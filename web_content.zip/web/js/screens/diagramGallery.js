/**
 * Diagram gallery — preview every CAPS / parametric recipe without grade gating.
 */
import { el, card } from "../ui/widgets.js";
import { DIAGRAM_CATALOG, drawCatalogDiagram, partsForDiagram } from "../engines/parametricEngine.js";
import { drawDiagram } from "../ui/render.js";
import { recipe } from "../engines/diagramEngine.js";
import { drawPeriodicTable, drawFormulaSheet } from "../engines/referenceEngine.js";
import { recipeById } from "../engines/recipeTemplates.js";

const FALLBACK_SPECS = {
  accounting_equation: { type: "accounting_equation", assets: 12000, liabilities: 4000, equity: 8000 },
  journal_table: { type: "journal_table" },
  t_account: { type: "t_account", account: "Bank", debit: [["Capital", "5 000"]], credit: [["Purchases", "1 200"]] },
  bank_recon: { type: "bank_recon" },
  food_web: { type: "food_web" },
  income_statement: { type: "income_statement" },
  trial_balance: { type: "trial_balance" }
};

function paint(canvas, id) {
  const w = 320, h = 230;
  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  canvas.style.width = w + "px";
  canvas.style.height = h + "px";
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, w, h);

  if (id === "periodic_table") {
    drawPeriodicTable(ctx, w, h);
    return;
  }
  if (id === "formula_maths") {
    drawFormulaSheet(ctx, w, h, "maths");
    return;
  }

  const handled = drawCatalogDiagram(ctx, w, h, id);
  if (handled === null) {
    const spec = FALLBACK_SPECS[id] || recipe(id, 11) || { type: id };
    drawDiagram(canvas, spec, w, h);
  }
}

export async function DiagramGallery(app) {
  const groups = {};
  DIAGRAM_CATALOG.forEach((d) => {
    groups[d.group] = groups[d.group] || [];
    groups[d.group].push(d);
  });

  const body = [
    el("button", { class: "btn-secondary", onClick: () => app.showSettings() }, "← Settings"),
    el("div", { class: "role-subtitle wrap" },
      "CAPS and parametric diagrams built from named parts on a layout grid. Each card lists parts; long recipes describe the textbook intent and how the figure should look.")
  ];

  Object.keys(groups).forEach((g) => {
    body.push(el("div", { class: "section-eyebrow" }, g.toUpperCase()));
    groups[g].forEach((d) => {
      const host = el("div", {
        style: "width:100%;max-width:340px;margin:0.35rem auto;border:1px solid var(--hairline);border-radius:0.75rem;overflow:hidden;background:#fff;"
      });
      const c = el("canvas");
      host.appendChild(c);
      const parts = partsForDiagram(d.id);
      const partsLine = parts.length
        ? "Parts: " + parts.map((p) => p.label).join(" · ")
        : d.id;
      const long = recipeById(d.id);
      const children = [
        el("div", { class: "role-heading" }, d.name),
        el("div", { class: "role-muted" }, partsLine)
      ];
      if (long && long.description) {
        children.push(el("div", {
          class: "role-muted wrap",
          style: "font-size:0.8rem;margin:0.35rem 0;line-height:1.35;"
        }, long.description.slice(0, 220) + (long.description.length > 220 ? "…" : "")));
      }
      if (long && long.look) {
        children.push(el("div", {
          class: "role-muted wrap",
          style: "font-size:0.78rem;margin-bottom:0.35rem;line-height:1.3;opacity:0.9;"
        }, "Look: " + long.look.slice(0, 160) + (long.look.length > 160 ? "…" : "")));
      }
      children.push(host);
      body.push(el("div", { class: "card" }, children));
      requestAnimationFrame(() => {
        try { paint(c, d.id); } catch (err) { console.warn("diagram", d.id, err); }
      });
    });
  });

  return { title: "🖼 Diagram library", bottomNavKey: "home", body };
}
