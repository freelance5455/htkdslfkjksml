import { el, card, masteryBar } from "../ui/widgets.js";
import { GamificationEngine } from "../engines/gamificationEngine.js";
import { EconomyEngine } from "../engines/economyEngine.js";

function titleCase(s) { return s.replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase()); }
function starsFor(v) {
  if (v >= 0.8) return "★★★";
  if (v >= 0.5) return "★★☆";
  if (v >= 0.25) return "★☆☆";
  return "☆☆☆";
}

export async function Profile(app) {
  const s = app.student;
  const mastery = s.mastery || {};
  const vals = Object.values(mastery);
  const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
  const gam = new GamificationEngine(s);
  const econ = new EconomyEngine(s);
  const [unlocked, total] = gam.progressSummary();
  const subLabel = (s.subject || "maths").replaceAll("_", " ");

  const body = [
    card(s.name || "Learner",
      `Grade 12 · ${titleCase(subLabel)}\nThe Elites Academy\n⭐ ${s.xp ?? 0} XP · Level ${s.level ?? 1}\n🪙 ${econ.balance()} stars · 🏅 ${unlocked}/${total} badges`),
    card("Today's goal", `${s.today_done ?? 0} / ${s.daily_goal ?? 20} · 🔥 ${s.streak ?? 0} day streak`),
    card("Overall mastery", `${Math.round(avg * 100)}% average`),

    el("div", { class: "section-eyebrow" }, "TOPICS"),
    ...Object.entries(mastery).sort((a, b) => b[1] - a[1]).slice(0, 12).map(([topic, val]) =>
      el("div", { class: "card" }, [
        el("div", { class: "role-heading wrap" }, `${titleCase(topic)} ${starsFor(val)}`),
        masteryBar("Mastery", val)
      ])
    ),

    card("Focus areas", (s.weaknesses || []).map(titleCase).join(", ") || "Looking solid"),
    card("Strengths", (s.strengths || []).map(titleCase).join(", ") || "More practice unlocks this"),

    card("Badges", "See what you have unlocked.", [{ label: "OPEN BADGES", onClick: () => app.showAchievements() }]),
    card("Rewards", "Spend stars on unlocks.", [{ label: "OPEN REWARDS", onClick: () => app.showRewards() }]),
    card("Settings", "Name, theme and daily goal.", [{ label: "OPEN", onClick: () => app.showSettings() }])
  ];

  return { title: "Profile", bottomNavKey: "profile", body };
}
