import { el, card } from "../ui/widgets.js";
import { licenceDaysLeft } from "../db.js";
import { AdaptiveEngine } from "../engines/adaptive.js";
import { EconomyEngine } from "../engines/economyEngine.js";
import { GamificationEngine, getWeeklyQuest, getDailyMissions } from "../engines/gamificationEngine.js";
import { applyTheme } from "../theme.js";
import { loadSubjectRegistry, subjectsForGrade, subjectChipLabel, defaultSubject, topicsForSubject, subjectAccent } from "../engines/subjectRegistry.js";
import { GradeManager } from "../engines/gradeManager.js";
import { mascotCard, homeMood, mascotLine, MASCOT_NAME } from "../engines/mascotEngine.js";
import { progressRing, subjectHero } from "../ui/visualPolish.js";

const GREETS = [
  "Good to see you",
  "Welcome back",
  "Ready when you are",
  "Let's make progress",
  "Sharp focus today",
  "You've got this",
  "Steady steps",
  "Time to shine",
  "Onwards",
  "Hi",
  "Hello",
  "Sawubona",
  "Yebo",
  "Afternoon focus",
  "Evening study mode"
];

function titleCase(s) {
  return String(s || "").replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

function subjectTopicIds(subject, grade) {
  const list = topicsForSubject(subject) || [];
  return list.map((t) => t.id || t).filter(Boolean);
}

function subjectInsights(student, subject) {
  const mastery = student.mastery || {};
  const ids = subjectTopicIds(subject, student.grade ?? 10);
  const scored = ids
    .map((id) => [id, mastery[id]])
    .filter(([, v]) => v != null && !Number.isNaN(v));
  if (!scored.length) {
    return {
      strengths: "Practise a few questions to build your profile.",
      weaknesses: "No subject data yet — start with notes or a short quiz.",
      tip: "Your strengths and focus areas will appear here for the selected subject."
    };
  }
  scored.sort((a, b) => b[1] - a[1]);
  const strong = scored.filter(([, v]) => v >= 0.65).slice(0, 3);
  const weak = scored.filter(([, v]) => v < 0.55).sort((a, b) => a[1] - b[1]).slice(0, 3);
  const strengths = strong.length
    ? strong.map(([id, v]) => `${titleCase(id)} (${Math.round(v * 100)}%)`).join(" · ")
    : "Still building — keep practising strong topics.";
  const weaknesses = weak.length
    ? weak.map(([id, v]) => `${titleCase(id)} (${Math.round(v * 100)}%)`).join(" · ")
    : "No critical gaps detected in this subject.";
  const tip = weak.length
    ? `Focus next: ${titleCase(weak[0][0])}.`
    : "Solid coverage — try exam-style papers for this subject.";
  return { strengths, weaknesses, tip };
}

export async function Home(app) {
  const s = app.student;
  await loadSubjectRegistry();
  const available = subjectsForGrade(10);
  if (!s.subject || !available.includes(s.subject)) s.subject = defaultSubject(10);
  s.subject = s.subject || "mathematical_literacy";
  const goal = s.daily_goal ?? 20, done = s.today_done ?? 0;
  const econ = new EconomyEngine(s);
  const gam = new GamificationEngine(s);
  gam.checkNewUnlocks();
  app.saveStudent();
  const [unlocked, visible] = gam.progressSummary();
  const name = s.name || "learner";
  const greet = GREETS[Math.floor(Math.random() * GREETS.length)];
  const insights = subjectInsights(s, s.subject);

  const themeMap = {
    theme_sunset: "Sunset", theme_forest: "Forest", theme_ocean: "Ocean",
    theme_candy: "Candy", theme_midnight: "Midnight", theme_neon: "Neon"
  };
  if (s.active_reward && themeMap[s.active_reward]) {
    applyTheme(themeMap[s.active_reward], s.settings?.font_scale || "Normal");
    s.settings = s.settings || {};
    s.settings.theme = themeMap[s.active_reward];
  }

  const pct = Math.min(100, Math.round((done / Math.max(1, goal)) * 100));
  const playCards = [
        (() => {
          const c = card("Practise", "Topic questions for this subject", [{ label: "GO", onClick: () => app.showPractice("choose") }]);
          c.classList.add("home-cta", "anim-reveal", "anim-tilt-hover");
          return c;
        })(),
        (() => { const c = card("Papers", "Exam-style papers and topic practice", [{ label: "GO", onClick: () => app.showPapers() }]); c.classList.add("anim-flip"); return c; })(),
        card("Notes", "Key facts, method and worked examples", [{ label: "GO", onClick: () => app.showSubjectHub() }])
      ];

  const learnCards = [
        card("Topics", "CAPS topics for this subject", [{ label: "GO", onClick: () => app.showSubjectHub() }]),
        card("Quiz", "Short questions with feedback", [{ label: "GO", onClick: () => app.navigate("subjectQuiz", { subjectId: s.subject, topicId: null }) }]),
        card("Reference", "Formulae and key tables", [{ label: "GO", onClick: () => app.showReferenceSheets() }])
      ];

  const mood = homeMood(s);
  const kepiLine = mood === "celebrate"
    ? mascotLine("goal")
    : mood === "nudge"
      ? mascotLine("idle")
      : mood === "happy"
        ? mascotLine("streak")
        : mascotLine("greet");

  const acc = subjectAccent(s.subject);
  const ring = progressRing(el, done, goal, {
    size: 64,
    stroke: 6,
    label: `${done}/${goal}`
  });
  ring.style.marginLeft = "auto";

  const statsLine = el("div", {
    class: "home-stats",
    style: "margin-top:0.4rem;opacity:0.95;font-size:0.9rem;display:flex;flex-wrap:wrap;gap:0.35rem 0.75rem;align-items:center;"
  }, [
    el("span", {}, `Lv ${s.level ?? 1}`),
    el("span", { class: "stat-xp" }, `✦ ${s.xp ?? 0} XP`),
    el("span", {}, `🔥 ${s.streak ?? 0}`),
    el("span", { class: "stat-stars score-pop" }, `⭐ ${econ.balance()}`)
  ]);

  const body = [
    el("div", {
      class: "card hero-card",
      style: `background:linear-gradient(145deg,${acc.hex},color-mix(in srgb,${acc.hex} 55%,#1e1b4b));color:#fff;border:none;padding:1.15rem 1.1rem;`
    }, [
      el("div", {
        style: "display:flex;align-items:flex-start;gap:0.75rem;"
      }, [
        el("div", { style: "flex:1;min-width:0;" }, [
          el("div", { style: "font-size:0.72rem;font-weight:800;letter-spacing:0.08em;opacity:0.9;text-transform:uppercase;" }, "Learnly Grade 10"),
          el("div", { class: "display-title", style: "font-size:1.5rem;font-weight:800;letter-spacing:-0.03em;margin-top:0.2rem;" }, `${greet}, ${name}`),
          statsLine,
          el("div", { style: "margin-top:0.35rem;opacity:0.9;font-size:0.8rem;" }, "Math Lit · Business · Tourism · The Elites Academy"),
          el("div", { style: "margin-top:0.2rem;opacity:0.85;font-size:0.75rem;font-weight:700;" },
            (() => { const d = licenceDaysLeft(); return d > 0 ? `Licence · ${d} day${d === 1 ? "" : "s"} left` : "Licence expired — renew in Settings"; })())
        ]),
        ring
      ]),
      el("div", { style: "margin-top:0.85rem;background:rgba(255,255,255,0.22);border-radius:999px;height:8px;overflow:hidden;" }, [
        el("div", { style: `height:100%;width:${pct}%;background:#fff;border-radius:999px;transition:width 0.45s cubic-bezier(0.22,1,0.36,1);` })
      ]),
      el("div", { style: "margin-top:0.4rem;font-size:0.82rem;opacity:0.92;" }, `Today ${done}/${goal} · ${insights.tip}`)
    ]),
    mascotCard(el, { mood, line: kepiLine, size: "68px" }),
    subjectHero(el, s.subject, {
      title: subjectChipLabel(s.subject).replace(/^[^\w]+/, "").trim(),
      subtitle: insights.tip
    }),
    el("div", {
      class: "btn-row subject-chip-row",
      style: "margin:0.5rem 0 0.75rem;gap:0.35rem;flex-wrap:wrap;"
    }, available.map((sid) => {
      const a = subjectAccent(sid);
      const active = s.subject === sid;
      return el("button", {
        class: "chip subject-accent-chip" + (active ? " active" : ""),
        style: active
          ? `flex:1;min-width:40%;padding:0.6rem;font-weight:700;background:${a.hex};border-color:${a.hex};color:#fff;`
          : `flex:1;min-width:40%;padding:0.6rem;font-weight:700;border-color:${a.hex};color:${a.hex};`,
        onClick: () => {
          s.subject = sid;
          app.saveStudent();
          try { app.applyThemeAndFont(); } catch (_) {}
          app.showHome();
        }
      }, subjectChipLabel(sid));
    })),
    (() => {
      const challenges = [
        { label: "5 quick questions", count: 5, mode: "recommended" },
        { label: "10-question sprint", count: 10, mode: "recommended" },
        { label: "Open a learning card", type: "lesson" },
        { label: "One exam-style paper", type: "paper" }
      ];
      const dayIdx = new Date().getDate() % challenges.length;
      const ch = challenges[dayIdx];
      const doneKey = `daily_ch_${new Date().toISOString().slice(0, 10)}`;
      const doneCh = !!(s.flags && s.flags[doneKey]);
      return card(
        doneCh ? "Daily challenge · done" : "Daily challenge",
        doneCh
          ? "You completed today’s challenge. Come back tomorrow."
          : ch.label + " · bonus XP when you finish.",
        doneCh ? [] : [{
          label: "START",
          onClick: async () => {
            s.flags = s.flags || {};
            s.flags[doneKey] = true;
            try {
              const { EconomyEngine, touchCalendarStreak } = await import("../engines/economyEngine.js");
              new EconomyEngine(s).reward("daily_challenge", "Daily challenge");
              touchCalendarStreak(s);
            } catch (_) {}
            app.saveStudent();
            if (ch.type === "lesson") return app.navigate("learningCardHub");
            if (ch.type === "paper") return app.showPapers();
            return app.navigate("practiceSession", {
              mode: ch.mode || "recommended",
              topics: subjectTopicIds(s.subject, 10),
              difficulty: 2,
              count: ch.count || 5,
              timed: false,
              hints: true,
              showSolution: true
            });
          }
        }]
      );
    })(),
    (() => {
      const wq = getWeeklyQuest(s);
      const pct = wq.target ? Math.min(100, Math.round((wq.progress || 0) / wq.target * 100)) : 0;
      return card(
        wq.done ? "Weekly quest · complete" : "Weekly quest",
        wq.done
          ? `${wq.label} — claimed. Next quest next week.`
          : `${wq.label} · ${wq.progress || 0}/${wq.target} (${pct}%)`,
        wq.done ? [] : [{
          label: "PRACTISE",
          onClick: () => app.navigate("practiceSession", {
            mode: "recommended",
            topics: subjectTopicIds(s.subject, 10),
            difficulty: 2,
            count: 8,
            timed: false,
            hints: true,
            showSolution: true
          })
        }]
      );
    })(),
    (() => {
      const pack = getDailyMissions(s);
      const items = pack.items || [];
      const doneN = items.filter((m) => m.done).length;
      const lines = items.map((m) => {
        const p = Math.min(m.target, m.progress || 0);
        const mark = m.done ? "✓" : "·";
        return `${mark} ${m.icon || ""} ${m.label} (${p}/${m.target})`;
      }).join("\n");
      return el("div", { class: "card anim-flip mission-card anim-tilt3d" }, [
        el("div", { class: "role-heading wrap" }, `Daily missions · ${doneN}/${items.length || 3}`),
        el("div", { class: "role-muted wrap", style: "margin-top:0.35rem;white-space:pre-wrap;font-size:0.88rem;line-height:1.45;" },
          lines || "Missions refresh each day."),
        el("div", { class: "meter", style: "margin-top:0.65rem;" }, [
          el("i", { style: `--meter:${items.length ? Math.round(doneN / items.length * 100) : 0}%` })
        ]),
        el("div", { class: "btn-row", style: "margin-top:0.65rem;" }, [
          el("button", {
            class: "btn-secondary",
            onClick: () => app.navigate("practiceSession", {
              mode: "recommended",
              topics: subjectTopicIds(s.subject, 10),
              difficulty: 2,
              count: 8,
              timed: false,
              hints: true,
              showSolution: true
            })
          }, "Practise"),
          el("button", {
            class: "btn-secondary",
            onClick: () => app.navigate("learningCardHub")
          }, "Lesson")
        ])
      ]);
    })(),
        ...(!s.flags?.install_guide_seen ? [
      card("Install & offline", "First-run guide: Add to Home Screen and check offline cache status.", [
        { label: "OPEN", onClick: () => app.navigate("installGuide") }
      ])
    ] : []),
    card("ATP term planner", "Term 1–4 checklist linked to topics, learning cards and papers.", [
      { label: "OPEN", onClick: () => app.navigate("atpPlanner") }
    ]),
    el("div", { class: "section-eyebrow" }, `THIS SUBJECT · ${subjectChipLabel(s.subject).replace(/^[^\w]+/, "")}`),
    card("Strengths", insights.strengths),
    card("Focus areas", insights.weaknesses),
    el("div", { class: "section-eyebrow" }, "PLAY"),
    ...playCards,
    el("div", { class: "section-eyebrow" }, "LEARN"),
    card("Learning cards", "Step-by-step lessons + memory check", [
      { label: "OPEN", onClick: () => app.navigate("learningCardHub") }
    ]),
    ...learnCards,
    el("div", { class: "section-eyebrow" }, "YOU"),
    card("Badges", `${unlocked}/${visible}`, [{ label: "OPEN", onClick: () => app.showAchievements() }]),
    card("Shop", "Themes & packs", [{ label: "OPEN", onClick: () => app.showRewards() }])
  ];

  return { title: "Home", showBack: false, bottomNavKey: "home", body };
}
