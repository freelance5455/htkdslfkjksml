// Paste your Supabase Project URL and anon/public key here.
// Supabase Dashboard → Project Settings → API.
// This file is safe to publish only with the anon/public key and proper RLS enabled.
// NEVER put a service_role/secret key in frontend code.
window.DIVAFIT_SUPABASE_URL = "YOUR_PROJECT_URL";
window.DIVAFIT_SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_PUBLIC_KEY";
