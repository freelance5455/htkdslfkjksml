
import { createWorker } from "https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/+esm";
let workerPromise;
async function getWorker(){
  if(!workerPromise) workerPromise=createWorker("ara+eng");
  return workerPromise;
}
export async function extractImageText(file){
  const w=await getWorker();
  const r=await w.recognize(await file.arrayBuffer());
  return r.data.text||"";
}
