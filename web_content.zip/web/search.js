
export function searchDocuments(docs,query){
  const terms=query.trim().toLowerCase().split(/\s+/).filter(Boolean);
  if(!terms.length)return [];
  const hits=[];
  for(const d of docs) for(const p of d.pages){
    const text=(p.text||"");
    const low=text.toLowerCase();
    const score=terms.reduce((n,t)=>n+(low.includes(t)?1:0),0);
    if(score)hits.push({name:d.name,page:p.page,score,text});
  }
  return hits.sort((a,b)=>b.score-a.score).slice(0,10);
}
