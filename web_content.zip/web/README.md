# AirTouch – hands-free phone control (HTML / JS)

Camera → hand tracking (MediaPipe Hands) → a dot follows your hand → pinch = tap.

## Run it
The camera only works on **HTTPS** or **localhost**.

* Quick test on PC:  `python -m http.server 8000`  then open http://localhost:8000
* On your phone: upload the folder to any free HTTPS host (Netlify Drop, GitHub Pages, Vercel, Cloudflare Pages) and open the link in Chrome / Safari.
* Optional: "Add to Home screen" installs it as an app (PWA).

## Gestures
| Gesture | Action |
|---|---|
| Move hand | Dot moves |
| Pinch thumb + index (quick) | Tap / click |
| Two quick pinches | Double tap (click, click, dblclick) |
| Pinch, hold, move up/down | Scroll |

## Make your own screens
Put your UI in `index.html` (replace the demo `<main id="app">`). Real DOM events are fired
(`pointerdown/up`, `mousedown/up`, `click`, `dblclick`), so normal buttons and links just work.
Add `data-g` to anything custom for the green hover highlight. Listen to gestures with:

    document.addEventListener('gesture', e => console.log(e.detail)); // {type:'tap'|'doubletap', x, y}

## Files
index.html · css/style.css · js/app.js (engine) · js/demo.js (demo UI) · manifest.json · sw.js · icons/

## Limits (important)
* A web page can only control **itself**. It cannot move a pointer over other apps or the home screen.
* Browsers pause the camera when the screen turns off or you switch apps. The app keeps the screen awake (Wake Lock) while it is open.
* For **whole-phone** control you need a native Android app (CameraX + MediaPipe + an AccessibilityService).
  This HTML project's `js/app.js` logic can be ported 1:1.
* Offline use: download `@mediapipe/hands` files into a `vendor/` folder and change `MP_BASE` in `js/app.js` and the `<script>` tag.
