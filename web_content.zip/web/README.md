# MasterFlow Trading — No Backend

Versi tanpa backend. Aplikasi mengambil data OHLCV langsung dari Twelve Data.

## Cara pakai
1. Buka aplikasi.
2. Masuk Pengaturan API.
3. Isi API Key Twelve Data.
4. Simpan.
5. Pilih saham lalu tekan ANALISIS.

Catatan keamanan: karena tanpa backend, API key berada di perangkat/browser dan tidak dapat disembunyikan dari sisi frontend. Gunakan untuk penggunaan pribadi dan patuhi ketentuan lisensi Twelve Data.

Tidak ada auto-trading dan tidak ada data/demo fallback.
