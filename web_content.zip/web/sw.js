/* Jurevia service worker: opens offline. Bump V on every release. */
const V = 'jurevia-v9-1';
const SHELL = ['./', 'index.html', 'manifest.webmanifest', 'assets/jurevia-hero.png', 'assets/jurevia-mark.png', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-512-maskable.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(V).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin) return;
  e.respondWith(fetch(r).then(x => { if (x.ok && x.status === 200) { const c = x.clone(); caches.open(V).then(h => h.put(r, c)); } return x; })
    .catch(() => caches.match(r).then(m => m || (r.mode === 'navigate' ? caches.match('index.html') : Response.error()))));
});
