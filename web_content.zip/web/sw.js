const CACHE_NAME = 'aether-calculator-v1.2';
const ASSETS = [
  './',
  './index.html',
  './favicon.svg',
  './manifest.webmanifest',
  './styles/tokens.css',
  './styles/app.css',
  './src/app.js',
  './src/engine/bigDecimal.js',
  './src/engine/numberFormatter.js',
  './src/engine/calculationEngine.js',
  './src/engine/unitConverter.js',
  './src/engine/toolsEngine.js',
  './src/engine/futureEngines.js',
  './src/state/storage.js',
  './src/state/calculatorStore.js',
  './src/state/converterStore.js',
  './src/ui/haptics.js',
  './src/ui/icons.js',
  './src/ui/calculatorView.js',
  './src/ui/converterView.js',
  './src/ui/historySheet.js',
  './src/ui/settingsSheet.js',
  './src/ui/toolsView.js',
  './src/ui/toolForms.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS)).then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))),
    ).then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).catch(() => caches.match('./index.html'));
    }),
  );
});
