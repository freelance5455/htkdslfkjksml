// Learnly G12 — offline-first service worker (browser PWA).
// Intentionally soft: never block APK / WebView asset loads.
const CACHE_NAME = "learnly-g12-v9-apk-safe";

const CORE_ASSETS = [
  "./",
  "./index.html",
  "./manifest.json",
  "./sw.js",
  "./css/style.css",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./content/curriculum_all_grades.json",
  "./content/tips_and_tricks.json",
  "./content/subject_topics.json",
  "./content/subjects_by_grade.json",
  "./content/grade12/past_papers/paper_templates.json",
  "./js/app.js",
  "./js/db.js",
  "./js/theme.js"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) =>
      Promise.all(
        CORE_ASSETS.map((url) => cache.add(url).catch(() => {}))
      )
    ).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  // Never intercept non-http(s) or Android asset-loader synthetic hosts
  try {
    const u = new URL(req.url);
    if (u.protocol !== "http:" && u.protocol !== "https:") return;
    if (u.hostname === "appassets.androidplatform.net") return;
  } catch (_) {
    return;
  }

  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;
      return fetch(req)
        .then((res) => {
          if (!res || res.status !== 200 || res.type === "opaque") return res;
          const copy = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, copy)).catch(() => {});
          return res;
        })
        .catch(() => {
          if (req.mode === "navigate" || (req.headers.get("accept") || "").includes("text/html")) {
            return caches.match("./index.html").then((r) => r || Response.error());
          }
          return Response.error();
        });
    })
  );
});
