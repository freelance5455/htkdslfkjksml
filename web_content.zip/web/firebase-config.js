const firebaseConfig = {
  apiKey: "AIzaSyD9f8E3eZuaUVXNOiycBsxqiw4bgW_McZg",
  authDomain: "hare-krishna-94342.firebaseapp.com",
  databaseURL: "https://hare-krishna-94342-default-rtdb.firebaseio.com",
  projectId: "hare-krishna-94342",
  storageBucket: "hare-krishna-94342.firebasestorage.app",
  messagingSenderId: "648445902152",
  appId: "1:648445902152:web:f1ef523abb197031f4c77d",
  measurementId: "G-2VWQXRJ3B4"
};
export { firebaseConfig };