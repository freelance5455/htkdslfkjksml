const $=id=>document.getElementById(id);
let api=(localStorage.getItem('gh_api')||'http://127.0.0.1:5000').replace(/\/$/,'');
$('apiBase').value=api;
let tf='M1', chart, candles, ema9, ema21, ema50;
function initChart(){
 if(!window.LightweightCharts){$('chartStatus').textContent='Chart library unavailable. Check internet connection.';return}
 chart=LightweightCharts.createChart($('chart'),{layout:{background:{color:'#121820'},textColor:'#9aa7b5'},grid:{vertLines:{color:'#202a35'},horzLines:{color:'#202a35'}},rightPriceScale:{borderColor:'#34404d'},timeScale:{borderColor:'#34404d',timeVisible:true,secondsVisible:false},crosshair:{mode:0}});
 candles=chart.addCandlestickSeries({upColor:'#19a879',downColor:'#d65460',borderUpColor:'#19a879',borderDownColor:'#d65460',wickUpColor:'#19a879',wickDownColor:'#d65460'});
 ema9=chart.addLineSeries({color:'#e7bd5c',lineWidth:1});ema21=chart.addLineSeries({color:'#64b5f6',lineWidth:1});ema50=chart.addLineSeries({color:'#bd83d9',lineWidth:1});
 new ResizeObserver(()=>chart.applyOptions({width:$('chart').clientWidth})).observe($('chart'));
}
async function get(path){const r=await fetch(api+path,{cache:'no-store'});if(!r.ok)throw Error((await r.json()).error||r.statusText);return r.json()}
function setConnected(ok,msg){$('dot').style.background=ok?'#20c58b':'#d59a39';$('connectionText').textContent=msg}
function lineData(rows,key){return rows.filter(x=>Number.isFinite(x[key])).map(x=>({time:x.time,value:x[key]}))}
async function refresh(){
 try{
  const [status,tick,cs,sig]=await Promise.all([get('/api/status'),get('/api/tick'),get('/api/candles?timeframe='+tf+'&limit=300'),get('/api/signal?timeframe='+tf)]);
  setConnected(status.connected,'MT5 CONNECTED');$('chartStatus').textContent=`${status.symbol} • ${tf} • broker time ${status.server_time||'—'}`;
  $('price').textContent=Number(tick.last).toFixed(status.digits??2);$('bid').textContent=Number(tick.bid).toFixed(status.digits??2);$('ask').textContent=Number(tick.ask).toFixed(status.digits??2);
  $('change').textContent=`Spread ${tick.spread_points} points`;
  const rows=cs.candles||[];if(rows.length&&candles){candles.setData(rows.map(x=>({time:x.time,open:x.open,high:x.high,low:x.low,close:x.close})));ema9.setData(lineData(rows,'ema9'));ema21.setData(lineData(rows,'ema21'));ema50.setData(lineData(rows,'ema50'));chart.timeScale().fitContent()}
  const s=sig.signal||{};$('signal').textContent=s.direction||'WAIT';$('signal').style.color=s.direction==='BUY'?'#20c58b':s.direction==='SELL'?'#e56b73':'#e5c779';
  $('signalState').textContent=s.direction==='WAIT'?'SCANNING':'SETUP DETECTED';$('confidence').textContent=`${s.score||0}/5 confirmations`;
  $('entry').textContent=s.entry??'--';$('sl').textContent=s.stop_loss??'--';$('tp').textContent=s.take_profit??'--';$('reason').textContent=s.reason||'No confirmed setup.';
  const i=s.indicators||{};$('rsi').textContent=i.rsi??'--';$('macd').textContent=i.macd??'--';$('ema').textContent=i.ema9&&i.ema21?`${i.ema9} / ${i.ema21}`:'--';$('trend').textContent=i.trend||'--';$('spread').textContent=tick.spread_points;$('pattern').textContent=i.pattern||'--';
 }catch(e){setConnected(false,'BRIDGE OFFLINE');$('chartStatus').textContent=e.message;$('orderResult').textContent='Connection error: '+e.message}
}
async function order(side){
 const mode=$('tradeMode').value;if(mode==='signal'){ $('orderResult').textContent=`${side} signal-only mode: no order sent.`;return}
 if(!confirm(`Send ${side} market order to the connected MT5 account? Verify account is DEMO before proceeding.`))return;
 try{const result=await fetch(api+'/api/order',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({side,volume:Number($('volume').value),sl_points:Number($('slPoints').value),tp_points:Number($('tpPoints').value),mode})}).then(r=>r.json());$('orderResult').textContent=result.message||JSON.stringify(result)}
 catch(e){$('orderResult').textContent='Order error: '+e.message}
}
$('buyBtn').onclick=()=>order('BUY');$('sellBtn').onclick=()=>order('SELL');$('refreshBtn').onclick=refresh;
$('saveApi').onclick=()=>{api=$('apiBase').value.trim().replace(/\/$/,'');localStorage.setItem('gh_api',api);refresh()};
document.querySelectorAll('[data-tf]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-tf]').forEach(x=>x.classList.remove('active'));b.classList.add('active');tf=b.dataset.tf;refresh()});
initChart();refresh();setInterval(refresh,3000);