/**
 * ATC Aviation Weather — Web Application Engine (ES6 Vanilla)
 * Daylight Aviation Console Standard (No Dark Mode)
 * Modular Multi-Screen Architecture matching ATC Calendar
 * Information-Specific Thematic Card Rendering
 */

// Comprehensive Airport Database (Iran Hubs Priority & Global)
const AIRPORTS = [
  // --- Iran Hubs ---
  { icao: "OIIE", iata: "IKA", nameEn: "Tehran Imam Khomeini Intl", nameFa: "فرودگاه بین‌المللی امام خمینی", cityFa: "تهران", countryFa: "ایران", lat: 35.416, lon: 51.152, elev: 3305, fir: "OIIX" },
  { icao: "OIII", iata: "THR", nameEn: "Tehran Mehrabad Intl", nameFa: "فرودگاه بین‌المللی مهرآباد", cityFa: "تهران", countryFa: "ایران", lat: 35.689, lon: 51.313, elev: 3962, fir: "OIIX" },
  { icao: "OIMM", iata: "MHD", nameEn: "Mashhad Shahid Hashemi Nejad", nameFa: "فرودگاه بین‌المللی شهید هاشمی‌نژاد مشهد", cityFa: "مشهد", countryFa: "ایران", lat: 36.235, lon: 59.641, elev: 3263, fir: "OIIX" },
  { icao: "OISS", iata: "SYZ", nameEn: "Shiraz Shahid Dastghaib", nameFa: "فرودگاه بین‌المللی شهید دستغیب شیراز", cityFa: "شیراز", countryFa: "ایران", lat: 29.539, lon: 52.589, elev: 4921, fir: "OIIX" },
  { icao: "OIFM", iata: "IFN", nameEn: "Isfahan Shahid Beheshti", nameFa: "فرودگاه بین‌المللی شهید بهشتی اصفهان", cityFa: "اصفهان", countryFa: "ایران", lat: 32.751, lon: 51.861, elev: 5059, fir: "OIIX" },
  { icao: "OITT", iata: "TBZ", nameEn: "Tabriz Shahid Madani", nameFa: "فرودگاه بین‌المللی شهید مدنی تبریز", cityFa: "تبریز", countryFa: "ایران", lat: 38.133, lon: 46.235, elev: 4459, fir: "OIIX" },
  { icao: "OIKB", iata: "BND", nameEn: "Bandar Abbas Intl", nameFa: "فرودگاه بین‌المللی بندرعباس", cityFa: "بندرعباس", countryFa: "ایران", lat: 27.218, lon: 56.378, elev: 22, fir: "OIIX" },
  { icao: "OIAW", iata: "AWZ", nameEn: "Ahvaz General Soleimani", nameFa: "فرودگاه بین‌المللی شهید سلیمانی اهواز", cityFa: "اهواز", countryFa: "ایران", lat: 31.337, lon: 48.762, elev: 66, fir: "OIIX" },
  { icao: "OIBK", iata: "KIH", nameEn: "Kish Island Intl", nameFa: "فرودگاه بین‌المللی کیش", cityFa: "کیش", countryFa: "ایران", lat: 26.526, lon: 53.980, elev: 101, fir: "OIIX" },
  { icao: "OIZH", iata: "ZAH", nameEn: "Zahedan Intl", nameFa: "فرودگاه بین‌المللی زاهدان", cityFa: "زاهدان", countryFa: "ایران", lat: 29.476, lon: 60.906, elev: 4525, fir: "OIIX" },
  { icao: "OIBB", iata: "BUZ", nameEn: "Bushehr Intl", nameFa: "فرودگاه بین‌المللی بوشهر", cityFa: "بوشهر", countryFa: "ایران", lat: 28.945, lon: 50.835, elev: 68, fir: "OIIX" },
  { icao: "OIKK", iata: "KER", nameEn: "Kerman Ayatollah Hashemi", nameFa: "فرودگاه بین‌المللی کرمان", cityFa: "کرمان", countryFa: "ایران", lat: 30.274, lon: 56.964, elev: 5741, fir: "OIIX" },
  { icao: "OIGG", iata: "RAS", nameEn: "Rasht Sardar Jangal", nameFa: "فرودگاه سردار جنگل رشت", cityFa: "رشت", countryFa: "ایران", lat: 37.325, lon: 49.626, elev: -40, fir: "OIIX" },
  { icao: "OINZ", iata: "SRY", nameEn: "Sari Dasht-e Naz", nameFa: "فرودگاه دشت ناز ساری", cityFa: "ساری", countryFa: "ایران", lat: 36.665, lon: 53.193, elev: 35, fir: "OIIX" },
  { icao: "OITY", iata: "AZD", nameEn: "Yazd Shahid Sadooghi", nameFa: "فرودگاه بین‌المللی شهید صدوقی یزد", cityFa: "یزد", countryFa: "ایران", lat: 31.905, lon: 54.276, elev: 4055, fir: "OIIX" },

  // --- Regional & International Hubs ---
  { icao: "OMDB", iata: "DXB", nameEn: "Dubai International", nameFa: "فرودگاه بین‌المللی دبی", cityFa: "دبی", countryFa: "امارات", lat: 25.253, lon: 55.365, elev: 62, fir: "OMAE" },
  { icao: "OTHH", iata: "DOH", nameEn: "Hamad International", nameFa: "فرودگاه بین‌المللی حمد دوحه", cityFa: "دوحه", countryFa: "قطر", lat: 25.273, lon: 51.608, elev: 13, fir: "OTBD" },
  { icao: "OKBK", iata: "KWI", nameEn: "Kuwait International", nameFa: "فرودگاه بین‌المللی کویت", cityFa: "کویت", countryFa: "کویت", lat: 29.227, lon: 47.979, elev: 206, fir: "OKAC" },
  { icao: "LTFM", iata: "IST", nameEn: "Istanbul Airport", nameFa: "فرودگاه بین‌المللی استانبول", cityFa: "استانبول", countryFa: "ترکیه", lat: 41.275, lon: 28.751, elev: 325, fir: "LTBB" },
  { icao: "EGLL", iata: "LHR", nameEn: "London Heathrow", nameFa: "فرودگاه هیترو لندن", cityFa: "لندن", countryFa: "بریتانیا", lat: 51.470, lon: -0.454, elev: 83, fir: "EGTT" },
  { icao: "KJFK", iata: "JFK", nameEn: "John F. Kennedy Intl", nameFa: "فرودگاه جان اف کندی نیویورک", cityFa: "نیویورک", countryFa: "ایالات متحده", lat: 40.639, lon: -73.778, elev: 13, fir: "KZNY" }
];

// App State
let currentAirport = AIRPORTS[0]; // OIIE default
let activeNavTab = 'home';
let currentMetar = null;
let currentTaf = null;
let activeSigmets = [];
let currentWindReport = null;
let selectedWindLevelIdx = 3; // FL180 default
let storedSnowtams = [];
let favorites = ['OIIE', 'OIII', 'OIMM', 'OISS'];
let isOffline = false;
let chipFilter = 'iran';
let manualBulletinType = 'METAR';

// Startup Lifecycle
document.addEventListener('DOMContentLoaded', () => {
  startLiveUtcClock();
  loadStoredPreferences();
  renderQuickChips(chipFilter);
  updateActiveAirportBanner();
  loadAllDataForAirport(currentAirport.icao);
  fetchGlobalSigmets();
  renderSnowtamView();
  renderAtcBoard();
});

// 1. Live Real-time UTC Clock
function startLiveUtcClock() {
  function tick() {
    const d = new Date();
    const hrs = String(d.getUTCHours()).padStart(2, '0');
    const mins = String(d.getUTCMinutes()).padStart(2, '0');
    const secs = String(d.getUTCSeconds()).padStart(2, '0');
    const clockEl = document.getElementById('live-utc-clock');
    if (clockEl) clockEl.textContent = `${hrs}:${mins}:${secs} UTC`;
  }
  tick();
  setInterval(tick, 1000);
}

// 2. Navigation Switcher (Synchronizing Top Tabs and Bottom Navigation Bar)
function switchNavTab(tabName) {
  activeNavTab = tabName;

  // Hide all sections
  document.querySelectorAll('.content-tab-page').forEach(page => page.classList.add('d-none'));

  // Show target page
  const target = document.getElementById(`page-${tabName}`);
  if (target) target.classList.remove('d-none');

  // Update Top Pill Buttons
  document.querySelectorAll('.atc-tab-pill').forEach(pill => pill.classList.remove('active'));
  const topPill = document.getElementById(`top-pill-${tabName}`);
  if (topPill) topPill.classList.add('active');

  // Update Bottom Nav Buttons
  document.querySelectorAll('.nav-tab-btn').forEach(btn => btn.classList.remove('active'));
  const botBtn = document.getElementById(`bot-btn-${tabName}`);
  if (botBtn) botBtn.classList.add('active');

  // If opening board, refresh board
  if (tabName === 'board') {
    renderAtcBoard();
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// 3. Airport Selection and Chips
// 3. Airport Selection and Chips
function renderQuickChips(filter = 'all', searchQuery = '') {
  chipFilter = filter;
  const container = document.getElementById('quick-chips-wrapper');
  if (!container) return;
  container.innerHTML = '';

  // Update filter buttons
  ['all', 'iran', 'intl'].forEach(f => {
    const btn = document.getElementById(`filter-btn-${f}`);
    if (btn) {
      if (f === filter) {
        btn.className = 'btn btn-sm btn-primary active px-3';
      } else {
        btn.className = 'btn btn-sm btn-outline-primary px-3';
      }
    }
  });

  let list = AIRPORTS;
  if (filter === 'iran') {
    list = AIRPORTS.filter(a => a.countryFa === 'ایران' || a.icao.startsWith('OI'));
  } else if (filter === 'intl') {
    list = AIRPORTS.filter(a => a.countryFa !== 'ایران' && !a.icao.startsWith('OI'));
  }

  if (searchQuery && searchQuery.trim() !== '') {
    const q = searchQuery.trim().toLowerCase();
    list = list.filter(a =>
      a.icao.toLowerCase().includes(q) ||
      (a.iata && a.iata.toLowerCase().includes(q)) ||
      (a.nameEn && a.nameEn.toLowerCase().includes(q)) ||
      (a.cityFa && a.cityFa.includes(q))
    );
  }

  list.forEach(apt => {
    const chip = document.createElement('div');
    const isCurrent = apt.icao === currentAirport.icao;
    const isDom = apt.icao.startsWith('OI') || apt.countryFa === 'ایران';
    chip.className = `btn btn-sm ${isCurrent ? 'btn-primary' : 'btn-light border'} text-nowrap`;
    chip.innerHTML = `<strong>${apt.icao}</strong> <small class="text-muted">(${apt.iata || apt.nameEn.split(' ')[0]})</small> <span class="badge ${isDom ? 'bg-success' : 'bg-warning text-dark'}" style="font-size: 8px;">${isDom ? 'DOM' : 'INTL'}</span>`;
    chip.onclick = () => selectAirport(apt);
    container.appendChild(chip);
  });
}

function filterChips(type) {
  const searchInput = document.getElementById('home-airport-search-input');
  const q = searchInput ? searchInput.value : '';
  renderQuickChips(type, q);
}

function handleAirportSearch(val) {
  renderQuickChips(chipFilter, val);
}

function selectAirport(apt) {
  currentAirport = apt;
  renderQuickChips(chipFilter);
  updateActiveAirportBanner();
  loadAllDataForAirport(apt.icao);
}

function updateActiveAirportBanner() {
  const badge = document.getElementById('current-icao-badge');
  const name = document.getElementById('current-airport-name');
  const city = document.getElementById('current-airport-city');
  const starIcon = document.getElementById('favorite-star-icon');

  if (badge) badge.textContent = currentAirport.icao;
  if (name) name.textContent = `${currentAirport.nameEn} (${currentAirport.nameFa})`;
  if (city) city.textContent = `${currentAirport.cityFa}, ${currentAirport.countryFa} • ${currentAirport.iata} • Elev ${currentAirport.elev} FT • FIR ${currentAirport.fir}`;

  const isFav = favorites.includes(currentAirport.icao);
  if (starIcon) {
    starIcon.className = isFav ? 'bi bi-star-fill text-warning' : 'bi bi-star';
  }
}

function toggleCurrentFavorite() {
  const idx = favorites.indexOf(currentAirport.icao);
  if (idx > -1) {
    favorites.splice(idx, 1);
  } else {
    favorites.push(currentAirport.icao);
  }
  localStorage.setItem('atc_favorites', JSON.stringify(favorites));
  updateActiveAirportBanner();
  renderFavoritesModalList();
}

function loadStoredPreferences() {
  try {
    const storedFavs = localStorage.getItem('atc_favorites');
    if (storedFavs) favorites = JSON.parse(storedFavs);

    const storedSnow = localStorage.getItem('atc_stored_snowtams');
    if (storedSnow) {
      storedSnowtams = JSON.parse(storedSnow);
    } else {
      seedSampleSnowtam();
    }
  } catch (e) {
    console.warn('Storage read warning', e);
  }
}

// 4. Data Retrieval Engine (AviationWeather.gov OPMET API + Open-Meteo GFS)
async function loadAllDataForAirport(icao) {
  // 1. Fetch METAR
  try {
    const url = `https://aviationweather.gov/api/data/metar?ids=${icao}&format=json`;
    const res = await fetch(url);
    if (res.ok) {
      const data = await res.json();
      if (data && data.length > 0) {
        currentMetar = parseMetar(data[0].rawOb || `METAR ${icao} 120500Z 28006KT 9999 FEW040 22/08 Q1020 NOSIG`, icao);
        currentMetar.source = "AviationWeather.gov (NOAA/NWS)";
        currentMetar.retrievalTime = new Date().toISOString().substring(11, 16) + ' UTC';
        localStorage.setItem(`metar_${icao}`, JSON.stringify(currentMetar));
        setOfflineState(false);
      } else {
        fallbackCachedMetar(icao);
      }
    } else {
      fallbackCachedMetar(icao);
    }
  } catch (e) {
    fallbackCachedMetar(icao);
  }

  // 2. Fetch TAF
  try {
    const url = `https://aviationweather.gov/api/data/taf?ids=${icao}&format=json`;
    const res = await fetch(url);
    if (res.ok) {
      const data = await res.json();
      if (data && data.length > 0) {
        currentTaf = parseTaf(data[0].rawTAF || `TAF ${icao}`, icao);
        currentTaf.source = "AviationWeather.gov WIFS";
        localStorage.setItem(`taf_${icao}`, JSON.stringify(currentTaf));
      } else {
        fallbackCachedTaf(icao);
      }
    } else {
      fallbackCachedTaf(icao);
    }
  } catch (e) {
    fallbackCachedTaf(icao);
  }

  // 3. Fetch Upper Winds (Open-Meteo GFS multi-level model)
  try {
    const windUrl = `https://api.open-meteo.com/v1/forecast?latitude=${currentAirport.lat}&longitude=${currentAirport.lon}&hourly=wind_speed_1000hPa,wind_direction_1000hPa,temperature_1000hPa,wind_speed_850hPa,wind_direction_850hPa,temperature_850hPa,wind_speed_700hPa,wind_direction_700hPa,temperature_700hPa,wind_speed_500hPa,wind_direction_500hPa,temperature_500hPa,wind_speed_400hPa,wind_direction_400hPa,temperature_400hPa,wind_speed_300hPa,wind_direction_300hPa,temperature_300hPa,wind_speed_250hPa,wind_direction_250hPa,temperature_250hPa,wind_speed_200hPa,wind_direction_200hPa,temperature_200hPa&wind_speed_unit=kn&forecast_days=1`;
    const windRes = await fetch(windUrl);
    if (windRes.ok) {
      const json = await windRes.json();
      currentWindReport = processUpperWindData(json);
    }
  } catch (e) {
    console.warn('Upper wind fetch error', e);
  }

  renderAllViews();
}

function fallbackCachedMetar(icao) {
  const cached = localStorage.getItem(`metar_${icao}`);
  if (cached) {
    currentMetar = JSON.parse(cached);
    setOfflineState(true);
  } else {
    // Generate realistic unparsed bulletin notice
    currentMetar = {
      icao,
      rawMetar: `METAR ${icao} NIL (NO RECENT REPORT / LIVE DATA UNAVAILABLE)`,
      isSpeci: false,
      windDir: null,
      windSpd: null,
      windGust: null,
      isCalm: false,
      isCavok: false,
      visMeters: null,
      temp: null,
      dewp: null,
      altHpa: null,
      altInHg: null,
      category: 'VFR',
      cloudsSummary: 'اطلاعات در دسترس نیست',
      ceilingFt: null,
      presentWeather: null,
      trend: 'NIL',
      source: 'OFFLINE CACHE (EMPTY)',
      obsTimeUtc: '--:--Z',
      retrievalTime: '--:-- UTC'
    };
    setOfflineState(true);
  }
}

function fallbackCachedTaf(icao) {
  const cached = localStorage.getItem(`taf_${icao}`);
  if (cached) {
    currentTaf = JSON.parse(cached);
  } else {
    currentTaf = {
      icao,
      rawTaf: `TAF ${icao} NIL (NO CURRENT TAF / CONTACT MET OFFICE)`,
      issueTime: '--:--Z',
      validPeriod: '--/--',
      source: 'LOCAL NOTICE'
    };
  }
}

function setOfflineState(offline) {
  isOffline = offline;
  const alert = document.getElementById('offline-alert');
  if (alert) {
    alert.classList.toggle('d-none', !offline);
  }
}

// Global SIGMET Fetcher
async function fetchGlobalSigmets() {
  try {
    const res = await fetch('https://aviationweather.gov/api/data/sigmet?format=json');
    if (res.ok) {
      const list = await res.json();
      activeSigmets = list || [];
      renderSigmetView();
    }
  } catch (e) {
    console.warn('SIGMET fetch error', e);
  }
}

function refreshCurrentPageData() {
  loadAllDataForAirport(currentAirport.icao);
  fetchGlobalSigmets();
}

// 5. ICAO Aviation Parsers (METAR, TAF, SNOWTAM)
function parseMetar(raw, icaoFallback) {
  const clean = raw.trim().replace(/\s+/g, ' ');
  const isSpeci = clean.startsWith('SPECI') || clean.includes(' SPECI ');

  // Wind parsing
  const windMatch = clean.match(/\b(\d{3}|VRB)(\d{2,3})(?:G(\d{2,3}))?KT\b/);
  let windDir = null, windSpd = null, windGust = null, isCalm = false;
  if (windMatch) {
    windDir = windMatch[1] === 'VRB' ? 'VRB' : parseInt(windMatch[1], 10);
    windSpd = parseInt(windMatch[2], 10);
    if (windSpd === 0) isCalm = true;
    if (windMatch[3]) windGust = parseInt(windMatch[3], 10);
  }

  // Cavok & Visibility
  const isCavok = clean.includes('CAVOK');
  let visMeters = null;
  if (isCavok) {
    visMeters = 9999;
  } else {
    const visMatch = clean.match(/\b(\d{4})\b/);
    if (visMatch && !clean.includes('Q' + visMatch[1]) && !clean.includes('A' + visMatch[1])) {
      visMeters = parseInt(visMatch[1], 10);
    }
  }

  // Clouds & Ceiling
  let ceilingFt = null;
  const cloudMatches = clean.match(/\b(FEW|SCT|BKN|OVC|VV)(\d{3})(CB|TCU)?\b/g);
  let cloudsSummary = isCavok ? "CAVOK (بدون ابر زیر ۵۰۰۰ پا)" : "صاف / بدون ابر مهم (NSC)";
  if (cloudMatches && cloudMatches.length > 0) {
    cloudsSummary = cloudMatches.join(' • ');
    for (const cm of cloudMatches) {
      const type = cm.substring(0, 3);
      const fl = parseInt(cm.substring(3, 6), 10) * 100;
      if ((type === 'BKN' || type === 'OVC' || type === 'VV') && ceilingFt === null) {
        ceilingFt = fl;
      }
    }
  }

  // Temperature & Dewpoint
  const tdMatch = clean.match(/\b(M?\d{2})\/(M?\d{2})\b/);
  let temp = null, dewp = null;
  if (tdMatch) {
    temp = parseSignedTemp(tdMatch[1]);
    dewp = parseSignedTemp(tdMatch[2]);
  }

  // Altimeter QNH
  const qnhMatch = clean.match(/\bQ(\d{4})\b/);
  let altHpa = qnhMatch ? parseInt(qnhMatch[1], 10) : null;
  const inHgMatch = clean.match(/\bA(\d{4})\b/);
  let altInHg = inHgMatch ? parseFloat((parseInt(inHgMatch[1], 10) / 100).toFixed(2)) : (altHpa ? parseFloat((altHpa * 0.02953).toFixed(2)) : null);

  // Present weather phenomena
  const wxCodes = ["-RA", "+RA", "RA", "-SN", "+SN", "SN", "TSRA", "TS", "FG", "BR", "HZ", "SA", "DU", "DZ", "VCTS"];
  let presentWeather = null;
  for (const c of wxCodes) {
    if (new RegExp(`\\b${c}\\b`).test(clean)) {
      presentWeather = c;
      break;
    }
  }

  // Trend
  let trend = "NOSIG (بدون تغییر مهم)";
  if (clean.includes("BECMG")) trend = "BECMG (روند تغییر تدریجی)";
  else if (clean.includes("TEMPO")) trend = "TEMPO (تغییرات نوسانی موقت)";

  // Flight Category (VFR, MVFR, IFR, LIFR)
  let category = 'VFR';
  const effVis = visMeters !== null ? visMeters : 10000;
  const effCeil = ceilingFt !== null ? ceilingFt : 10000;

  if (effCeil < 500 || effVis < 1600) category = 'LIFR';
  else if (effCeil < 1000 || effVis < 5000) category = 'IFR';
  else if (effCeil <= 3000 || effVis <= 8000) category = 'MVFR';
  else category = 'VFR';

  const timeMatch = clean.match(/\b(\d{6}Z)\b/);

  return {
    icao: icaoFallback,
    rawMetar: raw,
    isSpeci,
    windDir,
    windSpd,
    windGust,
    isCalm,
    isCavok,
    visMeters,
    cloudsSummary,
    ceilingFt,
    temp,
    dewp,
    altHpa,
    altInHg,
    presentWeather,
    trend,
    category,
    source: "AviationWeather.gov OPMET",
    obsTimeUtc: timeMatch ? timeMatch[1] : (new Date().toISOString().substring(8, 10) + new Date().toISOString().substring(11, 13) + '00Z'),
    retrievalTime: new Date().toISOString().substring(11, 16) + ' UTC'
  };
}

function parseSignedTemp(str) {
  if (str.startsWith('M')) return -parseInt(str.substring(1), 10);
  return parseInt(str, 10);
}

function parseTaf(raw, icaoFallback) {
  const clean = raw.trim().replace(/\s+/g, ' ');
  const timeMatch = clean.match(/\b(\d{6}Z)\s+(\d{4}\/\d{4})\b/);
  return {
    icao: icaoFallback,
    rawTaf: raw,
    issueTime: timeMatch ? timeMatch[1] : '--',
    validPeriod: timeMatch ? timeMatch[2] : '--',
    source: "AviationWeather.gov WIFS"
  };
}

function processUpperWindData(json) {
  if (!json || !json.hourly) return null;
  const h = json.hourly;
  const idx = 0; // Current forecast hour

  const levels = [
    { name: "سطح زمین (SFC)", alt: "300 FT", spd: Math.round(h.wind_speed_1000hPa?.[idx] || 0), dir: Math.round(h.wind_direction_1000hPa?.[idx] || 0), temp: Math.round(h.temperature_1000hPa?.[idx] || 0) },
    { name: "FL050 (850 hPa)", alt: "5,000 FT", spd: Math.round(h.wind_speed_850hPa?.[idx] || 0), dir: Math.round(h.wind_direction_850hPa?.[idx] || 0), temp: Math.round(h.temperature_850hPa?.[idx] || 0) },
    { name: "FL100 (700 hPa)", alt: "10,000 FT", spd: Math.round(h.wind_speed_700hPa?.[idx] || 0), dir: Math.round(h.wind_direction_700hPa?.[idx] || 0), temp: Math.round(h.temperature_700hPa?.[idx] || 0) },
    { name: "FL180 (500 hPa)", alt: "18,000 FT", spd: Math.round(h.wind_speed_500hPa?.[idx] || 0), dir: Math.round(h.wind_direction_500hPa?.[idx] || 0), temp: Math.round(h.temperature_500hPa?.[idx] || 0) },
    { name: "FL240 (400 hPa)", alt: "24,000 FT", spd: Math.round(h.wind_speed_400hPa?.[idx] || 0), dir: Math.round(h.wind_direction_400hPa?.[idx] || 0), temp: Math.round(h.temperature_400hPa?.[idx] || 0) },
    { name: "FL300 (300 hPa)", alt: "30,000 FT", spd: Math.round(h.wind_speed_300hPa?.[idx] || 0), dir: Math.round(h.wind_direction_300hPa?.[idx] || 0), temp: Math.round(h.temperature_300hPa?.[idx] || 0) },
    { name: "FL340 (250 hPa)", alt: "34,000 FT", spd: Math.round(h.wind_speed_250hPa?.[idx] || 0), dir: Math.round(h.wind_direction_250hPa?.[idx] || 0), temp: Math.round(h.temperature_250hPa?.[idx] || 0) },
    { name: "FL390 (200 hPa)", alt: "39,000 FT", spd: Math.round(h.wind_speed_200hPa?.[idx] || 0), dir: Math.round(h.wind_direction_200hPa?.[idx] || 0), temp: Math.round(h.temperature_200hPa?.[idx] || 0) }
  ];

  return { levels, time: h.time?.[idx] || 'Current UTC' };
}

// 6. View Renderers (Daylight Themed, Ergonomic and Color-Coded)
function renderAllViews() {
  renderHomeView();
  renderMetarView();
  renderTafView();
  renderWindView();
}

function renderHomeView() {
  const flightBadge = document.getElementById('home-flight-cat-badge');
  const stationTitle = document.getElementById('home-station-title');
  const stationTime = document.getElementById('home-station-time');
  const windSummary = document.getElementById('home-wind-summary');
  const visSummary = document.getElementById('home-vis-summary');
  const tempSummary = document.getElementById('home-temp-summary');
  const qnhSummary = document.getElementById('home-qnh-summary');
  const metarBadge = document.getElementById('badge-home-metar-status');

  if (stationTitle) stationTitle.textContent = `دیده‌بان فرودگاه ${currentAirport.icao} (${currentAirport.iata})`;

  if (currentMetar) {
    if (flightBadge) {
      flightBadge.className = `flight-cat-badge ${currentMetar.category} fs-6`;
      flightBadge.textContent = currentMetar.category;
    }
    if (stationTime) stationTime.textContent = `رصد رسمی پیام: ${currentMetar.obsTimeUtc}`;

    if (windSummary) {
      windSummary.textContent = currentMetar.isCalm ? "CALM" : `${currentMetar.windDir}°/${currentMetar.windSpd}KT`;
    }
    if (visSummary) {
      visSummary.textContent = currentMetar.isCavok ? "CAVOK" : (currentMetar.visMeters ? `${currentMetar.visMeters}m` : "--");
    }
    if (tempSummary) {
      tempSummary.textContent = currentMetar.temp !== null ? `${currentMetar.temp}°C` : "--";
    }
    if (qnhSummary) {
      qnhSummary.textContent = currentMetar.altHpa ? `Q${currentMetar.altHpa}` : "--";
    }
    if (metarBadge) {
      metarBadge.textContent = currentMetar.isSpeci ? "SPECI فعال" : "METAR OK";
      metarBadge.className = currentMetar.isSpeci ? "badge bg-danger" : "badge bg-primary";
    }
  }
}

function renderMetarView() {
  const rawBox = document.getElementById('raw-metar-display');
  const obsTime = document.getElementById('metar-obs-time');
  const retTime = document.getElementById('metar-retrieval-time');
  const sourceTag = document.getElementById('metar-source-tag');
  const speciBox = document.getElementById('speci-alert-box');
  const homeSnippet = document.getElementById('home-raw-metar-snippet');

  if (!currentMetar) return;

  if (rawBox) rawBox.textContent = currentMetar.rawMetar;
  if (homeSnippet) homeSnippet.textContent = currentMetar.rawMetar;
  if (obsTime) obsTime.textContent = `Observation Time: ${currentMetar.obsTimeUtc}`;
  if (retTime) retTime.textContent = `Receipt: ${currentMetar.retrievalTime}`;
  if (sourceTag) sourceTag.textContent = `Source: ${currentMetar.source}`;
  if (speciBox) speciBox.classList.toggle('d-none', !currentMetar.isSpeci);

  // A. Wind Card
  const windVal = document.getElementById('decoded-wind-val');
  const windMps = document.getElementById('decoded-wind-mps');
  const gustBadge = document.getElementById('wind-gust-badge');
  const arrow = document.getElementById('wind-compass-arrow');

  if (windVal) {
    windVal.textContent = currentMetar.isCalm ? "آرام (CALM 00000KT)" : `${currentMetar.windDir}° / ${currentMetar.windSpd} گره (KT)`;
  }
  if (windMps && currentMetar.windSpd !== null) {
    const mps = Math.round(currentMetar.windSpd * 0.514444);
    const kmh = Math.round(currentMetar.windSpd * 1.852);
    windMps.textContent = `معادل: ${mps} متر بر ثانیه (m/s) • ${kmh} km/h`;
  }
  if (gustBadge) {
    gustBadge.classList.toggle('d-none', !currentMetar.windGust);
    if (currentMetar.windGust) gustBadge.textContent = `تندباد GUST: ${currentMetar.windGust} KT`;
  }
  if (arrow && currentMetar.windDir !== null && typeof currentMetar.windDir === 'number') {
    arrow.style.transform = `rotate(${currentMetar.windDir}deg)`;
  }

  // B. Visibility Card (Themed by category)
  const visCard = document.getElementById('card-vis-container');
  const visVal = document.getElementById('decoded-vis-val');
  const catBadge = document.getElementById('decoded-cat-badge');
  const rvrVal = document.getElementById('decoded-rvr-val');
  const catDesc = document.getElementById('decoded-cat-desc');

  if (catBadge) {
    catBadge.className = `flight-cat-badge ${currentMetar.category}`;
    catBadge.textContent = currentMetar.category;
  }
  if (visCard) {
    visCard.className = `atc-card h-100 card-${currentMetar.category.toLowerCase()}`;
  }
  if (visVal) {
    visVal.textContent = currentMetar.isCavok ? "CAVOK (دید بیش از ۱۰ کیلومتر)" : (currentMetar.visMeters ? `${currentMetar.visMeters} متر (${(currentMetar.visMeters/1000).toFixed(1)} کیلومتر)` : "نامشخص");
  }
  if (catDesc) {
    const descMap = {
      'VFR': 'دید پرواز بصری بدون محدودیت عملیاتی',
      'MVFR': 'دید پرواز بصری بینابینی (Marginal VFR)',
      'IFR': 'دید پرواز با دستگاه (احتمال تأخیر ترافیک)',
      'LIFR': 'دید بسیار کم زیر حداقل‌های تقرب (Low IFR)'
    };
    catDesc.textContent = descMap[currentMetar.category] || '';
  }

  // C. Clouds Card
  const cloudsSummary = document.getElementById('decoded-clouds-summary');
  const ceilingBadge = document.getElementById('decoded-ceiling-badge');
  const ceilingFt = document.getElementById('decoded-ceiling-ft');

  if (cloudsSummary) cloudsSummary.textContent = currentMetar.cloudsSummary;
  if (ceilingFt) {
    ceilingFt.textContent = currentMetar.ceilingFt ? `سقف پرواز عملیاتی (Ceiling): ${currentMetar.ceilingFt} پا AGL` : "فاقد سقف ابر محدودکننده (بدون لایه BKN/OVC)";
  }
  if (ceilingBadge) {
    ceilingBadge.textContent = currentMetar.ceilingFt ? `CEILING: ${currentMetar.ceilingFt} FT` : "NO CEILING";
  }

  // D. Temperature & Dew Point Card
  const tempVal = document.getElementById('decoded-temp-val');
  const dewVal = document.getElementById('decoded-dew-val');
  const spreadVal = document.getElementById('decoded-spread-val');
  const spreadAlert = document.getElementById('decoded-spread-alert');

  if (tempVal) tempVal.textContent = currentMetar.temp !== null ? `${currentMetar.temp} °C (${Math.round((currentMetar.temp*9/5)+32)} °F)` : "--";
  if (dewVal) dewVal.textContent = `نقطه شبنم: ${currentMetar.dewp !== null ? currentMetar.dewp : '--'} °C`;

  if (spreadVal && currentMetar.temp !== null && currentMetar.dewp !== null) {
    const spread = currentMetar.temp - currentMetar.dewp;
    spreadVal.textContent = `فاصله: ${spread} °C`;
    if (spread <= 2) {
      spreadAlert.textContent = "هشدار: احتمال شدید تشکیل مه و اشباع بخار آب";
      spreadAlert.className = "small fw-bold text-danger";
    } else {
      spreadAlert.textContent = "رطوبت نسبی متناسب — عدم ریسک مه ناگهانی";
      spreadAlert.className = "small text-muted";
    }
  }

  // E. Altimeter QNH Card
  const qnhHpa = document.getElementById('decoded-qnh-hpa');
  const qnhInhg = document.getElementById('decoded-qnh-inhg');

  if (qnhHpa) qnhHpa.textContent = currentMetar.altHpa ? `Q${currentMetar.altHpa} hPa` : "نامشخص";
  if (qnhInhg) qnhInhg.textContent = currentMetar.altInHg ? `معادل: A${currentMetar.altInHg.toFixed(2)} inHg` : "--";

  // F. Weather & Trend Card
  const wxPhenom = document.getElementById('decoded-wx-phenom');
  const trendVal = document.getElementById('decoded-trend-val');

  if (wxPhenom) wxPhenom.textContent = currentMetar.presentWeather || "بدون پدیده جوی نامساعد";
  if (trendVal) trendVal.textContent = currentMetar.trend;
}

function renderTafView() {
  const rawBox = document.getElementById('raw-taf-display');
  const issueTime = document.getElementById('taf-issue-time');
  const validPeriod = document.getElementById('taf-valid-period');
  const groupsContainer = document.getElementById('taf-groups-container');

  if (!currentTaf) return;

  if (rawBox) rawBox.textContent = currentTaf.rawTaf;
  if (issueTime) issueTime.textContent = `زمان صدور: ${currentTaf.issueTime}`;
  if (validPeriod) validPeriod.textContent = `دوره اعتبار: ${currentTaf.validPeriod}`;

  if (!groupsContainer) return;
  groupsContainer.innerHTML = '';

  // Parse TAF groups (TEMPO, BECMG, PROB, FM)
  const lines = currentTaf.rawTaf.split(/(?=\b(?:TEMPO|BECMG|PROB\d{2}|FM\d{6})\b)/g);
  lines.forEach((part, index) => {
    const text = part.trim();
    if (!text) return;

    let cardBg = 'var(--card-bg)';
    let cardBorder = 'var(--border-color)';
    let badgeText = 'BASE (پیش‌بینی پایه)';
    let badgeColor = 'var(--primary-blue)';

    if (text.startsWith('TEMPO')) {
      cardBg = 'var(--taf-tempo-bg)';
      cardBorder = 'var(--taf-tempo-border)';
      badgeText = 'TEMPO (تغییرات موقت)';
      badgeColor = 'var(--taf-tempo-text)';
    } else if (text.startsWith('BECMG')) {
      cardBg = 'var(--taf-becmg-bg)';
      cardBorder = 'var(--taf-becmg-border)';
      badgeText = 'BECMG (روند تدریجی)';
      badgeColor = 'var(--taf-becmg-text)';
    } else if (text.startsWith('PROB')) {
      cardBg = 'var(--taf-prob-bg)';
      cardBorder = 'var(--taf-prob-border)';
      badgeText = 'PROB (احتمال رخداد)';
      badgeColor = 'var(--taf-prob-text)';
    }

    const card = document.createElement('div');
    card.className = 'atc-card mb-2';
    card.style.background = cardBg;
    card.style.border = `1.5px solid ${cardBorder}`;
    card.innerHTML = `
      <div class="d-flex justify-content-between align-items-center mb-2">
        <span class="badge" style="background: ${badgeColor}; color: white;">${badgeText}</span>
        <small class="text-muted">گروه #${index + 1}</small>
      </div>
      <div class="raw-message-box p-2 fs-6 mb-0" style="background: white;">${text}</div>
    `;
    groupsContainer.appendChild(card);
  });
}

function renderSigmetView() {
  const container = document.getElementById('sigmet-messages-list');
  const countBadge = document.getElementById('badge-sigmet-count');
  if (!container) return;

  if (activeSigmets.length === 0) {
    container.innerHTML = `
      <div class="text-center py-4">
        <i class="bi bi-shield-check text-success fs-1 mb-2 d-block"></i>
        <h6 class="fw-bold text-success">در حال حاضر هیچ پیام SIGMET فعالی در محدوده ثبت نشده است</h6>
        <small class="text-muted">شرایط پروازی در FIRهای بررسی شده فاقد پدیده‌های مخرب فوق‌العاده گزارش شده است.</small>
      </div>
    `;
    if (countBadge) countBadge.textContent = 'SIGMET (0)';
    return;
  }

  if (countBadge) countBadge.textContent = `SIGMET (${activeSigmets.length})`;
  container.innerHTML = '';

  activeSigmets.slice(0, 15).forEach((sig, idx) => {
    let cardBg = 'var(--sigmet-turb-bg)';
    let cardBorder = 'var(--sigmet-turb-border)';
    let hazardColor = 'var(--sigmet-turb-text)';

    const haz = (sig.hazard || '').toUpperCase();
    if (haz.includes('TS') || haz.includes('CONV')) {
      cardBg = 'var(--sigmet-ts-bg)';
      cardBorder = 'var(--sigmet-ts-border)';
      hazardColor = 'var(--sigmet-ts-text)';
    } else if (haz.includes('ICE')) {
      cardBg = 'var(--sigmet-ice-bg)';
      cardBorder = 'var(--sigmet-ice-border)';
      hazardColor = 'var(--sigmet-ice-text)';
    }

    const card = document.createElement('div');
    card.className = 'atc-card mb-2';
    card.style.background = cardBg;
    card.style.border = `1.5px solid ${cardBorder}`;
    card.innerHTML = `
      <div class="d-flex justify-content-between align-items-center mb-2">
        <div class="d-flex align-items-center gap-2">
          <span class="badge" style="background: ${hazardColor}; color: white;">${sig.firId || 'OIIX'}</span>
          <strong class="text-dark">${sig.firName || 'منطقه پروازی'}</strong>
        </div>
        <span class="badge bg-light text-dark border">اعتبار: ${sig.validTimeFrom || '--'} تا ${sig.validTimeTo || '--'}</span>
      </div>
      <div class="mb-2">
        <strong style="color: ${hazardColor};">پدیده: ${sig.hazard || 'مخاطره جوی'}</strong>
        ${sig.altitude ? `<span class="small text-muted ms-2">• تراز: ${sig.altitude}</span>` : ''}
      </div>
      <div class="raw-message-box p-2 fs-6 mb-0" style="background: white;">${sig.rawSigmet || 'NO RAW TEXT AVAILABLE'}</div>
    `;
    container.appendChild(card);
  });
}

function renderAtcBoard() {
  const grid = document.getElementById('atc-board-grid');
  if (!grid) return;
  grid.innerHTML = '';

  const hubIcaos = ['OIIE', 'OIII', 'OIMM', 'OISS', 'OIFM', 'OITT', 'OIBK', 'OIAW', 'OIKB', 'OMDB', 'LTFM', 'OTHH'];
  const hubs = hubIcaos.map(code => AIRPORTS.find(a => a.icao === code)).filter(Boolean);

  hubs.forEach(apt => {
    const isCurrent = apt.icao === currentAirport.icao;
    const col = document.createElement('div');
    col.className = 'col-12 col-md-6 col-lg-4';

    col.innerHTML = `
      <div class="atc-card h-100 p-3 cursor-pointer" style="border: 2px solid ${isCurrent ? 'var(--primary-blue)' : 'var(--border-color)'}; background: #FFFFFF; cursor: pointer;" onclick="selectAirportByIcao('${apt.icao}')">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <div>
            <strong class="fs-5 text-primary">${apt.icao}</strong>
            <small class="text-muted ms-1">(${apt.iata})</small>
            <div class="small fw-bold text-dark">${apt.nameFa}</div>
          </div>
          <span class="flight-cat-badge VFR" id="board-cat-${apt.icao}">VFR</span>
        </div>
        <div class="d-flex justify-content-between small text-muted pt-2 border-top">
          <span>تراز: ${apt.elev} FT</span>
          <span>منطقه: ${apt.fir}</span>
          <span class="text-primary fw-bold">انتخاب فرودگاه ←</span>
        </div>
      </div>
    `;
    grid.appendChild(col);
  });
}

function selectAirportByIcao(icao) {
  const apt = AIRPORTS.find(a => a.icao === icao);
  if (apt) {
    selectAirport(apt);
    switchNavTab('metar');
  }
}

function renderWindView() {
  const tableBody = document.getElementById('wind-levels-table-body');
  const spotlightTitle = document.getElementById('spotlight-level-title');
  const spotlightWind = document.getElementById('spotlight-wind-val');
  const spotlightTemp = document.getElementById('spotlight-temp-val');

  if (!currentWindReport) return;

  const lvl = currentWindReport.levels[selectedWindLevelIdx] || currentWindReport.levels[0];
  if (spotlightTitle) spotlightTitle.textContent = `${lvl.name}`;
  if (spotlightWind) spotlightWind.textContent = `${lvl.dir}° / ${lvl.spd} KT`;
  if (spotlightTemp) spotlightTemp.textContent = `${lvl.temp} °C`;

  if (!tableBody) return;
  tableBody.innerHTML = '';

  currentWindReport.levels.forEach((l, idx) => {
    const tr = document.createElement('tr');
    tr.className = idx === selectedWindLevelIdx ? 'table-primary fw-bold' : '';
    tr.style.cursor = 'pointer';
    tr.onclick = () => selectFlightLevel(idx);
    tr.innerHTML = `
      <td><strong>${l.name}</strong></td>
      <td>${l.alt}</td>
      <td class="text-primary fw-bold">${l.dir}° / ${l.spd} KT</td>
      <td class="${l.temp <= 0 ? 'text-primary' : 'text-danger'} fw-bold">${l.temp} °C</td>
    `;
    tableBody.appendChild(tr);
  });
}

function selectFlightLevel(index) {
  selectedWindLevelIdx = index;
  document.querySelectorAll('#flight-levels-chips .airport-chip').forEach((chip, i) => {
    chip.classList.toggle('active', i === index);
  });
  renderWindView();
}

function renderSnowtamView() {
  const container = document.getElementById('snowtam-content-container');
  if (!container) return;

  if (storedSnowtams.length > 0) {
    const s = storedSnowtams[0];
    const rwyccColor = (code) => {
      switch (code) {
        case 6: return 'var(--rwycc-6)';
        case 5: return 'var(--rwycc-5)';
        case 4: return 'var(--rwycc-4)';
        case 3: return 'var(--rwycc-3)';
        case 2: return 'var(--rwycc-2)';
        case 1: return 'var(--rwycc-1)';
        case 0: return 'var(--rwycc-0)';
        default: return '#64748B';
      }
    };

    container.innerHTML = `
      <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
          <h5 class="fw-bold mb-0">وضعیت سه‌گانه باند ${s.rwy} (ICAO GRF)</h5>
          <small class="text-muted">شماره سریال: ${s.serial} • زمان ثبت: ${s.issueTime}</small>
        </div>
        <span class="badge" style="background-color: ${rwyccColor(s.lowestRwycc)}; font-size: 1rem; color: white;">
          حداقل RWYCC: ${s.lowestRwycc}
        </span>
      </div>

      <div class="rwy-thirds-box">
        <div class="rwy-third" style="background: ${rwyccColor(s.rwycc1)}33;">
          <div class="title">THIRD 1 (ابتدای باند)</div>
          <div class="rwycc-pill" style="background: ${rwyccColor(s.rwycc1)};">RWYCC ${s.rwycc1}</div>
        </div>
        <div class="rwy-third" style="background: ${rwyccColor(s.rwycc2)}33;">
          <div class="title">THIRD 2 (میانه باند)</div>
          <div class="rwycc-pill" style="background: ${rwyccColor(s.rwycc2)};">RWYCC ${s.rwycc2}</div>
        </div>
        <div class="rwy-third" style="background: ${rwyccColor(s.rwycc3)}33;">
          <div class="title">THIRD 3 (انتهای باند)</div>
          <div class="rwycc-pill" style="background: ${rwyccColor(s.rwycc3)};">RWYCC ${s.rwycc3}</div>
        </div>
      </div>

      <div class="p-3 bg-light rounded border mb-3">
        <div class="row g-2 small">
          <div class="col-6"><strong>نوع آلاینده سطحی:</strong> ${s.contaminant}</div>
          <div class="col-6"><strong>منبع داده:</strong> ${s.source}</div>
        </div>
      </div>

      <label class="form-label small text-muted fw-bold">پیام خام رسمی اسنوتام (RAW SNOWTAM):</label>
      <div class="raw-message-box">${s.rawSnowtam}</div>
    `;
  }
}

function seedSampleSnowtam() {
  const sample = {
    id: Date.now(),
    icao: currentAirport.icao,
    serial: "0001",
    rwy: "29R",
    rwycc1: 5,
    rwycc2: 5,
    rwycc3: 5,
    lowestRwycc: 5,
    contaminant: "WET SNOW (برف مرطوب تا ۳ میلی‌متر)",
    rawSnowtam: `SWIR0001 ${currentAirport.icao} 12050020\n(SNOWTAM 0001\n${currentAirport.icao}\n12050020 29R 5/5/5 100/100/100 03/03/03 WET SNOW/WET SNOW/WET SNOW\nRWY 29R FICON 5/5/5 100/100/100 03/03/03 WET SNOW/WET SNOW/WET SNOW)`,
    issueTime: new Date().toISOString().substring(11, 16) + 'Z',
    source: "ICAO GRF Sample (Doc 10066)"
  };
  storedSnowtams = [sample];
  localStorage.setItem('atc_stored_snowtams', JSON.stringify(storedSnowtams));
  renderSnowtamView();
}

// 7. Utility Actions: Copy & AFTN Import
function copyRawMessage(elementId) {
  const el = document.getElementById(elementId);
  if (!el) return;
  navigator.clipboard.writeText(el.textContent).then(() => {
    alert("متن پیام هوانوردی با موفقیت در حافظه کپی شد.");
  }).catch(() => {
    // Fallback
    const area = document.createElement('textarea');
    area.value = el.textContent;
    document.body.appendChild(area);
    area.select();
    document.execCommand('copy');
    document.body.removeChild(area);
    alert("متن پیام در حافظه کپی شد.");
  });
}

function openAftnImportModal(type) {
  manualBulletinType = type;
  const modal = new bootstrap.Modal(document.getElementById('aftnImportModal'));
  modal.show();
}

function applyManualBulletin() {
  const input = document.getElementById('manual-bulletin-input');
  if (!input || !input.value.trim()) return;

  const raw = input.value.trim();
  if (manualBulletinType === 'METAR') {
    currentMetar = parseMetar(raw, currentAirport.icao);
    currentMetar.source = "شبکه اختصاصی AFTN / ورود دستی";
    renderMetarView();
    renderHomeView();
    switchNavTab('metar');
  } else if (manualBulletinType === 'TAF') {
    currentTaf = parseTaf(raw, currentAirport.icao);
    currentTaf.source = "شبکه اختصاصی AFTN / ورود دستی";
    renderTafView();
    switchNavTab('taf');
  }

  const modalEl = document.getElementById('aftnImportModal');
  const modal = bootstrap.Modal.getInstance(modalEl);
  if (modal) modal.hide();
  input.value = '';
}

// 8. Search Modal Logic
function handleAirportSearch(query) {
  const resultsContainer = document.getElementById('airport-search-results');
  if (!resultsContainer) return;
  resultsContainer.innerHTML = '';

  const q = query.trim().toLowerCase();
  if (!q) {
    renderFavoritesModalList();
    return;
  }

  const matched = AIRPORTS.filter(a =>
    a.icao.toLowerCase().includes(q) ||
    a.iata.toLowerCase().includes(q) ||
    a.nameFa.toLowerCase().includes(q) ||
    a.nameEn.toLowerCase().includes(q) ||
    a.cityFa.toLowerCase().includes(q)
  );

  if (matched.length === 0) {
    resultsContainer.innerHTML = `<div class="p-3 text-center text-muted">فرودگاهی با این مشخصات یافت نشد.</div>`;
    return;
  }

  matched.forEach(a => {
    const item = document.createElement('button');
    item.className = 'list-group-item list-group-item-action d-flex justify-content-between align-items-center py-2';
    item.innerHTML = `
      <div>
        <strong class="text-primary">${a.icao}</strong> / ${a.iata || '--'}
        <div class="small text-dark">${a.nameFa} (${a.cityFa}، ${a.countryFa})</div>
      </div>
      <span class="badge bg-light text-secondary border">تراز ${a.elev} FT</span>
    `;
    item.onclick = () => {
      selectAirport(a);
      const modal = bootstrap.Modal.getInstance(document.getElementById('searchAirportModal'));
      if (modal) modal.hide();
    };
    resultsContainer.appendChild(item);
  });
}

function renderFavoritesModalList() {
  const chipsList = document.getElementById('favorites-chips-list');
  if (!chipsList) return;
  chipsList.innerHTML = '';

  favorites.forEach(icao => {
    const apt = AIRPORTS.find(a => a.icao === icao);
    if (!apt) return;
    const chip = document.createElement('span');
    chip.className = 'badge bg-light text-primary border cursor-pointer p-2';
    chip.style.cursor = 'pointer';
    chip.innerHTML = `<i class="bi bi-star-fill text-warning me-1"></i> ${apt.icao} • ${apt.nameFa}`;
    chip.onclick = () => {
      selectAirport(apt);
      const modal = bootstrap.Modal.getInstance(document.getElementById('searchAirportModal'));
      if (modal) modal.hide();
    };
    chipsList.appendChild(chip);
  });
}
