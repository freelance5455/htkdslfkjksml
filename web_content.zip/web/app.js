import { initializeApp } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js";
import { getAuth, signInAnonymously, signOut, onAuthStateChanged, setPersistence, browserLocalPersistence } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js";
import { getDatabase, ref, get, set, push, update, remove } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-database.js";
import { getStorage, ref as storageRef, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-storage.js";
import { firebaseConfig } from "./firebase-config.js";

const app=initializeApp(firebaseConfig),auth=getAuth(app),db=getDatabase(app),storage=getStorage(app),ADMIN_PASSWORD="2011";
const $=id=>document.getElementById(id);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[c]));
const localDate=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`};
function toast(x){const t=$("toast");t.textContent=x;t.classList.add("show");clearTimeout(window._toast);window._toast=setTimeout(()=>t.classList.remove("show"),2400)}
function item(title,body,actions=""){return `<div class="item"><b>${esc(title)}</b><small>${esc(body)}</small>${actions}</div>`}
function openTab(id){document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));$(id)?.classList.add("active");document.querySelectorAll("aside button,.mobile-nav button").forEach(b=>b.classList.toggle("active",b.dataset.tab===id));window.scrollTo({top:0,behavior:"smooth"})}
document.querySelectorAll("aside button,.mobile-nav button").forEach(b=>b.onclick=()=>openTab(b.dataset.tab));
document.querySelectorAll("[data-open]").forEach(b=>b.onclick=()=>openTab(b.dataset.open));

async function openAdmin(){
  if($("password").value!==ADMIN_PASSWORD)return toast("Wrong admin password.");
  try{await signInAnonymously(auth);localStorage.setItem("vwAdminUnlocked","1");showAdmin();toast("Admin panel opened.");}
  catch(e){toast(e.message||"Firebase sign-in failed.");}
}
function showAdmin(){$("auth").classList.add("hidden");$("adminApp").classList.remove("hidden");loadAll()}
$("login").onclick=openAdmin;$("password").addEventListener("keydown",e=>{if(e.key==="Enter")openAdmin()});
setPersistence(auth,browserLocalPersistence).catch(()=>{});
onAuthStateChanged(auth,u=>{if(u&&localStorage.getItem("vwAdminUnlocked")==="1")showAdmin()});
$("logout").onclick=async()=>{localStorage.removeItem("vwAdminUnlocked");await signOut(auth);$("adminApp").classList.add("hidden");$("auth").classList.remove("hidden");$("password").value=""};

async function loadAll(){
  await Promise.allSettled([loadUsers(),loadYatra(),loadCourses(),loadChallenges(),loadBooks(),loadPosters(),loadContent(),loadQuotes(),loadCalendar(),loadYoutube(),loadNotifications()]);
  setupQuizEditor("Hindi");setupQuizEditor("Bengali");
  loadQuizHistory("Hindi");loadQuizHistory("Bengali");
  $("leaderDate").value=localDate();
}

async function notify(title,text,type="General"){
  const r=push(ref(db,"notifications"));
  await set(r,{title,text,type,createdAt:Date.now(),source:"admin"});
}
async function uploadImage(file,path){
  if(!file)throw new Error("Select an image first.");
  const safe=file.name.replace(/[^a-zA-Z0-9._-]/g,"_");
  const r=storageRef(storage,`${path}/${Date.now()}_${safe}`);
  await uploadBytes(r,file);
  return await getDownloadURL(r);
}

async function loadUsers(){
  const s=await get(ref(db,"users"));
  $("usersCount").textContent=s.exists()?Object.keys(s.val()).length:0;
  $("devoteeList").innerHTML=s.exists()?Object.entries(s.val()).map(([id,v])=>item(v.name||"Devotee",`${v.phone||v.mobile||""} · UID ${id}`)).join(""):"<div class='panel muted'>No devotees.</div>";
}

function memberArray(m){
  if(Array.isArray(m))return m;
  if(m&&typeof m==="object")return Object.values(m);
  return [];
}
async function loadYatra(){
  const s=await get(ref(db,"yatra"));
  $("yatraCount").textContent=s.exists()?Object.keys(s.val()).length:0;
  if(!s.exists()){$("yatraList").innerHTML="<div class='panel muted'>No registrations.</div>";return}
  $("yatraList").innerHTML=Object.entries(s.val()).map(([id,v])=>{
    const members=memberArray(v.members);
    const memberHtml=members.map((m,i)=>{
      const uid=m.uid||m.userId||m.devoteeUid||"";
      return `<div class="item"><b>${esc(m.name||m.fullName||`Member ${i+1}`)}</b><small>Status: ${esc(m.status||v.status||"Pending")} · Seat: ${esc(m.seatNumber||m.seat||"Not assigned")} ${uid?`· UID ${esc(uid)}`:""}</small><div class="actions"><button onclick="setMemberStatus('${id}','${esc(uid)}','Approved')">Approve</button><button onclick="setMemberStatus('${id}','${esc(uid)}','Rejected')" class="danger">Reject</button><button onclick="assignSeat('${id}','${esc(uid)}')">Set Seat</button><button onclick="ticketUpload('${id}','${esc(uid)}')">Upload Ticket</button></div></div>`;
    }).join("");
    return `<div class="item"><b>${esc(v.name||v.bookingId||id)}</b><small>${esc(v.status||"Pending")} · ${members.length} member(s) · Booking ${esc(id)}</small><div class="actions"><button onclick="setYatra('${id}','Approved')">Approve All</button><button onclick="setYatra('${id}','Rejected')" class="danger">Reject All</button><button onclick="openYatraDetails('${id}')">View Members</button></div><div id="yatraMembers-${id}" class="hidden">${memberHtml}</div></div>`;
  }).join("");
}
window.openYatraDetails=id=>{document.getElementById(`yatraMembers-${id}`)?.classList.toggle("hidden")};
window.setYatra=async(id,status)=>{await update(ref(db,"yatra/"+id),{status,updatedAt:Date.now()});await notify("Yatra status updated",`Yatra application ${id} is now ${status}.`,"Yatra");toast("Yatra status updated");loadYatra()};
window.setMemberStatus=async(id,uid,status)=>{
  const s=await get(ref(db,"yatra/"+id+"/members"));if(!s.exists())return toast("Members not found.");
  const members=s.val();
  let found=false;
  Object.entries(members).forEach(([k,m])=>{if(String(m.uid||m.userId||m.devoteeUid||"")===String(uid)){members[k].status=status;found=true}});
  if(!found)return toast("Member UID not found.");
  await set(ref(db,"yatra/"+id+"/members"),members);await notify("Yatra member status",`A Yatra member in ${id} is ${status}.`,"Yatra");toast("Member status updated");loadYatra();
};
window.assignSeat=async(id,uid)=>{
  const seat=prompt("Enter seat number:");if(!seat)return;
  const s=await get(ref(db,"yatra/"+id+"/members"));if(!s.exists())return toast("Members not found.");
  const members=s.val();let found=false;
  Object.entries(members).forEach(([k,m])=>{if(String(m.uid||m.userId||m.devoteeUid||"")===String(uid)){members[k].seatNumber=seat;found=true}});
  if(!found)return toast("Member UID not found.");
  await set(ref(db,"yatra/"+id+"/members"),members);await notify("Yatra seat assigned",`Your Yatra seat has been assigned: ${seat}.`,"Yatra");toast("Seat saved");loadYatra();
};
window.ticketUpload=async(id,uid)=>{
  const input=document.createElement("input");input.type="file";input.accept="image/*,.pdf";input.onchange=async()=>{
    try{
      const file=input.files[0];if(!file)return;
      const url=await uploadImage(file,`yatraTickets/${id}/${uid||"booking"}`);
      const s=await get(ref(db,"yatra/"+id+"/members"));if(!s.exists())return toast("Members not found.");
      const members=s.val();let found=false;
      Object.entries(members).forEach(([k,m])=>{if(String(m.uid||m.userId||m.devoteeUid||"")===String(uid)){members[k].ticketUrl=url;found=true}});
      if(found){await set(ref(db,"yatra/"+id+"/members"),members)}else{await update(ref(db,"yatra/"+id),{ticketUrl:url})}
      await notify("Yatra ticket uploaded","Your Yatra ticket is now available in the app.","Yatra");toast("Ticket uploaded");loadYatra();
    }catch(e){toast(e.message||"Ticket upload failed.")}};
  input.click();
};

async function loadCourses(){const s=await get(ref(db,"courses"));$("courseCount").textContent=s.exists()?Object.keys(s.val()).length:0;$("courseAdminList").innerHTML=s.exists()?Object.entries(s.val()).map(([id,v])=>item(v.title||id,v.description||"")).join(""):"<div class='panel muted'>No courses.</div>"}
$("addCourse").onclick=async()=>{const title=$("courseTitle").value.trim();if(!title)return toast("Enter a course title.");const r=push(ref(db,"courses"));await set(r,{title,description:$("courseDesc").value.trim(),duration:$("courseDuration").value.trim(),days:{},createdAt:Date.now()});await notify("New course added",title,"Course");toast("Course created");loadCourses()};

function addTaskRow(name="",points=10){const row=document.createElement("div");row.className="task-editor-row";row.innerHTML=`<input class="task-name" placeholder="Task name" value="${esc(name)}"><input class="task-points" type="number" min="1" value="${Number(points)}"><button class="secondary remove-task">Remove</button>`;row.querySelector(".remove-task").onclick=()=>row.remove();$("taskEditor").appendChild(row)}
$("addTask").onclick=()=>addTaskRow();
if(!$("taskEditor").children.length){addTaskRow("16 Mala",160);addTaskRow("Daily Quiz",100);addTaskRow("Aarti",100)}
$("addChallenge").onclick=async()=>{const tasks={};[...document.querySelectorAll(".task-editor-row")].forEach((r,i)=>{const n=r.querySelector(".task-name").value.trim();if(n)tasks["task"+(i+1)]={name:n,points:Number(r.querySelector(".task-points").value||10)}});const r=push(ref(db,"challenges"));const title=$("challengeTitle").value.trim()||"Weekly Bhakti Challenge";await set(r,{title,week:$("challengeWeek").value.trim()||"THIS WEEK",active:true,tasks,createdAt:Date.now()});await notify("New Weekly Challenge",title,"Challenge");toast("Challenge published");loadChallenges()};
async function loadChallenges(){const s=await get(ref(db,"challenges"));$("challengeCount").textContent=s.exists()?Object.keys(s.val()).length:0;$("challengeAdminList").innerHTML=s.exists()?Object.entries(s.val()).map(([id,v])=>item(v.title||id,`${v.week||""} · ${Object.keys(v.tasks||{}).length} task(s)`)).join(""):"<div class='panel muted'>No challenges.</div>"};

function setupQuizEditor(language){
  const key=language.toLowerCase(),date=$(key==="hindi"?"quizHindiDate":"quizBengaliDate"),box=$(key==="hindi"?"quizHindiEditor":"quizBengaliEditor");
  if(!date.value)date.value=localDate();box.innerHTML="";
  for(let i=1;i<=10;i++){const q=document.createElement("div");q.className="quiz-admin-question";q.innerHTML=`<div class="q-number">Q${i}</div><textarea data-q="question" placeholder="${language} question ${i}"></textarea><input data-q="A" placeholder="Option A"><input data-q="B" placeholder="Option B"><input data-q="C" placeholder="Option C"><input data-q="D" placeholder="Option D"><select data-q="correct"><option>A</option><option>B</option><option>C</option><option>D</option></select>`;box.appendChild(q)}
  date.onchange=()=>loadQuizForDate(language,date.value);loadQuizForDate(language,date.value);
}
async function quizPath(language,date){return `quiz/daily/${language.toLowerCase()}/${date}`}
async function loadQuizForDate(language,date){
  const box=$(language==="Hindi"?"quizHindiEditor":"quizBengaliEditor");if(!date||!box)return;
  const s=await get(ref(db,await quizPath(language,date)));const qs=s.exists()?s.val():null;
  box.querySelectorAll(".quiz-admin-question").forEach((b,i)=>{const v=qs?.["Q"+(i+1)]||{};b.querySelector('[data-q="question"]').value=v.question||"";["A","B","C","D"].forEach(k=>b.querySelector(`[data-q="${k}"]`).value=v["option"+k]||"");b.querySelector('[data-q="correct"]').value=v.correct||"A"});
}
async function publishQuiz(language){
  const key=language.toLowerCase(),date=$(key==="hindi"?"quizHindiDate":"quizBengaliDate"),box=$(key==="hindi"?"quizHindiEditor":"quizBengaliEditor");if(!date.value)return toast("Select a quiz date.");
  const payload={};let valid=true;
  box.querySelectorAll(".quiz-admin-question").forEach((b,i)=>{const q=b.querySelector('[data-q="question"]').value.trim(),A=b.querySelector('[data-q="A"]').value.trim(),B=b.querySelector('[data-q="B"]').value.trim(),C=b.querySelector('[data-q="C"]').value.trim(),D=b.querySelector('[data-q="D"]').value.trim(),correct=b.querySelector('[data-q="correct"]').value;if(!q||!A||!B||!C||!D)valid=false;payload["Q"+(i+1)]={question:q,optionA:A,optionB:B,optionC:C,optionD:D,correct,language,createdAt:Date.now()}});
  if(!valid)return toast("Complete all 10 questions.");
  await set(ref(db,await quizPath(language,date.value)),payload);await notify(`New ${language} Quiz`,`Today's ${language} quiz is now available.`,"Quiz");toast(`${language} quiz published.`);loadQuizHistory(language);
}
$("publishQuizHindi").onclick=()=>publishQuiz("Hindi");$("publishQuizBengali").onclick=()=>publishQuiz("Bengali");
async function loadQuizHistory(language){
  const key=language.toLowerCase(),s=await get(ref(db,`quiz/daily/${key}`)),box=$(language==="Hindi"?"quizHindiHistory":"quizBengaliHistory");let h="";
  if(s.exists())Object.entries(s.val()).sort((a,b)=>b[0].localeCompare(a[0])).forEach(([date,v])=>h+=`<div class="item"><b>${esc(date)}</b><small>${Object.keys(v||{}).length} questions</small><div class="actions"><button onclick="editQuiz('${language}','${date}')">Edit</button><button onclick="deleteQuiz('${language}','${date}')" class="danger">Delete</button></div></div>`);
  box.innerHTML=h||'<div class="muted">No quiz history yet.</div>';
}
window.editQuiz=async(language,date)=>{const id=language==="Hindi"?"quizHindi":"quizBengali";$(language==="Hindi"?"quizHindiDate":"quizBengaliDate").value=date;await loadQuizForDate(language,date);openTab(id);toast(`${language} quiz loaded.`)};
window.deleteQuiz=async(language,date)=>{if(!confirm(`Delete ${language} quiz for ${date}?`))return;await remove(ref(db,`quiz/daily/${language.toLowerCase()}/${date}`));toast("Quiz deleted.");loadQuizHistory(language)};

async function loadBooks(){
  const s=await get(ref(db,"books"));$("bookAdminList").innerHTML=s.exists()?Object.entries(s.val()).map(([id,v])=>`<div class="item media-row">${v.imageUrl?`<img class="thumb" src="${esc(v.imageUrl)}">`:""}<div class="media-copy"><b>${esc(v.title||id)}</b><small>${esc(v.author||"")} · ${esc(v.language||"")} · ${esc(v.price||"")}</small><small>${esc(v.description||"")}</small></div><div class="actions"><button onclick="deleteBook('${id}')" class="danger">Delete</button></div></div>`).join(""):"<div class='panel muted'>No books yet.</div>"
}
$("addBook").onclick=async()=>{
  try{const title=$("bookTitle").value.trim(),file=$("bookImage").files[0];if(!title||!file)return toast("Book name and image are required.");const imageUrl=await uploadImage(file,"books");const r=push(ref(db,"books"));await set(r,{title,author:$("bookAuthor").value.trim(),language:$("bookLanguage").value,price:$("bookPrice").value.trim(),description:$("bookDesc").value.trim(),imageUrl,createdAt:Date.now()});await notify("New book added",title,"Book");toast("Book published");loadBooks()}catch(e){toast(e.message||"Book upload failed. Check Storage rules/plan.")}}
window.deleteBook=async id=>{if(!confirm("Delete this book?"))return;await remove(ref(db,"books/"+id));loadBooks();toast("Book deleted")};

async function loadPosters(){const s=await get(ref(db,"posters"));$("posterAdminList").innerHTML=s.exists()?Object.entries(s.val()).map(([id,v])=>`<div class="item media-row">${v.imageUrl?`<img class="thumb" src="${esc(v.imageUrl)}">`:""}<div class="media-copy"><b>${esc(v.title||id)}</b><small>${new Date(v.createdAt||0).toLocaleString()}</small></div><div class="actions"><button onclick="deletePoster('${id}')" class="danger">Delete</button></div></div>`).join(""):"<div class='panel muted'>No posters yet.</div>"}
$("addPoster").onclick=async()=>{try{const title=$("posterTitle").value.trim(),file=$("posterImage").files[0];if(!title||!file)return toast("Poster title and image are required.");const imageUrl=await uploadImage(file,"posters");const r=push(ref(db,"posters"));await set(r,{title,imageUrl,createdAt:Date.now()});await notify("New poster added",title,"Poster");toast("Poster published");loadPosters()}catch(e){toast(e.message||"Poster upload failed. Check Storage rules/plan.")}};
window.deletePoster=async id=>{if(!confirm("Delete this poster?"))return;await remove(ref(db,"posters/"+id));loadPosters();toast("Poster deleted")};

async function loadContent(){const s=await get(ref(db,"bhaktiContent"));$("contentAdminList").innerHTML=s.exists()?Object.entries(s.val()).map(([id,v])=>item(v.title||id,v.type||"")).join(""):"<div class='panel muted'>No content.</div>"}
$("addContent").onclick=async()=>{const title=$("contentTitle").value.trim();if(!title)return toast("Enter a title.");const r=push(ref(db,"bhaktiContent"));await set(r,{type:$("contentType").value,title,text:$("contentText").value,createdAt:Date.now()});await notify("New Bhakti Content",title,"Katha");toast("Content published");loadContent()};

async function loadQuotes(){const s=await get(ref(db,"prabhupadaToday"));$("quoteAdminList").innerHTML=s.exists()?Object.entries(s.val()).sort((a,b)=>b[0].localeCompare(a[0])).map(([date,v])=>`<div class="item"><b>${esc(date)}</b><small>${esc(v.text||"")}</small><small>Source: ${esc(v.source||"Not added")}</small><div class="actions"><button onclick="deleteQuote('${date}')" class="danger">Delete</button></div></div>`).join(""):"<div class='panel muted'>No quotes yet.</div>"}
$("quoteDate").value=localDate();
$("addQuote").onclick=async()=>{const date=$("quoteDate").value,text=$("quoteText").value.trim();if(!date||!text)return toast("Date and quote are required.");await set(ref(db,`prabhupadaToday/${date}`),{date,text,source:$("quoteSource").value.trim(),createdAt:Date.now()});await notify("Prabhupada Today",`Today's Prabhupada quote is available for ${date}.`,"Prabhupada Today");toast("Today's quote published");loadQuotes()};
window.deleteQuote=async date=>{if(!confirm("Delete this quote?"))return;await remove(ref(db,`prabhupadaToday/${date}`));loadQuotes();toast("Quote deleted")};

async function loadCalendar(){const s=await get(ref(db,"calendar"));$("calendarAdminList").innerHTML=s.exists()?Object.entries(s.val()).map(([id,v])=>item(v.title||id,v.date||"")).join(""):"<div class='panel muted'>No calendar events.</div>"}
$("addCalendar").onclick=async()=>{const title=$("calTitle").value.trim();if(!title)return toast("Enter a festival title.");const r=push(ref(db,"calendar"));await set(r,{date:$("calDate").value,title,details:$("calDetails").value,createdAt:Date.now()});await notify("Calendar update",title,"Calendar");toast("Calendar event published");loadCalendar()};

async function loadYoutube(){const s=await get(ref(db,"youtube"));$("youtubeAdminList").innerHTML=s.exists()?Object.entries(s.val()).map(([id,v])=>item(v.title||id,v.url||"")).join(""):"<div class='panel muted'>No videos.</div>"}
$("addYoutube").onclick=async()=>{const title=$("ytTitle").value.trim();if(!title)return toast("Enter a video title.");const r=push(ref(db,"youtube"));await set(r,{title,url:$("ytUrl").value,description:$("ytDesc").value,createdAt:Date.now()});await notify("New YouTube video",title,"YouTube");toast("Video published");loadYoutube()};

async function loadNotifications(){const s=await get(ref(db,"notifications"));$("notificationAdminList").innerHTML=s.exists()?Object.entries(s.val()).sort((a,b)=>(b[1].createdAt||0)-(a[1].createdAt||0)).map(([id,v])=>item(v.title||id,`${v.type||"General"} · ${v.text||""}`)).join(""):"<div class='panel muted'>No notifications.</div>"}
$("addNotification").onclick=async()=>{const title=$("nTitle").value.trim(),text=$("nText").value.trim();if(!title||!text)return toast("Title and message are required.");await notify(title,text,$("nType").value);toast("Notification published");loadNotifications()};

$("loadLeaderboard").onclick=async()=>{
  const date=$("leaderDate").value;if(!date)return toast("Select a date.");
  const s=await get(ref(db,`quiz/results/${date}`));if(!s.exists()){$("leaderboardList").innerHTML="<div class='panel muted'>No quiz results for this date.</div>";return}
  const rows=Object.values(s.val()).map(v=>({name:v.name||"Devotee",score:Number(v.score||0),total:Number(v.total||10),submittedAt:Number(v.submittedAt||0),language:v.language||"Unknown"})).sort((a,b)=>b.score-a.score||a.submittedAt-b.submittedAt||a.name.localeCompare(b.name));
  $("leaderboardList").innerHTML=rows.map((v,i)=>`<div class="item"><b>#${i+1} · ${esc(v.name)}</b><small>${esc(v.language)} · Score ${v.score}/${v.total}</small></div>`).join("");
};
