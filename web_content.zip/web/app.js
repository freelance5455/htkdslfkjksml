const $=id=>document.getElementById(id);
const ACCOUNTS=[
 {id:'cash',name:'Caisse physique',type:'Caisse'},
 {id:'airtel',name:'Airtel Money',type:'Mobile Money'},
 {id:'orange',name:'Orange Money',type:'Mobile Money'},
 {id:'mpesa',name:'M-Pesa',type:'Mobile Money'}
];
const CURRENCIES=['FC','USD'];
const USD_FC_RATE=2250;
const fmt=(n,c)=>c==='USD'?'$'+Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}):Number(n||0).toLocaleString('fr-FR',{maximumFractionDigits:0})+' FC';
const today=()=>new Date().toISOString().slice(0,10);
const month=()=>today().slice(0,7);
let db=load();
function blank(){return {opening:{},tx:[]}}
function load(){try{return JSON.parse(localStorage.getItem('mercury_db'))||blank()}catch(e){return blank()}}
function save(){localStorage.setItem('mercury_db',JSON.stringify(db));renderAll()}
function accountOptions(includeCash=true){return ACCOUNTS.filter(a=>includeCash||a.id!=='cash').map(a=>`<option value="${a.id}">${a.name}</option>`).join('')}
function field(label,id,html){return `<label>${label}</label><div>${html}</div>`}
function input(id,placeholder='0',step='0.01'){return `<input id="${id}" type="number" min="0" step="${step}" placeholder="${placeholder}">`}
function select(id,opts){return `<select id="${id}">${opts}</select>`}
function currSelect(id='currency'){return select(id,CURRENCIES.map(c=>`<option>${c}</option>`).join(''))}
function accountSelect(id='account',includeCash=true){return select(id,accountOptions(includeCash))}
function renderForm(){
 const k=$('kind').value;let h=''; $('quickOptions').innerHTML='';
 if(k==='sale'){
 h=field('Activité', 'activity',select('activity','<option>Vente unités</option><option>Vente forfaits</option>'))+
 field('Compte qui reçoit le paiement','account',accountSelect())+
 `<div class="row"><div>${field('Devise','currency',currSelect())}</div><div>${field('Montant encaissé','amount',input('amount'))}</div></div>`+
 `<div class="row"><div>${field("Coût d'achat total",'cost',input('cost'))}</div><div>${field('Coût déjà payé maintenant','paidCost',input('paidCost'))}</div></div>`+
 `<p class="small">Le bénéfice = montant encaissé − coût d'achat. Le solde est augmenté du montant encaissé puis diminué du coût déjà payé. Si le fournisseur n'est pas encore payé, mets 0 dans « coût déjà payé ».</p>`;
 }else if(k==='mm_deposit'||k==='mm_withdraw'){
 h=field('Service', 'wallet',select('wallet','<option value="airtel">Airtel Money</option><option value="orange">Orange Money</option><option value="mpesa">M-Pesa</option>'))+
 `<div class="row"><div>${field('Devise','currency',currSelect())}</div><div>${field('Montant client','amount',input('amount'))}</div></div>`+
 `<div class="row"><div>${field('Commission gagnée (FC)','commission',input('commission','0','1'))}</div><div>${field('Caisse physique','cashAccount',`<div class="pill">Caisse physique</div>`)}</div></div>`+
 `<p class="small">${k==='mm_deposit'?'Dépôt : le client te remet le montant + commission en espèces ; ton portefeuille Mobile Money diminue du montant envoyé.':'Retrait : ton portefeuille Mobile Money reçoit le montant ; tu remets au client le montant moins la commission.'}</p>`;
 }else if(k==='fx_usd_fc'||k==='fx_fc_usd'){
 h=`<div class="row"><div>${field('Montant USD','usd',input('usd'))}</div><div>${field('Montant FC','fc',input('fc','0','1'))}</div></div>`+
 `<div class="row"><div>${field('Taux de référence (FC pour 1 USD)','rate',input('rate',String(USD_FC_RATE),'1'))}</div><div>${field('Compte utilisé','account',accountSelect())}</div></div>`+
 `<p class="small">${k==='fx_usd_fc'?'Client donne USD et reçoit FC.':'Client donne FC et reçoit USD.'} Le bénéfice est estimé en FC avec le taux de référence saisi. Vérifie le résultat avant d'enregistrer.</p>`;
 }else if(k==='expense'){
 h=field('Catégorie','activity',select('activity','<option>Loyer</option><option>Transport</option><option>Électricité / Internet</option><option>Frais de fonctionnement</option><option>Autre</option>'))+
 `<div class="row"><div>${field('Compte débité','account',accountSelect())}</div><div>${field('Devise','currency',currSelect())}</div></div>`+
 field('Montant de la dépense','amount',input('amount'));
 }else{
 h=field('Compte','account',accountSelect())+
 `<div class="row"><div>${field('Devise','currency',currSelect())}</div><div>${field('Sens','direction',select('direction','<option value="in">Entrée (+)</option><option value="out">Sortie (−)</option>'))}</div></div>`+
 field('Montant','amount',input('amount'))+
 `<p class="small">Utilise cette option pour corriger un solde. Les corrections ne sont pas comptées comme bénéfice.</p>`;
 }
 $('dynamicForm').innerHTML=h;
 if(k==='sale') renderQuickSales();
 if(k==='mm_withdraw') renderQuickWithdrawals();
 if(k==='fx_usd_fc') renderQuickExchange();
}
function quickButton(title,detail,fn){return `<button type="button" class="quickChoice" data-quick="${escapeHtml(title)}"><span class="radioMark">○</span><span><b>${title}</b><small>${detail}</small></span></button>`}
function quickPanel(title,buttons){$('quickOptions').innerHTML=`<div class="card quickPanel"><h3>${title}</h3><div class="quickGrid">${buttons}</div><div class="small">Appuie sur un cercle pour enregistrer immédiatement l'opération.</div></div>`}
function renderQuickSales(){
 const presets=[[15,352.5,174.5],[30,705,295],[50,1175,325],[100,2350,650]];
 quickPanel('VENTES RAPIDES',presets.map(([u,price,profit])=>quickButton(`${u} unités`,`${fmt(price,'FC')} · bénéfice ${fmt(profit,'FC')}`,()=>{})).join(''));
 document.querySelectorAll('#quickOptions [data-quick]').forEach((b,i)=>b.onclick=()=>{const [u,price,profit]=presets[i];quickRecord({kind:'sale',activity:'Vente '+u+' unités',amount:price,cost:price-profit,profitFC:profit,account:$('account').value,currency:'FC',note:'Vente rapide '+u+' unités'});});
}
function renderQuickWithdrawals(){
 const presets=Array.from({length:20},(_,i)=>(i+1)*100000);
 quickPanel('RETRAITS RAPIDES · COMMISSION 1 %',presets.map(v=>quickButton(fmt(v,'FC'),`bénéfice ${fmt(v*.01,'FC')}`,()=>{})).join(''));
 document.querySelectorAll('#quickOptions [data-quick]').forEach((b,i)=>b.onclick=()=>{const amount=presets[i];quickRecord({kind:'mm_withdraw',activity:'Mobile Money retrait',amount,profitFC:amount*.01,wallet:$('wallet').value,currency:'FC',note:'Retrait rapide '+fmt(amount,'FC')});});
}
function renderQuickExchange(){
 const presets=[10,20,30,40,50,100];
 quickPanel('CHANGE RAPIDE · BÉNÉFICE 70 FC / USD',presets.map(v=>quickButton(v+' $',`bénéfice ${fmt(v*70,'FC')}`,()=>{})).join(''));
 document.querySelectorAll('#quickOptions [data-quick]').forEach((b,i)=>b.onclick=()=>{const usd=presets[i],rate=USD_FC_RATE,profit=usd*70,fc=usd*rate-profit;quickRecord({kind:'fx_usd_fc',activity:'Change USD → FC',usd,fc,rate,account:$('account').value,profitFC:profit,note:'Change rapide '+usd+' USD'});});
}
function quickRecord(o){
 const date=new Date().toISOString();let moves=[],profit={FC:o.profitFC||0,USD:0};
 if(o.kind==='sale'){const a=o.account||'cash',c=o.currency||'FC';moves=[{account:a,currency:c,delta:o.amount}];if(o.cost>0)moves.push({account:a,currency:c,delta:-o.cost});profit.FC=Number(o.profitFC||0)*(c==='USD'?USD_FC_RATE:1);}
 else if(o.kind==='mm_withdraw'){const w=o.wallet||'airtel',c=o.currency||'FC';moves=[{account:w,currency:c,delta:o.amount},{account:'cash',currency:c,delta:-(o.amount-o.profitFC)}];}
 else if(o.kind==='fx_usd_fc'){const a=o.account||'cash';moves=[{account:a,currency:'USD',delta:o.usd},{account:a,currency:'FC',delta:-o.fc}];}
 db.tx.unshift({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),date,kind:o.kind,activity:o.activity,note:o.note||'',moves,profit});$('note').value='';save();
}
function get(id){return Number($(id)?.value||0)}
function addMove(moves,account,currency,delta){moves.push({account,currency,delta:Number(delta.toFixed(2))})}
function record(){
 const k=$('kind').value, date=new Date().toISOString(), note=$('note').value.trim();let moves=[],profit={FC:0,USD:0},activity=k;
 if(k==='sale'){
 const a=$('account').value,c=$('currency').value,amt=get('amount'),cost=get('cost'),paid=get('paidCost');
 if(amt<=0||cost<0||paid<0||paid>amt+0.0001)return alert('Vérifie les montants de la vente et le coût payé.');
 activity=$('activity').value;addMove(moves,a,c,amt-paid);if(paid)addMove(moves,a,c,-paid);profit.FC=(amt-cost)*(c==='USD'?USD_FC_RATE:1);
 // Le solde net est la recette moins le coût payé.
 moves=[{account:a,currency:c,delta:amt-paid}];
 }else if(k==='mm_deposit'||k==='mm_withdraw'){
 const w=$('wallet').value,c=$('currency').value,amt=get('amount'),com=get('commission');
 if(amt<=0||com<0||com>=amt&&k==='mm_withdraw')return alert('Montants Mobile Money invalides.');
 activity=k==='mm_deposit'?'Mobile Money dépôt':'Mobile Money retrait';
 if(k==='mm_deposit'){addMove(moves,'cash',c,amt+com);addMove(moves,w,c,-amt)}
 else{addMove(moves,w,c,amt);addMove(moves,'cash',c,-(amt-com))}
 profit.FC=com;
 }else if(k==='fx_usd_fc'||k==='fx_fc_usd'){
 const usd=get('usd'),fc=get('fc'),rate=get('rate'),a=$('account').value;
 if(usd<=0||fc<=0||rate<=0)return alert('Saisis les deux montants et un taux valide.');
 activity=k==='fx_usd_fc'?'Change USD → FC':'Change FC → USD';
 if(k==='fx_usd_fc'){addMove(moves,a,'USD',usd);addMove(moves,a,'FC',-fc);profit.FC=usd*rate-fc}
 else{addMove(moves,a,'FC',fc);addMove(moves,a,'USD',-usd);profit.FC=fc-usd*rate}
 }else if(k==='expense'){
 const a=$('account').value,c=$('currency').value,amt=get('amount');
 if(amt<=0)return alert('Saisis un montant valide.');
 activity='Dépense — '+$('activity').value;addMove(moves,a,c,-amt);profit.FC=-amt*(c==='USD'?USD_FC_RATE:1);
 }else{
 const a=$('account').value,c=$('currency').value,amt=get('amount');
 if(amt<=0)return alert('Saisis un montant valide.');
 activity='Correction de caisse';addMove(moves,a,c,$('direction').value==='in'?amt:-amt);
 }
 if(moves.some(m=>!Number.isFinite(m.delta)))return alert('Montant invalide.');
 db.tx.unshift({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),date,kind:k,activity,note,moves,profit});
 $('note').value='';save();alert('Opération enregistrée.');
}
function balance(account,currency){
 let n=Number(db.opening[account+'_'+currency]||0);
 db.tx.forEach(t=>t.moves.forEach(m=>{if(m.account===account&&m.currency===currency)n+=m.delta}));
 return n;
}
function total(currency){return ACCOUNTS.reduce((s,a)=>s+balance(a.id,currency),0)}
function profitFor(tx,c){if(c!=='FC')return 0;return Number(tx.profit?.FC||0)+Number(tx.profit?.USD||0)*USD_FC_RATE}
function inPeriod(tx,p){const d=tx.date.slice(0,10);return p==='day'?d===today():p==='month'?d.slice(0,7)===month():true}
function sumProfit(p){return db.tx.filter(t=>inPeriod(t,p)).reduce((s,t)=>s+profitFor(t,'FC'),0)}
function renderHome(){
 $('totalFC').textContent=fmt(total('FC'),'FC');$('totalUSD').textContent=fmt(total('USD'),'USD');
 $('profitToday').textContent=fmt(sumProfit('day'),'FC');
 $('headerProfitToday').textContent=fmt(sumProfit('day'),'FC');
 $('profitMonth').textContent=fmt(sumProfit('month'),'FC');
 $('homeBalances').innerHTML=ACCOUNTS.map(a=>`<div class="item"><div>${a.name}</div><div class="amt">${fmt(balance(a.id,'FC'),'FC')}<br>${fmt(balance(a.id,'USD'),'USD')}</div></div>`).join('');
 $('recent').innerHTML=db.tx.slice(0,5).map(txRow).join('')||'<div class="empty">Aucune opération pour le moment.</div>';
}
function txRow(t){
 const date=new Date(t.date).toLocaleString('fr-FR',{dateStyle:'short',timeStyle:'short'});
 const p=[];if(profitFor(t,'FC'))p.push(fmt(profitFor(t,'FC'),'FC'));
 return `<div class="item"><div><b>${t.activity}</b><div class="small">${date}${t.note?' · '+escapeHtml(t.note):''}</div></div><div class="amt ${p.length?'positive':''}">${p.length?p.join('<br>'):'—'}</div></div>`;
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function renderAccounts(){
 $('accountList').innerHTML=ACCOUNTS.map(a=>`<div class="card"><h3>${a.name}</h3><div class="row"><div><label>Solde de départ FC</label><input type="number" min="0" step="1" data-opening="${a.id}_FC" value="${db.opening[a.id+'_FC']??0}"></div><div><label>Solde de départ USD</label><input type="number" min="0" step=".01" data-opening="${a.id}_USD" value="${db.opening[a.id+'_USD']??0}"></div></div><div class="sub">Solde actuel : ${fmt(balance(a.id,'FC'),'FC')} · ${fmt(balance(a.id,'USD'),'USD')}</div></div>`).join('')+
 `<button class="primary" id="saveOpening">Enregistrer les soldes de départ</button>`;
 $('saveOpening').onclick=()=>{document.querySelectorAll('[data-opening]').forEach(el=>{const v=Number(el.value);if(v>=0)db.opening[el.dataset.opening]=v});save();alert('Soldes de départ enregistrés.')};
}
function renderReports(){
 const p=$('period').value;
 $('reportProfit').textContent=fmt(sumProfit(p),'FC');
 const map={};db.tx.filter(t=>inPeriod(t,p)).forEach(t=>{map[t.activity]??={FC:0};map[t.activity].FC+=profitFor(t,'FC')});
 $('byActivity').innerHTML=Object.keys(map).length?Object.entries(map).map(([k,v])=>`<div class="item"><div>${escapeHtml(k)}</div><div class="amt">${fmt(v.FC,'FC')}</div></div>`).join(''):'<div class="empty">Aucune donnée pour cette période.</div>';
 $('history').innerHTML=db.tx.filter(t=>inPeriod(t,p)).map(txRow).join('')||'<div class="empty">Aucune opération.</div>';
}
function renderAll(){renderHome();renderAccounts();renderReports()}
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===b));document.querySelectorAll('main section').forEach(s=>s.classList.toggle('active',s.id===b.dataset.tab));});
$('kind').onchange=renderForm;$('saveTx').onclick=record;$('clearForm').onclick=()=>{renderForm();$('note').value=''};
$('period').onchange=renderReports;
$('exportBtn').onclick=()=>{const blob=new Blob([JSON.stringify({app:'Mercury Business Manager',version:1,exportedAt:new Date().toISOString(),data:db},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='mercury-sauvegarde-'+today()+'.json';a.click();URL.revokeObjectURL(a.href)};
$('importBtn').onclick=()=>{const f=$('importFile').files[0];if(!f)return alert('Choisis un fichier de sauvegarde.');const r=new FileReader();r.onload=()=>{try{const x=JSON.parse(r.result);const d=x.data||x;if(!d.opening||!Array.isArray(d.tx))throw Error();if(!confirm('Restaurer ce fichier remplacera les données actuelles. Continuer ?'))return;db=d;save();alert('Sauvegarde restaurée.')}catch(e){alert('Fichier invalide.')}};r.readAsText(f)};
$('resetBtn').onclick=()=>{if(confirm('Effacer définitivement toutes les données locales ? Exporte une sauvegarde avant.')){db=blank();save();alert('Données effacées.')}};
$('undoLastBtn').onclick=()=>{
 if(!db.tx.length)return alert('Aucune transaction à annuler.');
 const last=db.tx[0];
 const when=new Date(last.date).toLocaleString('fr-FR',{dateStyle:'short',timeStyle:'short'});
 if(!confirm(`Annuler la dernière transaction ?\n${last.activity} — ${when}\nLes soldes et bénéfices seront recalculés.`))return;
 db.tx.shift();save();alert('Dernière transaction annulée. Les soldes et bénéfices ont été recalculés.');
};
// Calculatrice autonome, sans effet sur les comptes ni les opérations.
let calcValue='0',calcStored=null,calcOperator=null,calcNewNumber=false;
function calcRender(){$('calcDisplay').value=calcValue;}
function calcInput(key){
 if(key==='C'){calcValue='0';calcStored=null;calcOperator=null;calcNewNumber=false;return calcRender();}
 if(key==='back'){calcValue=calcValue.length>1?calcValue.slice(0,-1):'0';return calcRender();}
 if('0123456789.'.includes(key)||key==='00'){
  if(calcNewNumber){calcValue=key==='.'?'0.':key;calcNewNumber=false;}
  else if(key==='.'&&!calcValue.includes('.'))calcValue+='.';
  else if(key!=='.')calcValue=calcValue==='0'?key:calcValue+key;
  return calcRender();
 }
 if(['+','-','*','/'].includes(key)){
  if(calcOperator&&calcStored!==null&&!calcNewNumber)calcCompute();
  calcStored=Number(calcValue);calcOperator=key;calcNewNumber=true;return;
 }
 if(key==='='&&calcOperator&&calcStored!==null){calcCompute();calcOperator=null;calcStored=null;calcNewNumber=true;}
}
function calcCompute(){const b=Number(calcValue),a=calcStored;let result=calcOperator==='+'?a+b:calcOperator==='-'?a-b:calcOperator==='*'?a*b:calcOperator==='/'?(b===0?NaN:a/b):b;calcValue=Number.isFinite(result)?String(Number(result.toFixed(8))):'Erreur';calcRender();}
document.querySelectorAll('[data-calc]').forEach(b=>b.onclick=()=>calcInput(b.dataset.calc));
renderForm();renderAll();calcRender();
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
