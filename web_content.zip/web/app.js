// Study Companion — syllabus-led planner for SRM B.Tech Mechanical Engineering
// Syllabus topics below are transcribed from the five PDFs supplied by the student.
// Theory-only edition. Topics for courses without an uploaded syllabus are intentionally not invented.
const subjects = [
  {
    id:"math3", name:"Engineering Mathematics-III", code:"24AS301", type:"Theory", credits:4, hours:4,
    source:"Syllabus PDF supplied · 2 pages", status:"verified",
    units:[
      {name:"Unit I — Fourier Series", topics:["Periodic functions","Fourier series","Dirichlet’s conditions","Fourier series of discontinuous functions","Even and odd functions","Half-range series (period 0 to π)","Change of interval and arbitrary period","Half-period series","Parseval’s formula","Practical harmonic analysis"],application:"Signal and vibration analysis"},
      {name:"Unit II — Partial Differential Equations",topics:["Introduction to partial differential equations","Order of PDEs","Formation of PDEs","Solution by direct integration","Lagrange’s linear equation of first order","Linear PDEs with constant coefficients"],application:"Scientific computing and real-world modelling"},
      {name:"Unit III — Heat and Wave Equations",topics:["Classification of PDEs","Separation of variables","One-dimensional wave equation","One-dimensional heat equation"],application:"Modelling problems of mechanics"},
      {name:"Unit IV — Fourier Transforms",topics:["Introduction and linear property","Shifting property and change of scale","Modulation theorem","Fourier transform of derivatives and integrals","Fourier transform of Dirac-delta function","Fourier cosine and sine transforms","Transforms of derivatives","Finite Fourier cosine and sine transforms","Convolution theorem","Parseval’s identity (without proof)"],application:"Signal processing in time and frequency domains"},
      {name:"Unit V — Z-Transforms",topics:["Introduction and definition","Linear property and frequency shifting","First and second shifting","Differentiation in z-domain","Initial and final value theorems","Convolution theorem","Z-transforms of basic functions","Inverse Z-transform by partial fractions and long division","Difference equations"],application:"Frequency response of discrete systems"}
    ],
    start:"Prerequisite listed in syllabus: Engineering Mathematics-II. Revise the relevant calculus and algebra you already learned, then follow Units I–V in order."
  },
  {
    id:"mt",name:"Manufacturing Technology",code:"23ME302",type:"Theory",credits:3,hours:2.5,
    source:"MT.pdf supplied · 2 pages",status:"verified",
    units:[
      {name:"Unit I — Casting",topics:["Foundry process and its importance","Sand casting","Patterns and pattern allowances","Riser and gating system design","Centrifugal casting","Hot-chamber and cold-chamber die casting","Investment casting","Shell moulding","Theory of solidification"]},
      {name:"Unit II — Theory of Metal Cutting",topics:["Single-point cutting tool geometry","Orthogonal cutting","Shear-angle relationships","Tool forces in orthogonal cutting","Tool-life equation","Machinability and types of chips","Tool failure and tool life","Cutting-tool materials"]},
      {name:"Unit III — Machine Tools",topics:["Lathe: construction, operations and specifications","Shaper: construction, operations and specifications","Milling machine: construction, operations and specifications","Drilling machine: construction, operations and specifications","Grinding and types of grinding processes"]},
      {name:"Unit IV — Metal Forming",topics:["Recovery, recrystallization and grain growth","Hot and cold working","Rolling: classification, mills, products and variables","Open- and closed-die forging","Forging operations","Extrusion: classification and hot/cold processes","Sheet-metal operations: blanking, piercing, deep drawing and bending"]},
      {name:"Unit V — Welding Principle",topics:["Oxy-acetylene gas welding: principle, working and applications","Electric arc welding: MMAW/SMAW, SAW, GTAW and GMAW","Resistance welding","Soldering and brazing","Heat flow during welding","Friction-stir welding","Thermit welding","Welding defects"]}
    ],
    start:"Prerequisite listed: NIL. Start with Unit I and build a process-comparison notebook. For every process, record principle, setup, working, applications, advantages and limitations."
  },
  {
    id:"mechanics",name:"Engineering Mechanics",code:"25ME304",type:"Theory",credits:3,hours:2.5,
    source:"Mechanics syllabus PDF supplied · 2 pages",status:"verified",
    units:[
      {name:"Unit I — Force Systems",topics:["Basic concepts and assumptions","Scalar and vector quantities; free, forced and fixed vectors","Force classification and representation","Composition and resolution of forces","Parallelogram law and transmissibility","Moment of a force and Varignon’s theorem","Couples and force-couple systems","Coplanar concurrent and non-concurrent systems","Resultants and equilibrium","Free-body diagrams and reactions","Three-force equilibrium and Lami’s theorem"]},
      {name:"Unit II — Friction and Structural Analysis",topics:["Wet and dry friction","Theory of dry friction","Angle of friction and angle of repose","Cone of friction","Coulomb’s laws of friction","Plane trusses and frames","Perfect and imperfect trusses","Assumptions for plane-truss analysis","Method of joints and method of sections","Zero-force members"]},
      {name:"Unit III — Centroid and Moment of Inertia",topics:["Centre of gravity, centre of mass and centroid","Centroids of curves, areas and volumes","Centroid by integration and composite bodies","Area moment of inertia","Perpendicular-axis and polar moment theorems","Parallel-axis theorem","Moment of inertia of simple and composite areas","Mass moment of inertia by integration","Mass moment of inertia of composite bodies"]},
      {name:"Unit IV — Kinematics of Rigid Body",topics:["Introduction and absolute motion","Plane rectilinear motion","Plane curvilinear motion","x-y and n-t components","Rotation of rigid bodies","Relative motion","Plane motion of rigid bodies","Instantaneous centre of zero velocity"]},
      {name:"Unit V — Kinetics of Rigid Body",topics:["Force, mass and acceleration","Newton’s laws of motion","D’Alembert’s principle and dynamic equilibrium","Planar translation, rotation and plane motion","Work and energy","Kinetic energy and work-energy principle","Conservative forces and conservation of energy","Linear impulse and momentum","Conservation of linear momentum"]}
    ],
    start:"Prerequisite listed: NIL. Begin with vectors and force representation in Unit I. Do not skip free-body diagrams; use them before solving equilibrium problems."
  },
  {
    id:"som",name:"Strength of Materials",code:"23ME301",type:"Theory",credits:3,hours:3,
    source:"SOM Syllabus PDF supplied · 3 pages",status:"verified",
    units:[
      {name:"Unit I — Concepts of Stresses and Strains",topics:["Stress and strain","Hooke’s law in tension, compression and shear","Stress–strain diagram","Poisson’s ratio","Elastic constants and their relationships","Deformation of simple and compound bars","Mohr’s circle for plane stresses"]},
      {name:"Unit II — Analysis of Beams",topics:["Types of beams and transverse loadings","Shear-force and bending-moment diagrams for cantilevers","Simply supported and overhanging beams","Theory of pure bending","Bending stresses in simple and composite beams","Shear-stress distribution in different beam sections"]},
      {name:"Unit III — Torsion of Shafts and Springs",topics:["Theory of pure torsion","Torsion of circular shafts","Strain energy due to torsion","Types and stiffness of springs","Springs in series and parallel","Stresses and deflections in helical and leaf springs","Design of helical and leaf springs"]},
      {name:"Unit IV — Deflection of Beams",topics:["Slope and deflection of cantilever beams","Simply supported and fixed beams","Double-integration method","Macaulay’s method","Moment-area method","Strain-energy method","Castigliano’s theorem"]},
      {name:"Unit V — Columns and Struts; Cylinders and Shells",topics:["Combined bending and axial loads","Euler’s theory and crippling load","Rankine’s theory","Thin cylinders and thin spherical shells under internal pressure","Thick cylinders","Lame’s equation"]}
    ],
    start:"Prerequisite listed: Engineering Mechanics. Revise force equilibrium, bending moments and area moment of inertia before starting Unit I."
  },
  {
    id:"materials",name:"Material Science and Smart Materials",code:"23ME404*",type:"Theory",credits:3,hours:2.5,
    source:"Material science.pdf supplied · Material Science section, 2 pages",status:"partial",
    units:[
      {name:"Unit I — Introduction",topics:["Structure of crystalline solids","Interatomic bonding","Crystal systems and unit cells","Metallic crystal structures","Miller indices","Crystallographic planes and directions","Linear and planar atomic densities","Point, linear and interfacial defects"]},
      {name:"Unit II — Mechanical Properties",topics:["Elastic, inelastic and plastic behaviour","Stress–strain curves for ductile and brittle alloys","Ductility, resilience and toughness","Hardness testing","Dislocations and plastic deformation","Slip phenomenon and slip in single crystals"]},
      {name:"Unit III — Strengthening Mechanisms",topics:["Grain-boundary, solution and work hardening","Ductile and brittle fracture","Fracture mechanics and impact testing","Ductile–brittle transition","Fatigue and creep","Constitution of alloys and intermetallic compounds","Phase rule and lever principle","Isomorphous, eutectic, peritectic and eutectoid reactions","Iron–carbon phase diagram","Equilibrium and non-equilibrium cooling","Isothermal transformation, martensite and bainite"]},
      {name:"Unit IV — Heat Treatment",topics:["Annealing, normalizing, hardening and tempering","Heat treatment of tool and die steels","Hardenability and its testing","Material-selection problems","Carburizing, nitriding, carbonitriding and induction hardening"]},
      {name:"Unit V — Alloying",topics:["Classification, properties, microstructures and uses of cast irons","Plain-carbon, alloy, stainless, heat-resistant, tool and die steels","Brass and bronze","Aluminium, magnesium, nickel and zinc alloys"]}
    ],
    start:"The supplied PDF contains a Material Science syllabus. Your timetable says “Material Science and Smart Materials”; the uploaded document does not show a separate Smart Materials unit. Ask your faculty whether a separate/additional syllabus applies.",
    note:"*Course code 23ME404 is printed on the supplied Material Science PDF. Confirm that this code and document match your current timetable."
  },
  {id:"thermo",name:"Engineering Thermodynamics",type:"Theory",hours:2.5,status:"missing",source:"No syllabus PDF supplied",units:[],start:"Syllabus not uploaded. Do not use a guessed topic list. Add the official course syllabus to generate a unit-by-unit roadmap."},
  {id:"communication",name:"Effective Communication Skills",type:"Theory",hours:1,status:"verified",source:"Teacher's group message supplied",note:"Teacher's instructions: presentation topic date 21 September 2026. External exam: 24 November 2026, 1:30 PM–4:00 PM. External faculty: Mr. Aakash Dahiya. Soft Skill Trainer: Aashna. These details are transcribed from the group message; confirm any later updates with your teacher.",units:[
      {name:"Topic 1 — Self Introduction",topics:["Basic biographical details: name, place, age and languages known","Educational qualifications: from what you are currently pursuing","Work experience: internship or job","Awards and certifications","Skills: soft skills and hard skills","Hobbies: professional practices you follow","Goals and aspirations: where you see yourself in the next five years"]},
      {name:"Topic 2 — Listening Skills",topics:["Role of listening skills in effective communication","Barriers to listening skills","Overcoming listening barriers","Empathetic listening and avoiding selective listening"]}
    ],start:"Prepare a clear self-introduction using the seven headings from your trainer. For Listening Skills, learn each of the four teacher-listed points and prepare simple examples. This checklist follows the trainer's group message; no additional topics have been added."},

];
const studyResources = [
 {subject:"Engineering Mathematics-III",coach:"Dr. Gajendra Purohit",role:"Suggested instructor · Hindi",why:"Detailed engineering-mathematics lessons for Fourier series, PDEs, Fourier transforms and Z-transforms. Start from the exact unit topic, then solve the examples yourself.",backup:"B.S. Grewal — Higher Engineering Mathematics, for additional solved problems."},
 {subject:"Engineering Mechanics",coach:"Mr. Deepak B.S.",role:"Suggested lecture instructor",why:"A Mechanical Engineering department lists his Engineering Mechanics video lectures. Use the lessons for force systems, equilibrium, friction, centroid, kinematics and kinetics.",backup:"R.C. Hibbeler — Engineering Mechanics: Statics and Dynamics, for practice."},
 {subject:"Strength of Materials",coach:"Mr. Hanumant Borate",role:"Suggested instructor",why:"Use the suggested instructor reference alongside your prescribed textbook. Use it for stress and strain, torsion, shear force, bending moment, deflection and columns.",backup:"Use the prescribed Strength of Materials textbook for derivations and numericals."},
 {subject:"Manufacturing Technology",coach:"Dr. Sachin Bhosle",role:"Manufacturing Processes YouTube teacher",why:"Use the suggested instructor reference alongside your prescribed textbook. Use the topic playlists for casting, metal cutting, machine tools, metal forming and welding.",backup:"Use P.N. Rao — Manufacturing Technology, for process diagrams and detailed theory."},
 {subject:"Material Science and Smart Materials",coach:"Dr. Shashank Shekhar · IIT Kanpur",role:"Materials Science professor · suggested reference",why:"Use the supplied course material for crystalline defects, mechanical behaviour and materials processing. The supplied SRM PDF covers Material Science; it does not show a separate Smart Materials unit.",backup:"Callister — Materials Science and Engineering, for diagrams and deeper explanations."},
 {subject:"Engineering Thermodynamics",coach:"Dr. Avinash Kolekar",role:"Suggested instructor",why:"Use the suggested instructor reference for Thermodynamics and Applied Thermodynamics. Match each lesson to your official SRM unit outline before studying.",backup:"Your exact Engineering Thermodynamics syllabus PDF has not been supplied, so its topic list remains unfilled."},
 {subject:"Effective Communication Skills",coach:"Aashna — Soft Skill Trainer",role:"Your course trainer",why:"Your trainer has assigned Self Introduction and Listening Skills. Use the trainer's exact topic list as the syllabus. Study from class notes and prescribed material.",backup:"Prepare from Aashna's group message and class notes. Ask your trainer if additional units are included."}
];
const STORAGE_KEY="studyCompanionSyllabusV2";
const $=id=>document.getElementById(id);
let saved={};try{saved=JSON.parse(localStorage.getItem(STORAGE_KEY)||"{}")}catch{}
let data={name:saved.name||"",age:saved.age||"",sessions:Array.isArray(saved.sessions)?saved.sessions.filter(x=>subjects.some(s=>s.id===x.subjectId)):[],done:saved.done&&typeof saved.done==="object"?saved.done:{},subjectHours:saved.subjectHours&&typeof saved.subjectHours==="object"?saved.subjectHours:{},dailyResetAt:Number(saved.dailyResetAt)||new Date().setHours(0,0,0,0)};
let elapsed=0,tick=null,lastAns=0;
const CALC_HISTORY_KEY="pjsa.calculator.history.v1", CALC_ANS_KEY="pjsa.calculator.ans.v1";
try{lastAns=Number(localStorage.getItem(CALC_ANS_KEY)||0);if(!Number.isFinite(lastAns))lastAns=0}catch{lastAns=0}
function readCalcHistory(){try{const v=JSON.parse(localStorage.getItem(CALC_HISTORY_KEY)||"[]");return Array.isArray(v)?v:[]}catch{return []}}
function saveCalc(expression,result){const history=readCalcHistory();history.unshift({expression,result:String(result),time:new Date().toISOString()});try{localStorage.setItem(CALC_HISTORY_KEY,JSON.stringify(history));localStorage.setItem(CALC_ANS_KEY,String(result))}catch{alert("Device storage is full. Your newest calculation could not be saved. Please export or clear old app data.")}renderCalcHistory()}
function renderCalcHistory(){const host=$("calcHistory");if(!host)return;const history=readCalcHistory();if(!history.length){host.innerHTML="<p class=\"empty-state\">No calculations saved yet.</p>";return}host.innerHTML=history.map((item,index)=>`<div class=\"calc-history-item\"><button type=\"button\" class=\"calc-history-expression\" data-recall-calc=\"${index}\">${esc(item.expression)}</button><strong>${esc(item.result)}</strong><small>${new Date(item.time).toLocaleString()}</small></div>`).join("")}
function commitCalculation(field){const expression=field.value.trim();try{const result=calculate(expression);lastAns=result;const shown=String(Number(result.toPrecision(12)));field.value=shown;saveCalc(expression,shown)}catch{field.value="Error"}}
const titles={home:"Overview",analysis:"Syllabus analysis",timer:"Focus timer",coaches:"Where to study",calculator:"Scientific calculator",books:"Your Books PDF",profile:"My profile"};
const totalSeconds=a=>a.reduce((n,s)=>n+(Number(s.seconds)||0),0);
const hoursFor=s=>{const v=Number(data.subjectHours[s.id]);return Number.isFinite(v)&&v>=0?Math.min(40,v):s.hours};
const weeklyTarget=()=>subjects.reduce((n,s)=>n+hoursFor(s),0);
const dailySeconds=()=>{const midnight=new Date();midnight.setHours(0,0,0,0);const since=Math.max(midnight.getTime(),Number(data.dailyResetAt)||0);return totalSeconds(data.sessions.filter(s=>new Date(s.date).getTime()>=since))};
const fmt=n=>{n=Math.max(0,Math.floor(n));return `${Math.floor(n/3600)}h ${Math.floor(n%3600/60)}m`};
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function persist(){localStorage.setItem(STORAGE_KEY,JSON.stringify(data));render()}
function mondayStart(){const d=new Date();d.setHours(0,0,0,0);d.setDate(d.getDate()-((d.getDay()+6)%7));return d}
function subjectTime(s){return totalSeconds(data.sessions.filter(x=>x.subjectId===s.id))}
function doneCount(s){return s.units.reduce((n,u,i)=>n+(u.topics||[]).filter((t,j)=>data.done[`${s.id}:${i}:${j}`]).length,0)}
function totalTopics(s){return s.units.reduce((n,u)=>n+u.topics.length,0)}
function render(){
 const total=totalSeconds(data.sessions),week=totalSeconds(data.sessions.filter(s=>new Date(s.date)>=mondayStart()));
 $("hello").innerHTML=`Hello${data.name?`, ${esc(data.name)}`:", Student"} <span>✦</span>`;
 $("homeTotal").textContent=fmt(total);$("weekTotal").textContent=fmt(week);$("sessionCountHome").textContent=data.sessions.length;
 $("profileTotal").textContent=fmt(total);$("sessionCount").textContent=data.sessions.length;
 $("name").value=data.name;$("age").value=data.age;
 $("avatar").textContent=(data.name||"S").trim().charAt(0).toUpperCase();$("profileAvatar").textContent=(data.name||"S").trim().charAt(0).toUpperCase();
 $("today").textContent=new Date().toLocaleDateString("en-IN",{weekday:"short",day:"numeric",month:"short"});
 const weekTarget=weeklyTarget();
 $("targetTotal").textContent=weekTarget.toFixed(1)+"h weekly plan";$("homeWeeklyTarget").textContent=weekTarget.toFixed(1)+" hours";$("analysisTarget").textContent=weekTarget.toFixed(1)+"h";$("theoryTarget").textContent=weekTarget.toFixed(1)+" hours";
 $("todayPlan").innerHTML=subjects.filter(s=>s.type==="Theory").sort((a,b)=>b.hours-a.hours).slice(0,3).map(s=>`<article class="plan-item"><div class="plan-dot"></div><div><strong>${esc(s.name)}</strong><p>${hoursFor(s)}h/week · ${esc(s.start.split(".")[0])}.</p></div></article>`).join("");
 $("subjectQuick").innerHTML=subjects.map(s=>`<div class="quick-row"><span class="course-mark mark-lilac">T</span><span class="quick-name">${esc(s.name)}<small>Theory · ${s.status==="verified"?"Syllabus added":s.status==="partial"?"Partially matched":"Syllabus needed"}</small></span><b>${hoursFor(s)}h</b></div>`).join("");
 const percent=weekTarget>0?Math.min(100,Math.round(week/(weekTarget*3600)*100)):0;$("analysisDone").textContent=fmt(week);$("percent").textContent=percent+"%";$("weeklyBar").style.width=percent+"%";
 const daily=dailySeconds(),dailyPct=Math.min(100,Math.round(daily/(3*3600)*100));$("dailyTime").textContent=fmt(daily);$("dailyPercent").textContent=dailyPct+"% of 3h";$("dailyBar").style.width=dailyPct+"%";$("dailyResetNote").textContent="Counter started "+new Date(data.dailyResetAt).toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"})+" · resets at midnight";
 const card=s=>{const target=hoursFor(s),got=subjectTime(s),pct=target>0?Math.min(100,got/(target*3600)*100):0;const status=s.status==="verified"?"Syllabus verified":s.status==="partial"?"Check syllabus match":"Syllabus needed";return `<article class="analysis-card"><div class="analysis-card-head"><div><span class="course-type type-theory">${s.type}</span><h4>${esc(s.name)}</h4><small class="course-meta">${esc(s.code||"Course code not in supplied PDF")} · ${esc(s.source)}</small></div><div class="target-editor"><label>Weekly target</label><div><input type="number" min="0" max="40" step="0.5" value="${target}" data-hours="${s.id}" aria-label="Weekly study hours for ${esc(s.name)}"><b>h</b></div></div></div><div class="progress-track"><span style="width:${pct}%"></span></div><div class="analysis-card-foot"><span>${fmt(got)} studied</span><span>${Math.max(0,target-got/3600).toFixed(1)}h left</span></div><div class="status-line ${s.status}">${status}</div></article>`};
 $("theoryList").innerHTML=subjects.map(card).join("");
 $("coachCards").innerHTML=studyResources.map(r=>`<article class="coach-card"><div class="coach-card-top"><span class="course-type type-theory">Theory</span><span class="coach-badge">Recommended resource</span></div><h3>${esc(r.subject)}</h3><strong class="coach-name">${esc(r.coach)}</strong><small class="coach-role">${esc(r.role)}</small><p>${esc(r.why)}</p><div class="coach-backup"><b>Also use:</b> ${esc(r.backup)}</div></article>`).join("");
 $("roadmaps").innerHTML=subjects.map(s=>`<article class="roadmap-card"><div class="roadmap-card-head"><span class="course-type type-theory">${s.type}</span><span class="roadmap-hours">${hoursFor(s)}h / week</span></div><h4>${esc(s.name)}</h4><p class="roadmap-source">${esc(s.source)}</p><p>${esc(s.start)}</p>${s.note?`<p class="source-warning">${esc(s.note)}</p>`:""}${s.units.length?`<div class="unit-list">${s.units.map((u,i)=>`<details class="unit-detail"><summary><span>${esc(u.name)}</span><small>${u.topics.filter((t,j)=>data.done[`${s.id}:${i}:${j}`]).length}/${u.topics.length} done</small></summary><div class="topic-list">${u.topics.map((t,j)=>{const k=`${s.id}:${i}:${j}`;return `<label class="topic-check"><input type="checkbox" data-topic="${k}" ${data.done[k]?"checked":""}><span>${esc(t)}</span></label>`}).join("")}</div>${u.application?`<p class="application-note"><b>Application in syllabus:</b> ${esc(u.application)}</p>`:""}</details>`).join("")}</div>`:`<div class="missing-box">Unit-wise checklist unavailable until the official syllabus/manual is added.</div>`}</article>`).join("");
 $("history").innerHTML=data.sessions.length?data.sessions.slice().reverse().slice(0,30).map(s=>`<div class="history-item"><div><strong>${esc(s.subject)}</strong><small>${new Date(s.date).toLocaleString()}</small></div><b>${fmt(s.seconds)}</b></div>`).join(""):'<div class="empty-state"><span>◷</span><strong>No sessions yet</strong><p>Your saved study sessions will appear here.</p></div>';
 const done=subjects.reduce((n,s)=>n+doneCount(s),0),all=subjects.reduce((n,s)=>n+totalTopics(s),0);
 $("topicProgress").textContent=`${done} / ${all} syllabus topics checked`;
}
function navigate(page){document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===page));document.querySelectorAll("[data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===page));$("pageHeading").textContent=titles[page]||"Study Companion";window.scrollTo({top:0,behavior:"smooth"})}
$("nav").addEventListener("click",e=>{const b=e.target.closest("[data-page]");if(b)navigate(b.dataset.page)});
$("avatar").addEventListener("click",()=>navigate("profile"));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.go)));
$("roadmaps").addEventListener("change",e=>{const input=e.target.closest("[data-topic]");if(!input)return;data.done[input.dataset.topic]=input.checked;persist()});
["theoryList"].forEach(id=>$(id).addEventListener("change",e=>{const input=e.target.closest("[data-hours]");if(!input)return;const value=Number(input.value);if(!Number.isFinite(value)||value<0||value>40){input.value=hoursFor(subjects.find(s=>s.id===input.dataset.hours));return}data.subjectHours[input.dataset.hours]=Math.round(value*2)/2;persist()}));
$("timerSubject").innerHTML=subjects.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join("");
function clock(){const h=Math.floor(elapsed/3600),m=Math.floor(elapsed%3600/60),s=elapsed%60;$("clock").textContent=[h,m,s].map(v=>String(v).padStart(2,"0")).join(":")}
function setTimerState(state){$("timerIndicator").textContent=state;$("timerStatus").textContent=state==="FOCUSING"?"You're doing great. Keep going.":state==="PAUSED"?"Paused. Resume whenever you're ready.":"Ready when you are"}
$("startBtn").onclick=()=>{if(tick)return;tick=setInterval(()=>{elapsed++;clock()},1000);setTimerState("FOCUSING")};
$("pauseBtn").onclick=()=>{if(tick){clearInterval(tick);tick=null;setTimerState("PAUSED")}};
$("resetBtn").onclick=()=>{if(tick)clearInterval(tick);tick=null;elapsed=0;clock();setTimerState("READY")};
$("saveBtn").onclick=()=>{if(tick)clearInterval(tick);tick=null;if(elapsed<1){setTimerState("READY");return}const subject=subjects.find(s=>s.id===$("timerSubject").value);data.sessions.push({subjectId:subject.id,subject:subject.name,seconds:elapsed,date:new Date().toISOString()});elapsed=0;clock();setTimerState("READY");persist()};
$("saveProfile").onclick=()=>{data.name=$("name").value.trim();data.age=$("age").value;persist()};
$("resetDaily").onclick=()=>{if(confirm("Reset today's study counter? Your saved sessions and total study history will remain unchanged.")){data.dailyResetAt=Date.now();persist()}};
function factorial(n){if(!Number.isInteger(n)||n<0||n>170)throw Error("Factorial accepts integers from 0 to 170");let r=1;for(let i=2;i<=n;i++)r*=i;return r}
function calculate(input){
 const tokens=String(input).match(/(?:\d+(?:\.\d*)?|\.\d+)|(?:[A-Za-z]+)|[()+\-*/^%!]/g)||[];
 const compact=String(input).replace(/\s/g,"");
 if(tokens.join("")!==compact||!tokens.length)throw Error("Invalid expression");
 let i=0;const peek=()=>tokens[i],take=()=>tokens[i++];
 const primary=()=>{
   let t=take(),v;
   if(t==="("){v=expr(0);if(take()!==")")throw Error("Missing )")}
   else if(t==="+"||t==="-"){v=primary();if(t==="-")v=-v}
   else if(/^(?:\d|\.)/.test(t)){v=Number(t);if(!Number.isFinite(v))throw Error("Invalid number")}
   else if(t==="pi")v=Math.PI;else if(t==="e")v=Math.E;
   else if(["sin","cos","tan","asin","acos","atan","sqrt","log","ln"].includes(t)){
     if(take()!=="(")throw Error("Function needs (");
     const x=expr(0);if(take()!==")")throw Error("Missing )");
     const f={sin:x=>Math.sin(x*Math.PI/180),cos:x=>Math.cos(x*Math.PI/180),tan:x=>Math.tan(x*Math.PI/180),asin:x=>Math.asin(x)*180/Math.PI,acos:x=>Math.acos(x)*180/Math.PI,atan:x=>Math.atan(x)*180/Math.PI,sqrt:Math.sqrt,log:Math.log10,ln:Math.log}[t];v=f(x);
   } else throw Error("Unknown value");
   while(peek()==="!"||peek()==="%"){const op=take();v=op==="!"?factorial(v):v/100}
   return v;
 };
 const expr=min=>{
   let left=primary();
   while(i<tokens.length){
     const op=peek(),prec={"+":1,"-":1,"*":2,"/":2,"^":3}[op];if(prec===undefined||prec<min)break;take();
     const right=expr(prec+(op==="^"?0:1));
     if(op==="+")left+=right;else if(op==="-")left-=right;else if(op==="*")left*=right;else if(op==="/")left/=right;else left=Math.pow(left,right);
   }
   return left;
 };
 const result=expr(0);if(i!==tokens.length||!Number.isFinite(result))throw Error("Math error");return result;
}
$("keys").addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;const d=$("display");if(b.dataset.action==="clear"){d.value="0";return}if(b.dataset.action==="back"){d.value=d.value.slice(0,-1)||"0";return}if(b.dataset.action==="equals"){commitCalculation(d);return}let v=b.dataset.v;if(v==="Ans")v=String(lastAns);if(d.value==="0"&&/^[0-9.]$/.test(v))d.value=v;else d.value+=v});
$("display").addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();commitCalculation(e.target)}});
$("calcHistory").addEventListener("click",e=>{const b=e.target.closest("[data-recall-calc]");if(!b)return;const item=readCalcHistory()[Number(b.dataset.recallCalc)];if(item){$("display").value=item.expression;$("display").focus()}});
$("clearCalcHistory").addEventListener("click",()=>{if(confirm("Delete all saved calculator calculations from this device?")){localStorage.removeItem(CALC_HISTORY_KEY);renderCalcHistory()}});
render();renderCalcHistory();clock();

$("accountIdentity").textContent="Signed in as "+(window.PJSAAuth?.username()||"local user");
if(window.PJSAAuth?.age() && !$("age").value) { $("age").value=window.PJSAAuth.age(); data.age=String(window.PJSAAuth.age()); persist(); }
$("logoutBtn").onclick=()=>window.PJSAAuth.logout();
function pjsaConfirmDOB(title,detail){
 return new Promise(resolve=>{
  const overlay=document.createElement("div");overlay.className="pjsa-action-overlay";
  overlay.innerHTML=`<div class="pjsa-action-dialog" role="dialog" aria-modal="true"><h3>${title}</h3><p>${detail}</p><label for="pjsaDobConfirm">Date of birth</label><input id="pjsaDobConfirm" type="date" autocomplete="bday"><p class="pjsa-dialog-error" aria-live="polite"></p><div class="pjsa-dialog-actions"><button type="button" class="button button-quiet" data-cancel>Cancel</button><button type="button" class="button button-danger" data-confirm>Continue</button></div></div>`;
  document.body.appendChild(overlay);const input=overlay.querySelector("input"),err=overlay.querySelector(".pjsa-dialog-error");
  const finish=v=>{overlay.remove();resolve(v)};
  overlay.querySelector("[data-cancel]").onclick=()=>finish(false);
  overlay.querySelector("[data-confirm]").onclick=()=>{if(!window.PJSAAuth.verifyDob(input.value)){err.textContent="Date of birth does not match this account.";return}finish(true)};
  overlay.addEventListener("click",e=>{if(e.target===overlay)finish(false)});input.focus();
 });
}
$("deleteStudyDataBtn").onclick=async()=>{
 if(!await pjsaConfirmDOB("Delete study data","This removes study sessions, profile details and topic checkmarks. Your local account and saved PDF books will remain."))return;
 
 ["studyCompanionSyllabusV2","pjsaCalcHistory","pjsa.study.sessions","pjsa.study.profile"].forEach(k=>localStorage.removeItem(k));
 location.reload();
};
$("deleteAccountBtn").onclick=async()=>{
 if(!await pjsaConfirmDOB("Delete account permanently","This removes the local account, its backup key, study data and saved PDF books from this device."))return;
 
 window.PJSAAuth.deleteAccount();
};
