const API='http://localhost:3000';
const messages=document.querySelector('#messages');
const form=document.querySelector('#form');
const input=document.querySelector('#input');
const drawer=document.querySelector('#drawer');
const dim=document.querySelector('#dim');
const modal=document.querySelector('#modal');
let voiceActive=false;
function add(t,u=false){const e=document.createElement('div');e.className='message '+(u?'user':'assistant');e.innerHTML=u?escapeHtml(t):escapeHtml(t).replace(/\n/g,'<br>');messages.appendChild(e);messages.scrollTop=messages.scrollHeight}
function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
async function sendCommand(c){if(!c)return;add(c,true);try{const r=await fetch(API+'/api/command',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({command:c})});const d=await r.json();add(d.message||'Command received.')}catch(e){add('Smart received your command. The web preview is not connected to the native Android phone-control service. Install the native Android build and grant the requested permissions to perform phone actions.')}}
function sendQuick(c){sendCommand(c)}
function newChat(){messages.innerHTML='';add('New chat started. What would you like Smart to do?')}
function focusChat(){input.focus()}
function openMenu(){drawer.classList.add('open');dim.classList.add('open')}
function closeMenu(){drawer.classList.remove('open');dim.classList.remove('open')}
function showInfo(title,text){document.querySelector('#modalTitle').textContent=title;document.querySelector('#modalText').textContent=text;modal.classList.add('open')}
function closeInfo(){modal.classList.remove('open')}
function toggleVoice(){voiceActive=!voiceActive;const b=document.querySelector('#voiceBtn');const s=document.querySelector('#voiceStatus');if(voiceActive){b.textContent='⏹ STOP SMART VOICE';b.classList.add('active');s.textContent='ACTIVE — voice service selected';showInfo('Smart Voice','This preview can show the voice control interface, but a browser page cannot control Android phone apps. Use the native Smart Android app for microphone, Accessibility and phone actions.');}else{b.textContent='🎤 ACTIVATE SMART VOICE';b.classList.remove('active');s.textContent='OFF — voice control is not active'}}
form.addEventListener('submit',e=>{e.preventDefault();const c=input.value.trim();if(c){input.value='';sendCommand(c)}});
add('Hello. I am Smart. Your assistant workspace is ready.');
