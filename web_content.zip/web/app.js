
const initialCustomers = []; // Clean distribution build: no customer records are embedded in the shared HTML file.
let customers = JSON.parse(localStorage.getItem("cg_customers") || "null") || initialCustomers;
customers=customers.map(c=>{let start=c.start||"";if(!start&&c.end){let d=new Date(c.end+"T00:00:00");d.setDate(d.getDate()-364);start=d.toISOString().slice(0,10);}let visits=Number(c.visits)||0;let st=visits===24?{visits:24,freq:"15 Days"}:visits===12?{visits:12,freq:"Monthly"}:{visits:visits,freq:(c.frequency||"Manual")};return {...c,start,end:endDate(start)||c.end||"",visits,frequency:c.frequency||st.freq,firstVisit:c.firstVisit||start,billingCycle:c.billingCycle||((c.paymentMethod&&["service","monthly","quarterly","semiannual"].includes(String(c.paymentMethod)))?c.paymentMethod:"monthly"),paymentMethod:(c.paymentMethod&&!["service","monthly","quarterly","semiannual"].includes(String(c.paymentMethod)))?c.paymentMethod:"Cash"}});
localStorage.setItem("cg_customers",JSON.stringify(customers));
let jobs = JSON.parse(localStorage.getItem("cg_daily_jobs") || "[]");
let visitPlans = JSON.parse(localStorage.getItem("cg_visit_plans") || "{}");
let deletedAutoInvoiceKeys = JSON.parse(localStorage.getItem("cg_deleted_auto_invoice_keys") || "[]");
if(!Array.isArray(deletedAutoInvoiceKeys)) deletedAutoInvoiceKeys=[];
let dismissedNotificationKeys = JSON.parse(localStorage.getItem("cg_dismissed_notifications") || "[]");
if(!Array.isArray(dismissedNotificationKeys)) dismissedNotificationKeys=[];
// Migrate legacy customer Last Treatment into the visit record once, then stop using the customer field.
customers.forEach(c=>{if(c.lastTreatment&&!Object.keys(visitPlans).some(k=>k.startsWith(c.id+"_")&&visitPlans[k]?.actualTreatment)){let count=Number(c.visits)||0,anchor=c.firstVisit||c.start,frequency=count===24?"15 Days":count===12?"Monthly":(c.frequency||"Manual"),base=[];for(let i=0;i<count;i++)base.push(frequency==="15 Days"?addDaysISO(anchor,i*15):addMonths(anchor,i));let n=base.reduce((acc,d,i)=>d<=c.lastTreatment?i+1:acc,0);if(n)visitPlans[c.id+"_"+n]={...(visitPlans[c.id+"_"+n]||{}),actualTreatment:c.lastTreatment,status:"Completed",plannedDate:base[n-1],originalDate:base[n-1]};}delete c.lastTreatment;});


function localTodayISO(){const d=new Date();return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");}
let todayISO = localTodayISO();
function refreshTodayISO(){ todayISO=localTodayISO(); return todayISO; }
if(document.getElementById("dailyDate")) document.getElementById("dailyDate").value=localTodayISO();
if(document.getElementById("jobDate")) document.getElementById("jobDate").value=localTodayISO();
if(document.getElementById("fromDate")) document.getElementById("fromDate").value=localTodayISO();
if(document.getElementById("toDate")) document.getElementById("toDate").value=addDaysISO(localTodayISO(),30);

/* ===== SAFE DATA STORAGE PATCH =====
   Prevents duplicate records from double-clicks/repeated autosave and
   cleans duplicate IDs already present in localStorage.
*/
function uniqueId(prefix, list){
  const used=new Set((Array.isArray(list)?list:[]).map(x=>String(x?.id||"")));
  let id="";
  do { id=prefix+Date.now().toString(36).toUpperCase()+Math.random().toString(36).slice(2,7).toUpperCase(); }
  while(used.has(id));
  return id;
}
function dedupeById(list){
  if(!Array.isArray(list)) return [];
  const map=new Map();
  list.forEach(x=>{
    if(!x || typeof x!=="object") return;
    const id=String(x.id||"").trim();
    if(id) map.set(id,x); else map.set("__noid_"+Math.random().toString(36),x);
  });
  return [...map.values()];
}
function safeSetStorage(key,value){
  try{
    localStorage.setItem(key,JSON.stringify(value));
    return true;
  }catch(err){
    console.error("Storage save failed:",key,err);
    const el=document.getElementById("saveState");
    if(el){el.textContent="Save error — storage may be full";el.className="badge danger";}
    return false;
  }
}
function saveCollectionsClean(){
  customers=dedupeById(customers);
  jobs=dedupeById(jobs);
  employees=dedupeById(employees);
  inventoryItems=dedupeById(inventoryItems);
  serviceReports=dedupeById(serviceReports);
  invoices=dedupeById(invoices);
  quotations=dedupeById(quotations);
}
function dedupeStrings(a){return [...new Set((Array.isArray(a)?a:[]).map(String))];}
function formSaveOnce(form){
  if(!form) return true;
  if(form.dataset.saving==="1") return false;
  form.dataset.saving="1";
  setTimeout(()=>{try{delete form.dataset.saving}catch(_e){}},500);
  return true;
}

function save(){
  saveCollectionsClean();
  safeSetStorage("cg_customers",customers);
  safeSetStorage("cg_daily_jobs",jobs);
  safeSetStorage("cg_visit_plans",visitPlans);
  safeSetStorage("cg_deleted_auto_invoice_keys",dedupeStrings(deletedAutoInvoiceKeys));
  persistLastTreatmentView();
}
let lastDeleted=null;
let companySettings=JSON.parse(localStorage.getItem("cg_company_settings")||"null")||{name:"",trn:"",licenseNo:"",licenseExpiry:"",authority:"",branch:"",phone1:"",phone2:"",email:"",website:"",adminContact:"",emergency:"",address:"",terms:"",quoteValidity:"",vat:5,footer:""};
function saveCompanySettings(e){
  if(e&&e.preventDefault)e.preventDefault();
  const get=id=>document.getElementById(id);
  const val=id=>(get(id)?.value||"").trim();
  companySettings={...companySettings,
    name:val("coName"),trn:val("coTrn"),licenseNo:val("coLicenseNo"),licenseExpiry:get("coLicenseExpiry")?.value||"",
    authority:val("coAuthority"),branch:val("coBranch"),phone1:val("coPhone1"),phone2:val("coPhone2"),
    email:val("coEmail"),website:val("coWebsite"),adminContact:val("coAdminContact"),emergency:val("coEmergency"),
    address:val("coAddress"),terms:val("coTerms")||"Due Upon Receipt",quoteValidity:val("coQuoteValidity")||"30 Days",
    vat:Number(get("coVat")?.value||0),footer:val("coFooter")
  };
  safeSetStorage("cg_company_settings",companySettings);
  if(typeof saveAllData==="function")saveAllData();
  const el=get("companyStatus");
  if(el){el.textContent="✓ Company information saved successfully at "+new Date().toLocaleTimeString();el.className="notice ok";}
  if(typeof loadCompanySettings==="function")loadCompanySettings();
  if(typeof renderInvoices==="function")renderInvoices();
  if(typeof renderQuotations==="function")renderQuotations();
}
function loadCompanySettings(){
  const get=id=>document.getElementById(id);
  if(!get("coName"))return;
  get("coName").value=companySettings.name||"";get("coTrn").value=companySettings.trn||"";
  get("coLicenseNo").value=companySettings.licenseNo||"";get("coLicenseExpiry").value=companySettings.licenseExpiry||"";
  get("coAuthority").value=companySettings.authority||"";get("coBranch").value=companySettings.branch||"";
  get("coPhone1").value=companySettings.phone1||"";get("coPhone2").value=companySettings.phone2||"";
  get("coEmail").value=companySettings.email||"";get("coWebsite").value=companySettings.website||"";
  get("coAdminContact").value=companySettings.adminContact||"";get("coEmergency").value=companySettings.emergency||"";
  get("coAddress").value=companySettings.address||"";get("coTerms").value=companySettings.terms||"Due Upon Receipt";
  get("coQuoteValidity").value=companySettings.quoteValidity||"30 Days";get("coVat").value=companySettings.vat??5;get("coFooter").value=companySettings.footer||"";
}
function actualTreatmentForCustomer(c){let vals=Object.entries(visitPlans).filter(([k,v])=>k.startsWith(c.id+"_")&&v&&v.actualTreatment).map(([k,v])=>v.actualTreatment).filter(Boolean);return vals.sort().slice(-1)[0]||"";}
function persistLastTreatmentView(){let el=document.getElementById("saveState");if(el){el.textContent="💾 تم الحفظ · "+new Date().toLocaleTimeString();el.className="save-pill";}let info=document.getElementById("infoSaveState");if(info)info.textContent="✓ تم الحفظ تلقائيًا";}
function saveAllData(){
  saveCollectionsClean();
  save();
  if(typeof saveEmployees==="function")saveEmployees();
  if(typeof saveInventory==="function")saveInventory();
  if(typeof saveServiceReports==="function")saveServiceReports();
  if(typeof saveInvoices==="function")saveInvoices();
  if(typeof saveQuotations==="function")saveQuotations();
  localStorage.setItem("cg_company_settings",JSON.stringify(companySettings));
  safeSetStorage("cg_deleted_auto_invoice_keys",dedupeStrings(deletedAutoInvoiceKeys));
  let el=document.getElementById("saveState");if(el){el.textContent="💾 تم حفظ جميع البيانات · "+new Date().toLocaleTimeString();el.className="save-pill";}
}
function saveAllAndRefresh(){saveAllData();setTimeout(()=>location.reload(),80);}
function manualSaveV3(){
  const el=document.getElementById("saveState");
  if(el){el.textContent="⏳ جارٍ الحفظ...";el.className="save-pill saving";}
  try{saveAllData();renderAll();if(el){el.textContent="✓ تم الحفظ بنجاح · "+new Date().toLocaleTimeString();el.className="save-pill";}alert("تم حفظ جميع البيانات بنجاح.");}
  catch(err){if(el){el.textContent="⚠ خطأ في الحفظ";el.className="save-pill error";}alert("تعذر حفظ البيانات: "+err.message);}
}
function goTodayV3(){
  const t=localTodayISO();
  const dd=document.getElementById("dailyDate");if(dd)dd.value=t;
  const jd=document.getElementById("jobDate");if(jd)jd.value=t;
  renderDaily();renderJobs();renderDashboard();
  const nav=document.querySelector('#nav button[data-view="daily"]');if(nav)nav.click();
}
function exitAppV3(){
  try{saveAllData();}catch(e){}
  const nativeCandidates=[
    ()=>window.Android&&typeof window.Android.exitApp==='function'&&window.Android.exitApp(),
    ()=>window.Android&&typeof window.Android.closeApp==='function'&&window.Android.closeApp(),
    ()=>window.Android&&typeof window.Android.finish==='function'&&window.Android.finish(),
    ()=>window.App&&typeof window.App.exit==='function'&&window.App.exit(),
    ()=>window.cordova&&window.navigator.app&&typeof window.navigator.app.exitApp==='function'&&window.navigator.app.exitApp()
  ];
  for(const fn of nativeCandidates){try{if(fn()!==false)return;}catch(e){}}
  try{window.close();}catch(e){}
  // Browsers and most WebView converters do not permit scripts to close a top-level window.
  // Give the user a clear fallback instead of silently doing nothing.
  const s=document.getElementById('settingsStatus');
  if(s){s.textContent='تم حفظ البيانات. في نسخة Android استخدم زر خروج لإغلاق التطبيق؛ في المتصفح استخدم زر الرجوع/إغلاق النافذة.';s.className='notice ok';}
  alert('تم حفظ جميع البيانات. إذا كنت تستخدم APK سيغلق التطبيق الآن. أما نسخة المتصفح فلا تسمح بإغلاق النافذة برمجيًا.');
}
window.addEventListener('online',()=>{const x=document.getElementById('connectionStatus');if(x){x.textContent='● متصل';x.className='save-pill';}});
window.addEventListener('offline',()=>{const x=document.getElementById('connectionStatus');if(x){x.textContent='● يعمل بدون إنترنت';x.className='save-pill';}});
window.addEventListener("beforeunload",saveAllData);
window.addEventListener("pagehide",saveAllData);

function is24(type){let t=String(type||"").toUpperCase().trim();return t.includes("RESTAURANT")||t.includes("RESTUR")||t.includes("RESTUA")||t.includes("RESTAU")||t.includes("RESTU")||t==="REST"||t.includes("CAFETERIA")||t.includes("CAFETER")||t.includes("CAFFEE")||t.includes("CAFF")||t.includes("CAFE")||t.includes("HOSPITAL")||t.includes("MEDICAL")||t.includes("مطعم")||t.includes("كافتريا")||t.includes("كافتيريا")||t.includes("مستشفى")||t.includes("مستشفيات")}
function settings(type){return is24(type)?{visits:24,freq:"15 Days"}:{visits:12,freq:"Monthly"}}
function endDate(start){if(!start)return "";let d=new Date(start+"T00:00:00");d.setDate(d.getDate()+364);return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")}
function addMonths(s,n){let d=new Date(s+"T00:00:00");let day=d.getDate();d.setMonth(d.getMonth()+n);if(d.getDate()<day)d.setDate(0);return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")}
function addDaysISO(s,n){let d=new Date(s+"T00:00:00");d.setDate(d.getDate()+Number(n||0));return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")}
function daysBetweenISO(a,b){return Math.round((new Date(b+"T00:00:00")-new Date(a+"T00:00:00"))/86400000)}
/* Schedule source of truth: First Visit Date + manual service count. Postponement is applied in saveJob by shifting the selected and all following plannedDate values. */
function scheduleFor(c){
 let anchor=c.firstVisit||c.start;if(!anchor)return [];
 let count=Number(c.visits)||0;if(count<=0)return [];
 // The service count is entered manually. Only the agreed 24/12 patterns determine the interval.
 let freq=count===24?"15 Days":count===12?"Monthly":(c.frequency||"Manual");
 if(freq!=="15 Days"&&freq!=="Monthly") return [];
 let out=[];
 for(let i=0;i<count;i++){
   let no=i+1,key=c.id+"_"+no,plan=visitPlans[key]||{};
   let originalDate=freq==="15 Days"?addDaysISO(anchor,i*15):addMonths(anchor,i);
   // plannedDate is the single source of truth after postponement. The old/original date is never used for display.
   let date=plan.plannedDate||originalDate;
   out.push({customerId:c.id,name:c.name,area:c.area,visitNo:no,date,frequency:freq,status:plan.status||"Scheduled",lastTreatment:actualTreatmentForCustomer(c),actualTreatment:plan.actualTreatment||"",plannedDate:date,originalDate:plan.originalDate||originalDate,postponed:!!plan.postponed||date!==originalDate,postponedFrom:plan.postponedFrom||"",postponedTo:plan.postponedTo||"",paymentMethod:c.paymentMethod||"Cash"});
 }
 return out;
}
function allVisits(){return customers.flatMap(scheduleFor)}
function statusFor(end){let diff=Math.ceil((new Date(end+"T00:00:00")-new Date(new Date().toISOString().slice(0,10)+"T00:00:00"))/86400000);if(diff<0)return ["EXPIRED","danger",diff];if(diff<=7)return ["URGENT: 0-7 DAYS","danger",diff];if(diff<=30)return ["RENEW: 8-30 DAYS","warn",diff];if(diff<=60)return ["PLAN: 31-60 DAYS","warn",diff];return ["ACTIVE","ok",diff]}
function renderDashboard(){
 let v=allVisits(), td=document.getElementById("dailyDate").value||todayISO, today=v.filter(x=>x.date===td);
 let exp=customers.map(c=>statusFor(endDate(c.start))).filter(x=>x[0]!=="ACTIVE");
 document.getElementById("metrics").innerHTML=[
 ["Total Customers",customers.length],["Visits Today",today.length],["Scheduled Visits",v.length],["Contracts Needing Attention",exp.length]
 ].map(x=>`<div class="card"><div class="muted">${x[0]}</div><div class="metric">${x[1]}</div></div>`).join("");
 document.getElementById("todayPreview").innerHTML=today.length?`<div class="grid">${today.map(x=>`<div class="card"><b>${esc(x.name)}</b><div class="muted">${esc(x.area||"")} · Visit ${x.visitNo}</div></div>`).join("")}</div>`:`<div class="empty">No scheduled visits for ${td}</div>`;
}
function toggleAllCustomers(checked){document.querySelectorAll(".customerSelect").forEach(x=>x.checked=!!checked);}
function deleteSelectedCustomers(){
  let ids=[...document.querySelectorAll(".customerSelect:checked")].map(x=>x.value);
  if(!ids.length){alert("Please select at least one customer to delete.");return;}
  if(!confirm("Delete the selected customers and their linked scheduled visits, jobs and invoices? You can use Undo Last Delete immediately if needed."))return;
  if(ids.length===1){deleteCustomer(ids[0]);return;}
  let removed=[],plans={},linkedInvoices=[],linkedJobs=[];
  ids.forEach(id=>{let c=customers.find(x=>x.id===id);if(c)removed.push(c);Object.keys(visitPlans).filter(k=>k.startsWith(id+"_")).forEach(k=>plans[k]=visitPlans[k]);linkedInvoices.push(...invoices.filter(x=>x.customerId===id));linkedJobs.push(...jobs.filter(x=>x.customerId===id));});
  lastDeleted={type:"customers",items:JSON.parse(JSON.stringify(removed)),plans:JSON.parse(JSON.stringify(plans)),linkedInvoices:JSON.parse(JSON.stringify(linkedInvoices)),linkedJobs:JSON.parse(JSON.stringify(linkedJobs))};
  customers=customers.filter(x=>!ids.includes(x.id));Object.keys(visitPlans).forEach(k=>{if(ids.some(id=>k.startsWith(id+"_")))delete visitPlans[k]});invoices=invoices.filter(x=>!ids.includes(x.customerId));jobs=jobs.filter(x=>!ids.includes(x.customerId));save();saveInvoices();renderAll();
}
function renderCustomers(){
 let q=(document.getElementById("custSearch").value||"").toLowerCase();
 let list=customers.filter(c=>[c.id,c.name,c.type,c.area].join(" ").toLowerCase().includes(q));
 document.getElementById("custBody").innerHTML=list.map(c=>{let manualVisits=Number(c.visits)||0,manualFreq=manualVisits===24?"15 Days":manualVisits===12?"Monthly":"Manual",e=endDate(c.start)||c.end||"";let balance=invoices.filter(i=>i.customerId===c.id&&i.status!=="Cancelled").reduce((a,i)=>a+Math.max(0,Number(i.amount||0)-Number(i.paid||0)),0);return `<tr><td><input type="checkbox" class="customerSelect" value="${esc(c.id)}"></td><td>${esc(c.id)}</td><td><b>${esc(c.name)}</b></td><td>${esc(c.type)}</td><td>${esc(c.area)}</td><td>${esc(c.start||"—")}</td><td>${esc(c.firstVisit||c.start||"—")}</td><td>${esc(e)}</td><td>${manualVisits||"—"}</td><td>${manualFreq}</td><td>${esc(({service:"By Service",monthly:"Every Month",quarterly:"Every 3 Months",semiannual:"Every 6 Months"}[c.billingCycle]||"Every Month"))}</td><td>${balance.toFixed(2)}</td><td><button class="secondary" onclick="openCustomer('${esc(c.id)}')">Edit</button> <button class="secondary" onclick="openInvoiceForCustomer('${esc(c.id)}')">Invoice</button> <button class="secondary" onclick="openCustomerStatement('${esc(c.id)}')">Statement</button> <button class="danger" onclick="deleteCustomer('${esc(c.id)}')">Delete</button></td></tr>`}).join("")||`<tr><td colspan="13" class="empty">No customers</td></tr>`;
}
function renderDaily(){
 let d=document.getElementById("dailyDate").value||todayISO,q=(document.getElementById("dailySearch").value||"").toLowerCase();
 let v=allVisits().filter(x=>x.date===d&&[x.customerId,x.name,x.area].join(" ").toLowerCase().includes(q)).sort((a,b)=>a.date.localeCompare(b.date)||a.name.localeCompare(b.name)||a.visitNo-b.visitNo);
 document.getElementById("dailySummary").innerHTML=`<div class="card"><div class="muted">Report Date</div><div class="metric">${esc(d)}</div></div><div class="card"><div class="muted">Visits Today</div><div class="metric">${v.length}</div></div><div class="card"><div class="muted">Customers Today</div><div class="metric">${new Set(v.map(x=>x.customerId)).size}</div></div>`;
 document.getElementById("dailyBody").innerHTML=v.map(x=>`<tr><td>${esc(x.customerId)}</td><td><b>${esc(x.name)}</b></td><td>${esc(x.area)}</td><td>${x.visitNo}</td><td>${esc(x.date)}</td><td>${esc(x.frequency)}</td><td><span class="badge">${esc(x.status)}</span></td><td><button class="secondary" onclick="openScheduledVisit('${esc(x.customerId)}','${x.visitNo}')">Edit / Plan</button></td></tr>`).join("")||`<tr><td colspan="8" class="empty">No customers scheduled for this date</td></tr>`;
 renderDashboard();
}

function printDailyReport(){
 let d=document.getElementById("dailyDate").value||todayISO;
 let v=allVisits().filter(x=>x.date===d).sort((a,b)=>a.name.localeCompare(b.name)||a.visitNo-b.visitNo);
 let rows=v.map(x=>`<tr><td>${esc(x.customerId)}</td><td>${esc(x.name)}</td><td>${esc(x.area||"")}</td><td>${x.visitNo}</td><td>${esc(x.date)}</td><td>${esc(x.frequency)}</td><td>${esc(x.status)}</td></tr>`).join("")||'<tr><td colspan="7">No scheduled visits for this date</td></tr>';
 let w=window.open("","_blank");if(!w)return;
 w.document.write(`<html><head><title>Daily Visit Report - ${esc(d)}</title><style>body{font-family:Arial;padding:20px}table{border-collapse:collapse;width:100%;margin-top:15px}th,td{border:1px solid #999;padding:8px;font-size:12px;text-align:left}h1{margin-bottom:5px}.summary{margin:10px 0;font-size:14px}</style></head><body><h1>Daily Visit Report</h1><div class="summary"><b>Date:</b> ${esc(d)} &nbsp; | &nbsp; <b>Total Visits:</b> ${v.length} &nbsp; | &nbsp; <b>Customers:</b> ${new Set(v.map(x=>x.customerId)).size}</div><table><thead><tr><th>Customer ID</th><th>Customer</th><th>Area</th><th>Visit No.</th><th>Planned Date</th><th>Frequency</th><th>Status</th></tr></thead><tbody>${rows}</tbody></table>
<script id="stable-2-finalize">
(function(){
  'use strict';
  try {
    // Snapshot VAT on existing persisted documents once, without changing their monetary values.
    ['invoices','quotations'].forEach(function(k){
      try{
        const raw = localStorage.getItem(k);
        if(!raw) return;
        const arr = JSON.parse(raw);
        if(!Array.isArray(arr)) return;
        let changed = false;
        arr.forEach(function(d){
          if(d && (d.vatRate === undefined || d.vatRate === null || d.vatRate === '')){
            d.vatRate = (window.CGStable2 && window.CGStable2.vatRate) ? window.CGStable2.vatRate() : 5;
            changed = true;
          }
        });
        if(changed) localStorage.setItem(k, JSON.stringify(arr));
      }catch(e){ console.warn('Stable Save v2 document snapshot:', e); }
    });
  } catch(e) {}
})();
<\/script>

</body></html>`);
 w.document.close();w.focus();w.print();
}
function renderSchedule(){
 let mode=document.getElementById("scheduleView")?.value||"period",year=Number(document.getElementById("scheduleYear")?.value||new Date().getFullYear());
 let f=document.getElementById("fromDate").value,t=document.getElementById("toDate").value;
 let v=allVisits();
 if(mode==="annual"){f=year+"-01-01";t=year+"-12-31";}
 let filtered=v.filter(x=>(!f||x.date>=f)&&(!t||x.date<=t)).sort((a,b)=>a.date.localeCompare(b.date)||a.name.localeCompare(b.name)||a.visitNo-b.visitNo);
 document.getElementById("scheduleBody").innerHTML=filtered.map(x=>`<tr><td>${esc(x.customerId)}</td><td><b>${esc(x.name)}</b></td><td>${x.visitNo}</td><td>${esc(x.date)}</td><td>${esc(x.frequency)}</td><td><span class="badge ${x.status==='Completed'||x.status==='Closed'?'ok':x.status==='Postponed'?'warn':''}">${esc(x.status)}</span>${x.postponed?`<div class="muted">Moved from ${esc(x.originalDate)}</div>`:""}</td><td><button class="secondary" onclick="openScheduledVisit('${esc(x.customerId)}','${x.visitNo}')">Edit / Plan</button></td></tr>`).join("")||`<tr><td colspan="7" class="empty">No scheduled visits for the selected period</td></tr>`;
 let scheduled=filtered.length,completed=filtered.filter(x=>x.status==='Completed'||x.status==='Closed').length,postponed=filtered.filter(x=>x.postponed).length,customersCount=new Set(filtered.map(x=>x.customerId)).size;
 document.getElementById("scheduleSummary").innerHTML=`<div class="card"><div class="muted">Period</div><b>${esc(f||"All dates")} → ${esc(t||"All dates")}</b></div><div class="card"><div class="muted">Scheduled Visits</div><div class="metric">${scheduled}</div></div><div class="card"><div class="muted">Contracts</div><div class="metric">${customersCount}</div></div><div class="card"><div class="muted">Completed / Closed</div><div class="metric">${completed}</div></div><div class="card"><div class="muted">Postponed</div><div class="metric">${postponed}</div></div>`;
 renderAnnualScheduleTotals(year);
}
function renderAnnualScheduleTotals(year){
 let body=document.getElementById("annualScheduleBody");if(!body)return;
 let allScheduled=allVisits();
 let rows=customers.map(c=>{
   let all=allScheduled.filter(v=>v.customerId===c.id).sort((a,b)=>a.date.localeCompare(b.date)||a.visitNo-b.visitNo);
   let cal=all.filter(v=>v.date>=year+"-01-01"&&v.date<=year+"-12-31");
   let entered=Number(c.visits)||0;
   let done=all.filter(v=>{let p=visitPlans[jobKey(v)]||{};return p.status==='Completed'||p.status==='Closed'}).length;
   let post=all.filter(v=>v.postponed).length;
   let remaining=Math.max(0,entered-done);
   let freq=entered===24?'15 Days':entered===12?'Monthly':(c.frequency||'Manual');
   return {c,all,cal,entered,done,post,remaining,freq};
 }).filter(x=>x.entered>0);
 let totalEntered=rows.reduce((a,x)=>a+x.entered,0),totalContract=rows.reduce((a,x)=>a+x.all.length,0),totalYear=rows.reduce((a,x)=>a+x.cal.length,0),totalDone=rows.reduce((a,x)=>a+x.done,0),totalPost=rows.reduce((a,x)=>a+x.post,0),totalRemaining=rows.reduce((a,x)=>a+x.remaining,0);
 body.innerHTML=rows.map(x=>`<tr><td>${esc(x.c.id)}</td><td><b>${esc(x.c.name)}</b><div class="muted">${esc(x.freq)}</div></td><td>${esc(x.c.start||"—")}</td><td>${esc(x.c.firstVisit||x.c.start||"—")}</td><td>${x.entered}</td><td>${x.all.length}</td><td>${x.cal.length}</td><td>${x.done}</td><td>${x.post}</td><td>${x.remaining}</td></tr>`).join("")+
 (rows.length?`<tr style="font-weight:700;background:var(--soft)"><td colspan="4">GRAND TOTAL</td><td>${totalEntered}</td><td>${totalContract}</td><td>${totalYear}</td><td>${totalDone}</td><td>${totalPost}</td><td>${totalRemaining}</td></tr>`:`<tr><td colspan="10" class="empty">No annual contract schedules found</td></tr>`);
}

function renderExpiry(){
 let f=document.getElementById("expiryFilter").value;
 let list=customers.map(c=>{let e=endDate(c.start),s=statusFor(e);return {...c,end:e,st:s[0],cls:s[1],days:s[2]}}).filter(c=>f==="all"||(f==="expired"&&c.days<0)||(f==="urgent"&&c.days>=0&&c.days<=7)||(f==="renew"&&c.days>7&&c.days<=30)||(f==="plan"&&c.days>30&&c.days<=60));
 document.getElementById("expiryBody").innerHTML=list.sort((a,b)=>a.days-b.days).map(c=>`<tr><td>${esc(c.id)}</td><td><b>${esc(c.name)}</b></td><td>${esc(c.type)}</td><td>${c.end}</td><td>${c.days}</td><td><span class="badge ${c.cls}">${c.st}</span></td></tr>`).join("")||`<tr><td colspan="6" class="empty">No contracts</td></tr>`;
}
function lastCompletedVisit(c){
 let today=todayISO, completed=allVisits().filter(v=>v.customerId===c.id&&v.date<=today).filter(v=>{let p=visitPlans[jobKey(v)]||{};return p.status==='Completed'||p.status==='Closed'}).sort((a,b)=>b.date.localeCompare(a.date));
 return completed[0]||null;
}
function renderOverdueVisits(){
 let today=todayISO;
 let list=customers.map(c=>{
   let last=lastCompletedVisit(c);
   let ref=last?last.date:(c.start||today);
   let days=Math.floor((new Date(today+'T00:00:00')-new Date(ref+'T00:00:00'))/86400000);
   let next=allVisits().filter(v=>v.customerId===c.id&&v.date>today).sort((a,b)=>a.date.localeCompare(b.date))[0];
   let np=next?visitPlans[jobKey(next)]||{}:{};
   return {c,last,ref,days,next,np};
 }).filter(x=>x.days>=20).sort((a,b)=>b.days-a.days);
 document.getElementById('overdueVisitBody').innerHTML=list.map(x=>`<tr><td>${esc(x.c.id)}</td><td><b>${esc(x.c.name)}</b></td><td>${esc(x.c.type)}</td><td>${esc(x.last?x.last.date:x.c.start||'—')}</td><td><span class="badge warn">${x.days} days</span></td><td>${x.next?esc(x.next.date):'—'}</td><td>${esc(x.np.tech||'Unassigned')}</td><td><span class="badge warn">Needs Visit</span></td></tr>`).join('')||`<tr><td colspan="8" class="empty">No contracts have gone 20 days or more without a recorded visit</td></tr>`;
}

function openCustomer(id){
 let c=customers.find(x=>x.id===id)||{id:"",name:"",type:"",area:"",contact:"",phone:"",start:todayISO,firstVisit:todayISO,value:"",notes:"",billingCycle:"monthly"};
 document.getElementById("modalTitle").textContent=id?"Edit Customer":"Add Customer";deleteCustomerBtn.style.display=id?"inline-block":"none";
 fId.value=c.id;fName.value=c.name;fType.value=c.type;fArea.value=c.area;fContact.value=c.contact;fPhone.value=c.phone;fStart.value=c.start||todayISO;fVisits.value=c.visits||"";fFirstVisit.value=c.firstVisit||c.start||todayISO;fValue.value=c.value;fPaymentSchedule.value=c.billingCycle||"monthly";fNotes.value=c.notes;updateAuto();document.getElementById("modal").classList.add("open");
}
fType.addEventListener("input",updateAuto);fVisits.addEventListener("input",updateAuto);fStart.addEventListener("input",()=>{if(!fFirstVisit.value)fFirstVisit.value=fStart.value;updateAuto()});fFirstVisit.addEventListener("input",updateAuto);
function updateAuto(){let visits=Number(fVisits.value)||0;let freq=visits===24?"15 Days":visits===12?"Monthly":"Manual";let msg=`الخدمات/السنة: ${visits||"أدخل العدد"} · التكرار: ${freq} · أول زيارة: ${fFirstVisit.value||"—"} · نهاية العقد: ${endDate(fStart.value)||"—"}`;if(!visits)msg+=" · ⚠ لا يمكن إنشاء جدول الزيارات حتى يتم إدخال عدد الخدمات";document.getElementById("autoInfo").textContent=msg;fFirstVisit.min=fStart.value||""}
function closeModal(){document.getElementById("modal").classList.remove("open")}
function saveCustomer(e){e.preventDefault();if(!formSaveOnce(e?.currentTarget))return;let id=fId.value||("C"+String(Math.max(0,...customers.map(c=>parseInt((c.id||"").replace(/\D/g,""))||0))+1).padStart(3,"0"));let old=customers.find(x=>x.id===id)||{},first=fFirstVisit.value||fStart.value,c={...old,id,name:fName.value,type:fType.value,area:fArea.value,contact:fContact.value,phone:fPhone.value,start:fStart.value,end:endDate(fStart.value),visits:Number(fVisits.value)||0,frequency:(Number(fVisits.value)===24?"15 Days":Number(fVisits.value)===12?"Monthly":"Manual"),firstVisit:first,value:fValue.value?Number(fValue.value):"",billingCycle:fPaymentSchedule.value||"monthly",paymentMethod:old.paymentMethod||"Cash",notes:fNotes.value};let idx=customers.findIndex(x=>x.id===id);if(idx>=0)customers[idx]=c;else customers.push(c);save();closeModal();const dd=document.getElementById("dailyDate");if(dd&&first===localTodayISO())dd.value=localTodayISO();renderAll();renderDaily();}
function esc(x){return String(x??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

function timeToMin(t){if(!t)return null;let p=t.split(":").map(Number);return p[0]*60+p[1]}
function minToTime(m){m=((m%1440)+1440)%1440;return String(Math.floor(m/60)).padStart(2,"0")+":"+String(m%60).padStart(2,"0")}
function jobKey(x){return x.customerId+"_"+x.visitNo}
function scheduledVisitItems(date){
 return allVisits().filter(v=>v.date===date).map(v=>{let p=visitPlans[jobKey(v)]||{};let c=customers.find(x=>x.id===v.customerId)||{};return {id:"SV-"+jobKey(v),source:"Scheduled Visit",visitKey:jobKey(v),customerId:v.customerId,name:v.name,phone:c.phone||"",date:v.date,time:p.time||"",duration:Number(p.duration||60),address:p.address||c.area||"",pest:p.pest||"",property:p.property||"",rooms:p.rooms||"",tech:p.tech||"",status:p.status||"Scheduled",follow:p.follow||"",notes:p.notes||"",visitNo:v.visitNo,frequency:v.frequency};});
}
function allJobItems(date){return [...scheduledVisitItems(date),...jobs.filter(j=>j.date===date).map(j=>({...j,source:"Daily Job",duration:Number(j.duration||60),end:j.end||""}))]}
function activeTechnicians(){return employees.filter(e=>e.status==="Active"&&String(e.role||"").toLowerCase()==="technician")}
function overlaps(aStart,aDur,bStart,bDur){let a=timeToMin(aStart),b=timeToMin(bStart);if(a===null||b===null)return false;return a<b+Number(bDur||60)&&b<a+Number(aDur||60)}
function technicianConflicts(name,date,time,duration,excludeId,excludeVisitKey){
 if(!name||!time)return [];
 return allJobItems(date).filter(x=>x.tech===name&&x.id!==excludeId&&x.visitKey!==excludeVisitKey&&x.status!=="Completed"&&x.status!=="Closed"&&overlaps(time,duration,x.time,x.duration));
}
function technicianSlots(name,date,excludeId,excludeVisitKey){
 let items=allJobItems(date).filter(x=>x.tech===name&&x.time&&x.status!=="Completed"&&x.status!=="Closed"&&x.id!==excludeId&&x.visitKey!==excludeVisitKey).sort((a,b)=>timeToMin(a.time)-timeToMin(b.time));
 let free=[];let cursor=8*60;items.forEach(x=>{let st=timeToMin(x.time),en=st+Number(x.duration||60);if(st>cursor)free.push(minToTime(cursor)+"–"+minToTime(st));cursor=Math.max(cursor,en)});if(cursor<18*60)free.push(minToTime(cursor)+"–"+minToTime(18*60));return {items,free};
}
function populateJobTechnicians(selected){let sel=document.getElementById("jTech");let old=selected||sel.value||"";sel.innerHTML='<option value="">Unassigned — choose from available technicians</option>'+activeTechnicians().map(e=>`<option value="${esc(e.name)}">${esc(e.name)}</option>`).join("");if(activeTechnicians().some(e=>e.name===old))sel.value=old;}
function updateJobAvailability(){
 let date=jDate.value,time=jTime.value,dur=Number(jDuration.value||60),sel=jTech.value, box=document.getElementById("jobAvailability");
 if(time)jEnd.value=minToTime(timeToMin(time)+dur);else jEnd.value="";
 let techs=activeTechnicians();
 if(!date||!time){box.innerHTML="Enter the date and start time to see technician availability.";return}
 let cards=techs.map(e=>{let conflicts=technicianConflicts(e.name,date,time,dur,jId.value,jVisitKey.value);let slots=technicianSlots(e.name,date,jId.value,jVisitKey.value);return {e,conflicts,slots}});
 box.innerHTML=cards.length?cards.map(x=>`<div style="margin-bottom:9px"><b>${esc(x.e.name)}</b> — ${x.conflicts.length?'<span class="badge warn">Busy at this time</span>':'<span class="badge ok">Available</span>'}<div class="muted">Free: ${x.slots.free.length?x.slots.free.join(' · '):'No free slot in 08:00–18:00'}</div>${x.slots.items.length?'<div>'+x.slots.items.map(j=>`<span class="slot busy">${esc(j.time)}–${esc(minToTime(timeToMin(j.time)+Number(j.duration||60)))} ${esc(j.name)}</span>`).join("")+'</div>':''}</div>`).join(""):'No active technicians have been added yet.';
}
function openJob(id){
 let j=jobs.find(x=>x.id===id)||{id:"",name:"",phone:"",date:todayISO,time:"",duration:60,address:"",pest:"",property:"Apartment",rooms:"",tech:"",status:"New",follow:"",notes:"",cost:0,source:"Daily Job",visitKey:""};
 jId.value=j.id;jSource.value="Daily Job";jVisitKey.value="";
 document.getElementById("jobModalTitle").textContent=id?"Edit Daily Job":"New Daily Job";
 jName.value=j.name;jPhone.value=j.phone;jDate.value=j.date||todayISO;jTime.value=j.time||"";jDuration.value=j.duration||60;jEnd.value=j.time?minToTime(timeToMin(j.time)+Number(j.duration||60)):"";jAddress.value=j.address;jPest.value=j.pest;jProperty.value=j.property||"Apartment";jRooms.value=j.rooms||"";populateJobTechnicians(j.tech||"");jStatus.value=j.status||"New";jFollow.value=j.follow||"";jActualTreatment.value=j.actualTreatment||"";jCost.value=Number(j.cost||0);jNotes.value=j.notes||"";deleteJobBtn.style.display=id?"inline-block":"none";updateJobAvailability();document.getElementById("jobModal").classList.add("open");
}
function openScheduledVisit(customerId,visitNo){
 let v=allVisits().find(x=>x.customerId===customerId&&x.visitNo===Number(visitNo));if(!v)return;let p=visitPlans[jobKey(v)]||{},c=customers.find(x=>x.id===customerId)||{};
 jId.value="SV-"+jobKey(v);jSource.value="Scheduled Visit";jVisitKey.value=jobKey(v);document.getElementById("jobModalTitle").textContent="Plan Scheduled Visit";
 jName.value=c.name||v.name;jPhone.value=c.phone||"";jDate.value=v.date;jTime.value=p.time||"";jDuration.value=p.duration||60;jEnd.value=p.time?minToTime(timeToMin(p.time)+Number(p.duration||60)):"";jAddress.value=p.address||c.area||"";jPest.value=p.pest||"";jProperty.value=p.property||"Apartment";jRooms.value=p.rooms||"";populateJobTechnicians(p.tech||"");jStatus.value=p.status||"Scheduled";jFollow.value=p.follow||"";jActualTreatment.value=p.actualTreatment||"";jCost.value=0;jNotes.value=p.notes||"";jId.value="SV-"+jobKey(v);deleteJobBtn.style.display="none";updateJobAvailability();document.getElementById("jobModal").classList.add("open");
}
function closeJob(){document.getElementById("jobModal").classList.remove("open")}
function rescheduleVisitAndFollowing(customerId, visitNo, oldDate, newDate, status){
  const delta=daysBetweenISO(oldDate,newDate);
  if(!delta) return;
  const visits=allVisits().filter(v=>v.customerId===customerId && v.visitNo>=Number(visitNo)).sort((a,b)=>a.visitNo-b.visitNo);
  visits.forEach(v=>{
    const key=jobKey(v), old=visitPlans[key]||{};
    const base=v.date||old.plannedDate||v.originalDate;
    visitPlans[key]={...old, originalDate:old.originalDate||v.originalDate||base, plannedDate:addDaysISO(base,delta),
      postponed:v.visitNo===Number(visitNo)?true:(old.postponed||false),
      postponedFrom:v.visitNo===Number(visitNo)?oldDate:(old.postponedFrom||''),
      postponedTo:v.visitNo===Number(visitNo)?newDate:(old.postponedTo||''),
      status:v.visitNo===Number(visitNo)?status:(old.status||'Scheduled')};
  });
  safeSetStorage('cg_visit_plans',visitPlans);
}
function ensureDailyJobInvoice(job){
  if(!job || job.source!=='Daily Job' || job.status!=='Completed') return false;
  const amount=Number(job.cost||0); if(amount<=0) return false;
  if(invoices.some(i=>i.jobId===job.id && i.source==='Daily Job' && i.status!=='Cancelled')) return false;
  invoices.push({id:uniqueId('DI',invoices),no:invoiceNo(),date:job.actualTreatment||job.date||localTodayISO(),source:'Daily Job',financialType:'daily',customerId:'',jobId:job.id,amount:Number(amount.toFixed(2)),paid:0,paymentMethod:'Cash',due:job.actualTreatment||job.date||localTodayISO(),status:'Issued',notes:'Automatic daily-job invoice'});
  saveInvoices(); return true;
}
function saveJob(e){
 e.preventDefault();if(!formSaveOnce(e?.currentTarget))return;
 let dur=Number(jDuration.value||60),conf=jTech.value?technicianConflicts(jTech.value,jDate.value,jTime.value,dur,jSource.value==="Daily Job"?jId.value:"",jVisitKey.value):[];
 if(conf.length){alert("This technician is already booked at this time. Please choose another technician or another time.");return}
 if(jSource.value==="Scheduled Visit"){
   let parts=jVisitKey.value.split("_"),customerId=parts[0],visitNo=Number(parts[1]),customer=customers.find(c=>c.id===customerId),actual=jActualTreatment.value||"";
   if(!customer||!visitNo){alert("Invalid scheduled visit.");return}
   let existingPlan=visitPlans[jVisitKey.value]||{},plannedDate=jDate.value||"";
   let currentVisits=allVisits().filter(x=>x.customerId===customerId).sort((a,b)=>a.visitNo-b.visitNo);
   let currentVisit=currentVisits.find(x=>x.visitNo===visitNo);
   let originalDate=existingPlan.originalDate||(currentVisit&&currentVisit.originalDate)||plannedDate;
   let oldPlannedDate=currentVisit&&currentVisit.date?currentVisit.date:(existingPlan.plannedDate||originalDate);
   let isPostponed=jStatus.value==="Postponed"&&plannedDate&&oldPlannedDate&&plannedDate!==oldPlannedDate;
   let postponementDays=isPostponed?daysBetweenISO(oldPlannedDate,plannedDate):0;
   if(isPostponed&&postponementDays!==0){
     rescheduleVisitAndFollowing(customerId,visitNo,oldPlannedDate,plannedDate,jStatus.value);
   }
   let finalPlan=visitPlans[jVisitKey.value]||existingPlan;
   visitPlans[jVisitKey.value]={...finalPlan,time:jTime.value,duration:dur,address:jAddress.value,pest:jPest.value,property:jProperty.value,rooms:jRooms.value,tech:jTech.value,status:jStatus.value,follow:jFollow.value,actualTreatment:actual,plannedDate:(isPostponed&&postponementDays!==0)?(visitPlans[jVisitKey.value].plannedDate||plannedDate):plannedDate,originalDate:originalDate,postponed:(isPostponed&&postponementDays!==0)||!!finalPlan.postponed,postponedFrom:(isPostponed&&postponementDays!==0)?oldPlannedDate:(finalPlan.postponedFrom||""),postponedTo:(isPostponed&&postponementDays!==0)?plannedDate:(finalPlan.postponedTo||""),notes:jNotes.value};
   save();closeJob();renderAll();return;
 }
 let id=jId.value||uniqueId("J",jobs),j={id,name:jName.value,phone:jPhone.value,date:jDate.value,time:jTime.value,duration:dur,end:minToTime(timeToMin(jTime.value)+dur),address:jAddress.value,pest:jPest.value,property:jProperty.value,rooms:jRooms.value?Number(jRooms.value):"",tech:jTech.value,status:jStatus.value,follow:jFollow.value,actualTreatment:jActualTreatment.value||"",cost:Number(jCost.value||0),notes:jNotes.value,source:"Daily Job"};
 let i=jobs.findIndex(x=>x.id===id);if(i>=0)jobs[i]=j;else jobs.push(j);save();ensureDailyJobInvoice(j);closeJob();renderAll();
}
function deleteJob(id){if(!id||id.startsWith("SV-"))return;if(!confirm("Delete this daily job? You can use Undo Last Delete immediately if needed."))return;let item=jobs.find(x=>x.id===id);if(!item)return;lastDeleted={type:"job",item:JSON.parse(JSON.stringify(item))};jobs=jobs.filter(x=>x.id!==id);save();closeJob();renderAll();}
function renderJobs(){
 let d=document.getElementById("jobDate").value||todayISO,q=(document.getElementById("jobSearch").value||"").toLowerCase(),tech=document.getElementById("jobTech").value,status=document.getElementById("jobStatus").value;
 let techs=activeTechnicians().map(e=>e.name).sort();let sel=document.getElementById("jobTech"),old=sel.value;sel.innerHTML='<option value="">All Technicians</option>'+techs.map(t=>`<option>${esc(t)}</option>`).join("");if(techs.includes(old))sel.value=old;tech=sel.value;
 let list=allJobItems(d).filter(j=>(!tech||j.tech===tech)&&(!status||j.status===status)&&(!q||[j.id,j.name,j.phone,j.address,j.pest,j.property,j.tech,j.notes,j.source].join(" ").toLowerCase().includes(q))).sort((a,b)=>(a.time||"99:99").localeCompare(b.time||"99:99")||a.name.localeCompare(b.name));
 document.getElementById("jobsBody").innerHTML=list.map(j=>`<tr><td><span class="badge ${j.source==='Scheduled Visit'?'warn':'ok'}">${esc(j.source)}</span>${j.visitNo?`<div class="muted">Visit ${j.visitNo}</div>`:''}</td><td>${esc(j.time||"Not set")}${j.time?`<div class="muted">to ${esc(minToTime(timeToMin(j.time)+Number(j.duration||60)))}</div>`:''}</td><td>${j.time?esc(j.duration||60)+" min":"—"}</td><td><b>${esc(j.name)}</b><div class="muted">${esc(j.id)}</div></td><td>${esc(j.phone)}</td><td>${esc(j.address)}</td><td>${esc(j.pest)}</td><td>${esc(j.property)}</td><td>${esc(j.tech||"Unassigned")}</td><td>AED ${Number(j.cost||0).toFixed(2)}</td><td><span class="badge ${j.status==='Completed'||j.status==='Closed'?'ok':j.status==='Follow-up'?'warn':''}">${esc(j.status)}</span></td><td>${j.source==='Scheduled Visit'?`<button class="secondary" onclick="openScheduledVisit('${esc(j.customerId)}','${j.visitNo}')">Plan</button>`:`<button class="secondary" onclick="openJob('${esc(j.id)}')">Edit</button> <button class="danger" onclick="deleteJob('${esc(j.id)}')">Delete</button>`}</td></tr>`).join("")||`<tr><td colspan="12" class="empty">No jobs or scheduled visits for this date</td></tr>`;
 renderTechnicianAvailability(d);
}
function renderTechnicianAvailability(date){
 let box=document.getElementById("techAvailability");if(!box)return;let techs=activeTechnicians();box.innerHTML=techs.length?techs.map(e=>{let s=technicianSlots(e.name,date);return `<div class="card avail-card"><b>${esc(e.name)}</b><div class="muted" style="margin-top:4px">${s.items.length?s.items.length+" booking(s)":"No bookings"}</div><div style="margin-top:5px">${s.free.length?s.free.map(x=>`<span class="slot free">${esc(x)}</span>`).join(""):'<span class="slot busy">Fully booked 08:00–18:00</span>'}</div></div>`}).join(""):'';
}


let employees=JSON.parse(localStorage.getItem("cg_employees")||"[]");
if(!employees.length){
 employees=[
  {id:"EMP001",code:"EMP001",name:"Technician 1",role:"Technician",phone:"",user:"",status:"Active",notes:""},
  {id:"EMP002",code:"EMP002",name:"Technician 2",role:"Technician",phone:"",user:"",status:"Active",notes:""}
 ];
 localStorage.setItem("cg_employees",JSON.stringify(employees));
}
function saveEmployees(){employees=dedupeById(employees);safeSetStorage("cg_employees",employees)}
function openEmployee(id){
 let e=employees.find(x=>x.id===id)||{id:"",code:"",name:"",role:"Technician",phone:"",user:"",status:"Active",notes:""};
 eId.value=e.id;eCode.value=e.code;eName.value=e.name;eRole.value=e.role;ePhone.value=e.phone;eUser.value=e.user;eStatus.value=e.status;eNotes.value=e.notes;
 document.getElementById("employeeModalTitle").textContent=id?"Edit Employee":"New Employee";deleteEmployeeBtn.style.display=id?"inline-block":"none";
 document.getElementById("employeeModal").classList.add("open");
}
function closeEmployee(){document.getElementById("employeeModal").classList.remove("open")}
function saveEmployee(ev){
 ev.preventDefault();
 if(!formSaveOnce(ev?.currentTarget))return; let id=eId.value||uniqueId("E",employees);
 let e={id,code:eCode.value.trim(),name:eName.value.trim(),role:eRole.value,phone:ePhone.value.trim(),user:eUser.value.trim(),status:eStatus.value,notes:eNotes.value.trim()};
 let i=employees.findIndex(x=>x.id===id); if(i>=0) employees[i]=e; else employees.push(e);
 saveEmployees();closeEmployee();renderEmployees();renderJobs();
}
function deleteEmployee(id){if(!id||!confirm("Delete this employee? You can use Undo Last Delete immediately if needed."))return;let item=employees.find(x=>x.id===id);if(!item)return;lastDeleted={type:"employee",item:JSON.parse(JSON.stringify(item))};employees=employees.filter(x=>x.id!==id);saveEmployees();closeEmployee();renderAll();}
function renderEmployees(){
 let q=(document.getElementById("empSearch").value||"").toLowerCase(), role=document.getElementById("empRoleFilter").value, status=document.getElementById("empStatusFilter").value;
 let list=employees.filter(e=>(!role||e.role===role)&&(!status||e.status===status)&&(!q||[e.code,e.name,e.role,e.phone,e.user,e.notes].join(" ").toLowerCase().includes(q)));
 document.getElementById("employeesBody").innerHTML=list.map(e=>{
   let count=jobs.filter(j=>j.tech===e.name).length;
   return `<tr><td>${esc(e.code)}</td><td><b>${esc(e.name)}</b></td><td>${esc(e.role)}</td><td>${esc(e.phone)}</td><td>${esc(e.user)}</td><td><span class="badge ${e.status==='Active'?'ok':''}">${esc(e.status)}</span></td><td>${count}</td><td><button class="secondary" onclick="openEmployee('${esc(e.id)}')">Edit</button> <button class="secondary" onclick="deleteEmployee('${esc(e.id)}')">Delete</button></td></tr>`;
 }).join("")||`<tr><td colspan="8" class="empty">No employees found</td></tr>`;
}

let inventoryItems=JSON.parse(localStorage.getItem("cg_inventory_items")||"[]");
let inventoryMovements=JSON.parse(localStorage.getItem("cg_inventory_movements")||"[]");
function saveInventory(){inventoryItems=dedupeById(inventoryItems);safeSetStorage("cg_inventory_items",inventoryItems);safeSetStorage("cg_inventory_movements",inventoryMovements)}
function inventoryStatus(item){
 let today=new Date(); today.setHours(0,0,0,0); let exp=item.expiry?new Date(item.expiry+"T00:00:00"):null;
 if(exp&&exp<today)return ["expired","Expired"];
 if(exp){let days=Math.ceil((exp-today)/86400000);if(days<=30)return ["soon","Expiring Soon"]}
 if(Number(item.stock||0)<=Number(item.min||0))return ["low","Low Stock"];
 return ["ok","Available"];
}
function openInventoryItem(id){
 let x=inventoryItems.find(a=>a.id===id)||{id:"",name:"",active:"",company:"",pack:"",unit:"Liter",stock:0,min:0,expiry:"",notes:""};
 invId.value=x.id;invName.value=x.name;invActive.value=x.active;invCompany.value=x.company;invPack.value=x.pack;invUnit.value=x.unit;invStock.value=x.stock;invMin.value=x.min;invExpiry.value=x.expiry;invNotes.value=x.notes;
 inventoryItemModalTitle.textContent=id?"Edit Pesticide":"New Pesticide";deleteInventoryBtn.style.display=id?"inline-block":"none";inventoryItemModal.classList.add("open");
}
function closeInventoryItem(){inventoryItemModal.classList.remove("open")}
function deleteInventoryItem(id){if(!id||!confirm("Delete this pesticide? Stock history will also be removed. You can use Undo Last Delete immediately if needed."))return;let item=inventoryItems.find(x=>x.id===id);if(!item)return;let linked=inventoryMovements.filter(m=>m.itemId===id);lastDeleted={type:"inventory",item:JSON.parse(JSON.stringify(item)),movements:JSON.parse(JSON.stringify(linked))};inventoryItems=inventoryItems.filter(x=>x.id!==id);inventoryMovements=inventoryMovements.filter(m=>m.itemId!==id);saveInventory();closeInventoryItem();renderAll();}
function deleteInventoryMovement(index){let m=inventoryMovements[index];if(!m||!confirm("Delete this stock movement and reverse its stock effect?"))return;let x=inventoryItems.find(a=>a.id===m.itemId);if(x)x.stock=Number(x.stock||0)-(m.type==='in'?Number(m.qty||0):-Number(m.qty||0));inventoryMovements.splice(index,1);saveInventory();renderInventory();renderNotifications();}
function saveInventoryItem(e){e.preventDefault();if(!formSaveOnce(e?.currentTarget))return; let id=invId.value||uniqueId("P",inventoryItems);let x={id,name:invName.value.trim(),active:invActive.value.trim(),company:invCompany.value.trim(),pack:invPack.value.trim(),unit:invUnit.value,stock:Number(invStock.value||0),min:Number(invMin.value||0),expiry:invExpiry.value,notes:invNotes.value.trim()};let i=inventoryItems.findIndex(a=>a.id===id);if(i>=0)inventoryItems[i]=x;else inventoryItems.push(x);saveInventory();closeInventoryItem();renderInventory()}
function openStockMovement(type){
 moveType.value=type;moveDate.value=todayISO;moveQty.value="";moveReason.value="";moveNotes.value="";
 moveItem.innerHTML='<option value="">Select pesticide</option>'+inventoryItems.map(x=>`<option value="${esc(x.id)}">${esc(x.name)}</option>`).join("");
 moveEmployee.innerHTML='<option value="">Select employee</option>'+employees.filter(e=>e.status==='Active').map(e=>`<option value="${esc(e.name)}">${esc(e.name)}</option>`).join("");
 stockMovementTitle.textContent=type==='in'?"Stock In":"Stock Out";stockMovementModal.classList.add("open");
}
function closeStockMovement(){stockMovementModal.classList.remove("open")}
function saveStockMovement(e){e.preventDefault();if(!formSaveOnce(e?.currentTarget))return;let id=moveItem.value,x=inventoryItems.find(a=>a.id===id),qty=Number(moveQty.value||0);if(!x||qty<=0)return;if(moveType.value==='out'&&qty>Number(x.stock||0)){alert('Insufficient stock for this pesticide.');return}x.stock=Number(x.stock||0)+(moveType.value==='in'?qty:-qty);inventoryMovements.unshift({date:moveDate.value,itemId:id,item:x.name,type:moveType.value,qty,employee:moveEmployee.value,reason:moveReason.value,notes:moveNotes.value});saveInventory();closeStockMovement();renderInventory()}
function renderInventory(){
 let q=(document.getElementById('invSearch').value||'').toLowerCase(),filter=document.getElementById('invStatus').value;
 let list=inventoryItems.filter(x=>{let st=inventoryStatus(x)[0];return(!filter||st===filter)&&(!q||[x.name,x.active,x.company,x.pack,x.unit].join(' ').toLowerCase().includes(q))});
 let counts={low:0,expired:0,soon:0};inventoryItems.forEach(x=>{let st=inventoryStatus(x)[0];if(counts[st]!==undefined)counts[st]++});
 document.getElementById('inventoryMetrics').innerHTML=`<div class="card"><b>Total Pesticides</b><div style="font-size:25px;font-weight:700;margin-top:5px">${inventoryItems.length}</div></div><div class="card"><b>Low Stock</b><div style="font-size:25px;font-weight:700;margin-top:5px">${counts.low}</div></div><div class="card"><b>Expiring Soon</b><div style="font-size:25px;font-weight:700;margin-top:5px">${counts.soon}</div></div><div class="card"><b>Expired</b><div style="font-size:25px;font-weight:700;margin-top:5px">${counts.expired}</div></div>`;
 document.getElementById('inventoryBody').innerHTML=list.map(x=>{let [cls,label]=inventoryStatus(x);return `<tr><td><b>${esc(x.name)}</b><div class="muted">${esc(x.id)}</div></td><td>${esc(x.active)}</td><td>${esc(x.company)}</td><td>${esc(x.pack)} ${esc(x.unit)}</td><td><b>${esc(x.stock)}</b></td><td>${esc(x.min)}</td><td>${esc(x.expiry||'—')}</td><td><span class="badge ${cls==='ok'?'ok':cls==='soon'||cls==='low'?'warn':''}">${label}</span></td><td><button class="secondary" onclick="openInventoryItem('${esc(x.id)}')">Edit</button></td></tr>`}).join('')||'<tr><td colspan="9" class="empty">No pesticides found</td></tr>';
 document.getElementById('inventoryMovementsBody').innerHTML=inventoryMovements.slice(0,100).map(m=>`<tr><td>${esc(m.date)}</td><td>${esc(m.item)}</td><td><span class="badge ${m.type==='in'?'ok':'warn'}">${m.type==='in'?'Stock In':'Stock Out'}</span></td><td>${esc(m.qty)}</td><td>${esc(m.employee||'—')}</td><td>${esc(m.reason||'—')}</td><td>${esc(m.notes||'—')}</td><td><button class="secondary" onclick="deleteInventoryMovement(${inventoryMovements.indexOf(m)})">Delete</button></td></tr>`).join('')||'<tr><td colspan="8" class="empty">No stock movements yet</td></tr>';
}


let serviceReports=JSON.parse(localStorage.getItem("cg_service_reports")||"[]");
function saveServiceReports(){serviceReports=dedupeById(serviceReports);safeSetStorage("cg_service_reports",serviceReports);}
function serviceReportNo(){return "SR-"+(new Date().getFullYear())+"-"+String(serviceReports.length+1).padStart(4,"0");}
function openServiceReport(id){
 let r=serviceReports.find(x=>x.id===id)||{id:"",date:todayISO,customerId:customers[0]?.id||"",address:"",phone:"",pest:"",property:"",tech:activeTechnicians()[0]?.name||"",action:"",chemical:"",qty:"",follow:"No",signature:"",remarks:"",reportNo:""};
 document.getElementById("srId").value=r.id;document.getElementById("srDate").value=r.date;document.getElementById("srAddress").value=r.address||"";document.getElementById("srPhone").value=r.phone||"";document.getElementById("srPest").value=r.pest||"";document.getElementById("srProperty").value=r.property||"";document.getElementById("srAction").value=r.action||"";document.getElementById("srChemical").value=r.chemical||"";document.getElementById("srQty").value=r.qty||"";document.getElementById("srFollow").value=r.follow||"No";document.getElementById("srSignature").value=r.signature||"";document.getElementById("srRemarks").value=r.remarks||"";
 let cs=document.getElementById("srCustomer");cs.innerHTML=customers.map(c=>`<option value="${esc(c.id)}">${esc(c.name)} (${esc(c.id)})</option>`).join("");cs.value=r.customerId||"";
 let ts=activeTechnicians();document.getElementById("srTechForm").innerHTML=ts.map(e=>`<option>${esc(e.name)}</option>`).join("");document.getElementById("srTechForm").value=r.tech||"";fillServiceCustomer();
 document.getElementById("serviceReportModalTitle").textContent=id?"Edit Service Report":"New Service Report";deleteServiceReportBtn.style.display=id?"inline-block":"none";document.getElementById("serviceReportModal").classList.add("open");
}
function fillServiceCustomer(){let c=customers.find(x=>x.id===document.getElementById("srCustomer").value);if(c){document.getElementById("srAddress").value=document.getElementById("srAddress").value||c.area||"";document.getElementById("srPhone").value=document.getElementById("srPhone").value||c.phone||"";}}
function closeServiceReport(){document.getElementById("serviceReportModal").classList.remove("open");}
function saveServiceReport(e){e.preventDefault();if(!formSaveOnce(e?.currentTarget))return; let id=document.getElementById("srId").value||uniqueId("SR",serviceReports),old=serviceReports.find(x=>x.id===id);let r={id,date:document.getElementById("srDate").value,customerId:document.getElementById("srCustomer").value,address:document.getElementById("srAddress").value,phone:document.getElementById("srPhone").value,pest:document.getElementById("srPest").value,property:document.getElementById("srProperty").value,tech:document.getElementById("srTechForm").value,action:document.getElementById("srAction").value,chemical:document.getElementById("srChemical").value,qty:document.getElementById("srQty").value,follow:document.getElementById("srFollow").value,signature:document.getElementById("srSignature").value,remarks:document.getElementById("srRemarks").value,reportNo:old?.reportNo||serviceReportNo()};if(old)serviceReports=serviceReports.map(x=>x.id===id?r:x);else serviceReports.push(r);save();saveServiceReports();closeServiceReport();renderAll();}
function deleteServiceReport(id){if(!id||!confirm("Delete this service report? You can use Undo Last Delete immediately if needed."))return;let item=serviceReports.find(x=>x.id===id);if(!item)return;lastDeleted={type:"serviceReport",item:JSON.parse(JSON.stringify(item))};serviceReports=serviceReports.filter(x=>x.id!==id);saveServiceReports();closeServiceReport();renderAll();}
function renderServiceReports(){let f=document.getElementById("srFrom").value,t=document.getElementById("srTo").value,tech=document.getElementById("srTech").value;let ts=activeTechnicians().map(e=>e.name).sort(),sel=document.getElementById("srTech");if(sel){let old=sel.value;sel.innerHTML='<option value="">All Technicians</option>'+ts.map(x=>`<option>${esc(x)}</option>`).join("");if(ts.includes(old))sel.value=old;tech=sel.value;}let list=serviceReports.filter(r=>(!f||r.date>=f)&&(!t||r.date<=t)&&(!tech||r.tech===tech)).sort((a,b)=>b.date.localeCompare(a.date));document.getElementById("serviceReportsBody").innerHTML=list.map(r=>{let c=customers.find(x=>x.id===r.customerId)||{};return `<tr><td>${esc(r.reportNo)}</td><td>${esc(r.date)}</td><td><b>${esc(c.name||r.customerId)}</b></td><td>${esc(r.address)}</td><td>${esc(r.pest)}</td><td>${esc(r.action)}</td><td>${esc(r.chemical)}</td><td>${esc(r.qty)}</td><td>${esc(r.tech)}</td><td>${esc(r.follow)}</td><td><button class="secondary" onclick="openServiceReport('${esc(r.id)}')">Edit</button> <button class="secondary" onclick="deleteServiceReport('${esc(r.id)}')">Delete</button></td></tr>`}).join("")||`<tr><td colspan="11" class="empty">No service reports</td></tr>`;}
function printServiceReports(){let w=window.open("","_blank");if(!w)return;let body=document.getElementById("serviceReportsBody").closest("table").outerHTML;w.document.write('<html><head><title>Service Reports</title><style>body{font-family:Arial;padding:20px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #999;padding:6px;font-size:11px}</style></head><body><h1>Service Reports</h1>'+body+'</body></html>');w.document.close();w.print();}
function completedCount(from,to){return allVisits().filter(v=>v.date>=from&&v.date<=to).filter(v=>{let p=visitPlans[jobKey(v)]||{};return p.status==='Completed'||p.status==='Closed'}).length;}
function setReportPeriod(){let sel=document.getElementById('grPeriod'),from=document.getElementById('grFrom'),to=document.getElementById('grTo');if(!sel||!from||!to)return;let d=new Date(todayISO+'T00:00:00');if(sel.value==='daily'){from.value=to.value=todayISO;}else if(sel.value==='weekly'){let day=d.getDay();let diff=day===0?-6:1-day;let a=new Date(d);a.setDate(d.getDate()+diff);let b=new Date(a);b.setDate(a.getDate()+6);from.value=a.toISOString().slice(0,10);to.value=b.toISOString().slice(0,10);}else if(sel.value==='monthly'){from.value=todayISO.slice(0,8)+'01';let b=new Date(d.getFullYear(),d.getMonth()+1,0);to.value=b.toISOString().slice(0,10);}}
function generatePeriodReport(){renderGeneralReport();}
function financialTypeOfInvoice(i){
  if(!i)return 'contract';
  if(i.financialType==='daily'||i.financialType==='contract')return i.financialType;
  let src=String(i.source||'').toLowerCase().trim();
  if(src==='daily job'||src==='daily service'||src==='daily')return 'daily';
  return 'contract';
}
function renderGeneralReport(){
 let f=document.getElementById('grFrom').value||todayISO,t=document.getElementById('grTo').value||todayISO,type=document.getElementById('grType').value||'all',ft=document.getElementById('grFinancialType')?.value||'all';
 let vis=allVisits().filter(v=>v.date>=f&&v.date<=t),dailyJobs=jobs.filter(j=>j.date>=f&&j.date<=t),sr=serviceReports.filter(r=>r.date>=f&&r.date<=t);
 let allInv=invoices.filter(i=>i.date>=f&&i.date<=t&&i.status!=='Cancelled');
 let inv=allInv.filter(i=>ft==='all'||financialTypeOfInvoice(i)===ft);
 let payments=inv.reduce((a,i)=>a+Number(i.paid||0),0),sales=inv.reduce((a,i)=>a+Number(i.amount||0),0),balance=inv.reduce((a,i)=>a+Math.max(0,Number(i.amount||0)-Number(i.paid||0)),0),completed=completedCount(f,t);
 let contractInv=allInv.filter(i=>financialTypeOfInvoice(i)==='contract'),dailyInv=allInv.filter(i=>financialTypeOfInvoice(i)==='daily');
 let rows=vis.map(v=>{let p=visitPlans[jobKey(v)]||{};return `<tr><td>${esc(v.date)}</td><td>${esc(v.customerId)}</td><td>${esc(v.name)}</td><td>${v.visitNo}</td><td>${esc(p.status||v.status)}</td><td>${esc(p.actualTreatment||v.lastTreatment||'—')}</td><td>${esc(p.tech||'—')}</td></tr>`}).join('');
 let jobrows=dailyJobs.map(j=>`<tr><td>${esc(j.date)}</td><td>${esc(j.name)}</td><td>${esc(j.phone||'')}</td><td>${esc(j.address||'')}</td><td>${esc(j.pest||'')}</td><td>${esc(j.tech||'—')}</td><td>${esc(j.status||'')}</td></tr>`).join('');
 let invrows=inv.map(i=>{let c=customers.find(c=>c.id===i.customerId),j=jobs.find(j=>j.id===i.jobId),kind=financialTypeOfInvoice(i)==='daily'?'Daily Service':'Contract Service';return `<tr><td>${esc(i.no)}</td><td>${esc(i.date)}</td><td>${esc(kind)}</td><td>${esc(c?.name||j?.name||i.source)}</td><td>${Number(i.amount||0).toFixed(2)}</td><td>${Number(i.paid||0).toFixed(2)}</td><td>${Math.max(0,Number(i.amount||0)-Number(i.paid||0)).toFixed(2)}</td><td>${esc(i.paymentMethod||'—')}</td><td>${esc(i.status)}</td></tr>`}).join('');
 let custrows=customers.map(c=>{let bal=invoices.filter(i=>i.customerId===c.id&&i.status!=='Cancelled').reduce((a,i)=>a+Math.max(0,Number(i.amount||0)-Number(i.paid||0)),0);return `<tr><td>${esc(c.id)}</td><td>${esc(c.name)}</td><td>${esc(c.type)}</td><td>${esc(actualTreatmentForCustomer(c)||'—')}</td><td>${esc(({service:"By Service",monthly:"Every Month",quarterly:"Every 3 Months",semiannual:"Every 6 Months"}[c.billingCycle]||"Every Month"))}</td><td>${bal.toFixed(2)}</td></tr>`}).join('');
 let invitems=inventoryItems.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.active)}</td><td>${esc(x.stock)}</td><td>${esc(x.min)}</td><td>${esc(x.expiry||'—')}</td><td>${esc(inventoryStatus(x)[1])}</td></tr>`).join('');
 let html=`<div class="notice"><b>Financial Report Scope:</b> <b>Daily Service</b> = invoices linked to Daily Jobs. <b>Contract Service</b> = contract invoices. The <b>Financial Type</b> selector controls the financial totals, invoice count, collected amount, invoiced amount, outstanding balance, and invoice details below. It does not alter operational visit counts.</div><div class="grid" style="margin-top:12px"><div class="card"><div class="muted">Period</div><b>${esc(f)} → ${esc(t)}</b></div><div class="card"><div class="muted">Scheduled Visits</div><div class="metric">${vis.length}</div></div><div class="card"><div class="muted">Completed / Closed</div><div class="metric">${completed}</div></div><div class="card"><div class="muted">Daily Jobs</div><div class="metric">${dailyJobs.length}</div></div><div class="card"><div class="muted">Invoices (${ft==='daily'?'Daily Service':ft==='contract'?'Contract Service':'All'})</div><div class="metric">${inv.length}</div></div><div class="card"><div class="muted">Collected</div><div class="metric">${payments.toFixed(2)}</div></div><div class="card"><div class="muted">Invoiced</div><div class="metric">${sales.toFixed(2)}</div></div><div class="card"><div class="muted">Outstanding</div><div class="metric">${balance.toFixed(2)}</div></div><div class="card"><div class="muted">Contract Service Total</div><div class="metric">${contractInv.reduce((a,i)=>a+Number(i.amount||0),0).toFixed(2)}</div></div><div class="card"><div class="muted">Daily Service Total</div><div class="metric">${dailyInv.reduce((a,i)=>a+Number(i.amount||0),0).toFixed(2)}</div></div></div>`;
 if(type==='all'||type==='operations')html+=`<div class="card" style="margin-top:16px"><h3>Contract Visits</h3><div class="tablewrap"><table><thead><tr><th>Date</th><th>ID</th><th>Customer</th><th>Visit</th><th>Status</th><th>Actual</th><th>Technician</th></tr></thead><tbody>${rows||'<tr><td colspan="7" class="empty">No contract visits</td></tr>'}</tbody></table></div></div><div class="card" style="margin-top:16px"><h3>Daily Jobs</h3><div class="tablewrap"><table><thead><tr><th>Date</th><th>Customer</th><th>Phone</th><th>Address</th><th>Pest</th><th>Technician</th><th>Status</th></tr></thead><tbody>${jobrows||'<tr><td colspan="7" class="empty">No daily jobs</td></tr>'}</tbody></table></div></div><div class="card" style="margin-top:16px"><h3>Service Reports</h3><div class="tablewrap"><table><thead><tr><th>No.</th><th>Date</th><th>Customer</th><th>Address</th><th>Pest</th><th>Action</th><th>Chemical</th><th>Qty</th><th>Technician</th></tr></thead><tbody>${sr.map(r=>`<tr><td>${esc(r.reportNo)}</td><td>${esc(r.date)}</td><td>${esc(customers.find(c=>c.id===r.customerId)?.name||r.customerId)}</td><td>${esc(r.address)}</td><td>${esc(r.pest)}</td><td>${esc(r.action)}</td><td>${esc(r.chemical)}</td><td>${esc(r.qty)}</td><td>${esc(r.tech)}</td></tr>`).join('')||'<tr><td colspan="9" class="empty">No service reports</td></tr>'}</tbody></table></div></div>`;
 if(type==='all'||type==='financial')html+=`<div class="card" style="margin-top:16px"><h3>Financial Report — ${ft==='daily'?'Daily Service':ft==='contract'?'Contract Service':'All Types'}</h3><div class="tablewrap"><table><thead><tr><th>Invoice</th><th>Date</th><th>Financial Type</th><th>Customer / Job</th><th>Amount</th><th>Paid</th><th>Balance</th><th>Payment</th><th>Status</th></tr></thead><tbody>${invrows||'<tr><td colspan="9" class="empty">No invoices for the selected financial type</td></tr>'}</tbody></table></div></div>`;
 if(type==='all'||type==='customers')html+=`<div class="card" style="margin-top:16px"><h3>Customers & Contracts</h3><div class="tablewrap"><table><thead><tr><th>ID</th><th>Customer</th><th>Type</th><th>Last Actual Treatment</th><th>Payment Schedule</th><th>Outstanding</th></tr></thead><tbody>${custrows}</tbody></table></div></div>`;
 if(type==='all'||type==='inventory')html+=`<div class="card" style="margin-top:16px"><h3>Inventory Status</h3><div class="tablewrap"><table><thead><tr><th>Pesticide</th><th>Active Ingredient</th><th>Stock</th><th>Min</th><th>Expiry</th><th>Status</th></tr></thead><tbody>${invitems||'<tr><td colspan="6" class="empty">No inventory items</td></tr>'}</tbody></table></div></div>`;
 document.getElementById('generalReportContent').innerHTML=html;
}

function printGeneralReport(){renderGeneralReport();setTimeout(()=>{let w=window.open('','_blank');if(!w)return;w.document.write('<html><head><title>Detailed Report</title><style>body{font-family:Arial;padding:20px}table{border-collapse:collapse;width:100%;margin-bottom:20px}th,td{border:1px solid #999;padding:7px;font-size:11px}h2,h3{margin-bottom:8px}</style></head><body><h1>Detailed Pest Control Report</h1>'+document.getElementById('generalReportContent').innerHTML+'</body></html>');w.document.close();w.print();},50);}
setReportPeriod();
(function initScheduleYear(){let y=document.getElementById("scheduleYear");if(y)y.value=new Date().getFullYear();})();

function deleteCustomer(id){if(!id)return;if(!confirm("Delete this customer and linked scheduled visits/invoices? You can use Undo Last Delete immediately if needed."))return;let c=customers.find(x=>x.id===id);if(!c)return;let plans={};Object.keys(visitPlans).filter(k=>k.startsWith(id+"_")).forEach(k=>plans[k]=visitPlans[k]);let linkedInvoices=invoices.filter(x=>x.customerId===id);let linkedJobs=jobs.filter(x=>x.customerId===id);lastDeleted={type:"customer",item:JSON.parse(JSON.stringify(c)),plans,linkedInvoices,linkedJobs};customers=customers.filter(x=>x.id!==id);Object.keys(visitPlans).forEach(k=>{if(k.startsWith(id+"_"))delete visitPlans[k]});invoices=invoices.filter(x=>x.customerId!==id);jobs=jobs.filter(x=>x.customerId!==id);save();if(typeof saveInvoices==='function')saveInvoices();closeModal();renderAll();}
function populateFinanceCustomers(){let opts=customers.map(c=>`<option value="${esc(c.id)}">${esc(c.name)} (${esc(c.id)})</option>`).join("");let a=document.getElementById("invoiceCustomer"),q=document.getElementById("quotationCustomer");if(a)a.innerHTML='<option value="">Select customer</option>'+opts;if(q)q.innerHTML='<option value="">Select customer</option>'+opts;}
let invoices=JSON.parse(localStorage.getItem("cg_invoices")||"[]");
function saveInvoices(){invoices=dedupeById(invoices);safeSetStorage("cg_invoices",invoices);}
function invoiceNo(){
  let y=new Date().getFullYear();
  let nums=invoices.map(x=>Number(String(x.no||"").split("-").pop())).filter(Number.isFinite);
  return "INV-"+y+"-"+String((nums.length?Math.max(...nums):0)+1).padStart(4,"0");
}
function openInvoice(id){populateFinanceCustomers();let x=invoices.find(a=>a.id===id)||{id:"",date:todayISO,source:"Contract Customer",customerId:customers[0]?.id||"",jobId:"",amount:"",paid:0,paymentMethod:"Cash",due:todayISO,status:"Draft",notes:""};invoiceId.value=x.id;invoiceDate.value=x.date;invoiceSource.value=x.source;invoiceCustomer.value=x.customerId||"";invoiceJob.innerHTML='<option value="">Select daily job</option>'+jobs.map(j=>`<option value="${esc(j.id)}">${esc(j.date)} — ${esc(j.name)}</option>`).join("");invoiceJob.value=x.jobId||"";invoiceAmount.value=x.amount;invoicePaid.value=x.paid||0;invoicePaymentMethod.value=x.paymentMethod||((customers.find(c=>c.id===x.customerId)||{}).paymentMethod)||"Cash";invoiceDue.value=x.due||"";invoiceStatus.value=x.status||"Draft";invoiceNotes.value=x.notes||"";updateInvoiceSource();invoiceModalTitle.textContent=id?"Edit Invoice":"New Invoice";deleteInvoiceBtn.style.display=id?"inline-block":"none";invoiceModal.classList.add("open")}
function openInvoiceForCustomer(customerId){openInvoice();invoiceCustomer.value=customerId;invoiceSource.value="Contract Customer";let c=customers.find(x=>x.id===customerId);invoicePaymentMethod.value="Cash";updateInvoiceSource();}
function updateInvoiceSource(){invoiceCustomer.disabled=invoiceSource.value!=="Contract Customer";invoiceJob.disabled=invoiceSource.value!=="Daily Job"}
function closeInvoice(){invoiceModal.classList.remove("open")}
function saveInvoice(e){e.preventDefault();if(!formSaveOnce(e?.currentTarget))return; let id=invoiceId.value||uniqueId("I",invoices),old=invoices.find(x=>x.id===id),amount=Number(invoiceAmount.value||0),paid=Math.min(amount,Math.max(0,Number(invoicePaid.value||0))),status=invoiceStatus.value;if(amount>0&&paid>=amount&&status!=="Cancelled")status="Paid";else if(paid>0&&status!=="Cancelled")status="Partially Paid";let x={id,no:old?.no||invoiceNo(),date:invoiceDate.value,source:invoiceSource.value,financialType:invoiceSource.value==='Daily Job'?'daily':'contract',customerId:invoiceCustomer.value,jobId:invoiceJob.value,amount,paid,paymentMethod:invoicePaymentMethod.value,due:invoiceDue.value,status,notes:invoiceNotes.value};let i=invoices.findIndex(a=>a.id===id);if(i>=0)invoices[i]=x;else invoices.push(x);save();saveInvoices();closeInvoice();renderAll()}
function deleteInvoice(id){if(!id||!confirm("Delete this invoice?"))return;let item=invoices.find(x=>x.id===id);if(!item)return;if(item.autoKey&&!deletedAutoInvoiceKeys.includes(item.autoKey))deletedAutoInvoiceKeys.push(item.autoKey);invoices=invoices.filter(x=>x.id!==id);saveInvoices();save();closeInvoice();renderInvoices();renderNotifications()}
function renderInvoices(){let q=(document.getElementById("invSearch2").value||"").toLowerCase(),st=document.getElementById("invStatus2").value;let list=invoices.filter(x=>(!st||x.status===st)&&(!q||[x.no,x.id,x.customerId,x.source].join(" ").toLowerCase().includes(q)));document.getElementById("invoicesBody").innerHTML=list.map(x=>{let c=customers.find(a=>a.id===x.customerId),j=jobs.find(a=>a.id===x.jobId),name=c?.name||j?.name||x.source;return `<tr><td>${esc(x.no)}</td><td>${esc(x.date)}</td><td>${esc(x.source)}</td><td>${esc(name||"—")}</td><td>${x.amount.toFixed(2)}</td><td>${Number(x.paid||0).toFixed(2)}</td><td>${Math.max(0,Number(x.amount||0)-Number(x.paid||0)).toFixed(2)}</td><td>${esc(x.paymentMethod||"—")}</td><td>${esc(x.due||"—")}</td><td><span class="badge ${x.status==='Paid'?'ok':x.status==='Cancelled'?'danger':'warn'}">${esc(x.status)}</span></td><td><button class="secondary" onclick="openInvoice('${esc(x.id)}')">Edit</button> <button class="secondary" onclick="deleteInvoice('${esc(x.id)}')">Delete</button></td></tr>`}).join("")||'<tr><td colspan="11" class="empty">No invoices</td></tr>'}
let currentStatementCustomerId="";
function openCustomerStatement(customerId){
 currentStatementCustomerId=customerId||"";
 renderCustomerStatement();
 document.getElementById("statementModal").classList.add("open");
}
function closeCustomerStatement(){document.getElementById("statementModal").classList.remove("open");currentStatementCustomerId="";}
function renderCustomerStatement(){
 let c=customers.find(x=>x.id===currentStatementCustomerId); if(!c)return;
 let customerInvoices=invoices.filter(i=>i.customerId===c.id&&i.status!=="Cancelled").slice().sort((a,b)=>(b.date||"").localeCompare(a.date||""));
 let total=customerInvoices.reduce((a,i)=>a+Number(i.amount||0),0);
 let paid=customerInvoices.reduce((a,i)=>a+Number(i.paid||0),0);
 let balance=Math.max(0,total-paid);
 let visits=allVisits().filter(v=>v.customerId===c.id).sort((a,b)=>(b.date||"").localeCompare(a.date||""));
 let actuals=visits.map(v=>{let pl=visitPlans[jobKey(v)]||{};return {...v,actual:pl.actualTreatment||v.lastTreatment||"",status:pl.status||v.status||"Scheduled",tech:pl.tech||""};});
 let upcoming=actuals.filter(v=>v.date>=todayISO&&v.status!=="Cancelled").slice().sort((a,b)=>a.date.localeCompare(b.date)).slice(0,6);
 let last=actualTreatmentForCustomer(c)||"—";
 document.getElementById("statementTitle").textContent="Customer Statement — "+(c.name||c.id);
 document.getElementById("statementContent").innerHTML=`
 <div class="grid">
  <div class="card"><div class="muted">Customer</div><b>${esc(c.name)}</b><div class="muted">${esc(c.id)} · ${esc(c.type||"")}</div></div>
  <div class="card"><div class="muted">Contract Value</div><div class="metric">${Number(c.value||0).toFixed(2)}</div></div>
  <div class="card"><div class="muted">Invoiced</div><div class="metric">${total.toFixed(2)}</div></div>
  <div class="card"><div class="muted">Paid</div><div class="metric">${paid.toFixed(2)}</div></div>
  <div class="card"><div class="muted">Outstanding</div><div class="metric">${balance.toFixed(2)}</div></div>
 </div>
 <div class="card" style="margin-top:14px"><div class="row"><div><b>Phone</b><div>${esc(c.phone||"—")}</div></div><div><b>Payment Schedule</b><div>${esc(({service:"By Service",monthly:"Every Month",quarterly:"Every 3 Months",semiannual:"Every 6 Months"}[c.billingCycle]||"Every Month"))}</div></div><div><b>Contract Start</b><div>${esc(c.start||"—")}</div></div><div><b>Contract End</b><div>${esc(endDate(c.start)||c.end||"—")}</div></div><div><b>Last Actual Treatment</b><div>${esc(last)}</div></div><div><b>Visits / Frequency</b><div>${esc(String(c.visits||0))} / ${esc(c.frequency||(Number(c.visits)===24?"15 Days":Number(c.visits)===12?"Monthly":"Manual"))}</div></div></div></div>
 <div class="card" style="margin-top:14px"><h3>Invoices & Payments</h3><div class="tablewrap"><table><thead><tr><th>Invoice</th><th>Date</th><th>Amount</th><th>Paid</th><th>Balance</th><th>Payment</th><th>Due</th><th>Status</th></tr></thead><tbody>${customerInvoices.map(i=>`<tr><td>${esc(i.no)}</td><td>${esc(i.date)}</td><td>${Number(i.amount||0).toFixed(2)}</td><td>${Number(i.paid||0).toFixed(2)}</td><td>${Math.max(0,Number(i.amount||0)-Number(i.paid||0)).toFixed(2)}</td><td>${esc(i.paymentMethod||"—")}</td><td>${esc(i.due||"—")}</td><td>${esc(i.status||"—")}</td></tr>`).join("")||'<tr><td colspan="8" class="empty">No invoices recorded</td></tr>'}</tbody></table></div></div>
 <div class="card" style="margin-top:14px"><h3>Visit History</h3><div class="tablewrap"><table><thead><tr><th>Planned Date</th><th>Visit</th><th>Actual Treatment</th><th>Status</th><th>Technician</th></tr></thead><tbody>${actuals.map(v=>`<tr><td>${esc(v.date)}</td><td>${esc(v.visitNo)}</td><td>${esc(v.actual||"—")}</td><td>${esc(v.status)}</td><td>${esc(v.tech||"—")}</td></tr>`).join("")||'<tr><td colspan="5" class="empty">No visits recorded</td></tr>'}</tbody></table></div></div>
 <div class="card" style="margin-top:14px"><h3>Upcoming Visits</h3><div class="tablewrap"><table><thead><tr><th>Date</th><th>Visit</th><th>Status</th><th>Technician</th></tr></thead><tbody>${upcoming.map(v=>`<tr><td>${esc(v.date)}</td><td>${esc(v.visitNo)}</td><td>${esc(v.status)}</td><td>${esc(v.tech||"—")}</td></tr>`).join("")||'<tr><td colspan="4" class="empty">No upcoming visits</td></tr>'}</tbody></table></div></div>`;
}
function printCustomerStatement(){
 renderCustomerStatement();
 let c=customers.find(x=>x.id===currentStatementCustomerId);if(!c)return;
 let w=window.open("","_blank");if(!w)return;
 w.document.write('<html><head><title>Customer Statement</title><style>body{font-family:Arial;padding:20px;color:#172033}table{border-collapse:collapse;width:100%;margin:12px 0 22px}th,td{border:1px solid #bbb;padding:7px;font-size:11px;text-align:left}th{background:#f1f5f9}.grid{display:flex;gap:10px;flex-wrap:wrap}.card{border:1px solid #ddd;border-radius:8px;padding:12px;margin:6px 0;flex:1;min-width:150px}.muted{color:#667085}</style></head><body><h1>Customer Statement</h1><h2>'+esc(c.name)+'</h2>'+document.getElementById("statementContent").innerHTML+'</body></html>');w.document.close();w.print();
}
function companyContactHtml(){return [companySettings.address,companySettings.branch&&("Branch: "+companySettings.branch),companySettings.authority&&("Authority: "+companySettings.authority),companySettings.licenseNo&&("Trade License No.: "+companySettings.licenseNo),companySettings.licenseExpiry&&("License Expiry: "+companySettings.licenseExpiry),companySettings.phone1&&("Tel: "+companySettings.phone1),companySettings.phone2&&("Tel: "+companySettings.phone2),companySettings.email&&("Email: "+companySettings.email),companySettings.website,companySettings.adminContact&&("Admin Contact: "+companySettings.adminContact),companySettings.emergency&&("Emergency: "+companySettings.emergency)].filter(Boolean).map(x=>`<div>${esc(x)}</div>`).join("")}
function openPrintWindow(title,body){let w=window.open("","_blank");if(!w){alert("Please allow pop-ups to print.");return;}w.document.write(`<html><head><title>${esc(title)}</title><style>body{font-family:Arial,sans-serif;color:#172033;padding:24px}.print-sheet{max-width:900px;margin:auto}.print-head{display:flex;justify-content:space-between;gap:20px;border-bottom:3px solid #0b5cab;padding-bottom:16px}.print-company{font-size:22px;font-weight:800;color:#0b5cab}.print-title{font-size:25px;font-weight:800;text-align:right}.print-meta{font-size:12px;color:#667085;margin-top:4px}.print-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:18px 0}.print-box{border:1px solid #dbe2ea;border-radius:8px;padding:12px}.print-box h4{margin:0 0 7px;color:#0b5cab}.print-table{width:100%;border-collapse:collapse;margin-top:16px}.print-table th,.print-table td{border:1px solid #dbe2ea;padding:9px;text-align:left}.print-table th{background:#f1f5f9}.print-total{margin-left:auto;width:330px;margin-top:16px}.print-total div{display:flex;justify-content:space-between;padding:6px 0}.print-grand{font-size:18px;font-weight:800;border-top:2px solid #172033;margin-top:5px}.print-foot{border-top:1px solid #dbe2ea;margin-top:24px;padding-top:12px;font-size:11px;color:#667085}</style></head><body>${body}</body></html>`);w.document.close();setTimeout(()=>w.print(),150);}
function invoicePrintHtml(x){let c=customers.find(a=>a.id===x.customerId),j=jobs.find(a=>a.id===x.jobId),name=c?.name||j?.name||"Customer",phone=c?.phone||j?.phone||"",sub=Number(x.amount||0),vat=sub*(Number(companySettings.vat||0)/100),total=sub+vat;return `<div class="print-sheet"><div class="print-head"><div><div class="print-company">${esc(companySettings.name||"Company")}</div>${companyContactHtml()}${companySettings.trn?`<div class="print-meta">TRN: ${esc(companySettings.trn)}</div>`:""}</div><div><div class="print-title">TAX INVOICE</div><div class="print-meta">Invoice #: <b>${esc(x.no)}</b></div><div class="print-meta">Date: <b>${esc(x.date)}</b></div></div></div><div class="print-grid"><div class="print-box"><h4>TO</h4><b>${esc(name)}</b><div>${esc(c?.area||j?.address||"")}</div>${phone?`<div>Phone: ${esc(phone)}</div>`:""}${c?.id?`<div>Customer ID: ${esc(c.id)}</div>`:""}</div><div class="print-box"><h4>TERMS</h4><div>${esc(companySettings.terms||"Due Upon Receipt")}</div><div>Due Date: ${esc(x.due||x.date||"")}</div></div></div><table class="print-table"><thead><tr><th>Description</th><th>Qty</th><th>Unit Price (AED)</th><th>Amount (AED)</th></tr></thead><tbody><tr><td>${esc(x.source==="Daily Job"&&j?.pest?`PEST CONTROL TREATMENT — ${j.pest}`:"PEST CONTROL TREATMENT")}</td><td>1</td><td>${sub.toFixed(2)}</td><td>${sub.toFixed(2)}</td></tr></tbody></table><div class="print-total"><div><span>SUBTOTAL</span><b>AED ${sub.toFixed(2)}</b></div><div><span>VAT (${Number(companySettings.vat||0).toFixed(2)}%)</span><b>AED ${vat.toFixed(2)}</b></div><div class="print-grand"><span>TOTAL</span><b>AED ${total.toFixed(2)}</b></div></div>${x.notes?`<div class="print-box" style="margin-top:20px"><h4>Notes</h4><div>${esc(x.notes)}</div></div>`:""}<div class="print-foot">${esc(companySettings.footer||"Thank you for your business!")}<br>${companySettings.phone1?`Contact: ${esc(companySettings.phone1)}`:""}${companySettings.adminContact?`<br>Administrative Contact: ${esc(companySettings.adminContact)}`:""}${companySettings.emergency?`<br>Emergency Contact: ${esc(companySettings.emergency)}`:""}</div></div>`}
function printInvoice(id){let x=invoices.find(a=>a.id===id);if(x)openPrintWindow("Tax Invoice "+x.no,invoicePrintHtml(x));}
function printInvoices(){let x=invoices.slice().sort((a,b)=>(b.date||"").localeCompare(a.date||""))[0];if(x)printInvoice(x.id);else alert("No invoices to print.");}
let quotations=JSON.parse(localStorage.getItem("cg_quotations")||"[]");
function saveQuotations(){quotations=dedupeById(quotations);safeSetStorage("cg_quotations",quotations)}
function quotationNo(){let y=new Date().getFullYear(),nums=quotations.map(q=>Number(String(q.no||"").split("-").pop())).filter(Number.isFinite);return "QT-"+y+"-"+String((nums.length?Math.max(...nums):0)+1).padStart(4,"0")}
function quotationVatRate(x){return Number(x?.vatRate ?? companySettings.vat ?? 5)||0}
function updateQuotationTotals(){let sub=Number(document.getElementById("quotationAmount")?.value||0),rate=Number(document.getElementById("quotationVat")?.value||5),vat=sub*rate/100,total=sub+vat,box=document.getElementById("quotationTotalsPreview");if(box)box.innerHTML=`<div class="print-total" style="width:100%;max-width:420px;margin-left:auto"><div><span>SUBTOTAL</span><b>AED ${sub.toFixed(2)}</b></div><div><span>VAT (${rate.toFixed(2)}%)</span><b>AED ${vat.toFixed(2)}</b></div><div class="print-grand"><span>TOTAL</span><b>AED ${total.toFixed(2)}</b></div></div>`}
function quotationCustomerChanged(){let id=document.getElementById("quotationCustomer")?.value,c=customers.find(x=>x.id===id);if(!c)return;quotationCustomerName.value=c.name||"";quotationPhone.value=c.phone||"";quotationContact.value=c.contact||"";quotationAddress.value=c.area||"";quotationProperty.value=c.type||"";}
function quotationTypeChanged(){let annual=quotationType.value==="annual";quotationService.value=annual?"Annual Pest Control Contract – 12 Months":"Pest Control Treatment – One-Time Service"}
function openQuotation(id){populateFinanceCustomers();let x=quotations.find(a=>a.id===id)||{id:"",no:"",date:todayISO,customerId:"",customerName:"",phone:"",contact:"",property:"",pest:"",address:"",project:"",type:"one_time",service:"Pest Control Treatment – One-Time Service",scope:"",qty:1,amount:"",vatRate:Number(companySettings.vat??5),terms:companySettings.terms||"To be discussed",validity:companySettings.quoteValidity||"30 Days",status:"Draft",notes:""};
quotationId.value=x.id;quotationDate.value=x.date||todayISO;quotationType.value=x.type||"one_time";quotationCustomer.value=x.customerId||"";quotationCustomerName.value=x.customerName||customers.find(c=>c.id===x.customerId)?.name||"";quotationPhone.value=x.phone||customers.find(c=>c.id===x.customerId)?.phone||"";quotationContact.value=x.contact||customers.find(c=>c.id===x.customerId)?.contact||"";quotationProperty.value=x.property||"";quotationPest.value=x.pest||"";quotationAddress.value=x.address||customers.find(c=>c.id===x.customerId)?.area||"";quotationProject.value=x.project||"";quotationService.value=x.service||"";quotationScope.value=x.scope||"";quotationQty.value=x.qty||1;quotationAmount.value=x.amount??"";quotationVat.value=quotationVatRate(x);quotationTerms.value=x.terms||companySettings.terms||"To be discussed";quotationValidity.value=x.validity||companySettings.quoteValidity||"30 Days";quotationStatus.value=x.status||"Draft";quotationNotes.value=x.notes||"";quotationModalTitle.textContent=id?`Edit Quotation ${x.no||""}`:"New Quotation";deleteQuotationBtn.style.display=id?"inline-block":"none";quotationModal.classList.add("open");updateQuotationTotals()}
function closeQuotation(){quotationModal.classList.remove("open")}
function saveQuotation(e){e.preventDefault();if(!formSaveOnce(e?.currentTarget))return; let id=quotationId.value||uniqueId("Q",quotations),old=quotations.find(x=>x.id===id),x={...old,id,no:old?.no||quotationNo(),date:quotationDate.value,type:quotationType.value,customerId:quotationCustomer.value||"",customerName:quotationCustomerName.value.trim(),phone:quotationPhone.value.trim(),contact:quotationContact.value.trim(),property:quotationProperty.value.trim(),pest:quotationPest.value.trim(),address:quotationAddress.value.trim(),project:quotationProject.value.trim(),service:quotationService.value.trim(),scope:quotationScope.value.trim(),qty:Number(quotationQty.value||1),amount:Number(quotationAmount.value||0),vatRate:Number(quotationVat.value||5),terms:quotationTerms.value.trim(),validity:quotationValidity.value.trim(),status:quotationStatus.value,notes:quotationNotes.value.trim()};let i=quotations.findIndex(a=>a.id===id);if(i>=0)quotations[i]=x;else quotations.push(x);saveQuotations();closeQuotation();renderQuotations()}
function deleteQuotation(id){if(!id||!confirm("Delete this quotation? You can use Undo Last Delete immediately if needed."))return;let item=quotations.find(x=>x.id===id);if(!item)return;lastDeleted={type:"quotation",item:JSON.parse(JSON.stringify(item))};quotations=quotations.filter(x=>x.id!==id);saveQuotations();closeQuotation();renderQuotations()}
function renderQuotations(){document.getElementById("quotationsBody").innerHTML=quotations.slice().sort((a,b)=>(b.date||"").localeCompare(a.date||"")).map(x=>{let name=x.customerName||customers.find(a=>a.id===x.customerId)?.name||x.customerId||"—",sub=Number(x.amount||0),vat=sub*quotationVatRate(x)/100,total=sub+vat;return `<tr><td>${esc(x.no)}</td><td>${esc(x.date)}</td><td><b>${esc(name)}</b><div class="muted">${esc(x.type==="annual"?"Annual Contract":"One-Time Service")}</div></td><td>${esc(x.service)}</td><td>AED ${sub.toFixed(2)}<div class="muted">VAT ${vat.toFixed(2)} · Total ${total.toFixed(2)}</div></td><td><span class="badge ${x.status==='Accepted'?'ok':x.status==='Rejected'?'warn':''}">${esc(x.status)}</span></td><td><button class="secondary" onclick="openQuotation('${esc(x.id)}')">Edit</button> <button class="secondary" onclick="printQuotation('${esc(x.id)}')">Print</button> <button class="danger" onclick="deleteQuotation('${esc(x.id)}')">Delete</button>${x.status==='Accepted'?(x.type==='annual'?` <button class="primary" onclick="convertQuotationToContract('${esc(x.id)}')">Create Contract</button>`:` <button class="primary" onclick="convertQuotationToDailyJob('${esc(x.id)}')">Create Daily Job</button>`):''}</td></tr>`}).join("")||'<tr><td colspan="7" class="empty">No quotations</td></tr>'}
function quotationPrintHtml(x){let name=x.customerName||customers.find(a=>a.id===x.customerId)?.name||"Customer",phone=x.phone||customers.find(a=>a.id===x.customerId)?.phone||"",sub=Number(x.amount||0),rate=quotationVatRate(x),vat=sub*rate/100,total=sub+vat,desc=x.service||"Pest Control Service",scope=x.scope||"Inspection, treatment and prevention as required at the inspected premises.",qty=Number(x.qty||1);return `<div class="print-sheet"><div class="print-head"><div><div class="print-company">${esc(companySettings.name||"Company")}</div>${companyContactHtml()}${companySettings.trn?`<div class="print-meta">TRN: ${esc(companySettings.trn)}</div>`:""}</div><div><div class="print-title">QUOTATION</div><div class="print-meta">Quotation #: <b>${esc(x.no)}</b></div><div class="print-meta">Date: <b>${esc(x.date)}</b></div><div class="print-meta">Valid Until: <b>${esc(x.validity||companySettings.quoteValidity||"30 Days")}</b></div></div></div><div class="print-grid"><div class="print-box"><h4>TO</h4><b>${esc(name)}</b>${x.project?`<div>Project: ${esc(x.project)}</div>`:""}${x.address?`<div>Site: ${esc(x.address)}</div>`:""}${phone?`<div>Phone: ${esc(phone)}</div>`:""}${x.contact?`<div>Contact: ${esc(x.contact)}</div>`:""}${x.property?`<div>Property: ${esc(x.property)}</div>`:""}${x.pest?`<div>Pest: ${esc(x.pest)}</div>`:""}</div><div class="print-box"><h4>QUOTATION TYPE</h4><b>${esc(x.type==="annual"?"Annual Contract – 12 Months":"One-Time Service")}</b><div style="margin-top:6px">Payment Terms: ${esc(x.terms||"To be discussed")}</div></div></div><table class="print-table"><thead><tr><th>Description</th><th>Qty</th><th>Unit Price (AED)</th><th>Amount (AED)</th></tr></thead><tbody><tr><td>${esc(desc)}</td><td>${qty}</td><td>${sub.toFixed(2)}</td><td>${(sub*qty).toFixed(2)}</td></tr></tbody></table><div class="print-box" style="margin-top:18px"><h4>SCOPE OF WORK</h4><div style="white-space:pre-line;line-height:1.6">${esc(scope)}</div></div><div class="print-total"><div><span>SUBTOTAL</span><b>AED ${sub.toFixed(2)}</b></div><div><span>VAT (${rate.toFixed(2)}%)</span><b>AED ${vat.toFixed(2)}</b></div><div class="print-grand"><span>TOTAL DUE</span><b>AED ${total.toFixed(2)}</b></div></div>${x.notes?`<div class="print-box" style="margin-top:18px"><h4>TERMS & CONDITIONS / NOTES</h4><div style="white-space:pre-line;line-height:1.6">${esc(x.notes)}</div></div>`:""}<div class="print-foot">${esc(companySettings.footer||"Thank you for your business!")}<br>${companySettings.phone1?`Contact: ${esc(companySettings.phone1)}`:""}${companySettings.adminContact?`<br>Administrative Contact: ${esc(companySettings.adminContact)}`:""}${companySettings.emergency?`<br>Emergency Contact: ${esc(companySettings.emergency)}`:""}</div></div>`}
function printQuotation(id){let x=quotations.find(a=>a.id===id);if(x)openPrintWindow("Quotation "+x.no,quotationPrintHtml(x))}
function printQuotations(){let x=quotations.slice().sort((a,b)=>(b.date||"").localeCompare(a.date||""))[0];if(x)printQuotation(x.id);else alert("No quotations to print.")}
function convertQuotationToDailyJob(id){let q=quotations.find(x=>x.id===id);if(!q||q.status!=="Accepted")return;let j={id:"J"+Date.now(),name:q.customerName,phone:q.phone,date:todayISO,time:"",duration:60,address:q.address,pest:q.pest,property:q.property||"Apartment",rooms:"",tech:"",status:"New",follow:"",notes:`Quotation ${q.no}. ${q.scope||q.notes||""}`,source:"Daily Job",quotationId:q.id,quotedAmount:Number(q.amount||0),vatRate:quotationVatRate(q)};jobs.push(j);save();renderAll();alert("Accepted quotation converted to a Daily Job.")}
function convertQuotationToContract(id){let q=quotations.find(x=>x.id===id);if(!q||q.status!=="Accepted")return;let start=prompt("Enter contract start date (YYYY-MM-DD):",q.date||todayISO);if(!start)return;if(!/^\d{4}-\d{2}-\d{2}$/.test(start)){alert("Please enter the date as YYYY-MM-DD.");return}let visits=Number(prompt("Enter number of services/visits per year:","12"));if(!Number.isInteger(visits)||visits<1||visits>60){alert("Please enter a valid number from 1 to 60.");return}let firstVisit=prompt("Enter first visit date (YYYY-MM-DD):",start);if(!/^\d{4}-\d{2}-\d{2}$/.test(firstVisit||"")){alert("Please enter the first visit date as YYYY-MM-DD.");return}let num=Math.max(0,...customers.map(c=>parseInt(String(c.id||"").replace(/\D/g,""))||0))+1,c={id:"C"+String(num).padStart(3,"0"),name:q.customerName,type:q.property||"OTHER",area:q.address,contact:q.contact,phone:q.phone,start,end:endDate(start),visits,frequency:visits===24?"15 Days":visits===12?"Monthly":"Manual",firstVisit,value:Number(q.amount||0),billingCycle:"monthly",paymentMethod:"Cash",notes:`Created from quotation ${q.no}. ${q.scope||q.notes||""}`};customers.push(c);q.convertedCustomerId=c.id;q.convertedAt=new Date().toISOString();save();saveQuotations();renderAll();alert("Accepted quotation converted to an Annual Contract.")}

function billingConfig(c){
  let cycle=c.billingCycle||"monthly", visits=Number(c.visits)||0, value=Number(c.value||0);
  if(cycle==="service") return {cycle,label:"By Service",amount:visits?value/visits:0,dates:allVisits().filter(v=>v.customerId===c.id).map(v=>v.date)};
  let months=cycle==="quarterly"?3:cycle==="semiannual"?6:1;
  return {cycle,label:months===1?"Every Month":months===3?"Every 3 Months":"Every 6 Months",amount:(value/12)*months,months,dates:[]};
}
function autoBillingDates(c){
  let cfg=billingConfig(c), dates=[];
  if(!c.start) return dates;
  if(cfg.cycle==="service") return cfg.dates;
  for(let m=0;m<12;m+=cfg.months) dates.push(addMonths(c.start,m));
  return dates.filter(d=>!c.end||d<=c.end);
}
function ensureAutoInvoices(){
  let changed=false;
  customers.forEach(c=>{
    if(!c.value||!c.start) return;
    let cfg=billingConfig(c), dates=autoBillingDates(c);
    dates.forEach((due,n)=>{
      let key=`AUTO-${c.id}-${due}-${cfg.cycle}`;
      let exists=invoices.some(i=>i.autoKey===key);
      if(!exists && !deletedAutoInvoiceKeys.includes(key)){
        invoices.push({id:uniqueId("AI",invoices),no:invoiceNo(),date:due,source:"Contract Customer",financialType:"contract",customerId:c.id,jobId:"",amount:Number(cfg.amount.toFixed(2)),paid:0,paymentMethod:c.paymentMethod||"Cash",due,status:"Issued",notes:"Automatic invoice - "+cfg.label,autoKey:key});
        changed=true;
      }
    });
  });
  if(changed) saveInvoices();
}
function dismissNotification(key){
 if(!key)return;
 if(!dismissedNotificationKeys.includes(key))dismissedNotificationKeys.push(key);
 localStorage.setItem("cg_dismissed_notifications",JSON.stringify(dismissedNotificationKeys));
 renderNotifications();
}
function clearNotifications(){
 let box=document.getElementById("notificationsContent");
 if(!box)return;
 let keys=[...box.querySelectorAll("[data-notification-key]")].map(x=>x.getAttribute("data-notification-key")).filter(Boolean);
 if(!keys.length){box.innerHTML='<div class="empty">No notifications</div>';return;}
 if(!confirm("Clear the current notifications? They will stay cleared until their underlying data changes."))return;
 keys.forEach(k=>{if(!dismissedNotificationKeys.includes(k))dismissedNotificationKeys.push(k)});
 localStorage.setItem("cg_dismissed_notifications",JSON.stringify(dismissedNotificationKeys));
 renderNotifications();
}
function notificationCard(key,title,body,muted=""){
 if(dismissedNotificationKeys.includes(key))return "";
 return `<div class="card" data-notification-key="${esc(key)}"><div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start"><div><b>${esc(title)}</b><div>${body}</div>${muted?`<div class="muted">${muted}</div>`:""}</div><button class="secondary" type="button" onclick="dismissNotification('${esc(key)}')">Dismiss</button></div></div>`;
}
function renderNotifications(){
 let today=todayISO,items=[];
 invoices.forEach(x=>{
   let balance=Math.max(0,Number(x.amount||0)-Number(x.paid||0));
   if(x.status!=="Paid"&&x.status!=="Cancelled"&&balance>0&&x.due&&x.due<=today){
     let c=customers.find(a=>a.id===x.customerId);
     let key=`payment:${x.id}:${x.due}:${balance.toFixed(2)}`;
     items.push(notificationCard(key,"Payment Notification",`${esc(c?.name||x.customerId||"Customer")} — ${x.due<today?'Payment overdue':'Payment due today'} — <strong>${balance.toFixed(2)}</strong>`,`${esc(x.notes||"")} · Invoice ${esc(x.no)}`));
   }
 });
 invoices.filter(x=>x.source==='Daily Job' && (x.date===today || x.due===today) && x.status!=='Cancelled').forEach(x=>{
   let j=jobs.find(a=>a.id===x.jobId), key=`daily-invoice:${x.id}:${x.date}:${x.due||''}:${x.status}`;
   items.push(notificationCard(key,'Daily Job Invoice',`${esc(j?.name||x.customerId||'Daily Job')} — Invoice ${esc(x.no)} — <strong>${Number(x.amount||0).toFixed(2)}</strong>`,`${x.due===today?'Payment due today':'Invoice created today'}`));
 });
 jobs.filter(j=>(j.date===today||j.follow===today)&&j.status!=="Completed"&&j.status!=="Closed"&&j.status!=="Cancelled").forEach(j=>{
   let key=`daily-job:${j.id}:${j.date}:${j.follow||""}:${j.status}`;
   items.push(notificationCard(key,"Daily Job",`${esc(j.name)} — ${esc(j.phone||"")} — ${esc(j.address||"")}`));
 });
 allVisits().filter(v=>v.date===today&&v.status!=="Completed"&&v.status!=="Closed"&&v.status!=="Cancelled").forEach(v=>{
   let key=`contract-visit:${v.customerId}:${v.visitNo}:${v.date}`;
   items.push(notificationCard(key,"Contract Visit",`${esc(v.name)} — scheduled today.`));
 });
 inventoryItems.forEach(x=>{
   let st=inventoryStatus(x)[0];
   if(st==='low'||st==='expired'||st==='soon'){
     let key=`inventory:${x.id}:${st}:${x.stock}:${x.expiry||""}`;
     items.push(notificationCard(key,"Inventory",`${esc(x.name)} — ${esc(inventoryStatus(x)[1])}`));
   }
 });
 let visible=items.filter(Boolean).join("");
 document.getElementById("notificationsContent").innerHTML=(visible?`<div class="toolbar" style="justify-content:flex-end"><button class="secondary" type="button" onclick="clearNotifications()">Dismiss Current Notifications</button></div>`+visible:'<div class="empty">No notifications</div>');
}

function undoLastDelete(){
  if(!lastDeleted){alert("There is no recent deletion to undo.");return;}
  let x=lastDeleted;
  if(x.type==="customer"){customers.push(x.item);Object.assign(visitPlans,x.plans||{});invoices.push(...(x.linkedInvoices||[]));jobs.push(...(x.linkedJobs||[]));save();saveInvoices();}
  else if(x.type==="customers"){customers.push(...x.items);Object.assign(visitPlans,x.plans||{});invoices.push(...(x.linkedInvoices||[]));jobs.push(...(x.linkedJobs||[]));save();saveInvoices();}
  else if(x.type==="job"){jobs.push(x.item);save();}
  else if(x.type==="employee"){employees.push(x.item);saveEmployees();}
  else if(x.type==="inventory"){inventoryItems.push(x.item);inventoryMovements.push(...(x.movements||[]));saveInventory();}
  else if(x.type==="serviceReport"){serviceReports.push(x.item);saveServiceReports();}
  else if(x.type==="quotation"){quotations.push(x.item);saveQuotations();}
  else {alert("This deletion cannot be undone.");return;}
  lastDeleted=null;let b=document.getElementById("backupStatus");if(b)b.textContent="Last deletion restored successfully.";renderAll();
}
function backupPayload(){return {version:5,createdAt:new Date().toISOString(),companySettings,customers,jobs,visitPlans,deletedAutoInvoiceKeys,dismissedNotificationKeys,employees,inventoryItems,inventoryMovements,serviceReports,invoices,quotations};}
function exportBackup(){let blob=new Blob([JSON.stringify(backupPayload(),null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="CG_System_Backup_"+todayISO+".json";a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);let b=document.getElementById("backupStatus");if(b)b.textContent="Backup exported successfully: "+new Date().toLocaleString();}
function clearAllLocalData(){
 if(!confirm("This will permanently remove all customers, jobs, scheduled visits, employees, inventory, service reports, invoices, quotations and company information stored on this device. Continue?"))return;
 ["cg_customers","cg_daily_jobs","cg_visit_plans","cg_employees","cg_inventory_items","cg_inventory_movements","cg_service_reports","cg_invoices","cg_quotations","cg_company_settings","cg_deleted_auto_invoice_keys","cg_dismissed_notifications"].forEach(k=>localStorage.removeItem(k));
 location.reload();
}
function importBackup(e){let file=e.target.files&&e.target.files[0];if(!file)return;let r=new FileReader();r.onload=function(){try{let d=JSON.parse(r.result);if(!d||!Array.isArray(d.customers)||!Array.isArray(d.jobs)||!d.visitPlans)throw new Error("Invalid backup");if(!confirm("Restore this backup? Current data on this device will be replaced."))return;companySettings=d.companySettings||companySettings;localStorage.setItem("cg_company_settings",JSON.stringify(companySettings));customers=d.customers;jobs=d.jobs;visitPlans=d.visitPlans;deletedAutoInvoiceKeys=Array.isArray(d.deletedAutoInvoiceKeys)?d.deletedAutoInvoiceKeys:[];dismissedNotificationKeys=Array.isArray(d.dismissedNotificationKeys)?d.dismissedNotificationKeys:[];employees=d.employees||[];inventoryItems=d.inventoryItems||[];inventoryMovements=d.inventoryMovements||[];serviceReports=d.serviceReports||[];invoices=d.invoices||[];quotations=d.quotations||[];save();if(typeof saveEmployees==='function')saveEmployees();if(typeof saveInventory==='function')saveInventory();if(typeof saveServiceReports==='function')saveServiceReports();if(typeof saveInvoices==='function')saveInvoices();if(typeof saveQuotations==='function')saveQuotations();localStorage.setItem("cg_deleted_auto_invoice_keys",JSON.stringify(deletedAutoInvoiceKeys));localStorage.setItem("cg_dismissed_notifications",JSON.stringify(dismissedNotificationKeys));let b=document.getElementById("backupStatus");if(b)b.textContent="Backup restored successfully: "+new Date().toLocaleString();renderAll();}catch(err){alert("Could not restore backup: "+err.message)}};r.readAsText(file);e.target.value="";}
document.addEventListener("input",e=>{if(e.target&&["quotationAmount","quotationVat"].includes(e.target.id))updateQuotationTotals()});
document.addEventListener("change",e=>{if(e.target&&e.target.id==="quotationCustomer")quotationCustomerChanged();if(e.target&&e.target.id==="quotationType")quotationTypeChanged()});
saveCollectionsClean();
const appSettings=JSON.parse(localStorage.getItem('cg_app_settings')||'null')||{language:'ar',theme:'light',notifications:true};
const I18N={
  ar:{'Dashboard':'لوحة التحكم','Customers':'العملاء','Daily Schedule':'الجدول اليومي','Daily Jobs':'الجوبات اليومية','Employees & Technicians':'الموظفون والفنيون','Pesticides & Inventory':'المبيدات والمخزون','Visit Schedule':'جدول الزيارات','Contract Expiry':'انتهاء العقود','Service Reports':'تقارير الخدمة','General Report':'التقرير العام','Invoices':'الفواتير','Quotations':'الكوتيشن','Notifications':'الإشعارات','Data & Backup':'البيانات والنسخ الاحتياطي','Settings':'الضبط','Language':'اللغة','Appearance':'المظهر','Light':'فاتح','Dark':'داكن','System':'النظام','Save Now':'حفظ الآن','Refresh Application':'تحديث التطبيق','Exit Application':'خروج من التطبيق','About':'حول التطبيق','Application Actions':'إجراءات التطبيق','Data Protection':'حماية البيانات','Backup & Restore':'النسخ الاحتياطي والاستعادة','Company Information':'بيانات الشركة','Enable notifications':'تفعيل الإشعارات','Enable device notifications':'تفعيل إشعارات الجهاز','Choose the application language':'اختر لغة التطبيق','Choose light or dark appearance':'اختر مظهر التطبيق','Control in-app payment, visit, daily job and inventory alerts':'التحكم في تنبيهات الفواتير والزيارات والجوبات والمخزون','Data is stored locally on this device. Use Backup before changing phones.':'البيانات محفوظة محليًا على هذا الجهاز. استخدم النسخ الاحتياطي قبل تغيير الهاتف.','Version 5.0 · Offline-first · Local device storage':'الإصدار 5.0 · يعمل دون إنترنت · تخزين محلي على الجهاز'},
  en:{}};
I18N.en=Object.fromEntries(Object.entries(I18N.ar).map(([k,v])=>[k,k]));
function applyLanguage(){
  const lang=appSettings.language==='en'?'en':'ar'; document.documentElement.lang=lang; document.documentElement.dir=lang==='ar'?'rtl':'ltr';
  const map=I18N[lang];
  document.querySelectorAll('[data-i18n]').forEach(el=>{const k=el.getAttribute('data-i18n');if(map[k])el.textContent=map[k];});
  document.querySelectorAll('#nav button').forEach(b=>{const raw=b.dataset.view==='settings'?'Settings':(b.dataset.view==='dashboard'?'Dashboard':b.dataset.view==='customers'?'Customers':b.dataset.view==='daily'?'Daily Schedule':b.dataset.view==='jobs'?'Daily Jobs':b.dataset.view==='employees'?'Employees & Technicians':b.dataset.view==='inventory'?'Pesticides & Inventory':b.dataset.view==='schedule'?'Visit Schedule':b.dataset.view==='expiry'?'Contract Expiry':b.dataset.view==='serviceReports'?'Service Reports':b.dataset.view==='generalReports'?'General Report':b.dataset.view==='invoices'?'Invoices':b.dataset.view==='quotations'?'Quotations':b.dataset.view==='notifications'?'Notifications':'Data & Backup'); b.textContent=map[raw]||raw;});
  document.getElementById('appLanguage').value=lang;document.getElementById('appTheme').value=appSettings.theme||'light';document.getElementById('notifyEnabled').checked=appSettings.notifications!==false;
  const extra={ar:{'↻ تحديث':'↻ تحديث','💾 حفظ':'💾 حفظ','⏻ خروج':'⏻ خروج','Dashboard':'لوحة التحكم','Customers':'العملاء','Daily Schedule & Daily Visit Report':'الجدول اليومي وتقرير الزيارات',"Today's Visits":'زيارات اليوم','Daily Schedule':'الجدول اليومي','Daily Jobs':'الجوبات اليومية','Employees & Technicians':'الموظفون والفنيون','Pesticides & Inventory':'المبيدات والمخزون','Visit Schedule':'جدول الزيارات','Contract Expiry':'انتهاء العقود','Service Reports':'تقارير الخدمة','Reports':'التقارير','Invoices':'الفواتير','Quotations':'الكوتيشن','Notifications':'الإشعارات','Data & Backup':'البيانات والنسخ الاحتياطي','Date':'التاريخ','Search':'بحث','Technician':'الفني','Status':'الحالة','Customer':'العميل','Address':'العنوان','Pest':'الآفة','Property':'نوع العقار','Phone':'الهاتف','Amount':'المبلغ','Paid Amount':'المبلغ المدفوع','Due Date':'تاريخ الاستحقاق','Payment Method':'طريقة الدفع','Save':'حفظ','Cancel':'إلغاء','Delete':'حذف','Edit':'تعديل','Print / Save PDF':'طباعة / حفظ PDF','Print / Save Daily Report':'طباعة / حفظ تقرير اليوم','New':'جديد','Scheduled':'مجدول','Assigned':'مسند','In Progress':'قيد التنفيذ','Completed':'مكتمل','Follow-up':'متابعة','Postponed':'مؤجل','Closed':'مغلق','Cancelled':'ملغى','Cost (AED)':'التكلفة (درهم)','New Daily Job':'جوبة يومية جديدة','Save Job':'حفظ الجوبة','New Invoice':'فاتورة جديدة','New Quotation':'كوتيشن جديد','New Service Report':'تقرير خدمة جديد','Save Company Information':'حفظ بيانات الشركة','Export Backup':'تصدير نسخة احتياطية','Restore Backup':'استعادة نسخة احتياطية','Undo Last Delete':'تراجع عن آخر حذف','Clear All Local Data':'مسح جميع البيانات المحلية'}};
  document.querySelectorAll('h1:not([data-i18n]),h2:not([data-i18n]),h3:not([data-i18n]),label:not([data-i18n]),button:not([data-i18n]),th:not([data-i18n]),option:not([data-i18n])').forEach(el=>{const base=el.getAttribute('data-en-text')||el.textContent.trim();if(!el.getAttribute('data-en-text'))el.setAttribute('data-en-text',base);if(extra.ar[base])el.textContent=lang==='ar'?extra.ar[base]:base;});
  document.querySelectorAll('input[placeholder],textarea[placeholder]').forEach(el=>{const key=el.getAttribute('data-placeholder-en')||el.placeholder;if(!el.getAttribute('data-placeholder-en'))el.setAttribute('data-placeholder-en',key);});
}
function saveAppSettings(){const l=document.getElementById('appLanguage'),t=document.getElementById('appTheme'),n=document.getElementById('notifyEnabled');appSettings.language=l?.value||'ar';appSettings.theme=t?.value||'light';appSettings.notifications=!!n?.checked;localStorage.setItem('cg_app_settings',JSON.stringify(appSettings));applyTheme();applyLanguage();renderAll();}
function applyTheme(){let th=appSettings.theme||'light';if(th==='system')th=window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';document.documentElement.classList.toggle('dark-theme',th==='dark');}
function requestAppNotifications(){if(!('Notification' in window)){alert('إشعارات الجهاز غير مدعومة في هذا WebView. ستبقى الإشعارات داخل التطبيق متاحة.');return;}Notification.requestPermission().then(p=>alert(p==='granted'?'تم تفعيل إشعارات الجهاز.':'لم يتم السماح بإشعارات الجهاز.'));}
function goToView(id){const b=document.querySelector(`#nav button[data-view="${id}"]`);if(b)b.click();}
function renderAll(){refreshTodayISO();ensureAutoInvoices();loadCompanySettings();renderCustomers();renderDaily();renderJobs();renderEmployees();renderInventory();renderSchedule();renderExpiry();renderOverdueVisits();renderServiceReports();renderGeneralReport();renderInvoices();renderQuotations();renderNotifications();renderDashboard();if(appSettings.notifications===false){const n=document.getElementById("notificationsContent");if(n)n.innerHTML="<div class=\"notice\">الإشعارات متوقفة من الضبط.</div>";}applyTheme();applyLanguage();}
document.querySelectorAll("#nav button").forEach(b=>b.onclick=()=>{document.querySelectorAll("#nav button").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.querySelectorAll(".view").forEach(x=>x.classList.remove("active"));document.getElementById(b.dataset.view).classList.add("active");renderAll()});
applyTheme();
renderAll();
document.addEventListener("keydown",function(e){if((e.ctrlKey||e.metaKey)&&["u","s"].includes(String(e.key).toLowerCase()))e.preventDefault();});
