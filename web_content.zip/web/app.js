import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth, RecaptchaVerifier, signInWithPhoneNumber, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore, doc, setDoc, getDoc, collection, query, where, getDocs, addDoc, onSnapshot, orderBy, serverTimestamp, updateDoc, arrayUnion } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { getStorage, ref as storageRef, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";

const firebaseConfig = {
  apiKey: "PASTE_FIREBASE_API_KEY",
  authDomain: "PASTE_PROJECT.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT.appspot.com",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};
const $ = id => document.getElementById(id);
const configured = !Object.values(firebaseConfig).some(v => String(v).startsWith("PASTE_"));
let auth, db, storage, recaptcha, confirmation, currentUser, profile, activeRoomId = null, stopRooms = null, stopMessages = null;
const unsubscribers = [];
function say(el, msg, error=false) { $(el).textContent = msg; $(el).style.color = error ? "#fda4af" : "#63e6e2"; }
function normalizePhone(raw) {
  let s = String(raw||"").replace(/[\s()-]/g,"");
  if (s.startsWith("01") && s.length === 11) s = "+88" + s;
  else if (s.startsWith("8801") && !s.startsWith("+")) s = "+" + s;
  return s;
}
function esc(s) { return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function showApp(on) { $("auth").classList.toggle("hidden",on); $("app").classList.toggle("hidden",!on); }
function setView(view) {
  const names = {chats:["তোমার কথোপকথন","নিবন্ধিত বন্ধুর সঙ্গে রিয়েল-টাইম মেসেজ শুরু করো।"],find:["বন্ধু খুঁজুন","ফোন নম্বর দিয়ে নিবন্ধিত ব্যবহারকারী খুঁজে নাও।"],calls:["অডিও / ভিডিও কল","কলিং ফিচারের পরিকল্পিত স্ক্রিন। বাস্তব কল এখনো যুক্ত নয়।"],files:["ফাইল শেয়ার","চ্যাট খুলে ছবি বা ফাইল পাঠাও।"],profile:["প্রোফাইল সেটিংস","নিজের নাম ও খোঁজার অনুমতি পরিবর্তন করো।"]};
  Object.keys(names).forEach(v => $(v+"View").classList.toggle("hidden",v!==view));
  document.querySelectorAll(".nav").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
  $("pageTitle").textContent=names[view][0]; $("pageDesc").textContent=names[view][1];
}
document.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>setView(b.dataset.view)));
document.querySelectorAll("[data-goto]").forEach(b=>b.addEventListener("click",()=>setView(b.dataset.goto)));
if (!configured) {
  $("connection").textContent="CONFIG REQUIRED";
  say("authStatus","প্রথমে web/app.js-এ Firebase config বসান।",true);
  $("sendOtp").disabled=true;
} else {
  const app=initializeApp(firebaseConfig); auth=getAuth(app); db=getFirestore(app); storage=getStorage(app);
  onAuthStateChanged(auth, async user=>{
    currentUser=user;
    if(!user){showApp(false);cleanupListeners();return;}
    try { await loadProfile(); showApp(true); setView("chats"); listenRooms(); }
    catch(e){console.error(e);say("authStatus","প্রোফাইল লোড হয়নি: "+(e.code||e.message),true);}
  });
}
$("sendOtp").addEventListener("click",async()=>{
  if(!auth)return say("authStatus","Firebase config বসানো হয়নি।",true);
  const phone=normalizePhone($("phone").value);
  if(!/^\+\d{10,15}$/.test(phone))return say("authStatus","দেশের কোডসহ সঠিক নম্বর দিন, যেমন +8801XXXXXXXXX",true);
  $("sendOtp").disabled=true;
  try{
    if(!recaptcha)recaptcha=new RecaptchaVerifier(auth,"recaptcha-container",{size:"normal"});
    confirmation=await signInWithPhoneNumber(auth,phone,recaptcha);
    $("otpArea").classList.remove("hidden");say("authStatus","SMS কোড পাঠানো হয়েছে।");
  }catch(e){console.error(e);say("authStatus","OTP পাঠানো যায়নি: "+(e.code||e.message)+"। Firebase Phone Auth, domain ও SMS region settings পরীক্ষা করুন।",true);}
  finally{$("sendOtp").disabled=false;}
});
$("verifyOtp").addEventListener("click",async()=>{
  const code=$("otp").value.trim();
  if(!confirmation)return say("authStatus","আগে OTP পাঠান।",true);
  if(!/^\d{6}$/.test(code))return say("authStatus","৬ সংখ্যার SMS কোড দিন।",true);
  try{await confirmation.confirm(code);say("authStatus","লগইন সফল।");}
  catch(e){say("authStatus","কোড যাচাই হয়নি: "+(e.code||e.message),true);}
});
$("logout").addEventListener("click",async()=>{if(auth)await signOut(auth);});
async function loadProfile(){
  const ref=doc(db,"users",currentUser.uid),snap=await getDoc(ref);
  profile=snap.exists()?snap.data():{uid:currentUser.uid,phoneNumber:currentUser.phoneNumber,displayName:"LV75 User",discoverable:true};
  await setDoc(ref,{uid:currentUser.uid,phoneNumber:currentUser.phoneNumber,displayName:profile.displayName||"LV75 User",discoverable:profile.discoverable!==false,updatedAt:serverTimestamp()},{merge:true});
  $("myName").textContent=profile.displayName||"LV75 User";$("myPhone").textContent=currentUser.phoneNumber||"";$("avatar").textContent=(profile.displayName||"L").charAt(0).toUpperCase();
  $("displayName").value=profile.displayName||"";$("discoverable").checked=profile.discoverable!==false;
}
$("saveProfile").addEventListener("click",async()=>{
  if(!currentUser)return;
  const displayName=$("displayName").value.trim().slice(0,40)||"LV75 User",discoverable=$("discoverable").checked;
  try{await setDoc(doc(db,"users",currentUser.uid),{displayName,discoverable,phoneNumber:currentUser.phoneNumber,updatedAt:serverTimestamp()},{merge:true});profile={...profile,displayName,discoverable};$("myName").textContent=displayName;$("avatar").textContent=displayName.charAt(0).toUpperCase();say("profileStatus","প্রোফাইল সংরক্ষণ হয়েছে।");}
  catch(e){say("profileStatus","সংরক্ষণ হয়নি: "+(e.code||e.message),true);}
});
$("searchUser").addEventListener("click",async()=>{
  if(!currentUser)return;
  const phone=normalizePhone($("searchPhone").value),out=$("searchResult");
  if(!/^\+\d{10,15}$/.test(phone)){out.textContent="সঠিক নম্বর দিন, যেমন +8801XXXXXXXXX";return;}
  out.textContent="খোঁজা হচ্ছে…";
  try{
    const q=query(collection(db,"users"),where("phoneNumber","==",phone),where("discoverable","==",true));
    const snap=await getDocs(q),hit=snap.docs.find(d=>d.id!==currentUser.uid);
    if(!hit){out.textContent="এই নম্বরে খুঁজে পাওয়ার অনুমতি দেওয়া কোনো ব্যবহারকারী পাওয়া যায়নি।";return;}
    const u=hit.data();
    out.innerHTML=`<div class="found"><div class="contact-avatar">${esc((u.displayName||"U").charAt(0).toUpperCase())}</div><div class="grow"><b>${esc(u.displayName||"LV75 User")}</b><small>${esc(u.phoneNumber||"")}</small></div><button id="startChat" class="primary">মেসেজ করুন →</button></div>`;
    $("startChat").addEventListener("click",()=>startChat(hit.id,u));
  }catch(e){console.error(e);out.textContent="ব্যবহারকারী খোঁজা যায়নি। Firestore rules/config এবং index error পরীক্ষা করুন।";}
});
async function startChat(otherUid,other){
  try{
    const q=query(collection(db,"chats"),where("participants","array-contains",currentUser.uid));
    const snap=await getDocs(q);
    let existing=snap.docs.find(d=>(d.data().participants||[]).includes(otherUid));
    let roomId;
    if(existing)roomId=existing.id;
    else{
      const ref=await addDoc(collection(db,"chats"),{participants:[currentUser.uid,otherUid],participantNames:{[currentUser.uid]:profile.displayName||"LV75 User",[otherUid]:other.displayName||"LV75 User"},createdAt:serverTimestamp(),lastMessage:"",updatedAt:serverTimestamp()});
      roomId=ref.id;
    }
    await renderRoomList();
    await openRoom(roomId,otherUid,other);
    setView("chats");
  }catch(e){console.error(e);say("chatStatus","চ্যাট শুরু হয়নি: "+(e.code||e.message),true);}
}
function cleanupListeners(){if(stopRooms)stopRooms();if(stopMessages)stopMessages();stopRooms=null;stopMessages=null;}
function listenRooms(){
  if(stopRooms)stopRooms();
  const q=query(collection(db,"chats"),where("participants","array-contains",currentUser.uid));
  stopRooms=onSnapshot(q,async()=>{await renderRoomList();},e=>console.error("rooms",e));
}
async function renderRoomList(){
  if(!currentUser)return;
  try{
    const q=query(collection(db,"chats"),where("participants","array-contains",currentUser.uid));
    const snap=await getDocs(q),out=$("roomList");
    if(snap.empty){out.innerHTML='<div class="list-empty">এখনো কোনো চ্যাট নেই। বন্ধু খুঁজে শুরু করো।</div>';return;}
    const rooms=snap.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(b.updatedAt?.seconds||0)-(a.updatedAt?.seconds||0));
    out.innerHTML="";
    rooms.forEach(r=>{
      const other=(r.participants||[]).find(x=>x!==currentUser.uid);
      const name=r.participantNames?.[other]||"LV75 Contact";
      const el=document.createElement("button");el.className="room"+(r.id===activeRoomId?" active":"");el.innerHTML=`<div class="contact-avatar">${esc(name.charAt(0).toUpperCase())}</div><div><b>${esc(name)}</b><small>${esc(r.lastMessage||"কথোপকথন খুলুন")}</small></div>`;
      el.addEventListener("click",async()=>{
        let otherProfile={displayName:name};
        try{const s=await getDoc(doc(db,"users",other));if(s.exists())otherProfile=s.data();}catch{}
        await openRoom(r.id,other,otherProfile);
      });
      out.appendChild(el);
    });
  }catch(e){console.error(e);}
}
async function openRoom(roomId,otherUid,other){
  activeRoomId=roomId;
  $("chatPlaceholder").classList.add("hidden");$("activeChat").classList.remove("hidden");
  $("chatName").textContent=other.displayName||"LV75 Contact";$("chatPhone").textContent=other.phoneNumber||"";
  $("chatAvatar").textContent=(other.displayName||"U").charAt(0).toUpperCase();
  if(stopMessages)stopMessages();
  const q=query(collection(db,"chats",roomId,"messages"),orderBy("createdAt","asc"));
  stopMessages=onSnapshot(q,snap=>{
    const out=$("messages");out.innerHTML="";
    snap.forEach(d=>{
      const m=d.data(),mine=m.senderId===currentUser.uid;
      const div=document.createElement("div");div.className="msg"+(mine?" mine":"");
      const body=m.type==="file"?`<a href="${esc(m.fileUrl)}" target="_blank" rel="noopener">${esc(m.fileName||"ফাইল খুলুন")}</a>`:esc(m.text||"");
      const time=m.createdAt?.toDate?m.createdAt.toDate().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}):"";
      div.innerHTML=`${body}<small>${mine?"আপনি":esc(other.displayName||"বন্ধু")} · ${time}</small>`;
      out.appendChild(div);
    });out.scrollTop=out.scrollHeight;
  },e=>{console.error(e);say("chatStatus","মেসেজ লোড হয়নি: "+(e.code||e.message),true);});
  await renderRoomList();
}
async function sendText(){
  if(!activeRoomId||!currentUser)return say("chatStatus","আগে একটি চ্যাট খুলুন।",true);
  const text=$("messageInput").value.trim();if(!text)return;
  $("sendMessage").disabled=true;
  try{
    const roomRef=doc(db,"chats",activeRoomId);
    const roomSnap=await getDoc(roomRef);if(!roomSnap.exists())throw new Error("Chat not found");
    await addDoc(collection(db,"chats",activeRoomId,"messages"),{senderId:currentUser.uid,type:"text",text,createdAt:serverTimestamp()});
    await updateDoc(roomRef,{lastMessage:text.slice(0,120),updatedAt:serverTimestamp()});
    $("messageInput").value="";say("chatStatus","পাঠানো হয়েছে।");
  }catch(e){console.error(e);say("chatStatus","পাঠানো যায়নি: "+(e.code||e.message),true);}
  finally{$("sendMessage").disabled=false;}
}
$("sendMessage").addEventListener("click",sendText);
$("messageInput").addEventListener("keydown",e=>{if(e.key==="Enter")sendText();});
$("attachment").addEventListener("change",async e=>{
  const file=e.target.files?.[0];if(!file)return;
  if(!activeRoomId||!currentUser){say("chatStatus","আগে একটি চ্যাট খুলুন।",true);e.target.value="";return;}
  if(file.size>15*1024*1024){say("chatStatus","ফাইল 15 MB-এর কম হতে হবে।",true);e.target.value="";return;}
  say("chatStatus","ফাইল আপলোড হচ্ছে…");
  try{
    const safeName=file.name.replace(/[^a-zA-Z0-9._-]/g,"_").slice(-90)||"upload";
    const path=`chats/${activeRoomId}/${Date.now()}_${currentUser.uid}_${safeName}`;
    const sref=storageRef(storage,path);
    await uploadBytes(sref,file,{contentType:file.type||"application/octet-stream"});
    const url=await getDownloadURL(sref);
    await addDoc(collection(db,"chats",activeRoomId,"messages"),{senderId:currentUser.uid,type:"file",fileName:file.name,fileUrl:url,createdAt:serverTimestamp()});
    await updateDoc(doc(db,"chats",activeRoomId),{lastMessage:"ফাইল: "+file.name.slice(0,90),updatedAt:serverTimestamp()});
    say("chatStatus","ফাইল পাঠানো হয়েছে।");
  }catch(e){console.error(e);say("chatStatus","ফাইল পাঠানো যায়নি: "+(e.code||e.message)+"। Storage চালু আছে কি দেখুন।",true);}
  finally{e.target.value="";}
});
