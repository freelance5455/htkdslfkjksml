const KEY='ec-tech-final-v1';
let db=JSON.parse(localStorage.getItem(KEY)||'{"products":[],"docs":[],"purchases":[],"contacts":[],"expenses":[],"log":[],"settings":{"name":"EC Technologie"}}');
const money=n=>new Intl.NumberFormat('fr-FR').format(Math.round(Number(n)||0))+' Ar';
const now=()=>new Date().toISOString().slice(0,10);
const esc=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[x]));
const product=ref=>db.products.find(p=>p.ref.toLowerCase()===ref.trim().toLowerCase());
function save(){localStorage.setItem(KEY,JSON.stringify(db));renderAll()}
function log(action){db.log.unshift({date:new Date().toLocaleString('fr-FR'),action});db.log=db.log.slice(0,200)}
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));document.getElementById(b.dataset.p).classList.add('active')});

function line(){
 const tr=document.createElement('tr');
 tr.innerHTML='<td><input class="r" placeholder="CAB-001"></td><td class="d"></td><td><input class="q" type="number" min="1" value="1"></td><td class="p"></td><td class="t"></td><td class="h">0 Ar</td><td class="tt">0 Ar</td><td><button>×</button></td>';
 document.querySelector('#lines tbody').appendChild(tr);
 tr.querySelector('.r').oninput=()=>fill(tr);tr.querySelector('.q').oninput=()=>calc(tr);tr.querySelector('button').onclick=()=>{tr.remove();totals()}
}
function fill(tr){let p=product(tr.querySelector('.r').value);tr.querySelector('.d').textContent=p?p.name:'';tr.querySelector('.p').textContent=p?money(p.sell):'';tr.querySelector('.t').textContent=p?p.tax+' %':'';calc(tr)}
function calc(tr){let p=product(tr.querySelector('.r').value),q=+tr.querySelector('.q').value||0,ht=p?q*p.sell:0,ttc=p?ht*(1+p.tax/100):0;tr.querySelector('.h').textContent=money(ht);tr.querySelector('.tt').textContent=money(ttc);totals()}
function totals(){let h=0,t=0;document.querySelectorAll('#lines tbody tr').forEach(x=>{h+=+(x.querySelector('.h').textContent.replace(/[^0-9]/g,''))||0;t+=+(x.querySelector('.tt').textContent.replace(/[^0-9]/g,''))||0});document.getElementById('ht').textContent=money(h);document.getElementById('vat').textContent=money(t-h);document.getElementById('ttc').textContent=money(t)}
document.getElementById('newDoc').onclick=()=>{document.getElementById('docEditor').classList.remove('hidden');document.querySelector('#lines tbody').innerHTML='';line()}
document.getElementById('cancelDoc').onclick=()=>document.getElementById('docEditor').classList.add('hidden');
document.getElementById('addLine').onclick=line;
document.getElementById('saveDoc').onclick=()=>{
 try{
  let rows=[...document.querySelectorAll('#lines tbody tr')];if(!rows.length)throw Error('Ajoute une ligne');
  let items=rows.map(x=>{let p=product(x.querySelector('.r').value);if(!p)throw Error('Référence inconnue : '+x.querySelector('.r').value);return{ref:p.ref,name:p.name,qty:+x.querySelector('.q').value||1,price:p.sell,tax:p.tax,buy:p.buy}});
  let ht=items.reduce((s,x)=>s+x.qty*x.price,0),vat=items.reduce((s,x)=>s+x.qty*x.price*x.tax/100,0);
  let num='DV-'+new Date().getFullYear()+'-'+String(db.docs.length+1).padStart(4,'0');
  db.docs.unshift({num,date:now(),type:document.getElementById('docType').value,client:document.getElementById('docClient').value||'Client comptant',items,ht,vat,ttc:ht+vat,status:'Brouillon'});
  log('Création '+num);save();document.getElementById('docEditor').classList.add('hidden');alert('Document enregistré : '+num)
 }catch(e){alert(e.message)}
};

document.getElementById('saveProduct').onclick=()=>{let r=document.getElementById('ref').value.trim();if(!r)return alert('Référence obligatoire');let p=product(r)||{ref:r};if(!db.products.includes(p))db.products.push(p);p.name=document.getElementById('name').value;p.buy=+document.getElementById('buy').value||0;p.sell=+document.getElementById('sell').value||0;p.tax=+document.getElementById('tax').value||0;p.qty=+document.getElementById('qty').value||0;p.min=+document.getElementById('min').value||0;log('Produit '+r+' enregistré');save();alert('Produit enregistré')};

document.getElementById('savePurchase').onclick=()=>{let p=product(document.getElementById('buyRef').value);if(!p)return alert('Référence inconnue');let q=+document.getElementById('buyQty').value||0,c=+document.getElementById('buyUnit').value||p.buy;p.qty+=q;p.buy=c;db.purchases.unshift({date:now(),ref:p.ref,supplier:document.getElementById('supplier').value,qty:q,cost:c,total:q*c});log('Achat '+q+' × '+p.ref);save();alert('Achat enregistré et stock augmenté')};

document.getElementById('saveContact').onclick=()=>{let n=document.getElementById('cn').value.trim();if(!n)return alert('Nom obligatoire');db.contacts.unshift({type:ct.value,name:n,phone:cp.value,address:document.getElementById('ca').value});log('Contact '+n+' ajouté');save()};
document.getElementById('saveExpense').onclick=()=>{let a=+document.getElementById('expenseAmount').value||0;if(a<=0)return alert('Montant invalide');db.expenses.unshift({date:now(),label:document.getElementById('expenseLabel').value||'Dépense',amount:a});log('Dépense '+money(a));save()};

document.getElementById('saveSettings').onclick=()=>{db.settings={name:bizName.value,phone:bizPhone.value,email:bizEmail.value,address:bizAddress.value,nif:bizNif.value,stat:bizStat.value,terms:terms.value,warranty:warranty.value};log('Configuration modifiée');save();alert('Configuration sauvegardée')};
document.getElementById('backup').onclick=()=>{let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(db,null,2)],{type:'application/json'}));a.download='EC_Technologie_sauvegarde_'+now()+'.json';a.click();URL.revokeObjectURL(a.href)};
document.getElementById('restore').onchange=e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{db=JSON.parse(r.result);save();alert('Sauvegarde restaurée')}catch(_){alert('Fichier invalide')}};r.readAsText(f)};

function renderProducts(){products.innerHTML='<table><tr><th>Référence</th><th>Désignation</th><th>Achat</th><th>Vente</th><th>Stock</th><th>Valeur</th></tr>'+db.products.map(p=>`<tr class="${p.qty<=p.min?'low':''}"><td>${esc(p.ref)}</td><td>${esc(p.name)}</td><td>${money(p.buy)}</td><td>${money(p.sell)}</td><td>${p.qty}${p.qty<=p.min?' ⚠️':''}</td><td>${money(p.qty*p.buy)}</td></tr>`).join('')+'</table>'}
function renderDocs(){let f=docFilter.value,s=docSearch.value.toLowerCase();documentsList.innerHTML='<table><tr><th>N°</th><th>Date</th><th>Type</th><th>Client</th><th>TTC</th><th>Statut</th></tr>'+db.docs.filter(d=>(f==='Tous'||d.type===f)&&JSON.stringify(d).toLowerCase().includes(s)).map(d=>`<tr><td>${d.num}</td><td>${d.date}</td><td>${d.type}</td><td>${esc(d.client)}</td><td>${money(d.ttc)}</td><td>${d.status}</td></tr>`).join('')+'</table>'}
docSearch.oninput=renderDocs;docFilter.onchange=renderDocs;
function renderAll(){
 renderProducts();renderDocs();
 purchaseList.innerHTML='<table><tr><th>Date</th><th>Réf.</th><th>Fournisseur</th><th>Qté</th><th>Total</th></tr>'+db.purchases.map(x=>`<tr><td>${x.date}</td><td>${esc(x.ref)}</td><td>${esc(x.supplier)}</td><td>${x.qty}</td><td>${money(x.total)}</td></tr>`).join('')+'</table>';
 contactList.innerHTML='<table><tr><th>Type</th><th>Nom</th><th>Téléphone</th><th>Adresse</th></tr>'+db.contacts.map(x=>`<tr><td>${x.type}</td><td>${esc(x.name)}</td><td>${esc(x.phone)}</td><td>${esc(x.address)}</td></tr>`).join('')+'</table>';
 expenseList.innerHTML='<table><tr><th>Date</th><th>Libellé</th><th>Montant</th></tr>'+db.expenses.map(x=>`<tr><td>${x.date}</td><td>${esc(x.label)}</td><td>${money(x.amount)}</td></tr>`).join('')+'</table>';
 let sales=db.docs.filter(x=>x.status==='Facture'),CA=sales.reduce((s,x)=>s+x.ttc,0),ach=db.purchases.reduce((s,x)=>s+x.total,0),dep=db.expenses.reduce((s,x)=>s+x.amount,0),mar=sales.reduce((s,x)=>s+x.items.reduce((a,i)=>a+i.qty*(i.price-i.buy),0),0),sv=db.products.reduce((s,p)=>s+p.qty*p.buy,0);
 ca.textContent=money(CA);purchasesKpi.textContent=money(ach);expensesKpi.textContent=money(dep);margin.textContent=money(mar);profit.textContent=money(mar-dep);stockValue.textContent=money(sv);
 activity.innerHTML=db.log.slice(0,12).map(x=>`<p><b>${x.date}</b> — ${esc(x.action)}</p>`).join('')||'<p>Aucune opération.</p>';
 log.innerHTML=db.log.map(x=>`<p>${x.date} — ${esc(x.action)}</p>`).join('');
 bizName.value=db.settings.name||'EC Technologie';bizPhone.value=db.settings.phone||'';bizEmail.value=db.settings.email||'';bizAddress.value=db.settings.address||'';bizNif.value=db.settings.nif||'';bizStat.value=db.settings.stat||'';terms.value=db.settings.terms||'';warranty.value=db.settings.warranty||'';
 draw()
}
function draw(){let c=document.getElementById('chart'),x=c.getContext('2d');x.clearRect(0,0,c.width,c.height);x.strokeStyle='#12633d';x.beginPath();x.moveTo(40,240);x.lineTo(860,240);x.stroke();let months=[...Array(12)].map((_,i)=>i+1);months.forEach((m,i)=>{let v=db.docs.filter(d=>d.status==='Facture'&&+d.date.slice(5,7)===m).reduce((s,d)=>s+d.ttc,0),h=Math.min(190,v/10000);x.fillRect(65+i*65,240-h,30,h);x.fillText(String(m).padStart(2,'0'),70+i*65,260)})}
line();renderAll();if('serviceWorker'in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});
