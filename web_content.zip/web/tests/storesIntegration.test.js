import assert from 'node:assert/strict';
import test from 'node:test';
import { AngleMode } from '../src/engine/calculationEngine.js';
import { NumberGroupingStyle } from '../src/engine/numberFormatter.js';
import { CalculatorStore } from '../src/state/calculatorStore.js';
import { ConverterStore } from '../src/state/converterStore.js';
import {
  AppThemeMode,
  HistoryStore,
  InMemoryStorage,
  PreferencesStore,
} from '../src/state/storage.js';

test('memory sequence rapid M+ M- MR MC and negative decimals', () => {
  const storage = new InMemoryStorage();
  const history = new HistoryStore({ storage });
  const prefs = new PreferencesStore({ storage });
  const vm = new CalculatorStore(history, prefs);

  vm.onMemoryClear();
  assert.equal(vm.uiState.hasMemory, false);

  vm.onDigit('1');
  vm.onDigit('0');
  vm.onDecimal();
  vm.onDigit('5');
  vm.onMemoryAdd();
  vm.onMemoryAdd();
  assert.equal(vm.uiState.hasMemory, true);
  assert.equal(vm.uiState.memoryFormatted, '21');

  vm.onClearAll();
  vm.onDigit('3');
  vm.onDigit('0');
  vm.onDecimal();
  vm.onDigit('2');
  vm.onDigit('5');
  vm.onMemorySubtract();
  assert.equal(vm.uiState.memoryFormatted, '−9.25');

  vm.onClearAll();
  vm.onMemoryRecall();
  assert.equal(vm.uiState.expression, '−9.25');

  vm.onClearAll();
  vm.onMemoryClear();
  assert.equal(vm.uiState.hasMemory, false);
  vm.onMemoryRecall();
  assert.equal(vm.uiState.expression, '');
});

test('history lifecycle save reverse order reuse delete clear and 300-entry stress', () => {
  const storage = new InMemoryStorage();
  const history = new HistoryStore({ storage });
  const prefs = new PreferencesStore({ storage });
  const vm = new CalculatorStore(history, prefs);

  vm.onDigit('1');
  vm.onOperator('+');
  vm.onDigit('2');
  vm.onEquals();
  assert.equal(vm.uiState.resultText, '3');

  vm.onEquals();
  assert.equal(vm.uiState.resultText, '5');
  vm.onEquals();
  assert.equal(vm.uiState.resultText, '7');

  assert.equal(vm.history.length, 3);
  assert.equal(vm.history[0].resultFormatted, '7');
  assert.equal(vm.history[2].resultFormatted, '3');

  vm.reuseHistoryItem(vm.history[2]);
  assert.equal(vm.uiState.expression, '1+2');
  assert.equal(vm.uiState.resultText, '3');

  const midId = vm.history[1].id;
  vm.deleteHistoryItem(midId);
  assert.equal(vm.history.length, 2);

  vm.clearAllHistory();
  assert.equal(vm.history.length, 0);

  for (let i = 1; i <= 300; i++) {
    vm.onClearAll();
    for (const ch of String(i)) vm.onDigit(ch);
    vm.onOperator('×');
    vm.onDigit('2');
    vm.onEquals();
  }
  assert.equal(vm.history.length, 300);
  assert.equal(vm.history[0].resultFormatted, '600');
});

test('error recovery sign toggle and scientific mode flow', () => {
  const storage = new InMemoryStorage();
  const history = new HistoryStore({ storage });
  const prefs = new PreferencesStore({ storage });
  const vm = new CalculatorStore(history, prefs);

  vm.onDigit('5');
  vm.onOperator('÷');
  vm.onDigit('0');
  vm.onEquals();
  assert.equal(vm.uiState.errorMessage, "Can't divide by zero");

  vm.onDigit('8');
  vm.onOperator('+');
  vm.onDigit('2');
  vm.onEquals();
  assert.equal(vm.uiState.errorMessage, null);
  assert.equal(vm.uiState.resultText, '10');

  vm.onClearAll();
  vm.onDigit('1');
  vm.onDecimal();
  vm.onDigit('2');
  vm.onDecimal();
  vm.onDigit('3');
  assert.equal(vm.uiState.expression, '1.23');

  vm.onOperator('×');
  vm.onDigit('5');
  vm.onToggleSign();
  assert.equal(vm.uiState.expression, '1.23×(−5)');
  vm.onToggleSign();
  assert.equal(vm.uiState.expression, '1.23×5');

  vm.setScientificMode(true);
  vm.onClearAll();
  vm.onScientificFunction('sin(');
  vm.onDigit('3');
  vm.onDigit('0');
  vm.onParen(')');
  vm.onEquals();
  assert.equal(vm.uiState.resultText, '0.5');

  vm.toggleAngleMode();
  assert.equal(vm.uiState.angleMode, AngleMode.RAD);
});

test('converter store swap clear and keyboard-free digits', () => {
  const cvm = new ConverterStore();
  cvm.onClear();
  cvm.onDigit('1');
  cvm.onDigit('0');
  cvm.onDecimal();
  cvm.onDigit('5');
  assert.equal(cvm.state.inputText, '10.5');

  const originalFrom = cvm.state.fromUnit;
  const originalTo = cvm.state.toUnit;
  cvm.swapUnits();
  assert.equal(cvm.state.fromUnit.id, originalTo.id);
  assert.equal(cvm.state.toUnit.id, originalFrom.id);

  cvm.onBackspace();
  assert.equal(cvm.state.inputText, '10.');
  cvm.onClear();
  assert.equal(cvm.state.inputText, '0');
});

test('storage persistence across simulated reload for history memory and settings', () => {
  const storage = new InMemoryStorage();
  const prefs1 = new PreferencesStore({ storage });
  const hist1 = new HistoryStore({ storage });
  const vm1 = new CalculatorStore(hist1, prefs1);

  prefs1.setThemeMode(AppThemeMode.LIGHT);
  prefs1.setHapticEnabled(false);
  prefs1.setGroupingStyle(NumberGroupingStyle.SPACE);
  prefs1.setDecimalPrecision(4);
  prefs1.setAngleMode(AngleMode.RAD);

  vm1.onDigit('2');
  vm1.onDigit('5');
  vm1.onMemoryAdd();
  vm1.onOperator('+');
  vm1.onDigit('5');
  vm1.onEquals();

  // Recreate stores reading the exact same backing storage
  const prefs2 = new PreferencesStore({ storage });
  const hist2 = new HistoryStore({ storage });
  const vm2 = new CalculatorStore(hist2, prefs2);

  assert.equal(prefs2.value.themeMode.name, 'LIGHT');
  assert.equal(prefs2.value.hapticEnabled, false);
  assert.equal(prefs2.value.groupingStyle.name, 'SPACE');
  assert.equal(prefs2.value.decimalPrecision, 4);
  assert.equal(prefs2.value.angleMode, AngleMode.RAD);
  assert.equal(vm2.uiState.hasMemory, true);
  assert.equal(vm2.uiState.memoryFormatted, '25.0000');
  assert.equal(vm2.history.length, 1);
  assert.equal(vm2.history[0].expression, '25+5');
});
