import assert from 'node:assert/strict';
import test from 'node:test';
import { BigDecimal } from '../src/engine/bigDecimal.js';
import {
  AngleMode,
  CalcError,
  CalculationEngine,
  isEvalError,
  isEvalSuccess,
} from '../src/engine/calculationEngine.js';
import { FormattingOptions, NumberFormatter } from '../src/engine/numberFormatter.js';
import { FractionOp, SimpleDate, ToolsEngine } from '../src/engine/toolsEngine.js';
import { ConverterCategory, UnitConverter } from '../src/engine/unitConverter.js';
import { CalculatorStore } from '../src/state/calculatorStore.js';
import { ConverterStore } from '../src/state/converterStore.js';
import { HistoryStore, InMemoryStorage, PreferencesStore } from '../src/state/storage.js';

function fmtRes(res) {
  return JSON.stringify(res, (_, v) => (typeof v === 'bigint' ? v.toString() : v));
}

function evalOk(expr, angleMode = AngleMode.DEG, formatting = new FormattingOptions()) {
  const res = CalculationEngine.evaluate(expr, angleMode, formatting);
  if (!isEvalSuccess(res)) {
    assert.fail(`Expected Success for '${expr}' (${angleMode}), got ${fmtRes(res)}`);
  }
  return res;
}

function evalErr(expr, expected, angleMode = AngleMode.DEG) {
  const res = CalculationEngine.evaluate(expr, angleMode);
  if (!isEvalError(res)) {
    assert.fail(`Expected Error(${expected.name}) for '${expr}', got ${fmtRes(res)}`);
  }
  assert.equal(res.error.name, expected.name, `Wrong error for '${expr}'`);
}

function assertClose(actual, expected, tol = 1e-9, msg = '') {
  assert.ok(Math.abs(actual - expected) <= tol, `${msg}: expected ${expected}, got ${actual}`);
}

test('precision attack large integers vastly different magnitudes and raw reuse', () => {
  const int50 = '1234567890'.repeat(5);
  const res50 = evalOk(`${int50}+7`);
  assert.equal(res50.value.compareTo(BigDecimal.parse(int50).add(7)), 0);

  const reused50 = evalOk(`${res50.rawNumericString}−${int50}`);
  assert.equal(reused50.formatted, '7');

  const int100 = '9876543210'.repeat(10);
  const res100 = evalOk(`${int100}+42`);
  assert.equal(res100.value.compareTo(BigDecimal.parse(int100).add(42)), 0);
  const reused100 = evalOk(`${res100.rawNumericString}−${int100}`);
  assert.equal(reused100.formatted, '42');

  const int120 = '9'.repeat(120);
  const res120 = evalOk(`${int120}+1`);
  assert.equal(res120.value.compareTo(BigDecimal.parse('1' + '0'.repeat(120))), 0);

  const catCancel = evalOk('1e130+1−1e130');
  assert.equal(catCancel.value.compareTo(BigDecimal.ONE), 0);

  const bigPctBase = '1' + '0'.repeat(49);
  const bigPct = evalOk(`${bigPctBase}+10%`);
  assert.equal(bigPct.value.compareTo(BigDecimal.parse('11' + '0'.repeat(48))), 0);
});

test('near zero values in trig inverse trig hyperbolic and huge or tiny logs and roots', () => {
  const nineE14 = BigDecimal.parse('9e-14');
  assert.ok(evalOk('sin(1e-13)', AngleMode.RAD).value.compareTo(nineE14) > 0);
  assert.ok(evalOk('asin(1e-13)', AngleMode.RAD).value.compareTo(nineE14) > 0);
  assert.ok(evalOk('atan(1e-13)', AngleMode.RAD).value.compareTo(nineE14) > 0);
  assert.ok(evalOk('sinh(1e-13)').value.compareTo(nineE14) > 0);
  assert.ok(evalOk('tanh(1e-13)').value.compareTo(nineE14) > 0);

  assert.equal(evalOk('sin(360000000000000030)', AngleMode.DEG).formatted, '0.5');
  assert.equal(evalOk('sin(180000000000000000)', AngleMode.DEG).formatted, '0');
  assert.equal(evalOk('cos(900000000000000090)', AngleMode.DEG).formatted, '0');
  evalErr('tan(900000000000000090)', CalcError.DOMAIN_ERROR, AngleMode.DEG);

  assert.equal(evalOk('log(10^400)').formatted, '400');
  assert.equal(evalOk('log(10^(−400))').formatted, '−400');
  assertClose(evalOk('ln(10^400)').value.toNumber(), 400.0 * Math.log(10.0), 1e-8);
  assertClose(evalOk('ln(10^(−400))').value.toNumber(), -400.0 * Math.log(10.0), 1e-8);
  assert.equal(evalOk('logBase(2,2^1500)').formatted, '1,500');
  assert.equal(evalOk('√(10^400)').value.compareTo(BigDecimal.parse('1e200')), 0);
  assert.equal(evalOk('√(10^(−400))').value.compareTo(BigDecimal.parse('1e-200')), 0);
  assert.equal(evalOk('∛(10^600)').value.compareTo(BigDecimal.parse('1e200')), 0);
  assert.equal(evalOk('tanh(10^400)').formatted, '1');
});

test('formatter never produces negative zero with fixed decimal precision', () => {
  const fixed2 = new FormattingOptions({ decimalPrecision: 2 });
  assert.equal(NumberFormatter.formatResult(BigDecimal.parse('-0.001'), fixed2), '0.00');
  assert.equal(NumberFormatter.formatDouble(-0.001, fixed2), '0.00');
  assert.equal(
    NumberFormatter.formatResult(BigDecimal.parse('-0.1'), new FormattingOptions({ decimalPrecision: 0 })),
    '0',
  );
});

test('unit converter extreme magnitudes all 16 categories and header rate label', () => {
  const dataUnits = UnitConverter.unitsFor(ConverterCategory.DATA_STORAGE);
  const tb = dataUnits.find((u) => u.id === 'tb');
  const gb = dataUnits.find((u) => u.id === 'gb');
  const convBig = UnitConverter.convert(1e300, tb, gb, ConverterCategory.DATA_STORAGE);
  assert.ok(convBig !== null);
  assertClose(convBig, 1e303, 1e292);

  const lenUnits = UnitConverter.unitsFor(ConverterCategory.LENGTH);
  const km = lenUnits.find((u) => u.id === 'km');
  const mm = lenUnits.find((u) => u.id === 'mm');
  assert.equal(UnitConverter.convert(1e308, km, mm, ConverterCategory.LENGTH), null);

  assertClose(
    UnitConverter.convert(1.0, lenUnits.find((u) => u.id === 'mi'), lenUnits.find((u) => u.id === 'm'), ConverterCategory.LENGTH),
    1609.344,
  );
  assertClose(
    UnitConverter.convert(1.0, lenUnits.find((u) => u.id === 'mi'), lenUnits.find((u) => u.id === 'ft'), ConverterCategory.LENGTH),
    5280.0,
  );
  const angleUnits = UnitConverter.unitsFor(ConverterCategory.ANGLE);
  assertClose(
    UnitConverter.convert(1.0, angleUnits.find((u) => u.id === 'rad'), angleUnits.find((u) => u.id === 'deg'), ConverterCategory.ANGLE),
    180.0 / Math.PI,
  );

  const fuelUnits = UnitConverter.unitsFor(ConverterCategory.FUEL_ECONOMY);
  const mpgUs = fuelUnits.find((u) => u.id === 'mpg_us');
  const l100 = fuelUnits.find((u) => u.id === 'l100km');
  const expectedL100 = 100.0 / ((30.0 * 1.609344) / 3.785411784);
  assertClose(UnitConverter.convert(30.0, mpgUs, l100, ConverterCategory.FUEL_ECONOMY), expectedL100);

  const cvm = new ConverterStore();
  cvm.selectCategory(ConverterCategory.TEMPERATURE);
  assert.ok(cvm.effectiveRateLabel().includes('33.8'));

  cvm.selectCategory(ConverterCategory.FUEL_ECONOMY);
  assert.ok(cvm.effectiveRateLabel().includes('100'));

  cvm.selectCategory(ConverterCategory.TEMPERATURE);
  cvm.onClear();
  cvm.onDigit('4');
  cvm.onDigit('0');
  cvm.onToggleSign();
  assert.equal(cvm.state.inputText, '−40');
  cvm.selectCategory(ConverterCategory.LENGTH);
  assert.equal(cvm.state.inputText, '40');
});

test('tools engine extreme inputs tiny EMI rates Long MIN_VALUE ratio and dates', () => {
  const rMin = ToolsEngine.ratio(-9223372036854775808n, -9223372036854775808n, null);
  assert.deepEqual(rMin[0], [1n, 1n]);

  const tinyEmi = ToolsEngine.calculateEmi(120_000.0, 1e-14, 12);
  assert.ok(tinyEmi !== null);
  assertClose(tinyEmi[0], 10_000.0, 1e-6);

  const pd = ToolsEngine.percentDifference(1e308, -1e308);
  assert.ok(Number.isFinite(pd));

  const avgMax = ToolsEngine.average([1e308, 1e308]);
  assert.ok(Number.isFinite(avgMax.median));

  const pre1582 = ToolsEngine.dateDifference(new SimpleDate(1500, 3, 1), new SimpleDate(1500, 3, 10));
  assert.equal(pre1582.totalDays, 9);
  const across1582 = ToolsEngine.dateDifference(new SimpleDate(1582, 10, 4), new SimpleDate(1582, 10, 15));
  assert.equal(across1582.totalDays, 11);

  const leapBday = ToolsEngine.calculateAge(new SimpleDate(2000, 2, 29), new SimpleDate(2024, 2, 28));
  assert.equal(leapBday.daysUntilNextBirthday, 1);
});

test('scientific notation repeat equals', () => {
  const storage = new InMemoryStorage();
  const vm = new CalculatorStore(new HistoryStore({ storage }), new PreferencesStore({ storage }));
  vm.reuseHistoryItem({
    id: 99,
    expression: '2×1E+3',
    resultFormatted: '2,000',
    resultRaw: '2000',
    angleMode: 'DEG',
    isScientific: false,
  });
  vm.onEquals();
  assert.equal(vm.uiState.resultText, '2,000');
  vm.onEquals();
  assert.equal(vm.uiState.resultText, '2,000,000');
});

test('long min exponent overflow repeated division implicit multiplication and scaled fractional powers', () => {
  evalErr('2^(−9223372036854775808)', CalcError.OVERFLOW);
  assert.equal(evalOk('1^(−9223372036854775808)').formatted, '1');

  assert.equal(evalOk('(10^400)^0.5').value.compareTo(BigDecimal.parse('1e200')), 0);
  assert.equal(evalOk('(10^(−400))^0.5').value.compareTo(BigDecimal.parse('1e-200')), 0);
  assert.equal(evalOk('nroot(3,−(10^600))').value.compareTo(BigDecimal.parse('-1e200')), 0);
  assert.equal(evalOk('nroot(5,−32)').formatted, '−2');
  assert.equal(evalOk('0^0').formatted, '1');

  const repDiv = evalOk('1÷3÷3÷3÷3');
  const direct81 = evalOk('1÷81');
  assert.equal(repDiv.formatted, direct81.formatted);
  assert.ok(repDiv.value.subtract(direct81.value).abs().compareTo(BigDecimal.parse('1e-32')) < 0);

  assert.equal(evalOk('5!2').formatted, '240');
  assert.equal(evalOk('50%2').formatted, '1');
  assert.equal(evalOk('2e3').formatted, '2,000');
  assertClose(evalOk('sin(30)cos(60)', AngleMode.DEG).value.toNumber(), 0.25, 1e-12);
  assertClose(evalOk('2e').value.toNumber(), 2.0 * Math.E, 1e-12);

  evalErr('logBase(2)', CalcError.SYNTAX_ERROR);
  evalErr('nroot(3)', CalcError.SYNTAX_ERROR);
  evalErr('sin(1,2)', CalcError.SYNTAX_ERROR);
  evalErr('10^99999999', CalcError.OVERFLOW);
  evalErr('1E10000000', CalcError.OVERFLOW);
});

test('all 16 converter categories exact physical constant verification', () => {
  function conv(cat, fromId, toId, value) {
    const units = UnitConverter.unitsFor(cat);
    const f = units.find((u) => u.id === fromId);
    const t = units.find((u) => u.id === toId);
    return UnitConverter.convert(value, f, t, cat);
  }

  assertClose(conv(ConverterCategory.LENGTH, 'yd', 'in', 1.0), 36.0, 1e-12);
  assertClose(conv(ConverterCategory.LENGTH, 'nmi', 'm', 1.0), 1852.0, 1e-12);
  assertClose(conv(ConverterCategory.WEIGHT, 'st', 'lb', 1.0), 14.0, 1e-12);
  assertClose(conv(ConverterCategory.WEIGHT, 'lb', 'oz', 1.0), 16.0, 1e-12);
  assertClose(conv(ConverterCategory.WEIGHT, 'lb', 'g', 1.0), 453.59237, 1e-9);
  assertClose(conv(ConverterCategory.TEMPERATURE, 'c', 'f', 37.0), 98.6, 1e-12);
  assertClose(conv(ConverterCategory.TEMPERATURE, 'c', 'k', 37.0), 310.15, 1e-12);
  assertClose(conv(ConverterCategory.AREA, 'ac', 'ft2', 1.0), 43560.0, 1e-9);
  assertClose(conv(ConverterCategory.AREA, 'ac', 'yd2', 1.0), 4840.0, 1e-9);
  assertClose(conv(ConverterCategory.VOLUME, 'gal', 'floz', 1.0), 128.0, 1e-9);
  assertClose(conv(ConverterCategory.VOLUME, 'gal', 'tsp', 1.0), 768.0, 1e-9);
  assertClose(conv(ConverterCategory.SPEED, 'kmh', 'ms', 100.0), 100.0 / 3.6, 1e-12);
  assertClose(conv(ConverterCategory.SPEED, 'kn', 'kmh', 1.0), 1.852, 1e-12);
  assertClose(conv(ConverterCategory.TIME, 'yr', 'd', 1.0), 365.25, 1e-12);
  assertClose(conv(ConverterCategory.TIME, 'wk', 'h', 1.0), 168.0, 1e-12);
  assertClose(conv(ConverterCategory.DATA_STORAGE, 'tib', 'gib', 1.0), 1024.0, 1e-12);
  assertClose(conv(ConverterCategory.DATA_STORAGE, 'b', 'bit', 1.0), 8.0, 1e-12);
  assertClose(conv(ConverterCategory.PRESSURE, 'atm', 'kpa', 1.0), 101.325, 1e-12);
  assertClose(conv(ConverterCategory.PRESSURE, 'atm', 'bar', 1.0), 1.01325, 1e-12);
  assertClose(conv(ConverterCategory.ENERGY, 'kwh', 'kj', 1.0), 3600.0, 1e-12);
  assertClose(conv(ConverterCategory.ENERGY, 'kcal', 'j', 1.0), 4184.0, 1e-12);
  assertClose(conv(ConverterCategory.POWER, 'hp', 'w', 1.0), 745.6998715822702, 1e-9);
  assertClose(conv(ConverterCategory.POWER, 'btuh', 'w', 1000.0), 293.0710701722222, 1e-9);
  assertClose(conv(ConverterCategory.FORCE, 'kgf', 'n', 1.0), 9.80665, 1e-12);
  assertClose(conv(ConverterCategory.FORCE, 'n', 'dyn', 1.0), 100_000.0, 1e-9);
  assertClose(conv(ConverterCategory.ANGLE, 'rev', 'grad', 1.0), 400.0, 1e-9);
  assertClose(conv(ConverterCategory.ANGLE, 'rev', 'arcsec', 1.0), 1_296_000.0, 1e-6);
  assertClose(conv(ConverterCategory.FREQUENCY, 'ghz', 'khz', 1.0), 1_000_000.0, 1e-6);
  assert.equal(
    UnitConverter.convert(
      -5.0,
      UnitConverter.unitsFor(ConverterCategory.FUEL_ECONOMY)[0],
      UnitConverter.unitsFor(ConverterCategory.FUEL_ECONOMY)[1],
      ConverterCategory.FUEL_ECONOMY,
    ),
    null,
  );
  assertClose(conv(ConverterCategory.FUEL_ECONOMY, 'mpg_uk', 'mpg_us', 1.0), 3.785411784 / 4.54609, 1e-9);
  const usd = UnitConverter.unitsFor(ConverterCategory.CURRENCY).find((u) => u.id === 'usd');
  assertClose(UnitConverter.convert(100.0, usd, usd, ConverterCategory.CURRENCY, 5.0), 100.0, 1e-9);
});

test('tools edge cases and viewmodel backspace decimal sign and history result reuse', () => {
  assert.equal(ToolsEngine.average([1.0, Number.NaN]), null);
  assert.equal(ToolsEngine.average([1.0, Number.POSITIVE_INFINITY]), null);

  const fracNeg = ToolsEngine.fraction(1, -2, 1, -4, FractionOp.ADD);
  assert.equal(fracNeg.numerator, -3n);
  assert.equal(fracNeg.denominator, 4n);
  assert.equal(fracNeg.mixedWhole, 0n);

  const tdAbs = ToolsEngine.timeDuration(14, 0, 12, 30, false);
  assert.equal(tdAbs[0], 1);
  assert.equal(tdAbs[1], 30);

  const newborn = ToolsEngine.calculateAge(new SimpleDate(2026, 5, 1), new SimpleDate(2026, 5, 1));
  assert.equal(newborn.years, 0);
  assert.equal(newborn.totalDays, 0);
  assert.equal(newborn.daysUntilNextBirthday, 365);

  const eqPrice = ToolsEngine.unitPriceCompare(10.0, 5.0, 20.0, 10.0);
  assertClose(eqPrice[2], 0.0, 1e-12);

  const storage = new InMemoryStorage();
  const vm = new CalculatorStore(new HistoryStore({ storage }), new PreferencesStore({ storage }));

  vm.onScientificFunction('logBase(');
  assert.equal(vm.uiState.expression, 'logBase(');
  vm.onBackspace();
  assert.equal(vm.uiState.expression, '');

  vm.reuseHistoryResult({
    id: 1,
    expression: '1÷1e10',
    resultFormatted: '1×10^−10',
    resultRaw: '1E-10',
    angleMode: 'DEG',
    isScientific: false,
  });
  assert.equal(vm.uiState.expression, '1E-10');
  vm.onDecimal();
  assert.equal(vm.uiState.expression, '1E-10');

  vm.onClearAll();
  vm.onDigit('5');
  vm.onOperator('+');
  vm.reuseHistoryResult({
    id: 2,
    expression: '1−4',
    resultFormatted: '−3',
    resultRaw: '−3',
    angleMode: 'DEG',
    isScientific: false,
  });
  assert.equal(vm.uiState.expression, '5+(−3)');
  vm.onEquals();
  assert.equal(vm.uiState.resultText, '2');
});
