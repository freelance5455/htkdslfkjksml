import assert from 'node:assert/strict';
import test from 'node:test';
import { BigDecimal } from '../src/engine/bigDecimal.js';
import {
  AngleMode,
  CalculationEngine,
  isEvalSuccess,
} from '../src/engine/calculationEngine.js';
import { FormattingOptions, NumberGroupingStyle } from '../src/engine/numberFormatter.js';
import { ConverterCategories, UnitConverter } from '../src/engine/unitConverter.js';

const noGroup = new FormattingOptions({ grouping: NumberGroupingStyle.NONE });

function createRng(seedBigInt) {
  let state = seedBigInt & ((1n << 64n) - 1n);
  const nextInt32 = () => {
    state = (state * 6364136223846793005n + 1442695040888963407n) & ((1n << 64n) - 1n);
    return Number((state >> 32n) & 0xffffffffn);
  };
  return {
    nextDouble(min, max) {
      const u = nextInt32() / 4294967296.0;
      return min + u * (max - min);
    },
    nextInt(bound) {
      return nextInt32() % bound;
    },
    nextSignedInt(min, max) {
      return min + (nextInt32() % (max - min));
    },
  };
}

function evalVal(expr) {
  const res = CalculationEngine.evaluate(expr, AngleMode.DEG, noGroup);
  if (!isEvalSuccess(res)) {
    assert.fail(`Failed evaluating '${expr}': ${JSON.stringify(res, (_, v) => (typeof v === 'bigint' ? v.toString() : v))}`);
  }
  return res.value;
}

function fmtLiteral(v) {
  const s = v.toPlainString();
  return s.startsWith('-') ? `(−${s.slice(1)})` : s;
}

test('randomized arithmetic algebraic identities 500 seeds', () => {
  const rng = createRng(20261124n);
  for (let iter = 0; iter < 500; iter++) {
    const aUnscaled = BigInt(rng.nextSignedInt(-100_000_000, 100_000_000));
    const bUnscaled = BigInt(rng.nextSignedInt(-100_000_000, 100_000_000));
    const a = new BigDecimal(aUnscaled, rng.nextInt(5));
    const b = new BigDecimal(bUnscaled, rng.nextInt(5));
    const sa = fmtLiteral(a);
    const sb = fmtLiteral(b);

    const addAB = evalVal(`${sa}+${sb}`);
    const addBA = evalVal(`${sb}+${sa}`);
    assert.equal(addAB.compareTo(addBA), 0, `Add commutativity failed at iter=${iter}`);

    const mulAB = evalVal(`${sa}×${sb}`);
    const mulBA = evalVal(`${sb}×${sa}`);
    assert.equal(mulAB.compareTo(mulBA), 0, `Mul commutativity failed at iter=${iter}`);

    assert.equal(evalVal(`${sa}−0`).compareTo(a), 0, `a-0 failed at iter=${iter}`);
    assert.equal(evalVal(`${sa}×1`).compareTo(a), 0, `a*1 failed at iter=${iter}`);
    assert.equal(evalVal(`${sa}÷1`).compareTo(a), 0, `a/1 failed at iter=${iter}`);
    assert.equal(
      evalVal(`${sa}+(−${sa})`).compareTo(BigDecimal.ZERO),
      0,
      `a+(-a)=0 failed at iter=${iter}`,
    );
    assert.equal(evalVal(`${sa}×0`).compareTo(BigDecimal.ZERO), 0, `a*0=0 failed at iter=${iter}`);
  }
});

test('randomized unit converter round-trip consistency across all categories', () => {
  const rng = createRng(99887766n);
  const categories = ConverterCategories.filter((c) => !c.isCurrency);

  for (let iter = 0; iter < 320; iter++) {
    const cat = categories[iter % categories.length];
    const units = UnitConverter.unitsFor(cat);
    const uA = units[rng.nextInt(units.length)];
    const uB = units[rng.nextInt(units.length)];

    let raw;
    if (cat.name === 'TEMPERATURE') raw = rng.nextDouble(-200.0, 2000.0);
    else if (cat.name === 'FUEL_ECONOMY') raw = rng.nextDouble(1.0, 80.0);
    else raw = rng.nextDouble(0.001, 100_000.0);

    const forward = UnitConverter.convert(raw, uA, uB, cat);
    assert.ok(forward !== null, `Null forward at ${cat.name} ${uA.id}->${uB.id} val=${raw}`);
    const back = UnitConverter.convert(forward, uB, uA, cat);
    assert.ok(back !== null, `Null back at ${cat.name} ${uB.id}->${uA.id} val=${forward}`);

    const tol = Math.max(1e-7, Math.abs(raw) * 1e-9);
    assert.ok(
      Math.abs(raw - back) <= tol,
      `Round-trip mismatch ${cat.name} (${uA.id} -> ${uB.id}) iter=${iter}: ${raw} vs ${back}`,
    );
  }
});

test('long expression and rapid evaluation stress test', () => {
  const terms = Array.from({ length: 200 }, (_, i) => String(i + 1)).join('+');
  const res = CalculationEngine.evaluate(terms, AngleMode.DEG, noGroup);
  assert.ok(isEvalSuccess(res));
  assert.equal(res.value.compareTo(BigDecimal.parse('20100')), 0);

  const nested = '('.repeat(50) + '42' + ')'.repeat(50);
  const nestedRes = CalculationEngine.evaluate(nested);
  assert.ok(isEvalSuccess(nestedRes));
  assert.equal(nestedRes.formatted, '42');

  const startMs = Date.now();
  for (let k = 0; k < 1000; k++) {
    const r = CalculationEngine.evaluate(`(${k}+12.5)×sin(30)+√(144)`, AngleMode.DEG);
    assert.ok(isEvalSuccess(r));
  }
  const elapsedMs = Date.now() - startMs;
  assert.ok(elapsedMs < 5000, `1000 evaluations took too long: ${elapsedMs}ms`);
});
