import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { FormattingOptions, NumberFormatter } from '../src/engine/numberFormatter.js';
import { ToolGroups, ToolIds } from '../src/engine/toolsEngine.js';
import { ConverterCategories, UnitConverter } from '../src/engine/unitConverter.js';
import { InMemoryStorage, PreferencesStore } from '../src/state/storage.js';
import { createApp } from '../src/app.js';
import { APP_VERSION_CODE, APP_VERSION_NAME } from '../src/ui/settingsSheet.js';
import { mountToolForm, renderToolResultHtml } from '../src/ui/toolForms.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const WEB_ROOT = path.resolve(__dirname, '..');

// --- Minimal Self-Contained DOM Harness for Node UI Testing ---
function splitSelectorParts(selector) {
  const parts = [];
  let cur = '';
  let bracket = 0;
  for (let i = 0; i < selector.length; i++) {
    const ch = selector[i];
    if (ch === '[') bracket++;
    else if (ch === ']') bracket--;
    if (ch === ' ' && bracket === 0) {
      if (cur) parts.push(cur);
      cur = '';
    } else {
      cur += ch;
    }
  }
  if (cur) parts.push(cur);
  return parts;
}

function matchesSimpleSelector(el, sel) {
  if (!el || el.nodeType !== 1) return false;
  let rest = sel.trim();
  if (!rest) return false;

  const attrMatches = [];
  rest = rest.replace(/\[([^\]]+)\]/g, (_, expr) => {
    const eqIdx = expr.indexOf('=');
    if (eqIdx === -1) {
      attrMatches.push([expr.trim(), null]);
    } else {
      const k = expr.slice(0, eqIdx).trim();
      const v = expr.slice(eqIdx + 1).trim().replace(/^["']|["']$/g, '');
      attrMatches.push([k, v]);
    }
    return '';
  });

  const classes = [];
  rest = rest.replace(/\.([A-Za-z0-9_-]+)/g, (_, cls) => {
    classes.push(cls);
    return '';
  });

  let id = null;
  rest = rest.replace(/#([A-Za-z0-9_-]+)/g, (_, val) => {
    id = val;
    return '';
  });

  const tag = rest ? rest.toUpperCase() : null;
  if (tag && el.tagName !== tag) return false;
  if (id && el.id !== id) return false;
  for (const c of classes) {
    if (!el.classList.contains(c)) return false;
  }
  for (const [k, v] of attrMatches) {
    const actual = el.getAttribute(k);
    if (actual === null || actual === undefined) return false;
    if (v !== null && String(actual) !== v) return false;
  }
  return true;
}

function matchesSelector(el, selector) {
  const selectors = selector.split(',').map((s) => s.trim()).filter(Boolean);
  return selectors.some((sel) => {
    const parts = splitSelectorParts(sel);
    if (parts.length === 0) return false;
    if (!matchesSimpleSelector(el, parts[parts.length - 1])) return false;
    let cur = el.parentNode;
    for (let i = parts.length - 2; i >= 0; i--) {
      while (cur && !matchesSimpleSelector(cur, parts[i])) {
        cur = cur.parentNode;
      }
      if (!cur) return false;
      cur = cur.parentNode;
    }
    return true;
  });
}

function decodeHtmlEntities(str) {
  return str
    .replaceAll('&amp;', '&')
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>')
    .replaceAll('&quot;', '"')
    .replaceAll('&#39;', "'");
}

function parseAttributes(rawAttrs) {
  const attrs = {};
  const re = /([A-Za-z0-9_:-]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+)))?/g;
  let m;
  while ((m = re.exec(rawAttrs)) !== null) {
    attrs[m[1]] = m[2] ?? m[3] ?? m[4] ?? '';
  }
  return attrs;
}

const VOID_TAGS = new Set(['INPUT', 'META', 'LINK', 'BR', 'HR', 'PATH', 'CIRCLE', 'RECT', 'LINE', 'POLYLINE']);

function parseHtmlInto(parent, html) {
  parent.children = [];
  const stack = [parent];
  const tokenRe = /(<\/?[^>]+>)|([^<]+)/g;
  let m;
  while ((m = tokenRe.exec(html)) !== null) {
    const tagTok = m[1];
    const textTok = m[2];
    if (textTok !== undefined) {
      const top = stack[stack.length - 1];
      top._appendText(decodeHtmlEntities(textTok));
      continue;
    }
    if (tagTok.startsWith('</')) {
      if (stack.length > 1) stack.pop();
      continue;
    }
    const selfClosing = tagTok.endsWith('/>');
    const inner = tagTok.slice(1, selfClosing ? -2 : -1).trim();
    const spaceIdx = inner.search(/\s/);
    const tagName = (spaceIdx === -1 ? inner : inner.slice(0, spaceIdx)).toUpperCase();
    const attrStr = spaceIdx === -1 ? '' : inner.slice(spaceIdx + 1);
    const attrs = parseAttributes(attrStr);

    const el = new FakeElement(tagName, parent.ownerDocument);
    for (const [k, v] of Object.entries(attrs)) {
      el.setAttribute(k, v);
    }
    if (tagName === 'INPUT' || tagName === 'TEXTAREA') {
      el.value = attrs.value ?? '';
    }
    stack[stack.length - 1].appendChild(el);
    if (!selfClosing && !VOID_TAGS.has(tagName)) {
      stack.push(el);
    }
  }
}

class FakeClassList {
  constructor(el) {
    this.el = el;
  }
  _set() {
    const raw = this.el.attrs.class || '';
    return new Set(raw.split(/\s+/).filter(Boolean));
  }
  _save(set) {
    this.el.attrs.class = Array.from(set).join(' ');
  }
  add(...names) {
    const s = this._set();
    for (const n of names) if (n) s.add(n);
    this._save(s);
  }
  remove(...names) {
    const s = this._set();
    for (const n of names) s.delete(n);
    this._save(s);
  }
  toggle(name, force) {
    const s = this._set();
    const has = s.has(name);
    const next = force !== undefined ? Boolean(force) : !has;
    if (next) s.add(name);
    else s.delete(name);
    this._save(s);
    return next;
  }
  contains(name) {
    return this._set().has(name);
  }
}

class FakeEvent {
  constructor(type, { target, key, bubbles = true } = {}) {
    this.type = type;
    this.target = target;
    this.currentTarget = target;
    this.key = key;
    this.bubbles = bubbles;
    this.defaultPrevented = false;
    this._stopped = false;
  }
  preventDefault() {
    this.defaultPrevented = true;
  }
  stopPropagation() {
    this._stopped = true;
  }
}

class FakeElement {
  constructor(tagName, ownerDocument) {
    this.nodeType = 1;
    this.tagName = tagName.toUpperCase();
    this.ownerDocument = ownerDocument;
    this.attrs = {};
    this.dataset = {};
    this.children = [];
    this.parentNode = null;
    this.style = {};
    this._text = '';
    this.value = '';
    this.scrollLeft = 0;
    this.scrollWidth = 100;
    this.listeners = new Map();
    this.classList = new FakeClassList(this);
  }

  get id() {
    return this.attrs.id ?? '';
  }
  set id(v) {
    this.attrs.id = String(v);
  }

  get className() {
    return this.attrs.class ?? '';
  }
  set className(v) {
    this.attrs.class = String(v);
  }

  get textContent() {
    if (this.children.length === 0) return this._text;
    return this._text + this.children.map((c) => c.textContent).join('');
  }
  set textContent(v) {
    this.children = [];
    this._text = String(v ?? '');
  }

  get innerHTML() {
    return this.children.map((c) => `<${c.tagName.toLowerCase()}>${c.textContent}</${c.tagName.toLowerCase()}>`).join('');
  }
  set innerHTML(html) {
    this._text = '';
    parseHtmlInto(this, String(html ?? ''));
    if (this.tagName === 'TEXTAREA') {
      this.value = this.textContent;
    }
  }

  _appendText(str) {
    if (this.children.length === 0) {
      this._text += str;
    } else {
      const span = new FakeElement('span', this.ownerDocument);
      span._text = str;
      this.appendChild(span);
    }
  }

  setAttribute(name, value) {
    const val = String(value);
    this.attrs[name] = val;
    if (name.startsWith('data-')) {
      const camel = name
        .slice(5)
        .replace(/-([a-z0-9])/g, (_, ch) => ch.toUpperCase());
      this.dataset[camel] = val;
    }
  }

  getAttribute(name) {
    return Object.prototype.hasOwnProperty.call(this.attrs, name) ? this.attrs[name] : null;
  }

  appendChild(child) {
    child.parentNode = this;
    this.children.push(child);
    return child;
  }

  remove() {
    if (this.parentNode) {
      this.parentNode.children = this.parentNode.children.filter((c) => c !== this);
      this.parentNode = null;
    }
  }

  contains(node) {
    let cur = node;
    while (cur) {
      if (cur === this) return true;
      cur = cur.parentNode;
    }
    return false;
  }

  closest(selector) {
    let cur = this;
    while (cur && cur.nodeType === 1) {
      if (matchesSelector(cur, selector)) return cur;
      cur = cur.parentNode;
    }
    return null;
  }

  querySelectorAll(selector) {
    const out = [];
    const walk = (node) => {
      for (const ch of node.children) {
        if (matchesSelector(ch, selector)) out.push(ch);
        walk(ch);
      }
    };
    walk(this);
    return out;
  }

  querySelector(selector) {
    return this.querySelectorAll(selector)[0] ?? null;
  }

  addEventListener(type, fn) {
    if (!this.listeners.has(type)) this.listeners.set(type, new Set());
    this.listeners.get(type).add(fn);
  }

  removeEventListener(type, fn) {
    this.listeners.get(type)?.delete(fn);
  }

  dispatchEvent(ev) {
    ev.target = ev.target ?? this;
    let cur = this;
    while (cur) {
      ev.currentTarget = cur;
      const set = cur.listeners?.get(ev.type);
      if (set) {
        for (const fn of Array.from(set)) {
          fn(ev);
        }
      }
      if (!ev.bubbles || ev._stopped) break;
      cur = cur.parentNode;
    }
    return !ev.defaultPrevented;
  }

  click() {
    this.dispatchEvent(new FakeEvent('click', { target: this, bubbles: true }));
  }
}

class FakeDocument {
  constructor() {
    this.nodeType = 9;
    this.listeners = new Map();
    this.documentElement = new FakeElement('html', this);
    this.head = new FakeElement('head', this);
    this.body = new FakeElement('body', this);
    this.documentElement.appendChild(this.head);
    this.documentElement.appendChild(this.body);

    const meta = this.createElement('meta');
    meta.setAttribute('name', 'theme-color');
    meta.setAttribute('content', '#0B0B0F');
    this.head.appendChild(meta);
  }

  createElement(tag) {
    return new FakeElement(tag, this);
  }

  getElementById(id) {
    return this.querySelector(`#${id}`);
  }

  querySelector(selector) {
    return this.documentElement.querySelector(selector);
  }

  querySelectorAll(selector) {
    return this.documentElement.querySelectorAll(selector);
  }

  addEventListener(type, fn) {
    if (!this.listeners.has(type)) this.listeners.set(type, new Set());
    this.listeners.get(type).add(fn);
  }

  removeEventListener(type, fn) {
    this.listeners.get(type)?.delete(fn);
  }

  dispatchEvent(ev) {
    const set = this.listeners.get(ev.type);
    if (set) {
      for (const fn of Array.from(set)) fn(ev);
    }
  }

  execCommand() {
    return true;
  }
}

function setupFakeDom() {
  const prevDoc = globalThis.document;
  const prevLocalStorage = globalThis.localStorage;
  const prevNavigatorDesc = Object.getOwnPropertyDescriptor(globalThis, 'navigator');

  const doc = new FakeDocument();
  const memStorage = new InMemoryStorage();
  let lastCopied = null;
  let vibratedCount = 0;

  globalThis.document = doc;
  globalThis.localStorage = memStorage;
  Object.defineProperty(globalThis, 'navigator', {
    configurable: true,
    value: {
      clipboard: {
        writeText: async (text) => {
          lastCopied = text;
        },
      },
      vibrate: () => {
        vibratedCount++;
        return true;
      },
    },
  });

  const rootEl = doc.createElement('div');
  rootEl.id = 'app';
  doc.body.appendChild(rootEl);

  return {
    doc,
    rootEl,
    memStorage,
    getLastCopied: () => lastCopied,
    getVibratedCount: () => vibratedCount,
    teardown() {
      globalThis.document = prevDoc;
      globalThis.localStorage = prevLocalStorage;
      if (prevNavigatorDesc) {
        Object.defineProperty(globalThis, 'navigator', prevNavigatorDesc);
      } else {
        delete globalThis.navigator;
      }
    },
  };
}

// --- Tests ---

test('static asset integrity: html, manifest, sw cache, and Aether theme tokens', () => {
  const indexHtml = fs.readFileSync(path.join(WEB_ROOT, 'index.html'), 'utf8');
  for (const rel of ['./favicon.svg', './manifest.webmanifest', './styles/tokens.css', './styles/app.css', './src/app.js']) {
    assert.ok(indexHtml.includes(rel), `index.html missing ${rel}`);
    assert.ok(fs.existsSync(path.join(WEB_ROOT, rel)), `Referenced file missing: ${rel}`);
  }

  const manifest = JSON.parse(fs.readFileSync(path.join(WEB_ROOT, 'manifest.webmanifest'), 'utf8'));
  assert.equal(manifest.name, 'Calculator');
  assert.equal(manifest.version, '1.2');
  for (const icon of manifest.icons) {
    assert.ok(fs.existsSync(path.join(WEB_ROOT, icon.src)), `Manifest icon missing: ${icon.src}`);
  }

  const swText = fs.readFileSync(path.join(WEB_ROOT, 'sw.js'), 'utf8');
  assert.ok(swText.includes("CACHE_NAME = 'aether-calculator-v1.2'"), 'sw.js must use v1.2 cache name');
  const assetMatches = [...swText.matchAll(/'(\.\/[^']+)'/g)].map((m) => m[1]);
  assert.ok(assetMatches.length >= 20, 'Expected complete ASSETS list in sw.js');
  for (const asset of assetMatches) {
    if (asset === './') continue;
    assert.ok(fs.existsSync(path.join(WEB_ROOT, asset)), `SW cached asset missing on disk: ${asset}`);
  }

  const tokensCss = fs.readFileSync(path.join(WEB_ROOT, 'styles/tokens.css'), 'utf8');
  for (const token of ['OLED_DARK', 'AETHER_DARK', 'LIGHT', '#0b0b0f', '#13131a', '#f7f7fa', '#8b5cf6', '#7c3aed', '#b9a0ff', '#5b21b6']) {
    assert.ok(tokensCss.toLowerCase().includes(token.toLowerCase()), `tokens.css missing ${token}`);
  }

  const appCss = fs.readFileSync(path.join(WEB_ROOT, 'styles/app.css'), 'utf8');
  assert.ok(appCss.includes('@media (min-width: 600px)'), 'Missing responsive navigation rail breakpoint');
  assert.ok(appCss.includes('max-width: 560px'), 'Missing canonical centered stage width');
  assert.ok(appCss.includes('touch-action: manipulation'), 'Missing touch-action manipulation for instant key taps');
  assert.ok(appCss.includes('@media (prefers-reduced-motion: reduce)'), 'Missing reduced-motion accessibility support');
  assert.ok(appCss.includes('.tactile-key.accent.is-pressed'), 'Missing pressed style parity for accent keys');
  assert.ok(appCss.includes('.is-hidden'), 'Missing .is-hidden utility class');
  assert.ok(!appCss.includes('grid-template-rows: 0fr'), 'Layout-thrashing grid-template-rows sci drawer should be replaced');

  const appJs = fs.readFileSync(path.join(WEB_ROOT, 'src/app.js'), 'utf8');
  assert.ok(!/splash|onboard|welcome|intro/i.test(appJs), 'app.js must not contain intro/splash/onboarding logic');
  assert.equal(APP_VERSION_NAME, '1.2');
  assert.equal(APP_VERSION_CODE, 3);
});

test('all 21 tools mount cleanly in DOM, filter inputs, toggle chips, and format results', (t) => {
  const env = setupFakeDom();
  t.after(() => env.teardown());

  const prefs = new PreferencesStore(new InMemoryStorage());
  const fmt = new FormattingOptions();

  assert.equal(ToolIds.length, 21);
  assert.equal(ToolGroups.length, 3);

  for (const tool of ToolIds) {
    const host = env.doc.createElement('div');
    let copied = null;
    const unmount = mountToolForm(host, {
      toolId: tool,
      preferencesStore: prefs,
      onCopyResult: (val) => {
        copied = val;
      },
    });
    const resultCard = host.querySelector('[data-slot="result-card"]');
    assert.ok(resultCard, `Missing result card for ${tool.name}`);
    assert.ok(resultCard.textContent.trim().length > 0, `Empty result card for ${tool.name}`);
    assert.ok(!resultCard.textContent.includes('NaN') && !resultCard.textContent.includes('undefined'), `Invalid text in ${tool.name}: ${resultCard.textContent}`);

    // Verify copy button inside result card works when present
    const copyBtn = resultCard.querySelector('[data-copy]');
    if (copyBtn) {
      copyBtn.click();
      assert.ok(copied && copied.length > 0, `Copy callback failed on ${tool.name}`);
    }
    unmount();
  }

  // Test interactive chip toggle & invalid input handling on FRACTION
  const fracTool = ToolIds.find((x) => x.name === 'FRACTION');
  const host = env.doc.createElement('div');
  const unmountFrac = mountToolForm(host, {
    toolId: fracTool,
    preferencesStore: prefs,
    onCopyResult: () => {},
  });
  const d1Input = host.querySelector('[data-field="d1"]');
  d1Input.value = '0abc';
  d1Input.dispatchEvent(new FakeEvent('input', { target: d1Input }));
  assert.equal(d1Input.value, '0');
  assert.ok(host.querySelector('[data-slot="result-card"]').textContent.includes('cannot be zero'));

  d1Input.value = '4';
  d1Input.dispatchEvent(new FakeEvent('input', { target: d1Input }));
  host.querySelector('[data-chip="fracOp"][data-key="MUL"]').click();
  assert.ok(host.querySelector('[data-slot="result-card"]').textContent.includes('3/10'));
  unmountFrac();

  // Verify renderToolResultHtml directly for RATIO with 64-bit numbers and UNIT_PRICE tie
  const ratioHtml = renderToolResultHtml(
    ToolIds.find((x) => x.name === 'RATIO'),
    { valA: '9223372036854775806', valB: '2', scaleC: '' },
    fmt,
  );
  assert.ok(ratioHtml.includes('4611686018427387903 : 1'));

  const tieHtml = renderToolResultHtml(
    ToolIds.find((x) => x.name === 'UNIT_PRICE'),
    { pA: '10', qA: '2', pB: '20', qB: '4' },
    fmt,
  );
  assert.ok(tieHtml.includes('equal unit price'));
});

test('full app DOM harness: navigation, calculator, sci, memory, history, settings themes, converter, tools, and persistence', (t) => {
  const env = setupFakeDom();
  t.after(() => env.teardown());

  const app = createApp(env.rootEl);

  // 0. Opens immediately to Calculator screen with zero splash/onboarding/welcome overlays
  assert.ok(env.rootEl.querySelector('[data-testid="nav_calculator"]').classList.contains('active'));
  assert.equal(env.rootEl.querySelector('[data-testid="calc_expression_display"]').textContent, '0');
  assert.ok(env.rootEl.querySelector('[data-testid="key_equals"]'));
  assert.equal(env.doc.getElementById('aether-history-sheet'), null);
  assert.equal(env.doc.getElementById('aether-settings-sheet'), null);

  // Pointer tactile press feedback registers input immediately on pointerdown, clears on pointerup, and deduplicates synthetic click
  const key7 = env.rootEl.querySelector('[data-testid="key_7"]');
  key7.dispatchEvent(new FakeEvent('pointerdown', { target: key7, bubbles: true }));
  assert.ok(key7.classList.contains('is-pressed'));
  assert.equal(env.rootEl.querySelector('[data-testid="calc_expression_display"]').textContent, '7');
  key7.dispatchEvent(new FakeEvent('pointerup', { target: key7, bubbles: true }));
  assert.ok(!key7.classList.contains('is-pressed'));
  key7.click();
  assert.equal(env.rootEl.querySelector('[data-testid="calc_expression_display"]').textContent, '7');
  env.rootEl.querySelector('[data-testid="key_ac"]').click();

  // Physical keyboard shortcut calculates immediately and pulses matching keycap
  env.doc.dispatchEvent(new FakeEvent('keydown', { key: '9' }));
  assert.ok(env.rootEl.querySelector('[data-testid="key_9"]').classList.contains('is-pressed'));
  assert.equal(env.rootEl.querySelector('[data-testid="calc_expression_display"]').textContent, '9');
  env.rootEl.querySelector('[data-testid="key_ac"]').click();

  // 1. Both mobile bottom bar and nav rail exist and stay synced
  const click = (testId) => {
    const el = env.rootEl.querySelector(`[data-testid="${testId}"]`);
    assert.ok(el, `Missing element with data-testid="${testId}"`);
    el.click();
    return el;
  };

  assert.equal(env.rootEl.querySelectorAll('[data-slot="nav-rail"] .nav-item').length, 3);
  assert.equal(env.rootEl.querySelectorAll('[data-slot="bottom-nav-inner"] .nav-item').length, 3);

  // 2. Calculator interactions: 2 + 3 × 4 = 14
  click('key_2');
  click('key_add');
  click('key_3');
  click('key_mul');
  click('key_4');
  assert.equal(env.rootEl.querySelector('[data-testid="calc_result_display"]').textContent, '14');
  click('key_equals');
  assert.equal(env.rootEl.querySelector('[data-testid="calc_expression_display"]').textContent, '2+3×4');
  assert.equal(env.rootEl.querySelector('[data-testid="calc_result_display"]').textContent, '14');

  // 3. Memory M+, pill, M-, MR, MC
  click('mem_mplus');
  assert.ok(env.rootEl.querySelector('[data-testid="memory_active_indicator"]').textContent.includes('14'));
  click('key_ac');
  click('mem_mr');
  assert.equal(env.rootEl.querySelector('[data-testid="calc_expression_display"]').textContent, '14');

  // 4. Scientific drawer toggles (Sci -> 2nd -> HYP -> DEG/RAD -> cosh(0)=1)
  click('toggle_scientific_button');
  assert.ok(env.rootEl.querySelector('[data-slot="sci-drawer"]').classList.contains('open'));
  assert.equal(env.rootEl.querySelector('[data-testid="angle_mode_indicator"]').textContent, 'DEG');
  click('sci_deg_rad');
  assert.equal(env.rootEl.querySelector('[data-testid="angle_mode_indicator"]').textContent, 'RAD');
  click('sci_2nd');
  assert.ok(env.rootEl.querySelector('[data-testid="sci_key_sin⁻¹"]'));
  click('sci_hyp');
  assert.ok(env.rootEl.querySelector('[data-testid="sci_key_cosh"]'));
  click('key_ac');
  click('sci_key_cosh');
  click('key_0');
  click('sci_rparen');
  click('key_equals');
  assert.equal(env.rootEl.querySelector('[data-testid="calc_result_display"]').textContent, '1');

  // 5. History sheet open, reuse, delete, clear all
  click('open_history_button');
  const historySheet = env.doc.getElementById('aether-history-sheet');
  assert.ok(historySheet, 'History sheet did not open');
  assert.equal(historySheet.querySelectorAll('.history-card').length, 2);
  // Reuse older expression '2+3×4'
  historySheet.querySelectorAll('[data-action="reuse"]')[1].click();
  assert.equal(env.doc.getElementById('aether-history-sheet'), null);
  assert.equal(env.rootEl.querySelector('[data-testid="calc_expression_display"]').textContent, '2+3×4');

  // Reopen and clear all
  click('open_history_button');
  env.doc.getElementById('aether-history-sheet').querySelector('[data-testid="clear_history_button"]').click();
  env.doc.getElementById('aether-history-sheet').querySelector('[data-action="do-clear"]').click();
  assert.ok(env.doc.getElementById('aether-history-sheet').textContent.includes('No calculations yet'));
  // Close history sheet with Escape
  env.doc.dispatchEvent(new FakeEvent('keydown', { key: 'Escape' }));
  assert.equal(env.doc.getElementById('aether-history-sheet'), null);

  // 6. Settings sheet: About v1.2 (3), themes (Slate Dark, Light, OLED Dark), grouping, precision, haptics
  click('open_settings_button');
  const settingsSheet = env.doc.getElementById('aether-settings-sheet');
  assert.ok(settingsSheet, 'Settings sheet did not open');
  assert.equal(settingsSheet.querySelector('[data-testid="settings_app_version"]').textContent, 'v1.2 (3)');

  settingsSheet.querySelector('[data-testid="theme_option_AETHER_DARK"]').click();
  assert.equal(env.doc.documentElement.getAttribute('data-theme'), 'AETHER_DARK');
  assert.equal(env.doc.querySelector('meta[name="theme-color"]').getAttribute('content'), '#13131A');

  settingsSheet.querySelector('[data-testid="theme_option_LIGHT"]').click();
  assert.equal(env.doc.documentElement.getAttribute('data-theme'), 'LIGHT');
  assert.equal(env.doc.querySelector('meta[name="theme-color"]').getAttribute('content'), '#F7F7FA');

  // Toggle precision to 2 and space grouping
  settingsSheet.querySelector('[data-action="grouping"][data-val="SPACE"]').click();
  settingsSheet.querySelector('[data-action="precision"][data-val="2"]').click();
  assert.equal(env.rootEl.querySelector('[data-testid="calc_result_display"]').textContent, '14.00');

  // Toggle haptics off and verify vibrate count stops increasing
  const beforeVib = env.getVibratedCount();
  settingsSheet.querySelector('[data-testid="haptics_switch"]').click();
  assert.equal(settingsSheet.querySelector('[data-testid="haptics_switch"]').getAttribute('aria-checked'), 'false');
  settingsSheet.querySelector('[data-action="close"]').click();
  assert.equal(env.doc.getElementById('aether-settings-sheet'), null);
  click('key_5');
  assert.equal(env.getVibratedCount(), beforeVib);

  // 7. Convert tab: verify all 16 categories, keypad, swap, currency custom rate
  click('nav_convert');
  for (const cat of ConverterCategories) {
    click(`converter_cat_${cat.name}`);
    const fromOpts = env.rootEl.querySelectorAll('[data-testid="unit_picker_from"] option');
    assert.equal(fromOpts.length, UnitConverter.unitsFor(cat).length, `Missing unit options for ${cat.name}`);
  }
  click('converter_cat_LENGTH');
  click('conv_key_clear');
  click('conv_key_1');
  click('conv_key_0');
  click('conv_key_0');
  click('conv_key_0');
  assert.equal(env.rootEl.querySelector('[data-testid="converter_from_value"]').textContent, '1000');
  click('converter_swap_button');
  assert.equal(env.rootEl.querySelector('[data-testid="converter_to_value"]').textContent, '304.80');

  click('converter_cat_CURRENCY');
  const rateInput = env.rootEl.querySelector('[data-slot="custom-rate-input"]');
  assert.ok(rateInput, 'Missing custom currency rate input');
  rateInput.value = '2.5';
  rateInput.dispatchEvent(new FakeEvent('input', { target: rateInput }));
  assert.ok(env.rootEl.querySelector('[data-slot="rate-label"]').textContent.includes('2.5'));

  // 8. Tools tab: filter groups, open a tool, navigate back
  click('nav_tools');
  assert.equal(env.rootEl.querySelectorAll('.tool-row').length, 21);
  env.rootEl.querySelector('[data-action="filter-group"][data-group="FINANCE"]').click();
  assert.equal(env.rootEl.querySelectorAll('.tool-row').length, 3);
  click('tool_row_EMI_CALCULATOR');
  assert.ok(env.rootEl.querySelector('[data-slot="tool-form-host"]'));
  click('tool_back_button');
  assert.equal(env.rootEl.querySelectorAll('.tool-row').length, 3);

  // 9. Rapid tab switching retains Convert & Tools DOM state with zero rebuilds
  click('nav_convert');
  click('nav_tools');
  click('nav_calculator');
  click('nav_tools');
  assert.equal(env.rootEl.querySelectorAll('.tool-row').length, 3);
  click('nav_convert');
  assert.ok(env.rootEl.querySelector('[data-testid="converter_cat_CURRENCY"]').classList.contains('selected'));

  // 10. Rapid keypad sequence via pointerdown+pointerup+click never loses or duplicates digits
  click('nav_calculator');
  click('key_ac');
  const tapKey = (testId) => {
    const el = env.rootEl.querySelector(`[data-testid="${testId}"]`);
    el.dispatchEvent(new FakeEvent('pointerdown', { target: el, bubbles: true }));
    el.dispatchEvent(new FakeEvent('pointerup', { target: el, bubbles: true }));
    el.click();
  };
  for (const tid of ['key_1', 'key_2', 'key_3', 'key_add', 'key_4', 'key_5', 'key_6', 'key_equals']) {
    tapKey(tid);
  }
  assert.equal(env.rootEl.querySelector('[data-testid="calc_result_display"]').textContent, '579.00');

  // 11. Verify persistence across fresh app boot sharing same localStorage
  const rootEl2 = env.doc.createElement('div');
  env.doc.body.appendChild(rootEl2);
  const app2 = createApp(rootEl2);
  assert.equal(app2.preferencesStore.value.themeMode.name, 'LIGHT');
  assert.equal(app2.preferencesStore.value.groupingStyle.name, 'SPACE');
  assert.equal(app2.preferencesStore.value.decimalPrecision, 2);
  assert.equal(app2.preferencesStore.value.hapticEnabled, false);
  assert.ok(app2.calcStore.uiState.hasMemory);
  assert.equal(app2.calcStore.uiState.memoryFormatted, '14.00');
  void app;
});
