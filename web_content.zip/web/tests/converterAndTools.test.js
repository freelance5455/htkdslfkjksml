import assert from 'node:assert/strict';
import test from 'node:test';
import { DeterministicMathSolver, GraphSampler } from '../src/engine/futureEngines.js';
import { NumberFormatter } from '../src/engine/numberFormatter.js';
import {
  CompoundingFrequency,
  FractionOp,
  MotionTarget,
  SimpleDate,
  ToolsEngine,
} from '../src/engine/toolsEngine.js';
import { ConverterCategories, ConverterCategory, UnitConverter } from '../src/engine/unitConverter.js';

function assertClose(actual, expected, tol = 1e-9, msg = '') {
  assert.ok(actual !== null && actual !== undefined, `Expected number, got ${actual} (${msg})`);
  assert.ok(
    Math.abs(actual - expected) <= tol,
    `${msg}: expected ${expected} ± ${tol}, got ${actual}`,
  );
}

test('all 16 converter categories basic reverse same-unit and zero', () => {
  assert.equal(ConverterCategories.length, 16);
  for (const category of ConverterCategories) {
    const units = UnitConverter.unitsFor(category);
    assert.ok(units.length >= 2, `Category ${category.name} should have >=2 units`);
    const u0 = units[0];
    const u1 = units[1];

    assertClose(UnitConverter.convert(42.5, u0, u0, category), 42.5, 1e-9);

    const testVal = 123.456;
    const forward = UnitConverter.convert(testVal, u0, u1, category);
    const back = UnitConverter.convert(forward, u1, u0, category);
    assertClose(back, testVal, 1e-6, `Round-trip failed for ${category.name}`);

    if (category.name !== 'FUEL_ECONOMY') {
      const zeroFwd = UnitConverter.convert(0.0, u0, u1, category);
      const zeroBack = UnitConverter.convert(zeroFwd, u1, u0, category);
      assertClose(zeroBack, 0.0, 1e-9, `Zero round-trip failed for ${category.name}`);
    }
  }
});

test('temperature exact formulas and negative values', () => {
  const units = UnitConverter.unitsFor(ConverterCategory.TEMPERATURE);
  const c = units.find((u) => u.id === 'c');
  const f = units.find((u) => u.id === 'f');
  const k = units.find((u) => u.id === 'k');

  assertClose(UnitConverter.convert(0.0, c, f, ConverterCategory.TEMPERATURE), 32.0);
  assertClose(UnitConverter.convert(100.0, c, f, ConverterCategory.TEMPERATURE), 212.0);
  assertClose(UnitConverter.convert(-40.0, c, f, ConverterCategory.TEMPERATURE), -40.0);
  assertClose(UnitConverter.convert(0.0, c, k, ConverterCategory.TEMPERATURE), 273.15);
  assertClose(UnitConverter.convert(0.0, k, c, ConverterCategory.TEMPERATURE), -273.15);
  assertClose(UnitConverter.convert(0.0, k, f, ConverterCategory.TEMPERATURE), -459.67);
});

test('data storage decimal vs binary and energy eV precision', () => {
  const data = UnitConverter.unitsFor(ConverterCategory.DATA_STORAGE);
  const bit = data.find((u) => u.id === 'bit');
  const byte = data.find((u) => u.id === 'b');
  const kb = data.find((u) => u.id === 'kb');
  const kib = data.find((u) => u.id === 'kib');
  const gb = data.find((u) => u.id === 'gb');
  const gib = data.find((u) => u.id === 'gib');

  assertClose(UnitConverter.convert(1.0, byte, bit, ConverterCategory.DATA_STORAGE), 8.0);
  assertClose(UnitConverter.convert(1.0, kb, byte, ConverterCategory.DATA_STORAGE), 1000.0);
  assertClose(UnitConverter.convert(1.0, kib, byte, ConverterCategory.DATA_STORAGE), 1024.0);
  assertClose(UnitConverter.convert(1.0, gb, byte, ConverterCategory.DATA_STORAGE), 1_000_000_000.0, 1e-3);
  assertClose(UnitConverter.convert(1.0, gib, byte, ConverterCategory.DATA_STORAGE), 1_073_741_824.0, 1e-3);

  const energy = UnitConverter.unitsFor(ConverterCategory.ENERGY);
  const ev = energy.find((u) => u.id === 'ev');
  const j = energy.find((u) => u.id === 'j');
  const joules = UnitConverter.convert(1.0, ev, j, ConverterCategory.ENERGY);
  assertClose(joules, 1.602176634e-19, 1e-28);
  assert.equal(NumberFormatter.formatDouble(joules), '1.602176634×10^−19');
});

test('fuel economy reciprocal and zero handling and custom currency rate', () => {
  const fuel = UnitConverter.unitsFor(ConverterCategory.FUEL_ECONOMY);
  const kml = fuel.find((u) => u.id === 'kml');
  const l100 = fuel.find((u) => u.id === 'l100km');
  const mpgUs = fuel.find((u) => u.id === 'mpg_us');

  assertClose(UnitConverter.convert(20.0, kml, l100, ConverterCategory.FUEL_ECONOMY), 5.0);
  assertClose(UnitConverter.convert(5.0, l100, kml, ConverterCategory.FUEL_ECONOMY), 20.0);
  assert.equal(UnitConverter.convert(0.0, kml, l100, ConverterCategory.FUEL_ECONOMY), null);
  assert.equal(UnitConverter.convert(0.0, l100, kml, ConverterCategory.FUEL_ECONOMY), null);
  assertClose(UnitConverter.convert(0.0, kml, mpgUs, ConverterCategory.FUEL_ECONOMY), 0.0);

  const curr = UnitConverter.unitsFor(ConverterCategory.CURRENCY);
  const usd = curr.find((u) => u.id === 'usd');
  const eur = curr.find((u) => u.id === 'eur');
  assertClose(UnitConverter.convert(100.0, usd, eur, ConverterCategory.CURRENCY, 0.92), 92.0);
  assert.equal(UnitConverter.convert(100.0, usd, eur, ConverterCategory.CURRENCY, -1.0), null);
});

test('tools engine all 21 calculators and edge cases', () => {
  assertClose(ToolsEngine.percentOf(15.0, 200.0), 30.0);
  assertClose(ToolsEngine.percentChange(80.0, 100.0)[0], 25.0);
  assert.equal(ToolsEngine.percentChange(0.0, 100.0), null);
  assertClose(ToolsEngine.increaseByPercent(100.0, 15.0)[0], 115.0);
  assertClose(ToolsEngine.decreaseByPercent(100.0, 15.0)[0], 85.0);
  assertClose(ToolsEngine.percentDifference(80.0, 100.0), 22.222222222, 1e-6);
  assertClose(ToolsEngine.percentDifference(0.0, 0.0), 0.0);

  const [siInt, siTot] = ToolsEngine.simpleInterest(10000.0, 6.5, 3.0);
  assertClose(siInt, 1950.0);
  assertClose(siTot, 11950.0);

  const [ciInt, ciTot] = ToolsEngine.compoundInterest(10000.0, 12.0, 1.0, CompoundingFrequency.MONTHLY);
  assertClose(ciTot, 11268.250301319697, 1e-6);
  assertClose(ciInt, 1268.250301319697, 1e-6);
  assertClose(ToolsEngine.compoundInterest(10000.0, 0.0, 5.0, CompoundingFrequency.QUARTERLY)[1], 10000.0);

  const emiStd = ToolsEngine.calculateEmi(100000.0, 12.0, 12);
  assertClose(emiStd[0], 8884.878868, 1e-4);
  assertClose(emiStd[2], emiStd[0] * 12.0, 1e-4);
  assertClose(emiStd[1], emiStd[2] - 100000.0, 1e-4);

  const emiZero = ToolsEngine.calculateEmi(120000.0, 0.0, 12);
  assertClose(emiZero[0], 10000.0);
  assertClose(emiZero[1], 0.0);

  assert.equal(ToolsEngine.calculateEmi(100000.0, 12.0, 0), null);
  const emiExtreme = ToolsEngine.calculateEmi(100000.0, 120.0, 10000);
  assert.ok(emiExtreme !== null && !Number.isNaN(emiExtreme[0]));

  assertClose(ToolsEngine.discount(120.0, 25.0)[1], 90.0);
  const [saved, taxAmt, checkout] = ToolsEngine.salePrice(150.0, 20.0, 8.0);
  assertClose(saved, 30.0);
  assertClose(taxAmt, 9.6);
  assertClose(checkout, 129.6);

  const [exclBase, exclTax, exclTot] = ToolsEngine.taxGst(1000.0, 18.0, false);
  assertClose(exclBase, 1000.0);
  assertClose(exclTax, 180.0);
  assertClose(exclTot, 1180.0);

  const [inclBase, inclTax, inclTot] = ToolsEngine.taxGst(1180.0, 18.0, true);
  assertClose(inclBase, 1000.0);
  assertClose(inclTax, 180.0);
  assertClose(inclTot, 1180.0);

  const [tipAmt, billTot, perPerson] = ToolsEngine.tipAndSplit(120.0, 15.0, 4);
  assertClose(tipAmt, 18.0);
  assertClose(billTot, 138.0);
  assertClose(perPerson, 34.5);
  assert.equal(ToolsEngine.tipAndSplit(100.0, 15.0, 0), null);

  const ratioRes = ToolsEngine.ratio(1920, 1080, 1280.0);
  assert.deepEqual(ratioRes[0], [16n, 9n]);
  assertClose(ratioRes[1], 720.0);

  const avg = ToolsEngine.average([10.0, 20.0, 30.0, 40.0]);
  assert.equal(avg.count, 4);
  assertClose(avg.sum, 100.0);
  assertClose(avg.mean, 25.0);
  assertClose(avg.median, 25.0);
  assertClose(avg.min, 10.0);
  assertClose(avg.max, 40.0);

  const fAdd = ToolsEngine.fraction(3, 4, 2, 5, FractionOp.ADD);
  assert.equal(fAdd.numerator, 23n);
  assert.equal(fAdd.denominator, 20n);
  assert.equal(fAdd.mixedWhole, 1n);
  assert.equal(fAdd.mixedRemNum, 3n);
  const fDiv = ToolsEngine.fraction(1, 2, 3, 4, FractionOp.DIV);
  assert.equal(fDiv.numerator, 2n);
  assert.equal(fDiv.denominator, 3n);
  assert.equal(ToolsEngine.fraction(1, 2, 0, 4, FractionOp.DIV), null);

  const fLarge = ToolsEngine.fraction(1_000_000_000_000n, 2_000_000_000_000n, 1n, 2n, FractionOp.ADD);
  assert.equal(fLarge.numerator, 1n);
  assert.equal(fLarge.denominator, 1n);

  const dur = ToolsEngine.timeDuration(22, 30, 6, 15);
  assert.deepEqual(dur, [7, 45, 465]);
  assert.equal(ToolsEngine.timeDuration(25, 0, 10, 0), null);

  const dateDiff = ToolsEngine.dateDifference(new SimpleDate(2024, 1, 1), new SimpleDate(2024, 3, 1));
  assert.equal(dateDiff.totalDays, 60);

  const eomLeap = ToolsEngine.dateDifference(new SimpleDate(2024, 1, 31), new SimpleDate(2024, 3, 1));
  assert.equal(eomLeap.totalDays, 30);
  assert.ok(eomLeap.days >= 0);
  assert.equal(eomLeap.months, 1);
  assert.equal(eomLeap.days, 1);

  const eomNonLeap = ToolsEngine.dateDifference(new SimpleDate(2023, 1, 31), new SimpleDate(2023, 3, 1));
  assert.equal(eomNonLeap.totalDays, 29);
  assert.equal(eomNonLeap.months, 1);
  assert.equal(eomNonLeap.days, 1);

  const age = ToolsEngine.calculateAge(new SimpleDate(2000, 2, 29), new SimpleDate(2026, 3, 1));
  assert.equal(age.years, 26);
  assert.equal(age.months, 0);
  assert.equal(age.days, 1);
  assert.equal(ToolsEngine.calculateAge(new SimpleDate(2030, 1, 1), new SimpleDate(2026, 1, 1)), null);

  assertClose(ToolsEngine.solveMotion(MotionTarget.SPEED, 150.0, 2.5), 60.0);
  assertClose(ToolsEngine.solveMotion(MotionTarget.DISTANCE, 60.0, 2.5), 150.0);
  assertClose(ToolsEngine.solveMotion(MotionTarget.TIME, 150.0, 60.0), 2.5);
  assert.equal(ToolsEngine.solveMotion(MotionTarget.SPEED, 100.0, 0.0), null);

  const [fuelNeeded, fuelCost] = ToolsEngine.fuelCost(320.0, 16.0, 1.65);
  assertClose(fuelNeeded, 20.0);
  assertClose(fuelCost, 33.0);

  const [uA, uB, savingsPct] = ToolsEngine.unitPriceCompare(4.99, 500.0, 7.49, 1000.0);
  assert.ok(uB < uA);
  assertClose(savingsPct, ((uA - uB) / uA) * 100.0);
});

test('future graphing sampler and deterministic solver', () => {
  const points = GraphSampler.sampleFunction(
    { id: 'f1', expressionWithX: 'x^2', label: 'x²' },
    { xMin: -2.0, xMax: 2.0, yMin: 0.0, yMax: 4.0 },
    5,
  );
  assert.equal(points.length, 5);
  assertClose(points[0].y, 4.0, 1e-6);
  assertClose(points[2].y, 0.0, 1e-6);
  assertClose(points[4].y, 4.0, 1e-6);

  const lin = DeterministicMathSolver.solveLinear(2.0, 4.0, 10.0);
  assert.equal(lin.ok, true);
  assert.equal(lin.summary, 'x = 3');

  const quad = DeterministicMathSolver.solveQuadratic(1.0, -5.0, 6.0);
  assert.equal(quad.ok, true);
  assert.ok(quad.summary.includes('3') && quad.summary.includes('2'));
});
