import assert from 'node:assert/strict';
import test from 'node:test';
import { BigDecimal } from '../src/engine/bigDecimal.js';
import {
  AngleMode,
  CalcError,
  CalculationEngine,
  isEvalError,
  isEvalSuccess,
} from '../src/engine/calculationEngine.js';
import { FormattingOptions, NumberGroupingStyle } from '../src/engine/numberFormatter.js';

function fmtRes(res) {
  return JSON.stringify(res, (_, v) => (typeof v === 'bigint' ? v.toString() : v));
}

function evalSuccess(expr, angleMode = AngleMode.DEG, formatting = new FormattingOptions()) {
  const res = CalculationEngine.evaluate(expr, angleMode, formatting);
  if (!isEvalSuccess(res)) {
    assert.fail(`Expected Success for '${expr}' (${angleMode}), got ${fmtRes(res)}`);
  }
  return res;
}

function assertFormatted(expr, expectedFormatted, angleMode = AngleMode.DEG, formatting = new FormattingOptions()) {
  assert.equal(evalSuccess(expr, angleMode, formatting).formatted, expectedFormatted);
}

function assertApprox(expr, expected, tolerance = 1e-9, angleMode = AngleMode.DEG) {
  const actual = evalSuccess(expr, angleMode).value.toNumber();
  assert.ok(
    Math.abs(actual - expected) <= tolerance,
    `Mismatch for '${expr}' (${angleMode}): expected ${expected} ± ${tolerance}, got ${actual}`,
  );
}

function assertError(expr, expectedError, angleMode = AngleMode.DEG) {
  const res = CalculationEngine.evaluate(expr, angleMode);
  if (!isEvalError(res)) {
    assert.fail(`Expected Error(${expectedError.name}) for '${expr}', got ${fmtRes(res)}`);
  }
  assert.equal(res.error.name, expectedError.name, `Wrong error type for '${expr}'`);
}

test('mandatory arithmetic and percentage cases', () => {
  assertFormatted('1+1', '2');
  assertFormatted('9−5', '4');
  assertFormatted('7×8', '56');
  assertFormatted('144÷12', '12');
  assertFormatted('0÷5', '0');
  assertError('5÷0', CalcError.DIVISION_BY_ZERO);
  assertError('0÷0', CalcError.DIVISION_BY_ZERO);

  assertFormatted('0.1+0.2', '0.3');
  assertFormatted('0.7−0.2', '0.5');
  assertFormatted('1.25×4', '5');
  assertFormatted('10÷4', '2.5');

  assertFormatted('−5+8', '3');
  assertFormatted('−5×−5', '25');
  assertFormatted('−5×5', '−25');
  assertFormatted('5−9', '−4');

  assertFormatted('25%', '0.25');
  assertFormatted('200×10%', '20');
  assertFormatted('200+10%', '220');
  assertFormatted('200−10%', '180');
  assertFormatted('200+10%+10%', '242');
  assertFormatted('200+10%×2', '200.2');
});

test('operator precedence and associativity', () => {
  assertFormatted('2+3×4', '14');
  assertFormatted('10−2×3', '4');
  assertFormatted('20÷5+3', '7');
  assertFormatted('2×3+4×5', '26');
  assertFormatted('100÷10÷2', '5');
  assertFormatted('8−3+2', '7');
  assertFormatted('8÷4×2', '4');
  assertFormatted('2+2×2+2', '8');
  assertFormatted('2^3^2', '512');
  assertFormatted('−5^2', '−25');
  assertFormatted('(−5)^2', '25');
});

test('parentheses nested and malformed expressions', () => {
  assertFormatted('(2+3)×4', '20');
  assertFormatted('2×(3+4)', '14');
  assertFormatted('(10−4)÷2', '3');
  assertFormatted('2×(3+4×2)', '22');
  assertFormatted('(5+5)×(2+3)', '50');
  assertFormatted('((2+3)×4)÷2', '10');
  assertFormatted('2(3+4)', '14');
  assertFormatted('(2+3)(4+1)', '25');

  assertFormatted('sin(30', '0.5', AngleMode.DEG);

  assertError('', CalcError.SYNTAX_ERROR);
  assertError('   ', CalcError.SYNTAX_ERROR);
  assertError('()', CalcError.SYNTAX_ERROR);
  assertError('((()))', CalcError.SYNTAX_ERROR);
  assertError('2+)3(', CalcError.SYNTAX_ERROR);
  assertError('+', CalcError.SYNTAX_ERROR);
  assertError('5+', CalcError.SYNTAX_ERROR);
  assertError('2++3', CalcError.SYNTAX_ERROR);
  assertError('1..2', CalcError.SYNTAX_ERROR);
  assertError('sin()', CalcError.SYNTAX_ERROR);
  assertError('foo(5)', CalcError.SYNTAX_ERROR);
});

test('decimal precision repeating fractions and reuse fidelity', () => {
  assertFormatted('0.1+0.2', '0.3');
  assertFormatted('0.3−0.1', '0.2');
  assertFormatted('0.1×0.1', '0.01');
  assertFormatted('99999999.99+0.01', '100,000,000');
  assertFormatted('1000000000×0.0000001', '100');

  assertApprox('1÷3', 1.0 / 3.0, 1e-12);
  assertApprox('2÷3', 2.0 / 3.0, 1e-12);
  assertApprox('10÷3', 10.0 / 3.0, 1e-12);
  assertApprox('1÷7', 1.0 / 7.0, 1e-12);

  assertFormatted('(1÷3)×3', '1');
  assertFormatted('(1÷7)×7', '1');

  const oneThird = evalSuccess('1÷3');
  const reused = evalSuccess(`${oneThird.rawNumericString}×3`);
  assert.equal(reused.formatted, '1');

  assertFormatted(
    '1234567.89',
    '1 234 567.89',
    AngleMode.DEG,
    new FormattingOptions({ grouping: NumberGroupingStyle.SPACE }),
  );
  assertFormatted(
    '1234567.89',
    '1234567.89',
    AngleMode.DEG,
    new FormattingOptions({ grouping: NumberGroupingStyle.NONE }),
  );
  assertFormatted(
    '10÷3',
    '3.33',
    AngleMode.DEG,
    new FormattingOptions({ decimalPrecision: 2 }),
  );
});

test('large numbers 10 20 50 digits and extreme magnitudes', () => {
  const r1 = evalSuccess('999999999×999999999');
  assert.equal(r1.value.compareTo(BigDecimal.parse('999999998000000001')), 0);

  const r2 = evalSuccess('123456789012345×987654321098765');
  const expectedProd = BigDecimal.parse('123456789012345').multiply(BigDecimal.parse('987654321098765'));
  assert.equal(expectedProd.compareTo(r2.value), 0);

  const r3 = evalSuccess('999999999999999999+1');
  assert.equal(r3.value.compareTo(BigDecimal.parse('1000000000000000000')), 0);
  assert.equal(r3.formatted, '1×10^18');

  const r4 = evalSuccess('1000000000000000000×1000000000');
  assert.equal(r4.formatted, '1×10^27');

  const fiftyNines = '9'.repeat(50);
  const fiftyPlusOne = evalSuccess(`${fiftyNines}+1`);
  assert.equal(fiftyPlusOne.value.compareTo(BigDecimal.parse('1' + '0'.repeat(50))), 0);
  assert.equal(fiftyPlusOne.formatted, '1×10^50');

  const tinyProd = evalSuccess('0.0000000001×0.0000000001');
  assert.equal(tinyProd.value.compareTo(BigDecimal.parse('1e-20')), 0);
  assert.equal(tinyProd.formatted, '1×10^−20');

  const tinyPow = evalSuccess('10^(−15)');
  assert.equal(tinyPow.value.compareTo(BigDecimal.parse('1e-15')), 0);
  assert.equal(tinyPow.formatted, '1×10^−15');

  const bigDiv = evalSuccess('999999999999999999÷3');
  assert.equal(bigDiv.value.compareTo(BigDecimal.parse('333333333333333333')), 0);

  const bigPow = evalSuccess('2^2000');
  assert.ok(bigPow.value.compareTo(BigDecimal.parse('1e600')) > 0);

  assertError('10^99999999', CalcError.OVERFLOW);
});

test('scientific trigonometry deg and rad and inverse', () => {
  assertFormatted('sin(0)', '0', AngleMode.DEG);
  assertFormatted('sin(30)', '0.5', AngleMode.DEG);
  assertApprox('sin(45)', 0.7071067811865476, 1e-10, AngleMode.DEG);
  assertFormatted('sin(90)', '1', AngleMode.DEG);
  assertFormatted('sin(180)', '0', AngleMode.DEG);

  assertFormatted('cos(0)', '1', AngleMode.DEG);
  assertFormatted('cos(60)', '0.5', AngleMode.DEG);
  assertFormatted('cos(90)', '0', AngleMode.DEG);

  assertFormatted('tan(0)', '0', AngleMode.DEG);
  assertFormatted('tan(45)', '1', AngleMode.DEG);
  assertError('tan(90)', CalcError.DOMAIN_ERROR, AngleMode.DEG);
  assertError('tan(270)', CalcError.DOMAIN_ERROR, AngleMode.DEG);

  assertFormatted('sin(π÷6)', '0.5', AngleMode.RAD);
  assertFormatted('cos(π)', '−1', AngleMode.RAD);
  assertFormatted('sin(π)', '0', AngleMode.RAD);
  assertError('tan(π÷2)', CalcError.DOMAIN_ERROR, AngleMode.RAD);

  assertFormatted('asin(0.5)', '30', AngleMode.DEG);
  assertFormatted('acos(0.5)', '60', AngleMode.DEG);
  assertFormatted('atan(1)', '45', AngleMode.DEG);
  assertApprox('asin(0.5)', Math.PI / 6.0, 1e-10, AngleMode.RAD);
  assertError('asin(1.5)', CalcError.DOMAIN_ERROR, AngleMode.DEG);
  assertError('acos(−1.1)', CalcError.DOMAIN_ERROR, AngleMode.DEG);
});

test('scientific logs powers roots factorial hyperbolic and abs', () => {
  assertFormatted('log(1)', '0');
  assertFormatted('log(10)', '1');
  assertFormatted('log(100)', '2');
  assertFormatted('ln(1)', '0');
  assertFormatted('ln(e)', '1');
  assertFormatted('ln(e^2)', '2');
  assertFormatted('logBase(2,8)', '3');
  assertFormatted('logBase(10,1000)', '3');
  assertError('log(0)', CalcError.DOMAIN_ERROR);
  assertError('log(−1)', CalcError.DOMAIN_ERROR);
  assertError('ln(0)', CalcError.DOMAIN_ERROR);
  assertError('ln(−5)', CalcError.DOMAIN_ERROR);
  assertError('logBase(1,10)', CalcError.DOMAIN_ERROR);
  assertError('logBase(−2,8)', CalcError.DOMAIN_ERROR);

  assertFormatted('2^2', '4');
  assertFormatted('3^3', '27');
  assertFormatted('10^6', '1,000,000');
  assertFormatted('2^0', '1');
  assertFormatted('2^(−3)', '0.125');
  assertFormatted('9^0.5', '3');
  assertError('0^(−2)', CalcError.DIVISION_BY_ZERO);
  assertError('(−4)^0.5', CalcError.DOMAIN_ERROR);

  assertFormatted('√(4)', '2');
  assertFormatted('√(9)', '3');
  assertApprox('√(2)', Math.sqrt(2.0), 1e-10);
  assertFormatted('∛(27)', '3');
  assertFormatted('∛(−8)', '−2');
  assertFormatted('nroot(4,16)', '2');
  assertFormatted('nroot(3,−27)', '−3');
  assertError('√(−1)', CalcError.DOMAIN_ERROR);
  assertError('nroot(2,−4)', CalcError.DOMAIN_ERROR);

  assertFormatted('0!', '1');
  assertFormatted('1!', '1');
  assertFormatted('5!', '120');
  assertFormatted('10!', '3,628,800');
  const fact171 = evalSuccess('171!');
  assert.ok(fact171.value.compareTo(BigDecimal.parse('1e308')) > 0);
  assertError('1001!', CalcError.OVERFLOW);
  assertError('(−1)!', CalcError.DOMAIN_ERROR);
  assertError('2.5!', CalcError.DOMAIN_ERROR);

  assertFormatted('abs(−42.5)', '42.5');
  assertFormatted('1÷(4)', '0.25');
  assertFormatted('sinh(0)', '0');
  assertFormatted('cosh(0)', '1');
  assertFormatted('tanh(0)', '0');
});
