import assert from 'node:assert/strict';
import test from 'node:test';
import {
  BigDecimal,
  MATH_CONTEXT_DECIMAL128,
  MATH_CONTEXT_EXACT_CAP,
  MathContext,
  RoundingMode,
} from '../src/engine/bigDecimal.js';

test('BigDecimal parsing, plain strings, and Java toString scientific formatting', () => {
  assert.equal(BigDecimal.parse('0').toPlainString(), '0');
  assert.equal(BigDecimal.parse('0.00').toPlainString(), '0.00');
  assert.equal(BigDecimal.parse('−42.50').toPlainString(), '-42.50');
  assert.equal(BigDecimal.parse('1e18').toPlainString(), '1000000000000000000');
  assert.equal(BigDecimal.parse('1e18').toString(), '1E+18');
  assert.equal(BigDecimal.parse('1e-10').toString(), '1E-10');
  assert.equal(BigDecimal.parse('1e-6').toString(), '0.000001');
  assert.equal(BigDecimal.parse('1e-7').toString(), '1E-7');
});

test('BigDecimal arithmetic, division sticky HALF_UP, pow, and remainder', () => {
  assert.equal(BigDecimal.parse('0.1').add('0.2').toPlainString(), '0.3');
  assert.equal(BigDecimal.parse('0.3').subtract('0.1').toPlainString(), '0.2');
  assert.equal(BigDecimal.parse('1').divide('3', MATH_CONTEXT_DECIMAL128).toString().length, 36); // 0. + 34 threes
  assert.equal(
    BigDecimal.parse('2.5').divide('2', new MathContext(1, RoundingMode.HALF_UP)).toPlainString(),
    '1',
  );
  assert.equal(
    BigDecimal.parse('1.5').divide('2', new MathContext(1, RoundingMode.HALF_UP)).toPlainString(),
    '0.8',
  );
  assert.equal(BigDecimal.parse('360000000000000030').remainder(360).toPlainString(), '30');
  assert.equal(BigDecimal.parse('-30').remainder(360).toPlainString(), '-30');
  assert.equal(BigDecimal.parse('2').pow(10, MATH_CONTEXT_DECIMAL128).toPlainString(), '1024');
  assert.equal(BigDecimal.parse('2').pow(-3, MATH_CONTEXT_DECIMAL128).toPlainString(), '0.125');

  const exact120 = BigDecimal.parse('9'.repeat(120)).add(1, MATH_CONTEXT_EXACT_CAP);
  assert.equal(exact120.compareTo(BigDecimal.parse('1' + '0'.repeat(120))), 0);
});

test('BigDecimal setScale avoids negative zero and rounds HALF_UP', () => {
  assert.equal(BigDecimal.parse('-0.001').setScale(2).toPlainString(), '0.00');
  assert.equal(BigDecimal.parse('-0.005').setScale(2).toPlainString(), '-0.01');
  assert.equal(BigDecimal.parse('0.005').setScale(2).toPlainString(), '0.01');
  assert.equal(BigDecimal.parse('100').setScale(2).toPlainString(), '100.00');
});
