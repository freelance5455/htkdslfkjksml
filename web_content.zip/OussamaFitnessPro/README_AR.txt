OUSSAMA FITNESS PRO v2.0

مشروع Android حقيقي جاهز للبناء إلى APK.

المميزات:
- واجهة احترافية
- حاسبة الطعام بالجرامات
- سعرات + بروتين + كارب + دهون
- إضافة أطعمة خاصة
- برنامج تمارين أسبوعي
- الأرجل مرتين أسبوعياً
- متابعة الوزن ورسم بياني
- المكملات
- إعدادات الهدف
- نسخة احتياطية
- Offline

بناء APK:
Android Studio > Open Project > Build > Build APK(s)

المسار المتوقع:
app/build/outputs/apk/debug/app-debug.apk
