package com.malipro.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.net.Uri;
import android.content.Intent;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.os.Environment;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.database.Cursor;
import android.widget.Toast;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.net.URLConnection;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int PICK_FILE = 2001;
    private ValueCallback<Uri[]> fileCallback;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true); // Persist app data in localStorage
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("application/json");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(Intent.createChooser(intent, "اختر النسخة الاحتياطية"), PICK_FILE);
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient());
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            webView.evaluateJavascript("(function(){return document.documentElement.outerHTML})()", null);
            Toast.makeText(this, "استخدم أزرار التصدير والنسخ الاحتياطي داخل التطبيق", Toast.LENGTH_SHORT).show();
        });
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface public void saveFile(String name, String mime, String data) {
                runOnUiThread(() -> saveExport(name, mime, data));
            }
        }, "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void saveExport(String name, String mime, String data) {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, name);
            values.put(MediaStore.Downloads.MIME_TYPE, mime);
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("تعذر إنشاء الملف");
            try (OutputStream out = getContentResolver().openOutputStream(uri)) { out.write(data.getBytes("UTF-8")); }
            Toast.makeText(this, "تم حفظ الملف في مجلد التنزيلات", Toast.LENGTH_LONG).show();
        } catch (Exception ex) { Toast.makeText(this, "تعذر حفظ الملف: " + ex.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && fileCallback != null) {
            Uri[] result = resultCode == RESULT_OK && data != null ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
