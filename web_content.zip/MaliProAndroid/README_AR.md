# مالي الاحترافي — مشروع Android

هذا مشروع Android Studio يغلّف ملف HTML الأصلي داخل WebView كتطبيق أندرويد. التخزين المحلي `localStorage` مفعّل، لذا تبقى البيانات محفوظة على الجهاز بين مرات فتح التطبيق.

## بناء ملف APK
1. ثبّت Android Studio على الكمبيوتر.
2. افتح مجلد `MaliProAndroid` من Android Studio.
3. انتظر اكتمال Gradle Sync وتثبيت Android SDK Platform 35 عند الطلب.
4. اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. ستجد ملف APK عادةً في `app/build/outputs/apk/debug/app-debug.apk`.

## ملاحظات
- التطبيق يعمل دون الحاجة إلى اتصال بالإنترنت بعد تثبيته.
- البيانات محفوظة محليًا على نفس الجهاز؛ احفظ نسخة احتياطية بانتظام من داخل التطبيق.
- هذا مجلد مشروع قابل للتعديل، وليس ملف APK موقّعًا جاهزًا.
