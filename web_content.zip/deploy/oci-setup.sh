#!/usr/bin/env bash
# Oracle Cloud (OCI) VM.Standard1.1 (Ubuntu 22.04/24.04) par ek baar chalao:
#   sudo bash deploy/oci-setup.sh
# Ye Docker lagata hai, VM ka andar wala firewall kholta hai, aur server chalu karta hai.
set -e
[ "$EUID" -eq 0 ] || { echo "sudo se chalao: sudo bash deploy/oci-setup.sh"; exit 1; }
cd "$(dirname "$0")/../backend"

echo "==> Docker install"
if ! command -v docker >/dev/null; then
  curl -fsSL https://get.docker.com | sh
fi
systemctl enable --now docker

echo "==> VM ka firewall (OCI Ubuntu image me iptables band hota hai)"
for r in "tcp 80" "tcp 443" "tcp 7881"; do set -- $r; iptables -C INPUT -p $1 --dport $2 -j ACCEPT 2>/dev/null || iptables -I INPUT 5 -p $1 --dport $2 -j ACCEPT; done
iptables -C INPUT -p udp --dport 50000:50050 -j ACCEPT 2>/dev/null || iptables -I INPUT 5 -p udp --dport 50000:50050 -j ACCEPT
apt-get install -y iptables-persistent >/dev/null 2>&1 || true
netfilter-persistent save 2>/dev/null || iptables-save > /etc/iptables/rules.v4

if [ ! -f .env ]; then
  cp .env.example .env
  K=$(openssl rand -hex 8); S=$(openssl rand -hex 32)
  sed -i "s/^LIVEKIT_API_KEY=.*/LIVEKIT_API_KEY=api$K/; s/^LIVEKIT_API_SECRET=.*/LIVEKIT_API_SECRET=$S/" .env
  echo ""
  echo "backend/.env ban gaya (LiveKit keys auto). Ab usme API_DOMAIN, LK_DOMAIN aur GOOGLE_CLIENT_ID bharo:"
  echo "    nano backend/.env"
  echo "phir dobara chalao: sudo bash deploy/oci-setup.sh"
  exit 0
fi
grep -q "XXXXXXXX\|paste-token" .env && { echo ".env me domain/GOOGLE_CLIENT_ID abhi placeholder hain, pehle bharo."; exit 1; }

echo "==> Server start"
docker compose up -d --build
echo "Ho gaya. Check: curl https://\$(grep ^API_DOMAIN .env | cut -d= -f2)/health"
