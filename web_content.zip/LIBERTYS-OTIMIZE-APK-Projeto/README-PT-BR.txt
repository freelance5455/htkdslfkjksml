LIBERTYS OTIMIZE — projeto Android (WebView)
================================================

Este pacote contém o HTML original dentro de um aplicativo Android básico.
Nome do app: LIBERTYS OTIMIZE
Pacote: br.com.libertys.otimize
Android mínimo: 6.0 (API 23)

COMO GERAR O APK
1. Extraia o ZIP.
2. Abra a pasta LibertysOtimize no Android Studio (PC) ou em um IDE Android compatível.
3. Aguarde a sincronização do Gradle e instale os componentes de SDK solicitados.
4. Use Build > Build APK(s).
5. O APK de depuração normalmente fica em:
   app/build/outputs/apk/debug/app-debug.apk

IMPORTANTE
- Este ZIP é o projeto-fonte, não um APK já compilado.
- Para compilar, é necessário um ambiente Android/Gradle com acesso aos componentes de compilação.
- O app carrega o HTML local, sem precisar de hospedagem ou internet para abrir a interface.
- A interface HTML apresenta orientações e dados limitados pelo navegador/WebView. Ela não limpa automaticamente a RAM/cache geral nem aumenta FPS diretamente.
