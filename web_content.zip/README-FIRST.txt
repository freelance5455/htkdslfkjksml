# Grand Guide updated web/PWA package

## Included
- `index.html`: your existing Grand Guide Master app, updated additively.
- `manifest.webmanifest`: install name, display mode, colors, and icon declarations.
- `service-worker.js`: caches the local app shell for repeat visits and offline fallback.
- `assets/grand-guide-icon-192.png`, `grand-guide-icon-512.png`, and `grand-guide-icon-maskable-512.png`: derived from the earlier selected blue-and-gold Grand Guide emblem.
- `assets/grand-guide-splash.png`: full-size splash artwork to use in packaging/configuration.
- original logo/icon images retained in `assets/`.

## New features added (existing features kept)
1. Branded animated startup splash with a Skip intro button (auto-dismisses).
2. Grand Guide emblem replaces the emoji-only home header.
3. PWA manifest and icon sizes for compatible install flows.
4. Service-worker shell caching with network/offline fallback.
5. Online/offline status in the Toolbox.
6. Save/bookmark individual lessons.
7. Saved lessons list and remove control.
8. Resume the most recently opened lesson.
9. Personal notes with save and delete (local to the browser/device).
10. Searchable glossary of phone/technology terms.
11. Safe quick-fix guides for Wi-Fi, slow phone, battery, storage, scams and finding settings.
12. Text-to-speech tool and stop control where supported.
13. Voice question entry into AI Teacher where the browser supports speech recognition.
14. Self-reported daily learning goal and study-minute log.
15. In-app daily reminder; browser notification support is optional and not guaranteed when the app is closed.
16. Export progress/settings/notes to a JSON backup.
17. Restore a Grand Guide JSON backup.
18. High-contrast reading mode, while keeping the existing font-size controls.
19. Copyable issue-report text that does not automatically upload user data.
20. Privacy reminder about bank PINs, passwords and one-time codes.

## Important installation note
This package is a web app/PWA source bundle, **not an APK**. The HTML splash and PWA icon metadata work when the folder is served from a compatible HTTPS web host. A true Android launcher icon and Android-native splash must be assigned by the APK wrapper/build system during Android packaging. The current inline splash will not hold the app on a permanent loading screen: it is designed to dismiss after about 1.8 seconds or when Skip intro is tapped.

The AI Teacher still depends on internet access and the existing configured backend. Offline shell caching does not make AI responses available offline. Check your AI backend and policies before public release.
