DON'T LAUGH! — Android APK project

This project wraps the existing meme game in a simple Android WebView app.
The game HTML is bundled locally in app/src/main/assets/index.html. Meme images
still load from Wikimedia Commons, so those images require an internet connection.

BUILD AN APK USING GITHUB ACTIONS (no Android Studio needed):
1. Extract this ZIP.
2. Create/sign in to a GitHub account and create a NEW repository.
3. Upload all files/folders from this extracted project to the repository.
4. Open the repository's Actions tab.
5. Select "Build Android APK" and press "Run workflow" (or push to main).
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run and download the artifact named
   "dont-laugh-debug-apk". Extract it to get app-debug.apk.
8. On your Android phone, tap the APK to install it. Android may ask you to
   allow installation from that source; only do this for a project you trust.

IMPORTANT:
- This ZIP is an Android project, NOT a precompiled APK.
- This environment does not have the Android SDK/Gradle build setup needed to
  compile and test the APK directly.
- The debug APK is for personal testing, not Play Store publishing.
- For Google Play, create a signed release AAB/APK and complete the store's
  current requirements.
