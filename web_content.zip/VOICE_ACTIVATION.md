# Smart Voice Activation

The main Smart screen now has a large, clearly labeled **ACTIVATE SMART VOICE** button.

## How to use it
1. Open the native Smart Android app.
2. On the main chat screen, find the **Smart Voice** card.
3. Tap **🎤 ACTIVATE SMART VOICE**.
4. If Android asks for microphone permission, choose **Allow**.
5. The card changes to **● ACTIVE — listening for “Hey Smart”**.
6. You can then say commands such as **“Hey Smart, open WhatsApp.”**
7. Tap **⏹ STOP SMART VOICE** whenever you want to stop it.

The floating Smart button is optional and can be enabled from **☰ → Floating Smart Button**.

## Important Android behavior
Smart Voice starts its microphone foreground service from the visible Smart app after microphone permission is granted. Modern Android versions impose restrictions on microphone foreground services, so the app must be activated from the visible app rather than silently starting microphone access in the background.
