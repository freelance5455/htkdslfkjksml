"use strict";

window.Nexora = window.Nexora || {};

window.Nexora.Mobile = {

    initialized: false,

    settings: {

        trackpad: true,

        wasd: true,

        mouseButtons: true,

        space: false,

        shift: false,

        cursorSpeed: 1

    },

    trackpad: null,

    init() {

        if (this.initialized) {
            return;
        }

        this.load();

        this.createTopbar();

        this.setupKeyboardButtons();

        this.update();

        window.addEventListener(
            "resize",
            () => this.update()
        );

        this.initialized = true;

        console.log(
            "[Mobile] Mobile system ready."
        );
    },

    load() {

        try {

            const saved =
                JSON.parse(
                    localStorage.getItem(
                        "nexora-mobile"
                    ) || "{}"
                );

            this.settings = {
                ...this.settings,
                ...saved
            };

        } catch {}

    },

    save() {

        localStorage.setItem(
            "nexora-mobile",
            JSON.stringify(
                this.settings
            )
        );
    },

    createTopbar() {

        if (
            document.getElementById(
                "mobileTopbar"
            )
        ) {
            return;
        }

        const topbar =
            document.createElement("div");

        topbar.id =
            "mobileTopbar";

        topbar.innerHTML = `

            <button
                id="mobileSettingsButton"
                type="button"
            >
                ☰
            </button>

            <div class="mobile-top-title">
                Nexora
            </div>

            <button
                id="mobileNotificationButton"
                type="button"
            >
                ●
            </button>

        `;

        document.body.appendChild(
            topbar
        );

        const settings =
            topbar.querySelector(
                "#mobileSettingsButton"
            );

        const notification =
            topbar.querySelector(
                "#mobileNotificationButton"
            );

        settings.addEventListener(
            "click",
            () => {

                window.Nexora.System
                    ?.launch(
                        "mobileSettings"
                    );

            }
        );

        notification.addEventListener(
            "click",
            () => {

                window.Nexora.Notifications
                    ?.info(
                        "Nexora",
                        "No new notifications."
                    );

            }
        );
    },

    update() {

        const mobile =
            window.innerWidth <= 700;

        document.body.classList.toggle(
            "nexora-mobile",
            mobile
        );

        const topbar =
            document.getElementById(
                "mobileTopbar"
            );

        if (topbar) {

            topbar.style.display =
                mobile
                    ? "flex"
                    : "none";

        }

        if (!mobile) {

            this.destroyControls();

        } else {

            this.createControls();

        }
    },

    createControls() {

        this.destroyControls();

        if (
            this.settings.trackpad
        ) {

            this.createTrackpad();

        }

        if (
            this.settings.wasd
        ) {

            this.createWASD();

        }

        if (
            this.settings.mouseButtons
        ) {

            this.createMouseButtons();

        }
    },

    destroyControls() {

        document
            .querySelectorAll(
                ".nexora-mobile-control"
            )
            .forEach(
                element =>
                    element.remove()
            );

        this.trackpad = null;
    },

    createTrackpad() {

        const trackpad =
            document.createElement("div");

        trackpad.className =
            "nexora-mobile-control";

        trackpad.id =
            "nexoraTrackpad";

        trackpad.innerHTML = `
            <div>
                TRACKPAD
            </div>
        `;

        trackpad.style.cssText = `
            position:fixed;
            left:15px;
            bottom:20px;
            width:170px;
            height:120px;
            border-radius:22px;
            background:rgba(255,255,255,.07);
            border:1px solid rgba(255,255,255,.1);
            backdrop-filter:blur(15px);
            -webkit-backdrop-filter:blur(15px);
            z-index:2147482000;
            color:white;
            display:flex;
            align-items:center;
            justify-content:center;
            font:10px system-ui;
            letter-spacing:2px;
            opacity:.7;
            touch-action:none;
            user-select:none;
        `;

        document.body.appendChild(
            trackpad
        );

        this.trackpad =
            trackpad;

        let active = false;

        let lastX = 0;
        let lastY = 0;

        trackpad.addEventListener(
            "pointerdown",
            event => {

                active = true;

                lastX =
                    event.clientX;

                lastY =
                    event.clientY;

                trackpad.setPointerCapture(
                    event.pointerId
                );

                event.preventDefault();

            }
        );

        trackpad.addEventListener(
            "pointermove",
            event => {

                if (!active) {
                    return;
                }

                const dx =
                    event.clientX -
                    lastX;

                const dy =
                    event.clientY -
                    lastY;

                lastX =
                    event.clientX;

                lastY =
                    event.clientY;

                window.Nexora.Input
                    ?.moveBy(
                        dx,
                        dy
                    );

                event.preventDefault();

            }
        );

        const stop =
            event => {

                active = false;

                try {

                    trackpad.releasePointerCapture(
                        event.pointerId
                    );

                } catch {}

            };

        trackpad.addEventListener(
            "pointerup",
            stop
        );

        trackpad.addEventListener(
            "pointercancel",
            stop
        );
    },

    createWASD() {

        const container =
            document.createElement("div");

        container.className =
            "nexora-mobile-control";

        container.id =
            "nexoraWASD";

        container.style.cssText = `
            position:fixed;
            right:20px;
            bottom:25px;
            width:145px;
            height:145px;
            z-index:2147482000;
            display:grid;
            grid-template-columns:
                repeat(3,1fr);
            grid-template-rows:
                repeat(3,1fr);
            gap:6px;
            touch-action:none;
            user-select:none;
        `;

        const buttons = {

            W: [1, 0],

            A: [0, 1],

            S: [1, 2],

            D: [2, 1]

        };

        for (
            const [key, position]
            of Object.entries(buttons)
        ) {

            const button =
                document.createElement(
                    "button"
                );

            button.textContent =
                key;

            button.style.cssText = `
                grid-row:${position[0] + 1};
                grid-column:${position[1] + 1};
                border:1px solid rgba(255,255,255,.1);
                border-radius:14px;
                background:rgba(255,255,255,.08);
                color:white;
                font-weight:700;
                font-size:15px;
                touch-action:none;
            `;

            const down =
                event => {

                    event.preventDefault();

                    button.style.background =
                        "rgba(255,255,255,.18)";

                    window.Nexora.Input
                        ?.keyDown(key);

                };

            const up =
                event => {

                    event.preventDefault();

                    button.style.background =
                        "rgba(255,255,255,.08)";

                    window.Nexora.Input
                        ?.keyUp(key);

                };

            button.addEventListener(
                "pointerdown",
                down
            );

            button.addEventListener(
                "pointerup",
                up
            );

            button.addEventListener(
                "pointercancel",
                up
            );

            button.addEventListener(
                "pointerleave",
                event => {

                    if (
                        event.buttons === 0
                    ) {
                        up(event);
                    }

                }
            );

            container.appendChild(
                button
            );
        }

        document.body.appendChild(
            container
        );
    },

    createMouseButtons() {

        const container =
            document.createElement("div");

        container.className =
            "nexora-mobile-control";

        container.id =
            "nexoraMouseButtons";

        container.style.cssText = `
            position:fixed;
            right:20px;
            bottom:180px;
            z-index:2147482000;
            display:flex;
            gap:8px;
            touch-action:none;
        `;

        const createButton =
            (text, button) => {

                const element =
                    document.createElement(
                        "button"
                    );

                element.textContent =
                    text;

                element.style.cssText = `
                    width:54px;
                    height:42px;
                    border:1px solid rgba(255,255,255,.1);
                    border-radius:12px;
                    background:rgba(255,255,255,.08);
                    color:white;
                    font-weight:700;
                    touch-action:none;
                `;

                element.addEventListener(
                    "pointerdown",
                    event => {

                        event.preventDefault();

                        window.Nexora.Input
                            ?.click(
                                button
                            );

                    }
                );

                return element;
            };

        container.appendChild(
            createButton(
                "L",
                0
            )
        );

        container.appendChild(
            createButton(
                "R",
                2
            )
        );

        document.body.appendChild(
            container
        );
    },

    setupKeyboardButtons() {}
};

window.Nexora.Mobile.init();

console.log(
    "Nexora Mobile loaded."
);