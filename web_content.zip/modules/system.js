"use strict";

window.Nexora = window.Nexora || {};

window.Nexora.System = {
    name: "Nexora System",
    version: "0.1.0",
    apps: new Map(),
    coreApps: [],
    initialized: false,

    async init() {
        if (this.initialized) return;

        console.log("[System] Initializing Nexora System...");

        this.registerCore();
        await this.loadApps();

        this.initialized = true;

        console.log("[System] Nexora System ready.");
    },

    registerCore() {
        this.coreApps = [
            {
                id: "welcome",
                name: "Welcome",
                description: "Welcome to Nexora OS",
                icon: "N"
            },
            {
                id: "explorer",
                name: "File Explorer",
                description: "Browse your files",
                icon: "📁"
            },
            {
                id: "apps",
                name: "Nexora Apps",
                description: "Installed applications",
                icon: "◈"
            },
            {
                id: "appcreator",
                name: "App Creator",
                description: "Create applications with NexPy",
                icon: "⌘"
            },
            {
                id: "terminal",
                name: "Terminal",
                description: "Nexora command line",
                icon: ">_"
            },
            {
                id: "calculator",
                name: "Calculator",
                description: "Perform calculations",
                icon: "＋"
            },
            {
                id: "settings",
                name: "Settings",
                description: "Configure Nexora",
                icon: "⚙"
            },
            {
                id: "paint",
                name: "Paint",
                description: "Create drawings",
                icon: "✦"
            },
            {
                id: "browser",
                name: "Nexora Browser",
                description: "Browse the Web",
                icon: "◎"
            },
            {
                id: "trash",
                name: "Trash",
                description: "Deleted files",
                icon: "⌫"
            },
            {
                id: "about",
                name: "About Nexora",
                description: "System information",
                icon: "ⓘ"
            },
            {
                id: "cursor",
                name: "Cursor",
                description: "Customize the Nexora cursor",
                icon: "⌁"
            },
        ];
    },

    async loadApps() {
        for (const manifest of this.coreApps) {
            try {
                const module = await import(
                    `../apps/${manifest.id}.js?v=2`
                );

                const app = module.default || module;

                this.apps.set(manifest.id, {
                    ...manifest,
                    ...app
                });

                console.log(
                    `[System] Loaded app: ${manifest.name}`
                );

            } catch (error) {
                console.error(
                    `[System] Failed to load ${manifest.id}`,
                    error
                );
            }
        }
    },

    getApp(id) {
        return this.apps.get(id) ?? null;
    },

    getApps() {
        return [...this.apps.values()];
    },

    async launch(id) {
        const app = this.getApp(id);

        if (!app) {
            console.error(
                "Nexora: app not found:",
                id
            );

            return null;
        }

        const existing =
            WindowManager.findByAppId(id);

        if (existing) {
            WindowManager.focus(existing);
            return existing;
        }

        if (typeof app.create !== "function") {
            console.error(
                "Nexora: app has no create() function:",
                id
            );

            return null;
        }

        return await app.create();
    }
};

window.Nexora.System.init();