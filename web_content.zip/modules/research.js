const https = require("https");

function get(url) {
  return new Promise((resolve,reject)=>{
    const u=new URL(url);
    https.get({hostname:u.hostname,path:u.pathname+u.search,headers:{"User-Agent":"AutoBusinessAI/1.0"}},res=>{
      let raw="";
      res.on("data",c=>raw+=c);
      res.on("end",()=>resolve(raw));
    }).on("error",reject);
  });
}

async function gdelt(query, max=20) {
  const url = "https://api.gdeltproject.org/api/v2/doc/doc?query="+encodeURIComponent(query)+
    "&mode=ArtList&format=json&maxrecords="+Math.min(max,250)+"&sort=HybridRel";
  try {
    const raw=await get(url);
    const data=JSON.parse(raw);
    return (data.articles||[]).map(a=>({
      title:a.title, url:a.url, domain:a.domain, date:a.seendate,
      language:a.language, sourceCountry:a.sourcecountry
    }));
  } catch(e) {
    return [];
  }
}

async function researchWorld(config) {
  const queries=config.research?.queries || ["AI tools","small business","education"];
  const all=[];
  for(const q of queries) {
    const items=await gdelt(q, config.research?.maxArticles || 20);
    all.push(...items.map(x=>({...x, query:q})));
  }
  return all.slice(0,100);
}

module.exports={researchWorld};
