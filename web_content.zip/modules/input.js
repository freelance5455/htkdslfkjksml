"use strict";

window.Nexora = window.Nexora || {};

window.Nexora.Input = {

    initialized: false,

    keys: new Set(),

    mouse: {
        x: window.innerWidth / 2,
        y: window.innerHeight / 2,
        left: false,
        right: false,
        middle: false
    },

    virtualMouse: false,

    init() {

        if (this.initialized) {
            return;
        }

        this.setupKeyboard();

        this.setupMouse();

        this.setupVirtualMouseEvents();

        this.initialized = true;

        console.log(
            "[Input] Input system ready."
        );
    },

    setupKeyboard() {

        window.addEventListener(
            "keydown",
            event => {

                this.keys.add(
                    event.key
                );

                document.dispatchEvent(
                    new CustomEvent(
                        "nexora-keydown",
                        {
                            detail: {
                                key: event.key,
                                code: event.code,
                                originalEvent: event
                            }
                        }
                    )
                );

            }
        );

        window.addEventListener(
            "keyup",
            event => {

                this.keys.delete(
                    event.key
                );

                document.dispatchEvent(
                    new CustomEvent(
                        "nexora-keyup",
                        {
                            detail: {
                                key: event.key,
                                code: event.code,
                                originalEvent: event
                            }
                        }
                    )
                );

            }
        );

        window.addEventListener(
            "blur",
            () => {

                this.keys.clear();

            }
        );
    },

    setupMouse() {

        window.addEventListener(
            "pointermove",
            event => {

                if (
                    event.pointerType ===
                    "mouse"
                ) {

                    this.mouse.x =
                        event.clientX;

                    this.mouse.y =
                        event.clientY;

                }

            },
            true
        );

        window.addEventListener(
            "pointerdown",
            event => {

                if (
                    event.pointerType !==
                    "mouse"
                ) {
                    return;
                }

                if (event.button === 0) {

                    this.mouse.left =
                        true;

                }

                if (event.button === 1) {

                    this.mouse.middle =
                        true;

                }

                if (event.button === 2) {

                    this.mouse.right =
                        true;

                }

            },
            true
        );

        window.addEventListener(
            "pointerup",
            event => {

                if (
                    event.pointerType !==
                    "mouse"
                ) {
                    return;
                }

                if (event.button === 0) {

                    this.mouse.left =
                        false;

                }

                if (event.button === 1) {

                    this.mouse.middle =
                        false;

                }

                if (event.button === 2) {

                    this.mouse.right =
                        false;

                }

            },
            true
        );
    },

    setupVirtualMouseEvents() {

        document.addEventListener(
            "nexora-mouseclick",
            event => {

                const detail =
                    event.detail;

                if (!detail) {
                    return;
                }

                document.dispatchEvent(
                    new CustomEvent(
                        "nexora-input-click",
                        {
                            detail
                        }
                    )
                );

            }
        );
    },

    enableVirtualMouse() {

        this.virtualMouse =
            true;

        if (
            window.Nexora.Cursor
        ) {

            window.Nexora.Cursor
                .setVirtualVisible(
                    true
                );

        }
    },

    disableVirtualMouse() {

        this.virtualMouse =
            false;

        if (
            window.Nexora.Cursor
        ) {

            window.Nexora.Cursor
                .setVirtualVisible(
                    false
                );

        }
    },

    moveMouse(x, y) {

        if (
            window.Nexora.Cursor
        ) {

            window.Nexora.Cursor
                .moveVirtual(
                    x,
                    y
                );

        }

        this.mouse.x = x;
        this.mouse.y = y;
    },

    moveBy(dx, dy) {

        if (
            window.Nexora.Cursor
        ) {

            window.Nexora.Cursor
                .moveBy(
                    dx,
                    dy
                );

        }

        const cursor =
            window.Nexora.Cursor;

        if (cursor?.virtual) {

            const rect =
                cursor.virtual
                    .getBoundingClientRect();

            this.mouse.x =
                rect.left;

            this.mouse.y =
                rect.top;

        }
    },

    click(button = 0) {

        if (
            window.Nexora.Cursor
        ) {

            window.Nexora.Cursor
                .click(button);

        }
    },

    keyDown(key) {

        this.keys.add(key);

        document.dispatchEvent(
            new CustomEvent(
                "nexora-keydown",
                {
                    detail: {
                        key,
                        virtual: true
                    }
                }
            )
        );
    },

    keyUp(key) {

        this.keys.delete(key);

        document.dispatchEvent(
            new CustomEvent(
                "nexora-keyup",
                {
                    detail: {
                        key,
                        virtual: true
                    }
                }
            )
        );
    },

    isDown(key) {

        return this.keys.has(key);

    }
};

window.Nexora.Input.init();

console.log(
    "Nexora Input loaded."
);