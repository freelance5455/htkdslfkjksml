"use strict";

window.Nexora = window.Nexora || {};

window.Nexora.Notifications = {

    initialized: false,

    container: null,

    init() {

        if (this.initialized) {
            return;
        }

        this.createContainer();

        this.initialized = true;

        console.log(
            "[Notifications] System ready."
        );
    },

    createContainer() {

        if (document.getElementById(
            "nexoraNotifications"
        )) {

            this.container =
                document.getElementById(
                    "nexoraNotifications"
                );

            return;
        }

        const container =
            document.createElement("div");

        container.id =
            "nexoraNotifications";

        container.style.cssText = `
            position:fixed;
            top:18px;
            right:18px;
            width:min(360px,calc(100vw - 36px));
            display:flex;
            flex-direction:column;
            gap:10px;
            z-index:2147483000;
            pointer-events:none;
        `;

        document.body.appendChild(
            container
        );

        this.container =
            container;
    },

    show(
        title,
        message,
        type = "info",
        duration = 4500
    ) {

        if (!this.container) {
            this.init();
        }

        const notification =
            document.createElement("div");

        notification.className =
            "nexora-notification";

        const icons = {

            info: "●",

            success: "✓",

            warning: "!",

            error: "×"

        };

        const icon =
            icons[type] || icons.info;

        notification.style.cssText = `
            pointer-events:auto;
            width:100%;
            box-sizing:border-box;
            padding:14px 15px;
            display:flex;
            gap:12px;
            align-items:flex-start;
            border:1px solid rgba(255,255,255,.1);
            border-radius:16px;
            background:rgba(18,18,24,.82);
            backdrop-filter:blur(22px);
            -webkit-backdrop-filter:blur(22px);
            box-shadow:
                0 15px 45px rgba(0,0,0,.35),
                inset 0 1px rgba(255,255,255,.06);
            color:white;
            opacity:0;
            transform:translateX(30px);
            transition:
                opacity .22s ease,
                transform .22s ease;
            font-family:system-ui,sans-serif;
        `;

        notification.innerHTML = `
            <div style="
                width:30px;
                height:30px;
                flex:none;
                display:flex;
                align-items:center;
                justify-content:center;
                border-radius:10px;
                background:rgba(255,255,255,.08);
                font-weight:700;
            ">
                ${icon}
            </div>

            <div style="
                min-width:0;
                flex:1;
            ">

                <div style="
                    font-size:13px;
                    font-weight:700;
                    margin-bottom:3px;
                ">
                    ${this.escape(title)}
                </div>

                <div style="
                    font-size:12px;
                    line-height:1.45;
                    opacity:.58;
                    word-break:break-word;
                ">
                    ${this.escape(message)}
                </div>

            </div>

            <button
                type="button"
                class="nexora-notification-close"
                style="
                    width:25px;
                    height:25px;
                    flex:none;
                    border:0;
                    border-radius:8px;
                    background:rgba(255,255,255,.06);
                    color:white;
                    cursor:pointer;
                    opacity:.55;
                "
            >
                ×
            </button>
        `;

        this.container.appendChild(
            notification
        );

        requestAnimationFrame(() => {

            notification.style.opacity =
                "1";

            notification.style.transform =
                "translateX(0)";

        });

        const close = () => {

            notification.style.opacity =
                "0";

            notification.style.transform =
                "translateX(30px)";

            setTimeout(() => {

                notification.remove();

            }, 230);
        };

        notification
            .querySelector(
                ".nexora-notification-close"
            )
            .addEventListener(
                "click",
                close
            );

        if (duration > 0) {

            setTimeout(
                close,
                duration
            );

        }

        return notification;
    },

    info(title, message, duration) {

        return this.show(
            title,
            message,
            "info",
            duration
        );

    },

    success(title, message, duration) {

        return this.show(
            title,
            message,
            "success",
            duration
        );

    },

    warning(title, message, duration) {

        return this.show(
            title,
            message,
            "warning",
            duration
        );

    },

    error(title, message, duration) {

        return this.show(
            title,
            message,
            "error",
            duration
        );

    },

    clear() {

        if (!this.container) {
            return;
        }

        this.container.innerHTML =
            "";
    },

    escape(value) {

        return String(value)
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    }
};

window.Nexora.Notifications.init();

console.log(
    "Nexora Notifications loaded."
);