const fs=require("fs");
const path=require("path");
const file=path.join(__dirname,"..","data","notifications.json");
function load(){try{return JSON.parse(fs.readFileSync(file,"utf8"));}catch{return [];}}
function save(x){fs.writeFileSync(file,JSON.stringify(x,null,2));}
function notify(type,title,message,data={}){
  const arr=load();
  arr.unshift({id:Date.now()+"-"+Math.random().toString(16).slice(2),type,title,message,data,createdAt:new Date().toISOString(),read:false});
  save(arr.slice(0,200));
}
module.exports={notify,load,save};
