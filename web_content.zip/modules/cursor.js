"use strict";

window.Nexora = window.Nexora || {};

window.Nexora.Cursor = {

    initialized: false,

    settings: {
        style: "default",
        size: 22,
        color: "#ffffff",
        visible: true,
        virtualVisible: true,
        speed: 1
    },

    virtual: null,

    styles: {
        default: "default",
        dot: "dot",
        ring: "ring",
        cross: "cross",
        pointer: "pointer",
        glow: "glow",
        square: "square"
    },

    init() {

        if (this.initialized) {
            return;
        }

        this.load();

        this.createVirtualCursor();

        this.apply();

        this.initialized = true;

        console.log(
            "[Cursor] Cursor system ready."
        );
    },

    load() {

        try {

            const saved =
                JSON.parse(
                    localStorage.getItem(
                        "nexora-cursor"
                    ) || "{}"
                );

            this.settings = {
                ...this.settings,
                ...saved
            };

        } catch {

            console.warn(
                "[Cursor] Failed to load settings."
            );

        }
    },

    save() {

        localStorage.setItem(
            "nexora-cursor",
            JSON.stringify(
                this.settings
            )
        );
    },

    createVirtualCursor() {

        if (this.virtual) {
            return;
        }

        const cursor =
            document.createElement("div");

        cursor.id =
            "nexoraVirtualCursor";

        cursor.setAttribute(
            "aria-hidden",
            "true"
        );

        cursor.style.cssText = `
            position: fixed;
            left: 50%;
            top: 50%;
            width: 22px;
            height: 22px;
            pointer-events: none;
            z-index: 2147483647;
            transform: translate(-50%, -50%);
            display: none;
        `;

        document.body.appendChild(cursor);

        this.virtual = cursor;

        this.bindPointerTracking();
    },

    bindPointerTracking() {

        document.addEventListener(
            "pointermove",
            event => {

                if (
                    event.pointerType ===
                    "mouse"
                ) {
                    this.moveVirtual(
                        event.clientX,
                        event.clientY
                    );
                }

            },
            true
        );
    },

    moveVirtual(x, y) {

        if (!this.virtual) {
            return;
        }

        this.virtual.style.left =
            `${x}px`;

        this.virtual.style.top =
            `${y}px`;
    },

    setStyle(style) {

        if (!this.styles[style]) {

            console.warn(
                "[Cursor] Unknown style:",
                style
            );

            return false;
        }

        this.settings.style =
            style;

        this.save();

        this.apply();

        return true;
    },

    setSize(size) {

        size =
            Number(size);

        if (!Number.isFinite(size)) {
            return false;
        }

        size =
            Math.max(
                8,
                Math.min(
                    80,
                    size
                )
            );

        this.settings.size =
            size;

        this.save();

        this.apply();

        return true;
    },

    setColor(color) {

        if (
            typeof color !==
            "string"
        ) {
            return false;
        }

        this.settings.color =
            color;

        this.save();

        this.apply();

        return true;
    },

    setVisible(value) {

        this.settings.visible =
            Boolean(value);

        this.save();

        this.apply();

        return true;
    },

    setVirtualVisible(value) {

        this.settings.virtualVisible =
            Boolean(value);

        this.save();

        this.apply();

        return true;
    },

    setSpeed(speed) {

        speed =
            Number(speed);

        if (!Number.isFinite(speed)) {
            return false;
        }

        this.settings.speed =
            Math.max(
                0.25,
                Math.min(
                    5,
                    speed
                )
            );

        this.save();

        return true;
    },

    getStyle() {
        return this.settings.style;
    },

    getSize() {
        return this.settings.size;
    },

    getColor() {
        return this.settings.color;
    },

    getSpeed() {
        return this.settings.speed;
    },

    apply() {

        const style =
            this.settings.style;

        const size =
            this.settings.size;

        const color =
            this.settings.color;

        const visible =
            this.settings.visible;

        document.documentElement
            .style
            .setProperty(
                "--nexora-cursor-color",
                color
            );

        document.documentElement
            .style
            .setProperty(
                "--nexora-cursor-size",
                `${size}px`
            );

        if (!visible) {

            document.body.style.cursor =
                "none";

        } else {

            if (
                style === "default"
            ) {

                document.body.style.cursor =
                    "default";

            } else {

                document.body.style.cursor =
                    this.makeCursor(
                        style,
                        color,
                        size
                    );

            }
        }

        this.applyVirtual();
    },

    applyVirtual() {

        if (!this.virtual) {
            return;
        }

        if (
            !this.settings.virtualVisible
        ) {

            this.virtual.style.display =
                "none";

            return;
        }

        if (
            window.innerWidth <= 700
        ) {

            this.virtual.style.display =
                "block";

        } else {

            this.virtual.style.display =
                "none";

        }

        const size =
            this.settings.size;

        const color =
            this.settings.color;

        const style =
            this.settings.style;

        this.virtual.innerHTML = "";

        this.virtual.style.width =
            `${size}px`;

        this.virtual.style.height =
            `${size}px`;

        this.virtual.style.background =
            "transparent";

        this.virtual.style.border =
            "0";

        this.virtual.style.borderRadius =
            "0";

        this.virtual.style.boxShadow =
            "none";

        if (style === "dot") {

            this.virtual.style.width =
                `${Math.max(6, size * 0.45)}px`;

            this.virtual.style.height =
                `${Math.max(6, size * 0.45)}px`;

            this.virtual.style.background =
                color;

            this.virtual.style.borderRadius =
                "50%";

            this.virtual.style.boxShadow =
                `0 0 12px ${color}`;

        }

        else if (style === "ring") {

            this.virtual.style.border =
                `${Math.max(2, size * 0.1)}px solid ${color}`;

            this.virtual.style.borderRadius =
                "50%";

            this.virtual.style.boxSizing =
                "border-box";

        }

        else if (style === "cross") {

            this.virtual.innerHTML = `
                <div style="
                    position:absolute;
                    left:50%;
                    top:0;
                    width:2px;
                    height:100%;
                    transform:translateX(-50%);
                    background:${color};
                "></div>

                <div style="
                    position:absolute;
                    top:50%;
                    left:0;
                    width:100%;
                    height:2px;
                    transform:translateY(-50%);
                    background:${color};
                "></div>
            `;

        }

        else if (style === "square") {

            this.virtual.style.border =
                `2px solid ${color}`;

            this.virtual.style.boxSizing =
                "border-box";

        }

        else if (style === "glow") {

            this.virtual.style.width =
                `${Math.max(8, size * 0.5)}px`;

            this.virtual.style.height =
                `${Math.max(8, size * 0.5)}px`;

            this.virtual.style.background =
                color;

            this.virtual.style.borderRadius =
                "50%";

            this.virtual.style.boxShadow =
                `
                    0 0 6px ${color},
                    0 0 14px ${color},
                    0 0 28px ${color}
                `;

        }

        else if (style === "pointer") {

            this.virtual.innerHTML = `
                <div style="
                    width:0;
                    height:0;
                    border-left:${size * 0.28}px solid transparent;
                    border-right:${size * 0.28}px solid transparent;
                    border-bottom:${size}px solid ${color};
                    transform:rotate(-45deg);
                    transform-origin:center;
                "></div>
            `;

        }

        else {

            this.virtual.innerHTML = `
                <div style="
                    width:100%;
                    height:100%;
                    position:relative;
                ">
                    <div style="
                        position:absolute;
                        left:0;
                        top:0;
                        width:2px;
                        height:100%;
                        background:${color};
                    "></div>

                    <div style="
                        position:absolute;
                        left:0;
                        top:0;
                        width:100%;
                        height:2px;
                        background:${color};
                    "></div>
                </div>
            `;
        }
    },

    makeCursor(style, color, size) {

        let svg = "";

        if (style === "dot") {

            svg = `
                <svg xmlns="http://www.w3.org/2000/svg"
                     width="${size}"
                     height="${size}"
                     viewBox="0 0 ${size} ${size}">
                    <circle
                        cx="${size / 2}"
                        cy="${size / 2}"
                        r="${size / 4}"
                        fill="${color}"
                    />
                </svg>
            `;

        } else if (style === "ring") {

            svg = `
                <svg xmlns="http://www.w3.org/2000/svg"
                     width="${size}"
                     height="${size}"
                     viewBox="0 0 ${size} ${size}">
                    <circle
                        cx="${size / 2}"
                        cy="${size / 2}"
                        r="${size / 3}"
                        fill="none"
                        stroke="${color}"
                        stroke-width="2"
                    />
                </svg>
            `;

        } else if (style === "cross") {

            svg = `
                <svg xmlns="http://www.w3.org/2000/svg"
                     width="${size}"
                     height="${size}"
                     viewBox="0 0 ${size} ${size}">
                    <path
                        d="M${size / 2} 0V${size}M0 ${size / 2}H${size}"
                        stroke="${color}"
                        stroke-width="2"
                    />
                </svg>
            `;

        } else if (style === "square") {

            svg = `
                <svg xmlns="http://www.w3.org/2000/svg"
                     width="${size}"
                     height="${size}"
                     viewBox="0 0 ${size} ${size}">
                    <rect
                        x="3"
                        y="3"
                        width="${size - 6}"
                        height="${size - 6}"
                        fill="none"
                        stroke="${color}"
                        stroke-width="2"
                    />
                </svg>
            `;

        } else if (style === "glow") {

            svg = `
                <svg xmlns="http://www.w3.org/2000/svg"
                     width="${size}"
                     height="${size}"
                     viewBox="0 0 ${size} ${size}">
                    <circle
                        cx="${size / 2}"
                        cy="${size / 2}"
                        r="${size / 5}"
                        fill="${color}"
                    />
                </svg>
            `;

        } else {

            svg = `
                <svg xmlns="http://www.w3.org/2000/svg"
                     width="${size}"
                     height="${size}"
                     viewBox="0 0 ${size} ${size}">
                    <path
                        d="M3 2L3 20L8 15L12 23L15 21L11 13L18 13Z"
                        fill="${color}"
                    />
                </svg>
            `;
        }

        return `
            url("data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}")
            2 2,
            auto
        `;
    },

    moveBy(dx, dy) {

        if (!this.virtual) {
            return;
        }

        const rect =
            this.virtual.getBoundingClientRect();

        const speed =
            this.settings.speed;

        let x =
            rect.left +
            dx * speed;

        let y =
            rect.top +
            dy * speed;

        x =
            Math.max(
                0,
                Math.min(
                    window.innerWidth,
                    x
                )
            );

        y =
            Math.max(
                0,
                Math.min(
                    window.innerHeight,
                    y
                )
            );

        this.moveVirtual(x, y);
    },

    click(button = 0) {

        if (!this.virtual) {
            return;
        }

        const rect =
            this.virtual.getBoundingClientRect();

        const x =
            rect.left +
            rect.width / 2;

        const y =
            rect.top +
            rect.height / 2;

        const target =
            document.elementFromPoint(
                x,
                y
            );

        if (!target) {
            return;
        }

        const type =
            button === 2
                ? "contextmenu"
                : "click";

        target.dispatchEvent(
            new MouseEvent(
                type,
                {
                    bubbles: true,
                    cancelable: true,
                    clientX: x,
                    clientY: y,
                    button
                }
            )
        );

        document.dispatchEvent(
            new CustomEvent(
                "nexora-mouseclick",
                {
                    detail: {
                        button,
                        x,
                        y,
                        target
                    }
                }
            )
        );
    },

    reset() {

        this.settings = {

            style: "default",

            size: 22,

            color: "#ffffff",

            visible: true,

            virtualVisible: true,

            speed: 1

        };

        this.save();

        this.apply();
    }
};

window.addEventListener(
    "resize",
    () => {

        if (
            window.Nexora.Cursor
        ) {

            window.Nexora.Cursor.apply();

        }

    }
);

console.log(
    "Nexora Cursor module loaded."
);