const { askOpenRouter } = require("./ai");

const EBOOK_SCHEMA = {
  title: "string",
  subtitle: "string",
  audience: "string",
  language: "string",
  coverText: {"title":"string","subtitle":"string","author":"string"},
  description: "string",
  tableOfContents: ["string"],
  chapters: [{
    title:"string",
    learningObjective:"string",
    sections:["string"],
    examples:["string"],
    caseStudies:["string"],
    exercises:["string"],
    checklist:["string"],
    templates:["string"],
    summary:"string"
  }],
  faq:["string"],
  resources:["string"],
  actionPlan:["string"],
  nextStepOffer:"string",
  sourceNotes:["string"],
  limitations:["string"]
};

async function generateEbook(config, opportunity, language) {
  const system = `Tu es le moteur éditorial d'un produit numérique sérieux.
Retourne UNIQUEMENT un JSON valide conforme au schéma.
Ne fabrique pas de faits ou de sources. Signale les incertitudes.
L'ebook doit être réellement utile, pédagogique et structuré.
Il doit contenir couverture, sommaire, chapitres, exemples, études de cas,
exercices, checklists, tableaux/templates, plan d'action, FAQ, ressources,
limites et prochaine étape commerciale sans promesse trompeuse.
Langue cible: ${language}.
Schéma: ${JSON.stringify(EBOOK_SCHEMA)}`;

  const user = `Opportunité détectée:
${JSON.stringify(opportunity,null,2)}

Crée un ebook complet sur cette opportunité en ${language}.`;
  const raw=await askOpenRouter(config,system,user);
  return JSON.parse(raw.replace(/^```json\s*/,"").replace(/\s*```$/,""));
}

async function localizeEbook(config, ebook, targetLanguage) {
  const system=`Traduis/localise entièrement le document en ${targetLanguage}.
Conserve les faits, nombres, structures et limites. N'invente rien.
Tout le texte doit être dans la langue cible, y compris titre, couverture,
chapitres, exercices, tableaux/templates, FAQ, ressources, description et offre.
Retourne uniquement un JSON valide avec la même structure.`;
  const raw=await askOpenRouter(config,system,JSON.stringify(ebook));
  return JSON.parse(raw.replace(/^```json\s*/,"").replace(/\s*```$/,""));
}

function collectStrings(v,out=[]){
  if(typeof v==="string") out.push(v);
  else if(Array.isArray(v)) v.forEach(x=>collectStrings(x,out));
  else if(v && typeof v==="object") Object.values(v).forEach(x=>collectStrings(x,out));
  return out;
}

async function localizationQA(config, ebook, targetLanguage) {
  const system=`Tu es un contrôleur qualité linguistique.
Évalue si un ebook est entièrement localisé en ${targetLanguage}.
Repère les passages probablement restés dans une autre langue, les traductions
littérales, incohérences de terminologie et éléments oubliés.
Retourne JSON: {"passed":boolean,"issues":[string],"suggestedFixes":[string]}.
Ne juge pas le style comme un problème si la langue est correcte.`;
  return JSON.parse(await askOpenRouter(config,system,JSON.stringify(ebook)));
}

module.exports={generateEbook,localizeEbook,localizationQA,collectStrings};
