const https = require("https");

function postJson(url, body, headers={}) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const data = JSON.stringify(body);
    const req = https.request({
      hostname: u.hostname, path: u.pathname + u.search, method: "POST",
      headers: {"Content-Type":"application/json","Content-Length":Buffer.byteLength(data), ...headers}
    }, res => {
      let raw="";
      res.on("data", c => raw += c);
      res.on("end", () => {
        try {
          const parsed=JSON.parse(raw);
          if(res.statusCode >= 400) return reject(new Error(`OpenRouter ${res.statusCode}: ${raw.slice(0,500)}`));
          resolve(parsed);
        } catch(e){ reject(new Error("Réponse IA invalide: "+raw.slice(0,500))); }
      });
    });
    req.on("error", reject);
    req.end(data);
  });
}

async function askOpenRouter(config, system, user) {
  if(!config.openRouterApiKey) throw new Error("OPENROUTER_API_KEY manquante");
  const result = await postJson("https://openrouter.ai/api/v1/chat/completions", {
    model: config.openRouterModel,
    temperature: 0.4,
    messages: [{role:"system",content:system},{role:"user",content:user}]
  }, {
    Authorization: `Bearer ${config.openRouterApiKey}`,
    "HTTP-Referer": config.publicBaseUrl || "https://localhost",
    "X-Title": "Auto Business AI"
  });
  return result.choices?.[0]?.message?.content || "";
}

module.exports = { askOpenRouter };
