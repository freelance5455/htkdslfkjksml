/*
  Safe wallet module:
  - stores only the public address/network;
  - creates analysis/transaction proposals;
  - NEVER accepts a seed phrase, private key, or Trust Wallet password;
  - NEVER signs or broadcasts a transaction.
*/
function validatePublicAddress(address){
  return typeof address==="string" && address.length>=20 && !/\s/.test(address);
}
function makeProposal({asset,amount,network,to,reason,confidence}){
  return {
    status:"PENDING_HUMAN_APPROVAL",
    asset,amount,network,to,reason,confidence,
    createdAt:new Date().toISOString(),
    warning:"Proposition uniquement. Validation et signature manuelles dans le portefeuille."
  };
}
module.exports={validatePublicAddress,makeProposal};
