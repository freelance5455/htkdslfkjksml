const https = require("https");

function getJson(url) {
  return new Promise((resolve,reject)=>{
    const u=new URL(url);
    https.get({hostname:u.hostname,path:u.pathname+u.search,headers:{"User-Agent":"AutoBusinessAI/1.0"}},res=>{
      let raw="";
      res.on("data",c=>raw+=c);
      res.on("end",()=>{
        try { resolve(JSON.parse(raw)); } catch(e){ reject(new Error(raw.slice(0,500))); }
      });
    }).on("error",reject);
  });
}

/*
  PayGate integration intentionally lives on the server.
  Each order should have its own callback URL/token.
  Do not trust the browser redirect as proof of payment.
*/
async function createPayment({paygate, amount, currency, customerEmail, callbackUrl}) {
  if(!paygate.enabled) throw new Error("PayGate désactivé");
  if(!paygate.destinationAddress || paygate.destinationAddress.startsWith("YOUR_"))
    throw new Error("Adresse publique PayGate non configurée");

  const endpoint = "https://api.paygate.to/control/wallet.php?address="+
    encodeURIComponent(paygate.destinationAddress)+"&callback="+encodeURIComponent(callbackUrl);
  const data=await getJson(endpoint);
  const addressIn=data.address_in || data.address || data;
  if(!addressIn) throw new Error("PayGate n'a pas renvoyé address_in");

  const paymentUrl = "https://paygate.to/pay/?address="+encodeURIComponent(addressIn)+
    "&amount="+encodeURIComponent(amount)+
    "&currency="+encodeURIComponent(currency)+
    "&email="+encodeURIComponent(customerEmail||"");
  return {addressIn,paymentUrl,raw:data};
}

module.exports={createPayment};
