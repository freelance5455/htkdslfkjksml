# Sumrid Holidays Adventure — Web Version

This package is designed for Firebase Hosting. It gives you:

- Customer booking website at `/`
- Private manager/admin web app at `/admin/`
- Same Firebase project/config already used by the app
- No Android Studio and no APK converter required

## Publish with Firebase Hosting

From a computer with Firebase CLI installed:

```bash
firebase login
firebase use sumrid-holiday-s-adventure
firebase deploy --only hosting
```

Then the public customer site will be available on your Firebase Hosting URL, and the manager will be at `/admin/`.

Do not share the `/admin/` address with customers.

## Important

This package does not require a Play Store app. Customers can open the website in Chrome and use it as a booking site. On Android Chrome they can also use Add to Home screen if desired.
