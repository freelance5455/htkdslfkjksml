NICOLAUS DALANICO LAUS - Android WebView Project

App label: nicolaus Dalanico laus
Application ID: com.nicolaus.dalanicolaus
Target SDK: 36

Build APK in Android Studio:
1. Open this folder as a project.
2. Let Gradle sync/download dependencies.
3. Build > Build APK(s).
4. Install the generated app-debug.apk on your phone.

The website is bundled locally in app/src/main/assets/index.html.
