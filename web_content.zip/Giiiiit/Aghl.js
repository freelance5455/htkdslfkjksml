const home = document.getElementById("home");
const newProject = document.getElementById("newProject");
const result = document.getElementById("result");

const projectName = document.getElementById("projectName");
const codeInput = document.getElementById("codeInput");

const searchInput = document.getElementById("searchInput");
const resultName = document.getElementById("resultName");
const codeResult = document.getElementById("codeResult");

const newProjectBtn = document.getElementById("newProjectBtn");
const backBtn = document.getElementById("backBtn");
const saveBtn = document.getElementById("saveBtn");
const searchBtn = document.getElementById("searchBtn");
const copyBtn = document.getElementById("copyBtn");

let projects = JSON.parse(
    localStorage.getItem("git_prise_projects")
) || {};

let currentProject = null;


// OPEN NEW PROJECT

newProjectBtn.addEventListener("click", () => {
    home.hidden = true;
    result.hidden = true;
    newProject.hidden = false;
});


// BACK TO HOME

backBtn.addEventListener("click", () => {
    newProject.hidden = true;
    result.hidden = true;
    home.hidden = false;
});


// SAVE PROJECT

saveBtn.addEventListener("click", () => {

    const name = projectName.value.trim();
    const code = codeInput.value;

    if (!name || !code.trim()) {
        alert("Please enter project name and code!");
        return;
    }

    const existingName = Object.keys(projects).find(
        key => key.toLowerCase() === name.toLowerCase()
    );

    const finalName = existingName || name;

    projects[finalName] = {
        code: code,
        language: "html",
        lastUpdate: new Date().toISOString()
    };

    localStorage.setItem(
        "git_prise_projects",
        JSON.stringify(projects)
    );

    alert("PROJECT SAVED!");

    projectName.value = "";
    codeInput.value = "";

    newProject.hidden = true;
    home.hidden = false;

});


// SEARCH PROJECT

searchBtn.addEventListener("click", () => {

    const query = searchInput.value.trim().toLowerCase();

    if (!query) {
        alert("Enter project name!");
        return;
    }

    const foundName = Object.keys(projects).find(
        name => name.toLowerCase() === query
    );

    if (!foundName) {
        alert("PROJECT NOT FOUND!");
        return;
    }

    currentProject = foundName;

    resultName.textContent = foundName;
    codeResult.textContent = projects[foundName].code;

    home.hidden = true;
    newProject.hidden = true;
    result.hidden = false;

});


// COPY CODE

copyBtn.addEventListener("click", async () => {

    try {
        await navigator.clipboard.writeText(
            projects[currentProject].code
        );

        alert("CODE COPIED!");

    } catch (error) {
        alert("COPY FAILED!");
    }

});