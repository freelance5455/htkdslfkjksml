# Sentry — Android APK banane ke steps

Yeh folder ek ready Cordova project hai jo app ki web app (`www/index.html`)
ko Android APK me wrap karta hai. Data sirf is app/device par hi store
hota hai (koi server nahi).

## Zaroori cheezein (ek baar install karni hongi)
1. Node.js install karo: https://nodejs.org (LTS version)
2. Java JDK 17 install karo
3. Android Studio install karo (https://developer.android.com/studio) —
   isse Android SDK bhi aa jaata hai. Android Studio khol kar
   "More Actions > SDK Manager" se kam se kam ek Android SDK Platform
   aur "Android SDK Build-Tools" install kar lo.

## APK banane ke steps
Terminal/Command Prompt me is folder ke andar jaakar:

```
npm install -g cordova
cordova platform add android
cordova build android
```

Agar signed/release APK chahiye (Play Store ya distribute karne ke liye):

```
cordova build android --release
```

Built APK yahan milegi:
```
platforms/android/app/build/outputs/apk/debug/app-debug.apk
```
(ya `release` folder me, agar `--release` use kiya)

Is APK ko seedha apne phone me bhej kar install kar sakte ho
("Install from unknown sources" allow karna padega).

## Agar Android Studio / command line use nahi karna
Simplest option: `www/index.html` file ko kisi free "Website to APK"
converter app/tool me upload kar do (Play Store par aise kayi free
tools milte hain) — woh bina code likhe seedha APK bana denge.

## App ka naam/icon badalna ho to
- Naam: `config.xml` me `<name>Sentry</name>` line badal do
- Icon: Android Studio me project khol kar `res/mipmap` folders me apna
  icon daal do, ya online "Android icon generator" se sizes bana lo.

## Note
- App ka data (`localStorage`) sirf us device/app install par rehta hai.
  Agar app uninstall karoge, data chala jayega — isliye Backup &
  Restore (JSON file) ka use karte raho.
- Internet chahiye hoga QR code aur PDF libraries load karne ke liye
  (ek baar load hone ke baad cache ho jaati hain).


## Advanced Tools (v1.1.0)
- Universal search across personnel, leave entries and stored documents.
- Filter search results by record type and company.
- Export current search results as CSV.
- Data-quality scan for duplicate service numbers, missing personnel fields and orphaned leave/document records.
- Quick local statistics panel.

**Privacy note:** This app still stores records locally on the device. Use encrypted device storage and keep backups in a secure location. This upgrade does not add cloud sync or server-side authentication.


## Sentry Pro visual refresh (v1.2.0)
- Refined responsive interface with a premium forest-green visual theme.
- Improved navigation, dashboard cards, forms, login screen, buttons and mobile spacing.
- Existing app workflows and on-device data storage are retained.

**Important:** The current role picker is a convenience UI, not secure authentication.
Do not store real personal, medical, identity or service records in this demo build.
For production use, add verified authentication, role authorization, encryption,
secure backups, audit controls and an approved data-protection review.


## Sentry Pro secure sign-in update (v1.3.0)
- First-run administrator enrollment; login no longer accepts a freely selected role.
- Password verifier derived with PBKDF2-HMAC-SHA-256 (310,000 iterations) and a per-install random salt.
- Five failed login attempts trigger a 60-second cooldown.
- Password re-entry is required after five minutes of inactivity and on every fresh app launch.
- Session data is not restored automatically after app restart.

### Security boundary — read before real use
This is still an **offline, client-side demo**, not production-grade authentication. The password verifier and application data live in browser storage and can be inspected or altered by someone with device/debug access. The records database is **not encrypted at rest**. There is no server identity provider, remote account recovery, central audit service, or enforceable multi-user authorization. The first setup account is the only local administrator; do not treat this as a multi-user role-management system.

Do not enter real personnel, operational, medical, identity, or other sensitive records. For real deployment, require an organization-approved backend identity provider, server-side role checks, encrypted database/storage, managed device controls, key management, backups, security testing, and formal authorization. Use synthetic test data only until then.
