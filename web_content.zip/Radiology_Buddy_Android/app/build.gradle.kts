plugins { id("com.android.application") }

android { namespace = "com.radiologybuddy"; compileSdk = 35
    defaultConfig { applicationId = "com.radiologybuddy"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
