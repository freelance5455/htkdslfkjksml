# Radiology Buddy Android APK project

This is an Android Studio project wrapping the Radiology Buddy web UI in a native Android WebView.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

The app requests microphone permission for speech recognition.

Important:
- The APK contains no AI API key.
- The backend/database must remain on a secure server.
- The bundled UI currently points to a local asset copy; for live AI/account persistence, configure the app's API base URL to your deployed HTTPS backend before release.
- This source project is APK-ready, but an APK binary cannot be safely produced in this environment because Android SDK/Gradle build tools are not installed here.
