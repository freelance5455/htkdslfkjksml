# Fideo Production Checklist

- [ ] Supabase project created
- [ ] `supabase/schema.sql` executed
- [ ] Email/Password enabled
- [ ] URL + publishable/anon key configured in APK
- [ ] Storage buckets `videos` and `avatars` exist
- [ ] Admin user created and role changed to `admin`
- [ ] HTTPS hosting for `/admin`
- [ ] LIVE provider selected (LiveKit/Agora)
- [ ] Secure token endpoint deployed
- [ ] FCM project + Android app configured for push notifications
- [ ] Release signing key created
- [ ] APK/AAB built and tested
- [ ] Privacy policy + terms published
- [ ] Abuse/report moderation rules reviewed
