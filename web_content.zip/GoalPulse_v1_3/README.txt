GoalPulse v1.3.0
Version Name: 1.3.0
Version Code: 4
Package: com.goalpulse.football

Online upgrade:
- Home, Live, Leagues and News load live internet data.
- Settings/navigation fixed (removed startup JavaScript error).
- API-Football key remains local to the phone.
- Network requests use a timeout and one retry.
- Live/Home refresh every 1 second as requested.
- Leagues/News refresh while their pages are active.
