# اپ اندروید محاسبه حجم خاکبرداری و خاکریزی

این پروژه نسخه Android ابزار HTML محاسبه حجم TIN-to-TIN است.

## امکانات
- اجرا کاملاً آفلاین
- Before و After از TXT/CSV/DAT
- جداکننده کاما، فاصله، Tab و ترکیب آنها
- LandXML برای سطوح TIN
- Boundary از TXT/CSV و DXF
- محاسبه CUT، FILL و NET
- ذخیره گزارش TXT با انتخاب مسیر در Android

## ساخت APK
پروژه را در Android Studio باز کنید و از:

`Build > Build APK(s)`

استفاده کنید.

نسخه پروژه با Android Gradle Plugin 9.4.0 و Gradle 9.6 طراحی شده است؛ JDK 17 لازم است.

پس از Build، فایل APK در مسیر مشابه زیر قرار می‌گیرد:

`app/build/outputs/apk/debug/app-debug.apk`
