# Newly APK Builder instructions (v1.1)

1. Upload **Sindh_Rescue_Rover_Android_v1_1_Native_WiFi_Fix.zip**. ZIP root directly contains `app`, `gradle/wrapper/gradle-wrapper.properties`, `build.gradle`, `settings.gradle`.
2. Set Android bundle/package ID to `pk.edu.khairpur.sindhrover`.
3. The project declares Gradle **8.9**, Android Gradle Plugin **8.7.3**, Java **17**, Android SDK **35**, minSdk 26.
4. Select **Build APK**, download the signed APK from Newly after a successful cloud build.
5. If a later build error appears, preserve and share the **entire textual build failure**, not just the screen header.

If upgrading fails because Android says the package has a different signature, uninstall the previous sideloaded app before installing the newly signed version.
