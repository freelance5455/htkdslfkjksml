CATEQUESE MANAGER — PROJECTO ANDROID

Este é o código-fonte de uma aplicação Android que incorpora a aplicação de gestão da catequese num WebView local. A página é servida através de WebViewAssetLoader num contexto HTTPS local, para permitir as APIs de cifragem WebCrypto utilizadas pela palavra-passe.

ESTADO
- Projecto Android Studio preparado.
- Ainda NÃO é um APK compilado/instalável.
- A compilação requer Android Studio/Android SDK e acesso para descarregar dependências Gradle.

COMO GERAR O APK
1. Instalar Android Studio num computador.
2. Abrir a pasta CatequeseManager no Android Studio.
3. Aceitar a sincronização Gradle e instalar o Android SDK 35 quando solicitado.
4. Usar Build > Build APK(s).
5. O APK de debug costuma ficar em app/build/outputs/apk/debug/app-debug.apk.

SEGURANÇA
- A aplicação HTML inclui palavra-passe, PBKDF2 e cifragem AES-GCM dos registos.
- O Android bloqueia capturas de ecrã para esta janela.
- O armazenamento local do WebView permanece no dispositivo. Não há sincronização online.
- Guarda exportações de cópia de segurança num local seguro; perder a palavra-passe pode tornar os dados irrecuperáveis.
- Antes de guardar dados reais de menores, testa bem o projecto e valida as regras de privacidade da paróquia.


CORREÇÃO DE IMPRESSÃO (2026-10-21)
O botão de boletim chama a ponte nativa AndroidPrint, que usa o PrintManager do Android. No diálogo de impressão do Android, escolha “Guardar como PDF” e selecione a pasta de destino. Esta ponte só existe nesta versão nativa; importar apenas o HTML para um construtor WebView como APK Forge não cria automaticamente a ponte.
