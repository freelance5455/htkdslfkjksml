ANIVORA — نسخة NanoIDE جديدة

مهم: بعد فك الضغط، اختر المجلد الذي يحتوي settings.gradle مباشرة.
ثم Import Gradle project → Convert to NanoIDE.
بعد فتح المشروع استخدم Build APK.
