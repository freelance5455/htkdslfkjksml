# QIRAAT

QIRAAT is a mobile-first game for learning the 28 Arabic letters in a fixed sequence. The app opens directly on the first letter; there is no world map, course catalogue, dashboard or start menu.

## Current version: 0.17.0

### How the game works

1. A new letter appears large on screen with its name, a short sound hint and the connected forms that actually exist for that letter.
2. Tap **Play / Начать игру** to enter the letter-hunt round.
3. Find the target letter on a 3×2 board five times. The round gives three lives; a wrong tile costs one life.
4. Distractors are only letters introduced earlier in the sequence, plus simple geometric symbols. No future Arabic letters are shown before they are taught.
5. Each successful catch gives 2 XP; clearing the round gives a 10 XP bonus. The player can retry a failed round.
6. Clearing the round unlocks the next letter. The 28-letter progress strip shows learned letters in order.

The first letter also has a playable round: its distractors are geometric symbols because no other Arabic letter has been introduced yet.

### Interface

- One game screen, no worlds, no map, no lesson list and no extra rules.
- Progress is strictly sequential: a later letter cannot be marked learned while an earlier one is missing.
- Light/dark themes, adjustable text size and 12 interface-language choices remain available. Russian is the primary instructional language; English is supported, and other languages may fall back to English.
- Progress is stored locally on the device.
- Arcade-style letter hunt with three lives, five catches per round, XP and a retry after a failed round. No timer or energy system.

### Audio

Two individual human recordings are integrated for alif and bāʾ. They are streamed from Wikimedia Commons and credited in the letter screen; both are CC BY 4.0 by Escuela Internacional de Árabe (Eiarabe). The remaining 26 letters do not yet have verified individual recordings, so the app does not fake them with device text-to-speech. External streaming requires internet; offline audio is not included yet.

### Scope

This version focuses only on learning the letters in sequence. Quran text, recitation, tajwid and the later Arabic-script topics are not part of the current playable flow. They should be introduced only after the letter-learning game is solid.

## Run and test

Requires Node.js 18+.

```bash
npm test
npm run serve
```

Open `http://localhost:8080`. The service worker requires localhost or HTTPS.

## Project layout

- `index.html` — minimal game shell
- `src/app/main.js` — sequential game flow
- `src/game/linear-progress.js` — ordered progression and challenge generation
- `src/data/letters.js` — Arabic letter data and connected forms
- `src/data/content-locales.js` — Russian/English letter labels
- `src/storage/progress.js` — local progress and backup import/export
- `src/ui/styles.css` — responsive game UI
- `tests/` — content, progression and storage tests

## Android status

No APK/AAB has been built or tested on a physical Android device.

## v0.14.0

- Removed all world/map/course navigation from the actual app shell.
- The app now starts directly on the next unlearned letter.
- Letters are unlocked strictly in the source order, one at a time.
- Each letter is introduced visually before a recognition challenge.
- Challenge options are restricted to the current letter and previously introduced letters.
- Removed old audio-player claims from the active app; individual letter recordings are still pending.
- Preserved older backups while normalizing progression to a continuous ordered prefix.


## v0.15.0

- Added an individual audio playback control on the alif and bāʾ introduction screens.
- Added attribution links and CC BY 4.0 source metadata.
- No TTS fallback: letters without a verified recording do not show a misleading audio control.
- Added audio-source status documentation.


## v0.16.0

- Replaced the one-tap recognition question with a playable 3×2 letter-hunt round.
- Added five successful catches per round, three lives, miss feedback, retry, XP per catch and a clear-round bonus.
- The first letter can now be played without exposing unknown Arabic letters; it uses geometric distractors.
- Later rounds use only previously introduced Arabic letters as letter distractors.
- Added responsive board styling and short hit/miss animations.


## v0.17.0

- Rebuilt the active learning and letter-hunt screens with a distinct arcade visual identity: dark emerald arena, gold level badge, XP wallet, progress bar, target halo, tile numbering and reward panel.
- Added animated letter orbit, pulsing target, hit feedback and reward entrance; respects reduced-motion preferences.
- Reworked the light theme so the new arcade layout remains legible in both themes.
- Kept the original sequential learning rules, three-life round, five catches, audio availability and local save format.
- Updated the service-worker cache namespace so existing installations request the new interface assets.
