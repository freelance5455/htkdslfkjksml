// Deterministic module exam scoring.
export function evaluateExam(answers, questions, threshold = 0.8) {
  if (!Array.isArray(questions) || questions.length === 0) throw new Error('Exam requires questions');
  if (!Number.isFinite(threshold) || threshold < 0 || threshold > 1) throw new RangeError('threshold must be between 0 and 1');
  if (!questions.every(q => Number.isInteger(q?.answer) && q.answer >= 0)) throw new Error('Every question needs a valid answer key');
  if (!Array.isArray(answers) || answers.length !== questions.length || answers.some(a => !Number.isInteger(a) || a < 0)) throw new Error('Every question must be answered with a valid option index');
  const correct = answers.reduce((sum, answer, i) => sum + (answer === questions[i].answer ? 1 : 0), 0);
  const score = correct / questions.length;
  return { correct, total: questions.length, score: Math.round(score * 100), passed: score >= threshold, threshold: Math.round(threshold * 100) };
}
