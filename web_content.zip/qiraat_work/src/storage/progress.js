const DB_NAME='qiraat-local';
const STORE='state';
const KEY='progress-v1';
export const defaults={completedLessons:[],letterAttempts:{},letterCorrect:[],topicChecks:{},reviewSchedule:{},examResults:{},game:{xp:0,gamesPlayed:0,bestScore:0,zoneStars:[0,0,0,0,0,0,0,0],completedMissions:{},achievements:[],letterMastery:{},letterIntroduced:[],collectibles:[]},settings:{language:'ru',theme:'light',fontScale:1},updatedAt:null};

export function parseProgressBackup(raw){
 const parsed=typeof raw==='string'?JSON.parse(raw):raw;
 if(!parsed||parsed.format!=='qiraat-progress'||parsed.version!==1||!parsed.data||typeof parsed.data!=='object')throw new Error('Unsupported backup format');
 const data=parsed.data;
 if(!Array.isArray(data.completedLessons)||!Array.isArray(data.letterCorrect)||typeof data.letterAttempts!=='object'||data.letterAttempts===null)throw new Error('Invalid backup data');
 const settings=data.settings||{};
 if(settings.language&&!['ru','en','ar','fr','es','de','tr','id','ur','bn','pt','zh-CN'].includes(settings.language))throw new Error('Unsupported language');
 if(settings.theme&&!['light','dark'].includes(settings.theme))throw new Error('Unsupported theme');
 if(settings.fontScale!==undefined&&(!Number.isFinite(settings.fontScale)||settings.fontScale<0.9||settings.fontScale>1.3))throw new Error('Unsupported font scale');
 for(const key of ['topicChecks','reviewSchedule','examResults'])if(data[key]!==undefined&&(!data[key]||typeof data[key]!=='object'||Array.isArray(data[key])))throw new Error(`Invalid ${key}`);
 if(data.game!==undefined){
  const game=data.game;
  if(!game||typeof game!=='object'||Array.isArray(game))throw new Error('Invalid game progress');
  for(const key of ['xp','coins','gamesPlayed','bestScore'])if(game[key]!==undefined&&(!Number.isInteger(game[key])||game[key]<0))throw new Error(`Invalid game ${key}`);
  if(game.zoneStars!==undefined&&(!Array.isArray(game.zoneStars)||![7,8].includes(game.zoneStars.length)||game.zoneStars.some(x=>!Number.isInteger(x)||x<0||x>3)))throw new Error('Invalid game zone stars');
  if(game.achievements!==undefined&&!Array.isArray(game.achievements))throw new Error('Invalid game achievements');
  if(game.collectibles!==undefined&&!Array.isArray(game.collectibles))throw new Error('Invalid game collectibles');
  if(game.letterIntroduced!==undefined&&(!Array.isArray(game.letterIntroduced)||game.letterIntroduced.length>28||game.letterIntroduced.some(x=>typeof x!=='string')||new Set(game.letterIntroduced).size!==game.letterIntroduced.length))throw new Error('Invalid introduced letters');
  for(const key of ['completedMissions','letterMastery'])if(game[key]!==undefined&&(!game[key]||typeof game[key]!=='object'||Array.isArray(game[key])))throw new Error(`Invalid game ${key}`);
 }
 return {...defaults,...data,topicChecks:data.topicChecks||{},reviewSchedule:data.reviewSchedule||{},examResults:data.examResults||{},game:{...defaults.game,...(data.game||{}),zoneStars:Array.isArray(data.game?.zoneStars)?[...data.game.zoneStars,...Array(Math.max(0,8-data.game.zoneStars.length)).fill(0)].slice(0,8):defaults.game.zoneStars,completedMissions:data.game?.completedMissions||{},achievements:data.game?.achievements||[],letterMastery:data.game?.letterMastery||{},letterIntroduced:data.game?.letterIntroduced||[],collectibles:data.game?.collectibles||[]},settings:{...defaults.settings,...settings}};
}

function openDb(){return new Promise((resolve,reject)=>{if(!('indexedDB' in globalThis)){reject(new Error('IndexedDB unavailable'));return;}const req=indexedDB.open(DB_NAME,1);req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains(STORE))req.result.createObjectStore(STORE);};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
export async function loadProgress(){try{const db=await openDb();const value=await new Promise((resolve,reject)=>{const r=db.transaction(STORE,'readonly').objectStore(STORE).get(KEY);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});db.close();return {...defaults,...value,topicChecks:value?.topicChecks||{},reviewSchedule:value?.reviewSchedule||{},examResults:value?.examResults||{},game:{...defaults.game,...(value?.game||{}),zoneStars:Array.isArray(value?.game?.zoneStars)?[...value.game.zoneStars,...Array(Math.max(0,8-value.game.zoneStars.length)).fill(0)].slice(0,8):defaults.game.zoneStars,completedMissions:value?.game?.completedMissions||{},achievements:value?.game?.achievements||[],letterMastery:value?.game?.letterMastery||{},letterIntroduced:value?.game?.letterIntroduced||[],collectibles:value?.game?.collectibles||[]},settings:{...defaults.settings,...value?.settings}};}catch{const value=JSON.parse(localStorage.getItem(KEY)||'{}');return {...defaults,...value,topicChecks:value.topicChecks||{},reviewSchedule:value.reviewSchedule||{},examResults:value.examResults||{},game:{...defaults.game,...(value.game||{}),zoneStars:Array.isArray(value.game?.zoneStars)?[...value.game.zoneStars,...Array(Math.max(0,8-value.game.zoneStars.length)).fill(0)].slice(0,8):defaults.game.zoneStars,completedMissions:value.game?.completedMissions||{},achievements:value.game?.achievements||[],letterMastery:value.game?.letterMastery||{},collectibles:value.game?.collectibles||[]},settings:{...defaults.settings,...value.settings}};}}
export async function saveProgress(value){const next={...value,updatedAt:new Date().toISOString()};try{const db=await openDb();await new Promise((resolve,reject)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).put(next,KEY);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});db.close();}catch{localStorage.setItem(KEY,JSON.stringify(next));}return next;}
export function exportProgress(value){const blob=new Blob([JSON.stringify({format:'qiraat-progress',version:1,exportedAt:new Date().toISOString(),data:value},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='qiraat-progress-backup.json';a.click();URL.revokeObjectURL(url);}

export async function importProgressBackup(raw){const restored=parseProgressBackup(raw);return saveProgress(restored);}
