// Deterministic spaced-repetition scheduler inspired by SM-2.
// Grades are deliberately coarse until reliable timing/audio assessment exists.
export function scheduleReview(previous, quality, now = new Date()) {
  if (!Number.isInteger(quality) || quality < 0 || quality > 5) throw new RangeError('quality must be an integer from 0 to 5');
  const old = previous || { repetitions: 0, intervalDays: 0, ease: 2.5 };
  let ease = Math.max(1.3, old.ease + (0.1 - (5-quality) * (0.08 + (5-quality) * 0.02)));
  let repetitions = old.repetitions || 0;
  let intervalDays;
  if (quality < 3) {
    repetitions = 0;
    intervalDays = 1;
  } else {
    repetitions += 1;
    intervalDays = repetitions === 1 ? 1 : repetitions === 2 ? 6 : Math.max(1, Math.round((old.intervalDays || 6) * ease));
  }
  const due = new Date(now);
  due.setDate(due.getDate() + intervalDays);
  return { repetitions, intervalDays, ease: Number(ease.toFixed(2)), lastReviewedAt: new Date(now).toISOString(), dueAt: due.toISOString(), lastQuality: quality };
}

export function getDueReviews(reviewSchedule, now = new Date()) {
  const timestamp = new Date(now).getTime();
  return Object.entries(reviewSchedule || {})
    .filter(([, item]) => item?.dueAt && new Date(item.dueAt).getTime() <= timestamp)
    .sort((a,b) => new Date(a[1].dueAt) - new Date(b[1].dueAt))
    .map(([id, schedule]) => ({ id, ...schedule }));
}
