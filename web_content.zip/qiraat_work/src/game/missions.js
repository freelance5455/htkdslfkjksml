import {vowelMarks,signLessons,maddLessons,orthographyLessons,syllableLessons} from '../data/curriculum.js';
import {letters as alphabet} from '../data/letters.js';
import {getLetterContent,getLessonContent,getVowelContent} from '../data/content-locales.js';

function shuffle(items){const copy=[...items];for(let i=copy.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[copy[i],copy[j]]=[copy[j],copy[i]];}return copy;}
function pick(items,count,excludeId){return shuffle(items.filter(x=>x.id!==excludeId)).slice(0,count);}


// A learner only gets tested on letters that were introduced in the current batch.
export function buildLetterLearningBatch(introducedIds=[],batchSize=3){
 const seen=new Set(introducedIds);
 const remaining=alphabet.filter(letter=>!seen.has(letter.id));
 if(remaining.length>0&&remaining.length<Math.max(1,batchSize)&&seen.size>0)return alphabet.slice(-Math.max(1,batchSize));
 return remaining.slice(0,Math.max(1,batchSize));
}

export function buildLetterBatchQuestions(batch,language='ru'){
 return batch.map((target,index)=>{
  const letter=getLetterContent(target,language);
  const choices=shuffle(batch).map(item=>{const content=getLetterContent(item,language);return {id:item.id,label:content.isolated,arabic:true};});
  return {id:`learned-letter-${target.id}-${index}`,mode:'letter-batch',prompt:'gameFindLetter',glyph:letter.isolated,name:letter.name,options:choices,answer:target.id,why:letter.name};
 });
}

export function buildMissionQuestions(moduleId,language='ru',count=8){
 const questions=[];
 if(moduleId==='letters'){
  for(let i=0;i<count;i++){
   const target=alphabet[Math.floor(Math.random()*alphabet.length)];
   const mode=i%2===0?'glyph-to-name':'name-to-glyph';
   const letter=getLetterContent(target,language);
   const choices=shuffle([target,...pick(alphabet,3,target.id)]);
   questions.push({id:`letter-${target.id}-${i}`,mode,prompt:mode==='glyph-to-name'?'gameIdentifyName':'gameIdentifyGlyph',glyph:letter.isolated,name:letter.name,options:choices.map(x=>{const c=getLetterContent(x,language);return {id:x.id,label:mode==='glyph-to-name'?c.name:c.isolated,arabic:mode==='name-to-glyph'};}),answer:target.id,why:letter.name});
  }
 }
 if(moduleId==='forms'){
  const joiners=alphabet.filter(x=>x.joinsNext);
  for(let i=0;i<count;i++){
   const target=joiners[Math.floor(Math.random()*joiners.length)];
   const position=['initial','medial','final'][i%3];
   const letter=getLetterContent(target,language);
   const choices=shuffle([target,...pick(joiners,3,target.id)]);
   questions.push({id:`form-${target.id}-${position}-${i}`,prompt:'gameChooseForm',glyph:letter.isolated,name:letter.name,position,options:choices.map(x=>({id:x.id,label:getLetterContent(x,language)[position],arabic:true})),answer:target.id,why:`${letter.name}: ${letter[position]}`});
  }
 }
 if(moduleId==='joining'){
  for(let i=0;i<count;i++){
   const target=alphabet[Math.floor(Math.random()*alphabet.length)];
   questions.push({id:`join-${target.id}-${i}`,prompt:'gameCanJoin',glyph:target.isolated,name:getLetterContent(target,language).name,options:[{id:'yes',label:'gameYes'},{id:'no',label:'gameNo'}],answer:target.joinsNext?'yes':'no',why:target.joinsNext?'gameJoinExplanationYes':'gameJoinExplanationNo'});
  }
 }
 if(moduleId==='vowels'){
  const vowels=getVowelContent(vowelMarks,language);
  for(let i=0;i<count;i++){
   const target=vowels[i%vowels.length];
   questions.push({id:`vowel-${target.id}-${i}`,prompt:'gameNameVowel',glyph:target.example,name:target.name,options:shuffle(vowels).map(x=>({id:x.id,label:x.name})),answer:target.id,why:target.detail});
  }
 }
 const groups={'sukun-shadda-tanwin':signLessons,madd:maddLessons,orthography:orthographyLessons,syllables:syllableLessons};
 if(groups[moduleId]){
  groups[moduleId].forEach(source=>{const lesson=getLessonContent(source,language);questions.push({id:`${moduleId}-${source.id}`,promptText:lesson.check.question,glyph:lesson.symbol,options:lesson.check.options.map((label,index)=>({id:String(index),label})),answer:String(lesson.check.answer),why:lesson.check.why});});
 }
 return questions;
}

export function scoreMission(answers,questions){
 const correct=questions.reduce((total,q,index)=>total+(answers[index]===q.answer?1:0),0);
 const accuracy=questions.length?Math.round(correct/questions.length*100):0;
 const perfect=correct===questions.length;
 const stars=accuracy>=90?3:accuracy>=70?2:accuracy>0?1:0;
 return {correct,total:questions.length,accuracy,perfect,stars,xp:correct*10+stars*10+(perfect?20:0)};
}

export function buildLetterHuntRound(){
 const target=alphabet[Math.floor(Math.random()*alphabet.length)];
 const distractors=shuffle(alphabet.filter(letter=>letter.id!==target.id)).slice(0,9);
 const tiles=shuffle([target,target,target,...distractors]).map((letter,index)=>({id:`${letter.id}-${index}`,letterId:letter.id,glyph:letter.isolated,isTarget:letter.id===target.id}));
 return {target,tiles};
}

export function scoreLetterHunt(found,total=15){
 const correct=Math.max(0,Math.min(total,Number(found)||0));
 const accuracy=Math.round(correct/total*100);
 const perfect=correct===total;
 const stars=accuracy>=90?3:accuracy>=70?2:accuracy>0?1:0;
 return {correct,total,accuracy,perfect,stars,xp:correct*10+stars*10+(perfect?20:0)};
}

export function getUnlockedZoneCount(stars=[]){
 let unlocked=1;
 for(let i=0;i<7;i++){if((Number(stars[i])||0)>0)unlocked=i+2;else break;}
 return Math.min(8,unlocked);
}
