import {letters} from '../data/letters.js';
export function getLearnedLetterCount(introducedIds=[]) {
  const saved = new Set(Array.isArray(introducedIds) ? introducedIds : []);
  let count = 0;
  while (count < letters.length && saved.has(letters[count].id)) count++;
  return count;
}
export function getLetterChallenge(currentIndex, language='ru', getContent=(letter)=>letter) {
  if (!Number.isInteger(currentIndex) || currentIndex < 1 || currentIndex >= letters.length) return null;
  const target = letters[currentIndex];
  const known = letters.slice(0, currentIndex + 1);
  const options = known.slice(Math.max(0, known.length - 4));
  return {target, name:getContent(target, language).name, options:options.map(letter=>({id:letter.id,glyph:letter.isolated})), answer:target.id};
}
export function markLetterLearned(introducedIds=[], letterId) {
  const count = getLearnedLetterCount(introducedIds);
  if (count >= letters.length || letters[count]?.id !== letterId) return [...introducedIds];
  return [...letters.slice(0,count).map(letter=>letter.id), letterId];
}
