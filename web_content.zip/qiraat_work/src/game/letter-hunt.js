const SHAPE_DECOYS = ['●','◆','▲','✦','⬟','○','◇','△'];

export function createLetterHuntTiles(target, knownLetters = [], random = Math.random) {
  const pool = knownLetters.filter(letter => letter.id !== target.id);
  const decoys = [];
  for (let i = 0; i < 5; i++) {
    if (pool.length && (i < 3 || i % 2 === 0)) {
      const letter = pool[Math.floor(random() * pool.length)];
      decoys.push({ id: `known-${i}`, glyph: letter.isolated, kind: 'known' });
    } else {
      const shape = SHAPE_DECOYS[Math.floor(random() * SHAPE_DECOYS.length)];
      decoys.push({ id: `shape-${i}`, glyph: shape, kind: 'shape' });
    }
  }
  const tiles = [...decoys, { id: target.id, glyph: target.isolated, kind: 'target' }];
  for (let i = tiles.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [tiles[i], tiles[j]] = [tiles[j], tiles[i]];
  }
  return tiles;
}
