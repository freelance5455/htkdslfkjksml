// Verified individual human recordings. Missing entries are intentionally omitted;
// the UI must never substitute device TTS and label it as a recording.
export const letterAudio = {
  alif: {
    src: 'https://commons.wikimedia.org/wiki/Special:FilePath/Letra_alif_por_la_Escuela_Internacional_de_%C3%81rabe.ogg',
    source: 'https://commons.wikimedia.org/wiki/File:Letra_alif_por_la_Escuela_Internacional_de_%C3%81rabe.ogg',
    creator: 'Escuela Internacional de Árabe',
    license: 'CC BY 4.0'
  },
  ba: {
    src: 'https://commons.wikimedia.org/wiki/Special:FilePath/Letra_ba%27_por_la_Escuela_Internacional_de_%C3%81rabe.ogg',
    source: 'https://commons.wikimedia.org/wiki/File:Letra_ba%27_por_la_Escuela_Internacional_de_%C3%81rabe.ogg',
    creator: 'Escuela Internacional de Árabe',
    license: 'CC BY 4.0'
  }
};
