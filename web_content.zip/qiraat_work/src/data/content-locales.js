import {signLessons,maddLessons,orthographyLessons,syllableLessons,vowelMarks} from './curriculum.js';

// Instructional content is deliberately available in Russian and English only in this release.
// Other interface locales use English lesson content until their translations are completed.
const englishLessons = {
 sukun:{title:'Sukun (ْ)',explanation:'Sukun shows that no short vowel follows the consonant. Read the consonant without adding “a”, “i” or “u”.',check:{question:'Which mark indicates that no short vowel follows a consonant?',options:['Sukun ْ','Shadda ّ','Fatha َ'],why:'Sukun ْ marks a consonant without a following short vowel.'}},
 shadda:{title:'Shadda (ّ)',explanation:'Shadda indicates a doubled consonant. In reading, the consonant is held longer: conceptually, this combines the first consonant without a vowel and the second with its vowel mark.',check:{question:'What does shadda indicate?',options:['A long vowel','A doubled consonant','A pause'],why:'Shadda indicates a doubled consonant sound.'}},
 tanwin:{title:'Tanwin (ً ٍ ٌ)',explanation:'Tanwin is a double vowel mark at the end of a word: fathatayn, kasratayn and dammatayn. In the relevant reading forms, it represents a final “n” sound. Rules for pausing and connected reading are studied separately.',check:{question:'How many basic tanwin marks are studied in this lesson?',options:['Two','Three','Four'],why:'There are three forms: fathatayn, kasratayn and dammatayn.'}},
 alif:{title:'Long vowel with alif ا',explanation:'In a basic teaching combination, fatha followed by alif produces the long “ā” sound. Here alif serves as a lengthening letter, not as a separate new consonant.',check:{question:'Which short vowel usually comes before alif madd?',options:['Fatha','Kasra','Damma'],why:'Alif madd follows fatha and lengthens the “a” sound.'}},
 ya:{title:'Long vowel with ya ي',explanation:'Kasra followed by ya madd produces the long “ī” sound. Do not confuse ya as a consonant with ya when it functions as a lengthening letter.',check:{question:'Which short vowel before ya madd produces long “ī”?',options:['Fatha','Kasra','Damma'],why:'Ya madd follows kasra.'}},
 waw:{title:'Long vowel with waw و',explanation:'Damma followed by waw madd produces the long “ū” sound. Waw can also be a consonant in another context.',check:{question:'Which short vowel before waw madd produces long “ū”?',options:['Fatha','Kasra','Damma'],why:'Waw madd follows damma.'}},
 hamza:{title:'Hamza ء',explanation:'Hamza represents a glottal stop. It can be written independently or on a carrier: alif, waw or ya. Its position and spelling follow orthographic rules.',check:{question:'What sound does hamza represent?',options:['A glottal stop','A long “a” sound','A nasal sound'],why:'Hamza represents a glottal stop.'}},
 wasl:{title:'Hamzat al-wasl ٱ',explanation:'Hamzat al-wasl is pronounced when beginning recitation from the relevant word, but is not pronounced when joining it to the preceding word according to reading rules. It is distinct from hamzat al-qatʿ.',check:{question:'What happens to hamzat al-wasl when joining to the preceding word?',options:['It is always doubled','It is not pronounced','It becomes a long vowel'],why:'When joining, hamzat al-wasl is not pronounced.'}},
 qat:{title:'Hamzat al-qatʿ أ / إ',explanation:'Hamzat al-qatʿ is pronounced both at the beginning and when joining to a preceding word. Its written mark remains.',check:{question:'Is hamzat al-qatʿ pronounced when joining?',options:['Yes','No'],why:'Hamzat al-qatʿ retains its pronunciation.'}},
 'ta-marbuta':{title:'Ta marbuta ة',explanation:'Ta marbuta appears at the end of a word. Its reading differs between continuing and stopping; the specific pronunciation depends on context and stopping rules.',check:{question:'Where is ta marbuta usually found?',options:['At the beginning','In the middle','At the end'],why:'Ta marbuta is a word-final form.'}},
 maqsurah:{title:'Alif maqsurah ى',explanation:'Alif maqsurah resembles ya without dots and usually appears at the end of a word. In reading it represents the long “ā” sound, not the consonant “y”.',check:{question:'Which long sound does alif maqsurah usually represent?',options:['ā','ī','ū'],why:'Alif maqsurah represents the long “ā” sound.'}},
 open:{title:'Open syllables',explanation:'An open syllable ends in a vowel sound. First identify the consonant, then its vowel mark, and read the combination smoothly.',check:{question:'Which sound does kasra indicate?',options:['a','i','u'],why:'Kasra indicates the short “i” sound.'}},
 closed:{title:'Closed syllables',explanation:'A closed syllable ends in a consonant that is not followed by a short vowel. Sukun helps identify the final consonant.',check:{question:'Which mark often shows a final consonant without a following short vowel?',options:['Sukun','Damma','Tanwin'],why:'Sukun indicates that no short vowel follows the consonant.'}},
 long:{title:'Syllables with a long vowel',explanation:'Compare short and long combinations: بَ / بَا, بِ / بِي, بُ / بُو. Length changes the duration of the vowel.',check:{question:'Which combination contains the long “ī” sound?',options:['بَا','بِي','بُو'],why:'Kasra followed by ya madd forms “ī”.'}},
 shadda:{title:'Syllables with a doubled consonant',explanation:'Shadda doubles the consonant. Do not skip the first part of the doubled consonant or turn it into a separate vowel.',check:{question:'Which mark indicates a doubled consonant?',options:['Sukun','Shadda','Kasra'],why:'Shadda indicates a doubled consonant.'}}
};

const lessonGroups=[signLessons,maddLessons,orthographyLessons,syllableLessons];
export function getLessonContent(lesson,language='ru'){
 if(language==='ru')return lesson;
 const translated=lesson.id==='shadda'?(lesson.title.startsWith('Слоги')?{title:'Syllables with a doubled consonant',explanation:'Shadda doubles the consonant. Do not skip the first part of the doubled consonant or turn it into a separate vowel.',check:{question:'Which mark indicates a doubled consonant?',options:['Sukun','Shadda','Kasra'],why:'Shadda indicates a doubled consonant.'}}:{title:'Shadda (ّ)',explanation:'Shadda indicates a doubled consonant. In reading, the consonant is held longer: conceptually, this combines the first consonant without a vowel and the second with its vowel mark.',check:{question:'What does shadda indicate?',options:['A long vowel','A doubled consonant','A pause'],why:'Shadda indicates a doubled consonant sound.'}}):englishLessons[lesson.id];
 if(!translated)return lesson;
 return {...lesson,...translated,check:{...lesson.check,...translated.check}};
}
export function getLessonGroups(language='ru'){
 return lessonGroups.map(group=>group.map(lesson=>getLessonContent(lesson,language)));
}
export function getVowelContent(items=vowelMarks,language='ru'){
 if(language==='ru')return items;
 const values={fatha:{name:'Fatha',reading:'ba',detail:'A short “a” sound after the consonant.'},kasra:{name:'Kasra',reading:'bi',detail:'A short “i” sound after the consonant.'},damma:{name:'Damma',reading:'bu',detail:'A short “u” sound after the consonant.'}};
 return items.map(item=>({...item,...values[item.id]}));
}

const englishLetters={
 alif:['Alif','Long vowel carrier or hamza carrier, depending on context'],ba:['Ba','B'],ta:['Ta','T'],tha:['Tha','Voiceless “th”, as in “think”'],jim:['Jim','J'],ha:['Ha (ح)','Voiceless pharyngeal consonant'],kha:['Kha','Voiceless uvular or velar fricative'],dal:['Dal','D'],dhal:['Dhal','Voiced “th”, as in “this”'],ra:['Ra','R, articulated with the tongue tip'],zay:['Zay','Z'],sin:['Sin','S'],shin:['Shin','Sh'],sad:['Sad','Emphatic S'],dad:['Dad','Emphatic D'],ta_emphatic:['Ta (ط)','Emphatic T'],za_emphatic:['Za (ظ)','Emphatic voiced interdental consonant'],ayn:['Ayn','Voiced pharyngeal consonant'],ghayn:['Ghayn','Voiced uvular fricative'],fa:['Fa','F'],qaf:['Qaf','Deep Q'],kaf:['Kaf','K'],lam:['Lam','L'],mim:['Mim','M'],nun:['Nun','N'],ha_round:['Ha (ه)','Light breathy h'],waw:['Waw','W; also a long-vowel carrier in the relevant context'],ya:['Ya','Y; also a long-vowel carrier in the relevant context']
};
export function getLetterContent(letter,language='ru'){
 if(language==='ru')return letter;
 const [name,sound]=englishLetters[letter.id]||[letter.name,letter.sound];
 return {...letter,name,sound};
}
