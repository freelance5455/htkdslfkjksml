# Letter audio status

QIRAAT uses individual human-recorded audio only when the exact letter recording and reuse terms have been verified. Device text-to-speech is not presented as recorded audio.

## Integrated recordings

| Letter | Recording | Creator | License | Notes |
|---|---|---|---|---|
| ا (Alif) | [Wikimedia Commons file](https://commons.wikimedia.org/wiki/File:Letra_alif_por_la_Escuela_Internacional_de_%C3%81rabe.ogg) | Escuela Internacional de Árabe (Eiarabe) | CC BY 4.0 | Streamed from Wikimedia Commons; attribution link shown in app |
| ب (Bāʾ) | [Wikimedia Commons file](https://commons.wikimedia.org/wiki/File:Letra_ba%27_por_la_Escuela_Internacional_de_%C3%81rabe.ogg) | Escuela Internacional de Árabe (Eiarabe) | CC BY 4.0 | Streamed from Wikimedia Commons; attribution link shown in app |

## Not yet integrated

The remaining 26 letters do not yet have verified individual human recordings in this build. Their buttons are intentionally not shown. No synthetic voice or segment of an unrelated recording is substituted.

External streaming requires an internet connection. Offline audio is not yet included.
