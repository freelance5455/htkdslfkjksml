import test from 'node:test';
import assert from 'node:assert/strict';
import {letters} from '../src/data/letters.js';
import {modules,vowelMarks} from '../src/data/curriculum.js';
import {languages,dictionaries,t} from '../src/i18n/locales.js';

test('exactly 28 unique Arabic base letters are present',()=>{assert.equal(letters.length,28);assert.equal(new Set(letters.map(x=>x.id)).size,28);assert.equal(new Set(letters.map(x=>x.isolated)).size,28);});
test('six non-joining letters are correctly represented without invented connected forms',()=>{const noJoin=letters.filter(x=>!x.joinsNext);assert.deepEqual(noJoin.map(x=>x.isolated),['ا','د','ذ','ر','ز','و']);for(const l of noJoin){assert.equal(l.initial,undefined);assert.equal(l.medial,undefined);}});
test('joining letters include all positional forms',()=>{for(const l of letters.filter(x=>x.joinsNext)){assert.ok(l.initial&&l.medial&&l.final,l.id);}});
test('12 interface languages have dictionary entries',()=>{assert.equal(languages.length,12);for(const lang of languages)assert.ok(dictionaries[lang.code]);});
test('short vowel module has fatha kasra and damma',()=>{assert.deepEqual(vowelMarks.map(x=>x.id),['fatha','kasra','damma']);});
test('the current scope contains eight Arabic-script learning modules and no Quran course',()=>{assert.equal(modules.length,8);assert.equal(modules.some(x=>x.id==='quran-practice'||x.id==='tajwid'),false);});
import {signLessons,maddLessons,orthographyLessons,syllableLessons} from '../src/data/curriculum.js';

test('modules 5–8 contain structured teaching content and checks',()=>{
  const active=['sukun-shadda-tanwin','madd','orthography','syllables'];
  for(const id of active)assert.equal(modules.find(m=>m.id===id).status,'available');
  for(const lessons of [signLessons,maddLessons,orthographyLessons,syllableLessons]){
    assert.ok(lessons.length>=3);
    assert.equal(new Set(lessons.map(x=>x.id)).size,lessons.length);
    for(const lesson of lessons){
      assert.ok(lesson.title&&lesson.explanation&&lesson.symbol&&lesson.examples.length);
      assert.ok(lesson.check.question&&lesson.check.options.length>=2);
      assert.ok(lesson.check.answer>=0&&lesson.check.answer<lesson.check.options.length);
      assert.ok(lesson.check.why);
    }
  }
});

test('the learning path remains focused on Arabic letters and script',()=>{assert.ok(modules.every(m=>!['tajwid','quran-practice'].includes(m.id)));});
import {parseProgressBackup} from '../src/storage/progress.js';

test('progress backup parser validates and normalizes a supported backup',()=>{
  const value=parseProgressBackup({format:'qiraat-progress',version:1,data:{completedLessons:['letters'],letterCorrect:['alif'],letterAttempts:{alif:2},settings:{language:'ru',theme:'dark'}}});
  assert.deepEqual(value.completedLessons,['letters']);
  assert.equal(value.settings.theme,'dark');
  assert.deepEqual(value.topicChecks,{});assert.deepEqual(value.reviewSchedule,{});
});

test('progress backup parser rejects unsupported or malformed backups',()=>{
  assert.throws(()=>parseProgressBackup({format:'other',version:1,data:{}}));
  assert.throws(()=>parseProgressBackup({format:'qiraat-progress',version:1,data:{completedLessons:'bad',letterCorrect:[],letterAttempts:{}}}));
  assert.throws(()=>parseProgressBackup({format:'qiraat-progress',version:1,data:{completedLessons:[],letterCorrect:[],letterAttempts:{},settings:{language:'xx'}}}));
});

import {scheduleReview,getDueReviews} from '../src/storage/repetition.js';
test('spaced repetition schedules correct answers progressively and resets after a lapse',()=>{
  const now=new Date('2026-01-01T12:00:00Z');
  const first=scheduleReview(null,4,now);assert.equal(first.intervalDays,1);assert.equal(first.repetitions,1);
  const second=scheduleReview(first,4,now);assert.equal(second.intervalDays,6);assert.equal(second.repetitions,2);
  const lapse=scheduleReview(second,1,now);assert.equal(lapse.intervalDays,1);assert.equal(lapse.repetitions,0);
  assert.equal(getDueReviews({x:first},new Date('2026-01-03T00:00:00Z')).length,1);
  assert.throws(()=>scheduleReview(null,7,now),RangeError);
});

import {evaluateExam} from '../src/storage/exams.js';
test('module exam requires every answer and enforces 80 percent threshold',()=>{
 const questions=[{answer:0},{answer:1},{answer:2},{answer:0},{answer:1}];
 assert.deepEqual(evaluateExam([0,1,2,0,2],questions),{correct:4,total:5,score:80,passed:true,threshold:80});
 assert.equal(evaluateExam([0,1,2,2,2],questions).passed,false);
 assert.throws(()=>evaluateExam([0],questions));
 assert.throws(()=>evaluateExam([],[]));
});

import {buildCoreExam} from '../src/data/core-exams.js';
test('core modules 1–4 have practical scored exam banks',()=>{
 for(const id of ['letters','forms','joining','vowels']){
  const bank=buildCoreExam(id);assert.ok(bank.length>=3,id);
  for(const item of bank){assert.ok(item.question&&item.options.length>=2);assert.ok(item.answer>=0&&item.answer<item.options.length);assert.ok(item.why);}
 }
 assert.equal(buildCoreExam('joining').filter(x=>x.answer===1).length,6);
 assert.equal(buildCoreExam('vowels').length,3);
 assert.equal(buildCoreExam('letters').length,28);
 assert.equal(buildCoreExam('forms').length,28);
 assert.ok(new Set(buildCoreExam('letters').map(x=>x.answer)).size>1);
});


test('exam scorer rejects invalid thresholds, answer keys and option indices',()=>{
 const qs=[{answer:0},{answer:1}];
 assert.throws(()=>evaluateExam([0,1],qs,1.1),RangeError);
 assert.throws(()=>evaluateExam([0,1],qs,-0.1),RangeError);
 assert.throws(()=>evaluateExam([0,1],[{answer:-1},{answer:1}]));
 assert.throws(()=>evaluateExam([0,-1],qs));
 assert.equal(evaluateExam([0,1],qs,1).passed,true);
});

test('backup parser retains exam results and validates accessibility settings',()=>{
 const value=parseProgressBackup({format:'qiraat-progress',version:1,data:{completedLessons:[],letterCorrect:[],letterAttempts:{},examResults:{letters:{score:90,passed:true}},settings:{language:'ru',theme:'light',fontScale:1.2}}});
 assert.equal(value.examResults.letters.score,90);
 assert.equal(value.settings.fontScale,1.2);
 assert.throws(()=>parseProgressBackup({format:'qiraat-progress',version:1,data:{completedLessons:[],letterCorrect:[],letterAttempts:{},settings:{fontScale:2}}}));
 assert.throws(()=>parseProgressBackup({format:'qiraat-progress',version:1,data:{completedLessons:[],letterCorrect:[],letterAttempts:{},examResults:[]}}));
});

test('all 12 interface dictionaries expose every English interface key',()=>{
  const keys=Object.keys(dictionaries.en);
  for(const language of languages){
    assert.deepEqual(Object.keys(dictionaries[language.code]),keys,language.code);
    for(const key of keys)assert.equal(typeof dictionaries[language.code][key],'string',`${language.code}:${key}`);
  }
});

test('translation interpolation replaces dynamic review and exam values',()=>{
  assert.equal(t('reviewDue','en',{due:3,total:8}),'Due for review: 3. Skills in schedule: 8.');
  assert.equal(t('examResult','ru',{correct:8,total:10,score:80,threshold:80}),'Результат: 8 из 10 (80%). Порог прохождения: 80%.');
});

test('progress denominator includes only modules currently available to study',()=>{
  const available=modules.filter(module=>module.status==='available');
  assert.equal(available.length,8);
  assert.equal(modules.filter(module=>module.status==='source-pending').length,0);
});

import {getLessonContent,getLetterContent,getVowelContent} from '../src/data/content-locales.js';

test('English instructional content covers every structured lesson without replacing Arabic examples',()=>{
 const groups=[signLessons,maddLessons,orthographyLessons,syllableLessons];
 for(const group of groups)for(const source of group){
  const translated=getLessonContent(source,'en');
  assert.ok(translated.title&&translated.explanation&&translated.check.question&&translated.check.why,source.id);
  assert.deepEqual(translated.examples,source.examples);
  assert.equal(translated.symbol,source.symbol);
 }
 const syllableShadda=getLessonContent(syllableLessons.find(x=>x.id==='shadda'),'en');
 assert.equal(syllableShadda.title,'Syllables with a doubled consonant');
 assert.equal(getLessonContent(signLessons.find(x=>x.id==='shadda'),'en').title,'Shadda (ّ)');
});

test('English letter and vowel content is complete and preserves Arabic glyphs',()=>{
 for(const source of letters){const translated=getLetterContent(source,'en');assert.ok(translated.name&&translated.sound,source.id);assert.equal(translated.isolated,source.isolated);}
 const translated=getVowelContent(vowelMarks,'en');
 assert.deepEqual(translated.map(x=>x.name),['Fatha','Kasra','Damma']);
 assert.deepEqual(translated.map(x=>x.example),vowelMarks.map(x=>x.example));
});

test('core exams follow the selected Russian or English content language',async()=>{
 const {buildCoreExam}=await import('../src/data/core-exams.js');
 assert.match(buildCoreExam('letters','en')[0].question,/What is the name/);
 assert.match(buildCoreExam('letters','ru')[0].question,/Как называется/);
 assert.match(buildCoreExam('joining','en')[0].options[0],/Yes|No/);
 assert.match(buildCoreExam('vowels','en')[0].why,/Fatha|Kasra|Damma/);
});



test('backup parser remains compatible with older saves and validates game stats',()=>{
 const data={format:'qiraat-progress',version:1,data:{completedLessons:[],letterCorrect:[],letterAttempts:{},game:{xp:120,gamesPlayed:3,bestScore:8,zoneStars:[3,2,0,0,0,0,0,0],completedMissions:{letters:2},achievements:['first'],letterMastery:{ba:true},collectibles:['letters']}}};
 const parsed=parseProgressBackup(data);assert.equal(parsed.game.xp,120);assert.deepEqual(parsed.game.zoneStars,[3,2,0,0,0,0,0,0]);assert.deepEqual(parsed.game.achievements,['first']);assert.equal(parsed.game.letterMastery.ba,true);assert.deepEqual(parsed.game.collectibles,['letters']);
 assert.throws(()=>parseProgressBackup({...data,data:{...data.data,game:{xp:-1}}}));
 assert.throws(()=>parseProgressBackup({...data,data:{...data.data,game:{achievements:{bad:true}}}}));assert.throws(()=>parseProgressBackup({...data,data:{...data.data,game:{collectibles:{bad:true}}}}));
});

test('the app starts directly on the first letter and contains no worlds or course map',async()=>{
 const fs=await import('node:fs/promises');const app=await fs.readFile(new URL('../src/app/main.js',import.meta.url),'utf8');const html=await fs.readFile(new URL('../index.html',import.meta.url),'utf8');
 assert.match(app,/render\(\);\s*$/);assert.match(app,/renderIntro\(count\)/);assert.match(html,/id="game"/);
 assert.doesNotMatch(html,/Карта миров|module-list|world-map|dashboard-grid|course-section/);
 assert.doesNotMatch(app,/renderGameHome|startMission|gameWorldIds|world-node/);
});

test('a letter is introduced before the challenge, and only already introduced letters are answer choices',async()=>{
 const {getLearnedLetterCount,getLetterChallenge,markLetterLearned}=await import('../src/game/linear-progress.js');
 assert.equal(getLearnedLetterCount([]),0);
 const first=markLetterLearned([],'alif');assert.deepEqual(first,['alif']);assert.equal(getLearnedLetterCount(first),1);
 const challenge=getLetterChallenge(1,'ru',getLetterContent);assert.equal(challenge.answer,'ba');assert.deepEqual(challenge.options.map(x=>x.id),['alif','ba']);
 const second=markLetterLearned(first,'ba');assert.deepEqual(second,['alif','ba']);
 assert.deepEqual(markLetterLearned(second,'jim'),second,'out-of-order letters cannot be unlocked');
});

test('linear progression never skips an unknown letter even if a backup contains later IDs',async()=>{
 const {getLearnedLetterCount}=await import('../src/game/linear-progress.js');
 assert.equal(getLearnedLetterCount(['alif','ta','jim']),1);
 assert.equal(getLearnedLetterCount(letters.map(x=>x.id)),28);
});

test('letter introductions persist in a backup and malformed introduction lists are rejected',()=>{
 const base={format:'qiraat-progress',version:1,data:{completedLessons:[],letterCorrect:[],letterAttempts:{},game:{letterIntroduced:['alif','ba','ta']}}};
 const restored=parseProgressBackup(base);assert.deepEqual(restored.game.letterIntroduced,['alif','ba','ta']);
 assert.throws(()=>parseProgressBackup({...base,data:{...base.data,game:{letterIntroduced:'alif'}}}));
 assert.throws(()=>parseProgressBackup({...base,data:{...base.data,game:{letterIntroduced:['alif','alif']}}}));
});


test('individual letter audio only exposes verified human recordings with source and license metadata',async()=>{
 const {letterAudio}=await import('../src/data/letter-audio.js');
 assert.deepEqual(Object.keys(letterAudio).sort(),['alif','ba']);
 for(const [id,recording] of Object.entries(letterAudio)){assert.ok(recording.src.includes('commons.wikimedia.org'));assert.ok(recording.source.includes('commons.wikimedia.org/wiki/File:'));assert.equal(recording.license,'CC BY 4.0');assert.ok(recording.creator);}
 const fs=await import('node:fs/promises');const app=await fs.readFile(new URL('../src/app/main.js',import.meta.url),'utf8');
 assert.match(app,/const recording=letterAudio\[letter\.id\]/);assert.match(app,/audio\.play\(\)/);assert.doesNotMatch(app,/speechSynthesis|SpeechSynthesisUtterance/);
});

test('letter hunt round has six tiles and exactly one target',async()=>{
 const {createLetterHuntTiles}=await import('../src/game/letter-hunt.js');
 const target=letters[0];
 const tiles=createLetterHuntTiles(target,[],()=>0.37);
 assert.equal(tiles.length,6);
 assert.equal(tiles.filter(tile=>tile.kind==='target'&&tile.id===target.id).length,1);
 assert.ok(tiles.filter(tile=>tile.kind!=='target').every(tile=>tile.kind==='shape'));
});

test('letter hunt distractors never reveal letters that have not been introduced',async()=>{
 const {createLetterHuntTiles}=await import('../src/game/letter-hunt.js');
 const target=letters[5],known=letters.slice(0,5);
 const tiles=createLetterHuntTiles(target,known,Math.random);
 assert.equal(tiles.filter(tile=>tile.id===target.id).length,1);
 const knownGlyphs=new Set(known.map(letter=>letter.isolated));
 for(const tile of tiles.filter(item=>item.kind==='known'))assert.ok(knownGlyphs.has(tile.glyph));
 assert.ok(tiles.every(tile=>tile.kind==='target'||tile.kind==='known'||tile.kind==='shape'));
});


test('v0.17 arcade redesign is wired into both intro and hunt screens', async () => {
  const {readFile} = await import('node:fs/promises');
  const main = await readFile(new URL('../src/app/main.js', import.meta.url), 'utf8');
  const css = await readFile(new URL('../src/ui/styles.css', import.meta.url), 'utf8');
  const sw = await readFile(new URL('../service-worker.js', import.meta.url), 'utf8');
  for (const token of ['arcade-topline','arcade-stage','letter-orbit','mission-strip','arcade-cta']) assert.ok(main.includes(token), `missing intro UI: ${token}`);
  for (const token of ['hunt-scorebar','arcade-arena','target-halo','tile-index','win-burst']) assert.ok(main.includes(token), `missing hunt UI: ${token}`);
  for (const token of ['.arcade-stage','.arcade-arena','.hunt-tile.found','@keyframes letterFloat','prefers-reduced-motion']) assert.ok(css.includes(token), `missing arcade styling: ${token}`);
  assert.match(sw, /qiraat-shell-v17/);
});
