# QIRAAT v0.8.0 — verification report

Date: 2026-11-03

## Automated checks

- `npm test`: **21 passed, 0 failed**.
- `node --check` passed for `src/app/main.js`, `src/data/core-exams.js`, `src/data/content-locales.js`, `src/i18n/locales.js` and `src/storage/progress.js`.
- HTTP smoke check served `index.html` and the new instructional locale module over a local HTTP server.
- Regression coverage confirms English lesson text exists for every structured lesson, Arabic glyphs/examples remain unchanged, letter and vowel content is present, and core exams use the selected Russian or English instructional language.

## Work included

- Added English explanations, titles, quiz prompts, answer options and feedback for modules 5–8.
- Added English letter names and sound descriptions for all 28 letters.
- Added English vowel-mark names, readings and descriptions.
- Localized core exam question banks for letters, positional forms, joining and short vowels.
- Localized spaced-repetition prompts for letter and structured-lesson review.
- Added a visible language notice when a non-Russian interface is selected; English is currently the instructional fallback.
- Preserved Arabic Unicode glyphs and sample combinations.
- Updated the service-worker cache namespace to `qiraat-shell-v8` and precached the new content locale module.

## Limitations

- Full instructional localization is currently available only in Russian and English. The other ten interface languages display English lesson content.
- The browser smoke check verifies HTTP delivery only; no full browser automation, RTL visual audit, screen-reader test or physical-device test was performed.
- Tajwid and Quran-practice modules remain source-gated. No Quran text, authoritative recitation audio, APK/AAB or Android device test was added in this update.
