# QIRAAT v0.13.0 — test report

Date: 2026-11-03

## Changes verified
- Main entry screen reduced to one primary game entry; secondary dashboard, review and course listing hidden from the main path.
- Letter world teaches three letters one at a time before presenting a recognition challenge.
- Recognition options in the first challenge are drawn only from the letters shown in that batch.
- Introduced-letter progress is persisted and backup-validated.
- Last new letter is reinforced in a three-letter recap batch.
- Completing a world challenge unlocks the next world without requiring a high score.
- No lives or countdown timer were added.

## Automated checks
- `npm test`: 33 passed, 0 failed.
- `node --check`: main.js, missions.js, progress.js passed.
- HTTP smoke test: index.html and core module files returned successfully from local server.
- ZIP integrity check passed.

## Not verified
- No physical Android device/browser interaction test in this run.
- No APK build.
- Individual human-recorded audio clips for each letter are still not integrated; existing full-alphabet recording remains a single track.
- The other seven worlds still need the same introduce-first gameplay treatment; this release fixes the first letters world flow.
