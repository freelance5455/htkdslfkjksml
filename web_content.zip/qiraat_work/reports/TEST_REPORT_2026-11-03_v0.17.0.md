# QIRAAT v0.17.0 — test report

Date: 2026-11-03

## Automated checks

- `npm test`: 30 passed, 0 failed.
- `node --check src/app/main.js`: passed.
- `node --check src/data/letter-audio.js`: passed.
- ZIP integrity: `unzip -t QIRAAT_v0.17.0.zip` passed.
- Added regression test verifies arcade UI markup in both letter-introduction and hunt screens, arcade CSS/animations, reduced-motion handling, and service-worker cache version.

## Visual changes

- New emerald arcade scene with animated orbit around the introduced letter.
- Level badge, XP wallet and progress bar.
- Mission strip and gold action button.
- Hunt screen redesigned as a target arena with target halo, numbered tiles, lives, caught counter and round XP.
- Hit/miss feedback and animated reward panel.
- Separate light-theme styling; reduced-motion preference respected.

## Not verified

- No physical Android device test was performed.
- Headless Chromium screenshot capture did not complete in this environment.
- Audio availability still depends on the external Wikimedia streams; only alif and bāʾ have verified individual recordings.
