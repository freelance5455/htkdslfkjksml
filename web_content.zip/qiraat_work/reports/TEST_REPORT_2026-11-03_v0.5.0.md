# QIRAAT v0.5.0 — verification report

- Node test suite: 13 passed, 0 failed.
- `node --check src/app/main.js`: passed.
- `node --check src/data/core-exams.js`: passed.
- Added exam banks for all 28 letters, all 28 letter forms, 12 joining cases, and the three short-vowel marks.
- Correct answer positions vary; the answer is not always the first option.
- The exam evaluator requires all questions to be answered and applies an 80% pass threshold.
- Tajwid and Quran reading remain gated pending source-identified religious content and licensed, text-matched audio.
- No physical Android-device test and no APK/AAB build are claimed.
