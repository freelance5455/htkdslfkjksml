# QIRAAT v0.14.0 — test report

Date: 2026-11-03

## Automated checks

- `npm test`: **26 passed, 0 failed**.
- `node --check` on every JavaScript file under `src/`: passed.
- Local HTTP smoke check: `index.html` and `src/game/linear-progress.js` served successfully.
- ZIP integrity: to be checked after packaging.

## Verified behaviour in code/tests

- App shell starts directly on the first unlearned letter; no start screen is required.
- World map, course list, and world-navigation UI have been removed from `index.html` and the active app flow.
- Letters unlock strictly in the source order.
- A letter is shown with its name, a short sound hint and available positional forms before a recognition challenge.
- From the second letter onward, answer choices contain only the current letter and previously introduced letters.
- Progress persists through the existing local IndexedDB/localStorage layer.
- Old saves remain readable; progression is normalized to a continuous prefix so a later letter cannot bypass an earlier one.

## Not verified / not implemented

- Full interactive browser test: attempted with headless Chromium, but the browser process did not terminate in this environment; no browser-test pass is claimed.
- Physical Android device test: not performed.
- Individual audio recordings for the 28 letters: not integrated.
- Android APK/AAB: not built.
- Non-Russian instructional localization: still incomplete.
