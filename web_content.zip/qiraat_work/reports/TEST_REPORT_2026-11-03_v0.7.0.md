# QIRAAT v0.7.0 — verification report

Date: 2026-11-03

## Automated checks

- `npm test`: **18 passed, 0 failed**.
- `node --check src/i18n/locales.js`: passed.
- `node --check src/app/main.js`: passed.
- Dictionary coverage test confirms that all 12 configured interface locales expose every key in the English interface dictionary.
- Interpolation tests confirm that review counts and exam results render with dynamic values.

## Work included

- Expanded the interface dictionaries to cover the dashboard, module names/descriptions, review panel, exam controls/results, core lesson navigation and accessibility labels in 12 configured languages.
- Added dynamic translation interpolation for review and exam status strings.
- Localized the review panel and several lesson introductions/table labels.
- Fixed progress calculation so the two source-gated modules do not prevent learners from reaching 100% of currently available course content.
- Updated the service-worker cache namespace to `qiraat-shell-v7`.

## Important limitations

- This is **not** a claim of complete course localization. The detailed instructional lesson content, lesson questions/explanations, letter names/transliterations and much of the exercise bank remain Russian-language data. Some supplemental labels in secondary locales currently fall back to English.
- Arabic and Urdu interface direction is RTL; this has been configured but not yet verified in a real browser/device visual test.
- No browser automation, screen-reader test, physical Android test, APK/AAB build, Quran source integration, or recitation audio verification was performed in this update.
- Tajwid and Quran-practice modules remain source-gated.
