# QIRAAT v0.15.0 test report

Date: 2026-11-03

- Node test suite: 27 passed, 0 failed.
- `node --check src/app/main.js`: passed.
- `node --check src/data/letter-audio.js`: passed.
- Audio metadata test: confirms only two verified human recordings are exposed (alif and bāʾ), each with a Commons source and CC BY 4.0 attribution.
- Static inspection: no device speech synthesis fallback is used.

Limitations:
- 26 of 28 individual recordings remain unsourced and are not presented as available.
- Audio is streamed from Wikimedia Commons and requires internet.
- Browser/device playback was not physically tested in this environment.
- Android APK has not been built or tested.
