# Blazing Wheels Championship 2026 — starter app

Mobile-first shared championship portal with racer accounts and server-enforced Race Director access.

## Included
- Registration/login; setup-key gated account creation (first account becomes Race Director; later accounts are racers).
- Shared SQLite data for races, riders, announcements, laps, pit stops, results and technical-zone settings.
- Manual publication of announcements/races; results are only shown publicly after an official approves them.
- Race points 20/15/10/5 and challenge bonuses technical +2, precision +2, sportsmanship +1 (maximum +5).
- Race-control stopwatch, lap recording, pit-stop log, results/DNF, CSV export.
- Mobile-first dark motorsport UI, track/rules pages, standings, race history.

## Run locally
Install Node.js 20+, copy `.env.example` to `.env`, set a strong unique `SESSION_SECRET` and private `ADMIN_SETUP_KEY`, then run `npm install` and `npm start`. Open http://localhost:3000.

## First account
The first account created with the setup key becomes Race Director; subsequent accounts are racers. Keep the setup key private and rotate/remove it after initial setup. For public launch, replace this bootstrap mechanism with proper invite-only provisioning, email verification and password reset.

## Shared online use
Devices see shared data only when using the same deployed server. SQLite needs persistent storage; for multi-instance hosting migrate to managed PostgreSQL. Deploy behind HTTPS, set secure secrets, configure backups, and test with multiple accounts/devices before the event.

## Android
This is a mobile-first web-app starter, not an APK. Deploy and test it first; package with a trusted Android wrapper such as Capacitor and test on physical devices afterward.

## Limitations
Not publicly deployed, not penetration-tested, and no real race data is preloaded. Race control should be tested carefully before live use. Do not store sensitive personal data.
