import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

export function createWorld(scene, psx) {
  scene.background = new THREE.Color(0x090d12);

  const materials = new Map(), boxes = new Map(), mergedGeometry = new Set();
  const modelGeometry = new Set(), modelMaterials = new Set(), modelTextures = new Set();
  const modelLoads = new Map();
  const mat = color => {
    if (!materials.has(color)) materials.set(color,psx.material({color}));
    return materials.get(color);
  };
  const box = (w,h,d) => {
    const key = `${w},${h},${d}`;
    if (!boxes.has(key)) boxes.set(key, new THREE.BoxGeometry(w,h,d));
    return boxes.get(key);
  };

  const root = new THREE.Group(); scene.add(root);

  const fixed = new THREE.Group(); root.add(fixed);
  const batches = new Map();
  function batch(color, w,h,d,x,y,z) {
    const material = mat(color);
    if (!batches.has(material)) batches.set(material, []);
    const geometry = box(w,h,d).clone();
    geometry.translate(x,y,z); batches.get(material).push(geometry);
  }
  function prop(name,w,h,d,x,y,z,color) {
    const mesh = new THREE.Mesh(box(w,h,d), mat(color));
    mesh.name = name; mesh.position.set(x,y,z); fixed.add(mesh); return mesh;
  }

  batch(0x202528,20,.2,20,0,-.12,-1);          // quiet street
  batch(0x48413a,6,.16,3,0,0,0);                // stand floor
  batch(0x33271d,4.5,1.05,.72,0,.68,-.85);     // counter
  batch(0x806143,4.6,.12,.82,0,1.24,-.85);    // countertop
  batch(0x2c2925,.18,1.6,.18,-1.75,2.2,-.9); // lantern cord
  batch(0x8c552a,.62,.42,.62,-1.75,1.3,-.9);  // lantern
  batch(0x31271e,.16,3.8,.16,-5.4,1.9,-5.8);  // streetlight pole
  batch(0xd1ad70,.42,.12,.42,-5.4,3.85,-5.8); // streetlight head
  for (let i=0;i<7;i++) {
    const side = i%2 ? 1 : -1, z = -3 - Math.floor(i/2)*2.5;
    batch(i%3===0 ? 0x252a2b : 0x1b2022,1.6,2.4+(i%3)*.55,1.7,side*6.2,1.2,z);
  }
  for (const [material, parts] of batches) {
    const geometry = mergeGeometries(parts, false);
    if (geometry) { fixed.add(new THREE.Mesh(geometry, material)); mergedGeometry.add(geometry); }
    for (const part of parts) part.dispose();
  }

  const bowlFallback = prop('bowl-fallback',.45,.18,.45,-.35,1.39,-.85,0x8d8170);
  const stoveFallback = prop('stove-fallback',.9,.12,.72,-1.25,1.38,-.85,0x262829);
  const potFallback = prop('pot-fallback',.62,.65,.62,-1.25,1.68,-.85,0x101416);
  const stools = [];
  for (const z of [-2.6,.9]) for (const x of [-1.55,1.45]) {
    const stool = new THREE.Group(); stool.position.set(x,0,z); fixed.add(stool); stools.push({ stool,x,z });
    const leg = new THREE.Mesh(box(.34,.72,.34),mat(0x3b3026)); leg.position.y=.36; stool.add(leg);
    const seat = new THREE.Mesh(box(.55,.1,.55),mat(0x6a5034)); seat.position.y=.78; stool.add(seat);
  }

  // A small rest room sits behind the stand, with a bed and the night computer.
  prop('bedroom-floor',4,.12,4,6.4,.02,3.2,0x342f2c);
  prop('bedroom-back-wall',4,2.8,.12,6.4,1.42,5.2,0x29292a);
  prop('bedroom-east-wall',.12,2.8,4,8.4,1.42,3.2,0x29292a);
  prop('bedroom-north-wall',.12,2.8,1.3,4.4,1.42,1.85,0x29292a);
  prop('bedroom-south-wall',.12,2.8,1.3,4.4,1.42,4.55,0x29292a);
  prop('bed-frame',1.75,.42,2.15,7.05,.34,3.95,0x493b32);
  prop('bed-mattress',1.65,.24,2.05,7.05,.66,3.95,0xaaa39a);
  prop('bed-blanket',1.68,.18,1.15,7.05,.82,4.35,0x58616a);
  prop('bed-pillow',.75,.16,.42,7.05,.85,3.18,0xc4b8a4);
  prop('desk',1.65,.14,.72,5.25,.82,2.0,0x493b30);
  prop('computer-monitor',.92,.64,.11,5.25,1.24,1.78,0x252b2b);
  prop('computer-screen',.78,.48,.025,5.25,1.25,1.71,0x55735f);
  prop('computer-keyboard',.72,.05,.25,5.25,.93,1.72,0x252728);
  prop('computer-tower',.3,.66,.48,4.35,.45,2.2,0x282c2c);
  for(const [x,y,z] of [[-2.9,2.25,-2.5],[2.9,2.25,-2.5],[0,2.65,1.3]]) {
    prop('cctv-camera',.24,.16,.28,x,y,z,0x323b3d);
    prop('cctv-lens',.11,.1,.04,x,y,z-.16,0x7b8b83);
  }
  // Simple drive-up vehicle: the plate and paint change with each visitor.
  const vehicle=new THREE.Group(); vehicle.position.set(0,0,-4.25); vehicle.visible=false; root.add(vehicle);
  const paint=psx.material({color:0xe3d6b9});
  const plateCanvas=document.createElement('canvas');plateCanvas.width=256;plateCanvas.height=64;
  const plateContext=plateCanvas.getContext('2d');
  const plateTexture=new THREE.CanvasTexture(plateCanvas);
  const plateMaterial=psx.material({map:plateTexture,unlit:true});
  const vehicleExtraMaterials=new Set([paint,plateMaterial]);
  const wheelGeometry=new THREE.CylinderGeometry(.18,.18,.16,6);
  const plateGeometry=new THREE.PlaneGeometry(.66,.16);
  const vehicleExtraGeometry=new Set([wheelGeometry,plateGeometry]);
  vehicle.add(new THREE.Mesh(box(2.05,.52,2.9),paint));
  const cabin=new THREE.Mesh(box(1.35,.62,1.55),mat(0x343b3d));cabin.position.set(0,.52,-.12);vehicle.add(cabin);
  for(const x of [-.91,.91])for(const z of [-.92,.92]){
    const wheel=new THREE.Mesh(wheelGeometry,mat(0x17191a));wheel.rotation.z=Math.PI/2;wheel.position.set(x,.25,z);vehicle.add(wheel);
  }
  const licensePlate=new THREE.Mesh(plateGeometry,plateMaterial);licensePlate.position.set(0,.36,1.47);vehicle.add(licensePlate);
  function setCustomer(record){
    if(!record){vehicle.visible=false;return;}
    const car=record.vehicle.toLowerCase();
    const color=car.includes('black')||car.includes('charcoal')?0x292b30:car.includes('green')?0x435747:car.includes('blue')?0x465873:car.includes('red')?0x865142:car.includes('yellow')?0x9a8548:car.includes('white')?0xb3b0a7:0xb59f7b;
    paint.uniforms.uColor.value.setHex(color);
    plateContext.fillStyle='#ded6bf';plateContext.fillRect(0,0,256,64);
    plateContext.fillStyle='#1b1a17';plateContext.font='bold 44px monospace';plateContext.textAlign='center';plateContext.textBaseline='middle';plateContext.fillText(record.plate,128,33);
    plateTexture.needsUpdate=true;vehicle.visible=true;
  }
  const ghostMaterial=psx.material({color:0xc0d0cf,opacity:.82,unlit:true});
  const ghost=new THREE.Group(); ghost.visible=false; root.add(ghost);
  const ghostBodyGeometry=new THREE.CylinderGeometry(.18,.43,1.35,6);
  const ghostHeadGeometry=new THREE.SphereGeometry(.27,7,5);
  const ghostEyeGeometry=new THREE.BoxGeometry(.055,.045,.035);
  const eyeMaterial=psx.material({color:0x110f13,unlit:true});
  ghost.add(new THREE.Mesh(ghostBodyGeometry,ghostMaterial));
  const ghostHead=new THREE.Mesh(ghostHeadGeometry,ghostMaterial); ghostHead.position.y=.82; ghost.add(ghostHead);
  for(const x of [-.09,.09]) {const eye=new THREE.Mesh(ghostEyeGeometry,eyeMaterial);eye.position.set(x,.84,-.245);ghost.add(eye);}
  let ghostTimer=0,ghostActive=false;
  function scare(playerPosition,yaw=0){
    const forward=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw));
    ghost.position.set(playerPosition.x+forward.x*3,0,playerPosition.z+forward.z*3);
    ghost.lookAt(playerPosition.x,1,playerPosition.z); ghost.visible=true;ghostActive=true;ghostTimer=3.2;
  }
  function updateGhost(dt,playerPosition){
    if(!ghostActive)return; ghostTimer-=dt;
    const target=new THREE.Vector3(playerPosition.x,0,playerPosition.z);
    ghost.position.lerp(target,Math.min(dt*.35,.025));
    if(ghostTimer<=0){ghost.visible=false;ghostActive=false;}
  }
  const loader = new GLTFLoader();
  function loadModel(url) {
    if (!modelLoads.has(url)) {
      modelLoads.set(url, loader.loadAsync(url).then(({ scene: model }) => {
        const sourceMaterials=new Set();
        model.traverse(object=>{if(object.isMesh)for(const material of (Array.isArray(object.material)?object.material:[object.material]))if(material)sourceMaterials.add(material);});
        psx.applyToGLTF(model);
        for(const material of sourceMaterials)material.dispose();
        model.traverse(object => {
          if (!object.isMesh) return;
          object.castShadow=false; object.receiveShadow=false; modelGeometry.add(object.geometry);
          const list=Array.isArray(object.material)?object.material:[object.material];
          for(const material of list){
            modelMaterials.add(material);
            const map=material.uniforms?.uMap?.value; if(map)modelTextures.add(map);
          }
        });
        return model;
      }));
    }
    return modelLoads.get(url);
  }
  function loadOptional(url, position, height, fallback) {
    const holder = new THREE.Group(); holder.position.set(...position); root.add(holder);
    loadModel(url).then(template => {
      const model = template.clone(true);
      let bounds = new THREE.Box3().setFromObject(model);
      const size = bounds.getSize(new THREE.Vector3());
      if (size.y > 0) model.scale.setScalar(height / size.y);
      model.updateMatrixWorld(true);
      bounds = new THREE.Box3().setFromObject(model);
      const center = bounds.getCenter(new THREE.Vector3());
      model.position.set(-center.x,-bounds.min.y,-center.z);
      holder.add(model);
      if (fallback) fallback.visible = false;
    }).catch(() => {}); // Keep the blockout if the asset is absent or invalid.
  }
  loadOptional('./assets/models/ramen_bowl.glb',[-.35,1.30,-.85],.34,bowlFallback);
  loadOptional('./assets/models/stove.glb',[-1.25,1.44,-.85],.22,stoveFallback);
  loadOptional('./assets/models/stock_pot.glb',[-1.25,1.44,-.85],.55,potFallback);
  for (const { stool,x,z } of stools) loadOptional('./assets/models/stool.glb',[x,0,z],.78,stool);

  return { scare, updateGhost, setCustomer, dispose() {
    for (const geometry of boxes.values()) geometry.dispose();
    for (const geometry of mergedGeometry) geometry.dispose();
    for (const geometry of modelGeometry) geometry.dispose();
    for (const material of materials.values()) material.dispose();
    for (const material of modelMaterials) material.dispose();
    for (const texture of modelTextures) texture.dispose();
    ghostBodyGeometry.dispose(); ghostHeadGeometry.dispose(); ghostEyeGeometry.dispose();
    ghostMaterial.dispose(); eyeMaterial.dispose();
    for(const material of vehicleExtraMaterials)material.dispose();
    plateTexture.dispose();for(const geometry of vehicleExtraGeometry)geometry.dispose();scene.remove(root);
  } };
}

