import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

export function createWorld(scene, psx) {
  scene.background = new THREE.Color(0x090d12);

  const materials = new Map(), boxes = new Map(), mergedGeometry = new Set();
  const modelGeometry = new Set(), modelMaterials = new Set(), modelTextures = new Set();
  const modelLoads = new Map();
  let disposed = false;
  const mat = color => {
    if (!materials.has(color)) materials.set(color,psx.material({color}));
    return materials.get(color);
  };
  const box = (w,h,d) => {
    const key = `${w},${h},${d}`;
    if (!boxes.has(key)) boxes.set(key, new THREE.BoxGeometry(w,h,d));
    return boxes.get(key);
  };

  const root = new THREE.Group(); scene.add(root);

  const fixed = new THREE.Group(); root.add(fixed);
  const batches = new Map();
  function batch(color, w,h,d,x,y,z) {
    const material = mat(color);
    if (!batches.has(material)) batches.set(material, []);
    const geometry = box(w,h,d).clone();
    geometry.translate(x,y,z); batches.get(material).push(geometry);
  }
  function prop(name,w,h,d,x,y,z,color) {
    const mesh = new THREE.Mesh(box(w,h,d), mat(color));
    mesh.name = name; mesh.position.set(x,y,z); fixed.add(mesh); return mesh;
  }

  batch(0x202528,20,.2,20,0,-.12,-1);          // quiet street
  batch(0x48413a,6,.16,3,0,0,0);                // stand floor
  // Leave a centered service pass through the counter and worktop.
  for(const x of [-1.35,1.35]){
    batch(0x33271d,1.8,1.05,.72,x,.68,-.85);
    batch(0x806143,1.82,.12,.82,x,1.24,-.85);
  }
  batch(0x2c2925,.18,1.6,.18,-1.75,2.2,-.9); // lantern cord
  batch(0x8c552a,.62,.42,.62,-1.75,1.3,-.9);  // lantern
  batch(0x31271e,.16,3.8,.16,-5.4,1.9,-5.8);  // streetlight pole
  batch(0xd1ad70,.42,.12,.42,-5.4,3.85,-5.8); // streetlight head
  for (let i=0;i<7;i++) {
    const side = i%2 ? 1 : -1, z = -3 - Math.floor(i/2)*2.5;
    batch(i%3===0 ? 0x252a2b : 0x1b2022,1.6,2.4+(i%3)*.55,1.7,side*6.2,1.2,z);
  }
  for (const [material, parts] of batches) {
    const geometry = mergeGeometries(parts, false);
    if (geometry) { fixed.add(new THREE.Mesh(geometry, material)); mergedGeometry.add(geometry); }
    for (const part of parts) part.dispose();
  }

  const bowlFallback = prop('bowl-fallback',.45,.18,.45,-.35,1.39,-.85,0x8d8170);
  const stoveFallback = prop('stove-fallback',.9,.12,.72,-1.25,1.38,-.85,0x262829);
  const potFallback = prop('pot-fallback',.62,.65,.62,-1.25,1.68,-.85,0x101416);
  const stools = [];
  for (const z of [-2.6,.9]) for (const x of [-1.55,1.45]) {
    const stool = new THREE.Group(); stool.position.set(x,0,z); fixed.add(stool); stools.push({ stool,x,z });
    const leg = new THREE.Mesh(box(.34,.72,.34),mat(0x3b3026)); leg.position.y=.36; stool.add(leg);
    const seat = new THREE.Mesh(box(.55,.1,.55),mat(0x6a5034)); seat.position.y=.78; stool.add(seat);
  }

  // A small rest room sits behind the stand, with a bed and the night computer.
  prop('bedroom-floor',4,.12,4,6.4,.02,3.2,0x342f2c);
  prop('bedroom-back-wall',4,2.8,.12,6.4,1.42,5.2,0x29292a);
  prop('bedroom-east-wall',.12,2.8,4,8.4,1.42,3.2,0x29292a);
  prop('bedroom-north-wall',.12,2.8,1.3,4.4,1.42,1.85,0x29292a);
  prop('bedroom-south-wall',.12,2.8,1.3,4.4,1.42,4.55,0x29292a);
  prop('bed-frame',1.75,.42,2.15,7.05,.34,3.95,0x493b32);
  prop('bed-mattress',1.65,.24,2.05,7.05,.66,3.95,0xaaa39a);
  prop('bed-blanket',1.68,.18,1.15,7.05,.82,4.35,0x58616a);
  prop('bed-pillow',.75,.16,.42,7.05,.85,3.18,0xc4b8a4);
  prop('desk',1.65,.14,.72,5.25,.82,4.45,0x493b30);
  prop('computer-monitor',.92,.64,.11,5.25,1.24,4.23,0x252b2b);
  prop('computer-screen',.78,.48,.025,5.25,1.25,4.16,0x55735f);
  prop('computer-keyboard',.72,.05,.25,5.25,.93,4.17,0x252728);
  prop('computer-tower',.3,.66,.48,4.45,.45,4.6,0x282c2c);
  for(const [x,y,z] of [[-2.9,2.25,-2.5],[2.9,2.25,-2.5],[0,2.65,1.3]]) {
    prop('cctv-camera',.24,.16,.28,x,y,z,0x323b3d);
    prop('cctv-lens',.11,.1,.04,x,y,z-.16,0x7b8b83);
  }
  // Simple drive-up vehicle: the plate and paint change with each visitor.
  const vehicle=new THREE.Group(); vehicle.position.set(0,0,-4.25); vehicle.visible=false; root.add(vehicle);
  let departureTimer=0;
  function customerLeaves(){customer.visible=false;if(vehicle.visible)departureTimer=1.35;}
  function updateDeparture(dt){if(departureTimer<=0)return;departureTimer-=dt;vehicle.position.z-=dt*2.8;if(departureTimer<=0){departureTimer=0;vehicle.visible=false;vehicle.position.z=-4.25;}}
  const paint=psx.material({color:0xe3d6b9});
  const plateCanvas=document.createElement('canvas');plateCanvas.width=256;plateCanvas.height=64;
  const plateContext=plateCanvas.getContext('2d');
  const plateTexture=new THREE.CanvasTexture(plateCanvas);
  const plateMaterial=psx.material({map:plateTexture,unlit:true});
  const vehicleExtraMaterials=new Set([paint,plateMaterial]);
  const wheelGeometry=new THREE.CylinderGeometry(.18,.18,.16,6);
  const plateGeometry=new THREE.PlaneGeometry(.66,.16);
  const vehicleExtraGeometry=new Set([wheelGeometry,plateGeometry]);
  vehicle.add(new THREE.Mesh(box(2.05,.52,2.9),paint));
  const cabin=new THREE.Mesh(box(1.35,.62,1.55),mat(0x343b3d));cabin.position.set(0,.52,-.12);vehicle.add(cabin);
  for(const x of [-.91,.91])for(const z of [-.92,.92]){
    const wheel=new THREE.Mesh(wheelGeometry,mat(0x17191a));wheel.rotation.z=Math.PI/2;wheel.position.set(x,.25,z);vehicle.add(wheel);
  }
  const licensePlate=new THREE.Mesh(plateGeometry,plateMaterial);licensePlate.position.set(0,.36,1.47);vehicle.add(licensePlate);
  function setCustomer(record){
    if(!record){departureTimer=0;vehicle.visible=false;customer.visible=false;vehicle.position.z=-4.25;return;}
    departureTimer=0;vehicle.position.z=-4.25;const car=record.vehicle.toLowerCase();customer.visible=true;customerFallback.visible=!customerModelLoaded;customerBody.material=mat(car.includes('red')?0x60403b:car.includes('blue')?0x3e4b5c:0x414b56);customerHead.material=mat(record.name.length%2?0xb38b70:0x98745f);
    const color=car.includes('black')||car.includes('charcoal')?0x292b30:car.includes('green')?0x435747:car.includes('blue')?0x465873:car.includes('red')?0x865142:car.includes('yellow')?0x9a8548:car.includes('white')?0xb3b0a7:0xb59f7b;
    paint.uniforms.uColor.value.setHex(color);
    plateContext.fillStyle='#ded6bf';plateContext.fillRect(0,0,256,64);
    plateContext.fillStyle='#1b1a17';plateContext.font='bold 44px monospace';plateContext.textAlign='center';plateContext.textBaseline='middle';plateContext.fillText(record.plate,128,33);
    plateTexture.needsUpdate=true;vehicle.visible=true;
  }
  // A blocky customer waits at the service window while their car remains on the road.
  const customer=new THREE.Group();customer.visible=false;customer.position.set(0,0,-1.75);root.add(customer);
  const customerFallback=new THREE.Group();customerFallback.name='blocky-customer-fallback';customer.add(customerFallback);
  const customerBody=new THREE.Mesh(box(.48,.88,.28),mat(0x414b56));customerBody.position.y=.78;customerFallback.add(customerBody);
  const customerHead=new THREE.Mesh(box(.32,.34,.3),mat(0xb38b70));customerHead.position.y=1.42;customerFallback.add(customerHead);
  const customerHair=new THREE.Mesh(box(.34,.12,.32),mat(0x211d20));customerHair.position.set(0,1.62,0);customerFallback.add(customerHair);
  for(const x of [-.075,.075]){const eye=new THREE.Mesh(box(.035,.035,.018),mat(0x111416));eye.position.set(x,1.44,.16);customerFallback.add(eye);}
  const customerMouth=new THREE.Mesh(box(.075,.018,.018),mat(0x492b2d));customerMouth.position.set(0,1.34,.16);customerFallback.add(customerMouth);
  for(const x of [-.3,.3]){const arm=new THREE.Mesh(box(.14,.62,.16),mat(0x414b56));arm.position.set(x,.83,0);customerFallback.add(arm);}
  for(const x of [-.13,.13]){const leg=new THREE.Mesh(box(.16,.48,.18),mat(0x292a30));leg.position.set(x,.24,0);customerFallback.add(leg);}
  const ghostMaterial=psx.material({color:0xc0d0cf,opacity:.82,unlit:true});
  const ghost=new THREE.Group(); ghost.visible=false; root.add(ghost);
  const ghostBodyGeometry=new THREE.CylinderGeometry(.18,.43,1.35,6);
  const ghostHeadGeometry=new THREE.SphereGeometry(.27,7,5);
  const ghostEyeGeometry=new THREE.BoxGeometry(.055,.045,.035);
  const eyeMaterial=psx.material({color:0x110f13,unlit:true});
  const ghostFallback=new THREE.Group();ghostFallback.name='procedural-ghost-fallback';ghost.add(ghostFallback);
  ghostFallback.add(new THREE.Mesh(ghostBodyGeometry,ghostMaterial));
  const ghostHead=new THREE.Mesh(ghostHeadGeometry,ghostMaterial); ghostHead.position.y=.82; ghostFallback.add(ghostHead);
  for(const x of [-.09,.09]) {const eye=new THREE.Mesh(ghostEyeGeometry,eyeMaterial);eye.position.set(x,.84,-.245);ghostFallback.add(eye);}
  // The same pale figure can watch from the street, then appear close during a scare.
  const watcher=ghost.clone(true);watcher.name='roadside-watcher';watcher.visible=false;root.add(watcher);
  const watcherSpots=[[1.45,-7.1],[-1.5,-6.7],[1.7,-8.4],[-1.25,-9.1]];
  function setWatcher(visible,playerPosition={x:0,z:0},index=0){
    watcher.visible=Boolean(visible);if(!watcher.visible)return;
    const [x,z]=watcherSpots[index%watcherSpots.length];watcher.position.set(x,0,z);watcher.lookAt(playerPosition.x,1,playerPosition.z);
  }
  let ghostTimer=0,ghostActive=false,watcherPhase=0;
  const ghostTarget=new THREE.Vector3();
  function updateWatcher(dt,playerPosition){if(!watcher.visible)return;watcherPhase+=dt;watcher.lookAt(playerPosition.x,1,playerPosition.z);watcher.position.y=.035+Math.sin(watcherPhase*2.2)*.025;}
  function scare(playerPosition,yaw=0){
    watcher.visible=false;const forward=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw));
    ghost.position.set(playerPosition.x+forward.x*2.2,0,playerPosition.z+forward.z*2.2);
    ghost.lookAt(playerPosition.x,1,playerPosition.z);ghost.scale.setScalar(1.18);ghost.visible=true;ghostActive=true;ghostTimer=2.4;
  }
  function clearHaunting(){watcher.visible=false;ghost.visible=false;ghostActive=false;ghostTimer=0;}
  function updateGhost(dt,playerPosition){
    if(!ghostActive)return; ghostTimer-=dt;
    ghostTarget.set(playerPosition.x,0,playerPosition.z);
    ghost.position.lerp(ghostTarget,Math.min(dt*.35,.025));
    if(ghostTimer<=0){ghost.visible=false;ghostActive=false;}
  }
  const loader = new GLTFLoader();
  function loadModel(url) {
    if (!modelLoads.has(url)) {
      modelLoads.set(url, loader.loadAsync(url).then(({ scene: model }) => {
        const sourceMaterials=new Set();
        model.traverse(object=>{if(object.isMesh)for(const material of (Array.isArray(object.material)?object.material:[object.material]))if(material)sourceMaterials.add(material);});
        psx.applyToGLTF(model);
        for(const material of sourceMaterials)material.dispose();
        const geometries=new Set(),materials=new Set(),textures=new Set();
        model.traverse(object => {
          if (!object.isMesh) return;
          object.castShadow=false; object.receiveShadow=false; geometries.add(object.geometry);
          const list=Array.isArray(object.material)?object.material:[object.material];
          for(const material of list){materials.add(material);const map=material.uniforms?.uMap?.value;if(map)textures.add(map);}
        });
        const targetGeometry=disposed?null:modelGeometry,targetMaterials=disposed?null:modelMaterials,targetTextures=disposed?null:modelTextures;
        if(disposed){for(const geometry of geometries)geometry.dispose();for(const material of materials)material.dispose();for(const texture of textures)texture.dispose();}
        else{for(const geometry of geometries)targetGeometry.add(geometry);for(const material of materials)targetMaterials.add(material);for(const texture of textures)targetTextures.add(texture);}
        return model;
      }));
    }
    return modelLoads.get(url);
  }
  function fitModel(model,height) {
    let bounds=new THREE.Box3().setFromObject(model);
    const size=bounds.getSize(new THREE.Vector3());
    if(size.y>0)model.scale.setScalar(height/size.y);
    model.updateMatrixWorld(true);bounds=new THREE.Box3().setFromObject(model);
    const center=bounds.getCenter(new THREE.Vector3());
    model.position.set(-center.x,-bounds.min.y,-center.z);
  }
  function loadOptional(url, position, height, fallback) {
    const holder = new THREE.Group(); holder.position.set(...position); root.add(holder);
    loadModel(url).then(template => {
      if(disposed)return;
      const model = template.clone(true);
      fitModel(model,height);
      holder.add(model);
      if (fallback) fallback.visible = false;
    }).catch(() => {}); // Keep the blockout if the asset is absent or invalid.
  }
  let customerModelLoaded=false;
  loadModel('./assets/models/characters/customer-psx.glb').then(template=>{
    if(disposed)return;
    const model=template.clone(true);fitModel(model,1.72);model.name='psx-customer';customer.add(model);
    customerModelLoaded=true;customerFallback.visible=false;
  }).catch(()=>{});
  loadModel('./assets/models/ghost.glb').then(template=>{
    if(disposed)return;
    for(const target of [ghost,watcher]){
      const model=template.clone(true);fitModel(model,1.9);model.name='white-ghost-model';target.add(model);
      const fallback=target.getObjectByName('procedural-ghost-fallback');if(fallback)fallback.visible=false;
    }
  }).catch(()=>{});
  loadOptional('./assets/models/japanese-food/ramen_bowl.glb',[-.35,1.30,-.85],.34,bowlFallback);
  loadOptional('./assets/models/stove.glb',[-1.25,1.44,-.85],.22,stoveFallback);
  loadOptional('./assets/models/stock_pot.glb',[-1.25,1.44,-.85],.55,potFallback);
  for (const { stool,x,z } of stools) loadOptional('./assets/models/stool.glb',[x,0,z],.78,stool);
  loadOptional('./assets/models/japanese-food/nigiri_salmon.glb',[.78,1.30,-.72],.16,null);
  loadOptional('./assets/models/japanese-food/maki_roll.glb',[1.16,1.30,-.72],.16,null);
  loadOptional('./assets/models/japanese-food/soy_sauce_set.glb',[1.62,1.30,-.72],.22,null);

  const solids = [
    {minX:-2.30,maxX:-.45,minZ:-1.32,maxZ:-.38},
    {minX:.45,maxX:2.30,minZ:-1.32,maxZ:-.38},
    {minX:-5.55,maxX:-5.25,minZ:-5.95,maxZ:-5.65},
    {minX:4.34,maxX:4.46,minZ:1.15,maxZ:2.50},
    {minX:4.34,maxX:4.46,minZ:3.90,maxZ:5.25},
    {minX:4.30,maxX:8.50,minZ:5.14,maxZ:5.26},
    {minX:8.34,maxX:8.46,minZ:1.15,maxZ:5.25},
    {minX:6.175,maxX:7.925,minZ:2.875,maxZ:5.025},
    {minX:4.425,maxX:6.075,minZ:4.09,maxZ:4.81},
    {minX:4.30,maxX:4.62,minZ:4.36,maxZ:4.84}
  ];
  for (const z of [-2.6,.9]) for (const x of [-1.55,1.45]) solids.push({minX:x-.34,maxX:x+.34,minZ:z-.34,maxZ:z+.34});
  for (let i=0;i<7;i++) { const side=i%2?1:-1,z=-3-Math.floor(i/2)*2.5;solids.push({minX:side*6.2-.82,maxX:side*6.2+.82,minZ:z-.88,maxZ:z+.88}); }
  function collides(x,z,radius=.24) {
    if (solids.some(r=>x+radius>r.minX&&x-radius<r.maxX&&z+radius>r.minZ&&z-radius<r.maxZ)) return true;
    if(customer.visible&&x+radius>-.3&&x-radius<.3&&z+radius>-1.95&&z-radius<-1.55)return true;
    const carZ=vehicle.position.z;return vehicle.visible&&x+radius> -1.05&&x-radius<1.05&&z+radius>carZ-1.47&&z-radius<carZ+1.47;
  }
  const nearComputer=position=>Math.hypot(position.x-5.25,position.z-3.18)<1.25;
  const nearBed=position=>Math.hypot(position.x-6.5,position.z-2.55)<.72;
  const nearCustomer=position=>customer.visible&&Math.hypot(position.x,position.z+1.75)<1.75;
  const nearStove=position=>Math.hypot(position.x+1.25,position.z-.08)<1.15;
  const nearBowl=position=>Math.hypot(position.x+.35,position.z-.08)<1.10;
  const nearServingPass=position=>Math.hypot(position.x-.85,position.z-.08)<1.12;
  return { scare, setWatcher, updateWatcher, clearHaunting, updateGhost, setCustomer, customerLeaves, updateDeparture, collides, nearComputer, nearBed, nearCustomer, nearStove, nearBowl, nearServingPass, dispose() {
    disposed=true;
    for (const geometry of boxes.values()) geometry.dispose();
    for (const geometry of mergedGeometry) geometry.dispose();
    for (const geometry of modelGeometry) geometry.dispose();
    for (const material of materials.values()) material.dispose();
    for (const material of modelMaterials) material.dispose();
    for (const texture of modelTextures) texture.dispose();
    ghostBodyGeometry.dispose(); ghostHeadGeometry.dispose(); ghostEyeGeometry.dispose();
    ghostMaterial.dispose(); eyeMaterial.dispose();
    for(const material of vehicleExtraMaterials)material.dispose();
    plateTexture.dispose();for(const geometry of vehicleExtraGeometry)geometry.dispose();scene.remove(root);
  } };
}

