# தொலைந்த பூனை (LOST & FOUND) — HTML-only project

**BFS DEVELOPERS PVT.**  
Created by **AHMED AFSHAN SIKKANDER**  
**BUILD • CREATE • EXPERIENCE**

## Files
- `index.html` — game interface
- `style.css` — visual design and responsive controls
- `script.js` — Canvas game, movement, chapters, interactions and save system
- `assets/` — optional location for your own sound/image files

## Run
The project uses only HTML, CSS, vanilla JavaScript and the built-in HTML Canvas API. No Three.js, Unity, Unreal, or game engine is used.

1. Extract the ZIP.
2. Open `index.html` in a modern browser.
3. For Android, open the folder in an HTML-to-APK/WebView wrapper and set `index.html` as the start page.
4. Enable JavaScript, DOM storage and hardware acceleration. The game now displays in portrait or landscape and does not show a rotation-blocking screen. If you prefer landscape, set orientation to Landscape in the APK wrapper settings; HTML cannot override a native wrapper orientation lock.

The Tamil font is loaded from Google Fonts when internet is available; the game itself does not depend on it. For offline use, install a Tamil system font or place a licensed font in the project and update `style.css`.

## Controls
- Left virtual joystick: move Milo
- Right camera pad: adjust view
- `தாவு`: jump
- `ஓடு`: run
- `செயல்`: interact with the chapter objective
- `Ⅱ`: pause
- Keyboard fallback: WASD/arrow keys, E to interact, Shift to run, Escape to pause

## Visual note
This is a self-contained Canvas-based 2D/perspective adventure, not photorealistic 3D. The cat, Chennai-inspired streets, rain, lighting, stalls and props are drawn procedurally in JavaScript. Custom high-detail art, voice acting and recorded music can be added later in `assets/`.
