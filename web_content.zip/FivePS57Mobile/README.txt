5P57 for Android phones
=======================
1. Install Android Studio (free) on a computer.
2. File > Open, choose this FivePS57Mobile folder. Wait for the first Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
   Output: app/build/outputs/apk/debug/app-debug.apk
4. Copy app-debug.apk to the phone, open it, and allow "install unknown apps" for your file manager or browser.
5. Open "5P57" from the app drawer.

To publish on the Play Store, use Build > Generate Signed Bundle (AAB) in Android Studio.
The whole UI is in app/src/main/assets/index.html. Edit it and rebuild to change anything.
