# Real Prédiction — Android starter project

This is a simple Android WebView app starter for **Real Prédiction**. It includes:
- Football match analysis (manual team/stat input; illustrative heuristic, not guaranteed)
- Aviator / Crash history logging and basic descriptive statistics
- Number history logging
- Local history saved on the device

## Build an APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Let Gradle sync, then choose **Build > Build APK(s)**.
4. Find the debug APK in `app/build/outputs/apk/debug/`.

This ZIP is source code, not an already-built APK. Building a signed/release APK requires Android Studio and Android SDK.
The app does not connect to Bet261, predict provably random results, place bets, or guarantee winnings.
