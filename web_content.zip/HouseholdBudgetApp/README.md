# Household Budget Tracker - Android app

A WebView app that bundles the tracker page (app/src/main/assets/index.html). It works fully offline:
no internet permission (only calendar access, asked when you add a reminder), data kept in the app's local storage, Excel export saved to Downloads.

## Fastest way to get the APK (no Android Studio)
1. Create a free GitHub account and a new repository.
2. Upload the CONTENTS of this folder (including the hidden .github folder) to the repository root.
3. Open the Actions tab > "Build APK" > wait for it to finish (about 3-5 minutes).
4. Download the "budget-tracker-apk" artifact, unzip it, send app-debug.apk to your phone and open it
   (allow "Install unknown apps" when asked).

## Build the APK with Android Studio
1. Install Android Studio (Hedgehog 2023.1 or newer) and open this folder.
2. Let it sync. If it asks about Gradle, accept Gradle 8.5.
3. Phone: enable Developer options + USB debugging, connect, press Run.
   Or build an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
   The file appears in app/build/outputs/apk/debug/.

## Notes
- PIN lock: use the "Set PIN lock" button at the bottom of the app (4 to 6 digits). The app locks on start and after being in the background for 30+ seconds. The PIN only locks the screen; it does not encrypt the stored data. If you forget it, "Forgot PIN?" erases all data, so export backups regularly.
- Requires Android 10 (API 29) or newer.
- Export to Excel writes Household_Budget_Data.xlsx to the Downloads folder.
- Loans have an "Add to calendar" button. It asks for calendar permission once, then adds a monthly 9:00 AM EMI event with your chosen reminder (on the day, 1 day, 3 days or 1 week before). If permission is denied it opens the calendar app with a prefilled event instead.
- Import Excel opens the file picker; use a file exported from this app (you can edit it in Excel first).
- Clearing the app's storage or uninstalling deletes the data, so export regularly as a backup.
- To change the app, edit app/src/main/assets/index.html.
