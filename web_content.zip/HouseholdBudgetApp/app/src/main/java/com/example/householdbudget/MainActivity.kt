package com.example.householdbudget

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.CalendarContract
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import java.util.Calendar
import java.util.TimeZone

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var chooserCallback: ValueCallback<Array<Uri>>? = null

    private data class CalReq(
        val title: String, val date: String, val count: Int,
        val details: String, val daysBefore: Int
    )

    private var pendingReq: CalReq? = null

    private val picker = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        chooserCallback?.onReceiveValue(
            WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        )
        chooserCallback = null
    }

    private val calendarPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val req = pendingReq
        pendingReq = null
        if (req != null) {
            if (grants.values.all { it } && insertWithReminder(req)) {
                // done
            } else {
                toast("Opening your calendar app instead.")
                openCalendarInsert(req)
            }
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun hasCalendarPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED

    /** Creates a monthly 9:00 AM event on the phone's calendar with an alert N days before. */
    private fun insertWithReminder(q: CalReq): Boolean {
        return try {
            val calId = contentResolver.query(
                CalendarContract.Calendars.CONTENT_URI,
                arrayOf(CalendarContract.Calendars._ID),
                "${CalendarContract.Calendars.VISIBLE}=1 AND " +
                    "${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL}>=${CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR}",
                null,
                "${CalendarContract.Calendars.IS_PRIMARY} DESC"
            )?.use { if (it.moveToFirst()) it.getLong(0) else null } ?: return false

            val p = q.date.split("-").map { it.toInt() }
            val start = Calendar.getInstance().apply { clear(); set(p[0], p[1] - 1, p[2], 9, 0) }
            val event = ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, calId)
                put(CalendarContract.Events.TITLE, q.title)
                put(CalendarContract.Events.DESCRIPTION, q.details)
                put(CalendarContract.Events.DTSTART, start.timeInMillis)
                put(CalendarContract.Events.DURATION, "PT30M")
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
                put(CalendarContract.Events.RRULE, "FREQ=MONTHLY;COUNT=${q.count}")
                put(CalendarContract.Events.HAS_ALARM, 1)
            }
            val uri = contentResolver.insert(CalendarContract.Events.CONTENT_URI, event) ?: return false
            val eventId = uri.lastPathSegment?.toLong() ?: return false
            val reminder = ContentValues().apply {
                put(CalendarContract.Reminders.EVENT_ID, eventId)
                put(CalendarContract.Reminders.MINUTES, q.daysBefore * 1440)
                put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
            }
            contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, reminder)
            toast("EMI reminder added to your calendar")
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Fallback: opens the calendar app with a prefilled event (no permission needed). */
    private fun openCalendarInsert(q: CalReq): Boolean {
        return try {
            val p = q.date.split("-").map { it.toInt() }
            val start = Calendar.getInstance().apply { clear(); set(p[0], p[1] - 1, p[2], 9, 0) }.timeInMillis
            val intent = Intent(Intent.ACTION_INSERT).apply {
                data = CalendarContract.Events.CONTENT_URI
                putExtra(CalendarContract.Events.TITLE, q.title)
                putExtra(CalendarContract.Events.DESCRIPTION, q.details)
                putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
                putExtra(CalendarContract.EXTRA_EVENT_END_TIME, start + 30 * 60_000L)
                putExtra(CalendarContract.Events.RRULE, "FREQ=MONTHLY;COUNT=${q.count}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            true
        } catch (e: Exception) {
            toast("No calendar app found")
            false
        }
    }

    /** Exposed to the page as `window.Android`. */
    inner class Bridge {
        @JavascriptInterface
        fun saveFile(name: String, base64: String): Boolean {
            return try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(
                        MediaStore.Downloads.MIME_TYPE,
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    )
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return false
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: return false
                runOnUiThread { toast("Saved to Downloads: $name") }
                true
            } catch (e: Exception) {
                false
            }
        }

        /** Adds a monthly EMI event with an alert [daysBefore] days earlier to the phone calendar. */
        @JavascriptInterface
        fun addEmiReminder(title: String, date: String, count: Int, details: String, daysBefore: Int): Boolean {
            val req = CalReq(title, date, count, details, daysBefore)
            runOnUiThread {
                if (hasCalendarPermission()) {
                    if (!insertWithReminder(req)) {
                        toast("Could not add directly. Opening your calendar app.")
                        openCalendarInsert(req)
                    }
                } else {
                    pendingReq = req
                    calendarPermission.launch(
                        arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)
                    )
                }
            }
            return true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Serves app/src/main/assets over https://appassets.androidplatform.net/assets/
        // so localStorage persists and no INTERNET permission is needed.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = true
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView, request: WebResourceRequest
                ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView,
                    callback: ValueCallback<Array<Uri>>,
                    params: FileChooserParams
                ): Boolean {
                    chooserCallback?.onReceiveValue(null)
                    chooserCallback = callback
                    return try {
                        picker.launch(params.createIntent())
                        true
                    } catch (e: Exception) {
                        chooserCallback = null
                        false
                    }
                }
            }
        }
        setContentView(web)
        if (savedInstanceState == null) {
            web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        } else {
            web.restoreState(savedInstanceState)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
