#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ApkOrientationTool - تعديل اتجاه اللعبة (أفقي / عمودي)
مستوحى من فكرة ApkForge
يضيف خيار landscape أو portrait لأي APK
"""

import os
import sys
import subprocess
import shutil
import re
from pathlib import Path


def run_cmd(cmd, cwd=None):
    print(f"→ {cmd}")
    result = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    if result.returncode != 0:
        print("خطأ:", result.stderr)
        sys.exit(1)
    return result.stdout


def change_orientation(manifest_path: Path, orientation: str):
    """يعدل android:screenOrientation في AndroidManifest.xml"""
    content = manifest_path.read_text(encoding="utf-8")

    # إزالة أي screenOrientation موجودة مسبقاً
    content = re.sub(
        r'\s*android:screenOrientation\s*=\s*"[^"]*"',
        "",
        content
    )

    # إضافة الاتجاه الجديد على أول <activity (عادةً الـ Main Activity)
    replacement = f' android:screenOrientation="{orientation}"'
    content = re.sub(
        r'(<activity\b[^>]*)(>)',
        rf'\1{replacement}\2',
        content,
        count=1
    )

    manifest_path.write_text(content, encoding="utf-8")
    print(f"✓ تم تعيين الاتجاه إلى: {orientation}")


def main():
    print("=" * 55)
    print("   Apk Orientation Tool (مستوحى من ApkForge)")
    print("   خيار أفقي / عمودي للألعاب")
    print("=" * 55)

    if len(sys.argv) < 2:
        print("\nالاستخدام:")
        print("  python apk_orientation.py <مسار_اللعبة.apk> [landscape|portrait]")
        print()
        print("أمثلة:")
        print("  python apk_orientation.py game.apk landscape   # أفقي")
        print("  python apk_orientation.py game.apk portrait    # عمودي")
        print("  python apk_orientation.py game.apk             # يسألك تختار")
        sys.exit(1)

    apk_path = Path(sys.argv[1]).resolve()
    if not apk_path.exists():
        print(f"❌ الملف غير موجود: {apk_path}")
        sys.exit(1)

    # اختيار الاتجاه
    if len(sys.argv) >= 3:
        orientation = sys.argv[2].lower().strip()
    else:
        print("\nاختر الاتجاه:")
        print("  1) landscape  ← أفقي")
        print("  2) portrait   ← عمودي")
        choice = input("اختيارك (1 أو 2): ").strip()
        orientation = "landscape" if choice == "1" else "portrait"

    valid = ("landscape", "portrait", "sensor", "fullSensor",
             "reverseLandscape", "reversePortrait", "unspecified")
    if orientation not in valid:
        print(f"❌ الاتجاه غير مدعوم. استخدم واحد من: {', '.join(valid)}")
        sys.exit(1)

    work_dir = Path("apk_work")
    if work_dir.exists():
        shutil.rmtree(work_dir)
    work_dir.mkdir()

    decompiled = work_dir / "decompiled"
    output_apk = work_dir / f"{apk_path.stem}_{orientation}.apk"
    signed_apk = work_dir / f"{apk_path.stem}_{orientation}_signed.apk"

    # 1. فك الـ APK
    print("\n[1/4] فك الـ APK...")
    run_cmd(f'apktool d "{apk_path}" -o "{decompiled}" -f')

    # 2. تعديل الاتجاه
    print("\n[2/4] تعديل الاتجاه...")
    manifest = decompiled / "AndroidManifest.xml"
    if not manifest.exists():
        print("❌ لم يتم العثور على AndroidManifest.xml")
        sys.exit(1)
    change_orientation(manifest, orientation)

    # 3. بناء الـ APK
    print("\n[3/4] بناء الـ APK...")
    run_cmd(f'apktool b "{decompiled}" -o "{output_apk}"')

    # 4. نسخ الملف النهائي (غير موقّع)
    print("\n[4/4] تجهيز الملف النهائي...")
    shutil.copy(output_apk, signed_apk)
    print(f"✓ تم إنشاء: {signed_apk}")

    print("\n" + "=" * 55)
    print("انتهى بنجاح!")
    print(f"الملف: {signed_apk}")
    print("ملاحظة: الملف غير موقّع.")
    print("وقّعه بـ: apksigner أو uber-apk-signer قبل التثبيت.")
    print("=" * 55)


if __name__ == "__main__":
    main()
