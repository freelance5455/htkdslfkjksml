export default {

    async fetch(request, env) {

        const url = new URL(request.url);
        const method = request.method;

        const corsHeaders = {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, Authorization",
            "Access-Control-Max-Age": "86400"
        };

        if (method === "OPTIONS") {
            return new Response(null, {
                status: 204,
                headers: corsHeaders
            });
        }

        function respuestaJSON(data, status = 200) {
            return new Response(JSON.stringify(data), {
                status,
                headers: {
                    "Content-Type": "application/json; charset=UTF-8",
                    ...corsHeaders
                }
            });
        }

        async function hashToken(token) {
            const data = new TextEncoder().encode(token);
            const hash = await crypto.subtle.digest("SHA-256", data);

            return Array.from(new Uint8Array(hash))
                .map(byte => byte.toString(16).padStart(2, "0"))
                .join("");
        }

        async function obtenerSesionValida(request) {

            const auth = request.headers.get("Authorization");

            if (!auth || !auth.startsWith("Bearer ")) {
                return null;
            }

            const token = auth.substring(7).trim();

            if (!token) {
                return null;
            }

            const tokenHash = await hashToken(token);
            const ahora = new Date().toISOString();

            return await env.DB.prepare(`
                SELECT
                    s.id AS sesion_id,
                    s.usuario_id,
                    s.fecha_expiracion,
                    u.nombre_usuario,
                    u.nombre,
                    u.rol,
                    u.estado
                FROM sesiones s
                INNER JOIN usuarios u
                    ON u.id = s.usuario_id
                WHERE s.token_hash = ?
                    AND s.fecha_expiracion > ?
                    AND u.estado = 'ACTIVO'
                LIMIT 1
            `)
            .bind(tokenHash, ahora)
            .first();
        }

        async function exigirAdministrador(request) {

            const sesion = await obtenerSesionValida(request);

            if (!sesion) {
                return {
                    ok: false,
                    respuesta: respuestaJSON({
                        ok: false,
                        error: "Sesión no válida o expirada."
                    }, 401)
                };
            }

            if (sesion.rol !== "ADMINISTRADOR") {
                return {
                    ok: false,
                    respuesta: respuestaJSON({
                        ok: false,
                        error: "Esta función requiere una cuenta ADMINISTRADOR."
                    }, 403)
                };
            }

            return {
                ok: true,
                sesion
            };
        }

        async function subirImagenImageKit(archivo) {

            if (!(archivo instanceof File)) {
                throw new Error("Archivo inválido.");
            }

            const MAX = 5 * 1024 * 1024;

            if (archivo.size > MAX) {
                throw new Error("La imagen supera los 5MB.");
            }

            const permitidos = [
                "image/jpeg",
                "image/png",
                "image/webp"
            ];

            if (!permitidos.includes(archivo.type)) {
                throw new Error("Formato no permitido. Usa JPG, PNG o WebP.");
            }

            const privateKey = env.IMAGEKIT_PRIVATE_KEY;

            if (!privateKey) {
                throw new Error("Falta IMAGEKIT_PRIVATE_KEY en el Worker.");
            }

            const form = new FormData();

            form.append("file", archivo);

            form.append(
                "fileName",
                archivo.name || `banner-${Date.now()}`
            );

            form.append(
                "folder",
                "/que-bola-shop/banners"
            );

            form.append(
                "useUniqueFileName",
                "true"
            );

            const auth = btoa(privateKey + ":");

            const respuesta = await fetch(
                "https://upload.imagekit.io/api/v1/files/upload",
                {
                    method: "POST",
                    headers: {
                        "Authorization": `Basic ${auth}`
                    },
                    body: form
                }
            );

            let datos = null;

            try {
                datos = await respuesta.json();
            } catch {
                datos = null;
            }

            if (!respuesta.ok) {
                throw new Error(
                    datos?.message ||
                    "No se pudo subir el banner a ImageKit."
                );
            }

            return {
                fileId: datos.fileId,
                url: datos.url
            };
        }

        async function eliminarImagenImageKit(fileId) {

            if (!fileId) {
                return true;
            }

            const privateKey = env.IMAGEKIT_PRIVATE_KEY;

            if (!privateKey) {
                throw new Error("Falta IMAGEKIT_PRIVATE_KEY en el Worker.");
            }

            const auth = btoa(privateKey + ":");

            const respuesta = await fetch(
                `https://api.imagekit.io/v1/files/${encodeURIComponent(fileId)}`,
                {
                    method: "DELETE",
                    headers: {
                        "Authorization": `Basic ${auth}`
                    }
                }
            );

            if (respuesta.status === 404) {
                return true;
            }

            if (!respuesta.ok) {
                throw new Error(
                    "No se pudo eliminar la imagen de ImageKit."
                );
            }

            return true;
        }

        try {

            /*
             * =================================================
             * ESTADO DEL WORKER
             * =================================================
             */

            if (method === "GET" && url.pathname === "/") {

                return respuestaJSON({
                    ok: true,
                    worker: "que-bola-shop-banner",
                    estado: "activo"
                });

            }

            /*
             * =================================================
             * BANNERS PÚBLICOS
             * =================================================
             */

            if (method === "GET" && url.pathname === "/banners") {

                const resultado = await env.DB.prepare(`
                    SELECT
                        id,
                        url,
                        nombre,
                        orden,
                        estado,
                        fecha_creacion
                    FROM banners
                    WHERE estado = 'ACTIVO'
                    ORDER BY orden ASC, id ASC
                `).all();

                return respuestaJSON({
                    ok: true,
                    banners: resultado.results || []
                });

            }

            /*
             * =================================================
             * LISTADO ADMINISTRATIVO
             * =================================================
             */

            if (method === "GET" && url.pathname === "/admin/banners") {

                const acceso = await exigirAdministrador(request);

                if (!acceso.ok) {
                    return acceso.respuesta;
                }

                const resultado = await env.DB.prepare(`
                    SELECT
                        id,
                        url,
                        file_id,
                        nombre,
                        orden,
                        estado,
                        fecha_creacion
                    FROM banners
                    ORDER BY orden ASC, id ASC
                `).all();

                return respuestaJSON({
                    ok: true,
                    banners: resultado.results || []
                });

            }

            /*
             * =================================================
             * SUBIR BANNER
             * =================================================
             */

            if (method === "POST" && url.pathname === "/admin/banners") {

                const acceso = await exigirAdministrador(request);

                if (!acceso.ok) {
                    return acceso.respuesta;
                }

                const form = await request.formData();

                const archivo =
                    form.get("banner") ||
                    form.get("foto") ||
                    form.get("imagen");

                if (!(archivo instanceof File)) {
                    return respuestaJSON({
                        ok: false,
                        error: "Debes seleccionar una imagen."
                    }, 400);
                }

                const nombre =
                    String(
                        form.get("nombre") ||
                        archivo.name ||
                        "Banner"
                    )
                    .trim()
                    .slice(0, 150);

                let nuevaImagen = null;

                try {

                    nuevaImagen =
                        await subirImagenImageKit(archivo);

                    const maxOrden = await env.DB.prepare(`
                        SELECT COALESCE(MAX(orden), 0) AS max_orden
                        FROM banners
                    `).first();

                    const orden =
                        Number(maxOrden?.max_orden || 0) + 1;

                    const resultado = await env.DB.prepare(`
                        INSERT INTO banners
                        (
                            url,
                            file_id,
                            nombre,
                            orden,
                            estado
                        )
                        VALUES (?, ?, ?, ?, 'ACTIVO')
                    `)
                    .bind(
                        nuevaImagen.url,
                        nuevaImagen.fileId,
                        nombre,
                        orden
                    )
                    .run();

                    const banner =
                        await env.DB.prepare(`
                            SELECT
                                id,
                                url,
                                file_id,
                                nombre,
                                orden,
                                estado,
                                fecha_creacion
                            FROM banners
                            WHERE id = ?
                            LIMIT 1
                        `)
                        .bind(resultado.meta.last_row_id)
                        .first();

                    return respuestaJSON({
                        ok: true,
                        mensaje: "Banner subido correctamente.",
                        banner
                    }, 201);

                } catch (error) {

                    /*
                     * Si ImageKit ya creó la imagen pero después
                     * falló D1, intentamos limpiar el archivo.
                     */

                    if (nuevaImagen?.fileId) {
                        try {
                            await eliminarImagenImageKit(
                                nuevaImagen.fileId
                            );
                        } catch {}
                    }

                    throw error;
                }
            }

            /*
             * =================================================
             * ELIMINAR BANNER
             * =================================================
             */

            const rutaEliminar =
                url.pathname.match(
                    /^\/admin\/banners\/(\d+)$/
                );

            if (
                method === "DELETE" &&
                rutaEliminar
            ) {

                const acceso =
                    await exigirAdministrador(request);

                if (!acceso.ok) {
                    return acceso.respuesta;
                }

                const id =
                    Number(rutaEliminar[1]);

                if (!Number.isInteger(id) || id <= 0) {
                    return respuestaJSON({
                        ok: false,
                        error: "ID de banner inválido."
                    }, 400);
                }

                const banner =
                    await env.DB.prepare(`
                        SELECT
                            id,
                            url,
                            file_id,
                            nombre
                        FROM banners
                        WHERE id = ?
                        LIMIT 1
                    `)
                    .bind(id)
                    .first();

                if (!banner) {
                    return respuestaJSON({
                        ok: false,
                        error: "Banner no encontrado."
                    }, 404);
                }

                await env.DB.prepare(`
                    DELETE FROM banners
                    WHERE id = ?
                `)
                .bind(id)
                .run();

                let advertencia = null;

                if (banner.file_id) {
                    try {
                        await eliminarImagenImageKit(
                            banner.file_id
                        );
                    } catch (error) {
                        advertencia =
                            "El banner fue eliminado de la base de datos, pero no se pudo eliminar la imagen de ImageKit.";
                    }
                }

                return respuestaJSON({
                    ok: true,
                    mensaje:
                        advertencia ||
                        "Banner eliminado correctamente.",
                    advertencia
                });

            }

            return respuestaJSON({
                ok: false,
                error: "Ruta no encontrada."
            }, 404);

        } catch (error) {

            console.error(
                "Error en que-bola-shop-banner:",
                error
            );

            return respuestaJSON({
                ok: false,
                error: error?.message ||
                    "Error interno del servidor."
            }, 500);
        }
    }
};
