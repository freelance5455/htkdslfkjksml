Café Kasse Android-Projekt
Dieses Projekt verpackt die Café-Kasse als Android-WebView-App.
Der APK-Forge-Fehler "API rate limit exceeded" wird nicht durch HTML-Code verursacht, sondern durch das GitHub-Abfragelimit im Builder.
Zum Erstellen einer APK: Projekt in Android Studio öffnen, Gradle synchronisieren und Build > Build APK(s) wählen. Das erfordert Android Studio auf einem Computer und Internetzugang.
