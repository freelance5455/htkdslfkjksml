'use strict';
/**
 * Vidora — منصة فيديو مفتوحة على طراز يوتيوب
 * الخادم الرئيسي: Express + SQLite + بث Range + SSE لمتابعة المهام
 */
const path = require('path');
const fs = require('fs');
const express = require('express');

// محمّل .env بسيط (بدون تبعيات خارجية)
(function loadEnv() {
  const envPath = path.join(__dirname, '.env');
  if (!fs.existsSync(envPath)) return;
  for (const line of fs.readFileSync(envPath, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)?\s*$/i);
    if (!m) continue;
    const key = m[1];
    let value = (m[2] || '').trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (process.env[key] === undefined) process.env[key] = value;
  }
})();

const { getSetting, stats } = require('./src/db');
const auth = require('./src/auth');
const media = require('./src/media');
const ytdlp = require('./src/ytdlp');
const pipeline = require('./src/pipeline');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';

app.set('trust proxy', true);
app.disable('x-powered-by');
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));

// رؤوس أمان أساسية
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  next();
});

/* ------------------------------ الواجهة ------------------------------ */
const PUBLIC_DIR = path.join(__dirname, 'public');
app.use(express.static(PUBLIC_DIR, {
  index: 'index.html',
  maxAge: process.env.NODE_ENV === 'production' ? '1h' : 0,
  setHeaders(res, filePath) {
    if (/\.(css|js|svg|png|jpg|webp)$/.test(filePath)) {
      res.setHeader('Cache-Control', 'public, max-age=3600');
    }
  },
}));

/* -------------------------------- API -------------------------------- */
app.get('/api/config', (req, res) => {
  res.json({
    siteName: getSetting('siteName', process.env.SITE_NAME || 'Vidora'),
    siteTagline: getSetting('siteTagline', process.env.SITE_TAGLINE || 'منصة الفيديو المفتوحة'),
    announcement: getSetting('announcement', ''),
    capabilities: {
      ytdlp: ytdlp.ytdlpAvailable(),
      ffmpeg: media.hasFfmpeg(),
      cookies: Boolean(ytdlp.cookiesPath()),
      proxy: Boolean(process.env.DOWNLOAD_PROXY),
      subtitles: process.env.ENABLE_SUBTITLES !== '0',
    },
    maxUploadMb: Number(process.env.MAX_UPLOAD_MB || 2048),
    pageSize: Number(process.env.PAGE_SIZE || 24),
    stats: (() => { try { return stats(); } catch { return null; } })(),
  });
});

app.get('/api/health', (req, res) => {
  res.json({ ok: true, uptime: Math.round(process.uptime()), ts: Date.now() });
});

app.use('/api/auth', require('./src/routes/auth'));
app.use('/api', require('./src/routes/videos'));
app.use('/api', require('./src/routes/channels'));
app.use('/api/admin', require('./src/routes/admin'));
app.use('/media', require('./src/routes/media'));

/* ------------- بث الأحداث (SSE) لمتابعة مهام الاستيراد ------------- */
app.get('/api/events', (req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.write(`retry: 3000\n\n`);
  const send = (event) => {
    try { res.write(`data: ${JSON.stringify(event)}\n\n`); } catch { /* ignore */ }
  };
  const unsubscribe = pipeline.onJobEvent(send);
  const ping = setInterval(() => { try { res.write(': ping\n\n'); } catch { /* ignore */ } }, 20000);
  req.on('close', () => { clearInterval(ping); unsubscribe(); });
});

/* ------------------------------ الأخطاء ------------------------------ */
app.use('/api', (req, res) => {
  res.status(404).json({ error: 'المسار غير موجود' });
});

app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  const status = err.status || 500;
  if (status >= 500) console.error('[vidora]', err);
  res.status(status).json({ error: err.message || 'خطأ داخلي في الخادم' });
});

/* ------------------------------ التشغيل ------------------------------ */
function bootstrapAdmin() {
  const email = (process.env.ADMIN_EMAIL || 'admin@vidora.local').toLowerCase();
  const password = process.env.ADMIN_PASSWORD || 'Admin@12345';
  const exists = require('./src/db').db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (!exists) {
    const user = auth.createUser({ email, password, name: 'مدير Vidora', role: 'admin' });
    console.log(`\n  ✔ تم إنشاء حساب المدير: ${email} / ${password}\n`);
  }
}

const interrupted = pipeline.resumeInterruptedJobs();
if (interrupted) console.log(`  ℹ أُعيد ضبط ${interrupted} مهمة متوقفة.`);

bootstrapAdmin();

const server = app.listen(PORT, HOST, () => {
  const banner = `
  ┌────────────────────────────────────────────┐
  │   Vidora — منصة الفيديو المفتوحة            │
  │   يعمل الآن على  http://localhost:${String(PORT).padEnd(5)}          │
  │   yt-dlp: ${ytdlp.ytdlpAvailable() ? '✔ متاح' : '✖ غير مثبّت'}   ffmpeg: ${media.hasFfmpeg() ? '✔ متاح' : '✖ غير مثبّت'}   كوكيز: ${ytdlp.cookiesPath() ? '✔' : '—'}   │
  └────────────────────────────────────────────┘`;
  console.log(banner);
});

process.on('SIGTERM', () => server.close(() => process.exit(0)));
process.on('SIGINT', () => server.close(() => process.exit(0)));

module.exports = app;
