/* التطبيق الرئيسي: التوجيه وهيكل الواجهة */
import { API } from './api.js';
import { el, icon, toast, debounce } from './utils.js';
import { loadConfig, loadSession, loadCategories, loadSubscriptions, store, isLoggedIn } from './store.js';
import { renderSidebar, renderAccountMenu } from './ui.js';

import { renderHome, renderExplore } from './pages/home.js';
import { renderWatch } from './pages/watch.js';
import { renderChannel } from './pages/channel.js';
import { renderSearch } from './pages/search.js';
import { renderUpload } from './pages/upload.js';
import { renderImport } from './pages/import.js';
import { renderLibrary, renderPlaylist } from './pages/library.js';
import { renderAuth } from './pages/auth.js';
import { renderAdmin } from './pages/admin.js';
import { renderSettings } from './pages/settings.js';

const content = document.getElementById('content');

/* ------------------------------ التوجيه ------------------------------ */
const routes = [
  { pattern: /^\/?$/, handler: renderHome },
  { pattern: /^\/explore$/, handler: renderExplore },
  { pattern: /^\/watch\/(\d+)$/, handler: renderWatch, keys: ['id'] },
  { pattern: /^\/channel\/(\w+)$/, handler: renderChannel, keys: ['id'] },
  { pattern: /^\/search$/, handler: renderSearch },
  { pattern: /^\/upload$/, handler: renderUpload },
  { pattern: /^\/import$/, handler: renderImport },
  { pattern: /^\/(history|watchlater|liked|playlists)$/, handler: renderLibrary, keys: ['kind'] },
  { pattern: /^\/playlist\/(\d+)$/, handler: renderPlaylist, keys: ['id'] },
  { pattern: /^\/(login|register)$/, handler: renderAuth, keys: ['mode'] },
  { pattern: /^\/settings$/, handler: renderSettings },
  { pattern: /^\/admin$/, handler: renderAdmin },
];

async function router() {
  const raw = location.hash.replace(/^#/, '') || '/';
  const [pathPart, queryPart] = raw.split('?');
  const query = Object.fromEntries(new URLSearchParams(queryPart || ''));
  const path = pathPart.startsWith('/') ? pathPart : `/${pathPart}`;

  renderSidebar();
  renderAccountMenu();
  closeMenus();

  for (const route of routes) {
    const m = path.match(route.pattern);
    if (!m) continue;
    const params = { ...query };
    (route.keys || []).forEach((k, i) => { params[k] = m[i + 1]; });
    window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
    try {
      await route.handler(content, params);
    } catch (err) {
      console.error(err);
      content.innerHTML = '';
      content.append(el('div', { class: 'empty' },
        el('h3', { text: 'حدث خطأ في هذه الصفحة' }),
        el('p', { text: err.message || 'خطأ غير متوقع' })
      ));
    }
    return;
  }

  content.innerHTML = '';
  content.append(el('div', { class: 'empty' },
    icon('compass'),
    el('h3', { text: 'الصفحة غير موجودة' }),
    el('p', { text: 'الرابط الذي طلبته غير متاح.' }),
    el('a', { class: 'btn primary', href: '#/', text: 'العودة للرئيسية' })
  ));
}

/* ------------------------------- القوائم ------------------------------- */
function closeMenus() {
  document.getElementById('accountMenu').hidden = true;
  document.getElementById('suggestBox').hidden = true;
}

document.getElementById('avatarBtn').addEventListener('click', (e) => {
  e.stopPropagation();
  const menu = document.getElementById('accountMenu');
  menu.hidden = !menu.hidden;
});
document.addEventListener('click', (e) => {
  if (!e.target.closest('.avatar-wrap')) document.getElementById('accountMenu').hidden = true;
  if (!e.target.closest('.search')) document.getElementById('suggestBox').hidden = true;
});

document.getElementById('menuBtn').addEventListener('click', () => {
  if (window.innerWidth <= 900) {
    document.body.classList.toggle('side-open');
    document.getElementById('scrim').hidden = !document.body.classList.contains('side-open');
  } else {
    document.body.classList.toggle('side-collapsed');
    localStorage.setItem('vidora_side', document.body.classList.contains('side-collapsed') ? '1' : '');
  }
});
document.getElementById('scrim').addEventListener('click', () => {
  document.body.classList.remove('side-open');
  document.getElementById('scrim').hidden = true;
});

/* -------------------------------- البحث -------------------------------- */
const searchInput = document.getElementById('searchInput');
const suggestBox = document.getElementById('suggestBox');

document.getElementById('searchForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const q = searchInput.value.trim();
  suggestBox.hidden = true;
  location.hash = q ? `#/search?q=${encodeURIComponent(q)}` : '#/search';
});

const fetchSuggest = debounce(async (q) => {
  if (!q) { suggestBox.hidden = true; return; }
  try {
    const { items } = await API.suggest(q);
    if (!items.length) { suggestBox.hidden = true; return; }
    suggestBox.innerHTML = '';
    for (const s of items) {
      suggestBox.append(el('button', {
        type: 'button',
        onclick: () => {
          searchInput.value = s;
          suggestBox.hidden = true;
          location.hash = `#/search?q=${encodeURIComponent(s)}`;
        },
      }, icon('search'), el('span', { text: s })));
    }
    suggestBox.hidden = false;
  } catch { suggestBox.hidden = true; }
}, 220);

searchInput.addEventListener('input', (e) => fetchSuggest(e.target.value.trim()));
searchInput.addEventListener('focus', (e) => { if (e.target.value.trim()) fetchSuggest(e.target.value.trim()); });

/* ------------------------------ الإشعارات ------------------------------ */
document.getElementById('bellBtn').addEventListener('click', async () => {
  if (!isLoggedIn()) { toast('سجّل الدخول لعرض الإشعارات', 'err'); return; }
  try {
    const { items, unread } = await API.notifications();
    const badge = document.getElementById('bellBadge');
    badge.hidden = !unread;
    badge.textContent = unread;
    const body = el('div');
    if (!items.length) body.append(el('p', { class: 'muted', text: 'لا توجد إشعارات.' }));
    for (const n of items.slice(0, 12)) {
      const p = n.payload || {};
      body.append(el('a', {
        class: 'job', href: p.videoId ? `#/watch/${p.videoId}` : '#/',
        style: { display: 'block' },
      },
        el('div', { class: 'job-title', text: p.title || 'إشعار' }),
        el('div', { class: 'job-msg', text: 'فيديو جديد من قناة تشترك بها' })
      ));
    }
    const { modal } = await import('./utils.js');
    modal({ title: 'الإشعارات', body, wide: false, onMount: () => API.readNotifications().then(() => { badge.hidden = true; }) });
  } catch (err) { toast(err.message, 'err'); }
});

/* ------------------------------ التمرير ------------------------------ */
window.addEventListener('scroll', () => {
  document.querySelector('.topbar').classList.toggle('scrolled', window.scrollY > 8);
});

/* --------------------------- أحداث الجلسة --------------------------- */
window.addEventListener('vidora:session-changed', () => {
  loadSession().then(() => { renderSidebar(); renderAccountMenu(); router(); });
});
window.addEventListener('vidora:session-expired', () => {
  toast('انتهت الجلسة، يرجى تسجيل الدخول من جديد', 'err');
  renderSidebar(); renderAccountMenu();
});

/* ------------------------------- الإقلاع ------------------------------- */
(async function init() {
  if (localStorage.getItem('vidora_side') === '1') document.body.classList.add('side-collapsed');
  await loadConfig();
  await loadSession();
  await loadCategories();
  await loadSubscriptions();
  window.addEventListener('hashchange', router);
  await router();
  if (!isLoggedIn()) {
    const cfg = store.config || {};
    if (cfg.capabilities && !cfg.capabilities.ytdlp) {
      console.warn('[vidora] yt-dlp غير مثبّت — شغّل install.sh لتفعيل الاستيراد من الإنترنت');
    }
  }
})();
