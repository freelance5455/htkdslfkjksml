/* مكوّنات الواجهة المشتركة */
import { el, icon, fmtViews, timeAgo, thumb, avatarEl } from './utils.js';
import { store, isLoggedIn, isAdmin } from './store.js';

/* ---------------------------- بطاقة فيديو ---------------------------- */
export function videoCard(video, { showChannel = true } = {}) {
  const card = el('div', { class: 'card', onclick: () => { location.hash = `#/watch/${video.id}`; } });

  const t = thumb(video);
  card.append(t);

  const body = el('div', { class: 'card-body' });
  body.append(el('h3', { class: 'card-title', text: video.title || 'بدون عنوان' }));

  const meta = el('div', { class: 'card-meta' });
  if (showChannel) {
    meta.append(avatarEl(video.channel_name, '#3ea6ff', video.channel_avatar));
  }
  const sub = el('div', { class: 'card-sub' });
  if (showChannel) {
    sub.append(el('a', {
      class: 'card-chan',
      text: video.channel_name || 'قناة مجهولة',
      onclick: (e) => { e.stopPropagation(); location.hash = `#/channel/${video.channel_id}`; },
    }));
  }
  sub.append(el('div', { class: 'card-stats', text: `${fmtViews(video.views)} مشاهدة • ${timeAgo(video.published_at || video.created_at)}` }));
  meta.append(sub);
  body.append(meta);
  card.append(body);
  return card;
}

export function videoGrid(videos, opts = {}) {
  const grid = el('div', { class: 'grid' });
  if (!videos || !videos.length) {
    grid.append(emptyState({
      icon: 'play',
      title: 'لا توجد فيديوهات هنا بعد',
      text: 'جرّب استيراد فيديو من رابط أو رفع ملف من جهازك.',
      action: { label: 'استيراد من رابط', href: '#/import' },
    }));
    return grid;
  }
  for (const v of videos) grid.append(videoCard(v, opts));
  return grid;
}

export function emptyState({ icon: ic = 'play', title, text, action }) {
  const box = el('div', { class: 'empty', style: { gridColumn: '1/-1' } },
    icon(ic),
    el('h3', { text: title }),
    text ? el('p', { text }) : null,
    action ? el('a', { class: 'btn primary', href: action.href, text: action.label }) : null
  );
  return box;
}

export function skeletonGrid(count = 12) {
  const grid = el('div', { class: 'grid' });
  for (let i = 0; i < count; i += 1) {
    grid.append(el('div', { class: 'card sk-card' },
      el('div', { class: 'thumb skeleton' }),
      el('div', { class: 'sk-line skeleton' }),
      el('div', { class: 'sk-line skeleton', style: { width: '55%' } })
    ));
  }
  return grid;
}

/* ------------------------------ الشرائح ------------------------------ */
export function chipsBar(active, onSelect) {
  const bar = el('div', { class: 'chips' });
  const list = (store.categories.length ? store.categories : [{ name: 'الكل', count: 0 }]);
  for (const c of list) {
    const chip = el('button', {
      class: `chip${c.name === active ? ' active' : ''}`,
      text: c.name,
      onclick: () => onSelect(c.name),
    });
    bar.append(chip);
  }
  return bar;
}

/* --------------------------- الشريط الجانبي --------------------------- */
export function renderSidebar() {
  const nav = document.getElementById('sideNav');
  nav.innerHTML = '';

  const group = (title, links) => {
    const g = el('div', { class: 'side-group' });
    if (title) g.append(el('div', { class: 'side-head', text: title }));
    for (const l of links) g.append(l);
    nav.append(g);
  };

  const link = (href, ic, label, id) => el('a', {
    class: 'side-link', href, dataset: { route: id || href },
    onclick: () => document.body.classList.remove('side-open'),
  }, icon(ic), el('span', { text: label }));

  const hash = location.hash || '#/';

  group(null, [
    link('#/', 'home', 'الرئيسية', 'home'),
    link('#/explore', 'compass', 'استكشاف', 'explore'),
    link('#/import', 'link', 'استيراد من الإنترنت', 'import'),
    link('#/upload', 'upload', 'رفع فيديو', 'upload'),
  ]);

  group('أنت', [
    link('#/channel/mine', 'user', 'قناتك', 'channel-mine'),
    link('#/history', 'clock', 'السجل', 'history'),
    link('#/watchlater', 'bookmark', 'المشاهدة لاحقاً', 'watchlater'),
    link('#/liked', 'like', 'الفيديوهات المعجوبة', 'liked'),
    link('#/playlists', 'playlist', 'قوائم التشغيل', 'playlists'),
  ]);

  if (isAdmin()) {
    group('الإدارة', [link('#/admin', 'settings', 'لوحة التحكم', 'admin')]);
  }

  if (store.subscriptions.length) {
    const g = el('div', { class: 'side-group' });
    g.append(el('div', { class: 'side-head', text: 'الاشتراكات' }));
    for (const ch of store.subscriptions.slice(0, 12)) {
      g.append(el('a', { class: 'side-sub', href: `#/channel/${ch.id}` },
        avatarEl(ch.name, '#7c4dff', ch.avatar),
        el('span', { text: ch.name })
      ));
    }
    nav.append(g);
  }

  // تمييز الرابط الحالي
  for (const a of nav.querySelectorAll('.side-link')) {
    const route = a.dataset.route;
    const current = hash.startsWith('#/watch') ? 'home'
      : hash === '#/' ? 'home'
        : hash.replace('#/', '');
    if (route === current || (route === 'home' && hash === '#/')) a.classList.add('active');
  }
}

/* --------------------------- قائمة الحساب --------------------------- */
export function renderAccountMenu() {
  const menu = document.getElementById('accountMenu');
  menu.innerHTML = '';
  if (isLoggedIn()) {
    menu.append(el('div', { class: 'user-head' },
      avatarEl(store.user.name, store.user.color),
      el('div', {},
        el('div', { style: { fontWeight: '700' }, text: store.user.name }),
        el('div', { class: 'muted small', text: store.user.email })
      )
    ));
    menu.append(el('div', { class: 'sep' }));
    menu.append(el('a', { href: '#/channel/mine' }, icon('user'), 'قناتي'));
    menu.append(el('a', { href: '#/upload' }, icon('upload'), 'رفع فيديو'));
    menu.append(el('a', { href: '#/import' }, icon('link'), 'استيراد من رابط'));
    menu.append(el('a', { href: '#/settings' }, icon('settings'), 'الإعدادات'));
    menu.append(el('div', { class: 'sep' }));
    menu.append(el('button', { onclick: () => { localStorage.clear(); location.reload(); } }, icon('close'), 'تسجيل الخروج'));
  } else {
    menu.append(el('a', { href: '#/login' }, icon('user'), 'تسجيل الدخول'));
    menu.append(el('a', { href: '#/register' }, icon('plus'), 'إنشاء حساب'));
  }
}

/* ------------------------------ التنبيهات ------------------------------ */
export function announcementBar() {
  const text = store.config?.announcement;
  if (!text) return null;
  return el('div', {
    class: 'announcement',
    style: {
      margin: '16px 0 0', padding: '10px 16px', borderRadius: '12px',
      background: 'var(--accent-soft)', border: '1px solid rgba(255,0,51,.3)',
      fontSize: '14px', display: 'flex', gap: '10px', alignItems: 'center',
    },
  }, icon('bell'), el('span', { text }));
}
