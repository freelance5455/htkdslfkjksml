/* أدوات مساعدة عامة */

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

export function el(tag, props = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') node.className = v;
    else if (k === 'html') node.innerHTML = v;
    else if (k === 'text') node.textContent = v;
    else if (k === 'dataset') Object.assign(node.dataset, v);
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'style' && typeof v === 'object') Object.assign(node.style, v);
    else node.setAttribute(k, v);
  }
  for (const c of children.flat(4)) {
    if (c === null || c === undefined || c === false) continue;
    node.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return node;
}

/** أيقونة SVG من مكتبة الرموز */
export function icon(name, cls = 'ic') {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('class', cls);
  const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
  use.setAttribute('href', `#i-${name}`);
  svg.append(use);
  return svg;
}

export function escapeHtml(str = '') {
  return String(str).replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

/** 1234567 -> "1.2 مليون" */
export function fmtViews(n = 0) {
  const v = Number(n) || 0;
  if (v >= 1e9) return `${(v / 1e9).toFixed(v % 1e9 === 0 ? 0 : 1)} مليار`;
  if (v >= 1e6) return `${(v / 1e6).toFixed(v % 1e6 === 0 ? 0 : 1)} مليون`;
  if (v >= 1e3) return `${(v / 1e3).toFixed(v % 1e3 === 0 ? 0 : 1)} ألف`;
  return String(v);
}

/** 3725 -> "1:02:05" */
export function fmtDuration(sec = 0) {
  const s = Math.max(0, Math.round(Number(sec) || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = s % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(ss)}` : `${m}:${pad(ss)}`;
}

/** وقت نسبي بالعربية */
export function timeAgo(dateStr) {
  if (!dateStr) return '';
  const then = new Date(String(dateStr).includes('T') ? dateStr : `${String(dateStr).replace(' ', 'T')}Z`);
  const diff = (Date.now() - then.getTime()) / 1000;
  if (!Number.isFinite(diff)) return '';
  if (diff < 60) return 'قبل ثوانٍ';
  if (diff < 3600) return `قبل ${Math.floor(diff / 60)} دقيقة`;
  if (diff < 86400) return `قبل ${Math.floor(diff / 3600)} ساعة`;
  if (diff < 604800) return `قبل ${Math.floor(diff / 86400)} يوم`;
  if (diff < 2592000) return `قبل ${Math.floor(diff / 604800)} أسبوع`;
  if (diff < 31536000) return `قبل ${Math.floor(diff / 2592000)} شهر`;
  return `قبل ${Math.floor(diff / 31536000)} سنة`;
}

export function fmtDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(String(dateStr).replace(' ', 'T') + (String(dateStr).includes('Z') ? '' : 'Z'));
  try {
    return d.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' });
  } catch {
    return String(dateStr).slice(0, 10);
  }
}

export function fmtBytes(bytes = 0) {
  const b = Number(bytes) || 0;
  const units = ['بايت', 'ك.ب', 'م.ب', 'ج.ب'];
  let i = 0; let n = b;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i += 1; }
  return `${n.toFixed(n >= 10 || i === 0 ? 0 : 1)} ${units[i]}`;
}

export function debounce(fn, wait = 280) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), wait);
  };
}

/** تنبيه سريع */
export function toast(message, type = '') {
  const wrap = document.getElementById('toastWrap');
  if (!wrap) return;
  const node = el('div', { class: `toast ${type}` },
    icon(type === 'err' ? 'close' : type === 'ok' ? 'check' : 'bell'),
    el('span', { text: message })
  );
  wrap.append(node);
  setTimeout(() => {
    node.style.opacity = '0';
    node.style.transition = 'opacity .25s';
    setTimeout(() => node.remove(), 260);
  }, 3800);
}

/** نافذة منبثقة */
export function modal({ title, subtitle, body, actions = [], wide = false, onMount }) {
  const root = document.getElementById('modalRoot');
  root.hidden = false;
  root.innerHTML = '';
  const box = el('div', { class: `modal${wide ? ' wide' : ''}` });
  if (title) box.append(el('h2', { text: title }));
  if (subtitle) box.append(el('p', { class: 'sub', text: subtitle }));
  if (body) box.append(body);
  if (actions.length) {
    const bar = el('div', { class: 'modal-actions' });
    for (const a of actions) {
      bar.append(el('button', {
        class: `btn ${a.class || ''}`,
        onclick: () => { const r = a.onClick?.(box); if (r !== false) closeModal(); },
      }, a.label));
    }
    box.append(bar);
  }
  root.append(box);
  root.onclick = (e) => { if (e.target === root) closeModal(); };
  document.addEventListener('keydown', escHandler);
  onMount?.(box);
  return box;
}

export function closeModal() {
  const root = document.getElementById('modalRoot');
  root.hidden = true;
  root.innerHTML = '';
  document.removeEventListener('keydown', escHandler);
}

function escHandler(e) { if (e.key === 'Escape') closeModal(); }

/** نسخ إلى الحافظة */
export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    toast('تم نسخ الرابط', 'ok');
  } catch {
    const ta = el('textarea', { value: text, style: { position: 'fixed', opacity: '0' } });
    document.body.append(ta); ta.select();
    try { document.execCommand('copy'); toast('تم نسخ الرابط', 'ok'); } catch { toast('فشل النسخ', 'err'); }
    ta.remove();
  }
}

/** عنصر صورة مصغّرة مع بديل */
export function thumb(video, { eager = false } = {}) {
  const wrap = el('div', { class: 'thumb' });
  if (video.poster_url || video.thumb_url) {
    wrap.append(el('img', {
      src: video.poster_url || video.thumb_url,
      alt: video.title || 'صورة مصغّرة',
      loading: eager ? 'eager' : 'lazy',
      onerror: (e) => { e.target.remove(); wrap.append(el('div', { class: 'ph' }, icon('play'))); },
    }));
  } else {
    wrap.append(el('div', { class: 'ph' }, icon('play')));
  }
  if (video.duration) wrap.append(el('span', { class: 'dur', text: fmtDuration(video.duration) }));
  if (video.source_type === 'import') wrap.append(el('span', { class: 'badge-imp', text: 'مستورد' }));
  return wrap;
}

/** صورة رمزية ملوّنة */
export function avatarEl(name = '?', color = '#3ea6ff', imageUrl = null) {
  const node = el('div', { class: 'chan' }, (name || '?').trim().charAt(0).toUpperCase());
  node.style.background = color || '#3ea6ff';
  if (imageUrl) {
    const img = el('img', { src: imageUrl, alt: name, onerror: () => img.remove() });
    node.append(img);
  }
  return node;
}
