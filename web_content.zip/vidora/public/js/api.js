/* عميل الـ API — يتعامل مع الجلسة والرمز */

const BASE = (window.VIDORA_API_BASE || '').replace(/\/$/, '');
let token = localStorage.getItem('vidora_token') || null;

export function setToken(t) {
  token = t;
  if (t) localStorage.setItem('vidora_token', t);
  else localStorage.removeItem('vidora_token');
}
export function getToken() { return token; }
export function hasToken() { return Boolean(token); }

async function request(method, path, body, opts = {}) {
  const headers = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  let payload;
  if (body instanceof FormData) {
    payload = body;
  } else if (body !== undefined) {
    headers['Content-Type'] = 'application/json';
    payload = JSON.stringify(body);
  }

  let res;
  try {
    res = await fetch(`${BASE}${path}`, { method, headers, body: payload });
  } catch (err) {
    throw new Error('تعذّر الاتصال بالخادم. تأكد أن الخادم يعمل.');
  }

  const isJson = (res.headers.get('content-type') || '').includes('application/json');
  const data = isJson ? await res.json().catch(() => ({})) : await res.text();

  if (!res.ok) {
    if (res.status === 401 && token && !opts.silent) {
      setToken(null);
      window.dispatchEvent(new CustomEvent('vidora:session-expired'));
    }
    throw new Error((isJson && data && data.error) || `فشل الطلب (${res.status})`);
  }
  return data;
}

export const api = {
  get: (p, o) => request('GET', p, undefined, o),
  post: (p, b, o) => request('POST', p, b, o),
  patch: (p, b, o) => request('PATCH', p, b, o),
  put: (p, b, o) => request('PUT', p, b, o),
  del: (p, o) => request('DELETE', p, undefined, o),
};

/* --------------------------- نقاط النهاية --------------------------- */
export const API = {
  config: () => api.get('/api/config'),
  health: () => api.get('/api/health'),

  login: (email, password) => api.post('/api/auth/login', { email, password }),
  register: (email, password, name) => api.post('/api/auth/register', { email, password, name }),
  me: () => api.get('/api/auth/me'),
  updateMe: (data) => api.patch('/api/auth/me', data),
  changePassword: (current, next) => api.post('/api/auth/me/password', { current, next }),

  videos: (params = {}) => api.get(`/api/videos?${new URLSearchParams(params)}`),
  video: (id) => api.get(`/api/videos/${id}`),
  similar: (id) => api.get(`/api/videos/${id}/similar`),
  updateVideo: (id, data) => api.patch(`/api/videos/${id}`, data),
  deleteVideo: (id) => api.del(`/api/videos/${id}`),
  view: (id) => api.post(`/api/videos/${id}/view`),
  react: (id, value) => api.post(`/api/videos/${id}/reaction`, { value }),
  toggleWatchLater: (id) => api.post(`/api/videos/${id}/watch-later`),
  progress: (id, p) => api.post(`/api/videos/${id}/progress`, { progress: p }),
  comments: (id) => api.get(`/api/videos/${id}/comments`),
  addComment: (id, text) => api.post(`/api/videos/${id}/comments`, { text }),
  deleteComment: (id) => api.del(`/api/comments/${id}`),

  upload: (formData) => api.post('/api/videos/upload', formData),
  importVideo: (payload) => api.post('/api/videos/import', payload),
  jobs: () => api.get('/api/jobs'),
  job: (id) => api.get(`/api/jobs/${id}`),

  categories: () => api.get('/api/categories'),
  suggest: (q) => api.get(`/api/search/suggest?q=${encodeURIComponent(q)}`),

  channel: (id) => api.get(`/api/channels/${id}`),
  updateChannel: (id, data) => api.patch(`/api/channels/${id}`, data),
  subscribe: (id) => api.post(`/api/channels/${id}/subscribe`),
  subscriptions: () => api.get('/api/subscriptions'),

  history: () => api.get('/api/library/history'),
  watchLater: () => api.get('/api/library/watch-later'),
  liked: () => api.get('/api/library/liked'),

  playlists: () => api.get('/api/playlists'),
  createPlaylist: (name, description) => api.post('/api/playlists', { name, description }),
  playlist: (id) => api.get(`/api/playlists/${id}`),
  addToPlaylist: (id, videoId) => api.post(`/api/playlists/${id}/items`, { videoId }),
  removeFromPlaylist: (id, videoId) => api.del(`/api/playlists/${id}/items/${videoId}`),
  deletePlaylist: (id) => api.del(`/api/playlists/${id}`),

  notifications: () => api.get('/api/notifications'),
  readNotifications: () => api.post('/api/notifications/read'),

  adminStats: () => api.get('/api/admin/stats'),
  adminUsers: () => api.get('/api/admin/users'),
  adminUser: (id, role) => api.patch(`/api/admin/users/${id}`, { role }),
  adminDeleteUser: (id) => api.del(`/api/admin/users/${id}`),
  adminVideos: () => api.get('/api/admin/videos'),
  adminDeleteVideo: (id) => api.del(`/api/admin/videos/${id}`),
  adminFeature: (id, featured) => api.post(`/api/admin/videos/${id}/feature`, { featured }),
  adminJobs: () => api.get('/api/admin/jobs'),
  adminSettings: () => api.get('/api/admin/settings'),
  saveSettings: (data) => api.put('/api/admin/settings', data),
};

/** بث الأحداث (SSE) لمتابعة المهام */
export function connectEvents(onMessage) {
  let es;
  try {
    es = new EventSource(`${BASE}/api/events`);
    es.onmessage = (e) => {
      try { onMessage(JSON.parse(e.data)); } catch { /* ignore */ }
    };
    es.onerror = () => { /* يعيد الاتصال تلقائياً */ };
  } catch { /* ignore */ }
  return es;
}
