/* تسجيل الدخول / إنشاء حساب */
import { API, setToken } from '../api.js';
import { el, icon, toast } from '../utils.js';
import { loadSession, loadSubscriptions } from '../store.js';

export async function renderAuth(container, params) {
  const mode = params.mode === 'register' ? 'register' : 'login';
  container.innerHTML = '';

  const tabs = el('div', { class: 'tabs-auth' });
  const loginTab = el('button', { class: mode === 'login' ? 'active' : '', text: 'تسجيل الدخول', onclick: () => { location.hash = '#/login'; } });
  const regTab = el('button', { class: mode === 'register' ? 'active' : '', text: 'إنشاء حساب', onclick: () => { location.hash = '#/register'; } });
  tabs.append(loginTab, regTab);

  const box = el('div', { class: 'panel', style: { maxWidth: '460px', margin: '40px auto' } });
  box.append(tabs);
  box.append(el('h1', { text: mode === 'login' ? 'تسجيل الدخول' : 'إنشاء حساب جديد', style: { fontSize: '22px', margin: '8px 0 4px' } }));
  box.append(el('p', { class: 'muted small', style: { margin: '0 0 20px' }, text: mode === 'login' ? 'أدخل بياناتك للمتابعة.' : 'أنشئ حساباً لتتمكن من الرفع والاستيراد والاشتراك.' }));

  const email = el('input', { class: 'input', type: 'email', placeholder: 'البريد الإلكتروني', dir: 'ltr' });
  const pass = el('input', { class: 'input', type: 'password', placeholder: 'كلمة المرور', dir: 'ltr' });
  const name = el('input', { class: 'input', placeholder: 'الاسم (مطلوب للإنشاء)' });
  const err = el('p', { class: 'hint', style: { color: '#ff6b8a', minHeight: '18px' } });
  const submit = el('button', { class: 'btn primary', style: { width: '100%', justifyContent: 'center', height: '44px' }, text: mode === 'login' ? 'دخول' : 'إنشاء الحساب' });

  if (mode === 'register') box.append(el('div', { class: 'field' }, el('label', { text: 'الاسم' }), name));
  box.append(el('div', { class: 'field' }, el('label', { text: 'البريد الإلكتروني' }), email));
  box.append(el('div', { class: 'field' }, el('label', { text: 'كلمة المرور' }), pass));
  box.append(err, submit);

  submit.onclick = async () => {
    err.textContent = '';
    submit.disabled = true;
    try {
      const res = mode === 'login'
        ? await API.login(email.value.trim(), pass.value)
        : await API.register(email.value.trim(), pass.value, name.value.trim());
      setToken(res.token);
      await loadSession();
      await loadSubscriptions();
      toast(mode === 'login' ? `أهلاً بعودتك ${res.user.name}` : 'تم إنشاء الحساب بنجاح', 'ok');
      location.hash = '#/';
      window.dispatchEvent(new CustomEvent('vidora:session-changed'));
    } catch (e) {
      err.textContent = e.message;
    } finally {
      submit.disabled = false;
    }
  };

  const onKey = (e) => { if (e.key === 'Enter') submit.click(); };
  [email, pass, name].forEach((i) => i.addEventListener('keydown', onKey));

  container.append(box);
}
