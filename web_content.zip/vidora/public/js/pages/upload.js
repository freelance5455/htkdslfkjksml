/* صفحة رفع فيديو من الجهاز */
import { API, setToken } from '../api.js';
import { el, icon, toast, fmtBytes } from '../utils.js';
import { store, isLoggedIn } from '../store.js';

export async function renderUpload(container) {
  container.innerHTML = '';
  container.append(el('div', { class: 'page-head' },
    el('h1', { text: 'رفع فيديو' }),
    el('p', { text: 'ارفع ملفاً من جهازك — سيُحوَّل تلقائياً إلى صيغة MP4 مناسبة للبث.' })
  ));

  if (!isLoggedIn()) {
    container.append(el('div', { class: 'panel center' },
      el('h3', { text: 'يلزم تسجيل الدخول' }),
      el('p', { class: 'muted', text: 'سجّل الدخول أو أنشئ حساباً لرفع الفيديوهات.' }),
      el('a', { class: 'btn primary', href: '#/register', text: 'إنشاء حساب' })
    ));
    return;
  }

  let selectedFile = null;

  const drop = el('div', { class: 'drop' },
    icon('upload'),
    el('h3', { text: 'اسحب الفيديو هنا أو اضغط للاختيار' }),
    el('p', { id: 'fileInfo', text: `MP4 / MKV / WEBM / MOV — الحد الأقصى ${store.config?.maxUploadMb || 2048} ميجابايت` })
  );
  const fileInput = el('input', { type: 'file', accept: 'video/*', style: { display: 'none' } });
  drop.onclick = () => fileInput.click();
  drop.ondragover = (e) => { e.preventDefault(); drop.classList.add('over'); };
  drop.ondragleave = () => drop.classList.remove('over');
  drop.ondrop = (e) => {
    e.preventDefault();
    drop.classList.remove('over');
    const f = e.dataTransfer.files?.[0];
    if (f) setFile(f);
  };
  fileInput.onchange = () => { const f = fileInput.files?.[0]; if (f) setFile(f); };

  function setFile(f) {
    selectedFile = f;
    const info = container.querySelector('#fileInfo');
    if (info) info.textContent = `${f.name} — ${fmtBytes(f.size)}`;
    titleInput.value = titleInput.value || f.name.replace(/\.[^.]+$/, '');
    if (progressBox) progressBox.remove();
  }

  const panel = el('div', { class: 'panel' });
  panel.append(drop, fileInput);

  const titleInput = el('input', { class: 'input', placeholder: 'عنوان الفيديو', maxlength: '200' });
  const descInput = el('textarea', { class: 'textarea', placeholder: 'الوصف' });
  const tagsInput = el('input', { class: 'input', placeholder: 'وسوم مفصولة بفاصلة: رياضة، مباريات' });
  const catSelect = el('select', { class: 'input' });
  for (const c of store.categories.filter((x) => x.name !== 'الكل')) catSelect.append(el('option', { value: c.name, text: c.name }));
  const visSelect = el('select', { class: 'input' });
  for (const [v, l] of [['public', 'عام'], ['unlisted', 'غير مدرج'], ['private', 'خاص']]) visSelect.append(el('option', { value: v, text: l }));

  panel.append(
    el('div', { class: 'field' }, el('label', { text: 'العنوان' }), titleInput),
    el('div', { class: 'field' }, el('label', { text: 'الوصف' }), descInput),
    el('div', { class: 'row' },
      el('div', { class: 'field' }, el('label', { text: 'الفئة' }), catSelect),
      el('div', { class: 'field' }, el('label', { text: 'الوسوم' }), tagsInput),
      el('div', { class: 'field' }, el('label', { text: 'الظهور' }), visSelect)
    )
  );

  let progressBox = null;
  const submit = el('button', { class: 'btn accent', style: { width: '100%', justifyContent: 'center', height: '46px' } },
    icon('upload'), 'رفع ونشر');
  panel.append(el('div', { style: { marginTop: '10px' } }, submit));

  submit.onclick = async () => {
    if (!selectedFile) { toast('اختر ملف فيديو أولاً', 'err'); return; }
    if (!titleInput.value.trim()) { toast('اكتب عنواناً للفيديو', 'err'); return; }

    const fd = new FormData();
    fd.append('video', selectedFile);
    fd.append('title', titleInput.value.trim());
    fd.append('description', descInput.value);
    fd.append('tags', tagsInput.value);
    fd.append('category', catSelect.value);
    fd.append('visibility', visSelect.value);

    progressBox = el('div', { style: { marginTop: '16px' } },
      el('div', { class: 'muted small', id: 'upMsg', text: 'جاري الرفع… 0%' }),
      el('div', { class: 'progress' }, el('i', { id: 'upBar', style: { width: '0%' } }))
    );
    panel.append(progressBox);

    submit.disabled = true;

    // رفع باستخدام XHR للحصول على نسبة التقدم الحقيقية
    await new Promise((resolve) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', '/api/videos/upload');
      const token = localStorage.getItem('vidora_token');
      if (token) xhr.setRequestHeader('Authorization', `Bearer ${token}`);
      xhr.upload.onprogress = (e) => {
        if (!e.lengthComputable) return;
        const pct = Math.round((e.loaded / e.total) * 100);
        const bar = panel.querySelector('#upBar');
        const msg = panel.querySelector('#upMsg');
        if (bar) bar.style.width = `${pct}%`;
        if (msg) msg.textContent = `جاري الرفع… ${pct}%`;
      };
      xhr.onload = () => {
        try {
          const data = JSON.parse(xhr.responseText || '{}');
          if (xhr.status >= 200 && xhr.status < 300) {
            const bar = panel.querySelector('#upBar');
            const msg = panel.querySelector('#upMsg');
            if (bar) { bar.style.width = '100%'; bar.parentElement.classList.add('green'); }
            if (msg) msg.textContent = 'تم الرفع بنجاح — جارٍ فتح الفيديو…';
            toast('تم رفع الفيديو بنجاح', 'ok');
            setTimeout(() => { location.hash = `#/watch/${data.video.id}`; }, 700);
          } else {
            toast(data.error || 'فشل الرفع', 'err');
            submit.disabled = false;
          }
        } catch {
          toast('فشل الرفع', 'err');
          submit.disabled = false;
        }
        resolve();
      };
      xhr.onerror = () => { toast('فشل الاتصال أثناء الرفع', 'err'); submit.disabled = false; resolve(); };
      xhr.send(fd);
    });
  };

  container.append(panel);
}
