/* المكتبة الشخصية: السجل، المشاهدة لاحقاً، المعجب، قوائم التشغيل */
import { API } from '../api.js';
import { el, icon, toast, timeAgo } from '../utils.js';
import { videoGrid, skeletonGrid, emptyState } from '../ui.js';
import { isLoggedIn } from '../store.js';

export async function renderLibrary(container, params) {
  const kind = params.kind || 'history';
  container.innerHTML = '';

  const titles = {
    history: ['السجل', 'clock'],
    watchlater: ['المشاهدة لاحقاً', 'bookmark'],
    liked: ['الفيديوهات المعجوبة', 'like'],
    playlists: ['قوائم التشغيل', 'playlist'],
  };
  const [title, ic] = titles[kind] || titles.history;

  container.append(el('div', { class: 'page-head' },
    el('h1', { text: title }),
    el('p', { text: kind === 'history' ? 'الفيديوهات التي شاهدتها recently.' : kind === 'watchlater' ? 'قائمة تشغيلك الخاصة.' : kind === 'liked' ? 'كل ما أعجبك في مكان واحد.' : 'أنشئ قوائم وقسّم محتواك.' })
  ));

  if (!isLoggedIn()) {
    container.append(el('div', { class: 'panel center' },
      el('h3', { text: 'يلزم تسجيل الدخول' }),
      el('p', { class: 'muted', text: 'سجّل الدخول لعرض مكتبتك.' }),
      el('a', { class: 'btn primary', href: '#/login', text: 'تسجيل الدخول' })
    ));
    return;
  }

  if (kind === 'playlists') return renderPlaylists(container);

  const box = el('div', {}, skeletonGrid(6));
  container.append(box);
  try {
    const data = kind === 'history' ? await API.history()
      : kind === 'watchlater' ? await API.watchLater()
        : await API.liked();
    box.innerHTML = '';
    if (!data.items.length) {
      box.append(emptyState({
        icon: ic,
        title: 'القائمة فارغة',
        text: 'تصفّح الفيديوهات وستظهر هنا تلقائياً.',
        action: { label: 'تصفّح الرئيسية', href: '#/' },
      }));
      return;
    }
    box.append(videoGrid(data.items));
  } catch (err) {
    box.innerHTML = '';
    box.append(el('p', { class: 'muted', text: err.message }));
  }
}

async function renderPlaylists(container) {
  const panel = el('div', { class: 'panel' });
  const input = el('input', { class: 'input', placeholder: 'اسم القائمة الجديدة' });
  const btn = el('button', { class: 'btn primary', text: 'إنشاء' });
  btn.onclick = async () => {
    const name = input.value.trim();
    if (!name) return;
    try {
      await API.createPlaylist(name);
      input.value = '';
      load();
      toast('تم إنشاء القائمة', 'ok');
    } catch (e) { toast(e.message, 'err'); }
  };
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') btn.click(); });
  panel.append(el('h3', { text: 'إنشاء قائمة تشغيل' }),
    el('div', { class: 'row' }, input, el('div', { style: { flex: '0 0 auto' } }, btn)));
  container.append(panel);

  const list = el('div', { class: 'stat-grid' });
  container.append(list);

  async function load() {
    try {
      const { items } = await API.playlists();
      list.innerHTML = '';
      if (!items.length) {
        list.append(el('div', { class: 'empty' }, el('h3', { text: 'لا توجد قوائم' }), el('p', { text: 'أنشئ أول قائمة من الأعلى.' })));
        return;
      }
      for (const p of items) {
        const card = el('div', { class: 'stat', style: { position: 'relative' } });
        card.append(el('div', { class: 'k', text: 'قائمة' }));
        card.append(el('div', { class: 'v', style: { fontSize: '17px' }, text: p.name }));
        card.append(el('div', { class: 'muted small', text: `${p.count} فيديو` }));
        card.append(el('a', { class: 'btn sm', style: { marginTop: '10px' }, href: `#/playlist/${p.id}`, text: 'فتح' }));
        const del = el('button', { class: 'icon-btn', style: { position: 'absolute', top: '8px', insetInlineEnd: '8px' }, title: 'حذف' }, icon('trash'));
        del.onclick = async () => {
          if (!confirm('حذف هذه القائمة؟')) return;
          try { await API.deletePlaylist(p.id); load(); toast('تم الحذف', 'ok'); } catch (e) { toast(e.message, 'err'); }
        };
        card.append(del);
        list.append(card);
      }
    } catch (err) {
      list.innerHTML = '';
      list.append(el('p', { class: 'muted', text: err.message }));
    }
  }
  await load();
}

export async function renderPlaylist(container, params) {
  container.innerHTML = '';
  const box = el('div', {}, skeletonGrid(4));
  container.append(box);
  try {
    const { playlist, items } = await API.playlist(params.id);
    container.innerHTML = '';
    container.append(el('div', { class: 'page-head' },
      el('h1', { text: playlist.name }),
      el('p', { text: `${items.length} فيديو • ${playlist.description || ''}` })
    ));
    box.innerHTML = '';
    if (!items.length) {
      box.append(emptyState({ icon: 'playlist', title: 'القائمة فارغة', text: 'أضف فيديوهات من صفحة الفيديو.' }));
      return;
    }
    box.append(videoGrid(items));
    container.append(box);
  } catch (err) {
    box.innerHTML = '';
    box.append(el('p', { class: 'muted', text: err.message }));
  }
}
