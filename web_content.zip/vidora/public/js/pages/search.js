/* صفحة البحث */
import { API } from '../api.js';
import { el, fmtViews } from '../utils.js';
import { videoGrid, skeletonGrid, emptyState } from '../ui.js';
import { store } from '../store.js';

let lastQuery = '';

export async function renderSearch(container, params) {
  const q = params.q || '';
  const category = params.category || '';
  let sort = params.sort || 'relevance';
  let duration = params.duration || '';
  container.innerHTML = '';

  container.append(el('div', { class: 'page-head' },
    el('h1', { text: q ? `نتائج البحث عن «${q}»` : 'البحث' }),
    el('p', { id: 'resultCount', text: 'جارٍ البحث…' })
  ));

  const filters = el('div', { class: 'row', style: { marginBottom: '18px' } });
  filters.append(el('div', {},
    el('label', { text: 'ترتيب حسب' }),
    (() => {
      const sel = el('select', { class: 'input', onchange: (e) => { sort = e.target.value; run(); } });
      for (const [v, l] of [['relevance', 'الأكثر صلة'], ['recent', 'الأحدث'], ['views', 'الأكثر مشاهدة'], ['likes', 'الأكثر إعجاباً']]) {
        sel.append(el('option', { value: v, text: l, selected: v === sort }));
      }
      return sel;
    })()
  ));
  filters.append(el('div', {},
    el('label', { text: 'المدة' }),
    (() => {
      const sel = el('select', { class: 'input', onchange: (e) => { duration = e.target.value; run(); } });
      for (const [v, l] of [['', 'الكل'], ['short', 'أقل من 4 دقائق'], ['medium', '4 - 20 دقيقة'], ['long', 'أكثر من 20 دقيقة']]) {
        sel.append(el('option', { value: v, text: l, selected: v === duration }));
      }
      return sel;
    })()
  ));
  if (category) {
    filters.append(el('div', {},
      el('label', { text: 'الفئة' }),
      el('select', { class: 'input', onchange: (e) => { category = e.target.value; run(); } },
        ...store.categories.map((c) => el('option', { value: c.name, text: c.name, selected: c.name === category }))
      )
    ));
  }
  container.append(filters);

  const grid = el('div', {}, skeletonGrid(8));
  container.append(grid);

  lastQuery = q;
  async function run() {
    grid.innerHTML = '';
    grid.append(skeletonGrid(8));
    try {
      const { items, total } = await API.videos({
        q, category, sort: sort === 'relevance' ? 'recent' : sort, duration, limit: 40,
      });
      grid.innerHTML = '';
      const count = container.querySelector('#resultCount');
      if (count) count.textContent = `${total} نتيجة`;
      if (!items.length) {
        grid.append(emptyState({
          icon: 'search',
          title: 'لا توجد نتائج',
          text: 'جرّب كلمات مفتاحية مختلفة أو استورد الفيديو بنفسك من صفحة الاستيراد.',
          action: { label: 'استيراد من رابط', href: '#/import' },
        }));
        return;
      }
      grid.append(videoGrid(items));
    } catch (err) {
      grid.innerHTML = '';
      grid.append(el('p', { class: 'muted', text: err.message }));
    }
  }
  await run();
}
