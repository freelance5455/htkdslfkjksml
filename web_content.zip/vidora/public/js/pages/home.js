/* الصفحة الرئيسية + الاستكشاف */
import { API } from '../api.js';
import { el, fmtViews, toast } from '../utils.js';
import { videoGrid, skeletonGrid, chipsBar, announcementBar } from '../ui.js';
import { store } from '../store.js';

let currentCategory = 'الكل';
let currentSort = 'recent';

export async function renderHome(container, params = {}) {
  container.innerHTML = '';
  const head = el('div', { class: 'page-head' },
    el('h1', { text: 'الرئيسية' }),
    el('p', { text: 'اكتشف أحدث الفيديوهات والمحتوى المستورد من الإنترنت.' })
  );
  container.append(head);
  const ann = announcementBar();
  if (ann) container.append(ann);

  const bar = chipsBar(currentCategory, (name) => {
    currentCategory = name;
    loadFeed(container);
  });
  container.append(bar);

  const sortBar = el('div', { class: 'row chips-row', style: { marginBottom: '18px', alignItems: 'center' } },
    el('div', { class: 'muted small sort-label', text: 'الترتيب:' }),
    ...['recent', 'trending', 'views', 'oldest'].map((s) => el('button', {
      class: `chip${currentSort === s ? ' active' : ''}`,
      text: { recent: 'الأحدث', trending: 'الرائج', views: 'الأكثر مشاهدة', oldest: 'الأقدم' }[s],
      onclick: (e) => {
        currentSort = s;
        for (const b of e.target.parentElement.querySelectorAll('.chip')) b.classList.remove('active');
        e.target.classList.add('active');
        loadFeed(container);
      },
    }))
  );
  container.append(sortBar);

  const feed = el('div', { id: 'feed' }, skeletonGrid(12));
  container.append(feed);

  await loadFeed(container);
}

async function loadFeed(container) {
  const feed = container.querySelector('#feed');
  if (!feed) return;
  feed.innerHTML = '';
  feed.append(skeletonGrid(12));
  try {
    const { items } = await API.videos({
      category: currentCategory === 'الكل' ? '' : currentCategory,
      sort: currentSort,
      limit: 24,
    });
    feed.innerHTML = '';
    if (!items.length) {
      feed.append(videoGrid([]));
      return;
    }
    feed.append(videoGrid(items));
  } catch (err) {
    feed.innerHTML = '';
    feed.append(el('div', { class: 'empty' }, el('h3', { text: 'تعذّر تحميل الفيديوهات' }), el('p', { text: err.message })));
  }
}

export async function renderExplore(container) {
  container.innerHTML = '';
  container.append(el('div', { class: 'page-head' },
    el('h1', { text: 'استكشاف' }),
    el('p', { text: 'تصفّح حسب الفئة أو ابحث عن ما تريد مشاهدته.' })
  ));
  const cats = el('div', { class: 'stat-grid' });
  for (const c of store.categories.filter((x) => x.name !== 'الكل')) {
    cats.append(el('a', {
      class: 'stat', href: `#/search?category=${encodeURIComponent(c.name)}`,
      style: { display: 'block' },
    },
      el('div', { class: 'k', text: 'فئة' }),
      el('div', { class: 'v', style: { fontSize: '18px' }, text: c.name }),
      el('div', { class: 'muted small', text: `${c.count} فيديو` })
    ));
  }
  container.append(cats);

  container.append(el('div', { class: 'page-head', style: { marginTop: '30px' } },
    el('h1', { text: 'الأكثر مشاهدة' }),
    el('p', { text: 'الأعلى تفاعلاً على Vidora.' })
  ));
  const grid = el('div', {}, skeletonGrid(8));
  container.append(grid);
  try {
    const { items } = await API.videos({ sort: 'views', limit: 16 });
    grid.innerHTML = '';
    grid.append(videoGrid(items));
  } catch (err) {
    grid.innerHTML = '';
    grid.append(el('p', { class: 'muted', text: err.message }));
  }
}
