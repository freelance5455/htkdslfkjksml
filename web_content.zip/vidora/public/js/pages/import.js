/* صفحة الاستيراد من الإنترنت */
import { API, connectEvents } from '../api.js';
import { el, icon, toast, timeAgo } from '../utils.js';
import { store, isLoggedIn } from '../store.js';

let eventSource = null;

export async function renderImport(container) {
  container.innerHTML = '';
  container.append(el('div', { class: 'page-head' },
    el('h1', { text: 'استيراد فيديو من الإنترنت' }),
    el('p', { text: 'الصق رابطاً من أي منصة مدعومة (يوتيوب، فيميو، ديلي موشن، تيك توك، روابط MP4 مباشرة…) وسيُنزَّل الفيديو ويُضاف إلى منصتك.' })
  ));

  if (!isLoggedIn()) {
    container.append(el('div', { class: 'panel center' },
      el('h3', { text: 'يلزم تسجيل الدخول' }),
      el('p', { class: 'muted', text: 'سجّل الدخول لتنزيل الفيديوهات وإضافتها إلى قناتك.' }),
      el('a', { class: 'btn primary', href: '#/register', text: 'إنشاء حساب' })
    ));
    return;
  }

  const caps = store.capabilities || {};
  const capBox = el('div', { class: 'panel' });
  capBox.append(el('h3', { text: 'حالة الأدوات' }));
  const capRow = el('div', { class: 'stat-grid' });
  const cap = (k, ok, hint) => capRow.append(el('div', { class: 'stat' },
    el('div', { class: 'k', text: k }),
    el('div', { class: 'v', style: { fontSize: '18px', color: ok ? '#4ade80' : '#ff6b8a' }, text: ok ? 'متاح' : 'غير متاح' }),
    hint ? el('div', { class: 'muted small', text: hint }) : null
  ));
  cap('yt-dlp', caps.ytdlp, caps.ytdlp ? 'محرك التنزيل' : 'شغّل install.sh');
  cap('ffmpeg', caps.ffmpeg, 'تحويل الفيديو');
  cap('ملف الكوكيز', caps.cookies, caps.cookies ? 'موجود — يفتح المنصات المحمية' : 'ضعه في data/cookies.txt');
  cap('البروكسي', caps.proxy, caps.proxy ? 'مفعّل للتنزيل' : 'اضبط DOWNLOAD_PROXY');
  capBox.append(capRow);
  if (!caps.ytdlp || !caps.ffmpeg) {
    capBox.append(el('p', { class: 'hint', text: 'لتفعيل كل الوظائف على خادم إنتاجي: bash install.sh && sudo systemctl restart vidora' }));
  }
  container.append(capBox);

  /* ------------------------- نموذج الاستيراد ------------------------- */
  const panel = el('div', { class: 'panel' });
  const urlInput = el('input', { class: 'input', placeholder: 'https://www.youtube.com/watch?v=...', dir: 'ltr', style: { textAlign: 'left' } });
  const titleInput = el('input', { class: 'input', placeholder: 'العنوان (اختياري — يُجلب تلقائياً من الرابط)' });
  const descInput = el('textarea', { class: 'textarea', placeholder: 'الوصف (اختياري)' });
  const tagsInput = el('input', { class: 'input', placeholder: 'وسوم مفصولة بفاصلة' });
  const catSelect = el('select', { class: 'input' });
  for (const c of store.categories.filter((x) => x.name !== 'الكل')) catSelect.append(el('option', { value: c.name, text: c.name }));
  const qualitySelect = el('select', { class: 'input' });
  qualitySelect.append(el('option', { value: 'best', text: 'أعلى جودة' }), el('option', { value: 'low', text: 'جودة أقل (أسرع)' }));

  panel.append(
    el('div', { class: 'field' }, el('label', { text: 'رابط الفيديو' }), urlInput,
      el('div', { class: 'hint', text: 'يدعم: يوتيوب، فيميو، ديلي موشن، تيك توك، إنستغرام، X،بيكسels، أرشيف.ORG، وأي رابط MP4 مباشر.' })),
    el('div', { class: 'field' }, el('label', { text: 'العنوان' }), titleInput),
    el('div', { class: 'field' }, el('label', { text: 'الوصف' }), descInput),
    el('div', { class: 'row' },
      el('div', { class: 'field' }, el('label', { text: 'الفئة' }), catSelect),
      el('div', { class: 'field' }, el('label', { text: 'الوسوم' }), tagsInput),
      el('div', { class: 'field' }, el('label', { text: 'الجودة' }), qualitySelect)
    )
  );

  const startBtn = el('button', { class: 'btn accent', style: { width: '100%', justifyContent: 'center', height: '46px' } },
    icon('download'), 'ابدأ التنزيل');
  panel.append(el('div', { style: { marginTop: '6px' } }, startBtn));
  container.append(panel);

  /* ----------------------------- سجل المهام ----------------------------- */
  const jobsTitle = el('h3', { text: 'المهام الأخيرة', style: { margin: '28px 0 4px', fontSize: '18px' } });
  const jobsBox = el('div');
  container.append(jobsTitle, jobsBox);

  const renderJobs = (jobs) => {
    jobsBox.innerHTML = '';
    if (!jobs.length) {
      jobsBox.append(el('p', { class: 'muted', text: 'لا توجد مهام بعد.' }));
      return;
    }
    for (const job of jobs) jobsBox.append(jobCard(job));
  };

  const jobCard = (job) => {
    const state = job.status;
    const stateLabel = {
      queued: 'بالانتظار', running: 'قيد التنفيذ', done: 'اكتملت', failed: 'فشلت',
    }[state] || state;
    const cls = state === 'done' ? 'done' : state === 'failed' ? 'failed' : state === 'running' ? 'running' : 'queued';
    const card = el('div', { class: 'job' });
    const top = el('div', { class: 'job-top' });
    top.append(el('div', { style: { minWidth: '0' } },
      el('div', { class: 'job-title', text: job.title || job.url || 'مهمة' }),
      el('div', { class: 'job-url', text: job.url || '' })
    ));
    top.append(el('span', { class: `state ${cls}` },
      state === 'running' ? el('span', { class: 'spin' }) : null,
      stateLabel
    ));
    card.append(top);

    const msg = el('div', { class: 'job-msg', text: job.message || '' });
    card.append(msg);
    if (state === 'running' || state === 'queued') {
      card.append(el('div', { class: 'progress' }, el('i', { style: { width: `${Math.round(job.progress || 0)}%` } })));
    }
    if (job.error) card.append(el('div', { class: 'job-msg', style: { color: '#ff6b8a', marginTop: '6px' }, text: job.error }));
    if (job.video_id && state === 'done') {
      card.append(el('a', { class: 'btn sm', style: { marginTop: '10px' }, href: `#/watch/${job.video_id}`, text: 'مشاهدة الفيديو' }));
    }
    return card;
  };

  startBtn.onclick = async () => {
    const url = urlInput.value.trim();
    if (!url) { toast('أدخل رابط الفيديو', 'err'); urlInput.focus(); return; }
    startBtn.disabled = true;
    try {
      await API.importVideo({
        url,
        title: titleInput.value.trim(),
        description: descInput.value,
        tags: tagsInput.value,
        category: catSelect.value,
        quality: qualitySelect.value,
      });
      toast('بدأت مهمة التنزيل', 'ok');
      urlInput.value = '';
      await refresh();
    } catch (err) {
      toast(err.message, 'err');
    } finally {
      startBtn.disabled = false;
    }
  };

  async function refresh() {
    try {
      const { items } = await API.jobs();
      renderJobs(items);
    } catch { /* ignore */ }
  }
  await refresh();

  // تحديث حي عبر SSE
  if (!eventSource) {
    eventSource = connectEvents((evt) => {
      if (evt?.type === 'job') {
        const idx = jobsBox.children.length;
        const job = evt.job;
        const existing = Array.from(jobsBox.children).find((c) => c.dataset && c.dataset.id === String(job.id));
        if (existing) existing.replaceWith(jobCard(job));
        else if (idx >= 0) refresh();
      }
    });
  }
  window.addEventListener('hashchange', () => { /* لا شيء */ });
}
