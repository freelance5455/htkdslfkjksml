/* صفحة مشاهدة الفيديو */
import { API } from '../api.js';
import { el, icon, fmtViews, fmtDuration, timeAgo, fmtDate, toast, copyText, avatarEl } from '../utils.js';
import { videoCard } from '../ui.js';
import { store, isLoggedIn } from '../store.js';

let cleanup = null;

export async function renderWatch(container, params) {
  if (cleanup) { cleanup(); cleanup = null; }
  container.innerHTML = '';

  const id = params.id;
  const wrap = el('div', { class: 'watch' });
  const main = el('div');
  const side = el('div');
  wrap.append(main, side);
  container.append(wrap);

  main.append(el('div', { class: 'player-wrap skeleton', style: { height: '360px' } }));

  let data;
  try {
    data = await API.video(id);
  } catch (err) {
    main.innerHTML = '';
    main.append(el('div', { class: 'empty' }, el('h3', { text: 'الفيديو غير متاح' }), el('p', { text: err.message })));
    return;
  }

  const { video, reaction, inWatchLater } = data;
  main.innerHTML = '';

  /* ---------------------- المشغّل ---------------------- */
  const playerWrap = el('div', { class: 'player-wrap' });
  const videoEl = el('video', {
    controls: true, playsinline: true, preload: 'metadata',
    poster: video.poster_url || '',
  });
  if (video.stream_url) videoEl.append(el('source', { src: video.stream_url, type: 'video/mp4' }));
  if (video.webm_url) videoEl.append(el('source', { src: video.webm_url, type: 'video/webm' }));
  playerWrap.append(videoEl);
  if (video.source_type === 'import') playerWrap.append(el('span', { class: 'player-badge', text: 'مستورد من الإنترنت' }));
  main.append(playerWrap);

  /* ---------------------- العنوان ---------------------- */
  main.append(el('h1', { text: video.title }));

  const bar = el('div', { class: 'watch-bar' });

  const chanRow = el('div', { class: 'chan-row' });
  chanRow.append(avatarEl(video.channel_name, '#3ea6ff', video.channel_avatar));
  chanRow.append(el('div', {},
    el('div', { class: 'chan-name' },
      el('a', { href: `#/channel/${video.channel_id}`, text: video.channel_name || 'قناة مجهولة' })
    ),
    el('div', { class: 'chan-subs', text: `${fmtViews(video.channel_subscribers)} مشترك` })
  ));
  if (isLoggedIn()) {
    const subBtn = el('button', { class: 'btn sm', text: 'اشتراك' });
    subBtn.onclick = async () => {
      try {
        const r = await API.subscribe(video.channel_id);
        subBtn.textContent = r.subscribed ? 'مشترك ✓' : 'اشتراك';
        subBtn.classList.toggle('on', r.subscribed);
        toast(r.subscribed ? 'تم الاشتراك في القناة' : 'تم إلغاء الاشتراك', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    };
    chanRow.append(subBtn);
  }
  bar.append(chanRow);

  const actions = el('div', { class: 'actions' });

  const likeBtn = el('button', { class: `btn sm${reaction === 1 ? ' on' : ''}` }, icon('like'), el('span', { text: fmtViews(video.likes) }));
  const dislikeBtn = el('button', { class: `btn sm${reaction === -1 ? ' on' : ''}` }, icon('dislike'));
  actions.append(likeBtn, dislikeBtn);

  const shareBtn = el('button', {
    class: 'btn sm', onclick: () => copyText(location.href),
  }, icon('share'), 'مشاركة');
  actions.append(shareBtn);

  if (video.download_url) {
    actions.append(el('a', {
      class: 'btn sm', href: video.download_url, download: '',
    }, icon('download'), 'تنزيل'));
  }

  const laterBtn = el('button', { class: `btn sm${inWatchLater ? ' on' : ''}` }, icon('bookmark'), 'حفظ');
  actions.append(laterBtn);
  bar.append(actions);
  main.append(bar);

  /* ---------------------- الوصف ---------------------- */
  const desc = el('div', { class: 'desc' });
  const descStats = el('div', { class: 'stats-line', text: `${fmtViews(video.views)} مشاهدة • ${timeAgo(video.published_at)} • ${fmtDate(video.published_at)}` });
  const descText = el('p', { text: video.description || 'لا يوجد وصف لهذا الفيديو.' });
  desc.append(descStats, descText);
  if (video.tags?.length) {
    desc.append(el('div', { style: { display: 'flex', gap: '8px', flexWrap: 'wrap', marginTop: '6px' } },
      ...video.tags.map((t) => el('a', { class: 'chip', href: `#/search?q=${encodeURIComponent(t)}`, text: `#${t}` }))
    ));
  }
  const toggle = el('div', { class: 'toggle', text: 'عرض المزيد' });
  desc.append(toggle);
  let expanded = false;
  toggle.onclick = () => {
    expanded = !expanded;
    descText.style.display = expanded ? 'block' : '-webkit-box';
    descText.style.webkitLineClamp = expanded ? 'unset' : '2';
    descText.style.webkitBoxOrient = expanded ? 'initial' : 'vertical';
    toggle.textContent = expanded ? 'عرض أقل' : 'عرض المزيد';
  };
  main.append(desc);

  /* ---------------------- التعليقات ---------------------- */
  const commentsBox = el('div', { class: 'comments' });
  main.append(commentsBox);
  await renderComments(commentsBox, video);

  /* ---------------------- المرتبطة ---------------------- */
  side.append(el('div', { class: 'page-head', style: { marginTop: '0' } }, el('h1', { text: 'فيديوهات مقترحة' })));
  try {
    const { items } = await API.similar(video.id);
    const list = el('div');
    for (const v of items) {
      const row = el('div', { class: 'side-videos', onclick: () => { location.hash = `#/watch/${v.id}`; } });
      const t = el('div', { class: 'thumb' });
      if (v.poster_url || v.thumb_url) {
        t.append(el('img', { src: v.poster_url || v.thumb_url, alt: v.title, loading: 'lazy' }));
      } else t.append(el('div', { class: 'ph' }, icon('play')));
      if (v.duration) t.append(el('span', { class: 'dur', text: fmtDuration(v.duration) }));
      row.append(t, el('div', {},
        el('div', { class: 'st', text: v.title }),
        el('div', { class: 'meta', text: `${v.channel_name || ''} • ${fmtViews(v.views)} مشاهدة` })
      ));
      list.append(row);
    }
    side.append(list);
  } catch { /* لا شيء */ }

  /* ---------------------- التفاعلات ---------------------- */
  const doReact = async (value) => {
    if (!isLoggedIn()) { toast('سجّل الدخول للتفاعل مع الفيديوهات', 'err'); return; }
    try {
      const r = await API.react(video.id, value);
      likeBtn.querySelector('span').textContent = fmtViews(r.likes);
      likeBtn.classList.toggle('on', r.reaction === 1);
      dislikeBtn.classList.toggle('on', r.reaction === -1);
    } catch (e) { toast(e.message, 'err'); }
  };
  likeBtn.onclick = () => doReact(1);
  dislikeBtn.onclick = () => doReact(-1);

  laterBtn.onclick = async () => {
    if (!isLoggedIn()) { toast('سجّل الدخول لحفظ الفيديوهات', 'err'); return; }
    try {
      const r = await API.toggleWatchLater(video.id);
      laterBtn.classList.toggle('on', r.inWatchLater);
      toast(r.inWatchLater ? 'أُضيف إلى المشاهدة لاحقاً' : 'أُزيل من القائمة', 'ok');
    } catch (e) { toast(e.message, 'err'); }
  };

  /* ---------------------- التتبع ---------------------- */
  let counted = false;
  let progressTimer = null;
  const onPlay = async () => {
    if (!counted) {
      counted = true;
      try {
        const r = await API.view(video.id);
        const stat = main.querySelector('.stats-line');
        if (stat) stat.textContent = `${fmtViews(r.views)} مشاهدة • ${timeAgo(video.published_at)} • ${fmtDate(video.published_at)}`;
      } catch { /* ignore */ }
    }
  };
  videoEl.addEventListener('play', onPlay);
  progressTimer = setInterval(() => {
    if (videoEl.currentTime > 0 && isLoggedIn()) {
      API.progress(video.id, videoEl.currentTime).catch(() => {});
    }
  }, 20000);

  cleanup = () => {
    videoEl.removeEventListener('play', onPlay);
    clearInterval(progressTimer);
    try { videoEl.pause(); } catch { /* ignore */ }
  };
}

async function renderComments(box, video) {
  box.innerHTML = '';
  box.append(el('h3', { text: 'التعليقات' }));

  if (isLoggedIn()) {
    const form = el('div', { class: 'comment-form' });
    form.append(avatarEl(store.user.name, store.user.color));
    const input = el('textarea', { class: 'comment-input', placeholder: 'أضف تعليقاً…', rows: '1' });
    const send = el('button', { class: 'btn primary', text: 'تعليق' });
    send.onclick = async () => {
      const text = input.value.trim();
      if (!text) return;
      try {
        await API.addComment(video.id, text);
        input.value = '';
        await renderComments(box, video);
      } catch (e) { toast(e.message, 'err'); }
    };
    form.append(input, send);
    box.append(form);
  }

  const list = el('div');
  box.append(list);
  try {
    const { items } = await API.comments(video.id);
    if (!items.length) {
      list.append(el('p', { class: 'muted', text: 'لا توجد تعليقات بعد — كن أول المعلّقين!' }));
      return;
    }
    for (const c of items) {
      const item = el('div', { class: 'comment' });
      item.append(avatarEl(c.user_name || c.author, c.user_color || '#3ea6ff'));
      const body = el('div', { class: 'comment-body' });
      body.append(el('div', { class: 'comment-head' },
        el('b', { text: c.user_name || c.author || 'زائر' }),
        el('span', { text: timeAgo(c.created_at) })
      ));
      body.append(el('div', { class: 'comment-text', text: c.text }));
      const acts = el('div', { class: 'comment-actions' });
      acts.append(el('button', { onclick: (e) => { e.target.closest('button').querySelector('span').textContent = Number(e.target.closest('button').querySelector('span').textContent || 0) + 1; } },
        icon('like'), el('span', { text: '0' })));
      if (isLoggedIn() && (c.user_id === store.user.id || store.user.role === 'admin')) {
        acts.append(el('button', {
          onclick: async () => {
            try { await API.deleteComment(c.id); await renderComments(box, video); } catch (e) { toast(e.message, 'err'); }
          },
        }, icon('trash'), 'حذف'));
      }
      body.append(acts);
      item.append(body);
      list.append(item);
    }
  } catch (err) {
    list.append(el('p', { class: 'muted', text: err.message }));
  }
}
