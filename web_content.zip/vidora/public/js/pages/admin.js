/* لوحة التحكم */
import { API } from '../api.js';
import { el, icon, toast, fmtViews, fmtBytes, timeAgo } from '../utils.js';
import { isAdmin } from '../store.js';

export async function renderAdmin(container) {
  container.innerHTML = '';
  if (!isAdmin()) {
    container.append(el('div', { class: 'empty' }, el('h3', { text: 'هذه الصفحة للمديرين فقط' })));
    return;
  }

  container.append(el('div', { class: 'page-head' },
    el('h1', { text: 'لوحة التحكم' }),
    el('p', { text: 'إدارة الفيديوهات والمستخدمين وإعدادات الموقع.' })
  ));

  const body = el('div');
  container.append(body);
  body.append(el('div', { class: 'skeleton', style: { height: '160px', borderRadius: '14px' } }));

  let data;
  try {
    data = await API.adminStats();
  } catch (err) {
    body.innerHTML = '';
    body.append(el('p', { class: 'muted', text: err.message }));
    return;
  }
  body.innerHTML = '';

  /* إحصاءات */
  const stats = el('div', { class: 'stat-grid' });
  const stat = (k, v) => stats.append(el('div', { class: 'stat' },
    el('div', { class: 'k', text: k }), el('div', { class: 'v', text: v })));
  stat('الفيديوهات', data.videos);
  stat('المستخدمون', data.users);
  stat('القنوات', data.channels);
  stat('المشاهدات', fmtViews(data.views));
  stat('الإعجابات', fmtViews(data.likes));
  stat('التعليقات', data.comments);
  stat('المشتركون', fmtViews(data.subs));
  stat('حجم التخزين', fmtBytes(data.storage));
  body.append(stats);

  /* حالة النظام */
  const sys = el('div', { class: 'panel' });
  sys.append(el('h3', { text: 'حالة النظام' }));
  const s = data.system;
  const sysGrid = el('div', { class: 'stat-grid' });
  const sstat = (k, v, ok) => sysGrid.append(el('div', { class: 'stat' },
    el('div', { class: 'k', text: k }),
    el('div', { class: 'v', style: { fontSize: '16px', color: ok ? '#4ade80' : '#ff6b8a' }, text: v })));
  sstat('Node', s.node, true);
  sstat('مدة التشغيل', `${Math.floor(s.uptime / 60)} دقيقة`, true);
  sstat('ffmpeg', s.ffmpeg ? 'متاح' : 'غير متاح', s.ffmpeg);
  sstat('yt-dlp', s.ytdlp ? 'متاح' : 'غير متاح', s.ytdlp);
  sstat('ملف الكوكيز', s.cookies ? 'موجود' : 'غير موجود', s.cookies);
  sstat('البروكسي', s.proxy ? 'مفعّل' : 'غير مفعّل', s.proxy);
  sstat('قاعدة البيانات', fmtBytes(s.dbSize), true);
  sys.append(sysGrid);
  body.append(sys);

  /* إعدادات الموقع */
  const setPanel = el('div', { class: 'panel' });
  setPanel.append(el('h3', { text: 'إعدادات الموقع' }));
  const siteName = el('input', { class: 'input' });
  const tagline = el('input', { class: 'input' });
  const announcement = el('input', { class: 'input', placeholder: 'إعلان يظهر أعلى الصفحة الرئيسية' });
  try {
    const cfg = await API.adminSettings();
    siteName.value = cfg.siteName || '';
    tagline.value = cfg.siteTagline || '';
    announcement.value = cfg.announcement || '';
  } catch { /* ignore */ }
  const saveBtn = el('button', { class: 'btn primary', text: 'حفظ' });
  saveBtn.onclick = async () => {
    try {
      await API.saveSettings({ siteName: siteName.value, siteTagline: tagline.value, announcement: announcement.value });
      toast('تم حفظ الإعدادات', 'ok');
      setTimeout(() => location.reload(), 600);
    } catch (e) { toast(e.message, 'err'); }
  };
  setPanel.append(
    el('div', { class: 'field' }, el('label', { text: 'اسم الموقع' }), siteName),
    el('div', { class: 'field' }, el('label', { text: 'الوصف المختصر' }), tagline),
    el('div', { class: 'field' }, el('label', { text: 'الإعلان' }), announcement),
    saveBtn
  );
  body.append(setPanel);

  /* الفيديوهات */
  const vPanel = el('div', { class: 'panel' });
  vPanel.append(el('h3', { text: 'إدارة الفيديوهات' }));
  const vTable = el('table', { class: 'table' });
  vPanel.append(vTable);
  body.append(vPanel);
  try {
    const { items } = await API.adminVideos();
    vTable.innerHTML = '';
    vTable.append(el('thead', {}, el('tr', {},
      el('th', { text: 'العنوان' }), el('th', { text: 'القناة' }), el('th', { text: 'المصدر' }),
      el('th', { text: 'المشاهدات' }), el('th', { text: 'الحالة' }), el('th', { text: 'إجراءات' })
    )));
    const tb = el('tbody');
    for (const v of items) {
      const del = el('button', { class: 'btn sm', text: 'حذف' });
      del.onclick = async () => {
        if (!confirm(`حذف "${v.title}" نهائياً؟`)) return;
        try { await API.adminDeleteVideo(v.id); toast('تم الحذف', 'ok'); renderAdmin(container); } catch (e) { toast(e.message, 'err'); }
      };
      const feat = el('button', { class: 'btn sm', text: v.featured ? 'إلغاء التمييز' : 'تمييز' });
      feat.onclick = async () => {
        try { await API.adminFeature(v.id, !v.featured); renderAdmin(container); } catch (e) { toast(e.message, 'err'); }
      };
      tb.append(el('tr', {},
        el('td', { text: (v.title || '').slice(0, 48) }),
        el('td', { text: v.channel_name || '—' }),
        el('td', { text: v.source_type === 'import' ? 'مستورد' : 'مرفوع' }),
        el('td', { text: fmtViews(v.views) }),
        el('td', { text: v.status }),
        el('td', {}, el('div', { style: { display: 'flex', gap: '6px' } }, feat, del))
      ));
    }
    vTable.append(tb);
  } catch (err) {
    vTable.innerHTML = '';
    vTable.append(el('tr', {}, el('td', { text: err.message })));
  }

  /* المستخدمون */
  const uPanel = el('div', { class: 'panel' });
  uPanel.append(el('h3', { text: 'المستخدمون' }));
  const uTable = el('table', { class: 'table' });
  uPanel.append(uTable);
  body.append(uPanel);
  try {
    const { items } = await API.adminUsers();
    uTable.innerHTML = '';
    uTable.append(el('thead', {}, el('tr', {},
      el('th', { text: 'الاسم' }), el('th', { text: 'البريد' }), el('th', { text: 'الدور' }), el('th', { text: 'إجراءات' })
    )));
    const tb = el('tbody');
    for (const u of items) {
      const roleBtn = el('button', { class: 'btn sm', text: u.role === 'admin' ? 'إزالة المدير' : 'ترقية لمدير' });
      roleBtn.onclick = async () => {
        try { await API.adminUser(u.id, u.role === 'admin' ? 'user' : 'admin'); toast('تم تحديث الدور', 'ok'); renderAdmin(container); } catch (e) { toast(e.message, 'err'); }
      };
      const del = el('button', { class: 'btn sm', text: 'حذف' });
      del.onclick = async () => {
        if (!confirm(`حذف المستخدم ${u.name}؟`)) return;
        try { await API.adminDeleteUser(u.id); toast('تم الحذف', 'ok'); renderAdmin(container); } catch (e) { toast(e.message, 'err'); }
      };
      tb.append(el('tr', {},
        el('td', { text: u.name }), el('td', { text: u.email }), el('td', { text: u.role }),
        el('td', {}, el('div', { style: { display: 'flex', gap: '6px' } }, roleBtn, del))
      ));
    }
    uTable.append(tb);
  } catch (err) {
    uTable.innerHTML = '';
    uTable.append(el('tr', {}, el('td', { text: err.message })));
  }

  /* سجل المهام */
  const jPanel = el('div', { class: 'panel' });
  jPanel.append(el('h3', { text: 'سجل مهام الاستيراد' }));
  const jTable = el('table', { class: 'table' });
  jPanel.append(jTable);
  body.append(jPanel);
  try {
    const { items } = await API.adminJobs();
    jTable.innerHTML = '';
    jTable.append(el('thead', {}, el('tr', {},
      el('th', { text: '#' }), el('th', { text: 'العنوان' }), el('th', { text: 'الحالة' }),
      el('th', { text: 'الرسالة' }), el('th', { text: 'الوقت' })
    )));
    const tb = el('tbody');
    for (const j of items.slice(0, 40)) {
      tb.append(el('tr', {},
        el('td', { text: j.id }), el('td', { text: (j.title || j.url || '').slice(0, 40) }),
        el('td', { text: j.status }), el('td', { text: j.error || j.message || '' }),
        el('td', { text: timeAgo(j.updated_at) })
      ));
    }
    jTable.append(tb);
  } catch (err) {
    jTable.innerHTML = '';
    jTable.append(el('tr', {}, el('td', { text: err.message })));
  }
}
