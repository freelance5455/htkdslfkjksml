/* إعدادات الحساب */
import { API } from '../api.js';
import { el, toast } from '../utils.js';
import { store, isLoggedIn, loadSession } from '../store.js';

export async function renderSettings(container) {
  container.innerHTML = '';
  if (!isLoggedIn()) {
    container.append(el('div', { class: 'empty' }, el('h3', { text: 'سجّل الدخول أولاً' })));
    return;
  }
  container.append(el('div', { class: 'page-head' },
    el('h1', { text: 'الإعدادات' }),
    el('p', { text: 'إدارة بيانات حسابك وكلمة المرور.' })
  ));

  const panel = el('div', { class: 'panel', style: { maxWidth: '560px' } });
  const name = el('input', { class: 'input', value: store.user.name || '' });
  const color = el('input', { class: 'input', type: 'color', value: store.user.color || '#3ea6ff', style: { height: '44px', padding: '4px' } });
  panel.append(
    el('div', { class: 'field' }, el('label', { text: 'الاسم' }), name),
    el('div', { class: 'field' }, el('label', { text: 'لون الصورة الرمزية' }), color)
  );
  const save = el('button', { class: 'btn primary', text: 'حفظ البيانات' });
  save.onclick = async () => {
    try {
      await API.updateMe({ name: name.value.trim(), color: color.value });
      await loadSession();
      toast('تم حفظ البيانات', 'ok');
      window.dispatchEvent(new CustomEvent('vidora:session-changed'));
    } catch (e) { toast(e.message, 'err'); }
  };
  panel.append(save);
  container.append(panel);

  const pPanel = el('div', { class: 'panel', style: { maxWidth: '560px' } });
  pPanel.append(el('h3', { text: 'تغيير كلمة المرور' }));
  const cur = el('input', { class: 'input', type: 'password', placeholder: 'كلمة المرور الحالية', dir: 'ltr' });
  const nxt = el('input', { class: 'input', type: 'password', placeholder: 'كلمة المرور الجديدة', dir: 'ltr' });
  const chg = el('button', { class: 'btn', text: 'تغيير' });
  chg.onclick = async () => {
    try {
      await API.changePassword(cur.value, nxt.value);
      cur.value = ''; nxt.value = '';
      toast('تم تغيير كلمة المرور', 'ok');
    } catch (e) { toast(e.message, 'err'); }
  };
  pPanel.append(el('div', { class: 'field' }, el('label', { text: 'الحالية' }), cur),
    el('div', { class: 'field' }, el('label', { text: 'الجديدة' }), nxt), chg);
  container.append(pPanel);
}
