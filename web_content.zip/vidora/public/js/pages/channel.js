/* صفحة القناة */
import { API } from '../api.js';
import { el, icon, fmtViews, toast, avatarEl } from '../utils.js';
import { videoGrid, skeletonGrid } from '../ui.js';
import { store, isLoggedIn } from '../store.js';

export async function renderChannel(container, params) {
  container.innerHTML = '';
  let channelId = params.id;

  if (channelId === 'mine') {
    if (!isLoggedIn()) { location.hash = '#/login'; return; }
    if (!store.channel) {
      try { const d = await API.me(); store.channel = d.channel; } catch { /* ignore */ }
    }
    if (!store.channel) { container.append(el('div', { class: 'empty' }, el('h3', { text: 'لا توجد قناة لحسابك' }))); return; }
    channelId = store.channel.id;
  }

  container.append(el('div', { class: 'banner skeleton' }));
  const head = el('div', { class: 'chan-head' });
  container.append(head);

  const gridBox = el('div', {}, skeletonGrid(8));
  container.append(gridBox);

  let data;
  try {
    data = await API.channel(channelId);
  } catch (err) {
    container.innerHTML = '';
    container.append(el('div', { class: 'empty' }, el('h3', { text: 'القناة غير موجودة' }), el('p', { text: err.message })));
    return;
  }

  const { channel, videos, subscribed } = data;

  const banner = container.querySelector('.banner');
  banner.classList.remove('skeleton');
  if (channel.banner) banner.style.backgroundImage = `url(${channel.banner})`;
  banner.style.backgroundSize = 'cover';
  banner.style.backgroundPosition = 'center';

  head.innerHTML = '';
  head.append(avatarEl(channel.name, '#7c4dff', channel.avatar));
  const info = el('div', { style: { flex: '1 1 260px' } });
  info.append(el('h1', { text: channel.name }));
  info.append(el('div', { class: 'muted', text: `@${channel.handle || 'channel'} • ${fmtViews(channel.subscribers)} مشترك • ${videos.length} فيديو` }));
  if (channel.description) info.append(el('p', { class: 'muted', style: { margin: '8px 0 0', fontSize: '14px' }, text: channel.description }));
  head.append(info);

  if (isLoggedIn() && channel.user_id !== store.user?.id) {
    const btn = el('button', { class: `btn${subscribed ? '' : ' accent'}`, text: subscribed ? 'مشترك ✓' : 'اشتراك' });
    btn.onclick = async () => {
      try {
        const r = await API.subscribe(channel.id);
        btn.textContent = r.subscribed ? 'مشترك ✓' : 'اشتراك';
        btn.classList.toggle('accent', !r.subscribed);
        toast(r.subscribed ? 'تم الاشتراك' : 'تم إلغاء الاشتراك', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    };
    head.append(btn);
  }

  const tabs = el('div', { class: 'tabs' });
  const tVideos = el('button', { class: 'tab active', text: 'الفيديوهات' });
  const tAbout = el('button', { class: 'tab', text: 'نبذة' });
  tabs.append(tVideos, tAbout);
  container.append(tabs);

  gridBox.innerHTML = '';
  gridBox.append(videoGrid(videos));

  tAbout.onclick = () => {
    tAbout.classList.add('active'); tVideos.classList.remove('active');
    gridBox.innerHTML = '';
    const box = el('div', { class: 'panel' });
    box.append(el('h3', { text: 'عن القناة' }));
    box.append(el('p', { text: channel.description || 'لا يوجد وصف للقناة بعد.' }));
    box.append(el('p', { class: 'muted small', text: `تاريخ الانضمام: ${String(channel.created_at || '').slice(0, 10)}` }));
    if (channel.links) box.append(el('p', { class: 'muted small', text: `الروابط: ${channel.links}` }));
    gridBox.append(box);
  };
  tVideos.onclick = () => {
    tVideos.classList.add('active'); tAbout.classList.remove('active');
    gridBox.innerHTML = '';
    gridBox.append(videoGrid(videos));
  };
}
