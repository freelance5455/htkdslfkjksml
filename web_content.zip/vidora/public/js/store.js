/* حالة التطبيق المشتركة */
import { API, setToken, hasToken } from './api.js';

export const store = {
  config: null,
  user: null,
  channel: null,
  categories: [],
  subscriptions: [],
};

export async function loadConfig() {
  try {
    store.config = await API.config();
    if (store.config.siteName) {
      document.getElementById('siteName').textContent = store.config.siteName;
      document.title = `${store.config.siteName} — ${store.config.siteTagline || ''}`.trim();
    }
    store.capabilities = store.config.capabilities || {};
  } catch (err) {
    store.config = { siteName: 'Vidora', siteTagline: 'منصة الفيديو المفتوحة', capabilities: {}, offline: true };
    store.capabilities = {};
  }
  return store.config;
}

export async function loadSession() {
  if (!hasToken()) {
    store.user = null; store.channel = null;
    return null;
  }
  try {
    const data = await API.me();
    store.user = data.user;
    store.channel = data.channel;
  } catch {
    setToken(null);
    store.user = null; store.channel = null;
  }
  return store.user;
}

export async function loadCategories() {
  try {
    const data = await API.categories();
    store.categories = data.items || [];
  } catch {
    store.categories = ['الكل'].map((name) => ({ name, count: 0 }));
  }
  return store.categories;
}

export async function loadSubscriptions() {
  if (!hasToken()) { store.subscriptions = []; return []; }
  try {
    const data = await API.subscriptions();
    store.subscriptions = data.channels || [];
  } catch {
    store.subscriptions = [];
  }
  return store.subscriptions;
}

export function isLoggedIn() { return Boolean(store.user); }
export function isAdmin() { return store.user?.role === 'admin'; }
