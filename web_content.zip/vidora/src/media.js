'use strict';
/**
 * محرّك الوسائط: استخراج البيانات، توليد الصور المصغّرة، وتحويل الفيديو
 * إلى صيغة MP4 (H.264/AAC) متوافقة مع كل المتصفحات مع إعادة ترتيب
 * البايتات (faststart) كي يبدأ البث فوراً.
 */
const { spawn, execFile } = require('child_process');
const fs = require('fs');
const path = require('path');
const { THUMBS_DIR } = require('./db');

const FFMPEG = process.env.FFMPEG_PATH || 'ffmpeg';
const FFPROBE = process.env.FFPROBE_PATH || 'ffprobe';

function hasFfmpeg() {
  try {
    require('fs').accessSync('/usr/bin/ffmpeg', fs.constants.X_OK);
    return true;
  } catch {
    try {
      require('child_process').execFileSync('which', ['ffmpeg'], { stdio: 'ignore' });
      return true;
    } catch {
      return false;
    }
  }
}

function run(cmd, args, { timeout = 0, onStdout, onStderr } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '';
    let err = '';
    let timer = null;
    if (timeout > 0) {
      timer = setTimeout(() => {
        try { child.kill('SIGKILL'); } catch { /* ignore */ }
        reject(new Error('انتهت المهلة'));
      }, timeout);
    }
    child.stdout.on('data', (d) => {
      const s = d.toString();
      out += s;
      if (onStdout) onStdout(s);
    });
    child.stderr.on('data', (d) => {
      const s = d.toString();
      err += s;
      if (onStderr) onStderr(s);
    });
    child.on('error', (e) => { if (timer) clearTimeout(timer); reject(e); });
    child.on('close', (code) => {
      if (timer) clearTimeout(timer);
      if (code === 0) resolve({ out, err });
      else reject(Object.assign(new Error(err.trim().split('\n').slice(-6).join('\n') || `خروج بالرمز ${code}`), { code, stderr: err }));
    });
  });
}

/** قراءة أبعاد الفيديو ومدته باستخدام ffprobe */
async function probe(file) {
  try {
    const { out } = await run(FFPROBE, [
      '-v', 'error', '-print_format', 'json',
      '-show_format', '-show_streams', file,
    ], { timeout: 120000 });
    const data = JSON.parse(out);
    const video = (data.streams || []).find((s) => s.codec_type === 'video');
    const audio = (data.streams || []).find((s) => s.codec_type === 'audio');
    const duration = Number(data.format?.duration || video?.duration || 0);
    const width = Number(video?.width || 0);
    const height = Number(video?.height || 0);
    return {
      duration: Number.isFinite(duration) ? duration : 0,
      width,
      height,
      codec: video?.codec_name || '',
      vcodec: video?.codec_name || '',
      acodec: audio?.codec_name || '',
      hasAudio: Boolean(audio),
      bitrate: Number(data.format?.bit_rate || 0),
      size: Number(data.format?.size || 0),
    };
  } catch {
    return { duration: 0, width: 0, height: 0, codec: '', hasAudio: false, bitrate: 0, size: 0 };
  }
}

/** توليد صورة مصغّرة عند ثانية محددة (افتراضياً 25% من المدة) */
async function thumbnail(videoFile, outName, atSeconds) {
  const out = path.join(THUMBS_DIR, outName);
  let t = Number(atSeconds);
  if (!t || t < 0) {
    const info = await probe(videoFile);
    t = Math.max(1, Math.round((info.duration || 10) * 0.25));
  }
  try {
    await run(FFMPEG, [
      '-y', '-ss', String(t), '-i', videoFile,
      '-frames:v', '1', '-q:v', '4', '-vf', 'scale=640:-2',
      out,
    ], { timeout: 180000 });
    return out;
  } catch {
    try {
      await run(FFMPEG, ['-y', '-i', videoFile, '-frames:v', '1', '-q:v', '4', '-vf', 'scale=640:-2', out], { timeout: 180000 });
      return out;
    } catch {
      return null;
    }
  }
}

/** توليد صورة غلاف (poster) بدقة أعلى */
async function poster(videoFile, outName) {
  const out = path.join(THUMBS_DIR, outName);
  try {
    await run(FFMPEG, [
      '-y', '-ss', '1', '-i', videoFile,
      '-frames:v', '1', '-q:v', '3', '-vf', 'scale=1280:-2',
      out,
    ], { timeout: 180000 });
    return out;
  } catch {
    return null;
  }
}

/**
 * تحويل الفيديو إلى MP4 متوافق.
 * - إذا كان المصدر H.264/M4A => إعادة تعبئة فقط (سريعة بدون فقدان جودة)
 * - غير ذلك => ترميز H.264/AAC مع faststart
 */
async function toWebMp4(input, output, { maxHeight = 1080, onProgress } = {}) {
  const info = await probe(input);
  const isWebReady =
    /^(h264|avc1)$/i.test(info.vcodec || '') && /^(aac|mp4a)$/i.test(info.acodec || '');

  if (isWebReady && (info.height || 0) <= maxHeight + 1) {
    await run(FFMPEG, [
      '-y', '-i', input,
      '-c', 'copy', '-movflags', '+faststart',
      output,
    ], { timeout: 3600000 });
    return { mode: 'remux', ...info };
  }

  const vf = (info.height || 0) > maxHeight
    ? `scale=-2:'min(${maxHeight},iw)':force_original_aspect_ratio=decrease`
    : null;

  const args = ['-y', '-i', input];
  if (vf) args.push('-vf', vf);
  args.push(
    '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23',
    '-pix_fmt', 'yuv420p', '-profile:v', 'high', '-level', '4.1',
    '-c:a', 'aac', '-b:a', '128k', '-ac', '2',
    '-movflags', '+faststart', '-f', 'mp4',
    output
  );

  await run(FFMPEG, args, {
    timeout: 7200000,
    onStderr: (chunk) => {
      if (!onProgress) return;
      const m = chunk.match(/time=(\d+):(\d+):(\d+)/);
      if (m && info.duration > 0) {
        const secs = Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]);
        onProgress(Math.min(99, (secs / info.duration) * 100));
      }
    },
  });
  return { mode: 'transcode', ...info };
}

/**
 * نسخة WebM (VP9/Opus) كبديل — تعمل على المتصفحات التي لا تدعم H.264
 * (مثل نسخ Chromium مفتوحة المصدر وبعض توزيعات لينكس).
 */
async function toWebWebm(input, output, { maxHeight = 720 } = {}) {
  const info = await probe(input);
  const vf = (info.height || 0) > maxHeight
    ? `scale=-2:'min(${maxHeight},iw)':force_original_aspect_ratio=decrease`
    : null;
  const args = ['-y', '-i', input];
  if (vf) args.push('-vf', vf);
  args.push(
    '-c:v', 'libvpx-vp9', '-deadline', 'realtime', '-cpu-used', '8',
    '-row-mt', '1', '-b:v', '0', '-crf', '38',
    '-c:a', 'libopus', '-b:a', '96k', '-ac', '2',
    '-f', 'webm', output
  );
  await run(FFMPEG, args, { timeout: 7200000 });
  return output;
}

/** استخراج الصوت (اختياري) */
async function extractAudio(input, output) {
  await run(FFMPEG, ['-y', '-i', input, '-vn', '-c:a', 'libmp3lame', '-q:a', '3', output], { timeout: 3600000 });
  return output;
}

module.exports = { hasFfmpeg, probe, thumbnail, poster, toWebMp4, toWebWebm, extractAudio, run };
