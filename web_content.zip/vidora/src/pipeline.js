'use strict';
/**
 * خط أنابيب معالجة الفيديو:
 *   تنزيل/رفع  ->  تحويل إلى MP4  ->  توليد مصغّرة وغلاف  ->  ترجمة  ->  نشر
 * يعمل كطابور داخل العملية مع متابعة لحظية عبر جدول jobs.
 */
const fs = require('fs');
const path = require('path');
const { db, VIDEOS_DIR, THUMBS_DIR, TMP_DIR, SUBS_DIR } = require('./db');
const media = require('./media');
const ytdlp = require('./ytdlp');

const MAX_CONCURRENT = 2;
let running = 0;
const queue = [];
const listeners = new Set();

function emit(event) {
  for (const fn of listeners) {
    try { fn(event); } catch { /* ignore */ }
  }
}

function onJobEvent(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

function updateJob(id, patch) {
  const fields = [];
  const params = [];
  for (const [k, v] of Object.entries(patch)) {
    fields.push(`${k} = ?`);
    params.push(v);
  }
  fields.push("updated_at = datetime('now')");
  params.push(id);
  db.prepare(`UPDATE jobs SET ${fields.join(', ')} WHERE id = ?`).run(...params);
  const job = db.prepare('SELECT * FROM jobs WHERE id = ?').get(id);
  emit({ type: 'job', job });
  return job;
}

function getJob(id) {
  return db.prepare('SELECT * FROM jobs WHERE id = ?').get(id);
}

/* ------------------------------ الاستيراد ------------------------------ */
async function importFromUrl({ url, userId, channelId, title, description, category, tags, quality }) {
  const jobId = db
    .prepare("INSERT INTO jobs (user_id, type, url, title, status, progress, message) VALUES (?, 'import', ?, ?, 'queued', 0, 'في الانتظار')")
    .run(userId || null, url, title || url).lastInsertRowid;

  enqueue(async () => {
    const workDir = path.join(TMP_DIR, `job_${jobId}`);
    fs.mkdirSync(workDir, { recursive: true });
    let videoId = null;
    try {
      updateJob(jobId, { status: 'running', progress: 1, message: 'جاري التحضير…' });

      // 1) جلب البيانات الوصفية (اختياري)
      let info = null;
      try {
        info = await ytdlp.getInfo(url);
        updateJob(jobId, { progress: 2, title: info.title || title || url, message: 'تم قراءة بيانات الفيديو' });
      } catch {
        updateJob(jobId, { progress: 2, message: 'تعذّرت قراءة البيانات الوصفية — سيستمر التنزيل' });
      }

      // 2) التنزيل
      const dl = await ytdlp.download(url, {
        outDir: workDir,
        quality: quality || 'best',
        onProgress: (p, stage) => updateJob(jobId, { progress: Math.max(2, p), message: stage || 'جاري التنزيل' }),
      });

      // 3) إنشاء سجل الفيديو بحالة "processing"
      const channel = resolveChannel(channelId, userId);
      const finalTitle = (title && title.trim()) || info?.title || 'فيديو بدون عنوان';
      const finalDesc = description ?? info?.description ?? '';
      const finalTags = normalizeTags(tags || (info?.tags || []).join(',') || (info?.categories || []).join(','));
      const finalCategory = category || 'عام';
      const duration = Number(info?.duration) || 0;

      const vid = db
        .prepare(`INSERT INTO videos (channel_id, title, description, tags, category, visibility, duration,
                    source_type, source_url, source_id, status, created_at, published_at)
                  VALUES (?, ?, ?, ?, ?, 'public', ?, 'import', ?, ?, 'processing', datetime('now'), datetime('now'))`)
        .run(channel.id, finalTitle, finalDesc, finalTags, finalCategory, duration, url, info?.id || null);
      videoId = Number(vid.lastInsertRowid);
      updateJob(jobId, { video_id: videoId, progress: 60, message: 'جاري التحويل...' });

      // 4) التحويل إلى MP4 (+ نسخة WebM بديلة)
      const built = await buildVariants(videoId, dl.file);
      const outFile = built.outFile;
      fs.rmSync(dl.file, { force: true });
      updateJob(jobId, { progress: 90, message: 'جاري إنشاء الصور المصغّرة...' });

      // 5) الترجمة (اختياري)
      let subPath = null;
      if (process.env.ENABLE_SUBTITLES !== '0') {
        try {
          const vtt = await ytdlp.downloadSubtitles(url, workDir);
          if (vtt) {
            const dest = path.join(SUBS_DIR, `v_${videoId}.vtt`);
            fs.copyFileSync(vtt, dest);
            subPath = dest;
          }
        } catch { /* الترجمة اختيارية */ }
      }

      // 6) التحديث النهائي
      db.prepare(`UPDATE videos SET
          file_path = ?, webm_path = ?, thumb_path = ?, poster_path = ?, subtitle_path = ?, status = 'ready',
          duration = ?, width = ?, height = ?, size_bytes = ?, quality = ?, error = NULL,
          published_at = datetime('now')
        WHERE id = ?`).run(
        path.basename(outFile),
        built.webmName,
        built.thumb ? path.basename(built.thumb) : null,
        built.posterImg ? path.basename(built.posterImg) : null,
        subPath ? path.basename(subPath) : null,
        built.probed.duration || duration,
        built.probed.width, built.probed.height, built.size,
        built.probed.height >= 1080 ? 'Full HD' : built.probed.height >= 720 ? 'HD' : 'SD',
        videoId
      );

      notifySubscribers(channel.id, videoId, finalTitle);
      updateJob(jobId, { status: 'done', progress: 100, message: 'اكتمل بنجاح', video_id: videoId });      emit({ type: 'imported', videoId });
    } catch (err) {
      const message = ytdlp.translateError(err.message || String(err));
      updateJob(jobId, { status: 'failed', error: message, message: 'فشل' });
      if (videoId) {
        db.prepare("UPDATE videos SET status = 'failed', error = ? WHERE id = ?").run(message, videoId);
      }
    } finally {
      ytdlp.cleanupDir(workDir);
      try { fs.rmdirSync(workDir); } catch { /* ignore */ }
    }
  });

  return jobId;
}

/* ------------------------------- الرفع ------------------------------- */
async function importFromUpload({ tmpPath, originalName, userId, channelId, title, description, category, tags, visibility }) {
  const channel = resolveChannel(channelId, userId);
  const finalTitle = (title && title.trim()) || path.parse(originalName).name;
  const vid = db
    .prepare(`INSERT INTO videos (channel_id, title, description, tags, category, visibility, source_type, source_url, status, created_at, published_at)
              VALUES (?, ?, ?, ?, ?, ?, 'upload', ?, 'processing', datetime('now'), datetime('now'))`)
    .run(channel.id, finalTitle, description || '', normalizeTags(tags), category || 'عام', visibility || 'public', originalName);
  const videoId = Number(vid.lastInsertRowid);

  try {
    const built = await buildVariants(videoId, tmpPath);
    db.prepare(`UPDATE videos SET file_path = ?, webm_path = ?, thumb_path = ?, poster_path = ?, status = 'ready',
        duration = ?, width = ?, height = ?, size_bytes = ?, quality = ?, published_at = datetime('now')
        WHERE id = ?`).run(
      path.basename(built.outFile),
      built.webmName,
      built.thumb ? path.basename(built.thumb) : null,
      built.posterImg ? path.basename(built.posterImg) : null,
      built.probed.duration, built.probed.width, built.probed.height, built.size,
      built.probed.height >= 1080 ? 'Full HD' : built.probed.height >= 720 ? 'HD' : 'SD',
      videoId
    );
    notifySubscribers(channel.id, videoId, finalTitle);
  } catch (err) {
    db.prepare("UPDATE videos SET status = 'failed', error = ? WHERE id = ?").run(err.message || 'فشل التحويل', videoId);
    throw err;
  } finally {
    try { fs.unlinkSync(tmpPath); } catch { /* ignore */ }
  }
  return videoId;
}

/* ------------------------------ مساعدات ------------------------------ */

/** بناء نسخ الفيديو النهائية (MP4 + WebM) والصور وتحديث السجل */
async function buildVariants(videoId, sourceFile) {
  const outFile = path.join(VIDEOS_DIR, `v_${videoId}.mp4`);
  await media.toWebMp4(sourceFile, outFile, { maxHeight: 1080 });

  let webmPath = null;
  if (process.env.ENABLE_WEBM !== '0') {
    const webmFile = path.join(VIDEOS_DIR, `v_${videoId}.webm`);
    try {
      await media.toWebWebm(outFile, webmFile, { maxHeight: 1080 });
      if (fs.existsSync(webmFile) && fs.statSync(webmFile).size > 1024) webmPath = webmFile;
    } catch (err) {
      console.warn('[vidora] تعذّر إنتاج نسخة WebM:', err.message);
    }
  }

  const thumb = await media.thumbnail(outFile, `t_${videoId}.jpg`);
  const posterImg = await media.poster(outFile, `p_${videoId}.jpg`);
  const probed = await media.probe(outFile);
  const size = fs.existsSync(outFile) ? fs.statSync(outFile).size : 0;

  return {
    outFile, webmPath, thumb, posterImg, probed, size,
    webmName: webmPath ? path.basename(webmPath) : null,
  };
}

function resolveChannel(channelId, userId) {
  if (channelId) {
    const ch = db.prepare('SELECT * FROM channels WHERE id = ?').get(channelId);
    if (ch) return ch;
  }
  if (userId) {
    const ch = db.prepare('SELECT * FROM channels WHERE user_id = ? ORDER BY id LIMIT 1').get(userId);
    if (ch) return ch;
  }
  const any = db.prepare('SELECT * FROM channels ORDER BY id LIMIT 1').get();
  if (any) return any;
  const info = db.prepare('INSERT INTO channels (user_id, name, handle) VALUES (NULL, ?, ?)').run('Vidora Official', 'vidora');
  return db.prepare('SELECT * FROM channels WHERE id = ?').get(info.lastInsertRowid);
}

function normalizeTags(tags) {
  if (Array.isArray(tags)) return tags.map((t) => String(t).trim()).filter(Boolean).slice(0, 20).join(',');
  return String(tags || '').split(',').map((t) => t.trim()).filter(Boolean).slice(0, 20).join(',');
}

function notifySubscribers(channelId, videoId, title) {
  const subs = db.prepare('SELECT user_id FROM subscriptions WHERE channel_id = ?').all(channelId);
  const stmt = db.prepare("INSERT INTO notifications (user_id, type, payload) VALUES (?, 'video', ?)");
  for (const s of subs) {
    stmt.run(s.user_id, JSON.stringify({ videoId, channelId, title }));
  }
}

/* ------------------------------ الطابور ------------------------------ */
function enqueue(task) {
  queue.push(task);
  pump();
}

function pump() {
  while (running < MAX_CONCURRENT && queue.length > 0) {
    const task = queue.shift();
    running += 1;
    Promise.resolve()
      .then(task)
      .catch(() => { /* تُعالَج داخل المهمة */ })
      .finally(() => {
        running -= 1;
        pump();
      });
  }
}

/** إعادة تشغيل المهام التي كانت قيد التنفيذ قبل إعادة تشغيل الخادم */
function resumeInterruptedJobs() {
  const stuck = db.prepare("SELECT id, url FROM jobs WHERE status IN ('queued','running')").all();
  for (const j of stuck) {
    db.prepare("UPDATE jobs SET status = 'failed', error = 'توقف بسبب إعادة تشغيل الخادم', updated_at = datetime('now') WHERE id = ?").run(j.id);
  }
  return stuck.length;
}

module.exports = {
  importFromUrl, importFromUpload, resolveChannel, normalizeTags,
  getJob, updateJob, onJobEvent, resumeInterruptedJobs, queueSize: () => queue.length,
};
