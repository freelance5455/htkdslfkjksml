'use strict';
/** القنوات، الاشتراكات، المكتبة الشخصية، قوائم التشغيل، الإشعارات */
const express = require('express');
const { db, getVideo, queryVideos } = require('../db');
const { requireAuth, userFromRequest } = require('../auth');

const router = express.Router();

/* ------------------------------- القنوات ------------------------------- */
router.get('/channels/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const channel = db.prepare(`
    SELECT c.*, u.name AS owner_name, u.color AS owner_color
    FROM channels c LEFT JOIN users u ON u.id = c.user_id WHERE c.id = ?`).get(id);
  if (!channel) return res.status(404).json({ error: 'القناة غير موجودة' });
  const user = userFromRequest(req);
  let subscribed = false;
  if (user) {
    subscribed = Boolean(db.prepare('SELECT 1 FROM subscriptions WHERE channel_id = ? AND user_id = ?').get(id, user.id));
  }
  const videos = queryVideos({ channelId: id, limit: 60 }).items;
  res.json({ channel, videos, subscribed });
});

router.patch('/channels/:id', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(id);
  if (!channel) return res.status(404).json({ error: 'القناة غير موجودة' });
  if (channel.user_id !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'غير مصرّح' });
  const { name, description, banner, avatar, links } = req.body || {};
  const fields = []; const params = [];
  if (name) { fields.push('name = ?'); params.push(String(name).slice(0, 80)); }
  if (description !== undefined) { fields.push('description = ?'); params.push(String(description)); }
  if (banner !== undefined) { fields.push('banner = ?'); params.push(String(banner)); }
  if (avatar !== undefined) { fields.push('avatar = ?'); params.push(String(avatar)); }
  if (links !== undefined) { fields.push('links = ?'); params.push(String(links)); }
  if (!fields.length) return res.json({ channel });
  params.push(id);
  db.prepare(`UPDATE channels SET ${fields.join(', ')} WHERE id = ?`).run(...params);
  res.json({ channel: db.prepare('SELECT * FROM channels WHERE id = ?').get(id) });
});

router.post('/channels/:id/subscribe', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const userId = req.user.id;
  const exists = db.prepare('SELECT 1 FROM subscriptions WHERE channel_id = ? AND user_id = ?').get(id, userId);
  if (exists) {
    db.prepare('DELETE FROM subscriptions WHERE channel_id = ? AND user_id = ?').run(id, userId);
    db.prepare('UPDATE channels SET subscribers = MAX(0, subscribers - 1) WHERE id = ?').run(id);
    return res.json({ subscribed: false, subscribers: db.prepare('SELECT subscribers FROM channels WHERE id = ?').get(id)?.subscribers || 0 });
  }
  db.prepare('INSERT INTO subscriptions (channel_id, user_id) VALUES (?, ?)').run(id, userId);
  db.prepare('UPDATE channels SET subscribers = subscribers + 1 WHERE id = ?').run(id);
  res.json({ subscribed: true, subscribers: db.prepare('SELECT subscribers FROM channels WHERE id = ?').get(id)?.subscribers || 0 });
});

router.get('/channels/:id/videos', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const result = queryVideos({ channelId: id, limit: Math.min(60, parseInt(req.query.limit, 10) || 24) });
  res.json(result);
});

/* ------------------------------ الاشتراكات ------------------------------ */
router.get('/subscriptions', requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT c.* FROM channels c JOIN subscriptions s ON s.channel_id = c.id
    WHERE s.user_id = ? ORDER BY s.created_at DESC`).all(req.user.id);
  const videos = db.prepare(`
    SELECT v.* FROM videos v JOIN subscriptions s ON s.channel_id = v.channel_id
    WHERE s.user_id = ? AND v.status='ready' AND v.visibility='public'
    ORDER BY v.published_at DESC LIMIT 50`).all(req.user.id).map(getVideo);
  res.json({ channels: rows, videos });
});

/* -------------------------------- المكتبة -------------------------------- */
router.get('/library/history', requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT v.*, h.progress, h.watched_at FROM history h JOIN videos v ON v.id = h.video_id
    WHERE h.user_id = ? ORDER BY h.watched_at DESC LIMIT 100`).all(req.user.id).map(getVideo);
  res.json({ items: rows });
});

router.get('/library/watch-later', requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT v.*, w.created_at FROM watch_later w JOIN videos v ON v.id = w.video_id
    WHERE w.user_id = ? ORDER BY w.created_at DESC LIMIT 100`).all(req.user.id).map(getVideo);
  res.json({ items: rows });
});

router.get('/library/liked', requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT v.* FROM videos v JOIN reactions r ON r.video_id = v.id
    WHERE r.user_id = ? AND r.value = 1 ORDER BY r.created_at DESC LIMIT 100`).all(req.user.id).map(getVideo);
  res.json({ items: rows });
});

/* ---------------------------- قوائم التشغيل ---------------------------- */
router.get('/playlists', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT * FROM playlists WHERE user_id = ? ORDER BY created_at DESC').all(req.user.id);
  const withCounts = rows.map((p) => ({
    ...p,
    count: db.prepare('SELECT COUNT(*) AS n FROM playlist_items WHERE playlist_id = ?').get(p.id).n,
  }));
  res.json({ items: withCounts });
});

router.post('/playlists', requireAuth, (req, res) => {
  const name = String(req.body?.name || '').trim();
  if (!name) return res.status(400).json({ error: 'اسم القائمة مطلوب' });
  const info = db.prepare('INSERT INTO playlists (user_id, name, description, privacy) VALUES (?, ?, ?, ?)')
    .run(req.user.id, name, String(req.body?.description || ''), req.body?.privacy || 'public');
  res.json({ playlist: db.prepare('SELECT * FROM playlists WHERE id = ?').get(info.lastInsertRowid) });
});

router.get('/playlists/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const playlist = db.prepare('SELECT * FROM playlists WHERE id = ?').get(id);
  if (!playlist) return res.status(404).json({ error: 'القائمة غير موجودة' });
  const items = db.prepare(`
    SELECT v.*, pi.position FROM playlist_items pi JOIN videos v ON v.id = pi.video_id
    WHERE pi.playlist_id = ? ORDER BY pi.position ASC`).all(id).map(getVideo);
  res.json({ playlist, items });
});

router.post('/playlists/:id/items', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const playlist = db.prepare('SELECT * FROM playlists WHERE id = ?').get(id);
  if (!playlist) return res.status(404).json({ error: 'القائمة غير موجودة' });
  if (playlist.user_id !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'غير مصرّح' });
  const videoId = parseInt(req.body?.videoId, 10);
  const pos = db.prepare('SELECT COALESCE(MAX(position), -1) + 1 AS p FROM playlist_items WHERE playlist_id = ?').get(id).p;
  db.prepare('INSERT OR IGNORE INTO playlist_items (playlist_id, video_id, position) VALUES (?, ?, ?)').run(id, videoId, pos);
  res.json({ ok: true });
});

router.delete('/playlists/:id/items/:videoId', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const playlist = db.prepare('SELECT * FROM playlists WHERE id = ?').get(id);
  if (!playlist) return res.status(404).json({ error: 'القائمة غير موجودة' });
  if (playlist.user_id !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'غير مصرّح' });
  db.prepare('DELETE FROM playlist_items WHERE playlist_id = ? AND video_id = ?').run(id, parseInt(req.params.videoId, 10));
  res.json({ ok: true });
});

router.delete('/playlists/:id', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const playlist = db.prepare('SELECT * FROM playlists WHERE id = ?').get(id);
  if (!playlist) return res.status(404).json({ error: 'القائمة غير موجودة' });
  if (playlist.user_id !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'غير مصرّح' });
  db.prepare('DELETE FROM playlists WHERE id = ?').run(id);
  res.json({ ok: true });
});

/* ------------------------------ الإشعارات ------------------------------ */
router.get('/notifications', requireAuth, (req, res) => {
  const items = db.prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 50').all(req.user.id)
    .map((n) => ({ ...n, payload: JSON.parse(n.payload || '{}') }));
  const unread = db.prepare('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND is_read = 0').get(req.user.id).n;
  res.json({ items, unread });
});

router.post('/notifications/read', requireAuth, (req, res) => {
  db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(req.user.id);
  res.json({ ok: true });
});

module.exports = router;
