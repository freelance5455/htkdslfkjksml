'use strict';
/** مسارات الفيديوهات: التصفح، البحث، الرفع، الاستيراد، التفاعلات */
const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const { db, queryVideos, getVideo, TMP_DIR } = require('../db');
const { requireAuth, userFromRequest } = require('../auth');
const pipeline = require('../pipeline');
const ytdlp = require('../ytdlp');

const router = express.Router();
const MAX_MB = Number(process.env.MAX_UPLOAD_MB || 2048);

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      fs.mkdirSync(TMP_DIR, { recursive: true });
      cb(null, TMP_DIR);
    },
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname || '.bin').toLowerCase() || '.bin';
      cb(null, `up_${Date.now()}_${Math.random().toString(36).slice(2, 8)}${ext}`);
    },
  }),
  limits: { fileSize: MAX_MB * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = /^video\//.test(file.mimetype) || /\.(mp4|mkv|webm|mov|m4v|avi|flv|ts)$/i.test(file.originalname);
    cb(null, ok);
  },
});

/* ------------------------------ التصفح ------------------------------ */
router.get('/videos', (req, res) => {
  const page = Math.max(1, parseInt(req.query.page, 10) || 1);
  const limit = Math.min(60, Math.max(1, parseInt(req.query.limit, 10) || 24));
  const result = queryVideos({
    q: req.query.q || '',
    category: req.query.category || '',
    sort: req.query.sort || 'recent',
    duration: req.query.duration || '',
    channelId: req.query.channelId ? parseInt(req.query.channelId, 10) : null,
    source: req.query.source || '',
    limit,
    offset: (page - 1) * limit,
  });
  res.json({ ...result, page, limit, hasMore: page * limit < result.total });
});

router.get('/videos/:id', (req, res) => {
  const video = getVideo(parseInt(req.params.id, 10));
  if (!video) return res.status(404).json({ error: 'الفيديو غير موجود' });
  const user = userFromRequest(req);
  let reaction = 0;
  let inWatchLater = false;
  if (user) {
    const r = db.prepare('SELECT value FROM reactions WHERE user_id = ? AND video_id = ?').get(user.id, video.id);
    reaction = r ? r.value : 0;
    inWatchLater = Boolean(db.prepare('SELECT 1 FROM watch_later WHERE user_id = ? AND video_id = ?').get(user.id, video.id));
  }
  res.json({ video, reaction, inWatchLater });
});

router.get('/videos/:id/similar', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const video = getVideo(id);
  if (!video) return res.status(404).json({ error: 'الفيديو غير موجود' });
  const sameCat = queryVideos({ category: video.category, limit: 16 }).items.filter((v) => v.id !== id);
  const items = [...sameCat];
  if (items.length < 8) {
    const recent = queryVideos({ sort: 'trending', limit: 20 }).items.filter((v) => v.id !== id && !items.some((x) => x.id === v.id));
    items.push(...recent);
  }
  res.json({ items: items.slice(0, 14) });
});

/* --------------------------- التعديل والحذف --------------------------- */
router.patch('/videos/:id', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const video = getVideo(id);
  if (!video) return res.status(404).json({ error: 'الفيديو غير موجود' });
  const isOwner = video.channel_user_id === req.user.id;
  if (!isOwner && req.user.role !== 'admin') return res.status(403).json({ error: 'غير مصرّح لك' });

  const { title, description, tags, category, visibility } = req.body || {};
  const fields = [];
  const params = [];
  if (title !== undefined) { fields.push('title = ?'); params.push(String(title).slice(0, 200)); }
  if (description !== undefined) { fields.push('description = ?'); params.push(String(description)); }
  if (tags !== undefined) { fields.push('tags = ?'); params.push(pipeline.normalizeTags(tags)); }
  if (category !== undefined) { fields.push('category = ?'); params.push(String(category)); }
  if (visibility !== undefined && ['public', 'unlisted', 'private'].includes(visibility)) {
    fields.push('visibility = ?'); params.push(visibility);
  }
  if (!fields.length) return res.json({ video });
  params.push(id);
  db.prepare(`UPDATE videos SET ${fields.join(', ')} WHERE id = ?`).run(...params);
  res.json({ video: getVideo(id) });
});

router.delete('/videos/:id', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const video = getVideo(id);
  if (!video) return res.status(404).json({ error: 'الفيديو غير موجود' });
  const isOwner = video.channel_user_id === req.user.id;
  if (!isOwner && req.user.role !== 'admin') return res.status(403).json({ error: 'غير مصرّح لك' });
  cleanupVideoFiles(video);
  db.prepare('DELETE FROM videos WHERE id = ?').run(id);
  res.json({ ok: true });
});

function cleanupVideoFiles(video) {
  const { VIDEOS_DIR, THUMBS_DIR, SUBS_DIR } = require('../db');
  const targets = [
    video.file_path && path.join(VIDEOS_DIR, video.file_path),
    video.webm_path && path.join(VIDEOS_DIR, video.webm_path),
    video.thumb_path && path.join(THUMBS_DIR, video.thumb_path),
    video.poster_path && path.join(THUMBS_DIR, video.poster_path),
    video.subtitle_path && path.join(SUBS_DIR, video.subtitle_path),
  ].filter(Boolean);
  for (const f of targets) { try { fs.unlinkSync(f); } catch { /* ignore */ } }
}

/* ----------------------------- التفاعلات ----------------------------- */
router.post('/videos/:id/view', (req, res) => {
  const id = parseInt(req.params.id, 10);
  db.prepare('UPDATE videos SET views = views + 1 WHERE id = ?').run(id);
  const row = db.prepare('SELECT views FROM videos WHERE id = ?').get(id);
  res.json({ views: row ? row.views : 0 });
});

router.post('/videos/:id/reaction', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const value = Number(req.body?.value);
  if (![1, -1, 0].includes(value)) return res.status(400).json({ error: 'قيمة غير صالحة' });
  const userId = req.user.id;
  const existing = db.prepare('SELECT value FROM reactions WHERE user_id = ? AND video_id = ?').get(userId, id);
  const old = existing ? existing.value : 0;
  if (old === value) {
    db.prepare('DELETE FROM reactions WHERE user_id = ? AND video_id = ?').run(userId, id);
  } else if (value === 0) {
    db.prepare('DELETE FROM reactions WHERE user_id = ? AND video_id = ?').run(userId, id);
  } else {
    db.prepare(`INSERT INTO reactions (user_id, video_id, value) VALUES (?, ?, ?)
                ON CONFLICT(user_id, video_id) DO UPDATE SET value = excluded.value`).run(userId, id, value);
  }
  const now = db.prepare('SELECT likes, dislikes FROM videos WHERE id = ?').get(id) || { likes: 0, dislikes: 0 };
  const likes = Math.max(0, now.likes - (old === 1 ? 1 : 0) + (value === 1 && old !== 1 ? 1 : 0));
  const dislikes = Math.max(0, now.dislikes - (old === -1 ? 1 : 0) + (value === -1 && old !== -1 ? 1 : 0));
  db.prepare('UPDATE videos SET likes = ?, dislikes = ? WHERE id = ?').run(likes, dislikes, id);
  res.json({ likes, dislikes, reaction: old === value ? 0 : value });
});

router.post('/videos/:id/watch-later', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const userId = req.user.id;
  const exists = db.prepare('SELECT 1 FROM watch_later WHERE user_id = ? AND video_id = ?').get(userId, id);
  if (exists) {
    db.prepare('DELETE FROM watch_later WHERE user_id = ? AND video_id = ?').run(userId, id);
    return res.json({ inWatchLater: false });
  }
  db.prepare('INSERT INTO watch_later (user_id, video_id) VALUES (?, ?)').run(userId, id);
  res.json({ inWatchLater: true });
});

router.post('/videos/:id/progress', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const progress = Number(req.body?.progress) || 0;
  db.prepare(`INSERT INTO history (user_id, video_id, progress, watched_at) VALUES (?, ?, ?, datetime('now'))
              ON CONFLICT(user_id, video_id) DO UPDATE SET progress = excluded.progress, watched_at = datetime('now')`)
    .run(req.user.id, id, progress);
  res.json({ ok: true });
});

/* ----------------------------- التعليقات ----------------------------- */
router.get('/videos/:id/comments', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const limit = Math.min(100, parseInt(req.query.limit, 10) || 30);
  const items = db.prepare(`
    SELECT c.*, u.name AS user_name, u.color AS user_color
    FROM comments c LEFT JOIN users u ON u.id = c.user_id
    WHERE c.video_id = ? ORDER BY c.created_at DESC LIMIT ?`).all(id, limit);
  res.json({ items });
});

router.post('/videos/:id/comments', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const text = String(req.body?.text || '').trim().slice(0, 2000);
  if (!text) return res.status(400).json({ error: 'التعليق فارغ' });
  const info = db.prepare(`
    INSERT INTO comments (video_id, user_id, author, text) VALUES (?, ?, ?, ?)`)
    .run(id, req.user.id, req.user.name, text);
  const item = db.prepare(`
    SELECT c.*, u.name AS user_name, u.color AS user_color
    FROM comments c LEFT JOIN users u ON u.id = c.user_id WHERE c.id = ?`).get(info.lastInsertRowid);
  res.json({ comment: item });
});

router.delete('/comments/:id', requireAuth, (req, res) => {
  const row = db.prepare('SELECT * FROM comments WHERE id = ?').get(parseInt(req.params.id, 10));
  if (!row) return res.status(404).json({ error: 'التعليق غير موجود' });
  if (row.user_id !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'غير مصرّح' });
  db.prepare('DELETE FROM comments WHERE id = ?').run(row.id);
  res.json({ ok: true });
});

/* ------------------------------ الرفع ------------------------------ */
router.post('/videos/upload', requireAuth, (req, res, next) => {
  upload.single('video')(req, res, (err) => {
    if (err) {
      const msg = err.code === 'LIMIT_FILE_SIZE'
        ? `حجم الملف يتجاوز الحد المسموح (${MAX_MB} ميجابايت)`
        : 'فشل رفع الملف';
      return res.status(400).json({ error: msg });
    }
    next();
  });
}, async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'لم يتم إرفاق ملف فيديو' });
  try {
    const videoId = await pipeline.importFromUpload({
      tmpPath: req.file.path,
      originalName: req.file.originalname,
      userId: req.user.id,
      channelId: req.body.channelId ? parseInt(req.body.channelId, 10) : null,
      title: req.body.title,
      description: req.body.description,
      category: req.body.category,
      tags: req.body.tags,
      visibility: req.body.visibility,
    });
    res.json({ video: getVideo(videoId) });
  } catch (err) {
    res.status(500).json({ error: `فشل معالجة الفيديو: ${err.message}` });
  }
});

/* --------------------------- الاستيراد من رابط --------------------------- */
router.post('/videos/import', requireAuth, async (req, res) => {
  const { url, title, description, category, tags, channelId, quality } = req.body || {};
  if (!url || !/^https?:\/\//i.test(String(url))) {
    return res.status(400).json({ error: 'أدخل رابطاً صحيحاً يبدأ بـ http أو https' });
  }
  if (!ytdlp.ytdlpAvailable()) {
    return res.status(503).json({ error: 'أداة yt-dlp غير مثبّتة. شغّل install.sh لتثبيتها.' });
  }
  const jobId = await pipeline.importFromUrl({
    url: String(url).trim(),
    userId: req.user.id,
    channelId: channelId ? parseInt(channelId, 10) : null,
    title, description, category, tags, quality,
  });
  res.json({ jobId, job: pipeline.getJob(jobId) });
});

router.get('/jobs', requireAuth, (req, res) => {
  const items = req.user.role === 'admin'
    ? db.prepare('SELECT * FROM jobs ORDER BY id DESC LIMIT 100').all()
    : db.prepare('SELECT * FROM jobs WHERE user_id = ? ORDER BY id DESC LIMIT 50').all(req.user.id);
  res.json({ items });
});

router.get('/jobs/:id', (req, res) => {
  const job = pipeline.getJob(parseInt(req.params.id, 10));
  if (!job) return res.status(404).json({ error: 'المهمة غير موجودة' });
  res.json({ job });
});

/* ------------------------------ التصنيفات ------------------------------ */
router.get('/categories', (req, res) => {
  const rows = db.prepare("SELECT category, COUNT(*) AS n FROM videos WHERE status='ready' GROUP BY category ORDER BY n DESC").all();
  const fixed = ['الكل', 'موسيقى', 'ألعاب', 'تعليم', 'أخبار', 'ترفيه', 'رياضة', 'تكنولوجيا', 'طبخ', 'سيارات', 'عام'];
  res.json({ items: fixed.map((c) => ({ name: c, count: c === 'الكل' ? rows.reduce((a, b) => a + b.n, 0) : (rows.find((r) => r.category === c)?.n || 0) })) });
});

/** اقتراحات البحث السريعة */
router.get('/search/suggest', (req, res) => {
  const q = String(req.query.q || '').trim();
  if (!q) return res.json({ items: [] });
  const like = `%${q}%`;
  const items = db.prepare(`
    SELECT DISTINCT title AS text FROM videos WHERE status='ready' AND title LIKE ? LIMIT 8`).all(like);
  const tags = db.prepare(`
    SELECT DISTINCT tags FROM videos WHERE status='ready' AND tags LIKE ? LIMIT 5`).all(like)
    .flatMap((r) => String(r.tags || '').split(','))
    .map((t) => t.trim())
    .filter((t) => t && t.toLowerCase().includes(q.toLowerCase()))
    .slice(0, 4);
  res.json({ items: [...items.map((i) => i.text), ...tags].slice(0, 10) });
});

module.exports = router;
