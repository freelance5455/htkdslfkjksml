'use strict';
/** مسارات المصادقة وإدارة الحساب */
const express = require('express');
const { db } = require('../db');
const auth = require('../auth');

const router = express.Router();

const attempts = new Map();
function tooManyAttempts(key) {
  const rec = attempts.get(key);
  if (!rec) return false;
  if (Date.now() - rec.at > 15 * 60 * 1000) { attempts.delete(key); return false; }
  return rec.count >= 8;
}
function noteAttempt(key) {
  const rec = attempts.get(key) || { count: 0, at: Date.now() };
  rec.count += 1; rec.at = Date.now();
  attempts.set(key, rec);
}

router.post('/register', (req, res) => {
  const { email, password, name } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'البريد وكلمة المرور مطلوبان' });
  if (String(password).length < 6) return res.status(400).json({ error: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' });
  if (!/^\S+@\S+\.\S+$/.test(String(email))) return res.status(400).json({ error: 'صيغة البريد غير صحيحة' });
  try {
    const user = auth.createUser({ email, password, name });
    res.json({ token: auth.signToken(user), user });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

router.post('/login', (req, res) => {
  const { email, password } = req.body || {};
  const key = String(email || '').toLowerCase();
  if (tooManyAttempts(key)) return res.status(429).json({ error: 'محاولات كثيرة جداً. حاول بعد 15 دقيقة.' });
  const row = db.prepare('SELECT * FROM users WHERE email = ?').get(key);
  if (!row || !auth.checkPassword(String(password || ''), row.password_hash)) {
    noteAttempt(key);
    return res.status(401).json({ error: 'البريد أو كلمة المرور غير صحيحة' });
  }
  attempts.delete(key);
  const user = { id: row.id, email: row.email, name: row.name, role: row.role, color: row.color };
  res.json({ token: auth.signToken(user), user });
});

router.get('/me', auth.requireAuth, (req, res) => {
  const channel = db.prepare('SELECT * FROM channels WHERE user_id = ? ORDER BY id LIMIT 1').get(req.user.id);
  res.json({ user: req.user, channel: channel || null });
});

router.patch('/me', auth.requireAuth, (req, res) => {
  const { name, color } = req.body || {};
  if (name) db.prepare('UPDATE users SET name = ? WHERE id = ?').run(String(name).slice(0, 80), req.user.id);
  if (color) db.prepare('UPDATE users SET color = ? WHERE id = ?').run(String(color).slice(0, 20), req.user.id);
  const user = db.prepare('SELECT id, email, name, role, color FROM users WHERE id = ?').get(req.user.id);
  if (user && channelOf(user.id)) db.prepare('UPDATE channels SET name = ? WHERE id = ?').run(user.name, channelOf(user.id).id);
  res.json({ user });
});

router.post('/me/password', auth.requireAuth, (req, res) => {
  const { current, next } = req.body || {};
  const row = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!auth.checkPassword(String(current || ''), row.password_hash)) return res.status(401).json({ error: 'كلمة المرور الحالية غير صحيحة' });
  if (String(next || '').length < 6) return res.status(400).json({ error: 'كلمة المرور الجديدة قصيرة جداً' });
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(auth.hashPassword(String(next)), req.user.id);
  res.json({ ok: true });
});

function channelOf(userId) {
  return db.prepare('SELECT * FROM channels WHERE user_id = ? ORDER BY id LIMIT 1').get(userId);
}

module.exports = router;
