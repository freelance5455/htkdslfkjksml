'use strict';
/** بث ملفات الفيديو وتنزيلها والصور المصغّرة */
const express = require('express');
const fs = require('fs');
const path = require('path');
const { db, VIDEOS_DIR, THUMBS_DIR, SUBS_DIR } = require('../db');

const router = express.Router();

/** بث يدعم Range للتقديم والتأخير في المشغّل */
function streamFile(req, res, filePath, { download = false, filename } = {}) {
  if (!filePath || !fs.existsSync(filePath)) {
    return res.status(404).json({ error: 'الملف غير موجود' });
  }
  const stat = fs.statSync(filePath);
  const total = stat.size;
  const range = req.headers.range;

  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader('Content-Type', mimeOf(filePath));
  res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
  if (download) {
    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(filename || path.basename(filePath))}"`);
  }

  if (range) {
    const m = /bytes=(\d*)-(\d*)/.exec(range);
    let start = m && m[1] ? parseInt(m[1], 10) : 0;
    let end = m && m[2] ? parseInt(m[2], 10) : total - 1;
    if (Number.isNaN(start)) start = 0;
    if (Number.isNaN(end) || end >= total) end = total - 1;
    if (start > end || start >= total) {
      res.status(416).setHeader('Content-Range', `bytes */${total}`);
      return res.end();
    }
    res.status(206);
    res.setHeader('Content-Range', `bytes ${start}-${end}/${total}`);
    res.setHeader('Content-Length', end - start + 1);
    fs.createReadStream(filePath, { start, end }).pipe(res);
  } else {
    res.setHeader('Content-Length', total);
    fs.createReadStream(filePath).pipe(res);
  }
}

function mimeOf(file) {
  const ext = path.extname(file).toLowerCase();
  const map = {
    '.mp4': 'video/mp4', '.m4v': 'video/mp4', '.webm': 'video/webm', '.mkv': 'video/x-matroska',
    '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp',
    '.vtt': 'text/vtt', '.srt': 'text/plain; charset=utf-8', '.m3u8': 'application/vnd.apple.mpegurl',
  };
  return map[ext] || 'application/octet-stream';
}

/** بث فيديو حسب المعرّف */
router.get('/stream/:id', (req, res) => {
  const row = db.prepare('SELECT file_path, title FROM videos WHERE id = ?').get(req.params.id);
  if (!row || !row.file_path) return res.status(404).json({ error: 'الفيديو غير موجود' });
  const file = path.join(VIDEOS_DIR, row.file_path);
  if (!fs.existsSync(file)) return res.status(404).json({ error: 'ملف الفيديو غير موجود' });
  streamFile(req, res, file, { filename: `${row.title}.mp4` });
});

/** بث نسخة WebM (بديل للمتصفحات بلا دعم H.264) */
router.get('/stream-webm/:id', (req, res) => {
  const row = db.prepare('SELECT webm_path, title FROM videos WHERE id = ?').get(req.params.id);
  if (!row || !row.webm_path) return res.status(404).json({ error: 'النسخة البديلة غير متاحة' });
  const file = path.join(VIDEOS_DIR, row.webm_path);
  if (!fs.existsSync(file)) return res.status(404).json({ error: 'النسخة البديلة غير متاحة' });
  streamFile(req, res, file, { filename: `${row.title}.webm` });
});

/** تنزيل الفيديو على الجهاز */
router.get('/download/:id', (req, res) => {
  const row = db.prepare('SELECT file_path, title FROM videos WHERE id = ?').get(req.params.id);
  if (!row || !row.file_path) return res.status(404).json({ error: 'الفيديو غير موجود' });
  const file = path.join(VIDEOS_DIR, row.file_path);
  if (!fs.existsSync(file)) return res.status(404).json({ error: 'ملف الفيديو غير موجود' });
  streamFile(req, res, file, { download: true, filename: `${row.title}.mp4` });
});

/** ملف الترجمة */
router.get('/subs/:id', (req, res) => {
  const row = db.prepare('SELECT subtitle_path FROM videos WHERE id = ?').get(req.params.id);
  if (!row || !row.subtitle_path) return res.status(404).end();
  const file = path.join(SUBS_DIR, row.subtitle_path);
  if (!fs.existsSync(file)) return res.status(404).end();
  res.setHeader('Content-Type', 'text/vtt; charset=utf-8');
  fs.createReadStream(file).pipe(res);
});

/** الصور المصغّرة والغلاف */
router.get('/thumb/:file', (req, res) => {
  const file = path.basename(String(req.params.file));
  const full = path.join(THUMBS_DIR, file);
  if (!fs.existsSync(full)) return res.status(404).end();
  res.setHeader('Content-Type', mimeOf(full));
  res.setHeader('Cache-Control', 'public, max-age=604800');
  fs.createReadStream(full).pipe(res);
});

module.exports = router;
