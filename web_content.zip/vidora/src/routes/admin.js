'use strict';
/** لوحة التحكم: الإحصاءات، المستخدمون، الفيديوهات، الإعدادات، سجل المهام */
const express = require('express');
const fs = require('fs');
const path = require('path');
const { db, stats, getSetting, setSetting, VIDEOS_DIR, THUMBS_DIR, SUBS_DIR } = require('../db');
const { requireAdmin } = require('../auth');
const ytdlp = require('../ytdlp');
const media = require('../media');

const router = express.Router();
router.use(requireAdmin);

router.get('/stats', (req, res) => {
  res.json({
    ...stats(),
    system: {
      node: process.version,
      uptime: Math.round(process.uptime()),
      platform: `${process.platform} ${process.arch}`,
      ffmpeg: media.hasFfmpeg(),
      ytdlp: ytdlp.ytdlpAvailable(),
      cookies: Boolean(ytdlp.cookiesPath()),
      proxy: Boolean(process.env.DOWNLOAD_PROXY),
      dbSize: fs.existsSync(path.join(require('../db').DATA_DIR, 'vidora.sqlite'))
        ? fs.statSync(path.join(require('../db').DATA_DIR, 'vidora.sqlite')).size : 0,
    },
  });
});

router.get('/users', (req, res) => {
  const items = db.prepare(`
    SELECT u.id, u.email, u.name, u.role, u.color, u.created_at,
           (SELECT COUNT(*) FROM channels c WHERE c.user_id = u.id) AS channels
    FROM users u ORDER BY u.id DESC LIMIT 200`).all();
  res.json({ items });
});

router.patch('/users/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const role = req.body?.role;
  if (!['user', 'admin'].includes(role)) return res.status(400).json({ error: 'دور غير صالح' });
  if (id === req.user.id && role !== 'admin') return res.status(400).json({ error: 'لا يمكنك إزالة صلاحياتك بنفسك' });
  db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, id);
  res.json({ ok: true });
});

router.delete('/users/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (id === req.user.id) return res.status(400).json({ error: 'لا يمكنك حذف حسابك' });
  db.prepare('DELETE FROM users WHERE id = ?').run(id);
  res.json({ ok: true });
});

router.get('/videos', (req, res) => {
  const items = db.prepare(`
    SELECT v.*, c.name AS channel_name FROM videos v LEFT JOIN channels c ON c.id = v.channel_id
    ORDER BY v.id DESC LIMIT 300`).all().map((v) => ({
    ...v,
    stream_url: v.file_path ? `/media/stream/${v.id}` : null,
    thumb_url: v.thumb_path ? `/media/thumb/${v.thumb_path}` : null,
  }));
  res.json({ items });
});

router.delete('/videos/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const v = db.prepare('SELECT * FROM videos WHERE id = ?').get(id);
  if (!v) return res.status(404).json({ error: 'الفيديو غير موجود' });
  for (const f of [
    v.file_path && path.join(VIDEOS_DIR, v.file_path),
    v.webm_path && path.join(VIDEOS_DIR, v.webm_path),
    v.thumb_path && path.join(THUMBS_DIR, v.thumb_path),
    v.poster_path && path.join(THUMBS_DIR, v.poster_path),
    v.subtitle_path && path.join(SUBS_DIR, v.subtitle_path),
  ].filter(Boolean)) { try { fs.unlinkSync(f); } catch { /* ignore */ } }
  db.prepare('DELETE FROM videos WHERE id = ?').run(id);
  res.json({ ok: true });
});

router.post('/videos/:id/feature', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const value = req.body?.featured ? 1 : 0;
  db.prepare('UPDATE videos SET featured = ? WHERE id = ?').run(value, id);
  res.json({ ok: true });
});

router.get('/jobs', (req, res) => {
  const items = db.prepare('SELECT * FROM jobs ORDER BY id DESC LIMIT 200').all();
  res.json({ items });
});

router.get('/settings', (req, res) => {
  res.json({
    siteName: getSetting('siteName', process.env.SITE_NAME || 'Vidora'),
    siteTagline: getSetting('siteTagline', process.env.SITE_TAGLINE || 'منصة الفيديو المفتوحة'),
    featuredChannel: getSetting('featuredChannel', ''),
    announcement: getSetting('announcement', ''),
  });
});

router.put('/settings', (req, res) => {
  const allowed = ['siteName', 'siteTagline', 'featuredChannel', 'announcement'];
  for (const key of allowed) {
    if (req.body?.[key] !== undefined) setSetting(key, String(req.body[key]).slice(0, 500));
  }
  res.json({ ok: true });
});

module.exports = router;
