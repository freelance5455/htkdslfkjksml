'use strict';
/**
 * طبقة قاعدة البيانات — SQLite (better-sqlite3)
 * مخطط كامل لمنصة الفيديو: مستخدمون، قنوات، فيديوهات، تعليقات، اشتراكات،
 * تاريخ المشاهدة، قوائم التشغيل، إعدادات الموقع، وسجل مهام الاستيراد.
 */
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, '..', 'data'));
const MEDIA_DIR = path.join(DATA_DIR, 'media');
const THUMBS_DIR = path.join(MEDIA_DIR, 'thumbs');
const VIDEOS_DIR = path.join(MEDIA_DIR, 'videos');
const SUBS_DIR = path.join(MEDIA_DIR, 'subs');
const TMP_DIR = path.join(DATA_DIR, 'tmp');

for (const dir of [DATA_DIR, MEDIA_DIR, THUMBS_DIR, VIDEOS_DIR, SUBS_DIR, TMP_DIR]) {
  fs.mkdirSync(dir, { recursive: true });
}

const db = new Database(path.join(DATA_DIR, 'vidora.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  email         TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  name          TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'user',
  color         TEXT NOT NULL DEFAULT '#3ea6ff',
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS channels (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id      INTEGER REFERENCES users(id) ON DELETE SET NULL,
  name         TEXT NOT NULL,
  handle       TEXT UNIQUE,
  description  TEXT DEFAULT '',
  avatar       TEXT,
  banner      TEXT,
  links        TEXT DEFAULT '',
  subscribers  INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS videos (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  channel_id   INTEGER REFERENCES channels(id) ON DELETE CASCADE,
  title        TEXT NOT NULL,
  description  TEXT DEFAULT '',
  tags         TEXT DEFAULT '',
  category     TEXT DEFAULT 'عام',
  visibility   TEXT NOT NULL DEFAULT 'public',
  duration     REAL DEFAULT 0,
  views        INTEGER NOT NULL DEFAULT 0,
  likes        INTEGER NOT NULL DEFAULT 0,
  dislikes     INTEGER NOT NULL DEFAULT 0,
  source_type  TEXT NOT NULL DEFAULT 'upload',
  source_url   TEXT,
  source_id    TEXT,
  file_path    TEXT,
  thumb_path   TEXT,
  poster_path  TEXT,
  subtitle_path TEXT,
  width        INTEGER DEFAULT 0,
  height       INTEGER DEFAULT 0,
  size_bytes   INTEGER DEFAULT 0,
  quality      TEXT DEFAULT 'HD',
  status       TEXT NOT NULL DEFAULT 'ready',
  error        TEXT,
  featured     INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT NOT NULL DEFAULT (datetime('now')),
  published_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS comments (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  video_id   INTEGER NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  user_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  author     TEXT NOT NULL DEFAULT 'زائر',
  avatar     TEXT,
  text       TEXT NOT NULL,
  likes      INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS subscriptions (
  channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (channel_id, user_id)
);

CREATE TABLE IF NOT EXISTS history (
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  video_id   INTEGER NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  progress   REAL DEFAULT 0,
  watched_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, video_id)
);

CREATE TABLE IF NOT EXISTS watch_later (
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  video_id   INTEGER NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, video_id)
);

CREATE TABLE IF NOT EXISTS reactions (
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  video_id   INTEGER NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  value      INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, video_id)
);

CREATE TABLE IF NOT EXISTS playlists (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER REFERENCES users(id) ON DELETE CASCADE,
  channel_id  INTEGER REFERENCES channels(id) ON DELETE CASCADE,
  name        TEXT NOT NULL,
  description TEXT DEFAULT '',
  privacy     TEXT NOT NULL DEFAULT 'public',
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS playlist_items (
  playlist_id INTEGER NOT NULL REFERENCES playlists(id) ON DELETE CASCADE,
  video_id    INTEGER NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  position    INTEGER NOT NULL DEFAULT 0,
  added_at    TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (playlist_id, video_id)
);

CREATE TABLE IF NOT EXISTS notifications (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER REFERENCES users(id) ON DELETE CASCADE,
  type       TEXT NOT NULL,
  payload    TEXT NOT NULL DEFAULT '{}',
  is_read    INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS jobs (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
  type        TEXT NOT NULL DEFAULT 'import',
  url         TEXT,
  title       TEXT,
  status      TEXT NOT NULL DEFAULT 'queued',
  progress    REAL NOT NULL DEFAULT 0,
  message     TEXT,
  error       TEXT,
  video_id    INTEGER REFERENCES videos(id) ON DELETE SET NULL,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT
);

CREATE INDEX IF NOT EXISTS idx_videos_channel   ON videos(channel_id);
CREATE INDEX IF NOT EXISTS idx_videos_published ON videos(published_at DESC);
CREATE INDEX IF NOT EXISTS idx_videos_status    ON videos(status);
CREATE INDEX IF NOT EXISTS idx_comments_video   ON comments(video_id);
CREATE INDEX IF NOT EXISTS idx_jobs_status      ON jobs(status);
`);

/* ------------------------- ترقية المخطط ------------------------- */
function ensureColumn(table, column, definition) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all();
  if (!cols.some((c) => c.name === column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
}
ensureColumn('videos', 'webm_path', 'TEXT');

/* ------------------------------ الإعدادات ------------------------------ */
const getSettingStmt = db.prepare('SELECT value FROM settings WHERE key = ?');
const setSettingStmt = db.prepare(
  'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'
);

function getSetting(key, fallback = null) {
  const row = getSettingStmt.get(key);
  if (!row) return fallback;
  try {
    return JSON.parse(row.value);
  } catch {
    return row.value;
  }
}

function setSetting(key, value) {
  setSettingStmt.run(key, JSON.stringify(value));
  return value;
}

/* ------------------------- مساعدات استعلام الفيديو ------------------------- */
const VIDEO_SELECT = `
  SELECT v.*, c.name AS channel_name, c.handle AS channel_handle, c.avatar AS channel_avatar,
         c.subscribers AS channel_subscribers, c.user_id AS channel_user_id
  FROM videos v LEFT JOIN channels c ON c.id = v.channel_id
`;

function hydrate(video) {
  if (!video) return null;
  const out = { ...video };
  out.tags = out.tags ? String(out.tags).split(',').map((t) => t.trim()).filter(Boolean) : [];
  out.stream_url = out.file_path ? `/media/stream/${out.id}` : null;
  out.webm_url = out.webm_path ? `/media/stream-webm/${out.id}` : null;
  out.thumb_url = out.thumb_path ? `/media/thumb/${out.thumb_path}` : null;
  out.poster_url = out.poster_path ? `/media/thumb/${out.poster_path}`
    : out.thumb_path ? `/media/thumb/${out.thumb_path}` : null;
  out.subtitle_url = out.subtitle_path ? `/media/subs/${out.id}` : null;
  out.download_url = out.file_path ? `/media/download/${out.id}` : null;
  return out;
}

const getVideoStmt = db.prepare(`${VIDEO_SELECT} WHERE v.id = ?`);
const listVideosStmt = db.prepare(
  `${VIDEO_SELECT} WHERE v.status = 'ready' AND v.visibility = 'public' ORDER BY v.published_at DESC`
);

function getVideo(id) {
  return hydrate(getVideoStmt.get(id));
}

function listVideos(limit = 24, offset = 0) {
  return listVideosStmt.all(limit, offset).map(hydrate);
}

/** استعلام مرن للفيديوهات (بحث، تصفية، ترتيب) */
function queryVideos(opts = {}) {
  const {
    q = '', category = '', channelId = null, userId = null,
    sort = 'recent', limit = 24, offset = 0,
    duration = '', minViews = null, source = '',
  } = opts;

  const where = ["v.status = 'ready'"];
  const params = {};

  if (q) {
    where.push(
      `(LOWER(v.title) LIKE @q OR LOWER(v.description) LIKE @q OR LOWER(v.tags) LIKE @q
        OR LOWER(IFNULL(c.name,'')) LIKE @q OR LOWER(IFNULL(c.handle,'')) LIKE @q)`
    );
    params.q = `%${q.toLowerCase()}%`;
  }
  if (category && category !== 'الكل') {
    where.push('v.category = @category');
    params.category = category;
  }
  if (channelId) {
    where.push('v.channel_id = @channelId');
    params.channelId = channelId;
  }
  if (source) {
    where.push('v.source_type = @source');
    params.source = source;
  }
  if (duration === 'short') where.push('v.duration > 0 AND v.duration < 240');
  else if (duration === 'medium') where.push('v.duration >= 240 AND v.duration < 1200');
  else if (duration === 'long') where.push('v.duration >= 1200');
  if (minViews) {
    where.push('v.views >= @minViews');
    params.minViews = minViews;
  }

  const orderBy =
    sort === 'oldest' ? 'v.published_at ASC'
      : sort === 'views' ? 'v.views DESC, v.published_at DESC'
        : sort === 'trending' ? '(v.views / (1 + (julianday(\'now\') - julianday(v.published_at)) / 7.0 + 1)) DESC'
          : sort === 'likes' ? 'v.likes DESC'
            : 'v.published_at DESC';

  const sql = `${VIDEO_SELECT} WHERE ${where.join(' AND ')} ORDER BY ${orderBy} LIMIT @limit OFFSET @offset`;
  params.limit = limit;
  params.offset = offset;

  const rows = db.prepare(sql).all(params).map(hydrate);
  const countSql = `SELECT COUNT(*) AS n FROM videos v LEFT JOIN channels c ON c.id = v.channel_id WHERE ${where.join(' AND ')}`;
  const total = db.prepare(countSql).get(params).n;
  return { items: rows, total };
}

/* ------------------------------ الإحصاءات ------------------------------ */
function stats() {
  const one = (sql) => db.prepare(sql).get();
  return {
    videos: one('SELECT COUNT(*) AS n FROM videos').n,
    users: one('SELECT COUNT(*) AS n FROM users').n,
    channels: one('SELECT COUNT(*) AS n FROM channels').n,
    views: one('SELECT COALESCE(SUM(views),0) AS n FROM videos').n,
    likes: one('SELECT COALESCE(SUM(likes),0) AS n FROM videos').n,
    comments: one('SELECT COUNT(*) AS n FROM comments').n,
    storage: one('SELECT COALESCE(SUM(size_bytes),0) AS n FROM videos').n,
    subs: one('SELECT COALESCE(SUM(subscribers),0) AS n FROM channels').n,
    bySource: db.prepare('SELECT source_type AS k, COUNT(*) AS n FROM videos GROUP BY source_type').all(),
    topVideos: db.prepare(`${VIDEO_SELECT} WHERE v.status='ready' ORDER BY v.views DESC LIMIT 8`).all().map(hydrate),
  };
}

module.exports = {
  db,
  DATA_DIR, MEDIA_DIR, THUMBS_DIR, VIDEOS_DIR, SUBS_DIR, TMP_DIR,
  getSetting, setSetting, getVideo, listVideos, queryVideos, hydrate, stats,
};
