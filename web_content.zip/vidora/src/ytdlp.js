'use strict';
/**
 * طبقة الاستيراد من الإنترنت عبر yt-dlp.
 *
 * الاستراتيجيات بالترتيب (حتى تنجح مع أكبر عدد ممكن من المنصات):
 *   1) الوضع الافتراضي لـ yt-dlp
 *   2) عملاء extractors بديلة (tv, web_embedded, mweb) — تساعد على تجاوز
 *      قيود "سجّل الدخول" على يوتيوب بدون كوكيز
 *   3) ملف كوكيز (data/cookies.txt أو COOKIES_FILE) — الحل الموثوق
 *   4) بروكسي (DOWNLOAD_PROXY) — لو كان IP الخادم محجوباً
 */
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const { TMP_DIR } = require('./db');

const PROJECT_ROOT = path.join(__dirname, '..');

function resolveYtdlp() {
  const candidates = [
    process.env.YTDLP_PATH,
    path.join(PROJECT_ROOT, 'vendor', 'yt-dlp'),
    path.join(PROJECT_ROOT, 'vendor', 'yt-dlp.exe'),
    '/usr/local/bin/yt-dlp',
    '/usr/bin/yt-dlp',
  ].filter(Boolean);
  for (const c of candidates) {
    try {
      fs.accessSync(c, fs.constants.X_OK);
      return c;
    } catch { /* next */ }
  }
  return 'yt-dlp';
}

function ytdlpAvailable() {
  const bin = resolveYtdlp();
  try {
    if (bin !== 'yt-dlp') {
      fs.accessSync(bin, fs.constants.X_OK);
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

function cookiesPath() {
  const configured = process.env.COOKIES_FILE;
  const candidates = [
    configured,
    path.join(process.env.DATA_DIR || path.join(PROJECT_ROOT, 'data'), 'cookies.txt'),
    path.join(PROJECT_ROOT, 'data', 'cookies.txt'),
  ].filter(Boolean);
  for (const c of candidates) {
    try {
      if (fs.statSync(c).isFile() && fs.statSync(c).size > 0) return c;
    } catch { /* next */ }
  }
  return null;
}

/** ترجمة رسائل الخطأ الشائعة إلى العربية مع إرشاد حل */
function translateError(message = '') {
  const m = message.toLowerCase();
  if (m.includes('sign in to confirm') || m.includes('not a bot')) {
    return 'المنصة تطلب التحقق من أنها ليست روبوت. الحل: ضع ملف كوكيز (data/cookies.txt) أو فعّل بروكسي في الإعدادات.';
  }
  if (m.includes('403') || m.includes('forbidden')) {
    return 'الموقع يحظر عنوان IP الخادم. الحل: استخدم بروكسي سكني أو غيّر مزوّد الاستضافة.';
  }
  if (m.includes('429') || m.includes('too many requests')) {
    return 'تم تجاوز حد الطلبات من هذا IP. الحل: انتظر قليلاً أو استخدم بروكسي.';
  }
  if (m.includes('private video')) return 'الفيديو خاص ولا يمكن تنزيله.';
  if (m.includes('video unavailable') || m.includes('not available')) return 'الفيديو غير متاح أو تم حذفه.';
  if (m.includes('unsupported url') || m.includes('no video formats')) return 'الرابط غير مدعوم أو لا يحتوي على فيديو.';
  if (m.includes('geo') || m.includes('not available in your country')) return 'الفيديو محجوب في هذه المنطقة.';
  if (m.includes('age') || m.includes('confirm your age')) return 'الفيديو مقيّد بالعمر ويتطلب تسجيل دخول.';
  if (m.includes('login required') || m.includes('requires authentication')) return 'المحتوى يتطلب تسجيل دخول — أضف ملف كوكيز.';
  if (m.includes('404')) return 'الصفحة غير موجودة أو الرابط خاطئ.';
  return message.split('\n').filter(Boolean).slice(-1)[0] || 'فشل الاستيراد من الرابط.';
}

/** تشغيل yt-dlp مع التقاط المخرجات */
function runYtdlp(args, { onProgress, onLine, timeout = 3600000 } = {}) {
  return new Promise((resolve) => {
    const bin = resolveYtdlp();
    const child = spawn(bin, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '';
    let stderr = '';
    let progress = 0;
    let timer = null;

    if (timeout > 0) {
      timer = setTimeout(() => { try { child.kill('SIGKILL'); } catch { /* ignore */ } }, timeout);
    }

    const handleLine = (line) => {
      if (onLine) onLine(line);
      const pm = line.match(/\[download\]\s+(\d+(?:\.\d+)?)%/);
      if (pm) {
        const p = Math.min(99, Number(pm[1]));
        if (p > progress) {
          progress = p;
          if (onProgress) onProgress(p);
        }
      }
    };

    let buffer = '';
    child.stdout.on('data', (d) => {
      const s = d.toString();
      stdout += s;
      buffer += s;
      const lines = buffer.split('\n');
      buffer = lines.pop();
      lines.forEach(handleLine);
    });
    child.stderr.on('data', (d) => {
      const s = d.toString();
      stderr += s;
      buffer += s;
      const lines = buffer.split('\n');
      buffer = lines.pop();
      lines.forEach(handleLine);
    });

    child.on('error', (e) => {
      if (timer) clearTimeout(timer);
      resolve({ ok: false, code: -1, stdout, stderr: stderr + '\n' + e.message, progress });
    });
    child.on('close', (code) => {
      if (timer) clearTimeout(timer);
      resolve({ ok: code === 0, code, stdout, stderr, progress });
    });
  });
}

const BASE_ARGS = [
  '--no-warnings',
  '--no-playlist',
  '--no-check-certificate',
  '--retries', '5',
  '--fragment-retries', '10',
  '--socket-timeout', '30',
  '--newline',
  '--no-color',
];

/** جلب بيانات الفيديو فقط (بدون تنزيل) */
async function getInfo(url, { proxy } = {}) {
  const args = [...BASE_ARGS, '--dump-single-json', '--skip-download', url];
  if (proxy || process.env.DOWNLOAD_PROXY) args.push('--proxy', proxy || process.env.DOWNLOAD_PROXY);
  const cookies = cookiesPath();
  if (cookies) args.push('--cookies', cookies);
  const res = await runYtdlp(args, { timeout: 180000 });
  if (!res.ok || !res.stdout.trim()) {
    throw new Error(translateError(res.stderr || 'تعذّر جلب بيانات الفيديو'));
  }
  try {
    return JSON.parse(res.stdout);
  } catch {
    throw new Error('تعذّر قراءة بيانات الفيديو من الرابط');
  }
}

/** توليد قائمة استراتيجيات الجرب */
function strategies() {
  const list = [{ name: 'default', args: [] }];
  const clients = ['tv_simply', 'web_embedded', 'mweb', 'android_vr'];
  for (const c of clients) {
    list.push({ name: `client:${c}`, args: [`--extractor-args`, `youtube:player_client=${c}`] });
  }
  const cookies = cookiesPath();
  if (cookies) {
    list.push({ name: 'cookies', args: ['--cookies', cookies], withCookies: true });
  }
  return list;
}

/**
 * تنزيل فيديو من رابط.
 * onProgress(percent, stage)
 */
async function download(url, { outDir = TMP_DIR, proxy, onProgress, quality = 'best' } = {}) {
  fs.mkdirSync(outDir, { recursive: true });
  const cookieFile = cookiesPath();
  const useProxy = proxy || process.env.DOWNLOAD_PROXY || null;

  const formatSel = quality === 'low'
    ? 'b[height<=480][ext=mp4]/b[ext=mp4]/bv*+ba/b'
    : 'bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b';

  const errors = [];
  const all = strategies();

  for (let i = 0; i < all.length; i += 1) {
    const strat = all[i];
    const args = [...BASE_ARGS, ...strat.args, '-f', formatSel, '--merge-output-format', 'mp4',
      '--ffmpeg-location', process.env.FFMPEG_PATH || 'ffmpeg',
      '-o', path.join(outDir, 'src.%(ext)s'), url];
    if (useProxy) args.push('--proxy', useProxy);
    if (strat.withCookies && cookieFile) args.push('--cookies', cookieFile);
    else if (cookieFile && !strat.withCookies) args.push('--cookies', cookieFile);

    if (onProgress) onProgress(0, `محاولة ${i + 1}/${all.length}: ${strat.name}`);

    const res = await runYtdlp(args, {
      onProgress: (p) => onProgress && onProgress(Math.max(2, p * 0.98), 'جاري التنزيل'),
      timeout: 3600000,
    });

    if (res.ok) {
      const file = findOutput(outDir);
      if (file) {
        return { file, strategy: strat.name, usedCookies: Boolean(cookieFile), usedProxy: Boolean(useProxy), stdout: res.stdout };
      }
      errors.push(`${strat.name}: اكتمل بدون ملف`);
    } else {
      errors.push(`${strat.name}: ${translateError(res.stderr)}`);
      // فشل مصاب بخطأ "cookies" لا قيمة لإبقائه في القائمة
      if (/cookies|netrc/i.test(res.stderr) && !strat.withCookies) continue;
    }
  }

  throw new Error(translateError(errors.join('\n')) || 'فشل تنزيل الفيديو من الرابط');
}

/** تنزيل ملف الترجمة (اختياري) لنفس الرابط */
async function downloadSubtitles(url, outDir, { proxy } = {}) {
  const cookies = cookiesPath();
  const args = [...BASE_ARGS, '--skip-download', '--write-subs', '--write-auto-subs',
    '--sub-langs', 'ar.*,en.*,ar,en', '--convert-subs', 'vtt',
    '-o', path.join(outDir, 'subs.%(ext)s'), url];
  if (proxy || process.env.DOWNLOAD_PROXY) args.push('--proxy', proxy || process.env.DOWNLOAD_PROXY);
  if (cookies) args.push('--cookies', cookies);
  const res = await runYtdlp(args, { timeout: 300000 });
  if (!res.ok) return null;
  const dir = fs.readdirSync(outDir);
  const vtt = dir.find((f) => f.endsWith('.vtt'));
  return vtt ? path.join(outDir, vtt) : null;
}

function findOutput(dir) {
  const files = fs.readdirSync(dir)
    .map((f) => ({ f, p: path.join(dir, f) }))
    .filter(({ f }) => !f.endsWith('.part') && !f.endsWith('.ytdl') && !f.endsWith('.vtt') && !f.endsWith('.json') && !f.endsWith('.jpg') && !f.endsWith('.webp'));
  const video = files.find(({ f }) => /\.(mp4|mkv|webm|mov|m4v|flv|ts)$/i.test(f));
  if (!video) return null;
  let size = 0;
  try { size = fs.statSync(video.p).size; } catch { size = 0; }
  if (size < 1024) return null;
  return video.p;
}

function cleanupDir(dir) {
  try {
    for (const f of fs.readdirSync(dir)) {
      try { fs.unlinkSync(path.join(dir, f)); } catch { /* ignore */ }
    }
  } catch { /* ignore */ }
}

module.exports = {
  resolveYtdlp, ytdlpAvailable, cookiesPath, getInfo, download,
  downloadSubtitles, translateError, cleanupDir, runYtdlp,
};
