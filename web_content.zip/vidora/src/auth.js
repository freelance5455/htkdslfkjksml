'use strict';
/** المصادقة: تسجيل/دخول بـ JWT + تشفير كلمات المرور بـ bcrypt */
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db } = require('./db');

const JWT_SECRET = process.env.JWT_SECRET || 'vidora-dev-secret-change-me';
const TTL_DAYS = Number(process.env.JWT_TTL_DAYS || 30);
const COLORS = ['#3ea6ff', '#ff4d4d', '#7c4dff', '#00c853', '#ff9100', '#00b8d4', '#ff4081', '#64b5f6'];

function hashPassword(plain) {
  return bcrypt.hashSync(plain, 10);
}

function checkPassword(plain, hash) {
  try {
    return bcrypt.compareSync(plain, hash);
  } catch {
    return false;
  }
}

function signToken(user) {
  return jwt.sign({ uid: user.id, role: user.role, name: user.name }, JWT_SECRET, {
    expiresIn: `${TTL_DAYS}d`,
  });
}

function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}

function userFromRequest(req) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return null;
  const payload = verifyToken(token);
  if (!payload) return null;
  const user = db.prepare('SELECT id, email, name, role, color, created_at FROM users WHERE id = ?').get(payload.uid);
  return user || null;
}

/** حارس: يتطلب مستخدماً */
function requireAuth(req, res, next) {
  const user = userFromRequest(req);
  if (!user) return res.status(401).json({ error: 'يجب تسجيل الدخول أولاً' });
  req.user = user;
  next();
}

/** حارس: يتطلب مشرفاً */
function requireAdmin(req, res, next) {
  const user = userFromRequest(req);
  if (!user) return res.status(401).json({ error: 'يجب تسجيل الدخول أولاً' });
  if (user.role !== 'admin') return res.status(403).json({ error: 'هذه العملية للمديرين فقط' });
  req.user = user;
  next();
}

function createUser({ email, password, name, role = 'user' }) {
  const normalized = String(email).trim().toLowerCase();
  const exists = db.prepare('SELECT id FROM users WHERE email = ?').get(normalized);
  if (exists) {
    const err = new Error('هذا البريد مسجّل مسبقاً');
    err.status = 409;
    throw err;
  }
  const color = COLORS[Math.floor(Math.random() * COLORS.length)];
  const info = db
    .prepare('INSERT INTO users (email, password_hash, name, role, color) VALUES (?, ?, ?, ?, ?)')
    .run(normalized, hashPassword(password), name || normalized.split('@')[0], role, color);
  const user = db.prepare('SELECT id, email, name, role, color FROM users WHERE id = ?').get(info.lastInsertRowid);
  // إنشاء قناة افتراضية لكل مستخدم
  const handle = `${(name || normalized.split('@')[0]).toString().replace(/\s+/g, '').toLowerCase()}-${info.lastInsertRowid}`;
  db.prepare('INSERT INTO channels (user_id, name, handle) VALUES (?, ?, ?)').run(user.id, user.name, handle);
  return user;
}

module.exports = { hashPassword, checkPassword, signToken, verifyToken, userFromRequest, requireAuth, requireAdmin, createUser, JWT_SECRET };
