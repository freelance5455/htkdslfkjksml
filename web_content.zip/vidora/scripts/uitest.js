/* اختبار واجهة Vidora بالمتصفح + لقطات شاشة */
const { chromium } = require('playwright');
const path = require('path');

const BASE = process.env.BASE || 'http://localhost:3000';
const OUT = path.join(__dirname, '..', 'shots');

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, locale: 'ar' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push(`PAGEERROR: ${e.message}`));

  const shot = async (name) => {
    await page.waitForTimeout(700);
    await page.screenshot({ path: path.join(OUT, `${name}.png`), fullPage: false });
    console.log(`📸 ${name}`);
  };

  // 1) الرئيسية
  await page.goto(`${BASE}/#/`, { waitUntil: 'networkidle' });
  await page.waitForSelector('.card', { timeout: 15000 });
  await shot('01-home');

  // 2) صفحة الفيديو
  await page.click('.card');
  await page.waitForSelector('.player-wrap video', { timeout: 15000 });
  await page.waitForTimeout(2500);
  await shot('02-watch');

  // 3) تشغيل الفيديو فعلياً
  const played = await page.evaluate(async () => {
    const v = document.querySelector('.player-wrap video');
    if (!v) return 'no-video';
    try { await v.play(); } catch (e) { return `play-error: ${e.message}`; }
    await new Promise((r) => setTimeout(r, 1500));
    return `time=${v.currentTime.toFixed(2)} dur=${v.duration} ready=${v.readyState}`;
  });
  console.log('▶️  تشغيل الفيديو:', played);
  await shot('03-watch-playing');

  // 4) تسجيل الدخول
  await page.goto(`${BASE}/#/login`, { waitUntil: 'networkidle' });
  await page.fill('input[type=email]', 'admin@vidora.local');
  await page.fill('input[type=password]', 'Vidora@2026');
  await page.click('.btn.primary');
  await page.waitForTimeout(2500);
  await shot('04-logged-in');

  // 5) صفحة الاستيراد
  await page.goto(`${BASE}/#/import`, { waitUntil: 'networkidle' });
  await page.waitForTimeout(1500);
  await shot('05-import');

  // 6) لوحة التحكم
  await page.goto(`${BASE}/#/admin`, { waitUntil: 'networkidle' });
  await page.waitForSelector('.stat', { timeout: 15000 });
  await page.waitForTimeout(1200);
  await shot('06-admin');

  // 7) البحث
  await page.goto(`${BASE}/#/search?q=%D8%A7%D8%B3%D8%AA%D9%8A%D8%B1%D8%A7%D8%AF`, { waitUntil: 'networkidle' });
  await page.waitForTimeout(1500);
  await shot('07-search');

  // 8) القناة
  await page.goto(`${BASE}/#/channel/1`, { waitUntil: 'networkidle' });
  await page.waitForTimeout(1500);
  await shot('08-channel');

  // 9) الجوال
  const mob = await ctx.newPage();
  await mob.setViewportSize({ width: 390, height: 844 });
  await mob.goto(`${BASE}/#/`, { waitUntil: 'networkidle' });
  await mob.waitForTimeout(1800);
  await mob.screenshot({ path: path.join(OUT, '09-mobile.png') });
  console.log('📸 09-mobile');

  console.log('\n=== أخطاء الكونسول ===');
  console.log(errors.length ? errors.slice(0, 15).join('\n') : 'لا يوجد ✅');

  await browser.close();
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
