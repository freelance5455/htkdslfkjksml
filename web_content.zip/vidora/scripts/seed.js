'use strict';
/**
 * سكربت المحتوى التجريبي — ينشئ قنوات وفيديوهات جاهزةعرضة للعرض.
 * التشغيل:  npm run seed          (أضف --clear لحذف المحتوى التجريبي أولاً)
 */
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const { db, VIDEOS_DIR, THUMBS_DIR, DATA_DIR } = require('../src/db');
const media = require('../src/media');

const FONT = [
  path.join(__dirname, '..', 'assets', 'fonts', 'NotoNaskhArabic.ttf'),
  '/usr/share/fonts/truetype/noto/NotoNaskhArabic-Bold.ttf',
  '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
].find((f) => fs.existsSync(f)) || null;

const CHANNELS = [
  { name: 'Vidora ستوديو', handle: 'vidora-studio', color: '#3ea6ff', desc: 'قناة رسمية لمنصة Vidora — كل جديد من الشركة.' },
  { name: 'موقع التقنية', handle: 'tech-ar', color: '#7c4dff', desc: 'مراجعات تقنية، شرح البرمجة، وأخبار عالم التقنية بالعربي.' },
  { name: 'ريلز ومقاطع', handle: 'reels-world', color: '#ff0033', desc: 'مقاطع قصيرة ومحتوى سريع التصفح.' },
];

const VIDEOS = [
  { t: 'مراجعة كاملة لنظام Vidora — منصة الفيديو المفتوحة', tt: 'مراجعة كاملة للمنصة', d: 'نستعرض كل ميزات المنصة: الرفع، الاستيراد من الإنترنت، البث، البحث، الاشتراكات، ولوحة التحكم. رابط المشروع في الوصف.', c: 'تكنولوجيا', tags: 'مراجعة,منصة,فيديو,تقنية', src: 'hd', dur: 24, grad: '0x1f6feb' },
  { t: 'كيف تستورد فيديو من يوتيوب بضغطة زر', tt: 'الاستيراد بضغطة زر', d: 'شرح عملي لخطوات استيراد أي فيديو من يوتيوب أو أي منصة أخرى، مع شرح الكوكيز والبروكسي.', c: 'تعليم', tags: 'شرح,يوتيوب,تنزيل,استيراد', src: 'hd', dur: 18, grad: '0x7c4dff' },
  { t: 'أفضل 10 قنوات تقنية عربية في 2026', tt: 'أفضل القنوات التقنية', d: 'قائمة مختارة من أفضل القنوات العربية التي تقدّم محتوى تقنياً مميزاً.', c: 'تكنولوجيا', tags: 'قنوات,عربية,تقنية', src: 'hd', dur: 20, grad: '0x00c853' },
  { t: 'مقطع مدّة سريعة — يوم في حياة مصوّر', tt: 'يوم في حياة مصوّر', d: 'مقطع قصير يوثّق يوماً كاملاً من العمل.', c: 'ترفيه', tags: 'مقطع,قصير,فيديو', src: 'short', dur: 12, grad: '0xff6d00' },
  { t: 'بناء تطبيق ويب من الصفر — الدرس الأول', tt: 'بناء تطبيق ويب من الصفر', d: 'نبدأ مشروع ويب كامل: الخادم، قاعدة البيانات، والواجهة.', c: 'تعليم', tags: 'برمجة,ويب,دروس,تعلم', src: 'hd', dur: 22, grad: '0x00b8d4' },
  { t: 'موسيقى هادئة للعمل والتركيز', tt: 'موسيقى للعمل والتركيز', d: 'مقطع موسيقي مناسب للعمل والتركيز بدون حقوق.', c: 'موسيقى', tags: 'موسيقى,هدوء,تخفيف', src: 'hd', dur: 20, grad: '0xea80fc' },
  { t: 'أجمل الوجهات السياحية هذا العام', tt: 'أجمل الوجهات السياحية', d: 'رحلة بصرية إلى أجمل المدن حول العالم.', c: 'عام', tags: 'سياحة,سفر', src: 'hd', dur: 25, grad: '0xffab40' },
  { t: 'وصفة سريعة في 5 دقائق', tt: 'وصفة سريعة في خمس دقائق', d: 'وصفة سهلة وسريعة بمكونات موجودة في أي مطبخ.', c: 'طبخ', tags: 'طبخ,وصفات', src: 'short', dur: 14, grad: '0xff5252' },
];

function run(cmd, args) {
  const r = spawnSync(cmd, args, { stdio: 'ignore' });
  return r.status === 0;
}

/** توليد فيديو تجريبي بتدرّج لوني + عنوان */
function generateVideo(outFile, { t, tt, dur, grad }) {
  const title = tt || t;
  const args = ['-y', '-f', 'lavfi', '-i', `gradients=s=1280x720:c0=${grad}:c1=0x000000:x0=0:y0=0:x1=1280:y1=720:d=${dur}:r=24`,
    '-f', 'lavfi', '-i', `sine=frequency=320:duration=${dur}`,
    '-t', String(dur)];
  if (FONT) {
    args.push('-vf', `drawtext=fontfile=${FONT}:text='${String(title).replace(/['\\:]/g, ' ').slice(0, 40)}':fontcolor=white@0.92:fontsize=42:x=(w-text_w)/2:y=(h-text_h)/2-30:box=1:boxcolor=black@0.35:boxborderw=18`);
  }
  args.push('-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '28', '-pix_fmt', 'yuv420p',
    '-c:a', 'aac', '-b:a', '96k', '-shortest', '-movflags', '+faststart', outFile);
  return run('ffmpeg', args);
}

function main() {
  const clear = process.argv.includes('--clear');
  if (clear) {
    db.exec('DELETE FROM videos; DELETE FROM channels; DELETE FROM comments; DELETE FROM notifications;');
    for (const dir of [VIDEOS_DIR, THUMBS_DIR]) {
      for (const f of fs.readdirSync(dir)) { try { fs.unlinkSync(path.join(dir, f)); } catch { /* ignore */ } }
    }
    console.log('✔ تم حذف المحتوى التجريبي');
    if (!process.argv.includes('--keep')) { process.exit(0); }
  }

  const existing = db.prepare("SELECT COUNT(*) AS n FROM channels WHERE handle = 'vidora-studio'").get().n;
  if (existing > 0) {
    console.log('ℹ المحتوى التجريبي موجود بالفعل — لن يُضاف محتوى مكرر. استخدم --clear لحذفه أولاً.');
    return;
  }

  const chIds = [];
  for (const c of CHANNELS) {
    const info = db.prepare('INSERT INTO channels (name, handle, description, subscribers) VALUES (?, ?, ?, ?)')
      .run(c.name, c.handle, c.desc, Math.floor(1000 + Math.random() * 90000));
    const id = Number(info.lastInsertRowid);
    chIds.push(id);
    db.prepare('UPDATE channels SET avatar = ? WHERE id = ?').run(null, id);
  }

  const rnd = (a, b) => a + Math.floor(Math.random() * (b - a));
  const comments = ['محتوى ممتاز، شكراً!', 'أخيراً شرح واضح كهذا 👏', 'طلبت منه بالضبط', 'جزاك الله خير', 'كيف تتعلم هذه المهارة؟', 'أفضل جزء في الفيديو هو latter half', 'جودة الفيديو ممتازة'];

  VIDEOS.forEach((v, idx) => {
    const tmp = path.join(DATA_DIR, 'tmp', `seed_${idx}.mp4`);
    if (!generateVideo(tmp, v)) { console.error(`✖ فشل توليد: ${v.t}`); return; }
    const outFile = path.join(VIDEOS_DIR, `v_seed_${idx}.mp4`);
    fs.copyFileSync(tmp, outFile);
    fs.unlinkSync(tmp);

    const info = db.prepare(`INSERT INTO videos (channel_id, title, description, tags, category, visibility, duration,
        views, likes, dislikes, source_type, source_url, file_path, thumb_path, poster_path, width, height,
        size_bytes, quality, status, created_at, published_at)
      VALUES (?, ?, ?, ?, ?, 'public', ?, ?, ?, ?, ?, ?, ?, ?, ?, 1280, 720, ?, 'HD', 'ready', datetime('now', ?), datetime('now', ?))`)
      .run(chIds[idx % chIds.length], v.t, v.d, v.tags, v.c, v.dur,
        rnd(120, 900000), rnd(20, 9000), rnd(0, 90),
        idx % 3 === 0 ? 'import' : 'upload',
        idx % 3 === 0 ? 'https://example.com/video' : null,
        path.basename(outFile), null, null,
        fs.statSync(outFile).size,
        `-${idx * 3} days`, `-${idx * 3} days`);
    const vid = Number(info.lastInsertRowid);

    (async () => {
      const thumb = await media.thumbnail(outFile, `t_seed_${idx}.jpg`);
      const poster = await media.poster(outFile, `p_seed_${idx}.jpg`);
      const webmFile = path.join(VIDEOS_DIR, `v_seed_${idx}.webm`);
      let webmName = null;
      try {
        await media.toWebWebm(outFile, webmFile, { maxHeight: 1080 });
        if (fs.existsSync(webmFile) && fs.statSync(webmFile).size > 1024) webmName = path.basename(webmFile);
      } catch { /* اختياري */ }
      db.prepare('UPDATE videos SET thumb_path = ?, poster_path = ?, webm_path = ? WHERE id = ?')
        .run(thumb ? path.basename(thumb) : null, poster ? path.basename(poster) : null, webmName, vid);
      const n = rnd(1, 4);
      for (let i = 0; i < n; i += 1) {
        db.prepare('INSERT INTO comments (video_id, author, text) VALUES (?, ?, ?)')
          .run(vid, ['سالم الحربي', 'نورا', 'أبو محمد', 'ليلى', 'مبتدئ'][rnd(0, 4)], comments[rnd(0, comments.length - 1)]);
      }
    })();
  });

  console.log(`✔ تم إنشاء ${VIDEOS.length} فيديو تجريبي في ${CHANNELS.length} قنوات`);
  console.log('✔ شغّل الخادم: npm start  ثم افتح http://localhost:3000');
}

main();
