'use strict';
/**
 * أداة صيانة: إنتاج نسخ WebM للفيديوهات التي لا تملكها،
 * وتحديث مسارات الصور المصغّرة في قاعدة البيانات.
 * التشغيل: node scripts/backfill.js
 */
const fs = require('fs');
const path = require('path');
const { db, VIDEOS_DIR, THUMBS_DIR } = require('../src/db');
const media = require('../src/media');

(async () => {
  const rows = db.prepare("SELECT * FROM videos WHERE status='ready'").all();
  for (const v of rows) {
    const mp4 = v.file_path && path.join(VIDEOS_DIR, v.file_path);
    if (!mp4 || !fs.existsSync(mp4)) { console.log(`✖ مفقود: ${v.id}`); continue; }

    let webmName = v.webm_path || null;
    if (!webmName) {
      const webmFile = path.join(VIDEOS_DIR, `v_${v.id}.webm`);
      try {
        await media.toWebWebm(mp4, webmFile, { maxHeight: 1080 });
        webmName = path.basename(webmFile);
      } catch (e) { console.log(`⚠ WebM فشل (${v.id}): ${e.message}`); }
    }

    let thumb = v.thumb_path || null;
    if (!thumb) {
      const t = await media.thumbnail(mp4, `t_${v.id}.jpg`);
      thumb = t ? path.basename(t) : null;
    }
    let poster = v.poster_path || null;
    if (!poster) {
      const p = await media.poster(mp4, `p_${v.id}.jpg`);
      poster = p ? path.basename(p) : null;
    }

    db.prepare('UPDATE videos SET webm_path = ?, thumb_path = ?, poster_path = ? WHERE id = ?')
      .run(webmName, thumb, poster, v.id);
    console.log(`✔ ${v.id} — ${v.title.slice(0, 40)}`);
  }
  console.log('انتهت المعالجة.');
})();
