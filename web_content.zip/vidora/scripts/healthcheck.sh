#!/usr/bin/env bash
# فحص سريع للتأكد أن كل مكوّنات Vidora يعمل
set -u
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$DIR"

fail=0
ok()   { echo -e "  \033[0;32m✔\033[0m $*"; }
bad()  { echo -e "  \033[0;31m✖\033[0m $*"; fail=1; }

echo "فحص Vidora…"
command -v node >/dev/null 2>&1 && ok "Node.js $(node -v)" || bad "Node.js غير مثبّت"
[ -d node_modules ] && ok "الحزم مثبّتة" || bad "الحزم غير مثبّتة — شغّل npm install"
command -v ffmpeg >/dev/null 2>&1 && ok "ffmpeg متاح" || bad "ffmpeg غير مثبّت"
[ -x vendor/yt-dlp ] && ok "yt-dlp جاهز" || (command -v yt-dlp >/dev/null 2>&1 && ok "yt-dlp في النظام" || bad "yt-dlp غير مثبّت")
[ -f .env ] && ok "ملف .env موجود" || bad ".env غير موجود — انسخ .env.example"
node -e "require('./src/db')" >/dev/null 2>&1 && ok "قاعدة البيانات تعمل" || bad "مشكلة في قاعدة البيانات"
node -e "require('./src/ytdlp');require('./src/media')" >/dev/null 2>&1 && ok "وحدات الاستيراد والوسائط تعمل" || bad "خطأ في الوحدات"

if [ $fail -eq 0 ]; then
  echo -e "\n\033[0;32mكل شيء جاهز — شغّل: npm start\033[0m"
else
  echo -e "\n\033[0;31mيوجد مشاكل — راجع الرسائل أعلاه\033[0m"
fi
exit $fail
