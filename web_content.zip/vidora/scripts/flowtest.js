/* اختبار تدفّق كامل من المتصفح: رفع ملف + استيراد من رابط إنترنت */
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
const os = require('os');

const BASE = process.env.BASE || 'http://localhost:3000';
const OUT = path.join(__dirname, '..', 'shots');
const CREDS = { email: 'admin@vidora.local', password: 'Vidora@2026' };

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, locale: 'ar' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(`PAGEERROR: ${e.message}`));

  // تسجيل الدخول
  await page.goto(`${BASE}/#/login`, { waitUntil: 'networkidle' });
  await page.fill('input[type=email]', CREDS.email);
  await page.fill('input[type=password]', CREDS.password);
  await page.click('.btn.primary');
  await page.waitForTimeout(2000);

  /* ---------------- 1) رفع ملف من الجهاز ---------------- */
  const tmpVideo = path.join(os.tmpdir(), 'vidora_upload_test.mp4');
  if (!fs.existsSync(tmpVideo)) {
    const { execFileSync } = require('child_process');
    execFileSync('ffmpeg', ['-y', '-f', 'lavfi', '-i', 'testsrc=size=640x360:rate=15:duration=6',
      '-f', 'lavfi', '-i', 'sine=frequency=440:duration=6',
      '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-shortest', tmpVideo],
    { stdio: 'ignore' });
  }

  await page.goto(`${BASE}/#/upload`, { waitUntil: 'networkidle' });
  await page.setInputFiles('input[type=file]', tmpVideo);
  await page.waitForTimeout(800);
  const titleInput = page.locator('.panel input.input').first();
  await titleInput.fill('فيديو مرفوع من اختبار المتصفح');
  await page.screenshot({ path: path.join(OUT, '10-upload-form.png') });

  await page.click('button.btn.accent');
  await page.waitForTimeout(1000);
  await page.screenshot({ path: path.join(OUT, '11-upload-progress.png') });

  // انتظار انتهاء الرفع والتحويل
  let uploaded = false;
  for (let i = 0; i < 40; i += 1) {
    await page.waitForTimeout(1500);
    const url = page.url();
    if (url.includes('#/watch/')) { uploaded = true; break; }
    const msg = await page.locator('#upMsg').textContent().catch(() => '');
    if (i % 4 === 0) console.log(`  [رفع] ${msg}`);
  }
  console.log(uploaded ? '✔ الرفع والتحويل نجح والانتقال لصفحة الفيديو' : '✖ فشل الرفع');
  await page.waitForTimeout(1500);
  await page.screenshot({ path: path.join(OUT, '12-upload-done.png') });

  /* ---------------- 2) استيراد من رابط إنترنت ---------------- */
  await page.goto(`${BASE}/#/import`, { waitUntil: 'networkidle' });
  await page.waitForTimeout(1200);
  const urlField = page.locator('.panel input.input').first();
  await urlField.fill('https://download.samplelib.com/mp4/sample-5s.mp4');
  const titleField = page.locator('.panel input.input').nth(1);
  await titleField.fill('مقطع مستورد من الإنترنت عبر الواجهة');
  await page.click('button.btn.accent');
  console.log('  بدأ الاستيراد…');

  let imported = false;
  for (let i = 0; i < 40; i += 1) {
    await page.waitForTimeout(2000);
    const state = await page.locator('.job .state').first().textContent().catch(() => '');
    const msg = await page.locator('.job .job-msg').first().textContent().catch(() => '');
    if (i % 3 === 0) console.log(`  [استيراد] ${state} — ${msg}`);
    if (state && state.includes('اكتملت')) { imported = true; break; }
    if (state && state.includes('فشلت')) break;
  }
  console.log(imported ? '✔ الاستيراد من الرابط نجح' : '✖ الاستيراد لم يكتمل');
  await page.screenshot({ path: path.join(OUT, '13-import-done.png') });

  // التحقق من ظهور الفيديو المستورد في الرئيسية
  await page.goto(`${BASE}/#/`, { waitUntil: 'networkidle' });
  await page.waitForTimeout(1500);
  const cards = await page.locator('.card-title').allTextContents();
  console.log(`✔ عدد البطاقات في الرئيسية: ${cards.length}`);
  console.log('  أول 3:', cards.slice(0, 3).map((t) => t.slice(0, 40)).join(' | '));
  await page.screenshot({ path: path.join(OUT, '14-home-after.png') });

  console.log('\n=== أخطاء ===');
  console.log(errors.length ? errors.join('\n') : 'لا يوجد ✅');
  await browser.close();
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
