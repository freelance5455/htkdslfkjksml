#!/usr/bin/env bash
# =====================================================================
#  Vidora — نشر إنتاجي على Ubuntu/Debian
#  خدمة systemd + Nginx reverse proxy + شهادة SSL مجانية
#  الاستخدام: sudo bash scripts/deploy.sh [your-domain.com]
# =====================================================================
set -euo pipefail

DOMAIN="${1:-}"
APP_DIR="/opt/vidora"
SERVICE="vidora"
USER_NAME="vidora"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;36m'; NC='\033[0m'
step() { echo -e "${BLUE}▶ $*${NC}"; }
ok()   { echo -e "${GREEN}✔ $*${NC}"; }
warn() { echo -e "${YELLOW}! $*${NC}"; }
die()  { echo -e "${RED}✖ $*${NC}"; exit 1; }

[ "$(id -u)" -eq 0 ] || die "شغّل السكربت بصلاحيات الجذر: sudo bash scripts/deploy.sh"
[ -n "$DOMAIN" ] || die "مرّر اسم النطاق: sudo bash scripts/deploy.sh example.com"

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

step "تثبيت الحزم المطلوبة…"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq nginx curl ca-certificates software-properties-common git >/dev/null

if ! command -v node >/dev/null 2>&1; then
  step "تثبيت Node.js 20…"
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash - >/dev/null 2>&1
  apt-get install -y -qq nodejs
fi
ok "Node.js $(node -v)"

if ! command -v ffmpeg >/dev/null 2>&1; then
  step "تثبيت ffmpeg…"
  apt-get install -y -qq ffmpeg
fi
ok "ffmpeg جاهز"

step "إنشاء مستخدم النظام…"
id -u "$USER_NAME" >/dev/null 2>&1 || useradd -m -s /bin/bash "$USER_NAME"

step "نسخ المشروع إلى $APP_DIR…"
mkdir -p "$APP_DIR"
rsync -a --delete --exclude 'node_modules' --exclude 'data' --exclude '.git' "$SRC_DIR/" "$APP_DIR/"
cd "$APP_DIR"
[ -f .env ] || { cp .env.example .env; sed -i "s|^JWT_SECRET=.*|JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(48).toString('hex'))")|" .env; }
mkdir -p data/media/videos data/media/thumbs data/media/subs data/tmp

step "تثبيت حزم Node.js…"
npm install --omit=dev --no-audit --no-fund >/dev/null

if [ ! -x vendor/yt-dlp ]; then
  step "تنزيل yt-dlp…"
  curl -fsSL -o vendor/yt-dlp https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp \
    && chmod +x vendor/yt-dlp || warn "تعذّر تنزيل yt-dlp"
fi

chown -R "$USER_NAME":"$USER_NAME" "$APP_DIR"

step "إنشاء خدمة systemd…"
cat > /etc/systemd/system/${SERVICE}.service <<EOF
[Unit]
Description=Vidora — منصة الفيديو المفتوحة
After=network.target

[Service]
Type=simple
User=$USER_NAME
WorkingDirectory=$APP_DIR
Environment=NODE_ENV=production
EnvironmentFile=$APP_DIR/.env
ExecStart=/usr/bin/node $APP_DIR/server.js
Restart=always
RestartSec=5
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable ${SERVICE} >/dev/null
systemctl restart ${SERVICE}
ok "الخدمة تعمل على المنفذ 3000"

step "إعداد Nginx…"
cat > /etc/nginx/sites-available/${SERVICE}.conf <<EOF
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN;

    client_max_body_size 4096M;
    proxy_read_timeout 3600s;
    proxy_send_timeout 3600s;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_buffering off;
    }
}
EOF
ln -sf /etc/nginx/sites-available/${SERVICE}.conf /etc/nginx/sites-enabled/${SERVICE}.conf
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
ok "Nginx جاهز"

step "تفعيل شهادة SSL (Let's Encrypt)…"
apt-get install -y -qq certbot python3-certbot-nginx >/dev/null
certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos --register-unsafely-without-email \
  --redirect || warn "فشل SSL — يمكنك تحديثه لاحقاً: certbot --nginx -d $DOMAIN"

echo ""
echo -e "${GREEN}✔ اكتمل النشر!${NC}"
echo -e "   الموقع: ${GREEN}https://$DOMAIN${NC}"
echo ""
echo "   أوامر مفيدة:"
echo "     sudo systemctl status $SERVICE"
echo "     sudo systemctl restart $SERVICE"
echo "     sudo journalctl -u $SERVICE -f"
echo ""
