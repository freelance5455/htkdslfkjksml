#!/usr/bin/env bash
# =====================================================================
#  Vidora — سكربت التثبيت والتشغيل
#  الاستخدام:  bash install.sh          # تثبيت + تجهيز
#              bash install.sh --seed   # تثبيت + محتوى تجريبي
#              bash install.sh --reset  # حذف كل البيانات والبدء من جديد
# =====================================================================
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;36m'; NC='\033[0m'
step() { echo -e "${BLUE}▶ $*${NC}"; }
ok()   { echo -e "${GREEN}✔ $*${NC}"; }
warn() { echo -e "${YELLOW}! $*${NC}"; }
die()  { echo -e "${RED}✖ $*${NC}"; exit 1; }

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║            Vidora — منصة الفيديو المفتوحة           ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════╝${NC}"
echo ""

# ---------------------------- 1) المتطلبات ----------------------------
step "فحص المتطلبات…"

if ! command -v node >/dev/null 2>&1; then
  warn "Node.js غير مثبّت. جارٍ تثبيته…"
  if command -v apt-get >/dev/null 2>&1; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash - >/dev/null 2>&1 || true
    apt-get update -qq && apt-get install -y -qq nodejs
  elif command -v apk >/dev/null 2>&1; then
    apk add --no-cache nodejs npm
  else
    die "ثبّت Node.js 18+ يدوياً ثم أعد تشغيل السكربت."
  fi
fi
NODE_MAJOR=$(node -v | sed 's/v\([0-9]*\).*/\1/')
[ "$NODE_MAJOR" -ge 18 ] || die "مطلوب Node.js 18 أو أحدث (الحالي: $(node -v))."
ok "Node.js $(node -v)"

if ! command -v ffmpeg >/dev/null 2>&1; then
  warn "ffmpeg غير مثبّت — ضروري لتحويل الفيديو."
  if command -v apt-get >/dev/null 2>&1; then
    apt-get update -qq && apt-get install -y -qq ffmpeg
  elif command -v apk >/dev/null 2>&1; then
    apk add --no-cache ffmpeg
  else
    warn "تثبيت ffmpeg يدوياً مطلوب: https://ffmpeg.org/download.html"
  fi
fi
command -v ffmpeg >/dev/null 2>&1 && ok "ffmpeg $(ffmpeg -version | head -1 | cut -d' ' -f3)" || warn "ffmpeg غير متاح — بعض الوظائف لن تعمل."

# ---------------------------- 2) yt-dlp ----------------------------
step "تجهيز yt-dlp (محرك تنزيل الفيديوهات)…"
mkdir -p vendor
if [ ! -x vendor/yt-dlp ]; then
  if command -v yt-dlp >/dev/null 2>&1; then
    ln -sf "$(command -v yt-dlp)" vendor/yt-dlp
  else
    URL="https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp"
    if curl -fsSL -o vendor/yt-dlp "$URL"; then
      chmod +x vendor/yt-dlp
    else
      warn "تعذّر تنزيل yt-dlp — سيعمل الاستيراد إن كان مثبتاً في النظام."
    fi
  fi
fi
[ -x vendor/yt-dlp ] && ok "yt-dlp $(./vendor/yt-dlp --version 2>/dev/null | head -1)" || warn "yt-dlp غير متاح."

# ---------------------------- 3) الحزم ----------------------------
step "تثبيت حزم Node.js…"
npm install --omit=dev --no-audit --no-fund
ok "تم تثبيت الحزم."

# ---------------------------- 4) الإعدادات ----------------------------
if [ ! -f .env ]; then
  step "إنشاء ملف الإعدادات .env…"
  cp .env.example .env
  SECRET=$(node -e "console.log(require('crypto').randomBytes(48).toString('hex'))")
  PASS=$(node -e "console.log('Vid-'+require('crypto').randomBytes(6).toString('hex'))")
  sed -i "s|^JWT_SECRET=.*|JWT_SECRET=$SECRET|" .env
  sed -i "s|^ADMIN_PASSWORD=.*|ADMIN_PASSWORD=$PASS|" .env
  echo ""
  echo -e "${GREEN}  بيانات المدير:${NC}"
  echo -e "    البريد: admin@vidora.local"
  echo -e "    كلمة المرور: ${YELLOW}$PASS${NC}"
  echo -e "  (غيّرها من لوحة التحكم أو من ملف .env)"
  echo ""
fi

mkdir -p data/media/videos data/media/thumbs data/media/subs data/tmp

# ---------------------------- 5) اختياري: تنظيف/بذور ----------------------------
if [ "${1:-}" = "--reset" ]; then
  warn "حذف كل البيانات الحالية…"
  rm -rf data/vidora.sqlite data/vidora.sqlite-wal data/vidora.sqlite-shm data/media
  mkdir -p data/media/videos data/media/thumbs data/media/subs data/tmp
fi

if [ "${1:-}" = "--seed" ]; then
  step "إنشاء المحتوى التجريبي…"
  npm run seed || warn "تعذّر إنشاء المحتوى التجريبي."
fi

# ---------------------------- 6) التشغيل ----------------------------
echo ""
ok "اكتمل التثبيت بنجاح."
echo ""
echo -e "${GREEN}  لبدء الخادم:${NC}"
echo "    npm start                 # تشغيل مباشر"
echo "    npm run dev               # تشغيل مع إعادة التحميل التلقائي"
echo ""
echo -e "${GREEN}  عند النشر على سيرفر (Ubuntu/Debian):${NC}"
echo "    sudo bash scripts/deploy.sh   # خدمة systemd + Nginx + SSL"
echo ""
echo -e "${GREEN}  افتح المتصفح على:${NC}  http://localhost:3000"
echo ""
