# Scrap अड्डा — Native Android TTS (FIXED)

This build fixes the `appassets.androidplatform.net/web/index.html` / `ERR_HTTP_RESPONSE_CODE_FAILURE` problem by loading the bundled HTML directly from `file:///android_asset/index.html`.

It also connects the HTML voice guide to Android native Text-to-Speech (`hi-IN`). No AI voice and no MP3 files are required.

First launch shows:
- हिंदी आवाज़ निर्देश toggle
- Notifications toggle
- Start button

Voice guides are sent from the HTML to the native Android TTS bridge. Browser speech synthesis remains only as a fallback when the same HTML is opened in a normal browser.

Build with Android Studio or GitHub Actions.
