package com.scrapadda.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady=false, voiceEnabled=true, notificationsEnabled=true;
    private SharedPreferences prefs;
    private static final int REQ=77;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("scrap_adda",MODE_PRIVATE);
        voiceEnabled=prefs.getBoolean("voice_enabled",true);
        notificationsEnabled=prefs.getBoolean("notifications_enabled",true);
        tts=new TextToSpeech(this,this);
        setupWebView();
        requestRuntimePermissions();
        if(!prefs.getBoolean("voice_setup_done",false)) showSetup();
    }

    private void setupWebView(){
        webView=new WebView(this);
        setContentView(webView);
        WebSettings ws=webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        ws.setJavaScriptCanOpenWindowsAutomatically(true);
        webView.setBackgroundColor(Color.rgb(244,246,244));
        webView.addJavascriptInterface(new TTSBridge(),"AndroidTTS");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public void onPermissionRequest(final PermissionRequest r){ runOnUiThread(() -> r.grant(r.getResources())); }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void requestRuntimePermissions(){
        if(Build.VERSION.SDK_INT>=33 && notificationsEnabled && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},91);
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.CAMERA,Manifest.permission.ACCESS_FINE_LOCATION},REQ);
    }

    private void showSetup(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(52,8,52,4);
        TextView info=new TextView(this);
        info.setText("Scrap अड्डा में आवाज़ निर्देश\n\nहर स्क्रीन पर छोटा हिंदी voice guide सुनाया जाएगा। यह फोन के अपने Hindi Text-to-Speech engine से चलेगा — AI या इंटरनेट की जरूरत नहीं।");
        info.setTextSize(16); info.setTextColor(Color.rgb(22,36,28)); box.addView(info);
        Switch voice=new Switch(this); voice.setText("आवाज़ निर्देश"); voice.setTextSize(15); voice.setChecked(voiceEnabled); voice.setPadding(0,18,0,6); box.addView(voice);
        Switch notif=new Switch(this); notif.setText("सूचनाएं / Notifications"); notif.setTextSize(15); notif.setChecked(notificationsEnabled); box.addView(notif);
        AlertDialog d=new AlertDialog.Builder(this).setTitle("शुरुआत की सेटिंग").setView(box).setPositiveButton("शुरू करें",null).setCancelable(false).create();
        voice.setOnCheckedChangeListener((button,checked)->voiceEnabled=checked);
        notif.setOnCheckedChangeListener((button,checked)->notificationsEnabled=checked);
        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            prefs.edit().putBoolean("voice_enabled",voiceEnabled).putBoolean("notifications_enabled",notificationsEnabled).putBoolean("voice_setup_done",true).apply();
            if(Build.VERSION.SDK_INT>=33 && notificationsEnabled && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},91);
            if(voiceEnabled) speak("नमस्कार! Scrap अड्डा में आपका स्वागत है। अपनी भूमिका चुनें।");
            d.dismiss();
        }));
        d.show();
    }

    @Override public void onInit(int status){
        if(status==TextToSpeech.SUCCESS){
            int r=tts.setLanguage(new Locale("hi","IN"));
            ttsReady=r!=TextToSpeech.LANG_MISSING_DATA && r!=TextToSpeech.LANG_NOT_SUPPORTED;
            tts.setSpeechRate(0.92f); tts.setPitch(1.0f);
        }
    }
    private void speak(String text){ if(!voiceEnabled || !ttsReady || text==null || text.trim().isEmpty()) return; tts.stop(); tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"scrap_adda_guide"); }

    private class TTSBridge{
        @JavascriptInterface public void speak(String text){ runOnUiThread(()->speak(text)); }
        @JavascriptInterface public void stop(){ runOnUiThread(()->{if(tts!=null)tts.stop();}); }
        @JavascriptInterface public void unlock(){ }
        @JavascriptInterface public boolean isEnabled(){ return voiceEnabled; }
    }
    @Override protected void onDestroy(){ if(tts!=null){tts.stop();tts.shutdown();} if(webView!=null)webView.destroy(); super.onDestroy(); }
}
