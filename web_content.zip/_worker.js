// Cloudflare Pages Edge Worker (_worker.js) — Server-side Meta Graph API Relay & KV Persistence
// Bypasses office firewall blocks on facebook.com without VPN or proxy!
// --- Archive des pubs : union appareil + cloud, la suppression/relance la plus recente l'emporte ---
function mergeArchiveOnServer(existing, incoming) {
  const removed = {};
  [existing && existing.archivedRemoved, incoming && incoming.archivedRemoved].forEach((src) => {
    if (!src || typeof src !== 'object') return;
    Object.keys(src).forEach((k) => {
      removed[k] = Math.max(Number(removed[k]) || 0, Number(src[k]) || 0);
    });
  });
  const map = new Map();
  const lists = [
    existing && Array.isArray(existing.archivedAds) ? existing.archivedAds : [],
    incoming && Array.isArray(incoming.archivedAds) ? incoming.archivedAds : []
  ];
  lists.forEach((list) => {
    list.forEach((a) => {
      if (!a || !a.id) return;
      if ((Number(removed[a.id]) || 0) >= (Number(a.archivedAt) || 0)) return;
      const prev = map.get(a.id);
      if (!prev || (Number(a.archivedAt) || 0) > (Number(prev.archivedAt) || 0)) map.set(a.id, a);
    });
  });
  const keys = Object.keys(removed).sort((x, y) => removed[y] - removed[x]).slice(0, 500);
  const trimmed = {};
  keys.forEach((k) => { trimmed[k] = removed[k]; });
  return { ads: Array.from(map.values()), removed: trimmed };
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const metaPath = ['', 'api', 'meta'].join('/');
    const imgPath = ['', 'api', 'img'].join('/');
    const statePath = ['', 'api', 'state'].join('/');

    if (url.pathname === imgPath) {
      try {
        const b64 = url.searchParams.get('b64') || '';
        const rawUrl = b64 ? atob(b64) : (url.searchParams.get('url') || '');
        if (!rawUrl || !rawUrl.startsWith('https://')) {
          return new Response('Invalid image URL', { status: 400 });
        }
        const imgResp = await fetch(rawUrl, {
          method: 'GET',
          headers: {
            'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
          }
        });
        if (!imgResp.ok) {
          return new Response('Upstream image error', { status: imgResp.status });
        }
        const contentType = imgResp.headers.get('content-type') || 'image/jpeg';
        return new Response(imgResp.body, {
          status: 200,
          headers: {
            'Content-Type': contentType,
            'Access-Control-Allow-Origin': '*',
            'Cache-Control': 'public, max-age=86400'
          }
        });
      } catch (imgErr) {
        return new Response('Image relay error', { status: 502 });
      }
    }

    if (url.pathname === metaPath) {
      if (request.method === 'OPTIONS') {
        return new Response(null, {
          headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type'
          }
        });
      }
      try {
        let targetUrl = url.searchParams.get('url') || '';
        if (!targetUrl && request.method === 'POST') {
          const body = await request.json();
          if (body && body.b64) {
            targetUrl = atob(body.b64);
          } else if (body && body.url) {
            targetUrl = body.url;
          }
        }
        if (!targetUrl || !targetUrl.startsWith('https://graph.facebook.com/')) {
          return new Response(JSON.stringify({ error: { message: 'Invalid Meta Graph URL' } }), {
            status: 400,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
          });
        }
        const metaResp = await fetch(targetUrl, {
          method: 'GET',
          headers: { 'Accept': 'application/json', 'User-Agent': 'MetaCardGuard-Cloudflare-Relay/2.0' }
        });
        const text = await metaResp.text();
        return new Response(text, {
          status: metaResp.status,
          headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'Access-Control-Allow-Origin': '*',
            'Cache-Control': 'no-store'
          }
        });
      } catch (err) {
        return new Response(JSON.stringify({ error: { message: 'Cloudflare Relay Error: ' + (err.message || String(err)) } }), {
          status: 502,
          headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
        });
      }
    }

    if (url.pathname === statePath) {
      // CORS : l'authentification repose sur la cle X-State-Key (pas sur des cookies), l'APK (origine WebView) peut donc appeler cet endpoint
      const reqOrigin = request.headers.get('Origin') || '';
      const corsState = reqOrigin ? { 'Access-Control-Allow-Origin': reqOrigin, 'Vary': 'Origin' } : {};
      if (request.method === 'OPTIONS') {
        return new Response(null, { status: 204, headers: { ...corsState, 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, X-State-Key, Accept', 'Access-Control-Max-Age': '86400' } });
      }
      // --- Protection : la clé X-State-Key doit correspondre au secret STATE_SECRET du Worker ---
      const stateHeaders = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...corsState };
      const expectedKey = env && env.STATE_SECRET ? String(env.STATE_SECRET) : '';
      if (!expectedKey) {
        return new Response(JSON.stringify({ status: 'error', message: 'STATE_SECRET non configure sur le Worker' }), { status: 503, headers: stateHeaders });
      }
      const providedKey = request.headers.get('X-State-Key') || '';
      let diff = providedKey.length ^ expectedKey.length;
      for (let i = 0; i < expectedKey.length; i++) diff |= (providedKey.charCodeAt(i) || 0) ^ expectedKey.charCodeAt(i);
      if (diff !== 0) {
        return new Response(JSON.stringify({ status: 'unauthorized' }), { status: 401, headers: stateHeaders });
      }

      const cacheKeyReq = new Request('https://metacard-edge-state.internal/v1/state', { method: 'GET' });
      const readStoredState = async () => {
        try {
          if (env && env.METACARD_KV) {
            const kvRaw = await env.METACARD_KV.get('metacard_state');
            if (kvRaw) return JSON.parse(kvRaw);
          }
        } catch (e) {}
        try {
          if (typeof caches !== 'undefined' && caches.default) {
            const cachedResp = await caches.default.match(cacheKeyReq);
            if (cachedResp) {
              const txt = await cachedResp.text();
              if (txt) return JSON.parse(txt);
            }
          }
        } catch (e) {}
        if (globalThis.__METACARD_EDGE_STATE__) {
          return globalThis.__METACARD_EDGE_STATE__;
        }
        return null;
      };

      const writeStoredState = async (stateObj) => {
        globalThis.__METACARD_EDGE_STATE__ = stateObj;
        const jsonStr = JSON.stringify(stateObj);
        try {
          if (env && env.METACARD_KV) {
            await env.METACARD_KV.put('metacard_state', jsonStr);
          }
        } catch (e) {}
        try {
          if (typeof caches !== 'undefined' && caches.default) {
            const respToCache = new Response(jsonStr, {
              headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'Cache-Control': 'public, max-age=31536000'
              }
            });
            await caches.default.put(cacheKeyReq, respToCache);
          }
        } catch (e) {}
      };

      const mergeOverridesOnServer = (oldMap, newMap) => {
        const res = {};
        const a = (oldMap && typeof oldMap === 'object') ? oldMap : {};
        const b = (newMap && typeof newMap === 'object') ? newMap : {};
        const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
        for (const k of keys) {
          const ovA = a[k] || {};
          const ovB = b[k] || {};
          const aCustomT = Boolean(ovA.customThreshold || (ovA.threshold && Number(ovA.threshold) !== 100));
          const bCustomT = Boolean(ovB.customThreshold || (ovB.threshold && Number(ovB.threshold) !== 100));
          let threshold = 100;
          let customThreshold = false;
          if (bCustomT && !aCustomT) { threshold = Number(ovB.threshold); customThreshold = true; }
          else if (aCustomT && !bCustomT) { threshold = Number(ovA.threshold); customThreshold = true; }
          else if (bCustomT && aCustomT) {
            threshold = (Number(ovB.updatedAt || 0) >= Number(ovA.updatedAt || 0)) ? Number(ovB.threshold) : Number(ovA.threshold);
            customThreshold = true;
          } else {
            threshold = Number(ovB.threshold || ovA.threshold || 100);
          }

          const aCustomD = Boolean(ovA.customBillingDay || (ovA.billingDay && String(ovA.billingDay).toLowerCase() !== 'mensuel'));
          const bCustomD = Boolean(ovB.customBillingDay || (ovB.billingDay && String(ovB.billingDay).toLowerCase() !== 'mensuel'));
          let billingDay = 'Mensuel';
          let customBillingDay = false;
          if (bCustomD && !aCustomD) { billingDay = ovB.billingDay; customBillingDay = true; }
          else if (aCustomD && !bCustomD) { billingDay = ovA.billingDay; customBillingDay = true; }
          else if (bCustomD && aCustomD) {
            billingDay = (Number(ovB.updatedAt || 0) >= Number(ovA.updatedAt || 0)) ? ovB.billingDay : ovA.billingDay;
            customBillingDay = true;
          } else {
            billingDay = ovB.billingDay || ovA.billingDay || 'Mensuel';
          }

          res[k] = {
            ...ovA,
            ...ovB,
            threshold,
            customThreshold,
            billingDay,
            customBillingDay,
            cardId: ovB.cardId || ovA.cardId,
            cardLast4: ovB.cardLast4 || ovA.cardLast4,
            cardLabel: ovB.cardLabel || ovA.cardLabel,
            updatedAt: Math.max(Number(ovA.updatedAt || 0), Number(ovB.updatedAt || 0))
          };
        }
        return res;
      };

      if (request.method === 'GET') {
        const stored = await readStoredState();
        if (stored) {
          return new Response(JSON.stringify({ ...stored, metaAppSecret: '' }), { headers: stateHeaders });
        }
        return new Response(JSON.stringify({ status: 'empty' }), { status: 404, headers: stateHeaders });
      }
      if (request.method === 'POST') {
        try {
          const incoming = await request.json();
          const existing = (await readStoredState()) || {};
          const mergedOverrides = mergeOverridesOnServer(existing.accountOverrides, incoming.accountOverrides);
          const mergedArchive = mergeArchiveOnServer(existing, incoming);
          const mergedState = {
            ...existing,
            ...incoming,
            accountOverrides: mergedOverrides,
            archivedAds: mergedArchive.ads,
            archivedRemoved: mergedArchive.removed,
            metaAppSecret: '',
            savedToken: incoming.savedToken || existing.savedToken || ''
          };
          await writeStoredState(mergedState);
          return new Response(JSON.stringify({
            ok: true,
            mergedAccountOverrides: mergedOverrides,
            mergedCards: mergedState.cards || []
          }), { headers: stateHeaders });
        } catch (e) {
          return new Response(JSON.stringify({ status: 'error', message: String(e) }), { status: 200, headers: stateHeaders });
        }
      }
      return new Response(JSON.stringify({ status: 'method_not_allowed' }), { status: 405, headers: stateHeaders });
    }

    if (env && env.ASSETS) {
      return env.ASSETS.fetch(request);
    }
    return fetch(request);
  }
};
