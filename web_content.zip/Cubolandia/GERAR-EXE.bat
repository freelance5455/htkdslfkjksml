@echo off
cd /d "%~dp0"
call npm install
call npm run exe
echo.
echo Pronto! O .exe esta na pasta dist\
pause
