@echo off
cd /d "%~dp0"
call npm install
if not exist android call npx cap add android
call npx cap sync android
cd android
call gradlew.bat assembleDebug
echo.
echo Pronto! O APK esta em android\app\build\outputs\apk\debug\app-debug.apk
pause
