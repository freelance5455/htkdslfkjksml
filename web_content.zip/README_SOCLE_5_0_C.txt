CGD V117 — SOCLE 5.0-C : CRÉATION DU MANAGER

Cette étape ajoute l'écran de création du manager avant la sélection de la galaxie et du club.

Contenu :
- prénom et nom ;
- nationalité et profil ;
- 6 avatars prédéfinis ;
- 5 niveaux d'expérience ;
- 4 philosophies de management ;
- sauvegarde locale du profil préparatoire.

IMPORTANT : l'étape 5.0-C n'ouvre pas encore la carrière. Le manager reste un brouillon tant que la galaxie, le club et le mode de carrière ne sont pas confirmés à l'étape 5.0-D.
Les anciennes sauvegardes sont conservées et complétées avec un champ managerDraft vide.

Vérification technique :
Depuis le dossier v117, lancer `npm test` avec Node.js.
Pour ouvrir l'application dans un navigateur, utiliser un serveur HTTP local à la racine du dossier v117 (les modules JavaScript ES ne sont pas garantis depuis file://).
