NFC CAMERA - WEB APP

1. Άνοιξε το index.html σε σύγχρονο browser.
2. Για χρήση κάμερας, ο browser μπορεί να απαιτεί HTTPS ή localhost.
3. Για να γίνει APK, βάλε αυτά τα αρχεία σε έναν WebView/PWA-to-APK builder.

ΣΗΜΑΝΤΙΚΟ:
Αυτό διαβάζει QR/barcode μέσω κάμερας. Δεν διαβάζει πραγματικό NFC σήμα.
