const statusEl=document.getElementById('status');
const cardsEl=document.getElementById('cards');
let scanner=null;

function loadCards(){
 const cards=JSON.parse(localStorage.getItem('nfccamera_cards')||'[]');
 cardsEl.innerHTML=cards.length?cards.map((x,i)=>`<div class="card"><b>Κάρτα ${i+1}</b><br>${escapeHtml(x)}</div>`).join(''):'<div class="empty">Δεν υπάρχουν αποθηκευμένες κάρτες.</div>';
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
function saveCard(value){
 const cards=JSON.parse(localStorage.getItem('nfccamera_cards')||'[]');
 if(!cards.includes(value)){cards.unshift(value);localStorage.setItem('nfccamera_cards',JSON.stringify(cards.slice(0,50)));}
 loadCards();
}
document.getElementById('start').onclick=async()=>{
 try{
   scanner=new Html5Qrcode("reader");
   statusEl.textContent='Στρέψε την κάμερα στον κωδικό...';
   await scanner.start({facingMode:"environment"},{fps:10,qrbox:{width:250,height:180}},async text=>{
     statusEl.textContent='✓ Κάρτα αναγνωρίστηκε: '+text;
     saveCard(text);
     try{await scanner.stop();}catch(e){}
   },()=>{});
 }catch(e){
   statusEl.textContent='Δεν ήταν δυνατή η εκκίνηση της κάμερας. Έλεγξε την άδεια κάμερας.';
 }
};
loadCards();
