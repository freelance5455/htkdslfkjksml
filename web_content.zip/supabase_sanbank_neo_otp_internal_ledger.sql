-- SANBANK BR DIGITAL — compra interna Cartão Neo com token de confirmação
-- Esta migração NÃO integra Visa nem processa cobranças externas. Atualiza somente o ledger interno.
begin;
create extension if not exists pgcrypto;

create table if not exists public.sanbank_neo_card_challenges (
  id uuid primary key default gen_random_uuid(),
  account text not null references public.sanbank_accounts(account) on delete cascade,
  card_record_id bigint not null references public.sanbank_legacy_records(id),
  amount numeric(18,2) not null check (amount > 0),
  description text not null,
  code_hash text not null,
  status text not null default 'pending' check (status in ('pending','completed','expired','failed','superseded','declined')),
  attempts integer not null default 0,
  requested_by text not null,
  created_at timestamptz not null default timezone('utc', now()),
  expires_at timestamptz not null,
  completed_at timestamptz,
  transaction_id text,
  result jsonb not null default '{}'::jsonb
);
create index if not exists sanbank_neo_card_challenges_account_idx
  on public.sanbank_neo_card_challenges(account, created_at desc);
create index if not exists sanbank_neo_card_challenges_pending_idx
  on public.sanbank_neo_card_challenges(account, expires_at) where status='pending';

-- Fila privada de entrega ao inbox do próprio titular. O cliente não tem SELECT direto.
create table if not exists public.sanbank_neo_otp_delivery (
  challenge_id uuid primary key references public.sanbank_neo_card_challenges(id) on delete cascade,
  account text not null references public.sanbank_accounts(account) on delete cascade,
  code_value text not null check (code_value ~ '^[0-9]{6}$'),
  created_at timestamptz not null default timezone('utc', now())
);
create index if not exists sanbank_neo_otp_delivery_account_idx
  on public.sanbank_neo_otp_delivery(account, created_at);

create table if not exists public.sanbank_neo_card_transactions (
  id text primary key,
  challenge_id uuid not null unique references public.sanbank_neo_card_challenges(id),
  account text not null references public.sanbank_accounts(account),
  card_record_id bigint not null references public.sanbank_legacy_records(id),
  amount numeric(18,2) not null,
  description text not null,
  status text not null default 'completed',
  source text not null default 'internal_supabase_ledger',
  network_authorized boolean not null default false,
  created_at timestamptz not null default timezone('utc', now())
);
create index if not exists sanbank_neo_card_transactions_account_idx
  on public.sanbank_neo_card_transactions(account, created_at desc);

alter table public.sanbank_neo_card_challenges enable row level security;
alter table public.sanbank_neo_otp_delivery enable row level security;
alter table public.sanbank_neo_card_transactions enable row level security;
revoke all on table public.sanbank_neo_card_challenges from public, anon, authenticated;
revoke all on table public.sanbank_neo_otp_delivery from public, anon, authenticated;
revoke all on table public.sanbank_neo_card_transactions from public, anon, authenticated;

create or replace function public.sanbank_neo_terminal_begin(p_account text, p_amount numeric, p_description text)
returns jsonb
language plpgsql security definer
set search_path=public,extensions,pg_temp
as $$
declare
  v_me text := public.sanbank_current_account();
  v_admin boolean := public.sanbank_is_admin();
  v_account text := trim(coalesce(p_account,''));
  v_desc text := trim(coalesce(p_description,''));
  v_amount numeric(18,2) := round(coalesce(p_amount,0),2);
  v_account_row public.sanbank_accounts%rowtype;
  v_card public.sanbank_legacy_records%rowtype;
  v_payload jsonb;
  v_status text;
  v_total numeric(18,2);
  v_used numeric(18,2);
  v_invoice numeric(18,2);
  v_available numeric(18,2);
  v_challenge uuid := gen_random_uuid();
  v_random bytea;
  v_code text;
  v_hash text;
begin
  if v_me is null then raise exception 'SANBANK_SESSION_REQUIRED'; end if;
  if not v_admin and v_me <> v_account then raise exception 'SANBANK_ACCESS_DENIED'; end if;
  if v_account !~ '^[0-9]{6}$' then raise exception 'SANBANK_NEO_INVALID_ACCOUNT'; end if;
  if v_amount <= 0 or v_amount > 1000000 then raise exception 'SANBANK_NEO_INVALID_AMOUNT'; end if;
  if v_desc = '' or length(v_desc) > 80 then raise exception 'SANBANK_NEO_INVALID_DESCRIPTION'; end if;

  perform pg_advisory_xact_lock(hashtextextended('sanbank-neo-otp:'||v_account,0));
  update public.sanbank_neo_card_challenges set status='expired'
    where account=v_account and status='pending' and expires_at <= timezone('utc',now());
  update public.sanbank_neo_card_challenges set status='superseded'
    where account=v_account and status='pending';
  delete from public.sanbank_neo_otp_delivery where account=v_account;
  if (select count(*) from public.sanbank_neo_card_challenges
      where account=v_account and created_at > timezone('utc',now())-interval '5 minutes') >= 5 then
    raise exception 'SANBANK_NEO_RATE_LIMIT';
  end if;

  select * into v_account_row from public.sanbank_accounts where account=v_account for update;
  if not found or coalesce(v_account_row.access_enabled,true) is false
     or coalesce(v_account_row.client_access_enabled,true) is false then
    raise exception 'SANBANK_NEO_ACCOUNT_UNAVAILABLE';
  end if;
  if coalesce(public.sanbank_bool(v_account_row.legacy_data->>'security_locked'),false)
     or coalesce(public.sanbank_bool(v_account_row.legacy_data->>'account_locked'),false)
     or coalesce(public.sanbank_bool(v_account_row.legacy_data->>'security_balance_blocked'),false)
     or coalesce(public.sanbank_bool(v_account_row.legacy_data->>'available_balance_blocked'),false)
     or coalesce(public.sanbank_bool(v_account_row.legacy_data->>'balance_security_blocked'),false)
     or lower(trim(coalesce(v_account_row.legacy_data->>'security_status',''))) in ('bloqueado','bloqueada','blocked','locked','security_locked','security_blocked','bloqueado_por_seguranca','bloqueado_por_segurança')
     or lower(trim(coalesce(v_account_row.account_status,''))) in ('bloqueado','bloqueada','blocked','locked','cancelado','cancelada') then
    raise exception 'SANBANK_NEO_ACCOUNT_BLOCKED';
  end if;
  select * into v_card from public.sanbank_legacy_records r
    where r.source_tab='cartoes_neo' and coalesce(r.account,r.payload->>'account')=v_account
    order by r.source_row desc limit 1 for update;
  if v_card.id is null then raise exception 'SANBANK_NEO_CARD_NOT_FOUND'; end if;
  v_payload := coalesce(v_card.payload,'{}'::jsonb);
  v_status := lower(trim(coalesce(v_payload->>'status','ativo')));
  if v_status in ('bloqueado','bloqueada','blocked','locked','suspenso','suspensa','cancelado','cancelada','canceled','cancelled')
     or coalesce(public.sanbank_bool(v_payload->>'security_locked'),false)
     or coalesce(public.sanbank_bool(v_payload->>'card_security_blocked'),false) then
    raise exception 'SANBANK_NEO_CARD_BLOCKED';
  end if;
  v_total := coalesce(public.sanbank_decimal(v_payload->>'limit_total'),0);
  v_used := coalesce(public.sanbank_decimal(v_payload->>'limit_used'),0);
  v_invoice := greatest(coalesce(public.sanbank_decimal(v_payload->>'invoice_amount'),0),coalesce(public.sanbank_decimal(v_payload->>'fatura'),0),v_used);
  v_available := greatest(0,v_total-greatest(v_used,v_invoice));
  if v_amount > v_available then raise exception 'SANBANK_NEO_INSUFFICIENT_LIMIT'; end if;

  v_random := gen_random_bytes(4);
  v_code := lpad(((get_byte(v_random,0)::bigint*16777216 + get_byte(v_random,1)::bigint*65536 + get_byte(v_random,2)::bigint*256 + get_byte(v_random,3)::bigint) % 1000000)::text,6,'0');
  v_hash := encode(digest(v_challenge::text||':'||v_code,'sha256'),'hex');
  insert into public.sanbank_neo_card_challenges(id,account,card_record_id,amount,description,code_hash,status,attempts,requested_by,expires_at)
  values(v_challenge,v_account,v_card.id,v_amount,v_desc,v_hash,'pending',0,v_me,timezone('utc',now())+interval '60 seconds');
  insert into public.sanbank_neo_otp_delivery(challenge_id,account,code_value)
  values(v_challenge,v_account,v_code);
  return jsonb_build_object('ok',true,'challenge_id',v_challenge,'account',v_account,'amount',v_amount,
    'expires_at',timezone('utc',now())+interval '60 seconds','ttl_seconds',60,
    'delivery','in_app_notification','ledger_only',true,'network_authorized',false);
end;
$$;

create or replace function public.sanbank_neo_terminal_inbox()
returns jsonb
language plpgsql security definer
set search_path=public,extensions,pg_temp
as $$
declare
  v_me text := public.sanbank_current_account();
  v_row record;
begin
  if v_me is null or public.sanbank_is_admin() then raise exception 'SANBANK_SESSION_REQUIRED'; end if;
  delete from public.sanbank_neo_otp_delivery d
   where d.account=v_me and not exists (select 1 from public.sanbank_neo_card_challenges c
     where c.id=d.challenge_id and c.status='pending' and c.expires_at>timezone('utc',now()));
  select d.challenge_id,d.code_value,c.amount,c.description,c.expires_at
    into v_row
    from public.sanbank_neo_otp_delivery d
    join public.sanbank_neo_card_challenges c on c.id=d.challenge_id
   where d.account=v_me and c.status='pending' and c.expires_at>timezone('utc',now())
   order by d.created_at desc limit 1;
  if not found then return jsonb_build_object('ok',true,'pending',false); end if;
  return jsonb_build_object('ok',true,'pending',true,'challenge_id',v_row.challenge_id,
    'code',v_row.code_value,'amount',v_row.amount,'description',v_row.description,'expires_at',v_row.expires_at,
    'ttl_seconds',greatest(0,floor(extract(epoch from (v_row.expires_at-now())))::integer));
end;
$$;

create or replace function public.sanbank_neo_terminal_status(p_challenge_id uuid)
returns jsonb
language plpgsql stable security definer
set search_path=public,extensions,pg_temp
as $$
declare
  v_me text := public.sanbank_current_account();
  v_row public.sanbank_neo_card_challenges%rowtype;
begin
  if v_me is null then raise exception 'SANBANK_SESSION_REQUIRED'; end if;
  select * into v_row from public.sanbank_neo_card_challenges where id=p_challenge_id;
  if not found or (v_row.account<>v_me and not public.sanbank_is_admin()) then raise exception 'SANBANK_ACCESS_DENIED'; end if;
  return jsonb_build_object('ok',true,'challenge_id',v_row.id,'status',v_row.status,
    'expires_at',v_row.expires_at,'transaction_id',v_row.transaction_id,'result',v_row.result);
end;
$$;

create or replace function public.sanbank_neo_terminal_pending()
returns jsonb
language plpgsql stable security definer
set search_path=public,extensions,pg_temp
as $$
declare
  v_me text := public.sanbank_current_account();
  v_row public.sanbank_neo_card_challenges%rowtype;
begin
  if v_me is null or public.sanbank_is_admin() then raise exception 'SANBANK_SESSION_REQUIRED'; end if;
  select * into v_row from public.sanbank_neo_card_challenges
   where account=v_me and status='pending' and expires_at>timezone('utc',now())
   order by created_at desc limit 1;
  if not found then return jsonb_build_object('ok',true,'pending',false); end if;
  return jsonb_build_object('ok',true,'pending',true,'challenge_id',v_row.id,
    'amount',v_row.amount,'description',v_row.description,'expires_at',v_row.expires_at,
    'ttl_seconds',greatest(0,floor(extract(epoch from (v_row.expires_at-now())))::integer));
end;
$$;

create or replace function public.sanbank_neo_terminal_confirm(p_challenge_id uuid,p_code text)
returns jsonb
language plpgsql security definer
set search_path=public,extensions,pg_temp
as $$
declare
  v_me text := public.sanbank_current_account();
  v_admin boolean := public.sanbank_is_admin();
  v_ch public.sanbank_neo_card_challenges%rowtype;
  v_account_row public.sanbank_accounts%rowtype;
  v_card public.sanbank_legacy_records%rowtype;
  v_payload jsonb;
  v_total numeric(18,2);
  v_used numeric(18,2);
  v_invoice numeric(18,2);
  v_available numeric(18,2);
  v_new_used numeric(18,2);
  v_new_invoice numeric(18,2);
  v_source_row integer;
  v_tx text;
  v_result jsonb;
begin
  if v_me is null then raise exception 'SANBANK_SESSION_REQUIRED'; end if;
  select * into v_ch from public.sanbank_neo_card_challenges where id=p_challenge_id for update;
  if not found or v_ch.account<>v_me or v_admin then raise exception 'SANBANK_ACCESS_DENIED'; end if;
  if v_ch.status='completed' then return coalesce(v_ch.result,jsonb_build_object('ok',true,'status','completed','transaction_id',v_ch.transaction_id)); end if;
  if v_ch.status<>'pending' or v_ch.expires_at<=timezone('utc',now()) then
    update public.sanbank_neo_card_challenges set status='expired' where id=p_challenge_id and status='pending';
    delete from public.sanbank_neo_otp_delivery where challenge_id=p_challenge_id;
    return jsonb_build_object('ok',false,'code','TOKEN_EXPIRED');
  end if;
  if coalesce(p_code,'') !~ '^[0-9]{6}$' then
    update public.sanbank_neo_card_challenges set attempts=attempts+1,
      status=case when attempts+1>=3 then 'failed' else 'pending' end where id=p_challenge_id returning * into v_ch;
    if v_ch.status='failed' then delete from public.sanbank_neo_otp_delivery where challenge_id=p_challenge_id; end if;
    return jsonb_build_object('ok',false,'code','TOKEN_INVALID','attempts_left',greatest(0,3-v_ch.attempts));
  end if;
  if encode(digest(v_ch.id::text||':'||p_code,'sha256'),'hex')<>v_ch.code_hash then
    update public.sanbank_neo_card_challenges set attempts=attempts+1,
      status=case when attempts+1>=3 then 'failed' else 'pending' end where id=p_challenge_id returning * into v_ch;
    if v_ch.status='failed' then delete from public.sanbank_neo_otp_delivery where challenge_id=p_challenge_id; end if;
    return jsonb_build_object('ok',false,'code','TOKEN_INVALID','attempts_left',greatest(0,3-v_ch.attempts));
  end if;

  select * into v_account_row from public.sanbank_accounts where account=v_ch.account for update;
  if not found or coalesce(v_account_row.access_enabled,true) is false
     or coalesce(v_account_row.client_access_enabled,true) is false
     or coalesce(public.sanbank_bool(v_account_row.legacy_data->>'security_locked'),false)
     or coalesce(public.sanbank_bool(v_account_row.legacy_data->>'account_locked'),false)
     or coalesce(public.sanbank_bool(v_account_row.legacy_data->>'security_balance_blocked'),false)
     or coalesce(public.sanbank_bool(v_account_row.legacy_data->>'available_balance_blocked'),false)
     or coalesce(public.sanbank_bool(v_account_row.legacy_data->>'balance_security_blocked'),false)
     or lower(trim(coalesce(v_account_row.legacy_data->>'security_status',''))) in ('bloqueado','bloqueada','blocked','locked','security_locked','security_blocked','bloqueado_por_seguranca','bloqueado_por_segurança')
     or lower(trim(coalesce(v_account_row.account_status,''))) in ('bloqueado','bloqueada','blocked','locked','cancelado','cancelada') then
    update public.sanbank_neo_card_challenges set status='declined' where id=p_challenge_id;
    delete from public.sanbank_neo_otp_delivery where challenge_id=p_challenge_id;
    return jsonb_build_object('ok',false,'code','ACCOUNT_BLOCKED');
  end if;

  select * into v_card from public.sanbank_legacy_records where id=v_ch.card_record_id for update;
  if not found then update public.sanbank_neo_card_challenges set status='declined' where id=p_challenge_id; return jsonb_build_object('ok',false,'code','CARD_NOT_FOUND'); end if;
  v_payload:=coalesce(v_card.payload,'{}'::jsonb);
  if lower(trim(coalesce(v_payload->>'status','ativo'))) in ('bloqueado','bloqueada','blocked','locked','suspenso','suspensa','cancelado','cancelada','canceled','cancelled')
     or coalesce(public.sanbank_bool(v_payload->>'security_locked'),false)
     or coalesce(public.sanbank_bool(v_payload->>'card_security_blocked'),false) then
    update public.sanbank_neo_card_challenges set status='declined' where id=p_challenge_id;
    delete from public.sanbank_neo_otp_delivery where challenge_id=p_challenge_id;
    return jsonb_build_object('ok',false,'code','CARD_BLOCKED');
  end if;
  v_total:=coalesce(public.sanbank_decimal(v_payload->>'limit_total'),0);
  v_used:=coalesce(public.sanbank_decimal(v_payload->>'limit_used'),0);
  v_invoice:=greatest(coalesce(public.sanbank_decimal(v_payload->>'invoice_amount'),0),coalesce(public.sanbank_decimal(v_payload->>'fatura'),0),v_used);
  v_available:=greatest(0,v_total-greatest(v_used,v_invoice));
  if v_ch.amount>v_available then
    update public.sanbank_neo_card_challenges set status='declined' where id=p_challenge_id;
    delete from public.sanbank_neo_otp_delivery where challenge_id=p_challenge_id;
    return jsonb_build_object('ok',false,'code','INSUFFICIENT_LIMIT','available',v_available);
  end if;

  -- Reconcile legacy records where invoice and limit_used differ before adding the purchase.
  -- The client calculates available limit as limit_total - limit_used.
  v_new_used:=round(greatest(v_used,v_invoice)+v_ch.amount,2);
  v_new_invoice:=round(v_invoice+v_ch.amount,2);
  v_tx:='NEO-'||replace(v_ch.id::text,'-','');
  v_payload:=v_payload||jsonb_build_object('limit_used',to_char(v_new_used,'FM999999999990.00'),
    'invoice_amount',to_char(v_new_invoice,'FM999999999990.00'),'fatura',to_char(v_new_invoice,'FM999999999990.00'),
    'neo_last_transaction_id',v_tx,'neo_last_transaction_at',timezone('utc',now()),'neo_last_transaction_status','completed');
  update public.sanbank_legacy_records set payload=v_payload where id=v_card.id;
  update public.sanbank_neo_cards set limit_used=v_new_used,
    legacy_data=coalesce(legacy_data,'{}'::jsonb)||jsonb_build_object('limit_used',to_char(v_new_used,'FM999999999990.00'),
      'invoice_amount',to_char(v_new_invoice,'FM999999999990.00'),'fatura',to_char(v_new_invoice,'FM999999999990.00'),
      'neo_last_transaction_id',v_tx)
   where id=coalesce(nullif(v_payload->>'id',''),'cartoes_neo-'||coalesce(v_card.account,'sem-conta')||'-'||v_card.source_row);
  insert into public.sanbank_neo_card_transactions(id,challenge_id,account,card_record_id,amount,description,status,source,network_authorized)
  values(v_tx,v_ch.id,v_ch.account,v_card.id,v_ch.amount,v_ch.description,'completed','internal_supabase_ledger',false);
  perform pg_advisory_xact_lock(hashtextextended('sanbank-extrato-source-row',0));
  select coalesce(max(source_row),0)+1 into v_source_row from public.sanbank_legacy_records where source_tab='extrato';
  insert into public.sanbank_legacy_records(source_tab,source_row,legacy_id,account,payload)
  values('extrato',v_source_row,v_tx,v_ch.account,jsonb_build_object(
    'id',v_tx,'transaction_id',v_tx,'account',v_ch.account,'amount',to_char(-v_ch.amount,'FM999999999990.00'),
    'type','out','transaction_type','NEO_CARD_PURCHASE','title','Compra interna Cartão Neo',
    'description',v_ch.description||' — lançamento interno SANBANK; sem autorização externa Visa.',
    'date',timezone('utc',now()),'status','completed','card_transaction_id',v_tx,
    'ledger_source','internal_supabase_ledger','network_authorized',false,
    'invoice_amount_after',to_char(v_new_invoice,'FM999999999990.00'),
    'limit_available_after',to_char(greatest(0,v_total-v_new_used),'FM999999999990.00')));
  v_result:=jsonb_build_object('ok',true,'status','completed','transaction_id',v_tx,'account',v_ch.account,
    'amount',v_ch.amount,'invoice_amount',v_new_invoice,'limit_used',v_new_used,
    'limit_available',greatest(0,v_total-v_new_used),'ledger_only',true,'network_authorized',false);
  update public.sanbank_neo_card_challenges set status='completed',completed_at=timezone('utc',now()),
    transaction_id=v_tx,result=v_result where id=v_ch.id;
  delete from public.sanbank_neo_otp_delivery where challenge_id=v_ch.id;
  return v_result;
end;
$$;

revoke all on function public.sanbank_neo_terminal_begin(text,numeric,text) from public;
revoke all on function public.sanbank_neo_terminal_inbox() from public;
revoke all on function public.sanbank_neo_terminal_status(uuid) from public;
revoke all on function public.sanbank_neo_terminal_pending() from public;
revoke all on function public.sanbank_neo_terminal_confirm(uuid,text) from public;
grant execute on function public.sanbank_neo_terminal_begin(text,numeric,text) to anon,authenticated;
grant execute on function public.sanbank_neo_terminal_inbox() to anon,authenticated;
grant execute on function public.sanbank_neo_terminal_status(uuid) to anon,authenticated;
grant execute on function public.sanbank_neo_terminal_pending() to anon,authenticated;
grant execute on function public.sanbank_neo_terminal_confirm(uuid,text) to anon,authenticated;
commit;
