const $ = (id) => document.getElementById(id);
const guides = {
  tire: {
    title:"عطب الإطار (Panne de pneu)",
    symptoms:["ثقب أو تمزق ظاهر في الإطار.","انخفاض مفاجئ في ضغط الهواء أو اهتزاز السيارة."],
    steps:["خفف السرعة تدريجياً وتوقف في مكان بعيد عن حركة المرور إذا أمكن.","شغّل أضواء التحذير، واتبع قواعد السلامة المحلية. لا تقف في مسار السيارات.","إذا كنت على طريق سريع أو كتف ضيق، ابقَ في مكان آمن واتصل بالمساعدة؛ لا تحاول تغيير الإطار هناك.","استخدم الإطار الاحتياطي فقط إذا كانت السيارة في مكان آمن تماماً وكنت تعرف الإجراء من دليل السيارة."],
    danger:"لا تواصل القيادة بإطار مفرغ أو متضرر. قد تفقد السيطرة أو تتلف العجلة."
  },
  battery: {
    title:"مشكلة البطارية (Panne de batterie)",
    symptoms:["المحرك لا يبدأ أو تسمع نقرة عند محاولة التشغيل.","إضاءة ضعيفة أو ظهور تحذير البطارية."],
    steps:["أوقف المحاولات المتكررة لتشغيل السيارة.","تأكد من أن السيارة في مكان آمن، وأطفئ الأجهزة الكهربائية غير الضرورية.","قد يكون السبب البطارية أو المولد أو التوصيلات؛ لا يمكن الجزم من العرض وحده.","اطلب مساعدة مختص لفحص النظام. لا تلمس الأقطاب ولا توصل كابلات التشغيل إذا لم تكن مدرباً."],
    danger:"لا تضع أدوات معدنية على أقطاب البطارية، ولا تحاول شحنها أو تشغيلها بطريقة غير مألوفة."
  },
  overheat: {
    title:"ارتفاع حرارة المحرك (Surchauffe)",
    symptoms:["مؤشر الحرارة في المنطقة الحمراء.","ظهور تحذير حرارة أو بخار من حجرة المحرك."],
    steps:["خفف السرعة وتوقف في مكان آمن بأسرع ما يمكن.","أطفئ المحرك عندما يصبح التوقف آمناً، وابتعد عن حركة المرور.","اترك المحرك يبرد واطلب المساعدة إذا استمر التحذير أو ظهر بخار.","لا تفتح غطاء خزان التبريد أو الرادياتير والمحرك ساخن."],
    danger:"فتح نظام التبريد الساخن قد يسبب حروقاً خطيرة. لا تضف سائلاً إلى نظام ساخن."
  },
  brakes: {
    title:"مشكلة الفرامل (Freinage)",
    symptoms:["الدواسة تبدو مختلفة أو الفرملة أضعف من المعتاد.","صوت أو اهتزاز غير طبيعي أو ظهور ضوء تحذير الفرامل."],
    steps:["إذا لاحظت ضعف الفرامل، خفف السرعة بحذر وحاول التوقف في مكان آمن.","شغّل أضواء التحذير بعد التوقف إذا كان ذلك آمناً.","لا تواصل الرحلة ولا تختبر الفرامل على الطريق.","اطلب سحب السيارة أو مساعدة فني مختص."],
    danger:"أي خلل في قدرة الفرملة قد يسبب حادثاً. لا تقد السيارة حتى يفحصها مختص."
  },
  engine: {
    title:"مشكلة المحرك (Problème moteur)",
    symptoms:["توقف المحرك أو صعوبة تشغيله.","اهتزاز شديد أو صوت جديد أو فقدان واضح للقوة."],
    steps:["إذا ظهر تحذير أحمر أو كان هناك دخان أو صوت قوي، توقف بأمان وأطفئ المحرك.","لا تفتح أجزاء المحرك ولا تلمس القطع الساخنة أو المتحركة.","سجّل الأعراض والرموز الظاهرة على لوحة القيادة إن أمكن.","اطلب فحصاً من ميكانيكي، واطلب سحب السيارة إذا كان استمرار القيادة غير آمن."],
    danger:"لا تتجاهل التحذيرات الحمراء أو الدخان أو الروائح غير المعتادة."
  },
  electrical: {
    title:"مشكلة كهربائية (Problème électrique)",
    symptoms:["مصباح أو أكثر لا يعمل.","ظهور تحذيرات كهربائية أو تعطل بعض التجهيزات."],
    steps:["توقف في مكان آمن إذا أثرت المشكلة على الأضواء أو إشارات الانعطاف أو أنظمة السلامة.","أطفئ السيارة والأجهزة غير الضرورية إذا لاحظت رائحة احتراق أو دخاناً.","لا تعبث بالأسلاك أو صندوق الفيوزات دون معرفة ومخطط السيارة.","اطلب فحصاً من كهربائي سيارات."],
    danger:"عند وجود دخان أو رائحة احتراق، ابتعد عن السيارة واطلب المساعدة المناسبة."
  }
};
let selectedProblem = null;
let lastPosition = null;
let toastTimer;

function toast(message){const t=$("toast");t.textContent=message;t.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove("show"),2600)}
function openGuide(key){
  selectedProblem=key; const g=guides[key];
  $("dialogTitle").textContent=g.title;
  $("dialogContent").innerHTML=`
    <div class="guide-section"><h3>علامات ممكنة</h3><ul>${g.symptoms.map(x=>`<li>${x}</li>`).join("")}</ul></div>
    <div class="guide-section"><h3>ماذا تفعل؟</h3><ul>${g.steps.map(x=>`<li>${x}</li>`).join("")}</ul></div>
    <div class="danger-note"><strong>تنبيه سلامة:</strong> ${g.danger}</div>`;
  $("problemDialog").showModal();
}
document.querySelectorAll("[data-problem]").forEach(btn=>btn.addEventListener("click",()=>openGuide(btn.dataset.problem)));
$("closeDialog").addEventListener("click",()=>$("problemDialog").close());
$("dialogDone").addEventListener("click",()=>$("problemDialog").close());
$("saveProblem").addEventListener("click",()=>{
  if(!selectedProblem)return;
  const history=JSON.parse(localStorage.getItem("ar_history")||"[]");
  history.unshift({key:selectedProblem,title:guides[selectedProblem].title,date:new Date().toLocaleString("ar-MA")});
  localStorage.setItem("ar_history",JSON.stringify(history.slice(0,30)));renderHistory();toast("تم حفظ العطل في السجل");
});
function renderHistory(){
  const history=JSON.parse(localStorage.getItem("ar_history")||"[]");
  $("historyList").innerHTML=history.length?history.map((x,i)=>`<div class="history-item"><div><strong>${escapeHtml(x.title)}</strong><small>${escapeHtml(x.date)}</small></div><button class="text-button" data-remove="${i}" type="button">حذف</button></div>`).join(""):'<div class="empty-state">لا توجد أعطال محفوظة حتى الآن.</div>';
  document.querySelectorAll("[data-remove]").forEach(b=>b.addEventListener("click",()=>{const h=JSON.parse(localStorage.getItem("ar_history")||"[]");h.splice(Number(b.dataset.remove),1);localStorage.setItem("ar_history",JSON.stringify(h));renderHistory()}));
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("clearHistory").addEventListener("click",()=>{if(confirm("هل تريد مسح سجل الأعطال؟")){localStorage.removeItem("ar_history");renderHistory();toast("تم مسح السجل")}});
$("carForm").addEventListener("submit",e=>{
  e.preventDefault();
  const car={make:$("carMake").value.trim(),model:$("carModel").value.trim(),fuel:$("carFuel").value};
  localStorage.setItem("ar_car",JSON.stringify(car));$("carStatus").textContent="تم حفظ بيانات السيارة على هذا الجهاز.";toast("تم حفظ بيانات السيارة");
});
function loadCar(){const c=JSON.parse(localStorage.getItem("ar_car")||"null");if(c){$("carMake").value=c.make||"";$("carModel").value=c.model||"";$("carFuel").value=c.fuel||""}}
$("locateBtn").addEventListener("click",()=>{
  const status=$("locationStatus");
  if(!navigator.geolocation){status.textContent="المتصفح لا يدعم تحديد الموقع.";return}
  status.textContent="جارٍ طلب إذن تحديد الموقع…";
  navigator.geolocation.getCurrentPosition(pos=>{
    lastPosition={lat:pos.coords.latitude,lon:pos.coords.longitude};
    status.textContent=`تم تحديد الموقع. الدقة التقريبية: ${Math.round(pos.coords.accuracy)} متر.`;
    $("mapBtn").disabled=false;
  },err=>{
    status.textContent=err.code===1?"لم تسمح بالوصول إلى الموقع. يمكنك تفعيل الإذن من إعدادات المتصفح.":"تعذر تحديد الموقع. تحقق من GPS والاتصال.";
  },{enableHighAccuracy:true,timeout:12000,maximumAge:60000});
});
$("mapBtn").addEventListener("click",()=>{
  if(!lastPosition)return;
  const url=`https://www.google.com/maps/search/garage+auto/@${lastPosition.lat},${lastPosition.lon},14z`;
  window.open(url,"_blank","noopener");
});
$("contactForm").addEventListener("submit",e=>{
  e.preventDefault();
  const name=$("contactName").value.trim(),phone=$("contactPhone").value.trim();
  if(!name||!phone){toast("أدخل الاسم ورقم الهاتف");return}
  localStorage.setItem("ar_contact",JSON.stringify({name,phone}));renderContact();toast("تم حفظ جهة الاتصال");
});
function renderContact(){
  const c=JSON.parse(localStorage.getItem("ar_contact")||"null");
  if(c){$("contactName").value=c.name;$("contactPhone").value=c.phone;$("contactAction").innerHTML=`<a href="tel:${encodeURIComponent(c.phone)}">📞 الاتصال بـ ${escapeHtml(c.name)}</a>`}
}
$("languageToggle").addEventListener("click",()=>toast("النسخة الحالية باللغة العربية. يمكن إضافة الفرنسية والإنجليزية في تطوير لاحق."));
if("serviceWorker" in navigator && location.protocol.startsWith("http")){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}))}
renderHistory();loadCar();renderContact();
