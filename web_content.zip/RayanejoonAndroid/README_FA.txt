ساخت APK اندروید برای بازی‌های رایانه‌جون

۱) Android Studio را از وب‌سایت رسمی نصب کنید: https://developer.android.com/studio
۲) فایل ZIP را از حالت فشرده خارج کنید.
۳) در Android Studio گزینه Open را بزنید و پوشه RayanejoonAndroid را انتخاب کنید.
۴) صبر کنید تا Gradle Sync تمام شود. اگر درخواست نصب SDK 35 یا ابزارهای ساخت آمد، آن‌ها را نصب کنید.
۵) از منوی Build گزینه Build Bundle(s) / APK(s) و سپس Build APK(s) را انتخاب کنید.
۶) پس از پایان، روی Locate بزنید. معمولاً فایل در این مسیر است:
   app/build/outputs/apk/debug/app-debug.apk
۷) APK را به گوشی اندرویدی منتقل کنید و نصبش کنید. ممکن است گوشی برای نصب از این منبع اجازه بخواهد.

نکته: این پروژه یک پوستهٔ اندرویدی برای فایل HTML شماست؛ برای ساخت APK باید Android Studio و Android SDK روی رایانه نصب باشند. خود APK کد HTML/JavaScript را کاملاً مخفی نمی‌کند.
