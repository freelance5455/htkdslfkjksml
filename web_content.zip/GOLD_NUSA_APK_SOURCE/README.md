# GOLD NUSA Android source
Open this folder in Android Studio and build an APK. See `README_BUAT_APK.txt` for Indonesian instructions.
