GOLD NUSA — SOURCE PROJECT UNTUK DIBUAT APK

ISI
- Project Android Studio sederhana yang membungkus aplikasi web GOLD NUSA di WebView.
- Logo master digunakan sebagai ikon aplikasi.
- File HTML dan aset web berada di app/src/main/assets/www/.

CARA MEMBUAT APK (perlu komputer)
1. Ekstrak ZIP ini.
2. Instal Android Studio versi stabil dan Android SDK yang diminta.
3. Android Studio > Open > pilih folder GOLD_NUSA_APK_SOURCE.
4. Tunggu Gradle Sync selesai dan izinkan Android Studio mengunduh komponen yang diperlukan.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, klik Locate. APK debug biasanya ada di app/build/outputs/apk/debug/app-debug.apk.
7. Pindahkan APK ke HP Android, buka file tersebut, lalu izinkan instalasi dari sumber ini jika diminta.

CATATAN
- ZIP ini adalah source project Android, bukan file APK siap instal.
- Pembuatan APK memerlukan komputer, Android Studio, dan koneksi internet untuk mengunduh Gradle/SDK.
- Aplikasi memerlukan internet untuk Tailwind CDN dan sumber harga online; fitur yang bergantung layanan online tidak dijamin berjalan offline.
- Nama paket aplikasi: id.goldnusa.app. Jika dipublikasikan, ubah applicationId sebelum rilis.
