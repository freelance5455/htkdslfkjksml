CHAOS ARENA — Reference Style build

Android Studio WebView project. The game is included at app/src/main/assets/index.html.
Open the project in Android Studio and build an APK using Build > Build Bundle(s) / APK(s) > Build APK(s).
This ZIP is a project source package, not an APK.
