Personal Photo Flipper

Contenu : index.html — application HTML/CSS/JavaScript.

Pour l'utiliser sur Android :
1. Extrayez le fichier ZIP.
2. Ouvrez index.html avec un navigateur compatible (Chrome est conseillé).
3. Le code d'activation défini dans le fichier est : AZNEKM
4. Choisissez les deux images. Les images et réglages sont stockés localement dans le navigateur utilisé.

Remarque : le code reçu dans le message était coupé à la fin, au milieu de updateClock(). La fin du script a été complétée pour rendre le fichier HTML exploitable.
