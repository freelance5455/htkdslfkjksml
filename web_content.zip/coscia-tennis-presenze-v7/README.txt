COSCIA TENNIS TEAM - PRESENZE V6

Funzioni:
- Presenze giornaliere
- CALENDARIO mensile ben visibile
- Clic su una data per vedere lo storico del giorno
- Storico del singolo atleta
- Più giorni/orari settimanali per lo stesso atleta
- Sedi Crotone e Strongoli
- Aggiunta, modifica, spostamento ed eliminazione atleti
- Backup/importazione dati
- Nessuna gestione pagamenti

Nota: questa versione salva i dati nel browser del dispositivo. Non è una sincronizzazione cloud tra telefono e tablet.
