/* ==================================================
   MUEEN | ABSENCE REPORT
   تقرير الغياب
================================================== */


/* ==================================================
   STORAGE
================================================== */

const STORAGE = {

    subjects:
        "mueen_subjects",

    classes:
        "mueen_classes",

    attendanceRecords:
        "mueen_attendance_records",

    weeks:
        "mueen_school_weeks"

};


/* ==================================================
   STATE
================================================== */

const state = {

    subjects: [],

    classes: [],

    attendanceRecords: [],

    schoolWeeks: [],

    months: [],

    students: [],

    selectedStudents: new Set(),

    report: null

};


/* ==================================================
   DOM
================================================== */

const $ = id =>
    document.getElementById(id);


/* ==================================================
   SAFE STORAGE
================================================== */

function readStorage(key, fallback) {

    try {

        const raw =
            localStorage.getItem(key);

        if (!raw) {

            return fallback;
        }

        const parsed =
            JSON.parse(raw);

        return parsed ?? fallback;

    } catch (error) {

        console.error(
            "MUEEN storage error:",
            key,
            error
        );

        return fallback;
    }

}


function writeStorage(key, value) {

    try {

        localStorage.setItem(
            key,
            JSON.stringify(value)
        );

    } catch (error) {

        console.error(
            "MUEEN storage write error:",
            error
        );

    }

}


/* ==================================================
   REFRESH STORAGE
================================================== */

function refreshStorage() {

    state.subjects =
        readStorage(
            STORAGE.subjects,
            []
        );

    state.classes =
        readStorage(
            STORAGE.classes,
            []
        );

    state.attendanceRecords =
        readStorage(
            STORAGE.attendanceRecords,
            []
        );

    state.schoolWeeks =
        readStorage(
            STORAGE.weeks,
            []
        );


    if (!Array.isArray(state.subjects)) {

        state.subjects = [];
    }


    if (!Array.isArray(state.classes)) {

        state.classes = [];
    }


    if (!Array.isArray(state.attendanceRecords)) {

        state.attendanceRecords = [];
    }


    if (!Array.isArray(state.schoolWeeks)) {

        state.schoolWeeks = [];
    }


    state.months =
        getRegisteredMonths();
}


/* ==================================================
   TEXT HELPERS
================================================== */

function escapeHTML(value) {

    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


function formatNumber(value) {

    const number =
        Number(value);

    if (!Number.isFinite(number)) {

        return "";
    }

    return new Intl.NumberFormat(
        "ar-EG"
    ).format(number);
}


function pad2(value) {

    return String(value).padStart(
        2,
        "0"
    );
}


/* ==================================================
   DATE HELPERS
================================================== */

function parseDate(value) {

    if (!value) {

        return null;
    }


    const text =
        String(value).trim();


    const match =
        text.match(
            /^(\d{4})-(\d{1,2})-(\d{1,2})$/
        );


    if (match) {

        const year =
            Number(match[1]);

        const month =
            Number(match[2]);

        const day =
            Number(match[3]);

        const date =
            new Date(
                year,
                month - 1,
                day
            );

        date.setHours(
            0,
            0,
            0,
            0
        );

        return date;
    }


    const date =
        new Date(value);


    if (
        Number.isNaN(
            date.getTime()
        )
    ) {

        return null;
    }


    date.setHours(
        0,
        0,
        0,
        0
    );

    return date;
}


function dateToKey(date) {

    if (!date) {

        return "";
    }


    return [
        date.getFullYear(),
        pad2(date.getMonth() + 1),
        pad2(date.getDate())
    ].join("-");
}


function monthKeyFromDate(value) {

    const date =
        parseDate(value);


    if (!date) {

        return "";
    }


    return [
        date.getFullYear(),
        pad2(date.getMonth() + 1)
    ].join("-");
}


function monthLabel(monthKey) {

    if (!monthKey) {

        return "";
    }


    const parts =
        String(monthKey).split("-");


    if (parts.length !== 2) {

        return monthKey;
    }


    const year =
        Number(parts[0]);

    const month =
        Number(parts[1]);


    if (
        !Number.isFinite(year) ||
        !Number.isFinite(month)
    ) {

        return monthKey;
    }


    const date =
        new Date(
            year,
            month - 1,
            1
        );


    return new Intl.DateTimeFormat(
        "ar-EG",
        {
            month: "long",
            year: "numeric"
        }
    ).format(date);
}


function formatDate(value) {

    const date =
        parseDate(value);


    if (!date) {

        return "";
    }


    return new Intl.DateTimeFormat(
        "ar-EG",
        {
            day: "numeric",
            month: "numeric"
        }
    ).format(date);
}


function formatDateRange(start, end) {

    const startDate =
        parseDate(start);

    const endDate =
        parseDate(end);


    if (
        !startDate &&
        !endDate
    ) {

        return "";
    }


    if (
        startDate &&
        endDate
    ) {

        return `${formatDate(startDate)} – ${formatDate(endDate)}`;
    }


    return formatDate(
        startDate || endDate
    );
}


/* ==================================================
   SUBJECT HELPERS
================================================== */

function subjectId(subject) {

    return String(
        subject?.id ??
        subject?._id ??
        subject?.key ??
        subject?.subjectId ??
        ""
    );
}


function subjectName(subject) {

    return String(
        subject?.name ??
        subject?.title ??
        subject?.label ??
        subject?.subjectName ??
        ""
    ).trim();
}


/* ==================================================
   CLASS HELPERS
================================================== */

function classId(classItem) {

    return String(
        classItem?.id ??
        classItem?._id ??
        classItem?.key ??
        classItem?.classId ??
        ""
    );
}


function className(classItem) {

    if (!classItem) {

        return "الصف";
    }


    /*
       المصدر الأساسي هو code
       وهو نفس الحقل المستخدم
       في صفحة الطلاب.

       مثال:
       3/1
       3/2
       4/1
    */

    const code =
        String(
            classItem?.code ?? ""
        ).trim();


    if (code) {

        const codeMatch =
            code.match(
                /(\d+)\s*\/\s*(\d+)/
            );


        if (codeMatch) {

            return `${codeMatch[1]}/${codeMatch[2]}`;
        }


        return code;
    }


    /*
       احتياط للصفوف القديمة
       التي قد لا تحتوي على code
    */

    const direct =
        String(
            classItem?.name ??
            classItem?.title ??
            classItem?.label ??
            classItem?.className ??
            ""
        ).trim();


    const grade =
        String(
            classItem?.grade ??
            classItem?.gradeNumber ??
            classItem?.classGrade ??
            ""
        ).trim();


    const section =
        String(
            classItem?.section ??
            classItem?.sectionNumber ??
            classItem?.division ??
            ""
        ).trim();


    if (
        grade &&
        section
    ) {

        const gradeNumber =
            String(grade)
                .match(/\d+/)?.[0];


        const sectionNumber =
            String(section)
                .match(/\d+/)?.[0];


        if (
            gradeNumber &&
            sectionNumber
        ) {

            return `${gradeNumber}/${sectionNumber}`;
        }
    }


    const directMatch =
        direct.match(
            /(\d+)\s*\/\s*(\d+)/
        );


    if (directMatch) {

        return `${directMatch[1]}/${directMatch[2]}`;
    }


    return direct || "الصف";
}


function getClassStudents(classItem) {

    const students =
        classItem?.students ??
        classItem?.studentList ??
        classItem?.children ??
        classItem?.members ??
        [];


    return Array.isArray(students)
        ? students
        : [];
}


/* ==================================================
   STUDENT HELPERS
================================================== */

function studentId(student, index = 0) {

    const direct =
        student?.id ??
        student?.studentId ??
        student?._id ??
        student?.key;


    if (
        direct !== undefined &&
        direct !== null &&
        String(direct).trim()
    ) {

        return String(direct);
    }


    const name =
        studentName(student);


    if (name) {

        return `name-${name}`;
    }


    return `student-${index + 1}`;
}


function studentName(student) {

    return String(
        student?.name ??
        student?.studentName ??
        student?.fullName ??
        student?.title ??
        ""
    ).trim();
}


/* ==================================================
   WEEK HELPERS
================================================== */

function weekId(week, index = 0) {

    const direct =
        week?.id ??
        week?._id ??
        week?.key ??
        week?.weekId;


    if (
        direct !== undefined &&
        direct !== null &&
        String(direct).trim()
    ) {

        return String(direct);
    }


    return `week-${index + 1}`;
}


function getWeekNumber(week, index = 0) {

    const number =
        Number(
            week?.number ??
            week?.weekNumber ??
            week?.order ??
            index + 1
        );


    return Number.isFinite(number)
        ? number
        : index + 1;
}


function getWeekName(week, index = 0) {

    const explicit =
        String(
            week?.name ??
            week?.title ??
            week?.weekName ??
            week?.label ??
            ""
        ).trim();


    if (explicit) {

        return explicit;
    }


    const number =
        getWeekNumber(
            week,
            index
        );


    const arabicNumbers = [

        "الأول",
        "الثاني",
        "الثالث",
        "الرابع",
        "الخامس",
        "السادس",
        "السابع",
        "الثامن",
        "التاسع",
        "العاشر",
        "الحادي عشر",
        "الثاني عشر",
        "الثالث عشر",
        "الرابع عشر",
        "الخامس عشر",
        "السادس عشر",
        "السابع عشر",
        "الثامن عشر",
        "التاسع عشر",
        "العشرون"

    ];


    const arabic =
        arabicNumbers[
            number - 1
        ] ||
        formatNumber(number);


    return `الأسبوع ${arabic}`;
}


/* ==================================================
   SCHOOL DAYS
================================================== */

const SCHOOL_DAY_INDEXES = [
    0,
    1,
    2,
    3,
    4
];


const DAY_NAMES = [

    "الأحد",
    "الإثنين",
    "الثلاثاء",
    "الأربعاء",
    "الخميس",
    "الجمعة",
    "السبت"

];


/* ==================================================
   REGISTERED MONTHS
================================================== */

function getRegisteredMonths() {

    const months =
        new Set();


    state.attendanceRecords
        .forEach(record => {

            const month =
                monthKeyFromDate(
                    record?.date
                );


            if (month) {

                months.add(month);
            }

        });


    state.schoolWeeks
        .forEach(week => {

            const start =
                parseDate(
                    week?.start
                );

            const end =
                parseDate(
                    week?.end
                );


            if (start) {

                months.add(
                    monthKeyFromDate(start)
                );
            }


            if (end) {

                months.add(
                    monthKeyFromDate(end)
                );
            }

        });


    const result =
        [...months]
            .filter(Boolean)
            .sort();


    return result;
}


/* ==================================================
   MONTH SELECT
================================================== */

function buildMonthSelect() {

    const select =
        $("monthSelect");


    if (!select) {

        return;
    }


    select.innerHTML = "";


    if (!state.months.length) {

        const option =
            document.createElement(
                "option"
            );

        option.value = "";

        option.textContent =
            "لا توجد أشهر مسجلة";

        select.appendChild(option);

        select.disabled = true;

        return;
    }


    select.disabled = false;


    state.months.forEach(
        month => {

            const option =
                document.createElement(
                    "option"
                );

            option.value =
                month;

            option.textContent =
                monthLabel(month);

            select.appendChild(option);

        }
    );
}


/* ==================================================
   SUBJECT SELECT
================================================== */

function buildSubjectSelect() {

    const select =
        $("subjectSelect");


    if (!select) {

        return;
    }


    const previous =
        select.value;


    select.innerHTML = "";


    const first =
        document.createElement(
            "option"
        );

    first.value = "";

    first.textContent =
        "كل المواد";


    select.appendChild(first);


    state.subjects.forEach(
        subject => {

            const id =
                subjectId(subject);


            if (!id) {

                return;
            }


            const option =
                document.createElement(
                    "option"
                );

            option.value =
                id;

            option.textContent =
                subjectName(subject) ||
                "مادة";


            select.appendChild(option);

        }
    );


    if (
        previous &&
        [...select.options]
            .some(
                option =>
                    option.value === previous
            )
    ) {

        select.value =
            previous;
    }
}


/* ==================================================
   CLASS SELECT
================================================== */

function buildClassSelect() {

    const select =
        $("classSelect");


    if (!select) {

        return;
    }


    const previous =
        select.value;


    select.innerHTML = "";


    const first =
        document.createElement(
            "option"
        );

    first.value = "";

    first.textContent =
        "كل الصفوف";


    select.appendChild(first);


    state.classes.forEach(
        classItem => {

            const id =
                classId(classItem);


            if (!id) {

                return;
            }


            const option =
                document.createElement(
                    "option"
                );


            option.value =
                id;


            option.textContent =
                className(classItem);


            select.appendChild(
                option
            );

        }
    );


    if (
        previous &&
        [...select.options]
            .some(
                option =>
                    option.value === previous
            )
    ) {

        select.value =
            previous;
    }
}


/* ==================================================
   STUDENT LIST
================================================== */

function rebuildStudents() {

    const classSelect =
        $("classSelect");


    const selectedClassId =
        String(
            classSelect?.value || ""
        );


    const classItem =
        state.classes.find(
            item =>
                classId(item) ===
                selectedClassId
        );


    if (classItem) {

        state.students =
            getClassStudents(
                classItem
            ).map(
                (student, index) => ({

                    raw: student,

                    id:
                        studentId(
                            student,
                            index
                        ),

                    name:
                        studentName(
                            student
                        )

                })
            )
            .filter(
                student =>
                    student.name
            );

    } else {

        const map =
            new Map();


        state.classes.forEach(
            classItem => {

                getClassStudents(
                    classItem
                ).forEach(
                    (student, index) => {

                        const id =
                            studentId(
                                student,
                                index
                            );

                        const name =
                            studentName(
                                student
                            );


                        if (
                            name &&
                            !map.has(id)
                        ) {

                            map.set(
                                id,
                                {
                                    raw: student,
                                    id,
                                    name
                                }
                            );
                        }

                    }
                );

            }
        );


        state.students =
            [...map.values()];
    }


    const validIds =
        new Set(
            state.students.map(
                student =>
                    student.id
            )
        );


    state.selectedStudents =
        new Set(
            [...state.selectedStudents]
                .filter(
                    id =>
                        validIds.has(id)
                )
        );


    updateSelectionUI();

    renderStudentSearch();
}


/* ==================================================
   STUDENT SEARCH
================================================== */

function renderStudentSearch() {

    const results =
        $("studentSearchResults");

    const input =
        $("studentSearch");


    if (
        !results ||
        !input
    ) {

        return;
    }


    const query =
        String(
            input.value || ""
        ).trim().toLowerCase();


    if (!query) {

        results.innerHTML = "";

        results.hidden = true;

        return;
    }


    const matches =
        state.students
            .filter(
                student =>
                    student.name
                        .toLowerCase()
                        .includes(query)
            )
            .slice(0, 50);


    results.innerHTML = "";


    if (!matches.length) {

        const empty =
            document.createElement(
                "div"
            );

        empty.className =
            "student-candidate";


        empty.style.cursor =
            "default";


        empty.innerHTML = `
            <span class="student-candidate-name">
                لا توجد نتائج
            </span>
        `;


        results.appendChild(empty);

        results.hidden = false;

        return;
    }


    matches.forEach(
        student => {

            const button =
                document.createElement(
                    "button"
                );


            button.type =
                "button";


            button.className =
                "student-candidate";


            if (
                state.selectedStudents.has(
                    student.id
                )
            ) {

                button.classList.add(
                    "selected"
                );
            }


            button.innerHTML = `

                <span
                    class="student-candidate-check"
                >
                    ${
                        state.selectedStudents.has(
                            student.id
                        )
                            ? "✓"
                            : ""
                    }
                </span>

                <span
                    class="student-candidate-name"
                >
                    ${escapeHTML(student.name)}
                </span>

            `;


            button.addEventListener(
                "click",
                () => {

                    toggleStudent(
                        student.id
                    );

                    renderStudentSearch();

                }
            );


            results.appendChild(
                button
            );

        }
    );


    results.hidden = false;
}


/* ==================================================
   STUDENT TOGGLE
================================================== */

function toggleStudent(id) {

    const value =
        String(id);


    if (
        state.selectedStudents.has(
            value
        )
    ) {

        state.selectedStudents.delete(
            value
        );

    } else {

        state.selectedStudents.add(
            value
        );

    }


    updateSelectionUI();

    buildReport();
}


/* ==================================================
   SELECTION UI
================================================== */

function updateSelectionUI() {

    const count =
        $("selectionCount");

    const clear =
        $("clearStudentSelection");


    const selected =
        state.selectedStudents.size;


    if (count) {

        count.textContent =
            selected
                ? `تم اختيار ${formatNumber(selected)}`
                : "كل الطلاب";
    }


    if (clear) {

        clear.hidden =
            selected === 0;
    }
}


/* ==================================================
   WEEK SORT
================================================== */

function sortWeeks(weeks) {

    return [...weeks]
        .sort(
            (a, b) => {

                const aStart =
                    parseDate(a?.start);

                const bStart =
                    parseDate(b?.start);


                if (
                    aStart &&
                    bStart
                ) {

                    return (
                        aStart.getTime() -
                        bStart.getTime()
                    );
                }


                if (aStart) {

                    return -1;
                }


                if (bStart) {

                    return 1;
                }


                return (
                    getWeekNumber(a, 0) -
                    getWeekNumber(b, 0)
                );
            }
        );
}


/* ==================================================
   WEEKS FOR MONTH
================================================== */

function getWeeksForMonth(monthKey) {

    const monthStart =
        parseDate(
            `${monthKey}-01`
        );


    if (!monthStart) {

        return [];
    }


    const monthEnd =
        new Date(
            monthStart.getFullYear(),
            monthStart.getMonth() + 1,
            0
        );


    monthEnd.setHours(
        0,
        0,
        0,
        0
    );


    const weeks =
        sortWeeks(
            state.schoolWeeks
        )
        .filter(
            week => {

                const start =
                    parseDate(
                        week?.start
                    );

                const end =
                    parseDate(
                        week?.end
                    );


                if (
                    !start &&
                    !end
                ) {

                    return false;
                }


                const actualStart =
                    start || end;

                const actualEnd =
                    end || start;


                return (
                    actualStart <= monthEnd &&
                    actualEnd >= monthStart
                );
            }
        );


    return weeks;
}


/* ==================================================
   DAYS FOR WEEK
================================================== */

function getDaysForWeek(
    week,
    monthKey
) {

    const start =
        parseDate(
            week?.start
        );

    const end =
        parseDate(
            week?.end
        );


    if (
        !start &&
        !end
    ) {

        return [];
    }


    const first =
        new Date(
            start || end
        );


    const last =
        new Date(
            end || start
        );


    first.setHours(
        0,
        0,
        0,
        0
    );

    last.setHours(
        0,
        0,
        0,
        0
    );


    const days = [];


    for (
        let date = new Date(first);
        date <= last;
        date.setDate(
            date.getDate() + 1
        )
    ) {

        const current =
            new Date(date);


        const dayIndex =
            current.getDay();


        if (
            !SCHOOL_DAY_INDEXES.includes(
                dayIndex
            )
        ) {

            continue;
        }


        if (
            monthKeyFromDate(
                current
            ) !== monthKey
        ) {

            continue;
        }


        days.push({

            date: current,

            key:
                dateToKey(current),

            dayIndex,

            name:
                DAY_NAMES[dayIndex]

        });
    }


    return days;
}


/* ==================================================
   ATTENDANCE RECORD MATCH
================================================== */

function recordMatches(
    record,
    dateKey,
    subjectValue,
    classValue,
    week
) {

    if (
        String(record?.date || "") !==
        String(dateKey)
    ) {

        return false;
    }


    if (
        subjectValue &&
        String(
            record?.subjectId ?? ""
        ) !== String(subjectValue)
    ) {

        return false;
    }


    if (
        classValue &&
        String(
            record?.classId ?? ""
        ) !== String(classValue)
    ) {

        return false;
    }


    if (week) {

        const recordWeek =
            String(
                record?.weekId ?? ""
            );


        if (recordWeek) {

            return (
                recordWeek ===
                weekId(week)
            );
        }


        const date =
            parseDate(
                record?.date
            );

        const start =
            parseDate(
                week?.start
            );

        const end =
            parseDate(
                week?.end
            );


        if (
            date &&
            start &&
            end
        ) {

            return (
                date >= start &&
                date <= end
            );
        }
    }


    return true;
}


/* ==================================================
   GET RECORD
================================================== */

function getAttendanceRecord(
    dateKey,
    subjectValue,
    classValue,
    week
) {

    return state.attendanceRecords.find(
        record =>
            recordMatches(
                record,
                dateKey,
                subjectValue,
                classValue,
                week
            )
    ) || null;
}


/* ==================================================
   ABSENT STUDENTS
================================================== */

function getAbsentIds(record) {

    if (
        !record ||
        !Array.isArray(
            record.absentStudents
        )
    ) {

        return new Set();
    }


    return new Set(

        record.absentStudents
            .map(
                student =>
                    String(
                        student?.id ??
                        student?.studentId ??
                        student?._id ??
                        student?.key ??
                        (
                            student?.name
                                ? `name-${student.name}`
                                : ""
                        )
                    )
            )
            .filter(Boolean)

    );
}


/* ==================================================
   STUDENT ATTENDANCE STATUS
================================================== */

function getAttendanceStatus(
    student,
    record
) {

    if (!record) {

        return "empty";
    }


    const absentIds =
        getAbsentIds(record);


    const id =
        String(student.id);


    if (
        absentIds.has(id)
    ) {

        return "absent";
    }


    const studentNameValue =
        String(
            student.name || ""
        ).trim();


    const absentByName =
        Array.isArray(
            record.absentStudents
        ) &&
        record.absentStudents.some(
            item =>
                String(
                    item?.name || ""
                ).trim() ===
                studentNameValue
        );


    if (absentByName) {

        return "absent";
    }


    return "present";
}


/* ==================================================
   SELECT REPORT STUDENTS
================================================== */

function getReportStudents() {

    if (
        state.selectedStudents.size === 0
    ) {

        return [...state.students];
    }


    return state.students.filter(
        student =>
            state.selectedStudents.has(
                student.id
            )
    );
}


/* ==================================================
   BUILD REPORT
================================================== */

function buildReport() {

    refreshStorage();

    rebuildStudents();


    const month =
        String(
            $("monthSelect")?.value || ""
        );


    const subjectValue =
        String(
            $("subjectSelect")?.value || ""
        );


    const classValue =
        String(
            $("classSelect")?.value || ""
        );


    const table =
        $("absenceReportTable");

    const empty =
        $("reportEmpty");


    if (!table) {

        return;
    }


    table.innerHTML = "";


    if (!month) {

        showEmpty(
            "لا توجد بيانات",
            "لم يتم تسجيل أي شهر في بيانات الحضور."
        );

        return;
    }


    const weeks =
        getWeeksForMonth(
            month
        );


    const students =
        getReportStudents();


    if (!weeks.length) {

        showEmpty(
            "لا توجد أسابيع مسجلة",
            "لا توجد أسابيع مرتبطة بالشهر المحدد."
        );

        return;
    }


    if (!students.length) {

        showEmpty(
            "لا يوجد طلاب",
            "لا يوجد طلاب مسجلون في الصف المحدد."
        );

        return;
    }


    const tableData =
        [];


    let totalDayColumns = 0;


    weeks.forEach(
        week => {

            const days =
                getDaysForWeek(
                    week,
                    month
                );


            totalDayColumns +=
                days.length;


            tableData.push({

                week,

                days

            });

        }
    );


    if (
        totalDayColumns === 0
    ) {

        showEmpty(
            "لا توجد أيام دراسية",
            "لا توجد أيام من الأحد إلى الخميس ضمن الشهر المحدد."
        );

        return;
    }


    /* ==================================================
       HEADER ROW 1
    ================================================== */

    const headerRow1 =
        document.createElement(
            "tr"
        );


    const studentHeader =
        document.createElement(
            "th"
        );


    studentHeader.rowSpan = 2;

    studentHeader.className =
        "report-student-header";

    studentHeader.textContent =
        "اسم الطالب";


    headerRow1.appendChild(
        studentHeader
    );


    tableData.forEach(
        item => {

            const th =
                document.createElement(
                    "th"
                );


            th.colSpan =
                item.days.length;


            th.className =
                "report-week-header";


            th.innerHTML = `

                <div class="report-week-name">
                    ${escapeHTML(
                        getWeekName(
                            item.week,
                            state.schoolWeeks.indexOf(
                                item.week
                            )
                        )
                    )}
                </div>

                <div class="report-week-date">
                    ${escapeHTML(
                        formatDateRange(
                            item.week?.start,
                            item.week?.end
                        )
                    )}
                </div>

            `;


            headerRow1.appendChild(th);

        }
    );


    const totalHeader =
        document.createElement(
            "th"
        );


    totalHeader.rowSpan = 2;

    totalHeader.className =
        "total-absence-header";

    totalHeader.textContent =
        "إجمالي الغياب";


    headerRow1.appendChild(
        totalHeader
    );


    table.appendChild(
        headerRow1
    );


    /* ==================================================
       HEADER ROW 2
    ================================================== */

    const headerRow2 =
        document.createElement(
            "tr"
        );


    tableData.forEach(
        item => {

            item.days.forEach(
                day => {

                    const th =
                        document.createElement(
                            "th"
                        );


                    th.className =
                        "report-day-header";


                    th.innerHTML = `

                        <span class="report-day-name">
                            ${escapeHTML(day.name)}
                        </span>

                        <span class="report-day-date">
                            ${escapeHTML(
                                formatDate(
                                    day.date
                                )
                            )}
                        </span>

                    `;


                    headerRow2.appendChild(
                        th
                    );

                }
            );

        }
    );


    table.appendChild(
        headerRow2
    );


    /* ==================================================
       STUDENT ROWS
    ================================================== */

    students.forEach(
        (student, studentIndex) => {

            const row =
                document.createElement(
                    "tr"
                );


            const nameCell =
                document.createElement(
                    "td"
                );


            nameCell.className =
                "report-student-cell";


            nameCell.innerHTML = `

                <span class="student-number">
                    ${formatNumber(
                        studentIndex + 1
                    )}
                </span>

                ${escapeHTML(
                    student.name
                )}

            `;


            row.appendChild(
                nameCell
            );


            let absenceTotal = 0;


            tableData.forEach(
                item => {

                    item.days.forEach(
                        day => {

                            const cell =
                                document.createElement(
                                    "td"
                                );


                            cell.className =
                                "attendance-cell";


                            const record =
                                getAttendanceRecord(
                                    day.key,
                                    subjectValue,
                                    classValue,
                                    item.week
                                );


                            const status =
                                getAttendanceStatus(
                                    student,
                                    record
                                );


                            if (
                                status === "absent"
                            ) {

                                absenceTotal++;


                                cell.classList.add(
                                    "absent"
                                );


                                cell.textContent =
                                    "غ";

                            } else if (
                                status === "present"
                            ) {

                                cell.classList.add(
                                    "present"
                                );


                                cell.textContent =
                                    "✓";

                            } else {

                                cell.classList.add(
                                    "empty"
                                );


                                cell.textContent =
                                    "—";
                            }


                            row.appendChild(
                                cell
                            );

                        }
                    );

                }
            );


            const totalCell =
                document.createElement(
                    "td"
                );


            totalCell.className =
                "total-absence-cell";


            totalCell.textContent =
                formatNumber(
                    absenceTotal
                );


            row.appendChild(
                totalCell
            );


            table.appendChild(
                row
            );

        }
    );


    /* ==================================================
       SHOW REPORT / HIDE EMPTY CARD
    ================================================== */

    table.hidden = false;

    table.style.display = "table";


    if (empty) {

        empty.hidden = true;

        empty.style.display = "none";
    }


    updateReportInfo(
        month,
        subjectValue,
        classValue,
        students.length
    );


    state.report = {

        month,

        subjectId:
            subjectValue,

        classId:
            classValue,

        weeks:
            tableData,

        students

    };
}


/* ==================================================
   EMPTY
================================================== */

function showEmpty(
    title,
    description
) {

    const table =
        $("absenceReportTable");

    const empty =
        $("reportEmpty");


    if (table) {

        table.hidden = true;

        table.style.display = "none";

        table.innerHTML = "";
    }


    if (empty) {

        empty.hidden = false;

        empty.style.display = "flex";


        const titleElement =
            empty.querySelector(
                ".report-empty-title"
            );


        const textElement =
            empty.querySelector(
                ".report-empty-text"
            );


        if (titleElement) {

            titleElement.textContent =
                title;
        }


        if (textElement) {

            textElement.textContent =
                description;
        }
    }


    const subtitle =
        $("reportSubtitle");


    if (subtitle) {

        subtitle.textContent =
            description;
    }


    const status =
        $("reportStatus");


    if (status) {

        status.textContent =
            "لا توجد بيانات";
    }


    state.report =
        null;
}


/* ==================================================
   REPORT INFO
================================================== */

function updateReportInfo(
    month,
    subjectValue,
    classValue,
    studentCount
) {

    const subtitle =
        $("reportSubtitle");

    const status =
        $("reportStatus");


    const subject =
        state.subjects.find(
            item =>
                subjectId(item) ===
                subjectValue
        );


    const classItem =
        state.classes.find(
            item =>
                classId(item) ===
                classValue
        );


    const subjectText =
        subjectValue
            ? (
                subjectName(subject) ||
                "المادة"
            )
            : "كل المواد";


    const classText =
        classValue
            ? (
                className(classItem) ||
                "الصف"
            )
            : "كل الصفوف";


    if (subtitle) {

        subtitle.textContent =
            `${monthLabel(month)} • ${subjectText} • ${classText} • ${formatNumber(studentCount)} طالب`;
    }


    if (status) {

        status.textContent =
            "تم إعداد التقرير";
    }
}


/* ==================================================
   DOWNLOAD TOAST
================================================== */

let downloadToastTimer = null;


function showDownloadToast(
    title = "جاري تنزيل الملف...",
    text = "سيتم حفظ التقرير على جهازك"
) {

    const toast =
        $("downloadToast");


    const titleElement =
        $("downloadToastTitle");


    const textElement =
        $("downloadToastText");


    if (!toast) {

        return;
    }


    if (titleElement) {

        titleElement.textContent =
            title;
    }


    if (textElement) {

        textElement.textContent =
            text;
    }


    clearTimeout(
        downloadToastTimer
    );


    toast.hidden =
        false;


    requestAnimationFrame(
        () => {

            toast.classList.add(
                "show"
            );

        }
    );


    downloadToastTimer =
        setTimeout(
            () => {

                toast.classList.remove(
                    "show"
                );


                setTimeout(
                    () => {

                        toast.hidden =
                            true;

                    },
                    250
                );

            },
            3000
        );
}


/* ==================================================
   CLEAR TOAST
================================================== */

function hideDownloadToast() {

    const toast =
        $("downloadToast");


    if (!toast) {

        return;
    }


    toast.classList.remove(
        "show"
    );


    setTimeout(
        () => {

            toast.hidden =
                true;

        },
        250
    );
}


/* ==================================================
   EXCEL HELPERS
================================================== */

function getExportRows() {

    if (
        !state.report
    ) {

        return [];
    }


    const rows = [];


    const students =
        state.report.students;


    const subject =
        state.subjects.find(
            item =>
                subjectId(item) ===
                state.report.subjectId
        );


    const classItem =
        state.classes.find(
            item =>
                classId(item) ===
                state.report.classId
        );


    rows.push([
        "تقرير الغياب"
    ]);


    rows.push([
        "الشهر",
        monthLabel(
            state.report.month
        )
    ]);


    rows.push([
        "المادة",
        state.report.subjectId
            ? subjectName(subject)
            : "كل المواد"
    ]);


    rows.push([
        "الصف",
        state.report.classId
            ? className(classItem)
            : "كل الصفوف"
    ]);


    rows.push([
        "عدد الطلاب",
        students.length
    ]);


    rows.push([]);


    const header = [
        "اسم الطالب"
    ];


    state.report.weeks.forEach(
        item => {

            item.days.forEach(
                day => {

                    header.push(
                        `${getWeekName(
                            item.week,
                            state.schoolWeeks.indexOf(
                                item.week
                            )
                        )} - ${day.name} - ${formatDate(day.date)}`
                    );

                }
            );

        }
    );


    header.push(
        "إجمالي الغياب"
    );


    rows.push(header);


    students.forEach(
        student => {

            const row = [
                student.name
            ];


            let total = 0;


            state.report.weeks.forEach(
                item => {

                    item.days.forEach(
                        day => {

                            const record =
                                getAttendanceRecord(
                                    day.key,
                                    state.report.subjectId,
                                    state.report.classId,
                                    item.week
                                );


                            const status =
                                getAttendanceStatus(
                                    student,
                                    record
                                );


                            if (
                                status === "absent"
                            ) {

                                row.push("غ");

                                total++;

                            } else if (
                                status === "present"
                            ) {

                                row.push("✓");

                            } else {

                                row.push("—");
                            }

                        }
                    );

                }
            );


            row.push(total);

            rows.push(row);

        }
    );


    return rows;
}


/* ==================================================
   EXCEL EXPORT
================================================== */

function exportTableToExcel() {

    refreshStorage();


    if (
        !state.report
    ) {

        buildReport();
    }


    if (
        !state.report ||
        !state.report.weeks.length
    ) {

        return;
    }


    if (!window.MueenXLSX || typeof window.MueenXLSX.create !== "function") {
        window.MueenUI.alert("تعذر تجهيز ملف Excel.", "تعذر التصدير");
        return;
    }


    showDownloadToast(
        "جاري تجهيز التقرير...",
        "يتم إنشاء ملف Excel وتنزيله على جهازك الآن"
    );


    const button =
        $("exportExcelButton");


    if (button) {

        button.disabled = true;
    }


    setTimeout(
        () => {

            try {

                const rows =
                    getExportRows();


                const fileName = `تقرير الغياب - ${monthLabel(state.report.month)}.xlsx`;

                const blob = window.MueenXLSX.create(rows, "تقرير");

                if (window.MueenNative?.available && typeof window.MueenNative.saveFileBase64 === "function") {
                    const reader = new FileReader();
                    reader.onload = () => {
                        const result = String(reader.result || "");
                        const comma = result.indexOf(",");
                        const base64 = comma >= 0 ? result.slice(comma + 1) : result;
                        window.MueenNative.saveFileBase64(
                            base64,
                            fileName,
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        ).then(() => {
                            showDownloadToast(
                                "تم حفظ ملف Excel في مجلد التنزيلات ✓",
                                "تم حفظ التقرير على جهازك"
                            );
                        }).catch((error) => {
                            console.error("MUEEN native export error:", error);
                            showDownloadToast(
                                error?.message || "تعذر حفظ ملف Excel على الهاتف",
                                "تعذر الحفظ"
                            );
                        });
                    };
                    reader.readAsDataURL(blob);
                } else {
                    try {
                        const file = new File([blob], fileName, {
                            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        });
                        if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
                            navigator.share({
                                title: "ملف من مُعين",
                                text: fileName,
                                files: [file]
                            }).catch(() => {});
                        } else {
                            const url = URL.createObjectURL(blob);
                            window.open(url, "_blank", "noopener");
                            setTimeout(() => URL.revokeObjectURL(url), 10000);
                        }
                    } catch (shareError) {
                        console.warn("MUEEN export share failed:", shareError);
                    }
                }


                showDownloadToast(
                    "تم تنزيل ملف Excel ✓",
                    "تم حفظ التقرير على جهازك"
                );


            } catch (error) {

                console.error(
                    "Excel export error:",
                    error
                );


                showDownloadToast(
                    "تعذر تنزيل الملف",
                    "حدث خطأ أثناء تجهيز تقرير Excel"
                );

            } finally {

                if (button) {

                    button.disabled =
                        false;
                }

            }

        },
        120
    );
}


/* ==================================================
   PRINT TABLE
================================================== */

function buildPrintableTable() {

    const table =
        $("absenceReportTable");


    if (!table) {

        return "";
    }


    return table.outerHTML;
}


/* ==================================================
   PRINT / PDF
================================================== */

function exportToPDF() {

    refreshStorage();


    if (
        !state.report
    ) {

        buildReport();
    }


    if (
        !state.report ||
        !state.report.weeks.length
    ) {

        return;
    }


    if (window.MueenNative?.available && typeof window.MueenNative.printHtml === "function") {
        try {
            window.MueenNative.printHtml(
                document.documentElement.outerHTML,
                "تقرير مُعين"
            );
            return;
        } catch (_) {}
    }

    const printWindow =
        window.open(
            "",
            "_blank",
            "noopener,noreferrer,width=1200,height=850,scrollbars=yes,resizable=yes"
        );


    if (!printWindow) {

        alert(
            "تعذر فتح نافذة الطباعة. يرجى السماح للنوافذ المنبثقة ثم المحاولة مرة أخرى."
        );

        return;
    }


    const subject =
        state.subjects.find(
            item =>
                subjectId(item) ===
                state.report.subjectId
        );


    const classItem =
        state.classes.find(
            item =>
                classId(item) ===
                state.report.classId
        );


    const subjectText =
        state.report.subjectId
            ? (
                subjectName(subject) ||
                "المادة"
            )
            : "كل المواد";


    const classText =
        state.report.classId
            ? (
                className(classItem) ||
                "الصف"
            )
            : "كل الصفوف";


    const studentCount =
        state.report.students.length;


    const printableTable =
        buildPrintableTable();


    const printDocument = `

<!DOCTYPE html>

<html
    lang="ar"
    dir="rtl"
>

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        تقرير الغياب - ${escapeHTML(
            monthLabel(
                state.report.month
            )
        )}
    </title>


    <style>

        @page {

            size: A4 landscape;

            margin: 10mm;

        }


        * {

            box-sizing: border-box;

        }


        html {

            direction: rtl;

        }


        body {

            margin: 0;

            padding: 0;

            background: white;

            color: #18343A;

            font-family:
                Arial,
                Tahoma,
                sans-serif;

            direction: rtl;

        }


        .print-page {

            width: 100%;

        }


        .print-header {

            margin-bottom: 12px;

            padding-bottom: 10px;

            border-bottom:
                2px solid #073B46;

        }


        .print-brand {

            color: #073B46;

            font-size: 19px;

            font-weight: 900;

        }


        .print-title {

            margin-top: 3px;

            color: #18343A;

            font-size: 16px;

            font-weight: 800;

        }


        .print-info {

            margin-top: 10px;

            display: grid;

            grid-template-columns:
                repeat(4, 1fr);

            gap: 7px;

        }


        .print-info-item {

            padding:
                7px 9px;

            background: #F5F7F6;

            border:
                1px solid #E3E9E7;

            border-radius: 7px;

            font-size: 10px;

        }


        .print-info-label {

            color: #687B80;

            font-weight: 700;

        }


        .print-info-value {

            margin-right: 4px;

            color: #073B46;

            font-weight: 900;

        }


        .print-table-wrap {

            width: 100%;

            overflow: visible;

        }


        table {

            width: 100%;

            border-collapse: collapse;

            table-layout: auto;

            direction: rtl;

            font-size: 8px;

        }


        th,
        td {

            padding:
                4px 3px;

            border:
                1px solid #CBD5D3;

            text-align: center;

            vertical-align: middle;

        }


        th {

            background: #F1F5F4;

            color: #073B46;

            font-weight: 900;

        }


        td {

            color: #18343A;

            font-weight: 700;

        }


        .report-student-header,
        .report-student-cell {

            min-width: 90px;

            text-align: right !important;

        }


        .student-number {

            display: inline-block;

            min-width: 18px;

            margin-left: 3px;

            padding: 2px 3px;

            border-radius: 4px;

            background: #EDF5F5;

            color: #073B46;

            font-size: 7px;

            font-weight: 900;

        }


        .report-week-header {

            background: #EDF5F5 !important;

        }


        .report-week-name {

            color: #073B46;

            font-size: 9px;

            font-weight: 900;

        }


        .report-week-date {

            margin-top: 2px;

            color: #687B80;

            font-size: 7px;

            font-weight: 700;

        }


        .report-day-header {

            width: 26px;

            min-width: 26px;

            padding:
                3px 2px !important;

        }


        .report-day-name {

            display: block;

            writing-mode:
                vertical-rl;

            text-orientation:
                mixed;

            white-space:
                nowrap;

            margin:
                0 auto 2px;

            color: #073B46;

            font-size: 7px;

            font-weight: 900;

            line-height: 1;

        }


        .report-day-date {

            display: block;

            direction: ltr;

            color: #687B80;

            font-size: 6px;

        }


        .attendance-cell {

            width: 26px;

            min-width: 26px;

            height: 28px;

            font-size: 10px !important;

            font-weight: 900 !important;

        }


        .attendance-cell.absent {

            color: #A25C5C !important;

            background: #FFF5F5 !important;

        }


        .attendance-cell.present {

            color: #4F8064 !important;

            background: #F7FBF8 !important;

        }


        .attendance-cell.empty {

            color: #AAB5B6 !important;

            background: #FCFDFC !important;

        }


        .total-absence-header {

            min-width: 48px;

            background:
                #F8F2E8 !important;

            color:
                #8D6A30 !important;

        }


        .total-absence-cell {

            min-width: 48px;

            background:
                #FFFCF6 !important;

            color:
                #8D6A30 !important;

            font-weight: 900 !important;

        }


        .print-footer {

            margin-top: 10px;

            padding-top: 6px;

            border-top:
                1px solid #E3E9E7;

            color: #687B80;

            font-size: 7px;

            text-align: center;

        }


        @media print {

            body {

                -webkit-print-color-adjust:
                    exact;

                print-color-adjust:
                    exact;

            }


            .print-page {

                page-break-inside:
                    avoid;

            }

        }

    </style>

</head>


<body>


<div class="print-page">


    <div class="print-header">

        <div class="print-brand">
            مُعين | MUEEN
        </div>

        <div class="print-title">
            تقرير الغياب
        </div>


        <div class="print-info">


            <div class="print-info-item">

                <span class="print-info-label">
                    الشهر:
                </span>

                <span class="print-info-value">
                    ${escapeHTML(
                        monthLabel(
                            state.report.month
                        )
                    )}
                </span>

            </div>


            <div class="print-info-item">

                <span class="print-info-label">
                    المادة:
                </span>

                <span class="print-info-value">
                    ${escapeHTML(
                        subjectText
                    )}
                </span>

            </div>


            <div class="print-info-item">

                <span class="print-info-label">
                    الصف:
                </span>

                <span class="print-info-value">
                    ${escapeHTML(
                        classText
                    )}
                </span>

            </div>


            <div class="print-info-item">

                <span class="print-info-label">
                    عدد الطلاب:
                </span>

                <span class="print-info-value">
                    ${escapeHTML(
                        formatNumber(
                            studentCount
                        )
                    )}
                </span>

            </div>


        </div>

    </div>


    <div class="print-table-wrap">

        ${printableTable}

    </div>


    <div class="print-footer">

        تقرير الغياب الشهري — مُعين | MUEEN

    </div>


</div>


<script>

    window.onload = function () {

        setTimeout(
            function () {

                window.focus();

                window.print();

            },
            500
        );

    };


    window.onafterprint = function () {

        setTimeout(
            function () {

                window.close();

            },
            300
        );

    };

</script>


</body>

</html>

`;


    printWindow.document.open();

    printWindow.document.write(
        printDocument
    );

    printWindow.document.close();

}


/* ==================================================
   NAVIGATION
================================================== */

function goMain(page) {

    window.location.replace(
        page
    );
}


function goServicePage(page) {

    window.location.href =
        page;
}


function goSubPage(page) {

    window.location.href =
        page;
}


/* ==================================================
   EVENTS
================================================== */

function bindEvents() {


    /* --------------------------------------------------
       FILTERS
    -------------------------------------------------- */

    $("monthSelect")
        ?.addEventListener(
            "change",
            () => {

                state.selectedStudents =
                    new Set();

                rebuildStudents();

                buildReport();

            }
        );


    $("subjectSelect")
        ?.addEventListener(
            "change",
            () => {

                buildReport();

            }
        );


    $("classSelect")
        ?.addEventListener(
            "change",
            () => {

                state.selectedStudents =
                    new Set();

                rebuildStudents();

                buildReport();

            }
        );


    /* --------------------------------------------------
       STUDENT SEARCH
    -------------------------------------------------- */

    $("studentSearch")
        ?.addEventListener(
            "input",
            () => {

                renderStudentSearch();

            }
        );


    $("clearStudentSearch")
        ?.addEventListener(
            "click",
            () => {

                const input =
                    $("studentSearch");


                if (input) {

                    input.value = "";

                    input.focus();

                }


                renderStudentSearch();

            }
        );


    $("clearStudentSelection")
        ?.addEventListener(
            "click",
            () => {

                state.selectedStudents =
                    new Set();

                updateSelectionUI();

                renderStudentSearch();

                buildReport();

            }
        );


    /* --------------------------------------------------
       EXPORT
    -------------------------------------------------- */

    $("exportExcelButton")
        ?.addEventListener(
            "click",
            exportTableToExcel
        );


    $("exportPdfButton")
        ?.addEventListener(
            "click",
            exportToPDF
        );


    /* --------------------------------------------------
       HEADER BACK
    -------------------------------------------------- */

    $("backButton")
        ?.addEventListener(
            "click",
            () => {

                goMain(
                    "reports.html"
                );

            }
        );


    /* --------------------------------------------------
       BOTTOM NAVIGATION
       نفس الصفحة الرئيسية
    -------------------------------------------------- */

    $("homeNavigation")
        ?.addEventListener(
            "click",
            () =>
                goMain(
                    "home.html"
                )
        );


    $("attendanceNavigation")
        ?.addEventListener(
            "click",
            () =>
                goMain(
                    "attendance.html"
                )
        );


    $("studentsNavigation")
        ?.addEventListener(
            "click",
            () =>
                goMain(
                    "students.html"
                )
        );


    $("scheduleNavigation")
        ?.addEventListener(
            "click",
            () =>
                goMain(
                    "schedule.html"
                )
        );


    $("gradesNavigation")
        ?.addEventListener(
            "click",
            () =>
                goMain(
                    "grades.html"
                )
        );


    $("reportsNavigation")
        ?.addEventListener(
            "click",
            () =>
                goMain(
                    "reports.html"
                )
        );

}


/* ==================================================
   INITIALIZE
================================================== */

function initialize() {

    refreshStorage();

    buildMonthSelect();

    buildSubjectSelect();

    buildClassSelect();

    rebuildStudents();

    updateSelectionUI();

    bindEvents();

    buildReport();

}


/* ==================================================
   STORAGE REFRESH
================================================== */

window.addEventListener(
    "storage",
    () => {

        refreshStorage();

        buildMonthSelect();

        buildSubjectSelect();

        buildClassSelect();

        rebuildStudents();

        buildReport();

    }
);


/* ==================================================
   PAGE VISIBILITY
================================================== */

document.addEventListener(
    "visibilitychange",
    () => {

        if (
            document.visibilityState ===
            "visible"
        ) {

            refreshStorage();

            buildMonthSelect();

            buildSubjectSelect();

            buildClassSelect();

            rebuildStudents();

            buildReport();

        }

    }
);


/* ==================================================
   START
================================================== */

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initialize
    );

} else {

    initialize();

}