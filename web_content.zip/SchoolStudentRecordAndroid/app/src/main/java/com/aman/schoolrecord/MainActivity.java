package com.aman.schoolrecord;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.text.InputType;
import android.content.SharedPreferences;
import android.util.Base64;
import java.security.MessageDigest;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;
    private static final String PREFS = "school_record_lock";
    private static final String PIN_HASH = "pin_hash";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.contains(PIN_HASH)) showPinDialog(true);
        else showPinDialog(false);
    }

    private String hash(String pin) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256").digest(pin.getBytes("UTF-8"));
            return Base64.encodeToString(bytes, Base64.NO_WRAP);
        } catch (Exception e) { return ""; }
    }

    private void showPinDialog(boolean setup) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = (int)(22 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad, pad, pad);
        TextView message = new TextView(this);
        message.setText(setup ? "Create a 6-digit app PIN. Keep it private." : "Enter your app PIN to open student records.");
        layout.addView(message);
        EditText pin = new EditText(this);
        pin.setHint("6-digit PIN");
        pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pin.setSingleLine(true);
        layout.addView(pin);
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("School Student Record")
            .setView(layout)
            .setCancelable(false)
            .setPositiveButton(setup ? "Set PIN" : "Unlock", null)
            .setNegativeButton(setup ? "Exit" : "Exit", (d, w) -> finish())
            .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            String value = pin.getText().toString().trim();
            if (!value.matches("\\d{6}")) { pin.setError("Enter exactly 6 digits"); return; }
            String currentHash = hash(value);
            if (setup) {
                prefs.edit().putString(PIN_HASH, currentHash).apply();
                dialog.dismiss();
                openApp();
            } else if (currentHash.equals(prefs.getString(PIN_HASH, ""))) {
                dialog.dismiss();
                openApp();
            } else {
                pin.setError("Incorrect PIN");
            }
        }));
        dialog.show();
    }

    private void openApp() {
        webView = new WebView(this);
        webView.setBackgroundColor(0xFFF4F6FA);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setDatabaseEnabled(true);
        settings.setSupportZoom(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
