# File picker fix

This update adds Android WebView file chooser handling so HTML `<input type="file">` controls can open Android's file picker/gallery.

## Important
- This is updated Android project source, not a compiled APK.
- Rebuild the APK using your build service / Android build workflow after replacing the old project source with this updated project.
- Test with dummy images first.
- The prototype stores data in WebView localStorage and does not encrypt student document images. Do not use real B-Form/CNIC scans until secure encrypted storage is implemented and verified.
