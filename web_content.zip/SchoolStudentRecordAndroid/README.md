# School Student Record — Android project

This is an Android Studio project wrapper for the offline HTML prototype.

## Included
- Student profile register and optional document/photo attachments
- Daily attendance and monthly attendance analysis
- Test/marks records
- Parent call log and follow-up date
- Textbook issue/return tracking
- Reports and JSON export/restore
- First-launch 6-digit PIN gate and Android screenshot blocking (`FLAG_SECURE`)
- No Internet permission; designed to work offline

## Build APK
1. Install Android Studio on a computer.
2. Open this folder as an existing Android Studio project.
3. Let Android Studio download the Android Gradle Plugin and SDK components.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Debug APK is normally created under `app/build/outputs/apk/debug/app-debug.apk`.

## Important privacy limitation
This is a prototype, not a security-audited student records product. The PIN gate is an access barrier, but the HTML records stored by WebView are **not encrypted at rest**. Do not store real B-Form/CNIC scans or other sensitive student data until encrypted database/storage and tested recovery are implemented. The PIN hash is stored locally; use a strong device lock too. Backups are JSON files and are not encrypted. Keep them in a secure location.

The build requires Android Studio/SDK and internet access for the first dependency download. This execution environment did not have a configured Android SDK/Gradle build tool, so it could not produce a verified APK binary here.
