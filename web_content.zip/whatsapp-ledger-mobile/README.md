# WhatsApp Ledger — mobile MVP

A mobile-first, local-processing PWA prototype for analysing WhatsApp `.zip` chat exports (TXT + media), extracting likely NGN transaction amounts from chat text and receipt images, and exporting separate monthly Excel worksheets.

## Run / install

This is a static PWA and must be served over HTTPS (or localhost) for service-worker installation. Deploy the folder to any static HTTPS host, then open its URL in Android Chrome and choose **Install app** / **Add to Home screen**. No account or backend is required.

The first load requires internet to load JSZip, Tesseract.js and SheetJS from jsDelivr. The service worker caches the app shell; CDN libraries may need internet on first use and are not yet bundled for fully offline cold starts.

## WhatsApp export

In WhatsApp, open a group → menu → More → Export chat → Include media. Choose ZIP where available. Import one ZIP per group and give it a distinct group/project name.

## Current MVP capabilities

- Parses common WhatsApp text export date formats (DD/MM/YY or DD/MM/YYYY, time).
- Scans chat text for likely NGN payment amounts.
- Runs English OCR on JPG/JPEG/PNG/WebP media in the ZIP.
- Keeps each import as a separate group ledger.
- Provides a review/edit prompt for extracted records.
- Exports selected group or all groups to XLSX with a summary and month worksheets.
- Stores records in browser localStorage; includes JSON backup and delete controls.

## Important limitations before accounting use

This is an initial prototype, not an audited accounting system. Receipt-to-message matching is basic; many receipts need manual review. It currently extracts only amounts it can recognise as NGN, does not reliably infer sender/recipient/reference from every bank's layout, and does not yet support every WhatsApp export date format or HEIC media. Duplicate detection is heuristic. Review every transaction against the original receipt before relying on totals. Browser storage can be cleared by Android/browser settings, so download backups regularly.

## Privacy

The app does not upload chat files, images or ledger data to a backend. OCR runs in the browser. The OCR/ZIP/XLSX libraries are fetched from a public CDN on first load. For stricter offline use, bundle and self-host pinned library files and add an offline cache test before production.
