CABLESAT V2.4 - COMPARTIR PDF REALMENTE GUARDADO

CAMBIO PRINCIPAL
El boton "Compartir PDF" comparte directamente el archivo PDF fisico que acaba de guardarse mediante Android Storage Access Framework. No vuelve a generar el PDF ni intenta compartir el Blob del navegador.

1. Sustituye index.html y MainActivity.java en el proyecto Android.
2. Conserva los permisos de ubicacion agregados anteriormente.
3. Compila e instala.
4. Genera y guarda una solicitud.
5. Pulsa "Compartir PDF" y selecciona WhatsApp, correo, Telegram, etc.

El archivo compartido es el mismo URI que Android creo al guardar la solicitud en:
CABLESAT/Solicitudes/AÑO/MES/

El URI se conserva como ultimo_pdf_uri para poder compartir nuevamente el ultimo PDF guardado.

No es necesario borrar los datos de la aplicacion.
