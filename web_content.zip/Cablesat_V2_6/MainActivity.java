// CABLESAT V2.2 - MainActivity.java
// Mantén el package original de tu proyecto si existe.

import android.Manifest;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Looper;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.net.URLEncoder;

public class MainActivity extends Activity {
    private static final int REQUEST_CREATE_PDF = 9001;
    private static final int REQUEST_OPEN_PDF = 9002;
    private static final int REQUEST_ROOT_FOLDER = 9003;
    private static final int REQUEST_LOCATION = 9004;

    private boolean locationPending = false;

    private WebView webView;
    private byte[] pendingPdf;
    private String pendingFileName;
    private String pendingYear;
    private String pendingMonth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void generateAndSavePdf(String jsonData, String fileName, String solicitudDate) {
            try {
                byte[] pdf = buildNativePdf(jsonData);
                pendingPdf = pdf;
                pendingFileName = sanitizeFileName(fileName);
                String[] ym = getYearMonth(solicitudDate);
                pendingYear = ym[0];
                pendingMonth = ym[1];
                runOnUiThread(() -> {
                    Uri root = getSavedRoot();
                    if (root != null) saveIntoOrganizedFolder(root);
                    else {
                        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                        startActivityForResult(intent, REQUEST_ROOT_FOLDER);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> toast("No se pudo generar el PDF: " + e.getMessage()));
            }
        }

        @JavascriptInterface
        public void guardarPDFCarta(String jsonData, String fileName, String solicitudDate) {
            try {
                // NUEVO MECANISMO: genera el PDF directamente con PdfDocument Android.
                // Siempre produce tamaño Carta (612 x 792 puntos) y exactamente 2 páginas:
                // 1) solicitud, 2) documentación/fotos del DUI.
                pendingPdf = buildNativePdf(jsonData);
                pendingFileName = sanitizeFileName(fileName);
                String[] ym = getYearMonth(solicitudDate);
                pendingYear = ym[0];
                pendingMonth = ym[1];
                runOnUiThread(() -> {
                    // El nuevo botón siempre permite escoger la carpeta en cada guardado.
                    // Dentro de ella Android creará CABLESAT/Solicitudes/AÑO/MES.
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION |
                            Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                    startActivityForResult(intent, REQUEST_ROOT_FOLDER);
                });
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> toast("No se pudo crear el PDF tamaño Carta: " + e.getMessage()));
            }
        }

        @JavascriptInterface
        public void savePdf(String base64Pdf, String fileName, String solicitudDate) {
            try {
                pendingPdf = Base64.decode(base64Pdf, Base64.DEFAULT);
                pendingFileName = sanitizeFileName(fileName);
                String[] ym = getYearMonth(solicitudDate);
                pendingYear = ym[0];
                pendingMonth = ym[1];

                runOnUiThread(() -> {
                    // Si ya se escogió una carpeta raíz, se guarda automáticamente en
                    // CABLESAT/Solicitudes/AÑO/MES. Si no, se pide una sola vez.
                    Uri root = getSavedRoot();
                    if (root != null) {
                        saveIntoOrganizedFolder(root);
                    } else {
                        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                                Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION |
                                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                        startActivityForResult(intent, REQUEST_ROOT_FOLDER);
                    }
                });
            } catch (Exception e) {
                toast("No se pudo preparar el PDF");
            }
        }

        @JavascriptInterface
        public void openPdf() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/pdf");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(intent, REQUEST_OPEN_PDF);
            });
        }

        @JavascriptInterface
        public void shareLastPdf() {
            runOnUiThread(() -> {
                String value = getPreferences(MODE_PRIVATE).getString("last_pdf_uri", null);
                String name = getPreferences(MODE_PRIVATE).getString("last_pdf_name", "Solicitud_Cablesat.pdf");
                if (value == null || value.isEmpty()) {
                    toast("Primero genera y guarda una solicitud PDF.");
                    return;
                }
                try {
                    Uri uri = Uri.parse(value);
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("application/pdf");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.putExtra(Intent.EXTRA_SUBJECT, "Solicitud Cablesat");
                    share.putExtra(Intent.EXTRA_TEXT, "Solicitud de servicio Cablesat");
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, "Enviar PDF"));
                } catch (Exception e) {
                    toast("No se pudo compartir el PDF guardado.");
                }
            });
        }

        @JavascriptInterface
        public void getCurrentLocation() {
            runOnUiThread(() -> {
                if (android.os.Build.VERSION.SDK_INT >= 23 &&
                        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    locationPending = true;
                    requestPermissions(new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    }, REQUEST_LOCATION);
                    return;
                }
                obtenerUbicacionActual();
            });
        }

        @JavascriptInterface
        public void openGoogleMapsSearch(String query) {
            runOnUiThread(() -> {
                try {
                    String url = "https://www.google.com/maps/search/?api=1&query=" +
                            URLEncoder.encode(query == null ? "" : query, "UTF-8").replace("+", "%20");
                    abrirUrlMaps(url);
                } catch (Exception e) {
                    toast("No se pudo abrir Google Maps");
                }
            });
        }

        @JavascriptInterface
        public void openGoogleMapsCoordinates(double lat, double lon) {
            runOnUiThread(() -> {
                try {
                    String uriText = String.format(Locale.US, "geo:%f,%f?q=%f,%f", lat, lon, lat, lon);
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uriText));
                    intent.setPackage("com.google.android.apps.maps");
                    try {
                        startActivity(intent);
                    } catch (Exception noMaps) {
                        String url = String.format(Locale.US,
                                "https://www.google.com/maps/search/?api=1&query=%f,%f", lat, lon);
                        abrirUrlMaps(url);
                    }
                } catch (Exception e) {
                    toast("No se pudo abrir Google Maps");
                }
            });
        }
    }

    private void abrirUrlMaps(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        try {
            startActivity(intent);
        } catch (Exception e) {
            toast("No hay una aplicación disponible para abrir el mapa");
        }
    }

    private void obtenerUbicacionActual() {
        try {
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            if (lm == null) { toast("No se pudo acceder al GPS"); return; }

            boolean gps = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
            boolean network = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            if (!gps && !network) {
                toast("Activa la ubicación/GPS del teléfono e inténtalo nuevamente");
                return;
            }

            Location best = null;
            if (android.os.Build.VERSION.SDK_INT >= 23 &&
                    checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                toast("Se necesita permiso de ubicación");
                return;
            }
            if (gps) best = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location net = network ? lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) : null;
            if (best == null || (net != null && net.getTime() > best.getTime())) best = net;

            if (best != null && best.getTime() > System.currentTimeMillis() - 120000) {
                enviarUbicacion(best);
                return;
            }

            final LocationListener listener = new LocationListener() {
                @Override public void onLocationChanged(Location location) {
                    try { lm.removeUpdates(this); } catch (Exception ignored) {}
                    enviarUbicacion(location);
                }
                @Override public void onProviderEnabled(String provider) {}
                @Override public void onProviderDisabled(String provider) {}
                @Override public void onStatusChanged(String provider, int status, android.os.Bundle extras) {}
            };

            if (gps) lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 1f, listener, Looper.getMainLooper());
            else lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000L, 1f, listener, Looper.getMainLooper());

            new android.os.Handler(Looper.getMainLooper()).postDelayed(() -> {
                try { lm.removeUpdates(listener); } catch (Exception ignored) {}
                if (webView != null) webView.evaluateJavascript(
                        "window.locationCaptureTimeout && window.locationCaptureTimeout();", null);
            }, 15000L);
        } catch (Exception e) {
            toast("No se pudo obtener la ubicación. Verifica que el GPS esté activo.");
        }
    }

    private void enviarUbicacion(Location location) {
        if (location == null || webView == null) { toast("No se obtuvo una ubicación válida"); return; }
        double lat = location.getLatitude();
        double lon = location.getLongitude();
        float accuracy = location.hasAccuracy() ? location.getAccuracy() : 0f;
        String js = String.format(Locale.US, "window.recibirUbicacion(%f,%f,%f);", lat, lon, accuracy);
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_LOCATION) {
            boolean ok = false;
            for (int r : grantResults) if (r == PackageManager.PERMISSION_GRANTED) { ok = true; break; }
            if (ok) obtenerUbicacionActual();
            else toast("Permiso de ubicación denegado");
            locationPending = false;
        }
    }

    private Uri getSavedRoot() {
        String value = getPreferences(MODE_PRIVATE).getString("root_uri", null);
        return value == null ? null : Uri.parse(value);
    }

    private void saveRoot(Uri uri) {
        try {
            int flags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
            getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (Exception ignored) { }
        getPreferences(MODE_PRIVATE).edit().putString("root_uri", uri.toString()).apply();
    }

    private void saveIntoOrganizedFolder(Uri root) {
        try {
            Uri cablesat = findOrCreateDirectory(root, "CABLESAT");
            Uri solicitudes = findOrCreateDirectory(cablesat, "Solicitudes");
            Uri year = findOrCreateDirectory(solicitudes, pendingYear);
            Uri month = findOrCreateDirectory(year, pendingMonth);

            Uri fileUri = DocumentsContract.createDocument(
                    getContentResolver(), month, "application/pdf", pendingFileName);
            if (fileUri == null) throw new Exception("No se pudo crear el archivo");

            try (OutputStream out = getContentResolver().openOutputStream(fileUri)) {
                if (out == null) throw new Exception("No se pudo abrir el archivo");
                out.write(pendingPdf);
                out.flush();
            }
            getPreferences(MODE_PRIVATE).edit()
                    .putString("last_pdf_uri", fileUri.toString())
                    .putString("last_pdf_name", pendingFileName)
                    .apply();
            toast("PDF guardado en CABLESAT/Solicitudes/" + pendingYear + "/" + pendingMonth);
            clearPending();
        } catch (Exception e) {
            // Si el permiso quedó inválido, vuelve a pedir la carpeta raíz.
            getPreferences(MODE_PRIVATE).edit().remove("root_uri").apply();
            toast("No se pudo organizar el PDF. Selecciona nuevamente la carpeta raíz.");
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION |
                    Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
            startActivityForResult(intent, REQUEST_ROOT_FOLDER);
        }
    }

    private Uri findOrCreateDirectory(Uri parent, String name) throws Exception {
        String parentDocId = DocumentsContract.getDocumentId(parent);
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(parent, parentDocId);
        try (android.database.Cursor c = getContentResolver().query(
                children,
                new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                        DocumentsContract.Document.COLUMN_MIME_TYPE},
                null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String display = c.getString(1);
                    String mime = c.getString(2);
                    if (name.equals(display) && DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                        return DocumentsContract.buildDocumentUriUsingTree(parent, c.getString(0));
                    }
                }
            }
        }
        Uri created = DocumentsContract.createDocument(getContentResolver(), parent,
                DocumentsContract.Document.MIME_TYPE_DIR, name);
        if (created == null) throw new Exception("No se pudo crear carpeta " + name);
        return created;
    }

    private String[] getYearMonth(String date) {
        try {
            if (date != null && date.matches("\\d{4}-\\d{2}-\\d{2}")) {
                String[] p = date.split("-");
                int m = Integer.parseInt(p[1]);
                String[] months = {"01 - Enero","02 - Febrero","03 - Marzo","04 - Abril",
                        "05 - Mayo","06 - Junio","07 - Julio","08 - Agosto","09 - Septiembre",
                        "10 - Octubre","11 - Noviembre","12 - Diciembre"};
                return new String[]{p[0], months[Math.max(1, Math.min(12, m)) - 1]};
            }
        } catch (Exception ignored) { }
        String year = new SimpleDateFormat("yyyy", Locale.getDefault()).format(new Date());
        String month = new SimpleDateFormat("MM - MMMM", Locale.getDefault()).format(new Date());
        return new String[]{year, capitalize(month)};
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0,1).toUpperCase(Locale.getDefault()) + s.substring(1);
    }

    private String sanitizeFileName(String name) {
        if (name == null || name.trim().isEmpty()) return "Solicitud_Cablesat.pdf";
        String clean = name.trim().replaceAll("[\\\\/:*?\"<>|]", "_");
        if (!clean.toLowerCase(Locale.ROOT).endsWith(".pdf")) clean += ".pdf";
        return clean;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_ROOT_FOLDER) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri root = data.getData();
                saveRoot(root);
                if (pendingPdf != null) saveIntoOrganizedFolder(root);
            } else {
                clearPending();
                toast("Guardado cancelado");
            }
            return;
        }

        if (requestCode == REQUEST_OPEN_PDF) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                try {
                    int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    if ((flags & Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0) {
                        try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) { }
                    }
                    byte[] bytes = readAll(uri);
                    String marker = extractMarker(bytes);
                    if (marker == null) throw new Exception("PDF no compatible");
                    byte[] jsonBytes = Base64.decode(marker, Base64.DEFAULT);
                    String json = new String(jsonBytes, StandardCharsets.UTF_8);
                    String js = "window.cargarDatosDesdePDF(" + quoteJs(json) + ");";
                    webView.post(() -> webView.evaluateJavascript(js, null));
                } catch (Exception e) {
                    toast("Este PDF no contiene una solicitud Cablesat compatible.");
                }
            }
            return;
        }

        if (requestCode == REQUEST_CREATE_PDF) {
            // Compatibilidad con versiones anteriores del proyecto.
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingPdf != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new Exception();
                    out.write(pendingPdf);
                    out.flush();
                    getPreferences(MODE_PRIVATE).edit()
                            .putString("last_pdf_uri", data.getData().toString())
                            .putString("last_pdf_name", pendingFileName)
                            .apply();
                    toast("PDF guardado correctamente");
                } catch (Exception e) { toast("No se pudo guardar el PDF"); }
            }
            clearPending();
        }
    }

    private byte[] readAll(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new Exception();
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            return out.toByteArray();
        }
    }

    private String extractMarker(byte[] bytes) {
        String text = new String(bytes, StandardCharsets.ISO_8859_1);
        String begin = "%%CABLESAT_DATA_BEGIN";
        String end = "%%CABLESAT_DATA_END";
        int a = text.indexOf(begin);
        if (a < 0) return null;
        a += begin.length();
        int b = text.indexOf(end, a);
        if (b < 0) return null;
        String encoded = text.substring(a, b).replaceAll("\\s+", "");
        return encoded.isEmpty() ? null : encoded;
    }

    private String quoteJs(String value) {
        return "\"" + value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n")
                .replace("\u2028", "\\u2028")
                .replace("\u2029", "\\u2029") + "\"";
    }

    private byte[] buildNativePdf(String json) throws Exception {
        org.json.JSONObject d = new org.json.JSONObject(json);
        PdfDocument doc = new PdfDocument();
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // Tamaño Carta: 612 x 792 puntos. Exactamente 2 páginas.
        PdfDocument.Page page1 = doc.startPage(
                new PdfDocument.PageInfo.Builder(612, 792, 1).create());
        drawSolicitudPage(page1.getCanvas(), p, d);
        doc.finishPage(page1);

        PdfDocument.Page page2 = doc.startPage(
                new PdfDocument.PageInfo.Builder(612, 792, 2).create());
        drawDuiOnlyPage(page2.getCanvas(), p, d);
        doc.finishPage(page2);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        doc.writeTo(out);
        doc.close();
        return out.toByteArray();
    }

    private int lastIndexOf(byte[] data, byte[] pattern) {
        outer: for (int i=data.length-pattern.length; i>=0; i--) {
            for (int j=0; j<pattern.length; j++) if (data[i+j]!=pattern[j]) continue outer;
            return i;
        }
        return -1;
    }

    private void drawSolicitudPage(Canvas c, Paint p, org.json.JSONObject d) {
        c.drawColor(android.graphics.Color.WHITE);
        p.setStyle(Paint.Style.FILL); p.setColor(android.graphics.Color.rgb(18,98,82)); c.drawRect(0,0,612,58,p);
        p.setColor(android.graphics.Color.WHITE); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(17); c.drawText("SOLICITUD DE SERVICIO DE INTERNET",28,35,p);
        float y=72;
        field(c,p,28,y,268,"VELOCIDAD SERVICIO",val(d,"velocidad")); field(c,p,316,y,268,"FECHA",val(d,"fecha")); y+=48;
        field(c,p,28,y,268,"PERIODO DE CONTRATO",val(d,"periodo")); field(c,p,316,y,268,"PRECIO",money(val(d,"precio"))); y+=48;
        field(c,p,28,y,268,"TECNOLOGÍA",val(d,"tecnologia")); field(c,p,316,y,268,"CÓDIGO",val(d,"codigo")); y+=48;
        field(c,p,28,y,556,"NOMBRE:",val(d,"nombre")); y+=48;
        field(c,p,28,y,556,"NÚMERO DE DUI",val(d,"dui")); y+=48;
        field(c,p,28,y,556,"DIRECCIÓN / LUGAR",val(d,"direccion")); y+=48;
        field(c,p,28,y,180,"TELÉFONO N° 1",val(d,"telefono")); field(c,p,216,y,180,"TELÉFONO N° 2",val(d,"telefono2")); field(c,p,404,y,180,"WHATSAPP",val(d,"whatsapp")); y+=48;
        p.setColor(android.graphics.Color.DKGRAY); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(9); c.drawText("REFERENCIAS",28,y+8,p); y+=14;
        field(c,p,28,y,180,"NOMBRE",val(d,"ref1")); field(c,p,216,y,180,"PARENTESCO",val(d,"parentesco1")); field(c,p,404,y,180,"TELÉFONO",val(d,"refTel1")); y+=48;
        field(c,p,28,y,556,"OBSERVACIONES",val(d,"observaciones")); y+=48;
        field(c,p,28,y,556,"COORDENADAS",val(d,"coordenadas")); y+=48;
        field(c,p,28,y,268,"FECHA PROGRAMADA DE INSTALACIÓN",val(d,"fechaInstalacion")); field(c,p,316,y,268,"HORARIO DE INSTALACIÓN",val(d,"horarioInstalacion")); y+=48;
        field(c,p,28,y,180,"MEDIO",val(d,"medio")); field(c,p,216,y,180,"VENDEDOR",val(d,"vendedor")); field(c,p,404,y,180,"DEPENDENCIA",val(d,"dependencia"));
        p.setColor(android.graphics.Color.rgb(18,98,82)); c.drawRect(28,y+43,584,y+45,p);
        p.setColor(android.graphics.Color.GRAY); p.setTypeface(Typeface.DEFAULT); p.setTextSize(7); c.drawText("CABLESAT • SOLICITUD DE SERVICIO",28,y+59,p);
    }

    private void field(Canvas c, Paint p,float x,float y,float w,String label,String value){
        p.setStyle(Paint.Style.FILL); p.setColor(android.graphics.Color.rgb(246,248,249)); c.drawRect(x,y,x+w,y+38,p);
        p.setColor(android.graphics.Color.rgb(50,60,65)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(7.5f); c.drawText(label,x+6,y+11,p);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(9); String v=value==null?"":value; if(v.length()>62)v=v.substring(0,59)+"..."; c.drawText(v,x+6,y+28,p);
    }

    private void drawDuiOnlyPage(Canvas c, Paint p, org.json.JSONObject d) {
        c.drawColor(android.graphics.Color.WHITE);
        // Segunda hoja: únicamente las dos imágenes del DUI.
        drawPhoto(c, d.optString("fotoFrente", ""), new RectF(28, 24, 584, 380));
        drawPhoto(c, d.optString("fotoReverso", ""), new RectF(28, 412, 584, 768));
    }

    private void drawPhoto(Canvas c,String data,RectF box){
        Paint q=new Paint(Paint.ANTI_ALIAS_FLAG); q.setStyle(Paint.Style.STROKE); q.setStrokeWidth(1); q.setColor(android.graphics.Color.LTGRAY); c.drawRect(box,q);
        if(data==null||data.isEmpty())return; try{String b64=data.contains(",")?data.substring(data.indexOf(",")+1):data; Bitmap bmp=BitmapFactory.decodeByteArray(Base64.decode(b64,Base64.DEFAULT),0,Base64.decode(b64,Base64.DEFAULT).length); if(bmp==null)return; float scale=Math.min(box.width()/bmp.getWidth(),box.height()/bmp.getHeight()); float w=bmp.getWidth()*scale,h=bmp.getHeight()*scale; float l=box.left+(box.width()-w)/2f,t=box.top+(box.height()-h)/2f; c.drawBitmap(bmp,null,new RectF(l,t,l+w,t+h),new Paint(Paint.ANTI_ALIAS_FLAG)); bmp.recycle();}catch(Exception ignored){}
    }
    private String val(org.json.JSONObject d,String key){return d.optString(key,"");}
    private String money(String v){if(v==null||v.trim().isEmpty())return "";return v.startsWith("$")?v:"$"+v;}

    private void clearPending() {
        pendingPdf = null;
        pendingFileName = null;
        pendingYear = null;
        pendingMonth = null;
    }

    private void toast(String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
