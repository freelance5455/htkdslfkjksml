CABLESAT V2.5 - NUEVO GUARDADO PDF CARTA (2 HOJAS)

Se conserva la función anterior "Guardar" y la función "Limpiar".
Se añade un botón independiente: "📝 Guardar PDF Carta (2 hojas)".

Este botón NO utiliza el generador PDF JavaScript anterior. Llama directamente a Android PdfDocument y crea un PDF tamaño Carta de 612x792 puntos con exactamente 2 páginas:
1. Solicitud de servicio.
2. Documentación de DUI con frente y reverso.

El archivo se guarda mediante el mismo mecanismo de organización:
CABLESAT / Solicitudes / AÑO / MES

El nombre se propone automáticamente y puede modificarse antes de guardar.

Sustituir index.html y MainActivity.java en el proyecto Android Studio. No eliminar los datos de la app.
