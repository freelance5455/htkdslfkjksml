CABLESAT V2.6

En Realizar solicitud quedan únicamente tres acciones principales:
1. Guardar: conserva el registro para Gestionar.
2. Guardar PDF: genera un PDF nativo de Android tamaño Carta (612x792) con exactamente 2 páginas. La página 1 contiene todos los campos de la solicitud; la página 2 contiene únicamente las dos imágenes del DUI. En cada generación se abre el selector de carpeta de Android. Dentro de la carpeta seleccionada se crean CABLESAT/Solicitudes/AÑO/MES y se guarda el PDF con nombre automático editable.
3. Limpiar: conserva la función de limpiar el formulario.

IMPORTANTE: reemplazar index.html y MainActivity.java. Mantener los permisos de ubicación de versiones anteriores. No borrar los datos de la aplicación.
