# Keep overlay service
-keep class com.pcmode.overlay.service.** { *; }
