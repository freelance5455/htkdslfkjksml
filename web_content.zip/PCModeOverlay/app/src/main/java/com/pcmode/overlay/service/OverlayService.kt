package com.pcmode.overlay.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.pcmode.overlay.R
import com.pcmode.overlay.ui.MainActivity
import com.pcmode.overlay.utils.PrefsHelper

class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var params: WindowManager.LayoutParams? = null

    companion object {
        const val CHANNEL_ID = "pc_mode_overlay_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "com.pcmode.overlay.STOP"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        setupOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        // Refresh if settings changed
        if (overlayView != null) {
            applySettings()
        }
        return START_STICKY
    }

    private fun setupOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_view, null)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 80
        }

        applySettings()
        windowManager?.addView(overlayView, params)
        PrefsHelper.setOverlayRunning(this, true)
    }

    private fun applySettings() {
        val view = overlayView ?: return
        val root = view.findViewById<LinearLayout>(R.id.overlayRoot)
        val icon = view.findViewById<ImageView>(R.id.overlayIcon)
        val text = view.findViewById<TextView>(R.id.overlayText)

        // Size
        val size = PrefsHelper.getSize(this)
        val iconSize = when (size) {
            0 -> 16
            2 -> 28
            else -> 22
        }
        val textSize = when (size) {
            0 -> 11f
            2 -> 15f
            else -> 13f
        }
        val padH = when (size) {
            0 -> 8
            2 -> 16
            else -> 12
        }
        val padV = when (size) {
            0 -> 5
            2 -> 10
            else -> 8
        }

        val density = resources.displayMetrics.density
        icon.layoutParams = icon.layoutParams.apply {
            width = (iconSize * density).toInt()
            height = (iconSize * density).toInt()
        }
        text.textSize = textSize
        root.setPadding(
            (padH * density).toInt(),
            (padV * density).toInt(),
            (padH * density).toInt(),
            (padV * density).toInt()
        )

        // Theme
        val theme = PrefsHelper.getTheme(this)
        if (theme == 1) { // light
            root.setBackgroundResource(R.drawable.bg_overlay_light)
            text.setTextColor(getColor(R.color.overlay_text_light))
        } else {
            root.setBackgroundResource(R.drawable.bg_overlay_dark)
            text.setTextColor(getColor(R.color.overlay_text_dark))
        }

        // Transparency (alpha of whole view)
        val alpha = PrefsHelper.getTransparency(this) / 100f
        root.alpha = alpha

        // Show / hide
        root.visibility = if (PrefsHelper.isShowLogo(this)) View.VISIBLE else View.GONE

        // Position
        val pos = PrefsHelper.getPosition(this)
        params?.gravity = when (pos) {
            0 -> Gravity.TOP or Gravity.START
            1 -> Gravity.TOP or Gravity.END
            2 -> Gravity.BOTTOM or Gravity.START
            else -> Gravity.BOTTOM or Gravity.END
        }
        params?.x = 16
        params?.y = if (pos <= 1) 80 else 100

        try {
            windowManager?.updateViewLayout(overlayView, params)
        } catch (_: Exception) { }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "PC Mode Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows when PC Mode indicator is active"
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val openPi = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, OverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPi = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setContentText(getString(R.string.overlay_notification_text))
            .setSmallIcon(R.drawable.ic_pc_monitor)
            .setContentIntent(openPi)
            .addAction(0, "Stop", stopPi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            if (overlayView != null) {
                windowManager?.removeView(overlayView)
            }
        } catch (_: Exception) { }
        overlayView = null
        PrefsHelper.setOverlayRunning(this, false)
    }
}
