package com.pcmode.overlay.utils

import android.content.Context
import android.content.SharedPreferences

object PrefsHelper {
    private const val PREFS = "pc_mode_prefs"

    const val KEY_SIZE = "size"           // 0=small, 1=medium, 2=large
    const val KEY_POSITION = "position"   // 0=TL, 1=TR, 2=BL, 3=BR
    const val KEY_TRANSPARENCY = "transparency" // 0-100
    const val KEY_THEME = "theme"         // 0=dark, 1=light
    const val KEY_SHOW_LOGO = "show_logo"
    const val KEY_OVERLAY_RUNNING = "overlay_running"

    private fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getSize(ctx: Context) = prefs(ctx).getInt(KEY_SIZE, 1)
    fun setSize(ctx: Context, v: Int) = prefs(ctx).edit().putInt(KEY_SIZE, v).apply()

    fun getPosition(ctx: Context) = prefs(ctx).getInt(KEY_POSITION, 1)
    fun setPosition(ctx: Context, v: Int) = prefs(ctx).edit().putInt(KEY_POSITION, v).apply()

    fun getTransparency(ctx: Context) = prefs(ctx).getInt(KEY_TRANSPARENCY, 85)
    fun setTransparency(ctx: Context, v: Int) = prefs(ctx).edit().putInt(KEY_TRANSPARENCY, v).apply()

    fun getTheme(ctx: Context) = prefs(ctx).getInt(KEY_THEME, 0)
    fun setTheme(ctx: Context, v: Int) = prefs(ctx).edit().putInt(KEY_THEME, v).apply()

    fun isShowLogo(ctx: Context) = prefs(ctx).getBoolean(KEY_SHOW_LOGO, true)
    fun setShowLogo(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean(KEY_SHOW_LOGO, v).apply()

    fun isOverlayRunning(ctx: Context) = prefs(ctx).getBoolean(KEY_OVERLAY_RUNNING, false)
    fun setOverlayRunning(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean(KEY_OVERLAY_RUNNING, v).apply()
}
