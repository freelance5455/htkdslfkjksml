package com.pcmode.overlay.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.pcmode.overlay.R
import com.pcmode.overlay.databinding.ActivityMainBinding
import com.pcmode.overlay.service.OverlayService
import com.pcmode.overlay.utils.PrefsHelper

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            startOverlayService()
        } else {
            Toast.makeText(this, "Permission denied. Overlay cannot start.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        updateUI()

        binding.btnToggleOverlay.setOnClickListener {
            if (PrefsHelper.isOverlayRunning(this)) {
                stopOverlayService()
            } else {
                requestOverlayPermissionAndStart()
            }
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnPreview.setOnClickListener {
            startActivity(Intent(this, PreviewActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        updateUI()
    }

    private fun updateUI() {
        val running = PrefsHelper.isOverlayRunning(this)
        if (running) {
            binding.tvStatus.text = "Active"
            binding.tvStatus.setTextColor(ContextCompat.getColor(this, R.color.accent_green))
            binding.tvStatusHint.text = "PC Mode indicator is visible on screen"
            binding.btnToggleOverlay.text = getString(R.string.stop_overlay)
            binding.btnToggleOverlay.setBackgroundResource(R.drawable.bg_button_orange)
        } else {
            binding.tvStatus.text = "Inactive"
            binding.tvStatus.setTextColor(ContextCompat.getColor(this, R.color.accent_orange))
            binding.tvStatusHint.text = "Tap Start to show PC Mode indicator"
            binding.btnToggleOverlay.text = getString(R.string.start_overlay)
            binding.btnToggleOverlay.setBackgroundResource(R.drawable.bg_button_neon)
        }
    }

    private fun requestOverlayPermissionAndStart() {
        if (Settings.canDrawOverlays(this)) {
            startOverlayService()
        } else {
            AlertDialog.Builder(this)
                .setTitle(R.string.permission_title)
                .setMessage(R.string.permission_message)
                .setPositiveButton(R.string.grant_permission) { _, _ ->
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    overlayPermissionLauncher.launch(intent)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun startOverlayService() {
        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        PrefsHelper.setOverlayRunning(this, true)
        updateUI()
        Toast.makeText(this, "PC Mode started", Toast.LENGTH_SHORT).show()
    }

    private fun stopOverlayService() {
        stopService(Intent(this, OverlayService::class.java))
        PrefsHelper.setOverlayRunning(this, false)
        updateUI()
        Toast.makeText(this, "PC Mode stopped", Toast.LENGTH_SHORT).show()
    }
}
