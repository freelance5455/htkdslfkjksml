package com.pcmode.overlay.ui

import android.content.Intent
import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.pcmode.overlay.R
import com.pcmode.overlay.databinding.ActivitySettingsBinding
import com.pcmode.overlay.service.OverlayService
import com.pcmode.overlay.utils.PrefsHelper

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadSettings()
        setupListeners()
    }

    private fun loadSettings() {
        // Size
        when (PrefsHelper.getSize(this)) {
            0 -> binding.sizeGroup.check(R.id.btnSizeSmall)
            2 -> binding.sizeGroup.check(R.id.btnSizeLarge)
            else -> binding.sizeGroup.check(R.id.btnSizeMedium)
        }

        // Position
        highlightPosition(PrefsHelper.getPosition(this))

        // Transparency
        val trans = PrefsHelper.getTransparency(this)
        binding.seekTransparency.progress = trans
        binding.tvTransparencyValue.text = "$trans%"

        // Theme
        when (PrefsHelper.getTheme(this)) {
            1 -> binding.themeGroup.check(R.id.btnThemeLight)
            else -> binding.themeGroup.check(R.id.btnThemeDark)
        }

        // Show logo
        binding.switchShowLogo.isChecked = PrefsHelper.isShowLogo(this)
    }

    private fun setupListeners() {
        binding.btnBack.setOnClickListener { finish() }

        binding.seekTransparency.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.tvTransparencyValue.text = "$progress%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.btnPosTopLeft.setOnClickListener { highlightPosition(0) }
        binding.btnPosTopRight.setOnClickListener { highlightPosition(1) }
        binding.btnPosBottomLeft.setOnClickListener { highlightPosition(2) }
        binding.btnPosBottomRight.setOnClickListener { highlightPosition(3) }

        binding.btnSave.setOnClickListener { saveSettings() }
    }

    private var selectedPosition = 1

    private fun highlightPosition(pos: Int) {
        selectedPosition = pos
        val buttons = listOf(
            binding.btnPosTopLeft,
            binding.btnPosTopRight,
            binding.btnPosBottomLeft,
            binding.btnPosBottomRight
        )
        buttons.forEachIndexed { index, btn ->
            if (index == pos) {
                btn.strokeColor = ContextCompat.getColorStateList(this, R.color.accent_neon)
                btn.setTextColor(ContextCompat.getColor(this, R.color.accent_neon))
            } else {
                btn.strokeColor = ContextCompat.getColorStateList(this, R.color.divider)
                btn.setTextColor(ContextCompat.getColor(this, R.color.text_primary))
            }
        }
    }

    private fun saveSettings() {
        // Size
        val size = when (binding.sizeGroup.checkedButtonId) {
            R.id.btnSizeSmall -> 0
            R.id.btnSizeLarge -> 2
            else -> 1
        }
        PrefsHelper.setSize(this, size)

        // Position
        PrefsHelper.setPosition(this, selectedPosition)

        // Transparency
        PrefsHelper.setTransparency(this, binding.seekTransparency.progress)

        // Theme
        val theme = if (binding.themeGroup.checkedButtonId == R.id.btnThemeLight) 1 else 0
        PrefsHelper.setTheme(this, theme)

        // Show logo
        PrefsHelper.setShowLogo(this, binding.switchShowLogo.isChecked)

        // Refresh running overlay if active
        if (PrefsHelper.isOverlayRunning(this)) {
            startService(Intent(this, OverlayService::class.java))
        }

        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
        finish()
    }
}
