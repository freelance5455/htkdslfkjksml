package com.pcmode.overlay.ui

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.pcmode.overlay.R
import com.pcmode.overlay.databinding.ActivityPreviewBinding
import com.pcmode.overlay.utils.PrefsHelper

class PreviewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPreviewBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        applyPreviewSettings()

        binding.btnClosePreview.setOnClickListener { finish() }
    }

    private fun applyPreviewSettings() {
        val root = binding.previewOverlay
        val icon = binding.previewIcon
        val text = binding.previewText

        // Size
        val size = PrefsHelper.getSize(this)
        val iconSize = when (size) {
            0 -> 16
            2 -> 28
            else -> 22
        }
        val textSize = when (size) {
            0 -> 11f
            2 -> 15f
            else -> 13f
        }
        val density = resources.displayMetrics.density
        icon.layoutParams = icon.layoutParams.apply {
            width = (iconSize * density).toInt()
            height = (iconSize * density).toInt()
        }
        text.textSize = textSize

        // Theme
        val theme = PrefsHelper.getTheme(this)
        if (theme == 1) {
            root.setBackgroundResource(R.drawable.bg_overlay_light)
            text.setTextColor(ContextCompat.getColor(this, R.color.overlay_text_light))
        } else {
            root.setBackgroundResource(R.drawable.bg_overlay_dark)
            text.setTextColor(ContextCompat.getColor(this, R.color.overlay_text_dark))
        }

        // Transparency
        root.alpha = PrefsHelper.getTransparency(this) / 100f

        // Visibility
        root.visibility = if (PrefsHelper.isShowLogo(this)) View.VISIBLE else View.GONE

        // Position
        val params = root.layoutParams as FrameLayout.LayoutParams
        val pos = PrefsHelper.getPosition(this)
        params.gravity = when (pos) {
            0 -> Gravity.TOP or Gravity.START
            1 -> Gravity.TOP or Gravity.END
            2 -> Gravity.BOTTOM or Gravity.START
            else -> Gravity.BOTTOM or Gravity.END
        }
        params.setMargins(24, 80, 24, 120)
        root.layoutParams = params
    }
}
