# PC Mode Overlay – Free Fire MAX Visual Indicator

**Pure visual companion indicator only.**  
No game modification • No auto-aim • No memory editing • No anti-cheat bypass

---

## Features

- PC Monitor icon + “PC Mode” text
- Size: Small / Medium / Large
- Position: Top-Left / Top-Right / Bottom-Left / Bottom-Right
- Transparency: 0–100%
- On/Off toggle
- Dark & Light theme
- Android 10+ (API 29+)
- Modern gaming-style UI
- Overlay stops automatically when app/service is closed
- Clear permission request with user consent

---

## Project Structure

```
PCModeOverlay/
├── app/
│   ├── src/main/
│   │   ├── java/com/pcmode/overlay/
│   │   │   ├── ui/
│   │   │   │   ├── MainActivity.kt      ← Dashboard
│   │   │   │   ├── SettingsActivity.kt  ← Settings
│   │   │   │   └── PreviewActivity.kt   ← Live preview
│   │   │   ├── service/
│   │   │   │   └── OverlayService.kt    ← Floating overlay
│   │   │   └── utils/
│   │   │       └── PrefsHelper.kt
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   ├── drawable/
│   │   │   └── values/
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts
├── build.gradle.kts
└── settings.gradle.kts
```

---

## How to Build APK

1. Open the folder in **Android Studio** (Hedgehog or newer recommended)
2. Wait for Gradle sync
3. Connect a device or start an emulator (Android 10+)
4. Click **Run** or go to **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. APK will be generated at:  
   `app/build/outputs/apk/debug/app-debug.apk`

### Release Build
```
./gradlew assembleRelease
```

---

## Required Permission

Only one special permission is used:

- `SYSTEM_ALERT_WINDOW` (“Display over other apps”)

The app clearly explains why it is needed and opens the system settings page for the user to grant it manually.

---

## Important Notes

- This is a **visual indicator only**.
- It does **not** read, write, or modify any Free Fire / Free Fire MAX files.
- It does **not** interact with game memory.
- Closing the app / stopping the service removes the overlay immediately.
- Designed to be fully compliant with Google Play policies for companion apps.

---

## HTML Previews

Open the following files in any browser to see the UI mockups:

- `html/dashboard.html`
- `html/settings.html`
- `html/preview.html`

---

Made with ❤️ as a clean visual companion.
