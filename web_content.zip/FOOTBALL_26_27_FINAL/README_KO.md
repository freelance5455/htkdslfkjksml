# FOOTBALL 26/27 Android 프로젝트

- 앱 이름: FOOTBALL
- 앱 아이콘: 제공된 26/27 FOOTBALL 이미지
- 화면 방향: 가로(landscape) 고정
- 게임: `app/src/main/assets/www/index.html`

Android Studio에서 프로젝트 루트(`FOOTBALL_26_27`)를 열고 Gradle Sync 후 APK를 빌드하세요.
