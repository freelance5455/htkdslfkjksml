/* ===== طبقة Supabase: بتربط التطبيق بقاعدة البيانات (لو config.js فيه المفاتيح) ===== */
const SB_ON=!!(window.APP_CONFIG&&APP_CONFIG.SUPABASE_URL&&APP_CONFIG.SUPABASE_ANON_KEY&&window.supabase);
let sb=null,SBR={staff:null,user:null},REM={},STAFF=[],OCH=null,QO=null;const CID=Math.random().toString(36).slice(2);
if(SB_ON){
sb=supabase.createClient(APP_CONFIG.SUPABASE_URL,APP_CONFIG.SUPABASE_ANON_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
ACC={rest:"",owner:"",email:"",user:"",h:""};TEAM=[];SESS=false;
const o2row=o=>({id:o.id,ts:o.ts,src:o.src,name:o.name,phone:o.phone,dt:o.dt,addr:o.addr||"",items:o.items,fee:+o.fee||0,status:o.status,notes:o.notes||"",pay:o.pay||"cash",tid:o.tid||""});
const row2o=r=>({id:r.id,ts:+r.ts,src:r.src,name:r.name,phone:r.phone,dt:r.dt,addr:r.addr,items:r.items,fee:+r.fee,status:r.status,notes:r.notes,pay:r.pay,tid:r.tid});
const nj=o=>JSON.stringify(o2row(o));
function beep(){try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const o=AC.createOscillator(),g=AC.createGain();o.frequency.value=880;o.connect(g);g.connect(AC.destination);g.gain.setValueAtTime(.2,AC.currentTime);g.gain.exponentialRampToValueAtTime(.001,AC.currentTime+.5);o.start();o.stop(AC.currentTime+.5)}catch(e){}}
/* ---- بيانات المنيو والإعدادات (للجميع) ---- */
function applyPublic(p){if(!p)return;if(p.items)DATA.items=p.items;DATA.items.forEach(x=>{x.img=x.ci||IMG[x.n]});if(p.cats)CATS=p.cats;if(p.offs)OFFS=p.offs;if(p.wal)WAL=p.wal;if(p.set)ST=p.set;if(p.mus)MUS=p.mus;
 try{p.logo?localStorage.setItem("ao_logo",p.logo):localStorage.removeItem("ao_logo")}catch(e){}
 cart=cart.filter(l=>find(l.id));applyCats();applyOffs();applyWal();applySet();setLogo();init();renderCart()}
async function loadPublic(){const{data}=await sb.from("app_state").select("value").eq("key","public").maybeSingle();if(data&&data.value)applyPublic(data.value)}
async function pushPublic(){if(!SBR.staff)return;const v=pubState();v.by=CID;if((v.mus.data||"").length>150000){v.mus.data="";v.mus.name=""}
 const{error}=await sb.from("app_state").upsert({key:"public",value:v,updated_at:new Date().toISOString()});toast(error?"تعذّر الحفظ: "+error.message:"تم الحفظ للعملاء ✓")}
schedulePub=function(){if(!SBR.staff)return;clearTimeout(PT);PT=setTimeout(pushPublic,1500)};
pubNow=async function(){await pushPublic()};
/* ---- الطلبات ---- */
async function syncOrders(){const cur=new Map(ORD.map(o=>[o.id,nj(o)]));
 for(const o of ORD){const j=cur.get(o.id);if(!(o.id in REM)){const{error}=await sb.from("orders").insert(o2row(o));if(!error)REM[o.id]=j}
  else if(REM[o.id]!==j&&SBR.staff){const{error}=await sb.from("orders").update(o2row(o)).eq("id",o.id);if(!error)REM[o.id]=j}}
 if(SBR.staff)for(const id of Object.keys(REM))if(!cur.has(id)){const{error}=await sb.from("orders").delete().eq("id",id);if(!error)delete REM[id]}}
dbPush=function(k){if(k=="ao_ord"){clearTimeout(QO);QO=setTimeout(syncOrders,300)}};
async function loadOrders(){const{data}=await sb.from("orders").select("*").order("ts",{ascending:false}).limit(3000);if(data){ORD=data.map(row2o);REM={};ORD.forEach(o=>REM[o.id]=nj(o))}}
function unsubOrders(){if(OCH){try{sb.removeChannel(OCH)}catch(e){}OCH=null}}
function subOrders(){unsubOrders();OCH=sb.channel("ord").on("postgres_changes",{event:"*",schema:"public",table:"orders"},p=>{
 if(p.eventType=="INSERT"){const o=row2o(p.new);if(!ORD.some(x=>x.id==o.id)){ORD.push(o);REM[o.id]=nj(o);beep();toast("طلب جديد من "+o.name)}}
 else if(p.eventType=="UPDATE"){const o=row2o(p.new),i=ORD.findIndex(x=>x.id==o.id);if(i>=0)ORD[i]=o;else ORD.push(o);REM[o.id]=nj(o)}
 else if(p.eventType=="DELETE"){ORD=ORD.filter(x=>x.id!=p.old.id);delete REM[p.old.id]}
 if($("#admin").classList.contains("on")&&SESS=="sb"&&["orders","rep"].includes(A.tab)&&!$("#admModal").classList.contains("on"))dash()}).subscribe()}
function subPublic(){sb.channel("pub").on("postgres_changes",{event:"*",schema:"public",table:"app_state"},p=>{const v=p.new&&p.new.value;if(v&&v.by!==CID)applyPublic(v)}).subscribe()}
/* ---- الدخول ---- */
async function loadStaff(){const{data}=await sb.from("staff").select("*").order("email");STAFF=data||[]}
async function afterAuth(){const{data:{session}}=await sb.auth.getSession();
 if(!session){SBR={staff:null,user:null};SESS=false;TEAM=[];return}
 SBR.user=session.user;const em=(session.user.email||"").toLowerCase();const{data:st}=await sb.from("staff").select("*").eq("email",em).maybeSingle();SBR.staff=st||null;
 if(st){SESS="sb";TEAM=[{id:"sb",name:st.name||em,email:st.email,user:st.email,role:st.role,perms:st.perms||[],h:""}];await loadOrders();subOrders();if(can("team"))await loadStaff()}else{SESS=false;TEAM=[]}}
const wrap=b=>{$("#admBody").innerHTML=`<div class="card2" style="border-radius:36px;border-color:#3a2f12;margin-top:20px"><div class="logo" style="width:130px;height:130px;margin:4px auto 12px"><img src="${lg()}" alt=""></div><h2 class="nl" style="border:0;text-align:center;font-size:28px;padding:0">لوحة إدارة المطعم</h2><div style="text-align:center;color:var(--gold);margin:6px 0 16px">أبو عمر الكندي · مشويات على الفحم</div>${b}</div>`};
const er='<div class="err" id="aerr" style="display:none;margin:12px 0 0"></div>';
authView=function(k){A.auth=k;let b="";
 if(k=="login")b=fld("البريد الإلكتروني","l1","owner@restaurant.com","mail","email",'dir="ltr"')+fld("كلمة المرور","l2","••••••","key","password")+er+gb("تسجيل الدخول","doLogin()","logout")+lnk("<span style='color:var(--gold)'>نسيت كلمة المرور؟</span>","authView('forgot')")+`<button class="btn dark" style="width:100%;justify-content:center;margin-top:16px;color:var(--gold);border-color:#6b5a22" onclick="authView('reg')">${ic("store",22)} إنشاء حساب جديد</button><p class="sub" style="text-align:center;line-height:1.9;margin:14px 0 0">الحساب بيتفعّل كمالك أو موظف بعد ما صاحب المطعم يضيف بريدك في تبويب الفريق.</p><div style="border-top:1px solid var(--line);margin:16px 0 0"></div>`+lnk("← رجوع للمطعم","go('home')");
 else if(k=="reg")b=fld("الاسم","r2","أبو عمر","user")+fld("البريد الإلكتروني","r3","owner@restaurant.com","mail","email",'dir="ltr"')+fld("كلمة المرور","r5","••••••","lock","password")+fld("تأكيد كلمة المرور","r6","••••••","lock","password")+er+gb("إنشاء الحساب","doReg()","check")+lnk("عندي حساب بالفعل — دخول ←","authView('login')");
 else if(k=="forgot")b=`<h3 class="ar" style="text-align:center;font-size:24px;margin:0">استرجاع كلمة المرور</h3><p class="sub" style="text-align:center">اكتب بريد الحساب وهنبعتلك رابط تختار منه كلمة مرور جديدة.</p>`+fld("البريد الإلكتروني","f1","owner@restaurant.com","mail","email",'dir="ltr"')+er+gb("إرسال الرابط","doSend()","mail")+lnk("← رجوع لتسجيل الدخول","authView('login')");
 else if(k=="newpw")b=`<h3 class="ar" style="text-align:center;font-size:24px;margin:0">كلمة مرور جديدة</h3>`+fld("كلمة المرور الجديدة","n1","••••••","lock","password")+fld("تأكيد كلمة المرور","n2","••••••","lock","password")+er+gb("حفظ","doNewPw()","check");
 else b=`<div class="wp" style="text-align:center">الحساب ده مش مضاف كموظف لسه.<br><span class="sub">اطلب من صاحب المطعم يضيف بريدك (${esc(SBR.user?SBR.user.email:"")}) في تبويب الفريق.</span></div>`+gb("تسجيل خروج","logout()","logout");
 wrap(b)};
renderAdmin=function(){ACC.rest=ST.name||"مطعم أبو عمر الكندي";if(A.auth=="newpw")return authView("newpw");if(SESS=="sb"&&SBR.staff)return dash();if(SBR.user&&!SBR.staff)return authView("notstaff");authView(["reg","forgot"].includes(A.auth)?A.auth:"login")};
doLogin=async function(){const{error}=await sb.auth.signInWithPassword({email:gv("l1").toLowerCase(),password:$("#l2").value});if(error)return aerr("البريد أو كلمة المرور غلط.");await afterAuth();A.tab="orders";renderAdmin()};
doReg=async function(){const n=gv("r2"),e=gv("r3").toLowerCase(),p=$("#r5").value;if(n.length<2)return aerr("اكتب اسمك.");if(!/^\S+@\S+\.\S+$/.test(e))return aerr("اكتب بريد صحيح.");if(p.length<6)return aerr("كلمة المرور ٦ حروف على الأقل.");if(p!==$("#r6").value)return aerr("كلمتا المرور مش متطابقتين.");
 const{data,error}=await sb.auth.signUp({email:e,password:p,options:{data:{name:n}}});if(error)return aerr(error.message);
 if(data.session){await afterAuth();A.tab="orders";renderAdmin()}else{authView("login");toast("تم إنشاء الحساب — لو وصلك طلب تأكيد، افتح رسالة البريد الأول")}};
doSend=async function(){const{error}=await sb.auth.resetPasswordForEmail(gv("f1").toLowerCase(),{redirectTo:location.href.split("#")[0]});if(error)return aerr(error.message);authView("login");toast("بعتنالك رابط على بريدك ✓")};
doNewPw=window.doNewPw=async function(){const p=$("#n1").value;if(p.length<6)return aerr("كلمة المرور ٦ حروف على الأقل.");if(p!==$("#n2").value)return aerr("كلمتا المرور مش متطابقتين.");const{error}=await sb.auth.updateUser({password:p});if(error)return aerr(error.message);A.auth="login";await afterAuth();renderAdmin();toast("تم تغيير كلمة المرور ✓")};
logout=async function(){try{await sb.auth.signOut()}catch(e){}unsubOrders();SBR={staff:null,user:null};SESS=false;TEAM=[];ORD=[];REM={};A.auth="login";authView("login")};
sb.auth.onAuthStateChange((ev)=>{if(ev=="PASSWORD_RECOVERY")setTimeout(()=>{A.auth="newpw";go("admin")},0)});
/* ---- الفريق ---- */
let DTi=null;
teamTab=function(){return `<div class="card2" style="border-color:#3a2f12;margin-top:6px"><h3>${ic("users",22)} إدارة الفريق والصلاحيات</h3><p class="sub" style="line-height:1.9;margin-top:0">ضيف بريد الموظف وحدد دوره وصلاحياته. بعدها الموظف يعمل حساب بنفس البريد (من شاشة الدخول ← إنشاء حساب) ويدخل من أي جهاز.</p><button class="btn gold" style="width:100%;justify-content:center" onclick="editTeam()">${ic("userplus",20)} إضافة موظف</button></div>`+STAFF.map((m,i)=>`<div class="oc" style="cursor:default"><div><b class="n" dir="ltr">${esc(m.email)}</b><small>${esc(m.name||"")} · ${RL[m.role]}</small></div><div style="display:flex;gap:8px;align-items:center"><span class="stb" style="color:#4ade9a;border-color:#1f6b52;background:#0e1f18">${m.role=="staff"?(m.perms||[]).length:ALLP.length} صلاحية</span><button class="eb" onclick="editTeam(${i})">تعديل</button><button class="eb" style="${DTi===i?"color:#f0899a;border-color:#f0899a":""}" onclick="delTeam(${i})">${DTi===i?"تأكيد؟":ic("trash",20)}</button></div></div>`).join("")};
editTeam=function(i){const m=STAFF[i];ET=m?{...m,perms:[...(m.perms||[])]}:{email:"",name:"",role:"staff",perms:["orders"],isNew:1};drawET();openAdm()};
drawET=function(){const e=ET,full=e.role!="staff";$("#admBox").innerHTML=mh(e.isNew?"إضافة موظف جديد":"تعديل الموظف")+lb("الاسم")+inp(e.name,"ET.name=this.value")+lb("البريد الإلكتروني (هيسجّل بيه)")+inp(e.email,"ET.email=this.value","email","",e.isNew?'dir="ltr"':'dir="ltr" disabled')+lb("الدور")+[["owner","صاحب المطعم","كل الصلاحيات بدون استثناء."],["manager","مدير","إدارة الطلبات والمنيو والعروض والتقارير والفريق مع بعض."],["staff","موظف","يشوف ويشتغل في الأقسام اللي بتحددها بس."]].map(r=>`<div class="rc ${e.role==r[0]?"on":""}" onclick="ET.role='${r[0]}';drawET()"><b>${r[1]}</b><small>${r[2]}</small></div>`).join("")+`<div class="mh">الصلاحيات المسموح بها</div>`+PL.map(p=>{const on=full||e.perms.includes(p[0]);return `<div class="rc pc ${on?"on":""}" onclick="${full?"":`togP('${p[0]}')`}"><div><b>${p[1]}</b><small>${p[2]}</small></div><span class="bx">${on?"✓":""}</span></div>`}).join("")+`<div class="err" id="aerr" style="display:none"></div>`+gb("حفظ","saveET()")};
saveET=async function(){const e=ET,em=(e.email||"").trim().toLowerCase();if(!/^\S+@\S+\.\S+$/.test(em))return aerr("اكتب بريد صحيح.");if(e.role=="staff"&&!e.perms.length)return aerr("اختار صلاحية واحدة على الأقل.");
 const{error}=await sb.from("staff").upsert({email:em,name:(e.name||"").trim(),role:e.role,perms:e.role=="staff"?e.perms:[]});if(error)return aerr("تعذّر الحفظ: "+error.message);await loadStaff();closeAdm();fl("تم حفظ الموظف.")};
delTeam=async function(i){if(DTi!==i){DTi=i;dash();setTimeout(()=>{if(DTi===i){DTi=null;if(A.tab=="team"&&SESS)dash()}},3000);return}DTi=null;await sb.from("staff").delete().eq("email",STAFF[i].email);await loadStaff();dash()};
/* ---- الحساب ---- */
acctTab=function(){const C=CU(),sec=(t,i,b)=>`<div class="card2"><h3>${ic(i,22)} ${t}</h3>${b}</div>`,pf=(id,l)=>lb(l)+`<input class="fi" id="${id}" type="password">`;
 return `<div class="card2" style="border-color:#3a2f12;margin-top:6px"><div style="display:flex;gap:14px;align-items:center"><div class="th3" style="width:80px;height:80px;border-radius:50%;border:1px solid #6b5a22;background:#2a2210">${ic("uc",40)}</div><div><b style="font-size:24px">${esc(C.name)}</b><div class="sub" style="margin:0">${RL[C.role]}</div></div></div><p style="margin:16px 0 4px;color:var(--mut)">بريد الحساب: <span dir="ltr">${esc(C.email||"—")}</span></p><div style="border-top:1px solid var(--line);margin:14px 0"></div>${lb("اسم الحساب")}<div style="display:flex;gap:10px"><input class="fi" id="ac_n" value="${esc(C.name)}"><button class="btn dark" style="color:var(--gold);padding:12px 18px" onclick="saveAcN()">حفظ الاسم</button></div><button class="btn dark" style="margin-top:14px" onclick="logout()">تسجيل خروج</button></div>`+sec("تغيير كلمة المرور","key",pf("ac_p1","كلمة المرور الجديدة")+pf("ac_p2","تأكيد الجديدة")+gb("حفظ كلمة المرور الجديدة","savePw()"))+delCard()};
saveAcN=async function(){const n=$("#ac_n").value.trim();if(n.length<2)return fl("اكتب اسم صحيح.",0);const{error}=await sb.rpc("set_my_name",{n});if(error)return fl("تعذّر الحفظ.",0);await afterAuth();fl("تم حفظ الاسم.")};
savePw=async function(){const b=$("#ac_p1").value;if(b.length<6)return fl("كلمة المرور ٦ حروف على الأقل.",0);if(b!=$("#ac_p2").value)return fl("التأكيد مش مطابق.",0);const{error}=await sb.auth.updateUser({password:b});fl(error?error.message:"تم تغيير كلمة المرور.",!error)};
doDel=async function(){const{error}=await sb.auth.signInWithPassword({email:SBR.user.email,password:$("#dl_p").value});if(error)return fl("كلمة المرور غلط.",0);await sb.rpc("leave_staff");A.del=false;await logout();toast("تم حذف الحساب")};
/* ---- رفع الصور والموسيقى لمخزن Supabase ---- */
const _ri=readImg;readImg=function(f,w,cb){_ri(f,w,async d=>{if(!SBR.staff)return cb(d);try{const bl=await(await fetch(d)).blob(),path="img/"+Date.now()+"-"+Math.random().toString(36).slice(2,7)+".jpg",{error}=await sb.storage.from("menu").upload(path,bl,{contentType:"image/jpeg"});if(error)throw error;cb(sb.storage.from("menu").getPublicUrl(path).data.publicUrl)}catch(e){toast("تعذّر رفع الصورة — اتخزنت محلياً");cb(d)}})};
upMus=async function(f){if(!f||!SBR.staff)return;if(f.size>4e6)return fl("الملف كبير — الحد الأقصى ٤ ميجا.",0);const path="audio/"+Date.now()+"-"+f.name.replace(/[^\w.]/g,"_"),{error}=await sb.storage.from("menu").upload(path,f,{contentType:f.type||"audio/mpeg"});if(error)return fl("تعذّر رفع الملف: "+error.message,0);MUS.data=sb.storage.from("menu").getPublicUrl(path).data.publicUrl;MUS.name=f.name;saveMus()};
/* ---- تشغيل ---- */
(async()=>{try{await afterAuth();await loadPublic();subPublic();if(!SBR.staff)ORD.forEach(o=>REM[o.id]=nj(o));if($("#admin").classList.contains("on"))renderAdmin();resume()}catch(e){console.warn("supabase:",e)}})();
}
