SKY DASH — Android-ready endless runner prototype

This folder contains a playable browser game. To install as an Android APK, it must be wrapped and built with Android tooling (Android Studio/Gradle), which is not available in this runtime, so this package is not itself an APK.

Quick play: open index.html in Chrome. Swipe left/right to change lanes, up to jump, down to slide. Collect stars and avoid obstacles.

To create an APK:
1. Create a new Android Studio project with an Empty Activity.
2. Add a WebView to the activity and enable JavaScript.
3. Copy index.html to app/src/main/assets/index.html.
4. Load file:///android_asset/index.html in the WebView.
5. Build > Build APK(s).
