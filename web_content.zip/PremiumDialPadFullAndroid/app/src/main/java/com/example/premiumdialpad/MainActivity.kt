package com.example.premiumdialpad

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val requestCallPermission = 201
    private val requestContactsPermission = 202
    private var pendingNumber: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.addJavascriptInterface(NativeBridge(), "AndroidBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                if (uri.scheme.equals("tel", true)) {
                    startCallOrDial(uri.schemeSpecificPart ?: "")
                    return true
                }
                return uri.scheme == "http" || uri.scheme == "https"
            }

            @Suppress("DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (url == null) return false
                val uri = Uri.parse(url)
                if (uri.scheme.equals("tel", true)) {
                    startCallOrDial(uri.schemeSpecificPart ?: "")
                    return true
                }
                return uri.scheme == "http" || uri.scheme == "https"
            }
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")

        // Ask for notification permission on Android 13+.
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 203)
        }
    }

    private inner class NativeBridge {
        @JavascriptInterface
        fun callNumber(number: String) {
            runOnUiThread {
                val cleaned = number.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }
                if (cleaned.isBlank()) {
                    Toast.makeText(this@MainActivity, "আগে একটি নম্বর লিখুন", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                startCallOrDial(cleaned)
            }
        }

        @JavascriptInterface
        fun getContactsJson(): String {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread {
                    requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), requestContactsPermission)
                    Toast.makeText(this@MainActivity, "অনুমতি দিন, তারপর আবার ফোনের কন্টাক্ট আনুন", Toast.LENGTH_LONG).show()
                }
                return "[]"
            }
            val result = JSONArray()
            var cursor: Cursor? = null
            try {
                cursor = contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER
                    ),
                    null, null,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
                )
                cursor?.use {
                    val nameCol = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                    val numberCol = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    while (it.moveToNext()) {
                        val name = if (nameCol >= 0) it.getString(nameCol) ?: "" else ""
                        val number = if (numberCol >= 0) it.getString(numberCol) ?: "" else ""
                        if (name.isNotBlank() && number.isNotBlank()) {
                            val item = JSONObject()
                            item.put("name", name)
                            item.put("number", number)
                            result.put(item)
                        }
                    }
                }
            } catch (_: Exception) {
                // Return an empty list if the contact provider is unavailable.
            } finally {
                cursor?.close()
            }
            return result.toString()
        }
    }

    private fun startCallOrDial(number: String) {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            try {
                // Direct SIM call after explicit Android runtime permission.
                startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))))
                showCallNotification(number)
            } catch (_: SecurityException) {
                Toast.makeText(this, "ফোন কলের অনুমতি পাওয়া যায়নি", Toast.LENGTH_LONG).show()
                openDialer(number)
            } catch (_: Exception) {
                openDialer(number)
            }
        } else {
            pendingNumber = number
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), requestCallPermission)
        }
    }

    private fun openDialer(number: String) {
        try {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))
        } catch (_: Exception) {
            Toast.makeText(this, "এই ডিভাইসে ফোন ডায়ালার খোলা যায়নি", Toast.LENGTH_LONG).show()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "dialpad_calls",
                "Dial Pad",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "ডায়াল প্যাডের কল সংক্রান্ত নোটিফিকেশন" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun showCallNotification(number: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        try {
            val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                android.app.Notification.Builder(this, "dialpad_calls")
            } else {
                @Suppress("DEPRECATION")
                android.app.Notification.Builder(this)
            }
            val notification = builder
                .setSmallIcon(android.R.drawable.sym_action_call)
                .setContentTitle("কল শুরু করার অনুরোধ")
                .setContentText(number)
                .setAutoCancel(true)
                .build()
            getSystemService(NotificationManager::class.java).notify(1, notification)
        } catch (_: Exception) { }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            requestCallPermission -> {
                val number = pendingNumber
                pendingNumber = null
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED && number != null) {
                    startCallOrDial(number)
                } else {
                    Toast.makeText(this, "কল করার অনুমতি না থাকায় ফোনের ডায়ালার খোলা হচ্ছে", Toast.LENGTH_LONG).show()
                    if (number != null) openDialer(number)
                }
            }
            requestContactsPermission -> {
                Toast.makeText(
                    this,
                    if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                        "কন্টাক্টের অনুমতি দেওয়া হয়েছে। আবার ‘ফোনের কন্টাক্ট আনুন’ চাপুন।"
                    else "কন্টাক্টের অনুমতি দেওয়া হয়নি",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}
