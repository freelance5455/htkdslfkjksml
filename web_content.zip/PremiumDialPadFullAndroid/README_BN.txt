Premium Dial Pad — Android Studio Project
==========================================

এই ZIP একটি Android Studio source project; এটি নিজে APK নয়।

ফিচার:
- আগের Premium Dial Pad HTML UI অ্যাপের মধ্যে চলে
- কল বাটন চাপলে CALL_PHONE permission চায়; অনুমতি দিলে SIM-এর মাধ্যমে সাধারণ ফোন কল শুরু করার চেষ্টা করে
- অনুমতি না দিলে ফোনের ডায়ালার নম্বরসহ খোলে
- কন্টাক্ট ইমপোর্ট বাটনে READ_CONTACTS permission চায় এবং ফোনের contacts অ্যাপে কপি করে (অ্যাপের নিজস্ব তালিকায়)
- Android 13+ এ POST_NOTIFICATIONS অনুমতি Manifest-এ আছে; notification দেখানো অনুমতি না থাকলে notification দেখাবে না
- অ্যাপের নিজস্ব কল ইতিহাস, ফেভারিট, থিম, ব্যাকআপ ইত্যাদি HTML অংশে আছে

APK বানানোর ধাপ:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. ZIP extract করুন।
3. Android Studio > Open > PremiumDialPadFullAndroid ফোল্ডারটি নির্বাচন করুন।
4. Gradle Sync সম্পূর্ণ করুন (প্রথমবার ইন্টারনেট লাগতে পারে)।
5. Build > Build APK(s) চাপুন।
6. APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-তে তৈরি হবে।

সীমাবদ্ধতা ও নিরাপত্তা:
- সরাসরি কল করার অনুমতি দেওয়ার আগে Android permission dialog দেখায়। ব্যবহারকারী অনুমতি না দিলে app ফোনের dialer খুলবে।
- জরুরি নম্বর/প্রিমিয়াম নম্বরের ক্ষেত্রে সাবধানে ব্যবহার করুন; কল চার্জ হতে পারে।
- অ্যাপটি ডিফল্ট Phone/Dialer অ্যাপ নয়। তাই incoming-call screen, system call log, call waiting UI, system caller ID, SIM নির্বাচন, call recording, voicemail, call forwarding এবং পূর্ণ incoming call notifications পরিচালনা করে না।
- পূর্ণ ডিফল্ট ডায়ালার করতে Android Telecom framework, InCallService, RoleManager/Dialer role এবং অতিরিক্ত পরীক্ষিত নেটিভ UI দরকার।
- READ_CONTACTS permission শুধু কন্টাক্ট পড়ার জন্য; ফোনের contacts-এ নতুন contact save/edit করার permission এই সংস্করণে নেই।
- Call recording ও sensitive call-log access-এর জন্য ডিভাইস, Android version, আইন ও Google Play নীতিমালা প্রযোজ্য।
