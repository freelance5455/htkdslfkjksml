package com.privateview.street

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private lateinit var cameraExecutor: ExecutorService
    private var imageCapture: ImageCapture? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var previewView: PreviewView? = null
    private var activePanoDir: File? = null
    private var step = 0
    private val total = 26
    private val panoDirs = mutableListOf<File>()
    private lateinit var status: TextView

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCaptureScreen() else showPermissionHelp()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        setContentView(root)
        loadPanoramas()
        showHome()
    }

    private fun loadPanoramas() {
        val base = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "StreetView")
        if (!base.exists()) base.mkdirs()
        panoDirs.clear()
        base.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name }?.let { panoDirs.addAll(it) }
    }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply { this.text = text; setOnClickListener { action() } }

    private fun label(text: String, size: Float = 18f): TextView =
        TextView(this).apply { this.text = text; textSize = size; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER }

    private fun showHome() {
        root.removeAllViews()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 28, 24, 24)
        }
        layout.addView(label("PRIVATE STREET VIEW", 22f))
        layout.addView(label("Личная карта панорам", 16f))
        layout.addView(Space(this), LinearLayout.LayoutParams(1, 22))
        layout.addView(button("＋ Создать панораму") {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCaptureScreen()
            else permission.launch(Manifest.permission.CAMERA)
        })
        layout.addView(Space(this), LinearLayout.LayoutParams(1, 18))
        layout.addView(label("Мои точки: ${panoDirs.size}", 16f))
        val map = FrameLayout(this).apply {
            setBackgroundColor(0xFF090909.toInt())
        }
        val mapParams = LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 20 }
        layout.addView(map, mapParams)
        if (panoDirs.isEmpty()) {
            val empty = label("Здесь появятся твои панорамы", 14f)
            map.addView(empty, FrameLayout.LayoutParams(-1, -1))
        } else {
            val grid = GridLayout(this).apply { columnCount = 3; setPadding(12, 12, 12, 12) }
            panoDirs.forEachIndexed { index, dir ->
                val tile = button("●\n${index + 1}") { showPano(dir) }
                val p = GridLayout.LayoutParams().apply {
                    width = 0; height = 112; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins(5, 5, 5, 5)
                }
                grid.addView(tile, p)
            }
            map.addView(grid, FrameLayout.LayoutParams(-1, -1))
        }
        root.addView(layout, FrameLayout.LayoutParams(-1, -1))
    }

    private fun startCaptureScreen() {
        root.removeAllViews()
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 12, 12, 12) }
        layout.addView(label("СЪЁМКА 360°", 20f))
        status = label("Подготовка камеры…", 14f)
        layout.addView(status)
        previewView = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        layout.addView(previewView, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(label("26 кадров: 3 ряда по 8 + небо + земля", 13f))
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        buttons.addView(button("Снять кадр") { takeFrame() }, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(button("Отмена") { stopCamera(); showHome() }, LinearLayout.LayoutParams(0, -2, 1f))
        layout.addView(buttons)
        root.addView(layout, FrameLayout.LayoutParams(-1, -1))
        startCamera()
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                cameraProvider = providerFuture.get()
                val preview = Preview.Builder().build()
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setJpegQuality(95)
                    .build()
                preview.setSurfaceProvider(previewView!!.surfaceProvider)
                cameraProvider!!.unbindAll()
                cameraProvider!!.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
                status.text = "Камера включена • кадр 1 из $total"
            } catch (e: Exception) {
                status.text = "Не удалось открыть камеру: ${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takeFrame() {
        val capture = imageCapture ?: run { status.text = "Камера ещё запускается"; return }
        if (activePanoDir == null) {
            val base = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "StreetView")
            base.mkdirs()
            val name = "Pano_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            activePanoDir = File(base, name).apply { mkdirs() }
            step = 0
        }
        val file = File(activePanoDir, String.format(Locale.US, "frame_%02d.jpg", step + 1))
        val options = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(options, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                runOnUiThread {
                    step++
                    if (step >= total) {
                        File(activePanoDir, "INFO.txt").writeText("26 кадров съёмки. Это исходные кадры, не склеенная панорама.")
                        activePanoDir = null
                        stopCamera()
                        loadPanoramas()
                        Toast.makeText(this@MainActivity, "Кадры сохранены локально", Toast.LENGTH_LONG).show()
                        showHome()
                    } else {
                        status.text = "Сохранено: $step из $total кадров. Направь телефон на следующую отметку."
                    }
                }
            }
            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { status.text = "Ошибка съёмки: ${exception.message}" }
            }
        })
    }

    private fun stopCamera() {
        cameraProvider?.unbindAll()
        imageCapture = null
    }

    private fun showPermissionHelp() {
        root.removeAllViews()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(24, 24, 24, 24) }
        box.addView(label("Нужно разрешение на камеру", 20f))
        box.addView(label("Разреши приложению доступ к камере в настройках Android, затем попробуй снова.", 15f))
        box.addView(button("Повторить") { permission.launch(Manifest.permission.CAMERA) })
        box.addView(button("На главную") { showHome() })
        root.addView(box, FrameLayout.LayoutParams(-1, -1))
    }

    private fun showPano(dir: File) {
        val files = dir.listFiles()?.filter { it.extension.lowercase() == "jpg" }?.sortedBy { it.name } ?: emptyList()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18) }
        box.addView(label(dir.name, 18f))
        box.addView(label("Сохранено кадров: ${files.size}. Пока это набор кадров, а не склеенная 360° панорама.", 14f))
        box.addView(button("Назад") { showHome() })
        root.removeAllViews()
        root.addView(box, FrameLayout.LayoutParams(-1, -1))
    }

    override fun onDestroy() {
        stopCamera()
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
