# TV Kanalları — Türkiyə · Azərbaycan · Rusiya · İran

Pulsuz açıq yayım (FTA) TV kanalları üçün veb tətbiq.

## Xüsusiyyətlər

### Ölkələr
- 🇹🇷 **Türkiyə**: TRT ailəsi, Show TV, Kanal D, ATV, Star TV, TV8, teve2, Kanal 7, Beyaz TV, Halk TV, Habertürk, NTV, Bloomberg HT, A Spor, TV100 və digərləri
- 🇦🇿 **Azərbaycan**: Az TV, İctimai, Azad TV, Baku TV, APA TV, Mədəniyyət, Kanal 35, Xəzər, CBC Sport və s.
- 🇷🇺 **Rusiya**: Первый канал, Россия 1, Россия 24, НТВ, ТНТ, СТС, РЕН ТВ, Матч ТВ, Карусель, Звезда
- 🇮🇷 **İran**: Press TV, Hispan TV, Al Alam, IRIB TV1, IRINN, iFilm, **Səhər Azəri (Sahar)**

### Dizayn
- Yuxarıda ölkə **bayraqları** — toxunanda həmin ölkənin kanalları açılır
- Axtarış
- Mobil uyğun

### Reklam sistemi (pul qazanmaq üçün)
- Hər kanal dəyişəndə və ya 5 dəqiqədən bir **5 saniyəlik reklam** göstərilir
- "📢 Reklam" düyməsi → WhatsApp əlaqə
- `app.js` faylında `WHATSAPP_NUMBER` dəyişərək öz nömrənizi yazın

### Vacib qeyd
- **Pullu kanallar** (beIN Sports, Super Lig paket kanalları, premium kino kanalları) rəsmi lisenziya və ödəniş tələb etdiyi üçün daxil edilməyib. Onlar yalnız rəsmi platformalarda (tabii, TOD, beIN CONNECT və s.) mövcuddur.
- Bəzi axınlar geo-blok və ya müvəqqəti offline ola bilər. TRT və Press TV ən stabil olanlardandır.

## Necə işlətmək
1. ZIP-i açın
2. `index.html` faylını brauzerdə açın
3. Bayrağa toxunun və ya kanal seçin

## WhatsApp nömrəsini dəyişmək
`app.js` faylının əvvəlində:
```js
const WHATSAPP_NUMBER = "994501234567"; // öz nömrənizi yazın
```

Hazırlanıb: 2026
