# TV Kanalları — TR · AZ · RU · IR

## Tez başlanğıc
1. ZIP-i açın
2. `index.html` faylını brauzerdə açın (Chrome / Firefox / Edge / Safari)
3. Yuxarıdakı bayrağa toxunun → həmin ölkənin kanalları açılır

---

## ★ WhatsApp nömrəsini dəyişmək (Reklam üçün)

`app.js` faylını açın və **1-ci sətirlərə** baxın:

```js
const WHATSAPP_NUMBER = "994501234567";  // ← ÖZ NÖMRƏNİZİ YAZIN (məs: 994501112233)
```

Nömrə ölkə kodu ilə, **+ işarəsi olmadan** yazılmalıdır.  
Dəyişəndən sonra faylı yadda saxlayın və səhifəni yeniləyin.  
"📢 Reklam ver" düyməsi və reklamdakı WhatsApp linki işləyəcək.

---

## ★ Müştəri reklamını necə əlavə etmək (5 saniyəlik)

`app.js` faylında `ADS` siyahısını tapın. Hər reklam belə əlavə olunur:

```js
const ADS = [
  {
    title: "Mağaza adı / Başlıq",
    desc: "Qısa mətn (endirim, telefon və s.)",
    image: "https://example.com/reklam-sekli.jpg",  // istəyə bağlı
    link: "https://wa.me/99450xxxxxxx"               // istəyə bağlı
  },
  {
    title: "İkinci müştəri",
    desc: "Başqa reklam mətni",
    image: "",
    link: ""
  }
];
```

- Reklamlar növbə ilə göstərilir (5 saniyə)
- Hər kanal dəyişəndə və ya 4 dəqiqədən bir avtomatik çıxır
- Şəkil və link istəyə bağlıdır

---

## Kanallar haqqında dürüst məlumat

| Ölkə | Nə var |
|------|--------|
| 🇹🇷 Türkiyə | TRT 1, TRT Haber, TRT Çocuk, TRT Müzik, TRT Avaz, TRT World, TRT Türk, 360 TV, 4U TV, Kanal 7, Beyaz TV və s. |
| 🇦🇿 Azərbaycan | Az TV, İctimai, Baku TV, Azstar, Mədəniyyət, Kanal 35, Alvin, Ayaz, AnewZ və s. |
| 🇷🇺 Rusiya | Россия 24, Звезда |
| 🇮🇷 İran | Press TV, Al Alam, iFilm, Hispan TV |

**Niyə bəzi böyük kanallar (ATV, Show, Kanal D, beIN Sports) yoxdur?**  
Bu kanalların rəsmi açıq HLS axını yoxdur və ya geo-blok / ödəniş tələb edir.  
Pullu futbol (Super Lig / beIN) yalnız rəsmi platformalarda (beIN CONNECT, TOD və s.) mövcuddur.  
Qanunsuz / qeyri-sabit axınlar əlavə edilməyib — tətbiqin "qüsursuz" işləməsi üçün yalnız yoxlanmış açıq yayım URL-ləri saxlanılıb.

Bəzi kanallar vaxtaşırı offline ola bilər (yayınçı tərəfindən). TRT və Press TV adətən ən stabil olanlardır.

---

Hazırlanıb: 2026
