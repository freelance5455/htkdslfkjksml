# TV Kanalları — TR · AZ · RU · IR (40+ kanal)

## ƏN VACİB: Kanallar niyə brauzerdə açılmaya bilər?

Brauzer təhlükəsizlik qaydası (**CORS**) bir çox TV yayımını bloklayır.  
Bu normaldır. **Ən stabil yol VLC-dir.**

### VLC ilə izləmək (tövsiyə olunur)
1. [VLC](https://www.videolan.org/) yükləyin  
2. `channels.m3u` faylını VLC-də açın: **Media → Open File**  
3. Bütün kanallar siyahıda görünəcək  

və ya IPTV Smarters / TiviMate-də `channels.m3u` əlavə edin.

### Brauzerdə
`index.html` açın. Bəzi kanallar (xüsusən Az TV, Baku TV, 4U TV, Press TV) brauzerdə də işləyə bilər.

---

## Kanallar (channels.m3u)
- 🇹🇷 ~20: TRT ailəsi, Show TV, Star TV, A Spor, A Haber, Euro D, teve2, 360, Kanal 7, Beyaz TV...
- 🇦🇿 ~14: Az TV, İctimai, Baku TV, Azstar, Mədəniyyət, Alvin, Ayaz, AnewZ, APA...
- 🇷🇺 Россия 24, Звезда  
- 🇮🇷 Press TV, Al Alam, iFilm (kino), Hispan, IRIB TV1, 247 Box, AVA Family...

**Səhər Azəri (Sahar):** rəsmi açıq m3u8 axını hazırda public olaraq mövcud deyil (sayt iframe/player istifadə edir).  
**ATV / Kanal D / beIN:** rəsmi açıq HLS yoxdur.

---

## WhatsApp / Reklam
`app.js` → `WHATSAPP_NUMBER = "99450xxxxxxx"`  
`ADS` siyahısına müştəri reklamı əlavə edin.  
Reklam: hər **20 dəqiqədən bir**, **5 saniyə**.
