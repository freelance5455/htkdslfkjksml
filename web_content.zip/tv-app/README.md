# TV Kanalları — Türkiyə & Azərbaycan

Pulsuz açıq yayım (FTA) TV kanalları üçün sadə və gözəl veb tətbiq.

## Xüsusiyyətlər

- 🇹🇷 **Türkiyə kanalları**: TRT 1, TRT Haber, TRT Spor, TRT Çocuk, TRT Belgesel, TRT World və digərləri (rəsmi TRT axınları)
- 🇦🇿 **Azərbaycan kanalları**: Az TV, İctimai TV, Azad TV, Baku TV, APA TV, Mədəniyyət TV və s.
- Axtarış və ölkə filtri
- HLS.js ilə stabil oxutma (Chrome, Firefox, Edge, Safari)
- Mobil uyğun dizayn
- Heç bir quraşdırma tələb olunmur — sadəcə brauzerdə açın

## Necə işlətmək

1. `index.html` faylını brauzerdə açın (Chrome / Firefox / Edge / Safari)
2. Soldan və ya siyahıdan kanal seçin
3. İzləyin!

**Qeyd:** Bəzi kanallar geo-blok və ya müvəqqəti olaraq offline ola bilər. TRT kanalları ən stabil olanlardır.

## Fayllar

- `index.html` — əsas səhifə
- `styles.css` — dizayn
- `app.js` — məntiq və kanal siyahısı

## Texniki məlumat

- HLS axınları (m3u8)
- HLS.js kitabxanası (CDN)
- Yalnız rəsmi / ictimai açıq yayım URL-ləri istifadə olunur

---
Hazırlanıb: 2026
