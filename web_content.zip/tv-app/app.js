// ============================================================
// TV Kanalları — TR · AZ · RU · IR
// Yalnız yoxlanılmış açıq HLS axınları
// ============================================================

// ★★★ 1. ÖZ WHATSAPP NÖMRƏNİZİ YAZIN (ölkə kodu ilə, + olmadan) ★★★
const WHATSAPP_NUMBER = "994501234567";  // ← BURA ÖZ NÖMRƏNİZİ YAZIN
const WHATSAPP_MSG = encodeURIComponent("Salam! TV Kanalları tətbiqində reklam yerləşdirmək istəyirəm.");

// ★★★ 2. MÜŞTƏRİ REKLAMLARINI BURADA ƏLAVƏ EDİN ★★★
// Hər reklam 5 saniyə göstərilir. Növbə ilə dəyişir.
// title: başlıq, desc: mətn, image: şəkil URL (istəyə bağlı), link: klik linki (istəyə bağlı)
const ADS = [
  {
    title: "Sizin reklamınız burada ola bilər!",
    desc: "WhatsApp ilə əlaqə saxlayın — video, şəkil və ya yazılı reklam",
    image: "",
    link: ""
  },
  // Müştəri reklamı nümunəsi (özünüz əlavə edin):
  // {
  //   title: "Mağaza adı",
  //   desc: "Endirim 50% — zəng edin: 050-xxx-xx-xx",
  //   image: "https://example.com/reklam.jpg",
  //   link: "https://wa.me/99450xxxxxxx"
  // },
];

// Reklam hər neçə saniyədə bir göstərilsin (kanal dəyişəndə də)
const AD_INTERVAL_SECONDS = 240; // 4 dəqiqə
const AD_DURATION_SECONDS = 5;

// ============================================================
// KANALLAR — yalnız stabil açıq axınlar
// ============================================================
const channels = [
  // ——— TÜRKİYƏ (TRT rəsmi + yoxlanmış) ———
  { id: "trt1", name: "TRT 1", country: "tr", group: "Ulusal", url: "https://tv-trt1.medya.trt.com.tr/master.m3u8" },
  { id: "trthaber", name: "TRT Haber", country: "tr", group: "Haber", url: "https://tv-trthaber.medya.trt.com.tr/master.m3u8" },
  { id: "trtcocuk", name: "TRT Çocuk", country: "tr", group: "Çocuk", url: "https://tv-trtcocuk.medya.trt.com.tr/master.m3u8" },
  { id: "trtmuzik", name: "TRT Müzik", country: "tr", group: "Müzik", url: "https://tv-trtmuzik.medya.trt.com.tr/master.m3u8" },
  { id: "trtavaz", name: "TRT Avaz", country: "tr", group: "Ulusal", url: "https://tv-trtavaz.medya.trt.com.tr/master.m3u8" },
  { id: "trtworld", name: "TRT World", country: "tr", group: "Haber", url: "https://tv-trtworld.medya.trt.com.tr/master.m3u8" },
  { id: "trtturk", name: "TRT Türk", country: "tr", group: "Ulusal", url: "https://tv-trtturk.medya.trt.com.tr/master.m3u8" },
  { id: "trtkurdi", name: "TRT Kurdî", country: "tr", group: "Ulusal", url: "https://tv-trtkurdi.medya.trt.com.tr/master.m3u8" },
  { id: "trtarabi", name: "TRT Arabi", country: "tr", group: "Ulusal", url: "https://tv-trtarabi.medya.trt.com.tr/master.m3u8" },
  { id: "tv360", name: "360 TV", country: "tr", group: "Haber", url: "https://turkmedya-live.ercdn.net/tv360/tv360.m3u8" },
  { id: "4utv", name: "4U TV", country: "tr", group: "Eğlence", url: "https://hls.4utv.live/hls/stream.m3u8" },
  { id: "kanal7", name: "Kanal 7", country: "tr", group: "Ulusal", url: "https://kanal7-live.daioncdn.net/kanal7/kanal7_1080p.m3u8" },
  { id: "beyaztv", name: "Beyaz TV", country: "tr", group: "Ulusal", url: "https://beyaztv-live.daioncdn.net/beyaztv/beyaztv.m3u8" },
  { id: "aksutv", name: "Aksu TV", country: "tr", group: "Yerel", url: "https://live.artidijitalmedya.com/artidijital_aksutv/aksutv/playlist.m3u8" },

  // ——— AZƏRBAYCAN ———
  { id: "aztv", name: "Az TV", country: "az", group: "Milli", url: "https://str.yodacdn.net/azertv/index.m3u8" },
  { id: "ictimai", name: "İctimai TV", country: "az", group: "Milli", url: "https://live.itv.az/itv.m3u8" },
  { id: "bakutv", name: "Baku TV", country: "az", group: "Milli", url: "https://rtmp.baku.tv/hls/bakutv.m3u8" },
  { id: "azstartv", name: "Azstar TV", country: "az", group: "Milli", url: "https://live.livestreamtv.ca/azstar/amlst:azstar/playlist.m3u8" },
  { id: "medeniyyet", name: "Mədəniyyət TV", country: "az", group: "Mədəniyyət", url: "https://str.yodacdn.net/medeniyyettele/index.m3u8" },
  { id: "kanal35", name: "Kanal 35", country: "az", group: "Milli", url: "https://str2.yodacdn.net/kanal35/index.m3u8" },
  { id: "alvin", name: "Alvin Channel", country: "az", group: "Eyləncə", url: "https://cdn10-alvinchannel.yayin.com.tr/alvinchannel/alvinchannel/playlist.m3u8" },
  { id: "ayaztv", name: "Ayaz TV", country: "az", group: "Milli", url: "https://janya-ayaztv.vgcdn.net/ptnr-WebApp/title-Ayaz_TV/v1/vglive-sk-934820/main.m3u8" },
  { id: "anewz", name: "AnewZ", country: "az", group: "Xəbər", url: "https://53be5ef2d13aa.streamlock.net/cubesanewz-secure/smil:cubesanewz-secure-web.smil/playlist.m3u8" },
  { id: "knmusic", name: "KN Music TV", country: "az", group: "Musiqi", url: "https://cdn4.yayin.com.tr/kntv/tracks-v1a1/mono.m3u8" },
  { id: "xezertv", name: "Xəzər Xəbər", country: "az", group: "Xəbər", url: "https://www.xezerxeber.az/stream/index.m3u8" },
  { id: "naxcivantv", name: "Naxçıvan TV", country: "az", group: "Regional", url: "https://str2.yodacdn.net/ntv/video.m3u8" },

  // ——— RUSİYA (açıq) ———
  { id: "r24", name: "Россия 24", country: "ru", group: "Новости", url: "https://live-vgtrkwcdn.cdnvideo.ru/vgtrk/smil:r24.smil/playlist.m3u8" },
  { id: "zvezda", name: "Звезда", country: "ru", group: "Общие", url: "https://tvchannelstream1.tvzvezda.ru/cdn/tvzvezda/playlist.m3u8" },

  // ——— İRAN ———
  { id: "presstv", name: "Press TV", country: "ir", group: "News", url: "https://live.presstv.ir/hls/presstv_5_482/index.m3u8" },
  { id: "alalam", name: "Al Alam", country: "ir", group: "News", url: "https://live2.alalam.ir/alalam.m3u8" },
  { id: "ifilm", name: "iFilm English", country: "ir", group: "Movies", url: "https://live.presstv.co.uk/hls/ifilmen.m3u8" },
  { id: "ifilm2", name: "iFilm 2", country: "ir", group: "Movies", url: "https://live.presstv.co.uk/hls/ifilm2.m3u8" },
  { id: "hispan", name: "Hispan TV", country: "ir", group: "News", url: "https://cdnlive.presstv.ir/live/smil:live.smil/playlist.m3u8" },
];

// ============================================================
// Tətbiq məntiqi
// ============================================================
let currentCountry = "all";
let currentChannel = null;
let hls = null;
let filteredChannels = [...channels];
let lastAdTime = 0;
let adIndex = 0;
let adTimerInterval = null;

const video = document.getElementById("videoPlayer");
const overlay = document.getElementById("playerOverlay");
const channelList = document.getElementById("channelList");
const searchInput = document.getElementById("searchInput");
const npName = document.getElementById("npName");
const npCountry = document.getElementById("npCountry");
const flagBtns = document.querySelectorAll(".flag-btn");
const adOverlay = document.getElementById("adOverlay");
const adTimerEl = document.getElementById("adTimer");
const adContactBtn = document.getElementById("adContactBtn");
const adModal = document.getElementById("adModal");
const modalClose = document.getElementById("modalClose");

const countryNames = { tr: "Türkiyə", az: "Azərbaycan", ru: "Rusiya", ir: "İran" };
const countryFlags = { tr: "🇹🇷", az: "🇦🇿", ru: "🇷🇺", ir: "🇮🇷" };

function getWaLink() {
  return "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + WHATSAPP_MSG;
}

function init() {
  const wa = getWaLink();
  document.getElementById("waBigLink").href = wa;
  // Əgər reklamda link yoxdursa, WhatsApp göstər
  renderChannels();
  bindEvents();
}

function bindEvents() {
  flagBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      flagBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      currentCountry = btn.dataset.country;
      searchInput.value = "";
      filterAndRender();
    });
  });

  searchInput.addEventListener("input", filterAndRender);

  overlay.addEventListener("click", () => {
    if (currentChannel) video.play().catch(() => {});
  });

  adContactBtn.addEventListener("click", () => {
    adModal.classList.add("show");
  });
  modalClose.addEventListener("click", () => adModal.classList.remove("show"));
  adModal.addEventListener("click", e => {
    if (e.target === adModal) adModal.classList.remove("show");
  });
}

function filterAndRender() {
  const q = searchInput.value.trim().toLowerCase();
  filteredChannels = channels.filter(ch => {
    const matchC = currentCountry === "all" || ch.country === currentCountry;
    const matchS = !q || ch.name.toLowerCase().includes(q) || ch.group.toLowerCase().includes(q);
    return matchC && matchS;
  });
  renderChannels();
}

function renderChannels() {
  if (filteredChannels.length === 0) {
    channelList.innerHTML = '<div class="empty-state">Kanal tapılmadı</div>';
    return;
  }
  channelList.innerHTML = filteredChannels.map(ch => `
    <div class="channel-item ${currentChannel && currentChannel.id === ch.id ? "active" : ""}" data-id="${ch.id}">
      <span class="channel-flag">${countryFlags[ch.country] || "📺"}</span>
      <div class="channel-info">
        <div class="channel-name">${ch.name}</div>
        <div class="channel-group">${ch.group}</div>
      </div>
      <span class="channel-status"></span>
    </div>
  `).join("");

  channelList.querySelectorAll(".channel-item").forEach(item => {
    item.addEventListener("click", () => {
      const ch = channels.find(c => c.id === item.dataset.id);
      if (ch) playChannel(ch);
    });
  });
}

function playChannel(ch) {
  const now = Date.now();
  if (ADS.length > 0 && (now - lastAdTime > AD_INTERVAL_SECONDS * 1000)) {
    showAd(() => actuallyPlay(ch));
    return;
  }
  actuallyPlay(ch);
}

function actuallyPlay(ch) {
  currentChannel = ch;
  npName.textContent = ch.name;
  npCountry.textContent = (countryFlags[ch.country] || "") + " " + (countryNames[ch.country] || "");
  overlay.classList.add("hidden");

  document.querySelectorAll(".channel-item").forEach(el => {
    el.classList.toggle("active", el.dataset.id === ch.id);
  });

  if (hls) {
    hls.destroy();
    hls = null;
  }
  video.removeAttribute("src");
  video.load();

  if (video.canPlayType("application/vnd.apple.mpegurl")) {
    video.src = ch.url;
    video.play().catch(() => showError());
  } else if (window.Hls && Hls.isSupported()) {
    hls = new Hls({
      enableWorker: true,
      lowLatencyMode: false,
      backBufferLength: 90,
      maxBufferLength: 30,
      xhrSetup: function (xhr) {
        xhr.withCredentials = false;
      }
    });
    hls.loadSource(ch.url);
    hls.attachMedia(video);
    hls.on(Hls.Events.MANIFEST_PARSED, function () {
      video.play().catch(function () {});
    });
    hls.on(Hls.Events.ERROR, function (event, data) {
      if (data.fatal) {
        if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
          hls.startLoad();
        } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
          hls.recoverMediaError();
        } else {
          showError();
        }
      }
    });
  } else {
    video.src = ch.url;
    video.play().catch(() => showError());
  }
}

function showAd(callback) {
  lastAdTime = Date.now();
  const ad = ADS[adIndex % ADS.length];
  adIndex++;

  document.getElementById("adTitle").textContent = ad.title || "Reklam";
  document.getElementById("adDesc").textContent = ad.desc || "";

  const img = document.getElementById("adImage");
  if (ad.image) {
    img.src = ad.image;
    img.style.display = "block";
  } else {
    img.style.display = "none";
  }

  const linkEl = document.getElementById("adLink");
  if (ad.link) {
    linkEl.href = ad.link;
    linkEl.style.display = "inline-block";
    linkEl.textContent = "Ətraflı / Keçid";
  } else {
    linkEl.href = getWaLink();
    linkEl.style.display = "inline-block";
    linkEl.textContent = "📱 WhatsApp";
  }

  adOverlay.classList.add("show");
  let left = AD_DURATION_SECONDS;
  adTimerEl.textContent = left;

  if (adTimerInterval) clearInterval(adTimerInterval);
  adTimerInterval = setInterval(function () {
    left--;
    adTimerEl.textContent = left;
    if (left <= 0) {
      clearInterval(adTimerInterval);
      adOverlay.classList.remove("show");
      if (callback) callback();
    }
  }, 1000);
}

function showError(msg) {
  overlay.classList.remove("hidden");
  overlay.querySelector(".overlay-content").innerHTML =
    '<div class="play-icon">⚠️</div><p>' +
    (msg || "Yayım yüklənə bilmədi. Başqa kanal seçin.") +
    "</p>";
}

init();
