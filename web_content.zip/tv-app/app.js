// TV Kanalları — brauzer + VLC
// WHATSAPP və ADS burada dəyişilir

const WHATSAPP_NUMBER = "994501234567"; // ← ÖZ NÖMRƏNİZ
const WHATSAPP_MSG = encodeURIComponent("Salam! TV Kanalları tətbiqində reklam yerləşdirmək istəyirəm.");

const ADS = [
  { title: "Sizin reklamınız burada ola bilər!", desc: "WhatsApp ilə əlaqə saxlayın", image: "", link: "" }
];
const AD_INTERVAL_SECONDS = 1200; // 20 dəqiqə
const AD_DURATION_SECONDS = 5;

const channels = [
  // TR — əvvəlcə CORS-dostu olanlar
  { id:"trt1", name:"TRT 1", country:"tr", group:"Ulusal", url:"https://tv-trt1.medya.trt.com.tr/master.m3u8" },
  { id:"trthaber", name:"TRT Haber", country:"tr", group:"Haber", url:"https://tv-trthaber.medya.trt.com.tr/master.m3u8" },
  { id:"trtcocuk", name:"TRT Çocuk", country:"tr", group:"Çocuk", url:"https://tv-trtcocuk.medya.trt.com.tr/master.m3u8" },
  { id:"trtmuzik", name:"TRT Müzik", country:"tr", group:"Müzik", url:"https://tv-trtmuzik.medya.trt.com.tr/master.m3u8" },
  { id:"trtavaz", name:"TRT Avaz", country:"tr", group:"Ulusal", url:"https://tv-trtavaz.medya.trt.com.tr/master.m3u8" },
  { id:"trtworld", name:"TRT World", country:"tr", group:"Haber", url:"https://tv-trtworld.medya.trt.com.tr/master.m3u8" },
  { id:"trtturk", name:"TRT Türk", country:"tr", group:"Ulusal", url:"https://tv-trtturk.medya.trt.com.tr/master.m3u8" },
  { id:"showtv", name:"Show TV", country:"tr", group:"Ulusal", url:"https://ciner.daioncdn.net/showtv/showtv.m3u8?ce=3&app=4bc856ef-4c68-4a94-bc87-37dfaaa66558" },
  { id:"startv", name:"Star TV", country:"tr", group:"Ulusal", url:"https://dogus.daioncdn.net/startv/startv.m3u8?ce=3&app=1740db13-3ee9-4858-8d2c-b1a9cfaa3718" },
  { id:"aspor", name:"A Spor", country:"tr", group:"Spor", url:"https://rnttwmjcin.turknet.ercdn.net/lcpmvefbyo/aspor/aspor.m3u8" },
  { id:"ahaber", name:"A Haber", country:"tr", group:"Haber", url:"https://rnttwmjcin.turknet.ercdn.net/lcpmvefbyo/ahaber/ahaber.m3u8" },
  { id:"eurod", name:"Euro D", country:"tr", group:"Ulusal", url:"https://live.duhnet.tv/S2/HLS_LIVE/eurodnp/playlist.m3u8" },
  { id:"teve2", name:"teve2", country:"tr", group:"Eğlence", url:"https://live.duhnet.tv/S2/HLS_LIVE/teve2np/playlist.m3u8" },
  { id:"tv360", name:"360 TV", country:"tr", group:"Haber", url:"https://turkmedya-live.ercdn.net/tv360/tv360.m3u8" },
  { id:"4utv", name:"4U TV", country:"tr", group:"Eğlence", url:"https://hls.4utv.live/hls/stream.m3u8" },
  { id:"kanal7", name:"Kanal 7", country:"tr", group:"Ulusal", url:"https://kanal7-live.daioncdn.net/kanal7/kanal7_1080p.m3u8" },
  { id:"beyaztv", name:"Beyaz TV", country:"tr", group:"Ulusal", url:"https://beyaztv-live.daioncdn.net/beyaztv/beyaztv.m3u8" },
  { id:"aksutv", name:"Aksu TV", country:"tr", group:"Yerel", url:"https://live.artidijitalmedya.com/artidijital_aksutv/aksutv/playlist.m3u8" },
  // AZ
  { id:"aztv", name:"Az TV", country:"az", group:"Milli", url:"https://str.yodacdn.net/azertv/index.m3u8" },
  { id:"ictimai", name:"İctimai TV", country:"az", group:"Milli", url:"https://live.itv.az/itv.m3u8" },
  { id:"bakutv", name:"Baku TV", country:"az", group:"Milli", url:"https://rtmp.baku.tv/hls/bakutv.m3u8" },
  { id:"azstartv", name:"Azstar TV", country:"az", group:"Milli", url:"https://live.livestreamtv.ca/azstar/amlst:azstar/playlist.m3u8" },
  { id:"medeniyyet", name:"Mədəniyyət TV", country:"az", group:"Mədəniyyət", url:"https://str.yodacdn.net/medeniyyettele/index.m3u8" },
  { id:"kanal35", name:"Kanal 35", country:"az", group:"Milli", url:"https://str2.yodacdn.net/kanal35/index.m3u8" },
  { id:"alvin", name:"Alvin Channel", country:"az", group:"Eyləncə", url:"https://cdn10-alvinchannel.yayin.com.tr/alvinchannel/alvinchannel/playlist.m3u8" },
  { id:"ayaztv", name:"Ayaz TV", country:"az", group:"Milli", url:"https://janya-ayaztv.vgcdn.net/ptnr-WebApp/title-Ayaz_TV/v1/vglive-sk-934820/main.m3u8" },
  { id:"anewz", name:"AnewZ", country:"az", group:"Xəbər", url:"https://53be5ef2d13aa.streamlock.net/cubesanewz-secure/smil:cubesanewz-secure-web.smil/playlist.m3u8" },
  { id:"knmusic", name:"KN Music TV", country:"az", group:"Musiqi", url:"https://cdn4.yayin.com.tr/kntv/tracks-v1a1/mono.m3u8" },
  { id:"xezertv", name:"Xəzər Xəbər", country:"az", group:"Xəbər", url:"https://www.xezerxeber.az/stream/index.m3u8" },
  { id:"naxcivantv", name:"Naxçıvan TV", country:"az", group:"Regional", url:"https://str2.yodacdn.net/ntv/video.m3u8" },
  { id:"eltv", name:"EL TV", country:"az", group:"Regional", url:"https://live.eltv.az/live/eltv/playlist.m3u8" },
  { id:"apatv", name:"APA TV", country:"az", group:"Xəbər", url:"http://stream.apa.tv/apastream/index.m3u8" },
  // RU
  { id:"r24", name:"Россия 24", country:"ru", group:"Новости", url:"https://live-vgtrkwcdn.cdnvideo.ru/vgtrk/smil:r24.smil/playlist.m3u8" },
  { id:"zvezda", name:"Звезда", country:"ru", group:"Общие", url:"https://tvchannelstream1.tvzvezda.ru/cdn/tvzvezda/playlist.m3u8" },
  // IR + kino
  { id:"presstv", name:"Press TV", country:"ir", group:"News", url:"https://live.presstv.ir/hls/presstv_5_482/index.m3u8" },
  { id:"alalam", name:"Al Alam", country:"ir", group:"News", url:"https://live2.alalam.ir/alalam.m3u8" },
  { id:"ifilm", name:"iFilm English", country:"ir", group:"Kino", url:"https://live.presstv.co.uk/hls/ifilmen.m3u8" },
  { id:"ifilm2", name:"iFilm 2", country:"ir", group:"Kino", url:"https://live.presstv.co.uk/hls/ifilm2.m3u8" },
  { id:"ifilmar", name:"iFilm Arabic", country:"ir", group:"Kino", url:"https://live.presstv.co.uk/hls/ifilmar.m3u8" },
  { id:"hispan", name:"Hispan TV", country:"ir", group:"News", url:"https://cdnlive.presstv.ir/live/smil:live.smil/playlist.m3u8" },
  { id:"iribtv1", name:"IRIB TV1", country:"ir", group:"General", url:"https://ncdn.telewebion.ir/tv1/live/playlist.m3u8" },
  { id:"box247", name:"247 Box TV", country:"ir", group:"Kino", url:"https://hls.247box.live/hls/stream.m3u8" },
  { id:"avafamily", name:"AVA Family", country:"ir", group:"Kino", url:"https://familyhls.avatv.live/hls/stream.m3u8" },
  { id:"asiltv", name:"Asil TV", country:"ir", group:"General", url:"https://live.asil.tv/asiltv/index.m3u8" },
];

let currentCountry="all", currentChannel=null, hls=null, filtered=[...channels];
let lastAd=0, adIdx=0, adTimer=null;

const video=document.getElementById("videoPlayer");
const overlay=document.getElementById("playerOverlay");
const list=document.getElementById("channelList");
const search=document.getElementById("searchInput");
const npName=document.getElementById("npName");
const npCountry=document.getElementById("npCountry");
const flags=document.querySelectorAll(".flag-btn");
const adOverlay=document.getElementById("adOverlay");
const adTimerEl=document.getElementById("adTimer");
const names={tr:"Türkiyə",az:"Azərbaycan",ru:"Rusiya",ir:"İran"};
const emojis={tr:"🇹🇷",az:"🇦🇿",ru:"🇷🇺",ir:"🇮🇷"};

function wa(){ return "https://wa.me/"+WHATSAPP_NUMBER+"?text="+WHATSAPP_MSG; }

function init(){
  document.getElementById("waBigLink").href=wa();
  document.getElementById("adLink").href=wa();
  render();
  flags.forEach(b=>b.addEventListener("click",()=>{
    flags.forEach(x=>x.classList.remove("active"));
    b.classList.add("active");
    currentCountry=b.dataset.country;
    search.value="";
    filter();
  }));
  search.addEventListener("input",filter);
  overlay.addEventListener("click",()=>{ if(currentChannel) video.play().catch(()=>{}); });
  document.getElementById("adContactBtn").addEventListener("click",()=>document.getElementById("adModal").classList.add("show"));
  document.getElementById("modalClose").addEventListener("click",()=>document.getElementById("adModal").classList.remove("show"));
}

function filter(){
  const q=search.value.trim().toLowerCase();
  filtered=channels.filter(c=>{
    const okC=currentCountry==="all"||c.country===currentCountry;
    const okS=!q||c.name.toLowerCase().includes(q)||c.group.toLowerCase().includes(q);
    return okC&&okS;
  });
  render();
}

function render(){
  if(!filtered.length){ list.innerHTML='<div class="empty-state">Kanal tapılmadı</div>'; return; }
  list.innerHTML=filtered.map(c=>
    `<div class="channel-item${currentChannel&&currentChannel.id===c.id?' active':''}" data-id="${c.id}">
      <span class="channel-flag">${emojis[c.country]||'📺'}</span>
      <div class="channel-info"><div class="channel-name">${c.name}</div><div class="channel-group">${c.group}</div></div>
      <span class="channel-status"></span>
    </div>`
  ).join("");
  list.querySelectorAll(".channel-item").forEach(el=>{
    el.addEventListener("click",()=>{
      const c=channels.find(x=>x.id===el.dataset.id);
      if(c) play(c);
    });
  });
}

function play(c){
  const now=Date.now();
  if(ADS.length && now-lastAd > AD_INTERVAL_SECONDS*1000){
    showAd(()=>doPlay(c));
    return;
  }
  doPlay(c);
}

function doPlay(c){
  currentChannel=c;
  npName.textContent=c.name;
  npCountry.textContent=(emojis[c.country]||"")+" "+(names[c.country]||"");
  overlay.classList.add("hidden");
  document.querySelectorAll(".channel-item").forEach(el=>el.classList.toggle("active",el.dataset.id===c.id));
  if(hls){ hls.destroy(); hls=null; }
  video.removeAttribute("src"); video.load();

  if(video.canPlayType("application/vnd.apple.mpegurl")){
    video.src=c.url;
    video.play().catch(()=>err());
  } else if(window.Hls && Hls.isSupported()){
    hls=new Hls({
      enableWorker:true,
      lowLatencyMode:false,
      maxBufferLength:30,
      xhrSetup:function(xhr){ xhr.withCredentials=false; }
    });
    hls.loadSource(c.url);
    hls.attachMedia(video);
    hls.on(Hls.Events.MANIFEST_PARSED,()=>video.play().catch(()=>{}));
    hls.on(Hls.Events.ERROR,(e,d)=>{
      if(d.fatal){
        if(d.type===Hls.ErrorTypes.NETWORK_ERROR) hls.startLoad();
        else if(d.type===Hls.ErrorTypes.MEDIA_ERROR) hls.recoverMediaError();
        else err("Brauzer bu yayımı bloklayır (CORS). channels.m3u faylını VLC-də açın.");
      }
    });
  } else {
    video.src=c.url;
    video.play().catch(()=>err());
  }
}

function showAd(cb){
  lastAd=Date.now();
  const ad=ADS[adIdx++%ADS.length];
  document.getElementById("adTitle").textContent=ad.title||"Reklam";
  document.getElementById("adDesc").textContent=ad.desc||"";
  const img=document.getElementById("adImage");
  if(ad.image){ img.src=ad.image; img.style.display="block"; } else img.style.display="none";
  const a=document.getElementById("adLink");
  a.href=ad.link||wa();
  a.textContent=ad.link?"Ətraflı":"📱 WhatsApp";
  adOverlay.classList.add("show");
  let left=AD_DURATION_SECONDS;
  adTimerEl.textContent=left;
  if(adTimer) clearInterval(adTimer);
  adTimer=setInterval(()=>{
    left--; adTimerEl.textContent=left;
    if(left<=0){ clearInterval(adTimer); adOverlay.classList.remove("show"); if(cb) cb(); }
  },1000);
}

function err(msg){
  overlay.classList.remove("hidden");
  overlay.querySelector(".overlay-content").innerHTML=
    '<div class="play-icon">⚠️</div><p>'+(msg||"Yayım açılmadı. VLC üçün channels.m3u yükləyin.")+'</p>';
}

init();
