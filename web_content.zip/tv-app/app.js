// TV Kanalları — Türkiyə & Azərbaycan
// Rəsmi və açıq ictimai HLS axınları

const channels = [
  // ========== TÜRKİYƏ (TRT rəsmi) ==========
  { id: 'trt1', name: 'TRT 1', country: 'tr', group: 'Ulusal', url: 'https://tv-trt1.medya.trt.com.tr/master.m3u8' },
  { id: 'trt2', name: 'TRT 2', country: 'tr', group: 'Ulusal', url: 'https://tv-trt2.medya.trt.com.tr/master.m3u8' },
  { id: 'trthaber', name: 'TRT Haber', country: 'tr', group: 'Haber', url: 'https://tv-trthaber.medya.trt.com.tr/master.m3u8' },
  { id: 'trtspor', name: 'TRT Spor', country: 'tr', group: 'Spor', url: 'https://tv-trtspor1.medya.trt.com.tr/master.m3u8' },
  { id: 'trtspor2', name: 'TRT Spor 2', country: 'tr', group: 'Spor', url: 'https://tv-trtspor2.medya.trt.com.tr/master.m3u8' },
  { id: 'trtcocuk', name: 'TRT Çocuk', country: 'tr', group: 'Çocuk', url: 'https://tv-trtcocuk.medya.trt.com.tr/master.m3u8' },
  { id: 'trtmuzik', name: 'TRT Müzik', country: 'tr', group: 'Müzik', url: 'https://tv-trtmuzik.medya.trt.com.tr/master.m3u8' },
  { id: 'trtbelgesel', name: 'TRT Belgesel', country: 'tr', group: 'Belgesel', url: 'https://tv-trtbelgesel-dai.medya.trt.com.tr/master.m3u8' },
  { id: 'trtavaz', name: 'TRT Avaz', country: 'tr', group: 'Ulusal', url: 'https://tv-trtavaz.medya.trt.com.tr/master.m3u8' },
  { id: 'trtkurdi', name: 'TRT Kurdî', country: 'tr', group: 'Ulusal', url: 'https://tv-trtkurdi.medya.trt.com.tr/master.m3u8' },
  { id: 'trtarabi', name: 'TRT Arabi', country: 'tr', group: 'Ulusal', url: 'https://tv-trtarabi.medya.trt.com.tr/master.m3u8' },
  { id: 'trtworld', name: 'TRT World', country: 'tr', group: 'Haber', url: 'https://tv-trtworld.medya.trt.com.tr/master.m3u8' },
  { id: 'trtturk', name: 'TRT Türk', country: 'tr', group: 'Ulusal', url: 'https://tv-trtturk.medya.trt.com.tr/master.m3u8' },

  // Digər Türkiyə açıq axınlar
  { id: 'tv360', name: '360 TV', country: 'tr', group: 'Haber', url: 'https://turkmedya-live.ercdn.net/tv360/tv360.m3u8' },
  { id: '4utv', name: '4U TV', country: 'tr', group: 'Eğlence', url: 'https://hls.4utv.live/hls/stream.m3u8' },
  { id: 'aksutv', name: 'Aksu TV', country: 'tr', group: 'Yerel', url: 'https://live.artidijitalmedya.com/artidijital_aksutv/aksutv/playlist.m3u8' },

  // ========== AZƏRBAYCAN ==========
  { id: 'aztv', name: 'Az TV', country: 'az', group: 'Milli', url: 'https://str.yodacdn.net/azertv/index.m3u8' },
  { id: 'ictimai', name: 'İctimai TV', country: 'az', group: 'Milli', url: 'https://live.itv.az/itv.m3u8' },
  { id: 'azadtv', name: 'Azad TV (ATV)', country: 'az', group: 'Milli', url: 'https://lives.atv.az:5443/ATV_TV_STREAM/streams/atvcanli.m3u8' },
  { id: 'bakutv', name: 'Baku TV', country: 'az', group: 'Milli', url: 'https://rtmp.baku.tv/hls/bakutv.m3u8' },
  { id: 'azstartv', name: 'Azstar TV', country: 'az', group: 'Milli', url: 'https://live.livestreamtv.ca/azstar/amlst:azstar/playlist.m3u8' },
  { id: 'apatv', name: 'APA TV', country: 'az', group: 'Xəbər', url: 'http://stream.apa.tv/apastream/index.m3u8' },
  { id: 'medeniyyet', name: 'Mədəniyyət TV', country: 'az', group: 'Mədəniyyət', url: 'https://str.yodacdn.net/medeniyyettele/index.m3u8' },
  { id: 'kanal35', name: 'Kanal 35', country: 'az', group: 'Milli', url: 'https://str2.yodacdn.net/kanal35/index.m3u8' },
  { id: 'kanals', name: 'Kanal S', country: 'az', group: 'Milli', url: 'https://lives.atv.az:5443/KANAL-S/streams/kanals.m3u8' },
  { id: 'naxcivantv', name: 'Naxçıvan TV', country: 'az', group: 'Regional', url: 'https://str2.yodacdn.net/ntv/video.m3u8' },
  { id: 'xezertv', name: 'Xəzər TV', country: 'az', group: 'Xəbər', url: 'https://www.xezerxeber.az/stream/index.m3u8' },
  { id: 'anewz', name: 'AnewZ', country: 'az', group: 'Xəbər', url: 'https://53be5ef2d13aa.streamlock.net/cubesanewz-secure/smil:cubesanewz-secure-web.smil/playlist.m3u8' },
  { id: 'alvin', name: 'Alvin Channel TV', country: 'az', group: 'Eyləncə', url: 'https://cdn10-alvinchannel.yayin.com.tr/alvinchannel/alvinchannel/playlist.m3u8' },
  { id: 'ayaztv', name: 'Ayaz TV', country: 'az', group: 'Milli', url: 'https://janya-ayaztv.vgcdn.net/ptnr-WebApp/title-Ayaz_TV/v1/vglive-sk-934820/main.m3u8' },
  { id: 'eltv', name: 'EL TV', country: 'az', group: 'Regional', url: 'https://live.eltv.az/live/eltv/playlist.m3u8' },
  { id: 'knmusic', name: 'KN Music TV', country: 'az', group: 'Musiqi', url: 'https://cdn4.yayin.com.tr/kntv/tracks-v1a1/mono.m3u8' },
];

// State
let currentCountry = 'all';
let currentChannel = null;
let hls = null;
let filteredChannels = [...channels];

// DOM
const video = document.getElementById('videoPlayer');
const overlay = document.getElementById('playerOverlay');
const channelList = document.getElementById('channelList');
const searchInput = document.getElementById('searchInput');
const npName = document.getElementById('npName');
const tabs = document.querySelectorAll('.tab');

// Init
function init() {
  renderChannels();
  bindEvents();
}

function bindEvents() {
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      currentCountry = tab.dataset.country;
      filterAndRender();
    });
  });

  searchInput.addEventListener('input', () => {
    filterAndRender();
  });

  overlay.addEventListener('click', () => {
    if (currentChannel) {
      video.play().catch(() => {});
    }
  });
}

function filterAndRender() {
  const query = searchInput.value.trim().toLowerCase();
  filteredChannels = channels.filter(ch => {
    const matchCountry = currentCountry === 'all' || ch.country === currentCountry;
    const matchSearch = !query || ch.name.toLowerCase().includes(query) || ch.group.toLowerCase().includes(query);
    return matchCountry && matchSearch;
  });
  renderChannels();
}

function renderChannels() {
  if (filteredChannels.length === 0) {
    channelList.innerHTML = `<div class="empty-state">Kanal tapılmadı</div>`;
    return;
  }

  channelList.innerHTML = filteredChannels.map(ch => `
    <div class="channel-item ${currentChannel && currentChannel.id === ch.id ? 'active' : ''}" data-id="${ch.id}">
      <span class="channel-flag">${ch.country === 'tr' ? '🇹🇷' : '🇦🇿'}</span>
      <div class="channel-info">
        <div class="channel-name">${ch.name}</div>
        <div class="channel-group">${ch.group}</div>
      </div>
      <span class="channel-status" title="Açıq axın"></span>
    </div>
  `).join('');

  // Bind click
  channelList.querySelectorAll('.channel-item').forEach(item => {
    item.addEventListener('click', () => {
      const id = item.dataset.id;
      const ch = channels.find(c => c.id === id);
      if (ch) playChannel(ch);
    });
  });
}

function playChannel(ch) {
  currentChannel = ch;
  npName.textContent = ch.name;
  overlay.classList.add('hidden');

  // Highlight
  document.querySelectorAll('.channel-item').forEach(el => {
    el.classList.toggle('active', el.dataset.id === ch.id);
  });

  // Destroy previous HLS
  if (hls) {
    hls.destroy();
    hls = null;
  }

  // Native HLS (Safari) or HLS.js
  if (video.canPlayType('application/vnd.apple.mpegurl')) {
    video.src = ch.url;
    video.play().catch(err => {
      console.warn('Play error:', err);
      showError();
    });
  } else if (Hls.isSupported()) {
    hls = new Hls({
      enableWorker: true,
      lowLatencyMode: false,
      backBufferLength: 90,
      maxBufferLength: 30,
      maxMaxBufferLength: 60,
    });
    hls.loadSource(ch.url);
    hls.attachMedia(video);
    hls.on(Hls.Events.MANIFEST_PARSED, () => {
      video.play().catch(err => {
        console.warn('Play error:', err);
      });
    });
    hls.on(Hls.Events.ERROR, (event, data) => {
      if (data.fatal) {
        console.error('HLS fatal error:', data);
        switch (data.type) {
          case Hls.ErrorTypes.NETWORK_ERROR:
            hls.startLoad();
            break;
          case Hls.ErrorTypes.MEDIA_ERROR:
            hls.recoverMediaError();
            break;
          default:
            showError();
            break;
        }
      }
    });
  } else {
    showError('Brauzeriniz HLS dəstəkləmir');
  }
}

function showError(msg) {
  overlay.classList.remove('hidden');
  overlay.querySelector('.overlay-content').innerHTML = `
    <div class="play-icon">⚠️</div>
    <p>${msg || 'Yayım yüklənə bilmədi. Başqa kanal seçin.'}</p>
  `;
}

// Start
init();
