// ============================================================
// TV Kanalları — Türkiyə · Azərbaycan · Rusiya · İran
// Açıq/ictimai HLS axınları. Pullu kanallar (beIN və s.) rəsmi
// lisenziya tələb etdiyi üçün daxil edilməyib.
// ============================================================

// ★★★ REKLAM ÜÇÜN WHATSAPP NÖMRƏSİNİ BURADA DƏYİŞİN ★★★
const WHATSAPP_NUMBER = "994501234567"; // Məsələn: 994501234567 (ölkə kodu ilə, + olmadan)
const WHATSAPP_MSG = encodeURIComponent("Salam! TV Kanalları tətbiqində reklam yerləşdirmək istəyirəm.");

// Reklam məlumatı (öz reklamınızı bura yaza bilərsiniz)
const AD_CONFIG = {
  title: "Sizin reklamınız burada ola bilər!",
  desc: "WhatsApp ilə əlaqə saxlayın — video, şəkil və ya yazılı reklam",
  showEverySeconds: 300, // hər 5 dəqiqədə bir (kanal dəyişəndə də göstərilir)
  durationSeconds: 5
};

const channels = [
  // ==================== TÜRKİYƏ ====================
  // TRT (rəsmi)
  { id: "trt1", name: "TRT 1", country: "tr", group: "Ulusal", url: "https://tv-trt1.medya.trt.com.tr/master.m3u8" },
  { id: "trt2", name: "TRT 2", country: "tr", group: "Ulusal", url: "https://tv-trt2.medya.trt.com.tr/master.m3u8" },
  { id: "trthaber", name: "TRT Haber", country: "tr", group: "Haber", url: "https://tv-trthaber.medya.trt.com.tr/master.m3u8" },
  { id: "trtspor", name: "TRT Spor", country: "tr", group: "Spor", url: "https://tv-trtspor1.medya.trt.com.tr/master.m3u8" },
  { id: "trtspor2", name: "TRT Spor 2", country: "tr", group: "Spor", url: "https://tv-trtspor2.medya.trt.com.tr/master.m3u8" },
  { id: "trtcocuk", name: "TRT Çocuk", country: "tr", group: "Çocuk", url: "https://tv-trtcocuk.medya.trt.com.tr/master.m3u8" },
  { id: "trtmuzik", name: "TRT Müzik", country: "tr", group: "Müzik", url: "https://tv-trtmuzik.medya.trt.com.tr/master.m3u8" },
  { id: "trtbelgesel", name: "TRT Belgesel", country: "tr", group: "Belgesel", url: "https://tv-trtbelgesel-dai.medya.trt.com.tr/master.m3u8" },
  { id: "trtavaz", name: "TRT Avaz", country: "tr", group: "Ulusal", url: "https://tv-trtavaz.medya.trt.com.tr/master.m3u8" },
  { id: "trtkurdi", name: "TRT Kurdî", country: "tr", group: "Ulusal", url: "https://tv-trtkurdi.medya.trt.com.tr/master.m3u8" },
  { id: "trtarabi", name: "TRT Arabi", country: "tr", group: "Ulusal", url: "https://tv-trtarabi.medya.trt.com.tr/master.m3u8" },
  { id: "trtworld", name: "TRT World", country: "tr", group: "Haber", url: "https://tv-trtworld.medya.trt.com.tr/master.m3u8" },
  { id: "trtturk", name: "TRT Türk", country: "tr", group: "Ulusal", url: "https://tv-trtturk.medya.trt.com.tr/master.m3u8" },

  // Digər ulusal / açıq axınlar
  { id: "showtv", name: "Show TV", country: "tr", group: "Ulusal", url: "https://ciner-live.daioncdn.net/showtv/showtv.m3u8" },
  { id: "kanald", name: "Kanal D", country: "tr", group: "Ulusal", url: "https://demiroren.daioncdn.net/kanald/kanald.m3u8" },
  { id: "atv", name: "ATV", country: "tr", group: "Ulusal", url: "https://rnttwmjcin.turknet.ercdn.net/lcpmvefbyo/atv/atv_1080p.m3u8" },
  { id: "startv", name: "Star TV", country: "tr", group: "Ulusal", url: "https://raw.githubusercontent.com/ipstreet312/freeiptv/refs/heads/master/ressources/tur/star.m3u8" },
  { id: "tv8", name: "TV8", country: "tr", group: "Ulusal", url: "https://tv8-live.daioncdn.net/tv8/tv8_1080p.m3u8" },
  { id: "teve2", name: "teve2", country: "tr", group: "Eğlence", url: "https://demiroren-live.daioncdn.net/teve2/teve2.m3u8" },
  { id: "kanal7", name: "Kanal 7", country: "tr", group: "Ulusal", url: "https://kanal7-live.daioncdn.net/kanal7/kanal7_1080p.m3u8" },
  { id: "beyaztv", name: "Beyaz TV", country: "tr", group: "Ulusal", url: "https://beyaztv-live.daioncdn.net/beyaztv/beyaztv.m3u8" },
  { id: "halktv", name: "Halk TV", country: "tr", group: "Haber", url: "https://halktv-live.daioncdn.net/halktv/halktv.m3u8" },
  { id: "haberturk", name: "Habertürk", country: "tr", group: "Haber", url: "https://rmtftbjlne.turknet.ercdn.net/bpeytmnqyp/haberturktv/haberturktv_1080p.m3u8" },
  { id: "ntv", name: "NTV", country: "tr", group: "Haber", url: "https://dogus.daioncdn.net/ntv/ntv_720p.m3u8" },
  { id: "bloomberght", name: "Bloomberg HT", country: "tr", group: "Haber", url: "https://ciner-live.daioncdn.net/bloomberght/bloomberght.m3u8" },
  { id: "tv360", name: "360 TV", country: "tr", group: "Haber", url: "https://turkmedya-live.ercdn.net/tv360/tv360.m3u8" },
  { id: "tv100", name: "TV100", country: "tr", group: "Haber", url: "https://tv100-live.daioncdn.net/tv100/tv100_1080p.m3u8" },
  { id: "aspor", name: "A Spor", country: "tr", group: "Spor", url: "https://rnttwmjcin.turknet.ercdn.net/lcpmvefbyo/aSPOR/aSPOR_1080p.m3u8" },
  { id: "tgrthaber", name: "TGRT Haber", country: "tr", group: "Haber", url: "https://canli.tgrthaber.com/tgrt.m3u8" },
  { id: "ahaber", name: "A Haber", country: "tr", group: "Haber", url: "https://trkvz-live.daioncdn.net/ahaber/ahaber.m3u8" },
  { id: "tv4", name: "TV4", country: "tr", group: "Ulusal", url: "https://turkmedya-live.ercdn.net/tv4/tv4.m3u8" },
  { id: "4utv", name: "4U TV", country: "tr", group: "Eğlence", url: "https://hls.4utv.live/hls/stream.m3u8" },
  { id: "aksutv", name: "Aksu TV", country: "tr", group: "Yerel", url: "https://live.artidijitalmedya.com/artidijital_aksutv/aksutv/playlist.m3u8" },
  { id: "eurod", name: "Euro D", country: "tr", group: "Ulusal", url: "https://live.duhnet.tv/S2/HLS_LIVE/eurodnp/track_4_1000/playlist.m3u8" },

  // ==================== AZƏRBAYCAN ====================
  { id: "aztv", name: "Az TV", country: "az", group: "Milli", url: "https://str.yodacdn.net/azertv/index.m3u8" },
  { id: "ictimai", name: "İctimai TV", country: "az", group: "Milli", url: "https://live.itv.az/itv.m3u8" },
  { id: "azadtv", name: "Azad TV (ATV)", country: "az", group: "Milli", url: "https://lives.atv.az:5443/ATV_TV_STREAM/streams/atvcanli.m3u8" },
  { id: "bakutv", name: "Baku TV", country: "az", group: "Milli", url: "https://rtmp.baku.tv/hls/bakutv.m3u8" },
  { id: "azstartv", name: "Azstar TV", country: "az", group: "Milli", url: "https://live.livestreamtv.ca/azstar/amlst:azstar/playlist.m3u8" },
  { id: "apatv", name: "APA TV", country: "az", group: "Xəbər", url: "http://stream.apa.tv/apastream/index.m3u8" },
  { id: "medeniyyet", name: "Mədəniyyət TV", country: "az", group: "Mədəniyyət", url: "https://str.yodacdn.net/medeniyyettele/index.m3u8" },
  { id: "kanal35", name: "Kanal 35", country: "az", group: "Milli", url: "https://str2.yodacdn.net/kanal35/index.m3u8" },
  { id: "kanals", name: "Kanal S", country: "az", group: "Milli", url: "https://lives.atv.az:5443/KANAL-S/streams/kanals.m3u8" },
  { id: "naxcivantv", name: "Naxçıvan TV", country: "az", group: "Regional", url: "https://str2.yodacdn.net/ntv/video.m3u8" },
  { id: "xezertv", name: "Xəzər TV / Xəbər", country: "az", group: "Xəbər", url: "https://www.xezerxeber.az/stream/index.m3u8" },
  { id: "anewz", name: "AnewZ", country: "az", group: "Xəbər", url: "https://53be5ef2d13aa.streamlock.net/cubesanewz-secure/smil:cubesanewz-secure-web.smil/playlist.m3u8" },
  { id: "alvin", name: "Alvin Channel", country: "az", group: "Eyləncə", url: "https://cdn10-alvinchannel.yayin.com.tr/alvinchannel/alvinchannel/playlist.m3u8" },
  { id: "ayaztv", name: "Ayaz TV", country: "az", group: "Milli", url: "https://janya-ayaztv.vgcdn.net/ptnr-WebApp/title-Ayaz_TV/v1/vglive-sk-934820/main.m3u8" },
  { id: "eltv", name: "EL TV", country: "az", group: "Regional", url: "https://live.eltv.az/live/eltv/playlist.m3u8" },
  { id: "knmusic", name: "KN Music TV", country: "az", group: "Musiqi", url: "https://cdn4.yayin.com.tr/kntv/tracks-v1a1/mono.m3u8" },
  { id: "cbcsport", name: "CBC Sport", country: "az", group: "İdman", url: "https://mn-nl.mncdn.com/cbcsports_live/cbcsports/playlist.m3u8" },
  { id: "idmantv", name: "İdman TV", country: "az", group: "İdman", url: "https://live.itv.az/idman.m3u8" },

  // ==================== RUSİYA (açıq) ====================
  { id: "1tv", name: "Первый канал (1TV)", country: "ru", group: "Общие", url: "https://edge1.1internet.tv/dash/1tv/playlist.mpd" },
  { id: "rtr", name: "Россия 1", country: "ru", group: "Общие", url: "https://live-vgtrkwcdn.cdnvideo.ru/vgtrk/smil:r1hd.smil/playlist.m3u8" },
  { id: "r24", name: "Россия 24", country: "ru", group: "Новости", url: "https://live-vgtrkwcdn.cdnvideo.ru/vgtrk/smil:r24.smil/playlist.m3u8" },
  { id: "ntvru", name: "НТВ", country: "ru", group: "Общие", url: "https://live-ntv.cdnvideo.ru/ntv/smil:ntv.smil/playlist.m3u8" },
  { id: "tnt", name: "ТНТ", country: "ru", group: "Развлекательные", url: "https://live-tnt.cdnvideo.ru/tnt/smil:tnt.smil/playlist.m3u8" },
  { id: "sts", name: "СТС", country: "ru", group: "Развлекательные", url: "https://live-sts.cdnvideo.ru/sts/smil:sts.smil/playlist.m3u8" },
  { id: "rentv", name: "РЕН ТВ", country: "ru", group: "Общие", url: "https://live-rentv.cdnvideo.ru/rentv/smil:rentv.smil/playlist.m3u8" },
  { id: "matchtv", name: "Матч ТВ", country: "ru", group: "Спорт", url: "https://live-matchtv.cdnvideo.ru/matchtv/smil:matchtv.smil/playlist.m3u8" },
  { id: "karusel", name: "Карусель", country: "ru", group: "Детские", url: "https://live-karusel.cdnvideo.ru/karusel/smil:karusel.smil/playlist.m3u8" },
  { id: "zvezda", name: "Звезда", country: "ru", group: "Общие", url: "https://tvchannelstream1.tvzvezda.ru/cdn/tvzvezda/playlist.m3u8" },

  // ==================== İRAN ====================
  { id: "presstv", name: "Press TV", country: "ir", group: "News", url: "https://live.presstv.ir/hls/presstv_5_482/index.m3u8" },
  { id: "hispan", name: "Hispan TV", country: "ir", group: "News", url: "https://cdnlive.presstv.ir/live/smil:live.smil/playlist.m3u8" },
  { id: "alalam", name: "Al Alam", country: "ir", group: "News", url: "https://live2.alalam.ir/alalam.m3u8" },
  { id: "iranpress", name: "Iran Press", country: "ir", group: "News", url: "https://live.presstv.ir/hls/presstv_5_482/index.m3u8" },
  { id: "ifilm", name: "iFilm English", country: "ir", group: "Movies", url: "https://live.presstv.co.uk/hls/ifilmen.m3u8" },
  { id: "ifilm2", name: "iFilm 2", country: "ir", group: "Movies", url: "https://live.presstv.co.uk/hls/ifilm2.m3u8" },
  { id: "iribtv1", name: "IRIB TV1", country: "ir", group: "General", url: "https://ncdn.telewebion.ir/tv1/live/playlist.m3u8" },
  { id: "irinn", name: "IRINN", country: "ir", group: "News", url: "https://ncdn.telewebion.ir/irinn/live/playlist.m3u8" },
  // Sahar Azəri – bəzən offline ola bilər, amma əlavə olunub
  { id: "saharazeri", name: "Səhər Azəri (Sahar)", country: "ir", group: "Azərbaycan dili", url: "https://s1-cloud.irib.ir/securelive3/saharazarsd/saharazarsd.m3u8" },
];

// State
let currentCountry = "all";
let currentChannel = null;
let hls = null;
let filteredChannels = [...channels];
let lastAdTime = 0;
let adTimerInterval = null;

// DOM
const video = document.getElementById("videoPlayer");
const overlay = document.getElementById("playerOverlay");
const channelList = document.getElementById("channelList");
const searchInput = document.getElementById("searchInput");
const npName = document.getElementById("npName");
const npCountry = document.getElementById("npCountry");
const flagBtns = document.querySelectorAll(".flag-btn");
const adOverlay = document.getElementById("adOverlay");
const adTimerEl = document.getElementById("adTimer");
const adContactBtn = document.getElementById("adContactBtn");
const adModal = document.getElementById("adModal");
const modalClose = document.getElementById("modalClose");

const countryNames = { tr: "Türkiyə", az: "Azərbaycan", ru: "Rusiya", ir: "İran" };
const countryFlags = { tr: "🇹🇷", az: "🇦🇿", ru: "🇷🇺", ir: "🇮🇷" };

function getWaLink() {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MSG}`;
}

function init() {
  // WhatsApp linkləri
  document.getElementById("adWaLink").href = getWaLink();
  document.getElementById("waBigLink").href = getWaLink();

  renderChannels();
  bindEvents();
}

function bindEvents() {
  flagBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      flagBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      currentCountry = btn.dataset.country;
      searchInput.value = "";
      filterAndRender();
    });
  });

  searchInput.addEventListener("input", filterAndRender);

  overlay.addEventListener("click", () => {
    if (currentChannel) video.play().catch(() => {});
  });

  adContactBtn.addEventListener("click", () => adModal.classList.add("show"));
  modalClose.addEventListener("click", () => adModal.classList.remove("show"));
  adModal.addEventListener("click", e => {
    if (e.target === adModal) adModal.classList.remove("show");
  });
}

function filterAndRender() {
  const q = searchInput.value.trim().toLowerCase();
  filteredChannels = channels.filter(ch => {
    const matchCountry = currentCountry === "all" || ch.country === currentCountry;
    const matchSearch = !q || ch.name.toLowerCase().includes(q) || ch.group.toLowerCase().includes(q);
    return matchCountry && matchSearch;
  });
  renderChannels();
}

function renderChannels() {
  if (filteredChannels.length === 0) {
    channelList.innerHTML = `<div class="empty-state">Kanal tapılmadı</div>`;
    return;
  }
  channelList.innerHTML = filteredChannels.map(ch => `
    <div class="channel-item ${currentChannel && currentChannel.id === ch.id ? "active" : ""}" data-id="${ch.id}">
      <span class="channel-flag">${countryFlags[ch.country] || "📺"}</span>
      <div class="channel-info">
        <div class="channel-name">${ch.name}</div>
        <div class="channel-group">${ch.group}</div>
      </div>
      <span class="channel-status"></span>
    </div>
  `).join("");

  channelList.querySelectorAll(".channel-item").forEach(item => {
    item.addEventListener("click", () => {
      const ch = channels.find(c => c.id === item.dataset.id);
      if (ch) playChannel(ch);
    });
  });
}

function playChannel(ch) {
  // Reklam yoxlaması (kanal dəyişəndə və ya vaxt keçibsə)
  const now = Date.now();
  if (now - lastAdTime > AD_CONFIG.showEverySeconds * 1000) {
    showAd(() => actuallyPlay(ch));
    return;
  }
  actuallyPlay(ch);
}

function actuallyPlay(ch) {
  currentChannel = ch;
  npName.textContent = ch.name;
  npCountry.textContent = `${countryFlags[ch.country]} ${countryNames[ch.country] || ""}`;
  overlay.classList.add("hidden");

  document.querySelectorAll(".channel-item").forEach(el => {
    el.classList.toggle("active", el.dataset.id === ch.id);
  });

  if (hls) {
    hls.destroy();
    hls = null;
  }
  video.src = "";

  if (video.canPlayType("application/vnd.apple.mpegurl") && ch.url.includes(".m3u8")) {
    video.src = ch.url;
    video.play().catch(() => showError());
  } else if (Hls.isSupported() && (ch.url.includes(".m3u8") || ch.url.includes(".mpd"))) {
    hls = new Hls({
      enableWorker: true,
      lowLatencyMode: false,
      backBufferLength: 90,
      maxBufferLength: 30,
    });
    hls.loadSource(ch.url);
    hls.attachMedia(video);
    hls.on(Hls.Events.MANIFEST_PARSED, () => {
      video.play().catch(() => {});
    });
    hls.on(Hls.Events.ERROR, (e, data) => {
      if (data.fatal) {
        if (data.type === Hls.ErrorTypes.NETWORK_ERROR) hls.startLoad();
        else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) hls.recoverMediaError();
        else showError();
      }
    });
  } else {
    // Fallback: birbaşa src
    video.src = ch.url;
    video.play().catch(() => showError());
  }
}

function showAd(callback) {
  lastAdTime = Date.now();
  adOverlay.classList.add("show");
  let left = AD_CONFIG.durationSeconds;
  adTimerEl.textContent = left;

  if (adTimerInterval) clearInterval(adTimerInterval);
  adTimerInterval = setInterval(() => {
    left--;
    adTimerEl.textContent = left;
    if (left <= 0) {
      clearInterval(adTimerInterval);
      adOverlay.classList.remove("show");
      if (callback) callback();
    }
  }, 1000);
}

function showError(msg) {
  overlay.classList.remove("hidden");
  overlay.querySelector(".overlay-content").innerHTML = `
    <div class="play-icon">⚠️</div>
    <p>${msg || "Yayım yüklənə bilmədi. Başqa kanal seçin."}</p>
  `;
}

init();
