// Visual effect helpers extracted from script.js
import { rgbToHsl, hslToRgb, shiftHue } from './colorUtils.js';

/*
 * Perceptual Lab helpers for luminosity inversion:
 * - srgbToLinear: sRGB (0-255) -> linear RGB (0-1)
 * - linearToXyz / xyzToLinear: conversion helpers
 * - xyzToLab / labToXyz: Lab conversion helpers
 * - labToSrgb: convert Lab back to sRGB 0-255
 *
 * These functions are local, lightweight and avoid external deps.
 */

function srgbToLinearChannel(v) {
    v = v / 255;
    return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
}
function linearToSrgbChannel(v) {
    return v <= 0.0031308 ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - 0.055;
}
function rgbToXyz(r, g, b) {
    // r,g,b in 0-255
    const R = srgbToLinearChannel(r);
    const G = srgbToLinearChannel(g);
    const B = srgbToLinearChannel(b);
    // sRGB D65
    const X = R * 0.4124564 + G * 0.3575761 + B * 0.1804375;
    const Y = R * 0.2126729 + G * 0.7151522 + B * 0.0721750;
    const Z = R * 0.0193339 + G * 0.1191920 + B * 0.9503041;
    return [X, Y, Z];
}
function xyzToLab(X, Y, Z) {
    // D65 reference white
    const Xn = 0.95047, Yn = 1.00000, Zn = 1.08883;
    const eps = 216 / 24389; // 0.008856
    const k = 24389 / 27; // 903.3

    const fx = X / Xn;
    const fy = Y / Yn;
    const fz = Z / Zn;

    const f = v => v > eps ? Math.cbrt(v) : (k * v + 16) / 116;

    const fx2 = f(fx), fy2 = f(fy), fz2 = f(fz);

    const L = (116 * fy2) - 16;
    const a = 500 * (fx2 - fy2);
    const b = 200 * (fy2 - fz2);
    return [L, a, b];
}
function labToXyz(L, a, b) {
    const Xn = 0.95047, Yn = 1.00000, Zn = 1.08883;
    const eps = 216 / 24389;
    const k = 24389 / 27;

    const fy = (L + 16) / 116;
    const fx = fy + (a / 500);
    const fz = fy - (b / 200);

    const fInv = t => {
        const t3 = t * t * t;
        return t3 > eps ? t3 : (116 * t - 16) / k;
    };

    const X = Xn * fInv(fx);
    const Y = Yn * fInv(fy);
    const Z = Zn * fInv(fz);
    return [X, Y, Z];
}
function xyzToRgb(X, Y, Z) {
    // convert XYZ -> linear RGB
    let R = X *  3.2404542 + Y * -1.5371385 + Z * -0.4985314;
    let G = X * -0.9692660 + Y *  1.8760108 + Z *  0.0415560;
    let B = X *  0.0556434 + Y * -0.2040259 + Z *  1.0572252;
    // clamp then convert linear -> sRGB
    R = linearToSrgbChannel(Math.max(0, R));
    G = linearToSrgbChannel(Math.max(0, G));
    B = linearToSrgbChannel(Math.max(0, B));
    return [
        Math.round(Math.max(0, Math.min(1, R)) * 255),
        Math.round(Math.max(0, Math.min(1, G)) * 255),
        Math.round(Math.max(0, Math.min(1, B)) * 255)
    ];
}
function invertLabLightnessPreserveChroma(r, g, b) {
    // Convert to Lab, invert L* (perceptual lightness), convert back
    const [X, Y, Z] = rgbToXyz(r, g, b);
    const [L, a, bb] = xyzToLab(X, Y, Z);
    // avoid divide-by-zero: if L is near 0, treat as pure black -> map to white (100)
    const Li = isFinite(L) ? (100 - L) : 100;
    const [Xi, Yi, Zi] = labToXyz(Li, a, bb);
    return xyzToRgb(Xi, Yi, Zi);
}

/**
 * Helper to recursively multiply pitches to simulate "re-rendering".
 * Each "render" applies the base shifts to all current voices.
 */
function multiplyPitches(base, loopIndex, maxVoices = 2048) {
    // Prevent exponential blow-up of pitch voices by capping recursive multiplication.
    // Allow multiple compound passes driven by loopIndex, but clamp to a higher safe maximum
    // so compounding continues beyond 6–7 renders while still protecting CPU/memory.
    if (!Array.isArray(base) || base.length === 0) return [];
    if (loopIndex <= 0) return Array.from(new Set(base)).sort((a, b) => a - b);

    // Increase allowed compound loops but keep a hard upper bound to avoid runaway growth.
    // Most real-world uses won't need more than ~30 compound passes; clamp to that.
    const MAX_COMPOUND_LOOPS = 50;
    const effectiveLoops = Math.min(MAX_COMPOUND_LOOPS, Math.max(0, Math.floor(loopIndex)));

    // Defensive cap on voices to keep runtime stable; raise to 1024 but keep slicing if exceeded.
    let current = [...base];
    for (let i = 0; i < effectiveLoops; i++) {
        let next = [];
        for (let p of current) {
            for (let b of base) {
                next.push(p + b);
            }
        }
        // Deduplicate and sort for deterministic output
        current = [...new Set(next)].sort((a, b) => a - b);

        // If we exceed maxVoices, keep a representative subset:
        // - prefer low-to-high order (musically coherent)
        // - but if it's enormous, sample uniformly to avoid bias
        if (current.length > maxVoices) {
            // If only slightly over, just slice; if massively over, sample evenly
            if (current.length <= maxVoices * 4) {
                current = current.slice(0, maxVoices);
            } else {
                const sampled = [];
                const step = current.length / maxVoices;
                for (let s = 0; s < maxVoices; s++) {
                    sampled.push(current[Math.floor(s * step)]);
                }
                current = sampled;
            }
        }
    }
    return current;
}

export function getPitchShiftForEffect(effect, totalPower, loopIndex, customParams = {}) {
    if (effect === 'normal' || effect === 'reverse') return [];

    switch (effect) {
        case 'custom':
            const basePitch = customParams.pitch || 0;
            if (basePitch === 0) return [];
            // Create a compounding "choir" effect by stacking the custom pitch shift in each render pass
            return multiplyPitches([0, basePitch], loopIndex);

        case 'custom_major_333':
            // Custom Major 333: two voices 0 and -0.3, compound across re-renders
            return multiplyPitches([0, -0.3], loopIndex);

        case 'custom_major_3':
            // Custom Major 3: fixed preset per request (Hue +165, reflect left)
            // Pitches: 0 and +0.1 (compounded across re-renders)
            return multiplyPitches([0, 0.1], loopIndex);

        case 'simulator_v19':
            // Simulator V19: Invert + Hue +60 per render, both waves spatially; pitches -12, 0, +7 (compounding)
            return multiplyPitches([-12, 0, 7], loopIndex);

        case 'gmajor5':
            return multiplyPitches([4, 5, -4, -5], loopIndex);
        case 'wigglem major':
            return multiplyPitches([12, 0, -2], loopIndex);
        case 'navynusmajor':
            return multiplyPitches([4, -7], loopIndex);
        case 'dxi':
            return multiplyPitches([-7, 0, 7], loopIndex);

        case '22-dxi':
            // 22-DXI: follow user's request — musical pitches -19 and +19 (compounded across re-renders)
            return multiplyPitches([-19, 19], loopIndex);

        case '89-dxi':
            // 89-DXI: custom gradient mapping (green -> white -> black) with both-direction waves
            // and modest compound pitch voices -2.25 and +1.25
            return multiplyPitches([-2.25, 1.25], loopIndex);

        case '91-dxi':
            // 91-DXI: Invert + Hue 120 + saturation boost + vertical jitter
            // Pitch voices 0 and -3.5 compound across re-renders per request
            return multiplyPitches([0, -3.5], loopIndex);

        case 'fanny_major':
            // Fanny Major: gradient map (white -> black -> blue) and two pitch voices +1 and -6 (compounding across re-renders)
            return multiplyPitches([1, -6], loopIndex);

        case 'c_major':
            // C Major: Wave (Large preset) + Color Corrector (Secondary) + Invert + audio +2 semitones
            // Visuals: large wave preset, full inversion, hue rotate 100.408°, saturation boost 1.204, gain 1.25
            return multiplyPitches([2], loopIndex);

        case 'f_major':
            // F Major: TV simulator + horizontal wave, full invert, hue rotate ~146.939°, gain boost, single -2 semitone pitch (compounded)
            return multiplyPitches([-2], loopIndex);

        case 'usatve2004_g_major_12':
            // USATVE2004's G Major 12: Pitches: 0, -2.5 (compounding across re-renders)
            return multiplyPitches([0, -2.5], loopIndex);

        case 'usatve2004_g_major_32':
            // USATVE2004's G Major 32: Invert + RGB->BGR + Reflect Left visually; audio reverses on odd-numbered powers.
            // Musical voices: +4 and -5 (compounded across re-renders)
            return multiplyPitches([4, -5], loopIndex);

        case 'gmajor4':
            return multiplyPitches([0, 5], loopIndex);
        case 'gmajor74':
            return multiplyPitches([14, 9, -10], loopIndex);
        case 'braxtons_gmajor_74':
            return multiplyPitches([2, -3], loopIndex);
        case 'braxtons_gmajor_28':
            return multiplyPitches([7, 0, -7], loopIndex);
        case 'gmajor90v3':
            return multiplyPitches([1, -1], loopIndex);
        case 'luiggroup':
            return [-(loopIndex + 1)];
        case 'crying':
            return multiplyPitches([0, -5], loopIndex);
        case 'gmajor7':
        case 'normal_g_major_7':
            return multiplyPitches([0, 3], loopIndex);
        case 'haha_major':
            return multiplyPitches([1.5, -1.5], loopIndex);
        case 'haha_major_3_0':
            return multiplyPitches([3.5, -3.5], loopIndex);
        case 'h_major_9003':
            return multiplyPitches([3, -3], loopIndex);
        case 'j_major_9009':
            return multiplyPitches([1.5, -1.5], loopIndex);
        case 'pika_major':
            return multiplyPitches([7, 0, -7], loopIndex);
        case 'g_major_5xp':
            return multiplyPitches([-7, 0, 7], loopIndex);
        case 'g_major_3':
            // G-Major 3: red-tinted color treatment with faster waves; pitches 0 and -6 (compounding)
            return multiplyPitches([0, -6], loopIndex);
        case 'g_major_1':
            return multiplyPitches([8], loopIndex);

        case 'rga_major_1':
            // RGA Major 1: Hue -45 per render pass, horizontal flip, pitches -6 and +6 (compounding)
            return multiplyPitches([-6, 6], loopIndex);

        case 'doomsday':
            // Doomsday: audio choir with specified semitones (compounded across re-renders)
            // Pitches: -15, -13, -8, -6, -3, -1, +1, +3, +4, +6, +9, +11
            return multiplyPitches([-15, -13, -8, -6, -3, -1, 1, 3, 4, 6, 9, 11], loopIndex);

        case 'doomsday_alt':
            // Doomsday Alt: alternate pitch set for HSL+radial variant
            // Pitches: -15, -9, -8, -3, -2, +1, +3, +4, +7, +9, +10, +15
            return multiplyPitches([-15, -9, -8, -3, -2, 1, 3, 4, 7, 9, 10, 15], loopIndex);

        case 'baarenchrome_g_major_1':
            // BaarenChrome's G-Major 1: Invert, Hue 180 per render, mirror left, subtle swirl; pitches +4 and -3 (compounding)
            return multiplyPitches([4, -3], loopIndex);

        case 'mikesons_g_major_36':
            // Mikeson's G-Major 36: Hue +23 per render, mirror left, musical voices +7 and -5 (compounding)
            return multiplyPitches([7, -5], loopIndex);

        case 'g_major_137':
            return multiplyPitches([-10, 9, 14], loopIndex);
        case 'g_major_42':
            // BGR swap + luminosity invert + hue 180 per render, musical pitches -3, 0, +4, +7 (compounding)
            return multiplyPitches([-3, 0, 4, 7], loopIndex);

        case 'g_major_233':
            // G Major 233: hue +180 per render, GMajor4-like gradient mapping, pitches -11, +8, +13 (compounding)
            return multiplyPitches([-11, 8, 13], loopIndex);

        case 'g_major_25':
            // G Major 25: modest negative hue shift per render pass and pitch set [-1, -8] (compounding)
            return multiplyPitches([-1, -8], loopIndex);

        case 'g_minor_305':
            // Pitches multiply (compound) every power: base [-12, +7]
            return multiplyPitches([-12, 7], loopIndex);

        case 'g_major_54':
            // G Major 54: White -> Red -> Black gradient map with compound pitches 5.25, 10.25, 14.25
            return multiplyPitches([5.25, 10.25, 14.25], loopIndex);

        case 'a_major':
            // A Major: Invert, Hue 150, Reflect Right, Swirl 0.130, Pitches +5.73, +10.5
            return multiplyPitches([5.73, 10.5], loopIndex);

        case 'g_major_305':
            // G-Major 305: hue shifts negative per render and musical pitches 12 and -7 (compounding)
            return multiplyPitches([12, -7], loopIndex);
        case 'x_major_159':
            // X Major 159: gradient map (white -> pink -> black) with pitches -5 and +7
            return multiplyPitches([-5, 7], loopIndex);

        case 'js_x_major_159':
            // j's X Major 159: same pitches, different gradient map (orange)
            return multiplyPitches([-5, 7], loopIndex);

        case 'js_a_minor_10':
            // j's a Minor 10: single -3 semitone choir that compounds across re-renders
            return multiplyPitches([-3], loopIndex);

        case 'neptunegt8_g_major_121':
            // @NeptuneGT8's G-Major 121: Hue -180 per render pass, horizontal flip, pitches -12, 0, +7 (compounding)
            return multiplyPitches([-12, 0, 7], loopIndex);

        case 'g_major_901':
            // G Major 901: musical mapping to compound pitches -19, -6, -1, +13
            return multiplyPitches([-19, -6, -1, 13], loopIndex);

        case 'thousand_terrifying':
            // 1,000 Times Terrifying Instructions: deliver the requested pitch set (compounded across re-renders)
            // Pitches: 2, 0, -2, -4, -6
            return multiplyPitches([2, 0, -2, -4, -6], loopIndex);

        case 'notHandlebacks_g_major_5':
            // @notHandlebacks's G Major 5: Normal Split Hue 180 with split horizontal waves, pitches 0 and -2.5 (compounded across re-renders)
            return multiplyPitches([0, -2.5], loopIndex);

        case 'oskars_g_major_5':
            // Oskar's G Major 5: gradient map black -> cyan -> black with moderate light rays and compounding pitches +7, -5, +2
            return multiplyPitches([7, -5, 2], loopIndex);

        default:
            return [];
    }
}

// Pre-allocated buffers to avoid garbage collection lag
let noiseBuffer = null;
let cachedOutputBuffer = null;
let cachedImageData = null;

// Function to apply complex visual effects (pixel changes and spatial distortion)
// Optimized to reduce lag by reusing memory and minimizing object allocation.
export function applyComplexEffect(originalImageData, effectType, currentPower, loopIndex, frameTime, videoDurationSec, customParams = {}) {
    if (!originalImageData || effectType === 'normal') return originalImageData;

    // Performance guard: if source frame is very large, skip expensive per-pixel processing
    // to avoid severe lag/out-of-memory on low-end devices. This prevents the heavy pixel loops
    // from running for massive frames; you can downscale input in the UI before export if needed.
    try {
        const w = originalImageData.width || 0;
        const h = originalImageData.height || 0;
        const area = w * h;
        // Reduce SAFE_AREA threshold to prefer downscaled/offscreen processing for most sources
        const SAFE_AREA = 640 * 360; // lowered from ~HD to moderate size to avoid heavy pixel loops
        if (area > SAFE_AREA) {
            // return original image data unprocessed to keep export stable.
            return originalImageData;
        }
    } catch (e) {
        // if any check fails, proceed conservatively (don't crash)
    }

    // Performance guard: avoid expensive per-pixel processing for extremely deep re-renders.
    // Deep compound loops produce huge work for little perceptual benefit; skip processing and
    // return the original frame when loopIndex grows beyond a safe threshold.
    if (typeof loopIndex === 'number' && loopIndex > 8) {
        // returning originalImageData reduces CPU and memory pressure during export
        return originalImageData;
    }

    const width = originalImageData.width;
    const height = originalImageData.height;
    
    if (!cachedOutputBuffer || cachedOutputBuffer.length !== width * height * 4) {
        cachedOutputBuffer = new Uint8ClampedArray(width * height * 4);
        cachedImageData = new ImageData(cachedOutputBuffer, width, height);
    }
    
    const originalPixels = originalImageData.data;
    const newPixels = cachedOutputBuffer;
    
    // Optimization: Use 32-bit views for faster pixel movement where possible
    const original32 = new Uint32Array(originalPixels.buffer);
    const new32 = new Uint32Array(newPixels.buffer);

    const centerX = width >> 1;
    const centerY = height >> 1;

    let applyFisheye = false, k1 = 0, applyGMajor54 = false;
    let applyWave = false, waveAmplitude = 0, waveCount = 0, waveDirection = 'horizontal';
    let applySwirl = false, swirlStrength = 0.29, swirlCount = 0;
    let applyShake = false, shakeAmplitude = 0, shakeFrequency = 0;
    let applyInfiniteScroll = false, scrollDirection = 'horizontal', scrollPixelsPerSecondX = 0, scrollPixelsPerSecondY = 0;
    let applySkew = false, skewMode = 'eraser', skewMaxPixels = 20, skewStripeHeight = Math.max(8, Math.floor(height / 30));
    let applyInvert = false, applyHueShift = false, hueShiftDegrees = 0, applyGMajor4 = false, applyGreenTint = false;
    let applyNavynus = false, applyBraxtonsFisheye = false;
    let applyVhs = false, applyMirrorLR = false, applyFlip = false, applySwapRGB = false;
    // New: reflect-left mode mirrors the right side onto the left half
    // (updated: softened mirror anchored at center and optional saturation boost for psychedelic look)
    let applyReflectLeft = false, applyReflectRight = false;
    // New flag: force red-channel-only output (zero green/blue)
    let applyRedOnly = false;
    // Force/always-flip flag for presets that should unconditionally flip horizontally
    let applyFlipAlways = false;
    let applyXGradientMap = false, applyJXGradientMap = false;
    // Ensure saturation-related flags exist to avoid runtime ReferenceError (used in some case branches)
    let applySaturationBoost = false, saturationBoostValue = 0;
    // Optional waveform shaping flag (use 10th-power shaping to create pronounced peaked waves)

    // New: per-effect overall gain multiplier (used by F Major)
    let applyGain = 1.0;

    // New flags for Custom Major 333
    let applyRotate = false, rotateDegrees = 0;
    let applySharpen = false, sharpenStrength = 0;

    const speedFactor = 1.0; 

    switch (effectType) {
        case 'normal':
            break;

        case 'gmajor4':
            applyGMajor4 = true;
            break;

        case 'gmajor7':
        case 'normal_g_major_7':
            applyInvert = ((loopIndex + 1) % 2 === 1);
            break;

        case 'luiggroup':
            applyHueShift = true;
            hueShiftDegrees = -15 * (loopIndex + 1);
            break;

        case 'gmajor74':
            applyInvert = ((loopIndex + 1) % 2 === 1);
            applyHueShift = true;
            hueShiftDegrees = 180 * (loopIndex + 1);
            // fisheye disabled
            applyFisheye = false;
            k1 = 0;
            break;

        case 'braxtons_gmajor_74':
            // Recursive Re-render implementation for Braxtons G Major 74
            // Inversion alternates every pass
            applyInvert = ((loopIndex + 1) % 2 === 1);
            // Hue shift accumulates 180 degrees every pass
            applyHueShift = true;
            hueShiftDegrees = 180 * (loopIndex + 1);
            // fisheye disabled
            applyFisheye = false;
            k1 = 0;

            // Enhanced motion: add both-axis waves with a pronounced, peaked waveform using 10th-power shaping
            applyWave = true;
            waveDirection = 'both';
            // Increase cycles for a richer pattern; scale amplitude with image size for stability
            waveCount = 6;
            waveAmplitude = Math.max(3, Math.round(Math.min(width, height) * 0.03));

            // Use the 10th-power shaping for sharply peaked waves (same technique used by simulator_v19)
            var applyWavePower10 = true;

            // Slight shake to complement the wave motion on deeper re-renders
            if (loopIndex > 0) {
                applyShake = true;
                shakeAmplitude = 4 * Math.min(4, loopIndex); // modest increasing shake
                shakeFrequency = 6;
            }
            break;

        case 'braxtons_gmajor_28':
            // Cumulative re-render for Braxtons G Major 28
            applyHueShift = true; 
            hueShiftDegrees = 25 * (loopIndex + 1);
            applyFlip = (loopIndex % 2 === 0);
            applySwirl = true; 
            swirlStrength = -0.5 * (loopIndex + 1); 
            swirlCount = 0;
            break;

        case 'crying':
            applyInvert = ((loopIndex + 1) % 2 === 1);
            applyHueShift = true;
            hueShiftDegrees = -155 * (loopIndex + 1);
            applyWave = true;
            waveDirection = 'vertical';
            waveCount = 5;
            waveAmplitude = 5 * (loopIndex + 1);
            break;

        case 'gmajor5':
            // Cumulative re-render for G Major 5 (fisheye disabled)
            applyFisheye = false;
            k1 = 0;
            applyGreenTint = true;
            applyInvert = ((loopIndex + 1) % 2 === 1);
            break;

        case 'wigglem major':
            // Cumulative re-render for Wiggle Major
            applyHueShift = true;
            hueShiftDegrees = -15 * (loopIndex + 1);
            applyWave = true;
            waveDirection = 'both';
            waveCount = 1 + loopIndex;
            waveAmplitude = 15 + (5 * loopIndex);
            break;

        case 'navynusmajor':
            // Cumulative re-render for Navynus Major
            applyNavynus = true;
            applyHueShift = true;
            hueShiftDegrees = 10 * loopIndex;
            if (loopIndex > 0) applyShake = true, shakeAmplitude = 5 * loopIndex, shakeFrequency = 5;
            break;

        case 'dxi':
            if (loopIndex % 2 === 0) applyInvert = true;
            applyHueShift = true;
            hueShiftDegrees = 15;
            applySwirl = true;
            swirlStrength = -0.1;
            applyShake = true;
            shakeAmplitude = 10;
            shakeFrequency = 7;
            // saturation adjustments disabled per user preference
            break;

        case '89-dxi':
            // 89-DXI visual rules (renewed):
            // - Luminance gradient: 0 -> Green, 1 -> White, 2 -> Black
            // - Emphasize strong vertical waves (primary) with tuned amplitude/phase/animation
            applyHueShift = false;
            applyInvert = false;
            applyFisheye = false;
            k1 = 0;

            // Use vertical-dominant wave handling with a clear vertical signature
            applyWave = true;
            waveDirection = 'vertical';

            // Vertical wave: stronger, higher-count for pronounced vertical undulation
            const V_WAVE_COUNT = 6.0;
            const V_WAVE_AMPLITUDE_RATIO = 0.18; // larger fraction of min(width,height)
            const V_WAVE_PHASE = 0.8;

            // Keep a subtle horizontal component for depth but much weaker
            const H_WAVE_COUNT = 1.2;
            const H_WAVE_AMPLITUDE_RATIO = 0.006; // very small horizontal displacement
            const H_WAVE_PHASE = 0.0;
            const H_WAVE_ANIM_MULT = 800.0; // animate horizontal phase more rapidly for subtle motion

            // Map per-axis params into the existing wave variables for the inner loop
            waveCount = V_WAVE_COUNT;
            // compute a sensible aggregate amplitude (fallback) but inner loop will use v/h amp separately
            waveAmplitude = Math.max(1, Math.round(Math.min(width, height) * ((V_WAVE_AMPLITUDE_RATIO + H_WAVE_AMPLITUDE_RATIO) * 0.5)));
            var __89_v_wave_count = V_WAVE_COUNT;
            var __89_v_wave_amp_ratio = V_WAVE_AMPLITUDE_RATIO;
            var __89_v_wave_phase = V_WAVE_PHASE;
            var __89_h_wave_count = H_WAVE_COUNT;
            var __89_h_wave_amp_ratio = H_WAVE_AMPLITUDE_RATIO;
            var __89_h_wave_phase = H_WAVE_PHASE;
            var __89_h_wave_anim_mult = H_WAVE_ANIM_MULT;

            // Custom flag for later gradient mapping
            var apply89Gradient = true;
            break;

        case '1-dxi':
            // 1-DXI (reworked): apply vertical-only wave + per-line jitter only.
            // Intentionally avoid hue, swirl or fisheye so this preset is "wave + jitter only".
            applyHueShift = false;
            applyFisheye = false;
            k1 = 0;
            applySwirl = false;

            // Per-line "jitter" / vertical shake to emulate NewBlue jitter
            applyShake = true;
            // Base jitter amplitude; slightly increases with loopIndex for progressive passes
            shakeAmplitude = Math.max(1, Math.round(13.1125 * (1 + Math.min(8, loopIndex) * 0.02)));
            shakeFrequency = 6; // stable frequency for consistent jitter feel

            // Strict vertical wave for scanline motion
            applyWave = true;
            waveDirection = 'vertical';
            waveCount = 1.0;
            waveAmplitude = Math.max(1, Math.round(Math.min(width, height) * 0.01 * 4));

            // Special handling for the 50th power (loopIndex >= 49): emphasize final-pass effect
            if (typeof loopIndex === 'number' && loopIndex >= 49) {
                // increase jitter and wave for a pronounced final pass
                shakeAmplitude = Math.round(shakeAmplitude * 2.0);
                waveAmplitude = Math.max(1, Math.round(waveAmplitude * 1.5));
                // ensure the visual pops slightly more on final pass
                applySaturationBoost = true;
                saturationBoostValue = 1.12;
            }
            break;

        case '91-dxi':
            // 91-DXI: Invert + Hue 120 + Saturation boost + Vertical jitter (per user)
            applyInvert = true;
            applyHueShift = true;
            // Use fixed 120° hue per render pass (accumulates across re-renders similarly to other presets)
            hueShiftDegrees = 120 * (loopIndex + 1);
            // Saturation boost: +30% (1.3 saturation multiplier)
            applySaturationBoost = true;
            saturationBoostValue = 1.30;

            // Vertical jitter / Y-shake: moderate amplitude tuned to image size
            applyShake = true;
            // amplitude scales a bit with loopIndex to add subtle motion on deeper re-renders
            shakeAmplitude = Math.max(2, Math.min(24, Math.round(Math.min(width, height) * 0.01 * (1 + 0.06 * loopIndex))));
            shakeFrequency = 6 + Math.min(6, Math.floor(loopIndex)); // Hz-like factor for animation

            // Keep other heavy distortions off for this DXI variant
            applyFisheye = false;
            k1 = 0;
            applyWave = false;
            applySwirl = false;

            // Allow a small saturation pop on very deep 50th-power final pass
            if (typeof loopIndex === 'number' && loopIndex >= 49) {
                saturationBoostValue = 1.45;
                // Slight shake increase on final pass
                shakeAmplitude = Math.max(shakeAmplitude, 8);
                shakeFrequency = Math.max(shakeFrequency, 8);
            }
            break;

        case '22-dxi':
            // 22-DXI: Contrast 0.800, RGB->BGR swap, vertical Y-shake, Dark Red -> Transparent gradient map
            applySwapRGB = true;
            applyHueShift = false;
            applyFisheye = false;
            k1 = 0;

            // Y-shake (vertical jitter) + modest overall shake
            applyShake = true;
            shakeAmplitude = 6;        // pixels
            shakeFrequency = 10;       // Hz-like factor for animation

            // No wave displacement by default for this effect; primary motion comes from Y-shake
            applyWave = false;

            // Mark gradient and contrast for later color mapping
            var apply22Gradient = true;
            var contrastFactor22 = 0.8;

            break;

        case 'gmajor90v3':
            applyHueShift = true;
            hueShiftDegrees = -15;
            break;

        case 'pika_major':
            // Cumulative re-render for Pika Major
            applyHueShift = true; 
            hueShiftDegrees = 25 * (loopIndex + 1);
            applySaturationBoost = true; 
            saturationBoostValue = 1;
            // Flip on every render pass (alternates per loop)
            applyFlip = ((loopIndex + 1) % 2 !== 0);
            break;

        case 'haha_major':
            // Cumulative re-render for Haha Major (Speed increases)
            applyInfiniteScroll = true;
            scrollDirection = 'horizontal';
            scrollPixelsPerSecondX = width * speedFactor * (1 + (loopIndex * 0.5));
            if (loopIndex > 0) {
                applyHueShift = true;
                hueShiftDegrees = 45 * loopIndex;
            }
            break;

        case 'haha_major_3_0':
            // Cumulative re-render for Haha Major 3.0 (Speed increases)
            applyInfiniteScroll = true;
            scrollDirection = 'vertical';
            scrollPixelsPerSecondY = height * speedFactor * (1 + (loopIndex * 0.5));
            if (loopIndex > 0) {
                applyInvert = (loopIndex % 2 !== 0);
            }
            break;

        case 'h_major_9003':
            applyInvert = ((loopIndex + 1) % 2 === 1);
            applyHueShift = true;
            hueShiftDegrees = -179 * (loopIndex + 1);
            break;

        case 'j_major_9009':
            applyInvert = true;
            applyWave = true;
            waveDirection = 'vertical';
            waveCount = 5;
            waveAmplitude = 6;
            applySkew = true;
            skewMode = 'eraser';
            skewMaxPixels = Math.max(10, Math.round(width * 0.03));
            skewStripeHeight = Math.max(8, Math.floor(height / 28));
            break;

        case 'g_major_5xp':
            applyInvert = true;
            applyHueShift = true;
            hueShiftDegrees = -179;
            applyVhs = true;
            applyMirrorLR = true;
            break;

        case 'g_major_3':
            // G-Major 3 visual rules:
            // - Apply a strong red tint
            // - Enable both-direction waves with a perceptually faster "speed" feel (mapped to amplitude and count)
            applyHueShift = false;
            applyInvert = false;
            applyFisheye = false;
            k1 = 0;
            applyWave = true;
            waveDirection = 'both';
            // Interpret "Wave: Speed 5" as a more aggressive, faster-looking wave:
            // increase cycle count and modest amplitude so motion appears quicker without huge displacements.
            waveCount = 5;
            waveAmplitude = Math.max(2, Math.round(Math.min(2000, 0.03 * (width + height) ))); // modest amplitude scaled to size
            // Mark red tint to be applied later in color ops
            var applyRedTint = true;
            break;

        case 'g_major_1':
            applyInvert = ((loopIndex + 1) % 2 === 1);
            applyHueShift = true;
            hueShiftDegrees = 180 * (loopIndex + 1);
            break;

        case 'rga_major_1':
            // RGA Major 1 visuals: apply a -45° hue shift per render pass and enforce a horizontal flip
            applyHueShift = true;
            hueShiftDegrees = -45 * (loopIndex + 1);
            // Enforce a stable horizontal flip for this preset across all passes
            applyFlip = true; // legacy flip flag
            applyFlipAlways = true; // explicit always-flip guard honored in the main pixel loop
            // keep other heavy spatial distortions off for clarity
            applyFisheye = false;
            k1 = 0;
            break;

        case 'doomsday':
            // Doomsday visual rules (TV Simulator heavy):
            // - Channel blend: RGB -> BGR (applySwapRGB)
            // - Full invert
            // - Mirror: reflect right
            // - TV simulator characteristics mapped to VHS/noise + strong detail zoom and line-sync-like shake
            applySwapRGB = true;
            applyInvert = true;
            applyReflectRight = true;
            applyVhs = true;
            // Map requested detail zoom -> stronger subtle swirl plus per-line "jitter" via shake and wave
            // Use swirl as a proxy for radial/detail distortion and increase shake for line sync feel.
            applySwirl = true;
            swirlStrength = 0.35 * (loopIndex + 1);
            applyWave = true;
            waveDirection = 'horizontal';
            waveCount = 8;
            waveAmplitude = Math.max(2, Math.round(Math.min(8, 4 * (loopIndex + 1))));
            // Line sync mapping -> set moderate periodic shake frequency/amplitude (interpreted)
            applyShake = true;
            shakeAmplitude = Math.max(2, Math.round(4 * 0.75 * (1 + loopIndex * 0.05))); // scaled by requested 0.75
            shakeFrequency = 6;
            // Slight VHS flicker + saturation nudging off by default
            applySaturationBoost = false;
            // No fisheye by default for this preset
            applyFisheye = false;
            k1 = 0;
            break;

        case 'doomsday_alt':
            // Doomsday Alt visual rules (HSL-adjust + TV sim + radial blur hint):
            // - Apply small hue shift and strong saturation multiplier via HSL path
            applyHueShift = true;
            // the user requested HSL add of ~0.027 (in normalized rotations that's ~0.027*360 deg = ~9.72°),
            // but our hueShiftDegrees works in degrees, so map small normalized value to degrees approx 10deg per pass
            hueShiftDegrees = 9.72 * (loopIndex + 1);
            applySaturationBoost = true;
            saturationBoostValue = 2.0;
            applySwapRGB = true;
            applyInvert = true;
            applyReflectRight = true;
            // TV simulator line sync mapping (0.692) -> slightly lower shake amplitude/frequency
            applyVhs = true;
            applyShake = true;
            shakeAmplitude = Math.max(1, Math.round(3 * 0.692 * (1 + loopIndex * 0.03)));
            shakeFrequency = 5;
            // Simulate moderate proportional radial blur by using swirl + reduced detail 'light rays' to provide radial softening feel
            applySwirl = true;
            swirlStrength = 0.22;
            applyWave = false;
            // Fallback: no fisheye; keep k1 = 0 for stability
            applyFisheye = false;
            k1 = 0;
            break;

        case 'thousand_terrifying':
            // 1,000 Times Terrifying: compacted ruleset
            // - Always invert colors (perceptual alternating invert behavior handled elsewhere if needed)
            // - Force red-channel-only output for a stark red-only look
            // - Apply TV/VHS simulator artifacts (vhs, shake) to emulate old-TV character
            // - Add a radial/blurry finish via a moderate swirl to approximate radial blur without heavy convolution
            applyInvert = true;
            applyRedOnly = true;
            applyVhs = true;
            // stronger line-sync style shake to match the requested line sync ~0.7440 feel
            applyShake = true;
            shakeAmplitude = Math.max(2, Math.round(4 * 0.7440 * (1 + loopIndex * 0.02)));
            shakeFrequency = 6;
            // radial-like soft blur: use swirl as a lightweight proxy for radial blur, moderate strength
            applySwirl = true;
            swirlStrength = 0.30 * (1 + Math.min(1, loopIndex * 0.02)); // slightly increase on deeper re-renders
            // introduce a subtle horizontal wave for jittered scanline effect
            applyWave = true;
            waveDirection = 'horizontal';
            waveCount = 6;
            waveAmplitude = Math.max(1, Math.round(Math.min(6, 1 + loopIndex * 0.2)));
            // Avoid heavy fisheye or extreme color swaps; keep safe defaults
            applyFisheye = false;
            k1 = 0;
            break;

        case 'g_major_137':
            // Recursive Re-render implementation for G Major 137
            // Every 'power' pass (loopIndex) reapplies the visual logic.
            
            // Inversion alternates every render pass
            applyInvert = ((loopIndex + 1) % 2 === 1);
            
            // Hue shifts 180 degrees every render pass
            applyHueShift = true;
            hueShiftDegrees = 180 * (loopIndex + 1);
            
            // RGB -> BGR swap alternates every render pass
            applySwapRGB = ((loopIndex + 1) % 2 !== 0);
            
            // fisheye disabled for this effect
            applyFisheye = false;
            k1 = 0;
            break;

        case 'g_major_42':
            // G Major 42: always perform RGB->BGR swap, apply Lab-based luminosity inversion,
            // and apply a 180° hue shift (accumulated per render pass to preserve re-render behavior).
            applySwapRGB = true; // consistently swap R and B channels
            applyHueShift = true;
            // Keep cumulative 180° per pass (so multiple re-renders still accumulate)
            hueShiftDegrees = 180 * (loopIndex + 1);
            // Ensure the Lab-based luminosity inversion runs each pass
            var applyLumInvert = true;
            // Keep fisheye disabled for this effect
            applyFisheye = false;
            k1 = 0;
            break;

        case 'g_major_233':
            // G Major 233: combine a strong 180° hue shift per render pass with GMajor4-like bright->black mapping
            applyHueShift = true;
            // apply a single +180° per pass to produce the requested color flip
            hueShiftDegrees = 180 * (loopIndex + 1);
            // After hue shift, map bright areas to black similar to GMajor4
            applyGMajor4 = true;
            // No spatial distortion for this effect
            applyFisheye = false;
            k1 = 0;
            break;

        case 'g_major_25':
            // G Major 25: modest negative hue shift per render pass to tilt colors, no spatial distortion
            applyHueShift = true;
            // apply -50° per pass (accumulates across re-renders)
            hueShiftDegrees = -50 * (loopIndex + 1);
            applyFisheye = false;
            k1 = 0;
            break;

        case 'g_minor_305':
            // Visual rules for G Minor 305: cumulative hue growth (fisheye disabled) and modest saturation
            applyHueShift = true;
            hueShiftDegrees = 120 * (loopIndex + 1); // increase hue by 120° every power
            applyFisheye = false;
            k1 = 0;
            // saturation adjustments disabled per user preference
            break;

        case 'g_major_54':
            // G Major 54: gradient map White -> Red -> Black (luminance-driven), no spatial distortion
            applyGMajor54 = true;
            applyFisheye = false;
            k1 = 0;
            break;

        case 'g_major_305':
            // G-Major 305 visual rules: cumulative negative hue shift to tilt colors towards cooler tones
            applyHueShift = true;
            hueShiftDegrees = -120 * (loopIndex + 1); // decrease hue by 120° every power (accumulates)
            applyFisheye = false;
            k1 = 0;
            // Keep other defaults (no additional spatial distortion)
            break;

            case 'x_major_159':
            // X Major 159: apply a fixed gradient map (white -> pink -> black)
            // Gradient mapping happens after all other color ops using luminance.
            applyXGradientMap = true;
            // No fisheye or extra spatial distortion
            applyFisheye = false;
            k1 = 0;
            break;

        case 'notHandlebacks_g_major_5':
            // @notHandlebacks's G Major 5:
            // - "Normal Split Hue 180": implemented as a strong 180° hue shift per render pass
            // - "Normal Split Horizontal Waves": apply horizontal waves for split-motion across X axis
            applyHueShift = true;
            hueShiftDegrees = 180 * (loopIndex + 1); // strong 180° shift (accumulates per re-render pass)
            applyWave = true;
            waveDirection = 'horizontal';
            // Modest wave count/amplitude scaled to image size for visible but stable displacement
            waveCount = 3;
            waveAmplitude = Math.max(2, Math.round(Math.min(width, height) * 0.02));
            // No fisheye / swirl / heavy shake for this preset
            applyFisheye = false;
            k1 = 0;
            break;

        case 'oskars_g_major_5':
            // Oskar's G Major 5 visual rules:
            // - Gradient map: 0 -> Black, 1 -> Cyan, 2 -> Black (applied after primary color ops)
            // - Moderate radial "light rays" effect (subtle pulsing streaks from center)
            // - No fisheye distortion for clarity
            applyFisheye = false;
            k1 = 0;
            var applyOskarsGradient = true;
            var applyLightRays = true;
            var oskars_rays_strength = 0.25; // moderate brightness multiplier for rays
            var oskars_rays_count = 20; // number of streaks
            break;

        case 'g_major_901':
            // G Major 901: custom three-stop gradient map (spot0 black, spot1 teal-ish, spot2 blue)
            // We'll map using luminance to blend between spot0 -> spot1 -> spot2
            applyFisheye = false;
            k1 = 0;
            var applyGMajor901 = true;
            // Define the gradient stops as [r,g,b] (spot0, spot1, spot2)
            var g901_spot0 = [0, 0, 0];
            var g901_spot1 = [0, 200, 255];
            var g901_spot2 = [0, 0, 255];
            break;



        case 'js_x_major_159':
            // j's X Major 159: white -> orange -> black, with flip and a pronounced swirl
            applyJXGradientMap = true;
            applyFisheye = false;
            k1 = 0;
            // add horizontal flip and a swirl to create the requested distorted look
            applyFlip = true;
            applySwirl = true;
            // use a stronger swirl strength (positive for clockwise-ish warping) and enable one swirl octave
            swirlStrength = 3;
            swirlCount = 1;
            break;

        case 'js_a_minor_10':
            // j's a Minor 10: apply a strong fisheye variant and large hue shift, with compounding -3 semitone pitch voices
            applyFisheye = true;
            // Interpret user-requested "fisheye -15 / 15" as alternating strong barrel/pincushion passes:
            // negative strength for first-order distortion magnitude (scaled to safe small k1 range)
            // we'll use a fairly strong but stable value; alternating sign could be achieved across re-renders
            k1 = -0.15 * (loopIndex % 2 === 0 ? 1 : -1); // alternate sign each pass for the pair -15/15 feel
            applyHueShift = true;
            hueShiftDegrees = 180 * (loopIndex + 1); // cumulative 180° per pass to preserve re-render behavior
            // Keep fisheye size moderate so distortion is visible but not extreme
            applyBraxtonsFisheye = false;
            applyFlip = false;
            // No extra swirl; rely on fisheye + hue for character
            break;

        case 'fanny_major':
            // Fanny Major visual rules:
            // - Apply a luminance-based gradient map with stops: 0 -> White, 1 -> Black, 2 -> Blue
            // - No spatial distortion by default; color mapping applied after hue/invert ops.
            var applyFannyGradient = true;
            applyFisheye = false;
            k1 = 0;
            break;

        case 'simulator_v19':
            // Simulator V19 visual rules: invert colors, apply -60° hue shift per render pass, and add both-direction waves
            applyInvert = true;
            applyHueShift = true;
            hueShiftDegrees = -60 * (loopIndex + 1); // accumulate per re-render pass (negative)
            applyWave = true;
            waveDirection = 'both';
            // Use higher-frequency "10th-power" waves: more peaked waveform via sign-preserving exponentiation
            waveCount = 10; // number of wave cycles for both axes
            // base amplitude; scales slightly with loopIndex for re-render character
            waveAmplitude = 8 * (1 + loopIndex * 0.2);
            // When true, the wave displacement uses sign(sin(x)) * |sin(x)|^10 for a sharply peaked wave
            var applyWavePower10 = true;
            break;

        case 'a_major':
            // A Major: Invert colors, Hue +150°, reflect to the right, subtle swirl (0.130)
            applyInvert = true;
            applyHueShift = true;
            hueShiftDegrees = 150 * (loopIndex + 1); // accumulate per render pass to preserve re-render behavior
            applyReflectRight = true;
            applySwirl = true;
            swirlStrength = 0.130;
            swirlCount = 0;
            break;

        case 'c_major':
            // C Major: Wave (Large preset) + Color Corrector (Secondary) + Invert + gain + saturation
            // Wave: interpret "Large" preset as many cycles with noticeable amplitude for a bold look
            applyWave = true;
            waveDirection = 'both';
            waveCount = 10; // large preset -> many cycles
            waveAmplitude = Math.max(6, Math.round(Math.min(width, height) * 0.04)); // strong amplitude scaled to size

            // Color Corrector (Secondary) mapping: rotate hue, boost saturation, and apply gain
            applyHueShift = true;
            // apply hue rotation per render pass to preserve re-render behavior; use configured degrees
            hueShiftDegrees = 100.408 * (loopIndex + 1);
            applySaturationBoost = true;
            saturationBoostValue = 1.204;
            applyGain = 1.25;

            // Invert colors fully (100%)
            applyInvert = true;

            // Keep fisheye off for this preset
            applyFisheye = false;
            k1 = 0;
            break;

        case 'f_major':
            // F Major: TV Simulator with horizontal wave, line-sync feel, hue rotate, full inversion and gain boost
            applyVhs = true;
            // Line sync mapping (~0.7500) -> scale shake amplitude accordingly
            applyShake = true;
            shakeAmplitude = Math.max(1, Math.round(4 * 0.7500 * (1 + loopIndex * 0.02)));
            shakeFrequency = 6;
            // Horizontal-only wave for scan jitter
            applyWave = true;
            waveDirection = 'horizontal';
            waveCount = 6;
            waveAmplitude = Math.max(1, Math.round(Math.min(width, height) * 0.01));
            // Hue rotation and full inversion
            applyHueShift = true;
            hueShiftDegrees = 146.939 * (loopIndex + 1);
            applyInvert = true;
            // Slight gain boost (brightness multiplier)
            applyGain = 1.25;
            // keep fisheye off for TV look
            applyFisheye = false;
            k1 = 0;
            break;

        case 'baarenchrome_g_major_1':
            // BaarenChrome's G-Major 1:
            // - alternate inversion like other G-major re-renders
            // - apply a 180° hue shift per render pass
            // - softly mirror right->left (reflect-left) for the mirrored look
            // - apply a subtle swirl by default, and a pronounced swirl+motion on the 50th power
            applyHueShift = true;
            hueShiftDegrees = 180 * (loopIndex + 1);
            // We want inversion to alternate similarly to the other G-major effects;
            // initial value is set below by the global invertAllowedEffects override.
            applyReflectLeft = true;
            applySwirl = true;
            // default subtle swirl
            swirlStrength = 0.2;
            swirlCount = 0;
            // On the 50th power (loopIndex >= 49) boost swirl and add a touch of shake for a final-pass finish
            if (typeof loopIndex === 'number' && loopIndex >= 49) {
                swirlStrength = 0.50;      // stronger swirl for the "50th power" finish
                swirlCount = 0;
                applyShake = true;
                shakeAmplitude = Math.max(3, Math.min(8, Math.floor(Math.min(width || 0, height || 0) * 0.015)));
                shakeFrequency = 5;
                // slight saturation boost to help the final pass pop
                applySaturationBoost = true;
                saturationBoostValue = 1.12;
            }
            // Do not enable aggressive fisheye or wave by default
            applyFisheye = false;
            k1 = 0;
            break;

        case 'mikesons_g_major_36':
            // Mikeson's G-Major 36:
            // - apply a +23° hue shift per render pass (accumulates across re-renders)
            // - softly mirror right->left (reflect-left) to create the mirrored effect
            applyHueShift = true;
            hueShiftDegrees = 23 * (loopIndex + 1);
            applyReflectLeft = true;

            // Default: keep heavy spatial distortion off for a cleaner, color/mirror-focused preset
            applyFisheye = false;
            k1 = 0;
            applySwirl = false;

            // Special handling for 50th-power runs: add a pronounced visual "final pass" finish
            // when loopIndex >= 49 (50th power using 0-based loopIndex). This enables swirl, shake
            // and a small saturation boost to make the final render feel "finished".
            if (typeof loopIndex === 'number' && loopIndex >= 49) {
                applySwirl = true;
                swirlStrength = 0.50;      // stronger but stable swirl for the final pass
                swirlCount = 0;
                applyShake = true;
                shakeAmplitude = 6;        // modest shake to add motion
                shakeFrequency = 6;
                applySaturationBoost = true;
                saturationBoostValue = 1.20; // slight saturation lift for punch
                // also allow a subtle vignette-ish darkening through small VHS-like processing if available
                applyVhs = true;
            }
            break;

        case 'neptunegt8_g_major_121':
            // @NeptuneGT8's G-Major 121: apply a -180° hue shift per render and horizontal flip on odd-numbered powers only
            applyHueShift = true;
            hueShiftDegrees = -180 * (loopIndex + 1); // accumulate per re-render pass (deterministic)
            // Flip on powers 1,3,5,... (i.e., when loopIndex+1 is odd), do not flip on even powers
            applyFlip = ((loopIndex + 1) % 2 === 1);
            // No spatial distortion or extra processing beyond flip + hue mapping
            applyFisheye = false;
            k1 = 0;
            break;

        case 'usatve2004_g_major_32':
            // USATVE2004's G Major 32 visuals: Invert on odd powers, RGB->BGR swap, reflect-left mirror, and hue +180
            applySwapRGB = true;          // RGB -> BGR channel swap
            applyReflectLeft = true;      // mirror/reflect left (softened reflect)
            // Follow the project's invert-on-odd-powers convention for visual inversion
            applyInvert = ((loopIndex + 1) % 2 === 1);
            // Also apply a 180° hue shift per render pass (accumulates across re-renders)
            applyHueShift = true;
            hueShiftDegrees = 180 * (loopIndex + 1);
            // Keep heavy spatial distortions off by default for clarity
            applyFisheye = false;
            k1 = 0;
            // Subtle saturation boost on deeper passes for a psychedelic finish
            if (typeof loopIndex === 'number' && loopIndex >= 49) {
                applySaturationBoost = true;
                saturationBoostValue = 1.12;
            }
            break;

        case 'custom':
            // Respect custom params but do not apply fisheye
            applyFisheye = false;
            k1 = 0;
            applyHueShift = true;
            hueShiftDegrees = (customParams.hueShift || 0) * (loopIndex + 1);
            applyInvert = customParams.invert && ((loopIndex + 1) % 2 === 1);
            break;

        case 'custom_major_333':
            // Custom Major 333: rotate -1°, invert on 0th and 50th power, and apply sharpen 0.8
            applyRotate = true;
            rotateDegrees = -1; // fixed -1 degree rotation per pass (not cumulative)
            applySharpen = true;
            sharpenStrength = 0.8; // strength for unsharp-like operation
            // Invert only on loopIndex 0 or 49 (50th power -> index 49)
            if (loopIndex === 0 || loopIndex === 49) applyInvert = true;
            break;

        case 'custom_major_3':
            // "Custom Major 3" preset: Hue +165 per render, reflect-left (softened mirror), no fisheye
            applyFisheye = false;
            k1 = 0;
            applyHueShift = true;
            // Apply +165° hue per render pass to accumulate similar to other re-render effects
            hueShiftDegrees = 165 * (loopIndex + 1);
            // Use reflect-left (mirror right onto left) rather than simple horizontal flip and add a saturation boost
            applyReflectLeft = true;
            applySaturationBoost = true;
            saturationBoostValue = 1.3; // modest but visible saturation increase for psychedelic effect
            // No inversion unless custom params request it; keep deterministic behavior
            applyInvert = customParams.invert && ((loopIndex + 1) % 2 !== 0);
            break;
    }

    // Enforce global rule: invert on odd-numbered powers (1, 3, 5, ...) but only for a specific set of effects.
    // This override ensures consistent invert behavior for those effects while not forcing inversion for others.
    {
        const invertAllowedEffects = new Set([
            'normal_g_major_7',
            'gmajor7',
            'gmajor74',
            'braxtons_gmajor_74',
            'crying',
            'dxi',
            'h_major_9003',
            'j_major_9009',
            'g_major_5xp',
            'g_major_1',
            'g_major_137',
            'simulator_v19',
            'baarenchrome_g_major_1',
            'usatve2004_g_major_32'
        ]);
        applyInvert = invertAllowedEffects.has(effectType) && ((loopIndex + 1) % 2 === 1);
    }

    const continuousTimeForScroll = 
        (typeof frameTime === 'number' ? frameTime : 0) + 
        (loopIndex > 0 && isFinite(videoDurationSec) ? loopIndex * videoDurationSec : 0);

    if (applyInfiniteScroll) {
        const offsetX = scrollDirection === 'horizontal' ? (continuousTimeForScroll * scrollPixelsPerSecondX) : 0;
        const offsetY = scrollDirection === 'vertical' ? (continuousTimeForScroll * scrollPixelsPerSecondY) : 0;

        for (let y = 0; y < height; y++) {
            let srcY = (y + offsetY) % height;
            if (srcY < 0) srcY += height;
            const srcYInt = srcY | 0;
            const srcRowOffset = srcYInt * width;
            const destRowOffset = y * width;
            
            for (let x = 0; x < width; x++) {
                let srcX = (x + offsetX) % width;
                if (srcX < 0) srcX += width;
                const srcXInt = srcX | 0;
                new32[destRowOffset + x] = original32[srcRowOffset + srcXInt];
            }
        }
        return cachedImageData;
    }

    const t = (typeof frameTime === 'number' ? frameTime : 0);
    
    // Determine how many gradient layers to apply (repeat gradient mapping per export loop)
    // This multiplies gradient application by the render pass count (loopIndex+1) but clamps to a safe max.
    const gradientRepeat = Math.max(1, Math.min(8, (typeof loopIndex === 'number' ? Math.floor(loopIndex + 1) : 1)));
    
    // Reuse or create noise buffer for VHS
    if (applyVhs) {
        if (!noiseBuffer || noiseBuffer.length !== height) {
            noiseBuffer = new Float32Array(height);
        }
        for (let y = 0; y < height; y++) {
            const seed = (Math.sin(y * 12.9898 + t * 78.233) * 43758.5453) % 1;
            noiseBuffer[y] = seed - (seed | 0);
        }
    }

    // Pre-calculate spatial effect variables to speed up inner loop
    const halfWidth = width / 2;
    const halfHeight = height / 2;
    const maxDist = Math.sqrt(centerX * centerX + centerY * centerY);
    // Allow per-axis wave frequency/amplitude overrides for special effects like 89-dxi
    let waveFreqY = 2 * Math.PI * waveCount / height;
    let waveFreqX = 2 * Math.PI * waveCount / width;
    // default per-axis amplitudes derived from waveAmplitude; will be overridden if 89-dxi params exist
    let vWaveAmp = waveAmplitude;
    let hWaveAmp = waveAmplitude;

    // If custom 89-dxi parameters were set, compute axis-specific frequencies and amplitudes
    if (typeof __89_v_wave_count !== 'undefined' && typeof __89_v_wave_amp_ratio !== 'undefined') {
        waveFreqY = 2 * Math.PI * (__89_v_wave_count) / height;
        vWaveAmp = Math.max(1, Math.round(Math.min(width, height) * (__89_v_wave_amp_ratio)));
    }
    if (typeof __89_h_wave_count !== 'undefined' && typeof __89_h_wave_amp_ratio !== 'undefined') {
        waveFreqX = 2 * Math.PI * (__89_h_wave_count) / width;
        hWaveAmp = Math.max(0.5, Math.round(Math.min(width, height) * (__89_h_wave_amp_ratio))); // allow sub-pixel but at least 0.5
    }

    const swirlAngleMultiplier = swirlCount > 0 ? swirlCount * 2 * Math.PI : swirlStrength;
    const shakeOffset = applyShake ? shakeAmplitude * Math.sin(frameTime * shakeFrequency * 6.28318) : 0;

    // Spatial + Color loop: Optimized for speed
    for (let y = 0; y < height; y++) {
        let jitter = 0;
        if (applyVhs) {
            jitter = (Math.sin((t * 2.1) + y * 0.02) * 1.2) + (noiseBuffer[y] - 0.5) * 0.8;
        }

        const skewOffset = (applySkew && skewMode === 'eraser') 
            ? ((( (y % skewStripeHeight) / skewStripeHeight) * 2 ) - 1) * skewMaxPixels 
            : 0;

        const destRowOffset = y * width;
        const vhsFlicker = applyVhs ? (0.95 + 0.05 * Math.sin(t * 6.28)) : 1.0;
        const cy = applyVhs ? (y - halfHeight) / halfHeight : 0;

        for (let x = 0; x < width; x++) {
            let srcX = x + jitter + skewOffset;
            let srcY = y + shakeOffset;

            // Inverted reflect-left: mirror the left half onto the right half (so right looks like reflected left)
            if (applyReflectLeft) {
                // Softened reflect-left inverted: take pixels from the left of center and mirror them to the right,
                // with a small attenuation (0.9) to avoid a perfect rigid flip.
                if (x >= halfWidth) {
                    // mirrored relative to center with a small attenuation for a less perfect mirror
                    const mirroredX = Math.floor(centerX - (x - centerX) * 0.9);
                    // clamp into range
                    const safeMirroredX = Math.max(0, Math.min(width - 1, mirroredX));
                    srcX = safeMirroredX;
                }
            } else {
                if (applyFlip || applyFlipAlways) srcX = (width - 1) - srcX;
                if (applyMirrorLR && srcX >= halfWidth) srcX = (width - 1) - srcX;
            }

            if (applyBraxtonsFisheye || applyFisheye) {
                // Determine a mix/scalar from custom parameters (allows user to "mixture" the fisheye)
                // customParams.fisheyeStrength expected in roughly [-2.0 .. 2.0]; default to 1.0 (no change)
                const mixFactor = (customParams && typeof customParams.fisheyeStrength === 'number')
                    ? customParams.fisheyeStrength
                    : 1.0;

                // Determine base strengths for Braxtons vs generic fisheye, then apply mixFactor.
                const braxtonsBase = -0.12;
                const genericBase = k1 || 0;
                // If Braxtons fisheye requested, blend between braxtonsBase and genericBase (50/50) then scale.
                let strength = applyBraxtonsFisheye
                    ? (braxtonsBase * 0.5 + genericBase * 0.5) * mixFactor
                    : genericBase * mixFactor;

                // Allow custom fisheye size to influence zoom; fallback to 1.0
                const zoom = (customParams && typeof customParams.fisheyeSize === 'number')
                    ? Math.max(0.1, customParams.fisheyeSize)
                    : 1.0;

                // Accurate fisheye implementation using a division model with a small r4 term for smoother edges.
                // Center and normalize coordinates to [-1, 1]
                const nx = (srcX - halfWidth) / halfWidth;
                const ny = (srcY - halfHeight) / halfHeight;
                const r2 = nx * nx + ny * ny;

                // Compute distortion coefficients; k2 is proportional to k1 for a spherical look.
                const k1_val = strength;
                const k2_val = strength * 0.5;

                // Guard against extreme coefficients producing NaNs/Inf by clamping reasonable bounds.
                const safeK1 = Math.max(-4.0, Math.min(4.0, k1_val));
                const safeK2 = Math.max(-4.0, Math.min(4.0, k2_val));

                const denom = 1.0 + safeK1 * r2 + safeK2 * r2 * r2;
                const factor = (denom === 0) ? 1.0 : (1.0 / denom) * (1.0 / zoom);

                srcX = (nx * factor) * halfWidth + halfWidth;
                srcY = (ny * factor) * halfHeight + halfHeight;
            }

            if (applyWave) {
                // Use axis-specific amplitudes/frequencies when available (89-dxi uses vWaveAmp/hWaveAmp)
                // Support optional 10th-power sharpening of the sine waveform for peaked waves.
                const hAmp = (typeof hWaveAmp !== 'undefined' ? hWaveAmp : waveAmplitude);
                const vAmp = (typeof vWaveAmp !== 'undefined' ? vWaveAmp : waveAmplitude);

                if (waveDirection === 'horizontal' || waveDirection === 'both') {
                    const s = Math.sin(srcY * waveFreqY);
                    if (typeof applyWavePower10 !== 'undefined' && applyWavePower10) {
                        const shaped = Math.sign(s) * Math.pow(Math.abs(s), 10);
                        srcX += hAmp * shaped;
                    } else {
                        srcX += hAmp * s;
                    }
                }
                if (waveDirection === 'vertical' || waveDirection === 'both') {
                    const s2 = Math.sin(srcX * waveFreqX);
                    if (typeof applyWavePower10 !== 'undefined' && applyWavePower10) {
                        const shaped2 = Math.sign(s2) * Math.pow(Math.abs(s2), 10);
                        srcY += vAmp * shaped2;
                    } else {
                        srcY += vAmp * s2;
                    }
                }
            }

            if (applySwirl) {
                const dx = srcX - centerX, dy = srcY - centerY;
                const distance = Math.sqrt(dx * dx + dy * dy);
                const angle = Math.atan2(dy, dx) + (distance / maxDist) * swirlAngleMultiplier;
                srcX = centerX + distance * Math.cos(angle);
                srcY = centerY + distance * Math.sin(angle);
            }

            const ix = (srcX + 0.5) | 0;
            const iy = (srcY + 0.5) | 0;
            const safeX = ix < 0 ? 0 : (ix >= width ? width - 1 : ix);
            const safeY = iy < 0 ? 0 : (iy >= height ? height - 1 : iy);
            const srcIdx = (safeY * width + safeX) << 2;

            let r, g, b, a = originalPixels[srcIdx + 3];

            if (applyVhs) {
                const xR = (srcX + 1.5) | 0, xB = (srcX - 0.5) | 0;
                const sXR = xR < 0 ? 0 : (xR >= width ? width - 1 : xR);
                const sXB = xB < 0 ? 0 : (xB >= width ? width - 1 : xB);
                r = originalPixels[(safeY * width + sXR) << 2];
                g = originalPixels[srcIdx + 1];
                b = originalPixels[((safeY * width + sXB) << 2) + 2];
            } else {
                r = originalPixels[srcIdx];
                g = originalPixels[srcIdx + 1];
                b = originalPixels[srcIdx + 2];
            }

            if (applyHueShift) {
                let [h, s, l] = rgbToHsl(r, g, b);
                h = shiftHue(h, hueShiftDegrees);
                [r, g, b] = hslToRgb(h, s, l);
            }

            if (applyInvert) { r = 255 - r; g = 255 - g; b = 255 - b; }

            // Apply optional saturation boost for psychedelic reflect-left presets
            if (applySaturationBoost) {
                try {
                    let [hh, ss, ll] = rgbToHsl(
                        Math.max(0, Math.min(255, Math.round(r))),
                        Math.max(0, Math.min(255, Math.round(g))),
                        Math.max(0, Math.min(255, Math.round(b)))
                    );
                    ss = Math.min(1, ss * (saturationBoostValue || 1));
                    const [nr, ng, nb] = hslToRgb(hh, ss, ll);
                    r = nr; g = ng; b = nb;
                } catch (e) {
                    // if HSL path fails, ignore and keep original RGB
                }
            }

            if (applyGreenTint) { r *= 0.9; g *= 1.1; b *= 0.9; }

            // G-Major 3 red tint: boost red channel and reduce green/blue for a warm/red palette
            if (typeof applyRedTint !== 'undefined' && applyRedTint) {
                r = Math.min(255, r * 1.25);
                g = Math.max(0, g * 0.6);
                b = Math.max(0, b * 0.6);
            }

            if (applyGMajor4) {
                // Use luminance to accurately detect all "white" and bright areas (including bright yellows/cyans)
                const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
                if (lum > 190) { r = 0; g = 0; b = 0; }
            }

            if (applyNavynus) {
                const luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
                if (luminance < 30) { r = 0; g = 0; b = 0; }
                else {
                    r = 0; g = 0;
                    b = Math.max(50, Math.min(100, Math.round(50 + (luminance - 30) * 50 / 225)));
                }
            }

            if (applyVhs) {
                const dim = (y & 1) ? 0.88 : 1.0;
                r *= vhsFlicker * dim; g *= vhsFlicker * dim; b *= vhsFlicker * dim;
                const cx = (x - halfWidth) / halfWidth;
                const vignette = Math.max(0.75, 1.0 - (cx * cx + cy * cy) * 0.25);
                r *= vignette; g *= vignette; b *= vignette;
                const n = (noiseBuffer[y] - 0.5) * 18;
                r += n; g += n * 0.8; b += n * 1.2;
            }

            // Apply per-effect gain multiplier (clamp safely)
            if (typeof applyGain !== 'undefined' && applyGain !== 1.0) {
                r *= applyGain; g *= applyGain; b *= applyGain;
            }

            if (applySwapRGB) { const tmp = r; r = b; b = tmp; }
            // If red-only channel blend requested, zero out green and blue channels
            if (applyRedOnly) { g = 0; b = 0; }

            // Apply sharpening (simple unsharp-like blend) if requested
            if (applySharpen) {
                // sample four-neighbor average from originalPixels to compute local average
                const nx1 = Math.max(0, safeX - 1), nx2 = Math.min(width - 1, safeX + 1);
                const ny1 = Math.max(0, safeY - 1), ny2 = Math.min(height - 1, safeY + 1);
                const idxN1 = (safeY * width + nx1) << 2;
                const idxN2 = (safeY * width + nx2) << 2;
                const idxN3 = (ny1 * width + safeX) << 2;
                const idxN4 = (ny2 * width + safeX) << 2;
                const avgR = (originalPixels[idxN1] + originalPixels[idxN2] + originalPixels[idxN3] + originalPixels[idxN4]) * 0.25;
                const avgG = (originalPixels[idxN1 + 1] + originalPixels[idxN2 + 1] + originalPixels[idxN3 + 1] + originalPixels[idxN4 + 1]) * 0.25;
                const avgB = (originalPixels[idxN1 + 2] + originalPixels[idxN2 + 2] + originalPixels[idxN3 + 2] + originalPixels[idxN4 + 2]) * 0.25;
                // sharpen = original + strength * (original - neighborAvg)
                const s = sharpenStrength || 0.5;
                r = r + s * (r - avgR);
                g = g + s * (g - avgG);
                b = b + s * (b - avgB);
            }

            // Lab-based Luminosity inversion: invert perceptual L* while preserving chroma/a/b.
            // Only applied when flagged by the switch above (g_major_42)
            if (typeof applyLumInvert !== 'undefined' && applyLumInvert) {
                try {
                    const [nr, ng, nb] = invertLabLightnessPreserveChroma(
                        Math.max(0, Math.min(255, Math.round(r))),
                        Math.max(0, Math.min(255, Math.round(g))),
                        Math.max(0, Math.min(255, Math.round(b)))
                    );
                    r = nr; g = ng; b = nb;
                } catch (e) {
                    // Fallback to simple HSL inversion if Lab path fails
                    const [hh, ss, ll] = rgbToHsl(
                        Math.max(0, Math.min(255, Math.round(r))),
                        Math.max(0, Math.min(255, Math.round(g))),
                        Math.max(0, Math.min(255, Math.round(b)))
                    );
                    const invL = 1 - ll;
                    const [nr, ng, nb] = hslToRgb(hh, ss, invL);
                    r = nr; g = ng; b = nb;
                }
            }

            // X Major gradient map variants:
            // - X Major 159: white -> pink -> black
            // - j's X Major 159: white -> orange -> black
            if (applyXGradientMap || applyJXGradientMap) {
                // Multiply the gradient mapping per-export by iteratively remapping the pixel
                // Use a local triple to fold repeated gradient passes without allocating each time.
                let localR = r, localG = g, localB = b;
                const white = [255, 255, 255];
                const mid = applyJXGradientMap ? [255, 165, 0] : [255, 105, 180]; // orange or pink
                const black = [0, 0, 0];

                for (let gi = 0; gi < gradientRepeat; gi++) {
                    let lum = 0.2126 * localR + 0.7152 * localG + 0.0722 * localB;
                    let t = lum / 255;
                    if (t < 0) t = 0;
                    if (t > 1) t = 1;

                    let nr, ng, nb;
                    if (t <= 0.5) {
                        const u = t / 0.5; // 0..1 from white to mid
                        nr = white[0] + (mid[0] - white[0]) * u;
                        ng = white[1] + (mid[1] - white[1]) * u;
                        nb = white[2] + (mid[2] - white[2]) * u;
                    } else {
                        const u = (t - 0.5) / 0.5; // 0..1 from mid to black
                        nr = mid[0] + (black[0] - mid[0]) * u;
                        ng = mid[1] + (black[1] - mid[1]) * u;
                        nb = mid[2] + (black[2] - mid[2]) * u;
                    }

                    // write back for next iteration (or final assignment)
                    localR = nr; localG = ng; localB = nb;
                }

                r = localR; g = localG; b = localB;
            }

            // Oskar's G Major 5: gradient map black -> cyan -> black and moderate radial light rays
            if (typeof applyOskarsGradient !== 'undefined' && applyOskarsGradient) {
                const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
                let t = lum / 255;
                if (t < 0) t = 0;
                if (t > 1) t = 1;

                // Map 0..0.5 -> black -> cyan, 0.5..1 -> cyan -> black
                let nr, ng, nb;
                const black = [0, 0, 0];
                const cyan = [0, 255, 255];
                if (t <= 0.5) {
                    const u = t / 0.5;
                    nr = black[0] + (cyan[0] - black[0]) * u;
                    ng = black[1] + (cyan[1] - black[1]) * u;
                    nb = black[2] + (cyan[2] - black[2]) * u;
                } else {
                    const u = (t - 0.5) / 0.5;
                    nr = cyan[0] + (black[0] - cyan[0]) * u;
                    ng = cyan[1] + (black[1] - cyan[1]) * u;
                    nb = cyan[2] + (black[2] - cyan[2]) * u;
                }
                r = nr; g = ng; b = nb;
            }

            // 89-DXI gradient map: luminance-based mapping Green -> White -> Black
            if (typeof apply89Gradient !== 'undefined' && apply89Gradient) {
                const lum89 = 0.2126 * r + 0.7152 * g + 0.0722 * b;
                let t89 = lum89 / 255;
                if (t89 < 0) t89 = 0;
                if (t89 > 1) t89 = 1;

                let nr89, ng89, nb89;
                const green = [0, 255, 0];
                const white = [255, 255, 255];
                const black = [0, 0, 0];

                if (t89 <= 0.5) {
                    const u = t89 / 0.5;
                    nr89 = green[0] + (white[0] - green[0]) * u;
                    ng89 = green[1] + (white[1] - green[1]) * u;
                    nb89 = green[2] + (white[2] - green[2]) * u;
                } else {
                    const u = (t89 - 0.5) / 0.5;
                    nr89 = white[0] + (black[0] - white[0]) * u;
                    ng89 = white[1] + (black[1] - white[1]) * u;
                    nb89 = white[2] + (black[2] - white[2]) * u;
                }

                r = nr89; g = ng89; b = nb89;
            }

            // 22-DXI gradient map: Dark Red -> Transparent (luminance-driven)
            if (typeof apply22Gradient !== 'undefined' && apply22Gradient) {
                const lum22 = 0.2126 * r + 0.7152 * g + 0.0722 * b;
                let t22 = lum22 / 255;
                if (t22 < 0) t22 = 0;
                if (t22 > 1) t22 = 1;

                // dark red color
                const dr = [139, 0, 0];

                // Blend from dark red (low luminance) to original pixel (high luminance).
                // At the same time, reduce alpha toward 0 for brighter pixels to create Dark->Transparent mapping.
                const blendedR = dr[0] * (1 - t22) + r * t22;
                const blendedG = dr[1] * (1 - t22) + g * t22;
                const blendedB = dr[2] * (1 - t22) + b * t22;

                // Make darker pixels opaque and brighter pixels more transparent (alpha scaled by t22)
                a = a * t22;

                r = blendedR; g = blendedG; b = blendedB;
            }

            // Fanny Major gradient: luminance-based mapping White -> Black -> Blue (applied after main color ops)
            if (typeof applyFannyGradient !== 'undefined' && applyFannyGradient) {
                const lumF = 0.2126 * r + 0.7152 * g + 0.0722 * b;
                let tf = lumF / 255;
                if (tf < 0) tf = 0;
                if (tf > 1) tf = 1;

                let nrf, ngf, nbf;
                const white = [255, 255, 255];
                const black = [0, 0, 0];
                const blue = [0, 0, 255];

                // 0..0.5 : white -> black ; 0.5..1 : black -> blue
                if (tf <= 0.5) {
                    const u = tf / 0.5;
                    nrf = white[0] + (black[0] - white[0]) * u;
                    ngf = white[1] + (black[1] - white[1]) * u;
                    nbf = white[2] + (black[2] - white[2]) * u;
                } else {
                    const u = (tf - 0.5) / 0.5;
                    nrf = black[0] + (blue[0] - black[0]) * u;
                    ngf = black[1] + (blue[1] - black[1]) * u;
                    nbf = black[2] + (blue[2] - black[2]) * u;
                }

                r = nrf; g = ngf; b = nbf;
            }

            // G Major 54 gradient: luminance-based mapping White -> Red -> Black (applied after main color ops)
            if (typeof applyGMajor54 !== 'undefined' && applyGMajor54) {
                const lumG54 = 0.2126 * r + 0.7152 * g + 0.0722 * b;
                let tg54 = lumG54 / 255;
                if (tg54 < 0) tg54 = 0;
                if (tg54 > 1) tg54 = 1;

                let nr54, ng54, nb54;
                const white = [255, 255, 255];
                const red = [255, 0, 0];
                const black = [0, 0, 0];

                // 0..0.5 : white -> red ; 0.5..1 : red -> black
                if (tg54 <= 0.5) {
                    const u = tg54 / 0.5;
                    nr54 = white[0] + (red[0] - white[0]) * u;
                    ng54 = white[1] + (red[1] - white[1]) * u;
                    nb54 = white[2] + (red[2] - white[2]) * u;
                } else {
                    const u = (tg54 - 0.5) / 0.5;
                    nr54 = red[0] + (black[0] - red[0]) * u;
                    ng54 = red[1] + (black[1] - red[1]) * u;
                    nb54 = red[2] + (black[2] - red[2]) * u;
                }

                r = nr54; g = ng54; b = nb54;
            }

            if (typeof applyLightRays !== 'undefined' && applyLightRays) {
                // Moderate radial light rays: create angular modulation (streaks) emanating from center
                const dx = x - centerX;
                const dy = y - centerY;
                const dist = Math.sqrt(dx * dx + dy * dy);
                const nd = Math.max(0, 1 - (dist / maxDist)); // 1 at center -> 0 at edges
                const angle = Math.atan2(dy, dx);
                // Use sin of angle * ray count + time to produce moving/pulsing rays
                const rayPhase = Math.sin(angle * (oskars_rays_count || 20) + t * 2.0);
                const rayMask = Math.max(0, (rayPhase * 0.5) + 0.5); // 0..1
                const rayBoost = (oskars_rays_strength || 0.25) * rayMask * nd;
                r = r + (255 - r) * rayBoost;
                g = g + (255 - g) * rayBoost;
                b = b + (255 - b) * rayBoost;
            }

            // G Major 901 gradient mapping: spot0 -> spot1 -> spot2 via luminance (0..1)
            if (typeof applyGMajor901 !== 'undefined' && applyGMajor901) {
                const lumG = 0.2126 * r + 0.7152 * g + 0.0722 * b;
                let u = lumG / 255;
                if (u < 0) u = 0;
                if (u > 1) u = 1;

                // Map 0..0.5 -> spot0 -> spot1, 0.5..1 -> spot1 -> spot2
                let nr, ng, nb;
                if (u <= 0.5) {
                    const t0 = u / 0.5;
                    nr = g901_spot0[0] + (g901_spot1[0] - g901_spot0[0]) * t0;
                    ng = g901_spot0[1] + (g901_spot1[1] - g901_spot0[1]) * t0;
                    nb = g901_spot0[2] + (g901_spot1[2] - g901_spot0[2]) * t0;
                } else {
                    const t1 = (u - 0.5) / 0.5;
                    nr = g901_spot1[0] + (g901_spot2[0] - g901_spot1[0]) * t1;
                    ng = g901_spot1[1] + (g901_spot2[1] - g901_spot1[1]) * t1;
                    nb = g901_spot1[2] + (g901_spot2[2] - g901_spot1[2]) * t1;
                }
                r = nr; g = ng; b = nb;
            }

            // Apply optional contrast tweak for 22-DXI if set
            if (typeof contrastFactor22 !== 'undefined') {
                const cf = contrastFactor22;
                r = (r - 128) * cf + 128;
                g = (g - 128) * cf + 128;
                b = (b - 128) * cf + 128;
            }

            const di = destRowOffset + x;
            newPixels[di << 2] = r < 0 ? 0 : (r > 255 ? 255 : r);
            newPixels[(di << 2) + 1] = g < 0 ? 0 : (g > 255 ? 255 : g);
            newPixels[(di << 2) + 2] = b < 0 ? 0 : (b > 255 ? 255 : b);
            newPixels[(di << 2) + 3] = a;
        }
    }

    return cachedImageData;
}