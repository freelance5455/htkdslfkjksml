// Visual effect helpers extracted from script.js
import { rgbToHsl, hslToRgb, shiftHue } from './colorUtils.js';

/*
 * Perceptual Lab helpers for luminosity inversion:
 * - srgbToLinear: sRGB (0-255) -> linear RGB (0-1)
 * - linearToXyz / xyzToLinear: conversion helpers
 * - xyzToLab / labToXyz: Lab conversion helpers
 * - labToSrgb: convert Lab back to sRGB 0-255
 *
 * These functions are local, lightweight and avoid external deps.
 */

function srgbToLinearChannel(v) {
    v = v / 255;
    return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
}
function linearToSrgbChannel(v) {
    return v <= 0.0031308 ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - 0.055;
}
function rgbToXyz(r, g, b) {
    // r,g,b in 0-255
    const R = srgbToLinearChannel(r);
    const G = srgbToLinearChannel(g);
    const B = srgbToLinearChannel(b);
    // sRGB D65
    const X = R * 0.4124564 + G * 0.3575761 + B * 0.1804375;
    const Y = R * 0.2126729 + G * 0.7151522 + B * 0.0721750;
    const Z = R * 0.0193339 + G * 0.1191920 + B * 0.9503041;
    return [X, Y, Z];
}
function xyzToLab(X, Y, Z) {
    // D65 reference white
    const Xn = 0.95047, Yn = 1.00000, Zn = 1.08883;
    const eps = 216 / 24389; // 0.008856
    const k = 24389 / 27; // 903.3

    const fx = X / Xn;
    const fy = Y / Yn;
    const fz = Z / Zn;

    const f = v => v > eps ? Math.cbrt(v) : (k * v + 16) / 116;

    const fx2 = f(fx), fy2 = f(fy), fz2 = f(fz);

    const L = (116 * fy2) - 16;
    const a = 500 * (fx2 - fy2);
    const b = 200 * (fy2 - fz2);
    return [L, a, b];
}
function labToXyz(L, a, b) {
    const Xn = 0.95047, Yn = 1.00000, Zn = 1.08883;
    const eps = 216 / 24389;
    const k = 24389 / 27;

    const fy = (L + 16) / 116;
    const fx = fy + (a / 500);
    const fz = fy - (b / 200);

    const fInv = t => {
        const t3 = t * t * t;
        return t3 > eps ? t3 : (116 * t - 16) / k;
    };

    const X = Xn * fInv(fx);
    const Y = Yn * fInv(fy);
    const Z = Zn * fInv(fz);
    return [X, Y, Z];
}
function xyzToRgb(X, Y, Z) {
    // convert XYZ -> linear RGB
    let R = X *  3.2404542 + Y * -1.5371385 + Z * -0.4985314;
    let G = X * -0.9692660 + Y *  1.8760108 + Z *  0.0415560;
    let B = X *  0.0556434 + Y * -0.2040259 + Z *  1.0572252;
    // clamp then convert linear -> sRGB
    R = linearToSrgbChannel(Math.max(0, R));
    G = linearToSrgbChannel(Math.max(0, G));
    B = linearToSrgbChannel(Math.max(0, B));
    return [
        Math.round(Math.max(0, Math.min(1, R)) * 255),
        Math.round(Math.max(0, Math.min(1, G)) * 255),
        Math.round(Math.max(0, Math.min(1, B)) * 255)
    ];
}
function invertLabLightnessPreserveChroma(r, g, b) {
    // Convert to Lab, invert L* (perceptual lightness), convert back
    const [X, Y, Z] = rgbToXyz(r, g, b);
    const [L, a, bb] = xyzToLab(X, Y, Z);
    // avoid divide-by-zero: if L is near 0, treat as pure black -> map to white (100)
    const Li = isFinite(L) ? (100 - L) : 100;
    const [Xi, Yi, Zi] = labToXyz(Li, a, bb);
    return xyzToRgb(Xi, Yi, Zi);
}

/**
 * Helper to recursively multiply pitches to simulate "re-rendering".
 * Each "render" applies the base shifts to all current voices.
 */
function multiplyPitches(base, loopIndex, maxVoices = 2048) {
    // Prevent exponential blow-up of pitch voices by capping recursive multiplication.
    // Allow multiple compound passes driven by loopIndex, but clamp to a higher safe maximum
    // so compounding continues beyond 6–7 renders while still protecting CPU/memory.
    if (!Array.isArray(base) || base.length === 0) return [];
    if (loopIndex <= 0) return Array.from(new Set(base)).sort((a, b) => a - b);

    // Increase allowed compound loops but keep a hard upper bound to avoid runaway growth.
    // Most real-world uses won't need more than ~30 compound passes; clamp to that.
    const MAX_COMPOUND_LOOPS = 30;
    const effectiveLoops = Math.min(MAX_COMPOUND_LOOPS, Math.max(0, Math.floor(loopIndex)));

    // Defensive cap on voices to keep runtime stable; raise to 1024 but keep slicing if exceeded.
    let current = [...base];
    for (let i = 0; i < effectiveLoops; i++) {
        let next = [];
        for (let p of current) {
            for (let b of base) {
                next.push(p + b);
            }
        }
        // Deduplicate and sort for deterministic output
        current = [...new Set(next)].sort((a, b) => a - b);

        // If we exceed maxVoices, keep a representative subset:
        // - prefer low-to-high order (musically coherent)
        // - but if it's enormous, sample uniformly to avoid bias
        if (current.length > maxVoices) {
            // If only slightly over, just slice; if massively over, sample evenly
            if (current.length <= maxVoices * 4) {
                current = current.slice(0, maxVoices);
            } else {
                const sampled = [];
                const step = current.length / maxVoices;
                for (let s = 0; s < maxVoices; s++) {
                    sampled.push(current[Math.floor(s * step)]);
                }
                current = sampled;
            }
        }
    }
    return current;
}

export function getPitchShiftForEffect(effect, totalPower, loopIndex, customParams = {}) {
    if (effect === 'normal' || effect === 'reverse') return [];

    switch (effect) {
        case 'custom':
            const basePitch = customParams.pitch || 0;
            if (basePitch === 0) return [];
            // Create a compounding "choir" effect by stacking the custom pitch shift in each render pass
            return multiplyPitches([0, basePitch], loopIndex);
        case 'gmajor5':
            return multiplyPitches([4, 5, -4, -5], loopIndex);
        case 'wigglem major':
            return multiplyPitches([12, 0, -2], loopIndex);
        case 'navynusmajor':
            return multiplyPitches([4, -7], loopIndex);
        case 'dxi':
            return multiplyPitches([-7, 0, 7], loopIndex);
        case 'gmajor4':
            return multiplyPitches([0, 5], loopIndex);
        case 'gmajor74':
            return multiplyPitches([14, 9, -10], loopIndex);
        case 'braxtons_gmajor_74':
            return multiplyPitches([2, -3], loopIndex);
        case 'braxtons_gmajor_28':
            return multiplyPitches([7, 0, -7], loopIndex);
        case 'gmajor90v3':
            return multiplyPitches([1, -1], loopIndex);
        case 'luiggroup':
            return [-(loopIndex + 1)];
        case 'crying':
            return multiplyPitches([0, -5], loopIndex);
        case 'gmajor7':
        case 'normal_g_major_7':
            return multiplyPitches([0, 3], loopIndex);
        case 'haha_major':
            return multiplyPitches([1.5, -1.5], loopIndex);
        case 'haha_major_3_0':
            return multiplyPitches([3.5, -3.5], loopIndex);
        case 'h_major_9003':
            return multiplyPitches([3, -3], loopIndex);
        case 'j_major_9009':
            return multiplyPitches([1.5, -1.5], loopIndex);
        case 'pika_major':
            return multiplyPitches([7, 0, -7], loopIndex);
        case 'g_major_5xp':
            return multiplyPitches([-7, 0, 7], loopIndex);
        case 'g_major_1':
            return multiplyPitches([8], loopIndex);
        case 'g_major_137':
            return multiplyPitches([-10, 9, 14], loopIndex);
        case 'g_major_42':
            // BGR swap + luminosity invert + hue 180 per render, musical pitches -3, 0, +4, +7 (compounding)
            return multiplyPitches([-3, 0, 4, 7], loopIndex);
        case 'g_minor_305':
            // Pitches multiply (compound) every power: base [-12, +7]
            return multiplyPitches([-12, 7], loopIndex);
        case 'x_major_159':
            // X Major 159: gradient map (white -> pink -> black) with pitches -5 and +7
            return multiplyPitches([-5, 7], loopIndex);
        case 'x_major_159_better':
            // X Major 159 but better: same pitch set but explicitly allowed to compound every power
            return multiplyPitches([-5, 7], loopIndex);
        case '89_dxi':
            return multiplyPitches([-2.25, 1.25], loopIndex);
        case '91_dxi':
            return multiplyPitches([0, -3.5], loopIndex);
        case 'a_major':
            return multiplyPitches([5.73, 10.5], loopIndex);
        case 'baarenchromes_g_major_1':
            return multiplyPitches([-3, 4], loopIndex);
        case 'g_major_25':
            return multiplyPitches([-1, -8], loopIndex);
        case 'simulator_v19':
            return multiplyPitches([-12, 0, 7], loopIndex);
        case 'tbwve571_g_major_84':
            return multiplyPitches([-4.5, 4.5], loopIndex);
        case 'g_major_225':
            return multiplyPitches([-4, 5], loopIndex);
        case 'g_major_576':
            return multiplyPitches([-4.1, 8], loopIndex);
        case 'g_major_16':
            return multiplyPitches([0, -3], loopIndex);
        case 'not_scary':
            return multiplyPitches([-2], loopIndex);
        case 'white_black_white':
            return multiplyPitches([24], loopIndex);
        case 'nothandlebacks_g_major_5':
            return multiplyPitches([0, -2.5], loopIndex);
        case 'usatve2004_g_major_32':
            return multiplyPitches([4, -5], loopIndex);
        case 'custom_major_3':
            return multiplyPitches([0, 0.1], loopIndex);
        case 'caught_a_cold':
            return multiplyPitches([-10, -6], loopIndex);
        case 'minus44_dxi':
            return multiplyPitches([-5, 2], loopIndex);
        case 'lost_effect':
            return multiplyPitches([-8, 16], loopIndex);
        case '44_dxi_spot':
            return multiplyPitches([-2, 5], loopIndex);
        case 'g_major_15':
            return multiplyPitches([0, 5], loopIndex);
        default:
            return [];
    }
}

// Pre-allocated buffers to avoid garbage collection lag
let noiseBuffer = null;
let cachedOutputBuffer = null;
let cachedImageData = null;
const MINUS44_DXI_GRADIENT = [[89, 255, 89], [255, 255, 127], [120, 255, 0], [0, 0, 0]];
const FORTYFOUR_DXI_SPOT_GRADIENT = [[255, 38, 255, 255], [0, 0, 192, 255], [135, 0, 255, 255], [255, 255, 255, 255]];

// Function to apply complex visual effects (pixel changes and spatial distortion)
// Optimized to reduce lag by reusing memory and minimizing object allocation.
export function applyComplexEffect(originalImageData, effectType, currentPower, loopIndex, frameTime, videoDurationSec, customParams = {}) {
    if (!originalImageData || effectType === 'normal') return originalImageData;

    const width = originalImageData.width;
    const height = originalImageData.height;
    
    if (!cachedOutputBuffer || cachedOutputBuffer.length !== width * height * 4) {
        cachedOutputBuffer = new Uint8ClampedArray(width * height * 4);
        cachedImageData = new ImageData(cachedOutputBuffer, width, height);
    }
    
    const originalPixels = originalImageData.data;
    const newPixels = cachedOutputBuffer;
    
    // Optimization: Use 32-bit views for faster pixel movement where possible
    const original32 = new Uint32Array(originalPixels.buffer);
    const new32 = new Uint32Array(newPixels.buffer);

    const centerX = width >> 1;
    const centerY = height >> 1;

    let applyFisheye = false, k1 = 0;
    let applyWave = false, waveAmplitude = 0, waveCount = 0, waveDirection = 'horizontal';
    let applyVerticalJitter = false;
    let applySwirl = false, swirlStrength = 0, swirlCount = 0;
    let applyShake = false, shakeAmplitude = 0, shakeFrequency = 0;
    let applyInfiniteScroll = false, scrollDirection = 'horizontal', scrollPixelsPerSecondX = 0, scrollPixelsPerSecondY = 0;
    let applySkew = false, skewMode = 'eraser', skewMaxPixels = 20, skewStripeHeight = Math.max(8, Math.floor(height / 30));
    let applyInvert = false, applyHueShift = false, hueShiftDegrees = 0, applyGMajor4 = false, applyGreenTint = false;
    let applyNavynus = false, applyBraxtonsFisheye = false;
    let applySmoothSampling = false, applyAspectPinchPunch = false;
    let applyVhs = false, applyMirrorLR = false, applyMirrorRight = false, applyFlip = false, applySwapRGB = false;
    let applyXGradientMap = false;
    let applyGreenGradientMap = false;
    let applyWhiteBlackWhiteMap = false;
    let applyMinus44Gradient = false, applyFortyFourDxiSpotGradient = false;
    let applyTVSimulator = false, tvStrength = 0;
    // Ensure saturation-related flags exist to avoid runtime ReferenceError (used in some case branches)
    let applySaturationBoost = false, saturationBoostValue = 0;
    // Lab-based luminosity inversion flag (used e.g. by G Major 42)
    let applyLumInvert = false;

    const speedFactor = 1.0; 

    // Previously the code forced most effects to be deterministic across loops by resetting
    // loopIndex/currentPower; to allow full re-rendering and compounding per export pass,
    // we no longer reset loopIndex here. Keep the original loopIndex as the exportLoopIndex.
    const exportLoopIndex = loopIndex;

    switch (effectType) {
        case 'normal':
            break;

        case 'gmajor4':
            applyGMajor4 = true;
            break;

        case 'gmajor7':
        case 'normal_g_major_7':
            applyInvert = ((loopIndex + 1) % 2 !== 0);
            break;

        case 'luiggroup':
            applyHueShift = true;
            hueShiftDegrees = -54 * (loopIndex + 1);
            break;

        case 'gmajor74':
            // Perceptual lightness inversion with VEGAS-style center-out punch.
            applyLumInvert = true;
            applyAspectPinchPunch = true;
            applySmoothSampling = true;
            // Grow the visual warp with each render/power pass.
            k1 = 0.5 * (loopIndex + 1);
            break;

        case 'braxtons_gmajor_74':
            // Recursive Re-render implementation for Braxtons G Major 74
            // Inversion alternates every pass
            applyInvert = ((loopIndex + 1) % 2 !== 0);
            // Hue shift accumulates 180 degrees every pass
            applyHueShift = true;
            hueShiftDegrees = 180 * (loopIndex + 1);
            // fisheye disabled
            applyFisheye = false;
            k1 = 0;
            break;

        case 'braxtons_gmajor_28':
            // Cumulative re-render for Braxtons G Major 28
            applyHueShift = true; 
            hueShiftDegrees = 25 * (loopIndex + 1);
            applyFlip = (loopIndex % 2 === 0);
            applySwirl = true; 
            swirlStrength = -0.5 * (loopIndex + 1); 
            swirlCount = 0;
            break;

        case 'crying':
            if (loopIndex % 2 === 0) applyInvert = true;
            applyHueShift = true;
            hueShiftDegrees = -155 * (loopIndex + 1);
            applyWave = true;
            waveDirection = 'vertical';
            waveCount = 5;
            waveAmplitude = 5 * (loopIndex + 1);
            break;

        case 'gmajor5':
            // Cumulative re-render for G Major 5 (fisheye disabled)
            applyFisheye = false;
            k1 = 0;
            applyGreenTint = true;
            if (loopIndex % 2 !== 0) applyInvert = true;
            break;

        case 'wigglem major':
            // Cumulative re-render for Wiggle Major
            applyHueShift = true;
            hueShiftDegrees = -15 * (loopIndex + 1);
            applyWave = true;
            waveDirection = 'both';
            waveCount = 1 + loopIndex;
            waveAmplitude = 15 + (5 * loopIndex);
            break;

        case 'navynusmajor':
            // Cumulative re-render for Navynus Major
            applyNavynus = true;
            applyHueShift = true;
            hueShiftDegrees = 10 * loopIndex;
            if (loopIndex > 0) applyShake = true, shakeAmplitude = 5 * loopIndex, shakeFrequency = 5;
            break;

        case 'dxi':
            if (loopIndex % 2 === 0) applyInvert = true;
            applyHueShift = true;
            hueShiftDegrees = 15;
            applySwirl = true;
            swirlStrength = -0.1;
            applyShake = true;
            shakeAmplitude = 10;
            shakeFrequency = 7;
            // saturation adjustments disabled per user preference
            break;

        case 'gmajor90v3':
            applyHueShift = true;
            hueShiftDegrees = -15;
            break;

        case 'pika_major':
            // Cumulative re-render for Pika Major
            applyHueShift = true; 
            hueShiftDegrees = 25 * (loopIndex + 1);
            applySaturationBoost = true; 
            saturationBoostValue = 1;
            // Flip on every render pass (alternates per loop)
            applyFlip = ((loopIndex + 1) % 2 !== 0);
            break;

        case 'haha_major':
            // Cumulative re-render for Haha Major (Speed increases)
            applyInfiniteScroll = true;
            scrollDirection = 'horizontal';
            scrollPixelsPerSecondX = width * speedFactor * (1 + (loopIndex * 0.5));
            if (loopIndex > 0) {
                applyHueShift = true;
                hueShiftDegrees = 45 * loopIndex;
            }
            break;

        case 'haha_major_3_0':
            // Cumulative re-render for Haha Major 3.0 (Speed increases)
            applyInfiniteScroll = true;
            scrollDirection = 'vertical';
            scrollPixelsPerSecondY = height * speedFactor * (1 + (loopIndex * 0.5));
            if (loopIndex > 0) {
                applyInvert = (loopIndex % 2 !== 0);
            }
            break;

        case 'h_major_9003':
            applyInvert = ((loopIndex + 1) % 2 !== 0);
            applyHueShift = true;
            hueShiftDegrees = -179 * (loopIndex + 1);
            break;

        case 'g_major_15':
            applyWave = true;
            waveDirection = 'vertical';
            waveCount = 5;
            waveAmplitude = 15 * (loopIndex + 1);
            break;

        case 'j_major_9009':
            applyInvert = true;
            applyWave = true;
            waveDirection = 'vertical';
            waveCount = 5;
            waveAmplitude = 6;
            applySkew = true;
            skewMode = 'eraser';
            skewMaxPixels = Math.max(10, Math.round(width * 0.03));
            skewStripeHeight = Math.max(8, Math.floor(height / 28));
            break;

        case 'g_major_5xp':
            applyInvert = true;
            applyHueShift = true;
            hueShiftDegrees = -179;
            applyVhs = true;
            applyMirrorLR = true;
            break;

        case 'g_major_1':
            applyInvert = ((loopIndex + 1) % 2 !== 0);
            applyHueShift = true;
            hueShiftDegrees = 180 * (loopIndex + 1);
            break;

        case 'g_major_137':
            // Recursive Re-render implementation for G Major 137
            // Every 'power' pass (loopIndex) reapplies the visual logic.
            
            // Inversion alternates every render pass
            applyInvert = ((loopIndex + 1) % 2 !== 0);
            
            // Hue shifts 180 degrees every render pass
            applyHueShift = true;
            hueShiftDegrees = 180 * (loopIndex + 1);
            
            // RGB -> BGR swap alternates every render pass
            applySwapRGB = ((loopIndex + 1) % 2 !== 0);
            
            // fisheye disabled for this effect
            applyFisheye = false;
            k1 = 0;
            break;

        case 'g_major_42':
            // G Major 42 visuals: RGB swap -> Lab-based luminosity inversion -> hue shift 180°
            // Note: actual per-pixel order is implemented specially in the main loop for determinism.
            applySwapRGB = false;
            applyHueShift = false;
            applyLumInvert = false;
            applyFisheye = false;
            k1 = 0;
            break;

        case 'g_minor_305':
            // Visual rules for G Minor 305: cumulative hue growth (fisheye disabled) and modest saturation
            applyHueShift = true;
            hueShiftDegrees = 120 * (loopIndex + 1); // increase hue by 120° every power
            applyFisheye = false;
            k1 = 0;
            // saturation adjustments disabled per user preference
            break;

        case 'x_major_159':
            // X Major 159: apply a fixed gradient map (white -> pink -> black)
            // Gradient mapping happens after all other color ops using luminance.
            applyXGradientMap = true;
            // No fisheye or extra spatial distortion
            applyFisheye = false;
            k1 = 0;
            break;

        case 'x_major_159_better':
            // X Major 159 but better:
            // - Re-apply the gradient map on every power (handled by not resetting loopIndex earlier)
            // - Use magenta (stronger pink) as center stop to give a punchier map
            applyXGradientMap = true;
            // No fisheye or extra spatial distortion for this variant
            applyFisheye = false;
            k1 = 0;
            break;

        case '89_dxi':
            applyGreenGradientMap = true;
            applyTVSimulator = true;
            tvStrength = 0.9225;
            applyWave = true;
            waveDirection = 'vertical';
            waveCount = 5;
            waveAmplitude = 6 * tvStrength;
            applyFisheye = false;
            k1 = 0;
            break;

        case '91_dxi':
            applyInvert = true;
            applyHueShift = true;
            hueShiftDegrees = 60 * (loopIndex + 1);
            applySaturationBoost = true;
            saturationBoostValue = 0.3 * (loopIndex + 1);
            applyVerticalJitter = true;
            break;

        case 'a_major':
            applyInvert = true;
            applyHueShift = true;
            hueShiftDegrees = 150 * (loopIndex + 1);
            applyMirrorRight = true;
            applySwirl = true;
            swirlStrength = 0.130;
            break;

        case 'baarenchromes_g_major_1':
            applyLumInvert = true;
            applyMirrorLR = true;
            applySwirl = true;
            swirlStrength = 0.2;
            break;

        case 'g_major_25':
            applyHueShift = true;
            hueShiftDegrees = -50 * (loopIndex + 1);
            break;

        case 'simulator_v19':
            applyInvert = true;
            applyHueShift = true;
            hueShiftDegrees = -60 * (loopIndex + 1);
            applyWave = true;
            waveDirection = 'both';
            waveCount = 1 + loopIndex;
            waveAmplitude = 15 + 5 * loopIndex;
            break;

        case 'tbwve571_g_major_84':
            applySwapRGB = true;
            applyHueShift = true;
            hueShiftDegrees = 25 * (loopIndex + 1);
            break;

        case 'g_major_225':
            applySwapRGB = true;
            applyHueShift = true;
            hueShiftDegrees = -180 * (loopIndex + 1);
            break;

        case 'g_major_576':
            applyInvert = true;
            applyFlip = true;
            break;

        case 'g_major_16':
            applyInvert = true;
            applyHueShift = true;
            hueShiftDegrees = -120 * (loopIndex + 1);
            applyFlip = true;
            break;

        case 'not_scary':
            applyHueShift = true;
            hueShiftDegrees = -180 * (loopIndex + 1);
            applyMirrorRight = true;
            applyTVSimulator = true;
            tvStrength = 0.75;
            break;

        case 'white_black_white':
            applyWhiteBlackWhiteMap = true;
            break;

        case 'nothandlebacks_g_major_5':
            applyHueShift = true;
            hueShiftDegrees = 180 * (loopIndex + 1);
            applyTVSimulator = true;
            tvStrength = 0.75;
            applyMirrorLR = true;
            break;

        case 'usatve2004_g_major_32':
            applyInvert = true;
            applySwapRGB = true;
            applyHueShift = true;
            hueShiftDegrees = 180 * (loopIndex + 1);
            applyMirrorLR = true;
            break;

        case 'custom_major_3':
            applyHueShift = true;
            hueShiftDegrees = 170 * (loopIndex + 1);
            applyMirrorLR = true;
            break;

        case 'caught_a_cold':
            applyInvert = true;
            applyHueShift = true;
            hueShiftDegrees = 180 * (loopIndex + 1);
            applyLumInvert = true;
            break;

        case 'lost_effect':
            applyHueShift = true;
            hueShiftDegrees = 180 * (loopIndex + 1);
            break;

        case 'minus44_dxi':
            applyMinus44Gradient = true;
            applySwirl = true;
            swirlStrength = -2.65;
            applyMirrorRight = true;
            break;

        case '44_dxi_spot':
            applyFortyFourDxiSpotGradient = true;
            applySwirl = true;
            swirlStrength = -0.047;
            applyMirrorLR = true;
            break;

        case 'custom':
            // Respect custom params but do not apply fisheye
            applyFisheye = false;
            k1 = 0;
            applyHueShift = true;
            hueShiftDegrees = (customParams.hueShift || 0) * (loopIndex + 1);
            applyInvert = customParams.invert && ((loopIndex + 1) % 2 !== 0);
            break;
    }

    const continuousTimeForScroll = 
        (typeof frameTime === 'number' ? frameTime : 0) + 
        (exportLoopIndex > 0 && isFinite(videoDurationSec) ? exportLoopIndex * videoDurationSec : 0);

    if (applyInfiniteScroll) {
        const offsetX = scrollDirection === 'horizontal' ? (continuousTimeForScroll * scrollPixelsPerSecondX) : 0;
        const offsetY = scrollDirection === 'vertical' ? (continuousTimeForScroll * scrollPixelsPerSecondY) : 0;

        for (let y = 0; y < height; y++) {
            let srcY = (y + offsetY) % height;
            if (srcY < 0) srcY += height;
            const srcYInt = srcY | 0;
            const srcRowOffset = srcYInt * width;
            const destRowOffset = y * width;
            
            for (let x = 0; x < width; x++) {
                let srcX = (x + offsetX) % width;
                if (srcX < 0) srcX += width;
                const srcXInt = srcX | 0;
                new32[destRowOffset + x] = original32[srcRowOffset + srcXInt];
            }
        }
        return cachedImageData;
    }

    const t = (typeof frameTime === 'number' ? frameTime : 0);
    
    // Reuse or create noise buffer for VHS
    if (applyVhs) {
        if (!noiseBuffer || noiseBuffer.length !== height) {
            noiseBuffer = new Float32Array(height);
        }
        for (let y = 0; y < height; y++) {
            const seed = (Math.sin(y * 12.9898 + t * 78.233) * 43758.5453) % 1;
            noiseBuffer[y] = seed - (seed | 0);
        }
    }

    // Pre-calculate spatial effect variables to speed up inner loop
    const halfWidth = width / 2;
    const halfHeight = height / 2;
    const maxDist = Math.sqrt(centerX * centerX + centerY * centerY);
    const waveFreqY = 2 * Math.PI * waveCount / height;
    const waveFreqX = 2 * Math.PI * waveCount / width;
    const swirlAngleMultiplier = swirlCount > 0 ? swirlCount * 2 * Math.PI : swirlStrength;
    const shakeOffset = applyShake ? shakeAmplitude * Math.sin(frameTime * shakeFrequency * 6.28318) : 0;
    const verticalJitterOffset = applyVerticalJitter
        ? (Math.sin(frameTime * 2 * Math.PI * 13) * 2.8 + Math.sin(frameTime * 2 * Math.PI * 7.3) * 1.6)
        : 0;

    // Spatial + Color loop: Optimized for speed
    const isGMajor42 = effectType === 'g_major_42';
    for (let y = 0; y < height; y++) {
        let jitter = 0;
        if (applyVhs) {
            jitter = (Math.sin((t * 2.1) + y * 0.02) * 1.2) + (noiseBuffer[y] - 0.5) * 0.8;
        }

        const skewOffset = (applySkew && skewMode === 'eraser') 
            ? ((( (y % skewStripeHeight) / skewStripeHeight) * 2 ) - 1) * skewMaxPixels 
            : 0;

        const destRowOffset = y * width;
        const vhsFlicker = applyVhs ? (0.95 + 0.05 * Math.sin(t * 6.28)) : 1.0;
        const cy = applyVhs ? (y - halfHeight) / halfHeight : 0;

        for (let x = 0; x < width; x++) {
            let srcX = x + jitter + skewOffset;
            let srcY = y + shakeOffset + verticalJitterOffset;

            if (applyFlip) srcX = (width - 1) - srcX;
            if (applyMirrorLR && srcX >= halfWidth) srcX = (width - 1) - srcX;
            if (applyMirrorRight && srcX < halfWidth) srcX = (width - 1) - srcX;

            if (applyTVSimulator) {
                // A restrained CRT-style barrel bend.
                const nx = (srcX - halfWidth) / Math.max(1, halfWidth);
                const ny = (srcY - halfHeight) / Math.max(1, halfHeight);
                const bend = 0.018 * tvStrength * (nx * nx + ny * ny);
                srcX = halfWidth + nx * halfWidth * (1 + bend);
                srcY = halfHeight + ny * halfHeight * (1 + bend);
            }

            if (applyAspectPinchPunch) {
                // Normalize each axis independently so pinch/punch reaches the
                // same relative strength on portrait, landscape, and square clips.
                const nx = (srcX - halfWidth) / Math.max(1, halfWidth);
                const ny = (srcY - halfHeight) / Math.max(1, halfHeight);
                const r2 = nx * nx + ny * ny;
                const amount = k1;
                const radialInfluence = r2 / (1.0 + r2);
                // VEGAS amount > 0 is Punch: sample nearer the center so
                // center details expand outward. Negative amounts pinch inward.
                const distortion = amount >= 0
                    ? 1.0 / (1.0 + amount * radialInfluence)
                    : 1.0 + (-amount) * radialInfluence;
                srcX = halfWidth + nx * distortion * halfWidth;
                srcY = halfHeight + ny * distortion * halfHeight;
            } else if (applyBraxtonsFisheye || applyFisheye) {
                // Determine base strength. Braxtons G Major 74 uses a specific subtle barrel.
                // For others, we use the passed k1.
                let strength = applyBraxtonsFisheye ? -0.12 : k1;
                const zoom = (effectType === 'custom' && customParams.fisheyeSize) ? customParams.fisheyeSize : 1.0;
                
                // Normalize by the shorter dimension so the radial warp stays circular
                // on portrait, landscape, and square video.
                const radiusScale = Math.min(halfWidth, halfHeight);
                const nx = (srcX - halfWidth) / radiusScale;
                const ny = (srcY - halfHeight) / radiusScale;
                const r2 = nx * nx + ny * ny;
                // Negative strength reverses the previous warp direction. Keep its
                // radial growth bounded so portrait and ultrawide frames stay stable.
                const distortion = strength < 0
                    ? 1.0 + (-strength) * (r2 / (1.0 + r2))
                    : 1.0 / (1.0 + strength * r2);
                const factor = distortion * (1.0 / zoom);
                srcX = halfWidth + nx * factor * radiusScale;
                srcY = halfHeight + ny * factor * radiusScale;
            }

            if (applyWave) {
                if (waveDirection === 'horizontal' || waveDirection === 'both') srcX += waveAmplitude * Math.sin(srcY * waveFreqY);
                if (waveDirection === 'vertical' || waveDirection === 'both') srcY += waveAmplitude * Math.sin(srcX * waveFreqX);
            }

            if (applySwirl) {
                const dx = srcX - centerX, dy = srcY - centerY;
                const distance = Math.sqrt(dx * dx + dy * dy);
                const angle = Math.atan2(dy, dx) + (distance / maxDist) * swirlAngleMultiplier;
                srcX = centerX + distance * Math.cos(angle);
                srcY = centerY + distance * Math.sin(angle);
            }

            const ix = (srcX + 0.5) | 0;
            const iy = (srcY + 0.5) | 0;
            const safeX = ix < 0 ? 0 : (ix >= width ? width - 1 : ix);
            const safeY = iy < 0 ? 0 : (iy >= height ? height - 1 : iy);
            const srcIdx = (safeY * width + safeX) << 2;

            let r, g, b, a;
            if (applySmoothSampling) {
                // Bilinear resampling removes the jagged pixel stair-stepping of the warp.
                const x0 = Math.max(0, Math.min(width - 1, Math.floor(srcX)));
                const y0 = Math.max(0, Math.min(height - 1, Math.floor(srcY)));
                const x1 = Math.min(width - 1, x0 + 1);
                const y1 = Math.min(height - 1, y0 + 1);
                const fx = Math.max(0, Math.min(1, srcX - Math.floor(srcX)));
                const fy = Math.max(0, Math.min(1, srcY - Math.floor(srcY)));
                const i00 = (y0 * width + x0) << 2, i10 = (y0 * width + x1) << 2;
                const i01 = (y1 * width + x0) << 2, i11 = (y1 * width + x1) << 2;
                const blend = channel => {
                    const top = originalPixels[i00 + channel] * (1 - fx) + originalPixels[i10 + channel] * fx;
                    const bottom = originalPixels[i01 + channel] * (1 - fx) + originalPixels[i11 + channel] * fx;
                    return top * (1 - fy) + bottom * fy;
                };
                r = blend(0); g = blend(1); b = blend(2); a = blend(3);
            } else {
                r = originalPixels[srcIdx];
                g = originalPixels[srcIdx + 1];
                b = originalPixels[srcIdx + 2];
                a = originalPixels[srcIdx + 3];
            }

            if (applyVhs) {
                const xR = (srcX + 1.5) | 0, xB = (srcX - 0.5) | 0;
                const sXR = xR < 0 ? 0 : (xR >= width ? width - 1 : xR);
                const sXB = xB < 0 ? 0 : (xB >= width ? width - 1 : xB);
                r = originalPixels[(safeY * width + sXR) << 2];
                g = originalPixels[srcIdx + 1];
                b = originalPixels[((safeY * width + sXB) << 2) + 2];
            } else {
                r = originalPixels[srcIdx];
                g = originalPixels[srcIdx + 1];
                b = originalPixels[srcIdx + 2];
            }

            // SPECIAL CASE: G Major 42 exact pipeline (RGB swap -> Lab lightness invert -> hue +180),
            // completely independent of power/loop so visuals stay identical in every power.
            if (isGMajor42) {
                // 1) RGB swap (BGR)
                let rr = b, gg = g, bb = r;

                // 2) Lab-based luminosity inversion
                try {
                    [rr, gg, bb] = invertLabLightnessPreserveChroma(
                        Math.max(0, Math.min(255, Math.round(rr))),
                        Math.max(0, Math.min(255, Math.round(gg))),
                        Math.max(0, Math.min(255, Math.round(bb)))
                    );
                } catch (e) {
                    // Fallback: simple HSL lightness inversion if Lab path fails
                    const [hh0, ss0, ll0] = rgbToHsl(
                        Math.max(0, Math.min(255, Math.round(rr))),
                        Math.max(0, Math.min(255, Math.round(gg))),
                        Math.max(0, Math.min(255, Math.round(bb)))
                    );
                    const invL0 = 1 - ll0;
                    [rr, gg, bb] = hslToRgb(hh0, ss0, invL0);
                }

                // 3) Hue shift +180°
                let [hh, ss, ll] = rgbToHsl(rr, gg, bb);
                hh = shiftHue(hh, 180);
                [rr, gg, bb] = hslToRgb(hh, ss, ll);

                const di42 = destRowOffset + x;
                newPixels[di42 << 2]     = rr < 0 ? 0 : (rr > 255 ? 255 : rr);
                newPixels[(di42 << 2)+1] = gg < 0 ? 0 : (gg > 255 ? 255 : gg);
                newPixels[(di42 << 2)+2] = bb < 0 ? 0 : (bb > 255 ? 255 : bb);
                newPixels[(di42 << 2)+3] = a;
                continue;
            }

            if (applyHueShift) {
                let [h, s, l] = rgbToHsl(r, g, b);
                h = shiftHue(h, hueShiftDegrees);
                [r, g, b] = hslToRgb(h, s, l);
            }

            if (applyInvert) { r = 255 - r; g = 255 - g; b = 255 - b; }

            if (applySaturationBoost) {
                let [satH, satS, satL] = rgbToHsl(r, g, b);
                satS = Math.min(1, satS + saturationBoostValue);
                [r, g, b] = hslToRgb(satH, satS, satL);
            }

            if (applyGreenTint) { r *= 0.9; g *= 1.1; b *= 0.9; }

            if (applyGMajor4) {
                // Use luminance to accurately detect all "white" and bright areas (including bright yellows/cyans)
                const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
                if (lum > 190) { r = 0; g = 0; b = 0; }
            }

            if (applyNavynus) {
                const luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
                if (luminance < 30) { r = 0; g = 0; b = 0; }
                else {
                    r = 0; g = 0;
                    b = Math.max(50, Math.min(100, Math.round(50 + (luminance - 30) * 50 / 225)));
                }
            }

            if (applyVhs) {
                const dim = (y & 1) ? 0.88 : 1.0;
                r *= vhsFlicker * dim; g *= vhsFlicker * dim; b *= vhsFlicker * dim;
                const cx = (x - halfWidth) / halfWidth;
                const vignette = Math.max(0.75, 1.0 - (cx * cx + cy * cy) * 0.25);
                r *= vignette; g *= vignette; b *= vignette;
                const n = (noiseBuffer[y] - 0.5) * 18;
                r += n; g += n * 0.8; b += n * 1.2;
            }

            if (applySwapRGB) { const tmp = r; r = b; b = tmp; }

            // Lab-based Luminosity inversion: invert perceptual L* while preserving chroma/a/b.
            // Only applied when flagged by the switch above
            if (typeof applyLumInvert !== 'undefined' && applyLumInvert) {
                try {
                    const [nr, ng, nb] = invertLabLightnessPreserveChroma(
                        Math.max(0, Math.min(255, Math.round(r))),
                        Math.max(0, Math.min(255, Math.round(g))),
                        Math.max(0, Math.min(255, Math.round(b)))
                    );
                    r = nr; g = ng; b = nb;
                } catch (e) {
                    // Fallback to simple HSL inversion if Lab path fails
                    const [hh, ss, ll] = rgbToHsl(
                        Math.max(0, Math.min(255, Math.round(r))),
                        Math.max(0, Math.min(255, Math.round(g))),
                        Math.max(0, Math.min(255, Math.round(b)))
                    );
                    const invL = 1 - ll;
                    const [nr, ng, nb] = hslToRgb(hh, ss, invL);
                    r = nr; g = ng; b = nb;
                }
            }

            // X Major 159 gradient map: map luminance to a 3-point gradient
            // control points: white (0) -> pink (0.5) -> black (1)
            if (applyXGradientMap) {
                const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
                let t = lum / 255;
                if (t < 0) t = 0;
                if (t > 1) t = 1;

                // Define gradient stops
                const white = [255, 255, 255];
                const pink = [255, 105, 180];
                const black = [0, 0, 0];

                let nr, ng, nb;
                if (t <= 0.5) {
                    const u = t / 0.5; // 0..1 from white to pink
                    nr = white[0] + (pink[0] - white[0]) * u;
                    ng = white[1] + (pink[1] - white[1]) * u;
                    nb = white[2] + (pink[2] - white[2]) * u;
                } else {
                    const u = (t - 0.5) / 0.5; // 0..1 from pink to black
                    nr = pink[0] + (black[0] - pink[0]) * u;
                    ng = pink[1] + (black[1] - pink[1]) * u;
                    nb = pink[2] + (black[2] - pink[2]) * u;
                }
                r = nr; g = ng; b = nb;
            }

            if (applyWhiteBlackWhiteMap) {
                const lum = Math.max(0, Math.min(1, (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255));
                if (lum <= 0.5) {
                    const v = 255 * (1 - lum * 2);
                    r = v; g = v; b = v;
                } else {
                    const v = 255 * ((lum - 0.5) * 2);
                    r = v; g = v; b = v;
                }
            }

            if (applyMinus44Gradient) {
                const t = Math.max(0, Math.min(1, (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255));
                const position = t * (MINUS44_DXI_GRADIENT.length - 1);
                const stop = Math.min(MINUS44_DXI_GRADIENT.length - 2, Math.floor(position));
                const mix = position - stop;
                const c0 = MINUS44_DXI_GRADIENT[stop], c1 = MINUS44_DXI_GRADIENT[stop + 1];
                r = c0[0] + (c1[0] - c0[0]) * mix;
                g = c0[1] + (c1[1] - c0[1]) * mix;
                b = c0[2] + (c1[2] - c0[2]) * mix;
            }

            if (applyFortyFourDxiSpotGradient) {
                const t = Math.max(0, Math.min(1, (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255));
                const position = t * (FORTYFOUR_DXI_SPOT_GRADIENT.length - 1);
                const stop = Math.min(FORTYFOUR_DXI_SPOT_GRADIENT.length - 2, Math.floor(position));
                const mix = position - stop;
                const c0 = FORTYFOUR_DXI_SPOT_GRADIENT[stop], c1 = FORTYFOUR_DXI_SPOT_GRADIENT[stop + 1];
                r = c0[0] + (c1[0] - c0[0]) * mix;
                g = c0[1] + (c1[1] - c0[1]) * mix;
                b = c0[2] + (c1[2] - c0[2]) * mix;
                a = c0[3] + (c1[3] - c0[3]) * mix;
            }

            if (applyGreenGradientMap) {
                // Luminance 0 = green, midpoint = white, luminance 1 = black.
                const lum = Math.max(0, Math.min(1, (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255));
                if (lum <= 0.5) {
                    const u = lum * 2;
                    r = 255 * u; g = 255; b = 255 * u;
                } else {
                    const u = (lum - 0.5) * 2;
                    r = 255 * (1 - u); g = 255 * (1 - u); b = 255 * (1 - u);
                }
            }

            if (applyTVSimulator) {
                const scan = (y % 2 === 0) ? 1 : (1 - 0.22 * tvStrength);
                const nx = (x - halfWidth) / Math.max(1, halfWidth);
                const ny = (y - halfHeight) / Math.max(1, halfHeight);
                const edge = 1 - 0.10 * tvStrength * Math.min(1, nx * nx + ny * ny);
                const crt = scan * edge;
                r *= crt; g *= crt; b *= crt;
            }

            const di = destRowOffset + x;
            newPixels[di << 2] = r < 0 ? 0 : (r > 255 ? 255 : r);
            newPixels[(di << 2) + 1] = g < 0 ? 0 : (g > 255 ? 255 : g);
            newPixels[(di << 2) + 2] = b < 0 ? 0 : (b > 255 ? 255 : b);
            newPixels[(di << 2) + 3] = a;
        }
    }

    return cachedImageData;
}