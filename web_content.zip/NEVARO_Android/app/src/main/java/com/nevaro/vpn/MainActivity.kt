package com.nevaro.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.ByteArrayInputStream
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var backend: GoBackend
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var importedConfig: Config? = null
    @Volatile private var currentState = Tunnel.State.DOWN

    private val tunnel = NevaroTunnel { state ->
        currentState = state
        runOnUiThread {
            val jsState = when (state) {
                Tunnel.State.UP -> "connected"
                Tunnel.State.TOGGLE -> "connecting"
                else -> "disconnected"
            }
            web.evaluateJavascript("window.nevaroNativeState('$jsState')", null)
        }
    }

    private val configPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) {
            sendMessage("فایلی انتخاب نشد")
            return@registerForActivityResult
        }
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalArgumentException("فایل قابل خواندن نیست")
            val parsed = Config.parse(ByteArrayInputStream(bytes))
            importedConfig = parsed
            sendMessage("فایل تنظیمات WireGuard با موفقیت خوانده شد")
            web.evaluateJavascript("window.nevaroConfigReady(true)", null)
        } catch (e: Exception) {
            importedConfig = null
            sendMessage("فایل تنظیمات معتبر نیست: ${safeJsText(e.message ?: "خطای نامشخص")}")
            web.evaluateJavascript("window.nevaroConfigReady(false)", null)
        }
    }

    private val vpnPermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            connectWithConfig()
        } else {
            sendMessage("اجازه‌ی VPN داده نشد")
            publishState("disconnected")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backend = GoBackend(applicationContext)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = false
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(NativeBridge(), "NevaroVpn")
        web.loadUrl("file:///android_asset/index.html")
    }

    private inner class NativeBridge {
        @JavascriptInterface fun importConfig() {
            runOnUiThread { configPicker.launch(arrayOf("*/*")) }
        }

        @JavascriptInterface fun connect() {
            runOnUiThread {
                if (importedConfig == null) {
                    sendMessage("اول فایل پیکربندی WireGuard سرور خودت را وارد کن")
                    return@runOnUiThread
                }
                val prepareIntent: Intent? = VpnService.prepare(this@MainActivity)
                if (prepareIntent != null) vpnPermission.launch(prepareIntent)
                else connectWithConfig()
            }
        }

        @JavascriptInterface fun disconnect() {
            worker.execute {
                try {
                    backend.setState(tunnel, Tunnel.State.DOWN, null)
                    publishState("disconnected")
                } catch (e: Exception) {
                    sendMessage("قطع اتصال با خطا روبه‌رو شد")
                }
            }
        }

        @JavascriptInterface fun getStatus(): String =
            if (currentState == Tunnel.State.UP) "connected" else "disconnected"
    }

    private fun connectWithConfig() {
        val config = importedConfig ?: run {
            sendMessage("فایل پیکربندی انتخاب نشده است")
            return
        }
        publishState("connecting")
        worker.execute {
            try {
                backend.setState(tunnel, Tunnel.State.UP, config)
                // The tunnel callback reports the backend state. Do not fake success here.
            } catch (e: Exception) {
                publishState("disconnected")
                sendMessage("اتصال برقرار نشد: ${safeJsText(e.message ?: "خطای سرور یا تنظیمات")}")
            }
        }
    }

    private fun publishState(state: String) {
        runOnUiThread { web.evaluateJavascript("window.nevaroNativeState('$state')", null) }
    }

    private fun sendMessage(message: String) {
        val safe = safeJsText(message)
        runOnUiThread { web.evaluateJavascript("window.nevaroShowMessage('$safe')", null) }
    }

    private fun safeJsText(value: String): String =
        value.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ").replace("\r", " ")

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdown()
        web.removeJavascriptInterface("NevaroVpn")
        web.destroy()
    }
}
