package com.nevaro.vpn

import com.wireguard.android.backend.Tunnel

class NevaroTunnel(
    private val stateListener: (Tunnel.State) -> Unit
) : Tunnel {
    override fun getName(): String = "NEVARO"

    override fun onStateChange(newState: Tunnel.State) {
        stateListener(newState)
    }
}
