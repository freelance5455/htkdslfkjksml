Sensi Trick 2.0 v11
Gerador dinâmico de habilidades: 1 ativa + 3 passivas, escolhidas por função e objetivo. Inclui gerador de sensi no painel flutuante.
Base de funções/tipos conferida em fontes atuais de Free Fire; a classificação pode mudar com patches.
