// رقم واتساب بصيغة دولية بدون + أو مسافات: مصر 20 + الرقم بدون الصفر الأول
const WHATSAPP_NUMBER = "201223124400";

const products = [
  {id:1,name:"شاورما فراخ صغير",category:"شاورما",price:35,emoji:"🌯",description:"شاورما فراخ بطعم شامي"},
  {id:2,name:"شاورما فراخ كبير",category:"شاورما",price:45,emoji:"🌯",description:"حجم كبير ومشبع"},
  {id:3,name:"شاورما لحمة صغير",category:"شاورما",price:40,emoji:"🥙",description:"شاورما لحمة وتتبيلة مميزة"},
  {id:4,name:"شاورما لحمة كبير",category:"شاورما",price:55,emoji:"🥙",description:"حجم كبير"},
  {id:5,name:"فتة شاورما صغير",category:"وجبات",price:65,emoji:"🍛",description:"فتة شاورما مع الصوص"},
  {id:6,name:"فتة شاورما كبير",category:"وجبات",price:80,emoji:"🍛",description:"وجبة فتة شاورما"},
  {id:7,name:"سندوتش عربي",category:"سندوتشات",price:35,emoji:"🥪",description:"سندوتش على الطريقة الشامية"},
  {id:8,name:"سندوتش فرنجي",category:"سندوتشات",price:30,emoji:"🥖",description:"سندوتش شهي"},
  {id:9,name:"سندوتش بطاطس",category:"سندوتشات",price:20,emoji:"🍟",description:"بطاطس وصوص حسب الاختيار"},
  {id:10,name:"بطاطس صغير",category:"مقبلات",price:15,emoji:"🍟",description:"بطاطس مقرمشة"},
  {id:11,name:"بطاطس كبير",category:"مقبلات",price:25,emoji:"🍟",description:"حجم كبير للمشاركة"},
  {id:12,name:"ثومية",category:"مقبلات",price:10,emoji:"🥣",description:"صوص الثومية"},
  {id:13,name:"مخلل",category:"مقبلات",price:7,emoji:"🥒",description:"مخلل مشكل"},
  {id:14,name:"وجبة شاورما عربي",category:"وجبات",price:75,emoji:"🍽️",description:"وجبة شاورما مع الإضافات"},
  {id:15,name:"وجبة شاورما فراخ",category:"وجبات",price:85,emoji:"🍽️",description:"وجبة فراخ مشبعة"}
];

const categories = ["الكل", ...new Set(products.map(p => p.category))];
let activeCategory = "الكل";
let cart = {};

const menuEl = document.getElementById("menu");
const categoriesEl = document.getElementById("categories");
const searchEl = document.getElementById("search");

function money(n){ return `${n} جنيه`; }

function renderCategories(){
  categoriesEl.innerHTML = "";
  categories.forEach(category => {
    const btn = document.createElement("button");
    btn.className = `category-btn${category === activeCategory ? " active" : ""}`;
    btn.textContent = category;
    btn.type = "button";
    btn.addEventListener("click", () => { activeCategory = category; renderCategories(); renderMenu(); });
    categoriesEl.appendChild(btn);
  });
}

function renderMenu(){
  const term = searchEl.value.trim().toLowerCase();
  const filtered = products.filter(p =>
    (activeCategory === "الكل" || p.category === activeCategory) &&
    (p.name.toLowerCase().includes(term) || p.category.toLowerCase().includes(term) || p.description.toLowerCase().includes(term))
  );
  menuEl.innerHTML = "";
  if(!filtered.length){ menuEl.innerHTML = '<p class="empty-cart">مفيش أصناف مطابقة للبحث.</p>'; return; }
  filtered.forEach(p => {
    const card = document.createElement("article");
    card.className = "food-card";
    card.innerHTML = `<div class="food-emoji" aria-hidden="true">${p.emoji}</div>
      <h3>${p.name}</h3><p class="description">${p.description}</p>
      <div class="card-bottom"><span class="price">${money(p.price)}</span><button class="add-btn" type="button">+ أضف</button></div>`;
    card.querySelector("button").addEventListener("click", () => {
      cart[p.id] = (cart[p.id] || 0) + 1;
      renderCart();
    });
    menuEl.appendChild(card);
  });
}

function renderCart(){
  const el = document.getElementById("cart-items");
  const ids = Object.keys(cart).filter(id => cart[id] > 0);
  const count = ids.reduce((sum,id) => sum + cart[id], 0);
  document.getElementById("cart-count").textContent = `${count} صنف`;
  const total = ids.reduce((sum,id) => sum + products.find(p => p.id === Number(id)).price * cart[id], 0);
  document.getElementById("total").textContent = money(total);
  if(!ids.length){ el.innerHTML = '<p class="empty-cart">لسه ما اخترتش أي حاجة من المنيو.</p>'; return; }
  el.innerHTML = "";
  ids.forEach(id => {
    const p = products.find(item => item.id === Number(id));
    const row = document.createElement("div");
    row.className = "cart-row";
    row.innerHTML = `<div><span class="cart-name">${p.name}</span><span class="cart-sub">${money(p.price * cart[id])}</span></div>
      <div class="qty-control"><button type="button" aria-label="تقليل الكمية">−</button><strong>${cart[id]}</strong><button type="button" aria-label="زيادة الكمية">+</button></div>
      <button class="remove-btn" type="button" aria-label="حذف الصنف">×</button>`;
    const buttons = row.querySelectorAll(".qty-control button");
    buttons[0].addEventListener("click", () => { cart[id]--; if(cart[id] <= 0) delete cart[id]; renderCart(); });
    buttons[1].addEventListener("click", () => { cart[id]++; renderCart(); });
    row.querySelector(".remove-btn").addEventListener("click", () => { delete cart[id]; renderCart(); });
    el.appendChild(row);
  });
}

document.getElementById("whatsapp-order").addEventListener("click", () => {
  const ids = Object.keys(cart).filter(id => cart[id] > 0);
  const status = document.getElementById("status");
  if(!ids.length){ status.textContent = "اختار صنف واحد على الأقل الأول."; return; }
  const name = document.getElementById("customer-name").value.trim();
  const address = document.getElementById("customer-address").value.trim();
  const notes = document.getElementById("customer-notes").value.trim();
  const total = ids.reduce((sum,id) => sum + products.find(p => p.id === Number(id)).price * cart[id], 0);
  let message = "السلام عليكم، عايز أطلب من البراء الدمشقي:\n\n";
  ids.forEach(id => {
    const p = products.find(item => item.id === Number(id));
    message += `• ${p.name} × ${cart[id]} = ${p.price * cart[id]} جنيه\n`;
  });
  message += `\nالإجمالي التقريبي: ${total} جنيه`;
  if(name) message += `\nالاسم: ${name}`;
  if(address) message += `\nالعنوان: ${address}`;
  if(notes) message += `\nملاحظات: ${notes}`;
  message += "\n\nمن فضلك أكد السعر ووقت التوصيل.";
  const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
  window.open(url, "_blank", "noopener,noreferrer");
  status.textContent = "اتفتح واتساب برسالة الطلب؛ راجعها واضغط إرسال.";
});

document.getElementById("clear-cart").addEventListener("click", () => {
  cart = {};
  renderCart();
  document.getElementById("status").textContent = "تم إفراغ الطلب.";
});

searchEl.addEventListener("input", renderMenu);
renderCategories();
renderMenu();
renderCart();
