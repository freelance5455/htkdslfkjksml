// رقم واتساب بصيغة دولية بدون + أو مسافات: مصر 20 + الرقم بدون الصفر الأول
const WHATSAPP_NUMBER = "201223124400";
const WHATSAPP_NUMBER_SECOND = "201031500130";

const ADMIN_PASSWORD = "albaraalsory123";
const MENU_STORAGE_KEY = "albaraaDamashqiMenuV1";

const defaultProducts = [
  {id:1,name:"شاورما فراخ صغير",category:"شاورما",price:35,emoji:"🌯",description:"شاورما فراخ بطعم شامي"},
  {id:2,name:"شاورما فراخ كبير",category:"شاورما",price:45,emoji:"🌯",description:"حجم كبير ومشبع"},
  {id:3,name:"شاورما لحمة صغير",category:"شاورما",price:40,emoji:"🥙",description:"شاورما لحمة وتتبيلة مميزة"},
  {id:4,name:"شاورما لحمة كبير",category:"شاورما",price:55,emoji:"🥙",description:"حجم كبير"},
  {id:5,name:"فتة شاورما صغير",category:"وجبات",price:65,emoji:"🍛",description:"فتة شاورما مع الصوص"},
  {id:6,name:"فتة شاورما كبير",category:"وجبات",price:80,emoji:"🍛",description:"وجبة فتة شاورما"},
  {id:7,name:"سندوتش عربي",category:"سندوتشات",price:35,emoji:"🥪",description:"سندوتش على الطريقة الشامية"},
  {id:8,name:"سندوتش فرنجي",category:"سندوتشات",price:30,emoji:"🥖",description:"سندوتش شهي"},
  {id:9,name:"سندوتش بطاطس",category:"سندوتشات",price:20,emoji:"🍟",description:"بطاطس وصوص حسب الاختيار"},
  {id:10,name:"بطاطس صغير",category:"مقبلات",price:15,emoji:"🍟",description:"بطاطس مقرمشة"},
  {id:11,name:"بطاطس كبير",category:"مقبلات",price:25,emoji:"🍟",description:"حجم كبير للمشاركة"},
  {id:12,name:"ثومية",category:"مقبلات",price:10,emoji:"🥣",description:"صوص الثومية"},
  {id:13,name:"مخلل",category:"مقبلات",price:7,emoji:"🥒",description:"مخلل مشكل"},
  {id:14,name:"وجبة شاورما عربي",category:"وجبات",price:75,emoji:"🍽️",description:"وجبة شاورما مع الإضافات"},
  {id:15,name:"وجبة شاورما فراخ",category:"وجبات",price:85,emoji:"🍽️",description:"وجبة فراخ مشبعة"}
 ];
function loadMenu(){try{const saved=localStorage.getItem(MENU_STORAGE_KEY);if(saved){const parsed=JSON.parse(saved);if(Array.isArray(parsed)&&parsed.length)return parsed;}}catch(e){}return defaultProducts.map(p=>({...p}));}
let products=loadMenu();
function saveMenu(){try{localStorage.setItem(MENU_STORAGE_KEY,JSON.stringify(products));}catch(e){}}
let nextProductId=Math.max(0,...products.map(p=>Number(p.id)||0))+1;
let categories = ["الكل", ...new Set(products.map(p => p.category))];
let activeCategory = "الكل";
let cart = {};

const menuEl = document.getElementById("menu");
const categoriesEl = document.getElementById("categories");
const searchEl = document.getElementById("search");

function money(n){ return `${n} جنيه`; }

function renderCategories(){
  categoriesEl.innerHTML = "";
  categories.forEach(category => {
    const btn = document.createElement("button");
    btn.className = `category-btn${category === activeCategory ? " active" : ""}`;
    btn.textContent = category;
    btn.type = "button";
    btn.addEventListener("click", () => { activeCategory = category; renderCategories(); renderMenu(); });
    categoriesEl.appendChild(btn);
  });
}

function renderMenu(){
  const term = searchEl.value.trim().toLowerCase();
  const filtered = products.filter(p =>
    (activeCategory === "الكل" || p.category === activeCategory) &&
    (p.name.toLowerCase().includes(term) || p.category.toLowerCase().includes(term) || p.description.toLowerCase().includes(term))
  );
  menuEl.innerHTML = "";
  if(!filtered.length){ menuEl.innerHTML = '<p class="empty-cart">مفيش أصناف مطابقة للبحث.</p>'; return; }
  filtered.forEach(p => {
    const card = document.createElement("article");
    card.className = "food-card";
    card.innerHTML = `<div class="food-emoji" aria-hidden="true">${p.emoji}</div>
      <h3>${p.name}</h3><p class="description">${p.description}</p>
      <div class="card-bottom"><span class="price">${money(p.price)}</span><button class="add-btn" type="button">+ أضف</button></div>`;
    card.querySelector("button").addEventListener("click", () => {
      cart[p.id] = (cart[p.id] || 0) + 1;
      renderCart();
    });
    menuEl.appendChild(card);
  });
}

function renderCart(){
  const el = document.getElementById("cart-items");
  const ids = Object.keys(cart).filter(id => cart[id] > 0);
  const count = ids.reduce((sum,id) => sum + cart[id], 0);
  document.getElementById("cart-count").textContent = `${count} صنف`;
  const total = ids.reduce((sum,id) => sum + products.find(p => p.id === Number(id)).price * cart[id], 0);
  document.getElementById("total").textContent = money(total);
  if(!ids.length){ el.innerHTML = '<p class="empty-cart">لسه ما اخترتش أي حاجة من المنيو.</p>'; return; }
  el.innerHTML = "";
  ids.forEach(id => {
    const p = products.find(item => item.id === Number(id));
    const row = document.createElement("div");
    row.className = "cart-row";
    row.innerHTML = `<div><span class="cart-name">${p.name}</span><span class="cart-sub">${money(p.price * cart[id])}</span></div>
      <div class="qty-control"><button type="button" aria-label="تقليل الكمية">−</button><strong>${cart[id]}</strong><button type="button" aria-label="زيادة الكمية">+</button></div>
      <button class="remove-btn" type="button" aria-label="حذف الصنف">×</button>`;
    const buttons = row.querySelectorAll(".qty-control button");
    buttons[0].addEventListener("click", () => { cart[id]--; if(cart[id] <= 0) delete cart[id]; renderCart(); });
    buttons[1].addEventListener("click", () => { cart[id]++; renderCart(); });
    row.querySelector(".remove-btn").addEventListener("click", () => { delete cart[id]; renderCart(); });
    el.appendChild(row);
  });
}

function sendWhatsAppOrder(phoneNumber){
  const ids = Object.keys(cart).filter(id => cart[id] > 0);
  const status = document.getElementById("status");
  if(!ids.length){ status.textContent = "اختار صنف واحد على الأقل الأول."; return; }
  const name = document.getElementById("customer-name").value.trim();
  const address = document.getElementById("customer-address").value.trim();
  const notes = document.getElementById("customer-notes").value.trim();
  const total = ids.reduce((sum,id) => sum + products.find(p => p.id === Number(id)).price * cart[id], 0);
  let message = "السلام عليكم، عايز أطلب من البراء الدمشقي:\n\n";
  ids.forEach(id => {
    const p = products.find(item => item.id === Number(id));
    message += `• ${p.name} × ${cart[id]} = ${p.price * cart[id]} جنيه\n`;
  });
  message += `\nالإجمالي التقريبي: ${total} جنيه`;
  if(name) message += `\nالاسم: ${name}`;
  if(address) message += `\nالعنوان: ${address}`;
  if(notes) message += `\nملاحظات: ${notes}`;
  message += "\n\nمن فضلك أكد السعر ووقت التوصيل.";
  // استخدم رابط HTTPS القياسي بدل whatsapp:// لتفادي خطأ UNKNOWN_URL_SCHEME.
  const url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
  const opened = window.open(url, "_blank");
  if(!opened){
    // بديل لو المتصفح منع فتح نافذة جديدة
    window.location.href = url;
  }
  status.textContent = "اتفتح رابط واتساب برسالة الطلب؛ راجع الرسالة واضغط إرسال.";
}
document.getElementById("whatsapp-order").addEventListener("click", () => sendWhatsAppOrder(WHATSAPP_NUMBER));
const secondWhatsAppButton = document.getElementById("whatsapp-order-second");
if(secondWhatsAppButton){
  secondWhatsAppButton.addEventListener("click", () => sendWhatsAppOrder(WHATSAPP_NUMBER_SECOND));
}

document.getElementById("clear-cart").addEventListener("click", () => {
  cart = {};
  renderCart();
  document.getElementById("status").textContent = "تم إفراغ الطلب.";
});

searchEl.addEventListener("input", renderMenu);

// لوحة التحكم: كلمة السر محددة في أعلى الملف باسم ADMIN_PASSWORD
const sidebar=document.getElementById("admin-sidebar"), backdrop=document.getElementById("admin-backdrop");
const loginBox=document.getElementById("admin-login"), toolsBox=document.getElementById("admin-tools");
let adminUnlocked=false;
function openAdmin(){sidebar.classList.add("open");sidebar.setAttribute("aria-hidden","false");backdrop.hidden=false;if(!adminUnlocked)setTimeout(()=>document.getElementById("admin-password").focus(),100);}
function closeAdmin(){sidebar.classList.remove("open");sidebar.setAttribute("aria-hidden","true");backdrop.hidden=true;}
document.getElementById("admin-open").addEventListener("click",openAdmin);
document.getElementById("admin-close").addEventListener("click",closeAdmin);
backdrop.addEventListener("click",closeAdmin);
function updateCategories(){categories=["الكل",...new Set(products.map(p=>p.category))];}
function refreshAdminSelect(selectedId){const select=document.getElementById("admin-product-select");select.innerHTML="";products.forEach(p=>{const o=document.createElement("option");o.value=p.id;o.textContent=`${p.name} — ${p.price} جنيه`;select.appendChild(o);});if(selectedId!=null)select.value=String(selectedId);fillAdminFields();}
function fillAdminFields(){const p=products.find(x=>x.id===Number(document.getElementById("admin-product-select").value));if(!p)return;document.getElementById("admin-product-name").value=p.name;document.getElementById("admin-product-category").value=p.category;document.getElementById("admin-product-price").value=p.price;document.getElementById("admin-product-description").value=p.description||"";document.getElementById("admin-product-emoji").value=p.emoji||"🍽️";}
function refreshAfterChange(id){saveMenu();updateCategories();activeCategory="الكل";renderCategories();renderMenu();renderCart();refreshAdminSelect(id);}
function setUnlocked(v){adminUnlocked=v;loginBox.hidden=v;toolsBox.hidden=!v;if(v)refreshAdminSelect();}
function login(){const s=document.getElementById("admin-login-status");if(document.getElementById("admin-password").value===ADMIN_PASSWORD){s.textContent="";document.getElementById("admin-password").value="";setUnlocked(true);}else{s.textContent="كلمة السر غير صحيحة.";}}
document.getElementById("admin-login-btn").addEventListener("click",login);
document.getElementById("admin-password").addEventListener("keydown",e=>{if(e.key==="Enter")login();});
document.getElementById("admin-product-select").addEventListener("change",fillAdminFields);
document.getElementById("admin-save-product").addEventListener("click",()=>{const p=products.find(x=>x.id===Number(document.getElementById("admin-product-select").value));const name=document.getElementById("admin-product-name").value.trim();const raw=document.getElementById("admin-product-price").value;const price=Number(raw);const status=document.getElementById("admin-tools-status");if(!p||!name||raw===""||!Number.isFinite(price)||price<0){status.textContent="اكتب اسمًا وسعرًا صحيحين.";return;}p.name=name;p.category=document.getElementById("admin-product-category").value;p.price=price;p.description=document.getElementById("admin-product-description").value.trim();p.emoji=document.getElementById("admin-product-emoji").value.trim()||"🍽️";refreshAfterChange(p.id);status.textContent="تم حفظ التعديلات.";});
document.getElementById("admin-delete-product").addEventListener("click",()=>{const id=Number(document.getElementById("admin-product-select").value),p=products.find(x=>x.id===id);if(!p)return;if(!confirm(`هل تريد حذف ${p.name}؟`))return;products=products.filter(x=>x.id!==id);delete cart[id];refreshAfterChange(products[0]?.id);document.getElementById("admin-tools-status").textContent="تم حذف الصنف.";});
document.getElementById("admin-add-product").addEventListener("click",()=>{const name=document.getElementById("new-product-name").value.trim(),raw=document.getElementById("new-product-price").value,price=Number(raw),status=document.getElementById("admin-tools-status");if(!name||raw===""||!Number.isFinite(price)||price<0){status.textContent="اكتب اسم الصنف وسعرًا صحيحين.";return;}const p={id:nextProductId++,name,category:document.getElementById("new-product-category").value,price,description:document.getElementById("new-product-description").value.trim(),emoji:document.getElementById("new-product-emoji").value.trim()||"🍽️"};products.push(p);document.getElementById("new-product-name").value="";document.getElementById("new-product-price").value="";document.getElementById("new-product-description").value="";document.getElementById("new-product-emoji").value="🍽️";refreshAfterChange(p.id);status.textContent="تمت إضافة الصنف.";});
document.getElementById("admin-logout").addEventListener("click",()=>{setUnlocked(false);document.getElementById("admin-login-status").textContent="تم تسجيل الخروج.";});
renderCategories();
renderMenu();
renderCart();
