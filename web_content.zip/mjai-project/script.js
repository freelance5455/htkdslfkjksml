// MJAI Hub Interactive Logic
document.addEventListener('DOMContentLoaded', () => {
    // 13 Modules configuration
    const modulesData = [
        { id: "Core AI", name: "Core AI", icon: "🧠", desc: "Neural processing & multi-step reasoning", chips: ["Explain quantum computing", "Summarize latest trends", "Solve complex logic"] },
        { id: "Voice", name: "Voice", icon: "🎙️", desc: "Speech synthesis & voice command routing", chips: ["Synthesize speech", "Listen to microphone", "Adjust pitch & speed"] },
        { id: "UI", name: "UI", icon: "🎨", desc: "Dynamic layout & theme orchestrator", chips: ["Switch accent color", "Toggle dark/light mode", "Animate components"] },
        { id: "Study", name: "Study", icon: "📚", desc: "Flashcards, quizzes, & knowledge ingestion", chips: ["Generate flashcards", "Create practice quiz", "Summarize textbook chapter"] },
        { id: "System Control", name: "System Control", icon: "⚙️", desc: "CPU, memory, & process management", chips: ["Check CPU usage", "Optimize RAM", "Restart background service"] },
        { id: "Files", name: "Files", icon: "📁", desc: "Secure indexing, search, & file vaults", chips: ["Search local docs", "Encrypt file archive", "Clean temp cache"] },
        { id: "Comm", name: "Comm", icon: "💬", desc: "Encrypted messaging & email dispatch", chips: ["Send secure ping", "Draft email reply", "Sync contact logs"] },
        { id: "Health", name: "Health", icon: "❤️", desc: "Biometric tracking & wellness metrics", chips: ["Log hydration", "Analyze sleep cycle", "Calculate daily calories"] },
        { id: "Entertainment", name: "Entertainment", icon: "🎬", desc: "Media curating & generative playlists", chips: ["Play ambient lofi", "Curate movie queue", "Generate daily podcast"] },
        { id: "Smart Home", name: "Smart Home", icon: "🏠", desc: "IoT device automation & sensor monitoring", chips: ["Turn on living room lights", "Adjust thermostat to 22C", "Lock front door"] },
        { id: "Security", name: "Security", icon: "🛡️", desc: "HackerAgent intrusion detection & port scan", chips: ["Run vulnerability audit", "Scan local ports (21, 22, 80)", "Check SSL certificates"] },
        { id: "Social", name: "Social", icon: "🌐", desc: "Feed aggregation & interaction sync", chips: ["Fetch recent posts", "Schedule status update", "Analyze sentiment"] },
        { id: "Experimental", name: "Experimental", icon: "🧪", desc: "Sandbox quantum heuristics & edge AI", chips: ["Run heuristic simulation", "Test neural weights", "Benchmark latency"] }
    ];

    let state = {
        activeModule: "Core AI",
        activeLang: "en",
        stm: [],
        ltm: [
            { module: "Core AI", command: "System initialized", response: "All 13 modules active", timestamp: new Date().toLocaleTimeString() }
        ],
        activeMemTab: "stm"
    };

    // DOM Elements
    const modulesGrid = document.getElementById('modulesGrid');
    const quickChipsContainer = document.getElementById('quickChips');
    const currentConsoleModule = document.getElementById('currentConsoleModule');
    const consoleOutput = document.getElementById('consoleOutput');
    const commandInput = document.getElementById('commandInput');
    const sendBtn = document.getElementById('sendBtn');
    const clearConsoleBtn = document.getElementById('clearConsoleBtn');
    const langSelect = document.getElementById('langSelect');
    const activeLangBadge = document.getElementById('activeLangBadge');
    const activeModuleBadge = document.getElementById('activeModuleBadge');
    const stmCountBadge = document.getElementById('stmCountBadge');
    const ltmCountBadge = document.getElementById('ltmCountBadge');
    const tabStm = document.getElementById('tabStm');
    const tabLtm = document.getElementById('tabLtm');
    const memoryViewer = document.getElementById('memoryViewer');
    const consolidateBtn = document.getElementById('consolidateBtn');

    // Render Modules Grid
    function renderModules() {
        modulesGrid.innerHTML = '';
        modulesData.forEach(mod => {
            const card = document.createElement('div');
            card.className = `module-card ${state.activeModule === mod.id ? 'active' : ''}`;
            card.innerHTML = `
                <div class="mod-icon">${mod.icon}</div>
                <div class="mod-info">
                    <h4>${mod.name}</h4>
                    <p>${mod.desc}</p>
                </div>
            `;
            card.addEventListener('click', () => {
                setActiveModule(mod.id);
            });
            modulesGrid.appendChild(card);
        });
    }

    // Set Active Module
    function setActiveModule(modId) {
        state.activeModule = modId;
        renderModules();
        renderQuickChips();
        currentConsoleModule.textContent = modId;
        activeModuleBadge.querySelector('span:nth-child(2)').textContent = `MOD: ${modId}`;
        
        // Append system log to console
        appendConsole(`Switched active operational focus to [${modId}].`, 'system');
    }

    // Render Quick Chips for Active Module
    function renderQuickChips() {
        quickChipsContainer.innerHTML = '';
        const currentMod = modulesData.find(m => m.id === state.activeModule);
        if (!currentMod) return;

        currentMod.chips.forEach(chipText => {
            const chip = document.createElement('button');
            chip.className = 'chip';
            chip.textContent = chipText;
            chip.addEventListener('click', () => {
                commandInput.value = chipText;
                handleCommandSubmission(chipText);
            });
            quickChipsContainer.appendChild(chip);
        });
    }

    // Append to Terminal Output
    function appendConsole(text, type = 'normal') {
        const line = document.createElement('div');
        line.className = `console-line ${type}`;
        const timeStr = new Date().toLocaleTimeString();
        line.innerHTML = `<span class="c-time">[${timeStr}]</span> <span class="c-text">${text}</span>`;
        consoleOutput.appendChild(line);
        consoleOutput.scrollTop = consoleOutput.scrollHeight;
    }

    // Handle Command Submission
    function handleCommandSubmission(cmd) {
        if (!cmd.trim()) return;
        appendConsole(`> ${cmd}`, 'input');
        commandInput.value = '';

        // Simulate agent processing & hacker module integration
        setTimeout(() => {
            let response = "";
            if (state.activeModule === "Security") {
                if (cmd.toLowerCase().includes("scan") || cmd.toLowerCase().includes("port")) {
                    response = "HackerAgent Scan: Ports 21(ftp: closed), 22(ssh: open), 80(http: open), 443(https: open) — Status: Secure.";
                } else if (cmd.toLowerCase().includes("audit") || cmd.toLowerCase().includes("vulnerability")) {
                    response = "HackerAgent Audit: 0 Critical, 0 High, 2 Low vulnerabilities found. SSL/TLS valid.";
                } else {
                    response = `HackerAgent executed simulation for: "${cmd}". Target 127.0.0.1 verified operational.`;
                }
            } else if (state.activeModule === "Core AI") {
                response = `Core AI synthesized response: Neural weights aligned for "${cmd}". 99.4% confidence score.`;
            } else if (state.activeModule === "Voice") {
                response = `Voice Engine: Audio synthesized successfully for "${cmd}". Formats: WAV, MP3 ready.`;
            } else if (state.activeModule === "Study") {
                response = `Study Module: Generated 5 interactive flashcards and summary quiz for "${cmd}".`;
            } else {
                response = `[${state.activeModule}] Processed successfully. Result state updated for: "${cmd}".`;
            }

            appendConsole(response, 'output');

            // Add to STM
            state.stm.push({
                module: state.activeModule,
                command: cmd,
                response: response,
                timestamp: new Date().toLocaleTimeString()
            });
            updateMemoryCounts();
            renderMemoryViewer();
        }, 300);
    }

    // Update Memory Badges
    function updateMemoryCounts() {
        stmCountBadge.textContent = `STM: ${state.stm.length}`;
        ltmCountBadge.textContent = `LTM: ${state.ltm.length}`;
    }

    // Render Memory Viewer
    function renderMemoryViewer() {
        memoryViewer.innerHTML = '';
        const targetList = state.activeMemTab === 'stm' ? state.stm : state.ltm;

        if (targetList.length === 0) {
            memoryViewer.innerHTML = `<div class="empty-memory">No records in ${state.activeMemTab.toUpperCase()} vault.</div>`;
            return;
        }

        targetList.slice().reverse().forEach(item => {
            const memItem = document.createElement('div');
            memItem.className = 'memory-item';
            memItem.innerHTML = `
                <div class="mem-header">
                    <span class="mem-mod">${item.module}</span>
                    <span class="mem-time">${item.timestamp}</span>
                </div>
                <div class="mem-body">
                    <strong>Cmd:</strong> ${item.command}<br>
                    <strong>Res:</strong> ${item.response}
                </div>
            `;
            memoryViewer.appendChild(memItem);
        });
    }

    // Event Listeners
    sendBtn.addEventListener('click', () => {
        handleCommandSubmission(commandInput.value);
    });

    commandInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleCommandSubmission(commandInput.value);
        }
    });

    clearConsoleBtn.addEventListener('click', () => {
        consoleOutput.innerHTML = '';
        appendConsole("Console cleared.", 'system');
    });

    langSelect.addEventListener('change', (e) => {
        state.activeLang = e.target.value;
        activeLangBadge.textContent = `LANG: ${state.activeLang.toUpperCase()}`;
        appendConsole(`System language switched to ${state.activeLang.toUpperCase()}. Neural dictionaries updated.`, 'system');
    });

    tabStm.addEventListener('click', () => {
        state.activeMemTab = 'stm';
        tabStm.classList.add('active');
        tabLtm.classList.remove('active');
        renderMemoryViewer();
    });

    tabLtm.addEventListener('click', () => {
        state.activeMemTab = 'ltm';
        tabLtm.classList.add('active');
        tabStm.classList.remove('active');
        renderMemoryViewer();
    });

    consolidateBtn.addEventListener('click', () => {
        if (state.stm.length === 0) {
            appendConsole("No Short-Term memory items to consolidate.", 'system');
            return;
        }
        state.ltm.push(...state.stm);
        state.stm = [];
        updateMemoryCounts();
        renderMemoryViewer();
        appendConsole("Consolidated STM records into LTM Vault successfully.", 'system');
    });

    // Initial Render
    renderModules();
    renderQuickChips();
    updateMemoryCounts();
    renderMemoryViewer();
});
