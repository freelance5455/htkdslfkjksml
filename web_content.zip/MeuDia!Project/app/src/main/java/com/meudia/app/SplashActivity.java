package com.meudia.app;

// Splash Activity placeholder