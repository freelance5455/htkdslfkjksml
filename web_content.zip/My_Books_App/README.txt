MY BOOKS — FIXED PERSONAL PDF READER
====================================

This is the corrected Curl Edition. The previous build contained a JavaScript
syntax error in the empty-library screen. That error prevented the entire app
script from running, so all app controls appeared unresponsive. The syntax
error is fixed in this build.

FEATURES
- Import one or multiple PDF files using the device file picker
- Local bookshelf stored in browser IndexedDB
- Search, Recently Opened, Favorites
- Book options: favorite, rename, remove
- PDF reading with page navigation and 3D page-turn animation
- Swipe left/right to turn pages on touch screens
- Zoom in/out and fit-to-width
- Remember last reading page
- Page bookmarks
- PDF outline / contents (when included in the PDF)
- Search text within a PDF
- Save a copy of the original PDF
- Responsive mobile layout and installable PWA shell

HOW TO RUN
1. Extract the ZIP.
2. Serve the My_Books_App folder from localhost or HTTPS. Do not use file://
   directly; browser storage and service-worker features require a secure
   context (localhost is treated as secure).
3. On a computer with Python, open a terminal in the extracted folder and run:
       python -m http.server 8000
   Then open http://localhost:8000 in a browser.
4. On Android, host the folder on a trusted HTTPS static host, open the link
   in Chrome, then choose Chrome menu > Add to Home screen / Install app.
5. Tap Add PDFs and choose files from the Android file picker.

IMPORTANT
- PDF rendering uses Mozilla PDF.js. The app tries cdnjs first and unpkg as a
  fallback. Internet access is needed to load the PDF.js library and worker.
- Imported PDF files and reading progress are stored locally in this browser;
  this app does not upload them to a server.
- Clearing browser/site storage can delete the local library. Keep backups of
  your original PDF files.
- A browser/PWA cannot silently scan all device folders; use Add PDFs to select
  the documents you want to import.
- This package is a web app/PWA source ZIP, not a compiled Android APK.
