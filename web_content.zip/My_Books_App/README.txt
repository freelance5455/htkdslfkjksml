MY BOOKS — PERSONAL PDF READER
================================

A private, responsive PDF library for your own device. It is inspired by the
clean library-and-reader experience of popular book apps, but uses its own
visual design and branding.

FEATURES
- Import multiple PDF files from your device
- Local library stored in this browser using IndexedDB
- Search book titles; filter All / Recently opened / Favorites
- Custom book covers generated from file names
- Open PDFs with page navigation, zoom, and fit
- Save and restore last-read page
- Page bookmarks
- PDF table of contents (when the PDF contains one)
- Search text inside the current PDF
- Save a copy of the original PDF
- Keyboard left/right page navigation on desktop
- Responsive mobile layout and installable PWA shell

IMPORTANT
- PDF reading uses Mozilla PDF.js from a CDN. Internet is required the first
  time the app loads the PDF.js library. After the app shell is cached, your
  own imported PDF files remain stored locally in the browser.
- PDF files are not uploaded to a server by this app.
- Clearing browser/site storage can delete the app's local library. Keep
  original copies of important PDFs elsewhere.
- This is a web app package, not a compiled Android APK.

HOW TO RUN
1. Extract this ZIP.
2. For the best experience, serve the folder from localhost or HTTPS.
   Example on a computer with Python installed:
       python -m http.server 8000
   Then open http://localhost:8000 in a browser.
3. On Android, you can host the folder on a trusted HTTPS static host, open
   the link in Chrome, then use Chrome menu > Add to Home screen / Install app.
4. Open My Books and tap Add PDFs. Choose files from your device.

ANDROID NOTE
A browser/PWA cannot automatically scan all device folders. Use the Add PDFs
button and Android's file picker to select the PDFs you want to add.
