Universal Chat Web (texto + imagens grátis via ImgBB)

NÃO USA Firebase Storage → não precisa de plano pago.

=== IMAGENS (ImgBB grátis) ===
1. Acesse: https://api.imgbb.com/
2. Crie conta / faça login
3. Copie sua API Key
4. Abra o index.html e procure:
   const IMGBB_API_KEY = "SUA_CHAVE_IMGBB_AQUI";
5. Cole a chave no lugar de SUA_CHAVE_IMGBB_AQUI
6. Salve e gere o APK de novo

Limite do plano free do ImgBB: ~32 MB por imagem (na prática use até 5-8 MB).

=== FIREBASE (só Auth + Firestore) ===
- Authentication → E-mail/senha ligado
- Firestore criado e API ativada
- Storage NÃO é necessário

=== GERAR APK ===
Coloque o index.html como página inicial no seu gerador de APK (WebView).
Ative permissão de Internet.
