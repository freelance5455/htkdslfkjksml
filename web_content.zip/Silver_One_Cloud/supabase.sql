-- Silver One Cloud - Supabase database
create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  category text not null check (category in ('silver','watches','perfumes')),
  name text not null,
  type text,
  weight numeric(12,2),
  price numeric(12,2) not null default 0,
  total integer not null default 0,
  qty integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists invoices (
  id uuid primary key default gen_random_uuid(),
  invoice_no text not null unique,
  total numeric(12,2) not null default 0,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id)
);

create table if not exists invoice_items (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid not null references invoices(id) on delete cascade,
  product_id uuid references products(id),
  code text not null,
  name text not null,
  qty integer not null,
  price numeric(12,2) not null
);

create table if not exists app_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb
);

alter table products enable row level security;
alter table invoices enable row level security;
alter table invoice_items enable row level security;
alter table app_settings enable row level security;

-- جميع المستخدمين المسجلين في التطبيق لديهم نفس صلاحيات الإدارة.
create policy if not exists products_all_authenticated on products for all to authenticated using (true) with check (true);
create policy if not exists invoices_all_authenticated on invoices for all to authenticated using (true) with check (true);
create policy if not exists invoice_items_all_authenticated on invoice_items for all to authenticated using (true) with check (true);
create policy if not exists settings_all_authenticated on app_settings for all to authenticated using (true) with check (true);

-- تحديث المخزون وإنشاء الفاتورة كعملية واحدة.
create or replace function create_sale(p_items jsonb, p_total numeric)
returns jsonb
language plpgsql
security invoker
as $$
declare
  item jsonb;
  pid uuid;
  q integer;
  p numeric;
  v_invoice_id uuid;
  v_no text;
  r record;
begin
  for item in select * from jsonb_array_elements(p_items) loop
    pid := (item->>'product_id')::uuid;
    q := (item->>'qty')::integer;
    select * into r from products where id = pid for update;
    if not found then raise exception 'PRODUCT_NOT_FOUND'; end if;
    if r.qty < q then raise exception 'INSUFFICIENT_STOCK:%', r.code; end if;
  end loop;

  v_no := 'INV-' || lpad((coalesce((select count(*) from invoices),0)+1)::text,4,'0');
  insert into invoices(invoice_no,total,created_by) values(v_no,p_total,auth.uid()) returning id into v_invoice_id;

  for item in select * from jsonb_array_elements(p_items) loop
    pid := (item->>'product_id')::uuid;
    q := (item->>'qty')::integer;
    p := (item->>'price')::numeric;
    select code,name into r from products where id=pid;
    insert into invoice_items(invoice_id,product_id,code,name,qty,price)
      values(v_invoice_id,pid,r.code,r.name,q,p);
    update products set qty=qty-q where id=pid;
  end loop;
  return jsonb_build_object('id',v_invoice_id,'invoice_no',v_no);
end;
$$;

grant execute on function create_sale(jsonb,numeric) to authenticated;
