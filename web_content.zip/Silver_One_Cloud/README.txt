Silver One Cloud - تحديث لنفس تطبيق Silver One

هذه النسخة فارغة من المنتجات والفواتير التجريبية.
تعمل الواجهة نفسها تقريباً، لكن البيانات تحفظ في Supabase بدلاً من localStorage.

الإعداد السريع:
1) أنشئ مشروعاً مجانياً في Supabase.
2) افتح SQL Editor والصق محتوى supabase.sql ونفذه.
3) من Authentication > Users أنشئ حسابات الدخول التي تريدها.
4) افتح config.js وضع:
   SUPABASE_URL = رابط المشروع
   SUPABASE_ANON_KEY = anon/public key
5) ارفع المجلد إلى Netlify أو استخدم محتوى web/ لأداة تحويل HTML إلى APK.

ملاحظة: لا تضع service_role key داخل التطبيق. استخدم anon/public key فقط.
كل المستخدمين المسجلين لهم نفس صلاحية استخدام النظام، حسب طلبك.
