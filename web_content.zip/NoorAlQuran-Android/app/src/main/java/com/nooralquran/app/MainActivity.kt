package com.nooralquran.app

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject
import java.util.Calendar

private const val CHANNEL_ID = "noor_prayer_alarms"
private const val PREFS = "noor_prayer_prefs"
private const val TIMES = "prayer_times_json"
private const val ENABLED = "adhan_enabled"
private val prayerLabels = mapOf("Fajr" to "الفجر", "Dhuhr" to "الظهر", "Asr" to "العصر", "Maghrib" to "المغرب", "Isha" to "العشاء")

class MainActivity : Activity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(PrayerBridge(this), "AndroidPrayerBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/www/index.html")
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(CHANNEL_ID, "أذان ومواقيت الصلاة", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "تنبيه عند دخول وقت الصلاة"
                setSound(android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM),
                    android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_ALARM).build())
                enableVibration(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(channel)
        }
    }
    fun scheduleFromJson(json: String) {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        prefs.edit().putString(TIMES, json).putBoolean(ENABLED, true).apply()
        scheduleNextAlarms(json)
    }
    fun scheduleNextAlarms(json: String) {
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        val data = JSONObject(json)
        val now = System.currentTimeMillis()
        for ((key, label) in prayerLabels) {
            val raw = data.optString(key, "")
            val parts = raw.split(":")
            if (parts.size < 2) continue
            val hour = parts[0].toIntOrNull() ?: continue
            val minute = parts[1].toIntOrNull() ?: continue
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= now) add(Calendar.DAY_OF_YEAR, 1)
            }
            val intent = Intent(this, PrayerAlarmReceiver::class.java).putExtra("prayer_key", key).putExtra("prayer_label", label)
            val pi = PendingIntent.getBroadcast(this, key.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            else alarm.setExact(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        }
    }
    class PrayerBridge(private val activity: MainActivity) {
        @JavascriptInterface fun updatePrayerTimes(json: String) {
            if (activity.getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(ENABLED, false)) activity.runOnUiThread { activity.scheduleFromJson(json) }
        }
        @JavascriptInterface fun requestAlarmPermission() {
            activity.runOnUiThread {
                activity.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(ENABLED, true).apply()
                val saved = activity.getSharedPreferences(PREFS, MODE_PRIVATE).getString(TIMES, null)
                if (saved != null) activity.scheduleNextAlarms(saved)
                val am = activity.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                    activity.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${activity.packageName}")))
                }
                if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(activity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(activity, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2201)
                }
            }
        }
    }
}

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val key = intent.getStringExtra("prayer_key") ?: return
        val label = intent.getStringExtra("prayer_label") ?: prayerLabels[key] ?: return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(ENABLED, false)) return
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("حان وقت صلاة $label")
            .setContentText("حيّ على الصلاة — نور القرآن")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .build()
        if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            NotificationManagerCompat.from(context).notify(key.hashCode(), notification)
        }
        // Schedule this prayer again for the next day using the saved local prayer time.
        val json = prefs.getString(TIMES, null) ?: return
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val data = JSONObject(json)
        val raw = data.optString(key, "")
        val parts = raw.split(":")
        if (parts.size >= 2) {
            val h = parts[0].toIntOrNull(); val m = parts[1].toIntOrNull()
            if (h != null && m != null) {
                val next = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY,h); set(Calendar.MINUTE,m); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }
                val again = Intent(context, PrayerAlarmReceiver::class.java).putExtra("prayer_key",key).putExtra("prayer_label",label)
                val pi = PendingIntent.getBroadcast(context,key.hashCode(),again,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next.timeInMillis,pi) else alarm.setExact(AlarmManager.RTC_WAKEUP,next.timeInMillis,pi)
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED && intent.action != "android.intent.action.MY_PACKAGE_REPLACED") return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(ENABLED, false)) return
        val json = prefs.getString(TIMES, null) ?: return
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val data = JSONObject(json)
        for ((key, label) in prayerLabels) {
            val parts = data.optString(key, "").split(":")
            if (parts.size < 2) continue
            val h = parts[0].toIntOrNull() ?: continue
            val m = parts[1].toIntOrNull() ?: continue
            val next = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,h);set(Calendar.MINUTE,m);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);if(timeInMillis<=System.currentTimeMillis())add(Calendar.DAY_OF_YEAR,1) }
            val i = Intent(context,PrayerAlarmReceiver::class.java).putExtra("prayer_key",key).putExtra("prayer_label",label)
            val pi = PendingIntent.getBroadcast(context,key.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            if(Build.VERSION.SDK_INT>=23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next.timeInMillis,pi) else alarm.setExact(AlarmManager.RTC_WAKEUP,next.timeInMillis,pi)
        }
    }
}
