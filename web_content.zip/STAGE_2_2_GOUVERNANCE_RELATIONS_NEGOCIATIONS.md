# Socle 2.2 — Gouvernance de la Dame d’Or, relations et négociations

## Décisions officielles confirmées

### Dame d’Or
La Dame d’Or est organisée par la **Fédération Galactique des Dames (FGD)**, avec la collaboration de l’**Association Galactique des Dames (AGD)**. Elle reste une distinction individuelle annuelle, mixte, fondée sur les performances réellement homologuées. La FGD porte l’organisation officielle ; l’AGD intervient comme institution collaboratrice. Les deux institutions ne doivent pas être confondues avec les organisateurs propres aux autres compétitions.

### Messagerie et presse
Le système doit s’inspirer de la profondeur de gestion relationnelle de Football Manager 26, sans copier ses textes, son interface ou ses données. La messagerie est un système vivant, lié aux événements de carrière. Les interlocuteurs prévus sont :

- **Damistes** : temps de jeu, titularisation, rôle, forme, progression, ambitions, moral, contrat, frustration et avenir.
- **Supporters** : résultats, style de jeu, objectifs, recrutement, prix/abonnements si ces systèmes sont activés, confiance et mécontentement.
- **Direction** : objectifs, finances, résultats, discipline, stratégie, réputation et confiance envers le manager.
- **Presse** : demandes d’interview, conférences, réactions, critiques et actualités liées aux événements vérifiés.

Le manager doit pouvoir choisir une réponse ou une position. Les conséquences doivent être persistantes et contextualisées : moral des damistes, confiance de la direction, relation avec les supporters, réputation, pression médiatique ou relations individuelles. Une réponse ne doit jamais modifier arbitrairement plusieurs jauges sans lien avec le sujet. Les messages importants doivent pouvoir être consultés dans l’historique.

### Contrats des damistes
Le manager doit pouvoir consulter les contrats, discuter avec un damiste et négocier les éléments contractuels disponibles dans le modèle économique du jeu : durée, rémunération, primes, statut/rôle et éventuelles clauses. Les propositions, contre-propositions, acceptations et refus doivent être enregistrés. Aucun accord ne doit être conclu sans validation explicite des deux parties. Les règles détaillées de finances et les montants de référence restent à auditer avant de fixer des barèmes.

### Sponsors, partenaires et autres structures commerciales
**Règle non négociable : les sponsors, partenaires, promoteurs/diffuseurs, banques et autres structures commerciales viennent proposer leurs offres aux clubs.** Le club ne les démarche pas et ne signe pas spontanément de contrat.

Cycle attendu :
1. Une structure éligible approche un club avec une proposition entrante.
2. Le manager reçoit une notification et consulte les conditions.
3. Il peut accepter, refuser ou ouvrir une négociation.
4. Les deux parties discutent des avantages et obligations : apport financier ou matériel, visibilité, exclusivité, durée, objectifs, bonus, services et contreparties, selon le type de partenaire.
5. Une contre-proposition peut être acceptée, refusée ou renégociée.
6. Le contrat n’est signé qu’après accord explicite ; ses revenus, avantages, obligations et échéances sont ensuite intégrés à la gestion du club.

Le but est un accord **gagnant-gagnant** : l’offre doit tenir compte de la réputation, des résultats, de la division, de l’audience et de la situation du club, tandis que les conditions négociées doivent rester soutenables pour les deux parties. Les offres ne doivent pas être identiques pour tous les clubs et ne doivent pas créer de déséquilibre économique artificiel.

## Exigences de conception et de validation
- Les systèmes de messagerie, presse, contrats et partenariats doivent être persistants dans la sauvegarde de carrière et reliés au calendrier central.
- Les événements doivent être idempotents : une même rencontre ou actualité ne génère pas plusieurs fois le même message ou la même offre.
- Les choix du manager doivent avoir des conséquences traçables, cohérentes et réversibles uniquement par une nouvelle action de jeu, jamais par une réécriture silencieuse de l’historique.
- Les structures déjà présentes dans le catalogue historique sont conservées ; aucune banque, sponsor, entreprise, firme, partenaire, promoteur ou donnée historique n’est supprimé ou remplacé.
- Les valeurs financières, fréquences d’offres, critères d’éligibilité et barèmes non établis restent « à définir après audit » : aucun chiffre ne doit être inventé.
- La présentation doit rester adaptée à l’interface horizontale du CGD et accessible par défilement, sans supprimer les rubriques existantes.

## État de réalisation
Ce document consigne les règles fonctionnelles confirmées. La seule modification de code de ce socle est l’attribution officielle de la Dame d’Or à la FGD avec collaboration de l’AGD dans le catalogue des compétitions. Les interfaces et moteurs complets de messagerie, presse, négociation des contrats et offres commerciales entrantes restent à développer et à tester ; ils ne sont pas déclarés opérationnels à cette étape.

## Validation complémentaire — saison complète de la Dame d’Or (Socle 2.3)
Une simulation de saison régulière complète couvre les trois divisions actives de départ (Super League, Ligue A et Ligue B), soit 36 clubs et **396 rencontres aller-retour**. Après chaque rencontre homologuée, le test vérifie le classement recalculé, la progression de deux titulaires exactement, l’absence de doublon, la cohérence des statistiques et l’idempotence de l’homologation. À la fin des 396 rencontres, le test déclenche la clôture officielle à la date FGD, contrôle le classement final, le vainqueur et l’unicité de l’archive de cérémonie. Les sept autres compétitions sont comparées avant/après et doivent rester strictement inchangées.

**Résultat automatisé : 134/134 tests réussis.** Vérification syntaxique de tous les fichiers JavaScript réussie. Cette validation porte sur les moteurs et la cérémonie côté code ; elle ne constitue pas encore un test visuel dans un navigateur.
