/* =========================================================
   ALL-FEATURES.JS — v7.0
   Every feature. Zero errors. Safe for any page.
   ========================================================= */
(function () {
  'use strict';

  const S = window.ShapeStudio;
  if (!S) return;

  const $ = (id) => document.getElementById(id);
  const $$ = (sel) => document.querySelectorAll(sel);
  const mk = (tag, cls, css) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (css) e.style.cssText = css;
    return e;
  };

  // Safe local helpers
  const SFX = S.SFX || {};
  const settings = S.settings || {};
  const shapes = Array.isArray(S.SHAPES) ? S.SHAPES : [];
  const palette = Array.isArray(S.PALETTE) ? S.PALETTE : [];
  const renderDotsSafe = (canvas, shape, opts) => {
    try {
      if (typeof S.renderDots === 'function') S.renderDots(canvas, shape, opts);
    } catch (e) {}
  };
  const hexToRgbaSafe = (hex, a) => {
    try {
      if (typeof S.hexToRgba === 'function') return S.hexToRgba(hex, a);
      const h = String(hex || '#8b7cff').replace('#', '');
      const full = h.length === 3 ? h.split('').map(c => c + c).join('') : h;
      const n = parseInt(full, 16);
      return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
    } catch (e) { return 'rgba(139,124,255,' + a + ')'; }
  };
  const isOn = (k) => {
    try {
      if (typeof S.isFeatureOn === 'function') return S.isFeatureOn(k);
      return false;
    } catch (e) { return false; }
  };
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

  const Store = {
    get(k, def) {
      try { return JSON.parse(localStorage.getItem(k) || JSON.stringify(def)); }
      catch (e) { return def; }
    },
    set(k, v) {
      try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {}
    },
    flag(k) { try { return localStorage.getItem(k) === 'true'; } catch (e) { return false; } },
    setFlag(k, v) { try { localStorage.setItem(k, v ? 'true' : 'false'); } catch (e) {} }
  };

  let toastTimer = null;
  function toast(msg) {
    let el = $('toast');
    if (el) {
      el.textContent = msg;
      el.classList.add('show');
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => el.classList.remove('show'), 1600);
      return;
    }
    let t = $('afToast');
    if (!t) {
      t = mk('div', '', 'position:fixed;bottom:100px;left:50%;transform:translateX(-50%);z-index:10000;background:rgba(20,22,32,.98);border:1px solid rgba(139,124,255,.5);border-radius:999px;padding:12px 22px;color:#fff;font-family:Inter,sans-serif;font-size:13px;font-weight:600;opacity:0;transition:all .3s;pointer-events:none;');
      t.id = 'afToast';
      document.body.appendChild(t);
    }
    t.textContent = msg;
    requestAnimationFrame(() => {
      t.style.opacity = '1';
      t.style.transform = 'translateX(-50%) translateY(-8px)';
    });
    clearTimeout(t._t);
    t._t = setTimeout(() => {
      t.style.opacity = '0';
      t.style.transform = 'translateX(-50%)';
    }, 1600);
  }

  /* =========================================================
     FAVORITES
     ========================================================= */
  const Favorites = {
    KEY: 'af_favs',
    all() { return Store.get(Favorites.KEY, []); },
    has(i) { return Favorites.all().indexOf(i) >= 0; },
    toggle(i) {
      const a = Favorites.all();
      const k = a.indexOf(i);
      if (k >= 0) a.splice(k, 1);
      else a.push(i);
      Store.set(Favorites.KEY, a);
      Favorites.refreshStars();
      Favorites.renderHomeSection();
    },
    refreshStars() {
      $$('.af-star').forEach(st => {
        st.classList.toggle('active', Favorites.has(parseInt(st.dataset.idx, 10)));
      });
    },
    decorateCard(card) {
      if (!isOn('favorites')) return;
      if (card.querySelector('.af-star')) return;
      const idx = parseInt(card.dataset.shapeIndex, 10);
      if (isNaN(idx)) return;
      const star = mk('div', 'af-star', '');
      star.textContent = '★';
      star.dataset.idx = idx;
      if (Favorites.has(idx)) star.classList.add('active');
      star.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        Favorites.toggle(idx);
        if (typeof SFX.tap === 'function') SFX.tap();
        toast(Favorites.has(idx) ? '⭐ Favorited' : 'Removed');
      });
      card.style.position = 'relative';
      card.appendChild(star);
    },
    renderHomeSection() {
      if (!isOn('favorites')) return;
      const old = $('afFavSection');
      if (old) old.remove();
      const pagesGrid = $('pagesGrid');
      if (!pagesGrid || !pagesGrid.parentElement) return;
      const favs = Favorites.all();
      if (favs.length === 0) return;
      const sec = mk('div');
      sec.id = 'afFavSection';
      sec.innerHTML = '<div class="section-head"><h2>⭐ Favorites</h2><span class="count">' + favs.length + ' items</span><div class="line"></div></div><div class="shapes-grid" id="afFavGrid"></div>';
      pagesGrid.parentElement.insertBefore(sec, pagesGrid.parentElement.firstChild);
      const g = $('afFavGrid');
      if (!g) return;
      favs.forEach(idx => {
        const s = shapes[idx];
        if (!s) return;
        const el = document.createElement('div');
        el.className = 'shape-card';
        el.dataset.shapeIndex = idx;
        el.style.setProperty('--glow', hexToRgbaSafe(s.color || '#8b7cff', 0.35));
        const cv = document.createElement('canvas');
        el.appendChild(cv);
        const name = document.createElement('div');
        name.className = 'name';
        name.textContent = s.name || 'Shape';
        el.appendChild(name);
        g.appendChild(el);
        requestAnimationFrame(() => renderDotsSafe(cv, s, { dotCount: 90, dotSize: 1.1 }));
        el.addEventListener('click', () => {
          const orig = document.querySelector('.shape-card[data-shape-index="' + idx + '"]');
          if (orig && orig !== el) orig.click();
        });
      });
    }
  };

  /* =========================================================
     SAVED LOOKS
     ========================================================= */
  const SavedLooks = {
    KEY: 'af_saved',
    all() { return Store.get(SavedLooks.KEY, []); },
    add(data) {
      const a = SavedLooks.all();
      a.unshift({
        id: Date.now(),
        name: data.name || 'Design ' + (a.length + 1),
        timestamp: Date.now(),
        shapeName: data.shapeName || 'Custom',
        color: data.color || '#8b7cff',
        density: data.density || 2600,
        dotSize: data.dotSize || 1.6,
        glow: data.glow || 0.5,
        opacity: data.opacity || 1,
        dotPattern: data.dotPattern || 'grid',
        colorMode: data.colorMode || 'solid'
      });
      Store.set(SavedLooks.KEY, a.slice(0, 50));
    },
    remove(id) {
      Store.set(SavedLooks.KEY, SavedLooks.all().filter(l => l.id !== id));
    },
    apply(look) {
      const cards = $$('.shape-card');
      for (let i = 0; i < cards.length; i++) {
        if (cards[i].dataset.label === look.shapeName) {
          cards[i].click();
          break;
        }
      }
      setTimeout(() => {
        const set = (id, val) => {
          const e = $(id);
          if (!e) return;
          e.value = val;
          e.dispatchEvent(new Event('input', { bubbles: true }));
          e.dispatchEvent(new Event('change', { bubbles: true }));
        };
        if (look.color) set('colorPicker', look.color);
        if (look.density) set('densitySlider', look.density);
        if (look.dotSize) set('dotSizeSlider', look.dotSize);
        if (look.glow) set('glowSlider', Math.round(look.glow * 100));
        if (look.opacity) set('opacitySlider', Math.round(look.opacity * 100));
      }, 300);
      toast('Loaded: ' + look.name);
    },
    renderHomeSection() {
      if (!isOn('saveLook')) return;
      const old = $('afSavedSection');
      if (old) old.remove();
      const grid = $('customShapesGrid');
      if (!grid || !grid.parentElement) return;
      const a = SavedLooks.all();
      const sec = mk('div');
      sec.id = 'afSavedSection';
      sec.innerHTML = '<div class="section-head"><h2>💾 My Designs</h2><span class="count">' + a.length + ' items</span><div class="line"></div></div><div class="saved-grid" id="afSavedGrid"></div>';
      grid.parentElement.insertBefore(sec, grid);
      const g = $('afSavedGrid');
      if (!g) return;
      if (a.length === 0) {
        g.innerHTML = '<div class="empty-inline">Save designs from the editor to see them here</div>';
        return;
      }
      a.forEach(look => {
        const c = mk('div', 'saved-card');
        c.innerHTML =
          '<div class="saved-dot" style="background:linear-gradient(135deg,' + look.color + ',' + (look.secondaryColor || '#4dd4ff') + ');box-shadow:0 0 20px ' + hexToRgbaSafe(look.color, 0.6) + '"></div>' +
          '<div class="saved-info">' +
            '<div class="saved-name">' + look.name + '</div>' +
            '<div class="saved-meta">' + look.shapeName + ' · ' + look.dotPattern + '</div>' +
          '</div>' +
          '<button class="saved-del" data-id="' + look.id + '">✕</button>';
        c.querySelector('.saved-del').addEventListener('click', (e) => {
          e.stopPropagation();
          SavedLooks.remove(look.id);
          SavedLooks.renderHomeSection();
        });
        c.addEventListener('click', () => SavedLooks.apply(look));
        g.appendChild(c);
      });
    }
  };

  /* =========================================================
     ONBOARDING
     ========================================================= */
  function showOnboarding() {
    if (!isOn('onboarding')) return;
    if (Store.flag('af_onb_done')) return;
    const steps = [
      { icon: '👆', title: 'Tap any shape', desc: 'Open the editor to customize it.' },
      { icon: '🎨', title: 'Customize it', desc: 'Adjust color, density, glow, pattern and more.' },
      { icon: '▶️', title: 'Play the shape', desc: 'Drag, rotate, or use hand tracking.' },
      { icon: '⭐', title: 'Save your favorites', desc: 'Star shapes and save your own designs.' }
    ];
    let step = 0;
    const overlay = mk('div', 'onb-overlay');

    function render() {
      const s = steps[step];
      overlay.innerHTML =
        '<div class="onb-card">' +
          '<div class="onb-icon">' + s.icon + '</div>' +
          '<h2 class="onb-title">' + s.title + '</h2>' +
          '<p class="onb-desc">' + s.desc + '</p>' +
          '<div class="onb-dots">' + steps.map((_, i) => '<div class="onb-dot' + (i === step ? ' on' : '') + '"></div>').join('') + '</div>' +
          '<div class="onb-actions">' +
            '<button class="btn" id="afOnbSkip">Skip</button>' +
            '<button class="btn btn-primary" id="afOnbNext">' + (step === steps.length - 1 ? 'Got it!' : 'Next') + '</button>' +
          '</div>' +
        '</div>';
      const nextBtn = $('afOnbNext');
      if (nextBtn) nextBtn.addEventListener('click', () => {
        if (step < steps.length - 1) { step++; render(); }
        else finish();
      });
      const skipBtn = $('afOnbSkip');
      if (skipBtn) skipBtn.addEventListener('click', finish);
    }

    function finish() {
      Store.setFlag('af_onb_done', true);
      overlay.remove();
    }

    document.body.appendChild(overlay);
    render();
  }

  /* =========================================================
     SHAPE OF THE DAY
     ========================================================= */
  function renderShapeOfDay() {
    if (!isOn('shapeOfDay')) return;
    const home = $('page-home');
    if (!home || shapes.length === 0) return;
    if ($('sotdBanner')) return;
    const now = new Date();
    const seed = now.getFullYear() * 10000 + (now.getMonth() + 1) * 100 + now.getDate();
    const idx = seed % shapes.length;
    const shape = shapes[idx];
    if (!shape) return;

    const hero = home.querySelector('.hero');
    const banner = mk('div');
    banner.id = 'sotdBanner';
    banner.innerHTML =
      '<div class="sotd-inner">' +
        '<div class="sotd-canvas-wrap"><canvas id="afSotdCanvas" width="120" height="120"></canvas></div>' +
        '<div class="sotd-body">' +
          '<div class="sotd-badge">✨ Shape of the Day</div>' +
          '<div class="sotd-title">' + (shape.name || 'Shape') + '</div>' +
          '<div class="sotd-date">' + now.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' }) + '</div>' +
        '</div>' +
        '<button class="sotd-play" id="afSotdPlay">▶ Play</button>' +
      '</div>';
    if (hero && hero.nextSibling) home.insertBefore(banner, hero.nextSibling);
    else home.insertBefore(banner, home.firstChild);

    requestAnimationFrame(() => {
      const cv = $('afSotdCanvas');
      if (cv) renderDotsSafe(cv, shape, { dotCount: 180, dotSize: 1.3 });
    });
    const btn = $('afSotdPlay');
    if (btn) btn.addEventListener('click', () => {
      const card = document.querySelector('.shape-card[data-shape-index="' + idx + '"]');
      if (card) card.click();
    });
  }

  /* =========================================================
     PARTICLE TRAILS (stage)
     ========================================================= */
  const Trails = {
    canvas: null, ctx: null, parts: [], active: false, raf: null,
    start(stage) {
      if (!isOn('particleTrails') || settings.reduceMotion) return;
      if (Trails.active) return;
      if (!stage) return;
      const c = mk('canvas', '', 'position:fixed;inset:0;pointer-events:none;z-index:4');
      c.width = window.innerWidth;
      c.height = window.innerHeight;
      stage.appendChild(c);
      Trails.canvas = c;
      Trails.ctx = c.getContext('2d');
      Trails.parts = [];
      Trails.active = true;
      Trails.loop();
    },
    loop() {
      if (!Trails.active) return;
      Trails.raf = requestAnimationFrame(() => Trails.loop());
      const ctx = Trails.ctx;
      if (!ctx) return;
      ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
      for (let i = Trails.parts.length - 1; i >= 0; i--) {
        const p = Trails.parts[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vx *= 0.96;
        p.vy *= 0.96;
        p.life -= 0.02;
        if (p.life <= 0) { Trails.parts.splice(i, 1); continue; }
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r * p.life, 0, Math.PI * 2);
        ctx.fillStyle = hexToRgbaSafe(p.color, p.life * 0.9);
        ctx.fill();
      }
    },
    emit(x, y, color) {
      if (!Trails.active || Trails.parts.length > 180) return;
      Trails.parts.push({
        x: x, y: y,
        vx: (Math.random() - 0.5) * 1.5,
        vy: (Math.random() - 0.5) * 1.5,
        r: 2 + Math.random() * 3,
        life: 1,
        color: color || '#8b7cff'
      });
    },
    stop() {
      Trails.active = false;
      if (Trails.raf) cancelAnimationFrame(Trails.raf);
      if (Trails.canvas) Trails.canvas.remove();
      Trails.canvas = null;
      Trails.ctx = null;
      Trails.parts = [];
    }
  };

  /* =========================================================
     BACKGROUND PARTICLES
     ========================================================= */
  const BgParticles = {
    canvas: null, ctx: null, parts: [], active: false, raf: null,
    start(stage) {
      if (!isOn('bgParticles') || settings.reduceMotion) return;
      if (BgParticles.active) return;
      if (!stage) return;
      const c = mk('canvas', '', 'position:fixed;inset:0;pointer-events:none;z-index:3');
      c.width = window.innerWidth;
      c.height = window.innerHeight;
      stage.appendChild(c);
      BgParticles.canvas = c;
      BgParticles.ctx = c.getContext('2d');
      BgParticles.parts = [];
      for (let i = 0; i < 55; i++) {
        BgParticles.parts.push({
          x: Math.random() * c.width,
          y: Math.random() * c.height,
          r: 0.5 + Math.random() * 1.5,
          vx: (Math.random() - 0.5) * 0.25,
          vy: (Math.random() - 0.5) * 0.25,
          a: 0.2 + Math.random() * 0.4
        });
      }
      BgParticles.active = true;
      BgParticles.loop();
    },
    loop() {
      if (!BgParticles.active) return;
      BgParticles.raf = requestAnimationFrame(() => BgParticles.loop());
      const ctx = BgParticles.ctx;
      if (!ctx) return;
      ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
      BgParticles.parts.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0) p.x = ctx.canvas.width;
        if (p.x > ctx.canvas.width) p.x = 0;
        if (p.y < 0) p.y = ctx.canvas.height;
        if (p.y > ctx.canvas.height) p.y = 0;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(139,124,255,' + p.a + ')';
        ctx.fill();
      });
    },
    stop() {
      BgParticles.active = false;
      if (BgParticles.raf) cancelAnimationFrame(BgParticles.raf);
      if (BgParticles.canvas) BgParticles.canvas.remove();
      BgParticles.canvas = null;
      BgParticles.ctx = null;
      BgParticles.parts = [];
    }
  };

  /* =========================================================
     RANDOM GLITCH
     ========================================================= */
  const Glitch = {
    timer: null,
    start(target) {
      if (!isOn('glitch') || settings.reduceMotion) return;
      if (Glitch.timer) return;
      Glitch.timer = setInterval(() => {
        if (!target || !document.body.contains(target)) { Glitch.stop(); return; }
        if (Math.random() < 0.25) {
          try {
            target.animate([
              { filter: 'hue-rotate(0deg)', transform: 'translate(0,0)' },
              { filter: 'hue-rotate(90deg) drop-shadow(3px 0 0 rgba(255,0,100,.7))', transform: 'translate(2px,-1px)' },
              { filter: 'hue-rotate(-90deg) drop-shadow(-2px 0 0 rgba(0,200,255,.7))', transform: 'translate(-2px,1px)' },
              { filter: 'hue-rotate(0deg)', transform: 'translate(0,0)' }
            ], { duration: 200, easing: 'steps(4)' });
            if (typeof SFX.glitch === 'function') SFX.glitch();
          } catch (e) {}
        }
      }, 4000);
    },
    stop() {
      if (Glitch.timer) { clearInterval(Glitch.timer); Glitch.timer = null; }
    }
  };

  /* =========================================================
     SHATTER & REFORM
     ========================================================= */
  const Shatter = {
    state: 'intact',
    canvas: null, ctx: null, parts: [], raf: null, target: null,
    trigger(wrap, color) {
      if (!isOn('shatter')) return;
      if (Shatter.state !== 'intact') return;
      const c = wrap || $('shapeWrap');
      if (!c) return;
      const rect = c.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const R = rect.width / 2;
      const canvas = mk('canvas', '', 'position:fixed;inset:0;pointer-events:none;z-index:50');
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      document.body.appendChild(canvas);
      Shatter.canvas = canvas;
      Shatter.ctx = canvas.getContext('2d');
      Shatter.parts = [];
      Shatter.target = c;
      Shatter.state = 'shattering';
      for (let i = 0; i < 120; i++) {
        const ang = Math.random() * Math.PI * 2;
        const dist = Math.random() * R;
        const speed = 4 + Math.random() * 8;
        Shatter.parts.push({
          x: cx + Math.cos(ang) * dist,
          y: cy + Math.sin(ang) * dist,
          vx: Math.cos(ang) * speed,
          vy: Math.sin(ang) * speed,
          r: 1 + Math.random() * 2,
          color: color || '#8b7cff',
          life: 1
        });
      }
      c.style.transition = 'opacity .3s ease';
      c.style.opacity = '0';
      if (typeof SFX.shatter === 'function') SFX.shatter();
      toast('💥 Shattered! (4 fingers ×4 to reform)');
      Shatter.loop();
      setTimeout(() => { Shatter.state = 'shattered'; }, 500);
    },
    loop() {
      if (Shatter.state === 'intact') return;
      Shatter.raf = requestAnimationFrame(() => Shatter.loop());
      const ctx = Shatter.ctx;
      if (!ctx) return;
      ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
      for (let i = Shatter.parts.length - 1; i >= 0; i--) {
        const p = Shatter.parts[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.15;
        p.vx *= 0.99;
        p.vy *= 0.99;
        p.life -= 0.008;
        if (p.life <= 0) { Shatter.parts.splice(i, 1); continue; }
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r * p.life, 0, Math.PI * 2);
        ctx.fillStyle = hexToRgbaSafe(p.color, p.life);
        ctx.fill();
      }
    },
    reform() {
      if (Shatter.state !== 'shattered' || !Shatter.target) return;
      if (typeof SFX.reform === 'function') SFX.reform();
      Shatter.target.style.transition = 'opacity .6s cubic-bezier(.4,1.4,.6,1)';
      Shatter.target.style.opacity = '1';
      toast('✨ Reformed!');
      setTimeout(() => {
        Shatter.state = 'intact';
        if (Shatter.canvas) Shatter.canvas.remove();
        if (Shatter.raf) cancelAnimationFrame(Shatter.raf);
        Shatter.canvas = null;
        Shatter.ctx = null;
        Shatter.parts = [];
      }, 600);
    },
    reset() {
      Shatter.state = 'intact';
      if (Shatter.canvas) Shatter.canvas.remove();
      if (Shatter.raf) cancelAnimationFrame(Shatter.raf);
      Shatter.canvas = null;
      Shatter.ctx = null;
      Shatter.parts = [];
      if (Shatter.target) Shatter.target.style.opacity = '1';
    }
  };

  /* =========================================================
     PHYSICS — uses left/top, no transform conflict
     ========================================================= */
  const Physics = {
    active: false, vy: 0, vx: 0, raf: null,
    start() {
      if (!isOn('physics')) return;
      if (Physics.active) return;
      const wrap = $('shapeWrap');
      if (!wrap) return;

      document.body.classList.add('physics-mode');
      const rect = wrap.getBoundingClientRect();
      wrap.style.position = 'fixed';
      wrap.style.left = rect.left + 'px';
      wrap.style.top = rect.top + 'px';
      wrap.style.transform = 'translate(-50%, -50%)';

      Physics.active = true;
      Physics.vy = 0;
      Physics.vx = 0;
      Physics.loop(wrap);
      toast('🌍 Physics on');
    },
    loop(wrap) {
      if (!Physics.active || !wrap || !document.body.contains(wrap)) {
        Physics.active = false;
        return;
      }
      Physics.raf = requestAnimationFrame(() => Physics.loop(wrap));
      const W = wrap.offsetWidth || 160;
      const H = wrap.offsetHeight || 160;
      let left = parseFloat(wrap.style.left) || 0;
      let top = parseFloat(wrap.style.top) || 0;

      Physics.vy += 0.6;
      left += Physics.vx;
      top += Physics.vy;

      const minX = 20;
      const maxX = window.innerWidth - W - 20;
      const minY = 80;
      const maxY = window.innerHeight - H - 40;

      if (left < minX) { left = minX; Physics.vx = Math.abs(Physics.vx) * 0.6; }
      if (left > maxX) { left = maxX; Physics.vx = -Math.abs(Physics.vx) * 0.6; }
      if (top > maxY) {
        top = maxY;
        Physics.vy = -Math.abs(Physics.vy) * 0.45;
        if (Math.abs(Physics.vy) < 1.5) Physics.vy = 0;
      }
      if (top < minY) { top = minY; Physics.vy = Math.abs(Physics.vy) * 0.5; }
      Physics.vx *= 0.99;

      wrap.style.left = left + 'px';
      wrap.style.top = top + 'px';
    },
    stop() {
      Physics.active = false;
      document.body.classList.remove('physics-mode');
      if (Physics.raf) cancelAnimationFrame(Physics.raf);
      const wrap = $('shapeWrap');
      if (wrap) {
        wrap.style.left = '';
        wrap.style.top = '';
        wrap.style.position = '';
        wrap.style.transform = '';
      }
    }
  };

  /* =========================================================
     TILT TO ROLL
     ========================================================= */
  const TiltRoll = {
    active: false, handler: null,
    start() {
      if (!isOn('tiltRoll') || !window.DeviceOrientationEvent) return;
      if (TiltRoll.active) return;
      TiltRoll.active = true;
      TiltRoll.handler = (e) => {
        const wrap = $('shapeWrap');
        if (!wrap) return;
        const gx = clamp((e.gamma || 0) / 45, -1, 1);
        wrap.style.filter = 'drop-shadow(' + (gx * 30) + 'px 10px 30px rgba(139,124,255,.6))';
      };
      window.addEventListener('deviceorientation', TiltRoll.handler);
      toast('📱 Tilt to roll enabled');
    },
    stop() {
      TiltRoll.active = false;
      if (TiltRoll.handler) window.removeEventListener('deviceorientation', TiltRoll.handler);
      const wrap = $('shapeWrap');
      if (wrap) wrap.style.filter = '';
    }
  };

  /* =========================================================
     SHAKE TO EXPLODE
     ========================================================= */
  const ShakeExplode = {
    active: false, handler: null, lastX: 0, lastY: 0, lastZ: 0, lastShake: 0,
    start() {
      if (!isOn('shakeExplode')) return;
      if (ShakeExplode.active) return;
      ShakeExplode.active = true;
      ShakeExplode.handler = (e) => {
        const a = e.accelerationIncludingGravity || {};
        const ax = a.x || 0, ay = a.y || 0, az = a.z || 0;
        const dx = Math.abs(ax - ShakeExplode.lastX);
        const dy = Math.abs(ay - ShakeExplode.lastY);
        const dz = Math.abs(az - ShakeExplode.lastZ);
        ShakeExplode.lastX = ax;
        ShakeExplode.lastY = ay;
        ShakeExplode.lastZ = az;
        if (dx + dy + dz > 30) {
          const now = Date.now();
          if (now - ShakeExplode.lastShake > 1000) {
            ShakeExplode.lastShake = now;
            if (Shatter.state === 'intact') Shatter.trigger($('shapeWrap'));
            else if (Shatter.state === 'shattered') Shatter.reform();
          }
        }
      };
      window.addEventListener('devicemotion', ShakeExplode.handler);
      toast('📳 Shake detection on');
    },
    stop() {
      ShakeExplode.active = false;
      if (ShakeExplode.handler) window.removeEventListener('devicemotion', ShakeExplode.handler);
    }
  };

  /* =========================================================
     BREATHING
     ========================================================= */
  const Breathing = {
    active: false, anim: null,
    start() {
      if (!isOn('breathing')) return;
      if (Breathing.active) return;
      const wrap = $('shapeWrap');
      if (!wrap) return;
      Breathing.active = true;
      try {
        Breathing.anim = wrap.animate([
          { transform: (wrap.style.transform || '') + ' scale(1)' },
          { transform: (wrap.style.transform || '') + ' scale(1.08)' },
          { transform: (wrap.style.transform || '') + ' scale(1)' }
        ], { duration: 4000, iterations: Infinity, easing: 'ease-in-out' });
      } catch (e) {}
    },
    stop() {
      Breathing.active = false;
      if (Breathing.anim) { try { Breathing.anim.cancel(); } catch (e) {} Breathing.anim = null; }
    }
  };

  /* =========================================================
     STAGE FLOATING BUTTONS
     ========================================================= */
  function addStageButton(id, icon, title, bottom, onClick) {
    const stage = $('stage');
    if (!stage || $(id)) return;
    const btn = mk('button', 'stage-float-btn', '');
    btn.id = id;
    btn.title = title;
    btn.style.position = 'fixed';
    btn.style.right = '20px';
    btn.style.bottom = bottom + 'px';
    btn.style.width = '48px';
    btn.style.height = '48px';
    btn.style.borderRadius = '50%';
    btn.style.border = '1px solid rgba(255,255,255,.15)';
    btn.style.background = 'rgba(20,22,32,.85)';
    btn.style.color = '#f5f7ff';
    btn.style.fontSize = '20px';
    btn.style.cursor = 'pointer';
    btn.style.display = 'flex';
    btn.style.alignItems = 'center';
    btn.style.justifyContent = 'center';
    btn.style.zIndex = '55';
    btn.innerHTML = icon;
    btn.addEventListener('click', onClick);
    stage.appendChild(btn);
  }

  function installStageButtons() {
    if (isOn('photoMode')) {
      addStageButton('afPhotoBtn', '📸', 'Save photo', 140, () => {
        const canvas = $('shapeCanvas');
        if (!canvas) return;
        const a = document.createElement('a');
        a.download = 'shape-' + Date.now() + '.png';
        a.href = canvas.toDataURL('image/png');
        a.click();
        toast('📸 Saved');
      });
    }
    if (isOn('exportPng')) {
      addStageButton('afExportBtn', '⬇', 'Export PNG', 200, () => {
        const canvas = $('shapeCanvas');
        if (!canvas) return;
        const a = document.createElement('a');
        a.download = 'export-' + Date.now() + '.png';
        a.href = canvas.toDataURL('image/png');
        a.click();
        toast('⬇ Exported');
      });
    }
    if (isOn('zenMode')) {
      addStageButton('afZenBtn', '🧘', 'Zen mode', 260, () => {
        document.body.classList.toggle('zen-mode');
      });
    }
    if (isOn('arMode')) {
      addStageButton('afARBtn', '📱', 'AR mode', 320, async () => {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
          const video = mk('video', '', 'position:fixed;inset:0;width:100%;height:100%;object-fit:cover;z-index:1');
          video.autoplay = true;
          video.playsInline = true;
          video.muted = true;
          video.srcObject = stream;
          const stage = $('stage');
          if (stage) stage.insertBefore(video, stage.firstChild);
          toast('📱 AR mode');
          setTimeout(() => {
            video.remove();
            stream.getTracks().forEach(t => t.stop());
          }, 30000);
        } catch (e) { toast('Camera denied'); }
      });
    }
    if (isOn('scratchReveal')) {
      addStageButton('afScratchBtn', '✋', 'Scratch reveal', 380, () => {
        const stage = $('stage');
        if (!stage) return;
        const fog = mk('div', '', 'position:fixed;inset:0;z-index:8;background:rgba(60,60,80,.85);pointer-events:none;transition:opacity 1s');
        stage.appendChild(fog);
        toast('Scratch the fog');
        let n = 0;
        const h = () => {
          n++;
          fog.style.opacity = Math.max(0, 1 - n / 50);
          if (n >= 50) {
            fog.remove();
            document.removeEventListener('pointermove', h);
          }
        };
        document.addEventListener('pointermove', h);
      });
    }
    if (isOn('recordReplay')) {
      let recorder = null, chunks = [];
      addStageButton('afRecordBtn', '🔴', 'Record', 440, async () => {
        if (recorder) {
          recorder.stop();
          recorder = null;
          return;
        }
        try {
          const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
          recorder = new MediaRecorder(stream);
          chunks = [];
          recorder.ondataavailable = (e) => chunks.push(e.data);
          recorder.onstop = () => {
            const blob = new Blob(chunks, { type: 'video/webm' });
            const a = document.createElement('a');
            a.download = 'session-' + Date.now() + '.webm';
            a.href = URL.createObjectURL(blob);
            a.click();
            stream.getTracks().forEach(t => t.stop());
            toast('🎬 Video saved');
          };
          recorder.start();
          toast('🔴 Recording');
        } catch (e) { toast('Denied'); }
      });
    }
  }

  /* =========================================================
     FPS OVERLAY
     ========================================================= */
  const FpsOverlay = {
    el: null, frames: 0, last: performance.now(), active: false,
    start() {
      if (!isOn('fpsOverlay')) return;
      if (FpsOverlay.active) return;
      FpsOverlay.active = true;
      if (!FpsOverlay.el) {
        FpsOverlay.el = mk('div', '', 'position:fixed;top:14px;left:14px;z-index:9999;background:rgba(0,0,0,.8);border:1px solid rgba(77,212,255,.4);border-radius:8px;padding:6px 12px;color:#4dd4ff;font-family:monospace;font-size:11px;font-weight:700;pointer-events:none;');
        FpsOverlay.el.textContent = '— fps';
        document.body.appendChild(FpsOverlay.el);
      }
      FpsOverlay.loop();
    },
    loop() {
      if (!FpsOverlay.active) return;
      requestAnimationFrame(() => FpsOverlay.loop());
      FpsOverlay.frames++;
      const now = performance.now();
      if (now - FpsOverlay.last >= 500) {
        const fps = Math.round((FpsOverlay.frames * 1000) / (now - FpsOverlay.last));
        if (FpsOverlay.el) FpsOverlay.el.textContent = fps + ' fps';
        FpsOverlay.frames = 0;
        FpsOverlay.last = now;
      }
    },
    stop() {
      FpsOverlay.active = false;
      if (FpsOverlay.el) { FpsOverlay.el.remove(); FpsOverlay.el = null; }
    }
  };

  /* =========================================================
     COMMAND PALETTE
     ========================================================= */
  const CommandPalette = {
    open: false,
    show() {
      if (CommandPalette.open) return;
      CommandPalette.open = true;
      const cmds = [
        { label: '🏠 Go Home', action: () => location.href = 'index.html' },
        { label: '⚙️ Settings', action: () => location.href = 'settings.html#settings' },
        { label: '📊 Dashboard', action: () => location.href = 'settings.html#dashboard' },
        { label: '🎲 Random Shape', action: () => {
          const idx = Math.floor(Math.random() * shapes.length);
          const c = document.querySelector('.shape-card[data-shape-index="' + idx + '"]');
          if (c) c.click();
        }},
        { label: '💥 Shatter', action: () => Shatter.trigger($('shapeWrap')) },
        { label: '✨ Reform', action: () => Shatter.reform() }
      ];
      const overlay = mk('div', '', 'position:fixed;inset:0;z-index:10000;background:rgba(5,6,13,.94);backdrop-filter:blur(20px);display:flex;align-items:flex-start;justify-content:center;padding:80px 20px;');
      overlay.innerHTML =
        '<div style="width:100%;max-width:560px;">' +
          '<input id="afCmdInput" placeholder="Type a command…" style="width:100%;padding:16px 20px;border-radius:16px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.05);color:#f5f7ff;font-family:inherit;font-size:15px;outline:none;margin-bottom:12px;">' +
          '<div id="afCmdList" style="max-height:60vh;overflow-y:auto;border-radius:16px;border:1px solid rgba(255,255,255,.08);background:#0d0f18;padding:6px;"></div>' +
        '</div>';
      document.body.appendChild(overlay);
      const input = $('afCmdInput');
      const list = $('afCmdList');
      let filtered = cmds.slice();
      let selected = 0;

      function render() {
        if (!list) return;
        list.innerHTML = filtered.map((c, i) =>
          '<div data-i="' + i + '" style="padding:12px 16px;border-radius:10px;cursor:pointer;color:#f5f7ff;font-family:Inter,sans-serif;font-size:13.5px;' + (i === selected ? 'background:rgba(139,124,255,.15);' : '') + '">' + c.label + '</div>'
        ).join('');
        list.querySelectorAll('div[data-i]').forEach(d => {
          d.addEventListener('click', () => {
            filtered[parseInt(d.dataset.i, 10)].action();
            close();
          });
        });
      }
      function close() {
        overlay.remove();
        CommandPalette.open = false;
      }
      if (input) {
        input.addEventListener('input', () => {
          const q = input.value.toLowerCase();
          filtered = cmds.filter(c => c.label.toLowerCase().indexOf(q) >= 0);
          selected = 0;
          render();
        });
        input.addEventListener('keydown', (e) => {
          if (e.key === 'ArrowDown') { selected = Math.min(filtered.length - 1, selected + 1); render(); }
          else if (e.key === 'ArrowUp') { selected = Math.max(0, selected - 1); render(); }
          else if (e.key === 'Enter') { if (filtered[selected]) { filtered[selected].action(); close(); } }
          else if (e.key === 'Escape') close();
        });
        setTimeout(() => { try { input.focus(); } catch (e) {} }, 50);
      }
      overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
      render();
    }
  };

  /* =========================================================
     CHAOS + MOOD
     ========================================================= */
  function installChaosButton() {
    if (!isOn('chaosGenerator') || $('afChaosBtn')) return;
    const btn = mk('button', '', 'position:fixed;bottom:82px;left:18px;z-index:44;padding:11px 18px;border-radius:999px;border:none;background:linear-gradient(135deg,#ff5cb8,#ffd45c);color:#fff;font-family:inherit;font-size:12.5px;font-weight:700;cursor:pointer;box-shadow:0 15px 40px -10px rgba(255,92,184,.7);');
    btn.id = 'afChaosBtn';
    btn.textContent = '🎲 Chaos';
    btn.addEventListener('click', () => {
      const idx = Math.floor(Math.random() * shapes.length);
      const c = document.querySelector('.shape-card[data-shape-index="' + idx + '"]');
      if (c) c.click();
      setTimeout(() => {
        const cp = $('colorPicker');
        if (cp && palette.length) {
          cp.value = palette[Math.floor(Math.random() * palette.length)];
          cp.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }, 300);
      toast('🎲 Chaos!');
    });
    document.body.appendChild(btn);
  }

  function installMoodButton() {
    if (!isOn('moodRecommender') || $('afMoodBtn')) return;
    const btn = mk('button', '', 'position:fixed;bottom:130px;left:18px;z-index:44;padding:11px 18px;border-radius:999px;border:1px solid rgba(255,255,255,.15);background:rgba(20,22,32,.9);color:#f5f7ff;font-family:inherit;font-size:12.5px;font-weight:600;cursor:pointer;');
    btn.id = 'afMoodBtn';
    btn.textContent = '😊 Mood';
    btn.addEventListener('click', () => {
      const moods = [
        { emoji: '😊', label: 'Happy', color: '#ffd45c' },
        { emoji: '😌', label: 'Calm', color: '#4dd4ff' },
        { emoji: '⚡', label: 'Energetic', color: '#ff5c8c' },
        { emoji: '😢', label: 'Sad', color: '#8b7cff' },
        { emoji: '🎨', label: 'Creative', color: '#5cff8c' }
      ];
      const mood = moods[Math.floor(Math.random() * moods.length)];
      const idx = Math.floor(Math.random() * shapes.length);
      const c = document.querySelector('.shape-card[data-shape-index="' + idx + '"]');
      if (c) c.click();
      setTimeout(() => {
        const cp = $('colorPicker');
        if (cp) {
          cp.value = mood.color;
          cp.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }, 300);
      toast(mood.emoji + ' ' + mood.label);
    });
    document.body.appendChild(btn);
  }

  /* =========================================================
     EASTER EGGS
     ========================================================= */
  function installEasterEggs() {
    if (!isOn('easterEggs')) return;
    let count = 0, timer = null;
    document.addEventListener('pointerdown', () => {
      count++;
      clearTimeout(timer);
      timer = setTimeout(() => { count = 0; }, 1500);
      if (count === 3) {
        count = 0;
        toast('🥚 Easter egg!');
      }
    });
  }

  /* =========================================================
     BLEND MODES / SNAP GRID / QUICK PRESETS
     ========================================================= */
  function installBlendModes() {
    if (!isOn('blendModes')) return;
    const c = $('shapeCanvas');
    if (c && c.parentElement) c.parentElement.style.mixBlendMode = 'screen';
  }

  function installQuickPresets() {
    if (!isOn('quickPresets')) return;
    const editor = document.querySelector('#editorPage .editor-inner');
    if (!editor || $('afPresets')) return;
    const box = mk('div', 'control-section');
    box.id = 'afPresets';
    box.innerHTML =
      '<div class="control-head"><div class="control-label">Quick Presets</div></div>' +
      '<div style="display:flex;gap:8px;flex-wrap:wrap;">' +
        '<button class="preset-btn" data-p="fine">✨ Fine</button>' +
        '<button class="preset-btn" data-p="bold">🔵 Bold</button>' +
        '<button class="preset-btn" data-p="dense">🌫 Dense</button>' +
        '<button class="preset-btn" data-p="sparse">💨 Sparse</button>' +
        '<button class="preset-btn" data-p="glowy">🌟 Glowy</button>' +
      '</div>';
    const actions = document.querySelector('#editorPage .editor-actions');
    if (actions && actions.parentNode) actions.parentNode.insertBefore(box, actions);
    else editor.appendChild(box);

    const presets = {
      fine: { d: 4500, s: 1.0, g: 30 },
      bold: { d: 1800, s: 3.0, g: 70 },
      dense: { d: 6000, s: 1.2, g: 50 },
      sparse: { d: 800, s: 2.0, g: 40 },
      glowy: { d: 3000, s: 2.0, g: 90 }
    };
    box.querySelectorAll('.preset-btn').forEach(b => {
      b.addEventListener('click', () => {
        const v = presets[b.dataset.p];
        const set = (id, val) => {
          const e = $(id);
          if (e) {
            e.value = val;
            e.dispatchEvent(new Event('input', { bubbles: true }));
          }
        };
        set('densitySlider', v.d);
        set('dotSizeSlider', v.s);
        set('glowSlider', v.g);
      });
    });
  }

  /* =========================================================
     CAMERA SHAPE (loader)
     ========================================================= */
  function installCameraShape() {
    if (!isOn('cameraShape')) return;
    const loaders = document.querySelector('.loaders-grid');
    if (!loaders || $('afCamLoader')) return;
    const card = mk('div', 'loader-card');
    card.id = 'afCamLoader';
    card.innerHTML =
      '<div class="loader-icon">📷</div>' +
      '<div class="loader-title">Camera Shape</div>' +
      '<div class="loader-desc">Capture a photo → turn it into a shape</div>' +
      '<button class="loader-btn" id="afCamBtn">Open Camera</button>';
    loaders.appendChild(card);
    const camBtn = $('afCamBtn');
    if (camBtn) camBtn.addEventListener('click', async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        const video = mk('video', '', 'position:fixed;inset:0;z-index:9999;background:#000;object-fit:cover;width:100%;height:100%');
        video.playsInline = true;
        video.muted = true;
        video.autoplay = true;
        video.srcObject = stream;
        document.body.appendChild(video);
        const shutter = mk('button', '', 'position:fixed;bottom:40px;left:50%;transform:translateX(-50%);z-index:10000;padding:16px 32px;border-radius:999px;border:none;background:linear-gradient(135deg,#8b7cff,#4dd4ff);color:#fff;font-family:inherit;font-size:16px;font-weight:700;cursor:pointer;');
        shutter.textContent = '📸 Capture';
        document.body.appendChild(shutter);
        shutter.addEventListener('click', () => {
          try {
            const canvas = mk('canvas');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            canvas.getContext('2d').drawImage(video, 0, 0);
            stream.getTracks().forEach(t => t.stop());
            video.remove();
            shutter.remove();
            toast('📸 Captured');
          } catch (e) {}
        });
      } catch (e) { toast('Camera denied'); }
    });
  }

  /* =========================================================
     BATTERY AWARE
     ========================================================= */
  function installBattery() {
    if (!isOn('batteryAware') || !navigator.getBattery) return;
    try {
      navigator.getBattery().then(b => {
        if (b.level < 0.2 && !b.charging) {
          settings.quality = 'low';
          try { localStorage.setItem('s_quality', 'low'); } catch (e) {}
          if (S.QUALITY_CFG) S.qualityCfg = S.QUALITY_CFG.low;
          toast('🔋 Low battery — quality reduced');
        }
      }).catch(() => {});
    } catch (e) {}
  }

  /* =========================================================
     SETTINGS — feature toggles
     ========================================================= */
  function installSettingsToggles() {
    const container = $('settingsInner');
    if (!container || $('afFeatureSection')) return;
    if (!S.FEATURES) return;

    const A = Object.keys(S.FEATURES).filter(k => S.FEATURES[k].group === 'A');
    const B = Object.keys(S.FEATURES).filter(k => S.FEATURES[k].group === 'B');

    function row(k) {
      const f = S.FEATURES[k];
      const on = isOn(k);
      return '<div class="toggle-row"><div><div class="toggle-name">' + f.label + '</div><div class="toggle-desc">' + f.desc + '</div></div><div class="toggle-switch ' + (on ? 'on' : '') + '" data-feature="' + k + '"></div></div>';
    }

    const sec = mk('div');
    sec.id = 'afFeatureSection';
    sec.innerHTML =
      '<div class="setting-group-title">✨ Experience</div>' +
      '<div class="info-box">ON by default. Turn off if you don\'t want them.</div>' +
      '<div class="toggle-list">' + A.map(row).join('') + '</div>' +
      '<div class="setting-group-title">🔓 Advanced Features</div>' +
      '<div class="info-box warn">OFF by default. Turn on only what you need.</div>' +
      '<div class="toggle-list">' + B.map(row).join('') + '</div>';
    container.insertBefore(sec, container.firstChild);

    sec.querySelectorAll('[data-feature]').forEach(el => {
      el.addEventListener('click', () => {
        const k = el.dataset.feature;
        const v = !isOn(k);
        if (typeof S.setFeature === 'function') S.setFeature(k, v);
        el.classList.toggle('on', v);
        toast(S.FEATURES[k].label + ' ' + (v ? 'ON' : 'OFF'));
      });
    });
  }

  /* =========================================================
     BOOT
     ========================================================= */
  function boot() {
    const isHome = !!$('page-home');
    const isSettings = !!$('page-settings');
    const stage = $('stage');

    if (isHome) {
      setTimeout(showOnboarding, 800);
      setTimeout(() => {
        renderShapeOfDay();
        $$('.shape-card').forEach(c => Favorites.decorateCard(c));
        Favorites.renderHomeSection();
        SavedLooks.renderHomeSection();
        installChaosButton();
        installMoodButton();
        installCameraShape();
      }, 500);
    }

    if (isSettings) {
      installSettingsToggles();
    }

    if (stage) {
      const observer = new MutationObserver(() => {
        if (stage.classList.contains('active')) {
          setTimeout(() => {
            Trails.start(stage);
            BgParticles.start(stage);
            Glitch.start($('shapeWrap'));
            installStageButtons();
            if (isOn('physics')) Physics.start();
            if (isOn('tiltRoll')) TiltRoll.start();
            if (isOn('shakeExplode')) ShakeExplode.start();
            if (isOn('breathing')) Breathing.start();
            if (isOn('blendModes')) installBlendModes();
          }, 200);
        } else {
          Trails.stop();
          BgParticles.stop();
          Glitch.stop();
          Physics.stop();
          TiltRoll.stop();
          ShakeExplode.stop();
          Breathing.stop();
          Shatter.reset();
          document.body.classList.remove('zen-mode');
        }
      });
      observer.observe(stage, { attributes: true, attributeFilter: ['class'] });

      /* 4-finger tap → shatter */
      stage.addEventListener('touchstart', (e) => {
        if (!isOn('shatter') || e.touches.length !== 4) return;
        const now = Date.now();
        stage._taps = stage._taps || [];
        stage._taps = stage._taps.filter(t => now - t < 1200);
        stage._taps.push(now);
        if (stage._taps.length === 3 && Shatter.state === 'intact') {
          Shatter.trigger($('shapeWrap'));
          stage._taps = [];
        } else if (stage._taps.length === 4 && Shatter.state === 'shattered') {
          Shatter.reform();
          stage._taps = [];
        }
      }, { passive: true });

      /* Trail emit on drag */
      stage.addEventListener('pointermove', (e) => {
        if (Trails.active) Trails.emit(e.clientX, e.clientY, '#8b7cff');
      });
    }

    /* Keyboard shortcuts */
    document.addEventListener('keydown', (e) => {
      if (!stage || !stage.classList.contains('active')) return;
      if (e.ctrlKey && e.shiftKey && e.key === '4') {
        e.preventDefault();
        Shatter.trigger($('shapeWrap'));
      } else if (e.ctrlKey && e.shiftKey && e.key === '5') {
        e.preventDefault();
        Shatter.reform();
      }
    });

    document.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k' && isOn('commandPalette')) {
        const so = $('searchOverlay');
        if (so && so.classList.contains('open')) return;
        e.preventDefault();
        CommandPalette.show();
      }
    });

    installEasterEggs();
    FpsOverlay.start();
    installBattery();
    installQuickPresets();

    window.addEventListener('featurechange', (e) => {
      const d = e.detail || {};
      if (d.key === 'fpsOverlay') {
        if (d.value) FpsOverlay.start();
        else FpsOverlay.stop();
      }
      if (stage && stage.classList.contains('active')) {
        if (d.key === 'particleTrails') { d.value ? Trails.start(stage) : Trails.stop(); }
        if (d.key === 'bgParticles') { d.value ? BgParticles.start(stage) : BgParticles.stop(); }
      }
    });

    if (isOn('fpsOverlay')) FpsOverlay.start();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();