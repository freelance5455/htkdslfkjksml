# Raja Travel Agency Manager

A lightweight offline-first travel agency ticketing and ledger app for mobile and laptop browsers.

## Start using
1. Extract `Raja_Travel_Agency_Manager.zip`.
2. Open `index.html` in Chrome, Edge, Firefox, or another modern browser.
3. Login as Admin: username `admin`, password `Raja@123`.
4. Change the Admin password from the top button.
5. In Agencies, create separate agency accounts. Give each agency its own username/password.
6. Each agency login sees only that agency's tickets and payments in the app UI.

Default sample agency login: `raja` / `Raja@123`.

## Features
- Multiple agency accounts and separate ticketing ledgers
- Ticket number, passenger, route, travel date, supplier
- Purchase price, sale price, profit, payments and due balance
- Bill view, print / Save as PDF, WhatsApp share text
- Agency summary and reports
- Manual JSON backup and restore
- Responsive layout for phone and laptop

## Important offline and security notes
- Data is stored locally in the browser on the current device. No server is used.
- Mobile and laptop do NOT automatically sync with each other. Use Manual Backup on one device and Restore Backup on the other to transfer data. Avoid editing the same backup independently on both devices unless you understand which copy is newer.
- WhatsApp sharing needs an internet connection and WhatsApp access.
- Browser local storage is not a secure multi-user server. This is a practical offline starter project, not a hardened hosted system. Anyone with access to the same browser profile may potentially access local data. Use device passwords and regular backups.
- Do not clear browser data before making a backup.
- To start with an empty business dataset, make a backup first, then use a fresh browser profile. The default Raja agency is included as a starter account.

## Recommended backup routine
Use `Manual Backup` every day or after important changes. Store the downloaded `.json` file somewhere safe. To restore, click `Restore Backup` and select the backup file. Restoring replaces the current local data.

## Technical
The app is a single-file HTML/CSS/JavaScript application and does not require installation, a build tool, or an internet connection to open and use its core functions.
