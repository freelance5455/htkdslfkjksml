# APKZ

App Android com uma **bolinha verde com espinhos** (inspirado no MHZ) que transforma o **zip de um projeto em APK**: você escolhe o zip e o **bundle identifier**, e ele cuida do resto.

Versão atual: **v.07** (o nome do zip e o `versionName` mudam a cada atualização — veja `CHANGELOG.md`).

## Como funciona
O celular não consegue rodar um build do Gradle. Por isso o APKZ usa o **GitHub Actions** da sua própria conta (grátis; repositório privado tem uns 2000 min/mês):
1. limpa o zip (sem `build/`, `node_modules/`, `.git/`...);
2. envia para o seu repositório e dispara o workflow;
3. o workflow troca o bundle identifier (`applicationId` no Android, `android.package` no Expo), compila e publica o APK;
4. o APKZ acompanha, baixa o APK e deixa pronto para instalar.

## Antes de usar (uma vez só)
1. No GitHub, crie um **repositório só para o APKZ**, com um README (pode ser privado).
2. Crie um **token** com acesso a esse repositório:
   - *fine-grained*: Contents, Actions e Workflows com leitura e escrita (Metadata só leitura); ou
   - *clássico*: marque `repo` e `workflow`.
3. No APKZ, **Passo 1**: escreva `usuario/repositorio`, cole o token e toque em **Salvar e preparar o repositório**. Ele envia o workflow e o script de build.

## Como usar
1. **Passo 2:** "Escolher zip", confira o relatório e ajuste o **bundle identifier** (vem preenchido com o do projeto; vazio = não mexe).
2. **Passo 3:** "Transformar em APK". Deixe o app aberto (a tela fica ligada). Leva alguns minutos.
3. **Passo 4:** "Instalar". Na primeira vez, o Android pede para permitir que o APKZ instale apps.
- **Extra:** "Gerar zip limpo" salva só o zip limpo, sem compilar.

## O que é compilado
- **Android nativo (Gradle):** `assembleDebug` (assinado com a chave de debug, então o Android aceita instalar). Só o `applicationId` é trocado; o `namespace` e o código continuam iguais.
- **Expo:** `expo prebuild` + `assembleRelease` (o template do Expo assina com a chave de debug). Instala só com **Bun 1.4.3** (`bun install --frozen-lockfile`, com o `bun.lock` no zip); lockfiles de npm, pnpm e yarn não são usados. Sem `app.json`, não dá para trocar o identificador. **Esta parte é a menos testada.**

## Limites
- Zip limpo de até ~70 MB (limite da API do GitHub).
- O APK é de debug/teste, não serve para publicar na Play Store.
- O token fica guardado só neste aparelho, no armazenamento privado do app. Use um token restrito a esse repositório.
- Se o build falhar, o APKZ mostra um botão **Abrir no GitHub** com o log.

## Fonte
Usa a fonte **Go Eagles** (Iconian Fonts, Daniel Zadorozny), em `app/src/main/assets/fonts/`. Gratuita só para **uso não comercial** (veja `LICENSE_GoEagles.txt`).

## Estrutura
- `MainActivity`: a tela, com os passos e a instalação
- `GitHub`: cliente da API do GitHub (enviar, disparar, acompanhar, baixar)
- `ZipTools`: análise do zip e geração do zip limpo (não depende do Android)
- `SpikyBubbleView`: o desenho da bolinha/logotipo APKZ
- `Fonts`: carrega a Go Eagles
- `assets/github/apkz.yml` e `apkz-build.sh`: workflow e script que o APKZ envia ao seu repositório
- `index.html`: página de apresentação do projeto (abre no navegador, sem internet)
