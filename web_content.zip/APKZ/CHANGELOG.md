# Histórico de versões

Regra: a cada atualização muda a versão: o zip (`APKZ_v.02.zip`...), `versionName` e `versionCode` em `app/build.gradle`.

## v.07
- Novo `index.html` na raiz do projeto: página de apresentação do APKZ (como funciona, como usar, limites e estrutura), no tema verde. Abre direto no navegador. Não muda o app nem o build.

## v.06
- **O APK não se perde mais:** ao terminar o build, o APKZ guarda uma cópia no próprio app e, no Android 10 ou mais novo, outra em **Downloads** (sem pedir permissão). Ao reabrir o app, o último APK gerado aparece de volta no passo 4.
- Antes o APK ficava só na pasta de cache, que o Android pode apagar, e sumia da tela ao fechar o app.
- O APK no GitHub (artefato do build) passou a ficar **3 dias** em vez de 1. Precisa apertar o botão do passo 1 de novo para enviar o workflow novo.
- **Limite:** se você fechar o APKZ **durante** o build, o GitHub continua compilando, mas o APKZ não baixa sozinho.
- **Atenção:** não foi compilado nem testado num aparelho.

## v.05
- **Fim do build:** quando o APK fica pronto, aparece uma pergunta: **Instalar**, **Salvar numa pasta** ou **Depois**.
- Novo botão **Salvar APK em uma pasta** no passo 4: abre os arquivos do aparelho, você escolhe a pasta (e o nome) e o APK é gravado lá. Funciona também com um APK escolhido de arquivo.
- **Atenção:** esta mudança não foi compilada nem testada num aparelho. Se o Gradle reclamar, cole o erro.

## v.04
- **Expo com Bun 1.4.3:** o workflow instala o Bun 1.4.3 (`oven-sh/setup-bun`) e o script de build usa `bun install --frozen-lockfile` e `bunx expo prebuild`. Saem `npm`, `yarn` e `npx`.
- O relatório do zip agora pede `bun.lock` e avisa que lockfiles de npm, pnpm e yarn não são usados.
- **Importante:** quem já preparou o repositório precisa apertar o botão de preparar de novo (passo 1) para enviar o workflow e o script novos.

## v.03
- **Corrige o erro do build no GitHub:** o passo "Setup Android SDK" falhava com `Failed to find package 'tools'`. O workflow (`assets/github/apkz.yml`) agora pede só `platform-tools`.
- **Importante:** quem já preparou o repositório precisa apertar o botão de preparar de novo (passo 1) para enviar o workflow corrigido, ou trocar o `uses: android-actions/setup-android@v3` do `.github/workflows/apkz.yml` no GitHub por esse mesmo passo com `packages: platform-tools`.

## v.02
**Atenção:** a parte nova (GitHub + tela) foi feita sem o Android SDK e **não foi compilada nem testada contra o GitHub de verdade**. Se o Gradle reclamar ou o build falhar, cole o erro e eu corrijo. Testado de verdade: o script de build (troca do identificador, em Gradle Groovy, Kotlin DSL e Expo) e o `ZipTools`.

- **Transformar em APK de ponta a ponta:** escolhe o zip, digita o **bundle identifier** e o APKZ limpa o zip, envia ao seu repositório do GitHub, dispara o build (GitHub Actions), acompanha e baixa o APK.
- Campo de **bundle identifier**, preenchido com o do projeto (`ZipTools.Report.pkg`).
- Passo 1 novo: repositório + token do GitHub e botão que prepara o repositório (envia workflow e script).
- O zip enviado é apagado do repositório no fim do build.
- Passo 4 instala o APK que veio do build. "Gerar zip limpo" virou um extra.
- Nova permissão: `INTERNET`.

## v.01
- Primeira versão: tema **verde**, bolinha com espinhos, fonte Go Eagles e ícone APKZ.
- Ler o zip e mostrar o relatório, gerar o zip limpo e instalar um APK escolhido.
