#!/usr/bin/env bash
# APKZ: descompacta o zip do job, troca o bundle identifier, compila e deixa o APK em out/app.apk
set -euo pipefail

JOB="${1:?faltou o job}"
PKG="${2:-}"
ROOT="$PWD"
ZIP="$ROOT/jobs/$JOB/project.zip"
WORK="$ROOT/work"
OUT="$ROOT/out"

[ -f "$ZIP" ] || { echo "Zip não encontrado: jobs/$JOB/project.zip"; exit 1; }

if [ -n "$PKG" ] && ! [[ "$PKG" =~ ^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$ ]]; then
  echo "Bundle identifier inválido: $PKG (use algo como com.exemplo.app)"
  exit 1
fi

rm -rf "$WORK" "$OUT"
mkdir -p "$WORK" "$OUT"
unzip -q "$ZIP" -d "$WORK"
cd "$WORK"

# se o projeto veio dentro de uma pasta, entra nela
if [ ! -e settings.gradle ] && [ ! -e settings.gradle.kts ] && [ ! -e package.json ]; then
  found="$(find . -maxdepth 3 \( -name settings.gradle -o -name settings.gradle.kts -o -name package.json \) -not -path '*/node_modules/*' | head -1)"
  [ -n "$found" ] || { echo "Não achei settings.gradle nem package.json no zip."; exit 1; }
  cd "$(dirname "$found")"
fi
echo "Projeto em: $PWD"

if [ -e settings.gradle ] || [ -e settings.gradle.kts ]; then
  echo "== Android nativo (Gradle)"
  if [ -n "$PKG" ]; then
    mod="$(grep -rlE --include=build.gradle --include=build.gradle.kts 'applicationId' . | head -1 || true)"
    [ -n "$mod" ] || { echo "Não achei applicationId em nenhum build.gradle."; exit 1; }
    sed -E -i "s/(applicationId[[:space:]]*=?[[:space:]]*)[\"'][^\"']+[\"']/\1\"$PKG\"/" "$mod"
    echo "applicationId trocado em $mod:"
    grep -n applicationId "$mod"
  fi
  [ -f gradlew ] || { echo "Falta o gradlew no projeto."; exit 1; }
  chmod +x gradlew
  [ "${DRY_RUN:-}" = 1 ] && { echo "DRY_RUN: parei antes de compilar."; exit 0; }
  ./gradlew --no-daemon assembleDebug
  apk="$(find . -path '*outputs/apk/debug/*.apk' | head -1)"
else
  echo "== Expo / React Native"
  if [ -n "$PKG" ]; then
    [ -f app.json ] || { echo "Para trocar o identificador, o projeto precisa de app.json."; exit 1; }
    node -e '
      const fs = require("fs");
      const j = JSON.parse(fs.readFileSync("app.json", "utf8"));
      j.expo = j.expo || {};
      j.expo.android = j.expo.android || {};
      j.expo.android.package = process.argv[1];
      fs.writeFileSync("app.json", JSON.stringify(j, null, 2));
    ' "$PKG"
    echo "android.package = $PKG"
  fi
  [ "${DRY_RUN:-}" = 1 ] && { echo "DRY_RUN: parei antes de compilar."; exit 0; }
  # Expo / React Native: só Bun 1.4.3 (lockfiles de npm, pnpm e yarn não são usados)
  echo "Bun $(bun --version)"
  if [ -f bun.lock ]; then bun install --frozen-lockfile
  else
    echo "Aviso: sem bun.lock; instalando sem lockfile (as versões podem variar)."
    bun install
  fi
  bunx expo prebuild --platform android --no-install
  cd android
  chmod +x gradlew
  ./gradlew --no-daemon assembleRelease
  apk="$(find . -path '*outputs/apk/release/*.apk' | head -1)"
fi

[ -n "${apk:-}" ] || { echo "O build terminou, mas não achei o APK."; exit 1; }
cp "$apk" "$OUT/app.apk"
echo "APK pronto: $(ls -l "$OUT/app.apk")"
