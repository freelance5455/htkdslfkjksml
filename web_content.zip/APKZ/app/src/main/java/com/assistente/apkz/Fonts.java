package com.assistente.apkz;

import android.content.Context;
import android.graphics.Typeface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/** Fonte Go Eagles do APKZ (arquivos em assets/fonts). Se falhar ao carregar, usa a fonte do sistema. */
public final class Fonts {
	private static Typeface body;
	private static Typeface title;

	private Fonts() {
	}

	/** Versão condensada: textos, botões e campos. */
	public static synchronized Typeface body(Context c) {
		if (body == null) body = load(c, "fonts/goeaglescond.ttf");
		return body;
	}

	/** Versão larga: títulos e o logotipo APKZ. */
	public static synchronized Typeface title(Context c) {
		if (title == null) title = load(c, "fonts/goeaglesstraight.ttf");
		return title;
	}

	private static Typeface load(Context c, String path) {
		try {
			return Typeface.createFromAsset(c.getApplicationContext().getAssets(), path);
		} catch (Exception e) {
			return Typeface.DEFAULT_BOLD;
		}
	}

	/** Aplica a fonte do corpo em todos os textos de uma árvore de views. */
	public static void apply(View v, Typeface tf) {
		if (v instanceof TextView) ((TextView) v).setTypeface(tf);
		if (v instanceof ViewGroup) {
			ViewGroup g = (ViewGroup) v;
			for (int i = 0; i < g.getChildCount(); i++) apply(g.getChildAt(i), tf);
		}
	}
}
