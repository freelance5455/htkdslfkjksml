package com.assistente.apkz;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.animation.ValueAnimator;
import android.graphics.Shader;
import android.view.View;

/** Logotipo do APKZ: círculo verde com espinhos e o texto APKZ no centro. */
public class SpikyBubbleView extends View {
	private static final int SPIKES = 14;

	private final Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
	private final Paint spikes = new Paint(Paint.ANTI_ALIAS_FLAG);
	private final Paint disc = new Paint(Paint.ANTI_ALIAS_FLAG);
	private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
	private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
	private final Path spikePath = new Path();
	private final Path spikeShadow = new Path();
	private final Paint pulsePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
	private ValueAnimator pulseAnim;
	private float pulse = 0f;

	public SpikyBubbleView(Context c) {
		super(c);
		shadow.setColor(0xFF0A7A2C);
		shadow.setStyle(Paint.Style.FILL);
		spikes.setStyle(Paint.Style.FILL);
		disc.setStyle(Paint.Style.FILL);
		disc.setColor(0xFF04160B);
		ring.setStyle(Paint.Style.STROKE);
		ring.setColor(0xFF5CFF8C);
		text.setColor(0xFFFFFFFF);
		text.setTextAlign(Paint.Align.CENTER);
		text.setTypeface(Fonts.title(c));
	}

	/** Liga/desliga o pulso que mostra que a MHZ está ouvindo. */
	public void setListening(boolean on) {
		if (on && pulseAnim == null) {
			pulseAnim = ValueAnimator.ofFloat(0f, 1f);
			pulseAnim.setDuration(900);
			pulseAnim.setRepeatCount(ValueAnimator.INFINITE);
			pulseAnim.addUpdateListener(a -> {
				pulse = (float) a.getAnimatedValue();
				invalidate();
			});
			pulseAnim.start();
		} else if (!on && pulseAnim != null) {
			pulseAnim.cancel();
			pulseAnim = null;
			pulse = 0f;
			invalidate();
		}
	}

	@Override
	protected void onDetachedFromWindow() {
		if (pulseAnim != null) pulseAnim.cancel();
		pulseAnim = null;
		super.onDetachedFromWindow();
	}

	private static void star(Path p, float cx, float cy, float outer, float inner) {
		p.reset();
		for (int i = 0; i < SPIKES * 2; i++) {
			double a = Math.toRadians(-90 + i * 180.0 / SPIKES);
			float r = (i % 2 == 0) ? outer : inner;
			float x = (float) (cx + r * Math.cos(a));
			float y = (float) (cy + r * Math.sin(a));
			if (i == 0) p.moveTo(x, y);
			else p.lineTo(x, y);
		}
		p.close();
	}

	@Override
	protected void onSizeChanged(int w, int h, int ow, int oh) {
		float cx = w / 2f, cy = h / 2f, half = Math.min(w, h) / 2f;
		star(spikeShadow, cx, cy, half, half * 0.70f);
		star(spikePath, cx, cy, half * 0.958f, half * 0.67f);
		spikes.setShader(new RadialGradient(cx, cy, half, new int[]{0xFF5CFF8C, 0xFF1FD65F, 0xFF0F8F38},
				new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
		ring.setStrokeWidth(Math.max(1.5f, half * 0.04f));
		text.setTextSize(half * 0.26f);
	}

	@Override
	protected void onDraw(Canvas c) {
		float cx = getWidth() / 2f, cy = getHeight() / 2f, half = Math.min(getWidth(), getHeight()) / 2f;
		c.drawPath(spikeShadow, shadow);
		c.drawPath(spikePath, spikes);
		float dr = half * 0.60f;
		c.drawCircle(cx, cy, dr, disc);
		c.drawCircle(cx, cy, dr, ring);
		Paint.FontMetrics fm = text.getFontMetrics();
		c.drawText("APKZ", cx, cy - (fm.ascent + fm.descent) / 2f, text);
		if (pulse > 0f) {
			pulsePaint.setStyle(Paint.Style.STROKE);
			pulsePaint.setStrokeWidth(Math.max(2f, half * 0.06f));
			pulsePaint.setColor(0xFFFFFFFF);
			pulsePaint.setAlpha((int) (200 * (1f - pulse)));
			c.drawCircle(cx, cy, half * (0.62f + 0.36f * pulse), pulsePaint);
		}
	}
}
