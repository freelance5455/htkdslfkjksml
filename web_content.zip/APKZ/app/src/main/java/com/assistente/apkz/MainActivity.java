package com.assistente.apkz;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.database.Cursor;
import android.net.Uri;
import android.content.ContentValues;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Tela única do APKZ, em quatro passos:
 * 1) ligar o repositório do GitHub que faz o build;
 * 2) escolher o zip e o bundle identifier;
 * 3) transformar em APK (limpa o zip, envia, compila no GitHub Actions e baixa o APK);
 * 4) instalar. Extra: salvar só o zip limpo.
 */
public class MainActivity extends Activity {
	private static final int REQ_ZIP = 1;
	private static final int REQ_SAVE = 2;
	private static final int REQ_APK = 3;
	private static final int REQ_SAVE_APK = 4;
	private static final String ACTION_INSTALL = "com.assistente.apkz.INSTALL_RESULT";

	private static final Pattern PKG_RE = Pattern.compile("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+$");
	private static final int GREEN = 0xFF1FD65F;
	private static final int GREEN_LIGHT = 0xFF5CFF8C;

	private final ExecutorService io = Executors.newSingleThreadExecutor();
	private final List<TextView> headings = new ArrayList<>();

	private TextView zipInfo;
	private LinearLayout reportBox;
	private Button cleanBtn;
	private TextView cleanInfo;
	private TextView apkInfo;
	private Button installBtn;
	private Button saveApkBtn;
	private LinearLayout root;
	private SharedPreferences sp;
	private EditText tokenField;
	private EditText repoField;
	private TextView setupInfo;
	private EditText pkgField;
	private Button buildBtn;
	private TextView buildInfo;

	private File zipFile;
	private ZipTools.Report report;
	private File apkFile;
	private String apkName = "app.apk";

	private final BroadcastReceiver installResult = new BroadcastReceiver() {
		@Override
		@SuppressWarnings("deprecation")
		public void onReceive(Context c, Intent i) {
			int st = i.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
			if (st == PackageInstaller.STATUS_PENDING_USER_ACTION) {
				Intent confirm = Build.VERSION.SDK_INT >= 33
						? i.getParcelableExtra(Intent.EXTRA_INTENT, Intent.class)
						: (Intent) i.getParcelableExtra(Intent.EXTRA_INTENT);
				if (confirm != null) {
					confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(confirm);
				}
			} else if (st == PackageInstaller.STATUS_SUCCESS) {
				toast("APK instalado.");
			} else {
				String m = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
				say("O Android recusou a instalação", (m == null ? "Sem detalhes." : m)
						+ "\n\nDica: se esse app já está instalado com outra assinatura (ou com o mesmo identificador de outra origem), "
						+ "desinstale o antigo antes. Um APK escolhido de arquivo precisa estar assinado.");
			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		sp = getSharedPreferences("apkz", MODE_PRIVATE);

		ScrollView sv = new ScrollView(this);
		sv.setFitsSystemWindows(true);
		root = new LinearLayout(this);
		root.setOrientation(LinearLayout.VERTICAL);
		root.setPadding(dp(20), dp(20), dp(20), dp(32));
		sv.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

		// cabeçalho
		LinearLayout head = new LinearLayout(this);
		head.setOrientation(LinearLayout.HORIZONTAL);
		head.setGravity(Gravity.CENTER_VERTICAL);
		head.addView(new SpikyBubbleView(this), new LinearLayout.LayoutParams(dp(84), dp(84)));
		LinearLayout headText = new LinearLayout(this);
		headText.setOrientation(LinearLayout.VERTICAL);
		headText.setPadding(dp(16), 0, 0, 0);
		TextView title = new TextView(this);
		title.setText("APKZ");
		title.setTextSize(38);
		title.setTextColor(0xFFFFFFFF);
		headings.add(title);
		headText.addView(title);
		TextView ver = new TextView(this);
		ver.setText(versionName() + " · zip para APK");
		ver.setTextSize(14);
		ver.setTextColor(GREEN_LIGHT);
		headText.addView(ver);
		head.addView(headText);
		root.addView(head);

		TextView intro = new TextView(this);
		intro.setText("Escolha o zip do projeto (Android nativo ou Expo), digite o bundle identifier e o APKZ faz o resto: "
				+ "limpa o zip, manda para um build gratuito no seu GitHub (GitHub Actions), espera e baixa o APK pronto. Aí você instala ou salva numa pasta. "
				+ "O celular não compila sozinho; quem compila é o GitHub, na sua conta.");
		intro.setTextSize(13);
		intro.setPadding(0, dp(14), 0, 0);
		root.addView(intro);

		LinearLayout legend = new LinearLayout(this);
		legend.setOrientation(LinearLayout.VERTICAL);
		legend.setPadding(0, dp(12), 0, 0);
		legend.addView(row(R.drawable.ic_ok, 0xFFFFFFFF, "Verde: tudo certo, dá para seguir"));
		legend.addView(row(R.drawable.ic_info, 0xFFFFFFFF, "Informação: só para você saber"));
		legend.addView(row(R.drawable.ic_warning, 0xFFFFFFFF, "Atenção: o build pode falhar, mas dá para tentar"));
		legend.addView(row(R.drawable.ic_danger, 0xFFFFFFFF, "Erro: falta algo essencial, não dá para seguir"));
		root.addView(legend);

		// passo 1: GitHub
		root.addView(label("Passo 1 — Conta de build (GitHub)"));
		TextView hint1 = new TextView(this);
		hint1.setText("Uma vez só: crie no GitHub um repositório vazio só para o APKZ (com um README, pode ser privado) "
				+ "e um token com acesso a ele (fine-grained: Contents, Actions e Workflows em leitura e escrita; "
				+ "ou clássico: repo + workflow). O token fica só neste aparelho.");
		hint1.setTextSize(13);
		root.addView(hint1);
		repoField = new EditText(this);
		repoField.setHint("usuario/repositorio");
		repoField.setSingleLine(true);
		repoField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
		repoField.setText(sp.getString("repo", ""));
		root.addView(repoField);
		tokenField = new EditText(this);
		tokenField.setHint("Token do GitHub");
		tokenField.setSingleLine(true);
		tokenField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
		tokenField.setText(sp.getString("token", ""));
		root.addView(tokenField);
		root.addView(button("Salvar e preparar o repositório", v -> setupRepo()));
		setupInfo = new TextView(this);
		setupInfo.setTextSize(14);
		setupInfo.setPadding(0, dp(6), 0, 0);
		root.addView(setupInfo);

		// passo 2: zip + identificador
		root.addView(label("Passo 2 — Escolher o zip e o bundle identifier"));
		root.addView(button("Escolher zip", v -> pick(REQ_ZIP,
				new String[]{"application/zip", "application/x-zip-compressed", "application/octet-stream"})));
		zipInfo = new TextView(this);
		zipInfo.setTextSize(14);
		zipInfo.setPadding(0, dp(8), 0, dp(4));
		root.addView(zipInfo);
		reportBox = new LinearLayout(this);
		reportBox.setOrientation(LinearLayout.VERTICAL);
		root.addView(reportBox);
		pkgField = new EditText(this);
		pkgField.setHint("Bundle identifier (ex.: com.meunome.app)");
		pkgField.setSingleLine(true);
		pkgField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
		root.addView(pkgField);
		TextView hint2 = new TextView(this);
		hint2.setText("Vem preenchido com o identificador do projeto. Pode trocar: o APKZ muda o applicationId (Android) ou o android.package (Expo) antes de compilar. Deixe vazio para manter o original.");
		hint2.setTextSize(12);
		root.addView(hint2);

		// passo 3: transformar
		root.addView(label("Passo 3 — Transformar em APK"));
		buildBtn = button("Transformar em APK", v -> startBuild());
		buildBtn.setEnabled(false);
		root.addView(buildBtn);
		buildInfo = new TextView(this);
		buildInfo.setTextSize(14);
		buildInfo.setPadding(0, dp(6), 0, 0);
		root.addView(buildInfo);

		// passo 4: instalar
		root.addView(label("Passo 4 — Instalar ou salvar o APK"));
		TextView hint3 = new TextView(this);
		hint3.setText("O último APK gerado fica guardado no app e, no Android 10 ou mais novo, também em Downloads. Quando o build terminar, o APKZ pergunta se você quer instalar o APK ou salvar numa pasta (ele abre os arquivos e você escolhe onde deixar). "
				+ "O APK também fica aqui, com os dois botões. Dá para escolher um APK que você já tenha. "
				+ "Na primeira vez que instalar, o Android pede para permitir que o APKZ instale apps.");
		hint3.setTextSize(13);
		root.addView(hint3);
		apkInfo = new TextView(this);
		apkInfo.setTextSize(14);
		apkInfo.setPadding(0, dp(8), 0, dp(4));
		root.addView(apkInfo);
		installBtn = button("Instalar", v -> install());
		installBtn.setEnabled(false);
		root.addView(installBtn);
		saveApkBtn = button("Salvar APK em uma pasta", v -> pickSaveApk());
		saveApkBtn.setEnabled(false);
		root.addView(saveApkBtn);
		root.addView(button("Escolher outro APK", v -> pick(REQ_APK,
				new String[]{"application/vnd.android.package-archive", "application/octet-stream"})));

		// extra: zip limpo
		root.addView(label("Extra — Só salvar o zip limpo"));
		TextView hintC = new TextView(this);
		hintC.setText("Tira build/, node_modules/, .git/, .gradle/, .idea/, local.properties e APKs, "
				+ "e coloca o projeto na raiz do zip. O original não é alterado.");
		hintC.setTextSize(13);
		root.addView(hintC);
		cleanBtn = button("Gerar zip limpo", v -> pickSave());
		cleanBtn.setEnabled(false);
		root.addView(cleanBtn);
		cleanInfo = new TextView(this);
		cleanInfo.setTextSize(14);
		cleanInfo.setPadding(0, dp(6), 0, 0);
		root.addView(cleanInfo);

		Fonts.apply(root, Fonts.body(this));
		for (TextView t : headings) t.setTypeface(Fonts.title(this));
		setContentView(sv);

		IntentFilter f = new IntentFilter(ACTION_INSTALL);
		if (Build.VERSION.SDK_INT >= 33) registerReceiver(installResult, f, Context.RECEIVER_NOT_EXPORTED);
		else registerReceiver(installResult, f);

		restoreLastApk();
	}

	@Override
	protected void onDestroy() {
		try {
			unregisterReceiver(installResult);
		} catch (Exception ignored) {
		}
		io.shutdown();
		super.onDestroy();
	}

	// ---------- escolher arquivos ----------

	private void pick(int req, String[] mimes) {
		Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
		i.addCategory(Intent.CATEGORY_OPENABLE);
		i.setType("*/*");
		i.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
		startActivityForResult(i, req);
	}

	private void pickSave() {
		if (zipFile == null || report == null || !report.canPrepare()) return;
		Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
		i.addCategory(Intent.CATEGORY_OPENABLE);
		i.setType("application/zip");
		i.putExtra(Intent.EXTRA_TITLE, report.name + "_limpo.zip");
		startActivityForResult(i, REQ_SAVE);
	}

	private void pickSaveApk() {
		if (apkFile == null) return;
		Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
		i.addCategory(Intent.CATEGORY_OPENABLE);
		i.setType("application/vnd.android.package-archive");
		i.putExtra(Intent.EXTRA_TITLE, apkName.toLowerCase().endsWith(".apk") ? apkName : apkName + ".apk");
		startActivityForResult(i, REQ_SAVE_APK);
	}

	private void onSaveApkPicked(Uri uri) {
		final File f = apkFile;
		if (f == null) return;
		io.execute(() -> {
			try (InputStream in = new FileInputStream(f); OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
				if (out == null) throw new IOException("Não consegui abrir o destino.");
				byte[] buf = new byte[65536];
				int k;
				while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
				out.flush();
				runOnUiThread(() -> toast("APK salvo na pasta que você escolheu."));
			} catch (Exception e) {
				runOnUiThread(() -> toast("Não consegui salvar o APK: " + e.getMessage()));
			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
		Uri uri = data.getData();
		if (requestCode == REQ_ZIP) onZipPicked(uri);
		else if (requestCode == REQ_SAVE) onSavePicked(uri);
		else if (requestCode == REQ_APK) onApkPicked(uri);
		else if (requestCode == REQ_SAVE_APK) onSaveApkPicked(uri);
	}

	// ---------- passo 1: ler e analisar ----------

	private void onZipPicked(Uri uri) {
		zipFile = null;
		report = null;
		cleanBtn.setEnabled(false);
		buildBtn.setEnabled(false);
		cleanInfo.setText("");
		reportBox.removeAllViews();
		zipInfo.setText("Lendo o zip...");
		io.execute(() -> {
			try {
				String name = displayName(uri);
				File f = copyToCache(uri, "entrada.zip");
				ZipTools.Report r = ZipTools.analyze(f, name);
				runOnUiThread(() -> showReport(f, name, r));
			} catch (Exception e) {
				runOnUiThread(() -> {
					zipInfo.setText("Não consegui ler esse arquivo como zip: " + e.getMessage());
					Fonts.apply(zipInfo, Fonts.body(this));
				});
			}
		});
	}

	private void showReport(File f, String name, ZipTools.Report r) {
		zipFile = f;
		report = r;
		zipInfo.setText(name + " · " + ZipTools.human(f.length()));
		reportBox.removeAllViews();
		for (ZipTools.Line l : r.lines) {
			int icon = l.level == ZipTools.ERROR ? R.drawable.ic_danger
					: l.level == ZipTools.WARN ? R.drawable.ic_warning : R.drawable.ic_info;
			reportBox.addView(row(icon, l.level == ZipTools.ERROR ? 0xFFFF8A8A : 0xFFFFFFFF, l.text));
		}
		if (r.canPrepare()) {
			reportBox.addView(row(R.drawable.ic_ok, GREEN_LIGHT, "Pronto: confira o identificador abaixo e siga para o passo 3."));
		}
		cleanBtn.setEnabled(r.canPrepare());
		buildBtn.setEnabled(r.canPrepare());
		pkgField.setText(r.pkg);
		Fonts.apply(zipInfo, Fonts.body(this));
		Fonts.apply(reportBox, Fonts.body(this));
	}

	// ---------- passo 2: zip limpo ----------

	private void onSavePicked(Uri uri) {
		final File f = zipFile;
		final ZipTools.Report r = report;
		if (f == null || r == null) return;
		cleanInfo.setText("Gerando...");
		io.execute(() -> {
			try (OutputStream raw = getContentResolver().openOutputStream(uri, "wt")) {
				if (raw == null) throw new IOException("Não consegui abrir o destino.");
				ZipTools.Result res = ZipTools.clean(f, new BufferedOutputStream(raw), r);
				runOnUiThread(() -> {
					cleanInfo.setText("Pronto: " + res.files + " arquivos (" + ZipTools.human(res.bytes) + ") no zip limpo; "
							+ res.removed + " ficaram de fora.");
					Fonts.apply(cleanInfo, Fonts.body(this));
					toast("Zip limpo salvo.");
				});
			} catch (Exception e) {
				runOnUiThread(() -> {
					cleanInfo.setText("Falhou: " + e.getMessage());
					Fonts.apply(cleanInfo, Fonts.body(this));
				});
			}
		});
	}

	// ---------- passo 3: instalar ----------

	private void onApkPicked(Uri uri) {
		apkFile = null;
		installBtn.setEnabled(false);
		saveApkBtn.setEnabled(false);
		apkInfo.setText("Lendo o APK...");
		io.execute(() -> {
			try {
				String name = displayName(uri);
				File f = copyToCache(uri, "instalar.apk");
				PackageInfo pi = getPackageManager().getPackageArchiveInfo(f.getAbsolutePath(), 0);
				runOnUiThread(() -> {
					if (pi == null) {
						apkInfo.setText(name + ": isso não parece um APK válido (ou está corrompido).");
					} else {
						apkFile = f;
						apkName = name;
						apkInfo.setText(name + " · " + ZipTools.human(f.length()) + "\nPacote: " + pi.packageName
								+ (pi.versionName == null ? "" : " · versão " + pi.versionName));
						installBtn.setEnabled(true);
						saveApkBtn.setEnabled(true);
					}
					Fonts.apply(apkInfo, Fonts.body(this));
				});
			} catch (Exception e) {
				runOnUiThread(() -> {
					apkInfo.setText("Não consegui ler esse arquivo: " + e.getMessage());
					Fonts.apply(apkInfo, Fonts.body(this));
				});
			}
		});
	}

	private void install() {
		final File f = apkFile;
		if (f == null) return;
		if (!getPackageManager().canRequestPackageInstalls()) {
			toast("Permita que o APKZ instale apps e volte aqui.");
			startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
			return;
		}
		io.execute(() -> {
			try {
				PackageInstaller pi = getPackageManager().getPackageInstaller();
				int id = pi.createSession(new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL));
				try (PackageInstaller.Session s = pi.openSession(id)) {
					try (InputStream in = new FileInputStream(f); OutputStream out = s.openWrite("apkz", 0, f.length())) {
						byte[] buf = new byte[65536];
						int k;
						while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
						s.fsync(out);
					}
					Intent it = new Intent(ACTION_INSTALL).setPackage(getPackageName());
					PendingIntent pend = PendingIntent.getBroadcast(this, id, it,
							PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
					s.commit(pend.getIntentSender());
				}
			} catch (Exception e) {
				runOnUiThread(() -> say("Não consegui iniciar a instalação", String.valueOf(e.getMessage())));
			}
		});
	}

	// ---------- passo 1: preparar o repositório ----------

	private void setupRepo() {
		final String repo = repoField.getText().toString().trim();
		final String token = tokenField.getText().toString().trim();
		sp.edit().putString("repo", repo).putString("token", token).apply();
		setupInfo.setText("Preparando...");
		io.execute(() -> {
			try {
				GitHub gh = new GitHub(token, repo);
				String branch = gh.defaultBranch();
				gh.putFile(".github/workflows/" + GitHub.WORKFLOW_FILE, readAsset("github/apkz.yml"),
						"APKZ: workflow de build", branch);
				gh.putFile(".github/apkz-build.sh", readAsset("github/apkz-build.sh"), "APKZ: script de build", branch);
				runOnUiThread(() -> setupInfo.setText("Pronto: " + repo + " (branch " + branch + ") está preparado para compilar."));
			} catch (Exception e) {
				runOnUiThread(() -> setupInfo.setText("Falhou: " + e.getMessage()));
			}
		});
	}

	private byte[] readAsset(String path) throws IOException {
		try (InputStream in = getAssets().open(path)) {
			java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
			byte[] buf = new byte[8192];
			int k;
			while ((k = in.read(buf)) > 0) bo.write(buf, 0, k);
			return bo.toByteArray();
		}
	}

	// ---------- passo 3: transformar em APK ----------

	private void progress(String s) {
		runOnUiThread(() -> buildInfo.setText(s));
	}

	private void startBuild() {
		final File src = zipFile;
		final ZipTools.Report rep = report;
		if (src == null || rep == null || !rep.canPrepare()) return;
		final String repo = repoField.getText().toString().trim();
		final String token = tokenField.getText().toString().trim();
		final String pkg = pkgField.getText().toString().trim();
		if (repo.isEmpty() || token.isEmpty()) {
			say("Falta o passo 1", "Preencha o repositório e o token do GitHub e toque em \"Salvar e preparar o repositório\".");
			return;
		}
		if (!pkg.isEmpty() && !PKG_RE.matcher(pkg).matches()) {
			say("Bundle identifier inválido", "Use letras, números e _, separados por pontos, como com.meunome.app (começa com letra).");
			return;
		}
		sp.edit().putString("repo", repo).putString("token", token).apply();
		buildBtn.setEnabled(false);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		io.execute(() -> {
			String runUrl = "";
			try {
				progress("Limpando o zip...");
				File dir = new File(getCacheDir(), "apkz");
				if (!dir.exists() && !dir.mkdirs()) throw new IOException("Sem espaço de trabalho no aparelho.");
				File cleaned = new File(dir, "limpo.zip");
				ZipTools.clean(src, new FileOutputStream(cleaned), rep);
				if (cleaned.length() > 70L * 1024 * 1024) {
					throw new IOException("O zip limpo tem " + ZipTools.human(cleaned.length())
							+ "; o limite de envio é cerca de 70 MB.");
				}
				byte[] data = java.nio.file.Files.readAllBytes(cleaned.toPath());

				GitHub gh = new GitHub(token, repo);
				progress("Abrindo o repositório...");
				String branch = gh.defaultBranch();
				String job = "j" + (System.currentTimeMillis() / 1000);
				progress("Enviando o zip (" + ZipTools.human(data.length) + ")...");
				gh.putFile("jobs/" + job + "/project.zip", data, "APKZ: envia " + job, branch);

				progress("Iniciando o build...");
				try {
					gh.dispatch(branch, job, pkg);
				} catch (IOException e) {
					throw new IOException(e.getMessage()
							+ "\n\nSe for a primeira vez, toque em \"Salvar e preparar o repositório\" no passo 1.");
				}

				GitHub.Run run = null;
				for (int i = 0; i < 30 && run == null; i++) {
					run = gh.findRun(job);
					if (run == null) GitHub.sleep(4000);
				}
				if (run == null) throw new IOException("O GitHub não começou o build. Veja a aba Actions do repositório.");
				runUrl = run.url;

				long t0 = System.currentTimeMillis();
				while (!"completed".equals(run.status)) {
					long s = (System.currentTimeMillis() - t0) / 1000;
					if (s > 45 * 60) throw new IOException("O build passou de 45 minutos. Veja o andamento no GitHub.");
					progress(("in_progress".equals(run.status) ? "Compilando" : "Na fila") + "... " + (s / 60) + " min "
							+ (s % 60) + " s\nDeixe o APKZ aberto até terminar.");
					GitHub.sleep(8000);
					run = gh.getRun(run.id);
					runUrl = run.url;
				}
				if (!"success".equals(run.conclusion)) {
					throw new IOException("O build terminou com resultado \"" + run.conclusion
							+ "\". Abra o log no GitHub para ver o erro.");
				}

				progress("Baixando o APK...");
				File apk = new File(dir, "instalar.apk");
				gh.downloadApk(run.id, apk);
				final String apkName = rep.name + ".apk";
				// cópia que sobrevive a fechar o app (a pasta de cache pode ser apagada pelo Android)
				File keep = new File(getFilesDir(), "ultimo.apk");
				copyFile(apk, keep);
				sp.edit().putString("lastApkName", apkName).apply();
				final boolean inDownloads = saveCopyToDownloads(keep, apkName);
				runOnUiThread(() -> {
					buildInfo.setText("APK pronto! Instale ou salve numa pasta (passo 4)."
							+ (inDownloads ? "\nUma cópia foi salva em Downloads." : ""));
					showApk(keep, apkName);
					toast("APK pronto.");
					askWhatToDoWithApk(inDownloads);
				});
			} catch (Exception e) {
				final String url = runUrl;
				final String msg = String.valueOf(e.getMessage());
				runOnUiThread(() -> {
					buildInfo.setText("Falhou.");
					AlertDialog.Builder b = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
					b.setTitle("O build não terminou");
					b.setMessage(msg);
					b.setPositiveButton("OK", null);
					if (!url.isEmpty()) {
						b.setNeutralButton("Abrir no GitHub", (d, w) -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))));
					}
					b.show();
				});
			} finally {
				runOnUiThread(() -> {
					buildBtn.setEnabled(zipFile != null && report != null && report.canPrepare());
					getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
				});
			}
		});
	}

	/** Mostra o APK pronto no passo 4 e libera o botão Instalar (só na thread principal). */
	private void showApk(File f, String name) {
		PackageInfo pi = getPackageManager().getPackageArchiveInfo(f.getAbsolutePath(), 0);
		if (pi == null) {
			apkFile = null;
			installBtn.setEnabled(false);
			saveApkBtn.setEnabled(false);
			apkInfo.setText(name + ": isso não parece um APK válido (ou está corrompido).");
			return;
		}
		apkFile = f;
		apkName = name;
		apkInfo.setText(name + " · " + ZipTools.human(f.length()) + "\nPacote: " + pi.packageName
				+ (pi.versionName == null ? "" : " · versão " + pi.versionName));
		installBtn.setEnabled(true);
		saveApkBtn.setEnabled(true);
	}

	/** Quando o build termina: pergunta se instala ou salva numa pasta. */
	private void askWhatToDoWithApk(boolean inDownloads) {
		if (apkFile == null) return;
		AlertDialog.Builder b = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
		b.setTitle("APK pronto!");
		b.setMessage(apkName + " · " + ZipTools.human(apkFile.length())
				+ (inDownloads ? "\n\nUma cópia já está na pasta Downloads." : "")
				+ "\n\nO que você quer fazer?");
		b.setPositiveButton("Instalar", (d, w) -> install());
		b.setNegativeButton("Salvar numa pasta", (d, w) -> pickSaveApk());
		b.setNeutralButton("Depois", null);
		b.show();
	}

	/** Ao abrir o app, traz de volta o último APK gerado (se ainda existir). */
	private void restoreLastApk() {
		File keep = new File(getFilesDir(), "ultimo.apk");
		String name = sp.getString("lastApkName", "");
		if (!keep.isFile() || name.isEmpty()) return;
		showApk(keep, name);
	}

	private void copyFile(File from, File to) throws IOException {
		try (InputStream in = new FileInputStream(from); OutputStream out = new FileOutputStream(to)) {
			byte[] buf = new byte[65536];
			int k;
			while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
		}
	}

	/** Guarda uma cópia em Downloads (Android 10+, sem pedir permissão). Devolve true se salvou. */
	private boolean saveCopyToDownloads(File f, String name) {
		if (Build.VERSION.SDK_INT < 29) return false;
		try {
			ContentValues v = new ContentValues();
			v.put(MediaStore.Downloads.DISPLAY_NAME, name.toLowerCase().endsWith(".apk") ? name : name + ".apk");
			v.put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive");
			v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
			Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
			if (u == null) return false;
			try (InputStream in = new FileInputStream(f); OutputStream out = getContentResolver().openOutputStream(u)) {
				if (out == null) return false;
				byte[] buf = new byte[65536];
				int k;
				while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
			}
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	// ---------- utilidades ----------

	private File copyToCache(Uri uri, String fileName) throws IOException {
		File dir = new File(getCacheDir(), "apkz");
		if (!dir.exists() && !dir.mkdirs()) throw new IOException("Sem espaço de trabalho no aparelho.");
		File f = new File(dir, fileName);
		try (InputStream in = getContentResolver().openInputStream(uri); OutputStream out = new FileOutputStream(f)) {
			if (in == null) throw new IOException("Não consegui abrir o arquivo.");
			byte[] buf = new byte[65536];
			int k;
			while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
		}
		return f;
	}

	private String displayName(Uri uri) {
		try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
			if (c != null && c.moveToFirst()) {
				String n = c.getString(0);
				if (n != null && !n.trim().isEmpty()) return n;
			}
		} catch (Exception ignored) {
		}
		String last = uri.getLastPathSegment();
		return last == null ? "arquivo" : last;
	}

	private void say(String title, String msg) {
		AlertDialog.Builder b = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
		b.setTitle(title);
		b.setMessage(msg);
		b.setPositiveButton("OK", null);
		b.show();
	}

	private void toast(String s) {
		Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
	}

	private int dp(int v) {
		return Math.round(v * getResources().getDisplayMetrics().density);
	}

	private String versionName() {
		try {
			return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
		} catch (Exception e) {
			return "";
		}
	}

	private TextView label(String text) {
		TextView t = new TextView(this);
		t.setText(text);
		t.setTextSize(15);
		t.setTextColor(GREEN_LIGHT);
		t.setPadding(0, dp(24), 0, dp(6));
		headings.add(t);
		return t;
	}

	private Button button(String text, final android.view.View.OnClickListener l) {
		Button b = new Button(this);
		b.setText(text);
		b.setAllCaps(false);
		b.setOnClickListener(l);
		return b;
	}

	private LinearLayout row(int iconRes, int color, String text) {
		LinearLayout r = new LinearLayout(this);
		r.setOrientation(LinearLayout.HORIZONTAL);
		r.setPadding(0, dp(5), 0, dp(5));
		ImageView ic = new ImageView(this);
		ic.setImageResource(iconRes);
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(20), dp(20));
		lp.setMargins(0, dp(1), dp(10), 0);
		r.addView(ic, lp);
		TextView t = new TextView(this);
		t.setText(text);
		t.setTextSize(14);
		t.setTextColor(color);
		r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
		return r;
	}
}
