package com.assistente.apkz;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Cliente mínimo da API do GitHub: envia o zip para um repositório seu, dispara o workflow de build
 * (GitHub Actions), acompanha e baixa o APK. Tudo bloqueante: chame fora da thread principal.
 */
public final class GitHub {
	private static final String API = "https://api.github.com";
	public static final String WORKFLOW_FILE = "apkz.yml";

	public static final class Run {
		public long id;
		public String status = "";
		public String conclusion = "";
		public String url = "";
	}

	private static final class Resp {
		int code;
		String body = "";
		String location = "";
	}

	private final String token;
	private final String owner;
	private final String repo;

	public GitHub(String token, String ownerRepo) throws IOException {
		String t = token == null ? "" : token.trim();
		String r = ownerRepo == null ? "" : ownerRepo.trim();
		if (r.startsWith("https://github.com/")) r = r.substring("https://github.com/".length());
		while (r.endsWith("/")) r = r.substring(0, r.length() - 1);
		if (r.endsWith(".git")) r = r.substring(0, r.length() - 4);
		int slash = r.indexOf('/');
		if (t.isEmpty()) throw new IOException("Cole o token do GitHub.");
		if (slash <= 0 || slash == r.length() - 1 || r.indexOf('/', slash + 1) >= 0) {
			throw new IOException("Escreva o repositório assim: usuario/repositorio");
		}
		this.token = t;
		this.owner = r.substring(0, slash);
		this.repo = r.substring(slash + 1);
	}

	private String repoPath() {
		return "/repos/" + owner + "/" + repo;
	}

	// ---------- HTTP ----------

	private Resp call(String method, String urlOrPath, String json, boolean auth) throws IOException {
		String url = urlOrPath.startsWith("http") ? urlOrPath : API + urlOrPath;
		HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
		c.setInstanceFollowRedirects(false);
		c.setConnectTimeout(30_000);
		c.setReadTimeout(120_000);
		c.setRequestMethod(method);
		c.setRequestProperty("User-Agent", "APKZ");
		c.setRequestProperty("Accept", "application/vnd.github+json");
		c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
		if (auth) c.setRequestProperty("Authorization", "Bearer " + token);
		if (json != null) {
			byte[] b = json.getBytes(StandardCharsets.UTF_8);
			c.setDoOutput(true);
			c.setRequestProperty("Content-Type", "application/json");
			c.setFixedLengthStreamingMode(b.length);
			try (OutputStream o = c.getOutputStream()) {
				o.write(b);
			}
		}
		Resp r = new Resp();
		r.code = c.getResponseCode();
		r.location = c.getHeaderField("Location") == null ? "" : c.getHeaderField("Location");
		InputStream in = r.code >= 400 ? c.getErrorStream() : c.getInputStream();
		if (in != null) {
			try (InputStream i = in) {
				ByteArrayOutputStream bo = new ByteArrayOutputStream();
				byte[] buf = new byte[8192];
				int k;
				while ((k = i.read(buf)) > 0) bo.write(buf, 0, k);
				r.body = new String(bo.toByteArray(), StandardCharsets.UTF_8);
			}
		}
		c.disconnect();
		return r;
	}

	private static String message(Resp r) {
		try {
			String m = new JSONObject(r.body).optString("message", "");
			if (!m.isEmpty()) return m;
		} catch (Exception ignored) {
		}
		return "HTTP " + r.code;
	}

	private IOException fail(String what, Resp r) {
		String extra = "";
		if (r.code == 401) extra = " (token inválido ou vencido)";
		else if (r.code == 403) extra = " (o token não tem a permissão necessária)";
		else if (r.code == 404) extra = " (repositório ou arquivo não encontrado, ou o token não enxerga este repositório)";
		return new IOException(what + ": " + message(r) + extra);
	}

	// ---------- repositório ----------

	/** Confere o acesso e devolve o branch padrão. */
	public String defaultBranch() throws IOException {
		Resp r = call("GET", repoPath(), null, true);
		if (r.code != 200) throw fail("Não consegui abrir o repositório " + owner + "/" + repo, r);
		try {
			String b = new JSONObject(r.body).optString("default_branch", "");
			return b.isEmpty() ? "main" : b;
		} catch (Exception e) {
			return "main";
		}
	}

	/** Cria ou atualiza um arquivo no repositório (um commit). */
	public void putFile(String path, byte[] data, String message, String branch) throws IOException {
		String sha = "";
		Resp g = call("GET", repoPath() + "/contents/" + path + "?ref=" + branch, null, true);
		if (g.code == 200) {
			try {
				sha = new JSONObject(g.body).optString("sha", "");
			} catch (Exception ignored) {
			}
		} else if (g.code != 404) {
			throw fail("Não consegui ler " + path, g);
		}
		try {
			JSONObject j = new JSONObject();
			j.put("message", message);
			j.put("content", Base64.getEncoder().encodeToString(data));
			j.put("branch", branch);
			if (!sha.isEmpty()) j.put("sha", sha);
			Resp p = call("PUT", repoPath() + "/contents/" + path, j.toString(), true);
			if (p.code != 200 && p.code != 201) throw fail("Não consegui enviar " + path, p);
		} catch (org.json.JSONException e) {
			throw new IOException(e.getMessage());
		}
	}

	// ---------- build ----------

	public void dispatch(String branch, String job, String pkg) throws IOException {
		try {
			JSONObject inputs = new JSONObject();
			inputs.put("job", job);
			inputs.put("package", pkg == null ? "" : pkg);
			JSONObject j = new JSONObject();
			j.put("ref", branch);
			j.put("inputs", inputs);
			Resp r = null;
			// logo depois de enviar o workflow, o GitHub pode demorar alguns segundos para enxergá-lo
			for (int i = 0; i < 6; i++) {
				r = call("POST", repoPath() + "/actions/workflows/" + WORKFLOW_FILE + "/dispatches", j.toString(), true);
				if (r.code == 204) return;
				if (r.code != 404) break;
				sleep(5000);
			}
			throw fail("Não consegui iniciar o build", r);
		} catch (org.json.JSONException e) {
			throw new IOException(e.getMessage());
		}
	}

	/** Procura a execução deste job (o nome do run é "APKZ <job>"). Devolve null se ainda não apareceu. */
	public Run findRun(String job) throws IOException {
		Resp r = call("GET", repoPath() + "/actions/runs?event=workflow_dispatch&per_page=15", null, true);
		if (r.code != 200) throw fail("Não consegui listar os builds", r);
		try {
			JSONArray runs = new JSONObject(r.body).optJSONArray("workflow_runs");
			if (runs == null) return null;
			for (int i = 0; i < runs.length(); i++) {
				JSONObject o = runs.getJSONObject(i);
				String n = o.optString("display_title", "") + " " + o.optString("name", "");
				if (n.contains(job)) return parse(o);
			}
		} catch (org.json.JSONException e) {
			throw new IOException(e.getMessage());
		}
		return null;
	}

	public Run getRun(long id) throws IOException {
		Resp r = call("GET", repoPath() + "/actions/runs/" + id, null, true);
		if (r.code != 200) throw fail("Não consegui ver o andamento do build", r);
		try {
			return parse(new JSONObject(r.body));
		} catch (org.json.JSONException e) {
			throw new IOException(e.getMessage());
		}
	}

	private static Run parse(JSONObject o) {
		Run r = new Run();
		r.id = o.optLong("id");
		r.status = o.optString("status", "");
		r.conclusion = o.isNull("conclusion") ? "" : o.optString("conclusion", "");
		r.url = o.optString("html_url", "");
		return r;
	}

	/** Baixa o artefato do run e extrai o primeiro .apk para "out". */
	public void downloadApk(long runId, File out) throws IOException {
		Resp r = call("GET", repoPath() + "/actions/runs/" + runId + "/artifacts", null, true);
		if (r.code != 200) throw fail("Não consegui listar o resultado do build", r);
		long artifact;
		try {
			JSONArray a = new JSONObject(r.body).optJSONArray("artifacts");
			if (a == null || a.length() == 0) throw new IOException("O build terminou, mas não gerou nenhum APK.");
			artifact = a.getJSONObject(0).getLong("id");
		} catch (org.json.JSONException e) {
			throw new IOException(e.getMessage());
		}
		// a API responde com um redirecionamento para o arquivo; ele é baixado sem o token
		Resp redirect = call("GET", repoPath() + "/actions/artifacts/" + artifact + "/zip", null, true);
		if (redirect.code != 302 || redirect.location.isEmpty()) throw fail("Não consegui baixar o APK", redirect);
		HttpURLConnection c = (HttpURLConnection) new URL(redirect.location).openConnection();
		c.setConnectTimeout(30_000);
		c.setReadTimeout(120_000);
		c.setRequestProperty("User-Agent", "APKZ");
		if (c.getResponseCode() != 200) throw new IOException("Falha ao baixar o APK: HTTP " + c.getResponseCode());
		boolean found = false;
		try (ZipInputStream z = new ZipInputStream(c.getInputStream())) {
			ZipEntry e;
			while ((e = z.getNextEntry()) != null) {
				if (e.isDirectory() || !e.getName().toLowerCase(java.util.Locale.ROOT).endsWith(".apk")) continue;
				try (OutputStream o = new FileOutputStream(out)) {
					byte[] buf = new byte[65536];
					int k;
					while ((k = z.read(buf)) > 0) o.write(buf, 0, k);
				}
				found = true;
				break;
			}
		} finally {
			c.disconnect();
		}
		if (!found) throw new IOException("O resultado do build não tinha nenhum APK.");
	}

	public static void sleep(long ms) throws IOException {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			throw new IOException("Cancelado.");
		}
	}
}
