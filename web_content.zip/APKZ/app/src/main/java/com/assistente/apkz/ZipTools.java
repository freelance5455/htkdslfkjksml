package com.assistente.apkz;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Lê o zip de um projeto, descobre que tipo de projeto é (Android nativo, Expo...), aponta o que falta
 * ou sobra e gera um zip limpo, com a pasta do projeto na raiz. Não compila nada.
 */
public final class ZipTools {
	private ZipTools() {
	}

	public enum Kind { ANDROID, EXPO, NODE, APK, UNKNOWN }

	public static final int INFO = 0;
	public static final int WARN = 1;
	public static final int ERROR = 2;

	public static final class Line {
		public final int level;
		public final String text;

		Line(int level, String text) {
			this.level = level;
			this.text = text;
		}
	}

	public static final class Report {
		public Kind kind = Kind.UNKNOWN;
		/** Pasta do projeto dentro do zip, com "/" no fim ("" = o projeto já está na raiz). */
		public String root = "";
		public String name = "projeto";
		/** Bundle identifier / applicationId que o projeto já tem ("" se não achou). */
		public String pkg = "";
		public int files;
		public long bytes;
		public int junkFiles;
		public long junkBytes;
		public final List<Line> lines = new ArrayList<>();

		void info(String t) {
			lines.add(new Line(INFO, t));
		}

		void warn(String t) {
			lines.add(new Line(WARN, t));
		}

		void error(String t) {
			lines.add(new Line(ERROR, t));
		}

		public boolean hasError() {
			for (Line l : lines) if (l.level == ERROR) return true;
			return false;
		}

		/** Dá para gerar o zip limpo? (APK já pronto e zips sem projeto não têm o que limpar.) */
		public boolean canPrepare() {
			return (kind == Kind.ANDROID || kind == Kind.EXPO || kind == Kind.NODE) && !hasError();
		}
	}

	public static final class Result {
		public int files;
		public int removed;
		public long bytes;
	}

	// ---------- análise ----------

	public static Report analyze(File zip, String fileName) throws IOException {
		Report r = new Report();
		r.name = baseName(fileName);
		Map<String, Long> sizes = new LinkedHashMap<>();
		Map<String, String> texts = new LinkedHashMap<>();
		try (ZipFile zf = new ZipFile(zip)) {
			Enumeration<? extends ZipEntry> en = zf.entries();
			while (en.hasMoreElements()) {
				ZipEntry e = en.nextElement();
				if (e.isDirectory()) continue;
				String n = e.getName().replace('\\', '/');
				while (n.startsWith("/")) n = n.substring(1);
				if (n.isEmpty() || n.contains("..")) continue;
				sizes.put(n, Math.max(0L, e.getSize()));
				if (wantText(n) && e.getSize() <= 200_000) texts.put(n, readText(zf.getInputStream(e)));
			}
		}
		if (sizes.isEmpty()) {
			r.error("O zip está vazio.");
			return r;
		}

		String androidRoot = null;
		String nodeRoot = null;
		for (String n : sizes.keySet()) {
			if (n.contains("node_modules/") || n.startsWith("__MACOSX/") || n.contains("/__MACOSX/")) continue;
			String leaf = leaf(n);
			if (leaf.equals("settings.gradle") || leaf.equals("settings.gradle.kts")) {
				if (androidRoot == null || depth(dir(n)) < depth(androidRoot)) androidRoot = dir(n);
			} else if (leaf.equals("package.json")) {
				if (nodeRoot == null || depth(dir(n)) < depth(nodeRoot)) nodeRoot = dir(n);
			}
		}

		if (androidRoot == null && nodeRoot == null) {
			if (sizes.containsKey("AndroidManifest.xml") && sizes.containsKey("classes.dex")) {
				r.kind = Kind.APK;
				r.info("Tipo: isto já é um APK (um zip com outra extensão).");
				r.warn("Não há o que preparar aqui. Use a etapa 3 para instalar. Se não tiver assinatura, o Android recusa (a assinatura entra na v.02).");
			} else {
				r.error("Não achei settings.gradle nem package.json. Não parece um projeto Android nem Expo. Confira se o zip é do projeto certo.");
			}
			return r;
		}

		// o projeto mais perto da raiz do zip vence (um Expo tem uma pasta android/ dentro)
		if (nodeRoot == null || (androidRoot != null && depth(androidRoot) <= depth(nodeRoot))) {
			r.root = androidRoot;
			r.kind = Kind.ANDROID;
			androidInfo(r, sizes, texts);
		} else {
			r.root = nodeRoot;
			nodeInfo(r, sizes, texts);
		}

		Set<String> modules = moduleDirs(sizes.keySet(), r.root);
		int outside = 0;
		for (Map.Entry<String, Long> en : sizes.entrySet()) {
			String n = en.getKey();
			if (!n.startsWith(r.root)) {
				outside++;
				continue;
			}
			String rel = n.substring(r.root.length());
			r.files++;
			r.bytes += en.getValue();
			if (isJunk(rel, modules)) {
				r.junkFiles++;
				r.junkBytes += en.getValue();
			}
		}
		r.info("Arquivos do projeto: " + (r.files) + " (" + human(r.bytes) + ").");
		if (r.junkFiles > 0) {
			r.warn("Vão ficar de fora " + r.junkFiles + " arquivos (" + human(r.junkBytes)
					+ "): build/, node_modules/, .git/, .gradle/, .idea/, local.properties, APKs...");
		}
		if (outside > 0) r.info(outside + " arquivos fora da pasta do projeto também ficam de fora.");
		if (!r.root.isEmpty()) r.info("O projeto estava dentro da pasta \"" + r.root + "\"; no zip limpo ele vai para a raiz.");
		return r;
	}

	private static void androidInfo(Report r, Map<String, Long> sizes, Map<String, String> texts) {
		String root = r.root;
		r.info("Tipo: projeto Android nativo (Gradle).");
		String app = null;
		List<String> keys = new ArrayList<>(texts.keySet());
		Collections.sort(keys);
		for (String k : keys) {
			if (!k.startsWith(root)) continue;
			String leaf = leaf(k);
			if ((leaf.equals("build.gradle") || leaf.equals("build.gradle.kts")) && texts.get(k).contains("applicationId")) {
				app = texts.get(k);
				break;
			}
		}
		if (app == null) {
			r.error("Não achei o módulo do app (um build.gradle com applicationId).");
		} else {
			String pkg = find(app, "applicationId\\s*=?\\s*['\"]([^'\"]+)['\"]");
			String ns = find(app, "namespace\\s*=?\\s*['\"]([^'\"]+)['\"]");
			String vn = find(app, "versionName\\s*=?\\s*['\"]([^'\"]+)['\"]");
			String vc = find(app, "versionCode\\s*=?\\s*(\\d+)");
			String sdk = find(app, "compileSdk(?:Version)?\\s*=?\\s*(\\d+)");
			r.pkg = pkg;
			if (!pkg.isEmpty()) r.info("Pacote: " + pkg + (ns.isEmpty() || ns.equals(pkg) ? "" : " (namespace " + ns + ")"));
			if (!vn.isEmpty() || !vc.isEmpty()) r.info("Versão: " + (vn.isEmpty() ? "?" : vn) + " (código " + (vc.isEmpty() ? "?" : vc) + ")");
			String agp = "";
			String rootGradle = texts.get(root + "build.gradle");
			if (rootGradle == null) rootGradle = texts.get(root + "build.gradle.kts");
			String settings = texts.get(root + "settings.gradle");
			if (settings == null) settings = texts.get(root + "settings.gradle.kts");
			for (String t : new String[]{rootGradle, settings, app}) {
				if (t == null || !agp.isEmpty()) continue;
				agp = find(t, "com\\.android\\.tools\\.build:gradle:([0-9][^'\"\\s]*)");
				if (agp.isEmpty()) agp = find(t, "com\\.android\\.application['\"]\\s*version\\s*['\"]([^'\"]+)['\"]");
			}
			String gradle = find(texts.get(root + "gradle/wrapper/gradle-wrapper.properties"), "gradle-([0-9][0-9.]*)-(?:bin|all)\\.zip");
			StringBuilder sb = new StringBuilder();
			if (!gradle.isEmpty()) sb.append("Gradle ").append(gradle);
			if (!agp.isEmpty()) sb.append(sb.length() > 0 ? " · " : "").append("AGP ").append(agp);
			if (!sdk.isEmpty()) sb.append(sb.length() > 0 ? " · " : "").append("compileSdk ").append(sdk);
			if (sb.length() > 0) r.info("Ferramentas: " + sb);
		}
		boolean manifest = false;
		for (String n : sizes.keySet()) {
			if (n.startsWith(root) && n.endsWith("src/main/AndroidManifest.xml")) {
				manifest = true;
				break;
			}
		}
		if (!manifest) r.error("Faltou o AndroidManifest.xml (em app/src/main).");
		if (!sizes.containsKey(root + "gradlew")) r.warn("Sem o arquivo gradlew: um build na nuvem pode falhar.");
		if (!sizes.containsKey(root + "gradle/wrapper/gradle-wrapper.jar")
				|| !sizes.containsKey(root + "gradle/wrapper/gradle-wrapper.properties")) {
			r.warn("Faltam arquivos de gradle/wrapper/ (jar ou properties).");
		}
	}

	private static void nodeInfo(Report r, Map<String, Long> sizes, Map<String, String> texts) {
		String root = r.root;
		String pj = texts.get(root + "package.json");
		boolean expo = pj != null && Pattern.compile("\"expo\"\\s*:").matcher(pj).find();
		if (expo) {
			r.kind = Kind.EXPO;
			r.info("Tipo: projeto Expo (React Native).");
		} else {
			r.kind = Kind.NODE;
			r.info("Tipo: projeto Node com package.json.");
			r.warn("Não vi \"expo\" no package.json. O \"Build from ZIP\" do Newly pede projeto Expo.");
		}
		String name = find(pj, "\"name\"\\s*:\\s*\"([^\"]+)\"");
		String ver = find(pj, "\"version\"\\s*:\\s*\"([^\"]+)\"");
		if (!name.isEmpty()) r.info("Nome: " + name + (ver.isEmpty() ? "" : " · versão " + ver));
		boolean cfg = sizes.containsKey(root + "app.json");
		for (String n : sizes.keySet()) {
			if (n.startsWith(root + "app.config.") && leaf(n).startsWith("app.config.")) cfg = true;
		}
		if (!cfg) r.warn("Sem app.json nem app.config: um projeto Expo precisa de um.");
		String id = find(texts.get(root + "app.json"), "\"package\"\\s*:\\s*\"([^\"]+)\"");
		r.pkg = id;
		if (!id.isEmpty()) r.info("Pacote Android: " + id);
		boolean lock = sizes.containsKey(root + "bun.lock");
		if (!lock) r.warn("Sem bun.lock: o Expo usa só o Bun 1.4.3. Rode bun install e inclua o bun.lock no zip.");
		for (String f : new String[]{"package-lock.json", "yarn.lock", "pnpm-lock.yaml", "bun.lockb"}) {
			if (sizes.containsKey(root + f)) r.warn(f + " não é usado (só bun.lock): pode tirar do zip.");
		}
	}

	// ---------- zip limpo ----------

	public static Result clean(File zip, OutputStream out, Report r) throws IOException {
		Result res = new Result();
		try (ZipFile zf = new ZipFile(zip); ZipOutputStream zo = new ZipOutputStream(out)) {
			List<String> names = new ArrayList<>();
			Enumeration<? extends ZipEntry> en = zf.entries();
			while (en.hasMoreElements()) {
				ZipEntry e = en.nextElement();
				if (!e.isDirectory()) names.add(normName(e.getName()));
			}
			Set<String> modules = moduleDirs(names, r.root);
			Set<String> written = new HashSet<>();
			byte[] buf = new byte[65536];
			en = zf.entries();
			while (en.hasMoreElements()) {
				ZipEntry e = en.nextElement();
				if (e.isDirectory()) continue;
				String n = normName(e.getName());
				if (n.isEmpty() || n.contains("..") || !n.startsWith(r.root)) continue;
				String rel = n.substring(r.root.length());
				if (rel.isEmpty()) continue;
				if (isJunk(rel, modules)) {
					res.removed++;
					continue;
				}
				if (!written.add(rel)) continue;
				ZipEntry ne = new ZipEntry(rel);
				if (e.getTime() > 0) ne.setTime(e.getTime());
				zo.putNextEntry(ne);
				try (InputStream in = zf.getInputStream(e)) {
					int k;
					while ((k = in.read(buf)) > 0) {
						zo.write(buf, 0, k);
						res.bytes += k;
					}
				}
				zo.closeEntry();
				res.files++;
			}
		}
		return res;
	}

	// ---------- utilidades ----------

	private static String normName(String n) {
		n = n.replace('\\', '/');
		while (n.startsWith("/")) n = n.substring(1);
		return n;
	}

	/** Pastas (relativas à raiz do projeto) que têm um build.gradle: a "build/" dentro delas é saída de compilação. */
	private static Set<String> moduleDirs(Iterable<String> names, String root) {
		Set<String> set = new HashSet<>();
		for (String n : names) {
			if (!n.startsWith(root)) continue;
			String rel = n.substring(root.length());
			String leaf = leaf(rel);
			if (leaf.equals("build.gradle") || leaf.equals("build.gradle.kts")) set.add(dir(rel));
		}
		return set;
	}

	static boolean isJunk(String rel, Set<String> modules) {
		String[] seg = rel.split("/");
		String leaf = seg[seg.length - 1];
		if (leaf.equals(".DS_Store") || leaf.equals("Thumbs.db") || leaf.startsWith("._")) return true;
		if (rel.equals("local.properties")) return true;
		String l = leaf.toLowerCase(Locale.ROOT);
		if (l.endsWith(".apk") || l.endsWith(".aab") || l.endsWith(".iml")) return true;
		StringBuilder parent = new StringBuilder();
		for (int i = 0; i < seg.length - 1; i++) {
			String s = seg[i];
			if (s.equals(".gradle") || s.equals(".idea") || s.equals("node_modules") || s.equals(".git")
					|| s.equals("__MACOSX") || s.equals(".cxx") || s.equals(".externalNativeBuild")
					|| s.equals(".expo") || s.equals("captures")) {
				return true;
			}
			if (s.equals("build") && modules.contains(parent.toString())) return true;
			parent.append(s).append('/');
		}
		return false;
	}

	private static boolean wantText(String n) {
		if (n.contains("node_modules/")) return false;
		String l = leaf(n);
		return l.equals("settings.gradle") || l.equals("settings.gradle.kts") || l.equals("build.gradle")
				|| l.equals("build.gradle.kts") || l.equals("package.json") || l.equals("app.json")
				|| l.equals("gradle-wrapper.properties");
	}

	private static String readText(InputStream in) throws IOException {
		try (InputStream i = in) {
			ByteArrayOutputStream bo = new ByteArrayOutputStream();
			byte[] buf = new byte[8192];
			int k;
			while ((k = i.read(buf)) > 0 && bo.size() < 200_000) bo.write(buf, 0, k);
			return new String(bo.toByteArray(), StandardCharsets.UTF_8);
		}
	}

	private static String find(String text, String regex) {
		if (text == null) return "";
		Matcher m = Pattern.compile(regex).matcher(text);
		return m.find() ? m.group(1) : "";
	}

	private static String leaf(String n) {
		int i = n.lastIndexOf('/');
		return i < 0 ? n : n.substring(i + 1);
	}

	/** Pasta do arquivo, com "/" no fim ("" se estiver na raiz). */
	private static String dir(String n) {
		int i = n.lastIndexOf('/');
		return i < 0 ? "" : n.substring(0, i + 1);
	}

	private static int depth(String dir) {
		int d = 0;
		for (int i = 0; i < dir.length(); i++) if (dir.charAt(i) == '/') d++;
		return d;
	}

	private static String baseName(String fileName) {
		String n = fileName == null || fileName.trim().isEmpty() ? "projeto" : fileName.trim();
		int slash = n.lastIndexOf('/');
		if (slash >= 0) n = n.substring(slash + 1);
		if (n.toLowerCase(Locale.ROOT).endsWith(".zip")) n = n.substring(0, n.length() - 4);
		return n.isEmpty() ? "projeto" : n;
	}

	public static String human(long b) {
		if (b < 1024) return b + " B";
		if (b < 1024L * 1024) return String.format(Locale.US, "%.0f KB", b / 1024.0);
		return String.format(Locale.US, "%.1f MB", b / (1024.0 * 1024));
	}
}
