PVP ENGINES — TELEFONDA ÇALIŞTIRMAYA HAZIR SÜRÜM

BU SÜRÜMDE express/socket.io PAKETLERİ GEREKMİYOR.
Sunucu yalnızca Node.js'in kendi yerleşik modüllerini kullanır.

1. ZIP'i bir klasöre çıkar.
2. Node JS Server uygulamasında bu klasörü seç veya server.js dosyasının bulunduğu klasörü sunucu kökü olarak ayarla.
3. Port 3000 olsun ve Start/Başlat düğmesine bas.
4. Sunucu başlarsa aynı telefonda http://127.0.0.1:3000 adresini aç.
5. Aynı Wi-Fi'daki diğer telefonda, sunucuyu çalıştıran telefonun LAN IP'sini kullan: ör. http://192.168.1.23:3000
6. Oyunda Multiplayer ekranına gir, sunucu adresini gir ve SUNUCUYA BAĞLAN'a bas. Bir oyuncu ODA OLUŞTURur; diğerleri oda koduyla katılır.

ÖNEMLİ:
- Sunucu uygulamasının server.js dosyasını gerçekten Node.js ile çalıştırması gerekir. Sadece HTML sunan bir mod bu sunucuyu çalıştıramaz.
- LAN Access açık olmalı. Telefonlar aynı Wi-Fi ağında olmalı.
- Bu yerel sürüm farklı internet ağları arasında çalışmaz.
- Bu sürümde çok oyunculu bağlantı HTTP polling ile yapılır; performans ve cihaz uyumluluğu sunucu uygulamasına bağlıdır.

YENİ MOD — HARDCORE TANK CEHENNEMİ
- Modlar menüsüne HARDCORE modu eklendi.
- Karanlık, lav çatlaklı ve ateşli cehennem haritası oluşturuldu.
- Haritada 12 tam zırhlı tank rakip olarak doğar; tanklar 520 dayanıklılığa sahiptir.
- HARDCORE modunun arka plan müziği, eklediğin "BEETHOVEN HARDTEKK VIRUS - PHXKHXNG x KZAMANE.mp3" dosyasından alınan hardcore-music.mp3 dosyasıdır.
- Bu değişiklikler web oyun ZIP'inde yapılmıştır. APK'ye otomatik dönüşmez; APK oluşturmak için bu ZIP'i kullandığın Android paketleyiciye yeniden vermen gerekir.
