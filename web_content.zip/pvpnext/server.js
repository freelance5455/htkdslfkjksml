// PVP ENGINES: zero-dependency LAN server for Android Node JS Server apps.
// Uses built-in Node modules only; no npm install required.
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const ROOT = __dirname;
const PORT = Number(process.env.PORT || 3000);
const clients = new Map();
const rooms = new Map();
const roomSeeds = new Map();
const players = new Map();
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.webmanifest':'application/manifest+json','.mp3':'audio/mpeg','.wav':'audio/wav','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon'};
function send(res, status, data, type='application/json; charset=utf-8') { res.writeHead(status, {'Content-Type':type,'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Cache-Control':'no-store'}); res.end(typeof data === 'string' ? data : JSON.stringify(data)); }
function queue(id, event, data) { const c=clients.get(id); if(!c)return; if(event==='players'||event==='roomInfo')c.queue=c.queue.filter(e=>e.event!==event); c.queue.push({event,data}); if(c.queue.length>100)c.queue.splice(0,c.queue.length-100); }
function roomPlayers(code) { return [...players.values()].filter(p=>p.room===code); }
const dirtyRooms=new Set();
function publishRoom(code) { if(code)dirtyRooms.add(code); }
function publishNow(code) { if(!code)return; const list=roomPlayers(code); for(const id of rooms.get(code)||[]) { queue(id,'players',list); queue(id,'roomInfo',{code,count:list.length}); } }
function makeCode() { const chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let code; do {code=Array.from({length:6},()=>chars[Math.floor(Math.random()*chars.length)]).join('');} while(rooms.has(code)); return code; }
function leaveRoom(id) { const p=players.get(id); if(!p||!p.room){players.delete(id);return;} const code=p.room; const set=rooms.get(code); if(set){set.delete(id);if(!set.size)rooms.delete(code);} players.delete(id); publishRoom(code); }
function handleEvent(id,event,data) {
 const c=clients.get(id); if(!c)return;
 if(event==='createRoom') { leaveRoom(id); const code=makeCode(); rooms.set(code,new Set([id])); c.room=code; players.set(id,{id,name:'Oyuncu',color:0x11d6ef,x:0,y:0,z:0,rotation:0,room:code}); queue(id,'roomJoined',{code,count:1}); publishRoom(code); return; }
 if(event==='joinRoom') { const code=String(data||'').trim().toUpperCase(); if(!/^[A-HJ-NP-Z2-9]{6}$/.test(code)||!rooms.has(code)){queue(id,'roomError','Bu oda kodu bulunamadı. Kod doğru mu?');return;} if(rooms.get(code).size>=8){queue(id,'roomError','Bu oda dolu (en fazla 8 oyuncu).');return;} leaveRoom(id); rooms.get(code).add(id); c.room=code; players.set(id,{id,name:'Oyuncu',color:0x11d6ef,x:0,y:0,z:0,rotation:0,room:code}); queue(id,'roomJoined',{code,count:rooms.get(code).size}); publishRoom(code); return; }
 if(event==='joinGame') { const p=players.get(id); if(!p)return; p.color=Number.isFinite(Number(data?.color))?Number(data.color):p.color; const n=String(data?.name||'').trim();if(n)p.name=n.slice(0,16);p.model=['sahin','toros','bus','accent','togg','mercedes','bmw','bugatti','tank','motorcycle','minibus','tractor','truck','pickup'].includes(data?.model)?data.model:'sahin';publishRoom(p.room);return; }
 if(event==='mountainSeed') { const p=players.get(id);const code=p&&p.room;if(!code||!rooms.has(code))return;const v=Math.floor(Number(data));if(Number.isFinite(v)&&v>0&&v<2147483647&&!roomSeeds.has(code))roomSeeds.set(code,v);if(roomSeeds.has(code))for(const m of rooms.get(code))queue(m,'mountainSeed',roomSeeds.get(code));return; }
 if(event==='playerState') { const p=players.get(id);if(!p||!data||typeof data!=='object')return;const num=n=>Number.isFinite(Number(n))?Math.max(-500,Math.min(500,Number(n))):0;p.x=num(data.x);p.y=Math.max(0,Math.min(1000,num(data.y)));p.z=num(data.z);p.rotation=num(data.rotation);p.color=num(data.color)||p.color;if(['sahin','toros','bus','accent','togg','mercedes','bmw','bugatti','tank','motorcycle','minibus','tractor','truck','pickup'].includes(data.model))p.model=data.model;const n=String(data.name||'').trim();if(n)p.name=n.slice(0,16);publishRoom(p.room); }
}
const server=http.createServer((req,res)=>{
 if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'GET,POST,OPTIONS'});return res.end();}
 const u=new URL(req.url,'http://localhost');
 if(u.pathname==='/health')return send(res,200,{ok:true,players:players.size,rooms:rooms.size,server:'PVP ENGINES no-dependency'});
 if(u.pathname==='/api/connect'&&req.method==='POST'){const id=crypto.randomBytes(12).toString('hex');clients.set(id,{queue:[],room:null,last:Date.now()});return send(res,200,{id});}
 if(u.pathname==='/api/events'&&req.method==='GET'){const id=u.searchParams.get('id');const c=clients.get(id);if(!c)return send(res,404,{error:'client not found'});c.last=Date.now();const q=c.queue.splice(0,c.queue.length);return send(res,200,{events:q});}
 if(u.pathname==='/api/emit'&&req.method==='POST'){let body='';req.on('data',d=>{body+=d;if(body.length>100000)req.destroy();});req.on('end',()=>{try{const m=JSON.parse(body);if(!clients.has(m.id))return send(res,404,{error:'client not found'});handleEvent(m.id,String(m.event||''),m.data);send(res,200,{ok:true});}catch(e){send(res,400,{error:'invalid json'});}});return;}
 if(u.pathname==='/api/disconnect'&&req.method==='POST'){let body='';req.on('data',d=>body+=d);req.on('end',()=>{try{const {id}=JSON.parse(body);leaveRoom(id);clients.delete(id);send(res,200,{ok:true});}catch(e){send(res,400,{ok:false});}});return;}
 let pathname=decodeURIComponent(u.pathname);if(pathname==='/')pathname='/index.html';const file=path.resolve(ROOT,'.'+pathname);if(!file.startsWith(ROOT+path.sep)&&file!==path.join(ROOT,'index.html'))return send(res,403,'Forbidden','text/plain');fs.stat(file,(err,st)=>{if(err||!st.isFile())return send(res,404,'File not found','text/plain; charset=utf-8');res.writeHead(200,{'Content-Type':mime[path.extname(file).toLowerCase()]||'application/octet-stream','Access-Control-Allow-Origin':'*'});fs.createReadStream(file).pipe(res);});
});
server.on('error',e=>{console.error('SERVER ERROR:',e.code||e.message);});
server.listen(PORT,'0.0.0.0',()=>{console.log(`PVP ENGINES server started on port ${PORT}`);console.log(`Local URL: http://127.0.0.1:${PORT}`);for(const es of Object.values(os.networkInterfaces()))for(const n of es||[])if(n.family==='IPv4'&&!n.internal)console.log(`LAN URL: http://${n.address}:${PORT}`);console.log('No npm install needed. Keep this process running.');});
// Remove abandoned clients and stale room membership.
setInterval(()=>{const now=Date.now();for(const [id,c] of clients)if(now-c.last>60000){leaveRoom(id);clients.delete(id);}},15000).unref();
// Oda durumunu paket başına değil, 50 ms'de bir toplu gönder (ağ ve CPU yükünü düşürür).
setInterval(()=>{for(const c of dirtyRooms)publishNow(c);dirtyRooms.clear();},50).unref();
setInterval(()=>{for(const c of roomSeeds.keys())if(!rooms.has(c))roomSeeds.delete(c);},15000).unref();
