RDR2 OUTLAW CHEATBOOK - ANDROID PROJECT

This is an Android Studio Gradle project that wraps the offline HTML cheatbook in a WebView.

BUILD:
1. Open/import this project in Android Studio.
2. Let Gradle sync and install the required Android SDK (compileSdk 35).
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is normally created at app/build/outputs/apk/debug/app-debug.apk.

No network permission is requested. The app loads its bundled local HTML file.

For an APK built entirely on a phone, use an Android-compatible project builder that accepts Gradle projects. Availability and support vary; this ZIP is source code, not an APK.
