# Ragavi Agencies Attendance — installable web app

## Included
- Admin adds staff names; staff role selects a name.
- Present/Absent, clock-in/out time, GPS coordinates when browser location permission works.
- GPS Camera buttons for clock-in and clock-out; compressed photo, capture time, and available GPS coordinates are saved with the record. Monthly report shows photo thumbnails; JSON backup includes photos.
- Monthly report and CSV export for Excel/Google Sheets.
- Local browser storage and JSON backup.
- Add-to-home-screen PWA support when served over HTTPS.

## Run / install
1. Upload `index.html`, `manifest.json`, and `sw.js` to an HTTPS static host (for example GitHub Pages or Netlify).
2. Open the HTTPS site in Chrome on Android.
3. Allow location access.
4. Chrome menu (⋮) → **Add to Home screen** or **Install app**.
5. Open the new Ragavi Agencies icon.

Opening `index.html` directly as a file may block GPS; use HTTPS for GPS and PWA installation.

## Limitations
This is a local-device prototype. Admin/staff roles are not secure login accounts and data does not sync between phones. GPS may fail if the user denies permission or the device cannot obtain a location. For a real company system, add authentication, backend/cloud sync, server-side records, and admin access controls.
