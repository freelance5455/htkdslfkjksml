package com.jornadamusical.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Build;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.SeekBar;
import java.util.Locale;

/** User-movable overlay with compact, color-coded status and device media-volume controls. */
final class FloatingStatus {
 private final Context context;
 private final WindowManager wm;
 private LinearLayout root;
 private TextView header, progress, music, volumeText;
 private SeekBar volumeSlider;
 private WindowManager.LayoutParams params;
 FloatingStatus(Context c){context=c;wm=(WindowManager)c.getSystemService(Context.WINDOW_SERVICE);}
 private int dp(float v){return (int)(v*context.getResources().getDisplayMetrics().density+.5f);}
 private String clock(long s){s=Math.max(0,s);return String.format(Locale.US,"%02d:%02d:%02d",s/3600,(s%3600)/60,s%60);}
 private String minuteClock(long s){s=Math.max(0,s);return String.format(Locale.US,"%02d:%02d",s/60,s%60);}
 private GradientDrawable pill(int color){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(7));return g;}
 private int volumePercent(){AudioManager audio=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
   if(audio==null)return 0;int max=audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);return max>0?100*audio.getStreamVolume(AudioManager.STREAM_MUSIC)/max:0;
 }
 private void setVolume(int direction){AudioManager audio=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
   if(audio!=null)audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,direction,0);
   if(volumeText!=null)volumeText.setText("Volumen "+volumePercent()+"%");
 }
 private TextView volumeButton(String text,int direction){TextView t=new TextView(context);t.setText(text);t.setTextSize(15);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
   t.setTextColor(Color.rgb(185,28,28));t.setGravity(Gravity.CENTER);t.setPadding(dp(9),dp(2),dp(9),dp(2));t.setBackground(pill(Color.rgb(254,226,226)));
   t.setOnClickListener(v->setVolume(direction));return t;
 }
 private TextView mediaButton(String icon, String action){
   TextView b=new TextView(context);b.setText(icon);b.setTextSize(16);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
   b.setGravity(Gravity.CENTER);b.setTextColor(Color.rgb(21,128,61));b.setBackground(pill(Color.rgb(220,252,231)));
   b.setContentDescription(action.equals("MEDIA_PREVIOUS")?"Canción anterior":action.equals("MEDIA_NEXT")?"Siguiente canción":action.equals("MEDIA_PLAY")?"Reproducir":"Pausar");
   b.setOnClickListener(v->{Intent i=new Intent(context,JornadaService.class).setAction(action);context.startService(i);});
   return b;
 }
 void update(String phase,long remaining,long elapsed,long nextRest,long songElapsed,long songLeft,boolean confirmed){
   if(Build.VERSION.SDK_INT<23 || !Settings.canDrawOverlays(context)){remove();return;}
   if(root==null)create();if(root==null)return;
   boolean pause="Descanso".equals(phase);
   header.setText((pause?"☕ DESCANSO":"● TRABAJO")+"  ·  "+clock(elapsed));
   header.setTextColor(Color.rgb(107,33,168)); // purple time and phase
   progress.setText(pause?"Descanso · quedan "+minuteClock(remaining):"Próximo descanso en "+minuteClock(nextRest));
   progress.setTextColor(Color.rgb(157,23,77)); // pink
   music.setText(confirmed && songElapsed>=0 && songLeft>=0?
     "♪ Spotify "+minuteClock(songElapsed)+" · faltan "+minuteClock(songLeft):
     "♪ Spotify: reproducción sin confirmar");
   music.setTextColor(Color.rgb(21,128,61)); // green
   volumeText.setText("Volumen "+volumePercent()+"%");
   if(volumeSlider!=null && !volumeSlider.isPressed())volumeSlider.setProgress(volumePercent());
 }
 private void create(){
   root=new LinearLayout(context);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(12),dp(5),dp(12),dp(5));
   GradientDrawable bg=new GradientDrawable();bg.setColor(Color.rgb(5,5,7));bg.setCornerRadius(dp(12));bg.setStroke(dp(1.5f),Color.rgb(239,68,68));root.setBackground(bg); // fondo negro; conserva los colores de cada indicador y botón
   LinearLayout top=new LinearLayout(context);top.setOrientation(LinearLayout.HORIZONTAL);top.setGravity(Gravity.CENTER_VERTICAL);
   header=new TextView(context);header.setTextSize(11);header.setTypeface(Typeface.DEFAULT,Typeface.BOLD);header.setSingleLine(true);
   top.addView(header,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1));
   TextView close=new TextView(context);close.setText("×");close.setTextSize(20);close.setTextColor(Color.rgb(153,27,27));close.setPadding(dp(8),0,dp(2),0);
   close.setOnClickListener(v->remove());top.addView(close);root.addView(top);
   progress=new TextView(context);progress.setTextSize(11);progress.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
   progress.setBackground(pill(Color.rgb(252,231,243)));progress.setPadding(dp(6),dp(2),dp(6),dp(2));root.addView(progress);
   music=new TextView(context);music.setTextSize(11);music.setTypeface(Typeface.DEFAULT,Typeface.BOLD);music.setPadding(0,dp(2),0,dp(1));root.addView(music);
   // Controles de Spotify debajo del estado de reproducción, antes del volumen.
   LinearLayout mediaRow=new LinearLayout(context);mediaRow.setGravity(Gravity.CENTER_VERTICAL);
   mediaRow.setOrientation(LinearLayout.HORIZONTAL);mediaRow.setPadding(0,dp(1),0,dp(2));
   String[] symbols={"⏮","▶","⏸","⏭"};
   String[] actions={"MEDIA_PREVIOUS","MEDIA_PLAY","MEDIA_PAUSE","MEDIA_NEXT"};
   for(int i=0;i<actions.length;i++){
     LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,dp(27),1);
     if(i>0)mp.leftMargin=dp(5);
     mediaRow.addView(mediaButton(symbols[i],actions[i]),mp);
   }
   root.addView(mediaRow);
   LinearLayout volumeRow=new LinearLayout(context);volumeRow.setOrientation(LinearLayout.HORIZONTAL);volumeRow.setGravity(Gravity.CENTER_VERTICAL);
   volumeText=new TextView(context);volumeText.setTextSize(11);volumeText.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
   volumeText.setTextColor(Color.rgb(185,28,28));volumeText.setText("Volumen "+volumePercent()+"%");
   volumeRow.addView(volumeText,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1));
   volumeSlider=new SeekBar(context);
   volumeSlider.setMax(100);volumeSlider.setProgress(volumePercent());
   if(Build.VERSION.SDK_INT>=21)volumeSlider.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(239,68,68)));
   if(Build.VERSION.SDK_INT>=21)volumeSlider.setThumbTintList(android.content.res.ColorStateList.valueOf(Color.rgb(239,68,68)));
   volumeSlider.setContentDescription("Deslizar para subir o bajar el volumen multimedia");
   volumeSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
     public void onProgressChanged(SeekBar seekBar,int percent,boolean fromUser){
       if(!fromUser)return;
       AudioManager audio=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
       if(audio!=null){int max=audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
         audio.setStreamVolume(AudioManager.STREAM_MUSIC,Math.round(percent*max/100f),0);}
       if(volumeText!=null)volumeText.setText("Volumen "+volumePercent()+"%");
     }
     public void onStartTrackingTouch(SeekBar seekBar){}
     public void onStopTrackingTouch(SeekBar seekBar){}
   });
   volumeRow.addView(volumeSlider,new LinearLayout.LayoutParams(dp(155),dp(35)));
   root.addView(volumeRow);
   params=new WindowManager.LayoutParams(dp(342),WindowManager.LayoutParams.WRAP_CONTENT,
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
      PixelFormat.TRANSLUCENT);
   params.gravity=Gravity.TOP|Gravity.START;params.x=dp(12);params.y=dp(140);
   View.OnTouchListener drag=new View.OnTouchListener(){float x,y;int left,topPos;boolean moved;
     @Override public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){
       case MotionEvent.ACTION_DOWN:x=e.getRawX();y=e.getRawY();left=params.x;topPos=params.y;moved=false;return true;
       case MotionEvent.ACTION_MOVE:
         if(Math.abs(e.getRawX()-x)>dp(5)||Math.abs(e.getRawY()-y)>dp(5))moved=true;
         if(moved){params.x=Math.max(0,left+(int)(e.getRawX()-x));params.y=Math.max(0,topPos+(int)(e.getRawY()-y));try{wm.updateViewLayout(root,params);}catch(Exception ignored){}}return true;
       case MotionEvent.ACTION_UP:return true;
     }return false;}};
   header.setOnTouchListener(drag);progress.setOnTouchListener(drag);music.setOnTouchListener(drag);
   try{wm.addView(root,params);}catch(Exception e){root=null;header=null;progress=null;music=null;volumeText=null;volumeSlider=null;params=null;}
 }
 void remove(){if(root!=null){try{wm.removeView(root);}catch(Exception ignored){}root=null;header=null;progress=null;music=null;volumeText=null;volumeSlider=null;params=null;}}
}
