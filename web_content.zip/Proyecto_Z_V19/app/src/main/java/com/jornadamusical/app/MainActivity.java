package com.jornadamusical.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;
import android.app.NotificationManager;
import android.content.Context;
import android.os.PowerManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;

public class MainActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle b){super.onCreate(b);
   if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
      requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},42);
   web=new WebView(this);setContentView(web);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
   web.setWebViewClient(new WebViewClient());web.addJavascriptInterface(new Bridge(),"Robot");
   web.loadUrl("file:///android_asset/index.html");handleIntent(getIntent());
 }
 @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);handleIntent(intent);}
 private void result(String message){runOnUiThread(()->web.evaluateJavascript("window.nativeMessage("+JSONObject.quote(message)+")",null));}
 private void handleIntent(Intent in){Uri uri=in.getData();if(uri==null||!"jornadamusical".equals(uri.getScheme()))return;
   String code=uri.getQueryParameter("code"),state=uri.getQueryParameter("state");
   if(code==null){result("Spotify: autorización cancelada o rechazada");return;}
   new Thread(()->{try{SpotifyClient.exchange(this,code,state==null?"":state);result("Spotify conectado. Abre Spotify y reproduce una canción para activar el teléfono antes de iniciar la jornada.");}
   catch(Exception e){result("Error al conectar: "+e.getMessage());}}).start();
 }
 public class Bridge {
  @JavascriptInterface public void requestNotifications(){ runOnUiThread(()->{
     if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
       requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},42);
     else { Intent i=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);i.putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName());startActivity(i); }
   }); }
  @JavascriptInterface public void requestFloatingBar(){ runOnUiThread(()->{
     if(Build.VERSION.SDK_INT>=23 && !Settings.canDrawOverlays(MainActivity.this)){
       Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);
       result("En Ajustes, permite 'Mostrar encima de otras aplicaciones' para Proyecto Z y regresa. Android no permite activar ese permiso automáticamente.");
     } else result("Permiso de barra sobre otras aplicaciones disponible. Se mostrará al iniciar jornada.");
   }); }
  @JavascriptInterface public void openBatterySettings(){runOnUiThread(()->{
     try{ Intent i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()));startActivity(i); }
     catch(Exception e){result("No se pudo abrir ajustes: "+e.getMessage());}
   });}
  @JavascriptInterface public String permissionsStatus(){
    boolean n=Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;
    boolean overlay=Build.VERSION.SDK_INT<23||Settings.canDrawOverlays(MainActivity.this);
    return "Notificaciones: "+(n?"permitidas":"pendientes")+" · Barra sobre apps: "+(overlay?"permitida":"pendiente");
  }
  @JavascriptInterface public String saved(){return getSharedPreferences("config",MODE_PRIVATE).getString("json","{}");}
  @JavascriptInterface public boolean connected(){return !SpotifyClient.prefs(MainActivity.this).getString("access_token","").isEmpty();}
  @JavascriptInterface public void save(String json){getSharedPreferences("config",MODE_PRIVATE).edit().putString("json",json).apply();}
  @JavascriptInterface public void connect(String clientId){runOnUiThread(()->{try{String url=SpotifyClient.authorizationUrl(MainActivity.this,clientId.trim());startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}
    catch(Exception e){result("No se pudo iniciar la conexión: "+e.getMessage());}});}
  @JavascriptInterface public void start(String json){
    try{JSONObject o=new JSONObject(json);int total=o.optInt("hours"),work=o.optInt("work"),pause=o.optInt("pause");
      if(total<1||total>24||work<5||pause<2||SpotifyClient.playlistUri(o.optString("playlist")).isEmpty())throw new Exception("Revisa el horario y la playlist de trabajo");
      getSharedPreferences("config",MODE_PRIVATE).edit().putString("json",json).apply();
      Intent i=new Intent(MainActivity.this,JornadaService.class);i.setAction("START");
      if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
      result("Jornada iniciada. Consulta el estado de Spotify en la barra; si falla, aparecerá el error. En Spotify Gratis la reproducción automática no está disponible.");
    }catch(Exception e){result("No se inició: "+e.getMessage());}
  }
  @JavascriptInterface public void openSpotifyUrl(String url){runOnUiThread(()->{
     String uri=SpotifyClient.playlistUri(url);
     if(uri.isEmpty()){result("Enlace de playlist no válido");return;}
     try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(uri)).addCategory(Intent.CATEGORY_BROWSABLE));}
     catch(Exception e){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ex){result("No pude abrir Spotify: "+ex.getMessage());}}
   });}
  @JavascriptInterface public void mediaControl(String action){
    if(!action.equals("MEDIA_PLAY")&&!action.equals("MEDIA_PAUSE")&&!action.equals("MEDIA_NEXT")&&!action.equals("MEDIA_PREVIOUS"))return;
    Intent i=new Intent(MainActivity.this,JornadaService.class).setAction(action);startService(i);
  }
  @JavascriptInterface public void stop(){Intent i=new Intent(MainActivity.this,JornadaService.class);i.setAction("STOP");startService(i);result("Jornada detenida");}
  @JavascriptInterface public int getMusicVolume(){
    android.media.AudioManager a=(android.media.AudioManager)getSystemService(AUDIO_SERVICE);
    if(a==null)return 0;int max=a.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC);
    return max==0?0:Math.round(a.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)*100f/max);
  }
  @JavascriptInterface public void setMusicVolume(int percent){
    android.media.AudioManager a=(android.media.AudioManager)getSystemService(AUDIO_SERVICE);
    if(a==null)return;
    percent=Math.max(0,Math.min(100,percent));
    int max=a.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC);
    a.setStreamVolume(android.media.AudioManager.STREAM_MUSIC,Math.round(percent*max/100f),0);
  }
  @JavascriptInterface public String status(){return JornadaService.status(MainActivity.this);}
 }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){web.destroy();super.onDestroy();}
}
