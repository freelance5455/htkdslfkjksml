package com.jornadamusical.app;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;
import org.json.*;
import java.util.concurrent.*;

public class JornadaService extends Service {
  private final ScheduledExecutorService worker=Executors.newSingleThreadScheduledExecutor();
  private static final String CHANNEL="jornada_activa";
  private volatile boolean running=false; private int lastSegment=-1;private FloatingStatus floating;
  private long started;private int total,work,pause;private volatile boolean spotifyPlaying=false;private String account="premium";private String playlist;private String[] breaks;private long songElapsed=-1,songLeft=-1;
  private static final String PREF="robot_runtime";
  public static String status(Context c){return c.getSharedPreferences(PREF,MODE_PRIVATE).getString("status","{\"phase\":\"Listo\",\"remaining\":0,\"nextRest\":0,\"message\":\"\"}");}
  private void writeStatus(String phase,long remaining,long nextRest,String message){
    try{JSONObject o=new JSONObject();o.put("phase",phase);o.put("remaining",remaining);o.put("nextRest",nextRest);o.put("message",message);o.put("songElapsed",songElapsed);o.put("songLeft",songLeft);o.put("spotifyPlaying",spotifyPlaying);o.put("elapsed",Math.max(0,(SystemClock.elapsedRealtime()-started)/1000L));
      getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("status",o.toString()).apply();}
    catch(Exception ignored){}
  }
  @Override public void onCreate(){super.onCreate();floating=new FloatingStatus(this);NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Jornada Musical",NotificationManager.IMPORTANCE_LOW));
  }
  private Notification notification(String line){Intent i=new Intent(this,MainActivity.class);PendingIntent p=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    Intent stop=new Intent(this,JornadaService.class).setAction("STOP");PendingIntent ps=PendingIntent.getService(this,1,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    return new Notification.Builder(this,CHANNEL).setContentTitle("Jornada Musical").setContentText(line).setSmallIcon(android.R.drawable.ic_media_play)
      .setContentIntent(p).addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"Detener",ps).build()).setOngoing(true).build();
  }
  @Override public int onStartCommand(Intent in,int flags,int id){
    if(in!=null&&"STOP".equals(in.getAction())){running=false;if(floating!=null)floating.remove();writeStatus("Listo",0,0,"Detenida");stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY;}
    if(in!=null && in.getAction()!=null && in.getAction().startsWith("MEDIA_")){
      final String mediaAction=in.getAction();
      if(!running){getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("last_message","Inicia la jornada antes de controlar Spotify").apply();return START_NOT_STICKY;}
      worker.execute(()->{
        String message;
        if("free".equals(account)) message="Spotify Gratis no admite estos controles automáticos mediante la API";
        else try{
          switch(mediaAction){
            case "MEDIA_PLAY": SpotifyClient.resume(this);break;
            case "MEDIA_PAUSE": SpotifyClient.pause(this);break;
            case "MEDIA_NEXT": SpotifyClient.next(this);break;
            case "MEDIA_PREVIOUS": SpotifyClient.previous(this);break;
            default:return;
          }
          message="Orden enviada a Spotify; verificando reproducción";
          long[] t=SpotifyClient.currentTrackTime(this);
          songElapsed=t[0];songLeft=t[1];spotifyPlaying=t.length>2&&t[2]==1;
        }catch(Exception e){message="Error al controlar Spotify: "+e.getMessage();}
        getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("last_message",message).apply();
      });
      return START_STICKY;
    }
    if(running)return START_STICKY;
    try{
      JSONObject cfg=new JSONObject(getSharedPreferences("config",MODE_PRIVATE).getString("json","{}"));
      account=cfg.optString("account","premium");total=cfg.optInt("hours",24)*3600; work=cfg.optInt("work",120)*60; pause=cfg.optInt("pause",30)*60;
      playlist=SpotifyClient.playlistUri(cfg.optString("playlist"));
      JSONArray arr=cfg.optJSONArray("breaks");if(arr==null)arr=new JSONArray();
      java.util.ArrayList<String> valid=new java.util.ArrayList<>();for(int j=0;j<arr.length();j++){String s=SpotifyClient.artistUri(arr.optString(j));if(!s.isEmpty())valid.add(s);}
      breaks=valid.toArray(new String[0]);
      if(playlist.isEmpty()||total<=0||work<=0||pause<=0)throw new Exception("Configuración inválida");
      started=SystemClock.elapsedRealtime();lastSegment=-1;running=true;
      if(Build.VERSION.SDK_INT>=29)startForeground(1,notification("Jornada iniciada"),ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
      else startForeground(1,notification("Jornada iniciada"));
      worker.scheduleAtFixedRate(this::step,0,1,TimeUnit.SECONDS);
      return START_STICKY;
    }catch(Exception e){writeStatus("Error",0,0,e.getMessage());stopSelf();return START_NOT_STICKY;}
  }
  private void step(){if(!running)return;
   long elapsed=(SystemClock.elapsedRealtime()-started)/1000L;
   if(elapsed>=total){running=false;if(floating!=null)floating.remove();writeStatus("Finalizado",0,0,"Jornada completada");stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return;}
   long t=elapsed;int idx=0;boolean isBreak=false;long rem=0,nextRest=0;int breakNum=0;long consumed=0;
   while(true){long remainingDay=total-consumed;long duration=Math.min(isBreak?pause:work,remainingDay);
     if(t<duration){rem=duration-t;nextRest=isBreak?0:rem;break;}
     t-=duration;consumed+=duration;if(!isBreak)breakNum++;isBreak=!isBreak;idx++;
   }
   String phase=isBreak?"Descanso":"Trabajo";String message="";
   boolean changed=idx!=lastSegment;
   if(changed){lastSegment=idx;String target=isBreak?(breaks.length==0?playlist:breaks[(breakNum-1)%breaks.length]):playlist;
     if("free".equals(account)){message="Spotify Gratis: abre Spotify y pulsa Play en "+(isBreak?"el artista del descanso":"tu playlist")+". La API no permite iniciar automáticamente.";}
     else try{SpotifyClient.play(this,target);message="Spotify aceptó la orden de "+phase.toLowerCase()+"; comprueba que suene en el dispositivo activo";}
     catch(Exception e){message="Spotify no inició reproducción: "+e.getMessage();}
     // Retain errors; the user should see them rather than assume automatic playback worked.
     getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("last_message",message).apply();
   }else{message=getSharedPreferences(PREF,MODE_PRIVATE).getString("last_message","");}
   if(!"free".equals(account) && (elapsed%12==0 || changed)){try{long[] info=SpotifyClient.currentTrackTime(this);songElapsed=info[0];songLeft=info[1];spotifyPlaying=info.length>2&&info[2]==1;}catch(Exception ignored){songElapsed=-1;songLeft=-1;spotifyPlaying=false;}}
   if("free".equals(account)){songElapsed=-1;songLeft=-1;spotifyPlaying=false;}
   writeStatus(phase,rem,nextRest,message);
   final long elapsedFinal=elapsed, remainingFinal=rem, nextRestFinal=nextRest;
   final String phaseFinal=phase;
   if(floating!=null)new Handler(Looper.getMainLooper()).post(()->floating.update(phaseFinal,remainingFinal,elapsedFinal,nextRestFinal,songElapsed,songLeft,spotifyPlaying));
   if(rem % 30 == 0){NotificationManager n=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);n.notify(1,notification(phase+" · quedan "+(rem/60)+" min"));}
  }
  @Override public void onDestroy(){running=false;worker.shutdownNow();if(floating!=null)floating.remove();super.onDestroy();}
  @Override public IBinder onBind(Intent i){return null;}
}
