// DOM Elements
const arena = document.getElementById("arena");
const scoreEl = document.getElementById("score");
const timeEl = document.getElementById("time");
const bestEl = document.getElementById("best");
const coinCountEl = document.getElementById("coinCount");
const shopCoinsEl = document.getElementById("shopCoins");
const comboText = document.getElementById("comboText");
const startOverlay = document.getElementById("startOverlay");
const endOverlay = document.getElementById("endOverlay");
const startBtn = document.getElementById("startBtn");
const restartBtn = document.getElementById("restartBtn");
const finalScoreEl = document.getElementById("finalScore");
const finalComboEl = document.getElementById("finalCombo");
const finalCoinsEl = document.getElementById("finalCoins");
const finalTotalCoinsEl = document.getElementById("finalTotalCoins");
const finalRankEl = document.getElementById("finalRank");
const soundToggle = document.getElementById("soundToggle");
const musicToggle = document.getElementById("musicToggle");
const bgmAudio = document.getElementById("bgmAudio");
const diffBtns = document.querySelectorAll(".diff-btn");
const telegramFab = document.getElementById("telegramFab");
const toastEl = document.getElementById("toast");

// Shop Elements
const openSkinsBtn = document.getElementById("openSkinsBtn");
const changeBallBtn = document.getElementById("changeBallBtn");
const selectedBallCard = document.getElementById("selectedBallCard");
const endSkinsBtn = document.getElementById("endSkinsBtn");
const skinsModal = document.getElementById("skinsModal");
const closeSkinsBtn = document.getElementById("closeSkinsBtn");
const applySkinBtn = document.getElementById("applySkinBtn");
const skinTabs = document.getElementById("skinTabs");
const skinsContainer = document.getElementById("skinsContainer");
const selectedBallPreview = document.getElementById("selectedBallPreview");
const selectedBallName = document.getElementById("selectedBallName");

// Profile & Badges Elements
const openProfileBtn = document.getElementById("openProfileBtn");
const endProfileBtn = document.getElementById("endProfileBtn");
const profileModal = document.getElementById("profileModal");
const closeProfileBtn = document.getElementById("closeProfileBtn");
const closeProfileFooterBtn = document.getElementById("closeProfileFooterBtn");
const headerAvatar = document.getElementById("headerAvatar");
const headerName = document.getElementById("headerName");
const profileAvatarBig = document.getElementById("profileAvatarBig");
const nicknameInput = document.getElementById("nicknameInput");
const saveProfileBtn = document.getElementById("saveProfileBtn");
const avatarGrid = document.getElementById("avatarGrid");
const statTotalTaps = document.getElementById("statTotalTaps");
const statGames = document.getElementById("statGames");
const statBalls = document.getElementById("statBalls");
const statBadges = document.getElementById("statBadges");
const badgesProgress = document.getElementById("badgesProgress");
const badgesList = document.getElementById("badgesList");

const AVATARS = ["🥷", "👾", "🔥", "⚡", "🐉", "💀", "👑", "🦊", "🤖", "🎯", "🦁", "😈"];

// 24 Balls with Coin Prices & Custom Sound Types
const BALL_SECTIONS = [
  {
    id: "neon",
    title: "⚡ Neon Glow Balls",
    balls: [
      { id: "cyan_pulse", name: "Cyan Pulse", price: 0, sfx: "neon", bg: "radial-gradient(circle at 30% 30%, #8cfbff, #00b8d4)", glow: "0 0 20px rgba(0, 229, 255, 0.85)", border: "2px solid #b2fbff", textColor: "#08121a", floatColor: "#00e5ff", emoji: "" },
      { id: "cyber_pink", name: "Cyber Pink", price: 0, sfx: "neon", bg: "radial-gradient(circle at 30% 30%, #ff99e6, #ff007f)", glow: "0 0 20px rgba(255, 0, 127, 0.85)", border: "2px solid #ffb3ec", textColor: "#fff", floatColor: "#ff4da6", emoji: "" },
      { id: "toxic_green", name: "Toxic Lime", price: 0, sfx: "neon", bg: "radial-gradient(circle at 30% 30%, #c8ff70, #22c55e)", glow: "0 0 20px rgba(34, 197, 94, 0.85)", border: "2px solid #d9ffb3", textColor: "#061b0c", floatColor: "#4ade80", emoji: "" },
      { id: "crimson_laser", name: "Crimson Red", price: 25, sfx: "neon", bg: "radial-gradient(circle at 30% 30%, #ff8a8a, #e50914)", glow: "0 0 20px rgba(229, 9, 20, 0.88)", border: "2px solid #ffb3b3", textColor: "#fff", floatColor: "#ff4d5a", emoji: "" },
      { id: "solar_orange", name: "Solar Flare", price: 35, sfx: "neon", bg: "radial-gradient(circle at 30% 30%, #ffd280, #ff6b00)", glow: "0 0 20px rgba(255, 107, 0, 0.88)", border: "2px solid #ffe0a3", textColor: "#1f0c00", floatColor: "#ff9233", emoji: "" },
      { id: "electric_violet", name: "Neon Violet", price: 45, sfx: "neon", bg: "radial-gradient(circle at 30% 30%, #d8b4fe, #7c3aed)", glow: "0 0 20px rgba(124, 58, 237, 0.9)", border: "2px solid #e9d5ff", textColor: "#fff", floatColor: "#c084fc", emoji: "" }
    ]
  },
  {
    id: "energy",
    title: "🔥 Elemental & Energy Orbs",
    balls: [
      { id: "inferno_orb", name: "Inferno Fire", price: 60, sfx: "fire", bg: "radial-gradient(circle at 35% 35%, #fff099, #ff5e00 55%, #990000 100%)", glow: "0 0 24px rgba(255, 94, 0, 0.95)", border: "2px solid #ffd166", textColor: "#fff", floatColor: "#ff7b29", emoji: "🔥" },
      { id: "thunder_orb", name: "Thunder Bolt", price: 75, sfx: "thunder", bg: "radial-gradient(circle at 30% 30%, #fff9c4, #facc15 55%, #b45309 100%)", glow: "0 0 24px rgba(250, 204, 21, 0.95)", border: "2px solid #fef08a", textColor: "#1c1917", floatColor: "#fde047", emoji: "⚡" },
      { id: "frost_crystal", name: "Frost Ice", price: 85, sfx: "frost", bg: "radial-gradient(circle at 30% 30%, #ffffff, #7dd3fc 55%, #0284c7 100%)", glow: "0 0 22px rgba(125, 211, 252, 0.95)", border: "2px solid #e0f2fe", textColor: "#082f49", floatColor: "#7dd3fc", emoji: "❄️" },
      { id: "galaxy_void", name: "Galaxy Void", price: 110, sfx: "aura", bg: "radial-gradient(circle at 30% 30%, #a855f7, #312e81 60%, #09071a 100%)", glow: "0 0 24px rgba(168, 85, 247, 0.95)", border: "2px solid #c084fc", textColor: "#fff", floatColor: "#c084fc", emoji: "🌌" },
      { id: "prism_rainbow", name: "Rainbow Prism", price: 140, sfx: "frost", bg: "conic-gradient(from 0deg, #ff3d5a, #ffbe0b, #00f5d4, #3a86ff, #8338ec, #ff3d5a)", glow: "0 0 22px rgba(255, 255, 255, 0.75)", border: "2px solid #ffffff", textColor: "#fff", floatColor: "#ffffff", emoji: "✨" },
      { id: "diamond_core", name: "Diamond Core", price: 160, sfx: "frost", bg: "radial-gradient(circle at 30% 30%, #ffffff, #67e8f9 55%, #0e7490 100%)", glow: "0 0 22px rgba(103, 232, 249, 0.95)", border: "2px solid #cffafe", textColor: "#083344", floatColor: "#67e8f9", emoji: "💎" }
    ]
  },
  {
    id: "aura",
    title: "🌀 Power Aura Spheres",
    balls: [
      { id: "blue_rasen", name: "Wind Spiral", price: 120, sfx: "aura", bg: "radial-gradient(circle at center, #ffffff 10%, #38bdf8 45%, #1d4ed8 100%)", glow: "0 0 26px rgba(56, 189, 248, 0.95)", border: "2px solid #bae6fd", textColor: "#082f49", floatColor: "#38bdf8", emoji: "🌀" },
      { id: "cursed_purple", name: "Hollow Purple", price: 180, sfx: "aura", bg: "radial-gradient(circle at center, #f5d0fe 10%, #9333ea 55%, #3b0764 100%)", glow: "0 0 28px rgba(192, 38, 211, 0.95)", border: "2px solid #f0abfc", textColor: "#fff", floatColor: "#e879f9", emoji: "🟣" },
      { id: "shadow_monarch", name: "Shadow Core", price: 220, sfx: "aura", bg: "radial-gradient(circle at center, #60a5fa 12%, #1e1b4b 60%, #020617 100%)", glow: "0 0 26px rgba(59, 130, 246, 0.95)", border: "2px solid #60a5fa", textColor: "#fff", floatColor: "#60a5fa", emoji: "👁️" },
      { id: "dragon_soul", name: "Dragon Sphere", price: 250, sfx: "fire", bg: "radial-gradient(circle at 30% 30%, #fef08a, #f97316 60%, #c2410c 100%)", glow: "0 0 24px rgba(249, 115, 22, 0.95)", border: "2px solid #fed7aa", textColor: "#fff", floatColor: "#fb923c", emoji: "🐉" },
      { id: "blood_moon", name: "Blood Moon", price: 280, sfx: "aura", bg: "radial-gradient(circle at 35% 35%, #fca5a5, #b91c1c 58%, #450a0a 100%)", glow: "0 0 25px rgba(220, 38, 38, 0.95)", border: "2px solid #f87171", textColor: "#fff", floatColor: "#f87171", emoji: "🔴" },
      { id: "emerald_force", name: "Emerald Aura", price: 320, sfx: "aura", bg: "radial-gradient(circle at center, #d1fae5 12%, #10b981 55%, #064e3b 100%)", glow: "0 0 24px rgba(16, 185, 129, 0.95)", border: "2px solid #6ee7b7", textColor: "#022c22", floatColor: "#34d399", emoji: "❇️" }
    ]
  },
  {
    id: "sports",
    title: "🏀 Sports & Gaming Balls",
    balls: [
      { id: "basketball", name: "Basketball", price: 40, sfx: "bounce", bg: "radial-gradient(circle at 30% 30%, #fdba74, #ea580c)", glow: "0 0 18px rgba(234, 88, 12, 0.8)", border: "2px solid #fed7aa", textColor: "#fff", floatColor: "#fb923c", emoji: "🏀" },
      { id: "volleyball", name: "Volleyball", price: 50, sfx: "bounce", bg: "radial-gradient(circle at 30% 30%, #fef9c3, #e2e8f0)", glow: "0 0 18px rgba(255, 255, 255, 0.75)", border: "2px solid #f8fafc", textColor: "#000", floatColor: "#ffffff", emoji: "🏐" },
      { id: "football", name: "Football", price: 55, sfx: "bounce", bg: "radial-gradient(circle at 30% 30%, #ffffff, #cbd5e1)", glow: "0 0 18px rgba(255, 255, 255, 0.7)", border: "2px solid #f8fafc", textColor: "#000", floatColor: "#ffffff", emoji: "⚽" },
      { id: "bullseye", name: "Aim Target", price: 70, sfx: "neon", bg: "radial-gradient(circle at 30% 30%, #fecaca, #dc2626)", glow: "0 0 20px rgba(220, 38, 38, 0.85)", border: "2px solid #fca5a5", textColor: "#fff", floatColor: "#f87171", emoji: "🎯" },
      { id: "skull_pro", name: "Pro Skull", price: 100, sfx: "fire", bg: "radial-gradient(circle at 30% 30%, #475569, #0f172a)", glow: "0 0 20px rgba(148, 163, 184, 0.8)", border: "2px solid #94a3b8", textColor: "#fff", floatColor: "#e2e8f0", emoji: "💀" },
      { id: "bomb_ball", name: "Nitro Bomb", price: 130, sfx: "fire", bg: "radial-gradient(circle at 30% 30%, #52525b, #18181b)", glow: "0 0 20px rgba(255, 107, 43, 0.85)", border: "2px solid #ff6b2b", textColor: "#fff", floatColor: "#ff6b2b", emoji: "💣" }
    ]
  }
];

const ALL_BALLS = BALL_SECTIONS.flatMap((s) => s.balls);

// Badges Definition
const BADGES = [
  { id: "first_game", icon: "🎯", title: "First Blood", desc: "Play your first game", reward: 15 },
  { id: "combo_king", icon: "🔥", title: "Combo King", desc: "Reach a 10x Combo streak", reward: 30 },
  { id: "speed_demon", icon: "⚡", title: "Speed Demon", desc: "Score 40+ in one round", reward: 40 },
  { id: "god_reflex", icon: "👑", title: "God-Tier Reflex", desc: "Score 60+ in one round", reward: 75 },
  { id: "taps_master", icon: "👆", title: "1000 Taps Master", desc: "Reach 1,000 lifetime taps", reward: 100 },
  { id: "collector", icon: "🎨", title: "Ball Collector", desc: "Unlock 8 different balls", reward: 50 },
  { id: "insane_pro", icon: "💎", title: "Insane Survivor", desc: "Score 25+ in Insane mode", reward: 60 },
  { id: "coin_tycoon", icon: "🪙", title: "Coin Tycoon", desc: "Earn 250+ lifetime coins", reward: 45 }
];

// Persistent State
const DEFAULT_SAVE = {
  nickname: "Sahil",
  avatar: "🥷",
  bestScore: 0,
  coins: 0,
  totalCoinsEarned: 0,
  totalTaps: 0,
  gamesPlayed: 0,
  selectedBallId: "cyan_pulse",
  unlockedBalls: ["cyan_pulse", "cyber_pink", "toxic_green"],
  unlockedBadges: []
};

let save = { ...DEFAULT_SAVE };
try {
  const raw = localStorage.getItem("neon_reflex_v4_save");
  if (raw) {
    const parsed = JSON.parse(raw);
    save = {
      ...DEFAULT_SAVE,
      ...parsed,
      unlockedBalls: Array.isArray(parsed.unlockedBalls) ? parsed.unlockedBalls : DEFAULT_SAVE.unlockedBalls,
      unlockedBadges: Array.isArray(parsed.unlockedBadges) ? parsed.unlockedBadges : []
    };
  }
} catch (e) {}

function persistSave() {
  try {
    localStorage.setItem("neon_reflex_v4_save", JSON.stringify(save));
  } catch (e) {}
}

// Runtime State
let score = 0;
let timeLeft = 30;
let combo = 0;
let maxCombo = 0;
let timerId = null;
let spawnTimeout = null;
let running = false;
let soundOn = true;
let musicOn = true;
let difficulty = "normal";
let activeTab = "all";
let audioCtx = null;
let toastTimer = null;

bgmAudio.volume = 0.45;

function ensureAudioCtx() {
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) return null;
  if (!audioCtx) audioCtx = new AudioContextClass();
  if (audioCtx.state === "suspended") audioCtx.resume();
  return audioCtx;
}

function startMusicIfAllowed() {
  if (!musicOn) return;
  bgmAudio.play().catch(() => {});
}

// Custom Sound Pack Synthesizer
function playBallSound(type, isGold = false) {
  if (!soundOn) return;
  const ctx = ensureAudioCtx();
  if (!ctx) return;
  const now = ctx.currentTime;

  if (isGold) {
    // Golden Jackpot Chord
    [880, 1108, 1318].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(freq, now + i * 0.03);
      g.gain.setValueAtTime(0.11, now + i * 0.03);
      g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.03 + 0.16);
      osc.connect(g);
      g.connect(ctx.destination);
      osc.start(now + i * 0.03);
      osc.stop(now + i * 0.03 + 0.16);
    });
    return;
  }

  if (type === "bounce") {
    // Basketball / Volleyball realistic rubber bounce thump
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(195, now);
    osc.frequency.exponentialRampToValueAtTime(68, now + 0.11);
    g.gain.setValueAtTime(0.28, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.13);
    osc.connect(g);
    g.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.13);
    return;
  }

  if (type === "thunder") {
    // Electric zap crackle
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(920, now);
    osc.frequency.exponentialRampToValueAtTime(140, now + 0.09);
    g.gain.setValueAtTime(0.14, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
    osc.connect(g);
    g.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.1);
    return;
  }

  if (type === "frost") {
    // Crystalline glass/ice chime
    [1560, 2090].forEach((freq) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, now);
      g.gain.setValueAtTime(0.09, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
      osc.connect(g);
      g.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.14);
    });
    return;
  }

  if (type === "fire") {
    // Deep bassy pop boom
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(240, now);
    osc.frequency.exponentialRampToValueAtTime(55, now + 0.14);
    g.gain.setValueAtTime(0.22, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
    osc.connect(g);
    g.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.15);
    return;
  }

  if (type === "aura") {
    // Sci-fi resonant energy pulse
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(340, now);
    osc.frequency.exponentialRampToValueAtTime(760, now + 0.11);
    g.gain.setValueAtTime(0.15, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.13);
    osc.connect(g);
    g.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.13);
    return;
  }

  // Default Neon Pop (pitch climbs slightly with combo)
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = "triangle";
  const baseFreq = Math.min(950, 480 + combo * 24);
  osc.frequency.setValueAtTime(baseFreq, now);
  g.gain.setValueAtTime(0.13, now);
  g.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
  osc.connect(g);
  g.connect(ctx.destination);
  osc.start(now);
  osc.stop(now + 0.08);
}

function playUiSound(freq, dur = 0.08) {
  if (!soundOn) return;
  const ctx = ensureAudioCtx();
  if (!ctx) return;
  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = "triangle";
  osc.frequency.setValueAtTime(freq, now);
  g.gain.setValueAtTime(0.12, now);
  g.gain.exponentialRampToValueAtTime(0.001, now + dur);
  osc.connect(g);
  g.connect(ctx.destination);
  osc.start(now);
  osc.stop(now + dur);
}

function showToast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.remove("hidden");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.add("hidden"), 2600);
}

function getSelectedBall() {
  return ALL_BALLS.find((b) => b.id === save.selectedBallId) || ALL_BALLS[0];
}

function applyBallStyle(el, ball, labelText = "+1") {
  el.style.background = ball.bg;
  el.style.boxShadow = ball.glow;
  el.style.border = ball.border;
  el.style.color = ball.textColor;
  if (ball.emoji) {
    el.innerHTML = `<span class="ball-emoji">${ball.emoji}</span>`;
  } else {
    el.textContent = labelText;
  }
}

function syncHeaderUI() {
  bestEl.textContent = save.bestScore;
  coinCountEl.textContent = save.coins;
  shopCoinsEl.textContent = `${save.coins} 🪙`;
  headerAvatar.textContent = save.avatar;
  headerName.textContent = save.nickname;
  const ball = getSelectedBall();
  selectedBallName.textContent = ball.name;
  applyBallStyle(selectedBallPreview, ball, "+1");
}

// Badges Checker
function checkAndUnlockBadges(roundScore = 0, roundMaxCombo = 0, roundDiff = "normal") {
  const checks = {
    first_game: save.gamesPlayed >= 1,
    combo_king: roundMaxCombo >= 10,
    speed_demon: roundScore >= 40,
    god_reflex: roundScore >= 60,
    taps_master: save.totalTaps >= 1000,
    collector: save.unlockedBalls.length >= 8,
    insane_pro: roundDiff === "insane" && roundScore >= 25,
    coin_tycoon: save.totalCoinsEarned >= 250
  };

  let newlyUnlocked = [];
  BADGES.forEach((b) => {
    if (!save.unlockedBadges.includes(b.id) && checks[b.id]) {
      save.unlockedBadges.push(b.id);
      save.coins += b.reward;
      save.totalCoinsEarned += b.reward;
      newlyUnlocked.push(b);
    }
  });

  if (newlyUnlocked.length > 0) {
    persistSave();
    syncHeaderUI();
    playBallSound("neon", true);
    showToast(`🏆 Badge Unlocked: ${newlyUnlocked[0].title} (+${newlyUnlocked[0].reward} 🪙)`);
  }
}

// Render Ball Shop
function renderSkinSections() {
  shopCoinsEl.textContent = `${save.coins} 🪙`;
  skinsContainer.innerHTML = "";
  const sectionsToShow = activeTab === "all"
    ? BALL_SECTIONS
    : BALL_SECTIONS.filter((s) => s.id === activeTab);

  sectionsToShow.forEach((section) => {
    const secEl = document.createElement("div");

    const titleEl = document.createElement("div");
    titleEl.className = "skin-section-title";
    titleEl.innerHTML = `<span>${section.title}</span><span>${section.balls.length}</span>`;
    secEl.appendChild(titleEl);

    const gridEl = document.createElement("div");
    gridEl.className = "skin-grid";

    section.balls.forEach((ball) => {
      const isUnlocked = save.unlockedBalls.includes(ball.id);
      const isSelected = ball.id === save.selectedBallId;

      const card = document.createElement("div");
      card.className = `skin-card ${isSelected ? "selected" : ""} ${!isUnlocked ? "locked" : ""}`;

      const orb = document.createElement("div");
      orb.className = "skin-orb";
      applyBallStyle(orb, ball, "+1");

      const name = document.createElement("div");
      name.className = "skin-name";
      name.textContent = ball.name;

      const status = document.createElement("div");
      if (isUnlocked) {
        status.className = "owned-tag";
        status.textContent = isSelected ? "Equipped" : "Owned";
      } else {
        status.className = "price-tag";
        status.textContent = `🔒 ${ball.price} 🪙`;
      }

      card.appendChild(orb);
      card.appendChild(name);
      card.appendChild(status);

      card.addEventListener("click", () => {
        if (isUnlocked) {
          save.selectedBallId = ball.id;
          persistSave();
          playBallSound(ball.sfx, false);
          syncHeaderUI();
          renderSkinSections();
        } else {
          if (save.coins >= ball.price) {
            save.coins -= ball.price;
            save.unlockedBalls.push(ball.id);
            save.selectedBallId = ball.id;
            persistSave();
            playBallSound("neon", true);
            syncHeaderUI();
            renderSkinSections();
            showToast(`🎉 Unlocked ${ball.name}!`);
            checkAndUnlockBadges();
          } else {
            playUiSound(180, 0.1);
            showToast(`Need ${ball.price - save.coins} more 🪙 to unlock!`);
          }
        }
      });

      gridEl.appendChild(card);
    });

    secEl.appendChild(gridEl);
    skinsContainer.appendChild(secEl);
  });
}

// Render Profile & Badges
function renderProfileModal() {
  profileAvatarBig.textContent = save.avatar;
  nicknameInput.value = save.nickname;
  statTotalTaps.textContent = save.totalTaps;
  statGames.textContent = save.gamesPlayed;
  statBalls.textContent = `${save.unlockedBalls.length}/${ALL_BALLS.length}`;
  statBadges.textContent = `${save.unlockedBadges.length}/${BADGES.length}`;
  badgesProgress.textContent = `${save.unlockedBadges.length} / ${BADGES.length}`;

  avatarGrid.innerHTML = "";
  AVATARS.forEach((av) => {
    const btn = document.createElement("button");
    btn.className = `avatar-opt ${av === save.avatar ? "active" : ""}`;
    btn.textContent = av;
    btn.addEventListener("click", () => {
      save.avatar = av;
      persistSave();
      playUiSound(600, 0.06);
      syncHeaderUI();
      renderProfileModal();
    });
    avatarGrid.appendChild(btn);
  });

  badgesList.innerHTML = "";
  BADGES.forEach((b) => {
    const unlocked = save.unlockedBadges.includes(b.id);
    const row = document.createElement("div");
    row.className = `badge-row ${unlocked ? "unlocked" : ""}`;
    row.innerHTML = `
      <div class="badge-icon">${b.icon}</div>
      <div class="badge-info">
        <h4>${b.title}</h4>
        <p>${b.desc}</p>
      </div>
      <div class="badge-status ${unlocked ? "done" : "todo"}">
        ${unlocked ? "✓ Done" : `+${b.reward} 🪙`}
      </div>
    `;
    badgesList.appendChild(row);
  });
}

function stopActiveRound() {
  if (running) {
    running = false;
    clearInterval(timerId);
    clearTimeout(spawnTimeout);
    clearTargets();
    startOverlay.classList.remove("hidden");
  }
}

// Modal Controls
function openSkinsModal() {
  stopActiveRound();
  renderSkinSections();
  skinsModal.classList.remove("hidden");
}

function closeSkinsModal() {
  skinsModal.classList.add("hidden");
}

function openProfileModal() {
  stopActiveRound();
  renderProfileModal();
  profileModal.classList.remove("hidden");
}

function closeProfileModal() {
  profileModal.classList.add("hidden");
}

openSkinsBtn.addEventListener("click", openSkinsModal);
changeBallBtn.addEventListener("click", (e) => { e.stopPropagation(); openSkinsModal(); });
selectedBallCard.addEventListener("click", openSkinsModal);
endSkinsBtn.addEventListener("click", openSkinsModal);
closeSkinsBtn.addEventListener("click", closeSkinsModal);
applySkinBtn.addEventListener("click", closeSkinsModal);
skinsModal.addEventListener("click", (e) => { if (e.target === skinsModal) closeSkinsModal(); });

openProfileBtn.addEventListener("click", openProfileModal);
endProfileBtn.addEventListener("click", openProfileModal);
closeProfileBtn.addEventListener("click", closeProfileModal);
closeProfileFooterBtn.addEventListener("click", closeProfileModal);
profileModal.addEventListener("click", (e) => { if (e.target === profileModal) closeProfileModal(); });

saveProfileBtn.addEventListener("click", () => {
  const val = nicknameInput.value.trim();
  save.nickname = val || "Player";
  persistSave();
  syncHeaderUI();
  playUiSound(700, 0.08);
  showToast("✅ Profile saved!");
});

skinTabs.addEventListener("click", (e) => {
  const btn = e.target.closest(".tab-btn");
  if (!btn) return;
  skinTabs.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
  btn.classList.add("active");
  activeTab = btn.dataset.tab;
  renderSkinSections();
});

telegramFab.addEventListener("pointerdown", (e) => e.stopPropagation());
telegramFab.addEventListener("click", () => stopActiveRound());

// Audio Toggles
soundToggle.addEventListener("click", () => {
  soundOn = !soundOn;
  soundToggle.textContent = soundOn ? "🔊" : "🔇";
  soundToggle.classList.toggle("muted-btn", !soundOn);
});

musicToggle.addEventListener("click", () => {
  musicOn = !musicOn;
  musicToggle.classList.toggle("muted-btn", !musicOn);
  if (musicOn) {
    bgmAudio.play().catch(() => {});
  } else {
    bgmAudio.pause();
  }
});

diffBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    diffBtns.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    difficulty = btn.dataset.speed;
  });
});

// Gameplay
function clearTargets() {
  arena.querySelectorAll(".target, .float-score").forEach((el) => el.remove());
}

function showFloatText(x, y, text, color) {
  const el = document.createElement("div");
  el.className = "float-score";
  el.textContent = text;
  el.style.left = `${x}px`;
  el.style.top = `${y}px`;
  el.style.color = color;
  arena.appendChild(el);
  setTimeout(() => el.remove(), 550);
}

function spawnTarget() {
  if (!running) return;
  clearTargets();

  const rect = arena.getBoundingClientRect();
  const isGold = Math.random() < 0.22;
  const ball = getSelectedBall();

  let size = 64;
  if (difficulty === "pro") size = isGold ? 48 : 54;
  else if (difficulty === "insane") size = isGold ? 44 : 48;
  else size = isGold ? 56 : 64;

  const maxX = Math.max(10, rect.width - size - 16);
  const maxY = Math.max(10, rect.height - size - 72);
  const x = Math.floor(Math.random() * maxX) + 8;
  const y = Math.floor(Math.random() * maxY) + 8;

  const target = document.createElement("div");
  target.className = `target ${isGold ? "gold-bonus" : ""}`;
  target.style.width = `${size}px`;
  target.style.height = `${size}px`;
  target.style.left = `${x}px`;
  target.style.top = `${y}px`;

  if (isGold) {
    target.style.background = "radial-gradient(circle at 30% 30%, #fff3b0, #ffae00)";
    target.style.color = "#0b0d14";
    if (ball.emoji) {
      target.innerHTML = `<span class="ball-emoji">${ball.emoji}</span><span class="bonus-tag">+3</span>`;
    } else {
      target.textContent = "+3";
    }
  } else {
    applyBallStyle(target, ball, "+1");
  }

  target.addEventListener("pointerdown", (e) => {
    e.stopPropagation();
    if (!running) return;

    const points = isGold ? 3 : 1;
    score += points;
    combo += 1;
    save.totalTaps += 1;
    if (combo > maxCombo) maxCombo = combo;

    scoreEl.textContent = score;
    comboText.textContent = combo >= 3 ? `🔥 ${combo}x Combo Streak!` : "Nice hit!";

    playBallSound(ball.sfx, isGold);
    try { if (navigator.vibrate) navigator.vibrate(15); } catch (err) {}

    showFloatText(x + size / 4, y, `+${points}`, isGold ? "#ffd166" : ball.floatColor);
    clearTimeout(spawnTimeout);
    spawnTarget();
  });

  arena.appendChild(target);

  let stayTime = 1400;
  if (difficulty === "pro") stayTime = 950;
  else if (difficulty === "insane") stayTime = 720;

  spawnTimeout = setTimeout(() => {
    if (!running) return;
    combo = 0;
    comboText.textContent = "Missed! Combo reset.";
    spawnTarget();
  }, stayTime);
}

arena.addEventListener("pointerdown", (e) => {
  if (!running) return;
  if (e.target === arena) {
    combo = 0;
    comboText.textContent = "Miss tap! Ball par tap karo.";
    playUiSound(190, 0.07);
  }
});

function endGame() {
  running = false;
  clearInterval(timerId);
  clearTimeout(spawnTimeout);
  clearTargets();

  save.gamesPlayed += 1;
  if (score > save.bestScore) {
    save.bestScore = score;
  }

  // Calculate Coins Earned (score + combo bonus)
  const diffMult = difficulty === "insane" ? 1.5 : difficulty === "pro" ? 1.25 : 1;
  const earnedCoins = Math.max(2, Math.round((score + Math.floor(maxCombo / 2)) * diffMult));
  save.coins += earnedCoins;
  save.totalCoinsEarned += earnedCoins;

  persistSave();
  syncHeaderUI();

  // Check Badges
  checkAndUnlockBadges(score, maxCombo, difficulty);

  finalScoreEl.textContent = score;
  finalComboEl.textContent = `${maxCombo}x`;
  finalCoinsEl.textContent = `+${earnedCoins} 🪙`;
  finalTotalCoinsEl.textContent = `${save.coins} 🪙`;

  if (score >= 50) finalRankEl.textContent = "God-Tier Reflex! ⚡";
  else if (score >= 28) finalRankEl.textContent = "Pro Gamer Speed! 🔥";
  else finalRankEl.textContent = "Good Warmup! 💪";

  endOverlay.classList.remove("hidden");
  playUiSound(330, 0.22);
}

function startGame() {
  ensureAudioCtx();
  startMusicIfAllowed();

  score = 0;
  timeLeft = 30;
  combo = 0;
  maxCombo = 0;
  running = true;

  scoreEl.textContent = "0";
  timeEl.textContent = "30s";
  comboText.textContent = "Go! Balls tap karo!";
  startOverlay.classList.add("hidden");
  endOverlay.classList.add("hidden");

  spawnTarget();

  clearInterval(timerId);
  timerId = setInterval(() => {
    timeLeft -= 1;
    timeEl.textContent = `${timeLeft}s`;
    if (timeLeft <= 0) {
      endGame();
    }
  }, 1000);
}

startBtn.addEventListener("click", startGame);
restartBtn.addEventListener("click", startGame);

// Init UI
syncHeaderUI();
