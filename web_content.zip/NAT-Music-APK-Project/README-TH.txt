NAT Music APK project

วิธีสร้าง APK:
1. ติดตั้ง Android Studio
2. เปิดโฟลเดอร์นี้ด้วย Open
3. รอ Gradle Sync ให้เสร็จ
4. ไปที่ Build > Build Bundle(s) / APK(s) > Build APK(s)
5. APK จะอยู่ใน app/build/outputs/apk/debug/app-debug.apk

โปรเจกต์นี้นำ index.html ของ NAT Music มาใส่ใน WebView และเปิด Internet/JavaScript/DOM storage/third-party cookies เพื่อให้ YouTube/Spotify embed ทำงานได้ดีขึ้น

ข้อจำกัด:
- การห่อเว็บเป็น APK ไม่ได้ทำให้ YouTube iframe เล่นต่อหลังล็อกจอได้อัตโนมัติ
- ถ้าต้องการ background audio จริง ต้องใช้ native audio playback/Media3 กับแหล่งเสียงที่อนุญาตให้เล่นแบบ background
- ไม่ควรใช้ APK เพื่อดึง/แปลงเสียง YouTube หรือข้ามโฆษณา/ข้อจำกัดของ YouTube
