NAT Music - Ready package

Deploy the whole folder to Netlify, Cloudflare Pages, GitHub Pages, or another static host.
No API key and no server function are required.

Usage:
1. Paste a YouTube video/playlist or Spotify track/playlist URL.
2. Press เปิด.
3. "เล่นบนพื้นหลัง" is a UI/PWA mode and the site does not pause the player when hidden.
4. "หยุดเมื่อหน้าจอดับ" asks the YouTube player to pause when the page becomes hidden.

Important:
A normal HTML page cannot force YouTube/Spotify embedded players to continue after Android locks the screen, nor after the device powers off. This package does not falsely claim to bypass those platform restrictions.
For true lock-screen/background audio from YouTube, a native app or a service/player with permitted background playback is required.
