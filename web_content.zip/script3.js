
(function(){
 const KEY='shaikh_box_erp_display_preferences_v1';
 const defaults={caps:true,bold:true,font:'Arial',size:'normal',theme:'navy',confirmDelete:true,autoSave:true,sound:false,compactCards:false};
 function read(){try{return Object.assign({},defaults,JSON.parse(localStorage.getItem(KEY)||'{}'));}catch(e){return Object.assign({},defaults);}}
 function apply(p){
   const root=document.documentElement;
   root.classList.toggle('user-uppercase',!!p.caps);
   root.classList.toggle('user-bold',!!p.bold);
   root.dataset.userFont=p.font||'Arial';root.dataset.userSize=p.size||'normal';root.dataset.userTheme=p.theme||'navy';
   root.classList.toggle('compact-cards',!!p.compactCards);
   if(document.body) document.body.dataset.confirmDelete=p.confirmDelete?'1':'0';
 }
 window.saveDisplayPrefs=function(){
   const p={caps:!!document.getElementById('prefCaps')?.checked,bold:!!document.getElementById('prefBold')?.checked,
     font:document.getElementById('prefFont')?.value||'Arial',size:document.getElementById('prefSize')?.value||'normal',
     theme:document.getElementById('prefTheme')?.value||'navy',confirmDelete:!!document.getElementById('prefConfirmDelete')?.checked,
     autoSave:!!document.getElementById('prefAutoSave')?.checked,sound:!!document.getElementById('prefSound')?.checked,
     compactCards:!!document.getElementById('prefCompactCards')?.checked};
   try{localStorage.setItem(KEY,JSON.stringify(p));apply(p);const n=document.getElementById('displayPrefsStatus');if(n)n.textContent='PREFERENCES SAVED';}catch(e){alert('COULD NOT SAVE PREFERENCES. CHECK DEVICE STORAGE.');}
 };
 window.resetDisplayPrefs=function(){try{localStorage.removeItem(KEY);}catch(e){};populate(defaults);apply(defaults);};
 function populate(p){
  const map={prefCaps:p.caps,prefBold:p.bold,prefFont:p.font,prefSize:p.size,prefTheme:p.theme,prefConfirmDelete:p.confirmDelete,prefAutoSave:p.autoSave,prefSound:p.sound,prefCompactCards:p.compactCards};
  Object.keys(map).forEach(id=>{const el=document.getElementById(id);if(el){if(el.type==='checkbox')el.checked=!!map[id];else el.value=map[id];}});
 }
 function init(){const p=read();apply(p);populate(p);}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
