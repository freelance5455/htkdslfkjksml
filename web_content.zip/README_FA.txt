حسابیار - پروژه Android Studio
Android Studio و JDK 17 لازم است.
پروژه را Open کنید و بعد Build > Build APK(s) را بزنید.
APK در app/build/outputs/apk/debug/app-debug.apk ساخته می‌شود.
این نسخه آفلاین است و اطلاعات در WebView همان گوشی ذخیره می‌شود.
