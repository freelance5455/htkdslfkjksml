M.S.N Web-to-APK starter
1) Upload index.html or ZIP this folder into a web-to-APK service that accepts HTML projects.
2) Set app name to M.S.N and package ID e.g. org.msn.alarm.
3) Build and install the APK.
Important limitations:
- This is a mobile web implementation of the core alarm/math interaction, not a direct conversion of the Python/Kivy app.
- It stores alarms and stats in browser localStorage.
- Alarm scheduling only works while the web app is running and may be paused by Android when backgrounded/locked. Reliable alarms while closed require native Android alarm/service integration.
- The original WAV was not used because web audio needs a user gesture; this version uses a simple generated beep for testing.
