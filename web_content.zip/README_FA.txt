Wallet Finder — APK-ready web package

ساختار پیشنهادی برای برنامه HTML to APK:
- اگر برنامه پوشه/Project می‌گیرد: همین پوشه را وارد کنید و Start Page را روی web/index.html بگذارید.
- اگر فقط یک فایل HTML می‌گیرد: index.html را به عنوان Start Page انتخاب کنید.
- اگر گزینه Web Folder / Assets Folder دارد: پوشه web را به عنوان Web Folder انتخاب کنید.

نکته: بخش قیمت لحظه‌ای و QR Scanner به اینترنت نیاز دارند؛ صفحه اصلی و تصاویر داخل بسته محلی هستند.
