CryptoPulse V100 FinalStable

نسخه نهایی پایدار پروژه موبایلی CryptoPulse.

قابلیت‌های شاخص:
- داده زنده LBank با fallback به Binance
- اتصال WebSocket و reconnect خودکار
- کندل چندتایم‌فریمی
- زوم دو انگشتی و جابه‌جایی نمودار
- Order Book و انتخاب قیمت برای فرم معامله
- کیف پول، معاملات، سفارش‌ها و پروفایل
- Trailing Stop
- Partial Close
- Liquidation Guard
- Trade Analytics
- Live RSI/EMA
- Smart Notifications
- Crash Recovery
- تم روشن و رابط موبایلی سبک
- نسخه اپلیکیشن: 10.0.0 / versionCode 100

نکته:
این بسته سورس پروژه Android Studio است و در محیط فعلی ابزار Gradle/Android SDK برای تولید APK در دسترس نیست؛ بنابراین APK ادعا نمی‌شود.


V100 updates: Spot/Futures trade terminals separated with direct tabs; 0-100% capital allocation sliders show live entered amount; Futures chart loads 200 candles for wider historical price visibility.
