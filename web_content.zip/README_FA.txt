Zahid Rise - Android Project
این پروژه نسخه اندرویدی Zahid Rise است و فایل index.html را داخل WebView اجرا می‌کند.

برای ساخت APK/AAB:
1) پروژه را در Android Studio باز کنید.
2) Gradle Sync را اجرا کنید.
3) از Build > Build APK(s) خروجی APK بگیرید.
4) برای Google Play از Build > Generate Signed Bundle / APK و AAB استفاده کنید.

تبلیغات هنوز فعال نشده‌اند؛ برای درآمد باید حساب تبلیغاتی و شناسه‌های تبلیغات واقعی خودتان اضافه شود.
