# TOMTOM CHESS
پروژه آماده Android برای تبدیل بازی HTML به اپ اندروید.
- نام: TOMTOM CHESS
- نسخه: 1.0
- شناسه بسته: com.tomtom.chess
- جهت: عمودی
- حداقل Android: 6.0
- هدف Android: 15
فایل بازی در app/src/main/assets/index.html قرار دارد.
