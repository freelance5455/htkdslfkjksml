YOBRA AndroidIDE project

BUILD ON YOUR ANDROID PHONE
1. Extract this ZIP to a normal folder, for example Internal storage/AndroidIDEProjects/YOBRA.
2. In AndroidIDE, choose Open project and select the extracted YOBRA folder (the folder containing settings.gradle).
3. Allow Gradle sync/downloads and install any SDK platform/build tools AndroidIDE requests. Internet is needed for this first sync.
4. When sync finishes, choose Build > Assemble Project (or run the Gradle task :app:assembleDebug).
5. The debug APK should be at app/build/outputs/apk/debug/app-debug.apk.
6. Tap the APK in your file manager to install it. If Android asks, allow installs from that file manager.

APP CONTENT
The Android app opens the included YOBRA web prototype in a native WebView. It supports local demo posts, media selection, likes, comments, follow, share, reshare, groups, local messages, and an offline research guide. Data is stored locally on the device.

IMPORTANT
This is not yet a production online social network. Login is a local demo profile; chats/posts/groups are not synchronized to other users. Real secure accounts, realtime messaging, cloud media and live AI require backend integration.
If Gradle reports a plugin/SDK version unavailable, share the exact error text or screenshot so the versions can be adjusted to your AndroidIDE setup.
