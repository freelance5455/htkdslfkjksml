# SafeNex Android Project

Ready-to-build Android Studio project wrapping the supplied SafeNex web app in a native Android WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Choose **Build > Build APK(s)**.
4. The debug APK will be under `app/build/outputs/apk/debug/`.

## Notes
- Package: `com.safenex.app`
- App name: SafeNex
- Portrait orientation enabled.
- Camera permission is declared/requested for scanner functionality.
- JavaScript, DOM storage, and local asset loading are enabled.
- The supplied HTML is bundled as `app/src/main/assets/index.html`.

If the HTML app uses external CDN/API resources, an internet connection is required. For production distribution, review permissions and signing configuration before publishing.
