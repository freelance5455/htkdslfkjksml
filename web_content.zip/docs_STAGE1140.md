# CPLS V2 — Stage 1140

## Candle Gap / Freshness Monitor
- Extends gap monitoring with latest-candle freshness detection.
- Distinguishes historical gaps from a stale live boundary.
- Reports a delay warning without fabricating candles or prices.
- Preserves prior candle integrity, merge, zoom/pan and live continuity behavior.

Source ZIP stage only; APK build not performed.
