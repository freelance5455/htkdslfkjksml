# Gym Tracker — app web instalable

## Qué incluye
- Rutina de lunes a viernes editable.
- Seguimiento de series completadas, pesos y número de series.
- Temporizador de descanso con pitido y vibración cuando el navegador lo permite.
- Librería de ejercicios y opción de añadirlos a cualquier día.
- Guardado local en el teléfono y copia de seguridad JSON.
- Interfaz adaptada a móvil y modo sin conexión después de la primera carga.

## Cómo instalar en Android
Una PWA necesita servirse desde una dirección HTTPS (o localhost); abrir `index.html` directamente no permite instalarla como app.
1. Sube todos los archivos de esta carpeta a un hosting estático HTTPS, por ejemplo GitHub Pages, Netlify o Cloudflare Pages.
2. Abre la dirección HTTPS en Chrome en tu Android.
3. Pulsa el menú ⋮ y elige **Instalar aplicación** o **Añadir a pantalla de inicio**.
4. Abre la app desde el nuevo icono.

## Importante
Los datos se guardan en el almacenamiento del navegador de ese dispositivo. Usa **Ajustes → Exportar copia de seguridad** periódicamente. No borres los datos del navegador si quieres conservar el progreso.
