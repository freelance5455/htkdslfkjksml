# CarScanner Log Viewer als Android-App

Dieser Ordner ist die fertige App. Einfach statisch hosten – kein Server-Code nötig.

## Weg 1: Installieren ohne Play Store (empfohlen)

1. Ordnerinhalt irgendwo hochladen mit **HTTPS**, z. B.:
   - Netlify Drop: `app.netlify.com/drop` (Ordner reinziehen, fertig)
   - GitHub Pages, Cloudflare Pages oder eigener Webspace
2. Adresse in **Chrome für Android** öffnen → Menü (⋮) → **„App installieren"**
   (falls das nicht erscheint: „Zum Startbildschirm hinzufügen").
3. App öffnen → **„Datei wählen"** → `.brc`-Datei aus dem Dateimanager wählen.

Hinweise:
- Die App startet auch **offline**. Die Karte braucht Netz für Kacheln;
  ohne Netz zeigt sie ersatzweise die reine Spur.
- Alle Daten bleiben auf dem Gerät, nichts wird hochgeladen.

## Weg 2: Echter Play-Store-Eintrag (weiterführend)

1. App wie oben hosten (öffentliche HTTPS-URL).
2. Auf `pwabuilder.com` die URL eingeben → Android-Paket bauen lassen.
3. Die `.aab`-Datei in der Play Console hochladen
   (Google-Entwicklerkonto, einmalig ca. 25 $).
4. Für den Vollbild-Modus ohne URL-Leiste zusätzlich die von PWABuilder
   erzeugte `assetlinks.json` unter `/.well-known/` hosten.

## Dateien öffnen

- **Android:** In der App über „Datei wählen" (Android-Dateiauswahl).
- **Desktop/ChromeOS:** `.brc` kann per Doppelklick geöffnet werden,
  wenn der Browser die App als Handler registriert hat
  (Manifest `file_handlers`, wird automatisch angeboten).
