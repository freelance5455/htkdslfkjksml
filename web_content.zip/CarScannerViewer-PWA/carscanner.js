// CarScannerRECORD parser + encoder.
// Format (from user spec):
//   Header:  dotnet-string "CARSCANNERRECORD" magic, uint32 LE version,
//            dotnet-string VIN, car name, OBD protocol, adapter ID
//   Session: int64 LE .NET DateTime ticks (100ns since 0001-01-01)
//   Records (sequential, each uint32 LE marker):
//     SENSOR_DEF 0x00D56190: uint32 id, string full, string short, uint32 unitType
//     DATA_POINT 0x01274350: float64 tSec, uint32 sensorId, float64 value
//     GPS_DATA   0x1F76FB5C: float64 tSec, float64 lat, float64 lon
//
// Strings are .NET BinaryWriter.Write(string): 7-bit-encoded-int byte count + UTF-8.
// (Matches "1 byte length" for the 16-char magic = single byte 0x10.)

export const MARKER_SENSOR_DEF = 0x00d56190;
export const MARKER_DATA_POINT = 0x01274350;
export const MARKER_GPS = 0x1f76fb5c;
export const MAGIC = "CARSCANNERRECORD";

const KNOWN_MARKERS = new Set([MARKER_SENSOR_DEF, MARKER_DATA_POINT, MARKER_GPS]);

// Days between 0001-01-01 and 1970-01-01 = 719162 -> ticks offset
const TICKS_AT_UNIX_EPOCH = 621355968000000000n;
const TICKS_PER_MS = 10000n;

export function ticksToDate(ticks) {
  const t = typeof ticks === "bigint" ? ticks : BigInt(Math.trunc(ticks));
  const ms = Number((t - TICKS_AT_UNIX_EPOCH) / TICKS_PER_MS);
  return new Date(ms);
}

export function dateToTicks(date) {
  const ms = BigInt(date.getTime());
  return ms * TICKS_PER_MS + TICKS_AT_UNIX_EPOCH;
}

export function formatTicks(ticks) {
  try {
    const d = ticksToDate(ticks);
    return isNaN(d.getTime()) ? "ungültig (" + String(ticks) + ")" : d.toLocaleString("de-DE");
  } catch {
    return String(ticks);
  }
}

class Reader {
  constructor(buf) {
    this.bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    this.view = new DataView(this.bytes.buffer, this.bytes.byteOffset, this.bytes.byteLength);
    this.pos = 0;
    this.decoder = new TextDecoder("utf-8", { fatal: true });
  }
  get remaining() { return this.bytes.length - this.pos; }
  eof() { return this.pos >= this.bytes.length; }
  u8() {
    if (this.remaining < 1) throw new Error("Unerwartetes Dateiende (u8) bei Offset " + this.pos);
    return this.bytes[this.pos++];
  }
  u32() {
    if (this.remaining < 4) throw new Error("Unerwartetes Dateiende (u32) bei Offset " + this.pos);
    const v = this.view.getUint32(this.pos, true);
    this.pos += 4;
    return v;
  }
  i64() {
    if (this.remaining < 8) throw new Error("Unerwartetes Dateiende (i64) bei Offset " + this.pos);
    const v = this.view.getBigInt64(this.pos, true);
    this.pos += 8;
    return v;
  }
  f64() {
    if (this.remaining < 8) throw new Error("Unerwartetes Dateiende (f64) bei Offset " + this.pos);
    const v = this.view.getFloat64(this.pos, true);
    this.pos += 8;
    return v;
  }
  peekU32() {
    if (this.remaining < 4) return null;
    return this.view.getUint32(this.pos, true);
  }
  read7BitInt() {
    let value = 0, shift = 0, count = 0;
    while (true) {
      if (count >= 5) throw new Error("Ungültige 7-bit-Längenangabe bei Offset " + this.pos);
      const b = this.u8();
      count++;
      value |= (b & 0x7f) << shift;
      if ((b & 0x80) === 0) return value >>> 0;
      shift += 7;
    }
  }
  readString(maxLen = 200000) {
    const start = this.pos;
    const len = this.read7BitInt();
    if (len > maxLen) throw new Error(`String-Länge ${len} zu groß bei Offset ${start} (max ${maxLen})`);
    if (len > this.remaining) throw new Error(`String-Länge ${len} über Dateiende hinaus bei Offset ${start}`);
    const slice = this.bytes.subarray(this.pos, this.pos + len);
    this.pos += len;
    try {
      return this.decoder.decode(slice);
    } catch {
      // fallback: latin1, damit wir trotzdem etwas anzeigen
      let s = "";
      for (const b of slice) s += String.fromCharCode(b);
      return s;
    }
  }
}

function isKnownMarker(v) { return KNOWN_MARKERS.has(v >>> 0); }

export function parseCarScanner(input) {
  const buf = input instanceof Uint8Array ? input : new Uint8Array(input);
  const r = new Reader(buf);
  const warnings = [];

  // ---- header ----
  const headerStart = r.pos;
  let magic;
  try {
    magic = r.readString(64);
  } catch (e) {
    throw new Error("Kein CARSCANNERRECORD-Header: " + e.message +
      " (Bytes: " + Array.from(buf.subarray(0, Math.min(24, buf.length))).map(b => b.toString(16).padStart(2, "0")).join(" ") + ")");
  }
  if (magic !== MAGIC) {
    throw new Error(`Ungültiges Magic: "${magic}" (erwartet "${MAGIC}")`);
  }
  const version = r.u32();
  const vin = r.readString(200);
  const carName = r.readString(500);
  const protocol = r.readString(500);
  const adapterId = r.readString(500);
  const sessionTicks = r.i64();
  const sessionDate = ticksToDate(sessionTicks);

  // ---- records ----
  const sensors = new Map(); // id -> {id, full, short, unit, t:[], v:[], min,max,sum}
  const gps = { t: [], lat: [], lon: [] };
  let dataPointCount = 0;
  let sensorDefCount = 0;
  let gpsCount = 0;
  let skippedBytes = 0;
  let maxT = 0;

  function getSensor(id) {
    let s = sensors.get(id);
    if (!s) {
      s = { id, full: "(unbekannt, ID " + id + ")", short: "ID " + id, unit: -1, t: [], v: [], min: Infinity, max: -Infinity, sum: 0, undef: true };
      sensors.set(id, s);
      warnings.push(`DATA_POINT für nicht definierten Sensor ${id} (Def fehlt)`);
    }
    return s;
  }

  while (!r.eof()) {
    if (r.remaining < 4) {
      if (r.remaining > 0) warnings.push(`${r.remaining} Rest-Byte(s) am Dateiende (Offset ${r.pos}) ignoriert`);
      break;
    }
    const markerPos = r.pos;
    const marker = r.u32();

    if (marker === MARKER_SENSOR_DEF) {
      const id = r.u32();
      const full = r.readString(10000);
      const short = r.readString(10000);
      const unit = r.u32();
      sensorDefCount++;
      const ex = sensors.get(id);
      if (ex && !ex.undef) {
        warnings.push(`Sensor ${id} doppelt definiert (Offset ${markerPos}) – alte Def wird überschrieben`);
        ex.full = full; ex.short = short; ex.unit = unit; ex.undef = false;
      } else if (ex && ex.undef) {
        ex.full = full; ex.short = short; ex.unit = unit; ex.undef = false;
        // Statistiken der bereits gelesenen Punkte bleiben erhalten
      } else {
        sensors.set(id, { id, full, short, unit, t: [], v: [], min: Infinity, max: -Infinity, sum: 0 });
      }
    } else if (marker === MARKER_DATA_POINT) {
      const t = r.f64();
      const id = r.u32();
      const value = r.f64();
      dataPointCount++;
      if (Number.isFinite(t) && t > maxT) maxT = t;
      const s = getSensor(id);
      s.t.push(t); s.v.push(value); s.sum += value;
      if (value < s.min) s.min = value;
      if (value > s.max) s.max = value;
    } else if (marker === MARKER_GPS) {
      const t = r.f64();
      const lat = r.f64();
      const lon = r.f64();
      gpsCount++;
      if (Number.isFinite(t) && t > maxT) maxT = t;
      gps.t.push(t); gps.lat.push(lat); gps.lon.push(lon);
    } else {
      // unbekannter Marker -> Resync: suche nächsten bekannten Marker
      const hex = "0x" + (marker >>> 0).toString(16).padStart(8, "0").toUpperCase();
      let found = -1;
      const scanEnd = Math.min(buf.length - 4, markerPos + 65536);
      for (let i = markerPos + 1; i <= scanEnd; i++) {
        const c = r.view.getUint32(i, true);
        if (isKnownMarker(c)) { found = i; break; }
      }
      if (found === -1) {
        warnings.push(`Unbekannter Marker ${hex} bei Offset ${markerPos} – kein weiterer bekannter Marker, Rest (${r.remaining} Bytes) ignoriert`);
        break;
      } else {
        warnings.push(`Unbekannter Marker ${hex} bei Offset ${markerPos} – ${found - markerPos} Byte(s) übersprungen bis Offset ${found}`);
        skippedBytes += found - markerPos;
        r.pos = found;
      }
    }
  }

  // Stats finalisieren
  const sensorList = [...sensors.values()].sort((a, b) => a.id - b.id).map(s => ({
    ...s,
    count: s.v.length,
    avg: s.v.length ? s.sum / s.v.length : NaN,
    min: s.v.length ? s.min : NaN,
    max: s.v.length ? s.max : NaN,
    firstT: s.t.length ? s.t[0] : NaN,
    lastT: s.t.length ? s.t[s.t.length - 1] : NaN,
    lastV: s.v.length ? s.v[s.v.length - 1] : NaN,
  }));

  return {
    header: { magic, version, vin, carName, protocol, adapterId, headerBytes: r.pos },
    sessionTicks, sessionDate,
    sensors: sensorList,
    gps, gpsCount,
    dataPointCount, sensorDefCount,
    durationSec: maxT,
    warnings, skippedBytes,
    bytesTotal: buf.length,
    headerStart,
  };
}

// ---------- Encoder (für Demo-Dateien / Tests) ----------

class Writer {
  constructor() { this.out = []; this.enc = new TextEncoder(); }
  u8(b) { this.out.push(b & 0xff); }
  u32(v) { v >>>= 0; this.out.push(v & 0xff, (v >>> 8) & 0xff, (v >>> 16) & 0xff, (v >>> 24) & 0xff); }
  raw(bytes) { for (const b of bytes) this.out.push(b); }
  f64(v) {
    const b = new Uint8Array(8);
    new DataView(b.buffer).setFloat64(0, v, true);
    this.raw(b);
  }
  i64(v) {
    let t = BigInt(v);
    const b = new Uint8Array(8);
    new DataView(b.buffer).setBigInt64(0, t, true);
    this.raw(b);
  }
  vInt(v) {
    v >>>= 0;
    while (v >= 0x80) { this.out.push((v & 0x7f) | 0x80); v >>>= 7; }
    this.out.push(v);
  }
  str(s) {
    const b = this.enc.encode(s);
    this.vInt(b.length);
    this.raw(b);
  }
  bytes() { return Uint8Array.from(this.out); }
}

function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Erzeugt eine valide Demo-Datei nach Spec. Gibt {bytes, info} zurück. */
export function createDemoFile(opts = {}) {
  const {
    vin = "WVWZZZ1KZDP012345",
    carName = "VW Golf 1.4 TSI (Demo)",
    protocol = "ISO 15765-4 CAN 11bit/500baud",
    adapterId = "OBDLink MX+ (Demo)",
    version = 2,
    sessionDate = new Date(),
    durationSec = 300,
    seed = 42,
  } = opts;
  const rnd = mulberry32(seed);
  const w = new Writer();
  w.str(MAGIC);
  w.u32(version);
  w.str(vin);
  w.str(carName);
  w.str(protocol);
  w.str(adapterId);
  w.i64(dateToTicks(sessionDate));

  const defs = [
    [1, "Engine RPM", "RPM", 1],
    [2, "Vehicle Speed", "km/h", 2],
    [3, "Coolant Temperature", "°C", 3],
    [4, "Throttle Position", "%", 4],
    [5, "Engine Load", "%", 4],
    [6, "Battery Voltage", "V", 5],
  ];
  for (const [id, full, short, unit] of defs) {
    w.u32(MARKER_SENSOR_DEF);
    w.u32(id);
    w.str(full);
    w.str(short);
    w.u32(unit);
  }

  const noise = (a) => (rnd() - 0.5) * 2 * a;
  // 2 Hz Fahrzeugdaten
  for (let t = 0; t <= durationSec; t += 0.5) {
    const drive = 0.5 + 0.5 * Math.sin(t / 45) * Math.sin(t / 13 + 1);
    const rpm = 820 + drive * 2400 + noise(60) + Math.max(0, Math.sin(t / 3)) * 120;
    const speed = Math.max(0, drive * 130 + noise(2));
    const coolant = Math.min(92, 18 + t * 0.35) + noise(0.3);
    const throttle = Math.min(100, Math.max(0, drive * 75 + noise(4)));
    const load = Math.min(100, Math.max(5, drive * 85 + noise(3)));
    const volt = 14.1 + Math.sin(t / 60) * 0.25 + noise(0.05);
    const vals = [[1, rpm], [2, speed], [3, coolant], [4, throttle], [5, load], [6, volt]];
    for (const [id, v] of vals) {
      w.u32(MARKER_DATA_POINT);
      w.f64(t);
      w.u32(id);
      w.f64(v);
    }
  }
  // GPS: 1 Hz Runde (Berlin, ~3 km Runde)
  const cLat = 52.5200, cLon = 13.4050;
  for (let t = 0; t <= durationSec; t += 1) {
    const a = (t / durationSec) * Math.PI * 2;
    const lat = cLat + Math.sin(a) * 0.012 + noise(0.0002);
    const lon = cLon + Math.cos(a) * 0.018 + noise(0.0002);
    w.u32(MARKER_GPS);
    w.f64(t);
    w.f64(lat);
    w.f64(lon);
  }
  return { bytes: w.bytes(), info: { vin, carName, protocol, adapterId, version, sessionDate, durationSec } };
}

// ---------- Export-Helfer ----------

export function parsedToCSV(parsed) {
  const lines = ["sensor_id;sensor_full;sensor_short;timestamp_s;value"];
  const esc = (s) => `"${String(s).replace(/"/g, '""')}"`;
  const fmtDec = (n) => (typeof n === "number" && isFinite(n) ? String(n).replace(".", ",") : "");
  for (const s of parsed.sensors) {
    for (let i = 0; i < s.t.length; i++) {
      const tStr = isFinite(s.t[i]) ? s.t[i].toFixed(3).replace(".", ",") : "";
      lines.push(`${s.id};${esc(s.full)};${esc(s.short)};${tStr};${fmtDec(s.v[i])}`);
    }
  }
  // UTF-8 BOM voranstellen, damit Excel / LibreOffice Umlaute (z. B. °C) und Kommazahlen direkt erkennt
  return "\uFEFF" + lines.join("\n");
}

export function parsedToGPX(parsed) {
  const t0 = parsed.sessionDate.getTime();
  const esc = (n) => (typeof n === "number" && isFinite(n) ? n.toFixed(6) : "0");
  let gpx = `<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="CarScannerRECORD-Viewer" xmlns="http://www.topografix.com/GPX/1/1">\n<trk><name>CarScanner Track</name><trkseg>\n`;
  for (let i = 0; i < parsed.gps.t.length; i++) {
    const when = new Date(t0 + parsed.gps.t[i] * 1000).toISOString();
    gpx += `<trkpt lat="${esc(parsed.gps.lat[i])}" lon="${esc(parsed.gps.lon[i])}"><time>${when}</time></trkpt>\n`;
  }
  return gpx + "</trkseg></trk>\n</gpx>\n";
}

export function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371, dLa = (lat2 - lat1) * Math.PI / 180, dLo = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLa / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLo / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

export function gpsDistanceKm(gps) {
  let d = 0;
  for (let i = 1; i < gps.lat.length; i++) d += haversineKm(gps.lat[i - 1], gps.lon[i - 1], gps.lat[i], gps.lon[i]);
  return d;
}