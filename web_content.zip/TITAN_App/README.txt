TITAN - Personal AI Assistant
Total Intelligent Task Enabled Network - Ayushman Technologies

FILES
index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png

PHONE PAR APP BANANE KE 2 TARIKE

1) Sabse aasan (PWA)
   - Poore folder ko kisi HTTPS hosting par daalo (Netlify Drop, GitHub Pages ya Cloudflare Pages - free).
   - Phone ke Chrome mein link kholo, menu (3 dots) -> "Install app" ya "Add to Home screen".
   - Home screen par TITAN ka icon aa jayega aur woh app ki tarah khulega.

2) APK file chahiye to
   - pwabuilder.com kholo, apna hosted link daalo, "Package for stores" -> Android -> APK download.

NOTE
 - Mic (voice) ke liye HTTPS zaroori hai aur mic permission allow karni hogi.
 - WhatsApp / YouTube / Instagram buttons phone par hi app kholte hain (app installed hona chahiye).
 - Element ki detail ke liye upar strip mein kisi bhi element par tap karo, ya bolo "hydrogen".
 - Sirf index.html double-click karke bhi chal jata hai, par install/app ke liye hosting chahiye.
