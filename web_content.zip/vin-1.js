﻿var URL = location.pathname;
arr = URL.split('/'); 
UpperDirName = arr[arr.length-2];
ThisFileName = arr[arr.length-1];

BookShortName = 'BHS';
arrLayout = new Array();
WorksDisplay  = 'Быт Исх Лев Чис Втор Нав Суд Руф 1Цар 2Цар 3Цар 4Цар 1Пар 2Пар Езд Нее Есф Иов Пс Прит Екк Песн Ис Иер Плач Иез Дан Ос Иоил Ам Авд Иона Мих Наум Авв Соф Агг Зах Мал Мф Мр Лк Ин Деян Рим 1Кор 2Кор Гал Еф Флп Кол 1Фес 2Фес 1Тим 2Тим Тит Флм Евр Иак 1Пет 2Пет 1Ин 2Ин 3Ин Иуд Отк';
WorksLink = 'Ge Ex Le Nu De Jos Jud Ru 1Sa 2Sa 1Ki 2Ki 1Ch 2Ch Ezr Ne Es Job Ps Pr Ec So Isa Jer La Eze Da Ho Joe Am Ob Jon Mic Na Hab Zep Hag Zec Mal Mt Mr Lu Joh Ac Ro 1Co 2Co Ga Eph Php Col 1Th 2Th 1Ti 2Ti Tit Phm Heb Jas 1Pe 2Pe 1Jo 2Jo 3Jo Jude Re';
WorksSections = '50 40 27 36 34 24 21 4 31 24 22 25 29 36 10 13 10 42 150 31 12 8 66 52 5 48 12 14 3 9 1 4 7 3 3 3 2 14 4 28 16 24 21 28 16 16 13 6 6 4 4 5 3 6 4 3 1 13 5 5 3 5 1 1 1 22';

var arrWorksDisplay = WorksDisplay.split(' ');
var arrWorksLink = WorksLink.split(' ');
var arrWorksSections = WorksSections.split(' ');


document.addEventListener('DOMContentLoaded',function(){var b=document.getElementById('go_up');if(!b)return;
function t(){b.classList.toggle('show',window.scrollY>700)}
window.__goUp=t;window.addEventListener('scroll',t,{passive:true});t();
b.addEventListener('click',function(e){e.preventDefault();var r=window.matchMedia('(prefers-reduced-motion:reduce)').matches;window.scrollTo({top:0,behavior:r?'auto':'smooth'});});});
window.addEventListener('load',function(){if(location.hash.length>1){var e=document.getElementById(decodeURIComponent(location.hash.slice(1)));if(e)setTimeout(function(){e.scrollIntoView();if(window.__goUp)window.__goUp();},60);}});
