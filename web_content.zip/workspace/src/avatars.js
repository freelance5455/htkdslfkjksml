const palettes = {
  Yusuf: { skin: "#e8c4a0", hair: "#2b1d14", cloth: "#3d5a80", accent: "#d4af6a" },
  Amara: { skin: "#f0d0b0", hair: "#5a2e16", cloth: "#7a3b4a", accent: "#e8b4c4" },
  Aram: { skin: "#efd0a8", hair: "#1c1410", cloth: "#3f6b4a", accent: "#c9e4c5" },
  Rim: { skin: "#e6c09a", hair: "#1a1210", cloth: "#5c3d6e", accent: "#d4af6a" },
  Servan: { skin: "#d9b089", hair: "#24180f", cloth: "#2c3a4a", accent: "#8aa0b8" }
}

export function avatarSvg(name, size = 120) {
  const p = palettes[name] || palettes.Yusuf
  const id = name.toLowerCase()
  if (name === "Yusuf") {
    return `<svg viewBox="0 0 120 120" width="${size}" height="${size}" aria-hidden="true">
      <circle cx="60" cy="60" r="58" fill="#10161f"/>
      <circle cx="60" cy="78" r="34" fill="${p.cloth}"/>
      <ellipse cx="60" cy="58" rx="26" ry="30" fill="${p.skin}"/>
      <path d="M34 52 Q60 18 86 52 L82 46 Q60 22 38 46 Z" fill="${p.hair}"/>
      <rect x="38" y="36" width="44" height="8" rx="2" fill="#1a1a1a"/>
      <rect x="36" y="42" width="48" height="4" fill="#c9a45c"/>
      <circle cx="50" cy="58" r="3" fill="#1a1a1a"/>
      <circle cx="70" cy="58" r="3" fill="#1a1a1a"/>
      <path d="M52 70 Q60 76 68 70" stroke="#8a5a3a" fill="none" stroke-width="2"/>
      <path d="M48 48 L54 50" stroke="#1a1a1a" stroke-width="2"/>
      <path d="M72 48 L66 50" stroke="#1a1a1a" stroke-width="2"/>
    </svg>`
  }
  if (name === "Amara") {
    return `<svg viewBox="0 0 120 120" width="${size}" height="${size}" aria-hidden="true">
      <circle cx="60" cy="60" r="58" fill="#10161f"/>
      <circle cx="60" cy="82" r="32" fill="${p.cloth}"/>
      <ellipse cx="60" cy="58" rx="24" ry="28" fill="${p.skin}"/>
      <path d="M28 58 Q30 20 60 22 Q90 20 92 58 Q90 78 60 74 Q30 78 28 58" fill="${p.hair}"/>
      <circle cx="28" cy="62" r="8" fill="${p.hair}"/>
      <circle cx="92" cy="62" r="8" fill="${p.hair}"/>
      <circle cx="50" cy="58" r="2.6" fill="#2a1810"/>
      <circle cx="70" cy="58" r="2.6" fill="#2a1810"/>
      <path d="M54 70 Q60 75 66 70" stroke="#b07060" fill="none" stroke-width="2"/>
      <circle cx="60" cy="48" r="3" fill="${p.accent}"/>
    </svg>`
  }
  if (name === "Aram") {
    return `<svg viewBox="0 0 120 120" width="${size}" height="${size}" aria-hidden="true">
      <circle cx="60" cy="60" r="58" fill="#10161f"/>
      <circle cx="60" cy="84" r="30" fill="${p.cloth}"/>
      <ellipse cx="60" cy="60" rx="22" ry="26" fill="${p.skin}"/>
      <path d="M40 48 Q60 28 80 48 L78 42 Q60 26 42 42 Z" fill="${p.hair}"/>
      <circle cx="50" cy="60" r="2.4" fill="#1a1a1a"/>
      <circle cx="70" cy="60" r="2.4" fill="#1a1a1a"/>
      <path d="M54 72 Q60 78 66 72" stroke="#8a5a3a" fill="none" stroke-width="2"/>
      <rect x="44" y="86" width="32" height="8" rx="4" fill="${p.accent}"/>
    </svg>`
  }
  if (name === "Rim") {
    return `<svg viewBox="0 0 120 120" width="${size}" height="${size}" aria-hidden="true">
      <circle cx="60" cy="60" r="58" fill="#10161f"/>
      <circle cx="60" cy="86" r="34" fill="${p.cloth}"/>
      <ellipse cx="60" cy="56" rx="24" ry="28" fill="${p.skin}"/>
      <path d="M32 50 Q36 16 60 18 Q84 16 88 50 L86 78 Q60 92 34 78 Z" fill="${p.hair}"/>
      <path d="M34 58 Q60 70 86 58" fill="none" stroke="${p.hair}" stroke-width="10"/>
      <circle cx="50" cy="56" r="2.8" fill="#1a1a1a"/>
      <circle cx="70" cy="56" r="2.8" fill="#1a1a1a"/>
      <path d="M54 68 Q60 72 66 68" stroke="#8a5a3a" fill="none" stroke-width="2"/>
      <circle cx="60" cy="42" r="3.2" fill="${p.accent}"/>
    </svg>`
  }
  return `<svg viewBox="0 0 120 120" width="${size}" height="${size}" aria-hidden="true">
    <circle cx="60" cy="60" r="58" fill="#10161f"/>
    <circle cx="60" cy="86" r="34" fill="${p.cloth}"/>
    <ellipse cx="60" cy="54" rx="25" ry="28" fill="${p.skin}"/>
    <path d="M34 46 Q60 12 86 46 L80 40 Q60 16 40 40 Z" fill="${p.hair}"/>
    <rect x="42" y="50" width="36" height="6" rx="1" fill="#2a2a2a" opacity="0.35"/>
    <circle cx="50" cy="54" r="2.8" fill="#1a1a1a"/>
    <circle cx="70" cy="54" r="2.8" fill="#1a1a1a"/>
    <path d="M52 68 Q60 72 68 68" stroke="#8a5a3a" fill="none" stroke-width="2"/>
    <rect x="48" y="92" width="24" height="6" rx="2" fill="${p.accent}"/>
  </svg>`
}
