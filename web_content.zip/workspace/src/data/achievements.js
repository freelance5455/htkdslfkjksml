export const ACHIEVEMENTS = [
  { id: "ilk", ad: { tr: "İlk Dosya", ar: "الملف الأول" }, aciklama: { tr: "Bir bölümü bitir.", ar: "أنهِ فصلًا واحدًا." }, kosul: s => s.biten.length >= 1 },
  { id: "keskin", ad: { tr: "Keskin Göz", ar: "عين حادة" }, aciklama: { tr: "Bir bölümde tüm kanıtları bul.", ar: "اجمع كل الأدلة في فصل." }, kosul: s => s.oduller.includes("keskin") },
  { id: "celiski", ad: { tr: "Çelişki Avcısı", ar: "صائد التناقض" }, aciklama: { tr: "Doğru çelişkiyi işaretle.", ar: "علّم تناقضًا صحيحًا." }, kosul: s => s.oduller.includes("celiski") },
  { id: "yildiz3", ad: { tr: "Üç Yıldız", ar: "ثلاث نجوم" }, aciklama: { tr: "Bir bölümde üç yıldız al.", ar: "احصل على ثلاث نجوم في فصل." }, kosul: s => Object.values(s.yildiz).some(v => v >= 3) },
  { id: "on", ad: { tr: "On Dosya", ar: "عشرة ملفات" }, aciklama: { tr: "On bölümü bitir.", ar: "أنهِ عشرة فصول." }, kosul: s => s.biten.length >= 10 },
  { id: "sezon", ad: { tr: "Eski Oda", ar: "الغرفة القديمة" }, aciklama: { tr: "İlk sezonu bitir.", ar: "أنهِ الموسم الأول." }, kosul: s => s.biten.length >= 10 },
  { id: "ozel", ad: { tr: "Özel Dosya", ar: "ملف خاص" }, aciklama: { tr: "Onuncu özel soruşturmayı bitir.", ar: "أنهِ التحقيق الخاص العاشر." }, kosul: s => s.biten.includes(10) },
  { id: "ailesi", ad: { tr: "Aile Dosyası", ar: "ملف العائلة" }, aciklama: { tr: "Altmış bölümü de bitir.", ar: "أنهِ الستين فصلًا." }, kosul: s => s.biten.length >= 60 },
  { id: "adil", ad: { tr: "Adil Hüküm", ar: "حكم عادل" }, aciklama: { tr: "Doğru hükmü ver.", ar: "أصدر الحكم الصحيح." }, kosul: s => s.oduller.includes("adil") },
  { id: "arkadas", ad: { tr: "Ortak Sorgu", ar: "تحقيق مشترك" }, aciklama: { tr: "Arkadaşlarla bir oyun başlat.", ar: "ابدأ لعبة مع الأصدقاء." }, kosul: s => s.oduller.includes("arkadas") },
  { id: "ipucu0", ad: { tr: "İpucusuz", ar: "بلا تلميح" }, aciklama: { tr: "İpucu kullanmadan bir bölüm çöz.", ar: "حل فصلًا بلا تلميح." }, kosul: s => s.oduller.includes("ipucu0") },
  { id: "uzman", ad: { tr: "Uzman", ar: "خبير" }, aciklama: { tr: "Uzman zorluğunu aç.", ar: "افتح صعوبة الخبير." }, kosul: s => s.biten.length >= 30 }
]
