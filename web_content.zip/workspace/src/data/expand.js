export function kisi(rol, ifade, tutarli, ipucu, celiski) {
  const k = { rol, ifade, tutarli, ipucu }
  if (celiski) k.celiski = celiski
  return k
}

export function expand(raw) {
  return raw.map((r, i) => {
    const kanitlar = r.kanitlar.map(([id, ad, metin, onemli]) => ({ id, ad, metin, onemli: !!onemli }))
    const kisiler = {}
    for (const ad of Object.keys(r.kisiler)) {
      const [rol, ifade, tutarli, ipucu, celiski] = r.kisiler[ad]
      kisiler[ad] = kisi(rol, ifade, tutarli, ipucu, celiski)
    }
    return {
      id: i + 1,
      baslik: r.baslik,
      ozet: r.ozet,
      yer: r.yer,
      saat: r.saat,
      tur: r.tur || "mantik",
      sezon: r.sezon,
      kilit: i > 0,
      ozel: (i + 1) % 10 === 0,
      gercek: {
        suc: r.suc,
        fail: r.dogru,
        neden: r.neden,
        kanitlar: kanitlar.filter(k => k.onemli).map(k => k.id)
      },
      kisiler,
      kanitlar,
      sorular: (r.sorular || []).map(([kim, soru, a, b, c, dogru, yanit]) => ({
        kim, soru, a, b, c, dogru, yanit
      })),
      celiskiler: (r.celiskiler || []).map(([a, b, dogru], n) => ({
        id: "c" + (n + 1), a, b, dogru
      })),
      kararSoru: r.soru,
      kararSecenek: r.secenekler,
      ipucuSirasi: (r.ipuclari || ["İfadeleri saatlerle karşılaştır.", "Kanıtı iddiaya bağla.", "Çelişeni ele."]).slice(0, 3)
    }
  })
}
