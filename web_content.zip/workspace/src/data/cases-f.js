export const CASES_F = [
  {
    sezon: "6. sezon — Aile masası",
    baslik: "Yanlış sandalye",
    ozet: "Akşam yemeğinde Yusuf'un yeri değişmiş.",
    yer: "Yemek masası",
    saat: "Pazartesi, 19:00",
    tur: "sira",
    kisiler: {
      Yusuf: ["Tanık", "Ben pencereyi severim. Yerim perdeli kenar.", true, "Alışkanlık."],
      Amara: ["Tanık", "Yerleri oyun için döndürdüm, kart çekerek.", true, "Kartlar masada."],
      Aram: ["Tanık", "Ben Yusuf'un sandalyesine oturdum, yüksek.", true, "Dürüst."],
      Rim: ["Tanık", "Kart kâğıtları masada: Yusuf-Aram yer değiş.", true, "Gördü."]
    },
    kanitlar: [
      ["kartlar", "Oyun kartları", "İsimler yazılı, Yusuf ve Aram çapraz.", true],
      ["minder", "Minder basısı", "Aram küçük hip, Yusuf yerinde küçük bası.", true],
      ["perde", "Perde kenarı", "Yusuf'un çantası hâlâ orada, oturmamış."]
    ],
    sorular: [
      ["Amara", "Neden döndürdün?", "Oyun. Kimse kaçırmasın diye kart.", "Yusuf'u cezalandırmak.", "Rim dedi.", "a", "Oyun."]
    ],
    celiskiler: [
      ["Yusuf kendi gitti", "Çanta perdedeki yerde, minder küçük", true],
      ["Rim değiştirdi", "Kartlar Amara yazısı", true]
    ],
    soru: "Yerler neden değişti?",
    secenekler: ["Yusuf kendi değiştirdi", "Amara kart oyunu ile döndürdü", "Rim ceza verdi", "Servan şaka"],
    dogru: "Amara kart oyunu ile döndürdü",
    suc: "Oyun. Ceza yok. Kartlar açık kanıt.",
    neden: "İsimli kartlar Amara yazısı. Minder ve çanta yerleri doğrular. Aram yüksek sandalyeyi kabul etti.",
    ipuclari: ["Kartlara bak.", "Çanta nerede?", "Minder boyu."]
  },
  {
    sezon: "6. sezon — Aile masası",
    baslik: "Soğuyan çorba",
    ozet: "Çorba kâsesi Yusuf'ta soğuk, diğerleri sıcak.",
    yer: "Masa",
    saat: "Pazartesi, 19:20",
    tur: "zaman",
    kisiler: {
      Yusuf: ["Tanık", "Ben 19:00'de gelmedim, ödev. 19:18 oturdum.", true, "Defter."],
      Amara: ["Tanık", "Onun kâsesini erken doldurdum, beklesin diye.", true, "İyi niyet."],
      Aram: ["Tanık", "Benimki dumanlı, Yusuf'unki değil.", true, "Gözlem."],
      Servan: ["Tanık", "Fırın saati doğru, 19:20.", true, "Üçüncü dosya kuralı."]
    },
    kanitlar: [
      ["sicaklik", "Kâse ısısı", "Yusuf 32 derece, diğerleri 62 derece.", true],
      ["doldurma", "Kepçe izi", "Yusuf kâsesi 18 dakika önce dolmuş, kenar kuru halka.", true],
      ["def5", "Ödev bitiş", "19:17."]
    ],
    sorular: [
      ["Amara", "Neden erken doldurdun?", "Hazır olsun sandım. Soğuracağını düşünmedim.", "Cezalandırmak.", "Servan dedi.", "a", "Fizik."]
    ],
    celiskiler: [
      ["Yusuf geç geldiği için suçlu", "Amara erken doldurdu, ısı farkı", true],
      ["Fırın saati yanlış", "Fırın doğru, üçüncü dosya", true]
    ],
    soru: "Yusuf'un çorbası neden soğuk?",
    secenekler: ["Yusuf geç kaldı diye ceza", "Amara kâseyi 18 dakika erken doldurdu", "Fırın saati yanlış", "Aram üfledi"],
    dogru: "Amara kâseyi 18 dakika erken doldurdu",
    suc: "İyi niyet, kötü fizik. Erken doldurma soğutur.",
    neden: "Isı ve kuru halka süre verir. Ödev 19:17 bitti. Diğer kâseler dumanlı.",
    ipuclari: ["Isı ölç.", "Kenar halkası.", "Kim kepçeyi kullandı?"]
  },
  {
    sezon: "6. sezon — Aile masası",
    baslik: "Eksik peçete",
    ozet: "Beş kişilik masada dört peçete.",
    yer: "Masa",
    saat: "Pazartesi, 19:30",
    tur: "kayip",
    kisiler: {
      Yusuf: ["Tanık", "Peçeteleri saydım, beş. Biri düştü değil, biri cebe girdi.", true, "Sayım."],
      Amara: ["Tanık", "Resim silmek için birini aldım, cebimde boya.", true, "İtiraf."],
      Aram: ["Tanık", "Ben yere düşürmedim, yer temiz.", true, "Yer."],
      Rim: ["Tanık", "Beş katladım, sepete koydum.", true, "Kat."]
    },
    kanitlar: [
      ["cep2", "Amara cebi", "Boyalı peçete.", true],
      ["yer2", "Yer", "Peçete yok."],
      ["sepet", "Sepet", "Dört kalmış, beşinci alınmış."]
    ],
    sorular: [
      ["Amara", "Neden peçete?", "Yanlış çizgi, silmek. Yemekten önce unuttum.", "Sakladım.", "Yere attım.", "a", "Resim."]
    ],
    celiskiler: [
      ["Yere düştü", "Yer temiz, cepte boyalı peçete", true],
      ["Rim dört katladı", "Rim: beş katladım", true]
    ],
    soru: "Beşinci peçete nerede?",
    secenekler: ["Yerde", "Amara'nın boyalı cebinde", "Aram yedi", "Servan çöpe"],
    dogru: "Amara'nın boyalı cebinde",
    suc: "Peçete resim silme. Kayıp değil.",
    neden: "Cepte boya. Yer temiz. Rim beş katlamış. Yusuf cebe girdi dedi.",
    ipuclari: ["Cep.", "Yer.", "Boya."]
  },
  {
    sezon: "6. sezon — Aile masası",
    baslik: "Tuzlu tatlı",
    ozet: "Sütlaç tuzlu çıkmış. Kavanoz dosyası yeniden mi?",
    yer: "Mutfak",
    saat: "Pazartesi, 20:10",
    tur: "eslestirme",
    kisiler: {
      Yusuf: ["Tanık", "Kavanozlar düzeltildi, sol tuz etiket iç tuz.", true, "İkinci sezon düzeltme."],
      Amara: ["Tanık", "Ben şeker sandım, kaşıkla tattım, tuzdu, yine de döktüm çünkü acele.", false, "Tattıysa durmalıydı.", "Acele."],
      Aram: ["Tanık", "Amara kaşığı yaladı, yüzü ekşidi, yine döktü.", true, "Gördü."],
      Rim: ["Tanık", "Tarifte şeker sağ kavanoz.", true, "Tarif."]
    },
    kanitlar: [
      ["tat", "Sütlaç örneği", "Tuz baskın, şeker az.", true],
      ["kasik2", "Kaşık", "Amara dudak izi, tuz kristalleri.", true],
      ["kavanoz", "Kavanozlar", "Bu kez doğru etiketli. Hata yanlış kavanoz seçimi."]
    ],
    sorular: [
      ["Amara", "Tattın, neden döktün?", "Acele, misafir gibi oynadık. Hata.", "Kavanoz yine ters.", "Yusuf döktü.", "a", "Acele."]
    ],
    celiskiler: [
      ["Kavanozlar yine ters", "Etiket ve içerik bu kez doğru", true],
      ["Yusuf döktü", "Kaşık Amara izi", true]
    ],
    soru: "Sütlaç neden tuzlu?",
    secenekler: ["Kavanozlar yine ters", "Amara tattığı halde tuz kavanozunu döktü", "Rim tarif yanlış", "Aram tuz ekledi"],
    dogru: "Amara tattığı halde tuz kavanozunu döktü",
    suc: "Etiket doğru. Seçim yanlış. Acele, ikinci sezon dersi unutulmuş.",
    neden: "Kavanozlar düzeltilmişti. Kaşık tuzlu ve Amara izli. Aram yüz ekşimesini gördü.",
    ipuclari: ["Önce kavanozları kontrol et.", "Tattıysa neden durmadı?", "Kim yüzünü ekşitti?"]
  },
  {
    sezon: "6. sezon — Aile masası",
    baslik: "Telefon şarjı",
    ozet: "Rim'in telefonu mutfakta yüzde üç. Sabah yüzde seksen idi.",
    yer: "Mutfak tezgâhı",
    saat: "Salı, 07:50",
    tur: "zaman",
    kisiler: {
      Yusuf: ["Tanık", "Ekran açık unutulursa sekiz saatte biter. Fener uygulaması 23:00-07:40 açık.", true, "Kayıt."],
      Amara: ["Tanık", "Karanlıkta korkunca feneri açtım, kapatmadım.", true, "Korku."],
      Aram: ["Tanık", "Işık mutfakta gece yandı, uzun.", true, "Işık."],
      Rim: ["Mağdur", "Telefonu tezgâha bıraktım, şifresiz acil için.", true, "Fırsat."],
      Servan: ["Tanık", "Ben arama yapmadım, kayıtta yok.", true, "Liste."]
    },
    kanitlar: [
      ["pil2", "Pil kaydı", "Fener 23:04-07:41. Düşüş eğrisi uyumlu.", true],
      ["arama", "Arama listesi", "Boş.", true],
      ["isik6", "Mutfak gece ışığı", "Telefon feneri, tavan lambası kapalı."]
    ],
    sorular: [
      ["Amara", "Neden kapatmadın?", "Uyudum, fener açık kaldı.", "Oynadım saatlerce.", "Servan aradı.", "a", "Unutma."]
    ],
    celiskiler: [
      ["Servan aradı", "Arama listesi boş, fener kaydı", true],
      ["Ekran kapalı unutuldu", "Fener sekiz saat açık", true]
    ],
    soru: "Pil neden bitti?",
    secenekler: ["Servan gece aradı", "Amara feneri açık unuttu", "Yusuf oyun indirdi", "Şarj kablosu bozuk"],
    dogru: "Amara feneri açık unuttu",
    suc: "Fener sekiz saat. Arama yok. Kablo testte sağlam.",
    neden: "Pil eğrisi fenerle birebir. Tavan lambası kapalı. Rim şifresiz bırakmış, niyet korku.",
    ipuclari: ["Hangi uygulama açık kalır?", "Arama var mı?", "Kim karanlıktan korkar?"]
  },
  {
    sezon: "6. sezon — Aile masası",
    baslik: "Çift mesaj",
    ozet: "Aile grubunda okula gitme mesajı. Gönderen Rim görünüyor.",
    yer: "Telefonlar",
    saat: "Salı, 08:05",
    tur: "sahte-mesaj",
    kisiler: {
      Yusuf: ["Mağdur", "Mesaj 07:58. Rim o sırada duşta, buhar 07:50-08:08.", true, "Alibi."],
      Amara: ["Şüpheli", "Telefon açık tezgâhta. Okul istemedim. Yazdım.", true, "İtiraf."],
      Aram: ["Tanık", "Amara telefona baktı, kilit yoktu.", true, "Gördü."],
      Rim: ["Tanık", "Yazmadım. Duşta telefon yok.", true, "Duş."],
      Servan: ["Tanık", "İş yolundayım, 07:40 çıktım.", true, "Yol."]
    },
    kanitlar: [
      ["mesaj", "Mesaj kaydı", "Cihaz Rim, konum ev, yazım hatası gitmee Amara defterinde de var.", true],
      ["dus", "Banyo buharı", "07:50-08:08, Rim içeride.", true],
      ["kilit", "Ekran kilidi", "Kapalı, önceki dosya: acil şifresiz."]
    ],
    sorular: [
      ["Amara", "Sen mi yazdın?", "Evet. Rim sandılar diye. Yanlış.", "Hayır.", "Yusuf yazdı.", "a", "İtiraf."]
    ],
    celiskiler: [
      ["Rim yazdı", "Rim duşta, yazım hatası Amara", true],
      ["Servan yazdı", "Servan 07:40 çıktı", true]
    ],
    soru: "Mesajı kim gönderdi?",
    secenekler: ["Rim", "Amara, açık telefonda", "Yusuf", "Servan"],
    dogru: "Amara, açık telefonda",
    suc: "Şifresiz telefon. Amara okul kaçırmak için Rim adına yazdı.",
    neden: "Duş alibisi. Çift e yazımı Amara defterinde de var. Servan yolda. Önceki pil dosyası kilidi açıklıyor.",
    ipuclari: ["Gönderen ad her zaman kişi değildir.", "Duş saati.", "Yazım hatası."]
  },
  {
    sezon: "6. sezon — Aile masası",
    baslik: "Okul çantası",
    ozet: "Yusuf'un çantası hafif. Kitaplar masada.",
    yer: "Hol",
    saat: "Salı, 08:20",
    tur: "eksik-bilgi",
    kisiler: {
      Yusuf: ["Mağdur", "Çantayı 08:10'da kapadım, ağırdı. Şimdi hafif.", true, "Tartı."],
      Amara: ["Şüpheli", "Kitapları indirdim, mesaj işe yarasın diye okula gitmesin.", true, "Motif."],
      Aram: ["Tanık", "Amara fermuarı açtı, kitapları çekti.", true, "Gördü."],
      Rim: ["Tanık", "Duştan 08:12 çıktım, çanta halde duruyordu.", true, "Zaman."]
    },
    kanitlar: [
      ["kilo", "Çanta tartı", "08:10 fotoğrafta sarkma, 08:18 düz, boş.", true],
      ["kitap", "Masa kitapları", "Yusuf adı, Amara parmak boya izi.", true],
      ["fermuar", "Fermuar", "Yeşil boya dişi."]
    ],
    sorular: [
      ["Amara", "Kitapları neden aldın?", "Mesaj yetmez sandım. İki yanlış.", "Yusuf istedi.", "Rim indirdi.", "a", "Zincir."]
    ],
    celiskiler: [
      ["Yusuf unuttu", "08:10 ağır, 08:18 boş, boya fermuar", true],
      ["Rim indirdi", "Rim 08:12 duş çıkışı, Aram Amara'yı gördü", true]
    ],
    soru: "Çanta neden hafif?",
    secenekler: ["Yusuf unuttu", "Amara kitapları indirdi", "Aram oyuncak koydu", "Rim kontrol etti"],
    dogru: "Amara kitapları indirdi",
    suc: "Mesaja ek sabotaj. İki dosya aynı motif: okula gitmesin.",
    neden: "Tartı değişimi. Boya fermuarda. Aram gördü. 08:18 boşalma Amara penceresi.",
    ipuclari: ["Ağırlık değişimi.", "Boya.", "Önceki mesaj motifi."]
  },
  {
    sezon: "6. sezon — Aile masası",
    baslik: "Geç kalan otobüs",
    ozet: "Yusuf otobüsü kaçırdı. Saat mi, durak mı?",
    yer: "Durak ve hol",
    saat: "Salı, 08:45",
    tur: "zaman",
    kisiler: {
      Yusuf: ["Tanık", "08:32'de çıktım, otobüs 08:30'mış. Çanta yüzünden geç kaldım.", true, "Zincir."],
      Amara: ["Tanık", "Otobüs saati değişmedi, ben değiştirdim sandım, durak panosu aynı.", true, "Dürüstleşme."],
      Aram: ["Tanık", "Kapı 08:32 kapandı arkamızdan.", true, "Kapı."],
      Servan: ["Tanık", "Hat 08:30 geçer, 08:45 değil. Uygulama.", true, "Hat."]
    },
    kanitlar: [
      ["hat", "Hat uygulaması", "08:30, gecikme yok.", true],
      ["kapi", "Kapı kamerası", "08:32 çıkış, çanta hafif.", true],
      ["pano", "Durak panosu", "08:30 yazıyor, değişmemiş."]
    ],
    sorular: [
      ["Yusuf", "Neden geç?", "Çanta ve mesaj zinciri. Otobüs suçsuz.", "Otobüs erken.", "Saat geri.", "a", "Sebep evde."]
    ],
    celiskiler: [
      ["Otobüs saati değişti", "Pano ve uygulama 08:30", true],
      ["Yusuf 08:30 çıktı", "Kamera 08:32", true]
    ],
    soru: "Otobüs neden kaçtı?",
    secenekler: ["Hat saati değişti", "Yusuf çanta yüzünden 08:32 çıktı", "Şoför erken geldi", "Durak yanlıştı"],
    dogru: "Yusuf çanta yüzünden 08:32 çıktı",
    suc: "Otobüs dakik. Gecikme evdeki zincirden: mesaj, kitap, çıkış.",
    neden: "Uygulama ve pano aynı. Kamera 08:32. Amara panoyu değiştirmemiş. Sebep önceki iki dosya.",
    ipuclari: ["Resmi saat kaynağı.", "Kapı kamerası.", "Zincir dosyaları."]
  },
  {
    sezon: "6. sezon — Aile masası",
    baslik: "Özür kâğıdı",
    ozet: "Masada özür notu var. İmza Amara, ama yazı çok düzgün.",
    yer: "Masa",
    saat: "Salı, 16:00",
    tur: "sahte-mesaj",
    kisiler: {
      Yusuf: ["Tanık", "Yazı Rim. Amara imzası çocuk. İkisi bir arada.", true, "İki el."],
      Amara: ["Tanık", "Sözleri ben söyledim, Rim yazdı, ben imzaladım. Gerçek özür.", true, "Ortak."],
      Aram: ["Tanık", "Amara ağladı, Rim kâğıt verdi.", true, "Ağlama."],
      Rim: ["Tanık", "Amara istedi, ben kaleme aldım. İmza onun.", true, "Kalem."]
    },
    kanitlar: [
      ["yazi2", "Gövde yazısı", "Rim basılı harf.", true],
      ["imza", "İmza", "Amara, mor keçe, eğri.", true],
      ["murekkep5", "İki mürekkep", "Siyah gövde, mor imza. İki el."]
    ],
    sorular: [
      ["Amara", "Bu sahte mi?", "Hayır. Söz benim, yazı annem, imza ben.", "Yusuf yazdı.", "İnkâr.", "a", "Gerçek."]
    ],
    celiskiler: [
      ["Tümü sahte", "İki mürekkep, tanık ağlama, içerik zinciri kabul", true],
      ["Yusuf yazdı", "Basılı harf Rim, imza Amara", true]
    ],
    soru: "Özür notu sahte mi?",
    secenekler: ["Sahte, Yusuf yazdı", "Sahte, Rim uydurdu", "Gerçek, Rim yazdı Amara imzaladı", "Amara tek başına yazdı"],
    dogru: "Gerçek, Rim yazdı Amara imzaladı",
    suc: "Ortak not. Sahte değil. İçerik önceki yanlışları kabul ediyor.",
    neden: "İki mürekkep iki el. Amara ve Rim aynı hikâyeyi anlatıyor. Aram ağlamayı gördü. Yazı düzgünlüğü tuzak, çünkü Rim yazdı.",
    ipuclari: ["İki kalem.", "İmza kimin kıvrımı?", "Düzgün yazı her zaman sahte değildir."]
  },
  {
    sezon: "6. sezon — Aile masası",
    baslik: "Açık kapı",
    ozet: "Eski oda açık, içeride beş yastık ve bir lamba. Kim düzenledi?",
    yer: "Eski oda",
    saat: "Salı, 19:30",
    tur: "sira",
    kisiler: {
      Yusuf: ["Yardımcı", "Yastıklar boy sırası: Servan, Rim, ben, Amara, Aram. Toplantı.", true, "Sıra."],
      Amara: ["Tanık", "Odayı paylaşmak için çağırdım. Sır bitti, oyun başlasın.", true, "Veda."],
      Aram: ["Tanık", "Ben en küçük yastık, köşe.", true, "Yer."],
      Rim: ["Tanık", "Kabul ettim. Anneanne odası aile odası olsun.", true, "Karar."],
      Servan: ["Tanık", "Sürgü dışarıda açık, kilit yok. Ben taşıdım yastıkları, Amara sırayı söyledi.", true, "Sürgü."]
    },
    kanitlar: [
      ["yastik", "Beş yastık", "Boy sırası, isim etiketleri Yusuf el yazısı.", true],
      ["lamba", "Lamba", "Dış düğme açık, içeride biri yok zorunlu değil.", true],
      ["davet", "Davet kâğıdı", "Amara: 19:30 eski oda, herkes. Mor keçe, dürüst."]
    ],
    sorular: [
      ["Amara", "Bu yeni sır mı?", "Hayır. Paylaşım. İlk anahtarı aldığım oda artık herkesin.", "Sakladım.", "Yusuf zorladı.", "a", "Kapanış."]
    ],
    celiskiler: [
      ["Gizli toplantı şüpheli", "Davet açık, sürgü açık, beş yastık", true],
      ["Servan kilitlemiş", "Sürgü dışarıda açık", true]
    ],
    soru: "Oda neden düzenlenmiş?",
    secenekler: ["Yeni gizli plan", "Amara aileyi paylaşmaya çağırdı", "Servan odayı kilitledi", "Yastıklar rastgele"],
    dogru: "Amara aileyi paylaşmaya çağırdı",
    suc: "Son dosya bir tuzak değil. Eski oda açıldı. Zincir kapandı.",
    neden: "Davet yazılı. Yastıklar boy sırası ve isimli. Sürgü açık. Amara ilk dosyada anahtarı saklamıştı; son dosyada odayı paylaşıyor. Mantık çizgisi baştan sona bağlı.",
    ipuclari: ["Davet kâğıdı.", "Sürgü açık mı?", "İlk dosya ile son dosyayı bağla."]
  }
]
