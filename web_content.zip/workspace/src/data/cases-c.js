export const CASES_C = [
  {
    sezon: "3. sezon — Koridor ve odalar",
    baslik: "Kayıp kalem",
    ozet: "Yusuf'un mavi kalemi yok. Defter açık kalmış.",
    yer: "Yusuf'un masası",
    saat: "Perşembe, 16:10",
    tur: "kayip",
    kisiler: {
      Yusuf: ["Mağdur", "Kalemi 15:50'de masaya koydum, su içmeye gittim.", true, "Bardak 15:55 nemli."],
      Amara: ["Şüpheli", "Kalemim mor, mavi değil.", true, "Mor kutu yerinde."],
      Aram: ["Tanık", "Mavi kalem Rim'in kulağındaydı, mutfakta.", true, "Rim arşiv notu alırken kulağına koyar."],
      Rim: ["Tanık", "Mavi kalem? Not alırken almış olabilirim, bakayım.", true, "Kulakta mavi kalem."]
    },
    kanitlar: [
      ["kulak", "Rim'in kulağı", "Mavi tükenmez, Yusuf'un ucu ısırık izli.", true],
      ["isirik", "Uç ısırığı", "Yusuf stresten ucu ısırır. Eşsiz diş izi.", true],
      ["bardak", "Su bardağı", "15:55, Yusuf'un kısa yokluğu."]
    ],
    sorular: [
      ["Rim", "Neden aldın?", "Alışkanlık, arşiv. Fark etmedim.", "Sakladım.", "Amara verdi.", "a", "İhmal, hırsızlık değil."]
    ],
    celiskiler: [
      ["Amara: mavi değil", "Kalem: Rim kulağında, ısırık Yusuf", false],
      ["Yusuf: masaya koydum", "Aram: Rim kulağında", true]
    ],
    soru: "Kalem kimin yanında, neden?",
    secenekler: ["Amara sakladı", "Aram kırdı", "Rim alışkanlıkla aldı", "Kapıdan düştü"],
    dogru: "Rim alışkanlıkla aldı",
    suc: "Rim not alırken Yusuf'un kalemini kulağına koydu. Niyet yok.",
    neden: "Isırık Yusuf'a ait. Amara mor kullanır. Zaman penceresi su molası. Aram gördü.",
    ipuclari: ["Isırık kime ait?", "Rim'in alışkanlığı.", "Amara hangi renk?"]
  },
  {
    sezon: "3. sezon — Koridor ve odalar",
    baslik: "Kapalı oda ışığı",
    ozet: "Amara'nın odası kilitli, içeride lamba yanıyor. Amara salonda.",
    yer: "Amara'nın kapısı",
    saat: "Perşembe, 17:00",
    tur: "kapali-oda",
    kisiler: {
      Yusuf: ["Tanık", "Anahtar dışarıda, kilit dıştan. Lamba düğmesi içeride değil, kapı yanında dışarıda.", true, "Eski ev tesisatı."],
      Amara: ["Tanık", "Işığı kapayıp çıktım. Biri açtı.", true, "Düğme dışarıda olduğu için mümkün."],
      Aram: ["Şüpheli", "Karanlıktan korktum, ışığı açtım, kapıyı kilitledim oyun diye.", true, "Aram anahtarı salondaki kaseden alabilir."],
      Servan: ["Tanık", "Kilit çocuk kilidi, ben takmadım bugün.", true, "Kilit dün takılıydı."]
    },
    kanitlar: [
      ["dugme", "Lamba düğmesi", "Kapı çerçevesinin dışında, 90 cm. Aram yetişir.", true],
      ["kase", "Hol kasesi", "Amara'nın oda anahtarı yok, Aram'ın cezbünde çizik izli anahtar.", true],
      ["kilit2", "Çocuk kilidi", "Dıştan, basit sürgü."]
    ],
    sorular: [
      ["Aram", "Neden kilitledin?", "Saklambaç. Amara giremesin.", "Korktum, kaçtım.", "Yusuf dedi.", "a", "Oyun."]
    ],
    celiskiler: [
      ["Amara: düğme içeride sandım", "Düğme: dışarıda", true],
      ["Işık içeride biri var", "Amara salonda, düğme dışarıda", true]
    ],
    soru: "Işık neden yanıyor ve kapı neden kilitli?",
    secenekler: ["İçeride gizlenen var", "Aram dışarıdan açıp kilitledi", "Elektrik arızası", "Yusuf şaka yaptı"],
    dogru: "Aram dışarıdan açıp kilitledi",
    suc: "Aram saklambaç için ışığı açıp kapıyı dıştan kilitledi. Kapalı oda değil.",
    neden: "Düğme dışarıda. Anahtar kaseden gitmiş, Aram'da. Amara içeride olamaz, salonda. Tesisat yanıltıcı.",
    ipuclari: ["Düğme nerede?", "Kilit içten mi?", "Anahtar kasede mi?"]
  },
  {
    sezon: "3. sezon — Koridor ve odalar",
    baslik: "Yanlış ayakkabı",
    ozet: "Holde dört ayakkabı, biri eksik eş. Kim karıştırdı?",
    yer: "Hol",
    saat: "Perşembe, 18:30",
    tur: "eslestirme",
    kisiler: {
      Yusuf: ["Tanık", "Sol sporum var, sağ yok.", true, ""],
      Amara: ["Tanık", "Benim ikisi de pembe, yerinde.", true, ""],
      Aram: ["Tanık", "Büyük ayakkabıyla yürüdüm, düştüm.", true, "Yusuf'un sağı Aram'ın odasında."],
      Rim: ["Tanık", "Botlarım çift.", true, ""],
      Servan: ["Tanık", "İş ayakkabım çamurlu, holde değil balkonda.", true, ""]
    },
    kanitlar: [
      ["sag", "Sağ spor", "Aram'ın odasında, içinde kırmızı çorap tüyü.", true],
      ["tozt", "Hol tozu", "Sürükleme izi küçük adım, Aram.", true],
      ["pembe", "Pembe çift", "Amara tam."]
    ],
    sorular: [
      ["Aram", "Neden büyük ayakkabı?", "Dev gibi olmak. Oyun.", "Sakladım.", "Yok.", "a", "Oyun."]
    ],
    celiskiler: [
      ["Eksik ayakkabı çalındı", "Aram odasında sağ spor", true],
      ["Amara karıştırdı", "Pembe çift tam", true]
    ],
    soru: "Sağ spor ayakkabı nerede, kim aldı?",
    secenekler: ["Amara sakladı", "Aram oyun için aldı", "Servan balkona götürdü", "Kapı dışarıda"],
    dogru: "Aram oyun için aldı",
    suc: "Aram Yusuf'un sağ ayakkabısıyla dev oyunu oynadı.",
    neden: "Sürükleme küçük adım. İçinde Aram çorabı. Amara'nın çifti tam. Servan'ınki balkonda çamurlu.",
    ipuclari: ["Çiftleri say.", "Kim dev oyunu oynar?", "Sürükleme adımı."]
  },
  {
    sezon: "3. sezon — Koridor ve odalar",
    baslik: "Kulaklık kablosu",
    ozet: "Yusuf'un kablolu kulağı düğüm. Sabotaj mı, acele mi?",
    yer: "Yusuf'un çekmecesi",
    saat: "Perşembe, 19:00",
    tur: "mantik",
    kisiler: {
      Yusuf: ["Mağdur", "Dün düzgün sarmıştım. Bugün düğüm var.", true, "Dün akşam fotoğrafı düzgün."],
      Amara: ["Şüpheli", "Kablo yılan gibi, oynamadım.", false, "Boya kabloda yeşil nokta.", "Amara düğüm oyununu sever."],
      Aram: ["Tanık", "Amara 'yılan' dedi, çekmeceden çıkardı.", true, ""],
      Rim: ["Tanık", "Çekmeceye girmedim.", true, ""]
    },
    kanitlar: [
      ["yesil", "Kabloda boya", "Amara yeşili.", true],
      ["foto2", "Dün foto", "Kablo düz, 21:00.", true],
      ["cekmece", "Çekmece tozu", "Küçük parmak, sağ el."]
    ],
    sorular: [
      ["Amara", "Yılan oyunu mu?", "Evet, geri koydum.", "Hayır.", "Yusuf düğümledi.", "a", "Oyun itirafı."]
    ],
    celiskiler: [
      ["Amara: oynamadım", "Aram: yılan dedi", true],
      ["Yusuf: dün düzgün", "Foto: düzgün", false]
    ],
    soru: "Düğümü kim yaptı?",
    secenekler: ["Yusuf acele sardı", "Amara yılan oyunu", "Aram çekti", "Kablo kendiliğinden"],
    dogru: "Amara yılan oyunu",
    suc: "Amara kabloyu yılan sanıp düğümledi, geri koydu.",
    neden: "Yeşil boya. Aram duydu. Dünkü fotoğraf düzgün. Sabotaj değil oyun.",
    ipuclari: ["Boya rengi.", "Dünkü kanıt fotoğrafı.", "Yılan sözü."]
  },
  {
    sezon: "3. sezon — Koridor ve odalar",
    baslik: "Çalar saat",
    ozet: "Yusuf'un alarmı 06:00 yerine 05:00 çaldı.",
    yer: "Yusuf'un komodini",
    saat: "Cuma, 05:05",
    tur: "zaman",
    kisiler: {
      Yusuf: ["Mağdur", "Ben 06:00 kurdum, deftere yazdım.", true, "Defter 21:30."],
      Amara: ["Tanık", "Saate dokunmadım.", true, "Parmak izi yok onda."],
      Aram: ["Tanık", "Düğmeler parlak, bakmadım.", true, ""],
      Servan: ["Şüpheli", "Kendi alarmımı 05:00'e aldım, belki yanlış odaya baktım.", true, "Servan vardiya 05:30 çıkış. Yusuf'un saati aynı model."]
    },
    kanitlar: [
      ["model", "İki aynı saat", "Servan ve Yusuf, siyah kare.", true],
      ["iz3", "Saat düğmesi", "Yetişkin parmak, Servan.", true],
      ["def3", "Yusuf defteri", "06:00 kurdum, 21:30."]
    ],
    sorular: [
      ["Servan", "Hangi odaya girdin?", "Karanlıkta Yusuf'un saati sandım kendi saati.", "Şaka.", "Kurmadım.", "a", "Karışıklık."]
    ],
    celiskiler: [
      ["Yusuf: 06:00 kurdum", "Saat: 05:00, yetişkin iz", true],
      ["Amara dokundu", "İz: yetişkin", true]
    ],
    soru: "Alarm neden erken çaldı?",
    secenekler: ["Amara şaka yaptı", "Elektrik kesildi", "Servan karanlıkta yanlış saati kurdu", "Yusuf unuttu"],
    dogru: "Servan karanlıkta yanlış saati kurdu",
    suc: "Servan kendi 05:00 vardiyasını Yusuf'un aynı model saatine kurdu.",
    neden: "İki saat aynı. Yetişkin parmak. Defter 06:00 diyor. Çocuk izi yok.",
    ipuclari: ["Aynı model var mı?", "Parmak boyu.", "Vardiya saati."]
  },
  {
    sezon: "3. sezon — Koridor ve odalar",
    baslik: "Gizli çekmece",
    ozet: "Rim'in çekmecesi açık, içinde boş kutu.",
    yer: "Çalışma odası",
    saat: "Cuma, 10:20",
    tur: "eksik-bilgi",
    kisiler: {
      Yusuf: ["Tanık", "Kutu dün doluydu, arşiv fişleri.", true, "Dün gördü."],
      Amara: ["Tanık", "Fişleri yerde, sıralı, oyun değil.", true, "Yerde tarih sırası."],
      Aram: ["Tanık", "Açmadım, yüksek.", true, ""],
      Rim: ["Mağdur", "Fişleri ben yere dizdim, kutu dar geldi. Çekmeceyi kapatmayı unuttum.", true, "Çalışma yöntemi."]
    },
    kanitlar: [
      ["sira", "Yerdeki fişler", "Tarihe göre, 2019-2024. Çocuk oyunu rastgele olur.", true],
      ["kutu", "Kutu", "Dar, taşmış izi kenarda.", true],
      ["tozz", "Çekmece tozu", "Rim'in yüzük izi, başka yok."]
    ],
    sorular: [
      ["Rim", "Neden açık?", "Unuttum. Fişler yerde, çalınmadı.", "Hırsızlık.", "Yusuf açtı.", "a", "İhmal."]
    ],
    celiskiler: [
      ["Çekmece soyuldu", "Fişler: tarih sırası yerde", true],
      ["Aram açtı", "Yüksek + yüzük izi Rim", true]
    ],
    soru: "Kutu neden boş?",
    secenekler: ["Yusuf karıştırdı", "Amara oyun", "Rim fişleri yere dizdi", "Servan aldı"],
    dogru: "Rim fişleri yere dizdi",
    suc: "Boş kutu hırsızlık değil. Rim arşivi yere yaydı, çekmeceyi kapatmadı.",
    neden: "Tarih sırası bilinçli. Yüzük izi yalnız Rim. Kutu dar.",
    ipuclari: ["Rastgele mi sıralı mı?", "Kim yüzük takar?", "Yükseklik."]
  },
  {
    sezon: "3. sezon — Koridor ve odalar",
    baslik: "Yanlış kapı zili",
    ozet: "Zil üç kez çaldı, kapıda kimse yok.",
    yer: "Ön kapı",
    saat: "Cuma, 15:40",
    tur: "imkansiz",
    kisiler: {
      Yusuf: ["Tanık", "Merdiven boştu, bakış deliğinden gördüm.", true, ""],
      Amara: ["Tanık", "Hayalet komşu.", false, "Hayalet yok, kablo var.", ""],
      Aram: ["Tanık", "Ben düğmeye uzanamam.", true, "Düğme 130 cm."],
      Servan: ["Tanık", "Bahçedeydim, düğmeye basmadım. Kedi kabloya değdi.", true, "Kamera."]
    },
    kanitlar: [
      ["kamera", "Kapı kamerası", "Kedi 15:39, 15:41, 15:43 kabloyu çekiyor. İnsan yok.", true],
      ["kablo", "Zil kablosu", "Açıkta, izolasyon soyuk, kedi tüyü.", true],
      ["delik", "Bakış deliği", "Yusuf boş merdiven notu."]
    ],
    sorular: [
      ["Servan", "Kablo neden açık?", "Dün tamir ettim, bant unuttum.", "Sabotaj.", "Amara kesti.", "a", "Tamir eksik."]
    ],
    celiskiler: [
      ["Amara: hayalet", "Kamera: kedi", true],
      ["Biri kaçtı", "Kamera: insan yok", true]
    ],
    soru: "Zili ne çaldırdı?",
    secenekler: ["Kaçan bir komşu", "Amara içeriden", "Kedi açık kabloya değdi", "Aram uzandı"],
    dogru: "Kedi açık kabloya değdi",
    suc: "Zil arızası. Kedi, bantsız kabloya üç kez değdi.",
    neden: "Kamera insan göstermiyor. Düğme yüksek, Aram yetişmez. Servan tamirde bant unutmuş.",
    ipuclari: ["Kamera var mı?", "Kablo açık mı?", "Düğme boyu."]
  },
  {
    sezon: "3. sezon — Koridor ve odalar",
    baslik: "Kitap ayracı",
    ozet: "Rim'in kitabında ayracın yeri değişmiş. Sayfa 40'tan 12'ye.",
    yer: "Kanepe",
    saat: "Cuma, 20:00",
    tur: "sira",
    kisiler: {
      Yusuf: ["Tanık", "Kitabı okumadım, kapak sert.", true, ""],
      Amara: ["Tanık", "Resimlere baktım, baştaki resimler sayfa 12.", true, "Amara resim sever."],
      Aram: ["Tanık", "Ayracı çıkarıp arabama koydum, sonra geri.", false, "Ayraçta araba izi yok, boya var.", "Yalan, dikkat çekmek için."],
      Rim: ["Mağdur", "40. sayfadayım. Baştaki resimler Amara'ya uyar.", true, ""]
    },
    kanitlar: [
      ["ayrac", "Ayraç", "Yeşil boya, araba izi yok.", true],
      ["sayfa", "Sayfa 12", "Parmak ucu küçük, Amara, resim kenarı kıvrık.", true],
      ["kirk", "Sayfa 40", "Rim'in kurşun altı çizgisi yerinde, ayracsız."]
    ],
    sorular: [
      ["Amara", "Nereye koydun?", "Resimli sayfaya, unuttum.", "40'a.", "Almadım.", "a", "Resim."]
    ],
    celiskiler: [
      ["Aram: arabaya koydum", "Ayraç: araba izi yok, boya var", true],
      ["Yusuf okudu", "Kapak: Yusuf dokunmamış", true]
    ],
    soru: "Ayraç neden 12. sayfada?",
    secenekler: ["Rim baştan okudu", "Amara resme bakıp unuttu", "Aram arabaya koydu", "Yusuf şaka"],
    dogru: "Amara resme bakıp unuttu",
    suc: "Amara resimli sayfada ayraçı unuttu. Aram özenmek için yalan söyledi.",
    neden: "Boya Amara. Araba izi yok. Rim'in altı çizgisi 40'ta. Aram'ın yalanı kanıtsız.",
    ipuclari: ["Kim resim sever?", "Araba izi var mı?", "Altı çizili sayfa."]
  },
  {
    sezon: "3. sezon — Koridor ve odalar",
    baslik: "Islak havlu",
    ozet: "Banyoda üç havlu ıslak, bir kişi yıkanmış görünüyor.",
    yer: "Banyo",
    saat: "Cumartesi, 08:10",
    tur: "mantik",
    kisiler: {
      Yusuf: ["Tanık", "Ben kuru havlu aldım, asılı duruyor.", true, "Kuru."],
      Amara: ["Tanık", "Saçımı üç havluyla sardım, hepsi ıslandı.", true, "Saç uzun, ağır nem."],
      Aram: ["Tanık", "Yıkanmadım, el yıkadım.", true, "Küçük havlu az nemli, ayrı."],
      Servan: ["Tanık", "Duşa girmedim, vardiya dönüşü değil.", true, ""]
    },
    kanitlar: [
      ["sac", "Uzun saç teli", "Üç havluda Amara teli.", true],
      ["nem", "Nem ağırlığı", "Ortadaki havlu en ağır, saç sarması.", true],
      ["kuru", "Yusuf havlusu", "Kuru, ayrı askı."]
    ],
    sorular: [
      ["Amara", "Neden üç?", "Saç uzun, bir yetmedi.", "Sakladım.", "Yusuf ıslattı.", "a", "Pratik."]
    ],
    celiskiler: [
      ["Üç kişi yıkandı", "Tel: yalnız Amara, Yusuf kuru", true],
      ["Servan duş", "Vardiya yok, havlu onda kuru", true]
    ],
    soru: "Üç havlu neden ıslak?",
    secenekler: ["Üç kişi yıkandı", "Amara uzun saçı üç havluyla sardı", "Su kaçağı", "Aram oyun"],
    dogru: "Amara uzun saçı üç havluyla sardı",
    suc: "Tek kişi, üç havlu. Saç uzunluğu açıklar.",
    neden: "Tüm ıslak havlularda Amara teli. Yusuf'unki kuru. Su kaçağı yerde göl yok.",
    ipuclari: ["Tel kime ait?", "Yerde göl var mı?", "Saç uzunluğu."]
  },
  {
    sezon: "3. sezon — Koridor ve odalar",
    baslik: "Yanlış çorap",
    ozet: "Aram'ın sağ çorabı Rim'in çekmecesinde.",
    yer: "Çamaşır sepeti",
    saat: "Cumartesi, 11:00",
    tur: "eslestirme",
    kisiler: {
      Yusuf: ["Tanık", "Ben çorapları ayırdım, kırmızıları Aram kutusu.", true, ""],
      Amara: ["Tanık", "Kırmızı sevimli, birini cebime koydum sonra Rim çekmecesine düştü.", false, "Amara cebi boş, iz yok.", "Uydurma."],
      Aram: ["Tanık", "Çorabımı makineye attım, tek.", true, ""],
      Rim: ["Tanık", "Çamaşırı ben katladım, kırmızı tek kaldı, kendi çekmeceye koydum unutulanlar köşesine.", true, "Rim düzeni: tekler ayrı köşe."]
    },
    kanitlar: [
      ["kose", "Unutulanlar köşesi", "Tek çorap, tek eldiven, tek çorap notu.", true],
      ["makine", "Makine filtresi", "Kırmızı elyaf, eş yok.", true],
      ["cep", "Amara cebi", "Boş, kırmızı elyaf yok."]
    ],
    sorular: [
      ["Rim", "Neden senin çekmece?", "Tekleri oraya koyarım, sonra eşlenir.", "Sakladım.", "Amara koydu.", "a", "Sistem."]
    ],
    celiskiler: [
      ["Amara cebine koydu", "Cep: elyaf yok", true],
      ["Rim sistemi", "Köşe: tekler notu", false]
    ],
    soru: "Çorap neden Rim'de?",
    secenekler: ["Amara sakladı", "Yusuf şaka", "Rim tekleri ayrı köşeye koydu", "Aram gizledi"],
    dogru: "Rim tekleri ayrı köşeye koydu",
    suc: "Kayıp değil, katlama sistemi. Makine eşi yutmamış, tek kalmış.",
    neden: "Unutulanlar köşesi yazılı kural. Amara cebi boş. Yusuf ayırmış, Rim katlamış.",
    ipuclari: ["Rim'in köşe kuralı.", "Cepte iz var mı?", "Makine eşi."]
  }
]
