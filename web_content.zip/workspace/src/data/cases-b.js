export const CASES_B = [
  {
    sezon: "2. sezon — Mutfak izleri",
    baslik: "Eksik pasta",
    ozet: "Buzdolabındaki pastadan bir dilim eksik.",
    yer: "Mutfak",
    saat: "Pazartesi, 07:40",
    tur: "kayip",
    kisiler: {
      Yusuf: ["Şüpheli", "Gece uyudum. Dilimi Amara alır.", false, "Pijama kolunda çikolata.", "Defterde silinmiş 00:17 mutfak."],
      Amara: ["Koruyucu", "Beyaz gölge gördüm. Pencere açıktı.", false, "Pencere kilitli.", "Masal, Yusuf'u korur."],
      Aram: ["Tanık", "Kapı gıcırdadı. Yusuf'un sol terliği daha sesli.", true, "Terlik asimetrik."],
      Rim: ["Tanık", "00:05'te pasta tam, 00:30'da eksik.", true, "Dar pencere."],
      Servan: ["Tanık", "23:40'ta geldim, mutfağa girmedim. Holde çamur var, mutfakta yok.", true, "Çamur holde bitiyor."]
    },
    kanitlar: [
      ["tabak", "Küçük tabak", "Çocuk parmak izi, Yusuf boyu.", true],
      ["pijama", "Yusuf pijaması", "Kolda çikolata.", true],
      ["silik", "Defter satırı", "00:17 mutfak, silgi taze.", true],
      ["pencere", "Mutfak penceresi", "Kilitli, dış toz bozulmamış."]
    ],
    sorular: [
      ["Amara", "Gölge Yusuf boyunda mıydı?", "Hayaletler değişir.", "Belki Yusuf'du.", "Aram'dı.", "b", "Masal dağılıyor."]
    ],
    celiskiler: [
      ["Yusuf: uyudum", "Defter: 00:17 mutfak", true],
      ["Amara: pencere açık", "Pencere: kilitli", true],
      ["Servan: girmedim", "Hol: çamur bitiyor", false]
    ],
    soru: "Pastayı kim aldı?",
    secenekler: ["Yusuf", "Amara", "Aram", "Rim", "Servan"],
    dogru: "Yusuf",
    suc: "Yusuf gece bir dilim aldı. Amara onu korumak için masal anlattı.",
    neden: "Zaman 00:05-00:30. Servan'ın çamuru mutfakta yok. Pencere kilitli. Silinen satır ve çikolata Yusuf'ta. Amara'nın hayaleti kanıtsız.",
    ipuclari: ["Masalı kanıtla test et.", "Silinen yazı gizlenen gerçektir.", "Terlik sesi kime ait?"]
  },
  {
    sezon: "2. sezon — Mutfak izleri",
    baslik: "Yanlış sıra",
    ozet: "Kahvaltı tabağı dört kişiye kurulmuş, beş kişi evde.",
    yer: "Mutfak masası",
    saat: "Pazartesi, 08:00",
    tur: "sira",
    kisiler: {
      Yusuf: ["Tanık", "Ben tabak saydım, beş olmalı. Dördüncü eksik değil, beşinci yok.", true, "Yusuf sayıyı doğru kurar."],
      Amara: ["Tanık", "Aram'ın tabak yeri boş, o süt döktü diye ceza.", false, "Aram masada oturuyor, tabak Rim tarafında eksik.", "Boş yer Rim'in sandalyesi."],
      Aram: ["Tanık", "Benim tabak var, mavi. Mavi masada.", true, "Mavi tabak yerinde."],
      Rim: ["Tanık", "Çantamı aradım, soğuk kahve içecektim, oturmadım.", true, "Kart dosyası yüzünden acele."],
      Servan: ["Tanık", "Beş tabak koydum. Biri düştü sanmıştım.", false, "Yerde kırık yok.", "Unutmuş, Rim'i saymamış."]
    },
    kanitlar: [
      ["mavi", "Mavi tabak", "Aram'ın yeri dolu.", true],
      ["bos", "Boş servis", "Rim'in sandalye minderi basılmamış.", true],
      ["yer", "Yer", "Kırık yok, beşinci tabak dolapta unutulmuş."]
    ],
    sorular: [
      ["Rim", "Kahvaltıya oturdun mu?", "Hayır, kartı aradım.", "Evet.", "Aram'ı cezalandırdım.", "a", "Rim masaya oturmadı."]
    ],
    celiskiler: [
      ["Amara: Aram cezalı", "Mavi tabak: yerinde", true],
      ["Servan: biri düştü", "Yer: kırık yok", true]
    ],
    soru: "Kimin tabağı eksik ve neden?",
    secenekler: ["Aram cezalı", "Rim oturmadı", "Yusuf unuttu", "Tabak kırıldı"],
    dogru: "Rim oturmadı",
    suc: "Rim kartı ararken masaya oturmadı. Beşinci tabak dolapta kaldı.",
    neden: "Aram'ın mavi tabağı var. Minder basılmamış yer Rim'in. Kırık yok. Amara ceza uydurmuş.",
    ipuclari: ["Hangi sandalye boş?", "Kırık var mı?", "Kim acele ediyordu?"]
  },
  {
    sezon: "2. sezon — Mutfak izleri",
    baslik: "Tuz yerine şeker",
    ozet: "Çorbaya şeker girmiş. Kavanozlar karışmış.",
    yer: "Ocak yanı",
    saat: "Pazartesi, 12:30",
    tur: "eslestirme",
    kisiler: {
      Yusuf: ["Tanık", "Etiketler yerinde: mavi tuz, kırmızı şeker. Ben dokunmadım.", true, "Etiket mürekkebi kuru, dün yapıştırılmış."],
      Amara: ["Şüpheli", "Renkleri değiştirdim, oyun diye.", false, "Etiketler yerinde, içerik ters.", "İçerik karışmış, etiket değil."],
      Aram: ["Tanık", "Beyazı kaşığa koydum. Hangisi tuz bilemedim.", true, "Aram tadına bakmadan koydu."],
      Rim: ["Tanık", "Kavanozları sabah doldurdum: solda tuz.", true, "Rim sol=tuz demişti."],
      Servan: ["Tanık", "Kavanozları yıkayıp ters koydum, acele.", true, "Yıkama izi kapaklarda."]
    },
    kanitlar: [
      ["kapak", "Kapaklar", "Islak halka. Yeni yıkanmış, etiket aynı.", true],
      ["sol", "Sol kavanoz", "Etiket tuz, içerik tatlı. Şeker.", true],
      ["not", "Rim notu", "Sol tuz, sağ şeker. Servan yıkadıktan sonra yer değişmiş."]
    ],
    sorular: [
      ["Servan", "Kavanozları nereye koydun?", "Eski yerlerine.", "Elimdeki gibi, karışmış olabilir.", "Amara değiştirdi.", "b", "Yerler karışmış."]
    ],
    celiskiler: [
      ["Amara: etiket değiştirdim", "Etiket: dün, kuru", true],
      ["Rim: sol tuz", "Sol kavanoz: şeker", true]
    ],
    soru: "Çorbaya şeker nasıl girdi?",
    secenekler: ["Amara etiket değiştirdi", "Servan kavanozları ters koydu", "Yusuf şaka yaptı", "Rim yanlış doldurdu"],
    dogru: "Servan kavanozları ters koydu",
    suc: "Servan yıkadıktan sonra kavanozları ters yerleştirdi. Aram etiket okumadan sol kavanozu kullandı.",
    neden: "Etiketler yerinde. İçerik ters. Yıkama izi Servan. Amara etiket değiştiremez çünkü mürekkep dün kurumuş ve yerinde.",
    ipuclari: ["Etiket mi içerik mi ters?", "Kim yıkadı?", "Aram okumadan mı koydu?"]
  },
  {
    sezon: "2. sezon — Mutfak izleri",
    baslik: "Buzdolabı ışığı",
    ozet: "Buzdolabı gece üç kez açılmış. Kim uyanık?",
    yer: "Mutfak",
    saat: "Salı, 07:00",
    tur: "zaman",
    kisiler: {
      Yusuf: ["Tanık", "Bir kez, 00:17. Sonra yatım.", true, "Pasta dosyası ile uyumlu."],
      Amara: ["Tanık", "Ben açmadım. Işık korkutur.", true, "Amara gece mutfağa inmez."],
      Aram: ["Şüpheli", "Su içtim, bir kez.", false, "Kayıt üç kez: 00:17, 03:02, 03:06.", "İki kez 03'te, Aram suyu 03:02'de alır, kapıyı tam kapatmaz."],
      Rim: ["Tanık", "03:10'da su sesi duydum, indim, kapı aralıktı.", true, "Aralık kayıtta 4 dakika."],
      Servan: ["Tanık", "Vardiyadayım, 22:00-06:00 evde yokum.", true, "İş giriş kaydı."]
    },
    kanitlar: [
      ["log", "Kapı günlüğü", "00:17 kısa, 03:02 açılış, 03:06 hâlâ açık sinyal.", true],
      ["bardak", "Küçük bardak", "Lavaboda, Aram boyu, 03 civarı nem.", true],
      ["is", "Servan iş kaydı", "Gece evde değil."]
    ],
    sorular: [
      ["Aram", "Kapıyı kapattın mı?", "Evet.", "Unuttum, soğuk vurdu.", "Yusuf açtı.", "b", "Kapı aralık kalmış."]
    ],
    celiskiler: [
      ["Aram: bir kez", "Kayıt: 03:02 ve 03:06 açık", true],
      ["Servan: evde yokum", "İş kaydı: vardiya", false]
    ],
    soru: "03:00 kayıtları kime ait?",
    secenekler: ["Yusuf", "Amara", "Aram kapıyı aralık unuttu", "Rim üç kez açtı"],
    dogru: "Aram kapıyı aralık unuttu",
    suc: "Aram su aldı, kapıyı tam kapatmadı. Sistem iki kayıt üretti.",
    neden: "00:17 Yusuf, pasta dosyası. 03:02-03:06 tek kişi, kapı aralık. Servan evde yok. Amara inmez. Rim 03:10'da aralığı gördü.",
    ipuclari: ["Üç kayıt üç kişi demek değil.", "Açık kalan kapı ikinci sinyal üretir.", "Servan gece nerede?"]
  },
  {
    sezon: "2. sezon — Mutfak izleri",
    baslik: "Kırık kupa",
    ozet: "Rim'in kupası kulpsuz. Düştü mü, sıkıldı mı?",
    yer: "Lavabo",
    saat: "Salı, 08:20",
    tur: "mantik",
    kisiler: {
      Yusuf: ["Tanık", "Sıcak suyla yıkadım, kulp çatladı. Söyledim.", true, "Buhar izi camda."],
      Amara: ["Şüpheli", "Yusuf sakladı, o kırdı gizlemek için.", false, "Yusuf söylemiş, gizleme yok.", "İtiraf var."],
      Aram: ["Tanık", "Kupa sıcaktı, dokunamadım.", true, "Elini çekmiş."],
      Rim: ["Mağdur", "Kupa soğuk dolaptaydı. Ani sıcak çatlatır.", true, "Seramik kuralı."]
    },
    kanitlar: [
      ["catlak", "Çatlak hattı", "Termal çatlak, darbesiz, kulptan gövdeye.", true],
      ["cam", "Cam buhar", "08:12. Sıcak yıkama.", true],
      ["dolap", "Dolap notu", "Kupa dün gece dolaba konmuş, soğuk."]
    ],
    sorular: [
      ["Yusuf", "Neden sıcak su?", "Lekeyi çıkarmak için. Bilmeden.", "Kızmak için.", "Amara istedi.", "a", "Kaza, niyet yok."]
    ],
    celiskiler: [
      ["Amara: gizledi", "Yusuf: söyledim", true],
      ["Çatlak: darbe", "Hattı: termal", true]
    ],
    soru: "Kupa neden kırıldı?",
    secenekler: ["Amara vurdu", "Yusuf soğuk kupayı sıcak suya aldı", "Aram düşürdü", "Servan sıktı"],
    dogru: "Yusuf soğuk kupayı sıcak suya aldı",
    suc: "Kaza. Soğuk seramik ani sıcakta çatladı. Gizleme yok.",
    neden: "Çatlak darbe değil, termal. Yusuf itiraf etmiş. Amara gizleme uyduruyor.",
    ipuclari: ["Darbe izi var mı?", "Sıcak-soğuk farkı.", "Kim söyledi, kim suçladı?"]
  },
  {
    sezon: "2. sezon — Mutfak izleri",
    baslik: "Alışveriş listesi",
    ozet: "Listede 'anahtar kopyası' yazıyor. Kim ekledi?",
    yer: "Buzdolabı kapağı",
    saat: "Salı, 09:00",
    tur: "sahte-mesaj",
    kisiler: {
      Yusuf: ["Tanık", "Liste benim yazım değil. Kalem kalın.", true, "Yusuf ince uç."],
      Amara: ["Şüpheli", "Rim yazdı, ev işi.", false, "Rim basılı harf yazar, bu bitişik el yazısı.", "Yazı Amara defterindeki masal yazısına uyar."],
      Aram: ["Tanık", "Ben 'süt' yazdım, büyük harf.", true, "SÜT ayrı satır, büyük."],
      Rim: ["Tanık", "Listeye anahtar yazmam. Kopya için arşiv kartı yeter.", true, "Mantıklı."],
      Servan: ["Tanık", "Kopya istesem çilingir notu yazarım, listeye değil.", true, "Servan pratik."]
    },
    kanitlar: [
      ["kalem", "Kalın keçe", "Amara kutusu.", true],
      ["yazi", "Bitişik el yazısı", "Amara masal defteri ile aynı a, e.", true],
      ["sut", "SÜT satırı", "Aram, ayrı."]
    ],
    sorular: [
      ["Amara", "Neden kopya?", "Odaya yine girmek için.", "Rim istedi.", "Yazmadım.", "a", "Motif: eski oda."]
    ],
    celiskiler: [
      ["Amara: Rim yazdı", "Rim: basılı harf", true],
      ["Yusuf: ince uç", "Satır: kalın keçe", true]
    ],
    soru: "Anahtar kopyası satırını kim yazdı?",
    secenekler: ["Yusuf", "Amara", "Aram", "Rim", "Servan"],
    dogru: "Amara",
    suc: "Amara listeye kopya ekledi. Eski odaya tekrar girmek istiyor.",
    neden: "Yazı ve keçe Amara. Rim basılı yazar. Aram yalnız SÜT yazmış. Konu birinci sezonla bağlı.",
    ipuclari: ["Kim kalın keçe kullanır?", "Rim nasıl yazar?", "Satır ne işe yarar?"]
  },
  {
    sezon: "2. sezon — Mutfak izleri",
    baslik: "Bulaşık sırası",
    ozet: "Kimse bulaşık yıkamadığını söylüyor, tezgâh temiz.",
    yer: "Tezgâh",
    saat: "Salı, 21:10",
    tur: "eksik-bilgi",
    kisiler: {
      Yusuf: ["Tanık", "Ödevdim. Su sesi 20:40'ta geldi.", true, "Defter."],
      Amara: ["Tanık", "Ben resmi bitirdim, suya girmedim.", true, "Eller boyalı, ıslak değil."],
      Aram: ["Tanık", "Köpük gördüm, ellerim küçük, yetişmem.", true, "Musluk yüksek."],
      Rim: ["Tanık", "20:50'de indim, tezgâh temizdi. Ben yıkamadım.", true, "Zaman dar."],
      Servan: ["Şüpheli", "Televizyon izledim.", false, "Eller sabun kokuyor, TV 20:30-21:00 kapalı.", "İşten erken geldi, sessizce yıkadı."]
    },
    kanitlar: [
      ["sabun", "Servan elleri", "Limon sabunu, evin bulaşık sabunu.", true],
      ["tv2", "TV kaydı", "Kapalı.", true],
      ["bez", "Tezgâh bezi", "Nem 20:45 civarı, yetişkin el izi."]
    ],
    sorular: [
      ["Servan", "Sabun kokusu?", "Yüzümü yıkadım.", "Bulaşık. Söylemek istemedim, övülmeyeyim.", "Yok.", "b", "Sessiz iyilik."]
    ],
    celiskiler: [
      ["Servan: televizyon", "TV: kapalı", true],
      ["Yusuf: su 20:40", "Bez: 20:45 nem", false]
    ],
    soru: "Bulaşığı kim yıkadı?",
    secenekler: ["Yusuf", "Amara", "Aram", "Rim", "Servan"],
    dogru: "Servan",
    suc: "Servan sessizce yıkadı, övülmemek için inkâr etti.",
    neden: "TV kapalı. Sabun ve yetişkin el izi. Çocuklar boyalı veya kısa. Rim geç indi. Su sesi Yusuf notunda.",
    ipuclari: ["İnkâr her zaman suç değil.", "Sabun kokusu.", "TV alibisi."]
  },
  {
    sezon: "2. sezon — Mutfak izleri",
    baslik: "Pencere buğusu",
    ozet: "Camda 'GEÇ' yazısı. Kim yazdı, ne demek?",
    yer: "Mutfak camı",
    saat: "Çarşamba, 07:15",
    tur: "kod",
    kisiler: {
      Yusuf: ["Tanık", "GEÇ benim şifrem değil. Ben 'NOT' yazarım.", true, "Defter kodu."],
      Amara: ["Şüpheli", "Aram parmakla oynadı.", false, "Harfler 140 cm yükseklikte.", "Aram 95 cm, Yusuf 125, Amara 110, Rim 165, Servan 178."],
      Aram: ["Tanık", "Yazamadım, yüksek.", true, "Boy."],
      Rim: ["Tanık", "Ben 'GEÇ' yazmam. Belki Servan, vardiya geç kaldı diye.", true, "Mantık."],
      Servan: ["Tanık", "07:00'de çıktım, acele. Buğu taze, ben çıktıktan sonra.", true, "İş giriş 07:08."]
    },
    kanitlar: [
      ["yuk", "Yazı yüksekliği", "140 cm. Tabure izi cam önünde.", true],
      ["tabure", "Tabure", "Amara'nın boya ayakizi basamağında.", true],
      ["bugu", "Buğu nemi", "07:10-07:14. Servan 07:00'de çıkmış."]
    ],
    sorular: [
      ["Amara", "GEÇ ne demek?", "Yusuf geç kaldı, okul.", "Oyun.", "Servan.", "a", "Okul saati."]
    ],
    celiskiler: [
      ["Amara: Aram yazdı", "Yükseklik: 140 cm + tabure", true],
      ["Servan: ben çıktıktan sonra", "Buğu: 07:10", false]
    ],
    soru: "Yazıyı kim yazdı?",
    secenekler: ["Yusuf", "Amara tabureyle", "Aram", "Rim", "Servan"],
    dogru: "Amara tabureyle",
    suc: "Amara tabureye çıkıp Yusuf'a GEÇ yazdı.",
    neden: "Yükseklik tabure + Amara. Aram yetişmez. Servan erken çıkmış. Buğu onun çıkışından sonra.",
    ipuclari: ["Boy + yükseklik.", "Tabure izi.", "Servan saati."]
  },
  {
    sezon: "2. sezon — Mutfak izleri",
    baslik: "Eksik yoğurt",
    ozet: "Son yoğurt kayıp. Kapak çöpte.",
    yer: "Buzdolabı ve çöp",
    saat: "Çarşamba, 16:00",
    tur: "kayip",
    kisiler: {
      Yusuf: ["Tanık", "Okuldaydım, 15:50 geldim, yoğurt yoktu.", true, "Okul çıkış kaydı."],
      Amara: ["Tanık", "Ben meyve yedim, kabuk masada.", true, "Elma kabuğu."],
      Aram: ["Şüpheli", "Yoğurt yemedim, beyaz bıyık değil.", false, "Çöp kapağında küçük ağız izi, kaşık Aram boyu.", "Süt bıyığını silmiş."],
      Rim: ["Tanık", "Öğlen dolapta iki yoğurt vardı, akşam bir.", true, "Sayım."]
    },
    kanitlar: [
      ["kapak", "Kapak", "Küçük ağız, kaşık çizği içe doğru kısa.", true],
      ["okul", "Yusuf okul", "15:50'ye kadar dışarıda."],
      ["elma", "Elma kabuğu", "Amara, yoğurt değil."]
    ],
    sorular: [
      ["Aram", "Bıyığı sildin mi?", "Yok.", "Evet, Rim kızmasın.", "Yusuf yedi.", "b", "Gizleme küçük."]
    ],
    celiskiler: [
      ["Aram: yemedim", "Kapak: küçük ağız", true],
      ["Yusuf: okuldaydım", "Okul kaydı", false]
    ],
    soru: "Yoğurdu kim yedi?",
    secenekler: ["Yusuf", "Amara", "Aram", "Rim"],
    dogru: "Aram",
    suc: "Aram yoğurdu yedi, izi sildi.",
    neden: "Yusuf okulda. Amara elma. Kapak çocuk ağzı ve kısa kaşık. Öğlen iki, akşam bir.",
    ipuclari: ["Kim evdeydi?", "Ağız izi boyu.", "Elma yanıltmasın."]
  },
  {
    sezon: "2. sezon — Mutfak izleri",
    baslik: "Fırın zamanı",
    ozet: "Kek 10 dakika fazla pişmiş. Saat mi yanlış, unutkanlık mı?",
    yer: "Fırın",
    saat: "Çarşamba, 18:40",
    tur: "zaman",
    kisiler: {
      Yusuf: ["Tanık", "Zil 18:20 çaldı, ben odadaydım.", true, "Zil kaydı."],
      Amara: ["Tanık", "Kek kokusu güzeldi, çıkarmadım, Rim'in işi.", true, "Dokunmamış."],
      Aram: ["Tanık", "Kapı sıcak, yaklaşmadım.", true, ""],
      Rim: ["Mağdur", "18:20'de zili duymadım, arşiv telefonundaydım.", true, "Çağrı 18:18-18:31."],
      Servan: ["Şüpheli", "Zili kapadım, şaka, kek sürprizi.", false, "Zil kaydı kapanmamış, 18:20-18:30 çalmış.", "Servan zili duymadı, balkondaydı."]
    },
    kanitlar: [
      ["zil", "Fırın zili", "18:20-18:30 aktif, kapatılmamış.", true],
      ["cagri", "Rim çağrısı", "18:18-18:31 arşiv.", true],
      ["balkon", "Balkon kapısı", "Servan 18:15-18:35 dışarıda, sigara nemi."]
    ],
    sorular: [
      ["Rim", "Neden duymadın?", "Kulaklık ve çağrı.", "Umursamadım.", "Yusuf kapadı.", "a", "Çağrı kaydı."]
    ],
    celiskiler: [
      ["Servan: zili kapadım", "Zil: 10 dakika çalmış", true],
      ["Rim: duymadım", "Çağrı: 18:18-18:31", false]
    ],
    soru: "Kek neden fazla pişti?",
    secenekler: ["Servan zili kapadı", "Rim çağrıdayken kimse çıkarmadı", "Fırın saati 10 dakika ileri", "Yusuf unuttu"],
    dogru: "Rim çağrıdayken kimse çıkarmadı",
    suc: "Zil çalıştı. Rim çağrıdaydı, Servan balkonda, çocuklar yetki almadı.",
    neden: "Zil kapanmamış, Servan yalanı düşer. Fırın saati üçüncü dosyada doğruydu. Unutkanlık paylaşılmış sorumluluk, tek suçlu yok; asıl neden Rim'in duyamaması ve boş mutfak.",
    ipuclari: ["Zil gerçekten çaldı mı?", "Kim evin neresindeydi?", "Saat mi, insan mı?"]
  }
]
