export const CASES_E = [
  {
    sezon: "5. sezon — Kodlar ve defter",
    baslik: "Şifreli kutu",
    ozet: "Eski odada dört haneli kutu. İpucu: 'ilk kapı saati'.",
    yer: "Eski oda",
    saat: "Pazar, 15:00",
    tur: "kod",
    kisiler: {
      Yusuf: ["Yardımcı", "İlk kapı kaydı 17:51 idi. Dört hane 1751.", true, "Sensör dosyası."],
      Amara: ["Tanık", "Şifre doğum yılım 2018.", false, "Kutu 1751'de açıldı deneme izinde.", ""],
      Aram: ["Tanık", "Sayıları çevirdim, açılmadı.", true, "Yanlış deneme 1234."],
      Rim: ["Tanık", "Kutu anneannemin. İpucu kapı saatini işaret eder.", true, ""]
    },
    kanitlar: [
      ["kutu2", "Kutu denemeleri", "1234 hata, 2018 hata, 1751 açık tık.", true],
      ["ipucu", "İpucu kâğıdı", "İlk kapı saati. El yazısı Rim, eski.", true],
      ["sensor2", "Eski not", "Birinci dosya: 17:51."]
    ],
    sorular: [
      ["Yusuf", "Neden 1751?", "Kapı ilk o saatte açıldı.", "Amara doğumu.", "Rastgele.", "a", "Bağlı dosya."]
    ],
    celiskiler: [
      ["Amara: 2018", "Kutu: 2018 hata, 1751 açık", true],
      ["Aram açtı", "1234 hata", true]
    ],
    soru: "Kutunun şifresi nedir?",
    secenekler: ["2018", "1234", "1751", "1800"],
    dogru: "1751",
    suc: "Şifre 17:51, birinci dosyadaki kapı saati.",
    neden: "Deneme izleri 1751'de tık diyor. İpucu açık. Amara'nın doğum yılı elendi.",
    ipuclari: ["İpucunu kelimesi kelimesine al.", "Hangi dosyada kapı saati var?", "Deneme izleri."]
  },
  {
    sezon: "5. sezon — Kodlar ve defter",
    baslik: "Eksik harf",
    ozet: "Kutunun içinde 'A_ARA' kartı. Boşluk hangi harf?",
    yer: "Eski oda masası",
    saat: "Pazar, 15:20",
    tur: "eksik-bilgi",
    kisiler: {
      Yusuf: ["Yardımcı", "Aile adları: Amara uyar. Aram uyar ama A_ARA beş harf, Aram dört.", true, "Harf sayısı."],
      Amara: ["Tanık", "Benim adım. Kart bana.", true, ""],
      Aram: ["Tanık", "Benim adım kısa.", true, ""],
      Rim: ["Tanık", "Anneanne Amara'ya kart bırakırdı.", true, ""]
    },
    kanitlar: [
      ["kart2", "Kart", "A _ A R A. Beş hane, ikinci boş.", true],
      ["liste", "Ad listesi", "Yusuf 5, Amara 5, Aram 4, Rim 3, Servan 6.", true],
      ["murekkep3", "Kart mürekkebi", "Eski, anneanne. Yeni sahte değil."]
    ],
    sorular: [
      ["Yusuf", "Neden Amara?", "Beş harf, ikinci M.", "Aram.", "Rim.", "a", ""]
    ],
    celiskiler: [
      ["Aram'ın kartı", "Aram 4 harf, kart 5", true],
      ["Yeni sahte", "Mürekkep eski", true]
    ],
    soru: "Boşluk hangi harf, kart kimin?",
    secenekler: ["M, Amara", "R, Aram", "Y, Yusuf", "S, Servan"],
    dogru: "M, Amara",
    suc: "Kart AMARA. Anneanne bırakmış. Şifre kutusunun içi ona bağlı.",
    neden: "Harf sayısı eleyerek tek ad kalır. Aram sığmaz. Mürekkep eski, oyun kartı değil.",
    ipuclari: ["Harf say.", "İkinci harfi dene.", "Mürekkep yeni mi?"]
  },
  {
    sezon: "5. sezon — Kodlar ve defter",
    baslik: "Yanlış sıra notu",
    ozet: "Defterde olaylar 18:00, 17:51, 17:30 yazıyor. Sıra bozuk.",
    yer: "Yusuf'un defteri",
    saat: "Pazar, 16:00",
    tur: "sira",
    kisiler: {
      Yusuf: ["Tanık", "Sayfayı ters ciltledim, üç not yer değişti. Asıl sıra 17:30, 17:51, 18:00.", true, "Zımba izi ters."],
      Amara: ["Tanık", "Notları ben karıştırdım sandım, dokunmadım.", true, "Parmak yok."],
      Aram: ["Tanık", "Sayfa uçtu, Yusuf zımbaladı.", true, ""],
      Rim: ["Tanık", "Zaman çizelgesi birinci dosyayla ancak böyle uyum sağlar.", true, ""]
    },
    kanitlar: [
      ["zimba", "Zımba", "Ters batış, sayfa 180 derece.", true],
      ["murekkep4", "Not mürekkebi", "Aynı kalem, aynı gün, sıra yazım değil cilt hatası.", true],
      ["birinci", "Dosya 1 çizelgesi", "17:30 masa, 17:51 kapı, 18:00 foto."]
    ],
    sorular: [
      ["Yusuf", "Neden bozuk?", "Zımba ters. Okuma hatası olmasın diye söylüyorum.", "Amara değiştirdi.", "Uydurdum.", "a", ""]
    ],
    celiskiler: [
      ["Amara karıştırdı", "Parmak izi yok, zımba ters", true],
      ["Notlar yalan", "Birinci dosya ile uyum ters çevirince", true]
    ],
    soru: "Doğru zaman sırası nedir?",
    secenekler: ["18:00, 17:51, 17:30", "17:30, 17:51, 18:00", "17:51, 18:00, 17:30", "Hepsi aynı an"],
    dogru: "17:30, 17:51, 18:00",
    suc: "Sıra cilt hatası. Çevirince birinci dosya ile örtüşür.",
    neden: "Zımba ters. Parmak yok. 17:30 Yusuf masayı gördü, 17:51 kapı, 18:00 Servan fotoğrafı.",
    ipuclari: ["Zımbaya bak.", "Birinci dosyayı hatırla.", "Saatler geriye gidemez."]
  },
  {
    sezon: "5. sezon — Kodlar ve defter",
    baslik: "İki ifade, bir koridor",
    ozet: "Yusuf 'Amara soldan geldi' diyor, Aram 'sağdan'.",
    yer: "Koridor",
    saat: "Pazar, 16:40",
    tur: "celiski",
    kisiler: {
      Yusuf: ["Tanık", "Ben odamın kapısından baktım, Amara soldan.", true, "Yusuf'un kapısı koridoru ters gösterir."],
      Amara: ["Tanık", "Eski odadan geldim, pencere tarafı.", true, "Pencere planı sağ kanat, salondan bakınca."],
      Aram: ["Tanık", "Ben salondan baktım, sağdan geldi.", true, "Aynı an, ters bakış."],
      Rim: ["Yardımcı", "Koridor ayna gibi: iki uç ters yön söyler.", true, "Plan çizimi."]
    },
    kanitlar: [
      ["plan", "Ev planı", "Yusuf kapısı kuzey, salon güney. Sol ve sağ bakışa göre değişir.", true],
      ["pencerep", "Pencere kanadı", "Eski oda doğu. Salondan sağ, Yusuf'tan sol.", true],
      ["saat4", "İki not", "16:38 ikisi de. Yalan değil, geometri."]
    ],
    sorular: [
      ["Rim", "Kim yalan?", "Hiçbiri. Bakış yönü.", "Yusuf.", "Aram.", "a", ""]
    ],
    celiskiler: [
      ["Yusuf yalan", "Plan: ters bakış", true],
      ["İki saat farklı", "İkisi 16:38", true]
    ],
    soru: "Kim doğru konuşuyor?",
    secenekler: ["Yalnız Yusuf", "Yalnız Aram", "İkisi de, bakış yönü farklı", "İkisi de yalan"],
    dogru: "İkisi de, bakış yönü farklı",
    suc: "Çelişki görünür, gerçekte yok. Aynı yürüyüş, iki uç.",
    neden: "Ev planı sol-sağı ters çevirir. Saatler aynı. Amara pencere tarafını doğrular.",
    ipuclari: ["Haritayı çevir.", "Saatler aynı mı?", "Görünür çelişki her zaman yalan değildir."]
  },
  {
    sezon: "5. sezon — Kodlar ve defter",
    baslik: "Mühürlü zarf",
    ozet: "Kutudan çıkan zarf 'yalnız Rim açsın' diyor. Mühür sağlam.",
    yer: "Salon masası",
    saat: "Pazar, 17:10",
    tur: "mantik",
    kisiler: {
      Yusuf: ["Tanık", "Mühüre dokunmadık. Rim'i bekledik.", true, ""],
      Amara: ["Tanık", "Adımı görünce meraktım, açmadım.", true, ""],
      Aram: ["Tanık", "Yapıştırıcı tattım, kötü.", true, ""],
      Rim: ["Tanık", "Zarfı açtım: 'Amara'ya kartı ver, oda onun hatırası.'", true, "İçerik önceki kartı açıklar."],
      Servan: ["Tanık", "Mühürü ben kırmadım, iş mühürü ayrı.", true, ""]
    },
    kanitlar: [
      ["muhur2", "Mühür", "Tek kırılış 17:08, Rim yüzüğü baskı.", true],
      ["icerik", "İç not", "Amara'ya kartı ver. Anneanne.", true],
      ["yuzuk", "Rim yüzüğü", "Baskı motifi aynı."]
    ],
    sorular: [
      ["Rim", "Neden yalnız sen?", "Anneanne arşiv kuralı. İçerik Amara'ya emanet.", "Sakladım.", "Şifre yanlış.", "a", ""]
    ],
    celiskiler: [
      ["Servan açtı", "Yüzük baskısı Rim, tek kırılış", true],
      ["Amara gizlice açtı", "Mühür 17:08'e kadar sağlam", true]
    ],
    soru: "Zarfı kim açtı ve ne diyor?",
    secenekler: ["Servan, iş notu", "Amara, oyun", "Rim, kart Amara'ya emanet", "Yusuf, şifre"],
    dogru: "Rim, kart Amara'ya emanet",
    suc: "Mühür kuralı tutuldu. İçerik Amara kartını resmi emanet yapar.",
    neden: "Tek kırılış yüzükle uyumlu. Çocuklar bekledi. İki dosya birleşir: kart + zarf.",
    ipuclari: ["Mühür kaç kez kırık?", "Yüzük motifi.", "İçerik kime emanet?"]
  },
  {
    sezon: "5. sezon — Kodlar ve defter",
    baslik: "Yansıyan yazı",
    ozet: "Camda tersten 'AMARA' yazısı. Kim, nasıl?",
    yer: "Eski oda camı",
    saat: "Pazar, 17:40",
    tur: "kod",
    kisiler: {
      Yusuf: ["Yardımcı", "İçeriden düz yazılırsa dışarıdan ters okunur. Yazı içeriden.", true, ""],
      Amara: ["Tanık", "Ben dışarıdan yazdım sandım, aslında içeride buğu.", true, ""],
      Aram: ["Tanık", "Harfler korkutucu, hayalet adı.", false, "Hayalet değil, buğu.", ""],
      Rim: ["Tanık", "Amara adını camın içine yazmış, hatıra.", true, ""]
    },
    kanitlar: [
      ["bugu2", "Buğu katmanı", "İç camda. Dış cam kuru.", true],
      ["yon", "Harf yönü", "İçeriden AMARA düz, dışarıdan ARAMA.", true],
      ["parmak", "Yükseklik", "110 cm, Amara. Tabure yok bu kez, cam alçak kanat."]
    ],
    sorular: [
      ["Yusuf", "Neden ters?", "Dışarıdan bakış. Yazı içeride.", "Şifre.", "Servan.", "a", ""]
    ],
    celiskiler: [
      ["Hayalet adı", "İç buğu, Amara boyu", true],
      ["Dışarıdan yazıldı", "Dış cam kuru", true]
    ],
    soru: "Yazı nasıl oluştu?",
    secenekler: ["Dışarıdan biri yazdı", "Amara içeriden buğuya adını yazdı", "Aram tersten çizdi", "Yansıma tesadüf"],
    dogru: "Amara içeriden buğuya adını yazdı",
    suc: "Hatıra yazısı. Ters okuma cam fiziği.",
    neden: "Buğu içte. Dış kuru. Boy 110 cm. ARAMA dışarıdan okunuş, AMARA içeri.",
    ipuclari: ["İç cam mı dış cam mı ıslak?", "Ters okuma.", "Boy."]
  },
  {
    sezon: "5. sezon — Kodlar ve defter",
    baslik: "Üç anahtar ucu",
    ozet: "Çilingir üç yedek getirdi. Hangisi eski odaya uyar?",
    yer: "Hol masası",
    saat: "Pazar, 18:20",
    tur: "eslestirme",
    kisiler: {
      Yusuf: ["Yardımcı", "Asıl anahtarın diş sayısı 5. A ucu 4, B 5, C 6.", true, ""],
      Amara: ["Tanık", "En parlak olan C, o olsun.", false, "Parlaklık yeni kesim, uyum değil.", ""],
      Aram: ["Tanık", "B çıngırdadı, asıl da öyleydi.", true, "Kulak."],
      Servan: ["Tanık", "Çilingir B'yi asıldan kopyaladı, A ve C stok.", true, "Fiş."]
    },
    kanitlar: [
      ["dis", "Diş kalıbı", "Asıl 5 diş, B birebir.", true],
      ["fis", "Çilingir fişi", "Kopya: parça B.", true],
      ["parlak", "C parlaklığı", "Stok, oluklar farklı."]
    ],
    sorular: [
      ["Yusuf", "Neden B?", "Beş diş ve fiş.", "Parlak.", "A kısa.", "a", ""]
    ],
    celiskiler: [
      ["Amara: parlak C", "Fiş: kopya B, C stok", true],
      ["A uyar", "A 4 diş", true]
    ],
    soru: "Hangi yedek doğru?",
    secenekler: ["A", "B", "C", "Hiçbiri"],
    dogru: "B",
    suc: "B, asılın kopyası. Parlaklık ölçüt değil.",
    neden: "Diş 5. Fiş B diyor. Aram sesi doğruluyor. C stok.",
    ipuclari: ["Diş say.", "Fiş oku.", "Parlaklık tuzak."]
  },
  {
    sezon: "5. sezon — Kodlar ve defter",
    baslik: "Sessiz zil",
    ozet: "İç zil düğmesi basılı, ses yok. Kim kesti?",
    yer: "Hol",
    saat: "Pazar, 19:00",
    tur: "imkansiz",
    kisiler: {
      Yusuf: ["Tanık", "Pil kutusu boş. Ses kesilir.", true, ""],
      Amara: ["Tanık", "Ses korkutuyor diye pili çıkardım, söyleyecektim.", true, ""],
      Aram: ["Tanık", "Kabloyu kesmedim, makas yok.", true, "Kablo sağlam."],
      Servan: ["Tanık", "Kabloyu tamir ettim, bantlı. Pil ayrı konu.", true, "Önceki kedi dosyası."]
    },
    kanitlar: [
      ["pil", "Pil yuvası", "Boş, Amara parmak izi.", true],
      ["kablo3", "Kablo", "Bantlı, kesik yok. İletken sağlam.", true],
      ["makas", "Makas çekmecesi", "Tozlu, kullanılmamış."]
    ],
    sorular: [
      ["Amara", "Neden pil?", "Zil ani, korkuyorum. Söyleyecektim.", "Kabluyu kestim.", "Yusuf çıkardı.", "a", ""]
    ],
    celiskiler: [
      ["Kablo kesik", "Kablo sağlam, yuva boş", true],
      ["Servan bozdu", "Servan bantlamış, iletken var", true]
    ],
    soru: "Zil neden sessiz?",
    secenekler: ["Kablo kesik", "Amara pili çıkardı", "Servan ters bağladı", "Aram düğmeyi kırdı"],
    dogru: "Amara pili çıkardı",
    suc: "Ses yok çünkü pil yok. Kablo önceki tamirden sağlam.",
    neden: "Yuvarlak iz Amara. Makas tozlu. Servan'ın bantı iletkenliği koruyor.",
    ipuclari: ["Önce pile bak.", "Kablo gerçekten kesik mi?", "Kim sesten korkar?"]
  },
  {
    sezon: "5. sezon — Kodlar ve defter",
    baslik: "Çift defter",
    ozet: "İki defter var, ikisi de Yusuf'un yazısı gibi.",
    yer: "Yusuf'un masası",
    saat: "Pazar, 19:40",
    tur: "sahte-mesaj",
    kisiler: {
      Yusuf: ["Mağdur", "Asıl defter sağa yatık. Düz olan kopya.", true, ""],
      Amara: ["Şüpheli", "Ödev için kopya tuttum, tarihleri uydurdum.", true, "İtiraf yönünde."],
      Aram: ["Tanık", "Amara gece yazdı, ışık 21:10.", true, ""],
      Rim: ["Tanık", "Eğim ölçümü: asıl 12 derece, kopya 2 derece.", true, "Arşiv alışkanlığı."]
    },
    kanitlar: [
      ["egim", "İki eğim", "12° Yusuf, 2° Amara taklidi.", true],
      ["kagit", "Kâğıt", "Kopya yeni paket, asıl eski sarı kenar.", true],
      ["isik5", "Lamba 21:10", "Amara odası, Yusuf o saatte uyuyor notu."]
    ],
    sorular: [
      ["Amara", "Neden kopya?", "Suçlanmamak için tarih uydurdum. Yanlıştı.", "Yusuf istedi.", "Kopya değil.", "a", ""]
    ],
    celiskiler: [
      ["İkisi de Yusuf", "Eğim 12 ve 2, kâğıt yaş farkı", true],
      ["Yusuf 21:10 yazdı", "Yusuf uyuyor, ışık Amara odası", true]
    ],
    soru: "Düz yazı defteri kimin?",
    secenekler: ["Yusuf", "Amara taklidi", "Rim arşiv", "Servan"],
    dogru: "Amara taklidi",
    suc: "Amara Yusuf yazısını taklit etti. Eğim ve kâğıt yaş ele verir.",
    neden: "12 derece kuralı birinci notta da vardı. Yeni kâğıt. Gece ışığı Amara'da.",
    ipuclari: ["Eğimi ölç.", "Kâğıt yaşı.", "Kim gece yazdı?"]
  },
  {
    sezon: "5. sezon — Kodlar ve defter",
    baslik: "Son kilit denemesi",
    ozet: "Yedek B anahtar odaya uydu. İçeride yeni bir not: 'sır bitti mi?'",
    yer: "Eski oda",
    saat: "Pazar, 20:10",
    tur: "mantik",
    kisiler: {
      Yusuf: ["Yardımcı", "Sır bitti sayılır: anahtar, kart, zarf, kedi, kilit hepsi açıklandı.", true, ""],
      Amara: ["Tanık", "Sır bitsin istemiyorum, oda oyun alanıydı.", true, "Dürüst arzu."],
      Aram: ["Tanık", "Notu Amara yazdı, soru işareti onun.", true, ""],
      Rim: ["Tanık", "Oda artık açık, hatıra durur, yasak kalkar.", true, ""],
      Servan: ["Tanık", "Kapıyı açık bırakırız, sürgü dışarıda kalır.", true, "İkinci dosya bilgisi."]
    },
    kanitlar: [
      ["nots", "Not", "Soru işareti Amara kıvrımı, mor keçe.", true],
      ["anahtarB", "Anahtar B", "Kilitte, uyumlu, zorlama yok.", true],
      ["surgü2", "Sürgü", "Dışarıda, kasıtlı açık konum."]
    ],
    sorular: [
      ["Amara", "Sır bitti mi?", "Evet, saklamayacağım.", "Hayır, yeni sır var.", "Yusuf yazdı.", "a", "Kapanış."]
    ],
    celiskiler: [
      ["Yusuf notu yazdı", "Mor keçe ve soru kıvrımı Amara", true],
      ["Kilit hâlâ kapalı sır", "B uydu, sürgü açık", true]
    ],
    soru: "Oda sırrı bitti mi?",
    secenekler: ["Hayır, yeni kilit var", "Evet, not Amara'nın veda sorusu", "Servan hâlâ saklıyor", "Kart sahteydi"],
    dogru: "Evet, not Amara'nın veda sorusu",
    suc: "Teknik sırlar kapandı. Not veda. Oda hatıra olarak açık.",
    neden: "B anahtar uydu. Tüm önceki izler açıklanmıştı. Not Amara kalemi. Sürgü kasıtlı açık.",
    ipuclari: ["Kalem rengi.", "Anahtar uydu mu?", "Sürgü konumu."]
  }
]
