export const CASES_D = [
  {
    sezon: "4. sezon — Bahçe ve komşu",
    baslik: "Kayıp bileklik",
    ozet: "Parkta kayıp bileklik holdeki kasede duruyor.",
    yer: "Hol kasesi ve bahçe",
    saat: "Cumartesi, 11:20",
    tur: "kayip",
    kisiler: {
      Yusuf: ["Yardımcı", "Kasede bırakılmış, gizlenmemiş. Çalınmış gibi durmuyor.", true, "Yöntem doğru."],
      Amara: ["Tanık", "Rim'in ceketi sabah ıslaktı, çimen kokuyordu.", true, "Koku."],
      Aram: ["Tanık", "Ben almadım. Anne kaseya koy der. Ben koymadım.", true, ""],
      Rim: ["Şüpheli", "Sabah yürüdüm. Cebimde bir şey vardı, kaseye koydum. Sahibini arayacaktım. Unuttum.", true, "İfade kanıtla uyumlu."],
      Servan: ["Yanlış iz", "Bu hırsızlık. Çocuklardan biri almıştır.", false, "Varsayım.", "Kase görünür yer."]
    },
    kanitlar: [
      ["kaseb", "Hol kasesi", "Anahtarların yanı, gizlenmemiş.", true],
      ["ceketb", "Rim'in ceketi", "Sol cep nemli, çimen tohumu. Sağ cepte park bileti 08:40.", true],
      ["bileklik", "Mavi taş", "İçinde Lina kazıması. Ailede Lina yok.", true],
      ["paspas", "Hol paspası", "Tek bot izi, Rim. Bu saatte çocuk izi yok."]
    ],
    sorular: [
      ["Rim", "Neden söylemedin?", "Unuttum. İade niyeti vardı.", "Sakladım.", "Komşuyu üzmeyeyim.", "a", "İhmal."]
    ],
    celiskiler: [
      ["Servan: hırsızlık", "Kase: görünür yer", true],
      ["Rim: yürüdüm", "Bilet: 08:40 park", false]
    ],
    soru: "Bileklik eve nasıl girdi?",
    secenekler: ["Yusuf çaldı", "Amara aldı", "Aram parlak sandı", "Rim parkta bulup unuttu", "Servan gizledi"],
    dogru: "Rim parkta bulup unuttu",
    suc: "Rim bilekliği parkta buldu, kaseye koydu, iadeyi unuttu. Hırsızlık yok.",
    neden: "Gizleme yok. Islak ceket ve bilet aynı yürüyüşü anlatır. Paspasda çocuk izi yok. Servan varsayıyor.",
    ipuclari: ["Gizlenmeyen nesne çalınmamıştır.", "Islak ceket ve bilet.", "Suç ile ihmal ayrı."]
  },
  {
    sezon: "4. sezon — Bahçe ve komşu",
    baslik: "Sahte komşu notu",
    ozet: "Kapıda 'bilekliği geri verin — Lina'nın annesi' yazıyor.",
    yer: "Ön kapı",
    saat: "Cumartesi, 12:00",
    tur: "sahte-mesaj",
    kisiler: {
      Yusuf: ["Tanık", "Yazı komşu değil. Komşu basılı harf bırakır, bu çocuk yazısı.", true, "Dünkü notlarla karşılaştırdı."],
      Amara: ["Şüpheli", "Notu ben yazmadım, korktum.", false, "Mor keçe yine.", "Aynı kalem, alışveriş listesi."],
      Aram: ["Tanık", "Amara kapıya kâğıt bantladı.", true, ""],
      Rim: ["Tanık", "Komşuyu aradım, not bırakmadıklarını söyledi.", true, "Telefon 11:50."],
      Servan: ["Tanık", "Notu görünce kızdım, çocukları suçladım yine.", true, "Acele hüküm."]
    },
    kanitlar: [
      ["notk", "Kapı notu", "Mor keçe, Amara a ve e harfi.", true],
      ["tel", "Komşu çağrısı", "11:50, not yok dendi.", true],
      ["bant", "Pembe bant", "Amara kutusundan."]
    ],
    sorular: [
      ["Amara", "Neden not?", "Rim üzülmesin, konu kapansın sandım.", "Komşu istedi.", "Yazmadım.", "a", "Yanlış yardım."]
    ],
    celiskiler: [
      ["Not: Lina'nın annesi", "Komşu: not bırakmadık", true],
      ["Amara: yazmadım", "Aram: bantladı", true]
    ],
    soru: "Kapı notunu kim yazdı?",
    secenekler: ["Komşu", "Amara", "Yusuf", "Servan", "Rim"],
    dogru: "Amara",
    suc: "Amara sahte komşu notu yazdı. Rim'i korumak istedi, iz karıştı.",
    neden: "Komşu aranınca notu reddetti. Yazı ve bant Amara. Servan yine acele kızdı.",
    ipuclari: ["Komşuyu doğrula.", "Kalem rengi.", "Kim bantladı?"]
  },
  {
    sezon: "4. sezon — Bahçe ve komşu",
    baslik: "Bahçe kapısı",
    ozet: "Bahçe kapısı açık, kilit yerinde duruyor.",
    yer: "Bahçe girişi",
    saat: "Cumartesi, 13:10",
    tur: "kapali-oda",
    kisiler: {
      Yusuf: ["Tanık", "Kilit açık unutulmuş, kapı rüzgârla salınmış.", true, "Rüzgâr 13:00."],
      Amara: ["Tanık", "Kilit kırık sandım.", false, "Kilit sağlam, açık unutulmuş.", ""],
      Aram: ["Tanık", "Kapıyı ittim, kilit takılı değildi.", true, ""],
      Servan: ["Şüpheli", "Ben kilitledim, eminım.", false, "Servan 12:50 çöpü çıkardı, kilit elinde fotoğrafta.", "Çöp torbası yüzünden kilit takılmamış."]
    },
    kanitlar: [
      ["kilitb", "Asma kilit", "Sağlam, açık, anahtar hâlâ takılı.", true],
      ["ruzgar", "Rüzgâr kaydı", "13:00-13:08. Kapı menteşe izi salınım.", true],
      ["copf", "Çöp fotoğrafı", "Servan 12:50, kilit avucunda, kapı açık."]
    ],
    sorular: [
      ["Servan", "Kilit elde neden?", "Çöp ağırdı, sonra takmayı unuttum.", "Kırdım.", "Amara açtı.", "a", "Unutkanlık."]
    ],
    celiskiler: [
      ["Servan: kilitledim", "Foto: kilit elde, kapı açık", true],
      ["Amara: kilit kırık", "Kilit: sağlam", true]
    ],
    soru: "Kapı neden açık?",
    secenekler: ["Kilit kırıldı", "Amara açtı", "Servan çöp taşırken kilitlemeyi unuttu", "Hırsız girdi"],
    dogru: "Servan çöp taşırken kilitlemeyi unuttu",
    suc: "Kilit kırık değil. Servan unuttu, rüzgâr kapıyı saldı.",
    neden: "Fotoğraf kilit elde. Kilit sağlam ve anahtarlı. Rüzgâr salınımı menteşede. İçeri iz yok.",
    ipuclari: ["Kilit kırık mı açık mı?", "Servan'ın eli.", "Rüzgâr saati."]
  },
  {
    sezon: "4. sezon — Bahçe ve komşu",
    baslik: "Saksı yer değişti",
    ozet: "Bahçedeki ağır saksı bir metre kaymış.",
    yer: "Bahçe yolu",
    saat: "Cumartesi, 14:00",
    tur: "imkansiz",
    kisiler: {
      Yusuf: ["Tanık", "Saksı 18 kilo. Ben kaydıramam, Aram hiç.", true, "Kantar 18.2."],
      Amara: ["Tanık", "Tekerlekli tahta var, Servan odun taşır.", true, ""],
      Aram: ["Tanık", "Karınca gibi ittim, kıpırdamadı.", true, "Dürüst."],
      Rim: ["Tanık", "Çiçeği güneşe almak için tahtayı kullandım. Söylemedim, övülmeyeyim.", true, ""]
    },
    kanitlar: [
      ["tahta", "Tekerlekli tahta", "Toprak izi, saksı dibi çapı uyuyor.", true],
      ["kantar", "Kantar", "18.2 kg. Çocuk kaydıramaz.", true],
      ["izg", "Yol izi", "İki paralel teker, yetişkin adım yanı sıra. Rim botu."]
    ],
    sorular: [
      ["Rim", "Neden sessiz?", "Çiçek için. Küçük iş.", "Sakladım.", "Servan yaptı.", "a", "Güneş."]
    ],
    celiskiler: [
      ["Çocuk kaydırdı", "18 kg + teker izi Rim botu", true],
      ["Aram itti", "Aram: kıpırdamadı", false]
    ],
    soru: "Saksıyı kim kaydırdı?",
    secenekler: ["Yusuf", "Amara", "Aram", "Rim tekerlekli tahta ile"],
    dogru: "Rim tekerlekli tahta ile",
    suc: "Rim çiçeği güneşe aldı. Ağırlık imkânsızlığını tahta çözer.",
    neden: "18 kg çocuk işi değil. Teker izi ve bot Rim. Aram dürüstçe başaramadığını söyledi.",
    ipuclari: ["Ağırlık hesabı.", "Teker izi.", "Kim sessiz bahçıvan?"]
  },
  {
    sezon: "4. sezon — Bahçe ve komşu",
    baslik: "Islak çamaşır ipi",
    ozet: "Kuru olması gereken çamaşır yine ıslak. Yağmur yağmadı.",
    yer: "Bahçe ipi",
    saat: "Cumartesi, 16:30",
    tur: "mantik",
    kisiler: {
      Yusuf: ["Tanık", "Hava durumu: yağmur yok, nem %40.", true, "Uygulama."],
      Amara: ["Tanık", "Hortumla oyun. Rim kızmasın diye söylemedim.", true, ""],
      Aram: ["Tanık", "Su tabancası Amara'da.", true, ""],
      Servan: ["Tanık", "Hortumu 16:00'da kapadım sanmıştım, musluk damlıyordu.", false, "Musluk 16:10'dan beri kapalı, hortum kuru uçta.", "Damla yok, sıçrama var."]
    },
    kanitlar: [
      ["sicrama", "Sıçrama deseni", "Çocuk boyu, yelpaze. Hortum ucu oyun.", true],
      ["hava", "Hava kaydı", "Yağmur yok.", true],
      ["musluk", "Bahçe musluğu", "16:10 kapalı. Hortum ucu nemli, gövde kuru."]
    ],
    sorular: [
      ["Amara", "Neden ıslattın?", "Yaz sıcağı, serinlik. Çamaşır denk geldi.", "Yağmur sandım.", "Servan hortumu unuttu.", "a", "Oyun."]
    ],
    celiskiler: [
      ["Yağmur ıslattı", "Hava: yağmur yok", true],
      ["Servan: musluk damlıyor", "Musluk: kapalı, sıçrama yelpaze", true]
    ],
    soru: "Çamaşır neden ıslak?",
    secenekler: ["Yağmur", "Servan musluğu unuttu", "Amara hortum oyunu", "Rim yıkadı yeniden"],
    dogru: "Amara hortum oyunu",
    suc: "Amara su tabancasıyla oynadı, çamaşır denk geldi.",
    neden: "Yağmur yok. Musluk kapalı. Yelpaze sıçrama çocuk boyu. Aram tanık.",
    ipuclari: ["Hava kaydı.", "Sıçrama boyu.", "Musluk gerçekten açık mı?"]
  },
  {
    sezon: "4. sezon — Bahçe ve komşu",
    baslik: "Kayıp futbol topu",
    ozet: "Top bahçede yok. Komşu duvarının ardından ses geldi.",
    yer: "Bahçe ve duvar",
    saat: "Cumartesi, 17:20",
    tur: "kayip",
    kisiler: {
      Yusuf: ["Tanık", "Son vuruş Servan'dan, top yüksek gitti.", true, ""],
      Amara: ["Tanık", "Komşu kızgın değil, topu sepete koymuş.", true, "Çit aralığından gördü."],
      Aram: ["Tanık", "Top uçtu, ben ağladım, çalınmadı.", true, ""],
      Servan: ["Şüpheli", "Ben vurmadım, Yusuf vurdu.", false, "Çim izi büyük ayakkabı, Servan.", "İnkâr, mahcubiyet."]
    },
    kanitlar: [
      ["cim", "Çim izi", "42 numara kayma, Servan.", true],
      ["cit", "Çit aralığı", "Amara'nın gördüğü sarı top komşu sepetinde.", true],
      ["ses", "Duvar sesi", "17:18 lastik vuruş, sonra tok ses: sepete düşüş."]
    ],
    sorular: [
      ["Servan", "Neden inkâr?", "Camı kırarım diye utandım. Kırılmamış.", "Yusuf vurdu.", "Top yok.", "a", "Mahcubiyet."]
    ],
    celiskiler: [
      ["Servan: Yusuf vurdu", "Çim: 42 numara", true],
      ["Top çalındı", "Sepet: sarı top duruyor", true]
    ],
    soru: "Top nerede, kim gönderdi?",
    secenekler: ["Yusuf kaçırdı", "Amara sakladı", "Servan vurdu, top komşu sepetinde", "Aram duvardan attı"],
    dogru: "Servan vurdu, top komşu sepetinde",
    suc: "Servan yüksek vurdu. Top komşuda, çalınmadı. Utanç inkâr doğurdu.",
    neden: "42 numara iz. Çitten görünen sepet. Ses sırası vuruş-düşüş. Yusuf küçük numara.",
    ipuclari: ["Ayakkabı numarası.", "Çit aralığı.", "Utanç yalanı."]
  },
  {
    sezon: "4. sezon — Bahçe ve komşu",
    baslik: "Lina'nın teşekkürü",
    ozet: "Kapıda yeni not: 'Bileklik geldi, teşekkürler.' Yazı kimin?",
    yer: "Ön kapı",
    saat: "Cumartesi, 18:00",
    tur: "sahte-mesaj",
    kisiler: {
      Yusuf: ["Tanık", "Bu kez basılı harf. Komşu gerçekten yazmış olabilir.", true, "Önceki sahte bitişikti."],
      Amara: ["Tanık", "Ben yazmadım, söz.", true, "Mor keçe bu kâğıtta yok."],
      Aram: ["Tanık", "Kapıya bir kadın yapıştırdı, uzun saç.", true, ""],
      Rim: ["Tanık", "Bilekliği 17:40'ta iade ettim. Not 17:50 kamera.", true, ""],
      Servan: ["Tanık", "Yine sahte derim.", false, "Kamera kadını gösteriyor.", "Acele."]
    },
    kanitlar: [
      ["kam2", "Kapı kamerası", "17:50 kadın, basılı not. Amara değil.", true],
      ["murekkep2", "Mürekkep", "Siyah tükenmez, keçe değil.", true],
      ["onceki", "Önceki sahte not", "Mor, bitişik. Farklı."]
    ],
    sorular: [
      ["Servan", "Kamera ne diyor?", "Kadın var. Yanıldım.", "Sahte.", "Amara.", "a", "Kanıt."]
    ],
    celiskiler: [
      ["Servan: yine sahte", "Kamera: kadın 17:50", true],
      ["Amara yazdı", "Mürekkep: siyah tükenmez", true]
    ],
    soru: "Teşekkür notu gerçek mi?",
    secenekler: ["Amara yine yazdı", "Yusuf yazdı", "Gerçek, komşu bıraktı", "Servan yazdı"],
    dogru: "Gerçek, komşu bıraktı",
    suc: "Not gerçek. Rim iade etti, komşu teşekkür etti.",
    neden: "Yazı tipi değişti. Kamera kadın gösteriyor. Önceki sahte nottan farklı kalem. Servan kalıba saplandı.",
    ipuclari: ["İki notu karşılaştır.", "Kamera.", "İade saati."]
  },
  {
    sezon: "4. sezon — Bahçe ve komşu",
    baslik: "Kedi izi",
    ozet: "Eski oda pervazında pati izi. Evde kedi yok.",
    yer: "Eski oda penceresi",
    saat: "Pazar, 09:00",
    tur: "eslestirme",
    kisiler: {
      Yusuf: ["Tanık", "Pencere sürgüsü 8 cm açık. Kedi sığar, insan sığmaz.", true, "Ölçü."],
      Amara: ["Tanık", "Komşu kedisi zil kablosundaki kedi.", true, "Tüy rengi aynı."],
      Aram: ["Tanık", "Pati küçük, benim el değil.", true, ""],
      Rim: ["Tanık", "Pencereyi hava için 08:30'da araladım.", true, ""]
    },
    kanitlar: [
      ["pati", "Pati izi", "4.2 cm, kedi. İnsan parmak 1.8+ değil, yastık izi.", true],
      ["tuy", "Gri tüy", "Zil kablosundaki tüy ile aynı.", true],
      ["aciklik", "Sürgü açıklığı", "8 cm. Çocuk omzu 25 cm, sığmaz."]
    ],
    sorular: [
      ["Rim", "Neden aralık?", "Havalandırma. Kedi beklemiyordum.", "Davet.", "Yusuf açtı.", "a", ""]
    ],
    celiskiler: [
      ["İnsan girdi", "8 cm açıklık", true],
      ["Aram el bastı", "Yastık pati izi", true]
    ],
    soru: "Pati izi kime ait?",
    secenekler: ["Aram elini bastı", "Amara boya ile çizdi", "Komşu kedisi aralıktan girdi", "Yusuf şaka"],
    dogru: "Komşu kedisi aralıktan girdi",
    suc: "Kedi 8 cm aralıktan girdi. İnsan girişi imkânsız.",
    neden: "Ölçü ve tüy zil dosyasına bağlanır. Rim havalandırma için aralamış.",
    ipuclari: ["Açıklık kaç cm?", "Tüy rengi.", "Pati mi parmak mı?"]
  },
  {
    sezon: "4. sezon — Bahçe ve komşu",
    baslik: "Eksik çiçek",
    ozet: "Saksıdan bir lale kopmuş. Kim kopardı?",
    yer: "Bahçe saksısı",
    saat: "Pazar, 10:30",
    tur: "kayip",
    kisiler: {
      Yusuf: ["Tanık", "Koparma düz, makas değil, el. Çocuk bileği.", true, ""],
      Amara: ["Şüpheli", "Lale resim için. Söyledim Rim'e, izin verdi.", true, "Rim başını sallamış."],
      Aram: ["Tanık", "Amara kopardı, vazoya koydu.", true, ""],
      Rim: ["Tanık", "Bir dala izin verdim, hepsine değil. Bir dal eksik, uyumlu.", true, ""]
    },
    kanitlar: [
      ["dal", "Kopuş", "Eğik el kopuşu, makas yüzeyi yok.", true],
      ["vazo", "İç vazo", "Tek lale, Amara'nın masasında, resim yanında.", true],
      ["izin", "Rim notu", "Bir dal tamam, yazmamış ama söz Amara-Rim uyumlu."]
    ],
    sorular: [
      ["Amara", "İzin var mıydı?", "Evet, bir dal.", "Hayır, çaldım.", "Aram kopardı.", "a", ""]
    ],
    celiskiler: [
      ["Çiçek çalındı", "Rim: bir dala izin", true],
      ["Aram kopardı", "Vazo: Amara masası", true]
    ],
    soru: "Lale neden eksik?",
    secenekler: ["Aram kopardı", "Amara izinli bir dal aldı", "Servan bahçeyi kesti", "Kedi yedi"],
    dogru: "Amara izinli bir dal aldı",
    suc: "İzinli koparma. Suç yok. İki ifade örtüşüyor.",
    neden: "Vazo ve resim Amara'da. Rim izin verdiğini söylüyor. Kopuş makas değil. Kedi lale yemez, sapta diş yok.",
    ipuclari: ["İzin sor.", "Vazo nerede?", "Makas izi var mı?"]
  },
  {
    sezon: "4. sezon — Bahçe ve komşu",
    baslik: "Gölge saat",
    ozet: "Bahçe direğindeki gölge Yusuf'un çizimine uymuyor.",
    yer: "Bahçe direği",
    saat: "Pazar, 12:00",
    tur: "zaman",
    kisiler: {
      Yusuf: ["Tanık", "Çizimi 11:00'de yaptım, gölge kısa. Şimdi uzun. Bu normal, güneş döner.", true, ""],
      Amara: ["Tanık", "Direk yer değiştirdi sandım.", false, "Direk betonlu, kıpırdamaz.", ""],
      Aram: ["Tanık", "Gölge yürüdü, korktum.", true, "Çocuk dili."],
      Servan: ["Tanık", "Direği sökmedim.", true, "Beton sağlam."]
    },
    kanitlar: [
      ["cizimg", "11:00 çizimi", "Gölge 40 cm, kuzeybatı.", true],
      ["simdi", "12:00 ölçüm", "Gölge 55 cm, kuzey. Güneş takvimi ile uyumlu.", true],
      ["beton", "Direk kaidesi", "Çatlaksız beton, sökülmemiş."]
    ],
    sorular: [
      ["Yusuf", "Çizim yanlış mı?", "Hayır, bir saat geçmiş.", "Direk kaydı.", "Amara sildi.", "a", ""]
    ],
    celiskiler: [
      ["Amara: direk kaydı", "Beton: sağlam", true],
      ["Çizim sahte", "Güneş takvimi uyumlu", true]
    ],
    soru: "Gölge neden değişti?",
    secenekler: ["Direk söküldü", "Yusuf yanlış çizdi", "Güneş bir saatte döndü", "Amara direği itti"],
    dogru: "Güneş bir saatte döndü",
    suc: "Değişim doğal. Direk yerinde. Çizim saat 11, ölçüm 12.",
    neden: "Beton sağlam. Gölge uzunluğu ve yönü güneş takvimine uyuyor. Amara nesneyi suçlamış.",
    ipuclari: ["İki saat farkı.", "Beton.", "Gölge yönü."]
  }
]
