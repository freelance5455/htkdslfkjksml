export const CASES_A = [
  {
    sezon: "1. sezon — Eski oda",
    baslik: "Kayıp Anahtar",
    ozet: "Evin içindeki eski odanın anahtarı masadan kayboldu.",
    yer: "Aile evi — salon masası ve koridor",
    saat: "Pazar, 18:20",
    tur: "zaman",
    kisiler: {
      Yusuf: ["Tanık", "Anahtarı son kez masada gördüm.", true, "Yusuf saat vermiyor. Son görüş ödev saatinde, 17:30 notu defterde."],
      Amara: ["Şüpheli", "Odaya hiç girmedim.", false, "Kapı kolu yüksekliği Amara'ya uyuyor.", "Amara odaya girmedi der. Sensör 17:51 kaydı var."],
      Aram: ["Tanık", "Amara'yı koridorda gördüm, ama anahtar elinde değildi.", true, "Aram eli boş gördü. Bu, Amara'nın odaya giderken görülmesiyle uyumlu."],
      Rim: ["Tanık", "Anahtarı saat 18:00'de masada gördüm.", false, "Rim'in kol saati 12 dakika ileri.", "Rim 18:00 der. Duvar saati o anda 17:48."],
      Servan: ["Tanık", "Saat 18:00'de masaya baktım, ama anahtar yoktu.", true, "Servan'ın telefon fotoğrafı duvar saatiyle aynı."]
    },
    kanitlar: [
      ["foto", "Servan'ın telefonu", "18:00:02. Masa boş. Arka planda duvar saati 18:00. Fotoğraf değiştirilmemiş.", true],
      ["kolsaat", "Rim'in kol saati", "Duvar saati 17:48 iken kol saati 18:00 gösteriyor. Saat 12 dakika ileri.", true],
      ["sensor", "Eski oda kapı kaydı", "17:51'de kapı 8 saniye açık. Kol yüksekliği 108 cm. Amara'nın uzanmış eli bu boyda. Yusuf 125, Aram 95, yetişkinler 140.", true],
      ["defter", "Yusuf'un defteri", "17:30 — anahtar masada, ödev. 17:50 — Aram koridorda Amara'yı gördü dedi."],
      ["saksi", "Eski odadaki saksı", "Toprak taze karışmış. Yeşil boya lekesi. Altında evin eski oda anahtarı."]
    ],
    sorular: [
      ["Rim", "Saatin kaçtı, nasıl baktın?", "Duvar saatine baktım.", "Kol saatime baktım.", "Yusuf söyledi.", "b", "Rim kol saatine güvenmiş. Saat ileri."],
      ["Amara", "Kapı 17:51'de neden açıldı?", "Açılmadı.", "Merak ettim, bir baktım.", "Aram açtı.", "b", "Amara kısa bakışını kabul ederse izler birleşir."]
    ],
    celiskiler: [
      ["Rim: 18:00'de anahtar masada", "Servan: 18:00'de masa boş", true],
      ["Amara: odaya hiç girmedim", "Sensör: 17:51 kapı açık", true],
      ["Aram: eli boştu", "Yusuf: anahtar masadaydı", false]
    ],
    soru: "Anahtarı kim aldı?",
    secenekler: ["Yusuf", "Amara", "Aram", "Rim", "Servan"],
    dogru: "Amara",
    suc: "Amara anahtarı 17:51'de aldı ve saksıya sakladı.",
    neden: "Rim ile Servan aynı dakikayı anlatmaz: Rim'in saati 12 dakika ileri, o anahtarı 17:48'de gördü. Servan'ın fotoğrafı 18:00'de masayı boş gösterir. Ara zamanda kapı 17:51'de Amara boyuna uygun açıldı. Aram, Amara'yı koridorda eli boş gördü; çünkü Amara odaya henüz girmemişti. Saksıdaki boya ve anahtar izi tamamlar. Çözüm tahmine değil, saat ve yükseklik kanıtına dayanır.",
    ipuclari: [
      "İki kişi 18:00 deyince önce saatlerin aynı olup olmadığına bak.",
      "Kapı kolu yüksekliği kimin boyuna uyuyor?",
      "Eli boş görmek, odaya hiç girmedi demek değildir."
    ]
  },
  {
    sezon: "1. sezon — Eski oda",
    baslik: "Kilitli kapı",
    ozet: "Eski oda içeriden kilitli gibi duruyor. İçeride kimse yok.",
    yer: "Eski oda eşiği",
    saat: "Pazar, 18:40",
    tur: "kapali-oda",
    kisiler: {
      Yusuf: ["Tanık", "Sürgüyü dışarıdan ittim, içeride kimse yoktu. Anahtar deliği boş.", true, "Yusuf sürgünün yönünü doğru tarif ediyor."],
      Amara: ["Tanık", "Ben içeride kilitledim sanmıştım. Korktum, çıktım.", false, "Amara içeriden kilitlediğini sanıyor.", "Sürgü dışarıdan kayar model."],
      Aram: ["Tanık", "Kapı tık dedi. Ben salondaydım.", true, "Ses, sürgünün düşmesi."],
      Rim: ["Tanık", "Bu kilit dışarıdan kayar. Anneannem öyle taktırmıştı.", true, "Rim evin eski düzenini bilir."],
      Servan: ["Şüpheli", "Ben kapıyı çekiçle kilitledim, şaka.", false, "Kapıda darbe izi yok.", "Şaka, iz bırakmaz. Darbe yok."]
    },
    kanitlar: [
      ["surgü", "Kayar sürgü", "Sürgü yuvası dışarıda. İçeriden kilitlenemez. Yağ izi taze, dışarıdan kaydırılmış.", true],
      ["delik", "Anahtar deliği", "İçeride anahtar yok. Delik tozlu, son bir saatte anahtar dönmemiş."],
      ["boya", "Kapı kenarı", "Yeşil boya sürgü yanında. Amara çıkarken değmiş.", true]
    ],
    sorular: [
      ["Rim", "Bu kilit nasıl çalışır?", "İçeriden çevrilir.", "Dışarıdan kayar.", "Otomatik kapanır.", "b", "Eski sürgü dışarıdan."]
    ],
    celiskiler: [
      ["Amara: içeriden kilitledim", "Sürgü: dışarıda", true],
      ["Servan: çekiçle kilitledim", "Kapı: darbe izi yok", true],
      ["Yusuf: içeride kimse yok", "Aram: tık sesi", false]
    ],
    soru: "Kapı neden kilitli gibi duruyor?",
    secenekler: ["İçeride biri var", "Sürgü dışarıdan kaymış", "Servan çekiçle kapadı", "Anahtar içeride kırıldı"],
    dogru: "Sürgü dışarıdan kaymış",
    suc: "Kapı içeriden kilitli değil. Amara çıkınca sürgü dışarıdan kaymış.",
    neden: "Sürgü yuvası dışarıda. İçeriden kilit imkânsız. Servan'ın çekiç şakası darbe izi olmadığı için düşer. Amara korkup çıkmış, sürgü kendi yuvasına kaymış. Kapalı oda yanılsaması.",
    ipuclari: [
      "Kilit hangi yönde takılı?",
      "Darbe izi var mı?",
      "İçeride anahtar dönmüş mü?"
    ]
  },
  {
    sezon: "1. sezon — Eski oda",
    baslik: "Sahte not",
    ozet: "Masada 'anahtarı Yusuf aldı' yazan bir not var.",
    yer: "Salon masası",
    saat: "Pazar, 19:00",
    tur: "sahte-mesaj",
    kisiler: {
      Yusuf: ["Mağdur", "Ben yazmadım. Yazım sağa yatık, bu dik.", true, "Yusuf'un defteri sağa yatık."],
      Amara: ["Şüpheli", "Notu Rim yazdı, anne yazısı.", false, "Rim arşivde dik ama bu çocuk boyu baskı.", "Mürekkep Amara'nın keçe kalemi."],
      Aram: ["Tanık", "Amara kâğıdı katladı. Ben gördüm.", true, "Aram kat izini gördü."],
      Rim: ["Tanık", "Ben not yazmam, etiket yazarım.", true, "Rim'in arşiv yazısı basılı harf."],
      Servan: ["Tanık", "Notu görünce Yusuf'a kızdım. Acele ettim.", true, "Servan varsaymış, yazmamış."]
    },
    kanitlar: [
      ["murekkep", "Keçe kalem", "Mor keçe. Sadece Amara'nın kutusunda var. Yusuf mavi tükenmez kullanır.", true],
      ["yazi", "Yazı eğimi", "Harfler dik ve büyük. Yusuf'un defteri 12 derece sağa yatık.", true],
      ["kat", "Kat izi", "Kâğıt iki kez küçük elle katlanmış. Yetişkin katı daha geniş olur."]
    ],
    sorular: [
      ["Amara", "Mor kalem nerede?", "Yusuf'ta.", "Kutumda.", "Yok.", "b", "Kalem Amara'da."]
    ],
    celiskiler: [
      ["Not: Yusuf aldı", "Yazı: Yusuf'un eğimi değil", true],
      ["Amara: Rim yazdı", "Mürekkep: mor keçe", true],
      ["Servan: Yusuf'a kızdım", "Rim: etiket yazarım", false]
    ],
    soru: "Sahte notu kim yazdı?",
    secenekler: ["Yusuf", "Amara", "Aram", "Rim", "Servan"],
    dogru: "Amara",
    suc: "Amara, suçu Yusuf'a atmak için not yazdı.",
    neden: "Yazı Yusuf'un eğimine uymaz. Mor keçe yalnızca Amara'da. Kat izi küçük el. Rim basılı harf yazar. Not, anahtar dosyasını saptırmak için.",
    ipuclari: [
      "Kalem rengi kime ait?",
      "Yazı eğimini defterle karşılaştır.",
      "Kim saptırmak ister?"
    ]
  },
  {
    sezon: "1. sezon — Eski oda",
    baslik: "Toz haritası",
    ozet: "Eski odanın tozunda ayak izi var. Kim girdi?",
    yer: "Eski oda tabanı",
    saat: "Pazar, 19:30",
    tur: "eslestirme",
    kisiler: {
      Yusuf: ["Tanık", "Ben eşiğe kadar geldim, içeri basmadım.", true, "Eşikte durma izi var, içeride yok."],
      Amara: ["Şüpheli", "Çorapla girdim, iz bırakmam.", false, "Çorap da tozda kumaş izi bırakır.", "Tozda 18 numara kumaş izi."],
      Aram: ["Tanık", "Benim terliğim kırmızı. İçeride kırmızı yok.", true, "Aram doğru ayırıyor."],
      Rim: ["Tanık", "Sabah süpürecektim. Toz dün akşamdan.", true, "Toz katmanı tek, yeni süpürülmemiş."]
    },
    kanitlar: [
      ["iz", "Kumaş izi", "18 numara, kumaş dokusu. Amara'nın çorap kalıbı ile aynı.", true],
      ["esik", "Eşik izi", "Yusuf'un 32 numara ayakkabısı eşikte duruyor, içeride yok.", true],
      ["kirmizi", "Kırmızı terlik", "Aram'ın terliği salonda. Odada kırmızı elyaf yok."]
    ],
    sorular: [
      ["Amara", "Çorap iz bırakır mı?", "Hayır.", "Evet, doku bırakır.", "Sadece ıslaksa.", "b", "Toz, dokuyu alır."]
    ],
    celiskiler: [
      ["Amara: iz bırakmam", "Toz: 18 numara kumaş", true],
      ["Yusuf: içeri basmadım", "Eşik: 32 numara durmuş", false]
    ],
    soru: "Tozdaki iz kime ait?",
    secenekler: ["Yusuf", "Amara", "Aram", "Rim"],
    dogru: "Amara",
    suc: "İçeri giren Amara. Çorap izi onun kalıbı.",
    neden: "Yusuf eşikte kalmış. Aram'ın kırmızı terliği odada yok. Rim süpürmemiş, tek katman toz. 18 numara kumaş = Amara.",
    ipuclari: [
      "Numaraları ayır.",
      "Çorap iz bırakmaz demek yanlış olabilir.",
      "Eşik ile iç zemin ayrı bak."
    ]
  },
  {
    sezon: "1. sezon — Eski oda",
    baslik: "Saksı sırrı",
    ozet: "Anahtar saksıdan çıktı. Kim toprağı karıştırdı?",
    yer: "Eski oda — pencere önü",
    saat: "Pazar, 19:50",
    tur: "kanit-eslesme",
    kisiler: {
      Yusuf: ["Tanık", "Saksıyı çekmedim. Deftere çizdim, toprak yerindeydi.", true, "Çizimde toprak düz."],
      Amara: ["Şüpheli", "Çiçeği suladım, o kadar.", false, "Sulama izi yok, toprak kuru üstte, altta ıslak değil.", "Sulama değil, kazı izi."],
      Aram: ["Tanık", "Kürek yok. Amara kaşık aldı mutfaktan.", true, "Mutfakta eksik tatlı kaşığı."],
      Servan: ["Tanık", "Bahçe küreği balkonunda. Kullanılmamış.", true, "Kürek temiz."]
    },
    kanitlar: [
      ["kasik", "Tatlı kaşığı", "Toprak bulaşık. Amara'nın boya kutusunun yanında.", true],
      ["toprak", "Kazı izi", "Dar ve sığ. Kaşık genişliği 3 cm. Kürek 8 cm.", true],
      ["cizim", "Yusuf çizimi", "19:10'da toprak düz. Sonra bozulmuş."]
    ],
    sorular: [
      ["Aram", "Kaşık nerede?", "Mutfakta.", "Boya kutusunun yanında.", "Bahçede.", "b", "Kaşık Amara'nın yanında."]
    ],
    celiskiler: [
      ["Amara: suladım", "Toprak: üst kuru, kazı izi", true],
      ["Servan: kürek balkonunda", "Kürek: temiz", false]
    ],
    soru: "Toprağı kim kazıdı?",
    secenekler: ["Yusuf", "Amara", "Aram", "Servan"],
    dogru: "Amara",
    suc: "Amara anahtarı kaşıkla gömdü.",
    neden: "Sulama yok. Kazı kaşık genişliğinde. Kürek temiz. Yusuf'un çiziminde toprak daha önce düz.",
    ipuclari: [
      "Sulama ile kazı farklı iz bırakır.",
      "Hangi alet genişliği uyuyor?",
      "Çizim zamanı ne diyor?"
    ]
  },
  {
    sezon: "1. sezon — Eski oda",
    baslik: "Üç saat",
    ozet: "Duvar saati, kol saati ve fırın saati üç farklı zaman gösteriyor.",
    yer: "Mutfak ve salon",
    saat: "Pazar, 20:10",
    tur: "zaman",
    kisiler: {
      Yusuf: ["Tanık", "Fırın saati doğru, çünkü akşam yemeği 19:00'da çıktı, biz yedik.", true, "Yemek zamanı fırınla uyumlu."],
      Amara: ["Tanık", "Hepsi yanlış. Benim tablet 20:10.", true, "Tablet internet saati."],
      Rim: ["Tanık", "Kol saatim doğru olmalı, dün kurdum.", false, "Dün kurarken 12 dakika ileri bırakmış.", "Servis notu: ileri kalıyor."],
      Servan: ["Tanık", "Duvar saatini ben kurdum, elektrik kesilince durmuştu, akşama aldım.", true, "Duvar saati elektrik sonrası doğru."]
    },
    kanitlar: [
      ["firin", "Fırın saati", "20:10. Yemek 19:00'da bitti notu Rim'in tarif defterinde.", true],
      ["tablet", "Amara'nın tableti", "Otomatik ağ saati 20:10. Uçuş modu kapalı.", true],
      ["elektrik", "Sayaç kaydı", "Kesinti 16:02-16:18. Duvar saati sonra 16:18'e alınmış."]
    ],
    sorular: [
      ["Rim", "Kol saatini neye göre kurdun?", "Duvar saatine.", "Telefonuma.", "Tahminen.", "a", "Duvar o an durmuş olabilirdi."]
    ],
    celiskiler: [
      ["Rim: kol saatim doğru", "Tablet ve fırın: 12 dakika fark", true],
      ["Yusuf: fırın doğru", "Tablet: 20:10", false]
    ],
    soru: "Hangi saat doğru?",
    secenekler: ["Rim'in kol saati", "Fırın ve tablet", "Hiçbiri", "Yalnız duvar saati"],
    dogru: "Fırın ve tablet",
    suc: "Doğru saat 20:10. Kol saat 12 dakika ileri.",
    neden: "Birinci dosyadaki 18:00 çelişkisi de buradan gelir. Fırın yemekle, tablet ağla uyumlu. Kol saat dün duvara göre kurulmuş, duvar o sıra kaymış olabilir; ölçüm şimdi 12 dakika ileri.",
    ipuclari: [
      "İnternet saati bağımsız kaynaktır.",
      "Yemek saati hangi cihaza bağlı?",
      "Birinci dosyadaki 12 dakikayı unutma."
    ]
  },
  {
    sezon: "1. sezon — Eski oda",
    baslik: "Eksik sayfa",
    ozet: "Yusuf'un defterinden bir yaprak koparılmış.",
    yer: "Yusuf'un odası",
    saat: "Pazar, 20:40",
    tur: "eksik-bilgi",
    kisiler: {
      Yusuf: ["Mağdur", "Sayfa 17:51 notumdu. Koparan ben değilim.", true, "Yırtık kenar sağ el, Yusuf solak."],
      Amara: ["Şüpheli", "Deftere bakmadım.", false, "Parmak ucunda kâğıt tüyü.", "Yırtık sağ el izi Amara."],
      Aram: ["Tanık", "Amara defteri kapattı, 'görme' dedi.", true, "Aram kısa ve net."],
      Rim: ["Tanık", "Yırtık kâğıdı mutfak çöpünde gördüm, okumadım.", true, "Çöp saati 20:22."]
    },
    kanitlar: [
      ["yirtik", "Defter kenarı", "Sağ el yırtığı. Yusuf solak, yırtarsa ters elyaf.", true],
      ["cop", "Çöp kâğıdı", "Yazı: 17:51 Amara kapı. Yeşil boya bulaşık.", true],
      ["tüy", "Amara'nın parmağı", "Kâğıt tüyü ve boya."]
    ],
    sorular: [
      ["Yusuf", "Hangi elinle yazarsın?", "Sol.", "Sağ.", "İkisi.", "a", "Solak yırtık uyumsuz."]
    ],
    celiskiler: [
      ["Amara: bakmadım", "Aram: defteri kapattı", true],
      ["Yusuf: koparan ben değilim", "Yırtık: sağ el", false]
    ],
    soru: "Sayfayı kim kopardı?",
    secenekler: ["Yusuf", "Amara", "Aram", "Rim"],
    dogru: "Amara",
    suc: "Amara, 17:51 notunu gizlemek için sayfayı kopardı.",
    neden: "Yusuf solak. Yırtık sağ el. Çöpteki yazı tam o saati anlatıyor. Aram gördü.",
    ipuclari: [
      "Solak mı sağlak mı?",
      "Çöpteki yazı ne diyor?",
      "Kim 'görme' der?"
    ]
  },
  {
    sezon: "1. sezon — Eski oda",
    baslik: "Resimdeki kapı",
    ozet: "Amara bir resim çizmiş. Kapı açık mı, kapalı mı?",
    yer: "Amara'nın odası",
    saat: "Pazar, 21:00",
    tur: "kod",
    kisiler: {
      Yusuf: ["Tanık", "Resimde kapı sarı çizgi. Sarı onda açık demek.", true, "Amara'nın renk kodu defter kenarında."],
      Amara: ["Tanık", "Sarı mutluluk. Kapı kapalı.", false, "Kendi kod tablosu sarı=açık.", "Tablo ile ifade çelişir."],
      Aram: ["Tanık", "Ben kırmızı korku diye biliyorum. Resimde kırmızı örümcek var.", true, "Amara korkup çıkmış olabilir."],
      Rim: ["Tanık", "Renk kodunu birlikte yaptık. Sarı açık, mavi kapalı.", true, "Rim kodu doğrular."]
    },
    kanitlar: [
      ["tablo", "Renk tablosu", "Sarı: açık. Mavi: kapalı. Kırmızı: korku.", true],
      ["resim", "Resim", "Kapı sarı, odada kırmızı örümcek, saksı yeşil.", true],
      ["tarih", "Köşe tarihi", "17:55. Sensörden dört dakika sonra."]
    ],
    sorular: [
      ["Amara", "Sarı ne demek?", "Mutluluk.", "Açık.", "Kapalı.", "b", "Tablo sarı=açık."]
    ],
    celiskiler: [
      ["Amara: kapı kapalı", "Tablo: sarı=açık", true],
      ["Yusuf: sarı açık", "Rim: sarı açık", false]
    ],
    soru: "Resim ne anlatıyor?",
    secenekler: ["Kapı kapalıydı", "Kapı açıktı ve Amara korktu", "Örümcek yoktu", "Yusuf çizdi"],
    dogru: "Kapı açıktı ve Amara korktu",
    suc: "Resim, Amara'nın açık kapıyı görüp korkmasını anlatır.",
    neden: "Aile renk kodu yazılı. Sarı kapı = açık. Kırmızı örümcek = korku. Tarih 17:55, girişten hemen sonra. İfade değil, kod çözümü.",
    ipuclari: [
      "Rengi tahmin etme, tabloya bak.",
      "Tarih hangi kanıta yakın?",
      "Kırmızı neye karşılık?"
    ]
  },
  {
    sezon: "1. sezon — Eski oda",
    baslik: "Oyuncak tanık",
    ozet: "Aram'ın tahta arabası eski odada. Kim götürdü?",
    yer: "Eski oda köşesi",
    saat: "Pazar, 21:20",
    tur: "sira",
    kisiler: {
      Yusuf: ["Tanık", "Arabayı salonda 17:20'de gördüm.", true, "Defter notu var."],
      Amara: ["Şüpheli", "Aram kendi götürdü.", false, "Aram o saatte mutfakta süt içiyordu.", "Süt bardağı 17:50 bulaşıkta, Aram boyu."],
      Aram: ["Tanık", "Arabam salondaydı. Ben götürmedim.", true, "Aram oyuncağını kaybedince panikler, ama yalanı sevmez."],
      Servan: ["Tanık", "Odaya 18:40'ta girdim, araba zaten oradaydı.", true, "İkinci dosyadaki giriş saati."]
    },
    kanitlar: [
      ["araba", "Tahta araba", "Üstünde yeşil boya parmak. Amara.", true],
      ["sut", "Süt bardağı", "17:50 civarı bulaşık. Aram'ın ağız izi. O sırada mutfakta.", true],
      ["halı", "Salon halısı", "Araba teker izi koridora kadar, sonra kalkmış: taşınmış."]
    ],
    sorular: [
      ["Aram", "Süt içerken araba neredeydi?", "Yanımda.", "Salonda.", "Odada.", "b", "Araba salonda kalmış."]
    ],
    celiskiler: [
      ["Amara: Aram götürdü", "Süt: Aram mutfakta", true],
      ["Yusuf: 17:20 salonda", "Servan: 18:40 odada", false]
    ],
    soru: "Arabayı kim götürdü?",
    secenekler: ["Yusuf", "Amara", "Aram", "Servan"],
    dogru: "Amara",
    suc: "Amara, odaya girerken arabayı da götürdü.",
    neden: "Aram süt içerken mutfakta. Teker izi koridorda kesiliyor: biri kaldırmış. Yeşil boya Amara. Servan arabayı odada hazır bulmuş.",
    ipuclari: [
      "Aram o anda başka yerde miydi?",
      "Teker izi neden kesilir?",
      "Boya kime ait?"
    ]
  },
  {
    sezon: "1. sezon — Eski oda",
    baslik: "Arşiv kartı",
    ozet: "Rim'in arşiv kartında eski oda 'mühürlü' yazıyor. Kart kimde kalmış?",
    yer: "Çalışma odası",
    saat: "Pazartesi, 08:10",
    tur: "mantik",
    kisiler: {
      Yusuf: ["Tanık", "Kartı dün gece masada gördüm.", true, "21:40 notu."],
      Amara: ["Tanık", "Kartı okudum, 'mühürlü' kelimesini sildim sanmıştım. Silgi izi yok.", true, "Amara denemiş ama kâğıt cilalı, silinmez."],
      Rim: ["Mağdur", "Kart çantamda olmalı. Çanta boş.", true, "Çanta cebi boş, astar sağlam."],
      Servan: ["Şüpheli", "Kartı işe götürdüm, resmi iş.", false, "Kart ev arşivi, iş logosu yok.", "Ceket cebinde ev kartı, iş kartı ayrı."]
    },
    kanitlar: [
      ["kart", "Arşiv kartı", "Ceket iç cebinde. Ev basımı. 'Mühürlü — anneanne odası'.", true],
      ["canta", "Rim'in çantası", "Cep boş. Yırtık yok. Düşmemiş, alınmış."],
      ["logo", "İş kartı", "Servan'ın iş kartı cüzdanda. Karıştırmış."]
    ],
    sorular: [
      ["Servan", "Bu kart iş kartı mı?", "Evet.", "Hayır, ev kartı, karıştırdım.", "Yusuf koydu.", "b", "Karışıklık itirafı."]
    ],
    celiskiler: [
      ["Servan: resmi iş", "Kart: ev basımı, logo yok", true],
      ["Amara: sildim sandım", "Kart: silgi izi yok", false]
    ],
    soru: "Kart şu an kimin cebinde, neden?",
    secenekler: ["Yusuf sakladı", "Amara sildi", "Rim kaybetti", "Servan karıştırıp aldı"],
    dogru: "Servan karıştırıp aldı",
    suc: "Servan ev kartını iş kartı sanıp cebine koydu.",
    neden: "Çanta yırtılmamış. Kart ev basımı. İş kartı cüzdanda ayrı. Amara silememiş. Dün gece masada olan kart sabah cekette.",
    ipuclari: [
      "İki kart var mı?",
      "Çanta yırtık mı, alınmış mı?",
      "Logo var mı?"
    ]
  }
]
