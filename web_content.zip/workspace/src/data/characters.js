export const CHARACTERS = {
  Yusuf: {
    id: "Yusuf",
    ad: "Yusuf",
    yas: 10,
    rol: "Büyük kardeş",
    oz: "Keskin gözlü, ciddi ve meraklı. Küçük detayları unutmaz.",
    gecmis: "Okul gazetesinde haber yazıyor. Yalanı sevmez, not defteri taşır.",
    ses: "Kısa ve net konuşur. Kanıt ister.",
    renk: "#3d5a80"
  },
  Amara: {
    id: "Amara",
    ad: "Amara",
    yas: 8,
    rol: "Orta kız kardeş",
    oz: "Hayal gücü kuvvetli, duygusal ve zeki. Renkleri ve kokuları hatırlar.",
    gecmis: "Resim yapmayı sever. Sırları bazen masal gibi anlatır.",
    ses: "Soru sorarak konuşur. Bazen abartır, ama gördüğünü unutmaz.",
    renk: "#7a3b4a"
  },
  Aram: {
    id: "Aram",
    ad: "Aram",
    yas: 6,
    rol: "Küçük kardeş",
    oz: "Dürüst, ürkek ve oyuncu. Büyüklerin dilini tam kavramaz.",
    gecmis: "Oyuncaklarını kaybettiğinde panikler. Saatleri karıştırır.",
    ses: "Kısa cümleler. Bazen konuyu dağıtır.",
    renk: "#3f6b4a"
  },
  Rim: {
    id: "Rim",
    ad: "Rim",
    yas: 30,
    rol: "Anne",
    oz: "Sakin, dikkatli ve koruyucu. Evdeki düzeni bilir.",
    gecmis: "Arşivde çalışır. Belgeleri ve saatleri ezbere bilir.",
    ses: "Nazik ama kesin. Aileyi korumak ister.",
    renk: "#5c3d6e"
  },
  Servan: {
    id: "Servan",
    ad: "Servan",
    yas: 30,
    rol: "Baba",
    oz: "Pratik, yorgun ve esprili. Acele eder, ayrıntıyı atlar.",
    gecmis: "Gece vardiyasında çalışır. Anahtarları ceket cebinde taşır.",
    ses: "Rahat konuşur. Bazen şaka yapar, bazen kaçar.",
    renk: "#2c3a4a"
  }
}
