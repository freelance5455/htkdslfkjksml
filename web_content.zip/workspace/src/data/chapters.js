import { expand } from "./expand.js"
import { CASES_A } from "./cases-a.js"
import { CASES_B } from "./cases-b.js"
import { CASES_C } from "./cases-c.js"
import { CASES_D } from "./cases-d.js"
import { CASES_E } from "./cases-e.js"
import { CASES_F } from "./cases-f.js"

export const CHAPTERS = expand([
  ...CASES_A,
  ...CASES_B,
  ...CASES_C,
  ...CASES_D,
  ...CASES_E,
  ...CASES_F
])
