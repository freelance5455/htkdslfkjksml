const KEY = "son-dedektif-v2"

const bos = () => ({
  biten: [],
  yildiz: {},
  puan: 0,
  oduller: [],
  ayar: {
    ses: true,
    yazi: 1,
    titreşim: true,
    dil: "tr",
    zorluk: "kolay",
    renkli: true
  },
  isim: "Dedektif"
})

export function yukle() {
  try {
    const raw = localStorage.getItem(KEY) || localStorage.getItem("son-dedektif-v1")
    if (!raw) return bos()
    const old = JSON.parse(raw)
    const s = bos()
    return {
      ...s,
      ...old,
      ayar: { ...s.ayar, ...(old.ayar || {}) }
    }
  } catch {
    return bos()
  }
}

export function kaydet(s) {
  localStorage.setItem(KEY, JSON.stringify(s))
}
