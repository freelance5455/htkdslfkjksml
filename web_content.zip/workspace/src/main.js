import { CHARACTERS } from "./data/characters.js"
import { CHAPTERS } from "./data/chapters.js"
import { ACHIEVEMENTS } from "./data/achievements.js"
import { avatarSvg } from "./avatars.js"
import { yukle, kaydet } from "./storage.js"
import { t } from "./i18n.js"
import { DIFF, denemeSayisi, ozelMi } from "./difficulty.js"

const app = document.getElementById("app")
let state = yukle()
let oyun = null
let ekran = "splash"
let toastT = 0
let sezonFiltre = "hepsi"
let parti = { adlar: ["Yusuf", "Amara"], puan: {}, dogru: {}, yanlis: {}, sira: 0 }

const HAZIR = ["Yusuf", "Amara", "Aram", "Rim", "Servan"]
const svg = {
  back: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>`,
  file: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><path d="M14 2v6h6"/></svg>`,
  users: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>`,
  book: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>`,
  star: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l3 7h7l-5.5 4.5L18 21l-6-4-6 4 1.5-7.5L2 9h7z"/></svg>`,
  medal: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="6"/><path d="M8.2 13.5L7 22l5-2 5 2-1.2-8.5"/></svg>`,
  gear: `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9c.3.6.9 1 1.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/></svg>`,
  eye: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>`,
  chat: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>`,
  bag: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>`,
  alert: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>`,
  gavel: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 13l7 7M3 14l7-7 4 4-7 7z"/><path d="M14 7l3-3 3 3-3 3z"/></svg>`
}

const lang = () => state.ayar.dil || "tr"
const T = (key, ...args) => t(lang(), key, ...args)

function applyDoc() {
  const packLang = lang()
  document.documentElement.lang = packLang === "ar" ? "ar" : "tr"
  document.documentElement.dir = packLang === "ar" ? "rtl" : "ltr"
  document.documentElement.classList.toggle("classic", !state.ayar.renkli)
  document.documentElement.style.setProperty("--text-scale", String(state.ayar.yazi || 1))
  document.title = T("title")
  const theme = document.querySelector('meta[name="theme-color"]')
  if (theme) theme.setAttribute("content", state.ayar.renkli ? "#1a1030" : "#07090f")
}

function titre() {
  if (state.ayar.titreşim && navigator.vibrate) navigator.vibrate(12)
}

function toast(msg) {
  const el = document.getElementById("toast")
  if (!el) return
  el.textContent = msg
  el.classList.add("show")
  clearTimeout(toastT)
  toastT = setTimeout(() => el.classList.remove("show"), 2200)
}

function save() { kaydet(state) }

function acikMi(ch) {
  if (!ch.kilit) return true
  return state.biten.includes(ch.id - 1)
}

function zorlukAcik(id) {
  return state.biten.length >= (DIFF[id] || DIFF.kolay).gerek
}

function yildizYaz(n) {
  return "★".repeat(n) + "☆".repeat(Math.max(0, 3 - n))
}

function langBar() {
  const l = lang()
  return `<div class="lang-switch">
    <button class="${l === "tr" ? "on" : ""}" data-act="dil-tr">TR</button>
    <button class="${l === "ar" ? "on" : ""}" data-act="dil-ar">AR</button>
  </div>`
}

function yeniOyun(chId, arkadas) {
  const ch = CHAPTERS.find(c => c.id === chId)
  const deneme = denemeSayisi(state.ayar.zorluk, chId)
  oyun = {
    ch,
    tab: "ozet",
    bulunan: [],
    konusulan: [],
    sorulan: {},
    celiskiSec: [],
    ipucuIdx: -1,
    ipucuKullan: 0,
    karar: null,
    bitirildi: false,
    arkadas: arkadas || null,
    sira: arkadas ? parti.sira : 0,
    kisi: null,
    kanit: null,
    yildiz: 0,
    deneme,
    denemeMax: deneme,
    zorlaAc: false
  }
  ekran = "vaka"
  render()
}

function aktifOyuncu() {
  if (!oyun || !oyun.arkadas) return state.isim
  return oyun.arkadas[oyun.sira % oyun.arkadas.length]
}

function partiPuan(ad, n, dogruMu) {
  if (!oyun || !oyun.arkadas) return
  parti.puan[ad] = (parti.puan[ad] || 0) + n
  if (dogruMu === true) parti.dogru[ad] = (parti.dogru[ad] || 0) + 1
  if (dogruMu === false) parti.yanlis[ad] = (parti.yanlis[ad] || 0) + 1
}

function puanEkle(n, dogruMu) {
  const carpim = (DIFF[state.ayar.zorluk] || DIFF.kolay).carpim
  const v = Math.round(n * carpim)
  state.puan += v
  partiPuan(aktifOyuncu(), v, dogruMu)
  save()
  return v
}

function odul(id) {
  if (!state.oduller.includes(id)) {
    state.oduller.push(id)
    save()
    const a = ACHIEVEMENTS.find(x => x.id === id)
    if (a) toast(T("ach") + ": " + (a.ad[lang()] || a.ad.tr))
  }
}

function bitirKontrol() {
  ACHIEVEMENTS.forEach(a => { if (a.kosul(state)) odul(a.id) })
}

function hesaplaYildiz() {
  let y = 1
  if (oyun.karar === oyun.ch.gercek.fail) y = 2
  const gerekli = oyun.ch.gercek.kanitlar
  const hepsi = !gerekli.length || gerekli.every(k => oyun.bulunan.includes(k))
  const dogruCel = oyun.ch.celiskiler.filter(c => c.dogru)
  const celiskiOk = dogruCel.length === 0 || dogruCel.every(c => oyun.celiskiSec.includes(c.id))
  if (oyun.karar === oyun.ch.gercek.fail && hepsi && celiskiOk && oyun.ipucuKullan === 0) y = 3
  else if (oyun.karar === oyun.ch.gercek.fail && hepsi && celiskiOk) y = 3
  if (oyun.ipucuKullan === 0 && y >= 2) odul("ipucu0")
  if (hepsi) odul("keskin")
  if (celiskiOk) odul("celiski")
  if (oyun.karar === oyun.ch.gercek.fail) odul("adil")
  return y
}

function topbar(baslik, geri) {
  return `<div class="topbar">
    <button class="icon-btn" data-act="${geri}">${svg.back}</button>
    <h2>${baslik}</h2>
    ${langBar()}
  </div>`
}

function menuEkran() {
  return `<section class="screen active">
    <div class="hero">
      <div class="float-lang">${langBar()}</div>
      <div class="stamp">${T("stamp1")}<br>${T("stamp2")}</div>
      <div class="badge">${T("bureau")}</div>
      <h1>${T("splashName")}</h1>
      <p>${T("heroP")}</p>
    </div>
    <div class="scroll">
      <div class="menu">
        <button class="btn gold" data-act="yeni"><span class="ico">${svg.file}</span><span>${T("newGame")}<small>${T("newGameSub")}</small></span></button>
        <button class="btn" data-act="arkadas"><span class="ico">${svg.users}</span><span>${T("friends")}<small>${T("friendsSub")}</small></span></button>
        <button class="btn" data-act="bolumler"><span class="ico">${svg.book}</span><span>${T("chapters")}<small>${T("chaptersSub")}</small></span></button>
        <button class="btn" data-act="puan"><span class="ico">${svg.star}</span><span>${T("scores")}<small>${state.puan} ${T("points")}</small></span></button>
        <button class="btn" data-act="basarim"><span class="ico">${svg.medal}</span><span>${T("achievements")}<small>${state.oduller.length}/${ACHIEVEMENTS.length} ${T("openN")}</small></span></button>
        <button class="btn" data-act="ayar"><span class="ico">${svg.gear}</span><span>${T("settings")}<small>${T("settingsSub")}</small></span></button>
      </div>
    </div>
  </section>`
}

function bolumEkran() {
  const sezonlar = [...new Set(CHAPTERS.map(c => c.sezon))]
  const filtre = sezonFiltre === "hepsi" ? CHAPTERS : CHAPTERS.filter(c => c.sezon === sezonFiltre)
  let sezon = ""
  const chips = `<div class="chips">
    <button class="pill ${sezonFiltre === "hepsi" ? "sel" : ""}" data-sezon="hepsi">${T("all")} (${CHAPTERS.length})</button>
    ${sezonlar.map((s, i) => `<button class="pill ${sezonFiltre === s ? "sel" : ""}" data-sezon="${s}">${i + 1}. ${T("season")}</button>`).join("")}
  </div>`
  const list = filtre.map(c => {
    const acik = acikMi(c)
    const y = state.yildiz[c.id] || 0
    let head = ""
    if (c.sezon && c.sezon !== sezon) {
      sezon = c.sezon
      head = `<div class="badge" style="margin:8px 0 4px">${sezon}</div>`
    }
    const ozel = ozelMi(c.id) ? `<span class="tag special-tag">${T("special")}</span>` : ""
    return `${head}<button class="chapter ${acik ? "" : "locked"}" data-ch="${c.id}" ${acik ? "" : "disabled"}>
      <div class="ch-num">${c.id}</div>
      <div style="flex:1">
        <strong>${c.baslik}</strong> ${ozel}
        <div class="muted" style="font-size:.85rem">${acik ? c.ozet : T("prevFile")}</div>
        <div class="stars">${acik ? yildizYaz(y) : "🔒"}</div>
      </div>
    </button>`
  }).join("")
  return `<section class="screen active">
    ${topbar(T("chapters"), "menu")}
    <div class="scroll" style="display:grid;gap:10px">${chips}${list}</div>
  </section>`
}

function puanEkran() {
  const max = CHAPTERS.length * 120
  const pct = Math.min(100, Math.round((state.puan / Math.max(1, max)) * 100))
  return `<section class="screen active">
    ${topbar(T("scores"), "menu")}
    <div class="scroll">
      <div class="card" style="text-align:center">
        <div class="badge">${T("total")}</div>
        <h2 class="result-title">${state.puan}</h2>
        <p class="muted">${T("scoreNote")}</p>
        <div class="progress" style="margin-top:12px"><span style="width:${pct}%"></span></div>
      </div>
      <div class="card" style="margin-top:12px">
        <h3>${T("fileNotes")}</h3>
        ${CHAPTERS.map(c => `<div class="row space" style="padding:8px 0;border-bottom:1px solid rgba(212,175,106,.12)">
          <span>${c.id}. ${c.baslik}</span><span class="stars">${yildizYaz(state.yildiz[c.id] || 0)}</span>
        </div>`).join("")}
      </div>
    </div>
  </section>`
}

function basarimEkran() {
  const list = ACHIEVEMENTS.map(a => {
    const on = state.oduller.includes(a.id) || a.kosul(state)
    return `<div class="ach ${on ? "" : "off"}">
      <div class="ch-num">${on ? "★" : "○"}</div>
      <div><strong>${a.ad[lang()] || a.ad.tr}</strong><div class="muted">${a.aciklama[lang()] || a.aciklama.tr}</div></div>
    </div>`
  }).join("")
  return `<section class="screen active">${topbar(T("achievements"), "menu")}<div class="scroll">${list}</div></section>`
}

function ayarEkran() {
  const z = state.ayar.zorluk
  const diffs = [
    ["kolay", "easy", "easyHint"],
    ["orta", "medium", "mediumHint"],
    ["zor", "hard", "hardHint"],
    ["uzman", "expert", "expertHint"]
  ]
  return `<section class="screen active">
    ${topbar(T("settings"), "menu")}
    <div class="scroll">
      <div class="card">
        <label class="muted">${T("language")}</label>
        <div style="margin:8px 0 14px">${langBar()}</div>
        <div class="row space" style="margin-bottom:14px">
          <div><strong>${T("vibration")}</strong><div class="muted">${T("vibrationSub")}</div></div>
          <button class="toggle ${state.ayar.titreşim ? "on" : ""}" data-act="titresim"><i></i></button>
        </div>
        <div class="row space" style="margin-bottom:14px">
          <div><strong>${T("color")}</strong><div class="muted">${T("colorOn")}</div></div>
          <button class="toggle ${state.ayar.renkli ? "on" : ""}" data-act="renk"><i></i></button>
        </div>
        <label class="muted">${T("font")}</label>
        <select data-act="yazi" style="margin-top:8px">
          <option value="0.9" ${state.ayar.yazi === 0.9 ? "selected" : ""}>${T("small")}</option>
          <option value="1" ${state.ayar.yazi === 1 ? "selected" : ""}>${T("normal")}</option>
          <option value="1.12" ${state.ayar.yazi === 1.12 ? "selected" : ""}>${T("large")}</option>
        </select>
        <label class="muted" style="display:block;margin-top:14px">${T("detName")}</label>
        <input data-act="isim" value="${state.isim}" maxlength="18" style="margin-top:8px"/>
        <p class="muted" style="margin-top:12px">${T("offline")}</p>
      </div>
      <div class="card" style="margin-top:12px">
        <h3>${T("pickDiff")}</h3>
        ${diffs.map(([id, ad, hint]) => {
          const acik = zorlukAcik(id)
          return `<button class="chapter diff-card ${z === id ? "" : ""} ${acik ? "" : "locked"}" data-zorluk="${id}" ${acik ? "" : "disabled"}>
            <div class="ch-num">${acik ? (z === id ? "★" : "○") : "🔒"}</div>
            <div><strong>${T(ad)}</strong><div class="muted">${acik ? T(hint) : T("lockedDiff")}</div></div>
          </button>`
        }).join("")}
      </div>
    </div>
  </section>`
}

function arkadasEkran() {
  const secili = parti.adlar
  const chips = HAZIR.map(n =>
    `<button class="player-chip ${secili.includes(n) ? "on" : ""}" data-ad="${n}">
      <div class="avatar" style="width:36px;height:36px">${avatarSvg(n, 36)}</div>${n}
    </button>`
  ).join("")
  const extra = secili.filter(n => !HAZIR.includes(n))
  return `<section class="screen active">
    ${topbar(T("friends"), "menu")}
    <div class="scroll">
      <div class="card">
        <h3>${T("friendsTitle")}</h3>
        <p class="muted">${T("friendsP")}</p>
        <div class="muted" style="margin-top:12px">${T("players")} (${secili.length}/5)</div>
        <div style="display:grid;gap:8px;margin-top:8px">${chips}</div>
        ${extra.map(n => `<div class="player-chip on" style="margin-top:8px">${n}<button class="icon-btn" data-sil="${n}" style="margin-inline-start:auto">×</button></div>`).join("")}
        <div class="name-row">
          <input id="yeniad" maxlength="18" placeholder="${T("customName")}"/>
          <button class="btn gold" style="width:auto" data-act="ad-ekle">${T("addPlayer")}</button>
        </div>
        <button class="btn gold" style="margin-top:14px;justify-content:center" data-act="arkadas-basla">${T("startCase")}</button>
      </div>
    </div>
  </section>`
}

function splash() {
  return `<section class="screen active splash">
    <div class="float-lang">${langBar()}</div>
    <div class="logo-mark">${svg.eye}</div>
    <div class="kicker">${T("splashKicker")}</div>
    <h1 style="font-size:2.6rem;margin:.2em 0 .3em">${T("splashName")}</h1>
    <p class="muted">${T("splashSub")}</p>
    <button class="btn gold" style="max-width:280px;margin:28px auto 0;text-align:center;justify-content:center" data-act="menu">${T("enter")}</button>
  </section>`
}

function tabBar() {
  const tabs = [
    ["ozet", svg.file, T("summary")],
    ["kisiler", svg.chat, T("statements")],
    ["kanit", svg.bag, T("evidence")],
    ["celiski", svg.alert, T("clash")],
    ["karar", svg.gavel, T("verdict")]
  ]
  return `<nav class="tabs">${tabs.map(([id, ic, ad]) =>
    `<button class="tab ${oyun.tab === id ? "on" : ""}" data-tab="${id}">${ic}${ad}</button>`
  ).join("")}</nav>`
}

function kalp() {
  let s = ""
  for (let i = 0; i < oyun.denemeMax; i++) s += `<i class="heart ${i < oyun.deneme ? "" : "off"}"></i>`
  return `<div class="lives"><span class="muted">${T("attempts")}</span>${s}</div>`
}

function vakaOzet() {
  const ch = oyun.ch
  const pct = Math.round((oyun.bulunan.length / Math.max(1, ch.kanitlar.length)) * 100)
  const ipucuMetin = oyun.ipucuIdx >= 0 ? ch.ipucuSirasi[Math.min(oyun.ipucuIdx, 2)] : ""
  return `<div class="card">
    <div class="badge">${ch.yer}${ozelMi(ch.id) ? " • " + T("special") : ""}</div>
    <h3>${ch.baslik}</h3>
    <p>${ch.ozet}</p>
    <p class="muted" style="margin-top:8px">${ch.saat}</p>
    <div class="progress" style="margin-top:12px"><span style="width:${pct}%"></span></div>
    <p class="muted" style="margin-top:8px">${oyun.bulunan.length}/${ch.kanitlar.length} ${T("evidenceOf")} • ${oyun.konusulan.length}/${Object.keys(ch.kisiler).length} ${T("stmtOf")}</p>
    ${kalp()}
  </div>
  <div class="card" style="margin-top:12px">
    <h3>${T("detNote")}</h3>
    <p class="muted">${T("detP")}</p>
    <button class="btn" style="margin-top:12px" data-act="ipucu"><span class="ico">?</span> ${T("askHint")} <small>${3 - oyun.ipucuKullan} ${T("hintsLeft")}</small></button>
    ${ipucuMetin ? `<p class="note" style="margin-top:10px">${ipucuMetin}</p>` : ""}
  </div>
  ${oyun.arkadas ? `<div class="card" style="margin-top:12px"><strong>${T("turn")}: ${aktifOyuncu()}</strong><div class="muted">${T("turnHint")}</div>
    <button class="btn ghost" style="margin-top:8px" data-act="sira-bitir">${T("endSession")}</button></div>` : ""}`
}

function vakaKisiler() {
  const ch = oyun.ch
  return Object.keys(ch.kisiler).map(ad => {
    const k = ch.kisiler[ad]
    const c = CHARACTERS[ad] || { yas: "?", rol: k.rol }
    const ok = oyun.konusulan.includes(ad)
    return `<button class="person" data-kisi="${ad}">
      <div class="avatar">${avatarSvg(ad, 54)}</div>
      <div style="flex:1">
        <strong>${ad}</strong> <span class="tag">${k.rol}</span>
        ${ok ? `<span class="clue-dot"></span>` : ""}
        <div class="muted">${T("ageRole", c.yas, c.rol)}</div>
      </div>
    </button>`
  }).join("")
}

function vakaKanit() {
  return `<div class="evidence">${oyun.ch.kanitlar.map(k => {
    const found = oyun.bulunan.includes(k.id)
    return `<button class="ev ${found ? "found" : ""}" data-kanit="${k.id}">
      <div class="ev-art">${found ? T("examined") : T("sealed")}</div>
      <div class="ev-body"><strong>${k.ad}</strong><div class="muted">${found ? T("added") : T("tapExam")}</div></div>
    </button>`
  }).join("")}</div>`
}

function vakaCeliski() {
  const list = oyun.ch.celiskiler.map(c => {
    const sel = oyun.celiskiSec.includes(c.id)
    return `<button class="pill ${sel ? "sel" : ""}" data-cel="${c.id}">${c.a} ↔ ${c.b}</button>`
  }).join("")
  return `<div class="card">
    <h3>${T("clashBoard")}</h3>
    <p class="muted">${T("clashP")}</p>
    <div style="margin-top:10px">${list}</div>
  </div>`
}

function vakaKarar() {
  if (oyun.bitirildi) return sonucKart()
  const ops = oyun.ch.kararSecenek.map(ad => {
    const c = CHARACTERS[ad]
    if (c) {
      return `<button class="person" data-karar="${ad}">
        <div class="avatar">${avatarSvg(ad, 54)}</div>
        <div><strong>${ad}</strong><div class="muted">${c.oz}</div></div>
      </button>`
    }
    return `<button class="choice" data-karar="${ad}">${ad}</button>`
  }).join("")
  return `<div class="card"><h3>${T("verdict")}</h3><p class="muted">${oyun.ch.kararSoru || T("pickVerdict")}</p>${kalp()}</div>
  <div style="display:grid;gap:10px;margin-top:10px">${ops}</div>`
}

function sonucKart() {
  const ok = oyun.karar === oyun.ch.gercek.fail || oyun.zorlaAc
  const y = oyun.yildiz
  return `<div class="card" style="text-align:center">
    <div class="badge">${ok && !oyun.zorlaAc ? T("closed") : T("missed")}</div>
    <h2 class="result-title">${ok && !oyun.zorlaAc ? T("truth") : T("wrongTrack")}</h2>
    <div class="stars" style="font-size:1.4rem;margin:8px 0">${yildizYaz(y)}</div>
    <p>${oyun.ch.gercek.suc}</p>
    <p class="muted" style="margin-top:10px">${oyun.ch.gercek.neden}</p>
    <p style="margin-top:12px">${T("correct")}: <strong>${oyun.ch.gercek.fail}</strong></p>
    <p class="muted">${T("yourCall")}: ${oyun.karar || "—"}</p>
    <button class="btn gold" style="margin-top:16px;justify-content:center" data-act="sonra">${oyun.ch.id < CHAPTERS.length ? T("next") : T("office")}</button>
    <button class="btn ghost" style="margin-top:8px;justify-content:center" data-act="bolumler">${T("chapters")}</button>
  </div>`
}

function siralamaEkran() {
  const adlar = Object.keys(parti.puan)
  const sirali = [...(oyun && oyun.arkadas ? oyun.arkadas : adlar)].sort((a, b) => (parti.puan[b] || 0) - (parti.puan[a] || 0))
  const top = sirali[0]
  const berabere = sirali.length > 1 && (parti.puan[sirali[0]] || 0) === (parti.puan[sirali[1]] || 0)
  const rows = sirali.map((n, i) => `<div class="rank-row ${i === 0 && !berabere ? "win" : ""}">
    <div class="ch-num">${i + 1}</div>
    <div style="flex:1"><strong>${n}</strong>
      <div class="muted">${parti.puan[n] || 0} ${T("pts")} • ${parti.dogru[n] || 0} ${T("correctN")} / ${parti.yanlis[n] || 0} ${T("wrongN")}</div>
    </div>
  </div>`).join("")
  return `<section class="screen active">
    ${topbar(T("ranking"), "menu")}
    <div class="scroll">
      <div class="card" style="text-align:center">
        <div class="badge">${T("sessionOver")}</div>
        <h2 class="result-title">${berabere ? T("draw") : T("winner")}</h2>
        <p>${berabere ? sirali.filter(n => (parti.puan[n] || 0) === (parti.puan[top] || 0)).join(" • ") : top}</p>
      </div>
      <div style="margin-top:12px">${rows}</div>
      <button class="btn gold" style="margin-top:14px;justify-content:center" data-act="arkadas">${T("playAgain")}</button>
      <button class="btn ghost" style="margin-top:8px;justify-content:center" data-act="menu">${T("office")}</button>
    </div>
  </section>`
}

function modalKisi() {
  const ad = oyun.kisi
  if (!ad) return ""
  const k = oyun.ch.kisiler[ad]
  const c = CHARACTERS[ad] || { yas: "?", rol: k.rol, ses: "", oz: "" }
  const q = oyun.ch.sorular.filter(s => s.kim === ad)
  const soruldu = oyun.sorulan[ad]
  return `<div class="modal open" data-act="kapat">
    <div class="sheet" data-stop="1">
      <div class="handle"></div>
      <div class="row" style="gap:12px;margin-bottom:10px">
        <div class="avatar">${avatarSvg(ad, 64)}</div>
        <div><h3>${ad}</h3><div class="muted">${T("ageRole", c.yas, k.rol)}</div><div class="tag">${c.ses || ""}</div></div>
      </div>
      <p class="muted">${c.oz || ""}</p>
      <div class="dialog">
        <div class="quote">“${k.ifade}”</div>
        ${!k.tutarli && oyun.bulunan.length >= 2 ? `<p class="muted" style="margin-top:8px">${k.celiski || k.ipucu}</p>` : `<p class="muted" style="margin-top:8px">${k.ipucu || ""}</p>`}
      </div>
      ${q.length && !soruldu ? `<div class="choices">
        <p class="badge">${T("question")}</p>
        <p>${q[0].soru}</p>
        ${["a", "b", "c"].map(harf => `<button class="choice" data-cevap="${ad}:${harf}">${q[0][harf]}</button>`).join("")}
      </div>` : soruldu ? `<p class="note" style="margin-top:12px">${q[0] ? q[0].yanit : ""}</p>` : ""}
    </div>
  </div>`
}

function modalKanit() {
  const id = oyun.kanit
  if (!id) return ""
  const k = oyun.ch.kanitlar.find(x => x.id === id)
  return `<div class="modal open" data-act="kapat">
    <div class="sheet" data-stop="1">
      <div class="handle"></div>
      <div class="ev-art" style="border-radius:12px;margin-bottom:12px">KANIT #${id.toUpperCase()}</div>
      <h3>${k.ad}</h3>
      <p class="note" style="margin-top:10px">${k.metin}</p>
      <button class="btn gold" style="margin-top:14px;justify-content:center" data-act="kanit-al">${T("addNotes")}</button>
    </div>
  </div>`
}

function vakaEkran() {
  const ch = oyun.ch
  let ic = ""
  if (oyun.tab === "ozet") ic = vakaOzet()
  if (oyun.tab === "kisiler") ic = vakaKisiler()
  if (oyun.tab === "kanit") ic = vakaKanit()
  if (oyun.tab === "celiski") ic = vakaCeliski()
  if (oyun.tab === "karar") ic = vakaKarar()
  return `<section class="screen active">
    ${topbar(ch.baslik, "menu")}
    <div class="scroll">${ic}</div>
    ${tabBar()}
    ${oyun.kisi ? modalKisi() : ""}
    ${oyun.kanit ? modalKanit() : ""}
  </section>`
}

function render() {
  applyDoc()
  let html = `<div class="grain"></div><div class="vignette"></div>`
  if (ekran === "splash") html += splash()
  if (ekran === "menu") html += menuEkran()
  if (ekran === "bolumler") html += bolumEkran()
  if (ekran === "puan") html += puanEkran()
  if (ekran === "basarim") html += basarimEkran()
  if (ekran === "ayar") html += ayarEkran()
  if (ekran === "arkadas") html += arkadasEkran()
  if (ekran === "vaka") html += vakaEkran()
  if (ekran === "siralama") html += siralamaEkran()
  html += `<div class="toast" id="toast"></div>`
  app.innerHTML = html
}

function siradaki() {
  if (!oyun || !oyun.arkadas) return
  oyun.sira = (oyun.sira + 1) % oyun.arkadas.length
  parti.sira = oyun.sira
  toast(T("turn") + ": " + aktifOyuncu())
}

function dosyaKapat(karar, zorla) {
  oyun.karar = karar
  oyun.zorlaAc = !!zorla
  oyun.yildiz = zorla ? 0 : hesaplaYildiz()
  oyun.bitirildi = true
  oyun.tab = "karar"
  const ch = oyun.ch
  const ok = !zorla && karar === ch.gercek.fail
  if (ok && !state.biten.includes(ch.id)) state.biten.push(ch.id)
  if (ok) {
    const eski = state.yildiz[ch.id] || 0
    state.yildiz[ch.id] = Math.max(eski, oyun.yildiz)
  }
  let p = ok ? 50 : 10
  p += oyun.bulunan.length * 6
  p -= oyun.ipucuKullan * ((DIFF[state.ayar.zorluk] || DIFF.kolay).ipucuKesinti)
  puanEkle(Math.max(0, p), ok)
  bitirKontrol()
  save()
  titre()
  render()
}

function kararVer(ad) {
  if (oyun.bitirildi) return
  if (ad === oyun.ch.gercek.fail) {
    dosyaKapat(ad, false)
    return
  }
  oyun.deneme -= 1
  puanEkle(-8, false)
  toast(T("wrongTry") + " (" + oyun.deneme + ")")
  titre()
  if (oyun.deneme <= 0) {
    toast(T("noAttempts"))
    dosyaKapat(ad, true)
    return
  }
  render()
}

function setDil(d) {
  state.ayar.dil = d
  save()
  render()
}

app.addEventListener("click", e => {
  const tEl = e.target.closest("[data-act],[data-tab],[data-ch],[data-kisi],[data-kanit],[data-cel],[data-karar],[data-cevap],[data-sezon],[data-ad],[data-sil],[data-zorluk]")
  if (e.target.closest(".modal") && !e.target.closest("[data-stop]") && e.target.closest("[data-act=kapat]")) {
    if (oyun) { oyun.kisi = null; oyun.kanit = null }
    render()
    return
  }
  if (!tEl) return
  const act = tEl.dataset.act
  if (act === "dil-tr") { setDil("tr"); return }
  if (act === "dil-ar") { setDil("ar"); return }
  if (act === "menu") { ekran = "menu"; render(); return }
  if (act === "yeni") { yeniOyun(1); return }
  if (act === "arkadas") { ekran = "arkadas"; render(); return }
  if (act === "bolumler") { ekran = "bolumler"; render(); return }
  if (act === "puan") { ekran = "puan"; render(); return }
  if (act === "basarim") { ekran = "basarim"; render(); return }
  if (act === "ayar") { ekran = "ayar"; render(); return }
  if (act === "titresim") { state.ayar.titreşim = !state.ayar.titreşim; save(); render(); return }
  if (act === "renk") { state.ayar.renkli = !state.ayar.renkli; save(); render(); return }
  if (act === "ad-ekle") {
    const inp = document.getElementById("yeniad")
    const n = (inp && inp.value.trim()) || ""
    if (!n) return
    if (parti.adlar.length >= 5) { toast(T("maxFive")); return }
    if (!parti.adlar.includes(n)) parti.adlar.push(n)
    render()
    return
  }
  if (act === "arkadas-basla") {
    if (parti.adlar.length < 2) { toast(T("needTwo")); return }
    parti.puan = {}; parti.dogru = {}; parti.yanlis = {}; parti.sira = 0
    parti.adlar.forEach(n => { parti.puan[n] = 0; parti.dogru[n] = 0; parti.yanlis[n] = 0 })
    odul("arkadas")
    yeniOyun(1, parti.adlar.slice())
    return
  }
  if (act === "ipucu") {
    if (oyun.ipucuKullan >= 3) { toast(T("noHint")); return }
    oyun.ipucuKullan += 1
    oyun.ipucuIdx = Math.min(oyun.ipucuKullan - 1, 2)
    puanEkle(-((DIFF[state.ayar.zorluk] || DIFF.kolay).ipucuKesinti))
    toast(T("hintOpened"))
    render()
    return
  }
  if (act === "kapat") { oyun.kisi = null; oyun.kanit = null; render(); return }
  if (act === "kanit-al") {
    if (!oyun.bulunan.includes(oyun.kanit)) {
      oyun.bulunan.push(oyun.kanit)
      puanEkle(8)
      toast(T("evAdded"))
    }
    oyun.kanit = null
    render()
    return
  }
  if (act === "sonra") {
    if (oyun.arkadas) {
      siradaki()
      const n = oyun.ch.id + 1
      if (n <= CHAPTERS.length && acikMi(CHAPTERS[n - 1])) yeniOyun(n, oyun.arkadas)
      else { ekran = "siralama"; render() }
      return
    }
    const n = oyun.ch.id + 1
    if (n <= CHAPTERS.length) yeniOyun(n)
    else { ekran = "menu"; render() }
    return
  }
  if (act === "sira-bitir") { ekran = "siralama"; render(); return }
  if (tEl.dataset.sezon) { sezonFiltre = tEl.dataset.sezon; render(); return }
  if (tEl.dataset.zorluk) {
    const id = tEl.dataset.zorluk
    if (!zorlukAcik(id)) { toast(T("lockedDiff")); return }
    state.ayar.zorluk = id
    save()
    render()
    return
  }
  if (tEl.dataset.ad) {
    const n = tEl.dataset.ad
    if (parti.adlar.includes(n)) {
      if (parti.adlar.length <= 2) { toast(T("needTwo")); return }
      parti.adlar = parti.adlar.filter(x => x !== n)
    } else {
      if (parti.adlar.length >= 5) { toast(T("maxFive")); return }
      parti.adlar.push(n)
    }
    render()
    return
  }
  if (tEl.dataset.sil) {
    const n = tEl.dataset.sil
    if (parti.adlar.length <= 2) { toast(T("needTwo")); return }
    parti.adlar = parti.adlar.filter(x => x !== n)
    render()
    return
  }
  if (tEl.dataset.tab) { oyun.tab = tEl.dataset.tab; render(); return }
  if (tEl.dataset.ch) { yeniOyun(Number(tEl.dataset.ch), oyun && oyun.arkadas); return }
  if (tEl.dataset.kisi) {
    oyun.kisi = tEl.dataset.kisi
    if (!oyun.konusulan.includes(oyun.kisi)) oyun.konusulan.push(oyun.kisi)
    render()
    return
  }
  if (tEl.dataset.kanit) { oyun.kanit = tEl.dataset.kanit; render(); return }
  if (tEl.dataset.cel) {
    const id = tEl.dataset.cel
    if (oyun.celiskiSec.includes(id)) oyun.celiskiSec = oyun.celiskiSec.filter(x => x !== id)
    else {
      oyun.celiskiSec.push(id)
      const c = oyun.ch.celiskiler.find(x => x.id === id)
      if (c && c.dogru) { puanEkle(12, true); toast(T("clashOk")) }
      else { puanEkle(-6, false); toast(T("clashNo")) }
    }
    render()
    return
  }
  if (tEl.dataset.karar) { kararVer(tEl.dataset.karar); return }
  if (tEl.dataset.cevap) {
    const [ad, harf] = tEl.dataset.cevap.split(":")
    const q = oyun.ch.sorular.find(s => s.kim === ad)
    oyun.sorulan[ad] = harf
    if (q && q.dogru === harf) { puanEkle(10, true); toast(T("goodQ")) }
    else toast(T("logged"))
    render()
  }
})

app.addEventListener("change", e => {
  if (e.target.dataset.act === "yazi") {
    state.ayar.yazi = Number(e.target.value)
    save()
    render()
  }
})

app.addEventListener("input", e => {
  if (e.target.dataset.act === "isim") {
    state.isim = e.target.value.slice(0, 18)
    save()
  }
})

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("/sw.js").catch(() => {})
}

render()
