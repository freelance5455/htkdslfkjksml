export const DIFF = {
  kolay: { deneme: 5, ipucuKesinti: 10, carpim: 1, gerek: 0 },
  orta: { deneme: 4, ipucuKesinti: 15, carpim: 1.2, gerek: 10 },
  zor: { deneme: 3, ipucuKesinti: 20, carpim: 1.5, gerek: 20 },
  uzman: { deneme: 2, ipucuKesinti: 25, carpim: 2, gerek: 30 }
}

export function bolumZorluk(id) {
  if (id % 10 === 0) return "uzman"
  if (id <= 10) return "kolay"
  if (id <= 20) return "orta"
  if (id <= 40) return "zor"
  return "uzman"
}

export function ozelMi(id) {
  return id % 10 === 0
}

export function denemeSayisi(ayarZorluk, chId) {
  const d = DIFF[ayarZorluk] || DIFF.kolay
  return ozelMi(chId) ? Math.max(2, d.deneme - 1) : d.deneme
}
