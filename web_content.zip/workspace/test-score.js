"use strict";

function totals(rounds) {
  var a = 0;
  var b = 0;
  for (var i = 0; i < rounds.length; i++) {
    var r = rounds[i];
    if (r.a !== null && r.a !== "") a += Number(r.a);
    if (r.b !== null && r.b !== "") b += Number(r.b);
  }
  return { a: a, b: b };
}

function winnerByRule(t, threshold, winRule) {
  if (winRule === "lowest") {
    if (t.a === t.b) return null;
    return t.a < t.b ? "a" : "b";
  }
  if (winRule === "highest") {
    if (t.a === t.b) return null;
    return t.a > t.b ? "a" : "b";
  }
  if (t.a >= threshold && t.b < threshold) return "b";
  if (t.b >= threshold && t.a < threshold) return "a";
  return null;
}

function evaluateEnd(rounds, threshold, winRule, currentWinner) {
  var t = totals(rounds);
  var aHit = t.a >= threshold;
  var bHit = t.b >= threshold;
  var result = { ended: false, winner: null, needsManualWinner: false, totals: t };
  if (!aHit && !bHit) return result;
  result.ended = true;
  if (aHit && bHit) {
    var auto = winnerByRule(t, threshold, winRule);
    if (auto) {
      result.winner = auto;
    } else {
      result.needsManualWinner = !currentWinner;
    }
    return result;
  }
  result.winner = winnerByRule(t, threshold, winRule);
  return result;
}

var failed = 0;
function assert(name, cond) {
  if (!cond) {
    failed += 1;
    console.error("FAIL:", name);
  } else {
    console.log("OK:", name);
  }
}

assert("empty cells ignored", totals([{ a: null, b: 10 }, { a: 5, b: "" }]).a === 5 && totals([{ a: null, b: 10 }, { a: 5, b: "" }]).b === 10);
assert("negatives counted", totals([{ a: -20, b: 30 }]).a === -20 && totals([{ a: -20, b: 30 }]).b === 30);
assert("sum many rounds", totals([{ a: 100, b: 50 }, { a: 200, b: 80 }, { a: 472, b: 10 }]).a === 772);

var r1 = evaluateEnd([{ a: 771, b: 10 }], 772, "threshold_loses");
assert("not ended below 772", r1.ended === false);

var r2 = evaluateEnd([{ a: 772, b: 10 }], 772, "threshold_loses");
assert("ended at 772", r2.ended === true);
assert("threshold_loses: A hit so B wins", r2.winner === "b");

var r3 = evaluateEnd([{ a: 10, b: 800 }], 772, "threshold_loses");
assert("threshold_loses: B hit so A wins", r3.winner === "a");

var r4 = evaluateEnd([{ a: 800, b: 790 }], 772, "threshold_loses");
assert("both hit: ask for winner", r4.ended === true && r4.needsManualWinner === true && r4.winner === null);

var r5 = evaluateEnd([{ a: 800, b: 790 }], 772, "lowest");
assert("both hit lowest: B wins", r5.winner === "b" && r5.needsManualWinner === false);

var r6 = evaluateEnd([{ a: 800, b: 790 }], 772, "highest");
assert("both hit highest: A wins", r6.winner === "a");

var r7 = evaluateEnd([{ a: 800, b: 800 }], 772, "highest");
assert("tie both hit: manual", r7.needsManualWinner === true);

assert("game continues until 772", evaluateEnd([{ a: 400, b: 400 }, { a: 300, b: 300 }], 772, "threshold_loses").ended === false);

if (failed) {
  console.error("Failed:", failed);
  process.exit(1);
}
console.log("All tests passed");
