const CACHE = "son-dedektif-v2"
const CORE = ["/", "/index.html", "/manifest.webmanifest", "/icon.svg"]

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE)).then(() => self.skipWaiting()))
})

self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())
  )
})

self.addEventListener("fetch", e => {
  const req = e.request
  if (req.method !== "GET") return
  e.respondWith(
    caches.match(req).then(hit => {
      const net = fetch(req).then(res => {
        const copy = res.clone()
        if (res.ok && req.url.startsWith(self.location.origin)) {
          caches.open(CACHE).then(c => c.put(req, copy))
        }
        return res
      }).catch(() => hit || caches.match("/"))
      return hit || net
    })
  )
})
