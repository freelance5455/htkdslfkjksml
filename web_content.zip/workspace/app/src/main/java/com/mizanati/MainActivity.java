package com.mizanati

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.mizanati.R

class MainActivity : AppCompatActivity() {

    private lateinit var loadingTextView: TextView
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI components
        loadingTextView = findViewById(R.id.loadingTextView)
        progressBar = findViewById(R.id.progressBar)

        // Initialize loading indicator animation
        startLoadingAnimation()

        // Wait for app initialization
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this@MainActivity, WalletActivity::class.java)
            startActivity(intent)
            finish()
        }, 3000)
    }

    private fun startLoadingAnimation() {
        // Load animation for the loading indicator
        // This matches the attractive loading indicator requested
        loadingTextView.text = "MIZANATI INVEST"

        // Simulating loading progress
        val totalProgress = 100
        val progressStep = 1
        val handler = Handler(Looper.getMainLooper())

        val runnable = object : Runnable {
            var progress = 0

            override fun run() {
                if (progress < totalProgress) {
                    progress += progressStep
                    progressBar.progress = progress
                    handler.postDelayed(this, 30)
                }
            }
        }

        handler.post(runnable)
    }
}
