package com.mizanati

import android.app.Application
import com.google.gson.Gson
import java.security.SecureRandom

class App : Application() {

    companion object {
        @JvmStatic
        val GSON: Gson = Gson()
    }

    // Backup folder name (as requested)
    val BACKUP_FOLDER_NAME = "MIZANATI_BACKUP_INVEST"
    
    // App preferences keys
    const val PREFS_NAME = "mizanati_prefs"
    const val KEY_IS_DARK_MODE = "is_dark_mode"
    const val KEY_ENCRYPTION_PASSWORD = "encryption_password"
    const val KEY_HAS_PASSWORD = "has_password"
    
    // Encryption settings
    const val ENCRYPTION_ITERATIONS = 100000
    const val BACKUP_VERSION = 1
    
    // Generate random salt for encryption
    fun generateSalt(): ByteArray {
        val random = SecureRandom()
        val salt = ByteArray(16)
        random.nextBytes(salt)
        return salt
    }
}
