package com.mizanati

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.mizanati.adapter.WalletAdapter
import com.mizanati.databinding.ActivityWalletBinding
import com.mizanati.model.Wallet
import com.mizanati.util.BackupManager
import kotlinx.coroutines.launch
import java.util.UUID

class WalletActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWalletBinding
    private lateinit var backupManager: BackupManager
    private lateinit var walletAdapter: WalletAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWalletBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize backup manager with the requested backup folder
        backupManager = BackupManager(this)

        // Set up wallet adapter
        walletAdapter = WalletAdapter(
            onEditClick = { wallet -> editWallet(wallet) },
            onDeleteClick = { wallet -> deleteWallet(wallet) }
        )

        binding.apply {
            walletRecyclerView.layoutManager = LinearLayoutManager(this@WalletActivity)
            walletRecyclerView.adapter = walletAdapter

            btnAddWallet.setOnClickListener { showAddWalletDialog() }

            btnExport.setOnClickListener { exportData() }
            btnImport.setOnClickListener { importData() }
            btnBackup.setOnClickListener { backupData() }
            btnRestore.setOnClickListener { restoreData() }
        }

        loadWallets()
    }

    private fun loadWallets() {
        lifecycleScope.launch {
            try {
                backupManager.loadWallets().collect { wallets ->
                    walletAdapter.submitList(wallets.toList())
                }
            } catch (e: Exception) {
                Toast.makeText(this@WalletActivity, "خطأ في تحميل المحافظ: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showAddWalletDialog() {
        // Show dialog to add new wallet
        // This would be a proper dialog implementation
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_wallet, null)
        // Implement dialog logic here
    }

    private fun editWallet(wallet: Wallet) {
        // Show dialog to edit existing wallet
    }

    private fun deleteWallet(wallet: Wallet) {
        lifecycleScope.launch {
            try {
                backupManager.deleteWallet(wallet)
                loadWallets()
                Toast.makeText(this@WalletActivity, "تم حذف المحفظة بنجاح", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@WalletActivity, "خطأ في حذف المحفظة: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun backupData() {
        lifecycleScope.launch {
            try {
                val password = BackupManager.showPasswordDialog(this@WalletActivity)
                if (password != null) {
                    backupManager.backupData(password)
                    Toast.makeText(this@WalletActivity, "تم إنشاء النسخة الاحتياطية بنجاح", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@WalletActivity, "خطأ في إنشاء النسخة الاحتياطية: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun restoreData() {
        lifecycleScope.launch {
            try {
                val password = BackupManager.showPasswordDialog(this@WalletActivity)
                if (password != null) {
                    backupManager.restoreData(password)
                    loadWallets()
                    Toast.makeText(this@WalletActivity, "تم استعادة البيانات بنجاح", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@WalletActivity, "خطأ في استعادة البيانات: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun exportData() {
        lifecycleScope.launch {
            try {
                backupManager.exportData()
                Toast.makeText(this@WalletActivity, "تم تصدير البيانات بنجاح", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@WalletActivity, "خطأ في تصدير البيانات: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun importData() {
        // Show file chooser to import data
    }

    override fun onResume() {
        super.onResume()
        loadWallets()
    }
}
