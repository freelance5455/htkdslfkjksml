package com.mizanati.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.mizanati.databinding.ItemWalletBinding
import com.mizanati.model.Wallet

class WalletAdapter(
    private val onEditClick: (Wallet) -> Unit,
    private val onDeleteClick: (Wallet) -> Unit
) : ListAdapter<Wallet, WalletAdapter.WalletViewHolder>(WalletDiffCallback()) {

    class WalletViewHolder(private val binding: ItemWalletBinding) : 
        RecyclerView.ViewHolder(binding.root) {

        fun bind(wallet: Wallet) {
            binding.apply {
                txtWalletName.text = wallet.name
                txtWalletType.text = when (wallet.type) {
                    is Wallet.Type.GOLD -> "ذهب"
                    is Wallet.Type.REAL_ESTATE -> "عقارات"
                    is Wallet.Type.BOND -> "صكوك"
                    else -> "محفظة أخرى"
                }

                // Show progress or status
                if (wallet.isSyncing) {
                    txtStatus.text = "جارٍ التزامن..."
                    progressBar.visibility = View.VISIBLE
                } else {
                    txtStatus.text = "مُتزامن"
                    progressBar.visibility = View.GONE
                }

                // Set up click listeners
                btnEdit.setOnClickListener { onEditClick(wallet) }
                btnDelete.setOnClickListener { onDeleteClick(wallet) }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WalletViewHolder {
        val binding = ItemWalletBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return WalletViewHolder(binding)
    }

    override fun onBindViewHolder(holder: WalletViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class WalletDiffCallback : DiffUtil.ItemCallback<Wallet>() {
        override fun areItemsTheSame(oldItem: Wallet, newItem: Wallet): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Wallet, newItem: Wallet): Boolean {
            return oldItem == newItem
        }
    }
}
