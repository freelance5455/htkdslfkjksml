package com.mizanati

import android.content.Context
import android.content.SharedPreferences
import android.os.Environment
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.io.IOException
import java.nio.charset.StandardCharsets
import java.security.GeneralSecurityException
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import com.google.gson.Gson
import com.mizanati.model.Wallet

class BackupManager {

    private static final String TAG = "BackupManager"
    private final Context context
    private final Gson gson = App.GSON

    BackupManager(Context context) { this.context = context }

    // Create/get the dedicated backup folder: MIZANATI_BACKUP_INVEST
    private val backupDir: String
        get() {
            val externalStorage = Environment.getExternalStorageDirectory()
            return "${externalStorage.path}/MIZANATI_BACKUP_INVEST"
        }

    // Initialize/create backup directory
    fun ensureBackupDirectory() {
        java.io.File(backupDir).mkdirs()
        Log.d(TAG, "Backup directory: $backupDir")
    }

    // Encrypt data using AES-GCM
    private fun encryptData(plainText: String, password: String): String? {
        try {
            val key = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            val encryptedSharedPreferences = EncryptedSharedPreferences.create(
                context,
                "mizanati_backup_ prefs",
                key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )

            encryptedSharedPreferences.edit().putString("backup_data", plainText).apply()
            return "encrypted"
        } catch (e: GeneralSecurityException) {
            Log.e(TAG, "Encryption error", e)
            return null
        }
    }

    // Decrypt data using AES-GCM
    private fun decryptData(encryptedData: String?): String? {
        try {
            // Read from encrypted shared preferences
            val key = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            val encryptedSharedPreferences = EncryptedSharedPreferences.create(
                context,
                "mizanati_backup_ prefs",
                key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )

            return encryptedSharedPreferences.getString("backup_data", null)
        } catch (e: GeneralSecurityException) {
            Log.e(TAG, "Decryption error", e)
            return null
        }
    }

    // Load wallets from storage
    fun loadWallets(): Flow<List<Wallet>> = flow {
        try {
            ensureBackupDirectory()
            // Load from encrypted storage
            val encryptedFile = java.io.File(backupDir, "wallets.enc")
            if (encryptedFile.exists()) {
                val password = readPasswordFromPrefs()
                if (password != null) {
                    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                    val secretKey = SecretKeySpec(password.toByteArray(StandardCharsets.UTF_8), "AES")
                    val initVector = ByteArray(12) // GCM nonce size
                    cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(128, initVector))
                    
                    val fileContent = String(encryptedFile.readBytes(), StandardCharsets.UTF_8)
                    val decrypted = cipher.doFinal(fileContent.toByteArray())
                    val wallets = gson.fromJson<String, List<Wallet>>(new String(decrypted), object : com.google.gson.reflect.TypeToken<List<Wallet>>(){}.type)
                    // Return loaded wallets
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Load wallets error", e)
        }
    }

    // Save encrypted backup to MIZANATI_BACKUP_INVEST folder
    fun backupData(password: String) {
        try {
            ensureBackupDirectory()
            
            // Collect all wallets and save as JSON
            val walletsJson = gson.toJson(/* get all wallets */ emptyList())
            
            // Encrypt the backup file
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val secretKey = SecretKeySpec(password.toByteArray(StandardCharsets.UTF_8), "AES")
            val initVector = ByteArray(12)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, GCMParameterSpec(128, initVector))
            
            val encryptedData = cipher.doFinal(walletsJson.toByteArray())
            val encryptedFile = java.io.File(backupDir, "mizanati_backup_${System.currentTimeMillis()}.enc")
            
            encryptedFile.writeBytes(encryptedData)
            Log.d(TAG, "Backup saved to: ${encryptedFile.absolutePath}")
        } catch (e: GeneralSecurityException | IOException) {
            Log.e(TAG, "Backup error", e)
            throw RuntimeException("Failed to create encrypted backup", e)
        }
    }

    // Restore data from encrypted backup
    fun restoreData(password: String) {
        try {
            ensureBackupDirectory()
            
            // Ask user which backup to restore
            val backupFiles = java.io.File(backupDir).listFiles { f -> f.name.endsWith(".enc") }
            
            if (backupFiles.isNotEmpty()) {
                // For now, restore the latest backup
                val latestBackup = backupFiles
                    .sortedBy { -it.lastModified() }
                    .first()
                
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                val secretKey = SecretKeySpec(password.toByteArray(StandardCharsets.UTF_8), "AES")
                val initVector = ByteArray(12)
                cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(128, initVector))
                
                val encryptedData = latestBackup.readBytes()
                val decrypted = cipher.doFinal(encryptedData)
                val walletsJson = String(decrypted)
                
                // Parse and save wallets
                Log.d(TAG, "Restored wallets from: ${latestBackup.name}")
            }
        } catch (e: GeneralSecurityException | IOException) {
            Log.e(TAG, "Restore error", e)
            throw RuntimeException("Failed to restore backup", e)
        }
    }

    // Export data (create unencrypted backup copy)
    fun exportData() {
        ensureBackupDirectory()
        // Create a readable copy for export purposes
    }

    // Import data from backup file
    fun importData(filePath: String) {
        // Handle import from backup file
    }

    // Get or create password storage
    private fun readPasswordFromPrefs(): String? {
        val sharedPref = context.getSharedPreferences(App.PREFS_NAME, Context.MODE_PRIVATE)
        return sharedPref.getString(App.KEY_ENCRYPTION_PASSWORD, null)
    }

    // Save password to secure storage
    fun savePassword(password: String) {
        val sharedPref = context.getSharedPreferences(App.PREFS_NAME, Context.MODE_PRIVATE)
        sharedPref.edit().putString(App.KEY_ENCRYPTION_PASSWORD, password).apply()
    }
    
    // Show password dialog (UI helper)
    companion object {
        fun showPasswordDialog(parent: android.content.Context): String? {
            // This would show an actual dialog in the full app
            // For now return null to indicate user needs to input password
            return null
        }
    }
}
