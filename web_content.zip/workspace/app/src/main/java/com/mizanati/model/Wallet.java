package com.mizanati.model

import com.google.gson.annotations.SerializedName

data class Wallet(
    @SerializedName("id") val id: String = UUID.randomUUID().toString(),
    @SerializedName("name") val name: String = "محفظة جديدة",
    @SerializedName("type") val type: Type = Type.GOLD,
    @SerializedName("created_at") val createdAt: String = java.time.LocalDate.now().toString(),
    @SerializedName("balance") val balance: Double = 0.0,
    @SerializedName("is_syncing") val isSyncing: Boolean = false
) {
    enum class Type { GOLD, REAL_ESTATE, BOND, OTHER }

    fun getTypeText(context: android.content.Context): String {
        return when (this@Wallet.Type) {
            GOLD -> "ذهب"
            REAL_ESTATE -> "عقارات"
            BOND -> "صكوك"
            else -> "محفظة أخرى"
        }
    }
    
    fun getTypeIcon(context: android.content.Context): Int {
        return when (this@Wallet.Type) {
            GOLD -> R.drawable.ic_gold
            REAL_ESTATE -> R.drawable.ic_real_estate
            BOND -> R.drawable.ic_bond
            else -> R.drawable.ic_wallet
        }
    }
}

data class InvestmentInstrument(
    @SerializedName("id") val id: String = UUID.randomUUID().toString(),
    @SerializedName("name") val name: String = "",
    @SerializedName("type") val type: String = "gold",
    @SerializedName("amount") val amount: Double = 0.0,
    @SerializedName("rate") val rate: Double = 0.0,
    @SerializedName("term") val term: Int = 12,
    @SerializedName("frequency") val frequency: String = "monthly",
    @SerializedName("fee_pct") val feePct: Double = 0.0,
    @SerializedName("fee_fix") val feeFix: Double = 0.0,
    @SerializedName("fx") val fx: Double = 0.0,
    @SerializedName("purchase_date") val purchaseDate: String = ""
)

data class Transaction(
    @SerializedName("id") val id: String = UUID.randomUUID().toString(),
    @SerializedName("kind") val kind: String = "buy",
    @SerializedName("date") val date: String = "",
    @SerializedName("type") val type: String = "buy",
    @SerializedName("amt") val amt: Double = 0.0,
    @SerializedName("units") val units: Double = 0.0,
    @SerializedName("fx") val fx: Double = 0.0
)
