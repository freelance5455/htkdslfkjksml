(function () {
  "use strict";

  var STORAGE_KEY = "konkan-score-v1";
  var DEFAULT_THRESHOLD = 772;
  var WIN_RULES = {
    threshold_loses: "من بلغ حد الحسم يخسر، والفريق الآخر يفوز",
    lowest: "الأقل مجموعاً يفوز",
    highest: "الأكثر مجموعاً يفوز"
  };

  var state = emptyState();
  var undoStack = [];
  var keypadTarget = null;
  var keypadBuffer = "";
  var pendingConfirm = null;

  var el = {
    nameA: document.getElementById("nameA"),
    nameB: document.getElementById("nameB"),
    totalA: document.getElementById("totalA"),
    totalB: document.getElementById("totalB"),
    thA: document.getElementById("thA"),
    thB: document.getElementById("thB"),
    roundsBody: document.getElementById("roundsBody"),
    sumA: document.getElementById("sumA"),
    sumB: document.getElementById("sumB"),
    btnAdd: document.getElementById("btnAdd"),
    btnUndo: document.getElementById("btnUndo"),
    btnNewGame: document.getElementById("btnNewGame"),
    btnHistory: document.getElementById("btnHistory"),
    btnSettings: document.getElementById("btnSettings"),
    finaleNameA: document.getElementById("finaleNameA"),
    finaleNameB: document.getElementById("finaleNameB"),
    finaleTotalA: document.getElementById("finaleTotalA"),
    finaleTotalB: document.getElementById("finaleTotalB"),
    finaleDiff: document.getElementById("finaleDiff"),
    winnerLine: document.getElementById("winnerLine"),
    gameHint: document.getElementById("gameHint"),
    keypadOverlay: document.getElementById("keypadOverlay"),
    keypadDisplay: document.getElementById("keypadDisplay"),
    keypadTitle: document.getElementById("keypadTitle"),
    settingsOverlay: document.getElementById("settingsOverlay"),
    historyOverlay: document.getElementById("historyOverlay"),
    historyList: document.getElementById("historyList"),
    confirmOverlay: document.getElementById("confirmOverlay"),
    confirmTitle: document.getElementById("confirmTitle"),
    confirmText: document.getElementById("confirmText"),
    pickWinnerOverlay: document.getElementById("pickWinnerOverlay"),
    pickA: document.getElementById("pickA"),
    pickB: document.getElementById("pickB"),
    pickTitle: document.getElementById("pickTitle"),
    endOverlay: document.getElementById("endOverlay"),
    endTitle: document.getElementById("endTitle"),
    endNameA: document.getElementById("endNameA"),
    endNameB: document.getElementById("endNameB"),
    endTotalA: document.getElementById("endTotalA"),
    endTotalB: document.getElementById("endTotalB"),
    endRule: document.getElementById("endRule"),
    thresholdInput: document.getElementById("thresholdInput"),
    felt: document.querySelector(".felt")
  };

  function emptyState() {
    return {
      nameA: "فريق 1",
      nameB: "فريق 2",
      rounds: [{ a: null, b: null }],
      threshold: DEFAULT_THRESHOLD,
      winRule: "threshold_loses",
      ended: false,
      winner: null,
      needsManualWinner: false,
      history: [],
      lastEndShown: false
    };
  }

  function clone(obj) {
    return JSON.parse(JSON.stringify(obj));
  }

  function load() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      var data = JSON.parse(raw);
      if (!data || !Array.isArray(data.rounds)) return;
      state = Object.assign(emptyState(), data);
      if (!state.rounds.length) state.rounds = [{ a: null, b: null }];
    } catch (e) {
      state = emptyState();
    }
  }

  function save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {}
  }

  function snapshot() {
    undoStack.push(clone({
      rounds: state.rounds,
      ended: state.ended,
      winner: state.winner,
      needsManualWinner: state.needsManualWinner,
      lastEndShown: state.lastEndShown
    }));
    if (undoStack.length > 40) undoStack.shift();
    el.btnUndo.disabled = false;
  }

  function parseScore(value) {
    if (value === null || value === undefined || value === "") return null;
    var n = Number(value);
    return Number.isFinite(n) ? n : null;
  }

  function totals() {
    var a = 0;
    var b = 0;
    for (var i = 0; i < state.rounds.length; i++) {
      var r = state.rounds[i];
      if (r.a !== null && r.a !== "") a += Number(r.a);
      if (r.b !== null && r.b !== "") b += Number(r.b);
    }
    return { a: a, b: b };
  }

  function formatNum(n) {
    return String(n);
  }

  function winnerByRule(t) {
    if (state.winRule === "lowest") {
      if (t.a === t.b) return null;
      return t.a < t.b ? "a" : "b";
    }
    if (state.winRule === "highest") {
      if (t.a === t.b) return null;
      return t.a > t.b ? "a" : "b";
    }
    if (t.a >= state.threshold && t.b < state.threshold) return "b";
    if (t.b >= state.threshold && t.a < state.threshold) return "a";
    return null;
  }

  function evaluateEnd() {
    var t = totals();
    var aHit = t.a >= state.threshold;
    var bHit = t.b >= state.threshold;
    if (!aHit && !bHit) {
      state.ended = false;
      state.winner = null;
      state.needsManualWinner = false;
      return;
    }
    state.ended = true;
    if (aHit && bHit) {
      var auto = winnerByRule(t);
      if (auto) {
        state.winner = auto;
        state.needsManualWinner = false;
      } else {
        state.needsManualWinner = !state.winner;
      }
      return;
    }
    state.needsManualWinner = false;
    state.winner = winnerByRule(t);
  }

  function teamName(side) {
    return side === "a" ? (state.nameA || "فريق 1") : (state.nameB || "فريق 2");
  }

  function renderRounds() {
    var html = "";
    for (var i = 0; i < state.rounds.length; i++) {
      var r = state.rounds[i];
      var aVal = r.a === null || r.a === "" ? "" : String(r.a);
      var bVal = r.b === null || r.b === "" ? "" : String(r.b);
      html +=
        '<tr data-i="' + i + '">' +
        "<td>" + (i + 1) + "</td>" +
        '<td><button type="button" class="score-input' + (aVal === "" ? " empty" : "") + '" data-side="a" data-i="' + i + '">' +
        (aVal === "" ? "—" : aVal) + "</button></td>" +
        '<td><button type="button" class="score-input' + (bVal === "" ? " empty" : "") + '" data-side="b" data-i="' + i + '">' +
        (bVal === "" ? "—" : bVal) + "</button></td>" +
        '<td><button type="button" class="del-btn" data-del="' + i + '" aria-label="حذف الجولة">×</button></td>' +
        "</tr>";
    }
    el.roundsBody.innerHTML = html;
  }

  function render() {
    evaluateEnd();
    var t = totals();
    if (document.activeElement !== el.nameA) el.nameA.value = state.nameA;
    if (document.activeElement !== el.nameB) el.nameB.value = state.nameB;
    el.thA.textContent = state.nameA || "فريق 1";
    el.thB.textContent = state.nameB || "فريق 2";
    el.totalA.textContent = formatNum(t.a);
    el.totalB.textContent = formatNum(t.b);
    el.sumA.textContent = formatNum(t.a);
    el.sumB.textContent = formatNum(t.b);
    el.finaleNameA.textContent = state.nameA || "فريق 1";
    el.finaleNameB.textContent = state.nameB || "فريق 2";
    el.finaleTotalA.textContent = formatNum(t.a);
    el.finaleTotalB.textContent = formatNum(t.b);
    el.finaleDiff.textContent = formatNum(Math.abs(t.a - t.b));
    el.gameHint.textContent = "تُحسم اللعبة عند وصول أحد الفريقين إلى " + state.threshold + " نقطة.";
    el.btnUndo.disabled = undoStack.length === 0;
    renderRounds();

    if (state.ended) {
      el.felt.classList.add("locked");
      el.btnAdd.disabled = true;
      if (state.needsManualWinner && !state.winner) {
        el.winnerLine.textContent = "وصل الفريقان إلى حد الحسم — حدّد الفائز";
        el.winnerLine.classList.add("ended");
        showPickWinner();
      } else if (state.winner) {
        el.winnerLine.textContent = "الفائز: " + teamName(state.winner);
        el.winnerLine.classList.add("ended");
        if (!state.lastEndShown) showEndCard(t);
      } else {
        el.winnerLine.textContent = "انتهت اللعبة — حدّد الفائز من الإعدادات أو يدوياً";
        el.winnerLine.classList.add("ended");
      }
    } else {
      el.felt.classList.remove("locked");
      el.btnAdd.disabled = false;
      el.winnerLine.textContent = "اللعبة مستمرة";
      el.winnerLine.classList.remove("ended");
    }
    save();
  }

  function showEndCard(t) {
    state.lastEndShown = true;
    save();
    el.endNameA.textContent = teamName("a");
    el.endNameB.textContent = teamName("b");
    el.endTotalA.textContent = formatNum(t.a);
    el.endTotalB.textContent = formatNum(t.b);
    el.endTitle.textContent = state.winner ? "الفائز: " + teamName(state.winner) : "تعادل يحتاج حسماً";
    el.endRule.textContent = WIN_RULES[state.winRule] || "";
    el.endOverlay.classList.remove("hidden");
  }

  function showPickWinner() {
    el.pickA.textContent = teamName("a");
    el.pickB.textContent = teamName("b");
    el.pickWinnerOverlay.classList.remove("hidden");
  }

  function openKeypad(index, side) {
    if (state.ended) return;
    keypadTarget = { index: index, side: side };
    var current = state.rounds[index][side];
    keypadBuffer = current === null || current === "" ? "" : String(current);
    el.keypadTitle.textContent = "نتيجة " + teamName(side) + " — الجولة " + (index + 1);
    el.keypadDisplay.textContent = keypadBuffer === "" ? "0" : keypadBuffer;
    el.keypadOverlay.classList.remove("hidden");
  }

  function applyKeypad() {
    if (!keypadTarget) return;
    snapshot();
    var value = keypadBuffer === "" || keypadBuffer === "-" ? null : Number(keypadBuffer);
    if (value !== null && !Number.isFinite(value)) value = null;
    state.rounds[keypadTarget.index][keypadTarget.side] = value;
    keypadTarget = null;
    el.keypadOverlay.classList.add("hidden");
    render();
  }

  function addRound() {
    if (state.ended) return;
    snapshot();
    state.rounds.push({ a: null, b: null });
    render();
    var wrap = document.querySelector(".table-wrap");
    if (wrap) wrap.scrollTop = wrap.scrollHeight;
  }

  function deleteRound(index) {
    if (state.ended) return;
    if (state.rounds.length === 1) {
      snapshot();
      state.rounds[0] = { a: null, b: null };
      render();
      return;
    }
    snapshot();
    state.rounds.splice(index, 1);
    render();
  }

  function undo() {
    if (!undoStack.length) return;
    var prev = undoStack.pop();
    state.rounds = prev.rounds;
    state.ended = prev.ended;
    state.winner = prev.winner;
    state.needsManualWinner = prev.needsManualWinner;
    state.lastEndShown = prev.lastEndShown;
    render();
  }

  function archiveCurrent() {
    var t = totals();
    var hasScore = state.rounds.some(function (r) {
      return r.a !== null || r.b !== null;
    });
    if (!hasScore) return;
    state.history.unshift({
      date: new Date().toISOString(),
      nameA: state.nameA,
      nameB: state.nameB,
      totalA: t.a,
      totalB: t.b,
      winner: state.winner,
      ended: state.ended,
      threshold: state.threshold,
      rounds: state.rounds.length
    });
    if (state.history.length > 30) state.history.pop();
  }

  function newGame() {
    archiveCurrent();
    var history = state.history;
    var threshold = state.threshold;
    var winRule = state.winRule;
    var nameA = state.nameA;
    var nameB = state.nameB;
    state = emptyState();
    state.history = history;
    state.threshold = threshold;
    state.winRule = winRule;
    state.nameA = nameA;
    state.nameB = nameB;
    undoStack = [];
    render();
  }

  function renderHistory() {
    if (!state.history.length) {
      el.historyList.innerHTML = "<p class=\"field-note\">لا توجد مباريات محفوظة بعد.</p>";
      return;
    }
    el.historyList.innerHTML = state.history.map(function (h) {
      var d = new Date(h.date);
      var when = isNaN(d.getTime()) ? "" : d.toLocaleString("ar");
      var winner = h.winner ? (h.winner === "a" ? h.nameA : h.nameB) : (h.ended ? "غير محدد" : "لم تُحسم");
      return (
        '<div class="history-item">' +
        "<strong>" + escapeHtml(h.nameA) + " " + h.totalA + " — " + escapeHtml(h.nameB) + " " + h.totalB + "</strong>" +
        '<div class="history-meta">' + when + " · الفائز: " + escapeHtml(winner) + " · جولات: " + h.rounds + "</div>" +
        "</div>"
      );
    }).join("");
  }

  function escapeHtml(s) {
    return String(s || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function confirmDialog(title, text, onYes) {
    el.confirmTitle.textContent = title;
    el.confirmText.textContent = text;
    pendingConfirm = onYes;
    el.confirmOverlay.classList.remove("hidden");
  }

  el.roundsBody.addEventListener("click", function (e) {
    var btn = e.target.closest("button");
    if (!btn) return;
    if (btn.dataset.del !== undefined) {
      deleteRound(Number(btn.dataset.del));
      return;
    }
    if (btn.dataset.side) openKeypad(Number(btn.dataset.i), btn.dataset.side);
  });

  el.btnAdd.addEventListener("click", addRound);
  el.btnUndo.addEventListener("click", undo);
  el.btnNewGame.addEventListener("click", function () {
    confirmDialog("بدء لعبة جديدة؟", "سيتم حفظ المباراة الحالية في السجل وبدء مباراة جديدة.", newGame);
  });

  function bindName(input, key, fallback, header, finale) {
    input.addEventListener("input", function () {
      state[key] = input.value;
      var shown = state[key].trim() || fallback;
      header.textContent = shown;
      finale.textContent = shown;
      save();
    });
    input.addEventListener("blur", function () {
      if (!state[key].trim()) state[key] = fallback;
      else state[key] = state[key].trim();
      render();
    });
  }
  bindName(el.nameA, "nameA", "فريق 1", el.thA, el.finaleNameA);
  bindName(el.nameB, "nameB", "فريق 2", el.thB, el.finaleNameB);

  document.getElementById("keypadClose").addEventListener("click", function () {
    el.keypadOverlay.classList.add("hidden");
    keypadTarget = null;
  });
  document.getElementById("keypadClear").addEventListener("click", function () {
    keypadBuffer = "";
    el.keypadDisplay.textContent = "0";
  });
  document.getElementById("keypadOk").addEventListener("click", applyKeypad);

  el.keypadOverlay.querySelector(".keys").addEventListener("click", function (e) {
    var k = e.target.getAttribute("data-k");
    if (!k) return;
    if (k === "back") {
      keypadBuffer = keypadBuffer.slice(0, -1);
    } else if (k === "-") {
      if (keypadBuffer.charAt(0) === "-") keypadBuffer = keypadBuffer.slice(1);
      else keypadBuffer = "-" + keypadBuffer.replace("-", "");
    } else {
      if (keypadBuffer === "0") keypadBuffer = k;
      else if (keypadBuffer === "-0") keypadBuffer = "-" + k;
      else keypadBuffer += k;
      if (keypadBuffer.replace("-", "").length > 6) keypadBuffer = keypadBuffer.slice(0, keypadBuffer.charAt(0) === "-" ? 7 : 6);
    }
    el.keypadDisplay.textContent = keypadBuffer === "" || keypadBuffer === "-" ? "0" : keypadBuffer;
  });

  el.btnSettings.addEventListener("click", function () {
    el.thresholdInput.value = state.threshold;
    var radios = document.querySelectorAll('input[name="winRule"]');
    for (var i = 0; i < radios.length; i++) radios[i].checked = radios[i].value === state.winRule;
    el.settingsOverlay.classList.remove("hidden");
  });
  document.getElementById("settingsClose").addEventListener("click", function () {
    el.settingsOverlay.classList.add("hidden");
  });
  document.getElementById("settingsSave").addEventListener("click", function () {
    var th = Number(el.thresholdInput.value);
    if (!Number.isFinite(th) || th < 1) th = DEFAULT_THRESHOLD;
    state.threshold = Math.floor(th);
    var checked = document.querySelector('input[name="winRule"]:checked');
    state.winRule = checked ? checked.value : "threshold_loses";
    state.lastEndShown = false;
    el.settingsOverlay.classList.add("hidden");
    render();
  });

  el.btnHistory.addEventListener("click", function () {
    renderHistory();
    el.historyOverlay.classList.remove("hidden");
  });
  document.getElementById("historyClose").addEventListener("click", function () {
    el.historyOverlay.classList.add("hidden");
  });

  document.getElementById("confirmNo").addEventListener("click", function () {
    el.confirmOverlay.classList.add("hidden");
    pendingConfirm = null;
  });
  document.getElementById("confirmYes").addEventListener("click", function () {
    el.confirmOverlay.classList.add("hidden");
    el.endOverlay.classList.add("hidden");
    if (pendingConfirm) pendingConfirm();
    pendingConfirm = null;
  });

  el.pickA.addEventListener("click", function () {
    snapshot();
    state.winner = "a";
    state.needsManualWinner = false;
    el.pickWinnerOverlay.classList.add("hidden");
    render();
  });
  el.pickB.addEventListener("click", function () {
    snapshot();
    state.winner = "b";
    state.needsManualWinner = false;
    el.pickWinnerOverlay.classList.add("hidden");
    render();
  });

  document.getElementById("endReview").addEventListener("click", function () {
    el.endOverlay.classList.add("hidden");
  });
  document.getElementById("endNew").addEventListener("click", function () {
    el.endOverlay.classList.add("hidden");
    confirmDialog("بدء لعبة جديدة؟", "سيتم حفظ المباراة الحالية في السجل وبدء مباراة جديدة.", newGame);
  });

  load();
  render();

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("sw.js").catch(function () {});
  }
})();
