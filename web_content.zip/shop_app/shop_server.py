# -*- coding: utf-8 -*-
"""Cashier local app: serves cashier.html and keeps all data in shop-data.json (next to this file).
Run:  python shop_server.py        (add 'lan' to let phones on the same Wi-Fi use it too)"""
import http.server, json, os, sys, shutil, datetime, webbrowser, threading, socket, subprocess, glob

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, 'shop-data.json')
BK = os.path.join(BASE, 'backups')
PORT = int(os.environ.get('SHOP_PORT', '8765'))
LAN = 'lan' in sys.argv
lock = threading.Lock()
STATIC = {'/sw.js': 'text/javascript; charset=utf-8', '/manifest.webmanifest': 'application/manifest+json; charset=utf-8',
          '/icon-192.png': 'image/png', '/icon-512.png': 'image/png'}


class H(http.server.BaseHTTPRequestHandler):
    def _send(self, code, body=b'', ctype='application/json; charset=utf-8'):
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def _host_ok(self):
        if LAN:
            return True
        return (self.headers.get('Host') or '').split(':')[0] in ('127.0.0.1', 'localhost')

    def do_GET(self):
        if not self._host_ok():
            return self._send(403)
        p = self.path.split('?')[0]
        if p in ('/', '/index.html'):
            with open(os.path.join(BASE, 'cashier.html'), 'rb') as f:
                self._send(200, f.read(), 'text/html; charset=utf-8')
        elif p in STATIC:
            with open(os.path.join(BASE, p[1:]), 'rb') as f:
                self._send(200, f.read(), STATIC[p])
        elif p == '/api/data':
            with lock:
                b = open(DATA, 'rb').read() if os.path.exists(DATA) else b''
            self._send(200, b)
        else:
            self._send(404)

    def do_POST(self):
        if self.path != '/api/data' or not self._host_ok() or self.headers.get('X-Shop') != '1':
            return self._send(403)
        b = self.rfile.read(int(self.headers.get('Content-Length', 0)))
        try:
            json.loads(b.decode('utf-8'))
        except Exception:
            return self._send(400)
        with lock:
            os.makedirs(BK, exist_ok=True)
            day = os.path.join(BK, 'shop-data-' + datetime.date.today().isoformat() + '.json')
            if os.path.exists(DATA) and not os.path.exists(day):
                shutil.copy2(DATA, day)
                for old in sorted(glob.glob(os.path.join(BK, 'shop-data-*.json')))[:-30]:
                    os.remove(old)
            tmp = DATA + '.tmp'
            with open(tmp, 'wb') as f:
                f.write(b)
            os.replace(tmp, DATA)
        self._send(200, b'{"ok":true}')

    def log_message(self, *a):
        pass


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        return s.getsockname()[0]
    except Exception:
        return '127.0.0.1'
    finally:
        s.close()


def open_app(url):
    c = []
    if sys.platform == 'win32':
        for base in (os.environ.get('ProgramFiles'), os.environ.get('ProgramFiles(x86)'), os.environ.get('LOCALAPPDATA')):
            if base:
                c += [os.path.join(base, 'Google', 'Chrome', 'Application', 'chrome.exe'),
                      os.path.join(base, 'Microsoft', 'Edge', 'Application', 'msedge.exe')]
    else:
        c = [shutil.which(n) or '' for n in ('google-chrome', 'chromium', 'chromium-browser', 'microsoft-edge')]
    for x in c:
        if x and os.path.exists(x):
            subprocess.Popen([x, '--app=' + url])
            return
    webbrowser.open(url)


if __name__ == '__main__':
    url = 'http://127.0.0.1:%d/' % PORT
    try:
        srv = http.server.ThreadingHTTPServer(('0.0.0.0' if LAN else '127.0.0.1', PORT), H)
    except OSError:
        print('Already running - opening the app window.')
        open_app(url)
        sys.exit(0)
    print('Cashier is running.  Data file: ' + DATA)
    if LAN:
        print('Other phones on the same Wi-Fi: http://%s:%d/' % (lan_ip(), PORT))
    print('Close this window to stop the program.')
    if not os.environ.get('SHOP_NO_OPEN'):
        open_app(url)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
