@echo off
cd /d "%~dp0"
where python >nul 2>nul
if %errorlevel%==0 (python shop_server.py) else (py shop_server.py)
if errorlevel 1 (
  echo.
  echo Python is not installed. Install it from python.org and tick "Add Python to PATH", then run this file again.
  pause
)
