#!/bin/sh
cd "$(dirname "$0")"
python3 shop_server.py "$@"
