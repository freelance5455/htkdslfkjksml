Max Call 2027 — HD/2K video kamera oynasi

Ushbu arxivdagi assets/web/index.html faylida video sifati tanlash qo‘shildi:
- HD 720p
- Full HD 1080p
- 2K QHD 1440p (2560 × 1440)
- Old/orqa kamerani almashtirish tugmasi
- Kamera va mikrofonni yoqish/o‘chirish

Muhim: 2K faqat qurilma kamerasi, Android WebView va brauzer ruxsat bersa ishlaydi. Qurilma 2Kni qo‘llamasa, kamera pastroq aniqlikdan foydalanishi mumkin. Bu demo hozircha o‘z kamerangizni ko‘rsatadi; boshqa foydalanuvchi bilan haqiqiy internet videoqo‘ng‘iroq qilish uchun WebRTC/ZEGOCLOUD kabi xizmat, signalizatsiya va xavfsiz token serveri kerak. ZIP APK emas.

Ishlatish: assets/web/index.html faylini web loyihangizga joylang yoki mavjud web assets bilan birlashtiring.
