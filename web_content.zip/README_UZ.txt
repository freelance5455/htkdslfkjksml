IKROMOV AI — Android APK loyihasi

1. Android Studio o‘rnating.
2. Shu papkani Android Studio orqali Open qiling.
3. Gradle Sync tugashini kuting.
4. Telefonni USB debugging bilan ulang yoki emulator yarating.
5. Run ▶ ni bosing.
6. APK uchun: Build > Build APK(s).

Muhim:
- Hozirgi HTML prototip Android WebView ichida ishlaydi.
- "Yaratish" tugmasi hozircha demo matn chiqaradi.
- Haqiqiy AI uchun keyingi bosqichda xavfsiz backend + AI API ulanishi kerak.
