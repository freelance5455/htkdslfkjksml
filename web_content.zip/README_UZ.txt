KUNIM — OFFLINE PWA PAKETI

Ichida:
- index.html: ilovaning interfeysi va funksiyalari
- manifest.json: PWA ilova sozlamalari
- sw.js: kesh orqali offline ishlash
- icons/: ilova ikonkalari

MUHIM:
1. Ma’lumotlar brauzer localStorage xotirasida saqlanadi.
2. Offline PWA sifatida o‘rnatish uchun fayllarni HTTPS manzilga joylash kerak.
3. APK qilish uchun bu paketni HTML-to-APK/WebView wrapper xizmatiga yoki Android loyihasiga joylash kerak.
4. Bu paketning o‘zi APK emas. Hozirgi muhitda Android SDK bilan APK kompilyatsiyasi bajarilmadi.
5. Brauzer ma’lumotlarini tozalash ilova ichidagi yozuvlarni o‘chirishi mumkin.
