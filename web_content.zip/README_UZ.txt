TELEFON EKRAN PRO — ANDROID LOYIHA

Bu loyiha oldingi Telefon Ekran Professional saytini Android WebView ilovasiga joylaydi.
Ma'lumotlar LocalStorage orqali qurilmaning o'zida saqlanadi.

APK chiqarish:
1. Android Studio o'rnating.
2. Ushbu papkani Android Studio orqali Open qiling.
3. Gradle sync tugashini kuting.
4. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
5. APK app/build/outputs/apk/debug/ papkasida chiqadi.

Ilova nomi: Telefon Ekran Pro
Package: uz.telefon.ekranpro
