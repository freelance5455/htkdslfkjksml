TEPALIK — ANDROID BOSH EKRANIGA O'RNATISH

Bu papka PWA (telefon bosh ekraniga ilova kabi qo'shiladigan veb-o'yin) uchun tayyorlangan.
ZIP faylni bevosita APK kabi o'rnatib bo'lmaydi. Avval HTTPS saytga joylash kerak.

GITHUB PAGES ORQALI BEPUL JOYLASH:
1. https://github.com saytiga kiring va akkaunt oching/kiring.
2. New repository bosing. Nomi: tepalik. Public tanlang va Create repository bosing.
3. Add file > Upload files ni bosing.
4. ZIP ichidagi quyidagi 6 faylni yuklang:
   index.html
   manifest.webmanifest
   sw.js
   icon-192.png
   icon-512.png
   icon-maskable-512.png
   (README_UZ.txt va OQING_UZ.txt majburiy emas.)
5. Commit changes bosing.
6. Repository Settings > Pages bo'limiga kiring.
7. Build and deployment ichida Source: Deploy from a branch ni tanlang.
8. Branch: main, papka: /(root) ni tanlab Save bosing.
9. Bir necha daqiqa kuting. Pages ko'rsatgan manzilni Chrome'da oching:
   https://GITHUB_NOMINGIZ.github.io/tepalik/
10. Chrome menyusi (⋮) > Install app yoki Add to Home screen ni bosing.
11. O'yinni bosh ekrandagi Tepalik belgisidan oching.

ESLATMA:
- Birinchi marta sahifani ochishda internet kerak.
- Keyin kesh ishlasa, o'yin internetsiz ham ochilishi mumkin.
- GitHub repository Public bo'lsa, havolani bilgan boshqa odamlar ham o'yinni ko'ra oladi.
- ZIP faylning o'zi APK emas; bu usul ilovani Chrome orqali bosh ekranga qo'shadi.
