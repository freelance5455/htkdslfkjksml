Max Call — Kuchli kontaktlar (2027)

Funksiyalar:
- Kontaktlarni qurilmaning localStorage xotirasida saqlash (amaliy chegarasi brauzer/WebView xotirasiga bog‘liq; loyiha 10 000 ta kontaktgacha ruxsat beradi).
- Ism, telefon, email, kompaniya va izoh bo‘yicha qidirish.
- Kontakt qo‘shish, tahrirlash, o‘chirish.
- Sevimlilar, A–Z va yaqinda qo‘shilgan bo‘yicha saralash.
- JSON eksport/import va VCF (vCard) import.
- Takroriy telefon raqamlarini import paytida o‘tkazib yuborish.
- Kontakt raqamiga SIM qo‘ng‘iroqni Android telefon ilovasi orqali boshlash.

Eslatma: bu HTML/CSS/JavaScript manba loyihasi, APK emas. Kontaktlar faqat shu ilovaning shu qurilmadagi WebView/brauzer saqlash joyida turadi. Ilovani o‘chirish yoki WebView ma’lumotlarini tozalash kontaktlarni yo‘qotishi mumkin; muntazam eksport qiling. Bu versiya Android tizim kontaktlariga avtomatik ulanmaydi va internetda sinxronlamaydi.


Yangi emblema: assets/web/maxcall_logo_icon.png. Bosh sahifadagi eski M belgisi Max Call emblemasiga almashtirildi.


YANGI: Chiquvchi chaqiruv signali sinovi
- “Chaqiruv signalini sinash” tugmasi qisqa ikki tonli signalni ijro etadi.
- “Signalni to‘xtatish” tugmasi audio sinovini to‘xtatadi.
- SIM orqali haqiqiy qo‘ng‘iroqdagi ringback signal Android Telefon ilovasi/operator tomonidan boshqariladi.
- Internet qo‘ng‘irog‘ida masofadagi telefon jiringlayotganini ko‘rsatish uchun ZEGOCLOUD/WebRTC SDK holat callbacklari kerak. Bu signal sinovi haqiqiy ulanishni tasdiqlamaydi.
