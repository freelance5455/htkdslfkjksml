TBOT SERVER — HTML/CSS/JS mobil interfeysi
==========================================

Fayllar:
- index.html  — sahifalar va menyular
- style.css   — mobilga mos dizayn
- app.js      — fayl tanlash, RUN oynasi maketi, SAVERUN yozuvlari
- assets/     — logotip yoki qo‘shimcha rasmlar uchun

TEKSHIRISH:
1. ZIP arxivni chiqaring.
2. index.html faylini brauzerda oching.
3. Telefonda ishlatish uchun butun papkani HTML-to-APK xizmatiga yuklang (agar u ZIP importini qo‘llasa).

MUHIM CHEKLOV:
Bu HTML/CSS/JS interfeys. Brauzer xavfsizlik cheklovlari sababli Python .py fayllarini ishga tushirmaydi, Android fon xizmatlarini yaratmaydi va pip paketlarini o‘rnatmaydi.
Shu sababli asl TBOT Android ilovasidagi haqiqiy Python runner funksiyalari bu web-versiyada mavjud emas. RUN/STOP tugmalari cheklovni tushuntiradi, SAVERUN yozuvlari esa brauzerning localStorage xotirasida saqlanadi.

ASL LOYIHA:
Asl Kotlin/Chaquopy Android loyihasi o‘zgartirilmagan; bu ZIP alohida web interfeysdir.
