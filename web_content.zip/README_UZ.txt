Max Call — mikrofon ovozini tiniqlashtirish yangilanishi

Yangilanish:
- echoCancellation: aks-sadoni kamaytirishga urinadi
- noiseSuppression: fon shovqinini kamaytirishga urinadi
- autoGainControl: ovoz balandligini avtomatik moslashtiradi
- mono audio: qo‘ng‘iroq uchun mos bitta kanal

Eslatma: natija telefon mikrofoni, Android/WebView versiyasi va brauzer tomonidan qo‘llab-quvvatlanishiga bog‘liq. Bu sozlamalar ovozni kafolatli ravishda kuchaytirmaydi va professional shovqin filtri o‘rnini bosmaydi. Haqiqiy internet qo‘ng‘irog‘i uchun WebRTC/ZEGOCLOUD ulanishi kerak.
