IQ DUEL — Android loyiha (boshlang‘ich demo)

NIMA BOR:
- Android ilovasi uchun WebView qobig‘i
- Jumboq savollari va javoblar
- To‘g‘ri javob uchun tanga va reyting
- Baraban
- Demo duel kodi

MUHIM:
Bu tayyor APK emas, Android Studio loyihasidir. Yuklangan IQ Duel.md faylida faqat o‘yin tavsifi bor edi; savollar, internet-multiplayer va server kodi yo‘q edi. Shu sabab bu boshlang‘ich demo tuzildi. Duel kodi ikki alohida telefonda ishlashi uchun server/backend kerak.

APK YASASH:
1. Kompyuterga Android Studio o‘rnating.
2. IQ_Duel_Android_Project papkasini Android Studio-да Open orqali oching.
3. Gradle sync tugashini kuting.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) ni tanlang.
5. APK odatda app/build/outputs/apk/debug/app-debug.apk manzilida hosil bo‘ladi.
6. APK-ni telefonga yuboring. Faqat o‘zingiz yaratgan loyiha APK-sini o‘rnating; Android so‘rasa, shu fayl menejeri uchun “Install unknown apps” ruxsatini vaqtincha yoqing.

Talablar: Android Studio va mos Android SDK. Bu muhitda APK kompilyatsiya qilinmadi.
