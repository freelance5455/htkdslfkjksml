Max Call 2027 — Ultra Modern UI

Ichida:
- Yangilangan futuristik neon-ko‘k dizayn
- Kontaktlar va qo‘ng‘iroqlar ro‘yxati uchun kartali interfeys
- Kamera/mikrofon ruxsatini so‘rash va mahalliy kamera preview
- Old/orqa kamerani almashtirish tugmasi (qurilma/WebView qo‘llasa)
- Kamera va mikrofonni yoqish/o‘chirish, video panelni yopish
- Davlat kodi, til va sozlamalar sahifalari

Muhim: kamera preview boshqa foydalanuvchiga video yubormaydi. Haqiqiy internet audio/video qo‘ng‘iroq uchun WebRTC/ZEGOCLOUD va xavfsiz backend/token sozlamalari kerak. Kamera WebView ichida ishlashi uchun Android kamera/mikrofon ruxsatlari va HTTPS yoki tegishli WebView sozlamalari zarur.

Boshlash: assets/web/index.html faylini loyihangizning web asset joyiga qo‘ying.
