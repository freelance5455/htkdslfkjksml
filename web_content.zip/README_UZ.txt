MAX CALL 2027 PRO — OQ-KO'K ZAMONAVIY DIZAYN

Fayllar:
- assets/web/index.html: HTML/CSS/JavaScript loyiha sahifasi
- design-preview/MaxCall_2027_yangi_dizayn.png: ko'rgazmali dizayn rasmi

Yangilanishlar:
- yangi oq-ko'k premium interfeys va yumaloq kartalar
- pastki menyu: Bosh sahifa, Kontaktlar, Qo'ng'iroqlar, Sozlamalar
- mobil ekranga moslashuvchi tartib
- kontakt saqlash/qidirish/o'chirish kabi mavjud JavaScript funksiyalari
- raqam terish, davlat kodi, kamera/mikrofonni sinash oynasi

Muhim:
Bu manba kodi arxivi, tayyor APK emas. SIM qo'ng'iroq Android telefon ilovasini ochadi. Kamera/mikrofon ekrani qurilmada mahalliy media sinovidir; boshqa foydalanuvchi bilan haqiqiy internet audio/video qo'ng'irog'i uchun WebRTC yoki ZEGOCLOUD va xavfsiz server integratsiyasi kerak.
