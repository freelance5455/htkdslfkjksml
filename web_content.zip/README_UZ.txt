QADAM — STUDY SPACE 2.0 (PWA)

YANGILANGAN FUNKSIYALAR
- Maqsadni tanlaganda Qadam avtomatik kundalik reja yaratadi (Portugal tili, tez yozish, C dasturlash, o‘qish yoki shaxsiy maqsad).
- Kunlik yuklamani yengil, o‘rtacha yoki jiddiy tanlash mumkin.
- Qolib ketgan vazifani bugunga ko‘chirish mumkin; bajarilmagan ish progressni oshirmaydi.
- Maqsadni vaqtincha tanaffusga qo‘yish mumkin.
- Sozlamalarda mavzuni almashtirish, yuklamani tanlash, zaxira olish/tiklash va ma’lumotlarni o‘chirish bor.


FAYLLAR
- index.html: ilova kodi
- manifest.webmanifest: ilova nomi va ikonkalari
- sw.js: internet uzilganda asosiy sahifani keshlangan nusxadan ochishga yordam beradi
- icons/: Android ikonkalari

ANDROID PLANSHTETGA O‘RNATISH (BEPUL)
1. Barcha fayllarni HTTPS manzilida joylashtirish kerak. Eng sodda bepul usullardan biri GitHub Pages.
2. GitHub’da yangi PUBLIC repository yarat. Maxfiy ma’lumotlarni repositoryga qo‘shma: kod ommaga ko‘rinadi.
3. ZIP ichidagi index.html, manifest.webmanifest, sw.js va icons papkasini repositoryning asosiy qismiga yukla.
4. Repository → Settings → Pages → Build and deployment bo‘limida Deploy from a branch ni tanla, main va /(root) ni belgilab Save bos.
5. GitHub bergan https://...github.io/... manzilini Android planshetda Chrome’da och.
6. Chrome ⋮ menyusi → Install app (yoki Add to Home screen) → Install/Add. Menyu nomi Android/Chrome versiyasiga qarab farq qilishi mumkin.

MA’LUMOTLAR
Vazifa va maqsadlar shu qurilmaning brauzer xotirasida saqlanadi. Qurilmalar orasida avtomatik sinxronlash yo‘q. Sozlamalar bo‘limidan Qadam_zaxira_....json faylini vaqti-vaqti bilan yuklab ol. Boshqa qurilmaga tiklashda shu faylni tanla. Brauzer ma’lumotlarini tozalashdan oldin zaxira nusxa ol.

O‘ZGARTIRISH
Ilova kodini keyinchalik index.html ichida tahrirlash mumkin. Yangilangan fayllarni GitHub repositoryga qayta yuklasang, sayt yangilanadi. Brauzer eski nusxani saqlab qolsa, sahifani qayta yukla yoki Chrome keshini yangila.

ESLATMA
Bu PWA; u APK fayli emas va Play Store’da avtomatik paydo bo‘lmaydi. GitHub Pages bepul statik hosting beradi, ammo public repositorydagi kod hammaga ko‘rinadi.
