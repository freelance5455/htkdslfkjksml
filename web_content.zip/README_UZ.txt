PCzona SUPER POYGA — Android loyiha manbalari

Muhim: bu ZIP tayyor APK emas, APK yasash uchun Android Studio loyihasidir.
APK yaratish:
1. ZIP faylni kompyuterda oching.
2. Android Studio -> Open -> PCzona_Super_Poyga papkasini tanlang.
3. Gradle sync tugashini kuting.
4. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
5. APK odatda app/build/outputs/apk/debug/app-debug.apk ichida bo‘ladi.

O‘yin oflayn ishlaydi. Telefonni landscape holatda tuting.
Chitlar aynan katta-kichik harflar bilan:
PCzona       = 9999 almaz
PCZONA       = 9999 tanga
PCzona Legend= 50 skin va PCzona super mashinasi
PCzona speed = oddiy mashina tezligini oshiradi

Bu boshlang‘ich 2D prototip; mashinalar rangli chizilgan shakllar bilan ko‘rsatiladi.
