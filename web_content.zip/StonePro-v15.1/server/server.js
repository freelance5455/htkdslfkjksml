"use strict";
// Stone Pro static server — no dependencies. Run: node server/server.js  (PORT=8080 behind HTTPS proxy)
const http=require("http"),fs=require("fs"),path=require("path"),zlib=require("zlib");
const ROOT=path.resolve(__dirname,"..","site"),PORT=+process.env.PORT||8080;
const T={".html":"text/html;charset=utf-8",".js":"text/javascript;charset=utf-8",".css":"text/css;charset=utf-8",".json":"application/json;charset=utf-8",".png":"image/png",".webp":"image/webp",".ttf":"font/ttf",".svg":"image/svg+xml"};
const H={"Content-Security-Policy":"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self'; manifest-src 'self'; worker-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'; object-src 'none'","X-Content-Type-Options":"nosniff","X-Frame-Options":"DENY","Referrer-Policy":"no-referrer","Strict-Transport-Security":"max-age=63072000; includeSubDomains","Permissions-Policy":"camera=(), microphone=(), geolocation=()"};
http.createServer((q,r)=>{
 if(q.method!=="GET"&&q.method!=="HEAD"){r.writeHead(405,H);return r.end()}
 let u;try{u=decodeURIComponent(new URL(q.url,"http://x").pathname)}catch(e){r.writeHead(400,H);return r.end()}
 if(u==="/health"){r.writeHead(200,{...H,"Content-Type":"application/json"});return r.end("{\"ok\":true}")}
 if(u.endsWith("/"))u+="index.html";
 const f=path.join(ROOT,u);
 if(!f.startsWith(ROOT+path.sep)||/\.(map|zip|mjs)$/.test(f)){r.writeHead(404,H);return r.end("Not found")}
 fs.readFile(f,(e,b)=>{if(e){r.writeHead(404,H);return r.end("Not found")}
  const x=path.extname(f),h={...H,"Content-Type":T[x]||"application/octet-stream","Cache-Control":/service-worker\.js$|index\.html$/.test(f)?"no-cache":"public,max-age=86400"};
  if(/^(\.html|\.js|\.css|\.json)$/.test(x)&&/gzip/.test(q.headers["accept-encoding"]||"")){h["Content-Encoding"]="gzip";b=zlib.gzipSync(b)}
  r.writeHead(200,h);r.end(q.method==="HEAD"?undefined:b)})
}).listen(PORT,()=>console.log("Stone Pro on :"+PORT));
