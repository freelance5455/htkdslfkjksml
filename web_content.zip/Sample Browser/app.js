const picker = document.getElementById("picker");
const sampleList = document.getElementById("sampleList");

const showAllBtn = document.getElementById("showAll");
const showFavsBtn = document.getElementById("showFavs");
const exportFavsBtn =
    document.getElementById("exportFavs");

let favorites =
    JSON.parse(localStorage.getItem("favorites") || "[]");

let currentAudio = null;
let loadedFiles = [];
let currentFilter = "all";


let displayedFiles = [];
let currentIndex = -1;
let autoNext = true;

function saveFavorites() {
    localStorage.setItem(
        "favorites",
        JSON.stringify(favorites)
    );
}

function getFileId(file) {

    if (file.webkitRelativePath &&
        file.webkitRelativePath.length > 0) {

        return file.webkitRelativePath;
    }

    return file.name;
}

function isFavorite(file) {
    return favorites.includes(
        getFileId(file)
    );
}

function toggleFavorite(file) {

    const id = getFileId(file);

    if (favorites.includes(id)) {

        favorites =
            favorites.filter(f => f !== id);

    } else {

        favorites.push(id);
    }

    saveFavorites();

    renderFiles();
}

function exportFavorites() {

    if (favorites.length === 0) {

        alert("Não existem favoritos.");

        return;
    }

    const content =
        favorites.join("\n");

    const blob =
        new Blob(
            [content],
            { type: "text/plain" }
        );

    const url =
        URL.createObjectURL(blob);

    const link =
        document.createElement("a");

    link.href = url;

    const now =
        new Date()
            .toISOString()
            .replace(/[:]/g, "-")
            .substring(0, 19);

    link.download =
        `favoritos_${now}.txt`;

    document.body.appendChild(link);

    link.click();

    document.body.removeChild(link);

    URL.revokeObjectURL(url);
}


function playFile(file, row) {

    if (currentAudio) {
        currentAudio.pause();
        currentAudio.currentTime = 0;
    }

    document
        .querySelectorAll(".playing")
        .forEach(el =>
            el.classList.remove("playing")
        );

    const url =
        URL.createObjectURL(file);

    currentAudio =
        new Audio(url);

    currentAudio.play();

    row.classList.add("playing");

    currentAudio.addEventListener(
        "ended",
        () => row.classList.remove("playing")
    );
}

function renderFiles() {

    sampleList.innerHTML = "";

    let files = [...loadedFiles];

    if (currentFilter === "favorites") {

        files = files.filter(file =>
            isFavorite(file)
        );
    }

    files.sort((a, b) =>
        a.name.localeCompare(b.name)
    );

    files.forEach(file => {

        const row =
            document.createElement("div");

        row.className = "sample";

        row.style.display = "flex";
        row.style.justifyContent =
            "space-between";

        row.style.alignItems =
            "center";

        const left =
            document.createElement("div");

        left.style.flex = "1";

        const star =
            document.createElement("span");

        star.textContent =
            isFavorite(file) ? "⭐" : "☆";

        star.style.cursor = "pointer";
        star.style.fontSize = "22px";
        star.style.marginRight = "10px";

        const name =
            document.createElement("span");

        name.textContent = file.name;
        name.style.cursor = "pointer";

        star.addEventListener(
            "click",
            (e) => {

                e.stopPropagation();

                toggleFavorite(file);
            }
        );

        name.addEventListener(
            "click",
            () => {

                playFile(file, row);
            }
        );

        left.appendChild(star);
        left.appendChild(name);

        row.appendChild(left);

        sampleList.appendChild(row);
    });
}

picker.addEventListener(
    "change",
    (event) => {

        loadedFiles =
            [...event.target.files]
                .filter(file => {

                    const name =
                        file.name.toLowerCase();

                    return (
                        name.endsWith(".wav") ||
                        name.endsWith(".mp3") ||
                        name.endsWith(".ogg")
                    );
                });

        renderFiles();
    }
);

showAllBtn.addEventListener(
    "click",
    () => {

        currentFilter = "all";

        renderFiles();
    }
);

showFavsBtn.addEventListener(
    "click",
    () => {

        currentFilter = "favorites";

        renderFiles();
    }
);

exportFavsBtn.addEventListener(
    "click",
    exportFavorites
);
