पूरण ठेकेदार हाजिरी ऐप — Android APK बनाने के निर्देश

यह Android Studio प्रोजेक्ट है, अभी तैयार APK नहीं है।

APK बनाने के लिए:
1. कंप्यूटर में Android Studio और Android SDK इंस्टॉल करें।
2. Android Studio में इस PooranThekedar फ़ोल्डर को Open करें।
3. Gradle Sync पूरा होने दें और यदि SDK 35 माँगे तो इंस्टॉल करें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK app/build/outputs/apk/debug/app-debug.apk में मिलेगा।

ऐप में हाजिरी, मजदूर सूची, मासिक रिपोर्ट और भुगतान डेटा इसी फोन में सेव होते हैं।
SMS बटन फोन के SMS ऐप को खोलता है; मैसेज भेजने के लिए उपयोगकर्ता को Send दबाना होगा।
डेटा हटने से बचाने के लिए समय-समय पर CSV रिपोर्ट डाउनलोड करें।
