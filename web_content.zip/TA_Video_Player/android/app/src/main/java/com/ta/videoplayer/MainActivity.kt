package com.ta.videoplayer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.Locale
import kotlin.math.abs

data class VideoEntry(val uri: Uri, val name: String, val folder: String, val duration: Long, val size: Long)

class VideoAdapter(
    private var entries: List<VideoEntry>,
    private val onClick: (VideoEntry) -> Unit
) : RecyclerView.Adapter<VideoAdapter.Holder>() {
    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.video_name)
        val info: TextView = v.findViewById(R.id.video_info)
    }
    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): Holder {
        val v = android.view.LayoutInflater.from(parent.context).inflate(R.layout.item_video, parent, false)
        return Holder(v)
    }
    override fun getItemCount() = entries.size
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = entries[position]
        holder.name.text = item.name
        holder.info.text = "${item.folder}  •  ${formatDuration(item.duration)}  •  ${formatSize(item.size)}"
        holder.itemView.setOnClickListener { onClick(item) }
    }
    fun update(list: List<VideoEntry>) { entries = list; notifyDataSetChanged() }
    companion object {
        fun formatDuration(ms: Long): String {
            val s = ms / 1000
            return String.format(Locale.getDefault(), "%d:%02d:%02d", s/3600, (s%3600)/60, s%60)
        }
        fun formatSize(bytes: Long): String = String.format(Locale.getDefault(), "%.1f MB", bytes/1048576.0)
    }
}

class MainActivity : AppCompatActivity() {
    private var libVLC: LibVLC? = null
    private var mediaPlayer: MediaPlayer? = null
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var adapter: VideoAdapter
    private lateinit var allVideos: List<VideoEntry>
    private lateinit var folderChips: LinearLayout
    private lateinit var libraryTitle: TextView
    private var selectedFolder = "সব ভিডিও"
    private val audioManager by lazy { getSystemService(AUDIO_SERVICE) as AudioManager }
    private var startX = 0f
    private var startY = 0f
    private var startPosition = 0L
    private var startVolume = 0
    private var startBrightness = 0.5f
    private var gestureMode = 0
    private var gestureUsed = false

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) scanVideos() else Toast.makeText(this, "ভিডিও দেখাতে মিডিয়া অনুমতি প্রয়োজন", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        videoLayout = findViewById(R.id.video_layout)
        folderChips = findViewById(R.id.folder_chips)
        libraryTitle = findViewById(R.id.library_title)

        libVLC = LibVLC(this, arrayListOf("--aout=opensles", "--audio-time-stretch", "--no-video-title-show"))
        mediaPlayer = MediaPlayer(libVLC).also { it.attachViews(videoLayout, null, false, false) }

        adapter = VideoAdapter(emptyList()) { playVideo(it.uri) }
        findViewById<RecyclerView>(R.id.video_list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }
        findViewById<Button>(R.id.scan_button).setOnClickListener { checkPermissionAndScan() }
        setupGestures()

        if (intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { playVideo(it) }
        }
        checkPermissionAndScan()
    }

    private fun checkPermissionAndScan() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) scanVideos()
        else permissionLauncher.launch(permission)
    }

    private fun scanVideos() {
        val list = mutableListOf<VideoEntry>()
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME, MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE
        )
        contentResolver.query(collection, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val folderCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
            val durationCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val sizeCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                list.add(VideoEntry(
                    Uri.withAppendedPath(collection, id.toString()),
                    c.getString(nameCol) ?: "ভিডিও",
                    c.getString(folderCol) ?: "Unknown",
                    c.getLong(durationCol), c.getLong(sizeCol)
                ))
            }
        }
        allVideos = list
        buildFolderChips()
        applyFolder()
        Toast.makeText(this, "${list.size}টি ভিডিও পাওয়া গেছে", Toast.LENGTH_SHORT).show()
    }

    private fun buildFolderChips() {
        folderChips.removeAllViews()
        (listOf("সব ভিডিও") + allVideos.map { it.folder }.distinct().sorted()).forEach { folder ->
            val b = Button(this).apply {
                text = folder; isAllCaps = false
                alpha = if (folder == selectedFolder) 1f else 0.65f
                setOnClickListener { selectedFolder = folder; applyFolder(); buildFolderChips() }
            }
            folderChips.addView(b)
        }
    }

    private fun applyFolder() {
        val filtered = if (selectedFolder == "সব ভিডিও") allVideos else allVideos.filter { it.folder == selectedFolder }
        adapter.update(filtered)
        libraryTitle.text = "$selectedFolder (${filtered.size})"
    }

    private fun playVideo(uri: Uri) {
        try {
            mediaPlayer?.stop()
            val media = Media(libVLC, uri)
            media.setHWDecoderEnabled(true, false)
            mediaPlayer?.media = media
            media.release()
            mediaPlayer?.play()
        } catch (e: Exception) {
            Toast.makeText(this, "এই ফাইলটি চালানো যাচ্ছে না: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun setupGestures() {
        videoLayout.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.x; startY = event.y
                    startPosition = mediaPlayer?.time ?: 0L
                    startVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                    startBrightness = window.attributes.screenBrightness.let { if (it < 0) 0.5f else it }
                    gestureMode = 0; gestureUsed = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - startX
                    val dy = event.y - startY
                    if (gestureMode == 0 && (abs(dx) > 18 || abs(dy) > 18))
                        gestureMode = if (abs(dx) > abs(dy)) 1 else if (startX < videoLayout.width / 2f) 3 else 2
                    when (gestureMode) {
                        1 -> {
                            gestureUsed = true
                            val duration = mediaPlayer?.length ?: 0L
                            if (duration > 0) mediaPlayer?.time = (startPosition + dx * 1000).coerceIn(0, duration)
                        }
                        2 -> {
                            gestureUsed = true
                            val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                            val value = (startVolume - dy / videoLayout.height * max).toInt().coerceIn(0, max)
                            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, value, 0)
                        }
                        3 -> {
                            gestureUsed = true
                            val value = (startBrightness - dy / videoLayout.height).coerceIn(0.02f, 1f)
                            window.attributes = window.attributes.apply { screenBrightness = value }
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> true
                else -> true
            }
        }
    }

    override fun onStart() {
        super.onStart()
        mediaPlayer?.attachViews(videoLayout, null, false, false)
    }

    override fun onStop() {
        mediaPlayer?.pause()
        mediaPlayer?.detachViews()
        super.onStop()
    }

    override fun onDestroy() {
        mediaPlayer?.release()
        mediaPlayer = null
        libVLC?.release()
        libVLC = null
        super.onDestroy()
    }
}
