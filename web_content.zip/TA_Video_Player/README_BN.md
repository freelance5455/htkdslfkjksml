# TA Video Player — Version 1.2

## এই সংস্করণে বড় পরিবর্তন
Android playback engine Media3 থেকে official VideoLAN LibVLC-তে নেওয়া হয়েছে। LibVLC সাধারণ Android player-এর তুলনায় বেশি container/codec এবং software-decoding fallback দেয়।

সমর্থন লক্ষ্য: MP4, MKV, AVI, WebM, FLV, 3GP, M4V, TS, MPG/MPEG এবং বিভিন্ন H.264/H.265/HEVC, VP9, AAC/MP3/AC3/DTS ইত্যাদি codec—তবে ফাইলের encoding, DRM, ফোনের RAM/CPU/GPU ও ABI অনুযায়ী ফল আলাদা হতে পারে।

- ফোনের ভিডিও অটো স্ক্যান ও ফোল্ডার ফিল্টার
- VLC engine দিয়ে ভিডিও চালানো
- বাম/ডান সোয়াইপে brightness/volume
- ডানে/বামে সোয়াইপে seek
- অন্য অ্যাপ থেকে “Open with / Share” করে TA Video Player-এ ভিডিও খোলা

## PLAYit Smart Muxer বিষয়ে জরুরি সীমাবদ্ধতা
PLAYit-এর নিজস্ব FAQ বলছে, Smart Muxer দিয়ে তৈরি কিছু ডাউনলোড করা ফাইল অন্য player-এ চলে না, কারণ প্রযুক্তিটি PLAYit-এর proprietary। LibVLC যোগ করলেও ওই private muxing format-এর নিশ্চয়তা দেওয়া যায় না। সাধারণ MP4/MKV/AVI ইত্যাদি ফাইলের সঙ্গে তুলনামূলক বেশি compatibility লক্ষ্য করা হয়েছে। Smart Muxer ফাইল চালাতে হলে PLAYit-এর অনুমোদিত technical specification বা ওই ফাইলের sample/metadata দরকার।

## ওয়েব ভার্সন
`web/index.html` Chrome/Edge-এ খুলে ভিডিও নির্বাচন করে চালান। Browser-এর codec সীমাবদ্ধতার কারণে Android app-এর মতো সব format চালানো সম্ভব নয়।

## APK তৈরি
1. Android Studio-তে `android` ফোল্ডার Open করুন।
2. Gradle Sync করুন। প্রথমবার LibVLC AAR ডাউনলোডে বড় ডাটা লাগতে পারে।
3. Build > Build Bundle(s) / APK(s) > Build APK(s)।
4. Debug APK: `android/app/build/outputs/apk/debug/app-debug.apk`

## বাস্তব অবস্থা
এই ZIP-এর Android কোড এখানে Android SDK/ফোনে build ও playback-test করা হয়নি। তাই APK-কে tested বলা হচ্ছে না। VideoLAN LibVLC-এর লাইসেন্স LGPL-2.1; বিতরণ করার আগে লাইসেন্স/নোটিশ সংযুক্তি ও compliance যাচাই করতে হবে।
