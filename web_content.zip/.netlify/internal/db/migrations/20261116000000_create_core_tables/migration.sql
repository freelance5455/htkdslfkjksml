CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  whatsapp TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL
);

CREATE TABLE gmail_parents (
  id SERIAL PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  app_password TEXT,
  status TEXT NOT NULL DEFAULT 'unchecked',
  status_message TEXT,
  checked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE gmail_aliases (
  id SERIAL PRIMARY KEY,
  parent_id INTEGER NOT NULL REFERENCES gmail_parents(id) ON DELETE CASCADE,
  email TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE stock_accounts (
  id SERIAL PRIMARY KEY,
  label TEXT,
  ml_email TEXT NOT NULL UNIQUE,
  ml_password TEXT NOT NULL DEFAULT '',
  parent_id INTEGER REFERENCES gmail_parents(id) ON DELETE SET NULL,
  ready_days INTEGER NOT NULL DEFAULT 14,
  added_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_match_at DATE,
  status TEXT NOT NULL DEFAULT 'auto',
  note TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE payment_methods (
  id SERIAL PRIMARY KEY,
  type TEXT NOT NULL,
  name TEXT NOT NULL,
  account_number TEXT,
  holder TEXT,
  qris_image TEXT,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE orders (
  id SERIAL PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  access_token TEXT NOT NULL,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  buyer_name TEXT NOT NULL,
  buyer_contact TEXT,
  account_id INTEGER REFERENCES stock_accounts(id) ON DELETE SET NULL,
  days INTEGER NOT NULL DEFAULT 1,
  amount INTEGER NOT NULL DEFAULT 0,
  payment_method_id INTEGER REFERENCES payment_methods(id) ON DELETE SET NULL,
  payment_proof TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reserved_until TIMESTAMPTZ,
  started_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ
);

CREATE INDEX orders_account_idx ON orders(account_id, status);
CREATE INDEX orders_user_idx ON orders(user_id);
CREATE UNIQUE INDEX users_username_lower_idx ON users (LOWER(username));
