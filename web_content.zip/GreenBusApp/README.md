# Green Bus Timetable - Android App

Yeh app aapke HTML timetable se banayi gayi hai.

## Features
- Complete bus timetable (Kabirwala ↔ Khanewal ↔ Jahaniya ↔ Qadirpur Raan)
- Mon-Fri / Sat-Sun switch
- Next bus countdown + progress bar
- Mini game (while you wait)
- Dark / Light mode
- LocalStorage support (selected route + high score)

## Kaise chalayein (Android Studio)

1. **Android Studio** open karo (latest recommended)
2. **Open** → `GreenBusApp` folder select karo
3. Gradle sync hone do (internet chahiye first time)
4. Emulator ya real phone connect karo
5. **Run** ▶ button dabao

## Requirements
- Android Studio Hedgehog (2023.1.1) ya uske baad
- Min Android 7.0 (API 24)
- Target Android 14 (API 34)

## APK banane ke liye
Android Studio mein:
- **Build → Generate Signed Bundle / APK**
- ya simply **Build → Build Bundle(s) / APK(s) → Build APK(s)**

APK `app/build/outputs/apk/debug/app-debug.apk` mein mil jayegi.

## Package Name
`com.greenbus.timetable`

## Made from
Original HTML by **Mubashar Ali**
