package com.gx.apkbuilder.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.gx.apkbuilder.databinding.ActivityAuthBinding
import com.gx.apkbuilder.utils.SecureStorage

class AuthActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAuthBinding
    private lateinit var storage: SecureStorage
    private var creating = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAuthBinding.inflate(layoutInflater); setContentView(binding.root)
        storage = SecureStorage(this)
        updateMode()
        binding.btnPrimary.setOnClickListener { submit() }
        binding.btnGuest.setOnClickListener { openDashboard("Guest") }
        binding.btnToggle.setOnClickListener { creating = !creating; updateMode() }
        binding.btnForgot.setOnClickListener {
            if (!storage.hasLocalAccount()) { toast("No local account exists") ; return@setOnClickListener }
            androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Reset local account?").setMessage("This removes the local account from this device. It does not affect any online account.")
                .setPositiveButton("Reset") { _, _ -> storage.clearLocalAccount(); updateMode(); toast("Local account removed") }
                .setNegativeButton("Cancel", null).show()
        }
    }
    private fun updateMode(){
        binding.etName.visibility=if(creating) android.view.View.VISIBLE else android.view.View.GONE
        binding.etConfirmPassword.visibility=if(creating) android.view.View.VISIBLE else android.view.View.GONE
        binding.btnPrimary.text=if(creating) "Create local account" else "Login"
        binding.btnToggle.text=if(creating) "Back to Login" else "Create Account"
        binding.btnForgot.visibility=if(!creating) android.view.View.VISIBLE else android.view.View.GONE
    }
    private fun submit(){
        val id=binding.etIdentity.text.toString().trim(); val pw=binding.etPassword.text.toString()
        if(id.isBlank() || pw.isBlank()){toast("Enter identity and password"); return}
        if(creating){
            val name=binding.etName.text.toString().trim(); val cp=binding.etConfirmPassword.text.toString()
            if(name.isBlank() || pw.length<6 || pw!=cp){toast("Use a name, 6+ character password and matching confirmation"); return}
            if(storage.createLocalAccount(name,id,pw)){toast("Local account created"); creating=false; updateMode()} else toast("A local account already exists")
        } else {
            if(storage.verify(id,pw)) openDashboard(storage.userName()) else toast("Login failed")
        }
    }
    private fun openDashboard(label:String){ startActivity(Intent(this,DashboardActivity::class.java).putExtra("LABEL",label)); finish() }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
