package com.gx.apkbuilder.engine

import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ProjectGenerator {
    data class AppConfig(
        val appName: String,
        val packageName: String,
        val versionCode: Int = 1,
        val versionName: String = "1.0.0",
        val allowInternet: Boolean = false
    )

    companion object {
        private const val MAX_FILES = 10_000
        private const val MAX_FILE_BYTES = 50L * 1024 * 1024
        private const val MAX_TOTAL_BYTES = 250L * 1024 * 1024
    }

    fun exportAndroidProject(webSourceDir: File, outputZip: File, config: AppConfig): Result<File> = runCatching {
        val source = webSourceDir.canonicalFile
        require(source.isDirectory) { "Project folder does not exist" }
        require(File(source, "index.html").isFile) { "index.html is missing" }
        require(Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+$").matches(config.packageName)) {
            "Invalid package name. Use at least two dot-separated Android identifier segments."
        }
        require(config.appName.isNotBlank() && config.appName.length <= 50 && config.appName.none { it.isISOControl() }) {
            "App name must be 1–50 printable characters"
        }
        require(config.versionCode > 0) { "Version code must be a positive integer" }
        require(Regex("^[A-Za-z0-9][A-Za-z0-9._+-]{0,49}$").matches(config.versionName)) {
            "Invalid version name. Use up to 50 letters, digits, dots, underscores, plus signs, or hyphens."
        }
        val out = outputZip.canonicalFile
        require(!out.path.startsWith(source.path + File.separator) && out != source) {
            "Export ZIP must be outside the source project folder"
        }
        out.parentFile?.let { require(it.mkdirs() || it.isDirectory) { "Could not create export folder" } }
        val tempOut = File(out.parentFile ?: File("."), out.name + ".tmp")
        if (tempOut.exists()) require(tempOut.delete()) { "Could not clear previous temporary export" }
        val files = source.walkTopDown().filter { it.isFile }.toList()
        require(files.size <= MAX_FILES) { "Project contains more than $MAX_FILES files" }
        var total = 0L
        files.forEach { file ->
            val canonical = file.canonicalFile
            require(canonical.path.startsWith(source.path + File.separator)) { "Project contains a file outside its root: ${file.name}" }
            require(file.length() <= MAX_FILE_BYTES) { "File exceeds 50 MiB: ${file.relativeTo(source)}" }
            total += file.length()
            require(total <= MAX_TOTAL_BYTES) { "Project exceeds the 250 MiB export limit" }
        }

        ZipOutputStream(FileOutputStream(tempOut)).use { zip ->
            put(zip, "build.gradle.kts", rootGradle())
            put(zip, "settings.gradle.kts", settingsGradle(config))
            put(zip, "gradle.properties", "org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\n")
            put(zip, "app/build.gradle.kts", appGradle(config))
            put(zip, "app/src/main/AndroidManifest.xml", manifest(config))
            put(zip, "app/src/main/res/drawable/ic_launcher.xml", icon())
            put(zip, "app/src/main/res/values/themes.xml", theme())
            put(zip, "app/src/main/res/values/strings.xml", "<resources><string name=\"app_name\">${xml(config.appName)}</string></resources>")
            val packagePath = config.packageName.replace('.', '/')
            put(zip, "app/src/main/java/$packagePath/MainActivity.kt", mainActivity(config))
            put(zip, "README.md", buildInstructions(config))
            files.forEach { file ->
                val relative = file.canonicalFile.relativeTo(source).invariantSeparatorsPath
                require(relative.split('/').none { it.isBlank() || it == "." || it == ".." }) { "Unsafe project file path: $relative" }
                addFile(zip, file, "app/src/main/assets/web/$relative")
            }
        }
        require(tempOut.isFile && tempOut.length() > 0L) { "Android project ZIP was not created" }
        if (out.exists()) require(out.delete()) { "Could not replace previous export file" }
        check(tempOut.renameTo(out)) { "Could not finalize exported Android project ZIP" }
        out
    }

    private fun rootGradle() = """
        plugins {
            id("com.android.application") version "8.6.1" apply false
            id("org.jetbrains.kotlin.android") version "1.9.24" apply false
        }
    """.trimIndent()

    private fun settingsGradle(c: AppConfig) = """
        pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
        dependencyResolutionManagement {
            repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
            repositories { google(); mavenCentral() }
        }
        rootProject.name = "${gradleString(c.appName)}"
        include(":app")
    """.trimIndent()

    private fun appGradle(c: AppConfig) = """
        plugins {
            id("com.android.application")
            id("org.jetbrains.kotlin.android")
        }
        android {
            namespace = "${c.packageName}"
            compileSdk = 35
            defaultConfig {
                applicationId = "${c.packageName}"
                minSdk = 24
                targetSdk = 35
                versionCode = ${c.versionCode}
                versionName = "${c.versionName}"
            }
            compileOptions {
                sourceCompatibility = JavaVersion.VERSION_17
                targetCompatibility = JavaVersion.VERSION_17
            }
            kotlinOptions { jvmTarget = "17" }
        }
        dependencies {
            implementation("androidx.core:core-ktx:1.13.1")
            implementation("androidx.appcompat:appcompat:1.7.0")
            implementation("androidx.webkit:webkit:1.12.1")
        }
    """.trimIndent()

    private fun manifest(c: AppConfig): String {
        val internet = if (c.allowInternet) "<uses-permission android:name=\"android.permission.INTERNET\" />" else ""
        return """
            <?xml version="1.0" encoding="utf-8"?>
            <manifest xmlns:android="http://schemas.android.com/apk/res/android">
                $internet
                <application
                    android:theme="@style/AppTheme"
                    android:icon="@drawable/ic_launcher"
                    android:label="@string/app_name"
                    android:usesCleartextTraffic="false">
                    <activity android:name=".MainActivity" android:exported="true">
                        <intent-filter>
                            <action android:name="android.intent.action.MAIN" />
                            <category android:name="android.intent.category.LAUNCHER" />
                        </intent-filter>
                    </activity>
                </application>
            </manifest>
        """.trimIndent()
    }

    private fun theme() = """
        <resources>
            <style name="AppTheme" parent="Theme.AppCompat.DayNight.NoActionBar">
                <item name="android:fontFamily">sans</item>
                <item name="android:windowBackground">#0A0C10</item>
            </style>
        </resources>
    """.trimIndent()

    private fun mainActivity(c: AppConfig) = """
        package ${c.packageName}

        import android.app.Activity
        import android.os.Bundle
        import android.webkit.WebResourceRequest
        import android.webkit.WebResourceResponse
        import android.webkit.WebView
        import android.webkit.WebViewClient
        import androidx.webkit.WebViewAssetLoader

        class MainActivity : Activity() {
            private lateinit var assetLoader: WebViewAssetLoader

            override fun onCreate(savedInstanceState: Bundle?) {
                super.onCreate(savedInstanceState)
                assetLoader = WebViewAssetLoader.Builder()
                    .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
                    .build()
                val webView = WebView(this)
                webView.settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    allowFileAccess = false
                    allowContentAccess = false
                    mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
                }
                webView.webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                        val uri = request?.url ?: return null
                        if (uri.host != "appassets.androidplatform.net" || uri.scheme != "https") return null
                        return assetLoader.shouldInterceptRequest(uri)
                    }
                }
                setContentView(webView)
                webView.loadUrl("https://appassets.androidplatform.net/assets/web/index.html")
            }
        }
    """.trimIndent()

    private fun buildInstructions(c: AppConfig) = """
        # ${c.appName} — generated Android project

        This archive is **Android source code**, not a compiled APK.

        ## Build a debug APK
        1. Open this folder in Android Studio (a recent version with Android SDK Platform 35), or install JDK 17 and Gradle 8.7.
        2. From this folder run: `gradle :app:assembleDebug`.
        3. The APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

        The project uses Android Gradle Plugin 8.6.1, Kotlin 1.9.24, and `WebViewAssetLoader` to serve packaged web content from a secure HTTPS-like app origin. Package ID: `${c.packageName}`; version: `${c.versionName}` (${c.versionCode}).

        Release signing is not configured. Configure signing with your own protected keystore in a local Gradle properties file before distributing a release build. Do not commit keystore passwords.
    """.trimIndent()

    private fun addFile(zip: ZipOutputStream, file: File, path: String) {
        zip.putNextEntry(ZipEntry(path))
        file.inputStream().use { it.copyTo(zip) }
        zip.closeEntry()
    }

    private fun put(zip: ZipOutputStream, path: String, text: String) {
        zip.putNextEntry(ZipEntry(path))
        zip.write(text.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun icon() = """
        <?xml version="1.0" encoding="utf-8"?>
        <vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
            <path android:fillColor="#7C5CFC" android:pathData="M54,4A50,50 0,1 0,54 104A50,50 0,1 0,54 4" />
            <path android:fillColor="#FFFFFF" android:pathData="M29,33h50v8H29zM29,50h34v8H29zM29,67h43v8H29z" />
        </vector>
    """.trimIndent()

    private fun gradleString(value: String): String = value
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\$", "\\\$")

    private fun xml(value: String): String = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")
}
