package com.gx.apkbuilder.engine

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

class ZipManager(private val context: Context) {
    companion object {
        private const val MAX_ENTRIES = 10_000
        private const val MAX_TOTAL_BYTES = 250L * 1024 * 1024
        private const val MAX_ENTRY_BYTES = 50L * 1024 * 1024
        private const val MAX_PATH_DEPTH = 64
    }

    suspend fun importAndExtractSafe(zipUri: Uri, projectName: String): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val projectsDir = File(context.filesDir, "projects").apply { mkdirs() }
            val safeName = projectName.replace(Regex("[^A-Za-z0-9._-]"), "_").trim('.', '_').ifBlank { "Project" }
            val targetDir = File(projectsDir, uniqueName(projectsDir, safeName))
            require(targetDir.mkdirs()) { "Could not create project folder" }
            try {
                val canonicalTarget = targetDir.canonicalFile
                val seenFiles = mutableSetOf<String>()
                val seenDirectories = mutableSetOf<String>()
                var count = 0
                var total = 0L
                var extractedAny = false
                context.contentResolver.openInputStream(zipUri)?.use { input ->
                    ZipInputStream(input.buffered()).use { zis ->
                        var entry = zis.nextEntry
                        while (entry != null) {
                            require(++count <= MAX_ENTRIES) { "ZIP contains too many entries (limit: $MAX_ENTRIES)" }
                            val rawName = entry.name ?: error("Invalid ZIP entry")
                            require(rawName.none { it.code == 0 }) { "ZIP contains an invalid filename" }
                            val normalized = rawName.replace('\\', '/')
                            require(!normalized.startsWith('/') && !Regex("^[A-Za-z]:").containsMatchIn(normalized)) {
                                "Absolute ZIP paths are not allowed: $rawName"
                            }
                            val isDirectory = entry.isDirectory || normalized.endsWith('/')
                            val relative = normalized.trimEnd('/')
                            require(relative.isNotBlank()) { "ZIP contains an empty path" }
                            val segments = relative.split('/')
                            require(segments.size <= MAX_PATH_DEPTH && segments.all { it.isNotBlank() && it != "." && it != ".." }) {
                                "Unsafe or excessively deep ZIP path: $rawName"
                            }
                            val out = File(canonicalTarget, relative).canonicalFile
                            require(out.path.startsWith(canonicalTarget.path + File.separator)) { "Path traversal attempt detected" }

                            if (isDirectory) {
                                require(relative !in seenFiles) { "ZIP path is both a file and directory: $relative" }
                                require(seenDirectories.add(relative)) { "Duplicate ZIP directory: $relative" }
                                require(out.mkdirs() || out.isDirectory) { "Could not create directory: $relative" }
                            } else {
                                require(seenFiles.add(relative)) { "Duplicate ZIP file entry: $relative" }
                                require(relative !in seenDirectories) { "ZIP path is both a file and directory: $relative" }
                                out.parentFile?.let { parent -> require(parent.mkdirs() || parent.isDirectory) { "Could not create directory" } }
                                require(!out.exists()) { "ZIP entry conflicts with an existing path: $relative" }
                                var written = 0L
                                FileOutputStream(out).use { fos ->
                                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                                    while (true) {
                                        val n = zis.read(buffer)
                                        if (n < 0) break
                                        if (n == 0) continue
                                        written += n
                                        total += n
                                        require(written <= MAX_ENTRY_BYTES) { "ZIP entry exceeds the 50 MiB limit: $relative" }
                                        require(total <= MAX_TOTAL_BYTES) { "ZIP expands beyond the 250 MiB safety limit" }
                                        fos.write(buffer, 0, n)
                                    }
                                }
                                extractedAny = true
                            }
                            zis.closeEntry()
                            entry = zis.nextEntry
                        }
                    }
                } ?: error("Unable to read ZIP file")
                require(extractedAny) { "ZIP archive is empty" }
                ProjectRootNormalizer.normalize(targetDir)
            } catch (t: Throwable) {
                targetDir.deleteRecursively()
                throw t
            }
        }.onFailure { if (it is CancellationException) throw it }
    }

    private fun uniqueName(parent: File, base: String): String {
        var candidate = base
        var suffix = 2
        while (File(parent, candidate).exists()) {
            candidate = "$base-$suffix"
            suffix++
        }
        return candidate
    }

}
