package com.gx.apkbuilder.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.gx.apkbuilder.R
import com.gx.apkbuilder.databinding.ActivityDashboardBinding
import com.gx.apkbuilder.engine.ProjectManager
import com.gx.apkbuilder.engine.ZipManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

class DashboardActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDashboardBinding
    private lateinit var pm: ProjectManager

    private val zipPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) lifecycleScope.launch {
            val result = ZipManager(this@DashboardActivity).importAndExtractSafe(uri, "ImportedProject")
            result.fold({ open(it.path) }, { toast(it.message ?: "ZIP import failed") })
        }
    }
    private val htmlPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) lifecycleScope.launch {
            try {
                open(pm.importHtml(uri, "ImportedHtml.html").path)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (failure: Exception) {
                toast(failure.message ?: "HTML import failed")
            }
        }
    }
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) lifecycleScope.launch {
            try {
                open(pm.importFolder(uri, "ImportedFolder").path)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (failure: Exception) {
                toast(failure.message ?: "Folder import failed")
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        pm = ProjectManager(this)
        binding.tvWelcome.text = "Welcome, ${intent.getStringExtra("LABEL") ?: "Guest"}"
        binding.btnZip.setOnClickListener { zipPicker.launch("application/zip") }
        binding.btnHtml.setOnClickListener { htmlPicker.launch("text/html") }
        binding.btnFolder.setOnClickListener { folderPicker.launch(null) }
        binding.btnNew.setOnClickListener { open(pm.createDemoProject().path) }
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized) refresh()
    }

    private fun refresh() {
        binding.projectContainer.removeAllViews()
        val projects = pm.listProjects()
        if (projects.isEmpty()) {
            val text = TextView(this).apply {
                text = "No projects yet. Import a ZIP or create the demo project."
                setTextColor(getColor(R.color.gx_muted))
                setPadding(4, 24, 4, 24)
            }
            binding.projectContainer.addView(text)
            return
        }
        projects.forEach { project ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(12, 12, 12, 12)
                setBackgroundColor(getColor(R.color.gx_card))
            }
            val text = TextView(this).apply {
                this.text = "${project.name}\n${project.walkTopDown().count { it.isFile }} files"
                setTextColor(getColor(R.color.gx_text))
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val openButton = Button(this).apply {
                text = "Open"
                setOnClickListener { open(project.path) }
            }
            row.addView(text)
            row.addView(openButton)
            binding.projectContainer.addView(row)
            binding.projectContainer.addView(TextView(this).apply { height = 10 })
        }
    }

    private fun open(path: String) {
        startActivity(Intent(this, WorkspaceActivity::class.java).putExtra("PROJECT_PATH", path))
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
