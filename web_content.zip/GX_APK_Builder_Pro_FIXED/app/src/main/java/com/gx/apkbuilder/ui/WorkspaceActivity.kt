package com.gx.apkbuilder.ui

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.gx.apkbuilder.R
import com.gx.apkbuilder.databinding.ActivityWorkspaceBinding
import com.gx.apkbuilder.databinding.DialogEditorBinding
import com.gx.apkbuilder.engine.ProjectGenerator
import com.gx.apkbuilder.engine.ProjectValidator
import java.io.File

class WorkspaceActivity : AppCompatActivity() {
    private lateinit var binding: ActivityWorkspaceBinding
    private lateinit var project: File
    private val editable = setOf("html", "htm", "css", "js", "json", "txt", "xml", "md")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWorkspaceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val path = intent.getStringExtra("PROJECT_PATH")
        if (path.isNullOrBlank()) { finish(); return }
        project = File(path)
        binding.tvProjectName.text = project.name
        binding.btnPreview.setOnClickListener { preview() }
        binding.btnExport.setOnClickListener { exportProject() }
        binding.btnBuild.setOnClickListener { showBuildInfo() }
        validate()
        renderFiles()
    }

    private fun validate() {
        val issues = ProjectValidator(project).validate()
        val fatal = issues.count { it.fatal }
        val notes = issues.count { !it.fatal }
        binding.tvValidation.text = if (fatal > 0) {
            "❌ $fatal fatal issue(s) • ⚠ $notes note(s)"
        } else {
            "✅ No fatal issues • $notes note(s)"
        }
    }

    private fun renderFiles() {
        binding.fileContainer.removeAllViews()
        project.walkTopDown()
            .filter { it.isFile }
            .sortedBy { it.relativeTo(project).path }
            .forEach { file ->
                val row = TextView(this)
                val rel = file.relativeTo(project).invariantSeparatorsPath
                row.text = if (file.extension.lowercase() in editable) "✎ $rel" else "▣ $rel"
                row.setPadding(12, 14, 12, 14)
                row.setTextColor(getColor(R.color.gx_text))
                row.textSize = 15f
                if (file.extension.lowercase() in editable) row.setOnClickListener { edit(file) }
                binding.fileContainer.addView(row)
            }
    }

    private fun edit(file: File) {
        val vb = DialogEditorBinding.inflate(layoutInflater)
        vb.tvFile.text = file.relativeTo(project).invariantSeparatorsPath
        vb.etCode.setText(runCatching { file.readText() }.getOrDefault(""))
        val dialog = AlertDialog.Builder(this)
            .setTitle("Edit file")
            .setView(vb.root)
            .setNegativeButton("Cancel", null)
            .create()

        vb.btnSave.setOnClickListener {
            val saved = runCatching {
                file.writeText(vb.etCode.text.toString())
                validate()
                renderFiles()
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            }.onFailure {
                Toast.makeText(this, it.message ?: "Save failed", Toast.LENGTH_SHORT).show()
            }.isSuccess
            if (saved) dialog.dismiss()
        }
        dialog.show()
    }

    private fun preview() {
        if (!File(project, "index.html").isFile) {
            Toast.makeText(this, "index.html is missing", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, PreviewActivity::class.java).putExtra("PROJECT_PATH", project.path))
    }

    private fun exportProject() {
        val packageSuffix = project.name.lowercase().replace(Regex("[^a-z0-9]"), "").ifBlank { "app" }
        val safeSuffix = if (packageSuffix.first().isLetter()) packageSuffix else "app$packageSuffix"
        val pkg = "com.gx.generated.$safeSuffix"
        AlertDialog.Builder(this)
            .setTitle("Internet access for generated app")
            .setMessage("Does this web project need online APIs, remote images, CDN scripts, or external stylesheets? Choose internet access only if the project needs it.")
            .setPositiveButton("Allow internet") { _, _ -> exportProjectZip(pkg, allowInternet = true) }
            .setNegativeButton("Offline only") { _, _ -> exportProjectZip(pkg, allowInternet = false) }
            .setNeutralButton("Cancel", null)
            .show()
    }

    private fun exportProjectZip(packageName: String, allowInternet: Boolean) {
        val exportDir = File(cacheDir, "gx-exports")
        val out = File(exportDir, "${project.name}_AndroidProject.zip")
        val result = ProjectGenerator().exportAndroidProject(
            project,
            out,
            ProjectGenerator.AppConfig(project.name, packageName, allowInternet = allowInternet)
        )
        result.fold(::share, { Toast.makeText(this, it.message ?: "Export failed", Toast.LENGTH_LONG).show() })
    }

    private fun share(file: File) {
        val uri = FileProvider.getUriForFile(this, "com.gx.apkbuilder.pro.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Share Android project"))
    }

    private fun showBuildInfo() {
        AlertDialog.Builder(this)
            .setTitle("APK build unavailable")
            .setMessage("This app does not contain an Android SDK/Gradle build engine, and no remote build backend is configured. No APK was created. Use Export Android Project, open the source ZIP in Android Studio with Android SDK Platform 35, then build :app:assembleDebug. The exported Gradle project is source code, not an APK.")
            .setPositiveButton("OK", null)
            .show()
    }
}
