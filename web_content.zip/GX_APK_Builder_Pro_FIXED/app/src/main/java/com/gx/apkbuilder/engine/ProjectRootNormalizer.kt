package com.gx.apkbuilder.engine

import java.io.File

/** Ensures imported web projects have a root-level index.html for preview and export. */
internal object ProjectRootNormalizer {
    fun normalize(projectRoot: File): File {
        require(projectRoot.isDirectory) { "Project folder does not exist" }
        val root = projectRoot.canonicalFile
        val index = File(root, "index.html")
        if (index.isFile) return root

        val htmlFiles = root.walkTopDown()
            .filter { it.isFile && (it.extension.equals("html", true) || it.extension.equals("htm", true)) }
            .toList()
        require(htmlFiles.isNotEmpty()) {
            "No HTML files found. Import a web project containing an .html or .htm page."
        }

        val preferred = htmlFiles.filter { it.name.equals("index.html", true) || it.name.equals("index.htm", true) }
        val pool = if (preferred.isNotEmpty()) preferred else htmlFiles
        val shallowestDepth = pool.minOf { relativeDepth(it, root) }
        val shallowest = pool.filter { relativeDepth(it, root) == shallowestDepth }
        require(shallowest.size == 1) {
            "The ZIP/folder has multiple possible entry pages. Keep one index.html/index.htm at the project root and import again."
        }
        val entry = shallowest.single()
        val sourceDir = entry.parentFile.canonicalFile

        if (sourceDir != root) {
            require(sourceDir.path.startsWith(root.path + File.separator)) { "Entry page is outside the project folder" }
            val children = sourceDir.listFiles() ?: error("Could not read the selected project folder")
            for (child in children) {
                val destination = File(root, child.name)
                require(!destination.exists()) {
                    "Cannot flatten the project because '${child.name}' already exists at the archive root. Remove the duplicate wrapper/root files and import again."
                }
                val moved = child.renameTo(destination)
                if (!moved) {
                    if (child.isDirectory) child.copyRecursively(destination, overwrite = false)
                    else child.copyTo(destination, overwrite = false)
                    check(child.deleteRecursively()) { "Could not clean the nested project folder" }
                }
            }

            // Remove only now-empty wrapper directories; never recursively delete unrelated files.
            var wrapper: File? = sourceDir
            while (wrapper != null && wrapper != root) {
                val parent = wrapper.parentFile
                if (wrapper.list()?.isEmpty() == true) wrapper.delete()
                wrapper = parent
            }
        }

        val promotedEntry = File(root, entry.name)
        if (promotedEntry.canonicalFile != index.canonicalFile) {
            require(!index.exists()) { "Both index.html and another entry page exist; choose index.html explicitly." }
            promotedEntry.copyTo(index, overwrite = false)
        }
        require(index.isFile) { "Unable to create a root-level index.html entry page" }
        return root
    }

    private fun relativeDepth(file: File, root: File): Int =
        file.canonicalFile.relativeTo(root).invariantSeparatorsPath.split('/').size
}
