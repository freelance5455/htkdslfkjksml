package com.gx.apkbuilder.ui

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.webkit.ConsoleMessage
import android.webkit.MimeTypeMap
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.gx.apkbuilder.databinding.ActivityPreviewBinding
import java.io.File
import java.io.FileInputStream
import java.net.URLConnection

class PreviewActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPreviewBinding
    private lateinit var project: File
    private var callback: ValueCallback<Array<Uri>>? = null
    private val picker = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        callback?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
        callback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        binding = ActivityPreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val path = intent.getStringExtra("PROJECT_PATH")
        if (path.isNullOrBlank()) {
            finish()
            return
        }
        project = File(path).canonicalFile
        if (!project.isDirectory) {
            Toast.makeText(this, "Project folder is unavailable", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        setup()
        binding.webView.loadUrl("https://gx.local/index.html")
    }

    private fun setup() {
        binding.progress.visibility = android.view.View.VISIBLE
        binding.webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        binding.webView.webViewClient = LocalClient(project) { binding.progress.visibility = android.view.View.GONE }
        binding.webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, c: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                callback?.onReceiveValue(null)
                callback = c
                picker.launch("*/*")
                return true
            }

            override fun onConsoleMessage(m: ConsoleMessage?): Boolean {
                m?.let { Log.d("GX_WEB_CONSOLE", "${it.message()} -- line ${it.lineNumber()}") }
                return true
            }
        }
    }

    override fun onBackPressed() {
        if (binding.webView.canGoBack()) binding.webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        callback?.onReceiveValue(null)
        callback = null
        if (::binding.isInitialized) {
            binding.webView.stopLoading()
            (binding.webView.parent as? ViewGroup)?.removeView(binding.webView)
            binding.webView.destroy()
        }
        super.onDestroy()
    }

    private class LocalClient(private val root: File, private val ready: () -> Unit) : WebViewClient() {
        override fun onPageFinished(v: WebView?, url: String?) {
            super.onPageFinished(v, url)
            ready()
        }

        override fun shouldInterceptRequest(v: WebView?, request: WebResourceRequest?): WebResourceResponse? {
            val uri = request?.url ?: return null
            if (uri.scheme != "https" || uri.host != "gx.local") return null
            return serve(uri.path ?: "/")
        }

        override fun shouldInterceptRequest(v: WebView?, url: String?): WebResourceResponse? {
            val uri = url?.let(Uri::parse) ?: return null
            if (uri.scheme != "https" || uri.host != "gx.local") return null
            return serve(uri.path ?: "/")
        }

        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val uri = request?.url ?: return true
            // Only the synthetic local project origin is navigable in this preview.
            if (uri.scheme == "https" && uri.host == "gx.local") return false
            return true
        }

        private fun serve(path: String): WebResourceResponse? {
            if (!path.startsWith("/")) return null
            val normalizedPath = if (path == "/") "/index.html" else path
            val target = runCatching { File(root, normalizedPath.removePrefix("/")).canonicalFile }.getOrNull()
                ?: return notFound()
            if (!target.path.startsWith(root.canonicalPath + File.separator) || !target.isFile) return notFound()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(target.extension.lowercase())
                ?: URLConnection.guessContentTypeFromName(target.name)
                ?: "application/octet-stream"
            return runCatching { WebResourceResponse(mime, null, FileInputStream(target)) }.getOrElse { notFound() }
        }

        private fun notFound() = WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", emptyMap(), null)
    }
}
