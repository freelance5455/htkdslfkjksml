package com.gx.apkbuilder

import android.app.Application
import java.io.File

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val log = File(filesDir, "crash.log")
                log.appendText("\n[$thread]\n${throwable.stackTraceToString()}\n")
            } catch (_: Exception) { }
            android.os.Process.killProcess(android.os.Process.myPid())
        }
    }
}
