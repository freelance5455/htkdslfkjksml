package com.gx.apkbuilder.engine

import java.io.File
import java.net.URI

class ProjectValidator(private val projectDir: File) {
    data class ValidationResult(val fatal: Boolean, val message: String, val filePath: String? = null)

    companion object {
        private const val MAX_FILES = 10_000
        private const val MAX_TOTAL_BYTES = 250L * 1024 * 1024
        private const val MAX_FILE_BYTES = 50L * 1024 * 1024
        private val supportedText = setOf("html", "htm", "css", "js", "json", "txt", "md", "xml")
    }

    fun validate(): List<ValidationResult> {
        val issues = mutableListOf<ValidationResult>()
        val root = runCatching { projectDir.canonicalFile }.getOrElse { projectDir.absoluteFile }
        if (!root.isDirectory) return listOf(ValidationResult(true, "Project folder is unavailable"))
        val index = File(root, "index.html")
        if (!index.isFile) issues += ValidationResult(true, "Missing index.html; preview and source export require an entry page")

        val files = root.walkTopDown().filter { it.isFile }.toList()
        if (files.size > MAX_FILES) issues += ValidationResult(true, "Project contains more than $MAX_FILES files")
        var totalBytes = 0L
        var totalSizeReported = false
        files.forEach { file ->
            val canonical = runCatching { file.canonicalFile }.getOrNull()
            if (canonical == null || !canonical.path.startsWith(root.path + File.separator)) {
                issues += ValidationResult(true, "File resolves outside the project folder", relative(file, root))
                return@forEach
            }
            if (file.length() > MAX_FILE_BYTES) {
                issues += ValidationResult(true, "File exceeds the 50 MiB project limit", relative(file, root))
            }
            totalBytes += file.length()
            if (totalBytes > MAX_TOTAL_BYTES && !totalSizeReported) {
                issues += ValidationResult(true, "Project exceeds the 250 MiB total size limit")
                totalSizeReported = true
            }
        }

        for (file in files) {
            val ext = file.extension.lowercase()
            if (ext !in supportedText || file.length() > MAX_FILE_BYTES) continue
            val contentResult = runCatching { file.readText(Charsets.UTF_8) }
            if (contentResult.isFailure) {
                issues += ValidationResult(false, "Could not read as UTF-8 text; the file may be binary or use another encoding", relative(file, root))
                continue
            }
            val content = contentResult.getOrThrow()
            val filePath = relative(file, root)

            if (Regex("(?i)([A-Z]:\\\\|file:///([A-Za-z]:|storage/))").containsMatchIn(content)) {
                issues += ValidationResult(false, "Absolute desktop/device file path detected", filePath)
            }
            if (Regex("(?i)https?://").containsMatchIn(content)) {
                issues += ValidationResult(false, "External HTTP/HTTPS resource detected; offline builds may not load it", filePath)
            }

            if (ext == "html" || ext == "htm") {
                if (!Regex("(?i)<meta\\s+[^>]*name\\s*=\\s*[\"']viewport[\"']").containsMatchIn(content)) {
                    issues += ValidationResult(false, "Mobile viewport metadata is missing", filePath)
                }
                val refs = Regex("(?i)(?:src|href|poster|data)\\s*=\\s*[\"']([^\"'#]+)")
                    .findAll(content).map { it.groupValues[1].trim() }
                refs.forEach { ref -> checkReference(file, root, ref, issues) }
                val inlineStyleBlocks = Regex("(?is)<style\\b[^>]*>(.*?)</style>").findAll(content)
                inlineStyleBlocks.forEach { block -> checkCssReferences(file, root, block.groupValues[1], issues) }
            }
            if (ext == "css") checkCssReferences(file, root, content, issues)
        }

        if (issues.isEmpty()) issues += ValidationResult(false, "Validation completed: no issues detected")
        else if (issues.none { it.message.startsWith("Validation completed") }) {
            issues += ValidationResult(false, "Validation completed; review the warnings above")
        }
        return issues
    }

    private fun checkCssReferences(file: File, root: File, content: String, issues: MutableList<ValidationResult>) {
        val urls = Regex("(?i)url\\(\\s*(['\"]?)(.*?)\\1\\s*\\)")
            .findAll(content).map { it.groupValues[2].trim() }
        urls.forEach { checkReference(file, root, it, issues) }
    }

    private fun checkReference(file: File, root: File, rawRef: String, issues: MutableList<ValidationResult>) {
        val ref = rawRef.trim().trim('"', '\'')
        if (ref.isBlank() || ref.startsWith("#") || ref.startsWith("data:", true) ||
            ref.startsWith("http://", true) || ref.startsWith("https://", true) || ref.startsWith("//") ||
            ref.startsWith("mailto:", true) || ref.startsWith("tel:", true)) return
        val scheme = runCatching { URI(ref).scheme }.getOrNull()
        if (scheme != null) {
            issues += ValidationResult(false, "Unsupported local resource URL scheme '$scheme'", relative(file, root))
            return
        }
        val path = runCatching { URI(ref).path }.getOrNull()?.substringBefore('#')?.ifBlank { null } ?: return
        val target = runCatching { File(file.parentFile, path).canonicalFile }.getOrNull()
        if (target == null || !target.path.startsWith(root.path + File.separator) || !target.exists()) {
            issues += ValidationResult(false, "Referenced local file not found: $ref", relative(file, root))
        }
    }

    private fun relative(file: File, root: File): String = runCatching {
        file.canonicalFile.relativeTo(root).invariantSeparatorsPath
    }.getOrDefault(file.name)
}
