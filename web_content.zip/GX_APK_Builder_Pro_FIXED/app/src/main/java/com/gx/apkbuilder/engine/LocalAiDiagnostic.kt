package com.gx.apkbuilder.engine

class LocalAiDiagnostic {
    fun explain(question: String, context: String = ""): String {
        val q = question.lowercase()
        return when {
            "blank" in q || "white screen" in q -> "Check index.html, relative CSS/JS/image paths, WebView JavaScript, and browser console errors. This preview loads local files from an HTTPS-like local origin rather than file://."
            "zip" in q -> "Use Import ZIP. The importer blocks path traversal and oversized ZIP extraction. Keep index.html either at ZIP root or inside one single top-level folder."
            "file upload" in q || "input type=file" in q -> "The preview uses Android's file chooser through WebChromeClient.onShowFileChooser. Make sure your HTML uses <input type=\"file\">."
            "javascript" in q || "js error" in q -> "Open the file containing the error, check missing elements/paths, and use the project validator. Console output is also recorded by PreviewActivity."
            "apk" in q || "build" in q -> "This demo prepares and exports a complete Android project. A real APK build needs an Android build toolchain; this app intentionally does not fake APK output."
            else -> "Local diagnostic: start by checking index.html, relative paths, JavaScript errors, unsupported browser APIs, and external HTTP resources. ${if (context.isNotBlank()) "Context: $context" else ""}".trim()
        }
    }
}
