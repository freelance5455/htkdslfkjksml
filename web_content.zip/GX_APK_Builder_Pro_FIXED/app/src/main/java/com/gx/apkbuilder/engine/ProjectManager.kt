package com.gx.apkbuilder.engine

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class ProjectManager(private val context: Context) {
    companion object {
        private const val MAX_FILES = 10_000
        private const val MAX_FILE_BYTES = 50L * 1024 * 1024
        private const val MAX_TOTAL_BYTES = 250L * 1024 * 1024
        private const val MAX_DEPTH = 64
    }

    private val root = File(context.filesDir, "projects").apply { mkdirs() }

    fun listProjects(): List<File> =
        root.listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun createDemoProject(name: String = "GX Demo Web App"): File {
        val safe = safeProjectName(name)
        val dir = File(root, uniqueName(safe))
        check(dir.mkdirs()) { "Could not create project folder" }
        File(dir, "index.html").writeText(
            """<!doctype html>
<html><head><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="style.css"></head>
<body><main><div class="logo">GX</div><h1>GX Demo App</h1><p>This project is running from local app storage.</p><button onclick="count()">Tap me: <span id="n">0</span></button></main><script src="app.js"></script></body></html>"""
        )
        File(dir, "style.css").writeText(
            """body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0a0c10;color:#fff;font-family:system-ui}main{width:min(90%,520px);padding:28px;text-align:center;background:#12161e;border:1px solid #252b36;border-radius:24px}.logo{display:inline-grid;place-items:center;width:70px;height:70px;border-radius:20px;background:#7c5cfc;font-weight:900;font-size:22px}button{padding:13px 18px;border:0;border-radius:12px;background:#7c5cfc;color:#fff;font-weight:800}"""
        )
        File(dir, "app.js").writeText("let n=0;function count(){document.getElementById('n').textContent=++n}")
        return dir
    }

    suspend fun importHtml(uri: Uri, displayName: String): File = withContext(Dispatchers.IO) {
        val baseName = safeProjectName(displayName.substringBeforeLast('.'))
        val dir = File(root, uniqueName(baseName))
        check(dir.mkdirs()) { "Could not create project folder" }
        try {
            val target = File(dir, "index.html")
            context.contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { output -> copyBounded(input, output, MAX_FILE_BYTES) }
            } ?: error("Unable to read HTML file")
            dir
        } catch (t: Throwable) {
            dir.deleteRecursively()
            throw t
        }
    }

    suspend fun importFolder(treeUri: Uri, name: String): File = withContext(Dispatchers.IO) {
        val dir = File(root, uniqueName(safeProjectName(name)))
        check(dir.mkdirs()) { "Could not create project folder" }
        try {
            val tree = DocumentFile.fromTreeUri(context, treeUri) ?: error("Unable to open selected folder")
            val limits = CopyLimits()
            copyDocumentTree(tree, dir, 0, limits)
            require(limits.files > 0) { "The selected folder is empty" }
            ProjectRootNormalizer.normalize(dir)
        } catch (t: Throwable) {
            dir.deleteRecursively()
            throw t
        }
    }

    private data class CopyLimits(var files: Int = 0, var bytes: Long = 0)

    private fun copyDocumentTree(source: DocumentFile, target: File, depth: Int, limits: CopyLimits) {
        require(depth <= MAX_DEPTH) { "Folder nesting exceeds the $MAX_DEPTH-level safety limit" }
        val names = mutableSetOf<String>()
        for (doc in source.listFiles()) {
            val original = doc.name ?: error("A selected file has no name")
            val safeName = original.map { ch -> if (ch.code < 32 || ch.code == 127 || ch == '/' || ch == '\\') '_' else ch }
                .joinToString("").trim().takeIf { it.isNotBlank() && it != "." && it != ".." }
                ?: error("A selected item has an unsafe name")
            require(names.add(safeName)) { "Duplicate item name in selected folder: $safeName" }
            val child = File(target, safeName).canonicalFile
            require(child.path.startsWith(target.canonicalFile.path + File.separator)) { "Unsafe folder path detected" }
            when {
                doc.isDirectory -> {
                    require(child.mkdirs() || child.isDirectory) { "Could not create folder: $safeName" }
                    copyDocumentTree(doc, child, depth + 1, limits)
                }
                doc.isFile -> {
                    require(++limits.files <= MAX_FILES) { "Folder contains more than $MAX_FILES files" }
                    context.contentResolver.openInputStream(doc.uri)?.use { input ->
                        child.outputStream().use { output ->
                            val copied = copyBounded(input, output, MAX_FILE_BYTES)
                            limits.bytes += copied
                            require(limits.bytes <= MAX_TOTAL_BYTES) { "Folder exceeds the 250 MiB safety limit" }
                        }
                    } ?: error("Unable to read selected file: $safeName")
                }
            }
        }
    }

    private fun copyBounded(input: java.io.InputStream, output: java.io.OutputStream, maxBytes: Long): Long {
        var copied = 0L
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            if (count == 0) continue
            copied += count
            require(copied <= maxBytes) { "File exceeds the 50 MiB safety limit" }
            output.write(buffer, 0, count)
        }
        return copied
    }

    private fun safeProjectName(value: String): String =
        value.replace(Regex("[^A-Za-z0-9._-]"), "_").trim('.', '_').ifBlank { "Project" }

    private fun uniqueName(base: String): String {
        var candidate = base
        var suffix = 2
        while (File(root, candidate).exists()) {
            candidate = "$base-$suffix"
            suffix++
        }
        return candidate
    }
}
