package com.gx.apkbuilder.utils

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest
import java.security.SecureRandom

class SecureStorage(context: Context) {
    private val prefs by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "gx_secure",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun hasLocalAccount(): Boolean = prefs.contains("user_identity")

    fun createLocalAccount(name: String, identity: String, password: String): Boolean {
        if (hasLocalAccount() || identity.isBlank() || password.length < 6) return false
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString("user_name", name.trim())
            .putString("user_identity", identity.trim())
            .putString("user_salt", salt.toHex())
            .putString("user_hash", hash(password, salt))
            .apply()
        return true
    }

    fun verify(identity: String, password: String): Boolean {
        val storedId = prefs.getString("user_identity", null) ?: return false
        val saltHex = prefs.getString("user_salt", null) ?: return false
        val expected = prefs.getString("user_hash", null) ?: return false
        if (!storedId.equals(identity.trim(), ignoreCase = true)) return false
        return hash(password, saltHex.hexToBytes()) == expected
    }

    fun userName(): String = prefs.getString("user_name", "User") ?: "User"

    fun clearLocalAccount() = prefs.edit().clear().apply()

    private fun hash(password: String, salt: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest(salt + password.toByteArray(Charsets.UTF_8)).toHex()
    }

    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }
    private fun String.hexToBytes(): ByteArray = chunked(2).map { it.toInt(16).toByte() }.toByteArray()
}
