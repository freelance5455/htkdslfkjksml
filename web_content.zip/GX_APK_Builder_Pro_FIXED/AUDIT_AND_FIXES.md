# GX APK Builder Pro — audit, repairs, and verification

## Scope and outcome

The uploaded project was retained as the foundation. The work focused on source-breaking and safety defects in imports, WebView preview, validation, and Android source-project export. This is a targeted repair, **not** completion of every feature in the large supplied specification. In particular, no APK build backend exists and no APK is claimed.

## Defects found and addressed

| Area | Finding | Correction |
|---|---|---|
| ZIP source validity | `ZipManager.kt` contained an embedded NUL byte in a Kotlin character literal, making the source invalid. | Replaced it with a normal `Char.code == 0` check; verified the project sources contain no NUL bytes. |
| ZIP project naming | The collision loop generated the same malformed candidate repeatedly and could hang on name collisions. | Implemented an incrementing `base-2`, `base-3`, … suffix. |
| ZIP extraction | ZIP paths did not normalize Windows separators; there was no duplicate file-entry check and failed imports left partial projects behind. | Normalize separators, reject absolute/drive/traversal/empty/deep paths, reject duplicate/conflicting file entries, cap entries and expanded bytes, and delete partial extraction on failure. |
| Nested ZIP structure | Wrapper normalization could leave the entry page below the project root, and an archive could import successfully without a preview-compatible `index.html`. | A shared normalizer promotes the nearest unambiguous `index.html`/`index.htm`, supports uppercase index names and a single unambiguous HTML fallback, and rejects ambiguity or root filename collisions with a useful message. ZIP and folder imports use the same rule. |
| HTML/folder import | Copying could happen on the UI thread without file/count/size limits; folder names and partial imports were not robustly handled. | Move copy operations to `Dispatchers.IO`, impose per-file/aggregate/file-count/depth limits, sanitize names, reject duplicates, and clean up incomplete imports. Dashboard picker handlers now launch imports in lifecycle scopes. |
| Preview isolation | The preview server mapped a request path to local project files without first checking the request host/scheme. A request from an unrelated origin could resolve to a project file by path. | Serve only HTTPS requests to the synthetic `gx.local` origin; reject other top-level navigations; continue to disable WebView file/content access. |
| Validation | Validation skipped broken local CSS `url()` references and did not check viewport metadata or aggregate sizes; a generic success note could obscure warnings. | Added bounded size checks, HTML viewport warnings, local HTML/CSS reference checks, explicit warning summary, and actionable messages. |
| Generated Android source | The generated wrapper used `file:///android_asset`, lacked a secure local asset origin and explicit generated-project instructions, and did not validate version fields/source size. | Generate a `WebViewAssetLoader` wrapper with file access disabled, HTTPS app-assets origin, sanitized/validated identity/version values, package-source bounds, and build/readme instructions. |
| APK button | Existing behavior only explained that APK generation was unavailable. This was misleading only if interpreted as a real build. | Preserved truthful behavior; README and this report clearly state there is no local toolchain or configured remote backend and that export is source-only. No fake APK output or success state was added. |

## Test and build results

| Check | Result | Notes |
|---|---|---|
| Inspect ZIP contents and source inventory | **PASS** | Verified uploaded archive contents and reviewed key source, manifest, Gradle and documentation files. |
| Source NUL-byte scan | **PASS** | No NUL byte should remain in project files; final scan is part of packaging checks. |
| Parse Android XML resources/manifest | **PASS (static XML parse)** | All 11 project XML files parsed with Python's XML parser. This is not a substitute for Android resource linking. |
| Scan sources for embedded NUL bytes and review repaired source invariants | **PASS (static checks)** | No project file contains NUL bytes; import bounds/traversal checks, preview host allowlist, secure generated asset-loader source, and honest APK limitation are present. |
| Check included sample HTML references | **PASS (static check)** | Both relative HTML references resolve to files in `sample-project/`. |
| Verify delivered source and sample ZIP archives | **PASS** | Both created archives passed `unzip -t` integrity checks. |
| Isolated Kotlin engine checks | **PASS** | Kotlin 1.9.0 compiled `ProjectGenerator`, `ProjectValidator`, `ProjectRootNormalizer`, and `LocalAiDiagnostic`; generated temporary online/offline source ZIPs and tested key manifest/escaping behavior. |
| Entry-point normalizer tests | **PASS** | Tested root entry, nested wrapper, uppercase index, single HTML fallback, ambiguity rejection, and collision rejection in an isolated Kotlin runner. |
| Kotlin syntax/parser scan | **PASS (syntax only)** | No grammar/syntax diagnostics were found. A complete app compile cannot succeed in this sandbox because Android/AndroidX classes are not available. |
| Full Kotlin/Android compile | **NOT VERIFIED** | No Gradle or Android SDK/`android.jar` is installed. The raw compiler attempt has unresolved Android/AndroidX references and cascading type errors, so it is not a valid app build. |
| Import/preview on Android device | **NOT RUN** | No Android device or emulator is attached. |
| ZIP traversal/resource-limit runtime tests | **NOT RUN** | Requires executing Android/Kotlin app code. Static implementation was reviewed; do not count these as passed runtime tests. |
| Generated Android source ZIP from Kotlin exporter | **PASS (isolated test)** | Temporary online/offline project ZIPs were generated from Kotlin and checked for HTML/CSS assets, escaped Gradle project name, and internet permission setting. The test ZIPs were discarded after verification. |
| APK build and APK integrity verification | **NOT RUN** | No local Android build environment and no remote build service is configured. |

The exact intended Android compile command is `gradle :app:assembleDebug` from the project root. It could not be executed because Gradle and Android SDK Platform 35 are not available here.

## Remote APK build backend prerequisites (not deployed or integrated)

To turn the in-app action into a real remote build, a service owner must deploy an HTTPS API backed by isolated, disposable workers with JDK 17, Gradle 8.7, Android SDK Platform 35, and Android build tools. The app still needs a real authenticated client implementation and backend URL configuration; neither exists in this archive. A reasonable initial API contract is:

| Request | Purpose |
|---|---|
| `POST /v1/builds` (authenticated multipart source ZIP + validated app config) | Create a build job; enforce upload/file/expanded-size limits; return a job ID. |
| `GET /v1/builds/{jobId}` (authenticated) | Return queued/running/succeeded/failed state, progress, sanitized logs, and error summary. |
| `POST /v1/builds/{jobId}/cancel` (authenticated) | Cancel a job that has not completed. |
| `GET /v1/builds/{jobId}/artifact` (authenticated or short-lived signed URL) | Download the verified APK only after a successful build. |

Workers must have job timeouts, resource quotas, per-job temporary directories, cleanup, no cross-job filesystem sharing, and no access to app/server secrets. Do not execute arbitrary user-supplied Gradle scripts: package static web assets into a server-controlled Android template and build only that template. Authenticate and authorize every job operation, use TLS, limit retention, avoid sensitive log contents, and never upload user keystores without explicit consent. The mobile app must clearly ask before uploading project files. This is a deployment/integration checklist—not a claim that such a service is configured.

## Remaining work / specification gaps

The supplied specification's full acceptance list is substantially larger than this repair. These are still incomplete and must not be represented as implemented:

- No actual local APK compilation, remote build API, queue, cancellation, logs, artifact storage/download, or build history.
- No release-signing workflow, keystore UI, APK install workflow, or APK share workflow (source ZIP sharing is present).
- No full code editor features such as syntax highlighting, line numbers, search/replace, undo/redo, Save As, autosave, or unsaved-change warnings.
- No full tree explorer with create/rename/delete/search; existing UI lists files and opens editable text.
- No alternate HTML entry-point selection; preview/export require root `index.html`.
- No complete app-configuration screen, saved per-project identity/branding settings, custom icon/splash import, or WebView policy controls.
- No build history, exported APK manager, project operations (rename/duplicate/delete), or all requested templates.
- No comprehensive browser diagnostics panel, JavaScript exception bridge, external-link settings, or full device/UI tests.
- No compiler, unit/instrumentation test suite, device/emulator tests, or full regression run could be completed here.

## Opening and continuing

Open the root project folder in Android Studio. Configure JDK 17 and Android SDK Platform 35, allow Gradle plugin/dependency resolution, and build with `gradle :app:assembleDebug`. Then use an Android device/emulator to test the HTML, ZIP, and folder pickers; preview relative CSS/JS/assets; test malicious/oversized ZIP rejection; and verify source-project export. Install/build remote infrastructure only if a real in-app APK build is needed; do not label source ZIP export as APK compilation.


## Second-pass fixes (2026-10-10)

- Added `ProjectRootNormalizer` shared by ZIP and folder import. It promotes a single unambiguous nested `index.html`/`index.htm` to the project root, creates a root `index.html` alias for a single unambiguous HTML page, and reports ambiguity/collisions instead of accepting a project that the Preview screen cannot open.
- Explicit duplicate ZIP directory entries are rejected rather than silently accepted.
- Added Internet permission to the builder app so previewed sites that rely on remote CSS, scripts, or API calls can use network access. Top-level WebView navigation remains constrained to the synthetic local origin.
- Generated Android project name escaping now handles `$`, preventing unexpected Gradle/Kotlin string interpolation in an app name.
- Android source ZIP output uses a temporary file and only finalizes after successful archive creation.
- Failed code-editor saves keep the dialog open so user edits are not discarded.

These are source-level fixes. Isolated Kotlin engine/normalizer tests passed, but Android compilation, device runtime validation and APK generation remain unverified because this environment has no Android SDK or Gradle installation/wrapper and cannot fetch build tools.

- Export now asks whether the generated app needs internet access instead of silently forcing offline mode. File sharing is limited to a dedicated export folder, Preview resolves `/` to `index.html`, and `PreviewActivity` cleans up the WebView and pending file chooser callback on teardown.
