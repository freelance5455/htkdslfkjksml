# Build / QA Status

## Environment
- Java 21 is installed.
- Kotlin 1.9.0 compiler is available at `/root/.sdkman/candidates/kotlin/1.9.0/bin/kotlinc` for isolated pure-Kotlin checks.
- Gradle, the Android SDK (including `android.jar`), and a Gradle wrapper are not present. Network access to fetch build tools is unavailable in this environment.

## Checks performed during this repair
- **PASS** — all 11 Android XML files parse with Python's XML parser. This is not Android resource linking.
- **PASS** — compiled and ran isolated tests for `ProjectRootNormalizer`: root `index.html`, nested wrapper promotion, uppercase index filename, single-page fallback, ambiguous entry rejection, and root/nested filename conflict rejection.
- **PASS** — compiled and ran pure-Kotlin checks for `ProjectGenerator` and `ProjectValidator`.
- **PASS** — generated temporary offline and online Android source ZIPs; verified HTML/CSS inclusion, dollar-sign escaping in generated Gradle settings, and the expected INTERNET permission behavior. These temporary test artifacts were not included as deliverables.
- **PASS** — Kotlin source parser scan reported no grammar/syntax diagnostics. A full source compile was attempted but cannot complete without Android/AndroidX dependencies; unresolved-reference and cascading type errors are expected in that incomplete classpath.
- **PASS** — archive integrity checks are run against the final delivered ZIP during packaging.

## Not verified
- A full Android Gradle build was **not run** because Gradle and the Android SDK are absent.
- The app was not installed or tested on a physical device/emulator.
- Actual ZIP picking/extraction through Android's ContentResolver, WebView behavior on-device, and generated APK signature/integrity have not been verified here.
- No APK was generated or included. The in-app **Build APK** action still explains the limitation; there is no local Android build engine or configured remote backend.

## Build command after opening in Android Studio
Configure JDK 17+ and Android SDK Platform 35, allow Android Gradle Plugin/dependency resolution, and run `gradle :app:assembleDebug` from the project root. This source archive has no Gradle wrapper.

See `AUDIT_AND_FIXES.md` for the issue-by-issue audit and remaining feature gaps.
