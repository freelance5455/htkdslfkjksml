# Dependency License Notes

This project uses AndroidX / Kotlin / Material components and standard Android APIs. Keep the corresponding licenses/notices with redistributed builds as required by the libraries used in your final release.

No paid SDK, ad SDK, analytics SDK, or proprietary cloud compiler is bundled in this demo.
