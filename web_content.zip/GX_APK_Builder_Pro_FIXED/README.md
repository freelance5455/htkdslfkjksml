# GX APK Builder Pro

GX APK Builder Pro is an Android app for importing, editing, validating, previewing, and exporting static HTML/CSS/JavaScript projects as Android Studio source projects.

## Current supported workflow

- Import a single HTML document, a ZIP project, or a selected folder using Android's system picker.
- Browse project files and edit supported text files.
- Validate the project and preview `index.html` in the app's local WebView.
- Export an Android Gradle project ZIP containing the web assets and a WebView wrapper.
- Share the generated source ZIP using Android's share sheet.

Imports are copied to app-private storage. ZIP and folder imports are bounded to 10,000 files, 50 MiB per file, and 250 MiB total; ZIP path traversal and duplicate file entries are rejected. Local preview responses are only served for `https://gx.local/` and never grant WebView unrestricted file access.

## APK build limitation — do not confuse source export with an APK

The **Build APK** action in this app is explanatory only. This project does not bundle Gradle, a JDK, or the Android SDK, and no remote build backend is configured. It does **not** compile or return an APK. No APK is included with this source archive.

The Android project exporter creates source code only. To compile that exported project, open it in Android Studio with Android SDK Platform 35 installed, or use JDK 17, Gradle 8.7, and the Android SDK, then run:

```sh
gradle :app:assembleDebug
```

The generated debug artifact will be under `app/build/outputs/apk/debug/`. Release signing must be configured separately with a keystore stored and protected by the project owner.

## Build the GX APK Builder Pro app

This archive does not include the Gradle wrapper. Open the project root in Android Studio with Android SDK Platform 35 and JDK 17 configured, or install a compatible Gradle/Android SDK toolchain and run:

```sh
gradle :app:assembleDebug
```

This build was **not run** in the supplied sandbox because neither Gradle nor the Android SDK is installed there.

## Security and privacy

- Imported files remain in app-private storage; no backend upload is implemented.
- The builder requests INTERNET permission so Preview can load remote assets and API endpoints; top-level navigation remains restricted to the local preview origin. Generated app exports ask separately whether INTERNET permission should be included.
- Preview content runs with JavaScript and DOM storage enabled for project functionality, but direct file/content access is disabled.
- Generated projects package files as Android assets and serve them through AndroidX `WebViewAssetLoader` on a secure local origin.
- Never treat arbitrary imported project content as trusted. The preview sandbox is not a full browser security boundary for hostile HTML/JavaScript.

## Known feature limitations

This is not a full Android IDE. The editor is a basic text editor without syntax highlighting, search/replace, undo/redo, autosave, unsaved-change warnings, or a project-wide search. There is no full tree UI, alternate entry-page picker, build history, release signing UI, persistent project configuration, remote build API, installation flow, or actual APK compiler in the app. The app-settings screen, configurable WebView policies, and most of the requested starter templates are also not implemented. See [AUDIT_AND_FIXES.md](AUDIT_AND_FIXES.md) for the audit, changes, validation results, and remaining work.
