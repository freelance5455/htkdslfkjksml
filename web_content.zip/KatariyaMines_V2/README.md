# Katariya Mines V2
Mobile-friendly prototype with catalog, search, enquiry cart, customer enquiries and admin dashboard.

Demo admin:
Username: admin
Password: katariya123

Open index.html in Chrome. You can use Chrome's Add to Home screen option.

This is a prototype. The admin login is not secure and data is stored locally. A production release needs secure server-side authentication, database/cloud storage and an Android build/signing setup.
