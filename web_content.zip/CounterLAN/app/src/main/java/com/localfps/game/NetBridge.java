package com.localfps.game;

import android.app.Activity;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * LAN networking for the game (runs on the host phone and on the guests).
 *  - Host: TCP server on PORT + UDP broadcast of the server info every second on DISC_PORT.
 *  - Guest: UDP listener (server list) + TCP client.
 * All messages are single-line JSON strings; the game logic itself is in JavaScript.
 */
public class NetBridge {
    static final int PORT = 47777;
    static final int DISC_PORT = 47778;

    private final Activity act;
    private final WebView web;
    private final WifiManager.MulticastLock mlock;

    // ---- host ----
    private volatile boolean hosting = false;
    private ServerSocket server;
    private final Map<Integer, Client> clients = new ConcurrentHashMap<>();
    private int nextId = 1;
    private volatile String info = "{}";
    private DatagramSocket bcastSock;

    // ---- guest ----
    private Socket sock;
    private OutputStream sockOut;
    private volatile boolean discovering = false;
    private DatagramSocket discSock;

    private static class Client {
        final int id; final Socket s; final OutputStream out;
        Client(int id, Socket s) throws IOException { this.id = id; this.s = s; this.out = s.getOutputStream(); }
        synchronized void send(String line) {
            try { out.write((line + "\n").getBytes(StandardCharsets.UTF_8)); out.flush(); } catch (IOException ignored) { }
        }
        void close() { try { s.close(); } catch (IOException ignored) { } }
    }

    NetBridge(Activity a, WebView w) {
        act = a; web = w;
        WifiManager wm = (WifiManager) a.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        mlock = wm != null ? wm.createMulticastLock("counterlan") : null;
        if (mlock != null) mlock.setReferenceCounted(false);
    }

    // ------------------------------------------------------------------ JS events
    private void emit(final String type, final String a, final String b) {
        final String js = "window.__net&&window.__net(" + JSONObject.quote(type) + "," + JSONObject.quote(a == null ? "" : a)
                + "," + JSONObject.quote(b == null ? "" : b) + ")";
        act.runOnUiThread(new Runnable() { public void run() { web.evaluateJavascript(js, null); } });
    }

    // ------------------------------------------------------------------ host API
    @JavascriptInterface
    public synchronized void hostStart(String infoJson) {
        hostStop();
        info = infoJson;
        hosting = true;
        try {
            server = new ServerSocket();
            server.setReuseAddress(true);
            server.bind(new InetSocketAddress(PORT));
        } catch (IOException e) { hosting = false; emit("error", "سرور ساخته نشد: " + e.getMessage(), null); return; }
        final ServerSocket ss = server;
        new Thread(new Runnable() { public void run() { acceptLoop(ss); } }, "accept").start();
        new Thread(new Runnable() { public void run() { broadcastLoop(); } }, "bcast").start();
    }

    private void acceptLoop(ServerSocket ss) {
        while (hosting && !ss.isClosed()) {
            try {
                final Socket s = ss.accept();
                new Thread(new Runnable() { public void run() { handleConn(s); } }, "conn").start();
            } catch (IOException e) { if (!hosting) break; }
        }
    }

    /** First line "?" = a server-list probe: answer with the server info and hang up (no player is created). */
    private void handleConn(Socket s) {
        Client c = null;
        try {
            s.setTcpNoDelay(true);
            s.setSoTimeout(4000);
            BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            String first = r.readLine();
            s.setSoTimeout(0);
            if (first == null) { s.close(); return; }
            if ("?".equals(first)) {
                OutputStream o = s.getOutputStream();
                o.write((info + "\n").getBytes(StandardCharsets.UTF_8));
                o.flush();
                s.close();
                return;
            }
            final int id;
            synchronized (this) { id = nextId++; }
            c = new Client(id, s);
            clients.put(id, c);
            emit("peer", String.valueOf(id), "1");
            emit("hmsg", String.valueOf(id), first);
            String line;
            while ((line = r.readLine()) != null) emit("hmsg", String.valueOf(id), line);
        } catch (IOException ignored) { }
        if (c != null) {
            if (clients.remove(c.id) != null) emit("peer", String.valueOf(c.id), "0");
            c.close();
        } else {
            try { s.close(); } catch (IOException ignored) { }
        }
    }

    private void broadcastLoop() {
        try {
            bcastSock = new DatagramSocket();
            bcastSock.setBroadcast(true);
        } catch (IOException e) { return; }
        while (hosting) {
            try {
                byte[] data = info.getBytes(StandardCharsets.UTF_8);
                for (InetAddress addr : broadcastAddresses()) {
                    try { bcastSock.send(new DatagramPacket(data, data.length, addr, DISC_PORT)); } catch (IOException ignored) { }
                }
                Thread.sleep(1000);
            } catch (InterruptedException e) { break; }
        }
        if (bcastSock != null) bcastSock.close();
    }

    private static List<InetAddress> broadcastAddresses() {
        List<InetAddress> out = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    if (ia.getBroadcast() != null) out.add(ia.getBroadcast());
                }
            }
            out.add(InetAddress.getByName("255.255.255.255"));
        } catch (Exception ignored) { }
        return out;
    }

    @JavascriptInterface public void hostInfo(String infoJson) { info = infoJson; }

    @JavascriptInterface
    public void hostSend(String to, String line) {
        if (!hosting) return;
        if ("*".equals(to)) { for (Client c : clients.values()) c.send(line); }
        else {
            try { Client c = clients.get(Integer.parseInt(to)); if (c != null) c.send(line); } catch (NumberFormatException ignored) { }
        }
    }

    @JavascriptInterface
    public void hostKick(int id) {
        final Client c = clients.remove(id);
        if (c != null) new Thread(new Runnable() { public void run() { try { Thread.sleep(300); } catch (InterruptedException ignored) { } c.close(); } }).start();
    }

    @JavascriptInterface
    public synchronized void hostStop() {
        hosting = false;
        try { if (server != null) server.close(); } catch (IOException ignored) { }
        server = null;
        for (Client c : clients.values()) c.close();
        clients.clear();
        nextId = 1;
        if (bcastSock != null) bcastSock.close();
    }

    // ------------------------------------------------------------------ guest API
    @JavascriptInterface
    public void discoverStart() {
        if (discovering) return;
        discovering = true;
        if (mlock != null) mlock.acquire();
        new Thread(new Runnable() {
            public void run() {
                try {
                    discSock = new DatagramSocket(null);
                    discSock.setReuseAddress(true);
                    discSock.setBroadcast(true);
                    discSock.bind(new InetSocketAddress(DISC_PORT));
                    byte[] buf = new byte[1024];
                    while (discovering) {
                        DatagramPacket p = new DatagramPacket(buf, buf.length);
                        discSock.receive(p);
                        String json = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
                        emit("server", p.getAddress().getHostAddress(), json);
                    }
                } catch (IOException e) {
                    if (discovering) emit("error", "جستجو ناموفق بود: " + e.getMessage(), null);
                } finally {
                    if (discSock != null) discSock.close();
                }
            }
        }, "discover").start();
        new Thread(new Runnable() { public void run() { scanLoop(); } }, "scan").start();
    }

    /** Works even when the router/hotspot blocks UDP broadcast: probe every address of the local /24 on the game port. */
    private void scanLoop() {
        while (discovering) {
            try {
                List<String> targets = new ArrayList<>();
                Set<String> mine = new HashSet<>();
                for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                    if (!ni.isUp() || ni.isLoopback()) continue;
                    for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                        if (!(ia.getAddress() instanceof Inet4Address)) continue;
                        String ip = ia.getAddress().getHostAddress();
                        mine.add(ip);
                        String[] p = ip.split("\\.");
                        if (p.length != 4) continue;
                        String pre = p[0] + "." + p[1] + "." + p[2] + ".";
                        for (int i = 1; i < 255; i++) targets.add(pre + i);
                    }
                }
                targets.removeAll(mine);
                ExecutorService ex = Executors.newFixedThreadPool(48);
                for (final String ip : targets) ex.execute(new Runnable() { public void run() { probe(ip); } });
                ex.shutdown();
                ex.awaitTermination(8, TimeUnit.SECONDS);
                Thread.sleep(1200);
            } catch (InterruptedException e) {
                return;
            } catch (Exception e) {
                try { Thread.sleep(1500); } catch (InterruptedException ie) { return; }
            }
        }
    }

    private void probe(String ip) {
        if (!discovering) return;
        Socket s = null;
        try {
            s = new Socket();
            s.connect(new InetSocketAddress(ip, PORT), 450);
            s.setSoTimeout(900);
            OutputStream o = s.getOutputStream();
            o.write("?\n".getBytes(StandardCharsets.UTF_8));
            o.flush();
            String line = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8)).readLine();
            if (line != null && line.startsWith("{")) emit("server", ip, line);
        } catch (Exception ignored) {
        } finally {
            if (s != null) try { s.close(); } catch (IOException ignored) { }
        }
    }

    @JavascriptInterface
    public void discoverStop() {
        discovering = false;
        if (discSock != null) discSock.close();
        if (mlock != null && mlock.isHeld()) mlock.release();
    }

    @JavascriptInterface
    public void connect(final String ip, final int port) {
        disconnect();
        new Thread(new Runnable() {
            public void run() {
                boolean connected = false;
                try {
                    Socket s = new Socket();
                    s.setTcpNoDelay(true);
                    s.connect(new InetSocketAddress(ip, port > 0 ? port : PORT), 5000);
                    synchronized (NetBridge.this) { sock = s; sockOut = s.getOutputStream(); }
                    connected = true;
                    emit("open", null, null);
                    BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                    String line;
                    while ((line = r.readLine()) != null) emit("msg", line, null);
                } catch (IOException e) {
                    if (!connected) emit("error", "اتصال به سرور برقرار نشد", null);
                }
                boolean was;
                synchronized (NetBridge.this) { was = sock != null; sock = null; sockOut = null; }
                if (was) emit("close", null, null);
            }
        }, "client").start();
    }

    @JavascriptInterface
    public void send(String line) {
        OutputStream o; synchronized (this) { o = sockOut; }
        if (o == null) return;
        try { synchronized (o) { o.write((line + "\n").getBytes(StandardCharsets.UTF_8)); o.flush(); } } catch (IOException ignored) { }
    }

    @JavascriptInterface
    public void disconnect() {
        Socket s; synchronized (this) { s = sock; sock = null; sockOut = null; }
        if (s != null) try { s.close(); } catch (IOException ignored) { }
    }

    @JavascriptInterface
    public String localIp() {
        StringBuilder sb = new StringBuilder();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                        if (sb.length() > 0) sb.append(" / ");
                        sb.append(a.getHostAddress());
                    }
                }
            }
        } catch (Exception ignored) { }
        return sb.length() == 0 ? "—" : sb.toString();
    }

    void shutdown() { hostStop(); disconnect(); discoverStop(); }
}
