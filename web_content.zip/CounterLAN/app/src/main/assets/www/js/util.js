'use strict';
const PI=Math.PI;
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const lerp=(a,b,t)=>a+(b-a)*t;
const rnd=(a,b)=>a+Math.random()*(b-a);
function hex(h){const n=parseInt(h.slice(1),16);return [(n>>16&255)/255,(n>>8&255)/255,(n&255)/255]}
function lin(h){const c=typeof h==='string'?hex(h):h;return [Math.pow(c[0],2.2),Math.pow(c[1],2.2),Math.pow(c[2],2.2)]}
function mulberry(seed){return function(){seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const r2=v=>Math.round(v*100)/100;

const M4={
 mul(a,b){const o=new Float32Array(16);for(let c=0;c<4;c++){const b0=b[c*4],b1=b[c*4+1],b2=b[c*4+2],b3=b[c*4+3];for(let r=0;r<4;r++)o[c*4+r]=a[r]*b0+a[4+r]*b1+a[8+r]*b2+a[12+r]*b3}return o},
 T(x,y,z){return new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,x,y,z,1])},
 S(x,y,z){return new Float32Array([x,0,0,0,0,y,0,0,0,0,z,0,0,0,0,1])},
 RY(a){const c=Math.cos(a),s=Math.sin(a);return new Float32Array([c,0,-s,0,0,1,0,0,s,0,c,0,0,0,0,1])},
 RX(a){const c=Math.cos(a),s=Math.sin(a);return new Float32Array([1,0,0,0,0,c,s,0,0,-s,c,0,0,0,0,1])},
 persp(f,a,n,fa){const t=1/Math.tan(f/2);return new Float32Array([t/a,0,0,0,0,t,0,0,0,0,(fa+n)/(n-fa),-1,0,0,2*fa*n/(n-fa),0])},
 ortho(l,r,b,t,n,f){return new Float32Array([2/(r-l),0,0,0,0,2/(t-b),0,0,0,0,-2/(f-n),0,-(r+l)/(r-l),-(t+b)/(t-b),-(f+n)/(f-n),1])},
 look(e,c,u){let zx=e[0]-c[0],zy=e[1]-c[1],zz=e[2]-c[2];let l=Math.hypot(zx,zy,zz);zx/=l;zy/=l;zz/=l;
  let xx=u[1]*zz-u[2]*zy,xy=u[2]*zx-u[0]*zz,xz=u[0]*zy-u[1]*zx;l=Math.hypot(xx,xy,xz);xx/=l;xy/=l;xz/=l;
  const yx=zy*xz-zz*xy,yy=zz*xx-zx*xz,yz=zx*xy-zy*xx;
  return new Float32Array([xx,yx,zx,0,xy,yy,zy,0,xz,yz,zz,0,-(xx*e[0]+xy*e[1]+xz*e[2]),-(yx*e[0]+yy*e[1]+yz*e[2]),-(zx*e[0]+zy*e[1]+zz*e[2]),1])},
 // base * T(o) * RX(rx) * T(p) * S(s)
 part(base,ox,oy,oz,rx,px,py,pz,sx,sy,sz){const c=Math.cos(rx),s=Math.sin(rx);
  const L=new Float32Array([sx,0,0,0, 0,sy*c,sy*s,0, 0,-sz*s,sz*c,0, ox+px,oy+py*c-pz*s,oz+py*s+pz*c,1]);return M4.mul(base,L)},
 between(a,b,w){const dx=b[0]-a[0],dy=b[1]-a[1],dz=b[2]-a[2],L=Math.hypot(dx,dy,dz)||.001,h=Math.hypot(dx,dz);
  const yaw=Math.atan2(-dx,-dz),pit=Math.atan2(dy,h);
  return M4.mul(M4.mul(M4.T((a[0]+b[0])/2,(a[1]+b[1])/2,(a[2]+b[2])/2),M4.RY(yaw)),M4.mul(M4.RX(pit),M4.S(w,w,L)))}
};

// instance list: 22 floats per box (16 matrix, 4 color+emissive, 2 tex/tile)
class InstList{
 constructor(cap){this.data=new Float32Array((cap||256)*22);this.n=0;this.dirty=true}
 clear(){this.n=0}
 add(M,r,g,b,em,tex,tile){
  if((this.n+1)*22>this.data.length){const d=new Float32Array(this.data.length*2);d.set(this.data);this.data=d}
  const o=this.n*22,d=this.data;for(let i=0;i<16;i++)d[o+i]=M[i];
  d[o+16]=r;d[o+17]=g;d[o+18]=b;d[o+19]=em||0;d[o+20]=tex;d[o+21]=tile||2;this.n++}
 box(x,y,z,w,h,d,col,em,tex,tile){this.add(M4.mul(M4.T(x,y+h/2,z),M4.S(w,h,d)),col[0],col[1],col[2],em,tex,tile)}
}
class PList{ // particles: x,y,z,size,r,g,b,a
 constructor(cap){this.data=new Float32Array((cap||512)*8);this.n=0}
 clear(){this.n=0}
 add(x,y,z,s,r,g,b,a){if((this.n+1)*8>this.data.length){const d=new Float32Array(this.data.length*2);d.set(this.data);this.data=d}
  const o=this.n*8,d=this.data;d[o]=x;d[o+1]=y;d[o+2]=z;d[o+3]=s;d[o+4]=r;d[o+5]=g;d[o+6]=b;d[o+7]=a;this.n++}
}
