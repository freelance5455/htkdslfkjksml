'use strict';
function mkTheme(o){const k=o.ambK||1;return{zen:lin(o.zen),hor:lin(o.hor),gnd:lin(o.gnd),cloud:lin(o.cloud||'#ffffff'),skySunCol:o.sunCol.map(v=>v*.6),sunDir:o.sun,sunCol:o.sunCol,
 ambT:lin(o.ambT).map(v=>v*k),ambB:lin(o.ambB).map(v=>v*k),fog:lin(o.fog),fogD:o.fogD,cloudAmt:o.cloudAmt||0,stars:o.stars||0,exp:o.exp||1}}

class MB{
 constructor(half){this.half=half||32;this.b=[];this.lights=[];this.glows=[];this.sp=[[],[]];this.dummies=[];this.snow=false;this.rng=mulberry(1234)}
 box(x,y,z,w,h,d,tex,col,o){o=o||{};const b={x,y,z,w,h,d,x0:x-w/2,x1:x+w/2,y0:y,y1:y+h,z0:z-d/2,z1:z+d/2,tex,col:col||[1,1,1],
  em:o.em!==undefined?o.em:(tex===TX.WINN?1:0),tile:o.tile||3,solid:o.solid!==false};this.b.push(b);return b}
 decal(x,z,w,d,tex,col,o){o=Object.assign({solid:false},o||{});return this.box(x,.015,z,w,.03,d,tex,col,o)}
 crate(x,z,s,y){return this.box(x,y||0,z,s,s,s,TX.CRATE,[1,1,1],{tile:s})}
 light(x,y,z,r,col,k){this.lights.push({x,y,z,r,c:[col[0]*k,col[1]*k,col[2]*k]})}
 glow(x,y,z,s,col){this.glows.push({x,y,z,s,c:col})}
 sym(fn){fn(1);fn(-1)}
 walls(h,tex,col,tile){const H=this.half;
  this.box(0,0,-(H+1),2*H+4,h,2,tex,col,{tile});this.box(0,0,H+1,2*H+4,h,2,tex,col,{tile});
  this.box(-(H+1),0,0,2,h,2*H,tex,col,{tile});this.box(H+1,0,0,2,h,2*H,tex,col,{tile})}
 ground(tex,col,tile){const H=this.half;this.box(0,-1,0,2*H+12,1,2*H+12,tex,col,{tile})}
 // stairs ascending in direction (dx,dz); first step centre at (x,z)
 stairs(x,z,dx,dz,w,n,rise,run,tex,col){for(let i=0;i<n;i++){const cx=x+dx*run*i,cz=z+dz*run*i;
  this.box(cx,0,cz,dx!==0?run:w,rise*(i+1),dz!==0?run:w,tex,col,{tile:2})}}
 lamp(x,z,h,col,k){this.box(x,0,z,.18,h,.18,TX.METAL,[.18,.18,.2],{tile:1});this.box(x,h,z,.9,.14,.45,TX.WHITE,col,{em:1,solid:false});
  this.light(x,h-.4,z,15,col,k);this.glow(x,h,z,1.6,col)}
 neon(x,y,z,w,h,d,col,k,r){this.box(x,y,z,w,h,d,TX.WHITE,col,{em:1,solid:false});this.light(x+(w<d?(x>0?-1.2:1.2):0),y+h/2,z+(d<w?(z>0?-1.2:1.2):0),r||13,col,k||2);this.glow(x,y+h/2,z,Math.max(w,d)*.35+.8,col)}
}

const MAPS=[
/* ================= DUST ================= */
{id:'dust',name:'دشت داغ',desc:'نبرد روز در بیابان؛ دیوارهای خشتی، سکوی مرکزی و جعبه‌ها',grad:'linear-gradient(160deg,#7fb2e6 0%,#f3d9a6 55%,#c99a5e 100%)',half:32,
 theme:mkTheme({zen:'#3f78c9',hor:'#e8d9bd',gnd:'#b79a6e',cloud:'#ffffff',sun:[.55,.72,.38],sunCol:[2.9,2.5,1.95],ambT:'#8fb0e8',ambB:'#b08c5a',ambK:.95,fog:'#dccdb0',fogD:.011,cloudAmt:.7,exp:1}),
 build(B){
  const SD=[.96,.8,.58],ST=[.8,.7,.55];
  B.ground(TX.SAND,[1,.95,.85],4);B.walls(7,TX.PLAS,SD,4);
  B.sym(s=>{
   B.box(s*-8,0,s*22,6,1.2,1.1,TX.SAND,ST,{tile:2});B.box(s*8,0,s*22,6,1.2,1.1,TX.SAND,ST,{tile:2});
   B.box(s*14,0,s*12,10,4,1.5,TX.PLAS,SD,{tile:4});B.box(s*-14,0,s*17,1.5,4,8,TX.PLAS,SD,{tile:4});
   B.crate(s*8,s*11,2);B.crate(s*8.3,s*11.2,1.4,2);B.crate(s*-10,s*6,2.2);B.crate(s*20,s*3,2);B.crate(s*22.2,s*3.5,1.6);
   B.box(s*3,0,s*9,1,1.15,1,TX.METAL,[.7,.2,.15],{tile:1});B.box(s*4.2,0,s*9.3,1,1.15,1,TX.METAL,[.7,.2,.15],{tile:1});B.box(s*3.5,0,s*10.4,1,1.15,1,TX.METAL,[.2,.35,.6],{tile:1});
   B.box(s*22,0,s*-8,1.6,5.5,1.6,TX.PLAS,SD,{tile:3});B.box(s*22,0,s*-2,1.6,5.5,1.6,TX.PLAS,SD,{tile:3});B.box(s*22,5.5,s*-5,1.8,1.1,8.6,TX.PLAS,SD,{tile:3});
   // ruined room
   const cx=s*-20,cz=s*-14;B.box(cx,0,cz-4.5,9,3.8,.8,TX.PLAS,SD,{tile:3});B.box(cx-3.0,0,cz+4.5,3,3.8,.8,TX.PLAS,SD,{tile:3});B.box(cx+3.0,0,cz+4.5,3,3.8,.8,TX.PLAS,SD,{tile:3});
   B.box(cx-4.5,0,cz,.8,3.8,9,TX.PLAS,SD,{tile:3});B.box(cx+4.5,0,cz-2.5,.8,3.8,4,TX.PLAS,SD,{tile:3});B.crate(cx+1.5,cz-1,1.4);
   B.box(s*0,0,s*14,2,4,2,TX.PLAS,SD,{tile:3});
   B.box(s*-24,0,s*4,3.2,2,2.6,TX.ROCK,[.95,.82,.7],{tile:3});B.box(s*-26,0,s*7,2,1.3,2,TX.ROCK,[.95,.82,.7],{tile:3});
   B.box(s*14,0,s*-8,5,1.1,1,TX.SAND,ST,{tile:2});
  });
  B.box(0,0,0,12,1.6,10,TX.PLAS,[.95,.85,.7],{tile:3});
  B.sym(s=>B.stairs(s*-8.8,0,s,0,4,4,.4,.8,TX.PLAS,[.9,.8,.65]));
  B.crate(2.5,2.5,1.5,1.6);B.crate(-3,-2.5,1.5,1.6);B.box(0,1.6,-4.6,6,1,.6,TX.PLAS,SD,{tile:3});B.box(0,1.6,4.6,6,1,.6,TX.PLAS,SD,{tile:3});
  B.decal(0,0,3,3,TX.HAZ,[1,1,1],{y:0});
  B.sym(s=>{B.glow(s*0,4.2,s*14,2.4,[1,.9,.7])});
  for(const x of[-6,0,6,-12,12]){B.sp[0].push([x,27]);B.sp[1].push([-x,-27])}
 }},
/* ================= NEON CITY ================= */
{id:'neon',name:'شهر نئونی',desc:'خیابان‌های شب، ساختمان‌های پنجره‌دار، پل مرکزی و نورهای نئون',grad:'linear-gradient(160deg,#0a0d24 0%,#4b1c6e 55%,#ff3da8 100%)',half:32,
 theme:mkTheme({zen:'#04061a',hor:'#2a1442',gnd:'#0a0a12',cloud:'#4a2a6a',sun:[-.4,.68,.5],sunCol:[.42,.5,.95],ambT:'#3a4a8a',ambB:'#1c1230',ambK:1.15,fog:'#160d28',fogD:.017,cloudAmt:.35,stars:1,exp:1.35}),
 build(B){
  const G=[.82,.82,.88];
  B.ground(TX.ASPH,[1,1,1],4);B.walls(17,TX.WINN,G,8);
  // road marks
  for(let i=-28;i<=28;i+=6){B.decal(0,i,.25,3,TX.CONC,[1,.82,.1]);B.decal(i,0,3,.25,TX.CONC,[1,.82,.1])}
  B.decal(0,24,10,.5,TX.CONC,[.9,.9,.9]);B.decal(0,-24,10,.5,TX.CONC,[.9,.9,.9]);
  const hs=[[16,14,12],[-16,14,15],[16,-14,14],[-16,-14,11]];
  for(const[bx,bz,h]of hs){
   B.box(bx,0,bz,14,h,12,TX.WINN,G,{tile:8});B.box(bx+2,h,bz-1,3,1.2,3,TX.METAL,[.4,.4,.45],{tile:2});
   const sx=bx>0?-1:1;B.neon(bx+sx*7.1,5,bz,.12,1.3,7,bx>0===bz>0?[1,.2,.8]:[.1,.9,1],2.1);
  }
  // bridge
  B.box(0,3.0,0,28,.4,6,TX.CONC,[.85,.85,.88],{tile:4});B.box(0,3.4,-2.9,28,1,.2,TX.CONC,[.7,.7,.75],{tile:3});B.box(0,3.4,2.9,28,1,.2,TX.CONC,[.7,.7,.75],{tile:3});
  B.sym(s=>{B.stairs(s*-20,0,s,0,4,8,.425,.8,TX.CONC,[.8,.8,.85]);B.box(s*7,0,s*2.5,1,3,1,TX.CONC,[.7,.7,.75],{tile:2});B.box(s*7,0,s*-2.5,1,3,1,TX.CONC,[.7,.7,.75],{tile:2})});
  B.box(0,0,2.5,1,3,1,TX.CONC,[.7,.7,.75],{tile:2});B.box(0,0,-2.5,1,3,1,TX.CONC,[.7,.7,.75],{tile:2});
  B.neon(0,3.45,-3.05,26,.1,.08,[.1,.9,1],1.5,10);
  // cars
  const car=(x,z,alongX,col)=>{const w=alongX?4.4:1.9,d=alongX?1.9:4.4;B.box(x,.35,z,w,.75,d,TX.METAL,col,{tile:2});B.box(x,1.1,z,alongX?2.3:1.7,.6,alongX?1.7:2.3,TX.METAL,col.map(v=>v*.8),{tile:2});
   B.box(x,1.12,z,alongX?2.35:1.72,.45,alongX?1.72:2.35,TX.WHITE,[.05,.07,.1],{em:0,solid:false,tile:2});
   const tl=alongX?[x+2.2,.55,z,.06,.22,1.3]:[x,.55,z+2.2,1.3,.22,.06];B.box(...tl,TX.WHITE,[1,.08,.08],{em:1,solid:false})};
  B.sym(s=>{car(s*6,s*10,true,[.95,.75,.08]);car(s*-4,s*-16,false,[.15,.35,.75]);car(s*24,s*6,false,[.7,.1,.1]);
   B.box(s*-6,0,s*16,4,1,.8,TX.CONC,[.75,.75,.78],{tile:2});B.box(s*0,0,s*21,4,1,.8,TX.CONC,[.75,.75,.78],{tile:2});
   B.box(s*26,0,s*-6,3,1.5,1.5,TX.METAL,[.15,.45,.25],{tile:2});B.box(s*-24,0,s*0,3,1.5,1.5,TX.METAL,[.2,.3,.5],{tile:2});
   B.crate(s*10,s*-9,1.6);B.crate(s*-10,s*9,1.6);
   B.lamp(s*10,s*3,5.2,[1,.78,.45],1.7);B.lamp(s*-10,s*-3,5.2,[1,.78,.45],1.7);
  });
  B.neon(0,6,-31.9,10,1,.1,[1,.2,.7],2.2,15);B.neon(0,6,31.9,10,1,.1,[.1,.9,1],2.2,15);
  for(const x of[-6,0,6,-12,12]){B.sp[0].push([x,27]);B.sp[1].push([-x,-27])}
 }},
/* ================= FACTORY ================= */
{id:'factory',name:'کارخانه',desc:'غروب صنعتی؛ کانتینرها، پیاده‌رو فلزی بالا و مخازن بزرگ',grad:'linear-gradient(160deg,#2a3f6a 0%,#f0905a 60%,#4a3a35 100%)',half:32,
 theme:mkTheme({zen:'#2a3f6a',hor:'#f0905a',gnd:'#4a3a35',cloud:'#ffb080',sun:[-.72,.3,.42],sunCol:[3.2,1.75,.85],ambT:'#7686c0',ambB:'#6a4a38',ambK:.9,fog:'#cf8a64',fogD:.013,cloudAmt:.85,exp:1.02}),
 build(B){
  const M=[.62,.63,.66];
  B.ground(TX.CONC,[.95,.95,.97],4);B.walls(9,TX.METAL,M,4);
  const C={or:[.95,.5,.12],bl:[.2,.4,.75],gr:[.25,.6,.35],rs:[.7,.28,.18],gy:[.6,.62,.66],rd:[.8,.15,.15]};
  const cont=(x,y,z,ax,c)=>B.box(x,y,z,ax?6:2.4,2.6,ax?2.4:6,TX.CONT,c,{tile:3});
  B.sym(s=>{
   cont(s*10,0,s*6,true,C.or);cont(s*10.6,2.6,s*6.4,true,C.gy);
   cont(s*-12,0,s*14,false,C.bl);cont(s*-6,0,s*20.5,true,C.gr);cont(s*20,0,s*-4,false,C.rs);cont(s*21,2.6,s*-3.2,false,C.gr);
   cont(s*22,0,s*12,true,C.gy);cont(s*2,0,s*-10,true,C.rd);cont(s*-22,0,s*-20,false,C.or);
   // tank
   B.box(s*-22,0,s*-6,6,7,6,TX.METAL,[.72,.77,.82],{tile:3});B.box(s*-22,2,s*-6,6.4,.4,6.4,TX.METAL,[.35,.35,.4],{tile:2});B.box(s*-22,5,s*-6,6.4,.4,6.4,TX.METAL,[.35,.35,.4],{tile:2});
   B.box(s*-18,0,s*-6,1,3.5,1,TX.METAL,[.8,.4,.15],{tile:2});
   B.box(s*18,0,s*18,1,8.5,1,TX.METAL,[.4,.42,.46],{tile:2});B.box(s*-8,0,s*-18,1,8.5,1,TX.METAL,[.4,.42,.46],{tile:2});
   B.box(s*14,0,s*-12,.9,1.1,.9,TX.METAL,[.75,.2,.1],{tile:1});B.box(s*15.1,0,s*-12.3,.9,1.1,.9,TX.METAL,[.2,.4,.7],{tile:1});B.box(s*14.5,0,s*-11.2,.9,1.1,.9,TX.METAL,[.75,.2,.1],{tile:1});
   B.lamp(s*14,s*-2,7,[1,.6,.3],2.0);B.lamp(s*-4,s*16,7,[1,.6,.3],2.0);
   B.box(0,6.6,s*-14,50,.6,.6,TX.METAL,[.85,.42,.18],{tile:2,solid:false});
  });
  // catwalk
  B.box(0,3.7,0,16,.3,6,TX.METAL,[.55,.57,.6],{tile:2});B.box(0,4,-2.9,16,1,.15,TX.METAL,[.4,.42,.46],{tile:2});B.box(0,4,2.9,16,1,.15,TX.METAL,[.4,.42,.46],{tile:2});
  B.sym(s=>{B.stairs(s*-14.65,0,s,0,3,10,.4,.7,TX.METAL,[.5,.52,.55]);B.box(s*7,0,s*2.6,.5,3.7,.5,TX.METAL,[.4,.42,.46],{tile:2});B.box(s*7,0,s*-2.6,.5,3.7,.5,TX.METAL,[.4,.42,.46],{tile:2})});
  B.box(0,0,2.6,.5,3.7,.5,TX.METAL,[.4,.42,.46],{tile:2});B.box(0,0,-2.6,.5,3.7,.5,TX.METAL,[.4,.42,.46],{tile:2});
  B.decal(0,0,22,6,TX.HAZ,[1,1,1]);
  B.crate(0,0,1.6,4.0);B.crate(3,1,1.3,4.0);
  for(const x of[-6,0,6,-12,12]){B.sp[0].push([x,27]);B.sp[1].push([-x,-27])}
 }},
/* ================= SNOW ================= */
{id:'snow',name:'پاسگاه برفی',desc:'سپیده‌دم در کوهستان؛ کلبه‌ها، درخت‌های کاج و دریاچه یخ‌زده',grad:'linear-gradient(160deg,#2a3c6e 0%,#d9b4c0 55%,#eef3fb 100%)',half:32,snow:true,
 theme:mkTheme({zen:'#2e4278',hor:'#e2bccb',gnd:'#c2cadc',cloud:'#f6dce6',sun:[.62,.22,-.5],sunCol:[2.4,1.7,1.5],ambT:'#92a8dc',ambB:'#cfd8ee',ambK:.95,fog:'#cbc8da',fogD:.015,cloudAmt:.6,exp:1.08}),
 build(B){
  const rg=B.rng;
  B.ground(TX.SNOW,[1,1,1],5);B.walls(10,TX.ROCK,[.8,.82,.9],5);
  const cab=(cx,cz,w,d)=>{const WL=[1,.9,.85];
   B.box(cx,0,cz-d/2,w,3.3,.5,TX.WOOD,WL,{tile:3});B.box(cx-w/4-.9,0,cz+d/2,w/2-1.8,3.3,.5,TX.WOOD,WL,{tile:3});B.box(cx+w/4+.9,0,cz+d/2,w/2-1.8,3.3,.5,TX.WOOD,WL,{tile:3});
   B.box(cx,2.4,cz+d/2,2.4,.9,.5,TX.WOOD,WL,{tile:3});
   B.box(cx-w/2,0,cz,.5,3.3,d,TX.WOOD,WL,{tile:3});B.box(cx+w/2,0,cz,.5,3.3,d,TX.WOOD,WL,{tile:3});
   B.box(cx,3.3,cz,w+1.2,.4,d+1.2,TX.WOOD,[.5,.4,.36],{tile:3});B.box(cx,3.7,cz,w+1.4,.3,d+1.4,TX.SNOW,[1,1,1],{tile:3});
   B.light(cx,2,cz,10,[1,.7,.4],1.7);B.box(cx-w/2-.27,1.3,cz,.05,.9,1.4,TX.WHITE,[1,.75,.4],{em:.8,solid:false});B.box(cx+w/2+.27,1.3,cz,.05,.9,1.4,TX.WHITE,[1,.75,.4],{em:.8,solid:false});
   B.crate(cx-1.5,cz-1,1.1);B.box(cx+1.5,0,cz-1,2,.6,.9,TX.WOOD,[.8,.7,.6],{tile:2})};
  B.sym(s=>{cab(s*-14,s*-10,8,6);
   B.box(s*4,0,s*12,8,2.2,1,TX.ROCK,[.85,.85,.9],{tile:3});B.box(s*8,0,s*12.2,1.2,3,1.2,TX.ROCK,[.85,.85,.9],{tile:3});
   B.box(s*8,0,s*-3,.9,1.1,.9,TX.METAL,[.55,.22,.1],{tile:1});B.box(s*8,1.1,s*-3,.7,.05,.7,TX.WHITE,[1,.5,.1],{em:1,solid:false});B.light(s*8,2,s*-3,12,[1,.55,.2],2.2);B.glow(s*8,1.3,s*-3,1.8,[1,.55,.2]);
   B.crate(s*18,s*8,1.8);B.crate(s*18.4,s*8.2,1.2,1.8);B.box(s*22,0,s*-12,4,2.4,3,TX.ROCK,[.85,.85,.9],{tile:3});
   B.box(s*-6,0,s*6,1.6,1.4,3.2,TX.ROCK,[.85,.85,.9],{tile:3});
  });
  B.decal(0,0,14,10,TX.ICE,[1,1,1]);
  B.box(-5,0,-5,2.4,1.6,2,TX.ROCK,[.85,.85,.9],{tile:3});B.box(5,0,5,2.4,1.6,2,TX.ROCK,[.85,.85,.9],{tile:3});
  // trees (deterministic)
  const cabs=[[-14,-10],[14,10]];let n=0,tries=0;
  while(n<44&&tries<600){tries++;const x=(rg()*2-1)*29,z=(rg()*2-1)*29;
   if(Math.abs(z)>21&&Math.abs(x)<15)continue;if(Math.hypot(x,z)<8)continue;let bad=false;for(const c of cabs)if(Math.hypot(x-c[0],z-c[1])<7)bad=true;if(bad)continue;
   const sc=.8+rg()*.7;B.box(x,0,z,.45*sc,2.4*sc,.45*sc,TX.WOOD,[.5,.4,.35],{tile:1});
   B.box(x,1.6*sc,z,3.2*sc,1.6*sc,3.2*sc,TX.LEAF,[.8,1,.85],{tile:2,solid:false});B.box(x,3*sc,z,2.3*sc,1.5*sc,2.3*sc,TX.LEAF,[.85,1,.9],{tile:2,solid:false});B.box(x,4.3*sc,z,1.4*sc,1.5*sc,1.4*sc,TX.LEAF,[.9,1,.95],{tile:2,solid:false});
   B.box(x,5.7*sc,z,.7*sc,.6*sc,.7*sc,TX.SNOW,[1,1,1],{tile:1,solid:false});n++}
  for(const x of[-6,0,6,-12,12]){B.sp[0].push([x,27]);B.sp[1].push([-x,-27])}
 }},
/* ================= TRAINING RANGE ================= */
{id:'range',name:'میدان آموزش',desc:'میدان تمرین',grad:'linear-gradient(160deg,#6aa0e0,#cfd8e4)',half:20,hidden:true,
 theme:mkTheme({zen:'#4a86d6',hor:'#dfe8f2',gnd:'#9aa0a8',cloud:'#ffffff',sun:[.4,.8,.3],sunCol:[2.8,2.6,2.2],ambT:'#9ab8ea',ambB:'#8a8e94',ambK:.95,fog:'#d4dde8',fogD:.01,cloudAmt:.6,exp:1}),
 build(B){
  B.ground(TX.CONC,[1,1,1],4);B.walls(6,TX.METAL,[.6,.62,.66],4);
  B.decal(0,0,36,.5,TX.WHITE,[.9,.9,.9],{em:0});B.decal(0,12,36,.5,TX.HAZ,[1,1,1]);
  B.crate(-6,-4,1.6);B.crate(6,-4,1.6);B.crate(0,-8,1.6);B.crate(0,-8.2,1.2,1.6);B.box(-10,0,-9,4,1.2,.8,TX.CONC,[.8,.8,.82],{tile:2});B.box(10,0,-9,4,1.2,.8,TX.CONC,[.8,.8,.82],{tile:2});
  B.dummies=[[-9,-14],[-3,-14],[3,-14],[9,-14],[-12,-6],[12,-6],[0,-12]];
  B.sp[0].push([0,16]);B.sp[1].push([0,-16]);
 }}
];

function buildMap(idx){
 const def=MAPS[idx],B=new MB(def.half);def.build(B);
 const M={idx,def,name:def.name,half:def.half,theme:def.theme,boxes:B.b,solids:B.b.filter(b=>b.solid),lights:B.lights,glows:B.glows,sp:B.sp,dummies:B.dummies,snow:!!def.snow};
 const L=new InstList(B.b.length+8);
 for(const b of B.b){L.add(M4.mul(M4.T(b.x,b.y+b.h/2,b.z),M4.S(b.w,b.h,b.d)),b.col[0],b.col[1],b.col[2],b.em,b.tex,b.tile)}
 M.inst=L;return M;
}
