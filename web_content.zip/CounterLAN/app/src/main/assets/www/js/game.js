'use strict';
/* ========== data ========== */
const WEAPONS={
 pistol:{n:'کلت',price:0,dmg:24,rate:5,mag:12,res:72,rel:1.3,spr:.012,pel:1,auto:false,range:80,kick:.016},
 smg:{n:'ام‌پی‌پنج',price:900,dmg:16,rate:14,mag:30,res:150,rel:1.7,spr:.03,pel:1,auto:true,range:70,kick:.007},
 shotgun:{n:'شاتگان',price:1300,dmg:12,rate:1.25,mag:6,res:36,rel:2.4,spr:.075,pel:8,auto:false,range:28,kick:.05},
 rifle:{n:'ام‌چهار',price:2400,dmg:27,rate:9.5,mag:30,res:150,rel:2.1,spr:.014,pel:1,auto:true,range:120,kick:.011},
 sniper:{n:'اسنایپر',price:3500,dmg:105,rate:.9,mag:5,res:25,rel:2.8,spr:.05,pel:1,auto:false,range:200,kick:.07,scope:true},
 lmg:{n:'مسلسل سنگین',price:4500,dmg:21,rate:11.5,mag:100,res:200,rel:4.2,spr:.035,pel:1,auto:true,range:110,kick:.01}
};
const WORDER=['pistol','smg','shotgun','rifle','sniper','lmg'];
const AMMO_COST=150,KILL_REW=350,HEAD_REW=100,START_MONEY=1000;
const upCost=(w,lv)=>Math.max(400,Math.round(WEAPONS[w].price*.5))*(lv+1);
function stats(w,lv){const b=WEAPONS[w];lv=lv||0;return Object.assign({},b,{dmg:b.dmg*(1+.2*lv),mag:Math.round(b.mag*(1+.15*lv)),rate:b.rate*(1+.06*lv),spr:b.spr*(1-.1*lv)})}
const CM=[.32,.33,.37],CG=[.5,.52,.58],CW=[.62,.42,.24],CB=[.2,.2,.23],CL=[.2,.55,1],CO=[.42,.46,.3];
const M_=TX.METAL,W_=TX.WOOD,C_=TX.CLOTH;
const WMODEL={
 pistol:{mz:-.27,my:.045,lh:null,p:[[0,.04,-.13,.045,.05,.27,CM,M_],[0,0,-.1,.04,.045,.22,CG,M_],[0,-.065,-.01,.04,.1,.055,CB,C_],[0,.072,-.03,.012,.012,.02,CM,M_],[0,.072,-.24,.012,.012,.02,CM,M_]]},
 smg:{mz:-.5,my:.035,lh:[0,-.03,-.3],p:[[0,.03,-.16,.05,.07,.4,CG,M_],[0,.035,-.43,.022,.022,.14,CM,M_],[0,-.07,-.15,.035,.13,.05,CB,C_],[0,-.055,-.02,.04,.1,.045,CB,C_],[0,.075,-.17,.02,.02,.2,CM,M_],[0,0,.13,.03,.05,.14,CB,C_]]},
 shotgun:{mz:-.8,my:.045,lh:[0,-.02,-.38],p:[[0,.03,-.14,.05,.065,.3,CM,M_],[0,.045,-.52,.032,.032,.55,CM,M_],[0,0,-.52,.03,.03,.5,CG,M_],[0,0,-.38,.06,.045,.18,CW,W_],[0,0,.13,.045,.09,.28,CW,W_],[0,-.055,-.01,.04,.09,.045,CB,C_]]},
 rifle:{mz:-.97,my:.04,lh:[0,-.03,-.5],p:[[0,.03,-.2,.05,.07,.55,CG,M_],[0,.03,-.52,.06,.06,.28,CB,C_],[0,.04,-.82,.022,.022,.28,CM,M_],[0,-.07,-.2,.035,.14,.06,CB,C_],[0,0,.14,.04,.08,.28,CB,C_],[0,.095,-.28,.032,.035,.12,CB,C_],[0,-.055,-.03,.04,.1,.045,CB,C_]]},
 sniper:{mz:-1.27,my:.04,lh:[0,-.02,-.42],p:[[0,.03,-.22,.045,.07,.7,CG,M_],[0,.04,-.98,.02,.02,.6,CM,M_],[0,.105,-.28,.04,.04,.34,CB,C_],[0,.105,-.46,.034,.034,.012,CL,TX.WHITE,1],[0,-.05,-.22,.035,.08,.06,CB,C_],[0,0,.16,.045,.1,.32,CW,W_]]},
 lmg:{mz:-.92,my:.045,lh:[0,-.04,-.44],p:[[0,.03,-.2,.07,.09,.62,CG,M_],[0,.045,-.7,.03,.03,.4,CM,M_],[0,-.1,-.2,.11,.11,.12,CO,M_],[0,.1,-.2,.015,.05,.2,CM,M_],[0,0,.14,.05,.1,.28,CB,C_],[0,-.055,-.02,.04,.1,.045,CB,C_]]}
};
const TEAMC=[[.86,.26,.18],[.2,.44,.9]],TEAMN=['قرمز','آبی'];
const SKIN=[.85,.66,.52];
const PR=.36,PH=1.75,EYE=1.55,STEP=.55,GRAV=19;

/* ========== state ========== */
const G={role:'none',mode:'none',phase:'boot',map:null,players:{},me:null,zombies:[],fx:{parts:[],tracers:[],lights:[],dmgInd:[]},
 sens:1,vol:.8,quality:1,time:0,paused:false,H:null,tut:null,deathT:0,muzzleW:null,matchTime:0};
const IN={mx:0,mz:0,fire:false,jump:false,reload:false,swap:false,scope:false,lookX:0,lookY:0};
let R=null; // renderer
const pa=new PList(1400),pb=new PList(600),pvm=new PList(8),dyn=new InstList(512),vml=new InstList(64);

function newPlayer(id,name,team){return{id,name,team,kind:'p',x:0,y:0,z:0,vx:0,vz:0,vy:0,yaw:0,pitch:0,hp:100,alive:true,k:0,d:0,money:START_MONEY,lv:{pistol:0},w:'pistol',ammo:{pistol:{mag:12,res:72}},
 grounded:false,kick:0,phase:0,mov:0,fall:0,reloading:0,fireCd:0,swapT:0,scoped:false,respawnAt:0,seenT:0,tx:0,ty:0,tz:0,tyaw:0,tpitch:0,stepT:0,latch:false}}
function refillAmmo(p,w){const s=stats(w,p.lv[w]||0);p.ammo[w]={mag:s.mag,res:Math.round(s.res*(1+.15*(p.lv[w]||0)))}}

/* ========== collision / rays ========== */
function overlap(x,y,z,r,h){const S=G.map.solids;for(let i=0;i<S.length;i++){const b=S[i];if(x+r>b.x0&&x-r<b.x1&&z+r>b.z0&&z-r<b.z1&&y+h>b.y0+.0005&&y<b.y1-.0005)return b}return null}
function moveBody(o,dx,dz,dt,r,h){
 o.x+=dx;let b=overlap(o.x,o.y,o.z,r,h);
 if(b){if(b.y1-o.y<=STEP&&!overlap(o.x,b.y1+.001,o.z,r,h))o.y=b.y1+.001;else o.x-=dx}
 o.z+=dz;b=overlap(o.x,o.y,o.z,r,h);
 if(b){if(b.y1-o.y<=STEP&&!overlap(o.x,b.y1+.001,o.z,r,h))o.y=b.y1+.001;else o.z-=dz}
 o.vy-=GRAV*dt;o.y+=o.vy*dt;o.grounded=false;
 for(let k=0;k<3;k++){b=overlap(o.x,o.y,o.z,r,h);if(!b)break;if(o.vy<=0){o.y=b.y1;o.grounded=true}else o.y=b.y0-h-.001;o.vy=0}
}
function rayBox(o,d,b,maxT){let t0=0,t1=maxT;
 for(let i=0;i<3;i++){const mn=i===0?b.x0:i===1?b.y0:b.z0,mx=i===0?b.x1:i===1?b.y1:b.z1;
  if(Math.abs(d[i])<1e-9){if(o[i]<mn||o[i]>mx)return -1}else{let a=(mn-o[i])/d[i],c=(mx-o[i])/d[i];if(a>c){const t=a;a=c;c=t}if(a>t0)t0=a;if(c<t1)t1=c;if(t0>t1)return -1}}
 return t0}
function rayBoxes(o,d,maxT){let best=maxT;const S=G.map.solids;for(let i=0;i<S.length;i++){const t=rayBox(o,d,S[i],best);if(t>=0&&t<best)best=t}return best}
function rayCyl(o,d,cx,cz,y0,y1,r,maxT){const ox=o[0]-cx,oz=o[2]-cz,a=d[0]*d[0]+d[2]*d[2];if(a<1e-9)return -1;
 const b=2*(ox*d[0]+oz*d[2]),c=ox*ox+oz*oz-r*r,disc=b*b-4*a*c;if(disc<0)return -1;const s=Math.sqrt(disc);let t=(-b-s)/(2*a);
 if(t<0){t=(-b+s)/(2*a);if(t<0)return -1}if(t>maxT)return -1;const y=o[1]+d[1]*t;if(y<y0||y>y1)return -1;return t}
function freeAt(x,z){return !overlap(x,0.01,z,.45,PH)&&!overlap(x,.6,z,.45,.9)}
function pickSpawn(team){const sp=G.map.sp[team].filter(s=>freeAt(s[0],s[1]));const list=sp.length?sp:G.map.sp[team];let best=list[0],bs=-1;
 for(const s of list){let m=1e9;for(const id in G.players){const q=G.players[id];if(q.team!==team&&q.alive)m=Math.min(m,Math.hypot(q.x-s[0],q.z-s[1]))}const sc=m+Math.random()*6;if(sc>bs){bs=sc;best=s}}
 const yaw=Math.atan2(best[0],best[1]);return[best[0],0.02,best[1],yaw]}

/* ========== particles & fx ========== */
function addP(o){G.fx.parts.push(Object.assign({life:1,max:1,vx:0,vy:0,vz:0,g:0,s0:.1,s1:.1,c:[1,1,1],a0:1,a1:0,add:false,drag:0},o,{max:o.life}))}
function spark(x,y,z,n,col){for(let i=0;i<n;i++)addP({x,y,z,vx:rnd(-3,3),vy:rnd(0,3.5),vz:rnd(-3,3),g:9,life:rnd(.15,.4),s0:.05,s1:.01,c:col||[1,.8,.4],add:true})}
function dust(x,y,z,n,col){for(let i=0;i<n;i++)addP({x,y,z,vx:rnd(-.8,.8),vy:rnd(.2,1.2),vz:rnd(-.8,.8),life:rnd(.4,.8),s0:.1,s1:.35,c:col||[.7,.65,.6],a0:.5,a1:0,drag:2})}
function blood(x,y,z,n,col){for(let i=0;i<n;i++)addP({x,y,z,vx:rnd(-2,2),vy:rnd(0,2.5),vz:rnd(-2,2),g:8,life:rnd(.25,.6),s0:.09,s1:.04,c:col||[.7,.05,.05],a0:.9,a1:0})}
function flash(x,y,z,s){addP({x,y,z,life:.05,s0:s,s1:s*.6,c:[1,.78,.4],a0:1,a1:0,add:true});addP({x,y,z,life:.07,s0:s*.5,s1:s*.3,c:[1,1,.9],a0:1,a1:0,add:true});
 G.fx.lights.push({x,y,z,t:.06,r:11,c:[3,2,.9]})}
function updFx(dt){const F=G.fx;
 for(let i=F.parts.length-1;i>=0;i--){const p=F.parts[i];p.life-=dt;if(p.life<=0){F.parts.splice(i,1);continue}
  p.vy-=p.g*dt;if(p.drag){const k=Math.max(0,1-p.drag*dt);p.vx*=k;p.vy*=k;p.vz*=k}p.x+=p.vx*dt;p.y+=p.vy*dt;p.z+=p.vz*dt;if(p.y<.02&&p.g){p.y=.02;p.vy=0;p.vx*=.5;p.vz*=.5}}
 for(let i=F.tracers.length-1;i>=0;i--){F.tracers[i].t-=dt;if(F.tracers[i].t<=0)F.tracers.splice(i,1)}
 for(let i=F.lights.length-1;i>=0;i--){F.lights[i].t-=dt;if(F.lights[i].t<=0)F.lights.splice(i,1)}
 for(let i=F.dmgInd.length-1;i>=0;i--){F.dmgInd[i].t-=dt;if(F.dmgInd[i].t<=0)F.dmgInd.splice(i,1)}
 if(G.map.snow&&Math.random()<dt*70){const m=G.me;addP({x:m.x+rnd(-18,18),y:m.y+rnd(6,12),z:m.z+rnd(-18,18),vx:rnd(-.6,.2),vy:-rnd(1.2,2.2),vz:rnd(-.3,.3),life:5,s0:.035,s1:.035,c:[1,1,1],a0:.8,a1:.8})}
}
function playFx(m){
 const me=G.me,mine=m.id===me.id,sh=G.players[m.id];
 const o=m.o;let st=[o[0],o[1]-.15,o[2]];
 if(mine&&G.muzzleW)st=G.muzzleW;else if(sh&&!mine){const dx=m.e[0][0]-o[0],dz=m.e[0][2]-o[2],l=Math.hypot(dx,dz)||1;st=[sh.x+dx/l*.7,sh.y+1.25,sh.z+dz/l*.7];
  flash(st[0],st[1],st[2],.5);sh.seenT=1.6;Sfx.shot(m.w,Math.hypot(sh.x-me.x,sh.z-me.z),clamp(Math.sin(Math.atan2(sh.x-me.x,sh.z-me.z)+me.yaw)*.8,-1,1))}
 for(const e of m.e){
  if(e[3]!==2)G.fx.tracers.push({a:st,b:[e[0],e[1],e[2]],t:.07,w:.02});
  if(e[3]===0){spark(e[0],e[1],e[2],4);dust(e[0],e[1],e[2],2);Sfx.impact(Math.hypot(e[0]-me.x,e[2]-me.z))}
  else if(e[3]===1)blood(e[0],e[1],e[2],5);
 }
}

/* ========== characters ========== */
function drawHuman(L,o){
 const sc=o.scale||1;let base=M4.mul(M4.T(o.x,o.y,o.z),M4.RY(o.yaw));
 if(o.fall>0)base=M4.mul(base,M4.RX(Math.min(1,o.fall)*1.5));
 if(sc!==1)base=M4.mul(base,M4.S(sc,sc,sc));
 const z=o.kind==='z',d=o.kind==='d';
 const sw=Math.sin(o.phase)*o.mov*.8;
 const col=o.col,skin=z?o.skin:SKIN,pants=z?o.pants:[.15,.16,.2],shirt=z?o.shirt:[col[0]*.55,col[1]*.55,col[2]*.55];
 const P=(ox,oy,oz,rx,px,py,pz,sx,sy,sz,c,tex,em)=>L.add(M4.part(base,ox,oy,oz,rx,px,py,pz,sx,sy,sz),c[0],c[1],c[2],em||0,tex===undefined?C_:tex,1.2);
 const bw=z&&o.tank?1.25:1;
 P(-.13,.78,0,sw,0,-.39,0,.21,.78,.25,pants);P(.13,.78,0,-sw,0,-.39,0,.21,.78,.25,pants);
 P(-.13,.05,-.02,sw,0,0,0,.22,.1,.3,[.08,.08,.08]);P(.13,.05,-.02,-sw,0,0,0,.22,.1,.3,[.08,.08,.08]);
 P(0,1.1,0,0,0,0,0,.5*bw,.64,.28*bw,shirt);
 if(!z&&!d)P(0,1.12,-.01,0,0,0,0,.54,.4,.31,col);
 P(0,1.58,z?-.04:0,z?.25:0,0,0,0,.28,.28,.28,skin);
 if(!z&&!d){P(0,1.74,0,0,0,0,0,.31,.1,.31,col);P(0,1.62,-.14,0,0,0,0,.2,.05,.03,[.05,.05,.08],TX.WHITE,0)}
 if(z)for(const x of[-.07,.07])P(x,1.6,-.19,0,0,0,0,.05,.035,.02,[1,.1,.05],TX.WHITE,1);
 if(d){P(0,1.74,0,0,0,0,0,.34,.1,.34,[1,.5,.1]);P(0,1.1,-.16,0,0,0,0,.4,.4,.02,[1,1,1]);P(0,1.1,-.17,0,0,0,0,.2,.2,.02,[.9,.1,.1])}
 const ax=.3*bw;
 if(z){const w=Math.sin(o.phase*.5)*.12;P(-ax-.07,1.38,0,1.45+w,0,-.28,0,.15,.6,.17,skin);P(ax+.07,1.38,0,1.45-w,0,-.28,0,.15,.6,.17,skin)}
 else if(d){P(-ax-.07,1.38,0,.05,0,-.28,0,.15,.6,.17,shirt);P(ax+.07,1.38,0,-.05,0,-.28,0,.15,.6,.17,shirt)}
 else{const a=Math.PI/2+o.pitch;P(ax+.07,1.38,0,a,0,-.28,0,.15,.6,.17,shirt);P(-ax-.05,1.38,0,a-.25,0,-.28,0,.15,.6,.17,shirt);
  const m=WMODEL[o.w||'pistol'];let gb=M4.mul(base,M4.mul(M4.mul(M4.T(.27,1.33,-.05),M4.RX(o.pitch)),M4.S(.85,.85,.85)));
  for(const q of m.p)L.add(M4.part(gb,q[0],q[1],q[2],0,0,0,0,q[3],q[4],q[5]),q[6][0],q[6][1],q[6][2],q[8]||0,q[7],1.5)}
}
function remoteAnim(p,dt){
 if(p.rx===undefined){p.rx=p.x;p.ry=p.y;p.rz=p.z;p.ryaw=p.yaw;p.rpitch=p.pitch}
 const k=Math.min(1,dt*14),px=p.rx,pz=p.rz;
 if(Math.hypot(p.x-p.rx,p.z-p.rz)>6){p.rx=p.x;p.ry=p.y;p.rz=p.z}
 p.rx+=(p.x-p.rx)*k;p.ry+=(p.y-p.ry)*k;p.rz+=(p.z-p.rz)*k;
 let dy=p.yaw-p.ryaw;while(dy>PI)dy-=2*PI;while(dy<-PI)dy+=2*PI;p.ryaw+=dy*k;p.rpitch+=(p.pitch-p.rpitch)*k;
 const sp=Math.hypot(p.rx-px,p.rz-pz)/Math.max(dt,.001);p.mov+=((sp>.6?1:0)-p.mov)*Math.min(1,dt*10);p.phase+=sp*dt*2.2;
 p.fall=p.alive?0:Math.min(1,p.fall+dt*2.5);
}

/* ========== viewmodel ========== */
function buildViewmodel(L,eye,yaw,pitch,dt){
 const me=G.me;L.clear();pvm.clear();
 const m=WMODEL[me.w];if(!m)return;
 const bobA=me.grounded?Math.min(1,me.mov):0,t=G.time,bx=Math.sin(t*9)*.006*bobA,by=Math.abs(Math.sin(t*9))*.008*bobA;
 let rel=0,swp=0;
 if(me.reloading>0){const st=stats(me.w,me.lv[me.w]||0),u=1-me.reloading/st.rel;rel=Math.sin(clamp(u,0,1)*PI)}
 if(me.swapT>0)swp=Math.sin(clamp(me.swapT/.35,0,1)*PI*.5);
 const kk=me.kick*4;
 let C=M4.mul(M4.mul(M4.T(eye[0],eye[1],eye[2]),M4.RY(yaw)),M4.RX(pitch));
 const pt=!!G.pt,vs=pt?.5:.78;C=M4.mul(C,M4.mul(M4.T((pt?.11:.15)+bx,(pt?-.15:-.17)+by-rel*.14-swp*.22,-.36+kk*.6),M4.mul(M4.RX(kk*.8+rel*.6+swp*.5),M4.mul(M4.RY(-.04),M4.S(vs,vs,vs)))));
 for(const q of m.p)L.add(M4.part(C,q[0],q[1],q[2],0,0,0,0,q[3],q[4],q[5]),q[6][0],q[6][1],q[6][2],q[8]||0,q[7],1.5);
 const sl=TEAMC[me.team%2];const sleeve=[sl[0]*.5,sl[1]*.5,sl[2]*.5];
 L.add(M4.part(C,0,-.07,.01,0,0,0,0,.075,.08,.1),SKIN[0],SKIN[1],SKIN[2],0,C_,1);
 L.add(M4.part(C,.012,-.1,.22,0,0,0,0,.085,.09,.34),sleeve[0],sleeve[1],sleeve[2],0,C_,1);
 if(m.lh){L.add(M4.part(C,m.lh[0],m.lh[1],m.lh[2],0,0,0,0,.075,.07,.1),SKIN[0],SKIN[1],SKIN[2],0,C_,1);L.add(M4.part(C,m.lh[0]-.06,m.lh[1]-.07,m.lh[2]+.2,0,0,0,0,.08,.08,.34),sleeve[0],sleeve[1],sleeve[2],0,C_,1)}
 const mp=[.0,m.my,m.mz,1],mw=[C[0]*mp[0]+C[4]*mp[1]+C[8]*mp[2]+C[12],C[1]*mp[0]+C[5]*mp[1]+C[9]*mp[2]+C[13],C[2]*mp[0]+C[6]*mp[1]+C[10]*mp[2]+C[14]];
 G.muzzleW=mw;
}

/* ========== local player control ========== */
function curStats(){return stats(G.me.w,G.me.lv[G.me.w]||0)}
function curAmmo(){const me=G.me;if(!me.ammo[me.w])refillAmmo(me,me.w);return me.ammo[me.w]}
function setWeapon(w){const me=G.me;if(me.w===w||me.lv[w]===undefined)return;me.w=w;me.swapT=.35;me.reloading=0;me.scoped=false;Sfx.click();if(G.tut)tutEvent('swap')}
function cycleWeapon(){const me=G.me,own=WORDER.filter(w=>me.lv[w]!==undefined);if(own.length<2)return;setWeapon(own[(own.indexOf(me.w)+1)%own.length])}
function startReload(){const me=G.me,a=curAmmo(),s=curStats();if(G.tut)tutEvent('reload');if(me.reloading>0||a.mag>=s.mag||a.res<=0)return;me.reloading=s.rel;me.scoped=false;Sfx.reload()}
function updateMe(dt){
 const me=G.me;
 if(!me.alive){G.deathT+=dt;me.fall=Math.min(1,me.fall+dt*2.5);IN.lookX=IN.lookY=0;IN.jump=IN.reload=IN.swap=IN.scope=false;return}
 const s=curStats(),sens=.0042*G.sens*(me.scoped?.3:1)*(G.pt?1.3:1);
 me.yaw-=IN.lookX*sens;me.pitch=clamp(me.pitch-IN.lookY*sens,-1.45,1.45);IN.lookX=IN.lookY=0;
 let mx=IN.mx,mz=IN.mz;const ml=Math.hypot(mx,mz);if(ml>1){mx/=ml;mz/=ml}
 const sp=5.2*(me.scoped?.45:1)*(me.w==='lmg'?.88:1),c=Math.cos(me.yaw),sn=Math.sin(me.yaw);
 const tvx=(-sn*mz+c*mx)*sp,tvz=(-c*mz-sn*mx)*sp,k=Math.min(1,dt*(me.grounded?12:3));
 me.vx+=(tvx-me.vx)*k;me.vz+=(tvz-me.vz)*k;
 if(IN.jump){IN.jump=false;if(me.grounded){me.vy=6.3;if(G.tut)tutEvent('jump')}}
 const ox=me.x,oz=me.z;moveBody(me,me.vx*dt,me.vz*dt,dt,PR,PH);
 const spd=Math.hypot(me.x-ox,me.z-oz)/dt;me.mov+=((spd>.8?1:0)-me.mov)*Math.min(1,dt*10);if(G.tut)G.tut.dist+=Math.hypot(me.x-ox,me.z-oz);
 if(me.grounded&&spd>1){me.stepT-=dt*spd;if(me.stepT<=0){me.stepT=2.2;Sfx.step()}}
 if(me.y<-8){me.x=0;me.z=0;me.y=2;me.vy=0}
 me.kick=Math.max(0,me.kick-dt*.9);me.fireCd-=dt;if(me.swapT>0)me.swapT-=dt;
 if(IN.swap){IN.swap=false;cycleWeapon()}
 if(IN.reload){IN.reload=false;startReload()}
 if(IN.scope){IN.scope=false;if(s.scope&&me.reloading<=0)me.scoped=!me.scoped}
 if(!s.scope)me.scoped=false;
 if(me.reloading>0){me.reloading-=dt;if(me.reloading<=0){const a=curAmmo(),take=Math.min(s.mag-a.mag,a.res);a.mag+=take;a.res-=take;me.reloading=0}}
 if(IN.fire){if(me.fireCd<=0&&me.reloading<=0&&me.swapT<=0&&(s.auto||!me.latch)){fireWeapon(s);me.latch=true}}else me.latch=false;
}
function fireWeapon(s){
 const me=G.me,a=curAmmo();
 if(a.mag<=0){me.fireCd=.25;if(a.res>0)startReload();else Sfx.empty();return}
 a.mag--;me.fireCd=1/s.rate;me.kick=Math.min(.12,me.kick+s.kick);
 let spr=s.spr*(1+me.mov*1.1+(me.grounded?0:2.2));if(s.scope)spr=me.scoped?.0006:s.spr*4;
 me.sprNow=spr;
 const cp=Math.cos(me.pitch+me.kick*.5),dir=[-Math.sin(me.yaw)*cp,Math.sin(me.pitch+me.kick*.5),-Math.cos(me.yaw)*cp],o=[me.x,me.y+EYE,me.z];
 Sfx.shot(me.w,0,0);const mw=G.muzzleW||o;flash(mw[0],mw[1],mw[2],.35);
 if(G.tut)tutEvent('shoot');
 if(G.role==='client')Net.send({t:'shot',o:[r2(o[0]),r2(o[1]),r2(o[2])],d:[dir[0],dir[1],dir[2]],w:me.w,sp:spr});
 else authShot(me,o,dir,me.w,spr);
 if(a.mag<=0&&a.res>0)setTimeout(()=>{if(G.me.alive)startReload()},250);
}

/* ========== authoritative shooting ========== */
function targetsFor(p){const T=[];
 if(G.mode==='tdm'){for(const id in G.players){const q=G.players[id];if(q!==p&&q.alive&&q.team!==p.team)T.push({ref:q,x:q.x,y:q.y,z:q.z,r:.4,h:PH})}}
 else for(const z of G.zombies){if(!z.dead)T.push({ref:z,x:z.x,y:z.y,z:z.z,r:z.r+.05,h:z.h})}
 return T}
function authShot(p,o,d,wid,sp){
 const st=stats(wid,p.lv[wid]||0),T=targetsFor(p),ends=[],hits=new Map();
 for(let i=0;i<st.pel;i++){
  let dir=d;if(sp>0){let rx=rnd(-1,1),ry=rnd(-1,1);while(rx*rx+ry*ry>1){rx=rnd(-1,1);ry=rnd(-1,1)}
   const r=[Math.cos(Math.atan2(-d[0],-d[2])),0,-Math.sin(Math.atan2(-d[0],-d[2]))],u=[r[1]*d[2]-r[2]*d[1],r[2]*d[0]-r[0]*d[2],r[0]*d[1]-r[1]*d[0]];
   dir=[d[0]+(r[0]*rx+u[0]*ry)*sp,d[1]+(r[1]*rx+u[1]*ry)*sp,d[2]+(r[2]*rx+u[2]*ry)*sp];const l=Math.hypot(...dir);dir=[dir[0]/l,dir[1]/l,dir[2]/l]}
  const tm=rayBoxes(o,dir,st.range);let bt=tm,best=null;
  for(const tg of T){const t=rayCyl(o,dir,tg.x,tg.z,tg.y,tg.y+tg.h,tg.r,bt);if(t>=0&&t<bt){bt=t;best=tg}}
  const ex=o[0]+dir[0]*bt,ey=o[1]+dir[1]*bt,ez=o[2]+dir[2]*bt;
  if(best){const head=(ey-best.y)>best.h*.8;let dmg=st.dmg*(head?2:1);if(st.pel>1)dmg*=Math.max(.3,1-bt/st.range);
   const h=hits.get(best.ref)||{dmg:0,head:false};h.dmg+=dmg;h.head=h.head||head;hits.set(best.ref,h);ends.push([r2(ex),r2(ey),r2(ez),1])}
  else ends.push([r2(ex),r2(ey),r2(ez),tm>=st.range-.01?2:0]);
 }
 const msg={t:'fx',id:p.id,w:wid,o:[r2(o[0]),r2(o[1]),r2(o[2])],e:ends};
 playFx(msg);if(G.role==='host')Net.hostSend('*',msg);
 for(const[ref,h]of hits){const killed=ref.kind==='p'?damagePlayer(ref,h.dmg,p,h.head,wid):damageZombie(ref,h.dmg,p,h.head);
  if(p===G.me){UI.hitmark(killed,h.head);Sfx.hit(h.head);if(killed)Sfx.kill()}else if(G.role==='host')Net.hostSend(p.id,{t:'hm',h:h.head?1:0,k:killed?1:0})}
}

/* ========== frame ========== */
function viewState(){
 const me=G.me;let yaw=me.yaw,pitch=me.pitch,y=me.y+EYE;
 if(!me.alive){y=me.y+EYE-Math.min(1,me.fall)*1.2;pitch=clamp(me.pitch+me.fall*.4,-1.4,1.4);}
 return{eye:[me.x,y,me.z],yaw,pitch}
}
function buildScene(dt){
 const me=G.me,M=G.map;dyn.clear();pa.clear();pb.clear();
 for(const id in G.players){const p=G.players[id];if(p===me)continue;remoteAnim(p,dt);
  drawHuman(dyn,{x:p.rx,y:p.ry,z:p.rz,yaw:p.ryaw,pitch:p.rpitch,phase:p.phase,mov:p.mov,col:TEAMC[p.team%2],kind:'p',w:p.w,fall:p.alive?0:p.fall})}
 for(const z of G.zombies){if(z.dead&&z.deadT>2.2)continue;drawHuman(dyn,{x:z.x,y:z.y,z:z.z,yaw:z.yaw,pitch:0,phase:z.phase,mov:z.dead?0:(z.dummy?0:1),kind:z.dummy?'d':'z',col:[1,1,1],skin:z.skin,shirt:z.shirt,pants:z.pants,scale:z.scale,tank:z.tank,fall:z.dead?Math.min(1,z.deadT*2):0})}
 for(const t of G.fx.tracers){const k=t.t/.07;dyn.add(M4.between(t.a,t.b,t.w*k+.004),1,.85,.45,1,TX.WHITE,1)}
 // particles
 for(const p of G.fx.parts){const k=p.life/p.max,s=lerp(p.s1,p.s0,k),a=lerp(p.a1,p.a0,k);(p.add?pb:pa).add(p.x,p.y,p.z,s,p.c[0],p.c[1],p.c[2],a)}
 const eye=[me.x,me.y+EYE,me.z];
 for(const g of M.glows){const dx=g.x-eye[0],dz=g.z-eye[2];if(dx*dx+dz*dz<70*70)pb.add(g.x,g.y,g.z,g.s,g.c[0],g.c[1],g.c[2],.42)}
}
function pickLights(eye){
 const L=[],M=G.map;const arr=M.lights.map(l=>({l,d:(l.x-eye[0])**2+(l.y-eye[1])**2+(l.z-eye[2])**2})).sort((a,b)=>a.d-b.d);
 for(let i=0;i<Math.min(4,arr.length);i++)L.push(arr[i].l);
 for(const f of G.fx.lights.slice(-2))L.push(f);
 return L}
function renderFrame(){
 const me=G.me,v=viewState(),sp=G.map?G.map.theme:null;
 let fov=1.28;if(me&&me.scoped)fov=.3;
 const vmOn=me.alive&&!me.scoped&&G.phase==='play';
 if(vmOn)buildViewmodel(vml,v.eye,v.yaw,v.pitch+me.kick*.5,0);else vml.clear();
 const f={eye:v.eye,yaw:v.yaw,pitch:v.pitch+(me.alive?me.kick*.5:0),fov,vmFov:1.0,theme:sp,dyn,vm:vml,pa,pb,pvm,lights:pickLights(v.eye),time:G.time};
 return R.render(f);
}
