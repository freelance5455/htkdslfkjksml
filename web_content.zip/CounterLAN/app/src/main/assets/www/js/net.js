'use strict';
// Network layer. On Android: Java bridge (TCP server + UDP discovery). In a desktop browser: BroadcastChannel mock for testing.
const Net=(()=>{
 const native=(typeof Android!=='undefined');
 let h={};const uid=Math.random().toString(36).slice(2,8);
 const bc=(!native&&typeof BroadcastChannel!=='undefined')?new BroadcastChannel('fpsnet'):null;
 let mockHost=null,annTimer=null,discovering=false,hostUid=null,myId=0;const peers={},uidById={};let nextId=1;
 const emit=(k,...a)=>{try{h[k]&&h[k](...a)}catch(e){console.error(e)}};
 window.__net=function(type,a,b){
  if(type==='server'){try{emit('server',a,JSON.parse(b))}catch(e){}}
  else if(type==='open')emit('open');
  else if(type==='close')emit('close');
  else if(type==='error')emit('error',a);
  else if(type==='msg'){try{emit('msg',JSON.parse(a))}catch(e){}}
  else if(type==='hmsg'){try{emit('hmsg',+a,JSON.parse(b))}catch(e){}}
  else if(type==='peer')emit('peer',+a,b==='1');
 };
 if(bc)bc.onmessage=e=>{const m=e.data;
  if(m.k==='ann'&&discovering&&m.uid!==uid)emit('server',m.uid,m.info);
  else if(m.k==='join'&&mockHost&&m.to===uid){const id=nextId++;peers[m.uid]=id;uidById[id]=m.uid;bc.postMessage({k:'ok',to:m.uid,id});emit('peer',id,true)}
  else if(m.k==='ok'&&m.to===uid){myId=m.id;emit('open')}
  else if(m.k==='c2h'&&mockHost&&peers[m.uid]!==undefined){let o;try{o=JSON.parse(m.line)}catch(e){return}emit('hmsg',peers[m.uid],o)}
  else if(m.k==='h2c'&&hostUid===m.from&&(m.to==='*'||m.to===uid)){try{emit('msg',JSON.parse(m.line))}catch(e){}}
  else if(m.k==='bye'&&mockHost&&peers[m.uid]!==undefined){const id=peers[m.uid];delete peers[m.uid];delete uidById[id];emit('peer',id,false)}
  else if(m.k==='hbye'&&hostUid===m.from){hostUid=null;emit('close')}
 };

 // ---- WebRTC manual code pairing (works with no native bridge: both phones on same Wi-Fi/hotspot, codes copied by hand) ----
 const rtcHost={},rtcById={};let rtcC=null,rtcN=1;
 const enc=o=>btoa(unescape(encodeURIComponent(JSON.stringify(o))));
 const dec=t=>JSON.parse(decodeURIComponent(escape(atob(t.replace(/\s+/g,'')))));
 const mkPc=()=>new RTCPeerConnection({iceServers:[]});
 const gathered=pc=>new Promise(r=>{if(pc.iceGatheringState==='complete')return r();const f=()=>{if(pc.iceGatheringState==='complete'){pc.removeEventListener('icegatheringstatechange',f);r()}};pc.addEventListener('icegatheringstatechange',f);setTimeout(r,3500)});
 async function rtcOffer(){const pc=mkPc(),dc=pc.createDataChannel('g'),rid=rtcN++;const r={pc,dc,id:0};rtcHost[rid]=r;
  dc.onopen=()=>{r.id=nextId++;rtcById[r.id]=r;emit('peer',r.id,true)};
  dc.onmessage=e=>{try{emit('hmsg',r.id,JSON.parse(e.data))}catch(x){}};
  const gone=()=>{if(r.id&&rtcById[r.id]){delete rtcById[r.id];emit('peer',r.id,false)}};dc.onclose=gone;
  pc.onconnectionstatechange=()=>{if(pc.connectionState==='failed'||pc.connectionState==='closed')gone()};
  await pc.setLocalDescription(await pc.createOffer());await gathered(pc);
  return{rid,code:enc(pc.localDescription)}}
 async function rtcAccept(rid,code){const r=rtcHost[rid];if(!r)throw new Error('no offer');await r.pc.setRemoteDescription(dec(code))}
 async function rtcJoin(code){const pc=mkPc();rtcC={pc,dc:null};
  pc.ondatachannel=e=>{const dc=e.channel;rtcC.dc=dc;
   dc.onopen=()=>emit('open');
   dc.onmessage=m=>{try{emit('msg',JSON.parse(m.data))}catch(x){}};
   dc.onclose=()=>{if(rtcC){rtcC=null;emit('close')}}};
  pc.onconnectionstatechange=()=>{if(rtcC&&(pc.connectionState==='failed'||pc.connectionState==='disconnected')){rtcC=null;emit('close')}};
  await pc.setRemoteDescription(dec(code));await pc.setLocalDescription(await pc.createAnswer());await gathered(pc);
  return enc(pc.localDescription)}
 const rtcSendTo=(to,line)=>{for(const k in rtcById){if(to==='*'||+to===+k){const d=rtcById[k].dc;if(d.readyState==='open')d.send(line)}}};
 return{
  native,on(o){h=o},rtcOffer,rtcAccept,rtcJoin,rtcOK:typeof RTCPeerConnection!=='undefined',
  hostStart(info){nextId=1;if(native){Android.hostStart(JSON.stringify(info))}else if(bc){mockHost=info;annTimer=setInterval(()=>bc.postMessage({k:'ann',uid,info:mockHost}),800)}},
  hostInfo(info){if(native)Android.hostInfo(JSON.stringify(info));else mockHost=info},
  hostSend(to,obj){const line=JSON.stringify(obj);rtcSendTo(to,line);if(native)Android.hostSend(String(to),line);else if(bc){bc.postMessage({k:'h2c',from:uid,to:to==='*'?'*':uidById[to],line})}},
  hostKick(id){if(native)Android.hostKick(id);const r=rtcById[id];if(r){try{r.dc.close();r.pc.close()}catch(e){}}},
  hostStop(){for(const k in rtcHost){try{rtcHost[k].pc.close()}catch(e){}delete rtcHost[k]}for(const k in rtcById)delete rtcById[k];if(native)Android.hostStop();else if(bc&&mockHost){bc.postMessage({k:'hbye',from:uid});clearInterval(annTimer);mockHost=null}},
  discoverStart(){if(native)Android.discoverStart();else discovering=true},
  discoverStop(){if(native)Android.discoverStop();else discovering=false},
  connect(ip,port){if(native)Android.connect(ip,port|0);else if(bc){hostUid=ip;bc.postMessage({k:'join',uid,to:ip})}},
  send(obj){const line=JSON.stringify(obj);if(rtcC){if(rtcC.dc&&rtcC.dc.readyState==='open')rtcC.dc.send(line);return}if(native)Android.send(line);else if(bc&&hostUid)bc.postMessage({k:'c2h',uid,line})},
  disconnect(){if(rtcC){const c=rtcC;rtcC=null;try{c.pc.close()}catch(e){}return}if(native)Android.disconnect();else if(bc&&hostUid){bc.postMessage({k:'bye',uid});hostUid=null}},
  localIp(){return native?Android.localIp():'—'}
 };
})();
