'use strict';
let canvas,ov2d,ov2c,radarC,radarX,radarOff=null,lastT=0,snapT=0,sendT=0,hudT=0,radarT=0,lastVP=null;
const Z={wave:0,state:'break',toSpawn:0,spawnT:0,breakT:3,kills:0};
const RANGE_IDX=()=>MAPS.findIndex(m=>m.id==='range');
const W_IDX=w=>WORDER.indexOf(w);

/* ========== boot / map ========== */
function initGame(){
 canvas=document.getElementById('gl');ov2d=document.getElementById('ov2d');ov2c=ov2d.getContext('2d');radarC=document.getElementById('radar');radarX=radarC.getContext('2d');
 loadSettings();R=new Renderer(canvas,{texSize:G.quality===0?128:256});applyQuality();
 G.me=newPlayer(0,'',0);G.players={0:G.me};loadMap(0);G.phase='menu';
 window.addEventListener('resize',resize2d);resize2d();
 requestAnimationFrame(frame);
}
function resize2d(){if(!ov2d)return;const L=(typeof Lay!=='undefined')?Lay:null;ov2d.width=(L&&L.w)||innerWidth;ov2d.height=(L&&L.h)||innerHeight}
function applyQuality(){const q=G.quality;R.setQuality(q===0?{shadows:false,scale:.62,shadowSize:512}:q===1?{shadows:true,shadowSize:1024,scale:.8}:{shadows:true,shadowSize:2048,scale:1})}
function loadMap(idx){G.mapIdx=idx;const m=buildMap(idx);G.map=m;R.setStatic(m.inst);buildRadar()}
function buildRadar(){const m=G.map,k=4,S=(m.half*2+4)*k;radarOff=document.createElement('canvas');radarOff.width=radarOff.height=S;const c=radarOff.getContext('2d');
 c.fillStyle='rgba(20,28,40,.55)';c.fillRect(0,0,S,S);
 for(const b of m.solids){if(b.h>20||b.y1<.5||b.w>m.half*2)continue;c.fillStyle=b.h>2.2?'rgba(210,220,240,.9)':'rgba(140,155,180,.8)';c.fillRect((b.x0+m.half+2)*k,(b.z0+m.half+2)*k,b.w*k,b.d*k)}}
function loadSettings(){try{const s=JSON.parse(localStorage.getItem('fpsset')||'{}');G.sens=s.sens||1;G.vol=s.vol===undefined?.8:s.vol;G.quality=s.q===undefined?1:s.q}catch(e){}}
function saveSettings(){try{localStorage.setItem('fpsset',JSON.stringify({sens:G.sens,vol:G.vol,q:G.quality}))}catch(e){}}
function resetCommon(){G.fx={parts:[],tracers:[],lights:[],dmgInd:[]};G.zombies=[];G.tut=null;G.paused=false;G.deathT=0;G.killerName='';G.H=null;G.matchTime=0;
 IN.fire=IN.jump=IN.reload=IN.swap=IN.scope=false;IN.mx=IN.mz=0}
function placeMe(s){const me=G.me;me.x=s[0];me.y=s[1];me.z=s[2];me.yaw=s[3];me.pitch=0;me.vx=me.vz=me.vy=0;me.hp=100;me.alive=true;me.fall=0;me.reloading=0;me.scoped=false}
function resetStats(p){p.k=p.d=0;p.money=START_MONEY;p.lv={pistol:0};p.w='pistol';p.ammo={};refillAmmo(p,'pistol');p.alive=true;p.hp=100;p.fall=0;p.reloading=0}
function toMenu(){try{Net.disconnect();Net.hostStop();Net.discoverStop()}catch(e){}
 resetCommon();G.role='none';G.mode='none';G.phase='menu';G.me=newPlayer(0,'',0);G.players={0:G.me};loadMap(0);UI.exitGame();UI.portrait(false);UI.show('sMain')}

/* ========== solo modes ========== */
function startSolo(mode,mapIdx){
 resetCommon();G.role='solo';G.mode=mode;loadMap(mapIdx);
 const me=G.me=newPlayer(0,UI.name(),0);G.players={0:me};resetStats(me);
 const sp=G.map.sp[0][0];const ang=Math.atan2(sp[0],sp[1]);placeMe([sp[0],.02,sp[1],ang]);
 if(mode==='zombie'){Z.wave=0;Z.state='break';Z.breakT=4;Z.kills=0;UI.toast('آماده باش… زامبی‌ها دارن میان!',3)}
 if(mode==='tutorial'){for(const d of G.map.dummies)G.zombies.push(mkDummy(d[0],d[1]));G.tut={i:0,dist:0,yawSum:0,lastYaw:me.yaw,k3:0,done:false};UI.tut(TUT_STEPS[0].t,TUT_STEPS[0].btn)}
 G.phase='play';UI.enterGame();
}
function mkDummy(x,z){return{kind:'z',dummy:true,x,y:.02,z,vy:0,yaw:0,phase:0,dead:false,deadT:0,hp:90,max:90,r:.36,h:1.75,scale:1,skin:SKIN,shirt:[1,.5,.1],pants:[.2,.2,.25],reward:150,type:'dummy',grounded:true}}
function zSpawnPos(){const m=G.map,me=G.me;for(let i=0;i<60;i++){const a=Math.random()*6.283,rad=rnd(m.half*.45,m.half-3),x=Math.cos(a)*rad,z=Math.sin(a)*rad;
 if(freeAt(x,z)&&Math.hypot(x-me.x,z-me.z)>14)return[x,z]}return[m.sp[1][0][0],m.sp[1][0][1]]}
function spawnZombie(){
 const w=Z.wave,r=Math.random();let type='walk';if(w>=5&&r<.1)type='tank';else if(w>=3&&r<.32)type='run';
 const p=zSpawnPos(),pick=a=>a[Math.floor(Math.random()*a.length)];
 const z={kind:'z',x:p[0],y:.02,z:p[1],vy:0,yaw:0,phase:Math.random()*6,dead:false,deadT:0,atkT:.5,stuck:0,side:1,sideT:0,grounded:false,r:.36,h:1.75,scale:1,tank:false,type,
  skin:pick([[.45,.62,.4],[.5,.64,.46],[.4,.52,.38],[.55,.6,.42]]),shirt:pick([[.3,.25,.2],[.4,.15,.15],[.2,.25,.35],[.35,.35,.3],[.15,.2,.15]]),pants:pick([[.15,.15,.2],[.25,.2,.15],[.12,.14,.18]]),groan:rnd(2,6)};
 if(type==='walk'){z.hp=40+w*7;z.speed=Math.min(3.1,rnd(1.5,2.3)+w*.04);z.dmg=10;z.reward=60}
 else if(type==='run'){z.hp=28+w*4;z.speed=rnd(3.8,4.7);z.dmg=8;z.reward=80;z.skin=[.55,.35,.3]}
 else{z.hp=380+w*40;z.speed=1.9;z.dmg=25;z.reward=300;z.scale=1.35;z.r=.49;z.h=2.36;z.tank=true;z.shirt=[.1,.1,.12]}
 z.max=z.hp;G.zombies.push(z)}
function updateZombie(z,dt){
 const me=G.me;
 if(z.dead){z.deadT+=dt;if(z.dummy&&z.deadT>2.5){z.dead=false;z.hp=z.max}return}
 if(z.dummy)return;
 if(!me.alive)return;
 const dx=me.x-z.x,dz=me.z-z.z,dist=Math.hypot(dx,dz)||.01;z.yaw=Math.atan2(-dx,-dz);
 let mx=dx/dist,mz=dz/dist;if(z.sideT>0){z.sideT-=dt;const t=mx;mx=-mz*z.side;mz=t*z.side}
 const sp=dist<1.05?0:z.speed;z.phase+=dt*(sp||.5)*2.6;const ox=z.x,oz=z.z;
 moveBody(z,mx*sp*dt,mz*sp*dt,dt,z.r,z.h);
 const moved=Math.hypot(z.x-ox,z.z-oz);
 if(sp>0&&moved<sp*dt*.3){z.stuck+=dt;if(z.stuck>.3&&z.grounded)z.vy=6.4;if(z.stuck>1){z.side=Math.random()<.5?1:-1;z.sideT=1.3;z.stuck=0}}else z.stuck=Math.max(0,z.stuck-dt*2);
 if(dist<1.2*z.scale&&Math.abs(me.y-z.y)<1.7){z.atkT-=dt;if(z.atkT<=0){z.atkT=.9;hurtMe(z.dmg,z)}}else z.atkT=Math.min(z.atkT,.35);
 z.groan-=dt;if(z.groan<=0){z.groan=rnd(3,8);Sfx.zombie(dist,clamp(Math.sin(Math.atan2(z.x-me.x,z.z-me.z)+me.yaw),-1,1))}
}
function zombieTick(dt){
 const me=G.me;
 if(G.mode==='zombie'){
  if(Z.state==='break'){Z.breakT-=dt;if(Z.breakT<=0){Z.wave++;Z.toSpawn=5+Z.wave*3;Z.state='run';Z.spawnT=0;UI.toast('موج '+Z.wave,2);Sfx.horn()}}
  else{Z.spawnT-=dt;const al=G.zombies.filter(z=>!z.dead).length;
   if(Z.toSpawn>0&&Z.spawnT<=0&&al<18){spawnZombie();Z.toSpawn--;Z.spawnT=Math.max(.35,1.1-Z.wave*.06)}
   if(Z.toSpawn===0&&al===0){Z.state='break';Z.breakT=7;const b=150+Z.wave*30;me.money+=b;UI.toast('موج تمام شد! +$'+b,2.5);UI.shopRefresh()}}
  me.hitT=(me.hitT||0)+dt;if(me.hitT>6&&me.hp<100&&me.alive)me.hp=Math.min(100,me.hp+8*dt);
 }
 const Zs=G.zombies;
 for(const z of Zs)updateZombie(z,dt);
 for(let i=0;i<Zs.length;i++){const a=Zs[i];if(a.dead||a.dummy)continue;for(let j=i+1;j<Zs.length;j++){const b=Zs[j];if(b.dead||b.dummy)continue;const dx=b.x-a.x,dz=b.z-a.z,d=Math.hypot(dx,dz);if(d<.75&&d>.001){const p=(.75-d)*.5/d;a.x-=dx*p;a.z-=dz*p;b.x+=dx*p;b.z+=dz*p}}}
 if(G.mode==='zombie')G.zombies=Zs.filter(z=>!(z.dead&&z.deadT>3));
}
function damageZombie(z,dmg,p,head){
 if(z.dead)return false;z.hp-=dmg;
 if(z.hp<=0){z.dead=true;z.deadT=0;Z.kills++;if(p===G.me){p.money+=z.reward+(head?20:0);UI.toast('+$'+(z.reward+(head?20:0)),1);UI.shopRefresh();if(G.tut)tutEvent('kill')}return true}
 return false}
function hurtMe(dmg,src){
 const me=G.me;if(!me.alive)return;me.hp-=dmg;me.hitT=0;Sfx.hurt();UI.dmgFlash();
 if(src){const dx=src.x-me.x,dz=src.z-me.z,l=Math.hypot(dx,dz)||1;G.fx.dmgInd.push({dx:dx/l,dz:dz/l,t:1.3})}
 if(me.hp<=0){if(G.mode==='tutorial'){me.hp=100;return}me.hp=0;me.alive=false;G.phase='end';Sfx.die();UI.showEnd({solo:true,wave:Z.wave,kills:Z.kills})}}

/* ========== tutorial ========== */
const TUT_STEPS=[
 {t:'با جوی‌استیک سمت چپ صفحه راه برو',btn:'stickZone',ok:T=>T.dist>6},
 {t:'انگشتت رو روی سمت راست صفحه بکش تا اطراف رو ببینی',btn:null,ok:T=>Math.abs(T.yawSum)>2.6},
 {t:'دکمه پرش رو بزن',btn:'btnJump',ev:'jump'},
 {t:'به یکی از هدف‌ها نزدیک شو و با دکمه شلیک بزنش',btn:'btnFire',ev:'kill'},
 {t:'دکمه ری‌لود رو بزن تا خشاب پر بشه',btn:'btnReload',ev:'reload'},
 {t:'فروشگاه رو باز کن و «ام‌پی‌پنج» بخر (۹۰۰$)',btn:'btnShop',ev:'buy'},
 {t:'با دکمه تعویض سلاح، ام‌پی‌پنج رو انتخاب کن',btn:'btnSwap',ev:'swap'},
 {t:'با ام‌پی‌پنج ۳ تا هدف رو بزن',btn:'btnFire',ev:'kill3'},
 {t:'آفرین! آموزش تموم شد. حالا برو سراغ بازی اصلی 🎉',btn:null,end:true}
];
function tutNext(){const T=G.tut;T.i++;const s=TUT_STEPS[T.i];Sfx.kill();UI.tut(s.t,s.btn);if(s.end){T.done=true;UI.tutDone();return}
 if(s.ev==='swap'&&G.me.w==='smg')tutNext()}
function tutEvent(e,x){const T=G.tut;if(!T||T.done)return;const s=TUT_STEPS[T.i];if(!s)return;
 if(s.ev==='jump'&&e==='jump')tutNext();else if(s.ev==='kill'&&e==='kill')tutNext();else if(s.ev==='reload'&&e==='reload')tutNext();
 else if(s.ev==='buy'&&e==='buy'&&x==='smg')tutNext();else if(s.ev==='swap'&&e==='swap'&&G.me.w==='smg')tutNext();
 else if(s.ev==='kill3'&&e==='kill'&&G.me.w==='smg'){T.k3++;if(T.k3>=3)tutNext()}}
function tutTick(){const T=G.tut;if(!T||T.done)return;let d=G.me.yaw-T.lastYaw;T.lastYaw=G.me.yaw;T.yawSum+=d;const s=TUT_STEPS[T.i];if(s&&s.ok&&s.ok(T))tutNext()}

/* ========== shop ========== */
function doBuy(p,w,kind){
 const W=WEAPONS[w];if(!W)return false;
 if(kind==='buy'){if(p.lv[w]!==undefined||p.money<W.price)return false;p.money-=W.price;p.lv[w]=0}
 else if(kind==='upg'){const lv=p.lv[w];if(lv===undefined||lv>=3)return false;const c=upCost(w,lv);if(p.money<c)return false;p.money-=c;p.lv[w]=lv+1}
 else if(kind==='ammo'){if(p.lv[w]===undefined||p.money<AMMO_COST)return false;p.money-=AMMO_COST}
 else return false;
 if(p===G.me){if(kind==='buy'){refillAmmo(p,w);setWeapon(w)}else refillAmmo(p,w);Sfx.buy();UI.shopRefresh();if(G.tut&&kind==='buy')tutEvent('buy',w)}
 else Net.hostSend(p.id,{t:'pst',m:p.money,lv:p.lv,rf:kind==='buy'?null:w,nw:kind==='buy'?w:null});
 return true}
function buyReq(w,kind){if(G.role==='client')Net.send({t:'buy',w,k:kind});else doBuy(G.me,w,kind)}
function applyPst(m){const me=G.me,prev=me.money;
 for(const w in m.lv){if(me.lv[w]===undefined){me.lv[w]=m.lv[w];refillAmmo(me,w)}else if(m.lv[w]>me.lv[w]){me.lv[w]=m.lv[w];refillAmmo(me,w)}}
 if(m.rf)refillAmmo(me,m.rf);me.money=m.m;
 if(m.nw)setWeapon(m.nw);
 if(m.m>prev)UI.toast('+$'+(m.m-prev),1);else if(m.m<prev)Sfx.buy();
 UI.shopRefresh()}

/* ========== host ========== */
function hostInfo(){return{n:G.H.name,m:G.H.mapIdx,c:Object.keys(G.players).length,x:6,ph:G.phase==='play'?1:0}}
function hostCreate(name,mapIdx,limit){
 resetCommon();G.role='host';G.mode='tdm';loadMap(mapIdx);
 const me=G.me=newPlayer(0,UI.name(),0);G.players={0:me};resetStats(me);
 G.H={name,mapIdx,limit,sc:[0,0],over:false};
 Net.hostStart(hostInfo());G.phase='lobby';broadcastLobby(false);UI.show('sLobby')}
function playerList(){return Object.values(G.players).map(p=>({id:p.id,n:p.name,t:p.team,k:p.k,d:p.d}))}
function broadcastLobby(back){
 const msg={t:'lobby',pl:playerList(),m:G.H.mapIdx,lim:G.H.limit,hn:G.H.name,back:!!back};
 Net.hostSend('*',msg);UI.lobby(msg);Net.hostInfo(hostInfo())}
function teamCount(t){return Object.values(G.players).filter(p=>p.team===t).length}
function hostMsg(id,m){
 if(m.t==='hello'){
  if(Object.keys(G.players).length>=6){Net.hostSend(id,{t:'full'});Net.hostKick(id);return}
  const p=newPlayer(id,String(m.name||'بازیکن').slice(0,12),teamCount(0)<=teamCount(1)?0:1);resetStats(p);G.players[id]=p;
  Net.hostSend(id,{t:'welcome',id,map:G.H.mapIdx,lim:G.H.limit});
  if(G.phase==='play'){Net.hostSend(id,{t:'start',m:G.H.mapIdx,lim:G.H.limit,pl:playerList()});respawnPlayer(p)}
  broadcastLobby(false);return}
 const p=G.players[id];if(!p)return;
 if(m.t==='team'){const t=m.team===1?1:0;if(p.team!==t&&teamCount(t)<3&&G.phase==='lobby'){p.team=t;broadcastLobby(false)}}
 else if(m.t==='s'){if(p.alive){p.x=m.x;p.y=m.y;p.z=m.z;p.yaw=m.yaw;p.pitch=m.pitch;p.w=WORDER[m.w]||'pistol'}}
 else if(m.t==='shot'){if(G.phase==='play'&&p.alive&&p.lv[m.w]!==undefined)authShot(p,m.o,m.d,m.w,Math.min(.2,m.sp||0))}
 else if(m.t==='buy'){if(G.phase==='play')doBuy(p,m.w,m.k)}
}
function removePlayer(id){const p=G.players[id];if(!p||p===G.me)return;delete G.players[id];if(G.role==='host'){UI.feed(p.name+' خارج شد','sys');broadcastLobby(false)}}
function hostStartMatch(){
 const H=G.H;H.sc=[0,0];H.over=false;G.phase='play';
 for(const id in G.players)resetStats(G.players[id]);
 Net.hostSend('*',{t:'start',m:H.mapIdx,lim:H.limit,pl:playerList()});
 for(const id in G.players)respawnPlayer(G.players[id]);
 UI.enterGame();Net.hostInfo(hostInfo())}
function hostBackToLobby(){G.phase='lobby';UI.exitGame();broadcastLobby(true);UI.show('sLobby')}
function respawnPlayer(p){
 const s=pickSpawn(p.team);p.x=s[0];p.y=s[1];p.z=s[2];p.yaw=s[3];p.pitch=0;p.hp=100;p.alive=true;p.vy=0;p.vx=p.vz=0;p.fall=0;p.rx=undefined;
 if(p===G.me)onLocalRespawn();else Net.hostSend(p.id,{t:'spawn',x:r2(p.x),y:r2(p.y),z:r2(p.z),yaw:r2(p.yaw)})}
function onLocalRespawn(){const me=G.me;me.alive=true;me.hp=100;me.fall=0;me.reloading=0;me.scoped=false;me.vx=me.vz=me.vy=0;for(const w in me.lv)refillAmmo(me,w);UI.showDeath(false)}
function onLocalDeath(){const me=G.me;Sfx.die();me.alive=false;me.fall=0;me.scoped=false;G.deathT=0;IN.fire=false;UI.showDeath(true,G.killerName)}
function damagePlayer(v,dmg,a,head,wid){
 if(!v.alive||G.phase!=='play')return false;v.hp-=dmg;
 const dx=a.x-v.x,dz=a.z-v.z,l=Math.hypot(dx,dz)||1;
 if(v===G.me){G.fx.dmgInd.push({dx:dx/l,dz:dz/l,t:1.3});Sfx.hurt();UI.dmgFlash()}else Net.hostSend(v.id,{t:'dmg',dx:r2(dx/l),dz:r2(dz/l)});
 if(v.hp<=0){killPlayer(v,a,head,wid);return true}return false}
function killPlayer(v,a,head,wid){
 v.alive=false;v.hp=0;v.d++;v.respawnAt=G.time+4;
 if(a&&a!==v){a.k++;a.money+=KILL_REW+(head?HEAD_REW:0);G.H.sc[a.team]++;
  if(a===G.me){UI.toast('+$'+(KILL_REW+(head?HEAD_REW:0)),1);UI.shopRefresh()}else Net.hostSend(a.id,{t:'pst',m:a.money,lv:a.lv})}
 const km={t:'kill',k:a?a.id:-1,v:v.id,h:head?1:0,w:wid};Net.hostSend('*',km);onKillMsg(km);
 if(v===G.me)onLocalDeath();
 const H=G.H;for(let t=0;t<2;t++)if(H.sc[t]>=H.limit&&!H.over){H.over=true;endMatch(t)}}
function onKillMsg(m){const a=G.players[m.k],v=G.players[m.v];if(v===G.me&&a)G.killerName=a.name;UI.killfeed(a,v,m.h,WEAPONS[m.w]?WEAPONS[m.w].n:'')}
function endMatch(t){G.phase='end';const msg={t:'end',win:t,pl:playerList()};Net.hostSend('*',msg);onEnd(msg)}
function onEnd(m){G.phase='end';IN.fire=false;UI.showEnd(m)}
function hostTick(dt){
 for(const id in G.players){const p=G.players[id];if(!p.alive&&G.time>=p.respawnAt&&G.phase==='play')respawnPlayer(p)}
 snapT-=dt;if(snapT<=0){snapT=.05;const arr=[];for(const id in G.players){const p=G.players[id];arr.push([p.id,r2(p.x),r2(p.y),r2(p.z),r2(p.yaw),r2(p.pitch),Math.round(p.hp),p.alive?1:0,W_IDX(p.w),p.k,p.d,p.team])}
  Net.hostSend('*',{t:'snap',p:arr,sc:G.H.sc})}
}

/* ========== client ========== */
function joinServer(ip,port){
 resetCommon();G.role='client';G.mode='tdm';const me=G.me=newPlayer(-1,UI.name(),0);G.players={};UI.toast('در حال اتصال…',2);Net.connect(ip,port)}
async function joinRtc(code){resetCommon();G.role='client';G.mode='tdm';G.me=newPlayer(-1,UI.name(),0);G.players={};return Net.rtcJoin(code)}
function clientMsg(m){
 const me=G.me;if(!me)return;
 switch(m.t){
  case 'welcome':me.id=m.id;G.players[m.id]=me;G.H={sc:[0,0],limit:m.lim};G.phase='lobby';loadMap(m.map);UI.show('sLobby');break;
  case 'full':UI.msg('سرور پره (حداکثر ۶ نفر)');toMenu();break;
  case 'lobby':{
   const ids=m.pl.map(x=>x.id);
   for(const x of m.pl){let p=G.players[x.id];if(!p){p=newPlayer(x.id,x.n,x.t);G.players[x.id]=p;resetStats(p)}p.name=x.n;p.team=x.t}
   for(const id in G.players)if(!ids.includes(+id))delete G.players[id];G.players[me.id]=me;
   G.H.limit=m.lim;if(m.m!==G.mapIdx)loadMap(m.m);
   if(m.back&&(G.phase==='end'||G.phase==='play')){G.phase='lobby';UI.exitGame();UI.show('sLobby')}
   UI.lobby(m);break}
  case 'start':resetStats(me);for(const id in G.players)if(+id!==me.id)resetStats(G.players[id]);loadMap(m.m);G.H.limit=m.lim;G.H.sc=[0,0];G.phase='play';me.alive=false;G.fx={parts:[],tracers:[],lights:[],dmgInd:[]};UI.enterGame();break;
  case 'spawn':me.x=m.x;me.y=m.y;me.z=m.z;me.yaw=m.yaw;me.pitch=0;onLocalRespawn();break;
  case 'snap':for(const a of m.p){let p=G.players[a[0]];if(!p){p=newPlayer(a[0],'…',a[11]);G.players[a[0]]=p}
    if(p===me){const was=me.alive;me.hp=a[6];me.k=a[9];me.d=a[10];me.team=a[11];if(was&&!a[7]&&G.phase==='play')onLocalDeath()}
    else{p.x=a[1];p.y=a[2];p.z=a[3];p.yaw=a[4];p.pitch=a[5];p.hp=a[6];p.alive=!!a[7];p.w=WORDER[a[8]]||'pistol';p.k=a[9];p.d=a[10];p.team=a[11]}}
   G.H.sc=m.sc;break;
  case 'fx':playFx(m);break;
  case 'hm':UI.hitmark(!!m.k,!!m.h);Sfx.hit(!!m.h);if(m.k)Sfx.kill();break;
  case 'dmg':G.fx.dmgInd.push({dx:m.dx,dz:m.dz,t:1.3});Sfx.hurt();UI.dmgFlash();break;
  case 'pst':applyPst(m);break;
  case 'kill':onKillMsg(m);break;
  case 'end':onEnd(m);break;
 }
}
Net.on({
 server:(ip,info)=>UI.serverFound(ip,info),
 hmsg:(id,m)=>{if(G.role==='host')hostMsg(id,m)},
 peer:(id,j)=>{if(!j&&G.role==='host')removePlayer(id)},
 open:()=>{if(G.role==='client')Net.send({t:'hello',name:G.me.name,v:1})},
 msg:m=>{if(G.role==='client')clientMsg(m)},
 close:()=>{if(G.role==='client'){UI.msg('اتصال با میزبان قطع شد');toMenu()}},
 error:e=>{UI.msg('خطای شبکه: '+e)}
});
function teamReq(t){if(G.role==='host'){const p=G.me;if(p.team!==t&&teamCount(t)<3){p.team=t;broadcastLobby(false)}}else Net.send({t:'team',team:t})}

/* ========== main loop ========== */
function step(dt){
 const me=G.me;G.matchTime+=dt;
 updateMe(dt);for(const id in G.players){const p=G.players[id];if(p.seenT>0)p.seenT-=dt}
 if(G.role==='solo'){zombieTick(dt);tutTick()}
 if(G.role==='host')hostTick(dt);
 if(G.role==='client'){sendT-=dt;if(sendT<=0&&me.alive&&me.id>=0){sendT=.05;Net.send({t:'s',x:r2(me.x),y:r2(me.y),z:r2(me.z),yaw:r2(me.yaw),pitch:r2(me.pitch),w:W_IDX(me.w)})}}
 updFx(dt);
}
function frame(t){
 requestAnimationFrame(frame);
 const dt=Math.min(.05,(t-lastT)/1000||.016);lastT=t;G.time+=dt;if(!G.map)return;
 try{
  if(G.phase==='play'){if(!G.paused)step(dt);buildScene(dt);lastVP=renderFrame();overlay2d();hudT-=dt;if(hudT<=0){hudT=.066;UI.hud(hudData())}radarT-=dt;if(radarT<=0){radarT=.05;drawRadar()}}
  else{
   updFx(dt);buildScene(dt);G.menuA=(G.menuA||0)+dt*.12;const a=G.menuA,e=[Math.cos(a)*24,8,Math.sin(a)*24],fx=-e[0],fy=1.5-e[1],fz=-e[2],l=Math.hypot(fx,fy,fz);
   vml.clear();pvm.clear();R.render({eye:e,yaw:Math.atan2(-fx/l,-fz/l),pitch:Math.asin(fy/l),fov:1.1,theme:G.map.theme,dyn,vm:null,pa,pb,pvm,lights:pickLights(e),time:G.time});
   ov2c.clearRect(0,0,ov2d.width,ov2d.height)}
 }catch(e){console.error(e);window.__err=(window.__err||'')+String(e.stack||e)+'\n'}
}
function hudData(){
 const me=G.me,a=curAmmo(),s=curStats();
 return{hp:Math.round(me.hp),money:me.money,wname:WEAPONS[me.w].n,lv:me.lv[me.w]||0,mag:a.mag,res:a.res,rel:me.reloading>0,sc:G.H?G.H.sc:[0,0],lim:G.H?G.H.limit:0,mode:G.mode,wave:Z.wave,left:G.zombies.filter(z=>!z.dead).length+Z.toSpawn,
  spr:me.sprNow||s.spr,mov:me.mov,air:!me.grounded,scoped:me.scoped,isScope:!!s.scope,alive:me.alive,deathIn:Math.max(0,Math.ceil(4-G.deathT)),brk:Z.state==='break'?Math.ceil(Z.breakT):0,team:me.team,own:WORDER.filter(w=>me.lv[w]!==undefined),cur:me.w}}
function proj(x,y,z){const m=lastVP.VP,cx=m[0]*x+m[4]*y+m[8]*z+m[12],cy=m[1]*x+m[5]*y+m[9]*z+m[13],cw=m[3]*x+m[7]*y+m[11]*z+m[15];if(cw<=.1)return null;return[(cx/cw*.5+.5)*ov2d.width,(1-(cy/cw*.5+.5))*ov2d.height]}
function overlay2d(){
 const c=ov2c,W=ov2d.width,H=ov2d.height;c.clearRect(0,0,W,H);const me=G.me;
 if(G.mode==='tdm'&&me.alive){c.textAlign='center';c.font='bold 13px sans-serif';
  for(const id in G.players){const p=G.players[id];if(p===me||!p.alive||p.team!==me.team)continue;const s=proj(p.rx,p.ry+2.05,p.rz);if(!s)continue;
   const d=Math.hypot(p.rx-me.x,p.rz-me.z);if(d>70)continue;const col=TEAMC[p.team%2];c.fillStyle='rgba(0,0,0,.55)';const w=c.measureText(p.name).width+10;c.fillRect(s[0]-w/2,s[1]-16,w,18);
   c.fillStyle=`rgb(${col[0]*255|0},${col[1]*255|0},${col[2]*255|0})`;c.fillText(p.name,s[0],s[1]-3);c.fillStyle='rgba(0,0,0,.6)';c.fillRect(s[0]-20,s[1]+3,40,4);c.fillStyle='#4cd964';c.fillRect(s[0]-20,s[1]+3,40*clamp(p.hp/100,0,1),4)}}
 if(G.mode==='zombie'||G.mode==='tutorial'){for(const z of G.zombies){if(z.dead||!z.dummy&&G.mode!=='zombie')continue;if(z.hp>=z.max)continue;const s=proj(z.x,z.y+z.h+.3,z.z);if(!s)continue;c.fillStyle='rgba(0,0,0,.6)';c.fillRect(s[0]-18,s[1],36,4);c.fillStyle='#e74c3c';c.fillRect(s[0]-18,s[1],36*clamp(z.hp/z.max,0,1),4)}}
 const cx=W/2,cy=H/2;
 for(const d of G.fx.dmgInd){const f=Math.hypot(-Math.sin(me.yaw),-Math.cos(me.yaw)),fw=-Math.sin(me.yaw)*d.dx-Math.cos(me.yaw)*d.dz,rg=Math.cos(me.yaw)*d.dx-Math.sin(me.yaw)*d.dz;const ang=Math.atan2(rg,fw);
  c.save();c.translate(cx,cy);c.rotate(ang);c.strokeStyle=`rgba(255,40,40,${clamp(d.t,0,1)*.9})`;c.lineWidth=9;c.beginPath();c.arc(0,0,Math.min(W,H)*.32,-.28-PI/2,.28-PI/2);c.stroke();c.restore()}
}
function drawRadar(){
 const me=G.me,m=G.map,c=radarX,S=radarC.width,k=4,sc=2.1;c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,S,S);c.save();c.beginPath();c.arc(S/2,S/2,S/2-1,0,7);c.clip();
 c.fillStyle='rgba(8,12,18,.72)';c.fillRect(0,0,S,S);
 c.translate(S/2,S/2);c.rotate(me.yaw);c.scale(sc,sc);
 c.drawImage(radarOff,-(me.x+m.half+2),-(me.z+m.half+2),radarOff.width/k,radarOff.height/k);
 const dot=(x,z,col,r)=>{c.fillStyle=col;c.beginPath();c.arc(x-me.x,z-me.z,r,0,7);c.fill()};
 if(G.mode==='tdm'){for(const id in G.players){const p=G.players[id];if(p===me||!p.alive)continue;
  if(p.team===me.team)dot(p.x,p.z,'#4cd964',1.5);else if(p.seenT>0)dot(p.x,p.z,'#ff4d4d',1.7)}}
 else for(const z of G.zombies){if(!z.dead)dot(z.x,z.z,z.dummy?'#ffb020':'#ff4d4d',1.4)}
 c.restore();c.save();c.translate(S/2,S/2);c.fillStyle='#fff';c.beginPath();c.moveTo(0,-6);c.lineTo(4,5);c.lineTo(-4,5);c.closePath();c.fill();c.restore();
}
