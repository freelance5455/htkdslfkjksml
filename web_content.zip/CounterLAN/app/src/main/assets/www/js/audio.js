'use strict';
const Sfx=(()=>{
 let ac=null,master=null,nbuf=null,vol=.8;
 function init(){
  if(ac){if(ac.state==='suspended')ac.resume();return}
  try{ac=new(window.AudioContext||window.webkitAudioContext)();master=ac.createGain();master.gain.value=vol;master.connect(ac.destination);
   const n=ac.sampleRate;nbuf=ac.createBuffer(1,n,n);const d=nbuf.getChannelData(0);for(let i=0;i<n;i++)d[i]=Math.random()*2-1}catch(e){ac=null}
 }
 function out(pan){let n=master;if(pan&&ac.createStereoPanner){const p=ac.createStereoPanner();p.pan.value=clamp(pan,-1,1);p.connect(master);n=p}return n}
 function burst(o){ if(!ac)return;const t=ac.currentTime+(o.delay||0);
  const s=ac.createBufferSource();s.buffer=nbuf;s.loop=true;s.playbackRate.value=1;
  const f=ac.createBiquadFilter();f.type=o.type||'bandpass';f.Q.value=o.q||1;f.frequency.setValueAtTime(o.f0,t);f.frequency.exponentialRampToValueAtTime(Math.max(20,o.f1||o.f0),t+o.dur);
  const g=ac.createGain();g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(o.g,t+.004);g.gain.exponentialRampToValueAtTime(.0008,t+o.dur);
  s.connect(f);f.connect(g);g.connect(out(o.pan));s.start(t,Math.random());s.stop(t+o.dur+.05)}
 function tone(o){ if(!ac)return;const t=ac.currentTime+(o.delay||0);
  const s=ac.createOscillator();s.type=o.type||'sine';s.frequency.setValueAtTime(o.f0,t);s.frequency.exponentialRampToValueAtTime(Math.max(20,o.f1||o.f0),t+o.dur);
  const g=ac.createGain();g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(o.g,t+.005);g.gain.exponentialRampToValueAtTime(.0008,t+o.dur);
  s.connect(g);g.connect(out(o.pan));s.start(t);s.stop(t+o.dur+.05)}
 const SH={
  pistol:(g,p)=>{burst({f0:2200,f1:500,q:.8,dur:.12,g:.7*g,pan:p});tone({f0:170,f1:55,dur:.1,g:.8*g,pan:p})},
  smg:(g,p)=>{burst({f0:2600,f1:700,q:.7,dur:.08,g:.6*g,pan:p});tone({f0:200,f1:70,dur:.07,g:.6*g,pan:p})},
  shotgun:(g,p)=>{burst({type:'lowpass',f0:3500,f1:300,q:.5,dur:.35,g:1*g,pan:p});tone({f0:100,f1:30,dur:.28,g:1*g,pan:p})},
  rifle:(g,p)=>{burst({f0:1500,f1:300,q:.7,dur:.15,g:.8*g,pan:p});tone({f0:130,f1:40,dur:.12,g:.85*g,pan:p})},
  sniper:(g,p)=>{burst({type:'lowpass',f0:3000,f1:200,q:.5,dur:.6,g:1*g,pan:p});tone({f0:80,f1:25,dur:.4,g:1.1*g,pan:p});burst({type:'lowpass',f0:800,f1:150,dur:.8,g:.3*g,delay:.12,pan:p})},
  lmg:(g,p)=>{burst({f0:1300,f1:260,q:.7,dur:.13,g:.9*g,pan:p});tone({f0:110,f1:38,dur:.12,g:1*g,pan:p})}
 };
 return{
  init,setVol(v){vol=v;if(master)master.gain.value=v},
  shot(w,dist,pan){if(!ac)return;const g=clamp(1/(1+(dist||0)*.07),.05,1);(SH[w]||SH.pistol)(g,pan||0)},
  reload(){if(!ac)return;tone({type:'square',f0:900,f1:600,dur:.04,g:.2});burst({type:'highpass',f0:2500,dur:.06,g:.3,delay:.45});tone({type:'square',f0:700,f1:500,dur:.05,g:.25,delay:.8})},
  hit(head){if(!ac)return;tone({f0:head?2200:1300,f1:head?1800:900,dur:.06,g:.35});if(head)tone({f0:3000,f1:2600,dur:.05,g:.25,delay:.03})},
  kill(){if(!ac)return;tone({f0:600,f1:900,dur:.08,g:.3});tone({f0:900,f1:1400,dur:.12,g:.3,delay:.08})},
  hurt(){if(!ac)return;burst({type:'lowpass',f0:900,f1:200,dur:.18,g:.7});tone({f0:120,f1:60,dur:.15,g:.5})},
  step(){if(!ac)return;burst({type:'lowpass',f0:500,f1:150,dur:.07,g:.12})},
  zombie(dist,pan){if(!ac)return;const g=clamp(1/(1+(dist||0)*.15),.03,1)*.5;tone({type:'sawtooth',f0:rnd(70,110),f1:rnd(45,60),dur:.7,g:.25*g,pan});burst({type:'lowpass',f0:400,f1:150,dur:.7,g:.3*g,pan})},
  buy(){if(!ac)return;tone({f0:880,f1:880,dur:.12,g:.25});tone({f0:1320,f1:1320,dur:.18,g:.25,delay:.08})},
  click(){if(!ac)return;tone({f0:1000,f1:800,dur:.03,g:.15})},
  empty(){if(!ac)return;tone({type:'square',f0:300,f1:250,dur:.03,g:.15})},
  die(){if(!ac)return;tone({f0:200,f1:40,dur:.7,g:.5});burst({type:'lowpass',f0:600,f1:80,dur:.7,g:.5})},
  horn(){if(!ac)return;tone({type:'sawtooth',f0:140,f1:130,dur:1.1,g:.3});tone({type:'sawtooth',f0:210,f1:195,dur:1.1,g:.2})},
  impact(dist){if(!ac||dist>25)return;burst({f0:3000,f1:1500,q:2,dur:.05,g:.12/(1+dist*.2)})}
 };
})();
