'use strict';
/* ===== procedural textures (RGBA, alpha = emissive mask) ===== */
const TX={CONC:0,BRICK:1,METAL:2,CRATE:3,SAND:4,GRASS:5,ASPH:6,SNOW:7,TILE:8,CONT:9,WHITE:10,WIND:11,WINN:12,PLAS:13,HAZ:14,WOOD:15,ROCK:16,CLOTH:17,ICE:18,LEAF:19};
const TEX_N=20;
function h2(x,y,s){let h=Math.imul(x,374761393)+Math.imul(y,668265263)+Math.imul(s,1274126177);h=Math.imul(h^(h>>>13),1274126177);return((h^(h>>>16))>>>0)/4294967295}
function vn(x,y,per,s){const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi;
 const x0=((xi%per)+per)%per,x1=(x0+1)%per,y0=((yi%per)+per)%per,y1=(y0+1)%per;
 const u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf);
 return lerp(lerp(h2(x0,y0,s),h2(x1,y0,s),u),lerp(h2(x0,y1,s),h2(x1,y1,s),u),v)}
class Tex{
 constructor(S){this.S=S;this.d=new Uint8ClampedArray(S*S*4)}
 fill(r,g,b,a){const d=this.d;for(let i=0;i<d.length;i+=4){d[i]=r;d[i+1]=g;d[i+2]=b;d[i+3]=a||0}return this}
 rect(x,y,w,h,r,g,b,a){const S=this.S,d=this.d;for(let j=y;j<y+h;j++)for(let i=x;i<x+w;i++){const k=(((j%S)+S)%S*S+((i%S)+S)%S)*4;d[k]=r;d[k+1]=g;d[k+2]=b;if(a!==undefined)d[k+3]=a}return this}
 noise(cells,amp,seed){const S=this.S,d=this.d;for(let y=0;y<S;y++)for(let x=0;x<S;x++){const n=(vn(x/S*cells,y/S*cells,cells,seed)-.5)*amp,k=(y*S+x)*4;d[k]+=n;d[k+1]+=n;d[k+2]+=n}return this}
 speckle(amp,seed){const S=this.S,d=this.d;for(let y=0;y<S;y++)for(let x=0;x<S;x++){const n=(h2(x,y,seed)-.5)*amp,k=(y*S+x)*4;d[k]+=n;d[k+1]+=n;d[k+2]+=n}return this}
 shade(x,y,w,h,f){const S=this.S,d=this.d;for(let j=y;j<y+h;j++)for(let i=x;i<x+w;i++){const k=(((j%S)+S)%S*S+((i%S)+S)%S)*4;d[k]*=f;d[k+1]*=f;d[k+2]*=f}return this}
}
function makeTexture(id,S){
 const t=new Tex(S),k=S/256;const q=v=>Math.round(v*k);
 switch(id){
 case TX.CONC:t.fill(150,150,148).noise(8,30,1).noise(32,16,2).speckle(14,3);t.shade(0,0,S,q(2),.75);t.shade(0,0,q(2),S,.75);t.shade(0,q(128),S,q(2),.8);t.shade(q(128),0,q(2),S,.8);break;
 case TX.BRICK:t.fill(175,165,150);for(let r=0;r<16;r++){const off=(r%2)*q(16);for(let c=0;c<8;c++){const j=h2(r,c,7);t.rect(c*q(32)+off+1,r*q(16)+1,q(32)-2,q(16)-2,150+j*40,70+j*20,52+j*14)}}t.noise(16,26,4).speckle(18,5);break;
 case TX.METAL:t.fill(125,130,138).noise(4,20,6).speckle(10,7);{const d=t.d,S2=t.S;for(let y=0;y<S2;y++)for(let x=0;x<S2;x++){const n=(vn(x/S2*64,y/S2*2,2,9)-.5)*24,kk=(y*S2+x)*4;d[kk]+=n;d[kk+1]+=n;d[kk+2]+=n;const rs=vn(x/S2*6,y/S2*6,6,11);if(rs>.62){const a=(rs-.62)*3;d[kk]=lerp(d[kk],150,a);d[kk+1]=lerp(d[kk+1],80,a);d[kk+2]=lerp(d[kk+2],40,a)}}}
  t.shade(0,q(126),S,q(4),.6);t.shade(q(126),0,q(4),S,.6);for(const[a,b]of[[12,12],[240,12],[12,240],[240,240],[132,12],[132,240],[12,132],[240,132]])t.rect(q(a)-1,q(b)-1,3,3,70,72,78);break;
 case TX.CRATE:t.fill(150,106,62);for(let p=0;p<8;p++){t.shade(p*q(32),0,1,S,.6);t.rect(p*q(32),0,q(32),S,150+h2(p,1,3)*20,106+h2(p,1,3)*14,62+h2(p,1,3)*8)}t.noise(64,26,12).speckle(14,13);
  t.rect(0,0,S,q(18),112,76,42);t.rect(0,S-q(18),S,q(18),112,76,42);t.rect(0,0,q(18),S,112,76,42);t.rect(S-q(18),0,q(18),S,112,76,42);
  for(let i=0;i<S;i++){const j=Math.round(i*(S-q(36))/S)+q(18);t.rect(j,i,q(12),1,112,76,42)}break;
 case TX.SAND:t.fill(205,176,128).noise(4,22,14).noise(16,14,15).noise(64,10,16).speckle(16,17);break;
 case TX.GRASS:t.fill(72,112,46).noise(6,26,18).noise(32,22,19).speckle(40,20);break;
 case TX.ASPH:t.fill(58,60,66).noise(16,18,21).speckle(30,22).noise(4,12,23);break;
 case TX.SNOW:t.fill(236,241,250).noise(4,10,24).noise(32,8,25).speckle(8,26);break;
 case TX.TILE:t.fill(205,205,210);for(let y=0;y<4;y++)for(let x=0;x<4;x++){const dk=(x+y)%2?-70:0;t.rect(x*q(64)+2,y*q(64)+2,q(64)-4,q(64)-4,205+dk,205+dk,212+dk)}t.noise(16,14,27).speckle(10,28);break;
 case TX.CONT:t.fill(210,210,210);{const d=t.d;for(let y=0;y<S;y++)for(let x=0;x<S;x++){const p=(x%q(16))/q(16),f=.72+.28*Math.sin(p*PI),kk=(y*S+x)*4;d[kk]*=f;d[kk+1]*=f;d[kk+2]*=f}}t.noise(8,26,29).speckle(14,30);t.shade(0,S-q(40),S,q(40),.78);t.shade(0,0,S,q(8),.7);break;
 case TX.WHITE:t.fill(255,255,255,255);break;
 case TX.WIND:case TX.WINN:{t.fill(176,170,164).noise(16,24,31).speckle(14,32);
  for(let r=0;r<4;r++)for(let c=0;c<4;c++){const x=c*q(64)+q(10),y=r*q(64)+q(12),w=q(44),hh=q(40);
   const lit=id===TX.WINN&&h2(r,c,41)>.55;
   if(lit)t.rect(x,y,w,hh,255,215+h2(r,c,5)*30,140,255);else{t.rect(x,y,w,hh,34,52+h2(r,c,6)*20,74+h2(r,c,6)*24,0);t.rect(x,y,w,q(5),90,120,150,0)}
   t.shade(x-2,y+hh,w+4,3,.6)}}break;
 case TX.PLAS:t.fill(218,208,188).noise(8,22,33).noise(32,14,34).speckle(12,35);break;
 case TX.HAZ:{t.fill(30,30,30);const d=t.d;for(let y=0;y<S;y++)for(let x=0;x<S;x++){if(((x+y)%q(64))<q(32)){const kk=(y*S+x)*4;d[kk]=240;d[kk+1]=190;d[kk+2]=20}}t.noise(16,20,36).speckle(14,37)}break;
 case TX.WOOD:t.fill(125,88,52);for(let p=0;p<8;p++){t.rect(0,p*q(32),S,q(32)-2,125+h2(p,2,3)*25,88+h2(p,2,3)*16,52+h2(p,2,3)*10)}{const d=t.d;for(let y=0;y<S;y++)for(let x=0;x<S;x++){const n=(vn(x/S*2,y/S*32,2,38)-.5)*30,kk=(y*S+x)*4;d[kk]+=n;d[kk+1]+=n;d[kk+2]+=n}}t.speckle(12,39);break;
 case TX.ROCK:t.fill(112,110,106).noise(4,50,40).noise(16,30,41).noise(64,14,42).speckle(14,43);break;
 case TX.CLOTH:t.fill(205,205,205).noise(32,18,44).speckle(26,45);break;
 case TX.ICE:t.fill(160,205,232).noise(4,24,46).noise(16,16,47).speckle(8,48);break;
 case TX.LEAF:t.fill(34,74,42).noise(16,30,49).noise(64,26,50).speckle(34,51);break;
 }
 const d=t.d;for(let i=0;i<d.length;i++){if(d[i]<0)d[i]=0}
 return t.d;
}

/* ===== shaders ===== */
const VS_MAIN=`#version 300 es
precision highp float;
layout(location=0) in vec3 aPos;layout(location=1) in vec3 aNor;
layout(location=2) in vec4 m0;layout(location=3) in vec4 m1;layout(location=4) in vec4 m2;layout(location=5) in vec4 m3;
layout(location=6) in vec4 aCol;layout(location=7) in vec2 aTex;
uniform mat4 uVP;uniform mat4 uLVP;
out vec3 vW;out vec3 vN;out vec3 vO;out vec3 vON;out vec4 vCol;out vec2 vTex;out vec4 vL;
void main(){
 mat4 M=mat4(m0,m1,m2,m3);vec4 w=M*vec4(aPos,1.);
 vec3 sc=vec3(length(m0.xyz),length(m1.xyz),length(m2.xyz));
 mat3 R=mat3(m0.xyz/sc.x,m1.xyz/sc.y,m2.xyz/sc.z);
 vW=w.xyz;vN=R*aNor;vO=aPos*sc;vON=aNor;vCol=aCol;vTex=aTex;vL=uLVP*w;
 gl_Position=uVP*w;}`;
const FS_MAIN=`#version 300 es
precision highp float;precision highp sampler2DArray;precision highp sampler2DShadow;
in vec3 vW;in vec3 vN;in vec3 vO;in vec3 vON;in vec4 vCol;in vec2 vTex;in vec4 vL;
out vec4 o;
uniform sampler2DArray uTex;uniform sampler2DShadow uSh;
uniform vec3 uCam,uSunDir,uSunCol,uAmbT,uAmbB,uFog;uniform float uFogD,uShOn,uExp,uShTexel;
uniform vec4 uPL[6];uniform vec3 uPLC[6];uniform int uNPL;
void main(){
 vec3 an=abs(vON);
 vec2 uv=an.x>.5?vO.zy:(an.y>.5?vO.xz:vO.xy);
 vec4 t=texture(uTex,vec3(uv/vTex.y,vTex.x));
 vec3 alb=pow(t.rgb*vCol.rgb,vec3(2.2));
 vec3 N=normalize(vN);vec3 toC=uCam-vW;float dist=length(toC);vec3 V=toC/dist;
 float ndl=max(dot(N,uSunDir),0.);
 float sh=1.;
 if(uShOn>.5){vec3 pc=vL.xyz/vL.w*.5+.5;
  if(pc.z<1.&&pc.x>0.&&pc.x<1.&&pc.y>0.&&pc.y<1.){float bias=.0012+.003*(1.-ndl);sh=0.;
   for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)sh+=texture(uSh,vec3(pc.xy+vec2(float(x),float(y))*uShTexel,pc.z-bias));
   sh/=9.;}}
 vec3 amb=mix(uAmbB,uAmbT,N.y*.5+.5);
 float vert=1.-abs(N.y);float ao=1.-vert*.4*(1.-smoothstep(0.,2.5,vW.y));
 vec3 col=alb*(amb*ao+uSunCol*ndl*sh);
 vec3 H=normalize(uSunDir+V);col+=uSunCol*pow(max(dot(N,H),0.),40.)*ndl*sh*.12*(t.r+.2);
 for(int i=0;i<6;i++){if(i>=uNPL)break;vec3 d=uPL[i].xyz-vW;float l=length(d);float a=clamp(1.-l/uPL[i].w,0.,1.);a*=a;col+=alb*uPLC[i]*max(dot(N,d/l),0.)*a;}
 col+=alb*t.a*vCol.a*3.;
 float f=1.-exp(-pow(dist*uFogD,2.));col=mix(col,uFog,clamp(f,0.,1.));
 col*=uExp;col=(col*(2.51*col+.03))/(col*(2.43*col+.59)+.14);col=pow(col,vec3(1./2.2));
 o=vec4(col,1.);}`;
const VS_DEPTH=`#version 300 es
precision highp float;
layout(location=0) in vec3 aPos;
layout(location=2) in vec4 m0;layout(location=3) in vec4 m1;layout(location=4) in vec4 m2;layout(location=5) in vec4 m3;
uniform mat4 uLVP;
void main(){gl_Position=uLVP*(mat4(m0,m1,m2,m3)*vec4(aPos,1.));}`;
const FS_DEPTH=`#version 300 es
precision lowp float;out vec4 o;void main(){o=vec4(1.);}`;
const VS_SKY=`#version 300 es
out vec2 vUV;
void main(){vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));vUV=p*2.-1.;gl_Position=vec4(vUV,.9999,1.);}`;
const FS_SKY=`#version 300 es
precision highp float;in vec2 vUV;out vec4 o;
uniform vec3 uFwd,uRight,uUp,uSun,uSunCol,uZen,uHor,uGnd,uCloud;uniform float uTime,uCloudAmt,uStars,uExp;
float hs(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float nz(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hs(i),hs(i+vec2(1,0)),f.x),mix(hs(i+vec2(0,1)),hs(i+vec2(1,1)),f.x),f.y);}
float fbm(vec2 p){float a=.5,s=0.;for(int i=0;i<4;i++){s+=a*nz(p);p*=2.03;a*=.5;}return s;}
void main(){
 vec3 r=normalize(uFwd+uRight*vUV.x+uUp*vUV.y);float h=r.y;
 vec3 col=mix(uHor,uZen,pow(clamp(h,0.,1.),.55));
 if(h<0.)col=mix(uHor,uGnd,clamp(-h*5.,0.,1.));
 float sd=max(dot(r,uSun),0.);
 col+=uSunCol*(pow(sd,900.)*8.+pow(sd,16.)*.3+pow(sd,3.)*.08);
 if(h>.01){vec2 p=r.xz/(r.y+.2)*1.6+vec2(uTime*.012,0.);float n=fbm(p);col=mix(col,uCloud*(.7+.5*pow(sd,2.)),smoothstep(.48,.82,n)*uCloudAmt*smoothstep(.01,.2,h));}
 if(uStars>0.&&h>0.){vec3 s=floor(r*220.);float q=hs(s.xy+s.z*7.3);col+=vec3(step(.9972,q)*(.5+.5*hs(s.yz)))*uStars*smoothstep(0.,.3,h);}
 col*=uExp;col=(col*(2.51*col+.03))/(col*(2.43*col+.59)+.14);col=pow(col,vec3(1./2.2));
 o=vec4(col,1.);}`;
const VS_PART=`#version 300 es
precision highp float;
layout(location=0) in vec2 aQ;layout(location=1) in vec4 pp;layout(location=2) in vec4 pc;
uniform mat4 uVP;uniform vec3 uR,uU;out vec2 q;out vec4 c;
void main(){vec3 p=pp.xyz+(uR*aQ.x+uU*aQ.y)*pp.w;gl_Position=uVP*vec4(p,1.);q=aQ;c=pc;}`;
const FS_PART=`#version 300 es
precision mediump float;in vec2 q;in vec4 c;out vec4 o;
void main(){float d=dot(q,q);float a=clamp(1.-d,0.,1.);a*=a;o=vec4(c.rgb,c.a*a);}`;

class Renderer{
 constructor(canvas,opts){
  const gl=this.gl=canvas.getContext('webgl2',{antialias:true,alpha:false,powerPreference:'high-performance'});
  if(!gl)throw new Error('WebGL2 not supported');
  this.canvas=canvas;this.q=Object.assign({shadows:true,shadowSize:2048,scale:1,texSize:256},opts||{});
  this.progs={};this.uni={};this.sceneVAO=gl.createVertexArray();this.theme=null;
  this.init();
 }
 prog(name,vs,fs){const gl=this.gl;const mk=(t,s)=>{const x=gl.createShader(t);gl.shaderSource(x,s);gl.compileShader(x);if(!gl.getShaderParameter(x,gl.COMPILE_STATUS))throw new Error(name+': '+gl.getShaderInfoLog(x));return x};
  const p=gl.createProgram();gl.attachShader(p,mk(gl.VERTEX_SHADER,vs));gl.attachShader(p,mk(gl.FRAGMENT_SHADER,fs));gl.linkProgram(p);
  if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw new Error(name+' link: '+gl.getProgramInfoLog(p));this.progs[name]=p;this.uni[name]={};return p}
 U(name,u){const c=this.uni[name];if(!(u in c))c[u]=this.gl.getUniformLocation(this.progs[name],u);return c[u]}
 init(){
  const gl=this.gl;
  this.prog('main',VS_MAIN,FS_MAIN);this.prog('depth',VS_DEPTH,FS_DEPTH);this.prog('sky',VS_SKY,FS_SKY);this.prog('part',VS_PART,FS_PART);
  // cube geometry
  const F=[[[0,0,1],[[-.5,-.5,.5],[.5,-.5,.5],[.5,.5,.5],[-.5,.5,.5]]],[[0,0,-1],[[.5,-.5,-.5],[-.5,-.5,-.5],[-.5,.5,-.5],[.5,.5,-.5]]],
   [[1,0,0],[[.5,-.5,.5],[.5,-.5,-.5],[.5,.5,-.5],[.5,.5,.5]]],[[-1,0,0],[[-.5,-.5,-.5],[-.5,-.5,.5],[-.5,.5,.5],[-.5,.5,-.5]]],
   [[0,1,0],[[-.5,.5,.5],[.5,.5,.5],[.5,.5,-.5],[-.5,.5,-.5]]],[[0,-1,0],[[-.5,-.5,-.5],[.5,-.5,-.5],[.5,-.5,.5],[-.5,-.5,.5]]]];
  const v=[];for(const[n,p]of F)for(const i of[0,1,2,0,2,3]){v.push(...p[i],...n)}
  this.cubeBuf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,this.cubeBuf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(v),gl.STATIC_DRAW);
  this.dynBuf=gl.createBuffer();this.statBuf=gl.createBuffer();this.vmBuf=gl.createBuffer();
  this.vaos={};for(const n of['stat','dyn','vm']){this.vaos[n]=this.makeVAO(this[n==='stat'?'statBuf':n==='dyn'?'dynBuf':'vmBuf'])}
  // particles
  this.quad=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,this.quad);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);
  this.pBuf=gl.createBuffer();this.pVAO=gl.createVertexArray();gl.bindVertexArray(this.pVAO);
  gl.bindBuffer(gl.ARRAY_BUFFER,this.quad);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,2,gl.FLOAT,false,0,0);
  gl.bindBuffer(gl.ARRAY_BUFFER,this.pBuf);gl.enableVertexAttribArray(1);gl.vertexAttribPointer(1,4,gl.FLOAT,false,32,0);gl.vertexAttribDivisor(1,1);
  gl.enableVertexAttribArray(2);gl.vertexAttribPointer(2,4,gl.FLOAT,false,32,16);gl.vertexAttribDivisor(2,1);
  gl.bindVertexArray(null);
  this.initTex();this.initShadow();
 }
 makeVAO(buf){const gl=this.gl,vao=gl.createVertexArray();gl.bindVertexArray(vao);
  gl.bindBuffer(gl.ARRAY_BUFFER,this.cubeBuf);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,3,gl.FLOAT,false,24,0);gl.enableVertexAttribArray(1);gl.vertexAttribPointer(1,3,gl.FLOAT,false,24,12);
  gl.bindBuffer(gl.ARRAY_BUFFER,buf);const S=88;
  for(let i=0;i<4;i++){gl.enableVertexAttribArray(2+i);gl.vertexAttribPointer(2+i,4,gl.FLOAT,false,S,i*16);gl.vertexAttribDivisor(2+i,1)}
  gl.enableVertexAttribArray(6);gl.vertexAttribPointer(6,4,gl.FLOAT,false,S,64);gl.vertexAttribDivisor(6,1);
  gl.enableVertexAttribArray(7);gl.vertexAttribPointer(7,2,gl.FLOAT,false,S,80);gl.vertexAttribDivisor(7,1);
  gl.bindVertexArray(null);return vao}
 initTex(){const gl=this.gl,S=this.q.texSize;
  if(this.tex)gl.deleteTexture(this.tex);
  const t=this.tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D_ARRAY,t);
  const lv=Math.floor(Math.log2(S))+1;gl.texStorage3D(gl.TEXTURE_2D_ARRAY,lv,gl.RGBA8,S,S,TEX_N);
  for(let i=0;i<TEX_N;i++)gl.texSubImage3D(gl.TEXTURE_2D_ARRAY,0,0,0,i,S,S,1,gl.RGBA,gl.UNSIGNED_BYTE,makeTexture(i,S));
  gl.generateMipmap(gl.TEXTURE_2D_ARRAY);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_WRAP_S,gl.REPEAT);gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_WRAP_T,gl.REPEAT);
  const an=gl.getExtension('EXT_texture_filter_anisotropic');if(an)gl.texParameterf(gl.TEXTURE_2D_ARRAY,an.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(8,gl.getParameter(an.MAX_TEXTURE_MAX_ANISOTROPY_EXT)))}
 initShadow(){const gl=this.gl,S=this.q.shadowSize;
  if(this.shTex){gl.deleteTexture(this.shTex);gl.deleteFramebuffer(this.shFB)}
  this.shTex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,this.shTex);
  gl.texImage2D(gl.TEXTURE_2D,0,gl.DEPTH_COMPONENT24,S,S,0,gl.DEPTH_COMPONENT,gl.UNSIGNED_INT,null);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_COMPARE_MODE,gl.COMPARE_REF_TO_TEXTURE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_COMPARE_FUNC,gl.LEQUAL);
  this.shFB=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,this.shFB);
  gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,this.shTex,0);gl.drawBuffers([gl.NONE]);gl.readBuffer(gl.NONE);
  gl.bindFramebuffer(gl.FRAMEBUFFER,null)}
 setQuality(q){Object.assign(this.q,q);this.initShadow()}
 resize(){const c=this.canvas,dpr=Math.min(window.devicePixelRatio||1,2)*this.q.scale;
  const w=Math.max(2,Math.floor(c.clientWidth*dpr)),h=Math.max(2,Math.floor(c.clientHeight*dpr));if(c.width!==w||c.height!==h){c.width=w;c.height=h}}
 upload(list,buf,usage){const gl=this.gl;gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,list.data.subarray(0,Math.max(1,list.n)*22),usage)}
 setStatic(list){this.stat=list;this.upload(list,this.statBuf,this.gl.STATIC_DRAW)}
 draw(vao,n){if(n<=0)return;const gl=this.gl;gl.bindVertexArray(vao);gl.drawArraysInstanced(gl.TRIANGLES,0,36,n)}
 render(f){
  const gl=this.gl,T=f.theme,c=this.canvas;this.resize();
  const W=c.width,H=c.height,asp=W/H,e=f.eye;
  const effF=v=>asp<1.25?2*Math.atan(Math.min(1.9,Math.tan(v/2)*1.45/asp)):v;const fovE=effF(f.fov),vmE=effF(f.vmFov||1.0);
  const cp=Math.cos(f.pitch),fw=[-Math.sin(f.yaw)*cp,Math.sin(f.pitch),-Math.cos(f.yaw)*cp];
  const view=M4.look(e,[e[0]+fw[0],e[1]+fw[1],e[2]+fw[2]],[0,1,0]);
  const proj=M4.persp(fovE,asp,.08,220),VP=M4.mul(proj,view);
  const rt=[Math.cos(f.yaw),0,-Math.sin(f.yaw)];
  const up=[rt[1]*fw[2]-rt[2]*fw[1],rt[2]*fw[0]-rt[0]*fw[2],rt[0]*fw[1]-rt[1]*fw[0]];
  const sd=T.sunDir;const sl=Math.hypot(...sd),S3=[sd[0]/sl,sd[1]/sl,sd[2]/sl];
  this.upload(f.dyn,this.dynBuf,gl.DYNAMIC_DRAW);
  let LVP=new Float32Array(16);const shOn=this.q.shadows;
  if(shOn){
   const half=36,size=this.q.shadowSize,tex=2*half/size;
   const F=[e[0]+fw[0]*14,0,e[2]+fw[2]*14];
   const lf=[-S3[0],-S3[1],-S3[2]];let lr=[-lf[2],0,lf[0]];const ll=Math.hypot(...lr);lr=[lr[0]/ll,0,lr[2]/ll];
   const lu=[lr[1]*lf[2]-lr[2]*lf[1],lr[2]*lf[0]-lr[0]*lf[2],lr[0]*lf[1]-lr[1]*lf[0]];
   const dr=F[0]*lr[0]+F[1]*lr[1]+F[2]*lr[2],du=F[0]*lu[0]+F[1]*lu[1]+F[2]*lu[2];
   const sr=dr-Math.floor(dr/tex)*tex,su=du-Math.floor(du/tex)*tex;
   const Fs=[F[0]-lr[0]*sr-lu[0]*su,F[1]-lr[1]*sr-lu[1]*su,F[2]-lr[2]*sr-lu[2]*su];
   const lp=[Fs[0]+S3[0]*70,Fs[1]+S3[1]*70,Fs[2]+S3[2]*70];
   LVP=M4.mul(M4.ortho(-half,half,-half,half,1,160),M4.look(lp,Fs,[0,1,0]));
   gl.bindFramebuffer(gl.FRAMEBUFFER,this.shFB);gl.viewport(0,0,size,size);gl.clear(gl.DEPTH_BUFFER_BIT);
   gl.enable(gl.DEPTH_TEST);gl.depthMask(true);gl.enable(gl.CULL_FACE);gl.cullFace(gl.FRONT);gl.enable(gl.POLYGON_OFFSET_FILL);gl.polygonOffset(2,4);
   gl.useProgram(this.progs.depth);gl.uniformMatrix4fv(this.U('depth','uLVP'),false,LVP);
   this.draw(this.vaos.stat,this.stat.n);this.draw(this.vaos.dyn,f.dyn.n);
   gl.disable(gl.POLYGON_OFFSET_FILL);gl.cullFace(gl.BACK);gl.bindFramebuffer(gl.FRAMEBUFFER,null);
  }
  gl.viewport(0,0,W,H);gl.clearColor(0,0,0,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
  // sky
  gl.disable(gl.DEPTH_TEST);gl.disable(gl.CULL_FACE);gl.useProgram(this.progs.sky);
  const th=Math.tan(fovE/2),P='sky',u=(n,...a)=>gl.uniform3f(this.U(P,n),...a);
  u('uFwd',...fw);u('uRight',rt[0]*th*asp,rt[1]*th*asp,rt[2]*th*asp);u('uUp',up[0]*th,up[1]*th,up[2]*th);u('uSun',...S3);
  u('uSunCol',...T.skySunCol);u('uZen',...T.zen);u('uHor',...T.hor);u('uGnd',...T.gnd);u('uCloud',...T.cloud);
  gl.uniform1f(this.U(P,'uTime'),f.time);gl.uniform1f(this.U(P,'uCloudAmt'),T.cloudAmt);gl.uniform1f(this.U(P,'uStars'),T.stars);gl.uniform1f(this.U(P,'uExp'),T.exp);
  gl.bindVertexArray(this.sceneVAO);gl.drawArrays(gl.TRIANGLES,0,3);
  // scene
  gl.enable(gl.DEPTH_TEST);gl.enable(gl.CULL_FACE);gl.cullFace(gl.BACK);
  gl.useProgram(this.progs.main);this.mainUniforms(f,T,S3,LVP,e,shOn);
  gl.uniformMatrix4fv(this.U('main','uVP'),false,VP);
  this.draw(this.vaos.stat,this.stat.n);this.draw(this.vaos.dyn,f.dyn.n);
  // particles
  gl.bindVertexArray(this.pVAO);gl.useProgram(this.progs.part);gl.depthMask(false);
  gl.uniformMatrix4fv(this.U('part','uVP'),false,VP);gl.uniform3f(this.U('part','uR'),...rt);gl.uniform3f(this.U('part','uU'),...up);
  gl.enable(gl.BLEND);gl.disable(gl.CULL_FACE);
  const dp=(pl,add)=>{if(!pl||pl.n<=0)return;gl.blendFunc(gl.SRC_ALPHA,add?gl.ONE:gl.ONE_MINUS_SRC_ALPHA);gl.bindBuffer(gl.ARRAY_BUFFER,this.pBuf);gl.bufferData(gl.ARRAY_BUFFER,pl.data.subarray(0,pl.n*8),gl.DYNAMIC_DRAW);gl.drawArraysInstanced(gl.TRIANGLE_STRIP,0,4,pl.n)};
  dp(f.pa,false);dp(f.pb,true);gl.disable(gl.BLEND);gl.depthMask(true);gl.enable(gl.CULL_FACE);
  // viewmodel
  if(f.vm&&f.vm.n>0){
   gl.clear(gl.DEPTH_BUFFER_BIT);this.upload(f.vm,this.vmBuf,gl.DYNAMIC_DRAW);
   gl.useProgram(this.progs.main);this.mainUniforms(f,T,S3,LVP,e,shOn);
   gl.uniformMatrix4fv(this.U('main','uVP'),false,M4.mul(M4.persp(vmE,asp,.02,10),view));
   this.draw(this.vaos.vm,f.vm.n);
   if(f.pvm&&f.pvm.n){gl.bindVertexArray(this.pVAO);gl.useProgram(this.progs.part);gl.uniformMatrix4fv(this.U('part','uVP'),false,M4.mul(M4.persp(vmE,asp,.02,10),view));
    gl.enable(gl.BLEND);gl.depthMask(false);dp(f.pvm,true);gl.disable(gl.BLEND);gl.depthMask(true)}
  }
  gl.bindVertexArray(null);
  return{VP,W,H};
 }
 mainUniforms(f,T,S3,LVP,e,shOn){
  const gl=this.gl,P='main';
  gl.uniformMatrix4fv(this.U(P,'uLVP'),false,LVP);
  gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D_ARRAY,this.tex);gl.uniform1i(this.U(P,'uTex'),0);
  gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,this.shTex);gl.uniform1i(this.U(P,'uSh'),1);
  gl.uniform3f(this.U(P,'uCam'),...e);gl.uniform3f(this.U(P,'uSunDir'),...S3);gl.uniform3f(this.U(P,'uSunCol'),...T.sunCol);
  gl.uniform3f(this.U(P,'uAmbT'),...T.ambT);gl.uniform3f(this.U(P,'uAmbB'),...T.ambB);gl.uniform3f(this.U(P,'uFog'),...T.fog);
  gl.uniform1f(this.U(P,'uFogD'),T.fogD);gl.uniform1f(this.U(P,'uShOn'),shOn?1:0);gl.uniform1f(this.U(P,'uExp'),T.exp);gl.uniform1f(this.U(P,'uShTexel'),1/this.q.shadowSize);
  const L=f.lights||[],pl=new Float32Array(24),pc=new Float32Array(18);const n=Math.min(6,L.length);
  for(let i=0;i<n;i++){const l=L[i];pl.set([l.x,l.y,l.z,l.r],i*4);pc.set(l.c,i*3)}
  gl.uniform4fv(this.U(P,'uPL[0]'),pl);gl.uniform3fv(this.U(P,'uPLC[0]'),pc);gl.uniform1i(this.U(P,'uNPL'),n);
 }
}
