'use strict';
const $=id=>document.getElementById(id);
const Lay={rot:0,w:0,h:0,pt:false,want:false,flip:false,touch:('ontouchstart' in window)||(window.matchMedia&&matchMedia('(pointer:coarse)').matches),
 apply(){const rw=innerWidth,rh=innerHeight;let rot=0;
  if(Lay.want&&Lay.touch&&!Net.native&&rw<rh){rot=(screen.orientation&&/secondary/.test(screen.orientation.type))?-90:90;if(Lay.flip)rot=-rot}
  Lay.rot=rot;const app=document.getElementById('app');
  if(rot){Lay.w=rh;Lay.h=rw;app.style.width=rh+'px';app.style.height=rw+'px';app.style.transform=rot===90?'translateX('+rw+'px) rotate(90deg)':'translateY('+rh+'px) rotate(-90deg)'}
  else{Lay.w=rw;Lay.h=rh;app.style.width='100%';app.style.height='100%';app.style.transform='none'}
  Lay.pt=Lay.h>Lay.w;G.pt=Lay.pt;app.classList.toggle('pt',Lay.pt);app.style.setProperty('--vw',Lay.w/100+'px');app.style.setProperty('--vh',Lay.h/100+'px');
  if(typeof resize2d==='function')resize2d()},
 p(e){const x=e.clientX,y=e.clientY;if(Lay.rot===90)return[y,innerWidth-x];if(Lay.rot===-90)return[innerHeight-y,x];return[x,y]}};
addEventListener('resize',()=>Lay.apply());addEventListener('orientationchange',()=>setTimeout(()=>Lay.apply(),200));
const UI=(()=>{
 const servers={};let selHost=0,selZomb=0,hostLim=25,joinTimer=null,shopOpen=false,scoreOpen=false,pauseOpen=false,tutBtn=null,last={},scrNow='sLoad';
 const SCRS=['sLoad','sMain','sHost','sJoin','sLobby','sZomb','sSet'];
 function show(id){scrNow=id;for(const s of SCRS)$(s).classList.toggle('on',s===id);if(id==='sJoin'){Net.discoverStart();startJoinTimer()}else{Net.discoverStop();clearInterval(joinTimer)}
  if(id==='sSet'){$('setSens').value=G.sens;$('setVol').value=G.vol;markChips('setQ',G.quality)}}
 function markChips(id,v){for(const c of $(id).children)c.classList.toggle('sel',+c.dataset.v===+v)}
 function mapCards(el,sel,cb){el.innerHTML='';MAPS.forEach((m,i)=>{if(m.hidden)return;const d=document.createElement('div');d.className='mc'+(i===sel?' sel':'');
  d.innerHTML=`<div class="im" style="background:${m.grad}"></div><div class="nm">${m.name}</div><div class="ds">${m.desc}</div>`;d.onclick=()=>{cb(i);for(const c of el.children)c.classList.remove('sel');d.classList.add('sel');Sfx.click()};el.appendChild(d)})}
 function portrait(on){if(on!==false)forceLandscape()}
 function forceLandscape(){Lay.want=Lay.touch;try{const el=document.documentElement,lock=()=>{try{screen.orientation.lock('landscape').catch(()=>{})}catch(e){}},p=(!document.fullscreenElement&&el.requestFullscreen)?el.requestFullscreen():null;if(p&&p.then)p.then(lock,lock);else lock()}catch(e){}Lay.apply();setTimeout(()=>Lay.apply(),300)}
 function flip(){Lay.flip=!Lay.flip;try{localStorage.setItem('fpsflip',Lay.flip?'1':'0')}catch(e){}Lay.apply()}
 function startMatch(){portrait(true);hostStartMatch()}
 function name(){const v=$('nm').value.trim();return v||('بازیکن'+(10+Math.floor(Math.random()*90)))}
 function msg(t){$('msgTxt').textContent=t;$('msgBox').classList.add('on')}
 function toast(t,s){const d=document.createElement('div');d.textContent=t;if(s)d.style.animationDuration=(s+.6)+'s';$('toast').appendChild(d);setTimeout(()=>d.remove(),(s||1.6)*1000+700)}
 function killfeed(a,v,head,wn){const d=document.createElement('div');const me=G.me;const cl=p=>p?`<span class="${p.team===0?'r':'b'}">${esc(p.name)}</span>`:'؟';
  d.innerHTML=`${cl(a)} <i>${wn}${head?' 💀':''}</i> ${cl(v)}`;$('feed').appendChild(d);setTimeout(()=>d.remove(),5200);while($('feed').children.length>5)$('feed').firstChild.remove()}
 function feed(t){const d=document.createElement('div');d.textContent=t;$('feed').appendChild(d);setTimeout(()=>d.remove(),4000)}
 const esc=s=>String(s).replace(/[<>&]/g,'');
 function hitmark(k,h){const e=$('hitm');e.className='';void e.offsetWidth;e.className='on'+(k?' k':'')}
 function dmgFlash(){const e=$('dmgov');e.className='';void e.offsetWidth;e.className='on';if(navigator.vibrate)navigator.vibrate(40)}
 function showDeath(on,killer){$('death').style.display=on?'flex':'none';if(on)$('deathSub').textContent=killer?'توسط '+killer:''}

 /* --- menus --- */
 function goHost(){Sfx.init();$('hname').value=$('hname').value||('سرور '+name());mapCards($('hmaps'),selHost,i=>selHost=i);show('sHost')}
 function createServer(){Sfx.init();portrait(true);const n=$('hname').value.trim()||'سرور';hostCreate(n,selHost,hostLim)}
 function goJoin(){Sfx.init();for(const k in servers)delete servers[k];renderServers();show('sJoin')}
 function leaveJoin(){show('sMain')}
 function startJoinTimer(){clearInterval(joinTimer);joinTimer=setInterval(()=>{const n=Date.now();for(const k in servers)if(n-servers[k].ts>9000)delete servers[k];renderServers()},1000)}
 function serverFound(ip,info){servers[ip]={info,ts:Date.now()};if(scrNow==='sJoin')renderServers()}
 function renderServers(){const el=$('srvList'),ks=Object.keys(servers);if(!ks.length){el.innerHTML='<p class="s">هنوز سروری پیدا نشد</p>';return}
  el.innerHTML='';for(const ip of ks){const s=servers[ip].info,m=MAPS[s.m]||{name:'؟'};const d=document.createElement('div');d.className='srv';
   d.innerHTML=`<div><b>${esc(s.n)}</b><small>${m.name} · ${s.c}/${s.x} نفر ${s.ph?'· در حال بازی':''}</small></div>`;
   const b=document.createElement('button');b.className='sm';b.textContent=s.c>=s.x?'پر':'ورود';b.disabled=s.c>=s.x;b.onclick=()=>{Sfx.init();portrait(true);Net.discoverStop();joinServer(ip,47777)};d.appendChild(b);el.appendChild(d)}}
 function joinManual(){const ip=$('mip').value.trim();if(!ip)return;Sfx.init();portrait(true);joinServer(ip,47777)}
 let rtcRid=0;
 const cp=id=>{const t=$(id);t.select();try{navigator.clipboard.writeText(t.value)}catch(e){try{document.execCommand('copy')}catch(x){}}toast('کپی شد',1)};
 async function rtcMakeOffer(){if(!Net.rtcOK){msg('این مرورگر WebRTC نداره');return}$('hCode').value='در حال ساخت…';try{const r=await Net.rtcOffer();rtcRid=r.rid;$('hCode').value=r.code;$('hAns').value='';$('hRtc2').style.display=''}catch(e){$('hCode').value='';msg('خطا: '+e.message)}}
 async function rtcFinish(){const c=$('hAns').value.trim();if(!c)return;try{await Net.rtcAccept(rtcRid,c);toast('در حال اتصال…',2);$('hRtc2').style.display='none';$('hCode').value=''}catch(e){msg('کد پاسخ درست نیست')}}
 async function rtcJoinGo(){const c=$('jCode').value.trim();if(!c)return;if(!Net.rtcOK){msg('این مرورگر WebRTC نداره');return}Sfx.init();$('jAns').value='در حال ساخت…';try{$('jAns').value=await joinRtc(c);$('jRtc2').style.display='';portrait(true)}catch(e){$('jAns').value='';msg('کد دعوت درست نیست')}}
 function goZomb(){mapCards($('zmaps'),selZomb,i=>selZomb=i);show('sZomb')}
 function startZomb(){Sfx.init();portrait(true);show(null);startSolo('zombie',selZomb)}
 function startTut(){Sfx.init();portrait(true);show(null);startSolo('tutorial',RANGE_IDX())}
 function saveSet(){G.sens=+$('setSens').value;G.vol=+$('setVol').value;const q=[...$('setQ').children].find(c=>c.classList.contains('sel'));if(q)G.quality=+q.dataset.v;Sfx.setVol(G.vol);applyQuality();saveSettings();show('sMain')}
 function lobby(m){
  if(scrNow!=='sLobby'&&G.phase!=='lobby')return;
  const host=G.role==='host';$('lbTitle').textContent='لابی — '+esc(m.hn||G.H.name||'');
  $('lbInfo').textContent='نقشه: '+MAPS[m.m].name+' · تا '+m.lim+' کیل'+(host?' · آی‌پی تو: '+Net.localIp():'');
  for(let t=0;t<2;t++){const el=$('lt'+t);el.innerHTML='';const list=m.pl.filter(p=>p.t===t);for(let i=0;i<3;i++){const p=list[i],d=document.createElement('div');d.className='slot'+(p?'':' em')+(p&&p.id===G.me.id?' me':'');d.textContent=p?p.n:'— خالی —';el.appendChild(d)}}
  $('lbStart').style.display=host?'':'none';$('lbWait').textContent=host?'منتظر بمون دوستات از «جستجوی سرور» وارد بشن، بعد شروع کن.':'منتظر شروع بازی توسط میزبان…';$('hRtc').style.display=host?'':'none'}
 function switchTeam(){Sfx.click();teamReq(G.me.team===0?1:0)}
 function leave(){closeOverlays();toMenu()}

 /* --- in game --- */
 function enterGame(){show(null);$('hud').classList.add('on');$('ctl').classList.add('on');closeOverlays();$('endScr').classList.remove('on');showDeath(false);
  $('tutBox').style.display=G.mode==='tutorial'?'block':'none';if(G.mode!=='tutorial')tut('',null);
  try{const f=document.documentElement.requestFullscreen&&document.documentElement.requestFullscreen();if(f&&f.catch)f.catch(()=>{})}catch(e){}last={}}
 function exitGame(){$('hud').classList.remove('on');$('ctl').classList.remove('on');closeOverlays();$('endScr').classList.remove('on');showDeath(false);tut('',null)}
 function closeOverlays(){shopOpen=scoreOpen=pauseOpen=false;for(const i of['shop','score','pause'])$(i).classList.remove('on');G.paused=false}
 function openShop(){if(G.phase!=='play')return;shopOpen=true;$('shop').classList.add('on');if(G.role==='solo')G.paused=true;shopRefresh();Sfx.click()}
 function closeShop(){shopOpen=false;$('shop').classList.remove('on');if(!pauseOpen)G.paused=false}
 function toggleScore(){scoreOpen?closeScore():openScore()}
 function openScore(){if(G.phase!=='play')return;scoreOpen=true;$('score').classList.add('on');renderScore()}
 function closeScore(){scoreOpen=false;$('score').classList.remove('on')}
 function renderScore(){const el=$('scoreBody');
  if(G.mode==='tdm'){let h='';for(let t=0;t<2;t++){h+=`<table><tr><th class="r${t}">تیم ${TEAMN[t]} — ${G.H.sc[t]}</th><th>کیل</th><th>مرگ</th></tr>`;for(const id in G.players){const p=G.players[id];if(p.team===t)h+=`<tr><td>${esc(p.name)}${p===G.me?' (من)':''}</td><td>${p.k}</td><td>${p.d}</td></tr>`}h+='</table><br>'}el.innerHTML=h}
  else el.innerHTML=`<p class="s">موج ${Z.wave} · کیل: ${Z.kills} · پول: $${G.me.money}</p>`}
 function pause(){if(G.phase!=='play')return;pauseOpen=true;$('pause').classList.add('on');if(G.role==='solo')G.paused=true}
 function resume(){pauseOpen=false;$('pause').classList.remove('on');if(!shopOpen)G.paused=false}
 function shopRefresh(){
  const me=G.me;$('shopMoney').textContent='$'+me.money;if(!shopOpen)return;const g=$('shopGrid');g.innerHTML='';
  for(const w of WORDER){const W=WEAPONS[w],own=me.lv[w]!==undefined,lv=me.lv[w]||0,s=stats(w,lv),d=document.createElement('div');d.className='wc'+(own?' own':'');
   d.innerHTML=`<h3><span>${W.n}</span><span>${own?'سطح '+lv:'$'+W.price}</span></h3><div class="st">آسیب: ${Math.round(s.dmg)}${W.pel>1?'×'+W.pel:''}<br>سرعت: ${s.rate.toFixed(1)}/ث · خشاب: ${s.mag}<br>${W.scope?'قابلیت اسکوپ':W.auto?'تمام‌اتوماتیک':'تک‌تیر'}</div>`;
   const add=(t,cls,en,fn)=>{const b=document.createElement('button');b.textContent=t;if(cls)b.className=cls;b.disabled=!en;b.onclick=()=>{fn();};d.appendChild(b)};
   if(!own)add('خرید $'+W.price,'',me.money>=W.price,()=>buyReq(w,'buy'));
   else{if(lv<3){const c=upCost(w,lv);add('ارتقا $'+c,'bl',me.money>=c,()=>buyReq(w,'upg'))}else add('حداکثر سطح','g',false,()=>{});add('پر کردن مهمات $'+AMMO_COST,'g',me.money>=AMMO_COST,()=>buyReq(w,'ammo'));if(me.w!==w)add('انتخاب','g',true,()=>{setWeapon(w);shopRefresh()})}
   g.appendChild(d)}}
 function showEnd(m){
  closeOverlays();$('hud').classList.remove('on');$('ctl').classList.remove('on');const t=$('endTitle'),b=$('endBody'),bt=$('endBtns');bt.innerHTML='';
  const btn=(txt,cls,fn)=>{const x=document.createElement('button');x.textContent=txt;if(cls)x.className=cls;x.onclick=fn;bt.appendChild(x)};
  if(m.solo){t.textContent=G.mode==='zombie'?'بازی تموم شد':'';b.innerHTML=`<p class="s" style="font-size:16px">رسیدی به موج <b>${m.wave}</b> و <b>${m.kills}</b> زامبی کشتی</p>`;btn('دوباره','',()=>{$('endScr').classList.remove('on');startSolo('zombie',G.mapIdx)});btn('منو','g',()=>{$('endScr').classList.remove('on');toMenu()})}
  else{const win=m.win,mine=G.me.team===win;t.innerHTML=`<span class="r${win}">تیم ${TEAMN[win]}</span> برنده شد! ${mine?'🏆':''}`;
   let h='';for(let k=0;k<2;k++){h+=`<table><tr><th class="r${k}">تیم ${TEAMN[k]}</th><th>کیل</th><th>مرگ</th></tr>`;for(const p of m.pl)if(p.t===k)h+=`<tr><td>${esc(p.n)}</td><td>${p.k}</td><td>${p.d}</td></tr>`;h+='</table><br>'}b.innerHTML=h;
   if(G.role==='host')btn('بازگشت به لابی','',hostBackToLobby);else b.innerHTML+='<p class="s">منتظر میزبان…</p>';btn('خروج','g',()=>{$('endScr').classList.remove('on');toMenu()})}
  $('endScr').classList.add('on')}
 function tut(text,btn){if(btn==='stickZone')btn='stickHint';if(tutBtn){const e=$(tutBtn);e&&e.classList.remove('pulse')}tutBtn=btn;$('tutBox').textContent=text;if(btn){const e=$(btn);e&&e.classList.add('pulse')}}
 function tutDone(){const b=$('tutBox');b.innerHTML='آموزش تموم شد! 🎉 <button class="sm" style="margin-top:6px;pointer-events:auto" onclick="UI.leave()">بازگشت به منو</button>';b.style.pointerEvents='auto'}
 function hud(d){
  const set=(id,k,v)=>{if(last[k]!==v){last[k]=v;$(id).textContent=v}};
  set('hpn','hp',d.hp);if(last.hpw!==d.hp){last.hpw=d.hp;const f=$('hpf');f.style.width=d.hp+'%';f.style.background=d.hp>50?'#2ecc71':d.hp>25?'#f1c40f':'#e74c3c'}
  set('money','m','$'+d.money);
  const am=d.rel?'<small>ری‌لود…</small>':`${d.mag}<small> / ${d.res}</small>`;if(last.am!==am){last.am=am;$('ammo').innerHTML=am}
  set('wn','wn',d.wname+(d.lv?' ★'.repeat(d.lv):''));
  const sk=d.own.join(',')+d.cur;if(last.sl!==sk){last.sl=sk;$('slots').innerHTML=d.own.map(w=>`<span class="${w===d.cur?'cur':''}">${WORDER.indexOf(w)+1}</span>`).join('')}
  let sc='';if(d.mode==='tdm')sc=`<span class="a">${d.sc[0]}</span><span class="m">/ ${d.lim} /</span><span class="b">${d.sc[1]}</span>`;
  else if(d.mode==='zombie')sc=d.brk?`<span class="m">موج بعدی تا ${d.brk}</span>`:`<span class="m">موج ${d.wave} · زامبی: ${d.left}</span>`;
  if(last.sc!==sc){last.sc=sc;$('sc').innerHTML=sc;$('sc').style.display=sc?'flex':'none'}
  const gap=d.scoped?999:3+d.spr*520+(d.mov?5:0)+(d.air?8:0);if(Math.abs((last.gap||0)-gap)>.5){last.gap=gap;const c=$('cross').children;c[0].style.top=-(gap+8)+'px';c[1].style.top=gap+'px';c[2].style.left=-(gap+8)+'px';c[3].style.left=gap+'px';$('cross').style.display=d.scoped?'none':'block'}
  $('scope').style.display=d.scoped?'block':'none';$('btnScope').style.display=d.isScope?'flex':'none';
  if(d.alive===false&&G.mode==='tdm')$('deathSub').textContent=($('deathSub').textContent.split('·')[0]||'').trim()+' · برگشت در '+d.deathIn;
  if(scoreOpen)renderScore();
 }

 /* --- input --- */
 function initInput(){
  const bind=(id,down,up)=>{const e=$(id);e.addEventListener('pointerdown',ev=>{ev.preventDefault();e.setPointerCapture(ev.pointerId);e.classList.add('dn');down()});
   const u=ev=>{e.classList.remove('dn');up&&up()};e.addEventListener('pointerup',u);e.addEventListener('pointercancel',u)};
  bind('btnFire',()=>{IN.fire=true;Sfx.init()},()=>IN.fire=false);bind('btnJump',()=>IN.jump=true);bind('btnReload',()=>IN.reload=true);bind('btnSwap',()=>IN.swap=true);bind('btnScope',()=>IN.scope=true);
  bind('btnShop',()=>shopOpen?closeShop():openShop());bind('btnScore',toggleScore);bind('btnPause',pause);
  const sz=$('stickZone'),sb=$('sBase'),sk=$('sKnob');let sid=null,sx=0,sy=0;
  sz.addEventListener('pointerdown',e=>{if(sid!==null)return;e.preventDefault();sid=e.pointerId;sz.setPointerCapture(sid);const q=Lay.p(e);sx=q[0];sy=q[1];sb.style.display=sk.style.display='block';
   sb.style.left=sx-52+'px';sb.style.top=sy-52+'px';sk.style.left=sx-23+'px';sk.style.top=sy-23+'px'});
  sz.addEventListener('pointermove',e=>{if(e.pointerId!==sid)return;const q=Lay.p(e);let dx=q[0]-sx,dy=q[1]-sy;const R=52,l=Math.hypot(dx,dy);if(l>R){dx*=R/l;dy*=R/l}
   sk.style.left=sx+dx-23+'px';sk.style.top=sy+dy-23+'px';const m=Math.hypot(dx,dy)/R;if(m<.15){IN.mx=IN.mz=0}else{IN.mx=dx/R;IN.mz=-dy/R}});
  const su=e=>{if(e.pointerId!==sid)return;sid=null;IN.mx=IN.mz=0;sb.style.display=sk.style.display='none'};sz.addEventListener('pointerup',su);sz.addEventListener('pointercancel',su);
  const lz=$('lookZone');let lid=null,lx=0,ly=0;
  lz.addEventListener('pointerdown',e=>{if(lid!==null)return;e.preventDefault();lid=e.pointerId;lz.setPointerCapture(lid);const q=Lay.p(e);lx=q[0];ly=q[1]});
  lz.addEventListener('pointermove',e=>{if(e.pointerId===lid){const q=Lay.p(e);IN.lookX+=q[0]-lx;IN.lookY+=q[1]-ly;lx=q[0];ly=q[1]}});
  const lu=e=>{if(e.pointerId===lid)lid=null};lz.addEventListener('pointerup',lu);lz.addEventListener('pointercancel',lu);
  // desktop
  const keys={};const upd=()=>{IN.mz=(keys.KeyW?1:0)-(keys.KeyS?1:0);IN.mx=(keys.KeyD?1:0)-(keys.KeyA?1:0)};
  addEventListener('keydown',e=>{if(e.repeat||G.phase!=='play')return;keys[e.code]=1;upd();
   if(e.code==='Space')IN.jump=true;else if(e.code==='KeyR')IN.reload=true;else if(e.code==='KeyB')shopOpen?closeShop():openShop();else if(e.code==='Tab'){e.preventDefault();toggleScore()}
   else if(e.code==='KeyQ')IN.swap=true;else if(e.code==='KeyE'||e.code==='ShiftLeft')IN.scope=true;else if(e.code==='Escape')pause();
   else if(/^Digit[1-6]$/.test(e.code)){const w=WORDER[+e.code[5]-1];if(w)setWeapon(w)}});
  addEventListener('keyup',e=>{keys[e.code]=0;upd()});
  $('gl').addEventListener('click',()=>{if(G.phase==='play'&&!G.paused&&!('ontouchstart' in window))$('gl').requestPointerLock&&$('gl').requestPointerLock()});
  addEventListener('mousemove',e=>{if(document.pointerLockElement===$('gl')){IN.lookX+=e.movementX;IN.lookY+=e.movementY}});
  addEventListener('mousedown',e=>{if(document.pointerLockElement===$('gl')&&e.button===0)IN.fire=true;if(document.pointerLockElement===$('gl')&&e.button===2)IN.scope=true});
  addEventListener('mouseup',e=>{if(e.button===0)IN.fire=false});addEventListener('contextmenu',e=>e.preventDefault());
 }
 function init(){
  $('nm').value=(()=>{try{return localStorage.getItem('fpsname')||''}catch(e){return ''}})();$('nm').addEventListener('change',()=>{try{localStorage.setItem('fpsname',$('nm').value)}catch(e){}});
  for(const id of['hlim','setQ'])$(id).addEventListener('click',e=>{const c=e.target.closest('.chip');if(!c)return;for(const x of $(id).children)x.classList.remove('sel');c.classList.add('sel');if(id==='hlim')hostLim=+c.dataset.v;Sfx.click()});
  Sfx.setVol(G.vol);initInput();try{Lay.flip=localStorage.getItem('fpsflip')==='1'}catch(e){}Lay.want=Lay.touch;Lay.apply();document.addEventListener('pointerdown',()=>{if(Lay.touch)forceLandscape()},{once:true});
  window.__back=()=>{if($('msgBox').classList.contains('on')){$('msgBox').classList.remove('on');return}
   if(G.phase==='play'||G.phase==='end'){if(shopOpen)closeShop();else if(scoreOpen)closeScore();else if(pauseOpen)resume();else pause();return}
   if(scrNow==='sMain'){return}if(scrNow==='sLobby'){leave();return}show('sMain')};
 }
 return{portrait,flip,startMatch,init,show,name,msg,toast,hitmark,dmgFlash,showDeath,killfeed,feed,lobby,serverFound,showEnd,tut,tutDone,hud,shopRefresh,enterGame,exitGame,goHost,createServer,goJoin,leaveJoin,joinManual,rtcMakeOffer,rtcFinish,rtcJoinGo,cp,goZomb,startZomb,startTut,saveSet,switchTeam,leave,closeShop,closeScore,resume};
})();
