LOONIE ACADEMY v12 — LOONIE LIFE (PHASE 6 / ORIGINAL 6-PHASE ROADMAP)
2026-11-15 | Complete HTML/PWA with optional Android APK build kit

BUILD & PRESERVATION
--------------------
Built DIRECTLY from Loonie_Academy_v11_Career_Pathways_Portfolios.zip.
The prior v11 ZIP remains unchanged; this ZIP is the ENTIRE application,
NOT a patch. The original 384 lessons, 37 subjects, 2,022 objective lesson
questions and all four earlier phases remain intact. No external AI account,
cloud server, paid API or login is needed for v12's simulation or core lessons.

NEW IN v12 / PHASE 6: LOONIE LIFE
--------------------------------
Loonie Life is an OPTIONAL, FICTIONAL 24-month game with deliberate turn-based
monthly choices. The learner begins with $2,100 in simulated cash, $550 in
simulated debt, an entry-level simulated occupation, and real in-app progress
linked to Phase 5 Career Pathways. It is educational, NOT financial advice,
actual work, salary data, an employment service or a credential.

1. EIGHT BRANCHING CAREERS
   - Accounting, carpentry, electrical, automotive, software/data, business,
     HVAC, and design. Each has 3 fictional work tiers and disclosed wages.
   - Simulated experience alone is NOT enough for higher work roles: Level 2
     requires 18 simulation experience and at least 2 linked completed real
     Academy lesson quizzes. Level 3 requires 40 experience, all 4 linked
     lessons, and at least 1 passed real Career Pathways practice case.
   - Switch careers with two-step confirmation: lose 8 fictional experience
     and 4 reputation, but real Academy learning/work evidence remains safe.

2. TWENTY-FOUR SIMULATED MONTHS AND OPEN CASH-FLOW MODEL
   - Choose housing (3), groceries (3), transportation (3), work schedules
     (3), training depth (3), savings (5 levels), debt repayment (5 levels).
   - 12 rotating story dilemmas with 3 alternatives each = 36 distinct
     decisions, some gated on real in-app lessons and practical projects.
   - See a full monthly forecast BEFORE committing, including wages,
     living costs, decision effects, business costs, interest, loan payment,
     savings transfer, and expected ending checking balance.
   - Fictional debt interest accrues 1% per month. Payments cannot exceed
     available checking cash. Savings transfers retain a $250 cash cushion;
     a negative cash forecast becomes simulated debt rather than an
     impossible negative checking balance. The app does NOT use a real bank.
   - Tracks wellbeing, trust, experience, net worth, cash, savings and debt;
     no action advances the calendar automatically or in the background.

3. THREE OPTIONAL FICTIONAL SMALL BUSINESSES
   - Neighbourhood Service, Creative Studio, Small Product Venture.
   - Requires the first career case passed, at least 16 simulation experience,
     $1,200 checking, reputation >=45, and month 4 or later.
   - One-time $900 start-up investment, then transparent unit economics:
     unit count × selected price, minus $42 per unit, $480 overhead and
     investment in quality or marketing. Monthly profit feeds the game
     ledger; lifetime revenue, costs, and profit are recorded separately.
   - A real business is never opened; there are no customers, payments,
     legal registration, tax filings or simulated professional permissions.

4. JOURNAL, 24-MONTH FINALE, REPORTS, AND GAME REWARDS
   - Private story compass, separate monthly journal reflections, decision
     history and full monthly financial ledger.
   - Save/export CSV ledger, shareable report JSON, and optional private
     report with journal reflections; no automatic uploads.
   - Seven new achievements, one-time XP/coin milestone rewards for month 1,
     6, 12, 24, emergency buffer, debt-free status and business launch.
   - Completing the 24th month displays a detailed ending. Reset requires
     two confirmations and deletes only lifeV12, NOT the broader app's
     notes, lessons, Kingdom, University, or career portfolio. Reward
     eligibility is stored separately in lifeAwardsV12, so restarting
     cannot repeatedly mint XP or coins.

5. NAVIGATION AND SAVED PROGRESS
   - Enter Loonie Life from World or Learn; jump to journal from Me.
   - All progress is persisted inside the SAME loonieAcademy_v1 localStorage
     payload as the existing app. Existing Academy backup/restore includes
     both lifeV12 and lifeAwardsV12 without a new incompatible format.
   - Requires no server/API; optional external decorative fonts and the
     previous Python sandbox's first-run download still need internet.

WHAT IS STILL IN v12
--------------------
- v1-v7: 384 lessons, 37 subjects, 2,022 quiz questions, trade/industrial,
  accounting/finance, study/review tools, subject courses, original rewards.
- v8: Personal University (four semesters, assignments, exams, capstones,
  transcript export, backward-compatible backups).
- v9: Inquiry Studio (nine interactive models, six investigations,
  three Teach Lou Plus modes, research notebook).
- v10: Knowledge Kingdom (six regions, 12 quests, six guardians,
  18 building upgrades, six relics, daily dispatch and expedition journal).
- v11: Career Pathways & Portfolios (eight pathways, 16 projects with 64
  checked objective questions, saved case evidence, personal portfolio,
  HTML/Markdown/JSON portfolio exports, career plans and achievements).

HOW TO USE
----------
For browser experimentation, extract the ZIP and open index.html. Desktop
file:// storage may behave differently; full PWA installation requires HTTPS
or localhost. Never rely on a single browser storage copy without backups.

The app has NOT been publicly hosted or installed on the user's phone yet.
To install it as an Android APK WITHOUT website hosting, use the accompanying
android-build-kit/README-ANDROID.txt. This builds a Capacitor WebView app
with static assets embedded locally; app setup needs Node.js, Android Studio
and Android SDK OR the included GitHub Actions cloud workflow.

ANDROID INSTALL NOTE
--------------------
The root includes android-build-kit (package.json, config, staging script,
Windows build .bat) and .github/workflows/build-android-debug.yml. The
Capacitor project is a BUILDER SCAFFOLD, not an already-built APK. This build
environment has no Android SDK and could not run Gradle or install the app
on a real phone. Mobile WebView file-export/backup behavior is therefore
NOT YET verified. Until tested, retain your original complete ZIP and any
backup exports. Debug APKs have test-only signing; stable release updates
require an owner-controlled signing key and package identifier.

QA
--
See QA-v12.txt. QA scripts run in isolated Chromium with inlined assets,
no actual user data. The service-worker suite uses a Node simulation.
  python qa-phase6.py
  python qa-phase6-branch.py
  python qa-phase5-v12.py
  python qa-phase4-v12.py
  python qa-phase3-v12.py
  python qa-phase2-v12.py
  node qa-sw-v12.js

SAFETY & LIMITATIONS
--------------------
- No salary, debt or cost figures are claimed to be actual Canadian market
  figures, credit terms, tax advice, employment outcomes or credentials.
- No independent review of written project quality, real trades safety
  supervision, accounting license, or professional competency occurs.
- Local browser/app data may be lost if app storage is cleared or app is
  removed. Export Academy backups and store them separately.
- Historic third-party content, fonts, original tax examples and Python
  exercises may require connectivity or current factual verification.
- Actual Android APK installation, airplane-mode reopen, full native backup
  file export, and public HTTPS deployment remain unverified.

Phase 6 completes the ORIGINAL six-phase roadmap. This doesn't prevent later
polishing, accessibility, native packaging, updates or major new content.
