JUVE PROMAX STUDIO — Projet Android

CONTENU
- Application Android basée sur une interface locale intégrée.
- Galerie initiale avec les 5 photos fournies.
- Filtres Portraits / Mariages / Événements.
- Mode admin permettant d'ajouter des images depuis le téléphone et de supprimer les images ajoutées.
- Les photos ajoutées sont enregistrées localement sur l'appareil (IndexedDB du navigateur intégré).

OUVRIR DANS ANDROID STUDIO
1. Décompresser JuvePromaxStudio.zip.
2. Ouvrir Android Studio puis choisir Open.
3. Sélectionner le dossier JuvePromaxStudio (celui qui contient settings.gradle.kts).
4. Attendre la synchronisation Gradle. Utiliser JDK 17 si Android Studio le demande.
5. Connecter un téléphone Android avec le débogage USB activé, ou lancer un émulateur.
6. Cliquer sur Run ▶ pour installer et tester.

GÉNÉRER LE FICHIER APK
Dans Android Studio : Build > Build Bundle(s) / APK(s) > Build APK(s).
Le fichier APK sera créé dans app/build/outputs/apk/debug/app-debug.apk.
Pour partager largement l'application, générer ensuite une version signée via Build > Generate Signed Bundle / APK.

À SAVOIR
- Cette version fonctionne hors ligne et conserve les photos ajoutées sur l'appareil où elles ont été ajoutées.
- Elle n'inclut pas encore de synchronisation en ligne entre plusieurs téléphones.
- Le bouton WhatsApp et les coordonnées du studio pourront être ajoutés quand le numéro officiel sera fourni.
