// Build a static tailwind.css from the classes used in index.html + app.js (no CDN at runtime).
// Usage: node tools/build-css.mjs   (needs the `tailwindcss` v4 package resolvable, e.g. npm i -D tailwindcss)
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const require = createRequire(process.env.TW_RESOLVE_FROM || (root + '/package.json'));
const twDir = path.dirname(require.resolve('tailwindcss/package.json'));
const { compile } = await import(pathToFileURL(path.join(twDir, 'dist/lib.mjs')).href);

const input = fs.readFileSync(path.join(root, 'src/app.css'), 'utf8');
const compiler = await compile(input, {
  base: root,
  loadStylesheet: async (id, base) => {
    let file;
    if (id === 'tailwindcss') file = path.join(twDir, 'index.css');
    else if (id.startsWith('tailwindcss/')) file = path.join(twDir, id.slice('tailwindcss/'.length) + (id.endsWith('.css') ? '' : '.css'));
    else file = path.resolve(base, id);
    return { path: file, base: path.dirname(file), content: fs.readFileSync(file, 'utf8') };
  },
});

const files = ['index.html', 'app.js', 'i18n.js'].map(f => fs.readFileSync(path.join(root, f), 'utf8')).join('\n');
const candidates = new Set(files.split(/[\s"'`<>]+/));
const css = compiler.build([...candidates]);
fs.writeFileSync(path.join(root, 'tailwind.css'), css);
console.log('tailwind.css', css.length, 'bytes');
