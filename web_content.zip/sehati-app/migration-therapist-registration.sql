-- Sehati final migration: therapist role + automatic pending therapist row.
-- Run ONCE in Supabase SQL Editor after taking a backup.
begin;
alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles add constraint profiles_role_check check (role in ('patient','therapist','admin'));
update public.profiles set role='therapist' where role='doctor';
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
declare requested_role text;
begin
 requested_role := case when new.raw_user_meta_data->>'role' = 'therapist' then 'therapist' else 'patient' end;
 insert into public.profiles (id,name,phone,role) values (new.id,coalesce(new.raw_user_meta_data->>'name',''),coalesce(new.raw_user_meta_data->>'phone',''),requested_role);
 if requested_role='therapist' then
  insert into public.doctors (user_id,name,specialty,active) values (new.id,coalesce(new.raw_user_meta_data->>'name',''),coalesce(new.raw_user_meta_data->>'specialty','general'),false) on conflict (user_id) do nothing;
 end if;
 return new;
end $$;
insert into public.doctors (user_id,name,specialty,active) select p.id,coalesce(p.name,''),'general',false from public.profiles p where p.role='therapist' on conflict (user_id) do nothing;
commit;
