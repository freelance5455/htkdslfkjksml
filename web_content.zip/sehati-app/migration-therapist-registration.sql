-- Sehati migration: allow therapist registration while requiring admin activation.
-- Run in Supabase SQL Editor AFTER the original schema has been installed.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare requested_role text;
begin
  requested_role := case when new.raw_user_meta_data->>'role' = 'doctor' then 'doctor' else 'patient' end;
  insert into public.profiles (id, name, phone, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'name',''), coalesce(new.raw_user_meta_data->>'phone',''), requested_role);
  if requested_role = 'doctor' then
    insert into public.doctors (user_id, name, specialty, active)
    values (new.id, coalesce(new.raw_user_meta_data->>'name',''), 'general', false)
    on conflict (user_id) do nothing;
  end if;
  return new;
end $$;
