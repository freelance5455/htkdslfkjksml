/* sehati — Supabase client بدون مكتبات (fetch فقط)، يحافظ على فكرة "ما يحتاج CDN".
   حط الملف في الجذر، وأضف <script src="backend.js"></script> قبل app.js، وزيدو في SHELL تاع sw.js.
   الـ anon key عمومي بطبيعتو؛ الحماية الفعلية من RLS في schema.sql. */
(() => {
'use strict';
const SUPABASE_URL = 'https://sdqbgrlycxovmqnehiao.supabase.co'; // Supabase Project URL
const SUPABASE_ANON_KEY = 'sb_publishable_lCmEU2EU7w6gLDcPq1o8uw_64gW3ak3'; // Paste the sb_publishable_... key here

const KEY = 'sehati:sb-session';
const enabled = () => !!(SUPABASE_URL && SUPABASE_ANON_KEY);
let sess = (() => { try { return JSON.parse(localStorage.getItem(KEY)); } catch (e) { return null; } })();
const store = s => { sess = s; try { s ? localStorage.setItem(KEY, JSON.stringify(s)) : localStorage.removeItem(KEY); } catch (e) { /* ignore */ } };

async function raw(path, { method = 'GET', body, token, headers = {} } = {}) {
  const r = await fetch(SUPABASE_URL + path, {
    method, body: body === undefined ? undefined : JSON.stringify(body),
    headers: { apikey: SUPABASE_ANON_KEY, 'Content-Type': 'application/json',
      Authorization: 'Bearer ' + (token || SUPABASE_ANON_KEY), ...headers }
  });
  const txt = await r.text();
  let json = null; try { json = txt ? JSON.parse(txt) : null; } catch (e) { /* not json */ }
  if (!r.ok) { const e = new Error((json && (json.msg || json.message || json.error_description)) || r.statusText); e.status = r.status; e.code = json && json.code; throw e; }
  return json;
}

async function token() {
  if (!sess) return null;
  if (sess.expires_at * 1000 - Date.now() > 60000) return sess.access_token;
  try { setSession(await raw('/auth/v1/token?grant_type=refresh_token', { method: 'POST', body: { refresh_token: sess.refresh_token } })); }
  catch (e) { store(null); return null; }
  return sess.access_token;
}
const setSession = d => store({ access_token: d.access_token, refresh_token: d.refresh_token,
  expires_at: d.expires_at || Math.floor(Date.now() / 1000) + d.expires_in, user: d.user });

const auth = {
  async signUp({ email, password, name, phone, role = 'patient' }) {
    const safeRole = role === 'doctor' ? 'doctor' : 'patient';
    const d = await raw('/auth/v1/signup', { method: 'POST', body: { email, password, data: { name, phone, role: safeRole } } });
    if (d.access_token) { setSession(d); return { user: d.user, confirmed: true }; }
    return { user: d.user || d, confirmed: false };   // إذا تأكيد البريد مفعّل في Supabase
  },
  async signIn({ email, password }) {
    const d = await raw('/auth/v1/token?grant_type=password', { method: 'POST', body: { email, password } });
    setSession(d); return d.user;
  },
  async signOut() {
    const tk = await token();
    if (tk) { try { await raw('/auth/v1/logout', { method: 'POST', token: tk }); } catch (e) { /* ignore */ } }
    store(null);
  },
  user: () => (sess ? sess.user : null)
};

/* REST: db.select('appointments', 'select=*&order=date'), db.insert(...), db.update(table, 'id=eq.X', {...}) */
async function rest(table, { method = 'GET', query = '', body, prefer } = {}) {
  const tk = await token();
  return raw(`/rest/v1/${table}${query ? '?' + query : ''}`, { method, body, token: tk,
    headers: prefer ? { Prefer: prefer } : {} });
}
const db = {
  select: (t, q) => rest(t, { query: q }),
  insert: (t, row) => rest(t, { method: 'POST', body: row, prefer: 'return=representation' }).then(r => r && r[0]),
  update: (t, q, patch) => rest(t, { method: 'PATCH', query: q, body: patch, prefer: 'return=representation' }),
  upsert: (t, row, onConflict) => rest(t, { method: 'POST', query: onConflict ? 'on_conflict=' + onConflict : '', body: row, prefer: 'resolution=merge-duplicates,return=representation' }),
  remove: (t, q) => rest(t, { method: 'DELETE', query: q }),
  async rpc(fn, args) { const tk = await token(); return raw('/rest/v1/rpc/' + fn, { method: 'POST', body: args || {}, token: tk }); }
};

/* ===== دوال جاهزة تقابل طبقة app.js الحالية ===== */
const api = {
  listDoctors: () => db.select('doctors', 'select=*&active=eq.true&order=name'),
  takenSlots: (doctorId, from, to) => db.rpc('taken_slots', { p_doctor: doctorId, p_from: from, p_to: to }),
  myAppointments: () => db.select('appointments', 'select=*&order=date.desc,time.desc'),
  book: a => db.insert('appointments', a),     // يرجع خطأ code 23505 إذا الوقت تحجز (unique index)
  updateAppointment: (id, patch) => db.update('appointments', 'id=eq.' + id, patch),
  myProfile: () => db.select('profiles', 'select=*&id=eq.' + auth.user().id).then(r => r[0]),
  saveProfile: p => db.update('profiles', 'id=eq.' + auth.user().id, p),
  loadVitals: () => db.select('patient_vitals', 'select=vitals').then(r => (r[0] ? r[0].vitals : [])),
  saveVitals: v => db.upsert('patient_vitals', { user_id: auth.user().id, vitals: v }, 'user_id'),
  loadRecord: () => db.select('patient_records', 'select=record').then(r => (r[0] ? r[0].record : {})),
  saveRecord: rec => db.upsert('patient_records', { user_id: auth.user().id, record: rec }, 'user_id'),
  myLinks: () => db.select('care_links', 'select=*'),
  setSharing: (doctorId, flags) => db.update('care_links', `patient_id=eq.${auth.user().id}&doctor_id=eq.${doctorId}`, flags),
  // جهة الطبيب
  doctorAgenda: from => db.select('appointments', `select=*,profiles(name,phone)&status=eq.booked&date=gte.${from}&order=date,time`),
  doctorPatients: () => db.select('care_links', 'select=*,profiles(name,phone)'),
  patientVitals: pid => db.select('patient_vitals', 'select=vitals&user_id=eq.' + pid).then(r => (r[0] ? r[0].vitals : null))
};

window.SEHATI_BACKEND = { enabled, auth, db, api };
})();
