/* sehati — app logic. Everything is stored locally (localStorage) behind the LS/accounts/data layer,
   so a backend (e.g. Supabase) can replace that layer later without touching the UI code. */
(() => {
'use strict';

/* ============================== CONFIG ============================== */
const CONFIG = {
  contactEmail: '',                       // shown in the privacy text when set
  videoBase: 'https://meet.jit.si/Sehati-', // video room = base + random room id of the appointment
  joinBeforeMin: 15, joinAfterMin: 60, slotMinutes: 30, maxDaysAhead: 60,
  maxLoginAttempts: 5, lockSeconds: 30, pbkdf2Iterations: 210000
};
const mkHours = (from = 9, to = 17, step = 30) => {
  const out = [];
  for (let m = from * 60; m < to * 60; m += step) out.push(String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'));
  return out;
};
/* Replace with your real doctors. days: 0=Sunday … 6=Saturday (Algeria works Sun–Thu).
   demo:true shows a "demo mode" banner; remove the flag once the doctors are real. */
let DOCTORS = [
  { id: 'd1', name: 'Dr. Sophia Benallal', specialty: 'cardio', modes: ['video', 'clinic'], days: [0, 1, 2, 3, 4], hours: mkHours(9, 17), demo: true },
  { id: 'd2', name: 'Dr. Karim Mansouri', specialty: 'general', modes: ['video', 'clinic'], days: [0, 1, 2, 3, 4], hours: mkHours(9, 16), demo: true }
];

/* ============================== HELPERS ============================== */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = n => String(n).padStart(2, '0');
const dstr = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const todayStr = () => dstr(new Date());
const addDays = (s, n) => { const d = new Date(s + 'T00:00:00'); d.setDate(d.getDate() + n); return dstr(d); };
const startOf = a => new Date(`${a.date}T${a.time}:00`);
const endOf = a => new Date(startOf(a).getTime() + CONFIG.slotMinutes * 60000);
const randHex = n => { const b = new Uint8Array(n); crypto.getRandomValues(b); return [...b].map(x => pad(x.toString(16))).join(''); };
const uid = () => randHex(8);

const SB = window.SEHATI_BACKEND;
const REMOTE = !!(SB && SB.enabled());   // true = Supabase (shared); false = old localStorage mode
const api = REMOTE ? SB.api : null;
const LS = {
  get(k, d) { try { const v = localStorage.getItem('sehati:' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('sehati:' + k, JSON.stringify(v)); return true; } catch (e) { return false; } },
  del(k) { try { localStorage.removeItem('sehati:' + k); } catch (e) { /* ignore */ } }
};

/* ============================== i18n ============================== */
const I = window.SEHATI_I18N;
let lang = LS.get('lang', null);
if (!I[lang]) lang = 'fr';
const t = (k, v) => {
  let s = (I[lang] && I[lang][k] !== undefined) ? I[lang][k] : (I.fr[k] !== undefined ? I.fr[k] : k);
  if (v && typeof s === 'string') for (const x in v) s = s.replaceAll('{' + x + '}', v[x]);
  return s;
};
const LOCALES = { fr: 'fr-FR', ar: 'ar-DZ-u-nu-latn', en: 'en-GB' };
const fmtDate = (s, o = { weekday: 'short', day: 'numeric', month: 'short' }) => new Intl.DateTimeFormat(LOCALES[lang], o).format(new Date(s + 'T12:00:00'));
const fmtDateTime = ts => new Intl.DateTimeFormat(LOCALES[lang], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }).format(new Date(ts));
const dayLabel = s => s === todayStr() ? t('today') : s === addDays(todayStr(), 1) ? t('tomorrow') : fmtDate(s);
const whenLabel = a => `${dayLabel(a.date)} • ${a.time}`;

/* ============================== STORAGE / STATE ============================== */
let accounts = LS.get('accounts', {});
let session = LS.get('session', null);   // {email} | {guest:true} | null
let me = null;                           // account of the signed-in user
let data = emptyData();                  // that user's data (in memory only for guests)
function emptyData() { return { appointments: [], vitals: [], record: {}, prefs: { reminders: true } }; }
const saveAccounts = () => LS.set('accounts', accounts);
const netErr = () => toast(t('err_generic'), 'err');
const saveData = part => {
  if (!me) return;
  if (!REMOTE) return LS.set('data:' + me.email, data);
  if (part === 'vitals') api.saveVitals(data.vitals).catch(netErr);
  else if (part === 'record') api.saveRecord(data.record).catch(netErr);
  else if (part === 'prefs') api.saveProfile({ prefs: data.prefs }).catch(netErr);
};
const mapDoctor = d => ({ id: d.id, name: d.name, specialty: d.specialty, modes: d.modes, days: d.days, hours: d.hours });
const mapAppt = a => ({ id: a.id, doctorId: a.doctor_id, date: a.date, time: a.time, mode: a.mode, reason: a.reason || '', status: a.status, room: a.room, createdAt: a.created_at });
const takenCache = {};   // doctorId -> Set('YYYY-MM-DD|HH:MM') of slots booked by anyone
async function loadTaken(id) {
  const rows = await api.takenSlots(id, todayStr(), addDays(todayStr(), CONFIG.maxDaysAhead));
  takenCache[id] = new Set(rows.map(r => r.date + '|' + r.time));
}
async function loadRemote() {
  const u = SB.auth.user(); if (!u) throw new Error('nosession');
  const [p, docs, appts, vit, rec] = await Promise.all([api.myProfile(), api.listDoctors(), api.myAppointments(), api.loadVitals(), api.loadRecord()]);
  DOCTORS = docs.map(mapDoctor);
  me = { id: u.id, email: u.email, name: p.name, phone: p.phone, avatar: p.avatar, role: p.role };
  data = Object.assign(emptyData(), { appointments: appts.map(mapAppt), vitals: vit || [], record: rec || {} });
  data.prefs = Object.assign({ reminders: true }, p.prefs);
}
function loadUser(email) {
  me = accounts[email] || null;
  data = Object.assign(emptyData(), me ? LS.get('data:' + email, {}) : {});
  data.prefs = Object.assign({ reminders: true }, data.prefs);
}
const isGuest = () => !me;

/* ============================== CRYPTO (password hashing) ============================== */
const b64 = buf => btoa(String.fromCharCode(...new Uint8Array(buf)));
const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
async function hashPw(pw, saltB64, iter) {
  if (!(window.crypto && crypto.subtle)) throw new Error('nocrypto');
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(pw), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: unb64(saltB64), iterations: iter }, key, 256);
  return b64(bits);
}
const safeEq = (a, b) => { if (a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; };

/* ============================== UI PRIMITIVES ============================== */
let toastTimer;
function toast(msg, kind = 'ok') {
  const el = $('#toast');
  el.textContent = msg;
  el.className = 'absolute z-[130] bottom-24 inset-x-4 mx-auto max-w-xs text-center text-sm font-semibold rounded-2xl px-4 py-3 shadow-xl ' + (kind === 'err' ? 'bg-rose-600 text-white' : 'bg-slate-900 text-white');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), 2600);
}
function openSheet(html) {
  $('#sheet-panel').innerHTML = html;
  $('#sheet').classList.remove('hidden'); $('#sheet').classList.add('shown');
  const first = $('#sheet-panel input, #sheet-panel button[data-act="close-sheet"]'); if (first) first.focus();
}
function closeSheet() { $('#sheet').classList.add('hidden'); $('#sheet').classList.remove('shown'); $('#sheet-panel').innerHTML = ''; }
const sheetHead = (title) => `<div class="flex items-center justify-between mb-4"><h3 class="font-extrabold text-lg text-slate-900">${esc(title)}</h3>
  <button type="button" data-act="close-sheet" class="icon-btn -me-2" aria-label="${esc(t('common_close'))}"><svg class="size-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg></button></div>`;
const emptyState = (text, btn) => `<div class="card text-center py-8"><p class="text-sm text-slate-500">${esc(text)}</p>${btn || ''}</div>`;
const gateCard = () => `<div class="card text-center py-8 space-y-3"><h3 class="font-extrabold text-slate-900">${esc(t('gate_title'))}</h3><p class="text-sm text-slate-500">${esc(t('gate_text'))}</p>
  <button type="button" data-act="gate-register" class="btn-primary">${esc(t('gate_btn'))}</button></div>`;
const demoBanner = () => DOCTORS.some(d => d.demo) ? `<div class="rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-sm px-3 py-2.5">${esc(t('demo_banner'))}</div>` : '';

/* ============================== DOMAIN: doctors & appointments ============================== */
const doc = id => DOCTORS.find(d => d.id === id);
const initials = n => n.replace(/^Dr\.?\s*/i, '').split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
const spLabel = k => t('sp_' + k);
const modeLabel = m => t(m === 'video' ? 'mode_video' : 'mode_clinic');
const live = a => a.status === 'booked' && endOf(a) >= new Date();
const upcomingList = () => data.appointments.filter(live).sort((x, y) => startOf(x) - startOf(y));
const pastList = () => data.appointments.filter(a => !live(a)).sort((x, y) => startOf(y) - startOf(x));
const nextAppt = () => upcomingList()[0] || null;
const nextVideo = () => upcomingList().find(a => a.mode === 'video') || null;
function slotTaken(doctorId, date, time, excludeId) {
  if (data.appointments.some(a => a.status === 'booked' && a.id !== excludeId && a.doctorId === doctorId && a.date === date && a.time === time)) return true;
  if (!REMOTE) return false;
  const set = takenCache[doctorId];
  if (!set || !set.has(date + '|' + time)) return false;
  const ex = excludeId && data.appointments.find(a => a.id === excludeId);
  return !(ex && ex.doctorId === doctorId && ex.date === date && ex.time === time);   // my own slot while rescheduling
}
function availableSlots(d, date, excludeId) {
  if (!d || !date) return [];
  const dow = new Date(date + 'T12:00:00').getDay();
  if (!d.days.includes(dow)) return [];
  const now = new Date();
  return d.hours.filter(h => new Date(`${date}T${h}:00`) > now && !slotTaken(d.id, date, h, excludeId));
}
function firstAvailableDate(d, excludeId) {
  for (let i = 0; i <= 14; i++) { const s = addDays(todayStr(), i); if (availableSlots(d, s, excludeId).length) return s; }
  return todayStr();
}
function joinState(a) {
  const now = Date.now(), s = startOf(a).getTime();
  if (now < s - CONFIG.joinBeforeMin * 60000) return 'wait';
  if (now > s + CONFIG.joinAfterMin * 60000) return 'over';
  return 'open';
}
const roomUrl = a => CONFIG.videoBase + a.room;

/* ============================== ROUTER ============================== */
const VIEWS = ['dashboard', 'appointments', 'booking', 'telehealth', 'health', 'profile', 'settings'];
const NAV_OF = { telehealth: 'appointments', settings: 'profile' };
let current = 'dashboard';
let selectedAuthRole = 'patient';
function go(v) {
  if (!VIEWS.includes(v)) v = 'dashboard';
  if (location.hash !== '#/' + v) location.hash = '#/' + v; else show(v);
}
function show(v) {
  current = v;
  VIEWS.forEach(id => $('#view-' + id).classList.toggle('hidden', id !== v));
  const active = NAV_OF[v] || v;
  $$('[data-nav]').forEach(b => b.classList.toggle('active', b.dataset.nav === active));
  renderView(v);
  $('#main').scrollTop = 0;
}
window.addEventListener('hashchange', () => { if (appVisible()) show((location.hash.match(/^#\/(\w+)/) || [])[1] || 'dashboard'); });
const appVisible = () => $('#app').classList.contains('shown');

function renderView(v) {
  ({ dashboard: renderDashboard, appointments: renderAppointments, booking: renderBooking, telehealth: renderTelehealth,
     health: renderHealth, profile: renderProfile, settings: renderSettings }[v])();
  updateNotifDot();
}

/* ============================== LANGUAGE ============================== */
function applyLang(l) {
  if (!I[l]) l = 'fr';
  lang = l; LS.set('lang', l);
  document.documentElement.lang = l;
  document.documentElement.dir = l === 'ar' ? 'rtl' : 'ltr';
  $$('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
  $$('[data-i18n-ph]').forEach(el => { el.placeholder = t(el.dataset.i18nPh); });
  const regRole = $('#register-role-label');
  if (regRole) regRole.textContent = t(selectedAuthRole === 'doctor' ? 'role_therapist' : 'role_patient');
  const proNote = $('#register-role-note');
  if (proNote) proNote.textContent = t(selectedAuthRole === 'doctor' ? 'therapist_register_note' : 'pro_note');
  $$('.lang-btn').forEach(b => b.classList.toggle('on', b.dataset.l === l));
  if (appVisible()) renderView(current);
  if (!$('#sheet').classList.contains('hidden')) closeSheet();
}

/* ============================== AUTH ============================== */
function authMsg(text, ok) {
  const el = $('#auth-msg');
  if (!text) { el.classList.add('hidden'); return; }
  el.textContent = text;
  el.className = 'mt-4 text-sm text-center font-bold ' + (ok ? 'text-emerald-600' : 'text-rose-600');
}
function authMode(m) {
  
  const login = m === 'login';
  $('#auth-tabs').classList.remove('hidden');
  $('#therapist-note').classList.toggle('hidden', selectedAuthRole !== 'doctor');
  $('#form-login').classList.toggle('hidden', !login);
  $('#form-register').classList.toggle('hidden', login);
  $('#tab-login').classList.toggle('on', login);
  $('#tab-register').classList.toggle('on', !login);
  authMsg('');
}
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE_RE = /^\+?[0-9 ()-]{8,18}$/;

async function remoteRegister({ name, phone, email, pw, role }) {
  try {
    const r = await SB.auth.signUp({ email, password: pw, name, phone, role });
    $('#form-register').reset();
    if (role === 'doctor') {
      $('#form-register').reset();
      $('#auth').classList.add('hidden');
      const wait = $('#therapist-pending-screen');
      wait.classList.remove('hidden');
      wait.classList.add('flex');
      return;
    }
    if (r.confirmed) return startSession({ email });
    authMode('login'); authMsg(t('check_email'), true);
  } catch (err) { authMsg(/already|registered/i.test(err.message) ? t('err_exists') : t('err_generic')); }
}
async function remoteLogin(email, pw, lock) {
  try {
    await SB.auth.signIn({ email, password: pw });
    LS.del('lock');
    // Verify the account role from the protected profile before opening the chosen workspace.
    const profile = await api.myProfile();
    const actualRole = profile && profile.role ? profile.role : 'patient';
    if (actualRole !== selectedAuthRole && !(selectedAuthRole === 'doctor' && actualRole === 'doctor')) {
      await SB.auth.signOut();
      return authMsg(selectedAuthRole === 'doctor' ? t('therapist_not_approved') : t('therapist_login_as'));
    }
    $('#form-login').reset();
    await startSession({ email });
  } catch (err) {
    if (/confirm/i.test(err.message)) return authMsg(t('check_email'));
    if (err.status === 400 || err.status === 401 || err.status === 422) {
      lock.n = (lock.n || 0) + 1;
      if (lock.n >= CONFIG.maxLoginAttempts) { lock.n = 0; lock.until = Date.now() + CONFIG.lockSeconds * 1000; }
      LS.set('lock', lock);
      return authMsg(lock.until > Date.now() ? t('err_locked', { s: CONFIG.lockSeconds }) : t('err_bad_login'));
    }
    authMsg(t('err_generic'));
  }
}
async function doRegister(e) {
  e.preventDefault();
  const name = $('#r-name').value.trim(), phone = $('#r-phone').value.trim(), email = $('#r-email').value.trim().toLowerCase();
  const pw = $('#r-pw').value, pw2 = $('#r-pw2').value;
  if (name.length < 2) return authMsg(t('err_name'));
  if (!EMAIL_RE.test(email)) return authMsg(t('err_email'));
  if (!PHONE_RE.test(phone)) return authMsg(t('err_phone'));
  if (pw.length < 8 || !/[A-Za-z؀-ۿ]/.test(pw) || !/[0-9]/.test(pw)) return authMsg(t('err_pw_len'));
  if (pw !== pw2) return authMsg(t('err_pw_match'));
  if (!$('#r-terms').checked) return authMsg(t('err_terms'));
  if (REMOTE) return remoteRegister({ name, phone, email, pw, role: selectedAuthRole });
  if (selectedAuthRole === 'doctor') return authMsg(t('therapist_remote_only'));
  if (accounts[email]) return authMsg(t('err_exists'));
  try {
    const salt = b64(crypto.getRandomValues(new Uint8Array(16)));
    const hash = await hashPw(pw, salt, CONFIG.pbkdf2Iterations);
    accounts[email] = { name, phone, email, role: 'patient', avatar: 1, salt, hash, iter: CONFIG.pbkdf2Iterations, createdAt: new Date().toISOString() };
    if (!saveAccounts()) { delete accounts[email]; return authMsg(t('err_generic')); }
    $('#form-register').reset();
    startSession({ email });
  } catch (err) { authMsg(err.message === 'nocrypto' ? t('err_crypto') : t('err_generic')); }
}
async function doLogin(e) {
  e.preventDefault();
  const email = $('#l-email').value.trim().toLowerCase(), pw = $('#l-pw').value;
  if (!email || !pw) return authMsg(t('err_fields'));
  const lock = LS.get('lock', { n: 0, until: 0 });
  if (lock.until > Date.now()) return authMsg(t('err_locked', { s: Math.ceil((lock.until - Date.now()) / 1000) }));
  if (REMOTE) return remoteLogin(email, pw, lock);
  try {
    const acc = accounts[email];
    let ok = false;
    if (acc) ok = safeEq(await hashPw(pw, acc.salt, acc.iter), acc.hash);
    else await hashPw(pw, b64(new Uint8Array(16)), CONFIG.pbkdf2Iterations); // same timing for unknown e-mails
    if (!ok) {
      lock.n = (lock.n || 0) + 1;
      if (lock.n >= CONFIG.maxLoginAttempts) { lock.n = 0; lock.until = Date.now() + CONFIG.lockSeconds * 1000; }
      LS.set('lock', lock);
      return authMsg(lock.until > Date.now() ? t('err_locked', { s: CONFIG.lockSeconds }) : t('err_bad_login'));
    }
    if (selectedAuthRole !== 'patient' || (acc.role || 'patient') !== selectedAuthRole) return authMsg('هذا الحساب غير مفعّل لهذا النوع من الدخول.');
    LS.del('lock');
    $('#form-login').reset();
    startSession({ email });
  } catch (err) { authMsg(err.message === 'nocrypto' ? t('err_crypto') : t('err_generic')); }
}
async function startSession(s) {
  session = s;
  if (s.email) {
    LS.set('session', s);
    if (REMOTE) { try { await loadRemote(); } catch (err) { return endSession(t('err_generic')); } } else loadUser(s.email);
  } else {
    LS.del('session'); me = null; data = emptyData();
    if (REMOTE) { try { DOCTORS = (await api.listDoctors()).map(mapDoctor); } catch (err) { /* keep list */ } }
  }
  authMsg('');
  $('#auth').classList.add('hidden');
  $('#app').classList.remove('hidden'); $('#app').classList.add('shown');
  $$('[data-nav]').forEach(b => { b.classList.toggle('hidden', !!(me && me.role === 'doctor' && !['dashboard','profile'].includes(b.dataset.nav))); });
  const v = (location.hash.match(/^#\/(\w+)/) || [])[1];
  if (v && VIEWS.includes(v) && location.hash === '#/' + v) show(v); else go('dashboard');
}
function endSession(message) {
  if (REMOTE) SB.auth.signOut();
  LS.del('session'); session = null; me = null; data = emptyData();
  closeSheet();
  $('#app').classList.add('hidden'); $('#app').classList.remove('shown');
  $('#auth').classList.remove('hidden');
  history.replaceState(null, '', location.pathname);
  authMode('login');
  if (message) authMsg(message, true);
}

/* ============================== VIEW: dashboard ============================== */
function lastVital(type) { return data.vitals.filter(v => v.type === type).sort((a, b) => b.ts.localeCompare(a.ts))[0]; }
const vitalText = v => v.type === 'bp' ? `${v.a}/${v.b}` : String(v.a);
const VITAL_META = {
  hr: { label: 'v_hr', unit: 'u_hr', color: 'text-rose-500', bg: 'bg-rose-50' },
  bp: { label: 'v_bp', unit: 'u_bp', color: 'text-sky-600', bg: 'bg-sky-50' },
  glu: { label: 'v_glu', unit: 'u_glu', color: 'text-amber-600', bg: 'bg-amber-50' }
};
function renderDashboard() {
  const el = $('#view-dashboard');
  if (me && me.role === 'doctor') return renderTherapistDashboard();
  const name = me ? me.name.split(/\s+/)[0] : '';
  const n = nextAppt();
  const hero = n ? (() => { const d = doc(n.doctorId); return `
      <div class="mt-3 pt-3 border-t border-white/25 flex items-center justify-between gap-3">
        <div class="min-w-0"><p class="text-xs text-teal-100">${esc(t('next_appt'))}</p>
          <p class="font-bold truncate">${esc(whenLabel(n))} · ${esc(d ? d.name : '')}</p></div>
        ${n.mode === 'video' ? `<button type="button" data-act="go" data-v="telehealth" class="shrink-0 min-h-10 px-3.5 rounded-xl bg-white text-teal-800 text-sm font-bold">${esc(t('join'))}</button>` : ''}
      </div>`; })() : `
      <div class="mt-3 pt-3 border-t border-white/25 flex items-center justify-between gap-3">
        <p class="text-sm text-teal-50">${esc(t('none_next'))}</p>
        <button type="button" data-act="new-booking" class="shrink-0 min-h-10 px-3.5 rounded-xl bg-white text-teal-800 text-sm font-bold">${esc(t('book_now'))}</button>
      </div>`;
  const qa = [
    ['new-booking', '', t('q_book'), 'bg-teal-50 text-teal-600', 'M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5'],
    ['go', 'telehealth', t('q_video'), 'bg-sky-50 text-sky-600', 'M15.75 10.5l4.72-4.72a.75.75 0 011.28.53v11.38a.75.75 0 01-1.28.53l-4.72-4.72M4.5 18.75h9a2.25 2.25 0 002.25-2.25v-9a2.25 2.25 0 00-2.25-2.25h-9A2.25 2.25 0 002.25 7.5v9A2.25 2.25 0 004.5 18.75z'],
    ['go-file', '', t('q_file'), 'bg-purple-50 text-purple-600', 'M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z'],
    ['go-vitals', '', t('q_vitals'), 'bg-rose-50 text-rose-600', 'M3 12h4l2-5 4 10 2-5h6']
  ].map(([act, v, label, cls, path]) => `<button type="button" data-act="${act}" ${v ? `data-v="${v}"` : ''} class="card !p-3 flex flex-col items-center gap-2 min-h-[104px] hover:border-teal-400">
      <span class="size-11 rounded-xl ${cls} flex items-center justify-center"><svg class="size-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="${path}"/></svg></span>
      <span class="text-sm font-bold text-slate-700 text-center leading-tight">${esc(label)}</span></button>`).join('');
  const vit = isGuest() ? '' : `<div>
      <div class="flex items-center justify-between mb-2"><h3 class="text-sm font-extrabold text-slate-900">${esc(t('vitals_title'))}</h3>
        <button type="button" data-act="go-vitals" class="text-sm font-bold text-teal-600 min-h-10 px-1">${esc(t('add'))}</button></div>
      <div class="grid grid-cols-3 gap-2">${['hr', 'bp', 'glu'].map(k => { const v = lastVital(k), m = VITAL_META[k];
        return `<div class="card !p-3"><span class="text-xs text-slate-500 block leading-tight min-h-8">${esc(t(m.label))}</span>
          ${v ? `<div class="mt-1 flex items-baseline gap-1 flex-wrap"><span class="text-lg font-extrabold text-slate-900">${esc(vitalText(v))}</span><span class="text-xs text-slate-400">${esc(t(m.unit))}</span></div>
          <span class="text-xs text-slate-400">${esc(fmtDateTime(v.ts))}</span>` : `<div class="mt-1 text-lg font-extrabold text-slate-300">—</div><span class="text-xs text-slate-400">${esc(t('no_value'))}</span>`}</div>`; }).join('')}</div></div>`;
  const apptCardHtml = isGuest() ? gateCard() : (n ? `<div><h3 class="text-sm font-extrabold text-slate-900 mb-2">${esc(t('upcoming_card'))}</h3>${apptCard(n)}</div>` : '');
  el.innerHTML = `
    <div class="rounded-3xl p-5 bg-gradient-to-br from-teal-700 to-teal-600 text-white shadow-lg">
      <h2 class="text-xl font-extrabold">${esc(t('hello'))}${name ? ', ' + esc(name) : ''} 👋</h2>
      <p class="text-sm text-teal-100 mt-1">${esc(t('dash_sub'))}</p>${isGuest() ? '' : hero}
    </div>
    <div class="relative">
      <span class="absolute inset-y-0 start-0 ps-3.5 flex items-center text-slate-400 pointer-events-none"><svg class="size-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z"/></svg></span>
      <input id="dash-q" type="search" enterkeyhint="search" class="field !ps-11" placeholder="${esc(t('search_ph'))}">
    </div>
    <div><h3 class="text-sm font-extrabold text-slate-900 mb-2">${esc(t('quick'))}</h3><div class="grid grid-cols-2 gap-3">${qa}</div></div>
    ${vit}${apptCardHtml}
    <p class="text-xs text-slate-400 text-center px-2">${esc(t('medical_disclaimer'))}</p>`;
}

async function renderTherapistDashboard() {
  const el = $('#view-dashboard');
  el.innerHTML = `<div class="rounded-3xl p-5 bg-gradient-to-br from-indigo-800 to-violet-700 text-white shadow-lg"><p class="text-sm text-indigo-100">فضاء مهني</p><h2 class="text-2xl font-extrabold mt-1">مرحباً ${esc(me.name)} 👋</h2><p class="text-sm text-indigo-100 mt-2">لوحة المعالج الوظيفي — المواعيد ومتابعة المرضى</p></div><div class="grid grid-cols-2 gap-3"><div class="card !m-0"><span class="text-2xl">📅</span><p class="font-extrabold mt-2">مواعيدي</p><p class="text-xs text-slate-500">عرض المواعيد القادمة</p></div><div class="card !m-0"><span class="text-2xl">👥</span><p class="font-extrabold mt-2">المرضى</p><p class="text-xs text-slate-500">المرضى المرتبطون بحسابك</p></div></div><div class="card"><h3 class="font-extrabold text-slate-900 mb-3">المواعيد القادمة</h3><div id="therapist-agenda" class="text-sm text-slate-500">جاري تحميل المواعيد…</div></div><div class="card"><h3 class="font-extrabold text-slate-900 mb-3">المرضى</h3><div id="therapist-patients" class="text-sm text-slate-500">جاري تحميل قائمة المرضى…</div></div><button type="button" data-act="go" data-v="profile" class="btn-soft w-full">الملف الشخصي والإعدادات</button>`;
  if (!REMOTE) { $('#therapist-agenda').textContent = 'يتطلب حساب معالج مفعّل في قاعدة البيانات.'; $('#therapist-patients').textContent = 'لا توجد بيانات متاحة في الوضع المحلي.'; return; }
  try {
    const [agenda, patients] = await Promise.all([api.doctorAgenda(todayStr()), api.doctorPatients()]);
    const aEl = $('#therapist-agenda'), pEl = $('#therapist-patients');
    if (!aEl || !pEl) return;
    aEl.innerHTML = agenda.length ? agenda.map(a => `<div class="py-3 border-b border-slate-100 last:border-0"><p class="font-bold text-slate-800">${esc(a.profiles?.name || 'مريض')}</p><p class="text-xs text-slate-500 mt-1">${esc(a.date)} · ${esc(a.time)} · ${esc(a.mode === 'video' ? 'عن بعد' : 'في العيادة')}</p><span class="text-xs text-teal-700">${esc(a.status || 'محجوز')}</span></div>`).join('') : '<p>ما كاش مواعيد قادمة حالياً.</p>';
    pEl.innerHTML = patients.length ? patients.map(c => `<div class="py-3 border-b border-slate-100 last:border-0"><p class="font-bold text-slate-800">${esc(c.profiles?.name || 'مريض')}</p><p class="text-xs text-slate-500 mt-1">${esc(c.profiles?.phone || 'لا يوجد رقم هاتف')}</p></div>`).join('') : '<p>ما كاش مرضى مرتبطين بحسابك حالياً.</p>';
  } catch (e) { const aEl = $('#therapist-agenda'), pEl = $('#therapist-patients'); if (aEl) aEl.textContent = 'تعذّر تحميل المواعيد. تأكد أن حساب المعالج مفعّل وصلاحيات قاعدة البيانات مضبوطة.'; if (pEl) pEl.textContent = 'تعذّر تحميل المرضى.'; }
}

/* ============================== VIEW: appointments ============================== */
let apptTab = 'up';
function apptCard(a) {
  const d = doc(a.doctorId), isUp = live(a);
  const status = a.status === 'cancelled' ? `<span class="text-xs font-bold text-rose-600 bg-rose-50 px-2.5 py-1 rounded-full">${esc(t('st_cancelled'))}</span>`
    : !isUp ? `<span class="text-xs font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-full">${esc(t('st_done'))}</span>`
    : `<span class="text-xs font-bold ${a.mode === 'video' ? 'text-teal-700 bg-teal-50' : 'text-slate-700 bg-slate-100'} px-2.5 py-1 rounded-full">${esc(modeLabel(a.mode))}</span>`;
  const actions = isUp ? `<div class="flex gap-2 pt-3 mt-3 border-t border-slate-100">
      ${a.mode === 'video' ? `<button type="button" data-act="go" data-v="telehealth" class="btn-primary !min-h-11 !py-2 flex-1 !text-sm">${esc(t('join'))}</button>` : ''}
      <button type="button" data-act="resched" data-id="${esc(a.id)}" class="btn-soft flex-1">${esc(t('resched'))}</button>
      <button type="button" data-act="cancel-appt" data-id="${esc(a.id)}" class="btn-danger">${esc(t('cancel_appt'))}</button></div>` : '';
  return `<div class="card">
    <div class="flex items-center justify-between gap-2 text-sm">${status}<span class="font-semibold text-slate-600">${esc(whenLabel(a))}</span></div>
    <div class="flex items-center gap-3 mt-3">
      <span class="size-12 rounded-xl bg-teal-100 text-teal-800 font-extrabold flex items-center justify-center shrink-0">${esc(d ? initials(d.name) : '?')}</span>
      <div class="min-w-0"><p class="font-bold text-slate-900 truncate">${esc(d ? d.name : '—')}</p>
        <p class="text-sm text-slate-500 truncate">${esc(d ? spLabel(d.specialty) : '')}</p></div>
    </div>
    ${a.reason ? `<p class="mt-3 text-sm text-slate-600 bg-slate-50 rounded-xl px-3 py-2 break-words">${esc(a.reason)}</p>` : ''}
    ${actions}</div>`;
}
function renderAppointments() {
  const el = $('#view-appointments');
  if (isGuest()) { el.innerHTML = `<h2 class="text-lg font-extrabold text-slate-900">${esc(t('appts_title'))}</h2>${gateCard()}`; return; }
  const list = apptTab === 'up' ? upcomingList() : pastList();
  el.innerHTML = `<h2 class="text-lg font-extrabold text-slate-900">${esc(t('appts_title'))}</h2>
    <div class="seg"><button type="button" data-act="appt-tab" data-tab="up" class="${apptTab === 'up' ? 'on' : ''}">${esc(t('tab_up'))}</button>
      <button type="button" data-act="appt-tab" data-tab="past" class="${apptTab === 'past' ? 'on' : ''}">${esc(t('tab_past'))}</button></div>
    ${list.length ? list.map(apptCard).join('') : emptyState(apptTab === 'up' ? t('empty_up') : t('empty_past'),
      apptTab === 'up' ? `<button type="button" data-act="new-booking" class="btn-primary mt-4">${esc(t('book_now'))}</button>` : '')}`;
}

/* ============================== VIEW: booking ============================== */
const bkDefault = () => ({ sp: 'all', q: '', doctorId: null, mode: 'video', date: '', time: '', reason: '', editId: null });
let bk = bkDefault();
function renderBooking() {
  const el = $('#view-booking');
  const sps = [...new Set(DOCTORS.map(d => d.specialty))];
  el.innerHTML = `<div><h2 class="text-lg font-extrabold text-slate-900">${esc(bk.editId ? t('resched_title') : t('book_title'))}</h2>
      <p class="text-sm text-slate-500">${esc(t('book_sub'))}</p></div>
    ${demoBanner()}
    <input id="bk-q" type="search" data-in="bk-q" class="field" placeholder="${esc(t('search_ph'))}" value="${esc(bk.q)}">
    <div class="flex gap-2 overflow-x-auto no-scrollbar -mx-4 px-4 pb-1" id="bk-sps">
      <button type="button" data-act="bk-sp" data-sp="all" class="chip ${bk.sp === 'all' ? 'on' : ''}">${esc(t('all'))}</button>
      ${sps.map(s => `<button type="button" data-act="bk-sp" data-sp="${esc(s)}" class="chip ${bk.sp === s ? 'on' : ''}">${esc(spLabel(s))}</button>`).join('')}</div>
    <div id="bk-doctors" class="space-y-2"></div>
    <div id="bk-form" class="space-y-4"></div>`;
  renderDoctors(); renderBkForm();
}
function renderDoctors() {
  const q = bk.q.trim().toLowerCase();
  const list = DOCTORS.filter(d => (bk.sp === 'all' || d.specialty === bk.sp) && (!q || (d.name + ' ' + spLabel(d.specialty)).toLowerCase().includes(q)));
  $('#bk-doctors').innerHTML = list.length ? list.map(d => `<button type="button" data-act="bk-doc" data-id="${esc(d.id)}" class="opt w-full flex items-center gap-3 ${bk.doctorId === d.id ? 'on' : ''}" aria-pressed="${bk.doctorId === d.id}">
      <span class="size-11 rounded-xl bg-teal-100 text-teal-800 font-extrabold flex items-center justify-center shrink-0">${esc(initials(d.name))}</span>
      <span class="min-w-0"><span class="block font-bold text-slate-900 truncate">${esc(d.name)}</span><span class="block text-sm font-medium text-slate-500 truncate">${esc(spLabel(d.specialty))}</span></span></button>`).join('')
    : emptyState(t('no_doctor'));
}
function renderBkForm() {
  const f = $('#bk-form'); if (!f) return;
  const d = doc(bk.doctorId);
  if (!d) { f.innerHTML = `<p class="text-sm text-slate-500 text-center py-2">${esc(t('pick_doctor'))}</p>`; return; }
  f.innerHTML = `
    <div><span class="lbl">${esc(t('consult_type'))}</span><div class="grid grid-cols-2 gap-2">
      ${['video', 'clinic'].map(m => d.modes.includes(m) ? `<button type="button" data-act="bk-mode" data-m="${m}" class="opt ${bk.mode === m ? 'on' : ''}" aria-pressed="${bk.mode === m}">${esc(modeLabel(m))}</button>` : '').join('')}</div></div>
    <div><label class="lbl" for="bk-date">${esc(t('date'))}</label>
      <input id="bk-date" type="date" data-in="bk-date" class="field" min="${todayStr()}" max="${addDays(todayStr(), CONFIG.maxDaysAhead)}" value="${esc(bk.date)}"></div>
    <div><span class="lbl">${esc(t('slots'))}</span><div id="bk-slots"></div></div>
    <div><label class="lbl" for="bk-reason">${esc(t('reason'))}</label>
      <textarea id="bk-reason" data-in="bk-reason" rows="3" maxlength="500" class="field" placeholder="${esc(t('reason_ph'))}">${esc(bk.reason)}</textarea></div>
    <p id="bk-msg" role="alert" class="hidden text-sm font-bold text-rose-600"></p>
    <button type="button" id="bk-confirm" data-act="bk-confirm" class="btn-primary w-full">${esc(bk.editId ? t('confirm_update') : t('confirm_book'))}</button>`;
  renderSlots();
}
function renderSlots() {
  const box = $('#bk-slots'); if (!box) return;
  const d = doc(bk.doctorId);
  const slots = availableSlots(d, bk.date, bk.editId);
  if (bk.time && !slots.includes(bk.time)) bk.time = '';
  box.innerHTML = slots.length ? `<div class="grid grid-cols-4 gap-2">${slots.map(s => `<button type="button" data-act="bk-slot" data-time="${s}" class="slot ${bk.time === s ? 'on' : ''}" aria-pressed="${bk.time === s}">${s}</button>`).join('')}</div>`
    : `<p class="text-sm text-slate-500">${esc(t('no_slots'))}</p>`;
}
const bkMsg = m => { const el = $('#bk-msg'); if (!el) return; el.textContent = m || ''; el.classList.toggle('hidden', !m); };
function startBooking(preset) {
  bk = Object.assign(bkDefault(), preset || {});
  go('booking');
  if (REMOTE && bk.doctorId) loadTaken(bk.doctorId).then(renderSlots).catch(() => {});
}
async function confirmBooking() {
  if (isGuest()) { bkMsg(''); return openSheet(sheetHead(t('gate_title')) + `<p class="text-sm text-slate-600 mb-4">${esc(t('gate_text'))}</p><button type="button" data-act="gate-register" class="btn-primary w-full">${esc(t('gate_btn'))}</button>`); }
  const d = doc(bk.doctorId);
  if (!d || !bk.date || !bk.time) return bkMsg(t('err_pick'));
  if (REMOTE) { try { await loadTaken(d.id); } catch (e) { return bkMsg(t('err_generic')); } }
  if (!availableSlots(d, bk.date, bk.editId).includes(bk.time)) { renderSlots(); return bkMsg(t('err_taken')); }
  if (data.appointments.some(a => a.status === 'booked' && a.id !== bk.editId && a.date === bk.date && a.time === bk.time)) return bkMsg(t('err_overlap'));
  const reason = bk.reason.trim().slice(0, 500);
  if (REMOTE) {
    try {
      if (bk.editId) {
        const a = data.appointments.find(x => x.id === bk.editId);
        if (a) {
          const patch = { doctor_id: d.id, date: bk.date, time: bk.time, mode: bk.mode, reason };
          if (bk.mode === 'video' && !a.room) patch.room = randHex(10);
          const rows = await api.updateAppointment(a.id, patch);
          Object.assign(a, mapAppt(rows[0]));
        }
        toast(t('book_updated'));
      } else {
        const row = await api.book({ patient_id: me.id, doctor_id: d.id, date: bk.date, time: bk.time, mode: bk.mode, reason, room: bk.mode === 'video' ? randHex(10) : null });
        data.appointments.push(mapAppt(row));
        toast(t('book_done'));
      }
    } catch (err) {
      if (err.code === '23505') { try { await loadTaken(d.id); } catch (e) { /* ignore */ } renderSlots(); return bkMsg(t('err_taken')); }   // someone booked it first
      return bkMsg(t('err_generic'));
    }
    bk = bkDefault(); apptTab = 'up'; return go('appointments');
  }
  if (bk.editId) {
    const a = data.appointments.find(x => x.id === bk.editId);
    if (a) { Object.assign(a, { doctorId: d.id, date: bk.date, time: bk.time, mode: bk.mode, reason }); if (a.mode === 'video' && !a.room) a.room = randHex(10); }
    toast(t('book_updated'));
  } else {
    data.appointments.push({ id: uid(), doctorId: d.id, date: bk.date, time: bk.time, mode: bk.mode, reason, status: 'booked', room: bk.mode === 'video' ? randHex(10) : null, createdAt: new Date().toISOString() });
    toast(t('book_done'));
  }
  saveData(); bk = bkDefault(); apptTab = 'up'; go('appointments');
}

/* ============================== VIEW: telehealth ============================== */
function renderTelehealth() {
  const el = $('#view-telehealth');
  const head = `<h2 class="text-lg font-extrabold text-slate-900">${esc(t('tele_title'))}</h2>`;
  if (isGuest()) { el.innerHTML = head + gateCard(); return; }
  const a = nextVideo();
  if (!a) { el.innerHTML = head + emptyState(t('tele_none'), `<button type="button" data-act="new-booking" data-mode="video" class="btn-primary mt-4">${esc(t('book_now'))}</button>`); return; }
  if (!a.room) { a.room = randHex(10); saveData(); }
  const d = doc(a.doctorId), st = joinState(a);
  el.innerHTML = head + `<div class="card space-y-4">
      <div class="flex items-center gap-3"><span class="size-14 rounded-2xl bg-teal-600 text-white font-extrabold flex items-center justify-center">${esc(d ? initials(d.name) : '?')}</span>
        <div class="min-w-0"><p class="font-bold text-slate-900 truncate">${esc(d ? d.name : '')}</p><p class="text-sm text-slate-500">${esc(whenLabel(a))}</p></div></div>
      <button type="button" data-act="join" data-id="${esc(a.id)}" class="btn-primary w-full" ${st === 'wait' ? 'disabled' : ''}>${esc(t('tele_join'))}</button>
      ${st === 'wait' ? `<p class="text-sm text-slate-500 text-center">${esc(t('tele_wait'))}</p>` : ''}
      <button type="button" data-act="copy-link" data-id="${esc(a.id)}" class="btn-soft w-full">${esc(t('tele_copy'))}</button>
    </div>
    <p class="text-sm text-slate-500 bg-sky-50 border border-sky-100 rounded-xl px-3 py-2.5">${esc(t('tele_info'))}</p>`;
}

/* ============================== VIEW: health ============================== */
let hTab = 'vitals', vType = 'hr';
const BLOOD = ['', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
function renderHealth() {
  const el = $('#view-health');
  const head = `<h2 class="text-lg font-extrabold text-slate-900">${esc(t('health_title'))}</h2>`;
  if (isGuest()) { el.innerHTML = head + gateCard(); return; }
  el.innerHTML = head + `<div class="seg"><button type="button" data-act="h-tab" data-tab="vitals" class="${hTab === 'vitals' ? 'on' : ''}">${esc(t('tab_vitals'))}</button>
      <button type="button" data-act="h-tab" data-tab="file" class="${hTab === 'file' ? 'on' : ''}">${esc(t('tab_file'))}</button></div>
    <div id="h-body" class="space-y-4"></div>
    <p class="text-xs text-slate-400 text-center px-2">${esc(t('medical_disclaimer'))}</p>`;
  hTab === 'vitals' ? renderVitals() : renderRecord();
}
function chartSvg(type) {
  const pts = data.vitals.filter(v => v.type === type).sort((a, b) => a.ts.localeCompare(b.ts)).slice(-10);
  if (pts.length < 2) return '';
  const series = type === 'bp' ? [[pts.map(p => p.a), 'text-sky-600'], [pts.map(p => p.b), 'text-sky-300']] : [[pts.map(p => p.a), VITAL_META[type].color]];
  const all = series.flatMap(s => s[0]); let lo = Math.min(...all), hi = Math.max(...all); if (lo === hi) { lo -= 1; hi += 1; }
  const W = 300, H = 90, P = 8, x = i => P + (i * (W - 2 * P)) / (pts.length - 1), y = v => H - P - ((v - lo) / (hi - lo)) * (H - 2 * P);
  const lines = series.map(([vals, cls]) => `<polyline class="${cls}" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" points="${vals.map((v, i) => `${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ')}"/>` +
    vals.map((v, i) => `<circle class="${cls}" cx="${x(i).toFixed(1)}" cy="${y(v).toFixed(1)}" r="3" fill="currentColor"/>`).join('')).join('');
  return `<div class="card"><div class="flex justify-between text-xs text-slate-400 mb-1"><span>${esc(t('trend'))}</span><span>${lo} – ${hi}</span></div>
    <svg viewBox="0 0 ${W} ${H}" class="w-full h-24" role="img" aria-label="${esc(t(VITAL_META[type].label))}" style="direction:ltr">${lines}</svg></div>`;
}
function renderVitals() {
  const m = VITAL_META[vType];
  const hist = data.vitals.slice().sort((a, b) => b.ts.localeCompare(a.ts)).slice(0, 20);
  $('#h-body').innerHTML = `
    <div class="card space-y-3">
      <div class="grid grid-cols-3 gap-2">${['hr', 'bp', 'glu'].map(k => `<button type="button" data-act="v-type" data-k="${k}" class="opt !px-2 !text-xs text-center ${vType === k ? 'on' : ''}" aria-pressed="${vType === k}">${esc(t(VITAL_META[k].label))}</button>`).join('')}</div>
      <form id="v-form" class="space-y-3" novalidate>
        ${vType === 'bp' ? `<div class="grid grid-cols-2 gap-2">
          <div><label class="lbl" for="v-a">${esc(t('v_sys'))}</label><input id="v-a" type="number" inputmode="numeric" class="field" placeholder="120"></div>
          <div><label class="lbl" for="v-b">${esc(t('v_dia'))}</label><input id="v-b" type="number" inputmode="numeric" class="field" placeholder="80"></div></div>`
        : `<div><label class="lbl" for="v-a">${esc(t('v_value'))} (${esc(t(m.unit))})</label><input id="v-a" type="number" inputmode="decimal" step="${vType === 'glu' ? '0.01' : '1'}" class="field" placeholder="${vType === 'glu' ? '0.95' : '72'}"></div>`}
        <p id="v-msg" role="alert" class="hidden text-sm font-bold text-rose-600"></p>
        <button type="submit" class="btn-primary w-full">${esc(t('v_add'))}</button>
      </form></div>
    ${chartSvg(vType)}
    <div><h3 class="text-sm font-extrabold text-slate-900 mb-2">${esc(t('history'))}</h3>
      ${hist.length ? `<div class="card !p-0 divide-y divide-slate-100">${hist.map(v => `<div class="flex items-center gap-3 px-4 py-2.5">
          <div class="flex-1 min-w-0"><p class="text-sm font-bold text-slate-800">${esc(t(VITAL_META[v.type].label))}: ${esc(vitalText(v))} <span class="font-medium text-slate-400">${esc(t(VITAL_META[v.type].unit))}</span></p>
            <p class="text-xs text-slate-400">${esc(fmtDateTime(v.ts))}</p></div>
          <button type="button" data-act="v-del" data-id="${esc(v.id)}" class="icon-btn" aria-label="${esc(t('common_delete'))}"><svg class="size-5 text-slate-400" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"/></svg></button></div>`).join('')}</div>`
      : emptyState(t('no_history'))}</div>`;
}
const RANGES = { hr: [20, 250], glu: [0.1, 6], sys: [50, 260], dia: [30, 160] };
function addVital() {
  const a = parseFloat($('#v-a').value.replace(',', '.')), bEl = $('#v-b'), b = bEl ? parseFloat(bEl.value) : null;
  const msg = $('#v-msg'), fail = () => { msg.textContent = t('err_range'); msg.classList.remove('hidden'); };
  const inR = (v, [lo, hi]) => Number.isFinite(v) && v >= lo && v <= hi;
  if (vType === 'bp') { if (!inR(a, RANGES.sys) || !inR(b, RANGES.dia) || a <= b) return fail(); }
  else if (!inR(a, RANGES[vType])) return fail();
  data.vitals.push({ id: uid(), type: vType, a: vType === 'glu' ? Math.round(a * 100) / 100 : Math.round(a), b: vType === 'bp' ? Math.round(b) : undefined, ts: new Date().toISOString() });
  saveData('vitals'); toast(t('v_added')); renderVitals(); updateNotifDot();
}
function renderRecord() {
  const r = data.record || {};
  const ta = (id, label, v) => `<div><label class="lbl" for="${id}">${esc(label)}</label><textarea id="${id}" rows="2" maxlength="600" class="field">${esc(v || '')}</textarea></div>`;
  $('#h-body').innerHTML = `<form id="rec-form" class="card space-y-4" novalidate>
    <div><label class="lbl" for="rec-blood">${esc(t('rec_blood'))}</label><select id="rec-blood" class="field">${BLOOD.map(b => `<option value="${b}" ${r.blood === b ? 'selected' : ''}>${b || '—'}</option>`).join('')}</select></div>
    ${ta('rec-allergies', t('rec_allergies'), r.allergies)}${ta('rec-conditions', t('rec_conditions'), r.conditions)}${ta('rec-meds', t('rec_meds'), r.meds)}
    <div class="grid grid-cols-1 gap-3">
      <div><label class="lbl" for="rec-ecn">${esc(t('rec_ec_name'))}</label><input id="rec-ecn" class="field" maxlength="80" value="${esc(r.ecName || '')}"></div>
      <div><label class="lbl" for="rec-ecp">${esc(t('rec_ec_phone'))}</label><input id="rec-ecp" type="tel" inputmode="tel" class="field" maxlength="20" value="${esc(r.ecPhone || '')}"></div></div>
    ${ta('rec-notes', t('rec_notes'), r.notes)}
    <button type="submit" class="btn-primary w-full">${esc(t('common_save'))}</button>
    <p class="text-xs text-slate-500 text-center">${esc(t('rec_note'))}</p></form>`;
}
function saveRecord() {
  data.record = { blood: $('#rec-blood').value, allergies: $('#rec-allergies').value.trim(), conditions: $('#rec-conditions').value.trim(), meds: $('#rec-meds').value.trim(),
    ecName: $('#rec-ecn').value.trim(), ecPhone: $('#rec-ecp').value.trim(), notes: $('#rec-notes').value.trim() };
  saveData('record'); toast(t('saved'));
}

/* ============================== VIEW: profile / settings ============================== */
function renderProfile() {
  const el = $('#view-profile');
  const row = (k, v) => `<div class="flex justify-between gap-3 py-3 border-b border-slate-100 last:border-0"><span class="text-sm text-slate-500">${esc(t(k))}</span><span class="text-sm font-semibold text-slate-800 text-end break-all">${esc(v || '—')}</span></div>`;
  if (isGuest()) {
    el.innerHTML = `<div class="card flex items-center gap-4"><img src="assets/avatars/avatar-1.svg" alt="" class="size-16 rounded-full border border-slate-200">
      <div><h2 class="font-extrabold text-slate-900">${esc(t('guest_name'))}</h2><p class="text-sm text-teal-700 font-medium">${esc(t('role_guest'))}</p></div></div>${gateCard()}
      <button type="button" data-act="go" data-v="settings" class="card w-full flex items-center justify-between text-sm font-bold text-slate-700">${esc(t('settings'))}<span class="flip-rtl">›</span></button>
      <button type="button" data-act="logout" class="btn-soft w-full">${esc(t('logout'))}</button>`;
    return;
  }
  el.innerHTML = `<div class="card flex items-center gap-4">
      <img src="assets/avatars/avatar-${esc(me.avatar || 1)}.svg" alt="" class="size-16 rounded-full object-cover border border-slate-200">
      <div class="min-w-0"><h2 class="font-extrabold text-slate-900 truncate">${esc(me.name)}</h2><p class="text-sm text-teal-700 font-medium">${me.role === 'doctor' ? esc(t('role_therapist')) : esc(t('role_patient'))}</p></div></div>
    <div class="card"><h3 class="text-sm font-extrabold text-slate-900 mb-1">${esc(t('personal'))}</h3>${row('fullname', me.name)}${row('phone', me.phone)}${row('email', me.email)}
      <button type="button" data-act="edit-profile" class="btn-soft w-full mt-3">${esc(t('edit_profile'))}</button></div>
    <button type="button" data-act="go" data-v="settings" class="card w-full flex items-center justify-between text-sm font-bold text-slate-700">${esc(t('settings'))}<span class="flip-rtl">›</span></button>
    <button type="button" data-act="logout" class="btn-soft w-full !text-rose-600">${esc(t('logout'))}</button>`;
}
let avatarPick = 1;
function openProfileEditor() {
  avatarPick = me.avatar || 1;
  openSheet(sheetHead(t('edit_profile')) + `<form id="p-form" class="space-y-4" novalidate>
    <div class="grid grid-cols-6 gap-2" id="avatars">${[1, 2, 3, 4, 5, 6].map(i => `<button type="button" data-act="avatar-pick" data-n="${i}" class="rounded-full p-0.5 border-2 ${i === avatarPick ? 'border-teal-600' : 'border-transparent'}" aria-label="Avatar ${i}"><img src="assets/avatars/avatar-${i}.svg" alt="" class="w-full aspect-square rounded-full"></button>`).join('')}</div>
    <div><label class="lbl" for="p-name">${esc(t('fullname'))}</label><input id="p-name" class="field" maxlength="80" value="${esc(me.name)}"></div>
    <div><label class="lbl" for="p-phone">${esc(t('phone'))}</label><input id="p-phone" type="tel" inputmode="tel" class="field" maxlength="20" value="${esc(me.phone)}"></div>
    <div><label class="lbl" for="p-email">${esc(t('email'))}</label><input id="p-email" class="field !bg-slate-100 text-slate-500" value="${esc(me.email)}" disabled><p class="text-xs text-slate-400 mt-1">${esc(t('email_locked'))}</p></div>
    <p id="p-msg" role="alert" class="hidden text-sm font-bold text-rose-600"></p>
    <button type="submit" class="btn-primary w-full">${esc(t('common_save'))}</button></form>`);
}
async function saveProfile() {
  const name = $('#p-name').value.trim(), phone = $('#p-phone').value.trim(), msg = $('#p-msg');
  if (name.length < 2) { msg.textContent = t('err_name'); msg.classList.remove('hidden'); return; }
  if (!PHONE_RE.test(phone)) { msg.textContent = t('err_phone'); msg.classList.remove('hidden'); return; }
  try { if (REMOTE) await api.saveProfile({ name, phone, avatar: avatarPick }); }
  catch (e) { msg.textContent = t('err_generic'); msg.classList.remove('hidden'); return; }
  Object.assign(me, { name, phone, avatar: avatarPick }); if (!REMOTE) { accounts[me.email] = me; saveAccounts(); }
  closeSheet(); renderView(current); toast(t('saved'));
}
function renderSettings() {
  const el = $('#view-settings');
  el.innerHTML = `<h2 class="text-lg font-extrabold text-slate-900">${esc(t('set_title'))}</h2>
    <div class="card space-y-2"><span class="lbl">${esc(t('language'))}</span>
      ${[['ar', 'العربية', '🇩🇿'], ['fr', 'Français', '🇫🇷'], ['en', 'English', '🇬🇧']].map(([k, n, f]) => `<button type="button" data-act="lang" data-l="${k}" class="opt w-full flex items-center justify-between ${lang === k ? 'on' : ''}" aria-pressed="${lang === k}"><span>${f} ${n}</span><span>${lang === k ? '✓' : ''}</span></button>`).join('')}</div>
    ${isGuest() ? '' : `<label class="card flex items-center justify-between gap-3 cursor-pointer"><span><span class="block text-sm font-bold text-slate-800">${esc(t('reminders'))}</span><span class="block text-xs text-slate-500 mt-0.5">${esc(t('reminders_desc'))}</span></span>
      <input id="set-rem" type="checkbox" class="size-6 accent-teal-600 shrink-0" ${data.prefs.reminders ? 'checked' : ''}></label>`}
    <button type="button" data-act="open-privacy" class="card w-full flex items-center justify-between text-sm font-bold text-slate-700">${esc(t('privacy'))}<span class="flip-rtl">›</span></button>
    ${isGuest() ? '' : `<button type="button" data-act="export" class="card w-full flex items-center justify-between text-sm font-bold text-slate-700">${esc(t('export'))}<span class="flip-rtl">›</span></button>
    <div class="card space-y-2 border-rose-200"><p class="text-sm font-bold text-rose-700">${esc(t('delete_acc'))}</p><p class="text-xs text-slate-500">${esc(t('delete_desc'))}</p>
      <button type="button" data-act="delete-open" class="btn-danger w-full">${esc(t('delete_acc'))}</button></div>`}
    <button type="button" data-act="logout" class="btn-soft w-full !text-rose-600">${esc(t('logout'))}</button>`;
}
function openPrivacy() {
  openSheet(sheetHead(t('priv_title')) + `<div class="space-y-4">${t('priv').map(([h, p]) => `<div><h4 class="font-bold text-slate-900 text-sm">${esc(h)}</h4><p class="text-sm text-slate-600 mt-1 leading-relaxed">${esc(p)}</p></div>`).join('')}
    ${CONFIG.contactEmail ? `<p class="text-sm text-slate-600">${esc(t('contact'))}: ${esc(CONFIG.contactEmail)}</p>` : ''}</div>`);
}
function openDelete() {
  openSheet(sheetHead(t('delete_acc')) + `<form id="del-form" class="space-y-4" novalidate><p class="text-sm text-slate-600">${esc(t('delete_desc'))}</p>
    <div><label class="lbl" for="del-pw">${esc(t('delete_pw'))}</label><input id="del-pw" type="password" autocomplete="current-password" class="field"></div>
    <p id="del-msg" role="alert" class="hidden text-sm font-bold text-rose-600"></p>
    <button type="submit" class="btn-danger w-full !bg-rose-600 !text-white">${esc(t('delete_btn'))}</button></form>`);
}
async function doDelete() {
  const pw = $('#del-pw').value, msg = $('#del-msg');
  if (REMOTE) {
    try { await SB.auth.signIn({ email: me.email, password: pw }); } catch (e) { msg.textContent = t('err_wrong_pw'); msg.classList.remove('hidden'); return; }
    try { await SB.db.rpc('delete_my_account'); } catch (e) { msg.textContent = t('err_generic'); msg.classList.remove('hidden'); return; }
    return endSession(t('deleted'));
  }
  try {
    if (!pw || !safeEq(await hashPw(pw, me.salt, me.iter), me.hash)) { msg.textContent = t('err_wrong_pw'); msg.classList.remove('hidden'); return; }
  } catch (e) { msg.textContent = t('err_generic'); msg.classList.remove('hidden'); return; }
  const email = me.email; delete accounts[email]; saveAccounts(); LS.del('data:' + email);
  endSession(t('deleted'));
}
function exportData() {
  const { salt, hash, iter, ...account } = me;
  const blob = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), account, data }, null, 2)], { type: 'application/json' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'sehati-data.json';
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

/* ============================== NOTIFICATIONS ============================== */
function reminderList() {
  if (isGuest() || !data.prefs.reminders) return [];
  const limit = Date.now() + 48 * 3600000;
  return upcomingList().filter(a => startOf(a).getTime() <= limit);
}
function updateNotifDot() { $('#notif-dot').classList.toggle('hidden', reminderList().length === 0); }
function openNotif() {
  const list = reminderList();
  const body = list.length ? `<div class="space-y-2">${list.map(a => { const d = doc(a.doctorId); return `<div class="rounded-xl bg-teal-50 border border-teal-100 px-3 py-3 text-sm font-semibold text-teal-900">${esc(t('notif_item', { doc: d ? d.name : '', when: whenLabel(a) }))}</div>`; }).join('')}</div>`
    : `<p class="text-sm text-slate-500 py-4 text-center">${esc(!isGuest() && !data.prefs.reminders ? t('notif_off') : t('notif_none'))}</p>`;
  openSheet(sheetHead(t('notif_title')) + body);
}

/* ============================== EVENTS ============================== */
const ACTIONS = {
  lang: d => applyLang(d.l),
  'auth-mode': d => authMode(d.m),
  'pending-back': () => { $('#therapist-pending-screen').classList.add('hidden'); $('#therapist-pending-screen').classList.remove('flex'); $('#auth').classList.remove('hidden'); selectedAuthRole = 'doctor'; authMode('login'); },
  'auth-role': d => { selectedAuthRole = d.role === 'doctor' ? 'doctor' : 'patient'; $('#role-patient').className = 'card !m-0 !p-4 text-center border-2 ' + (selectedAuthRole === 'patient' ? 'border-teal-600 bg-teal-50' : 'border-slate-200 bg-white'); $('#role-doctor').className = 'card !m-0 !p-4 text-center border-2 ' + (selectedAuthRole === 'doctor' ? 'border-indigo-600 bg-indigo-50' : 'border-slate-200 bg-white'); authMsg(''); authMode('login'); },
  guest: () => startSession({ guest: true }),
  go: d => { closeSheet(); go(d.v); },
  'new-booking': d => startBooking(d.mode ? { mode: d.mode } : null),
  'go-file': () => { hTab = 'file'; go('health'); },
  'go-vitals': () => { hTab = 'vitals'; go('health'); },
  'gate-register': () => { endSession(); authMode('register'); },
  logout: () => endSession(),
  'close-sheet': closeSheet,
  'open-notif': openNotif,
  'open-privacy': openPrivacy,
  'appt-tab': d => { apptTab = d.tab; renderAppointments(); },
  'cancel-appt': async d => {
    if (!confirm(t('confirm_cancel'))) return;
    const a = data.appointments.find(x => x.id === d.id);
    if (a) {
      try { if (REMOTE) await api.updateAppointment(a.id, { status: 'cancelled' }); a.status = 'cancelled'; saveData(); toast(t('cancelled_toast')); }
      catch (e) { netErr(); }
    }
    renderView(current);
  },
  resched: d => {
    const a = data.appointments.find(x => x.id === d.id); if (!a) return;
    startBooking({ editId: a.id, doctorId: a.doctorId, mode: a.mode, date: a.date, time: a.time, reason: a.reason || '', sp: 'all' });
  },
  join: d => { const a = data.appointments.find(x => x.id === d.id); if (a && a.room) window.open(roomUrl(a), '_blank', 'noopener'); },
  'copy-link': async d => {
    const a = data.appointments.find(x => x.id === d.id); if (!a) return;
    try { await navigator.clipboard.writeText(roomUrl(a)); toast(t('tele_copied')); } catch (e) { window.prompt(t('tele_copy'), roomUrl(a)); }
  },
  'bk-sp': d => { bk.sp = d.sp; $$('#bk-sps .chip').forEach(c => c.classList.toggle('on', c.dataset.sp === bk.sp)); renderDoctors(); },
  'bk-doc': async d => {
    bk.doctorId = d.id; const dc = doc(d.id);
    if (REMOTE) { try { await loadTaken(d.id); } catch (e) { netErr(); } }
    if (!dc.modes.includes(bk.mode)) bk.mode = dc.modes[0];
    if (!bk.date || !bk.editId) bk.date = firstAvailableDate(dc, bk.editId);
    bk.time = ''; renderDoctors(); renderBkForm();
  },
  'bk-mode': d => { bk.mode = d.m; renderBkForm(); },
  'bk-slot': d => { bk.time = d.time; renderSlots(); bkMsg(''); },
  'bk-confirm': confirmBooking,
  'h-tab': d => { hTab = d.tab; renderHealth(); },
  'v-type': d => { vType = d.k; renderVitals(); },
  'v-del': d => { data.vitals = data.vitals.filter(v => v.id !== d.id); saveData('vitals'); renderVitals(); },
  'edit-profile': openProfileEditor,
  'avatar-pick': d => { avatarPick = Number(d.n); $$('#avatars button').forEach(b => { b.classList.toggle('border-teal-600', b.dataset.n === d.n); b.classList.toggle('border-transparent', b.dataset.n !== d.n); }); },
  export: exportData,
  'delete-open': openDelete
};
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (el) { const fn = ACTIONS[el.dataset.act]; if (fn) fn(el.dataset); return; }
  if (e.target === $('#sheet')) closeSheet();
});
document.addEventListener('input', e => {
  const k = e.target.dataset && e.target.dataset.in;
  if (k === 'bk-q') { bk.q = e.target.value; renderDoctors(); }
  else if (k === 'bk-reason') bk.reason = e.target.value;
});
document.addEventListener('change', e => {
  const k = e.target.dataset && e.target.dataset.in;
  if (k === 'bk-date') { bk.date = e.target.value; bk.time = ''; renderSlots(); }
  else if (e.target.id === 'set-rem') { data.prefs.reminders = e.target.checked; saveData('prefs'); updateNotifDot(); }
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && !$('#sheet').classList.contains('hidden')) closeSheet();
  if (e.key === 'Enter' && e.target.id === 'dash-q') { e.preventDefault(); startBooking({ q: e.target.value }); }
});
document.addEventListener('submit', e => {
  const id = e.target.id;
  if (id === 'form-login') return doLogin(e);
  if (id === 'form-register') return doRegister(e);
  e.preventDefault();
  if (id === 'v-form') addVital();
  else if (id === 'rec-form') saveRecord();
  else if (id === 'p-form') saveProfile();
  else if (id === 'del-form') doDelete();
});

/* ============================== BOOT ============================== */
function boot() {
  applyLang(lang);
  authMode('login');
  const finish = () => {
    let p;
    if (session && session.email && (REMOTE ? SB.auth.user() : accounts[session.email])) p = startSession(session);
    else if (session && session.guest) p = startSession(session);
    else { session = null; $('#auth').classList.remove('hidden'); }
    Promise.resolve(p).finally(() => $('#splash').classList.add('hidden'));
  };
  setTimeout(finish, matchMedia('(prefers-reduced-motion: reduce)').matches ? 150 : 1300);
  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) navigator.serviceWorker.register('sw.js').catch(() => {});
}
document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', boot) : boot();
})();
