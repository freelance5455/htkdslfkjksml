/* sehati service worker: offline app shell (stale-while-revalidate). Bump VERSION on each release. */
const VERSION = 'sehati-v2';
const SHELL = ['./', 'index.html', 'app.js', 'backend.js', 'i18n.js', 'tailwind.css', 'manifest.webmanifest',
  'assets/icon-192.png', 'assets/icon-512.png', 'assets/icon-maskable-512.png',
  'assets/avatars/avatar-1.svg', 'assets/avatars/avatar-2.svg', 'assets/avatars/avatar-3.svg',
  'assets/avatars/avatar-4.svg', 'assets/avatars/avatar-5.svg', 'assets/avatars/avatar-6.svg'];
self.addEventListener('install', e => { e.waitUntil(caches.open(VERSION).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== location.origin) return;
  e.respondWith(caches.open(VERSION).then(async c => {
    const hit = await c.match(req, { ignoreSearch: true });
    const net = fetch(req).then(r => { if (r.ok) c.put(req, r.clone()); return r; }).catch(() => hit);
    return hit || net;
  }));
});
