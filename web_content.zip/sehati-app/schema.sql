-- sehati — Supabase schema (patients <-> doctors). شغّلو في Supabase > SQL Editor.
create extension if not exists pgcrypto;

-- ============ TABLES ============
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null default '',
  phone text not null default '',
  role text not null default 'patient' check (role in ('patient','doctor','admin')),
  avatar int not null default 1,
  prefs jsonb not null default '{"reminders":true}',
  created_at timestamptz not null default now()
);

create table public.doctors (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique not null references public.profiles(id) on delete cascade,
  name text not null,
  specialty text not null default 'general',
  modes text[] not null default '{video,clinic}',
  days int[] not null default '{0,1,2,3,4}',   -- 0=Sunday
  hours text[] not null default '{}',          -- ex: {09:00,09:30,...}
  active boolean not null default false,       -- يفعّلو الـ admin فقط
  created_at timestamptz not null default now()
);

create table public.appointments (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references public.profiles(id) on delete cascade,
  doctor_id uuid not null references public.doctors(id) on delete restrict,
  date date not null,
  time text not null,
  mode text not null check (mode in ('video','clinic')),
  reason text not null default '' check (char_length(reason) <= 500),
  status text not null default 'booked' check (status in ('booked','cancelled','done')),
  room text,
  created_at timestamptz not null default now()
);
-- يمنع مريضين يحجزو نفس الوقت مع نفس الطبيب
create unique index appt_slot_unique on public.appointments (doctor_id, date, time) where status = 'booked';
create index appt_patient_idx on public.appointments (patient_id, date);

create table public.care_links (
  patient_id uuid references public.profiles(id) on delete cascade,
  doctor_id uuid references public.doctors(id) on delete cascade,
  share_vitals boolean not null default false,   -- المريض هو اللي يفعّل
  share_record boolean not null default false,
  created_at timestamptz not null default now(),
  primary key (patient_id, doctor_id)
);

create table public.patient_vitals (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  vitals jsonb not null default '[]'
);
create table public.patient_records (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  record jsonb not null default '{}'
);

-- ============ HELPERS ============
create function public.my_role() returns text language sql stable security definer set search_path = public as
$$ select role from profiles where id = auth.uid() $$;

create function public.my_doctor_id() returns uuid language sql stable security definer set search_path = public as
$$ select id from doctors where user_id = auth.uid() $$;

-- يرجع الأوقات المحجوزة بدون ما يكشف هوية المرضى
create function public.taken_slots(p_doctor uuid, p_from date, p_to date)
returns table(date date, "time" text) language sql stable security definer set search_path = public as
$$ select a.date, a.time from appointments a
   where a.doctor_id = p_doctor and a.status = 'booked' and a.date between p_from and p_to $$;

-- ============ TRIGGERS ============
-- التسجيل: يسمح فقط بالاختيار بين patient وdoctor؛ لا يمكن إنشاء admin من بيانات التسجيل.
-- حساب المعالج يُنشأ غير مفعّل، وتبقى الموافقة النهائية بيد الإدارة.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
declare requested_role text;
begin
  requested_role := case when new.raw_user_meta_data->>'role' = 'doctor' then 'doctor' else 'patient' end;
  insert into profiles (id, name, phone, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'name',''), coalesce(new.raw_user_meta_data->>'phone',''), requested_role);
  if requested_role = 'doctor' then
    insert into doctors (user_id, name, specialty, active)
    values (new.id, coalesce(new.raw_user_meta_data->>'name',''), 'general', false)
    on conflict (user_id) do nothing;
  end if;
  return new;
end $$;
-- إذا كان المشغل موجودًا، CREATE OR REPLACE يحدّث الدالة فقط ولا ينشئ مشغلًا مكررًا.
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- المستخدم ما يقدرش يبدل role ولا الطبيب يفعّل روحو
create function public.protect_columns() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if coalesce(public.my_role(),'') <> 'admin' and auth.uid() is not null then
    if tg_table_name = 'profiles' and new.role is distinct from old.role then raise exception 'role is read-only'; end if;
    if tg_table_name = 'doctors' and (new.active is distinct from old.active or new.user_id is distinct from old.user_id) then raise exception 'active is admin-only'; end if;
  end if;
  return new;
end $$;
create trigger protect_profiles before update on public.profiles for each row execute function public.protect_columns();
create trigger protect_doctors before update on public.doctors for each row execute function public.protect_columns();

-- أول موعد = ينشأ الرابط مريض↔طبيب (بدون مشاركة بيانات حتى يوافق المريض)
create function public.link_on_appointment() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into care_links (patient_id, doctor_id) values (new.patient_id, new.doctor_id) on conflict do nothing;
  return new;
end $$;
create trigger appt_link after insert on public.appointments for each row execute function public.link_on_appointment();

-- ============ ROW LEVEL SECURITY ============
alter table public.profiles enable row level security;
alter table public.doctors enable row level security;
alter table public.appointments enable row level security;
alter table public.care_links enable row level security;
alter table public.patient_vitals enable row level security;
alter table public.patient_records enable row level security;

-- profiles
create policy p_self_select on profiles for select using (id = auth.uid() or my_role() = 'admin');
create policy p_doctor_sees_patients on profiles for select using (
  exists (select 1 from care_links c where c.patient_id = profiles.id and c.doctor_id = my_doctor_id()));
create policy p_self_update on profiles for update using (id = auth.uid()) with check (id = auth.uid());

-- doctors: القائمة العامة للمفعّلين، الطبيب يعدل ملفو، الـ admin يدير الكل
create policy d_public_select on doctors for select using (active or user_id = auth.uid() or my_role() = 'admin');
create policy d_self_update on doctors for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy d_admin_all on doctors for all using (my_role() = 'admin') with check (my_role() = 'admin');

-- appointments
create policy a_patient_select on appointments for select using (patient_id = auth.uid());
create policy a_patient_insert on appointments for insert with check (
  patient_id = auth.uid() and exists (select 1 from doctors d where d.id = doctor_id and d.active));
create policy a_patient_update on appointments for update using (patient_id = auth.uid()) with check (patient_id = auth.uid());
create policy a_doctor_select on appointments for select using (doctor_id = my_doctor_id());
create policy a_doctor_update on appointments for update using (doctor_id = my_doctor_id()) with check (doctor_id = my_doctor_id());

-- care_links
create policy c_patient_select on care_links for select using (patient_id = auth.uid());
create policy c_patient_update on care_links for update using (patient_id = auth.uid()) with check (patient_id = auth.uid());
create policy c_doctor_select on care_links for select using (doctor_id = my_doctor_id());

-- بيانات صحية: المالك دائما، الطبيب فقط إذا فعّل المريض المشاركة
create policy v_owner on patient_vitals for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy v_doctor on patient_vitals for select using (
  exists (select 1 from care_links c where c.patient_id = user_id and c.doctor_id = my_doctor_id() and c.share_vitals));
create policy r_owner on patient_records for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy r_doctor on patient_records for select using (
  exists (select 1 from care_links c where c.patient_id = user_id and c.doctor_id = my_doctor_id() and c.share_record));

grant execute on function public.taken_slots(uuid, date, date) to authenticated, anon;

-- ============ كيفاش تدير طبيب (يدوي، من SQL Editor) ============
-- 1) الطبيب يسجل كمريض عادي من التطبيق
-- 2) update profiles set role = 'doctor' where id = '<USER_ID>';
-- 3) insert into doctors (user_id, name, specialty, hours, active)
--    values ('<USER_ID>', 'Dr. ...', 'cardio', '{09:00,09:30,10:00}', true);
-- admin: update profiles set role = 'admin' where id = '<YOUR_USER_ID>';

-- ============ حذف الحساب (يستعملو زر "حذف الحساب" في التطبيق) ============
-- يحذف المستخدم من auth.users، والباقي (profiles, appointments, care_links, vitals, records) يتحذف بالـ cascade
create function public.delete_my_account() returns void language plpgsql security definer set search_path = public, auth as $$
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  delete from auth.users where id = auth.uid();
end $$;
revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;
