# sehati — صحتي

تطبيق ويب ثابت (PWA): index.html + app.js + i18n.js + tailwind.css. ما يحتاج سيرفر ولا CDN.

## تشغيل
    python3 -m http.server 8000     # ثم افتح http://localhost:8000
(لازم http://localhost أو HTTPS باش يخدم تشفير كلمات السر.)

## وين نعدل
- `app.js` أعلى الملف: `CONFIG` (بريد التواصل، رابط الفيديو، مدة الحجز) و `DOCTORS` (الأطباء الحقيقيين؛ احذف `demo:true`).
- `i18n.js`: كل النصوص بالعربية/الفرنسية/الإنجليزية.
- بعد تغيير أي class في HTML/JS: `npm i` ثم `npm run build:css`.
- عند كل إصدار: غيّر `VERSION` في `sw.js`.

## طبقة البيانات
كل التخزين في `LS` / `accounts` / `data` داخل `app.js` (localStorage). لاستبدالها بـ backend (مثلاً Supabase)
عوّض دوال `saveAccounts / saveData / loadUser / doLogin / doRegister` فقط.

## وضع Supabase (مرضى ↔ أطباء)
1. أنشئ مشروع Supabase وشغّل `schema.sql` في SQL Editor.
2. عمّر `SUPABASE_URL` و`SUPABASE_ANON_KEY` في أول `backend.js`. إذا بقاو فارغين التطبيق يخدم بـ localStorage كالقديم.
3. المرضى يسجلو من التطبيق. لتفعيل طبيب: اتبع التعليمات في آخر القسم الأول من `schema.sql` (تحويل role + إدخال سطر في `doctors` مع `hours` و`active=true`).
4. غيّر `VERSION` في `sw.js` عند كل إصدار (الحالي sehati-v2).
