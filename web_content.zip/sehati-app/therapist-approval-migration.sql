-- صحتي: طلبات تسجيل المعالج الوظيفي وموافقة الإدارة
-- شغّل هذا الملف مرة واحدة في Supabase > SQL Editor.
create table if not exists public.therapist_requests (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references public.profiles(id)
);

alter table public.therapist_requests enable row level security;

drop policy if exists therapist_request_read_own on public.therapist_requests;
create policy therapist_request_read_own on public.therapist_requests
  for select to authenticated using (user_id = auth.uid() or public.my_role() = 'admin');

drop policy if exists therapist_request_admin_update on public.therapist_requests;
create policy therapist_request_admin_update on public.therapist_requests
  for update to authenticated using (public.my_role() = 'admin')
  with check (public.my_role() = 'admin');

drop policy if exists therapist_request_admin_select on public.therapist_requests;
create policy therapist_request_admin_select on public.therapist_requests
  for select to authenticated using (public.my_role() = 'admin');

-- تسجيل المستخدم يبقى patient مهما كانت البيانات المرسلة من الواجهة.
-- إذا اختار معالج وظيفي، نسجل طلب مراجعة فقط ولا نفعّل صلاحياته.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, name, phone, role)
  values (new.id,
          coalesce(new.raw_user_meta_data->>'name',''),
          coalesce(new.raw_user_meta_data->>'phone',''),
          'patient');
  if coalesce(new.raw_user_meta_data->>'requested_role','') = 'doctor' then
    insert into public.therapist_requests (user_id, status)
    values (new.id, 'pending')
    on conflict (user_id) do nothing;
  end if;
  return new;
end $$;

-- بعد التحقق من الشهادات، يوافق المسؤول على الطلب باستعمال SQL:
-- update public.therapist_requests set status='approved', reviewed_at=now(),
-- reviewed_by='<ADMIN_USER_UUID>' where user_id='<THERAPIST_USER_UUID>';
-- ثم يفعّل الحساب ويضيف سجل المعالج:
-- update public.profiles set role='doctor' where id='<THERAPIST_USER_UUID>';
-- insert into public.doctors (user_id, name, specialty, active)
-- select id, name, 'general', false from public.profiles where id='<THERAPIST_USER_UUID>';
-- يجب على المسؤول فقط تنفيذ خطوات الموافقة أعلاه.
