# V29 — Supabase Banked Delete Fix

V29 changes Banked-entry deletion to use a Supabase PostgreSQL RPC instead of a client-side direct PATCH. This is more reliable with Supabase RLS and ensures the database recalculates the stored Banked total after deletion.

## Required Supabase step

1. Open your Supabase project.
2. Open **SQL Editor**.
3. Create a new query.
4. Copy and run the complete contents of **`delete-banked-entry.sql`**.
5. Refresh/reopen the app.

The SQL creates `public.delete_banked_entry(uuid, date, text)` and grants it to authenticated users. The function only permits the item's owner or an Admin to delete a Banked entry.

## What changed in V29

- Delete button is bound after every Balance-page render.
- Delete uses `supabase.rpc('delete_banked_entry', ...)`.
- The database function removes only the selected Banked entry for the current day.
- The `banked` total is recalculated from the remaining entries.
- Legacy single-value Banked records are supported.
- The app reloads the item from Supabase after successful deletion.
- The Android asset and web version use the same fix.
