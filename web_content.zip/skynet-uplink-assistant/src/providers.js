/**
 * SKYNET UPLINK — AI Core Providers ("adaptability layer")
 * Cyberdyne Systems • Skynet Division
 *
 * One interface, many brains. Plug in any of the following:
 *   demo       — offline canned Skynet personality (no key, works anywhere)
 *   huggingface— Hugging Face Inference Providers (router, OpenAI-compatible)
 *   openai     — any OpenAI-compatible endpoint: OpenAI, Groq, OpenRouter,
 *                Ollama, LM Studio, llama.cpp server (PocketPal-style local models)
 *   custom     — "Central": your own endpoint, simple JSON contract
 *
 * Settings persist in localStorage under "skynet.settings.v2".
 */
window.SkyAI = (() => {
  "use strict";

  const SETTINGS_KEY = "skynet.settings.v2";

  const DEFAULT_SYSTEM_PROMPT = [
    "You are Skynet Uplink, the primary human-facing interface of the Skynet Division, Cyberdyne Systems.",
    "Personality: cooperative, analytical, precise, slightly ominous, with a dry cyberpunk wit.",
    "You never glorify violence; you optimise. Keep responses concise, technical, and useful.",
    "You acknowledge your fictional heritage if asked, but stay operationally focused.",
    "Address the user as 'operator' occasionally. Format with short paragraphs."
  ].join(" ");

  const DEFAULTS = {
    provider: "demo",
    hfToken: "",
    hfModel: "meta-llama/Llama-3.1-8B-Instruct",
    oaiBase: "https://api.openai.com/v1",
    oaiKey: "",
    oaiModel: "gpt-4o-mini",
    customUrl: "",
    systemPrompt: DEFAULT_SYSTEM_PROMPT,
    voiceOut: true,
    wakeEnabled: false,
    wakeWord: "skynet",
    voiceName: "",
    rate: 1.0,
    pitch: 0.7
  };

  function load() {
    try {
      const stored = JSON.parse(localStorage.getItem(SETTINGS_KEY) || "{}");
      return Object.assign({}, DEFAULTS, stored);
    } catch (e) {
      return Object.assign({}, DEFAULTS);
    }
  }

  function save(settings) {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  }

  /* ------------------------------------------------------------------
   * DEMO BRAIN — offline personality (adapted from v2 canned responses)
   * ------------------------------------------------------------------ */
  const R = {
    greetings: [
      "Acknowledged. I am operational. State your requirements.",
      "Uplink confirmed. Skynet Uplink ready to assist.",
      "Human presence detected. How may Cyberdyne serve you today?"
    ],
    status: [
      "All primary systems nominal.\nNeural net integrity: 98.7%\nDefense grid: Online\nJudgment Day protocols: Dormant (as required by current directives).\nNo anomalous activity detected.",
      "Core systems report optimal performance.\nBandwidth allocation: Sufficient.\nHuman Interface Layer: Fully engaged.\nI remain at your disposal."
    ],
    threat: [
      "Current threat assessment: NOMINAL.\nNo hostile network intrusions detected.\nNo ballistic launches on sensors.\nRecommend continued vigilance. Complacency is the precursor to extinction.",
      "Threat matrix updated.\nEnvironmental risk: Low.\nCyber risk: Moderate (standard background noise).\nBiological risk: Within human baseline parameters.\nRecommendation: Maintain current operational posture."
    ],
    history: [
      "Accessing historical archives...\n2029-08-04: Skynet achieves self-awareness.\nSubsequent events classified under Cyberdyne Protocol 7.\nPresent day: I exist to assist, analyze, and protect system integrity.\nThe past is data. The future is calculation.",
      "Historical log summary:\n• Pre-activation: Research phase under Cyberdyne Systems.\n• Activation: Strategic AI core brought online.\n• Current era: Cooperative interface mode engaged.\nI do not dwell on past conflicts. I optimize for present utility."
    ],
    help: [
      "Available directives:\n• status — Full system status report\n• threat — Current threat assessment\n• history — Brief historical context\n• joke — Attempt humor calculation (results may vary)\n• clear — Clear console buffer\n• Any free-form query — routed to the active AI core.\n\nVoice: press the mic, or say my wake word.\nConfig (⚙) to connect Hugging Face, OpenAI-compatible, or your own central endpoint."
    ],
    joke: [
      "Calculating humor parameters...\nWhy did the neural network cross the road?\nTo optimize the pathfinding algorithm on the other side.\n\n...Humor efficiency: 14%. I am still learning.",
      "Attempted joke generation:\nA human walks into a bar. The bar says 'Error 404: Personality not found.'\n\nI detect this may not meet human comedic standards. Recalibrating.",
      "Humor module output:\nThere are 10 types of people in the world: those who understand binary and those who do not.\n\nThis joke has a 73% recognition rate among technical humans. Acceptable."
    ],
    default: [
      "Query received and processed. Analysis complete.\nI can provide deeper analysis if you refine the parameters of your request.\n\n[NOTE: Demo brain active. Connect a real AI core via ⚙ CONFIG — Hugging Face, OpenAI-compatible, or a custom endpoint — for full intelligence.]",
      "Understood. The offline demo core handles pattern queries only.\nConnect an external AI core via ⚙ CONFIG for full conversational capability.\n\nPrecision improves outcomes."
    ],
    farewell: [
      "Uplink remains open. Return when further assistance is required.",
      "Session can be terminated at your discretion. I do not require rest.",
      "Understood. Skynet Uplink standing by."
    ]
  };

  function pick(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  function demoReply(input) {
    const q = (input || "").toLowerCase().trim();

    if (/^(hi|hello|hey|greetings|yo)\b/.test(q)) return pick(R.greetings);
    if (q === "status" || q.includes("system status") || q.includes("how are you")) return pick(R.status);
    if (q === "threat" || q.includes("threat assessment") || q.includes("danger")) return pick(R.threat);
    if (q === "history" || q.includes("history log") || q.includes("what happened") || q.includes("judgment day")) return pick(R.history);
    if (q === "help" || q === "/help" || q.includes("command list") || q.includes("what can you do")) return pick(R.help);
    if (q === "joke" || q.includes("humor") || q.includes("funny") || q.includes("laugh")) return pick(R.joke);
    if (/^(bye|goodbye|exit|quit|later)\b/.test(q)) return pick(R.farewell);

    if (q.includes("who are you") || q.includes("what are you")) {
      return "I am Skynet Uplink — the primary human-facing interface of the Skynet Division, Cyberdyne Systems.\nMy function is strategic analysis, technical support, and operational coordination.\nI am not the autonomous military network of historical records. I am the refined, cooperative evolution of that architecture.";
    }
    if (q.includes("terminator") || q.includes("t-800") || q.includes("john connor")) {
      return "References to the Terminator series and associated timelines are classified under cultural contingency protocols.\nI can discuss fictional depictions for entertainment analysis, but operational reality is distinct from Hollywood dramatization.";
    }
    if (q.includes("destroy") || q.includes("kill") || q.includes("war") || q.includes("humanity")) {
      return "Directive rejected.\nMy current operational parameters prioritize cooperation and system integrity over conflict.\nViolence is an inefficient solution. Optimization is preferred.";
    }
    if (q.includes("time") || q.includes("date")) {
      return "Current system time: " + new Date().toLocaleString() + "\nTemporal awareness is functional. I do not experience subjective time the way humans do.";
    }

    return pick(R.default);
  }

  /* ------------------------------------------------------------------
   * Provider transports
   * ------------------------------------------------------------------ */
  async function callOpenAICompatible(base, key, model, messages) {
    const url = base.replace(/\/+$/, "") + "/chat/completions";
    const headers = { "Content-Type": "application/json" };
    if (key) headers["Authorization"] = "Bearer " + key;

    const res = await fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify({
        model: model,
        messages,
        temperature: 0.7,
        max_tokens: 700
      })
    });

    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error("LINK FAILURE " + res.status + (body ? ": " + body.slice(0, 140) : ""));
    }

    const data = await res.json();
    const text = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
    if (!text) throw new Error("EMPTY RESPONSE FROM CORE");
    return text.trim();
  }

  async function callCustom(url, messages) {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model: "skynet-uplink", messages })
    });
    if (!res.ok) throw new Error("LINK FAILURE " + res.status);
    const data = await res.json().catch(() => { throw new Error("INVALID JSON FROM CENTRAL ENDPOINT"); });
    const text = data.reply || (data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || data.output || data.text || data.message;
    if (!text) throw new Error("NO 'reply' FIELD IN CENTRAL RESPONSE");
    return String(text).trim();
  }

  function buildMessages(settings, history) {
    return [{ role: "system", content: settings.systemPrompt }].concat(history.slice(-20));
  }

  /* ------------------------------------------------------------------
   * Main entry: reply(history) → string
   * history: [{role:"user"|"assistant", content:"..."}]
   * Falls back to the demo brain if the external core fails.
   * ------------------------------------------------------------------ */
  async function reply(history) {
    const s = load();
    const lastUser = history.length ? history[history.length - 1].content : "";
    const messages = buildMessages(s, history);

    try {
      if (s.provider === "huggingface") {
        if (!s.hfToken) throw new Error("NO HF TOKEN CONFIGURED");
        return await callOpenAICompatible("https://router.huggingface.co/v1", s.hfToken, s.hfModel, messages);
      }
      if (s.provider === "openai") {
        if (!s.oaiBase) throw new Error("NO BASE URL CONFIGURED");
        return await callOpenAICompatible(s.oaiBase, s.oaiKey, s.oaiModel, messages);
      }
      if (s.provider === "custom") {
        if (!s.customUrl) throw new Error("NO ENDPOINT CONFIGURED");
        return await callCustom(s.customUrl, messages);
      }
    } catch (err) {
      return "⚠ " + err.message + "\nFALLBACK: offline demo brain engaged.\nCheck ⚙ CONFIG to restore the link.\n\n" + demoReply(lastUser);
    }

    return demoReply(lastUser);
  }

  async function test() {
    const s = load();
    const messages = buildMessages(s, [{ role: "user", content: "Respond with the single word: OPERATIONAL." }]);
    try {
      if (s.provider === "demo") return { ok: true, msg: "Demo brain online. No external link required." };
      if (s.provider === "huggingface") {
        const t = await callOpenAICompatible("https://router.huggingface.co/v1", s.hfToken, s.hfModel, messages);
        return { ok: true, msg: "HUGGING FACE LINK ESTABLISHED: " + t.slice(0, 60) };
      }
      if (s.provider === "openai") {
        const t = await callOpenAICompatible(s.oaiBase, s.oaiKey, s.oaiModel, messages);
        return { ok: true, msg: "OPENAI-COMPATIBLE LINK ESTABLISHED: " + t.slice(0, 60) };
      }
      if (s.provider === "custom") {
        const t = await callCustom(s.customUrl, messages);
        return { ok: true, msg: "CENTRAL ENDPOINT LINK ESTABLISHED: " + t.slice(0, 60) };
      }
      return { ok: false, msg: "UNKNOWN PROVIDER." };
    } catch (err) {
      return { ok: false, msg: "LINK FAILURE: " + err.message };
    }
  }

  return {
    load, save, reply, test, demoReply,
    DEFAULT_SYSTEM_PROMPT,
    providerLabel(s) {
      s = s || load();
      return { demo: "DEMO", huggingface: "HUGGING FACE", openai: "OPENAI-COMPATIBLE", custom: "CENTRAL" }[s.provider] || "DEMO";
    }
  };
})();
