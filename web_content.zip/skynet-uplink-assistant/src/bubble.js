/**
 * SKYNET UPLINK — Floating Bubble (chat-head overlay)
 * Draggable overlay bubble that minimizes/restores the whole interface,
 * Google-Assistant style. Position persists; supports ?bubble=1 embed mode.
 */
window.SkyBubble = (() => {
  "use strict";

  const POS_KEY = "skynet.bubble.pos";
  const el = document.getElementById("bubble");
  const badge = document.getElementById("bubble-badge");
  if (!el) return { minimize() {}, restore() {}, toggle() {}, notify() {} };

  let unread = 0;

  /* -------- position -------- */
  function loadPos() {
    try {
      const p = JSON.parse(localStorage.getItem(POS_KEY) || "null");
      if (p && typeof p.left === "number" && typeof p.top === "number") return p;
    } catch (e) {}
    return {
      left: window.innerWidth - 96,
      top: window.innerHeight - 116
    };
  }

  function clamp(left, top) {
    const size = document.body.classList.contains("minimized") ? 96 : 64;
    left = Math.max(8, Math.min(left, window.innerWidth - size - 8));
    top = Math.max(8, Math.min(top, window.innerHeight - size - 8));
    return { left, top };
  }

  function applyPos(p) {
    const c = clamp(p.left, p.top);
    el.style.left = c.left + "px";
    el.style.top = c.top + "px";
  }

  applyPos(loadPos());

  /* -------- drag vs click -------- */
  let dragStart = null;
  let moved = false;

  el.addEventListener("pointerdown", (e) => {
    dragStart = { x: e.clientX, y: e.clientY, left: el.offsetLeft, top: el.offsetTop };
    moved = false;
    el.setPointerCapture(e.pointerId);
  });

  el.addEventListener("pointermove", (e) => {
    if (!dragStart) return;
    const dx = e.clientX - dragStart.x;
    const dy = e.clientY - dragStart.y;
    if (Math.abs(dx) > 6 || Math.abs(dy) > 6) {
      moved = true;
      el.classList.add("dragging");
      applyPos({ left: dragStart.left + dx, top: dragStart.top + dy });
    }
  });

  el.addEventListener("pointerup", (e) => {
    el.classList.remove("dragging");
    if (dragStart && !moved) toggle();
    if (dragStart && moved) {
      const p = clamp(el.offsetLeft, el.offsetTop);
      applyPos(p);
      localStorage.setItem(POS_KEY, JSON.stringify(p));
    }
    dragStart = null;
    try { el.releasePointerCapture(e.pointerId); } catch (err) {}
  });

  window.addEventListener("resize", () => {
    applyPos({ left: el.offsetLeft, top: el.offsetTop });
  });

  /* -------- minimize / restore -------- */
  function minimize() {
    document.body.classList.add("minimized");
    applyPos({ left: el.offsetLeft, top: el.offsetTop });
  }

  function restore() {
    document.body.classList.remove("minimized");
    unread = 0;
    if (badge) { badge.hidden = true; badge.textContent = "0"; }
    applyPos({ left: el.offsetLeft, top: el.offsetTop });
  }

  function toggle() {
    if (document.body.classList.contains("minimized")) restore();
    else minimize();
  }

  function notify() {
    if (document.body.classList.contains("minimized")) {
      unread++;
      if (badge) {
        badge.textContent = unread > 9 ? "9+" : String(unread);
        badge.hidden = false;
      }
    }
  }

  /* Embed mode: start minimized (e.g. iframed over another site) */
  if (new URLSearchParams(location.search).get("bubble") === "1") {
    minimize();
  }

  return { minimize, restore, toggle, notify };
})();
