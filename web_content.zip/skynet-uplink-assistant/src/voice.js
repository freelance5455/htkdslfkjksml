/**
 * SKYNET UPLINK — Voice Engine
 * Google-Assistant-style voice I/O using the browser's speech services:
 *   - SpeechRecognition (Chrome/Edge use Google's voice services)
 *   - speechSynthesis for spoken replies (Skynet voice preset)
 *   - Optional always-on wake word mode ("skynet ...")
 */
window.SkyVoice = (() => {
  "use strict";

  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const sttSupported = !!SR;
  const ttsSupported = !!window.speechSynthesis;

  let rec = null;
  let mode = null;            // null | "capture" | "wake"
  let wakeConfig = null;      // { word, onWake, onInterim }
  let captureConfig = null;   // { onInterim, onFinal, onError }
  let speakChain = Promise.resolve();

  /* ---------------- Recognition ---------------- */

  function ensureRec() {
    if (!sttSupported) return null;
    if (!rec) {
      rec = new SR();
      rec.lang = "en-US";
      rec.interimResults = true;
      rec.continuous = false;
      rec.maxAlternatives = 1;

      rec.onresult = (e) => {
        let interim = "";
        let final = "";
        for (let i = e.resultIndex; i < e.results.length; i++) {
          const r = e.results[i];
          if (r.isFinal) final += r[0].transcript;
          else interim += r[0].transcript;
        }

        if (mode === "wake" && wakeConfig) {
          const heard = (final + " " + interim).toLowerCase();
          const word = (wakeConfig.word || "").toLowerCase().trim();
          if (!word) return;
          const idx = heard.indexOf(word);
          if (idx !== -1) {
            // Everything after the wake word becomes the directive.
            const afterRaw = (final + " " + interim).slice(idx + word.length).trim();
            const after = afterRaw.replace(/^[,.!?\s]+/, "");
            const cfg = wakeConfig;
            stopAll();
            cfg.onWake(after);
          }
        }

        if (mode === "capture" && captureConfig) {
          if (interim && captureConfig.onInterim) captureConfig.onInterim(interim);
          if (final && captureConfig.onFinal) captureConfig.onFinal(final.trim());
        }
      };

      rec.onerror = (e) => {
        const err = e.error;
        if (mode === "capture" && captureConfig && captureConfig.onError) {
          if (err !== "aborted" && err !== "no-speech") captureConfig.onError(err);
        }
        if (err === "not-allowed" || err === "service-not-allowed") {
          // Microphone denied: kill wake mode entirely.
          mode = null;
        }
      };

      rec.onend = () => {
        if (mode === "wake") {
          // Always-listening loop: restart quietly.
          try { rec.start(); } catch (e) { /* already started */ }
        } else if (mode === "capture" && captureConfig) {
          // One-shot capture finished.
          const cfg = captureConfig;
          mode = null;
          captureConfig = null;
          if (cfg.onEnd) cfg.onEnd();
        }
      };
    }
    return rec;
  }

  /** One-shot dictation. Returns a stop() handle. */
  function capture({ onInterim, onFinal, onEnd, onError }) {
    if (!sttSupported) return { supported: false, stop: () => {} };
    const r = ensureRec();
    mode = "capture";
    captureConfig = { onInterim, onFinal, onEnd, onError };
    r.continuous = false;
    try { r.start(); } catch (e) { /* already running */ }
    return {
      supported: true,
      stop() {
        mode = null;
        captureConfig = null;
        try { r.stop(); } catch (e) {}
      }
    };
  }

  /** Always-on wake word listening. Auto-restarts until stopWake(). */
  function startWake({ word, onWake }) {
    if (!sttSupported) return false;
    const r = ensureRec();
    mode = "wake";
    wakeConfig = { word, onWake };
    r.continuous = true;
    try { r.start(); } catch (e) {}
    return true;
  }

  function stopAll() {
    mode = null;
    captureConfig = null;
    wakeConfig = null;
    if (rec) { try { rec.stop(); } catch (e) {} }
  }

  /* ---------------- Synthesis ---------------- */

  function getVoices() {
    if (!ttsSupported) return [];
    return window.speechSynthesis.getVoices() || [];
  }

  function pickVoice(list, preferredName) {
    if (preferredName) {
      const m = list.find((v) => v.name === preferredName);
      if (m) return m;
    }
    // Skynet voice preference: deep English male.
    const prefs = ["Google UK English Male", "Microsoft Ryan", "Microsoft Guy", "Daniel", "Alex", "Google US English"];
    for (const p of prefs) {
      const m = list.find((v) => v.name.indexOf(p) !== -1);
      if (m) return m;
    }
    return list.find((v) => (v.lang || "").indexOf("en") === 0) || list[0] || null;
  }

  function chunkText(text) {
    // Split into sentence-bounded chunks so long replies speak reliably.
    const sentences = text.replace(/\s+/g, " ").match(/[^.!?]+[.!?]*\s*/g) || [text];
    const chunks = [];
    let cur = "";
    for (const s of sentences) {
      if ((cur + s).length > 220 && cur) { chunks.push(cur.trim()); cur = s; }
      else cur += s;
    }
    if (cur.trim()) chunks.push(cur.trim());
    return chunks.filter(Boolean).slice(0, 8); // cap: ~8 chunks per reply
  }

  /** Speak text aloud. Serializes utterances; cancels previous queue. */
  let speakGen = 0;

  function speak(text, { voiceName, rate, pitch, onStart, onEnd } = {}) {
    if (!ttsSupported || !text) {
      if (onEnd) onEnd();
      return;
    }
    // Generation token: a new speak() invalidates any chain still running.
    const gen = ++speakGen;
    window.speechSynthesis.cancel();
    const clean = text.replace(/[⚠•]/g, "").replace(/[*_`#]/g, "");
    const chunks = chunkText(clean);
    const voices = getVoices();
    const voice = pickVoice(voices, voiceName);
    let i = 0;

    if (onStart) onStart();
    if (!chunks.length) { if (onEnd) onEnd(); return; }

    speakChain = speakChain.then(() => new Promise((resolve) => {
      const speakNext = () => {
        if (gen !== speakGen) { resolve(); return; } // superseded by a newer speak()
        if (i >= chunks.length) { resolve(); if (onEnd) onEnd(); return; }
        const u = new SpeechSynthesisUtterance(chunks[i++]);
        if (voice) u.voice = voice;
        u.rate = rate || 1.0;
        u.pitch = pitch || 0.7;
        u.onend = speakNext;
        u.onerror = speakNext;
        window.speechSynthesis.speak(u);
      };
      speakNext();
    }));
  }

  function cancelSpeak() {
    if (ttsSupported) window.speechSynthesis.cancel();
  }

  return {
    sttSupported,
    ttsSupported,
    capture,
    startWake,
    stopAll,
    speak,
    cancelSpeak,
    getVoices
  };
})();
