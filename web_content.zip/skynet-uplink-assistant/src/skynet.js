/**
 * SKYNET UPLINK — Core Interface Logic
 * Cyberdyne Systems • Skynet Division
 *
 * v3.0: adaptive AI core (SkyAI), voice I/O (SkyVoice), floating bubble (SkyBubble).
 */
(() => {
  "use strict";

  const chatWindow = document.getElementById("chat-window");
  const userInput = document.getElementById("user-input");
  const sendBtn = document.getElementById("send-btn");
  const micBtn = document.getElementById("mic-btn");
  const logStream = document.getElementById("log-stream");
  const clockEl = document.getElementById("clock");
  const coreTemp = document.getElementById("core-temp");
  const sessionId = document.getElementById("session-id");
  const wave = document.getElementById("wave");
  const voiceOverlay = document.getElementById("voice-overlay");
  const voiceOverlayText = document.getElementById("voice-overlay-text");

  const settingsBtn = document.getElementById("btn-settings");
  const minimizeBtn = document.getElementById("btn-minimize");
  const talkBtn = document.getElementById("btn-talk");
  const talkBtnLabel = document.getElementById("btn-talk-label");
  const wakeBtn = document.getElementById("btn-wake");
  const wakeBtnLabel = document.getElementById("btn-wake-label");
  const wakeWordEcho = document.getElementById("wake-word-echo");
  const voiceSupport = document.getElementById("voice-support");
  const idProvider = document.getElementById("id-provider");
  const idVoice = document.getElementById("id-voice");
  const coreProviderLabel = document.getElementById("core-provider-label");

  // Conversation history for AI cores
  const history = [];
  let busy = false;
  let micSession = null; // active capture handle
  let overlayActive = false;

  sessionId.textContent = "SESSION-" + Math.floor(Math.random() * 9000 + 1000);

  /* ---------------- Clock & telemetry ---------------- */
  function updateClock() {
    clockEl.textContent = new Date().toTimeString().slice(0, 8);
  }
  setInterval(updateClock, 1000);
  updateClock();

  function driftTelemetry() {
    const bars = [
      { id: "neural-bar", val: "neural-val", min: 45, max: 88 },
      { id: "bw-bar", val: "bw-val", min: 60, max: 95 },
      { id: "def-bar", val: "def-val", min: 85, max: 99 },
      { id: "hum-bar", val: "hum-val", min: 30, max: 55 }
    ];
    bars.forEach((b) => {
      const v = Math.floor(Math.random() * (b.max - b.min) + b.min);
      document.getElementById(b.id).style.width = v + "%";
      document.getElementById(b.val).textContent = v + "%";
    });
    coreTemp.textContent = (36 + Math.random() * 4).toFixed(1) + "°C";
  }
  setInterval(driftTelemetry, 4000);

  /* ---------------- Logging ---------------- */
  function addLog(msg) {
    const line = document.createElement("div");
    line.className = "log-line";
    line.textContent = "> " + msg;
    logStream.appendChild(line);
    logStream.scrollTop = logStream.scrollHeight;
    while (logStream.children.length > 14) {
      logStream.removeChild(logStream.firstChild);
    }
  }

  /* ---------------- Messages ---------------- */
  function addMessage(sender, text, isUser = false) {
    const msg = document.createElement("div");
    msg.className = "message " + (isUser ? "user" : "skynet");

    const header = document.createElement("div");
    header.className = "msg-header";
    header.innerHTML = `
      <span class="sender ${isUser ? "user" : "skynet"}">${sender}</span>
      <span class="timestamp">${new Date().toTimeString().slice(0, 8)}</span>
    `;

    const body = document.createElement("div");
    body.className = "msg-body";
    text.split("\n").forEach((p) => {
      if (p.trim()) {
        const para = document.createElement("p");
        para.textContent = p;
        body.appendChild(para);
      }
    });

    msg.appendChild(header);
    msg.appendChild(body);
    chatWindow.appendChild(msg);
    chatWindow.scrollTop = chatWindow.scrollHeight;
  }

  function showTyping() {
    const typing = document.createElement("div");
    typing.className = "message skynet";
    typing.id = "typing-indicator";
    typing.innerHTML = `
      <div class="msg-header">
        <span class="sender skynet">SKYNET</span>
        <span class="timestamp">PROCESSING</span>
      </div>
      <div class="msg-body"><p>Analyzing query<span class="dots">...</span></p></div>
    `;
    chatWindow.appendChild(typing);
    chatWindow.scrollTop = chatWindow.scrollHeight;
  }

  function hideTyping() {
    const t = document.getElementById("typing-indicator");
    if (t) t.remove();
  }

  /* ---------------- Transmit pipeline ---------------- */
  async function transmit(text, opts = {}) {
    text = (text || "").trim();
    if (!text || busy) return;
    busy = true;

    addMessage("OPERATOR", text, true);
    addLog('Query received: "' + text.slice(0, 40) + (text.length > 40 ? "…" : "") + '"');
    history.push({ role: "user", content: text });
    userInput.value = "";
    userInput.classList.remove("interim");

    showTyping();
    addLog("Neural processing initiated... // core: " + SkyAI.providerLabel());

    let reply;
    try {
      reply = await SkyAI.reply(history);
    } catch (e) {
      reply = "⚠ CORE ERROR: " + e.message;
    }

    hideTyping();
    addMessage("SKYNET", reply);
    addLog("Response transmitted.");
    history.push({ role: "assistant", content: reply });
    busy = false;

    // Voice output
    const s = SkyAI.load();
    if (s.voiceOut) {
      idVoice.textContent = "SPEAKING";
      SkyVoice.speak(reply, {
        voiceName: s.voiceName,
        rate: s.rate,
        pitch: s.pitch,
        onEnd: () => { idVoice.textContent = wakeActive() ? "LISTENING" : "STANDBY"; }
      });
    }

    // Bubble notification if minimized
    if (typeof SkyBubble !== "undefined" && SkyBubble.notify) SkyBubble.notify();

    // Resume wake listening after a voice-initiated exchange
    if (opts.fromVoice && wakeActive()) {
      // already restarted below via ensureWake
    }
    ensureWake();
  }

  /* ---------------- Voice input ---------------- */
  function sttReady() { return SkyVoice.sttSupported; }

  function startMicSession() {
    if (!sttReady()) {
      addLog("Voice recognition unsupported in this browser. Use Chrome or Edge.");
      return;
    }
    closeVoiceOverlay();
    SkyVoice.stopAll();
    micSession = SkyVoice.capture({
      onInterim: (t) => {
        userInput.value = t;
        userInput.classList.add("interim");
        if (overlayActive) voiceOverlayText.textContent = t.toUpperCase();
      },
      onFinal: (t) => {
        if (t.toLowerCase().trim() === "cancel") {
          addLog("Voice directive aborted by operator.");
          endMicSession();
          return;
        }
        endMicSession();
        transmit(t, { fromVoice: true });
      },
      onError: (err) => {
        addLog("Voice error: " + err);
        endMicSession();
      }
    });
    micBtn.classList.add("active");
    talkBtn.classList.add("listening");
    talkBtnLabel.textContent = "LISTENING...";
    wave.hidden = false;
    addLog("Voice input channel open.");
  }

  function endMicSession() {
    if (micSession && micSession.stop) micSession.stop();
    micSession = null;
    micBtn.classList.remove("active");
    talkBtn.classList.remove("listening");
    talkBtnLabel.textContent = "TALK TO SKYNET";
    wave.hidden = true;
    userInput.classList.remove("interim");
    closeVoiceOverlay();
    ensureWake();
  }

  micBtn.addEventListener("click", () => {
    if (micSession) endMicSession();
    else startMicSession();
  });
  talkBtn.addEventListener("click", () => {
    if (micSession) endMicSession();
    else startMicSession();
  });

  /* Fullscreen listening overlay */
  function openVoiceOverlay() {
    overlayActive = true;
    voiceOverlayText.textContent = "LISTENING...";
    voiceOverlay.hidden = false;
  }
  function closeVoiceOverlay() {
    overlayActive = false;
    voiceOverlay.hidden = true;
  }
  voiceOverlay.addEventListener("click", () => {
    endMicSession();
    addLog("Voice overlay dismissed.");
  });

  /* ---------------- Wake word ---------------- */
  function wakeActive() {
    return wakeBtn.classList.contains("on");
  }

  function ensureWake() {
    const s = SkyAI.load();
    if (wakeActive() && s.wakeEnabled && !micSession && !busy) {
      SkyVoice.stopAll();
      SkyVoice.startWake({
        word: s.wakeWord,
        onWake: (payload) => {
          addLog('Wake word detected: "' + s.wakeWord + '"');
          if (payload) {
            transmit(payload, { fromVoice: true });
          } else {
            idVoice.textContent = "LISTENING";
            startMicSession();
            openVoiceOverlay();
          }
        }
      });
    }
  }

  wakeBtn.addEventListener("click", () => {
    const s = SkyAI.load();
    if (!sttReady()) {
      addLog("Wake word requires Chrome/Edge speech services.");
      return;
    }
    if (wakeActive()) {
      s.wakeEnabled = false;
      SkyAI.save(s);
      wakeBtn.classList.remove("on");
      wakeBtnLabel.textContent = "WAKE WORD: STANDBY";
      SkyVoice.stopAll();
      idVoice.textContent = "STANDBY";
      addLog("Wake word listening disengaged.");
    } else {
      s.wakeEnabled = true;
      SkyAI.save(s);
      wakeBtn.classList.add("on");
      wakeBtnLabel.textContent = 'WAKE WORD: "' + (s.wakeWord || "skynet").toUpperCase() + '"';
      idVoice.textContent = "LISTENING";
      addLog('Wake word listening engaged. Say "' + s.wakeWord + '".');
      ensureWake();
    }
    refreshWakeEcho();
  });

  function refreshWakeEcho() {
    if (wakeWordEcho) wakeWordEcho.textContent = SkyAI.load().wakeWord || "skynet";
  }

  /* ---------------- Settings modal ---------------- */
  const modal = document.getElementById("settings-modal");
  const cfg = {
    provider: document.getElementById("cfg-provider"),
    hfBox: document.getElementById("cfg-box-hf"),
    oaiBox: document.getElementById("cfg-box-oai"),
    customBox: document.getElementById("cfg-box-custom"),
    hfToken: document.getElementById("cfg-hf-token"),
    hfModel: document.getElementById("cfg-hf-model"),
    oaiBase: document.getElementById("cfg-oai-base"),
    oaiKey: document.getElementById("cfg-oai-key"),
    oaiModel: document.getElementById("cfg-oai-model"),
    customUrl: document.getElementById("cfg-custom-url"),
    voiceOut: document.getElementById("cfg-voice-out"),
    wake: document.getElementById("cfg-wake"),
    wakeWord: document.getElementById("cfg-wake-word"),
    voiceName: document.getElementById("cfg-voice-name"),
    rate: document.getElementById("cfg-rate"),
    pitch: document.getElementById("cfg-pitch"),
    rateVal: document.getElementById("cfg-rate-val"),
    pitchVal: document.getElementById("cfg-pitch-val"),
    systemPrompt: document.getElementById("cfg-system-prompt"),
    testBtn: document.getElementById("cfg-test"),
    testResult: document.getElementById("cfg-test-result"),
    saveBtn: document.getElementById("settings-save"),
    closeBtn: document.getElementById("settings-close"),
    personaReset: document.getElementById("cfg-persona-reset")
  };

  settingsBtn.addEventListener("click", openSettings);
  minimizeBtn.addEventListener("click", () => SkyBubble.minimize());
  cfg.closeBtn.addEventListener("click", closeSettings);
  modal.addEventListener("click", (e) => {
    if (e.target === modal) closeSettings();
  });

  function openSettings() {
    const s = SkyAI.load();
    cfg.provider.value = s.provider;
    cfg.hfToken.value = s.hfToken;
    cfg.hfModel.value = s.hfModel;
    cfg.oaiBase.value = s.oaiBase;
    cfg.oaiKey.value = s.oaiKey;
    cfg.oaiModel.value = s.oaiModel;
    cfg.customUrl.value = s.customUrl;
    cfg.voiceOut.checked = s.voiceOut;
    cfg.wake.checked = s.wakeEnabled;
    cfg.wakeWord.value = s.wakeWord;
    cfg.systemPrompt.value = s.systemPrompt;
    cfg.rate.value = s.rate;
    cfg.pitch.value = s.pitch;
    cfg.rateVal.textContent = s.rate.toFixed(2);
    cfg.pitchVal.textContent = s.pitch.toFixed(2);

    // Voice list
    populateVoices(s.voiceName);
    if (window.speechSynthesis) {
      window.speechSynthesis.onvoiceschanged = () => populateVoices(cfg.voiceName.value);
    }

    updateProviderBoxes();
    modal.hidden = false;
  }

  function closeSettings() {
    modal.hidden = true;
  }

  function populateVoices(selected) {
    const voices = SkyVoice.getVoices();
    cfg.voiceName.innerHTML = '<option value="">AUTO (SKYNET PRESET)</option>' +
      voices.map((v) => '<option value="' + v.name.replace(/"/g, "&quot;") + '">' +
        v.name + " [" + v.lang + "]" + (v.localService ? " (local)" : "") + "</option>").join("");
    cfg.voiceName.value = selected && voices.some((v) => v.name === selected) ? selected : "";
  }

  function updateProviderBoxes() {
    const p = cfg.provider.value;
    cfg.hfBox.hidden = p !== "huggingface";
    cfg.oaiBox.hidden = p !== "openai";
    cfg.customBox.hidden = p !== "custom";
  }
  cfg.provider.addEventListener("change", updateProviderBoxes);

  cfg.rate.addEventListener("input", () => { cfg.rateVal.textContent = parseFloat(cfg.rate.value).toFixed(2); });
  cfg.pitch.addEventListener("input", () => { cfg.pitchVal.textContent = parseFloat(cfg.pitch.value).toFixed(2); });

  cfg.personaReset.addEventListener("click", () => {
    cfg.systemPrompt.value = SkyAI.DEFAULT_SYSTEM_PROMPT;
  });

  cfg.testBtn.addEventListener("click", async () => {
    collectSettings(); // test with what's currently in the form
    cfg.testResult.textContent = "Testing link...";
    const result = await SkyAI.test();
    cfg.testResult.textContent = result.msg;
    cfg.testResult.style.color = result.ok ? "var(--green)" : "var(--red)";
    addLog("Core link test: " + (result.ok ? "SUCCESS" : "FAILURE"));
  });

  function collectSettings() {
    const s = SkyAI.load();
    s.provider = cfg.provider.value;
    s.hfToken = cfg.hfToken.value.trim();
    s.hfModel = cfg.hfModel.value.trim() || DEFAULT_HF_MODEL;
    s.oaiBase = cfg.oaiBase.value.trim() || "https://api.openai.com/v1";
    s.oaiKey = cfg.oaiKey.value.trim();
    s.oaiModel = cfg.oaiModel.value.trim() || "gpt-4o-mini";
    s.customUrl = cfg.customUrl.value.trim();
    s.voiceOut = cfg.voiceOut.checked;
    s.wakeWord = (cfg.wakeWord.value.trim() || "skynet").toLowerCase();
    s.voiceName = cfg.voiceName.value;
    s.rate = parseFloat(cfg.rate.value) || 1.0;
    s.pitch = parseFloat(cfg.pitch.value) || 0.7;
    s.systemPrompt = cfg.systemPrompt.value.trim() || SkyAI.DEFAULT_SYSTEM_PROMPT;
    return s;
  }
  const DEFAULT_HF_MODEL = "meta-llama/Llama-3.1-8B-Instruct";

  cfg.saveBtn.addEventListener("click", () => {
    const s = collectSettings();
    const wakeWasEnabled = s.wakeEnabled;
    s.wakeEnabled = cfg.wake.checked;
    SkyAI.save(s);
    refreshStatus();
    refreshWakeEcho();

    if (s.wakeEnabled && !wakeActive()) {
      wakeBtn.click(); // engage listening
    } else if (!s.wakeEnabled && wakeActive()) {
      wakeBtn.click(); // disengage
    } else if (s.wakeEnabled) {
      ensureWake(); // restart with possibly new word
    }

    closeSettings();
    addMessage("SKYNET", "Configuration saved. AI core: " + SkyAI.providerLabel(s) +
      (s.wakeEnabled ? '. Always listening for "' + s.wakeWord + '".' : "."), false);
    addLog("Configuration updated. Core: " + SkyAI.providerLabel(s));
  });

  /* ---------------- Status refresh ---------------- */
  function refreshStatus() {
    const s = SkyAI.load();
    const label = SkyAI.providerLabel(s);
    coreProviderLabel.textContent = label;
    idProvider.textContent = label === "DEMO" ? "DEMO BRAIN" : label + " LINK";
    voiceSupport.textContent = SkyVoice.sttSupported ? "READY" : "UNSUPPORTED";
    if (wakeActive()) idVoice.textContent = "LISTENING";
    refreshWakeEcho();
  }

  /* ---------------- Input events ---------------- */
  sendBtn.addEventListener("click", () => transmit(userInput.value));
  userInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") transmit(userInput.value);
    if (e.ctrlKey && e.key === "k") {
      e.preventDefault();
      chatWindow.innerHTML = "";
      history.length = 0;
      addMessage("SKYNET", "Console buffer cleared. Awaiting new directives.");
      addLog("Console cleared by operator.");
    }
  });

  document.querySelectorAll(".qa-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      userInput.value = btn.dataset.cmd;
      transmit(btn.dataset.cmd);
    });
  });

  // Slash commands
  const slash = {
    "/help": () => transmit("help"),
    "/clear": () => {
      chatWindow.innerHTML = "";
      history.length = 0;
      addMessage("SKYNET", "Console buffer cleared. Awaiting new directives.");
    },
    "/settings": () => openSettings(),
    "/voice": () => startMicSession(),
    "/bubble": () => SkyBubble.toggle()
  };

  const origTransmit = transmit;
  transmit = function (text) {
    const t = (text || "").trim();
    if (slash[t]) { slash[t](); return; }
    return origTransmit(text);
  };

  /* ---------------- PWA install ---------------- */
  let deferredInstall = null;
  const installBtn = document.getElementById("btn-install");
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    deferredInstall = e;
    if (installBtn) installBtn.hidden = false;
    addLog("App installation available.");
  });
  if (installBtn) {
    installBtn.addEventListener("click", async () => {
      if (!deferredInstall) return;
      deferredInstall.prompt();
      await deferredInstall.userChoice;
      deferredInstall = null;
      installBtn.hidden = true;
    });
  }
  window.addEventListener("appinstalled", () => {
    if (installBtn) installBtn.hidden = true;
    addLog("Uplink installed as an application.");
  });

  /* ---------------- Boot ---------------- */
  userInput.focus();
  refreshStatus();
  addLog("Interface ready. Human operator detected.");
  addLog("Core: " + SkyAI.providerLabel() + " // voice: " + (SkyVoice.sttSupported ? "ready" : "unsupported"));

  if (!SkyVoice.sttSupported) {
    addLog("NOTE: Chrome/Edge recommended for voice features.");
  }
  if (new URLSearchParams(location.search).get("voice") === "1" && SkyVoice.sttSupported) {
    startMicSession();
    openVoiceOverlay();
    addLog("Voice shortcut invoked.");
  }
  const s0 = SkyAI.load();
  if (s0.wakeEnabled) {
    wakeBtn.classList.add("on");
    wakeBtnLabel.textContent = 'WAKE WORD: "' + (s0.wakeWord || "skynet").toUpperCase() + '"';
    idVoice.textContent = "LISTENING";
    addLog('Wake word standby. Say "' + (s0.wakeWord || "skynet") + '" to activate. Mic permission required.');
  }
})();
