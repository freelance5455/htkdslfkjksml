/**
 * SKYNET UPLINK — Service Worker
 * Offline-capable app shell. Installs as a PWA on Android/iOS/desktop.
 */
const CACHE = "skynet-uplink-v3.1.0";
const ASSETS = [
  "./",
  "./index.html",
  "./manifest.json",
  "./src/styles.css",
  "./src/providers.js",
  "./src/voice.js",
  "./src/bubble.js",
  "./src/skynet.js",
  "./assets/cyberdyne-logo.png",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon-192-maskable.png",
  "./icons/icon-512-maskable.png"
];

self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(CACHE)
      .then((c) => c.addAll(ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return; // never intercept AI-core API calls (POST)
  const url = new URL(req.url);
  if (url.origin !== location.origin) return; // external APIs/fonts go direct

  // Cache-first, network fallback, update cache in background
  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then((cached) => {
      const network = fetch(req)
        .then((res) => {
          if (res && res.ok) {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
          }
          return res;
        })
        .catch(() => caches.match("./index.html"));
      return cached || network;
    })
  );
});
