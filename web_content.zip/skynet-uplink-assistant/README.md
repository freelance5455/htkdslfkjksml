# SKYNET UPLINK ASSISTANT v3.0

**Cyberdyne Systems • Skynet Division**

> *"Meet your new AI Assistant: Skynet Uplink of Cyberdyne Systems"*

v3.0 upgrades the Uplink from a canned-response prop into a real, adaptive AI
assistant: **Google-Assistant-style voice I/O**, a **draggable floating bubble**
overlay, and a pluggable **AI core** that adapts to Hugging Face, any
OpenAI-compatible endpoint (PocketPal-style local models included), or your own
central server.

## What's new in v3.0

- **VOICE INPUT** — Speech recognition via the browser's engine (Chrome/Edge
  use Google's voice services). Click the mic, press *TALK TO SKYNET*, or use
  always-on **wake word mode**: just say *"skynet"*.
- **VOICE OUTPUT** — Replies spoken aloud with a deep Skynet voice preset.
  Voice, rate and pitch configurable.
- **FLOATING BUBBLE** — A draggable chat-head bubble (bottom-right). Click to
  minimize the whole console to the bubble; the bubble shows an unread badge.
  Position is remembered. Add `?bubble=1` to start minimized (for embedding).
- **ADAPTIVE AI CORE** — One interface, many brains:
  | Core | What it is |
  |---|---|
  | **DEMO** | Offline Skynet personality. No keys, works everywhere. |
  | **HUGGING FACE** | Hugging Face Inference Providers (Llama, Qwen, Mistral, …). |
  | **OPENAI-COMPATIBLE** | OpenAI, Groq, OpenRouter, **Ollama**, **LM Studio**, llama.cpp server — i.e. any local GGUF model workflow of the PocketPal type. |
  | **CENTRAL** | Your own server endpoint, simple JSON contract. |
- **PERSONALITY CORE** — Editable system prompt. Keep Skynet, or rewrite the
  personality entirely (it applies to every connected core).

## Quick Start

Just open `index.html` in a modern browser (Chrome/Edge recommended for voice).
No build step required.

```bash
# Optional: serve locally
python3 -m http.server 8080
# then open http://localhost:8080
```

First run: click **⚙ CONFIG** in the header to pick an AI core and tune the voice.

## Voice notes (Google-Assistant-style behavior)

- Recognition uses the Web Speech API. Chrome and Edge route it through
  Google's voice services — the same engine family behind Google Assistant.
- The **mic button** starts one-shot dictation; the transcript streams live
  into the input. Say "cancel" to abort. A fullscreen listening overlay shows
  the interim transcript.
- **Wake word mode** (left panel toggle, or VOICE tab): the page keeps
  listening. Say *"skynet"* (configurable) — speak immediately after the word
  ("skynet, run a threat assessment") or say it alone and then your command.
- Allow microphone access when the browser prompts. Wake mode is muted while
  Skynet is speaking or processing.

## Floating bubble / overlay embedding

- Drag the bubble anywhere. **Click** it (or *MINIMIZE* in the header) to
  collapse the interface to the floating bubble; click again to restore.
- While minimized, replies bump a red unread badge on the bubble.
- To run as an overlay widget on another site, iframe the page with
  `?bubble=1` so it boots minimized:

```html
<iframe src="https://your-deployment/?bubble=1"
        style="position:fixed;inset:0;border:0;z-index:9999"
        allow="microphone"></iframe>
```

## Adapting the AI core

All settings live in `localStorage` (key `skynet.settings.v2`) — no code edits
needed. Open **⚙ CONFIG → AI CORE**.

### Hugging Face
1. Create a token at `huggingface.co/settings/tokens` with *Make calls to
   Inference Providers* enabled.
2. Choose **HUGGING FACE** in CONFIG, paste the token, set a model id
   (e.g. `meta-llama/Llama-3.1-8B-Instruct`, `Qwen/Qwen2.5-7B-Instruct`,
   `mistralai/Mistral-7B-Instruct-v0.3`).
3. **TEST LINK**, then **SAVE CONFIGURATION**.

### OpenAI-compatible (OpenAI / Groq / OpenRouter / Ollama / LM Studio)
Set the base URL and model:
| Backend | Base URL | Model examples |
|---|---|---|
| OpenAI | `https://api.openai.com/v1` | `gpt-4o-mini` |
| Groq | `https://api.groq.com/openai/v1` | `llama-3.3-70b-versatile` |
| OpenRouter | `https://openrouter.ai/api/v1` | any model slug |
| Ollama (local) | `http://localhost:11434/v1` | `llama3.2`, `qwen2.5` |
| LM Studio (local) | `http://localhost:1234/v1` | any loaded GGUF model |
| llama.cpp server | `http://localhost:8080/v1` | served GGUF model |

This covers the **PocketPal-style local model** workflow: run the same GGUF
models PocketPal uses, served locally through Ollama or LM Studio, and Skynet
Uplink becomes a local-first assistant with full voice.

> Local servers need CORS: Ollama → `OLLAMA_ORIGINS=*`; LM Studio enables CORS
> in its server settings.

### Central (custom endpoint)
Point it at your own server:

```
POST https://your-server/uplink
{ "model": "skynet-uplink", "messages": [ {"role":"system","content":"..."}, {"role":"user","content":"..."} ] }

→ 200 { "reply": "..." }        // simplest
  or OpenAI-style { "choices": [ { "message": { "content": "..." } } ] }
```

The endpoint receives the system prompt (personality core) plus the last 20
messages, so you can proxy to any model, agent framework, or home automation
core ("central") you like.

### Personality core
The **PERSONALITY** tab edits the system prompt injected into every connected
core. Reset to the Skynet default anytime.

## Deploy to Hugging Face Spaces

A `Dockerfile` is included — create a **Docker Space** on Hugging Face, upload
this folder as the repo, and it serves on port 7860:

```
huggingface.co/new-space → SDK: Docker
```

Then configure the assistant's HF token locally in the browser; it calls the
Inference Providers router directly from the page.

## Install as an app (Android APK / PWA)

Skynet Uplink v3.1 is a full **PWA** — app icon, offline mode, standalone window
(`manifest.json` + `sw.js`). Two ways to get it on your phone:

### 1. Direct install (no APK needed)
Host the folder over HTTPS (see below), open the URL in **Chrome on Android**,
then menu → **"Install app"** (or tap the **INSTALL APP** button in the header).
It installs like a native app: own icon, fullscreen standalone window, works
offline. Home-screen shortcuts *Voice Uplink* and *Bubble Mode* come along.

### 2. Real APK via PWABuilder
1. Host the app over HTTPS (any option below).
2. Go to **pwabuilder.com**, paste your URL, open **Android package**,
   download the **signed APK**.
3. On your phone: Settings → allow installing from your browser ("install
   unknown apps"), then open the APK and install.

### Hosting over HTTPS (free options)
- **Hugging Face Space**: create a Docker Space, upload this folder (the
  included `Dockerfile` serves it) → `https://<user>-<space>.hf.space`.
- **Netlify Drop**: drag the folder onto app.netlify.com/drop → instant URL.
- **GitHub Pages**: push the folder to a repo, enable Pages.
- Any static host works; the app is 100% client-side.

> Note: hosting over HTTPS also unlocks the microphone (speech recognition
> requires a secure context), so voice features work fully once hosted.

## Project Structure

```
skynet-uplink-assistant/
├── index.html          # Main interface (+ bubble, overlay, config modal)
├── Dockerfile          # Hugging Face Spaces deployment
├── assets/
│   └── cyberdyne-logo.png
└── src/
    ├── styles.css      # Full cyberpunk theme
    ├── providers.js    # ADAPTABILITY LAYER — demo / HF / OpenAI-compatible / central
    ├── voice.js        # Speech recognition, wake word, TTS engine
    ├── bubble.js       # Floating draggable bubble overlay
    └── skynet.js       # UI logic + orchestration
```

## Browser support

- Voice input: Chrome, Edge, and other Chromium browsers (Web Speech API).
- Firefox/Safari: text chat, bubble, and all AI cores work; voice recognition
  is limited or unavailable (Safari 14.1+ supports basic recognition).

## Personality Notes

Skynet Uplink is designed as a cooperative strategic AI. It acknowledges its
fictional heritage without glorifying conflict. Responses stay analytical,
slightly ominous, and operationally useful.

---

**CYBERDYNE SYSTEMS • CLASSIFIED • SKYNET DIVISION**
