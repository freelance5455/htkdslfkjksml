# Raja International Travel KPK — Ledger PWA

An offline-capable, local-first multi-agency travel ledger starter project.

## Features
- Separate ledgers per agency
- Customer records and customer balances
- Ticket sale, purchase cost, profit, PNR, airline, route and travel date
- Customer receipts and supplier payments
- Expense tracking
- Invoice print and WhatsApp sharing
- CSV ticket export
- Manual JSON backup and restore
- English and Urdu interface
- IndexedDB storage, PWA manifest and Service Worker cache

## Run locally
1. Extract the ZIP.
2. Open a terminal in the project folder.
3. Run `python -m http.server 8000` (or `py -m http.server 8000` on Windows).
4. Visit `http://localhost:8000`.
5. Open it once while online/local server is running so the Service Worker can cache the app shell.

Service Workers require localhost or HTTPS; opening `index.html` directly with `file://` will not enable offline PWA behavior.

## Important notes
- Data is stored only in this browser on this device. There is no automatic sync between devices.
- WhatsApp sharing requires internet access.
- The JSON backup contains data from all agencies in this browser.
- Restore replaces the local dataset. Make a backup first.
- This is a starter ledger, not an airline GDS, tax/accounting compliance, or cloud multi-user system. Verify calculations against your agency workflow before entering live records.
