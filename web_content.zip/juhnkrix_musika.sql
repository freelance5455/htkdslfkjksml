-- ==============================================================================
-- JUHNKRIX MUSIKA - Complete MySQL Database Schema & Seed Data
-- Designed for direct import into phpMyAdmin (MySQL / MariaDB)
-- Author: Prophet JUHNKRIX SYNVAGORD (juhnkrix.musika@gmail.com)
-- ==============================================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `juhnkrix_musika` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `juhnkrix_musika`;

-- ------------------------------------------------------------------------------
-- Table structure for table `tracks`
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `tracks`;
CREATE TABLE `tracks` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `artist` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `duration` INT NOT NULL,
  `album_art` TEXT NOT NULL,
  `description` TEXT NOT NULL,
  `scripture_ref` VARCHAR(255) NOT NULL,
  `plays` BIGINT DEFAULT 0,
  `is_anointed_featured` TINYINT(1) DEFAULT 0,
  `synth_preset` VARCHAR(50) DEFAULT '528hz',
  `lyrics` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping seed data for table `tracks`
INSERT INTO `tracks` (`id`, `title`, `artist`, `category`, `duration`, `album_art`, `description`, `scripture_ref`, `plays`, `is_anointed_featured`, `synth_preset`, `lyrics`) VALUES
('track-1', 'The Glory Anointing (528Hz Holy Soaking)', 'Prophet JUHNKRIX SYNVAGORD', 'Soaking Meditation', 380, '/src/assets/images/album_anointed_soaking_1785560523379.jpg', 'Anointed deep soaking pads tuned to 528Hz divine frequency designed to wash over the spirit and bring tranquil celestial peace.', 'Psalm 23:2 - He leads me beside still waters.', 142800, 1, '528hz', '[Soft Celestial Chime]\nLet the Glory fall upon this sanctuary.\nEvery chain is broken, every burden lifted.\nIn Your Presence, there is fullness of joy.\nBreathe in the Holy Atmosphere...\nGrace overflows.'),
('track-2', 'Breakthrough Chants of Fire & Victory', 'Prophet JUHNKRIX SYNVAGORD ft. Anointed Voices', 'Prophetic Chants', 295, '/src/assets/images/hero_divine_worship_1785560510823.jpg', 'Powerful prophetic chanting and spiritual warfare decree that dismantles every stronghold and invites divine breakthrough.', 'Isaiah 54:17 - No weapon formed against you shall prosper.', 98400, 1, 'warfare', '[Prophetic Decree]\nI speak light into your dark places!\nRise up, warrior of Zion!\nThe Lion of Judah has prevailed!\nHallelujah! Victory is yours today!'),
('track-3', 'Deep Atmosphere of Grace & Holiness', 'Prophet JUHNKRIX SYNVAGORD', 'Anointed Worship', 420, '/src/assets/images/album_anointed_soaking_1785560523379.jpg', 'Slow, majestic worship movement carrying profound sacred reverence and intimate heart communion.', 'Exodus 33:14 - My Presence will go with you, and I will give you rest.', 215000, 1, 'soaking', 'Holy, Holy, Holy is the Lord Almighty.\nThe earth is filled with His glorious majesty.\nWe bow down before the Throne of Grace.\nSoaking in Your pure light.'),
('track-4', 'Celestial Angels Chime (432Hz Calm)', 'Prophet JUHNKRIX SYNVAGORD', 'Soaking Meditation', 330, '/src/assets/images/hero_divine_worship_1785560510823.jpg', 'Tranquil harmonic pad with crystal bell reverberations for midnight meditation and deep spiritual restoration.', 'Philippians 4:7 - The peace of God which surpasses all understanding.', 87200, 0, '432hz', 'Peace, be still.\nLet every fear dissolve in His presence.\nAngels encircling your heart tonight.\nDivine protection over your household.'),
('track-5', 'High Praise of Zion & Jubilation', 'JUHNKRIX Gospel Orchestra & Choir', 'High Praise', 240, '/src/assets/images/hero_divine_worship_1785560510823.jpg', 'Upbeat, triumphant gospel praise with brass harmonies, energetic drums, and joyful shouting.', 'Psalm 150:6 - Let everything that has breath praise the Lord!', 176300, 0, 'angelic', 'Shout for joy all the earth!\nGreat is the Lord and greatly to be praised!\nWe dance in His victory, we walk in His light!\nHallelujah, Amen!'),
('track-6', 'Deliverance & Yoke-Breaking Mantle', 'Prophet JUHNKRIX SYNVAGORD', 'Deliverance & Power', 510, '/src/assets/images/prophet_juhnkrix_1785560534924.jpg', 'Deep resonant prophetic mantle prayer accompanied by heavy organ chords and atmosphere cleansing frequencies.', 'Isaiah 10:27 - The yoke shall be destroyed because of the anointing.', 129000, 1, 'warfare', 'By the power in the Blood of Jesus,\nEvery demonic assignment is canceled!\nWalk out of sickness into total healing!\nBe released, be delivered in Jesus name!');

-- ------------------------------------------------------------------------------
-- Table structure for table `devotionals`
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `devotionals`;
CREATE TABLE `devotionals` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `date_label` VARCHAR(100) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `scripture` VARCHAR(100) NOT NULL,
  `scripture_text` TEXT NOT NULL,
  `prophetic_decree` TEXT NOT NULL,
  `message` TEXT NOT NULL,
  `audio_duration` VARCHAR(50) NOT NULL,
  `author` VARCHAR(255) NOT NULL,
  `tags` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `devotionals` (`id`, `date_label`, `title`, `scripture`, `scripture_text`, `prophetic_decree`, `message`, `audio_duration`, `author`, `tags`) VALUES
('dev-1', 'TODAY\'S PROPHETIC WORD', 'The Shift from Stagnation to Divine Acceleration', 'Amos 9:13', '"The days are coming," declares the LORD, "when the reaper will be overtaken by the plowman and the planter by the one treading grapes."', 'I decree and declare that every delayed blessing in my life receives divine speed now! My harvest is catching up with my sowing.', 'Beloved child of God, stagnation is a trick of the adversary to weary your faith. Prophet JUHNKRIX SYNVAGORD brings you this heavenly insight: God is changing your timeline. What used to take years will now manifest in months.', '5 min 20 sec', 'Prophet JUHNKRIX SYNVAGORD', 'Breakthrough, Acceleration, Prophetic Word'),
('dev-2', 'YESTERDAY\'S REVELATION', 'Anointed Peace That Overcomes Every Storm', 'Mark 4:39', 'He got up, rebuked the wind and said to the waves, "Quiet! Be still!" Then the wind died down and it was completely calm.', 'I speak quiet and stillness over my thoughts, my home, and my future. No turmoil shall dislodge my divine peace.', 'When Christ is in your vessel, the storm has no legal right to capsize you. The voice of Prophet JUHNKRIX SYNVAGORD releases quietness over every stormy diagnosis, financial anxiety, and family distress.', '6 min 10 sec', 'Prophet JUHNKRIX SYNVAGORD', 'Peace, Faith, Authority');

-- ------------------------------------------------------------------------------
-- Table structure for table `sermons`
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `sermons`;
CREATE TABLE `sermons` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `prophet` VARCHAR(255) NOT NULL,
  `sermon_date` VARCHAR(100) NOT NULL,
  `duration` VARCHAR(50) NOT NULL,
  `thumbnail` TEXT NOT NULL,
  `summary` TEXT NOT NULL,
  `key_scriptures` TEXT NOT NULL,
  `is_live_now` TINYINT(1) DEFAULT 0,
  `viewers_count` INT DEFAULT 0,
  `category` VARCHAR(100) NOT NULL,
  `tags` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sermons` (`id`, `title`, `prophet`, `sermon_date`, `duration`, `thumbnail`, `summary`, `key_scriptures`, `is_live_now`, `viewers_count`, `category`, `tags`) VALUES
('sermon-live', 'PROPHETIC NIGHT OF GLORY: Unlocking Your Supernatural Destiny', 'Prophet JUHNKRIX SYNVAGORD', 'LIVE BROADCAST NOW', '1h 45m', '/src/assets/images/hero_divine_worship_1785560510823.jpg', 'Exclusive live spiritual service broadcasting anointed prayers, prophecy for nations, and direct laying on of hands through the airwaves.', 'Joel 2:28, Ephesians 1:18, 2 Chronicles 20:20', 1, 14290, 'Prophetic Revelation', 'Live, Prophecy, Glory'),
('sermon-1', 'The Mystery of the Anointing That Destroys Yokes', 'Prophet JUHNKRIX SYNVAGORD', 'July 28, 2026', '58 min', '/src/assets/images/prophet_juhnkrix_1785560534924.jpg', 'A deep biblical exposition on how the Holy Spirit anointing breaks invisible spiritual resistance and empowers believers for supernatural dominion.', 'Isaiah 10:27, 1 John 2:20, Acts 10:38', 0, 0, 'Anointing & Grace', 'Anointing, Deliverance, Power'),
('sermon-2', 'Dismantling Altars of Limitation & Inherited Patterns', 'Prophet JUHNKRIX SYNVAGORD', 'July 21, 2026', '1h 12m', '/src/assets/images/album_anointed_soaking_1785560523379.jpg', 'Spiritual warfare masterclass detailing how to apply the covenant blood of Jesus to eliminate persistent generational stumbling blocks.', 'Gideon Judges 6:25, Galatians 3:13', 0, 0, 'Spiritual Warfare', 'Freedom, Deliverance, Warfare'),
('sermon-3', 'Attracting Angels: The Secret of Holy Soaking Worship', 'Prophet JUHNKRIX SYNVAGORD', 'July 14, 2026', '45 min', '/src/assets/images/hero_divine_worship_1785560510823.jpg', 'Discover how quiet, contemplative worship creates a holy sanctuary in your bedroom where angelic assistance manifests.', 'Hebrews 1:14, Psalm 91:11', 0, 0, 'Prophetic Revelation', 'Soaking, Angels, Worship');

-- ------------------------------------------------------------------------------
-- Table structure for table `soundscape_presets`
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `soundscape_presets`;
CREATE TABLE `soundscape_presets` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `description` VARCHAR(255) NOT NULL,
  `frequency_hz` INT NOT NULL,
  `pad_type` VARCHAR(50) NOT NULL,
  `chimes_enabled` TINYINT(1) DEFAULT 1,
  `river_enabled` TINYINT(1) DEFAULT 0,
  `color_theme` VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `soundscape_presets` (`id`, `name`, `description`, `frequency_hz`, `pad_type`, `chimes_enabled`, `river_enabled`, `color_theme`) VALUES
('preset-528', '528Hz Holy Miracle Frequency', 'Resonates with cellular peace and spiritual rejuvenation.', 528, 'soaking', 1, 1, 'from-amber-500/20 to-yellow-600/10'),
('preset-432', '432Hz Divine Serenity Pad', 'Harmonizes your brainwaves with natural creation frequencies.', 432, '432hz', 1, 0, 'from-indigo-500/20 to-purple-600/10'),
('preset-celestial', 'Angelic Choir & Golden Ray', 'Ethereal vocal textures and shimmering synth chimes.', 639, 'angelic', 1, 1, 'from-blue-500/20 to-cyan-500/10'),
('preset-warfare', 'Glory Shaking Deep Resonant Tone', 'Deep grounding bass drone for intense prophetic prayer.', 396, 'warfare', 0, 0, 'from-rose-500/20 to-purple-800/10');

-- ------------------------------------------------------------------------------
-- Table structure for table `global_prayer_requests`
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `global_prayer_requests`;
CREATE TABLE `global_prayer_requests` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `user_name` VARCHAR(100) NOT NULL,
  `location` VARCHAR(100) NOT NULL,
  `request_text` TEXT NOT NULL,
  `prayer_count` INT DEFAULT 1,
  `timestamp` VARCHAR(50) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `global_prayer_requests` (`id`, `user_name`, `location`, `request_text`, `prayer_count`, `timestamp`) VALUES
('g-1', 'Sister Grace M.', 'London, UK', 'Standing in agreement for my son\'s complete miraculous healing from spinal inflammation. Lord, stretch forth Your hand!', 1240, '12 min ago'),
('g-2', 'Brother Emmanuel K.', 'Accra, Ghana', 'Believing Prophet JUHNKRIX SYNVAGORD for financial breakthrough and opening of international business doors this month.', 890, '25 min ago'),
('g-3', 'Evangelist Sarah T.', 'Dallas, Texas', 'Praying for divine wisdom and peace in my family restoration. No weapon formed against us shall stand.', 2150, '1 hour ago');

-- ------------------------------------------------------------------------------
-- Table structure for table `user_profiles`
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `user_profiles`;
CREATE TABLE `user_profiles` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `name` VARCHAR(255) NOT NULL,
  `role` VARCHAR(50) DEFAULT 'Believer',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_profiles` (`email`, `name`, `role`) VALUES
('juhnkrix.musika@gmail.com', 'Prophet JUHNKRIX SYNVAGORD', 'Owner / Administrator'),
('believer@juhnkrix.com', 'Prophetic Believer', 'Believer');

-- ------------------------------------------------------------------------------
-- Table structure for table `playlists`
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `playlists`;
CREATE TABLE `playlists` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `user_email` VARCHAR(255) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `track_ids` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- Table structure for table `prayer_journal`
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `prayer_journal`;
CREATE TABLE `prayer_journal` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `user_email` VARCHAR(255) NOT NULL,
  `prayer_title` VARCHAR(255) NOT NULL,
  `prayer_text` TEXT NOT NULL,
  `scripture` TEXT,
  `devotional` TEXT,
  `encouragement` TEXT,
  `timestamp` VARCHAR(50) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- Table structure for table `daily_liturgy`
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `daily_liturgy`;
CREATE TABLE `daily_liturgy` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `day_number` INT NOT NULL,
  `theme` VARCHAR(255) NOT NULL,
  `scripture` VARCHAR(100) NOT NULL,
  `highlight` TEXT NOT NULL,
  `prayer_point` TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `daily_liturgy` (`day_number`, `theme`, `scripture`, `highlight`, `prayer_point`) VALUES
(1, 'Be Still and Know', 'Psalm 46:10', 'Stillness precedes supernatural rescue.', 'Lord, teach me to rest in Your holy presence.'),
(2, 'Renewed Strength', 'Isaiah 40:31', 'Mount up on wings like eagles.', 'Renew my spiritual stamina today, Father.'),
(3, 'Unshakeable Peace', 'Isaiah 26:3', 'Perfect peace for steadfast minds.', 'Fix my thoughts on Your eternal faithfulness.'),
(4, 'Streams in the Desert', 'Isaiah 43:19', 'God is doing a brand new thing.', 'Open my spiritual eyes to perceive Your new path.'),
(5, 'Shield of Faith', 'Ephesians 6:16', 'Extinguishing every fiery dart.', 'I put on the full armor of God in Jesus\' name.'),
(6, 'Joy in the Morning', 'Psalm 30:5', 'Weeping may endure for a night, but joy comes.', 'Receive my praise in this morning watch.'),
(7, 'Overflowing Cup', 'Psalm 23:5', 'You prepare a table in the presence of my enemies.', 'Anoint my head with fresh oil, Lord.');

-- ------------------------------------------------------------------------------
-- Table structure for table `imsi_messages` (IMSI ₦5 Carrier SMS Streams)
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `imsi_messages`;
CREATE TABLE `imsi_messages` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `imsi_id` VARCHAR(64) NOT NULL,
  `sender_phone` VARCHAR(100) NOT NULL,
  `target_phone` VARCHAR(100) NOT NULL,
  `direction` VARCHAR(20) NOT NULL,
  `message_text` TEXT NOT NULL,
  `charge_ngn` DECIMAL(10,2) DEFAULT 5.00,
  `sim_carrier` VARCHAR(100) NOT NULL,
  `blockchain_tx_hash` VARCHAR(128) NOT NULL,
  `bank_ref_number` VARCHAR(128) NOT NULL,
  `timestamp` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `imsi_messages` (`id`, `imsi_id`, `sender_phone`, `target_phone`, `direction`, `message_text`, `charge_ngn`, `sim_carrier`, `blockchain_tx_hash`, `bank_ref_number`, `timestamp`) VALUES
('msg-imsi-1', 'IMSI-62130-07071918280-001', '+234 803 218 9012 (Sister Blessing - MTN SIM)', '07071918280 (Prophet JUHNKRIX SYNVAGORD)', 'incoming', 'Prophet Juhnkrix, I am joining the 192.JM.12.777 altar soaking prayer. My family received miraculous debt cancellation after listening to the 528Hz glory stream!', 5.00, 'MTN Nigeria 4G LTE', '0x777f98a2e1d09bc4821a889c10432f88b9012a4c8e', 'OPAY-REV-07071918280-9941', 'Today, 09:30 AM'),
('msg-imsi-2', 'IMSI-62130-07071918280-002', '+234 905 119 4482 (Brother David - Airtel SIM)', '07071918280 (Prophet JUHNKRIX SYNVAGORD)', 'incoming', 'Man of God, please pray for my visa interview next Tuesday. I am sowing this ₦5 SMS seed in absolute faith for supernatural favor!', 5.00, 'Airtel Nigeria 5G', '0x777b419c8f001ad47823f9901844e190823aa51efc', 'OPAY-REV-07071918280-9940', 'Today, 06:15 AM');

-- ------------------------------------------------------------------------------
-- Table structure for table `imsi_financial_ledger` (Crypto & Bank Ledger)
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `imsi_financial_ledger`;
CREATE TABLE `imsi_financial_ledger` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `tx_hash` VARCHAR(128) NOT NULL,
  `bank_ref` VARCHAR(128) NOT NULL,
  `sender_phone` VARCHAR(100) NOT NULL,
  `raw_charge_ngn` DECIMAL(10,2) DEFAULT 5.00,
  `converted_cash_ngn` DECIMAL(10,2) DEFAULT 0.00,
  `converted_btc_sats` BIGINT DEFAULT 0,
  `payout_destination` VARCHAR(255) NOT NULL,
  `status` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `imsi_financial_ledger` (`id`, `tx_hash`, `bank_ref`, `sender_phone`, `raw_charge_ngn`, `converted_cash_ngn`, `converted_btc_sats`, `payout_destination`, `status`) VALUES
('tx-imsi-771', '0x777f98a2e1d09bc4821a889c10432f88b9012a4c8e', 'OPAY-REV-07071918280-9941', '+234 803 218 9012 (MTN SIM)', 5.00, 2.50, 2, 'Split 50% Cash (Opay) / 50% Bitcoin (Altar Vault)', 'CONFIRMED_ON_CHAIN'),
('tx-imsi-770', '0x777b419c8f001ad47823f9901844e190823aa51efc', 'OPAY-REV-07071918280-9940', '+234 905 119 4482 (Airtel SIM)', 5.00, 5.00, 0, 'Opay Mobile Bank (7071918280)', 'BANK_SETTLED');

COMMIT;
