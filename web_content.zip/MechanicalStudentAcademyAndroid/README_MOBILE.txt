Mechanical Student Academy - Android Project

This project wraps the supplied HTML portal in an Android WebView.
It includes Internet access for Supabase, JavaScript/DOM storage, and Android file chooser support for <input type=file>.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on Android.

Important:
- Supabase Storage policies must allow the logged-in/admin operation required by the HTML app.
- The HTML file already contains its Supabase URL/key and portal logic.
- For production, do not put privileged Supabase service-role keys in client HTML/app.
