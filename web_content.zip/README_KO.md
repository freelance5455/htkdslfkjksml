# GYM LOG Android 프로젝트

## APK 만들기
1. PC에 Android Studio를 설치합니다.
2. 압축을 푼 `gym_log_android_project` 폴더를 Android Studio에서 엽니다.
3. SDK 설치 및 Gradle 동기화 안내를 완료합니다. Android SDK Platform 35와 JDK 17 이상이 필요합니다.
4. 메뉴에서 **Build > Build Bundle(s) / APK(s) > Build APK(s)** 를 누릅니다.
5. APK는 `app/build/outputs/apk/debug/app-debug.apk` 에 생성됩니다.
6. APK를 Android 휴대폰으로 옮겨 설치합니다. 필요한 경우 설정에서 해당 출처의 앱 설치를 허용합니다.

## 안내
- 이 ZIP은 APK 자체가 아니라 APK를 만들기 위한 Android Studio 프로젝트입니다.
- 기존 운동 기록 화면은 `app/src/main/assets/index.html`에 포함되어 있습니다.
- 앱 데이터가 지워지거나 앱을 삭제하면 기록이 사라질 수 있으니 앱의 백업 기능을 이용해 주기적으로 백업하세요.
- WebView 기반 래퍼이므로 사진 선택·백업 기능은 Android 버전과 HTML 구현에 따라 추가 조정이 필요할 수 있습니다.
