import { EditorState } from '@codemirror/state';
import { EditorView, keymap, lineNumbers, highlightActiveLine, drawSelection } from '@codemirror/view';
import { defaultKeymap, history, historyKeymap, indentWithTab } from '@codemirror/commands';
import { foldGutter, indentOnInput, bracketMatching, syntaxHighlighting, defaultHighlightStyle } from '@codemirror/language';
import { search, searchKeymap, highlightSelectionMatches } from '@codemirror/search';
import { javascript } from '@codemirror/lang-javascript';
import { html } from '@codemirror/lang-html';
import { css } from '@codemirror/lang-css';
import { python } from '@codemirror/lang-python';
import { json } from '@codemirror/lang-json';
import { java } from '@codemirror/lang-java';
import { oneDark } from '@codemirror/theme-one-dark';

function languageFor(path) {
  const ext = path.split('.').pop()?.toLowerCase();
  if (['js','mjs','cjs','ts','jsx','tsx','luau','lua'].includes(ext)) return javascript({ typescript: ['ts','tsx'].includes(ext), jsx: ['jsx','tsx'].includes(ext) });
  if (['html','xml'].includes(ext)) return html();
  if (ext === 'css') return css();
  if (ext === 'py') return python();
  if (ext === 'json') return json();
  if (['java','kt'].includes(ext)) return java();
  return [];
}
export class CodeEditor {
  constructor(host, settings = {}) { this.host = host; this.settings = settings; this.view = null; }
  open(path, content, onChange) {
    this.view?.destroy();
    const extensions = [
      lineNumbers(), foldGutter(), history(), drawSelection(), indentOnInput(),
      bracketMatching(), highlightActiveLine(), highlightSelectionMatches(),
      search(), languageFor(path), syntaxHighlighting(defaultHighlightStyle, { fallback: true }),
      keymap.of([...defaultKeymap, ...historyKeymap, ...searchKeymap, indentWithTab]),
      EditorView.updateListener.of(update => { if (update.docChanged) onChange(update.state.doc.toString()); }),
      EditorView.theme({
        '&': { height: '100%', fontSize: `${this.settings.fontSize || 14}px` },
        '.cm-scroller': { overflow: 'auto', fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace', lineHeight: '1.65' },
        '.cm-gutters': { backgroundColor: 'transparent', border: 'none' },
        '.cm-content': { padding: '14px 0' },
        '.cm-line': { padding: '0 12px' }
      }),
      ...(this.settings.wrap ? [EditorView.lineWrapping] : []),
      ...(this.settings.theme !== 'light' ? [oneDark] : [])
    ];
    this.view = new EditorView({ state: EditorState.create({ doc: content, extensions }), parent: this.host });
  }
  value() { return this.view?.state.doc.toString() || ''; }
  focus() { this.view?.focus(); }
  destroy() { this.view?.destroy(); this.view = null; }
}
