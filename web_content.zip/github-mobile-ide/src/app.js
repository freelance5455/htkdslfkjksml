import { db } from './storage/db.js';
import { AuthService } from './services/auth.js';
import { GitHubService } from './services/github.js';
import { CodeEditor } from './editor/editor.js';

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const date = s => new Date(s).toLocaleDateString(undefined, { month:'short', day:'numeric', year:'numeric' });
const supported = /\.(lua|luau|html|css|js|json|py|xml|md|txt|java|kt|ts|jsx|tsx|yml|yaml)$/i;
const keyOf = (repo, branch, path) => `${repo.full_name}|${branch}|${path}`;

export class AppController {
  constructor(root) {
    this.root = root; this.auth = new AuthService(); this.github = new GitHubService(this.auth);
    this.state = { screen:'home', user:null, repos:[], repo:null, branch:null, branches:[], path:'', entries:[], tabs:[], active:null, drafts:new Map(), loading:false, online:navigator.onLine, settings:{theme:'dark',fontSize:14,tabSize:2,wrap:true,autosave:true}, query:'', toast:null, fullEditor:false };
    this.editor = null;
  }
  async start() {
    this.state.settings = { ...this.state.settings, ...(await db.get('settings','preferences')) };
    this.bindNetwork();
    const user = await this.auth.user();
    if (user && await this.auth.token()) { this.state.user = user; await this.loadRepos(); }
    this.render();
  }
  bindNetwork() {
    window.addEventListener('online', () => { this.state.online=true; this.render(); });
    window.addEventListener('offline', () => { this.state.online=false; this.render(); });
  }
  toast(message, kind='success') {
    this.state.toast={message,kind}; this.render();
    setTimeout(()=>{ this.state.toast=null; this.render(); }, 3200);
  }
  async run(task) {
    this.state.loading=true; this.render();
    try { await task(); }
    catch(e) { this.toast(e.rateLimit ? 'GitHub API rate limit reached. Try again later.' : e.message, 'error'); }
    finally { this.state.loading=false; this.render(); }
  }
  async login() {
    await this.auth.login(async user => {
      this.state.user=user; await this.loadRepos(); this.state.screen='repos'; this.render();
    }, e => this.toast(e.message,'error'));
  }
  async logout() {
    await this.auth.logout(); this.state.user=null; this.state.repos=[]; this.state.repo=null;
    this.state.tabs=[]; this.state.active=null; this.state.screen='home'; this.render();
  }
  async loadRepos() {
    this.state.repos=await this.github.repos();
    this.state.user=await this.github.user();
    this.state.screen=this.state.screen==='home'?'repos':this.state.screen;
  }
  async openRepo(repo) {
    this.state.repo=repo; this.state.branch=repo.default_branch; this.state.path='';
    await this.loadBranches(); await this.loadDirectory(); this.state.screen='files'; this.render();
    await db.put('recent',{id:repo.full_name,name:repo.full_name,updated:Date.now()});
  }
  async loadBranches() {
    this.state.branches=await this.github.branches(this.state.repo.owner.login,this.state.repo.name);
  }
  async loadDirectory() {
    const r=this.state.repo, b=this.state.branch, p=this.state.path;
    const cacheKey=`dir|${r.full_name}|${b}|${p}`;
    try {
      const data=await this.github.contents(r.owner.login,r.name,p,b);
      const entries=Array.isArray(data)?data:[data];
      this.state.entries=entries;
      await db.put('files',{key:cacheKey,value:entries,updated:Date.now()});
    } catch(e) {
      const cached=await db.get('files',cacheKey);
      if (cached) { this.state.entries=cached.value; this.toast('Offline: showing cached repository contents','error'); }
      else throw e;
    }
  }
  async openEntry(entry) {
    if(entry.type==='dir') { this.state.path=this.state.path?`${this.state.path}/${entry.name}`:entry.name; await this.loadDirectory(); this.render(); return; }
    if(!supported.test(entry.name)) { this.toast('This file type is not supported by the text editor.','error'); return; }
    await this.run(async()=>{
      const result=await this.github.readFile(this.state.repo.owner.login,this.state.repo.name,entry.path,this.state.branch);
      const key=keyOf(this.state.repo,this.state.branch,entry.path);
      const draft=await db.get('drafts',key);
      const tab={key,path:entry.path,name:entry.name,content:draft?.content ?? result.content,original:result.content,sha:result.sha,dirty:!!draft,deleted:false};
      const existing=this.state.tabs.find(t=>t.key===key);
      if(!existing) this.state.tabs.push(tab);
      else Object.assign(existing,tab);
      this.state.active=key; this.state.screen='editor'; this.render();
    });
  }
  async createFile() {
    const name=prompt('New file name (include folder path if needed):');
    if(!name) return;
    if(name.startsWith('/') || name.split('/').some(x=>x==='..') || !supported.test(name)) return this.toast('Enter a supported filename and a valid relative path.','error');
    const path=this.state.path?`${this.state.path}/${name}`:name;
    const key=keyOf(this.state.repo,this.state.branch,path);
    const tab={key,path,name:path.split('/').pop(),content:'',original:null,sha:null,dirty:true,isNew:true};
    this.state.tabs.push(tab); this.state.active=key; this.state.screen='editor'; await this.persist(tab); this.render();
  }
  async createFolder() {
    const name=prompt('New folder name:'); if(!name) return;
    if(/[\\/]/.test(name)||name==='.'||name==='..') return this.toast('Enter a simple folder name.','error');
    await this.run(async()=>{const path=this.state.path?`${this.state.path}/${name}`:name; await this.github.createFolder(this.state.repo.owner.login,this.state.repo.name,path,this.state.branch); await this.loadDirectory();});
  }
  activeTab() { return this.state.tabs.find(t=>t.key===this.state.active); }
  async persist(tab) {
    tab.dirty=true;
    if(this.state.settings.autosave) await db.put('drafts',{key:tab.key,content:tab.content,updated:Date.now(),path:tab.path});
  }
  onEdit(content) {
    const tab=this.activeTab(); if(!tab) return;
    tab.content=content; tab.dirty=true;
    this.persist(tab).catch(e=>this.toast(e.message,'error'));
    this.updateEditorStatus();
  }
  updateEditorStatus() {
    const el=document.querySelector('#editor-status');
    const tab=this.activeTab();
    if(el&&tab) el.textContent=tab.dirty?'Unsaved draft · stored locally':'All changes committed';
  }
  async saveActive() {
    const tab=this.activeTab(); if(!tab) return;
    if(!tab.dirty) return this.toast('No changes to save.','info');
    const message=prompt('Commit message:','Update '+tab.path);
    if(!message?.trim()) return;
    await this.run(async()=>{
      if(tab.isNew) {
        const exists=await this.github.contents(this.state.repo.owner.login,this.state.repo.name,tab.path,this.state.branch).then(()=>true).catch(e=>e.status===404?false:Promise.reject(e));
        if(exists) throw new Error('A file with this path already exists remotely.');
      } else {
        const latest=await this.github.readFile(this.state.repo.owner.login,this.state.repo.name,tab.path,this.state.branch);
        if(latest.sha!==tab.sha) {
          const choice=confirm('The remote file changed since you opened it. Your draft is preserved. Press OK to view a basic comparison, or Cancel to keep editing.');
          if(choice) this.showConflict(latest.content,tab.content);
          throw new Error('Remote conflict detected. Your local draft was preserved; compare and reconcile before saving.');
        }
      }
      const result=await this.github.saveFile(this.state.repo.owner.login,this.state.repo.name,tab.path,tab.content,message.trim(),this.state.branch,tab.sha);
      tab.sha=result.content.sha; tab.original=tab.content; tab.dirty=false; tab.isNew=false;
      await db.delete('drafts',tab.key); this.toast('Commit created successfully.');
      await this.loadDirectory();
    });
  }
  showConflict(remote,local) {
    const w=window.open('','_blank');
    if(!w) return this.toast('Popup blocked. Draft remains safe; copy it before reconciling.','error');
    w.document.write(`<title>Conflict comparison</title><style>body{background:#11141b;color:#eee;font:14px monospace;padding:20px}section{white-space:pre-wrap;overflow-wrap:anywhere;background:#202530;padding:12px;border-radius:8px}h2{font: bold 16px sans-serif}</style><h2>Latest GitHub version</h2><section>${esc(remote)}</section><h2>Your local draft</h2><section>${esc(local)}</section>`);
  }
  async renameActive() {
    const tab=this.activeTab(); if(!tab||tab.isNew) return this.toast('Commit a new file before renaming it.','error');
    const next=prompt('New filename (relative path):',tab.path);
    if(!next||next===tab.path)return;
    if(next.startsWith('/')||next.split('/').some(x=>x==='..')||!supported.test(next))return this.toast('Enter a valid supported file path.','error');
    if(!confirm('GitHub represents a rename as two commits: create the new path, then delete the old path. Continue?'))return;
    const message=prompt('Commit message:','Rename '+tab.path+' to '+next); if(!message?.trim())return;
    await this.run(async()=>{
      const latest=await this.github.readFile(this.state.repo.owner.login,this.state.repo.name,tab.path,this.state.branch);
      if(latest.sha!==tab.sha)throw new Error('Remote file changed. Rename cancelled; your draft is preserved.');
      const exists=await this.github.contents(this.state.repo.owner.login,this.state.repo.name,next,this.state.branch).then(()=>true).catch(e=>e.status===404?false:Promise.reject(e));
      if(exists)throw new Error('The destination path already exists.');
      const created=await this.github.saveFile(this.state.repo.owner.login,this.state.repo.name,next,tab.content,message.trim(),this.state.branch,null);
      try {
        await this.github.deleteFile(this.state.repo.owner.login,this.state.repo.name,tab.path,message.trim(),this.state.branch,tab.sha);
      } catch(error) {
        this.toast('New file was created, but deleting the original failed. Both copies may exist.','error');
        throw error;
      }
      await db.delete('drafts',tab.key);
      const newKey=keyOf(this.state.repo,this.state.branch,next);
      Object.assign(tab,{key:newKey,path:next,name:next.split('/').pop(),sha:created.content.sha,original:tab.content,dirty:false,isNew:false});
      this.state.active=newKey; await this.loadDirectory(); this.toast('File renamed in two commits.');
    });
  }
  async repositorySearch() {
    const query=prompt('Search code in this repository:');
    if(!query?.trim())return;
    await this.run(async()=>{
      const result=await this.github.searchCode(this.state.repo.owner.login,this.state.repo.name,query.trim());
      const matches=result.items||[];
      const listing=matches.slice(0,30).map(x=>`${x.path} (open from the file explorer)`).join('\\n');
      alert(matches.length?`Matches: ${result.total_count}\\n\\n${listing}`:'No code matches found.');
    });
  }
  async deleteActive() {
    const tab=this.activeTab(); if(!tab) return;
    if(!confirm(`Delete ${tab.path} from GitHub? This requires a commit.`)) return;
    const message=prompt('Commit message:','Delete '+tab.path); if(!message?.trim()) return;
    await this.run(async()=>{
      const latest=await this.github.readFile(this.state.repo.owner.login,this.state.repo.name,tab.path,this.state.branch);
      if(latest.sha!==tab.sha) throw new Error('Remote file changed. Deletion cancelled to prevent overwriting remote changes.');
      await this.github.deleteFile(this.state.repo.owner.login,this.state.repo.name,tab.path,message.trim(),this.state.branch,tab.sha);
      await db.delete('drafts',tab.key); this.state.tabs=this.state.tabs.filter(t=>t.key!==tab.key); this.state.active=this.state.tabs.at(-1)?.key||null;
      await this.loadDirectory(); this.state.screen='files'; this.toast('File deleted.');
    });
  }
  async changeBranch(branch) {
    if(!branch||branch===this.state.branch)return;
    if(this.state.tabs.some(t=>t.dirty)&&!confirm('You have unsaved drafts. Switch branch? Drafts remain stored under the original branch.'))return;
    this.state.branch=branch; this.state.path=''; await this.run(()=>this.loadDirectory());
  }
  setScreen(screen) { this.state.screen=screen; this.render(); }
  async setSetting(key,value) {
    this.state.settings[key]=value; await db.put('settings',{key:'preferences',...this.state.settings}); this.render();
    if(key==='theme'&&this.state.active) this.mountEditor();
  }
  mountEditor() {
    const tab=this.activeTab(), host=document.querySelector('#code-host');
    if(!host||!tab)return;
    this.editor=new CodeEditor(host,this.state.settings);
    this.editor.open(tab.path,tab.content,content=>this.onEdit(content));
  }
  render() {
    const s=this.state, user=s.user, repo=s.repo;
    const nav=(id,label,icon)=>`<button class="nav-item ${s.screen===id?'active':''}" data-screen="${id}"><i data-lucide="${icon}"></i><span>${label}</span></button>`;
    const header=`<header class="topbar"><div class="brand"><div class="brand-mark"><i data-lucide="code-2"></i></div><div><b>GitHub Mobile IDE</b><small>${user?`Signed in as @${esc(user.login)}`:'Code anywhere'}</small></div></div><div class="top-actions"><span class="connection ${s.online?'online':'offline'}"><i data-lucide="${s.online?'wifi':'wifi-off'}"></i>${s.online?'Online':'Offline'}</span>${user?`<img class="avatar" src="${esc(user.avatar_url)}" alt="GitHub avatar">`:''}</div></header>`;
    let content='';
    if(!user) content=this.homeView();
    else if(s.screen==='home') content=this.dashboardView();
    else if(s.screen==='repos') content=this.reposView();
    else if(s.screen==='files') content=this.filesView();
    else if(s.screen==='editor') content=this.editorView();
    else content=this.settingsView();
    this.root.innerHTML=`${header}<main class="main ${s.fullEditor?'full-editor':''}">${content}</main>${user?`<nav class="bottom-nav">${nav('home','Home','home')}${nav('repos','Repositories','folder-git-2')}${nav('editor','Editor','code-2')}${nav('settings','Settings','settings')}</nav>`:''}${s.toast?`<div class="toast ${s.toast.kind}">${esc(s.toast.message)}</div>`:''}${s.loading?'<div class="loading"><span></span></div>':''}`;
    window.refreshIcons();
    this.bindUI();
    if(s.screen==='editor'&&s.active) this.mountEditor();
  }
  homeView() {
    return `<section class="welcome"><div class="hero-icon"><i data-lucide="github"></i></div><div class="eyebrow">YOUR CODE. YOUR REPOSITORIES.</div><h1>A powerful GitHub workspace, built for mobile.</h1><p>Browse repositories, edit source files, keep local drafts and commit changes directly to GitHub.</p><div class="feature-grid"><div><i data-lucide="folder-git-2"></i><b>Repository access</b><small>Browse branches and files</small></div><div><i data-lucide="code-2"></i><b>CodeMirror editor</b><small>Syntax-aware editing</small></div><div><i data-lucide="cloud"></i><b>Manual commits</b><small>You control every save</small></div></div><button class="primary wide" id="login"><i data-lucide="github"></i> Continue with GitHub</button><small class="muted center">Authentication opens GitHub in your browser. Your token is stored in native secure storage on Android.</small></section>`;
  }
  dashboardView() {
    const recent=this.state.repos.slice(0,4);
    return `<div class="page-head"><div><div class="eyebrow">WORKSPACE</div><h1>Welcome back, ${esc(this.state.user.name||this.state.user.login)}</h1><p>Your development workspace at a glance.</p></div><button class="icon-btn" id="refresh"><i data-lucide="refresh-cw"></i></button></div><div class="stat-grid"><div class="stat-card"><small>Repositories</small><strong>${this.state.repos.length}</strong></div><div class="stat-card"><small>Open files</small><strong>${this.state.tabs.length}</strong></div><div class="stat-card"><small>Local drafts</small><strong>${this.state.tabs.filter(t=>t.dirty).length}</strong></div></div><section class="section"><div class="section-head"><h2>Recently updated</h2><button class="text-btn" data-screen="repos">View all</button></div>${recent.length?recent.map(r=>this.repoCard(r)).join(''):'<div class="empty">No repositories loaded yet.</div>'}</section>`;
  }
  repoCard(r) {
    return `<button class="repo-card" data-repo="${esc(r.full_name)}"><div class="repo-icon"><i data-lucide="folder-git-2"></i></div><div class="repo-info"><b>${esc(r.name)}</b><small>${esc(r.description||'No description')}</small><div class="repo-meta"><span>${esc(r.language||'—')}</span><span>${r.private?'Private':'Public'}</span><span>Updated ${date(r.updated_at)}</span></div></div><i data-lucide="chevron-right"></i></button>`;
  }
  reposView() {
    const q=this.state.query.toLowerCase();
    const repos=this.state.repos.filter(r=>`${r.name} ${r.full_name} ${r.description||''}`.toLowerCase().includes(q));
    return `<div class="page-head"><div><div class="eyebrow">GITHUB</div><h1>Repositories</h1><p>${this.state.repos.length} accessible repositories</p></div><button class="icon-btn" id="refresh"><i data-lucide="refresh-cw"></i></button></div><div class="searchbox"><i data-lucide="search"></i><input id="repo-search" placeholder="Search repositories..." value="${esc(this.state.query)}"></div><div class="repo-list">${repos.map(r=>this.repoCard(r)).join('')||'<div class="empty">No repositories match your search.</div>'}</div>`;
  }
  filesView() {
    const folders=this.state.path?this.state.path.split('/').slice(0,-1):[];
    const rows=this.state.entries.filter(e=>e.name.toLowerCase().includes(this.state.query.toLowerCase())).sort((a,b)=>a.type===b.type?a.name.localeCompare(b.name):a.type==='dir'?-1:1);
    return `<div class="page-head"><div><div class="eyebrow">${esc(repo.full_name)}</div><h1>Files</h1><p>${esc(this.state.branch)} · ${this.state.path?esc(this.state.path):'Repository root'}</p></div><button class="icon-btn" id="refresh-files"><i data-lucide="refresh-cw"></i></button></div><div class="toolbar"><button class="secondary" id="back"><i data-lucide="chevron-left"></i> Back</button><select id="branch-select">${this.state.branches.map(b=>`<option ${b.name===this.state.branch?'selected':''}>${esc(b.name)}</option>`).join('')}</select></div><div class="searchbox"><i data-lucide="search"></i><input id="file-search" placeholder="Filter this folder..." value="${esc(this.state.query)}"></div><div class="file-actions"><button class="secondary" id="new-file"><i data-lucide="plus"></i> New file</button><button class="secondary" id="new-folder"><i data-lucide="folder-plus"></i> New folder</button></div><div class="file-list">${rows.map(e=>`<button class="file-row" data-entry="${esc(e.path)}" data-type="${e.type}"><span class="file-icon"><i data-lucide="${e.type==='dir'?'folder':'file'}"></i></span><span>${esc(e.name)}</span><small>${e.type==='dir'?'Folder':(e.size??0)+' B'}</small><i data-lucide="chevron-right"></i></button>`).join('')||'<div class="empty">This folder is empty.</div>'}</div>`;
  }
  editorView() {
    const tab=this.activeTab();
    return `<div class="editor-head"><div class="editor-title"><button class="icon-btn" id="files-back"><i data-lucide="chevron-left"></i></button><div><b>${tab?esc(tab.name):'Editor'}</b><small id="editor-status">${tab?.dirty?'Unsaved draft · stored locally':'All changes committed'}</small></div></div><div class="editor-actions"><button class="icon-btn" id="editor-search" title="Find"><i data-lucide="search"></i></button><button class="icon-btn" id="repo-code-search" title="Search repository"><i data-lucide="scan-search"></i></button><button class="icon-btn" id="fullscreen" title="Full screen"><i data-lucide="${this.state.fullEditor?'minimize-2':'maximize-2'}"></i></button><button class="primary save-btn" id="save"><i data-lucide="save"></i> Save</button></div></div><div class="tabs">${this.state.tabs.map(t=>`<button class="tab ${t.key===this.state.active?'selected':''}" data-tab="${esc(t.key)}">${t.dirty?'<span class="dirty-dot"></span>':''}${esc(t.name)}<span class="tab-close" data-close="${esc(t.key)}">×</span></button>`).join('')}</div>${tab?`<div id="code-host" class="code-host"></div><div class="editor-footer"><span>${esc(tab.path)}</span><div class="file-edit-actions"><button class="text-btn" id="rename-file"><i data-lucide="pencil"></i> Rename</button><button class="danger-text" id="delete-file"><i data-lucide="trash-2"></i> Delete</button></div></div>`:'<div class="empty editor-empty">Open a file from a repository to start editing.</div>'}`;
  }
  settingsView() {
    const s=this.state.settings;
    return `<div class="page-head"><div><div class="eyebrow">PREFERENCES</div><h1>Settings</h1><p>Customize your mobile workspace.</p></div></div><section class="settings-group"><h2>Appearance</h2><label class="setting-row"><span><b>Theme</b><small>Choose the editor and app appearance</small></span><select id="theme"><option value="dark" ${s.theme==='dark'?'selected':''}>Dark</option><option value="light" ${s.theme==='light'?'selected':''}>Light</option></select></label><label class="setting-row"><span><b>Editor font size</b><small>Current: ${s.fontSize}px</small></span><input id="font-size" type="range" min="11" max="22" value="${s.fontSize}"></label><label class="setting-row"><span><b>Tab size</b><small>Indentation preference</small></span><select id="tab-size">${[2,4,8].map(n=>`<option ${s.tabSize===n?'selected':''}>${n}</option>`).join('')}</select></label><label class="setting-row"><span><b>Word wrapping</b><small>Wrap long lines in editor</small></span><input type="checkbox" id="wrap" ${s.wrap?'checked':''}></label><label class="setting-row"><span><b>Autosave drafts</b><small>Store unfinished edits locally</small></span><input type="checkbox" id="autosave" ${s.autosave?'checked':''}></label></section><section class="settings-group"><h2>Account</h2><div class="account-row"><img class="avatar large" src="${esc(this.state.user.avatar_url)}"><div><b>${esc(this.state.user.name||this.state.user.login)}</b><small>@${esc(this.state.user.login)}</small></div><span class="connected">Connected</span></div><button class="danger wide" id="logout"><i data-lucide="log-out"></i> Sign out of GitHub</button></section><div class="app-version">GitHub Mobile IDE · Version 1.0.0</div>`;
  }
  bindUI() {
    this.root.querySelectorAll('[data-screen]').forEach(b=>b.onclick=()=>this.setScreen(b.dataset.screen));
    this.root.querySelector('#login')?.addEventListener('click',()=>this.login());
    this.root.querySelector('#logout')?.addEventListener('click',()=>this.logout());
    this.root.querySelector('#refresh')?.addEventListener('click',()=>this.run(()=>this.loadRepos()));
    this.root.querySelector('#refresh-files')?.addEventListener('click',()=>this.run(()=>this.loadDirectory()));
    this.root.querySelector('#repo-search')?.addEventListener('input',e=>{this.state.query=e.target.value;const pos=e.target.selectionStart;this.render();const n=this.root.querySelector('#repo-search');n.focus();n.setSelectionRange(pos,pos);});
    this.root.querySelector('#file-search')?.addEventListener('input',e=>{this.state.query=e.target.value;this.render();const n=this.root.querySelector('#file-search');n.focus();n.setSelectionRange(n.value.length,n.value.length);});
    this.root.querySelectorAll('[data-repo]').forEach(b=>b.onclick=()=>{const r=this.state.repos.find(x=>x.full_name===b.dataset.repo);this.state.query='';this.run(()=>this.openRepo(r));});
    this.root.querySelectorAll('[data-entry]').forEach(b=>b.onclick=()=>{const e=this.state.entries.find(x=>x.path===b.dataset.entry);this.openEntry(e);});
    this.root.querySelector('#back')?.addEventListener('click',()=>{this.state.path=this.state.path.split('/').slice(0,-1).join('/');this.state.query='';this.run(()=>this.loadDirectory());});
    this.root.querySelector('#branch-select')?.addEventListener('change',e=>this.changeBranch(e.target.value));
    this.root.querySelector('#new-file')?.addEventListener('click',()=>this.createFile());
    this.root.querySelector('#new-folder')?.addEventListener('click',()=>this.createFolder());
    this.root.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{this.state.active=b.dataset.tab;this.render();});
    this.root.querySelectorAll('[data-close]').forEach(b=>b.onclick=e=>{e.stopPropagation();const key=b.dataset.close;const tab=this.state.tabs.find(t=>t.key===key);if(tab?.dirty&&!confirm('Close this tab? Its local draft will be kept.'))return;this.state.tabs=this.state.tabs.filter(t=>t.key!==key);if(this.state.active===key)this.state.active=this.state.tabs.at(-1)?.key||null;this.render();});
    this.root.querySelector('#files-back')?.addEventListener('click',()=>{this.state.screen='files';this.render();});
    this.root.querySelector('#save')?.addEventListener('click',()=>this.saveActive());
    this.root.querySelector('#delete-file')?.addEventListener('click',()=>this.deleteActive());
    this.root.querySelector('#rename-file')?.addEventListener('click',()=>this.renameActive());
    this.root.querySelector('#repo-code-search')?.addEventListener('click',()=>this.repositorySearch());
    this.root.querySelector('#fullscreen')?.addEventListener('click',()=>{this.state.fullEditor=!this.state.fullEditor;this.render();});
    this.root.querySelector('#editor-search')?.addEventListener('click',()=>{if(this.editor?.view){this.editor.view.focus();import('@codemirror/search').then(m=>m.openSearchPanel(this.editor.view));}});
    this.root.querySelector('#theme')?.addEventListener('change',e=>this.setSetting('theme',e.target.value));
    this.root.querySelector('#font-size')?.addEventListener('change',e=>this.setSetting('fontSize',Number(e.target.value)));
    this.root.querySelector('#tab-size')?.addEventListener('change',e=>this.setSetting('tabSize',Number(e.target.value)));
    this.root.querySelector('#wrap')?.addEventListener('change',e=>this.setSetting('wrap',e.target.checked));
    this.root.querySelector('#autosave')?.addEventListener('change',e=>this.setSetting('autosave',e.target.checked));
  }
}
