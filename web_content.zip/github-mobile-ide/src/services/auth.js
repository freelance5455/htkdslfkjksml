import { Capacitor } from '@capacitor/core';
import { Browser } from '@capacitor/browser';
import { App } from '@capacitor/app';
import { SecureStorage } from '@aparajita/capacitor-secure-storage';

const API = import.meta.env.VITE_OAUTH_BACKEND_URL || 'http://localhost:8787';
const TOKEN_KEY = 'github_access_token';
const USER_KEY = 'github_user';

export class AuthService {
  constructor() { this.listener = null; }
  async token() {
    try {
      const result = await SecureStorage.get({ key: TOKEN_KEY });
      return result?.value || null;
    } catch { return null; }
  }
  async user() {
    try {
      const result = await SecureStorage.get({ key: USER_KEY });
      return result?.value ? JSON.parse(result.value) : null;
    } catch { return null; }
  }
  async save(token, user) {
    await SecureStorage.set({ key: TOKEN_KEY, value: token });
    await SecureStorage.set({ key: USER_KEY, value: JSON.stringify(user) });
  }
  async logout() {
    await SecureStorage.remove({ key: TOKEN_KEY });
    await SecureStorage.remove({ key: USER_KEY });
  }
  async login(onSuccess, onError) {
    const redirect = 'githubmobileide://auth';
    const url = `${API}/auth/github/start?redirect_uri=${encodeURIComponent(redirect)}`;
    if (Capacitor.isNativePlatform()) {
      this.listener = await App.addListener('appUrlOpen', async ({ url: incoming }) => {
        if (!incoming?.startsWith(redirect)) return;
        try {
          await Browser.close();
          const parsed = new URL(incoming);
          const code = parsed.searchParams.get('code');
          if (!code) throw new Error(parsed.searchParams.get('error') || 'Authentication was cancelled.');
          const response = await fetch(`${API}/auth/github/exchange`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ code })
          });
          const payload = await response.json();
          if (!response.ok) throw new Error(payload.error || 'Authentication failed.');
          await this.save(payload.token, payload.user);
          await this.listener?.remove(); this.listener = null;
          onSuccess(payload.user);
        } catch (error) { onError(error); }
      });
      await Browser.open({ url });
    } else {
      window.location.href = url;
    }
  }
}
