const API = 'https://api.github.com';
export class GitHubService {
  constructor(auth) { this.auth = auth; }
  async request(path, options = {}) {
    const token = await this.auth.token();
    if (!token) throw new Error('Connect your GitHub account first.');
    const response = await fetch(`${API}${path}`, {
      ...options,
      headers: {
        Accept: 'application/vnd.github+json',
        Authorization: `Bearer ${token}`,
        'X-GitHub-Api-Version': '2022-11-28',
        ...(options.body ? { 'Content-Type': 'application/json' } : {}),
        ...options.headers
      }
    });
    if (response.status === 204) return null;
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data.message || `GitHub API error (${response.status})`);
      error.status = response.status;
      error.rateLimit = response.status === 403 && response.headers.get('X-RateLimit-Remaining') === '0';
      throw error;
    }
    return data;
  }
  async user() { return this.request('/user'); }
  async repos() {
    let page = 1, all = [];
    while (page <= 5) {
      const batch = await this.request(`/user/repos?per_page=100&sort=updated&page=${page}`);
      all = all.concat(batch);
      if (batch.length < 100) break;
      page++;
    }
    return all;
  }
  branches(owner, repo) { return this.request(`/repos/${owner}/${repo}/branches?per_page=100`); }
  contents(owner, repo, path = '', branch) {
    const query = branch ? `?ref=${encodeURIComponent(branch)}` : '';
    return this.request(`/repos/${owner}/${repo}/contents/${path.split('/').map(encodeURIComponent).join('/')}${query}`);
  }
  async readFile(owner, repo, path, branch) {
    const item = await this.contents(owner, repo, path, branch);
    if (Array.isArray(item) || item.type !== 'file') throw new Error('This is not a regular file.');
    if (item.size > 1_500_000) throw new Error('File is too large for the mobile editor (1.5 MB limit).');
    if (item.encoding !== 'base64') throw new Error('Unsupported or binary file. It can be browsed but not edited.');
    const binary = atob(item.content.replace(/\n/g, ''));
    const bytes = Uint8Array.from(binary, c => c.charCodeAt(0));
    const content = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
    return { content, sha: item.sha, size: item.size };
  }
  async saveFile(owner, repo, path, content, message, branch, sha) {
    const body = { message, content: btoa(unescape(encodeURIComponent(content))), branch };
    if (sha) body.sha = sha;
    return this.request(`/repos/${owner}/${repo}/contents/${path.split('/').map(encodeURIComponent).join('/')}`, {
      method: 'PUT', body: JSON.stringify(body)
    });
  }
  searchCode(owner, repo, query) {
    return this.request(`/search/code?q=${encodeURIComponent(query)}+repo:${encodeURIComponent(owner+'/'+repo)}&per_page=50`);
  }
  async deleteFile(owner, repo, path, message, branch, sha) {
    return this.request(`/repos/${owner}/${repo}/contents/${path.split('/').map(encodeURIComponent).join('/')}`, {
      method: 'DELETE', body: JSON.stringify({ message, sha, branch })
    });
  }
  async createFolder(owner, repo, path, branch) {
    const readme = `# ${path.split('/').pop()}\n`;
    return this.saveFile(owner, repo, `${path}/.gitkeep`, readme, `Create folder ${path}`, branch, null);
  }
}
