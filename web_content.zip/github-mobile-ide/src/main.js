import './styles.css';
import { createIcons, Github, Home, FolderGit2, Code2, Settings, Search, RefreshCw, Plus, ChevronRight, ChevronLeft, GitBranch, Save, Cloud, CloudOff, LogOut, Moon, Sun, File, Folder, MoreHorizontal, X, Check, AlertTriangle, Menu, Trash2, Pencil, ArrowUpDown, Maximize2, Minimize2, Wifi, WifiOff } from 'lucide';
import { AppController } from './app.js';

const iconSet = { Github, Home, FolderGit2, Code2, Settings, Search, RefreshCw, Plus, ChevronRight, ChevronLeft, GitBranch, Save, Cloud, CloudOff, LogOut, Moon, Sun, File, Folder, MoreHorizontal, X, Check, AlertTriangle, Menu, Trash2, Pencil, ArrowUpDown, Maximize2, Minimize2, Wifi, WifiOff };
window.refreshIcons = () => createIcons({ icons: iconSet, attrs: { 'stroke-width': 1.8 } });
new AppController(document.querySelector('#app')).start();
