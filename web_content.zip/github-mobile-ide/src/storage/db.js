import { openDB } from 'idb';

const dbPromise = openDB('github-mobile-ide', 1, {
  upgrade(db) {
    db.createObjectStore('drafts', { keyPath: 'key' });
    db.createObjectStore('files', { keyPath: 'key' });
    db.createObjectStore('settings', { keyPath: 'key' });
    db.createObjectStore('recent', { keyPath: 'id' });
  }
});
export const db = {
  async get(store, key) { return (await dbPromise).get(store, key); },
  async put(store, value) { return (await dbPromise).put(store, value); },
  async delete(store, key) { return (await dbPromise).delete(store, key); },
  async all(store) { return (await dbPromise).getAll(store); },
  async clear(store) { return (await dbPromise).clear(store); }
};
