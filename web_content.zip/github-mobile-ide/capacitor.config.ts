import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.githubmobileide.app',
  appName: 'GitHub Mobile IDE',
  webDir: 'dist',
  bundledWebRuntime: false,
  server: { androidScheme: 'https' }
};
export default config;
