import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { randomBytes, createHash, timingSafeEqual } from 'node:crypto';
import rateLimit from 'express-rate-limit';
dotenv.config();
const app=express();
const port=Number(process.env.PORT||8787);
const clientId=process.env.GITHUB_CLIENT_ID;
const clientSecret=process.env.GITHUB_CLIENT_SECRET;
const callback=process.env.OAUTH_CALLBACK_URL;
const allowed=(process.env.ALLOWED_REDIRECTS||'githubmobileide://auth').split(',');
if(!clientId||!clientSecret||!callback) console.warn('OAuth environment is incomplete; login will not work until configured.');
app.use(cors({origin:true,methods:['GET','POST'],allowedHeaders:['Content-Type']}));
app.use(express.json({limit:'20kb'}));
app.use(rateLimit({windowMs:60_000,max:30,standardHeaders:true,legacyHeaders:false}));
const states=new Map(), codes=new Map();
const b64=s=>Buffer.from(s).toString('base64url');
const safeEqual=(a,b)=>{const x=Buffer.from(a),y=Buffer.from(b);return x.length===y.length&&timingSafeEqual(x,y);};
app.get('/health',(_,res)=>res.json({ok:true}));
app.get('/auth/github/start',(req,res)=>{
  if(!clientId||!callback)return res.status(503).json({error:'OAuth backend is not configured.'});
  const redirect=req.query.redirect_uri;
  if(typeof redirect!=='string'||!allowed.includes(redirect))return res.status(400).json({error:'Redirect URI is not allowed.'});
  const state=randomBytes(32).toString('hex');
  states.set(state,{redirect,created:Date.now()});
  const url=new URL('https://github.com/login/oauth/authorize');
  url.searchParams.set('client_id',clientId);
  url.searchParams.set('redirect_uri',callback);
  url.searchParams.set('scope','repo read:user user:email');
  url.searchParams.set('state',state);
  res.redirect(url.toString());
});
app.get('/auth/github/callback',async(req,res)=>{
  const {code,state,error}=req.query;
  const record=states.get(state); states.delete(state);
  if(error||!record||Date.now()-record.created>5*60_000)return res.status(400).send('GitHub authentication failed. You may close this page and retry.');
  try{
    const tokenResponse=await fetch('https://github.com/login/oauth/access_token',{
      method:'POST',headers:{Accept:'application/json','Content-Type':'application/json'},
      body:JSON.stringify({client_id:clientId,client_secret:clientSecret,code})
    });
    const tokenData=await tokenResponse.json();
    if(!tokenResponse.ok||tokenData.error||!tokenData.access_token)throw new Error(tokenData.error_description||'Token exchange failed');
    const oneTime=randomBytes(32).toString('hex');
    codes.set(oneTime,{token:tokenData.access_token,created:Date.now()});
    res.redirect(`${record.redirect}?code=${encodeURIComponent(oneTime)}`);
  }catch(e){res.status(502).send('Could not complete GitHub sign-in: '+e.message);}
});
app.post('/auth/github/exchange',(req,res)=>{
  const code=req.body?.code;
  if(typeof code!=='string'||! /^[a-f0-9]{64}$/.test(code))return res.status(400).json({error:'Invalid exchange code.'});
  const item=codes.get(code); codes.delete(code);
  if(!item||Date.now()-item.created>60_000)return res.status(400).json({error:'Exchange code expired or already used.'});
  fetch('https://api.github.com/user',{headers:{Authorization:`Bearer ${item.token}`,Accept:'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'}})
    .then(r=>r.json()).then(user=>{
      if(!user.login)return res.status(502).json({error:'Could not verify GitHub account.'});
      res.json({token:item.token,user});
    }).catch(()=>res.status(502).json({error:'Could not retrieve GitHub profile.'}));
});
app.listen(port,()=>console.log(`OAuth service listening on ${port}`));
