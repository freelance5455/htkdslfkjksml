# GitHub Mobile IDE

A mobile-first GitHub repository browser and code editor built with Vite, Vanilla JavaScript, CodeMirror 6 and Capacitor.

## Features

- GitHub OAuth through a separate confidential-client backend (no client secret in the APK).
- Native secure token storage using `@aparajita/capacitor-secure-storage`.
- Repository and branch browsing through the GitHub REST API.
- File/folder navigation, file creation and folder creation (`.gitkeep`).
- CodeMirror editor with language modes, line numbers, folding, search, undo/redo, bracket matching and wrapping.
- Local IndexedDB drafts and cached directory listings.
- Explicit commit workflow; editing never commits automatically.
- Remote SHA check before updating/deleting to reduce accidental overwrites.
- Android deep-link sign-in callback.

## Requirements

- Node.js 22 or newer and npm.
- Android Studio + Android SDK for local APK builds.
- A publicly reachable HTTPS host for the OAuth backend in production.
- GitHub OAuth App credentials.

## 1. Install the web project

```bash
npm install
npm run dev
```

The development preview runs at `http://localhost:5173`. GitHub sign-in requires the OAuth backend described below.

## 2. Configure GitHub OAuth

Create a GitHub OAuth App in GitHub Developer Settings:
- Homepage URL: your public application information page.
- Authorization callback URL: `https://YOUR_BACKEND_HOST/auth/github/callback`.

Deploy `backend/` to a trusted HTTPS server. Configure its environment using `backend/.env.example`:
- `GITHUB_CLIENT_ID`
- `GITHUB_CLIENT_SECRET` (server only; never place this in Vite variables or the Android project)
- `OAUTH_CALLBACK_URL`
- `ALLOWED_REDIRECTS=githubmobileide://auth,http://localhost:5173/auth`
- `PORT`

Run the backend with:

```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your GitHub OAuth App values and real HTTPS domain.
npm start
```

Set the frontend's backend URL in a root `.env` file:

```env
VITE_OAUTH_BACKEND_URL=https://YOUR_BACKEND_HOST
```

Restart Vite after changing environment variables. For local browser testing, add `http://localhost:5173/auth` to the allowed redirects and implement a browser callback route if you want to use browser-based login. The supported production sign-in flow targets the Android custom URL scheme.

### OAuth backend deployment note

The included backend uses in-memory, one-time state and exchange-code stores for a single-instance demonstration deployment. For production with multiple instances or restarts, replace these maps with a shared short-lived store (Redis/database), enforce a strict CORS origin allowlist, use HTTPS only, add structured audit logging and operational monitoring, and configure rate limits at the hosting edge. Never log access tokens. GitHub OAuth Apps do not provide PKCE in the same way GitHub Apps do; keep the confidential client secret exclusively on the backend.

## 3. Add Android

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

In Android Studio, use the generated Android project. Set the app's network permission if it is not already present (Capacitor normally includes it). Add this intent filter inside the `MainActivity` activity in `android/app/src/main/AndroidManifest.xml` so the OAuth callback opens the app:

```xml
<intent-filter android:autoVerify="false">
  <action android:name="android.intent.action.VIEW" />
  <category android:name="android.intent.category.DEFAULT" />
  <category android:name="android.intent.category.BROWSABLE" />
  <data android:scheme="githubmobileide" android:host="auth" />
</intent-filter>
```

Re-run `npx cap sync android` after native plugin/configuration changes. The secure-storage plugin requires a native Android build; browser preview cannot persist credentials through the native secure store.

## 4. Build APK

Local debug APK:

```bash
npm install
npm run build
npx cap sync android
cd android
./gradlew assembleDebug
```

Output: `android/app/build/outputs/apk/debug/app-debug.apk`.

The GitHub Actions workflow at `.github/workflows/android-build.yml` creates a debug APK artifact on push to main/master or manual dispatch. For a release APK/AAB, configure Android signing credentials as GitHub Actions secrets and add a signed release Gradle task. Do not commit signing keys.

## 5. Test checklist

1. Deploy the OAuth backend with HTTPS and valid GitHub OAuth settings.
2. Install the debug APK on an Android device and test GitHub sign-in.
3. Confirm the account avatar and repository list appear.
4. Open a repository, switch branch, navigate folders and open supported text files.
5. Edit a file, close/reopen the tab and confirm the local draft remains.
6. Press **Save**, enter a commit message and verify the commit on GitHub.
7. Edit the same file elsewhere before saving; confirm the app detects the changed SHA and preserves the local draft.
8. Disable network and verify cached directory browsing and already-open draft editing.
9. Test create-file, create-folder, delete, logout, dark/light preference and Android keyboard behavior.

## Important implementation boundaries

- GitHub REST API write permissions are requested with the `repo` OAuth scope. Users should only authorize accounts/repositories they trust.
- GitHub Contents API writes are limited by GitHub's API semantics and file-size limits. This editor intentionally refuses binary files and files larger than 1.5 MB.
- Offline support caches directory listings and locally persisted drafts. It does not mirror entire repositories for offline browsing.
- Search/replace uses CodeMirror's editor search panel. Repository-wide code search uses GitHub's Code Search REST endpoint and may be subject to GitHub's code-search indexing, permission and rate-limit restrictions.
- Luau is highlighted using the JavaScript grammar as a practical fallback; a dedicated Luau grammar can be added later.
- Renaming is implemented as two explicit GitHub Contents API commits (create destination, then delete source), because GitHub does not expose an atomic rename operation through that API. If the delete step fails, the app warns that both copies may remain.
- The app never auto-commits edits. Turning off autosave disables background draft writes; press Save only to open the explicit commit dialog.
