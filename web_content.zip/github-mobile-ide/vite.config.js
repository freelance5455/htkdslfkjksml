import { defineConfig } from 'vite';
export default defineConfig({
  server: { host: '0.0.0.0', port: 5173 },
  build: { sourcemap: false, target: 'es2022' }
});
