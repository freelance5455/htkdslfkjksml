(function () {
  "use strict";

  var hasBridge = typeof Android !== "undefined";
  var goBtn = document.getElementById("go");
  var enableBtn = document.getElementById("enable");
  var accessEl = document.getElementById("access-state");
  var statusEl = document.getElementById("status");

  var enabled = hasBridge ? Android.isEnabled() : false;
  var state = "idle";

  var messages = {
    idle: "",
    running: "در حال پاکسازی… صبر کنید",
    done: "پاکسازی تمام شد",
    timeout: "کامل نشد. متن دکمه‌ها را در CleanService.kt بررسی کنید"
  };

  function render() {
    if (!hasBridge) {
      accessEl.textContent = "پیش‌نمایش مرورگر (در اپ اندروید کار می‌کند)";
      accessEl.className = "state";
      enableBtn.className = "outline hidden";
    } else if (enabled) {
      accessEl.textContent = "دسترسی‌پذیری فعال است";
      accessEl.className = "state on";
      enableBtn.className = "outline hidden";
    } else {
      accessEl.textContent = "دسترسی‌پذیری هنوز فعال نیست";
      accessEl.className = "state off";
      enableBtn.className = "outline";
    }
    statusEl.textContent = messages[state] || "";
    goBtn.className = state === "running" ? "fab busy" : "fab";
  }

  window.onStatus = function (isEnabled, newState) {
    enabled = isEnabled;
    state = newState;
    render();
  };

  enableBtn.addEventListener("click", function () {
    if (hasBridge) Android.openAccessibility();
  });

  goBtn.addEventListener("click", function () {
    if (!hasBridge) {
      statusEl.textContent = "این فقط پیش‌نمایش است؛ اپ را روی گوشی نصب کنید";
      return;
    }
    if (!enabled) {
      Android.openAccessibility();
      return;
    }
    if (state === "running") return;
    Android.startClean();
  });

  render();
})();
