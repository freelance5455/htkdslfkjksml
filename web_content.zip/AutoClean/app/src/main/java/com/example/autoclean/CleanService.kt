package com.example.autoclean

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class CleanService : AccessibilityService() {

    companion object {
        var instance: CleanService? = null

        // وضعیت را به صفحهٔ وب می‌فرستد: running, done, timeout
        var listener: ((String) -> Unit)? = null

        const val TARGET = "com.miui.securitycenter"

        // هر مرحله: لیست متن‌های ممکن برای دکمه (انگلیسی و فارسی).
        // اگر دکمه‌ها در گوشی شما اسم دیگری دارند، همین‌جا درستشان کنید.
        val STEPS = listOf(
            listOf("Cleaner", "پاک‌کننده", "پاکسازی", "Clean up"),
            listOf("Clean up", "Clean now", "پاکسازی", "پاک کردن", "پاک‌سازی"),
            listOf("Boost speed", "افزایش سرعت", "Boost")
        )
    }

    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var step = 0
    private var lastClick = 0L

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    fun start() {
        val intent = packageManager.getLaunchIntentForPackage(TARGET)
        if (intent == null) {
            Toast.makeText(applicationContext, "برنامهٔ Security پیدا نشد", Toast.LENGTH_LONG).show()
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        step = 0
        lastClick = 0L
        running = true
        listener?.invoke("running")
        startActivity(intent)
        // ایمنی: بعد از ۶۰ ثانیه خودکار متوقف می‌شود
        handler.postDelayed({ if (running) stop("timeout") }, 60_000)
    }

    private fun stop(state: String) {
        running = false
        handler.removeCallbacksAndMessages(null)
        listener?.invoke(state)
        val msg = if (state == "done") "پاکسازی تمام شد" else "زمان تمام شد؛ متن دکمه‌ها را در STEPS بررسی کنید"
        Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()
        try {
            val back = packageManager.getLaunchIntentForPackage(packageName)
            back?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            if (back != null) startActivity(back)
        } catch (e: Exception) {
            // اگر سیستم اجازه نداد، مشکلی نیست
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!running || event == null) return
        if (event.packageName != TARGET) return
        if (step >= STEPS.size) return
        if (System.currentTimeMillis() - lastClick < 1500) return

        val root = rootInActiveWindow ?: return
        for (label in STEPS[step]) {
            val nodes = root.findAccessibilityNodeInfosByText(label)
            for (node in nodes) {
                val target = clickableParent(node) ?: continue
                if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    lastClick = System.currentTimeMillis()
                    step++
                    if (step >= STEPS.size) {
                        handler.postDelayed({ if (running) stop("done") }, 3000)
                    }
                    return
                }
            }
        }
    }

    private fun clickableParent(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var cur = n
        while (cur != null) {
            if (cur.isClickable) return cur
            cur = cur.parent
        }
        return null
    }

    override fun onInterrupt() {
        if (running) stop("timeout")
    }
}
