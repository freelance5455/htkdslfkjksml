package com.example.autoclean

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        web.setBackgroundColor(Color.WHITE)
        web.settings.javaScriptEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pushStatus("idle")
            }

            // فقط صفحهٔ داخلی اپ اجازهٔ بارگذاری دارد
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                return request?.url?.toString()?.startsWith("file:///android_asset/") != true
            }
        }

        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")

        CleanService.listener = { state -> pushStatus(state) }
    }

    override fun onResume() {
        super.onResume()
        pushStatus("idle")
    }

    override fun onDestroy() {
        CleanService.listener = null
        super.onDestroy()
    }

    private fun pushStatus(state: String) {
        val enabled = CleanService.instance != null
        web.post {
            web.evaluateJavascript(
                "window.onStatus && window.onStatus($enabled, '$state')",
                null
            )
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun isEnabled(): Boolean = CleanService.instance != null

        @JavascriptInterface
        fun openAccessibility() {
            runOnUiThread {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        @JavascriptInterface
        fun startClean(): Boolean {
            val service = CleanService.instance ?: return false
            runOnUiThread { service.start() }
            return true
        }
    }
}
