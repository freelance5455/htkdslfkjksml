# AutoClean

پروژهٔ کامل Android Studio. رابط برنامه با HTML، CSS و JavaScript نوشته شده و داخل WebView نمایش داده می‌شود.
بخش دسترسی‌پذیری (که با وب ممکن نیست) با Kotlin نوشته شده است.

با زدن دکمهٔ سبز، برنامهٔ Security شیائومی باز می‌شود و دکمه‌های پاکسازی و Boost را خودکار می‌زند.

این برنامه رم مجازی نمی‌سازد؛ فقط پاکسازی را خودکار می‌کند.

## ساخت APK

1. Android Studio را باز کنید (نسخهٔ Hedgehog یا جدیدتر؛ JDK 17 داخل آن هست).
2. File ← Open و پوشهٔ AutoClean را انتخاب کنید.
3. صبر کنید Gradle همگام‌سازی شود (اینترنت لازم است).
4. Build ← Build Bundle(s) / APK(s) ← **Build APK(s)**
5. فایل خروجی: `app/build/outputs/apk/debug/app-debug.apk`

فایل APK را به گوشی منتقل و نصب کنید (نصب از منبع ناشناس را اجازه دهید).

## استفاده

1. اپ را باز کنید. اگر دسترسی‌پذیری روشن نبود، دکمهٔ «فعال‌سازی دسترسی‌پذیری» را بزنید.
2. در صفحهٔ باز شده، سرویس AutoClean را روشن کنید و به اپ برگردید (یک‌بار).
3. هر وقت خواستید، دکمهٔ سبز را بزنید.

## اگر دکمه‌ها را پیدا نکرد

این پروژه روی گوشی واقعی آزمایش نشده است. اسم دکمه‌ها در نسخه‌های MIUI فرق می‌کند.
متن واقعی دکمه‌های Security را در لیست `STEPS` داخل فایل زیر بنویسید:

`app/src/main/java/com/example/autoclean/CleanService.kt`

## ساختار فایل‌ها

- `app/src/main/assets/` : index.html، style.css، app.js (رابط)
- `app/src/main/java/com/example/autoclean/` : MainActivity.kt و CleanService.kt
- `app/src/main/res/xml/accessibility_config.xml` : تنظیمات سرویس (فقط برای Security)
- `app/src/main/AndroidManifest.xml`

## امنیت

سرویس دسترسی‌پذیری با `packageNames` فقط به برنامهٔ Security محدود شده است. این خط را برندارید.
