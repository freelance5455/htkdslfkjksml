plugins {
    id("com.android.application")
}

android {
    namespace = "com.nofap.countdown"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nofap.countdown"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Подписываем release тем же debug-ключом, чтобы APK сразу ставился на телефон
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
