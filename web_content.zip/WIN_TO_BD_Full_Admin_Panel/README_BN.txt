WIN TO BD Full Admin Studio — বাংলা নির্দেশনা
============================================
1) ZIP Extract করুন।
2) admin.html ফাইল Chrome-এ খুলুন।
3) App Design, Game Modes, Matches, Payments, Rules & Support থেকে তথ্য বদলান।
4) Save বোতাম চাপুন। সেটিংস একই ব্রাউজারে local storage-এ সেভ হবে।
5) Backup / Export থেকে JSON backup ডাউনলোড করতে পারবেন।

সীমাবদ্ধতা খুব গুরুত্বপূর্ণ:
- এটি একটি editable ADMIN UI prototype; এটি একা থেকে live app-এর code বদলায় না।
- অন্য ফোনে player app-এ পরিবর্তন পাঠাতে player app-কে একই backend/database-এর সাথে integrate করতে হবে।
- এখানে payment নম্বর সেট করা মানে টাকা auto-credit বা withdraw চালু হওয়া নয়।
- আসল wallet, login, slot locking, results, room ID/password, admin roles-এর জন্য secure backend,
  database rules এবং payment provider-এর approved API দরকার।
- HTML ফাইলে production admin password রাখা নিরাপদ নয়। production-এ server-side auth ব্যবহার করুন।
