BOOST MOBILE — prototype v1

CONTENU
- index.html : interface mobile du prototype
- manifest.json : métadonnées PWA
- README.txt : instructions

OUVRIR SUR ANDROID
1. Extraire le fichier ZIP dans le téléphone.
2. Ouvrir index.html avec Chrome.
3. Le prototype fonctionne localement pour la démonstration.

IMPORTANT
- Ce ZIP est un prototype web, pas encore un APK Android.
- Le formulaire ne transmet aucune commande à un serveur.
- Aucun paiement n'est encaissé ou vérifié automatiquement.
- Pour recevoir réellement les paiements, il faudra intégrer un compte marchand/API Airtel Money et un serveur sécurisé.
- Les services proposés doivent respecter les règles de TikTok. Ne demandez jamais le mot de passe TikTok ou le code secret Airtel Money d'un client.
- Les quantités et prix affichés sont ceux demandés : 2 000 likes = 2 000 FC ; 5 000 = 5 000 FC ; 10 000 = 10 000 FC.
- Numéro Airtel Money affiché : 0971274119. Vérifier que ce numéro est bien autorisé à recevoir les paiements avant toute publication.
