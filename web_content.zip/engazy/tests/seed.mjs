// Deterministic test data. Every date derives from TEST_BASE_DATE (default 2026-10-23),
// matching the fake clock used by the browser suite.
export default function seed() {
  const base = new Date(process.env.TEST_BASE_DATE || '2026-10-23T12:00:00');
  const k = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const add = n => { const d = new Date(base); d.setDate(d.getDate() + n); return k(d); };
  const t = k(base);
  const courses = [
    { id: 'c1', name: 'Fixed', lectures: [2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
    { id: 'c2', name: 'Removable Prosthodontics', lectures: [1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
    { id: 'c3', name: 'Oral pathology', lectures: [2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
    { id: 'c4', name: 'Operative', lectures: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] }
  ];
  const meta = {
    dailyLog: { [t]: ['c1:0', 'c1:1', 'c2:0'], [add(-1)]: ['c1:2', 'c3:0', 'c2:1'] },
    focusLog: { [t]: 25, [add(-2)]: 50 },
    lectureNotes: { 'c1:0': 'Crown margins: 1mm chamfer', 'c3:1': 'Odontogenic cysts vs tumors' },
    reviewSchedule: {
      'c1:0': { courseId: 'c1', lectureIndex: 0, count: 1, lastReviewed: add(-3), due: t },
      'c2:0': { courseId: 'c2', lectureIndex: 0, count: 1, lastReviewed: add(-7), due: add(-1) },
      'c1:1': { courseId: 'c1', lectureIndex: 1, count: 2, lastReviewed: add(-7), due: add(2) },
      'c3:0': { courseId: 'c3', lectureIndex: 0, count: 0, lastReviewed: add(-1), due: add(5) }
    },
    exams: [
      { id: 'e1', courseId: 'c1', courseName: 'Fixed', date: add(2), title: 'Midterm' },
      { id: 'e2', courseId: 'c3', courseName: 'Oral pathology', date: add(-4), title: 'Quiz 1' },
      { id: 'e3', courseId: 'c2', courseName: 'Removable Prosthodontics', date: add(20), title: 'Final' }
    ],
    reviewScheduleInitialized: true
  };
  const settings = { deadline: add(30), hours: 3, theme: 'light' };
  return { courses, meta, settings };
}
