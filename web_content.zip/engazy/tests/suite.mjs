// Behavioural suite for index.html (Playwright + Chromium) and the local Worker.
// Each case is isolated: its own timeout, all of its browser contexts are closed afterwards,
// and failures never stop the run. The summary is always printed.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import seed from './seed.mjs';
import workerModule from '../engazy-ai-proxy.js';

const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PLAYWRIGHT_PATH || 'playwright');
const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..');
const APP = path.join(ROOT, 'index.html');
const SHOTS = path.join(HERE, 'screenshots');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'engazy-test-'));
fs.mkdirSync(SHOTS, { recursive: true });
const CLOCK = new Date('2026-10-23T10:00:00Z');
const KEYS = { courses: 'engazy-study-tracker-v1', meta: 'engazy-study-meta-v2', settings: 'engazy-plan-settings-v2', snaps: 'engazy-snapshots-v1' };
const sleep = ms => new Promise(r => setTimeout(r, ms));

const results = [];
const check = (name, ok, info = '') => {
  results.push({ name, ok: !!ok });
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${info ? '  ' + info : ''}`);
};

let browser;
const openContexts = [];
const servers = [];

async function runCase(name, fn, timeoutMs = 150000) {
  const started = Date.now();
  const work = (async () => { try { await fn(); } catch (e) { check(`${name} :: threw`, false, String(e.message).split('\n')[0]); } })();
  let timer;
  const timedOut = new Promise(res => { timer = setTimeout(() => res('TIMEOUT'), timeoutMs); });
  const outcome = await Promise.race([work.then(() => 'DONE'), timedOut]);
  clearTimeout(timer);
  if (outcome === 'TIMEOUT') check(`${name} :: timed out after ${timeoutMs / 1000}s`, false);
  for (const c of openContexts.splice(0)) { try { await Promise.race([c.close(), sleep(4000)]); } catch (e) {} }
  console.log(`      [${name}: ${((Date.now() - started) / 1000).toFixed(1)}s]`);
}

// ---------------- browser helpers ----------------
function initFn(s) {
  if (!localStorage.getItem('__seeded')) {
    localStorage.clear();
    localStorage.setItem('engazy-study-tracker-v1', JSON.stringify(s.data.courses));
    localStorage.setItem('engazy-study-meta-v2', JSON.stringify(s.data.meta));
    localStorage.setItem('engazy-plan-settings-v2', JSON.stringify(s.data.settings));
    localStorage.setItem('__seeded', '1');
  }
  if (s.native) {
    window.__pending = []; window.__cancelled = 0; window.__scheduleCalls = 0;
    window.Capacitor = { Plugins: { LocalNotifications: {
      checkPermissions: async () => ({ display: s.grant }),
      requestPermissions: async () => ({ display: s.grant }),
      getPending: async () => ({ notifications: window.__pending.map(n => ({ id: n.id })) }),
      cancel: async ({ notifications }) => {
        window.__cancelled += notifications.length;
        window.__pending = window.__pending.filter(p => !notifications.some(n => n.id === p.id));
      },
      schedule: async ({ notifications }) => {
        window.__scheduleCalls += notifications.length;
        window.__pending = window.__pending.concat(notifications);
      }
    } } };
  }
}

async function open(o = {}) {
  const ctx = await browser.newContext({
    locale: 'ar-EG', acceptDownloads: true,
    viewport: o.viewport || { width: 390, height: 844 },
    isMobile: !!o.mobile, hasTouch: !!o.mobile,
    timezoneId: o.timezoneId || 'UTC'
  });
  openContexts.push(ctx);
  ctx.setDefaultTimeout(10000);
  const p = await ctx.newPage();
  p.errs = []; p.dialogs = [];
  p.on('pageerror', e => p.errs.push(e.message));
  p.on('console', m => { if (m.type() === 'error' && !m.text().includes('ERR_NAME_NOT_RESOLVED')) p.errs.push(m.text()); });
  p.on('dialog', d => { p.dialogs.push(d.message()); d.dismiss(); });
  if (o.clock !== false) await p.clock.install({ time: CLOCK });
  await p.addInitScript(initFn, { data: o.data || seed(), native: !!o.native, grant: o.grant || 'granted' });
  await p.goto('file://' + APP, { waitUntil: 'domcontentloaded' });
  await p.waitForTimeout(250);
  return p;
}
const readLS = (p, key) => p.evaluate(k => JSON.parse(localStorage.getItem(k)), key);
const meta = p => readLS(p, KEYS.meta);
const courses = p => readLS(p, KEYS.courses);
const settingsOf = p => readLS(p, KEYS.settings);
const isOpen = (p, id) => p.evaluate(i => document.getElementById(i).classList.contains('show'), id);
const pendingISO = p => p.evaluate(() => window.__pending.map(n => ({ id: n.id, title: n.title, body: n.body, iso: new Date(n.schedule.at).toISOString() })));
const unfold = t => t.replace(/\r\n[ \t]/g, '');
const download = async (p, trigger) => {
  const [d] = await Promise.all([p.waitForEvent('download', { timeout: 8000 }), trigger()]);
  return { name: d.suggestedFilename(), text: fs.readFileSync(await d.path(), 'utf8') };
};
const sameSet = (a, b) => JSON.stringify([...a].sort()) === JSON.stringify([...b].sort());
const noErrors = p => p.errs.length === 0;

// ---------------- local Worker: the real engazy-ai-proxy.js behind a tiny HTTP adapter ----------------
const REAL_FETCH = globalThis.fetch;
const upstreamLog = [];
function simulateAnthropic(expectedKey) {
  globalThis.fetch = async (url, init) => {
    if (String(url).startsWith('https://api.anthropic.com/')) {
      const body = JSON.parse(init.body);
      upstreamLog.push({ key: init.headers['x-api-key'], keyOk: init.headers['x-api-key'] === expectedKey, model: body.model, hasSystem: !!body.system });
      return new Response(JSON.stringify({ content: [{ type: 'text', text: `رد محاكى من خادم الاختبار على طلب من ${body.messages[0].content.length} حرف` }] }), { status: 200, headers: { 'content-type': 'application/json' } });
    }
    return REAL_FETCH(url, init);
  };
}
function startWorkerServer(port, env) {
  return new Promise(resolve => {
    const srv = http.createServer((req, res) => {
      let body = '';
      req.on('data', c => body += c);
      req.on('end', async () => {
        const headers = new Headers();
        for (const [k, v] of Object.entries(req.headers)) if (v && k !== 'host' && k !== 'content-length') headers.set(k, Array.isArray(v) ? v.join(', ') : v);
        const init = { method: req.method, headers };
        if (!['GET', 'HEAD'].includes(req.method)) init.body = body;
        const r = await workerModule.fetch(new Request(`http://localhost:${port}${req.url}`, init), env);
        const out = {}; r.headers.forEach((v, k) => { out[k] = v; });
        res.writeHead(r.status, out); res.end(await r.text());
      });
    });
    servers.push(srv);
    srv.listen(port, () => resolve(srv));
  });
}

try { browser = await chromium.launch({ headless: true }); }
catch (e) { check('launch chromium', false, String(e.message).split('\n')[0]); }

// ====================================================================================
// A. Static checks
// ====================================================================================
await runCase('A static', async () => {
  const html = fs.readFileSync(APP, 'utf8');
  const js = html.match(/<script>\n([\s\S]*)<\/script>/)[1];
  let compiled = true; try { new vm.Script(js); } catch (e) { compiled = false; }
  check('A1 inline script compiles (vm.Script)', compiled);
  const ids = new Set([...html.matchAll(/id="([^"]+)"/g)].map(m => m[1]));
  const refs = [...new Set([...js.matchAll(/\$\('([^']+)'\)/g)].map(m => m[1]))];
  check('A2 every $("id") used by the script exists in the HTML', refs.every(r => ids.has(r)), refs.filter(r => !ids.has(r)).join(',') || '');
  check('A3 no API key or Anthropic endpoint inside index.html', !/sk-ant|ANTHROPIC_API_KEY|api\.anthropic\.com/.test(html));
  check('A4 original storage keys unchanged', [KEYS.courses, KEYS.meta, KEYS.settings].every(k => html.includes(`'${k}'`)));
  const wk = spawnSync(process.execPath, ['--check', path.join(ROOT, 'engazy-ai-proxy.js')], { encoding: 'utf8' });
  check('A5 Worker source passes node --check', wk.status === 0, wk.stderr.split('\n')[0]);
});

// ====================================================================================
// B. Data compatibility: legacy backup, round trip, storage keys
// ====================================================================================
await runCase('B data', async () => {
  // B1 a v3-format backup (no lectureTitles/focusCourse/aiEndpoint fields) must restore cleanly
  const legacy = { app: 'Engazy', version: 3, courses: seed().courses.map(c => ({ id: c.id, name: c.name, lectures: c.lectures })), meta: { dailyLog: {}, lectureNotes: { 'c1:0': 'legacy note' }, reviewSchedule: {}, focusLog: {}, exams: [] }, settings: { deadline: '2026-11-30', hours: 2, theme: 'light' }, createdAt: '2026-10-01T00:00:00Z' };
  const file = path.join(TMP, 'legacy-v3-backup.json');
  fs.writeFileSync(file, JSON.stringify(legacy));
  const p = await open();
  await p.click('#settingsBtn');
  await p.setInputFiles('#restoreInput', file);
  await p.waitForTimeout(200);
  await p.click('#confirmYes');
  await p.waitForTimeout(300);
  const cs = await courses(p), m = await meta(p);
  check('B1 v3 backup restores courses', cs.length === 4 && cs[0].name === 'Fixed');
  check('B1 v3 backup restores notes, adds missing new fields', m.lectureNotes['c1:0'] === 'legacy note' && typeof m.lectureTitles === 'object' && typeof m.focusCourse === 'object');
  check('B1 v3 restore: no page errors', noErrors(p), p.errs.join('|'));
  await p.close();

  // B2 round trip: titles, notes and focus-per-course survive backup -> reset -> restore
  const p2 = await open();
  await p2.locator('#courseList .course').first().locator('button[data-act="toggle-course"]').click();
  await p2.click('button[data-act="rename-lecture"][data-id="c1"][data-lecture="0"]');
  await p2.fill('#lectureTitleInput', 'Round trip title');
  await p2.click('[data-act="save-title"]');
  const b = await download(p2, () => p2.click('.quick[data-act="backup"]'));
  check('B2 backup file has an ASCII name and is version-4 JSON', /^engazy-backup-\d{4}-\d{2}-\d{2}\.json$/.test(b.name) && JSON.parse(b.text).version === 4, b.name);
  await p2.click('#settingsBtn');
  await p2.click('#resetBtn');
  await p2.click('#confirmYes');
  await p2.waitForTimeout(200);
  check('B2 reset clears the title', !((await meta(p2)).lectureTitles || {})['c1:0']);
  const f2 = path.join(TMP, 'roundtrip-backup.json');
  fs.writeFileSync(f2, b.text);
  await p2.click('#settingsBtn');
  await p2.setInputFiles('#restoreInput', f2);
  await p2.waitForTimeout(200);
  await p2.click('#confirmYes');
  await p2.waitForTimeout(300);
  check('B2 restore brings back the lecture name', (await meta(p2)).lectureTitles['c1:0'] === 'Round trip title');
  check('B2 round trip: no page errors', noErrors(p2), p2.errs.join('|'));
  await p2.close();

  // B3 storage keys: the original three are written; the snapshot key is the only new one
  const p3 = await open();
  const keys = await p3.evaluate(() => Object.keys(localStorage).sort());
  check('B3 original storage keys present', [KEYS.courses, KEYS.meta, KEYS.settings].every(k => keys.includes(k)), keys.join(','));
  check('B3 only one new key added (snapshots)', keys.filter(k => !['engazy-study-tracker-v1', 'engazy-study-meta-v2', 'engazy-plan-settings-v2', '__seeded'].includes(k)).join() === KEYS.snaps, keys.join(','));
  await p3.close();
});

// ====================================================================================
// C. Lecture progress and review scheduling
// ====================================================================================
await runCase('C progress', async () => {
  const p = await open();
  const before = await p.textContent('#studiedCount');
  await p.locator('#courseList .course').filter({ hasText: 'Operative' }).locator('button[data-act="toggle-course"]').click();
  await p.click('.seg button[data-course="c4"][data-lecture="0"][data-status="1"]');
  check('C1 marking a lecture studied updates the summary', (await p.textContent('#studiedCount')) === String(Number(before) + 1), `(${before} -> ${await p.textContent('#studiedCount')})`);
  const m = await meta(p);
  check('C1 review schedule created for studied lecture (due tomorrow)', m.reviewSchedule['c4:0'] && m.reviewSchedule['c4:0'].due === '2026-10-24', JSON.stringify(m.reviewSchedule['c4:0']));
  check('C1 daily activity logged', (m.dailyLog['2026-10-23'] || []).includes('c4:0'));
  await p.click('.seg button[data-course="c4"][data-lecture="0"][data-status="0"]');
  check('C1 unmarking removes the review entry', !((await meta(p)).reviewSchedule['c4:0']) && (await p.textContent('#studiedCount')) === before);
  await p.click('.seg button[data-course="c4"][data-lecture="1"][data-status="2"]');
  check('C2 reviewed status counts in the reviewed total', Number(await p.textContent('#reviewedCount')) >= 4);
  check('C2 progress no page errors', noErrors(p), p.errs.join('|'));
  await p.close();
});

await runCase('C review completion', async () => {
  const p = await open();
  await p.click('.nav-btn[data-view="reviews"]');
  const due = await p.locator('#reviewDueList .review-item').count();
  check('C3 due review list shows overdue and due-today items', due === 2, `(${due})`);
  await p.locator('#reviewDueList .review-item').filter({ hasText: 'Fixed' }).locator('[data-act="review-complete"]').click();
  const r = (await meta(p)).reviewSchedule['c1:0'];
  check('C3 completing a review moves the next due date by the 2nd interval (7 days)', r.count === 2 && r.due === '2026-10-30', JSON.stringify({ count: r.count, due: r.due }));
  check('C3 review completion no page errors', noErrors(p), p.errs.join('|'));
  await p.close();
});

await runCase('C mark all', async () => {
  const p = await open();
  await p.locator('#courseList .course').filter({ hasText: 'Operative' }).locator('button[data-act="mark-all"]').click();
  const op = (await courses(p)).find(c => c.id === 'c4');
  check('C4 mark-all studies every lecture of the course', op.lectures.every(s => s === 1));
  check('C4 mark-all is reflected in the total', (await p.textContent('#studiedCount')) === '22', `(${await p.textContent('#studiedCount')})`);
  await p.close();
});

// ====================================================================================
// D. Lecture names and search
// ====================================================================================
await runCase('D names and search', async () => {
  const p = await open();
  await p.locator('#courseList .course').first().locator('button[data-act="toggle-course"]').click();
  await p.click('button[data-act="rename-lecture"][data-id="c1"][data-lecture="0"]');
  check('D1 rename dialog opens', await isOpen(p, 'titleBackdrop'));
  await p.fill('#lectureTitleInput', 'Crown margins');
  await p.click('[data-act="save-title"]');
  check('D1 name saved to meta.lectureTitles', (await meta(p)).lectureTitles['c1:0'] === 'Crown margins');
  check('D1 name shown in the lecture header', (await p.textContent('.lecture:first-child .lec-name')).includes('Crown margins'));
  await p.click('.nav-btn[data-view="reviews"]');
  check('D1 name shown in the review list', (await p.textContent('#reviewDueList')).includes('Crown margins'));
  await p.click('.nav-btn[data-view="home"]');
  await p.click('button[data-act="rename-lecture"][data-id="c1"][data-lecture="1"]');
  await p.fill('#lectureTitleInput', 'Temporary');
  await p.keyboard.press('Escape');
  check('D2 Escape closes the name dialog without saving', !(await isOpen(p, 'titleBackdrop')) && !(await meta(p)).lectureTitles['c1:1']);
  await p.click('button[data-act="rename-lecture"][data-id="c1"][data-lecture="1"]');
  await p.fill('#lectureTitleInput', 'Kept');
  await p.keyboard.press('Enter');
  await p.reload(); await p.waitForTimeout(200);
  check('D2 Enter saves and the name persists after reload', (await meta(p)).lectureTitles['c1:1'] === 'Kept');
  await p.locator('#courseList .course').first().locator('button[data-act="toggle-course"]').click();
  await p.click('button[data-act="rename-lecture"][data-id="c1"][data-lecture="1"]');
  await p.click('[data-act="clear-title"]');
  check('D2 clearing the name removes it', !((await meta(p)).lectureTitles['c1:1']));
  await p.fill('#searchInput', 'chamfer');
  check('D3 search by a note hides the course list and shows results', await p.isVisible('#searchResults') && !(await p.isVisible('#courseList')));
  check('D3 search result names the lecture', (await p.textContent('#searchResults')).includes('Fixed · Crown margins'));
  await p.click('#searchResults [data-act="open-lecture"]');
  await p.waitForTimeout(200);
  check('D3 opening a result clears the search and shows courses', (await p.inputValue('#searchInput')) === '' && await p.isVisible('#courseList'));
  await p.fill('#searchInput', 'operative');
  check('D4 search by course name', (await p.textContent('#searchResults')).includes('Operative'));
  await p.fill('#searchInput', 'zzz-nothing');
  check('D4 empty result message', (await p.textContent('#searchResults')).includes('لا توجد نتائج'));
  await p.fill('#searchInput', '');
  check('D4 clearing the search restores the course list', await p.isVisible('#courseList') && !(await p.isVisible('#searchResults')));
  check('D no page errors', noErrors(p), p.errs.join('|'));
  await p.close();
});

// ====================================================================================
// E. Focus timer, per-course focus totals, settings
// ====================================================================================
await runCase('E focus timer', async () => {
  const p = await open();
  await p.click('.nav-btn[data-view="focus"]');
  await p.click('#timerStartBtn');
  await p.clock.runFor(10000);
  check('E1 countdown after 10 s shows 24:50', (await p.textContent('#timerDisplay')) === '24:50', `(${await p.textContent('#timerDisplay')})`);
  await p.click('#timerStartBtn');
  const held = await p.textContent('#timerDisplay');
  await p.clock.runFor(30000);
  check('E1 pause holds the value', (await p.textContent('#timerDisplay')) === held);
  await p.click('#timerStartBtn');
  await p.clock.runFor(25 * 60 * 1000);
  check('E1 completing a focus session switches to the break', (await p.textContent('#timerModeLabel')).includes('الاستراحة'));
  check('E1 focus log increments by the session length', (await meta(p)).focusLog['2026-10-23'] === 25 + 25);
  await p.click('#timerResetBtn');
  check('E2 reset restarts the current phase (break stays 05:00 in break mode)', (await p.textContent('#timerDisplay')) === '05:00' && (await p.textContent('#timerModeLabel')).includes('الاستراحة'));
  await p.click('#timerModeBtn');
  check('E2 mode toggle switches from break back to focus (25:00)', (await p.textContent('#timerDisplay')) === '25:00' && (await p.textContent('#timerModeLabel')).includes('التركيز'));
  await p.click('#timerModeBtn');
  check('E2 mode toggle switches from focus to break (05:00)', (await p.textContent('#timerDisplay')) === '05:00');
  check('E no page errors', noErrors(p), p.errs.join('|'));
  await p.close();
});

await runCase('E per-course focus totals', async () => {
  const p = await open();
  await p.click('.nav-btn[data-view="focus"]');
  await p.selectOption('#timerCourse', 'c3');
  await p.click('#timerStartBtn');
  await p.clock.runFor(25 * 60 * 1000 + 1000);
  const m = await meta(p);
  check('E3 focus minutes are stored against the selected course', m.focusCourse['2026-10-23'].c3 === 25);
  await p.click('.nav-btn[data-view="insights"]');
  check('E3 insights show the per-course focus total', (await p.textContent('#courseProgressList')).includes('25 د تركيز'));
  await p.close();
});

await runCase('E settings change the focus length', async () => {
  const p = await open();
  await p.click('#settingsBtn');
  await p.selectOption('#setFocus', '15');
  await p.fill('#setName', 'سارة');
  await p.click('#settingsSaveBtn');
  check('E4 greeting uses the saved name', (await p.textContent('#greetingText')).includes('سارة'));
  await p.click('.nav-btn[data-view="focus"]');
  check('E4 idle timer shows the new 15-minute length', (await p.textContent('#timerDisplay')) === '15:00');
  await p.click('#timerStartBtn');
  await p.clock.runFor(15 * 60 * 1000 + 1000);
  check('E4 a 15-minute session logs 15 minutes', (await meta(p)).focusLog['2026-10-23'] === 25 + 15);
  check('E4 settings persisted', (await readLS(p, KEYS.settings)).focusMin === 15);
  await p.close();
});

// ====================================================================================
// F. Exams, undo, dark mode, settings validation, reset
// ====================================================================================
await runCase('F exams', async () => {
  const p = await open();
  await p.click('.nav-btn[data-view="exams"]');
  const order = await p.$$eval('#examList .exam-main strong', els => els.map(e => e.textContent));
  check('F1 upcoming exams are listed before past ones', order[0] === 'Midterm' && order[order.length - 1] === 'Quiz 1', order.join(' > '));
  const cls = await p.$eval('#examList .exam-item .exam-countdown', el => el.className);
  check('F1 exam within three days is highlighted', cls.includes('soon'));
  check('F1 home line names the nearest exam', (await p.textContent('#nextExamLine')).includes('Midterm') && (await p.textContent('#nextExamLine')).includes('باقي يومان'));
  await p.selectOption('#examCourse', 'c2');
  await p.fill('#examDate', '2026-10-28');
  await p.fill('#examTitle', 'Quiz 2');
  await p.click('#addExamBtn');
  check('F2 adding an exam stores it', (await meta(p)).exams.some(e => e.title === 'Quiz 2' && e.date === '2026-10-28'));
  const n = (await meta(p)).exams.length;
  await p.locator('#examList [data-act="delete-exam"]').first().click();
  check('F3 deleting an exam removes it', (await meta(p)).exams.length === n - 1);
  await p.click('.toast-action');
  check('F3 undo restores the exam', (await meta(p)).exams.length === n);
  check('F no page errors', noErrors(p), p.errs.join('|'));
  await p.close();
});

await runCase('F course delete with undo keeps titles', async () => {
  const p = await open();
  await p.locator('#courseList .course').first().locator('button[data-act="toggle-course"]').click();
  await p.click('button[data-act="rename-lecture"][data-id="c1"][data-lecture="0"]');
  await p.fill('#lectureTitleInput', 'Keep title');
  await p.click('[data-act="save-title"]');
  const before = (await courses(p)).length;
  await p.locator('#courseList .course').first().locator('button[data-act="delete-course"]').click();
  check('F4 deleting asks in-app first (no native dialog)', await isOpen(p, 'confirmBackdrop') && p.dialogs.length === 0);
  await p.click('#confirmNo');
  check('F4 cancel keeps the course', (await courses(p)).length === before);
  await p.locator('#courseList .course').first().locator('button[data-act="delete-course"]').click();
  await p.click('#confirmYes');
  check('F4 confirm deletes the course and its name', (await courses(p)).length === before - 1 && !(await meta(p)).lectureTitles['c1:0']);
  await p.click('.toast-action');
  check('F4 undo restores the course and its name', (await courses(p)).length === before && (await meta(p)).lectureTitles['c1:0'] === 'Keep title');
  await p.close();
});

await runCase('F dark mode and settings validation', async () => {
  const p = await open();
  await p.click('#themeToggle');
  await p.reload(); await p.waitForTimeout(200);
  const dark = await p.evaluate(() => document.body.classList.contains('dark-mode') && getComputedStyle(document.body).colorScheme.includes('dark'));
  check('F5 dark mode persists and styles native controls', dark);
  await p.click('#settingsBtn');
  await p.fill('#setAiEndpoint', 'http://example.com/ask');
  await p.click('#settingsSaveBtn');
  check('F6 plain-http endpoint (non-localhost) is refused', await isOpen(p, 'settingsBackdrop') && (await p.textContent('#toast')).includes('https'));
  await p.fill('#setAiEndpoint', 'https://example.com/ask');
  await p.click('#settingsSaveBtn');
  check('F6 https endpoint is accepted', !(await isOpen(p, 'settingsBackdrop')) && (await settingsOf(p)).aiEndpoint === 'https://example.com/ask');
  await p.click('#settingsBtn');
  await p.click('#resetBtn');
  await p.click('#confirmYes');
  await p.waitForTimeout(150);
  check('F7 reset restores the default courses', (await courses(p)).length === 8);
  check('F7 reset keeps the chosen theme', (await readLS(p, KEYS.settings)).theme === 'dark');
  check('F no page errors', noErrors(p), p.errs.join('|'));
  await p.close();
});

await runCase('F escape closes dialogs in order', async () => {
  const p = await open();
  await p.click('#settingsBtn');
  await p.click('#resetBtn');
  await p.keyboard.press('Escape');
  check('F8 first Escape closes only the confirm', !(await isOpen(p, 'confirmBackdrop')) && await isOpen(p, 'settingsBackdrop'));
  await p.keyboard.press('Escape');
  check('F8 second Escape closes settings', !(await isOpen(p, 'settingsBackdrop')));
  await p.close();
});

// ====================================================================================
// G. CSV and ICS export
// ====================================================================================
await runCase('G CSV', async () => {
  const p = await open();
  await p.click('#settingsBtn');
  const d = await download(p, () => p.click('#csvBtn'));
  check('G1 CSV file has an ASCII name', /^engazy-progress-\d{4}-\d{2}-\d{2}\.csv$/.test(d.name), d.name);
  const lines = d.text.split('\r\n');
  check('G1 CSV has a UTF-8 BOM and the lecture-name column', d.text.charCodeAt(0) === 0xFEFF && lines[0].includes('عنوان المحاضرة'));
  check('G1 CSV has one row per lecture (52 + header)', lines.length === 53, `(${lines.length})`);
  await p.close();
});

await runCase('G ICS', async () => {
  const p = await open();
  await p.click('#settingsBtn');
  const d = await download(p, () => p.click('#icsBtn'));
  check('G2 calendar file has an ASCII name', /^engazy-calendar-\d{4}-\d{2}-\d{2}\.ics$/.test(d.name), d.name);
  const t = d.text, u = unfold(t);
  check('G2 ICS is a calendar with CRLF line endings', u.startsWith('BEGIN:VCALENDAR') && t.endsWith('END:VCALENDAR\r\n'));
  check('G2 one event per exam and per review (3 + 4 = 7)', (t.match(/BEGIN:VEVENT/g) || []).length === 7);
  check('G2 every physical line is at most 75 octets', t.split('\r\n').filter(Boolean).every(l => Buffer.byteLength(l, 'utf8') <= 75));
  check('G2 exam reminder is 15 hours before midnight (09:00 the day before)', u.includes('TRIGGER:-PT15H') && u.includes('SUMMARY:امتحان: Midterm'));
  check('G2 review events carry the course and lecture label', u.includes('SUMMARY:مراجعة: Fixed · محاضرة 2'));
  await p.close();
});

await runCase('G ICS escaping', async () => {
  const p = await open();
  await p.click('.nav-btn[data-view="exams"]');
  await p.selectOption('#examCourse', 'c1');
  await p.fill('#examDate', '2026-11-02');
  await p.fill('#examTitle', 'Midterm, part 1; oral');
  await p.click('#addExamBtn');
  await p.click('#settingsBtn');
  const d = await download(p, () => p.click('#icsBtn'));
  check('G3 commas and semicolons are escaped in SUMMARY', unfold(d.text).includes('SUMMARY:امتحان: Midterm\\, part 1\\; oral'));
  check('G3 new exam adds one more event (8 total)', (d.text.match(/BEGIN:VEVENT/g) || []).length === 8);
  await p.close();
});

// ====================================================================================
// H. Reminders via a Capacitor-style plugin (native path; mocked plugin in the page)
// ====================================================================================
const EXPECT_UTC = [
  // review at 09:00 on the due date (Fixed lecture 2 due 2026-10-25; Oral pathology lecture 1 due 2026-10-28)
  '2026-10-25T09:00:00.000Z', '2026-10-28T09:00:00.000Z',
  // Midterm (2026-10-25): day before 19:00, day of 08:00
  '2026-10-24T19:00:00.000Z', '2026-10-25T08:00:00.000Z',
  // Final (2026-11-12): day before 19:00, day of 08:00 (UTC, no DST in play)
  '2026-11-11T19:00:00.000Z', '2026-11-12T08:00:00.000Z'
];
await runCase('H reminders startup sync (UTC)', async () => {
  const p = await open({ native: true });
  const pend = await pendingISO(p);
  check('H1 startup schedules reminders without any user action', pend.length === 6, `(${pend.length} pending)`);
  check('H1 exact instants match the expected wall-clock times', sameSet(pend.map(x => x.iso), EXPECT_UTC), JSON.stringify(pend.map(x => x.iso)));
  check('H1 overdue review, past exam and due-today-after-9 are NOT scheduled', !pend.some(x => x.body.startsWith('Removable Prosthodontics · محاضرة')) && !pend.some(x => x.body.includes('Quiz 1')) && !pend.some(x => x.body === 'Fixed · محاضرة 1'));
  check('H1 ids are unique and numeric', new Set(pend.map(x => x.id)).size === pend.length && pend.every(x => Number.isInteger(x.id) && x.id > 0));
  check('H1 native reminders: no page errors', noErrors(p), p.errs.join('|'));
  await p.close();
});

await runCase('H reminders DST (New York)', async () => {
  const p = await open({ native: true, timezoneId: 'America/New_York' });
  const pend = await pendingISO(p);
  // New York: 2026-10-23 is EDT (UTC-4); reviews at 09:00 EDT; Midterm 19:00 EDT / 08:00 EDT;
  // Final on 2026-11-11 is after the Nov 1 change to EST (UTC-5): 19:00 EST = 00:00Z next day.
  const expected = [
    '2026-10-23T13:00:00.000Z', // Fixed lecture 1 due today; 09:00 EDT still ahead at 06:00 EDT
    '2026-10-25T13:00:00.000Z', '2026-10-28T13:00:00.000Z',
    '2026-10-24T23:00:00.000Z', '2026-10-25T12:00:00.000Z',
    '2026-11-12T00:00:00.000Z', '2026-11-12T13:00:00.000Z'
  ];
  check('H2 New York: 7 reminders (one extra: due-today 09:00 is still ahead)', pend.length === 7, `(${pend.length})`);
  check('H2 New York: instants follow local wall-clock times across DST', sameSet(pend.map(x => x.iso), expected), JSON.stringify(pend.map(x => x.iso)));
  const localHours = await p.evaluate(() => window.__pending.map(n => new Date(n.schedule.at).getHours()));
  check('H2 local hours are 9, 19 or 8 in every zone', localHours.every(h => [8, 9, 19].includes(h)), localHours.join(','));
  await p.close();
});

await runCase('H reminders idempotent under rapid saves', async () => {
  const p = await open({ native: true });
  await p.evaluate(() => { for (let i = 0; i < 6; i++) document.getElementById('themeToggle').click(); });
  await p.waitForTimeout(400);
  const pend = await pendingISO(p);
  check('H3 six rapid saves keep exactly 6 pending (no duplicates)', pend.length === 6 && sameSet(pend.map(x => x.iso), EXPECT_UTC), `(${pend.length})`);
  check('H3 each reschedule cancels the previous batch', await p.evaluate(() => window.__cancelled) >= 6);
  await p.close();
});

await runCase('H reminders boundaries (future limit)', async () => {
  const p = await open({ native: true });
  await p.click('.nav-btn[data-view="exams"]');
  const add = async (date, title) => { await p.fill('#examDate', date); await p.fill('#examTitle', title); await p.click('#addExamBtn'); };
  await add('2026-11-23', 'Beyond limit'); // +31 days from 2026-10-23
  check('H4 an exam more than 30 days away is not scheduled', (await pendingISO(p)).length === 6);
  await add('2026-11-22', 'At limit'); // +30 days
  check('H4 an exam exactly 30 days away is scheduled (2 reminders)', (await pendingISO(p)).length === 8, `(${(await pendingISO(p)).length})`);
  await p.close();
});

await runCase('H reminders denied permission', async () => {
  const p = await open({ native: true, grant: 'denied' });
  await p.click('#settingsBtn');
  await p.click('#reminderBtn');
  await p.waitForTimeout(200);
  check('H5 denied permission schedules nothing and raises no error', (await pendingISO(p)).length === 0 && noErrors(p), p.errs.join('|'));
  await p.close();
});

await runCase('H reminders web fallback', async () => {
  const p = await open();
  await p.click('#settingsBtn');
  check('H6 status text is shown without the native plugin', (await p.textContent('#reminderStatus')).length > 10);
  await p.click('#reminderBtn');
  await p.waitForTimeout(300);
  check('H6 enabling in a plain browser raises no error', noErrors(p), p.errs.join('|'));
  check('H6 without the native plugin the status does not promise background delivery', !/مقفول/.test(await p.textContent('#reminderStatus')));
  await p.close();
});

// ====================================================================================
// I. Backups, snapshots, sharing
// ====================================================================================
await runCase('I snapshots', async () => {
  const p = await open();
  const n0 = (await readLS(p, KEYS.snaps)).length;
  check('I1 automatic snapshot on first start', n0 >= 1, `(${n0})`);
  await p.click('#addCourseBtn');
  await p.fill('#courseNameInput', 'Snapshot extra');
  await p.click('#saveCourseBtn');
  await p.click('#settingsBtn');
  await p.click('[data-act="snap-now"]');
  const shown1 = await p.locator('#snapshotList .item').count();
  check('I2 manual snapshot appears in the list', shown1 >= 2, `(${shown1})`);
  await p.locator('#snapshotList [data-act="snap-restore"]').nth(1).click();
  await p.click('#confirmYes');
  await p.waitForTimeout(200);
  check('I3 restoring an older snapshot brings back its courses', (await courses(p)).length === 4);
  check('I3 a safety snapshot is taken before restoring', (await readLS(p, KEYS.snaps)).some(s => s.reason === 'قبل الاستعادة'));
  check('I no page errors', noErrors(p), p.errs.join('|'));
  await p.close();
});

await runCase('I share uses Web Share when available, else downloads', async () => {
  const p = await open();
  await p.evaluate(() => {
    window.__shared = [];
    Object.defineProperty(navigator, 'canShare', { configurable: true, value: () => true });
    Object.defineProperty(navigator, 'share', { configurable: true, value: async d => { window.__shared.push({ name: d.files[0].name, type: d.files[0].type, size: d.files[0].size }); } });
  });
  await p.click('#settingsBtn');
  await p.click('#shareBtn');
  await p.waitForTimeout(200);
  const shared = await p.evaluate(() => window.__shared);
  check('I4 with Web Share the backup is offered as a .json file', shared.length === 1 && /^engazy-backup-\d{4}-\d{2}-\d{2}\.json$/.test(shared[0].name) && shared[0].type === 'application/json', JSON.stringify(shared));
  check('I4 a successful share does not also download a copy', p.dialogs.length === 0);
  await p.close();
  const q = await open();
  await q.evaluate(() => { Object.defineProperty(navigator, 'share', { configurable: true, value: undefined }); });
  await q.click('#settingsBtn');
  const d = await download(q, () => q.click('#shareBtn'));
  check('I4 without Web Share the backup is downloaded instead', /^engazy-backup-\d{4}-\d{2}-\d{2}\.json$/.test(d.name), d.name);
  await q.close();
});

// ====================================================================================
// J. AI assistant: prompt builder, and the real Worker end to end
// ====================================================================================
await runCase('J prompt builder', async () => {
  const p = await open();
  await p.click('.quick[data-view="ai"]');
  await p.click('.quick[data-aiquick="mcq"]');
  check('J1 quick tile selects the MCQ task', (await p.inputValue('#aiTask')) === 'mcq');
  await p.fill('#aiText', 'Dental caries is a multifactorial disease.');
  await p.click('#makePromptBtn');
  const prompt = await p.inputValue('#aiPrompt');
  check('J1 prompt contains the task instruction and the lecture text', prompt.includes('أنشئ 20 سؤال MCQ') && prompt.includes('Dental caries'));
  check('J1 without an endpoint the send button stays hidden', !(await p.isVisible('#sendAiBtn')));
  check('J no page errors', noErrors(p), p.errs.join('|'));
  await p.close();
});

const WORKER_PORT = 8788, APP_TOKEN = 'abc-test-token', TEST_KEY = 'sk-test-local-not-real';
simulateAnthropic(TEST_KEY);
const workerServer = await startWorkerServer(WORKER_PORT, { ANTHROPIC_API_KEY: TEST_KEY, APP_TOKEN, ALLOWED_ORIGIN: '*' });

await runCase('J AI through the Worker (token ok)', async () => {
  const p = await open();
  await p.click('#settingsBtn');
  await p.fill('#setAiEndpoint', `http://localhost:${WORKER_PORT}/`);
  await p.fill('#setAiToken', APP_TOKEN);
  await p.click('#settingsSaveBtn');
  await p.click('.quick[data-view="ai"]');
  await p.fill('#aiText', 'Dental caries is a multifactorial disease.');
  await p.click('#makePromptBtn');
  check('J2 send button appears once an endpoint is set', await p.isVisible('#sendAiBtn'));
  await p.click('#sendAiBtn');
  check('J2 sending requires an in-app confirmation', await isOpen(p, 'confirmBackdrop'));
  await p.click('#confirmYes');
  await p.waitForSelector('#aiAnswerCard:not([hidden])', { timeout: 8000 }).catch(() => {});
  const answer = await p.textContent('#aiAnswerText');
  check('J2 the answer from the Worker is displayed', answer.includes('رد محاكى'), `(${answer.slice(0, 50)})`);
  check('J2 the Worker used the server-side key (never sent to the browser)', upstreamLog.length >= 1 && upstreamLog.at(-1).keyOk && !(await p.content()).includes(TEST_KEY));
  check('J2 AI flow no page errors', noErrors(p), p.errs.join('|'));
  await p.close();
});

await runCase('J AI cancelled sends nothing', async () => {
  const p = await open();
  await p.click('#settingsBtn');
  await p.fill('#setAiEndpoint', `http://localhost:${WORKER_PORT}/`);
  await p.fill('#setAiToken', APP_TOKEN);
  await p.click('#settingsSaveBtn');
  await p.click('.quick[data-view="ai"]');
  await p.fill('#aiText', 'Cancel me');
  await p.click('#makePromptBtn');
  const before = upstreamLog.length;
  await p.click('#sendAiBtn');
  await p.click('#confirmNo');
  await p.waitForTimeout(300);
  check('J3 cancelling the confirmation makes no request', upstreamLog.length === before);
  await p.close();
});

await runCase('J AI wrong token', async () => {
  const p = await open();
  await p.click('#settingsBtn');
  await p.fill('#setAiEndpoint', `http://localhost:${WORKER_PORT}/`);
  await p.fill('#setAiToken', 'wrong');
  await p.click('#settingsSaveBtn');
  await p.click('.quick[data-view="ai"]');
  await p.fill('#aiText', 'x');
  await p.click('#makePromptBtn');
  await p.click('#sendAiBtn');
  await p.click('#confirmYes');
  await p.waitForTimeout(800);
  check('J4 wrong token shows a clear message', (await p.textContent('#toast')).includes('رمز الوصول'), `(${await p.textContent('#toast')})`);
  check('J4 no answer card is shown', !(await p.isVisible('#aiAnswerCard')));
  await p.close();
});

await runCase('J AI unreachable server', async () => {
  const p = await open();
  await p.click('#settingsBtn');
  await p.fill('#setAiEndpoint', 'http://localhost:8799/');
  await p.click('#settingsSaveBtn');
  await p.click('.quick[data-view="ai"]');
  await p.fill('#aiText', 'x');
  await p.click('#makePromptBtn');
  await p.click('#sendAiBtn');
  await p.click('#confirmYes');
  await p.waitForTimeout(1200);
  check('J5 unreachable server gives a readable error', (await p.textContent('#toast')).includes('تعذر الرد'));
  await p.close();
});

await runCase('J Worker unit tests', async () => {
  const r = spawnSync(process.execPath, [path.join(HERE, 'worker.test.mjs')], { encoding: 'utf8', timeout: 60000 });
  const lines = r.stdout.split('\n').filter(l => /^(PASS|FAIL)\s/.test(l));
  for (const l of lines) check(`J6 worker: ${l.replace(/^(PASS|FAIL)\s+/, '').trim()}`, l.startsWith('PASS'));
  check('J6 worker suite exit code is 0', r.status === 0);
});

// ====================================================================================
// K. Layout: phones at 320 / 360 / 390 and a landscape tablet
// ====================================================================================
for (const w of [320, 360, 390]) {
  await runCase(`K layout ${w}px`, async () => {
    const p = await open({ viewport: { width: w, height: 740 }, mobile: true });
    const items = await p.locator('.bottom-nav .nav-btn').count();
    const rows = await p.$$eval('.bottom-nav .nav-btn', els => new Set(els.map(e => Math.round(e.getBoundingClientRect().top))).size);
    check(`K${w} five-tab navigation on one row`, items === 5 && rows === 1, `(items=${items}, rows=${rows})`);
    const over = await p.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    check(`K${w} no horizontal page overflow`, over === 0, `(${over}px)`);
    check(`K${w} navigation labels fit`, await p.$$eval('.bottom-nav .nav-btn', els => els.every(e => e.scrollWidth <= e.clientWidth + 1)));
    await p.click('.nav-btn[data-view="insights"]');
    const over2 = await p.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    check(`K${w} insights page has no overflow`, over2 === 0, `(${over2}px)`);
    await p.click('.nav-btn[data-view="home"]');
    await p.locator('#courseList .course').first().locator('button[data-act="toggle-course"]').click();
    const segOver = await p.$$eval('.seg button', els => els.some(e => e.scrollWidth > e.clientWidth + 1));
    check(`K${w} lecture status buttons do not clip text`, !segOver);
    await p.screenshot({ path: path.join(SHOTS, `m${w}.png`) });
    await p.close();
  });
}
await runCase('K landscape tablet 1024x768', async () => {
  const p = await open({ viewport: { width: 1024, height: 768 } });
  const over = await p.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  check('K4 landscape tablet has no horizontal overflow', over === 0, `(${over}px)`);
  await p.click('.nav-btn[data-view="insights"]');
  await p.screenshot({ path: path.join(SHOTS, 'tablet-insights.png') });
  check('K4 landscape tablet: insights rendered', await p.isVisible('#heatmap'));
  await p.close();
});

// ====================================================================================
// L. Regression tour of the main screens (no page errors on any screen)
// ====================================================================================
await runCase('L screens', async () => {
  const p = await open();
  for (const v of ['focus', 'reviews', 'exams', 'insights', 'home']) {
    await p.click(`.nav-btn[data-view="${v}"]`);
    await p.waitForTimeout(80);
  }
  await p.click('.quick[data-view="ai"]');
  await p.waitForTimeout(80);
  await p.click('.nav-btn[data-view="home"]');
  await p.click('.quick[data-view="plan"]');
  check('L1 plan view opens and shows a daily target', (await p.textContent('#planPerDay')).length > 0);
  check('L1 all screens: no page errors', noErrors(p), p.errs.join('|'));
  await p.close();
});

// ====================================================================================
// Summary (always printed)
// ====================================================================================
for (const s of servers) try { s.close(); } catch (e) {}
await browser?.close().catch(() => {});
globalThis.fetch = REAL_FETCH;
const passed = results.filter(r => r.ok).length, failed = results.length - passed;
console.log('\n==================== SUMMARY ====================');
console.log(`checks: ${results.length}   passed: ${passed}   failed: ${failed}`);
if (failed) { console.log('failures:'); results.filter(r => !r.ok).forEach(r => console.log('  - ' + r.name)); }
process.exitCode = failed ? 1 : 0;
