import worker from '../engazy-ai-proxy.js';
let fails = 0; const ok = (n, c, x='') => { if(!c) fails++; console.log((c?'PASS':'FAIL')+'  '+n+' '+x); };

let upstreamCalls = []; let upstreamMode = 'ok';
globalThis.fetch = async (url, init) => {
  upstreamCalls.push({ url, init });
  if (upstreamMode === 'down') throw new Error('network');
  if (upstreamMode === 'fail') return new Response('err', { status: 500 });
  const req = JSON.parse(init.body);
  return new Response(JSON.stringify({ content: [{ type: 'text', text: 'رد تجريبي على: ' + req.messages[0].content.slice(0, 20) }] }), { status: 200, headers: { 'content-type': 'application/json' } });
};

const env = { ANTHROPIC_API_KEY: 'sk-test-123' };
const req = (method, body, headers={}) => new Request('https://w.example/', { method, headers: { 'content-type': 'application/json', ...headers }, body: body === undefined ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)) });

let r = await worker.fetch(req('OPTIONS'), env);
ok('OPTIONS preflight returns 204 with CORS', r.status === 204 && r.headers.get('Access-Control-Allow-Origin') === '*' && r.headers.get('Access-Control-Allow-Headers').includes('X-Engazy-Token'));
r = await worker.fetch(req('GET'), env);
ok('GET rejected with 405', r.status === 405);
r = await worker.fetch(req('POST', { prompt: 'x' }), {});
ok('missing key gives 500 (not leaking details)', r.status === 500);
r = await worker.fetch(req('POST', 'not json'), env);
ok('invalid JSON gives 400', r.status === 400);
r = await worker.fetch(req('POST', { prompt: '   ' }), env);
ok('empty prompt gives 400', r.status === 400);
r = await worker.fetch(req('POST', { prompt: 'a'.repeat(20001) }), env);
ok('overlong prompt gives 413', r.status === 413);
upstreamCalls = [];
r = await worker.fetch(req('POST', { prompt: 'Crown margins are ...' }), env);
const out = await r.json();
ok('valid prompt returns text', r.status === 200 && out.text.startsWith('رد تجريبي'), JSON.stringify(out).slice(0,60));
const call = upstreamCalls[0];
ok('calls Anthropic Messages endpoint with key header', call && call.url === 'https://api.anthropic.com/v1/messages' && call.init.headers['x-api-key'] === 'sk-test-123' && call.init.headers['anthropic-version'] === '2023-06-01');
const sent = JSON.parse(call.init.body);
ok('uses default model and a system prompt', sent.model === 'claude-sonnet-5-5' && typeof sent.system === 'string' && sent.system.length > 20 && sent.max_tokens === 2000);
ok('user prompt forwarded as single user message', sent.messages.length === 1 && sent.messages[0].role === 'user' && sent.messages[0].content === 'Crown margins are ...');
ok('CORS header on success', r.headers.get('Access-Control-Allow-Origin') === '*');

r = await worker.fetch(req('POST', { prompt: 'x' }, {'X-Engazy-Token':'nope'}), { ...env, APP_TOKEN: 'secret' });
ok('wrong app token gives 401', r.status === 401);
r = await worker.fetch(req('POST', { prompt: 'x' }, {'X-Engazy-Token':'secret'}), { ...env, APP_TOKEN: 'secret' });
ok('correct app token passes', r.status === 200);

upstreamMode = 'fail';
r = await worker.fetch(req('POST', { prompt: 'x' }), env);
ok('upstream error gives 502 without leaking the key', r.status === 502 && !(await r.text()).includes('sk-test'));
upstreamMode = 'down';
r = await worker.fetch(req('POST', { prompt: 'x' }), env);
ok('network failure gives 502', r.status === 502);
upstreamMode = 'ok';
r = await worker.fetch(req('POST', { prompt: 'x' }), { ...env, MODEL: 'claude-haiku-5-5' });
ok('MODEL env overrides default', JSON.parse(upstreamCalls.at(-1).init.body).model === 'claude-haiku-5-5');

console.log(fails ? `\n${fails} FAILED` : '\nall worker checks passed');
process.exit(fails ? 1 : 0);
