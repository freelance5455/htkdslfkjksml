/**
 * إنجازي: خادم المساعد الذكي (Cloudflare Worker)
 *
 * الغرض: يحتفظ بمفتاح الذكاء الاصطناعي على الخادم فقط، ولا يظهر أبدًا داخل التطبيق.
 *
 * الإعداد:
 *   1) أنشئ Worker جديدًا في Cloudflare والصق هذا الملف فيه.
 *   2) من Settings > Variables and Secrets أضف:
 *        ANTHROPIC_API_KEY  (إلزامي، secret)
 *        APP_TOKEN          (اختياري، secret: رمز يكتبه المستخدم في إعدادات إنجازي)
 *        ALLOWED_ORIGIN     (اختياري، مثلًا https://example.com؛ الافتراضي *)
 *        MODEL              (اختياري، الافتراضي claude-sonnet-5-5)
 *   3) انسخ عنوان الـ Worker (https://...workers.dev) والصقه في إعدادات إنجازي.
 */

const SYSTEM_PROMPT =
  'أنت مساعد دراسي لطلاب طب الأسنان. اعتمد أولًا على النص الذي يرسله الطالب، ' +
  'ولا تختلق معلومات غير موجودة فيه إلا إذا طُلب منك ذلك صراحةً، ووضّح ذلك عندها. ' +
  'اكتب بالعربية البسيطة، واحتفظ بالمصطلحات الطبية بالإنجليزية.';

const MAX_PROMPT_CHARS = 20000;

function corsHeaders(env) {
  return {
    'Access-Control-Allow-Origin': env.ALLOWED_ORIGIN || '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Engazy-Token',
    'Access-Control-Max-Age': '86400',
  };
}

function json(obj, status, headers) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { ...headers, 'Content-Type': 'application/json; charset=utf-8' },
  });
}

export default {
  async fetch(request, env) {
    const cors = corsHeaders(env);

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (request.method !== 'POST') return json({ error: 'method_not_allowed' }, 405, cors);

    if (env.APP_TOKEN && request.headers.get('X-Engazy-Token') !== env.APP_TOKEN) {
      return json({ error: 'unauthorized' }, 401, cors);
    }
    if (!env.ANTHROPIC_API_KEY) return json({ error: 'server_not_configured' }, 500, cors);

    let body;
    try {
      body = await request.json();
    } catch (e) {
      return json({ error: 'invalid_json' }, 400, cors);
    }

    const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
    if (!prompt) return json({ error: 'empty_prompt' }, 400, cors);
    if (prompt.length > MAX_PROMPT_CHARS) return json({ error: 'prompt_too_long' }, 413, cors);

    let upstream;
    try {
      upstream = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-api-key': env.ANTHROPIC_API_KEY,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: env.MODEL || 'claude-sonnet-5-5',
          max_tokens: 2000,
          system: SYSTEM_PROMPT,
          messages: [{ role: 'user', content: prompt }],
        }),
      });
    } catch (e) {
      return json({ error: 'upstream_unreachable' }, 502, cors);
    }

    if (!upstream.ok) return json({ error: 'upstream_error', status: upstream.status }, 502, cors);

    const data = await upstream.json();
    const text = (data.content || [])
      .filter((block) => block.type === 'text')
      .map((block) => block.text)
      .join('\n')
      .trim();

    return json({ text }, 200, cors);
  },
};
