# تفعيل Online للعبة Maze Quest

## الخدمة
المشروع يستخدم Supabase: Authentication + PostgreSQL + Realtime.

## تفعيل قاعدة البيانات بدون مشاركة كلمة المرور

1. افتح لوحة مشروعك في Supabase.
2. من القائمة اختر **SQL Editor** ثم **New query**.
3. افتح ملف `supabase-schema.sql` الموجود داخل هذه الحزمة.
4. انسخ محتواه كاملًا إلى محرر SQL.
5. اضغط **Run**.
6. من **Authentication → Providers** تأكد أن Email مفعّل.
7. إذا كان Email confirmation مفعّلًا، يجب على اللاعب تأكيد بريده قبل الدخول.

بعد تنفيذ SQL ستصبح الجداول التالية جاهزة:

- `profiles`
- `player_progress`
- `rooms`
- `room_members`
- `room_messages`
- `friendships`

وتوجد سياسات Row Level Security وRealtime في الملف نفسه.

## التشغيل

افتح `index.html` من خلال خادم HTTP محلي أو ارفعه إلى أي استضافة Static. لا تستخدم `file://` لأن بعض المتصفحات تمنع تحميل ملفات JavaScript المحلية بهذه الطريقة.

مثال:

```bash
python3 -m http.server 4173
```

ثم افتح:

```text
http://localhost:4173/
```

## ملاحظة مهمة

- مفتاح Supabase الموجود في `online-adapter.js` هو Publishable/Anon key فقط.
- لا تضع Service Role Key داخل ملفات HTML أو JavaScript العامة.
- اللعبة الأساسية تعمل محليًا عند غياب الإنترنت، بينما الحسابات والغرف والدردشة والمزامنة تحتاج الإنترنت.
- إذا أردت تغيير Backend مستقبلًا، استبدل `online-adapter.js` فقط مع إبقاء واجهة اللعبة الأساسية.
