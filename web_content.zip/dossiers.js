"use strict";

function paperSheet(id) {
  let p = PAPERS.find(p => p.id === id);
  if (!p) return;
  let i = 0;
  let sections = p.blocks.map(([title, doc, qs]) => '<section class="card spaced"><h2>' + esc(title) + '</h2><p class="soft pre">' + esc(doc) + '</p>' + qs.map(([q, max, solution]) => {
    let idx = ++i;
    return '<div class="entry"><strong>' + idx + '. ' + esc(q) + '</strong><div class="small">' + fmt(max) + ' pt(s)</div><details><summary>Corrigé et barème</summary><p>' + esc(solution) + '</p></details>' + field("Points obtenus", "p" + idx, "", "number", 'required min="0" max="' + max + '" step="0.25"') + '</div>';
  }).join("") + '</section>').join("");
  $("#main").innerHTML = btn("← Mon bac", "render()", "link") + heading("Sujet blanc original · copie sur papier", esc(p.title)) + '<p>' + esc(p.desc) + '</p><form id="paper">' + sections + '<p>Après avoir corrigé ta copie, reporte les points de chaque question pour conserver ton résultat dans Bac.</p><button class="primary">Enregistrer mon autoévaluation</button></form>';
  window.scrollTo(0, 0);
  $("#paper").onsubmit = e => {
    e.preventDefault();
    let total = 0;
    for (let j = 1; j <= i; j++) total += +e.target.elements["p" + j].value;
    confirmAction("Enregistrer " + fmt(total) + "/20 pour ce sujet blanc autocorrigé ?", () => {
      (D.papers || (D.papers = [])).push({
        id: p.id,
        date: day(),
        score: total
      });
      commit();
    });
  };
}
function paperLinks() {
  return box("Sujets blancs à rédiger", '<p>Travaille sur papier, puis utilise le barème détaillé pour enregistrer ton autoévaluation.</p>' + PAPERS.map(p => '<div class="entry">' + btn(esc(p.title) + " →", "paperSheet('" + p.id + "')", "link") + '</div>').join("") + (D.papers && D.papers.length ? '<h3>Copies autocorrigées</h3>' + D.papers.slice(-5).reverse().map(r => '<p>' + esc(PAPERS.find(p => p.id === r.id).title) + ' · ' + fmt(r.score) + '/20 · ' + r.date + '</p>').join("") : ""));
}
