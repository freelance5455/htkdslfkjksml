ScoreDeck — CBSE Class 12
Home-page UI update

This package preserves the existing single-file ScoreDeck application and changes only the home-page presentation/branding requested for this update.
Open CBSE_12_Commerce_Practice_Dashboard.html in a browser or use it as the existing HTML source for the APK packaging workflow.
