# Мой день — Android APK project

Это Android-проект для текущего MVP.

## Приватность
- INTERNET permission отсутствует.
- Нет аналитики, рекламы, аккаунтов или синхронизации.
- Данные планировщика сохраняются локально через localStorage WebView.
- Приложение не отправляет данные на сервер.

## Как собрать APK
Откройте папку проекта в Android Studio.
Дождитесь синхронизации Gradle.
Выберите Build → Build APK(s).
Готовый debug APK появится в:
app/build/outputs/apk/debug/app-debug.apk

Для публикации в Google Play потребуется отдельная release-сборка и подпись.
