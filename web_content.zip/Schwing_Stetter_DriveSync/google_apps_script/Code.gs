/** Schwing Stetter Mohali: Google Sheets snapshot sync.
 * Script Properties required: SPREADSHEET_ID and CLOUD_TOKEN.
 * Deploy Web App as Execute as Me. Anyone can reach endpoint but token is required.
 * Each backup replaces the ServiceCalls snapshot; use one primary device to avoid concurrent overwrite.
 */
const CALLS_SHEET = 'ServiceCalls';
const META_SHEET = '_AppMeta';
function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const props = PropertiesService.getScriptProperties();
    const expected = props.getProperty('CLOUD_TOKEN');
    if (!expected || !body.token || !constantTimeEqual_(String(body.token), expected)) return json_({ok:false,error:'Unauthorized token'});
    const spreadsheetId = props.getProperty('SPREADSHEET_ID');
    if (!spreadsheetId) return json_({ok:false,error:'Set SPREADSHEET_ID in Script Properties first'});
    const ss = SpreadsheetApp.openById(spreadsheetId);
    if (body.action === 'backup') {
      const data = body.data;
      if (!data || !Array.isArray(data.records) || !data.prefs) return json_({ok:false,error:'Invalid app data'});
      const sh = getOrCreate_(ss, CALLS_SHEET);
      sh.clearContents();
      sh.getRange(1,1,1,5).setValues([['Record ID','Date','Customer Name','Status','Record JSON']]);
      const rows = data.records.map(r => {
        const json = JSON.stringify(r);
        if (json.length > 45000) throw new Error('Record too large for a Google Sheets cell. Use a smaller photo.');
        return [String(r.id || ''), String(r.date || ''), String(r.customer || ''), String(r.status || ''), json];
      });
      if (rows.length) sh.getRange(2,1,rows.length,5).setValues(rows);
      sh.setFrozenRows(1); sh.autoResizeColumns(1,4); sh.setColumnWidth(5,420);
      const meta = getOrCreate_(ss, META_SHEET); meta.clearContents();
      meta.getRange(1,1,2,2).setValues([['App data JSON','Updated at'],[JSON.stringify({prefs:data.prefs,customers:data.customers||{},customColumns:data.customColumns||[],seq:data.seq||1}),new Date().toISOString()]]);
      props.setProperty('LAST_SYNC_AT', new Date().toISOString());
      return json_({ok:true,message:'Google Sheets sync saved',calls:rows.length,time:new Date().toISOString()});
    }
    if (body.action === 'restore') {
      const sh = ss.getSheetByName(CALLS_SHEET); if (!sh || sh.getLastRow() < 1) return json_({ok:false,error:'No records in Google Sheet'});
      const values = sh.getLastRow() > 1 ? sh.getRange(2,5,sh.getLastRow()-1,1).getValues().flat() : [];
      const records = values.filter(String).map(v => JSON.parse(String(v)));
      const meta = ss.getSheetByName(META_SHEET); let extra = {prefs:{},customers:{},customColumns:[],seq:1};
      if (meta && meta.getLastRow() >= 2) { try { extra = Object.assign(extra, JSON.parse(String(meta.getRange(2,1).getValue() || '{}'))); } catch (_) {} }
      return json_({ok:true,data:{records:records,prefs:extra.prefs||{},customers:extra.customers||{},customColumns:extra.customColumns||[],seq:extra.seq||1},time:new Date().toISOString()});
    }
    return json_({ok:false,error:'Unknown action'});
  } catch (err) { return json_({ok:false,error:String(err && err.message ? err.message : err)}); }
}
function getOrCreate_(ss, name) { return ss.getSheetByName(name) || ss.insertSheet(name); }
function json_(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
function constantTimeEqual_(a,b) { if(a.length!==b.length)return false;let diff=0;for(let i=0;i<a.length;i++)diff|=a.charCodeAt(i)^b.charCodeAt(i);return diff===0; }
function setupPropertiesOnce() {
  PropertiesService.getScriptProperties().setProperties({
    SPREADSHEET_ID: 'PASTE_YOUR_GOOGLE_SHEET_ID_HERE',
    CLOUD_TOKEN: 'REPLACE_WITH_RANDOM_SECRET_AT_LEAST_32_CHARS'
  });
}
