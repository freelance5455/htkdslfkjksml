package com.schwingstetter.fastentry

import android.app.Activity
import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.content.ContentValues
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import org.json.JSONObject
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.Charset
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val cloudExecutor = Executors.newSingleThreadExecutor()
    private val locationManager by lazy { getSystemService(LOCATION_SERVICE) as LocationManager }
    private val locationPermissionRequest = 7104

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(FileBridge(), "AndroidFiles")
        webView.addJavascriptInterface(CloudBridge(), "AndroidCloud")
        webView.addJavascriptInterface(LocationBridge(), "AndroidLocation")
        webView.loadUrl("file:///android_asset/index.html")
    }


    inner class LocationBridge {
        @JavascriptInterface
        fun getCurrentLocation() {
            runOnUiThread {
                val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                val coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (!fine && !coarse) {
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), locationPermissionRequest)
                } else {
                    fetchLocation()
                }
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationPermissionRequest) {
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) fetchLocation()
            else webView.evaluateJavascript("window.onNativeLocation(false, 0, 0, '')", null)
        }
    }

    @Suppress("MissingPermission", "DEPRECATION")
    private fun fetchLocation() {
        try {
            val providers = locationManager.getProviders(true)
            var best: Location? = null
            for (provider in providers) {
                val candidate = locationManager.getLastKnownLocation(provider) ?: continue
                if (best == null || candidate.accuracy < best!!.accuracy) best = candidate
            }
            if (best != null && System.currentTimeMillis() - best!!.time < 10 * 60 * 1000) {
                deliverLocation(best!!)
                return
            }
            val provider = when {
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                else -> null
            }
            if (provider == null) {
                webView.evaluateJavascript("window.onNativeLocation(false, 0, 0, '')", null)
                return
            }
            locationManager.requestSingleUpdate(provider, object : LocationListener {
                override fun onLocationChanged(location: Location) { deliverLocation(location) }
                @Deprecated("Deprecated by Android") override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }, Looper.getMainLooper())
        } catch (e: Exception) {
            webView.evaluateJavascript("window.onNativeLocation(false, 0, 0, '')", null)
        }
    }

    private fun deliverLocation(location: Location) {
        cloudExecutor.execute {
            var place = ""
            try {
                if (Geocoder.isPresent()) {
                    val geocoder = Geocoder(this@MainActivity, java.util.Locale.getDefault())
                    val addresses = if (Build.VERSION.SDK_INT >= 33) {
                        var result: List<android.location.Address> = emptyList()
                        val latch = java.util.concurrent.CountDownLatch(1)
                        geocoder.getFromLocation(location.latitude, location.longitude, 1) { found -> result = found; latch.countDown() }
                        latch.await(5, java.util.concurrent.TimeUnit.SECONDS)
                        result
                    } else {
                        @Suppress("DEPRECATION")
                        geocoder.getFromLocation(location.latitude, location.longitude, 1) ?: emptyList()
                    }
                    if (addresses.isNotEmpty()) {
                        val a = addresses[0]
                        place = listOfNotNull(a.subLocality, a.locality, a.subAdminArea, a.adminArea).distinct().joinToString(", ")
                    }
                }
            } catch (_: Exception) {}
            runOnUiThread {
                webView.evaluateJavascript("window.onNativeLocation(true, ${location.latitude}, ${location.longitude}, ${JSONObject.quote(place)})", null)
            }
        }
    }

    inner class FileBridge {
        @JavascriptInterface
        fun saveTextFile(fileName: String, content: String, mimeType: String) {
            try {
                val resolver = contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                    put(MediaStore.Downloads.MIME_TYPE, mimeType)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Could not create download")
                resolver.openOutputStream(uri).use { stream: OutputStream? ->
                    if (stream == null) throw IllegalStateException("Could not open download")
                    stream.write(content.toByteArray(Charsets.UTF_8))
                    stream.flush()
                }
                runOnUiThread { Toast.makeText(this@MainActivity, "Saved to Downloads", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Export failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    inner class CloudBridge {
        @JavascriptInterface
        fun backup(endpoint: String, token: String, payload: String) {
            cloudExecutor.execute {
                try {
                    val body = JSONObject().put("action", "backup").put("token", token).put("data", JSONObject(payload)).toString()
                    val response = postJson(endpoint, body)
                    val result = JSONObject(response)
                    if (!result.optBoolean("ok")) throw IllegalStateException(result.optString("error", "Backup rejected"))
                    runOnUiThread { webView.evaluateJavascript("window.onCloudBackupResult(true, ${JSONObject.quote(result.optString("message", "Backup saved"))})", null) }
                } catch (e: Exception) {
                    val message = e.message ?: "Network error"
                    runOnUiThread { webView.evaluateJavascript("window.onCloudBackupResult(false, ${JSONObject.quote(message)})", null) }
                }
            }
        }

        @JavascriptInterface
        fun restore(endpoint: String, token: String) {
            cloudExecutor.execute {
                try {
                    val body = JSONObject().put("action", "restore").put("token", token).toString()
                    val response = postJson(endpoint, body)
                    val result = JSONObject(response)
                    if (!result.optBoolean("ok")) throw IllegalStateException(result.optString("error", "Restore rejected"))
                    val data = result.getJSONObject("data").toString()
                    runOnUiThread { webView.evaluateJavascript("window.onCloudRestoreResult(true, ${JSONObject.quote(data)})", null) }
                } catch (e: Exception) {
                    val message = e.message ?: "Network error"
                    runOnUiThread { webView.evaluateJavascript("window.onCloudRestoreResult(false, ${JSONObject.quote(message)})", null) }
                }
            }
        }
    }

    private fun postJson(endpoint: String, body: String): String {
        require(endpoint.startsWith("https://script.google.com/macros/s/") && endpoint.endsWith("/exec")) { "Invalid Apps Script URL" }
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 30000
            doOutput = true
            instanceFollowRedirects = false
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }
        try {
            connection.outputStream.use { it.write(body.toByteArray(Charset.forName("UTF-8"))) }
            val code = connection.responseCode
            if (code in 300..399) {
                val location = connection.getHeaderField("Location")
                    ?: throw IllegalStateException("Google Apps Script redirect missing Location header")
                connection.disconnect()
                val redirectUrl = URL(URL(endpoint), location)
                val redirected = (redirectUrl.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 20000
                    readTimeout = 30000
                    instanceFollowRedirects = true
                    setRequestProperty("Accept", "application/json")
                }
                try {
                    val redirectedCode = redirected.responseCode
                    val redirectedStream = if (redirectedCode in 200..299) redirected.inputStream else redirected.errorStream
                    val redirectedBody = redirectedStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                    if (redirectedCode !in 200..299) throw IllegalStateException("HTTP $redirectedCode: ${redirectedBody.take(250)}")
                    return redirectedBody
                } finally { redirected.disconnect() }
            }
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IllegalStateException("HTTP $code: ${response.take(250)}")
            return response
        } finally { connection.disconnect() }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        cloudExecutor.shutdownNow()
        super.onDestroy()
    }
}
