Schwing Stetter Mohali Service Desk — updated source project

Includes Android WebView project, modern service-call form, image attachments, repeat calls, Sunday filter, protected custom columns, local storage, CSV/JSON export, and Google Sheets snapshot sync.

Start with SHEETS_SYNC_SETUP_HINDI.txt. Change default PIN 2468. Google Apps Script requires SPREADSHEET_ID and CLOUD_TOKEN properties. This ZIP is not a compiled APK.

Latest UI update: See UI_UPDATE_SETUP_HINDI.txt for automatic GPS location, repeated calls, location-wise details, My Daily Activities and dashboard customization.
