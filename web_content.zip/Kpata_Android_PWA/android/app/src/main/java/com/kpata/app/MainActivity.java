package com.kpata.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    WebView w=new WebView(this);
    w.setWebViewClient(new WebViewClient());
    WebSettings s=w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    // Replace this URL with the HTTPS URL where the Kpata backend is deployed.
    w.loadUrl("https://REPLACE-WITH-KPATA-DOMAIN/");
    setContentView(w);
  }
}