# Kpata V3.3 — flux prestataire intégré

## Ce qui est intégré
- Inscription « Devenir prestataire »
- Statut prestataire en attente de validation
- Validation/refus par l'administrateur
- Profil avec métier, quartier, expérience, description et prix indicatif
- Publication de services par le prestataire après validation
- Recherche de prestataires vérifiés à Djougou
- Demande client avec lieu, description du travail et moment souhaité
- Cycle de travail : pending → accepted → in_progress → completed → confirmed
- Avis client après confirmation
- Tableau de bord prestataire
- Suivi administratif des prestataires
- Enregistrement des paiements et calcul de commission
- Comptes de démonstration :
  - Admin : 97000000 / demo1234
  - Prestataire : 97000001 / demo1234
  - Client : 97000002 / demo1234

## Lancer
Node.js 18+
npm install
npm start
Puis ouvrir http://localhost:3000

Admin : http://localhost:3000/admin (le panneau admin de la version précédente peut être conservé/copié dans public/admin.html).

## À compléter avant production
- Pièce d'identité et vraie vérification documentaire avec stockage sécurisé
- Paiement Mobile Money réel (API d'un prestataire de paiement)
- SMS/push/WhatsApp
- géolocalisation/carte
- PostgreSQL/Supabase au lieu de SQLite
- HTTPS, sauvegardes, validation renforcée et gestion sécurisée des fichiers
