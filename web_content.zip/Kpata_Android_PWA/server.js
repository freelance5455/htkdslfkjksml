require("dotenv").config();
const express=require("express"), cors=require("cors"), helmet=require("helmet"), rateLimit=require("express-rate-limit");
const bcrypt=require("bcryptjs"), jwt=require("jsonwebtoken"), Database=require("better-sqlite3");
const path=require("path");
const app=express(), PORT=process.env.PORT||3000, SECRET=process.env.JWT_SECRET||"dev_secret_change_me";
const db=new Database("kpata.db");
app.use(helmet({contentSecurityPolicy:false})); app.use(cors()); app.use(express.json({limit:"1mb"}));
app.use(rateLimit({windowMs:15*60*1000,max:300}));
app.use(express.static(path.join(__dirname,"public")));

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT UNIQUE NOT NULL,
 password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'client', city TEXT DEFAULT 'Djougou',
 neighborhood TEXT DEFAULT '', category TEXT DEFAULT '', description TEXT DEFAULT '',
 experience TEXT DEFAULT '', price TEXT DEFAULT '', verified INTEGER DEFAULT 0,
 blocked INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS services(
 id INTEGER PRIMARY KEY AUTOINCREMENT, provider_id INTEGER NOT NULL, name TEXT NOT NULL,
 description TEXT DEFAULT '', price TEXT DEFAULT '', category TEXT DEFAULT '',
 active INTEGER DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS requests(
 id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL, provider_id INTEGER NOT NULL,
 service_id INTEGER, location TEXT DEFAULT '', notes TEXT DEFAULT '', preferred_time TEXT DEFAULT '',
 status TEXT DEFAULT 'pending', client_confirmed INTEGER DEFAULT 0,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS reviews(
 id INTEGER PRIMARY KEY AUTOINCREMENT, request_id INTEGER UNIQUE NOT NULL, client_id INTEGER NOT NULL,
 provider_id INTEGER NOT NULL, rating INTEGER NOT NULL, comment TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS payments(
 id INTEGER PRIMARY KEY AUTOINCREMENT, request_id INTEGER NOT NULL, amount REAL NOT NULL,
 commission_rate REAL DEFAULT 10, commission REAL DEFAULT 0, provider_amount REAL DEFAULT 0,
 method TEXT DEFAULT 'cash', status TEXT DEFAULT 'recorded', created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS admin_audit(
 id INTEGER PRIMARY KEY AUTOINCREMENT, admin_id INTEGER, action TEXT, target_type TEXT,
 target_id INTEGER, details TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS categories(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, active INTEGER DEFAULT 1
);`);

const count=db.prepare("SELECT COUNT(*) c FROM users").get().c;
if(!count){
 const ins=db.prepare("INSERT INTO users(name,phone,password,role,city,verified) VALUES(?,?,?,?,?,?)");
 ins.run("Admin Kpata","97000000",bcrypt.hashSync("demo1234",10),"admin","Djougou",1);
 ins.run("Prestataire Démo","97000001",bcrypt.hashSync("demo1234",10),"provider","Djougou",1);
 ins.run("Client Démo","97000002",bcrypt.hashSync("demo1234",10),"client","Djougou",1);
 const cats=["Plomberie","Électricité","Réparation téléphone","Maçonnerie","Menuiserie","Peinture","Coiffure","Mécanique","Informatique","Nettoyage","Agriculture","Autres"];
 cats.forEach(x=>db.prepare("INSERT OR IGNORE INTO categories(name) VALUES(?)").run(x));
 const p=db.prepare("SELECT id FROM users WHERE phone='97000001'").get().id;
 db.prepare("INSERT INTO services(provider_id,name,description,price,category) VALUES(?,?,?,?,?)")
   .run(p,"Réparation de fuite","Diagnostic et réparation de petites fuites","À partir de 5 000 FCFA","Plomberie");
}

function token(u){return jwt.sign({id:u.id,role:u.role},SECRET,{expiresIn:"7d"})}
function auth(req,res,next){try{const h=req.headers.authorization||""; if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Connexion requise"}); req.user=jwt.verify(h.slice(7),SECRET); const u=db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id); if(!u||u.blocked) return res.status(403).json({error:"Compte bloqué ou introuvable"}); req.me=u; next()}catch(e){res.status(401).json({error:"Session invalide"})}}
function role(r){return (req,res,next)=>req.me.role===r?next():res.status(403).json({error:"Accès refusé"})}
function audit(admin,action,type,id,details=""){db.prepare("INSERT INTO admin_audit(admin_id,action,target_type,target_id,details) VALUES(?,?,?,?,?)").run(admin,action,type,id,details)}

app.get("/api/health",(req,res)=>res.json({ok:true,city:"Djougou",version:"3.3"}));

app.post("/api/auth/register",(req,res)=>{
 const {name,phone,password,role="client",city="Djougou",neighborhood="",category="",description="",experience="",price=""}=req.body;
 if(!name||!phone||!password) return res.status(400).json({error:"Nom, téléphone et mot de passe requis"});
 if(!["client","provider"].includes(role)) return res.status(400).json({error:"Rôle invalide"});
 if(db.prepare("SELECT id FROM users WHERE phone=?").get(phone)) return res.status(409).json({error:"Numéro déjà utilisé"});
 const verified=role==="provider"?0:1;
 const info=db.prepare(`INSERT INTO users(name,phone,password,role,city,neighborhood,category,description,experience,price,verified) VALUES(?,?,?,?,?,?,?,?,?,?,?)`)
 .run(name,phone,bcrypt.hashSync(password,10),role,city,neighborhood,category,description,experience,price,verified);
 const u=db.prepare("SELECT * FROM users WHERE id=?").get(info.lastInsertRowid);
 res.json({token:token(u),user:{id:u.id,name:u.name,phone:u.phone,role:u.role,verified:u.verified,status:role==="provider"?"pending":"active"}});
});
app.post("/api/auth/login",(req,res)=>{
 const u=db.prepare("SELECT * FROM users WHERE phone=?").get(req.body.phone||"");
 if(!u||!bcrypt.compareSync(req.body.password||"",u.password)) return res.status(401).json({error:"Identifiants incorrects"});
 if(u.blocked) return res.status(403).json({error:"Compte bloqué"});
 res.json({token:token(u),user:{id:u.id,name:u.name,phone:u.phone,role:u.role,verified:u.verified,city:u.city,neighborhood:u.neighborhood}});
});
app.get("/api/me",auth,(req,res)=>{const u={...req.me}; delete u.password; res.json(u)});

app.get("/api/categories",(req,res)=>res.json(db.prepare("SELECT * FROM categories WHERE active=1 ORDER BY name").all()));

app.get("/api/providers",(req,res)=>{
 const q=(req.query.q||"").trim(), city=req.query.city||"Djougou", cat=req.query.category||"";
 let sql=`SELECT id,name,phone,city,neighborhood,category,description,experience,price,verified,
 (SELECT ROUND(AVG(rating),1) FROM reviews r WHERE r.provider_id=users.id) rating,
 (SELECT COUNT(*) FROM reviews r WHERE r.provider_id=users.id) reviews
 FROM users WHERE role='provider' AND blocked=0 AND verified=1 AND city=?`;
 const args=[city]; if(q){sql+=" AND (name LIKE ? OR category LIKE ? OR description LIKE ?)"; args.push("%"+q+"%","%"+q+"%","%"+q+"%")}
 if(cat){sql+=" AND category=?";args.push(cat)} sql+=" ORDER BY rating DESC, name";
 res.json(db.prepare(sql).all(...args));
});
app.get("/api/providers/:id", (req,res)=>{
 const u=db.prepare(`SELECT id,name,phone,city,neighborhood,category,description,experience,price,verified,
 (SELECT ROUND(AVG(rating),1) FROM reviews r WHERE r.provider_id=users.id) rating
 FROM users WHERE id=? AND role='provider'`).get(req.params.id);
 if(!u) return res.status(404).json({error:"Prestataire introuvable"});
 u.services=db.prepare("SELECT * FROM services WHERE provider_id=? AND active=1").all(u.id);
 res.json(u);
});

app.post("/api/services",auth,role("provider"),(req,res)=>{
 if(req.me.verified!==1) return res.status(403).json({error:"Votre profil prestataire doit être validé par Kpata avant de publier un service."});
 const {name,description="",price="",category=req.me.category}=req.body;
 if(!name) return res.status(400).json({error:"Nom du service requis"});
 const info=db.prepare("INSERT INTO services(provider_id,name,description,price,category) VALUES(?,?,?,?,?)").run(req.me.id,name,description,price,category);
 res.json(db.prepare("SELECT * FROM services WHERE id=?").get(info.lastInsertRowid));
});
app.get("/api/my/services",auth,role("provider"),(req,res)=>res.json(db.prepare("SELECT * FROM services WHERE provider_id=? ORDER BY id DESC").all(req.me.id)));

app.post("/api/requests",auth,role("client"),(req,res)=>{
 const {provider_id,service_id,location="",notes="",preferred_time=""}=req.body;
 const p=db.prepare("SELECT id FROM users WHERE id=? AND role='provider' AND verified=1 AND blocked=0").get(provider_id);
 if(!p) return res.status(400).json({error:"Prestataire non disponible"});
 const info=db.prepare(`INSERT INTO requests(client_id,provider_id,service_id,location,notes,preferred_time,status) VALUES(?,?,?,?,?,?,?)`)
 .run(req.me.id,provider_id,service_id||null,location,notes,preferred_time,"pending");
 res.json(db.prepare("SELECT * FROM requests WHERE id=?").get(info.lastInsertRowid));
});
app.get("/api/my/requests",auth,(req,res)=>{
 let sql=`SELECT r.*, c.name client_name,c.phone client_phone,p.name provider_name,p.phone provider_phone,
 s.name service_name, s.price service_price
 FROM requests r JOIN users c ON c.id=r.client_id JOIN users p ON p.id=r.provider_id
 LEFT JOIN services s ON s.id=r.service_id WHERE `;
 sql+=req.me.role==="client"?"r.client_id=?":"r.provider_id=?";
 res.json(db.prepare(sql+" ORDER BY r.id DESC").all(req.me.id));
});
app.patch("/api/requests/:id/status",auth,(req,res)=>{
 const r=db.prepare("SELECT * FROM requests WHERE id=?").get(req.params.id);
 if(!r) return res.status(404).json({error:"Demande introuvable"});
 const allowed={provider:["accepted","rejected","in_progress","completed"],client:["cancelled","confirmed"]};
 if(!allowed[req.me.role]?.includes(req.body.status)) return res.status(400).json({error:"Statut non autorisé"});
 if(req.me.role==="provider" && r.provider_id!==req.me.id || req.me.role==="client" && r.client_id!==req.me.id) return res.status(403).json({error:"Accès refusé"});
 const next=req.body.status, current=r.status;
 const valid={
  pending:["accepted","rejected","cancelled"], accepted:["in_progress","cancelled"], in_progress:["completed"], completed:["confirmed"]
 };
 if(!valid[current]?.includes(next)) return res.status(400).json({error:`Transition ${current} → ${next} non autorisée`});
 db.prepare("UPDATE requests SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(next,r.id);
 res.json(db.prepare("SELECT * FROM requests WHERE id=?").get(r.id));
});

app.post("/api/reviews",auth,role("client"),(req,res)=>{
 const r=db.prepare("SELECT * FROM requests WHERE id=? AND client_id=? AND status='confirmed'").get(req.body.request_id,req.me.id);
 if(!r) return res.status(400).json({error:"La prestation doit être confirmée avant l'avis"});
 if(db.prepare("SELECT id FROM reviews WHERE request_id=?").get(r.id)) return res.status(409).json({error:"Avis déjà envoyé"});
 const rating=Math.max(1,Math.min(5,Number(req.body.rating||5)));
 db.prepare("INSERT INTO reviews(request_id,client_id,provider_id,rating,comment) VALUES(?,?,?,?,?)").run(r.id,req.me.id,r.provider_id,rating,req.body.comment||"");
 res.json({ok:true});
});

app.get("/api/provider/dashboard",auth,role("provider"),(req,res)=>{
 const counts={pending:0,accepted:0,in_progress:0,completed:0};
 db.prepare("SELECT status,COUNT(*) c FROM requests WHERE provider_id=? GROUP BY status").all(req.me.id).forEach(x=>counts[x.status]=x.c);
 const avg=db.prepare("SELECT ROUND(AVG(rating),1) rating,COUNT(*) reviews FROM reviews WHERE provider_id=?").get(req.me.id);
 const services=db.prepare("SELECT COUNT(*) c FROM services WHERE provider_id=? AND active=1").get(req.me.id).c;
 res.json({profile:{id:req.me.id,name:req.me.name,verified:req.me.verified,city:req.me.city,neighborhood:req.me.neighborhood,category:req.me.category,description:req.me.description,experience:req.me.experience,price:req.me.price},counts,rating:avg.rating||0,reviews:avg.reviews,services});
});

app.get("/api/admin/providers/pending",auth,role("admin"),(req,res)=>res.json(db.prepare("SELECT id,name,phone,city,neighborhood,category,description,experience,price,verified,created_at FROM users WHERE role='provider' AND verified=0 AND blocked=0 ORDER BY id DESC").all()));
app.patch("/api/admin/providers/:id/verification",auth,role("admin"),(req,res)=>{
 const {status}=req.body; const v=status==="approved"?1:status==="rejected"?-1:0;
 db.prepare("UPDATE users SET verified=? WHERE id=? AND role='provider'").run(v,req.params.id); audit(req.me.id,"provider_"+status,"user",req.params.id);
 res.json({ok:true});
});
app.patch("/api/admin/users/:id/block",auth,role("admin"),(req,res)=>{
 const b=req.body.blocked?1:0; db.prepare("UPDATE users SET blocked=? WHERE id=?").run(b,req.params.id); audit(req.me.id,b?"block":"unblock","user",req.params.id); res.json({ok:true});
});
app.post("/api/admin/payments",auth,role("admin"),(req,res)=>{
 const amount=Number(req.body.amount||0), rate=Number(req.body.commission_rate??10);
 if(amount<=0) return res.status(400).json({error:"Montant invalide"});
 const commission=amount*rate/100, provider_amount=amount-commission;
 const i=db.prepare("INSERT INTO payments(request_id,amount,commission_rate,commission,provider_amount,method,status) VALUES(?,?,?,?,?,?,?)")
 .run(req.body.request_id,amount,rate,commission,provider_amount,req.body.method||"cash","recorded");
 res.json(db.prepare("SELECT * FROM payments WHERE id=?").get(i.lastInsertRowid));
});
app.get("/api/admin/finance",auth,role("admin"),(req,res)=>{
 res.json(db.prepare("SELECT COUNT(*) payments,COALESCE(SUM(amount),0) volume,COALESCE(SUM(commission),0) commission,COALESCE(SUM(provider_amount),0) provider_total FROM payments").get());
});
app.get("/api/admin/stats",auth,role("admin"),(req,res)=>{
 res.json({
  users:db.prepare("SELECT COUNT(*) c FROM users WHERE role!='admin'").get().c,
  providers:db.prepare("SELECT COUNT(*) c FROM users WHERE role='provider'").get().c,
  pendingProviders:db.prepare("SELECT COUNT(*) c FROM users WHERE role='provider' AND verified=0 AND blocked=0").get().c,
  requests:db.prepare("SELECT COUNT(*) c FROM requests").get().c,
  completed:db.prepare("SELECT COUNT(*) c FROM requests WHERE status IN ('completed','confirmed')").get().c,
  finance:db.prepare("SELECT COALESCE(SUM(commission),0) commission,COALESCE(SUM(amount),0) volume FROM payments").get()
 });
});

app.get("/api/admin/requests",auth,role("admin"),(req,res)=>res.json(db.prepare(`SELECT r.*,c.name client_name,p.name provider_name,s.name service_name
FROM requests r JOIN users c ON c.id=r.client_id JOIN users p ON p.id=r.provider_id LEFT JOIN services s ON s.id=r.service_id ORDER BY r.id DESC`).all()));
app.get("/api/admin/users",auth,role("admin"),(req,res)=>res.json(db.prepare("SELECT id,name,phone,role,city,neighborhood,category,verified,blocked,created_at FROM users ORDER BY id DESC").all()));

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`Kpata ${PORT}`));
