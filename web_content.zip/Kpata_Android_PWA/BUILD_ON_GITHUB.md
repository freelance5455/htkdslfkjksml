# Construire Kpata.apk automatiquement

Le projet contient maintenant un workflow GitHub Actions dans `.github/workflows/android-apk.yml`.

## Depuis un téléphone
1. Crée un compte GitHub si nécessaire.
2. Crée un dépôt, par exemple `kpata`.
3. Envoie tout le contenu de ce dossier dans le dépôt.
4. Ouvre l'onglet **Actions**.
5. Choisis **Build Kpata APK**.
6. Appuie sur **Run workflow**.
7. Quand la compilation est terminée, ouvre la tâche réussie et récupère l'artefact **Kpata-debug-apk**.
8. L'artefact contient `app-debug.apk`, installable pour les tests.

## Important
- Cet APK de test sera compilé par GitHub avec Android SDK + Gradle.
- L'application Android charge actuellement une URL de serveur indiquée dans `android/app/src/main/java/com/kpata/app/MainActivity.java`.
- Tant que `https://REPLACE-WITH-KPATA-DOMAIN/` n'est pas remplacé par le vrai domaine HTTPS de Kpata, l'application ne pourra pas communiquer avec le serveur réel.
- Pour une publication, il faudra ensuite une build **release signée** avec une clé de signature conservée en sécurité. Android exige une signature pour les APK distribués, et Google Play recommande le format AAB pour les nouvelles applications.
