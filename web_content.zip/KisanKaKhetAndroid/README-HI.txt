किसान का खेत — Android ऐप प्रोजेक्ट

यह ZIP Android Studio में APK बनाने के लिए तैयार प्रोजेक्ट है।
इस वातावरण में Android SDK/Gradle उपलब्ध नहीं था, इसलिए APK बाइनरी सीधे compile नहीं की जा सकी।

APK बनाने के चरण:
1. कंप्यूटर में Android Studio इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio में Extract किया हुआ KisanKaKhet फोल्डर Open करें।
4. Gradle Sync पूरा होने दें (इंटरनेट जरूरी है)।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK app/build/outputs/apk/debug/app-debug.apk में मिलेगा।
7. APK को Android फोन में भेजकर इंस्टॉल करें। जरूरत पड़े तो फोन में इस स्रोत से Install unknown apps की अनुमति दें।

ऐप का नाम: किसान का खेत
Package: com.mrmukamrawat.kisankakhet
Minimum Android: Android 6.0 (API 23)

नोट: गेम की HTML/JavaScript सामग्री assets/index.html में रखी गई है।
