import { useEffect, useRef, useState } from 'react';
import { BatteryCharging, Bell, BellOff, Check, ChevronDown, Info, Moon, PlugZap, Sun, Volume2, VolumeX, Zap } from 'lucide-react';

type BatteryManagerLike = EventTarget & { charging: boolean; level: number };
type BatteryNavigator = Navigator & { getBattery?: () => Promise<BatteryManagerLike> };
type BatteryState = { level: number; charging: boolean };
type SessionState = { charging: boolean; triggered: boolean; level: number };

const SETTINGS_KEY = 'chargealert.settings.v1';
const SESSION_KEY = 'chargealert.session.v1';

function getStoredSettings(): { target: number; enabled: boolean; dark: boolean } {
  try {
    const value = JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}');
    return {
      target: Number.isInteger(value.target) && value.target >= 1 && value.target <= 100 ? value.target : 80,
      enabled: value.enabled === true,
      dark: typeof value.dark === 'boolean' ? value.dark : window.matchMedia('(prefers-color-scheme: dark)').matches,
    };
  } catch {
    return { target: 80, enabled: false, dark: false };
  }
}

function getStoredSession(): SessionState | null {
  try {
    const value = JSON.parse(localStorage.getItem(SESSION_KEY) || 'null');
    if (value && typeof value.charging === 'boolean' && typeof value.triggered === 'boolean' && typeof value.level === 'number') return value;
  } catch { /* Storage may be unavailable. */ }
  return null;
}

function BatteryArt({ level, charging }: { level: number | null; charging: boolean }) {
  const fill = level === null ? 0 : Math.max(4, Math.min(100, level));
  return (
    <div className="relative mx-auto flex h-48 w-48 items-center justify-center sm:h-56 sm:w-56" aria-hidden="true">
      <div className="absolute inset-0 rounded-full bg-emerald-400/10 blur-3xl dark:bg-emerald-400/10" />
      <div className="absolute inset-3 rounded-full border border-emerald-500/15" />
      <div className="absolute inset-0 rounded-full border border-dashed border-emerald-500/20 animate-[spin_40s_linear_infinite]" />
      <div className="relative flex h-32 w-[78px] items-center justify-center rounded-[19px] border-[3px] border-slate-800 bg-white shadow-[0_18px_55px_-12px_rgba(16,185,129,0.25)] dark:border-slate-200 dark:bg-slate-900 sm:h-36 sm:w-[86px]">
        <span className="absolute -top-[9px] h-[6px] w-[30px] rounded-t-[4px] bg-slate-800 dark:bg-slate-200" />
        <div className="absolute inset-[5px] overflow-hidden rounded-[12px] bg-slate-100 dark:bg-slate-800">
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-emerald-600 via-emerald-500 to-teal-300 transition-[height] duration-700" style={{ height: `${fill}%` }}>
            <div className="absolute inset-x-0 top-0 h-2 bg-white/30 blur-sm" />
          </div>
        </div>
        {charging && <Zap className="relative z-10 h-9 w-9 fill-white text-white drop-shadow-md animate-pulse" strokeWidth={2.5} />}
      </div>
    </div>
  );
}

export default function App() {
  const [initial] = useState(getStoredSettings);
  const [target, setTarget] = useState(initial.target);
  const [enabled, setEnabled] = useState(initial.enabled);
  const [dark, setDark] = useState(initial.dark);
  const [battery, setBattery] = useState<BatteryState | null>(null);
  const [batteryStatus, setBatteryStatus] = useState<'loading' | 'ready' | 'unavailable'>('loading');
  const [notificationStatus, setNotificationStatus] = useState<NotificationPermission | 'unavailable'>(() => typeof Notification === 'undefined' ? 'unavailable' : Notification.permission);
  const [message, setMessage] = useState('');
  const [ringing, setRinging] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const enabledRef = useRef(enabled);
  const targetRef = useRef(target);
  const sessionRef = useRef<SessionState | null>(getStoredSession());
  const audioRef = useRef<AudioContext | null>(null);
  const soundTimersRef = useRef<number[]>([]);
  const activeSoundsRef = useRef<OscillatorNode[]>([]);
  const ringingTimeoutRef = useRef<number | null>(null);

  function stopSound() {
    soundTimersRef.current.forEach(window.clearTimeout);
    soundTimersRef.current = [];
    activeSoundsRef.current.forEach(osc => { try { osc.stop(); } catch { /* Already stopped. */ } });
    activeSoundsRef.current = [];
    if (ringingTimeoutRef.current !== null) window.clearTimeout(ringingTimeoutRef.current);
    ringingTimeoutRef.current = null;
    setRinging(false);
  }

  function ring(level: number) {
    setMessage(`شارژ به ${level}٪ رسید!`);
    setRinging(true);
    try {
      const AudioContextClass = window.AudioContext;
      if (AudioContextClass) {
        const ctx = audioRef.current ?? new AudioContextClass();
        audioRef.current = ctx;
        void ctx.resume().then(() => {
          for (let i = 0; i < 5; i++) {
            const timer = window.setTimeout(() => {
              const oscillator = ctx.createOscillator();
              const gain = ctx.createGain();
              oscillator.type = 'sine';
              oscillator.frequency.setValueAtTime(i % 2 ? 660 : 880, ctx.currentTime);
              gain.gain.setValueAtTime(0.0001, ctx.currentTime);
              gain.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.03);
              gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.36);
              oscillator.connect(gain);
              gain.connect(ctx.destination);
              oscillator.start();
              oscillator.stop(ctx.currentTime + 0.38);
              activeSoundsRef.current.push(oscillator);
            }, i * 510);
            soundTimersRef.current.push(timer);
          }
        }).catch(() => setMessage('شارژ به حد تنظیم‌شده رسید، اما پخش صدا در این دستگاه ممکن نبود.'));
      }
    } catch {
      setMessage('شارژ به حد تنظیم‌شده رسید، اما پخش صدا در این دستگاه ممکن نبود.');
    }
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
      try { new Notification('ChargeAlert • هشدار شارژ', { body: `باتری به ${level}٪ رسید. می‌توانید شارژر را جدا کنید.`, tag: 'chargealert-target' }); } catch { /* Notifications are not available in this view. */ }
    }
    ringingTimeoutRef.current = window.setTimeout(() => setRinging(false), 3000);
  }

  // Keep the battery listener independent of UI renders; the device reports changes only when needed.
  const ringRef = useRef(ring);
  ringRef.current = ring;

  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark);
  }, [dark]);

  useEffect(() => {
    try { localStorage.setItem(SETTINGS_KEY, JSON.stringify({ target, enabled, dark })); } catch { /* Storage may be unavailable. */ }
    targetRef.current = target;
    enabledRef.current = enabled;
  }, [target, enabled, dark]);

  useEffect(() => {
    let mounted = true;
    let manager: BatteryManagerLike | null = null;
    const getBattery = (navigator as BatteryNavigator).getBattery;
    if (!getBattery) {
      setBatteryStatus('unavailable');
      return;
    }
    const update = () => {
      if (!manager || !mounted) return;
      const level = Math.round(manager.level * 100);
      const charging = manager.charging;
      const previous = sessionRef.current;
      let triggered = previous?.triggered ?? false;
      if (!previous || (!previous.charging && charging)) {
        // Don't ring immediately if this session was first seen above the target.
        triggered = level >= targetRef.current;
      } else if (!charging) {
        triggered = false;
      } else if (level < targetRef.current && previous.level < targetRef.current && previous.triggered) {
        // The battery level has fallen below the target while still plugged in.
        triggered = false;
      }
      if (charging && enabledRef.current && !triggered && previous && previous.charging && previous.level < targetRef.current && level >= targetRef.current) {
        triggered = true;
        ringRef.current(level);
      }
      sessionRef.current = { charging, triggered, level };
      try { localStorage.setItem(SESSION_KEY, JSON.stringify(sessionRef.current)); } catch { /* Storage may be unavailable. */ }
      setBattery({ level, charging });
      setBatteryStatus('ready');
    };
    getBattery.call(navigator).then(result => {
      if (!mounted) return;
      manager = result;
      update();
      manager.addEventListener('levelchange', update);
      manager.addEventListener('chargingchange', update);
    }).catch(() => { if (mounted) setBatteryStatus('unavailable'); });
    return () => {
      mounted = false;
      manager?.removeEventListener('levelchange', update);
      manager?.removeEventListener('chargingchange', update);
    };
  }, []);

  useEffect(() => () => {
    soundTimersRef.current.forEach(window.clearTimeout);
    if (ringingTimeoutRef.current !== null) window.clearTimeout(ringingTimeoutRef.current);
    activeSoundsRef.current.forEach(osc => { try { osc.stop(); } catch { /* Already stopped. */ } });
    if (audioRef.current) void audioRef.current.close();
  }, []);

  async function toggleAlarm() {
    if (enabled) {
      enabledRef.current = false;
      setEnabled(false);
      stopSound();
      setMessage('هشدار خاموش شد.');
      return;
    }
    enabledRef.current = true;
    setEnabled(true);
    setMessage('هشدار روشن شد.');
    // Unlock audio from this user gesture so it can ring at the target later.
    try {
      const ctx = audioRef.current ?? new AudioContext();
      audioRef.current = ctx;
      await ctx.resume();
    } catch { setMessage('هشدار روشن شد؛ پخش صدا ممکن است در این دستگاه محدود باشد.'); }
    if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
      try {
        const permission = await Notification.requestPermission();
        setNotificationStatus(permission);
      } catch { setNotificationStatus('unavailable'); }
    }
  }

  function updateTarget(next: number) {
    const safe = Math.min(100, Math.max(1, next));
    targetRef.current = safe;
    setTarget(safe);
    if (sessionRef.current?.charging) {
      sessionRef.current = { ...sessionRef.current, triggered: sessionRef.current.level >= safe };
      try { localStorage.setItem(SESSION_KEY, JSON.stringify(sessionRef.current)); } catch { /* Storage may be unavailable. */ }
    }
    setMessage('');
  }

  return (
    <div className="min-h-dvh bg-[#f5f7f6] text-slate-900 transition-colors duration-300 dark:bg-[#0c1412] dark:text-slate-50">
      <div className="mx-auto w-full max-w-6xl px-4 pb-12 pt-5 sm:px-6 sm:pt-8 lg:px-8">
        <header className="flex items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-emerald-500 text-white shadow-lg shadow-emerald-500/20"><BatteryCharging size={24} strokeWidth={2.3} /></div>
            <div className="min-w-0"><h1 className="text-lg font-black leading-tight tracking-tight sm:text-xl" dir="ltr">ChargeAlert</h1><p className="text-xs text-slate-500 dark:text-slate-400 sm:text-sm">هشدار هوشمند شارژ باتری</p></div>
          </div>
          <button data-testid="theme-toggle" type="button" onClick={() => setDark(!dark)} aria-label={dark ? 'حالت روشن' : 'حالت تاریک'} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border border-slate-200 bg-white text-slate-600 transition hover:border-emerald-400 hover:text-emerald-600 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-200">{dark ? <Sun size={21} /> : <Moon size={21} />}</button>
        </header>

        <main className="mx-auto mt-8 max-w-4xl sm:mt-12">
          <div className="mb-8 text-center sm:mb-10"><span className="inline-flex items-center gap-2 rounded-full border border-emerald-500/15 bg-emerald-500/10 px-4 py-1.5 text-xs font-bold text-emerald-700 dark:text-emerald-300"><span className={`h-2 w-2 rounded-full ${enabled ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`} />{enabled ? 'هشدار فعال است' : 'هشدار خاموش است'}</span><h2 className="mt-5 text-3xl font-black leading-tight sm:text-4xl">شارژ رو به‌موقع متوقف کن</h2><p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500 dark:text-slate-400 sm:text-base">درصد دلخواهت رو انتخاب کن تا هنگام رسیدن باتری به اون، بهت خبر بدیم.</p></div>

          <div className="grid grid-cols-1 gap-5 md:grid-cols-[1.1fr_0.9fr] md:items-stretch">
            <section className="relative overflow-hidden rounded-[28px] border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-40px_rgba(15,23,42,0.35)] dark:border-white/10 dark:bg-[#15201c] sm:p-8" aria-label="وضعیت باتری">
              <div className="flex items-center justify-between gap-3"><span className="text-sm font-bold text-slate-500 dark:text-slate-400">وضعیت فعلی باتری</span><span className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold ${battery?.charging ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' : 'bg-slate-100 text-slate-500 dark:bg-white/5 dark:text-slate-300'}`}>{battery?.charging ? <><PlugZap size={14} /> در حال شارژ</> : battery ? 'متصل نیست' : 'در انتظار باتری'}</span></div>
              <BatteryArt level={battery?.level ?? null} charging={battery?.charging ?? false} />
              <div className="text-center"><div data-testid="battery-percentage" className="text-6xl font-black tabular-nums tracking-tight text-slate-900 dark:text-white sm:text-7xl" dir="ltr">{batteryStatus === 'ready' && battery ? `${battery.level}%` : '—%'}</div><p className="mt-2 text-sm text-slate-500 dark:text-slate-400">{batteryStatus === 'loading' ? 'در حال خواندن وضعیت باتری…' : batteryStatus === 'unavailable' ? 'خواندن باتری در این دستگاه پشتیبانی نمی‌شود.' : battery?.charging ? 'باتری در حال شارژ شدن است' : 'شارژر متصل نیست'}</p></div>
            </section>

            <section className="flex flex-col rounded-[28px] border border-slate-200/80 bg-white p-6 shadow-[0_20px_60px_-40px_rgba(15,23,42,0.35)] dark:border-white/10 dark:bg-[#15201c] sm:p-8" aria-label="تنظیم هشدار">
              <div className="mb-8 flex items-center gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"><Bell size={21} /></div><div><h3 className="text-lg font-extrabold">تنظیم هشدار</h3><p className="text-xs text-slate-500 dark:text-slate-400">درصد موردنظرت رو انتخاب کن</p></div></div>
              <label htmlFor="target-range" className="text-sm font-bold text-slate-700 dark:text-slate-200">وقتی باتری رسید به</label>
              <div className="mt-4 flex items-center justify-between gap-4 rounded-2xl bg-slate-50 px-5 py-4 dark:bg-white/5"><span className="text-sm text-slate-500 dark:text-slate-400">درصد هدف</span><span data-testid="target-value" className="text-4xl font-black tabular-nums text-emerald-600 dark:text-emerald-400" dir="ltr">{target}٪</span></div>
              <input data-testid="target-slider" id="target-range" type="range" min="1" max="100" value={target} onChange={e => updateTarget(Number(e.target.value))} className="target-range mt-7 h-3 w-full cursor-pointer appearance-none rounded-full bg-slate-200 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-emerald-500 dark:bg-slate-700" style={{ backgroundImage: `linear-gradient(to right, #10b981 ${target}%, transparent ${target}%)` }} />
              <div className="mt-3 flex justify-between text-xs font-semibold text-slate-400" dir="ltr"><span>1%</span><span>100%</span></div>
              <div className="mt-auto pt-8"><button data-testid="alarm-toggle" type="button" onClick={toggleAlarm} className={`flex min-h-14 w-full items-center justify-center gap-3 rounded-2xl px-5 text-base font-extrabold transition hover:-translate-y-0.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-500 ${enabled ? 'border border-slate-200 bg-slate-100 text-slate-800 hover:bg-slate-200 dark:border-white/10 dark:bg-white/10 dark:text-white dark:hover:bg-white/15' : 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/25 hover:bg-emerald-600'}`}>{enabled ? <><BellOff size={21} /> خاموش کردن هشدار</> : <><Bell size={21} /> روشن کردن هشدار</>}</button><p className="mt-4 flex items-start gap-2 text-xs leading-6 text-slate-500 dark:text-slate-400"><Check size={16} className="mt-1 shrink-0 text-emerald-500" />تنظیمات به‌صورت خودکار روی همین دستگاه ذخیره می‌شوند.</p></div>
            </section>
          </div>

          {message && <div data-testid="alarm-message" role="status" className={`mt-5 flex items-center justify-between gap-3 rounded-2xl border px-5 py-4 text-sm font-bold ${ringing ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-800 dark:text-emerald-300' : 'border-slate-200 bg-white text-slate-700 dark:border-white/10 dark:bg-[#15201c] dark:text-slate-200'}`}><span className="flex items-center gap-2">{ringing ? <Volume2 size={20} /> : <Check size={20} />}{message}</span>{ringing && <button data-testid="stop-alarm" type="button" onClick={stopSound} className="flex min-h-11 shrink-0 items-center gap-1 rounded-xl px-3 transition hover:bg-emerald-500/10 focus-visible:outline-2 focus-visible:outline-emerald-500"><VolumeX size={17} /> قطع صدا</button>}</div>}

          <div className="mt-5 rounded-2xl border border-slate-200/80 bg-white px-5 py-4 dark:border-white/10 dark:bg-[#15201c]"><div className="flex items-start gap-3"><div className="mt-0.5 rounded-xl bg-slate-100 p-2 text-slate-500 dark:bg-white/5 dark:text-slate-300"><Info size={18} /></div><div className="min-w-0 flex-1"><p className="text-sm font-bold">دربارهٔ عملکرد هشدار</p><p className="mt-1 text-sm leading-7 text-slate-500 dark:text-slate-400">{batteryStatus === 'unavailable' ? 'این دستگاه امکان خواندن درصد باتری را در اختیار برنامه نمی‌گذارد؛ بنابراین هشدار شارژ هم در آن کار نمی‌کند.' : notificationStatus === 'denied' ? 'اجازهٔ اعلان داده نشده؛ هشدار صوتی فقط تا وقتی برنامه باز است پخش می‌شود.' : 'هشدار فقط وقتی برنامه باز و فعال باشد، هنگام رسیدن به درصد هدف یک‌بار اجرا می‌شود.'}</p><button data-testid="limitations-toggle" type="button" onClick={() => setShowInfo(!showInfo)} aria-expanded={showInfo} className="mt-2 flex min-h-11 items-center gap-1 text-sm font-bold text-emerald-700 transition hover:text-emerald-800 focus-visible:outline-2 focus-visible:outline-emerald-500 dark:text-emerald-400"><ChevronDown size={16} className={`transition-transform ${showInfo ? 'rotate-180' : ''}`} /> نکتهٔ مهم دربارهٔ هشدار پس‌زمینه</button>{showInfo && <p data-testid="limitations-detail" className="pb-2 text-sm leading-7 text-slate-500 dark:text-slate-400">این نسخه فقط زمانی می‌تواند تغییر شارژ را تشخیص دهد که برنامه باز و فعال باشد. پس از بسته شدن برنامه، پخش صدا و ارسال اعلان در پس‌زمینه تضمین نمی‌شود. برای هشدار واقعی با برنامهٔ بسته، اجرای بومی اندروید لازم است.</p>}</div></div></div>
          <footer className="mt-8 text-center text-xs text-slate-400">ChargeAlert · ساده، سبک و بدون تبلیغات</footer>
        </main>
      </div>
    </div>
  );
}
