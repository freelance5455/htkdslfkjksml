---
name: Obsidian Cyber-Luxe
colors:
  surface: '#121318'
  surface-dim: '#121318'
  surface-bright: '#38393e'
  surface-container-lowest: '#0d0e12'
  surface-container-low: '#1a1b20'
  surface-container: '#1e1f24'
  surface-container-high: '#292a2f'
  surface-container-highest: '#34343a'
  on-surface: '#e3e2e8'
  on-surface-variant: '#bac9cc'
  inverse-surface: '#e3e2e8'
  inverse-on-surface: '#2f3035'
  outline: '#849396'
  outline-variant: '#3b494c'
  surface-tint: '#00daf3'
  primary: '#c3f5ff'
  on-primary: '#00363d'
  primary-container: '#00e5ff'
  on-primary-container: '#00626e'
  inverse-primary: '#006875'
  secondary: '#dcb8ff'
  on-secondary: '#480081'
  secondary-container: '#7701d0'
  on-secondary-container: '#dcb7ff'
  tertiary: '#e8ecff'
  on-tertiary: '#002d6e'
  tertiary-container: '#bfd0ff'
  on-tertiary-container: '#0053c0'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#9cf0ff'
  primary-fixed-dim: '#00daf3'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#efdbff'
  secondary-fixed-dim: '#dcb8ff'
  on-secondary-fixed: '#2c0051'
  on-secondary-fixed-variant: '#6700b5'
  tertiary-fixed: '#d9e2ff'
  tertiary-fixed-dim: '#b0c6ff'
  on-tertiary-fixed: '#001945'
  on-tertiary-fixed-variant: '#00429b'
  background: '#121318'
  on-background: '#e3e2e8'
  surface-variant: '#34343a'
typography:
  display-hero:
    fontFamily: Sora
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Sora
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Sora
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Sora
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Sora
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-telemetry:
    fontFamily: Space Mono
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.05em
  label-badge:
    fontFamily: Space Mono
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  gutter-lg: 1.5rem
  margin: 1.25rem
  margin-mobile: 1rem
  margin-tablet: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
This design system defines an ultra-futuristic, high-luxury cybernetic utility experience tailored for demanding network privacy tools. It fuses deep obsidian dark mode architecture with electric neon luminescences—specifically laser cyan, hyper-electric blue, and vivid ultraviolet violet.

### Brand Personality & Emotional Impact
- **Impenetrable Security & Precision:** The interface exudes mathematical exactitude, absolute zero-leak privacy, and bleeding-edge cryptographic engineering.
- **Hypnotic Fluidity:** Motion and depth mirror luminous particle fields and 3D refractive glass optics, evoking seamless high-speed transmission.
- **Bi-Directional Fluency:** Engineered to function symmetrically in both LTR (English) and RTL (Persian/Farsi) layouts, maintaining typographic cadence, optical weight balance, and technical clarity across both scripts.

### Aesthetic Movement
A synthesis of **Cyber-Glassmorphism** and **High-Tech Neomorphism**:
- Semi-translucent obsidian backplates (acrylic frosted glass with dual-tinted rim lights).
- Deep spatial elevation using multi-layered ambient neon photoluminescence rather than muddy drop shadows.
- Micro-faceted chamfers, glowing circuit traces, and 3D luminescent connection cores.

## Colors
The palette is built from an abyss of deep space blacks layered with high-intensity photonic light emitters:

- **Primary (`#00E5FF` - Hyper Cyan / Electric Azure):** Drives the primary connection state, active telemetry nodes, encrypted tunnels, and critical CTAs.
- **Secondary (`#8A2BE2` - Deep Neon Violet / Astral Purple):** Denotes secondary spatial rings, protocol switching badges, VIP server clusters, and premium encryption tiers.
- **Tertiary (`#2979FF` - Quantum Cobalt Blue):** Bridges Cyan and Violet in complex radial gradients, active orb refractions, and real-time upload/download charts.
- **Neutral Surface Matrix (`#06070B` to `#161922`):**
  - Void Canvas: `#040508`
  - Obsidian Base: `#06070B`
  - Glass Surface: `rgba(18, 22, 34, 0.65)`
  - Frosted Border Accent: `rgba(0, 229, 255, 0.22)`
  - Text Primary: `#F0F4FC`
  - Text Secondary / Muted: `#7E8B9F`
- **Telemetry Semantics:**
  - Excellent Latency (<40ms): `#00FFB2` (Neon Emerald)
  - Medium Latency (40–120ms): `#FFD000` (Cyber Amber)
  - Severe / Packet Loss (>120ms): `#FF2A6D` (Neon Crimson)

## Typography
Typographic architecture requires clinical technical legibility blended with futuristic character:

- **Headlines (Sora):** Geometric, wide optical structure providing high-tech luxury weight.
- **Body Text (Be Vietnam Pro):** Crisp humanist geometry ensuring effortless readability during extended scanning of connection logs and configuration panels.
- **Telemetry & Protocol Badges (Space Mono):** Fixed-width tabular figures for millisecond ping updates, raw bitrates, IP masks, and cryptographic hashes.

### Persian & RTL Optimization (Vazirmatn / Shabnam Pairing)
When the application switches to Persian/Farsi locale:
- Sora seamlessly translates to **Vazirmatn** (SemiBold/Bold/Black weights), keeping matching line-height increments (+4px vertical clearance to accommodate Persian diacritics).
- Telemetry figures and protocol names (V2Ray, VMess, Trojan, WireGuard) remain in fixed-width tabular alphanumeric characters, utilizing RTL contextual inline-mirroring so that unit markers (e.g., `ms` / `میلی‌ثانیه`, `MB/s`) flow naturally without layout breakage.

## Layout & Spacing
The layout follows a mobile-first, fluid cybernetic container model built around a primary tactical focal viewport:

- **Vertical Hierarchy:**
  1. **Status HUD / Header:** Compact 48px row displaying global kill-switch, VIP token status, and drawer triggers.
  2. **Central 3D Core Viewport:** A focused square bounding zone (height 260px–320px) reserved for the luminescent connection orb, orbital status rings, and one-tap engagement.
  3. **Telemetry Cockpit:** Bi-column or quad-pill cluster monitoring live throughput, ping, protocol indicator, and packet integrity.
  4. **Server Selector & Config Tray:** Scrollable bottom sheet card stack showcasing active routing nodes.

### Responsive Breakpoints & Sizing
- **Mobile (<600px):** 4-column fluid matrix; canvas outer margin `1rem`, card internal gaps `0.75rem`.
- **Tablet / Foldable (600px–1024px):** 8-column layout; split-screen HUD with the 3D Orb centered on the leading half and the server matrix/telemetry graphs pinned to the trailing half.

## Elevation & Depth
Depth in this system avoids standard muddy black shadows, using instead **diffuse photonic luminescence** and **acrylic refractive layering**:

### 1. Base Plate (Level 0)
Solid dark obsidian (`#040508`) with a subtle radial mesh gradient of deep indigo (`rgba(41, 121, 255, 0.08)`) and twilight purple (`rgba(138, 43, 226, 0.06)`).

### 2. Glass Cards (Level 1)
- Surface: `rgba(14, 18, 28, 0.6)`
- Backdrop Filter: `blur(20px) saturate(180%)`
- Outer Stroke: 1px continuous hairline gradient (`rgba(0, 229, 255, 0.35)` blending to `rgba(138, 43, 226, 0.15)` at diagonal light-source angles).
- Glow Rim: `box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.7), inset 0 1px 1px 0 rgba(255, 255, 255, 0.12)`.

### 3. Active Telemetry & Interactive Cards (Level 2)
Elevated floating cards feature an active under-glow:
- Glow Projection: `0 0 24px -4px rgba(0, 229, 255, 0.25)`
- Border Accent: Hairline gradient `rgba(0, 229, 255, 0.6)`.

### 4. 3D Orb / Main Activation Core (Level 3 - Hyper Elevation)
- Multi-tier radial projection:
  - Inner core glow: `0 0 45px rgba(0, 229, 255, 0.8)`
  - Secondary orbital aura: `0 0 90px rgba(138, 43, 226, 0.45)`
  - Atmospheric dispersion: `0 0 160px rgba(41, 121, 255, 0.25)`
- State transitions (Disconnected to Connected) morph the ambient atmosphere from idle twilight violet to brilliant hyper-cyan ring pulses.

## Shapes
A roundedness factor of `2` provides smooth aerodynamic contours (16px / 1rem on primary cards, 24px / 1.5rem on outer sheet wrappers), balancing sleek industrial hardware design with ultra-modern UI trends:

- **Cards & Enclosures:** Curvature radius of `16px` (`rounded-lg`) creates an ergonomic tactile panel aesthetic.
- **Badges & Chips:** `100px` (full pill) for protocol indicators (V2Ray, VMess, Trojan, OpenVPN, WireGuard), maintaining compact containment.
- **Connection Core:** Pure concentric geometry (`radius: 50%`) with multiple revolving orbital tracks and curved cybernetic ribbons.

## Components

### 1. 3D Glowing Connection Orb Switch
- **Visuals:** Floating concentric glass rings surrounding a twisted Möbius-inspired 3D prism core.
- **Idle State:** Deep violet luminescence, breathing pulse rate at 0.3Hz.
- **Connecting State:** Rapid dual-axis rotation, alternating cyan and ultraviolet ripples.
- **Secured State:** Vivid neon cyan beam with particle emissions; outer ring features rotational tick marks indicating real-time ping stability.

### 2. Protocol Badges & Chips
- **Geometry:** Pill container (`padding: 4px 12px`).
- **Surface:** `rgba(255, 255, 255, 0.04)` with a 1px border colored by protocol class:
  - *V2Ray / VLess:* Neon Cyan (`#00E5FF`)
  - *VMess:* Electric Cobalt (`#2979FF`)
  - *Trojan:* Vivid Purple (`#8A2BE2`)
  - *WireGuard:* Emerald Pulse (`#00FFB2`)
- **Typography:** `Space Mono`, uppercase, tracking `0.08em`.

### 3. Server Location Cards
- **Structure:** Glass container with flag icon/location glyph, server city name, load factor bar, and ping indicator.
- **Ping Monolith:** A miniature 3-bar vertical audio-wave style spark-indicator accompanied by exact numeric latency (e.g., `28 ms`).
- **Interactive State:** Ripple hover effect, active border shifts to full primary cyan gradient with a subtle inner edge glow.

### 4. Cybernetic Telemetry Dials & Graphs
- **Layout:** Dual HUD readout modules for **Upload** and **Download**.
- **Metrics:** Bold tabular numerals (`label-telemetry`), accompanied by animated mini neon bezier vectors graphing throughput curves.

### 5. Input Fields & Node Importers
- **Configuration Fields:** Recessed dark glass boxes (`rgba(6, 8, 12, 0.8)`) with internal drop shadows. Focus state ignites a 1px cyan neon border outline with zero offset glow.
- **RTL Sizing:** Input prefix labels, QR scanners, and clipboard action buttons cleanly mirror alignment in Farsi/RTL mode.

### 6. Buttons & Toggles
- **Primary Cyber Button:** High-intensity gradient fill (`linear-gradient(135deg, #00E5FF, #2979FF)`), dark bold text (`#040508`) for maximum contrast and legibility against high-emission backgrounds.
- **Secondary Ghost Button:** Transparent obsidian backplate with hairline violet border and high-opacity white text.
- **Kill-Switch Toggle:** Micro-mechanical slider with an energized cyan power-core that illuminates an internal lock icon when engaged.