Sri Krishna Interior Attendance App
This is an APK-ready web app package. A real signed Android APK cannot be compiled inside this chat environment. The package can be converted to APK with a Web-to-APK builder or Android Studio.
Features: worker, site, date, time, 1/2 hajri, rate, amount, local records, total, WhatsApp message, SK icon.
