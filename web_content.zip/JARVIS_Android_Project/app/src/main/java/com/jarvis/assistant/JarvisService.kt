package com.jarvis.assistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class JarvisService : Service(), TextToSpeech.OnInitListener {
    private var speech: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var awaitingCommand = false
    private var listening = false
    private var restarting = false
    private val handler = Handler(Looper.getMainLooper())
    private val channelId = "jarvis_voice"
    private val notificationId = 10

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(notificationId, makeNotification("Preparando micrófono…"))
        tts = TextToSpeech(this, this)

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNotification("No hay servicio de reconocimiento de voz")
            say("No encuentro reconocimiento de voz. Activa la aplicación de Google y sus servicios de voz.")
            return
        }

        try {
            speech = SpeechRecognizer.createSpeechRecognizer(this)
            speech?.setRecognitionListener(listener)
            updateNotification("Di Jarvis para activar un comando")
            handler.postDelayed({ listen() }, 700)
        } catch (e: Exception) {
            updateNotification("No se pudo iniciar el reconocimiento")
            say("No pude iniciar el micrófono. Comprueba los permisos.")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("es", "ES"))
            tts?.setSpeechRate(0.88f)
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
            if (ttsReady) say("JARVIS en línea. Di Jarvis para llamarme.")
            else Toast.makeText(this, "Instala los datos de voz en español en Ajustes", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "No se pudo iniciar la voz de Android", Toast.LENGTH_LONG).show()
        }
    }

    private fun makeNotification(message: String): Notification {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val pending = launch?.let {
            PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0))
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
                      else Notification.Builder(this)
        builder.setContentTitle("JARVIS")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
        if (pending != null) builder.setContentIntent(pending)
        return builder.build()
    }

    private fun updateNotification(message: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(notificationId, makeNotification(message))
    }

    private fun say(message: String) {
        if (ttsReady) {
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_${System.currentTimeMillis()}")
        } else {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun listen() {
        if (listening || speech == null || restarting) return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-ES")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            }
            listening = true
            updateNotification(if (awaitingCommand) "Escuchando tu instrucción…" else "Di Jarvis para activarme")
            speech?.startListening(intent)
        } catch (e: SecurityException) {
            listening = false
            updateNotification("Permiso de micrófono denegado")
            say("Necesito permiso para usar el micrófono.")
        } catch (e: Exception) {
            listening = false
            scheduleListen(1800)
        }
    }

    private fun scheduleListen(delay: Long = 1400) {
        if (restarting) return
        restarting = true
        handler.postDelayed({
            restarting = false
            listen()
        }, delay)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            updateNotification(if (awaitingCommand) "Te escucho…" else "Di Jarvis para activarme")
        }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { listening = false }
        override fun onError(error: Int) {
            listening = false
            val message = when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Permiso de micrófono denegado"
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Revisa tu conexión a internet"
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Esperando la palabra Jarvis"
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Reiniciando reconocimiento de voz"
                else -> "Reconocimiento pausado; intentando de nuevo"
            }
            updateNotification(message)
            scheduleListen(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 2200 else 1400)
        }
        override fun onResults(results: Bundle?) {
            listening = false
            val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()?.lowercase(Locale.ROOT).orEmpty()

            if (phrase.contains("jarvis")) {
                awaitingCommand = true
                say("A sus órdenes. ¿Qué necesitas?")
                updateNotification("JARVIS está esperando tu comando")
            } else if (awaitingCommand && phrase.isNotBlank()) {
                awaitingCommand = false
                handleCommand(phrase)
            }
            scheduleListen(1700)
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleCommand(command: String) {
        when {
            command.contains("apaga la linterna") || command.contains("apagar la linterna") -> toggleTorch(false)
            command.contains("enciende la linterna") || command.contains("prende la linterna") ||
                    command == "linterna" -> toggleTorch(true)
            command.contains("abre whatsapp") || command.contains("abrir whatsapp") ->
                openApp("com.whatsapp", "No encuentro WhatsApp instalado.")
            command.contains("abre youtube") || command.contains("abrir youtube") ->
                openApp("com.google.android.youtube", "No encuentro YouTube instalado.")
            command.contains("abre ajustes") || command.contains("abre configuración") -> {
                say("Abriendo ajustes.")
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            command.contains("qué hora") || command.contains("dime la hora") -> {
                val time = SimpleDateFormat("h:mm a", Locale("es", "ES")).format(Date())
                say("Son las $time")
            }
            else -> say("He escuchado $command. Esa acción todavía no está configurada.")
        }
    }

    private fun openApp(packageName: String, error: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            say("Abriendo la aplicación.")
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launch)
        } else say(error)
    }

    private fun toggleTorch(on: Boolean) {
        try {
            val camera = getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
            val id = camera.cameraIdList.first()
            camera.setTorchMode(id, on)
            say(if (on) "Linterna encendida." else "Linterna apagada.")
        } catch (_: Exception) {
            say("No puedo controlar la linterna en este dispositivo.")
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "JARVIS voz", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { speech?.cancel(); speech?.destroy() } catch (_: Exception) {}
        speech = null
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
