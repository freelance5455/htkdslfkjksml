package com.jarvis.assistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class JarvisService : Service(), TextToSpeech.OnInitListener {
    private var speech: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ready = false
    private var awaitingCommand = false
    private var listening = false
    private val channelId = "jarvis_voice"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("JARVIS está activo")
            .setContentText("Asistente de voz en segundo plano. Di “Jarvis”.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        startForeground(10, notification)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speech = SpeechRecognizer.createSpeechRecognizer(this)
            speech?.setRecognitionListener(listener)
            listen()
        } else speak("No encuentro un servicio de reconocimiento de voz en este teléfono.")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("es", "ES")
            tts?.setSpeechRate(0.88f)
            ready = true
        }
    }

    private fun speak(message: String) {
        if (ready) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun listen() {
        if (listening || speech == null) return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            listening = true
            speech?.startListening(intent)
        } catch (_: Exception) { listening = false }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: android.os.Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { listening = false }
        override fun onError(error: Int) {
            listening = false
            android.os.Handler(mainLooper).postDelayed({ listen() }, 900)
        }
        override fun onResults(results: android.os.Bundle?) {
            listening = false
            val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val phrase = words?.firstOrNull()?.lowercase(Locale.ROOT).orEmpty()
            if (phrase.contains("jarvis")) {
                awaitingCommand = true
                speak("A sus órdenes. ¿Qué necesitas?")
            } else if (awaitingCommand && phrase.isNotBlank()) {
                awaitingCommand = false
                handleCommand(phrase)
            }
            android.os.Handler(mainLooper).postDelayed({ listen() }, 1200)
        }
        override fun onPartialResults(partialResults: android.os.Bundle?) {}
        override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
    }

    private fun handleCommand(command: String) {
        when {
            command.contains("linterna") || command.contains("flash") -> toggleTorch(true)
            command.contains("apaga la linterna") -> toggleTorch(false)
            command.contains("abre whatsapp") || command.contains("abrir whatsapp") -> openApp("com.whatsapp", "No encuentro WhatsApp instalado.")
            command.contains("abre youtube") || command.contains("abrir youtube") -> openApp("com.google.android.youtube", "No encuentro YouTube instalado.")
            command.contains("abre ajustes") || command.contains("configuración") -> {
                speak("Abriendo ajustes.")
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            command.contains("qué hora") || command.contains("dime la hora") -> {
                val time = java.text.SimpleDateFormat("h:mm a", Locale("es", "ES")).format(java.util.Date())
                speak("Son las $time")
            }
            else -> speak("He escuchado: $command. Todavía no tengo esa acción configurada.")
        }
    }

    private fun openApp(packageName: String, error: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            speak("Abriendo la aplicación.")
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launch)
        } else speak(error)
    }

    private fun toggleTorch(on: Boolean) {
        try {
            val camera = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = camera.cameraIdList.first()
            camera.setTorchMode(id, on)
            speak(if (on) "Linterna encendida." else "Linterna apagada.")
        } catch (_: Exception) {
            speak("No puedo controlar la linterna en este dispositivo.")
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "JARVIS voz", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        speech?.destroy()
        speech = null
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
