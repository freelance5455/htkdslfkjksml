JARVIS - PROYECTO INICIAL ANDROID

IMPORTANTE:
- La interfaz principal está en app/src/main/assets/index.html y se carga dentro de la app mediante WebView.\n- Este ZIP contiene el CÓDIGO FUENTE de un proyecto Android, no un APK ya compilado.
- Se compila con Android Studio en una computadora con Android SDK instalado.
- No se puede convertir directamente a PKG de PS4: este proyecto es para Android (APK).
- El reconocimiento de voz depende del servicio de voz instalado en el teléfono y normalmente requiere internet.
- Android puede limitar la escucha continua, especialmente con ahorro de batería. El servicio usa una notificación persistente.
- Para iniciar: abre el proyecto en Android Studio, espera la sincronización de Gradle y pulsa Build > Build APK(s).
- APK resultante: app/build/outputs/apk/debug/app-debug.apk

COMANDOS DE PRUEBA:
1. Di “Jarvis”.
2. Cuando responda, di “abre WhatsApp”, “abre YouTube”, “enciende la linterna”, “apaga la linterna” o “qué hora es”.
3. Pulsa DETENER JARVIS para cerrar el servicio.

La voz se configura en español usando el motor TTS del teléfono. La profundidad/tono final depende de las voces instaladas en Android.

Este es un prototipo funcional básico. No incluye todavía conversación de IA en la nube ni control universal del teléfono. Esas funciones requieren integrar un proveedor de IA, configuración segura y permisos específicos.
