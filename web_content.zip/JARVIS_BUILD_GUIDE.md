# J.A.R.V.I.S. 2.0 — COMPLETE BUILD, RUN & ANDROID APK GUIDE

Welcome, Harman Sir. This guide provides complete instructions to extract, run, configure, and compile your JARVIS AI assistant into a signed Android APK.

---

## 1. Quick Start: Extracting & Running the Project

### 1.1. Prerequisites
- **Node.js**: v18.0.0 or higher (v20+ recommended).
- **npm** or **bun**.
- **Android Studio Hedgehog / Iguana / Jellyfish** (for Android APK compilation).

### 1.2. Extract Archive
```bash
unzip Jarvis_Complete_Project.zip -d jarvis-assistant
cd jarvis-assistant
```

### 1.3. Install Dependencies
```bash
npm install
```

### 1.4. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Open `.env` and configure your API keys:
```env
# Required for AI Brain, Vision, and Blueprint Scanner:
GEMINI_API_KEY=your_gemini_api_key_here

# Optional for ElevenLabs George voice (defaults to browser Baritone fallback if omitted):
ELEVENLABS_API_KEY=your_elevenlabs_api_key_here

# Port (default 3000)
PORT=3000
```

### 1.5. Run Development Server
```bash
npm run dev
```
Open your browser and navigate to:
```
http://localhost:3000
```

---

## 2. Converting to Android APK with Android Studio

The project includes both a Capacitor setup and a complete pre-scaffolded Android Studio native project in the `android/` directory.

### Method A: Direct Android Studio Open (Fastest)

1. **Build Web Production Assets:**
   ```bash
   npm run build
   ```
2. **Open Android Studio:**
   - Launch Android Studio.
   - Click **Open**, and select the `android` folder inside your extracted project.
3. **Gradle Sync:**
   - Android Studio will automatically sync the Gradle dependencies (`build.gradle`).
   - The project is pre-tuned for 4GB RAM systems (`org.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m`).
4. **Run or Build:**
   - Connect your **Redmi 12** via USB with **USB Debugging** enabled.
   - Click the green **Run (Play)** button in Android Studio to install directly on your phone.

---

### Method B: Building a Signed Release APK via Command Line

To build an authorized release APK without opening the full IDE:

1. **Generate Release Keystore (Valid for 25+ years):**
   ```bash
   cd android/app
   keytool -genkeypair -v -storetype PKCS12 -keystore jarvis-release-key.jks -alias jarvis -keyalg RSA -keysize 2048 -validity 10000
   ```
   *(Enter a password of your choice, e.g., `jarvis12345`, and complete the prompts).*

2. **Set Environment Passwords (Optional):**
   ```bash
   export JARVIS_KEYSTORE_PASSWORD="your_password"
   export JARVIS_KEY_ALIAS="jarvis"
   export JARVIS_KEY_PASSWORD="your_password"
   ```

3. **Build the APK:**
   ```bash
   cd ../ # Back to android folder
   ./gradlew assembleRelease
   ```
   *(On Windows Command Prompt, run `gradlew.bat assembleRelease`)*.

4. **Locate Your APK:**
   Your compiled, signed APK will be located at:
   ```
   android/app/build/outputs/apk/release/app-release.apk
   ```

5. **Install on Redmi 12:**
   - Transfer `app-release.apk` to your phone via USB or Google Drive.
   - Or install directly using ADB:
     ```bash
     adb install android/app/build/outputs/apk/release/app-release.apk
     ```

---

## 3. Xiaomi Redmi 12 (MIUI / HyperOS) Optimization Checklist

To ensure JARVIS runs with 100% reliability in the background on Xiaomi devices:

1. **Autostart Permission:**
   - Go to phone **Settings > Apps > Manage Apps > JARVIS**.
   - Enable **Autostart**.
2. **Battery Saver Configuration:**
   - In App Settings > Battery Saver, select **No restrictions** (prevents MIUI from killing the background alarm listener).
3. **Display Pop-Up Windows While Running in the Background:**
   - In App Settings > Other Permissions, enable:
     - *Show on Lock screen*
     - *Display pop-up windows while running in the background*
     - *Permanent notification*
4. **Exact Alarm Permission:**
   - Ensure *Alarms & reminders* permission is allowed so the morning wake-up protocol rings at the exact second.

---

## 4. Project File Structure Reference

```
jarvis-assistant/
├── .env.example                  # Environment configuration template
├── package.json                  # Dependencies & npm build scripts
├── tsconfig.json                 # TypeScript compiler options
├── vite.config.ts                # Vite frontend bundler configuration
├── capacitor.config.ts           # Capacitor Android wrapper configuration
├── server.ts                     # Full-stack Express backend & Gemini API proxy
├── index.html                    # Application HTML entry point
├── JARVIS_BUILD_GUIDE.md         # This build and deployment guide
├── JARVIS_FEATURE_AUDIT.md       # Complete 100% feature verification audit
├── public/
│   ├── Jarvis_Complete_Project.zip # Downloadable standalone archive
│   └── assets/
│       └── aistudio/             # Permanent audio files (unlock, welcome, alarm)
├── src/
│   ├── App.tsx                   # Central JARVIS orchestrator & state machine
│   ├── components/               # 22 specialized holographic & control modals
│   ├── services/                 # Action engine, voice engine, time engine, agents
│   └── types/                    # TypeScript interfaces & data contracts
└── android/                      # Native Android Studio project
    ├── build.gradle              # Top-level Gradle configuration
    ├── settings.gradle           # Module settings
    ├── gradle.properties         # JVM 4GB RAM memory tuning
    └── app/
        ├── build.gradle          # Android app build configuration
        └── src/main/
            ├── AndroidManifest.xml # Full native permissions
            └── java/com/jarvis/ai/ # MainActivity & AlarmReceiver bridge
```

---

## 5. Summary

Everything is bundled and pre-configured. You can run the web version locally at any time or build the Android APK for your Redmi 12 device whenever ready.
