package ro.jurnalbord.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import android.content.Intent;
import android.content.Context;
import android.app.KeyguardManager;
import android.os.Build;
import android.widget.Toast;
import android.provider.DocumentsContract;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executor;

public class MainActivity extends androidx.fragment.app.FragmentActivity {
    private WebView webView;
    private android.webkit.ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 7021;
    private static final int CREATE_FILE_REQUEST = 7022;
    private String pendingFileName = "jurnal-sofer-copie.json";
    private byte[] pendingFileBytes;
    private boolean authenticated = false;
    private boolean webLoaded = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        if (savedInstanceState != null) authenticated = savedInstanceState.getBoolean("authenticated", false);
        if (authenticated) showJournal(); else authenticate();
    }

    private void authenticate() {
        KeyguardManager keyguard = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        if (keyguard == null || !keyguard.isDeviceSecure()) {
            new android.app.AlertDialog.Builder(this)
                .setTitle("Protecția telefonului necesară")
                .setMessage("Pentru a proteja jurnalul, configurează mai întâi o amprentă sau un cod PIN/model/parolă în setările de securitate ale telefonului.")
                .setCancelable(false)
                .setPositiveButton("Încearcă din nou", (d, w) -> authenticate())
                .setNegativeButton("Închide", (d, w) -> finish())
                .show();
            return;
        }
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                authenticated = true;
                showJournal();
            }
            @Override public void onAuthenticationError(int errorCode, CharSequence errString) {
                if (errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON && errorCode != BiometricPrompt.ERROR_USER_CANCELED) {
                    Toast.makeText(MainActivity.this, "Autentificare anulată. Jurnalul rămâne blocat.", Toast.LENGTH_SHORT).show();
                }
                if (errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON || errorCode == BiometricPrompt.ERROR_USER_CANCELED) finish();
            }
            @Override public void onAuthenticationFailed() {
                Toast.makeText(MainActivity.this, "Nu am recunoscut amprenta. Încearcă din nou.", Toast.LENGTH_SHORT).show();
            }
        });
        BiometricPrompt.PromptInfo.Builder info = new BiometricPrompt.PromptInfo.Builder()
            .setTitle("Jurnal de bord privat")
            .setSubtitle("Confirmă identitatea pentru a deschide jurnalul")
            .setConfirmationRequired(false);
        if (Build.VERSION.SDK_INT >= 30) {
            info.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
        } else {
            info.setDeviceCredentialAllowed(true);
        }
        prompt.authenticate(info.build());
    }

    private void showJournal() {
        if (webLoaded) return;
        webLoaded = true;
        webView = new WebView(this);
        webView.setBackgroundColor(0xFFF8FAF9);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                // Keep navigation within the private app; no external web navigation.
                return !("https".equalsIgnoreCase(u.getScheme()) && "jurnal.local".equalsIgnoreCase(u.getHost()));
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, android.webkit.ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; return false; }
                return true;
            }
        });
        setContentView(webView);
        try {
            InputStream input = getAssets().open("index.html");
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192]; int n;
            while ((n = input.read(buffer)) > 0) output.write(buffer, 0, n);
            input.close();
            String html = output.toString("UTF-8");
            webView.loadDataWithBaseURL("https://jurnal.local/", html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            webView.loadData("<meta charset='utf-8'><h2>Nu am putut deschide jurnalul.</h2>", "text/html", "UTF-8", null);
        }
    }

    private class AndroidBridge {
        @JavascriptInterface public void saveFile(String name, String content) {
            if (content == null) return;
            pendingFileName = (name == null || name.trim().isEmpty()) ? "jurnal-sofer-copie.json" : name.replaceAll("[^a-zA-Z0-9._-]", "_");
            pendingFileBytes = content.getBytes(StandardCharsets.UTF_8);
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(pendingFileName.endsWith(".html") ? "text/html" : "application/json");
                intent.putExtra(Intent.EXTRA_TITLE, pendingFileName);
                startActivityForResult(intent, CREATE_FILE_REQUEST);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        } else if (requestCode == CREATE_FILE_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingFileBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) out.write(pendingFileBytes);
                    Toast.makeText(this, "Copia de siguranță salvată.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Nu am putut salva fișierul.", Toast.LENGTH_LONG).show();
                }
            }
            pendingFileBytes = null;
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        outState.putBoolean("authenticated", authenticated);
        super.onSaveInstanceState(outState);
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
