# Price Calculator Android app

This is an Android Studio project that wraps the supplied `PriceCalculator.html` in a local Android WebView. The calculator HTML is bundled in the app, so the calculator works without an internet connection and does not request internet permission.

## Build an installable APK
1. Install Android Studio on a computer.
2. Open Android Studio and choose **Open**, then select this `PriceCalculatorAndroid` folder (the folder containing `settings.gradle`).
3. Allow Gradle sync and install any Android SDK components it asks for (compile SDK 35).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When the build finishes, click **locate**. The APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to your Android phone and open it to install. If prompted, allow installing apps from that source.

No internet permission is declared in the app. Internet is only needed on the computer for the first Android Studio/Gradle setup and build downloads, not for using the calculator.
