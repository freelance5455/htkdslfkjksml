DATA X USER V90 — DEEP AUTH / AUTO-LOGIN SPEED FIX

Base: V89 Direct Balance Fix.

Deep changes:
- One unified fast boot for manual login, persistent auto-login and post-registration.
- Cached authenticated shell can paint before Firebase LOCAL persistence finishes restoring.
- Registration no longer performs a redundant users/{uid} read after an acknowledged set().
- Profile realtime listener is the single immediate profile/balance reconciliation path at boot.
- Account-switch and logout cleanup are now background jobs instead of awaited auth blockers.
- Top sellers, withdrawal/support listeners, activity and old-session recovery are deferred until after first paint.
- Existing V89 direct balance settlement is preserved.
- Existing activation popup Telegram contact is preserved.
