BPSC Test Master v5 prototype.
- Questions are ORIGINAL BPSC-style items (statement-based, chronology, quantitative), not official PYQs.
- Current Affairs items come from Oct-Nov 2026 reports (Drishti IAS, GKToday); re-verify before relying on them.
- Mock follows the 2026 pattern: 150 Q / 2 hrs, options A-E (E = not attempted), +1 / -1/3, blank = -1/3. Confirm against the official BPSC notice.
- The bank is small (~29 questions); a full 150-question mock needs a much larger verified bank. Nothing is duplicated to fill it.
- v6: theme switcher (Light / Dark / Neo-brutal), saved in browser, defaults to system dark mode.
