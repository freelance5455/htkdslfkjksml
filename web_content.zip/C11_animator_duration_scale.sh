#!/system/bin/sh
# C11_animator_duration_scale — animator duration scale
# Cut animator duration scale to 0.5.
MODULE_ID="C11_animator_duration_scale"
. "$(dirname "$0")/../lib/core.sh"
vcg_init
apply() {
    vcg_apply_or_skip C11_ENABLED || return 0
    vcg_put global animator_duration_scale 0.5
}
revert() {
    vcg_restore_setting global animator_duration_scale
}
case "${1:-apply}" in apply) apply ;; revert) revert ;; *) exit 1 ;; esac
