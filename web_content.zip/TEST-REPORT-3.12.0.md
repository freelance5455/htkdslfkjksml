# RISEUP 3.12.0 — Test Report

## Implemented
- Editable recurring core tasks with +10 XP on completion and -20 XP per missed task.
- Missed core task resets the consecutive-day streak; weekly celebration/reward triggers at each seven-day streak milestone.
- XP penalty is non-negative and recalculates current level progress.
- Level-based E-S ranks and rank-specific cosmetics.
- Six rank-gated regions, gates and bosses; boss duration and externally assessed result flow.
- Collection, weekly cosmetics, character/preset/frame/title selection.
- Goal deadline mode: fixed date or relative duration.
- Existing spiritual and recovery sections preserved unchanged from 3.11.0.

## Automated checks
- `node tests/run-static.js`: passed; all inline JavaScript parses and expected UI/features are present.
- `node tests/run-pwa.js`: passed; service worker shell caching and activation checks pass.
- `node tests/run-gameplay.js`: passed; rank thresholds, weekly streak milestone, missed-task XP penalty, non-negative XP, six gates/bosses and multi-day boss duration.
- Static DOM reference scan: no missing element IDs.
- Comparison against 3.11.0 source: spiritual path section and private recovery module are byte-for-byte unchanged.

## Not performed
- No full interactive browser session was run.
- No APK was built or tested on a physical Android device in this session.
- The boss assessment is intentionally manual: ChatGPT test generation/evaluation happens in the conversation, and the player records the result in the app.
