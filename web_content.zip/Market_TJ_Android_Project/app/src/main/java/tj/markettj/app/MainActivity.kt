package tj.markettj.app

import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.graphics.Bitmap
import java.io.FileOutputStream
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import java.io.File

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var cameraPhotoUri: Uri? = null
    private val cameraRequestCode = 702

    private fun openDialer(number: String) {
        val clean = number.trim().filter { it.isDigit() || it == '+' || it == '*' || it == '#' }
        if (clean.isEmpty()) {
            Toast.makeText(this, "Рақами телефон ёфт нашуд", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", clean, null)))
        } catch (_: Exception) {
            Toast.makeText(this, "Барномаи телефон дастрас нест", Toast.LENGTH_LONG).show()
        }
    }

    private fun launchCamera(): Boolean {
        return try {
            val photoFile = File(cacheDir, "market_photo_${System.currentTimeMillis()}.jpg")
            cameraPhotoUri = FileProvider.getUriForFile(
                this,
                "$packageName.fileprovider",
                photoFile
            )
            val cameraIntent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(android.provider.MediaStore.EXTRA_OUTPUT, cameraPhotoUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                clipData = ClipData.newUri(contentResolver, "Market TJ photo", cameraPhotoUri)
            }
            val cameraApps = packageManager.queryIntentActivities(cameraIntent, 0)
            if (cameraApps.isEmpty()) {
                cameraPhotoUri = null
                Toast.makeText(this, "Барномаи камера ёфт нашуд. Камераи телефонро фаъол кунед.", Toast.LENGTH_LONG).show()
                return false
            }
            cameraApps.forEach { info ->
                grantUriPermission(
                    info.activityInfo.packageName,
                    cameraPhotoUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            startActivityForResult(cameraIntent, cameraRequestCode)
            true
        } catch (_: Exception) {
            cameraPhotoUri = null
            Toast.makeText(this, "Камера кушода нашуд. Камераи телефонро санҷед.", Toast.LENGTH_LONG).show()
            false
        }
    }

    inner class MarketBridge {
        @JavascriptInterface
        fun callPhone(number: String) {
            runOnUiThread { openDialer(number) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            loadsImagesAutomatically = true
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        webView.addJavascriptInterface(MarketBridge(), "MarketAndroid")

        webView.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.scheme.equals("tel", ignoreCase = true)) {
                    openDialer(Uri.decode(url.schemeSpecificPart))
                    return true
                }
                val marker = "/web/tel%3A"
                if (url.host == "appassets.androidplatform.net" && url.encodedPath.startsWith(marker, true)) {
                    openDialer(Uri.decode(url.encodedPath.substring(marker.length)).substringBefore('?').substringBefore('#'))
                    return true
                }
                if (url.scheme.equals("mailto", true)) {
                    return try { startActivity(Intent(Intent.ACTION_SENDTO, url)); true }
                    catch (_: Exception) { true }
                }
                if (url.scheme == "https" && url.host != "appassets.androidplatform.net") {
                    return try { startActivity(Intent(Intent.ACTION_VIEW, url)); true }
                    catch (_: Exception) { true }
                }
                return false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                if (callback == null) return false
                filePathCallback = callback
                // Open the phone camera directly. The full-size photo is saved to a
                // FileProvider URI and returned to the HTML input for Supabase upload.
                return if (launchCamera()) true else {
                    filePathCallback?.onReceiveValue(null)
                    filePathCallback = null
                    false
                }
            }
        }
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    @Deprecated("Deprecated by Android; retained for WebView chooser compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == cameraRequestCode) {
            val uri = cameraPhotoUri
            // Some camera apps ignore EXTRA_OUTPUT and return a small thumbnail in data.extras.
            if (resultCode == RESULT_OK && uri != null) {
                val alreadyWritten = try {
                    contentResolver.openInputStream(uri)?.use { it.read() != -1 } == true
                } catch (_: Exception) { false }
                if (!alreadyWritten) {
                    val bitmap = data?.extras?.get("data") as? Bitmap
                    if (bitmap != null) {
                        try {
                            contentResolver.openOutputStream(uri, "w")?.use { out ->
                                bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
                            }
                        } catch (_: Exception) { }
                    }
                }
            }
            val validPhoto = resultCode == RESULT_OK && uri != null && try {
                contentResolver.openInputStream(uri)?.use { it.read() != -1 } == true
            } catch (_: Exception) { false }
            filePathCallback?.onReceiveValue(if (validPhoto) arrayOf(uri!!) else null)
            filePathCallback = null
            if (!validPhoto && uri != null) {
                try { contentResolver.delete(uri, null, null) } catch (_: Exception) { }
            }
            cameraPhotoUri = null
        }
    }

    @Deprecated("Deprecated by Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = null
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
