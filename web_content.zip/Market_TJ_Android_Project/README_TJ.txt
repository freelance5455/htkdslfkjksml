Market TJ — Android APK source project

This project wraps the supplied Market TJ HTML in Android WebView. It includes:
- JavaScript and DOM storage enabled
- Android gallery/photo picker through WebChromeClient file chooser
- Native phone dialer bridge for the seller call button
- Supabase client and existing Market TJ table/bucket settings retained in index.html

IMPORTANT: This is source code, not a compiled or device-tested APK. The APK must be built, installed and tested on a real phone. Supabase must allow the intended anonymous INSERT/SELECT operations and the market-images Storage bucket must allow upload and public read. Never put a service_role key in the HTML/app.

Build on GitHub: upload the contents of this project to a repository, open Actions, choose “Build Market TJ APK”, and press “Run workflow”. Download the Market-TJ-debug-APK artifact after the workflow succeeds.


Навсозӣ: тугмаи иловаи акс дар APK камераи телефонро мустақим мекушояд. Акс бо FileProvider ба HTML дода шуда, баъд тавассути коди мавҷуда ба Supabase Storage market-images бор карда мешавад. Барои сохтани APK лоиҳаро дар GitHub Actions истифода баред.


НАВ: Камера
Ин версия рӯйхати барномаҳои камераро месанҷад, иҷозати URI медиҳад ва барои камераҳое, ки танҳо thumbnail бармегардонанд, роҳи эҳтиётӣ дорад. Ин ZIP манбаи Android аст; барои APK сохтан аз GitHub Actions истифода баред. Дар телефони воқеӣ ҳанӯз санҷида нашудааст.
