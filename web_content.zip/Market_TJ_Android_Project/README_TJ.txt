Market TJ — Android WebView project

The app opens the Market TJ HTML from app/src/main/assets/index.html.
Internet permission, JavaScript, DOM storage, phone dialer links, and Android image picker support are configured.

Image picker: uses ACTION_GET_CONTENT with image/* so Samsung Gallery / Android photo providers can appear.

Build:
1. Open this folder in Android Studio.
2. Wait for Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on the phone.

Important: This is source code, not a prebuilt/tested APK. Supabase Storage policies and table policies must allow the intended public operations. Do not put service_role keys in the app.
