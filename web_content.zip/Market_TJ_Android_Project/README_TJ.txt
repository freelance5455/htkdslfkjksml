MARKET TJ — ЛОИҲАИ ANDROID WEBVIEW

Ин ZIP APK-и тайёр нест. Ин лоиҳаи Android Studio мебошад, ки HTML-и Market TJ-ро дар WebView мекушояд.

Дар дохилаш:
- иҷозати интернет;
- JavaScript ва DOM Storage фаъол;
- интихоби акс аз телефон тавассути File Chooser;
- WebViewAssetLoader барои кушодани саҳифаи дохилӣ бо HTTPS origin.

СОХТАНИ APK ДАР ANDROID STUDIO:
1. ZIP-ро кушоед (Extract).
2. Android Studio-ро дар компютер кушоед.
3. Open-ро интихоб карда папкаи Market_TJ_Android_Project-ро кушоед.
4. Интизор шавед Gradle Sync тамом шавад.
5. Аз меню Build → Build Bundle(s) / APK(s) → Build APK(s)-ро пахш кунед.
6. APK дар app/build/outputs/apk/debug/app-debug.apk пайдо мешавад.

ЭЗОҲИ МУҲИМ:
- Барои сохтани APK-и воқеӣ Android SDK/Android Studio лозим аст. Ин муҳит APK-ро компайл накардааст.
- HTML-и дохилшуда ҳамон файли Market TJ аз Library мебошад.
- Барнома барои кор интернет талаб мекунад; китобхонаи Supabase аз CDN бор мешавад.
- Агар маълумот дар APK ҳанӯз бор нашавад, мумкин аст Supabase CORS барои origin-и WebView маҳдуд бошад. Он гоҳ бояд URL-и HTTPS-и сомонаи ҷойгиршуда истифода шавад ё CORS-и Supabase дуруст танзим шавад.
- Дар HTML танҳо publishable key истифода мешавад. Ҳеҷ гоҳ service_role/secret key-ро ба HTML ё APK нагузоред.
