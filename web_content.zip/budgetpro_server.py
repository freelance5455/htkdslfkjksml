#!/usr/bin/env python3
"""ميزانيتي Pro: local-only SQLite application server."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import sqlite3, json, hashlib, secrets, os, time, threading, webbrowser, shutil
from datetime import datetime

ROOT = Path(__file__).resolve().parent
HTML = ROOT / 'budgetpro.html'
DATA_DIR = ROOT / 'ميزانيتي_Pro_بيانات'
DB_PATH = DATA_DIR / 'budget.sqlite3'
BACKUP_DIR = DATA_DIR / 'backups'
HOST, PORT = '127.0.0.1', 8765
SESSIONS = {}
LOCK = threading.RLock()

def connect():
    DATA_DIR.mkdir(exist_ok=True); BACKUP_DIR.mkdir(exist_ok=True)
    c=sqlite3.connect(DB_PATH, timeout=10)
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('''CREATE TABLE IF NOT EXISTS app_data (id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT NOT NULL, updated_at TEXT NOT NULL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS auth (id INTEGER PRIMARY KEY CHECK(id=1), salt BLOB NOT NULL, password_hash BLOB NOT NULL, iterations INTEGER NOT NULL, updated_at TEXT NOT NULL)''')
    c.commit()
    row=c.execute('SELECT id FROM auth WHERE id=1').fetchone()
    if not row:
        salt=secrets.token_bytes(16); iterations=600_000
        digest=hashlib.pbkdf2_hmac('sha256', b'1990', salt, iterations)
        c.execute('INSERT INTO auth VALUES(1,?,?,?,?)',(salt,digest,iterations,datetime.now().isoformat(timespec='seconds')))
        c.commit()
    return c

def hash_password(pw,salt,iterations): return hashlib.pbkdf2_hmac('sha256',pw.encode('utf-8'),salt,iterations)
def backup_current(payload):
    if not payload: return
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
    path=BACKUP_DIR/f'budget_backup_{stamp}.json'
    path.write_text(payload,encoding='utf-8')
    files=sorted(BACKUP_DIR.glob('budget_backup_*.json'))
    for f in files[:-30]:
        try:f.unlink()
        except OSError:pass

def valid_session(handler):
    cookie=handler.headers.get('Cookie','')
    token=''
    for part in cookie.split(';'):
        if part.strip().startswith('budget_session='): token=part.strip().split('=',1)[1]
    return bool(token and SESSIONS.get(token,0)>time.time())

class Handler(BaseHTTPRequestHandler):
    server_version='BudgetProLocal/1.0'
    def log_message(self, fmt, *args): pass
    def send_bytes(self, code, data, ctype='application/json; charset=utf-8', extra=None):
        self.send_response(code); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(data))); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Cache-Control','no-store'); self.send_header('Content-Security-Policy',"default-src 'self' 'unsafe-inline' 'unsafe-eval' data:; connect-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'")
        for k,v in (extra or {}).items(): self.send_header(k,v)
        self.end_headers(); self.wfile.write(data)
    def json(self,code,obj,extra=None): self.send_bytes(code,json.dumps(obj,ensure_ascii=False).encode('utf-8'),extra=extra)
    def read_json(self,limit=15_000_000):
        n=int(self.headers.get('Content-Length','0'))
        if n>limit: raise ValueError('حجم الملف أكبر من الحد المسموح')
        raw=self.rfile.read(n)
        return json.loads(raw.decode('utf-8'))
    def do_GET(self):
        if self.path in ('/','/index.html'):
            if not HTML.exists(): return self.send_bytes(500,b'Application HTML missing','text/plain')
            self.send_bytes(200,HTML.read_bytes(),'text/html; charset=utf-8'); return
        if self.path=='/api/data':
            if not valid_session(self): return self.json(401,{'error':'يرجى تسجيل الدخول أولاً'})
            with connect() as c: row=c.execute('SELECT payload FROM app_data WHERE id=1').fetchone()
            self.json(200,json.loads(row[0]) if row else {}); return
        if self.path=='/api/backup':
            if not valid_session(self): return self.json(401,{'error':'يرجى تسجيل الدخول أولاً'})
            with connect() as c: row=c.execute('SELECT payload FROM app_data WHERE id=1').fetchone()
            payload=row[0] if row else '{}'
            self.send_bytes(200,payload.encode('utf-8'),'application/json; charset=utf-8',{'Content-Disposition':'attachment; filename="budgetpro-backup.json"'}); return
        if self.path=='/api/status':
            self.json(200,{'app':'ميزانيتي Pro','database':'SQLite','local_only':True,'authenticated':valid_session(self)}); return
        self.send_bytes(404,b'Not found','text/plain')
    def do_POST(self):
        if self.path=='/api/login':
            try: d=self.read_json()
            except Exception: return self.json(400,{'error':'بيانات الدخول غير صالحة'})
            if d.get('username')!='1990' or not isinstance(d.get('password'),str): return self.json(401,{'error':'اسم المستخدم أو كلمة المرور غير صحيحة'})
            with connect() as c: row=c.execute('SELECT salt,password_hash,iterations FROM auth WHERE id=1').fetchone()
            if not secrets.compare_digest(hash_password(d['password'],row[0],row[2]),row[1]): return self.json(401,{'error':'اسم المستخدم أو كلمة المرور غير صحيحة'})
            token=secrets.token_urlsafe(32); SESSIONS[token]=time.time()+8*60*60
            return self.json(200,{'ok':True},{'Set-Cookie':f'budget_session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800'})
        if self.path=='/api/logout':
            cookie=self.headers.get('Cookie','')
            for p in cookie.split(';'):
                if p.strip().startswith('budget_session='): SESSIONS.pop(p.strip().split('=',1)[1],None)
            return self.json(200,{'ok':True},{'Set-Cookie':'budget_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'})
        if self.path in ('/api/data','/api/password','/api/restore') and not valid_session(self): return self.json(401,{'error':'انتهت الجلسة؛ سجّل الدخول مجددًا'})
        if self.path=='/api/data':
            try: d=self.read_json()
            except Exception as e: return self.json(400,{'error':str(e)})
            if not isinstance(d,dict): return self.json(400,{'error':'صيغة البيانات غير صحيحة'})
            payload=json.dumps(d,ensure_ascii=False,separators=(',',':'))
            with LOCK, connect() as c:
                old=c.execute('SELECT payload FROM app_data WHERE id=1').fetchone()
                if old and old[0]!=payload: backup_current(old[0])
                c.execute('INSERT INTO app_data(id,payload,updated_at) VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,updated_at=excluded.updated_at',(payload,datetime.now().isoformat(timespec='seconds')))
            return self.json(200,{'ok':True})
        if self.path=='/api/password':
            try:d=self.read_json()
            except Exception:return self.json(400,{'error':'بيانات غير صالحة'})
            current=d.get('current'); nxt=d.get('next')
            if not isinstance(current,str) or not isinstance(nxt,str) or len(nxt)<10: return self.json(400,{'error':'كلمة المرور الجديدة يجب أن تكون 10 أحرف على الأقل'})
            with connect() as c:
                row=c.execute('SELECT salt,password_hash,iterations FROM auth WHERE id=1').fetchone()
                if not secrets.compare_digest(hash_password(current,row[0],row[2]),row[1]): return self.json(401,{'error':'كلمة المرور الحالية غير صحيحة'})
                salt=secrets.token_bytes(16); iterations=600_000; digest=hash_password(nxt,salt,iterations)
                c.execute('UPDATE auth SET salt=?,password_hash=?,iterations=?,updated_at=? WHERE id=1',(salt,digest,iterations,datetime.now().isoformat(timespec='seconds')))
            return self.json(200,{'ok':True})
        if self.path=='/api/restore':
            try:d=self.read_json()
            except Exception as e:return self.json(400,{'error':str(e)})
            if not isinstance(d,dict):return self.json(400,{'error':'ملف النسخة الاحتياطية غير صالح'})
            payload=json.dumps(d,ensure_ascii=False,separators=(',',':'))
            with LOCK, connect() as c:
                old=c.execute('SELECT payload FROM app_data WHERE id=1').fetchone()
                if old: backup_current(old[0])
                c.execute('INSERT INTO app_data(id,payload,updated_at) VALUES(1,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,updated_at=excluded.updated_at',(payload,datetime.now().isoformat(timespec='seconds')))
            return self.json(200,{'ok':True})
        self.send_bytes(404,b'Not found','text/plain')
    def do_OPTIONS(self): self.send_bytes(405,b'Method not allowed','text/plain')

def main():
    DATA_DIR.mkdir(exist_ok=True); BACKUP_DIR.mkdir(exist_ok=True)
    with connect() as c: pass
    try:
        srv=ThreadingHTTPServer((HOST,PORT),Handler)
    except OSError as e:
        print('تعذر تشغيل السيرفر على المنفذ 8765.')
        print('قد يكون النظام يعمل بالفعل في نافذة أخرى، أو أن المنفذ مستخدم.')
        print('الرابط المحلي: http://127.0.0.1:8765/')
        print('تفاصيل الخطأ:', e)
        input('اضغط Enter للإغلاق...')
        return
    url=f'http://{HOST}:{PORT}/'
    print('\nميزانيتي Pro يعمل محليًا على هذا الكمبيوتر فقط.')
    print('الرابط:',url)
    print('قاعدة البيانات:',DB_PATH)
    print('النسخ الاحتياطية:',BACKUP_DIR)
    print('اترك هذه النافذة مفتوحة أثناء الاستخدام. لإيقاف النظام اضغط Ctrl+C.\n')
    threading.Timer(1.0,lambda:webbrowser.open(url)).start()
    try:srv.serve_forever()
    except KeyboardInterrupt: print('\nتم إيقاف النظام.')
    finally:srv.server_close()
if __name__=='__main__': main()
