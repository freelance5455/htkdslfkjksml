WASALNI ADMIN + SUPERVISOR V13.4

New admin feature:
- Settings > Driver Notifications
- Edit new-trip notification title
- Edit new-trip notification body
- Enable/disable new-trip push notifications
- Live preview
- Changes apply from database without rebuilding driver APK

Required database setup:
1) Run WASALNI_ADMIN_NOTIFICATION_SETTINGS_RPC.sql once in Supabase SQL Editor.
2) Use Wasalni_ADMIN_SUPERVISOR_V13_4_NOTIFICATION_SETTINGS.html as the new Admin + Supervisor build.

Security:
- The database table remains inaccessible directly to anon/authenticated users.
- Only the main admin UUID already used by the current app can read/update settings through the new RPCs.
- Supervisors cannot access these notification settings.
