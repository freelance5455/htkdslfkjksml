import fs from 'node:fs';
import path from 'node:path';

const project = process.cwd();
const javaSource = path.join(project, 'scripts', 'MainActivity.java');
const javaTarget = path.join(
  project, 'android', 'app', 'src', 'main', 'java',
  'com', 'dafiistudio', 'atom', 'MainActivity.java'
);

if (!fs.existsSync(path.join(project, 'android', 'app'))) {
  console.error('Android-проект ещё не создан. Сначала выполните: npx cap add android');
  process.exit(1);
}
fs.mkdirSync(path.dirname(javaTarget), { recursive: true });
fs.copyFileSync(javaSource, javaTarget);
console.log('Полноэкранный режим АТОМ настроен.');
