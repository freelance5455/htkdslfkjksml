import fs from 'node:fs';
import path from 'node:path';

const project = process.cwd();
const javaSource = path.join(project, 'scripts', 'MainActivity.java');
const javaTarget = path.join(
  project, 'android', 'app', 'src', 'main', 'java',
  'com', 'dafiistudio', 'atom', 'MainActivity.java'
);
const manifestPath = path.join(project, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');

if (!fs.existsSync(path.join(project, 'android', 'app'))) {
  console.error('Android-проект ещё не создан. Сначала выполните: npx cap add android');
  process.exit(1);
}

fs.mkdirSync(path.dirname(javaTarget), { recursive: true });
fs.copyFileSync(javaSource, javaTarget);

if (!fs.existsSync(manifestPath)) {
  console.error('Не найден AndroidManifest.xml: ' + manifestPath);
  process.exit(1);
}

let manifest = fs.readFileSync(manifestPath, 'utf8');
const activityTag = /<activity\b(?=[^>]*android:name=["'][^"']*MainActivity["'])[^>]*>/s;
const match = manifest.match(activityTag);
if (!match) {
  console.error('Не удалось найти MainActivity в AndroidManifest.xml');
  process.exit(1);
}
let activity = match[0];
if (/android:screenOrientation=["'][^"']*["']/.test(activity)) {
  activity = activity.replace(/android:screenOrientation=["'][^"']*["']/, 'android:screenOrientation="landscape"');
} else {
  activity = activity.replace(/\s*\/>$/, ' android:screenOrientation="landscape" />');
  if (activity === match[0]) activity = activity.replace(/>$/, ' android:screenOrientation="landscape">');
}
manifest = manifest.replace(match[0], activity);
fs.writeFileSync(manifestPath, manifest);
console.log('Настроены полноэкранный режим и горизонтальная ориентация АТОМ.');
