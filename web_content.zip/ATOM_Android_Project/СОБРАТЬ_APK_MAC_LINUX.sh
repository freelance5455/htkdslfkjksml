#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

echo "=== ATOM: подготовка Android APK ==="
node --version
npm install

if [ ! -d "android/app" ]; then
  npx cap add android
fi

node scripts/prepare-android.mjs
npx cap sync android
cd android
./gradlew assembleDebug

echo
echo "ГОТОВО! APK:"
echo "android/app/build/outputs/apk/debug/app-debug.apk"
