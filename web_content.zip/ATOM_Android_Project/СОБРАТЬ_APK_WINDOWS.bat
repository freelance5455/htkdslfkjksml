@echo off
setlocal
cd /d "%~dp0"

echo === ATOM: подготовка Android APK ===
where node >nul 2>nul
if errorlevel 1 (
  echo Не найден Node.js. Установите Node.js 22 или новее.
  pause
  exit /b 1
)

echo [1/5] Установка зависимостей...
call npm install
if errorlevel 1 goto fail

if not exist "android\app" (
  echo [2/5] Создание Android-проекта...
  call npx cap add android
  if errorlevel 1 goto fail
) else (
  echo [2/5] Android-проект уже существует.
)

echo [3/5] Настройка полноэкранного режима...
call node scripts\prepare-android.mjs
if errorlevel 1 goto fail

echo [4/5] Копирование игры в Android-проект...
call npx cap sync android
if errorlevel 1 goto fail

echo [5/5] Сборка APK...
cd android
call gradlew.bat assembleDebug
if errorlevel 1 goto fail_android

echo.
echo ГОТОВО! APK находится здесь:
echo android\app\build\outputs\apk\debug\app-debug.apk
cd ..
pause
exit /b 0

:fail_android
cd ..
:fail
echo.
echo Сборка остановилась. Проверьте Android Studio / SDK и сообщение об ошибке выше.
pause
exit /b 1
