HanzXBugV1 — Android WebView project

- Nama aplikasi: HanzXBugV1
- Ikon launcher: memakai gambar yang kamu kirim (89241.png), dipotong/diukur ke ukuran ikon Android.
- HTML asli disalin byte-for-byte ke app/src/main/assets/index.html; isi HTML tidak diedit.
- WebView mengizinkan JavaScript dan akses internet agar aset eksternal yang sudah dirujuk HTML dapat dimuat.

CARA MEMBUAT APK
1. Ekstrak ZIP ini.
2. Buka Android Studio.
3. Pilih Open, lalu pilih folder HanzXBugV1_Android_Project.
4. Tunggu Gradle Sync selesai (internet mungkin diperlukan untuk mengunduh komponen).
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya berada di app/build/outputs/apk/debug/app-debug.apk.

Catatan: paket ini adalah proyek Android Studio, bukan file APK yang sudah dikompilasi. Lingkungan pembuatan ini tidak memiliki Android SDK/Gradle untuk mengompilasi APK langsung.
