MIND KING – TNPSC Android Project

இது Android Studio-வில் APK உருவாக்கத் தேவையான source project.
இப்போதைக்கு APK கோப்பு அல்ல.

APK உருவாக்குவது:
1. Android Studio-வை கணினியில் நிறுவவும்.
2. இந்த ZIP-ஐ extract செய்யவும்.
3. Android Studio > Open > MindKingTNPSC folder தேர்வு செய்யவும்.
4. Gradle sync முடிந்ததும் Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK app/build/outputs/apk/debug/ இல் கிடைக்கும்.

குறிப்பு:
- App-ல் தற்போது மாதிரி வினாக்கள் மட்டுமே உள்ளன.
- 2016–2025 அசல் TNPSC வினாத்தாள்கள் சரிபார்த்து தனியாகச் சேர்க்கப்பட வேண்டும்.
