package com.parsamehr.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * پل جاوااسکریپت ↔ اندروید (window.PMNative).
 * همهٔ متدها رشته برمی‌گردانند: "ok" یا "ok:نام" در موفقیت، و "err:..." در خطا.
 */
public class PMNative {

    private final MainActivity act;

    PMNative(MainActivity act) {
        this.act = act;
    }

    /* ---------- کمکی ---------- */

    private static byte[] dec(String b64) {
        String s = b64 == null ? "" : b64;
        int c = s.indexOf(',');
        if (s.startsWith("data:") && c >= 0) s = s.substring(c + 1);
        return Base64.decode(s, Base64.DEFAULT);
    }

    private static String safeName(String n, String def) {
        String s = n == null ? "" : n.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return s.isEmpty() ? def : s;
    }

    private static String mimeOr(String m, String def) {
        return (m == null || m.isEmpty()) ? def : m;
    }

    private File cacheFile(String b64, String name) throws Exception {
        File dir = new File(act.getCacheDir(), "pm_shared");
        if (!dir.exists()) dir.mkdirs();
        File f = new File(dir, safeName(name, "file"));
        try (FileOutputStream o = new FileOutputStream(f)) {
            o.write(dec(b64));
        }
        return f;
    }

    private Uri uriFor(File f) {
        return FileProvider.getUriForFile(act, act.getPackageName() + ".fileprovider", f);
    }

    private String saveToMediaStore(Uri collection, String relDir, String b64, String name, String mime) throws Exception {
        ContentResolver cr = act.getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, relDir);
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri u = cr.insert(collection, v);
        if (u == null) throw new Exception("insert failed");
        try (OutputStream o = cr.openOutputStream(u)) {
            if (o == null) throw new Exception("open failed");
            o.write(dec(b64));
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
        cr.update(u, done, null, null);
        return "ok:" + name;
    }

    /* ---------- ذخیره ---------- */

    @JavascriptInterface
    public String saveImage(String b64, String name, String mime) {
        try {
            String n = safeName(name, "image_" + System.currentTimeMillis() + ".png");
            return saveToMediaStore(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    Environment.DIRECTORY_PICTURES + "/ParsaMehr", b64, n, mimeOr(mime, "image/png"));
        } catch (Exception e) {
            return "err:" + e.getMessage();
        }
    }

    @JavascriptInterface
    public String saveFile(String b64, String name, String mime) {
        try {
            String n = safeName(name, "file_" + System.currentTimeMillis());
            return saveToMediaStore(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    Environment.DIRECTORY_DOWNLOADS + "/ParsaMehr", b64, n, mimeOr(mime, "application/octet-stream"));
        } catch (Exception e) {
            return "err:" + e.getMessage();
        }
    }

    /* ---------- باز کردن / اشتراک ---------- */

    @JavascriptInterface
    public String openFile(String b64, String name, String mime) {
        try {
            File f = cacheFile(b64, name);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uriFor(f), mimeOr(mime, "application/octet-stream"));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(Intent.createChooser(i, "باز کردن با").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            return "ok";
        } catch (Exception e) {
            return "err:" + e.getMessage();
        }
    }

    @JavascriptInterface
    public String shareFile(String b64, String name, String mime, String title) {
        try {
            File f = cacheFile(b64, name);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(mimeOr(mime, "application/octet-stream"));
            i.putExtra(Intent.EXTRA_STREAM, uriFor(f));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent ch = Intent.createChooser(i, title == null || title.isEmpty() ? "اشتراک‌گذاری" : title);
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(ch);
            return "ok";
        } catch (Exception e) {
            return "err:" + e.getMessage();
        }
    }

    @JavascriptInterface
    public String shareImage(String b64, String name, String mime) {
        return shareFile(b64, safeName(name, "image.png"), mimeOr(mime, "image/png"), "اشتراک تصویر");
    }

    @JavascriptInterface
    public String shareText(String text, String title) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
            Intent ch = Intent.createChooser(i, title == null || title.isEmpty() ? "ارسال متن" : title);
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(ch);
            return "ok";
        } catch (Exception e) {
            return "err:" + e.getMessage();
        }
    }

    /* ---------- کپی تصویر ---------- */

    @JavascriptInterface
    public String copyImage(String b64, String name, String mime) {
        try {
            final File f = cacheFile(b64, safeName(name, "image.png"));
            final Uri u = uriFor(f);
            act.runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newUri(act.getContentResolver(), "image", u));
            });
            return "ok";
        } catch (Exception e) {
            return "err:" + e.getMessage();
        }
    }

    /* ---------- چاپ PDF ---------- */

    @JavascriptInterface
    public String printPdf(String b64, String name) {
        try {
            final File f = cacheFile(b64, safeName(name, "document.pdf"));
            final String label = f.getName();
            act.runOnUiThread(() -> {
                PrintManager pm = (PrintManager) act.getSystemService(Context.PRINT_SERVICE);
                pm.print(label, new PdfAdapter(f, label), null);
            });
            return "ok";
        } catch (Exception e) {
            return "err:" + e.getMessage();
        }
    }

    private static class PdfAdapter extends PrintDocumentAdapter {
        private final File file;
        private final String label;

        PdfAdapter(File f, String label) {
            this.file = f;
            this.label = label;
        }

        @Override
        public void onLayout(PrintAttributes o, PrintAttributes n, CancellationSignal c,
                             LayoutResultCallback cb, Bundle extras) {
            if (c.isCanceled()) {
                cb.onLayoutCancelled();
                return;
            }
            PrintDocumentInfo info = new PrintDocumentInfo.Builder(label)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                    .build();
            cb.onLayoutFinished(info, true);
        }

        @Override
        public void onWrite(PageRange[] pages, ParcelFileDescriptor dest, CancellationSignal c,
                            WriteResultCallback cb) {
            try (InputStream in = new FileInputStream(file);
                 OutputStream out = new FileOutputStream(dest.getFileDescriptor())) {
                byte[] buf = new byte[16384];
                int r;
                while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
            } catch (Exception e) {
                cb.onWriteFailed(e.getMessage());
            }
        }
    }

    /* ---------- تماس تلفنی ---------- */

    /** شمارهٔ مشتری را در شماره‌گیر گوشی باز می‌کند (بدون نیاز به مجوز). */
    @JavascriptInterface
    public String callPhone(String number) {
        try {
            String n = number == null ? "" : number.replaceAll("[^0-9+]", "");
            if (n.isEmpty()) return "err:empty";
            Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + n));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(i);
            return "ok";
        } catch (Exception e) {
            return "err:" + e.getMessage();
        }
    }
}
