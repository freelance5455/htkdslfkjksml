import { mkdir, copyFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const web = join(root, 'www');
await mkdir(web, { recursive: true });
for (const file of ['index.html', 'manifest.json', 'sw.js', 'icon-192.png', 'icon-512.png', 'favicon.png']) {
  await copyFile(join(root, file), join(web, file));
}
console.log('Arquivos web copiados para ./www — pronto para sincronizar com Capacitor.');
