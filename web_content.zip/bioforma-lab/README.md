# Bioforma Lab — Construtor anatômico

Aplicação web recreativa e educativa, em português, para montar organismos paramétricos e explorar sistemas anatômicos em uma vista lateral 2D. Funciona sem bibliotecas front-end externas e mantém projetos no armazenamento local do navegador.

## Abrir no computador ou celular

1. Extraia o ZIP.
2. Abra `index.html` em um navegador moderno. Para instalar como PWA ou usar o cache offline, sirva a pasta por HTTPS ou por um servidor local; por exemplo, no computador com Python instalado, execute `python -m http.server 8080` dentro da pasta e abra `http://localhost:8080`.
3. Em celulares, a interface se reorganiza conforme a orientação. O modo horizontal oferece o editor e os painéis lado a lado; no modo vertical, os controles ficam em um painel deslizante.

## O que está incluído

- Seis planos corporais ilustrativos: quadrúpede, bípede, ave, aquático, serpentino e vermiforme.
- Camadas de silhueta/pele, esqueleto, musculatura, órgãos, rede nervosa, rótulos e articulações.
- Seleção de componentes pelo desenho ou pela lista; ajuste de escala visual de uma estrutura e opção para restaurar a proporção.
- Parâmetros de comprimento, massa, proporção muscular, membros, cauda, armadura, atividade metabólica, capacidade aeróbica, complexidade neural fictícia e armas naturais.
- Nove regras heurísticas explicáveis: proporções anatômicas, locomoção terrestre, eficiência aquática, plano de ave, escavação/corpo mole, predador, herbívoro robusto, armadura e simetria.
- Ficha com estimativas comparativas de velocidade, força proxy, resistência, robustez, perigo ecológico, nível trófico ilustrativo, densidade corporal estimada, volume e massa muscular derivada.
- Salvar/abrir/excluir projetos neste dispositivo, desfazer alterações recentes, aleatorizar o modelo e importar/exportar JSON.
- Exportação do desenho visível em SVG, ícones PNG em 192 e 512 px, manifesto PWA e cache offline básico.

## Limites científicos importantes

Os algoritmos são **regras determinísticas de heurística**, não modelos de IA treinados nem simulações validadas por biomecânica. O desenho SVG é esquemático e paramétrico: não representa uma espécie exata, não constrói anatomia tridimensional real e não prevê movimento por dinâmica de corpos rígidos. Valores de velocidade, força, resistência, perigo, densidade corporal e posição trófica servem para comparação recreativa dentro deste aplicativo; não devem ser usados para avaliar risco de animais reais, saúde, segurança, desempenho ou viabilidade evolutiva. O índice neural também é fictício e não mede inteligência.

A anatomia comparada é variável: vertebrados podem ter endoesqueletos, invertebrados podem usar exoesqueletos ou suporte hidrostático, e os músculos esquelético, cardíaco e liso têm funções diferentes. O app resume esses temas em estruturas genéricas, sem pretender substituir material anatômico especializado.

## Converter em APK Android com Capacitor

Requisitos: Node.js 22 ou superior, Android Studio compatível, Android SDK e conexão à internet para instalar dependências. Capacitor usa uma pasta de ativos web separada; este projeto prepara essa pasta automaticamente.

Na pasta extraída, execute:

```bash
npm install
npm run android:add       # só na primeira vez; cria o projeto nativo Android
npm run android:open      # abre o projeto no Android Studio
```

Para levar mudanças futuras do HTML para o projeto Android:

```bash
npm run android:sync
npm run android:open
```

No Android Studio, aguarde a sincronização do Gradle e use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. O APK de teste normalmente fica em `android/app/build/outputs/apk/debug/`. Para distribuição, gere um APK/AAB assinado em **Build > Generate Signed Bundle / APK**.

O identificador padrão está definido como `br.bioformalab.app` em `capacitor.config.json`. Troque-o antes de uma publicação definitiva caso vá usar outro identificador.

### Preferir a orientação horizontal no APK

A interface aceita retrato e paisagem. Se quiser **bloquear** o APK em paisagem, depois de criar o projeto abra `android/app/src/main/AndroidManifest.xml` e acrescente `android:screenOrientation="sensorLandscape"` ao elemento `<activity>` principal. Isso é uma escolha do APK, separada da responsividade do HTML.

## Arquivos de origem

- `index.html`: aplicação completa (HTML, CSS, JavaScript e SVG procedurais).
- `manifest.json` / `sw.js`: metadados e cache offline para execução web instalada.
- `icon-192.png`, `icon-512.png`, `favicon.png`: ícones.
- `prepare-web.mjs`: atualiza a pasta que o Capacitor empacota.
- `www/`: cópia gerada dos ativos que seguem para o app Android.
- `package.json` / `capacitor.config.json`: configuração para a conversão em app nativo.

## Referências introdutórias

- OpenStax, *Biology 2e*, “Types of Skeletal Systems”: https://openstax.org/books/biology-2e/pages/38-1-types-of-skeletal-systems
- OpenStax, *Biology 2e*, “Muscle Contraction and Locomotion”: https://openstax.org/books/biology-2e/pages/38-4-muscle-contraction-and-locomotion
- OpenStax, *Anatomy and Physiology 2e*, “Muscle Tissue and Motion”: https://openstax.org/books/anatomy-and-physiology-2e/pages/4-4-muscle-tissue-and-motion

Estas referências apoiam os conceitos gerais; elas não validam as fórmulas heurísticas do aplicativo.
