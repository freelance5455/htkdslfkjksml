# Relatório de testes — Bioforma Lab 1.0

Testes automatizados executados em Chromium headless com recursos de armazenamento simulados no contexto de teste (a política do ambiente bloqueou navegações diretas para `file://` e `localhost`, então o HTML foi carregado diretamente no contexto do navegador).

- [x] Página inicial e montagem SVG renderizadas.
- [x] Abertura de todas as cinco seções da interface.
- [x] Troca do plano corporal e aplicação do algoritmo de ave.
- [x] Alternância da camada nervosa.
- [x] Seleção de estrutura e ajuste de escala local.
- [x] Renderização de oito cartões/indicadores da ficha técnica.
- [x] Salvamento e renderização de um projeto local no contexto simulado.
- [x] Download do SVG da anatomia.
- [x] Layout conferido nos viewports 1366×900, 854×393 (paisagem) e 390×844 (retrato).
- [x] Nenhuma exceção JavaScript ou erro de console observado durante esses fluxos.
- [x] Sintaxe do JavaScript validada com `node --check`.

## Limites do teste

O teste automatizado não substitui ensaios em dispositivos físicos, leitores de tela, versões variadas de WebView ou a compilação real de um APK. O contexto de navegação do ambiente de teste bloqueou navegações diretas de origem local; por isso, persistência local e fluxo de empacotamento Android precisam ser confirmados no computador/dispositivo de destino após extração. Não se afirma que o aplicativo esteja 100% livre de bugs.
