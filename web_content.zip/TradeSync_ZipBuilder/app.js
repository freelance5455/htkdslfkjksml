// TradeSync UI prototype only. No Telegram connection or native background service.
const demo = {pair:"AUD/JPY", otc:true, pairName:"Australian Dollar / Japanese Yen", direction:"SELL", entry:"19:15", seconds:12, expiry:"5 minutes", mg1:"19:20", mg2:"19:25"};
let timer = null;
let remaining = demo.seconds;
const $ = id => document.getElementById(id);
function renderSignal(s) {
  $("pair").innerHTML = `${escapeHtml(s.pair)} ${s.otc ? '<span class="otc">OTC</span>' : ''}`;
  $("pairName").textContent = s.pairName || "Currency pair";
  $("entryTime").textContent = s.entry || "Not provided";
  $("expiry").textContent = s.expiry || "Not provided";
  $("mg1").textContent = s.mg1 || "—";
  $("mg2").textContent = s.mg2 || "—";
  const isBuy = String(s.direction).toUpperCase() === "BUY";
  $("direction").textContent = isBuy ? "↗ BUY" : "↓ SELL";
  $("direction").className = `direction ${isBuy ? "buy" : "sell"}`;
  remaining = Math.max(0, Number(s.seconds) || 0);
  paintCountdown();
  if (timer) clearInterval(timer);
  timer = setInterval(() => { if (remaining > 0) remaining--; paintCountdown(); }, 1000);
}
function paintCountdown() {
  const m = Math.floor(remaining / 60), sec = remaining % 60;
  $("countdown").textContent = `${String(m).padStart(2,"0")}:${String(sec).padStart(2,"0")}`;
  $("countdown").classList.toggle("urgent", remaining <= 15 && remaining > 0);
  $("entryStatus").textContent = remaining > 0 ? "Until entry · demo" : "Entry time reached · demo";
}
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }

// Starter parser: expects a known signal text layout; real-world formats/timezones need testing.
function parseSignal(text) {
  const pair = text.match(/\b([A-Z]{3})\s*\/\s*([A-Z]{3})(?:\s+(OTC))?\b/i);
  const direction = text.match(/\b(BUY|SELL|CALL|PUT)\b/i);
  const entry = text.match(/\b(?:entry|at|time)\s*[:\-]?\s*(\d{1,2}:\d{2})\b/i);
  const expiry = text.match(/\b(?:expiry|expiration)\s*[:\-]?\s*(\d+)\s*(minutes?|mins?|m)\b/i);
  const martingales = [...text.matchAll(/\b(?:martingale|mg)\s*([12])\s*[:\-]?\s*(\d{1,2}:\d{2})\b/ig)];
  if (!pair || !direction) return null;
  return {
    pair: `${pair[1].toUpperCase()}/${pair[2].toUpperCase()}`,
    otc: Boolean(pair[3]),
    direction: /CALL/i.test(direction[1]) ? "BUY" : /PUT/i.test(direction[1]) ? "SELL" : direction[1].toUpperCase(),
    entry: entry ? entry[1] : null,
    expiry: expiry ? `${expiry[1]} minutes` : null,
    mg1: (martingales.find(x => x[1] === "1") || [])[2] || null,
    mg2: (martingales.find(x => x[1] === "2") || [])[2] || null
  };
}
window.TradeSync = {parseSignal, renderSignal};
$("urgentBtn").addEventListener("click", () => {
  renderSignal({...demo, seconds:7});
  $("toast").textContent = "Demo alert: entry in 7 seconds. No live signal connected.";
});
$("minutesBtn").addEventListener("click", () => {
  renderSignal({...demo, seconds:180});
  $("toast").textContent = "Demo alert: entry in 3 minutes. No live signal connected.";
});
renderSignal(demo);
