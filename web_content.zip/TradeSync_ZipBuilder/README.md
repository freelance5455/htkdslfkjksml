# TradeSync — Android ZIP Builder Starter

This is a phone-friendly starter project for building the **TradeSync signal-alert UI**. It is not a finished APK and does not yet connect to Telegram.

## What is included
- Dark, neon-blue compact signal alert preview
- Signal fields: currency pair/OTC, BUY/SELL, entry time, countdown, expiry, Martingale 1 and 2
- Demo signal data clearly labelled as demo
- Signal parser starter and timing helper
- Android implementation notes for a future native notification listener / overlay

## Important
A normal ZIP/web preview cannot reliably read Telegram channel history or show native Android floating notifications in the background. Those features require a native Android implementation, Android notification/overlay permissions, and a Telegram integration that can access the selected sender. This starter intentionally does **not** request Telegram credentials, execute trades, or place trades automatically.

## How to use
1. Extract the ZIP in your ZIP builder.
2. If your builder accepts HTML projects, open `index.html`.
3. If your builder expects a specific framework or Android project format, use the files as a UI/logic reference and select its Android/native option if available.
4. Treat all displayed signal values as demo data until connected to a real, authorized signal source.

## Project structure
- `index.html` — app-like demo screen
- `styles.css` — dark compact popup styling
- `app.js` — demo interaction, countdown, parser starter
- `android-native-notes.md` — what the native Android build still needs
