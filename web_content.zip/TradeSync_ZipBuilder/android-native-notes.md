# Native Android work still required

This ZIP is a UI prototype, not an Android APK.

For real background signal alerts, a native Android implementation must:
1. Use Android `NotificationListenerService` only after the user explicitly grants notification access. This can process Telegram notifications that Android exposes, not fetch arbitrary channel history.
2. Let the user select/confirm the exact sender/channel and test the match before enabling alerts.
3. Optionally use an overlay permission (`SYSTEM_ALERT_WINDOW`) for a small floating card; otherwise use a high-priority notification. Android version, battery restrictions, and app-specific policies affect behavior.
4. Parse the signal format from real examples, preserve the entry time as written, infer timezone only when supported by message context/settings, and show uncertainty rather than silently guessing.
5. Use Kenya time (`Africa/Nairobi`) for local comparison and test UTC−3 / UTC+3 cases including date rollover.
6. On reconnect, only alert for verified future/actionable entries; do not replay expired signals. If timing is ambiguous, show “TIME UNVERIFIED” and ask the user to check.
7. Store settings locally and provide export/import backup if desired.
8. Test background behavior with screen locked, battery saver, no network, duplicate messages, and Android notification permission changes.

No auto-trading is included. TradeSync alerts only; the user makes all entry decisions.
