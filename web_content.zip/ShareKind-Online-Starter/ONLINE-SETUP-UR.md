# ShareKind Online — اگلا مرحلہ

یہ پیکج ShareKind کے موجودہ prototype کے ساتھ آن لائن backend کے لیے ابتدائی database schema فراہم کرتا ہے۔ یہ اکیلا ابھی مکمل live app نہیں ہے؛ frontend کو Supabase credentials کے ساتھ connect کرنا، user login screens بنانا، cloud data loading/saving، email verification، moderation اور hosting مکمل کرنا باقی ہے۔

## ضروری چیزیں
- ایک Supabase project (cloud database + authentication + image storage)
- ایک HTTPS hosting site (مثلاً Netlify یا Vercel)
- ایپ کا privacy policy، terms، report/block اور moderation workflow

## Database شروع کرنے کا طریقہ
1. Supabase پر اپنا project بنائیں۔
2. Project کے SQL Editor میں `supabase/schema.sql` کا پورا متن paste کرکے Run کریں۔
3. Authentication settings میں email sign-up/verification کی ترتیب چیک کریں۔
4. Project URL اور anon/public key frontend configuration کے لیے درکار ہوں گے۔ **service_role/secret key کبھی browser یا APK میں نہ ڈالیں۔**
5. `index.html` ابھی پرانا demo frontend ہے؛ live users کے لیے اسے Supabase Auth اور database سے connect کرنا ضروری ہے۔
6. Hosting پر HTTPS کے ساتھ publish کرنے کے بعد Android Chrome میں site کھول کر “Install app” یا “Add to Home screen” استعمال کیا جا سکتا ہے۔

## اہم حفاظتی نوٹ
- یہ schema ابتدائی بنیاد ہے، production security audit نہیں۔ Public profiles/donations میں گھر کا مکمل پتہ یا ذاتی فون نمبر نہ دکھائیں۔
- حقیقی charity verification خودکار طور پر شامل نہیں۔ Verified badge تبھی دیں جب manual/admin review workflow بن جائے۔
- Donation handover, disputes, scams, prohibited items, account deletion اور privacy policy کے عمل launch سے پہلے بنانا ضروری ہے۔
- ابھی کوئی hosting یا Supabase project خودکار طور پر نہیں بنایا گیا؛ اس کے لیے آپ کے اپنے اکاؤنٹ میں setup کرنا ہوگا۔
