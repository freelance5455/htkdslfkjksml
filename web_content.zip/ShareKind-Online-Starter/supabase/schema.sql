-- ShareKind online backend starter (Supabase / PostgreSQL)
-- Run this in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'ShareKind member',
  country text,
  created_at timestamptz not null default now()
);

create table if not exists public.donations (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 2 and 100),
  category text not null check (category in ('Clothes','Books','Toys','Home','Shoes','School','Other')),
  condition text not null check (condition in ('Like new','Good','Used - still useful')),
  city text not null,
  country text not null,
  description text not null default '' check (char_length(description) <= 1000),
  photo_url text,
  status text not null default 'available' check (status in ('available','reserved','completed','hidden','under_review')),
  created_at timestamptz not null default now()
);

create table if not exists public.donation_requests (
  id uuid primary key default gen_random_uuid(),
  donation_id uuid not null references public.donations(id) on delete cascade,
  requester_id uuid not null references auth.users(id) on delete cascade,
  message text not null default '' check (char_length(message) <= 1000),
  status text not null default 'pending' check (status in ('pending','accepted','declined','cancelled','completed')),
  created_at timestamptz not null default now(),
  unique (donation_id, requester_id)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  donation_id uuid references public.donations(id) on delete set null,
  reason text not null check (char_length(reason) between 5 and 1000),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.donations enable row level security;
alter table public.donation_requests enable row level security;
alter table public.reports enable row level security;

create policy "Profiles readable to signed-in members" on public.profiles for select to authenticated using (true);
create policy "Members create own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "Members update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create policy "Anyone can view available donations" on public.donations for select to anon, authenticated using (status = 'available' or owner_id = auth.uid());
create policy "Members create own donations" on public.donations for insert to authenticated with check (owner_id = auth.uid());
create policy "Owners update own donations" on public.donations for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "Owners delete own donations" on public.donations for delete to authenticated using (owner_id = auth.uid());

create policy "Requesters and donation owners can view requests" on public.donation_requests for select to authenticated using (
  requester_id = auth.uid() or exists (select 1 from public.donations d where d.id = donation_id and d.owner_id = auth.uid())
);
create policy "Signed-in members request available donations" on public.donation_requests for insert to authenticated with check (
  requester_id = auth.uid() and exists (select 1 from public.donations d where d.id = donation_id and d.status = 'available' and d.owner_id <> auth.uid())
);
create policy "Requester can cancel own pending request" on public.donation_requests for update to authenticated using (requester_id = auth.uid() and status = 'pending') with check (requester_id = auth.uid() and status in ('pending','cancelled'));
create policy "Donation owner can respond to requests" on public.donation_requests for update to authenticated using (
  exists (select 1 from public.donations d where d.id = donation_id and d.owner_id = auth.uid())
) with check (
  exists (select 1 from public.donations d where d.id = donation_id and d.owner_id = auth.uid())
);

create policy "Members submit reports" on public.reports for insert to authenticated with check (reporter_id = auth.uid());
create policy "Members view only own reports" on public.reports for select to authenticated using (reporter_id = auth.uid());

-- Public listing images bucket (do not upload identity documents or sensitive photos here).
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('donation-photos', 'donation-photos', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
create policy "Anyone can view donation photos" on storage.objects for select using (bucket_id = 'donation-photos');
create policy "Signed-in members upload photos to own folder" on storage.objects for insert to authenticated with check (
  bucket_id = 'donation-photos' and (storage.foldername(name))[1] = auth.uid()::text
);
create policy "Members update own uploaded photos" on storage.objects for update to authenticated using (
  bucket_id = 'donation-photos' and (storage.foldername(name))[1] = auth.uid()::text
) with check (bucket_id = 'donation-photos' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Members delete own uploaded photos" on storage.objects for delete to authenticated using (
  bucket_id = 'donation-photos' and (storage.foldername(name))[1] = auth.uid()::text
);
