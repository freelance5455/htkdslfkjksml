KOR Institute Android App - APK ပြုလုပ်ရန်

ဤ ZIP သည် Android Studio project ဖြစ်သည်။ APK ဖိုင်ကိုယ်တိုင် မဟုတ်သေးပါ။

လိုအပ်သည့်အရာများ:
- Android Studio (တည်ငြိမ်သော နောက်ဆုံးဗားရှင်း)
- Android SDK Platform 35
- JDK 17

APK ပြုလုပ်ရန်:
1. ZIP ကို Extract လုပ်ပါ။
2. Android Studio ကိုဖွင့်ပြီး Open ကိုနှိပ်ပါ။
3. KOR_Android_APK_Project ဖိုလ်ဒါကိုရွေးပါ။
4. Gradle Sync ပြီးဆုံးእስኪሆን ይጠብቁ።
5. Build > Build Bundle(s) / APK(s) > Build APK(s) ይምረጡ።
6. APK በ app/build/outputs/apk/debug/app-debug.apk ይፈጠራል።

ማስታወሻ:
- አፕሊኬሽኑ የተሻሻለውን HTML dashboard በ Android WebView ያሳያል።
- Tailwind/Lucide/Google Fonts እንዲጫኑ የመጀመሪያ ጊዜ የInternet ግንኙነት ያስፈልጋል።
- የተመዘገቡ መረጃዎች በዚያ ስልክ ውስጥ በWebView local storage ይቀመጣሉ፤ ወደ cloud/server አይላኩም።
- Release APK ለማሰራጨት የራስዎ signing key ያስፈልጋል።
