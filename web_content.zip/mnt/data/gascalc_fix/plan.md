# Plan de implementación — GasCalc Chile (interfaz simplificada)

## Alcance y comportamiento

Mantener una sola vista y un único recuadro de trabajo con propietario, dirección, tipo de gas, datos editables de cada tramo, diámetros y pérdidas parciales/acumuladas por tramo. Quitar la fila completa de accesos rápidos (Tramos, Potencia, Metros, Diámetros y Pérdidas acumuladas) y retirar la tarjeta inferior titulada “Pérdidas acumuladas”; conservar el display superior y las pérdidas por tramo. Todos los campos visibles vuelven a calcular al modificarse. En cada campo de potencia ofrecer Mcal/h y kW; al cambiar de unidad, convertir el número visible para conservar la potencia física y normalizar a Mcal/h antes de aplicar f.1. Asumir automáticamente presión de operación menor a 10 kPa, sin casilla de confirmación, y mostrar ese supuesto como límite fijo; para 10 kPa o más, indicar que el método no aplica. Permitir guardar varios proyectos, abrirlos más adelante desde el mismo navegador y generar un PDF de la instalación y sus resultados.

Retirar de la interfaz los rótulos “Campo enfocado / Tramos”, “Atajos — enfoca el campo…”, el contador “Atajo 01/05” y los paneles “Instalar y usar sin conexión”, “Cómo se calcula y diferencias entre GLP y gas natural” y “Opciones técnicas adicionales”. Desactivar la instalación PWA en esta aplicación: quitar el enlace al manifiesto y el registro del service worker, retirar el manifiesto y el worker, cancelar registros existentes de GasCalc y borrar únicamente las cachés `gascalc-chile-*`. La propiedad PWA queda en `application_owned` para evitar que la plataforma inyecte otro manifiesto.

Para simplificar, usar perfiles fijos de referencia de Tabla VI (`GN d=0,59, PCS=9,0 Mcal/m³`; `GLP d=2,0, PCS=28,6 Mcal/m³`) y cobre Tipo L. El método f.1 y los límites de Tabla VIII se conservan. No aplicar e.2 al no pedir altura; mostrar una advertencia breve: desnivel vertical superior a 10 m o propiedades distintas al perfil referencial requieren cálculo/revisión profesional. Asumir automáticamente presión de operación menor a 10 kPa, mantener la actualización inmediata y advertir que el resultado no certifica una instalación.

## Implementación y estructura

- `index.html`: una sola caja, sin navegación por botones, paneles explicativos ni controles avanzados; conservar las pérdidas por tramo y el display superior, retirar la tarjeta inferior de resultado y la casilla de presión; mostrar estáticamente que se asume presión menor a 10 kPa; incluir el selector Mcal/h o kW por tramo y los controles/dialogs de guardar, abrir proyectos, crear uno nuevo y generar PDF.
- `src/app.js`: mantener el cálculo f.1 y el recálculo inmediato; fijar referencias GN/GLP y cobre Tipo L; asumir siempre baja presión sin bloquear el cálculo por confirmación; convertir la unidad seleccionada a Mcal/h para el cálculo y convertir el valor visible al alternar unidades; actualizar pérdidas por tramo y display superior sin escribir en la tarjeta final retirada; guardar, listar, abrir y eliminar proyectos en `localStorage` del mismo navegador; formar un informe imprimible desde el proyecto validado y abrir `window.print()` para guardarlo como PDF; retirar eventos de la casilla de presión, de los accesos rápidos, cálculo/controles de desnivel, registro del service worker e instrucciones de instalación; al iniciar, retirar registros y cachés de versiones anteriores.
- `assets/styles.css`: retirar estilos de accesos, paneles explicativos, tarjeta final y casilla eliminados; conservar el diseño móvil de una sola vista, dar cabida al selector de unidad dentro del campo de potencia, y definir estilos responsive para dialogs y un reporte A4 de impresión/PDF.
- `service-worker.js`, `manifest.webmanifest`, iconos PWA: dejar de usarlos y quitar los archivos instalables; conservar el símbolo SVG como favicon.
- `manus-routes.json`: única ruta `/`; `REFERENCIAS.md`, `plan.md` y `TODO.md`: conservar notas internas.
- Aplicación estática en el puerto 3000, sin servidor de aplicación ni base de datos; los proyectos se almacenan solo en el navegador actual y no se sincronizan a otros dispositivos.

## Diseño

- **Design Movement:** instrumento técnico editorial inspirado en calculadoras industriales de campo.
- **Core Principles:** vista única, cálculos comprensibles, pocos controles visibles y advertencias breves.
- **Color Philosophy:** papel claro y azul petróleo para calma; verde/turquesa para resultados admisibles; ámbar para límites.
- **Layout Paradigm:** caja compacta de una sola vista, sin paneles accesorios ni navegación por atajos.
- **Signature Elements:** display oscuro con el total de Δp; filas con potencia, metros y diámetro; pérdidas parciales y acumuladas visibles en cada tramo.
- **Interaction Philosophy:** modificar cualquier campo directamente, sin cambiar de pantalla; los resultados se actualizan al instante.
- **Animation:** transiciones discretas para controles activos y respeto a `prefers-reduced-motion`.
- **Typography System:** sans serif del sistema y cifras tabulares/monoespaciadas; sin descargas remotas.
- **Brand Essence:** calculadora chilena clara y directa para revisar cañerías de gas; precisa, sobria y cautelosa.
- **Brand Voice:** microcopy breve. Ejemplos: “Cambia un dato y revisa la pérdida.” / “Perfil de referencia; confirma las condiciones de tu instalación.”
- **Wordmark & Logo:** mantener el texto GASCALC CHILE y usar un monograma vectorial exacto “AHM” en alto contraste para el logo visible, favicon e identidad del proyecto.
- **Signature Brand Color:** verde petróleo `#167F79`.

Propietario y dirección se usan solo en la página; no se envían ni guardan automáticamente.

## Continuación recuperada — contraste de textos (10 de octubre de 2026)

Se recuperó el mismo recurso GasCalc desde su versión `eec591d500508bbbe5a88e6354769032799e108c`. La petición actual se limita a intensificar los colores de los textos interiores: etiquetas y ayudas en petróleo/verde más oscuro, valores de pérdidas en verde más profundo sobre fondos claros y verde luminoso en el display oscuro, y avisos en ámbar/rojo de mayor contraste. Se mantienen sin cambios fondos, medidas, distribución responsive, fuentes, logo AHM, código de cálculo, conversión Mcal/h–kW, supuesto de presión <10 kPa, almacenamiento local y generación PDF. Se cambia la referencia de CSS de v22 a v23 para cargar los nuevos colores. No se implementa kWh ni se publica permanentemente.

La nueva vista previa usa un origen de navegador distinto: el código y el historial del sitio sí se recuperan, pero las instalaciones guardadas en localStorage del origen anterior no se trasladan automáticamente. No se ha intentado acceder, modificar ni migrar esos datos del usuario.

## Realce expresivo de las letras — segunda revisión

La petición de letras más vivas y especiales se implementa con una jerarquía más marcada: títulos en petróleo sólido, etiquetas en esmeralda saturado y peso 800, entradas en peso 750, ejemplos con opacidad explícita 1, cifras de pérdidas más grandes y gruesas, y total en verde luminoso sobre el display oscuro. Las ayudas y las unidades también ganan peso y legibilidad. Se conserva la fuente del sistema y el diseño de los recuadros; únicamente se reserva una altura de 18 px para etiquetas móviles, manteniendo los cuatro campos alineados. Los cambios se limitan al medio pantalla: el informe impreso y el código de funciones permanecen idénticos a la revisión anterior. Hoja de estilos v24, sin publicación permanente.

## Campo Tramo más compacto y ejemplo «mt»

Se reduce un 20% el ancho del input Tramo respecto de la revisión 45d5c30: pasa de 25% a 20% de su área en escritorio y de 100% a 80% en móvil. Se reemplaza únicamente el placeholder «Distancia» por «mt»; la etiqueta Metros y la unidad lateral m se conservan. Sin cambios en columnas, tipografía viva, cálculos, guardado o PDF. Referencia de estilos v25; guardar sin publicación permanente.

## Más espacio para Potencia, menos para Metros

Se amplía Potencia de 50% a 75% del área de su campo en escritorio. Metros se reduce de 25% a 20%, con un mínimo de 26 px para mantener visible la cifra y la unidad. En móvil se redistribuyen solo las columnas de Potencia y Metros a 1,2 y 0,8 partes respectivamente, manteniendo el resto de columnas; así Potencia gana 20% y Metros pierde 20%. Se ocultan visualmente las flechas de incremento nativas en estos dos inputs numéricos para que no tapen sus cifras; siguen admitiendo números y edición por teclado. Se preservan placeholder mt, unidades, Tramo compacto, colores y todas las funciones. Estilos v26; sin publicación permanente.

## Unidad Mt única y textos interiores negros

Según la aclaración del usuario, se destacan las palabras interiores en negro, no los bordes. Todos los textos visibles de la calculadora, campos, resultados, ayudas, unidades, ejemplos, botones y diálogos pasan a negro sólido conservando sus pesos tipográficos. El display oscuro y el botón PDF usan un fondo verde claro para que las letras negras se lean; el estado sobre límite mantiene fondo rojizo. Se retira el placeholder mt y se reemplaza la unidad lateral m por Mt, con M mayúscula, t minúscula y peso 900. Solo aparece una abreviatura Mt por campo y permanece al ingresar un número. El mínimo de Metros pasa a 36 px para evitar superposición de cifra y unidad; el campo sigue compacto. Estilos v27; JavaScript y PDF sin cambios y sin publicación permanente.

## Potencia con más espacio y Mt centrada

Potencia ocupa el 100% del ancho de su área en escritorio (antes 75%). En móvil su columna pasa de 1,2 a 1,4 partes; la de Tramo pasa de 1 a 0,8 y su input utiliza toda esa columna, conservando prácticamente el ancho compacto previo. Metros y Diámetro mantienen sus columnas. Mt se centra horizontal y verticalmente dentro del recuadro cuando está vacío usando un placeholder invisible, sin duplicar la unidad; al introducir un valor, Mt se centra en su área lateral de 16 px para no tapar el número. Se preservan negro sólido, fórmulas, funciones e impresión. Estilos v28, sin publicación permanente.

## Ejemplo optativo de 60 Mcal/h

El usuario aclaró que los dos casos son un ejemplo. Se agrega únicamente una precarga por URL `?ejemplo=60mcal`: tramo A con 33 Mt, 60 Mcal/h y 1 1/4″; tramo B con 6 Mt, 60 Mcal/h y 1″. Para la comparación se mantiene gas natural como supuesto explícito en el nombre del ejemplo; el usuario no indicó el tipo de gas. Las pérdidas parciales del perfil vigente son 69,33 y 43,55 Pa, acumuladas 112,88 Pa si se consideran una ruta en serie; los valores aportados de 62,4 y 39,3 Pa se consideran referencias, no se fuerzan como salidas. No se calibra ni modifica fórmula, densidad, PCS, diámetros o K. El enlace normal y Nuevo siguen comenzando vacíos; el ejemplo no escribe en localStorage ni altera proyectos guardados. JS v15; sin publicación permanente.

## Confirmación del gas del ejemplo

El usuario confirmó gas natural. El nombre cargado por el ejemplo pasa a «Ejemplo · Gas natural · 60 Mcal/h»; ya no se presenta como un gas supuesto. Se mantienen fórmula y perfil vigente sin calibración, con pérdidas parciales 69,33 y 43,55 Pa para los dos casos. La diferencia frente a 62,4 y 39,3 Pa queda pendiente de identificar parámetros o método de referencia, no se corrige forzando las salidas. JS v16; sin publicación permanente.

## Cobre Tipo L de 2½″

Se agrega la medida 2 1/2″ entre 2″ y 3″. Parámetros: K=2160 del grupo 2″ a 2½″ de Tabla IX; diámetro exterior 66,675 mm y espesor 2,032 mm de ficha Conmetal (ASTM B88/NCh 951), corroborados con Taylor Walraven; diámetro interior derivado 62,611 mm, utilizado como 62,61 mm. Se conserva la fórmula f.1 y todos los diámetros existentes. Selección, normalización Mcal/h/kW, cálculo GN/GLP y serialización usan el catálogo común, sin alterar almacenamiento. Cuando se selecciona esta medida, una nota bajo la fila enlaza su ficha y detalla dimensiones/K; el PDF repite la procedencia para no atribuir el diámetro a Tabla XI. Se debe confirmar el tubo instalado y no trasladar este diámetro a otra serie/material. CSS v29, JS v17; sin publicación permanente.

## Letras AHM más vivas

Se sustituye Arial por Fredoka Bold (peso 700), de formas más redondeadas y expresivas, únicamente en AHM. Las letras se convierten a trazados SVG para conservar el aspecto sin instalar ni descargar fuentes en el navegador. Se mantiene el fondo petróleo, la línea verde, las iniciales exactas y la accesibilidad con título/descripción. El mismo SVG se usa en logo visible y favicon con versión v2, y en la identidad del proyecto mediante una nueva URL de activo. Fuente Fredoka de Google Fonts/Fontsource, licencia SIL OFL 1.1; no se redistribuye el archivo de fuente en la app. Código de cálculos y estilos de la calculadora sin cambios; sin publicación permanente.

## Vista de informe con zoom antes de PDF

PDF abre un diálogo que muestra el mismo informe HTML que se imprime, con los estilos de impresión existentes reutilizados en un iframe srcdoc sin scripts. `src/report-viewer.js` controla zoom 25–200%, −/+, 100%, Ajustar al ancho y el tamaño del área desplazable. La vista inicia ajustada al ancho disponible y permite desplazar un informe largo o ampliado. Guardar como PDF / Imprimir llama al flujo original de impresión, cerrando temporalmente la vista y restaurándola después; el zoom solo afecta la lectura, no el PDF A4. No se genera un archivo PDF dentro del visor ni se sustituye el diálogo nativo del navegador. Contenido, cálculos, parámetros, proyectos y diseño principal no cambian. No se publica permanentemente.

## Lector de PDF guardados para celular

La vista HTML anterior no resuelve el zoom al abrir un PDF descargado en otra aplicación. Se conserva esa vista y se añade un diálogo independiente mediante `src/saved-pdf-viewer.js`, con carga local de archivo y PDF.js vendorizado (biblioteca legacy, worker, licencia y recursos), importado solo al seleccionar PDF. Renderizar una página por vez en canvas con resolución adaptada al zoom, topes de píxeles y liberación al cerrar; zoom de lectura 25–400%, botones, Ajustar al ancho, gesto de dos dedos y arrastre en móvil, paginación. Ningún PDF se envía a un servidor ni se guarda en localStorage. La opción está disponible sin entradas de cálculo y también desde la vista previa. El contenido PDF ajeno no ejecuta scripts; los archivos inválidos o protegidos muestran un error sin bloquear la calculadora. No se puede cambiar el lector externo del teléfono ni sus controles desde el PDF: la entrega explicará usar Abrir PDF guardado o un lector externo con zoom. Ninguna fórmula, parámetro, formato de informe ni dato de instalación cambia. No se publica permanentemente.

## Icono AHM transparente + Gas

La petición se interpreta como AHM con letras caladas/transparencia real, acompañadas por un contorno claro para mantener legibilidad sobre distintos fondos, y «Gas» debajo. Se modifica el SVG fuente controlado en Git utilizando los mismos trazados Fredoka Bold, una máscara alfa para AHM y trazados de Gas derivados de la fuente ya usada y licenciada. Se conserva fondo petróleo y acento verde; se reorganiza solo el interior del icono. Refrescar favicon/logo de cabecera y metadata logoUrl con el mismo SVG final. Calculadora e informes intactos; sin publicación permanente.

## Uso sin conexión e instalación Android

Se añade manifiesto application_owned, iconos PNG desde el SVG AHM Gas, `src/offline.js` para registro/estado/instalación/actualización, `sw.js` generado desde recursos reales y `scripts/build-offline.mjs` para inventario versionado. El SW cachea toda la aplicación y recursos PDF.js en instalación atómica con concurrencia limitada y verificación SHA-256 de assets; HTML se acepta sin hash por enriquecimiento del hosting. Cache-first para navegación y recursos de la versión activa evita mezclar versión HTML y scripts. Una nueva versión espera hasta que el usuario pulse Actualizar tras guardar; no elimina localStorage ni recarga automáticamente trabajo abierto. Los caches viejos solo se reemplazan al activar la versión nueva. La pantalla anuncia Lista sin conexión solo cuando el worker completo está activo y controla la página, junto con versión. Se precachean recursos PDF antes de usarlos por primera vez sin internet. Fuentes remotas no intervienen. La impresión Guardar PDF usa el sistema del dispositivo, no un servidor. Enlaces externos a fichas/normativa requieren conexión. Primera carga y actualizaciones necesitan internet; no se garantiza disponibilidad si Android borra los datos del sitio. Publicación estática incluye manifiesto y SW; los proyectos quedan ligados al origen de la URL permanente y el acceso viejo se conserva.

## Letras de recuadros más grandes

Se amplían entradas a 12 px, etiquetas a 10–11 px, unidades Mt a 11 px y resultados parciales/acumulados a 15 px; también avisos y textos de cajas. Negro y fondos claros se conservan. Ajuste mínimo de espacio y altura en móvil para mantener cuatro campos juntos sin mezclar cifras y unidades. Reglas solo screen, impresión existente intacta. Se regenera SW/versionado offline para el nuevo CSS. Fórmulas, proyectos, logo y PDF no se modifican. No se duplica la solicitud de publicación pendiente.

## Archivos y compartir desde el celular

Se amplía el diálogo Guardar, no la barra superior: formato Proyecto editable JSON o Informe PDF, botones de descarga y compartir nativo, además del guardado en navegador existente. `src/project-files.js` maneja validación de entrada, Blob/File, descargas y PDF vectorial local con jsPDF empaquetado. El PDF se construye desde el informe vigente, no recalcula ni altera fórmulas. JSON guarda solo entradas y usa una envoltura versionada propia; se abre desde Proyectos con validación de tipo de gas, medidas y valores y queda como copia sin ID de guardado, evitando sobrescritura. Datos personales salen del dispositivo solo cuando el usuario elige destinatario en Compartir. Si compartir archivos no está admitido, se ofrece descarga explícita. Recursos incluidos por el generador offline actual; sin CDN. No se modifica la clave de localStorage ni la funcionalidad original de PDF/zoom. Referencias de navegador: https://developer.mozilla.org/en-US/docs/Web/API/Navigator/share y https://developer.mozilla.org/en-US/docs/Web/API/Navigator/canShare.

## Selección automática de diámetros comerciales

Los proyectos nuevos usan Diámetros automáticos (casilla desactivable para selección manual). Los guardados y archivos anteriores, sin esta propiedad, siguen manuales: no se cambia silenciosamente la instalación existente. Cada tramo requiere su potencia transportada y longitud efectiva (incluidos accesorios según proyecto); el alcance sigue siendo una ruta en serie de cobre Tipo L con perfiles GN/GLP referenciales y presión <10 kPa. No se suman las potencias de filas como si fueran artefactos independientes.

`src/diameter-sizing.js` recibe entradas válidas, medidas y la misma función f.1 de la aplicación. Empieza por la medida menor y aumenta el diámetro del tramo cuyo siguiente tamaño proporciona mayor reducción de pérdida hasta que la suma esté estrictamente bajo/equal al límite. Luego reduce medidas donde la suma recalculada aún permita respetar el límite. Es una selección determinista factible/localmente reducible, no un óptimo global ni un presupuesto ni un procedimiento prescrito por DS 66. El límite se comprueba sobre pérdidas sin redondear y no se reparte un límite completo por tramo. Si ni todas las medidas mayores cumplen, se muestran esas medidas con pérdida excedida y aviso explícito de que no hay solución disponible; nunca se presenta como instalación conforme. Valores incompletos/negativos/no finitos no producen recomendación válida. Cambiar potencia, longitud, gas, unidades o cantidad de tramos recalcula toda la ruta. Automático deshabilita los selectores pero conserva lectura clara; manual conserva los diámetros calculados y la validación original.

Guardado local y JSON incluyen `autoSizing` booleano opcional; los archivos antiguos se interpretan manuales. PDF identifica la selección automática y sus límites de uso. La selección funciona offline y no modifica densidad, PCS, K ni diámetros de catálogo. Fuentes verificadas el 16-10-2026: DS 66 art. 45.2.9 (demanda máxima, pérdida suministro–artefacto, longitud/accesorios), https://www.bcn.cl/leychile/navegar?idNorma=263058 y https://modulor.cl/especialidades/gas/capitulo-06-construccion-tuberias-de-gas/. La referencia de Tabla VIII y los perfiles existentes se conservan; no equivalen a certificar todos los requisitos normativos o la presión mínima del artefacto.

## Refinamiento de cercanía a la pérdida máxima

La selección automática conserva la primera combinación factible y añade una búsqueda acotada de combinaciones de medidas comerciales: ramificación y poda con hasta 100.000 estados, seguida de ajustes de uno/dos tramos con verificación completa de la suma. Solo se acepta una combinación cuando su pérdida sin redondear es mayor que la mejor encontrada y sigue ≤ al límite. El número de estados/pasadas se limita para mantener respuesta móvil, por lo que se muestra la mejor encontrada, no se promete óptimo global para cualquier red grande. Se muestra margen = límite − pérdida. No se altera ninguna distancia ni potencia ni se crean filas artificiales; los nuevos tramos solo deben reflejar secciones reales que el usuario conoce. Dividir una longitud en tramos con el mismo diámetro y flujo no cambia la pérdida lineal, y una reducción de diámetro implica una transición física/accesorio que debe contemplarse, no un truco para alcanzar el máximo. El límite es un máximo admisible, no un objetivo obligatorio: la revisión real debe considerar accesorios, presión mínima del artefacto y margen. El ejemplo 60 Mcal/h con 33 m y 6 m tiene mejor combinación disponible 1¼″/1″ = 112,88273973599121 Pa bajo 120 Pa, sin necesidad de nuevos tramos.

### Caso real de 21 metros indicado por el usuario

Se añade el enlace optativo `?ejemplo=21mts` con dos tramos reales: 7 m en 1¼″ y 14 m en 1″, ambos con 60 Mcal/h y GN. Se conservan exactamente esas entradas, sin guardar automáticamente. Con la fórmula y perfiles existentes: 14,706348159989 Pa + 101,623229624102 Pa = 116,329577784091 Pa; margen respecto de 120 Pa = 3,670422215909 Pa. Cumple el criterio de pérdida de este modelo, sujeto a incluir accesorios/longitudes efectivas y verificar suministro, presión mínima y revisión del instalador. No es certificación de la instalación.

El usuario pidió un tramo adicional de ejemplo. `?ejemplo=21mts3` divide la sección de 14 m de 1″ en B=7 m y C=7 m de 1″; A permanece 7 m de 1¼″. Las tres potencias son 60 Mcal/h transportados, no 180 Mcal/h de demanda sumada. Longitud total 21 m y pérdida lineal total 116,329577784091 Pa, igual a la variante de dos tramos. Es una división demostrativa; cualquier unión/transición real añadida debe contemplar su accesorio en las longitudes efectivas. No escribe ni borra proyectos.

Corrección final del usuario: el ejemplo principal `?ejemplo=21mts` usa exactamente **AB = 7 m de 1¼″** y **BC = 14 m de 1″**, ambos 60 Mcal/h GN. Se entrega este enlace de dos tramos, no la variante demostrativa de tres filas. Potencias/distancias/pérdidas permanecen iguales y no se guarda automáticamente.

## Alternativas técnicas para cotizar

Se añade `Comparar alternativas` en el editor, con diálogo compacto (sin rediseñar la calculadora). `src/alternatives.js` calcula tres criterios sobre las mismas entradas: cercana al límite (selector actual), más margen (siguiente medida disponible en cada tramo) y diámetro único (menor medida uniforme que respete la suma). Se deduplican combinaciones idénticas y se muestran solo alternativas verificadas ≤ al límite, con metros por medida, pérdida/margen y cambios de diámetro consecutivos. No se presentan precios, ahorro económico ni promesa de adjudicación. El precio real requiere cotizar tubo, reducciones/uniones/accesorios, mano de obra, ensayos y condiciones del proyecto. Agregar filas solo corresponde a cambios reales/planteados de trazado, no longitudes ficticias para forzar pérdidas.

Cada alternativa se puede abrir como copia manual: mismo propietario/dirección, gas, nombres, longitudes y unidades originales; solo cambian los diámetros. ID de guardado se desvincula, nombre indica alternativa y estado queda sin guardar. Se confirma reemplazo de pantalla si hay cambios, no se escribe ni elimina localStorage. El usuario puede guardar/exportar PDF/JSON/compartir por el flujo vigente. Si no hay ninguna solución con medidas disponibles, el diálogo informa imposibilidad; entradas incompletas no generan alternativas. Todos los recursos son locales y se incorporan al inventario offline existente.

## Etiquetas sobre los recuadros
Las cuatro etiquetas Tramo, Potencia, MTS y Diámetro se centran sobre el ancho efectivo de su control, con altura16px y separación3px. En móvil se elimina el espacio reservado40px y se mantienen las cuatro columnas y sus tamaños. MTS sustituye solo el título Metros; Mt interior y cálculos/formatos de archivos permanecen intactos. Se regenera caché offline.

## Matriz y arranques de la red interior

Se añade un modo explícito Lineal / Matriz y arranques, conservando Lineal para proyectos existentes. No se infiere una conexión por el nombre AB/BC ni por el diámetro y no se crean secciones. La persona define un único origen de baja presión y la conexión de cada fila con su alimentador real. El modelo es un árbol (sin anillos ni varios abastecimientos). El origen y tramos con varios terminales descendientes se identifican como Matriz; los que abastecen un solo terminal son Arranque, indicando terminal o continuación. La carga se escribe en terminales (demanda máxima alimentada); los intermedios muestran solo lectura la suma exacta transportada. Se usa factor de simultaneidad1,0; no se implementan factores multivivienda, otra presión, alturas ni propiedades de suministro distintas.

`src/network-tree.js` analiza conexiones por IDs estables, determina roles y cargas, suma pérdidas solo en cada trayectoria y selecciona medidas comerciales. Se empieza en la menor medida y se amplía un tramo elegible de la ruta crítica, manteniendo diámetro de padre ≥ hijo; después se reducen medidas cuando todos los recorridos siguen bajo el límite. Si incluso todos los mayores exceden alguna ruta, se muestra Sin solución. Toda comprobación usa f.1 original, K/diámetros/perfiles originales y sumas sin redondeo, máximo120/150Pa. No es óptimo global de costo ni certificación. El mayor recorrido en pérdida (no necesariamente el más largo) determina el resultado global. Las ramas hermanas no se suman como serie.

`src/network-controls.js` mantiene conexión, demanda propia y unidad por fila; los padres se eligen desde un selector y los nombres se presentan con número de fila. Las opciones se expanden al enfocar para no crear n² controles al cargar. Las demandas propias se conservan cuando un tramo pasa a intermedio o se vuelve al modo lineal, en vez de reutilizar una suma como nueva carga terminal. El cálculo de las matrices es exacto a partir de demandas; el número visible se redondea solo para lectura. Los cuatro campos y etiquetas actuales se conservan, agregando una fila de identificación/conexión solo en modo ramificado. Se añade `assets/network.css` y se empaquetan todos los recursos por el generador PWA existente.

Guardar local y PDF preservan conexiones, carga y roles calculados. JSON/TXT ramificado usa versión2 y metadata networkId/parentId/ownPower; el lector nuevo sigue aceptando versión1 lineal, mientras que el anterior rechaza versión2 en lugar de interpretar una ramificación como serie. No se migra ni borra localStorage. Los borradores con conexión incompleta pueden conservarse, pero no producen cálculos ni PDF válidos hasta resolverla. El informe mantiene seis columnas, con rol/alimentador en Tramo; muestra pérdida origen→fila y peor ruta. Comparar alternativas permanece disponible solo en Lineal, porque el comparador anterior presupone una sola serie. No se publica esta modificación.

### Identificación explícita del ejemplo del usuario

La matriz continua es AB→BD→DF, con potencias48→18→8Mcal/h. BC30sale de AB y DE10sale de BD: AB=BC+BD y BD=DE+DF. El rol de DF es Matriz final aunque sea un terminal en el árbol. Se añade identificación manual Auto/Matriz/Arranque/Matriz final; afecta nombres/informe, no el balance de potencias ni las conexiones. La clasificación automática no puede sustituir la identificación indicada por el usuario. El enlace ?ejemplo=matriz48 precarga exactamente estas conexiones/potencias y roles como ejemplo sin escribir localStorage; todas las distancias permanecen vacías, por lo que no muestra diámetros/resultados hasta completar los metros efectivos reales. Se interpreta 18cal como18Mcal/h por el contexto y el balance explícito48=30+18.

### Distancias finales proporcionadas

El usuario completó AB10m, BC5m, BD6m, DE5m y DF6m. Se actualiza el ejemplo sin inventar metros. La longitud instalada es32m; los recorridos son AB–BC, AB–BD–DE y AB–BD–DF y se verifican separadamente. La matriz física indicada es AB→BD→DF, BC/DE son arranques; el tipo manual DF=Matriz final se conserva. Los roles son identificación descriptiva elegida: las conexiones y demanda terminal determinan el flujo, no la etiqueta. El ejemplo se carga solo al abrir ?ejemplo=matriz48, no al abrir normal ni en los proyectos locales.

### Revisión final

La clasificación Auto/Matriz/Arranque/Matriz final es descriptiva y no cambia el balance. Una matriz final sin hijos transporta la demanda terminal suministrada (DF8), sin consumir una carga adicional. En modo automático ramificado, estado Sin solución conserva las mayores medidas solo como evidencia visual y bloquea resultado/PDF; no presenta selección factible. En manual, el informe puede documentar un exceso, pero lo señala expresamente y nunca lo describe como selección factible. El modelo lineal mantiene su diagnóstico previo de Sin solución en PDF. La revisión detectó y corrigió esta diferencia, conservando parámetros y fórmula.

## Foto del plano

La misma aplicación incorpora un diálogo de foto y transcripción revisable. Un servidor Node sin dependencias sirve los archivos actuales y POST /api/analyze-plan usa el servicio de visión del proyecto con credencial solo del servidor. La foto se reencoda conservando proporción/rotación y se envía únicamente al pulsar Analizar; no se guarda en disco. Se limita tamaño, concurrencia, frecuencia y tiempo de respuesta. Modelo elegido de catálogo real, salida estructurada validada; no se calcula con IA ni se cambian coeficientes.

El resultado es un borrador: las cifras sin evidencia, unidades, origen o alimentadores desconocidos se dejan pendientes. El usuario puede corregir o transcribir manualmente mirando la foto, incluso offline. Antes de crear copia se validan árbol, cargas, metros y conexión; una discrepancia entre potencia transportada legible y suma terminal exige corregirla. No se deducen longitudes de píxeles ni se aplica diámetro dibujado. Gas seleccionado y dimensiones originales alimentan el cálculo existente, con diámetro automático. La aceptación crea un proyecto nuevo no guardado, sin tocar proyectos anteriores. Fotos no se guardan en JSON/PDF ni servidor. Backend habilitado para el mismo proyecto, preparación de despliegue híbrido; esta edición se conserva local sin publicar. Reconocimiento visual necesita internet; funciones locales/offline previas se mantienen.

### Compuertas de revisión de foto

Gas desconocido queda pendiente y exige elección; no hereda el gas de otro proyecto. Cada potencia visible se clasifica explícitamente como demanda terminal o transporte antes de usarla; una matriz vacía se deriva de terminales verificados. Cobre Tipo L requiere confirmación separada; si la lectura indica otro material/espesor, se bloquea salvo corrección explícita de una lectura errónea verificada por el usuario. Presión leída debe ser positiva y menor a 10 kPa. Salida estructurada completa validada, dimensiones antes de decodificar (máximo 40 MP de entrada; API solo imagen reducida hasta 2400 px), cuota por conexión sin confiar en x-forwarded-for. Análisis en curso bloquea edición de revisión; cambiar a manual/cerrar invalida y aborta, y un guard evita aplicar una copia tras cerrar. Foto se procesa por servicio externo al analizar; la app no la archiva en servidor o proyectos.

### Recuadros Δp más compactos

Reducir únicamente las tarjetas de pérdidas parcial y acumulada por tramo al 85% de su área asignada (máximo 150 px), mínimo 38 px de alto y relleno de 3×5 px. Conservar legibilidad de números y Pa con 14 px, rótulos 10 px y coeficiente 8 px. No cambiar el display total, los cuatro campos, los cálculos ni PDF. Regenerar versión offline; guardar edición localmente sin publicar por la autorización vigente.

### Selector de modo sin comentario

Mostrar únicamente las opciones «Automático» y «Manual» para los diámetros. Sustituir la casilla por un selector compacto, manteniendo `autoSizing` booleano en proyectos/archivos y los estados originales al abrir, crear, importar o aplicar alternativas. El texto auxiliar de selección permanece oculto; los errores de entradas, imposibilidad y exceso de límite se siguen mostrando en el resultado. Sin cambios de fórmulas ni parámetros o PDF. Actualizar caché offline y guardar localmente sin publicar.

La finalidad explícita es aprovechar al máximo la pantalla: Red y Automático/Manual comparten una fila compacta sin párrafo auxiliar. Mantener íntegros los campos y los resultados; conservar únicamente los avisos técnicos que ya existen fuera de este selector, sin agregar comentarios nuevos.

### Pantalla sin recuadro central verde

Retirar de la pantalla la tarjeta central de pérdida total/peor recorrido. Los valores por tramo y el límite de tipo de gas permanecen; el informe PDF conserva total/peor recorrido y toda su información. Eliminar dependencias visuales de la tarjeta sin tocar cálculo ni selección de medidas. Datos incompletos/inválidos o fuera del límite producen un aviso simple de texto sin borde/fondo. Actualizar versión offline y guardar localmente sin publicar.

### Límite integrado en el gas

Mostrar «Gas natural · 120 Pa» y «Gas licuado (GLP) · 150 Pa» dentro del selector original. Retirar únicamente la caja de límite con Δp, «Límite Tabla VIII» y descripción de suministro; el selector ocupa el ancho disponible sin texto adicional. Las opciones toman sus límites del mismo objeto GAS, sin modificar valores, fórmula, cálculo, PDF ni almacenamiento. Actualizar versión offline y guardar localmente sin publicar.

### Plano y cálculo en pantalla principal

Reutilizar el reconocimiento y la revisión existentes; «Llevar a pantalla y calcular» importa todos los tramos verificados como proyecto nuevo no guardado y activa Automático. Añadir un apartado plegable, sin fondo verde, para la imagen original de la sesión y toda la lectura estructurada ya extraída (gas, red, material, presión, advertencias y evidencia de cada tramo). La imagen permanece local y temporal; se guardan únicamente textos estructurados opcionales del origen en proyectos/JSON, conservando compatibilidad de archivos previos. Limpiar la imagen anterior al iniciar/abrir otro proyecto, nunca al cancelar un traslado. No ampliar el alcance de extracción ni cambiar fórmulas, parámetros, diámetros disponibles, validaciones ni privacidad del envío. Sin datos inventados ni cálculo de información aún pendiente; sin publicación.

### Foto conservada y adjunta en PDF

La petición nueva autoriza guardar la foto localmente con el proyecto, sustituyendo la decisión previa de imagen temporal. Conservar una copia JPEG sin metadatos hasta 1600 px de lado y 1,2 millones de caracteres base64; no recortar ni cambiar proporción. Guardar en planSource.image con validación de firma/dimensiones y tamaño, junto a los textos ya leídos, dentro de localStorage y JSON editable (límite 2 MB vigente). Adjuntar una foto a un proyecto ya abierto no altera sus tramos, conexiones o gas: marca cambios y se conserva solo al pulsar Guardar. Incluir anexo fotográfico dentro del mismo PDF, tanto jsPDF descargado/compartido como impresión y visor. No subir al servidor para adjuntar; reconocimiento visual sigue siendo online solo al pulsar Analizar. Fotos ausentes de proyectos antiguos no se reconstruyen. Los fallos de cuota no borran proyectos. Fórmulas y limites originales intactos; sin publicación.

### Pantalla más compacta: conexiones y gas

Eliminar solo textos auxiliares repetidos de la pantalla principal: insignia de tipo de tramo, ayuda de potencia y título «Alimentado desde», manteniendo valores/conexiones/controles y avisos de error. Menús cortos «Lineal/Ramificada» y «Auto/Principal/Derivación/Final» representan exactamente las mismas opciones anteriores. Ocultar el título visual Tipo de gas (conservar nombre accesible), reducir ancho del selector al 50% de su ancho actual y abreviar la opción a «GLP · 150 Pa» para que quepa; GN conserva «Gas natural · 120 Pa». No reducir letra/altura ni modificar GAS o límites, algoritmos, PDF, foto y proyectos. Regenerar versión offline, verificar y guardar sin publicar.
