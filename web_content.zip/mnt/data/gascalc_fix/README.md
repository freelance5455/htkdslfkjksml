# Hormazabal Gascalc — calculadora compacta

## Vista previa

Desde el directorio del proyecto, iniciar `node server/index.mjs`. Sirve en `0.0.0.0:3000` (o el puerto indicado por `PORT`). No necesita instalar paquetes. No usar el servidor estático Python para la opción de foto: no ofrece la API de análisis.

## Plano por foto

«Subir foto del plano» permite elegir una imagen JPG/PNG/WebP y leer sus datos. La revisión, transcripción manual y creación de copia son locales. «Analizar foto» requiere internet y las variables de servicio inyectadas por el proyecto (`MANUS_API_URL`/`MANUS_API_KEY`, con aliases compatibles). No poner credenciales en JavaScript del navegador. El servidor no archiva la foto; se envía una copia reencodificada al servicio de visión solo después de pulsar Analizar.

Los datos inciertos quedan pendientes. Antes de crear una copia, revisar gas, conexiones/origen, unidades, potencias terminales/transportadas, metros efectivos, material cobre Tipo L y alcance de presión menor a 10 kPa. La IA no calcula diámetros ni modifica parámetros. Se valida el árbol y las discrepancias entre cargas de matriz y suma terminal. Cambiar de foto, pasar a manual o cerrar invalida operaciones anteriores.

«Llevar a pantalla y calcular» coloca todos los tramos revisados en el editor principal, activa Automático y conserva la lectura del plano en un apartado plegable. Una copia JPEG de la foto puede guardarse localmente con el proyecto y en el archivo editable; no se archiva en el servidor.

Para un proyecto existente: abrirlo en Proyectos, pulsar PDF → Adjuntar foto al PDF, seleccionar la imagen y cerrar la vista para pulsar Guardar. Esto actualiza solo el proyecto abierto; adjuntar no modifica los tramos ni ejecuta reconocimiento visual. El PDF descargado, compartido o impreso incluye la foto completa en una hoja de anexo. La foto reaparece al abrir el proyecto sin red. Si no cabe en el almacenamiento del navegador, el guardado informa el error y conserva los proyectos anteriores; se puede descargar una copia. Los proyectos antiguos sin imagen requieren adjuntarla una vez. Cerrar/reabrir el visor invalida una foto aún en preparación.

## Sin conexión y datos

Después de primera carga completa online, la PWA permite cálculo, edición, proyectos, archivos y PDF offline; el reconocimiento visual no funciona sin red, pero la foto y transcripción manual sí. Para regenerar la versión de caché: `node scripts/build-offline.mjs`. No borrar localStorage ni cachés fuera del mecanismo de actualización existente. Los proyectos se guardan por origen en el navegador y no se trasladan entre enlaces.

## Publicación

La entrega híbrida está declarada en la configuración del mismo proyecto y `Dockerfile`; no se ha publicado esta edición. Los últimos cambios se guardaron en commits locales: una publicación/checkpoint canónico requiere el flujo autorizado del proyecto, no basta el commit local. No empujar a main si la publicación automática está habilitada y el usuario no autoriza publicar.

## Red por nodos A-B (actualización 2026-11-02)
- Los tramos se identifican por nodos de inicio y término: A-B, B-C, B-D, etc.
- La Matriz transporta automáticamente la suma de todos los consumos aguas abajo.
- Derivación representa un arranque terminal desde la Matriz.
- Matriz final representa el último tramo de la Matriz y admite el consumo terminal.
- Caso de prueba del dibujo del usuario: A-B 12 m; B-C 8 m/30 Mcal/h; B-D 10 m/30; B-E 11 m; E-F 10 m/25; E-G 7 m/8; E-H 8 m; H-I 6 m/8; H-J 10 m/25 (Matriz final). Cargas automáticas: A-B 126, B-E 66, E-H 41, H-J 25 Mcal/h.

## Caso de regresión · dibujo A–J (2026-11-02)
La red A-B / B-C / B-D / B-E / E-F / E-G / E-H / H-I / H-J se usa como prueba de la suma automática de cargas. Con los consumos terminales 30, 30, 25, 8, 8 y 25 Mcal/h, el motor debe obtener A-B=126, B-E=66, E-H=33 y H-J=25 Mcal/h. Los tramos de rol `matrix` no guardan potencia manual; su carga se deriva exclusivamente de sus hijos. El archivo `tests-network-drawing.mjs` ejecuta esta comprobación y el dimensionamiento GN 120 Pa.
