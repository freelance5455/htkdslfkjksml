# Referencias y supuestos técnicos — GasCalc Chile

## Fuentes normativas primarias

- **Decreto Supremo N.º 66, Reglamento de Instalaciones Interiores y Medidores de Gas**, texto consolidado de Ley Chile, versión indicada como vigente al 9 de septiembre de 2026: <https://www.bcn.cl/leychile/navegar?idNorma=263058>.
- **Decreto Supremo N.º 20 de 2008**, modificación al DS 66: reemplaza la Tabla VI por “Propiedades Físicas Referenciales de los Gases” y establece que densidad relativa `d` y PCS deben corresponder al gas efectivamente distribuido: <https://www.bcn.cl/leychile/navegar?idNorma=275296>.
- **Decreto N.º 13 de 2026**, incorporación de requisitos para sistemas de tuberías multicapa; no altera las fórmulas de baja presión ni la Tabla VI: <https://www.bcn.cl/leychile/navegar?idNorma=1226878>.
- Copia del reglamento alojada por la SEC: <https://www.sec.cl/sitio-web/wp-content/uploads/2019/06/DSN66_REGLAMENTO_DE_INSTALACIONES_INTERIORES_Y_MEDIDORES_DE_GAS.pdf>.

## Parámetros y alcance de la aplicación

El modo simple conserva el cálculo f.1 del DS 66 art. 45.2.9 e.1 para presión inferior a 10 kPa. En cada tramo se calcula `Qᵢ = Pᵢ / PCS` con potencia `Pᵢ` en Mcal/h y el PCS de referencia; luego `Δpᵢ = (Qᵢ / (9,65 × 10⁻⁷·⁵ × Kᵢ))² × d × Lᵢ / Dᵢ⁵`, usando `D` en mm, `L` en m, `d` como densidad relativa y `Δp` en Pa. Las pérdidas se suman en el orden de la ruta y se comparan con Tabla VIII: 120 Pa para gas natural y 150 Pa para GLP licuado.

La interfaz acepta potencia en `Mcal/h` o `kW`. Antes de aplicar f.1, los datos en kW se convierten a Mcal/h con `1 kW = 3,6 / 4,184 = 0,86042065 Mcal/h`, usando la caloría termoquímica (`1 cal = 4,184 J`). Al alternar la unidad, también se convierte el número visible para conservar la misma potencia física.

Para mantener la interfaz mínima, los perfiles son fijos y referenciales: gas natural (`d=0,59`, PCS 9,0 Mcal/m³, referencia V/Metropolitana) y GLP licuado (`d=2,0`, PCS 28,6 Mcal/m³). La persona usuaria ya no edita densidad, PCS, material ni presión de regulador. El material es cobre Tipo L. La Tabla IX define K por grupo de diámetro; Tabla XI proporciona los diámetros interiores publicados. La medida 2½″ complementa esa tabla con dimensiones de fabricante, sin atribuirlas a una fila de Tabla XI.

Para 2½″ Tipo L, la [ficha Conmetal](https://conmetalltda.cl/caneria-cobre-2-12-x-6m-l) declara diámetro exterior 66,675 mm y espesor 2,032 mm, bajo ASTM B88/NCh 951. Se obtiene diámetro interior 62,611 mm mediante `66,675 − 2 × 2,032`; se emplean 62,61 mm, con la precisión de los otros diámetros de la calculadora. [Taylor Walraven](https://taylorwalraven.ca/copper-tubing-data-Type-L.php) corrobora exterior 2,625″ y pared 0,080″. Se utiliza K=2.160 del grupo 2″ a 2½″ de Tabla IX, cuya [reproducción visual](https://modulor.cl/static/img/especialidades/gas/34816.jpg) se consultó el 10 de octubre de 2026. La selección y el PDF muestran la procedencia; debe comprobarse la dimensión y certificación de la cañería real, no aplicarla a acero, cobre M/K u otra serie.

Esta versión no ingresa altura ni aplica el término e.2; por tanto, no debe utilizarse para desniveles verticales superiores a 10 m, gases cuyas propiedades difieren de los perfiles, otros materiales o cálculos que requieran compensación. La ruta se representa en serie, sin derivaciones; la potencia de cada fila es la carga que continúa circulando por ese tramo. Los metros ingresados deben contemplar accesorios según el proyecto; no se convierten automáticamente. La app no certifica ni reemplaza la revisión de un instalador autorizado SEC.

## Privacidad

Propietario y dirección solo se usan en la sesión visible. No se transmiten ni guardan automáticamente.

## Selección automática de medidas comerciales

La opción automática conserva la fórmula, perfiles, K y diámetros anteriores. El DS 66 art. 45.2.9 establece atender la demanda máxima, considerar longitud/accesorios y no exceder la pérdida admisible entre abastecimiento y artefacto. La selección automática comprueba la **suma sin redondear** de la ruta completa contra el límite del gas seleccionado (120 Pa GN, 150 Pa GLP), no 120/150 Pa independientes para cada tramo. Primero aumenta medidas comerciales hasta obtener una combinación admisible y después reduce medidas cuando esa suma lo permite; es una búsqueda determinista de una combinación factible, no un óptimo global económico ni un algoritmo prescrito por el reglamento. Si incluso todas las medidas de 4″ exceden el límite, muestra el exceso y no afirma cumplimiento.

El usuario debe ingresar en cada tramo la carga efectivamente transportada, no asumir que las filas son artefactos independientes; las longitudes deben incluir la consideración de accesorios y el recorrido sigue sin derivaciones. No se determina presión mínima de entrada del artefacto, certificación, trazado real, desnivel ni propiedades específicas del suministro. La factibilidad por pérdida de este modelo referencial no demuestra el cumplimiento integral de la instalación. Guardados previos sin modo automático se conservan manuales. Fuentes revisadas el 16 de octubre de 2026: https://www.bcn.cl/leychile/navegar?idNorma=263058 y https://modulor.cl/especialidades/gas/capitulo-06-construccion-tuberias-de-gas/.

### Margen y tramos reales

La búsqueda de una combinación comercial más cercana al límite modifica únicamente las medidas propuestas. La longitud y potencia introducidas no se alteran. No se añaden secciones para forzar una pérdida: con igual flujo y diámetro, dividir una longitud conserva la suma de la pérdida lineal; si se instala una transición de diámetro, el trazado, sus longitudes y accesorios deben ser reales y contemplados en el proyecto. La combinación más cercana encontrada puede dejar margen, porque las medidas comerciales son discretas. Una búsqueda acotada en redes grandes no garantiza óptimo global. Estar cerca del máximo no es una exigencia normativa ni elimina la necesidad de margen y revisión del suministro real.

## Matriz y arranques en baja presión

El DS66 art.45.2.9 a/b/c/d exige abastecer máxima demanda y controlar la pérdida desde abastecimiento hasta cada artefacto. La reproducción textual [del capítuloVI](https://modulor.cl/especialidades/gas/capitulo-06-construccion-tuberias-de-gas/) consultada el16/10/2026 reproduce b.2: factor de simultaneidad base1,0; b.3/b.4 contemplan otras condiciones justificadas que no se implementan aquí. También exige presión de alimentación al artefacto mayor que su mínima requerida, además del límite de TablaVIII. La página [LeyChile DS66](https://www.bcn.cl/leychile/navegar?idNorma=263058) fue consultada; su extracción automática en esta sesión devolvió índice y no el articulado, por lo que no se atribuye a ese extracto el contenido completo de b/c/d.

El modo ramificado suma demandas máximas terminales aguas abajo en las secciones comunes; no agrega un consumo adicional a una matriz ni suma pérdidas de ramas hermanas. Aplica los mismos perfiles fijos de gas y cobre, límites120/150Pa y f.1 para presión<10kPa del modelo anterior. Cada camino origen→terminal debe cumplir por separado. La selección adopta diámetros no crecientes aguas abajo; esto no fuerza reducir cada sección ni demuestra óptimo de costo. Las etiquetas Matriz/Arranque son identificación del árbol introducido, no una clasificación ni un algoritmo impuesto por el reglamento. No sirve para redes en anillo, múltiples regulaciones/suministros, matrices de otro régimen de presión, cálculo multivivienda con factores especiales, desniveles>10m ni otras propiedades. Longitudes/accesorios, presión disponible y mínima de artefactos, trazado/certificación requieren revisión de instalador autorizado; no se declaran certificados a partir de una etiqueta o de un diámetro.
