# Ma Annapurna Health Center

Simple offline-first clinic patient management prototype.

Features:
- Patient add/search
- New vs Repeat patient
- Visit history and Add Visit
- Dashboard and daily/monthly report
- Clinic timings
- Data saved in browser localStorage

For a real clinic deployment, add a secure backend/database and authentication before storing real patient records.
