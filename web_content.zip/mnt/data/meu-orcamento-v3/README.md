# Meu Orçamento v3

Aplicativo financeiro pessoal offline, com:
- Dashboard, gráficos, análise e comparação mensal
- Contas/carteiras, cartões de crédito, faturas e limite
- Metas, orçamento por categoria e visão do futuro (60 dias)
- Lançamentos recorrentes e sugestão automática de categoria
- Busca/edição/exclusão, calendário e relatórios
- Exportação CSV/PDF
- Backup normal e backup criptografado AES-GCM com PBKDF2
- PIN, biometria nativa no APK Android e proteção contra capturas
- Sem conta, servidor ou anúncios

## Gerar APK no celular

Este pacote contém um projeto Android nativo. Abra a pasta no AndroidIDE ou em outro IDE Android que suporte projetos Gradle, sincronize o Gradle e gere `app > assembleDebug`.

A biometria é feita pela API nativa `android.hardware.biometrics.BiometricPrompt`. O usuário precisa ter digital/rosto cadastrado no Android.

O `index.html` também pode ser usado sozinho como PWA/HTML offline, mas a biometria nativa e a proteção de captura dependem do APK nativo.
