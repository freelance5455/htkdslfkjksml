package com.meuorcamento.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.Context;
import android.view.Window;
import android.webkit.*;
import android.widget.Toast;
import android.hardware.biometrics.BiometricPrompt;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.security.KeyStore;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class MainActivity extends Activity {
  WebView web; Executor executor;
  @Override public void onCreate(Bundle b){super.onCreate(b);requestWindowFeature(Window.FEATURE_NO_TITLE);
    web=new WebView(this); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);web.addJavascriptInterface(new NativeBridge(this),"AndroidNative");setContentView(web);web.loadUrl("file:///android_asset/index.html");executor=Executors.newSingleThreadExecutor();}
  public void biometric(){if(Build.VERSION.SDK_INT<28){toast("Biometria requer Android 9 ou superior.");return;}try{
    KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);String alias="MeuOrcamentoBio";
    if(!ks.containsAlias(alias)){KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");kg.init(new KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setUserAuthenticationRequired(true).build());kg.generateKey();}
    SecretKey key=(SecretKey)ks.getKey(alias,null);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key);
    BiometricPrompt prompt=new BiometricPrompt.Builder(this).setTitle("Meu Orçamento").setSubtitle("Confirme sua identidade").setDescription("Use a biometria cadastrada no aparelho para desbloquear o app").setNegativeButton("Usar PIN",executor,(d,w)->{}).build();
    prompt.authenticate(new BiometricPrompt.CryptoObject(cipher),executor,new BiometricPrompt.AuthenticationCallback(){@Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r){runOnUiThread(()->web.evaluateJavascript("window.onNativeBiometric(true)",null));}@Override public void onAuthenticationFailed(){runOnUiThread(()->web.evaluateJavascript("window.onNativeBiometric(false)",null));}@Override public void onAuthenticationError(int e,CharSequence m){runOnUiThread(()->web.evaluateJavascript("window.onNativeBiometric(false)",null));}});
  }catch(Exception e){toast("Biometria indisponível: cadastre uma digital/rosto nas configurações do Android.");runOnUiThread(()->web.evaluateJavascript("window.onNativeBiometric(false)",null));}}
  void toast(String x){runOnUiThread(()->Toast.makeText(this,x,Toast.LENGTH_LONG).show());}
  public class NativeBridge{Context c;NativeBridge(Context x){c=x;}@JavascriptInterface public void authenticateBiometric(){biometric();}@JavascriptInterface public void setSecureFlag(boolean on){runOnUiThread(()->{if(on)getWindow().addFlags(8192);else getWindow().clearFlags(8192);});}}
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
