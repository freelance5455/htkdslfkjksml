# CBA AI — Gemini əsaslı web köməkçi

## Başlatmaq
1. ZIP-i çıxart.
2. `index.html` faylını Chrome-da aç. Daha etibarlı mikrofon icazələri üçün layihəni localhost üzərindən açmaq tövsiyə olunur.
3. Google AI Studio-dan Gemini API açarı yarat: https://aistudio.google.com/app/apikey
4. CBA AI-də ⚙ düyməsinə bas, API açarını daxil et və modeli seç.
5. Mikrofon icazəsi verərək səsli rejimi yoxla.

## Lokal server (kompüterdə)
Layihə qovluğunda terminal aç:
```bash
python -m http.server 8000
```
Sonra brauzerdə `http://localhost:8000` aç.

## Daxil olanlar
- Videoya uyğun qırmızı hissəcik kürəsi
- Gemini yazılı çat və sessiya daxilində söhbət konteksti
- Brauzer Speech Recognition ilə səsdən mətnə
- Speech Synthesis ilə cavabı səsləndirmə
- Azərbaycan, türk, ingilis və rus dili seçimi
- Controls & Specs və Auto Mission
- Mobilə uyğun görünüş

## Vacib təhlükəsizlik qeydləri
Bu prototip Gemini API-yə brauzerdən birbaşa sorğu göndərir. API açarı serverdə saxlanmır, localStorage/cookie-yə yazılmır və səhifə bağlananda yaddaşdan silinir. Bununla belə, brauzer DevTools və şəbəkə sorğularında açar görünə bilər. Şəxsi və ya ictimai yayımlanacaq layihədə API açarını backend proxy/serverless function arxasında saxla, istifadə limitləri və autentifikasiya əlavə et. API açarını heç vaxt GitHub-a yükləmə.

Səs tanıma dəstəyi brauzerdən asılıdır; Chrome/Chromium tövsiyə olunur. Bu ilkin versiya real vaxt tam-dupleks Gemini Live deyil: danışığı brauzer tanıyır, mətni Gemini-yə göndərir, cavabı cihazın TTS-i oxuyur. Şəkil generasiyası ayrıca uyğun Gemini image model/API inteqrasiyası tələb edir.
