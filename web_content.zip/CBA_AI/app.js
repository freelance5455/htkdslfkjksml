const $ = (id) => document.getElementById(id);
let apiKey = "";
let model = "gemini-2.5-flash";
let chat = [];
let recognition = null;
let listening = false;
let speaking = false;
let speechEnabled = true;
let autoListen = false;
let language = "az-AZ";
let animationEnabled = true;

function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
function openModal(id){$(id).classList.remove("hidden")}
function closeModal(id){$(id).classList.add("hidden")}
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>closeModal(b.dataset.close)));
$("settingsBtn").onclick=()=>openModal("settingsModal");
$("controlsBtn").onclick=()=>openModal("controlsModal");
$("historyBtn").onclick=()=>{showChat();toast(chat.length?"Bu sessiyanın mesajları açıqdır":"Hələ söhbət yoxdur")};
$("modeBtn").onclick=showChat;$("keyboardBtn").onclick=showChat;$("voiceFromChat").onclick=showVoice;
$("homeBtn").onclick=showVoice;
function showChat(){$("voiceView").classList.add("hidden");$("chatView").classList.remove("hidden");$("modeBtn").textContent="◉";$("promptInput").focus()}
function showVoice(){$("chatView").classList.add("hidden");$("voiceView").classList.remove("hidden");$("modeBtn").textContent="▤"}
$("saveSettings").onclick=()=>{apiKey=$("apiKey").value.trim();model=$("modelSelect").value;$("settingsStatus").textContent=apiKey?"Açar bu sessiya üçün hazırdır.":"API açarı daxil edilməyib.";toast(apiKey?"Gemini ayarları yadda saxlanıldı":"API açarını daxil et")};
$("speechToggle").onchange=e=>speechEnabled=e.target.checked;
$("autoListenToggle").onchange=e=>autoListen=e.target.checked;
$("animationToggle").onchange=e=>{animationEnabled=e.target.checked;$("particles").style.opacity=animationEnabled?"1":"0"};
$("languageSelect").onchange=e=>language=e.target.value;

function addMessage(role,text){const box=$("messages");const welcome=box.querySelector(".welcome-card");if(welcome)welcome.remove();const el=document.createElement("div");el.className="message "+role;if(role==="ai"){const tag=document.createElement("span");tag.className="tag";tag.textContent="CBA AI";el.appendChild(tag)}const body=document.createElement("div");body.textContent=text;el.appendChild(body);box.appendChild(el);box.scrollTop=box.scrollHeight;return el}
function setStatus(s){$("statusText").textContent=s;$("voiceCaption").textContent=s}
async function askGemini(prompt,fromVoice=false){
 if(!apiKey){openModal("settingsModal");toast("Əvvəl Gemini API açarını daxil et");return}
 const userText=prompt.trim();if(!userText)return;
 if(!fromVoice)addMessage("user",userText);
 chat.push({role:"user",parts:[{text:userText}]});
 const loading=fromVoice?null:addMessage("ai","Cavab hazırlanır…");
 if(loading)loading.querySelector("div:last-child").classList.add("typing");
 try{
  const url=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;
  const contents=chat.slice(-24);
  const response=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({system_instruction:{parts:[{text:"Sən CBA AI adlı faydalı, nəzakətli və ağıllı Azərbaycan dilli köməkçisən. İstifadəçi başqa dildə yazarsa həmin dildə cavab ver. Cavabları aydın və faydalı yaz."}]},contents,generationConfig:{temperature:0.7,maxOutputTokens:2048}})});
  const data=await response.json();
  if(!response.ok)throw new Error(data.error?.message||`Gemini xətası: ${response.status}`);
  const answer=data.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("").trim()||"Cavab alınmadı.";
  chat.push({role:"model",parts:[{text:answer}]});
  if(loading)loading.querySelector("div:last-child").textContent=answer;
  $("transcript").textContent=answer;
  if(speechEnabled)speak(answer);
  setStatus("CBA AI cavab verdi");
 }catch(err){if(loading)loading.querySelector("div:last-child").textContent="Xəta: "+err.message;toast(err.message);setStatus("Bağlantı xətası")}
}
function speak(text){if(!("speechSynthesis"in window))return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang=language;u.rate=1;u.onstart=()=>speaking=true;u.onend=()=>{speaking=false;if(autoListen)startListening()};speechSynthesis.speak(u)}
$("chatForm").addEventListener("submit",e=>{e.preventDefault();const v=$("promptInput").value;$("promptInput").value="";askGemini(v)});
$("promptInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();$("chatForm").requestSubmit()}});
$("newChatBtn").onclick=()=>{chat=[];$("messages").innerHTML='<div class="welcome-card"><div class="welcome-orb">✦</div><h2>Salam! Mən CBA AI-yam.</h2><p>Gemini ilə işləyən şəxsi süni intellekt köməkçin.</p></div>';toast("Yeni söhbət başladı")};
$("missionBtn").onclick=()=>{showChat();$("promptInput").value="Mənim üçün gündəlik işlərimə kömək edən ağıllı missiya planı hazırla."; $("promptInput").focus()};
function setupRecognition(){
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){toast("Bu brauzer səs tanımanı dəstəkləmir. Chrome istifadə et.");return null}
 const r=new SR();r.lang=language;r.interimResults=true;r.continuous=false;
 r.onstart=()=>{listening=true;$("micBtn").classList.add("listening");setStatus("Səni dinləyirəm…")};
 r.onresult=e=>{let final="",interim="";for(let i=e.resultIndex;i<e.results.length;i++){if(e.results[i].isFinal)final+=e.results[i][0].transcript;else interim+=e.results[i][0].transcript}$("transcript").textContent=final||interim;if(final){setStatus("Cavab hazırlanır…");askGemini(final,true)}};
 r.onerror=e=>{listening=false;$("micBtn").classList.remove("listening");setStatus("Mikrofon xətası: "+e.error)};
 r.onend=()=>{listening=false;$("micBtn").classList.remove("listening");if(!speaking)setStatus("CBA AI hazırdır")};
 return r;
}
function startListening(){if(listening)return;if(!recognition)recognition=setupRecognition();if(recognition){recognition.lang=language;try{recognition.start()}catch(e){toast("Mikrofon artıq aktivdir")}}}
$("micBtn").onclick=()=>{if(listening){recognition.stop()}else startListening()};
$("stopBtn").onclick=()=>{if(recognition&&listening)recognition.stop();if("speechSynthesis"in window)speechSynthesis.cancel();speaking=false;setStatus("CBA AI hazırdır")};

// Procedural crimson particle orb
const canvas=$("particles"),ctx=canvas.getContext("2d");let W=0,H=0,particles=[];
function resize(){const r=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);W=r.width;H=r.height;canvas.width=W*dpr;canvas.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);particles=Array.from({length:1250},()=>{const a=Math.random()*Math.PI*2,rad=Math.sqrt(Math.random())*.47;return{x:W/2+Math.cos(a)*rad*W,y:H/2+Math.sin(a)*rad*H*.8,z:Math.random(),a,rad,seed:Math.random()*9}})}
function draw(t){ctx.clearRect(0,0,W,H);if(animationEnabled){const cx=W/2,cy=H/2,scale=1+Math.sin(t*.0008)*.025;for(const p of particles){const pulse=Math.sin(t*.001+p.seed)*2;const x=cx+(p.x-cx)*scale+Math.sin(t*.0004+p.seed)*3;const y=cy+(p.y-cy)*scale+Math.cos(t*.0005+p.seed)*3;const dist=Math.hypot(x-cx,y-cy)/(W*.48);const alpha=Math.max(.08,(1-dist)*(.25+p.z*.65));ctx.beginPath();ctx.fillStyle=`rgba(255,${Math.floor(15+p.z*35)},${Math.floor(35+p.z*55)},${alpha})`;ctx.arc(x,y,.45+p.z*1.5+pulse*.08,0,Math.PI*2);ctx.fill()}}
 requestAnimationFrame(draw)}
new ResizeObserver(resize).observe(canvas);resize();requestAnimationFrame(draw);
window.addEventListener("beforeunload",()=>{apiKey="";if("speechSynthesis"in window)speechSynthesis.cancel()});
