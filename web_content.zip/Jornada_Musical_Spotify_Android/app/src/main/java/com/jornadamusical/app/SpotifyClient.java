package com.jornadamusical.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Base64;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;

public final class SpotifyClient {
  public static final String REDIRECT = "jornadamusical://callback";
  private static final String STORE = "spotify_auth";
  public static SharedPreferences prefs(Context c) { return c.getSharedPreferences(STORE, Context.MODE_PRIVATE); }
  private static String enc(String s) { return Uri.encode(s); }
  public static String authorizationUrl(Context c, String clientId) throws Exception {
    byte[] random = new byte[48]; new SecureRandom().nextBytes(random);
    String verifier=Base64.encodeToString(random,Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);
    byte[] hash=MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII));
    String challenge=Base64.encodeToString(hash,Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);
    byte[] nonce = new byte[16]; new SecureRandom().nextBytes(nonce);
    String state=Base64.encodeToString(nonce,Base64.URL_SAFE|Base64.NO_WRAP|Base64.NO_PADDING);
    prefs(c).edit().putString("client_id",clientId).putString("verifier",verifier).putString("state",state).apply();
    return "https://accounts.spotify.com/authorize?response_type=code&client_id="+enc(clientId)+"&redirect_uri="+enc(REDIRECT)+"&scope="+enc("user-modify-playback-state user-read-playback-state")+"&code_challenge_method=S256&code_challenge="+enc(challenge)+"&state="+enc(state);
  }
  private static String request(String method,String address,String body,String bearer) throws Exception {
    HttpURLConnection con=(HttpURLConnection)new URL(address).openConnection();
    con.setConnectTimeout(15000); con.setReadTimeout(15000); con.setRequestMethod(method);
    if(bearer != null) con.setRequestProperty("Authorization","Bearer "+bearer);
    if(body != null) {con.setDoOutput(true);con.setRequestProperty("Content-Type", address.contains("/api/token")?"application/x-www-form-urlencoded":"application/json");try(OutputStream os=con.getOutputStream()){os.write(body.getBytes(StandardCharsets.UTF_8));}}
    int code=con.getResponseCode();
    String result=""; InputStream is=code<400?con.getInputStream():con.getErrorStream();
    if(is!=null) try(InputStream i=is){result=new String(i.readAllBytes(), StandardCharsets.UTF_8);}
    con.disconnect();
    if(code<200 || code>=300)throw new IOException("Spotify HTTP "+code+": "+result);
    return result;
  }
  public static void exchange(Context c, String code, String state) throws Exception {
    SharedPreferences sp=prefs(c);
    if(!state.equals(sp.getString("state","")))throw new IOException("Estado de autorización inválido");
    String body="grant_type=authorization_code&code="+enc(code)+"&redirect_uri="+enc(REDIRECT)+"&client_id="+enc(sp.getString("client_id",""))+"&code_verifier="+enc(sp.getString("verifier",""));
    writeTokens(c,new JSONObject(request("POST","https://accounts.spotify.com/api/token",body,null)));
  }
  private static void writeTokens(Context c, JSONObject o){
    SharedPreferences sp=prefs(c);
    SharedPreferences.Editor e=sp.edit().putString("access_token",o.optString("access_token")).putLong("expiry",System.currentTimeMillis()+Math.max(60,o.optInt("expires_in",3600)-90)*1000L);
    if(o.has("refresh_token"))e.putString("refresh_token",o.optString("refresh_token"));
    e.apply();
  }
  private static synchronized String token(Context c) throws Exception {
    SharedPreferences sp=prefs(c); String a=sp.getString("access_token","");
    if(a.isEmpty())throw new IOException("Conecta primero tu Spotify Premium");
    if(System.currentTimeMillis() < sp.getLong("expiry",0)) return a;
    String refresh=sp.getString("refresh_token","");
    if(refresh.isEmpty())throw new IOException("Es necesario conectar Spotify de nuevo");
    String body="grant_type=refresh_token&refresh_token="+enc(refresh)+"&client_id="+enc(sp.getString("client_id",""));
    writeTokens(c,new JSONObject(request("POST","https://accounts.spotify.com/api/token",body,null)));
    return prefs(c).getString("access_token","");
  }
  public static void play(Context c, String uri) throws Exception {
    // Requires an already active Spotify playback device. Do not silently claim success.
    if(!uri.startsWith("spotify:playlist:"))throw new IOException("Usa enlaces de playlists de Spotify");
    JSONObject payload=new JSONObject();payload.put("context_uri",uri);
    request("PUT","https://api.spotify.com/v1/me/player/play",payload.toString(),token(c));
  }
  public static String playlistUri(String input) {
    if(input==null)return "";
    String t=input.trim();
    if(t.matches("spotify:playlist:[A-Za-z0-9]+"))return t;
    Uri u=Uri.parse(t);String path=u.getPath();
    if(!"open.spotify.com".equalsIgnoreCase(u.getHost())||path==null)return "";
    String[] parts=path.split("/");
    for(int i=1;i<parts.length-1;i++)if(parts[i].equals("playlist")&&parts[i+1].matches("[A-Za-z0-9]+"))return "spotify:playlist:"+parts[i+1];
    return "";
  }
}
