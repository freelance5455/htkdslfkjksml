package com.jornadamusical.app;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;
import org.json.*;
import java.util.concurrent.*;

public class JornadaService extends Service {
  private final ScheduledExecutorService worker=Executors.newSingleThreadScheduledExecutor();
  private static final String CHANNEL="jornada_activa";
  private volatile boolean running=false; private int lastSegment=-1;
  private long started;private int total,work,pause;private String playlist;private String[] breaks;
  private static final String PREF="robot_runtime";
  public static String status(Context c){return c.getSharedPreferences(PREF,MODE_PRIVATE).getString("status","{\"phase\":\"Listo\",\"remaining\":0,\"nextRest\":0,\"message\":\"\"}");}
  private void writeStatus(String phase,long remaining,long nextRest,String message){
    try{JSONObject o=new JSONObject();o.put("phase",phase);o.put("remaining",remaining);o.put("nextRest",nextRest);o.put("message",message);
      getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("status",o.toString()).apply();}
    catch(Exception ignored){}
  }
  @Override public void onCreate(){super.onCreate();NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Jornada Musical",NotificationManager.IMPORTANCE_LOW));
  }
  private Notification notification(String line){Intent i=new Intent(this,MainActivity.class);PendingIntent p=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    Intent stop=new Intent(this,JornadaService.class).setAction("STOP");PendingIntent ps=PendingIntent.getService(this,1,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    return new Notification.Builder(this,CHANNEL).setContentTitle("Jornada Musical").setContentText(line).setSmallIcon(android.R.drawable.ic_media_play)
      .setContentIntent(p).addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"Detener",ps).build()).setOngoing(true).build();
  }
  @Override public int onStartCommand(Intent in,int flags,int id){
    if(in!=null&&"STOP".equals(in.getAction())){running=false;writeStatus("Listo",0,0,"Detenida");stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY;}
    if(running)return START_STICKY;
    try{
      JSONObject cfg=new JSONObject(getSharedPreferences("config",MODE_PRIVATE).getString("json","{}"));
      total=cfg.optInt("hours",8)*3600; work=cfg.optInt("work",120)*60; pause=cfg.optInt("pause",30)*60;
      playlist=SpotifyClient.playlistUri(cfg.optString("playlist"));
      JSONArray arr=cfg.optJSONArray("breaks");if(arr==null)arr=new JSONArray();
      java.util.ArrayList<String> valid=new java.util.ArrayList<>();for(int j=0;j<arr.length();j++){String s=SpotifyClient.playlistUri(arr.optString(j));if(!s.isEmpty())valid.add(s);}
      breaks=valid.toArray(new String[0]);
      if(playlist.isEmpty()||total<=0||work<=0||pause<=0)throw new Exception("Configuración inválida");
      started=SystemClock.elapsedRealtime();lastSegment=-1;running=true;
      if(Build.VERSION.SDK_INT>=29)startForeground(1,notification("Jornada iniciada"),ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
      else startForeground(1,notification("Jornada iniciada"));
      worker.scheduleAtFixedRate(this::step,0,1,TimeUnit.SECONDS);
      return START_STICKY;
    }catch(Exception e){writeStatus("Error",0,0,e.getMessage());stopSelf();return START_NOT_STICKY;}
  }
  private void step(){if(!running)return;
   long elapsed=(SystemClock.elapsedRealtime()-started)/1000L;
   if(elapsed>=total){running=false;writeStatus("Finalizado",0,0,"Jornada completada");stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return;}
   long t=elapsed;int idx=0;boolean isBreak=false;long rem=0,nextRest=0;int breakNum=0;long consumed=0;
   while(true){long remainingDay=total-consumed;long duration=Math.min(isBreak?pause:work,remainingDay);
     if(t<duration){rem=duration-t;nextRest=isBreak?0:rem;break;}
     t-=duration;consumed+=duration;if(!isBreak)breakNum++;isBreak=!isBreak;idx++;
   }
   String phase=isBreak?"Descanso":"Trabajo";String message="";
   if(idx!=lastSegment){lastSegment=idx;String target=isBreak?(breaks.length==0?playlist:breaks[(breakNum-1)%breaks.length]):playlist;
     try{SpotifyClient.play(this,target);message="Playlist de "+phase.toLowerCase()+" activada";}
     catch(Exception e){message="No se pudo cambiar Spotify: "+e.getMessage();}
     // Retain errors; the user should see them rather than assume automatic playback worked.
     getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("last_message",message).apply();
   }else{message=getSharedPreferences(PREF,MODE_PRIVATE).getString("last_message","");}
   writeStatus(phase,rem,nextRest,message);
   if(rem % 30 == 0){NotificationManager n=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);n.notify(1,notification(phase+" · quedan "+(rem/60)+" min"));}
  }
  @Override public void onDestroy(){running=false;worker.shutdownNow();super.onDestroy();}
  @Override public IBinder onBind(Intent i){return null;}
}
