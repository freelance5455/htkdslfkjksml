package com.jornadamusical.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;

public class MainActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle b){super.onCreate(b);
   if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
      requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},42);
   web=new WebView(this);setContentView(web);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
   web.setWebViewClient(new WebViewClient());web.addJavascriptInterface(new Bridge(),"Robot");
   web.loadUrl("file:///android_asset/index.html");handleIntent(getIntent());
 }
 @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);handleIntent(intent);}
 private void result(String message){runOnUiThread(()->web.evaluateJavascript("window.nativeMessage("+JSONObject.quote(message)+")",null));}
 private void handleIntent(Intent in){Uri uri=in.getData();if(uri==null||!"jornadamusical".equals(uri.getScheme()))return;
   String code=uri.getQueryParameter("code"),state=uri.getQueryParameter("state");
   if(code==null){result("Spotify: autorización cancelada o rechazada");return;}
   new Thread(()->{try{SpotifyClient.exchange(this,code,state==null?"":state);result("Spotify conectado. Abre Spotify y reproduce una canción para activar el teléfono antes de iniciar la jornada.");}
   catch(Exception e){result("Error al conectar: "+e.getMessage());}}).start();
 }
 public class Bridge {
  @JavascriptInterface public String saved(){return getSharedPreferences("config",MODE_PRIVATE).getString("json","{}");}
  @JavascriptInterface public boolean connected(){return !SpotifyClient.prefs(MainActivity.this).getString("access_token","").isEmpty();}
  @JavascriptInterface public void save(String json){getSharedPreferences("config",MODE_PRIVATE).edit().putString("json",json).apply();}
  @JavascriptInterface public void connect(String clientId){runOnUiThread(()->{try{String url=SpotifyClient.authorizationUrl(MainActivity.this,clientId.trim());startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}
    catch(Exception e){result("No se pudo iniciar la conexión: "+e.getMessage());}});}
  @JavascriptInterface public void start(String json){
    try{JSONObject o=new JSONObject(json);int total=o.optInt("hours"),work=o.optInt("work"),pause=o.optInt("pause");
      if(total<1||total>24||work<5||pause<2||SpotifyClient.playlistUri(o.optString("playlist")).isEmpty())throw new Exception("Revisa el horario y la playlist de trabajo");
      getSharedPreferences("config",MODE_PRIVATE).edit().putString("json",json).apply();
      Intent i=new Intent(MainActivity.this,JornadaService.class);i.setAction("START");
      if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
      result("Jornada iniciada. El cambio de Spotify requiere un dispositivo activo y autorización válida.");
    }catch(Exception e){result("No se inició: "+e.getMessage());}
  }
  @JavascriptInterface public void stop(){Intent i=new Intent(MainActivity.this,JornadaService.class);i.setAction("STOP");startService(i);result("Jornada detenida");}
  @JavascriptInterface public String status(){return JornadaService.status(MainActivity.this);}
 }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){web.destroy();super.onDestroy();}
}
