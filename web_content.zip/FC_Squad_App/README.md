# FC Squad — Android-ready starter

FC Squad is an offline-first FC Mobile scouting tracker.

## Player Tracker
- Tap the green **+** button to create a player entry with a name and position.
- Every player gets their own saved checklist based on that position.
- All created players appear in **Saved players** on the lobby.
- Tap any saved player card to reopen that player's checklist.
- Checklist ticks are saved automatically, including when you close and reopen the report.
- Each player's progress is kept separately. You can add multiple players, and delete one report or clear all reports.

## Build an APK (requires a computer)
1. Install Node.js LTS and Android Studio.
2. Extract this ZIP.
3. Open a terminal in this folder and run:
   `npm install`
   `npx cap add android`
   `npx cap sync android`
   `npx cap open android`
4. In Android Studio, wait for Gradle sync. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location when it finishes.

For later edits, change files inside `www/`, then run `npx cap sync android` again before rebuilding.

## Important about the stat targets
Every checklist row displays an **AVG** reference number for that individual stat and selected position. These are estimated position-specific scouting benchmarks, roughly calibrated using examples of high-OVR cards around the 120-124 OVR range in public player databases. They are not official EA averages, nor mathematically calculated averages across the full player database, and they are not guaranteed minimums. There is no universal minimum for a position: card OVR, rank/training, current game balance, formation and your playstyle matter. Treat them as a starting point and compare players at similar OVR. Compare cards of similar OVR and inspect weak foot, skill moves, work rates, traits and price as well.

## App data
Saved player reports stay on that device using local storage. Each player's checklist is saved independently and updates automatically when you tick or untick a stat. Clearing app data or uninstalling may erase them. No account or server is used.
