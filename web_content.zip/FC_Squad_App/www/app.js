const $=id=>document.getElementById(id);
const profiles={
ST:{groups:[["PACE",["Acceleration",155],["Sprint Speed",155]],["SHOOTING",["Finishing",165],["Shot Power",160],["Attacking Positioning",160],["Volleys",145]],["DRIBBLING",["Ball Control",155],["Dribbling",150],["Reactions",155]],["PHYSICAL",["Strength",155],["Jumping",150],["Heading",150]]]},
CF:{groups:[["PACE",["Acceleration",150],["Sprint Speed",150]],["SHOOTING",["Finishing",160],["Shot Power",155],["Attacking Positioning",160],["Long Shots",155]],["DRIBBLING",["Ball Control",160],["Dribbling",155],["Agility",155],["Reactions",160]],["PASSING",["Short Passing",150],["Vision",150]]]},
LW:{groups:[["PACE",["Acceleration",165],["Sprint Speed",165]],["DRIBBLING",["Dribbling",165],["Ball Control",160],["Agility",160],["Balance",150]],["SHOOTING",["Finishing",150],["Shot Power",150],["Attacking Positioning",150]],["PASSING",["Crossing",145],["Short Passing",145],["Curve",145]]]},
RW:{groups:[["PACE",["Acceleration",165],["Sprint Speed",165]],["DRIBBLING",["Dribbling",165],["Ball Control",160],["Agility",160],["Balance",150]],["SHOOTING",["Finishing",150],["Shot Power",150],["Attacking Positioning",150]],["PASSING",["Crossing",145],["Short Passing",145],["Curve",145]]]},
CAM:{groups:[["DRIBBLING",["Ball Control",160],["Dribbling",155],["Agility",155],["Reactions",160]],["PASSING",["Vision",165],["Short Passing",165],["Long Passing",155],["Curve",150]],["SHOOTING",["Long Shots",155],["Finishing",150],["Shot Power",150]],["PACE",["Acceleration",150],["Sprint Speed",145]]]},
CM:{groups:[["PASSING",["Short Passing",165],["Long Passing",155],["Vision",155]],["DRIBBLING",["Ball Control",150],["Reactions",155],["Dribbling",145]],["DEFENDING",["Defensive Awareness",150],["Interceptions",155],["Standing Tackle",150]],["PHYSICAL",["Stamina",160],["Strength",150]],["PACE",["Acceleration",145],["Sprint Speed",145]]]},
CDM:{groups:[["DEFENDING",["Defensive Awareness",165],["Interceptions",165],["Standing Tackle",165],["Sliding Tackle",150]],["PHYSICAL",["Strength",160],["Aggression",155],["Stamina",160]],["PASSING",["Short Passing",155],["Long Passing",150]],["PACE",["Acceleration",140],["Sprint Speed",140]]]},
LM:{groups:[["PACE",["Acceleration",155],["Sprint Speed",155]],["PASSING",["Crossing",155],["Short Passing",150],["Vision",145]],["DRIBBLING",["Dribbling",155],["Ball Control",150],["Agility",155]],["PHYSICAL",["Stamina",155]],["DEFENDING",["Defensive Awareness",125],["Standing Tackle",120]]]},
RM:{groups:[["PACE",["Acceleration",155],["Sprint Speed",155]],["PASSING",["Crossing",155],["Short Passing",150],["Vision",145]],["DRIBBLING",["Dribbling",155],["Ball Control",150],["Agility",155]],["PHYSICAL",["Stamina",155]],["DEFENDING",["Defensive Awareness",125],["Standing Tackle",120]]]},
LB:{groups:[["DEFENDING",["Defensive Awareness",160],["Standing Tackle",160],["Sliding Tackle",155],["Interceptions",155]],["PACE",["Acceleration",155],["Sprint Speed",155]],["PHYSICAL",["Stamina",160],["Strength",145]],["PASSING",["Short Passing",145],["Crossing",145]]]},
RB:{groups:[["DEFENDING",["Defensive Awareness",160],["Standing Tackle",160],["Sliding Tackle",155],["Interceptions",155]],["PACE",["Acceleration",155],["Sprint Speed",155]],["PHYSICAL",["Stamina",160],["Strength",145]],["PASSING",["Short Passing",145],["Crossing",145]]]},
LWB:{groups:[["PACE",["Acceleration",160],["Sprint Speed",160]],["DEFENDING",["Defensive Awareness",150],["Standing Tackle",150],["Interceptions",145]],["PASSING",["Crossing",155],["Short Passing",145]],["PHYSICAL",["Stamina",165],["Strength",140]]]},
RWB:{groups:[["PACE",["Acceleration",160],["Sprint Speed",160]],["DEFENDING",["Defensive Awareness",150],["Standing Tackle",150],["Interceptions",145]],["PASSING",["Crossing",155],["Short Passing",145]],["PHYSICAL",["Stamina",165],["Strength",140]]]},
CB:{groups:[["DEFENDING",["Defensive Awareness",165],["Marking",160],["Standing Tackle",165],["Interceptions",160],["Heading",160]],["PHYSICAL",["Strength",165],["Jumping",160],["Aggression",155]],["PACE",["Acceleration",140],["Sprint Speed",145]],["PASSING",["Short Passing",140],["Long Passing",140]]]},
GK:{groups:[["GOALKEEPING",["Reflexes",165],["Diving",160],["Handling",155],["GK Positioning",160],["Kicking",145]],["PHYSICAL",["Reactions",155],["Agility",145],["Jumping",145]]]}
}

let players=[];
try { players=JSON.parse(localStorage.getItem('fcSquadPlayers')||'[]'); } catch(e) { players=[]; }
if(!Array.isArray(players)) players=[];
players=players.map(p=>({...p,id:String(p.id||Date.now()+Math.random()),checked:Array.isArray(p.checked)?p.checked:[]}));
let active=null;

function allStats(pos){return profiles[pos].groups.flatMap(g=>g.slice(1).map(s=>s[0]));}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function status(p){let n=allStats(p.pos).length;return p.checked.length===n?'Complete':p.checked.length?'In progress':'Not checked';}
function show(id){$(id).classList.add('show')}
function hide(id){$(id).classList.remove('show')}
function persist(){localStorage.setItem('fcSquadPlayers',JSON.stringify(players));render();}

function render(){
  $('playerCount').textContent=players.length;
  $('countPill').textContent=players.length;
  $('emptyState').style.display=players.length?'none':'flex';
  $('playerList').innerHTML=players.map(p=>{
    const total=allStats(p.pos).length, pct=Math.round(p.checked.length/total*100);
    return `<div class="player-card" role="button" tabindex="0" aria-label="Open ${esc(p.name)} checklist" onclick="openReport('${p.id}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openReport('${p.id}')}">
      <div class="position-badge">${esc(p.pos)}</div>
      <div class="player-info"><b>${esc(p.name)}</b><small>${p.checked.length}/${total} stats checked · ${status(p)}</small></div>
      <div class="player-score">${pct}%</div>
      <div class="player-actions"><button class="mini-btn" onclick="event.stopPropagation();removePlayer('${p.id}')" aria-label="Delete ${esc(p.name)}">×</button></div>
    </div>`;
  }).join('');
}
$('addBtn').onclick=()=>{
  $('playerName').value='';$('position').value='ST';$('playerName').style.borderColor='';
  show('addModal');setTimeout(()=>$('playerName').focus(),100);
};
$('closeModal').onclick=()=>hide('addModal');
$('closeCheck').onclick=()=>{if(active)persist();hide('checkModal');};
$('createBtn').onclick=()=>{
  const name=$('playerName').value.trim(),pos=$('position').value;
  if(!name){$('playerName').focus();$('playerName').style.borderColor='#ff6868';return;}
  const p={id:(Date.now().toString(36)+Math.random().toString(36).slice(2,7)),name,pos,checked:[],createdAt:new Date().toISOString()};
  players.unshift(p);persist();hide('addModal');openReport(p.id);
};
function openReport(id){
  active=players.find(p=>p.id===id);if(!active)return;
  $('checkEyebrow').textContent='SAVED SCOUT REPORT · '+active.pos;
  $('checkTitle').textContent=active.name;
  $('checkPosition').textContent=active.pos;
  let html='';
  profiles[active.pos].groups.forEach(g=>{
    html+=`<div class="group-title">${g[0]}</div>`;
    g.slice(1).forEach(s=>{
      const key=s[0],target=s[1],checked=active.checked.includes(key);
      html+=`<label class="stat-row"><input type="checkbox" data-stat="${esc(key)}" ${checked?'checked':''}><span class="stat-label">${esc(key)}<small>Average reference for ${esc(active.pos)}</small></span><span class="stat-target">AVG ${target}+</span></label>`;
    });
  });
  $('checklistGroups').innerHTML=html;
  $('checklistGroups').querySelectorAll('input').forEach(x=>x.onchange=()=>{
    const k=x.dataset.stat;
    if(x.checked&&!active.checked.includes(k))active.checked.push(k);
    if(!x.checked)active.checked=active.checked.filter(v=>v!==k);
    persist();
    updateProgress();
  });
  updateProgress();show('checkModal');
}
function updateProgress(){
  if(!active)return;
  const total=allStats(active.pos).length,n=active.checked.length,pct=Math.round(n/total*100);
  $('progressText').textContent=`${n} / ${total} checked`;
  $('progressBar').style.width=pct+'%';
  $('verdict').innerHTML=`<b>SCOUTING STATUS</b><span>${pct===100?'Checklist complete':pct>=70?'Looking promising':pct>=35?'Needs more checking':'Not enough info'} · ${pct}%</span>`;
}
$('saveReport').onclick=()=>{if(active)persist();hide('checkModal');};
window.openReport=openReport;
window.removePlayer=id=>{
  if(confirm('Delete this player report? This cannot be undone.')){
    players=players.filter(p=>p.id!==id);
    if(active&&active.id===id){active=null;hide('checkModal');}
    persist();
  }
};
$('clearBtn').onclick=()=>{
  if(players.length&&confirm('Clear all saved player reports? This cannot be undone.')){
    players=[];active=null;hide('checkModal');persist();
  }
};
$('aboutBtn').onclick=()=>show('aboutModal');
$('closeAbout').onclick=$('aboutOkay').onclick=()=>hide('aboutModal');
render();
