# Akshit Stores — Android app project

This Android Studio project wraps your uploaded `index.html` website in an Android WebView. The app display name is **Akshit Stores**.

## Build an APK

1. Install Android Studio on a computer: https://developer.android.com/studio
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the extracted `akshit-stores-android` folder.
4. Allow Gradle sync to finish. If prompted, install Android SDK Platform 35.
5. For a test install: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Android Studio will show a notification with **Locate**. The APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer that APK to your Android phone, open it, and allow installation from that source if Android asks.

## Important notes

- This project contains the website as a local asset, so it does not need a public website URL or internet access to show the storefront.
- Your page describes AKC coins, wallet top-ups, orders, VIP membership, delivery and checkout as **demo simulations**. It does not take real payments or ship products.
- Cart, wishlist and demo data use browser local storage. This is a basic local app wrapper, not a secure customer-account or production e-commerce backend.
- The project source is provided; an APK has not been compiled in this environment.
