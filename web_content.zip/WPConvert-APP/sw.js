/* WPConvert service worker: makes the app installable and lets it open offline.
   The api/ folder is never cached. Bump VERSION when you change app files. */
const VERSION = 'wpconvert-1.0.0';
const SHELL = ['./', 'index.html', 'assets/app.css', 'assets/app.js', 'assets/converter.js', 'assets/capture-core.js', 'assets/jszip.min.js', 'assets/fonts/manrope.woff2', 'assets/fonts/jetbrains-mono.woff2', 'manifest.webmanifest', 'icons/icon32.png', 'icons/icon48.png', 'icons/icon192.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin || url.pathname.includes('/api/')) return;
  // Network first so updates show up; fall back to the cached copy when offline.
  e.respondWith(
    fetch(e.request)
      .then((res) => {
        if (res.ok) { const copy = res.clone(); caches.open(VERSION).then((c) => c.put(e.request, copy)); }
        return res;
      })
      .catch(() => caches.match(e.request).then((r) => r || caches.match('index.html')))
  );
});
