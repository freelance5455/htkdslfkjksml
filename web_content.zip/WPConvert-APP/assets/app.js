/*
 * WPConvert app — runs entirely in the browser.
 *   - Web (hosted): optional PHP endpoints in /api add "Link" mode, AI and a WordPress proxy.
 *   - Chrome extension: the same UI runs as the extension's editor page (links via host permission).
 *   - Opened as a file: Paste HTML, Upload and Extension capture still work.
 * Depends on window.WPCCapture (capture-core.js) and window.WPConvert (converter.js).
 */
(function () {
  'use strict';

  // WordPress plugin pages define window.WPC_CONFIG (endpoints, nonces, asset URLs).
  var CFG = window.WPC_CONFIG || null;
  var ENV = window.__WPC_FORCE_ENV || (CFG ? 'wordpress' : location.protocol === 'chrome-extension:' ? 'extension' : /^https?:$/.test(location.protocol) ? 'web' : 'file');
  var VERSION = '1.1.0';
  var HOSTED = ENV === 'web' || ENV === 'wordpress';
  var EMBED = !!(CFG && CFG.embed) || /[?&]embed=1\b/.test(location.search);
  function api(name) { return CFG ? CFG.api[name] : 'api/' + name + '.php'; }
  function withQuery(url, params) {
    var q = Object.keys(params).map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]); }).join('&');
    return url + (url.indexOf('?') >= 0 ? '&' : '?') + q;
  }
  function apiHeaders(h) {
    h = h || {};
    if (CFG && CFG.restNonce) h['X-WP-Nonce'] = CFG.restNonce; // keeps signed-in users signed in for REST calls
    return h;
  }
  function notifyParent(msg) {
    if (EMBED && window.parent !== window) { try { window.parent.postMessage(msg, location.origin); } catch (e) {} }
  }
  var HISTORY_KEY = 'wpc.history.v1';
  var PREFS_KEY = 'wpc.prefs.v1';
  var MAX_HISTORY = 25;

  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  var state = {
    source: 'url',
    server: { checked: false, fetch: false, ai: false },
    files: { upload: null, capture: null },
    current: null, // { record, output }
    rtab: 'preview',
    codeFile: 'blocks',
    device: window.matchMedia && window.matchMedia('(min-width: 900px)').matches ? 1280 : 390,
    installPrompt: null,
  };

  /* ------------------------------------------------------------------ storage */

  function load(key, fallback) {
    try { var v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch (e) { return fallback; }
  }
  function save(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch (e) { return false; }
  }
  function prefs() { return load(PREFS_KEY, { format: (CFG && CFG.defaultFormat) || 'kadence' }); }
  function setPref(k, v) { var p = prefs(); p[k] = v; save(PREFS_KEY, p); }

  function history() { return load(HISTORY_KEY, []); }
  function saveRecord(rec) {
    var list = history().filter(function (r) { return r.id !== rec.id; });
    list.unshift(rec);
    list = list.slice(0, MAX_HISTORY);
    while (list.length && !save(HISTORY_KEY, list)) list.pop(); // drop oldest if storage is full
  }
  function getRecord(id) { return history().filter(function (r) { return r.id === id; })[0] || null; }
  function deleteRecord(id) { save(HISTORY_KEY, history().filter(function (r) { return r.id !== id; })); }

  function newId() {
    var a = new Uint8Array(8);
    (window.crypto || window.msCrypto).getRandomValues(a);
    return Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
  }

  /* ------------------------------------------------------------------ ui helpers */

  var toastTimer;
  function toast(msg) {
    var t = $('#toast');
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.hidden = true; }, 2600);
    notifyParent({ type: 'wpconvert:toast', text: msg });
  }
  function el(tag, attrs, children) {
    var e = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      if (k === 'text') e.textContent = attrs[k];
      else if (k === 'class') e.className = attrs[k];
      else e.setAttribute(k, attrs[k]);
    });
    (children || []).forEach(function (c) { if (c) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }
  function icon(name) {
    var ns = 'http://www.w3.org/2000/svg';
    var s = document.createElementNS(ns, 'svg');
    var u = document.createElementNS(ns, 'use');
    u.setAttribute('href', '#i-' + name);
    s.appendChild(u);
    return s;
  }
  function escapeHtml(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function slug(s) { return (s || 'page').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50) || 'page'; }
  function timeAgo(iso) {
    var d = (Date.now() - new Date(iso).getTime()) / 1000;
    if (d < 60) return 'just now';
    if (d < 3600) return Math.round(d / 60) + ' min ago';
    if (d < 86400) return Math.round(d / 3600) + ' h ago';
    return new Date(iso).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
  }
  function hostOf(u) { try { return new URL(u).host; } catch (e) { return ''; } }
  function download(name, text, type) {
    var blob = new Blob([text], { type: (type || 'text/plain') + ';charset=utf-8' });
    var a = el('a', { href: URL.createObjectURL(blob), download: name });
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  }
  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text).then(function () { return true; }, fallback);
    return Promise.resolve(fallback());
    function fallback() {
      var ta = el('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0';
      document.body.appendChild(ta);
      ta.select();
      ta.setSelectionRange(0, text.length);
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
      ta.remove();
      return ok;
    }
  }

  /* ------------------------------------------------------------------ router */

  function route() {
    var h = location.hash.replace(/^#/, '') || '/';
    var parts = h.split('/').filter(Boolean);
    var view = parts[0] || 'convert';
    if (view === 'import' && ENV === 'extension') { importFromExtension(); view = 'convert'; }
    if (view === 'result') {
      var rec = getRecord(parts[1] || '');
      if (!rec) { location.replace('#/history'); return; }
      openRecord(rec);
    }
    if (['convert', 'result', 'history', 'help', 'settings'].indexOf(view) < 0) view = 'convert';
    $$('.view').forEach(function (v) { v.hidden = v.getAttribute('data-view') !== view; });
    if (view === 'result') setRtab(state.rtab);
    var navKey = view === 'result' ? 'convert' : view;
    $$('[data-nav]').forEach(function (a) {
      if (a.getAttribute('data-nav') === navKey) a.setAttribute('aria-current', 'page');
      else a.removeAttribute('aria-current');
    });
    if (view === 'convert') renderRecent();
    if (view === 'history') renderHistory();
    if (view === 'settings') renderSettings();
    document.title = (view === 'result' && state.current ? state.current.record.title + ' — ' : '') + 'WPConvert — Website to WordPress Converter';
    window.scrollTo(0, 0);
    notifyParent({ type: 'wpconvert:navigate' });
  }

  /* ------------------------------------------------------------------ environment */

  function detectServer() {
    if (!HOSTED) {
      state.server.checked = true;
      updateUrlHint();
      return Promise.resolve();
    }
    return fetch(api('status'), { cache: 'no-store', headers: apiHeaders() })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (d) {
        if (d && d.ok) { state.server.fetch = !!d.fetch; state.server.ai = !!d.ai; state.server.wp = d.wp === undefined ? !!d.fetch : !!d.wp; }
      })
      .catch(function () {})
      .then(function () {
        state.server.checked = true;
        updateUrlHint();
        $('#ai-row').hidden = !state.server.ai;
      });
  }

  function canReadLinks() { return ENV === 'extension' || state.server.fetch; }

  function updateUrlHint() {
    var hint = $('#url-hint');
    hint.className = 'hint';
    if (ENV === 'extension') {
      hint.textContent = 'Chrome will ask once for permission to read that site.';
    } else if (state.server.fetch) {
      hint.textContent = ENV === 'wordpress' ? 'The page is fetched by this website, as a visitor would see it.' : 'The page is fetched through your hosting, as a visitor would see it.';
      hint.classList.add('ok');
    } else if (state.server.checked) {
      hint.className = 'hint warn';
      hint.textContent = ENV === 'file'
        ? 'Links need the app to be uploaded to your hosting (the api folder needs PHP). For now use Paste HTML, Upload file or Extension capture.'
        : 'Links need the api folder with PHP on this hosting. For now use Paste HTML, Upload file or Extension capture.';
    }
    var pill = $('#env-pill');
    if (ENV === 'extension') { pill.hidden = false; pill.textContent = 'Extension'; }
  }

  /* ------------------------------------------------------------------ convert form */

  function setSource(src) {
    state.source = src;
    $$('.source-tabs [data-source]').forEach(function (b) { b.setAttribute('aria-selected', String(b.getAttribute('data-source') === src)); });
    $$('.source-panel').forEach(function (p) { p.hidden = p.getAttribute('data-panel') !== src; });
    showFormError('');
  }

  function showFormError(msg) {
    var e = $('#form-error');
    e.textContent = msg || '';
    e.hidden = !msg;
    if (msg) e.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }

  function bindDrop(labelSel, inputSel, onFile) {
    var label = $(labelSel);
    var input = $(inputSel);
    input.addEventListener('change', function () { if (input.files[0]) onFile(input.files[0]); });
    ['dragenter', 'dragover'].forEach(function (ev) { label.addEventListener(ev, function (e) { e.preventDefault(); label.classList.add('is-over'); }); });
    ['dragleave', 'drop'].forEach(function (ev) { label.addEventListener(ev, function () { label.classList.remove('is-over'); }); });
    label.addEventListener('drop', function (e) { e.preventDefault(); if (e.dataTransfer.files[0]) onFile(e.dataTransfer.files[0]); });
  }

  function onUploadFile(file) {
    showFormError('');
    if (file.size > 25 * 1024 * 1024) return showFormError('That file is bigger than 25 MB.');
    if (!/\.(html?|zip)$/i.test(file.name)) return showFormError('Choose an .html, .htm or .zip file.');
    state.files.upload = file;
    $('#upload-title').textContent = file.name;
    $('#upload-sub').textContent = Math.round(file.size / 1024) + ' KB · tap to choose another file';
    $('#drop-upload').classList.add('has-file');
  }

  function onCaptureFile(file) {
    showFormError('');
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var data = JSON.parse(reader.result);
        if (!data || data.version !== 1 || !Array.isArray(data.sections)) throw new Error();
        state.files.capture = data;
        $('#capture-title').textContent = file.name + ' — ' + data.sections.length + ' sections';
        $('#drop-capture').classList.add('has-file');
      } catch (e) {
        state.files.capture = null;
        $('#drop-capture').classList.remove('has-file');
        showFormError('That file is not a WPConvert capture. In the extension, use “Download capture”.');
      }
    };
    reader.readAsText(file);
  }

  function selectedFormat() { var r = $('input[name="format"]:checked'); return r ? r.value : 'kadence'; }

  function normalizeUrl(input) {
    var s = (input || '').trim();
    if (!s) throw new Error('Enter the link of the page you want to convert.');
    if (/^[a-z][a-z0-9+.-]*:\/\//i.test(s) && !/^https?:\/\//i.test(s)) throw new Error('Only http and https links can be converted.');
    if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
    var u;
    try { u = new URL(s); } catch (e) { throw new Error('That link does not look right. Check it and try again.'); }
    if (!u.hostname || u.hostname.indexOf('.') < 0 && u.hostname !== 'localhost') throw new Error('That link does not look right. Check it and try again.');
    return u.href;
  }

  function onSubmit(e) {
    e.preventDefault();
    showFormError('');
    if (!$('#in-permission').checked) return showFormError('Tick the box to confirm you own this page or have permission to reuse it.');
    var format = selectedFormat();
    var useAi = state.server.ai && $('#in-ai').checked;
    var job;
    try {
      if (state.source === 'url') {
        if (!canReadLinks()) throw new Error(ENV === 'file' ? 'Links work after the app is uploaded to hosting with PHP. Use Paste HTML or Upload file for now.' : 'This hosting cannot read links (the api folder with PHP is missing). Use Paste HTML or Upload file.');
        var url = normalizeUrl($('#in-url').value);
        var permission = ENV === 'extension' ? requestSitePermission(url) : Promise.resolve(true); // must start inside the click
        job = { kind: 'url', url: url, permission: permission };
      } else if (state.source === 'paste') {
        var html = $('#in-html').value;
        if (html.replace(/\s/g, '').length < 20) throw new Error('Paste the page HTML first.');
        if (!/<[a-z!]/i.test(html)) throw new Error('That does not look like HTML. Paste the page source code.');
        job = { kind: 'paste', html: html, base: optionalUrl($('#in-paste-base').value) };
      } else if (state.source === 'upload') {
        if (!state.files.upload) throw new Error('Choose an .html or .zip file first.');
        job = { kind: 'upload', file: state.files.upload, base: optionalUrl($('#in-upload-base').value) };
      } else {
        if (!state.files.capture) throw new Error('Choose a capture file first.');
        job = { kind: 'capture', capture: state.files.capture };
      }
    } catch (err) {
      return showFormError(err.message);
    }
    setPref('format', format);
    runConversion(job, format, useAi);
  }

  function optionalUrl(v) {
    v = (v || '').trim();
    if (!v) return '';
    try { return normalizeUrl(v); } catch (e) { throw new Error('The page address is not a valid link. Leave it empty or fix it.'); }
  }


  var SAMPLE_HTML = '<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Harbor Studio — Coastal architects</title><style>' +
    'body{margin:0;font-family:Georgia,serif;color:#1c1917}.hero{background:#0f766e;color:#fff;padding:88px 24px;text-align:center}.hero h1{font-size:52px;margin:0 0 12px}' +
    '.btn{display:inline-block;background:#f59e0b;color:#1c1917;padding:13px 26px;border-radius:999px;text-decoration:none;font-weight:700}.ghost{background:transparent;color:#fff;border:2px solid #fff;margin-left:8px}' +
    '.wrap{max-width:1040px;margin:0 auto;padding:72px 24px}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}.card{background:#f5f5f4;border-radius:14px;padding:26px}' +
    '.split{display:flex;gap:40px;align-items:center}.split>div{flex:1}.quote{background:#1c1917;color:#fafaf9;text-align:center;padding:72px 24px}' +
    '</style></head><body>' +
    '<section class="hero"><h1>Harbor Studio</h1><p>Architecture for small coastal homes that age well by the sea.</p><p><a class="btn" href="/contact">Book a free call</a><a class="btn ghost" href="#work">See our work</a></p></section>' +
    '<section class="wrap" id="work"><h2>What we do</h2><div class="grid">' +
    '<div class="card"><h3>New homes</h3><p>Compact houses designed around wind, light and salt air.</p></div>' +
    '<div class="card"><h3>Renovations</h3><p>We open up old cottages without losing their character.</p></div>' +
    '<div class="card"><h3>Planning help</h3><p>Drawings and paperwork for <strong>coastal permits</strong>, start to finish.</p></div></div></section>' +
    '<section class="wrap"><div class="split"><div><h2>Fixed fees, no surprises</h2><p>Every project starts with a one-page plan and a fixed price.</p><ul><li>Free first visit</li><li>3D model before building</li><li>One architect from start to finish</li></ul></div>' +
    '<div><h3>Ready when you are</h3><p>Most designs are finished in six to eight weeks.</p><a class="btn" href="/pricing">See prices</a></div></div></section>' +
    '<section class="quote"><blockquote><p>They understood our plot better than we did.</p><cite>Maya and Tom, Saltburn</cite></blockquote></section>' +
    '</body></html>';

  /* ------------------------------------------------------------------ progress sheet */

  var STEP_LABELS = { fetch: 'Download the page', render: 'Read the layout', organize: 'Organize sections', build: 'Build WordPress blocks' };
  function openProgress(steps) {
    var list = $('#progress-steps');
    list.innerHTML = '';
    steps.forEach(function (k) {
      list.appendChild(el('li', { 'data-step': k }, [el('span', { class: 'dot' }), el('span', {}, [STEP_LABELS[k], el('span', { class: 'note' })])]));
    });
    $('#progress-title').textContent = 'Converting…';
    $('#progress-error').hidden = true;
    $('#btn-progress-close').hidden = true;
    $('#progress').hidden = false;
  }
  function step(key, status, note) {
    var li = $('#progress-steps [data-step="' + key + '"]');
    if (!li) return;
    li.className = status;
    var dot = $('.dot', li);
    dot.innerHTML = '';
    if (status === 'done') dot.appendChild(icon('check'));
    if (note) $('.note', li).textContent = note;
  }
  function failProgress(msg) {
    var active = $('#progress-steps li.active');
    if (active) active.className = 'failed';
    $('#progress-title').textContent = 'Could not convert';
    var e = $('#progress-error');
    e.textContent = msg;
    e.hidden = false;
    $('#btn-progress-close').hidden = false;
    $('#btn-progress-close').focus();
  }
  function closeProgress() { $('#progress').hidden = true; }
  function nextFrame() { return new Promise(function (r) { setTimeout(r, 30); }); }

  /* ------------------------------------------------------------------ getting HTML */

  function requestSitePermission(url) {
    if (!(window.chrome && chrome.permissions)) return Promise.resolve(false);
    var origin = new URL(url).origin + '/*';
    return chrome.permissions.contains({ origins: [origin] }).then(function (has) {
      return has || chrome.permissions.request({ origins: [origin] });
    }).catch(function () { return false; });
  }

  function fetchHtml(job) {
    if (ENV === 'extension') {
      return job.permission.then(function (granted) {
        if (!granted) throw new Error('Permission to read ' + hostOf(job.url) + ' was not given, so the page could not be read.');
        return fetch(job.url, { credentials: 'omit', redirect: 'follow' });
      }).then(function (res) {
        if (!res.ok) throw new Error('The site answered with an error (HTTP ' + res.status + ').');
        var type = res.headers.get('content-type') || '';
        if (!/html/i.test(type)) throw new Error('That link is not a web page (' + (type.split(';')[0] || 'unknown type') + ').');
        return res.text().then(function (html) { return { html: html, url: res.url || job.url }; });
      }, function (err) {
        if (err && /Permission/.test(err.message)) throw err;
        throw new Error('Could not reach ' + hostOf(job.url) + '. Check the link and your connection.');
      });
    }
    return fetch(withQuery(api('fetch'), { url: job.url }), { cache: 'no-store', headers: apiHeaders() })
      .then(function (res) { return res.json().catch(function () { throw new Error('The hosting returned an unexpected answer (HTTP ' + res.status + ').'); }); })
      .then(function (d) {
        if (!d.ok) throw new Error(d.error || 'The page could not be downloaded.');
        return { html: d.html, url: d.finalUrl || job.url };
      }, function (err) {
        if (err && err.message && !/Failed to fetch|NetworkError|Load failed/i.test(err.message)) throw err;
        throw new Error('Could not reach the hosting. Check your internet connection.');
      });
  }

  /* Website .zip → one HTML string with CSS inlined; images become blob: URLs for rendering. */
  function readUpload(job) {
    if (/\.html?$/i.test(job.file.name)) {
      return job.file.text().then(function (html) { return { html: html, url: job.base || 'https://example.invalid/', blobMap: null }; });
    }
    return loadJsZip().then(function () { return window.JSZip.loadAsync(job.file); }).then(function (zip) {
      var names = Object.keys(zip.files).filter(function (n) { return !zip.files[n].dir && !/(^|\/)(__MACOSX|\.)/.test(n); });
      var htmlName = names.filter(function (n) { return /(^|\/)index\.html?$/i.test(n); }).sort(function (a, b) { return a.length - b.length; })[0] ||
        names.filter(function (n) { return /\.html?$/i.test(n); })[0];
      if (!htmlName) throw new Error('No .html file was found in that zip.');
      var dir = htmlName.indexOf('/') >= 0 ? htmlName.slice(0, htmlName.lastIndexOf('/') + 1) : '';
      var blobMap = {};
      var images = names.filter(function (n) { return /\.(png|jpe?g|gif|webp|svg|avif)$/i.test(n); });
      return Promise.all(images.map(function (n) {
        return zip.files[n].async('blob').then(function (b) {
          var type = /\.svg$/i.test(n) ? 'image/svg+xml' : b.type;
          var url = URL.createObjectURL(type ? new Blob([b], { type: type }) : b);
          blobMap[url] = n.slice(dir.length);
          blobMap['__' + n.slice(dir.length)] = url;
        });
      })).then(function () {
        return zip.files[htmlName].async('string');
      }).then(function (html) {
        var cssLinks = [];
        html.replace(/<link\b[^>]*rel=["']?stylesheet[^>]*>/gi, function (tag) {
          var m = tag.match(/href=["']([^"']+)["']/i);
          if (m && !/^(https?:)?\/\//i.test(m[1])) cssLinks.push({ tag: tag, href: m[1] });
          return tag;
        });
        return Promise.all(cssLinks.map(function (l) {
          var path = resolveZipPath(dir, l.href);
          var f = zip.files[path];
          return f ? f.async('string').then(function (css) { l.css = rewriteRefs(css, path.slice(dir.length).replace(/[^/]*$/, ''), blobMap); }) : null;
        })).then(function () {
          cssLinks.forEach(function (l) { if (l.css != null) html = html.replace(l.tag, '<style>' + l.css + '</style>'); });
          html = rewriteRefs(html, '', blobMap);
          return { html: html, url: job.base || 'https://example.invalid/', blobMap: blobMap, images: images.length };
        });
      });
    });
  }
  function resolveZipPath(dir, href) {
    var parts = (dir + href.split(/[?#]/)[0]).split('/');
    var out = [];
    parts.forEach(function (p) { if (p === '..') out.pop(); else if (p && p !== '.') out.push(p); });
    return out.join('/');
  }
  function rewriteRefs(text, relDir, blobMap) {
    return text.replace(/(src=|href=|url\()(["']?)([^"')\s>]+)\2/gi, function (all, pre, q, ref) {
      if (/^(https?:|data:|blob:|#|mailto:|\/\/)/i.test(ref)) return all;
      var key = '__' + resolveZipPath(relDir, ref);
      return blobMap[key] ? pre + q + blobMap[key] + q : all;
    });
  }
  var jszipLoading;
  function loadJsZip() {
    if (window.JSZip) return Promise.resolve();
    if (!jszipLoading) jszipLoading = new Promise(function (res, rej) {
      var s = el('script', { src: (CFG ? CFG.assets : 'assets/') + 'jszip.min.js' });
      s.onload = res;
      s.onerror = function () { rej(new Error('Could not load the zip reader.')); };
      document.head.appendChild(s);
    });
    return jszipLoading;
  }

  /* Render the HTML in an invisible, script-free frame and read the real layout from it. */
  function renderAndCapture(html, baseUrl, sourceMode) {
    var clean = String(html)
      .replace(/<script\b[\s\S]*?<\/script\s*>/gi, '')
      .replace(/<noscript\b[\s\S]*?<\/noscript\s*>/gi, '')
      .replace(/<meta[^>]+http-equiv=["']?refresh[^>]*>/gi, '')
      .replace(/<base\b[^>]*>/gi, '');
    var baseTag = '<base href="' + escapeHtml(baseUrl).replace(/"/g, '&quot;') + '">';
    clean = /<head[^>]*>/i.test(clean) ? clean.replace(/<head([^>]*)>/i, '<head$1>' + baseTag) : baseTag + clean;

    return new Promise(function (resolve, reject) {
      var frame = el('iframe', { sandbox: 'allow-same-origin', 'aria-hidden': 'true', tabindex: '-1', title: 'capture' });
      frame.style.cssText = 'position:fixed;left:-30000px;top:0;width:1280px;height:1600px;border:0;pointer-events:none;';
      var done = false;
      var finish = function () {
        if (done) return;
        done = true;
        setTimeout(function () {
          try {
            var doc = frame.contentDocument;
            if (!doc || !doc.body) throw new Error('no-access');
            var cap = window.WPCCapture.captureDocument(doc, { layout: true, baseUrl: baseUrl, sourceMode: sourceMode });
            frame.remove();
            resolve(cap);
          } catch (err) {
            frame.remove();
            // Fall back to reading the HTML without layout (works everywhere).
            try {
              var parsed = new DOMParser().parseFromString(clean, 'text/html');
              resolve(window.WPCCapture.captureDocument(parsed, { baseUrl: baseUrl, sourceMode: sourceMode }));
            } catch (e2) { reject(new Error('The page could not be read.')); }
          }
        }, 350);
      };
      frame.addEventListener('load', finish);
      setTimeout(finish, 9000); // slow images or fonts: read what is there
      frame.srcdoc = clean;
      document.body.appendChild(frame);
    });
  }

  /* ------------------------------------------------------------------ AI (hosted only) */

  function extractJson(text) {
    var fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/);
    var raw = fenced ? fenced[1] : text.slice(text.indexOf('{'), text.lastIndexOf('}') + 1);
    return JSON.parse(raw);
  }
  function callAi(action, model, prompt) {
    return fetch(api('ai'), { method: 'POST', headers: apiHeaders({ 'Content-Type': 'application/json' }), body: JSON.stringify({ action: action, model: model, prompt: prompt || '' }) })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d.ok) throw new Error(d.error || 'AI request failed.');
        var obj = extractJson(d.text);
        obj.version = 1;
        obj.source = model.source;
        return window.WPConvert.sanitizePageModel(obj);
      });
  }

  /* ------------------------------------------------------------------ conversion */

  function runConversion(job, format, useAi) {
    var steps = (job.kind === 'url' ? ['fetch'] : []).concat(job.kind === 'capture' ? [] : ['render']).concat(['organize', 'build']);
    openProgress(steps);
    var blobMap = null;
    var p = Promise.resolve();
    var raw;
    if (job.kind === 'url') {
      step('fetch', 'active');
      p = fetchHtml(job).then(function (r) {
        step('fetch', 'done', Math.max(1, Math.round(r.html.length / 1024)) + ' KB from ' + hostOf(r.url));
        step('render', 'active');
        return nextFrame().then(function () { return renderAndCapture(r.html, r.url, 'url'); });
      });
    } else if (job.kind === 'paste') {
      step('render', 'active');
      p = nextFrame().then(function () { return renderAndCapture(job.html, job.base || 'https://example.invalid/', 'paste'); });
    } else if (job.kind === 'upload') {
      step('render', 'active');
      p = readUpload(job).then(function (r) {
        blobMap = r.blobMap;
        return renderAndCapture(r.html, r.url, 'upload');
      });
    } else {
      p = Promise.resolve(job.capture);
    }

    p.then(function (capture) {
      raw = capture;
      if (blobMap) mapZipImages(raw, blobMap, job.base);
      if (job.kind !== 'capture') step('render', 'done', raw.sections.length + ' sections found');
      step('organize', 'active');
      var model = window.WPConvert.sanitizePageModel(raw);
      if (!useAi) return { model: model, ai: { used: false, note: 'Organized with the built-in rules (Basic mode).' } };
      return callAi('organize', model).then(
        function (m) { return { model: m, ai: { used: true, note: 'AI tidied up the sections.' } }; },
        function (err) { return { model: model, ai: { used: false, note: 'AI was skipped (' + err.message + '); used the built-in rules.' } }; }
      );
    }).then(function (r) {
      step('organize', 'done', r.ai.note);
      step('build', 'active');
      var rec = {
        id: newId(),
        createdAt: new Date().toISOString(),
        title: r.model.source.title || (r.model.sections[0] && r.model.sections[0].label) || 'Untitled page',
        sourceUrl: job.kind === 'url' ? job.url : r.model.source.url && !/example\.invalid/.test(r.model.source.url) ? r.model.source.url : '',
        sourceMode: job.kind === 'capture' ? 'extension' : job.kind,
        format: format,
        model: r.model,
        ai: r.ai,
      };
      var out = window.WPConvert.convertModel(rec.model, { format: format, seed: rec.id.slice(0, 5) }).output;
      step('build', 'done', out.stats.blocks + ' blocks');
      saveRecord(rec);
      setTimeout(function () {
        closeProgress();
        location.hash = '#/result/' + rec.id;
      }, 450);
    }).catch(function (err) {
      var msg = err && err.message ? err.message : 'Something went wrong.';
      if (/Invalid capture data|No convertible content/.test(msg)) msg = 'No text, images or buttons were found to convert. If the page builds itself with JavaScript, capture it with the Chrome extension.';
      failProgress(msg);
    });
  }

  function mapZipImages(cap, blobMap, base) {
    var missing = 0;
    var fix = function (blocks) {
      return blocks.filter(function (b) {
        if (b.type === 'columns') { b.columns.forEach(function (c) { c.blocks = fix(c.blocks); }); return true; }
        if (b.type === 'image' && /^blob:/.test(b.src)) {
          var file = blobMap[b.src];
          if (base && file) { b.src = new URL(file, base).href; return true; }
          missing++;
          return false;
        }
        return true;
      });
    };
    cap.sections.forEach(function (s) {
      s.blocks = fix(s.blocks);
      if (s.backgroundImage && /^blob:/.test(s.backgroundImage)) {
        var f = blobMap[s.backgroundImage];
        s.backgroundImage = base && f ? new URL(f, base).href : undefined;
        if (!(base && f)) missing++;
      }
    });
    if (missing) (cap.warnings = cap.warnings || []).push(missing + ' image(s) from your zip were left out because no page address was given. Upload them to the Media Library and add them in WordPress, or convert again with the address where they will live.');
  }

  /* ------------------------------------------------------------------ result view */

  function openRecord(rec) {
    var conv = window.WPConvert.convertModel(rec.model, { format: rec.format, seed: rec.id.slice(0, 5) });
    state.current = { record: rec, output: conv.output };
    if (window.matchMedia('(min-width: 900px)').matches && state.rtab === 'preview') state.rtab = 'code';
    renderResult();
  }

  function renderResult() {
    var rec = state.current.record;
    var out = state.current.output;
    $('#result-title').textContent = rec.title;
    var src = rec.sourceUrl || ({ paste: 'Pasted HTML', upload: 'Uploaded file', extension: 'Extension capture' }[rec.sourceMode] || '');
    $('#result-source').textContent = src + ' · ' + timeAgo(rec.createdAt);
    var facts = $('#result-facts');
    facts.innerHTML = '';
    [out.stats.sections + ' sections', out.stats.blocks + ' blocks', out.stats.images + ' images'].forEach(function (t) { facts.appendChild(el('li', { text: t })); });
    facts.appendChild(el('li', { class: rec.ai.used ? 'ai' : '', text: rec.ai.used ? 'AI organized' : 'Basic mode' }));
    $$('.result-meta [data-format]').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-format') === rec.format)); });

    renderPreview();
    renderCode();
    renderPublish();
    renderReport();
    setRtab(state.rtab);
  }

  function setRtab(tab) {
    var desktop = window.matchMedia('(min-width: 900px)').matches;
    if (desktop && tab === 'preview') tab = 'code';
    state.rtab = tab;
    $$('.result-tabs [data-rtab]').forEach(function (b) { b.setAttribute('aria-selected', String(b.getAttribute('data-rtab') === tab)); });
    $$('.result-grid [data-pane]').forEach(function (p) {
      var name = p.getAttribute('data-pane');
      p.hidden = desktop ? name !== 'preview' && name !== tab : name !== tab;
    });
    if (tab === 'preview' || desktop) requestAnimationFrame(fitPreview);
  }

  var DEVICE_HEIGHT = { 390: 780, 768: 1000, 1280: 860 };
  function renderPreview() {
    $('#preview').srcdoc = state.current.output.previewDoc;
    $$('[data-device]').forEach(function (b) { b.setAttribute('aria-pressed', String(Number(b.getAttribute('data-device')) === state.device)); });
    fitPreview();
  }
  function fitPreview() {
    var stage = $('#preview-stage');
    var frame = $('#preview-frame');
    var iframe = $('#preview');
    if (!stage.offsetWidth) return;
    var avail = stage.clientWidth - 20;
    var w = state.device;
    var h = DEVICE_HEIGHT[w];
    var scale = Math.min(1, avail / w);
    iframe.style.width = w + 'px';
    iframe.style.height = h + 'px';
    iframe.style.transform = scale < 1 ? 'scale(' + scale + ')' : '';
    iframe.style.transformOrigin = 'top left';
    frame.style.width = Math.round(w * scale) + 'px';
    frame.style.height = Math.round(h * scale) + 'px';
    $('#preview-scale').textContent = w + 'px wide' + (scale < 1 ? ' · shown at ' + Math.round(scale * 100) + '%' : '');
  }

  function codeFiles() {
    var o = state.current.output;
    var rec = state.current.record;
    var name = slug(rec.title);
    var kad = o.format === 'kadence';
    return [
      { key: 'blocks', label: kad ? 'Kadence blocks' : 'Gutenberg blocks', text: o.blocks, file: name + '-' + o.format + '-blocks.html', type: 'text/html', hint: 'Paste into the WordPress editor: ⋮ menu → Code editor → paste → Exit code editor.' },
      { key: 'css', label: 'Extra CSS', text: o.css, file: name + '-extra.css', type: 'text/css', hint: 'Optional. Appearance → Customize → Additional CSS. Only needed for card shadows.' },
      { key: 'html', label: 'HTML page', text: o.html, file: name + '.html', type: 'text/html', hint: 'A standalone copy of the page for other platforms (links to styles.css). Not for WordPress.' },
      { key: 'styles', label: 'styles.css', text: o.htmlCss, file: 'styles.css', type: 'text/css', hint: 'The stylesheet for the standalone HTML page.' },
    ];
  }
  function renderCode() {
    var files = codeFiles();
    if (!files.some(function (f) { return f.key === state.codeFile; })) state.codeFile = 'blocks';
    var wrap = $('#code-files');
    wrap.innerHTML = '';
    files.forEach(function (f) {
      var b = el('button', { type: 'button', role: 'tab', 'aria-selected': String(f.key === state.codeFile), text: f.label });
      b.addEventListener('click', function () { state.codeFile = f.key; renderCode(); });
      wrap.appendChild(b);
    });
    var cur = files.filter(function (f) { return f.key === state.codeFile; })[0];
    $('#code-hint').textContent = cur.hint;
    var safe = escapeHtml(cur.text.length > 400000 ? cur.text.slice(0, 400000) + '\n… (shortened here — Copy and Download include everything)' : cur.text);
    $('#code-view code').innerHTML = safe.replace(/(&lt;!--[\s\S]*?--&gt;)/g, '<span class="c-comment">$1</span>');
    $('#btn-copy span').textContent = cur.key === 'blocks' ? 'Copy code' : 'Copy';
  }

  function renderPublish() {
    var rec = state.current.record;
    var here = !!(CFG && CFG.siteDraft);
    $('#this-site').hidden = !here;
    $('#this-site-result').hidden = true;
    if (here) $('#this-site-title').textContent = 'Add it to ' + (CFG.siteName || 'this site');
    $('#wp-form-title').textContent = here ? 'Or send it to another WordPress site' : 'Send to WordPress as a draft';
    var saved = load('wpc.wpsite', null);
    if (saved && !$('#wp-site').value) { $('#wp-site').value = saved.site || ''; $('#wp-user').value = saved.user || ''; }
    $('#wp-title').value = rec.title;
    $('#wp-result').hidden = true;
    $('#kadence-tip').hidden = rec.format !== 'kadence';
  }

  var TYPE_LABEL = { heading: 'Text', paragraph: 'Text', image: 'Image', buttons: 'Button', list: 'List', quote: 'Quote', separator: 'Divider' };
  var TYPE_CLASS = { Text: 'b-text', Image: 'b-image', Button: 'b-button', Columns: 'b-row' };
  function renderReport() {
    var rec = state.current.record;
    var o = state.current.output;
    var map = $('#blockmap');
    map.innerHTML = '';
    rec.model.sections.forEach(function (s) {
      var counts = {};
      var add = function (k, n) { counts[k] = (counts[k] || 0) + (n || 1); };
      s.blocks.forEach(function (b) {
        if (b.type === 'columns') {
          add('Columns', b.columns.length);
          b.columns.forEach(function (c) { c.blocks.forEach(function (x) { add(TYPE_LABEL[x.type], x.type === 'buttons' ? x.items.length : 1); }); });
        } else add(TYPE_LABEL[b.type], b.type === 'buttons' ? b.items.length : 1);
      });
      var chips = el('div', { class: 'bm-blocks' });
      chips.appendChild(el('span', { class: 'b-row', text: rec.format === 'kadence' ? 'Row Layout' : s.backgroundImage ? 'Cover' : 'Group' }));
      Object.keys(counts).forEach(function (k) { chips.appendChild(el('span', { class: TYPE_CLASS[k] || 'b-other', text: k + ' ' + counts[k] })); });
      var bg = s.background || rec.model.theme.background || '#ffffff';
      var li = el('li', { class: isLight(bg) ? 'light' : '' }, [el('span', { class: 'bm-title', text: s.label }), chips]);
      li.style.setProperty('--swatch', /^#|^rgba/.test(bg) ? bg : '#1f1a4d');
      map.appendChild(li);
    });
    var warn = $('#warnings');
    warn.innerHTML = '';
    o.warnings.forEach(function (w) { warn.appendChild(el('li', { text: w })); });
    $('#warnings-wrap').hidden = !o.warnings.length;
    $('#ai-form').hidden = !state.server.ai;
    $('#ai-msg').textContent = '';
  }
  function isLight(c) {
    var m = String(c).match(/^#([0-9a-f]{6})/i);
    if (!m) return true;
    var n = parseInt(m[1], 16);
    var r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    return 0.2126 * r + 0.7152 * g + 0.0722 * b > 165;
  }

  function switchFormat(fmt) {
    if (!state.current || state.current.record.format === fmt) return;
    var rec = state.current.record;
    rec.format = fmt;
    saveRecord(rec);
    setPref('format', fmt);
    openRecord(rec);
    toast(fmt === 'kadence' ? 'Switched to Kadence Blocks' : 'Switched to Gutenberg blocks');
  }

  /* ------------------------------------------------------------------ publish to WordPress */

  function onPublish(e) {
    e.preventDefault();
    var box = $('#wp-result');
    var show = function (ok, nodes) { box.className = 'notice ' + (ok ? 'ok' : 'err'); box.innerHTML = ''; nodes.forEach(function (n) { box.appendChild(typeof n === 'string' ? document.createTextNode(n) : n); }); box.hidden = false; };
    var site;
    try {
      site = normalizeUrl($('#wp-site').value).replace(/\/+$/, '').replace(/\/wp-admin.*$/, '');
    } catch (err) { return show(false, ['Enter your WordPress site address, like https://your-site.com']); }
    var local = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?/.test(site);
    if (/^http:/.test(site) && !local) return show(false, ['Use the https:// address of your site. Passwords must not be sent over plain http.']);
    var user = $('#wp-user').value.trim();
    var pass = $('#wp-pass').value.replace(/\s+/g, ' ').trim();
    if (!user || !pass) return show(false, ['Enter your WordPress username and an Application Password.']);
    if ($('#wp-remember').checked) save('wpc.wpsite', { site: site, user: user }); else { try { localStorage.removeItem('wpc.wpsite'); } catch (x) {} }

    var btn = $('#btn-wp');
    btn.disabled = true;
    btn.textContent = 'Creating draft…';
    var payload = { title: $('#wp-title').value.trim() || state.current.record.title, content: state.current.output.blocks, status: 'draft' };
    createDraft(site, user, pass, payload).then(function (r) {
      var link = el('a', { href: r.edit, target: '_blank', rel: 'noopener', text: 'Open it in the WordPress editor' });
      show(true, ['Draft page created (#' + r.id + '). ', link, '.']);
      toast('Draft created in WordPress');
    }, function (err) {
      show(false, [err.message]);
    }).then(function () {
      btn.disabled = false;
      btn.textContent = 'Create draft page';
      $('#wp-pass').value = '';
    });
  }

  function onThisSite() {
    var btn = $('#btn-this-site');
    var box = $('#this-site-result');
    btn.disabled = true;
    btn.textContent = 'Creating draft…';
    fetch(api('draft'), {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': CFG.restNonce },
      body: JSON.stringify({ title: $('#wp-title').value.trim() || state.current.record.title, content: state.current.output.blocks, css: state.current.output.css, source: state.current.record.sourceUrl }),
    }).then(function (r) { return r.json().then(function (d) { return { status: r.status, d: d }; }); }).then(function (r) {
      box.innerHTML = '';
      if (r.d && r.d.id) {
        box.className = 'notice ok';
        box.appendChild(document.createTextNode('Draft page created (#' + r.d.id + '). '));
        box.appendChild(el('a', { href: r.d.edit_url, target: '_top', text: 'Open it in the editor' }));
        toast('Draft created on ' + (CFG.siteName || 'this site'));
      } else {
        box.className = 'notice err';
        box.textContent = (r.d && r.d.message) ? String(r.d.message).replace(/<[^>]+>/g, '') : 'The draft could not be created (HTTP ' + r.status + ').';
      }
      box.hidden = false;
    }, function () {
      box.className = 'notice err';
      box.textContent = 'Could not reach this site. Check your connection and try again.';
      box.hidden = false;
    }).then(function () {
      btn.disabled = false;
      btn.textContent = 'Create draft on this site';
    });
  }

  function createDraft(site, user, pass, payload) {
    var auth = 'Basic ' + btoa(unescape(encodeURIComponent(user + ':' + pass)));
    var urls = [site + '/wp-json/wp/v2/pages', site + '/?rest_route=/wp/v2/pages'];
    var corsBlocked = false;
    var attempt = function (i) {
      if (i >= urls.length) return Promise.reject(null);
      return fetch(urls[i], { method: 'POST', headers: { Authorization: auth, 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(payload), credentials: 'omit' })
        .then(function (res) {
          return res.json().then(function (d) { return { res: res, d: d }; }, function () { return { res: res, d: null }; });
        }, function () { corsBlocked = true; return null; })
        .then(function (r) {
          if (!r || !r.d || r.d.code === 'rest_no_route') return attempt(i + 1);
          return finish(r.res.status, r.d);
        });
    };
    var finish = function (status, d) {
      if (status >= 200 && status < 300 && d.id) return { id: d.id, edit: site + '/wp-admin/post.php?post=' + d.id + '&action=edit' };
      throw new Error(wpError(status, d));
    };
    return attempt(0).catch(function (err) {
      if (err) throw err;
      if (HOSTED && state.server.wp) {
        return fetch(api('wp'), { method: 'POST', headers: apiHeaders({ 'Content-Type': 'application/json' }), body: JSON.stringify({ site: site, user: user, pass: pass, payload: payload }) })
          .then(function (r) { return r.json(); })
          .then(function (d) {
            if (d.ok) return finish(201, d.page);
            throw new Error(d.status ? wpError(d.status, d.page) : d.error || 'The draft could not be created.');
          });
      }
      throw new Error(corsBlocked
        ? 'Your site did not allow this request from the browser. Use “Prefer to paste it yourself?” below, or check that the WordPress REST API is not blocked by a security plugin.'
        : 'The WordPress REST API was not found at that address. Check the site address.');
    });
  }
  function wpError(status, d) {
    var msg = d && d.message ? String(d.message).replace(/<[^>]+>/g, '') : '';
    if (status === 401) return 'WordPress did not accept the login. Check the username and the Application Password (Users → Profile → Application Passwords).';
    if (status === 403) return 'This WordPress user is not allowed to create pages. Use an Editor or Administrator account.' + (msg ? ' (' + msg + ')' : '');
    return 'WordPress answered with an error (HTTP ' + status + ')' + (msg ? ': ' + msg : '.');
  }

  /* ------------------------------------------------------------------ AI change request */

  function onAiChange(e) {
    e.preventDefault();
    var prompt = $('#ai-prompt').value.trim();
    if (!prompt) return;
    var btn = $('#btn-ai');
    var msg = $('#ai-msg');
    btn.disabled = true;
    btn.textContent = 'Applying…';
    msg.textContent = '';
    callAi('refine', state.current.record.model, prompt).then(function (model) {
      var rec = state.current.record;
      rec.model = model;
      rec.ai = { used: true, note: 'Changed with AI: ' + prompt.slice(0, 80) };
      saveRecord(rec);
      openRecord(rec);
      $('#ai-prompt').value = '';
      toast('Change applied');
    }, function (err) {
      msg.textContent = 'Nothing was changed: ' + err.message;
    }).then(function () {
      btn.disabled = false;
      btn.textContent = 'Apply change';
    });
  }

  /* ------------------------------------------------------------------ lists & settings */

  function itemNode(r) {
    var tag = el('span', { class: 'tag' + (r.format === 'core' ? ' core' : ''), text: r.format === 'core' ? 'Gutenberg' : 'Kadence' });
    var main = el('a', { class: 'item-main', href: '#/result/' + r.id }, [
      el('span', { class: 'item-title', text: r.title }),
      el('span', { class: 'item-sub', text: (r.sourceUrl ? hostOf(r.sourceUrl) : { paste: 'Pasted HTML', upload: 'Uploaded file', extension: 'Extension capture' }[r.sourceMode] || '') + ' · ' + timeAgo(r.createdAt) }),
    ]);
    var del = el('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Delete ' + r.title }, [icon('trash')]);
    del.addEventListener('click', function () {
      deleteRecord(r.id);
      renderHistory();
      renderRecent();
      toast('Deleted');
    });
    return el('li', { class: 'item' }, [main, tag, del]);
  }
  function renderRecent() {
    var list = history().slice(0, 3);
    $('#recent').hidden = !list.length;
    var ul = $('#recent-list');
    ul.innerHTML = '';
    list.forEach(function (r) { ul.appendChild(itemNode(r)); });
  }
  function renderHistory() {
    var list = history();
    var ul = $('#history-list');
    ul.innerHTML = '';
    list.forEach(function (r) { ul.appendChild(itemNode(r)); });
    $('#history-empty').hidden = !!list.length;
    $('#btn-clear-history').hidden = !list.length;
  }
  var clearArmed = null;
  function clearHistory(e) {
    if (!history().length) return;
    var btn = e && e.currentTarget;
    var label = btn && (btn.querySelector('span') || btn);
    if (clearArmed !== btn) {
      // Ask for a second tap instead of a browser dialog (works everywhere, also inside app views).
      if (clearArmed) clearArmed.__reset();
      clearArmed = btn;
      var old = label.textContent;
      label.textContent = 'Tap again to delete all';
      btn.__reset = function () { label.textContent = old; clearArmed = null; };
      setTimeout(function () { if (clearArmed === btn) btn.__reset(); }, 3500);
      return;
    }
    btn.__reset();
    save(HISTORY_KEY, []);
    renderHistory();
    renderRecent();
    renderSettings();
    toast('History cleared');
  }
  function renderSettings() {
    var fmt = prefs().format;
    $$('#set-format button').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-value') === fmt)); });
    $('#set-fetch').textContent = ENV === 'extension' ? 'On — Chrome asks for permission per site.' : state.server.fetch ? 'On — pages are fetched by this website.' : 'Off — upload the app with its api folder to hosting with PHP to turn this on.';
    $('#set-ai').textContent = state.server.ai ? 'On — set up on the hosting.' : ENV === 'wordpress' ? 'Off — the site owner can add an API key in Settings → WPConvert.' : ENV === 'web' ? 'Off — add an API key in api/config.php on the hosting to turn it on.' : 'Off — available in the hosted app.';
    var wp = load('wpc.wpsite', null);
    $('#set-wp').textContent = wp ? wp.user + ' @ ' + hostOf(wp.site) : 'None';
    $('#btn-forget-wp').hidden = !wp;
    var n = history().length;
    $('#set-history').textContent = n ? n + ' conversion' + (n === 1 ? '' : 's') + ' saved on this device' : 'Empty';
    $('#set-version').textContent = 'WPConvert ' + VERSION + ' · converter verified with Kadence Blocks ' + window.WPConvert.KADENCE_VERIFIED_VERSION + ' · ' + { web: 'web app', wordpress: 'WordPress plugin', extension: 'Chrome extension', file: 'opened as a file' }[ENV];
  }

  /* ------------------------------------------------------------------ extension hand-off */

  function importFromExtension() {
    if (!(window.chrome && chrome.storage)) return;
    chrome.storage.local.get(['pendingCapture', 'pendingFormat']).then(function (d) {
      if (!d.pendingCapture) return;
      chrome.storage.local.remove(['pendingCapture', 'pendingFormat']);
      runConversion({ kind: 'capture', capture: d.pendingCapture }, d.pendingFormat || prefs().format, false);
    });
  }

  /* ------------------------------------------------------------------ init */

  function init() {
    if (!window.WPConvert || !window.WPCCapture) {
      document.body.innerHTML = '<p style="padding:24px;font-family:sans-serif">The app files are incomplete. Upload the whole folder, including the assets folder.</p>';
      return;
    }
    if (EMBED) {
      document.documentElement.classList.add('embed');
      // Progress shows inline under the form instead of as a fixed overlay inside a tall frame.
      $('#convert-form').insertAdjacentElement('afterend', $('#progress'));
      if (window.ResizeObserver) {
        var lastH = 0;
        new ResizeObserver(function () {
          var h = Math.ceil(document.documentElement.getBoundingClientRect().height);
          if (Math.abs(h - lastH) > 2) { lastH = h; notifyParent({ type: 'wpconvert:height', height: h }); }
        }).observe(document.body);
      }
    }
    var fmt = prefs().format;
    var radio = $('input[name="format"][value="' + fmt + '"]');
    if (radio) radio.checked = true;

    $$('.source-tabs [data-source]').forEach(function (b) { b.addEventListener('click', function () { setSource(b.getAttribute('data-source')); }); });
    $('#btn-sample').addEventListener('click', function () {
      setSource('paste');
      $('#in-html').value = SAMPLE_HTML;
      $('#in-paste-base').value = 'https://harbor-studio.example/';
      $('#in-permission').checked = true;
      toast('Sample loaded — tap Convert to WordPress');
      $('#btn-convert').scrollIntoView({ block: 'center', behavior: 'smooth' });
    });
    bindDrop('#drop-upload', '#in-file', onUploadFile);
    bindDrop('#drop-capture', '#in-capture', onCaptureFile);
    $('#convert-form').addEventListener('submit', onSubmit);
    $('#btn-progress-close').addEventListener('click', closeProgress);
    $('#progress').addEventListener('click', function (e) { if (e.target.id === 'progress' && !$('#btn-progress-close').hidden) closeProgress(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('#btn-progress-close').hidden) closeProgress(); });

    $$('.result-tabs [data-rtab]').forEach(function (b) { b.addEventListener('click', function () { setRtab(b.getAttribute('data-rtab')); }); });
    $$('.result-meta [data-format]').forEach(function (b) { b.addEventListener('click', function () { switchFormat(b.getAttribute('data-format')); }); });
    $$('[data-device]').forEach(function (b) {
      b.addEventListener('click', function () {
        state.device = Number(b.getAttribute('data-device'));
        $$('[data-device]').forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); });
        fitPreview();
      });
    });
    window.addEventListener('resize', function () { if (state.current) { setRtab(state.rtab); fitPreview(); } });

    $('#btn-copy').addEventListener('click', function () {
      var f = codeFiles().filter(function (x) { return x.key === state.codeFile; })[0];
      copyText(f.text).then(function (ok) { toast(ok ? 'Copied — paste it in the WordPress code editor' : 'Copy did not work here. Use Download instead.'); });
    });
    $('#btn-download').addEventListener('click', function () {
      var f = codeFiles().filter(function (x) { return x.key === state.codeFile; })[0];
      download(f.file, f.text, f.type);
    });
    if (navigator.share && window.File) {
      $('#btn-share').hidden = false;
      $('#btn-share').addEventListener('click', function () {
        var f = codeFiles().filter(function (x) { return x.key === state.codeFile; })[0];
        var file = new File([f.text], f.file.replace(/\.html$/, '.txt'), { type: 'text/plain' });
        var data = navigator.canShare && navigator.canShare({ files: [file] }) ? { files: [file], title: f.file } : { text: f.text, title: f.file };
        navigator.share(data).catch(function () {});
      });
    }
    $('#wp-form').addEventListener('submit', onPublish);
    $('#btn-this-site').addEventListener('click', onThisSite);
    $('#ai-form').addEventListener('submit', onAiChange);

    $('#btn-clear-history').addEventListener('click', clearHistory);
    $('#btn-clear-history-2').addEventListener('click', clearHistory);
    $$('#set-format button').forEach(function (b) {
      b.addEventListener('click', function () {
        setPref('format', b.getAttribute('data-value'));
        var r = $('input[name="format"][value="' + b.getAttribute('data-value') + '"]');
        if (r) r.checked = true;
        renderSettings();
        toast('Saved');
      });
    });
    $('#btn-forget-wp').addEventListener('click', function () {
      try { localStorage.removeItem('wpc.wpsite'); } catch (e) {}
      $('#wp-site').value = '';
      $('#wp-user').value = '';
      renderSettings();
      toast('Forgotten');
    });

    window.addEventListener('beforeinstallprompt', function (e) {
      e.preventDefault();
      state.installPrompt = e;
      $('#btn-install').hidden = false;
    });
    $('#btn-install').addEventListener('click', function () {
      if (!state.installPrompt) return;
      state.installPrompt.prompt();
      state.installPrompt.userChoice.then(function () { state.installPrompt = null; $('#btn-install').hidden = true; });
    });
    var swOk = 'serviceWorker' in navigator && (location.protocol === 'https:' || /^(localhost|127\.0\.0\.1)$/.test(location.hostname));
    if (swOk && ENV === 'web') navigator.serviceWorker.register('sw.js').catch(function () {});
    if (swOk && ENV === 'wordpress' && CFG.sw && !EMBED) navigator.serviceWorker.register(CFG.sw.url, { scope: CFG.sw.scope }).catch(function () {});

    window.addEventListener('hashchange', route);
    detectServer();
    route();
  }

  init();
})();
