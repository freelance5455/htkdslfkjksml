<?php
/**
 * Shared helpers for the WPConvert API (plain PHP 7.4+, works on shared hosting like Hostinger).
 * Not a public endpoint.
 */
if (basename($_SERVER['SCRIPT_FILENAME'] ?? '') === '_lib.php') { http_response_code(404); exit; }

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

$WPC_CONFIG = array(
	'anthropic_api_key'   => '',
	'ai_model'            => 'claude-sonnet-5-5',
	'requests_per_hour'   => 60,
	'allow_private_hosts' => false, // true only for local testing
);
if (is_file(__DIR__ . '/config.php')) {
	$user_config = include __DIR__ . '/config.php';
	if (is_array($user_config)) $WPC_CONFIG = array_merge($WPC_CONFIG, $user_config);
}
$WPC_CONFIG['anthropic_api_key'] = getenv('ANTHROPIC_API_KEY') ?: $WPC_CONFIG['anthropic_api_key'];
if (getenv('WPC_ALLOW_PRIVATE') === '1') $WPC_CONFIG['allow_private_hosts'] = true; // local testing only

function wpc_out($data, $status = 200) {
	http_response_code($status);
	echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
	exit;
}

/** Only answer requests coming from pages on this same site, so the API is not an open proxy. */
function wpc_same_origin_only() {
	$host = strtolower($_SERVER['HTTP_HOST'] ?? '');
	$src  = $_SERVER['HTTP_ORIGIN'] ?? ($_SERVER['HTTP_REFERER'] ?? '');
	if ($src === '') wpc_out(array('ok' => false, 'error' => 'Missing origin.'), 403);
	$src_host = strtolower((string) parse_url($src, PHP_URL_HOST) . (parse_url($src, PHP_URL_PORT) ? ':' . parse_url($src, PHP_URL_PORT) : ''));
	if ($src_host !== $host) wpc_out(array('ok' => false, 'error' => 'This API only serves the WPConvert app on this site.'), 403);
}

/** Simple per-IP hourly limit stored in the temp folder. */
function wpc_rate_limit($bucket) {
	global $WPC_CONFIG;
	$ip   = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
	$file = rtrim(sys_get_temp_dir(), '/') . '/wpc_' . $bucket . '_' . md5($ip) . '.json';
	$now  = time();
	$hits = is_file($file) ? (json_decode((string) @file_get_contents($file), true) ?: array()) : array();
	$hits = array_values(array_filter($hits, function ($t) use ($now) { return $now - $t < 3600; }));
	if (count($hits) >= (int) $WPC_CONFIG['requests_per_hour']) {
		wpc_out(array('ok' => false, 'error' => 'Hourly limit reached. Try again in a while.'), 429);
	}
	$hits[] = $now;
	@file_put_contents($file, json_encode($hits), LOCK_EX);
}

function wpc_json_body($max = 4194304) {
	$raw = file_get_contents('php://input', false, null, 0, $max + 1);
	if ($raw === false || strlen($raw) > $max) wpc_out(array('ok' => false, 'error' => 'Request too large.'), 413);
	$data = json_decode($raw, true);
	if (!is_array($data)) wpc_out(array('ok' => false, 'error' => 'Request must be JSON.'), 400);
	return $data;
}

/** Validate an http(s) URL and resolve it to a public IP (blocks localhost, private networks, cloud metadata). */
function wpc_public_target($url) {
	global $WPC_CONFIG;
	$p = parse_url($url);
	if (!$p || empty($p['host']) || !in_array(strtolower($p['scheme'] ?? ''), array('http', 'https'), true)) {
		wpc_out(array('ok' => false, 'error' => 'Only http and https links can be read.'), 400);
	}
	if (!empty($p['user']) || !empty($p['pass'])) wpc_out(array('ok' => false, 'error' => 'Links with passwords are not supported.'), 400);
	$host = trim($p['host'], '[]');
	$port = !empty($p['port']) ? (int) $p['port'] : (strtolower($p['scheme']) === 'https' ? 443 : 80);
	$ips  = filter_var($host, FILTER_VALIDATE_IP) ? array($host) : (gethostbynamel($host) ?: array());
	if (!$ips) wpc_out(array('ok' => false, 'error' => 'Could not find the website ' . $host . '.'), 422);
	if (empty($WPC_CONFIG['allow_private_hosts'])) {
		foreach ($ips as $ip) {
			if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
				wpc_out(array('ok' => false, 'error' => 'Private or local addresses cannot be read.'), 400);
			}
		}
	}
	return array('host' => $host, 'port' => $port, 'ip' => $ips[0]);
}

/**
 * HTTP request pinned to the checked IP (prevents DNS rebinding), size and time limited.
 * Returns array(status, headers[], body, effective_url).
 */
function wpc_http($method, $url, $headers = array(), $body = null, $max_bytes = 3145728, $follow = 4) {
	if (!function_exists('curl_init')) wpc_out(array('ok' => false, 'error' => 'The PHP curl extension is required on this hosting.'), 500);
	for ($hop = 0; $hop <= $follow; $hop++) {
		$t  = wpc_public_target($url);
		$ch = curl_init($url);
		$data = '';
		$too_big = false;
		$resp_headers = array();
		curl_setopt_array($ch, array(
			CURLOPT_CUSTOMREQUEST  => $method,
			CURLOPT_RESOLVE        => array($t['host'] . ':' . $t['port'] . ':' . $t['ip']),
			CURLOPT_FOLLOWLOCATION => false,
			CURLOPT_CONNECTTIMEOUT => 8,
			CURLOPT_TIMEOUT        => 20,
			CURLOPT_PROTOCOLS      => CURLPROTO_HTTP | CURLPROTO_HTTPS,
			CURLOPT_ENCODING       => '',
			CURLOPT_HTTPHEADER     => $headers,
			CURLOPT_HEADERFUNCTION => function ($ch, $line) use (&$resp_headers) {
				$parts = explode(':', $line, 2);
				if (count($parts) === 2) $resp_headers[strtolower(trim($parts[0]))] = trim($parts[1]);
				return strlen($line);
			},
			CURLOPT_WRITEFUNCTION  => function ($ch, $chunk) use (&$data, &$too_big, $max_bytes) {
				$data .= $chunk;
				if (strlen($data) > $max_bytes) { $too_big = true; return 0; }
				return strlen($chunk);
			},
		));
		if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
		curl_exec($ch);
		$status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
		$err    = curl_error($ch);
		curl_close($ch);
		if ($too_big) wpc_out(array('ok' => false, 'error' => 'The page is larger than 3 MB.'), 413);
		if ($status === 0) wpc_out(array('ok' => false, 'error' => 'Could not reach ' . $t['host'] . ($err ? ' (' . $err . ')' : '') . '.'), 502);
		if ($status >= 300 && $status < 400 && !empty($resp_headers['location']) && $method === 'GET') {
			$url = wpc_absolute($resp_headers['location'], $url);
			continue;
		}
		return array($status, $resp_headers, $data, $url);
	}
	wpc_out(array('ok' => false, 'error' => 'Too many redirects.'), 422);
}

function wpc_absolute($loc, $base) {
	if (preg_match('#^https?://#i', $loc)) return $loc;
	$b = parse_url($base);
	$root = $b['scheme'] . '://' . $b['host'] . (!empty($b['port']) ? ':' . $b['port'] : '');
	if (strpos($loc, '//') === 0) return $b['scheme'] . ':' . $loc;
	if (strpos($loc, '/') === 0) return $root . $loc;
	$dir = isset($b['path']) ? preg_replace('#/[^/]*$#', '/', $b['path']) : '/';
	return $root . $dir . $loc;
}
