<?php
/**
 * POST wp.php {site, user, pass, payload} — fallback used only when a WordPress site blocks the
 * browser request (CORS). Creates a DRAFT page through the core REST API. Nothing is stored.
 */
require __DIR__ . '/_lib.php';
wpc_same_origin_only();
wpc_rate_limit('wp');
$in   = wpc_json_body(4194304);
$site = rtrim((string) ($in['site'] ?? ''), '/');
if (!preg_match('#^https://#i', $site) && empty($WPC_CONFIG['allow_private_hosts'])) wpc_out(array('ok' => false, 'error' => 'Use the https:// address of your site.'), 400);
$payload = $in['payload'] ?? array();
$payload = array(
	'title'   => mb_substr((string) ($payload['title'] ?? 'Converted page'), 0, 200),
	'content' => (string) ($payload['content'] ?? ''),
	'status'  => 'draft',
);
$auth = 'Authorization: Basic ' . base64_encode((string) ($in['user'] ?? '') . ':' . preg_replace('/\s+/', ' ', trim((string) ($in['pass'] ?? ''))));
foreach (array($site . '/wp-json/wp/v2/pages', $site . '/?rest_route=/wp/v2/pages') as $endpoint) {
	list($status, $headers, $body) = wpc_http('POST', $endpoint, array($auth, 'Content-Type: application/json', 'Accept: application/json'), json_encode($payload), 4194304, 0);
	$page = json_decode($body, true);
	if (!is_array($page) || (($page['code'] ?? '') === 'rest_no_route')) continue;
	if ($status >= 200 && $status < 300 && !empty($page['id'])) wpc_out(array('ok' => true, 'page' => array('id' => $page['id'])));
	wpc_out(array('ok' => false, 'status' => $status, 'page' => array('message' => $page['message'] ?? '')));
}
wpc_out(array('ok' => false, 'error' => 'The WordPress REST API was not found at that address.'));
