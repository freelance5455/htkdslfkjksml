<?php
require __DIR__ . '/_lib.php';
wpc_out(array(
	'ok'    => true,
	'app'   => 'wpconvert',
	'fetch' => function_exists('curl_init'),
	'ai'    => $WPC_CONFIG['anthropic_api_key'] !== '',
));
