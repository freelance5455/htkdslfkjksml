<?php
/** POST ai.php {action: organize|refine, model, prompt} — optional AI step. The API key stays on the server. */
require __DIR__ . '/_lib.php';
wpc_same_origin_only();
if ($WPC_CONFIG['anthropic_api_key'] === '') wpc_out(array('ok' => false, 'error' => 'AI is not set up on this hosting.'), 400);
wpc_rate_limit('ai');
$in     = wpc_json_body();
$action = $in['action'] ?? '';
$model  = json_encode($in['model'] ?? null, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
if (!in_array($action, array('organize', 'refine'), true) || strlen($model) < 20) wpc_out(array('ok' => false, 'error' => 'Bad request.'), 400);
if (strlen($model) > 150000) wpc_out(array('ok' => false, 'error' => 'This page is too large for the AI step.'), 413);

$schema = 'PageModel JSON: {"version":1,"source":{...keep...},"theme":{"background","text","accent?"},"sections":[{"id","label","kind":"hero|features|content|cta|footer|header","background?","backgroundImage?","textColor?","align?":"left|center|right","paddingY?":number,"blocks":[Block]}],"warnings":[string]}. '
	. 'Block = heading{level 1-6,html,color?,align?,fontSize?} | paragraph{html,color?,align?,fontSize?,small?} | image{src,alt,width?,height?,radius?} | buttons{align?,items:[{text,href,variant:fill|outline,background?,color?,radius?}]} | list{ordered,items:[html]} | quote{html,cite?} | separator | columns{columns:[{background?,textColor?,radius?,padding?,shadow?,blocks:[Block without columns]}]} (1-6 columns). '
	. 'Every block has a "type" field. Colors are #rrggbb or rgba(r, g, b, a). "html" may only contain <strong>, <em>, <code>, <br>, <a href>.';
if ($action === 'organize') {
	$system = 'You clean up website captures before they become WordPress blocks. ' . $schema . ' Keep the real text and images — never invent copy, links, prices or testimonials. You may fix section labels and kinds, remove junk (cookie notices, "skip to content", duplicate menus, empty items), merge paragraphs split mid-sentence, make heading levels logical (one level-1 heading), and group obvious card lists into columns. Reply with the full PageModel JSON only.';
	$user = $model;
} else {
	$prompt = trim((string) ($in['prompt'] ?? ''));
	if ($prompt === '') wpc_out(array('ok' => false, 'error' => 'Describe the change.'), 400);
	$system = 'You edit a website layout described as JSON before it becomes WordPress blocks. ' . $schema . ' Apply the requested change and keep everything else the same. Only add new text if asked. Reply with the full PageModel JSON only.';
	$user = 'Change request: ' . mb_substr($prompt, 0, 2000) . "\n\nCurrent PageModel:\n" . $model;
}
$api = getenv('ANTHROPIC_BASE_URL') ?: 'https://api.anthropic.com';
$ch = curl_init(rtrim($api, '/') . '/v1/messages');
curl_setopt_array($ch, array(
	CURLOPT_POST           => true,
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_TIMEOUT        => 110,
	CURLOPT_HTTPHEADER     => array('content-type: application/json', 'x-api-key: ' . $WPC_CONFIG['anthropic_api_key'], 'anthropic-version: 2023-06-01'),
	CURLOPT_POSTFIELDS     => json_encode(array('model' => $WPC_CONFIG['ai_model'], 'max_tokens' => 16000, 'system' => $system, 'messages' => array(array('role' => 'user', 'content' => $user)))),
));
$res    = curl_exec($ch);
$status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);
$data = json_decode((string) $res, true);
if ($status !== 200 || !is_array($data)) wpc_out(array('ok' => false, 'error' => $data['error']['message'] ?? ('AI request failed (HTTP ' . $status . ').')), 502);
$text = '';
foreach ($data['content'] ?? array() as $c) if (($c['type'] ?? '') === 'text') $text .= $c['text'];
wpc_out(array('ok' => true, 'text' => $text));
