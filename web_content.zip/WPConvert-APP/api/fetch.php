<?php
/** GET fetch.php?url=… — downloads a public web page for the app (no cookies, no logins). */
require __DIR__ . '/_lib.php';
wpc_same_origin_only();
wpc_rate_limit('fetch');
$url = trim((string) ($_GET['url'] ?? ''));
if ($url === '') wpc_out(array('ok' => false, 'error' => 'Enter a link.'), 400);
list($status, $headers, $body, $final) = wpc_http('GET', $url, array(
	'User-Agent: Mozilla/5.0 (compatible; WPConvert/1.0; page-to-blocks)',
	'Accept: text/html,application/xhtml+xml',
	'Accept-Language: en,*;q=0.5',
));
if ($status === 401 || $status === 403) wpc_out(array('ok' => false, 'error' => 'The website refused access (HTTP ' . $status . '). Pages behind logins or bot protection cannot be read — use the Chrome extension on a page you are allowed to capture.'), 422);
if ($status >= 400) wpc_out(array('ok' => false, 'error' => 'The website answered with an error (HTTP ' . $status . ').'), 422);
$type = $headers['content-type'] ?? '';
if ($type !== '' && stripos($type, 'html') === false) wpc_out(array('ok' => false, 'error' => 'That link is not a web page (' . strtok($type, ';') . ').'), 422);
if (preg_match('/cf-browser-verification|challenge-platform|cf_chl_opt/i', $body)) {
	wpc_out(array('ok' => false, 'error' => 'The website shows a bot check. Use the Chrome extension on a page you are allowed to capture.'), 422);
}
if (!mb_check_encoding($body, 'UTF-8')) {
	$charset = preg_match('/charset=([\w-]+)/i', $type, $m) ? $m[1] : 'Windows-1252';
	$converted = @mb_convert_encoding($body, 'UTF-8', $charset);
	if ($converted !== false) $body = $converted;
}
wpc_out(array('ok' => true, 'html' => $body, 'finalUrl' => $final));
