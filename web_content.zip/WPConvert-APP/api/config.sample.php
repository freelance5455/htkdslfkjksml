<?php
/**
 * Optional settings. Copy this file to config.php (same folder) and fill in what you need.
 * config.php is protected by .htaccess and never sent to visitors.
 */
return array(
	// Anthropic API key — turns on "Tidy up sections with AI" and "Ask for a change". Leave empty for Basic mode.
	'anthropic_api_key'   => '',
	'ai_model'            => 'claude-sonnet-5-5',
	// Requests per visitor (IP) per hour for link reading, AI and WordPress publishing.
	'requests_per_hour'   => 60,
	// Keep false on a live site. true allows reading http://localhost pages while testing on your computer.
	'allow_private_hosts' => false,
);
