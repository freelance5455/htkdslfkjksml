#!/bin/bash
# Compila a VM Luau oficial + compilador + ponte GameForge para WebAssembly (arquivo único).
# Requisitos: emsdk ativo (source emsdk_env.sh) e o repositório https://github.com/luau-lang/luau em $LUAU_DIR
set -e
LUAU_DIR=${LUAU_DIR:-$HOME/luau}
OUT=${OUT:-../runtime/luau-runtime.js}
OBJ=build
mkdir -p $OBJ
FLAGS="-O2 -std=c++17 -DLUA_USE_LONGJMP=1 -I$LUAU_DIR/VM/include -I$LUAU_DIR/VM/src -I$LUAU_DIR/Compiler/include -I$LUAU_DIR/Ast/include -I$LUAU_DIR/Common/include -I$LUAU_DIR/Bytecode/include"
OBJS=""
for f in $LUAU_DIR/VM/src/*.cpp $LUAU_DIR/Compiler/src/*.cpp $LUAU_DIR/Ast/src/*.cpp $LUAU_DIR/Common/src/*.cpp $LUAU_DIR/Bytecode/src/*.cpp; do
  d=$(basename $(dirname $(dirname $f)))
  o=$OBJ/${d}_$(basename $f .cpp).o
  [ -f $o ] || em++ $FLAGS -c $f -o $o
  OBJS="$OBJS $o"
done
em++ $FLAGS -c gameforge.cpp -o $OBJ/gameforge.o
em++ -O2 $OBJS $OBJ/gameforge.o -o $OUT \
  -sSINGLE_FILE=1 -sMODULARIZE=1 -sEXPORT_NAME=createLuauRuntime -sALLOW_MEMORY_GROWTH=1 -sENVIRONMENT=web,worker,node \
  -sEXPORTED_FUNCTIONS=_gf_init,_gf_close,_gf_exec_global,_gf_run_script,_gf_step,_gf_check,_gf_memory_kb,_malloc,_free \
  -sEXPORTED_RUNTIME_METHODS=ccall,cwrap,UTF8ToString,stringToUTF8,lengthBytesUTF8 \
  -sSTACK_SIZE=1048576
echo "OK -> $OUT"
