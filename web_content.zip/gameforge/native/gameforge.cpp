// GameForge Studio - ponte nativa entre a VM Luau (oficial, compilada para WebAssembly)
// e o motor JavaScript/Three.js. Este arquivo NAO implementa a linguagem: ele usa
// o compilador e a VM do repositório oficial luau-lang/luau.
#include "lua.h"
#include "lualib.h"
#include "luacode.h"

#include <emscripten.h>
#include <string>
#include <string.h>
#include <stdlib.h>

static lua_State* GL = nullptr;
static double g_deadline = 1e300;
static bool g_timedOut = false;
static std::string g_result;

// ---------------------------------------------------------------------------
// Funções JS chamadas pelo C++ (definidas no lado JavaScript em Module.gfHost)
// ---------------------------------------------------------------------------
EM_JS(void, js_arg_begin, (), { Module.gfHost.args = []; });
EM_JS(void, js_arg_nil, (), { Module.gfHost.args.push(null); });
EM_JS(void, js_arg_num, (double v), { Module.gfHost.args.push(v); });
EM_JS(void, js_arg_bool, (int v), { Module.gfHost.args.push(!!v); });
EM_JS(void, js_arg_str, (const char* s, int len), {
    Module.gfHost.args.push(UTF8ToString(s, len));
});
// Executa a operação. Retorna número de resultados, ou -1 em caso de erro (mensagem em resultado 0)
EM_JS(int, js_invoke, (const char* op), {
    return Module.gfHost.invoke(UTF8ToString(op));
});
// tipo do resultado i: 0 nil, 1 number, 2 bool, 3 string
EM_JS(int, js_res_type, (int i), {
    var v = Module.gfHost.results[i];
    if (v === null || v === undefined) return 0;
    if (typeof v === 'number') return 1;
    if (typeof v === 'boolean') return 2;
    return 3;
});
EM_JS(double, js_res_num, (int i), { return Module.gfHost.results[i]; });
EM_JS(int, js_res_bool, (int i), { return Module.gfHost.results[i] ? 1 : 0; });
EM_JS(char*, js_res_str, (int i), {
    var s = String(Module.gfHost.results[i]);
    var n = lengthBytesUTF8(s) + 1;
    var p = _malloc(n);
    stringToUTF8(s, p, n);
    return p;
});
EM_JS(void, js_output, (int kind, const char* s), {
    Module.gfHost.output(kind, UTF8ToString(s));
});

// ---------------------------------------------------------------------------
// __host(op, ...) : único ponto de passagem Luau -> motor
// ---------------------------------------------------------------------------
static int l_host(lua_State* L)
{
    const char* op = luaL_checkstring(L, 1);
    int n = lua_gettop(L);
    js_arg_begin();
    for (int i = 2; i <= n; i++)
    {
        switch (lua_type(L, i))
        {
        case LUA_TNUMBER:
            js_arg_num(lua_tonumber(L, i));
            break;
        case LUA_TBOOLEAN:
            js_arg_bool(lua_toboolean(L, i));
            break;
        case LUA_TSTRING:
        {
            size_t len;
            const char* s = lua_tolstring(L, i, &len);
            js_arg_str(s, (int)len);
            break;
        }
        default:
            js_arg_nil();
            break;
        }
    }
    int r = js_invoke(op);
    if (r < 0)
    {
        char* msg = js_res_str(0);
        lua_pushstring(L, msg);
        free(msg);
        lua_error(L);
    }
    luaL_checkstack(L, r, "too many results");
    for (int i = 0; i < r; i++)
    {
        switch (js_res_type(i))
        {
        case 1:
            lua_pushnumber(L, js_res_num(i));
            break;
        case 2:
            lua_pushboolean(L, js_res_bool(i));
            break;
        case 3:
        {
            char* s = js_res_str(i);
            lua_pushstring(L, s);
            free(s);
            break;
        }
        default:
            lua_pushnil(L);
        }
    }
    return r;
}

// __compile(source, chunkname, env) -> function | nil, err
static int l_compile(lua_State* L)
{
    size_t len;
    const char* src = luaL_checklstring(L, 1, &len);
    const char* name = luaL_optstring(L, 2, "chunk");
    std::string chunk = std::string("=") + name;
    size_t bcSize = 0;
    char* bc = luau_compile(src, len, nullptr, &bcSize);
    int envIdx = 0;
    if (lua_istable(L, 3))
        envIdx = 3;
    int status = luau_load(L, chunk.c_str(), bc, bcSize, envIdx);
    free(bc);
    if (status != 0)
    {
        lua_pushnil(L);
        lua_insert(L, -2);
        return 2;
    }
    return 1;
}

// __output(kind, text) : 0 = print, 1 = warn, 2 = erro
static int l_output(lua_State* L)
{
    int kind = luaL_checkinteger(L, 1);
    const char* s = luaL_checkstring(L, 2);
    js_output(kind, s);
    return 0;
}

// __clock() : tempo de alta resolução em segundos
static int l_clock(lua_State* L)
{
    lua_pushnumber(L, emscripten_get_now() / 1000.0);
    return 1;
}

static void interruptCb(lua_State* L, int gc)
{
    if (gc >= 0)
        return;
    double now = emscripten_get_now();
    if (now > g_deadline)
    {
        g_timedOut = true;
        // pequena margem para o tratador de erros (traceback) terminar;
        // se o script capturar o erro e continuar travado, ele é interrompido de novo.
        g_deadline = now + 250;
        luaL_error(L, "Tempo de execução esgotado: o script rodou por muito tempo sem pausar (use task.wait() dentro de loops)");
    }
}

static double g_budget = 5000;
static void setDeadline(double ms)
{
    g_timedOut = false;
    g_budget = ms;
    g_deadline = emscripten_get_now() + ms;
}

// __resetdeadline() : chamado pelo agendador após cada corrotina, para que um
// script travado não afete os demais.
static int l_resetdeadline(lua_State* L)
{
    setDeadline(g_budget);
    return 0;
}

static const char* pcallTop(lua_State* L, int nargs)
{
    // traceback como handler
    int base = lua_gettop(L) - nargs;
    lua_getglobal(L, "__gf_traceback");
    int st;
    if (lua_isfunction(L, -1))
    {
        lua_insert(L, base);
        st = lua_pcall(L, nargs, 0, base);
        lua_remove(L, base);
    }
    else
    {
        lua_pop(L, 1);
        st = lua_pcall(L, nargs, 0, 0);
    }
    if (st != 0)
    {
        const char* m = lua_tostring(L, -1);
        g_result = m ? m : "erro desconhecido";
        lua_pop(L, 1);
        return g_result.c_str();
    }
    return "";
}

extern "C" {

EMSCRIPTEN_KEEPALIVE int gf_init()
{
    if (GL)
    {
        lua_close(GL);
        GL = nullptr;
    }
    GL = luaL_newstate();
    luaL_openlibs(GL);
    lua_pushcfunction(GL, l_host, "__host");
    lua_setglobal(GL, "__host");
    lua_pushcfunction(GL, l_compile, "__compile");
    lua_setglobal(GL, "__compile");
    lua_pushcfunction(GL, l_output, "__output");
    lua_setglobal(GL, "__output");
    lua_pushcfunction(GL, l_clock, "__clock");
    lua_setglobal(GL, "__clock");
    lua_pushcfunction(GL, l_resetdeadline, "__resetdeadline");
    lua_setglobal(GL, "__resetdeadline");
    lua_callbacks(GL)->interrupt = interruptCb;
    return 1;
}

EMSCRIPTEN_KEEPALIVE void gf_close()
{
    if (GL)
    {
        lua_close(GL);
        GL = nullptr;
    }
}

// Executa código diretamente no ambiente global (usado para o prelude da API)
EMSCRIPTEN_KEEPALIVE const char* gf_exec_global(const char* name, const char* src, double budgetMs)
{
    if (!GL)
        return "VM não iniciada";
    lua_State* L = GL;
    size_t bcSize = 0;
    char* bc = luau_compile(src, strlen(src), nullptr, &bcSize);
    std::string chunk = std::string("=") + name;
    int status = luau_load(L, chunk.c_str(), bc, bcSize, 0);
    free(bc);
    if (status != 0)
    {
        g_result = lua_tostring(L, -1);
        lua_pop(L, 1);
        return g_result.c_str();
    }
    setDeadline(budgetMs);
    return pcallTop(L, 0);
}

// Entrega um script do usuário para o agendador (__gf_spawn_script)
EMSCRIPTEN_KEEPALIVE const char* gf_run_script(const char* name, const char* src, double budgetMs)
{
    if (!GL)
        return "VM não iniciada";
    lua_State* L = GL;
    lua_getglobal(L, "__gf_spawn_script");
    lua_pushstring(L, name);
    lua_pushstring(L, src);
    setDeadline(budgetMs);
    return pcallTop(L, 2);
}

// Avança um quadro do jogo
EMSCRIPTEN_KEEPALIVE const char* gf_step(double dt, double budgetMs)
{
    if (!GL)
        return "VM não iniciada";
    lua_State* L = GL;
    lua_getglobal(L, "__gf_step");
    lua_pushnumber(L, dt);
    setDeadline(budgetMs);
    const char* r = pcallTop(L, 1);
    return r;
}

// Verificação de sintaxe (compilador oficial do Luau)
EMSCRIPTEN_KEEPALIVE const char* gf_check(const char* src)
{
    size_t bcSize = 0;
    char* bc = luau_compile(src, strlen(src), nullptr, &bcSize);
    if (bcSize > 0 && bc[0] == 0)
        g_result = std::string(bc + 1, bcSize - 1);
    else
        g_result = "";
    free(bc);
    return g_result.c_str();
}

EMSCRIPTEN_KEEPALIVE int gf_memory_kb()
{
    if (!GL)
        return 0;
    return lua_gc(GL, LUA_GCCOUNT, 0);
}
}
