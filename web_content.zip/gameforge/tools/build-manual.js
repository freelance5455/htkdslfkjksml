#!/usr/bin/env node
/*
 * Gera js/manual/content-1.js, content-2.js e content-3.js a partir dos arquivos
 * manual-src/*.md (em ordem alfabética). Cada capítulo começa com uma linha:
 *   <!-- capitulo id=variaveis num=2 group="Linguagem Luau" title="Variáveis" -->
 * Uso: node tools/build-manual.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const srcDir = path.join(root, 'manual-src');
const files = fs.readdirSync(srcDir).filter((f) => f.endsWith('.md')).sort();
const chapters = [];
for (const f of files) {
  const text = fs.readFileSync(path.join(srcDir, f), 'utf8').replace(/\r\n/g, '\n');
  const parts = text.split(/^<!-- capitulo (.*?) -->\s*$/m);
  for (let i = 1; i < parts.length; i += 2) {
    const attrs = {};
    parts[i].replace(/(\w+)=(?:"([^"]*)"|(\S+))/g, (_, k, a, b) => { attrs[k] = a !== undefined ? a : b; });
    if (!attrs.id || !attrs.title) throw new Error(f + ': capítulo sem id/title');
    chapters.push({ id: attrs.id, group: attrs.group || 'Manual', num: attrs.num || undefined, title: attrs.title, body: parts[i + 1].trim() + '\n', file: f });
  }
}
const ids = new Set();
for (const c of chapters) { if (ids.has(c.id)) throw new Error('id repetido: ' + c.id); ids.add(c.id); }
const per = Math.ceil(chapters.length / 3);
for (let n = 0; n < 3; n++) {
  const slice = chapters.slice(n * per, (n + 1) * per);
  let out = '/* Arquivo gerado por tools/build-manual.js a partir de manual-src/*.md — não edite à mão. */\n';
  out += 'window.GF = window.GF || {}; GF.MANUAL = GF.MANUAL || [];\n';
  for (const c of slice) {
    const o = { id: c.id, group: c.group, title: c.title, body: c.body };
    if (c.num) o.num = c.num;
    out += 'GF.MANUAL.push(' + JSON.stringify(o) + ');\n';
  }
  fs.writeFileSync(path.join(root, 'js/manual/content-' + (n + 1) + '.js'), out);
}
console.log(chapters.length + ' capítulos gerados.');
