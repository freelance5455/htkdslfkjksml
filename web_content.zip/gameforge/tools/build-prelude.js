// Gera js/runtime/prelude.js a partir de js/runtime/prelude.luau
// Uso: node tools/build-prelude.js
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const src = fs.readFileSync(path.join(root, 'js/runtime/prelude.luau'), 'utf8');
const out = '/* Gerado por tools/build-prelude.js a partir de prelude.luau — não edite manualmente. */\nwindow.GF_PRELUDE = ' + JSON.stringify(src) + ';\n';
fs.writeFileSync(path.join(root, 'js/runtime/prelude.js'), out);
console.log('prelude.js gerado (' + src.length + ' caracteres)');
