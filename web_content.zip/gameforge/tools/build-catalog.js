// Gera js/editor/api-catalog.js executando a API real (prelude.luau) na VM Luau.
// Uso: node tools/build-catalog.js
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const create = require(path.join(root, 'runtime/luau-runtime.js'));
(async () => {
  const M = await create();
  let captured = null;
  M.gfHost = {
    args: [], results: [],
    output: (k, s) => { if (k === 0 && s.startsWith('__CATALOG__')) captured = s.slice(11); else if (k) console.log(s); },
    invoke(op) {
      let r = [];
      if (op === 'get') r = ['cf', 0, 5, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1];
      else if (op === 'call') r = [null];
      else if (op === 'device') r = [false];
      this.results = r; return r.length;
    },
  };
  M._gf_init();
  const run = (f, ...a) => M.ccall(f, 'string', a.map((x) => (typeof x === 'number' ? 'number' : 'string')), a);
  const src = fs.readFileSync(path.join(root, 'js/runtime/prelude.luau'), 'utf8');
  const e = run('gf_exec_global', 'prelude', src, 10000);
  if (e) throw new Error(e);
  const e2 = run('gf_exec_global', 'cat', 'print("__CATALOG__" .. __gf_catalog())', 5000);
  if (e2) throw new Error(e2);
  const cat = JSON.parse(captured);
  fs.writeFileSync(path.join(root, 'js/editor/api-catalog.js'),
    '/* Gerado por tools/build-catalog.js a partir da API real — não edite manualmente. */\nwindow.GF = window.GF || {};\nwindow.GF.API_CATALOG = ' + JSON.stringify(cat) + ';\n');
  console.log('catálogo:', Object.keys(cat.classes).length, 'classes,', Object.keys(cat.enums).length, 'enums');
})();
