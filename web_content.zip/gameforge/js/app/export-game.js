/*
 * GameForge Studio — exportação do jogo como um único arquivo HTML jogável.
 * O arquivo gerado contém o motor 3D, a VM Luau (WebAssembly) e os scripts do projeto.
 * Funciona offline. Requer que o GameForge esteja sendo servido por HTTP(S)
 * ou por um WebView que permita ler os próprios arquivos (fetch).
 */
(function () {
  'use strict';
  const GF = (window.GF = window.GF || {});

  const SCRIPTS = [
    'lib/three.min.js',
    'js/engine/util.js', 'js/engine/materials.js', 'js/engine/audio.js', 'js/engine/particles.js',
    'js/engine/environment.js', 'js/engine/character.js', 'js/engine/physics.js', 'js/engine/terrain.js',
    'js/engine/gui.js', 'js/engine/engine.js',
    'runtime/luau-runtime.js', 'js/runtime/prelude.js', 'js/runtime/luau-host.js', 'js/storage/storage.js',
  ];

  async function fetchText(url) {
    const r = await fetch(url, { cache: 'no-cache' });
    if (!r.ok) throw new Error(url + ' (HTTP ' + r.status + ')');
    return r.text();
  }

  function safeScript(code) { return code.replace(/<\/script/gi, '<\\/script'); }

  async function buildGameHtml(project) {
    let css;
    const parts = [];
    try {
      css = await fetchText('css/app.css');
      for (const s of SCRIPTS) parts.push(await fetchText(s));
    } catch (e) {
      throw new Error('Não foi possível ler os arquivos do GameForge para montar o jogo (' + e.message + '). Abra o GameForge por um servidor local (ex.: Acode → Executar) e tente novamente.');
    }
    // apenas as regras do motor/interface do jogo
    const gameCss = css.split('/* ==== GAME-CSS-START ==== */')[1];
    const files = project.files.filter((f) => /\.(luau|lua)$/i.test(f.path)).map((f) => ({ path: f.path, source: f.source, disabled: !!f.disabled }));
    const payload = JSON.stringify({ id: project.id, name: project.name, files }).replace(/</g, '\\u003c');
    const boot = `
(function(){
  var P = ${payload};
  document.title = P.name;
  var engine = new GF.Engine(document.getElementById('game'), { settings: { shadows: true, quality: 'auto', showFps: false, volume: 0.8 } });
  var errBox = document.getElementById('err');
  function showErr(m){ errBox.hidden = false; var d = document.createElement('div'); d.textContent = m; errBox.appendChild(d); while (errBox.children.length > 6) errBox.firstChild.remove(); }
  var runner = new GF.LuauRunner(engine, {
    output: function(k, t){ (k === 'error' ? console.error : k === 'warn' ? console.warn : console.log)(t); if (k === 'error') showErr(t); },
    error: function(m){ console.error(m); showErr(m); },
    stopped: function(r){ if (r !== 'restart') document.getElementById('start').hidden = false; }
  });
  var dsId = 'export:' + P.id;
  async function start(){
    document.getElementById('start').hidden = true;
    errBox.hidden = true; errBox.textContent = '';
    var data = {};
    try { data = await GF.Storage.loadDataStores(dsId); } catch(e) {}
    engine.opts.datastore = { data: data, write: function(s,k,v){ GF.Storage.writeDataStore(dsId, s, k, v).catch(function(){}); } };
    try { await runner.run(P.files); } catch(e) { showErr(String(e && e.message || e)); }
  }
  document.getElementById('start-btn').addEventListener('click', start);
  document.getElementById('start-title').textContent = P.name;
})();`;
    return `<!DOCTYPE html>
<html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${GF.escapeHtml ? GF.escapeHtml(project.name) : project.name}</title>
<style>
html,body{margin:0;height:100%;background:#000;overflow:hidden;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#eee}
#game{position:fixed;inset:0}
#start{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle at 50% 40%,#232733,#0c0d10);z-index:50}
[hidden]{display:none!important}
#start div{text-align:center}
#start h1{font-size:28px;margin:0 0 6px}
#start p{opacity:.7;margin:0 0 20px;font-size:14px}
#start button{font:inherit;font-size:18px;padding:12px 32px;border-radius:10px;border:0;background:#3fb27f;color:#06150e;font-weight:700;cursor:pointer}
#err{position:fixed;left:8px;bottom:8px;max-width:min(90vw,640px);background:rgba(120,20,20,.9);padding:8px 12px;border-radius:8px;font:12px/1.4 ui-monospace,monospace;z-index:60}
${gameCss}
</style></head>
<body>
<div id="game"></div>
<div id="start"><div><h1 id="start-title"></h1><p>Feito com GameForge Studio</p><button id="start-btn">▶ Jogar</button></div></div>
<div id="err" hidden></div>
${parts.map((p) => '<script>' + safeScript(p) + '</script>').join('\n')}
<script>${safeScript(boot)}</script>
</body></html>`;
  }

  GF.buildGameHtml = buildGameHtml;
})();
