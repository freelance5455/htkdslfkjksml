/*
 * GameForge Studio — console de execução.
 * Mostra print/warn/erros da VM Luau, agrupa repetições e transforma
 * "Arquivo.luau:LINHA:" em links que levam à linha no editor.
 */
(function () {
  'use strict';
  const GF = (window.GF = window.GF || {});
  const MAX = 3000;
  const LOC_RE = /([A-Za-z0-9_\-. À-ÿ/()]+?\.luau?):(\d+)(?::(\d+))?/g;

  class Console {
    constructor(outEl, opts) {
      this.el = outEl;
      this.opts = opts || {}; // onLocation(path,line), onCount(errors)
      this.filter = 'all';
      this.entries = [];
      this.errors = 0;
      this.last = null;
      this.pending = [];
      this.raf = 0;
    }

    time() {
      const d = new Date();
      return d.toTimeString().slice(0, 8);
    }

    log(kind, text, detail) {
      text = String(text);
      if (this.last && this.last.kind === kind && this.last.text === text && !detail) {
        this.last.count++;
        if (this.last.el) {
          let c = this.last.el.querySelector('.c-count');
          if (!c) {
            c = document.createElement('span');
            c.className = 'c-count';
            this.last.el.insertBefore(c, this.last.el.firstChild.nextSibling);
          }
          c.textContent = this.last.count;
        }
        return;
      }
      const e = { kind, text, detail, time: this.time(), count: 1, el: null };
      this.entries.push(e);
      this.last = e;
      if (kind === 'error') { this.errors++; if (this.opts.onCount) this.opts.onCount(this.errors); }
      this.pending.push(e);
      if (!this.raf) this.raf = requestAnimationFrame(() => this.flush());
    }

    flush() {
      this.raf = 0;
      const atBottom = this.el.scrollHeight - this.el.scrollTop - this.el.clientHeight < 40;
      const frag = document.createDocumentFragment();
      for (const e of this.pending) frag.appendChild(this.render(e));
      this.pending = [];
      this.el.appendChild(frag);
      while (this.entries.length > MAX) {
        const old = this.entries.shift();
        if (old.el) old.el.remove();
      }
      if (atBottom) this.el.scrollTop = this.el.scrollHeight;
    }

    linkify(parent, text) {
      let last = 0;
      LOC_RE.lastIndex = 0;
      let m;
      while ((m = LOC_RE.exec(text))) {
        const path = m[1].trim();
        if (!this.opts.isFile || !this.opts.isFile(path)) continue;
        if (m.index > last) parent.appendChild(document.createTextNode(text.slice(last, m.index)));
        const a = document.createElement('button');
        a.type = 'button';
        a.className = 'c-loc';
        a.textContent = m[0];
        a.title = 'Ir para ' + path + ', linha ' + m[2];
        const line = +m[2];
        a.addEventListener('click', () => this.opts.onLocation && this.opts.onLocation(path, line));
        parent.appendChild(a);
        last = m.index + m[0].length;
      }
      if (last < text.length) parent.appendChild(document.createTextNode(text.slice(last)));
    }

    render(e) {
      const row = document.createElement('div');
      row.className = 'c-row c-' + e.kind;
      row.hidden = !this.visible(e);
      const t = document.createElement('span');
      t.className = 'c-time';
      t.textContent = e.time;
      row.appendChild(t);
      const msg = document.createElement('span');
      msg.className = 'c-msg';
      this.linkify(msg, e.text);
      row.appendChild(msg);
      if (e.detail) {
        const d = document.createElement('details');
        const s = document.createElement('summary');
        s.textContent = 'Rastreamento';
        const pre = document.createElement('pre');
        this.linkify(pre, e.detail);
        d.append(s, pre);
        msg.appendChild(d);
      }
      e.el = row;
      return row;
    }

    visible(e) {
      if (this.filter === 'all') return true;
      if (this.filter === 'print') return e.kind === 'print' || e.kind === 'info' || e.kind === 'input';
      return e.kind === this.filter;
    }

    setFilter(f) {
      this.filter = f;
      for (const e of this.entries) if (e.el) e.el.hidden = !this.visible(e);
    }

    clear() {
      this.entries = [];
      this.pending = [];
      this.last = null;
      this.errors = 0;
      this.el.textContent = '';
      if (this.opts.onCount) this.opts.onCount(0);
    }

    text() {
      return this.entries.map((e) => '[' + e.time + '] ' + (e.kind === 'error' ? 'ERRO: ' : e.kind === 'warn' ? 'AVISO: ' : '') + e.text + (e.count > 1 ? ' (x' + e.count + ')' : '') + (e.detail ? '\n' + e.detail : '')).join('\n');
    }
  }

  GF.Console = Console;
})();
