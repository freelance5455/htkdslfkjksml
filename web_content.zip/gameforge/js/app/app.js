/*
 * GameForge Studio — aplicação principal (interface, projetos, execução).
 */
(function () {
  'use strict';
  const GF = (window.GF = window.GF || {});
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const P = GF.paths;

  const DEFAULT_SETTINGS = {
    fontSize: 14,
    tabSize: 4,
    wrap: false,
    autocomplete: true,
    lint: true,
    autosave: true,
    clearOnRun: true,
    shadows: true,
    quality: 'auto',
    showFps: false,
    volume: 0.8,
    extraKeys: 'auto',
    layout: { files: 230, right: 44, console: 34 },
  };

  const App = {
    project: null,
    settings: null,
    dirty: false,
    selectedFolder: '',
    collapsed: new Set(),
    running: false,

    // ================================================================ início
    async init() {
      this.app = $('#app');
      try { await GF.Storage.init(); } catch (e) { console.warn(e); }
      const saved = await GF.Storage.getSetting('settings', null).catch(() => null);
      this.settings = Object.assign({}, DEFAULT_SETTINGS, saved || {});
      this.settings.layout = Object.assign({}, DEFAULT_SETTINGS.layout, (saved && saved.layout) || {});
      this.applyLayout();

      this.console = new GF.Console($('#console-out'), {
        isFile: (p) => !!(this.project && this.project.file(p)),
        onLocation: (p, l) => this.gotoLocation(p, l),
        onCount: (n) => this.setErrorBadge(n),
      });

      // motor 3D
      try {
        this.engine = new GF.Engine($('#viewport'), { settings: this.engineSettings() });
      } catch (e) {
        this.engine = null;
        this.console.log('error', 'Não foi possível iniciar o motor 3D: ' + e.message);
      }
      this.runner = this.engine ? new GF.LuauRunner(this.engine, {
        output: (k, t) => this.console.log(k, t),
        error: (m, tb) => this.onRuntimeError(m, tb),
        stopped: (r) => this.onStopped(r),
      }) : null;

      // editor
      this.editor = new GF.CodeEditor($('#cm-host'), $('#tabs'), {
        settings: this.settings,
        checker: (src) => (this.runner && this.runner.M ? this.runner.check(src) : null),
        onChange: (path) => this.onEditorChange(path),
        onActivate: (path) => this.onActivate(path),
        onCursor: (l, c) => { $('#st-pos').textContent = 'Ln ' + l + ', Col ' + c; },
        onCloseTab: (p) => this.closeTab(p),
        onLint: (path, n) => { $('#st-lint').textContent = n ? n + (n > 1 ? ' erros' : ' erro') : ''; },
      });

      // manual
      this.manual = new GF.Manual($('#man-toc'), $('#man-body'), $('#man-search'), {
        onSend: (code, mode, title) => this.sendToEditor(code, mode, title),
        onRun: (code) => this.runSnippet(code),
      });

      this.bindUi();
      await this.loadInitialProject();
      this.updateExtraKeys();
      this.updateStorageInfo();

      // carrega a VM Luau
      if (this.runner) {
        this.runner.ready().then(() => {
          this.console.log('info', 'VM Luau pronta (interpretador oficial do Luau em WebAssembly). Clique em Executar ou pressione F5.');
          if (this.settings.lint) this.editor.cm.performLint();
        }).catch((e) => this.console.log('error', 'Falha ao carregar a VM Luau: ' + e.message));
      }
      setInterval(() => this.updateMem(), 1000);
    },

    engineSettings() {
      const s = this.settings;
      return { shadows: s.shadows, quality: s.quality, showFps: s.showFps, volume: s.volume };
    },

    // ================================================================ projetos
    async loadInitialProject() {
      const lastId = await GF.Storage.getSetting('lastProject', null).catch(() => null);
      let data = lastId ? await GF.Storage.getProject(lastId).catch(() => null) : null;
      if (!data) {
        const list = await GF.Storage.listProjects().catch(() => []);
        if (list.length) data = await GF.Storage.getProject(list[0].id).catch(() => null);
      }
      if (!data) {
        data = GF.createProject('Meu Primeiro Jogo');
        await GF.Storage.saveProject(data).catch(() => {});
      }
      this.openProjectData(data);
    },

    openProjectData(data) {
      if (this.running && this.runner) this.runner.stop('project');
      this.project = new GF.Project(data);
      this.editor.closeAll();
      this.selectedFolder = '';
      const tabs = (data.openTabs || []).filter((p) => this.project.file(p));
      for (const p of tabs) this.editor.open(p, this.project.file(p).source);
      const act = data.activeFile && this.project.file(data.activeFile) ? data.activeFile : tabs[0];
      if (act) this.openFile(act);
      if (!act && this.project.files.length) this.openFile(this.project.files[0].path);
      this.editor.markAllSaved();
      this.setDirty(false);
      this.renderTree();
      this.updateTitle();
      GF.Storage.setSetting('lastProject', data.id).catch(() => {});
      this.updateStorageInfo();
    },

    syncFromEditor() {
      if (!this.project) return;
      for (const f of this.project.files) {
        const v = this.editor.getValue(f.path);
        if (v != null) f.source = v;
      }
      this.project.data.openTabs = this.editor.tabs.slice();
      this.project.data.activeFile = this.editor.active;
    },

    async save(manual, label) {
      this.syncFromEditor();
      try {
        await GF.Storage.saveProject(this.project.data);
        if (manual) await GF.Storage.addVersion(this.project.data, label);
        this.editor.markAllSaved();
        this.setDirty(false);
        if (manual) this.toast('Projeto salvo (' + GF.Storage.backend + '). Versão registrada.');
        this.updateStorageInfo();
        return true;
      } catch (e) {
        this.toast('Erro ao salvar: ' + e.message, 'error');
        return false;
      }
    },

    setDirty(d) {
      this.dirty = d;
      const s = $('#save-state');
      s.className = 'save-state' + (d ? ' dirty' : '');
      s.title = d ? 'Alterações não salvas' : 'Tudo salvo';
      if (d && this.settings.autosave) {
        clearTimeout(this.autosaveT);
        this.autosaveT = setTimeout(() => { if (this.dirty) this.save(false); }, 1500);
      }
    },

    updateTitle() {
      $('#proj-name-text').textContent = this.project.name;
      document.title = this.project.name + ' — GameForge Studio';
    },

    async confirmDiscard() {
      if (!this.dirty) return true;
      const r = await this.dialog({
        title: 'Alterações não salvas',
        body: 'O projeto "' + this.project.name + '" tem alterações não salvas.',
        buttons: [{ label: 'Cancelar', value: 'cancel' }, { label: 'Descartar', value: 'discard', danger: true }, { label: 'Salvar', value: 'save', primary: true }],
      });
      if (r === 'save') return this.save(true);
      return r === 'discard';
    },

    async newProject() {
      if (!(await this.confirmDiscard())) return;
      const body = document.createElement('div');
      body.innerHTML = '<label class="field">Nome do projeto<input id="np-name" value="Novo Jogo" maxlength="80"></label>' +
        '<fieldset class="field"><legend>Modelo</legend><label class="chk"><input type="radio" name="np-t" value="example" checked> Exemplo inicial (plataforma, moeda e módulo)</label>' +
        '<label class="chk"><input type="radio" name="np-t" value="blank"> Projeto vazio</label></fieldset>';
      const r = await this.dialog({ title: 'Novo projeto', body, buttons: [{ label: 'Cancelar', value: null }, { label: 'Criar', value: 'ok', primary: true }], focus: '#np-name' });
      if (r !== 'ok') return;
      const name = $('#np-name', body).value.trim() || 'Novo Jogo';
      const blank = $('input[name=np-t]:checked', body).value === 'blank';
      const data = GF.createProject(name, blank);
      await GF.Storage.saveProject(data);
      this.openProjectData(data);
      this.toast('Projeto "' + name + '" criado.');
    },

    async openDialog() {
      if (!(await this.confirmDiscard())) return;
      const list = await GF.Storage.listProjects();
      const body = document.createElement('div');
      body.className = 'proj-list';
      const render = (items) => {
        body.textContent = '';
        if (!items.length) { body.innerHTML = '<p class="muted">Nenhum projeto salvo.</p>'; return; }
        for (const p of items) {
          const row = document.createElement('div');
          row.className = 'proj-row' + (p.id === this.project.id ? ' current' : '');
          row.innerHTML = '<div class="pr-info"><b></b><small></small></div><div class="pr-act"><button class="btn sm" data-a="open">Abrir</button><button class="btn sm danger" data-a="del">Excluir</button></div>';
          $('b', row).textContent = p.name + (p.id === this.project.id ? ' (aberto)' : '');
          $('small', row).textContent = p.files + ' arquivo(s) · modificado em ' + new Date(p.modified).toLocaleString('pt-BR');
          $('[data-a=open]', row).addEventListener('click', async () => {
            const data = await GF.Storage.getProject(p.id);
            this.closeDialog();
            if (data) this.openProjectData(data);
          });
          $('[data-a=del]', row).addEventListener('click', async () => {
            if (!(await this.confirm('Excluir projeto', 'Excluir "' + p.name + '" e todas as suas versões? Esta ação não pode ser desfeita.', true))) { this.openDialog(); return; }
            await GF.Storage.deleteProject(p.id);
            if (p.id === this.project.id) {
              const rest = await GF.Storage.listProjects();
              const next = rest.length ? await GF.Storage.getProject(rest[0].id) : GF.createProject('Meu Primeiro Jogo');
              if (!rest.length) await GF.Storage.saveProject(next);
              this.openProjectData(next);
            }
            this.toast('Projeto excluído.');
            this.openDialog();
          });
          body.appendChild(row);
        }
      };
      render(list);
      this.dialog({ title: 'Abrir projeto', body, buttons: [{ label: 'Importar arquivo…', value: 'import' }, { label: 'Fechar', value: null }] }).then((r) => { if (r === 'import') this.pickImport(); });
    },

    async saveAs() {
      const name = await this.prompt('Salvar como', 'Nome do novo projeto', this.project.name + ' (cópia)');
      if (!name) return;
      this.syncFromEditor();
      const data = JSON.parse(JSON.stringify(this.project.data));
      data.id = GF.createProject().id;
      data.name = name;
      data.created = Date.now();
      await GF.Storage.saveProject(data);
      await GF.Storage.addVersion(data, 'Criado por "Salvar como"');
      this.openProjectData(data);
      this.toast('Projeto salvo como "' + name + '".');
    },

    async renameProject() {
      const name = await this.prompt('Renomear projeto', 'Novo nome', this.project.name);
      if (!name) return;
      this.project.name = name;
      this.updateTitle();
      this.setDirty(true);
      if (!this.settings.autosave) this.save(false);
    },

    // ---------------------------------------------------------------- versões
    async versionsDialog() {
      this.syncFromEditor();
      const list = await GF.Storage.listVersions(this.project.id);
      const body = document.createElement('div');
      body.className = 'proj-list';
      const head = document.createElement('p');
      head.className = 'muted';
      head.textContent = 'Uma versão é criada a cada salvamento manual (Ctrl+S). São mantidas as ' + 30 + ' mais recentes.';
      body.appendChild(head);
      if (!list.length) body.insertAdjacentHTML('beforeend', '<p>Nenhuma versão ainda. Use Arquivo → Salvar.</p>');
      for (const v of list) {
        const row = document.createElement('div');
        row.className = 'proj-row';
        row.innerHTML = '<div class="pr-info"><b></b><small></small></div><div class="pr-act"><button class="btn sm" data-a="restore">Restaurar</button><button class="btn sm" data-a="dl">Baixar</button><button class="btn sm danger" data-a="del">Excluir</button></div>';
        $('b', row).textContent = new Date(v.time).toLocaleString('pt-BR');
        $('small', row).textContent = v.label + ' · ' + v.files.length + ' arquivo(s)';
        $('[data-a=restore]', row).addEventListener('click', async () => {
          this.closeDialog();
          if (!(await this.confirm('Restaurar versão', 'Substituir os arquivos atuais pela versão de ' + new Date(v.time).toLocaleString('pt-BR') + '? Um backup do estado atual será criado antes.'))) return;
          await this.save(true, 'Backup antes de restaurar');
          const data = Object.assign({}, this.project.data, { files: JSON.parse(JSON.stringify(v.files)), openTabs: [], activeFile: null });
          this.openProjectData(data);
          await this.save(false);
          this.toast('Versão restaurada.');
        });
        $('[data-a=dl]', row).addEventListener('click', () => {
          const data = Object.assign({}, this.project.data, { files: v.files, name: this.project.name + ' ' + new Date(v.time).toISOString().slice(0, 16).replace(/[:T]/g, '-') });
          GF.download(new Blob([JSON.stringify(data, null, 1)], { type: 'application/json' }), safeFile(data.name) + '.gfproj');
        });
        $('[data-a=del]', row).addEventListener('click', async () => {
          await GF.Storage.deleteVersion(v.vid, this.project.id);
          row.remove();
        });
        body.appendChild(row);
      }
      this.dialog({ title: 'Versões e backups — ' + this.project.name, body, buttons: [{ label: 'Criar versão agora', value: 'snap' }, { label: 'Fechar', value: null, primary: true }] }).then(async (r) => {
        if (r === 'snap') { await this.save(true, 'Versão manual'); this.versionsDialog(); }
      });
    },

    // ---------------------------------------------------------------- importar / exportar
    pickImport() {
      const inp = $('#file-input');
      inp.value = '';
      inp.click();
    },

    async importFiles(fileList) {
      const files = Array.from(fileList || []);
      let added = 0;
      for (const f of files) {
        const name = f.name;
        try {
          if (/\.(gfproj|json)$/i.test(name)) {
            const data = JSON.parse(await f.text());
            await this.importProjectData(data);
            return;
          }
          if (/\.zip$/i.test(name)) {
            const entries = await GF.Zip.read(await f.arrayBuffer());
            const meta = entries.find((e) => e.path === 'gameforge-project.json' || e.path.endsWith('/gameforge-project.json'));
            const dec = new TextDecoder();
            if (meta) {
              const base = meta.path.slice(0, meta.path.length - 'gameforge-project.json'.length);
              const m = JSON.parse(dec.decode(meta.data));
              const disabled = new Set(m.disabled || []);
              const data = {
                id: GF.createProject().id, name: m.name || name.replace(/\.zip$/i, ''), created: Date.now(), modified: Date.now(),
                folders: m.folders || [],
                files: entries.filter((e) => e !== meta && e.path.startsWith(base + 'src/')).map((e) => {
                  const p = e.path.slice(base.length + 4);
                  return { path: p, source: dec.decode(e.data), disabled: disabled.has(p) };
                }),
              };
              const dsEntry = entries.find((e) => e.path === base + 'gameforge-data.json');
              if (dsEntry) { try { data.datastores = JSON.parse(dec.decode(dsEntry.data)); } catch (err) { /* ignora dados inválidos */ } }
              await this.importProjectData(data);
              return;
            }
            for (const e of entries) {
              if (!/\.(lua|luau|txt|md)$/i.test(e.path)) continue;
              const p = this.project.uniquePath(P.normalizePath(e.path));
              this.project.addFile(p, dec.decode(e.data));
              added++;
            }
            continue;
          }
          if (/\.(lua|luau|txt|md)$/i.test(name)) {
            const p = this.project.uniquePath(P.join(this.selectedFolder || 'Scripts', name));
            this.project.addFile(p, await f.text());
            added++;
            if (files.length === 1) this.openFile(p);
          } else {
            this.toast('Tipo de arquivo não suportado: ' + name, 'error');
          }
        } catch (e) {
          this.toast('Falha ao importar ' + name + ': ' + e.message, 'error');
        }
      }
      if (added) {
        this.renderTree();
        this.setDirty(true);
        this.toast(added + ' arquivo(s) importado(s).');
      }
    },

    async importProjectData(data) {
      if (!data || !Array.isArray(data.files)) throw new Error('Arquivo de projeto inválido.');
      if (!(await this.confirmDiscard())) return;
      const ds = data.datastores;
      data = {
        id: GF.createProject().id,
        name: String(data.name || 'Projeto importado'),
        created: Date.now(), modified: Date.now(),
        folders: Array.isArray(data.folders) ? data.folders.map(String) : [],
        files: data.files.filter((f) => f && f.path).map((f) => ({ path: P.normalizePath(f.path), source: String(f.source || ''), disabled: !!f.disabled })),
        openTabs: [], activeFile: null,
      };
      await GF.Storage.saveProject(data);
      if (ds && typeof ds === 'object') {
        for (const store of Object.keys(ds)) for (const key of Object.keys(ds[store] || {})) await GF.Storage.writeDataStore(data.id, store, key, ds[store][key]).catch(() => {});
      }
      this.openProjectData(data);
      this.toast('Projeto "' + data.name + '" importado.');
    },

    async exportZip() {
      this.syncFromEditor();
      const root = safeFile(this.project.name);
      const entries = this.project.files.map((f) => ({ path: root + '/src/' + f.path, data: f.source }));
      const ds = await GF.Storage.loadDataStores(this.project.id).catch(() => ({}));
      if (Object.keys(ds).length) entries.push({ path: root + '/gameforge-data.json', data: JSON.stringify(ds, null, 1) });
      entries.push({
        path: root + '/gameforge-project.json',
        data: JSON.stringify({ format: 'gameforge-project', version: 1, name: this.project.name, folders: this.project.data.folders, disabled: this.project.files.filter((f) => f.disabled).map((f) => f.path), exported: new Date().toISOString() }, null, 2),
      });
      entries.push({ path: root + '/LEIA-ME.txt', data: 'Projeto do GameForge Studio: ' + this.project.name + '\n\nOs scripts estão na pasta src/.\nPara abrir: GameForge Studio → Arquivo → Importar → selecione este .zip.\n' });
      GF.download(GF.Zip.make(entries), root + '.zip');
      this.toast('Projeto exportado como ZIP.');
    },

    exportGfproj() {
      this.syncFromEditor();
      const data = Object.assign({ format: 'gameforge-project', version: 1 }, this.project.data);
      GF.download(new Blob([JSON.stringify(data, null, 1)], { type: 'application/json' }), safeFile(this.project.name) + '.gfproj');
      this.toast('Projeto exportado (.gfproj).');
    },

    async exportGame() {
      this.syncFromEditor();
      this.toast('Montando o jogo…');
      try {
        const html = await GF.buildGameHtml(this.project.data);
        GF.download(new Blob([html], { type: 'text/html' }), safeFile(this.project.name) + '.html');
        this.toast('Jogo exportado: um único arquivo HTML que funciona offline.');
      } catch (e) {
        this.dialog({ title: 'Exportar jogo', body: e.message, buttons: [{ label: 'OK', value: null, primary: true }] });
      }
    },

    async clearData() {
      if (!(await this.confirm('Apagar dados do jogo', 'Apagar todos os dados gravados pelo DataStoreService deste projeto (pontuações, inventários salvos etc.)?', true))) return;
      await GF.Storage.clearDataStores(this.project.id);
      this.toast('Dados do DataStore apagados.');
    },

    async updateStorageInfo() {
      const list = await GF.Storage.listProjects().catch(() => []);
      $('#storage-info').textContent = 'Armazenamento local: ' + GF.Storage.backend + ' · ' + list.length + ' projeto(s)';
    },

    // ================================================================ arquivos
    openFile(path) {
      const f = this.project.file(path);
      if (!f) return;
      this.editor.open(path, f.source);
      if (this.isMobile()) this.setMobileTab('code');
    },

    closeTab(path) {
      const v = this.editor.getValue(path);
      const f = this.project.file(path);
      if (f && v != null) f.source = v;
      this.editor.close(path);
      this.setDirty(true);
    },

    onEditorChange() {
      this.setDirty(true);
      clearTimeout(this.outlineT);
      this.outlineT = setTimeout(() => { this.renderOutline(); this.updateFileStatus(); }, 400);
    },

    onActivate(path) {
      $('#cm-empty').hidden = !!path;
      this.renderOutline();
      this.updateFileStatus();
      $$('.tree-item.file').forEach((el) => el.classList.toggle('on', el.dataset.path === path));
    },

    updateFileStatus() {
      const path = this.editor.active;
      const f = path && this.project.file(path);
      const btn = $('#btn-toggle-disabled');
      if (!f) { $('#st-file').textContent = '—'; btn.disabled = true; $('#st-lang').textContent = ''; return; }
      const isLua = GF.scriptRules.isScriptFile(f.path);
      const isMod = isLua && GF.scriptRules.isModule({ path: f.path, source: this.editor.getValue(path) || f.source });
      $('#st-file').textContent = f.path + (isMod ? ' · módulo (require)' : f.disabled ? ' · desativado' : '');
      $('#st-lang').textContent = isLua ? 'Luau' : 'Texto';
      btn.disabled = !isLua || isMod;
      btn.textContent = isMod ? 'Módulo' : f.disabled ? 'Ativar' : 'Desativar';
      btn.title = isMod ? 'Módulos só rodam via require()' : f.disabled ? 'Este script NÃO roda ao executar. Clique para ativar.' : 'Clique para não executar este script.';
    },

    toggleDisabled(path) {
      const f = this.project.file(path || this.editor.active);
      if (!f) return;
      f.disabled = !f.disabled;
      this.setDirty(true);
      this.renderTree();
      this.updateFileStatus();
      this.toast(f.path + (f.disabled ? ' desativado.' : ' ativado.'));
    },

    async newFile(folder) {
      folder = folder != null ? folder : this.selectedFolder || 'Scripts';
      const body = document.createElement('div');
      body.innerHTML = '<label class="field">Nome do arquivo<input id="nf-name" value="NovoScript" maxlength="100"></label>' +
        '<label class="field">Extensão<select id="nf-ext"><option value=".luau">.luau</option><option value=".lua">.lua</option><option value=".txt">.txt (anotações)</option></select></label>' +
        '<label class="field">Pasta<select id="nf-dir"></select></label>';
      const sel = $('#nf-dir', body);
      ['', ...this.project.data.folders].forEach((d) => {
        const o = document.createElement('option');
        o.value = d;
        o.textContent = d || '(raiz)';
        if (d === folder) o.selected = true;
        sel.appendChild(o);
      });
      const r = await this.dialog({ title: 'Novo script', body, buttons: [{ label: 'Cancelar', value: null }, { label: 'Criar', value: 'ok', primary: true }], focus: '#nf-name', validate: () => {
        let n = $('#nf-name', body).value.trim();
        const err = P.validateName(n) || (n.includes('/') ? 'Use o campo Pasta para escolher a pasta.' : null);
        if (err) return err;
        n = n.replace(/\.(luau|lua|txt)$/i, '') + $('#nf-ext', body).value;
        if (this.project.exists(P.join(sel.value, n))) return 'Já existe um arquivo com esse nome.';
        return null;
      } });
      if (r !== 'ok') return;
      const ext = $('#nf-ext', body).value;
      const name = $('#nf-name', body).value.trim().replace(/\.(luau|lua|txt)$/i, '') + ext;
      const path = P.join(sel.value, name);
      const isModFolder = sel.value.split('/').some((s) => s.toLowerCase() === 'modules');
      const src = ext === '.txt' ? '' : isModFolder
        ? '-- Módulo ' + name + '\nlocal M = {}\n\nfunction M.exemplo()\n\treturn "ok"\nend\n\nreturn M\n'
        : '-- ' + name + '\n\n';
      try {
        this.project.addFile(path, src);
        this.renderTree();
        this.openFile(path);
        this.setDirty(true);
      } catch (e) { this.toast(e.message, 'error'); }
    },

    async newFolder(parent) {
      parent = parent != null ? parent : this.selectedFolder;
      const name = await this.prompt('Nova pasta', parent ? 'Nome da pasta dentro de "' + parent + '"' : 'Nome da pasta', 'NovaPasta');
      if (!name) return;
      try {
        this.project.addFolder(P.join(parent, name));
        this.collapsed.delete(parent);
        this.renderTree();
        this.setDirty(true);
      } catch (e) { this.toast(e.message, 'error'); }
    },

    async renameItem(path) {
      const isFile = !!this.project.file(path);
      const nv = await this.prompt(isFile ? 'Renomear arquivo' : 'Renomear pasta', 'Novo nome (ou caminho completo para mover)', path.includes('/') ? P.basename(path) : path);
      if (!nv) return;
      const target = nv.includes('/') ? nv : P.join(P.dirname(path), nv);
      this.syncFromEditor();
      try {
        const moved = this.project.rename(path, target);
        for (const [a, b] of moved) this.editor.rename(a, b);
        this.renderTree();
        this.updateFileStatus();
        this.setDirty(true);
      } catch (e) { this.toast(e.message, 'error'); }
    },

    async deleteItem(path) {
      const isFile = !!this.project.file(path);
      const ok = await this.confirm(isFile ? 'Excluir arquivo' : 'Excluir pasta', isFile ? 'Excluir "' + path + '"?' : 'Excluir a pasta "' + path + '" e todo o seu conteúdo?', true);
      if (!ok) return;
      this.syncFromEditor();
      const removed = this.project.remove(path);
      for (const p of removed) this.editor.remove(p);
      if (this.selectedFolder === path || this.selectedFolder.startsWith(path + '/')) this.selectedFolder = '';
      this.renderTree();
      this.setDirty(true);
      this.toast('Excluído. (Versões anteriores continuam disponíveis em Arquivo → Versões.)');
    },

    duplicateItem(path) {
      this.syncFromEditor();
      const f = this.project.file(path);
      if (!f) return;
      const np = this.project.uniquePath(path);
      this.project.addFile(np, f.source);
      this.renderTree();
      this.openFile(np);
      this.setDirty(true);
    },

    // ---------------------------------------------------------------- explorador
    renderTree() {
      const el = $('#tree');
      el.textContent = '';
      const tree = this.project.tree();
      const root = document.createElement('div');
      root.className = 'tree-item folder root' + (this.selectedFolder === '' ? ' sel' : '');
      root.innerHTML = '<span class="ti-ico">▣</span><span class="ti-name"></span>';
      $('.ti-name', root).textContent = this.project.name;
      root.addEventListener('click', () => { this.selectedFolder = ''; this.renderTree(); });
      el.appendChild(root);
      const walk = (node, depth) => {
        const folders = [...node.folders.values()].sort((a, b) => a.name.localeCompare(b.name));
        for (const d of folders) {
          const row = document.createElement('div');
          const closed = this.collapsed.has(d.path);
          row.className = 'tree-item folder' + (this.selectedFolder === d.path ? ' sel' : '');
          row.style.paddingLeft = 8 + depth * 14 + 'px';
          row.setAttribute('role', 'treeitem');
          row.setAttribute('aria-expanded', String(!closed));
          row.innerHTML = '<span class="ti-caret">' + (closed ? '▸' : '▾') + '</span><span class="ti-ico fold"></span><span class="ti-name"></span><button class="ti-more" aria-label="Ações da pasta">⋯</button>';
          $('.ti-name', row).textContent = d.name + (d.name.toLowerCase() === 'modules' ? '  (módulos)' : '');
          row.addEventListener('click', (e) => {
            if (e.target.closest('.ti-more')) return;
            if (this.selectedFolder === d.path || e.target.closest('.ti-caret')) {
              if (closed) this.collapsed.delete(d.path); else this.collapsed.add(d.path);
            }
            this.selectedFolder = d.path;
            this.renderTree();
          });
          $('.ti-more', row).addEventListener('click', (e) => { e.stopPropagation(); this.itemMenu(e.currentTarget, d.path, false); });
          el.appendChild(row);
          if (!closed) walk(d, depth + 1);
        }
        const files = node.files.slice().sort((a, b) => a.path.localeCompare(b.path));
        for (const f of files) {
          const row = document.createElement('div');
          const isLua = GF.scriptRules.isScriptFile(f.path);
          const isMod = isLua && GF.scriptRules.isModule(f);
          row.className = 'tree-item file' + (f.path === this.editor.active ? ' on' : '') + (f.disabled ? ' disabled' : '');
          row.dataset.path = f.path;
          row.style.paddingLeft = 8 + depth * 14 + 14 + 'px';
          row.setAttribute('role', 'treeitem');
          row.innerHTML = '<span class="ti-ico ' + (isLua ? (isMod ? 'mod' : 'lua') : 'txt') + '"></span><span class="ti-name"></span><span class="ti-tag"></span><button class="ti-more" aria-label="Ações do arquivo">⋯</button>';
          $('.ti-name', row).textContent = P.basename(f.path);
          $('.ti-tag', row).textContent = f.disabled ? 'desativado' : isMod ? 'módulo' : '';
          row.title = f.path + (isMod ? ' — módulo: roda apenas via require()' : f.disabled ? ' — desativado' : isLua ? ' — roda ao executar' : '');
          row.addEventListener('click', (e) => {
            if (e.target.closest('.ti-more')) return;
            this.selectedFolder = P.dirname(f.path);
            this.openFile(f.path);
            $$('.tree-item.folder.sel').forEach((x) => x.classList.remove('sel'));
          });
          row.addEventListener('contextmenu', (e) => { e.preventDefault(); this.itemMenu(row, f.path, true); });
          $('.ti-more', row).addEventListener('click', (e) => { e.stopPropagation(); this.itemMenu(e.currentTarget, f.path, true); });
          el.appendChild(row);
        }
      };
      walk(tree, 0);
    },

    itemMenu(anchor, path, isFile) {
      const f = isFile ? this.project.file(path) : null;
      const items = isFile
        ? [
            ['Abrir', () => this.openFile(path)],
            ['Renomear / mover…', () => this.renameItem(path)],
            ['Duplicar', () => this.duplicateItem(path)],
            GF.scriptRules.isScriptFile(path) && !GF.scriptRules.isModule(f) ? [f.disabled ? 'Ativar na execução' : 'Desativar na execução', () => this.toggleDisabled(path)] : null,
            ['Baixar arquivo', () => { this.syncFromEditor(); GF.download(new Blob([f.source], { type: 'text/plain' }), P.basename(path)); }],
            ['Excluir', () => this.deleteItem(path), true],
          ]
        : [
            ['Novo script aqui…', () => this.newFile(path)],
            ['Nova pasta aqui…', () => this.newFolder(path)],
            ['Renomear / mover…', () => this.renameItem(path)],
            ['Excluir pasta', () => this.deleteItem(path), true],
          ];
      this.popMenu(anchor, items.filter(Boolean));
    },

    popMenu(anchor, items) {
      this.closePop();
      const m = document.createElement('div');
      m.className = 'menu pop';
      m.setAttribute('role', 'menu');
      for (const [label, fn, danger] of items) {
        const b = document.createElement('button');
        b.textContent = label;
        b.setAttribute('role', 'menuitem');
        if (danger) b.className = 'danger';
        b.addEventListener('click', () => { this.closePop(); fn(); });
        m.appendChild(b);
      }
      document.body.appendChild(m);
      const r = anchor.getBoundingClientRect();
      const mw = m.offsetWidth, mh = m.offsetHeight;
      m.style.left = Math.max(4, Math.min(window.innerWidth - mw - 4, r.right - mw)) + 'px';
      m.style.top = (r.bottom + mh + 4 > window.innerHeight ? Math.max(4, r.top - mh - 2) : r.bottom + 2) + 'px';
      this.pop = m;
      setTimeout(() => m.querySelector('button').focus(), 0);
    },
    closePop() { if (this.pop) { this.pop.remove(); this.pop = null; } },

    renderOutline() {
      const el = $('#outline');
      el.textContent = '';
      const list = this.editor.outline();
      if (!list.length) { el.innerHTML = '<p class="muted sm">Nenhuma função neste arquivo.</p>'; return; }
      for (const fn of list) {
        const b = document.createElement('button');
        b.className = 'ol-item';
        b.innerHTML = '<span class="ol-name"></span><span class="ol-line"></span>';
        $('.ol-name', b).textContent = fn.name + '(' + fn.args + ')';
        $('.ol-line', b).textContent = fn.line;
        b.addEventListener('click', () => { this.editor.gotoLine(this.editor.active, fn.line); if (this.isMobile()) this.setMobileTab('code'); });
        el.appendChild(b);
      }
    },

    globalSearch() {
      const q = $('#gsearch-input').value;
      const out = $('#gsearch-res');
      out.textContent = '';
      if (!q) return;
      this.syncFromEditor();
      const cs = $('#gsearch-case').checked, ww = $('#gsearch-word').checked;
      const esc = q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const re = new RegExp(ww ? '\\b' + esc + '\\b' : esc, cs ? 'g' : 'gi');
      let total = 0;
      for (const f of this.project.files) {
        const lines = f.source.split('\n');
        const hits = [];
        lines.forEach((ln, i) => { re.lastIndex = 0; if (re.test(ln)) hits.push(i); });
        if (!hits.length) continue;
        total += hits.length;
        const h = document.createElement('div');
        h.className = 'gs-file';
        h.textContent = f.path + ' (' + hits.length + ')';
        out.appendChild(h);
        for (const i of hits.slice(0, 50)) {
          const b = document.createElement('button');
          b.className = 'gs-hit';
          const ln = document.createElement('span');
          ln.className = 'gs-ln';
          ln.textContent = i + 1;
          const tx = document.createElement('span');
          const text = lines[i].trim().slice(0, 140);
          re.lastIndex = 0;
          let last = 0, m;
          while ((m = re.exec(text)) && m[0]) {
            tx.appendChild(document.createTextNode(text.slice(last, m.index)));
            const mk = document.createElement('mark');
            mk.textContent = m[0];
            tx.appendChild(mk);
            last = m.index + m[0].length;
          }
          tx.appendChild(document.createTextNode(text.slice(last)));
          b.append(ln, tx);
          b.addEventListener('click', () => this.gotoLocation(f.path, i + 1));
          out.appendChild(b);
        }
      }
      if (!total) out.innerHTML = '<p class="muted sm">Nada encontrado.</p>';
    },

    gotoLocation(path, line) {
      if (!this.project.file(path)) return;
      this.setMode('editor');
      if (!this.editor.isOpen(path)) this.openFile(path);
      if (this.isMobile()) this.setMobileTab('code');
      setTimeout(() => this.editor.gotoLine(path, line), 30);
    },

    // ================================================================ execução
    async run() {
      if (!this.runner) { this.toast('O motor 3D não está disponível neste dispositivo (WebGL).', 'error'); return; }
      this.syncFromEditor();
      this.closePop();
      return this.startGame(this.project.files.map((f) => ({ path: f.path, source: f.source, disabled: f.disabled })));
    },

    async startGame(files) {
      if (this.settings.clearOnRun) this.console.clear();
      this.editor.clearRuntimeErrors();
      this.editor.blur();
      if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
      try {
        await this.runner.ready();
      } catch (e) {
        this.console.log('error', 'VM Luau indisponível: ' + e.message);
        return;
      }
      const data = await GF.Storage.loadDataStores(this.project.id).catch(() => ({}));
      const pid = this.project.id;
      this.engine.opts.datastore = { data, write: (s, k, v) => GF.Storage.writeDataStore(pid, s, k, v).catch(() => {}) };
      this.setRunning(true);
      if (this.isMobile()) this.setMobileTab('game');
      this.console.log('info', '▶ Executando "' + this.project.name + '" — scripts: ' + GF.scriptRules.runnableScripts(files).map((f) => f.path).join(', '));
      try {
        const ok = await this.runner.run(files);
        if (!ok && !this.runner.running) this.setRunning(false);
      } catch (e) {
        this.console.log('error', e.message);
        this.setRunning(false);
      }
      $('#viewport').focus({ preventScroll: true });
    },

    stop() {
      if (this.runner && this.runner.running) this.runner.stop('user');
    },

    onStopped(reason) {
      if (reason === 'restart') return;
      this.setRunning(false);
      if (reason === 'user') this.console.log('info', '■ Execução interrompida.');
      else if (reason === 'fatal') this.console.log('warn', '■ Execução encerrada por erro.');
      else if (reason === 'kick') this.console.log('warn', '■ Jogo encerrado (Kick).');
    },

    setRunning(r) {
      this.running = r;
      $('#btn-stop').disabled = !r;
      $('#btn-run span').textContent = r ? 'Reiniciar' : 'Executar';
      $('#run-dot').classList.toggle('on', r);
      this.app.classList.toggle('is-running', r);
      if (!r) $('#mem-info').textContent = '';
    },

    onRuntimeError(msg, tb) {
      this.console.log('error', msg, tb && tb.trim() ? tb.trim() : null);
      const re = /([A-Za-z0-9_\-. À-ÿ/()]+?\.luau?):(\d+)/g;
      let m;
      while ((m = re.exec(msg))) {
        const p = m[1].trim();
        if (this.project.file(p)) {
          if (!this.editor.isOpen(p)) this.editor.open(p, this.project.file(p).source);
          this.editor.setRuntimeError(p, +m[2], msg.slice(m.index + m[0].length).replace(/^:\s*/, ''));
          break;
        }
      }
      if (this.isMobile() && this.mtab !== 'console') this.flashConsoleTab();
    },

    updateMem() {
      if (!this.running || !this.runner) return;
      const kb = this.runner.memoryKB();
      const st = this.engine.stats();
      $('#mem-info').textContent = 'Luau ' + (kb / 1024).toFixed(1) + ' MB · ' + st.instances + ' obj';
    },

    runSnippet(code) {
      if (!this.runner) return;
      this.setMode('editor');
      this.syncFromEditor();
      const mods = this.project.files.filter((f) => GF.scriptRules.isScriptFile(f.path) && GF.scriptRules.isModule(f));
      this.startGame([{ path: 'Manual/Exemplo.luau', source: code, disabled: false }, ...mods]);
      this.toast('Exemplo do manual em execução na janela de teste.');
    },

    async sendToEditor(code, mode, title) {
      this.setMode('editor');
      if (mode === 'replace' && this.editor.active && GF.scriptRules.isScriptFile(this.editor.active)) {
        const ok = await this.confirm('Substituir script', 'Substituir todo o conteúdo de "' + this.editor.active + '" pelo exemplo? (Use Ctrl+Z para desfazer.)');
        if (!ok) return;
        this.editor.setValue(this.editor.active, code);
        this.toast('Exemplo colocado em ' + this.editor.active + '.');
      } else {
        const base = 'Scripts/' + (title ? safeFile(title).slice(0, 40) : 'Exemplo') + '.luau';
        const path = this.project.uniquePath(base);
        this.project.addFile(path, code);
        this.renderTree();
        this.openFile(path);
        this.setDirty(true);
        this.toast('Exemplo criado em ' + path + '. Os outros scripts ativos também rodam ao executar.');
      }
      if (this.isMobile()) this.setMobileTab('code');
    },

    // ================================================================ interface
    bindUi() {
      // menu Arquivo
      const menuBtn = $('#btn-menu'), menu = $('#file-menu');
      menuBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const open = menu.hidden;
        menu.hidden = !open;
        menuBtn.setAttribute('aria-expanded', String(open));
      });
      document.addEventListener('click', (e) => {
        if (!e.target.closest('#file-menu')) { menu.hidden = true; menuBtn.setAttribute('aria-expanded', 'false'); }
        if (this.pop && !e.target.closest('.menu.pop') && !e.target.closest('.ti-more')) this.closePop();
      });
      $$('[data-act]').forEach((b) => b.addEventListener('click', () => { menu.hidden = true; this.action(b.dataset.act); }));
      $('#proj-name').addEventListener('click', () => this.renameProject());

      $('#btn-run').addEventListener('click', () => this.run());
      $('#btn-stop').addEventListener('click', () => this.stop());
      $('#btn-settings').addEventListener('click', () => this.settingsDialog());
      $$('.seg [data-mode]').forEach((b) => b.addEventListener('click', () => this.setMode(b.dataset.mode)));
      $$('#mtabs [data-mtab]').forEach((b) => b.addEventListener('click', () => this.setMobileTab(b.dataset.mtab)));

      // ferramentas do editor
      $$('[data-ed]').forEach((b) => {
        b.addEventListener('pointerdown', (e) => { if (b.closest('.extra-keys')) e.preventDefault(); });
        b.addEventListener('click', () => this.editor.exec(b.dataset.ed));
      });
      $$('#extra-keys [data-k]').forEach((b) => {
        b.addEventListener('pointerdown', (e) => e.preventDefault());
        b.addEventListener('click', () => this.editor.insert(b.dataset.k === '\\t' ? '\t' : b.dataset.k));
      });
      $$('#extra-keys [data-mv]').forEach((b) => {
        b.addEventListener('pointerdown', (e) => e.preventDefault());
        b.addEventListener('click', () => this.editor.moveCursor(+b.dataset.mv));
      });
      $('#btn-toggle-disabled').addEventListener('click', () => this.toggleDisabled());

      // console
      $('#console-filter').addEventListener('change', (e) => this.console.setFilter(e.target.value));
      $('#btn-console-clear').addEventListener('click', () => this.console.clear());
      $('#btn-console-copy').addEventListener('click', async () => {
        try { await navigator.clipboard.writeText(this.console.text()); this.toast('Console copiado.'); } catch (e) { this.toast('Não foi possível copiar.', 'error'); }
      });
      const hist = [];
      let hi = 0;
      $('#repl').addEventListener('submit', (e) => {
        e.preventDefault();
        const inp = $('#repl-input');
        const code = inp.value.trim();
        if (!code) return;
        hist.push(code);
        hi = hist.length;
        inp.value = '';
        this.console.log('input', '> ' + code);
        if (!this.runner) return;
        const err = this.runner.repl(code);
        if (err) this.console.log(this.runner.running ? 'error' : 'warn', err);
      });
      $('#repl-input').addEventListener('keydown', (e) => {
        if (e.key === 'ArrowUp' && hi > 0) { hi--; e.target.value = hist[hi]; e.preventDefault(); }
        if (e.key === 'ArrowDown') { hi = Math.min(hist.length, hi + 1); e.target.value = hist[hi] || ''; e.preventDefault(); }
      });

      // jogo
      $('#btn-fullscreen').addEventListener('click', () => {
        const v = $('#pane-game');
        if (document.fullscreenElement) document.exitFullscreen();
        else if (v.requestFullscreen) v.requestFullscreen().catch(() => this.toast('Tela cheia não permitida.', 'error'));
      });

      // pesquisa global
      let gt;
      $('#gsearch-input').addEventListener('input', () => { clearTimeout(gt); gt = setTimeout(() => this.globalSearch(), 250); });
      $('#gsearch-case').addEventListener('change', () => this.globalSearch());
      $('#gsearch-word').addEventListener('change', () => this.globalSearch());

      // importar
      $('#file-input').addEventListener('change', (e) => this.importFiles(e.target.files));
      // arrastar e soltar arquivos
      document.addEventListener('dragover', (e) => { if (e.dataTransfer && [...e.dataTransfer.types].includes('Files')) e.preventDefault(); });
      document.addEventListener('drop', (e) => {
        if (e.dataTransfer && e.dataTransfer.files.length) { e.preventDefault(); this.importFiles(e.dataTransfer.files); }
      });

      // atalhos
      window.addEventListener('keydown', (e) => {
        const mod = e.ctrlKey || e.metaKey;
        if (mod && !e.shiftKey && e.key.toLowerCase() === 's') { e.preventDefault(); this.save(true); }
        else if (mod && e.key.toLowerCase() === 'o') { e.preventDefault(); this.openDialog(); }
        else if (mod && e.altKey && e.key.toLowerCase() === 'n') { e.preventDefault(); this.newProject(); }
        else if (e.key === 'F5' && !e.shiftKey) { e.preventDefault(); this.run(); }
        else if (e.key === 'F5' && e.shiftKey) { e.preventDefault(); this.stop(); }
        else if (e.key === 'Escape') { this.closePop(); }
      });
      window.addEventListener('beforeunload', (e) => {
        if (this.dirty) {
          this.syncFromEditor();
          GF.Storage.saveProject(this.project.data);
          if (!this.settings.autosave) { e.preventDefault(); e.returnValue = ''; }
        }
      });
      document.addEventListener('visibilitychange', () => { if (document.hidden && this.dirty && this.settings.autosave) this.save(false); });

      // splitters
      $$('.splitter').forEach((s) => this.bindSplitter(s));
      window.addEventListener('resize', () => { this.updateExtraKeys(); this.editor.refresh(); });

      // modal
      $('#modal-x').addEventListener('click', () => this.closeDialog(null));
      $('#modal-bg').addEventListener('pointerdown', (e) => { if (e.target.id === 'modal-bg') this.closeDialog(null); });
    },

    action(a) {
      const map = {
        new: () => this.newProject(),
        open: () => this.openDialog(),
        save: () => this.save(true),
        saveas: () => this.saveAs(),
        'rename-project': () => this.renameProject(),
        'new-file': () => this.newFile(),
        'new-folder': () => this.newFolder(),
        import: () => this.pickImport(),
        'export-zip': () => this.exportZip(),
        'export-gfproj': () => this.exportGfproj(),
        'export-game': () => this.exportGame(),
        versions: () => this.versionsDialog(),
        'clear-data': () => this.clearData(),
        collapse: () => { this.project.data.folders.forEach((d) => this.collapsed.add(d)); this.renderTree(); },
      };
      if (map[a]) map[a]();
    },

    setMode(m) {
      if (this.mode === m) return;
      this.mode = m;
      this.app.dataset.mode = m;
      $('#mode-editor').hidden = m !== 'editor';
      $('#mode-manual').hidden = m !== 'manual';
      $$('.seg [data-mode]').forEach((b) => { b.classList.toggle('on', b.dataset.mode === m); b.setAttribute('aria-selected', String(b.dataset.mode === m)); });
      if (m === 'editor') setTimeout(() => this.editor.refresh(), 0);
      if (m === 'manual') this.manual.show();
    },

    isMobile() { return window.innerWidth < 900; },

    setMobileTab(t) {
      this.mtab = t;
      this.app.dataset.mtab = t;
      $$('#mtabs [data-mtab]').forEach((b) => b.classList.toggle('on', b.dataset.mtab === t));
      if (t === 'code') setTimeout(() => this.editor.refresh(), 0);
      if (t === 'console') $('#mtabs [data-mtab=console]').classList.remove('flash');
    },

    flashConsoleTab() { $('#mtabs [data-mtab=console]').classList.add('flash'); },

    setErrorBadge(n) {
      for (const id of ['#err-badge', '#err-badge-m']) {
        const b = $(id);
        b.hidden = !n;
        b.textContent = n > 99 ? '99+' : n;
      }
    },

    updateExtraKeys() {
      const s = this.settings.extraKeys;
      const show = s === 'on' || (s === 'auto' && (this.isMobile() || window.matchMedia('(pointer: coarse)').matches));
      $('#extra-keys').hidden = !show;
    },

    applyLayout() {
      const L = this.settings.layout;
      const st = document.documentElement.style;
      st.setProperty('--files-w', L.files + 'px');
      st.setProperty('--right-w', L.right + '%');
      st.setProperty('--console-h', L.console + '%');
    },

    bindSplitter(s) {
      const kind = s.dataset.split;
      s.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        s.setPointerCapture(e.pointerId);
        s.classList.add('drag');
        const main = $('#mode-editor').getBoundingClientRect();
        const right = $('#right-col').getBoundingClientRect();
        const move = (ev) => {
          const L = this.settings.layout;
          if (kind === 'files') L.files = Math.round(Math.max(150, Math.min(420, ev.clientX - main.left)));
          else if (kind === 'right') L.right = Math.round(Math.max(22, Math.min(70, ((main.right - ev.clientX) / main.width) * 100)));
          else if (kind === 'console') L.console = Math.round(Math.max(12, Math.min(80, ((right.bottom - ev.clientY) / right.height) * 100)));
          this.applyLayout();
        };
        const up = () => {
          s.classList.remove('drag');
          s.removeEventListener('pointermove', move);
          s.removeEventListener('pointerup', up);
          s.removeEventListener('pointercancel', up);
          this.editor.refresh();
          GF.Storage.setSetting('settings', this.settings).catch(() => {});
        };
        s.addEventListener('pointermove', move);
        s.addEventListener('pointerup', up);
        s.addEventListener('pointercancel', up);
      });
    },

    // ---------------------------------------------------------------- configurações
    async settingsDialog() {
      const s = this.settings;
      const body = document.createElement('form');
      body.className = 'settings';
      body.innerHTML = `
        <h3>Editor</h3>
        <label class="field row">Tamanho da fonte <input type="number" name="fontSize" min="10" max="28" value="${s.fontSize}"></label>
        <label class="field row">Tamanho da indentação <select name="tabSize"><option>2</option><option>4</option><option>8</option></select></label>
        <label class="chk"><input type="checkbox" name="wrap"> Quebra de linha automática</label>
        <label class="chk"><input type="checkbox" name="autocomplete"> Autocompletar enquanto digita</label>
        <label class="chk"><input type="checkbox" name="lint"> Mostrar erros de sintaxe (compilador Luau)</label>
        <label class="field row">Teclas extras (celular) <select name="extraKeys"><option value="auto">Automático</option><option value="on">Sempre</option><option value="off">Nunca</option></select></label>
        <h3>Projeto</h3>
        <label class="chk"><input type="checkbox" name="autosave"> Salvamento automático</label>
        <label class="chk"><input type="checkbox" name="clearOnRun"> Limpar o console ao executar</label>
        <h3>Jogo</h3>
        <label class="chk"><input type="checkbox" name="shadows"> Sombras</label>
        <label class="field row">Qualidade gráfica <select name="quality"><option value="auto">Automática</option><option value="low">Baixa (celulares fracos)</option><option value="high">Alta</option></select></label>
        <label class="chk"><input type="checkbox" name="showFps"> Mostrar FPS</label>
        <label class="field row">Volume <input type="range" name="volume" min="0" max="1" step="0.05" value="${s.volume}"></label>
        <p class="muted sm">Armazenamento: ${GF.Storage.backend}. Todas as bibliotecas (Three.js, CodeMirror, VM Luau) são locais e funcionam offline.</p>`;
      body.tabSize.value = String(s.tabSize);
      body.extraKeys.value = s.extraKeys;
      body.quality.value = s.quality;
      for (const k of ['wrap', 'autocomplete', 'lint', 'autosave', 'clearOnRun', 'shadows', 'showFps']) body[k].checked = !!s[k];
      const r = await this.dialog({ title: 'Configurações', body, buttons: [{ label: 'Restaurar padrão', value: 'reset' }, { label: 'Cancelar', value: null }, { label: 'Aplicar', value: 'ok', primary: true }] });
      if (r === 'reset') {
        this.settings = Object.assign({}, DEFAULT_SETTINGS, { layout: Object.assign({}, DEFAULT_SETTINGS.layout) });
      } else if (r === 'ok') {
        s.fontSize = Math.max(10, Math.min(28, +body.fontSize.value || 14));
        s.tabSize = +body.tabSize.value;
        s.extraKeys = body.extraKeys.value;
        s.quality = body.quality.value;
        s.volume = +body.volume.value;
        for (const k of ['wrap', 'autocomplete', 'lint', 'autosave', 'clearOnRun', 'shadows', 'showFps']) s[k] = body[k].checked;
      } else return;
      this.editor.applySettings(this.settings);
      if (this.engine) this.engine.applySettings(this.engineSettings());
      this.applyLayout();
      this.updateExtraKeys();
      await GF.Storage.setSetting('settings', this.settings).catch(() => {});
      this.toast('Configurações aplicadas.');
    },

    // ---------------------------------------------------------------- diálogos
    dialog(o) {
      return new Promise((resolve) => {
        if (this.dialogResolve) this.dialogResolve(null);
        this.dialogResolve = resolve;
        $('#modal-title').textContent = o.title;
        const body = $('#modal-body');
        body.textContent = '';
        if (typeof o.body === 'string') { const p = document.createElement('p'); p.textContent = o.body; body.appendChild(p); } else if (o.body) body.appendChild(o.body);
        const err = document.createElement('p');
        err.className = 'form-err';
        err.hidden = true;
        body.appendChild(err);
        const foot = $('#modal-foot');
        foot.textContent = '';
        let primary = null;
        for (const b of o.buttons || []) {
          const el = document.createElement('button');
          el.type = 'button';
          el.className = 'btn' + (b.primary ? ' primary' : '') + (b.danger ? ' danger' : '');
          el.textContent = b.label;
          el.addEventListener('click', () => {
            if (b.primary && o.validate) {
              const msg = o.validate();
              if (msg) { err.textContent = msg; err.hidden = false; return; }
            }
            this.closeDialog(b.value);
          });
          if (b.primary) primary = el;
          foot.appendChild(el);
        }
        body.onkeydown = (e) => {
          if (e.key === 'Enter' && e.target.tagName === 'INPUT' && e.target.type !== 'checkbox' && primary) { e.preventDefault(); primary.click(); }
        };
        $('#modal-bg').hidden = false;
        this.modalKey = (e) => { if (e.key === 'Escape') this.closeDialog(null); };
        document.addEventListener('keydown', this.modalKey);
        setTimeout(() => {
          const f = o.focus ? $(o.focus, body) : primary || $('#modal-x');
          if (f) { f.focus(); if (f.select) f.select(); }
        }, 30);
      });
    },

    closeDialog(v) {
      $('#modal-bg').hidden = true;
      document.removeEventListener('keydown', this.modalKey);
      const r = this.dialogResolve;
      this.dialogResolve = null;
      if (r) r(v === undefined ? null : v);
    },

    async prompt(title, label, def) {
      const body = document.createElement('div');
      body.innerHTML = '<label class="field"><span></span><input id="pr-in" maxlength="120"></label>';
      $('span', body).textContent = label;
      $('#pr-in', body).value = def || '';
      const r = await this.dialog({ title, body, focus: '#pr-in', buttons: [{ label: 'Cancelar', value: null }, { label: 'OK', value: 'ok', primary: true }], validate: () => ($('#pr-in', body).value.trim() ? null : 'Digite um nome.') });
      return r === 'ok' ? $('#pr-in', body).value.trim() : null;
    },

    async confirm(title, msg, danger) {
      const r = await this.dialog({ title, body: msg, buttons: [{ label: 'Cancelar', value: false }, { label: danger ? 'Excluir' : 'Confirmar', value: true, primary: !danger, danger: !!danger }] });
      return r === true;
    },

    toast(msg, kind) {
      const box = $('#toast-box');
      const t = document.createElement('div');
      t.className = 'toast' + (kind ? ' ' + kind : '');
      t.textContent = msg;
      box.appendChild(t);
      setTimeout(() => t.classList.add('out'), kind === 'error' ? 5000 : 2800);
      setTimeout(() => t.remove(), kind === 'error' ? 5400 : 3200);
      while (box.children.length > 4) box.firstChild.remove();
    },
  };

  function safeFile(name) {
    return String(name).replace(/[\\/:*?"<>|]+/g, '_').trim() || 'projeto';
  }

  GF.App = App;
  window.addEventListener('DOMContentLoaded', () => {
    App.init().catch((e) => {
      console.error(e);
      document.body.insertAdjacentHTML('afterbegin', '<div style="background:#a22;color:#fff;padding:10px;font:14px sans-serif">Erro ao iniciar o GameForge Studio: ' + String(e.message).replace(/</g, '&lt;') + '</div>');
    });
  });
})();
