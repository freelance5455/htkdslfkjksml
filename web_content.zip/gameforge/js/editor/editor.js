/*
 * GameForge Studio — editor de código (CodeMirror 5 + modo Luau).
 * Gerencia abas, documentos, verificação de erros (compilador Luau real),
 * marcadores de erros de execução, localizar/substituir e estrutura de funções.
 */
(function () {
  'use strict';
  /* global CodeMirror */
  const GF = (window.GF = window.GF || {});

  const PHRASES = {
    'Search:': 'Localizar:',
    '(Use /re/ syntax for regexp search)': '(use /expr/ para expressão regular)',
    'Replace:': 'Substituir:',
    'Replace all:': 'Substituir tudo:',
    'With:': 'Por:',
    'Replace with:': 'Substituir por:',
    'Replace?': 'Substituir?',
    Yes: 'Sim',
    No: 'Não',
    All: 'Todos',
    Stop: 'Parar',
    'Jump to line:': 'Ir para a linha:',
    '(Use line:column or scroll% syntax)': '(use linha:coluna)',
  };

  class CodeEditor {
    /**
     * @param {HTMLElement} host  elemento onde o editor será montado
     * @param {HTMLElement} tabsEl  barra de abas
     * @param {object} opts {settings, checker(src)->{line,message}|null, onChange(path), onActivate(path), onCursor(line,col), onCloseTab(path)}
     */
    constructor(host, tabsEl, opts) {
      this.host = host;
      this.tabsEl = tabsEl;
      this.opts = opts;
      this.docs = new Map(); // path -> {doc, savedGen, runtimeErrors:[]}
      this.tabs = []; // ordem das abas
      this.active = null;
      this.settings = Object.assign({ fontSize: 14, tabSize: 4, wrap: false, autocomplete: true, lint: true }, opts.settings || {});
      this.emptyDoc = CodeMirror.Doc('', 'luau');
      this.cm = CodeMirror(host, {
        value: this.emptyDoc,
        mode: 'luau',
        theme: 'gameforge',
        lineNumbers: true,
        indentUnit: this.settings.tabSize,
        tabSize: this.settings.tabSize,
        indentWithTabs: false,
        smartIndent: true,
        electricChars: true,
        matchBrackets: true,
        autoCloseBrackets: { pairs: '()[]{}""\'\'``', explode: '[]{}()' },
        styleActiveLine: true,
        lineWrapping: this.settings.wrap,
        foldGutter: true,
        gutters: ['CodeMirror-lint-markers', 'CodeMirror-linenumbers', 'CodeMirror-foldgutter'],
        lint: false,
        phrases: PHRASES,
        inputStyle: 'contenteditable',
        spellcheck: false,
        autocorrect: false,
        autocapitalize: false,
        readOnly: 'nocursor',
        viewportMargin: 30,
        extraKeys: {
          Tab: (cm) => {
            if (cm.somethingSelected()) cm.indentSelection('add');
            else cm.replaceSelection(' '.repeat(cm.getOption('indentUnit')), 'end');
          },
          'Shift-Tab': (cm) => cm.indentSelection('subtract'),
          'Ctrl-Space': (cm) => this.showHint(true),
          'Ctrl-/': 'toggleComment',
          'Cmd-/': 'toggleComment',
          'Ctrl-F': 'findPersistent',
          'Cmd-F': 'findPersistent',
          'Ctrl-H': 'replace',
          'Shift-Ctrl-F': 'replace',
          'Cmd-Alt-F': 'replace',
          'Ctrl-G': 'jumpToLine',
          'Ctrl-Q': (cm) => cm.foldCode(cm.getCursor()),
          F3: 'findPersistentNext',
          'Shift-F3': 'findPersistentPrev',
          Esc: 'clearSearch',
        },
      });
      this.applySettings(this.settings);
      this.cm.on('changes', () => {
        if (!this.active) return;
        const d = this.docs.get(this.active);
        if (d.runtimeErrors.length) { d.runtimeErrors = []; }
        this.renderTabs();
        if (this.opts.onChange) this.opts.onChange(this.active);
      });
      this.cm.on('cursorActivity', () => {
        const c = this.cm.getCursor();
        if (this.opts.onCursor) this.opts.onCursor(c.line + 1, c.ch + 1);
      });
      this.cm.on('inputRead', (cm, change) => {
        if (!this.settings.autocomplete || cm.state.completionActive) return;
        const t = change.text[change.text.length - 1];
        if (/^[A-Za-z_.:"']$/.test(t)) this.showHint(false);
      });
    }

    showHint(manual) {
      this.cm.showHint({
        hint: GF.luauHint,
        completeSingle: false,
        closeCharacters: /[\s()[\]{};>,=+\-*/]/,
        alignWithWord: true,
        container: document.body,
        _manual: manual,
      });
    }

    applySettings(s) {
      Object.assign(this.settings, s);
      const cm = this.cm;
      cm.setOption('tabSize', +this.settings.tabSize);
      cm.setOption('indentUnit', +this.settings.tabSize);
      cm.setOption('lineWrapping', !!this.settings.wrap);
      cm.getWrapperElement().style.fontSize = this.settings.fontSize + 'px';
      cm.setOption('lint', this.settings.lint ? { getAnnotations: (text) => this.lint(text), delay: 400, tooltips: true } : false);
      cm.refresh();
    }

    lint(text) {
      const out = [];
      if (!this.active) return out;
      const d = this.docs.get(this.active);
      const isScript = /\.(luau|lua)$/i.test(this.active);
      if (isScript && this.opts.checker) {
        const e = this.opts.checker(text);
        if (e) {
          const ln = Math.max(0, Math.min(e.line - 1, this.cm.lineCount() - 1));
          out.push({ from: CodeMirror.Pos(ln, 0), to: CodeMirror.Pos(ln, this.cm.getLine(ln).length), message: 'Erro de sintaxe: ' + e.message, severity: 'error' });
        }
      }
      for (const r of d ? d.runtimeErrors : []) {
        const ln = Math.max(0, Math.min(r.line - 1, this.cm.lineCount() - 1));
        out.push({ from: CodeMirror.Pos(ln, 0), to: CodeMirror.Pos(ln, this.cm.getLine(ln).length), message: 'Erro de execução: ' + r.message, severity: 'error' });
      }
      if (this.opts.onLint) this.opts.onLint(this.active, out.length);
      return out;
    }

    // -------------------------------------------------------------- documentos
    open(path, source) {
      if (!this.docs.has(path)) {
        const doc = CodeMirror.Doc(source, /\.(luau|lua)$/i.test(path) ? 'luau' : 'text/plain');
        this.docs.set(path, { doc, savedGen: doc.changeGeneration(true), runtimeErrors: [] });
      }
      if (!this.tabs.includes(path)) this.tabs.push(path);
      this.activate(path);
    }

    activate(path) {
      const d = this.docs.get(path);
      if (!d) return;
      this.active = path;
      this.cm.swapDoc(d.doc);
      this.cm.setOption('readOnly', false);
      this.cm.setOption('mode', d.doc.getMode().name === 'luau' ? 'luau' : 'text/plain');
      this.renderTabs();
      if (this.opts.onActivate) this.opts.onActivate(path);
      setTimeout(() => { this.cm.refresh(); if (this.settings.lint) this.cm.performLint(); }, 0);
    }

    close(path) {
      const i = this.tabs.indexOf(path);
      if (i < 0) return;
      this.tabs.splice(i, 1);
      if (this.active === path) {
        const next = this.tabs[Math.min(i, this.tabs.length - 1)];
        if (next) this.activate(next);
        else {
          this.active = null;
          this.cm.swapDoc(this.emptyDoc);
          this.cm.setOption('readOnly', 'nocursor');
          if (this.opts.onActivate) this.opts.onActivate(null);
        }
      }
      this.renderTabs();
    }

    /** Remove o documento (arquivo excluído). */
    remove(path) {
      this.close(path);
      this.docs.delete(path);
    }

    rename(oldPath, newPath) {
      const d = this.docs.get(oldPath);
      if (!d) return;
      this.docs.delete(oldPath);
      this.docs.set(newPath, d);
      const i = this.tabs.indexOf(oldPath);
      if (i >= 0) this.tabs[i] = newPath;
      if (this.active === oldPath) this.active = newPath;
      this.renderTabs();
    }

    closeAll() {
      this.tabs = [];
      this.docs.clear();
      this.active = null;
      this.cm.swapDoc(this.emptyDoc);
      this.cm.setOption('readOnly', 'nocursor');
      this.renderTabs();
    }

    /** Conteúdo atual (o editor é a fonte de verdade para arquivos abertos). */
    getValue(path) {
      const d = this.docs.get(path);
      return d ? d.doc.getValue() : null;
    }

    setValue(path, text) {
      const d = this.docs.get(path);
      if (d) d.doc.setValue(text);
    }

    isOpen(path) { return this.docs.has(path); }

    isDirty(path) {
      const d = this.docs.get(path);
      return d ? !d.doc.isClean(d.savedGen) : false;
    }

    markAllSaved() {
      for (const d of this.docs.values()) d.savedGen = d.doc.changeGeneration(true);
      this.renderTabs();
    }

    gotoLine(path, line, col) {
      if (!this.docs.has(path)) return false;
      if (this.active !== path) this.activate(path);
      const ln = Math.max(0, Math.min(line - 1, this.cm.lineCount() - 1));
      this.cm.setCursor({ line: ln, ch: col ? col - 1 : 0 });
      this.cm.scrollIntoView({ line: ln, ch: 0 }, 80);
      this.cm.addLineClass(ln, 'background', 'gf-flash-line');
      setTimeout(() => this.cm.removeLineClass(ln, 'background', 'gf-flash-line'), 1400);
      this.cm.focus();
      return true;
    }

    setRuntimeError(path, line, message) {
      const d = this.docs.get(path);
      if (!d) return;
      d.runtimeErrors = [{ line, message }];
      if (this.active === path && this.settings.lint) this.cm.performLint();
    }

    clearRuntimeErrors() {
      for (const d of this.docs.values()) d.runtimeErrors = [];
      if (this.active && this.settings.lint) this.cm.performLint();
    }

    // -------------------------------------------------------------- comandos
    exec(cmd) {
      if (!this.active) return;
      this.cm.focus();
      if (cmd === 'find') this.cm.execCommand('findPersistent');
      else if (cmd === 'findNext') this.cm.execCommand('findPersistentNext');
      else if (cmd === 'findPrev') this.cm.execCommand('findPersistentPrev');
      else if (cmd === 'replace') this.cm.execCommand('replace');
      else if (cmd === 'replaceAll') this.cm.execCommand('replaceAll');
      else if (cmd === 'undo') this.cm.undo();
      else if (cmd === 'redo') this.cm.redo();
      else if (cmd === 'comment') this.cm.execCommand('toggleComment');
      else if (cmd === 'indent') this.cm.indentSelection('add');
      else if (cmd === 'outdent') this.cm.indentSelection('subtract');
      else if (cmd === 'format') this.reindent();
      else if (cmd === 'hint') this.showHint(true);
      else if (cmd === 'goto') this.cm.execCommand('jumpToLine');
      else if (cmd === 'foldAll') this.cm.execCommand('foldAll');
      else if (cmd === 'unfoldAll') this.cm.execCommand('unfoldAll');
    }

    /** Reindenta o arquivo inteiro usando as regras do modo Luau. */
    reindent() {
      const cm = this.cm;
      cm.operation(() => { for (let i = 0; i < cm.lineCount(); i++) cm.indentLine(i, 'smart'); });
    }

    insert(text) {
      if (!this.active) return;
      const cm = this.cm;
      if (text === '\t') text = ' '.repeat(cm.getOption('indentUnit'));
      cm.replaceSelection(text, 'end');
      if (/^[()[\]{}"']$/.test(text) === false) cm.focus();
      cm.focus();
    }

    moveCursor(dx) {
      const c = this.cm.getCursor();
      this.cm.setCursor({ line: c.line, ch: Math.max(0, c.ch + dx) });
      this.cm.focus();
    }

    /** Lista de funções declaradas no arquivo ativo (estrutura). */
    outline() {
      if (!this.active) return [];
      const out = [];
      const n = this.cm.lineCount();
      const re = /^\s*(?:local\s+)?function\s+([\w.:]+)\s*\(([^)]*)\)|^\s*(?:local\s+)?([\w.]+)\s*=\s*function\s*\(([^)]*)\)/;
      for (let i = 0; i < n; i++) {
        const m = re.exec(this.cm.getLine(i));
        if (m) out.push({ line: i + 1, name: m[1] || m[3], args: m[2] != null ? m[2] : m[4] });
      }
      return out;
    }

    focus() { this.cm.focus(); }
    blur() { this.cm.getInputField().blur(); }
    refresh() { this.cm.refresh(); }

    // -------------------------------------------------------------- abas
    renderTabs() {
      const el = this.tabsEl;
      el.textContent = '';
      for (const p of this.tabs) {
        const t = document.createElement('div');
        t.className = 'gf-tab' + (p === this.active ? ' on' : '') + (this.isDirty(p) ? ' dirty' : '');
        t.title = p;
        t.setAttribute('role', 'tab');
        const name = document.createElement('span');
        name.className = 'gf-tab-name';
        name.textContent = p.split('/').pop();
        const x = document.createElement('button');
        x.className = 'gf-tab-x';
        x.type = 'button';
        x.title = 'Fechar aba';
        x.setAttribute('aria-label', 'Fechar ' + p);
        x.textContent = '×';
        x.addEventListener('click', (e) => {
          e.stopPropagation();
          if (this.opts.onCloseTab) this.opts.onCloseTab(p);
          else this.close(p);
        });
        t.addEventListener('click', () => this.activate(p));
        t.addEventListener('auxclick', (e) => { if (e.button === 1) x.click(); });
        t.append(name, x);
        el.appendChild(t);
        if (p === this.active) setTimeout(() => t.scrollIntoView({ block: 'nearest', inline: 'nearest' }), 0);
      }
    }
  }

  GF.CodeEditor = CodeEditor;
})();
