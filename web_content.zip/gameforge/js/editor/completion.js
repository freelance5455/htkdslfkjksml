/*
 * GameForge Studio — autocompletar contextual para Luau + API do GameForge.
 * O catálogo (GF.API_CATALOG) é gerado a partir da API real executada na VM.
 */
(function () {
  'use strict';
  /* global CodeMirror */
  const GF = (window.GF = window.GF || {});

  const KEYWORDS = 'and break do else elseif end for function if in local not or repeat return then until while continue true false nil self type export'.split(' ');
  const GLOBALS = 'print warn error assert pcall xpcall select type typeof tostring tonumber pairs ipairs next rawget rawset rawequal rawlen setmetatable getmetatable unpack require tick time wait spawn delay math string table coroutine bit32 utf8 os debug task game Game workspace Workspace script shared _G Instance Vector3 Vector2 CFrame Color3 BrickColor UDim UDim2 Enum TweenInfo Ray RaycastParams NumberRange NumberSequence NumberSequenceKeypoint ColorSequence ColorSequenceKeypoint Lighting Weather Players RunService UserInputService TweenService Debris DataStoreService Models'.split(' ');

  // membros de bibliotecas e tipos (estáticos)
  const LIBS = {
    math: 'abs acos asin atan atan2 ceil clamp cos cosh deg exp floor fmod frexp huge ldexp log log10 lerp max min modf noise pi pow rad random randomseed round sign sin sinh sqrt tan tanh'.split(' '),
    string: 'byte char find format gmatch gsub len lower match rep reverse split sub upper pack unpack packsize'.split(' '),
    table: 'clear clone concat create find foreach foreachi freeze getn insert isfrozen maxn move pack remove sort unpack'.split(' '),
    coroutine: 'close create isyieldable resume running status wrap yield'.split(' '),
    task: 'wait spawn defer delay cancel'.split(' '),
    os: 'clock date difftime time'.split(' '),
    utf8: 'char charpattern codepoint codes len offset'.split(' '),
    bit32: 'arshift band bnot bor btest bxor countlz countrz extract lrotate lshift replace rrotate rshift'.split(' '),
    debug: 'traceback info'.split(' '),
    Instance: ['new'],
    Vector3: 'new zero one xAxis yAxis zAxis'.split(' '),
    Vector2: 'new zero one'.split(' '),
    CFrame: 'new Angles fromEulerAnglesXYZ fromOrientation lookAt fromAxisAngle identity'.split(' '),
    Color3: 'new fromRGB fromHSV fromHex'.split(' '),
    BrickColor: 'new random Red Blue Green White Black Yellow Gray'.split(' '),
    UDim: ['new'],
    UDim2: 'new fromScale fromOffset'.split(' '),
    TweenInfo: ['new'],
    Ray: ['new'],
    RaycastParams: ['new'],
    NumberRange: ['new'],
    NumberSequence: ['new'],
    NumberSequenceKeypoint: ['new'],
    ColorSequence: ['new'],
    ColorSequenceKeypoint: ['new'],
  };
  const VALUE_MEMBERS = {
    Vector3: 'X Y Z Magnitude Unit Lerp Dot Cross FuzzyEq Abs Floor Ceil Min Max'.split(' '),
    CFrame: 'Position X Y Z LookVector RightVector UpVector Rotation Inverse Lerp ToWorldSpace ToObjectSpace PointToWorldSpace PointToObjectSpace VectorToWorldSpace VectorToObjectSpace ToEulerAnglesXYZ ToOrientation GetComponents'.split(' '),
    Color3: 'R G B Lerp ToHSV ToHex'.split(' '),
  };

  const SNIPPETS = [
    { text: 'local function nome()\n\t\nend', display: 'function (snippet)' },
    { text: 'for i = 1, 10 do\n\t\nend', display: 'for i = 1, 10 (snippet)' },
    { text: 'for _, item in ipairs(lista) do\n\t\nend', display: 'for ipairs (snippet)' },
    { text: 'for chave, valor in pairs(tabela) do\n\t\nend', display: 'for pairs (snippet)' },
    { text: 'while true do\n\ttask.wait(1)\nend', display: 'while true + task.wait (snippet)' },
    { text: 'if condicao then\n\t\nend', display: 'if then (snippet)' },
    { text: 'local parte = Instance.new("Part")\nparte.Size = Vector3.new(4, 1, 4)\nparte.Position = Vector3.new(0, 5, 0)\nparte.Anchored = true\nparte.Parent = workspace', display: 'Instance.new("Part") (snippet)' },
    { text: 'parte.Touched:Connect(function(outro)\n\t\nend)', display: 'Touched:Connect (snippet)' },
  ];

  let catalogCache = null;
  function catalog() {
    if (catalogCache) return catalogCache;
    const C = GF.API_CATALOG || { classes: {}, enums: {}, services: [], game: [] };
    const members = {}; // classe -> {props, methods, events}
    const allProps = new Set(), allMethods = new Set(), allEvents = new Set();
    function collect(name) {
      if (members[name]) return members[name];
      const c = C.classes[name];
      if (!c) return { props: [], methods: [], events: [] };
      const sup = c.super ? collect(c.super) : { props: [], methods: [], events: [] };
      const m = {
        props: Array.from(new Set([...sup.props, ...c.props, ...c.nilProps, ...c.getters])).sort(),
        methods: Array.from(new Set([...sup.methods, ...c.methods])).sort(),
        events: Array.from(new Set([...sup.events, ...c.events])).sort(),
      };
      members[name] = m;
      return m;
    }
    for (const n of Object.keys(C.classes)) {
      const m = collect(n);
      m.props.forEach((p) => allProps.add(p));
      m.methods.forEach((p) => allMethods.add(p));
      m.events.forEach((p) => allEvents.add(p));
    }
    const creatable = Object.keys(C.classes).filter((n) => C.classes[n].creatable).sort();
    catalogCache = { C, members, creatable, allProps: [...allProps].sort(), allMethods: [...allMethods].sort(), allEvents: [...allEvents].sort() };
    return catalogCache;
  }

  const SERVICE_GLOBALS = { workspace: 'Workspace', Workspace: 'Workspace', Lighting: 'Lighting', Weather: 'Weather', Players: 'Players', RunService: 'RunService', UserInputService: 'UserInputService', TweenService: 'TweenService', Debris: 'Debris', DataStoreService: 'DataStoreService', script: 'Script' };

  // Tenta descobrir a classe de uma variável a partir do código do arquivo.
  function inferClass(name, text) {
    if (SERVICE_GLOBALS[name]) return SERVICE_GLOBALS[name];
    if (name === 'game' || name === 'Game') return 'DataModel';
    const esc = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    let m = new RegExp('\\b' + esc + '\\s*(?::\\s*\\w+\\s*)?=\\s*Instance\\.new\\(\\s*["\'](\\w+)["\']').exec(text);
    if (m) return m[1];
    m = new RegExp('\\b' + esc + '\\s*(?::\\s*\\w+\\s*)?=\\s*(?:game|Game)\\s*[:.]\\s*GetService\\(\\s*["\'](\\w+)["\']').exec(text);
    if (m) return m[1];
    m = new RegExp('\\b' + esc + '\\s*(?::\\s*\\w+\\s*)?=\\s*(?:game|Game)\\.(\\w+)\\b').exec(text);
    if (m && catalog().C.services.includes(m[1])) return m[1];
    m = new RegExp('\\b' + esc + '\\s*(?::\\s*\\w+\\s*)?=\\s*[\\w.]*[:.]WaitForChild\\(\\s*["\']Humanoid["\']').exec(text);
    if (m) return 'Humanoid';
    if (/^(hum|humanoid)$/i.test(name)) return 'Humanoid';
    if (/^(player|plr|jogador)$/i.test(name)) return 'Player';
    m = new RegExp('\\b' + esc + '\\s*:\\s*(\\w+)').exec(text);
    if (m && catalog().C.classes[m[1]]) return m[1];
    if (m && VALUE_MEMBERS[m[1]]) return m[1];
    m = new RegExp('\\b' + esc + '\\s*=\\s*(Vector3|CFrame|Color3)\\.').exec(text);
    if (m) return m[1];
    return null;
  }

  function words(text) {
    const set = new Set();
    const re = /\b[A-Za-z_][A-Za-z0-9_]{2,}\b/g;
    let m;
    while ((m = re.exec(text))) set.add(m[0]);
    return set;
  }

  function filter(list, prefix, cls) {
    const p = prefix.toLowerCase();
    const out = [];
    for (const item of list) {
      const t = typeof item === 'string' ? item : item.text;
      const d = typeof item === 'string' ? item : item.display;
      if (!p || t.toLowerCase().startsWith(p) || (typeof item !== 'string' && d.toLowerCase().startsWith(p))) {
        out.push(typeof item === 'string' ? { text: t, displayText: d, className: cls } : { text: t, displayText: d, className: item.className || cls });
      }
    }
    return out;
  }

  function hint(cm) {
    const cur = cm.getCursor();
    const line = cm.getLine(cur.line);
    const before = line.slice(0, cur.ch);
    const tok = cm.getTokenAt(cur);
    const state = tok.state;
    if (tok.type && /comment/.test(tok.type)) return null;
    const cat = catalog();

    // dentro de string: Instance.new(" / GetService(" / WaitForChild etc.
    let m = /(Instance\.new|GetService|FindService|IsA|FindFirstChildOfClass|FindFirstAncestorOfClass|FindFirstChildWhichIsA)\(\s*(["'])(\w*)$/.exec(before);
    if (m) {
      const list = m[1] === 'Instance.new' ? cat.creatable : (m[1] === 'GetService' || m[1] === 'FindService') ? cat.C.services : Object.keys(cat.C.classes).sort();
      const from = CodeMirror.Pos(cur.line, cur.ch - m[3].length);
      const after = line.slice(cur.ch);
      const closer = after.startsWith(m[2]) ? '' : m[2] + (after.startsWith(')') ? '' : ')');
      return { list: filter(list, m[3], 'gf-h-class').map((x) => ({ ...x, text: x.text + closer })), from, to: cur };
    }
    if (/["'][^"']*$/.test(before) && tok.type && /string/.test(tok.type)) {
      // Weather.Type = "R..."  /  SetWeather("
      m = /(?:Weather\.Type\s*=\s*|SetWeather\(\s*)["'](\w*)$/.exec(before);
      if (m) return { list: filter(cat.C.enums.WeatherType || [], m[1], 'gf-h-enum'), from: CodeMirror.Pos(cur.line, cur.ch - m[1].length), to: cur };
      return null;
    }

    // Enum.Tipo.Item
    m = /\bEnum\.(\w+)\.(\w*)$/.exec(before);
    if (m) {
      const items = cat.C.enums[m[1]] || [];
      return { list: filter(items, m[2], 'gf-h-enum'), from: CodeMirror.Pos(cur.line, cur.ch - m[2].length), to: cur };
    }
    m = /\bEnum\.(\w*)$/.exec(before);
    if (m) return { list: filter(Object.keys(cat.C.enums).sort(), m[1], 'gf-h-enum'), from: CodeMirror.Pos(cur.line, cur.ch - m[1].length), to: cur };

    // obj.membro / obj:metodo
    m = /([A-Za-z_][\w]*(?:\s*\.\s*[A-Za-z_]\w*)*)\s*([.:])\s*(\w*)$/.exec(before);
    if (m) {
      const chain = m[1].split('.').map((s) => s.trim());
      const sep = m[2];
      const prefix = m[3];
      const from = CodeMirror.Pos(cur.line, cur.ch - prefix.length);
      const root = chain[0];
      const text = cm.getValue();
      let list = [];
      if (chain.length === 1 && LIBS[root] && sep === '.') {
        list = filter(LIBS[root], prefix, 'gf-h-fn');
      } else if (chain.length === 1 && (root === 'game' || root === 'Game') && sep === '.') {
        const dm = cat.members.DataModel || { props: [], methods: [], events: [] };
        list = filter(cat.C.game, prefix, 'gf-h-fn').concat(filter(cat.C.services, prefix, 'gf-h-class'), filter(dm.props, prefix, 'gf-h-prop'));
      } else {
        let cls = null;
        if (chain.length === 1) cls = inferClass(root, text);
        else if ((root === 'game' || root === 'Game') && chain.length === 2 && cat.C.services.includes(chain[1])) cls = chain[1];
        else if (chain[chain.length - 1] === 'Humanoid') cls = 'Humanoid';
        else if (chain[chain.length - 1] === 'LocalPlayer') cls = 'Player';
        else if (chain[chain.length - 1] === 'CurrentCamera') cls = 'Camera';
        else if (chain[chain.length - 1] === 'Position' || chain[chain.length - 1] === 'Size' || chain[chain.length - 1] === 'Velocity') cls = 'Vector3';
        else if (chain[chain.length - 1] === 'CFrame') cls = 'CFrame';
        else if (chain[chain.length - 1] === 'Color') cls = 'Color3';
        if (cls && VALUE_MEMBERS[cls]) {
          list = filter(VALUE_MEMBERS[cls], prefix, 'gf-h-prop');
        } else if (cls && cat.members[cls]) {
          const mem = cat.members[cls];
          list = sep === ':' ? filter(mem.methods, prefix, 'gf-h-fn') : filter(mem.props, prefix, 'gf-h-prop').concat(filter(mem.events, prefix, 'gf-h-event'), filter(mem.methods, prefix, 'gf-h-fn'));
        } else {
          list = sep === ':' ? filter(cat.allMethods, prefix, 'gf-h-fn') : filter(cat.allProps, prefix, 'gf-h-prop').concat(filter(cat.allEvents, prefix, 'gf-h-event'));
        }
      }
      if (!list.length) return null;
      return { list: list.slice(0, 200), from, to: cur };
    }

    // palavra solta
    m = /([A-Za-z_]\w*)$/.exec(before);
    const prefix = m ? m[1] : '';
    if (!prefix) return null;
    const from = CodeMirror.Pos(cur.line, cur.ch - prefix.length);
    const local = [...words(cm.getValue())].filter((w) => w !== prefix);
    const seen = new Set();
    const list = [];
    const push = (arr) => { for (const x of arr) if (!seen.has(x.text)) { seen.add(x.text); list.push(x); } };
    push(filter(KEYWORDS, prefix, 'gf-h-kw'));
    push(filter(GLOBALS, prefix, 'gf-h-global'));
    push(filter(local.sort(), prefix, 'gf-h-word'));
    if (prefix.length >= 2) push(filter(SNIPPETS, prefix, 'gf-h-snip'));
    if (!list.length || (list.length === 1 && list[0].text === prefix)) return null;
    void state;
    return { list: list.slice(0, 100), from, to: cur };
  }

  GF.luauHint = hint;
  GF.luauCatalog = catalog;
})();
