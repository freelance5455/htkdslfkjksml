/*
 * GameForge Studio — modo de destaque de sintaxe Luau para o CodeMirror 5.
 * Reconhece palavras-chave do Luau (incluindo continue, type, export),
 * operadores compostos (+=, -=, //, ..=), strings longas, interpolação
 * `texto {expr}`, anotações de tipo, números hexadecimais/binários e
 * a API do GameForge (globais e serviços).
 */
(function () {
  'use strict';
  /* global CodeMirror */

  const words = (s) => new Set(s.split(' '));
  const KEYWORDS = words('and break do else elseif end for function if in local not or repeat return then until while continue');
  const SOFT_KEYWORDS = words('type export typeof');
  const ATOMS = words('true false nil self');
  const BUILTINS = words(
    'print warn error assert pcall xpcall select type typeof tostring tonumber pairs ipairs next rawget rawset rawequal rawlen setmetatable getmetatable unpack require tick time wait spawn delay elapsedTime gcinfo newproxy ' +
      'math string table coroutine bit32 utf8 os debug buffer task'
  );
  const API = words(
    'game Game workspace Workspace script shared _G Instance Vector3 Vector2 CFrame Color3 BrickColor UDim UDim2 Enum TweenInfo Ray RaycastParams ' +
      'NumberRange NumberSequence NumberSequenceKeypoint ColorSequence ColorSequenceKeypoint Lighting Weather Players RunService UserInputService TweenService Debris DataStoreService Models'
  );
  const INDENT = words('function then do repeat');
  const DEDENT = words('end until');

  CodeMirror.defineMode('luau', function (config) {
    const indentUnit = config.indentUnit;

    function longBracketLevel(stream) {
      const m = stream.match(/^\[(=*)\[/, false);
      return m ? m[1].length : -1;
    }

    function readLong(level, style) {
      return function (stream, state) {
        const close = ']' + '='.repeat(level) + ']';
        while (!stream.eol()) {
          if (stream.match(close)) { state.cur = normal; return style; }
          stream.next();
        }
        return style;
      };
    }

    function readString(quote) {
      return function (stream, state) {
        let escaped = false, ch;
        while ((ch = stream.next()) != null) {
          if (ch === quote && !escaped) { state.cur = normal; return 'string'; }
          if (ch === 'z' && escaped) { stream.eatSpace(); }
          escaped = !escaped && ch === '\\';
        }
        if (!escaped) state.cur = normal; // string não terminada: termina na linha
        return 'string error';
      };
    }

    function readInterp(stream, state) {
      // string com crase: `texto {expr} texto`
      let escaped = false, ch;
      while ((ch = stream.peek()) != null) {
        if (!escaped && ch === '{') {
          if (stream.current().length) return 'string';
          stream.next();
          state.interpDepth.push(0);
          state.cur = normal;
          return 'string-2 bracket';
        }
        stream.next();
        if (ch === '`' && !escaped) { state.cur = normal; return 'string'; }
        escaped = !escaped && ch === '\\';
      }
      return 'string';
    }

    function normal(stream, state) {
      const ch = stream.peek();
      // comentários
      if (stream.match('--')) {
        const lvl = longBracketLevel(stream);
        if (lvl >= 0) {
          stream.match(/^\[=*\[/);
          state.cur = readLong(lvl, 'comment');
          return state.cur(stream, state);
        }
        stream.skipToEnd();
        return 'comment';
      }
      if (ch === '"' || ch === "'") {
        stream.next();
        state.cur = readString(ch);
        return state.cur(stream, state);
      }
      if (ch === '`') {
        stream.next();
        state.cur = readInterp;
        return state.cur(stream, state);
      }
      if (ch === '[') {
        const lvl = longBracketLevel(stream);
        if (lvl >= 0) {
          stream.match(/^\[=*\[/);
          state.cur = readLong(lvl, 'string');
          return state.cur(stream, state);
        }
      }
      if (/\d/.test(ch) || (ch === '.' && /\d/.test(stream.string.charAt(stream.pos + 1)))) {
        if (stream.match(/^0[xX][0-9a-fA-F_]+/) || stream.match(/^0[bB][01_]+/) || stream.match(/^(\d[\d_]*)?\.?[\d_]*([eE][+-]?\d+)?/)) return 'number';
      }
      if (/[A-Za-z_]/.test(ch)) {
        stream.match(/^[A-Za-z_][A-Za-z0-9_]*/);
        const w = stream.current();
        const prevDot = state.lastSig === '.' || state.lastSig === ':';
        state.lastWord = w;
        if (!prevDot && KEYWORDS.has(w)) {
          if (INDENT.has(w)) state.stack.push(state.line);
          else if (DEDENT.has(w)) state.stack.pop();
          else if (w === 'elseif') state.stack.pop();
          else if (w === 'else') { state.stack.pop(); state.stack.push(state.line); }
          return 'keyword';
        }
        if (!prevDot && SOFT_KEYWORDS.has(w)) {
          if (w === 'typeof') return 'builtin';
          // "type Nome =" / "export type"
          if (/^\s*[A-Za-z_]/.test(stream.string.slice(stream.pos)) && (w === 'export' || /^\s*[A-Za-z_]\w*\s*(<[^>]*>)?\s*=/.test(stream.string.slice(stream.pos)))) return 'keyword';
          return 'variable';
        }
        if (!prevDot && ATOMS.has(w)) return 'atom';
        if (!prevDot && BUILTINS.has(w)) return 'builtin';
        if (!prevDot && API.has(w)) return 'variable-2';
        if (state.lastSig === ':') return 'def';
        if (prevDot) return 'property';
        if (state.lastWord === 'function' || /^\s*\(/.test(stream.string.slice(stream.pos))) return 'variable-3';
        return 'variable';
      }
      stream.next();
      if (ch === '{' || ch === '(' || ch === '[') {
        state.stack.push(state.line);
        if (ch === '{' && state.interpDepth.length) state.interpDepth[state.interpDepth.length - 1]++;
        return 'bracket';
      }
      if (ch === '}' || ch === ')' || ch === ']') {
        state.stack.pop();
        if (ch === '}' && state.interpDepth.length) {
          const d = state.interpDepth.length - 1;
          if (state.interpDepth[d] === 0) {
            state.interpDepth.pop();
            state.stack.push(state.line);
            state.cur = readInterp;
            return 'string-2 bracket';
          }
          state.interpDepth[d]--;
        }
        return 'bracket';
      }
      if (/[+\-*/%^#=<>~.:;,&|]/.test(ch)) {
        stream.eatWhile(/[+\-*/%^=<>~.]/);
        return 'operator';
      }
      return null;
    }

    return {
      startState: function (base) {
        return { cur: normal, base: base || 0, line: 0, stack: [], lastSig: null, lastWord: null, interpDepth: [] };
      },
      copyState: function (s) {
        return { cur: s.cur, base: s.base, line: s.line, stack: s.stack.slice(), lastSig: s.lastSig, lastWord: s.lastWord, interpDepth: s.interpDepth.slice() };
      },
      token: function (stream, state) {
        if (stream.sol()) state.line++;
        if (stream.eatSpace()) return null;
        const style = state.cur(stream, state);
        const cur = stream.current();
        if (style !== 'comment') state.lastSig = cur.length === 1 ? cur : (style === 'operator' ? cur.slice(-1) : '#');
        if (style !== 'keyword' && style !== null && !/^[A-Za-z_]/.test(cur)) state.lastWord = null;
        return style;
      },
      indent: function (state, textAfter) {
        if (state.cur !== normal) return CodeMirror.Pass;
        const stack = state.stack.slice();
        let rest = textAfter, m;
        while ((m = /^\s*(end\b|until\b|elseif\b|else\b|[)}\]])/.exec(rest))) {
          stack.pop();
          rest = rest.slice(m[0].length);
          if (m[1] === 'else' || m[1] === 'elseif' || m[1] === 'until') break;
        }
        let levels = 0, last = null;
        for (const ln of stack) if (ln !== last) { levels++; last = ln; }
        return state.base + levels * indentUnit;
      },
      electricInput: /^\s*(?:end|until|else|elseif|\}|\)|\])$/,
      lineComment: '--',
      blockCommentStart: '--[[',
      blockCommentEnd: ']]',
      fold: 'indent',
    };
  });

  CodeMirror.defineMIME('text/x-luau', 'luau');
})();
