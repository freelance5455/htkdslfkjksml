/*
 * GameForge Studio — modelo de projeto: arquivos, pastas e operações.
 * Projeto: { id, name, created, modified, folders: [caminhos], files: [{path, source, disabled}], openTabs, activeFile }
 */
(function () {
  'use strict';
  const GF = (window.GF = window.GF || {});

  const MAIN_TEMPLATE = `-- Bem-vindo ao GameForge Studio!
-- Este script roda na VM Luau quando você clica em Executar.

print("Meu primeiro jogo!")

Game.SetGravity(196.2)
local player = Game.CreatePlayer("Soldado")
Game.SetWeather("Clear")

-- Uma plataforma vermelha
local bloco = Instance.new("Part")
bloco.Name = "Plataforma"
bloco.Position = Vector3.new(0, 4, -12)
bloco.Size = Vector3.new(10, 1, 10)
bloco.Color = Color3.fromRGB(255, 0, 0)
bloco.Anchored = true
bloco.Parent = workspace

-- Uma moeda que gira e some quando é tocada
local Util = require("Utilidades")
local moeda = Util.criarMoeda(Vector3.new(0, 3, -7)) -- ande para frente (W) para pegá-la

moeda.Touched:Connect(function(outro)
	local humanoid = outro.Parent and outro.Parent:FindFirstChild("Humanoid")
	if humanoid then
		print(player.Name .. " pegou a moeda!")
		moeda:Destroy()
	end
end)

-- Clique em "Manual" para aprender todos os comandos.
`;

  const UTIL_TEMPLATE = `-- Módulo: scripts dentro da pasta "Modules" não rodam sozinhos.
-- Eles são carregados com require("Utilidades").
local Utilidades = {}

function Utilidades.criarMoeda(posicao: Vector3)
	local moeda = Instance.new("Part")
	moeda.Name = "Moeda"
	moeda.Shape = Enum.PartType.Cylinder
	moeda.Size = Vector3.new(0.4, 2, 2)
	moeda.Color = Color3.fromRGB(255, 200, 40)
	moeda.Material = Enum.Material.Neon
	moeda.Anchored = true
	moeda.CanCollide = false
	moeda.Position = posicao
	moeda.Parent = workspace

	task.spawn(function()
		local angulo = 0
		while moeda.Parent do
			angulo += 3
			moeda.CFrame = CFrame.new(posicao) * CFrame.Angles(0, math.rad(angulo), 0)
			task.wait()
		end
	end)
	return moeda
end

return Utilidades
`;

  function uid() {
    return 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  function createProject(name, blank) {
    const now = Date.now();
    return {
      id: uid(),
      name: name || 'Meu Jogo',
      created: now,
      modified: now,
      folders: ['Scripts', 'Modules'],
      files: blank
        ? [{ path: 'Scripts/Main.luau', source: '-- Escreva seu jogo aqui\nprint("Olá, GameForge!")\n', disabled: false }]
        : [
            { path: 'Scripts/Main.luau', source: MAIN_TEMPLATE, disabled: false },
            { path: 'Modules/Utilidades.luau', source: UTIL_TEMPLATE, disabled: false },
          ],
      openTabs: ['Scripts/Main.luau'],
      activeFile: 'Scripts/Main.luau',
    };
  }

  // ------------------------------------------------------------------ caminhos
  const INVALID = /[\\:*?"<>|]/;
  function normalizePath(p) {
    return String(p || '')
      .replace(/\\/g, '/')
      .split('/')
      .map((s) => s.trim())
      .filter((s) => s && s !== '.' && s !== '..')
      .join('/');
  }
  function validateName(name) {
    if (!name || !name.trim()) return 'O nome não pode ficar vazio.';
    if (INVALID.test(name)) return 'O nome não pode conter \\ : * ? " < > |';
    if (name.length > 120) return 'Nome muito longo.';
    return null;
  }
  function dirname(p) { const i = p.lastIndexOf('/'); return i < 0 ? '' : p.slice(0, i); }
  function basename(p) { return p.slice(p.lastIndexOf('/') + 1); }
  function join(dir, name) { return dir ? dir + '/' + name : name; }

  class Project {
    constructor(data) {
      this.data = data;
      this.data.folders = this.data.folders || [];
      this.data.files = this.data.files || [];
      this.ensureFolders();
    }
    get id() { return this.data.id; }
    get name() { return this.data.name; }
    set name(v) { this.data.name = v; }
    get files() { return this.data.files; }

    file(path) { return this.data.files.find((f) => f.path === path) || null; }
    hasFolder(path) { return this.data.folders.includes(path); }
    exists(path) { return !!this.file(path) || this.hasFolder(path); }

    ensureFolders() {
      const set = new Set(this.data.folders);
      for (const f of this.data.files) {
        let d = dirname(f.path);
        while (d) { set.add(d); d = dirname(d); }
      }
      this.data.folders = [...set].sort();
    }

    addFile(path, source) {
      path = normalizePath(path);
      if (!path) throw new Error('Caminho inválido.');
      const err = validateName(basename(path));
      if (err) throw new Error(err);
      if (this.exists(path)) throw new Error('Já existe um item chamado "' + path + '".');
      const f = { path, source: source == null ? '' : String(source), disabled: false };
      this.data.files.push(f);
      this.ensureFolders();
      return f;
    }

    addFolder(path) {
      path = normalizePath(path);
      const err = validateName(basename(path));
      if (err) throw new Error(err);
      if (this.exists(path)) throw new Error('Já existe um item chamado "' + path + '".');
      this.data.folders.push(path);
      this.ensureFolders();
    }

    /** Renomeia/move arquivo ou pasta. Retorna lista de pares [antigo, novo] de arquivos afetados. */
    rename(oldPath, newPath) {
      newPath = normalizePath(newPath);
      const err = validateName(basename(newPath));
      if (err) throw new Error(err);
      if (oldPath === newPath) return [];
      if (this.exists(newPath)) throw new Error('Já existe um item chamado "' + newPath + '".');
      const moved = [];
      const f = this.file(oldPath);
      if (f) {
        f.path = newPath;
        moved.push([oldPath, newPath]);
      } else if (this.hasFolder(oldPath)) {
        if (newPath.startsWith(oldPath + '/')) throw new Error('Não é possível mover uma pasta para dentro dela mesma.');
        this.data.folders = this.data.folders.map((d) => (d === oldPath ? newPath : d.startsWith(oldPath + '/') ? newPath + d.slice(oldPath.length) : d));
        for (const file of this.data.files) {
          if (file.path.startsWith(oldPath + '/')) {
            const np = newPath + file.path.slice(oldPath.length);
            moved.push([file.path, np]);
            file.path = np;
          }
        }
      } else throw new Error('Item não encontrado: ' + oldPath);
      this.ensureFolders();
      return moved;
    }

    /** Exclui arquivo ou pasta (recursivo). Retorna caminhos de arquivos removidos. */
    remove(path) {
      const removed = [];
      if (this.file(path)) {
        this.data.files = this.data.files.filter((f) => f.path !== path);
        removed.push(path);
      } else {
        this.data.files = this.data.files.filter((f) => {
          if (f.path.startsWith(path + '/')) { removed.push(f.path); return false; }
          return true;
        });
        this.data.folders = this.data.folders.filter((d) => d !== path && !d.startsWith(path + '/'));
      }
      return removed;
    }

    uniquePath(path) {
      if (!this.exists(path)) return path;
      const m = /^(.*?)(\.[^./]+)?$/.exec(path);
      for (let i = 2; i < 1000; i++) {
        const p = m[1] + ' (' + i + ')' + (m[2] || '');
        if (!this.exists(p)) return p;
      }
      return path + '-' + Date.now();
    }

    /** Árvore para o explorador. */
    tree() {
      const root = { name: '', path: '', folders: new Map(), files: [] };
      const getDir = (p) => {
        if (!p) return root;
        let node = root;
        let acc = '';
        for (const part of p.split('/')) {
          acc = acc ? acc + '/' + part : part;
          if (!node.folders.has(part)) node.folders.set(part, { name: part, path: acc, folders: new Map(), files: [] });
          node = node.folders.get(part);
        }
        return node;
      };
      for (const d of this.data.folders) getDir(d);
      for (const f of this.data.files) getDir(dirname(f.path)).files.push(f);
      return root;
    }

    toJSON() { return this.data; }
  }

  GF.Project = Project;
  GF.createProject = createProject;
  GF.paths = { normalizePath, validateName, dirname, basename, join };
})();
