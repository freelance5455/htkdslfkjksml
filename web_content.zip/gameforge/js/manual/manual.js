/*
 * GameForge Studio — Manual de Programação (renderização, navegação e pesquisa).
 *
 * Formato dos capítulos (GF.MANUAL): { id, group, title, body } onde body usa uma marcação simples:
 *   ## Título de seção          ### Subtítulo
 *   parágrafos separados por linha em branco, com `código`, **negrito** e [texto](url)
 *   - item de lista             | a | b |  (tabela, primeira linha = cabeçalho)
 *   > dica                      >! aviso
 *   ```luau Título              bloco de código executável (Enviar ao editor / Executar)
 *   ```luau-frag Título         trecho que depende de outro código (só Copiar / Enviar)
 *   ```text                     bloco sem destaque
 *   ::: exercicio Título        exercício (texto + bloco ```luau com a solução) … :::
 */
(function () {
  'use strict';
  /* global CodeMirror */
  const GF = (window.GF = window.GF || {});

  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function inline(s) {
    return esc(s)
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/\[([^\]]+)\]\((https?:[^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  }

  function highlight(code, el) {
    if (window.CodeMirror && CodeMirror.runMode) { CodeMirror.runMode(code, 'luau', el); return; }
    el.textContent = code;
  }

  // CodeMirror 5 não traz runMode no pacote principal: implementação mínima
  if (window.CodeMirror && !CodeMirror.runMode) {
    CodeMirror.runMode = function (string, modespec, el) {
      const mode = CodeMirror.getMode(CodeMirror.defaults, modespec);
      const lines = CodeMirror.splitLines(string);
      let state = CodeMirror.startState(mode);
      el.textContent = '';
      lines.forEach((line, i) => {
        if (i) el.appendChild(document.createTextNode('\n'));
        const stream = new CodeMirror.StringStream(line, 4);
        if (!line && mode.blankLine) mode.blankLine(state);
        while (!stream.eol()) {
          const style = mode.token(stream, state);
          const text = stream.current();
          if (style) {
            const sp = document.createElement('span');
            sp.className = style.split(' ').map((s) => 'cm-' + s).join(' ');
            sp.textContent = text;
            el.appendChild(sp);
          } else el.appendChild(document.createTextNode(text));
          stream.start = stream.pos;
        }
      });
    };
  }

  class Manual {
    constructor(tocEl, bodyEl, searchEl, hooks) {
      this.toc = tocEl;
      this.body = bodyEl;
      this.search = searchEl;
      this.hooks = hooks;
      this.chapters = (GF.MANUAL || []).slice();
      this.current = null;
      this.rendered = false;
      let t;
      searchEl.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => this.renderToc(searchEl.value.trim()), 200); });
    }

    show() {
      if (!this.rendered) {
        this.renderToc('');
        this.open(this.chapters[0] && this.chapters[0].id);
        this.rendered = true;
      }
    }

    renderToc(q) {
      this.toc.textContent = '';
      const ql = q.toLowerCase();
      let group = null;
      let n = 0;
      this.chapters.forEach((c, i) => {
        let hits = [];
        if (ql) {
          const text = (c.title + '\n' + c.body).toLowerCase();
          if (!text.includes(ql)) return;
          // seções que contêm o termo
          const parts = c.body.split(/\n(?=## )/);
          for (const p of parts) {
            if (p.toLowerCase().includes(ql)) {
              const h = /^## (.+)/m.exec(p);
              if (h) hits.push(h[1]);
            }
          }
          hits = hits.slice(0, 4);
        }
        if (c.group !== group) {
          group = c.group;
          const g = document.createElement('div');
          g.className = 'grp';
          g.textContent = group;
          this.toc.appendChild(g);
        }
        n++;
        const b = document.createElement('button');
        b.dataset.id = c.id;
        b.className = c.id === this.current ? 'on' : '';
        b.innerHTML = '<span class="num"></span><span></span>';
        b.firstChild.textContent = c.num || String(i + 1);
        b.lastChild.textContent = c.title;
        b.addEventListener('click', () => this.open(c.id, q));
        this.toc.appendChild(b);
        for (const h of hits) {
          const s = document.createElement('button');
          s.className = 'hit';
          s.textContent = '↳ ' + h;
          s.addEventListener('click', () => this.open(c.id, q, h));
          this.toc.appendChild(s);
        }
      });
      if (!n) this.toc.innerHTML = '<p class="muted sm" style="padding:8px">Nada encontrado.</p>';
    }

    open(id, query, section) {
      const c = this.chapters.find((x) => x.id === id);
      if (!c) return;
      this.current = id;
      Array.from(this.toc.querySelectorAll('button[data-id]')).forEach((b) => b.classList.toggle('on', b.dataset.id === id));
      this.body.textContent = '';
      const tog = document.createElement('button');
      tog.className = 'btn sm man-mtoggle';
      tog.textContent = '☰ Capítulos';
      tog.addEventListener('click', () => this.body.parentElement.classList.toggle('nav-open'));
      this.body.appendChild(tog);
      const h1 = document.createElement('h1');
      h1.textContent = (c.num ? c.num + '. ' : '') + c.title;
      this.body.appendChild(h1);
      this.renderBody(c.body, this.body, c.title);
      // paginação
      const i = this.chapters.indexOf(c);
      const pager = document.createElement('div');
      pager.className = 'man-pager';
      const prev = this.chapters[i - 1], next = this.chapters[i + 1];
      pager.innerHTML = '<span></span><span></span>';
      if (prev) { const b = document.createElement('button'); b.className = 'btn'; b.textContent = '← ' + prev.title; b.addEventListener('click', () => this.open(prev.id)); pager.firstChild.appendChild(b); }
      if (next) { const b = document.createElement('button'); b.className = 'btn'; b.textContent = next.title + ' →'; b.addEventListener('click', () => this.open(next.id)); pager.lastChild.appendChild(b); }
      this.body.appendChild(pager);
      this.body.parentElement.classList.remove('nav-open');
      this.body.scrollTop = 0;
      if (section) {
        const target = Array.from(this.body.querySelectorAll('h2')).find((h) => h.textContent === section);
        if (target) target.scrollIntoView({ block: 'start' });
      } else this.body.focus({ preventScroll: true });
      if (query) this.mark(query);
    }

    mark(q) {
      const ql = q.toLowerCase();
      const walker = document.createTreeWalker(this.body, NodeFilter.SHOW_TEXT);
      const nodes = [];
      while (walker.nextNode()) if (walker.currentNode.nodeValue.toLowerCase().includes(ql) && !walker.currentNode.parentElement.closest('pre,button')) nodes.push(walker.currentNode);
      let first = null;
      for (const n of nodes.slice(0, 200)) {
        const v = n.nodeValue;
        const idx = v.toLowerCase().indexOf(ql);
        const mk = document.createElement('mark');
        mk.textContent = v.slice(idx, idx + q.length);
        const after = n.splitText(idx);
        after.nodeValue = after.nodeValue.slice(q.length);
        n.parentNode.insertBefore(mk, after);
        if (!first) first = mk;
      }
      if (first) first.scrollIntoView({ block: 'center' });
    }

    renderBody(src, root, chapterTitle) {
      const lines = src.replace(/\r/g, '').split('\n');
      let i = 0;
      let para = [];
      let container = root;
      const flush = () => {
        if (para.length) {
          const p = document.createElement('p');
          p.innerHTML = inline(para.join(' '));
          container.appendChild(p);
          para = [];
        }
      };
      while (i < lines.length) {
        const line = lines[i];
        let m;
        if ((m = /^```(\S*)\s*(.*)$/.exec(line))) {
          flush();
          const lang = m[1] || 'text';
          const title = m[2] || '';
          const code = [];
          i++;
          while (i < lines.length && !/^```\s*$/.test(lines[i])) code.push(lines[i++]);
          i++;
          container.appendChild(this.codeBlock(code.join('\n'), lang, title, chapterTitle, container !== root));
          continue;
        }
        if ((m = /^::: exercicio\s*(.*)$/.exec(line))) {
          flush();
          const box = document.createElement('div');
          box.className = 'man-ex';
          const h = document.createElement('h4');
          h.textContent = 'Exercício' + (m[1] ? ': ' + m[1] : '');
          box.appendChild(h);
          root.appendChild(box);
          container = box;
          i++;
          continue;
        }
        if (/^:::\s*$/.test(line)) { flush(); container = root; i++; continue; }
        if ((m = /^(#{2,3}) (.+)$/.exec(line))) {
          flush();
          const h = document.createElement(m[1].length === 2 ? 'h2' : 'h3');
          h.textContent = m[2];
          container.appendChild(h);
          i++;
          continue;
        }
        if (/^- /.test(line)) {
          flush();
          const ul = document.createElement('ul');
          while (i < lines.length && /^- /.test(lines[i])) {
            const li = document.createElement('li');
            li.innerHTML = inline(lines[i].slice(2));
            ul.appendChild(li);
            i++;
          }
          container.appendChild(ul);
          continue;
        }
        if (/^\|/.test(line)) {
          flush();
          const table = document.createElement('table');
          let first = true;
          while (i < lines.length && /^\|/.test(lines[i])) {
            const cells = lines[i].replace(/^\||\|\s*$/g, '').split('|').map((s) => s.trim());
            if (cells.every((c) => /^-+$/.test(c))) { i++; continue; }
            const tr = document.createElement('tr');
            for (const c of cells) {
              const td = document.createElement(first ? 'th' : 'td');
              td.innerHTML = inline(c);
              tr.appendChild(td);
            }
            table.appendChild(tr);
            first = false;
            i++;
          }
          container.appendChild(table);
          continue;
        }
        if ((m = /^>(!?) ?(.*)$/.exec(line))) {
          flush();
          const d = document.createElement('div');
          d.className = 'man-tip' + (m[1] ? ' warn' : '');
          const txt = [m[2]];
          i++;
          while (i < lines.length && /^> ?/.test(lines[i]) && !/^>!/.test(lines[i])) { txt.push(lines[i].replace(/^> ?/, '')); i++; }
          d.innerHTML = '<p>' + inline(txt.join(' ')) + '</p>';
          container.appendChild(d);
          continue;
        }
        if (!line.trim()) { flush(); i++; continue; }
        para.push(line.trim());
        i++;
      }
      flush();
    }

    codeBlock(code, lang, title, chapterTitle, isSolution) {
      const wrap = document.createElement('div');
      wrap.className = 'man-code';
      const runnable = lang === 'luau';
      const isLuau = lang === 'luau' || lang === 'luau-frag';
      const head = document.createElement('div');
      head.className = 'man-code-head';
      const t = document.createElement('span');
      t.className = 't';
      t.textContent = title || (isSolution ? 'Solução' : isLuau ? 'Luau' : '');
      head.appendChild(t);
      const btn = (label, cls, fn, tip) => {
        const b = document.createElement('button');
        b.className = 'btn sm' + (cls ? ' ' + cls : '');
        b.textContent = label;
        if (tip) b.title = tip;
        b.addEventListener('click', fn);
        head.appendChild(b);
      };
      btn('Copiar', '', async () => {
        try { await navigator.clipboard.writeText(code); GF.App && GF.App.toast('Código copiado.'); } catch (e) { GF.App && GF.App.toast('Não foi possível copiar.', 'error'); }
      });
      if (isLuau) {
        btn('Novo script', '', () => this.hooks.onSend(code, 'new', title || chapterTitle), 'Cria um novo script no projeto com este código');
        btn('Substituir atual', '', () => this.hooks.onSend(code, 'replace', title || chapterTitle), 'Substitui o conteúdo do script aberto no editor');
      }
      if (runnable) btn('▶ Executar', 'run', () => this.hooks.onRun(code), 'Executa somente este exemplo na janela de teste');
      wrap.appendChild(head);
      const pre = document.createElement('pre');
      pre.className = 'cm-s-gameforge';
      if (isLuau) highlight(code, pre); else pre.textContent = code;
      if (isSolution) {
        const det = document.createElement('details');
        const sum = document.createElement('summary');
        sum.textContent = 'Ver solução';
        det.appendChild(sum);
        wrap.appendChild(pre);
        det.appendChild(wrap);
        return det;
      }
      wrap.appendChild(pre);
      return wrap;
    }
  }

  GF.Manual = Manual;
})();
