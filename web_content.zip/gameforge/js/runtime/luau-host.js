/*
 * GameForge Studio — ponte entre a VM Luau (WebAssembly) e o motor 3D.
 *
 * A VM é o interpretador oficial do Luau (github.com/luau-lang/luau) compilado
 * para WebAssembly (runtime/luau-runtime.js). Nenhum código do usuário é
 * convertido para JavaScript: o texto é compilado em bytecode Luau e executado
 * pela VM. O JavaScript só recebe chamadas da API do motor através de __host.
 */
(function () {
  'use strict';
  const GF = (window.GF = window.GF || {});

  const KIND = ['print', 'warn', 'error'];
  const BUDGET_PRELUDE = 8000;
  const BUDGET_SCRIPT = 3000;
  const BUDGET_STEP = 2500;
  const BUDGET_REPL = 2000;

  // ---------------------------------------------------------------- regras de scripts
  function baseName(path) {
    const f = path.split('/').pop();
    return f.replace(/\.(luau|lua)$/i, '');
  }
  function isScriptFile(path) { return /\.(luau|lua)$/i.test(path); }
  function isModule(file) {
    if (/^\s*--!module\b/.test(file.source || '')) return true;
    const parts = file.path.split('/');
    parts.pop();
    return parts.some((p) => p.toLowerCase() === 'modules');
  }
  function runnableScripts(files) {
    return files
      .filter((f) => isScriptFile(f.path) && !f.disabled && !isModule(f))
      .sort((a, b) => a.path.localeCompare(b.path));
  }
  function resolveModule(files, name) {
    name = String(name).replace(/^\.?\//, '');
    const lua = files.filter((f) => isScriptFile(f.path));
    const exact = lua.find((f) => f.path === name) || lua.find((f) => f.path === name + '.luau') || lua.find((f) => f.path === name + '.lua');
    if (exact) return exact;
    const bn = baseName(name);
    const cands = lua.filter((f) => baseName(f.path) === bn);
    if (!cands.length) return null;
    return cands.find((f) => f.path.split('/').slice(0, -1).some((p) => p.toLowerCase() === 'modules')) || cands[0];
  }

  // ---------------------------------------------------------------- carregamento da VM
  let modulePromise = null;
  function loadModule() {
    if (!modulePromise) {
      if (typeof window.createLuauRuntime !== 'function') {
        return Promise.reject(new Error('runtime/luau-runtime.js não foi carregado.'));
      }
      modulePromise = window.createLuauRuntime({
        print: (t) => console.log('[luau]', t),
        printErr: (t) => console.warn('[luau]', t),
      }).then((M) => {
        M.gfHost = {
          args: [],
          results: [],
          handler: null,
          out: null,
          invoke(op) {
            try {
              const r = this.handler ? this.handler(op, this.args) : [];
              this.results = r || [];
              return this.results.length;
            } catch (e) {
              this.results = [String(e && e.message ? e.message : e)];
              return -1;
            }
          },
          output(kind, text) { if (this.out) this.out(KIND[kind] || 'print', text); },
        };
        return M;
      });
    }
    return modulePromise;
  }

  // ---------------------------------------------------------------- verificação de sintaxe
  let checkerModule = null;
  function parseCompileError(msg) {
    // formato: ":LINHA: mensagem" ou "nome:LINHA: mensagem"
    const m = /:(\d+):\s*(.*)$/s.exec(msg);
    if (!m) return { line: 1, message: msg };
    return { line: parseInt(m[1], 10), message: m[2] };
  }

  class LuauRunner {
    constructor(engine, hooks) {
      this.engine = engine;
      this.hooks = hooks || {}; // output(kind,text), error(msg,traceback), stopped(reason)
      this.M = null;
      this.running = false;
      this.files = [];
    }

    async ready() {
      if (!this.M) this.M = await loadModule();
      checkerModule = this.M;
      return this.M;
    }

    call(fn, ...args) {
      return this.M.ccall(fn, 'string', args.map((a) => (typeof a === 'number' ? 'number' : 'string')), args);
    }

    /** Verifica a sintaxe com o compilador oficial. Retorna null ou {line,message}. */
    check(src) {
      if (!this.M) return null;
      const r = this.call('gf_check', src);
      return r ? parseCompileError(r) : null;
    }

    /** Inicia o jogo: cria a VM, carrega a API (prelude) e executa os scripts. */
    async run(files) {
      await this.ready();
      if (this.running) this.stop('restart');
      if (typeof window.GF_PRELUDE !== 'string') throw new Error('A API do GameForge (js/runtime/prelude.js) não foi carregada.');
      this.files = files.map((f) => ({ path: f.path, source: f.source, disabled: !!f.disabled }));
      const scripts = runnableScripts(this.files);
      const out = (kind, text) => { if (this.hooks.output) this.hooks.output(kind, String(text)); };
      const host = this.M.gfHost;
      host.out = out;
      host.handler = (op, args) => this.engine.host(op, args);

      this.engine.start({
        step: (dt) => this.step(dt),
        error: (msg, tb) => { if (this.hooks.error) this.hooks.error(msg, tb); },
        fatal: () => this.stop('fatal'),
        kick: (msg) => { out('warn', 'Jogador removido: ' + msg); this.stop('kick'); },
        resolveModule: (name) => resolveModule(this.files, name),
        output: out,
      });
      this.running = true;
      this.M._gf_init();
      const perr = this.call('gf_exec_global', 'GameForgeAPI', window.GF_PRELUDE, BUDGET_PRELUDE);
      if (perr) {
        out('error', 'Falha ao iniciar a API do GameForge: ' + perr);
        this.stop('fatal');
        return false;
      }
      if (!scripts.length) out('warn', 'Nenhum script executável no projeto (scripts em "Modules" só rodam via require).');
      for (const s of scripts) {
        if (!this.running) break;
        const err = this.call('gf_run_script', s.path, s.source, BUDGET_SCRIPT);
        if (err && this.hooks.error) this.hooks.error(err, '');
      }
      return this.running;
    }

    step(dt) {
      if (!this.running) return false;
      const err = this.call('gf_step', dt, BUDGET_STEP);
      if (err) {
        if (this.hooks.error) this.hooks.error(err, '');
        // erro no agendador = estado inconsistente; encerra o jogo
        this.stop('fatal');
        return false;
      }
      return true;
    }

    /** Executa uma linha do console dentro do jogo em andamento. */
    repl(code) {
      if (!this.running) return 'O jogo não está em execução. Clique em Executar primeiro.';
      const isExpr = !this.check('return ' + code) && !/^\s*(local|for|while|if|function|repeat|return|do)\b/.test(code);
      const src = isExpr ? 'print(' + code + ')' : code;
      const err = this.call('gf_run_script', 'Console', src, BUDGET_REPL);
      return err || '';
    }

    stop(reason) {
      if (!this.running) return;
      this.running = false;
      try { this.call('gf_exec_global', 'shutdown', 'if __gf_shutdown then __gf_shutdown() end', 1000); } catch (e) { /* ignore */ }
      try { this.M._gf_close(); } catch (e) { /* ignore */ }
      this.engine.stop();
      if (this.hooks.stopped) this.hooks.stopped(reason || 'user');
    }

    memoryKB() { return this.M && this.running ? this.M._gf_memory_kb() : 0; }
  }

  GF.LuauRunner = LuauRunner;
  GF.loadLuau = loadModule;
  GF.scriptRules = { isModule, isScriptFile, runnableScripts, resolveModule, baseName };
})();
