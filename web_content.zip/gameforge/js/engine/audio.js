/* GameForge Studio — Sistema de áudio (Web Audio API).
 * Sons embutidos são sintetizados localmente (funcionam offline).
 * SoundId com http(s):// depende de internet e de o servidor permitir CORS. */
(function () {
  'use strict';
  const GF = (window.GF = window.GF || {});

  const BUILTIN = ['sfx:jump', 'sfx:coin', 'sfx:explosion', 'sfx:hit', 'sfx:laser', 'sfx:click', 'sfx:powerup', 'sfx:hurt', 'sfx:win', 'sfx:lose', 'sfx:step', 'sfx:thunder', 'sfx:swing', 'sfx:door', 'sfx:bell', 'ambient:rain', 'ambient:wind', 'ambient:birds', 'music:adventure', 'music:calm', 'music:battle'];

  class AudioSystem {
    constructor() {
      this.ctx = null;
      this.master = null;
      this.buffers = {};
      this.sounds = new Map(); // id -> estado
      this.volume = 1;
      this.listener = { pos: new THREE.Vector3(), fwd: new THREE.Vector3(0, 0, -1) };
      this.ambient = {};
    }

    ensure() {
      if (this.ctx) {
        if (this.ctx.state === 'suspended') this.ctx.resume();
        return this.ctx;
      }
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.volume;
      this.master.connect(this.ctx.destination);
      return this.ctx;
    }

    setMasterVolume(v) {
      this.volume = v;
      if (this.master) this.master.gain.value = v;
    }

    // ---------- síntese ----------
    synth(name) {
      const ctx = this.ctx;
      const sr = ctx.sampleRate;
      const mk = (dur) => ctx.createBuffer(1, Math.max(1, Math.floor(sr * dur)), sr);
      const env = (t, a, d) => (t < a ? t / a : Math.exp(-(t - a) / d));
      let buf, ch, n;
      const tone = (data, f0, f1, dur, type, vol, start) => {
        const s0 = Math.floor((start || 0) * sr);
        const len = Math.floor(dur * sr);
        let ph = 0;
        for (let i = 0; i < len && s0 + i < data.length; i++) {
          const t = i / sr;
          const f = f0 + (f1 - f0) * (t / dur);
          ph += (2 * Math.PI * f) / sr;
          let v;
          if (type === 'square') v = Math.sign(Math.sin(ph)) * 0.5;
          else if (type === 'saw') v = ((ph / Math.PI) % 2) - 1;
          else if (type === 'tri') v = (2 / Math.PI) * Math.asin(Math.sin(ph));
          else v = Math.sin(ph);
          data[s0 + i] += v * vol * env(t, 0.005, dur / 3);
        }
      };
      const noise = (data, dur, vol, lp, start, decay) => {
        const s0 = Math.floor((start || 0) * sr);
        let last = 0;
        for (let i = 0; i < dur * sr && s0 + i < data.length; i++) {
          const t = i / sr;
          const w = Math.random() * 2 - 1;
          last = last + lp * (w - last);
          data[s0 + i] += last * vol * env(t, 0.003, decay || dur / 4);
        }
      };
      switch (name) {
        case 'sfx:jump': buf = mk(0.25); ch = buf.getChannelData(0); tone(ch, 300, 700, 0.25, 'square', 0.35); break;
        case 'sfx:coin': buf = mk(0.35); ch = buf.getChannelData(0); tone(ch, 988, 988, 0.08, 'square', 0.3); tone(ch, 1319, 1319, 0.27, 'square', 0.3, 0.08); break;
        case 'sfx:explosion': buf = mk(1.6); ch = buf.getChannelData(0); noise(ch, 1.6, 1.2, 0.08, 0, 0.35); tone(ch, 80, 30, 0.8, 'sine', 0.6); break;
        case 'sfx:hit': buf = mk(0.2); ch = buf.getChannelData(0); noise(ch, 0.2, 0.9, 0.3, 0, 0.04); tone(ch, 160, 60, 0.15, 'sine', 0.6); break;
        case 'sfx:laser': buf = mk(0.3); ch = buf.getChannelData(0); tone(ch, 1500, 200, 0.3, 'saw', 0.25); break;
        case 'sfx:click': buf = mk(0.05); ch = buf.getChannelData(0); tone(ch, 1800, 1200, 0.05, 'square', 0.25); break;
        case 'sfx:powerup': buf = mk(0.6); ch = buf.getChannelData(0); [523, 659, 784, 1047].forEach((f, i) => tone(ch, f, f, 0.15, 'square', 0.22, i * 0.12)); break;
        case 'sfx:hurt': buf = mk(0.35); ch = buf.getChannelData(0); tone(ch, 400, 120, 0.35, 'saw', 0.3); break;
        case 'sfx:win': buf = mk(1.2); ch = buf.getChannelData(0); [523, 659, 784, 1047, 784, 1047].forEach((f, i) => tone(ch, f, f, 0.25, 'tri', 0.35, i * 0.15)); break;
        case 'sfx:lose': buf = mk(1.0); ch = buf.getChannelData(0); [392, 370, 349, 262].forEach((f, i) => tone(ch, f, f * 0.98, 0.3, 'tri', 0.35, i * 0.22)); break;
        case 'sfx:step': buf = mk(0.08); ch = buf.getChannelData(0); noise(ch, 0.08, 0.35, 0.2, 0, 0.02); break;
        case 'sfx:thunder': buf = mk(3.5); ch = buf.getChannelData(0); noise(ch, 3.5, 1.5, 0.03, 0, 0.9); noise(ch, 0.3, 0.9, 0.3, 0, 0.08); break;
        case 'sfx:swing': buf = mk(0.25); ch = buf.getChannelData(0); noise(ch, 0.25, 0.6, 0.15, 0, 0.08); break;
        case 'sfx:door': buf = mk(0.6); ch = buf.getChannelData(0); tone(ch, 120, 90, 0.6, 'saw', 0.15); noise(ch, 0.1, 0.5, 0.2, 0.45, 0.04); break;
        case 'sfx:bell': buf = mk(1.5); ch = buf.getChannelData(0); tone(ch, 880, 880, 1.5, 'sine', 0.35); tone(ch, 1760, 1760, 1.0, 'sine', 0.12); break;
        case 'ambient:rain': buf = mk(3); ch = buf.getChannelData(0); { let l = 0; for (let i = 0; i < ch.length; i++) { l += 0.5 * ((Math.random() * 2 - 1) - l); ch[i] = l * 0.5 + (Math.random() < 0.0008 ? (Math.random() - 0.5) * 0.6 : 0); } } break;
        case 'ambient:wind': buf = mk(4); ch = buf.getChannelData(0); { let l = 0; for (let i = 0; i < ch.length; i++) { const t = i / sr; l += 0.02 * ((Math.random() * 2 - 1) - l); ch[i] = l * 3 * (0.6 + 0.4 * Math.sin(t * 1.5)); } } break;
        case 'ambient:birds': buf = mk(4); ch = buf.getChannelData(0); for (let k = 0; k < 7; k++) { const st = Math.random() * 3.5, f = 2500 + Math.random() * 1500; tone(ch, f, f * 1.3, 0.12, 'sine', 0.15, st); tone(ch, f * 1.2, f, 0.1, 'sine', 0.12, st + 0.13); } break;
        case 'music:adventure':
        case 'music:calm':
        case 'music:battle': {
          const bpm = name === 'music:battle' ? 150 : name === 'music:calm' ? 80 : 118;
          const beat = 60 / bpm;
          const scale = name === 'music:battle' ? [220, 247, 262, 294, 330, 349, 392, 440] : [262, 294, 330, 392, 440, 523, 587, 659];
          const bars = 8, steps = bars * 4;
          buf = mk(steps * beat); ch = buf.getChannelData(0);
          const melody = name === 'music:calm' ? [0, 2, 4, 2, 5, 4, 2, 1, 0, 2, 4, 5, 7, 5, 4, 2] : [0, 4, 7, 4, 5, 4, 2, 4, 0, 4, 7, 6, 5, 4, 2, 0];
          const bass = [0, 0, 5, 5, 3, 3, 4, 4];
          for (let s = 0; s < steps; s++) {
            const t = s * beat;
            const m = scale[melody[s % melody.length] % scale.length];
            tone(ch, m, m, beat * 0.9, name === 'music:calm' ? 'sine' : 'tri', 0.18, t);
            if (s % 4 === 0) { const b = scale[bass[(s / 4) % bass.length]] / 2; tone(ch, b, b, beat * 3.5, 'tri', 0.2, t); }
            if (name !== 'music:calm') noise(ch, 0.05, s % 2 ? 0.12 : 0.3, s % 2 ? 0.9 : 0.1, t, 0.02);
          }
          break;
        }
        default: return null;
      }
      // normaliza
      ch = buf.getChannelData(0);
      let peak = 0;
      for (let i = 0; i < ch.length; i++) peak = Math.max(peak, Math.abs(ch[i]));
      if (peak > 1) for (let i = 0; i < ch.length; i++) ch[i] /= peak;
      return buf;
    }

    async loadBuffer(id) {
      if (this.buffers[id]) return this.buffers[id];
      if (!this.ensure()) throw new Error('Web Audio não suportado neste navegador');
      if (BUILTIN.includes(id)) {
        const b = this.synth(id);
        this.buffers[id] = b;
        return b;
      }
      if (/^(https?:|data:|blob:)/.test(id)) {
        const res = await fetch(id);
        if (!res.ok) throw new Error('Falha ao baixar som: HTTP ' + res.status);
        const arr = await res.arrayBuffer();
        const b = await this.ctx.decodeAudioData(arr);
        this.buffers[id] = b;
        return b;
      }
      throw new Error('SoundId inválido: "' + id + '". Use um som embutido (' + BUILTIN.join(', ') + ') ou uma URL.');
    }

    // ---------- instâncias Sound ----------
    play(id, props, getPos, onEnded, onError) {
      this.stop(id);
      const ctx = this.ensure();
      if (!ctx) return;
      const sid = props.SoundId || '';
      const st = { playing: true, startedAt: ctx.currentTime, offset: props._offset || 0, getPos };
      this.sounds.set(id, st);
      this.loadBuffer(sid).then((buf) => {
        if (!st.playing || this.sounds.get(id) !== st) return;
        const src = ctx.createBufferSource();
        src.buffer = buf;
        src.loop = !!props.Looped;
        src.playbackRate.value = props.PlaybackSpeed || 1;
        const gain = ctx.createGain();
        gain.gain.value = Math.max(0, props.Volume == null ? 0.5 : props.Volume) * (props._serviceVolume == null ? 1 : props._serviceVolume);
        let node = src;
        src.connect(gain);
        if (getPos) {
          const pan = ctx.createPanner();
          pan.panningModel = 'HRTF';
          pan.distanceModel = 'linear';
          pan.refDistance = 5;
          pan.maxDistance = props.RollOffMaxDistance || 100;
          pan.rolloffFactor = 1;
          gain.connect(pan);
          pan.connect(this.master);
          st.panner = pan;
        } else {
          gain.connect(this.master);
        }
        st.src = src; st.gain = gain; st.duration = buf.duration;
        src.onended = () => {
          if (this.sounds.get(id) === st && st.playing && !src.loop) {
            st.playing = false;
            this.sounds.delete(id);
            onEnded && onEnded();
          }
        };
        src.start(0, Math.min(st.offset, buf.duration - 0.001));
        st.startedAt = ctx.currentTime - st.offset;
        void node;
      }).catch((e) => { st.playing = false; onError && onError(e.message || String(e)); });
    }

    stop(id) {
      const st = this.sounds.get(id);
      if (st) {
        st.playing = false;
        try { st.src && st.src.stop(); } catch (e) { /* já parado */ }
        this.sounds.delete(id);
      }
    }

    pause(id) {
      const st = this.sounds.get(id);
      if (st && this.ctx) {
        const off = this.ctx.currentTime - st.startedAt;
        this.stop(id);
        return off;
      }
      return 0;
    }

    update(id, props) {
      const st = this.sounds.get(id);
      if (!st || !st.src) return;
      st.gain.gain.value = Math.max(0, props.Volume) * (props._serviceVolume == null ? 1 : props._serviceVolume);
      st.src.playbackRate.value = props.PlaybackSpeed || 1;
      st.src.loop = !!props.Looped;
    }

    length(sid) {
      const b = this.buffers[sid];
      return b ? b.duration : 0;
    }

    // efeito único (motor)
    oneShot(sid, volume, pos) {
      const ctx = this.ensure();
      if (!ctx) return;
      this.loadBuffer(sid).then((buf) => {
        const src = ctx.createBufferSource();
        src.buffer = buf;
        const g = ctx.createGain();
        g.gain.value = volume == null ? 0.5 : volume;
        src.connect(g);
        if (pos) {
          const p = ctx.createPanner();
          p.distanceModel = 'linear'; p.refDistance = 8; p.maxDistance = 200;
          p.positionX ? (p.positionX.value = pos.x, p.positionY.value = pos.y, p.positionZ.value = pos.z) : p.setPosition(pos.x, pos.y, pos.z);
          g.connect(p); p.connect(this.master);
        } else g.connect(this.master);
        src.start();
      }).catch(() => {});
    }

    // som ambiente contínuo (chuva, vento)
    setAmbient(sid, volume) {
      const ctx = this.ctx;
      if (!ctx) return;
      let a = this.ambient[sid];
      if (volume <= 0.001) {
        if (a) { try { a.src.stop(); } catch (e) {} delete this.ambient[sid]; }
        return;
      }
      if (!a) {
        a = this.ambient[sid] = { pending: true };
        this.loadBuffer(sid).then((buf) => {
          if (this.ambient[sid] !== a) return;
          const src = ctx.createBufferSource();
          src.buffer = buf; src.loop = true;
          const g = ctx.createGain(); g.gain.value = 0;
          src.connect(g); g.connect(this.master); src.start();
          a.src = src; a.gain = g; a.pending = false;
          a.gain.gain.value = a.target || 0;
        });
      }
      a.target = volume;
      if (a.gain) a.gain.gain.value += (volume - a.gain.gain.value) * 0.1;
    }

    frame(camera) {
      if (!this.ctx) return;
      const l = this.ctx.listener;
      const p = camera.position;
      const f = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
      const u = new THREE.Vector3(0, 1, 0).applyQuaternion(camera.quaternion);
      if (l.positionX) {
        l.positionX.value = p.x; l.positionY.value = p.y; l.positionZ.value = p.z;
        l.forwardX.value = f.x; l.forwardY.value = f.y; l.forwardZ.value = f.z;
        l.upX.value = u.x; l.upY.value = u.y; l.upZ.value = u.z;
      } else if (l.setPosition) {
        l.setPosition(p.x, p.y, p.z);
        l.setOrientation(f.x, f.y, f.z, u.x, u.y, u.z);
      }
      for (const st of this.sounds.values()) {
        if (st.panner && st.getPos) {
          const pos = st.getPos();
          if (pos) {
            if (st.panner.positionX) { st.panner.positionX.value = pos.x; st.panner.positionY.value = pos.y; st.panner.positionZ.value = pos.z; }
            else st.panner.setPosition(pos.x, pos.y, pos.z);
          }
        }
      }
    }

    stopAll() {
      for (const id of Array.from(this.sounds.keys())) this.stop(id);
      for (const k of Object.keys(this.ambient)) this.setAmbient(k, 0);
    }
  }

  GF.AudioSystem = AudioSystem;
  GF.BUILTIN_SOUNDS = BUILTIN;
})();
