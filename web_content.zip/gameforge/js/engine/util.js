/* GameForge Studio — utilidades compartilhadas do motor 3D. */
(function () {
  'use strict';
  const GF = (window.GF = window.GF || {});

  // CFrame do Luau: [x, y, z, r00, r01, r02, r10, r11, r12, r20, r21, r22]
  GF.matrixFromCF = function (cf, out) {
    const m = out || new THREE.Matrix4();
    m.set(cf[3], cf[4], cf[5], cf[0], cf[6], cf[7], cf[8], cf[1], cf[9], cf[10], cf[11], cf[2], 0, 0, 0, 1);
    return m;
  };
  GF.quatFromCF = function (cf) {
    const m = GF.matrixFromCF(cf);
    return new THREE.Quaternion().setFromRotationMatrix(m);
  };
  GF.cfFrom = function (pos, quat) {
    const e = new THREE.Matrix4().makeRotationFromQuaternion(quat).elements; // coluna-maior
    return [pos.x, pos.y, pos.z, e[0], e[4], e[8], e[1], e[5], e[9], e[2], e[6], e[10]];
  };

  // Cunha (WedgePart): parte alta em +Z, rampa voltada para -Z (frente)
  GF.wedgeGeometry = function (sx, sy, sz) {
    const shape = new THREE.Shape();
    shape.moveTo(-sz / 2, -sy / 2);
    shape.lineTo(sz / 2, -sy / 2);
    shape.lineTo(sz / 2, sy / 2);
    shape.lineTo(-sz / 2, -sy / 2);
    const geo = new THREE.ExtrudeGeometry(shape, { depth: sx, bevelEnabled: false });
    // shape no plano XY (x=z local, y=y), extrusão em +Z => girar para extrusão em X
    geo.translate(0, 0, -sx / 2);
    geo.rotateY(-Math.PI / 2);
    // após girar: x_shape -> z ; z_extrusão -> x
    geo.computeVertexNormals();
    return geo;
  };

  // Colisores em degraus para rampas (permitem subir caminhando)
  GF.wedgeSlabs = function (pos, quat, size) {
    const n = Math.max(1, Math.min(40, Math.ceil(size.y / 0.6)));
    const h = size.y / n;
    const out = [];
    for (let i = 0; i < n; i++) {
      const z0 = -size.z / 2 + (size.z * (i + 0.5)) / n, z1 = size.z / 2;
      const local = new THREE.Vector3(0, -size.y / 2 + (i + 0.5) * h, (z0 + z1) / 2);
      out.push({ pos: local.applyQuaternion(quat).add(pos), size: new THREE.Vector3(size.x, h, z1 - z0) });
    }
    return out;
  };

  GF.clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  GF.escapeHtml = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
})();
