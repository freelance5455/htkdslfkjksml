/* GameForge Studio — Terreno: relevo por mapa de altura (GenerateHills) e preenchimentos
 * (FillBlock, FillBall, FillCylinder, FillWedge) que viram colisores estáticos. */
(function () {
  'use strict';
  const GF = (window.GF = window.GF || {});

  // ruído de valor suave e determinístico
  function makeNoise(seed) {
    const perm = new Uint8Array(512);
    let s = (seed * 9301 + 49297) % 233280 || 1;
    const rnd = () => ((s = (s * 16807) % 2147483647) / 2147483647);
    const p = Array.from({ length: 256 }, (_, i) => i);
    for (let i = 255; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [p[i], p[j]] = [p[j], p[i]]; }
    for (let i = 0; i < 512; i++) perm[i] = p[i & 255];
    const val = (x, z) => perm[(perm[x & 255] + z) & 511] / 255;
    const sm = (t) => t * t * (3 - 2 * t);
    const n2 = (x, z) => {
      const xi = Math.floor(x), zi = Math.floor(z), xf = x - xi, zf = z - zi;
      const a = val(xi, zi), b = val(xi + 1, zi), c = val(xi, zi + 1), d = val(xi + 1, zi + 1);
      const u = sm(xf), v = sm(zf);
      return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
    };
    return (x, z) => {
      let sum = 0, amp = 1, f = 1, norm = 0;
      for (let o = 0; o < 5; o++) { sum += n2(x * f, z * f) * amp; norm += amp; amp *= 0.5; f *= 2; }
      return sum / norm;
    };
  }

  const MAT_COLOR = {
    Grass: [0.36, 0.6, 0.3], LeafyGrass: [0.3, 0.55, 0.25], Sand: [0.85, 0.78, 0.55], Snow: [0.95, 0.96, 1], Rock: [0.45, 0.45, 0.47],
    Ground: [0.45, 0.35, 0.25], Mud: [0.35, 0.27, 0.2], Slate: [0.35, 0.37, 0.4], Ice: [0.7, 0.85, 0.95], Basalt: [0.25, 0.25, 0.27],
    Sandstone: [0.75, 0.55, 0.4], Concrete: [0.6, 0.6, 0.6], Water: [0.1, 0.35, 0.4], CrackedLava: [0.6, 0.2, 0.05], Asphalt: [0.2, 0.2, 0.22],
  };

  class Terrain {
    constructor(engine) {
      this.engine = engine;
      this.group = new THREE.Group();
      engine.scene.add(this.group);
      this.hm = null;
      this.pieces = []; // corpos estáticos
      this.count = 0;
      this.terrainId = null;
    }

    color(material) {
      const c = MAT_COLOR[material] || MAT_COLOR.Grass;
      return { r: c[0], g: c[1], b: c[2] };
    }

    material(material) {
      const m = new THREE.MeshStandardMaterial({ roughness: 1 });
      GF.Materials.applyMaterial(m, { material, color: this.color(material) });
      return m;
    }

    addPiece(mesh, pos, quat, size, material, shape) {
      mesh.castShadow = true; mesh.receiveShadow = true;
      this.group.add(mesh);
      const body = {
        id: this.terrainId, isTerrain: true, pos: pos.clone(), quat: quat.clone(), size: size.clone(), half: new THREE.Vector3(), radius: 0,
        shape: shape || 'Block', canCollide: true, canTouch: false, friction: 0.7, elasticity: 0.1, material, vel: new THREE.Vector3(),
      };
      GF.Physics.updateHalf(body);
      body.radius = 0;
      this.pieces.push(body);
      this.engine.physics.markDirty();
      return body;
    }

    uv(geo, scale) {
      // UV em unidades do mundo para que a textura não estique
      const pos = geo.attributes.position, nrm = geo.attributes.normal;
      const uv = new Float32Array(pos.count * 2);
      for (let i = 0; i < pos.count; i++) {
        const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
        const ax = Math.abs(nrm.getX(i)), ay = Math.abs(nrm.getY(i)), az = Math.abs(nrm.getZ(i));
        let u, v;
        if (ay >= ax && ay >= az) { u = x; v = z; } else if (ax >= az) { u = z; v = y; } else { u = x; v = y; }
        uv[i * 2] = u / scale; uv[i * 2 + 1] = v / scale;
      }
      geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    }

    fillBlock(cf, size, material) {
      const pos = new THREE.Vector3(cf[0], cf[1], cf[2]);
      const quat = GF.quatFromCF(cf);
      const geo = new THREE.BoxGeometry(size.x, size.y, size.z);
      geo.scale(1, 1, 1);
      // UV mundial aproximado
      const g2 = geo.clone(); g2.applyQuaternion(quat); g2.translate(pos.x, pos.y, pos.z);
      this.uv(g2, 8);
      geo.setAttribute('uv', g2.attributes.uv);
      const mesh = new THREE.Mesh(geo, this.material(material));
      mesh.position.copy(pos); mesh.quaternion.copy(quat);
      this.addPiece(mesh, pos, quat, size, material);
    }

    fillBall(center, radius, material) {
      const geo = new THREE.SphereGeometry(radius, 24, 16);
      const g2 = geo.clone(); g2.translate(center.x, center.y, center.z); this.uv(g2, 8);
      geo.setAttribute('uv', g2.attributes.uv);
      const mesh = new THREE.Mesh(geo, this.material(material));
      mesh.position.copy(center);
      this.group.add(mesh); mesh.castShadow = mesh.receiveShadow = true;
      // colisão em camadas (permite subir na esfera)
      const n = Math.max(3, Math.min(12, Math.ceil(radius / 1.2)));
      const id = new THREE.Quaternion();
      for (let i = 0; i < n; i++) {
        const y0 = -radius + (2 * radius * i) / n, y1 = -radius + (2 * radius * (i + 1)) / n;
        const ym = Math.abs((y0 + y1) / 2) < Math.abs(y0) && Math.abs((y0 + y1) / 2) < Math.abs(y1) ? 0 : Math.min(Math.abs(y0), Math.abs(y1));
        const w = Math.sqrt(Math.max(0, radius * radius - ym * ym)) * 0.85;
        if (w < 0.2) continue;
        const body = {
          id: this.terrainId, isTerrain: true, pos: new THREE.Vector3(center.x, center.y + (y0 + y1) / 2, center.z), quat: id.clone(),
          size: new THREE.Vector3(w * 2, y1 - y0, w * 2), half: new THREE.Vector3(w, (y1 - y0) / 2, w), radius: 0, shape: 'Block',
          canCollide: true, canTouch: false, friction: 0.7, elasticity: 0.1, material, vel: new THREE.Vector3(),
        };
        this.pieces.push(body);
      }
      this.engine.physics.markDirty();
    }

    fillCylinder(cf, height, radius, material) {
      const pos = new THREE.Vector3(cf[0], cf[1], cf[2]);
      const quat = GF.quatFromCF(cf);
      const geo = new THREE.CylinderGeometry(radius, radius, height, 24);
      const g2 = geo.clone(); g2.applyQuaternion(quat); g2.translate(pos.x, pos.y, pos.z); this.uv(g2, 8);
      geo.setAttribute('uv', g2.attributes.uv);
      const mesh = new THREE.Mesh(geo, this.material(material));
      mesh.position.copy(pos); mesh.quaternion.copy(quat);
      // cilindro vertical: caixa inscrita (0.85 r)
      this.addPiece(mesh, pos, quat, new THREE.Vector3(radius * 1.7, height, radius * 1.7), material);
    }

    fillWedge(cf, size, material) {
      const pos = new THREE.Vector3(cf[0], cf[1], cf[2]);
      const quat = GF.quatFromCF(cf);
      const geo = GF.wedgeGeometry(size.x, size.y, size.z);
      const g2 = geo.clone(); g2.applyQuaternion(quat); g2.translate(pos.x, pos.y, pos.z); this.uv(g2, 8);
      geo.setAttribute('uv', g2.attributes.uv);
      const mesh = new THREE.Mesh(geo, this.material(material));
      mesh.position.copy(pos); mesh.quaternion.copy(quat);
      mesh.castShadow = mesh.receiveShadow = true;
      this.group.add(mesh);
      for (const s of GF.wedgeSlabs(pos, quat, size)) {
        const body = {
          id: this.terrainId, isTerrain: true, pos: s.pos, quat: quat.clone(), size: s.size, half: new THREE.Vector3(), radius: 0, shape: 'Block',
          canCollide: true, canTouch: false, friction: 0.7, elasticity: 0.1, material, vel: new THREE.Vector3(),
        };
        GF.Physics.updateHalf(body);
        this.pieces.push(body);
      }
      this.engine.physics.markDirty();
    }

    generateHills(size, height, seed, scale, material, waterLevel, resolution) {
      if (this.hm) { this.group.remove(this.hm.mesh); this.hm.mesh.geometry.dispose(); if (this.hm.water) this.group.remove(this.hm.water); }
      size = Math.max(16, Math.min(4096, size || 256));
      const res = Math.max(16, Math.min(256, Math.floor(resolution || 128)));
      scale = Math.max(4, scale || 60);
      const noise = makeNoise(Math.floor(seed || 1));
      const n = res + 1;
      const heights = new Float32Array(n * n);
      const cell = size / res;
      const ox = -size / 2, oz = -size / 2;
      for (let j = 0; j < n; j++) {
        for (let i = 0; i < n; i++) {
          const x = ox + i * cell, z = oz + j * cell;
          let h = noise(x / scale + 100, z / scale + 100);
          h = Math.pow(h, 1.6) * height;
          // borda suave para baixo
          const edge = Math.min(i, j, res - i, res - j) / (res * 0.08);
          if (edge < 1) h *= Math.max(0, edge);
          heights[j * n + i] = h;
        }
      }
      const geo = new THREE.PlaneGeometry(size, size, res, res);
      geo.rotateX(-Math.PI / 2);
      const p = geo.attributes.position;
      const colors = new Float32Array(p.count * 3);
      const base = this.color(material);
      const sand = { r: 0.82, g: 0.76, b: 0.55 }, rock = { r: 0.48, g: 0.47, b: 0.46 }, snow = { r: 0.95, g: 0.96, b: 1 };
      for (let k = 0; k < p.count; k++) {
        const i = Math.round((p.getX(k) - ox) / cell), j = Math.round((p.getZ(k) - oz) / cell);
        const h = heights[j * n + i];
        p.setY(k, h);
      }
      geo.computeVertexNormals();
      const nr = geo.attributes.normal;
      const wl = waterLevel != null && waterLevel > -1e8 ? waterLevel : null;
      for (let k = 0; k < p.count; k++) {
        const h = p.getY(k), slope = 1 - nr.getY(k);
        let c = base;
        if (wl != null && h < wl + 1.2) c = sand;
        else if (slope > 0.35) c = rock;
        else if (h > height * 0.85 && material === 'Grass') c = snow;
        colors[k * 3] = c.r; colors[k * 3 + 1] = c.g; colors[k * 3 + 2] = c.b;
      }
      geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
      this.uv(geo, 8);
      const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1 });
      mat.map = GF.Materials.getTexture((GF.Materials.MATERIALS[material] || {}).tex || 'grass');
      const mesh = new THREE.Mesh(geo, mat);
      mesh.receiveShadow = true; mesh.castShadow = true;
      this.group.add(mesh);
      let water = null;
      if (wl != null) {
        const tp = this.engine.terrainProps();
        const wc = tp.WaterColor || { r: 0.05, g: 0.33, b: 0.36 };
        const wm = new THREE.MeshStandardMaterial({ color: new THREE.Color(wc.r, wc.g, wc.b), transparent: true, opacity: 1 - (tp.WaterTransparency == null ? 0.3 : tp.WaterTransparency), roughness: 0.1, metalness: 0.2 });
        water = new THREE.Mesh(new THREE.PlaneGeometry(size, size), wm);
        water.rotation.x = -Math.PI / 2; water.position.y = wl;
        this.group.add(water);
      }
      this.hm = { size, res, n, cell, ox, oz, heights, mesh, water, waterLevel: wl, material };
    }

    heightAt(x, z) {
      const hm = this.hm;
      if (!hm) return null;
      const fx = (x - hm.ox) / hm.cell, fz = (z - hm.oz) / hm.cell;
      if (fx < 0 || fz < 0 || fx > hm.res || fz > hm.res) return null;
      const i = Math.min(hm.res - 1, Math.floor(fx)), j = Math.min(hm.res - 1, Math.floor(fz));
      const u = fx - i, v = fz - j, n = hm.n, H = hm.heights;
      // mesma triangulação do PlaneGeometry
      const a = H[j * n + i], b = H[j * n + i + 1], c = H[(j + 1) * n + i], d = H[(j + 1) * n + i + 1];
      if (u + v <= 1) return a + (b - a) * u + (c - a) * v;
      return d + (c - d) * (1 - u) + (b - d) * (1 - v);
    }

    // raio contra o relevo (marcha simples)
    raycastHeightmap(o, d, maxDist) {
      if (!this.hm) return null;
      const steps = Math.min(800, Math.ceil(maxDist / 0.5));
      const len = d.length();
      if (len < 1e-9) return null;
      const dir = d.clone().divideScalar(len);
      let prev = 0;
      for (let s = 1; s <= steps; s++) {
        const t = (s / steps) * Math.min(maxDist, len);
        const x = o.x + dir.x * t, y = o.y + dir.y * t, z = o.z + dir.z * t;
        const h = this.heightAt(x, z);
        if (h != null && y <= h) {
          // refina
          let lo = prev, hi = t;
          for (let k = 0; k < 8; k++) {
            const m = (lo + hi) / 2;
            const hh = this.heightAt(o.x + dir.x * m, o.z + dir.z * m);
            if (hh != null && o.y + dir.y * m <= hh) hi = m; else lo = m;
          }
          const px = o.x + dir.x * hi, pz = o.z + dir.z * hi;
          const e = 0.5;
          const hx = (this.heightAt(px + e, pz) ?? h) - (this.heightAt(px - e, pz) ?? h);
          const hz = (this.heightAt(px, pz + e) ?? h) - (this.heightAt(px, pz - e) ?? h);
          const nrm = new THREE.Vector3(-hx, 2 * e, -hz).normalize();
          return { point: new THREE.Vector3(px, o.y + dir.y * hi, pz), normal: nrm, dist: hi, material: this.hm.material };
        }
        prev = t;
      }
      return null;
    }

    clear() {
      for (const ch of [...this.group.children]) {
        this.group.remove(ch);
        if (ch.geometry) ch.geometry.dispose();
      }
      this.hm = null;
      this.pieces = [];
      this.engine.physics.markDirty();
    }

    dispose() {
      this.clear();
      this.engine.scene.remove(this.group);
    }
  }

  GF.Terrain = Terrain;
})();
