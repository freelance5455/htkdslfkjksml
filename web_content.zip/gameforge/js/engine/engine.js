/* GameForge Studio — Motor 3D (Three.js). Mantém um espelho das instâncias criadas
 * pelos scripts Luau e executa as operações recebidas pela ponte __host(). */
(function () {
  'use strict';
  const GF = (window.GF = window.GF || {});

  const PART_CLASSES = new Set(['Part', 'WedgePart', 'SpawnLocation', 'Seat', 'TrussPart']);
  const PARTICLE_CLASSES = new Set(['ParticleEmitter', 'Fire', 'Smoke', 'Sparkles']);
  const LIGHT_CLASSES = new Set(['PointLight', 'SpotLight', 'SurfaceLight']);
  const VALUE_CLASSES = new Set(['IntValue', 'NumberValue', 'StringValue', 'BoolValue']);
  const TAG_SIZE = { num: 1, bool: 1, str: 1, v3: 3, v2: 2, c3: 3, cf: 12, u2: 4, u1: 2, enum: 1, inst: 1, nr: 2, cs: 6, nil: 0 };
  const FACE = {
    Front: [0, 0, -1], Back: [0, 0, 1], Top: [0, 1, 0], Bottom: [0, -1, 0], Left: [-1, 0, 0], Right: [1, 0, 0],
  };

  function decode(a, i) {
    const tag = a[i];
    switch (tag) {
      case 'num': case 'bool': case 'str': case 'enum': return [a[i + 1], i + 2];
      case 'inst': return [a[i + 1] == null ? null : a[i + 1], i + 2];
      case 'v3': return [new THREE.Vector3(a[i + 1], a[i + 2], a[i + 3]), i + 4];
      case 'v2': return [{ x: a[i + 1], y: a[i + 2] }, i + 3];
      case 'c3': return [{ r: a[i + 1], g: a[i + 2], b: a[i + 3] }, i + 4];
      case 'cf': return [a.slice(i + 1, i + 13), i + 13];
      case 'u2': return [{ xs: a[i + 1], xo: a[i + 2], ys: a[i + 3], yo: a[i + 4] }, i + 5];
      case 'u1': return [{ s: a[i + 1], o: a[i + 2] }, i + 3];
      case 'nr': return [{ min: a[i + 1], max: a[i + 2] }, i + 3];
      case 'cs': return [{ a: { r: a[i + 1], g: a[i + 2], b: a[i + 3] }, b: { r: a[i + 4], g: a[i + 5], b: a[i + 6] } }, i + 7];
      case 'nil': return [null, i + 1];
      default: return [null, i + 1 + (TAG_SIZE[tag] || 0)];
    }
  }
  function decodeAll(a, start) {
    const out = [];
    let i = start;
    while (i < a.length) { const [v, n] = decode(a, i); out.push(v); i = n; }
    return out;
  }

  const KEYMAP = {
    Space: 'Space', Enter: 'Return', NumpadEnter: 'Return', Backspace: 'Backspace', Tab: 'Tab', Escape: 'Escape',
    ShiftLeft: 'LeftShift', ShiftRight: 'RightShift', ControlLeft: 'LeftControl', ControlRight: 'RightControl', AltLeft: 'LeftAlt', AltRight: 'RightAlt',
    ArrowUp: 'Up', ArrowDown: 'Down', ArrowLeft: 'Left', ArrowRight: 'Right', Minus: 'Minus', Equal: 'Equals', Comma: 'Comma', Period: 'Period',
    Slash: 'Slash', Semicolon: 'Semicolon', Quote: 'Quote', BracketLeft: 'LeftBracket', BracketRight: 'RightBracket', Backslash: 'BackSlash',
    Delete: 'Delete', Insert: 'Insert', Home: 'Home', End: 'End', PageUp: 'PageUp', PageDown: 'PageDown',
  };
  const DIGITS = ['Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
  function keyName(code) {
    if (/^Key[A-Z]$/.test(code)) return code.slice(3);
    if (/^Digit[0-9]$/.test(code)) return DIGITS[+code.slice(5)];
    if (/^Numpad[0-9]$/.test(code)) return DIGITS[+code.slice(6)];
    if (/^F([1-9]|1[0-2])$/.test(code)) return code;
    return KEYMAP[code] || 'Unknown';
  }
  GF.keyName = keyName;

  class Engine {
    constructor(container, opts) {
      this.container = container;
      this.opts = opts || {};
      this.settings = Object.assign({ shadows: true, quality: 'auto', showFps: false, volume: 0.8 }, this.opts.settings || {});
      this.isMobile = /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent);
      this.isTouch = window.matchMedia ? window.matchMedia('(pointer: coarse)').matches : false;
      this.audio = new GF.AudioSystem();
      this.audio.setMasterVolume(this.settings.volume);
      this.running = false;
      this.buildDom();
      this.initRenderer();
      this.gui = new GF.GuiSystem(this, this.overlay);
      this.bindInput();
      this.resize();
      this.ro = new ResizeObserver(() => this.resize());
      this.ro.observe(container);
      this.renderIdle();
    }

    // ---------------------------------------------------------------- DOM
    buildDom() {
      const c = this.container;
      c.classList.add('gf-viewport');
      c.tabIndex = 0;
      this.canvasWrap = document.createElement('div');
      this.canvasWrap.className = 'gf-canvas-wrap';
      c.appendChild(this.canvasWrap);
      this.overlay = document.createElement('div');
      this.overlay.className = 'gf-overlay';
      c.appendChild(this.overlay);
      this.touchUi = document.createElement('div');
      this.touchUi.className = 'gf-touch';
      this.touchUi.innerHTML = '<div class="gf-joy"><div class="gf-joy-knob"></div></div><button class="gf-jump" aria-label="Pular">Pular</button><button class="gf-fp" aria-label="Alternar primeira pessoa">1ª</button>';
      c.appendChild(this.touchUi);
      this.joy = this.touchUi.querySelector('.gf-joy');
      this.knob = this.touchUi.querySelector('.gf-joy-knob');
      this.jumpBtn = this.touchUi.querySelector('.gf-jump');
      this.fpBtn = this.touchUi.querySelector('.gf-fp');
      this.fpsEl = document.createElement('div');
      this.fpsEl.className = 'gf-fps';
      c.appendChild(this.fpsEl);
      this.idleEl = document.createElement('div');
      this.idleEl.className = 'gf-idle';
      this.idleEl.innerHTML = '<div><b>Janela de teste</b><span>Pressione ▶ Executar para rodar seus scripts Luau.</span></div>';
      c.appendChild(this.idleEl);
    }

    initRenderer() {
      let renderer;
      try {
        renderer = new THREE.WebGLRenderer({ antialias: !this.isMobile, powerPreference: 'high-performance' });
      } catch (e) {
        this.glError = 'WebGL indisponível neste dispositivo: ' + e.message;
        return;
      }
      renderer.useLegacyLights = true;
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      this.renderer = renderer;
      this.canvasWrap.appendChild(renderer.domElement);
      // mapa de reflexo simples (céu/chão) para materiais metálicos
      try {
        const envScene = new THREE.Scene();
        const geo = new THREE.SphereGeometry(10, 24, 12);
        const cols = [];
        const pos = geo.attributes.position;
        for (let i = 0; i < pos.count; i++) {
          const t = GF.clamp(pos.getY(i) / 10 * 0.5 + 0.5, 0, 1);
          const c = new THREE.Color(0.35, 0.33, 0.3).lerp(new THREE.Color(0.75, 0.85, 1), t);
          cols.push(c.r, c.g, c.b);
        }
        geo.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
        envScene.add(new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide })));
        const pm = new THREE.PMREMGenerator(renderer);
        GF.Materials.envMap = pm.fromScene(envScene, 0.04).texture;
        pm.dispose();
      } catch (e) { GF.Materials.envMap = null; }
      this.camera = new THREE.PerspectiveCamera(70, 1, 0.1, 5000);
      this.camera.position.set(0, 20, 30);
    }

    pixelRatio() {
      const q = this.settings.quality;
      const dpr = window.devicePixelRatio || 1;
      if (q === 'low') return Math.min(dpr, 0.75);
      if (q === 'high') return Math.min(dpr, 2);
      return Math.min(dpr, this.isMobile ? 1.25 : 1.5);
    }

    resize() {
      if (!this.renderer) return;
      const w = Math.max(1, this.container.clientWidth), h = Math.max(1, this.container.clientHeight);
      this.vw = w; this.vh = h;
      this.renderer.setPixelRatio(this.pixelRatio());
      this.renderer.setSize(w, h, false);
      this.renderer.domElement.style.width = w + 'px';
      this.renderer.domElement.style.height = h + 'px';
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      if (!this.running) this.renderIdle();
    }

    applySettings(s) {
      Object.assign(this.settings, s);
      this.audio.setMasterVolume(this.settings.volume);
      if (this.env) this.env.shadowsEnabled = this.settings.shadows;
      if (this.renderer) this.renderer.shadowMap.enabled = this.settings.shadows;
      this.fpsEl.style.display = this.settings.showFps ? '' : 'none';
      this.resize();
    }

    renderIdle() {
      if (!this.renderer) {
        this.idleEl.querySelector('span').textContent = this.glError || 'WebGL indisponível.';
        return;
      }
      this.idleEl.hidden = this.running;
      if (!this.running) {
        this.renderer.setClearColor(0x15171c, 1);
        this.renderer.clear();
      }
    }

    // ------------------------------------------------------------ ciclo de vida
    start(callbacks) {
      if (!this.renderer) throw new Error(this.glError || 'WebGL indisponível');
      this.stop(true);
      this.cb = callbacks || {};
      this.scene = new THREE.Scene();
      this.recs = new Map();
      this.characters = new Map(); // humId -> ch
      this.charByModel = new Map();
      this.charByRoot = new Map();
      this.events = [];
      this.welds = new Set();
      this.lights = new Map();
      this.decals = new Map();
      this.soundIds = new Set();
      this.promptIds = new Set();
      this.toolIds = new Set();
      this.lists = { dirty: true, stat: [], kin: [], dyn: [], meshes: [] };
      this.time = 0;
      this.frameNo = 0;
      this.physics = new GF.Physics(this);
      this.terrain = new GF.Terrain(this);
      this.particles = new GF.ParticleSystem(this.scene);
      this.env = new GF.Environment(this.scene, { shadows: this.settings.shadows, shadowMap: this.isMobile ? 1024 : 2048 });
      this.env.shadowsEnabled = this.settings.shadows;
      this.renderer.shadowMap.enabled = this.settings.shadows;
      this.ids = { workspace: null, lighting: null, weather: null, camera: null, terrain: null, players: null, soundService: null };
      this.playerGuiId = null;
      this.localPlayerId = null;
      this.backpackId = null;
      this.cam = { yaw: 0.6, pitch: 0.35, dist: 16, targetDist: 16, first: false, focus: new THREE.Vector3(0, 5, 0), shake: 0, free: new THREE.Vector3(0, 5, 0) };
      this.input = { keys: new Set(), joy: { x: 0, y: 0 }, jump: false, mouse: { x: 0, y: 0, b1: false, b2: false }, ptrs: new Map() };
      this.typing = false;
      this.camera.fov = 70;
      this.camera.updateProjectionMatrix();
      this.datastore = this.opts.datastore || { data: {}, write() {} };
      this.gui.reset();
      this.running = true;
      this.idleEl.hidden = true;
      this.touchUi.style.display = this.isTouch ? '' : 'none';
      this.fpsEl.style.display = this.settings.showFps ? '' : 'none';
      this.fps = { t: 0, n: 0 };
      this.lastT = performance.now();
      this.acc = 0;
      this.loop = this.loop || ((t) => this.frame(t));
      this.raf = requestAnimationFrame(this.loop);
      this.container.focus({ preventScroll: true });
      this.active = true;
    }

    stop(silent) {
      if (!this.running) return;
      this.running = false;
      cancelAnimationFrame(this.raf);
      if (document.pointerLockElement) document.exitPointerLock();
      this.audio.stopAll();
      try {
        this.particles.disposeAll();
        this.terrain.dispose();
        this.env.dispose();
        for (const ch of this.characters.values()) ch.rig.dispose();
        this.scene.traverse((o) => {
          if (o.geometry) o.geometry.dispose();
          if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach((m) => { if (m.map && m.map.userData && m.map.userData.own) m.map.dispose(); m.dispose(); });
        });
        this.renderer.renderLists.dispose();
      } catch (e) { /* limpeza */ }
      this.scene = null;
      this.recs = new Map();
      this.characters = new Map();
      this.gui.reset();
      this.touchUi.style.display = 'none';
      this.fpsEl.style.display = 'none';
      if (!silent) this.renderIdle();
    }

    warn(msg) { if (this.cb && this.cb.output) this.cb.output('warn', msg); }

    queueEvent(kind, a, b, c, d, e, f) {
      if (!this.running) return;
      if (this.events.length > 5000) this.events.shift();
      this.events.push([kind, a, b, c, d, e, f]);
    }

    // ------------------------------------------------------------ consultas
    gravity() { const w = this.recs.get(this.ids.workspace); return w && w.props.Gravity != null ? w.props.Gravity : 196.2; }
    fallenHeight() { const w = this.recs.get(this.ids.workspace); return w && w.props.FallenPartsDestroyHeight != null ? w.props.FallenPartsDestroyHeight : -500; }
    terrainHeight(x, z) { return this.terrain.heightAt(x, z); }
    terrainProps() { const t = this.recs.get(this.ids.terrain); return t ? t.props : {}; }

    rebuildLists() {
      const L = this.lists;
      L.stat = []; L.kin = []; L.dyn = []; L.meshes = [];
      for (const rec of this.recs.values()) {
        const b = rec.part;
        if (!b) continue;
        if (rec.inWorld && b.mesh) L.meshes.push(b.mesh);
        if (!rec.inWorld || b.characterOwned || b.toolHeld) continue;
        if (b.welded) { L.kin.push(b); b.dynamic = false; continue; }
        if (b.anchored) { if (b.kinematic) L.kin.push(b); else L.stat.push(...this.colliders(b)); }
        else L.dyn.push(b);
        b.dynamic = !b.anchored;
        b.kinematicBody = b.anchored && b.kinematic;
      }
      for (const p of this.terrain.pieces) L.stat.push(p);
      for (const ch of this.characters.values()) if (!ch.dead) for (const m of ch.rig.meshes) L.meshes.push(m);
      for (const m of this.terrain.group.children) if (m.isMesh) L.meshes.push(m);
      L.dirty = false;
    }
    colliders(b) {
      if (b.shape !== 'Wedge') return [b];
      if (!b.slabs) {
        b.slabs = GF.wedgeSlabs(b.pos, b.quat, b.size).map((s) => {
          const o = { id: b.id, rec: b.rec, pos: s.pos, quat: b.quat, size: s.size, half: new THREE.Vector3(), radius: 0, shape: 'Block', canCollide: b.canCollide, canTouch: b.canTouch, friction: b.friction, elasticity: b.elasticity, vel: b.vel, material: b.material };
          GF.Physics.updateHalf(o);
          return o;
        });
      }
      return b.slabs;
    }
    staticBodies() { if (this.lists.dirty) this.rebuildLists(); return this.lists.stat; }
    kinematicBodies() { if (this.lists.dirty) this.rebuildLists(); return this.lists.kin; }
    dynamicBodies() { if (this.lists.dirty) this.rebuildLists(); return this.lists.dyn; }
    worldChanged() { this.lists.dirty = true; this.physics.markDirty(); }

    localCharacter() {
      let best = null;
      for (const ch of this.characters.values()) if (ch.isPlayer && (!best || ch.modelId > best.modelId)) best = ch;
      return best;
    }
    localPlayerName() { const p = this.recs.get(this.localPlayerId); return p ? String(p.props.Name || 'Jogador') : 'Jogador'; }
    childByName(rec, name) {
      if (!rec) return null;
      for (const c of rec.children) { const r = this.recs.get(c); if (r && r.props.Name === name) return r; }
      return null;
    }
    leaderstats() {
      const ls = this.childByName(this.recs.get(this.localPlayerId), 'leaderstats');
      if (!ls) return null;
      const out = [];
      for (const c of ls.children) {
        const r = this.recs.get(c);
        if (r && VALUE_CLASSES.has(r.cls)) {
          let v = r.props.Value;
          if (typeof v === 'number') v = Number.isInteger(v) ? String(v) : v.toFixed(1);
          out.push({ name: String(r.props.Name), value: String(v == null ? '' : v) });
        }
      }
      return out;
    }
    toolList() {
      const out = [];
      const bp = this.recs.get(this.backpackId);
      const ch = this.localCharacter();
      const model = ch && this.recs.get(ch.modelId);
      const add = (rec, equipped) => { for (const c of rec.children) { const r = this.recs.get(c); if (r && r.cls === 'Tool') out.push({ id: r.id, name: String(r.props.Name), icon: r.props.TextureId || '', equipped }); } };
      if (bp) add(bp, false);
      if (model) add(model, true);
      out.sort((a, b) => a.id - b.id);
      return out;
    }
    modelCenter(rec) {
      if (rec.props.PrimaryPart != null) { const p = this.recs.get(rec.props.PrimaryPart); if (p && p.part) return p.part.pos; }
      const stack = [...rec.children];
      while (stack.length) { const r = this.recs.get(stack.shift()); if (!r) continue; if (r.part) return r.part.pos; stack.push(...r.children); }
      return null;
    }
    isDescendantOfWorld(rec) { return !!rec.inWorld; }

    project(pos) {
      const v = pos.clone().project(this.camera);
      const behind = v.z > 1 || v.z < -1;
      return { x: (v.x * 0.5 + 0.5) * this.vw, y: (-v.y * 0.5 + 0.5) * this.vh, z: v.z, visible: !behind && Math.abs(v.x) < 1.3 && Math.abs(v.y) < 1.3 };
    }
    pixelsPerStud(wp) {
      const d = Math.max(0.1, this.camera.position.distanceTo(wp));
      return this.vh / (2 * d * Math.tan(THREE.MathUtils.degToRad(this.camera.fov) / 2));
    }

    // ------------------------------------------------------------ instâncias
    newRec(id, cls) {
      const rec = { id, cls, props: {}, parent: null, children: [], inWorld: false };
      this.recs.set(id, rec);
      switch (cls) {
        case 'Workspace': this.ids.workspace = id; rec.inWorld = true; break;
        case 'Lighting': this.ids.lighting = id; break;
        case 'Weather': this.ids.weather = id; break;
        case 'Camera': if (this.ids.camera == null) this.ids.camera = id; break;
        case 'Terrain': this.ids.terrain = id; this.terrain.terrainId = id; break;
        case 'Players': this.ids.players = id; break;
        case 'SoundService': this.ids.soundService = id; break;
        case 'PlayerGui': if (this.playerGuiId == null) this.playerGuiId = id; break;
        case 'Backpack': if (this.backpackId == null) this.backpackId = id; break;
        case 'Sound': this.soundIds.add(id); break;
        case 'ProximityPrompt': this.promptIds.add(id); break;
        case 'WeldConstraint': this.welds.add(rec); break;
        case 'Tool': this.toolIds.add(id); break;
        default: break;
      }
      if (PART_CLASSES.has(cls)) {
        rec.part = {
          id, rec, pos: new THREE.Vector3(0, 0.5, 0), quat: new THREE.Quaternion(), size: new THREE.Vector3(4, 1, 2), half: new THREE.Vector3(2, 0.5, 1),
          radius: 0, shape: cls === 'WedgePart' ? 'Wedge' : 'Block', anchored: false, canCollide: true, canTouch: true, friction: 0.6, elasticity: 0.2,
          vel: new THREE.Vector3(), prevPos: new THREE.Vector3(0, 0.5, 0), delta: null, material: 'Plastic', mesh: null, geoDirty: true, matDirty: true,
        };
      }
      this.gui.onNew(rec);
      return rec;
    }

    ensureMesh(rec) {
      const b = rec.part;
      if (!b.mesh) {
        const mat = new THREE.MeshStandardMaterial({ color: 0xa3a2a5 });
        b.mesh = new THREE.Mesh(new THREE.BufferGeometry(), mat);
        b.mesh.userData.partId = rec.id;
        b.mesh.receiveShadow = true;
        b.mesh.matrixAutoUpdate = true;
      }
      if (b.geoDirty) this.buildGeometry(rec);
      if (b.matDirty) this.updateMaterial(rec);
      return b.mesh;
    }

    buildGeometry(rec) {
      const b = rec.part;
      b.geoDirty = false;
      const s = b.size;
      const ts = Math.max(0.1, rec.props.TextureScale || 4);
      let geo;
      if (b.shape === 'Ball') {
        const r = Math.min(s.x, s.y, s.z) / 2;
        geo = new THREE.SphereGeometry(r, 28, 18);
        const uv = geo.attributes.uv;
        for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * (Math.PI * 2 * r) / ts, uv.getY(i) * (Math.PI * r) / ts);
      } else if (b.shape === 'Cylinder') {
        const r = Math.min(s.y, s.z) / 2;
        geo = new THREE.CylinderGeometry(r, r, s.x, 28);
        const uv = geo.attributes.uv;
        for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * (Math.PI * 2 * r) / ts, uv.getY(i) * s.x / ts);
        geo.rotateZ(Math.PI / 2);
      } else if (b.shape === 'Wedge') {
        geo = GF.wedgeGeometry(s.x, s.y, s.z);
        GF.Terrain.prototype.uv.call(null, geo, ts);
      } else {
        geo = new THREE.BoxGeometry(s.x, s.y, s.z);
        const uv = geo.attributes.uv;
        const dims = [[s.z, s.y], [s.z, s.y], [s.x, s.z], [s.x, s.z], [s.x, s.y], [s.x, s.y]];
        for (let f = 0; f < 6; f++) for (let k = 0; k < 4; k++) { const i = f * 4 + k; uv.setXY(i, uv.getX(i) * dims[f][0] / ts, uv.getY(i) * dims[f][1] / ts); }
      }
      if (b.mesh.geometry) b.mesh.geometry.dispose();
      b.mesh.geometry = geo;
      b.slabs = null;
      GF.Physics.updateHalf(b);
      if (b.shape !== 'Ball') b.radius = 0;
    }

    updateMaterial(rec) {
      const b = rec.part, p = rec.props;
      b.matDirty = false;
      GF.Materials.applyMaterial(b.mesh.material, { material: p.Material || 'Plastic', color: p.Color || { r: 0.64, g: 0.64, b: 0.65 }, transparency: p.Transparency || 0, reflectance: p.Reflectance || 0 });
      b.mesh.castShadow = p.CastShadow !== false && (p.Transparency || 0) < 0.9;
    }

    syncMesh(rec) {
      const b = rec.part;
      if (!b.mesh) return;
      b.mesh.position.copy(b.pos);
      b.mesh.quaternion.copy(b.quat);
    }

    setInWorld(rec, inW) {
      const was = rec.inWorld;
      if (rec.cls === 'Workspace') inW = true;
      rec.inWorld = inW;
      if (was !== inW) this.onWorldChange(rec, inW);
      for (const c of rec.children) { const r = this.recs.get(c); if (r) this.setInWorld(r, inW); }
    }

    onWorldChange(rec, inW) {
      if (rec.part) {
        if (inW) { const m = this.ensureMesh(rec); this.syncMesh(rec); this.scene.add(m); rec.part.prevPos.copy(rec.part.pos); }
        else if (rec.part.mesh) this.scene.remove(rec.part.mesh);
        this.worldChanged();
      }
      if (PARTICLE_CLASSES.has(rec.cls)) { if (inW) this.particles.attach(rec); else this.particles.detach(rec.id); }
      if (LIGHT_CLASSES.has(rec.cls)) this.updateLight(rec);
      if (rec.cls === 'Decal' || rec.cls === 'Texture') this.updateDecal(rec);
      if (rec.cls === 'Sound' && !inW) { /* som continua tocando se fora do mundo? como no Roblox, só sons no mundo são posicionais */ }
      const ch = this.charByModel.get(rec.id);
      if (ch) ch.rig.group.visible = inW && !ch.dead;
    }

    setParent(id, pid) {
      const rec = this.recs.get(id);
      if (!rec) return;
      rec._oldParent = rec.parent;
      if (rec.parent != null) {
        const old = this.recs.get(rec.parent);
        if (old) { const i = old.children.indexOf(id); if (i >= 0) old.children.splice(i, 1); }
      }
      rec.parent = pid;
      const np = pid != null ? this.recs.get(pid) : null;
      if (np) np.children.push(id);
      const inW = rec.cls === 'Workspace' || !!(np && np.inWorld);
      this.setInWorld(rec, inW);
      if (rec.part) { this.worldChanged(); }
      if (LIGHT_CLASSES.has(rec.cls)) this.updateLight(rec);
      if (rec.cls === 'Decal' || rec.cls === 'Texture') this.updateDecal(rec);
      if (rec.cls === 'Tool' || (rec.part && rec.props.Name === 'Handle')) this.worldChanged();
      if (rec.cls === 'Sound' && np) { const st = this.audio.sounds.get(id); if (st) st.getPos = this.soundPosFn(rec); }
      this.gui.onParent(rec);
    }

    destroyRec(id) {
      const rec = this.recs.get(id);
      if (!rec) return;
      for (const c of [...rec.children]) this.destroyRec(c);
      if (rec.parent != null) { const p = this.recs.get(rec.parent); if (p) { const i = p.children.indexOf(id); if (i >= 0) p.children.splice(i, 1); } }
      if (rec.part) {
        if (rec.part.mesh) { this.scene.remove(rec.part.mesh); rec.part.mesh.geometry.dispose(); rec.part.mesh.material.dispose(); }
        this.worldChanged();
      }
      if (PARTICLE_CLASSES.has(rec.cls)) this.particles.detach(id);
      if (LIGHT_CLASSES.has(rec.cls)) { const l = this.lights.get(id); if (l) { l.removeFromParent(); this.lights.delete(id); } }
      if (rec.cls === 'Decal' || rec.cls === 'Texture') { const d = this.decals.get(id); if (d) { d.removeFromParent(); d.geometry.dispose(); this.decals.delete(id); } }
      if (rec.cls === 'Sound') {
        if (rec.props.PlayOnRemove && rec.props.SoundId) this.audio.oneShot(rec.props.SoundId, rec.props.Volume, this.soundPosFn(rec) && this.soundPosFn(rec)());
        this.audio.stop(id); this.soundIds.delete(id);
      }
      if (rec.cls === 'WeldConstraint') { this.welds.delete(rec); this.unweld(rec); }
      this.promptIds.delete(id); this.toolIds.delete(id);
      const ch = this.charByModel.get(id) || this.characters.get(id);
      if (ch) this.removeCharacter(ch);
      this.gui.onDestroy(rec);
      this.recs.delete(id);
    }

    unweld(w) {
      const p1 = this.recs.get(w.props.Part1);
      if (p1 && p1.part && p1.part.welded === w) { p1.part.welded = null; this.worldChanged(); }
    }

    // ------------------------------------------------------------ propriedades
    setProp(id, key, val) {
      const rec = this.recs.get(id);
      if (!rec) return;
      rec.props[key] = val;
      const b = rec.part;
      if (b) return this.setPartProp(rec, b, key, val);
      const cls = rec.cls;
      if (cls === 'Humanoid') {
        const ch = this.characters.get(id);
        if (ch) {
          if (key === 'BodyColor' || key === 'ShirtColor' || key === 'PantsColor') ch.rig.setColors(rec.props.BodyColor, rec.props.ShirtColor, rec.props.PantsColor);
          if (key === 'Sit' && !val && ch.sitting) this.setHumanoidSit(ch, false);
        }
        return;
      }
      if (LIGHT_CLASSES.has(cls)) return this.updateLight(rec);
      if (cls === 'Decal' || cls === 'Texture') return this.updateDecal(rec);
      if (cls === 'Sound') return this.audio.update(id, this.soundProps(rec));
      if (cls === 'SoundService') { for (const sid of this.soundIds) { const r = this.recs.get(sid); if (r) this.audio.update(sid, this.soundProps(r)); } return; }
      if (cls === 'Camera') {
        if (key === 'FieldOfView') { this.camera.fov = GF.clamp(val || 70, 1, 120); this.camera.updateProjectionMatrix(); }
        return;
      }
      if (cls === 'WeldConstraint') { this.unweld(rec); rec.offset = null; return; }
      if (cls === 'Model' && key === 'PrimaryPart') return;
      if (cls === 'Player' && id === this.localPlayerId && key === 'CameraMode') { this.cam.first = val === 'LockFirstPerson'; return; }
      if (cls === 'Tool' && key === 'TextureId') return;
      this.gui.onSet(rec, key);
    }

    setPartProp(rec, b, key, val) {
      switch (key) {
        case 'CFrame': {
          const ch = this.charByRoot.get(rec.id);
          b.pos.set(val[0], val[1], val[2]);
          b.quat.copy(GF.quatFromCF(val));
          if (ch) {
            ch.feet.set(val[0], val[1] - 3, val[2]);
            ch.vel.set(0, 0, 0); ch.knock.set(0, 0, 0);
            const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(b.quat);
            if (Math.abs(fwd.y) < 0.99) ch.yaw = Math.atan2(-fwd.x, -fwd.z);
            ch.fellQueued = false;
            return;
          }
          if (b.characterOwned || b.toolHeld) return;
          GF.Physics.updateHalf(b);
          if (b.shape !== 'Ball') b.radius = 0;
          b.slabs = null;
          b.fellQueued = false;
          if (b.anchored && rec.inWorld && this.frameNo > 1) {
            b.kinematicUntil = this.time + 1.5;
            if (!b.kinematic) { b.kinematic = true; this.worldChanged(); }
          } else if (b.anchored && rec.inWorld) this.worldChanged();
          for (const w of this.welds) if (w.props.Part1 === rec.id) w.offset = null;
          this.syncMesh(rec);
          return;
        }
        case 'Size': b.size.copy(val); b.geoDirty = true; if (b.mesh) this.buildGeometry(rec); else GF.Physics.updateHalf(b); if (b.anchored && rec.inWorld) this.worldChanged(); for (const w of this.welds) if (w.props.Part1 === rec.id || w.props.Part0 === rec.id) w.offset = null; this.refreshAttachments(rec); return;
        case 'Shape': b.shape = val === 'Wedge' ? 'Wedge' : val === 'Ball' ? 'Ball' : val === 'Cylinder' ? 'Cylinder' : 'Block'; b.geoDirty = true; if (b.mesh) this.buildGeometry(rec); else GF.Physics.updateHalf(b); if (rec.inWorld) this.worldChanged(); return;
        case 'TextureScale': b.geoDirty = true; if (b.mesh) this.buildGeometry(rec); return;
        case 'Anchored': b.anchored = !!val; b.kinematic = false; if (!b.anchored) b.vel.set(0, 0, 0); this.worldChanged(); return;
        case 'CanCollide': b.canCollide = !!val; if (b.slabs) b.slabs.forEach((s) => (s.canCollide = !!val)); this.physics.markDirty(); return;
        case 'CanTouch': b.canTouch = !!val; if (b.slabs) b.slabs.forEach((s) => (s.canTouch = !!val)); return;
        case 'Friction': b.friction = val; return;
        case 'Elasticity': b.elasticity = val; return;
        case 'Velocity': {
          const ch = this.charByRoot.get(rec.id);
          if (ch) { ch.knock.set(val.x, 0, val.z); ch.vel.y = val.y; if (val.y > 0) ch.onGround = false; return; }
          b.vel.copy(val); return;
        }
        case 'Material': b.material = val; b.matDirty = true; if (b.mesh) this.updateMaterial(rec); return;
        case 'Color': case 'Transparency': case 'Reflectance': case 'CastShadow':
          b.matDirty = true; if (b.mesh) this.updateMaterial(rec); return;
        case 'Name': return;
        default: return;
      }
    }

    refreshAttachments(rec) {
      for (const c of rec.children) {
        const r = this.recs.get(c);
        if (!r) continue;
        if (r.cls === 'Decal' || r.cls === 'Texture') this.updateDecal(r);
        if (LIGHT_CLASSES.has(r.cls)) this.updateLight(r);
      }
    }

    // luzes presas a peças
    updateLight(rec) {
      const p = rec.props;
      const parent = this.recs.get(rec.parent);
      let l = this.lights.get(rec.id);
      const want = parent && parent.part && rec.inWorld && p.Enabled !== false;
      if (!want) { if (l) { l.removeFromParent(); this.lights.delete(rec.id); } return; }
      const mesh = this.ensureMesh(parent);
      if (!l) {
        if (rec.cls === 'PointLight') l = new THREE.PointLight(0xffffff, 1, 8, 1.5);
        else { l = new THREE.SpotLight(0xffffff, 1, 16, Math.PI / 4, 0.4, 1.5); l.add(l.target); }
        this.lights.set(rec.id, l);
      }
      if (l.parent !== mesh) mesh.add(l);
      const c = p.Color || { r: 1, g: 1, b: 1 };
      l.color.setRGB(c.r, c.g, c.b);
      l.intensity = Math.max(0, p.Brightness == null ? 1 : p.Brightness);
      l.distance = Math.max(0.5, p.Range == null ? 8 : p.Range) * 1.5;
      const allowShadow = p.Shadows && this.settings.shadows && !this.isMobile;
      l.castShadow = !!allowShadow;
      if (l.isSpotLight) {
        const ang = THREE.MathUtils.degToRad(GF.clamp(p.Angle == null ? 90 : p.Angle, 1, 180));
        l.angle = Math.min(Math.PI / 2 - 0.01, ang / 2);
        const f = FACE[p.Face || 'Front'] || FACE.Front;
        const half = parent.part.size;
        l.position.set(f[0] * half.x / 2, f[1] * half.y / 2, f[2] * half.z / 2);
        l.target.position.set(f[0] * 10, f[1] * 10, f[2] * 10);
        if (rec.cls === 'SurfaceLight') l.penumbra = 0.9;
      }
    }

    // decalques nas faces
    updateDecal(rec) {
      const p = rec.props;
      const parent = this.recs.get(rec.parent);
      let d = this.decals.get(rec.id);
      if (!(parent && parent.part && rec.inWorld)) { if (d) { d.removeFromParent(); } return; }
      const mesh = this.ensureMesh(parent);
      const s = parent.part.size;
      const face = p.Face || 'Front';
      const f = FACE[face] || FACE.Front;
      let w, h;
      if (f[0]) { w = s.z; h = s.y; } else if (f[1]) { w = s.x; h = s.z; } else { w = s.x; h = s.y; }
      if (!d) {
        d = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshStandardMaterial({ transparent: true, roughness: 0.8, polygonOffset: true, polygonOffsetFactor: -2 }));
        d.userData.partId = parent.id;
        this.decals.set(rec.id, d);
      }
      if (d.parent !== mesh) mesh.add(d);
      d.scale.set(w, h, 1);
      const n = new THREE.Vector3(f[0], f[1], f[2]);
      d.position.set(f[0] * (s.x / 2 + 0.01), f[1] * (s.y / 2 + 0.01), f[2] * (s.z / 2 + 0.01));
      d.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), n);
      const c = p.Color3 || { r: 1, g: 1, b: 1 };
      d.material.color.setRGB(c.r, c.g, c.b);
      d.material.opacity = 1 - (p.Transparency || 0);
      const url = GF.resolveImage(p.Texture || '', (m) => this.gui.warnOnce(m));
      if (url !== d.userData.url) {
        d.userData.url = url;
        if (d.material.map) d.material.map.dispose();
        d.material.map = null;
        if (url) {
          if (/^https?:/.test(url)) this.gui.warnOnce('Texturas por endereço http(s) dependem de conexão com a internet.');
          const loader = new THREE.TextureLoader();
          loader.setCrossOrigin('anonymous');
          const tex = loader.load(url, () => { d.material.needsUpdate = true; }, undefined, () => this.warn('Não foi possível carregar a textura: ' + p.Texture));
          tex.colorSpace = THREE.SRGBColorSpace;
          tex.userData.own = true;
          d.material.map = tex;
        }
        d.material.needsUpdate = true;
      }
      if (d.material.map && rec.cls === 'Texture') {
        d.material.map.wrapS = d.material.map.wrapT = THREE.RepeatWrapping;
        d.material.map.repeat.set(w / (p.StudsPerTileU || 2), h / (p.StudsPerTileV || 2));
      }
      d.visible = !!url && (p.Transparency || 0) < 1;
    }

    soundProps(rec) {
      const ss = this.recs.get(this.ids.soundService);
      return Object.assign({}, rec.props, { _serviceVolume: ss && ss.props.Volume != null ? ss.props.Volume : 1 });
    }
    soundPosFn(rec) {
      const parent = this.recs.get(rec.parent);
      if (!parent) return null;
      if (parent.part) return () => parent.part.pos;
      if (parent.cls === 'Model') return () => this.modelCenter(parent);
      return null;
    }

    // ------------------------------------------------------------ personagens
    registerCharacter(modelId, humId, rootId, headId, isPlayer) {
      const root = this.recs.get(rootId), head = this.recs.get(headId), hum = this.recs.get(humId), model = this.recs.get(modelId);
      if (!root || !hum || !model) return;
      root.part.characterOwned = true;
      if (head && head.part) head.part.characterOwned = true;
      const rig = new GF.CharacterRig(this.scene, { label: isPlayer ? null : String(model.props.Name || 'NPC') });
      rig.setColors(hum.props.BodyColor, hum.props.ShirtColor, hum.props.PantsColor);
      for (const m of rig.meshes) m.userData.partId = m === rig.head ? headId : rootId;
      const ch = {
        modelId, humId, rootId, headId, isPlayer, hum, rig, feet: root.part.pos.clone().sub(new THREE.Vector3(0, 3, 0)),
        vel: new THREE.Vector3(), knock: new THREE.Vector3(), yaw: 0, moveDir: new THREE.Vector3(), scriptMove: new THREE.Vector3(), moveDirWorld: new THREE.Vector3(),
        moveTarget: null, moveTime: 0, jumpRequest: false, onGround: false, dead: false, moving: 0, lastRun: -1, sitting: null, seatCooldown: 0, ground: null,
      };
      this.characters.set(humId, ch);
      this.charByModel.set(modelId, ch);
      this.charByRoot.set(rootId, ch);
      rig.group.visible = model.inWorld;
      this.worldChanged();
      if (isPlayer) { this.cam.yaw = 0; this.cam.pitch = 0.3; }
    }

    removeCharacter(ch) {
      ch.rig.dispose();
      this.characters.delete(ch.humId);
      this.charByModel.delete(ch.modelId);
      this.charByRoot.delete(ch.rootId);
      this.worldChanged();
    }

    setHumanoidSit(ch, on, seat) {
      if (on) {
        ch.sitting = seat; ch.rig.play('__sit', 'Sit', true, 1); ch.hum.props.Sit = true;
      } else {
        ch.sitting = null; ch.rig.stop('__sit'); ch.hum.props.Sit = false; ch.seatCooldown = 1;
      }
    }

    updateCharacters(dt) {
      for (const ch of this.characters.values()) {
        const model = this.recs.get(ch.modelId);
        const root = this.recs.get(ch.rootId), head = this.recs.get(ch.headId);
        if (!model || !root) continue;
        if (!ch.dead && ch.ground && ch.ground.rec && ch.ground.rec.cls === 'Seat' && !ch.sitting && ch.seatCooldown <= 0 && !ch.ground.rec.props.Disabled) this.setHumanoidSit(ch, true, ch.ground.rec);
        ch.seatCooldown -= dt;
        // peças controladas pelo motor
        root.part.pos.set(ch.feet.x, ch.feet.y + 3, ch.feet.z);
        root.part.quat.setFromAxisAngle(new THREE.Vector3(0, 1, 0), ch.yaw);
        root.part.vel.copy(ch.vel);
        GF.Physics.updateHalf(root.part);
        if (head && head.part) { head.part.pos.set(ch.feet.x, ch.feet.y + 4.6, ch.feet.z); head.part.quat.copy(root.part.quat); }
        const g = ch.rig.group;
        g.position.copy(ch.feet);
        g.rotation.y = ch.yaw;
        const hs = Math.hypot(ch.vel.x, ch.vel.z);
        ch.rig.groundY = ch.feet.y;
        ch.rig.animate(dt, { speed: ch.onGround ? hs : 0, walkSpeed: ch.hum.props.WalkSpeed || 16, onGround: ch.onGround || !!ch.sitting, vy: ch.vel.y, sitting: !!ch.sitting }, (trackId) => this.queueEvent('animended', trackId));
        // ferramenta na mão
        let holding = false;
        for (const cid of model.children) {
          const t = this.recs.get(cid);
          if (!t || t.cls !== 'Tool') continue;
          const handle = this.childByName(t, 'Handle');
          if (handle && handle.part) {
            holding = true;
            if (!handle.part.toolHeld) { handle.part.toolHeld = true; this.worldChanged(); }
            ch.rig.group.updateMatrixWorld(true);
            const hp = new THREE.Vector3(), hq = new THREE.Quaternion();
            ch.rig.hand.getWorldPosition(hp); ch.rig.hand.getWorldQuaternion(hq);
            hq.multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), Math.PI / 2));
            handle.part.pos.copy(hp); handle.part.quat.copy(hq);
            this.syncMesh(handle);
          }
        }
        if (holding && !ch.dead && !ch.sitting) ch.rig.rArm.pivot.rotation.x = Math.PI / 2;
        const label = !ch.isPlayer ? String(ch.hum.props.DisplayName || model.props.Name || '') : '';
        if (!ch.isPlayer) ch.rig.setLabel(label, (ch.hum.props.Health || 0) / (ch.hum.props.MaxHealth || 100));
        if (!ch.dead) {
          const sp = Math.round(hs * 2) / 2;
          if ((sp > 0.1) !== (ch.lastRun > 0.1) || Math.abs(sp - ch.lastRun) > 2) { ch.lastRun = sp; this.queueEvent('running', ch.humId, sp); }
        }
        g.visible = model.inWorld && !ch.dead && !(ch.isPlayer && this.cam.isFirst);
      }
      // ferramentas soltas voltam a ter física
      for (const tid of this.toolIds) {
        const t = this.recs.get(tid);
        if (!t) continue;
        const handle = this.childByName(t, 'Handle');
        if (handle && handle.part && handle.part.toolHeld && !this.charByModel.has(t.parent)) { handle.part.toolHeld = false; this.worldChanged(); }
      }
    }

    // ------------------------------------------------------------ chamadas
    call(id, method, args) {
      const rec = this.recs.get(id);
      const ch = this.characters.get(id);
      switch (method) {
        case 'ApplyImpulse': {
          if (!rec || !rec.part) return [];
          const v = args[0];
          const cc = this.charByRoot.get(id);
          if (cc) { cc.knock.x += v.x / 10; cc.knock.z += v.z / 10; cc.vel.y += v.y / 10; if (v.y > 0) cc.onGround = false; return []; }
          const s = rec.part.size;
          const mass = Math.max(0.1, s.x * s.y * s.z * (rec.props.Density || 1) * 0.7);
          rec.part.vel.addScaledVector(v, 1 / mass);
          return [];
        }
        case 'GetTouchingParts': return this.physics.touchingOf(id).filter((x) => typeof x === 'number');
        case 'Emit': {
          if (!rec) return [];
          const info = this.partInfo(rec.parent);
          this.particles.emit(rec, Math.min(1000, args[0] || 10), info);
          return [];
        }
        case 'Clear':
          if (rec && rec.cls === 'Terrain') { this.terrain.clear(); this.worldChanged(); return []; }
          this.particles.clear(id); return [];
        case 'Explode': {
          if (!rec) return [];
          const p = rec.props.Position || new THREE.Vector3();
          const r = rec.props.BlastRadius || 4;
          if (rec.props.Visible !== false) {
            this.particles.burst(p.clone(), { count: 70, speedMin: r * 2, speedMax: r * 6, size0: r * 0.8, size1: r * 2, c0: { r: 1, g: 0.75, b: 0.3 }, c1: { r: 0.25, g: 0.22, b: 0.2 }, lifeMax: 1.3 });
            this.particles.burst(p.clone(), { count: 40, speedMin: r * 4, speedMax: r * 10, size0: 0.6, size1: 0.1, texture: 'spark', additive: true, c0: { r: 1, g: 0.9, b: 0.5 }, c1: { r: 1, g: 0.3, b: 0.1 }, lifeMax: 0.8, acc: { x: 0, y: -40, z: 0 } });
            const flash = new THREE.PointLight(0xffaa55, 6, r * 8);
            flash.position.copy(p);
            this.scene.add(flash);
            const t0 = this.time;
            flash.userData.update = () => { const k = 1 - (this.time - t0) / 0.4; flash.intensity = Math.max(0, 6 * k); if (k <= 0) { this.scene.remove(flash); return false; } return true; };
            (this.tempObjs = this.tempObjs || []).push(flash);
          }
          this.audio.oneShot('sfx:explosion', 0.7, p);
          const d = this.camera.position.distanceTo(p);
          this.cam.shake = Math.max(this.cam.shake, GF.clamp(1.5 - d / 80, 0, 1.2));
          return [];
        }
        case 'Play': if (rec) this.audio.play(id, this.soundProps(rec), this.soundPosFn(rec), () => this.queueEvent('soundended', id), (m) => this.warn('Som "' + rec.props.SoundId + '": ' + m)); return [];
        case 'Stop': this.audio.stop(id); if (rec) rec._offset = 0; return [];
        case 'Pause': if (rec) rec.props._offset = this.audio.pause(id); return [];
        case 'Resume': if (rec) this.audio.play(id, this.soundProps(rec), this.soundPosFn(rec), () => this.queueEvent('soundended', id)); if (rec) rec.props._offset = 0; return [];
        case 'TimeLength': {
          if (!rec) return [0];
          const sid = rec.props.SoundId || '';
          if (GF.BUILTIN_SOUNDS.includes(sid) && !this.audio.buffers[sid] && this.audio.ensure()) this.audio.buffers[sid] = this.audio.synth(sid);
          return [this.audio.length(sid)];
        }
        case 'PlayAnimation': if (ch) ch.rig.play(args[1], args[0], !!args[2], args[3] || 1); return [];
        case 'StopAnimation': if (ch) ch.rig.stop(args[0]); return [];
        case 'AnimationSpeed': if (ch) ch.rig.speed(args[0], args[1]); return [];
        case 'AnimationLength': return [GF.ANIMS[args[0]] == null ? null : GF.ANIMS[args[0]]];
        case 'Die': if (ch && !ch.dead) { ch.dead = true; if (ch.sitting) this.setHumanoidSit(ch, false); ch.rig.die(ch.vel.clone().multiplyScalar(0.3)); if (ch.isPlayer) this.audio.oneShot('sfx:hurt', 0.5); this.worldChanged(); } return [];
        case 'Jump': if (ch && !ch.dead) ch.jumpRequest = true; return [];
        case 'MoveTo': if (ch && !ch.dead) { ch.moveTarget = args[0].clone(); ch.moveTime = 0; } return [];
        case 'Move': if (ch) { const v = args[0]; ch.scriptMove.set(v.x, 0, v.z); if (ch.scriptMove.lengthSq() > 1) ch.scriptMove.normalize(); } return [];
        case 'MoveDirection': return ch ? [ch.moveDirWorld.x, 0, ch.moveDirWorld.z] : [0, 0, 0];
        case 'FloorMaterial': {
          if (!ch || !ch.onGround) return ['Air'];
          if (ch.ground === 'terrain') return [this.terrain.hm ? this.terrain.hm.material : 'Grass'];
          return [ch.ground && ch.ground.material ? ch.ground.material : 'Plastic'];
        }
        case 'GetCFrame': return GF.cfFrom(this.camera.position, this.camera.quaternion);
        case 'ViewportSize': return [this.vw, this.vh];
        case 'ScreenPointToRay': {
          const r = this.rayFromScreen(args[0], args[1]);
          return [r.origin.x, r.origin.y, r.origin.z, r.direction.x, r.direction.y, r.direction.z];
        }
        case 'WorldToScreenPoint': {
          const p = args[0];
          const sp = this.project(p);
          const depth = p.clone().sub(this.camera.position).dot(new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion));
          return [sp.x, sp.y, depth, depth > 0 && sp.x >= 0 && sp.y >= 0 && sp.x <= this.vw && sp.y <= this.vh];
        }
        case 'FillBlock': this.terrain.fillBlock(args[0], args[1], args[2]); this.worldChanged(); return [];
        case 'FillBall': this.terrain.fillBall(args[0], args[1], args[2]); this.worldChanged(); return [];
        case 'FillCylinder': this.terrain.fillCylinder(args[0], args[1], args[2], args[3]); this.worldChanged(); return [];
        case 'FillWedge': this.terrain.fillWedge(args[0], args[1], args[2]); this.worldChanged(); return [];
        case 'GenerateHills': this.terrain.generateHills(args[0], args[1], args[2], args[3], args[4], args[5], args[6]); this.worldChanged(); return [];
        case 'HeightAt': return [this.terrain.heightAt(args[0], args[1])];
        case 'Strike': this.env.strike(this.audio, this.cam.focus); return [];
        case 'AbsoluteSize': case 'AbsolutePosition': case 'Focus': case 'Blur':
          return rec ? this.gui.call(rec, method) : [0, 0];
        default:
          throw new Error('Método do motor não implementado: ' + method);
      }
    }

    partInfo(id) {
      const rec = this.recs.get(id);
      if (!rec) return null;
      if (rec.part) {
        if (!rec.inWorld) return null;
        return { pos: rec.part.pos, quat: rec.part.quat, half: rec.part.size.clone().multiplyScalar(0.5) };
      }
      if (rec.cls === 'Model') {
        const c = this.modelCenter(rec);
        return c ? { pos: c, quat: new THREE.Quaternion(), half: new THREE.Vector3(1, 1, 1) } : null;
      }
      return null;
    }

    // ------------------------------------------------------------ raios
    rayFromScreen(x, y) {
      const ndc = new THREE.Vector2((x / this.vw) * 2 - 1, -(y / this.vh) * 2 + 1);
      const rc = new THREE.Raycaster();
      rc.setFromCamera(ndc, this.camera);
      return rc.ray;
    }

    raycast(origin, dir, filterIds, mode) {
      if (this.lists.dirty) this.rebuildLists();
      if (this.matrixStale !== false) { this.scene.updateMatrixWorld(); this.matrixStale = false; }
      const len = dir.length();
      if (len < 1e-6) return null;
      const rc = new THREE.Raycaster(origin, dir.clone().divideScalar(len), 0, len);
      const hits = rc.intersectObjects(this.lists.meshes, false);
      const set = filterIds && filterIds.length ? new Set(filterIds) : null;
      const inList = (id) => {
        let r = this.recs.get(id);
        while (r) { if (set.has(r.id)) return true; r = r.parent != null ? this.recs.get(r.parent) : null; }
        return false;
      };
      for (const h of hits) {
        if (!h.object.visible && !h.object.userData.partId) continue;
        const isTerr = !h.object.userData.partId;
        const id = isTerr ? this.ids.terrain : h.object.userData.partId;
        const rec = this.recs.get(id);
        if (!isTerr && (!rec || rec.props.CanQuery === false)) continue;
        if (set) { const inside = inList(id); if (mode === 'Include' ? !inside : inside) continue; }
        else if (mode === 'Include') continue;
        const n = h.face ? h.face.normal.clone().transformDirection(h.object.matrixWorld) : new THREE.Vector3(0, 1, 0);
        const material = isTerr ? (this.terrain.hm ? this.terrain.hm.material : 'Grass') : (rec.props.Material || 'Plastic');
        return { id, point: h.point, normal: n, material, dist: h.distance };
      }
      // relevo (heightmap) também é testado analiticamente
      return null;
    }

    mouseInfo() {
      if (this.mouseCache && this.mouseCache.frame === this.frameNo) return this.mouseCache.v;
      const m = this.input.mouse;
      const x = this.pointerLocked ? this.vw / 2 : m.x, y = this.pointerLocked ? this.vh / 2 : m.y;
      const ray = this.rayFromScreen(x, y);
      const ch = this.localCharacter();
      const hit = this.raycast(ray.origin, ray.direction.clone().multiplyScalar(1000), ch ? [ch.modelId] : null, 'Exclude');
      const p = hit ? hit.point : ray.origin.clone().addScaledVector(ray.direction, 1000);
      const v = [x, y, p.x, p.y, p.z, hit && hit.id !== this.ids.terrain ? hit.id : null];
      this.mouseCache = { frame: this.frameNo, v };
      return v;
    }

    // ------------------------------------------------------------ ponte __host
    host(op, a) {
      if (op === 'set' || op === 'parent' || op === 'new') this.matrixStale = true;
      switch (op) {
        case 'new': this.newRec(a[0], a[1]); return [];
        case 'set': { const [v] = decode(a, 2); this.setProp(a[0], a[1], v); return []; }
        case 'parent': this.setParent(a[0], a[1] == null ? null : a[1]); return [];
        case 'destroy': this.destroyRec(a[0]); return [];
        case 'get': {
          const rec = this.recs.get(a[0]);
          if (!rec || !rec.part) return [];
          const b = rec.part;
          if (a[1] === 'CFrame') return ['cf', ...GF.cfFrom(b.pos, b.quat)];
          if (a[1] === 'Velocity') return ['v3', b.vel.x, b.vel.y, b.vel.z];
          return [];
        }
        case 'call': return this.call(a[0], a[1], decodeAll(a, 2));
        case 'poll': { const e = this.events.shift(); return e || []; }
        case 'raycast': {
          const o = new THREE.Vector3(a[0], a[1], a[2]), d = new THREE.Vector3(a[3], a[4], a[5]);
          const ids = a[7] ? String(a[7]).split(',').filter(Boolean).map(Number) : null;
          let hit = this.raycast(o, d, ids, a[6] || 'Exclude');
          const th = this.terrain.raycastHeightmap(o, d, d.length());
          if (th && (!hit || th.dist < hit.dist) && !(ids && a[6] === 'Include' && !ids.includes(this.ids.terrain)) && !(ids && a[6] !== 'Include' && ids.includes(this.ids.terrain))) hit = { id: this.ids.terrain, point: th.point, normal: th.normal, material: th.material, dist: th.dist };
          if (!hit) return [];
          return [hit.id, hit.point.x, hit.point.y, hit.point.z, hit.normal.x, hit.normal.y, hit.normal.z, hit.material, hit.dist];
        }
        case 'path': {
          const pts = this.physics.findPath(new THREE.Vector3(a[0], a[1], a[2]), new THREE.Vector3(a[3], a[4], a[5]), a[6], a[7]);
          if (!pts) return [];
          const out = [];
          for (const p of pts) out.push(p.x, p.y, p.z, p.jump ? 'Jump' : 'Walk');
          return out;
        }
        case 'ds_get': { const s = this.datastore.data[a[0]]; return [s && s[a[1]] != null ? s[a[1]] : null]; }
        case 'ds_set': { const s = (this.datastore.data[a[0]] = this.datastore.data[a[0]] || {}); s[a[1]] = a[2]; this.datastore.write(a[0], a[1], a[2]); return []; }
        case 'ds_remove': { const s = this.datastore.data[a[0]]; if (s) delete s[a[1]]; this.datastore.write(a[0], a[1], null); return []; }
        case 'ds_keys': return Object.keys(this.datastore.data[a[0]] || {});
        case 'module': { const m = this.cb.resolveModule ? this.cb.resolveModule(String(a[0])) : null; return m ? [m.path, m.source] : []; }
        case 'mouse': return this.mouseInfo();
        case 'mousebutton': return [!!this.input.mouse.b1];
        case 'device': return [a[0] === 'touch' ? this.isTouch : a[0] === 'keyboard' ? !this.isTouch || this.hadKeyboard === true : !this.isTouch];
        case 'localplayer': this.localPlayerId = a[0]; return [];
        case 'character': this.registerCharacter(a[0], a[1], a[2], a[3], !!a[4]); return [];
        case 'error': if (this.cb.error) this.cb.error(String(a[0]), String(a[1] || '')); return [];
        case 'notify': this.gui.notify(String(a[0] || ''), String(a[1] || ''), a[2]); return [];
        case 'bubble': this.gui.bubble(a[0], String(a[1])); return [];
        case 'kick': this.gui.kick(String(a[0])); if (this.cb.kick) setTimeout(() => this.cb.kick(String(a[0])), 50); return [];
        case 'cas_bind': this.gui.casBind(String(a[0]), !!a[1], String(a[2] || '')); return [];
        case 'cas_unbind': this.gui.casUnbind(String(a[0])); return [];
        case 'cas_title': this.gui.casTitle(String(a[0]), String(a[1])); return [];
        case 'cas_position': this.gui.casPosition(String(a[0]), a[1], a[2], a[3], a[4]); return [];
        case 'coregui': this.gui.coregui(String(a[0]), !!a[1]); return [];
        default: throw new Error('Operação desconhecida do motor: ' + op);
      }
    }

    // ------------------------------------------------------------ soldas
    updateWelds() {
      const m0 = new THREE.Matrix4(), m1 = new THREE.Matrix4(), tmp = new THREE.Matrix4(), s = new THREE.Vector3();
      for (const w of this.welds) {
        const p0 = this.recs.get(w.props.Part0), p1 = this.recs.get(w.props.Part1);
        if (!p0 || !p1 || !p0.part || !p1.part || w.props.Enabled === false || !w.inWorld && !(p0.inWorld && p1.inWorld)) {
          if (p1 && p1.part && p1.part.welded === w) { p1.part.welded = null; this.worldChanged(); }
          continue;
        }
        const b0 = p0.part, b1 = p1.part;
        m0.compose(b0.pos, b0.quat, s.set(1, 1, 1));
        if (!w.offset) {
          m1.compose(b1.pos, b1.quat, s.set(1, 1, 1));
          w.offset = tmp.copy(m0).invert().multiply(m1).clone();
        }
        if (b1.welded !== w) { b1.welded = w; this.worldChanged(); }
        m1.multiplyMatrices(m0, w.offset);
        m1.decompose(b1.pos, b1.quat, s);
        b1.vel.copy(b0.vel);
        GF.Physics.updateHalf(b1);
        if (b1.shape !== 'Ball') b1.radius = 0;
        this.syncMesh(p1);
      }
    }

    // ------------------------------------------------------------ entrada
    bindInput() {
      const c = this.container;
      const local = (e) => { const r = c.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; };
      document.addEventListener('pointerdown', (e) => { this.active = c.contains(e.target); }, true);
      window.addEventListener('keydown', (e) => {
        if (!this.running || !this.active || this.typing) return;
        const t = e.target;
        if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable) && !c.contains(t)) return;
        this.hadKeyboard = true;
        const k = keyName(e.code);
        if (['Space', 'Up', 'Down', 'Left', 'Right', 'Tab'].includes(k) || e.code === 'Slash') e.preventDefault();
        if (e.repeat) return;
        this.input.keys.add(k);
        if (k === 'Space') this.input.jumpLatch = true;
        this.audio.ensure();
        const processed = this.gui.promptKeyDown(k);
        if (/^(One|Two|Three|Four|Five|Six|Seven|Eight|Nine)$/.test(k) && this.gui.coreEnabled.Backpack) this.gui.equipSlot(DIGITS.indexOf(k) - 1);
        if (k === 'V') this.cam.toggleFirst = !this.cam.toggleFirst;
        this.queueEvent('key', k, true, processed);
      });
      window.addEventListener('keyup', (e) => {
        if (!this.running) return;
        const k = keyName(e.code);
        if (!this.input.keys.has(k)) return;
        this.input.keys.delete(k);
        this.gui.promptKeyUp(k);
        this.queueEvent('key', k, false, false);
      });
      window.addEventListener('blur', () => { if (this.input) { for (const k of this.input.keys) this.queueEvent('key', k, false, false); this.input.keys.clear(); } });

      // ponteiro na área 3D
      const canvasArea = this.canvasWrap;
      const overlayDown = (e) => {
        if (!this.running) return;
        if (e.target.closest && e.target.closest('.gfg-btn, .gfg-input, .gfg-scroll, .gfg-slot, .gfg-prompt, .gfg-casbtn, .gf-joy, .gf-jump, .gf-fp')) return;
        this.audio.ensure();
        const p = local(e);
        const isTouch = e.pointerType === 'touch';
        if (isTouch && !this.isTouch) { this.isTouch = true; this.touchUi.style.display = ''; }
        this.input.ptrs.set(e.pointerId, { x: p.x, y: p.y, sx: p.x, sy: p.y, t: performance.now(), moved: false, touch: isTouch, button: e.button });
        if (e.button === 0) this.input.mouse.b1 = true;
        if (e.button === 2) this.input.mouse.b2 = true;
        this.input.mouse.x = p.x; this.input.mouse.y = p.y;
        this.queueEvent('pointer', e.button === 2 ? 2 : 1, true, p.x, p.y, isTouch, false);
        try { c.setPointerCapture(e.pointerId); } catch (err) { /* ok */ }
        if (this.cam.isFirst && !isTouch && !document.pointerLockElement && this.renderer.domElement.requestPointerLock) {
          try { const r = this.renderer.domElement.requestPointerLock(); if (r && r.catch) r.catch(() => {}); } catch (err) { /* ok */ }
        }
      };
      c.addEventListener('pointerdown', overlayDown);
      c.addEventListener('pointermove', (e) => {
        if (!this.running) return;
        const p = local(e);
        if (document.pointerLockElement === this.renderer.domElement) {
          this.cam.yaw -= e.movementX * 0.0035; this.cam.pitch = GF.clamp(this.cam.pitch - e.movementY * 0.0035, -1.4, 1.4);
          return;
        }
        this.input.mouse.x = p.x; this.input.mouse.y = p.y;
        const ptr = this.input.ptrs.get(e.pointerId);
        if (!ptr) return;
        const dx = p.x - ptr.x, dy = p.y - ptr.y;
        ptr.x = p.x; ptr.y = p.y;
        if (Math.hypot(p.x - ptr.sx, p.y - ptr.sy) > 6) ptr.moved = true;
        if (this.input.ptrs.size === 2) {
          const [a, b] = [...this.input.ptrs.values()];
          const d = Math.hypot(a.x - b.x, a.y - b.y);
          if (this.input.pinch) this.cam.targetDist = GF.clamp(this.cam.targetDist * (this.input.pinch / d), this.zoomLimits()[0], this.zoomLimits()[1]);
          this.input.pinch = d;
          return;
        }
        if (ptr.moved) {
          const sens = ptr.touch ? 0.008 : 0.006;
          this.cam.yaw -= dx * sens;
          this.cam.pitch = GF.clamp(this.cam.pitch + dy * sens * (this.cam.isFirst ? -1 : 1), -1.4, 1.4);
        }
      });
      const up = (e) => {
        if (!this.running) return;
        const ptr = this.input.ptrs.get(e.pointerId);
        this.input.ptrs.delete(e.pointerId);
        if (this.input.ptrs.size < 2) this.input.pinch = 0;
        if (!ptr) return;
        if (ptr.button === 0) this.input.mouse.b1 = false;
        if (ptr.button === 2) this.input.mouse.b2 = false;
        this.queueEvent('pointer', ptr.button === 2 ? 2 : 1, false, ptr.x, ptr.y, ptr.touch, false);
        if (!ptr.moved && performance.now() - ptr.t < 600 && ptr.button !== 2) {
          const x = this.pointerLocked ? this.vw / 2 : ptr.x, y = this.pointerLocked ? this.vh / 2 : ptr.y;
          const ray = this.rayFromScreen(x, y);
          const ch = this.localCharacter();
          const hit = this.raycast(ray.origin, ray.direction.clone().multiplyScalar(1000), ch ? [ch.modelId] : null, 'Exclude');
          this.queueEvent('click3d', hit && hit.id !== this.ids.terrain ? hit.id : null);
        }
      };
      c.addEventListener('pointerup', up);
      c.addEventListener('pointercancel', up);
      c.addEventListener('contextmenu', (e) => { if (this.running) e.preventDefault(); });
      c.addEventListener('wheel', (e) => {
        if (!this.running) return;
        e.preventDefault();
        const [mn, mx] = this.zoomLimits();
        this.cam.targetDist = GF.clamp(this.cam.targetDist * (e.deltaY > 0 ? 1.12 : 0.89), mn, mx);
      }, { passive: false });
      document.addEventListener('pointerlockchange', () => { this.pointerLocked = document.pointerLockElement === (this.renderer && this.renderer.domElement); });
      void canvasArea;

      // joystick virtual
      const joyStart = (e) => {
        e.preventDefault(); e.stopPropagation();
        this.audio.ensure();
        const r = this.joy.getBoundingClientRect();
        this.input.joyPtr = { id: e.pointerId, cx: r.left + r.width / 2, cy: r.top + r.height / 2, r: r.width / 2 };
        try { this.joy.setPointerCapture(e.pointerId); } catch (err) { /* ok */ }
        joyMove(e);
      };
      const joyMove = (e) => {
        const j = this.input.joyPtr;
        if (!j || j.id !== e.pointerId) return;
        e.preventDefault(); e.stopPropagation();
        let dx = (e.clientX - j.cx) / j.r, dy = (e.clientY - j.cy) / j.r;
        const l = Math.hypot(dx, dy);
        if (l > 1) { dx /= l; dy /= l; }
        this.input.joy.x = dx; this.input.joy.y = dy;
        this.knob.style.transform = `translate(${dx * j.r * 0.6}px, ${dy * j.r * 0.6}px)`;
      };
      const joyEnd = (e) => {
        const j = this.input.joyPtr;
        if (!j || j.id !== e.pointerId) return;
        this.input.joyPtr = null; this.input.joy.x = 0; this.input.joy.y = 0;
        this.knob.style.transform = '';
      };
      this.joy.addEventListener('pointerdown', joyStart);
      this.joy.addEventListener('pointermove', joyMove);
      this.joy.addEventListener('pointerup', joyEnd);
      this.joy.addEventListener('pointercancel', joyEnd);
      const jumpDown = (e) => { e.preventDefault(); e.stopPropagation(); this.audio.ensure(); this.input.jump = true; this.queueEvent('key', 'Space', true, false); };
      const jumpUp = (e) => { e.preventDefault(); e.stopPropagation(); if (this.input.jump) this.queueEvent('key', 'Space', false, false); this.input.jump = false; };
      this.jumpBtn.addEventListener('pointerdown', jumpDown);
      this.jumpBtn.addEventListener('pointerup', jumpUp);
      this.jumpBtn.addEventListener('pointercancel', jumpUp);
      this.jumpBtn.addEventListener('pointerleave', jumpUp);
      this.fpBtn.addEventListener('pointerdown', (e) => { e.stopPropagation(); e.preventDefault(); this.cam.toggleFirst = !this.cam.toggleFirst; });
    }

    zoomLimits() {
      const p = this.recs && this.recs.get(this.localPlayerId);
      const mn = p && p.props.CameraMinZoomDistance != null ? p.props.CameraMinZoomDistance : 0.5;
      const mx = p && p.props.CameraMaxZoomDistance != null ? p.props.CameraMaxZoomDistance : 128;
      return [Math.max(0.5, mn), Math.max(mn, mx)];
    }

    applyPlayerInput(dt) {
      const ch = this.localCharacter();
      const k = this.input.keys;
      let f = 0, r = 0;
      if (!this.typing) {
        if (k.has('W') || k.has('Up')) f += 1;
        if (k.has('S') || k.has('Down')) f -= 1;
        if (k.has('D') || k.has('Right')) r += 1;
        if (k.has('A') || k.has('Left')) r -= 1;
        if (k.has('I')) this.cam.targetDist = Math.max(this.zoomLimits()[0], this.cam.targetDist - 30 * dt);
        if (k.has('O')) this.cam.targetDist = Math.min(this.zoomLimits()[1], this.cam.targetDist + 30 * dt);
      }
      f -= this.input.joy.y; r += this.input.joy.x;
      const yaw = this.cam.yaw;
      const fx = -Math.sin(yaw), fz = -Math.cos(yaw), rx = Math.cos(yaw), rz = -Math.sin(yaw);
      let mx = fx * f + rx * r, mz = fz * f + rz * r;
      const l = Math.hypot(mx, mz);
      if (l > 1) { mx /= l; mz /= l; }
      if (!ch) {
        // sem personagem: câmera livre
        const sp = (k.has('LeftShift') ? 80 : 30) * dt;
        this.cam.free.x += mx * sp; this.cam.free.z += mz * sp;
        if (k.has('E') || k.has('Space')) this.cam.free.y += sp;
        if (k.has('Q')) this.cam.free.y -= sp;
        return;
      }
      if (l > 0.01) ch.moveDir.set(mx, 0, mz);
      else ch.moveDir.copy(ch.scriptMove);
      if (l > 0.01 && ch.moveTarget) { ch.moveTarget = null; }
      if ((k.has('Space') && !this.typing) || this.input.jump || this.input.jumpLatch) ch.jumpRequest = true;
      this.input.jumpLatch = false;
    }

    updateCamera(dt) {
      const camRec = this.recs.get(this.ids.camera);
      const cam = this.camera;
      const ctype = camRec ? camRec.props.CameraType : 'Custom';
      const player = this.recs.get(this.localPlayerId);
      if (ctype === 'Scriptable' && camRec && camRec.props.CFrame) {
        const cf = camRec.props.CFrame;
        cam.position.set(cf[0], cf[1], cf[2]);
        cam.quaternion.copy(GF.quatFromCF(cf));
        this.cam.isFirst = false;
        this.cam.focus.copy(cam.position);
        return;
      }
      // alvo da câmera
      let subjectCh = this.localCharacter();
      let target = null;
      if (camRec && camRec.props.CameraSubject != null) {
        const sid = camRec.props.CameraSubject;
        const sc = this.characters.get(sid);
        if (sc) subjectCh = sc;
        else { const r = this.recs.get(sid); if (r && r.part) { target = r.part.pos.clone(); subjectCh = null; } else if (r && r.cls === 'Model') { const c = this.modelCenter(r); if (c) { target = c.clone(); subjectCh = null; } } }
      }
      if (subjectCh) target = subjectCh.feet.clone().add(new THREE.Vector3(0, 4.5, 0));
      if (!target) target = this.cam.free.clone();
      const lockFirst = (player && player.props.CameraMode === 'LockFirstPerson') || this.cam.toggleFirst;
      const [mn, mx] = this.zoomLimits();
      this.cam.targetDist = GF.clamp(this.cam.targetDist, mn, mx);
      this.cam.dist += (this.cam.targetDist - this.cam.dist) * Math.min(1, dt * 10);
      const first = !!subjectCh && (lockFirst || this.cam.dist < 1.2);
      this.cam.isFirst = first;
      if (subjectCh) subjectCh.firstPerson = first && subjectCh.isPlayer;
      if (!first && document.pointerLockElement) document.exitPointerLock();
      const yaw = this.cam.yaw, pitch = this.cam.pitch;
      if (first) {
        cam.position.copy(target).add(new THREE.Vector3(0, 0.2, 0));
        const look = new THREE.Vector3(-Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), -Math.cos(yaw) * Math.cos(pitch));
        cam.lookAt(cam.position.clone().add(look));
        if (subjectCh && subjectCh.isPlayer && !subjectCh.dead) subjectCh.yaw = yaw;
      } else {
        const off = new THREE.Vector3(Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        let dist = this.cam.dist;
        // evita atravessar paredes
        const hit = this.raycast(target, off.clone().multiplyScalar(dist), subjectCh ? [subjectCh.modelId] : null, 'Exclude');
        if (hit && hit.dist < dist) {
          const r = hit.id != null ? this.recs.get(hit.id) : null;
          if (!r || !r.part || (r.props.Transparency || 0) < 0.6) dist = Math.max(0.8, hit.dist - 0.6);
        }
        const th = this.terrain.heightAt(target.x + off.x * dist, target.z + off.z * dist);
        cam.position.copy(target).addScaledVector(off, dist);
        if (th != null && cam.position.y < th + 1) cam.position.y = th + 1;
        cam.lookAt(target);
      }
      if (this.cam.shake > 0) {
        const s = this.cam.shake;
        cam.position.x += (Math.random() - 0.5) * s; cam.position.y += (Math.random() - 0.5) * s;
        this.cam.shake = Math.max(0, s - dt * 2);
      }
      this.cam.focus.copy(target);
    }

    // ------------------------------------------------------------ quadro
    frame(t) {
      if (!this.running) return;
      this.raf = requestAnimationFrame(this.loop);
      let dt = (t - this.lastT) / 1000;
      this.lastT = t;
      if (!(dt > 0)) dt = 1 / 60;
      dt = Math.min(dt, 0.1);
      this.time += dt;
      this.frameNo++;
      try {
        this.applyPlayerInput(dt);
        // scripts Luau
        if (this.cb.step) {
          const ok = this.cb.step(dt);
          if (ok === false || !this.running) return;
        }
        // física a 60 Hz
        this.acc += dt;
        let n = 0;
        while (this.acc >= 1 / 60 && n < 4) {
          for (const b of this.kinematicBodies()) { b.delta = b.pos.clone().sub(b.prevPos); }
          this.physics.step(1 / 60);
          this.updateWelds();
          for (const b of this.kinematicBodies()) { b.prevPos.copy(b.pos); b.delta = null; }
          this.acc -= 1 / 60; n++;
        }
        if (n === 4) this.acc = 0;
        this.physics.detectTouches();
        this.matrixStale = true;
        for (const b of this.dynamicBodies()) this.syncMesh(b.rec);
        for (const b of this.kinematicBodies()) {
          this.syncMesh(b.rec);
          if (this.time > b.kinematicUntil) { b.kinematic = false; this.worldChanged(); }
        }
        this.updateCharacters(dt);
        this.updateCamera(dt);
        // ambiente
        const L = this.recs.get(this.ids.lighting), W = this.recs.get(this.ids.weather);
        this.env.update(dt, L ? L.props : {}, W ? W.props : {}, this.cam.focus, this.audio, this.time);
        this.particles.update(dt, (id) => this.partInfo(id), this.vh / (2 * Math.tan(THREE.MathUtils.degToRad(this.camera.fov) / 2)));
        if (this.tempObjs) this.tempObjs = this.tempObjs.filter((o) => o.userData.update());
        this.audio.frame(this.camera);
        this.gui.frame(dt);
        this.renderer.render(this.scene, this.camera);
      } catch (e) {
        console.error(e);
        if (this.cb.error) this.cb.error('Erro interno do motor: ' + (e && e.message ? e.message : e), e && e.stack ? String(e.stack) : '');
        if (this.cb.fatal) this.cb.fatal();
        return;
      }
      // FPS
      if (this.settings.showFps) {
        this.fps.t += dt; this.fps.n++;
        if (this.fps.t >= 0.5) {
          const info = this.renderer.info.render;
          this.fpsEl.textContent = Math.round(this.fps.n / this.fps.t) + ' FPS · ' + info.calls + ' draw · ' + this.recs.size + ' inst';
          this.fps.t = 0; this.fps.n = 0;
        }
      }
    }

    // estatísticas para o console
    stats() {
      return { instances: this.recs ? this.recs.size : 0, parts: this.lists ? this.lists.meshes.length : 0, characters: this.characters ? this.characters.size : 0 };
    }
  }

  GF.Engine = Engine;
  GF.decodeTagged = decode;
})();
