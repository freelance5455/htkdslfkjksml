/* GameForge Studio — Física: gravidade, colisões (AABB/esfera), personagens, toques e pathfinding.
 * Simplificações documentadas no Manual: corpos dinâmicos não giram por colisão; peças giradas
 * usam a caixa alinhada aos eixos (AABB) que as envolve. */
(function () {
  'use strict';
  const GF = (window.GF = window.GF || {});
  const CELL = 8;
  const BIG = 48;

  class Physics {
    constructor(engine) {
      this.engine = engine;
      this.grid = new Map();
      this.big = [];
      this.dirty = true;
      this.touching = new Map(); // chave -> [a, b]
      this.tmp = new THREE.Vector3();
    }

    markDirty() { this.dirty = true; }

    // Atualiza AABB de um corpo (p = rec.part)
    static updateHalf(p) {
      const e = new THREE.Matrix4().makeRotationFromQuaternion(p.quat).elements;
      const hx = p.size.x / 2, hy = p.size.y / 2, hz = p.size.z / 2;
      if (p.shape === 'Ball') {
        const r = Math.min(p.size.x, p.size.y, p.size.z) / 2;
        p.half.set(r, r, r);
        p.radius = r;
        return;
      }
      p.radius = 0;
      p.half.set(
        Math.abs(e[0]) * hx + Math.abs(e[4]) * hy + Math.abs(e[8]) * hz,
        Math.abs(e[1]) * hx + Math.abs(e[5]) * hy + Math.abs(e[9]) * hz,
        Math.abs(e[2]) * hx + Math.abs(e[6]) * hy + Math.abs(e[10]) * hz
      );
    }

    rebuild() {
      this.grid.clear();
      this.big = [];
      for (const p of this.engine.staticBodies()) {
        const h = p.half;
        if (h.x * 2 > BIG || h.y * 2 > BIG || h.z * 2 > BIG) { this.big.push(p); continue; }
        const x0 = Math.floor((p.pos.x - h.x) / CELL), x1 = Math.floor((p.pos.x + h.x) / CELL);
        const y0 = Math.floor((p.pos.y - h.y) / CELL), y1 = Math.floor((p.pos.y + h.y) / CELL);
        const z0 = Math.floor((p.pos.z - h.z) / CELL), z1 = Math.floor((p.pos.z + h.z) / CELL);
        for (let x = x0; x <= x1; x++)
          for (let y = y0; y <= y1; y++)
            for (let z = z0; z <= z1; z++) {
              const k = x + ',' + y + ',' + z;
              let arr = this.grid.get(k);
              if (!arr) this.grid.set(k, (arr = []));
              arr.push(p);
            }
      }
      this.dirty = false;
    }

    // Candidatos estáticos que podem tocar a caixa [min,max]
    queryStatic(minx, miny, minz, maxx, maxy, maxz, out) {
      const seen = new Set();
      for (const p of this.big) { out.push(p); seen.add(p); }
      for (const p of this.engine.kinematicBodies()) {
        if (p.pos.x + p.half.x < minx || p.pos.x - p.half.x > maxx || p.pos.y + p.half.y < miny || p.pos.y - p.half.y > maxy || p.pos.z + p.half.z < minz || p.pos.z - p.half.z > maxz) continue;
        out.push(p); seen.add(p);
      }
      const x0 = Math.floor(minx / CELL), x1 = Math.floor(maxx / CELL);
      const y0 = Math.floor(miny / CELL), y1 = Math.floor(maxy / CELL);
      const z0 = Math.floor(minz / CELL), z1 = Math.floor(maxz / CELL);
      if ((x1 - x0 + 1) * (y1 - y0 + 1) * (z1 - z0 + 1) > 4000) {
        for (const arr of this.grid.values()) for (const p of arr) if (!seen.has(p)) { seen.add(p); out.push(p); }
        return out;
      }
      for (let x = x0; x <= x1; x++)
        for (let y = y0; y <= y1; y++)
          for (let z = z0; z <= z1; z++) {
            const arr = this.grid.get(x + ',' + y + ',' + z);
            if (arr) for (const p of arr) if (!seen.has(p)) { seen.add(p); out.push(p); }
          }
      return out;
    }

    candidates(minx, miny, minz, maxx, maxy, maxz, self) {
      const out = [];
      this.queryStatic(minx, miny, minz, maxx, maxy, maxz, out);
      for (const d of this.engine.dynamicBodies()) {
        if (d === self) continue;
        if (d.pos.x + d.half.x < minx || d.pos.x - d.half.x > maxx || d.pos.y + d.half.y < miny || d.pos.y - d.half.y > maxy || d.pos.z + d.half.z < minz || d.pos.z - d.half.z > maxz) continue;
        out.push(d);
      }
      return out;
    }

    static overlap(a, b, pad) {
      pad = pad || 0;
      return Math.abs(a.pos.x - b.pos.x) < a.half.x + b.half.x + pad &&
        Math.abs(a.pos.y - b.pos.y) < a.half.y + b.half.y + pad &&
        Math.abs(a.pos.z - b.pos.z) < a.half.z + b.half.z + pad;
    }

    // Resolve corpo dinâmico b contra c. Retorna normal (eixo) ou null
    resolve(b, c) {
      const dx = b.pos.x - c.pos.x, dy = b.pos.y - c.pos.y, dz = b.pos.z - c.pos.z;
      let nx = 0, ny = 0, nz = 0, depth = 0;
      if (b.radius && !c.radius) {
        // esfera contra caixa (AABB)
        const cx = Math.max(c.pos.x - c.half.x, Math.min(b.pos.x, c.pos.x + c.half.x));
        const cy = Math.max(c.pos.y - c.half.y, Math.min(b.pos.y, c.pos.y + c.half.y));
        const cz = Math.max(c.pos.z - c.half.z, Math.min(b.pos.z, c.pos.z + c.half.z));
        let vx = b.pos.x - cx, vy = b.pos.y - cy, vz = b.pos.z - cz;
        const d2 = vx * vx + vy * vy + vz * vz;
        if (d2 >= b.radius * b.radius) return null;
        if (d2 < 1e-9) { ny = 1; depth = b.radius + (c.pos.y + c.half.y - b.pos.y); }
        else { const d = Math.sqrt(d2); nx = vx / d; ny = vy / d; nz = vz / d; depth = b.radius - d; }
      } else if (b.radius && c.radius) {
        const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        const r = b.radius + c.radius;
        if (d >= r) return null;
        if (d < 1e-6) { ny = 1; depth = r; } else { nx = dx / d; ny = dy / d; nz = dz / d; depth = r - d; }
      } else {
        const ox = b.half.x + c.half.x - Math.abs(dx);
        const oy = b.half.y + c.half.y - Math.abs(dy);
        const oz = b.half.z + c.half.z - Math.abs(dz);
        if (ox <= 0 || oy <= 0 || oz <= 0) return null;
        if (oy <= ox && oy <= oz) { ny = dy >= 0 ? 1 : -1; depth = oy; }
        else if (ox <= oz) { nx = dx >= 0 ? 1 : -1; depth = ox; }
        else { nz = dz >= 0 ? 1 : -1; depth = oz; }
      }
      const cDyn = c.dynamic;
      const share = cDyn ? 0.5 : 1;
      b.pos.x += nx * depth * share; b.pos.y += ny * depth * share; b.pos.z += nz * depth * share;
      if (cDyn) { c.pos.x -= nx * depth * 0.5; c.pos.y -= ny * depth * 0.5; c.pos.z -= nz * depth * 0.5; }
      // velocidade relativa
      const cv = c.vel || { x: 0, y: 0, z: 0 };
      const rv = (b.vel.x - cv.x) * nx + (b.vel.y - cv.y) * ny + (b.vel.z - cv.z) * nz;
      if (rv < 0) {
        const e = Math.max(b.elasticity || 0, c.elasticity || 0);
        const j = -(1 + (Math.abs(rv) > 4 ? e : 0)) * rv;
        const jb = cDyn ? j * 0.5 : j;
        b.vel.x += nx * jb; b.vel.y += ny * jb; b.vel.z += nz * jb;
        if (cDyn) { c.vel.x -= nx * jb; c.vel.y -= ny * jb; c.vel.z -= nz * jb; }
      }
      return { nx, ny, nz };
    }

    stepBodies(dt, g) {
      const destroyY = this.engine.fallenHeight();
      for (const b of this.engine.dynamicBodies()) {
        b.vel.y -= g * dt;
        b.pos.x += b.vel.x * dt; b.pos.y += b.vel.y * dt; b.pos.z += b.vel.z * dt;
        b.onGround = false;
        if (b.canCollide) {
          const h = b.half;
          const cands = this.candidates(b.pos.x - h.x - 1, b.pos.y - h.y - 1, b.pos.z - h.z - 1, b.pos.x + h.x + 1, b.pos.y + h.y + 1, b.pos.z + h.z + 1, b);
          for (let iter = 0; iter < 2; iter++) {
            for (const c of cands) {
              if (!c.canCollide || c === b) continue;
              const n = this.resolve(b, c);
              if (n && n.ny > 0.6) {
                b.onGround = true;
                const fr = Math.max(0, 1 - ((b.friction + (c.friction || 0.5)) * 0.5) * 10 * dt);
                b.vel.x *= fr; b.vel.z *= fr;
                if (c.delta && !c.dynamic) { b.pos.x += c.delta.x; b.pos.z += c.delta.z; }
              }
            }
          }
          // terreno de relevo
          const th = this.engine.terrainHeight(b.pos.x, b.pos.z);
          if (th != null && b.pos.y - h.y < th) {
            b.pos.y = th + h.y;
            if (b.vel.y < 0) b.vel.y = Math.abs(b.vel.y) > 8 ? -b.vel.y * (b.elasticity || 0) : 0;
            b.onGround = true;
            const fr = Math.max(0, 1 - b.friction * 8 * dt);
            b.vel.x *= fr; b.vel.z *= fr;
          }
        }
        if (b.radius && b.onGround) {
          // rolar visualmente
          const sp = Math.hypot(b.vel.x, b.vel.z);
          if (sp > 0.01) {
            const axis = new THREE.Vector3(b.vel.z, 0, -b.vel.x).normalize();
            const q = new THREE.Quaternion().setFromAxisAngle(axis, (sp * dt) / b.radius);
            b.quat.premultiply(q);
          }
        }
        if (b.pos.y < destroyY && !b.fellQueued) { b.fellQueued = true; this.engine.queueEvent('fellpart', b.id); }
      }
    }

    // ---------------- Personagens ----------------
    stepCharacter(ch, dt, g) {
      const hum = ch.hum.props;
      const box = ch.box;
      if (ch.dead) return;
      // direção desejada
      let mx = ch.moveDir.x, mz = ch.moveDir.z;
      if (ch.moveTarget) {
        const tx = ch.moveTarget.x - ch.feet.x, tz = ch.moveTarget.z - ch.feet.z;
        const d = Math.hypot(tx, tz);
        ch.moveTime += dt;
        if (d < 1.2) {
          ch.moveTarget = null; mx = mz = 0;
          this.engine.queueEvent('movefinished', ch.hum.id, true);
        } else if (ch.moveTime > 8) {
          ch.moveTarget = null; mx = mz = 0;
          this.engine.queueEvent('movefinished', ch.hum.id, false);
        } else { mx = tx / d; mz = tz / d; }
      }
      const ml = Math.hypot(mx, mz);
      if (ml > 1) { mx /= ml; mz /= ml; }
      const speed = hum.PlatformStand || hum.Sit || ch.sitting ? 0 : (hum.WalkSpeed == null ? 16 : hum.WalkSpeed);
      const kd = Math.exp(-(ch.onGround ? 6 : 1.5) * dt);
      ch.knock.multiplyScalar(kd);
      ch.vel.x = mx * speed + ch.knock.x; ch.vel.z = mz * speed + ch.knock.z;
      ch.moving = ml > 0.05 ? speed * Math.min(1, ml) : 0;
      ch.moveDirWorld.set(mx, 0, mz);
      // pulo
      if (ch.jumpRequest) {
        if (ch.sitting) { this.engine.setHumanoidSit(ch, false); ch.vel.y = (hum.JumpPower == null ? 50 : hum.JumpPower) * 0.7; ch.onGround = false; }
        else if (ch.onGround && !hum.Sit) {
          ch.vel.y = hum.JumpPower == null ? 50 : hum.JumpPower;
          ch.onGround = false;
          this.engine.queueEvent('jumped', ch.hum.id);
          if (ch.isPlayer) this.engine.audio.oneShot('sfx:jump', 0.15);
        }
        ch.jumpRequest = false;
      }
      if (ch.sitting) {
        const s = ch.sitting.part;
        if (!s || !ch.sitting.inWorld) { this.engine.setHumanoidSit(ch, false); }
        else {
          ch.feet.set(s.pos.x, s.pos.y + s.half.y - 1, s.pos.z);
          ch.vel.set(0, 0, 0); ch.onGround = true; ch.moving = 0;
          return;
        }
      }
      ch.vel.y -= g * dt;
      if (ch.vel.y < -300) ch.vel.y = -300;

      const wasGround = ch.onGround;
      ch.onGround = false;
      const cands = this.candidates(ch.feet.x - 3, ch.feet.y - 4, ch.feet.z - 3, ch.feet.x + 3, ch.feet.y + 8, ch.feet.z + 3, null)
        .filter((c) => c.canCollide && !c.characterOwned);
      const R = 0.95, H = 5.2;
      const blocked = (fx, fy, fz) => {
        for (const c of cands) {
          if (Math.abs(fx - c.pos.x) < R + c.half.x && Math.abs(fz - c.pos.z) < R + c.half.z && fy < c.pos.y + c.half.y && fy + H > c.pos.y - c.half.y) return c;
        }
        return null;
      };
      // movimento horizontal com degrau automático
      let blockedH = false;
      const tryAxis = (axis, amount) => {
        if (amount === 0) return;
        const nf = ch.feet.clone(); nf[axis] += amount;
        const c = blocked(nf.x, nf.y + 0.01, nf.z);
        if (!c) { ch.feet.copy(nf); return; }
        const top = c.pos.y + c.half.y;
        if (top - ch.feet.y <= 1.25 && (wasGround || ch.vel.y <= 0) && !blocked(nf.x, top + 0.02, nf.z)) {
          nf.y = top + 0.01; ch.feet.copy(nf); return;
        }
        if (c.dynamic) {
          c.vel[axis] += Math.sign(amount) * 30 * dt;
          c.pos[axis] += amount * 0.4;
        }
        blockedH = true;
        // encosta na face
        const s = Math.sign(amount);
        ch.feet[axis] = c.pos[axis] - s * (c.half[axis] + R + 0.001);
      };
      tryAxis('x', ch.vel.x * dt);
      tryAxis('z', ch.vel.z * dt);
      // vertical
      const dy = ch.vel.y * dt;
      const ny = ch.feet.y + dy;
      ch.ground = null;
      let hit = null;
      for (const c of cands) {
        if (Math.abs(ch.feet.x - c.pos.x) < R + c.half.x && Math.abs(ch.feet.z - c.pos.z) < R + c.half.z) {
          const top = c.pos.y + c.half.y, bottom = c.pos.y - c.half.y;
          if (dy <= 0 && ch.feet.y >= top - 0.6 && ny <= top + (wasGround ? 0.35 : 0)) {
            if (!hit || top > hit.top) hit = { c, top, kind: 'floor' };
          } else if (dy > 0 && ch.feet.y + H <= bottom + 0.3 && ny + H > bottom) {
            hit = { c, top: bottom - H, kind: 'ceil' };
          }
        }
      }
      if (hit && hit.kind === 'floor') {
        ch.feet.y = hit.top; ch.vel.y = 0; ch.onGround = true; ch.ground = hit.c;
        if (hit.c.delta && !hit.c.dynamic) ch.feet.add(hit.c.delta);
      } else if (hit && hit.kind === 'ceil') {
        ch.feet.y = hit.top - 0.01; ch.vel.y = Math.min(0, ch.vel.y);
      } else {
        ch.feet.y = ny;
      }
      const th = this.engine.terrainHeight(ch.feet.x, ch.feet.z);
      if (th != null && ch.feet.y <= th + (wasGround && ch.vel.y <= 0 ? 0.5 : 0)) {
        ch.feet.y = th; if (ch.vel.y < 0) ch.vel.y = 0; ch.onGround = true; ch.ground = 'terrain';
      }
      // pulo automático de NPC ao encontrar obstáculo
      if (blockedH && ch.moveTarget && ch.onGround) ch.jumpRequest = true;
      if (!wasGround && ch.onGround) ch.landed = true;
      // rotação
      if (ml > 0.05 && hum.AutoRotate !== false && !ch.firstPerson) {
        const target = Math.atan2(-mx, -mz);
        let diff = target - ch.yaw;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        ch.yaw += diff * Math.min(1, dt * 12);
      }
      if (ch.feet.y < this.engine.fallenHeight() && !ch.fellQueued) { ch.fellQueued = true; this.engine.queueEvent('fell', ch.hum.id); }
      void box;
    }

    // ---------------- Toques ----------------
    detectTouches() {
      const now = new Map();
      const add = (a, b) => {
        if (a === b) return;
        const k = a < b ? a + '|' + b : b + '|' + a;
        if (!now.has(k)) now.set(k, [a, b]);
      };
      for (const b of this.engine.dynamicBodies()) {
        if (!b.canTouch) continue;
        const h = b.half;
        const cands = this.candidates(b.pos.x - h.x - 0.2, b.pos.y - h.y - 0.2, b.pos.z - h.z - 0.2, b.pos.x + h.x + 0.2, b.pos.y + h.y + 0.2, b.pos.z + h.z + 0.2, b);
        for (const c of cands) if (c.canTouch && !c.isTerrain && Physics.overlap(b, c, 0.08)) add(b.id, c.id);
      }
      for (const ch of this.engine.characters.values()) {
        if (ch.dead) continue;
        const box = { pos: new THREE.Vector3(ch.feet.x, ch.feet.y + 2.6, ch.feet.z), half: new THREE.Vector3(1, 2.65, 1) };
        const cands = this.candidates(box.pos.x - 1.3, box.pos.y - 3, box.pos.z - 1.3, box.pos.x + 1.3, box.pos.y + 3, box.pos.z + 1.3, null);
        for (const c of cands) if (c.canTouch && !c.characterOwned && Physics.overlap(box, c, 0.12)) add(ch.rootId, c.id);
        // personagem x personagem
        for (const o of this.engine.characters.values()) {
          if (o === ch || o.dead) continue;
          if (Math.abs(o.feet.x - ch.feet.x) < 2 && Math.abs(o.feet.z - ch.feet.z) < 2 && Math.abs(o.feet.y - ch.feet.y) < 5) add(ch.rootId, o.rootId);
        }
      }
      for (const [k, pair] of now) {
        if (!this.touching.has(k)) {
          this.engine.queueEvent('touch', pair[0], pair[1]);
          this.engine.queueEvent('touch', pair[1], pair[0]);
        }
      }
      for (const [k, pair] of this.touching) {
        if (!now.has(k)) {
          this.engine.queueEvent('touchend', pair[0], pair[1]);
          this.engine.queueEvent('touchend', pair[1], pair[0]);
        }
      }
      this.touching = now;
    }

    touchingOf(id) {
      const out = [];
      for (const [, p] of this.touching) {
        if (p[0] === id) out.push(p[1]);
        else if (p[1] === id) out.push(p[0]);
      }
      return out;
    }

    step(dt) {
      if (this.dirty) this.rebuild();
      const g = this.engine.gravity();
      this.stepBodies(dt, g);
      for (const ch of this.engine.characters.values()) this.stepCharacter(ch, dt, g);
    }

    // ---------------- Pathfinding (A* em grade) ----------------
    surfaceAt(x, z, maxY) {
      // superfície mais alta abaixo de maxY nesse ponto
      let best = -Infinity;
      const out = [];
      this.queryStatic(x - 0.5, maxY - 400, z - 0.5, x + 0.5, maxY, z + 0.5, out);
      for (const c of out) {
        if (!c.canCollide) continue;
        if (Math.abs(x - c.pos.x) <= c.half.x && Math.abs(z - c.pos.z) <= c.half.z) {
          const top = c.pos.y + c.half.y;
          if (top <= maxY && top > best) best = top;
        }
      }
      const th = this.engine.terrainHeight(x, z);
      if (th != null && th <= maxY && th > best) best = th;
      return best;
    }

    clearAt(x, y, z, radius, height) {
      const out = [];
      this.queryStatic(x - radius, y + 0.3, z - radius, x + radius, y + height, z + radius, out);
      for (const c of out) {
        if (!c.canCollide) continue;
        if (Math.abs(x - c.pos.x) < c.half.x + radius * 0.6 && Math.abs(z - c.pos.z) < c.half.z + radius * 0.6 && y + 0.3 < c.pos.y + c.half.y && y + height > c.pos.y - c.half.y) return false;
      }
      return true;
    }

    findPath(start, goal, radius, height) {
      if (this.dirty) this.rebuild();
      radius = radius || 2; height = height || 5;
      const span = Math.max(Math.abs(goal.x - start.x), Math.abs(goal.z - start.z)) + 40;
      let cs = 2;
      while (span / cs > 180) cs *= 1.5;
      const ox = Math.min(start.x, goal.x) - 20, oz = Math.min(start.z, goal.z) - 20;
      const W = Math.ceil((Math.abs(goal.x - start.x) + 40) / cs) + 1;
      const Hh = Math.ceil((Math.abs(goal.z - start.z) + 40) / cs) + 1;
      const idx = (i, j) => j * W + i;
      const toCell = (p) => [Math.round((p.x - ox) / cs), Math.round((p.z - oz) / cs)];
      const [si, sj] = toCell(start), [gi, gj] = toCell(goal);
      const startY = this.surfaceAt(start.x, start.z, start.y + 1);
      const sy = isFinite(startY) ? startY : start.y - 3;
      const open = [[0, si, sj]];
      const gScore = new Map([[idx(si, sj), 0]]);
      const yOf = new Map([[idx(si, sj), sy]]);
      const came = new Map();
      const jumpAt = new Set();
      const hfn = (i, j) => Math.hypot(i - gi, j - gj);
      let found = null, iter = 0;
      const closed = new Set();
      while (open.length && iter++ < 30000) {
        // menor f
        let bi = 0;
        for (let k = 1; k < open.length; k++) if (open[k][0] < open[bi][0]) bi = k;
        const [, ci, cj] = open.splice(bi, 1)[0];
        const ck = idx(ci, cj);
        if (closed.has(ck)) continue;
        closed.add(ck);
        if (ci === gi && cj === gj) { found = ck; break; }
        const cy = yOf.get(ck);
        for (let di = -1; di <= 1; di++)
          for (let dj = -1; dj <= 1; dj++) {
            if (!di && !dj) continue;
            const ni = ci + di, nj = cj + dj;
            if (ni < 0 || nj < 0 || ni >= W || nj >= Hh) continue;
            const nk = idx(ni, nj);
            if (closed.has(nk)) continue;
            const wx = ox + ni * cs, wz = oz + nj * cs;
            const ny = this.surfaceAt(wx, wz, cy + 6.5);
            if (!isFinite(ny) || cy - ny > 12) continue; // buraco
            if (!this.clearAt(wx, ny, wz, radius, height)) continue;
            if (di && dj) {
              // evita cortar quinas
              if (!this.clearAt(ox + ci * cs + di * cs, cy, oz + cj * cs, radius, height) || !this.clearAt(ox + ci * cs, cy, oz + cj * cs + dj * cs, radius, height)) continue;
            }
            const rise = ny - cy;
            const cost = (di && dj ? 1.414 : 1) + (rise > 1.2 ? 2 : 0);
            const ng = gScore.get(ck) + cost;
            if (ng < (gScore.has(nk) ? gScore.get(nk) : Infinity)) {
              gScore.set(nk, ng); yOf.set(nk, ny); came.set(nk, ck);
              if (rise > 1.2) jumpAt.add(nk); else jumpAt.delete(nk);
              open.push([ng + hfn(ni, nj), ni, nj]);
            }
          }
      }
      if (found == null) return null;
      const pts = [];
      let k = found;
      while (k != null) {
        const i = k % W, j = Math.floor(k / W);
        pts.push({ x: ox + i * cs, y: yOf.get(k), z: oz + j * cs, jump: jumpAt.has(k) });
        k = came.get(k);
      }
      pts.reverse();
      pts[pts.length - 1].x = goal.x; pts[pts.length - 1].z = goal.z;
      // simplifica pontos colineares na mesma altura
      const simp = [pts[0]];
      for (let i = 1; i < pts.length - 1; i++) {
        const a = simp[simp.length - 1], b = pts[i], c = pts[i + 1];
        const cross = (b.x - a.x) * (c.z - a.z) - (b.z - a.z) * (c.x - a.x);
        if (Math.abs(cross) > 0.01 || b.jump || Math.abs(b.y - a.y) > 0.5 || Math.abs(c.y - b.y) > 0.5) simp.push(b);
      }
      if (pts.length > 1) simp.push(pts[pts.length - 1]);
      return simp;
    }
  }

  GF.Physics = Physics;
})();
