/* GameForge Studio — Materiais e texturas procedurais (sem downloads). */
(function () {
  'use strict';
  const GF = (window.GF = window.GF || {});

  // Parâmetros físicos de cada material
  const MATERIALS = {
    Plastic: { rough: 0.55, metal: 0, tex: 'plastic' },
    SmoothPlastic: { rough: 0.3, metal: 0, tex: null },
    Wood: { rough: 0.8, metal: 0, tex: 'wood' },
    WoodPlanks: { rough: 0.8, metal: 0, tex: 'planks' },
    Brick: { rough: 0.9, metal: 0, tex: 'brick' },
    Cobblestone: { rough: 0.95, metal: 0, tex: 'cobble' },
    Concrete: { rough: 0.95, metal: 0, tex: 'concrete' },
    Slate: { rough: 0.85, metal: 0, tex: 'slate' },
    Granite: { rough: 0.7, metal: 0, tex: 'granite' },
    Marble: { rough: 0.25, metal: 0, tex: 'marble' },
    Metal: { rough: 0.35, metal: 0.85, tex: 'brushed' },
    DiamondPlate: { rough: 0.4, metal: 0.9, tex: 'diamond' },
    CorrodedMetal: { rough: 0.8, metal: 0.6, tex: 'corroded' },
    Foil: { rough: 0.15, metal: 1, tex: null },
    Neon: { rough: 1, metal: 0, tex: null, emissive: true },
    Glass: { rough: 0.05, metal: 0.1, tex: null, glass: true },
    Ice: { rough: 0.1, metal: 0, tex: 'ice', glass: true },
    Sand: { rough: 1, metal: 0, tex: 'sand' },
    Grass: { rough: 1, metal: 0, tex: 'grass' },
    LeafyGrass: { rough: 1, metal: 0, tex: 'grass' },
    Ground: { rough: 1, metal: 0, tex: 'ground' },
    Rock: { rough: 0.95, metal: 0, tex: 'rock' },
    Basalt: { rough: 0.95, metal: 0, tex: 'rock' },
    Limestone: { rough: 0.9, metal: 0, tex: 'concrete' },
    Sandstone: { rough: 0.95, metal: 0, tex: 'sand' },
    Snow: { rough: 0.9, metal: 0, tex: 'snow' },
    Salt: { rough: 0.9, metal: 0, tex: 'snow' },
    Mud: { rough: 1, metal: 0, tex: 'ground' },
    Fabric: { rough: 1, metal: 0, tex: 'fabric' },
    Pebble: { rough: 0.9, metal: 0, tex: 'pebble' },
    Water: { rough: 0.05, metal: 0.1, tex: null, glass: true },
    Asphalt: { rough: 1, metal: 0, tex: 'concrete' },
    Pavement: { rough: 0.95, metal: 0, tex: 'cobble' },
    CrackedLava: { rough: 0.9, metal: 0, tex: 'rock', emissive: true },
  };

  const SIZE = 128;
  const cache = {};

  // Gerador pseudoaleatório determinístico
  function rng(seed) {
    let s = seed >>> 0 || 1;
    return function () {
      s ^= s << 13; s ^= s >>> 17; s ^= s << 5;
      return ((s >>> 0) % 100000) / 100000;
    };
  }

  function canvas() {
    const c = document.createElement('canvas');
    c.width = c.height = SIZE;
    return c;
  }

  function noiseFill(ctx, r, base, amp, size) {
    const img = ctx.getImageData(0, 0, SIZE, SIZE);
    const d = img.data;
    for (let y = 0; y < SIZE; y += size) {
      for (let x = 0; x < SIZE; x += size) {
        const v = Math.max(0, Math.min(255, base + (r() - 0.5) * amp));
        for (let yy = 0; yy < size; yy++)
          for (let xx = 0; xx < size; xx++) {
            const i = ((y + yy) * SIZE + (x + xx)) * 4;
            d[i] = d[i + 1] = d[i + 2] = v; d[i + 3] = 255;
          }
      }
    }
    ctx.putImageData(img, 0, 0);
  }

  const painters = {
    plastic(ctx, r) { noiseFill(ctx, r, 240, 12, 2); },
    concrete(ctx, r) { noiseFill(ctx, r, 225, 50, 1); for (let i = 0; i < 40; i++) { ctx.fillStyle = `rgba(0,0,0,${r() * 0.08})`; ctx.beginPath(); ctx.arc(r() * SIZE, r() * SIZE, r() * 6, 0, 7); ctx.fill(); } },
    sand(ctx, r) { noiseFill(ctx, r, 230, 45, 1); },
    snow(ctx, r) { noiseFill(ctx, r, 248, 14, 2); },
    ground(ctx, r) { noiseFill(ctx, r, 200, 70, 2); for (let i = 0; i < 60; i++) { ctx.fillStyle = `rgba(0,0,0,${r() * 0.15})`; ctx.fillRect(r() * SIZE, r() * SIZE, 3, 2); } },
    grass(ctx, r) {
      noiseFill(ctx, r, 215, 40, 2);
      for (let i = 0; i < 500; i++) {
        const x = r() * SIZE, y = r() * SIZE, l = 2 + r() * 5;
        ctx.strokeStyle = r() > 0.5 ? 'rgba(255,255,255,0.18)' : 'rgba(0,0,0,0.16)';
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + (r() - 0.5) * 2, y - l); ctx.stroke();
      }
    },
    rock(ctx, r) {
      noiseFill(ctx, r, 205, 60, 2);
      for (let i = 0; i < 12; i++) {
        ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 1;
        ctx.beginPath(); let x = r() * SIZE, y = r() * SIZE; ctx.moveTo(x, y);
        for (let k = 0; k < 5; k++) { x += (r() - 0.5) * 30; y += (r() - 0.5) * 30; ctx.lineTo(x, y); }
        ctx.stroke();
      }
    },
    brick(ctx, r) {
      ctx.fillStyle = '#b8b8b8'; ctx.fillRect(0, 0, SIZE, SIZE);
      const bh = 16, bw = 32;
      for (let row = 0; row < SIZE / bh; row++) {
        const off = (row % 2) * bw / 2;
        for (let col = -1; col < SIZE / bw + 1; col++) {
          const v = 215 + (r() - 0.5) * 50;
          ctx.fillStyle = `rgb(${v},${v},${v})`;
          ctx.fillRect(col * bw + off + 1, row * bh + 1, bw - 2, bh - 2);
        }
      }
    },
    cobble(ctx, r) {
      ctx.fillStyle = '#8a8a8a'; ctx.fillRect(0, 0, SIZE, SIZE);
      for (let i = 0; i < 45; i++) {
        const v = 190 + (r() - 0.5) * 70;
        ctx.fillStyle = `rgb(${v},${v},${v})`;
        ctx.beginPath(); ctx.ellipse(r() * SIZE, r() * SIZE, 8 + r() * 8, 6 + r() * 7, r() * 3, 0, 7); ctx.fill();
      }
    },
    pebble(ctx, r) {
      noiseFill(ctx, r, 200, 30, 2);
      for (let i = 0; i < 140; i++) {
        const v = 170 + r() * 80;
        ctx.fillStyle = `rgb(${v},${v},${v})`;
        ctx.beginPath(); ctx.ellipse(r() * SIZE, r() * SIZE, 2 + r() * 4, 2 + r() * 3, r() * 3, 0, 7); ctx.fill();
      }
    },
    slate(ctx, r) {
      noiseFill(ctx, r, 210, 25, 4);
      ctx.strokeStyle = 'rgba(0,0,0,0.25)';
      for (let y = 0; y < SIZE; y += 21) { ctx.beginPath(); ctx.moveTo(0, y + r() * 4); ctx.lineTo(SIZE, y + r() * 4); ctx.stroke(); }
    },
    granite(ctx, r) {
      noiseFill(ctx, r, 215, 30, 1);
      for (let i = 0; i < 700; i++) { const v = r() > 0.5 ? 255 : 60; ctx.fillStyle = `rgba(${v},${v},${v},0.5)`; ctx.fillRect(r() * SIZE, r() * SIZE, 1.5, 1.5); }
    },
    marble(ctx, r) {
      ctx.fillStyle = '#f0f0f0'; ctx.fillRect(0, 0, SIZE, SIZE);
      for (let i = 0; i < 8; i++) {
        ctx.strokeStyle = `rgba(90,90,90,${0.15 + r() * 0.2})`; ctx.lineWidth = 0.5 + r() * 1.5;
        ctx.beginPath(); let x = r() * SIZE, y = 0; ctx.moveTo(x, y);
        while (y < SIZE) { x += (r() - 0.5) * 18; y += 6; ctx.lineTo(x, y); }
        ctx.stroke();
      }
    },
    wood(ctx, r) {
      ctx.fillStyle = '#d8d8d8'; ctx.fillRect(0, 0, SIZE, SIZE);
      for (let y = 0; y < SIZE; y += 2) {
        const v = 200 + Math.sin(y * 0.35 + r() * 0.8) * 25 + (r() - 0.5) * 12;
        ctx.fillStyle = `rgb(${v},${v},${v})`; ctx.fillRect(0, y, SIZE, 2);
      }
      for (let i = 0; i < 3; i++) { ctx.fillStyle = 'rgba(0,0,0,0.15)'; ctx.beginPath(); ctx.ellipse(r() * SIZE, r() * SIZE, 7, 3, 0, 0, 7); ctx.fill(); }
    },
    planks(ctx, r) {
      painters.wood(ctx, r);
      ctx.fillStyle = 'rgba(0,0,0,0.35)';
      for (let y = 0; y < SIZE; y += 32) ctx.fillRect(0, y, SIZE, 2);
      for (let row = 0; row < 4; row++) ctx.fillRect((row * 53) % SIZE, row * 32, 2, 32);
    },
    brushed(ctx, r) {
      ctx.fillStyle = '#d0d0d0'; ctx.fillRect(0, 0, SIZE, SIZE);
      for (let y = 0; y < SIZE; y++) { const v = 200 + (r() - 0.5) * 40; ctx.fillStyle = `rgba(${v},${v},${v},0.6)`; ctx.fillRect(0, y, SIZE, 1); }
    },
    diamond(ctx, r) {
      painters.brushed(ctx, r);
      ctx.fillStyle = 'rgba(255,255,255,0.45)';
      for (let y = 0; y < SIZE; y += 16)
        for (let x = (y / 16) % 2 * 8; x < SIZE; x += 16) {
          ctx.save(); ctx.translate(x + 4, y + 4); ctx.rotate(0.78); ctx.fillRect(-5, -1.5, 10, 3); ctx.restore();
        }
    },
    corroded(ctx, r) {
      painters.brushed(ctx, r);
      for (let i = 0; i < 80; i++) { ctx.fillStyle = `rgba(120,70,30,${r() * 0.35})`; ctx.beginPath(); ctx.arc(r() * SIZE, r() * SIZE, r() * 8, 0, 7); ctx.fill(); }
    },
    ice(ctx, r) {
      ctx.fillStyle = '#f4f8ff'; ctx.fillRect(0, 0, SIZE, SIZE);
      ctx.strokeStyle = 'rgba(255,255,255,0.8)';
      for (let i = 0; i < 14; i++) { ctx.beginPath(); ctx.moveTo(r() * SIZE, r() * SIZE); ctx.lineTo(r() * SIZE, r() * SIZE); ctx.stroke(); }
    },
    fabric(ctx, r) {
      ctx.fillStyle = '#d6d6d6'; ctx.fillRect(0, 0, SIZE, SIZE);
      for (let i = 0; i < SIZE; i += 3) {
        ctx.fillStyle = 'rgba(255,255,255,0.15)'; ctx.fillRect(i, 0, 1, SIZE);
        ctx.fillStyle = 'rgba(0,0,0,0.12)'; ctx.fillRect(0, i, SIZE, 1);
      }
    },
  };

  function getTexture(kind) {
    if (!kind) return null;
    if (cache[kind]) return cache[kind];
    const c = canvas();
    const ctx = c.getContext('2d');
    let seed = 0;
    for (let i = 0; i < kind.length; i++) seed = (seed * 31 + kind.charCodeAt(i)) | 0;
    (painters[kind] || painters.plastic)(ctx, rng(seed + 7));
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 4;
    cache[kind] = tex;
    return tex;
  }

  // Cria ou atualiza o material de uma peça
  function applyMaterial(mat, opts) {
    const def = MATERIALS[opts.material] || MATERIALS.Plastic;
    const color = new THREE.Color(opts.color.r, opts.color.g, opts.color.b);
    mat.color.copy(color);
    mat.roughness = def.rough;
    mat.metalness = Math.min(1, def.metal + (opts.reflectance || 0) * 0.8);
    if (opts.reflectance) mat.roughness = Math.max(0.02, def.rough * (1 - opts.reflectance));
    const env = mat.metalness > 0.2 ? GF.Materials.envMap || null : null;
    if (mat.envMap !== env) { mat.envMap = env; mat.envMapIntensity = 1; mat.needsUpdate = true; }
    const map = opts.customMap || getTexture(def.tex);
    if (mat.map !== map) { mat.map = map; mat.needsUpdate = true; }
    if (def.emissive) {
      mat.emissive.copy(color); mat.emissiveIntensity = opts.material === 'CrackedLava' ? 0.6 : 1.6;
    } else {
      mat.emissive.setRGB(0, 0, 0); mat.emissiveIntensity = 0;
    }
    let alpha = 1 - (opts.transparency || 0);
    if (def.glass) alpha = Math.min(alpha, opts.material === 'Water' ? 0.6 : 0.55);
    const transparent = alpha < 0.999;
    if (mat.transparent !== transparent) { mat.transparent = transparent; mat.needsUpdate = true; }
    mat.opacity = alpha;
    mat.depthWrite = alpha > 0.6;
    mat.visible = alpha > 0.001;
  }

  GF.Materials = { MATERIALS, getTexture, applyMaterial };
})();
