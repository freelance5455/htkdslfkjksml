/* GameForge Studio — Interface dentro do jogo (ScreenGui, BillboardGui e elementos),
 * renderizada como camada DOM sobre a janela de teste. Inclui a interface padrão:
 * barra de vida, placar (leaderstats), mochila (Backpack), notificações, ProximityPrompt,
 * balões de fala e botões de toque do ContextActionService. */
(function () {
  'use strict';
  const GF = (window.GF = window.GF || {});

  const svg = (body, vb) => 'data:image/svg+xml;utf8,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${vb || '0 0 64 64'}">${body}</svg>`);
  const ICONS = {
    coin: svg('<circle cx="32" cy="32" r="28" fill="#f5c542" stroke="#b8860b" stroke-width="4"/><text x="32" y="43" font-size="30" text-anchor="middle" font-family="Arial" font-weight="bold" fill="#b8860b">$</text>'),
    heart: svg('<path d="M32 56 C8 38 4 26 10 16 C16 6 28 8 32 18 C36 8 48 6 54 16 C60 26 56 38 32 56Z" fill="#e53950" stroke="#8c1c2c" stroke-width="3"/>'),
    star: svg('<path d="M32 4 L40 24 L61 25 L44 38 L50 59 L32 47 L14 59 L20 38 L3 25 L24 24Z" fill="#ffd23f" stroke="#c08d00" stroke-width="3"/>'),
    sword: svg('<path d="M50 4 L60 4 L60 14 L26 46 L18 38Z" fill="#cfd8dc" stroke="#607d8b" stroke-width="3"/><path d="M12 36 L28 52" stroke="#8d6e63" stroke-width="6"/><path d="M6 58 L18 46" stroke="#5d4037" stroke-width="7" stroke-linecap="round"/>'),
    shield: svg('<path d="M32 4 L56 12 C56 36 48 50 32 60 C16 50 8 36 8 12Z" fill="#3f7fd9" stroke="#1d3f73" stroke-width="4"/><path d="M32 14 L32 50" stroke="#ffd23f" stroke-width="5"/>'),
    gem: svg('<path d="M16 8 L48 8 L60 24 L32 58 L4 24Z" fill="#40d6c8" stroke="#137a72" stroke-width="3"/><path d="M4 24 L60 24 M16 8 L24 24 L32 58 L40 24 L48 8" stroke="#137a72" stroke-width="2" fill="none"/>'),
    key: svg('<circle cx="18" cy="32" r="12" fill="none" stroke="#f5c542" stroke-width="6"/><path d="M30 32 L60 32 M50 32 L50 42 M58 32 L58 40" stroke="#f5c542" stroke-width="6"/>'),
    potion: svg('<path d="M24 6 L40 6 L40 20 C52 26 54 40 48 50 C42 60 22 60 16 50 C10 40 12 26 24 20Z" fill="#9b59b6" stroke="#4a235a" stroke-width="3"/><rect x="22" y="2" width="20" height="6" fill="#8d6e63"/>'),
    trophy: svg('<path d="M16 6 H48 V22 C48 34 40 40 32 40 C24 40 16 34 16 22Z" fill="#f5c542" stroke="#b8860b" stroke-width="3"/><path d="M26 40 H38 V50 H26Z M18 50 H46 V58 H18Z" fill="#b8860b"/>'),
    bolt: svg('<path d="M36 2 L10 36 L28 36 L22 62 L54 24 L34 24Z" fill="#ffeb3b" stroke="#f57f17" stroke-width="3"/>'),
  };
  GF.ICONS = ICONS;

  const GUI_OBJECTS = new Set(['Frame', 'ScrollingFrame', 'TextLabel', 'TextButton', 'TextBox', 'ImageLabel', 'ImageButton']);
  const MODIFIERS = new Set(['UICorner', 'UIStroke', 'UIPadding', 'UIListLayout', 'UIGridLayout', 'UIGradient', 'UIAspectRatioConstraint']);
  const FONTS = {
    SourceSans: ['system-ui, "Segoe UI", Roboto, sans-serif', 400], SourceSansBold: ['system-ui, "Segoe UI", Roboto, sans-serif', 700],
    Gotham: ['"Montserrat", system-ui, sans-serif', 500], GothamBold: ['"Montserrat", system-ui, sans-serif', 800],
    Arial: ['Arial, Helvetica, sans-serif', 400], ArialBold: ['Arial, Helvetica, sans-serif', 700],
    Code: ['ui-monospace, "Cascadia Code", Consolas, monospace', 400], Cartoon: ['"Comic Sans MS", "Chalkboard SE", cursive', 700],
    Fantasy: ['Papyrus, fantasy, serif', 700], Arcade: ['"Courier New", monospace', 900],
  };

  const col = (c, t) => (c ? `rgba(${Math.round(c.r * 255)},${Math.round(c.g * 255)},${Math.round(c.b * 255)},${t == null ? 1 : 1 - t})` : 'transparent');
  const ud = (u, axis) => (u ? `calc(${(axis === 'x' ? u.xs : u.ys) * 100}% + ${axis === 'x' ? u.xo : u.yo}px)` : '0px');
  const udim = (u) => (u ? `calc(${u.s * 100}% + ${u.o}px)` : '0px');

  function resolveImage(src, warn) {
    if (!src) return '';
    if (src.startsWith('gf://icons/')) return ICONS[src.slice(11)] || '';
    if (/^https?:\/\//.test(src) || src.startsWith('data:')) return src;
    if (warn) warn('Imagem "' + src + '" não suportada. Use "gf://icons/coin" (heart, star, sword, shield, gem, key, potion, trophy, bolt) ou um endereço http(s) (requer internet).');
    return '';
  }

  class GuiSystem {
    constructor(engine, container) {
      this.engine = engine;
      this.root = document.createElement('div');
      this.root.className = 'gfg-root';
      container.appendChild(this.root);
      this.screen = this.layer('gfg-screen');
      this.bill = this.layer('gfg-bill');
      this.core = this.layer('gfg-core');
      this.els = new Map(); // id -> elemento
      this.guiIds = new Set();
      this.billboards = new Set();
      this.scaled = new Set();
      this.dirty = true;
      this.warned = new Set();
      this.coreEnabled = { Health: true, PlayerList: true, Backpack: true, All: true };
      this.cas = new Map();
      this.prompts = new Map();
      this.bubbles = [];
      this.buildCore();
    }

    layer(cls) {
      const d = document.createElement('div');
      d.className = 'gfg-layer ' + cls;
      this.root.appendChild(d);
      return d;
    }

    warnOnce(msg) {
      if (this.warned.has(msg)) return;
      this.warned.add(msg);
      this.engine.warn(msg);
    }

    // ------------------------------------------------------------------
    isGui(cls) { return GUI_OBJECTS.has(cls) || cls === 'ScreenGui' || cls === 'BillboardGui'; }
    isModifier(cls) { return MODIFIERS.has(cls); }

    onNew(rec) {
      if (this.isGui(rec.cls)) { this.guiIds.add(rec.id); if (rec.cls === 'BillboardGui') this.billboards.add(rec.id); this.dirty = true; }
    }

    onParent(rec) {
      if (this.isGui(rec.cls) || this.isModifier(rec.cls)) this.dirty = true;
      if (this.isModifier(rec.cls)) {
        if (rec._oldParent != null) this.styleId(rec._oldParent);
        if (rec.parent != null) this.styleId(rec.parent);
      }
    }

    onDestroy(rec) {
      const el = this.els.get(rec.id);
      if (el) { el.remove(); this.els.delete(rec.id); }
      this.guiIds.delete(rec.id); this.billboards.delete(rec.id); this.scaled.delete(rec.id);
      if (this.isModifier(rec.cls) && rec.parent != null) this.styleId(rec.parent);
      if (rec.cls === 'ProximityPrompt') this.removePrompt(rec.id);
      this.dirty = true;
    }

    onSet(rec, key) {
      if (this.isGui(rec.cls)) {
        if (key === 'Enabled' || key === 'Adornee') this.dirty = true;
        this.style(rec);
      } else if (this.isModifier(rec.cls) && rec.parent != null) {
        this.styleId(rec.parent);
      }
    }

    styleId(id) {
      const r = this.engine.recs.get(id);
      if (r && this.isGui(r.cls)) {
        this.style(r);
        for (const c of r.children) { const cr = this.engine.recs.get(c); if (cr && GUI_OBJECTS.has(cr.cls)) this.style(cr); }
      }
    }

    modifier(rec, cls) {
      for (const c of rec.children) {
        const r = this.engine.recs.get(c);
        if (r && r.cls === cls) return r;
      }
      return null;
    }

    layoutOf(rec) { return this.modifier(rec, 'UIListLayout') || this.modifier(rec, 'UIGridLayout'); }

    element(rec) {
      let el = this.els.get(rec.id);
      if (el) return el;
      const cls = rec.cls;
      el = document.createElement(cls === 'TextBox' ? 'div' : 'div');
      el.className = 'gfg-el gfg-' + cls;
      el.dataset.id = rec.id;
      el.inner = document.createElement('div');
      el.inner.className = 'gfg-inner';
      if (cls === 'TextLabel' || cls === 'TextButton') {
        el.text = document.createElement('span');
        el.text.className = 'gfg-text';
        el.appendChild(el.text);
      } else if (cls === 'TextBox') {
        el.input = document.createElement('input');
        el.input.className = 'gfg-input';
        el.input.type = 'text';
        el.input.addEventListener('input', () => { rec.props.Text = el.input.value; this.engine.queueEvent('gui_text', rec.id, el.input.value); });
        el.input.addEventListener('focus', () => {
          if (rec.props.ClearTextOnFocus) { el.input.value = ''; rec.props.Text = ''; this.engine.queueEvent('gui_text', rec.id, ''); }
          this.engine.typing = true; this.engine.queueEvent('gui_focus', rec.id, true);
        });
        el.input.addEventListener('blur', () => { this.engine.typing = false; this.engine.queueEvent('gui_focus', rec.id, false, el._enter === true); el._enter = false; });
        el.input.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') { el._enter = true; el.input.blur(); } });
        el.input.addEventListener('keyup', (e) => e.stopPropagation());
        el.appendChild(el.input);
      } else if (cls === 'ImageLabel' || cls === 'ImageButton') {
        el.img = document.createElement('div');
        el.img.className = 'gfg-img';
        el.appendChild(el.img);
      }
      el.appendChild(el.inner);
      if (cls === 'TextButton' || cls === 'ImageButton') {
        el.classList.add('gfg-btn');
        el.addEventListener('pointerdown', (e) => { e.stopPropagation(); this.engine.queueEvent('gui_down', rec.id); });
        el.addEventListener('pointerup', (e) => { e.stopPropagation(); this.engine.queueEvent('gui_up', rec.id); });
        el.addEventListener('click', (e) => { e.stopPropagation(); this.engine.audio.ensure(); this.engine.queueEvent('gui_click', rec.id); });
      }
      if (GUI_OBJECTS.has(cls)) {
        el.addEventListener('pointerenter', () => this.engine.queueEvent('gui_hover', rec.id, true));
        el.addEventListener('pointerleave', () => this.engine.queueEvent('gui_hover', rec.id, false));
      }
      if (cls === 'ScrollingFrame') { el.classList.add('gfg-scroll'); el.addEventListener('pointerdown', (e) => e.stopPropagation()); el.addEventListener('wheel', (e) => e.stopPropagation()); }
      this.els.set(rec.id, el);
      this.style(rec);
      return el;
    }

    style(rec) {
      const el = this.els.get(rec.id);
      if (!el) return;
      const p = rec.props, s = el.style;
      if (rec.cls === 'ScreenGui') {
        s.left = s.top = s.right = s.bottom = '0';
        s.display = p.Enabled === false ? 'none' : '';
        s.zIndex = String(10 + (p.DisplayOrder || 0));
        return;
      }
      if (rec.cls === 'BillboardGui') {
        s.display = p.Enabled === false ? 'none' : '';
        s.width = (p.Size ? p.Size.xo : 200) + 'px';
        s.height = (p.Size ? p.Size.yo : 50) + 'px';
        el._scaleW = p.Size ? p.Size.xs : 0; el._scaleH = p.Size ? p.Size.ys : 0;
        return;
      }
      const parent = this.engine.recs.get(rec.parent);
      const inLayout = parent && this.layoutOf(parent);
      const ar = this.modifier(rec, 'UIAspectRatioConstraint');
      s.display = p.Visible === false ? 'none' : '';
      if (inLayout) {
        s.position = 'relative'; s.left = ''; s.top = ''; s.transform = p.Rotation ? `rotate(${p.Rotation}deg)` : '';
        s.flex = '0 0 auto';
        if (inLayout.cls === 'UIGridLayout') { s.width = ''; s.height = ''; }
        else { s.width = ud(p.Size, 'x'); s.height = ar ? 'auto' : ud(p.Size, 'y'); }
        // ordem
        const sortName = inLayout.props.SortOrder === 'Name';
        s.order = sortName ? '0' : String(Math.round(p.LayoutOrder || 0));
      } else {
        s.position = 'absolute';
        s.order = '';
        s.left = ud(p.Position, 'x'); s.top = ud(p.Position, 'y');
        s.width = ud(p.Size, 'x'); s.height = ar ? 'auto' : ud(p.Size, 'y');
        const a = p.AnchorPoint || { x: 0, y: 0 };
        s.transform = `translate(${-a.x * 100}%, ${-a.y * 100}%)` + (p.Rotation ? ` rotate(${p.Rotation}deg)` : '');
      }
      s.aspectRatio = ar ? String(ar.props.AspectRatio || 1) : '';
      s.zIndex = String(p.ZIndex || 1);
      const grad = this.modifier(rec, 'UIGradient');
      const bt = p.BackgroundTransparency == null ? 0 : p.BackgroundTransparency;
      if (grad && grad.props.Color) {
        const c = grad.props.Color;
        s.background = bt >= 1 ? 'transparent' : `linear-gradient(${(grad.props.Rotation || 0) + 90}deg, ${col(c.a, bt)}, ${col(c.b, bt)})`;
      } else {
        s.background = bt >= 1 ? 'transparent' : col(p.BackgroundColor3, bt);
      }
      const corner = this.modifier(rec, 'UICorner');
      s.borderRadius = corner ? udim(corner.props.CornerRadius) : '';
      const stroke = this.modifier(rec, 'UIStroke');
      const textOnly = bt >= 1 && el.text;
      if (stroke && !textOnly) { s.outline = `${stroke.props.Thickness || 1}px solid ${col(stroke.props.Color, stroke.props.Transparency)}`; s.outlineOffset = `-${stroke.props.Thickness || 1}px`; }
      else s.outline = '';
      s.border = !stroke && (p.BorderSizePixel || 0) > 0 && bt < 1 ? `${p.BorderSizePixel}px solid ${col(p.BorderColor3)}` : 'none';
      s.overflow = p.ClipsDescendants || rec.cls === 'ScrollingFrame' ? (rec.cls === 'ScrollingFrame' ? 'auto' : 'hidden') : 'visible';
      // padding / layout no container interno
      const pad = this.modifier(rec, 'UIPadding');
      const is = el.inner.style;
      const padv = (u) => udim(u);
      if (pad) { is.top = padv(pad.props.PaddingTop); is.bottom = padv(pad.props.PaddingBottom); is.left = padv(pad.props.PaddingLeft); is.right = padv(pad.props.PaddingRight); }
      else { is.top = is.bottom = is.left = is.right = '0px'; }
      if (rec.cls === 'ScrollingFrame') {
        const cs = p.CanvasSize || { xs: 0, xo: 0, ys: 2, yo: 0 };
        is.right = ''; is.bottom = '';
        is.width = `calc(${(cs.xs || 1) * 100}% + ${cs.xo}px)`; is.height = `calc(${cs.ys * 100}% + ${cs.yo}px)`;
        if (!cs.xs && !cs.xo) is.width = '100%';
        s.setProperty('--sb', (p.ScrollBarThickness == null ? 8 : p.ScrollBarThickness) + 'px');
      }
      const lay = this.layoutOf(rec);
      if (lay && lay.cls === 'UIListLayout') {
        const lp = lay.props;
        const horiz = lp.FillDirection === 'Horizontal';
        is.display = 'flex'; is.flexDirection = horiz ? 'row' : 'column'; is.gridTemplateColumns = '';
        is.gap = udim(lp.Padding);
        const ha = { Left: 'flex-start', Center: 'center', Right: 'flex-end' }[lp.HorizontalAlignment] || 'flex-start';
        const va = { Top: 'flex-start', Center: 'center', Bottom: 'flex-end' }[lp.VerticalAlignment] || 'flex-start';
        is.justifyContent = horiz ? ha : va; is.alignItems = horiz ? va : ha;
      } else if (lay && lay.cls === 'UIGridLayout') {
        const cs = lay.props.CellSize || { xs: 0, xo: 100, ys: 0, yo: 100 }, cp = lay.props.CellPadding || { xs: 0, xo: 5, ys: 0, yo: 5 };
        is.display = 'grid'; is.flexDirection = '';
        is.gridTemplateColumns = `repeat(auto-fill, ${ud(cs, 'x')})`; is.gridAutoRows = ud(cs, 'y');
        is.gap = `${ud(cp, 'y')} ${ud(cp, 'x')}`; is.justifyContent = ''; is.alignItems = '';
      } else {
        is.display = ''; is.gap = ''; is.gridTemplateColumns = ''; is.flexDirection = '';
      }
      // texto
      if (el.text || el.input) {
        const f = FONTS[p.Font] || FONTS.SourceSans;
        const target = el.text || el.input;
        const ts = target.style;
        ts.fontFamily = f[0]; ts.fontWeight = String(f[1]);
        ts.color = col(p.TextColor3, p.TextTransparency);
        const xa = { Left: 'flex-start', Center: 'center', Right: 'flex-end' }[p.TextXAlignment] || 'center';
        const ya = { Top: 'flex-start', Center: 'center', Bottom: 'flex-end' }[p.TextYAlignment] || 'center';
        s.setProperty('--tx', xa); s.setProperty('--ty', ya);
        ts.textAlign = p.TextXAlignment === 'Left' ? 'left' : p.TextXAlignment === 'Right' ? 'right' : 'center';
        ts.whiteSpace = p.TextWrapped || p.TextScaled ? 'normal' : 'pre';
        if (stroke && textOnly) ts.webkitTextStroke = `${Math.min(3, stroke.props.Thickness || 1)}px ${col(stroke.props.Color, stroke.props.Transparency)}`;
        else ts.webkitTextStroke = '';
        if (p.TextScaled) { this.scaled.add(rec.id); el._scaleKey = ''; } else { this.scaled.delete(rec.id); ts.fontSize = (p.TextSize || 14) + 'px'; }
        if (el.text) {
          const t = p.Text == null ? '' : String(p.Text);
          if (p.RichText) el.text.innerHTML = this.rich(t); else el.text.textContent = t;
        } else {
          if (el.input.value !== (p.Text || '')) el.input.value = p.Text || '';
          el.input.placeholder = p.PlaceholderText || '';
        }
      }
      if (el.img) {
        const url = resolveImage(p.Image || '', (m) => this.warnOnce(m));
        const is2 = el.img.style;
        is2.backgroundImage = url ? `url("${url}")` : '';
        is2.backgroundSize = { Fit: 'contain', Crop: 'cover', Tile: 'auto', Stretch: '100% 100%' }[p.ScaleType] || '100% 100%';
        is2.backgroundRepeat = p.ScaleType === 'Tile' ? 'repeat' : 'no-repeat';
        is2.opacity = String(1 - (p.ImageTransparency || 0));
        if (p.Image && /^https?:/.test(p.Image)) this.warnOnce('Imagens por endereço http(s) dependem de conexão com a internet.');
      }
    }

    rich(t) {
      // suporte a <b>, <i>, <u>, <font color="#hex">, <br>
      let h = GF.escapeHtml(t);
      h = h.replace(/&lt;(\/?)(b|i|u|s)&gt;/g, '<$1$2>').replace(/&lt;br\s*\/?&gt;/g, '<br>');
      h = h.replace(/&lt;font color=&quot;(#[0-9a-fA-F]{3,8}|[a-z]+)&quot;&gt;/g, '<span style="color:$1">').replace(/&lt;\/font&gt;/g, '</span>');
      return h;
    }

    // reorganiza árvore DOM conforme a hierarquia
    reconcile() {
      this.dirty = false;
      const recs = this.engine.recs;
      const pgId = this.engine.playerGuiId;
      const order = [];
      for (const id of this.guiIds) order.push(id);
      order.sort((a, b) => a - b);
      for (const id of order) {
        const rec = recs.get(id);
        if (!rec) continue;
        const parent = rec.parent != null ? recs.get(rec.parent) : null;
        let target = null;
        if (rec.cls === 'ScreenGui') {
          if (parent && rec.parent === pgId) target = this.screen;
        } else if (rec.cls === 'BillboardGui') {
          const adorn = this.adornee(rec);
          if (adorn && adorn.inWorld && (rec.parent === pgId || this.engine.isDescendantOfWorld(rec))) target = this.bill;
        } else if (parent && this.isGui(parent.cls)) {
          const pel = this.els.get(parent.id);
          if (pel && pel.isConnected) target = pel.inner;
        }
        if (target) {
          const el = this.element(rec);
          if (el.parentNode !== target) { target.appendChild(el); this.style(rec); }
        } else {
          const el = this.els.get(id);
          if (el && el.parentNode) el.remove();
        }
      }
      // uma segunda passada garante filhos de pais recém-anexados
      for (const id of order) {
        const rec = recs.get(id);
        if (!rec || !GUI_OBJECTS.has(rec.cls)) continue;
        const parent = rec.parent != null ? recs.get(rec.parent) : null;
        const pel = parent && this.els.get(parent.id);
        if (pel && pel.isConnected) {
          const el = this.element(rec);
          if (el.parentNode !== pel.inner) { pel.inner.appendChild(el); this.style(rec); }
        }
      }
      // ordenação por nome nos layouts
      for (const id of order) {
        const rec = recs.get(id);
        const lay = rec && this.layoutOf(rec);
        if (lay && lay.props.SortOrder === 'Name') {
          const kids = rec.children.map((c) => recs.get(c)).filter((r) => r && GUI_OBJECTS.has(r.cls)).sort((a, b) => String(a.props.Name).localeCompare(String(b.props.Name)));
          kids.forEach((k, i) => { const e = this.els.get(k.id); if (e) e.style.order = String(i); });
        }
      }
    }

    adornee(rec) {
      const recs = this.engine.recs;
      if (rec.props.Adornee != null) return recs.get(rec.props.Adornee);
      const p = rec.parent != null ? recs.get(rec.parent) : null;
      if (p && p.part) return p;
      if (p && p.cls === 'Model' && p.props.PrimaryPart != null) return recs.get(p.props.PrimaryPart);
      return null;
    }

    call(rec, method) {
      const el = this.els.get(rec.id);
      const vp = this.root.getBoundingClientRect();
      if (method === 'AbsoluteSize') {
        if (!el || !el.isConnected) return [0, 0];
        const r = el.getBoundingClientRect();
        return [r.width, r.height];
      }
      if (method === 'AbsolutePosition') {
        if (!el || !el.isConnected) return [0, 0];
        const r = el.getBoundingClientRect();
        return [r.left - vp.left, r.top - vp.top];
      }
      if (method === 'Focus') { if (el && el.input) el.input.focus(); return []; }
      if (method === 'Blur') { if (el && el.input) el.input.blur(); return []; }
      return [];
    }

    // ------------------------------------------------------------------
    // Interface padrão
    buildCore() {
      const c = this.core;
      c.innerHTML = `
        <div class="gfg-health" hidden><div class="gfg-health-fill"></div><span></span></div>
        <div class="gfg-board" hidden></div>
        <div class="gfg-hotbar" hidden></div>
        <div class="gfg-toasts"></div>
        <div class="gfg-prompts"></div>
        <div class="gfg-bubbles"></div>
        <div class="gfg-cas"></div>
        <div class="gfg-kick" hidden><div><h3>Desconectado</h3><p></p></div></div>`;
      this.hp = c.querySelector('.gfg-health');
      this.board = c.querySelector('.gfg-board');
      this.hotbar = c.querySelector('.gfg-hotbar');
      this.toasts = c.querySelector('.gfg-toasts');
      this.promptLayer = c.querySelector('.gfg-prompts');
      this.bubbleLayer = c.querySelector('.gfg-bubbles');
      this.casLayer = c.querySelector('.gfg-cas');
      this.kickEl = c.querySelector('.gfg-kick');
      this.hotbarKey = '';
      this.boardKey = '';
    }

    notify(title, text, dur) {
      const t = document.createElement('div');
      t.className = 'gfg-toast';
      t.innerHTML = (title ? `<b>${GF.escapeHtml(title)}</b>` : '') + `<span>${GF.escapeHtml(text)}</span>`;
      this.toasts.appendChild(t);
      while (this.toasts.children.length > 4) this.toasts.firstChild.remove();
      setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 400); }, Math.max(0.5, dur || 3) * 1000);
    }

    bubble(partId, text) {
      const el = document.createElement('div');
      el.className = 'gfg-bubble';
      el.textContent = text;
      this.bubbleLayer.appendChild(el);
      // empilha balões da mesma peça
      for (const b of this.bubbles) if (b.partId === partId) b.stack++;
      this.bubbles.push({ partId, el, ttl: 5, stack: 0 });
    }

    coregui(kind, enabled) {
      if (kind === 'All') { this.coreEnabled.Health = this.coreEnabled.PlayerList = this.coreEnabled.Backpack = enabled; }
      this.coreEnabled[kind] = enabled;
    }

    kick(msg) {
      this.kickEl.hidden = false;
      this.kickEl.querySelector('p').textContent = msg;
    }

    casBind(name, touch, keys) {
      this.casUnbind(name);
      if (!touch) return;
      const b = document.createElement('button');
      b.className = 'gfg-casbtn';
      b.textContent = keys ? keys.split(',')[0] : name;
      const down = (e) => { e.preventDefault(); e.stopPropagation(); b.classList.add('on'); this.engine.queueEvent('cas', name, true); };
      const up = (e) => { e.preventDefault(); e.stopPropagation(); if (!b.classList.contains('on')) return; b.classList.remove('on'); this.engine.queueEvent('cas', name, false); };
      b.addEventListener('pointerdown', down);
      b.addEventListener('pointerup', up);
      b.addEventListener('pointerleave', up);
      const idx = this.cas.size;
      b.style.right = 110 + (idx % 3) * 64 + 'px';
      b.style.bottom = 30 + Math.floor(idx / 3) * 64 + 'px';
      this.casLayer.appendChild(b);
      this.cas.set(name, b);
    }
    casUnbind(name) { const b = this.cas.get(name); if (b) { b.remove(); this.cas.delete(name); } }
    casTitle(name, t) { const b = this.cas.get(name); if (b) b.textContent = t; }
    casPosition(name, xs, xo, ys, yo) {
      const b = this.cas.get(name);
      if (b) { b.style.right = ''; b.style.bottom = ''; b.style.left = `calc(${xs * 100}% + ${xo}px)`; b.style.top = `calc(${ys * 100}% + ${yo}px)`; }
    }

    removePrompt(id) { const p = this.prompts.get(id); if (p) { p.el.remove(); this.prompts.delete(id); } }

    triggerPrompt(id) { this.engine.queueEvent('prompt', id); this.engine.audio.oneShot('sfx:click', 0.3); }

    promptKeyDown(code) {
      for (const [id, p] of this.prompts) {
        if (p.visible && p.key === code) {
          const hold = p.rec.props.HoldDuration || 0;
          if (hold <= 0) this.triggerPrompt(id); else p.holding = 0.0001;
          return true;
        }
      }
      return false;
    }
    promptKeyUp(code) { for (const p of this.prompts.values()) if (p.key === code) p.holding = 0; }

    updatePrompts(dt) {
      const eng = this.engine;
      const ch = eng.localCharacter();
      const rootPos = ch && !ch.dead ? ch.feet.clone().add(new THREE.Vector3(0, 3, 0)) : null;
      let best = null, bestD = Infinity;
      for (const id of eng.promptIds) {
        const rec = eng.recs.get(id);
        if (!rec || !rec.inWorld || rec.props.Enabled === false) { this.removePrompt(id); continue; }
        const part = eng.recs.get(rec.parent);
        const pos = part && part.part ? part.part.pos : part && part.cls === 'Model' ? eng.modelCenter(part) : null;
        if (!pos || !rootPos) { this.removePrompt(id); continue; }
        const d = pos.distanceTo(rootPos);
        if (d <= (rec.props.MaxActivationDistance || 10) && d < bestD) { best = { id, rec, pos }; bestD = d; }
      }
      for (const [id, p] of this.prompts) if (!best || best.id !== id) { p.visible = false; p.el.style.display = 'none'; p.holding = 0; }
      if (!best) return;
      let p = this.prompts.get(best.id);
      if (!p) {
        const el = document.createElement('div');
        el.className = 'gfg-prompt';
        el.innerHTML = '<div class="gfg-pkey"><i></i><span></span></div><div class="gfg-ptext"><small></small><b></b></div>';
        el.addEventListener('pointerdown', (e) => {
          e.stopPropagation();
          const hold = best.rec.props.HoldDuration || 0;
          if (hold <= 0) this.triggerPrompt(best.id); else pp.holding = 0.0001;
        });
        el.addEventListener('pointerup', (e) => { e.stopPropagation(); pp.holding = 0; });
        this.promptLayer.appendChild(el);
        const pp = (p = { el, rec: best.rec, visible: true, holding: 0, key: 'E' });
        this.prompts.set(best.id, p);
      }
      p.visible = true;
      const pr = best.rec.props;
      p.key = pr.KeyboardKeyCode || 'E';
      p.el.querySelector('.gfg-pkey span').textContent = eng.isTouch ? 'Toque' : p.key;
      p.el.querySelector('small').textContent = pr.ObjectText || '';
      p.el.querySelector('b').textContent = pr.ActionText || 'Interagir';
      const hold = pr.HoldDuration || 0;
      if (p.holding > 0 && hold > 0) {
        p.holding += dt;
        if (p.holding >= hold) { p.holding = 0; this.triggerPrompt(best.id); }
      }
      p.el.querySelector('.gfg-pkey i').style.height = hold > 0 ? Math.min(100, (p.holding / hold) * 100) + '%' : '0%';
      const sp = eng.project(best.pos);
      if (sp.visible) { p.el.style.display = ''; p.el.style.left = sp.x + 'px'; p.el.style.top = sp.y + 'px'; }
      else p.el.style.display = 'none';
    }

    updateCore(dt) {
      const eng = this.engine;
      const ch = eng.localCharacter();
      // vida
      const showHp = this.coreEnabled.Health && ch && ch.hum;
      this.hp.hidden = !showHp;
      if (showHp) {
        const hp = ch.hum.props.Health == null ? 100 : ch.hum.props.Health, max = ch.hum.props.MaxHealth || 100;
        const f = Math.max(0, Math.min(1, hp / max));
        const fill = this.hp.firstElementChild;
        fill.style.width = f * 100 + '%';
        fill.style.background = f > 0.5 ? '#3fbf5f' : f > 0.25 ? '#e0b33a' : '#e04a4a';
        this.hp.querySelector('span').textContent = Math.ceil(hp) + ' / ' + Math.ceil(max);
      }
      // placar
      const stats = this.coreEnabled.PlayerList ? eng.leaderstats() : null;
      this.board.hidden = !stats || !stats.length;
      if (stats && stats.length) {
        const key = JSON.stringify(stats) + eng.localPlayerName();
        if (key !== this.boardKey) {
          this.boardKey = key;
          this.board.innerHTML = `<table><tr><th>Jogador</th>${stats.map((s) => `<th>${GF.escapeHtml(s.name)}</th>`).join('')}</tr><tr><td>${GF.escapeHtml(eng.localPlayerName())}</td>${stats.map((s) => `<td>${GF.escapeHtml(s.value)}</td>`).join('')}</tr></table>`;
        }
      }
      // mochila
      const tools = this.coreEnabled.Backpack ? eng.toolList() : [];
      this.hotbar.hidden = !tools.length;
      const hk = JSON.stringify(tools);
      if (hk !== this.hotbarKey) {
        this.hotbarKey = hk;
        this.hotbar.innerHTML = '';
        tools.forEach((t, i) => {
          const b = document.createElement('button');
          b.className = 'gfg-slot' + (t.equipped ? ' on' : '');
          const icon = resolveImage(t.icon || '', null);
          b.innerHTML = `<small>${i + 1}</small>` + (icon ? `<img alt="" src="${icon}">` : '') + `<span>${GF.escapeHtml(t.name)}</span>`;
          b.addEventListener('pointerdown', (e) => e.stopPropagation());
          b.addEventListener('click', (e) => { e.stopPropagation(); this.equipSlot(i); });
          this.hotbar.appendChild(b);
        });
      }
      // balões
      this.bubbles = this.bubbles.filter((b) => {
        b.ttl -= dt;
        const rec = eng.recs.get(b.partId);
        const pos = rec && rec.part ? rec.part.pos : null;
        if (b.ttl <= 0 || !pos) { b.el.remove(); return false; }
        const sp = eng.project(pos.clone().add(new THREE.Vector3(0, 2.5, 0)));
        b.el.style.display = sp.visible ? '' : 'none';
        b.el.style.left = sp.x + 'px';
        b.el.style.top = sp.y - b.stack * 34 + 'px';
        b.el.style.opacity = String(Math.min(1, b.ttl));
        return true;
      });
      this.casLayer.style.display = eng.isTouch ? '' : 'none';
      this.updatePrompts(dt);
    }

    equipSlot(i) {
      const tools = this.engine.toolList();
      const t = tools[i];
      if (!t) return;
      this.engine.queueEvent('equip', t.equipped ? null : t.id);
    }

    frame(dt) {
      if (this.dirty) this.reconcile();
      const eng = this.engine;
      // BillboardGui
      for (const id of this.billboards) {
        const el = this.els.get(id);
        if (!el || !el.isConnected) continue;
        const rec = eng.recs.get(id);
        const ad = this.adornee(rec);
        const pos = ad && ad.part ? ad.part.pos : null;
        if (!pos) { el.style.display = 'none'; continue; }
        const off = rec.props.StudsOffset || { x: 0, y: 2, z: 0 };
        const wp = new THREE.Vector3(pos.x + off.x, pos.y + off.y, pos.z + off.z);
        const sp = eng.project(wp);
        const dist = eng.camera.position.distanceTo(wp);
        const maxD = rec.props.MaxDistance || 100;
        if (!sp.visible || dist > maxD || rec.props.Enabled === false) { el.style.display = 'none'; continue; }
        el.style.display = '';
        // escala em studs (Size.Scale) ou pixels fixos (Size.Offset)
        const pxPerStud = eng.pixelsPerStud(wp);
        const w = (el._scaleW || 0) * pxPerStud + (rec.props.Size ? rec.props.Size.xo : 200);
        const h = (el._scaleH || 0) * pxPerStud + (rec.props.Size ? rec.props.Size.yo : 50);
        el.style.width = w + 'px'; el.style.height = h + 'px';
        el.style.transform = `translate(${sp.x - w / 2}px, ${sp.y - h / 2}px)`;
        el.style.zIndex = rec.props.AlwaysOnTop ? '5' : String(Math.max(1, 4 - Math.floor(dist / 50)));
      }
      // texto escalado
      for (const id of this.scaled) {
        const el = this.els.get(id);
        if (!el || !el.isConnected) continue;
        const rec = eng.recs.get(id);
        const w = el.clientWidth, h = el.clientHeight;
        const text = String(rec.props.Text || '');
        const k = w + 'x' + h + ':' + text.length;
        if (k === el._scaleKey) continue;
        el._scaleKey = k;
        const lines = Math.max(1, text.split('\n').length);
        const size = Math.max(6, Math.min(h * 0.8 / lines, (w * 1.75) / Math.max(1, text.length / lines), 100));
        (el.text || el.input).style.fontSize = size + 'px';
      }
      this.updateCore(dt);
    }

    reset() {
      this.screen.innerHTML = '';
      this.bill.innerHTML = '';
      this.els.clear(); this.guiIds.clear(); this.billboards.clear(); this.scaled.clear();
      this.prompts.forEach((p) => p.el.remove()); this.prompts.clear();
      this.bubbles.forEach((b) => b.el.remove()); this.bubbles = [];
      this.cas.forEach((b) => b.remove()); this.cas.clear();
      this.toasts.innerHTML = '';
      this.kickEl.hidden = true;
      this.hotbarKey = ''; this.boardKey = '';
      this.coreEnabled = { Health: true, PlayerList: true, Backpack: true, All: true };
      this.warned.clear();
    }

    dispose() { this.reset(); this.root.remove(); }
  }

  GF.GuiSystem = GuiSystem;
  GF.resolveImage = resolveImage;
})();
