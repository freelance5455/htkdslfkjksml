/* GameForge Studio — Ambiente: céu, ciclo dia/noite, iluminação, neblina e clima. */
(function () {
  'use strict';
  const GF = (window.GF = window.GF || {});

  const C = (hex) => new THREE.Color(hex);
  const SKY = {
    night: C(0x070b1d), dawn: C(0xf08a4b), day: C(0x86b9ea), dusk: C(0xe0704a),
    stormDay: C(0x5a6270), stormNight: C(0x0b0d12), fog: C(0xb8bec6), sand: C(0xc9a46a),
  };

  class Environment {
    constructor(scene, quality) {
      this.scene = scene;
      this.hemi = new THREE.HemisphereLight(0xbfd8ff, 0x4a4030, 0.6);
      scene.add(this.hemi);
      this.ambient = new THREE.AmbientLight(0x464646, 0.4);
      scene.add(this.ambient);
      this.sun = new THREE.DirectionalLight(0xfff2dd, 1.2);
      this.sun.castShadow = quality.shadows;
      const sm = quality.shadowMap || 2048;
      this.sun.shadow.mapSize.set(sm, sm);
      const s = 70;
      Object.assign(this.sun.shadow.camera, { left: -s, right: s, top: s, bottom: -s, near: 1, far: 400 });
      this.sun.shadow.bias = -0.0005;
      this.sun.shadow.normalBias = 0.04;
      scene.add(this.sun);
      scene.add(this.sun.target);
      this.flash = 0;

      // sol e lua visíveis
      const sunMat = new THREE.MeshBasicMaterial({ color: 0xfff6d0, fog: false });
      this.sunDisk = new THREE.Mesh(new THREE.SphereGeometry(12, 16, 12), sunMat);
      const moonMat = new THREE.MeshBasicMaterial({ color: 0xdfe6ff, fog: false });
      this.moonDisk = new THREE.Mesh(new THREE.SphereGeometry(8, 16, 12), moonMat);
      scene.add(this.sunDisk, this.moonDisk);

      // estrelas
      const n = 900, pos = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) {
        const u = Math.random() * 2 - 1, th = Math.random() * Math.PI * 2, r = 900;
        const sq = Math.sqrt(1 - u * u);
        pos[i * 3] = r * sq * Math.cos(th); pos[i * 3 + 1] = Math.abs(r * u); pos[i * 3 + 2] = r * sq * Math.sin(th);
      }
      const sg = new THREE.BufferGeometry();
      sg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      this.starMat = new THREE.PointsMaterial({ color: 0xffffff, size: 2, sizeAttenuation: false, transparent: true, opacity: 0, fog: false, depthWrite: false });
      this.stars = new THREE.Points(sg, this.starMat);
      scene.add(this.stars);

      // nuvens simples (planos com textura)
      this.clouds = this.makeClouds();
      scene.add(this.clouds);

      // precipitação
      this.rain = this.makeRain(6000);
      this.snow = this.makeSnow(4000);
      scene.add(this.rain.mesh, this.snow.mesh);
      this.scene.fog = new THREE.Fog(0xb8bec6, 50, 100000);
      this.nextStrike = 5;
      this.state = { skyColor: new THREE.Color() };
    }

    makeClouds() {
      const c = document.createElement('canvas');
      c.width = c.height = 256;
      const g = c.getContext('2d');
      for (let i = 0; i < 40; i++) {
        const x = Math.random() * 256, y = Math.random() * 256, r = 15 + Math.random() * 35;
        const gr = g.createRadialGradient(x, y, 0, x, y, r);
        gr.addColorStop(0, 'rgba(255,255,255,0.55)');
        gr.addColorStop(1, 'rgba(255,255,255,0)');
        g.fillStyle = gr; g.fillRect(0, 0, 256, 256);
      }
      const tex = new THREE.CanvasTexture(c);
      tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(4, 4);
      const mat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0.6, depthWrite: false, fog: false, side: THREE.DoubleSide });
      const mesh = new THREE.Mesh(new THREE.PlaneGeometry(2400, 2400), mat);
      mesh.rotation.x = -Math.PI / 2;
      mesh.position.y = 260;
      mesh.renderOrder = -1;
      this.cloudTex = tex;
      return mesh;
    }

    makeRain(n) {
      const pos = new Float32Array(n * 6);
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      const mat = new THREE.LineBasicMaterial({ color: 0xaac4e0, transparent: true, opacity: 0.55 });
      const mesh = new THREE.LineSegments(geo, mat);
      mesh.frustumCulled = false;
      const drops = [];
      for (let i = 0; i < n; i++) drops.push({ x: (Math.random() - 0.5) * 120, y: Math.random() * 70, z: (Math.random() - 0.5) * 120, s: 70 + Math.random() * 40 });
      return { mesh, geo, pos, drops, n };
    }

    makeSnow(n) {
      const pos = new Float32Array(n * 3);
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      const mat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.45, map: GF.particleTexture('snow'), transparent: true, depthWrite: false });
      const mesh = new THREE.Points(geo, mat);
      mesh.frustumCulled = false;
      const flakes = [];
      for (let i = 0; i < n; i++) flakes.push({ x: (Math.random() - 0.5) * 120, y: Math.random() * 60, z: (Math.random() - 0.5) * 120, s: 4 + Math.random() * 4, ph: Math.random() * 6 });
      return { mesh, geo, pos, flakes, n, mat };
    }

    strike(audio, focus) {
      this.flash = 1;
      const dist = 40 + Math.random() * 200;
      if (audio) setTimeout(() => audio.oneShot('sfx:thunder', 0.7 * (this.thunderVolume == null ? 0.6 : this.thunderVolume) / 0.6), Math.min(3000, dist * 6));
      void focus;
    }

    update(dt, L, W, focus, audio, time) {
      // ---------- tempo do dia ----------
      const clock = ((L.ClockTime == null ? 14 : L.ClockTime) % 24 + 24) % 24;
      const ang = ((clock - 6) / 24) * Math.PI * 2; // 6h nasce, 18h se põe
      const elev = Math.sin(ang);
      const sunDir = new THREE.Vector3(Math.cos(ang), elev, 0.35).normalize();
      const day = THREE.MathUtils.smoothstep(elev, -0.12, 0.25);
      const twilight = Math.max(0, 1 - Math.abs(elev) / 0.3) * (elev > -0.25 ? 1 : 0);

      const type = W.Type || 'Clear';
      const intensity = W.Intensity == null ? 0.5 : W.Intensity;
      const wet = type === 'Rain' ? intensity : type === 'Storm' ? Math.max(0.7, intensity) : 0;
      const overcast = Math.min(1, (type === 'Rain' ? 0.5 + intensity * 0.4 : type === 'Storm' ? 0.95 : type === 'Snow' ? 0.5 : type === 'Fog' ? 0.6 : type === 'Sandstorm' ? 0.5 : 0) + (W.CloudCover || 0) * 0.2);

      // cor do céu
      const sky = this.state.skyColor;
      if (L.AutoSkyColor === false && L.SkyColor) {
        sky.setRGB(L.SkyColor.r, L.SkyColor.g, L.SkyColor.b);
      } else {
        sky.copy(SKY.night).lerp(SKY.day, day);
        const tw = clock < 12 ? SKY.dawn : SKY.dusk;
        sky.lerp(tw, twilight * 0.55);
        const storm = SKY.stormNight.clone().lerp(SKY.stormDay, day);
        sky.lerp(storm, overcast * 0.85);
        if (type === 'Fog') sky.lerp(SKY.fog.clone().multiplyScalar(0.25 + day * 0.75), intensity * 0.8);
        if (type === 'Sandstorm') sky.lerp(SKY.sand.clone().multiplyScalar(0.3 + 0.7 * day), intensity);
      }
      if (this.flash > 0) sky.lerp(new THREE.Color(0xe8eeff), this.flash * 0.8);
      this.scene.background = sky;

      // luzes
      const bright = L.Brightness == null ? 2 : L.Brightness;
      const exposure = Math.pow(2, L.ExposureCompensation || 0);
      const sunVisible = elev > -0.05;
      this.sun.position.copy(focus).addScaledVector(sunVisible ? sunDir : new THREE.Vector3(-sunDir.x, -sunDir.y, sunDir.z), 150);
      this.sun.target.position.copy(focus);
      const moonFactor = sunVisible ? 0 : 0.18;
      this.sun.intensity = (Math.max(0, elev) > 0 ? (0.25 + 0.75 * day) * bright * 0.6 * (1 - overcast * 0.75) : moonFactor * bright * 0.5) * exposure + this.flash * 2;
      this.sun.color.set(sunVisible ? 0xfff0d8 : 0x9fb4ff).lerp(new THREE.Color(0xff9a5a), twilight * 0.6 * (sunVisible ? 1 : 0));
      this.sun.castShadow = this.shadowsEnabled !== false && L.GlobalShadows !== false;

      const amb = L.Ambient || { r: 0.27, g: 0.27, b: 0.27 };
      const out = L.OutdoorAmbient || { r: 0.5, g: 0.5, b: 0.5 };
      this.ambient.color.setRGB(amb.r, amb.g, amb.b);
      this.ambient.intensity = 0.7 * exposure;
      this.hemi.color.setRGB(out.r, out.g, out.b).lerp(sky, 0.5);
      this.hemi.intensity = (0.25 + 0.75 * day) * (0.4 + bright * 0.2) * exposure + this.flash;
      this.flash = Math.max(0, this.flash - dt * 4);

      // sol/lua/estrelas
      this.sunDisk.position.copy(focus).addScaledVector(sunDir, 800);
      this.sunDisk.visible = elev > -0.1 && overcast < 0.8;
      this.moonDisk.position.copy(focus).addScaledVector(sunDir, -800);
      this.moonDisk.visible = elev < 0.1 && overcast < 0.8;
      this.starMat.opacity = (1 - day) * (1 - overcast) * 0.9;
      this.stars.position.copy(focus);
      this.clouds.position.x = focus.x; this.clouds.position.z = focus.z;
      this.cloudTex.offset.x += dt * 0.002 * (W.WindSpeed || 4);
      this.clouds.material.opacity = 0.25 + overcast * 0.6 + (W.CloudCover || 0) * 0.3;
      this.clouds.material.color.copy(sky).lerp(new THREE.Color(1, 1, 1), 0.5 * day * (1 - overcast));

      // neblina
      const fog = this.scene.fog;
      let fogStart = L.FogStart || 0, fogEnd = L.FogEnd == null ? 100000 : L.FogEnd;
      const lf = L.FogColor;
      if (fogEnd < 100000 && lf) fog.color.setRGB(lf.r, lf.g, lf.b); else fog.color.copy(sky);
      if (type === 'Fog') { fogEnd = Math.min(fogEnd, 260 - 230 * intensity * (W.FogDensity == null ? 0.5 : W.FogDensity) * 1.6); fogStart = 0; fog.color.copy(sky); }
      else if (type === 'Sandstorm') { fogEnd = Math.min(fogEnd, 220 - 170 * intensity); fogStart = 0; fog.color.copy(sky); }
      else if (type === 'Storm' || type === 'Rain') { fogEnd = Math.min(fogEnd, 700 - 450 * wet); }
      else if (type === 'Snow') { fogEnd = Math.min(fogEnd, 600 - 380 * intensity); }
      else if (fogEnd >= 100000) { fogStart = 400; fogEnd = 1600; }
      fog.near = fogStart; fog.far = Math.max(fogStart + 1, fogEnd);

      // vento
      const wd = W.WindDirection || { x: 1, y: 0, z: 0.3 };
      const ws = W.WindSpeed == null ? 4 : W.WindSpeed;
      const wl = Math.hypot(wd.x, wd.z) || 1;
      const wx = (wd.x / wl) * ws, wz = (wd.z / wl) * ws;

      // chuva
      const rainOn = wet > 0 || type === 'Sandstorm';
      this.rain.mesh.visible = rainOn;
      if (rainOn) {
        const r = this.rain, sand = type === 'Sandstorm';
        const count = Math.floor(r.n * (sand ? intensity * 0.7 : wet));
        r.mesh.material.color.set(sand ? 0xd8b67a : 0xaac4e0);
        r.mesh.material.opacity = sand ? 0.5 : 0.35 + wet * 0.3;
        for (let i = 0; i < count; i++) {
          const d = r.drops[i];
          const vy = sand ? -3 : -d.s;
          const vx = sand ? ws * 3 + 20 : wx * 1.5, vz = sand ? wz * 3 : wz * 1.5;
          d.y += vy * dt; d.x += vx * dt; d.z += vz * dt;
          if (d.y < -5 || Math.abs(d.x) > 60 || Math.abs(d.z) > 60) {
            d.y = sand ? Math.random() * 30 : 60 + Math.random() * 15;
            d.x = (Math.random() - 0.5) * 120; d.z = (Math.random() - 0.5) * 120;
          }
          const k = i * 6, len = sand ? 0.6 : 1.6;
          const bx = focus.x + d.x, by = focus.y + d.y - 15, bz = focus.z + d.z;
          r.pos[k] = bx; r.pos[k + 1] = by; r.pos[k + 2] = bz;
          r.pos[k + 3] = bx - (vx / 60) * len * 2; r.pos[k + 4] = by - (vy / 60) * len; r.pos[k + 5] = bz - (vz / 60) * len * 2;
        }
        r.geo.setDrawRange(0, count * 2);
        r.geo.attributes.position.needsUpdate = true;
      }

      // neve
      const snowOn = type === 'Snow';
      this.snow.mesh.visible = snowOn;
      if (snowOn) {
        const s = this.snow;
        const count = Math.floor(s.n * intensity);
        for (let i = 0; i < count; i++) {
          const f = s.flakes[i];
          f.ph += dt;
          f.y -= f.s * dt; f.x += (wx * 0.8 + Math.sin(f.ph) * 0.8) * dt; f.z += (wz * 0.8 + Math.cos(f.ph * 0.7) * 0.8) * dt;
          if (f.y < -5 || Math.abs(f.x) > 60 || Math.abs(f.z) > 60) { f.y = 50 + Math.random() * 10; f.x = (Math.random() - 0.5) * 120; f.z = (Math.random() - 0.5) * 120; }
          s.pos[i * 3] = focus.x + f.x; s.pos[i * 3 + 1] = focus.y + f.y - 12; s.pos[i * 3 + 2] = focus.z + f.z;
        }
        s.geo.setDrawRange(0, count);
        s.geo.attributes.position.needsUpdate = true;
      }

      // relâmpagos
      if (type === 'Storm' && W.Lightning !== false) {
        this.nextStrike -= dt;
        if (this.nextStrike <= 0) {
          this.thunderVolume = W.ThunderVolume;
          this.strike(audio, focus);
          this.nextStrike = 3 + Math.random() * (12 - intensity * 8);
        }
      }

      // som ambiente
      if (audio) {
        const rv = W.RainVolume == null ? 0.4 : W.RainVolume;
        audio.setAmbient('ambient:rain', rainOn && type !== 'Sandstorm' ? wet * rv : 0);
        audio.setAmbient('ambient:wind', (type === 'Storm' || type === 'Sandstorm' || type === 'Snow') ? 0.25 * intensity + 0.02 * ws : 0);
      }
      void time;
      return { sky, day };
    }

    dispose() {
      [this.hemi, this.ambient, this.sun, this.sun.target, this.sunDisk, this.moonDisk, this.stars, this.clouds, this.rain.mesh, this.snow.mesh].forEach((o) => this.scene.remove(o));
    }
  }

  GF.Environment = Environment;
})();
