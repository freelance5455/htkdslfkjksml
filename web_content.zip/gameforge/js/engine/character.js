/* GameForge Studio — Personagens: modelo 3D articulado e animações procedurais. */
(function () {
  'use strict';
  const GF = (window.GF = window.GF || {});

  // Duração (s) das animações embutidas
  const ANIMS = { Idle: 2, Walk: 1, Run: 0.7, Jump: 0.6, Wave: 2, Dance: 4, Point: 1.5, Cheer: 2, Sit: 1, Punch: 0.5, Spin: 1, Kick: 0.6, Climb: 1, Swim: 1.5 };

  let faceTex = null;
  function faceTexture() {
    if (faceTex) return faceTex;
    const c = document.createElement('canvas');
    c.width = c.height = 64;
    const g = c.getContext('2d');
    g.fillStyle = '#fff'; g.fillRect(0, 0, 64, 64);
    g.fillStyle = '#1b1b1b';
    g.beginPath(); g.ellipse(22, 26, 4, 6, 0, 0, 7); g.fill();
    g.beginPath(); g.ellipse(42, 26, 4, 6, 0, 0, 7); g.fill();
    g.strokeStyle = '#1b1b1b'; g.lineWidth = 3; g.lineCap = 'round';
    g.beginPath(); g.arc(32, 36, 12, 0.2 * Math.PI, 0.8 * Math.PI); g.stroke();
    faceTex = new THREE.CanvasTexture(c);
    faceTex.colorSpace = THREE.SRGBColorSpace;
    return faceTex;
  }

  function labelSprite(text, sub) {
    const c = document.createElement('canvas');
    c.width = 256; c.height = 64;
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), depthTest: true, transparent: true }));
    sp.scale.set(5, 1.25, 1);
    sp.userData.canvas = c;
    sp.userData.draw = function (name, health) {
      const g = c.getContext('2d');
      g.clearRect(0, 0, 256, 64);
      g.font = 'bold 26px system-ui, sans-serif';
      g.textAlign = 'center';
      g.lineWidth = 5; g.strokeStyle = 'rgba(0,0,0,0.65)'; g.strokeText(name, 128, 28);
      g.fillStyle = '#fff'; g.fillText(name, 128, 28);
      if (health != null && health < 1) {
        g.fillStyle = 'rgba(0,0,0,0.6)'; g.fillRect(48, 40, 160, 12);
        g.fillStyle = health > 0.5 ? '#3ad35a' : health > 0.2 ? '#e8c22f' : '#e04545';
        g.fillRect(50, 42, 156 * Math.max(0, health), 8);
      }
      sp.material.map.needsUpdate = true;
    };
    sp.userData.draw(text, sub);
    return sp;
  }

  class CharacterRig {
    constructor(scene, opts) {
      this.scene = scene;
      this.group = new THREE.Group();
      const std = (c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.6 });
      this.skinMat = std(0xffcc99);
      this.shirtMat = std(0x0d69ac);
      this.pantsMat = std(0x27462d);
      const box = (w, h, d) => new THREE.BoxGeometry(w, h, d);
      const mk = (geo, mat) => { const m = new THREE.Mesh(geo, mat); m.castShadow = true; m.receiveShadow = true; return m; };

      this.hips = new THREE.Group(); this.hips.position.y = 2; this.group.add(this.hips);
      this.torso = mk(box(2, 2, 1), this.shirtMat); this.torso.position.y = 1; this.hips.add(this.torso);
      // cabeça com rosto
      const headMats = [this.skinMat, this.skinMat, this.skinMat, this.skinMat, this.skinMat, new THREE.MeshStandardMaterial({ map: faceTexture(), roughness: 0.6 })];
      this.faceMat = headMats[5];
      this.neck = new THREE.Group(); this.neck.position.y = 2; this.hips.add(this.neck);
      // a face fica em -Z (frente do personagem): BoxGeometry índice 5 = -Z
      this.head = mk(box(1.2, 1.2, 1.2), headMats); this.head.position.y = 0.6; this.neck.add(this.head);
      const limb = (x, y, mat, len) => {
        const pivot = new THREE.Group(); pivot.position.set(x, y, 0);
        const m = mk(box(1, len, 1), mat); m.position.y = -len / 2; pivot.add(m);
        this.hips.add(pivot);
        return { pivot, mesh: m };
      };
      this.lArm = limb(-1.5, 1.95, this.skinMat, 2);
      this.rArm = limb(1.5, 1.95, this.skinMat, 2);
      // mangas
      const sleeve = (arm) => { const s = mk(box(1.02, 0.8, 1.02), this.shirtMat); s.position.y = -0.4; arm.pivot.add(s); };
      sleeve(this.lArm); sleeve(this.rArm);
      this.lLeg = limb(-0.5, 0, this.pantsMat, 2);
      this.rLeg = limb(0.5, 0, this.pantsMat, 2);
      this.hand = new THREE.Group(); this.hand.position.set(0, -1.9, -0.2); this.rArm.pivot.add(this.hand);
      this.meshes = [this.torso, this.head, this.lArm.mesh, this.rArm.mesh, this.lLeg.mesh, this.rLeg.mesh];
      scene.add(this.group);
      this.phase = 0;
      this.tracks = new Map(); // id -> {name, t, looped, speed}
      this.label = null;
      if (opts && opts.label) {
        this.label = labelSprite(opts.label, 1);
        this.label.position.y = 6.2;
        this.group.add(this.label);
      }
      this.labelState = '';
      this.dead = false;
      this.debris = [];
    }

    setColors(body, shirt, pants) {
      if (body) this.skinMat.color.setRGB(body.r, body.g, body.b);
      if (shirt) this.shirtMat.color.setRGB(shirt.r, shirt.g, shirt.b);
      if (pants) this.pantsMat.color.setRGB(pants.r, pants.g, pants.b);
      if (body) this.faceMat.color.setRGB(body.r, body.g, body.b);
    }

    setLabel(name, health) {
      if (!this.label) return;
      const key = name + '|' + Math.round(health * 50);
      if (key !== this.labelState) { this.labelState = key; this.label.userData.draw(name, health); }
    }

    setVisible(v) { this.meshes.forEach((m) => (m.visible = v)); this.lArm.pivot.children.forEach((c) => (c.visible = v)); this.rArm.pivot.children.forEach((c) => { if (c !== this.hand) c.visible = v; }); }

    play(id, name, looped, speed) {
      if (!(name in ANIMS)) return false;
      this.tracks.set(id, { name, t: 0, looped, speed: speed || 1 });
      return true;
    }
    stop(id) { this.tracks.delete(id); }
    speed(id, s) { const t = this.tracks.get(id); if (t) t.speed = s; }

    // Atualiza pose. state: {speed, walkSpeed, onGround, vy, sitting}
    animate(dt, state, onTrackEnd) {
      if (this.dead) { this.updateDebris(dt); return; }
      const sp = state.speed;
      const moving = sp > 0.5;
      const running = sp > 20;
      this.phase += dt * (moving ? Math.max(4, sp * 0.55) : 2);
      let la = { x: 0, z: 0 }, ra = { x: 0, z: 0 }, ll = 0, rl = 0, bob = 0, yaw = 0, tilt = 0, headY = 0;
      if (!state.onGround) {
        la = { x: Math.PI * 0.95, z: -0.15 }; ra = { x: Math.PI * 0.95, z: 0.15 };
        ll = 0.15; rl = -0.15;
      } else if (moving) {
        const amp = running ? 1.0 : 0.8;
        const s = Math.sin(this.phase);
        ll = s * amp; rl = -s * amp;
        la.x = -s * amp * 0.9; ra.x = s * amp * 0.9;
        bob = Math.abs(Math.cos(this.phase)) * 0.15;
      } else {
        const s = Math.sin(this.phase * 0.8) * 0.04;
        la = { x: s, z: -0.04 }; ra = { x: -s, z: 0.04 };
      }
      let sit = false;
      for (const [id, tr] of this.tracks) {
        const len = ANIMS[tr.name];
        tr.t += dt * tr.speed;
        let t = tr.t;
        if (t >= len) {
          if (tr.looped) { tr.t %= len; t = tr.t; }
          else { this.tracks.delete(id); onTrackEnd && onTrackEnd(id); continue; }
        }
        const k = t / len;
        const env = Math.min(1, Math.min(t, len - t) * 6 + (tr.looped ? 1 : 0));
        switch (tr.name) {
          case 'Wave': ra = { x: 0, z: (2.7 + Math.sin(t * 10) * 0.35) * env }; break;
          case 'Point': ra = { x: (Math.PI / 2) * env, z: 0 }; break;
          case 'Cheer': la = { x: 0, z: -2.8 * env }; ra = { x: 0, z: 2.8 * env }; bob = Math.abs(Math.sin(t * 8)) * 0.4 * env; break;
          case 'Dance': {
            const b = Math.sin(t * 7);
            la = { x: 0, z: -(1.5 + b) }; ra = { x: 0, z: 1.5 - b };
            ll = b * 0.3; rl = -b * 0.3; bob = Math.abs(b) * 0.3; tilt = b * 0.15; headY = b * 0.3;
            break;
          }
          case 'Punch': ra = { x: (Math.PI / 2) * Math.sin(k * Math.PI), z: 0 }; break;
          case 'Kick': rl = -1.4 * Math.sin(k * Math.PI); break;
          case 'Spin': yaw = k * Math.PI * 2; break;
          case 'Sit': sit = true; break;
          case 'Jump': la = { x: Math.PI * 0.9, z: 0 }; ra = { x: Math.PI * 0.9, z: 0 }; bob = Math.sin(k * Math.PI) * 1.2; break;
          case 'Climb': la.x = Math.PI * 0.9 + Math.sin(t * 8) * 0.3; ra.x = Math.PI * 0.9 - Math.sin(t * 8) * 0.3; break;
          case 'Swim': la = { x: Math.PI * 0.6 + Math.sin(t * 5), z: 0 }; ra = { x: Math.PI * 0.6 - Math.sin(t * 5), z: 0 }; tilt = 0.4; break;
          case 'Walk': { const s = Math.sin(t * 8); ll = s * 0.8; rl = -s * 0.8; la.x = -s * 0.7; ra.x = s * 0.7; break; }
          case 'Run': { const s = Math.sin(t * 12); ll = s; rl = -s; la.x = -s; ra.x = s; break; }
          default: break;
        }
      }
      if (state.sitting || sit) { ll = Math.PI / 2; rl = Math.PI / 2; bob = -1; }
      const lerp = (a, b) => a + (b - a) * Math.min(1, dt * 14);
      this.lArm.pivot.rotation.x = lerp(this.lArm.pivot.rotation.x, la.x);
      this.lArm.pivot.rotation.z = lerp(this.lArm.pivot.rotation.z, la.z);
      this.rArm.pivot.rotation.x = lerp(this.rArm.pivot.rotation.x, ra.x);
      this.rArm.pivot.rotation.z = lerp(this.rArm.pivot.rotation.z, ra.z);
      this.lLeg.pivot.rotation.x = lerp(this.lLeg.pivot.rotation.x, ll);
      this.rLeg.pivot.rotation.x = lerp(this.rLeg.pivot.rotation.x, rl);
      this.hips.position.y = 2 + bob;
      this.hips.rotation.y = yaw;
      this.hips.rotation.z = lerp(this.hips.rotation.z, tilt);
      this.neck.rotation.y = lerp(this.neck.rotation.y, headY);
    }

    die(vel) {
      if (this.dead) return;
      this.dead = true;
      this.group.updateMatrixWorld(true);
      for (const m of this.meshes) {
        const wp = new THREE.Vector3(), wq = new THREE.Quaternion();
        m.getWorldPosition(wp); m.getWorldQuaternion(wq);
        const clone = new THREE.Mesh(m.geometry, Array.isArray(m.material) ? m.material : m.material);
        clone.position.copy(wp); clone.quaternion.copy(wq); clone.castShadow = true;
        this.scene.add(clone);
        const v = new THREE.Vector3((Math.random() - 0.5) * 16, 8 + Math.random() * 10, (Math.random() - 0.5) * 16);
        if (vel) v.add(vel);
        this.debris.push({ mesh: clone, v, w: new THREE.Vector3(Math.random() * 6, Math.random() * 6, Math.random() * 6), ground: wp.y - 50 });
      }
      this.group.visible = false;
    }

    updateDebris(dt, groundAt) {
      for (const d of this.debris) {
        d.v.y -= 60 * dt;
        d.mesh.position.addScaledVector(d.v, dt);
        const gy = this.groundY != null ? this.groundY + 0.5 : -1e9;
        if (d.mesh.position.y < gy) { d.mesh.position.y = gy; d.v.multiplyScalar(0.3); d.v.y = Math.abs(d.v.y) * 0.3; d.w.multiplyScalar(0.5); }
        d.mesh.rotation.x += d.w.x * dt; d.mesh.rotation.y += d.w.y * dt; d.mesh.rotation.z += d.w.z * dt;
      }
      void groundAt;
    }

    dispose() {
      this.scene.remove(this.group);
      for (const d of this.debris) this.scene.remove(d.mesh);
      this.debris = [];
    }
  }

  GF.CharacterRig = CharacterRig;
  GF.ANIMS = ANIMS;
  GF.labelSprite = labelSprite;
})();
