/* GameForge Studio — Sistema de partículas (ParticleEmitter, Fire, Smoke, Sparkles, Explosion). */
(function () {
  'use strict';
  const GF = (window.GF = window.GF || {});

  const texCache = {};
  function particleTexture(kind) {
    if (texCache[kind]) return texCache[kind];
    const c = document.createElement('canvas');
    c.width = c.height = 64;
    const g = c.getContext('2d');
    const grad = (r0, stops) => {
      const gr = g.createRadialGradient(32, 32, 0, 32, 32, r0);
      stops.forEach(([o, col]) => gr.addColorStop(o, col));
      g.fillStyle = gr;
      g.fillRect(0, 0, 64, 64);
    };
    switch (kind) {
      case 'spark':
        grad(32, [[0, 'rgba(255,255,255,1)'], [0.15, 'rgba(255,255,255,0.9)'], [0.4, 'rgba(255,255,255,0.2)'], [1, 'rgba(255,255,255,0)']]);
        break;
      case 'smoke': {
        for (let i = 0; i < 9; i++) {
          const x = 20 + Math.random() * 24, y = 20 + Math.random() * 24, r = 10 + Math.random() * 14;
          const gr = g.createRadialGradient(x, y, 0, x, y, r);
          gr.addColorStop(0, 'rgba(255,255,255,0.35)');
          gr.addColorStop(1, 'rgba(255,255,255,0)');
          g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
        }
        break;
      }
      case 'star': {
        g.fillStyle = '#fff'; g.beginPath();
        for (let i = 0; i < 10; i++) {
          const r = i % 2 ? 12 : 30, a = (i / 10) * Math.PI * 2 - Math.PI / 2;
          g.lineTo(32 + Math.cos(a) * r, 32 + Math.sin(a) * r);
        }
        g.fill();
        break;
      }
      case 'square': g.fillStyle = '#fff'; g.fillRect(12, 12, 40, 40); break;
      case 'snow': grad(32, [[0, 'rgba(255,255,255,1)'], [0.5, 'rgba(255,255,255,0.7)'], [1, 'rgba(255,255,255,0)']]); break;
      default:
        grad(32, [[0, 'rgba(255,255,255,1)'], [0.6, 'rgba(255,255,255,0.6)'], [1, 'rgba(255,255,255,0)']]);
    }
    const t = new THREE.CanvasTexture(c);
    texCache[kind] = t;
    return t;
  }

  const VERT = `
    attribute float size;
    attribute float alpha;
    attribute vec3 pcolor;
    varying float vAlpha;
    varying vec3 vColor;
    uniform float scale;
    void main(){
      vAlpha = alpha; vColor = pcolor;
      vec4 mv = modelViewMatrix * vec4(position,1.0);
      gl_PointSize = size * scale / max(0.1, -mv.z);
      gl_Position = projectionMatrix * mv;
    }`;
  const FRAG = `
    uniform sampler2D map;
    uniform float emission;
    varying float vAlpha;
    varying vec3 vColor;
    void main(){
      vec4 t = texture2D(map, gl_PointCoord);
      gl_FragColor = vec4(vColor * (1.0 + emission), t.a * vAlpha);
      if (gl_FragColor.a < 0.01) discard;
    }`;

  class Emitter {
    constructor(scene, max, texture, additive) {
      this.max = max;
      this.n = 0;
      this.p = []; // partículas
      const geo = new THREE.BufferGeometry();
      this.pos = new Float32Array(max * 3);
      this.size = new Float32Array(max);
      this.alpha = new Float32Array(max);
      this.col = new Float32Array(max * 3);
      geo.setAttribute('position', new THREE.BufferAttribute(this.pos, 3));
      geo.setAttribute('size', new THREE.BufferAttribute(this.size, 1));
      geo.setAttribute('alpha', new THREE.BufferAttribute(this.alpha, 1));
      geo.setAttribute('pcolor', new THREE.BufferAttribute(this.col, 3));
      this.mat = new THREE.ShaderMaterial({
        uniforms: { map: { value: particleTexture(texture) }, scale: { value: 400 }, emission: { value: 0 } },
        vertexShader: VERT, fragmentShader: FRAG,
        transparent: true, depthWrite: false,
        blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
      });
      this.points = new THREE.Points(geo, this.mat);
      this.points.frustumCulled = false;
      this.geo = geo;
      scene.add(this.points);
      this.acc = 0;
      this.cfg = null;
    }
    setTexture(kind) { this.mat.uniforms.map.value = particleTexture(kind); }
    spawn(origin, dir, cfg) {
      if (this.p.length >= this.max) this.p.shift();
      const life = cfg.lifeMin + Math.random() * (cfg.lifeMax - cfg.lifeMin);
      const speed = cfg.speedMin + Math.random() * (cfg.speedMax - cfg.speedMin);
      const sx = THREE.MathUtils.degToRad(cfg.spreadX || 0), sy = THREE.MathUtils.degToRad(cfg.spreadY || 0);
      const d = dir.clone();
      if (sx || sy) {
        const ax = new THREE.Vector3(1, 0, 0), az = new THREE.Vector3(0, 0, 1);
        d.applyAxisAngle(ax, (Math.random() * 2 - 1) * sx);
        d.applyAxisAngle(az, (Math.random() * 2 - 1) * sy);
      }
      this.p.push({ x: origin.x, y: origin.y, z: origin.z, v: d.multiplyScalar(speed), age: 0, life });
    }
    update(dt, cfg, wind) {
      this.cfg = cfg;
      const acc = cfg.acc || { x: 0, y: 0, z: 0 };
      const drag = cfg.drag || 0;
      let n = 0;
      const alive = [];
      for (const q of this.p) {
        q.age += dt;
        if (q.age >= q.life) continue;
        q.v.x += acc.x * dt; q.v.y += acc.y * dt; q.v.z += acc.z * dt;
        if (drag) q.v.multiplyScalar(Math.max(0, 1 - drag * dt));
        q.x += q.v.x * dt; q.y += q.v.y * dt; q.z += q.v.z * dt;
        const t = q.age / q.life;
        this.pos[n * 3] = q.x; this.pos[n * 3 + 1] = q.y; this.pos[n * 3 + 2] = q.z;
        this.size[n] = cfg.size0 + (cfg.size1 - cfg.size0) * t;
        this.alpha[n] = 1 - (cfg.tr0 + (cfg.tr1 - cfg.tr0) * t);
        const c0 = cfg.c0, c1 = cfg.c1;
        this.col[n * 3] = c0.r + (c1.r - c0.r) * t;
        this.col[n * 3 + 1] = c0.g + (c1.g - c0.g) * t;
        this.col[n * 3 + 2] = c0.b + (c1.b - c0.b) * t;
        alive.push(q);
        n++;
      }
      this.p = alive;
      this.n = n;
      this.geo.setDrawRange(0, n);
      this.geo.attributes.position.needsUpdate = true;
      this.geo.attributes.size.needsUpdate = true;
      this.geo.attributes.alpha.needsUpdate = true;
      this.geo.attributes.pcolor.needsUpdate = true;
      this.mat.uniforms.emission.value = cfg.emission || 0;
    }
    dispose(scene) {
      scene.remove(this.points);
      this.geo.dispose();
      this.mat.dispose();
    }
  }

  const FACE_DIR = {
    Top: [0, 1, 0], Bottom: [0, -1, 0], Front: [0, 0, -1], Back: [0, 0, 1], Left: [-1, 0, 0], Right: [1, 0, 0],
  };

  class ParticleSystem {
    constructor(scene) {
      this.scene = scene;
      this.emitters = new Map(); // id -> {em, kind}
      this.bursts = []; // emissores temporários
      this.pixelScale = 400;
    }

    configFor(rec) {
      const p = rec.props;
      const cls = rec.cls;
      if (cls === 'ParticleEmitter') {
        const col = p.Color || { a: { r: 1, g: 1, b: 1 }, b: { r: 1, g: 1, b: 1 } };
        return {
          enabled: p.Enabled !== false, rate: p.Rate == null ? 20 : p.Rate,
          lifeMin: p.Lifetime ? p.Lifetime.min : 1, lifeMax: p.Lifetime ? p.Lifetime.max : 2,
          speedMin: p.Speed ? p.Speed.min : 5, speedMax: p.Speed ? p.Speed.max : 5,
          spreadX: p.SpreadAngle ? p.SpreadAngle.x : 0, spreadY: p.SpreadAngle ? p.SpreadAngle.y : 0,
          size0: p.Size ? p.Size.min : 1, size1: p.Size ? p.Size.max : 1,
          tr0: p.Transparency ? p.Transparency.min : 0, tr1: p.Transparency ? p.Transparency.max : 0,
          c0: col.a, c1: col.b, acc: p.Acceleration || { x: 0, y: 0, z: 0 }, drag: p.Drag || 0,
          emission: p.LightEmission || 0, texture: p.Texture || 'circle', face: p.EmissionDirection || 'Top',
          additive: (p.LightEmission || 0) > 0.5,
        };
      }
      if (cls === 'Fire') {
        const s = p.Size || 5;
        return {
          enabled: p.Enabled !== false, rate: 40, lifeMin: 0.5, lifeMax: 1.0, speedMin: (p.Heat || 9) * 0.6, speedMax: (p.Heat || 9),
          spreadX: 15, spreadY: 15, size0: s * 0.9, size1: s * 0.2, tr0: 0.1, tr1: 1, c0: p.Color || { r: 1, g: 0.55, b: 0.27 }, c1: p.SecondaryColor || { r: 0.55, g: 0.3, b: 0.2 },
          acc: { x: 0, y: 2, z: 0 }, emission: 1, texture: 'spark', face: 'Top', additive: true,
        };
      }
      if (cls === 'Smoke') {
        const s = p.Size || 1;
        return {
          enabled: p.Enabled !== false, rate: 15, lifeMin: 2, lifeMax: 4, speedMin: p.RiseVelocity || 1, speedMax: (p.RiseVelocity || 1) * 2,
          spreadX: 25, spreadY: 25, size0: s * 2, size1: s * 6, tr0: 1 - (p.Opacity == null ? 0.5 : p.Opacity), tr1: 1, c0: p.Color || { r: 1, g: 1, b: 1 }, c1: p.Color || { r: 1, g: 1, b: 1 },
          acc: { x: 0, y: 0.3, z: 0 }, emission: 0, texture: 'smoke', face: 'Top', additive: false,
        };
      }
      if (cls === 'Sparkles') {
        const c = p.SparkleColor || { r: 0.56, g: 0.1, b: 1 };
        return {
          enabled: p.Enabled !== false, rate: 25, lifeMin: 0.6, lifeMax: 1.2, speedMin: 2, speedMax: 4, spreadX: 180, spreadY: 180,
          size0: 0.8, size1: 0.1, tr0: 0, tr1: 0.5, c0: c, c1: { r: 1, g: 1, b: 1 }, acc: { x: 0, y: 0, z: 0 }, emission: 1, texture: 'star', face: 'Top', additive: true,
        };
      }
      return null;
    }

    attach(rec) {
      if (this.emitters.has(rec.id)) return;
      const cfg = this.configFor(rec);
      if (!cfg) return;
      const max = Math.min(1500, Math.max(50, Math.ceil(cfg.rate * cfg.lifeMax * 1.3) + 60));
      const em = new Emitter(this.scene, max, cfg.texture, cfg.additive);
      em.pixelScale = this.pixelScale;
      this.emitters.set(rec.id, { em, rec, texture: cfg.texture, additive: cfg.additive });
    }

    detach(id) {
      const e = this.emitters.get(id);
      if (e) {
        e.em.dispose(this.scene);
        this.emitters.delete(id);
      }
    }

    emit(rec, count, partInfo) {
      this.attach(rec);
      const e = this.emitters.get(rec.id);
      if (!e || !partInfo) return;
      const cfg = this.configFor(rec);
      for (let i = 0; i < count; i++) this.spawnFrom(e.em, cfg, partInfo);
    }

    spawnFrom(em, cfg, info) {
      const half = info.half;
      const local = new THREE.Vector3((Math.random() - 0.5) * 2 * half.x, (Math.random() - 0.5) * 2 * half.y, (Math.random() - 0.5) * 2 * half.z);
      const fd = FACE_DIR[cfg.face] || FACE_DIR.Top;
      const dir = new THREE.Vector3(fd[0], fd[1], fd[2]);
      const origin = local.applyQuaternion(info.quat).add(info.pos);
      dir.applyQuaternion(info.quat);
      em.spawn(origin, dir, cfg);
    }

    clear(id) {
      const e = this.emitters.get(id);
      if (e) e.em.p = [];
    }

    burst(pos, opts) {
      const cfg = Object.assign({
        lifeMin: 0.5, lifeMax: 1.2, speedMin: 10, speedMax: 30, spreadX: 180, spreadY: 180,
        size0: 4, size1: 8, tr0: 0, tr1: 1, c0: { r: 1, g: 0.8, b: 0.3 }, c1: { r: 0.3, g: 0.3, b: 0.3 },
        acc: { x: 0, y: -10, z: 0 }, drag: 2, emission: 1, texture: 'smoke',
      }, opts || {});
      const em = new Emitter(this.scene, cfg.count || 80, cfg.texture, cfg.additive);
      for (let i = 0; i < (cfg.count || 80); i++) em.spawn(pos, new THREE.Vector3(0, 1, 0), cfg);
      this.bursts.push({ em, cfg, ttl: cfg.lifeMax + 0.2 });
    }

    update(dt, getPartInfo, scale) {
      for (const [id, e] of this.emitters) {
        const rec = e.rec;
        const cfg = this.configFor(rec);
        if (!cfg) continue;
        if (cfg.texture !== e.texture) { e.em.setTexture(cfg.texture); e.texture = cfg.texture; }
        e.em.mat.uniforms.scale.value = scale;
        const info = rec.parent != null ? getPartInfo(rec.parent) : null;
        if (info && cfg.enabled && rec.inWorld) {
          e.em.acc += cfg.rate * dt;
          let n = Math.floor(e.em.acc);
          e.em.acc -= n;
          n = Math.min(n, 200);
          for (let i = 0; i < n; i++) this.spawnFrom(e.em, cfg, info);
        }
        e.em.update(dt, cfg);
        e.em.points.visible = rec.inWorld;
      }
      this.bursts = this.bursts.filter((b) => {
        b.ttl -= dt;
        b.em.mat.uniforms.scale.value = scale;
        b.em.update(dt, b.cfg);
        if (b.ttl <= 0) { b.em.dispose(this.scene); return false; }
        return true;
      });
    }

    disposeAll() {
      for (const id of Array.from(this.emitters.keys())) this.detach(id);
      this.bursts.forEach((b) => b.em.dispose(this.scene));
      this.bursts = [];
    }
  }

  GF.ParticleSystem = ParticleSystem;
  GF.particleTexture = particleTexture;
})();
