/*
 * GameForge Studio — armazenamento local.
 * IndexedDB (banco "gameforge"): projetos, versões (backups), DataStores dos jogos e configurações.
 * Se o IndexedDB não estiver disponível, usa localStorage como reserva.
 * Inclui um gravador/leitor de ZIP próprio (sem dependências externas).
 */
(function () {
  'use strict';
  const GF = (window.GF = window.GF || {});
  const DB_NAME = 'gameforge';
  const DB_VERSION = 1;
  const MAX_VERSIONS = 30;

  // ---------------------------------------------------------------- IndexedDB
  let dbPromise = null;
  function openDB() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      if (!window.indexedDB) return reject(new Error('IndexedDB indisponível'));
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('projects')) db.createObjectStore('projects', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('versions')) {
          const v = db.createObjectStore('versions', { keyPath: 'vid', autoIncrement: true });
          v.createIndex('project', 'projectId');
        }
        if (!db.objectStoreNames.contains('datastores')) db.createObjectStore('datastores', { keyPath: 'k' });
        if (!db.objectStoreNames.contains('settings')) db.createObjectStore('settings', { keyPath: 'k' });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error('Falha ao abrir o IndexedDB'));
      req.onblocked = () => reject(new Error('IndexedDB bloqueado por outra aba'));
    });
    return dbPromise;
  }

  function tx(store, mode, fn) {
    return openDB().then((db) => new Promise((resolve, reject) => {
      const t = db.transaction(store, mode);
      const s = t.objectStore(store);
      let result;
      const r = fn(s);
      if (r && 'onsuccess' in r) r.onsuccess = () => { result = r.result; };
      t.oncomplete = () => resolve(result);
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error || new Error('Transação abortada'));
    }));
  }

  // reserva em localStorage (ou em memória, se nem localStorage estiver disponível)
  const ls = (function () {
    try { const k = '__gf_test__'; window.localStorage.setItem(k, '1'); window.localStorage.removeItem(k); return window.localStorage; }
    catch (e) {
      const m = new Map();
      return { get length() { return m.size; }, key(i) { return Array.from(m.keys())[i] || null; },
        getItem(k) { return m.has(k) ? m.get(k) : null; }, setItem(k, v) { m.set(k, String(v)); }, removeItem(k) { m.delete(k); }, memory: true };
    }
  })();
  const LS = {
    get(store, key) { try { return JSON.parse(ls.getItem('gf.' + store + '.' + key)); } catch (e) { return null; } },
    put(store, key, val) { ls.setItem('gf.' + store + '.' + key, JSON.stringify(val)); },
    del(store, key) { ls.removeItem('gf.' + store + '.' + key); },
    all(store) {
      const out = [];
      for (let i = 0; i < ls.length; i++) {
        const k = ls.key(i);
        if (k.startsWith('gf.' + store + '.')) { try { out.push(JSON.parse(ls.getItem(k))); } catch (e) { /* ignore */ } }
      }
      return out;
    },
  };

  let useLS = false;
  async function ensure() {
    if (useLS) return false;
    try { await openDB(); return true; } catch (e) { useLS = true; console.warn('Usando localStorage:', e); return false; }
  }

  const Storage = {
    get backend() { return useLS ? (ls.memory ? 'memória (temporário)' : 'localStorage') : 'IndexedDB'; },
    async init() { await ensure(); return this.backend; },

    // ---- projetos
    async listProjects() {
      const all = (await ensure()) ? await tx('projects', 'readonly', (s) => s.getAll()) : LS.all('projects');
      return (all || []).map((p) => ({ id: p.id, name: p.name, modified: p.modified, created: p.created, files: p.files.length })).sort((a, b) => b.modified - a.modified);
    },
    async getProject(id) {
      return (await ensure()) ? tx('projects', 'readonly', (s) => s.get(id)) : LS.get('projects', id);
    },
    async saveProject(p) {
      p.modified = Date.now();
      const clean = JSON.parse(JSON.stringify(p));
      if (await ensure()) await tx('projects', 'readwrite', (s) => s.put(clean));
      else LS.put('projects', p.id, clean);
      return p;
    },
    async deleteProject(id) {
      if (await ensure()) {
        await tx('projects', 'readwrite', (s) => s.delete(id));
        const vs = await this.listVersions(id);
        await tx('versions', 'readwrite', (s) => { vs.forEach((v) => s.delete(v.vid)); });
        const ds = await tx('datastores', 'readonly', (s) => s.getAll());
        await tx('datastores', 'readwrite', (s) => { ds.filter((d) => d.projectId === id).forEach((d) => s.delete(d.k)); });
      } else LS.del('projects', id);
    },

    // ---- versões (backups)
    async addVersion(p, label) {
      const v = { projectId: p.id, name: p.name, label: label || 'Salvamento manual', time: Date.now(), files: JSON.parse(JSON.stringify(p.files)) };
      if (await ensure()) {
        await tx('versions', 'readwrite', (s) => s.add(v));
        const list = await this.listVersions(p.id);
        if (list.length > MAX_VERSIONS) {
          const old = list.slice(MAX_VERSIONS);
          await tx('versions', 'readwrite', (s) => { old.forEach((o) => s.delete(o.vid)); });
        }
      } else {
        const list = LS.get('versions', p.id) || [];
        v.vid = Date.now();
        list.unshift(v);
        LS.put('versions', p.id, list.slice(0, 10));
      }
    },
    async listVersions(projectId) {
      if (await ensure()) {
        const list = await openDB().then((db) => new Promise((resolve, reject) => {
          const r = db.transaction('versions').objectStore('versions').index('project').getAll(projectId);
          r.onsuccess = () => resolve(r.result);
          r.onerror = () => reject(r.error);
        }));
        return list.sort((a, b) => b.time - a.time);
      }
      return LS.get('versions', projectId) || [];
    },
    async deleteVersion(vid, projectId) {
      if (await ensure()) await tx('versions', 'readwrite', (s) => s.delete(vid));
      else LS.put('versions', projectId, (LS.get('versions', projectId) || []).filter((v) => v.vid !== vid));
    },

    // ---- DataStores dos jogos (persistem entre execuções)
    async loadDataStores(projectId) {
      const data = {};
      const rows = (await ensure()) ? await tx('datastores', 'readonly', (s) => s.getAll()) : LS.all('datastores');
      for (const r of rows || []) {
        if (r.projectId !== projectId) continue;
        (data[r.store] = data[r.store] || {})[r.key] = r.value;
      }
      return data;
    },
    async writeDataStore(projectId, store, key, value) {
      const k = projectId + '|' + store + '|' + key;
      if (await ensure()) {
        if (value == null) await tx('datastores', 'readwrite', (s) => s.delete(k));
        else await tx('datastores', 'readwrite', (s) => s.put({ k, projectId, store, key, value }));
      } else if (value == null) LS.del('datastores', k);
      else LS.put('datastores', k, { k, projectId, store, key, value });
    },
    async clearDataStores(projectId) {
      if (await ensure()) {
        const ds = await tx('datastores', 'readonly', (s) => s.getAll());
        await tx('datastores', 'readwrite', (s) => { ds.filter((d) => d.projectId === projectId).forEach((d) => s.delete(d.k)); });
      }
    },

    // ---- configurações
    async getSetting(k, def) {
      const r = (await ensure()) ? await tx('settings', 'readonly', (s) => s.get(k)) : LS.get('settings', k);
      return r ? r.v : def;
    },
    async setSetting(k, v) {
      if (await ensure()) await tx('settings', 'readwrite', (s) => s.put({ k, v }));
      else LS.put('settings', k, { k, v });
    },
  };

  // ---------------------------------------------------------------- ZIP
  const CRC_TABLE = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      t[n] = c >>> 0;
    }
    return t;
  })();
  function crc32(buf) {
    let c = 0xffffffff;
    for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  }

  /** Cria um ZIP (sem compressão — método "store") a partir de [{path, data: string|Uint8Array}]. */
  function makeZip(entries) {
    const enc = new TextEncoder();
    const chunks = [];
    const central = [];
    let offset = 0;
    const d = new Date();
    const dosTime = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
    const dosDate = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    for (const e of entries) {
      const name = enc.encode(e.path);
      const data = typeof e.data === 'string' ? enc.encode(e.data) : e.data;
      const crc = crc32(data);
      const lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true);
      lh.setUint16(4, 20, true);
      lh.setUint16(6, 0x0800, true); // UTF-8
      lh.setUint16(8, 0, true);
      lh.setUint16(10, dosTime, true);
      lh.setUint16(12, dosDate, true);
      lh.setUint32(14, crc, true);
      lh.setUint32(18, data.length, true);
      lh.setUint32(22, data.length, true);
      lh.setUint16(26, name.length, true);
      lh.setUint16(28, 0, true);
      chunks.push(new Uint8Array(lh.buffer), name, data);
      const ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true);
      ch.setUint16(4, 20, true);
      ch.setUint16(6, 20, true);
      ch.setUint16(8, 0x0800, true);
      ch.setUint16(10, 0, true);
      ch.setUint16(12, dosTime, true);
      ch.setUint16(14, dosDate, true);
      ch.setUint32(16, crc, true);
      ch.setUint32(20, data.length, true);
      ch.setUint32(24, data.length, true);
      ch.setUint16(28, name.length, true);
      ch.setUint32(42, offset, true);
      central.push(new Uint8Array(ch.buffer), name);
      offset += 30 + name.length + data.length;
    }
    const cdSize = central.reduce((a, c) => a + c.length, 0);
    const end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true);
    end.setUint16(8, entries.length, true);
    end.setUint16(10, entries.length, true);
    end.setUint32(12, cdSize, true);
    end.setUint32(16, offset, true);
    return new Blob([...chunks, ...central, new Uint8Array(end.buffer)], { type: 'application/zip' });
  }

  async function inflateRaw(data) {
    if (typeof DecompressionStream === 'undefined') throw new Error('Este navegador não suporta ZIP comprimido (DecompressionStream). Use um ZIP sem compressão.');
    const ds = new DecompressionStream('deflate-raw');
    const stream = new Blob([data]).stream().pipeThrough(ds);
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  /** Lê um ZIP. Retorna [{path, data: Uint8Array}] (somente arquivos). */
  async function readZip(buffer) {
    const u8 = new Uint8Array(buffer);
    const dv = new DataView(buffer);
    let eocd = -1;
    for (let i = u8.length - 22; i >= Math.max(0, u8.length - 65557); i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('Arquivo ZIP inválido');
    const count = dv.getUint16(eocd + 10, true);
    let p = dv.getUint32(eocd + 16, true);
    const dec = new TextDecoder();
    const out = [];
    for (let i = 0; i < count; i++) {
      if (dv.getUint32(p, true) !== 0x02014b50) throw new Error('Diretório central do ZIP corrompido');
      const method = dv.getUint16(p + 10, true);
      const csize = dv.getUint32(p + 20, true);
      const nlen = dv.getUint16(p + 28, true);
      const xlen = dv.getUint16(p + 30, true);
      const clen = dv.getUint16(p + 32, true);
      const lho = dv.getUint32(p + 42, true);
      const name = dec.decode(u8.subarray(p + 46, p + 46 + nlen));
      p += 46 + nlen + xlen + clen;
      if (name.endsWith('/')) continue;
      const lnlen = dv.getUint16(lho + 26, true);
      const lxlen = dv.getUint16(lho + 28, true);
      const start = lho + 30 + lnlen + lxlen;
      const raw = u8.subarray(start, start + csize);
      let data;
      if (method === 0) data = raw.slice();
      else if (method === 8) data = await inflateRaw(raw);
      else throw new Error('Método de compressão não suportado em ' + name);
      out.push({ path: name, data });
    }
    return out;
  }

  function download(blob, filename) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  }

  GF.Storage = Storage;
  GF.Zip = { make: makeZip, read: readZip, crc32 };
  GF.download = download;
})();
