# GameForge Studio

IDE para criar jogos 3D escrevendo código **Luau**. O app tem duas áreas: o **Editor de Código** (com janela de teste e console) e o **Manual de Programação**. É feito só com HTML5, CSS e JavaScript. Abre no Acode e pode ser empacotado como APK pelo APKForge. O arquivo principal é `index.html`.

## Como abrir

- **Acode (Android)**: copie a pasta `gameforge` para o aparelho, abra a pasta no Acode e use "Executar/Preview" no `index.html`.
- **APKForge**: aponte o projeto para esta pasta, com `index.html` como página inicial. Nenhuma permissão especial é necessária.
- **Computador**: sirva a pasta por HTTP, por exemplo com `python3 -m http.server 8080`, e abra `http://localhost:8080`. Abrir o arquivo direto (`file://`) funciona na maioria dos navegadores, mas alguns bloqueiam IndexedDB e a exportação do jogo nesse modo.

## Internet

**O aplicativo não precisa de internet.** Todas as bibliotecas ficam na pasta `lib/` e a VM Luau fica em `runtime/`. Os ícones (`gf://icons/...`) e os sons (`sfx:`, `ambient:`, `music:`) são gerados localmente.

Só precisam de internet as imagens e os sons que o próprio script do usuário carregar por endereço `http(s)://`. O servidor de origem também precisa permitir CORS.

## Luau real

A VM e o compilador **oficiais** do Luau ([luau-lang/luau](https://github.com/luau-lang/luau)) foram compilados para WebAssembly com Emscripten (`runtime/luau-runtime.js`, arquivo único, sem dependências). Os scripts não são traduzidos para JavaScript. O código Luau roda na VM e conversa com o motor 3D (Three.js) por uma ponte de funções nativas (`native/gameforge.cpp` ↔ `js/runtime/luau-host.js`).

A API do jogo (Instance, Part, Humanoid, serviços, eventos, Tween, DataStore etc.) está em `js/runtime/prelude.luau`. Ela também é escrita em Luau e roda dentro da mesma VM.

## Estrutura

```
index.html                 página principal
css/app.css                tema escuro, layout desktop/celular, estilos do jogo
assets/icon.svg            ícone
lib/three.min.js           Three.js r160 (MIT)
lib/codemirror/            CodeMirror 5.65 (MIT) + addons
runtime/luau-runtime.js    VM + compilador Luau em WebAssembly (MIT)
js/engine/                 motor 3D: materiais, física, personagens, terreno, clima, áudio, partículas, GUI
js/runtime/                prelude.luau (API em Luau), prelude.js (gerado), luau-host.js (ponte)
js/editor/                 modo Luau, autocompletar, editor com abas, catálogo da API (gerado)
js/storage/storage.js      IndexedDB (projetos, versões, DataStores, configurações) + ZIP
js/project/project.js      modelo de projeto e modelo inicial
js/manual/                 renderizador do manual + conteúdo (gerado de manual-src/)
js/app/                    aplicação: menus, diálogos, explorador, console, exportação do jogo
manual-src/*.md            texto do manual (fonte)
native/                    código C++ da ponte e script de compilação do WebAssembly
tools/                     geradores (prelude, catálogo, manual)
```

## Recursos

- Editor: destaque de sintaxe Luau, numeração de linhas, verificação de sintaxe pelo compilador real ao digitar, marcação dos erros de execução na linha, indentação automática, autocompletar sensível ao contexto (Ctrl+Espaço), localizar/substituir, ir para linha, pesquisa em todos os arquivos, lista de funções do arquivo, abas e vários arquivos. Não há limite de tamanho de script.
- Projetos: criar, abrir, salvar (Ctrl+S), salvar como (cópia), renomear, excluir, pastas, scripts `.lua`/`.luau`, módulos (`Modules/`), salvamento automático, versões e backups (até 30 por projeto), importação/exportação `.zip` e `.gfproj`, além da exportação do jogo como um único HTML offline.
- Execução: botões Executar/Parar, console com filtros e erros `arquivo:linha` clicáveis, linha de comando Luau com o jogo rodando, limite de tempo contra laços infinitos.
- Motor: câmera em 1ª/3ª pessoa, personagens com animações, NPCs, pathfinding, física com gravidade/colisões/impulsos, terreno, iluminação com ciclo de dia, sombras, materiais e texturas, partículas, fogo, fumaça, explosões, áudio 3D, clima (chuva, neve, tempestade, neblina, areia, raios), interface (ScreenGui/BillboardGui), ferramentas e mochila, placar, DataStore local.
- Celular: abas inferiores (Arquivos, Código, Jogo, Console), teclas extras para programação, joystick e botão de pulo no jogo.

## Regras dos scripts

- Os arquivos `.lua`/`.luau` fora de `Modules/` rodam juntos ao clicar em Executar, na ordem do explorador. Para desativar um script, use o menu ⋯ do explorador.
- Os arquivos em `Modules/` (ou com o nome `*.module.luau`) só rodam via `require("Nome")`.

## Limitações conhecidas

- O jogo roda localmente. Não há servidor nem multijogador, e `HttpService` não faz requisições.
- A física usa caixas alinhadas aos eixos (AABB) e esferas. Corpos dinâmicos não giram por colisão.
- Os personagens usam o corpo e as animações embutidas do GameForge. Não é possível importar malhas externas.

## Recompilar (só para desenvolvedores)

O aplicativo já vem compilado. Só é preciso recompilar quando o código-fonte mudar:

```
# VM Luau → WebAssembly (requer emsdk e o repositório do Luau em $LUAU_DIR)
source ~/emsdk/emsdk_env.sh && cd native && bash build.sh

# depois de editar js/runtime/prelude.luau
node tools/build-prelude.js && node tools/build-catalog.js

# depois de editar manual-src/*.md
node tools/build-manual.js
```

## Licenças de terceiros

Luau (MIT, Roblox Corporation), Three.js (MIT), CodeMirror 5 (MIT).
