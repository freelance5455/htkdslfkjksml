<!-- capitulo id=interface num=14 group="Recursos do jogo" title="Interface" -->
A interface do jogo (placar, botões, menus, barras) é feita com objetos de GUI dentro de um `ScreenGui`, colocado em `player.PlayerGui` (ou em `StarterGui`, que é copiado a cada renascimento).

## Posição e tamanho com UDim2

`UDim2.new(escalaX, pixelsX, escalaY, pixelsY)`: a escala vai de 0 a 1 (proporção da tela) e os pixels somam um deslocamento fixo. `UDim2.fromScale` e `UDim2.fromOffset` são atalhos.

```luau Placar de moedas
local player = Game:GetService("Players").LocalPlayer
local gui = Instance.new("ScreenGui")
gui.Name = "HUD"
gui.Parent = player.PlayerGui

local painel = Instance.new("Frame")
painel.Size = UDim2.fromOffset(200, 56)
painel.Position = UDim2.new(0, 16, 1, -72)
painel.BackgroundColor3 = Color3.fromRGB(20, 22, 30)
painel.BackgroundTransparency = 0.2
painel.Parent = gui
local canto = Instance.new("UICorner")
canto.CornerRadius = UDim.new(0, 12)
canto.Parent = painel
local borda = Instance.new("UIStroke")
borda.Color = Color3.fromRGB(255, 200, 0)
borda.Thickness = 2
borda.Parent = painel

local icone = Instance.new("ImageLabel")
icone.Image = "gf://icons/coin"
icone.Size = UDim2.fromOffset(40, 40)
icone.Position = UDim2.fromOffset(8, 8)
icone.BackgroundTransparency = 1
icone.Parent = painel

local texto = Instance.new("TextLabel")
texto.Size = UDim2.new(1, -60, 1, 0)
texto.Position = UDim2.fromOffset(56, 0)
texto.BackgroundTransparency = 1
texto.TextColor3 = Color3.new(1, 1, 1)
texto.TextSize = 24
texto.Font = Enum.Font.GothamBold
texto.TextXAlignment = Enum.TextXAlignment.Left
texto.Text = "0 moedas"
texto.Parent = painel

local moedas = 0
while true do
    task.wait(1)
    moedas += 1
    texto.Text = moedas .. " moedas"
end
```

## Botões e caixas de texto

```luau Menu com botão e TextBox
local player = Game:GetService("Players").LocalPlayer
local gui = Instance.new("ScreenGui")
gui.Parent = player.PlayerGui

local janela = Instance.new("Frame")
janela.AnchorPoint = Vector2.new(0.5, 0.5)
janela.Position = UDim2.fromScale(0.5, 0.5)
janela.Size = UDim2.fromOffset(280, 190)
janela.BackgroundColor3 = Color3.fromRGB(30, 34, 46)
janela.Parent = gui
Instance.new("UICorner").Parent = janela
local pad = Instance.new("UIPadding")
pad.PaddingTop = UDim.new(0, 12)
pad.PaddingLeft = UDim.new(0, 12)
pad.PaddingRight = UDim.new(0, 12)
pad.Parent = janela
local lista = Instance.new("UIListLayout")
lista.Padding = UDim.new(0, 10)
lista.Parent = janela

local titulo = Instance.new("TextLabel")
titulo.Size = UDim2.new(1, 0, 0, 30)
titulo.BackgroundTransparency = 1
titulo.Text = "Qual é o seu nome?"
titulo.TextColor3 = Color3.new(1, 1, 1)
titulo.TextSize = 20
titulo.Parent = janela

local caixa = Instance.new("TextBox")
caixa.Size = UDim2.new(1, 0, 0, 40)
caixa.PlaceholderText = "Digite aqui"
caixa.Text = ""
caixa.TextSize = 18
caixa.Parent = janela

local botao = Instance.new("TextButton")
botao.Size = UDim2.new(1, 0, 0, 44)
botao.BackgroundColor3 = Color3.fromRGB(0, 170, 90)
botao.Text = "Começar"
botao.TextColor3 = Color3.new(1, 1, 1)
botao.TextSize = 20
botao.Parent = janela
Instance.new("UICorner").Parent = botao

botao.MouseButton1Click:Connect(function()
    local nome = if caixa.Text ~= "" then caixa.Text else "Aventureiro"
    Game.Notify("Boa sorte, " .. nome .. "!", 3)
    gui:Destroy()
end)
```

## Elementos disponíveis

| Classe | Uso |
|---|---|
| `ScreenGui` | camada da tela (`DisplayOrder`, `Enabled`, `ResetOnSpawn`) |
| `Frame` | retângulo/contêiner |
| `TextLabel`, `TextButton`, `TextBox` | texto, botão, entrada de texto |
| `ImageLabel`, `ImageButton` | imagens (`gf://icons/...` sem internet; `http(s)` requer internet) |
| `ScrollingFrame` | área com rolagem (`CanvasSize`) |
| `UICorner`, `UIStroke`, `UIPadding`, `UIGradient` | estilo |
| `UIListLayout`, `UIGridLayout`, `UIAspectRatioConstraint` | organização automática |
| `BillboardGui` | interface presa a uma peça no mundo 3D |

## Interface no mundo 3D

```luau BillboardGui
local placa = Instance.new("Part")
placa.Size = Vector3.new(2, 4, 2)
placa.Position = Vector3.new(0, 2, -12)
placa.Anchored = true
placa.Parent = workspace
local bb = Instance.new("BillboardGui")
bb.Size = UDim2.fromOffset(180, 50)
bb.StudsOffset = Vector3.new(0, 3.5, 0)
bb.Parent = placa
local t = Instance.new("TextLabel")
t.Size = UDim2.fromScale(1, 1)
t.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
t.BackgroundTransparency = 0.4
t.TextColor3 = Color3.fromRGB(255, 220, 0)
t.TextSize = 22
t.Text = "Loja do Zé"
t.Parent = bb
```

## Interface padrão

A barra de vida, o placar (`leaderstats`) e a mochila aparecem sozinhos. Para escondê-los:

```luau-frag
local StarterGui = Game:GetService("StarterGui")
StarterGui:SetCoreGuiEnabled("Health", false)
StarterGui:SetCoreGuiEnabled("PlayerList", false)
StarterGui:SetCoreGuiEnabled("Backpack", false)
StarterGui:SetCore("SendNotification", { Title = "Aviso", Text = "Olá!", Duration = 3 })
```

::: exercicio Barra de energia
Crie uma barra que diminui 10% a cada segundo, usando `TweenSize` ou alterando `Size`.
```luau
local gui = Instance.new("ScreenGui")
gui.Parent = Game:GetService("Players").LocalPlayer.PlayerGui
local fundo = Instance.new("Frame")
fundo.Size = UDim2.fromOffset(240, 20)
fundo.Position = UDim2.new(0.5, -120, 0, 60)
fundo.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
fundo.Parent = gui
local barra = Instance.new("Frame")
barra.Size = UDim2.fromScale(1, 1)
barra.BackgroundColor3 = Color3.fromRGB(0, 200, 255)
barra.Parent = fundo
for energia = 9, 0, -1 do
    task.wait(1)
    barra:TweenSize(UDim2.fromScale(energia / 10, 1), "Out", "Quad", 0.3)
end
print("Sem energia!")
```
:::

<!-- capitulo id=iluminacao num=15 group="Recursos do jogo" title="Iluminação" -->
O serviço `Lighting` controla o sol, a hora do dia, o céu, a neblina e as sombras.

```luau Pôr do sol
local Lighting = Game:GetService("Lighting")
Lighting.ClockTime = 18.2
Lighting.Brightness = 2
Lighting.Ambient = Color3.fromRGB(90, 70, 80)
Lighting.FogColor = Color3.fromRGB(255, 170, 120)
Lighting.FogStart = 40
Lighting.FogEnd = 300
print("Hora:", Lighting.TimeOfDay)
Models.Create("House", Vector3.new(0, 0, -30))
```

| Propriedade | Descrição |
|---|---|
| `ClockTime` | hora do dia de 0 a 24 (14 = 14h) |
| `TimeOfDay` | hora como texto `"14:00:00"` |
| `DayLength` | segundos para um dia completo passar sozinho (0 = parado) |
| `Brightness` | intensidade do sol |
| `Ambient`, `OutdoorAmbient` | luz ambiente |
| `GlobalShadows` | liga/desliga sombras |
| `FogColor`, `FogStart`, `FogEnd` | neblina por distância |
| `SkyColor`, `AutoSkyColor` | cor do céu (automática segue a hora) |
| `ExposureCompensation` | exposição geral |

## Ciclo de dia e noite

```luau Dia e noite rápidos
local Lighting = Game:GetService("Lighting")
Lighting.DayLength = 40 -- um dia inteiro em 40 segundos
Models.Create("Lamp", Vector3.new(4, 0, -12))
Models.Create("Lamp", Vector3.new(-4, 0, -12))
while true do
    task.wait(2)
    print("Agora são", Lighting.TimeOfDay)
end
```

## Luzes

`PointLight` ilumina em todas as direções; `SpotLight` e `SurfaceLight` iluminam a partir de uma face (`Face`, `Angle`).

```luau Luzes coloridas à noite
local Lighting = Game:GetService("Lighting")
Lighting.ClockTime = 22
local cores = { Color3.fromRGB(255, 50, 50), Color3.fromRGB(50, 255, 80), Color3.fromRGB(60, 120, 255) }
for i, cor in cores do
    local poste = Instance.new("Part")
    poste.Size = Vector3.new(1, 1, 1)
    poste.Position = Vector3.new(i * 8 - 16, 4, -14)
    poste.Material = Enum.Material.Neon
    poste.Color = cor
    poste.Anchored = true
    poste.Parent = workspace
    local luz = Instance.new("PointLight")
    luz.Color = cor
    luz.Range = 18
    luz.Brightness = 3
    luz.Parent = poste
end
local holofote = Instance.new("Part")
holofote.Size = Vector3.new(2, 1, 2)
holofote.Position = Vector3.new(0, 14, -24)
holofote.Anchored = true
holofote.Parent = workspace
local spot = Instance.new("SpotLight")
spot.Face = Enum.NormalId.Bottom
spot.Angle = 45
spot.Range = 30
spot.Brightness = 5
spot.Parent = holofote
```

## Efeitos visuais

| Classe | Descrição |
|---|---|
| `ParticleEmitter` | partículas configuráveis (`Rate`, `Lifetime`, `Speed`, `Color`, `Size`, `Texture`, `:Emit(n)`) |
| `Fire` | fogo (`Size`, `Heat`, `Color`, `SecondaryColor`) |
| `Smoke` | fumaça (`Opacity`, `RiseVelocity`) |
| `Sparkles` | brilhos |
| `Explosion` | explosão com onda de choque |

```luau Fogueira e partículas
local lenha = Instance.new("Part")
lenha.Size = Vector3.new(3, 0.6, 3)
lenha.Position = Vector3.new(0, 0.3, -10)
lenha.Material = Enum.Material.Wood
lenha.Color = Color3.fromRGB(90, 50, 30)
lenha.Anchored = true
lenha.Parent = workspace
local fogo = Instance.new("Fire")
fogo.Size = 6
fogo.Heat = 12
fogo.Parent = lenha
local fumaca = Instance.new("Smoke")
fumaca.Opacity = 0.2
fumaca.RiseVelocity = 4
fumaca.Parent = lenha
local luz = Instance.new("PointLight")
luz.Color = Color3.fromRGB(255, 150, 60)
luz.Range = 20
luz.Parent = lenha

local fonte = Instance.new("Part")
fonte.Size = Vector3.new(1, 1, 1)
fonte.Position = Vector3.new(8, 1, -10)
fonte.Anchored = true
fonte.Transparency = 1
fonte.Parent = workspace
local p = Instance.new("ParticleEmitter")
p.Texture = "gf://icons/star"
p.Rate = 30
p.Lifetime = NumberRange.new(1, 2)
p.Speed = NumberRange.new(6, 10)
p.SpreadAngle = Vector2.new(30, 30)
p.Color = ColorSequence.new(Color3.fromRGB(255, 255, 0), Color3.fromRGB(255, 0, 150))
p.Size = NumberSequence.new(1, 0)
p.Acceleration = Vector3.new(0, -10, 0)
p.Parent = fonte
Game:GetService("Lighting").ClockTime = 20
```

::: exercicio Farol
Crie uma torre com uma `SpotLight` que gira continuamente durante a noite.
```luau
Game:GetService("Lighting").ClockTime = 23
local torre = Models.Create("Tower", Vector3.new(0, 0, -25))
local cabeca = Instance.new("Part")
cabeca.Size = Vector3.new(2, 2, 2)
cabeca.Anchored = true
cabeca.Material = Enum.Material.Neon
cabeca.Parent = workspace
local luz = Instance.new("SpotLight")
luz.Face = Enum.NormalId.Front
luz.Range = 60
luz.Brightness = 6
luz.Angle = 30
luz.Parent = cabeca
local topo = torre:GetBoundingBox().Position.Y + torre:GetExtentsSize().Y / 2 + 1
local a = 0
Game:GetService("RunService").Heartbeat:Connect(function(dt)
    a += dt
    cabeca.CFrame = CFrame.new(0, topo, -25) * CFrame.Angles(-0.3, a, 0)
end)
```
:::

<!-- capitulo id=audio num=16 group="Recursos do jogo" title="Áudio" -->
Sons são objetos `Sound`. O GameForge tem uma biblioteca de sons **gerados no próprio aparelho** (funcionam sem internet):

| Grupo | SoundId |
|---|---|
| Efeitos | `sfx:jump`, `sfx:coin`, `sfx:explosion`, `sfx:hit`, `sfx:laser`, `sfx:click`, `sfx:powerup`, `sfx:hurt`, `sfx:win`, `sfx:lose`, `sfx:step`, `sfx:thunder`, `sfx:swing`, `sfx:door`, `sfx:bell` |
| Ambiente (em loop) | `ambient:rain`, `ambient:wind`, `ambient:birds` |
| Música (em loop) | `music:adventure`, `music:calm`, `music:battle` |

>! Também é possível usar um arquivo `http(s)://...mp3`. Esse caso **depende de internet** e de o servidor permitir o acesso (CORS).

> Navegadores só liberam áudio depois de uma interação. Clique ou toque na janela do jogo se não ouvir nada.

```luau Tocando sons
local SoundService = Game:GetService("SoundService")
local musica = Instance.new("Sound")
musica.SoundId = "music:adventure"
musica.Looped = true
musica.Volume = 0.4
musica.Parent = SoundService
musica:Play()

local efeitos = { "sfx:coin", "sfx:jump", "sfx:powerup", "sfx:laser", "sfx:win" }
for _, id in efeitos do
    task.wait(1)
    print("Tocando", id)
    SoundService:PlayLocalSound(id)
end
```

## Som no mundo 3D

Um `Sound` dentro de uma peça fica mais baixo quanto mais longe você estiver (`RollOffMaxDistance`):

```luau Som posicional
local radio = Instance.new("Part")
radio.Size = Vector3.new(2, 1.5, 1)
radio.Position = Vector3.new(0, 0.75, -30)
radio.Anchored = true
radio.Color = Color3.fromRGB(40, 40, 40)
radio.Parent = workspace
local som = Instance.new("Sound")
som.SoundId = "music:calm"
som.Looped = true
som.RollOffMaxDistance = 60
som.Parent = radio
som:Play()
print("Aproxime-se do rádio para ouvir melhor")
```

| Sound | Descrição |
|---|---|
| `SoundId` | qual som |
| `Volume` (0–10), `PlaybackSpeed` | volume e velocidade/tom |
| `Looped` | repetir |
| `:Play()`, `:Stop()`, `:Pause()`, `:Resume()` | controle |
| `IsPlaying`, `TimeLength` | leitura |
| `Ended`, `Played` | eventos |
| `PlayOnRemove` | toca ao ser destruído |
| `SoundService.Volume` | volume geral |

::: exercicio Moeda sonora
Crie uma moeda que toca `sfx:coin` e some quando o jogador a toca.
```luau
local moeda = Models.Create("Coin", Vector3.new(0, 2, -8))
local tocou = false
for _, p in moeda:GetDescendants() do
    if p:IsA("BasePart") then
        p.Touched:Connect(function(outro)
            if tocou or not outro.Parent:FindFirstChildOfClass("Humanoid") then return end
            tocou = true
            Game:GetService("SoundService"):PlayLocalSound("sfx:coin")
            moeda:Destroy()
        end)
    end
end
```
:::

<!-- capitulo id=clima num=17 group="Recursos do jogo" title="Clima" -->
O serviço `Weather` cria chuva, neve, tempestades com raios, neblina e tempestades de areia, com som ambiente.

## Exemplo: começou a chover

```luau Começou a chover
local Lighting = Game:GetService("Lighting")
local Weather = Game:GetService("Weather")

Lighting.ClockTime = 18
Weather.Type = "Rain"
Weather.Intensity = 0.8

print("Começou a chover!")
```

| Propriedade | Descrição |
|---|---|
| `Type` | `"Clear"`, `"Rain"`, `"Snow"`, `"Storm"`, `"Fog"`, `"Sandstorm"` (texto ou `Enum.WeatherType`) |
| `Intensity` | 0 a 1 |
| `WindSpeed`, `WindDirection` | vento (inclina chuva e neve) |
| `CloudCover` | nuvens 0 a 1 |
| `FogDensity` | neblina extra 0 a 1 |
| `Lightning` | raios automáticos na tempestade |
| `RainVolume`, `ThunderVolume` | volume dos sons |
| `:Strike(posição?)` | dispara um raio |

Atalho: `Game.SetWeather("Snow", 0.6)`.

## Previsão do tempo

```luau Ciclo de clima
local Weather = Game:GetService("Weather")
local Lighting = Game:GetService("Lighting")
Models.Create("House", Vector3.new(0, 0, -28))
local previsao = {
    { "Clear", 0, 13, "Céu limpo" },
    { "Fog", 0.7, 8, "Neblina da manhã" },
    { "Rain", 0.6, 16, "Chuva" },
    { "Storm", 1, 19, "Tempestade!" },
    { "Snow", 0.8, 21, "Neve" },
    { "Sandstorm", 0.7, 15, "Tempestade de areia" },
}
while true do
    for _, p in previsao do
        Weather.Type = p[1]
        Weather.Intensity = p[2]
        Lighting.ClockTime = p[3]
        Game.Notify(p[4], 3)
        task.wait(6)
    end
end
```

## Vento e raios

```luau Tempestade com raios
local Weather = Game:GetService("Weather")
Weather.Type = "Storm"
Weather.Intensity = 1
Weather.WindSpeed = 30
Weather.WindDirection = Vector3.new(1, 0, 0.3)
Weather.Lightning = false -- raios só quando o script mandar
for i = 1, 5 do
    task.wait(2)
    Weather:Strike(Vector3.new(math.random(-30, 30), 0, math.random(-60, -20)))
    print("Raio", i)
end
```

::: exercicio Neve à noite
Faça nevar com intensidade 0.5 às 21h e acenda uma fogueira.
```luau
Game.SetWeather("Snow", 0.5)
Game.SetTime(21)
local base = Instance.new("Part")
base.Size = Vector3.new(3, 0.5, 3)
base.Position = Vector3.new(0, 0.25, -10)
base.Anchored = true
base.Parent = workspace
Instance.new("Fire").Parent = base
```
:::

<!-- capitulo id=ia-npcs num=18 group="Recursos do jogo" title="IA dos NPCs" -->
NPCs são personagens controlados por script. Crie com `Game.CreateNPC(nome, posição)` e controle com `Humanoid:MoveTo`, `PathfindingService` e lógica de estados.

## Patrulha

```luau Patrulha por pontos
local npc = Game.CreateNPC("Patrulheiro", Vector3.new(0, 3, -20))
local h = npc.Humanoid
h.WalkSpeed = 12
local pontos = { Vector3.new(-15, 0, -20), Vector3.new(-15, 0, -40), Vector3.new(15, 0, -40), Vector3.new(15, 0, -20) }
while true do
    for _, ponto in pontos do
        h:MoveTo(ponto)
        h.MoveToFinished:Wait()
        task.wait(0.5)
    end
end
```

## Perseguir o jogador

```luau Inimigo que persegue
local Players = Game:GetService("Players")
local inimigo = Game.CreateNPC("Zumbi", Vector3.new(0, 3, -40))
local h = inimigo.Humanoid
h.ShirtColor = Color3.fromRGB(60, 120, 60)
h.BodyColor = Color3.fromRGB(120, 170, 110)
h.WalkSpeed = 10
local raiz = inimigo.HumanoidRootPart
local ultimoAtaque = 0
while h.Health > 0 do
    local char = Players.LocalPlayer.Character
    local alvo = char and char:FindFirstChild("HumanoidRootPart")
    if alvo then
        local distancia = (alvo.Position - raiz.Position).Magnitude
        if distancia < 40 then
            h:MoveTo(alvo.Position)
            if distancia < 4 and os.clock() - ultimoAtaque > 1 then
                ultimoAtaque = os.clock()
                char.Humanoid:TakeDamage(10)
                h:LoadAnimation("Punch"):Play()
            end
        else
            h:MoveTo(raiz.Position) -- parado: muito longe
        end
    end
    task.wait(0.2)
end
```

## Caminhos com obstáculos

`PathfindingService` calcula uma rota desviando de paredes. Cada waypoint tem `Position` e `Action` (`Walk` ou `Jump`).

```luau Pathfinding
local PathfindingService = Game:GetService("PathfindingService")
for i = -2, 2 do
    local parede = Instance.new("Part")
    parede.Size = Vector3.new(16, 6, 1)
    parede.Position = Vector3.new(i % 2 == 0 and -4 or 4, 3, -10 - (i + 2) * 6)
    parede.Anchored = true
    parede.Color = Color3.fromRGB(120, 120, 140)
    parede.Parent = workspace
end
local npc = Game.CreateNPC("Explorador", Vector3.new(0, 3, -4))
local h = npc.Humanoid
local destino = Vector3.new(0, 0, -40)
task.wait(1)
local caminho = PathfindingService:CreatePath({ AgentRadius = 2, AgentHeight = 5 })
caminho:ComputeAsync(npc.HumanoidRootPart.Position, destino)
if caminho.Status == Enum.PathStatus.Success then
    for _, wp in caminho:GetWaypoints() do
        local marca = Instance.new("Part")
        marca.Size = Vector3.new(0.6, 0.6, 0.6)
        marca.Position = wp.Position + Vector3.new(0, 0.3, 0)
        marca.Anchored = true
        marca.CanCollide = false
        marca.Material = Enum.Material.Neon
        marca.Parent = workspace
    end
    for _, wp in caminho:GetWaypoints() do
        if wp.Action == Enum.PathWaypointAction.Jump then h.Jump = true end
        h:MoveTo(wp.Position)
        h.MoveToFinished:Wait()
    end
    print("Cheguei!")
else
    print("Sem caminho")
end
```

## Máquina de estados

```luau-frag
local estado = "patrulhar"
while true do
    if estado == "patrulhar" then
        -- andar entre pontos; se ver o jogador: estado = "perseguir"
    elseif estado == "perseguir" then
        -- MoveTo(jogador); se perto: estado = "atacar"; se longe: "patrulhar"
    elseif estado == "atacar" then
        -- TakeDamage + animação Punch; depois "perseguir"
    end
    task.wait(0.2)
end
```

## Diálogo

```luau NPC que conversa
local Chat = Game:GetService("Chat")
local velho = Game.CreateNPC("Sábio", Vector3.new(0, 3, -12))
local prompt = Instance.new("ProximityPrompt")
prompt.ActionText = "Conversar"
prompt.ObjectText = "Sábio"
prompt.Parent = velho.HumanoidRootPart
local falas = { "Olá, viajante!", "A espada lendária está na torre.", "Cuidado com os zumbis à noite." }
local i = 0
prompt.Triggered:Connect(function()
    i = i % #falas + 1
    Chat:Chat(velho.Head, falas[i])
    velho.Humanoid:LoadAnimation("Point"):Play()
end)
```

::: exercicio Fuga
Crie um NPC "Galinha" que foge do jogador quando ele chega a menos de 15 studs.
```luau
local Players = Game:GetService("Players")
local galinha = Game.CreateNPC("Galinha", Vector3.new(0, 3, -15))
galinha.Humanoid.WalkSpeed = 18
while true do
    local char = Players.LocalPlayer.Character
    local raiz = galinha.HumanoidRootPart
    if char and char:FindFirstChild("HumanoidRootPart") then
        local diff = raiz.Position - char.HumanoidRootPart.Position
        if diff.Magnitude < 15 then
            local fuga = Vector3.new(diff.X, 0, diff.Z).Unit * 12
            galinha.Humanoid:MoveTo(raiz.Position + fuga)
        end
    end
    task.wait(0.3)
end
```
:::

<!-- capitulo id=inventario num=19 group="Recursos do jogo" title="Inventário" -->
Ferramentas (`Tool`) ficam na `Backpack` do jogador e aparecem na barra inferior. Aperte 1–9 (ou toque) para equipar; clique/toque na tela para usar (`Activated`).

## Criando uma ferramenta

Uma ferramenta precisa de uma peça chamada `Handle`, que fica na mão do personagem.

```luau Espada
local player = Game:GetService("Players").LocalPlayer
local espada = Instance.new("Tool")
espada.Name = "Espada"
espada.TextureId = "gf://icons/sword"
espada.ToolTip = "Clique para atacar"
local handle = Instance.new("Part")
handle.Name = "Handle"
handle.Size = Vector3.new(0.4, 4, 0.4)
handle.Color = Color3.fromRGB(200, 200, 210)
handle.Material = Enum.Material.Metal
handle.Parent = espada
espada.Parent = player.Backpack

local alvo = Game.CreateNPC("Boneco", Vector3.new(0, 3, -10))
alvo.Humanoid.WalkSpeed = 0
alvo.Humanoid.Died:Connect(function() print("Boneco derrotado!") end)

espada.Activated:Connect(function()
    local char = player.Character
    char.Humanoid:LoadAnimation("Punch"):Play()
    Game:GetService("SoundService"):PlayLocalSound("sfx:swing")
    for _, p in workspace:GetPartBoundsInRadius(handle.Position, 5) do
        local h = p.Parent and p.Parent:FindFirstChildOfClass("Humanoid")
        if h and p.Parent ~= char then
            h:TakeDamage(25)
            print("Acertou! Vida do boneco:", h.Health)
            break
        end
    end
end)
espada.Equipped:Connect(function() print("Espada equipada") end)
print("Aperte 1 para equipar e clique para atacar")
```

## Itens no StarterPack

Ferramentas em `StarterPack` são copiadas para a mochila sempre que o jogador nasce.

## Inventário de dados

Para itens que não são ferramentas (chaves, poções, minério), guarde uma tabela e mostre na interface:

```luau Inventário com tabela e placar
local player = Game:GetService("Players").LocalPlayer
local stats = Instance.new("Folder")
stats.Name = "leaderstats" -- aparece no placar do canto da tela
stats.Parent = player
local ouro = Instance.new("IntValue")
ouro.Name = "Ouro"
ouro.Parent = stats

local inventario = {}
local function adicionar(item, qtd)
    inventario[item] = (inventario[item] or 0) + qtd
    print(`+{qtd} {item} (total {inventario[item]})`)
end

local itens = { { "Poção", "gf://icons/potion" }, { "Chave", "gf://icons/key" }, { "Gema", "gf://icons/gem" } }
for i, info in itens do
    local p = Instance.new("Part")
    p.Size = Vector3.new(2, 2, 2)
    p.Position = Vector3.new(i * 6 - 12, 1.5, -10)
    p.Anchored = true
    p.Color = Color3.fromRGB(255, 220, 120)
    p.Parent = workspace
    local d = Instance.new("Decal")
    d.Texture = info[2]
    d.Face = Enum.NormalId.Back
    d.Parent = p
    local pr = Instance.new("ProximityPrompt")
    pr.ActionText = "Pegar"
    pr.ObjectText = info[1]
    pr.Parent = p
    pr.Triggered:Connect(function()
        adicionar(info[1], 1)
        ouro.Value += 10
        p:Destroy()
    end)
end
```

::: exercicio Poção de cura
Crie uma ferramenta "Poção" que cura 50 de vida e desaparece ao ser usada.
```luau
local player = Game:GetService("Players").LocalPlayer
local pocao = Instance.new("Tool")
pocao.Name = "Poção"
pocao.TextureId = "gf://icons/potion"
local handle = Instance.new("Part")
handle.Name = "Handle"
handle.Size = Vector3.new(1, 1.4, 1)
handle.Color = Color3.fromRGB(220, 40, 80)
handle.Parent = pocao
pocao.Parent = player.Backpack
pocao.Activated:Connect(function()
    local h = player.Character.Humanoid
    h.Health = math.min(h.Health + 50, h.MaxHealth)
    print("Curado! Vida:", h.Health)
    pocao:Destroy()
end)
```
:::

<!-- capitulo id=salvamento num=20 group="Recursos do jogo" title="Salvamento de dados" -->
`DataStoreService` guarda dados **no próprio aparelho** (IndexedDB), separados por projeto. Os dados continuam depois de parar o jogo, fechar o aplicativo ou reiniciar o celular. Não há servidor nem internet envolvidos.

```luau Salvando o recorde
local DataStoreService = Game:GetService("DataStoreService")
local dados = DataStoreService:GetDataStore("Progresso")

local execucoes = dados:IncrementAsync("execucoes", 1)
print("Você já executou este jogo", execucoes, "vez(es)")

local perfil = dados:GetAsync("perfil") or { nivel = 1, moedas = 0, itens = {} }
perfil.moedas += 25
perfil.nivel = 1 + perfil.moedas // 100
table.insert(perfil.itens, "Item " .. #perfil.itens + 1)
dados:SetAsync("perfil", perfil)
print(`Nível {perfil.nivel}, moedas {perfil.moedas}, itens: {table.concat(perfil.itens, ", ")}`)
```

Execute o exemplo várias vezes: os valores continuam de onde pararam.

## Métodos

| Método | Descrição |
|---|---|
| `DataStoreService:GetDataStore(nome, escopo?)` | abre um banco de dados |
| `:GetAsync(chave)` | lê (nil se não existir) |
| `:SetAsync(chave, valor)` | grava números, textos, booleanos e tabelas |
| `:UpdateAsync(chave, função)` | lê, transforma e grava |
| `:IncrementAsync(chave, n)` | soma n |
| `:RemoveAsync(chave)` | apaga |
| `:ListKeysAsync()` | lista as chaves |

## Salvando ao sair

`game:BindToClose(função)` roda quando o jogo é parado:

```luau Salvar ao parar
local dados = Game:GetService("DataStoreService"):GetDataStore("Tempo")
local inicio = os.clock()
Game:BindToClose(function()
    local total = (dados:GetAsync("segundos") or 0) + (os.clock() - inicio)
    dados:SetAsync("segundos", total)
end)
print("Tempo total jogado antes desta sessão:", math.floor(dados:GetAsync("segundos") or 0), "s")
print("Clique em Parar e execute de novo para ver o total aumentar")
```

## JSON

`HttpService:JSONEncode` e `JSONDecode` convertem tabelas em texto, úteis para depurar ou montar códigos de salvamento:

```luau JSON
local HttpService = Game:GetService("HttpService")
local texto = HttpService:JSONEncode({ nome = "Ana", nivel = 5, itens = { "Espada", "Escudo" } })
print(texto)
local volta = HttpService:JSONDecode(texto)
print(volta.nome, volta.itens[2])
print("ID único:", HttpService:GenerateGUID(false))
```

> O `HttpService` do GameForge não faz requisições à internet; apenas JSON e GUID.

>! Os dados salvos ficam no navegador/aplicativo deste aparelho. Limpar os dados do aplicativo apaga tudo. Para levar o progresso a outro aparelho, use **Arquivo → Exportar projeto** (os dados do DataStore vão junto no ZIP).

::: exercicio Recorde de pulos
Conte os pulos do jogador e salve o maior valor já alcançado.
```luau
local dados = Game:GetService("DataStoreService"):GetDataStore("Pulos")
local recorde = dados:GetAsync("recorde") or 0
print("Recorde atual:", recorde)
local player = Game:GetService("Players").LocalPlayer
local char = player.Character or player.CharacterAdded:Wait()
local pulos = 0
char:WaitForChild("Humanoid").Jumping:Connect(function(ativo)
    if not ativo then return end
    pulos += 1
    if pulos > recorde then
        recorde = pulos
        dados:SetAsync("recorde", recorde)
        print("Novo recorde:", recorde)
    end
end)
```
:::
