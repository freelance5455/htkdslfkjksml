<!-- capitulo id=inicio num=0 group="Começando" title="Como usar o GameForge Studio" -->
O GameForge Studio é um ambiente para criar jogos 3D **escrevendo código Luau**. Não existe editor de mapas por arrastar blocos: tudo o que aparece no mundo — terreno, blocos, personagens, luzes, chuva, interface — é criado pelos seus scripts e executado por uma máquina virtual Luau real (compilada para WebAssembly) que controla o motor 3D do GameForge.

## As duas áreas

- **Editor**: explorador de arquivos, editor de código com abas, janela de teste do jogo e console.
- **Manual**: este guia. Cada exemplo tem os botões **Copiar**, **Novo script**, **Substituir atual** e **▶ Executar**.

## Seu primeiro jogo

Clique em **▶ Executar** no exemplo abaixo. O jogo começa na janela de teste e o texto aparece no console.

```luau Meu primeiro jogo
print("Meu primeiro jogo!")

Game.SetGravity(196.2)
local player = Game.CreatePlayer("Soldado")
Game.SetWeather("Rain")

local bloco = Instance.new("Part")
bloco.Name = "MeuBloco"
bloco.Position = Vector3.new(0, 5, -10)
bloco.Size = Vector3.new(4, 4, 4)
bloco.Color = Color3.fromRGB(255, 0, 0)
bloco.Anchored = true
bloco.Parent = workspace
```

## Controles da janela de teste

| Ação | Computador | Celular |
|---|---|---|
| Andar | W A S D ou setas | joystick virtual (canto esquerdo) |
| Pular | Espaço | botão de pulo |
| Girar a câmera | arrastar com o botão direito | arrastar na tela |
| Zoom | roda do mouse | dois dedos (pinça) |
| 1ª / 3ª pessoa | V | — (use `Game.SetCameraMode`) |
| Ferramentas | 1 a 9 | toque na barra da mochila |

> Clique dentro da janela do jogo antes de usar o teclado. Enquanto você digita no editor, as teclas não controlam o personagem.

## Como os scripts rodam

- Todos os arquivos `.lua`/`.luau` fora da pasta `Modules` são **scripts** e rodam juntos quando você clica em **Executar** (na ordem do explorador).
- Arquivos dentro de `Modules` (ou que terminam em `.module.luau`) são **módulos**: só rodam quando outro script chama `require("Nome")`.
- Um script pode ser desativado pelo menu "⋯" do explorador.
- **Parar** encerra a VM e limpa o mundo. Cada execução começa do zero.
- Com o jogo rodando, a linha de comando do console executa Luau na mesma VM (ex.: `workspace.MeuBloco.Color = Color3.new(0,0,1)`).

>! Laços infinitos sem `task.wait()` travariam o jogo. O GameForge interrompe um script que passa alguns segundos sem devolver o controle e mostra o erro "Tempo de execução esgotado" com a linha.

## Erros

Erros de sintaxe são sublinhados no editor enquanto você digita. Erros de execução aparecem no console com **arquivo:linha** clicável e a linha é marcada no editor.

```luau Um erro de propósito
local vida = 100
print("Vida:", vida)
local x = nil
print(x.Nome) -- erro: tentativa de indexar nil
```

::: exercicio Mudando a cor
Altere o primeiro exemplo para que o bloco fique azul e duas vezes maior.
```luau
local bloco = Instance.new("Part")
bloco.Position = Vector3.new(0, 5, -10)
bloco.Size = Vector3.new(8, 8, 8)
bloco.Color = Color3.fromRGB(0, 0, 255)
bloco.Anchored = true
bloco.Parent = workspace
```
:::

<!-- capitulo id=fundamentos num=1 group="Linguagem Luau" title="Fundamentos de Luau" -->
Luau é a linguagem derivada do Lua 5.1 usada em jogos. O GameForge executa **Luau de verdade**: o mesmo compilador e a mesma VM oficiais, com a biblioteca padrão (`string`, `table`, `math`, `os.clock`, `coroutine`, `buffer`, `utf8`, `bit32`) e as extensões do Luau, como tipos opcionais, `+=`, `continue` e interpolação de strings.

## Comentários

```luau-frag
-- comentário de uma linha
--[[ comentário
     de várias linhas ]]
```

## Imprimindo valores

`print` escreve no console. `warn` escreve um aviso (amarelo). `error` gera um erro.

```luau Print e warn
print("Olá, mundo!")
print("Soma:", 2 + 3, "Texto e número juntos")
warn("Isto é um aviso")
local nome = "Ana"
print(`Bem-vinda, {nome}! 2 x 21 = {2 * 21}`)
```

## Tipos de valores

| Tipo | Exemplo |
|---|---|
| nil | `nil` (ausência de valor) |
| boolean | `true`, `false` |
| number | `10`, `3.14`, `-2`, `1e6` |
| string | `"texto"`, `'texto'`, `[[várias linhas]]` |
| table | `{1, 2, 3}`, `{nome = "Ana"}` |
| function | `function() end` |
| Vector3, Color3, CFrame… | tipos do motor GameForge |
| Instance | objetos do jogo (`Part`, `Model`…) |

`typeof(valor)` informa o tipo, inclusive dos tipos do motor:

```luau typeof
print(typeof(10), typeof("a"), typeof({}), typeof(nil))
print(typeof(Vector3.new(1, 2, 3)), typeof(workspace))
```

## Operadores

| Operador | Significado |
|---|---|
| `+ - * / % ^` | aritméticos (`//` é divisão inteira) |
| `..` | junta textos |
| `== ~= < > <= >=` | comparação (`~=` é "diferente") |
| `and or not` | lógicos |
| `#` | tamanho de string ou lista |
| `+= -= *= /= ..=` | atribuição composta |

```luau Operadores
local a, b = 7, 2
print(a + b, a - b, a * b, a / b, a // b, a % b, a ^ b)
print("Game" .. "Forge", #"Luau")
local pontos = 10
pontos += 5
print(pontos, pontos > 12 and "muitos" or "poucos")
```

::: exercicio Calculadora
Crie duas variáveis `largura` e `altura` e imprima a área e o perímetro de um retângulo usando interpolação de strings.
```luau
local largura, altura = 8, 3
print(`Área: {largura * altura}, perímetro: {2 * (largura + altura)}`)
```
:::

<!-- capitulo id=variaveis num=2 group="Linguagem Luau" title="Variáveis" -->
Variáveis guardam valores. Em Luau use sempre `local`: a variável fica visível só no bloco onde foi criada, o que evita conflitos entre scripts.

```luau Criando variáveis
local nome = "Guerreiro"
local vida = 100
local vivo = true
local velocidade = 16.5
print(nome, vida, vivo, velocidade)

vida = vida - 25 -- variáveis podem mudar de valor
print("Vida agora:", vida)
```

## Escopo

```luau Escopo
local x = 1
do
    local x = 2 -- outra variável, só existe dentro do do...end
    print("dentro:", x)
end
print("fora:", x)
```

## Tipos opcionais

Luau aceita anotações de tipo. Elas documentam o código e o verificador aponta alguns erros; a execução não muda.

```luau Anotações de tipo
local moedas: number = 0
local jogador: string = "Ana"
local function dobro(n: number): number
    return n * 2
end
print(jogador, dobro(moedas + 21))
```

## Constantes e nomes

- Nomes podem ter letras, números e `_`, sem começar com número: `vidaMaxima`, `VELOCIDADE_BASE`.
- Maiúsculas importam: `Vida` e `vida` são diferentes.
- Por convenção, valores que não mudam ficam em MAIÚSCULAS.

## Variáveis globais compartilhadas

Variáveis sem `local` são globais **do script**. Para compartilhar dados entre scripts use o módulo (`require`), a tabela `shared` ou atributos de objetos:

```luau Compartilhando com shared
shared.recorde = 50
print("Recorde salvo em shared:", shared.recorde)
workspace:SetAttribute("Fase", 2)
print("Fase:", workspace:GetAttribute("Fase"))
```

::: exercicio Troca de valores
Crie `a = 5` e `b = 9` e troque os valores das duas usando atribuição múltipla.
```luau
local a, b = 5, 9
a, b = b, a
print(a, b) -- 9 5
```
:::

<!-- capitulo id=funcoes num=3 group="Linguagem Luau" title="Funções" -->
Funções agrupam código reutilizável. Recebem parâmetros e podem devolver um ou mais valores.

```luau Funções básicas
local function saudar(nome)
    print("Olá, " .. nome .. "!")
end
saudar("Ana")
saudar("Bruno")

local function somar(a, b)
    return a + b
end
print("3 + 4 =", somar(3, 4))
```

## Vários retornos e valores padrão

```luau Vários retornos
local function minMax(lista)
    local menor, maior = math.huge, -math.huge
    for _, v in lista do
        menor = math.min(menor, v)
        maior = math.max(maior, v)
    end
    return menor, maior
end
local mn, mx = minMax({ 4, 9, 1, 7 })
print("menor", mn, "maior", mx)

local function dano(quantidade)
    quantidade = quantidade or 10 -- valor padrão
    return quantidade
end
print(dano(), dano(35))
```

## Funções como valores

Funções podem ser guardadas em variáveis, tabelas e passadas para outras funções. É assim que os **eventos** funcionam.

```luau Funções anônimas
local function repetir(vezes, acao)
    for i = 1, vezes do
        acao(i)
    end
end
repetir(3, function(i)
    print("Rodada", i)
end)
```

## Número variável de argumentos

```luau Varargs
local function media(...)
    local soma, n = 0, select("#", ...)
    for _, v in { ... } do
        soma += v
    end
    return soma / n
end
print(media(10, 20, 30))
```

## Funções que esperam

`task.wait(segundos)` pausa a função sem travar o jogo. `task.spawn` roda uma função em paralelo e `task.delay` agenda para depois.

```luau task.wait, spawn e delay
task.spawn(function()
    for i = 3, 1, -1 do
        print("Contagem:", i)
        task.wait(1)
    end
    print("Já!")
end)
task.delay(4, function()
    print("Isto roda 4 segundos depois")
end)
print("O script principal continua sem esperar")
```

::: exercicio Função de cura
Escreva `curar(vida, quantidade)` que devolve a nova vida, sem passar de 100.
```luau
local function curar(vida, quantidade)
    return math.min(vida + quantidade, 100)
end
print(curar(80, 30)) -- 100
print(curar(40, 30)) -- 70
```
:::

<!-- capitulo id=condicoes num=4 group="Linguagem Luau" title="Condições" -->
`if` executa código apenas quando uma condição é verdadeira. Em Luau somente `false` e `nil` são falsos; `0` e `""` são verdadeiros.

```luau if, elseif, else
local vida = 35
if vida <= 0 then
    print("Derrotado")
elseif vida < 50 then
    print("Ferido! Procure uma poção.")
else
    print("Saudável")
end
```

## Combinando condições

```luau and, or, not
local temChave = true
local nivel = 4
if temChave and nivel >= 3 then
    print("A porta abriu")
end
if not temChave or nivel < 2 then
    print("Ainda não pode entrar")
end
```

## Expressão if

Luau permite `if` dentro de uma expressão:

```luau Expressão if
local pontos = 1200
local medalha = if pontos >= 1000 then "Ouro" elseif pontos >= 500 then "Prata" else "Bronze"
print("Medalha:", medalha)
```

## Verificando objetos

Antes de usar um objeto, confira se ele existe com `FindFirstChild`:

```luau Checando se existe
local bloco = workspace:FindFirstChild("Porta")
if bloco then
    print("Achei a porta")
else
    print("Não existe nenhum objeto chamado Porta no workspace")
end
```

::: exercicio Par ou ímpar
Imprima se o número 17 é par ou ímpar usando o operador `%`.
```luau
local n = 17
if n % 2 == 0 then
    print(n, "é par")
else
    print(n, "é ímpar")
end
```
:::

<!-- capitulo id=repeticoes num=5 group="Linguagem Luau" title="Repetições" -->
Laços repetem código. Use-os para criar muitos objetos, percorrer listas ou executar lógica contínua.

## for numérico

```luau Escada de blocos
for i = 1, 10 do
    local degrau = Instance.new("Part")
    degrau.Size = Vector3.new(6, 1, 3)
    degrau.Position = Vector3.new(0, i, -6 - i * 3)
    degrau.Color = Color3.fromHSV(i / 10, 0.8, 1)
    degrau.Anchored = true
    degrau.Parent = workspace
end
print("Escada criada! Ande para frente e pule.")
```

O terceiro número é o passo: `for i = 10, 1, -1` conta para trás.

## for genérico

Percorre tabelas. Em Luau basta `for chave, valor in tabela do`; `ipairs` e `pairs` também funcionam.

```luau Percorrendo listas
local frutas = { "maçã", "banana", "uva" }
for i, fruta in frutas do
    print(i, fruta)
end
local precos = { espada = 50, escudo = 30 }
for item, preco in pairs(precos) do
    print(item, "custa", preco)
end
```

## while e repeat

```luau while e repeat
local n = 1
while n < 100 do
    n *= 2
end
print("Primeira potência de 2 acima de 100:", n)

local tentativas = 0
repeat
    tentativas += 1
until math.random(1, 6) == 6
print("Tirei 6 depois de", tentativas, "tentativas")
```

## break e continue

```luau break e continue
for i = 1, 10 do
    if i % 2 == 0 then
        continue -- pula os pares
    end
    if i > 7 then
        break -- para o laço
    end
    print(i)
end
```

## Laços do jogo

Um laço infinito precisa de `task.wait()` ou do evento `RunService.Heartbeat`, que roda a cada quadro:

```luau Bloco piscando
local bloco = Instance.new("Part")
bloco.Size = Vector3.new(4, 4, 4)
bloco.Position = Vector3.new(0, 3, -12)
bloco.Anchored = true
bloco.Material = Enum.Material.Neon
bloco.Parent = workspace
while true do
    bloco.Color = Color3.fromRGB(255, 60, 60)
    task.wait(0.5)
    bloco.Color = Color3.fromRGB(60, 60, 255)
    task.wait(0.5)
end
```

::: exercicio Pirâmide
Construa uma pirâmide de 5 andares com dois laços `for`.
```luau
for andar = 0, 4 do
    local lado = 5 - andar
    for x = 1, lado do
        for z = 1, lado do
            local p = Instance.new("Part")
            p.Size = Vector3.new(2, 2, 2)
            p.Position = Vector3.new((x - lado / 2) * 2 + andar, andar * 2 + 1, (z - lado / 2) * 2 - 20 + andar)
            p.Color = Color3.fromRGB(230, 200, 120)
            p.Material = Enum.Material.Sandstone
            p.Anchored = true
            p.Parent = workspace
        end
    end
end
```
:::

<!-- capitulo id=tabelas num=6 group="Linguagem Luau" title="Tabelas" -->
Tabelas são a única estrutura de dados do Luau: servem como listas, dicionários, objetos e módulos.

## Listas

```luau Listas
local inventario = { "Espada", "Poção" }
table.insert(inventario, "Escudo")
print(#inventario, inventario[1], inventario[3]) -- índices começam em 1
table.remove(inventario, 1)
print(table.concat(inventario, ", "))
print("Tem poção?", table.find(inventario, "Poção") ~= nil)
table.sort(inventario)
print(table.concat(inventario, ", "))
```

## Dicionários

```luau Dicionários
local heroi = {
    nome = "Lia",
    vida = 100,
    habilidades = { "Pulo duplo", "Corrida" },
}
heroi.nivel = 3
heroi["ouro"] = 250
print(heroi.nome, heroi.nivel, heroi.ouro, heroi.habilidades[2])
heroi.ouro = nil -- remove a chave
for chave, valor in heroi do
    print(chave, valor)
end
```

## Tabelas como objetos

Com `:` a função recebe a própria tabela como `self`. Metatabelas permitem criar "classes":

```luau Classe com metatabela
local Inimigo = {}
Inimigo.__index = Inimigo

function Inimigo.new(nome, vida)
    return setmetatable({ nome = nome, vida = vida }, Inimigo)
end

function Inimigo:receberDano(qtd)
    self.vida = math.max(self.vida - qtd, 0)
    print(`{self.nome} recebeu {qtd} de dano. Vida: {self.vida}`)
end

local slime = Inimigo.new("Slime", 30)
slime:receberDano(12)
slime:receberDano(25)
```

## Módulos

Um arquivo na pasta **Modules** devolve uma tabela. Outros scripts o carregam com `require("NomeDoArquivo")`. O projeto padrão tem o módulo `Utilidades`:

```luau-frag Uso de um módulo
-- Modules/Pontuacao.luau
local Pontuacao = {}
local total = 0
function Pontuacao.adicionar(n)
    total += n
    return total
end
return Pontuacao

-- Scripts/Main.luau
local Pontuacao = require("Pontuacao")
print(Pontuacao.adicionar(10))
```

## Funções úteis

| Função | O que faz |
|---|---|
| `table.insert(t, v)` / `table.insert(t, i, v)` | adiciona |
| `table.remove(t, i)` | remove e devolve |
| `table.find(t, v)` | índice do valor ou nil |
| `table.sort(t, comparador?)` | ordena |
| `table.concat(t, sep)` | junta em texto |
| `table.clone(t)` | cópia rasa |
| `table.clear(t)` | esvazia |
| `#t` | tamanho da lista |

::: exercicio Ranking
Ordene a lista de jogadores pela pontuação, do maior para o menor, e imprima o ranking.
```luau
local jogadores = {
    { nome = "Ana", pontos = 120 },
    { nome = "Beto", pontos = 340 },
    { nome = "Caio", pontos = 90 },
}
table.sort(jogadores, function(a, b)
    return a.pontos > b.pontos
end)
for pos, j in jogadores do
    print(`{pos}º {j.nome} - {j.pontos}`)
end
```
:::
