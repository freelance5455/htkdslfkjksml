<!-- capitulo id=jogos-completos num=21 group="Projetos" title="Criação de jogos completos" -->
Este capítulo junta tudo: mundo, regras, interface, sons e salvamento. Comece pelo planejamento:

- **Objetivo**: o que o jogador precisa fazer para vencer?
- **Mundo**: terreno, plataformas, obstáculos, decoração.
- **Regras**: pontos, vida, tempo, inimigos.
- **Retorno**: interface, sons, partículas, notificações.
- **Progresso**: o que é salvo entre partidas.

## Organização do projeto

| Pasta | Conteúdo |
|---|---|
| `Scripts/` | scripts que rodam ao executar (`Main.luau`, `Mundo.luau`, `Inimigos.luau`…) |
| `Modules/` | módulos chamados com `require` (configurações, funções utilitárias, classes) |

Use **Arquivo → Salvar** (Ctrl+S) com frequência. O GameForge guarda versões automáticas; volte a qualquer uma em **Arquivo → Versões e backups**. Para levar o projeto a outro aparelho use **Exportar projeto (.zip)** e **Importar**. **Exportar jogo (HTML)** gera um arquivo único que roda o jogo sem o editor e sem internet.

## Terreno

```luau Ilha com colinas e lago
local terrain = workspace.Terrain
workspace.Baseplate:Destroy()
terrain:GenerateHills({ Size = 300, Height = 30, Seed = 7, Scale = 70, Material = "Grass", WaterLevel = 4 })
terrain:FillBlock(CFrame.new(0, 2, 0), Vector3.new(20, 4, 20), Enum.Material.Sand)
terrain:FillBall(Vector3.new(40, 10, -40), 12, Enum.Material.Rock)
terrain:FillCylinder(CFrame.new(-40, 6, -30), 12, 6, Enum.Material.Snow)
print("Altura do terreno em (40, -40):", terrain:HeightAt(40, -40))
for i = 1, 12 do
    local x, z = math.random(-120, 120), math.random(-120, 120)
    local y = terrain:HeightAt(x, z)
    if y and y > 5 then
        Models.Create("PineTree", Vector3.new(x, y, z))
    end
end
local player = Game:GetService("Players").LocalPlayer
player:LoadCharacter()
```

| Terrain | Descrição |
|---|---|
| `:GenerateHills({Size, Height, Seed, Scale, Material, WaterLevel})` | gera colinas (e água abaixo de `WaterLevel`) |
| `:FillBlock(cframe, tamanho, material)` | bloco de terreno |
| `:FillBall(centro, raio, material)` | esfera |
| `:FillCylinder(cframe, altura, raio, material)` | cilindro |
| `:FillWedge(cframe, tamanho, material)` | rampa |
| `:HeightAt(x, z)` | altura do terreno no ponto |
| `:Clear()` | apaga o terreno |
| `WaterColor`, `WaterTransparency` | aparência da água |

## Jogo completo: Corrida das Moedas

Pegue as 10 moedas antes de o tempo acabar, sem cair na lava. O recorde fica salvo. Clique em **Novo script** para levar ao projeto, ou **▶ Executar** para jogar agora.

```luau Corrida das Moedas
-- ===== Configuração =====
local TEMPO_LIMITE = 60
local TOTAL_MOEDAS = 10

local Players = Game:GetService("Players")
local SoundService = Game:GetService("SoundService")
local TweenService = Game:GetService("TweenService")
local RunService = Game:GetService("RunService")
local dados = Game:GetService("DataStoreService"):GetDataStore("CorridaDasMoedas")

Game.SetTime(16)
Game.SetWeather("Clear")

-- ===== Mundo =====
workspace.Baseplate.Material = Enum.Material.CrackedLava
workspace.Baseplate.Color = Color3.fromRGB(255, 70, 0)

local function plataforma(pos, tamanho, cor)
    local p = Instance.new("Part")
    p.Size = tamanho
    p.Position = pos
    p.Color = cor or Color3.fromRGB(110, 110, 120)
    p.Material = Enum.Material.Concrete
    p.Anchored = true
    p.Parent = workspace
    return p
end

local spawn = Instance.new("SpawnLocation")
spawn.Size = Vector3.new(12, 1, 12)
spawn.Position = Vector3.new(0, 8, 0)
spawn.Anchored = true
spawn.Parent = workspace
local player = Game.CreatePlayer("Corredor") -- nasce sobre o SpawnLocation

local posicoes = {}
local angulo, raio, altura = 0, 14, 8
for i = 1, TOTAL_MOEDAS do
    angulo += 10 / raio -- passo de ~10 studs entre plataformas
    raio += 1
    altura += 1.5
    local pos = Vector3.new(math.cos(angulo) * raio, altura, math.sin(angulo) * raio)
    plataforma(pos, Vector3.new(7, 1, 7), Color3.fromHSV(i / TOTAL_MOEDAS, 0.5, 0.9))
    table.insert(posicoes, pos + Vector3.new(0, 3, 0))
end
-- plataforma móvel
local movel = plataforma(Vector3.new(-12, 10, 0), Vector3.new(6, 1, 6), Color3.fromRGB(80, 200, 255))
TweenService:Create(movel, TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), { Position = Vector3.new(-12, 18, 12) }):Play()

-- ===== Interface =====
local gui = Instance.new("ScreenGui")
gui.Parent = player.PlayerGui
local topo = Instance.new("TextLabel")
topo.Position = UDim2.fromOffset(12, 12)
topo.Size = UDim2.fromOffset(250, 40)
topo.BackgroundColor3 = Color3.fromRGB(15, 15, 25)
topo.BackgroundTransparency = 0.25
topo.TextColor3 = Color3.new(1, 1, 1)
topo.TextSize = 18
topo.Font = Enum.Font.GothamBold
topo.Parent = gui
Instance.new("UICorner").Parent = topo

-- ===== Regras =====
local coletadas = 0
local tempo = TEMPO_LIMITE
local fim = false
local recorde = dados:GetAsync("melhorTempo")

local function atualizar()
    topo.Text = `Moedas {coletadas}/{TOTAL_MOEDAS}   Tempo {math.ceil(tempo)}s`
end
atualizar()

local function terminar(venceu)
    if fim then return end
    fim = true
    if venceu then
        local usado = TEMPO_LIMITE - tempo
        SoundService:PlayLocalSound("sfx:win")
        local msg = string.format("Você venceu em %.1f s!", usado)
        if not recorde or usado < recorde then
            recorde = usado
            dados:SetAsync("melhorTempo", usado)
            msg ..= " Novo recorde!"
        end
        Game.Notify(msg, 6)
        player.Character.Humanoid:LoadAnimation("Cheer"):Play()
    else
        SoundService:PlayLocalSound("sfx:lose")
        Game.Notify("O tempo acabou! Execute de novo para tentar.", 6)
    end
    print("Fim de jogo. Recorde:", recorde and string.format("%.1f s", recorde) or "nenhum")
end

for _, pos in posicoes do
    local moeda = Models.Create("Coin", pos)
    local pegou = false
    for _, parte in moeda:GetDescendants() do
        if parte:IsA("BasePart") then
            parte.Touched:Connect(function(outro)
                if pegou or fim or not outro.Parent:FindFirstChildOfClass("Humanoid") then return end
                pegou = true
                coletadas += 1
                SoundService:PlayLocalSound("sfx:coin")
                moeda:Destroy()
                atualizar()
                if coletadas == TOTAL_MOEDAS then terminar(true) end
            end)
        end
    end
end

-- lava: o Baseplate causa dano
workspace.Baseplate.Touched:Connect(function(outro)
    local h = outro.Parent and outro.Parent:FindFirstChildOfClass("Humanoid")
    if h and h.Health > 0 then
        h.Health = 0
        SoundService:PlayLocalSound("sfx:hurt")
    end
end)
Players.RespawnTime = 1
player.CharacterAdded:Connect(function() Game.Notify("Cuidado com a lava!", 2) end)

RunService.Heartbeat:Connect(function(dt)
    if fim then return end
    tempo = math.max(tempo - dt, 0)
    atualizar()
    if tempo <= 0 then terminar(false) end
end)

print("Recorde atual:", recorde and string.format("%.1f s", recorde) or "nenhum")
Game.Notify("Pegue as 10 moedas subindo as plataformas!", 4)
```

## Dicas para jogos maiores

- Separe responsabilidades: um script para o mundo, outro para regras, módulos para configurações.
- Prefira eventos (`Touched`, `Changed`, `Heartbeat`) a laços com `task.wait` muito curtos.
- Agrupe objetos em `Folder` e `Model` para encontrá-los e destruí-los de uma vez.
- Use `CollectionService` para dar o mesmo comportamento a vários objetos.
- Use `pcall` para tratar erros sem parar o jogo:

```luau pcall
local ok, erro = pcall(function()
    local x = nil
    return x.campo
end)
print("Deu certo?", ok, "Erro:", erro)
```

::: exercicio Seu primeiro jogo completo
Modifique a Corrida das Moedas: adicione um inimigo que patrulha a plataforma inicial (capítulo 18) e uma poção na mochila (capítulo 19). Depois exporte o jogo em **Arquivo → Exportar jogo (HTML)**.
```luau
-- Trecho para adicionar ao final do script:
local guarda = Game.CreateNPC("Guarda", Vector3.new(4, 12, 4))
task.spawn(function()
    while guarda.Humanoid.Health > 0 do
        guarda.Humanoid:MoveTo(Vector3.new(-4, 9, -4))
        guarda.Humanoid.MoveToFinished:Wait()
        guarda.Humanoid:MoveTo(Vector3.new(4, 9, 4))
        guarda.Humanoid.MoveToFinished:Wait()
    end
end)
```
:::

<!-- capitulo id=referencia num=A group="Referência" title="Referência da API" -->
Lista do que está implementado no motor GameForge. O autocompletar do editor usa esta mesma lista (Ctrl+Espaço).

## Globais

| Nome | Descrição |
|---|---|
| `Game` / `game` | raiz do jogo; `:GetService(nome)` e atalhos (`SetGravity`, `SetWeather`, `SetTime`, `CreatePlayer`, `CreateNPC`, `SetCameraMode`, `Notify`, `BindToClose`) |
| `workspace` / `Workspace` | mundo 3D |
| `script` | o script atual |
| `shared` | tabela compartilhada entre scripts |
| `Instance.new(classe, pai?)` | cria objetos |
| `Models.Create(tipo, posição?, escala?)`, `Models.List()` | modelos 3D prontos |
| `task.wait`, `task.spawn`, `task.delay`, `task.defer`, `task.cancel` | agendamento |
| `wait`, `spawn`, `delay`, `tick`, `time` | versões antigas |
| `print`, `warn`, `error`, `pcall`, `xpcall`, `typeof`, `require` | básico |
| `Enum.*` | enumerações |

## Tipos de dados

| Tipo | Construtores e membros |
|---|---|
| `Vector3` | `new(x,y,z)`, `zero`, `one`; `X Y Z Magnitude Unit`; `:Dot :Cross :Lerp :Abs :Floor :Min :Max :Angle :FuzzyEq`; `+ - * /` |
| `Vector2` | `new(x,y)`; `X Y Magnitude Unit`; `:Dot :Lerp` |
| `Color3` | `new(r,g,b)` (0–1), `fromRGB`, `fromHSV`, `fromHex`; `R G B`; `:Lerp :ToHex :ToHSV` |
| `CFrame` | `new(x,y,z)`, `new(pos, alvo)`, `lookAt`, `Angles`, `fromEulerAnglesXYZ`, `fromOrientation`; `Position LookVector RightVector UpVector`; `:Inverse :Lerp :ToWorldSpace :ToObjectSpace :PointToWorldSpace :GetComponents :ToEulerAnglesXYZ :ToOrientation`; `*` |
| `UDim`, `UDim2` | `new`, `fromScale`, `fromOffset`; `:Lerp` |
| `BrickColor` | `new(nome)`; `.Color`, `.Name` |
| `NumberRange`, `NumberSequence`, `ColorSequence` | partículas |
| `TweenInfo` | `new(tempo, estilo, direção, repetições, volta, atraso)` |
| `RaycastParams` | `new()`; `FilterDescendantsInstances`, `FilterType` |

## Classes

| Classe | Principais membros |
|---|---|
| `Instance` | `Name Parent ClassName`; `:Clone :Destroy :FindFirstChild :WaitForChild :GetChildren :GetDescendants :IsA :SetAttribute :GetAttribute :GetPropertyChangedSignal`; `Changed ChildAdded ChildRemoved Destroying` |
| `BasePart` (`Part`, `WedgePart`, `TrussPart`, `Seat`, `SpawnLocation`) | `Position Size CFrame Orientation Color BrickColor Material Transparency Reflectance Anchored CanCollide CanTouch CastShadow Elasticity Friction Density Massless AssemblyLinearVelocity`; `:ApplyImpulse :GetMass :GetTouchingParts`; `Touched TouchEnded` |
| `Model` | `PrimaryPart`; `:PivotTo :GetPivot :MoveTo :GetBoundingBox :GetExtentsSize` |
| `Humanoid` | ver capítulo 12 |
| `Player` | `Name DisplayName UserId Character Backpack PlayerGui CameraMode RespawnLocation`; `:LoadCharacter :GetMouse :DistanceFromCharacter`; `CharacterAdded CharacterRemoving Chatted` |
| `Camera` | `CFrame CameraType FieldOfView Focus ViewportSize`; `:WorldToScreenPoint :ScreenPointToRay` |
| `Terrain` | ver capítulo 21 |
| `Light` (`PointLight`, `SpotLight`, `SurfaceLight`) | `Brightness Color Range Angle Face Shadows Enabled` |
| `Sound` | ver capítulo 16 |
| `Tool` | `Enabled RequiresHandle TextureId ToolTip CanBeDropped`; `Activated Deactivated Equipped Unequipped` |
| `ProximityPrompt` | `ActionText ObjectText HoldDuration KeyboardKeyCode MaxActivationDistance Enabled`; `Triggered` |
| `ClickDetector` | `MaxActivationDistance`; `MouseClick` |
| `Decal`, `Texture` | `Texture Face Color3 Transparency StudsPerTileU StudsPerTileV` |
| Efeitos | `ParticleEmitter Fire Smoke Sparkles Explosion ForceField` |
| Valores | `IntValue NumberValue StringValue BoolValue ObjectValue Vector3Value Color3Value` (`Value`, `Changed`) |
| Comunicação | `BindableEvent BindableFunction RemoteEvent RemoteFunction` |
| Organização | `Folder Model Configuration WeldConstraint Animation` |
| GUI | `ScreenGui BillboardGui Frame TextLabel TextButton TextBox ImageLabel ImageButton ScrollingFrame UICorner UIStroke UIPadding UIGradient UIListLayout UIGridLayout UIAspectRatioConstraint` |

## Serviços

`Workspace Lighting Weather Players RunService UserInputService ContextActionService TweenService Debris SoundService HttpService DataStoreService PathfindingService StarterGui StarterPack StarterPlayer ReplicatedStorage ServerStorage ServerScriptService Teams Chat CollectionService`

## Enumerações

`Material PartType NormalId KeyCode UserInputType UserInputState EasingStyle EasingDirection PlaybackState CameraType CameraMode WeatherType Font TextXAlignment TextYAlignment FillDirection HorizontalAlignment VerticalAlignment SortOrder ScaleType HumanoidStateType AnimationPriority PathStatus PathWaypointAction RaycastFilterType SurfaceType`

## Diferenças em relação ao Roblox

- O jogo roda localmente: não há servidor, rede ou multijogador. `RemoteEvent` funciona dentro da mesma VM (útil para manter código compatível).
- `HttpService` não acessa a internet.
- `DataStoreService` grava no aparelho.
- A física usa caixas alinhadas aos eixos e esferas, sem rotação causada por colisões.
- IDs de imagens e sons do Roblox (`rbxassetid://`) não existem; use `gf://icons/...`, `sfx:...`, `ambient:...`, `music:...` ou endereços `http(s)` (estes precisam de internet).
- Personagens têm corpo próprio do GameForge e animações embutidas (capítulo 13).
