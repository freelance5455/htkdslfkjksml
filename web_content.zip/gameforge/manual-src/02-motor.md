<!-- capitulo id=eventos num=7 group="Motor GameForge" title="Eventos" -->
Eventos avisam quando algo acontece: um toque, uma tecla, um clique, a morte de um personagem, cada quadro do jogo. Você **conecta** uma função a um evento com `:Connect`.

```luau Touched: bloco que muda de cor
local bloco = Instance.new("Part")
bloco.Size = Vector3.new(6, 1, 6)
bloco.Position = Vector3.new(0, 0.5, -10)
bloco.Anchored = true
bloco.Color = Color3.fromRGB(200, 200, 200)
bloco.Parent = workspace

bloco.Touched:Connect(function(outro)
    local humanoid = outro.Parent and outro.Parent:FindFirstChildOfClass("Humanoid")
    if humanoid then
        bloco.Color = Color3.fromRGB(math.random(0, 255), math.random(0, 255), math.random(0, 255))
        print(outro.Parent.Name, "pisou no bloco")
    end
end)
print("Ande até o bloco cinza à frente")
```

## Métodos de um evento

| Método | Uso |
|---|---|
| `evento:Connect(fn)` | chama `fn` sempre; devolve uma conexão |
| `evento:Once(fn)` | chama só na primeira vez |
| `evento:Wait()` | pausa o script até o evento acontecer e devolve os argumentos |
| `conexao:Disconnect()` | desliga a conexão |

```luau Desconectando
local RunService = Game:GetService("RunService")
local tempo = 0
local conexao
conexao = RunService.Heartbeat:Connect(function(dt)
    tempo += dt
    if tempo >= 3 then
        print("Passaram 3 segundos; desligando o Heartbeat")
        conexao:Disconnect()
    end
end)
```

## Teclado e toque

`UserInputService.InputBegan` recebe um objeto `input` com `KeyCode`, `UserInputType` e `Position`. O segundo argumento é `true` se a interface já usou a entrada (por exemplo, digitando numa TextBox).

```luau Teclas
local UserInputService = Game:GetService("UserInputService")
UserInputService.InputBegan:Connect(function(input, processado)
    if processado then return end
    if input.KeyCode == Enum.KeyCode.E then
        print("Você apertou E")
    elseif input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
        print("Clique/toque em", input.Position.X, input.Position.Y)
    end
end)
print("Clique na janela do jogo e aperte E")
```

`ContextActionService:BindAction` liga uma ação a teclas e, no celular, cria um botão na tela:

```luau Botão de ação (funciona no celular)
local ContextActionService = Game:GetService("ContextActionService")
local function acao(nome, estado, input)
    if estado == Enum.UserInputState.Begin then
        Game.Notify("Ação especial!", 2)
    end
end
ContextActionService:BindAction("Especial", acao, true, Enum.KeyCode.F)
ContextActionService:SetTitle("Especial", "F")
print("Aperte F ou toque no botão F")
```

## Cliques e prompts em objetos

```luau ClickDetector e ProximityPrompt
local botao = Instance.new("Part")
botao.Size = Vector3.new(2, 2, 2)
botao.Position = Vector3.new(-5, 1, -8)
botao.Anchored = true
botao.Color = Color3.fromRGB(0, 170, 255)
botao.Parent = workspace
local click = Instance.new("ClickDetector")
click.Parent = botao
click.MouseClick:Connect(function(jogador)
    print(jogador.Name, "clicou no cubo azul")
end)

local bau = Instance.new("Part")
bau.Size = Vector3.new(3, 2, 2)
bau.Position = Vector3.new(5, 1, -8)
bau.Anchored = true
bau.Color = Color3.fromRGB(140, 90, 40)
bau.Parent = workspace
local prompt = Instance.new("ProximityPrompt")
prompt.ActionText = "Abrir"
prompt.ObjectText = "Baú"
prompt.Parent = bau
prompt.Triggered:Connect(function(jogador)
    print("Baú aberto! Você ganhou 10 moedas")
    prompt.Enabled = false
end)
```

## Eventos de propriedades

```luau GetPropertyChangedSignal
local valor = Instance.new("IntValue")
valor.Name = "Moedas"
valor.Parent = workspace
valor.Changed:Connect(function(novo)
    print("Moedas mudou para", novo)
end)
for i = 1, 3 do
    valor.Value += 5
    task.wait(0.5)
end
```

## Eventos próprios

`BindableEvent` cria eventos entre scripts:

```luau BindableEvent
local evento = Instance.new("BindableEvent")
evento.Name = "FaseConcluida"
evento.Parent = Game:GetService("ReplicatedStorage")
evento.Event:Connect(function(fase)
    print("Fase", fase, "concluída!")
end)
evento:Fire(1)
```

::: exercicio Contador de pulos
Conte quantas vezes o jogador pula usando `Humanoid.Jumping` e mostre no console.
```luau
local player = Game:GetService("Players").LocalPlayer
local personagem = player.Character or player.CharacterAdded:Wait()
local humanoid = personagem:WaitForChild("Humanoid")
local pulos = 0
humanoid.Jumping:Connect(function(ativo)
    if ativo then
        pulos += 1
        print("Pulos:", pulos)
    end
end)
```
:::

<!-- capitulo id=objetos num=8 group="Motor GameForge" title="Objetos" -->
Tudo no jogo é uma **Instance** organizada em árvore: `game` → serviços (`Workspace`, `Lighting`…) → objetos → filhos. Só o que está dentro de `workspace` aparece no mundo 3D.

## Criando objetos

```luau Instance.new
local bloco = Instance.new("Part")
bloco.Name = "Plataforma"
bloco.Position = Vector3.new(0, 5, 0)
bloco.Size = Vector3.new(10, 1, 10)
bloco.Color = Color3.fromRGB(255, 0, 0)
bloco.Anchored = true
bloco.Parent = workspace
print(bloco:GetFullName())
```

> Defina as propriedades **antes** de `Parent`; assim o objeto já aparece pronto.

## Tipos de peças

| Classe | Descrição |
|---|---|
| `Part` | bloco; `Shape` pode ser `Block`, `Ball`, `Cylinder` ou `Wedge` |
| `WedgePart` | rampa |
| `TrussPart` | treliça (escada) |
| `SpawnLocation` | ponto de nascimento do jogador |
| `Seat` | assento: o personagem senta ao tocar |
| `Model` | agrupa várias peças |
| `Folder` | organiza objetos sem efeito visual |

```luau Formas
local formas = { Enum.PartType.Block, Enum.PartType.Ball, Enum.PartType.Cylinder, Enum.PartType.Wedge }
for i, forma in formas do
    local p = Instance.new("Part")
    p.Shape = forma
    p.Size = Vector3.new(4, 4, 4)
    p.Position = Vector3.new(-9 + i * 5, 2, -12)
    p.Color = Color3.fromHSV(i / 5, 0.7, 1)
    p.Anchored = true
    p.Parent = workspace
end
local rampa = Instance.new("WedgePart")
rampa.Size = Vector3.new(6, 3, 8)
rampa.Position = Vector3.new(0, 1.5, -22)
rampa.Anchored = true
rampa.Parent = workspace
```

## Encontrando, clonando e destruindo

| Método | Uso |
|---|---|
| `pai:FindFirstChild("Nome")` | filho pelo nome, ou nil |
| `pai:WaitForChild("Nome")` | espera o filho existir |
| `pai:GetChildren()` / `GetDescendants()` | lista de filhos / todos os descendentes |
| `obj:FindFirstChildOfClass("Humanoid")` | primeiro filho da classe |
| `obj:IsA("BasePart")` | verifica a classe (inclui herança) |
| `obj:Clone()` | cópia (com filhos) |
| `obj:Destroy()` | remove para sempre |
| `Debris:AddItem(obj, s)` | destrói após `s` segundos |

```luau Clonando e destruindo
local Debris = Game:GetService("Debris")
local modelo = Instance.new("Part")
modelo.Size = Vector3.new(2, 2, 2)
modelo.Color = Color3.fromRGB(255, 200, 0)
modelo.Anchored = true
for i = 1, 5 do
    local copia = modelo:Clone()
    copia.Name = "Cubo" .. i
    copia.Position = Vector3.new(i * 3 - 9, 1, -10)
    copia.Parent = workspace
    Debris:AddItem(copia, i) -- cada cubo some depois de i segundos
end
print("Filhos do workspace:", #workspace:GetChildren())
```

## Modelos

`Model` agrupa peças. `PivotTo` move o modelo inteiro e `GetBoundingBox` informa o tamanho. A biblioteca **Models** traz modelos 3D prontos, feitos de peças reais que você pode alterar: `Tree`, `PineTree`, `Rock`, `House`, `Lamp`, `Crate`, `Coin`, `Fence`, `Car`, `Tower`, `Bridge`.

```luau Modelos prontos
print("Modelos disponíveis:", table.concat(Models.List(), ", "))
Models.Create("House", Vector3.new(0, 0, -30))
Models.Create("Tree", Vector3.new(-14, 0, -24))
Models.Create("PineTree", Vector3.new(14, 0, -26), 1.3)
Models.Create("Lamp", Vector3.new(6, 0, -16))
local carro = Models.Create("Car", Vector3.new(-8, 0, -12))
carro:PivotTo(carro:GetPivot() * CFrame.Angles(0, math.rad(45), 0))
for _, peca in carro:GetDescendants() do
    if peca:IsA("BasePart") and peca.Name == "Chassi" then
        peca.Color = Color3.fromRGB(30, 90, 220)
    end
end
```

## Atributos e tags

```luau Atributos e CollectionService
local CollectionService = Game:GetService("CollectionService")
for i = 1, 3 do
    local lava = Instance.new("Part")
    lava.Size = Vector3.new(4, 1, 4)
    lava.Position = Vector3.new(i * 6 - 12, 0.5, -14)
    lava.Material = Enum.Material.CrackedLava
    lava.Color = Color3.fromRGB(255, 80, 0)
    lava.Anchored = true
    lava:SetAttribute("Dano", i * 10)
    lava.Parent = workspace
    CollectionService:AddTag(lava, "Lava")
end
for _, lava in CollectionService:GetTagged("Lava") do
    lava.Touched:Connect(function(outro)
        local h = outro.Parent and outro.Parent:FindFirstChildOfClass("Humanoid")
        if h then h:TakeDamage(lava:GetAttribute("Dano")) end
    end)
end
print("Cuidado com a lava!")
```

::: exercicio Floresta
Use um laço e `Models.Create` para plantar 15 árvores em posições aleatórias.
```luau
for i = 1, 15 do
    local x = math.random(-60, 60)
    local z = math.random(-80, -15)
    local tipo = if math.random() < 0.5 then "Tree" else "PineTree"
    Models.Create(tipo, Vector3.new(x, 0, z), math.random(8, 14) / 10)
end
```
:::

<!-- capitulo id=propriedades num=9 group="Motor GameForge" title="Propriedades" -->
Propriedades descrevem um objeto: posição, tamanho, cor, material, transparência… Basta ler ou atribuir.

## Propriedades de BasePart

| Propriedade | Tipo | Descrição |
|---|---|---|
| `Position` | Vector3 | centro da peça |
| `Size` | Vector3 | tamanho em studs |
| `CFrame` | CFrame | posição + rotação |
| `Orientation` | Vector3 | rotação em graus |
| `Color` | Color3 | cor |
| `BrickColor` | BrickColor | cor por nome |
| `Material` | Enum.Material | aparência/textura |
| `Transparency` | number | 0 = opaco, 1 = invisível |
| `Reflectance` | number | brilho metálico 0–1 |
| `Anchored` | boolean | fica parado (sem gravidade) |
| `CanCollide` | boolean | bloqueia outros objetos |
| `CanTouch` | boolean | dispara `Touched` |
| `CastShadow` | boolean | projeta sombra |
| `Elasticity`, `Friction`, `Density` | number | física |

## Tipos de dados

```luau Vector3, Color3 e CFrame
local a = Vector3.new(1, 2, 3)
local b = Vector3.new(4, 0, 0)
print(a + b, a * 2, (b - a).Magnitude, b.Unit)
print(Color3.fromRGB(255, 128, 0), Color3.new(0, 1, 0), Color3.fromHex("#33AAFF"))
local cf = CFrame.new(0, 5, 0) * CFrame.Angles(0, math.rad(90), 0)
print(cf.Position, cf.LookVector)
print(BrickColor.new("Bright red").Color)
```

## Materiais

```luau Vitrine de materiais
local materiais = { "Plastic", "Wood", "WoodPlanks", "Brick", "Cobblestone", "Concrete", "Metal", "DiamondPlate", "Grass", "Sand", "Ice", "Glass", "Neon", "Marble", "Granite", "CrackedLava" }
for i, nome in materiais do
    local p = Instance.new("Part")
    p.Size = Vector3.new(3, 3, 3)
    local col = (i - 1) % 8
    local lin = (i - 1) // 8
    p.Position = Vector3.new(col * 4 - 14, 1.5 + lin * 4, -14)
    p.Material = Enum.Material[nome]
    p.Color = if nome == "Neon" then Color3.fromRGB(0, 255, 200) else Color3.fromRGB(200, 200, 200)
    p.Anchored = true
    p.Parent = workspace
end
print("Materiais:", #materiais)
```

## Texturas e decalques

`Decal` cola uma imagem numa face; `Texture` repete a imagem. Ícones embutidos funcionam sem internet: `gf://icons/coin`, `heart`, `star`, `sword`, `shield`, `gem`, `key`, `potion`, `trophy`, `bolt`.

>! Imagens com endereço `http(s)://` precisam de internet e de um servidor que permita o carregamento (CORS). Sem conexão, a peça fica sem a imagem.

```luau Decal com ícone embutido
local placa = Instance.new("Part")
placa.Size = Vector3.new(6, 6, 1)
placa.Position = Vector3.new(0, 4, -12)
placa.Anchored = true
placa.Color = Color3.fromRGB(40, 40, 60)
placa.Parent = workspace
local decal = Instance.new("Decal")
decal.Texture = "gf://icons/star"
decal.Face = Enum.NormalId.Back
decal.Parent = placa
local tex = Instance.new("Texture")
tex.Texture = "gf://icons/gem"
tex.Face = Enum.NormalId.Front
tex.StudsPerTileU = 2
tex.StudsPerTileV = 2
tex.Parent = placa
```

## Animando propriedades com Tween

`TweenService:Create(objeto, TweenInfo.new(tempo, estilo, direção, repetições, volta), {propriedades})` interpola suavemente qualquer número, Vector3, Color3, CFrame ou UDim2.

```luau Plataforma que sobe e desce
local TweenService = Game:GetService("TweenService")
local p = Instance.new("Part")
p.Size = Vector3.new(8, 1, 8)
p.Position = Vector3.new(0, 1, -14)
p.Anchored = true
p.Color = Color3.fromRGB(80, 200, 120)
p.Parent = workspace
local info = TweenInfo.new(2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true)
TweenService:Create(p, info, { Position = Vector3.new(0, 10, -14), Color = Color3.fromRGB(255, 220, 0) }):Play()
```

`RepeatCount = -1` repete para sempre; `Reverses = true` volta ao início.

::: exercicio Porta de vidro
Crie uma porta que fica transparente e sem colisão quando o jogador toca nela, e volta ao normal 3 segundos depois.
```luau
local porta = Instance.new("Part")
porta.Size = Vector3.new(6, 8, 1)
porta.Position = Vector3.new(0, 4, -10)
porta.Anchored = true
porta.Material = Enum.Material.Glass
porta.Color = Color3.fromRGB(150, 200, 255)
porta.Parent = workspace
local aberta = false
porta.Touched:Connect(function(outro)
    if aberta or not outro.Parent:FindFirstChildOfClass("Humanoid") then return end
    aberta = true
    porta.Transparency = 0.8
    porta.CanCollide = false
    task.wait(3)
    porta.Transparency = 0
    porta.CanCollide = true
    aberta = false
end)
```
:::

<!-- capitulo id=servicos num=10 group="Motor GameForge" title="Serviços" -->
Serviços são objetos especiais que oferecem recursos do motor. Obtenha com `Game:GetService("Nome")` (ou `game:GetService`). Os mais usados também existem como variáveis globais (`workspace`, `Lighting`, `Weather`, `Players`, `RunService`, `TweenService`, `Debris`, `UserInputService`, `DataStoreService`).

| Serviço | Para que serve |
|---|---|
| `Workspace` | mundo 3D, gravidade, `Raycast`, `Terrain`, câmera |
| `Lighting` | sol, hora do dia, brilho, neblina, céu |
| `Weather` | chuva, neve, tempestade, neblina, vento, raios |
| `Players` | jogador local, personagem, renascimento |
| `RunService` | eventos por quadro (`Heartbeat`, `RenderStepped`) |
| `UserInputService` | teclado, mouse, toque |
| `ContextActionService` | ações com botões na tela |
| `TweenService` | animação de propriedades |
| `Debris` | destruir objetos após um tempo |
| `SoundService` | volume geral, sons locais |
| `PathfindingService` | rotas para NPCs |
| `DataStoreService` | salvar dados no aparelho |
| `HttpService` | JSON e GUID (sem acesso à rede) |
| `CollectionService` | tags |
| `StarterGui`, `StarterPack`, `StarterPlayer` | itens copiados para o jogador ao nascer |
| `ReplicatedStorage`, `ServerStorage`, `ServerScriptService` | guardar objetos fora do mundo |
| `Teams`, `Chat` | equipes e balões de fala |

```luau Listando serviços
local nomes = { "Workspace", "Lighting", "Weather", "Players", "RunService", "TweenService", "SoundService", "DataStoreService" }
for _, nome in nomes do
    local s = Game:GetService(nome)
    print(nome, "->", s.ClassName)
end
```

## Atalhos do objeto Game

| Função | Equivale a |
|---|---|
| `Game.SetGravity(n)` | `workspace.Gravity = n` |
| `Game.SetWeather(tipo, intensidade?)` | `Weather.Type = tipo` |
| `Game.SetTime(hora)` | `Lighting.ClockTime = hora` |
| `Game.CreatePlayer(nome)` | cria o personagem do jogador com esse nome |
| `Game.CreateNPC(nome, posição)` | cria um personagem controlado por script |
| `Game.SetCameraMode("FirstPerson" ou "ThirdPerson")` | modo de câmera |
| `Game.Notify(texto, segundos?)` | notificação na tela |

## Workspace e Raycast

```luau Raycast
local alvo = Instance.new("Part")
alvo.Name = "Alvo"
alvo.Size = Vector3.new(4, 4, 1)
alvo.Position = Vector3.new(0, 2, -20)
alvo.Anchored = true
alvo.Parent = workspace

local resultado = workspace:Raycast(Vector3.new(0, 2, 0), Vector3.new(0, 0, -50))
if resultado then
    print("Acertou", resultado.Instance.Name, "em", resultado.Position, "distância", resultado.Distance)
end
local perto = workspace:GetPartBoundsInRadius(Vector3.new(0, 2, -20), 5)
print("Peças perto do alvo:", #perto)
```

## Câmera

```luau Câmera cinematográfica
local camera = workspace.CurrentCamera
camera.CameraType = Enum.CameraType.Scriptable
Models.Create("Tower", Vector3.new(0, 0, -20))
local angulo = 0
Game:GetService("RunService").Heartbeat:Connect(function(dt)
    angulo += dt * 0.4
    local pos = Vector3.new(math.sin(angulo) * 40, 25, -20 + math.cos(angulo) * 40)
    camera.CFrame = CFrame.lookAt(pos, Vector3.new(0, 8, -20))
end)
```

Use `CameraType = Enum.CameraType.Custom` para voltar à câmera que segue o personagem e `camera.FieldOfView` para o ângulo de visão.

::: exercicio Gravidade da Lua
Deixe a gravidade 6 vezes menor que a padrão (196.2) e aumente o pulo do jogador para testar.
```luau
Game.SetGravity(196.2 / 6)
local player = Game:GetService("Players").LocalPlayer
local char = player.Character or player.CharacterAdded:Wait()
char:WaitForChild("Humanoid").JumpPower = 60
print("Gravidade:", workspace.Gravity)
```
:::

<!-- capitulo id=fisica num=11 group="Motor GameForge" title="Física" -->
O motor de física do GameForge aplica gravidade, colisões, atrito, quique e impulsos às peças com `Anchored = false`.

## Gravidade e queda

```luau Chuva de caixas
Game.SetGravity(196.2)
for i = 1, 20 do
    local caixa = Instance.new("Part")
    caixa.Size = Vector3.new(2, 2, 2)
    caixa.Position = Vector3.new(math.random(-8, 8), 20 + i * 3, -15 + math.random(-4, 4))
    caixa.Color = Color3.fromHSV(math.random(), 0.7, 1)
    caixa.Anchored = false
    caixa.Parent = workspace
    task.wait(0.15)
end
print("As caixas empilham porque colidem")
```

## Velocidade e impulso

```luau Bola quicando
local bola = Instance.new("Part")
bola.Shape = Enum.PartType.Ball
bola.Size = Vector3.new(3, 3, 3)
bola.Position = Vector3.new(-10, 15, -15)
bola.Color = Color3.fromRGB(255, 90, 90)
bola.Elasticity = 0.8
bola.Parent = workspace
bola.AssemblyLinearVelocity = Vector3.new(8, 0, 0)
task.wait(3)
bola:ApplyImpulse(Vector3.new(0, 60, 0) * bola:GetMass())
print("Massa da bola:", bola:GetMass())
```

## Propriedades físicas

| Propriedade | Efeito |
|---|---|
| `Anchored` | `true`: parada; `false`: sofre gravidade |
| `CanCollide` | `false`: atravessável |
| `Elasticity` | 0 a 1, quanto quica |
| `Friction` | atrito ao deslizar |
| `Density` | densidade (massa = densidade × volume) |
| `Massless` | ignora a massa |
| `AssemblyLinearVelocity` | velocidade atual (pode ser alterada) |
| `workspace.Gravity` | aceleração da gravidade (padrão 196.2) |
| `workspace.FallenPartsDestroyHeight` | altura abaixo da qual peças caídas são destruídas |

## Unindo peças

`WeldConstraint` prende duas peças: a `Part1` acompanha a `Part0`.

```luau WeldConstraint
local base = Instance.new("Part")
base.Size = Vector3.new(4, 1, 4)
base.Position = Vector3.new(0, 12, -12)
base.Color = Color3.fromRGB(90, 90, 90)
base.Parent = workspace
local topo = Instance.new("Part")
topo.Size = Vector3.new(1, 3, 1)
topo.Position = Vector3.new(0, 14, -12)
topo.Color = Color3.fromRGB(255, 200, 0)
topo.Parent = workspace
local solda = Instance.new("WeldConstraint")
solda.Part0 = base
solda.Part1 = topo
solda.Parent = base
print("As duas peças caem juntas")
```

## Explosões

```luau Explosão
for x = -2, 2 do
    for y = 0, 4 do
        local tijolo = Instance.new("Part")
        tijolo.Size = Vector3.new(2, 1, 1)
        tijolo.Position = Vector3.new(x * 2, y + 0.5, -16)
        tijolo.Material = Enum.Material.Brick
        tijolo.Color = Color3.fromRGB(170, 70, 50)
        tijolo.Parent = workspace
    end
end
task.wait(2)
local e = Instance.new("Explosion")
e.Position = Vector3.new(0, 2, -15)
e.BlastRadius = 8
e.BlastPressure = 600000
e.Parent = workspace
```

## Limitações conhecidas

> A física do GameForge usa caixas alinhadas aos eixos (AABB) e esferas. Peças giradas colidem como a caixa que as envolve, e corpos dinâmicos não giram por causa de colisões. Para jogos de plataforma, quebra-cabeças e ação isso é suficiente; simulações de veículos ou empilhamentos inclinados não são precisos.

::: exercicio Trampolim
Crie uma peça ancorada que lança o jogador para cima quando ele pisa nela.
```luau
local trampolim = Instance.new("Part")
trampolim.Size = Vector3.new(6, 1, 6)
trampolim.Position = Vector3.new(0, 0.5, -10)
trampolim.Color = Color3.fromRGB(255, 0, 200)
trampolim.Material = Enum.Material.Neon
trampolim.Anchored = true
trampolim.Parent = workspace
trampolim.Touched:Connect(function(outro)
    local raiz = outro.Parent and outro.Parent:FindFirstChild("HumanoidRootPart")
    if raiz then
        raiz.AssemblyLinearVelocity = Vector3.new(0, 120, 0)
    end
end)
```
:::

<!-- capitulo id=personagens num=12 group="Motor GameForge" title="Personagens" -->
Um personagem é um `Model` com `Humanoid`, `HumanoidRootPart` e `Head`. O GameForge desenha o corpo, anima andar/pular e controla a física.

## O jogador

Ao executar, o jogador nasce automaticamente (`Players.CharacterAutoLoads`). `Game.CreatePlayer("Nome")` cria o personagem com um nome escolhido.

```luau Configurando o jogador
local player = Game.CreatePlayer("Soldado")
local personagem = player.Character
local humanoid = personagem:FindFirstChildOfClass("Humanoid")
humanoid.WalkSpeed = 24
humanoid.JumpPower = 70
humanoid.MaxHealth = 150
humanoid.Health = 150
humanoid.ShirtColor = Color3.fromRGB(200, 40, 40)
humanoid.PantsColor = Color3.fromRGB(30, 30, 30)
print(player.Name, "nasceu em", personagem.HumanoidRootPart.Position)
```

## Humanoid

| Membro | Descrição |
|---|---|
| `Health`, `MaxHealth` | vida |
| `WalkSpeed` | velocidade (padrão 16) |
| `JumpPower` | força do pulo (padrão 50) |
| `DisplayName` | nome sobre a cabeça |
| `ShirtColor`, `PantsColor`, `BodyColor` | cores do corpo |
| `Sit`, `Jump`, `PlatformStand`, `AutoRotate` | estados |
| `MoveDirection`, `FloorMaterial`, `RootPart` | leitura |
| `:TakeDamage(n)` | causa dano |
| `:MoveTo(posição)` | anda até um ponto (`MoveToFinished` avisa) |
| `:Move(direção)` | anda numa direção |
| `:LoadAnimation(anim)` | carrega uma animação |
| `:EquipTool(tool)` / `:UnequipTools()` | ferramentas |
| `Died`, `HealthChanged`, `Running`, `Jumping`, `StateChanged` | eventos |

## Vida, dano e renascimento

```luau Zona de dano e cura
local player = Game:GetService("Players").LocalPlayer
Game:GetService("Players").RespawnTime = 3
local function zona(cor, posicao, quantidade)
    local z = Instance.new("Part")
    z.Size = Vector3.new(6, 0.4, 6)
    z.Position = posicao
    z.Color = cor
    z.Material = Enum.Material.Neon
    z.Anchored = true
    z.Parent = workspace
    local ultimo = 0
    z.Touched:Connect(function(outro)
        local h = outro.Parent and outro.Parent:FindFirstChildOfClass("Humanoid")
        if h and os.clock() - ultimo > 0.5 then
            ultimo = os.clock()
            h.Health = math.clamp(h.Health + quantidade, 0, h.MaxHealth)
        end
    end)
end
zona(Color3.fromRGB(255, 40, 40), Vector3.new(-5, 0.2, -10), -25)
zona(Color3.fromRGB(40, 255, 80), Vector3.new(5, 0.2, -10), 25)

player.CharacterAdded:Connect(function(char)
    print("Renasceu!")
    char:WaitForChild("Humanoid").Died:Connect(function()
        print("Você morreu. Renascendo em 3 segundos...")
    end)
end)
if player.Character then
    player.Character.Humanoid.Died:Connect(function()
        print("Você morreu. Renascendo em 3 segundos...")
    end)
end
```

## Ponto de nascimento

```luau SpawnLocation
local spawn = Instance.new("SpawnLocation")
spawn.Size = Vector3.new(8, 1, 8)
spawn.Position = Vector3.new(0, 20, -30)
spawn.Anchored = true
spawn.Parent = workspace
local player = Game:GetService("Players").LocalPlayer
player:LoadCharacter() -- renasce no novo ponto
print("Você está no alto da plataforma")
```

## NPCs

```luau Criando NPCs
local guarda = Game.CreateNPC("Guarda", Vector3.new(0, 3, -15))
local h = guarda:FindFirstChildOfClass("Humanoid")
h.ShirtColor = Color3.fromRGB(30, 60, 160)
h.WalkSpeed = 10
while true do
    h:MoveTo(Vector3.new(-12, 0, -15))
    h.MoveToFinished:Wait()
    h:MoveTo(Vector3.new(12, 0, -15))
    h.MoveToFinished:Wait()
end
```

## Câmera em primeira e terceira pessoa

```luau Primeira pessoa
Game.SetCameraMode("FirstPerson")
print("Câmera em 1ª pessoa. Em 5 segundos volta para 3ª pessoa.")
task.wait(5)
Game.SetCameraMode("ThirdPerson")
```

::: exercicio Corredor
Faça o jogador correr (WalkSpeed 32) enquanto segura Shift esquerdo e voltar a 16 ao soltar.
```luau
local UIS = Game:GetService("UserInputService")
local player = Game:GetService("Players").LocalPlayer
local function humanoid()
    return player.Character and player.Character:FindFirstChildOfClass("Humanoid")
end
UIS.InputBegan:Connect(function(input)
    if input.KeyCode == Enum.KeyCode.LeftShift and humanoid() then humanoid().WalkSpeed = 32 end
end)
UIS.InputEnded:Connect(function(input)
    if input.KeyCode == Enum.KeyCode.LeftShift and humanoid() then humanoid().WalkSpeed = 16 end
end)
```
:::

<!-- capitulo id=animacoes num=13 group="Motor GameForge" title="Animações" -->
O GameForge tem animações de personagem embutidas: `Idle`, `Walk`, `Run`, `Jump`, `Wave`, `Dance`, `Point`, `Cheer`, `Sit`, `Punch`, `Spin`, `Kick`, `Climb`, `Swim`. Andar, correr e pular são automáticos; as outras você toca por script.

```luau Acenar e dançar
local player = Game:GetService("Players").LocalPlayer
local char = player.Character or player.CharacterAdded:Wait()
local humanoid = char:WaitForChild("Humanoid")
task.wait(1)
local aceno = humanoid:LoadAnimation("Wave")
aceno:Play()
aceno.Ended:Wait()
print("Acenou! Agora dança por 4 segundos")
local danca = humanoid:LoadAnimation("Dance")
danca.Looped = true
danca:Play()
task.wait(4)
danca:Stop()
```

## Objetos Animation

Também é possível usar um objeto `Animation` com `AnimationId = "gameforge://Nome"`:

```luau Animation e AnimationTrack
local npc = Game.CreateNPC("Dançarino", Vector3.new(0, 3, -10))
local anim = Instance.new("Animation")
anim.AnimationId = "gameforge://Dance"
local track = npc.Humanoid:LoadAnimation(anim)
track.Looped = true
track:Play()
track:AdjustSpeed(1.5)
print("Duração:", track.Length, "Tocando:", track.IsPlaying)
```

| AnimationTrack | Descrição |
|---|---|
| `:Play()` / `:Stop()` | iniciar/parar |
| `:AdjustSpeed(n)` / `Speed` | velocidade |
| `Looped` | repetir |
| `IsPlaying`, `Length` | leitura |
| `Ended`, `Stopped` | eventos |

## Animando objetos

Para objetos, use `TweenService` ou altere `CFrame` a cada quadro:

```luau Moinho girando
local RunService = Game:GetService("RunService")
local eixo = Instance.new("Part")
eixo.Size = Vector3.new(1, 12, 1)
eixo.Position = Vector3.new(0, 6, -15)
eixo.Anchored = true
eixo.Parent = workspace
local pas = Instance.new("Part")
pas.Size = Vector3.new(14, 1.5, 0.5)
pas.Anchored = true
pas.Color = Color3.fromRGB(240, 240, 240)
pas.Parent = workspace
local angulo = 0
RunService.Heartbeat:Connect(function(dt)
    angulo += dt * 2
    pas.CFrame = CFrame.new(0, 12, -14.2) * CFrame.Angles(0, 0, angulo)
end)
```

## Estilos de easing

```luau Comparando EasingStyle
local TweenService = Game:GetService("TweenService")
local estilos = { "Linear", "Quad", "Sine", "Back", "Bounce", "Elastic" }
for i, estilo in estilos do
    local p = Instance.new("Part")
    p.Size = Vector3.new(2, 2, 2)
    p.Position = Vector3.new(-10, 1, -8 - i * 3)
    p.Anchored = true
    p.Color = Color3.fromHSV(i / 7, 0.8, 1)
    p.Parent = workspace
    local info = TweenInfo.new(2, Enum.EasingStyle[estilo], Enum.EasingDirection.Out, -1, true, 0.5)
    TweenService:Create(p, info, { Position = Vector3.new(10, 1, -8 - i * 3) }):Play()
end
```

::: exercicio Comemoração
Faça o jogador tocar a animação `Cheer` sempre que apertar a tecla G.
```luau
local UIS = Game:GetService("UserInputService")
local player = Game:GetService("Players").LocalPlayer
UIS.InputBegan:Connect(function(input, processado)
    if processado or input.KeyCode ~= Enum.KeyCode.G then return end
    local h = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
    if h then h:LoadAnimation("Cheer"):Play() end
end)
```
:::
