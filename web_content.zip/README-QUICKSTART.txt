DIES IST QUELLCODE, KEINE APK.

Zum Bauen brauchst du später Android Studio, ein eigenes Firebase-Projekt und dessen google-services.json in app/.
Die vollständige Anleitung steht in README.md.
Keine Demo-Nutzer oder Beispieldaten sind enthalten.
