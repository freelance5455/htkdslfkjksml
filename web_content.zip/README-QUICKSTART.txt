DIES IST QUELLCODE, KEINE APK.

Diese Ausgabe ist für den kostenlosen Firebase-Spark-Tarif vorbereitet. Sie verwendet E-Mail/Passwort und Firestore. Kein Abrechnungskonto, Cloud Functions oder Firebase Storage sind erforderlich.

Einrichtung: siehe README.md. Du brauchst Android Studio, ein Firebase-Projekt mit Authentication (E-Mail/Passwort) und Firestore sowie google-services.json in app/.

Familienbilder werden als HTTPS-Links geteilt; Bilddateien werden nicht in Firebase hochgeladen. PIN-Anmeldung und Beispielkonten sind nicht enthalten.
