const $=id=>document.getElementById(id);
const KEY="gartic_control_v2";
const makeDefaults=()=>({room:"",accounts:Array.from({length:10},()=>({name:"",entered:false}))});
let data;
try{data=JSON.parse(localStorage.getItem(KEY))||makeDefaults()}catch(e){data=makeDefaults()}
if(!Array.isArray(data.accounts))data=makeDefaults();
data.accounts=Array.from({length:10},(_,i)=>data.accounts[i]||({name:"",entered:false}));
$("room").value=data.room||"";
function msg(t){$("message").textContent=t}
function persist(){data.room=$("room").value.trim();localStorage.setItem(KEY,JSON.stringify(data));renderStatus()}
function renderAccounts(){
 $("accounts").innerHTML="";
 data.accounts.forEach((a,i)=>{
  const card=document.createElement("div");card.className="account";
  card.innerHTML=`<div class="accthead"><span style="display:flex;align-items:center"><span class="number">${i+1}</span>Conta ${i+1}</span><span class="pill">Slot ${i+1}</span></div><label for="name${i}">Nome opcional</label><input id="name${i}" maxlength="40" placeholder="Ex.: conta ${i+1}"><div class="statusrow"><span class="state">${a.entered?"Marcada como entrou":"Ainda não entrou"}</span><button class="outline" id="toggle${i}">${a.entered?"Desmarcar":"Marcar entrada"}</button></div><button class="${["blue","purple","green"][i%3]}" id="open${i}">Abrir app correspondente</button><button class="outline" id="join${i}">Copiar link/código</button>`;
  $("accounts").appendChild(card);
  card.querySelector(`#name${i}`).value=a.name||"";
  card.querySelector(`#name${i}`).addEventListener("change",e=>{data.accounts[i].name=e.target.value;persist();msg("Nome salvo.")});
  card.querySelector(`#toggle${i}`).onclick=()=>{data.accounts[i].entered=!data.accounts[i].entered;persist();renderAccounts();renderStatus();msg("Status atualizado manualmente.")};
  card.querySelector(`#open${i}`).onclick=()=>msg("Abra manualmente o APK/versão correspondente à Conta "+(i+1)+". O painel não consegue detectar ou controlar outros apps automaticamente.");
  card.querySelector(`#join${i}`).onclick=copyRoom;
 });
}
function renderStatus(){
 const n=data.accounts.filter(a=>a.entered).length;
 $("roomStatus").textContent=data.room?"Link/código salvo":"Sala não configurada";
 $("statusList").innerHTML="";
 data.accounts.forEach((a,i)=>{const row=document.createElement("div");row.className="statusitem";const name=a.name||`Conta ${i+1}`;row.innerHTML=`<span>${i+1}. ${escapeHtml(name)}</span><button>${a.entered?"Entrou":"Não entrou"}</button>`;row.querySelector("button").onclick=()=>{data.accounts[i].entered=!data.accounts[i].entered;persist();renderAccounts();renderStatus()};$("statusList").appendChild(row)});
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("saveRoom").onclick=()=>{persist();msg("Link/código salvo neste aparelho.")};
async function copyRoom(){const v=$("room").value.trim();if(!v){msg("Cole primeiro o link ou código da sala.");return}try{await navigator.clipboard.writeText(v);msg("Link/código copiado. Cole no app.")}catch(e){$("room").focus();$("room").select();msg("Selecione o texto e use Copiar no menu do Android.")}}
$("copyRoom").onclick=copyRoom;
$("openRoom").onclick=()=>{const v=$("room").value.trim();if(/^https?:\\/\\//i.test(v)){window.open(v,"_blank","noopener");msg("Sala aberta no navegador.")}else if(v){copyRoom();msg("Código pronto para copiar. Abra o Gartic e cole o código.")}else msg("Insira o link ou código da sala primeiro.")};
$("reset").onclick=()=>{if(confirm("Apagar link, nomes e status salvos neste painel?")){data=makeDefaults();$("room").value="";persist();renderAccounts();renderStatus();msg("Dados locais apagados.")}};
renderAccounts();renderStatus();
