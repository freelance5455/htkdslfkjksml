GARTIC CONTROL — VERSÃO PARA ATÉ 10 CONTAS

Este ZIP contém o código-fonte web, não um APK compilado.
O painel permite organizar até 10 nomes, salvar o link/código da sala,
copiar o link e marcar manualmente o status de cada conta.
Não faz login nem controla outros aplicativos automaticamente.

Para testar: abra index.html em um navegador ou publique os arquivos
em hospedagem estática. Os dados ficam no armazenamento local do navegador.
