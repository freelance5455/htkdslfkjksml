SHREE SENDHAV DAIRY V34 - MOBILE APP (DESKTOP + FARMER APP SYNC)
================================================================

IMPORTANT: Existing V34 app code/design/calculation/entry flow ko change nahi kiya gaya.
Ye project current Shree Sendhav Dairy V34 Desktop ke Firebase plantSync + Farmer Portal system ko dhyan me rakhkar hai.

SYNC
----
1. Desktop V34 -> Mobile: same plant dataset realtime/automatic sync.
2. Mobile -> Desktop V34: mobile par save/edit/delete ke baad same plant dataset sync.
3. Desktop/Mobile current dataset -> Farmer App: Farmer Portal republish hota hai.
4. Farmer code/mobile/PIN changes: old login mappings and stale portal user/history cleanup is supported by the existing publishFarmerPortal() logic.
5. Deleted milk entries/purchases/payments ko current Farmer Portal history rebuild me stale nahi rakha jata.
6. Plants are isolated: main, arandiya, narsinggarh.
7. Offline local data device par rahega; internet available hone par sync hota hai.

V34 FEATURES PRESERVED
----------------------
Dashboard, Farmer Master, Milk Entry, Farmer Purchase, Payments/AD/Cut-off,
10-Day Bill, 10-Day Purchase Summary, Reports, Products, Cow CLR Rate List,
Complaint Inbox, Settings, Backup/Restore, existing calculations and entry flow.

LOGIN / FIREBASE
----------------
Firebase project: shree-sendhav-dairy-v-34
Plant login and existing Google/Gmail sync controls are retained as in V34.

ANDROID APK BUILD
-----------------
Android Studio me folder open karein: SS_Dairy_V34_Mobile
Gradle Sync complete hone dein.
Build > Build Bundle(s) / APK(s) > Build APK(s)
APK: app/build/outputs/apk/debug/app-debug.apk

NOTE
----
Actual APK binary is not included; this is the Android Studio project.
Android WebView file:// mode me Firebase Google popup login browser limitation ho sakti hai;
existing V34 Google login logic ko bina changing core desktop V34 ke preserve kiya gaya hai.
