SHOPZO mobile web prototype.
Open index.html in a browser. It includes Home, categories, product search, products and a working cart counter.
This is a prototype; real login, database, payments, delivery tracking and admin backend are not connected yet.
