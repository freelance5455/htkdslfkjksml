ONLINE (ORTAK + KARŞILIKLI) — PeerJS, hesap yok
- Ana menü > Yeni Fetih > "Online (2 kişi)". Biri "Oda kur — Ortak" seçer, 5 harfli kodu arkadaşına verir; arkadaşı kodu girip "Katıl"a basar.
- Ortak: aynı ülke, sırayla oynanır. Tur (yapay zekâ fazı dahil) bitince durum arkadaşa gönderilir, sıra ona geçer.
- İkiniz de aynı anda açık ve internette olmalısınız. Online oyun yerel kayda yazılmaz (bağlantı koparsa oyun gider).
- PeerJS kütüphanesi önce www/peerjs.min.js dosyasından, yoksa unpkg/jsdelivr CDN'den yüklenir.
  Çevrimdışı/APK için https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js dosyasını indirip www/ içine koyun.
- Değişen dosyalar: www/online.js, www/v5.js (check5), www/v35.js (menü), www/index.html (script etiketi).

V103: Online (ORTAK + KARŞILIKLI) en son sürüme (V102) taşındı. Online paketindeki 5 değişiklik aynen uygulandı:
online.js (yeni), v5.js (startPlayerTurn kancası + check5), v20.js (YZ, online oyuncuları hedeflemez), v35.js (menü "Online (2 kişi)"), index.html (online.js etiketi).
Ana menü > Yeni Fetih > "Online (2 kişi)". V94 sonrası tüm değişiklikler korundu (savaş animasyonları, açılış sinematiği, zorluk, vb.).
