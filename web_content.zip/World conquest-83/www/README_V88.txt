V88 — V87 üzerine. Zarlar savas-zari.html'deki 'Savaş zarı' ile değiştirildi.
1) dice3d.js: yüzler artık SVG (faceSvg): krem gövde, altın dişli kenar, köşelerde çapraz kılıçlar, 1 = yakut gözlü güneş/kılıç armasi, 2-6 = oyuk gözler. Zar fiziği/animasyonu/sonuç mantığı DEĞİŞMEDİ.
2) v88.css (en son yüklenir): eski beyaz/obsidyen yüz stilini ezer; takım (mavi/kırmızı), kazanan (yeşil) ve 6 (altın) vurguları parıltı olarak.
TEST EDİLMEDİ (yalnızca söz dizimi denetlendi).
3) 'Zar At' düğmesi ikonu (v5.js) artık yeni zarın 5 yüzü (WCDice.faceUri); WCDice yüklenmezse eski ikon.
4) Performans: yüzler canlı SVG yerine tek seferlik üretilen tek bir <style> içinde data-URI arka plan (zar başına ~1400 SVG düğümü → 6 boş div; zar HTML’i ~260 KB → ~1 KB); takım/kazanan parıltı filtreleri sadece zar durunca (.landed) uygulanır.
