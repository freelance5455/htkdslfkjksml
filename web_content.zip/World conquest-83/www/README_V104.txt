V104 — 1) "Tur başına tek saldırı" kuralı KALDIRILDI (v5.js, v102.js): artık bir turda hamle hakkın yettiği sürece istediğin kadar saldırabilirsin. Saldırı ve keşif yine birer hamle harcar; deniz aşırı saldırı yine toplam 2 hamle. "Bu tur saldırdın" kilidi, otomatik tur-bitirme kısayolu ve ilgili uyarı metinleri kaldırıldı/etkisizleştirildi (eski kayıtlarda T.attacked true kalsa bile hiçbir şey kilitlenmez).
2) POLİTİKALAR (v17.js): bedel 3 hamle -> 2 hamle (hamle yetmezse yine 35 altın). Bir zar atışında (turda) yalnızca 1 politika uygulanabilir: örn. 6 attın, 2 hamle harcayıp politika aldın -> o turda kalan 4 hamleyle bile başka politika (altınla da) alınamaz. Menüde düğmeler "Bu zarda kullanıldı" olarak kilitlenir; kural uygulama anında da kontrol edilir. Sonraki zar atışında (yeni turda) tekrar kullanılabilir. Sayaç G.pol.usedTurn içinde kayda yazılır.
TEST EDİLMEDİ (istek üzerine; yalnızca node --check ile söz dizimi denetlendi). Yedekler: v5.js.bak, v17.js.bak, v102.js.bak.
YAPILMADI / DİKKAT
- Yapay zekâ (rakip) tarafında hiçbir değişiklik yok; zaten tek saldırı sınırı yalnızca oyuncuya uygulanıyordu.
- "2 tur" ifadesi "2 hamle" olarak yorumlandı (politika zaten hamle harcıyor). Gerçekten 2 TUR bekleme (cooldown) istiyorsan söyle, değiştirelim.
- "Bir zar atışında 1 politika" tüm politikalar için ortak sayıldı (aynı politika zaten üst üste uygulanamıyordu).
