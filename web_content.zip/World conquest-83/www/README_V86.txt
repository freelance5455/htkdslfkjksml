V86 — V85 üzerine. TEST EDİLMEDİ (yalnızca JS söz dizimi denetlendi).
1) Savaş paneli (v7.js row + v85.css): her istatistik satırında üstün taraftaki değerin yanında yeşil dolu ▲, düşük taraftakinde kırmızı küçük ▼; eşitse işaret yok. Değer sütunu 44→58px.
2) Ana menü (v35.js): "Yeni Fetih" artık "Seferi Sürdür"ün üstünde (ilk sırada).
Ayar: v85.css sonundaki .ar boyutu/renkleri.
3) Oyunu bitirecek savaş (v7.js, lock86): ATLANAMAZ. Dokunarak geçme kapalı, azaltılmış hareket/hız 0 olsa da animasyon oynar; yalnızca 6 gelince yeni zar için dokunma çalışır. Sonuç düğmesi animasyon bitince çıkar.
