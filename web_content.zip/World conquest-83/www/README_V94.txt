V94 — SAVAŞ ANİMASYONLARINI (tank, piyade, gemi, füze) GERİ AÇMA. TEST EDİLMEDİ (yalnızca JS söz dizimi denetlendi).
Sebep: V92'nin sıfır hata toleransı ve aşırı küçülme (en küçük ölçek .09 / SC*.03) sahneyi ya kurdurmuyor ya da görünmeyecek kadar küçültüyordu.
Değişenler (yalnızca v60.js):
1) place(): kara sahnesi hata toleransı 0 -> 2 (deniz sahnesi 0 kalır; gemi karaya çıkmaz). Ölçek kademeleri: kara ... .18'e, deniz .13'e kadar.
2) DL yoğun denetim: yanal genişlik [-1.5,0,1.6], adım .8 (V92'deki ±3 / .6 çok sıkıydı).
3) Yedek ateş + füze sahnesi: ölçek alt sınırı SC*.03 -> SC*.3 (birlikler görünür kalır).
Ayar: place() scales, DL, fitFireScale minSc. Yedek: v60.js.bak (çalışma klasöründe, pakette yok).
