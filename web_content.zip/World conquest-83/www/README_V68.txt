V68 — TEST EDİLMEDİ (yalnızca JS söz dizimi + sayfanın hatasız yüklenmesi denetlendi; savaş akışı tarayıcıda denenmedi)
1) YAPAY ZEKÂ ZARI (v20.js): AI_TURNS 2 → 1. Eskiden tur başına iki rakip arka arkaya zar atıyordu ("çift zar"). Artık tek rakip, tek zar.
   Zar 6 gelirse AYNI zar tekrar atılır (hamle hakkı = toplam, en çok 3 atış). Oyuncunun tur zarı değişmedi (tek zar). Savaş zarı (V66) değişmedi.
   Daha fazla rakip istersen: v20.js en üstte AI_TURNS.
2) SALDIRI ANİMASYONU (v60.js): Hedef küçükse / küre verisinde yoksa / yerleşim denetimi geçemezse animasyon artık atlanmıyor.
   YEDEK SAHNE: saldıranın kendi toprağından (hedefe en yakın sınır noktasının biraz içinden) hedefin YÖNÜNE doğru 2 tank ateş eder (3'er atış).
   Sınır denetimi yok; mermiler hedef yönüne düşer. Kazanırsa patlamalar büyük. Deniz aşırı saldırıda da bu yedek kullanılır (gemi sahnesi kurulamazsa).
3) RENKLER (v57.js): Saldırmazlık paktı (G.pacts) artık ülkeyi renklendirmez. Yalnızca DOSTLUK antlaşması (ittifak) renk paylaşır:
   AI ittifakları kendi ortak rengini (v40 ACOL), oyuncunun ittifak üyeleri OYUNCUNUN rengini alır. Eski açık yeşil için v57.js'te ALLY_SAME_AS_PLAYER = false.
4) SAVUNMA ZAFERİ (v55.js): Saldıran yenilince toprağı savunana geçer (eskisi gibi). Tek topraklı savunan bu toprağı alınca imparatorluk rengine
   boyanmaz: iki toprak da kendi (varsayılan/ittifak) rengini korur. Birden çok topraklı savunan kazanırsa kazanılan toprak kazananın rengiyle boyanır.
   (Saldırıyı kazanıp fethetmek V53'teki gibi imparatorluk rengi verir.)
