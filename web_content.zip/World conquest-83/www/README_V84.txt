V84 — V83 üzerine. TEST EDİLMEDİ (yalnızca JS söz dizimi denetlendi).
1) Gemi sahnesi (v60.js): iki geminin tüm gövdesi, ilerleme alanı ve torpido yolu için denetim noktaları (SEA_CHK) artık DENİZde olmak zorunda;
   hata toleransı sıfır (eskiden 2 nokta). Sığmazsa sahne küçülür / başka aday denenir; hiçbiri uymazsa yedek ateş sahnesi oynar (gemi karaya çıkmaz).
2) Gemiler küçültüldü: SHIP_S = 0.85 (v60.js; eski 1.25). Yerleşim denetimi bu değere göre yapılır.
3) Fetih zinciri dengesi:
   - "Önceki zafer bonusu" ×1.5 → ×1.25 (app.js PREV_WIN).
   - Bonus tek kullanımlık: bonusla kazanılan zafer yeni bonus doğurmaz (v5.js attack5) → kazanan aynı rakibe sürekli ×bonusla saldıramaz.
   - İmparatorluk yükü (v73.js): 3'ten fazla her toprak savaş değerlerini %1.2 düşürür (en çok %18); saldıran ve savunan için.
   - Yenilgi cezası (Ordu + Diplomasi) %8 → %5 (v5.js LOSS_PEN) — kaybeden çöküp kazananı daha da şişirmesin.
   Ayarlar: PREV_WIN, OVR_STEP/OVR_MAX, LOSS_PEN, SHIP_S.
