V65 — kara saldırısında askerlerin denizden çıkması + animasyon sonrası kasma (v60.js, v30.js)

1) KARA SALDIRISI YERLEŞİMİ (v60.js): Sahne artık iki ülke merkezinin ortasına değil, iki ülkenin GERÇEK SINIR noktasına kurulur
   (sınır köşelerinden en yakın çiftler aranır). Sahnedeki 19 örnek noktası (tank/piyade başlangıcı, yol, kule/ev) ülke
   çokgenleriyle denetlenir: başlangıçlar saldıranın karasında, hedefler hedef ülkede, yol kara üzerinde olmalı.
   Olmuyorsa sahne sırayla küçültülür (1 → 0.09) ve farklı sınır noktası/yön denenir. Küçük ülkelerde modeller küçük görünür;
   kamera da ölçeğe göre yaklaşır. Deniz aşırı saldırıda gemiler yalnızca denizde olacak şekilde aynı denetim uygulanır.
2) KASMA (v60.js, v30.js): animasyon bitince yükseltilmiş ülkeler hemen geri indirilir (v30API.unlift) ve efekt kökü küreden
   sökülür (sahne dolaşımından çıkar). Yeni v30API: at(lon,lat), unlift(), border(id,max).
Test: headless Chromium'da 150 komşu çiftinin 100'ünde sıfır hatalı nokta, kalanında çoğunlukla 1–2 nokta; gerçek savaş akışı
(Türkiye→Yunanistan) hatasız çalıştı. Yazılım GL'de kare süresi ölçülemedi: kasmanın telefonda geçip geçmediği TEST EDİLMEDİ.
Bilinen: dar/adalı sınırlarda (ör. Afganistan–Çin, Lüksemburg–Belçika) birkaç nokta yine kara dışına düşebilir.
