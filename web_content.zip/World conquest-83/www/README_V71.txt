V71 — kısa test: kütüphane boş sahnede çalıştırıldı (hatasız, 12,6 sn animasyon sonuna kadar), isabet geometrisi sahte küre verisiyle doğrulandı, oyun hatasız açıldı.
Gerçek oyunda saldırı akışı tarayıcıda uçtan uca denenmedi.
1) KAMERA (v60.js): animasyon başlangıç uzaklığı biraz artırıldı: ZOOM 2.7 → 3.2, en yakın 2.2 → 2.8 (ZMIN). Sonrası yine serbest.
2) ATEŞ HEDEF ÜLKEYE GİDER (v60.js + wc_battle_fx.js): Tank, piyade ve yedek ateş sahnesinde isabet noktaları artık dünya koordinatında hedef ülkenin
   İÇİNDEN seçilir (kenardan içeride olanlar tercih edilir); mermi/kurşun/patlama rastgele denize ya da başka ülkeye düşmez.
   Hata düzeltmesi: yedek sahnede büyük saldıran ülkede ölçek mesafeye de çarpıldığı için ateş hedefi aşıyordu (sizeF); düzeltildi.
   Yedek/füze sahnesi kamera yaklaşınca küçülmez (isabetler kaymasın), kara sahnesi en çok %30 küçülür.
   Kütüphane: tankAttack {tos:[...]} (atış başına hedef), infantryAttack {pool:[...]} (kurşun hedef havuzu).
3) FÜZE ATAR (yeni): Hedef ülkenin ana kara parçasının sınır kutusu TINY (v60.js, 3.6°) altındaysa tank/piyade yerine füze atar sahnesi oynar.
   Saldıranın kendi toprağında (hedefe en yakın sınırın biraz içinde) kamyon belirir, sürerek yerleşir, ayakları iner, rampa kalkar ve 6 minik füze
   hedef ülkenin içindeki birbirinden uzak noktalara düşer (son füze daha büyük patlar). Kazanırsan patlamalar büyük.
   Model/efekt tank kalitesinde: kamuflaj dokusu, takım şeritleri, tekerlek+sırt blokları, çamurluk, kabin/cam/farlar, hidrolik ayaklar, anten yayı,
   füzede burun/bant/kanatçıklar, motor alevi + duman izi, arka püskürtme, geri tepme. Yeni: WCBattleFX.missileAttack, models.missile, models.missileLauncher.
   Deniz aşırı küçük ülkelerde de aynı sahne (füzelerin menzili uzun; ölçek/kamera mesafeye göre ayarlanır). Kurulamazsa eski akışa (kara/yedek) düşer.
   Ayar: v60.js TINY (büyütürsen daha fazla ülke füzeyle vurulur), füze sayısı buildMissileScene içinde missiles:6.
4) v30.js: v30API.bbox(id) eklendi (küçük ülke ölçütü için).
