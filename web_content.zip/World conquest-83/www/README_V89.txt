V89 — ZORLUK ARTIŞI (V88 üzerine). Yalnızca denge sabitleri değişti; yeni sistem eklenmedi. Sözdizimi denetlendi, oyun elle test EDİLMEDİ.
Rakip yapay zekâ (v20.js):
  - AI_TURNS 1 → 2: oyuncunun her turundan sonra İKİ rakip oynar.
  - Saldırı eşiği: kazanma ihtimali .58/.72 → .46/.60; hedef/kendi güç oranı sınırı 1.15 → 1.3 (oyuncuya karşı 1.6); oyuncuya saldırı +.18 öncelik.
  - Gelişim: x1.12+.7 → x1.18+1.1; THREAT_W .4 → 1.1 (tehlikeli rakipler oyuncuya daha sık sıra alır).
  - Saldırmazlık paktı 6 → 4 tur (v20 PACT_TURNS, v40 metni); güçlü devletin oyuncunun pakt teklifini kabulü .6 → .35 (v24 P_WEAK_PL).
Savaş / ekonomi:
  - app.js PREV_WIN 1.25 → 1.35 (intikam bonusu; rakip de kullanır).
  - v5.js LOSS_PEN -5 → -8; kriz turu (zar 1) kayıpları ~%40 daha ağır.
  - v73.js FAT_STEP .07 → .09; imparatorluk yükü OVR_STEP .012 → .02, OVR_MAX .18 → .30 (fetih zincirini yavaşlatır).
  - rules5.js MAX_SCOUTS 2 → 1 (tur başına tek keşif).
  - v18.js altın ödülü: win 2 → 1, ecoK .1 → .06, ecoCap 5 → 3.
  - v23.js elçi maliyetleri guard 40→60, incite 25→40, prot 40→60; isyan REV_HEAT 4.5→3.5, REV_P .3→.45, REV_COOL 6→4, HATE 1.5→1.75.
  - v17.js politika: POL_MOVES 2 → 3, POL_GOLD 20 → 35.
Geri almak / ayarlamak için ilgili dosyadaki sabiti değiştir; ilk değerler yukarıda.
Değer dengesi (app.js, genStats sonrası): 50 üstü değerler %45'e sıkıştırılıyor, sonra üs .8 ile zayıf ülkeler yukarı çekiliyor.
  ABD 5 değerin toplamı ~460 → ~371, Çin ~420 → ~357, Hindistan 100 → ~77 tepe; küçük ülkeler birkaç puan güçlendi. Ayar: SQ_KNEE, SQ_TOP, SQ_POW.
  Eski kayıtlı oyunlarda gelişmiş değerler korunur; tam etki için Yeni Oyun başlat.
