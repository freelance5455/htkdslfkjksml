V83 — V82 üzerine. TEST EDİLMEDİ (yalnızca JS söz dizimi denetlendi).
1) v5.js attack5: oyuncu SAVUNMA savaşını kazanırsa saldıran ülkenin tüm toprakları oyuncuya geçer (birleşir), saldıran ülke yok edilir; fethedilen sayacı artar.
2) "Batı Şeria" → "Filistin", "West Bank" → "Palestine" (i18n.js, index.html harita verisi, v23facts.js bilgi metni).
3) İsrail (ISR) tüm özelliklerde %15 zayıflatıldı (app.js genStats; eski kayıtlarda değişmez, yeni oyunda geçerli).
4) İsrail'e karşı birlik: YZ devletleri İsrail'i öncelikli hedef alır (v5.js aiPlan, +0.45 puan, düşük kazanma ihtimalinde bile), ve İsrail'e saldırırken +%15 birlik bonusu alır.
5) Kriz turu: tur zarı 1 gelirse 1 hamle + zorunlu olumsuz olay (rastgele: salgın / ekonomik çöküş / ordu isyanı / diplomatik skandal / casusluk skandalı; kalıcı %8–12 düşüş). YZ de zar 1 atarsa aynı krizi yaşar (v5.js crisis5).
6) Yenilgi cezası: savaşı kaybeden (oyuncu veya YZ) Ordu ve Diplomasi'de kalıcı %8 kaybeder; savaş kapanınca bildirim çıkar (v5.js lossPenalty).
7) Deniz aşırı saldırı 2 hamle harcar (oyuncu); YZ de deniz aşırı saldırı için zar ≥2 gerekir.
