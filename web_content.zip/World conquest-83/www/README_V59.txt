V59 — TEST EDİLMEDİ (yalnızca JS söz dizimi denetlendi)
1) Zar: 6 gelince tekrar atma artık SADECE SAVAŞ zarlarında (saldırı + yapay zekâ saldırısı). Tur başı hamle zarında yok (tek zar).
   Savaşta 6 gelirse o taraf tekrar atar, toplam sayılır (en çok 4 zar). Küp zar son yüzü gösterir, altındaki sayı toplamı (örn. "9 (3)").
2) Başlangıç kamerası (3B küre): yeni oyunda önce dünya uzaktan yaklaşır, ~2,5 sn sonra Türkiye'ye döner/yaklaşır.
   Ülke seçim ekranında 3B'ye geçince de Türkiye'ye odaklanır. 2B düz harita zaten Türkiye'de açılır (2B'de dünya görünümü yok: KMIN=6).
NOT: "Başlangıç konumu Türkiye" yalnızca kamera olarak yapıldı; oyuncunun ülkesini yine sen seçiyorsun.
