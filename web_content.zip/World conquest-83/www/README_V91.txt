V91 — YENİ OYUN / DEVAM SONRASI 2B HARİTA EKRANI DÜZELTMESİ (V90 üzerine). Oyun kuralları değişmedi. Yalnızca v30.js.
1) Menü kapanır kapanmaz (MutationObserver) 3B küre kapağı ANINDA konur; önceki 250 ms'lik yoklama boşluğunda 2B harita görünebiliyordu.
2) 3B küre kurulumu ilk seferde hata verirse (telefonda geçici GL/bellek hatası) hemen 2B haritaya düşmek yerine yarım kalan tuval temizlenip BİR KEZ daha denenir.
Test (headless Chromium, telefon boyutu): yavaş CPU'da 2B harita karesi 1 -> 0; ilk GL hatası simüle edilince 2. denemede küre açılıyor (tek tuval, hata yok).
Not: cihazda WebGL hiç açılmıyorsa yine düz harita kullanılır.

V92 — YÜKLEME DÖNMESİ KISALTMA (yalnızca v30.js)
- Menü açıkken (1,5 sn sonra, boşta) three.js + doku verisi önceden yüklenip çözülür; oyun başlayınca küre sadece kurulur.
- Yükleyiciler önbellekli. Yükleme 9 sn'yi aşarsa dönen kapak kalkar, düz harita görünür; küre hazır olunca kendiliğinden açılır.
- Ölçüm (6x yavaş CPU): menü kapandıktan sonra dönme süresi 2,5 sn -> 1,2 sn.

V93 — GÖRÜNÜR BEKLEMEYİ KISALTMA (yalnızca v30.js)
- Küre belirme gecikmesi 350 ms -> 30 ms, solma süresi 1,1 sn -> 0,45 sn; yaklaşma animasyonu gecikmesi 350 -> 60 ms; kurulum başlatma gecikmesi 60 -> 0 ms.
