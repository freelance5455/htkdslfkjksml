/* V73 — SAVAŞ YORGUNLUĞU: bir turda savaşan devletin değerleri, o turun sonraki savaşlarında düşer.
   Her savaşa giren iki taraf (saldıran + savunan) 1 yorgunluk puanı kazanır; her puan o tur içindeki sonraki savaşlarında 5 değeri de %7 düşürür (en çok 4 puan = %28).
   Tur değişince sıfırlanır (G.fat = {t: tur, s: {ülke: puan}}; kayıtla birlikte saklanır). Kalıcı değerlere dokunmaz: yalnızca o savaşın hesabında uygulanır.
   Hem oyuncu hem yapay zekâ için geçerli. Ayar: FAT_STEP, FAT_MAX. */
(function () {
  'use strict';
  var FAT_STEP = .09, FAT_MAX = 4;
  function T(tr, en) { return (typeof L !== 'undefined' && L === 'en') ? en : tr; }
  function nm(e) { return (M[e] && M[e].name) || e; }
  function tn() { return (G && G.T && G.T.turn) || 0; }
  function fd() { if (!G.fat || G.fat.t !== tn()) G.fat = { t: tn(), s: {} }; return G.fat; }
  function fac(e) { return 1 - FAT_STEP * Math.min(FAT_MAX, fd().s[e] || 0); }
  function mul(a, f) { return a.map(function (v) { return v * f; }); }
  /* V84: İMPARATORLUK YÜKÜ — çok toprağı olan devletin savaş değerleri düşer (kazanan ardı ardına her yeri fethetmesin).
     Her toprak (3'ten sonra) %OVR_STEP, en çok %OVR_MAX. Hem saldıran hem savunan için; kalıcı değere dokunmaz. Ayar: OVR_STEP, OVR_MAX. */
  var OVR_STEP = .02, OVR_MAX = .3;
  function ownN(e) { var n = 0; for (var k in G.owner) if (G.owner[k] === e) n++; return n; }
  function ovr(e) { return 1 - Math.min(OVR_MAX, Math.max(0, ownN(e) - 3) * OVR_STEP); }
  var pendMsg = '';
  function flushMsg() { if (pendMsg) { var m = pendMsg; pendMsg = ''; try { toast(m); } catch (e) { } } }
  function hookClose() {   // V79: yorgunluk bildirimi savaş ekranı kapanınca çıkar
    if (typeof closeBattle !== 'function' || closeBattle.v79) return;
    var _cb = closeBattle;
    closeBattle = function () { var r = _cb.apply(this, arguments); setTimeout(flushMsg, 600); return r; };
    closeBattle.v79 = 1;
  }
  hookClose();
  function install() {
    if (!window.WCD || typeof WCD.war !== 'function' || WCD.war.v73) return !!(window.WCD && WCD.war && WCD.war.v73);
    var _war = WCD.war;
    WCD.war = function (att, de) {
      var r = _war.apply(this, arguments);
      try {
        if (!G || G.v5 !== 1 || typeof G.pl !== 'string') return r;
        var fa = fac(att) * ovr(att), fb = fac(de) * ovr(de);
        if (fa < 1) r.A = mul(r.A, fa);
        if (fb < 1) r.D = mul(r.D, fb);
        var S = fd().s; S[att] = (S[att] || 0) + 1; S[de] = (S[de] || 0) + 1;   // bu savaştan sonra ikisi de yorulur
        var me = att === G.pl ? att : (de === G.pl ? de : null);
        if (me) {
          var f0 = fac(me), pct = Math.round((1 - f0) * 100);
          if (f0 < 1) pendMsg = '😮‍💨 ' + T('Savaş yorgunluğu: bu tur sonraki savaşlarında değerlerin −%' + pct, 'War fatigue: your stats are −' + pct + '% in further battles this turn');   // V79: savaştan SONRA gösterilir
        }
      } catch (e) { console.error(e); }
      return r;
    };
    WCD.war.v73 = 1; return true;
  }
  if (!install()) { var n = 0, iv = setInterval(function () { if (install() || ++n > 40) clearInterval(iv); }, 250); }
})();
