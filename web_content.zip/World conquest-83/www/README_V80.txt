V80 — TEST EDİLMEDİ (yalnızca JS söz dizimi denetlendi)
1) v60.js: kara sınırı olmayan (deniz aşırı) saldırıda GEMİ + TORPİDO sahnesi (V79'da yazılan, mevcut navalAttack) yalnızca hedef ÇOK KÜÇÜK DEĞİLSE oynar.
   Hedef çok küçükse (TINY) artık kara sınırı olsun olmasın FÜZE ATAR sahnesi oynar (eskiden yalnızca kara komşusunda oynuyordu, deniz aşırı küçük hedefe de gemi gidiyordu).
   Yenilgide karşı taraf sahnesi: savunan çok küçükse gemi gönderilmez (yedek ateş sahnesi).
   Ayar: v60.js TINY (derece cinsinden sınır kutusu eşiği; büyütürsen daha çok ülke "küçük" sayılır).
2) v20.js: rakibin TUR zarında 6 gelince tekrar atma kaldırıldı (tek zar). Oyuncunun tur zarında zaten yoktu (V59).
   6 → tekrar at kuralı artık YALNIZCA savaş panelindeki zarlarda (app.js d6c/d6b; en çok 3 zar).
