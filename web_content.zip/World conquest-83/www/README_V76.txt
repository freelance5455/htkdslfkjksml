V76 — RASTGELE OLAYLAR + MESAJ DÜZELTMESİ (v76.js, v76.css [yeni], v40.js, index.html). TEST EDİLMEDİ (yalnızca JS söz dizimi denetlendi; tarayıcıda oynanmadı).
1) Mesaj: "Lider cezası!" -> "Rakipler gücünüze karşı birleşti!" (v40.js leaderTick toast'u).
2) Olaylar: rakip turu bitince, oyuncu turu başlamadan (V5.start sarmalayıcı) her turda ~%16 olasılıkla, en erken 3. turda, iki olay arası en az 4 tur.
   Yatay açılan parşömen penceresi; Kabul/Reddet; her seçeneğin altında artan(▲) / azalan(▼) değerler yazar (aynı veriden uygulanır).
   - Sığınma talebi (dini lider): Kabul: Diplomasi +%10, komşularla ilişki kötüleşir. Reddet: Diplomasi +%4, ilişkiler iyileşir.
   - Azınlık lideri (komşu ülke): Kabul: o ülkenin 5 değeri −%10, o ülkeyle ilişki kötüleşir; fethedersen o toprakta %50 isyan olasılığı (saldırgan olmasan bile; 2-5 tur sonra bir kez zar atılır).
     Reddet: Diplomasi −%3, o ülkeyle ilişki iyileşir.
   - Ek: Silah tüccarı (Ordu +%8 / Ekonomi −%6), Bilim insanları (Teknoloji +%10 / komşu ilişkisi kötü), Kıtlık (Ekonomi −%8 Nüfus +%5 ya da Nüfus −%6 Diplomasi −%2).
   Ayar: v76.js üst satır EVT_P, EVT_GAP, EVT_FIRST, LIB_REVOLT_CHANCE, LIB_POWER_CUT. Yeni olay eklemek: EVENTS dizisine bir nesne (title/text/yes/no).
   Konsoldan deneme: WCEV.test('refuge') | 'liberate' | 'arms' | 'brain' | 'famine'.
   - Yeni olaylar: Darbe teklifi (komşu: gücü −%12, ilişki kötü, Diplomasi −%5 / red: Diplomasi +%2), Taht kavgası (müttefik gerekir: Ordu −%5 Ekonomi −%4, müttefik gücü +%10, ilişki iyi / red: Diplomasi −%4, ilişki kötü),
     Korsanlar (Ordu −%4 Ekonomi +%6 / red: Ekonomi −%6), Salgın (Ekonomi −%7 Nüfus −%2 / red: Nüfus −%10 Ordu −%3). Konsol: WCEV.test('coup'|'ally'|'pirates'|'plague').
