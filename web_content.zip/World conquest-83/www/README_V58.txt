V58 — TEST EDİLMEDİ (kullanıcı isteğiyle; yalnızca JS söz dizimi denetlendi)
Yalnızca "yatay mod" isteği yapıldı (Yükselt'in üstündeki mesaj). Haraç/renk/zar V57'deki gibi bırakıldı.

DÜZELTİLEN
1) "Dünya çok uzak": app.js area0() yatay telefonda sol ülke panelini (#panel) ve sağ savaş panelini (#bs)
   ALT panel sanıp harita yüksekliğini ~120px'e düşürüyordu -> harita çok küçük/uzak kalıyordu.
   Artık yatayda (orientation:landscape + max-height:520px) paneller YAN panel sayılır: harita alanının
   genişliği panel kadar azalır, yükseklik tam kalır, ülke boş kalan alanın ortasına yakınlaştırılır.
   (area0 + clampT + fit + home + zoomBy sol kaydırma 'x' değerini kullanır.)
2) "Baloncuklar kayıyor/sığmıyor": diplomasi baloncuğu yatayda artık v57.css ile ekranın üstünde ortalı,
   2 sütun, yükseklik = ekran - 12px, taşarsa kendi içinde kaydırılır; satır içi konumlar !important ile ezilir.
   Yön değişirse (dikey<->yatay) açık baloncuk kapatılır. Dikey modda eski davranış (düğmenin üstünde) korunur.
3D küre: V57'deki yatay yakınlık (0.70) aynen duruyor.

EKSİK / RİSK
- Gerçek cihazda denenmedi. 520px'ten yüksek yatay ekranlarda (tablet) eski dikey mantık geçerli.
