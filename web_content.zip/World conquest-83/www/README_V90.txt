V90 — ANA MENÜ KASMA DÜZELTMESİ (V89 üzerine). Oyun kuralları değişmedi.
Sorun: v30.js oyunun 3B küresini açılıştan 600 ms sonra, ana menü küresi (v35.js) başlarken arka planda kuruyordu
  (3072x1536 doku, 320x160 küre, normal haritası; ana thread'de ~sn'lik kilit) ve menünün arkasında gizli küreyi çizmeye devam ediyordu.
Çözüm (yalnızca v30.js):
  - Menü (body.wcm-on) açıkken oyun küresi kurulmaz; menü kapanınca (Yeni Fetih / Seferi Sürdür) kurulur. Menü hiç açılmazsa 3 sn sonra eskisi gibi yüklenir.
  - Menü üstteyken v30 döngüsü kareyi çizmez.
Ölçüm (headless Chromium, yazılım GL): ana thread uzun görevi 6266 ms -> 0; mobil emülasyonda ortalama fps 19 -> 32.
Not: oyun başlayınca 3B küre menüdeyken değil o anda kurulur; ilk ~1-3 sn 2B harita görünür, sonra küre belirir.
