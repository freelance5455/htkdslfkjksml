V92 — SAVAŞ ANİMASYONU SINIR DENETİMİ (V91 üzerine). TEST EDİLMEDİ (yalnızca JS söz dizimi denetlendi, oyun çalıştırılmadı).
Amaç: ateş eden birliklerin yer izdüşümü başka ülkenin sınırını geçmesin; sahne ülkeye göre küçülsün.
1) v60.js place(): kara sahnesinde hata toleransı 2 -> 0. Ölçek listesi 5 -> 9 kademe (en küçük .09). Sığana kadar küçülür.
2) v60.js DL (yoğun denetim): yanal genişlik x ±3'e çıkarıldı, adım .8 -> .6; tank/piyade ayak izinin tamamı denetlenir.
   Başlangıç yarısı yalnızca saldıranın karasında, hedef yarısı hedef ülkede, ara yol yalnızca bu ikisinde olabilir (üçüncü ülke / deniz yok).
3) Yedek ateş sahnesi + füze sahnesi: yeni fireFootOK / fitFireScale — birliklerin durduğu noktalar ve çevresi saldıranın kendi topraklarında kalana
   kadar ölçek %20'şer küçülür (alt sınır SC*.03). Eskiden bu sahnelerde sınır denetimi yoktu.
Ayar: scales (place), DL xs/adım, FP_PTS (v60.js).
