V72 — saldırı animasyonu sağlamlaştırma + kasma azaltma (v30.js, v60.js). Kısa test: oyun hatasız açıldı, saldırıda animasyon başladı.
NEDEN ANİMASYON GÖRÜNMEYEBİLİYORDU: v60.js'te tek bir hata (dosya yüklenemedi, sahne kurulurken istisna) "bad" bayrağını KALICI açıyor,
 oyun yeniden başlatılana kadar tüm animasyonlar sessizce kapanıyordu; ayrıca sonuç düğmesi algılanamazsa hiç başlamıyordu.
 Ayrıca animasyon yalnızca 3B küre açıkken, Ayarlar'da "hareketi azalt" kapalı ve animasyon hızı 0 değilken çalışır (kontrol et).
 Düzeltme: hata sayacı (üst üste 3 hatada kapanır, başarılı sahne sıfırlar), dosya yüklenemezse sonraki savaşta tekrar dener,
 sonuç yazısı algılanamazsa 20 sn sonra yine başlar, hata konsola yazılır.
KASMA: 1) v30.js: sahnede hiçbir şey değişmiyorsa küre yeniden çizilmez (bulutlar için ~4 kare/sn) -> ülke seçiminde GPU yükü düşer.
 2) Telefonda kaplama dokusu 2048x1024 -> 1536x768, piksel oranı 1.5 -> 1.25 (seçimde doku yüklemesi ve dolgu azalır).
 3) v60.js: animasyon dosyası + modeller oyun açıldıktan ~6 sn sonra boş zamanda hazırlanır; saldırı öncesi donma azalır.
V72b: KÜÇÜK ÜLKE: füze eşiği TINY 3.6 → 7° (daha çok küçük ülke füzeyle vurulur); füze sahnesi ölçeği en az SC*0.8 (eskiden 0.35), yedek ateş sahnesi en az 0.6;
 kara sahnesi artık 0.32 altına küçülmez (olmazsa füze/ateş sahnesine geçer). Füze yolu BALİSTİK: yüksek tepe + dik iniş (wc_battle_fx.js missileAttack).
