V97 — SAVAŞ ANİMASYONU GÖRÜNÜRLÜĞÜ + SAVAŞ YORGUNLUĞU KARTI
1) v60.js: kamera uzaklığı artık sahne boyutuna göre (camFor): sahne dar ekran kenarının ~%55'ini kaplar. Eskiden en az 3.0 uzaktı, modeller birkaç piksel kalıyor, animasyon "çalışmıyor" gibi görünüyordu. Füze/ateş sahnelerinin kendi zr değerleri de yakınlaştırıldı. En yakın 1.95.
2) v30.js: animasyon sırasında (v60Active) savaş paneli gizli olduğu için görüntü yukarı kaydırılmaz; sahne ekranda ortalanır.
3) v73.js: yorgunluk bildirimi düz toast yerine kart: ikon, başlık, açıklama (−%N nowrap) ve 4 kademeli gösterge. 3,6 sn görünür; savaş ekranı kapanınca çıkar.
Test: headless Chromium (yazılım GL, çok yavaş): animasyon başlıyor, model görünüyor, kart çıkıyor. Gerçek cihaz hızı ve ilk savaş donması (shader derleme) ölçülemedi.
