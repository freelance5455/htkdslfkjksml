V66 — TEST EDİLMEDİ (yalnızca JS söz dizimi denetlendi)
SAVAŞ ZARI: 6 gelen zar ekranda sabit kalır (altın parıltı), yanına "?" işaretli yeni zar eklenir. Oyuncu ekrana dokununca
yeni zar atılır. En çok 2 kez 6 → yan yana en çok 3 zar. Zarların toplamı hesapta kullanılır; zarın altında "= toplam" yazar.
- Saldıran ve savunan taraf ayrı ayrı: biri 6 atar diğeri atmazsa yalnız o taraf yeni zar alır.
- Yapay zekâ (AI saldırısı / AI savunması) için de aynı kural geçerli (aynı savaş fonksiyonu). Oyuncu dokunmadan "?" zar beklemede kalır.
- Bekleme sırasında dokunmak yeni zarı atar; animasyon sürerken dokunmak (eskisi gibi) sonuca atlar ve tüm zarları gösterir.
- Hızlı/animasyonsuz modda zarlar doğrudan sonuçta gösterilir.
Teknik: app.js d6c/d6b (zar dizisi) + battle sarmalayıcısı (r.da / r.dd); v7.js showBattle (roundRoll/showDice); v65.css.
Tur başı hamle zarında 6'da tekrar atma yok (V59'dan beri).
