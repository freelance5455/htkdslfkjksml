V70 — TEST EDİLMEDİ (yalnızca JS söz dizimi + hatasız yükleme denetlendi)
1) ZAR HATASI (v7.js): Savunan (rakip) tarafın ilk zarı hep 1 kalıyordu, ikinci zar değişiyordu. Sebep: savunan ilk zarın kimliği 'db' iken kod 'dd' arıyor,
   bulamayınca YENİ bir zar ekliyordu (eski zar 1'de kalıyordu). Düzeltildi: her taraf tek zarla başlar; 6 gelirse yalnızca bir sonraki zar atılır, yine 6 ise üçüncü (en çok 3, yan yana).
2) KAMERA (v60.js): animasyon kamerası en yakın 1.5 → 2.2 uzaklıktan başlar; büyük ülkelerde daha da uzak.
3) BÜYÜK ÜLKE = BÜYÜK ANİMASYON (v60.js): sahne ölçeği ülkenin sınır kutusuna göre 1–2.5 kat büyür (kamera görüş sınırı yine aşılmaz).
4) SAVUNAN TARAFTA ANİMASYON YOK (v60.js): kule/ev kaldırıldı. Yalnızca saldıranın tank + piyadesi hedef yönüne ateş eder. Deniz aşırı saldırıda
   hedef gemisi batışı kaldırıldı; yedek ateş sahnesi (tanklar) kullanılır.
5) İZLEME ZORUNLU DEĞİL (v60.js): animasyon sırasında "Animasyonu geç" yanına "Devam ▶" eklendi (animasyonu bırakıp savaşı doğrudan kapatır).
   Kamera savaş alanına bir kez götürülür, kilitlenmez; sürükle/yakınlaştır serbest.
