V60 — TEST EDİLMEDİ (tarayıcıda/telefonda hiç çalıştırılmadı; yalnızca JS söz dizimi denetlendi + Node'da sahte nesnelerle akış testi yapıldı)

YAPILANLAR
1) wc_battle_fx.js (savaş modelleri v5: tank, piyade, kule, ev, gemi + torpido, patlama/duman efektleri) oyuna eklendi.
2) v60.js (yeni): saldırı sonucu hesaplandıktan sonra, eski savaş ekranı açılmadan önce 3B küre üzerinde kısa bir savaş sahnesi oynatır.
   - Kara komşusu → tank + piyade, hedefte kule + ev (saldıran kazandıysa yıkılır, kaybettiyse ayakta kalır).
   - Komşu değil (deniz aşırı) → gemi + torpido (kazanırsa hedef gemi batar).
   - Saldıran MAVİ, savunan KIRMIZI. Sahne iki ülkenin arasındaki noktada, yüzeye dik (normal ekseninde) kurulur; kamera oraya yaklaşır.
   - Ekrana dokununca sahne geçilir ("Geçmek için dokun"). Sahne bitince/geçilince eski savaş ekranı (zarlar, sonuç) aynen açılır.
   - Sonuç/oyun kuralları DEĞİŞMEDİ: animasyon yalnızca hesaplanmış sonucu (r.win) gösterir.
   - Çalışmadığı durumlar (eski davranış aynen): 2B harita, Ayarlar'da "hareketi azalt" veya hız 0, oyuncunun karışmadığı YZ-YZ savaşları, wc_battle_fx.js yüklenemezse.
3) v30.js: küreye küçük bir dış arayüz (window.v30API) + her karede çağrılan kanca eklendi (başka bir şey değişmedi).
4) index.html: v60.js, v57.js'den sonra yüklenir.

AYARLANABİLİR (v60.js'in en üstü)
   SC = 0.022 (modellerin boyutu)  ·  ZOOM = 1.65 (kamera uzaklığı)  ·  TS = 1.3 (animasyon hızı; 1 = demo hızı)
   Tamamen kapatmak için: index.html'den <script src="v60.js"></script> satırını sil.

BİLİNEN RİSKLER / YAPILMAYANLAR (hiç çalıştırılmadığı için ilk açılışta şunlara bak)
- Sahne, iki ülkenin merkez noktalarının ortasına kurulur; gerçek sınır çizgisini aramaz. Büyük/girintili ülkelerde birimler üçüncü bir ülkenin veya denizin üstüne düşebilir.
- Deniz aşırı saldırıda gemiler de iki merkezin ortasında durur (çoğu zaman deniz, ama garanti değil).
- Modeller çok küçük/büyük görünürse SC'yi değiştir. Kamera yatay/dikey ekranda aynı yüzey uzaklığına ayarlandı (yatayda v30 kamerayı 0.7 ile çarpıyor).
- Savaş ışıkları (patlama parlaması) sahneye 3 nokta ışığı ekler: ilk savaşta kürenin gölgelendiricileri bir kez yeniden derlenir, kısa bir takılma olabilir.
- Hedef kule/ev boyutları ve konumları sabit değerlerle verildi; gerçek ekranda üst üste binme/yüzeyde gömülme olabilir.
- Kara savaşında sadece tank+piyade var; topçu/uçak yok. Savunan taraf karşılık ateşi etmez.
- Ses yok. APK derlenmedi (bu ortamda Android SDK yok).
