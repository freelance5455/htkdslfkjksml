V77 — SALDIRI ANİMASYONLARI BÜYÜDÜ + YENİLGİDE KARŞI TARAFIN ANİMASYONU (v60.js). TEST EDİLMEDİ (tarayıcıda oynanmadı; yalnızca JS söz dizimi denetlendi).
1) BÜYÜTME: sahne ölçeği SC 0.034 -> 0.046; tank 0.85 -> 1.15, piyade 0.9 -> 1.2, füze atar 0.9 -> 1.15 (patlamalar da biraz büyük);
   yedek ateş sahnesi ve füze sahnesi ölçeği artırıldı; büyük ülke çarpanı (sizeF) en çok 2.5 -> 3; kamera başlangıç uzaklığı ZOOM 3.2 -> 3.5, ZMIN 2.8 -> 3.0 (büyüyen modeller sığsın).
   Not: modeller büyüdüğü için çok dar/küçük bölgelerde kara sahnesi yerleşemeyebilir; o durumda eskisi gibi yedek ateş / füze sahnesine düşer.
2) YENİLGİDE KARŞI TARAF (yeni): saldırı KAYBEDİLİRSE (r.win = false) saldıran animasyonu bittikten sonra savunan taraf (KIRMIZI) bizim topraklarımıza saldırır:
   - Kara komşusu: savunanın tankı + piyadesi bizim toprağa ateş eder (isabetler bizim ülkenin içinde).
   - Deniz aşırı: savunanın gemisi torpido atar, bizim (mavi) gemi batar. Gemi sahnesi kurulamazsa savunanın tankları kendi kıyısından bize ateş eder.
   Kamera karşı sahneye bir kez yeniden odaklanır, sonrası yine serbest. "Animasyonu geç" / "Devam ▶" karşı sahneyi de kapatır.
   Zaferde karşı sahne oynamaz.
Ayar: v60.js SC (genel boyut), ZOOM/ZMIN (kamera), tank/piyade scale değerleri buildScene içinde.
