V69 — TEST EDİLMEDİ (yalnızca JS söz dizimi + hatasız yükleme denetlendi)
1) DOSTLUK ANTLAŞMASI SÜRESİ (v40.js): ALLY_TURNS = 8. Her ittifak 8 tur sonra kendiliğinden biter (yeni imza/katılım süreyi yeniler;
   eski kayıtlarda süre ilk turda başlar). Süre dolunca renk ortaklığı ve ortak savaş biter, oyuncu ittifaktaysa bildirim çıkar.
   Diplomasi listesinde "N tur kaldı" yazar (v41.js).
2) DOSTA İHANET (v40.js): Oyuncu müttefikine saldırabilir (yapay zekâ saldıramaz). O savaşta müttefik 2 kat güçlü (ek olarak normal savunma bonusu),
   ittifak bozulur. Yalnızca o savaşa özel; sonraki savaşlarda etki yok.
3) FETİH RENKLERİ (v53.js): doygunluk %22-36 → %50-64, parlaklık %40-54 (ne soluk ne cırtlak). Yeşil bandı hariç (dostlara ayrılmıştı).
   Seçim, kullanılmış renklere ve komşulara en uzak renk olacak şekilde yapılır (63 aday; ittifak/bej/oyuncu kırmızısından ≥14 ΔE uzak).
   Eski kayıtlardaki soluk renkler yeni paletle bir kez yeniden atanır.
Ayar: süre için v40.js ALLY_TURNS.
