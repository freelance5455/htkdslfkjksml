V64 — "savaş zarı dönünce duruyor" HATASI DÜZELTİLDİ (v7.js) + önceki değişiklikler

KÖK NEDEN: Savaş zarında 6 gelince tekrar atılır (app.js d6b, toplam en çok 24). Toplam 6'yı aşınca (ör. 6+4=10)
v7.js pipsHtml PP[10] bulamayıp "Cannot read properties of undefined (reading 'map')" hatası veriyordu; hata zar durduktan sonraki
zamanlayıcıda olduğu için beş özellik karşılaştırması ve sonuç hiç gelmiyor, savaş ekranı zarda kalıyordu (rastgele, her savaşta değil).
DÜZELTME: pipsHtml artık (n-1)%6+1 noktası çizer; toplam 6'yı aşarsa zarın köşesinde sarı rozetle toplam yazılır.
Test: headless Chromium'da 6 kara + deniz aşırı hedefe saldırı, zarlar zorla 11-18 toplamıyla; hepsi sonuca ulaştı, hata yok. (Düzeltmeden önce 6 saldırının 2'si takılıyordu.)

Önceki: animasyon zafer yazısından sonra, geniş açı + serbest kamera (V62); panel açıkken küre seyrek çizilir + animasyon ışıkları kaldırıldı (V63).
