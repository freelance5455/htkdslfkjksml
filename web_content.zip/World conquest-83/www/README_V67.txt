V67 — 3B savaş animasyonları (v60.js) — TEST EDİLMEDİ (yalnızca JS söz dizimi denetlendi)
1) BOYUT / BAKIŞ AÇISI: Her karede kameranın sahneye uzaklığı ve ekranın dar kenarı hesaplanır; sahne (tank/piyade/gemi), görüş alanının dar
   kenarının en çok yarısını kaplayacak şekilde ölçeklenir. Oyuncu yakınlaştırdıkça modeller küçülür, uzaklaştırdıkça (en çok yerleşim
   ölçeğine kadar) büyür. Yerleşim ölçeğinin üstüne asla çıkmaz, bu yüzden ülke sınırı denetimi bozulmaz.
2) ÜLKE ALANI: Yol denetimi sıklaştırıldı (iki şerit + orta hat boyunca ~0,8 birim aralıkla ~100 nokta): başlangıç yarısı saldıranın karasında,
   hedef yarısı hedef ülkede, aradaki yol yalnızca bu ikisinin karasında; gemiler yalnızca denizde. Uygun yer bulunamazsa (en çok 2 kenar noktası
   hoşgörü) o saldırının 3B animasyonu hiç kurulmaz — savaş ekranı normal devam eder (başka ülkeye taşma yerine animasyonu atlama seçildi).
3) İKİ MÜTTEFİK SALDIRISI: Saldıranın ittifak üyelerinden biri hedef ülkeyle kara sınırı paylaşıyorsa ikinci bir sahne de kurulur: saldıranın
   kendi sınırından MAVİ, müttefiğin sınırından CAMGÖBEĞİ (turkuaz) birlikler aynı anda saldırır. Kamera iki sahneyi görecek kadar açılır.
   En çok 2 taraf. Müttefik hedefle sınır komşusu değilse (deniz aşırı) ikinci sahne yok.
NOT: "Topçu" modeli animasyon kütüphanesinde yok (yalnızca tank, piyade, gemi). Savunan müttefikleri için ayrı sahne yok.
