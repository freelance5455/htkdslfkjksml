V81 — KÜÇÜK ÜLKELERE UZAKTAN DOKUNMA + YAKINLAŞMA BOZULMASI (v30.js, 3B küre). TEST EDİLMEDİ (yalnızca JS söz dizimi denetlendi).
1) pickNear: dokunulan noktanın ~22 px çevresindeki küçük ülkeler (sınır kutusu toleransın 2 katından küçük) seçilebilir.
   Denizdeyse tam tolerans, büyük bir komşunun içindeyse tolerans %60. Ayar: v30.js PICK_PX (büyüt = daha kolay seçim, ama komşu karışır).
2) Çok küçük ülkelerin (kutu < 2.2°) merkezine ince altın halka çizilir; uzaktan görünür.
3) Yakınlaşınca bozulma: sınır/renk kaplaması çözünürlüğü masaüstü 2048x1024 -> 3072x1536, telefon 1536x768 -> 2048x1024;
   çizgi kalınlığı orantılı (LS), anisotropi 4 -> 8; en yakın kamera uzaklığı 1.5 -> 1.9 (ZMIN3; aşırı yakında bulanıklaşma azalır).
   Not: kaplama büyüdüğü için sahiplik değişince yeniden boyama biraz daha yavaş olabilir. Kasma olursa v30.js'te OW/OH değerlerini düşür.
Yapılmadı: 2B düz harita (gizli katman) değişmedi.
