V82 — V80'deki gerçek 3D zar sistemi V81'e işlendi. TEST EDİLMEDİ (yalnızca JS söz dizimi denetlendi).
Eklenen: dice3d.js, v80.css; index.html'e dice3d.js (v76.js'den sonra) ve v80.css (v76.css'den sonra) bağlandı;
v7.js savaş zarı 3D'ye bağlandı (sonuç zarın ÜST yüzünden okunur; dice3d.js yoksa eski SVG zara düşer).
V81'in kendi değişiklikleri (küçük ülkeye dokunma, küre çözünürlüğü, V80 deniz/füze sahnesi, tur zarında 6 tekrar atma yok) korundu.
