V55 (World conquest-55)
YAPILDI (kısmen test: yükleme hatasız, altın 99.999 görüldü, oyun başlıyor)
- Altın: oyuncu 99999 ile başlar (eski kayıtlarda da bir kez 99999 yapılır) - TEST EDİLDİ
- Kaybeden imparatorluk (birden çok toprağı olan, saldırıda yenilen) varsayılan renge döner, kazandığı topraklar da (v55.js + v53.js kilidi) - TEST EDİLMEDİ
- Üst çubuktaki ülke baloncuğuna tıklayınca kamera oyuncunun ülkesine gider (2B ve 3B) - TEST EDİLMEDİ
- Politikalar X tuşu sağ üste sabitlendi (v55.css) - TEST EDİLMEDİ
- Eski "Koruma Talebi" -> "Tampon Bölge Talebi"; yalnızca oyuncu iki güçlü devlet arasındaysa görünür (v23.js) - TEST EDİLMEDİ
- Yeni "Koruma Talebi": Elçi menüsünde her zaman var; saldırı gelirse talep edilen ülke seninle birlikte saldırgana yönelir (8 tur); olumlu/müttefik ilişkide ücret yarıya iner - TEST EDİLMEDİ
YAPILAMAYAN / EKSİK
- Koruyucu ülke, saldırgana ulaşamasa bile savaşa girer (v55.js targets) - TEST EDİLMEDİ
