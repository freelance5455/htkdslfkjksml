V73 — fetih renkleri birbirinden ayrı + tehlikeli rakiplere sıra gelme ihtimali artar (v53.js, v20.js). TEST EDİLMEDİ (tarayıcıda oynanmadı; yalnızca JS söz dizimi
 + renk mantığı Node'da sahte verilerle, seçim olasılığı model olarak denendi).
1) RENKLER (v53.js): Fetih yapan devletler (Brezilya+Uruguay, Almanya+Fransa gibi >=2 toprağı olanlar) artık birbirine benzemez.
   - Aday renk paleti ~63 -> ~170 (hue adımı 12° -> 6°, daha çok doygunluk/parlaklık çifti). Bej + ittifak renklerinden en az 18 ΔE uzak olanlar aday.
   - Yeni renk seçerken sadece diğer imparatorluklara değil bej ve ittifak renklerine uzaklık da hesaplanır; komşu imparatorluklara ekstra uzak seçilir.
   - Her güncellemede "tekrar kontrolü": iki imparatorluğun rengi ΔE < 22 ise toprağı az olan yeni renk alır (MINDE, v53.js).
   - Renk atanınca/değişince 3B küre ve 2B harita yeniden boyanır (WCD.sig imzasına G.ecol eklendi). Eskiden renk sonradan atanırsa küre eski (bej) rengi tutabiliyordu.
   - Eski kayıtlar bir kez yeni paletle yeniden renklenir (G.ecolV73).
2) SIRA (v20.js pickActors): Oyuncu turu bitince hangi rakibin oynayacağı hâlâ rastgele; ama oyuncuya zarar verebilecek rakiplerin ağırlığı artar:
   tehdit = oyuncunun topraklarına saldırabilme (sayısıyla artar) + oyuncuya göre güçlü olma + oyuncudan intikam bayrağı (G.rv). Saldıramayan uzak rakipler eskisi gibi.
   Ayar: v20.js en üst THREAT_W (0 = eskisi gibi tam rastgele, .4 = varsayılan: 6 rakipli örnekte en tehlikeli ~%17 -> ~%49, uzaklar ~%17 -> ~%5; 1+ = neredeyse hep tehlikeli olan).

V73b — LİDER CEZASI KOALİSYONU + SAVAŞ YORGUNLUĞU + HIZLI AI GELİŞİMİ (v40.js, v73.js [yeni], v20.js, index.html). TEST EDİLMEDİ (tarayıcıda oynanmadı; mantık Node'da sahte verilerle denendi).
3) LİDER CEZASI (v40.js leaderTick, her oyuncu turu başında): oyuncu >= 6 toprağa sahip VE (gücü en güçlü rakibin 1.25 katı veya dünyanın %8'i) ise,
   oyuncunun komşusu/güçlü, ittifaksız 3 yapay zekâ devleti ona karşı otomatik koalisyon (Dostluk Antlaşması) kurar, 8 tur sürer. Büyüdükçe kurulma şansı artar (%35 → %90).
   Üyeler savaşta değerlerini toplar (WCD.side), oyuncuya karşı kışkırtılır (inc23: sıra alma + saldırı önceliği 3 tur). Koalisyon sürerken yenisi kurulmaz; bitince hâlâ liderse tekrar kurulabilir.
   Ayar: v40.js LEADER_MIN_LANDS, LEADER_POWER_RATIO, LEADER_SHARE, LEADER_CO_SIZE (en çok 4), LEADER_TURNS.
4) SAVAŞ YORGUNLUĞU (v73.js): savaşa giren iki taraf (saldıran + savunan) 1 yorgunluk puanı alır; puan başına o tur içindeki sonraki savaşlarında 5 değer de %7 düşer (en çok 4 puan = %28).
   Tur değişince sıfırlanır. Yalnızca savaş hesabına uygulanır, kalıcı değerler değişmez. Oyuncu etkilendiğinde bilgi mesajı çıkar. Ayar: v73.js FAT_STEP, FAT_MAX.
5) AI GELİŞİMİ (v20.js): HATA BULUNDU: V46'dan beri gelişimin kayıt satırı bir // yorumunun içinde kalmıştı → rakipler "gelişti" kartı gösteriyor ama değerleri hiç artmıyordu.
   Düzeltildi ve hızlandırıldı: en zayıf değer x1.12 + 0.7 (eskiden yazılı: x1.08 + 0.5). Ayar: v20.js AI_GROW_MUL / AI_GROW_ADD.
   Not: v40.js balance() (oyuncu çok büyükse rakipleri toparlar) zaten çalışıyordu, değişmedi.
