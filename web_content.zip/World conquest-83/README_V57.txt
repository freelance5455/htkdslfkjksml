V57 (World conquest-57) — TEST EDİLMEDİ (kullanıcı isteğiyle test yapılmadı; yalnızca JS söz dizimi denetlendi)
YAPILDI
- Haraç: haraç ÖDEYEN ülkeye o tur saldıramazsın; o ülkenin müttefiklerine (ittifak üyeleri) ve saldırmazlık/dostluk antlaşması olduğu ülkelere de o tur saldıramazsın (v57.js targets sarmalayıcısı; G.trib57 = {ülke: tur}). "o tur" = haracı aldığın tur olarak yorumlandı.
- Renk: oyuncuyla aktif saldırmazlık antlaşması (G.pacts) veya ittifakı olan ülkeler açık yeşil (hsl(112,55%,72%)). Diğer tüm ülke/ittifak/imparatorluk renkleri 60°-170° yeşil aralığındaysa +130° döndürülür (v57.js col). Renk imzası (WCD.sig) dost listesini içerir, 3B küre/2B harita yeniden boyanır.
- Zar: 6 gelirse tekrar atılır (üst üste en çok 8 zar); hamle hakkı toplam (örn. 6+6+3=15). Ara zarlar "6 geldi — tekrar atıyorsun!" ile otomatik geçer (v5.js startPlayerTurn).
- Yatay ekran: diplomasi baloncuğu ekrana sığacak şekilde 2 sütun, en çok ekran yüksekliği kadar, taşarsa kaydırılır; pencereler (#mod .box) yatayda kaydırılır/sıkıştırıldı (v57.css + v57.js); 3B küre yatayda daha yakın (v30.js 0.86 -> 0.70).
YAPILAMAYAN / EKSİK
- 2B düz harita kamerasının yatayda varsayılan yakınlığı (app.js fit/KMIN) değiştirilmedi; yalnızca 3B küre yaklaştırıldı.
- Yapay zekâ ülkelerinin haraç/antlaşma kuralını ihlal etmesi (oyuncuya saldırması) kapsam dışı: kural yalnızca oyuncunun saldırısına uygulanır.
- Saldırı engellendiğinde ekranda "neden saldıramıyorum" mesajı gösterilmiyor (hedef sadece listeden çıkar).
- Savaş paneli (#bs) ve diğer pencerelerin yatay taşma kontrolü gerçek cihazda yapılmadı.
