#!/usr/bin/env python3
"""Run once after `npx cap add android`. Adds the permissions, the background
service entries and the notification icon that the timer needs."""
import pathlib, re, sys

root = pathlib.Path(__file__).resolve().parent.parent / "android" / "app" / "src" / "main"
manifest = root / "AndroidManifest.xml"
if not manifest.exists():
    sys.exit("android/ not found. Run: npx cap add android")

xml = manifest.read_text(encoding="utf-8")

perms = [
    "android.permission.POST_NOTIFICATIONS",
    "android.permission.SCHEDULE_EXACT_ALARM",
    "android.permission.FOREGROUND_SERVICE",
    "android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK",
    "android.permission.WAKE_LOCK",
    "android.permission.RECEIVE_BOOT_COMPLETED",
]
add_perms = ""
for p in perms:
    if p not in xml:
        add_perms += f'    <uses-permission android:name="{p}" />\n'
if add_perms:
    xml = xml.replace("</manifest>", add_perms + "</manifest>")

svc = "io.capawesome.capacitorjs.plugins.foregroundservice.AndroidForegroundService"
rcv = "io.capawesome.capacitorjs.plugins.foregroundservice.NotificationActionBroadcastReceiver"
add_app = ""
if svc not in xml:
    add_app += f'        <service android:name="{svc}" android:foregroundServiceType="mediaPlayback" android:exported="false" />\n'
if rcv not in xml:
    add_app += f'        <receiver android:name="{rcv}" android:exported="false" />\n'
if add_app:
    xml = xml.replace("</application>", add_app + "    </application>")

manifest.write_text(xml, encoding="utf-8")

drawable = root / "res" / "drawable"
drawable.mkdir(parents=True, exist_ok=True)
(drawable / "ic_stat_timer.xml").write_text(
    '''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp" android:height="24dp"
    android:viewportWidth="24" android:viewportHeight="24">
  <path android:fillColor="#FFFFFFFF"
      android:pathData="M15,1H9v2h6V1zM11,14h2V8h-2v6zM19.03,7.39l1.42,-1.42c-0.43,-0.51 -0.9,-0.99 -1.41,-1.41l-1.42,1.42C16.07,4.74 14.12,4 12,4c-4.97,0 -9,4.03 -9,9s4.02,9 9,9 9,-4.03 9,-9c0,-2.12 -0.74,-4.08 -1.97,-5.61zM12,20c-3.87,0 -7,-3.13 -7,-7s3.13,-7 7,-7 7,3.13 7,7 -3.13,7 -7,7z"/>
</vector>
''', encoding="utf-8")
print("patched", manifest)
