// Punto de entrada. Arranque en pasos reales; cada paso avanza el progreso del splash.
import { detectProfile } from './core/device.js';
import { LayerManager } from './core/layers.js';
import { settings } from './core/settings.js';
import { loadThree } from './core/threeLoader.js';
import { openStore } from './storage/db.js';
import { warmUpWorker } from './import/client.js';
import { Importer } from './import/importer.js';
import { createSplash } from './layers/splash.js';
import { createHub } from './layers/hub.js';
import { toast } from './ui/toast.js';

const MIN_SPLASH_MS = 1600;
const THREE_TIMEOUT_MS = 9000;

const withTimeout = (promise, ms) =>
  Promise.race([promise, new Promise((_, reject) => setTimeout(() => reject(new Error('tiempo agotado')), ms))]);

async function boot() {
  const root = document.getElementById('app');
  const profile = detectProfile();
  const layers = new LayerManager(root);
  const splash = createSplash({ profile });
  layers.register('splash', splash);
  await layers.show('splash');

  const notes = [];
  let store = null;
  const started = performance.now();

  const steps = [
    {
      label: 'Detectando dispositivo…',
      weight: 1,
      run: async () => {
        if (!profile.webgl.ok) {
          notes.push({ kind: 'warn', text: 'Este dispositivo no ofrece WebGL 2. Podrás importar y guardar modelos, pero verás miniaturas 2D y no habrá vista previa 3D.' });
        }
      },
    },
    {
      label: 'Abriendo la biblioteca…',
      weight: 3,
      run: async () => {
        store = await openStore();
        if (!store.persistent) {
          notes.push({ kind: 'warn', text: 'El navegador no permite guardar archivos (¿ventana privada?). Los modelos se perderán al cerrar esta pestaña.' });
        } else {
          const removed = await store.repairOrphans().catch(() => 0);
          if (removed) console.info(`[db] se limpiaron ${removed} importaciones interrumpidas`);
        }
      },
    },
    {
      label: 'Restaurando ajustes…',
      weight: 1,
      run: async () => {
        await settings.load(store, profile);
      },
    },
    {
      label: 'Preparando el importador…',
      weight: 2,
      run: async () => {
        await warmUpWorker();
      },
    },
    {
      label: 'Cargando el motor 3D…',
      weight: 4,
      run: async () => {
        try {
          await withTimeout(loadThree(), THREE_TIMEOUT_MS);
        } catch (err) {
          console.warn('[boot] Three.js:', err);
          notes.push({
            kind: 'warn',
            text: 'No se pudo cargar el motor 3D (¿sin conexión?). Las miniaturas serán 2D y la vista previa 3D se reintentará al abrir un modelo.',
          });
        }
      },
    },
  ];

  const totalWeight = steps.reduce((s, x) => s + x.weight, 0);
  let done = 0;
  for (const step of steps) {
    splash.setProgress(done / totalWeight, step.label);
    try {
      await step.run();
    } catch (err) {
      console.error(`[boot] «${step.label}»`, err);
      notes.push({ kind: 'warn', text: `Falló un paso del arranque (${step.label.replace('…', '')}). La app seguirá con funciones limitadas.` });
    }
    done += step.weight;
    splash.setProgress(done / totalWeight);
  }

  // Un respaldo en memoria siempre existe: si todo falló, la app igualmente funciona.
  if (!store) store = await openStore();

  const remaining = MIN_SPLASH_MS - (performance.now() - started);
  if (remaining > 0) await new Promise((r) => setTimeout(r, remaining));
  await splash.finish();

  const importer = new Importer(store, { useWebGL: profile.webgl.ok });
  const hub = createHub({ store, importer, layers, profile, notes });
  layers.register('hub', hub);
  await layers.show('hub');

  // Estado accesible desde la consola para depurar en el móvil (chrome://inspect).
  window.rigworld = { profile, store, importer, layers, settings };
}

let lastErrorToast = 0;
function reportUnexpected(message) {
  const now = Date.now();
  if (now - lastErrorToast < 6000) return;
  lastErrorToast = now;
  toast('Ocurrió un error inesperado. Si se repite, recarga la página.', { kind: 'error' });
  console.error('[error global]', message);
}
window.addEventListener('error', (e) => reportUnexpected(e.message));
window.addEventListener('unhandledrejection', (e) => {
  if (e.reason?.name === 'AbortError') return;
  reportUnexpected(e.reason?.message || e.reason);
});

boot().catch((err) => {
  console.error('[boot] fallo crítico', err);
  const root = document.getElementById('app');
  root.textContent = '';
  const box = document.createElement('div');
  box.className = 'fatal gutter';
  const title = document.createElement('h1');
  title.textContent = 'No se pudo iniciar RigWorld';
  const p = document.createElement('p');
  p.textContent = `${err?.message || err}. Recarga la página; si persiste, prueba un navegador actualizado (Chrome para Android 100 o superior).`;
  box.append(title, p);
  root.append(box);
});
