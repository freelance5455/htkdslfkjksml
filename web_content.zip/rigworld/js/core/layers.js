// Gestor de capas: muestra una capa a la vez con transición, y una pila de
// superposiciones (hojas, vista previa) enlazada al botón Atrás del sistema.
//
// Contrato de una capa: { el: HTMLElement, enter?(params), exit?() }

const TRANSITION_MS = 420;

export class LayerManager {
  constructor(root) {
    this.root = root;
    this.layers = new Map();
    this.currentId = null;
    this.overlays = [];
    window.addEventListener('popstate', () => this.#onPop());
  }

  register(id, controller) {
    controller.el.classList.add('layer');
    controller.el.dataset.layer = id;
    controller.el.inert = true;
    controller.el.setAttribute('aria-hidden', 'true');
    this.layers.set(id, controller);
    this.root.append(controller.el);
  }

  async show(id, params) {
    const next = this.layers.get(id);
    if (!next) throw new Error(`Capa desconocida: ${id}`);
    const prev = this.layers.get(this.currentId);
    if (prev === next) return;
    this.currentId = id;

    await next.enter?.(params);
    next.el.inert = false;
    next.el.removeAttribute('aria-hidden');
    // Dos fotogramas para que la transición CSS arranque desde el estado oculto.
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    next.el.classList.add('is-active');

    if (prev) {
      prev.el.classList.remove('is-active');
      prev.el.inert = true;
      prev.el.setAttribute('aria-hidden', 'true');
      setTimeout(() => prev.exit?.(), TRANSITION_MS);
    }
  }

  // Registra una superposición. Devuelve una función para cerrarla desde la propia UI.
  // `close` se ejecuta siempre una sola vez, ya sea por el botón Atrás o por la UI.
  pushOverlay(close) {
    const entry = { close, closed: false, hist: false };
    this.overlays.push(entry);
    try {
      history.pushState({ rwOverlay: this.overlays.length }, '');
      entry.hist = true;
    } catch {
      entry.hist = false;
    }
    const dismiss = () => this.#dismiss(entry);
    // Permite a quien abre la superposición saber si es la de más arriba (p. ej. para la tecla Escape).
    dismiss.isTop = () => !entry.closed && this.overlays[this.overlays.length - 1] === entry;
    return dismiss;
  }

  #dismiss(entry) {
    if (entry.closed) return;
    const isTop = this.overlays[this.overlays.length - 1] === entry;
    if (entry.hist && isTop) {
      try {
        history.back(); // popstate ejecutará #close
        // Si el navegador no emite popstate, cerramos igualmente.
        setTimeout(() => this.#close(entry), 300);
        return;
      } catch {
        /* cae al cierre directo */
      }
    }
    this.#close(entry);
  }

  #onPop() {
    const top = this.overlays[this.overlays.length - 1];
    if (top) this.#close(top);
  }

  #close(entry) {
    if (entry.closed) return;
    entry.closed = true;
    this.overlays = this.overlays.filter((e) => e !== entry);
    try {
      entry.close();
    } catch (err) {
      console.error('[layers] error al cerrar la superposición', err);
    }
  }
}
