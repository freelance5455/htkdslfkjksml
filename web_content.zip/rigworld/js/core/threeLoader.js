// Carga perezosa de Three.js. Ningún módulo importa «three» de forma estática:
// si la CDN falla, la app sigue funcionando (sin 3D) en lugar de quedarse en blanco.

let promise = null;
let loaded = false;

export function loadThree() {
  if (!promise) {
    promise = import('three')
      .then((THREE) => {
        loaded = true;
        return THREE;
      })
      .catch((err) => {
        promise = null; // permite reintentar
        console.warn('[three] no se pudo cargar:', err);
        throw new Error('No se pudo cargar el motor 3D. Revisa tu conexión a internet y pulsa Reintentar.');
      });
  }
  return promise;
}

// ¿Three.js ya está cargado en esta sesión? (no dispara la carga)
export const isThreeLoaded = () => loaded;
