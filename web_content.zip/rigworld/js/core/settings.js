// Ajustes de visualización. Se guardan en IndexedDB y se aplican en vivo.
import { bus } from './bus.js';

const KEY = 'view';
let values = { budgetTris: 200000, pixelRatioCap: 1.5, reducedMotion: false };
let storage = null;

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

function sanitize(raw) {
  const out = { ...values };
  if (Number.isFinite(raw?.budgetTris)) out.budgetTris = clamp(Math.round(raw.budgetTris / 10000) * 10000, 20000, 600000);
  if (Number.isFinite(raw?.pixelRatioCap)) out.pixelRatioCap = clamp(raw.pixelRatioCap, 1, 2);
  if (typeof raw?.reducedMotion === 'boolean') out.reducedMotion = raw.reducedMotion;
  return out;
}

function apply() {
  if (typeof document !== 'undefined') {
    document.documentElement.classList.toggle('reduce-motion', values.reducedMotion);
  }
}

export const settings = {
  get: (key) => values[key],
  all: () => ({ ...values }),

  async load(store, profile) {
    storage = store;
    values = sanitize({
      budgetTris: profile.budgetTris,
      pixelRatioCap: profile.pixelRatioCap,
      reducedMotion: profile.reducedMotion,
    });
    const saved = await store.getSetting(KEY, null).catch(() => null);
    if (saved) values = sanitize(saved);
    apply();
    return this.all();
  },

  async update(patch) {
    values = sanitize({ ...values, ...patch });
    apply();
    bus.emit('settings:changed', this.all());
    try {
      await storage?.setSetting(KEY, values);
    } catch (err) {
      console.warn('[settings] no se pudo guardar', err);
    }
    return this.all();
  },
};
