// Utilidades WebGL.
// Nota: Three.js desde r163 eliminó el soporte de WebGL 1. Si el dispositivo no
// ofrece WebGL 2, la app sigue funcionando sin escenas 3D (miniaturas y vista previa).

export function probeWebGL2() {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2');
    if (!gl) return { ok: false, version: 0 };
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return { ok: true, version: 2 };
  } catch {
    return { ok: false, version: 0 };
  }
}

export function createRenderer(THREE, canvas, { antialias = false, alpha = true, pixelRatio = 1 } = {}) {
  try {
    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias,
      alpha,
      stencil: false,
      powerPreference: 'high-performance',
    });
    renderer.setPixelRatio(pixelRatio);
    return renderer;
  } catch (err) {
    console.warn('[gl] no se pudo crear el renderer WebGL', err);
    return null;
  }
}

export function releaseRenderer(renderer) {
  if (!renderer) return;
  try {
    renderer.dispose();
    renderer.forceContextLoss?.();
  } catch {
    /* ya liberado */
  }
}
