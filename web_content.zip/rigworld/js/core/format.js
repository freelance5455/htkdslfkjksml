// Formateo de números, tamaños y fechas (sin dependencias).

export function fmtBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes < 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let v = bytes;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  const digits = i === 0 || v >= 100 ? 0 : v >= 10 ? 1 : 2;
  return `${v.toFixed(digits)} ${units[i]}`;
}

export function fmtCount(n) {
  if (!Number.isFinite(n)) return '0';
  if (n >= 1e6) return `${(n / 1e6).toFixed(n >= 1e7 ? 0 : 1)} M`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(n >= 1e4 ? 0 : 1)} k`;
  return String(Math.round(n));
}

export function fmtNum(n) {
  if (!Number.isFinite(n)) return '0';
  return Math.round(n).toLocaleString('es');
}

export function fmtDate(ms) {
  try {
    return new Date(ms).toLocaleDateString('es', { day: 'numeric', month: 'short', year: 'numeric' });
  } catch {
    return '';
  }
}

export function fmtDim(n) {
  if (!Number.isFinite(n)) return '0';
  const a = Math.abs(n);
  const d = a >= 100 ? 0 : a >= 10 ? 1 : 2;
  return n.toFixed(d);
}
