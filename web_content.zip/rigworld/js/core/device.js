// Detección de capacidades del dispositivo para ajustar calidad por defecto.
import { probeWebGL2 } from './gl.js';

export function detectProfile() {
  const nav = typeof navigator !== 'undefined' ? navigator : {};
  const cores = nav.hardwareConcurrency || 4;
  const memGB = nav.deviceMemory || 4;
  const dpr = typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1;
  const isAndroid = /Android/i.test(nav.userAgent || '');
  const reducedMotion =
    typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;

  let tier = 'high';
  if (memGB <= 2 || cores <= 4) tier = 'low';
  else if (memGB <= 4 || cores <= 6) tier = 'mid';

  return {
    tier,
    cores,
    memGB,
    dpr,
    isAndroid,
    reducedMotion,
    webgl: probeWebGL2(),
    antialias: tier !== 'low',
    pixelRatioCap: { low: 1, mid: 1.5, high: 2 }[tier],
    budgetTris: { low: 100000, mid: 200000, high: 350000 }[tier],
    particles: { low: 500, mid: 900, high: 1400 }[tier],
    maxFps: tier === 'low' ? 30 : 60,
  };
}
