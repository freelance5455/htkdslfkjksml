// Plantilla del esqueleto humanoide de 19 articulaciones, en pose T, en metros.
// El personaje mira hacia +Z; su lado izquierdo es +X. El orden garantiza que
// el índice del padre es siempre menor que el del hijo.
// La Fase 2 (Auto-Rig) reutiliza esta definición como destino de la predicción.

export const HUMANOID_19 = Object.freeze([
  { name: 'Hips', parent: -1, pos: [0, 0.95, 0] },
  { name: 'Spine', parent: 0, pos: [0, 1.1, 0] },
  { name: 'Chest', parent: 1, pos: [0, 1.3, 0] },
  { name: 'Neck', parent: 2, pos: [0, 1.5, 0] },
  { name: 'Head', parent: 3, pos: [0, 1.62, 0] },
  { name: 'LeftShoulder', parent: 2, pos: [0.08, 1.45, 0] },
  { name: 'LeftUpperArm', parent: 5, pos: [0.2, 1.45, 0] },
  { name: 'LeftLowerArm', parent: 6, pos: [0.5, 1.45, 0] },
  { name: 'LeftHand', parent: 7, pos: [0.78, 1.45, 0] },
  { name: 'RightShoulder', parent: 2, pos: [-0.08, 1.45, 0] },
  { name: 'RightUpperArm', parent: 9, pos: [-0.2, 1.45, 0] },
  { name: 'RightLowerArm', parent: 10, pos: [-0.5, 1.45, 0] },
  { name: 'RightHand', parent: 11, pos: [-0.78, 1.45, 0] },
  { name: 'LeftUpperLeg', parent: 0, pos: [0.09, 0.92, 0] },
  { name: 'LeftLowerLeg', parent: 13, pos: [0.09, 0.5, 0.01] },
  { name: 'LeftFoot', parent: 14, pos: [0.09, 0.08, 0] },
  { name: 'RightUpperLeg', parent: 0, pos: [-0.09, 0.92, 0] },
  { name: 'RightLowerLeg', parent: 16, pos: [-0.09, 0.5, 0.01] },
  { name: 'RightFoot', parent: 17, pos: [-0.09, 0.08, 0] },
]);

export const BONE_NAMES = Object.freeze(HUMANOID_19.map((j) => j.name));

// Radio aproximado del volumen del cuerpo alrededor de cada hueso (hueso = padre → hijo),
// usado por la pantalla de inicio para dibujar la silueta de puntos.
export const BONE_RADIUS = Object.freeze({
  Spine: 0.13,
  Chest: 0.15,
  Neck: 0.05,
  Head: 0.1,
  LeftShoulder: 0.06,
  LeftUpperArm: 0.05,
  LeftLowerArm: 0.04,
  LeftHand: 0.04,
  RightShoulder: 0.06,
  RightUpperArm: 0.05,
  RightLowerArm: 0.04,
  RightHand: 0.04,
  LeftUpperLeg: 0.08,
  LeftLowerLeg: 0.06,
  LeftFoot: 0.05,
  RightUpperLeg: 0.08,
  RightLowerLeg: 0.06,
  RightFoot: 0.05,
});
