// Bus de eventos mínimo para desacoplar capas, importador y almacenamiento.

class Bus {
  #handlers = new Map();

  on(event, fn) {
    let set = this.#handlers.get(event);
    if (!set) {
      set = new Set();
      this.#handlers.set(event, set);
    }
    set.add(fn);
    return () => set.delete(fn);
  }

  emit(event, payload) {
    const set = this.#handlers.get(event);
    if (!set) return;
    for (const fn of [...set]) {
      try {
        fn(payload);
      } catch (err) {
        console.error(`[bus] error en el manejador de «${event}»`, err);
      }
    }
  }
}

export const bus = new Bus();
