// Lector PLY (ASCII, binario little-endian y big-endian). Triangula caras con abanico.
import { scanLines, readAllBytes, sliceBuffer, byteSize } from './lines.js';
import { GrowU32 } from './mesh.js';

const TYPES = {
  char: ['getInt8', 1], int8: ['getInt8', 1],
  uchar: ['getUint8', 1], uint8: ['getUint8', 1],
  short: ['getInt16', 2], int16: ['getInt16', 2],
  ushort: ['getUint16', 2], uint16: ['getUint16', 2],
  int: ['getInt32', 4], int32: ['getInt32', 4],
  uint: ['getUint32', 4], uint32: ['getUint32', 4],
  float: ['getFloat32', 4], float32: ['getFloat32', 4],
  double: ['getFloat64', 8], float64: ['getFloat64', 8],
};
const NORM = { uchar: 255, uint8: 255, ushort: 65535, uint16: 65535 };

async function readHeader(source) {
  const probe = new Uint8Array(await sliceBuffer(source, 0, 65536));
  let text = '';
  for (let i = 0; i < probe.length; i++) text += String.fromCharCode(probe[i]);
  const m = /end_header\r?\n/.exec(text);
  if (!m) throw new Error('El PLY no tiene una cabecera válida (falta end_header).');
  const headerText = text.slice(0, m.index);
  const dataStart = m.index + m[0].length;
  const lines = headerText.split(/\r?\n/);
  if (lines[0].trim() !== 'ply') throw new Error('El archivo no es un PLY válido.');

  let format = null;
  const elements = [];
  for (const raw of lines.slice(1)) {
    const t = raw.trim().split(/\s+/);
    if (t[0] === 'format') format = t[1];
    else if (t[0] === 'element') elements.push({ name: t[1], count: parseInt(t[2], 10), props: [] });
    else if (t[0] === 'property') {
      const el = elements[elements.length - 1];
      if (!el) continue;
      if (t[1] === 'list') el.props.push({ list: true, countType: t[2], type: t[3], name: t[4] });
      else el.props.push({ list: false, type: t[1], name: t[2] });
    }
  }
  if (!['ascii', 'binary_little_endian', 'binary_big_endian'].includes(format)) {
    throw new Error(`Formato PLY no compatible: ${format || 'desconocido'}.`);
  }
  for (const el of elements) {
    for (const p of el.props) {
      if (!TYPES[p.type] || (p.list && !TYPES[p.countType])) throw new Error(`Tipo de dato PLY no compatible en «${el.name}.${p.name}».`);
    }
  }
  return { format, elements, dataStart };
}

// Prepara dónde se guardará cada propiedad del elemento «vertex».
function vertexTargets(el) {
  const n = el.count;
  const idx = (names) => el.props.findIndex((p) => !p.list && names.includes(p.name));
  const ix = idx(['x']), iy = idx(['y']), iz = idx(['z']);
  if (ix < 0 || iy < 0 || iz < 0) throw new Error('El PLY no define x, y, z en los vértices.');
  const nx = idx(['nx']), ny = idx(['ny']), nz = idx(['nz']);
  const iu = idx(['s', 'u', 'texture_u', 'texture_s']), iv = idx(['t', 'v', 'texture_v', 'texture_t']);
  const ir = idx(['red', 'r']), ig = idx(['green', 'g']), ib = idx(['blue', 'b']);
  return {
    positions: new Float32Array(n * 3),
    normals: nx >= 0 && ny >= 0 && nz >= 0 ? new Float32Array(n * 3) : null,
    uvs: iu >= 0 && iv >= 0 ? new Float32Array(n * 2) : null,
    colors: ir >= 0 && ig >= 0 && ib >= 0 ? new Float32Array(n * 3) : null,
    ix, iy, iz, nx, ny, nz, iu, iv, ir, ig, ib,
  };
}

function storeVertex(t, v, row, el) {
  const p = v * 3;
  t.positions[p] = row[t.ix];
  t.positions[p + 1] = row[t.iy];
  t.positions[p + 2] = row[t.iz];
  if (t.normals) {
    t.normals[p] = row[t.nx];
    t.normals[p + 1] = row[t.ny];
    t.normals[p + 2] = row[t.nz];
  }
  if (t.uvs) {
    t.uvs[v * 2] = row[t.iu];
    t.uvs[v * 2 + 1] = row[t.iv];
  }
  if (t.colors) {
    const kr = NORM[el.props[t.ir].type] || 1, kg = NORM[el.props[t.ig].type] || 1, kb = NORM[el.props[t.ib].type] || 1;
    t.colors[p] = row[t.ir] / kr;
    t.colors[p + 1] = row[t.ig] / kg;
    t.colors[p + 2] = row[t.ib] / kb;
  }
}

function addFace(tris, ids, vcount) {
  for (let k = 1; k + 1 < ids.length; k++) {
    const a = ids[0], b = ids[k], c = ids[k + 1];
    if (a < vcount && b < vcount && c < vcount) tris.push3(a, b, c);
  }
}

export async function parsePly(source, { onProgress } = {}) {
  const { format, elements, dataStart } = await readHeader(source);
  const vEl = elements.find((e) => e.name === 'vertex');
  if (!vEl || !vEl.count) throw new Error('El PLY no contiene vértices.');
  const fEl = elements.find((e) => e.name === 'face');
  if (!fEl || !fEl.count) {
    throw new Error('El PLY solo contiene puntos (nube de puntos) y no tiene caras. Reconstruye una superficie antes de importarlo.');
  }
  const t = vertexTargets(vEl);
  const tris = new GrowU32(1 << 15);
  const faceListIdx = fEl.props.findIndex((p) => p.list && (p.name === 'vertex_indices' || p.name === 'vertex_index'));
  if (faceListIdx < 0) throw new Error('El PLY no define vertex_indices en las caras.');

  if (format === 'ascii') {
    let ei = 0;
    let remaining = elements[0]?.count ?? 0;
    const row = [];
    const ids = [];
    await scanLines(
      source,
      (line) => {
        const s = line.trim();
        if (!s) return;
        while (ei < elements.length && remaining === 0) {
          ei++;
          remaining = elements[ei]?.count ?? 0;
        }
        if (ei >= elements.length) return false;
        const el = elements[ei];
        const tok = s.split(/\s+/);
        let k = 0;
        row.length = 0;
        ids.length = 0;
        for (let pi = 0; pi < el.props.length; pi++) {
          const p = el.props[pi];
          if (p.list) {
            const n = parseInt(tok[k++], 10);
            for (let j = 0; j < n; j++) {
              const val = parseFloat(tok[k++]);
              if (el === fEl && pi === faceListIdx) ids.push(val);
            }
            row.push(0);
          } else row.push(parseFloat(tok[k++]));
        }
        if (el === vEl) storeVertex(t, vEl.count - remaining, row, vEl);
        else if (el === fEl) addFace(tris, ids, vEl.count);
        remaining--;
      },
      { onProgress, startByte: dataStart },
    );
  } else {
    const little = format === 'binary_little_endian';
    const buf = await readAllBytes(source);
    const dv = new DataView(buf);
    let o = dataStart;
    const ids = [];
    try {
      readBinaryElements();
    } catch (err) {
      if (err instanceof RangeError) throw new Error('El PLY está truncado: faltan datos.');
      throw err;
    }
    onProgress?.(1);

    function readBinaryElements() {
    for (const el of elements) {
      const reads = el.props.map((p) => ({ ...p, get: TYPES[p.type][0], size: TYPES[p.type][1], cget: p.list ? TYPES[p.countType][0] : null, csize: p.list ? TYPES[p.countType][1] : 0 }));
      const row = new Array(reads.length).fill(0);
      for (let i = 0; i < el.count; i++) {
        ids.length = 0;
        for (let pi = 0; pi < reads.length; pi++) {
          const p = reads[pi];
          if (p.list) {
            const n = dv[p.cget](o, little);
            o += p.csize;
            const keep = el === fEl && pi === faceListIdx;
            for (let j = 0; j < n; j++) {
              if (keep) ids.push(dv[p.get](o, little));
              o += p.size;
            }
          } else {
            row[pi] = dv[p.get](o, little);
            o += p.size;
          }
        }
        if (el === vEl) storeVertex(t, i, row, vEl);
        else if (el === fEl) addFace(tris, ids, vEl.count);
        if ((i & 0x3ffff) === 0) onProgress?.(Math.min(1, (o - dataStart) / Math.max(1, byteSize(source) - dataStart)));
      }
      if (o > buf.byteLength) throw new RangeError('truncado');
    }
    }
  }

  if (tris.n === 0) throw new Error('El PLY no contiene caras utilizables.');
  return {
    meshes: [{ name: 'ply', positions: t.positions, normals: t.normals, uvs: t.uvs, colors: t.colors, indices: tris.toArray(), material: 0 }],
    materials: [{ name: 'default', color: [0.8, 0.8, 0.82], opacity: 1, map: -1, doubleSided: true, colorLinear: false }],
    images: [],
    info: { vertices: vEl.count, plyFormat: format },
    warnings: [],
  };
}
