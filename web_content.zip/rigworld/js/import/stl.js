// Lector STL (binario y ASCII). Produce una malla sin índices con normales planas.
import { scanLines, readAllBytes, sliceBuffer, byteSize } from './lines.js';
import { GrowF32, weldMesh } from './mesh.js';
import { isBinaryStl } from './formats.js';

const WELD_LIMIT_TRIS = 150000; // por encima, no se calcula el número de vértices únicos

export async function parseStl(source, { onProgress } = {}) {
  const size = byteSize(source);
  const head = new Uint8Array(await sliceBuffer(source, 0, 84));
  const binary = isBinaryStl(head, size);
  let positions;

  if (binary) {
    const buf = await readAllBytes(source);
    const dv = new DataView(buf);
    const count = dv.getUint32(80, true);
    positions = new Float32Array(count * 9);
    let o = 84;
    let w = 0;
    for (let t = 0; t < count; t++) {
      o += 12; // normal del archivo (se recalcula)
      for (let k = 0; k < 9; k++, o += 4) positions[w++] = dv.getFloat32(o, true);
      o += 2; // atributos
      if ((t & 0x3ffff) === 0) onProgress?.(t / count);
    }
    onProgress?.(1);
  } else {
    const acc = new GrowF32(1 << 16);
    await scanLines(
      source,
      (line) => {
        const s = line.trimStart();
        if (s.charCodeAt(0) !== 118 /* v */ || !s.startsWith('vertex')) return;
        const p = s.split(/\s+/);
        const x = parseFloat(p[1]), y = parseFloat(p[2]), z = parseFloat(p[3]);
        if (Number.isFinite(x) && Number.isFinite(y) && Number.isFinite(z)) acc.push3(x, y, z);
      },
      { onProgress },
    );
    const usable = acc.n - (acc.n % 9);
    positions = acc.a.slice(0, usable);
  }

  const tris = positions.length / 9;
  if (tris === 0) throw new Error('El STL no contiene triángulos.');
  const vertices = tris <= WELD_LIMIT_TRIS ? weldMesh(positions).positions.length / 3 : null;

  return {
    meshes: [{ name: 'stl', positions, normals: null, uvs: null, colors: null, indices: null, material: 0 }],
    materials: [{ name: 'default', color: [0.78, 0.78, 0.8], opacity: 1, map: -1, doubleSided: true, colorLinear: false }],
    images: [],
    info: { vertices, stlKind: binary ? 'binario' : 'ASCII' },
    warnings: [],
  };
}
