// Importación con los loaders oficiales de Three.js, en el hilo principal (necesitan DOM):
//   · FBX (FBXLoader)     · DAE/Collada (ColladaLoader)
//   · glTF/GLB con Draco o meshopt (GLTFLoader + DRACOLoader + MeshoptDecoder)
// objectToRaw() no usa Three.js directamente: convierte cualquier Object3D a mallas neutras,
// así que se prueba en Node con objetos simulados.
import { loadThree } from '../core/threeLoader.js';
import { DRACO_DECODER_PATH } from '../config.js';
import { baseName } from './formats.js';
import { bakeWorld, flipWinding, ensureNormals } from './mesh.js';
import { finalizeModel } from './parse.js';

const DOUBLE_SIDE = 2; // THREE.DoubleSide
const TRANSPARENT_PX = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';

function readAttr(attr, size) {
  if (!attr) return null;
  const n = attr.count;
  if (!attr.isInterleavedBufferAttribute && !attr.normalized && attr.itemSize === size && attr.array instanceof Float32Array) {
    return attr.array.slice(0, n * size);
  }
  const out = new Float32Array(n * size);
  for (let i = 0; i < n; i++) {
    out[i * size] = attr.getX(i);
    if (size > 1) out[i * size + 1] = attr.getY(i);
    if (size > 2) out[i * size + 2] = attr.getZ(i);
  }
  return out;
}

function isDrawable(image) {
  if (!image) return false;
  const w = image.naturalWidth || image.videoWidth || image.width;
  const h = image.naturalHeight || image.videoHeight || image.height;
  return w > 0 && h > 0 && typeof image.data === 'undefined';
}

export function objectToRaw(root) {
  root.updateMatrixWorld?.(true);
  const meshes = [];
  const materials = [];
  const images = [];
  const warnings = [];
  const matIndex = new Map();
  const imgIndex = new Map();
  let hasSkeleton = false;

  const imageFor = (tex) => {
    if (!tex || !isDrawable(tex.image)) return -1;
    if (imgIndex.has(tex.image)) return imgIndex.get(tex.image);
    images.push({ name: tex.name || tex.image.currentSrc?.split('/').pop()?.slice(0, 60) || `textura_${images.length}`, image: tex.image });
    imgIndex.set(tex.image, images.length - 1);
    return images.length - 1;
  };

  const materialFor = (m) => {
    if (!m) m = {};
    if (matIndex.has(m)) return matIndex.get(m);
    const c = m.color;
    materials.push({
      name: m.name || `material_${materials.length}`,
      color: c ? [c.r, c.g, c.b] : [0.8, 0.8, 0.82],
      opacity: m.transparent && Number.isFinite(m.opacity) ? m.opacity : 1,
      map: imageFor(m.map),
      doubleSided: m.side === DOUBLE_SIDE,
      colorLinear: true, // Three.js guarda Color en espacio lineal
    });
    matIndex.set(m, materials.length - 1);
    return materials.length - 1;
  };

  root.traverse((o) => {
    if (o.isBone || o.isSkinnedMesh) hasSkeleton = true;
    if (!o.isMesh || !o.geometry?.attributes?.position) return;
    const g = o.geometry;
    const basePos = readAttr(g.attributes.position, 3);
    const baseNor = readAttr(g.attributes.normal, 3);
    const baseUv = readAttr(g.attributes.uv, 2);
    const baseCol = readAttr(g.attributes.color, 3);
    const baked = bakeWorld(o.matrixWorld.elements, basePos, baseNor);
    const index = g.index ? Uint32Array.from(g.index.array) : null;
    const mats = Array.isArray(o.material) ? o.material : [o.material];
    const groups = Array.isArray(o.material) && g.groups?.length
      ? g.groups
      : [{ start: 0, count: index ? index.length : basePos.length / 3, materialIndex: 0 }];

    for (const grp of groups) {
      const start = grp.start;
      const count = Math.min(grp.count, (index ? index.length : basePos.length / 3) - start);
      if (count < 3) continue;
      let idx;
      if (index) idx = index.slice(start, start + count);
      else idx = Uint32Array.from({ length: count }, (_, i) => start + i);
      if (baked.flipped) idx = flipWinding(idx, 0);
      meshes.push({
        name: o.name || `malla_${meshes.length}`,
        positions: baked.positions.slice(),
        normals: baked.normals ? baked.normals.slice() : null,
        uvs: baseUv ? baseUv.slice() : null,
        colors: baseCol ? baseCol.slice() : null,
        indices: idx,
        material: materialFor(mats[grp.materialIndex] ?? mats[0]),
      });
    }
  });

  if (!meshes.length) throw new Error('El archivo no contiene mallas.');
  ensureNormals(meshes);
  return {
    meshes,
    materials,
    images,
    info: { hasSkeleton, animations: root.animations?.length || 0 },
    warnings,
  };
}

async function waitForImages(raw, timeoutMs = 8000) {
  await Promise.all(
    raw.images.map(
      (im) =>
        new Promise((resolve) => {
          const el = im.image;
          const t = setTimeout(resolve, timeoutMs);
          const done = () => {
            clearTimeout(t);
            resolve();
          };
          if (el.complete === false) {
            el.addEventListener('load', done, { once: true });
            el.addEventListener('error', done, { once: true });
          } else if (typeof el.decode === 'function') el.decode().then(done, done);
          else done();
        }),
    ),
  );
  raw.images = raw.images.filter((im) => isDrawable(im.image));
}

// Crea un LoadingManager que sirve texturas y buffers desde los archivos adjuntos.
function createManager(THREE, extras) {
  const urls = new Map();
  for (const e of extras) urls.set(baseName(e.name).toLowerCase(), URL.createObjectURL(e.blob));
  const manager = new THREE.LoadingManager();
  manager.setURLModifier((url) => {
    if (url.startsWith('blob:') || url.startsWith('data:')) return url;
    let key = url.split('?')[0];
    try {
      key = decodeURIComponent(key);
    } catch {
      /* se usa tal cual */
    }
    return urls.get(baseName(key).toLowerCase()) || TRANSPARENT_PX;
  });
  return { manager, revoke: () => urls.forEach((u) => URL.revokeObjectURL(u)) };
}

export async function parseWithThree({ format, file, extras = [], budgetTris, onProgress }) {
  const THREE = await loadThree();
  const { manager, revoke } = createManager(THREE, extras);
  onProgress?.(0.1);
  let root;
  let cleanup = () => {};
  try {
    if (format === 'fbx') {
      const { FBXLoader } = await import('three/addons/loaders/FBXLoader.js');
      const buf = await file.arrayBuffer();
      onProgress?.(0.3);
      root = new FBXLoader(manager).parse(buf, '');
    } else if (format === 'dae') {
      const { ColladaLoader } = await import('three/addons/loaders/ColladaLoader.js');
      const text = await file.text();
      onProgress?.(0.3);
      root = new ColladaLoader(manager).parse(text, '').scene;
    } else if (format === 'glb' || format === 'gltf') {
      const [{ GLTFLoader }, { DRACOLoader }, { MeshoptDecoder }] = await Promise.all([
        import('three/addons/loaders/GLTFLoader.js'),
        import('three/addons/loaders/DRACOLoader.js'),
        import('three/addons/libs/meshopt_decoder.module.js'),
      ]);
      const draco = new DRACOLoader(manager);
      draco.setDecoderPath(DRACO_DECODER_PATH);
      cleanup = () => draco.dispose();
      const loader = new GLTFLoader(manager);
      loader.setDRACOLoader(draco);
      loader.setMeshoptDecoder(MeshoptDecoder);
      const data = format === 'glb' ? await file.arrayBuffer() : await file.text();
      onProgress?.(0.3);
      const gltf = await new Promise((resolve, reject) => loader.parse(data, '', resolve, reject));
      root = gltf.scene;
      root.animations = gltf.animations || [];
    } else {
      throw new Error(`El formato «${format}» no se procesa con Three.js.`);
    }
    onProgress?.(0.6);
    const raw = objectToRaw(root);
    await waitForImages(raw);
    onProgress?.(0.9);
    // Las texturas de un material pueden haber quedado sin imagen válida: se quita la referencia.
    raw.materials.forEach((m) => {
      if (m.map >= raw.images.length) m.map = -1;
    });
    const result = finalizeModel(raw, { budgetTris, sizeBytes: file.size });
    onProgress?.(1);
    return result;
  } catch (err) {
    const hint = /draco|fetch|network|decoder/i.test(err?.message || '')
      ? ' El decodificador Draco se descarga de una CDN; si tu entorno bloquea la red, exporta el modelo sin compresión Draco.'
      : '';
    throw new Error(`No se pudo leer el archivo ${format.toUpperCase()}: ${err?.message || err}.${hint}`);
  } finally {
    cleanup();
    // Las texturas ya se copiaron a <img> en memoria; las URL temporales pueden liberarse.
    setTimeout(revoke, 10000);
  }
}
