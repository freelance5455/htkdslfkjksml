// Construye un grupo de Three.js a partir de la malla neutra de vista previa.
// Lo comparten el visor del Hub y el generador de miniaturas. Recibe THREE por parámetro
// para no importar Three.js de forma estática.

async function toCanvas(image, maxSize) {
  let src = image.image;
  if (!src && image.data) {
    const blob = new Blob([image.data], { type: image.mime || 'image/png' });
    src = await createImageBitmap(blob);
  }
  const w = src.naturalWidth || src.width;
  const h = src.naturalHeight || src.height;
  const k = Math.min(1, maxSize / Math.max(w, h));
  const cw = Math.max(1, Math.round(w * k)), ch = Math.max(1, Math.round(h * k));
  const canvas = document.createElement('canvas');
  canvas.width = cw;
  canvas.height = ch;
  canvas.getContext('2d').drawImage(src, 0, 0, cw, ch);
  src.close?.();
  return canvas;
}

// skin (opcional): { weights: [{skinIndex, skinWeight}] por malla, skeleton } crea SkinnedMesh en lugar de Mesh. Las mallas
// deben venir ya en el marco del rig; el hueso raíz lo añade quien llama al grupo.
export async function buildPreviewGroup(THREE, preview, { texMax = 512, wireframe = false, skin = null } = {}) {
  const textures = [];
  const disposables = [];

  // Texturas (si una imagen está dañada, el material queda sin textura en vez de fallar).
  const texFor = [];
  for (const im of preview.images || []) {
    try {
      const canvas = await toCanvas(im, texMax);
      const tex = new THREE.CanvasTexture(canvas);
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = 4;
      textures.push(tex);
      texFor.push(tex);
    } catch (err) {
      console.warn('[preview] textura omitida', im.name, err);
      texFor.push(null);
    }
  }

  const matCache = new Map();
  const materialFor = (idx, vertexColors, hasUv) => {
    const key = `${idx}:${vertexColors ? 1 : 0}:${hasUv ? 1 : 0}`;
    let m = matCache.get(key);
    if (m) return m;
    const d = preview.materials[idx] || { color: [0.8, 0.8, 0.84], opacity: 1, map: -1, doubleSided: true, colorLinear: false };
    const color = new THREE.Color();
    color.setRGB(d.color[0], d.color[1], d.color[2], d.colorLinear ? THREE.LinearSRGBColorSpace : THREE.SRGBColorSpace);
    m = new THREE.MeshStandardMaterial({
      color,
      roughness: 0.82,
      metalness: 0,
      side: d.doubleSided ? THREE.DoubleSide : THREE.FrontSide,
      transparent: d.opacity < 1,
      opacity: d.opacity,
      map: hasUv && d.map >= 0 ? texFor[d.map] || null : null, // sin UV, la textura se vería como un solo píxel
      vertexColors: !!vertexColors,
      wireframe,
    });
    matCache.set(key, m);
    disposables.push(m);
    return m;
  };

  const group = new THREE.Group();
  for (const [mi, md] of preview.meshes.entries()) {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(md.positions, 3));
    if (md.normals) geo.setAttribute('normal', new THREE.BufferAttribute(md.normals, 3));
    if (md.uvs) geo.setAttribute('uv', new THREE.BufferAttribute(md.uvs, 2));
    if (md.colors) geo.setAttribute('color', new THREE.BufferAttribute(md.colors, 3));
    if (md.indices) geo.setIndex(new THREE.BufferAttribute(md.indices, 1));
    disposables.push(geo);
    if (skin) {
      const w = skin.weights[mi];
      // Uint16 es el tipo estándar de skinIndex en Three.js; los pesos suman 1 por vértice.
      geo.setAttribute('skinIndex', new THREE.Uint16BufferAttribute(Uint16Array.from(w.skinIndex), 4));
      geo.setAttribute('skinWeight', new THREE.Float32BufferAttribute(w.skinWeight, 4));
      geo.computeBoundingSphere();
      const mesh = new THREE.SkinnedMesh(geo, materialFor(md.material, !!md.colors, !!md.uvs));
      mesh.frustumCulled = false; // la pose cambia cada fotograma; la esfera del reposo no sirve para descartar
      mesh.bind(skin.skeleton, new THREE.Matrix4());
      group.add(mesh);
    } else {
      geo.computeBoundingSphere();
      group.add(new THREE.Mesh(geo, materialFor(md.material, !!md.colors, !!md.uvs)));
    }
  }

  const box = new THREE.Box3().setFromObject(group);
  const center = box.getCenter(new THREE.Vector3());
  const size = box.getSize(new THREE.Vector3());
  const radius = Math.max(size.length() / 2, 1e-6);

  return {
    group,
    box,
    center,
    size,
    radius,
    setWireframe(on) {
      for (const m of matCache.values()) m.wireframe = on;
    },
    dispose() {
      for (const d of disposables) d.dispose();
      for (const t of textures) t.dispose();
    },
  };
}
