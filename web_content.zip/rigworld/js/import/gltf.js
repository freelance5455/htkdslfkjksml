// Lector glTF 2.0 / GLB sin dependencias. Hornea las transformaciones de los nodos en la
// geometría y devuelve mallas neutras. Lo que necesita descompresión (Draco, meshopt)
// lanza NeedsThreeError para que el importador use GLTFLoader de Three.js en el hilo principal.
import { readAllBytes, readText } from './lines.js';
import { baseName } from './formats.js';
import { bakeWorld, flipWinding } from './mesh.js';

export class NeedsThreeError extends Error {
  constructor(reason) {
    super(`Este glTF necesita ${reason}.`);
    this.code = 'NEEDS_THREE';
    this.reason = reason;
  }
}

const COMP = {
  5120: { size: 1, get: 'getInt8', norm: 127 },
  5121: { size: 1, get: 'getUint8', norm: 255 },
  5122: { size: 2, get: 'getInt16', norm: 32767 },
  5123: { size: 2, get: 'getUint16', norm: 65535 },
  5125: { size: 4, get: 'getUint32', norm: 4294967295 },
  5126: { size: 4, get: 'getFloat32', norm: 1 },
};
const TYPE_N = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT2: 4, MAT3: 9, MAT4: 16 };

function dataUri(uri) {
  const m = /^data:([^;,]*)(;base64)?,(.*)$/s.exec(uri);
  if (!m) throw new Error('URI de datos glTF no válida.');
  const mime = m[1] || 'application/octet-stream';
  if (m[2]) {
    const bin = atob(m[3]);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return { mime, bytes };
  }
  return { mime, bytes: new TextEncoder().encode(decodeURIComponent(m[3])) };
}

// ── Matrices 4×4 en columnas (convención glTF) ───────────────────────────────────────────────
function composeNode(node) {
  if (node.matrix) return Float64Array.from(node.matrix);
  const [tx, ty, tz] = node.translation || [0, 0, 0];
  const [x, y, z, w] = node.rotation || [0, 0, 0, 1];
  const [sx, sy, sz] = node.scale || [1, 1, 1];
  const x2 = x + x, y2 = y + y, z2 = z + z;
  const xx = x * x2, xy = x * y2, xz = x * z2, yy = y * y2, yz = y * z2, zz = z * z2, wx = w * x2, wy = w * y2, wz = w * z2;
  return Float64Array.of(
    (1 - (yy + zz)) * sx, (xy + wz) * sx, (xz - wy) * sx, 0,
    (xy - wz) * sy, (1 - (xx + zz)) * sy, (yz + wx) * sy, 0,
    (xz + wy) * sz, (yz - wx) * sz, (1 - (xx + yy)) * sz, 0,
    tx, ty, tz, 1,
  );
}

function mul(a, b) {
  const o = new Float64Array(16);
  for (let c = 0; c < 4; c++) {
    for (let r = 0; r < 4; r++) {
      o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
    }
  }
  return o;
}

const IDENTITY = Float64Array.of(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);

export async function parseGltf(source, { isGlb, extras = new Map(), onProgress } = {}) {
  const warnings = [];
  let json;
  let binChunk = null;

  if (isGlb) {
    const buf = await readAllBytes(source);
    const dv = new DataView(buf);
    if (buf.byteLength < 20 || dv.getUint32(0, true) !== 0x46546c67) throw new Error('El archivo no es un GLB válido.');
    if (dv.getUint32(4, true) !== 2) throw new Error('Solo se admite GLB versión 2.');
    let off = 12;
    while (off + 8 <= buf.byteLength) {
      const len = dv.getUint32(off, true);
      const type = dv.getUint32(off + 4, true);
      const start = off + 8;
      if (start + len > buf.byteLength) throw new Error('El GLB está truncado o dañado.');
      if (type === 0x4e4f534a) json = JSON.parse(new TextDecoder().decode(new Uint8Array(buf, start, len)));
      else if (type === 0x004e4942 && !binChunk) binChunk = new Uint8Array(buf, start, len);
      off = (start + len + 3) & ~3; // los bloques GLB se alinean a 4 bytes
    }
    if (!json) throw new Error('El GLB no contiene el bloque JSON.');
  } else {
    try {
      json = JSON.parse((await readText(source)).replace(/^﻿/, ''));
    } catch {
      throw new Error('El archivo .gltf no contiene JSON válido.');
    }
  }
  onProgress?.(0.15);

  if (!json.asset || !String(json.asset.version || '').startsWith('2')) throw new Error('Solo se admite glTF 2.0.');
  const required = json.extensionsRequired || [];
  if (required.includes('KHR_draco_mesh_compression')) throw new NeedsThreeError('descompresión Draco');
  if (required.includes('EXT_meshopt_compression') || required.includes('KHR_meshopt_compression')) throw new NeedsThreeError('descompresión meshopt');

  // Buffers
  const buffers = [];
  for (let i = 0; i < (json.buffers || []).length; i++) {
    const b = json.buffers[i];
    if (b.uri === undefined) {
      if (!isGlb || i !== 0 || !binChunk) throw new Error('Falta el bloque binario del GLB.');
      buffers.push(binChunk);
    } else if (b.uri.startsWith('data:')) {
      buffers.push(dataUri(b.uri).bytes);
    } else {
      const name = decodeURIComponent(baseName(b.uri)).toLowerCase();
      const ex = extras.get(name);
      if (!ex) throw new Error(`Falta el archivo «${decodeURIComponent(baseName(b.uri))}» que usa este glTF. Selecciónalo junto con el .gltf.`);
      buffers.push(new Uint8Array(await readAllBytes(ex.blob)));
    }
  }

  const readAccessor = (index, asIndex = false) => {
    const acc = json.accessors?.[index];
    if (!acc) throw new Error('El glTF referencia un accesor inexistente.');
    const n = TYPE_N[acc.type];
    const comp = COMP[acc.componentType];
    if (!n || !comp) throw new Error('Tipo de accesor glTF no compatible.');
    const count = acc.count;
    const out = asIndex ? new Uint32Array(count * n) : new Float32Array(count * n);
    const normalized = !asIndex && !!acc.normalized && acc.componentType !== 5126;
    const k = 1 / comp.norm;
    const conv = (v) => (asIndex ? v : normalized ? Math.max(-1, v * k) : v);
    if (acc.bufferView !== undefined) {
      const bv = json.bufferViews[acc.bufferView];
      if (bv.extensions?.EXT_meshopt_compression || bv.extensions?.KHR_meshopt_compression) throw new NeedsThreeError('descompresión meshopt');
      const buf = buffers[bv.buffer];
      if (!buf) throw new Error('El glTF referencia un buffer inexistente.');
      const base = buf.byteOffset + (bv.byteOffset || 0) + (acc.byteOffset || 0);
      const stride = bv.byteStride || n * comp.size;
      if (base + (count - 1) * stride + n * comp.size > buf.byteOffset + buf.byteLength) throw new Error('Los datos del glTF están truncados.');
      if (acc.componentType === 5126 && !asIndex && stride === n * 4 && base % 4 === 0) {
        out.set(new Float32Array(buf.buffer, base, count * n));
      } else {
        const dv = new DataView(buf.buffer);
        const get = comp.get;
        for (let i = 0; i < count; i++) {
          const row = base + i * stride;
          for (let j = 0; j < n; j++) {
            out[i * n + j] = conv(dv[get](row + j * comp.size, true));
          }
        }
      }
    }
    if (acc.sparse) {
      const sp = acc.sparse;
      const ibv = json.bufferViews[sp.indices.bufferView];
      const vbv = json.bufferViews[sp.values.bufferView];
      const ibuf = buffers[ibv.buffer], vbuf = buffers[vbv.buffer];
      const ic = COMP[sp.indices.componentType];
      const idv = new DataView(ibuf.buffer), vdv = new DataView(vbuf.buffer);
      const ibase = ibuf.byteOffset + (ibv.byteOffset || 0) + (sp.indices.byteOffset || 0);
      const vbase = vbuf.byteOffset + (vbv.byteOffset || 0) + (sp.values.byteOffset || 0);
      for (let s = 0; s < sp.count; s++) {
        const target = idv[ic.get](ibase + s * ic.size, true);
        for (let j = 0; j < n; j++) {
          out[target * n + j] = conv(vdv[comp.get](vbase + (s * n + j) * comp.size, true));
        }
      }
    }
    return { array: out, n, count };
  };

  // Imágenes (solo las usadas como color base) y materiales
  const images = [];
  const imageBySource = new Map();
  const imageForSource = async (srcIdx) => {
    if (imageBySource.has(srcIdx)) return imageBySource.get(srcIdx);
    const im = json.images?.[srcIdx];
    let result = -1;
    if (im) {
      let bytes = null;
      let mime = im.mimeType || '';
      let name = im.name || `imagen_${srcIdx}`;
      if (im.uri !== undefined) {
        if (im.uri.startsWith('data:')) {
          const d = dataUri(im.uri);
          bytes = d.bytes;
          mime = d.mime;
        } else {
          const fname = decodeURIComponent(baseName(im.uri));
          name = fname;
          const ex = extras.get(fname.toLowerCase());
          if (ex) {
            bytes = new Uint8Array(await readAllBytes(ex.blob));
            mime = ex.blob.type || mime;
          } else warnings.push(`Textura no encontrada: ${fname}`);
        }
      } else if (im.bufferView !== undefined) {
        const bv = json.bufferViews[im.bufferView];
        const buf = buffers[bv.buffer];
        const o = buf.byteOffset + (bv.byteOffset || 0);
        bytes = new Uint8Array(buf.buffer, o, bv.byteLength);
      }
      if (bytes) {
        if (/ktx2/i.test(mime) || /\.ktx2$/i.test(name)) warnings.push(`Textura KTX2 omitida en la vista previa: ${name}`);
        else {
          if (!mime) mime = /\.png$/i.test(name) ? 'image/png' : /\.webp$/i.test(name) ? 'image/webp' : 'image/jpeg';
          images.push({ name, mime, data: bytes.slice().buffer });
          result = images.length - 1;
        }
      }
    }
    imageBySource.set(srcIdx, result);
    return result;
  };

  const materials = [];
  for (const m of json.materials || []) {
    const pbr = m.pbrMetallicRoughness || {};
    const f = pbr.baseColorFactor || [1, 1, 1, 1];
    let map = -1;
    const tex = pbr.baseColorTexture ? json.textures?.[pbr.baseColorTexture.index] : null;
    if (tex) {
      const src = tex.source ?? tex.extensions?.EXT_texture_webp?.source;
      if (src !== undefined) map = await imageForSource(src);
      else if (tex.extensions?.KHR_texture_basisu) warnings.push('Textura KTX2 (Basis) omitida en la vista previa.');
    }
    materials.push({
      name: m.name || `material_${materials.length}`,
      color: [f[0], f[1], f[2]],
      opacity: m.alphaMode === 'BLEND' ? f[3] : 1,
      map,
      doubleSided: !!m.doubleSided,
      colorLinear: true,
    });
  }
  const defaultMat = materials.length;
  let usedDefault = false;
  onProgress?.(0.35);

  // Recorrido de nodos con matrices de mundo
  const nodes = json.nodes || [];
  const sceneIdx = json.scene ?? 0;
  let roots = json.scenes?.[sceneIdx]?.nodes;
  if (!roots) {
    const child = new Set();
    nodes.forEach((n) => (n.children || []).forEach((c) => child.add(c)));
    roots = nodes.map((_, i) => i).filter((i) => !child.has(i));
  }
  const instances = []; // {mesh, world}
  const stack = roots.map((r) => ({ node: r, parent: IDENTITY }));
  let guard = 0;
  while (stack.length) {
    if (++guard > 5e6) throw new Error('Jerarquía de nodos glTF demasiado grande o cíclica.');
    const { node: ni, parent } = stack.pop();
    const node = nodes[ni];
    if (!node) continue;
    const world = mul(parent, composeNode(node));
    if (node.mesh !== undefined) instances.push({ mesh: node.mesh, world, skinned: node.skin !== undefined });
    if (node.extensions?.EXT_mesh_gpu_instancing) warnings.push('Se ignoran las instancias GPU (EXT_mesh_gpu_instancing).');
    for (const c of node.children || []) stack.push({ node: c, parent: world });
  }
  if (!nodes.length && json.meshes?.length) json.meshes.forEach((_, i) => instances.push({ mesh: i, world: IDENTITY, skinned: false }));

  const meshes = [];
  let warnedMode = false;
  let skinnedMeshes = 0;
  const cache = new Map(); // datos de primitiva ya leídos
  let done = 0;

  for (const inst of instances) {
    const m = json.meshes?.[inst.mesh];
    if (!m) continue;
    if (inst.skinned) skinnedMeshes++;
    for (let pi = 0; pi < m.primitives.length; pi++) {
      const prim = m.primitives[pi];
      if (prim.extensions?.KHR_draco_mesh_compression) throw new NeedsThreeError('descompresión Draco');
      const mode = prim.mode ?? 4;
      if (![4, 5, 6].includes(mode)) {
        if (!warnedMode) warnings.push('Se omitieron primitivas de puntos o líneas.');
        warnedMode = true;
        continue;
      }
      if (prim.attributes?.POSITION === undefined) continue;
      const ck = `${inst.mesh}:${pi}`;
      let data = cache.get(ck);
      if (!data) {
        data = { pos: readAccessor(prim.attributes.POSITION).array };
        if (prim.attributes.NORMAL !== undefined) data.nor = readAccessor(prim.attributes.NORMAL).array;
        if (prim.attributes.TEXCOORD_0 !== undefined) data.uv = readAccessor(prim.attributes.TEXCOORD_0).array;
        if (prim.attributes.COLOR_0 !== undefined) {
          const c = readAccessor(prim.attributes.COLOR_0);
          if (c.n === 3) data.col = c.array;
          else {
            data.col = new Float32Array(c.count * 3);
            for (let i = 0; i < c.count; i++) {
              data.col[i * 3] = c.array[i * 4];
              data.col[i * 3 + 1] = c.array[i * 4 + 1];
              data.col[i * 3 + 2] = c.array[i * 4 + 2];
            }
          }
        }
        if (prim.attributes.JOINTS_0 !== undefined) data.skinned = true;
        let idx = prim.indices !== undefined ? readAccessor(prim.indices, true).array : null;
        if (mode !== 4) {
          const src = idx || Uint32Array.from({ length: data.pos.length / 3 }, (_, i) => i);
          const out = [];
          if (mode === 5) {
            for (let i = 0; i + 2 < src.length; i++) {
              if (i % 2 === 0) out.push(src[i], src[i + 1], src[i + 2]);
              else out.push(src[i + 1], src[i], src[i + 2]);
            }
          } else {
            for (let i = 1; i + 1 < src.length; i++) out.push(src[0], src[i], src[i + 1]);
          }
          idx = Uint32Array.from(out);
        }
        data.idx = idx;
        cache.set(ck, data);
      }

      // Hornear la matriz de mundo (posiciones, normales y orden de caras si hay espejo)
      const baked = bakeWorld(inst.world, data.pos, data.nor || null);
      const positions = baked.positions;
      const normals = baked.normals;
      let indices = data.idx ? data.idx.slice() : null;
      if (baked.flipped) indices = flipWinding(indices, positions.length / 3);
      let uvs = null;
      if (data.uv) {
        uvs = new Float32Array(data.uv.length);
        for (let i = 0; i < uvs.length; i += 2) {
          uvs[i] = data.uv[i];
          uvs[i + 1] = 1 - data.uv[i + 1]; // glTF: v hacia abajo → origen abajo-izquierda
        }
      }
      let mat = prim.material;
      if (mat === undefined || !materials[mat]) {
        mat = defaultMat;
        usedDefault = true;
      }
      meshes.push({ name: m.name || `malla_${inst.mesh}`, positions, normals, uvs, colors: data.col ? data.col.slice() : null, indices, material: mat, skinned: !!data.skinned });
    }
    if (++done % 50 === 0) onProgress?.(0.35 + 0.6 * (done / instances.length));
  }

  if (usedDefault) materials.push({ name: 'default', color: [0.8, 0.8, 0.82], opacity: 1, map: -1, doubleSided: true, colorLinear: false });
  if (!meshes.length) throw new Error('El glTF no contiene mallas de triángulos.');
  onProgress?.(1);

  const skinned = json.skins?.length > 0 || skinnedMeshes > 0 || meshes.some((m) => m.skinned);
  return {
    meshes,
    materials,
    images,
    info: {
      skins: json.skins?.length || 0,
      animations: json.animations?.length || 0,
      hasSkeleton: skinned,
      generator: json.asset?.generator || '',
      extensionsUsed: json.extensionsUsed || [],
    },
    warnings,
  };
}
