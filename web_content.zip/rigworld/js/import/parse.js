// Despachador de parseo. Lo usan el Worker (import.worker.js) y el hilo principal (respaldo
// y formatos que necesitan DOM). Convierte cualquier formato en el mismo resultado:
//   { stats, preview: {meshes, materials, images}, warnings }
import { parseStl } from './stl.js';
import { parsePly } from './ply.js';
import { parseObj } from './obj.js';
import { parseGltf, NeedsThreeError } from './gltf.js';
import { boundsOf, simplifyForPreview, totalTris, totalVerts } from './mesh.js';
import { readAllBytes } from './lines.js';
import { baseName } from './formats.js';

export { NeedsThreeError };

// Formatos que este módulo lee por sí mismo, sin Three.js.
export const NATIVE_FORMATS = new Set(['stl', 'ply', 'obj', 'glb', 'gltf']);

export function buildExtrasMap(extras = []) {
  const map = new Map();
  for (const e of extras) map.set(baseName(e.name).toLowerCase(), { role: e.role, blob: e.blob, name: baseName(e.name) });
  return map;
}

// Asocia a cada material de un OBJ su imagen (si el archivo de textura fue adjuntado).
async function resolveTextures(raw, extrasMap) {
  for (const m of raw.materials) {
    if (!m.mapName) continue;
    const ex = extrasMap.get(m.mapName.toLowerCase());
    if (!ex || ex.role !== 'texture') {
      raw.warnings.push(`Textura no encontrada: ${m.mapName}`);
      continue;
    }
    let idx = raw.images.findIndex((im) => im.name.toLowerCase() === ex.name.toLowerCase());
    if (idx < 0) {
      raw.images.push({ name: ex.name, mime: ex.blob.type || 'image/png', data: await readAllBytes(ex.blob) });
      idx = raw.images.length - 1;
    }
    m.map = idx;
  }
}

// raw: { meshes, materials, images, info, warnings } con mallas completas.
export function finalizeModel(raw, { budgetTris, sizeBytes = 0 }) {
  const meshes = raw.meshes.filter((m) => m.positions.length >= 9);
  if (!meshes.length) throw new Error('El modelo no contiene geometría utilizable.');
  const bbox = boundsOf(meshes);
  const triangles = totalTris(meshes);
  const stats = {
    triangles,
    vertices: 'vertices' in raw.info ? raw.info.vertices : totalVerts(meshes),
    meshes: meshes.length,
    materials: raw.materials.length,
    textures: raw.images.length,
    bbox,
    size: [bbox.max[0] - bbox.min[0], bbox.max[1] - bbox.min[1], bbox.max[2] - bbox.min[2]],
    hasSkeleton: !!raw.info.hasSkeleton,
    animations: raw.info.animations || 0,
    sizeBytes,
  };
  const warnings = [...raw.warnings];

  const simp = simplifyForPreview(meshes, budgetTris, raw.materials);
  stats.simplified = simp.simplified;
  stats.previewTriangles = totalTris(simp.meshes);
  if (simp.simplified) {
    warnings.push(`Vista previa simplificada de ${Math.round(simp.originalTriangles / 1000)} k a ${Math.round(stats.previewTriangles / 1000)} k triángulos. El archivo original se guarda completo.`);
  }
  // Materiales e imágenes se conservan: la vista simplificada mantiene la textura.
  const materials = raw.materials;
  const images = raw.images;
  return { stats, preview: { meshes: simp.meshes, materials, images }, warnings };
}

// Parseo completo en el contexto actual (Worker o hilo principal).
export async function parseModel({ format, file, extras = [], budgetTris, onProgress }) {
  const extrasMap = buildExtrasMap(extras);
  let raw;
  switch (format) {
    case 'stl':
      raw = await parseStl(file, { onProgress });
      break;
    case 'ply':
      raw = await parsePly(file, { onProgress });
      break;
    case 'obj':
      raw = await parseObj(file, { extras: extrasMap, onProgress });
      await resolveTextures(raw, extrasMap);
      break;
    case 'glb':
    case 'gltf':
      raw = await parseGltf(file, { isGlb: format === 'glb', extras: extrasMap, onProgress });
      break;
    default:
      throw new Error(`El formato «${format}» no se procesa en este contexto.`);
  }
  return finalizeModel(raw, { budgetTris, sizeBytes: file.size ?? file.byteLength ?? 0 });
}

// ArrayBuffers de un resultado, sin duplicados, para transferirlos entre hilos sin copiar.
export function collectTransfers(result) {
  const set = new Set();
  for (const m of result.preview.meshes) {
    for (const k of ['positions', 'normals', 'uvs', 'colors', 'indices']) if (m[k]) set.add(m[k].buffer);
  }
  for (const im of result.preview.images) if (im.data instanceof ArrayBuffer) set.add(im.data);
  return [...set];
}
