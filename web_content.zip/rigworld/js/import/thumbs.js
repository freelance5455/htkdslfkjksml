// Miniaturas de la biblioteca. Con Three.js se renderiza la malla con luces; si no hay WebGL o
// Three.js no carga, se dibujan los triángulos rellenos con Canvas 2D (siempre disponible).
import { LIMITS } from '../config.js';
import { loadThree } from '../core/threeLoader.js';
import { buildPreviewGroup } from './previewScene.js';
import { boundsOf, decimateCluster, totalTris } from './mesh.js';

const MAX_2D_TRIS = 12000;
const LIGHT = (() => {
  const l = [0.4, 0.7, 0.6];
  const n = Math.hypot(...l);
  return l.map((x) => x / n);
})();

const toSrgb = (c) => Math.pow(Math.min(1, Math.max(0, c)), 1 / 2.2);

// Proyección ortográfica de los triángulos con sombreado plano. Devuelve
// [{ p: [x0,y0,x1,y1,x2,y2], depth, shade, r, g, b }] ordenados de lejos a cerca, ya encajados
// en un cuadrado de `size` px. Función pura: se prueba sin canvas.
export function projectTriangles(preview, size, { yaw = -0.62, pitch = 0.2, maxTris = MAX_2D_TRIS } = {}) {
  let meshes = preview.meshes;
  if (totalTris(meshes) > maxTris) meshes = [decimateCluster(meshes, maxTris)];
  const b = boundsOf(meshes);
  const cx = (b.min[0] + b.max[0]) / 2, cy = (b.min[1] + b.max[1]) / 2, cz = (b.min[2] + b.max[2]) / 2;
  const cosY = Math.cos(yaw), sinY = Math.sin(yaw), cosP = Math.cos(pitch), sinP = Math.sin(pitch);

  // 1) Rotar todos los vértices una vez.
  const rotated = meshes.map((m) => {
    const n = m.positions.length / 3;
    const out = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const x = m.positions[i * 3] - cx, y = m.positions[i * 3 + 1] - cy, z = m.positions[i * 3 + 2] - cz;
      const rx = x * cosY + z * sinY, rz = -x * sinY + z * cosY;
      out[i * 3] = rx;
      out[i * 3 + 1] = y * cosP - rz * sinP;
      out[i * 3 + 2] = y * sinP + rz * cosP;
    }
    return out;
  });
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const r of rotated) {
    for (let i = 0; i < r.length; i += 3) {
      if (r[i] < minX) minX = r[i];
      if (r[i] > maxX) maxX = r[i];
      if (r[i + 1] < minY) minY = r[i + 1];
      if (r[i + 1] > maxY) maxY = r[i + 1];
    }
  }
  const span = Math.max(maxX - minX, maxY - minY) || 1;
  const scale = (size * 0.86) / span;
  const ox = size / 2 - ((minX + maxX) / 2) * scale;
  const oy = size / 2 + ((minY + maxY) / 2) * scale;

  // 2) Un elemento por triángulo.
  const tris = [];
  meshes.forEach((m, mi) => {
    const r = rotated[mi];
    const mat = preview.materials[m.material] || { color: [0.8, 0.8, 0.84], colorLinear: false };
    const conv = mat.colorLinear ? toSrgb : (c) => c;
    const nt = m.indices ? m.indices.length / 3 : m.positions.length / 9;
    for (let t = 0; t < nt; t++) {
      const ia = (m.indices ? m.indices[t * 3] : t * 3) * 3;
      const ib = (m.indices ? m.indices[t * 3 + 1] : t * 3 + 1) * 3;
      const ic = (m.indices ? m.indices[t * 3 + 2] : t * 3 + 2) * 3;
      const ux = r[ib] - r[ia], uy = r[ib + 1] - r[ia + 1], uz = r[ib + 2] - r[ia + 2];
      const vx = r[ic] - r[ia], vy = r[ic + 1] - r[ia + 1], vz = r[ic + 2] - r[ia + 2];
      let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      const l = Math.hypot(nx, ny, nz);
      if (l < 1e-18) continue; // triángulo degenerado
      if (nz < 0) { nx = -nx; ny = -ny; nz = -nz; } // cara trasera: se sombrea como frontal
      const shade = 0.3 + 0.7 * Math.max(0, (nx * LIGHT[0] + ny * LIGHT[1] + nz * LIGHT[2]) / l);
      let cr = mat.color[0], cg = mat.color[1], cb = mat.color[2];
      if (m.colors) {
        cr = (m.colors[ia] + m.colors[ib] + m.colors[ic]) / 3;
        cg = (m.colors[ia + 1] + m.colors[ib + 1] + m.colors[ic + 1]) / 3;
        cb = (m.colors[ia + 2] + m.colors[ib + 2] + m.colors[ic + 2]) / 3;
      }
      tris.push({
        p: [ox + r[ia] * scale, oy - r[ia + 1] * scale, ox + r[ib] * scale, oy - r[ib + 1] * scale, ox + r[ic] * scale, oy - r[ic + 1] * scale],
        depth: (r[ia + 2] + r[ib + 2] + r[ic + 2]) / 3,
        shade,
        r: conv(cr),
        g: conv(cg),
        b: conv(cb),
      });
    }
  });
  tris.sort((a, c) => a.depth - c.depth); // lejos → cerca (la cámara mira hacia -z)
  return tris;
}

function makeCanvas(size) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  return c;
}

export function thumb2d(preview, size = LIMITS.thumbSize) {
  const canvas = makeCanvas(size);
  const ctx = canvas.getContext('2d');
  ctx.lineJoin = 'round';
  ctx.lineWidth = 0.7; // el contorno del mismo color tapa las rendijas entre triángulos
  for (const t of projectTriangles(preview, size)) {
    const byte = (v) => Math.round(Math.min(1, Math.max(0, v * t.shade)) * 255);
    const color = `rgb(${byte(t.r)},${byte(t.g)},${byte(t.b)})`;
    ctx.fillStyle = color;
    ctx.strokeStyle = color;
    ctx.beginPath();
    ctx.moveTo(t.p[0], t.p[1]);
    ctx.lineTo(t.p[2], t.p[3]);
    ctx.lineTo(t.p[4], t.p[5]);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
  return canvas;
}

// Renderizador compartido para todas las miniaturas (un único contexto WebGL).
let shared = null;
function getSharedRenderer(THREE, size) {
  if (shared) return shared;
  try {
    const canvas = makeCanvas(size);
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, preserveDrawingBuffer: true, powerPreference: 'low-power' });
    renderer.setPixelRatio(1);
    renderer.setSize(size, size, false);
    shared = { renderer, canvas };
  } catch {
    shared = { renderer: null, canvas: null };
  }
  return shared;
}

export function releaseThumbRenderer() {
  try {
    shared?.renderer?.dispose();
    shared?.renderer?.forceContextLoss?.();
  } catch {
    /* ya liberado */
  }
  shared = null;
}

async function thumbWebGL(THREE, preview, size) {
  const { renderer, canvas } = getSharedRenderer(THREE, size);
  if (!renderer) return null;
  const built = await buildPreviewGroup(THREE, preview, { texMax: 256 });
  try {
    const scene = new THREE.Scene();
    scene.add(built.group);
    scene.add(new THREE.HemisphereLight(0xffffff, 0x556070, 1.5));
    const key = new THREE.DirectionalLight(0xffffff, 2.2);
    key.position.set(-1.5, 2.2, 2.5);
    scene.add(key);
    built.group.position.sub(built.center);
    const cam = new THREE.PerspectiveCamera(30, 1, built.radius * 0.05, built.radius * 20);
    const dist = (built.radius / Math.sin((cam.fov * Math.PI) / 360)) * 1.05;
    cam.position.set(Math.sin(-0.62) * Math.cos(0.2) * dist, Math.sin(0.2) * dist, Math.cos(-0.62) * Math.cos(0.2) * dist);
    cam.lookAt(0, 0, 0);
    renderer.setClearColor(0x000000, 0);
    renderer.render(scene, cam);
    const out = makeCanvas(size);
    out.getContext('2d').drawImage(canvas, 0, 0);
    return out;
  } finally {
    built.dispose();
  }
}

export async function canvasToThumb(canvas) {
  const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/webp', 0.85));
  const type = blob?.type === 'image/webp' ? 'image/webp' : 'image/png';
  const final = blob?.type === type ? blob : await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
  if (!final) throw new Error('No se pudo codificar la miniatura.');
  return { type: final.type, data: await final.arrayBuffer() };
}

// Devuelve { type, data: ArrayBuffer }. Nunca lanza: en el peor caso, el dibujo 2D.
// `mode` indica cómo se dibujó: 'webgl' (con textura) o '2d' (sin textura).
export async function renderThumbnail(preview, { size = LIMITS.thumbSize, useWebGL = true } = {}) {
  let canvas = null;
  let mode = 'webgl';
  if (useWebGL) {
    try {
      const THREE = await loadThree();
      canvas = await thumbWebGL(THREE, preview, size);
    } catch (err) {
      console.warn('[thumbs] WebGL no disponible, se usa el dibujo 2D:', err?.message || err);
    }
  }
  if (!canvas) {
    canvas = thumb2d(preview, size);
    mode = '2d';
  }
  return { ...(await canvasToThumb(canvas)), mode };
}
