// Lectura de texto por bloques: procesa un Blob/ArrayBuffer línea a línea sin crear una
// cadena de 200 MB. Un OBJ enorme se recorre en ventanas de 4 MB.

const WINDOW = 4 * 1024 * 1024;

async function sliceBytes(source, start, end) {
  if (source instanceof ArrayBuffer) return new Uint8Array(source, start, end - start);
  if (ArrayBuffer.isView(source)) return new Uint8Array(source.buffer, source.byteOffset + start, end - start);
  return new Uint8Array(await source.slice(start, end).arrayBuffer());
}

const sizeOf = (s) => (s instanceof ArrayBuffer || ArrayBuffer.isView(s) ? s.byteLength : s.size);

// onLine(line) es síncrono. onProgress(0..1) se llama una vez por ventana.
// startByte permite saltarse una cabecera ya leída.
export async function scanLines(source, onLine, { onProgress, startByte = 0 } = {}) {
  const size = sizeOf(source);
  const decoder = new TextDecoder('utf-8');
  let carry = '';
  for (let off = startByte; off < size; off += WINDOW) {
    const bytes = await sliceBytes(source, off, Math.min(off + WINDOW, size));
    const text = carry + decoder.decode(bytes, { stream: off + WINDOW < size });
    let pos = 0;
    let nl;
    while ((nl = text.indexOf('\n', pos)) !== -1) {
      let end = nl;
      if (end > pos && text.charCodeAt(end - 1) === 13) end--; // \r\n
      if (onLine(text.slice(pos, end)) === false) return;
      pos = nl + 1;
    }
    carry = text.slice(pos);
    onProgress?.(Math.min(1, (off + WINDOW) / size));
  }
  if (carry.length) onLine(carry);
  onProgress?.(1);
}

export const byteSize = sizeOf;

// ArrayBuffer con los bytes [start, end) de un Blob/ArrayBuffer/vista, sin leer el resto.
export async function sliceBuffer(source, start, end) {
  const e = Math.min(end, sizeOf(source));
  if (source instanceof ArrayBuffer) return source.slice(start, e);
  if (ArrayBuffer.isView(source)) return source.buffer.slice(source.byteOffset + start, source.byteOffset + e);
  return source.slice(start, e).arrayBuffer();
}

export async function readAllBytes(source) {
  if (source instanceof ArrayBuffer) return source;
  if (ArrayBuffer.isView(source)) return source.buffer.slice(source.byteOffset, source.byteOffset + source.byteLength);
  return source.arrayBuffer();
}

export async function readText(source) {
  return new TextDecoder('utf-8').decode(await readAllBytes(source));
}
