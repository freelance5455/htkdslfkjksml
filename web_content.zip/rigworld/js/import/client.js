// Cliente del Worker de importación. Un único Worker, creado al primer uso.
// Si el navegador no puede crearlo (o no arranca a tiempo), se parsea en el hilo principal:
// más lento y la interfaz se congela durante el análisis, pero el resultado es el mismo.
import { LIMITS } from '../config.js';
import { parseModel, NeedsThreeError } from './parse.js';

let worker = null;
let readyPromise = null;
let broken = false;
let nextId = 1;
const jobs = new Map();

function ensureWorker() {
  if (broken || typeof Worker === 'undefined') return Promise.reject(new Error('Worker no disponible'));
  if (readyPromise) return readyPromise;
  readyPromise = new Promise((resolve, reject) => {
    let w;
    try {
      w = new Worker(new URL('../workers/import.worker.js', import.meta.url), { type: 'module' });
    } catch (err) {
      reject(err);
      return;
    }
    const timer = setTimeout(() => reject(new Error('El Worker no arrancó a tiempo')), LIMITS.workerReadyTimeoutMs);
    w.onmessage = (e) => {
      const m = e.data;
      if (m.type === 'ready') {
        clearTimeout(timer);
        worker = w;
        resolve(w);
        return;
      }
      const job = jobs.get(m.id);
      if (!job) return;
      if (m.type === 'progress') job.onProgress?.(m.value);
      else if (m.type === 'done') {
        jobs.delete(m.id);
        job.resolve(m.result);
      } else if (m.type === 'error') {
        jobs.delete(m.id);
        job.reject(m.code === 'NEEDS_THREE' ? new NeedsThreeError(m.reason || 'descompresión') : new Error(m.message));
      }
    };
    w.onerror = (e) => {
      clearTimeout(timer);
      const err = new Error(e.message || 'Error del Worker');
      reject(err);
      for (const [id, job] of jobs) {
        jobs.delete(id);
        job.reject(err);
      }
    };
  }).catch((err) => {
    console.warn('[import] Worker no disponible, se parsea en el hilo principal:', err);
    broken = true;
    readyPromise = null;
    try {
      worker?.terminate();
    } catch {
      /* ya terminado */
    }
    worker = null;
    throw err;
  });
  return readyPromise;
}

function resetWorker() {
  try {
    worker?.terminate();
  } catch {
    /* ya terminado */
  }
  worker = null;
  readyPromise = null;
}

// job: { format, file, extras, budgetTris }. signal: AbortSignal opcional.
export async function parseInBackground(job, { onProgress, signal } = {}) {
  if (signal?.aborted) throw new DOMException('Importación cancelada', 'AbortError');
  let w = null;
  try {
    w = await ensureWorker();
  } catch {
    w = null;
  }
  if (!w) return parseModel({ ...job, onProgress });

  const id = nextId++;
  return new Promise((resolve, reject) => {
    const abort = () => {
      jobs.delete(id);
      resetWorker(); // la única forma de detener un parseo en curso
      reject(new DOMException('Importación cancelada', 'AbortError'));
    };
    signal?.addEventListener('abort', abort, { once: true });
    jobs.set(id, {
      onProgress,
      resolve: (r) => {
        signal?.removeEventListener('abort', abort);
        resolve(r);
      },
      reject: (e) => {
        signal?.removeEventListener('abort', abort);
        reject(e);
      },
    });
    w.postMessage({ type: 'parse', id, format: job.format, file: job.file, extras: job.extras, budgetTris: job.budgetTris });
  });
}

export const workerState = () => ({ broken, active: !!worker });

// Crea el Worker durante el arranque para que la primera importación no espere. Nunca lanza.
export async function warmUpWorker() {
  try {
    await ensureWorker();
    return true;
  } catch {
    return false;
  }
}
