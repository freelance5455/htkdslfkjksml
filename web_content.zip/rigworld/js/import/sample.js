// Modelo de ejemplo: maniquí humanoide estático en T-pose (~1,84 m), generado por código y
// empaquetado como un GLB real. Pasa por el mismo pipeline que cualquier archivo del usuario.
// También exporta buildGlb(), usado por las pruebas para fabricar archivos con casos límite.
import { HUMANOID_19 } from '../core/skeletonTemplate.js';

export const SAMPLE_NAME = 'Maniquí de ejemplo';

class Geo {
  constructor() {
    this.p = [];
    this.n = [];
    this.i = [];
  }

  ellipsoid(cx, cy, cz, rx, ry, rz, seg = 20, rings = 12) {
    const base = this.p.length / 3;
    for (let j = 0; j <= rings; j++) {
      const th = (j / rings) * Math.PI;
      for (let i = 0; i <= seg; i++) {
        const ph = (i / seg) * Math.PI * 2;
        const sx = Math.sin(th) * Math.cos(ph), cy_ = Math.cos(th), sz = Math.sin(th) * Math.sin(ph);
        this.p.push(cx + rx * sx, cy + ry * cy_, cz + rz * sz);
        const nx = sx / rx, ny = cy_ / ry, nz = sz / rz;
        const l = Math.hypot(nx, ny, nz) || 1;
        this.n.push(nx / l, ny / l, nz / l);
      }
    }
    const row = seg + 1;
    for (let j = 0; j < rings; j++) {
      for (let i = 0; i < seg; i++) {
        const a = base + j * row + i, b = a + 1, c = a + row + 1, d = a + row;
        this.i.push(a, b, d, b, c, d);
      }
    }
    return this;
  }

  limb(a, b, r0, r1, seg = 14) {
    const dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2];
    const len = Math.hypot(dx, dy, dz);
    const d = [dx / len, dy / len, dz / len];
    const ref = Math.abs(d[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0];
    let u = [d[1] * ref[2] - d[2] * ref[1], d[2] * ref[0] - d[0] * ref[2], d[0] * ref[1] - d[1] * ref[0]];
    const ul = Math.hypot(...u);
    u = u.map((x) => x / ul);
    const v = [d[1] * u[2] - d[2] * u[1], d[2] * u[0] - d[0] * u[2], d[0] * u[1] - d[1] * u[0]];
    const base = this.p.length / 3;
    const slope = (r0 - r1) / len;
    for (const [c, r] of [[a, r0], [b, r1]]) {
      for (let i = 0; i <= seg; i++) {
        const ph = (i / seg) * Math.PI * 2;
        const rx = Math.cos(ph) * u[0] + Math.sin(ph) * v[0];
        const ry = Math.cos(ph) * u[1] + Math.sin(ph) * v[1];
        const rz = Math.cos(ph) * u[2] + Math.sin(ph) * v[2];
        this.p.push(c[0] + r * rx, c[1] + r * ry, c[2] + r * rz);
        const nx = rx + d[0] * slope, ny = ry + d[1] * slope, nz = rz + d[2] * slope;
        const l = Math.hypot(nx, ny, nz) || 1;
        this.n.push(nx / l, ny / l, nz / l);
      }
    }
    const row = seg + 1;
    for (let i = 0; i < seg; i++) {
      const a0 = base + i, a1 = a0 + 1, b0 = a0 + row, b1 = b0 + 1;
      this.i.push(a0, a1, b0, a1, b1, b0);
    }
    return this;
  }

  primitive(color) {
    return { positions: Float32Array.from(this.p), normals: Float32Array.from(this.n), indices: Uint32Array.from(this.i), color };
  }
}

const J = Object.fromEntries(HUMANOID_19.map((j) => [j.name, j.pos]));

export function buildMannequinPrimitives() {
  const g = new Geo();
  // Torso y cabeza
  g.ellipsoid(0, 1.3, 0, 0.17, 0.22, 0.1);
  g.ellipsoid(0, 1.0, 0, 0.16, 0.12, 0.1);
  g.limb([0, 1.0, 0], [0, 1.3, 0], 0.09, 0.1);
  g.limb(J.Neck, J.Head, 0.045, 0.04);
  g.ellipsoid(0, 1.72, 0.005, 0.095, 0.12, 0.105);
  for (const s of ['Left', 'Right']) {
    const sx = s === 'Left' ? 1 : -1;
    g.ellipsoid(J[`${s}UpperArm`][0], J[`${s}UpperArm`][1], 0, 0.055, 0.055, 0.055);
    g.limb(J[`${s}UpperArm`], J[`${s}LowerArm`], 0.048, 0.04);
    g.ellipsoid(J[`${s}LowerArm`][0], J[`${s}LowerArm`][1], 0, 0.042, 0.042, 0.042);
    g.limb(J[`${s}LowerArm`], J[`${s}Hand`], 0.04, 0.03);
    g.ellipsoid(sx * 0.84, 1.45, 0, 0.065, 0.026, 0.045);
    g.ellipsoid(J[`${s}UpperLeg`][0], J[`${s}UpperLeg`][1], 0, 0.08, 0.08, 0.08);
    g.limb(J[`${s}UpperLeg`], J[`${s}LowerLeg`], 0.076, 0.056);
    g.ellipsoid(J[`${s}LowerLeg`][0], J[`${s}LowerLeg`][1], J[`${s}LowerLeg`][2], 0.058, 0.058, 0.058);
    g.limb(J[`${s}LowerLeg`], [J[`${s}Foot`][0], 0.1, 0], 0.056, 0.042);
    g.ellipsoid(sx * 0.09, 0.045, 0.06, 0.05, 0.045, 0.11);
  }
  return [g.primitive([0.78, 0.7, 0.62])];
}

// primitives: [{positions, normals?, indices?, color?}] → ArrayBuffer GLB válido.
// nodes (opcional): lista de nodos glTF que referencian mesh 0; por defecto, un nodo.
export function buildGlb(primitives, { name = 'modelo', nodes, sceneNodes } = {}) {
  const chunks = [];
  let offset = 0;
  const bufferViews = [];
  const accessors = [];
  const push = (typed, target) => {
    const bytes = new Uint8Array(typed.buffer, typed.byteOffset, typed.byteLength);
    const padded = new Uint8Array((bytes.length + 3) & ~3);
    padded.set(bytes);
    bufferViews.push({ buffer: 0, byteOffset: offset, byteLength: bytes.length, target });
    chunks.push(padded);
    offset += padded.length;
    return bufferViews.length - 1;
  };

  const prims = [];
  const materials = [];
  const images = [];
  const textures = [];
  for (const p of primitives) {
    const attributes = {};
    const pv = push(p.positions, 34962);
    const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
    for (let i = 0; i < p.positions.length; i += 3) for (let k = 0; k < 3; k++) {
      min[k] = Math.min(min[k], p.positions[i + k]);
      max[k] = Math.max(max[k], p.positions[i + k]);
    }
    accessors.push({ bufferView: pv, componentType: 5126, count: p.positions.length / 3, type: 'VEC3', min, max });
    attributes.POSITION = accessors.length - 1;
    if (p.normals) {
      accessors.push({ bufferView: push(p.normals, 34962), componentType: 5126, count: p.normals.length / 3, type: 'VEC3' });
      attributes.NORMAL = accessors.length - 1;
    }
    if (p.uvs) {
      accessors.push({ bufferView: push(p.uvs, 34962), componentType: 5126, count: p.uvs.length / 2, type: 'VEC2' });
      attributes.TEXCOORD_0 = accessors.length - 1;
    }
    const prim = { attributes };
    if (p.indices) {
      const idx = p.indices instanceof Uint32Array ? p.indices : Uint32Array.from(p.indices);
      accessors.push({ bufferView: push(idx, 34963), componentType: 5125, count: idx.length, type: 'SCALAR' });
      prim.indices = accessors.length - 1;
    }
    if (p.mode !== undefined) prim.mode = p.mode;
    const pbr = { baseColorFactor: [...(p.color || [0.8, 0.8, 0.8]), 1], metallicFactor: 0, roughnessFactor: 0.85 };
    if (p.texture) {
      // Textura incrustada: { mime, bytes: Uint8Array }
      images.push({ bufferView: push(p.texture.bytes), mimeType: p.texture.mime });
      textures.push({ source: images.length - 1 });
      pbr.baseColorTexture = { index: textures.length - 1 };
    }
    materials.push({ name: `material_${materials.length}`, pbrMetallicRoughness: pbr, doubleSided: false });
    prim.material = materials.length - 1;
    prims.push(prim);
  }

  const json = {
    asset: { version: '2.0', generator: 'RigWorld 3D' },
    scene: 0,
    scenes: [{ nodes: sceneNodes || [0] }],
    nodes: nodes || [{ name, mesh: 0 }],
    meshes: [{ name, primitives: prims }],
    materials,
    accessors,
    bufferViews,
    buffers: [{ byteLength: offset }],
  };
  if (images.length) {
    json.images = images;
    json.textures = textures;
  }

  const jsonBytes = new TextEncoder().encode(JSON.stringify(json));
  const jsonPadded = new Uint8Array((jsonBytes.length + 3) & ~3).fill(0x20);
  jsonPadded.set(jsonBytes);
  const bin = new Uint8Array(offset);
  let o = 0;
  for (const c of chunks) {
    bin.set(c, o);
    o += c.length;
  }
  const total = 12 + 8 + jsonPadded.length + 8 + bin.length;
  const out = new ArrayBuffer(total);
  const dv = new DataView(out);
  dv.setUint32(0, 0x46546c67, true);
  dv.setUint32(4, 2, true);
  dv.setUint32(8, total, true);
  dv.setUint32(12, jsonPadded.length, true);
  dv.setUint32(16, 0x4e4f534a, true);
  new Uint8Array(out, 20, jsonPadded.length).set(jsonPadded);
  const b0 = 20 + jsonPadded.length;
  dv.setUint32(b0, bin.length, true);
  dv.setUint32(b0 + 4, 0x004e4942, true);
  new Uint8Array(out, b0 + 8, bin.length).set(bin);
  return out;
}

export function buildSampleGlb() {
  return buildGlb(buildMannequinPrimitives(), { name: 'Maniquí' });
}
