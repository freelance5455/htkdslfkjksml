// Lector OBJ + MTL. Recorre el archivo por bloques (nunca crea una cadena de 200 MB).
// Una malla por material. Triangula polígonos con abanico. Los modelos muy grandes
// ignoran uv y normales para ahorrar memoria (la vista previa se decima de todos modos).
import { scanLines, readText, byteSize } from './lines.js';
import { GrowF32, GrowU32 } from './mesh.js';
import { LIMITS } from '../config.js';
import { baseName } from './formats.js';

export function parseMtl(text) {
  const mats = new Map();
  let cur = null;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line[0] === '#') continue;
    const sp = line.search(/\s/);
    const key = (sp < 0 ? line : line.slice(0, sp)).toLowerCase();
    const rest = sp < 0 ? '' : line.slice(sp + 1).trim();
    if (key === 'newmtl') {
      cur = { name: rest, color: [0.8, 0.8, 0.8], opacity: 1, mapName: null };
      mats.set(rest, cur);
    } else if (!cur) continue;
    else if (key === 'kd') {
      const c = rest.split(/\s+/).map(parseFloat);
      if (c.length >= 3 && c.every(Number.isFinite)) cur.color = [c[0], c[1], c[2]];
    } else if (key === 'd') {
      const d = parseFloat(rest);
      if (Number.isFinite(d)) cur.opacity = d;
    } else if (key === 'tr') {
      const tr = parseFloat(rest);
      if (Number.isFinite(tr)) cur.opacity = 1 - tr;
    } else if (key === 'map_kd') {
      // Quita opciones como «-s 1 1 1» o «-bm 0.5» que preceden al nombre del archivo.
      const name = rest.replace(/^(?:-\w+(?:\s+-?\d*\.?\d+)*\s+)+/, '');
      if (name) cur.mapName = baseName(name);
    }
  }
  return mats;
}

class Group {
  constructor(matIdx, simple) {
    this.matIdx = matIdx;
    this.simple = simple;
    this.map = new Map();
    this.pos = new GrowF32(3 * 1024);
    this.uv = simple ? null : new GrowF32(2 * 1024);
    this.nor = simple ? null : new GrowF32(3 * 1024);
    this.col = null;
    this.idx = new GrowU32(3 * 1024);
    this.badNormals = false;
    this.anyUv = false;
  }
}

export async function parseObj(source, { extras = new Map(), onProgress } = {}) {
  const size = byteSize(source);
  const simple = size > LIMITS.hugeFileBytes;
  const P = new GrowF32(3 * 4096);
  const C = new GrowF32(3 * 4096);
  let hasColor = false;
  const T = new GrowF32(2 * 4096);
  const N = new GrowF32(3 * 4096);
  const mtlNames = [];
  const matOrder = []; // nombres de material en orden de primer uso
  const groups = new Map(); // índice de material → Group
  let curMat = -1;
  let curGroup = null;
  const warnings = [];
  const ids = [];

  const groupFor = (matName) => {
    let mi = matOrder.indexOf(matName);
    if (mi < 0) {
      mi = matOrder.length;
      matOrder.push(matName);
    }
    let g = groups.get(mi);
    if (!g) {
      g = new Group(mi, simple);
      groups.set(mi, g);
    }
    return g;
  };

  const absIndex = (token, count) => {
    if (token === '' || token === undefined) return -1;
    const n = parseInt(token, 10);
    if (!Number.isFinite(n) || n === 0) return -1;
    return n > 0 ? n - 1 : count + n;
  };

  const vertexId = (g, tok, vc, tc, nc) => {
    const parts = tok.split('/');
    const vi = absIndex(parts[0], vc);
    if (vi < 0 || vi >= vc) return -1;
    let ti = -1, ni = -1;
    if (!simple) {
      ti = parts.length > 1 ? absIndex(parts[1], tc) : -1;
      ni = parts.length > 2 ? absIndex(parts[2], nc) : -1;
    }
    const key = simple ? vi : `${vi}/${ti}/${ni}`;
    let id = g.map.get(key);
    if (id !== undefined) return id;
    id = g.pos.n / 3;
    g.map.set(key, id);
    g.pos.push3(P.a[vi * 3], P.a[vi * 3 + 1], P.a[vi * 3 + 2]);
    if (hasColor) {
      if (!g.col) g.col = new GrowF32(3 * 1024);
      g.col.push3(C.a[vi * 3], C.a[vi * 3 + 1], C.a[vi * 3 + 2]);
    }
    if (!simple) {
      if (ti >= 0 && ti < tc) {
        g.uv.push2(T.a[ti * 2], T.a[ti * 2 + 1]);
        g.anyUv = true;
      } else g.uv.push2(0, 0);
      if (ni >= 0 && ni < nc) g.nor.push3(N.a[ni * 3], N.a[ni * 3 + 1], N.a[ni * 3 + 2]);
      else {
        g.nor.push3(0, 0, 0);
        g.badNormals = true;
      }
    }
    return id;
  };

  await scanLines(
    source,
    (line) => {
      const c0 = line.charCodeAt(0);
      if (c0 === 35 /* # */ || line.length < 2) return;
      if (c0 === 118 /* v */) {
        const c1 = line.charCodeAt(1);
        if (c1 === 32 || c1 === 9) {
          const p = line.trim().split(/\s+/);
          const x = parseFloat(p[1]), y = parseFloat(p[2]), z = parseFloat(p[3]);
          P.push3(x || 0, y || 0, z || 0);
          if (p.length >= 7) {
            hasColor = true;
            C.push3(parseFloat(p[4]) || 0, parseFloat(p[5]) || 0, parseFloat(p[6]) || 0);
          } else C.push3(1, 1, 1);
        } else if (c1 === 116 /* t */ && !simple) {
          const p = line.trim().split(/\s+/);
          T.push2(parseFloat(p[1]) || 0, parseFloat(p[2]) || 0);
        } else if (c1 === 110 /* n */ && !simple) {
          const p = line.trim().split(/\s+/);
          N.push3(parseFloat(p[1]) || 0, parseFloat(p[2]) || 0, parseFloat(p[3]) || 0);
        }
        return;
      }
      if (c0 === 102 /* f */ && (line.charCodeAt(1) === 32 || line.charCodeAt(1) === 9)) {
        if (!curGroup) curGroup = groupFor('__default__');
        const toks = line.trim().split(/\s+/);
        const vc = P.n / 3, tc = T.n / 2, nc = N.n / 3;
        ids.length = 0;
        for (let k = 1; k < toks.length; k++) {
          const id = vertexId(curGroup, toks[k], vc, tc, nc);
          if (id >= 0) ids.push(id);
        }
        for (let k = 1; k + 1 < ids.length; k++) curGroup.idx.push3(ids[0], ids[k], ids[k + 1]);
        return;
      }
      if (line.startsWith('usemtl')) {
        curMat = line.slice(6).trim();
        curGroup = groupFor(curMat);
      } else if (line.startsWith('mtllib')) {
        mtlNames.push(...line.slice(6).trim().split(/\s+/).map(baseName));
      }
    },
    { onProgress },
  );

  const vertexTotal = P.n / 3;
  if (vertexTotal === 0) throw new Error('El OBJ no contiene vértices.');
  const faceGroups = [...groups.values()].filter((g) => g.idx.n > 0);
  if (faceGroups.length === 0) throw new Error('El OBJ no contiene caras (solo puntos o líneas).');

  // Materiales: se leen del .mtl adjunto (por nombre o, si solo hay uno, ese).
  let mtl = new Map();
  const mtlExtras = [...extras].filter(([, e]) => e.role === 'material');
  const wanted = mtlNames.map((n) => n.toLowerCase());
  let chosen = mtlExtras.filter(([name]) => wanted.includes(name));
  if (!chosen.length && mtlExtras.length === 1) chosen = mtlExtras;
  for (const [, e] of chosen) {
    for (const [k, v] of parseMtl(await readText(e.blob))) mtl.set(k, v);
  }
  if (mtlNames.length && !chosen.length) {
    warnings.push(`No se adjuntó el archivo de materiales (${mtlNames.join(', ')}). Se usan colores por defecto.`);
  }

  const materials = matOrder.map((name) => {
    const m = mtl.get(name);
    return {
      name: name === '__default__' ? 'default' : name,
      color: m ? m.color : [0.8, 0.8, 0.82],
      opacity: m ? m.opacity : 1,
      mapName: m ? m.mapName : null,
      map: -1,
      doubleSided: true,
      colorLinear: false,
    };
  });

  const meshes = faceGroups.map((g) => ({
    name: materials[g.matIdx].name,
    positions: g.pos.toArray(),
    normals: !g.simple && !g.badNormals ? g.nor.toArray() : null,
    uvs: !g.simple && g.anyUv ? g.uv.toArray() : null,
    colors: g.col ? g.col.toArray() : null,
    indices: g.idx.toArray(),
    material: g.matIdx,
  }));

  if (simple) warnings.push('Archivo muy grande: la vista previa no incluye texturas ni normales originales.');
  return { meshes, materials, images: [], info: { vertices: vertexTotal, objVertexColors: hasColor }, warnings };
}
