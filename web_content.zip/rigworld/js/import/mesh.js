// Utilidades de malla sin dependencias (se ejecutan en el Worker y en Node).
//
// Contrato de malla neutra (lo producen todos los parsers):
//   { name, positions: Float32Array, normals: Float32Array|null, uvs: Float32Array|null,
//     colors: Float32Array|null /* RGB */, indices: Uint32Array|null, material: number }
// Si indices es null, la malla no está indexada (cada 3 vértices forman un triángulo).

export class GrowF32 {
  constructor(capacity = 1024) {
    this.a = new Float32Array(capacity);
    this.n = 0;
  }
  #grow(extra) {
    if (this.n + extra <= this.a.length) return;
    let cap = this.a.length * 2;
    while (cap < this.n + extra) cap *= 2;
    const next = new Float32Array(cap);
    next.set(this.a.subarray(0, this.n));
    this.a = next;
  }
  push1(x) {
    this.#grow(1);
    this.a[this.n++] = x;
  }
  push2(x, y) {
    this.#grow(2);
    this.a[this.n++] = x;
    this.a[this.n++] = y;
  }
  push3(x, y, z) {
    this.#grow(3);
    const a = this.a;
    a[this.n++] = x;
    a[this.n++] = y;
    a[this.n++] = z;
  }
  toArray() {
    return this.a.slice(0, this.n);
  }
}

export class GrowU32 {
  constructor(capacity = 1024) {
    this.a = new Uint32Array(capacity);
    this.n = 0;
  }
  push3(x, y, z) {
    if (this.n + 3 > this.a.length) {
      const next = new Uint32Array(this.a.length * 2);
      next.set(this.a.subarray(0, this.n));
      this.a = next;
    }
    const a = this.a;
    a[this.n++] = x;
    a[this.n++] = y;
    a[this.n++] = z;
  }
  toArray() {
    return this.a.slice(0, this.n);
  }
}

export const triCount = (m) => (m.indices ? m.indices.length / 3 : m.positions.length / 9);
export const vertCount = (m) => m.positions.length / 3;

export function totalTris(meshes) {
  let t = 0;
  for (const m of meshes) t += triCount(m);
  return t;
}

export function totalVerts(meshes) {
  let t = 0;
  for (const m of meshes) t += vertCount(m);
  return t;
}

export function boundsOf(meshes) {
  const min = [Infinity, Infinity, Infinity];
  const max = [-Infinity, -Infinity, -Infinity];
  for (const m of meshes) {
    const p = m.positions;
    for (let i = 0; i < p.length; i += 3) {
      const x = p[i], y = p[i + 1], z = p[i + 2];
      if (x < min[0]) min[0] = x;
      if (x > max[0]) max[0] = x;
      if (y < min[1]) min[1] = y;
      if (y > max[1]) max[1] = y;
      if (z < min[2]) min[2] = z;
      if (z > max[2]) max[2] = z;
    }
  }
  if (!Number.isFinite(min[0])) return { min: [0, 0, 0], max: [0, 0, 0] };
  return { min, max };
}

// Normales suaves (promedio ponderado por área). Sin índices: normales planas por triángulo.
export function computeNormals(positions, indices) {
  const normals = new Float32Array(positions.length);
  const triN = indices ? indices.length : positions.length / 3;
  for (let t = 0; t < triN; t += 3) {
    const a = indices ? indices[t] * 3 : t * 3;
    const b = indices ? indices[t + 1] * 3 : (t + 1) * 3;
    const c = indices ? indices[t + 2] * 3 : (t + 2) * 3;
    const ux = positions[b] - positions[a], uy = positions[b + 1] - positions[a + 1], uz = positions[b + 2] - positions[a + 2];
    const vx = positions[c] - positions[a], vy = positions[c + 1] - positions[a + 1], vz = positions[c + 2] - positions[a + 2];
    const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
    for (const o of [a, b, c]) {
      normals[o] += nx;
      normals[o + 1] += ny;
      normals[o + 2] += nz;
    }
  }
  for (let i = 0; i < normals.length; i += 3) {
    const l = Math.hypot(normals[i], normals[i + 1], normals[i + 2]);
    if (l > 1e-20) {
      normals[i] /= l;
      normals[i + 1] /= l;
      normals[i + 2] /= l;
    } else normals[i + 1] = 1;
  }
  return normals;
}

// Aplica una matriz de mundo 4×4 (columnas, como glTF y Three.js) a posiciones y normales.
// Devuelve arrays nuevos y `flipped`: true si la matriz refleja (determinante < 0), en cuyo caso
// quien construya los triángulos debe invertir su orden para conservar la cara frontal.
export function bakeWorld(w, positions, normals) {
  const outP = new Float32Array(positions.length);
  for (let i = 0; i < positions.length; i += 3) {
    const x = positions[i], y = positions[i + 1], z = positions[i + 2];
    outP[i] = w[0] * x + w[4] * y + w[8] * z + w[12];
    outP[i + 1] = w[1] * x + w[5] * y + w[9] * z + w[13];
    outP[i + 2] = w[2] * x + w[6] * y + w[10] * z + w[14];
  }
  const a = w[0], b = w[4], c = w[8], d = w[1], e = w[5], f = w[9], g = w[2], h = w[6], k = w[10];
  const c00 = e * k - f * h, c01 = -(d * k - f * g), c02 = d * h - e * g;
  const c10 = -(b * k - c * h), c11 = a * k - c * g, c12 = -(a * h - b * g);
  const c20 = b * f - c * e, c21 = -(a * f - c * d), c22 = a * e - b * d;
  const det = a * c00 + b * c01 + c * c02;
  const sgn = det < 0 ? -1 : 1;
  let outN = null;
  if (normals) {
    outN = new Float32Array(normals.length);
    for (let i = 0; i < normals.length; i += 3) {
      const nx = normals[i], ny = normals[i + 1], nz = normals[i + 2];
      const x = (c00 * nx + c01 * ny + c02 * nz) * sgn;
      const y = (c10 * nx + c11 * ny + c12 * nz) * sgn;
      const z = (c20 * nx + c21 * ny + c22 * nz) * sgn;
      const l = Math.hypot(x, y, z) || 1;
      outN[i] = x / l;
      outN[i + 1] = y / l;
      outN[i + 2] = z / l;
    }
  }
  return { positions: outP, normals: outN, flipped: det < 0 };
}

// Invierte el orden de cada triángulo (b↔c). Sin índices, crea índices secuenciales.
export function flipWinding(indices, vertexCount) {
  const out = indices ? indices.slice() : Uint32Array.from({ length: vertexCount }, (_, i) => i);
  for (let i = 0; i + 2 < out.length; i += 3) {
    const t = out[i + 1];
    out[i + 1] = out[i + 2];
    out[i + 2] = t;
  }
  return out;
}

export function ensureNormals(meshes) {
  for (const m of meshes) if (!m.normals) m.normals = computeNormals(m.positions, m.indices);
  return meshes;
}

// Une vértices idénticos de una malla sin índices. Para mallas pequeñas (STL).
export function weldMesh(positions) {
  const bits = new Uint32Array(positions.buffer, positions.byteOffset, positions.length);
  const map = new Map();
  const out = new GrowF32(Math.min(positions.length, 4096));
  const idx = new Uint32Array(positions.length / 3);
  for (let i = 0; i < idx.length; i++) {
    const o = i * 3;
    const key = `${bits[o]},${bits[o + 1]},${bits[o + 2]}`;
    let id = map.get(key);
    if (id === undefined) {
      id = out.n / 3;
      out.push3(positions[o], positions[o + 1], positions[o + 2]);
      map.set(key, id);
    }
    idx[i] = id;
  }
  return { positions: out.toArray(), indices: idx };
}

// ── Decimado por agrupación de vértices ─────────────────────────────────────────────────────
// Reduce la malla a ~targetTris triángulos conservando la silueta. Cada vértice cae en una celda
// de una rejilla 3D y los que comparten celda se funden en uno. Para que la textura sobreviva:
//   · cada material se decima por separado y conserva su índice de material;
//   · la clave de celda incluye la zona de la textura (UV), así dos partes del modelo que se tocan
//     en 3D pero viven en islas distintas del atlas no se mezclan;
//   · cada vértice resultante conserva las UV de su primer miembro (nunca un promedio entre islas);
//   · las normales son el promedio de las originales, y los triángulos que quedan plegados al
//     fundir vértices se vuelven a orientar según ellas (si no, aparecen puntos oscuros).
const MAX_AXIS_CELLS = 640; // acota la clave numérica (celda × zona UV) por debajo de 2^53
const UV_CELL_FACTOR = 3; // tamaño de la zona UV respecto a lo que cubre una celda 3D
const FOLD_TOLERANCE = 0.1;

function median(values) {
  if (!values.length) return 0;
  values.sort((a, b) => a - b);
  return values[values.length >> 1];
}

// Cuánto cambian las UV por unidad de espacio: mediana de |ΔUV| / |Δposición| en aristas de muestra.
function estimateUvScale(list) {
  const ratios = [];
  for (const m of list) {
    const nt = triCount(m);
    const step = Math.max(1, Math.floor(nt / 1500));
    const p = m.positions, uv = m.uvs, idx = m.indices;
    for (let t = 0; t < nt; t += step) {
      const a = idx ? idx[t * 3] : t * 3, b = idx ? idx[t * 3 + 1] : t * 3 + 1;
      const dp = Math.hypot(p[a * 3] - p[b * 3], p[a * 3 + 1] - p[b * 3 + 1], p[a * 3 + 2] - p[b * 3 + 2]);
      if (dp < 1e-12) continue;
      ratios.push(Math.hypot(uv[a * 2] - uv[b * 2], uv[a * 2 + 1] - uv[b * 2 + 1]) / dp);
    }
  }
  return median(ratios);
}

function planGroups(meshes, { materials, merge }) {
  const byMaterial = new Map();
  for (const m of meshes) {
    const key = merge ? 0 : m.material;
    if (!byMaterial.has(key)) byMaterial.set(key, []);
    byMaterial.get(key).push(m);
  }
  const groups = [];
  for (const [material, list] of byMaterial) {
    // Las UV solo se conservan si el material realmente usa una textura.
    const textured = !merge && list.every((m) => m.uvs) && (!materials || (materials[material]?.map ?? -1) >= 0);
    groups.push({
      material,
      list,
      uv: textured,
      uvScale: textured ? estimateUvScale(list) : 0,
      normals: list.every((m) => m.normals),
      colors: list.every((m) => m.colors),
    });
  }
  return groups;
}

// Agrupa los vértices de un material y devuelve una malla indexada compacta.
function clusterGroup(g, grid, cell) {
  const { min, nx, ny, inv } = grid;
  const guv = g.uv ? Math.ceil(1 / Math.min(1 / 16, Math.max(1 / 1024, UV_CELL_FACTOR * cell * g.uvScale))) : 1;
  const uvStride = guv * guv;
  const clusters = new Map();
  const sumP = new GrowF32(3 * 4096);
  const sumN = g.normals ? new GrowF32(3 * 4096) : null;
  const sumC = g.colors ? new GrowF32(3 * 4096) : null;
  const firstUv = g.uv ? new GrowF32(2 * 4096) : null;
  const count = [];
  const tris = new GrowU32(3 * 4096);

  for (const m of g.list) {
    const p = m.positions, nrm = m.normals, uv = m.uvs, col = m.colors, idx = m.indices;
    const vid = new Int32Array(p.length / 3).fill(-1); // vértice original → clúster
    const clusterOf = (v) => {
      let id = vid[v];
      if (id >= 0) return id;
      const o = v * 3;
      const ix = Math.min(nx - 1, Math.floor((p[o] - min[0]) * inv));
      const iy = Math.min(ny - 1, Math.floor((p[o + 1] - min[1]) * inv));
      const iz = Math.floor((p[o + 2] - min[2]) * inv);
      let key = ix + nx * (iy + ny * iz);
      if (g.uv) {
        const u = uv[v * 2], w = uv[v * 2 + 1];
        const iu = Math.min(guv - 1, Math.floor((u - Math.floor(u)) * guv));
        const iw = Math.min(guv - 1, Math.floor((w - Math.floor(w)) * guv));
        key = key * uvStride + iu + guv * iw;
      }
      id = clusters.get(key);
      if (id === undefined) {
        id = count.length;
        clusters.set(key, id);
        count.push(0);
        sumP.push3(0, 0, 0);
        sumN?.push3(0, 0, 0);
        sumC?.push3(0, 0, 0);
        firstUv?.push2(uv[v * 2], uv[v * 2 + 1]);
      }
      count[id]++;
      sumP.a[id * 3] += p[o];
      sumP.a[id * 3 + 1] += p[o + 1];
      sumP.a[id * 3 + 2] += p[o + 2];
      if (sumN) {
        sumN.a[id * 3] += nrm[o];
        sumN.a[id * 3 + 1] += nrm[o + 1];
        sumN.a[id * 3 + 2] += nrm[o + 2];
      }
      if (sumC) {
        sumC.a[id * 3] += col[o];
        sumC.a[id * 3 + 1] += col[o + 1];
        sumC.a[id * 3 + 2] += col[o + 2];
      }
      vid[v] = id;
      return id;
    };
    const nt = triCount(m);
    for (let t = 0; t < nt; t++) {
      const a = clusterOf(idx ? idx[t * 3] : t * 3);
      const b = clusterOf(idx ? idx[t * 3 + 1] : t * 3 + 1);
      const c = clusterOf(idx ? idx[t * 3 + 2] : t * 3 + 2);
      if (a === b || b === c || a === c) continue; // el triángulo se colapsó
      tris.push3(a, b, c);
    }
  }

  // Compacta: solo se conservan los clústeres que algún triángulo usa.
  const used = new Uint8Array(count.length);
  for (let i = 0; i < tris.n; i++) used[tris.a[i]] = 1;
  const remap = new Int32Array(count.length).fill(-1);
  let vN = 0;
  for (let i = 0; i < count.length; i++) if (used[i]) remap[i] = vN++;

  const positions = new Float32Array(vN * 3);
  const uvs = g.uv ? new Float32Array(vN * 2) : null;
  const colors = g.colors ? new Float32Array(vN * 3) : null;
  let normals = g.normals ? new Float32Array(vN * 3) : null;
  let weakNormals = false;
  for (let i = 0; i < count.length; i++) {
    const r = remap[i];
    if (r < 0) continue;
    const k = 1 / count[i];
    positions[r * 3] = sumP.a[i * 3] * k;
    positions[r * 3 + 1] = sumP.a[i * 3 + 1] * k;
    positions[r * 3 + 2] = sumP.a[i * 3 + 2] * k;
    if (uvs) {
      uvs[r * 2] = firstUv.a[i * 2];
      uvs[r * 2 + 1] = firstUv.a[i * 2 + 1];
    }
    if (colors) {
      colors[r * 3] = sumC.a[i * 3] * k;
      colors[r * 3 + 1] = sumC.a[i * 3 + 1] * k;
      colors[r * 3 + 2] = sumC.a[i * 3 + 2] * k;
    }
    if (normals) {
      const x = sumN.a[i * 3], y = sumN.a[i * 3 + 1], z = sumN.a[i * 3 + 2];
      const l = Math.hypot(x, y, z);
      if (l > 1e-6) {
        normals[r * 3] = x / l;
        normals[r * 3 + 1] = y / l;
        normals[r * 3 + 2] = z / l;
      } else weakNormals = true; // normales opuestas que se anulan: se calculan de la geometría
    }
  }
  const indices = new Uint32Array(tris.n);
  for (let i = 0; i < tris.n; i++) indices[i] = remap[tris.a[i]];

  if (!normals) {
    normals = computeNormals(positions, indices);
  } else {
    if (weakNormals) {
      const fallback = computeNormals(positions, indices);
      for (let v = 0; v < vN; v++) {
        if (normals[v * 3] === 0 && normals[v * 3 + 1] === 0 && normals[v * 3 + 2] === 0) {
          normals[v * 3] = fallback[v * 3];
          normals[v * 3 + 1] = fallback[v * 3 + 1];
          normals[v * 3 + 2] = fallback[v * 3 + 2];
        }
      }
    }
    // Triángulos plegados por la fusión: se reorientan para que concuerden con las normales.
    for (let t = 0; t < indices.length; t += 3) {
      const a = indices[t] * 3, b = indices[t + 1] * 3, c = indices[t + 2] * 3;
      const ux = positions[b] - positions[a], uy = positions[b + 1] - positions[a + 1], uz = positions[b + 2] - positions[a + 2];
      const vx = positions[c] - positions[a], vy = positions[c + 1] - positions[a + 1], vz = positions[c + 2] - positions[a + 2];
      const fx = uy * vz - uz * vy, fy = uz * vx - ux * vz, fz = ux * vy - uy * vx;
      const sx = normals[a] + normals[b] + normals[c];
      const sy = normals[a + 1] + normals[b + 1] + normals[c + 1];
      const sz = normals[a + 2] + normals[b + 2] + normals[c + 2];
      const dot = fx * sx + fy * sy + fz * sz;
      if (dot < -FOLD_TOLERANCE * Math.hypot(fx, fy, fz) * Math.hypot(sx, sy, sz)) {
        const tmp = indices[t + 1];
        indices[t + 1] = indices[t + 2];
        indices[t + 2] = tmp;
      }
    }
  }
  return { material: g.material, positions, normals, uvs, colors, indices, tris: indices.length / 3 };
}

// Decima a ~targetTris triángulos en total. Devuelve una malla por material.
//   materials: lista de materiales (para saber cuáles llevan textura y conservar sus UV).
//   merge: junta todo en una sola malla sin UV (miniaturas 2D).
export function decimateMeshes(meshes, targetTris, { materials = null, merge = false } = {}) {
  const b = boundsOf(meshes);
  const ex = b.max[0] - b.min[0], ey = b.max[1] - b.min[1], ez = b.max[2] - b.min[2];
  const maxExt = Math.max(ex, ey, ez) || 1;
  const groups = planGroups(meshes, { materials, merge });
  const limit = targetTris * 1.15;
  let n = Math.min(MAX_AXIS_CELLS, Math.max(4, Math.round(Math.sqrt(targetTris / 3))));
  let best = null;

  for (let iter = 0; iter < 5; iter++) {
    const cell = maxExt / n;
    const grid = { min: b.min, nx: Math.floor(ex / cell) + 1, ny: Math.floor(ey / cell) + 1, inv: 1 / cell };
    const parts = groups.map((g) => clusterGroup(g, grid, cell));
    const triOut = parts.reduce((sum, part) => sum + part.tris, 0);
    const result = { parts, tris: triOut };
    // Se prefiere el resultado más denso que no pase el límite; si todos lo pasan, el más pequeño.
    if (!best) best = result;
    else if (triOut <= limit && (best.tris > limit || triOut > best.tris)) best = result;
    else if (triOut > limit && best.tris > limit && triOut < best.tris) best = result;
    if (triOut <= limit && triOut >= targetTris * 0.6) break;
    // Ajuste de resolución: los triángulos crecen ~ n².
    const factor = Math.sqrt(targetTris / Math.max(1, triOut));
    const next = Math.min(MAX_AXIS_CELLS, Math.max(4, Math.round(n * Math.min(2, Math.max(0.4, factor)))));
    if (next === n) break;
    n = next;
  }
  return best.parts.filter((part) => part.tris > 0).map(({ tris, ...mesh }) => ({ name: 'preview', ...mesh }));
}

// Versión de siempre: una sola malla indexada, sin UV (para miniaturas 2D y pruebas).
export function decimateCluster(meshes, targetTris) {
  const [one] = decimateMeshes(meshes, targetTris, { merge: true });
  return one || { name: 'preview', positions: new Float32Array(0), normals: new Float32Array(0), uvs: null, colors: null, indices: new Uint32Array(0), material: 0 };
}

// Devuelve las mallas de vista previa: tal cual si caben en el presupuesto; si no, decimadas
// (una por material, con sus UV si el material tiene textura).
export function simplifyForPreview(meshes, budgetTris, materials = null) {
  const original = totalTris(meshes);
  if (original <= budgetTris) return { meshes: ensureNormals(meshes), simplified: false, originalTriangles: original };
  return { meshes: decimateMeshes(meshes, budgetTris, { materials }), simplified: true, originalTriangles: original };
}
