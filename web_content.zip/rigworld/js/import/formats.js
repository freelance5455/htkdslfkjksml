// Detección de formato por firma de bytes y agrupación de archivos auxiliares.
// Sin dependencias: se usa tanto en la UI como en las pruebas de Node.
import { LIMITS } from '../config.js';

export const MAIN_FORMATS = Object.freeze(['glb', 'gltf', 'fbx', 'obj', 'dae', 'stl', 'ply']);

export const FORMAT_LABEL = Object.freeze({
  glb: 'GLB',
  gltf: 'glTF',
  fbx: 'FBX',
  obj: 'OBJ',
  dae: 'DAE',
  stl: 'STL',
  ply: 'PLY',
});

const IMAGE_MIME = {
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  webp: 'image/webp',
  gif: 'image/gif',
  bmp: 'image/bmp',
};

export const ACCEPT_ATTR = '.glb,.gltf,.fbx,.obj,.dae,.stl,.ply,.bin,.mtl,.png,.jpg,.jpeg,.webp,.gif,.bmp';

export function baseName(path) {
  return String(path || '').split(/[\\/]/).pop();
}

export function extOf(name) {
  const m = /\.([a-z0-9]+)$/i.exec(baseName(name));
  return m ? m[1].toLowerCase() : '';
}

export function stripExt(name) {
  return baseName(name).replace(/\.[a-z0-9]+$/i, '');
}

export function mimeFor(name, role) {
  const ext = extOf(name);
  if (role === 'texture') return IMAGE_MIME[ext] || 'application/octet-stream';
  if (ext === 'glb') return 'model/gltf-binary';
  if (ext === 'gltf') return 'model/gltf+json';
  return 'application/octet-stream';
}

const decodeAscii = (bytes, n = bytes.length) => {
  let s = '';
  const end = Math.min(n, bytes.length);
  for (let i = 0; i < end; i++) s += String.fromCharCode(bytes[i]);
  return s;
};

// head: primeros bytes del archivo (con 4 KB basta). size: tamaño total en bytes.
// Devuelve { role, format?, note? } donde role ∈ main | buffer | material | texture | unknown.
export function classifyHead(name, head, size) {
  const ext = extOf(name);
  const text = decodeAscii(head, 1024);
  const trimmed = text.replace(/^﻿/, '').trimStart();

  if (ext in IMAGE_MIME) return { role: 'texture' };
  if (ext === 'mtl') return { role: 'material' };
  if (ext === 'bin') return { role: 'buffer' };

  // Firmas inequívocas primero: mandan sobre la extensión.
  if (head.length >= 4 && decodeAscii(head, 4) === 'glTF') return { role: 'main', format: 'glb' };
  if (text.startsWith('Kaydara FBX Binary') || /^;\s*FBX/.test(trimmed)) return { role: 'main', format: 'fbx' };
  if (/^ply\r?\n/.test(text) || /^ply\s/.test(text)) return { role: 'main', format: 'ply' };
  if (/<COLLADA[\s>]/i.test(text) || (trimmed.startsWith('<?xml') && ext === 'dae')) return { role: 'main', format: 'dae' };

  if (ext === 'gltf') {
    if (trimmed.startsWith('{')) return { role: 'main', format: 'gltf' };
    return { role: 'unknown', note: 'El archivo .gltf no contiene JSON válido.' };
  }
  if (ext === 'stl') {
    if (isBinaryStl(head, size) || /^solid/i.test(trimmed)) return { role: 'main', format: 'stl' };
    return { role: 'unknown', note: 'El archivo .stl no tiene un formato STL reconocible.' };
  }
  if (ext === 'obj') return { role: 'main', format: 'obj' };
  if (ext === 'fbx') return { role: 'unknown', note: 'El archivo .fbx no tiene una cabecera FBX válida.' };
  if (ext === 'dae') return { role: 'unknown', note: 'El archivo .dae no es un documento Collada válido.' };
  if (ext === 'ply') return { role: 'unknown', note: 'El archivo .ply no tiene una cabecera PLY válida.' };
  if (ext === 'glb') return { role: 'unknown', note: 'El archivo .glb no tiene una cabecera glTF válida.' };

  return { role: 'unknown', note: `Formato no compatible${ext ? ` (.${ext})` : ''}.` };
}

// STL binario: 80 bytes de cabecera + uint32 de triángulos + 50 bytes por triángulo.
export function isBinaryStl(head, size) {
  if (head.length < 84 || !Number.isFinite(size)) return false;
  const count = new DataView(head.buffer, head.byteOffset, head.byteLength).getUint32(80, true);
  return 84 + count * 50 === size;
}

export async function readHead(file, bytes = 4096) {
  return new Uint8Array(await file.slice(0, bytes).arrayBuffer());
}

// Valida y clasifica una selección de archivos. Devuelve:
//   groups:   [{ name, format, main: File, extras: [{file, role}] }]
//   rejected: [{ name, reason }]
export async function groupSelection(fileList) {
  const files = [...fileList];
  const rejected = [];
  const mains = [];
  const extras = [];

  for (const file of files) {
    const name = baseName(file.name);
    if (file.size === 0) {
      rejected.push({ name, reason: 'El archivo está vacío.' });
      continue;
    }
    if (file.size > LIMITS.maxFileBytes) {
      rejected.push({ name, reason: `Supera el límite de ${LIMITS.maxFileBytes / 1024 / 1024} MB por archivo.` });
      continue;
    }
    let info;
    try {
      info = classifyHead(name, await readHead(file), file.size);
    } catch {
      rejected.push({ name, reason: 'No se pudo leer el archivo.' });
      continue;
    }
    if (info.role === 'main') mains.push({ file, name, format: info.format });
    else if (info.role === 'unknown') rejected.push({ name, reason: info.note });
    else extras.push({ file, name, role: info.role });
  }

  if (mains.length === 0 && extras.length) {
    rejected.push(
      ...extras.map((e) => ({ name: e.name, reason: 'Archivo auxiliar sin modelo. Selecciónalo junto con su .gltf, .obj o .fbx.' })),
    );
    return { groups: [], rejected };
  }

  const wants = {
    gltf: ['buffer', 'texture'],
    glb: ['texture'],
    obj: ['material', 'texture'],
    fbx: ['texture'],
    dae: ['texture'],
    stl: [],
    ply: [],
  };

  const groups = mains.map((m) => ({
    name: stripExt(m.name),
    format: m.format,
    main: m.file,
    extras: extras.filter((e) => wants[m.format].includes(e.role)).map((e) => ({ file: e.file, role: e.role })),
  }));

  // Auxiliares que ningún modelo usa.
  for (const e of extras) {
    if (!groups.some((g) => g.extras.some((x) => x.file === e.file))) {
      rejected.push({ name: e.name, reason: 'No lo usa ninguno de los modelos seleccionados.' });
    }
  }
  return { groups, rejected };
}
