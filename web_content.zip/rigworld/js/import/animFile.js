// Lee un archivo FBX o GLB/glTF con un personaje animado (p. ej. de Mixamo) y devuelve su esqueleto y sus clips
// en datos planos (ver rig/sourceScene.js). Corre en el hilo principal porque los cargadores de Three.js necesitan DOM.
// No se importa la malla ni las texturas: cualquier textura se sustituye por un píxel transparente.
import { loadThree } from '../core/threeLoader.js';
import { LIMITS } from '../config.js';
import { extOf, stripExt } from './formats.js';
import { sourceFromObject3D, clipsFromThree } from '../rig/sourceScene.js';

const TRANSPARENT_PX = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
export const ANIM_ACCEPT = '.fbx,.glb,.gltf';

export async function readAnimationFile(file, { onProgress } = {}) {
  const ext = extOf(file.name);
  if (!['fbx', 'glb', 'gltf'].includes(ext)) throw new Error('Para animaciones usa un archivo FBX, GLB o glTF.');
  if (file.size > LIMITS.maxFileBytes) throw new Error('El archivo supera el límite de 200 MB.');
  const THREE = await loadThree();
  const manager = new THREE.LoadingManager();
  manager.setURLModifier(() => TRANSPARENT_PX);
  onProgress?.(0.1);
  let root;
  let animations;
  try {
    if (ext === 'fbx') {
      const { FBXLoader } = await import('three/addons/loaders/FBXLoader.js');
      const buf = await file.arrayBuffer();
      onProgress?.(0.3);
      root = new FBXLoader(manager).parse(buf, '');
      animations = root.animations || [];
    } else {
      const { GLTFLoader } = await import('three/addons/loaders/GLTFLoader.js');
      const { MeshoptDecoder } = await import('three/addons/libs/meshopt_decoder.module.js');
      const loader = new GLTFLoader(manager);
      loader.setMeshoptDecoder(MeshoptDecoder);
      const data = ext === 'glb' ? await file.arrayBuffer() : await file.text();
      onProgress?.(0.3);
      const gltf = await new Promise((resolve, reject) => loader.parse(data, '', resolve, reject));
      root = gltf.scene;
      animations = gltf.animations || [];
    }
  } catch (err) {
    throw new Error(`No se pudo leer el archivo ${ext.toUpperCase()}: ${err?.message || err}.`);
  }
  onProgress?.(0.7);
  if (!animations.length) throw new Error('El archivo no contiene animaciones. Descarga el personaje con la animación incluida (en Mixamo, formato FBX).');
  const source = sourceFromObject3D(root);
  const clips = clipsFromThree(animations);
  if (!clips.length) throw new Error('Las animaciones del archivo no tienen movimiento de huesos que se pueda usar.');
  onProgress?.(1);
  return { source, clips, label: stripExt(file.name) };
}
