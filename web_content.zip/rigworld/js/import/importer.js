// Cola de importación. Procesa un modelo cada vez (la memoria de un móvil no aguanta dos
// archivos de 200 MB a la vez): analizar → miniatura → guardar. Permite cancelar y reintentar.
import { bus } from '../core/bus.js';
import { settings } from '../core/settings.js';
import { LIMITS, THUMB_VERSION } from '../config.js';
import { friendlyStorageError } from '../storage/db.js';
import { NATIVE_FORMATS, NeedsThreeError } from './parse.js';
import { parseInBackground } from './client.js';
import { parseWithThree } from './threeImport.js';
import { renderThumbnail } from './thumbs.js';
import { isThreeLoaded } from '../core/threeLoader.js';
import { mimeFor } from './formats.js';
import { buildSampleGlb, SAMPLE_NAME } from './sample.js';

export const STATUS = Object.freeze({
  QUEUED: 'queued',
  PARSING: 'parsing',
  THUMB: 'thumb',
  SAVING: 'saving',
  DONE: 'done',
  ERROR: 'error',
  CANCELED: 'canceled',
});

const ACTIVE = new Set([STATUS.QUEUED, STATUS.PARSING, STATUS.THUMB, STATUS.SAVING]);

// Parseo con el mejor método disponible para el formato.
export async function parseAny(job, { onProgress, signal } = {}) {
  if (NATIVE_FORMATS.has(job.format)) {
    try {
      return await parseInBackground(job, { onProgress, signal });
    } catch (err) {
      if (!(err instanceof NeedsThreeError)) throw err;
      return parseWithThree({ ...job, onProgress });
    }
  }
  return parseWithThree({ ...job, onProgress });
}

// ── Vista previa de un modelo ya guardado (se vuelve a analizar el archivo original) ─────────
const previewCache = new Map(); // id → resultado; máximo 2 entradas
export function rememberPreview(id, result) {
  previewCache.delete(id);
  previewCache.set(id, result);
  while (previewCache.size > 2) previewCache.delete(previewCache.keys().next().value);
}
export const forgetPreview = (id) => previewCache.delete(id);

// full: true carga la geometría completa (sin simplificar). No se guarda en la caché: puede pesar
// decenas de MB y solo se mantiene mientras el visor la usa.
export async function loadPreviewFor(store, model, { onProgress, signal, full = false } = {}) {
  const hit = full ? null : previewCache.get(model.id);
  if (hit && hit.budget === settings.get('budgetTris')) return hit.result;
  const mainIdx = model.files.findIndex((f) => f.role === 'main');
  const file = await store.getFileBlob(model.id, mainIdx);
  const extras = [];
  for (let i = 0; i < model.files.length; i++) {
    if (i === mainIdx) continue;
    extras.push({ name: model.files[i].name, role: model.files[i].role, blob: await store.getFileBlob(model.id, i) });
  }
  const budgetTris = full ? Infinity : settings.get('budgetTris');
  const result = await parseAny({ format: model.format, file, extras, budgetTris }, { onProgress, signal });
  if (!full) rememberPreview(model.id, { result, budget: budgetTris });
  return result;
}

// ¿La miniatura de este modelo conviene redibujarla? Solo importan los modelos con textura: los demás
// se ven igual. Una miniatura en 2D tampoco muestra textura, pero solo se ofrece rehacerla si ahora
// hay motor 3D disponible.
export function thumbOutdated(model, { webgl = true } = {}) {
  if (!(model.stats?.textures > 0)) return false;
  if ((model.thumbVersion || 1) < THUMB_VERSION) return webgl;
  return model.thumbMode === '2d' && !model.thumbRetried && webgl && isThreeLoaded();
}

const STAGE_LABEL = {
  [STATUS.QUEUED]: 'En cola',
  [STATUS.PARSING]: 'Analizando geometría',
  [STATUS.THUMB]: 'Creando miniatura',
  [STATUS.SAVING]: 'Guardando en el dispositivo',
  [STATUS.DONE]: 'Listo',
  [STATUS.ERROR]: 'Error',
  [STATUS.CANCELED]: 'Cancelado',
};

export class Importer {
  constructor(store, { useWebGL = true } = {}) {
    this.store = store;
    this.useWebGL = useWebGL;
    this.tasks = [];
    this.seq = 1;
    this.running = false;
    this.regenerating = false;
    this.controllers = new Map();
  }

  snapshot() {
    return this.tasks.map(({ group, ...pub }) => ({ ...pub, canRetry: !!group && (pub.status === STATUS.ERROR || pub.status === STATUS.CANCELED) }));
  }

  #emit() {
    bus.emit('import:tasks', this.snapshot());
  }

  #set(task, status, progress, message) {
    task.status = status;
    if (progress != null) task.progress = Math.max(task.progress, Math.min(1, progress));
    task.message = message ?? STAGE_LABEL[status];
    this.#emit();
  }

  // Vuelve a dibujar las miniaturas de los modelos que se crearon sin textura. No reimporta nada:
  // analiza otra vez el archivo guardado. Devuelve { total, improved }.
  async regenerateThumbnails({ onProgress } = {}) {
    if (this.running || this.regenerating) return { total: 0, improved: 0 };
    this.regenerating = true;
    let improved = 0;
    try {
      const todo = (await this.store.listModels()).filter((m) => thumbOutdated(m, { webgl: this.useWebGL }));
      for (let n = 0; n < todo.length; n++) {
        const m = todo[n];
        onProgress?.({ done: n, total: todo.length, name: m.name });
        try {
          const { preview } = await loadPreviewFor(this.store, m);
          const thumb = await renderThumbnail(preview, { useWebGL: this.useWebGL });
          await this.store.updateModel(
            m.id,
            { thumb: { type: thumb.type, data: thumb.data }, thumbVersion: THUMB_VERSION, thumbMode: thumb.mode, thumbStamp: Date.now(), thumbRetried: thumb.mode === '2d' },
            { touch: false },
          );
          if (thumb.mode === 'webgl') improved++;
          bus.emit('library:changed', { thumb: m.id });
        } catch (err) {
          console.warn('[miniaturas]', m.name, err);
        }
      }
      return { total: todo.length, improved };
    } finally {
      this.regenerating = false;
    }
  }

  get activeCount() {
    return this.tasks.filter((t) => ACTIVE.has(t.status)).length;
  }

  // groups: resultado de groupSelection().groups. Devuelve cuántos entraron y cuántos no caben.
  enqueue(groups) {
    const room = Math.max(0, LIMITS.maxPending - this.activeCount);
    const accepted = groups.slice(0, room);
    for (const g of accepted) {
      this.tasks.push({
        id: this.seq++,
        name: g.name,
        format: g.format,
        sizeBytes: g.main.size + g.extras.reduce((s, e) => s + e.file.size, 0),
        group: g,
        status: STATUS.QUEUED,
        progress: 0,
        message: STAGE_LABEL[STATUS.QUEUED],
        error: null,
        warnings: [],
        modelId: null,
      });
    }
    this.#emit();
    this.#run();
    return { accepted: accepted.length, overflow: groups.length - accepted.length };
  }

  enqueueSample() {
    const file = new File([buildSampleGlb()], 'maniqui-ejemplo.glb', { type: 'model/gltf-binary' });
    return this.enqueue([{ name: SAMPLE_NAME, format: 'glb', main: file, extras: [] }]);
  }

  cancel(id) {
    const t = this.tasks.find((x) => x.id === id);
    if (!t) return;
    if (t.status === STATUS.QUEUED) this.#set(t, STATUS.CANCELED, null, 'Cancelado');
    else if (ACTIVE.has(t.status)) this.controllers.get(id)?.abort();
  }

  retry(id) {
    const t = this.tasks.find((x) => x.id === id);
    if (!t?.group || (t.status !== STATUS.ERROR && t.status !== STATUS.CANCELED)) return;
    t.progress = 0;
    t.error = null;
    this.#set(t, STATUS.QUEUED, 0);
    this.#run();
  }

  clearFinished() {
    this.tasks = this.tasks.filter((t) => ACTIVE.has(t.status));
    this.#emit();
  }

  async #run() {
    if (this.running) return;
    this.running = true;
    try {
      let next;
      while ((next = this.tasks.find((t) => t.status === STATUS.QUEUED))) await this.#process(next);
    } finally {
      this.running = false;
    }
  }

  async #process(task) {
    const ctl = new AbortController();
    this.controllers.set(task.id, ctl);
    const check = () => {
      if (ctl.signal.aborted) throw new DOMException('Importación cancelada', 'AbortError');
    };
    try {
      const { main, extras } = task.group;
      this.#set(task, STATUS.PARSING, 0.02);
      const result = await parseAny(
        {
          format: task.format,
          file: main,
          extras: extras.map((e) => ({ name: e.file.name, role: e.role, blob: e.file })),
          budgetTris: settings.get('budgetTris'),
        },
        { onProgress: (p) => this.#set(task, STATUS.PARSING, 0.02 + p * 0.58), signal: ctl.signal },
      );
      check();

      this.#set(task, STATUS.THUMB, 0.62);
      const thumb = await renderThumbnail(result.preview, { useWebGL: this.useWebGL });
      check();

      this.#set(task, STATUS.SAVING, 0.7);
      const files = [
        { name: main.name, mime: mimeFor(main.name, 'main'), role: 'main', data: main },
        ...extras.map((e) => ({ name: e.file.name, mime: e.file.type || mimeFor(e.file.name, e.role), role: e.role, data: e.file })),
      ];
      const record = await this.store.saveModel(
        {
          name: task.name,
          format: task.format,
          files,
          stats: result.stats,
          thumb: { type: thumb.type, data: thumb.data },
          meta: { thumbVersion: THUMB_VERSION, thumbMode: thumb.mode, thumbStamp: Date.now() },
        },
        { onProgress: (p) => this.#set(task, STATUS.SAVING, 0.7 + p * 0.3) },
      );
      check();

      task.modelId = record.id;
      task.warnings = result.warnings;
      task.group = null; // libera las referencias a los archivos
      rememberPreview(record.id, { result, budget: settings.get('budgetTris') });
      this.#set(task, STATUS.DONE, 1);
      bus.emit('library:changed', { added: record.id });
    } catch (err) {
      if (err?.name === 'AbortError') {
        // Si el guardado ya había terminado, el modelo existe: se retira para que cancelar signifique cancelar.
        if (task.modelId) await this.store.deleteModel(task.modelId).catch(() => {});
        task.modelId = null;
        this.#set(task, STATUS.CANCELED, null, 'Cancelado');
        bus.emit('library:changed', {});
      } else {
        console.error('[import]', task.name, err);
        task.error = err?.name === 'QuotaExceededError' || /quota|storage|almacenamiento/i.test(err?.message || '')
          ? friendlyStorageError(err)
          : err?.message || 'Error desconocido al importar.';
        this.#set(task, STATUS.ERROR, null, 'No se pudo importar');
      }
    } finally {
      this.controllers.delete(task.id);
    }
  }
}
