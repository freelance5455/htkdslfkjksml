// Capa 3 · Estudio de personaje: esqueleto automático + animación (reposo, marcha, carrera, salto, saludo).
//
// Flujo: vista previa del modelo → ajuste del esqueleto (Worker) → pesos de skinning (Worker) → visor con
// SkinnedMesh y animación procedural. El rig se guarda solo al terminar de ajustarse (≈ 3 KB); los pesos se
// recalculan al abrir. «Girar 90°» corrige el frente si el modelo salió de lado o de espaldas.
import { h, icon, clear } from '../ui/dom.js';
import { openSheet } from '../ui/sheet.js';
import { toast } from '../ui/toast.js';
import { PreviewViewer } from '../ui/viewer3d.js';
import { loadPreviewFor } from '../import/importer.js';
import { settings } from '../core/settings.js';
import { fitRigInBackground, skinInBackground } from '../rig/client.js';
import { isRigCompatible, orientMeshes, describeRig } from '../rig/service.js';
import { buildRiggedPreview } from '../rig/skinned.js';
import { createAnimator } from '../rig/animator.js';
import { blendPose, clonePose } from '../rig/skeleton.js';
import { smoothstep } from '../rig/mathq.js';
import { createRetargeter, createClipPlayer, isClipValid, RETARGET_LIMITS } from '../rig/retarget.js';
import { readAnimationFile, ANIM_ACCEPT } from '../import/animFile.js';

const QUALITY_LABEL = { good: 'Deformación: buena', fair: 'Deformación: aceptable', poor: 'Deformación: puede estirar la malla' };
const HEIGHT_REF_M = 1.75; // para mostrar la velocidad en km/h se supone una persona de 1,75 m
const CLIP_FADE = 0.2; // s: fundido al entrar y salir de una animación importada

const note = (kind, text) => h('p', { class: `note note--${kind}` }, icon(kind === 'warn' ? 'warn' : 'eye', 18), h('span', null, text));

export function openRigStudio({ store, model: initial, layers, profile, onModel }) {
  let model = initial;
  let closed = false;
  let viewer = null;
  let built = null;
  let animator = null;
  let record = null; // registro de rig vigente
  let quality = null;
  let yawOffset = 0;
  let busy = false;
  let animBusy = false;
  let clips = []; // animaciones importadas ya adaptadas a este esqueleto (se guardan junto al rig)
  let player = null; // reproductor de la animación importada en curso
  let playingIdx = -1;
  let fadeFrom = null;
  let fadeT = 0;
  let lastShown = null;
  let travel = 0; // distancia que ha «recorrido» la cinta para desplazar el suelo
  const ctl = new AbortController();
  let preview = null;

  // ── Estado del visor ──────────────────────────────────────────────────────────────────────
  const statusIcon = h('span', { class: 'spinner', 'aria-hidden': 'true' });
  const statusText = h('p', { class: 'viewer-status__text' }, 'Preparando…');
  const statusBar = h('div', { class: 'progress progress--thin' }, h('i'));
  const retryBtn = h('button', { class: 'btn btn--ghost', type: 'button', hidden: true, onclick: () => load() }, 'Reintentar');
  const status = h('div', { class: 'viewer-status', role: 'status' }, statusIcon, statusText, statusBar, retryBtn);
  const host = h('div', { class: 'viewer-host viewer-host--studio' }, status);

  function setStatus(text, p, { error = false } = {}) {
    status.hidden = false;
    status.classList.toggle('is-error', error);
    statusIcon.hidden = error;
    statusBar.hidden = error || p == null;
    retryBtn.hidden = !error;
    statusText.textContent = text;
    if (p != null) statusBar.firstChild.style.transform = `scaleX(${Math.min(1, Math.max(0, p))})`;
  }

  // ── Controles ─────────────────────────────────────────────────────────────────────────────
  const gaits = [
    ['idle', 'Quieto', () => 0],
    ['walk', 'Caminar', (s) => s.walk],
    ['trot', 'Trotar', (s) => s.trot],
    ['run', 'Correr', (s) => s.run],
    ['sprint', 'Sprint', (s) => s.sprint],
  ];
  const gaitBtns = new Map();
  const speedLabel = h('span', { class: 'studio__value mono' }, '0 km/h');
  const speedInput = h('input', { class: 'range', type: 'range', min: '0', max: '100', step: '1', value: '0', 'aria-label': 'Velocidad de movimiento', oninput: () => onSlider() });
  const gaitRow = h('div', { class: 'viewer-tools', role: 'group', 'aria-label': 'Tipo de movimiento' });
  for (const [key, label, speedOf] of gaits) {
    const b = h('button', { class: 'chip-btn', type: 'button', 'aria-pressed': 'false', onclick: () => chooseGait(key, speedOf) }, label);
    gaitBtns.set(key, b);
    gaitRow.append(b);
  }
  const actionRow = h('div', { class: 'viewer-tools', role: 'group', 'aria-label': 'Acciones' });
  const jumpBtn = h('button', { class: 'chip-btn', type: 'button', onclick: () => { stopClip(); animator?.jump(); } }, icon('upload', 18), 'Saltar');
  const waveBtn = h('button', { class: 'chip-btn', type: 'button', onclick: () => { stopClip(); animator?.wave(); } }, icon('person', 18), 'Saludar');
  const boneBtn = h('button', { class: 'chip-btn', type: 'button', 'aria-pressed': 'false', onclick: () => toggle(boneBtn, (on) => built?.setSkeletonVisible(on)) }, icon('grid', 18), 'Esqueleto');
  const wireBtn = h('button', { class: 'chip-btn', type: 'button', 'aria-pressed': 'false', onclick: () => toggle(wireBtn, (on) => viewer?.setWireframe(on)) }, icon('cube', 18), 'Malla');
  const frameBtn = h('button', { class: 'chip-btn', type: 'button', onclick: () => viewer?.resetView() }, icon('frame', 18), 'Encuadrar');
  actionRow.append(jumpBtn, waveBtn, boneBtn, wireBtn, frameBtn);

  // Animaciones de otros personajes (Mixamo, VRM…), adaptadas al esqueleto automático.
  const fileInput = h('input', { type: 'file', accept: ANIM_ACCEPT, hidden: true, 'aria-hidden': 'true', tabindex: '-1', onchange: () => onAnimFile() });
  const loadAnimBtn = h('button', { class: 'btn btn--ghost', type: 'button', onclick: () => fileInput.click() }, icon('upload', 18), 'Cargar animación (FBX/GLB)');
  const animLine = h('p', { class: 'hint', hidden: true, role: 'status' });
  const clipRow = h('div', { class: 'viewer-tools', role: 'group', 'aria-label': 'Animaciones importadas', hidden: true });
  const clearClipsBtn = h('button', { class: 'btn btn--danger-ghost', type: 'button', hidden: true, onclick: () => dropClips() }, icon('trash', 18), 'Quitar animaciones importadas');

  const rotBtn = h('button', { class: 'btn btn--ghost', type: 'button', onclick: () => rotate() }, icon('refresh', 18), 'Girar 90°');
  const refitBtn = h('button', { class: 'btn btn--ghost', type: 'button', onclick: () => refit() }, icon('sliders', 18), 'Reajustar');
  const dropBtn = h('button', { class: 'btn btn--danger-ghost', type: 'button', hidden: true, onclick: () => dropRig() }, icon('trash', 18), 'Quitar esqueleto guardado');
  const controls = h(
    'div',
    { class: 'studio', hidden: true },
    h('p', { class: 'studio__label' }, 'Movimiento'),
    gaitRow,
    h('div', { class: 'studio__speed' }, h('label', { class: 'studio__label', for: 'rig-speed' }, 'Velocidad'), speedLabel),
    speedInput,
    h('p', { class: 'studio__label' }, 'Acciones y vista'),
    actionRow,
    h('p', { class: 'studio__label' }, 'Animaciones de otros personajes'),
    loadAnimBtn,
    fileInput,
    animLine,
    clipRow,
    clearClipsBtn,
    h('p', { class: 'studio__label' }, 'Esqueleto'),
    h('div', { class: 'detail__row' }, rotBtn, refitBtn),
    dropBtn,
  );
  speedInput.id = 'rig-speed';
  const notesBox = h('div', { class: 'notes' });
  const savedLine = h('p', { class: 'hint', hidden: true });

  function toggle(b, fn) {
    const on = b.getAttribute('aria-pressed') !== 'true';
    b.setAttribute('aria-pressed', String(on));
    fn(on);
  }

  const kmh = (v) => (v / (record?.rig?.height || HEIGHT_REF_M)) * HEIGHT_REF_M * 3.6;
  function paintSpeed(v) {
    speedLabel.textContent = `${kmh(v).toFixed(v < 0.01 ? 0 : 1)} km/h`;
  }
  function chooseGait(key, speedOf) {
    if (!animator) return;
    stopClip();
    const v = speedOf(animator.speeds);
    animator.setSpeed(v);
    speedInput.value = String(Math.round((v / animator.speeds.sprint) * 100));
    paintSpeed(v);
    paintGait(key);
  }
  function onSlider() {
    if (!animator) return;
    stopClip();
    const v = (Number(speedInput.value) / 100) * animator.speeds.sprint;
    animator.setSpeed(v);
    paintSpeed(v);
    paintGait(null);
  }
  function paintGait(key) {
    for (const [k, b] of gaitBtns) b.setAttribute('aria-pressed', String(k === key));
  }

  function paintNotes() {
    clear(notesBox);
    if (!record) return;
    if (quality) notesBox.append(note(quality.level === 'poor' ? 'warn' : 'info', `${QUALITY_LABEL[quality.level]}${quality.level === 'good' ? '' : ` (${quality.severePct.toFixed(2)} % de aristas muy estiradas)`}.`));
    for (const n of describeRig(record, quality)) notesBox.append(note(n.kind, n.text));
    if (model.stats?.hasSkeleton || model.stats?.animations) {
      notesBox.append(note('info', 'El modelo ya traía esqueleto o animaciones; aquí se usa solo su geometría con el esqueleto automático.'));
    }
  }

  // ── Carga y ajuste ────────────────────────────────────────────────────────────────────────
  // Calcula pesos y calidad para un registro y deja listos los datos del visor.
  async function prepare(rec, base) {
    const meshes = orientMeshes(base.meshes, rec.rig);
    setStatus('Calculando pesos de la malla…', 0);
    const { weights, quality: q } = await skinInBackground(meshes, rec.rig, { signal: ctl.signal, onProgress: (p) => !closed && setStatus('Calculando pesos de la malla…', p) });
    return { meshes, weights, quality: q };
  }

  const builderFor = (prep) => (THREE) => buildRiggedPreview(THREE, { ...preview, meshes: prep.meshes }, record.rig, prep.weights, { texMax: profile.tier === 'low' ? 1024 : 2048 });

  function startAnimation() {
    animator = createAnimator(record.rig);
    travel = 0;
    viewer.tick = tick;
    built.applyPose(animator.update(0).pose);
    viewer.requestRender();
    paintGait(null);
    speedInput.value = '0';
    paintSpeed(0);
    chooseGait('idle', () => 0);
  }

  // Funde desde la última pose mostrada (al empezar o terminar una animación importada) para que no haya saltos.
  function startFade() {
    fadeFrom = lastShown ? clonePose(lastShown) : null;
    fadeT = 0;
  }
  function paintClips() {
    clear(clipRow);
    clips.forEach((c, i) => {
      const b = h('button', { class: 'chip-btn', type: 'button', 'aria-pressed': String(i === playingIdx), title: `${c.duration.toFixed(1)} s${c.loop ? ' · se repite' : ''}`, onclick: () => (i === playingIdx ? backToIdle() : playClip(i)) }, c.label || c.name);
      clipRow.append(b);
    });
    clipRow.hidden = clips.length === 0;
    clearClipsBtn.hidden = clips.length === 0;
  }
  function playClip(i) {
    if (!animator || !clips[i]) return;
    player = createClipPlayer(clips[i]);
    playingIdx = i;
    startFade();
    paintGait(null);
    paintClips();
  }
  function stopClip() {
    if (!player) return;
    player = null;
    playingIdx = -1;
    startFade();
    paintClips();
  }
  function backToIdle() {
    chooseGait('idle', () => 0);
  }

  function tick(dt) {
    if (!animator || !built) return false;
    let r;
    if (player) {
      r = player.update(dt);
      if (r.done) {
        // Una animación de una sola vez termina: se vuelve al reposo (con fundido).
        const last = r.pose;
        backToIdle();
        lastShown = last;
        startFade();
        r = animator.update(dt);
      }
    } else r = animator.update(dt);
    let pose = r.pose;
    if (fadeFrom && fadeT < CLIP_FADE) {
      fadeT += dt;
      pose = blendPose(fadeFrom, pose, smoothstep(0, 1, fadeT / CLIP_FADE));
      if (fadeT >= CLIP_FADE) fadeFrom = null;
    }
    lastShown = pose;
    built.applyPose(pose);
    // Suelo tipo cinta: se desplaza hacia atrás a la velocidad real del ciclo, así los pies se ven fijos al suelo.
    if (viewer.grid && r.groundSpeed > 0) {
      const cell = (viewer.built.radius * 4) / 16;
      travel = (travel + r.groundSpeed * dt) % cell;
      viewer.grid.position.z = -travel;
    }
    return true;
  }

  async function persist() {
    try {
      await store.saveRig(model.id, { ...record, clips, quality: { level: quality.level, severePct: quality.severePct } });
      model = await store.updateModel(model.id, { rig: { poseType: record.poseType, confidence: record.confidence, level: quality.level, createdAt: record.createdAt } }, { touch: false });
      onModel?.(model);
      savedLine.hidden = false;
      savedLine.textContent = store.persistent ? 'Esqueleto guardado en este dispositivo.' : 'Esqueleto listo (el almacenamiento del navegador no está disponible: no se conservará al cerrar).';
      dropBtn.hidden = false;
    } catch (err) {
      console.warn('[rig] no se pudo guardar', err);
      savedLine.hidden = false;
      savedLine.textContent = 'No se pudo guardar el esqueleto; seguirá funcionando mientras no cierres esta ventana.';
    }
  }

  async function load() {
    if (viewer) {
      viewer.dispose();
      viewer = null;
      built = null;
      animator = null;
    }
    controls.hidden = true;
    clear(notesBox);
    savedLine.hidden = true;
    player = null;
    playingIdx = -1;
    fadeFrom = null;
    lastShown = null;
    if (!profile.webgl.ok) {
      setStatus('Este dispositivo no ofrece WebGL 2, así que no se puede mostrar el personaje.', null, { error: true });
      retryBtn.hidden = true;
      return;
    }
    try {
      setStatus('Analizando modelo…', 0);
      const result = await loadPreviewFor(store, model, { signal: ctl.signal, onProgress: (p) => !closed && setStatus('Analizando modelo…', p) });
      if (closed) return;
      preview = result.preview;
      const saved = await store.getRig(model.id);
      if (isRigCompatible(saved)) {
        record = saved;
        yawOffset = saved.options?.yawOffset || 0;
        quality = null;
        clips = (saved.clips || []).filter(isClipValid);
      } else {
        clips = [];
        setStatus('Detectando esqueleto…', 0);
        record = await fitRigInBackground(preview.meshes, { yawOffset }, { signal: ctl.signal, onProgress: (p) => !closed && setStatus('Detectando esqueleto…', p) });
        if (closed) return;
      }
      const prep = await prepare(record, preview);
      if (closed) return;
      quality = prep.quality;
      setStatus('Preparando vista 3D…', 1);
      const v = new PreviewViewer(host, {
        pixelRatioCap: settings.get('pixelRatioCap'),
        antialias: profile.antialias,
        gridColor: getComputedStyle(host).getPropertyValue('--line').trim() || '#7a8a9a',
        reducedMotion: settings.get('reducedMotion'),
      });
      v.onContextLost = () => setStatus('Se perdió el contexto gráfico. Vuelve a intentarlo.', null, { error: true });
      await v.init(preview, {
        builder: async (THREE) => {
          built = await builderFor(prep)(THREE);
          return built;
        },
      });
      if (closed) {
        v.dispose();
        return;
      }
      viewer = v;
      status.hidden = true;
      controls.hidden = false;
      startAnimation();
      paintNotes();
      paintClips();
      if (!saved || !isRigCompatible(saved)) await persist();
      else {
        savedLine.hidden = false;
        savedLine.textContent = 'Esqueleto cargado del dispositivo.';
        dropBtn.hidden = false;
      }
    } catch (err) {
      if (closed || err?.name === 'AbortError') return;
      console.error('[estudio]', err);
      setStatus(err?.message || 'No se pudo preparar el personaje.', null, { error: true });
    }
  }

  // Vuelve a ajustar el esqueleto (con otro giro) y reconstruye el personaje sin recargar el visor.
  async function refitWith(offset) {
    if (busy || !viewer || closed) return;
    busy = true;
    for (const b of [rotBtn, refitBtn]) b.disabled = true;
    const prevTick = viewer.tick;
    viewer.tick = null;
    setStatus('Ajustando esqueleto…', 0);
    try {
      const rec = await fitRigInBackground(preview.meshes, { yawOffset: offset }, { signal: ctl.signal, onProgress: (p) => !closed && setStatus('Ajustando esqueleto…', p) });
      if (closed) return;
      const prep = await prepare(rec, preview);
      if (closed) return;
      record = rec;
      yawOffset = offset;
      quality = prep.quality;
      const hadClips = clips.length > 0;
      clips = []; // las animaciones se adaptaron al esqueleto anterior
      player = null;
      playingIdx = -1;
      await viewer.replaceWith(async (THREE) => {
        built = await builderFor(prep)(THREE);
        return built;
      });
      if (closed) return;
      status.hidden = true;
      startAnimation();
      paintNotes();
      paintClips();
      await persist();
      if (hadClips) toast('Se quitaron las animaciones importadas: el esqueleto cambió y habría que adaptarlas de nuevo.');
    } catch (err) {
      if (closed || err?.name === 'AbortError') return;
      console.error('[estudio] reajuste', err);
      toast(err?.message || 'No se pudo reajustar el esqueleto.', { kind: 'error' });
      status.hidden = true;
      viewer.tick = prevTick;
    } finally {
      busy = false;
      for (const b of [rotBtn, refitBtn]) b.disabled = false;
    }
  }
  const rotate = () => refitWith(yawOffset + Math.PI / 2);
  const refit = () => refitWith(0);

  // Carga un FBX/GLB con una animación y la adapta a este esqueleto.
  async function onAnimFile() {
    const file = fileInput.files?.[0];
    fileInput.value = '';
    if (!file || animBusy || !record || closed) return;
    if (clips.length >= RETARGET_LIMITS.maxClips) {
      toast(`Ya hay ${RETARGET_LIMITS.maxClips} animaciones importadas. Quita alguna para añadir otra.`, { kind: 'error' });
      return;
    }
    animBusy = true;
    loadAnimBtn.disabled = true;
    animLine.hidden = false;
    animLine.textContent = 'Leyendo animación…';
    try {
      const { source, clips: raw, label } = await readAnimationFile(file, { onProgress: (p) => !closed && (animLine.textContent = `Leyendo animación… ${Math.round(p * 100)} %`) });
      if (closed) return;
      animLine.textContent = 'Adaptando al esqueleto…';
      await new Promise((r) => setTimeout(r, 30)); // deja pintar el aviso antes del cálculo
      const rt = createRetargeter(record.rig, source);
      const added = [];
      let firstError = null;
      for (const c of raw) {
        if (clips.length + added.length >= RETARGET_LIMITS.maxClips) break;
        try {
          const baked = rt.bake(c, { inPlace: true });
          const tag = raw.length > 1 ? `${label} · ${c.name}` : label;
          baked.label = tag.length > 28 ? `${tag.slice(0, 27)}…` : tag;
          added.push(baked);
        } catch (err) {
          firstError = firstError || err;
        }
      }
      if (!added.length) throw firstError || new Error('No se pudo adaptar ninguna animación del archivo.');
      clips = clips.concat(added);
      paintClips();
      await persist();
      const lost = rt.missingOptional.filter((n) => /Hand|Shoulder|Chest|Neck|Head|Spine/.test(n));
      animLine.textContent = `${added.length === 1 ? 'Animación lista' : `${added.length} animaciones listas`}${lost.length ? ` (el archivo no tiene: ${lost.join(', ')}; esos huesos siguen a su padre)` : ''}.`;
      playClip(clips.length - added.length);
    } catch (err) {
      if (closed) return;
      console.warn('[estudio] animación', err);
      animLine.hidden = true;
      toast(err?.message || 'No se pudo usar la animación.', { kind: 'error' });
    } finally {
      animBusy = false;
      loadAnimBtn.disabled = false;
    }
  }

  async function dropClips() {
    clips = [];
    backToIdle();
    paintClips();
    animLine.hidden = false;
    animLine.textContent = 'Animaciones importadas eliminadas.';
    try {
      await persist();
    } catch (err) {
      toast(err?.message || 'No se pudo guardar el cambio.', { kind: 'error' });
    }
  }

  async function dropRig() {
    try {
      await store.deleteRig(model.id);
      model = await store.updateModel(model.id, { rig: null }, { touch: false });
      onModel?.(model);
      clips = [];
      stopClip();
      paintClips();
      dropBtn.hidden = true;
      savedLine.hidden = false;
      savedLine.textContent = 'Esqueleto guardado eliminado. Se volverá a detectar la próxima vez.';
    } catch (err) {
      toast(err?.message || 'No se pudo eliminar el esqueleto guardado.', { kind: 'error' });
    }
  }

  const body = h(
    'div',
    { class: 'detail' },
    h('div', { class: 'viewer-wrap' }, host),
    controls,
    savedLine,
    notesBox,
    h('p', { class: 'hint' }, 'Un dedo gira la cámara y dos dedos acercan. Si el personaje sale de lado o de espaldas, usa «Girar 90°».'),
  );

  const sheet = openSheet({
    title: `Personaje · ${model.name}`,
    body,
    layers,
    tall: true,
    onClose: () => {
      closed = true;
      ctl.abort();
      if (viewer) viewer.tick = null;
      viewer?.dispose();
      viewer = null;
      built = null;
      animator = null;
    },
  });
  load();
  return sheet;
}
