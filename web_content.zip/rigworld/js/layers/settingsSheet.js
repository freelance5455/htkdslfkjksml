// Ajustes: calidad de la vista previa, almacenamiento y datos del dispositivo.
import { h, icon, clear } from '../ui/dom.js';
import { openSheet, confirmDialog } from '../ui/sheet.js';
import { toast } from '../ui/toast.js';
import { settings } from '../core/settings.js';
import { fmtBytes, fmtCount } from '../core/format.js';
import { storageEstimate, requestPersistence } from '../storage/db.js';
import { workerState } from '../import/client.js';
import { forgetPreview } from '../import/importer.js';
import { APP, LIMITS } from '../config.js';

const TIER = { low: 'Básica', mid: 'Media', high: 'Alta' };

function slider({ id, label, help, min, max, step, value, format, onCommit }) {
  const out = h('output', { class: 'mono', for: id }, format(value));
  const input = h('input', { class: 'range', id, type: 'range', min, max, step, value });
  input.addEventListener('input', () => {
    out.textContent = format(Number(input.value));
  });
  input.addEventListener('change', () => onCommit(Number(input.value)));
  return h('div', { class: 'setting' }, h('div', { class: 'setting__head' }, h('label', { for: id }, label), out), input, h('p', { class: 'hint' }, help));
}

export function openSettings({ store, layers, profile, onLibraryChanged, onActiveChange }) {
  const storageBox = h('div', { class: 'storage-box' });

  async function paintStorage() {
    const models = await store.listModels();
    const libBytes = models.reduce((s, m) => s + m.totalBytes, 0);
    const est = await storageEstimate();
    clear(storageBox);
    const pct = est && est.quota ? Math.min(1, est.usage / est.quota) : 0;
    storageBox.append(
      h('p', { class: 'storage-box__line' }, h('strong', null, `${models.length} ${models.length === 1 ? 'modelo' : 'modelos'}`), ` · ${fmtBytes(libBytes)} en la biblioteca`),
      est
        ? h('div', null, h('div', { class: 'progress progress--thin', role: 'img', 'aria-label': `Almacenamiento usado: ${Math.round(pct * 100)} %` }, h('i', { style: { transform: `scaleX(${Math.max(0.01, pct)})` } })), h('p', { class: 'hint' }, `El navegador permite ${fmtBytes(est.quota)} a esta app y ya usa ${fmtBytes(est.usage)}.`))
        : h('p', { class: 'hint' }, 'Este navegador no informa del espacio disponible.'),
      store.persistent ? null : h('p', { class: 'note note--warn' }, icon('warn', 18), h('span', null, 'El almacenamiento del navegador no está disponible: los modelos se pierden al cerrar la pestaña.')),
    );
  }
  paintStorage();

  const persistBtn = h(
    'button',
    {
      class: 'btn btn--ghost',
      type: 'button',
      onclick: async () => {
        const ok = await requestPersistence();
        toast(ok ? 'Almacenamiento persistente concedido.' : 'El navegador no concedió almacenamiento persistente. Puede borrar los datos si falta espacio.', { kind: ok ? 'ok' : 'info' });
      },
    },
    'Proteger mis modelos',
  );

  const wipeBtn = h(
    'button',
    {
      class: 'btn btn--danger-ghost',
      type: 'button',
      onclick: async () => {
        const models = await store.listModels();
        if (!models.length) return toast('La biblioteca ya está vacía.');
        const ok = await confirmDialog({ title: 'Borrar la biblioteca', message: `Se eliminarán ${models.length} modelos y todos sus archivos. Esta acción no se puede deshacer.`, confirmLabel: 'Borrar todo', danger: true, layers });
        if (!ok) return;
        for (const m of models) {
          await store.deleteModel(m.id);
          forgetPreview(m.id);
        }
        await onActiveChange(null);
        onLibraryChanged();
        paintStorage();
        toast('Biblioteca vacía.', { kind: 'ok' });
      },
    },
    icon('trash', 18),
    'Borrar toda la biblioteca',
  );

  const reduce = h('input', { id: 'set-reduce', class: 'switch', type: 'checkbox', checked: settings.get('reducedMotion') });
  reduce.addEventListener('change', () => settings.update({ reducedMotion: reduce.checked }));

  const w = workerState();
  const info = [
    ['Gama del dispositivo', TIER[profile.tier]],
    ['Núcleos / memoria', `${profile.cores} / ${profile.memGB} GB`],
    ['WebGL 2', profile.webgl.ok ? 'Disponible' : 'No disponible'],
    ['Importación', w.broken ? 'En el hilo principal' : 'En segundo plano'],
    ['Fragmentos de guardado', fmtBytes(LIMITS.chunkBytes)],
    ['Versión', `${APP.name} ${APP.version} · Fase ${APP.fase}`],
  ];

  const body = h(
    'div',
    { class: 'settings' },
    h(
      'section',
      { class: 'settings__group' },
      h('h3', null, 'Vista previa'),
      slider({
        id: 'set-tris',
        label: 'Triángulos máximos',
        help: 'Si un modelo tiene más, la vista previa se simplifica. El archivo original se guarda completo.',
        min: 20000,
        max: 600000,
        step: 10000,
        value: settings.get('budgetTris'),
        format: (v) => `${fmtCount(v)} triáng.`,
        onCommit: (v) => settings.update({ budgetTris: v }).then(() => toast('Se aplicará al abrir cada modelo.')),
      }),
      slider({
        id: 'set-dpr',
        label: 'Resolución del visor',
        help: 'Menos resolución ahorra batería y mejora la fluidez.',
        min: 1,
        max: 2,
        step: 0.25,
        value: settings.get('pixelRatioCap'),
        format: (v) => `${v.toFixed(2).replace(/0$/, '')}×`,
        onCommit: (v) => settings.update({ pixelRatioCap: v }),
      }),
      h('div', { class: 'setting setting--switch' }, h('label', { for: 'set-reduce' }, 'Reducir animaciones', h('span', { class: 'hint' }, 'Detiene el giro automático y los efectos de inicio.')), reduce),
    ),
    h('section', { class: 'settings__group' }, h('h3', null, 'Almacenamiento'), storageBox, h('div', { class: 'detail__row' }, persistBtn, wipeBtn)),
    h('section', { class: 'settings__group' }, h('h3', null, 'Este dispositivo'), h('dl', { class: 'stats' }, info.map(([k, v]) => h('div', { class: 'stats__row' }, h('dt', null, k), h('dd', null, v))))),
  );

  return openSheet({ title: 'Ajustes', body, layers, tall: true });
}
