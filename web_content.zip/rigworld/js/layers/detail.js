// Detalle de un modelo de la biblioteca: vista previa 3D, estadísticas y acciones.
import { h, icon, clear } from '../ui/dom.js';
import { openSheet, confirmDialog, promptDialog } from '../ui/sheet.js';
import { toast } from '../ui/toast.js';
import { PreviewViewer } from '../ui/viewer3d.js';
import { loadPreviewFor, forgetPreview } from '../import/importer.js';
import { fmtBytes, fmtCount, fmtNum, fmtDate, fmtDim } from '../core/format.js';
import { FORMAT_LABEL } from '../import/formats.js';
import { settings } from '../core/settings.js';
import { openRigStudio } from './rigStudio.js';

// Por encima de esto la vista completa puede cerrar el navegador en un móvil: se pide confirmación.
const FULL_VIEW_CONFIRM_TRIS = 2_000_000;

function statRows(model) {
  const s = model.stats || {};
  const rows = [
    ['Formato', FORMAT_LABEL[model.format] || model.format.toUpperCase()],
    ['Triángulos', s.triangles != null ? fmtNum(s.triangles) : '—'],
    ['Vértices', s.vertices != null ? fmtNum(s.vertices) : '—'],
    ['Mallas', fmtNum(s.meshes || 0)],
    ['Materiales', fmtNum(s.materials || 0)],
    ['Texturas', fmtNum(s.textures || 0)],
    ['Dimensiones', s.size ? `${fmtDim(s.size[0])} × ${fmtDim(s.size[1])} × ${fmtDim(s.size[2])} u` : '—'],
    ['Esqueleto', s.hasSkeleton ? 'Sí' : 'No (estático)'],
    ['Animaciones', fmtNum(s.animations || 0)],
    ['Tamaño en disco', fmtBytes(model.totalBytes)],
    ['Importado', fmtDate(model.createdAt)],
  ];
  return rows;
}

export function openModelDetail({ store, model: initial, layers, profile, isActive, onChanged, onActiveChange }) {
  let model = initial;
  let active = isActive;
  let closed = false;
  let viewer = null;
  const ctl = new AbortController();

  // ── Zona del visor ────────────────────────────────────────────────────────────────────────
  const statusIcon = h('span', { class: 'spinner', 'aria-hidden': 'true' });
  const statusText = h('p', { class: 'viewer-status__text' }, 'Analizando modelo…');
  const statusBar = h('div', { class: 'progress progress--thin' }, h('i'));
  const retryBtn = h('button', { class: 'btn btn--ghost', type: 'button', hidden: true, onclick: () => load() }, 'Reintentar');
  const status = h('div', { class: 'viewer-status', role: 'status' }, statusIcon, statusText, statusBar, retryBtn);
  const host = h('div', { class: 'viewer-host' }, status);

  const tools = h('div', { class: 'viewer-tools', hidden: true, role: 'toolbar', 'aria-label': 'Controles de la vista 3D' });
  const toggles = {};
  const mkTool = (key, label, ico, onClick, pressed) => {
    const b = h('button', { class: 'chip-btn', type: 'button', 'aria-pressed': pressed === undefined ? undefined : String(pressed), onclick: () => onClick(b) }, icon(ico, 18), label);
    toggles[key] = b;
    return b;
  };
  const toggle = (b, fn) => {
    const on = b.getAttribute('aria-pressed') !== 'true';
    b.setAttribute('aria-pressed', String(on));
    fn(on);
  };
  const fullLabel = document.createTextNode('Vista completa');
  const fullBtn = h('button', { class: 'chip-btn', type: 'button', hidden: true, 'aria-pressed': 'false', onclick: () => toggleFull() }, icon('eye', 18), fullLabel);
  toggles.full = fullBtn;
  tools.append(
    mkTool('reset', 'Encuadrar', 'frame', () => viewer?.resetView()),
    mkTool('wire', 'Malla', 'grid', (b) => toggle(b, (on) => viewer?.setWireframe(on)), false),
    mkTool('floor', 'Suelo', 'cube', (b) => toggle(b, (on) => viewer?.setGrid(on)), true),
    mkTool('spin', 'Girar', 'refresh', (b) => toggle(b, (on) => viewer?.setAutoRotate(on)), false),
    fullBtn,
  );

  function setStatus(text, p, { error = false } = {}) {
    status.hidden = false;
    status.classList.toggle('is-error', error);
    statusIcon.hidden = error;
    statusBar.hidden = error || p == null;
    retryBtn.hidden = !error;
    statusText.textContent = text;
    if (p != null) statusBar.firstChild.style.transform = `scaleX(${Math.min(1, Math.max(0, p))})`;
  }

  const warningsBox = h('div', { class: 'notes' });

  // ── Vista completa: la geometría sin simplificar, con su textura ───────────────────────────
  let showFull = false;
  let fullBusy = false;
  let fullNote = null;
  let simplifiedNotes = []; // avisos que solo valen para la vista simplificada
  function paintFull(busyText) {
    fullLabel.textContent = busyText || (showFull ? 'Vista simplificada' : 'Vista completa');
    fullBtn.setAttribute('aria-pressed', String(showFull));
    fullBtn.disabled = !!busyText;
  }
  async function toggleFull() {
    if (fullBusy || !viewer || closed) return;
    const want = !showFull;
    const tris = model.stats?.triangles || 0;
    if (want && tris > FULL_VIEW_CONFIRM_TRIS) {
      const ok = await confirmDialog({
        title: 'Vista completa',
        message: `Este modelo tiene ${fmtNum(tris)} triángulos. En un móvil la vista completa puede ir muy lenta o cerrar el navegador. ¿Quieres intentarlo?`,
        confirmLabel: 'Intentarlo',
        layers,
      });
      if (!ok || closed) return;
    }
    fullBusy = true;
    paintFull(want ? 'Cargando…' : 'Volviendo…');
    try {
      const result = await loadPreviewFor(store, model, {
        full: want,
        signal: ctl.signal,
        onProgress: (p) => !closed && paintFull(`${want ? 'Cargando' : 'Volviendo'} ${Math.round(p * 100)} %`),
      });
      if (closed) return;
      await viewer.replacePreview(result.preview);
      showFull = want;
      fullNote?.remove();
      fullNote = null;
      for (const n of simplifiedNotes) n.hidden = showFull;
      if (showFull) {
        fullNote = note('info', `Vista completa: ${fmtNum(model.stats.triangles)} triángulos. Si va lenta, vuelve a la vista simplificada.`);
        warningsBox.prepend(fullNote);
      }
    } catch (err) {
      if (closed || err?.name === 'AbortError') return;
      console.error('[detalle] vista completa', err);
      toast(err?.message || 'No se pudo cargar la vista completa.', { kind: 'error' });
    } finally {
      fullBusy = false;
      if (!closed) paintFull();
    }
  }

  async function load() {
    if (viewer) {
      viewer.dispose();
      viewer = null;
    }
    clear(warningsBox);
    tools.hidden = true;
    showFull = false;
    fullNote = null;
    simplifiedNotes = [];
    fullBtn.hidden = true;
    paintFull();
    if (model.stats?.hasSkeleton || model.stats?.animations) {
      warningsBox.append(note('warn', 'Este modelo ya incluye esqueleto o animaciones. Aquí se usa solo su geometría; «Preparar personaje» le crea un esqueleto automático.'));
    }
    if (!profile.webgl.ok) {
      setStatus('Este dispositivo no ofrece WebGL 2, así que no se puede mostrar la vista 3D. Las estadísticas siguen disponibles.', null, { error: true });
      retryBtn.hidden = true;
      return;
    }
    setStatus('Analizando modelo…', 0);
    try {
      const result = await loadPreviewFor(store, model, { onProgress: (p) => !closed && setStatus('Analizando modelo…', p), signal: ctl.signal });
      if (closed) return;
      setStatus('Preparando vista 3D…', 1);
      const v = new PreviewViewer(host, {
        pixelRatioCap: settings.get('pixelRatioCap'),
        antialias: profile.antialias,
        texMax: profile.tier === 'low' ? 1024 : 2048,
        gridColor: getComputedStyle(host).getPropertyValue('--line').trim() || '#7a8a9a',
        reducedMotion: settings.get('reducedMotion'),
      });
      v.onContextLost = () => setStatus('Se perdió el contexto gráfico. Vuelve a intentarlo.', null, { error: true });
      v.onInteract = () => toggles.spin?.setAttribute('aria-pressed', 'false');
      await v.init(result.preview);
      if (closed) {
        v.dispose();
        return;
      }
      viewer = v;
      status.hidden = true;
      tools.hidden = false;
      fullBtn.hidden = !model.stats?.simplified; // solo tiene sentido si la vista previa se simplificó
      for (const w of result.warnings) {
        const n = note('info', w);
        if (/^Vista previa simplificada/.test(w)) simplifiedNotes.push(n);
        warningsBox.append(n);
      }
    } catch (err) {
      if (closed || err?.name === 'AbortError') return;
      console.error('[detalle]', err);
      setStatus(err?.message || 'No se pudo mostrar el modelo.', null, { error: true });
    }
  }

  // ── Estadísticas y acciones ───────────────────────────────────────────────────────────────
  const stats = h('dl', { class: 'stats' });
  function renderStats() {
    clear(stats);
    for (const [k, v] of statRows(model)) stats.append(h('div', { class: 'stats__row' }, h('dt', null, k), h('dd', null, v)));
    if (model.stats?.simplified) {
      stats.append(h('div', { class: 'stats__row' }, h('dt', null, 'Vista previa'), h('dd', null, `${fmtCount(model.stats.previewTriangles)} triáng. (simplificada)`)));
    }
  }
  renderStats();

  const filesList = model.files.length > 1
    ? h('details', { class: 'files' }, h('summary', null, `Archivos guardados (${model.files.length})`), h('ul', null, model.files.map((f) => h('li', null, h('span', null, f.name), h('span', { class: 'mono' }, fmtBytes(f.size))))))
    : null;

  // Esqueleto automático y animación (Capa 3).
  const rigBtn = h('button', { class: 'btn btn--primary btn--block', type: 'button', onclick: () => openStudio() });
  function paintRig() {
    clear(rigBtn);
    rigBtn.append(icon('person', 20), model.rig ? 'Abrir personaje (esqueleto listo)' : 'Preparar personaje (esqueleto automático)');
    rigBtn.disabled = !profile.webgl.ok;
    rigBtn.title = profile.webgl.ok ? '' : 'Este dispositivo no ofrece WebGL 2.';
  }
  paintRig();
  function openStudio() {
    openRigStudio({
      store,
      model,
      layers,
      profile,
      onModel: (m) => {
        model = m;
        paintRig();
        onChanged();
      },
    });
  }

  const activeBtn = h('button', { class: 'btn btn--primary btn--block', type: 'button', onclick: () => setActive() });
  function paintActive() {
    clear(activeBtn);
    activeBtn.append(active ? icon('check', 20) : icon('person', 20), active ? 'Modelo activo (tocar para quitar)' : 'Usar como modelo activo');
    activeBtn.classList.toggle('is-on', active);
  }
  paintActive();
  async function setActive() {
    active = !active;
    paintActive();
    await onActiveChange(active ? model.id : null);
    toast(active ? `«${model.name}» es ahora el modelo activo.` : 'Ya no hay modelo activo.', { kind: 'ok' });
  }

  async function rename() {
    const name = await promptDialog({ title: 'Renombrar modelo', label: 'Nombre', value: model.name, layers });
    if (!name || name === model.name) return;
    try {
      model = await store.updateModel(model.id, { name });
      sheet.el.querySelector('.sheet__title').textContent = model.name;
      onChanged();
    } catch (err) {
      toast(err.message || 'No se pudo renombrar.', { kind: 'error' });
    }
  }

  async function remove() {
    const ok = await confirmDialog({
      title: 'Eliminar modelo',
      message: `Se borrará «${model.name}» y todos sus archivos guardados (${fmtBytes(model.totalBytes)}). Esta acción no se puede deshacer.`,
      confirmLabel: 'Eliminar',
      danger: true,
      layers,
    });
    if (!ok) return;
    try {
      await store.deleteModel(model.id);
      forgetPreview(model.id);
      if (active) await onActiveChange(null);
      toast(`«${model.name}» eliminado.`, { kind: 'ok' });
      onChanged();
      sheet.close();
    } catch (err) {
      toast(err.message || 'No se pudo eliminar.', { kind: 'error' });
    }
  }

  const body = h(
    'div',
    { class: 'detail' },
    h('div', { class: 'viewer-wrap' }, host, tools),
    warningsBox,
    h('p', { class: 'hint' }, 'Un dedo gira, dos dedos acercan y desplazan.'),
    stats,
    filesList,
    h(
      'div',
      { class: 'detail__actions' },
      rigBtn,
      activeBtn,
      h('div', { class: 'detail__row' }, h('button', { class: 'btn btn--ghost', type: 'button', onclick: rename }, icon('edit', 18), 'Renombrar'), h('button', { class: 'btn btn--danger-ghost', type: 'button', onclick: remove }, icon('trash', 18), 'Eliminar')),
    ),
  );

  const sheet = openSheet({
    title: model.name,
    body,
    layers,
    tall: true,
    onClose: () => {
      closed = true;
      ctl.abort();
      viewer?.dispose();
      viewer = null;
    },
  });
  load();
  return sheet;
}

export function note(kind, text) {
  return h('p', { class: `note note--${kind}` }, icon(kind === 'warn' ? 'warn' : 'eye', 18), h('span', null, text));
}
