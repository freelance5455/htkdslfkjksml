// CAPA 2 · Hub de importación: importar, ver el progreso, gestionar la biblioteca y
// elegir el modelo activo que usarán las capas siguientes.
import { h, icon, clear } from '../ui/dom.js';
import { bus } from '../core/bus.js';
import { toast } from '../ui/toast.js';
import { groupSelection, ACCEPT_ATTR, FORMAT_LABEL } from '../import/formats.js';
import { STATUS, thumbOutdated } from '../import/importer.js';
import { openModelDetail, note } from './detail.js';
import { openSettings } from './settingsSheet.js';
import { fmtBytes, fmtCount } from '../core/format.js';
import { LIMITS } from '../config.js';

const ACTIVE_STATES = new Set([STATUS.QUEUED, STATUS.PARSING, STATUS.THUMB, STATUS.SAVING]);
const ACTIVE_KEY = 'activeModel';

export function createHub({ store, importer, layers, profile, notes = [] }) {
  let models = [];
  let activeId = null;
  let rejected = [];
  let rejectedSeq = 1;
  const thumbUrls = new Map(); // «id:marca de la miniatura» → blob URL
  const rows = new Map(); // id de tarea → elementos de la fila
  let latestTasks = [];
  let raf = 0;

  // ── Cabecera ───────────────────────────────────────────────────────────────────────────────
  const summary = h('p', { class: 'summary mono' }, '0 modelos');
  const settingsBtn = h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Ajustes', onclick: openSettingsSheet }, icon('sliders'));
  const bar = h(
    'header',
    { class: 'hub__bar gutter' },
    h('div', { class: 'brand' }, icon('person', 24), h('span', { class: 'brand__name' }, 'RigWorld')),
    summary,
    settingsBtn,
  );

  // ── Avisos del arranque ───────────────────────────────────────────────────────────────────
  const notesBox = h('div', { class: 'notes gutter' }, notes.map((n) => note(n.kind, n.text)));
  notesBox.hidden = notes.length === 0;

  // ── Miniaturas antiguas (creadas sin textura) ──────────────────────────────────────────────
  let thumbBusy = false;
  const thumbText = h('span', null, '');
  const thumbBtn = h('button', { class: 'btn btn--ghost btn--small', type: 'button', onclick: () => refreshThumbs() }, 'Actualizar');
  const thumbBox = h('div', { class: 'notes gutter', hidden: true }, h('div', { class: 'note note--action' }, icon('eye', 18), thumbText, thumbBtn));

  function paintThumbNote() {
    const stale = models.filter((m) => thumbOutdated(m, { webgl: importer.useWebGL }));
    thumbBox.hidden = !thumbBusy && stale.length === 0;
    if (thumbBusy) return;
    thumbText.textContent = stale.length === 1 ? 'Una miniatura se creó sin textura.' : `${stale.length} miniaturas se crearon sin textura.`;
    thumbBtn.disabled = false;
  }

  async function refreshThumbs() {
    if (thumbBusy) return;
    if (importer.activeCount > 0) return toast('Espera a que terminen las importaciones.');
    thumbBusy = true;
    thumbBtn.disabled = true;
    thumbText.textContent = 'Actualizando miniaturas…';
    try {
      const res = await importer.regenerateThumbnails({
        onProgress: ({ done, total }) => (thumbText.textContent = `Actualizando miniaturas… ${done + 1} de ${total}`),
      });
      if (res.improved) toast(res.improved === 1 ? 'Miniatura actualizada.' : `${res.improved} miniaturas actualizadas.`, { kind: 'ok' });
      else if (res.total) toast('No se pudo dibujar la textura. Revisa tu conexión y vuelve a intentarlo.', { kind: 'error' });
    } catch (err) {
      console.error('[hub] miniaturas', err);
      toast('No se pudieron actualizar las miniaturas.', { kind: 'error' });
    } finally {
      thumbBusy = false;
      await refresh();
    }
  }

  // ── Importar ───────────────────────────────────────────────────────────────────────────────
  const input = h('input', {
    id: 'file-input',
    class: 'visually-hidden',
    type: 'file',
    multiple: true,
    accept: ACCEPT_ATTR,
    tabIndex: -1,
    onchange: () => {
      const files = [...input.files];
      input.value = ''; // permite elegir el mismo archivo otra vez
      onFiles(files);
    },
  });
  const pickBtn = h('button', { class: 'btn btn--primary', type: 'button', onclick: () => input.click() }, icon('upload', 20), 'Elegir archivos');
  const sampleBtn = h(
    'button',
    {
      class: 'btn btn--ghost',
      type: 'button',
      onclick: () => {
        importer.enqueueSample();
        toast('Importando el maniquí de ejemplo…');
      },
    },
    icon('person', 20),
    'Probar con el maniquí',
  );
  const drop = h(
    'div',
    { class: 'drop' },
    h('h2', { class: 'section-title', id: 'import-title' }, 'Importar modelos'),
    h('ul', { class: 'formats', 'aria-label': 'Formatos compatibles' }, Object.values(FORMAT_LABEL).map((l) => h('li', null, l))),
    h('p', { class: 'drop__text' }, `Hasta ${LIMITS.maxFileBytes / 1024 / 1024} MB por archivo. Para glTF u OBJ, elige también el .bin, el .mtl y las texturas en la misma selección.`),
    h('div', { class: 'drop__actions' }, pickBtn, sampleBtn),
    h('p', { class: 'drop__hint hint' }, 'También puedes arrastrar los archivos aquí.'),
    input,
  );
  const importSection = h('section', { class: 'import gutter', 'aria-labelledby': 'import-title' }, drop);

  // Arrastrar y soltar (escritorio y tabletas)
  let dragDepth = 0;
  const hasFiles = (e) => [...(e.dataTransfer?.types || [])].includes('Files');
  const hubOnDrag = (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    if (e.type === 'dragenter') dragDepth++;
    if (e.type === 'dragleave') dragDepth = Math.max(0, dragDepth - 1);
    if (e.type === 'drop') dragDepth = 0;
    drop.classList.toggle('is-over', dragDepth > 0);
    if (e.type === 'drop') onFiles([...e.dataTransfer.files]);
  };

  async function onFiles(files) {
    if (!files.length) return;
    let result;
    try {
      result = await groupSelection(files);
    } catch (err) {
      console.error('[hub] selección', err);
      toast('No se pudieron leer los archivos seleccionados.', { kind: 'error' });
      return;
    }
    for (const r of result.rejected) rejected.push({ id: rejectedSeq++, ...r });
    renderRejected();
    if (result.groups.length) {
      const { accepted, overflow } = importer.enqueue(result.groups);
      if (accepted) toast(accepted === 1 ? 'Importando 1 modelo…' : `Importando ${accepted} modelos…`);
      if (overflow) toast(`Solo caben ${LIMITS.maxPending} importaciones a la vez. ${overflow} no entraron en la cola.`, { kind: 'error' });
    } else if (!result.rejected.length) toast('No se seleccionó ningún archivo.');
  }

  // ── Cola de importación ────────────────────────────────────────────────────────────────────
  const clearBtn = h('button', { class: 'btn btn--ghost btn--small', type: 'button', onclick: () => { importer.clearFinished(); rejected = []; renderRejected(); } }, 'Limpiar');
  const taskList = h('ul', { class: 'queue__list' });
  const rejectedList = h('ul', { class: 'rejected' });
  const queueSection = h(
    'section',
    { class: 'queue gutter', 'aria-labelledby': 'queue-title', hidden: true },
    h('div', { class: 'section-head' }, h('h2', { class: 'section-title', id: 'queue-title' }, 'Importaciones'), clearBtn),
    taskList,
    rejectedList,
  );

  function buildRow(task) {
    const badge = h('span', { class: 'badge' }, FORMAT_LABEL[task.format] || task.format.toUpperCase());
    const name = h('span', { class: 'task__name' }, task.name);
    const size = h('span', { class: 'task__size mono' }, fmtBytes(task.sizeBytes));
    const fill = h('i');
    const barEl = h('div', { class: 'progress', role: 'progressbar', 'aria-valuemin': 0, 'aria-valuemax': 100, 'aria-valuenow': 0, 'aria-label': `Progreso de ${task.name}` }, fill);
    const msg = h('span', { class: 'task__msg' });
    const pct = h('span', { class: 'task__pct mono' });
    const btn = h('button', { class: 'btn btn--ghost btn--small', type: 'button' });
    const err = h('p', { class: 'task__error', role: 'alert', hidden: true });
    const warn = h('details', { class: 'task__warn', hidden: true });
    const li = h(
      'li',
      { class: 'task' },
      h('div', { class: 'task__head' }, badge, name, size),
      barEl,
      h('div', { class: 'task__foot' }, msg, pct, btn),
      err,
      warn,
    );
    return { li, fill, barEl, msg, pct, btn, err, warn, warnKey: '' };
  }

  function updateRow(row, task) {
    row.li.className = `task task--${task.status}`;
    const pctNum = Math.round(task.progress * 100);
    row.fill.style.transform = `scaleX(${task.progress})`;
    row.barEl.setAttribute('aria-valuenow', String(pctNum));
    row.msg.textContent = task.message;
    const active = ACTIVE_STATES.has(task.status);
    row.pct.textContent = active ? `${pctNum} %` : task.status === STATUS.DONE ? '' : '';
    row.err.hidden = !task.error;
    row.err.textContent = task.error || '';
    row.btn.hidden = false;
    if (active) {
      row.btn.textContent = 'Cancelar';
      row.btn.onclick = () => importer.cancel(task.id);
    } else if (task.canRetry) {
      row.btn.textContent = 'Reintentar';
      row.btn.onclick = () => importer.retry(task.id);
    } else if (task.status === STATUS.DONE && task.modelId) {
      row.btn.textContent = 'Ver';
      row.btn.onclick = () => openDetail(task.modelId);
    } else row.btn.hidden = true;

    const key = (task.warnings || []).join('|');
    if (key !== row.warnKey) {
      row.warnKey = key;
      clear(row.warn);
      row.warn.hidden = !key;
      if (key) {
        row.warn.append(h('summary', null, `${task.warnings.length} ${task.warnings.length === 1 ? 'aviso' : 'avisos'}`), h('ul', null, task.warnings.map((w) => h('li', null, w))));
      }
    }
  }

  function renderTasks(list) {
    latestTasks = list;
    const seen = new Set();
    for (const task of list) {
      seen.add(task.id);
      let row = rows.get(task.id);
      if (!row) {
        row = buildRow(task);
        rows.set(task.id, row);
        taskList.append(row.li);
      }
      updateRow(row, task);
    }
    for (const [id, row] of rows) {
      if (!seen.has(id)) {
        row.li.remove();
        rows.delete(id);
      }
    }
    syncQueueVisibility();
  }

  function renderRejected() {
    clear(rejectedList);
    for (const r of rejected) {
      rejectedList.append(
        h(
          'li',
          { class: 'rejected__item' },
          icon('warn', 18),
          h('div', { class: 'rejected__text' }, h('strong', null, r.name), h('span', null, r.reason)),
          h('button', { class: 'icon-btn icon-btn--small', type: 'button', 'aria-label': `Descartar aviso de ${r.name}`, onclick: () => { rejected = rejected.filter((x) => x.id !== r.id); renderRejected(); } }, icon('close', 18)),
        ),
      );
    }
    syncQueueVisibility();
  }

  function syncQueueVisibility() {
    const finished = latestTasks.some((t) => !ACTIVE_STATES.has(t.status));
    queueSection.hidden = latestTasks.length === 0 && rejected.length === 0;
    clearBtn.hidden = !finished && rejected.length === 0;
  }

  bus.on('import:tasks', (list) => {
    latestTasks = list;
    if (!raf) {
      raf = requestAnimationFrame(() => {
        raf = 0;
        renderTasks(latestTasks);
      });
    }
  });

  // ── Biblioteca ─────────────────────────────────────────────────────────────────────────────
  const libCount = h('span', { class: 'section-count mono' });
  const grid = h('ul', { class: 'grid' });
  const empty = h(
    'div',
    { class: 'empty' },
    icon('cube', 40),
    h('p', { class: 'empty__title' }, 'Todavía no hay modelos'),
    h('p', { class: 'hint' }, 'Importa un archivo o prueba con el maniquí de ejemplo. Los modelos se guardan en este dispositivo.'),
  );
  const librarySection = h(
    'section',
    { class: 'library gutter', 'aria-labelledby': 'lib-title' },
    h('div', { class: 'section-head' }, h('h2', { class: 'section-title', id: 'lib-title' }, 'Biblioteca'), libCount),
    grid,
    empty,
  );

  function thumbUrl(m) {
    if (!m.thumb) return null;
    const key = `${m.id}:${m.thumbStamp ?? m.updatedAt}`;
    let url = thumbUrls.get(key);
    if (!url) {
      url = URL.createObjectURL(new Blob([m.thumb.data], { type: m.thumb.type }));
      thumbUrls.set(key, url);
    }
    return url;
  }

  function renderLibrary() {
    const keep = new Set(models.map((m) => `${m.id}:${m.thumbStamp ?? m.updatedAt}`));
    for (const [key, url] of thumbUrls) {
      if (!keep.has(key)) {
        URL.revokeObjectURL(url);
        thumbUrls.delete(key);
      }
    }
    clear(grid);
    for (const m of models) {
      const url = thumbUrl(m);
      const fmt = FORMAT_LABEL[m.format] || m.format.toUpperCase();
      const meta = [`${fmtCount(m.stats?.triangles || 0)} tri`, fmtBytes(m.totalBytes)].join(' · ');
      const isActive = m.id === activeId;
      grid.append(
        h(
          'li',
          null,
          h(
            'button',
            { class: `card${isActive ? ' is-active' : ''}`, type: 'button', 'aria-label': `${m.name}${isActive ? ' (modelo activo)' : ''}${m.rig ? ', con esqueleto' : ''}. ${fmt}, ${meta}`, onclick: () => openDetail(m.id) },
            h('span', { class: 'card__thumb' }, url ? h('img', { src: url, alt: '', width: 256, height: 256, decoding: 'async' }) : icon('cube', 36), isActive ? h('span', { class: 'card__flag' }, 'Activo') : null, m.rig ? h('span', { class: 'card__rig' }, 'Rig') : null, h('span', { class: 'card__fmt badge' }, fmt)),
            h('span', { class: 'card__body' }, h('span', { class: 'card__name' }, m.name), h('span', { class: 'card__meta mono' }, meta)),
          ),
        ),
      );
    }
    empty.hidden = models.length > 0;
    grid.hidden = models.length === 0;
    libCount.textContent = models.length ? String(models.length) : '';
    const total = models.reduce((s, m) => s + m.totalBytes, 0);
    summary.textContent = `${models.length} ${models.length === 1 ? 'modelo' : 'modelos'} · ${fmtBytes(total)}`;
    paintActiveBar();
    paintThumbNote();
  }

  // ── Modelo activo ──────────────────────────────────────────────────────────────────────────
  const activeName = h('strong', { class: 'activebar__name' });
  const activeHint = h('span', { class: 'hint' });
  const activeBar = h(
    'div',
    { class: 'activebar gutter', hidden: true },
    h('span', { class: 'activebar__dot', 'aria-hidden': 'true' }),
    h('p', { class: 'activebar__text' }, 'Modelo activo: ', activeName, activeHint),
  );

  function paintActiveBar() {
    const m = models.find((x) => x.id === activeId);
    activeBar.hidden = !m;
    if (m) {
      activeName.textContent = m.name;
      activeHint.textContent = m.rig ? ' Ábrelo para verlo caminar y correr.' : ' Ábrelo para preparar su esqueleto y verlo caminar.';
    }
  }

  async function setActive(id) {
    activeId = id;
    try {
      await store.setSetting(ACTIVE_KEY, id);
    } catch (err) {
      console.warn('[hub] no se pudo guardar el modelo activo', err);
    }
    renderLibrary();
  }

  async function refresh() {
    try {
      models = await store.listModels();
      activeId = await store.getSetting(ACTIVE_KEY, null);
    } catch (err) {
      console.error('[hub] biblioteca', err);
      toast('No se pudo leer la biblioteca.', { kind: 'error' });
      models = [];
    }
    if (activeId && !models.some((m) => m.id === activeId)) {
      activeId = null;
      store.setSetting(ACTIVE_KEY, null).catch(() => {});
    }
    renderLibrary();
  }
  bus.on('library:changed', refresh);

  function openDetail(id) {
    const model = models.find((m) => m.id === id);
    if (!model) return toast('Ese modelo ya no está en la biblioteca.');
    openModelDetail({
      store,
      model,
      layers,
      profile,
      isActive: id === activeId,
      onChanged: refresh,
      onActiveChange: setActive,
    });
  }

  function openSettingsSheet() {
    openSettings({ store, layers, profile, onLibraryChanged: refresh, onActiveChange: setActive });
  }

  // ── Montaje ────────────────────────────────────────────────────────────────────────────────
  const scroller = h('div', { class: 'hub__scroll' }, bar, notesBox, thumbBox, importSection, queueSection, librarySection);
  const el = h('section', { class: 'hub', 'aria-label': 'Hub de importación' }, scroller, activeBar);
  el.addEventListener('dragenter', hubOnDrag);
  el.addEventListener('dragover', hubOnDrag);
  el.addEventListener('dragleave', hubOnDrag);
  el.addEventListener('drop', hubOnDrag);

  return {
    el,
    async enter() {
      await refresh();
    },
    refresh,
  };
}
