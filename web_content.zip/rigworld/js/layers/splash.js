// CAPA 1 · Splash. El progreso es real: cada paso del arranque enciende articulaciones del
// esqueleto de 19 huesos (la silueta se "ensambla" a medida que avanza). Dibujo en Canvas 2D
// con proyección 3D propia: no depende de Three.js ni de WebGL, así que aparece al instante.
import { h } from '../ui/dom.js';
import { HUMANOID_19, BONE_RADIUS } from '../core/skeletonTemplate.js';

const FOCAL = 3.4;
const PITCH = 0.1;

function mulberry32(seed) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Puntos de la silueta: cápsulas alrededor de cada hueso, más cabeza y pelvis.
export function buildSilhouette(count, seed = 7) {
  const rnd = mulberry32(seed);
  const segs = [];
  HUMANOID_19.forEach((j, i) => {
    if (j.parent < 0) return;
    const a = HUMANOID_19[j.parent].pos, b = j.pos;
    const len = Math.hypot(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
    const r = BONE_RADIUS[j.name] || 0.05;
    if (j.name === 'LeftShoulder' || j.name === 'RightShoulder') return; // lo cubre el pecho
    segs.push({ a, b, r, w: len * r * r + 0.002 });
  });
  segs.push({ a: [0, 0.95, 0], b: [0, 1.02, 0], r: 0.15, w: 0.02 }); // pelvis
  segs.push({ a: [0, 1.72, 0], b: [0, 1.74, 0], r: 0.105, w: 0.012 }); // cabeza
  const total = segs.reduce((s, x) => s + x.w, 0);
  const pts = new Float32Array(count * 6); // x y z + dispersión x y z
  for (let n = 0; n < count; n++) {
    let pick = rnd() * total;
    let s = segs[0];
    for (const c of segs) {
      pick -= c.w;
      if (pick <= 0) {
        s = c;
        break;
      }
    }
    const t = rnd();
    const u = rnd() * 2 - 1, phi = rnd() * Math.PI * 2, rr = s.r * (0.55 + 0.45 * Math.cbrt(rnd()));
    const k = Math.sqrt(1 - u * u);
    pts[n * 6] = s.a[0] + (s.b[0] - s.a[0]) * t + rr * k * Math.cos(phi);
    pts[n * 6 + 1] = s.a[1] + (s.b[1] - s.a[1]) * t + rr * u;
    pts[n * 6 + 2] = s.a[2] + (s.b[2] - s.a[2]) * t + rr * k * Math.sin(phi);
    pts[n * 6 + 3] = (rnd() - 0.5) * 2.6;
    pts[n * 6 + 4] = (rnd() - 0.5) * 2.6 + 0.4;
    pts[n * 6 + 5] = (rnd() - 0.5) * 2.6;
  }
  return pts;
}

export function createSplash({ profile }) {
  const canvas = h('canvas', { class: 'splash__canvas', 'aria-hidden': 'true' });
  const countEl = h('span', { class: 'boot__count' }, '00');
  const labelEl = h('p', { class: 'boot__label', role: 'status', 'aria-live': 'polite' }, 'Preparando…');
  const barFill = h('i');
  const bar = h(
    'div',
    { class: 'boot__bar', role: 'progressbar', 'aria-label': 'Progreso de arranque', 'aria-valuemin': 0, 'aria-valuemax': 100, 'aria-valuenow': 0 },
    barFill,
  );
  const el = h(
    'section',
    { class: 'splash', 'aria-label': 'Pantalla de inicio' },
    canvas,
    h(
      'div',
      { class: 'splash__copy gutter' },
      h('h1', { class: 'wordmark' }, 'RigWorld'),
      h('p', { class: 'tagline' }, 'De malla estática a personaje que camina.'),
      h('div', { class: 'boot' }, h('div', { class: 'boot__row' }, labelEl, h('p', { class: 'boot__joints' }, countEl, ' / 19')), bar),
    ),
  );

  const pts = buildSilhouette(profile.particles * 3);
  const reduce = profile.reducedMotion;
  let ctx = null;
  let raf = 0;
  let running = false;
  let w = 0, hgt = 0, dpr = 1;
  let progress = 0; // objetivo
  let shown = 0; // valor animado
  let yaw = -0.5;
  let last = 0;
  let pulse = 0;
  let colors = { ink: '#e6eef8', signal: '#ff8a3d', line: '#27476f' };
  let ro = null;
  let mq = null;

  function readColors() {
    const cs = getComputedStyle(el);
    const get = (n, f) => cs.getPropertyValue(n).trim() || f;
    colors = { ink: get('--ink', colors.ink), signal: get('--signal', colors.signal), line: get('--line', colors.line), accent: get('--accent', '#6fb0ff') };
  }

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, profile.pixelRatioCap);
    w = canvas.clientWidth;
    hgt = canvas.clientHeight;
    canvas.width = Math.max(1, Math.round(w * dpr));
    canvas.height = Math.max(1, Math.round(hgt * dpr));
    ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    draw(0);
  }

  const proj = { x: 0, y: 0, s: 0, z: 0 };
  function project(x, y, z, cosY, sinY, scale, ox, oy) {
    const rx = x * cosY + z * sinY;
    const rz = -x * sinY + z * cosY;
    const ry = y * Math.cos(PITCH) - rz * Math.sin(PITCH);
    const rz2 = y * Math.sin(PITCH) + rz * Math.cos(PITCH);
    const p = FOCAL / (FOCAL + rz2);
    proj.x = ox + rx * scale * p;
    proj.y = oy - ry * scale * p;
    proj.s = p;
    proj.z = rz2;
  }

  function draw(dt) {
    if (!ctx) return;
    ctx.clearRect(0, 0, w, hgt);
    const cosY = Math.cos(yaw), sinY = Math.sin(yaw);
    const scale = Math.min(hgt * 0.5, w * 0.5);
    const ox = w / 2;
    const oy = hgt * 0.5 + scale * 0.92;
    const ease = 1 - Math.pow(1 - Math.min(1, shown), 3);
    const lit = shown * 19;

    // Puntos de la silueta: parten dispersos y convergen a medida que avanza el arranque.
    ctx.fillStyle = colors.ink;
    const n = pts.length / 6;
    for (let i = 0; i < n; i++) {
      const o = i * 6;
      const k = 1 - ease;
      project(pts[o] + pts[o + 3] * k, pts[o + 1] + pts[o + 4] * k, pts[o + 2] + pts[o + 5] * k, cosY, sinY, scale, ox, oy);
      const a = (0.15 + 0.7 * ease) * Math.min(1, 0.55 + proj.s * 0.5);
      ctx.globalAlpha = a;
      const r = 1.1 + proj.s * 1.5;
      ctx.fillRect(proj.x - r / 2, proj.y - r / 2, r, r);
    }
    ctx.globalAlpha = 1;

    // Esqueleto: huesos y articulaciones. Las articulaciones se encienden en orden.
    const P = HUMANOID_19.map((j) => {
      project(j.pos[0], j.pos[1], j.pos[2], cosY, sinY, scale, ox, oy);
      return { x: proj.x, y: proj.y, s: proj.s };
    });
    ctx.lineWidth = 1.25;
    for (let i = 1; i < HUMANOID_19.length; i++) {
      const p = HUMANOID_19[i].parent;
      if (p < 0) continue;
      const on = i < lit;
      ctx.strokeStyle = on ? colors.signal : colors.line;
      ctx.globalAlpha = on ? 0.9 : 0.5;
      ctx.beginPath();
      ctx.moveTo(P[p].x, P[p].y);
      ctx.lineTo(P[i].x, P[i].y);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    for (let i = 0; i < P.length; i++) {
      const on = i < lit;
      const r = (on ? 3.6 : 2.4) * (0.75 + P[i].s * 0.4);
      if (on) {
        const fresh = Math.max(0, 1 - (lit - i) / 1.6);
        ctx.fillStyle = colors.signal;
        ctx.globalAlpha = 0.18 + 0.4 * fresh;
        ctx.beginPath();
        ctx.arc(P[i].x, P[i].y, r + 4 + 6 * fresh, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
        ctx.fillStyle = colors.signal;
      } else {
        ctx.fillStyle = colors.line;
      }
      ctx.beginPath();
      ctx.arc(P[i].x, P[i].y, r, 0, Math.PI * 2);
      ctx.fill();
    }

    // Pulso final cuando el arranque termina.
    if (pulse > 0) {
      ctx.strokeStyle = colors.signal;
      ctx.globalAlpha = Math.max(0, pulse) * 0.5;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(ox, oy - scale * 0.95, scale * (0.4 + (1 - pulse) * 1.1), 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = 1;
      pulse = Math.max(0, pulse - dt * 1.4);
    }
  }

  function frame(t) {
    raf = 0;
    if (!running) return;
    const dt = last ? Math.min(0.05, (t - last) / 1000) : 0.016;
    last = t;
    shown += (progress - shown) * Math.min(1, dt * 5);
    if (Math.abs(progress - shown) < 0.0005) shown = progress;
    if (!reduce) yaw += dt * 0.42;
    draw(dt);
    const joints = Math.min(19, Math.floor(shown * 19 + 0.0001));
    countEl.textContent = String(joints).padStart(2, '0');
    raf = requestAnimationFrame(frame);
  }

  return {
    el,
    enter() {
      readColors();
      resize();
      ro = new ResizeObserver(resize);
      ro.observe(canvas);
      mq = matchMedia('(prefers-color-scheme: dark)');
      mq.addEventListener?.('change', readColors);
      running = true;
      last = 0;
      raf = requestAnimationFrame(frame);
    },
    exit() {
      running = false;
      cancelAnimationFrame(raf);
      ro?.disconnect();
      mq?.removeEventListener?.('change', readColors);
    },
    setProgress(p, label) {
      progress = Math.max(progress, Math.min(1, p));
      if (label) labelEl.textContent = label;
      const pct = Math.round(progress * 100);
      bar.setAttribute('aria-valuenow', String(pct));
      barFill.style.transform = `scaleX(${progress})`;
    },
    // Espera a que la animación alcance el 100 % y muestra el pulso final.
    async finish() {
      this.setProgress(1, 'Listo');
      const start = performance.now();
      while (shown < 0.995 && performance.now() - start < 1500) await new Promise((r) => setTimeout(r, 40));
      shown = 1;
      pulse = reduce ? 0 : 1;
      countEl.textContent = '19';
      await new Promise((r) => setTimeout(r, reduce ? 150 : 520));
    },
  };
}
