// Hojas inferiores y diálogos propios. El navegador no muestra confirm()/prompt()
// dentro de un artefacto, así que toda confirmación se construye aquí.
import { h, icon } from './dom.js';

const CLOSE_MS = 260;

export function openSheet({ title, body, layers, onClose, tall = false, root = document.getElementById('app') }) {
  const previouslyFocused = document.activeElement;
  let finished = false;

  const closeBtn = h(
    'button',
    { class: 'icon-btn', type: 'button', 'aria-label': 'Cerrar', onclick: () => dismiss() },
    icon('close'),
  );
  const titleEl = h('h2', { class: 'sheet__title', id: `sheet-title-${Math.random().toString(36).slice(2, 7)}` }, title);
  const sheet = h(
    'div',
    { class: `sheet${tall ? ' sheet--tall' : ''}`, role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': titleEl.id },
    h('div', { class: 'sheet__grip', 'aria-hidden': 'true' }),
    h('header', { class: 'sheet__head gutter' }, titleEl, closeBtn),
    h('div', { class: 'sheet__body gutter' }, body),
  );
  const backdrop = h('div', { class: 'sheet-wrap' }, h('div', { class: 'sheet-backdrop', onclick: () => dismiss() }), sheet);
  root.append(backdrop);
  requestAnimationFrame(() => {
    backdrop.classList.add('is-open');
    closeBtn.focus({ preventScroll: true });
  });

  const onKey = (e) => {
    if (e.key === 'Escape' && dismiss.isTop()) dismiss(); // con varias hojas apiladas, Escape cierra solo la de arriba
  };
  document.addEventListener('keydown', onKey);

  const dismiss = layers.pushOverlay(() => finish());

  function finish() {
    if (finished) return;
    finished = true;
    document.removeEventListener('keydown', onKey);
    backdrop.classList.remove('is-open');
    setTimeout(() => {
      backdrop.remove();
      try {
        previouslyFocused?.focus?.({ preventScroll: true });
      } catch {
        /* sin foco previo */
      }
    }, CLOSE_MS);
    onClose?.();
  }

  return { el: sheet, close: () => dismiss() };
}

export function confirmDialog({ title, message, confirmLabel = 'Aceptar', cancelLabel = 'Cancelar', danger = false, layers }) {
  return new Promise((resolve) => {
    let decided = false;
    const decide = (value) => {
      if (decided) return;
      decided = true;
      resolve(value);
      handle.close();
    };
    const body = h(
      'div',
      { class: 'dialog' },
      h('p', { class: 'dialog__msg' }, message),
      h(
        'div',
        { class: 'dialog__actions' },
        h('button', { class: 'btn btn--ghost', type: 'button', onclick: () => decide(false) }, cancelLabel),
        h('button', { class: `btn ${danger ? 'btn--danger' : 'btn--primary'}`, type: 'button', onclick: () => decide(true) }, confirmLabel),
      ),
    );
    const handle = openSheet({ title, body, layers, onClose: () => decide(false) });
  });
}

export function promptDialog({ title, label, value = '', confirmLabel = 'Guardar', layers }) {
  return new Promise((resolve) => {
    let decided = false;
    const decide = (v) => {
      if (decided) return;
      decided = true;
      resolve(v);
      handle.close();
    };
    const input = h('input', { class: 'field__input', id: 'prompt-input', type: 'text', value, maxLength: 80, autocomplete: 'off' });
    const form = h(
      'form',
      {
        class: 'dialog',
        onsubmit: (e) => {
          e.preventDefault();
          const v = input.value.trim();
          decide(v || null);
        },
      },
      h('label', { class: 'field__label', for: 'prompt-input' }, label),
      input,
      h(
        'div',
        { class: 'dialog__actions' },
        h('button', { class: 'btn btn--ghost', type: 'button', onclick: () => decide(null) }, 'Cancelar'),
        h('button', { class: 'btn btn--primary', type: 'submit' }, confirmLabel),
      ),
    );
    const handle = openSheet({ title, body: form, layers, onClose: () => decide(null) });
    setTimeout(() => {
      input.focus({ preventScroll: true });
      input.select();
    }, 80);
  });
}
