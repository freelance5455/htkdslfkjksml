// Visor 3D de la vista previa. Controles propios con Pointer Events (multitáctil real):
//   1 dedo: orbitar · 2 dedos: zoom con pellizco y desplazar · rueda: zoom.
// Renderiza solo cuando hay cambios o inercia (no consume batería en reposo).
import { loadThree } from '../core/threeLoader.js';
import { createRenderer, releaseRenderer } from '../core/gl.js';
import { buildPreviewGroup } from '../import/previewScene.js';

const DEFAULT_THETA = -0.62;
const DEFAULT_PHI = 0.2;
const MAX_PHI = Math.PI / 2 - 0.04;
const DEFAULT_TEX_MAX = 2048;

export class PreviewViewer {
  constructor(container, { pixelRatioCap = 1.5, antialias = true, gridColor = '#7a8a9a', reducedMotion = false, texMax = DEFAULT_TEX_MAX } = {}) {
    this.container = container;
    this.texMax = texMax;
    this.wireframeOn = false;
    this.pixelRatioCap = pixelRatioCap;
    this.antialias = antialias;
    this.gridColor = gridColor;
    this.reducedMotion = reducedMotion;
    this.pointers = new Map();
    this.state = { theta: DEFAULT_THETA, phi: DEFAULT_PHI, dist: 5, vTheta: 0, vPhi: 0 };
    this.autoRotate = false;
    this.disposed = false;
    this.raf = 0;
    this.lastT = 0;
    this.onContextLost = null;
    this.tick = null; // (dt) => boolean: animación por fotograma; devolver true mantiene el bucle de render
  }

  // preview: malla neutra. builder (opcional): async (THREE) => built, para escenas propias (p. ej. el personaje con esqueleto).
  async init(preview, { builder = null } = {}) {
    const THREE = await loadThree();
    if (this.disposed) return;
    this.THREE = THREE;
    this.canvas = document.createElement('canvas');
    this.canvas.className = 'viewer-canvas';
    this.canvas.setAttribute('aria-label', 'Vista previa 3D. Arrastra para girar, pellizca para acercar.');
    this.canvas.tabIndex = 0;
    this.container.append(this.canvas);

    this.renderer = createRenderer(THREE, this.canvas, {
      antialias: this.antialias,
      pixelRatio: Math.min(window.devicePixelRatio || 1, this.pixelRatioCap),
    });
    if (!this.renderer) {
      this.canvas.remove();
      throw new Error('No se pudo crear el contexto WebGL en este dispositivo.');
    }
    this.renderer.setClearColor(0x000000, 0);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(32, 1, 0.01, 100);
    this.scene.add(this.camera);
    this.camera.add(new THREE.HemisphereLight(0xffffff, 0x4a5563, 1.35));
    const key = new THREE.DirectionalLight(0xffffff, 2.3);
    key.position.set(-1.2, 1.8, 2.4);
    this.camera.add(key);

    this.built = builder ? await builder(THREE) : await buildPreviewGroup(THREE, preview, { texMax: this.texMax });
    if (this.disposed) {
      this.built.dispose();
      return;
    }
    this.built.group.position.sub(this.built.center);
    this.scene.add(this.built.group);

    const r = this.built.radius;
    this.grid = new THREE.GridHelper(r * 4, 16, this.gridColor, this.gridColor);
    this.grid.position.y = -this.built.size.y / 2;
    this.grid.material.transparent = true;
    this.grid.material.opacity = 0.35;
    this.scene.add(this.grid);

    this.target = new THREE.Vector3();
    this.tmpRight = new THREE.Vector3();
    this.tmpUp = new THREE.Vector3();
    this.camera.near = r * 0.01;
    this.camera.far = r * 100;

    this.#resize();
    this.fitDistance = this.#computeFit();
    this.resetView(false);

    this.ro = new ResizeObserver(() => this.#resize());
    this.ro.observe(this.container);
    this.#bind();
    this.requestRender();
  }

  #computeFit() {
    const vfov = (this.camera.fov * Math.PI) / 180;
    const hfov = 2 * Math.atan(Math.tan(vfov / 2) * this.camera.aspect);
    return (this.built.radius / Math.sin(Math.min(vfov, hfov) / 2)) * 1.12;
  }

  #resize() {
    if (!this.renderer) return;
    const w = Math.max(1, this.container.clientWidth);
    const h = Math.max(1, this.container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, this.pixelRatioCap));
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    if (this.built) {
      const prevFit = this.fitDistance || 1;
      this.fitDistance = this.#computeFit();
      this.state.dist *= this.fitDistance / prevFit; // mantiene el encuadre al girar el móvil
    }
    this.requestRender();
  }

  #bind() {
    const c = this.canvas;
    c.addEventListener('pointerdown', (e) => {
      c.setPointerCapture(e.pointerId);
      this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      this.state.vTheta = this.state.vPhi = 0;
      this.autoRotate = false;
      this.onInteract?.();
      if (this.pointers.size === 2) this.#pinchStart();
    });
    c.addEventListener('pointermove', (e) => {
      const p = this.pointers.get(e.pointerId);
      if (!p) return;
      const dx = e.clientX - p.x, dy = e.clientY - p.y;
      p.x = e.clientX;
      p.y = e.clientY;
      if (this.pointers.size === 1) {
        const k = 0.0085;
        this.state.theta -= dx * k;
        this.state.phi = Math.min(MAX_PHI, Math.max(-MAX_PHI, this.state.phi + dy * k));
        this.state.vTheta = -dx * k;
        this.state.vPhi = dy * k;
      } else if (this.pointers.size === 2) {
        this.#pinchMove();
      }
      this.requestRender();
    });
    const up = (e) => {
      this.pointers.delete(e.pointerId);
      if (this.pointers.size === 1) this.#pinchStart(); // el dedo restante sigue orbitando sin saltos
      this.requestRender();
    };
    c.addEventListener('pointerup', up);
    c.addEventListener('pointercancel', up);
    c.addEventListener(
      'wheel',
      (e) => {
        e.preventDefault();
        this.state.dist = this.#clampDist(this.state.dist * Math.exp(e.deltaY * 0.0012));
        this.requestRender();
      },
      { passive: false },
    );
    c.addEventListener('webglcontextlost', (e) => {
      e.preventDefault();
      this.onContextLost?.();
    });
    c.addEventListener('webglcontextrestored', () => this.requestRender());
    c.addEventListener('keydown', (e) => {
      const step = e.shiftKey ? 0.3 : 0.1;
      if (e.key === 'ArrowLeft') this.state.theta += step;
      else if (e.key === 'ArrowRight') this.state.theta -= step;
      else if (e.key === 'ArrowUp') this.state.phi = Math.min(MAX_PHI, this.state.phi + step);
      else if (e.key === 'ArrowDown') this.state.phi = Math.max(-MAX_PHI, this.state.phi - step);
      else if (e.key === '+' || e.key === '=') this.state.dist = this.#clampDist(this.state.dist * 0.88);
      else if (e.key === '-') this.state.dist = this.#clampDist(this.state.dist / 0.88);
      else return;
      e.preventDefault();
      this.requestRender();
    });
  }

  #pair() {
    const [a, b] = [...this.pointers.values()];
    return { dist: Math.hypot(a.x - b.x, a.y - b.y) || 1, mx: (a.x + b.x) / 2, my: (a.y + b.y) / 2 };
  }

  #pinchStart() {
    this.pinch = this.pointers.size >= 2 ? this.#pair() : null;
  }

  #pinchMove() {
    if (!this.pinch) return this.#pinchStart();
    const now = this.#pair();
    this.state.dist = this.#clampDist((this.state.dist * this.pinch.dist) / now.dist);
    // Desplazamiento: se mueve el objetivo sobre el plano de la cámara.
    const h = this.container.clientHeight || 1;
    const unit = (2 * this.state.dist * Math.tan((this.camera.fov * Math.PI) / 360)) / h;
    this.tmpRight.setFromMatrixColumn(this.camera.matrixWorld, 0);
    this.tmpUp.setFromMatrixColumn(this.camera.matrixWorld, 1);
    this.target.addScaledVector(this.tmpRight, -(now.mx - this.pinch.mx) * unit);
    this.target.addScaledVector(this.tmpUp, (now.my - this.pinch.my) * unit);
    const lim = this.built.radius * 1.5;
    this.target.clampLength(0, lim);
    this.pinch = now;
  }

  #clampDist(d) {
    return Math.min(this.fitDistance * 6, Math.max(this.built.radius * 0.35, d));
  }

  resetView(render = true) {
    this.state.theta = DEFAULT_THETA;
    this.state.phi = DEFAULT_PHI;
    this.state.vTheta = this.state.vPhi = 0;
    this.state.dist = this.fitDistance;
    this.target.set(0, 0, 0);
    if (render) this.requestRender();
  }

  setWireframe(on) {
    this.wireframeOn = on;
    this.built?.setWireframe(on);
    this.requestRender();
  }

  // Cambia la geometría mostrada (p. ej. de la vista simplificada a la completa) sin mover la cámara.
  async replacePreview(preview) {
    return this.replaceWith((THREE) => buildPreviewGroup(THREE, preview, { texMax: this.texMax, wireframe: this.wireframeOn }));
  }

  // builder: async (THREE) => built (mismo contrato que buildPreviewGroup).
  async replaceWith(builder) {
    if (this.disposed || !this.renderer || !this.built) return;
    const built = await builder(this.THREE);
    if (this.disposed) {
      built.dispose();
      return;
    }
    built.group.position.sub(built.center);
    const old = this.built;
    this.scene.remove(old.group);
    this.scene.add(built.group);
    this.built = built;
    old.dispose();
    this.grid.position.y = -built.size.y / 2;
    this.camera.near = built.radius * 0.01;
    this.camera.far = built.radius * 100;
    this.camera.updateProjectionMatrix();
    const prevFit = this.fitDistance || 1;
    this.fitDistance = this.#computeFit();
    this.state.dist *= this.fitDistance / prevFit;
    this.requestRender();
  }

  setGrid(on) {
    if (this.grid) this.grid.visible = on;
    this.requestRender();
  }

  setAutoRotate(on) {
    this.autoRotate = on && !this.reducedMotion;
    this.lastT = 0;
    this.requestRender();
  }

  requestRender() {
    if (this.raf || this.disposed || !this.renderer) return;
    this.raf = requestAnimationFrame((t) => this.#frame(t));
  }

  #frame(t) {
    this.raf = 0;
    if (this.disposed) return;
    const dt = this.lastT ? Math.min(0.05, (t - this.lastT) / 1000) : 0.016;
    this.lastT = t;
    const s = this.state;
    let moving = false;

    if (this.pointers.size === 0) {
      if (Math.abs(s.vTheta) > 0.0004 || Math.abs(s.vPhi) > 0.0004) {
        s.theta += s.vTheta;
        s.phi = Math.min(MAX_PHI, Math.max(-MAX_PHI, s.phi + s.vPhi));
        s.vTheta *= 0.92;
        s.vPhi *= 0.92;
        moving = true;
      }
      if (this.autoRotate) {
        s.theta += dt * 0.5;
        moving = true;
      }
    }

    const cp = Math.cos(s.phi);
    if (this.tick) moving = this.tick(dt) || moving;

    this.camera.position.set(this.target.x + s.dist * Math.sin(s.theta) * cp, this.target.y + s.dist * Math.sin(s.phi), this.target.z + s.dist * Math.cos(s.theta) * cp);
    this.camera.lookAt(this.target);
    this.camera.updateMatrixWorld();
    this.renderer.render(this.scene, this.camera);

    if (moving) this.requestRender();
    else this.lastT = 0;
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.ro?.disconnect();
    this.built?.dispose();
    this.grid?.geometry?.dispose();
    this.grid?.material?.dispose();
    releaseRenderer(this.renderer);
    this.renderer = null;
    this.canvas?.remove();
  }
}
