// Configuración global de RigWorld 3D (Fases 1–3: importación, esqueleto automático y animación).
// Three.js e idb se cargan desde jsDelivr mediante el importmap de index.html.
// Si cambias THREE_VERSION, cámbiala también en el importmap.

export const APP = Object.freeze({ name: 'RigWorld 3D', version: '0.3.0', fase: 3 });

export const THREE_VERSION = '0.186.1';
export const THREE_CDN = `https://cdn.jsdelivr.net/npm/three@${THREE_VERSION}`;
export const DRACO_DECODER_PATH = `${THREE_CDN}/examples/jsm/libs/draco/gltf/`;

export const LIMITS = Object.freeze({
  maxFileBytes: 200 * 1024 * 1024, // límite por archivo
  chunkBytes: 10 * 1024 * 1024, // fragmentos de IndexedDB
  maxPending: 25, // archivos en cola a la vez
  workerReadyTimeoutMs: 12000,
  thumbSize: 256,
  previewTextureMax: 512,
  hugeFileBytes: 80 * 1024 * 1024, // por encima de esto se omiten texturas en la vista previa
});

// Versión del dibujo de las miniaturas: 1 = sin textura (modelos simplificados salían grises), 2 = con textura.
export const THUMB_VERSION = 2;

export const DB_INFO = Object.freeze({ name: 'rigworld3d', version: 2 });
