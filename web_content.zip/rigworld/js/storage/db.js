// Persistencia en IndexedDB, sin librerías.
//
// Por qué IndexedDB directo y no localforage/idb: la app necesita escribir archivos de
// hasta 200 MB en fragmentos, cada uno en su propia transacción, y limpiar restos de
// importaciones interrumpidas por rango de claves. Con la API nativa son ~150 líneas,
// sin dependencias de CDN y con el mismo código probado en un navegador real.
//
// Límite conocido: algunos navegadores móviles fallan al guardar un único valor de más de
// ~150 MB en IndexedDB. Por eso cada archivo se divide en fragmentos de 10 MB (LIMITS.chunkBytes)
// y se reensambla al leer. Si el almacenamiento no está disponible (modo privado, datos
// bloqueados), se usa un almacén en memoria y la UI avisa de que no se conservará.
//
// Esquema (versión 2):
//   models   {id, name, createdAt, updatedAt, format, files[], totalBytes, stats, thumb, rig?}
//   chunks   clave «<id>:<fichero>:<fragmento>» → ArrayBuffer
//   settings clave → valor
//   rigs     {id (= id del modelo), version, rig, options, warnings, confidence, poseType, quality, createdAt}
//            solo el esqueleto ajustado (≈ 3 KB); los pesos se recalculan al abrir. La versión 1 no tenía este almacén.
import { DB_INFO, LIMITS } from '../config.js';

const MODELS = 'models';
const CHUNKS = 'chunks';
const SETTINGS = 'settings';
const RIGS = 'rigs';

const pad = (n) => String(n).padStart(6, '0');
const chunkKey = (id, fileIdx, n) => `${id}:${fileIdx}:${pad(n)}`;
const idRange = (id) => IDBKeyRange.bound(`${id}:`, `${id}:￿`);

function req(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function txDone(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new DOMException('Transacción cancelada', 'AbortError'));
  });
}

export function newId() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID().replace(/-/g, '').slice(0, 20);
  return Math.random().toString(36).slice(2, 12) + Date.now().toString(36);
}

export function friendlyStorageError(err) {
  if (err?.name === 'QuotaExceededError' || /quota/i.test(err?.message || '')) {
    return 'No queda espacio en el dispositivo para guardar este modelo. Borra modelos de la biblioteca o libera almacenamiento.';
  }
  return `No se pudo guardar en el almacenamiento del navegador (${err?.message || err?.name || 'error desconocido'}).`;
}

async function toBuffer(blobOrBuffer, start, end) {
  if (blobOrBuffer instanceof ArrayBuffer) return blobOrBuffer.slice(start, end);
  if (ArrayBuffer.isView(blobOrBuffer)) {
    const { buffer, byteOffset } = blobOrBuffer;
    return buffer.slice(byteOffset + start, byteOffset + end);
  }
  return blobOrBuffer.slice(start, end).arrayBuffer(); // Blob o File: no carga el archivo entero
}

const sizeOf = (x) => (x instanceof ArrayBuffer ? x.byteLength : ArrayBuffer.isView(x) ? x.byteLength : x.size);

// ── Implementación sobre IndexedDB ──────────────────────────────────────────────────────────
class IdbStore {
  persistent = true;

  constructor(db) {
    this.db = db;
  }

  static async open(name = DB_INFO.name) {
    const request = indexedDB.open(name, DB_INFO.version);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(MODELS)) db.createObjectStore(MODELS, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(CHUNKS)) db.createObjectStore(CHUNKS);
      if (!db.objectStoreNames.contains(SETTINGS)) db.createObjectStore(SETTINGS);
      if (!db.objectStoreNames.contains(RIGS)) db.createObjectStore(RIGS, { keyPath: 'id' });
    };
    request.onblocked = () => console.warn('[db] apertura bloqueada por otra pestaña');
    const db = await req(request);
    db.onversionchange = () => db.close();
    return new IdbStore(db);
  }

  async saveModel({ id = newId(), name, format, files, stats = {}, thumb = null, meta: extra = {} }, { onProgress, chunkBytes = LIMITS.chunkBytes } = {}) {
    const now = Date.now();
    const totalBytes = files.reduce((s, f) => s + sizeOf(f.data), 0);
    const meta = [];
    let written = 0;
    try {
      for (let fi = 0; fi < files.length; fi++) {
        const f = files[fi];
        const size = sizeOf(f.data);
        let n = 0;
        for (let off = 0; off < size || (size === 0 && n === 0); off += chunkBytes) {
          const buf = await toBuffer(f.data, off, Math.min(off + chunkBytes, size));
          const tx = this.db.transaction(CHUNKS, 'readwrite');
          tx.objectStore(CHUNKS).put(buf, chunkKey(id, fi, n));
          await txDone(tx);
          n++;
          written += buf.byteLength;
          onProgress?.(totalBytes ? written / totalBytes : 1);
          if (size === 0) break;
        }
        meta.push({ name: f.name, mime: f.mime || '', role: f.role || 'main', size, chunks: n });
      }
      const record = {
        ...extra,
        id,
        name,
        format,
        files: meta,
        totalBytes,
        stats,
        thumb: thumb ? { type: thumb.type, data: thumb.data } : null,
        createdAt: now,
        updatedAt: now,
      };
      // El registro se escribe al final: si algo falla antes, los fragmentos quedan huérfanos
      // y repairOrphans() los elimina en el siguiente arranque.
      const tx = this.db.transaction(MODELS, 'readwrite');
      tx.objectStore(MODELS).put(record);
      await txDone(tx);
      return record;
    } catch (err) {
      await this.#deleteChunks(id).catch(() => {});
      throw err;
    }
  }

  async listModels() {
    const all = await req(this.db.transaction(MODELS).objectStore(MODELS).getAll());
    return all.sort((a, b) => b.updatedAt - a.updatedAt);
  }

  async getModel(id) {
    return (await req(this.db.transaction(MODELS).objectStore(MODELS).get(id))) || null;
  }

  // touch: false conserva updatedAt (la biblioteca se ordena por él): para cambios internos como las miniaturas.
  async updateModel(id, patch, { touch = true } = {}) {
    const tx = this.db.transaction(MODELS, 'readwrite');
    const store = tx.objectStore(MODELS);
    const current = await req(store.get(id));
    if (!current) {
      tx.abort();
      throw new Error('El modelo ya no existe.');
    }
    const next = { ...current, ...patch, id, updatedAt: touch ? Date.now() : current.updatedAt };
    store.put(next);
    await txDone(tx);
    return next;
  }

  async getFileBlob(id, fileIdx) {
    const model = await this.getModel(id);
    const file = model?.files?.[fileIdx];
    if (!file) throw new Error('Archivo no encontrado en la biblioteca.');
    const parts = [];
    for (let n = 0; n < file.chunks; n++) {
      const buf = await req(this.db.transaction(CHUNKS).objectStore(CHUNKS).get(chunkKey(id, fileIdx, n)));
      if (!buf) throw new Error(`Faltan datos guardados de «${file.name}». Vuelve a importarlo.`);
      parts.push(buf);
    }
    return new Blob(parts, { type: file.mime || 'application/octet-stream' });
  }

  async getFileBuffer(id, fileIdx) {
    return (await this.getFileBlob(id, fileIdx)).arrayBuffer();
  }

  async deleteModel(id) {
    const tx = this.db.transaction([MODELS, RIGS], 'readwrite');
    tx.objectStore(MODELS).delete(id);
    tx.objectStore(RIGS).delete(id);
    await txDone(tx);
    await this.#deleteChunks(id);
  }

  // Rig del personaje (esqueleto ajustado). Un registro por modelo.
  async saveRig(id, record) {
    const tx = this.db.transaction(RIGS, 'readwrite');
    tx.objectStore(RIGS).put({ ...record, id });
    await txDone(tx);
  }

  async getRig(id) {
    return (await req(this.db.transaction(RIGS).objectStore(RIGS).get(id))) || null;
  }

  async deleteRig(id) {
    const tx = this.db.transaction(RIGS, 'readwrite');
    tx.objectStore(RIGS).delete(id);
    await txDone(tx);
  }

  async #deleteChunks(id) {
    const tx = this.db.transaction(CHUNKS, 'readwrite');
    tx.objectStore(CHUNKS).delete(idRange(id));
    await txDone(tx);
  }

  // Borra fragmentos de importaciones interrumpidas (sin registro de modelo).
  async repairOrphans() {
    const ids = new Set((await this.listModels()).map((m) => m.id));
    const keys = await req(this.db.transaction(CHUNKS).objectStore(CHUNKS).getAllKeys());
    const orphanIds = new Set();
    for (const k of keys) {
      const id = String(k).split(':')[0];
      if (!ids.has(id)) orphanIds.add(id);
    }
    for (const id of orphanIds) await this.#deleteChunks(id);
    return orphanIds.size;
  }

  async getSetting(key, fallback = null) {
    const v = await req(this.db.transaction(SETTINGS).objectStore(SETTINGS).get(key));
    return v === undefined ? fallback : v;
  }

  async setSetting(key, value) {
    const tx = this.db.transaction(SETTINGS, 'readwrite');
    tx.objectStore(SETTINGS).put(value, key);
    await txDone(tx);
  }

  async clearAll() {
    const tx = this.db.transaction([MODELS, CHUNKS, SETTINGS, RIGS], 'readwrite');
    for (const n of [MODELS, CHUNKS, SETTINGS, RIGS]) tx.objectStore(n).clear();
    await txDone(tx);
  }

  close() {
    this.db.close();
  }
}

// ── Respaldo en memoria (misma API) ─────────────────────────────────────────────────────────
class MemoryStore {
  persistent = false;
  models = new Map();
  chunks = new Map();
  settings = new Map();
  rigs = new Map();

  async saveModel({ id = newId(), name, format, files, stats = {}, thumb = null, meta: extra = {} }, { onProgress, chunkBytes = LIMITS.chunkBytes } = {}) {
    const now = Date.now();
    const totalBytes = files.reduce((s, f) => s + sizeOf(f.data), 0);
    const meta = [];
    let written = 0;
    for (let fi = 0; fi < files.length; fi++) {
      const f = files[fi];
      const size = sizeOf(f.data);
      const buf = await toBuffer(f.data, 0, size);
      this.chunks.set(`${id}:${fi}`, buf);
      written += size;
      onProgress?.(totalBytes ? written / totalBytes : 1);
      meta.push({ name: f.name, mime: f.mime || '', role: f.role || 'main', size, chunks: 1 });
    }
    const record = { ...extra, id, name, format, files: meta, totalBytes, stats, thumb: thumb ? { type: thumb.type, data: thumb.data } : null, createdAt: now, updatedAt: now };
    this.models.set(id, record);
    return record;
  }

  async listModels() {
    return [...this.models.values()].sort((a, b) => b.updatedAt - a.updatedAt);
  }

  async getModel(id) {
    return this.models.get(id) || null;
  }

  async updateModel(id, patch, { touch = true } = {}) {
    const cur = this.models.get(id);
    if (!cur) throw new Error('El modelo ya no existe.');
    const next = { ...cur, ...patch, id, updatedAt: touch ? Date.now() : cur.updatedAt };
    this.models.set(id, next);
    return next;
  }

  async getFileBlob(id, fileIdx) {
    const buf = this.chunks.get(`${id}:${fileIdx}`);
    const file = this.models.get(id)?.files?.[fileIdx];
    if (!buf || !file) throw new Error('Archivo no encontrado en la biblioteca.');
    return new Blob([buf], { type: file.mime || 'application/octet-stream' });
  }

  async getFileBuffer(id, fileIdx) {
    return (await this.getFileBlob(id, fileIdx)).arrayBuffer();
  }

  async deleteModel(id) {
    this.models.delete(id);
    this.rigs.delete(id);
    for (const k of [...this.chunks.keys()]) if (k.startsWith(`${id}:`)) this.chunks.delete(k);
  }

  async saveRig(id, record) {
    this.rigs.set(id, structuredClone({ ...record, id }));
  }

  async getRig(id) {
    const r = this.rigs.get(id);
    return r ? structuredClone(r) : null;
  }

  async deleteRig(id) {
    this.rigs.delete(id);
  }

  async repairOrphans() {
    return 0;
  }

  async getSetting(key, fallback = null) {
    return this.settings.has(key) ? this.settings.get(key) : fallback;
  }

  async setSetting(key, value) {
    this.settings.set(key, value);
  }

  async clearAll() {
    this.models.clear();
    this.chunks.clear();
    this.settings.clear();
    this.rigs.clear();
  }

  close() {}
}

// Abre IndexedDB y, si falla, cae a memoria. Devuelve siempre un almacén utilizable.
export async function openStore(name) {
  try {
    if (typeof indexedDB === 'undefined') throw new Error('IndexedDB no disponible');
    const store = await IdbStore.open(name);
    // Comprobación de escritura real: en algunos contextos abre pero falla al escribir.
    await store.setSetting('_probe', Date.now());
    return store;
  } catch (err) {
    console.warn('[db] usando almacenamiento en memoria:', err);
    const store = new MemoryStore();
    store.fallbackReason = err?.message || String(err);
    return store;
  }
}

export async function storageEstimate() {
  try {
    const est = await navigator.storage?.estimate?.();
    if (!est) return null;
    return { usage: est.usage || 0, quota: est.quota || 0 };
  } catch {
    return null;
  }
}

export async function requestPersistence() {
  try {
    if (navigator.storage?.persisted && (await navigator.storage.persisted())) return true;
    return (await navigator.storage?.persist?.()) || false;
  } catch {
    return false;
  }
}
