// Animador: decide en cada fotograma qué pose mostrar a partir de una velocidad pedida y de acciones puntuales.
//
//  · La velocidad pedida se alcanza con aceleración limitada. El ciclo de zancada avanza según esa velocidad
//    (fase += velocidad / longitud de zancada), por lo que el pie en apoyo recorre el suelo exactamente a la
//    velocidad del cuerpo: no patina nunca, ni siquiera al arrancar o frenar.
//  · Al parar, el ciclo no se congela a mitad de un paso: sigue hasta la próxima postura de «cruce» (pies
//    juntos, fase 0,25 o 0,75) y desde ahí se funde con el reposo.
//  · Saltar y saludar son acciones puntuales que se funden con la pose base (el saludo solo se aplica
//    cuando va despacio, porque con los brazos ocupados corriendo no tiene sentido).
// La velocidad real del ciclo se devuelve como `groundSpeed`; quien mueva al personaje por el mundo (o el
// suelo que se desliza en el estudio) debe usar ese valor para que los pies no resbalen.
import { clamp, smoothstep } from './mathq.js';
import { blendPose } from './skeleton.js';
import { createGait } from './gait.js';

const FADE_IN = 0.16; // s: de reposo a marcha
const FADE_OUT = 0.22; // s: de marcha a reposo
const PASS_PHASE = 0.25; // fase de «cruce» (el siguiente es 0,75)

export const ANIM_STATES = Object.freeze({ IDLE: 'idle', LOCO: 'loco', JUMP: 'jump' });

export function createAnimator(rig, { gait: gaitIn } = {}) {
  const gait = gaitIn || createGait(rig);
  const L = gait.legLen;
  const vMin = gait.speedAt(0);
  const vMax = gait.speedAt(1);
  const vWalk = gait.speedAt(0.3);
  const stride = (u) => {
    const p = gait.paramsAt(u);
    return (2 * p.a) / p.beta; // distancia por ciclo completo (dos pasos)
  };
  const ACCEL = 5 * L, DECEL = 7 * L; // unidades/s²

  const S = {
    time: 0,
    phase: PASS_PHASE,
    speed: 0, // velocidad actual (unidades/s)
    target: 0, // velocidad pedida
    moving: false,
    settle: false, // parando: seguir hasta el próximo cruce
    loco: 0, // peso de la marcha frente al reposo
    u: 0,
    groundSpeed: 0,
    lock: [{ off: 0, end: 0 }, { off: 0, end: 0 }], // bloqueo de pie: desplazamiento z que cancela el arrastre al cambiar de velocidad
    jumpT: -1,
    jumpAge: 0, // segundos desde que se pidió el salto (el fundido de entrada cuenta desde aquí)
    waveT: -1,
  };

  const setSpeed = (v) => {
    S.target = clamp(Number.isFinite(v) ? v : 0, 0, vMax * 1.15);
  };

  const jump = () => {
    if (S.jumpT >= 0) return false;
    // Si ya va rápido se salta sin la agachada previa (salto en carrera).
    S.jumpT = S.speed > 0.6 * vWalk ? 0.8 * gait.jumpAnticip : 0;
    S.jumpAge = 0;
    return true;
  };
  const wave = () => {
    if (S.waveT >= 0) return false;
    S.waveT = 0;
    return true;
  };
  const reset = () => {
    Object.assign(S, { time: 0, phase: PASS_PHASE, speed: 0, target: 0, moving: false, settle: false, loco: 0, u: 0, groundSpeed: 0, jumpT: -1, jumpAge: 0, waveT: -1 });
    S.lock = [{ off: 0, end: 0 }, { off: 0, end: 0 }];
  };

  // Bloqueo de pie. Al cambiar de velocidad cambian a la vez el largo de zancada y la fracción de apoyo, y con
  // el pie plantado eso lo arrastraría unos centímetros. En apoyo se resta justo ese arrastre (diferencia entre
  // evaluar la fase actual con los parámetros nuevos y con los anteriores); en balanceo el ajuste se desvanece
  // hasta cero, de modo que el pie siguiente se planta donde toca y no hay saltos.
  const lockFeet = (uPrev) => {
    const pNew = gait.paramsAt(S.u);
    for (let i = 0; i < 2; i++) {
      const phi = (S.phase + 0.5 * i) % 1;
      const k = S.lock[i];
      if (phi < pNew.beta) {
        if (Math.abs(S.u - uPrev) > 1e-9) k.off -= gait.footFlatZ(i, phi, S.u) - gait.footFlatZ(i, phi, uPrev);
        k.off = clamp(k.off, -0.5 * L, 0.5 * L);
        k.end = k.off;
      } else {
        k.off = k.end * (1 - smoothstep(0, 1, (phi - pNew.beta) / (1 - pNew.beta)));
      }
    }
  };

  const update = (dtIn) => {
    const dt = clamp(Number.isFinite(dtIn) ? dtIn : 0, 0, 0.1);
    S.time += dt;

    // ── Marcha: velocidad → ciclo ───────────────────────────────────────────────────────────
    if (!S.moving && S.target > 0.05 * vMin) {
      S.moving = true;
      S.settle = false;
    }
    S.groundSpeed = 0;
    if (S.moving) {
      if (S.target <= 0.02 * vMin && S.speed < 0.3 * vMin) S.settle = true;
      else if (S.target > 0.05 * vMin) S.settle = false;
      const goal = S.settle ? 0 : S.target;
      S.speed += clamp(goal - S.speed, -DECEL * dt, ACCEL * dt);
      const uPrev = S.u;
      S.u = gait.uForSpeed(S.speed);
      const st = stride(S.u);
      let rate = S.speed / st; // ciclos por segundo
      if (S.settle) rate = Math.max(rate, 0.3);
      const prev = S.phase;
      S.phase = prev + rate * dt;
      if (S.settle) {
        const k0 = Math.floor((prev - PASS_PHASE) * 2), k1 = Math.floor((S.phase - PASS_PHASE) * 2);
        if (k1 > k0) {
          S.phase = PASS_PHASE + 0.5 * k1;
          S.moving = false;
          S.settle = false;
          S.speed = 0;
          rate = 0;
        }
      }
      S.phase -= Math.floor(S.phase);
      S.groundSpeed = rate * st;
      lockFeet(uPrev);
    }
    const locoGoal = S.moving ? 1 : 0;
    const step = dt / (locoGoal > S.loco ? FADE_IN : FADE_OUT);
    S.loco = clamp(S.loco + clamp(locoGoal - S.loco, -step, step), 0, 1);

    // ── Pose base: reposo ↔ marcha ──────────────────────────────────────────────────────────
    let pose = gait.idle(S.time);
    if (S.loco > 0) {
      const lp = gait.walkRun(S.phase, S.u, [S.lock[0].off, S.lock[1].off]).pose;
      pose = S.loco >= 1 ? lp : blendPose(pose, lp, smoothstep(0, 1, S.loco));
    }

    // ── Salto ───────────────────────────────────────────────────────────────────────────────
    let state = S.loco > 0.5 ? ANIM_STATES.LOCO : ANIM_STATES.IDLE;
    let jumpW = 0;
    if (S.jumpT >= 0) {
      S.jumpT += dt;
      S.jumpAge += dt;
      if (S.jumpT >= gait.jumpDuration) S.jumpT = -1;
      else {
        const t = S.jumpT, D = gait.jumpDuration;
        jumpW = smoothstep(0, 0.2, S.jumpAge) * (1 - smoothstep(D - 0.16, D, t));
        pose = blendPose(pose, gait.jump(t), jumpW);
        state = ANIM_STATES.JUMP;
      }
    }

    // ── Saludo (solo despacio y sin saltar) ─────────────────────────────────────────────────
    if (S.waveT >= 0) {
      S.waveT += dt;
      if (S.waveT >= gait.waveDuration) S.waveT = -1;
      else {
        const slow = 1 - smoothstep(0.6 * vWalk, 1.1 * vWalk, S.speed);
        gait.wave(pose, S.waveT, slow * (1 - jumpW));
      }
    }
    return { pose, state, phase: S.phase, u: S.u, speed: S.speed, groundSpeed: S.groundSpeed, moving: S.moving, waving: S.waveT >= 0 };
  };

  return {
    gait, update, setSpeed, jump, wave, reset,
    get state() { return { ...S }; },
    get isJumping() { return S.jumpT >= 0; },
    get isWaving() { return S.waveT >= 0; },
    speeds: { min: vMin, walk: vWalk, trot: gait.speedAt(0.72), run: gait.speedAt(0.88), sprint: vMax },
  };
}
