// Matemática mínima sin dependencias para el rig: vectores como [x, y, z] y cuaterniones como
// [x, y, z, w] (mismo orden que Three.js). Se usa en el Worker, en el visor y en las pruebas de Node.

export const EPS = 1e-9;

export const v3 = {
  add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]],
  sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
  mul: (a, s) => [a[0] * s, a[1] * s, a[2] * s],
  dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
  cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
  len: (a) => Math.hypot(a[0], a[1], a[2]),
  dist: (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]),
  lerp: (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t],
  norm(a) {
    const l = Math.hypot(a[0], a[1], a[2]);
    return l > EPS ? [a[0] / l, a[1] / l, a[2] / l] : [0, 0, 0];
  },
};

export const clamp = (x, lo, hi) => (x < lo ? lo : x > hi ? hi : x);
export const lerp = (a, b, t) => a + (b - a) * t;
export const smoothstep = (a, b, x) => {
  const t = clamp((x - a) / (b - a || 1), 0, 1);
  return t * t * (3 - 2 * t);
};
export const DEG = Math.PI / 180;

export const Q_IDENTITY = Object.freeze([0, 0, 0, 1]);

// a·b: aplica primero b y después a (como Quaternion.multiplyQuaternions de Three.js).
export function qMul(a, b) {
  return [
    a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
    a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
    a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
    a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2],
  ];
}

export const qConj = (q) => [-q[0], -q[1], -q[2], q[3]];

export function qNorm(q) {
  const l = Math.hypot(q[0], q[1], q[2], q[3]);
  return l > EPS ? [q[0] / l, q[1] / l, q[2] / l, q[3] / l] : [0, 0, 0, 1];
}

export function qAxisAngle(axis, angle) {
  const a = v3.norm(axis);
  const s = Math.sin(angle / 2);
  return [a[0] * s, a[1] * s, a[2] * s, Math.cos(angle / 2)];
}

export const qRotX = (a) => [Math.sin(a / 2), 0, 0, Math.cos(a / 2)];
export const qRotY = (a) => [0, Math.sin(a / 2), 0, Math.cos(a / 2)];
export const qRotZ = (a) => [0, 0, Math.sin(a / 2), Math.cos(a / 2)];

// Giro de un vector: v' = q · v · q⁻¹
export function qRotate(q, v) {
  const [x, y, z, w] = q;
  const tx = 2 * (y * v[2] - z * v[1]);
  const ty = 2 * (z * v[0] - x * v[2]);
  const tz = 2 * (x * v[1] - y * v[0]);
  return [v[0] + w * tx + (y * tz - z * ty), v[1] + w * ty + (z * tx - x * tz), v[2] + w * tz + (x * ty - y * tx)];
}

// Giro mínimo que lleva el vector unitario `from` al vector unitario `to`.
export function qFromUnitVectors(from, to) {
  const d = v3.dot(from, to);
  if (d > 1 - 1e-12) return [0, 0, 0, 1];
  if (d < -1 + 1e-12) {
    // Opuestos: cualquier eje perpendicular sirve.
    let axis = v3.cross([1, 0, 0], from);
    if (v3.len(axis) < 1e-6) axis = v3.cross([0, 1, 0], from);
    return qAxisAngle(axis, Math.PI);
  }
  const c = v3.cross(from, to);
  return qNorm([c[0], c[1], c[2], 1 + d]);
}

// Cuaternión de una base ortonormal con columnas (x, y, z).
export function qFromBasis(x, y, z) {
  const m00 = x[0], m10 = x[1], m20 = x[2];
  const m01 = y[0], m11 = y[1], m21 = y[2];
  const m02 = z[0], m12 = z[1], m22 = z[2];
  const tr = m00 + m11 + m22;
  let q;
  if (tr > 0) {
    const s = Math.sqrt(tr + 1) * 2;
    q = [(m21 - m12) / s, (m02 - m20) / s, (m10 - m01) / s, s / 4];
  } else if (m00 > m11 && m00 > m22) {
    const s = Math.sqrt(1 + m00 - m11 - m22) * 2;
    q = [s / 4, (m01 + m10) / s, (m02 + m20) / s, (m21 - m12) / s];
  } else if (m11 > m22) {
    const s = Math.sqrt(1 + m11 - m00 - m22) * 2;
    q = [(m01 + m10) / s, s / 4, (m12 + m21) / s, (m02 - m20) / s];
  } else {
    const s = Math.sqrt(1 + m22 - m00 - m11) * 2;
    q = [(m02 + m20) / s, (m12 + m21) / s, s / 4, (m10 - m01) / s];
  }
  return qNorm(q);
}

// Base ortonormal a partir de un eje principal `a` y una referencia `r` (se ortogonaliza contra a).
// Si r es casi paralela a a, se usa un eje alternativo estable.
export function frameFrom(a, r) {
  const ax = v3.norm(a);
  let ref = r;
  let rp = v3.sub(ref, v3.mul(ax, v3.dot(ref, ax)));
  if (v3.len(rp) < 1e-6) {
    ref = Math.abs(ax[1]) < 0.9 ? [0, 1, 0] : [0, 0, 1];
    rp = v3.sub(ref, v3.mul(ax, v3.dot(ref, ax)));
  }
  const y = v3.norm(rp);
  const z = v3.cross(ax, y);
  return [ax, y, z];
}

// Giro que lleva el marco (a0, r0) al marco (a1, r1): el eje del hueso va de a0 a a1 y, además,
// la referencia r (p. ej. hacia dónde dobla la rodilla) se conserva, de modo que no aparece torsión.
export function qFromFrames(a0, r0, a1, r1) {
  const f0 = frameFrom(a0, r0);
  const f1 = frameFrom(a1, r1);
  return qMul(qFromBasis(...f1), qConj(qFromBasis(...f0)));
}

export function qSlerp(a, b, t) {
  let [bx, by, bz, bw] = b;
  let cos = a[0] * bx + a[1] * by + a[2] * bz + a[3] * bw;
  if (cos < 0) {
    cos = -cos;
    bx = -bx;
    by = -by;
    bz = -bz;
    bw = -bw;
  }
  if (cos > 0.9995) {
    return qNorm([a[0] + (bx - a[0]) * t, a[1] + (by - a[1]) * t, a[2] + (bz - a[2]) * t, a[3] + (bw - a[3]) * t]);
  }
  const theta = Math.acos(cos);
  const sin = Math.sin(theta);
  const s0 = Math.sin((1 - t) * theta) / sin;
  const s1 = Math.sin(t * theta) / sin;
  return [a[0] * s0 + bx * s1, a[1] * s0 + by * s1, a[2] * s0 + bz * s1, a[3] * s0 + bw * s1];
}

// Giro por ejes del mundo: primero roll (Z), luego pitch (X), luego yaw (Y): R = Ry · Rx · Rz.
export function qYawPitchRoll(yaw, pitch, roll) {
  return qMul(qRotY(yaw), qMul(qRotX(pitch), qRotZ(roll)));
}

export const isFiniteVec = (v) => v.every(Number.isFinite);
