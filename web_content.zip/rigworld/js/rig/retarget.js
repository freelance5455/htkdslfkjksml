// Retargeting: lleva una animación de otro personaje (Mixamo, VRM/VRoid y cualquier esqueleto
// humanoide con nombres estándar) al esqueleto automático de 19 huesos de RigWorld.
//
// Entrada, en datos planos (sin Three.js, así que se prueba en Node):
//   source = { bones: [{ name, parent, pos: [x,y,z], rot: [x,y,z,w], scale }] }   (reposo; padres antes que hijos)
//   clip   = { name, duration, tracks: [{ node, prop: 'quaternion' | 'position', times, values }] }
//
// Método (robusto a que el origen esté en pose T, A, con otra orientación, otra escala o más huesos):
//   1. Los nombres se reconocen por palabras (LeftUpLeg, upper_arm.L, J_Bip_L_UpperArm, mixamorig:Spine1…).
//   2. El marco del origen se deduce del reposo (izquierda = pierna izquierda − derecha, arriba = caderas → cabeza),
//      de modo que un VRM que mira a −Z o un FBX con eje Z hacia arriba llegan igual.
//   3. Huesos con hijo en la cadena (columna, hombros, brazos, piernas, cuello): la DIRECCIÓN del hueso es la del
//      origen en cada instante (giro mínimo desde el reposo del destino) y la torsión alrededor del hueso se toma del
//      giro del origen. Por eso un origen en pose A y un destino en pose T no se doblan ni se cruzan.
//   4. Caderas, cabeza y pies copian el giro respecto al reposo (los pies quedan planos si lo estaban); las manos
//      conservan su orientación respecto al antebrazo.
//   5. La posición de las caderas se escala por la proporción de largo de pierna y se corrige la altura para que el pie
//      más bajo siga al del origen (sin hundirse ni flotar con piernas de otro largo; los saltos se conservan).
// Resultado: una animación «cocida» (poses de mundo por fotograma) que se guarda en IndexedDB y se reproduce con
// createClipPlayer(); no hace falta conservar el archivo original.
import { v3, qMul, qConj, qNorm, qRotate, qSlerp, qFromUnitVectors, qFromBasis, qAxisAngle, clamp } from './mathq.js';
import { PARENTS, BONE_COUNT, BONE_NAMES, IDX, poseJoints, poseIsFinite, restPose } from './skeleton.js';

export const RETARGET_LIMITS = Object.freeze({ maxSeconds: 30, maxClips: 8, fps: 30 });

// ── Reconocimiento de nombres ──────────────────────────────────────────────────────────────────
const JUNK = new Set(['mixamorig', 'armature', 'bone', 'bip', 'j', 'c', 'def', 'org', 'jnt', 'joint', 'rig', 'skeleton', 'cc', 'base']);
// base (sin lado) → [hueso, prioridad]; con varias candidatas para un hueso gana la de menor prioridad.
const BASES = {
  hips: ['Hips', 0], hip: ['Hips', 1], pelvis: ['Hips', 2],
  spine: ['Spine', 0], abdomen: ['Spine', 1], spine0: ['Spine', 2], spine01: ['Spine', 3],
  chest: ['Chest', 0], spine1: ['Chest', 1], spine02: ['Chest', 2], upperchest: ['Chest', 3], spine2: ['Chest', 4], spine03: ['Chest', 5],
  neck: ['Neck', 0], neck1: ['Neck', 1],
  head: ['Head', 0],
  shoulder: ['Shoulder', 0], clavicle: ['Shoulder', 1], collar: ['Shoulder', 2],
  upperarm: ['UpperArm', 0], arm: ['UpperArm', 1], uparm: ['UpperArm', 2],
  lowerarm: ['LowerArm', 0], forearm: ['LowerArm', 1],
  hand: ['Hand', 0],
  upperleg: ['UpperLeg', 0], upleg: ['UpperLeg', 1], thigh: ['UpperLeg', 2],
  lowerleg: ['LowerLeg', 0], leg: ['LowerLeg', 1], calf: ['LowerLeg', 2], shin: ['LowerLeg', 3],
  foot: ['Foot', 0],
};
const SIDED = new Set(['Shoulder', 'UpperArm', 'LowerArm', 'Hand', 'UpperLeg', 'LowerLeg', 'Foot']);

function tokens(raw) {
  let s = String(raw || '');
  s = s.slice(Math.max(s.lastIndexOf(':'), s.lastIndexOf('|')) + 1);
  s = s.replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2');
  return s.toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
}

// Devuelve { bone: índice 0–18, rank } o null si el nombre no corresponde a ninguno de los 19 huesos.
export function canonicalBoneFor(name) {
  let toks = tokens(name);
  let side = null;
  const rest = [];
  for (const t of toks) {
    if (t === 'left' || t === 'l') side = side || 'Left';
    else if (t === 'right' || t === 'r') side = side || 'Right';
    else if (!JUNK.has(t)) rest.push(t);
  }
  // «mixamorigHips» sin separador queda como un solo token que empieza por mixamorig.
  const base = rest.join('').replace(/^mixamorig/, '');
  const hit = BASES[base];
  if (!hit) return null;
  const [kind, rank] = hit;
  if (SIDED.has(kind)) {
    if (!side) return null;
    return { bone: IDX[`${side}${kind}`], rank };
  }
  if (side) return null;
  return { bone: IDX[kind], rank };
}

// Asocia cada hueso canónico con un hueso del origen. map[b] = índice en source.bones o −1.
export function mapSourceBones(source) {
  const map = new Array(BONE_COUNT).fill(-1);
  const best = new Array(BONE_COUNT).fill(Infinity);
  source.bones.forEach((b, i) => {
    const hit = canonicalBoneFor(b.name);
    if (!hit) return;
    // Entre varias candidatas gana la de menor rango; a igual rango, la más cercana a la raíz.
    if (hit.rank < best[hit.bone]) {
      best[hit.bone] = hit.rank;
      map[hit.bone] = i;
    }
  });
  return map;
}

const REQUIRED = ['Hips', 'LeftUpperLeg', 'LeftLowerLeg', 'LeftFoot', 'RightUpperLeg', 'RightLowerLeg', 'RightFoot', 'LeftUpperArm', 'LeftLowerArm', 'RightUpperArm', 'RightLowerArm'];

// Hijo de la cadena principal que define la dirección de cada hueso.
const CHAIN_CHILD = new Map(
  [
    ['Spine', 'Chest'], ['Chest', 'Neck'], ['Neck', 'Head'],
    ['LeftShoulder', 'LeftUpperArm'], ['LeftUpperArm', 'LeftLowerArm'], ['LeftLowerArm', 'LeftHand'],
    ['RightShoulder', 'RightUpperArm'], ['RightUpperArm', 'RightLowerArm'], ['RightLowerArm', 'RightHand'],
    ['LeftUpperLeg', 'LeftLowerLeg'], ['LeftLowerLeg', 'LeftFoot'],
    ['RightUpperLeg', 'RightLowerLeg'], ['RightLowerLeg', 'RightFoot'],
  ].map(([a, b]) => [IDX[a], IDX[b]]),
);
// Huesos que copian el giro del origen respecto a su reposo, en el marco del mundo.
const WORLD_DELTA = new Set([IDX.Hips, IDX.Head, IDX.LeftFoot, IDX.RightFoot]);

// ── Muestreo de pistas ─────────────────────────────────────────────────────────────────────────
function findIndex(times, t) {
  let lo = 0;
  let hi = times.length - 1;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if (times[mid] <= t) lo = mid;
    else hi = mid;
  }
  return lo;
}
function sampleQuat(tr, t) {
  const n = tr.times.length;
  const v = tr.values;
  if (n === 1 || t <= tr.times[0]) return [v[0], v[1], v[2], v[3]];
  if (t >= tr.times[n - 1]) return [v[(n - 1) * 4], v[(n - 1) * 4 + 1], v[(n - 1) * 4 + 2], v[(n - 1) * 4 + 3]];
  const i = findIndex(tr.times, t);
  const f = (t - tr.times[i]) / (tr.times[i + 1] - tr.times[i] || 1);
  return qSlerp([v[i * 4], v[i * 4 + 1], v[i * 4 + 2], v[i * 4 + 3]], [v[i * 4 + 4], v[i * 4 + 5], v[i * 4 + 6], v[i * 4 + 7]], f);
}
function sampleVec(tr, t) {
  const n = tr.times.length;
  const v = tr.values;
  if (n === 1 || t <= tr.times[0]) return [v[0], v[1], v[2]];
  if (t >= tr.times[n - 1]) return [v[(n - 1) * 3], v[(n - 1) * 3 + 1], v[(n - 1) * 3 + 2]];
  const i = findIndex(tr.times, t);
  const f = (t - tr.times[i]) / (tr.times[i + 1] - tr.times[i] || 1);
  return [0, 1, 2].map((k) => v[i * 3 + k] + (v[i * 3 + 3 + k] - v[i * 3 + k]) * f);
}

// Cinemática directa del origen. Devuelve giros y posiciones de mundo (marco del origen).
function forwardKinematics(bones, rot, pos) {
  const n = bones.length;
  const W = new Array(n);
  const P = new Array(n);
  const S = new Array(n);
  for (let i = 0; i < n; i++) {
    const p = bones[i].parent;
    const sc = bones[i].scale ?? 1;
    if (p < 0) {
      W[i] = rot[i];
      P[i] = pos[i];
      S[i] = sc;
    } else {
      W[i] = qMul(W[p], rot[i]);
      P[i] = v3.add(P[p], qRotate(W[p], v3.mul(pos[i], S[p])));
      S[i] = S[p] * sc;
    }
  }
  return { W, P };
}

const softMin = (a, b, k) => {
  const m = Math.min(a, b);
  return m - k * Math.log(Math.exp(-(a - m) / k) + Math.exp(-(b - m) / k));
};
const wrapAngle = (a) => (a > Math.PI ? a - 2 * Math.PI : a < -Math.PI ? a + 2 * Math.PI : a);
// Ángulo de torsión del giro q alrededor de un eje unitario.
const twistAngle = (q, axis) => wrapAngle(2 * Math.atan2(q[0] * axis[0] + q[1] * axis[1] + q[2] * axis[2], q[3]));

// ── Retargeter ─────────────────────────────────────────────────────────────────────────────────
// Prepara la correspondencia y el marco una sola vez; después se puede «cocer» cualquier animación del mismo origen.
export function createRetargeter(rig, source) {
  const bones = source?.bones;
  if (!Array.isArray(bones) || bones.length < 5) throw new Error('El archivo no contiene un esqueleto utilizable.');
  bones.forEach((b, i) => {
    if (!(b.parent < i)) throw new Error('El esqueleto del archivo no está ordenado (cada hueso debe ir después de su padre).');
  });
  const map = mapSourceBones(source);
  const missing = REQUIRED.filter((name) => map[IDX[name]] < 0);
  if (missing.length) throw new Error(`No se reconocen estos huesos en el esqueleto del archivo: ${missing.join(', ')}. Usa un personaje humanoide con nombres estándar (Mixamo, VRM, Rigify).`);

  const n = bones.length;
  const restRot = bones.map((b) => b.rot || [0, 0, 0, 1]);
  const restPos = bones.map((b) => b.pos || [0, 0, 0]);
  const rest = forwardKinematics(bones, restRot, restPos);
  const at = (b) => rest.P[map[IDX[b]]];

  // Marco del origen: izquierda, arriba y adelante (izquierda × arriba) → ejes canónicos X, Y, Z.
  // «Arriba» y «izquierda» se estiman del reposo y se ajustan al eje del mundo más cercano si están a menos de 12°:
  // los archivos reales están alineados con los ejes (Y arriba, o Z arriba con el Armature girado) y una postura
  // ligeramente inclinada (cabeza adelantada, cadera girada) no debe inclinar todo el movimiento.
  const AXES = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
  const snap = (v) => {
    let best = null;
    let bd = -2;
    for (const a of AXES) {
      const d = v3.dot(v, a);
      if (d > bd) {
        bd = d;
        best = a;
      }
    }
    return bd > Math.cos((12 * Math.PI) / 180) ? best : v;
  };
  const top = ['Head', 'Neck', 'Chest', 'Spine'].find((b) => map[IDX[b]] >= 0);
  let up = top ? v3.sub(at(top), at('Hips')) : [0, 1, 0];
  if (v3.len(up) < 1e-9) up = [0, 1, 0];
  up = snap(v3.norm(up));
  let left = v3.sub(at('LeftUpperLeg'), at('RightUpperLeg'));
  left = v3.sub(left, v3.mul(up, v3.dot(left, up)));
  if (v3.len(left) < 1e-9) throw new Error('No se pudo determinar el lado izquierdo del personaje del archivo (las piernas coinciden).');
  left = v3.norm(left);
  left = v3.norm(v3.sub(snap(left), v3.mul(up, v3.dot(snap(left), up))));
  const fwd = v3.cross(left, up);
  const qFrame = qConj(qFromBasis(left, up, fwd));
  const toCanonQ = (q) => qMul(qFrame, q); // orientación del hueso vista desde el marco canónico
  const toCanonP = (p) => qRotate(qFrame, p);

  const legLen = (side) => v3.dist(at(`${side}UpperLeg`), at(`${side}LowerLeg`)) + v3.dist(at(`${side}LowerLeg`), at(`${side}Foot`));
  const srcLeg = (legLen('Left') + legLen('Right')) / 2;
  const rj = rig.joints;
  const rigLeg = (v3.dist(rj[IDX.LeftUpperLeg], rj[IDX.LeftLowerLeg]) + v3.dist(rj[IDX.LeftLowerLeg], rj[IDX.LeftFoot]) + v3.dist(rj[IDX.RightUpperLeg], rj[IDX.RightLowerLeg]) + v3.dist(rj[IDX.RightLowerLeg], rj[IDX.RightFoot])) / 2;
  if (!(srcLeg > 1e-9) || !(rigLeg > 1e-9)) throw new Error('Las piernas del esqueleto del archivo tienen largo cero.');
  const k = rigLeg / srcLeg;

  const canon0 = { W: rest.W.map(toCanonQ), P: rest.P.map(toCanonP) };
  const restDir = new Map();
  for (const [b, c] of CHAIN_CHILD) {
    if (map[b] < 0 || map[c] < 0) continue;
    const d = v3.sub(canon0.P[map[c]], canon0.P[map[b]]);
    if (v3.len(d) > 1e-9) restDir.set(b, v3.norm(d));
  }
  const rigDir = (b, c) => v3.norm(v3.sub(rj[c], rj[b]));
  const hipsRestC = canon0.P[map[IDX.Hips]];
  const softK = 0.01 * (rig.height || 1.7);
  const ankleRestT = softMin(rj[IDX.LeftFoot][1], rj[IDX.RightFoot][1], softK);
  const ankleRestSrcSoft = softMin(canon0.P[map[IDX.LeftFoot]][1], canon0.P[map[IDX.RightFoot]][1], softK / k);

  // Pistas por hueso del origen.
  const byNode = new Map(bones.map((b, i) => [b.name, i]));
  const prepareTracks = (clip) => {
    const rotT = new Array(n).fill(null);
    const posT = new Array(n).fill(null);
    for (const tr of clip.tracks || []) {
      const i = byNode.get(tr.node);
      if (i === undefined || !tr.times?.length) continue;
      if (tr.prop === 'quaternion' && tr.values.length >= tr.times.length * 4) rotT[i] = tr;
      else if (tr.prop === 'position' && tr.values.length >= tr.times.length * 3) posT[i] = tr;
    }
    return { rotT, posT };
  };

  // Pose canónica del destino para el instante t del clip.
  function poseAt(tracks, t) {
    const rot = restRot.map((r, i) => (tracks.rotT[i] ? sampleQuat(tracks.rotT[i], t) : r));
    const pos = restPos.map((p, i) => (tracks.posT[i] ? sampleVec(tracks.posT[i], t) : p));
    const { W, P } = forwardKinematics(bones, rot, pos);
    const Wc = W.map(toCanonQ);
    const Pc = P.map(toCanonP);
    const D = (b) => qMul(Wc[map[b]], qConj(canon0.W[map[b]])); // giro respecto al reposo, en el marco del mundo

    const world = new Array(BONE_COUNT);
    for (let b = 0; b < BONE_COUNT; b++) {
      const parent = PARENTS[b];
      const fallback = parent >= 0 ? world[parent] : [0, 0, 0, 1];
      if (map[b] < 0) {
        world[b] = fallback;
        continue;
      }
      const d = D(b);
      const child = CHAIN_CHILD.get(b);
      if (child !== undefined && restDir.has(b)) {
        const sd = v3.sub(Pc[map[child]], Pc[map[b]]);
        if (v3.len(sd) > 1e-9) {
          const td0 = rigDir(b, child);
          const swing = qFromUnitVectors(td0, v3.norm(sd));
          const twist = qAxisAngle(td0, twistAngle(d, restDir.get(b)));
          world[b] = qNorm(qMul(swing, twist));
          continue;
        }
      }
      if (WORLD_DELTA.has(b) || parent < 0 || map[parent] < 0) world[b] = qNorm(d);
      else world[b] = qNorm(qMul(world[parent], qMul(qConj(D(parent)), d))); // manos: orientación respecto al antebrazo
    }
    // Posición de caderas (respecto a su reposo) escalada por la proporción de piernas.
    const hipsOffset = v3.mul(v3.sub(Pc[map[IDX.Hips]], hipsRestC), k);
    const srcLow = softMin(Pc[map[IDX.LeftFoot]][1], Pc[map[IDX.RightFoot]][1], softK / k);
    return { world, hipsOffset, srcLow };
  }

  // Cuece una animación: poses de mundo a `fps` fotogramas por segundo, listas para guardarse y reproducirse.
  function bake(clip, { fps = RETARGET_LIMITS.fps, inPlace = true } = {}) {
    const tracks = prepareTracks(clip);
    if (!tracks.rotT.some(Boolean) && !tracks.posT.some(Boolean)) throw new Error('La animación no tiene pistas que correspondan al esqueleto del archivo.');
    let duration = Number(clip.duration);
    if (!(duration > 0)) {
      duration = 0;
      for (const tr of [...tracks.rotT, ...tracks.posT]) if (tr) duration = Math.max(duration, tr.times[tr.times.length - 1]);
    }
    if (!(duration > 0)) throw new Error('La animación dura 0 segundos.');
    if (duration > RETARGET_LIMITS.maxSeconds) throw new Error(`La animación dura ${duration.toFixed(1)} s; el máximo es ${RETARGET_LIMITS.maxSeconds} s.`);

    const evalAt = (t) => {
      const r = poseAt(tracks, t);
      const pose = { root: [r.hipsOffset[0], r.hipsOffset[1], r.hipsOffset[2]], world: r.world };
      // Altura: el pie más bajo del destino sigue al del origen (escalado), con la misma suavidad que al medir el origen.
      const J = poseJoints(rig, { root: [0, 0, 0], world: r.world });
      const tLow = softMin(J[IDX.LeftFoot][1] + pose.root[1], J[IDX.RightFoot][1] + pose.root[1], softK);
      const want = ankleRestT + k * (r.srcLow - ankleRestSrcSoft);
      pose.root[1] += want - tLow;
      return pose;
    };

    const first = evalAt(0);
    const last = evalAt(duration);
    const H = rig.height || 1.7;
    const jf = poseJoints(rig, { root: [0, first.root[1], 0], world: first.world });
    const jl = poseJoints(rig, { root: [0, last.root[1], 0], world: last.world });
    let gap = 0;
    for (let i = 0; i < BONE_COUNT; i++) gap = Math.max(gap, v3.dist(jf[i], jl[i]));
    const loop = gap < 0.02 * H;

    const N = loop ? Math.max(2, Math.round(duration * fps)) : Math.max(2, Math.round(duration * fps) + 1);
    const span = loop ? N : N - 1;
    const root = new Float32Array(N * 3);
    const quats = new Float32Array(N * BONE_COUNT * 4);
    const x0 = first.root[0];
    const z0 = first.root[2];
    const driftX = last.root[0] - x0;
    const driftZ = last.root[2] - z0;
    for (let f = 0; f < N; f++) {
      const t = (f / span) * duration;
      const pose = f === 0 ? first : evalAt(t);
      let rx = pose.root[0] - x0;
      let rz = pose.root[2] - z0;
      if (inPlace) {
        const u = t / duration;
        rx -= driftX * u;
        rz -= driftZ * u;
      }
      root.set([rx, pose.root[1], rz], f * 3);
      for (let b = 0; b < BONE_COUNT; b++) {
        let q = pose.world[b];
        if (f > 0) {
          const o = ((f - 1) * BONE_COUNT + b) * 4;
          if (quats[o] * q[0] + quats[o + 1] * q[1] + quats[o + 2] * q[2] + quats[o + 3] * q[3] < 0) q = [-q[0], -q[1], -q[2], -q[3]];
        }
        quats.set(q, (f * BONE_COUNT + b) * 4);
      }
    }
    for (let i = 0; i < root.length; i++) if (!Number.isFinite(root[i])) throw new Error('La animación contiene valores no válidos.');
    for (let i = 0; i < quats.length; i++) if (!Number.isFinite(quats[i])) throw new Error('La animación contiene valores no válidos.');
    return {
      name: clip.name || 'Animación',
      fps: span / duration,
      duration,
      loop,
      frames: N,
      root,
      quats,
      groundSpeed: inPlace ? Math.hypot(driftX, driftZ) / duration : 0,
      scale: k,
    };
  }

  const mapped = map.filter((i) => i >= 0).length;
  return { map, mapped, missingOptional: BONE_NAMES.filter((_, i) => map[i] < 0), scale: k, bake };
}

// Atajo: reconocer, cocer y devolver el clip.
export function retargetClip(rig, source, clip, options) {
  return createRetargeter(rig, source).bake(clip, options);
}

// ── Reproductor ────────────────────────────────────────────────────────────────────────────────
// Reproduce un clip cocido. Los bucles se repiten; los clips de una sola vez se detienen en el último fotograma
// (done = true) para que quien lo use vuelva al movimiento normal.
export function createClipPlayer(clip) {
  const N = clip.frames;
  const span = clip.loop ? N : N - 1;
  let time = 0;
  let done = false;
  const quatAt = (f, b) => {
    const o = (f * BONE_COUNT + b) * 4;
    return [clip.quats[o], clip.quats[o + 1], clip.quats[o + 2], clip.quats[o + 3]];
  };
  function sample(t) {
    const x = clamp(t / clip.duration, 0, 1) * span;
    let f0 = Math.floor(x);
    let frac = x - f0;
    if (f0 >= N - 1 && !clip.loop) {
      f0 = N - 1;
      frac = 0;
    }
    const f1 = clip.loop ? (f0 + 1) % N : Math.min(f0 + 1, N - 1);
    f0 = clip.loop ? f0 % N : f0;
    const world = new Array(BONE_COUNT);
    for (let b = 0; b < BONE_COUNT; b++) world[b] = frac === 0 ? quatAt(f0, b) : qSlerp(quatAt(f0, b), quatAt(f1, b), frac);
    const r0 = f0 * 3;
    const r1 = f1 * 3;
    const root = [0, 1, 2].map((i) => clip.root[r0 + i] + (clip.root[r1 + i] - clip.root[r0 + i]) * frac);
    return { root, world };
  }
  return {
    clip,
    sample,
    get time() { return time; },
    get done() { return done; },
    reset() {
      time = 0;
      done = false;
    },
    update(dt) {
      if (!done) {
        time += dt;
        if (clip.loop) time %= clip.duration;
        else if (time >= clip.duration) {
          time = clip.duration;
          done = true;
        }
      }
      return { pose: sample(time), time, done, groundSpeed: clip.groundSpeed || 0 };
    },
  };
}

// Comprueba que un clip guardado es utilizable (versión del esqueleto y tamaños coherentes).
export function isClipValid(clip) {
  return !!clip && Number.isFinite(clip.duration) && clip.duration > 0 && clip.frames >= 2
    && clip.root?.length === clip.frames * 3 && clip.quats?.length === clip.frames * BONE_COUNT * 4;
}

export { restPose, poseIsFinite };
