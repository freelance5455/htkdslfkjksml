// Convierte una escena de Three.js (FBX/GLB con esqueleto y animaciones) en los datos planos que usa retarget.js.
// No importa Three.js: solo lee propiedades (name, parent, position, quaternion, scale, isBone, children), de modo
// que se prueba en Node con objetos simulados.
import { canonicalBoneFor } from './retarget.js';

const isSkippable = (o) => !!(o.isMesh || o.isSkinnedMesh || o.isLight || o.isCamera);

// Esqueleto del origen en orden de recorrido (padres antes que hijos). Solo se conservan los huesos y sus
// ancestros (el Armature o el grupo raíz pueden llevar giro y escala que forman parte del movimiento).
export function sourceFromObject3D(root) {
  const all = [];
  const walk = (o, parent) => {
    const entry = { o, parent, keep: false };
    all.push(entry);
    for (const c of o.children || []) walk(c, entry);
  };
  walk(root, null);
  const nameOf = (o) => o.name || o.uuid || '';
  for (const e of all) {
    if (isSkippable(e.o)) continue;
    if (e.o.isBone || canonicalBoneFor(nameOf(e.o))) {
      for (let a = e; a && !a.keep; a = a.parent) a.keep = true;
    }
  }
  const kept = all.filter((e) => e.keep);
  if (!kept.length) throw new Error('El archivo no contiene un esqueleto (no hay huesos).');
  const index = new Map(kept.map((e, i) => [e, i]));
  const bones = kept.map((e) => {
    const o = e.o;
    const q = o.quaternion || { x: 0, y: 0, z: 0, w: 1 };
    const p = o.position || { x: 0, y: 0, z: 0 };
    const s = o.scale || { x: 1, y: 1, z: 1 };
    let parent = -1;
    for (let a = e.parent; a; a = a.parent) {
      if (index.has(a)) {
        parent = index.get(a);
        break;
      }
    }
    const scale = (s.x + s.y + s.z) / 3;
    return { name: nameOf(o), parent, pos: [p.x, p.y, p.z], rot: [q.x, q.y, q.z, q.w], scale: Number.isFinite(scale) && scale > 0 ? scale : 1 };
  });
  return { bones };
}

// AnimationClip[] de Three.js → clips planos. Solo se usan las pistas de giro y de posición.
export function clipsFromThree(animations) {
  const out = [];
  for (const a of animations || []) {
    const tracks = [];
    for (const t of a.tracks || []) {
      const dot = t.name.lastIndexOf('.');
      if (dot < 0) continue;
      const prop = t.name.slice(dot + 1);
      if (prop !== 'quaternion' && prop !== 'position') continue;
      tracks.push({ node: t.name.slice(0, dot), prop, times: t.times, values: t.values });
    }
    if (tracks.length) out.push({ name: a.name || 'Animación', duration: a.duration, tracks });
  }
  return out;
}
