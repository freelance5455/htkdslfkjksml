// Cliente del Worker de rig. Igual que el de importación: un único Worker creado al primer uso y, si el
// navegador no puede crearlo, se calcula en el hilo principal (más lento: la interfaz se congela unos
// instantes, pero el resultado es idéntico).
import { LIMITS } from '../config.js';
import { fitRigRecord, skinAndAssess } from './service.js';

let worker = null;
let readyPromise = null;
let broken = false;
let nextId = 1;
const jobs = new Map();

function ensureWorker() {
  if (broken || typeof Worker === 'undefined') return Promise.reject(new Error('Worker no disponible'));
  if (readyPromise) return readyPromise;
  readyPromise = new Promise((resolve, reject) => {
    let w;
    try {
      w = new Worker(new URL('../workers/rig.worker.js', import.meta.url), { type: 'module' });
    } catch (err) {
      reject(err);
      return;
    }
    const timer = setTimeout(() => reject(new Error('El Worker de rig no arrancó a tiempo')), LIMITS.workerReadyTimeoutMs);
    w.onmessage = (e) => {
      const m = e.data;
      if (m.type === 'ready') {
        clearTimeout(timer);
        worker = w;
        resolve(w);
        return;
      }
      const job = jobs.get(m.id);
      if (!job) return;
      if (m.type === 'progress') job.onProgress?.(m.value);
      else if (m.type === 'done') {
        jobs.delete(m.id);
        job.resolve(m.result);
      } else if (m.type === 'error') {
        jobs.delete(m.id);
        job.reject(new Error(m.message));
      }
    };
    w.onerror = (e) => {
      clearTimeout(timer);
      const err = new Error(e.message || 'Error del Worker de rig');
      reject(err);
      for (const [id, job] of jobs) {
        jobs.delete(id);
        job.reject(err);
      }
    };
  }).catch((err) => {
    console.warn('[rig] Worker no disponible, se calcula en el hilo principal:', err);
    broken = true;
    readyPromise = null;
    try {
      worker?.terminate();
    } catch {
      /* ya terminado */
    }
    worker = null;
    throw err;
  });
  return readyPromise;
}

function resetWorker() {
  try {
    worker?.terminate();
  } catch {
    /* ya terminado */
  }
  worker = null;
  readyPromise = null;
}

async function run(message, fallback, { onProgress, signal } = {}) {
  if (signal?.aborted) throw new DOMException('Cancelado', 'AbortError');
  let w = null;
  try {
    w = await ensureWorker();
  } catch {
    w = null;
  }
  if (!w) {
    // Respaldo: se cede un instante al navegador para que pinte el mensaje de progreso antes de bloquear.
    await new Promise((r) => setTimeout(r, 30));
    return fallback(onProgress);
  }
  const id = nextId++;
  return new Promise((resolve, reject) => {
    const abort = () => {
      jobs.delete(id);
      resetWorker();
      reject(new DOMException('Cancelado', 'AbortError'));
    };
    signal?.addEventListener('abort', abort, { once: true });
    jobs.set(id, {
      onProgress,
      resolve: (r) => {
        signal?.removeEventListener('abort', abort);
        resolve(r);
      },
      reject: (e) => {
        signal?.removeEventListener('abort', abort);
        reject(e);
      },
    });
    w.postMessage({ ...message, id });
  });
}

const positionsOnly = (meshes) => meshes.map((m) => ({ positions: m.positions }));

// Ajusta el esqueleto a las mallas de vista previa. Devuelve el registro de rig (ver service.js).
export function fitRigInBackground(meshes, options = {}, { onProgress, signal } = {}) {
  return run({ type: 'fit', meshes: positionsOnly(meshes), options: { yawOffset: options.yawOffset || 0, up: options.up || 'auto' } }, (cb) => fitRigRecord(meshes, { ...options, onProgress: cb }), { onProgress, signal });
}

// Pesos y calidad para mallas ya orientadas (usa positions e indices; los buffers se copian, no se ceden).
export function skinInBackground(orientedMeshes, rig, { onProgress, signal } = {}) {
  const slim = orientedMeshes.map((m) => ({ positions: m.positions, indices: m.indices || null }));
  return run({ type: 'skin', meshes: slim, rig }, (cb) => skinAndAssess(orientedMeshes, rig, { onProgress: cb }), { onProgress, signal });
}

export const rigWorkerState = () => ({ broken, active: !!worker });
