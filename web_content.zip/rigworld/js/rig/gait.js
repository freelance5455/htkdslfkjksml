// Animación procedural del esqueleto: marcha, carrera, reposo, salto y saludo.
//
// Por qué se ve fluido y sin deformar pies ni piernas:
//  · Cada pierna se resuelve con IK de dos huesos hacia un tobillo que sigue una trayectoria de pie
//    real: en apoyo el pie recorre el suelo hacia atrás exactamente a la velocidad del cuerpo (no hay
//    patinaje) y en balanceo va con una curva Hermite que entra al suelo ya a esa velocidad.
//  · El pie es rígido (un solo hueso, pesos 100 %) y rueda talón → planta → punta girando sobre el
//    talón o la bola del pie, así la planta nunca atraviesa el suelo ni se despega de golpe.
//  · La pelvis baja lo justo para que ninguna pierna se estire más de su largo (sin rodillas
//    bloqueadas ni pies que se arrastran) y sube y baja, se desplaza y gira como al caminar de verdad.
//  · Los brazos se balancean en oposición a la pierna contraria, con el codo más flexionado hacia
//    delante; el torso contragira respecto a la pelvis y la cabeza se mantiene estable.
//  · Las poses son giros absolutos de cada segmento calculados con «marcos» (eje del hueso + referencia
//    hacia delante), por lo que funcionan con cualquier pose de reposo (T, A, brazos abajo, piernas
//    abiertas) y no introducen torsión: así se corrige también la pose original del modelo.
// Todo se expresa en unidades del modelo y escala con el largo de la pierna, no con metros fijos.
import { v3, clamp, lerp, smoothstep, DEG, qRotX, qRotY, qRotZ, qAxisAngle, qMul, qConj, qRotate, qFromFrames, qYawPitchRoll, qSlerp, Q_IDENTITY } from './mathq.js';
import { IDX, BONE_COUNT, restPose } from './skeleton.js';

const FWD = [0, 0, 1];
const UP = [0, 1, 0];
const LAT = [1, 0, 0];
const REF_LEG = 0.9; // largo de pierna de referencia (m) para los tiempos

// Parámetros de la marcha en función de u ∈ [0, 1]: 0 paso lento, 0.3 caminar, 0.55 paso ligero,
// 0.72 trote, 0.88 correr, 1 sprint. Longitudes en unidades de largo de pierna (L); ángulos en grados.
const KEYS = [
  // u     a     β     T     lift  crouch bob     yaw  roll sway   arm  abd elbow eswing lean hs   to
  [0.0, 0.28, 0.68, 1.3, 0.06, 0.015, 0.012, 3, 2, 0.012, 14, 7, 10, 8, 0, 10, -18],
  [0.3, 0.38, 0.62, 1.0, 0.07, 0.02, 0.018, 5, 3, 0.016, 24, 6, 16, 14, 1, 12, -24],
  [0.55, 0.43, 0.55, 0.86, 0.09, 0.035, 0.012, 6, 3, 0.014, 34, 6, 30, 20, 3, 8, -28],
  [0.72, 0.46, 0.42, 0.76, 0.14, 0.07, -0.02, 7, 2, 0.01, 44, 5, 70, 15, 7, 0, -34],
  [0.88, 0.48, 0.36, 0.68, 0.19, 0.09, -0.04, 8, 2, 0.008, 52, 5, 88, 10, 10, -4, -40],
  [1.0, 0.52, 0.3, 0.6, 0.24, 0.1, -0.05, 9, 2, 0.006, 60, 4, 95, 5, 14, -8, -45],
];
const FIELDS = ['a', 'beta', 'T', 'lift', 'crouch', 'bob', 'yaw', 'roll', 'sway', 'arm', 'abd', 'elbow', 'eswing', 'lean', 'hs', 'to'];

export function gaitKeysAt(u) {
  const x = clamp(u, 0, 1);
  let i = 0;
  while (i < KEYS.length - 2 && x > KEYS[i + 1][0]) i++;
  const k0 = KEYS[i], k1 = KEYS[i + 1];
  const t = (x - k0[0]) / (k1[0] - k0[0]);
  const out = {};
  FIELDS.forEach((f, j) => (out[f] = lerp(k0[j + 1], k1[j + 1], t)));
  return out;
}

const softMin = (a, b, k) => {
  const m = Math.min(a, b);
  return m - k * Math.log(Math.exp(-(a - m) / k) + Math.exp(-(b - m) / k));
};
const hermite = (u, p0, m0, p1, m1) => {
  const u2 = u * u, u3 = u2 * u;
  return (2 * u3 - 3 * u2 + 1) * p0 + (u3 - 2 * u2 + u) * m0 + (-2 * u3 + 3 * u2) * p1 + (u3 - u2) * m1;
};

// IK analítico de dos huesos. Devuelve la rodilla y el tobillo realmente alcanzado.
export function solveTwoBone(H, A, L1, L2, pole) {
  const v = v3.sub(A, H);
  const dRaw = v3.len(v);
  const e = dRaw > 1e-9 ? v3.mul(v, 1 / dRaw) : [0, -1, 0];
  const d = clamp(dRaw, Math.abs(L1 - L2) + 1e-6, (L1 + L2) * 0.9995);
  const a = (L1 * L1 - L2 * L2 + d * d) / (2 * d);
  const h = Math.sqrt(Math.max(0, L1 * L1 - a * a));
  let p = v3.sub(pole, v3.mul(e, v3.dot(pole, e)));
  p = v3.len(p) < 1e-6 ? [0, 0, 1] : v3.norm(p);
  const knee = v3.add(H, v3.add(v3.mul(e, a), v3.mul(p, h)));
  return { knee, ankle: v3.add(H, v3.mul(e, d)), reach: d };
}

export function createGait(rig) {
  const m = rig.measures;
  const J = rig.joints;
  const L = m.legLen;
  const kappa = L / REF_LEG;
  const timeScale = Math.sqrt(kappa);
  const sides = [
    { name: 'Left', s: 1, side: 0 },
    { name: 'Right', s: -1, side: 1 },
  ].map((o) => {
    const hip = J[IDX[`${o.name}UpperLeg`]], knee = J[IDX[`${o.name}LowerLeg`]], ankle = J[IDX[`${o.name}Foot`]], toe = rig.tips[`toe${o.name}`];
    const sh = J[IDX[`${o.name}UpperArm`]], el = J[IDX[`${o.name}LowerArm`]], wr = J[IDX[`${o.name}Hand`]];
    const fwd = Math.max(1e-6, toe[2] - ankle[2]);
    const drop = Math.max(0, ankle[1] - toe[1]);
    return {
      ...o,
      hip, knee, ankle, toe, sh, el, wr,
      L1: v3.dist(hip, knee), L2: v3.dist(knee, ankle),
      restThigh: v3.norm(v3.sub(knee, hip)), restShin: v3.norm(v3.sub(ankle, knee)), restFoot: v3.norm(v3.sub(toe, ankle)),
      restUpper: v3.norm(v3.sub(el, sh)), restFore: v3.norm(v3.sub(wr, el)),
      upperLen: v3.dist(sh, el), foreLen: v3.dist(el, wr),
      footFwd: fwd, footDir0: v3.norm([0, -drop, fwd]),
      heelBack: Math.max(0.01 * m.height, rig.heelBack[o.side]),
      // Sin hueso de dedos, el pie rígido gira sobre la punta al despegar (sobre la bola la punta se hundiría).
      toePivot: 0.97 * fwd,
    };
  });
  const hipsJ = J[IDX.Hips];
  const hipsRestOffset = hipsJ[1] - m.hipY; // el hueso Hips está algo por encima de las articulaciones de la cadera
  const footHalf = Math.max(0.9 * m.hipHalf, 0.03 * m.height);
  const ankleH = m.ankleH;

  // Medidas auxiliares de un paso de marcha para un u dado.
  const scaled = (u) => {
    const k = gaitKeysAt(u);
    return {
      a: k.a * L, beta: k.beta, T: k.T * timeScale, lift: k.lift * L, crouch: k.crouch * L, bob: k.bob * L,
      yaw: k.yaw * DEG, roll: k.roll * DEG, sway: k.sway * L, arm: k.arm * DEG, abd: k.abd * DEG,
      elbow: k.elbow * DEG, eswing: k.eswing * DEG, lean: k.lean * DEG, hs: k.hs * DEG, to: k.to * DEG,
    };
  };
  const speedAt = (u) => {
    const p = scaled(u);
    return (2 * p.a) / (p.beta * p.T);
  };
  // Inversa: u para una velocidad dada (la velocidad crece con u).
  const uForSpeed = (v) => {
    let lo = 0, hi = 1;
    if (v <= speedAt(0)) return 0;
    if (v >= speedAt(1)) return 1;
    for (let i = 0; i < 40; i++) {
      const mid = (lo + hi) / 2;
      if (speedAt(mid) < v) lo = mid;
      else hi = mid;
    }
    return (lo + hi) / 2;
  };

  // Desplazamiento [dy, dz] del tobillo respecto al pie plano cuando el pie está girado `psi` (punta arriba > 0),
  // girando sobre el talón (psi > 0) o sobre la punta (psi < 0): el punto de apoyo no se mueve ni se hunde.
  const rollOffset = (sd, psi) => {
    const q = qRotX(-psi);
    if (psi >= 0) {
      const r = qRotate(q, [0, ankleH, sd.heelBack]); // tobillo respecto al talón
      return [r[1] - ankleH, r[2] - sd.heelBack];
    }
    const r = qRotate(q, [0, ankleH, -sd.toePivot]); // tobillo respecto a la punta
    return [r[1] - ankleH, r[2] + sd.toePivot];
  };

  // Estado del pie en la fase φ: posición relativa del tobillo (z adelante, y alto) y giro del pie.
  const footState = (sd, phi, p) => {
    const { a, beta } = p;
    const f1 = 0.14, f2 = 0.5;
    const stancePitch = (st) => (st < f1 ? p.hs * (1 - smoothstep(0, f1, st)) : st < f2 ? 0 : p.to * smoothstep(f2, 1, st));
    if (phi < beta) {
      const st = phi / beta;
      const psi = stancePitch(st);
      const [dy, dz] = rollOffset(sd, psi);
      return { z: a - 2 * a * st + dz, y: ankleH + dy, pitch: psi, stance: true, flatZ: a - 2 * a * st };
    }
    const u = (phi - beta) / (1 - beta);
    const slope = (-2 * a * (1 - beta)) / beta; // velocidad del suelo en unidades de u
    const flatZ = hermite(u, -a, slope, a, slope);
    const [dy0, dz0] = rollOffset(sd, stancePitch(1));
    const [dy1, dz1] = rollOffset(sd, stancePitch(0));
    const k = smoothstep(0, 1, u);
    const lift = p.lift * Math.sin(Math.PI * u) ** 2;
    const psi = lerp(p.to, p.hs, k);
    return { z: flatZ + lerp(dz0, dz1, k), y: ankleH + lerp(dy0, dy1, k) + lift, pitch: psi, stance: false, flatZ };
  };

  const worldRotFoot = (sd, pitch, yaw) => {
    const q = qMul(qRotY(yaw), qRotX(-pitch));
    const dir = qRotate(q, sd.footDir0);
    const up = qRotate(q, UP);
    return qFromFrames(sd.restFoot, UP, dir, up);
  };

  // Construye la pose de piernas dado el hueso Hips (posición y giro) y los tobillos objetivo.
  const legsPose = (pose, hipsPos, hipsQ, targets, kneeOut) => {
    const out = [];
    sides.forEach((sd, i) => {
      const H = v3.add(hipsPos, qRotate(hipsQ, v3.sub(sd.hip, hipsJ)));
      const pole = v3.norm([sd.s * kneeOut, 0, 1]);
      const ik = solveTwoBone(H, targets[i].pos, sd.L1, sd.L2, pole);
      const dirT = v3.norm(v3.sub(ik.knee, H));
      const dirS = v3.norm(v3.sub(ik.ankle, ik.knee));
      // Referencia = eje lateral del cuerpo: las piernas se mueven en el plano sagital, así el marco nunca es
      // degenerado (con «hacia delante» como referencia se rompía al levantar mucho el muslo) y no hay torsión.
      const lat = qRotate(hipsQ, LAT);
      pose.world[IDX[`${sd.name}UpperLeg`]] = qFromFrames(sd.restThigh, LAT, dirT, lat);
      pose.world[IDX[`${sd.name}LowerLeg`]] = qFromFrames(sd.restShin, LAT, dirS, lat);
      pose.world[IDX[`${sd.name}Foot`]] = worldRotFoot(sd, targets[i].pitch, sd.s * kneeOut * 1.2);
      out.push({ hip: H, knee: ik.knee, ankle: ik.ankle });
    });
    return out;
  };

  // Brazo: el húmero se orienta con un marco (eje + «hacia delante»); el antebrazo es el mismo marco con el codo
  // flexionado como una bisagra pura. La bisagra gira sobre el eje lateral del cuerpo (−X, perpendicular al brazo):
  // el codo real flexiona en el plano sagital. (Con «hacia delante» como referencia, al pasar el brazo por la
  // horizontal apuntando al frente el plano de flexión giraba 180° en dos fotogramas.)
  const HINGE = [-1, 0, 0];
  const elbowFlex = (dUp, elbow) => {
    const n = v3.norm(v3.sub(HINGE, v3.mul(dUp, v3.dot(HINGE, dUp))));
    return qAxisAngle(n, elbow);
  };
  const armPose = (pose, i, swing, abd, elbow) => {
    const sd = sides[i];
    const dUp = v3.norm([sd.s * Math.sin(abd), -Math.cos(abd) * Math.cos(swing), Math.cos(abd) * Math.sin(swing)]);
    const qu = qFromFrames(sd.restUpper, FWD, dUp, FWD);
    const qf = qMul(elbowFlex(dUp, elbow), qFromFrames(sd.restFore, FWD, dUp, FWD));
    pose.world[IDX[`${sd.name}UpperArm`]] = qu;
    pose.world[IDX[`${sd.name}LowerArm`]] = qf;
    pose.world[IDX[`${sd.name}Hand`]] = qf;
  };

  // Torso: giros absolutos (guiñada, cabeceo, alabeo) de cada hueso de la columna.
  const torsoPose = (pose, { yaw, pitch, roll }) => {
    const set = (name, y, p, r) => (pose.world[IDX[name]] = qYawPitchRoll(y, p, r));
    set('Hips', yaw, pitch * 0.25, roll);
    set('Spine', -0.2 * yaw, pitch * 0.55, -0.3 * roll);
    set('Chest', -1.0 * yaw, pitch * 0.85, -0.5 * roll);
    set('Neck', -0.4 * yaw, pitch * 0.6, -0.2 * roll);
    set('Head', 0, pitch * 0.2, 0);
    pose.world[IDX.LeftShoulder] = pose.world[IDX.Chest];
    pose.world[IDX.RightShoulder] = pose.world[IDX.Chest];
  };

  // ── Marcha / carrera ───────────────────────────────────────────────────────────────────────
  // phase ∈ [0, 1): 0 = el pie izquierdo toca el suelo con el talón.
  // zOff: [izq, der] desplazamiento z adicional del tobillo (lo usa el animador para mantener el pie fijo al cambiar de velocidad).
  const walkRun = (phase, u, zOff = null) => {
    const p = scaled(u);
    const pose = restPose();
    const phiL = ((phase % 1) + 1) % 1, phiR = (phiL + 0.5) % 1;
    const fs = [footState(sides[0], phiL, p), footState(sides[1], phiR, p)];
    const halfStride = Math.max(p.a, 1e-6);
    const yawP = (-p.yaw * (fs[0].flatZ - fs[1].flatZ)) / (2 * halfStride);
    const cosMid = Math.cos(2 * Math.PI * (phiL - p.beta / 2));
    const rollP = p.roll * cosMid;
    const pitchP = p.lean;
    const hipsQ = qYawPitchRoll(yawP, pitchP * 0.25, rollP);

    const swayX = p.sway * cosMid;
    const targets = sides.map((sd, i) => ({
      pos: [sd.s * footHalf, fs[i].y, sd.ankle[2] + fs[i].z + (zOff ? zOff[i] : 0)],
      pitch: fs[i].pitch,
    }));
    // Altura de la pelvis: la ideal (con rebote y flexión) limitada por lo que alcanzan las piernas.
    const hipRest = m.hipY;
    const yDesired = hipRest - p.crouch + p.bob * Math.cos(4 * Math.PI * (phiL - p.beta / 2));
    let py = yDesired + hipsRestOffset;
    const allowed = sides.map((sd, i) => {
      const o = qRotate(hipsQ, v3.sub(sd.hip, hipsJ));
      const dx = targets[i].pos[0] - (hipsJ[0] + swayX + o[0]);
      const dz = targets[i].pos[2] - (hipsJ[2] + o[2]);
      const reach = 0.992 * (sd.L1 + sd.L2);
      const dy = Math.sqrt(Math.max(0, reach * reach - dx * dx - dz * dz));
      return targets[i].pos[1] + dy - o[1];
    });
    py = softMin(softMin(py, allowed[0], 0.012 * L), allowed[1], 0.012 * L);
    const hipsPos = [hipsJ[0] + swayX, py, hipsJ[2]];
    pose.root = [swayX, py - hipsJ[1], 0];

    torsoPose(pose, { yaw: yawP, pitch: pitchP, roll: rollP });
    pose.world[IDX.Hips] = hipsQ;
    const feet = legsPose(pose, hipsPos, hipsQ, targets, 0.06);

    // Brazos: en oposición a la pierna contraria (según la z de su tobillo respecto al paso).
    // Saturación suave (tanh) en vez de un corte: un clamp deja un pico de aceleración en la mano al correr.
    const zn = fs.map((f) => 1.2 * Math.tanh(f.flatZ / halfStride / 1.2));
    [0, 1].forEach((i) => {
      const t = zn[1 - i];
      const swing = p.arm * t;
      armPose(pose, i, swing, p.abd, p.elbow + p.eswing * Math.max(0, t));
    });
    return { pose, feet, speed: (2 * p.a) / (p.beta * p.T), cycle: p.T, stance: [fs[0].stance, fs[1].stance], zFlat: [fs[0].flatZ, fs[1].flatZ] };
  };

  // ── Reposo ─────────────────────────────────────────────────────────────────────────────────
  const idle = (t) => {
    const pose = restPose();
    const breath = Math.sin(t * 2 * Math.PI * 0.27);
    const shift = Math.sin(t * 2 * Math.PI * 0.11);
    const sway = 0.012 * L * shift;
    const yDes = m.hipY - 0.012 * L - 0.0015 * L * breath;
    const hipsQ = qYawPitchRoll(0.02 * Math.sin(t * 0.9), 0.012 * breath, 0.018 * shift);
    const hipsPos = [hipsJ[0] + sway, yDes + hipsRestOffset, hipsJ[2]];
    pose.root = [sway, hipsPos[1] - hipsJ[1], 0];
    torsoPose(pose, { yaw: 0.02 * Math.sin(t * 0.9), pitch: 0.012 * breath, roll: 0.018 * shift });
    pose.world[IDX.Hips] = hipsQ;
    const stance = Math.max(footHalf * 1.15, 0.04 * m.height);
    const targets = sides.map((sd) => ({ pos: [sd.s * stance, ankleH, sd.ankle[2]], pitch: 0 }));
    legsPose(pose, hipsPos, hipsQ, targets, 0.1);
    [0, 1].forEach((i) => armPose(pose, i, 0.03 * Math.sin(t * 1.3 + i * 2.1), 7 * DEG + 0.01 * breath, (9 + 1.5 * breath) * DEG));
    pose.world[IDX.Head] = qYawPitchRoll(0.05 * Math.sin(t * 0.37), 0.02 * Math.sin(t * 0.5), 0);
    return pose;
  };

  // ── Salto ──────────────────────────────────────────────────────────────────────────────────
  const g = 9.8 * kappa;
  const jumpH = 0.5 * L;
  const v0 = Math.sqrt(2 * g * jumpH);
  const jt = { anticip: 0.3, launch: 0.15, flight: (2 * v0) / g, land: 0.14, recover: 0.34 };
  const jumpDuration = jt.anticip + jt.launch + jt.flight + jt.land + jt.recover;
  const crouchDepth = 0.2 * L;
  const landDepth = 0.17 * L;

  const ARM_BACK = -0.6, ARM_UP = 2.0, ARM_TIME = 0.4; // balanceo de brazos del salto (rad, s)
  const jump = (t) => {
    const pose = restPose();
    const T1 = jt.anticip, T2 = T1 + jt.launch, T3 = T2 + jt.flight, T4 = T3 + jt.land;
    let dy, tuck = 0, air = 0, plant = 0, lean = 0;
    const standY = m.hipY - 0.012 * L;
    if (t < T1) {
      const k = smoothstep(0, 1, t / T1);
      dy = -crouchDepth * k;
      lean = 0.25 * k;
    } else if (t < T2) {
      const u = (t - T1) / jt.launch;
      dy = hermite(u, -crouchDepth, 0, 0.012 * L, v0 * jt.launch);
      lean = lerp(0.25, 0.05, u);
      air = smoothstep(0.7, 1, u);
      plant = smoothstep(0.1, 1, u); // flexión plantar (el talón sube) a lo largo de todo el impulso
    } else if (t < T3) {
      const tau = t - T2;
      dy = 0.012 * L + v0 * tau - 0.5 * g * tau * tau;
      tuck = Math.sin((Math.PI * tau) / jt.flight);
      air = 1;
      plant = 1;
      lean = 0.05;
    } else if (t < T4) {
      const u = (t - T3) / jt.land;
      dy = hermite(u, 0.012 * L, -v0 * jt.land, -landDepth, 0);
      air = 1 - smoothstep(0, 0.6, u);
      plant = air;
      lean = lerp(0.05, 0.2, u);
    } else {
      const k = smoothstep(0, 1, (t - T4) / jt.recover);
      dy = lerp(-landDepth, 0, k);
      lean = lerp(0.2, 0, k);
    }
    // Brazos: atrás al agacharse, impulso hacia arriba (ARM_TIME s, sin brusquedad) y bajan durante el vuelo y la caída.
    const tA = T1 + ARM_TIME;
    let armSwing;
    if (t < T1) armSwing = lerp(0.1, ARM_BACK, smoothstep(0, 1, t / T1));
    else if (t < tA) armSwing = lerp(ARM_BACK, ARM_UP, smoothstep(0, 1, (t - T1) / ARM_TIME));
    else if (t < T3) armSwing = lerp(ARM_UP, 1.0, smoothstep(0, 1, (t - tA) / (T3 - tA)));
    else if (t < T4) armSwing = lerp(1.0, 0.5, smoothstep(0, 1, (t - T3) / jt.land));
    else armSwing = lerp(0.5, 0.08, smoothstep(0, 1, (t - T4) / jt.recover));
    const hipsQ = qYawPitchRoll(0, lean * 0.25, 0);
    const hipsPos = [hipsJ[0], standY + dy + hipsRestOffset, hipsJ[2]];
    pose.root = [0, hipsPos[1] - hipsJ[1], 0];
    torsoPose(pose, { yaw: 0, pitch: lean, roll: 0 });
    pose.world[IDX.Hips] = hipsQ;
    // Tobillos: en el suelo mientras la pierna no llega; en el aire cuelgan bajo la pelvis con las rodillas recogidas.
    const stance = Math.max(footHalf * 1.1, 0.04 * m.height);
    const targets = sides.map((sd, i) => {
      const H = v3.add(hipsPos, qRotate(hipsQ, v3.sub(sd.hip, hipsJ)));
      const hang = (0.99 - 0.17 * tuck) * (sd.L1 + sd.L2);
      const zOff = 0.08 * L * tuck * (i === 0 ? 1 : 0.4);
      const yAir = H[1] - hang;
      // Pie hacia abajo (punta) durante el vuelo. `req` = altura mínima del tobillo para que la suela no atraviese el
      // suelo con ese giro. Se pasa de «pie en el suelo» a «pierna colgando» con una mezcla continua (un max() entre
      // ambas cambiaba de rama de golpe y el tobillo subía a trompicones al despegar).
      const pitch = (-0.6 * plant + 0.3 * tuck) * smoothstep(0, 1, plant);
      const req = ankleH + rollOffset(sd, pitch)[0];
      const s = smoothstep(0, 1, air);
      const x = yAir - req, k = 0.035 * L;
      const y = req + s * 0.5 * (x + Math.sqrt(x * x + 4 * k * k));
      return { pos: [sd.s * stance, y, sd.ankle[2] + zOff], pitch };
    });
    legsPose(pose, hipsPos, hipsQ, targets, 0.1);
    [0, 1].forEach((i) => armPose(pose, i, armSwing, lerp(7, 28, clamp(armSwing / ARM_UP, 0, 1)) * DEG, lerp(10, 55, clamp(armSwing / ARM_UP, 0, 1)) * DEG));
    return pose;
  };

  // ── Saludo (solo brazo derecho; se mezcla sobre otra pose) ────────────────────────────────
  const waveDuration = 2.8;
  const waveWeight = (t) => smoothstep(0, 0.4, t) * (1 - smoothstep(waveDuration - 0.45, waveDuration, t));
  const WAVE_BONES = ['RightUpperArm', 'RightLowerArm', 'RightHand'];
  const wave = (t) => {
    const sd = sides[1];
    const sway = Math.sin(t * 2 * Math.PI * 2.1);
    // Brazo levantado hacia fuera y arriba; el antebrazo se dobla hacia la vertical con una bisagra en el plano
    // frontal (eje Z) y oscila de lado a lado. Para el brazo derecho (s = −1) girar s·ángulo sobre Z lleva la
    // dirección del brazo hacia +Y.
    const abd = 128 * DEG;
    const dUp = v3.norm([sd.s * Math.sin(abd), -Math.cos(abd), 0.12]);
    const qu = qFromFrames(sd.restUpper, FWD, dUp, FWD);
    const bend = 52 * DEG + 0.45 * sway;
    const qf = qMul(qRotZ(sd.s * bend), qFromFrames(sd.restFore, FWD, dUp, FWD));
    return [qu, qf, qMul(qRotZ(0.25 * sway), qf)];
  };
  // Mezcla el saludo sobre `pose` en espacio LOCAL (antebrazo y mano respecto a su padre): en mundo, el brazo colgando
  // y el levantado quedan casi opuestos y el camino más corto salta de lado a mitad de la mezcla.
  const applyWave = (pose, t, scale = 1) => {
    const w = waveWeight(t) * scale;
    if (w <= 0) return pose;
    const q = wave(t);
    let baseParent = pose.world[IDX.RightShoulder]; // giro de mundo (original) del padre en la pose base
    let newParent = baseParent; // giro de mundo (ya mezclado) del padre
    let waveParent = Q_IDENTITY; // en la pose del saludo el hombro está en reposo
    WAVE_BONES.forEach((n, i) => {
      const id = IDX[n];
      const baseWorld = pose.world[id];
      const local = qSlerp(qMul(qConj(baseParent), baseWorld), qMul(qConj(waveParent), q[i]), w);
      pose.world[id] = qMul(newParent, local);
      baseParent = baseWorld;
      newParent = pose.world[id];
      waveParent = q[i];
    });
    return pose;
  };

  return {
    rig, measures: m, legLen: L, scale: kappa, timeScale,
    paramsAt: scaled, speedAt, uForSpeed, cycleTime: (u) => scaled(u).T,
    idle, walkRun, jump, wave: applyWave, waveWeight, waveDuration, jumpDuration, jumpAnticip: jt.anticip,
    footState, footHalf,
    // z «plana» del tobillo (sin el giro del pie) del pie `i` (0 izq, 1 der) en su fase `phi` con los parámetros de `u`.
    // En apoyo el punto de contacto es esta z más una constante, así que es lo que hay que mantener fijo.
    footFlatZ: (i, phi, u) => footState(sides[i], phi, scaled(u)).flatZ,
  };
}

export { Q_IDENTITY, BONE_COUNT };
