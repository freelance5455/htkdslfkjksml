// Esqueleto de 19 huesos ya ajustado a un modelo (el «rig» sin pesos), cinemática directa y skinning en CPU.
//
// Convenciones (todo en el marco canónico: Y arriba, +Z al frente, +X el lado izquierdo, pies en y = 0):
//  · Cada hueso tiene rotación de reposo = identidad. Su orientación local coincide con los ejes del
//    mundo, así una animación se describe con giros absolutos de cada segmento del cuerpo.
//  · Una pose es { root: [x, y, z], world: [q × 19] }. `root` se suma a la posición de Hips; world[i] es
//    el giro del hueso i respecto a su orientación de reposo, medido en ejes del mundo.
//  · La rotación local que necesita Three.js es inv(world[padre]) · world[hueso] (poseToLocal).
import { HUMANOID_19, BONE_NAMES } from '../core/skeletonTemplate.js';
import { v3, qMul, qConj, qRotate, qSlerp, Q_IDENTITY } from './mathq.js';
import { IDX } from './fit.js';

export const PARENTS = Object.freeze(HUMANOID_19.map((j) => j.parent));
export const BONE_COUNT = BONE_NAMES.length;
export { IDX, BONE_NAMES };

export const CHILDREN = (() => {
  const c = Array.from({ length: BONE_COUNT }, () => []);
  PARENTS.forEach((p, i) => p >= 0 && c[p].push(i));
  return c;
})();

const avg = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2];

// Crea el rig a partir del resultado de fitHumanoid().
export function createRig(fit) {
  const joints = fit.joints.map((j) => [...j]);
  const local = joints.map((j, i) => (PARENTS[i] < 0 ? [...j] : v3.sub(j, joints[PARENTS[i]])));
  const tips = Object.fromEntries(Object.entries(fit.tips).map(([k, v]) => [k, [...v]]));
  const rig = {
    version: 1,
    names: [...BONE_NAMES],
    parents: [...PARENTS],
    joints,
    local,
    tips,
    radii: [...fit.radii],
    heelBack: [...fit.heelBack],
    height: fit.height,
    orientation: fit.orientation,
    pose: fit.pose,
    confidence: fit.confidence,
  };
  rig.measures = measuresOf(rig);
  return rig;
}

// Medidas del cuerpo que usan las animaciones.
export function measuresOf(rig) {
  const J = rig.joints;
  const side = (n) => ({
    hip: J[IDX[`${n}UpperLeg`]],
    knee: J[IDX[`${n}LowerLeg`]],
    ankle: J[IDX[`${n}Foot`]],
    toe: rig.tips[`toe${n}`],
    shoulder: J[IDX[`${n}UpperArm`]],
    elbow: J[IDX[`${n}LowerArm`]],
    wrist: J[IDX[`${n}Hand`]],
    handTip: rig.tips[`hand${n}`],
  });
  const L = side('Left'), R = side('Right');
  const thigh = (v3.dist(L.hip, L.knee) + v3.dist(R.hip, R.knee)) / 2;
  const shin = (v3.dist(L.knee, L.ankle) + v3.dist(R.knee, R.ankle)) / 2;
  const hipMid = avg(L.hip, R.hip);
  const ankleH = (L.ankle[1] + R.ankle[1]) / 2;
  return {
    height: rig.height,
    thigh,
    shin,
    legLen: thigh + shin,
    hipY: hipMid[1],
    hipHalf: Math.abs(L.hip[0] - R.hip[0]) / 2,
    ankleH,
    ankleHalf: Math.abs(L.ankle[0] - R.ankle[0]) / 2,
    // Pie: largo hacia delante desde el tobillo, caída de la punta y talón.
    footFwd: [L.toe[2] - L.ankle[2], R.toe[2] - R.ankle[2]],
    toeDrop: [L.ankle[1] - L.toe[1], R.ankle[1] - R.toe[1]],
    heelBack: rig.heelBack,
    upperArm: (v3.dist(L.shoulder, L.elbow) + v3.dist(R.shoulder, R.elbow)) / 2,
    foreArm: (v3.dist(L.elbow, L.wrist) + v3.dist(R.elbow, R.wrist)) / 2,
    handLen: (v3.dist(L.wrist, L.handTip) + v3.dist(R.wrist, R.handTip)) / 2,
    shoulderHalf: Math.abs(L.shoulder[0] - R.shoulder[0]) / 2,
    shoulderY: (L.shoulder[1] + R.shoulder[1]) / 2,
    hipsY: J[IDX.Hips][1],
    neckY: J[IDX.Neck][1],
    headY: J[IDX.Head][1],
  };
}

// Segmentos (cabeza → cola) de cada hueso, para calcular pesos. Float64Array(19 × 6).
export function boneSegments(rig) {
  const J = rig.joints, T = rig.tips;
  const out = new Float64Array(BONE_COUNT * 6);
  const set = (b, h, t) => {
    out.set(h, b * 6);
    out.set(t, b * 6 + 3);
  };
  const hipY = (J[IDX.LeftUpperLeg][1] + J[IDX.RightUpperLeg][1]) / 2;
  set(IDX.Hips, [J[IDX.Hips][0], hipY - 0.03 * rig.height, J[IDX.Hips][2]], J[IDX.Spine]);
  set(IDX.Spine, J[IDX.Spine], J[IDX.Chest]);
  set(IDX.Chest, J[IDX.Chest], J[IDX.Neck]);
  set(IDX.Neck, J[IDX.Neck], J[IDX.Head]);
  set(IDX.Head, J[IDX.Head], T.head);
  for (const n of ['Left', 'Right']) {
    set(IDX[`${n}Shoulder`], J[IDX[`${n}Shoulder`]], J[IDX[`${n}UpperArm`]]);
    set(IDX[`${n}UpperArm`], J[IDX[`${n}UpperArm`]], J[IDX[`${n}LowerArm`]]);
    set(IDX[`${n}LowerArm`], J[IDX[`${n}LowerArm`]], J[IDX[`${n}Hand`]]);
    set(IDX[`${n}Hand`], J[IDX[`${n}Hand`]], T[`hand${n}`]);
    set(IDX[`${n}UpperLeg`], J[IDX[`${n}UpperLeg`]], J[IDX[`${n}LowerLeg`]]);
    set(IDX[`${n}LowerLeg`], J[IDX[`${n}LowerLeg`]], J[IDX[`${n}Foot`]]);
    // El pie (para los pesos) arranca en el centro del talón, no en el tobillo: si no, el talón y la parte trasera de la
    // planta quedaban más cerca de la espinilla (ambas terminan en el tobillo, y la espinilla tiene más radio) y se
    // movían con ella en vez de con el pie.
    const ank = J[IDX[`${n}Foot`]];
    const hb = rig.heelBack[n === 'Left' ? 0 : 1];
    set(IDX[`${n}Foot`], [ank[0], 0.5 * ank[1], ank[2] - 0.85 * hb], T[`toe${n}`]);
  }
  return out;
}

// ── Poses ────────────────────────────────────────────────────────────────────────────────────
export const restPose = () => ({ root: [0, 0, 0], world: Array.from({ length: BONE_COUNT }, () => [...Q_IDENTITY]) });
export const clonePose = (p) => ({ root: [...p.root], world: p.world.map((q) => [...q]) });

// Mezcla dos poses interpolando el giro LOCAL de cada articulación (respecto a su padre), no el giro de mundo.
// Con giros de mundo, un antebrazo colgando y otro levantado difieren ~180° y el camino más corto cambia de lado
// a mitad de la mezcla (la mano da un salto). En local, cada articulación gira poco y la mezcla es continua.
export function blendPose(a, b, t) {
  if (t <= 0) return clonePose(a);
  if (t >= 1) return clonePose(b);
  const world = new Array(BONE_COUNT);
  for (let i = 0; i < BONE_COUNT; i++) {
    const p = PARENTS[i];
    if (p < 0) {
      world[i] = qSlerp(a.world[i], b.world[i], t);
    } else {
      const la = qMul(qConj(a.world[p]), a.world[i]);
      const lb = qMul(qConj(b.world[p]), b.world[i]);
      world[i] = qMul(world[p], qSlerp(la, lb, t));
    }
  }
  return { root: v3.lerp(a.root, b.root, t), world };
}

// Posiciones de todas las articulaciones tras la pose (cinemática directa).
export function poseJoints(rig, pose) {
  const pos = new Array(BONE_COUNT);
  for (let i = 0; i < BONE_COUNT; i++) {
    const p = PARENTS[i];
    pos[i] = p < 0 ? v3.add(rig.joints[0], pose.root) : v3.add(pos[p], qRotate(pose.world[p], rig.local[i]));
  }
  return pos;
}

// Giros locales (lo que se escribe en bone.quaternion) y posición local de la raíz.
export function poseToLocal(rig, pose) {
  const q = new Array(BONE_COUNT);
  for (let i = 0; i < BONE_COUNT; i++) q[i] = PARENTS[i] < 0 ? [...pose.world[i]] : qMul(qConj(pose.world[PARENTS[i]]), pose.world[i]);
  return { quats: q, rootPos: v3.add(rig.joints[0], pose.root) };
}

// Skinning lineal en CPU (mismo resultado que el de la GPU). Devuelve posiciones nuevas.
export function skinPositions(rig, pose, positions, skinIndex, skinWeight) {
  const pos = poseJoints(rig, pose);
  const out = new Float32Array(positions.length);
  const n = positions.length / 3;
  // Matriz por hueso: rotación como 9 números + traslación efectiva (pos − R·reposo).
  const R = pos.map((_, b) => {
    const q = pose.world[b];
    const c0 = qRotate(q, [1, 0, 0]), c1 = qRotate(q, [0, 1, 0]), c2 = qRotate(q, [0, 0, 1]);
    const t = v3.sub(pos[b], qRotate(q, rig.joints[b]));
    return [c0[0], c1[0], c2[0], c0[1], c1[1], c2[1], c0[2], c1[2], c2[2], t[0], t[1], t[2]];
  });
  for (let v = 0; v < n; v++) {
    const x = positions[v * 3], y = positions[v * 3 + 1], z = positions[v * 3 + 2];
    let ox = 0, oy = 0, oz = 0;
    for (let k = 0; k < 4; k++) {
      const w = skinWeight[v * 4 + k];
      if (w === 0) continue;
      const m = R[skinIndex[v * 4 + k]];
      ox += w * (m[0] * x + m[1] * y + m[2] * z + m[9]);
      oy += w * (m[3] * x + m[4] * y + m[5] * z + m[10]);
      oz += w * (m[6] * x + m[7] * y + m[8] * z + m[11]);
    }
    out[v * 3] = ox;
    out[v * 3 + 1] = oy;
    out[v * 3 + 2] = oz;
  }
  return out;
}

// Cuaternión → número finito comprobado (para pruebas).
export const poseIsFinite = (pose) => pose.root.every(Number.isFinite) && pose.world.every((q) => q.every(Number.isFinite));
