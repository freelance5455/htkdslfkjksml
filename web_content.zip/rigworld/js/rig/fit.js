// Ajuste automático del esqueleto de 19 huesos sobre una malla humanoide estática (sin red neuronal).
//
// 1. Orientación: eje vertical (Y o Z), hacia dónde mira (por la posición de los pies respecto a las
//    espinillas) y centrado en el suelo. El resultado es el «marco canónico»: Y arriba, +Z al frente,
//    +X el lado izquierdo del personaje, pies en y = 0.
// 2. Puntos de referencia: altura de la entrepierna, del cuello y de los tobillos a partir de cortes
//    horizontales de la malla.
// 3. Ajuste por modelo de cápsulas: se buscan el ángulo de cada brazo (T, A o pegado al cuerpo), la
//    apertura de cada pierna y los anchos de hombros y caderas que mejor explican la nube de puntos
//    (distancia de los puntos a los huesos + cobertura de los huesos dentro del volumen). Después se
//    afinan codos y rodillas y se mide el radio real del cuerpo alrededor de cada hueso.
//
// Todo son funciones puras sobre arrays, así que se ejecuta igual en el Worker, el hilo principal y Node.
import { BONE_NAMES } from '../core/skeletonTemplate.js';
import { DEG, clamp, lerp, v3 } from './mathq.js';

export const IDX = Object.freeze(Object.fromEntries(BONE_NAMES.map((n, i) => [n, i])));
export const FIT_VERSION = 1;

// Radio típico del cuerpo alrededor de cada hueso, como fracción de la altura (cuerpo humano medio).
const RADIUS_FRAC = {
  Hips: 0.085, Spine: 0.085, Chest: 0.095, Neck: 0.032, Head: 0.06,
  LeftShoulder: 0.045, LeftUpperArm: 0.034, LeftLowerArm: 0.028, LeftHand: 0.022,
  RightShoulder: 0.045, RightUpperArm: 0.034, RightLowerArm: 0.028, RightHand: 0.022,
  LeftUpperLeg: 0.058, LeftLowerLeg: 0.038, LeftFoot: 0.03,
  RightUpperLeg: 0.058, RightLowerLeg: 0.038, RightFoot: 0.03,
};
const ARM_LEN = 0.332; // hombro → muñeca, fracción de la altura
const HAND_LEN = 0.095;
const ANKLE_FRAC = 0.045;

// ── Orientación ─────────────────────────────────────────────────────────────────────────────
const mapUp = (x, y, z, up) => (up === 'z' ? [x, z, -y] : [x, y, z]);

// Lleva posiciones del archivo al marco canónico. orientation = { up, yaw, offset }.
export function applyOrientation(positions, o) {
  const out = new Float32Array(positions.length);
  const c = Math.cos(o.yaw), s = Math.sin(o.yaw);
  const up = o.up;
  for (let i = 0; i < positions.length; i += 3) {
    let x = positions[i], y = positions[i + 1], z = positions[i + 2];
    if (up === 'z') {
      const t = y;
      y = z;
      z = -t;
    }
    out[i] = x * c + z * s + o.offset[0];
    out[i + 1] = y + o.offset[1];
    out[i + 2] = -x * s + z * c + o.offset[2];
  }
  return out;
}

// Igual pero solo giro (sirve para normales).
export function applyOrientationRotation(vectors, o) {
  const out = new Float32Array(vectors.length);
  const c = Math.cos(o.yaw), s = Math.sin(o.yaw);
  for (let i = 0; i < vectors.length; i += 3) {
    let x = vectors[i], y = vectors[i + 1], z = vectors[i + 2];
    if (o.up === 'z') {
      const t = y;
      y = z;
      z = -t;
    }
    out[i] = x * c + z * s;
    out[i + 1] = y;
    out[i + 2] = -x * s + z * c;
  }
  return out;
}

function gather(meshes) {
  let n = 0;
  for (const m of meshes) n += m.positions.length;
  const all = new Float32Array(n);
  let o = 0;
  for (const m of meshes) {
    all.set(m.positions, o);
    o += m.positions.length;
  }
  return all;
}

function sample(P, maxPts) {
  const n = P.length / 3;
  const stride = Math.max(1, Math.floor(n / maxPts));
  const out = new Float32Array(Math.ceil(n / stride) * 3);
  let k = 0;
  for (let i = 0; i < n; i += stride) {
    out[k++] = P[i * 3];
    out[k++] = P[i * 3 + 1];
    out[k++] = P[i * 3 + 2];
  }
  return out.subarray(0, k);
}

function bboxOf(P) {
  const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < P.length; i += 3) {
    for (let k = 0; k < 3; k++) {
      const v = P[i + k];
      if (v < mn[k]) mn[k] = v;
      if (v > mx[k]) mx[k] = v;
    }
  }
  return { min: mn, max: mx };
}

// ¿Hay «dos piernas» si `up` fuera el eje vertical? En el tramo bajo del cuerpo (10 %–36 % de la
// altura desde el extremo inferior) debe verse un hueco entre dos columnas separadas.
function hasTwoLegs(S, box, axis) {
  const ui = axis === 'z' ? 2 : 1;
  const others = ui === 2 ? [0, 1] : [0, 2];
  const u0 = box.min[ui], span = box.max[ui] - box.min[ui];
  if (span < 1e-9) return false;
  for (const flip of [false, true]) {
    const slab = [];
    for (let i = 0; i < S.length; i += 3) {
      const t = (S[i + ui] - u0) / span;
      const tt = flip ? 1 - t : t;
      if (tt > 0.1 && tt < 0.36) slab.push(i);
    }
    if (slab.length < 40) continue;
    for (const o of others) {
      const lo = box.min[o], ext = box.max[o] - box.min[o];
      if (ext < 1e-9) continue;
      const bins = new Int32Array(48);
      for (const i of slab) bins[Math.min(47, Math.floor(((S[i + o] - lo) / ext) * 48))]++;
      let first = -1, last = -1;
      for (let b = 0; b < 48; b++) if (bins[b] >= 2) {
        if (first < 0) first = b;
        last = b;
      }
      let run = 0, best = 0;
      for (let b = first; b <= last && first >= 0; b++) {
        run = bins[b] < 2 ? run + 1 : 0;
        if (run > best) best = run;
      }
      if (best >= 2) return true;
    }
  }
  return false;
}

function detectUp(S, box) {
  const two = [hasTwoLegs(S, box, 'y'), hasTwoLegs(S, box, 'z')];
  const ex = box.max[0] - box.min[0], ey = box.max[1] - box.min[1], ez = box.max[2] - box.min[2];
  if (two[0] !== two[1]) {
    // Control de plausibilidad: un humanoide de pie no puede ser mucho más bajo en su eje vertical que en los otros
    // (con las piernas fundidas en una sola masa, un falso positivo en Z daba «altura 0,34 y envergadura 1,49»).
    const cand = two[0] ? 'y' : 'z';
    const up = cand === 'y' ? ey : ez;
    const others = cand === 'y' ? Math.max(ex, ez) : Math.max(ex, ey);
    if (up >= 0.45 * others) return cand;
  }
  return ez > 1.25 * ey && ez > 0.6 * ex ? 'z' : 'y';
}

// Hacia dónde mira: el centro de los pies queda delante del de las espinillas. Devuelve el giro (rad)
// alrededor de Y que lo lleva a +Z, y la fiabilidad (longitud del vector respecto a la altura).
function detectYaw(S, minY, H) {
  let fx = 0, fz = 0, fn = 0, sx = 0, sz = 0, sn = 0;
  for (let i = 0; i < S.length; i += 3) {
    const y = S[i + 1] - minY;
    if (y < 0.035 * H) {
      fx += S[i];
      fz += S[i + 2];
      fn++;
    } else if (y > 0.12 * H && y < 0.2 * H) {
      sx += S[i];
      sz += S[i + 2];
      sn++;
    }
  }
  if (fn < 8 || sn < 8) return { yaw: 0, strength: 0 };
  const vx = fx / fn - sx / sn, vz = fz / fn - sz / sn;
  const strength = Math.hypot(vx, vz) / H;
  // Sin señal clara (pies simétricos bajo la espinilla) el ángulo sería ruido y podría girar el modelo al azar:
  // se respeta la convención de glTF/FBX (+Z al frente) y el aviso invita a usar «Girar 90°» si hace falta.
  if (strength < 0.006) return { yaw: 0, strength };
  let yaw = Math.atan2(-vx, vz);
  const q = Math.round(yaw / (Math.PI / 2)) * (Math.PI / 2);
  // Los modelos suelen venir alineados a los ejes. Con las piernas abiertas la estimación se desvía hasta ~0,35 rad,
  // por eso la tolerancia es amplia; una rotación intermedia de verdad (≥ 0,5 rad del cuarto de vuelta) se respeta.
  if (Math.abs(yaw - q) < 0.5) yaw = q;
  return { yaw, strength };
}

// ── Referencias del cuerpo (sobre el marco canónico) ──────────────────────────────────────────
function detectCrotch(P, H) {
  const y0 = 0.28 * H, bin = 0.01 * H, nb = 38;
  const counts = new Int32Array(nb);
  for (let i = 0; i < P.length; i += 3) {
    if (Math.abs(P[i]) > 0.012 * H) continue;
    const b = Math.floor((P[i + 1] - y0) / bin);
    if (b >= 0 && b < nb) counts[b]++;
  }
  if (counts[0] >= 3 || counts[1] >= 3) return null; // piernas pegadas: no hay hueco que medir
  for (let k = 2; k < nb - 2; k++) {
    if (counts[k] >= 3 && counts[k + 1] >= 3 && counts[k + 2] >= 3) return y0 + (k - 0.5) * bin;
  }
  return null;
}

function detectNeck(P, H) {
  const y0 = 0.7 * H, bin = 0.005 * H, nb = 50;
  const mn = new Float32Array(nb).fill(Infinity), mx = new Float32Array(nb).fill(-Infinity), cnt = new Int32Array(nb);
  for (let i = 0; i < P.length; i += 3) {
    const x = P[i];
    if (Math.abs(x) > 0.11 * H) continue;
    const b = Math.floor((P[i + 1] - y0) / bin);
    if (b < 0 || b >= nb) continue;
    cnt[b]++;
    if (x < mn[b]) mn[b] = x;
    if (x > mx[b]) mx[b] = x;
  }
  let best = -1, bw = Infinity;
  const lo = Math.floor(0.04 * H / bin), hi = Math.floor(0.23 * H / bin);
  for (let b = lo; b < Math.min(nb, hi); b++) {
    if (cnt[b] < 4) continue;
    const w = mx[b] - mn[b];
    if (w < bw) {
      bw = w;
      best = b;
    }
  }
  if (best < 0) return null;
  // Centro de la zona estrecha: contigua al mínimo y dentro de un 25 % de él.
  let a = best, z = best;
  while (a > 0 && cnt[a - 1] >= 4 && mx[a - 1] - mn[a - 1] <= bw * 1.25 + 0.004 * H) a--;
  while (z < nb - 1 && cnt[z + 1] >= 4 && mx[z + 1] - mn[z + 1] <= bw * 1.25 + 0.004 * H) z++;
  return y0 + ((a + z) / 2 + 0.5) * bin;
}

function meanZ(S, pred) {
  let z = 0, n = 0;
  for (let i = 0; i < S.length; i += 3) {
    if (pred(S[i], S[i + 1], S[i + 2])) {
      z += S[i + 2];
      n++;
    }
  }
  return n >= 4 ? z / n : null;
}

// ── Campo de distancias al cuerpo (transformada de distancia 3D por chaflán) ──────────────────
function buildField(S, H) {
  const box = bboxOf(S);
  const h = H / 70;
  const m = 3;
  const nx = Math.ceil((box.max[0] - box.min[0]) / h) + 2 * m + 1;
  const ny = Math.ceil((box.max[1] - box.min[1]) / h) + 2 * m + 1;
  const nz = Math.ceil((box.max[2] - box.min[2]) / h) + 2 * m + 1;
  const d = new Float32Array(nx * ny * nz).fill(1e9);
  const at = (i, j, k) => i + nx * (j + ny * k);
  for (let p = 0; p < S.length; p += 3) {
    const i = Math.round((S[p] - box.min[0]) / h) + m, j = Math.round((S[p + 1] - box.min[1]) / h) + m, k = Math.round((S[p + 2] - box.min[2]) / h) + m;
    d[at(i, j, k)] = 0;
  }
  const W = (a, b, c) => (a + b + c === 1 ? 3 : a + b + c === 2 ? 4 : 5);
  const fwd = [], bwd = [];
  for (let dk = -1; dk <= 1; dk++) for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) {
    if (!di && !dj && !dk) continue;
    const w = W(Math.abs(di), Math.abs(dj), Math.abs(dk));
    const first = dk < 0 || (dk === 0 && (dj < 0 || (dj === 0 && di < 0)));
    (first ? fwd : bwd).push([di, dj, dk, w]);
  }
  const pass = (list, rev) => {
    for (let kk = 0; kk < nz; kk++) {
      const k = rev ? nz - 1 - kk : kk;
      for (let jj = 0; jj < ny; jj++) {
        const j = rev ? ny - 1 - jj : jj;
        for (let ii = 0; ii < nx; ii++) {
          const i = rev ? nx - 1 - ii : ii;
          let best = d[at(i, j, k)];
          for (const [di, dj, dk, w] of list) {
            const a = i + di, b = j + dj, c = k + dk;
            if (a < 0 || b < 0 || c < 0 || a >= nx || b >= ny || c >= nz) continue;
            const v = d[at(a, b, c)] + w;
            if (v < best) best = v;
          }
          d[at(i, j, k)] = best;
        }
      }
    }
  };
  pass(fwd, false);
  pass(bwd, true);
  return {
    // Distancia (en las unidades del modelo) del punto p a la nube de puntos más cercana.
    at(x, y, z) {
      const i = clamp(Math.round((x - box.min[0]) / h) + m, 0, nx - 1);
      const j = clamp(Math.round((y - box.min[1]) / h) + m, 0, ny - 1);
      const k = clamp(Math.round((z - box.min[2]) / h) + m, 0, nz - 1);
      return (d[at(i, j, k)] / 3) * h;
    },
  };
}

// ── Modelo de cápsulas ────────────────────────────────────────────────────────────────────────
function buildModel(p, c) {
  const { H } = c;
  const J = new Array(19);
  const hipY = c.hipY;
  J[IDX.Hips] = [0, hipY + 0.012 * H, c.zAt(hipY)];
  const yS = lerp(J[IDX.Hips][1], c.neckY, 0.28), yC = lerp(J[IDX.Hips][1], c.neckY, 0.64);
  J[IDX.Spine] = [0, yS, c.zAt(yS)];
  J[IDX.Chest] = [0, yC, c.zAt(yC)];
  J[IDX.Neck] = [0, c.neckY, c.zAt(c.neckY)];
  J[IDX.Head] = [0, c.headY, c.zHead];
  const tips = { head: [0, H, c.zHead] };
  [['Left', 1, 0], ['Right', -1, 1]].forEach(([name, s, side]) => {
    const zc = c.zAt(p.shY);
    J[IDX[`${name}Shoulder`]] = [s * 0.38 * p.shHalf, p.shY + 0.012 * H, zc];
    const ua = [s * p.shHalf, p.shY, zc];
    J[IDX[`${name}UpperArm`]] = ua;
    const a = p.abd[side] * DEG;
    const dir = [s * Math.sin(a), -Math.cos(a), 0];
    const len = c.armLen[side];
    const eo = c.elbowOff[side];
    J[IDX[`${name}LowerArm`]] = [ua[0] + dir[0] * len * 0.56 + eo[0], ua[1] + dir[1] * len * 0.56 + eo[1], ua[2] + dir[2] * len * 0.56 + eo[2]];
    const wr = [ua[0] + dir[0] * len, ua[1] + dir[1] * len, ua[2] + dir[2] * len];
    J[IDX[`${name}Hand`]] = wr;
    const el = J[IDX[`${name}LowerArm`]];
    const fd = [wr[0] - el[0], wr[1] - el[1], wr[2] - el[2]];
    const fl = Math.hypot(...fd) || 1;
    tips[`hand${name}`] = [wr[0] + (fd[0] / fl) * c.handLen, wr[1] + (fd[1] / fl) * c.handLen, wr[2] + (fd[2] / fl) * c.handLen];

    const hip = [s * p.hipHalf, hipY, c.zAt(hipY)];
    J[IDX[`${name}UpperLeg`]] = hip;
    const sp = p.splay[side] * DEG;
    const L = (hipY - c.ankleY) / Math.cos(sp);
    const ank = [hip[0] + s * Math.sin(sp) * L, c.ankleY, c.zShin[side]];
    J[IDX[`${name}Foot`]] = ank;
    const ko = c.kneeOff[side];
    J[IDX[`${name}LowerLeg`]] = [(hip[0] + ank[0]) / 2 + ko[0], (hip[1] + ank[1]) / 2 + ko[1], (hip[2] + ank[2]) / 2 + ko[2]];
    tips[`toe${name}`] = [ank[0], c.toeY, ank[2] + c.footFwd[side]];
  });
  return { J, tips };
}

function segmentsOf(J, tips, c) {
  const S = new Float64Array(19 * 6);
  const set = (b, h, t) => {
    S.set(h, b * 6);
    S.set(t, b * 6 + 3);
  };
  set(IDX.Hips, [J[IDX.Hips][0], c.hipY - 0.03 * c.H, J[IDX.Hips][2]], J[IDX.Spine]);
  set(IDX.Spine, J[IDX.Spine], J[IDX.Chest]);
  set(IDX.Chest, J[IDX.Chest], J[IDX.Neck]);
  set(IDX.Neck, J[IDX.Neck], J[IDX.Head]);
  set(IDX.Head, J[IDX.Head], tips.head);
  for (const name of ['Left', 'Right']) {
    set(IDX[`${name}Shoulder`], J[IDX[`${name}Shoulder`]], J[IDX[`${name}UpperArm`]]);
    set(IDX[`${name}UpperArm`], J[IDX[`${name}UpperArm`]], J[IDX[`${name}LowerArm`]]);
    set(IDX[`${name}LowerArm`], J[IDX[`${name}LowerArm`]], J[IDX[`${name}Hand`]]);
    set(IDX[`${name}Hand`], J[IDX[`${name}Hand`]], tips[`hand${name}`]);
    set(IDX[`${name}UpperLeg`], J[IDX[`${name}UpperLeg`]], J[IDX[`${name}LowerLeg`]]);
    set(IDX[`${name}LowerLeg`], J[IDX[`${name}LowerLeg`]], J[IDX[`${name}Foot`]]);
    set(IDX[`${name}Foot`], J[IDX[`${name}Foot`]], tips[`toe${name}`]);
  }
  return S;
}

// Distancia de un punto a un segmento (a partir de un Float64Array de segmentos).
function segDist(x, y, z, S, b) {
  const o = b * 6;
  const ax = S[o], ay = S[o + 1], az = S[o + 2];
  const bx = S[o + 3] - ax, by = S[o + 4] - ay, bz = S[o + 5] - az;
  const px = x - ax, py = y - ay, pz = z - az;
  const l2 = bx * bx + by * by + bz * bz;
  const t = l2 > 1e-12 ? clamp((px * bx + py * by + pz * bz) / l2, 0, 1) : 0;
  return Math.hypot(px - bx * t, py - by * t, pz - bz * t);
}

function costOf(segs, R, pts, field) {
  let data = 0;
  const n = pts.length / 3;
  for (let i = 0; i < pts.length; i += 3) {
    let best = Infinity;
    for (let b = 0; b < 19; b++) {
      const d = segDist(pts[i], pts[i + 1], pts[i + 2], segs, b) / R[b];
      if (d < best) best = d;
    }
    const q = best * best;
    data += q < 4 ? q : 4;
  }
  data /= n;
  // Cobertura: los huesos deben quedar dentro del volumen, no flotando en el aire.
  let cover = 0, cn = 0;
  for (let b = 0; b < 19; b++) {
    for (const t of [0.15, 0.5, 0.85]) {
      const o = b * 6;
      const x = segs[o] + (segs[o + 3] - segs[o]) * t, y = segs[o + 1] + (segs[o + 4] - segs[o + 1]) * t, z = segs[o + 2] + (segs[o + 5] - segs[o + 2]) * t;
      const d = field.at(x, y, z) / R[b] - 1.6;
      if (d > 0) cover += Math.min(4, d * d);
      cn++;
    }
  }
  return data + 0.6 * (cover / cn);
}

function descend(p, specs, evalFn, rounds) {
  let best = evalFn(p);
  for (const m of rounds) {
    for (const s of specs) {
      const base = s.get(p);
      let bv = base, bc = best;
      for (const k of [-2, -1, 1, 2]) {
        const v = clamp(base + k * s.step * m, s.lo, s.hi);
        if (v === base) continue;
        s.set(p, v);
        const c = evalFn(p);
        if (c < bc - 1e-9) {
          bc = c;
          bv = v;
        }
      }
      s.set(p, bv);
      best = bc;
    }
  }
  return best;
}

// ── Ajuste completo ───────────────────────────────────────────────────────────────────────────
export function fitHumanoid(meshes, { up = 'auto', yawOffset = 0, onProgress } = {}) {
  const warnings = [];
  const raw = gather(meshes);
  if (raw.length < 9 * 4) throw new Error('El modelo tiene muy poca geometría para crear un esqueleto.');
  onProgress?.(0.02);

  // 1. Orientación
  const rawBox = bboxOf(raw);
  const upAxis = up === 'auto' ? detectUp(sample(raw, 14000), rawBox) : up;
  const probe = { up: upAxis, yaw: 0, offset: [0, 0, 0] };
  let U = applyOrientation(raw, probe);
  const ubox = bboxOf(U);
  const H0 = ubox.max[1] - ubox.min[1];
  const Su = sample(U, 14000);
  const facing = detectYaw(Su, ubox.min[1], H0);
  if (facing.strength < 0.006) warnings.push('No pude saber hacia dónde mira el modelo. Si el personaje sale de espaldas o de lado, usa «Girar 90°».');
  const yaw = facing.yaw + yawOffset;
  const orientation = { up: upAxis, yaw, offset: [0, 0, 0] };
  let P = applyOrientation(raw, orientation);
  let S = sample(P, 14000);
  // Centro: pies/caderas para X, torso para Z; suelo en y = 0.
  const pb = bboxOf(P);
  const H1 = pb.max[1] - pb.min[1];
  let cx = 0, nx = 0, cz = 0, nz = 0;
  for (let i = 0; i < S.length; i += 3) {
    const y = S[i + 1] - pb.min[1];
    if (y > 0.05 * H1 && y < 0.6 * H1) {
      cx += S[i];
      nx++;
    }
    if (y > 0.5 * H1 && y < 0.7 * H1) {
      cz += S[i + 2];
      nz++;
    }
  }
  orientation.offset = [nx ? -cx / nx : 0, -pb.min[1], nz ? -cz / nz : 0];
  P = applyOrientation(raw, orientation);
  S = sample(P, 14000);
  const H = H1;
  onProgress?.(0.1);
  if (H < 1e-6) throw new Error('El modelo no tiene altura.');

  // 2. Referencias
  // Una entrepierna humana está a 0,45–0,49 H. Si el hueco entre las piernas «empieza» por debajo de 0,41 H, es que los
  // muslos se tocan y se fundieron en la malla desde la rodilla: ese nivel no es la entrepierna, se usa la proporción.
  const crotchRaw = detectCrotch(P, H);
  const crotch = crotchRaw != null && crotchRaw >= 0.41 * H ? crotchRaw : null;
  const hipY = crotch != null ? crotch + 0.045 * H : 0.515 * H;
  if (crotch == null) warnings.push('Las piernas están pegadas: la altura de la cadera se estimó con proporciones humanas.');
  const neckC = detectNeck(P, H);
  const neckY = neckC != null ? neckC - 0.055 * H : 0.815 * H;
  const headY = clamp((neckC != null ? neckC + 0.005 * H : 0.88 * H), neckY + 0.03 * H, 0.93 * H);
  if (neckC == null) warnings.push('No encontré el cuello; se usaron proporciones humanas.');
  const zAt = (() => {
    const cache = new Map();
    return (y) => {
      const key = Math.round(y / (0.01 * H));
      if (!cache.has(key)) cache.set(key, meanZ(S, (x, yy) => Math.abs(x) < 0.09 * H && Math.abs(yy - y) < 0.03 * H) ?? 0);
      return cache.get(key);
    };
  })();
  const zHead = meanZ(S, (x, y) => y > headY) ?? 0;
  const ankleY = ANKLE_FRAC * H;
  const zShin = [1, -1].map((s) => meanZ(S, (x, y) => s * x > 0.01 * H && y > 0.1 * H && y < 0.17 * H) ?? 0);
  const footFwd = [1, -1].map((s, side) => {
    let zmax = -Infinity;
    for (let i = 0; i < P.length; i += 3) {
      if (P[i + 1] < 0.07 * H && s * P[i] > 0.01 * H && P[i + 2] > zmax) zmax = P[i + 2];
    }
    const f = zmax - zShin[side];
    return Number.isFinite(f) && f > 0.05 * H ? Math.min(f, 0.2 * H) : 0.1 * H;
  });
  const ctx = {
    H, hipY, neckY, headY, zAt, zHead, ankleY, zShin, footFwd,
    toeY: ankleY * 0.3,
    armLen: [ARM_LEN * H, ARM_LEN * H],
    handLen: HAND_LEN * H,
    elbowOff: [[0, 0, 0], [0, 0, 0]],
    kneeOff: [[0, 0, 0], [0, 0, 0]],
  };
  const R = new Float64Array(19);
  BONE_NAMES.forEach((n, i) => (R[i] = RADIUS_FRAC[n] * H));
  onProgress?.(0.2);

  // 3. Ajuste de cápsulas
  const field = buildField(S, H);
  const pts = sample(S, 2000);
  const p = { shHalf: 0.115 * H, shY: neckY - 0.012 * H, abd: [45, 45], hipHalf: 0.065 * H, splay: [4, 4] };
  const evalP = (q) => {
    const m = buildModel(q, ctx);
    const sh = (q.shHalf - 0.115 * H) / (0.03 * H), hp = (q.hipHalf - 0.065 * H) / (0.02 * H);
    // Los anchos de hombros y caderas tienen un valor a priori suave (proporciones humanas).
    return costOf(segmentsOf(m.J, m.tips, ctx), R, pts, field) + 0.04 * sh * sh + 0.03 * hp * hp;
  };
  // Búsqueda inicial por barrido de los ángulos (cada brazo y cada pierna es casi independiente).
  for (const side of [0, 1]) {
    let bc = Infinity, bv = 45;
    for (let a = 0; a <= 100; a += 10) {
      p.abd[side] = a;
      const c = evalP(p);
      if (c < bc) {
        bc = c;
        bv = a;
      }
    }
    p.abd[side] = bv;
    bc = Infinity;
    bv = 4;
    for (const sp of [0, 4, 9, 15, 22, 30]) {
      p.splay[side] = sp;
      const c = evalP(p);
      if (c < bc) {
        bc = c;
        bv = sp;
      }
    }
    p.splay[side] = bv;
  }
  onProgress?.(0.4);
  const specs = [
    { get: (q) => q.shHalf, set: (q, v) => (q.shHalf = v), lo: 0.06 * H, hi: 0.2 * H, step: 0.015 * H },
    { get: (q) => q.shY, set: (q, v) => (q.shY = v), lo: neckY - 0.1 * H, hi: neckY + 0.01 * H, step: 0.012 * H },
    { get: (q) => q.abd[0], set: (q, v) => (q.abd[0] = v), lo: -8, hi: 110, step: 6 },
    { get: (q) => q.abd[1], set: (q, v) => (q.abd[1] = v), lo: -8, hi: 110, step: 6 },
    { get: (q) => q.hipHalf, set: (q, v) => (q.hipHalf = v), lo: 0.03 * H, hi: 0.12 * H, step: 0.01 * H },
    { get: (q) => q.splay[0], set: (q, v) => (q.splay[0] = v), lo: -6, hi: 38, step: 4 },
    { get: (q) => q.splay[1], set: (q, v) => (q.splay[1] = v), lo: -6, hi: 38, step: 4 },
  ];
  descend(p, specs, evalP, [1, 0.5, 0.25]);
  onProgress?.(0.6);

  // Longitud de los brazos medida en la malla (solo si es creíble; si no, proporciones humanas).
  [1, -1].forEach((s, side) => {
    const a = p.abd[side] * DEG;
    const dir = [s * Math.sin(a), -Math.cos(a), 0];
    const origin = [s * p.shHalf, p.shY, ctx.zAt(p.shY)];
    const bins = new Float32Array(80).fill(0);
    for (let i = 0; i < S.length; i += 3) {
      const rx = S[i] - origin[0], ry = S[i + 1] - origin[1], rz = S[i + 2] - origin[2];
      const t = rx * dir[0] + ry * dir[1] + rz * dir[2];
      const d = Math.hypot(rx - dir[0] * t, ry - dir[1] * t, rz - dir[2] * t);
      if (d < 0.04 * H && t > 0 && t < 0.8 * H) bins[Math.floor(t / (0.01 * H))]++;
    }
    let end = 0, gap = 0;
    for (let b = 0; b < 80; b++) {
      if (bins[b] > 0) {
        end = b;
        gap = 0;
      } else if (++gap >= 4) break;
    }
    const total = (end + 1) * 0.01 * H;
    const expect = (ARM_LEN + HAND_LEN) * H;
    if (total > 0.8 * expect && total < 1.2 * expect) ctx.armLen[side] = total - HAND_LEN * H;
  });
  descend(p, specs.slice(2, 4), evalP, [0.5, 0.25]);

  // Codos y rodillas: ajuste fino, solo en dirección perpendicular al miembro. A lo largo del eje un
  // brazo o pierna recto no revela dónde está la articulación, así que ahí se mantiene la proporción humana.
  const refine = (key, side, endA, endB) => {
    const off = ctx[key][side];
    const m0 = buildModel(p, ctx);
    const A = m0.J[endA], B = m0.J[endB];
    const u = v3.norm(v3.sub(B, A));
    let e1 = v3.cross(u, [0, 0, 1]);
    if (v3.len(e1) < 0.3) e1 = v3.cross(u, [1, 0, 0]);
    e1 = v3.norm(e1);
    const e2 = v3.cross(u, e1);
    let best = evalP(p);
    const lim = 0.05 * H;
    for (const step of [0.02 * H, 0.01 * H]) {
      for (let it = 0; it < 4; it++) {
        let improved = false;
        for (const e of [e1, e2]) {
          for (const sgn of [-1, 1]) {
            const next = [off[0] + e[0] * sgn * step, off[1] + e[1] * sgn * step, off[2] + e[2] * sgn * step];
            if (v3.len(next) > lim) continue;
            const prev = [off[0], off[1], off[2]];
            off[0] = next[0];
            off[1] = next[1];
            off[2] = next[2];
            const c = evalP(p);
            if (c < best - 1e-9) {
              best = c;
              improved = true;
            } else {
              off[0] = prev[0];
              off[1] = prev[1];
              off[2] = prev[2];
            }
          }
        }
        if (!improved) break;
      }
    }
  };
  refine('elbowOff', 0, IDX.LeftUpperArm, IDX.LeftHand);
  refine('elbowOff', 1, IDX.RightUpperArm, IDX.RightHand);
  refine('kneeOff', 0, IDX.LeftUpperLeg, IDX.LeftFoot);
  refine('kneeOff', 1, IDX.RightUpperLeg, IDX.RightFoot);
  onProgress?.(0.8);

  const model = buildModel(p, ctx);
  const segs = segmentsOf(model.J, model.tips, ctx);

  // 4. Radios reales alrededor de cada hueso, cobertura y confianza.
  const dists = Array.from({ length: 19 }, () => []);
  let covered = 0;
  for (let i = 0; i < S.length; i += 3) {
    let best = Infinity, bb = 0;
    for (let b = 0; b < 19; b++) {
      const d = segDist(S[i], S[i + 1], S[i + 2], segs, b);
      const nd = d / R[b];
      if (nd < best) {
        best = nd;
        bb = b;
      }
      if (b === 18) {
        if (best <= 1.7) covered++;
        if (best < 2.2) dists[bb].push(segDist(S[i], S[i + 1], S[i + 2], segs, bb));
      }
    }
  }
  const radii = new Float64Array(19);
  for (let b = 0; b < 19; b++) {
    const d = dists[b].sort((a, c) => a - c);
    radii[b] = d.length >= 25 ? clamp(d[Math.floor(d.length * 0.8)], 0.5 * R[b], 2.2 * R[b]) : R[b];
  }
  const coverage = covered / (S.length / 3);
  const confidence = clamp((coverage - 0.55) / 0.4, 0, 1);
  if (confidence < 0.5) warnings.push('El modelo no se parece mucho a un humanoide de pie (T, A o brazos abajo). El esqueleto puede quedar mal colocado.');

  // Punta del pie y talón con la malla.
  const foot = [1, -1].map((s, side) => {
    const ank = model.J[IDX[`${s > 0 ? 'Left' : 'Right'}Foot`]];
    let zmax = -Infinity, zmin = Infinity;
    for (let i = 0; i < P.length; i += 3) {
      if (P[i + 1] < 0.08 * H && Math.abs(P[i] - ank[0]) < 0.07 * H) {
        if (P[i + 2] > zmax) zmax = P[i + 2];
        if (P[i + 2] < zmin) zmin = P[i + 2];
      }
    }
    const toeZ = Number.isFinite(zmax) && zmax - ank[2] > 0.04 * H ? zmax : ank[2] + footFwd[side];
    const heelZ = Number.isFinite(zmin) && ank[2] - zmin > 0.01 * H ? zmin : ank[2] - 0.04 * H;
    return { toe: [ank[0], ctx.toeY, toeZ], heelBack: ank[2] - heelZ };
  });
  model.tips.toeLeft = foot[0].toe;
  model.tips.toeRight = foot[1].toe;

  const armAvg = (p.abd[0] + p.abd[1]) / 2;
  const poseType = armAvg >= 65 ? 'T' : armAvg >= 25 ? 'A' : 'down';
  onProgress?.(1);
  return {
    version: FIT_VERSION,
    orientation,
    height: H,
    joints: model.J.map((v) => v.map((x) => +x.toFixed(5))),
    tips: Object.fromEntries(Object.entries(model.tips).map(([k, v]) => [k, v.map((x) => +x.toFixed(5))])),
    radii: Array.from(radii, (x) => +x.toFixed(5)),
    heelBack: foot.map((f) => +f.heelBack.toFixed(5)),
    pose: { type: poseType, armAbduction: [...p.abd], legSplay: [...p.splay] },
    coverage,
    confidence,
    warnings,
  };
}
