// Personaje con esqueleto para Three.js: 19 huesos (THREE.Bone), SkinnedMesh con los pesos calculados,
// superposición opcional del esqueleto y aplicación de poses (las de gait.js / animator.js).
//
// Convenciones (ver skeleton.js): todos los huesos tienen rotación de reposo = identidad, así que la
// rotación local de cada hueso es inv(mundo[padre]) · mundo[hueso] y la raíz (Hips) lleva la posición.
// Recibe THREE por parámetro para no importar Three.js de forma estática (se carga bajo demanda).
import { buildPreviewGroup } from '../import/previewScene.js';
import { poseToLocal, poseJoints, PARENTS, BONE_COUNT } from './skeleton.js';

// meshes: ya en el marco del rig (service.orientMeshes). weights: por malla { skinIndex, skinWeight }.
export async function buildRiggedPreview(THREE, preview, rig, weights, { texMax = 512, wireframe = false } = {}) {
  const bones = rig.names.map((name) => {
    const b = new THREE.Bone();
    b.name = name;
    return b;
  });
  PARENTS.forEach((p, i) => p >= 0 && bones[p].add(bones[i]));
  bones.forEach((b, i) => b.position.set(rig.local[i][0], rig.local[i][1], rig.local[i][2]));
  const root = bones[0];
  root.updateMatrixWorld(true); // las inversas del esqueleto se calculan desde la pose de reposo
  const skeleton = new THREE.Skeleton(bones);

  const built = await buildPreviewGroup(THREE, preview, { texMax, wireframe, skin: { weights, skeleton } });
  built.group.add(root);

  // Superposición del esqueleto: una línea por hueso (padre → hijo) y un punto por articulación.
  const links = [];
  PARENTS.forEach((p, i) => p >= 0 && links.push([p, i]));
  const linePos = new Float32Array(links.length * 6);
  const lineGeo = new THREE.BufferGeometry();
  lineGeo.setAttribute('position', new THREE.BufferAttribute(linePos, 3));
  const lineMat = new THREE.LineBasicMaterial({ color: 0x2dd4bf, depthTest: false, transparent: true });
  const lines = new THREE.LineSegments(lineGeo, lineMat);
  const pointPos = new Float32Array(BONE_COUNT * 3);
  const pointGeo = new THREE.BufferGeometry();
  pointGeo.setAttribute('position', new THREE.BufferAttribute(pointPos, 3));
  const pointMat = new THREE.PointsMaterial({ color: 0xfacc15, size: Math.max(rig.height * 0.018, 1e-4), sizeAttenuation: true, depthTest: false, transparent: true });
  const points = new THREE.Points(pointGeo, pointMat);
  for (const o of [lines, points]) {
    o.frustumCulled = false;
    o.renderOrder = 10;
    o.visible = false;
  }
  built.group.add(lines, points);

  const origDispose = built.dispose;
  let overlayOn = false;
  let lastPose = null;

  const writeOverlay = (pose) => {
    const J = poseJoints(rig, pose);
    links.forEach(([a, b], k) => {
      linePos.set(J[a], k * 6);
      linePos.set(J[b], k * 6 + 3);
    });
    J.forEach((j, i) => pointPos.set(j, i * 3));
    lineGeo.attributes.position.needsUpdate = true;
    pointGeo.attributes.position.needsUpdate = true;
  };

  return Object.assign(built, {
    bones,
    skeleton,
    // Aplica una pose { root, world[19] } a los huesos. Devuelve true si todos los números eran finitos.
    applyPose(pose) {
      const { quats, rootPos } = poseToLocal(rig, pose);
      if (!rootPos.every(Number.isFinite) || !quats.every((q) => q.every(Number.isFinite))) return false;
      for (let i = 0; i < BONE_COUNT; i++) bones[i].quaternion.set(quats[i][0], quats[i][1], quats[i][2], quats[i][3]);
      root.position.set(rootPos[0], rootPos[1], rootPos[2]);
      lastPose = pose;
      if (overlayOn) writeOverlay(pose);
      return true;
    },
    setSkeletonVisible(on) {
      overlayOn = !!on;
      lines.visible = points.visible = overlayOn;
      if (overlayOn && lastPose) writeOverlay(lastPose);
    },
    dispose() {
      origDispose();
      skeleton.dispose?.();
      lineGeo.dispose();
      lineMat.dispose();
      pointGeo.dispose();
      pointMat.dispose();
    },
  });
}
