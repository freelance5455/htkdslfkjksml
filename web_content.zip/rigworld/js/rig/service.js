// Servicio de rig: funciones puras que ajustan el esqueleto, orientan las mallas y calculan pesos y calidad.
// Las usan tanto el Worker (js/workers/rig.worker.js) como el respaldo en el hilo principal (client.js),
// así que no pueden tocar el DOM ni Three.js.
//
// Qué se guarda de un personaje: solo el rig (≈ 5 KB: 19 articulaciones, radios, medidas) y las opciones
// con que se creó. Los pesos NO se guardan: se recalculan en una fracción de segundo a partir del rig y de
// la malla de vista previa, que ya se regenera del archivo original. Así no se duplican texturas ni mallas
// en el almacenamiento y los pesos nunca quedan desfasados si el usuario cambia el presupuesto de triángulos.
import { fitHumanoid, applyOrientation, applyOrientationRotation, FIT_VERSION } from './fit.js';
import { createRig, skinPositions } from './skeleton.js';
import { computeSkinWeights } from './weights.js';
import { createGait } from './gait.js';

export const RIG_VERSION = 1;

// Ajusta el esqueleto a las mallas (solo usa `positions`). Devuelve un registro listo para guardar.
export function fitRigRecord(meshes, { yawOffset = 0, up = 'auto', onProgress } = {}) {
  const fit = fitHumanoid(meshes, { up, yawOffset, onProgress });
  const rig = createRig(fit);
  return {
    version: RIG_VERSION,
    fitVersion: FIT_VERSION,
    options: { yawOffset, up },
    rig,
    warnings: fit.warnings,
    coverage: fit.coverage,
    confidence: fit.confidence,
    poseType: fit.pose.type,
    createdAt: Date.now(),
  };
}

// ¿Sirve un registro guardado con esta versión del código? Si no, hay que volver a ajustar.
export function isRigCompatible(record) {
  const r = record?.rig;
  return !!record && record.version === RIG_VERSION && record.fitVersion === FIT_VERSION && Array.isArray(r?.joints) && r.joints.length === 19 && !!r.measures && Number.isFinite(r.height) && r.height > 0;
}

// Lleva las mallas de vista previa al marco canónico del rig (Y arriba, +Z al frente, pies en y = 0).
export function orientMeshes(meshes, rig) {
  return meshes.map((m) => ({
    ...m,
    positions: applyOrientation(m.positions, rig.orientation),
    normals: m.normals ? applyOrientationRotation(m.normals, rig.orientation) : null,
  }));
}

// Pesos de skinning + informe de calidad. `meshes` ya están orientadas (solo hacen falta `positions` e `indices`).
export function skinAndAssess(meshes, rig, { onProgress } = {}) {
  const weights = computeSkinWeights(meshes, rig, { onProgress: (p) => onProgress?.(0.85 * p) });
  const quality = assessQuality(meshes, rig, weights);
  onProgress?.(1);
  return { weights, quality };
}

// ── Calidad de la deformación ───────────────────────────────────────────────────────────────────
// Se deforma la malla con una pose exigente (zancada de carrera) y se mide cuántas aristas se estiran
// de forma exagerada (más de 5 veces su largo en reposo). En un modelo en T o en A casi no hay; si los
// brazos están pegados al cuerpo con las manos tocando la cadera, la malla que une mano y cuerpo se
// estira como una membrana y el porcentaje sube. Es un aviso honesto, no un juicio estético.
const SEVERE_RATIO = 5;
const MAX_TRIS_SAMPLED = 60000;

export function assessQuality(meshes, rig, weights) {
  const gait = createGait(rig);
  const poses = [gait.walkRun(0, 0.88).pose, gait.walkRun(0.5, 0.88).pose];
  let edges = 0, severe = 0;
  meshes.forEach((m, k) => {
    const P = m.positions;
    const nTris = m.indices ? m.indices.length / 3 : P.length / 9;
    const stride = Math.max(1, Math.ceil(nTris / MAX_TRIS_SAMPLED));
    const minLen = 0.002 * rig.height;
    for (const pose of poses) {
      const out = skinPositions(rig, pose, P, weights[k].skinIndex, weights[k].skinWeight);
      for (let t = 0; t < nTris; t += stride) {
        const ia = m.indices ? m.indices[t * 3] : t * 3, ib = m.indices ? m.indices[t * 3 + 1] : t * 3 + 1, ic = m.indices ? m.indices[t * 3 + 2] : t * 3 + 2;
        const tri = [ia, ib, ic];
        for (let e = 0; e < 3; e++) {
          const a = tri[e], b = tri[(e + 1) % 3];
          const d0 = Math.hypot(P[a * 3] - P[b * 3], P[a * 3 + 1] - P[b * 3 + 1], P[a * 3 + 2] - P[b * 3 + 2]);
          if (d0 < minLen) continue;
          const d1 = Math.hypot(out[a * 3] - out[b * 3], out[a * 3 + 1] - out[b * 3 + 1], out[a * 3 + 2] - out[b * 3 + 2]);
          edges++;
          if (d1 / d0 > SEVERE_RATIO) severe++;
        }
      }
    }
  });
  const severePct = edges ? (100 * severe) / edges : 0;
  const level = severePct < 0.15 ? 'good' : severePct < 0.4 ? 'fair' : 'poor';
  return { severePct, level, edges };
}

// Texto de aviso según la calidad, el tipo de pose y los avisos del ajuste.
export function describeRig(record, quality) {
  const notes = [];
  for (const w of record.warnings || []) notes.push({ kind: 'warn', text: w });
  if (record.poseType === 'down') {
    notes.push({ kind: 'warn', text: 'Los brazos están pegados al cuerpo. Las piernas y los pies se mueven bien, pero los brazos pueden deformar la malla junto a la cadera. Con el modelo en T o en A queda mejor.' });
  }
  if (quality?.level === 'poor') {
    notes.push({ kind: 'warn', text: `La malla se estira mucho en algunas zonas (${quality.severePct.toFixed(1)} % de aristas). Prueba «Girar 90°» o usa un modelo en pose T o A.` });
  } else if (quality?.level === 'fair') {
    notes.push({ kind: 'info', text: 'Hay pequeños estiramientos en zonas de unión (axila, entrepierna). Es normal en mallas de una sola pieza.' });
  }
  return notes;
}
