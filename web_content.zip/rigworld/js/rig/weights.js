// Pesos de skinning (hasta 4 huesos por vértice) sin necesidad de que la malla sea estanca ni conexa.
//
// Idea: «Voronoi suave» por distancia normalizada al segmento de cada hueso.
//   e_b = distancia(vértice, hueso b) / radio_b            (radio medido sobre el modelo en el ajuste)
//   w_b ∝ exp(−(e_b² − e_min²) / (2·s²))                   (e_min: el hueso más cercano)
// Dos huesos consecutivos se reparten el vértice en un plano que pasa por la articulación; el ancho de
// la mezcla lo da s (en unidades de radio): ancho en rodillas y codos para que doblen suave, casi nulo
// en pies y manos para que se muevan como un sólido rígido y no se deformen al caminar.
//
// Los huesos de cada lado solo compiten por los vértices de su lado (compuerta suave en x), así las
// dos piernas nunca se arrastran entre sí aunque los muslos se toquen.
//
// Como los pesos son una función continua de la posición, no hay saltos entre vértices vecinos y por
// tanto no se rompen los triángulos al animar.
import { BONE_NAMES } from '../core/skeletonTemplate.js';
import { smoothstep } from './mathq.js';
import { boneSegments, IDX } from './skeleton.js';

export const MAX_INFLUENCES = 4;

// Anchura de la mezcla de cada hueso (en radios). Menor = más rígido.
const SHARPNESS = {
  Hips: 0.3, Spine: 0.34, Chest: 0.34, Neck: 0.28, Head: 0.2,
  Shoulder: 0.3, UpperArm: 0.32, LowerArm: 0.32, Hand: 0.13,
  UpperLeg: 0.3, LowerLeg: 0.32, Foot: 0.11,
};
const sharpOf = (name) => SHARPNESS[name.replace(/^(Left|Right)/, '')];
const sideOf = (name) => (name.startsWith('Left') ? 1 : name.startsWith('Right') ? -1 : 0);
const isLeg = (name) => /Leg|Foot/.test(name);

export function computeSkinWeights(meshes, rig, { onProgress } = {}) {
  const segs = boneSegments(rig);
  const nb = BONE_NAMES.length;
  const radius = new Float64Array(nb), sharp = new Float64Array(nb), side = new Int8Array(nb);
  const legBone = new Uint8Array(nb);
  BONE_NAMES.forEach((n, i) => {
    radius[i] = Math.max(1e-6, rig.radii[i]);
    sharp[i] = sharpOf(n);
    side[i] = sideOf(n);
    legBone[i] = isLeg(n) ? 1 : 0;
  });
  const m = rig.measures;
  const legGate = Math.max(0.012 * rig.height, 0.4 * m.hipHalf);
  const armGate = 0.5 * m.shoulderHalf;

  // Segmentos precalculados: origen, vector y 1/|v|².
  const A = new Float64Array(nb * 3), B = new Float64Array(nb * 3), inv = new Float64Array(nb);
  for (let b = 0; b < nb; b++) {
    for (let k = 0; k < 3; k++) {
      A[b * 3 + k] = segs[b * 6 + k];
      B[b * 3 + k] = segs[b * 6 + 3 + k] - segs[b * 6 + k];
    }
    const l2 = B[b * 3] ** 2 + B[b * 3 + 1] ** 2 + B[b * 3 + 2] ** 2;
    inv[b] = l2 > 1e-12 ? 1 / l2 : 0;
  }

  const e = new Float64Array(nb);
  const u = new Float64Array(nb);
  let total = 0;
  for (const mesh of meshes) total += mesh.positions.length / 3;
  let done = 0;
  const out = [];

  for (const mesh of meshes) {
    const P = mesh.positions;
    const n = P.length / 3;
    const skinIndex = new Uint8Array(n * 4);
    const skinWeight = new Float32Array(n * 4);
    for (let v = 0; v < n; v++) {
      const x = P[v * 3], y = P[v * 3 + 1], z = P[v * 3 + 2];
      let emin = Infinity, bmin = 0;
      for (let b = 0; b < nb; b++) {
        const px = x - A[b * 3], py = y - A[b * 3 + 1], pz = z - A[b * 3 + 2];
        let t = (px * B[b * 3] + py * B[b * 3 + 1] + pz * B[b * 3 + 2]) * inv[b];
        t = t < 0 ? 0 : t > 1 ? 1 : t;
        const d = Math.hypot(px - B[b * 3] * t, py - B[b * 3 + 1] * t, pz - B[b * 3 + 2] * t);
        let eb = d / radius[b];
        const s = side[b];
        if (s !== 0) {
          // Compuerta suave: un hueso de un lado no reclama vértices del lado contrario.
          const g = legBone[b] ? smoothstep(-legGate, legGate, s * x) : smoothstep(-armGate, 0.2 * armGate, s * x);
          eb /= Math.max(g, 0.04);
        }
        e[b] = eb;
        if (eb < emin) {
          emin = eb;
          bmin = b;
        }
      }
      const sn = sharp[bmin];
      let sum = 0;
      for (let b = 0; b < nb; b++) {
        const s = Math.min(sn, sharp[b]);
        const w = Math.exp(-(e[b] * e[b] - emin * emin) / (2 * s * s));
        u[b] = w;
        sum += w;
      }
      // Los 4 mayores, renormalizados.
      let wsum = 0;
      for (let k = 0; k < MAX_INFLUENCES; k++) {
        let bi = -1, bw = 0;
        for (let b = 0; b < nb; b++) {
          if (u[b] > bw) {
            bw = u[b];
            bi = b;
          }
        }
        if (bi < 0 || bw < 1e-4 * sum) break;
        skinIndex[v * 4 + k] = bi;
        skinWeight[v * 4 + k] = bw;
        wsum += bw;
        u[bi] = 0;
      }
      for (let k = 0; k < 4; k++) skinWeight[v * 4 + k] /= wsum || 1;
    }
    done += n;
    onProgress?.(done / total);
    out.push({ skinIndex, skinWeight });
  }
  return out;
}

// Cuantiza pesos a bytes (suma exacta 255) para guardarlos en 1 byte por peso.
export function quantizeWeights(skinWeight) {
  const q = new Uint8Array(skinWeight.length);
  for (let v = 0; v < skinWeight.length; v += 4) {
    let sum = 0, big = 0;
    for (let k = 0; k < 4; k++) {
      q[v + k] = Math.round(skinWeight[v + k] * 255);
      sum += q[v + k];
      if (q[v + k] > q[v + big]) big = k;
    }
    q[v + big] += 255 - sum;
  }
  return q;
}

export function dequantizeWeights(q) {
  const out = new Float32Array(q.length);
  for (let i = 0; i < q.length; i++) out[i] = q[i] / 255;
  return out;
}

// Estadísticas de calidad para pruebas y para el aviso al usuario.
export function weightStats(positions, skinIndex, skinWeight) {
  const n = positions.length / 3;
  const per = new Float64Array(BONE_NAMES.length);
  let crossLeg = 0, maxCross = 0, multi = 0;
  const L = new Set([IDX.LeftUpperLeg, IDX.LeftLowerLeg, IDX.LeftFoot]);
  const Rr = new Set([IDX.RightUpperLeg, IDX.RightLowerLeg, IDX.RightFoot]);
  for (let v = 0; v < n; v++) {
    let nz = 0, left = 0, right = 0;
    for (let k = 0; k < 4; k++) {
      const w = skinWeight[v * 4 + k];
      if (w <= 0) continue;
      nz++;
      per[skinIndex[v * 4 + k]] += w;
      if (L.has(skinIndex[v * 4 + k])) left += w;
      if (Rr.has(skinIndex[v * 4 + k])) right += w;
    }
    if (nz > 1) multi++;
    // Vértice con peso de una pierna en el lado contrario del cuerpo.
    const x = positions[v * 3];
    const wrong = x < -0.01 ? left : x > 0.01 ? right : 0;
    if (wrong > 0.02) crossLeg++;
    if (wrong > maxCross) maxCross = wrong;
  }
  return { vertices: n, perBone: per, crossLeg, maxCross, blended: multi / n };
}
