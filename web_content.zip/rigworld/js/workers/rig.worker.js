// Worker de rig (módulo). Ajusta el esqueleto y calcula pesos sin bloquear la interfaz.
// Entrada:  { type: 'fit',  id, meshes: [{positions}], options: {yawOffset, up} }
//           { type: 'skin', id, meshes: [{positions, indices}], rig }
// Salida:   { type: 'ready' } | { type: 'progress', id, value } | { type: 'done', id, result } | { type: 'error', id, message }
import { fitRigRecord, skinAndAssess } from '../rig/service.js';

self.onmessage = (event) => {
  const msg = event.data;
  if (!msg || (msg.type !== 'fit' && msg.type !== 'skin')) return;
  const { id } = msg;
  let last = 0;
  const onProgress = (value) => {
    const now = Date.now();
    if (now - last > 60 || value >= 1) {
      last = now;
      self.postMessage({ type: 'progress', id, value });
    }
  };
  try {
    if (msg.type === 'fit') {
      const result = fitRigRecord(msg.meshes, { ...msg.options, onProgress });
      self.postMessage({ type: 'done', id, result });
    } else {
      const result = skinAndAssess(msg.meshes, msg.rig, { onProgress });
      const transfer = [];
      for (const w of result.weights) transfer.push(w.skinIndex.buffer, w.skinWeight.buffer);
      self.postMessage({ type: 'done', id, result }, transfer);
    }
  } catch (err) {
    self.postMessage({ type: 'error', id, message: err?.message || String(err) });
  }
};

self.postMessage({ type: 'ready' });
