// Worker de importación (módulo). Parsea sin bloquear la interfaz.
// Mensajes de entrada:  { type: 'parse', id, format, file, extras, budgetTris }
// Mensajes de salida:   { type: 'ready' } | { type: 'progress', id, value }
//                       { type: 'done', id, result } | { type: 'error', id, message, code }
import { parseModel, collectTransfers } from '../import/parse.js';

self.onmessage = async (event) => {
  const msg = event.data;
  if (msg?.type !== 'parse') return;
  const { id } = msg;
  let last = 0;
  try {
    const result = await parseModel({
      format: msg.format,
      file: msg.file,
      extras: msg.extras,
      budgetTris: msg.budgetTris,
      onProgress: (value) => {
        const now = Date.now();
        if (now - last > 60 || value >= 1) {
          last = now;
          self.postMessage({ type: 'progress', id, value });
        }
      },
    });
    self.postMessage({ type: 'done', id, result }, collectTransfers(result));
  } catch (err) {
    self.postMessage({ type: 'error', id, message: err?.message || String(err), code: err?.code || null, reason: err?.reason || null });
  }
};

self.postMessage({ type: 'ready' });
