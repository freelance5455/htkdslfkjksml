// Pruebas unitarias del pipeline de importación (Node, sin navegador).
// Ejecutar: node --test test/unit.test.mjs
import test from 'node:test';
import assert from 'node:assert/strict';

import { classifyHead, groupSelection, isBinaryStl, extOf } from '../js/import/formats.js';
import { parseModel, NeedsThreeError } from '../js/import/parse.js';
import { parseMtl } from '../js/import/obj.js';
import { scanLines } from '../js/import/lines.js';
import { buildGlb, buildSampleGlb } from '../js/import/sample.js';
import { totalTris, decimateCluster, decimateMeshes, weldMesh } from '../js/import/mesh.js';
import { fmtBytes, fmtCount } from '../js/core/format.js';
import { HUMANOID_19 } from '../js/core/skeletonTemplate.js';

const enc = (s) => new TextEncoder().encode(s);
const BUDGET = 100000;
const approx = (a, b, eps = 1e-4) => assert.ok(Math.abs(a - b) <= eps, `${a} ≉ ${b}`);

// Cubo unidad [0,1]^3: 8 vértices, 12 triángulos.
const CUBE_V = [[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1]];
const CUBE_QUADS = [[0,3,2,1],[4,5,6,7],[0,1,5,4],[2,3,7,6],[1,2,6,5],[0,4,7,3]];
const cubeTris = () => CUBE_QUADS.flatMap(([a,b,c,d]) => [[a,b,c],[a,c,d]]);

function binaryStl(tris, verts) {
  const buf = new ArrayBuffer(84 + tris.length * 50);
  const dv = new DataView(buf);
  dv.setUint32(80, tris.length, true);
  tris.forEach((t, i) => {
    let o = 84 + i * 50 + 12;
    for (const vi of t) for (const c of verts[vi]) { dv.setFloat32(o, c, true); o += 4; }
  });
  return buf;
}
function asciiStl(tris, verts) {
  let s = 'solid cubo\n';
  for (const t of tris) {
    s += ' facet normal 0 0 0\n  outer loop\n';
    for (const vi of t) s += `   vertex ${verts[vi].join(' ')}\n`;
    s += '  endloop\n endfacet\n';
  }
  return enc(s + 'endsolid cubo\n');
}

// ── formatos ────────────────────────────────────────────────────────────────────────────────
test('classifyHead reconoce formatos por firma, no solo por extensión', () => {
  const glb = new Uint8Array([0x67, 0x6c, 0x54, 0x46, 2, 0, 0, 0, 0, 0, 0, 0]);
  assert.deepEqual(classifyHead('x.bin', glb, 12), { role: 'buffer' });
  assert.equal(classifyHead('modelo.dat', glb, 12).format, 'glb');
  assert.equal(classifyHead('a.gltf', enc('{"asset":{"version":"2.0"}}'), 30).format, 'gltf');
  assert.equal(classifyHead('a.fbx', enc('Kaydara FBX Binary  \0'), 100).format, 'fbx');
  assert.equal(classifyHead('a.fbx', enc('; FBX 7.3.0 project file'), 100).format, 'fbx');
  assert.equal(classifyHead('a.obj', enc('# cubo\nv 0 0 0\n'), 20).format, 'obj');
  assert.equal(classifyHead('a.ply', enc('ply\nformat ascii 1.0\n'), 30).format, 'ply');
  assert.equal(classifyHead('a.dae', enc('<?xml version="1.0"?><COLLADA xmlns="x">'), 60).format, 'dae');
  assert.equal(classifyHead('a.stl', enc('solid x\nfacet'), 50).format, 'stl');
  assert.equal(classifyHead('t.PNG', enc('x'), 1).role, 'texture');
  assert.equal(classifyHead('m.mtl', enc('newmtl a'), 8).role, 'material');
  assert.equal(classifyHead('a.zip', enc('PK'), 2).role, 'unknown');
  assert.equal(classifyHead('roto.glb', enc('no soy glb'), 10).role, 'unknown');
  assert.equal(extOf('Dir/Sub\\Modelo.Final.GLB'), 'glb');
});

test('isBinaryStl distingue STL binario de ASCII que empieza por "solid"', () => {
  const bin = new Uint8Array(binaryStl(cubeTris(), CUBE_V));
  bin.set(enc('solid parece ascii'), 0); // algunos exportadores hacen esto
  assert.equal(isBinaryStl(bin.subarray(0, 4096), bin.length), true);
  const ascii = asciiStl(cubeTris(), CUBE_V);
  assert.equal(isBinaryStl(ascii.subarray(0, 4096), ascii.length), false);
});

test('groupSelection agrupa auxiliares y rechaza lo inválido', async () => {
  const f = (name, data) => new File([data], name);
  const gltf = f('Robot.gltf', enc('{"asset":{"version":"2.0"}}'));
  const bin = f('Robot.bin', new Uint8Array(8));
  const tex = f('albedo.png', new Uint8Array(8));
  const stl = f('pieza.stl', asciiStl(cubeTris(), CUBE_V));
  const vacio = f('vacio.obj', new Uint8Array(0));
  const enorme = { name: 'enorme.glb', size: 300 * 1024 * 1024, slice() { throw new Error('no debe leerse'); } };
  const raro = f('cosa.xyz', enc('hola'));
  const huerfano = f('suelto.png', new Uint8Array(8));

  const r1 = await groupSelection([gltf, bin, tex, stl, vacio, enorme, raro]);
  assert.equal(r1.groups.length, 2);
  const g = r1.groups.find((x) => x.format === 'gltf');
  assert.deepEqual(g.extras.map((e) => e.role).sort(), ['buffer', 'texture']);
  assert.equal(r1.groups.find((x) => x.format === 'stl').extras.length, 0);
  const reasons = Object.fromEntries(r1.rejected.map((x) => [x.name, x.reason]));
  assert.match(reasons['vacio.obj'], /vacío/);
  assert.match(reasons['enorme.glb'], /200 MB/);
  assert.match(reasons['cosa.xyz'], /no compatible/i);

  const r2 = await groupSelection([huerfano]);
  assert.equal(r2.groups.length, 0);
  assert.match(r2.rejected[0].reason, /auxiliar/i);
});

// ── STL ─────────────────────────────────────────────────────────────────────────────────────
for (const [label, make] of [['binario', binaryStl], ['ASCII', asciiStl]]) {
  test(`STL ${label}: cubo con 12 triángulos y 8 vértices únicos`, async () => {
    const data = make(cubeTris(), CUBE_V);
    const r = await parseModel({ format: 'stl', file: new Blob([data]), budgetTris: BUDGET });
    assert.equal(r.stats.triangles, 12);
    assert.equal(r.stats.vertices, 8);
    assert.deepEqual(r.stats.size.map((x) => +x.toFixed(3)), [1, 1, 1]);
    assert.equal(r.stats.simplified, false);
    assert.ok(r.preview.meshes[0].normals, 'se calculan normales');
  });
}

test('STL sin triángulos da un error claro', async () => {
  await assert.rejects(parseModel({ format: 'stl', file: new Blob([enc('solid vacio\nendsolid vacio\n')]), budgetTris: BUDGET }), /no contiene triángulos/);
});

// ── PLY ─────────────────────────────────────────────────────────────────────────────────────
test('PLY ASCII con cuadriláteros y colores', async () => {
  let s = 'ply\nformat ascii 1.0\ncomment cubo\nelement vertex 8\nproperty float x\nproperty float y\nproperty float z\nproperty uchar red\nproperty uchar green\nproperty uchar blue\nelement face 6\nproperty list uchar int vertex_indices\nend_header\n';
  for (const v of CUBE_V) s += `${v.join(' ')} 255 128 0\n`;
  for (const q of CUBE_QUADS) s += `4 ${q.join(' ')}\n`;
  const r = await parseModel({ format: 'ply', file: new Blob([enc(s)]), budgetTris: BUDGET });
  assert.equal(r.stats.triangles, 12);
  assert.equal(r.stats.vertices, 8);
  const m = r.preview.meshes[0];
  approx(m.colors[0], 1);
  approx(m.colors[1], 128 / 255);
});

for (const [fmt, little] of [['binary_little_endian', true], ['binary_big_endian', false]]) {
  test(`PLY ${fmt}`, async () => {
    const head = enc(`ply\nformat ${fmt} 1.0\nelement vertex 8\nproperty float x\nproperty float y\nproperty float z\nelement face 6\nproperty list uchar uint vertex_indices\nend_header\n`);
    const body = new ArrayBuffer(8 * 12 + 6 * (1 + 16));
    const dv = new DataView(body);
    let o = 0;
    for (const v of CUBE_V) for (const c of v) { dv.setFloat32(o, c, little); o += 4; }
    for (const q of CUBE_QUADS) { dv.setUint8(o++, 4); for (const i of q) { dv.setUint32(o, i, little); o += 4; } }
    const all = new Uint8Array(head.length + body.byteLength);
    all.set(head);
    all.set(new Uint8Array(body), head.length);
    const r = await parseModel({ format: 'ply', file: new Blob([all]), budgetTris: BUDGET });
    assert.equal(r.stats.triangles, 12);
    assert.deepEqual(r.stats.size.map((x) => +x.toFixed(3)), [1, 1, 1]);
  });
}

test('PLY: nube de puntos y archivo truncado dan errores claros', async () => {
  const puntos = enc('ply\nformat ascii 1.0\nelement vertex 2\nproperty float x\nproperty float y\nproperty float z\nend_header\n0 0 0\n1 1 1\n');
  await assert.rejects(parseModel({ format: 'ply', file: new Blob([puntos]), budgetTris: BUDGET }), /nube de puntos/);
  const head = enc('ply\nformat binary_little_endian 1.0\nelement vertex 100\nproperty float x\nproperty float y\nproperty float z\nelement face 1\nproperty list uchar int vertex_indices\nend_header\n');
  const trunc = new Uint8Array(head.length + 20);
  trunc.set(head);
  await assert.rejects(parseModel({ format: 'ply', file: new Blob([trunc]), budgetTris: BUDGET }), /truncado/);
});

// ── OBJ / MTL ───────────────────────────────────────────────────────────────────────────────
test('parseMtl lee Kd, opacidad y mapa (con opciones)', () => {
  const m = parseMtl('newmtl piel\nKd 0.5 0.25 0.125\nd 0.5\nmap_Kd -s 1 1 1 texturas\\cara color.png\nnewmtl pelo\nKd 0 0 0\nTr 0.25\n');
  assert.deepEqual(m.get('piel').color, [0.5, 0.25, 0.125]);
  assert.equal(m.get('piel').opacity, 0.5);
  assert.equal(m.get('piel').mapName, 'cara color.png');
  assert.equal(m.get('pelo').opacity, 0.75);
});

test('OBJ: cuadriláteros, índices negativos, materiales, uv y textura', async () => {
  let s = 'mtllib cubo.mtl\n';
  for (const v of CUBE_V) s += `v ${v.join(' ')}\n`;
  s += 'vt 0 0\nvt 1 0\nvt 1 1\nvt 0 1\n';
  s += 'usemtl rojo\n';
  CUBE_QUADS.slice(0, 3).forEach((q) => { s += `f ${q.map((i, k) => `${i + 1}/${k + 1}`).join(' ')}\n`; });
  s += 'usemtl azul\n';
  CUBE_QUADS.slice(3).forEach((q) => { s += `f ${q.map((i) => i - 8).join(' ')}\r\n`; }); // -1 = último vértice; CRLF
  const mtl = 'newmtl rojo\nKd 1 0 0\nmap_Kd piel.PNG\nnewmtl azul\nKd 0 0 1\n';
  const png = new Blob([new Uint8Array([137, 80, 78, 71])], { type: 'image/png' });
  const r = await parseModel({
    format: 'obj',
    file: new Blob([enc(s)]),
    extras: [{ name: 'Cubo.MTL', role: 'material', blob: new Blob([enc(mtl)]) }, { name: 'piel.png', role: 'texture', blob: png }],
    budgetTris: BUDGET,
  });
  assert.equal(r.stats.triangles, 12);
  assert.equal(r.stats.meshes, 2);
  assert.equal(r.stats.vertices, 8, 'vértices del archivo');
  assert.equal(r.stats.textures, 1);
  const rojo = r.preview.materials.find((m) => m.name === 'rojo');
  assert.deepEqual(rojo.color, [1, 0, 0]);
  assert.equal(rojo.map, 0);
  assert.ok(r.preview.meshes.find((m) => m.name === 'rojo').uvs, 'uv conservadas');
  assert.equal(r.preview.meshes.find((m) => m.name === 'azul').uvs, null);
  assert.deepEqual(r.warnings, []);
});

test('OBJ sin .mtl adjunto avisa y usa colores por defecto', async () => {
  const s = 'mtllib falta.mtl\nusemtl x\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 2 3\n';
  const r = await parseModel({ format: 'obj', file: new Blob([enc(s)]), budgetTris: BUDGET });
  assert.equal(r.stats.triangles, 1);
  assert.match(r.warnings.join(' '), /materiales/);
});

test('OBJ sin caras da un error claro', async () => {
  await assert.rejects(parseModel({ format: 'obj', file: new Blob([enc('v 0 0 0\nv 1 1 1\nl 1 2\n')]), budgetTris: BUDGET }), /no contiene caras/);
});

test('OBJ de ~9 MB cruza varias ventanas de lectura sin perder líneas', async () => {
  const N = 150000; // cuadrícula de triángulos
  const parts = [];
  for (let i = 0; i < N + 2; i++) parts.push(`v ${i}.123456 ${(i % 97) * 0.5} ${(i % 13) * 0.25}`);
  for (let i = 1; i <= N; i++) parts.push(`f ${i} ${i + 1} ${i + 2}`);
  const text = parts.join('\n') + '\n';
  assert.ok(text.length > 4 * 1024 * 1024, `tamaño ${text.length}`);
  const r = await parseModel({ format: 'obj', file: new Blob([enc(text)]), budgetTris: 1e9 });
  assert.equal(r.stats.triangles, N);
  assert.equal(r.stats.vertices, N + 2);
});

test('scanLines maneja CRLF, última línea sin salto y caracteres UTF-8 partidos entre ventanas', async () => {
  const lines = [];
  const filler = 'ñ'.repeat(1000);
  const src = Array.from({ length: 6000 }, (_, i) => `l${i} ${filler}`).join('\r\n');
  await scanLines(new Blob([enc(src)]), (l) => { lines.push(l); });
  assert.equal(lines.length, 6000);
  assert.equal(lines[5999], `l5999 ${filler}`);
  assert.ok(lines.every((l) => !l.includes('�') && !l.endsWith('\r')));
});

// ── glTF / GLB ──────────────────────────────────────────────────────────────────────────────
const TRI = { positions: Float32Array.of(0, 0, 0, 1, 0, 0, 0, 1, 0), normals: Float32Array.of(0, 0, 1, 0, 0, 1, 0, 0, 1), indices: Uint32Array.of(0, 1, 2), color: [1, 0.5, 0.25] };

function faceNormalZ(m, t = 0) {
  const i = m.indices, p = m.positions;
  const [a, b, c] = [i[t * 3] * 3, i[t * 3 + 1] * 3, i[t * 3 + 2] * 3];
  const ux = p[b] - p[a], uy = p[b + 1] - p[a + 1], vx = p[c] - p[a], vy = p[c + 1] - p[a + 1];
  return ux * vy - uy * vx;
}

test('GLB mínimo: geometría, material y sin esqueleto', async () => {
  const r = await parseModel({ format: 'glb', file: new Blob([buildGlb([TRI])]), budgetTris: BUDGET });
  assert.equal(r.stats.triangles, 1);
  assert.equal(r.stats.hasSkeleton, false);
  assert.deepEqual(r.preview.materials[0].color.map((x) => +x.toFixed(2)), [1, 0.5, 0.25]);
  assert.ok(faceNormalZ(r.preview.meshes[0]) > 0);
});

test('GLB: coordenadas negativas menores que -1 no se recortan', async () => {
  const tri = { ...TRI, positions: Float32Array.of(-5, -7.5, 0, 1, 0, 0, 0, 1, 0) };
  const r = await parseModel({ format: 'glb', file: new Blob([buildGlb([tri])]), budgetTris: BUDGET });
  assert.deepEqual(r.stats.bbox.min, [-5, -7.5, 0]);
});

test('glTF: traslación/rotación/escala de nodos se hornean en la geometría', async () => {
  const nodes = [
    { name: 'raiz', translation: [10, 0, 0], scale: [2, 2, 2], children: [1] },
    { name: 'hijo', mesh: 0, translation: [0, 5, 0], rotation: [0, 0, Math.SQRT1_2, Math.SQRT1_2] }, // 90° en Z
  ];
  const r = await parseModel({ format: 'glb', file: new Blob([buildGlb([TRI], { nodes, sceneNodes: [0] })]), budgetTris: BUDGET });
  // Rotación 90° Z: (x,y)→(-y,x); luego +5 en y, escala ×2, +10 en x.
  const p = r.preview.meshes[0].positions;
  const got = [...p].map((v) => +v.toFixed(4));
  assert.deepEqual(got, [10, 10, 0, 10, 12, 0, 8, 10, 0]);
});

test('glTF: escala negativa (espejo) conserva la cara frontal', async () => {
  const nodes = [{ name: 'espejo', mesh: 0, scale: [-1, 1, 1] }];
  const r = await parseModel({ format: 'glb', file: new Blob([buildGlb([TRI], { nodes })]), budgetTris: BUDGET });
  const m = r.preview.meshes[0];
  assert.ok(faceNormalZ(m) > 0, 'el triángulo reflejado sigue mirando a +Z');
  approx(m.normals[2], 1);
});

test('glTF: tiras y abanicos de triángulos se convierten a triángulos', async () => {
  const quad = { positions: Float32Array.of(0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 0), indices: Uint32Array.of(0, 1, 2, 3), color: [1, 1, 1] };
  for (const mode of [5, 6]) {
    const r = await parseModel({ format: 'glb', file: new Blob([buildGlb([{ ...quad, mode }])]), budgetTris: BUDGET });
    assert.equal(r.stats.triangles, 2, `modo ${mode}`);
  }
});

test('glTF con buffer incrustado en base64 y con .bin externo', async () => {
  const glb = new Uint8Array(buildGlb([TRI]));
  const dv = new DataView(glb.buffer);
  const jsonLen = dv.getUint32(12, true);
  const json = JSON.parse(new TextDecoder().decode(glb.subarray(20, 20 + jsonLen)));
  const binStart = 20 + jsonLen + 8;
  const bin = glb.slice(binStart, binStart + json.buffers[0].byteLength);

  // a) data URI
  let s = '';
  for (const b of bin) s += String.fromCharCode(b);
  const j1 = { ...json, buffers: [{ byteLength: bin.length, uri: `data:application/octet-stream;base64,${btoa(s)}` }] };
  const r1 = await parseModel({ format: 'gltf', file: new Blob([enc(JSON.stringify(j1))]), budgetTris: BUDGET });
  assert.equal(r1.stats.triangles, 1);

  // b) .bin externo con nombre codificado
  const j2 = { ...json, buffers: [{ byteLength: bin.length, uri: 'mi%20modelo.bin' }] };
  const r2 = await parseModel({
    format: 'gltf',
    file: new Blob([enc(JSON.stringify(j2))]),
    extras: [{ name: 'Mi Modelo.BIN', role: 'buffer', blob: new Blob([bin]) }],
    budgetTris: BUDGET,
  });
  assert.equal(r2.stats.triangles, 1);

  // c) falta el .bin
  await assert.rejects(parseModel({ format: 'gltf', file: new Blob([enc(JSON.stringify(j2))]), budgetTris: BUDGET }), /Falta el archivo «mi modelo\.bin»/);
});

test('glTF con Draco requerido pide descompresión a Three.js', async () => {
  const glb = new Uint8Array(buildGlb([TRI]));
  const dv = new DataView(glb.buffer);
  const jsonLen = dv.getUint32(12, true);
  const json = JSON.parse(new TextDecoder().decode(glb.subarray(20, 20 + jsonLen)));
  json.extensionsRequired = ['KHR_draco_mesh_compression'];
  await assert.rejects(
    parseModel({ format: 'gltf', file: new Blob([enc(JSON.stringify(json))]), budgetTris: BUDGET }),
    (e) => e instanceof NeedsThreeError && e.code === 'NEEDS_THREE',
  );
});

test('GLB dañado o de otra versión da errores claros', async () => {
  const glb = new Uint8Array(buildGlb([TRI]));
  await assert.rejects(parseModel({ format: 'glb', file: new Blob([glb.slice(0, 40)]), budgetTris: BUDGET }), /truncado|dañado/);
  const v1 = glb.slice();
  new DataView(v1.buffer).setUint32(4, 1, true);
  await assert.rejects(parseModel({ format: 'glb', file: new Blob([v1]), budgetTris: BUDGET }), /versión 2/);
});

// ── Maniquí de ejemplo ──────────────────────────────────────────────────────────────────────
test('maniquí de ejemplo: T-pose de ~1,84 m, caras hacia afuera y normales coherentes', async () => {
  const r = await parseModel({ format: 'glb', file: new Blob([buildSampleGlb()]), budgetTris: BUDGET });
  const { stats } = r;
  assert.ok(stats.triangles > 3000 && stats.triangles < 30000, `triángulos: ${stats.triangles}`);
  assert.ok(stats.size[1] > 1.75 && stats.size[1] < 1.95, `alto ${stats.size[1]}`);
  assert.ok(stats.size[0] > 1.7 && stats.size[0] < 1.95, `envergadura ${stats.size[0]} (T-pose)`);
  approx(stats.bbox.min[1], 0, 0.02);
  assert.equal(stats.hasSkeleton, false);

  const m = r.preview.meshes[0];
  let ok = 0, total = 0;
  for (let t = 0; t < m.indices.length / 3; t++) {
    const ids = [m.indices[t * 3], m.indices[t * 3 + 1], m.indices[t * 3 + 2]];
    const [a, b, c] = ids.map((i) => i * 3);
    const p = m.positions, n = m.normals;
    const ux = p[b] - p[a], uy = p[b + 1] - p[a + 1], uz = p[b + 2] - p[a + 2];
    const vx = p[c] - p[a], vy = p[c + 1] - p[a + 1], vz = p[c + 2] - p[a + 2];
    const fx = uy * vz - uz * vy, fy = uz * vx - ux * vz, fz = ux * vy - uy * vx;
    const fl = Math.hypot(fx, fy, fz);
    if (fl < 1e-12) continue; // triángulo degenerado en el polo
    total++;
    const dot = (fx * (n[a] + n[b] + n[c]) + fy * (n[a + 1] + n[b + 1] + n[c + 1]) + fz * (n[a + 2] + n[b + 2] + n[c + 2])) / fl;
    if (dot > 0) ok++;
  }
  assert.ok(ok / total > 0.995, `${ok}/${total} triángulos con la orientación correcta`);
});

test('la plantilla de 19 huesos es coherente (padres antes que hijos, un solo raíz)', () => {
  assert.equal(HUMANOID_19.length, 19);
  assert.equal(HUMANOID_19.filter((j) => j.parent === -1).length, 1);
  HUMANOID_19.forEach((j, i) => assert.ok(j.parent < i, `${j.name}: padre ${j.parent} < ${i}`));
  assert.equal(new Set(HUMANOID_19.map((j) => j.name)).size, 19);
});

// ── Decimado ────────────────────────────────────────────────────────────────────────────────
test('modelos sobre el presupuesto se simplifican y avisan; bajo el presupuesto no', async () => {
  const seg = 150, rings = 150, pos = [];
  const P = (a, b) => [Math.sin(b) * Math.cos(a), Math.cos(b), Math.sin(b) * Math.sin(a)];
  for (let i = 0; i < seg; i++) for (let j = 0; j < rings; j++) {
    const a0 = (i / seg) * 2 * Math.PI, a1 = ((i + 1) / seg) * 2 * Math.PI, b0 = (j / rings) * Math.PI, b1 = ((j + 1) / rings) * Math.PI;
    pos.push(...P(a0, b0), ...P(a1, b0), ...P(a1, b1), ...P(a0, b0), ...P(a1, b1), ...P(a0, b1));
  }
  const stl = binaryStl(Array.from({ length: pos.length / 9 }, (_, i) => [i * 3, i * 3 + 1, i * 3 + 2]), Array.from({ length: pos.length / 3 }, (_, i) => pos.slice(i * 3, i * 3 + 3)));
  const full = await parseModel({ format: 'stl', file: new Blob([stl]), budgetTris: 1e9 });
  assert.equal(full.stats.simplified, false);
  assert.equal(full.stats.triangles, 45000);

  const small = await parseModel({ format: 'stl', file: new Blob([stl]), budgetTris: 8000 });
  assert.equal(small.stats.simplified, true);
  assert.equal(small.stats.triangles, 45000, 'las estadísticas son del modelo original');
  assert.ok(small.stats.previewTriangles <= 8000 * 1.15 && small.stats.previewTriangles > 3000, `previa: ${small.stats.previewTriangles}`);
  assert.match(small.warnings.join(' '), /simplificada/);
  assert.equal(totalTris(small.preview.meshes), small.stats.previewTriangles);
});

test('weldMesh une vértices idénticos', () => {
  const w = weldMesh(Float32Array.of(0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0));
  assert.equal(w.positions.length / 3, 4);
  assert.deepEqual([...w.indices], [0, 1, 2, 1, 3, 2]);
});

test('formato de tamaños y recuentos', () => {
  assert.equal(fmtBytes(0), '0 B');
  assert.equal(fmtBytes(1536), '1.50 KB');
  assert.equal(fmtBytes(200 * 1024 * 1024), '200 MB');
  assert.equal(fmtCount(950), '950');
  assert.equal(fmtCount(12400), '12 k');
  assert.equal(fmtCount(12500), '13 k');
  assert.equal(fmtCount(2_400_000), '2.4 M');
});

// ── Conversión de escenas Three.js (objetos simulados) ──────────────────────────────────────
import { objectToRaw } from '../js/import/threeImport.js';

function fakeAttr(array, itemSize) {
  return { array, itemSize, count: array.length / itemSize, normalized: false, getX: (i) => array[i * itemSize], getY: (i) => array[i * itemSize + 1], getZ: (i) => array[i * itemSize + 2] };
}
function fakeMesh({ name = 'm', pos, nor, uv, idx, groups, material, matrix, extra = {} }) {
  return {
    name,
    isMesh: true,
    material,
    geometry: { attributes: { position: fakeAttr(pos, 3), ...(nor && { normal: fakeAttr(nor, 3) }), ...(uv && { uv: fakeAttr(uv, 2) }) }, index: idx ? { array: idx } : null, groups: groups || [] },
    matrixWorld: { elements: matrix || [1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1] },
    ...extra,
  };
}
const fakeRoot = (children, animations = []) => ({ animations, updateMatrixWorld() {}, traverse(cb) { cb(this); children.forEach(cb); } });

test('objectToRaw: matriz de mundo, uv, material y esqueleto', () => {
  const img = { width: 4, height: 4 };
  const mat = { name: 'piel', color: { r: 0.5, g: 0.25, b: 1 }, map: { image: img, name: 'piel.png' }, side: 2, transparent: true, opacity: 0.5 };
  const mesh = fakeMesh({
    pos: Float32Array.of(0, 0, 0, 1, 0, 0, 0, 1, 0),
    nor: Float32Array.of(0, 0, 1, 0, 0, 1, 0, 0, 1),
    uv: Float32Array.of(0, 0, 1, 0, 0, 1),
    idx: Uint16Array.of(0, 1, 2),
    material: mat,
    matrix: [1,0,0,0, 0,1,0,0, 0,0,1,0, 5,6,7,1],
  });
  const bone = { isBone: true };
  const raw = objectToRaw(fakeRoot([mesh, bone], [{}, {}]));
  assert.deepEqual([...raw.meshes[0].positions].slice(0, 3), [5, 6, 7]);
  assert.deepEqual([...raw.meshes[0].indices], [0, 1, 2]);
  assert.equal(raw.meshes[0].uvs.length, 6);
  assert.deepEqual(raw.materials[0].color, [0.5, 0.25, 1]);
  assert.equal(raw.materials[0].opacity, 0.5);
  assert.equal(raw.materials[0].doubleSided, true);
  assert.equal(raw.materials[0].map, 0);
  assert.equal(raw.images[0].image, img);
  assert.equal(raw.info.hasSkeleton, true);
  assert.equal(raw.info.animations, 2);
});

test('objectToRaw: multimaterial por grupos, espejo y malla sin índices', () => {
  const a = { name: 'a', color: { r: 1, g: 0, b: 0 } }, b = { name: 'b', color: { r: 0, g: 0, b: 1 } };
  const multi = fakeMesh({
    pos: Float32Array.of(0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 0),
    idx: Uint16Array.of(0, 1, 2, 1, 3, 2),
    groups: [{ start: 0, count: 3, materialIndex: 0 }, { start: 3, count: 3, materialIndex: 1 }],
    material: [a, b],
  });
  const mirrored = fakeMesh({ pos: Float32Array.of(0, 0, 0, 1, 0, 0, 0, 1, 0), material: a, matrix: [-1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1] });
  const raw = objectToRaw(fakeRoot([multi, mirrored]));
  assert.equal(raw.meshes.length, 3);
  assert.equal(raw.materials.length, 2);
  assert.deepEqual(raw.meshes.map((m) => m.material), [0, 1, 0]);
  assert.deepEqual([...raw.meshes[2].indices], [0, 2, 1], 'el espejo invierte el orden de los vértices');
  assert.ok(raw.meshes.every((m) => m.normals), 'se calculan normales cuando faltan');
  assert.throws(() => objectToRaw(fakeRoot([])), /no contiene mallas/);
});

// ── Proyección 2D de miniaturas (función pura) ──────────────────────────────────────────────
import { projectTriangles } from '../js/import/thumbs.js';

test('projectTriangles rellena el modelo: encaja en el cuadro, ordena por profundidad y sombrea', async () => {
  const r = await parseModel({ format: 'glb', file: new Blob([buildSampleGlb()]), budgetTris: BUDGET });
  const tris = projectTriangles(r.preview, 256);
  // Los polos de esferas/cápsulas generan triángulos degenerados que no se dibujan.
  assert.ok(tris.length > r.stats.triangles * 0.85 && tris.length <= r.stats.triangles, `triángulos: ${tris.length} de ${r.stats.triangles}`);
  const xs = tris.flatMap((t) => [t.p[0], t.p[2], t.p[4]]), ys = tris.flatMap((t) => [t.p[1], t.p[3], t.p[5]]);
  assert.ok(Math.min(...xs) >= -0.5 && Math.max(...xs) <= 256.5, 'x dentro del cuadro');
  assert.ok(Math.min(...ys) >= -0.5 && Math.max(...ys) <= 256.5, 'y dentro del cuadro');
  const w = Math.max(...xs) - Math.min(...xs), h = Math.max(...ys) - Math.min(...ys);
  assert.ok(Math.max(w, h) > 256 * 0.8, 'ocupa casi todo el cuadro');
  for (let i = 1; i < tris.length; i++) assert.ok(tris[i].depth >= tris[i - 1].depth, 'lejos → cerca');
  assert.ok(tris.every((t) => t.shade >= 0.3 - 1e-9 && t.shade <= 1.0001));
  // Las extremidades (tubos de pocos vértices) deben dibujarse: hay triángulos a lo largo de toda la figura.
  const bandsHit = new Set(tris.map((t) => Math.floor(((t.p[1] + t.p[3] + t.p[5]) / 3) / 16)));
  assert.ok(bandsHit.size >= 12, `la figura debe cubrir todo el alto, bandas: ${bandsHit.size}`);
});

test('projectTriangles decima los modelos grandes y respeta el límite', () => {
  // Esfera UV de 60 000 triángulos (superficie densa, como un escaneo real).
  const seg = 245, ring = 122, pos = new Float32Array((seg + 1) * (ring + 1) * 3), idx = [];
  for (let y = 0; y <= ring; y++) {
    for (let x = 0; x <= seg; x++) {
      const th = (y / ring) * Math.PI, ph = (x / seg) * Math.PI * 2, o = (y * (seg + 1) + x) * 3;
      pos[o] = Math.sin(th) * Math.cos(ph);
      pos[o + 1] = Math.cos(th);
      pos[o + 2] = Math.sin(th) * Math.sin(ph);
    }
  }
  for (let y = 0; y < ring; y++) {
    for (let x = 0; x < seg; x++) {
      const a = y * (seg + 1) + x, b = a + seg + 1;
      idx.push(a, b, a + 1, b, b + 1, a + 1);
    }
  }
  const preview = { meshes: [{ positions: pos, normals: null, indices: new Uint32Array(idx), colors: null, material: 0 }], materials: [{ color: [1, 0.3, 0.1], colorLinear: false }] };
  assert.ok(idx.length / 3 > 55000);
  const tris = projectTriangles(preview, 256, { maxTris: 3000 });
  assert.ok(tris.length > 1200 && tris.length <= 3000 * 1.15, `triángulos tras decimar: ${tris.length}`);
});

// ── Decimado que conserva textura, UV y materiales ───────────────────────────────────────────
// Mitad de esfera de radio 1 (polo +y si lower=false, −y si lower=true) con su propia isla de UV.
function hemisphere({ lower = false, seg = 200, ring = 75, u0 = 0, uSpan = 0.4, material = 0, withUv = true, withNormals = true }) {
  const pos = [], nor = [], uv = [], idx = [];
  for (let j = 0; j <= ring; j++) {
    const th = lower ? Math.PI / 2 + (j / ring) * (Math.PI / 2) : (j / ring) * (Math.PI / 2);
    for (let i = 0; i <= seg; i++) {
      const ph = (i / seg) * Math.PI * 2;
      const x = Math.sin(th) * Math.cos(ph), y = Math.cos(th), z = Math.sin(th) * Math.sin(ph);
      pos.push(x, y, z);
      nor.push(x, y, z);
      uv.push(u0 + uSpan * (i / seg), j / ring);
    }
  }
  for (let j = 0; j < ring; j++) {
    for (let i = 0; i < seg; i++) {
      const a = j * (seg + 1) + i, b = a + 1, c = a + seg + 1, d = c + 1;
      idx.push(a, b, c, b, d, c); // cara frontal hacia fuera
    }
  }
  return {
    name: lower ? 'inferior' : 'superior',
    positions: Float32Array.from(pos),
    normals: withNormals ? Float32Array.from(nor) : null,
    uvs: withUv ? Float32Array.from(uv) : null,
    colors: null,
    indices: Uint32Array.from(idx),
    material,
  };
}

test('decimateMeshes con textura: UV conservadas, una malla por material, sin mezclar islas', () => {
  const upper = hemisphere({ u0: 0, material: 0 });
  const lower = hemisphere({ lower: true, u0: 0.6, material: 1 });
  const mats = [{ map: 0 }, { map: 1 }];
  const out = decimateMeshes([upper, lower], 6000, { materials: mats });
  assert.equal(out.length, 2, 'una malla por material');
  assert.deepEqual(out.map((m) => m.material).sort(), [0, 1]);
  const tris = totalTris(out);
  assert.ok(tris > 3000 && tris <= 6000 * 1.15, `triángulos: ${tris}`);
  for (const m of out) {
    assert.ok(m.uvs && m.uvs.length === (m.positions.length / 3) * 2, 'UV por vértice');
    assert.ok(m.normals.length === m.positions.length && m.indices.length % 3 === 0);
    const isLower = m.material === 1;
    for (let v = 0; v < m.positions.length / 3; v++) {
      const u = m.uvs[v * 2], w = m.uvs[v * 2 + 1];
      assert.ok(u >= 0 && u <= 1 && w >= 0 && w <= 1, `UV fuera de rango: ${u}, ${w}`);
      assert.ok(isLower ? u >= 0.6 - 1e-6 : u <= 0.4 + 1e-6, 'la UV pertenece a la isla de su material');
      const x = m.positions[v * 3], y = m.positions[v * 3 + 1], z = m.positions[v * 3 + 2];
      if (Math.abs(y) > 0.85 || Math.hypot(x, y, z) < 0.9) continue; // cerca del polo la UV cambia muy rápido
      // La UV guardada debe corresponder a la posición del vértice (misma zona de la esfera).
      const th = Math.acos(Math.max(-1, Math.min(1, y / Math.hypot(x, y, z))));
      const vExpected = isLower ? (th - Math.PI / 2) / (Math.PI / 2) : th / (Math.PI / 2);
      assert.ok(Math.abs(w - vExpected) < 0.12, `v=${w} esperado≈${vExpected}`);
      let ph = Math.atan2(z, x);
      if (ph < 0) ph += Math.PI * 2;
      const uExpected = (isLower ? 0.6 : 0) + 0.4 * (ph / (Math.PI * 2));
      let du = Math.abs(u - uExpected);
      du = Math.min(du, 0.4 - du); // la costura da la vuelta
      assert.ok(du < 0.1, `u=${u} esperado≈${uExpected}`);
    }
    // Ningún triángulo une vértices de zonas de textura lejanas.
    for (let t = 0; t < m.indices.length; t += 3) {
      const us = [0, 1, 2].map((k) => m.uvs[m.indices[t + k] * 2]);
      const vs = [0, 1, 2].map((k) => m.uvs[m.indices[t + k] * 2 + 1]);
      assert.ok(Math.max(...us) - Math.min(...us) < 0.25 && Math.max(...vs) - Math.min(...vs) < 0.5, 'triángulo estirado entre zonas de la textura');
    }
  }
});

test('decimateMeshes: material sin textura no conserva UV; sin normales se calculan', () => {
  const m = hemisphere({ withNormals: false });
  const out = decimateMeshes([m], 4000, { materials: [{ map: -1 }] });
  assert.equal(out.length, 1);
  assert.equal(out[0].uvs, null);
  assert.ok(out[0].normals && out[0].normals.length === out[0].positions.length);
  for (let i = 0; i < out[0].normals.length; i += 3) approx(Math.hypot(out[0].normals[i], out[0].normals[i + 1], out[0].normals[i + 2]), 1, 1e-3);
});

test('decimateMeshes: triángulos coherentes con las normales aunque la malla tenga ruido (sin puntos oscuros)', () => {
  // Un escaneo real tiene ruido: al fundir vértices aparecen triángulos plegados que hay que reorientar.
  let seed = 12345;
  const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296 - 0.5);
  const noisy = (m) => {
    for (let i = 0; i < m.positions.length; i++) m.positions[i] += rnd() * 0.05;
    return m;
  };
  const out = decimateMeshes([noisy(hemisphere({ seg: 300, ring: 110 })), noisy(hemisphere({ lower: true, seg: 300, ring: 110, u0: 0.6 }))], 8000, { materials: [{ map: 0 }] });
  let bad = 0, total = 0;
  for (const m of out) {
    const p = m.positions, n = m.normals;
    for (let t = 0; t < m.indices.length; t += 3) {
      const a = m.indices[t] * 3, b = m.indices[t + 1] * 3, c = m.indices[t + 2] * 3;
      const ux = p[b] - p[a], uy = p[b + 1] - p[a + 1], uz = p[b + 2] - p[a + 2];
      const vx = p[c] - p[a], vy = p[c + 1] - p[a + 1], vz = p[c + 2] - p[a + 2];
      const fx = uy * vz - uz * vy, fy = uz * vx - ux * vz, fz = ux * vy - uy * vx;
      const dot = fx * (n[a] + n[b] + n[c]) + fy * (n[a + 1] + n[b + 1] + n[c + 1]) + fz * (n[a + 2] + n[b + 2] + n[c + 2]);
      total++;
      if (dot < 0) bad++;
    }
  }
  assert.ok(total > 4000);
  // Sin la corrección contradicen sus normales más del 25 % (ruido muy fuerte); con ella, solo restos mínimos.
  assert.ok(bad / total < 0.02, `${bad} de ${total} triángulos contradicen sus normales`);
});

test('decimateCluster (versión de una sola malla) sigue juntando materiales sin UV', () => {
  const a = hemisphere({ material: 0 }), b = hemisphere({ lower: true, material: 3 });
  const one = decimateCluster([a, b], 5000);
  assert.equal(one.uvs, null);
  assert.equal(one.material, 0);
  assert.ok(totalTris([one]) > 2500 && totalTris([one]) <= 5000 * 1.15);
});

test('GLB con textura incrustada: la vista previa simplificada conserva imagen, material y UV', async () => {
  const sphere = hemisphere({ seg: 260, ring: 130, uSpan: 1 });
  const png = Uint8Array.from(Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64'));
  const glb = buildGlb([{ positions: sphere.positions, normals: sphere.normals, uvs: sphere.uvs, indices: sphere.indices, color: [1, 1, 1], texture: { mime: 'image/png', bytes: png } }]);
  const r = await parseModel({ format: 'glb', file: new Blob([glb]), budgetTris: 9000 });
  assert.equal(r.stats.textures, 1);
  assert.equal(r.stats.simplified, true);
  assert.ok(r.stats.previewTriangles > 4000 && r.stats.previewTriangles <= 9000 * 1.15, `previa: ${r.stats.previewTriangles}`);
  assert.equal(r.preview.images.length, 1, 'la imagen sigue disponible tras simplificar');
  assert.equal(r.preview.images[0].mime, 'image/png');
  assert.equal(r.preview.materials[0].map, 0);
  for (const m of r.preview.meshes) {
    assert.ok(m.uvs, 'la malla simplificada conserva UV');
    assert.equal(m.material, 0);
  }
  // Sin simplificar (presupuesto infinito) la geometría es la original.
  const full = await parseModel({ format: 'glb', file: new Blob([glb]), budgetTris: Infinity });
  assert.equal(full.stats.simplified, false);
  assert.equal(totalTris(full.preview.meshes), r.stats.triangles);
  assert.equal(full.preview.images.length, 1);
});

// ── Miniaturas: cuándo conviene redibujarlas ─────────────────────────────────────────────────
import { thumbOutdated } from '../js/import/importer.js';
import { THUMB_VERSION } from '../js/config.js';

test('thumbOutdated: solo los modelos con textura y miniatura de una versión anterior', () => {
  const textured = { stats: { textures: 1 } };
  assert.equal(thumbOutdated({ ...textured }, { webgl: true }), true, 'sin versión = versión 1');
  assert.equal(thumbOutdated({ ...textured, thumbVersion: 1 }, { webgl: true }), true);
  assert.equal(thumbOutdated({ ...textured, thumbVersion: 1 }, { webgl: false }), false, 'sin WebGL no se puede mejorar');
  assert.equal(thumbOutdated({ ...textured, thumbVersion: THUMB_VERSION, thumbMode: 'webgl' }, { webgl: true }), false);
  assert.equal(thumbOutdated({ stats: { textures: 0 }, thumbVersion: 1 }, { webgl: true }), false, 'sin texturas la miniatura es igual');
  assert.equal(thumbOutdated({ stats: {} }, { webgl: true }), false);
  // En 2D no hay textura, pero solo se ofrece rehacerla si Three.js está cargado (en Node no lo está).
  assert.equal(thumbOutdated({ ...textured, thumbVersion: THUMB_VERSION, thumbMode: '2d' }, { webgl: true }), false);
});
