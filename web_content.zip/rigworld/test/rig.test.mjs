// Pruebas del esqueleto automático y la animación (Node, sin navegador ni Three.js).
// Ejecutar: node --test test/rig.test.mjs
// Usan humanoides sintéticos con la verdad conocida (test/synth.mjs). Lo que NO cubren (WebGL real, cargadores
// FBX/GLB de Three.js) se prueba en el navegador con test/browser.mjs.
import test from 'node:test';
import assert from 'node:assert/strict';

import { makeHumanoid } from './synth.mjs';
import { BONE_NAMES } from '../js/core/skeletonTemplate.js';
import { qFromFrames, qRotate, qMul, qConj, qAxisAngle, v3 } from '../js/rig/mathq.js';
import { fitRigRecord, isRigCompatible, orientMeshes, skinAndAssess, describeRig, RIG_VERSION } from '../js/rig/service.js';
import { poseJoints, poseToLocal, poseIsFinite, skinPositions, restPose, IDX, BONE_COUNT, PARENTS } from '../js/rig/skeleton.js';
import { computeSkinWeights, quantizeWeights, dequantizeWeights, weightStats } from '../js/rig/weights.js';
import { createGait, solveTwoBone } from '../js/rig/gait.js';
import { createAnimator } from '../js/rig/animator.js';
import { openStore } from '../js/storage/db.js';

const STEP = 0.03; // malla sintética ligera: el ajuste no depende de la resolución
const humanoid = (o = {}) => makeHumanoid({ step: STEP, ...o });
const SIDES = ['Left', 'Right'];

// Un ajuste por caso, compartido entre pruebas.
const cache = new Map();
function rigFor(label, opts) {
  if (!cache.has(label)) {
    const src = humanoid(opts);
    const record = fitRigRecord(src.meshes);
    cache.set(label, { src, record, rig: record.rig });
  }
  return cache.get(label);
}

// ── Matemática ────────────────────────────────────────────────────────────────────────────────
test('qFromFrames lleva el eje y la referencia de reposo a los nuevos sin torsión', () => {
  const a0 = [0, -1, 0], r0 = [0, 0, 1];
  const a1 = v3.norm([0.3, -0.8, 0.5]), r1 = [0, 0, 1];
  const q = qFromFrames(a0, r0, a1, r1);
  const a = qRotate(q, a0);
  for (let i = 0; i < 3; i++) assert.ok(Math.abs(a[i] - a1[i]) < 1e-9);
  // La referencia proyectada ⟂ al eje queda en el plano (a1, r1): no hay giro alrededor del hueso.
  const r = qRotate(q, r0);
  const n = v3.norm(v3.cross(a1, r1));
  assert.ok(Math.abs(v3.dot(r, n)) < 1e-9);
});

test('qFromFrames no se degenera cuando el eje coincide con la referencia', () => {
  const q = qFromFrames([0, -1, 0], [0, 0, 1], [0, 0, 1], [0, 0, 1]);
  assert.ok(q.every(Number.isFinite));
  const a = qRotate(q, [0, -1, 0]);
  assert.ok(Math.abs(a[2] - 1) < 1e-9);
});

test('IK de dos huesos conserva las longitudes y alcanza el objetivo', () => {
  const H = [0, 1, 0], A = [0.1, 0.25, 0.3];
  const { knee, ankle, reach } = solveTwoBone(H, A, 0.45, 0.45, [0, 0, 1]);
  assert.ok(Math.abs(v3.dist(H, knee) - 0.45) < 1e-9);
  assert.ok(Math.abs(v3.dist(knee, ankle) - 0.45) < 1e-9);
  assert.ok(v3.dist(ankle, A) < 1e-9 && reach < 0.9);
  assert.ok(knee[2] > H[2], 'la rodilla se dobla hacia el frente');
  // Fuera de alcance: se estira sin romperse ni dar NaN.
  const far = solveTwoBone(H, [0, -5, 0], 0.45, 0.45, [0, 0, 1]);
  assert.ok(far.knee.every(Number.isFinite) && v3.dist(H, far.ankle) < 0.9);
});

// ── Ajuste del esqueleto ──────────────────────────────────────────────────────────────────────
const FIT_CASES = [
  ['T', { pose: 'T' }],
  ['A', { pose: 'A' }],
  ['brazos abajo', { pose: 'down' }],
  ['piernas fundidas', { pose: 'A', legSplay: 0 }],
  ['piernas abiertas 12°', { pose: 'A', legSplay: 12 }],
  ['rotado, Z arriba, escalado y desplazado', { pose: 'A', yaw: 0.9, up: 'z', scale: 37, offset: [3, -2, 5] }],
];
for (const [label, opts] of FIT_CASES) {
  test(`ajuste: ${label} coloca las articulaciones a menos de 0,06 H de la verdad`, () => {
    const { src, record } = rigFor(label, opts);
    const H = record.rig.height;
    const sc = opts.scale || 1;
    assert.ok(record.confidence >= 0.7, `confianza ${record.confidence}`);
    for (const n of ['Hips', 'Neck', 'Head', 'LeftUpperArm', 'LeftLowerArm', 'LeftHand', 'LeftUpperLeg', 'LeftLowerLeg', 'LeftFoot', 'RightUpperArm', 'RightHand', 'RightLowerLeg', 'RightFoot']) {
      const t = src.truth[n];
      if (!t) continue;
      const j = record.rig.joints[IDX[n]];
      const err = Math.hypot(j[0] - t[0] * sc, j[1] - t[1] * sc, j[2] - t[2] * sc) / H;
      assert.ok(err < 0.06, `${n}: error ${err.toFixed(3)} H`);
    }
  });
}

test('ajuste: detecta el frente aunque el modelo mire hacia atrás (180°)', () => {
  const { record } = rigFor('de espaldas', { pose: 'A', yaw: Math.PI });
  const z = (n) => record.rig.tips[`toe${n}`][2] - record.rig.joints[IDX[`${n}Foot`]][2];
  assert.ok(z('Left') > 0.03 && z('Right') > 0.03, 'la punta del pie debe quedar delante (+Z) del tobillo');
});

test('ajuste: el izquierdo queda en +X y los pies en y = 0', () => {
  const { record } = rigFor('A', { pose: 'A' });
  const J = record.rig.joints;
  assert.ok(J[IDX.LeftUpperArm][0] > 0 && J[IDX.RightUpperArm][0] < 0);
  assert.ok(J[IDX.LeftUpperLeg][0] > 0 && J[IDX.RightUpperLeg][0] < 0);
  assert.ok(Math.abs(record.rig.tips.toeLeft[1]) < 0.05 * record.rig.height);
});

test('el registro de rig es serializable y reconocible como compatible', () => {
  const { record } = rigFor('A', { pose: 'A' });
  const copy = structuredClone(record);
  assert.deepEqual(copy.rig.joints, record.rig.joints);
  assert.ok(isRigCompatible(copy));
  assert.ok(!isRigCompatible({ ...copy, version: RIG_VERSION + 1 }));
  assert.ok(!isRigCompatible({ ...copy, fitVersion: 99 }));
  assert.ok(!isRigCompatible(null));
  assert.ok(JSON.stringify(record).length < 12000, 'el rig guardado es pequeño (unos KB)');
});

test('una malla casi vacía da un error claro, no un esqueleto basura', () => {
  assert.throws(() => fitRigRecord([{ positions: new Float32Array([0, 0, 0, 1, 1, 1]) }]), /poca geometr/i);
});

// ── Pesos ─────────────────────────────────────────────────────────────────────────────────────
test('pesos: suman 1, máximo 4 huesos y las piernas no se arrastran entre sí', () => {
  const { src, record } = rigFor('A', { pose: 'A' });
  const meshes = orientMeshes(src.meshes, record.rig);
  const w = computeSkinWeights(meshes, record.rig);
  const n = meshes[0].positions.length / 3;
  for (let v = 0; v < n; v += 7) {
    let s = 0;
    for (let k = 0; k < 4; k++) {
      assert.ok(w[0].skinWeight[v * 4 + k] >= 0);
      s += w[0].skinWeight[v * 4 + k];
    }
    assert.ok(Math.abs(s - 1) < 1e-4, `vértice ${v}: suma ${s}`);
  }
  const st = weightStats(meshes[0].positions, w[0].skinIndex, w[0].skinWeight);
  assert.equal(st.crossLeg, 0, 'ningún vértice de una pierna pesa sobre la otra');
});

test('pesos: el pie se mueve como un sólido (la mayoría de sus vértices pesan 100 % sobre el pie)', () => {
  const { src, record } = rigFor('A', { pose: 'A' });
  const meshes = orientMeshes(src.meshes, record.rig);
  const w = computeSkinWeights(meshes, record.rig)[0];
  const P = meshes[0].positions;
  let foot = 0, rigid = 0;
  for (let v = 0; v < P.length / 3; v++) {
    if (P[v * 3 + 1] < 0.03 * record.rig.height) {
      foot++;
      let wf = 0;
      for (let k = 0; k < 4; k++) if (w.skinIndex[v * 4 + k] === IDX.LeftFoot || w.skinIndex[v * 4 + k] === IDX.RightFoot) wf += w.skinWeight[v * 4 + k];
      if (wf > 0.995) rigid++;
    }
  }
  assert.ok(foot > 100 && rigid / foot > 0.9, `${rigid}/${foot} vértices del pie son rígidos`);
});

test('cuantizar pesos a bytes conserva la suma exacta (255) y el valor', () => {
  const w = new Float32Array([0.5, 0.25, 0.25, 0, 1, 0, 0, 0, 0.333333, 0.333333, 0.333334, 0]);
  const q = quantizeWeights(w);
  for (let v = 0; v < 3; v++) assert.equal(q[v * 4] + q[v * 4 + 1] + q[v * 4 + 2] + q[v * 4 + 3], 255);
  const d = dequantizeWeights(q);
  for (let i = 0; i < w.length; i++) assert.ok(Math.abs(d[i] - w[i]) < 0.005);
});

test('la malla en reposo no cambia al aplicar la pose de reposo', () => {
  const { src, record } = rigFor('A', { pose: 'A' });
  const meshes = orientMeshes(src.meshes, record.rig);
  const w = computeSkinWeights(meshes, record.rig)[0];
  const out = skinPositions(record.rig, restPose(), meshes[0].positions, w.skinIndex, w.skinWeight);
  let worst = 0;
  for (let i = 0; i < out.length; i++) worst = Math.max(worst, Math.abs(out[i] - meshes[0].positions[i]));
  assert.ok(worst < 1e-4, `desviación ${worst}`);
});

test('poseToLocal y poseJoints son coherentes (rotación local = inv(padre)·mundo)', () => {
  const { record } = rigFor('A', { pose: 'A' });
  const rig = record.rig;
  const pose = restPose();
  pose.world[IDX.LeftUpperLeg] = qAxisAngle([1, 0, 0], -0.6);
  pose.world[IDX.LeftLowerLeg] = qAxisAngle([1, 0, 0], 0.2);
  const { quats } = poseToLocal(rig, pose);
  // Recomponer el mundo desde lo local debe dar lo mismo.
  const world = [];
  for (let i = 0; i < BONE_COUNT; i++) world[i] = PARENTS[i] < 0 ? quats[i] : qMul(world[PARENTS[i]], quats[i]);
  for (let i = 0; i < BONE_COUNT; i++) for (let k = 0; k < 4; k++) assert.ok(Math.abs(world[i][k] - pose.world[i][k]) < 1e-9);
  const J = poseJoints(rig, pose);
  assert.ok(Math.abs(v3.dist(J[IDX.LeftLowerLeg], J[IDX.LeftUpperLeg]) - v3.len(rig.local[IDX.LeftLowerLeg])) < 1e-9);
});

// ── Marcha y carrera ──────────────────────────────────────────────────────────────────────────
const footPoints = (rig, pose, pos, s) => {
  const J = rig.joints, name = SIDES[s];
  const a0 = J[IDX[`${name}Foot`]], toe0 = rig.tips[`toe${name}`];
  const q = pose.world[IDX[`${name}Foot`]], ank = pos[IDX[`${name}Foot`]];
  const w = (p) => v3.add(ank, qRotate(q, v3.sub(p, a0)));
  return { heel: w([a0[0], 0, a0[2] - rig.heelBack[s]]), ball: w([a0[0], 0, a0[2] + 0.72 * (toe0[2] - a0[2])]), toe: w([toe0[0], 0, toe0[2]]) };
};

for (const poseName of ['A', 'T', 'down']) {
  const label = poseName === 'down' ? 'brazos abajo' : poseName;
  test(`marcha (${label}): huesos rígidos, sin NaN, continua y cierra el ciclo`, () => {
    const { record } = rigFor(label, { pose: poseName });
    const rig = record.rig, gait = createGait(rig);
    for (const u of [0, 0.3, 0.55, 0.72, 0.88, 1]) {
      let prev = null;
      const N = 240;
      for (let i = 0; i <= N; i++) {
        const r = gait.walkRun((i / N) % 1, u);
        assert.ok(poseIsFinite(r.pose), `u=${u} fase ${i / N}`);
        const pos = poseJoints(rig, r.pose);
        for (let k = 1; k < BONE_COUNT; k++) assert.ok(Math.abs(v3.dist(pos[k], pos[PARENTS[k]]) - v3.len(rig.local[k])) < 1e-6, 'longitud de hueso');
        if (prev) {
          for (let k = 0; k < BONE_COUNT; k++) {
            const a = r.pose.world[k], b = prev[k];
            const ang = 2 * Math.acos(Math.min(1, Math.abs(a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3])));
            assert.ok(ang < 0.08, `${BONE_NAMES[k]} salta ${(ang * 57.3).toFixed(1)}° entre fotogramas (u=${u})`);
          }
        }
        prev = r.pose.world;
      }
      const a = poseJoints(rig, gait.walkRun(0, u).pose), b = poseJoints(rig, gait.walkRun(0.99999, u).pose);
      a.forEach((p, i) => assert.ok(v3.dist(p, b[i]) < 1e-3 * rig.height, 'el ciclo cierra'));
    }
  });

  test(`marcha (${label}): el pie en apoyo no patina, no atraviesa el suelo y al correr hay fase de vuelo`, () => {
    const { record } = rigFor(label, { pose: poseName });
    const rig = record.rig, gait = createGait(rig), H = rig.height;
    for (const [u, flight] of [[0.3, false], [0.88, true]]) {
      const v = gait.speedAt(u), T = gait.paramsAt(u).T;
      let minY = Infinity, slide = 0, flightFrames = 0;
      const N = 240;
      const tracks = {};
      for (let i = 0; i < N; i++) {
        const r = gait.walkRun(i / N, u);
        const pos = poseJoints(rig, r.pose);
        if (!r.stance[0] && !r.stance[1]) flightFrames++;
        [0, 1].forEach((s) => {
          const f = footPoints(rig, r.pose, pos, s);
          for (const pt of ['heel', 'ball', 'toe']) {
            minY = Math.min(minY, f[pt][1]);
            const key = `${s}${pt}`;
            if (r.stance[s] && Math.abs(f[pt][1]) < 0.0015) {
              const z = f[pt][2] + v * (i / N) * T;
              let t = tracks[key];
              if (!t || i !== t.last + 1) {
                if (t) slide = Math.max(slide, t.hi - t.lo);
                t = tracks[key] = { lo: z, hi: z, last: i };
              } else {
                t.lo = Math.min(t.lo, z);
                t.hi = Math.max(t.hi, z);
                t.last = i;
              }
            }
          }
        });
      }
      for (const t of Object.values(tracks)) slide = Math.max(slide, t.hi - t.lo);
      assert.ok(minY > -0.006 * H, `u=${u}: la suela baja a ${minY.toFixed(4)}`);
      assert.ok(slide < 0.01 * H, `u=${u}: el pie patina ${slide.toFixed(4)}`);
      if (flight) assert.ok(flightFrames > 20, 'al correr debe haber fase de vuelo');
      else assert.equal(flightFrames, 0, 'al caminar siempre hay un pie en el suelo');
    }
  });
}

test('velocidad: crece con u y uForSpeed es su inversa', () => {
  const { record } = rigFor('A', { pose: 'A' });
  const gait = createGait(record.rig);
  let last = -1;
  for (let i = 0; i <= 20; i++) {
    const s = gait.speedAt(i / 20);
    assert.ok(s > last, 'la velocidad crece con u');
    last = s;
  }
  for (const u of [0.2, 0.5, 0.8]) assert.ok(Math.abs(gait.uForSpeed(gait.speedAt(u)) - u) < 1e-6);
  assert.equal(gait.uForSpeed(0), 0);
  assert.equal(gait.uForSpeed(1e9), 1);
});

test('los brazos se balancean en oposición a las piernas', () => {
  const { record } = rigFor('A', { pose: 'A' });
  const rig = record.rig, gait = createGait(rig);
  // Con el pie izquierdo delante (fase 0, talón), la mano derecha debe ir delante de la izquierda.
  for (const u of [0.3, 0.88]) {
    const J = poseJoints(rig, gait.walkRun(0.02, u).pose);
    const handZ = (n) => J[IDX[`${n}Hand`]][2];
    const footZ = (n) => J[IDX[`${n}Foot`]][2];
    assert.ok(footZ('Left') > footZ('Right'), 'pie izquierdo delante');
    assert.ok(handZ('Right') > handZ('Left'), `u=${u}: brazo derecho delante cuando el pie izquierdo va delante`);
  }
});

test('salto: despega, vuelve al suelo y nunca hunde los pies; saludo levanta el brazo derecho', () => {
  const { record } = rigFor('A', { pose: 'A' });
  const rig = record.rig, gait = createGait(rig);
  let maxRoot = -Infinity, minFoot = Infinity;
  for (let t = 0; t <= gait.jumpDuration; t += 0.01) {
    const pose = gait.jump(t);
    assert.ok(poseIsFinite(pose));
    maxRoot = Math.max(maxRoot, pose.root[1]);
    const pos = poseJoints(rig, pose);
    [0, 1].forEach((s) => Object.values(footPoints(rig, pose, pos, s)).forEach((p) => (minFoot = Math.min(minFoot, p[1]))));
  }
  assert.ok(maxRoot > 0.2 * gait.legLen, 'la pelvis sube en el vuelo');
  assert.ok(minFoot > -0.006 * rig.height, `los pies no se hunden (${minFoot.toFixed(4)})`);
  const rest = gait.idle(0);
  const waving = gait.wave(gait.idle(0), 0.8, 1);
  const hand = (p) => poseJoints(rig, p)[IDX.RightHand][1];
  assert.ok(hand(waving) > hand(rest) + 0.2 * rig.height, 'la mano derecha sube');
});

// ── Animador ──────────────────────────────────────────────────────────────────────────────────
function simulate(rig, script, seconds, { fps = 60 } = {}) {
  const an = createAnimator(rig);
  const H = rig.height;
  const dt = 1 / fps;
  let t = 0, si = 0, travelled = 0, nonFinite = 0, slide = 0, prevRoot = null, maxRootJump = 0;
  const contacts = {};
  const log = [];
  while (t < seconds) {
    while (si < script.length && t >= script[si][0]) script[si++][1](an);
    const r = an.update(dt);
    if (!poseIsFinite(r.pose)) nonFinite++;
    const pos = poseJoints(rig, r.pose);
    travelled += r.groundSpeed * dt;
    const st = an.state;
    if (r.state !== 'jump' && st.loco >= 1 && r.groundSpeed > 0.01) {
      const beta = an.gait.paramsAt(r.u).beta;
      [0, 1].forEach((s) => {
        const inStance = ((r.phase + 0.5 * s) % 1) < beta;
        const f = footPoints(rig, r.pose, pos, s);
        for (const pt of ['heel', 'ball', 'toe']) {
          const key = `${s}${pt}`;
          if (inStance && f[pt][1] < 0.0015) {
            const wz = f[pt][2] + travelled;
            if (contacts[key] === undefined) contacts[key] = wz;
            else slide = Math.max(slide, Math.abs(wz - contacts[key]));
          } else delete contacts[key];
        }
      });
    } else for (const k of Object.keys(contacts)) delete contacts[k];
    if (prevRoot) maxRootJump = Math.max(maxRootJump, v3.dist(pos[0], prevRoot) / H);
    prevRoot = pos[0];
    log.push({ t, ...r, loco: st.loco });
    t += dt;
  }
  return { an, log, nonFinite, slide, maxRootJump, H };
}

test('animador: arrancar, acelerar, frenar, saltar y saludar no produce NaN ni saltos, y el pie no patina', () => {
  const { rig } = rigFor('A', { pose: 'A' });
  const sp = createAnimator(rig).speeds;
  const sim = simulate(rig, [
    [0.5, (a) => a.setSpeed(sp.walk)], [3, (a) => a.setSpeed(sp.run)], [6, (a) => a.setSpeed(sp.walk * 0.6)], [8, (a) => a.setSpeed(0)],
    [10.5, (a) => a.wave()], [14, (a) => a.setSpeed(sp.trot)], [16, (a) => a.jump()], [18, (a) => a.setSpeed(sp.sprint)], [20, (a) => a.setSpeed(0)], [22, (a) => a.jump()],
  ], 24);
  assert.equal(sim.nonFinite, 0);
  assert.ok(sim.slide < 0.03 * sim.H, `deslizamiento máximo ${(sim.slide / sim.H * 100).toFixed(2)} % de la altura`);
  assert.ok(sim.maxRootJump < 0.05, `la pelvis salta ${sim.maxRootJump.toFixed(3)} H en un fotograma`);
  assert.ok(sim.log.some((f) => f.state === 'jump') && sim.log.some((f) => f.waving), 'se ejecutaron salto y saludo');
});

test('animador: a velocidad constante la velocidad del suelo coincide con la pedida', () => {
  const { rig } = rigFor('A', { pose: 'A' });
  const sp = createAnimator(rig).speeds;
  const sim = simulate(rig, [[0, (a) => a.setSpeed(sp.run)]], 5);
  const last = sim.log.at(-1);
  assert.ok(Math.abs(last.groundSpeed - sp.run) < 0.01 * sp.run, `${last.groundSpeed} vs ${sp.run}`);
});

test('animador: al parar termina en un cruce de pasos y se funde con el reposo (no se congela a medio paso)', () => {
  const { rig } = rigFor('A', { pose: 'A' });
  const sp = createAnimator(rig).speeds;
  const sim = simulate(rig, [[0.2, (a) => a.setSpeed(sp.run)], [3, (a) => a.setSpeed(0)]], 8);
  const end = sim.log.at(-1);
  assert.equal(end.moving, false);
  assert.equal(end.speed, 0);
  assert.equal(end.loco, 0, 'el peso de la marcha llega a 0');
  assert.ok(Math.abs(end.phase - 0.25) < 1e-6 || Math.abs(end.phase - 0.75) < 1e-6, `fase de parada ${end.phase}`);
  // Y vuelve a arrancar desde ahí sin NaN.
  const again = simulate(rig, [[0.2, (a) => a.setSpeed(sp.walk)]], 3);
  assert.equal(again.nonFinite, 0);
});

test('animador: salto y saludo terminan solos; no se puede saltar dos veces a la vez', () => {
  const { rig } = rigFor('A', { pose: 'A' });
  const an = createAnimator(rig);
  assert.equal(an.jump(), true);
  assert.equal(an.jump(), false);
  assert.equal(an.wave(), true);
  for (let i = 0; i < 60 * 5; i++) an.update(1 / 60);
  assert.equal(an.isJumping, false);
  assert.equal(an.isWaving, false);
  assert.equal(an.jump(), true, 'se puede volver a saltar');
});

test('animador: tolera dt raro (0, enorme, NaN) y velocidades absurdas', () => {
  const { rig } = rigFor('A', { pose: 'A' });
  const an = createAnimator(rig);
  an.setSpeed(NaN);
  an.setSpeed(1e12);
  for (const dt of [0, 5, NaN, -1, 0.016, undefined]) assert.ok(poseIsFinite(an.update(dt).pose));
  assert.ok(an.state.speed <= an.speeds.sprint * 1.15 + 1e-9);
});

// ── Calidad y avisos ──────────────────────────────────────────────────────────────────────────
test('calidad: T y A salen buenas; brazos pegados al cuerpo se avisan', () => {
  const grade = (label, opts) => {
    const { src, record } = rigFor(label, opts);
    const { quality } = skinAndAssess(orientMeshes(src.meshes, record.rig), record.rig);
    return { quality, record };
  };
  const a = grade('A', { pose: 'A' }), t = grade('T', { pose: 'T' }), d = grade('brazos abajo', { pose: 'down' });
  assert.equal(a.quality.level, 'good');
  assert.equal(t.quality.level, 'good');
  assert.equal(d.quality.level, 'poor');
  assert.ok(a.quality.severePct < d.quality.severePct);
  assert.equal(describeRig(a.record, a.quality).length, 0);
  assert.ok(describeRig(d.record, d.quality).some((n) => n.kind === 'warn' && /brazos/i.test(n.text)));
});

// ── Persistencia (almacén en memoria; IndexedDB real se prueba en el navegador) ──────────────
test('almacén: guarda, lee y borra el rig, y borrar el modelo borra su rig', async () => {
  const store = await openStore('rigtest-' + Math.random());
  try {
    const { record } = rigFor('A', { pose: 'A' });
    const saved = await store.saveModel({ name: 'x', format: 'glb', files: [{ name: 'x.glb', data: new Uint8Array([1, 2, 3]), role: 'main' }] });
    assert.equal(await store.getRig(saved.id), null);
    await store.saveRig(saved.id, record);
    const back = await store.getRig(saved.id);
    assert.ok(isRigCompatible(back));
    assert.deepEqual(back.rig.joints, record.rig.joints);
    await store.deleteRig(saved.id);
    assert.equal(await store.getRig(saved.id), null);
    await store.saveRig(saved.id, record);
    await store.deleteModel(saved.id);
    assert.equal(await store.getRig(saved.id), null, 'borrar el modelo borra también su esqueleto');
  } finally {
    store.close?.();
  }
});

test('huesos: el orden y los padres del rig coinciden con la plantilla de 19 huesos', () => {
  assert.equal(BONE_COUNT, 19);
  assert.equal(BONE_NAMES.length, 19);
  assert.equal(PARENTS[0], -1);
  PARENTS.forEach((p, i) => i > 0 && assert.ok(p >= 0 && p < i, 'los padres van antes que los hijos'));
});
