// Piezas de prueba compartidas por test/retarget.test.mjs y test/browser.mjs: construyen el esqueleto de «otro
// personaje» (estilo Mixamo o VRoid) a partir del rig, y una animación suya hecha con poses reales del animador.
import { qMul, qConj, qRotY, qRotZ, v3 } from '../js/rig/mathq.js';
import { BONE_COUNT, PARENTS, BONE_NAMES } from '../js/rig/skeleton.js';
import { createAnimator } from '../js/rig/animator.js';

// ── Construcción de un «otro personaje» a partir del rig ───────────────────────────────────────
// Esqueleto estilo Mixamo: Armature (girado/escalado) → Hips → … con huesos extra sin equivalente (Spine2, dedos, punta).
export function makeSource(rig, { scale = 1, yaw = 0, armScale = 0.01, style = 'mixamo', legStretch = 1, aRest = 0 } = {}) {
  const nm = style === 'vroid'
    ? { Hips: 'J_Bip_C_Hips', Spine: 'J_Bip_C_Spine', Chest: 'J_Bip_C_Chest', Neck: 'J_Bip_C_Neck', Head: 'J_Bip_C_Head', L: 'J_Bip_L_', R: 'J_Bip_R_', sh: 'Shoulder', ua: 'UpperArm', la: 'LowerArm', ha: 'Hand', ul: 'UpperLeg', ll: 'LowerLeg', ft: 'Foot' }
    : { Hips: 'mixamorig:Hips', Spine: 'mixamorig:Spine', Chest: 'mixamorig:Spine1', Neck: 'mixamorig:Neck', Head: 'mixamorig:Head', L: 'mixamorig:Left', R: 'mixamorig:Right', sh: 'Shoulder', ua: 'Arm', la: 'ForeArm', ha: 'Hand', ul: 'UpLeg', ll: 'Leg', ft: 'Foot' };
  const name = (b) => {
    if (['Hips', 'Spine', 'Chest', 'Neck', 'Head'].includes(b)) return nm[b];
    const side = b.startsWith('Left') ? nm.L : nm.R;
    const kind = b.replace(/^(Left|Right)/, '');
    const m = { Shoulder: nm.sh, UpperArm: nm.ua, LowerArm: nm.la, Hand: nm.ha, UpperLeg: nm.ul, LowerLeg: nm.ll, Foot: nm.ft }[kind];
    return side + m;
  };
  const bones = [];
  const add = (nameStr, parent, pos, rot = [0, 0, 0, 1]) => bones.push({ name: nameStr, parent, pos, rot, scale: 1 }) - 1;
  const yawQ = qRotY(yaw);
  // Armature: gira la orientación y escala las unidades (como un FBX de Mixamo, en cm con escala 0,01).
  bones.push({ name: 'Armature', parent: -1, pos: [0, 0, 0], rot: yawQ, scale: armScale });
  const S = scale / armScale; // posiciones locales en unidades del Armature
  const idx = new Array(BONE_COUNT);
  const legMul = (b) => (legStretch !== 1 && /LowerLeg|Foot$/.test(b) ? legStretch : 1);
  for (let b = 0; b < BONE_COUNT; b++) {
    const p = PARENTS[b];
    const local = b === 0 ? rig.joints[0] : rig.local[b];
    const pos = v3.mul(local, S * legMul(BONE_NAMES[b]));
    const parentIdx = p < 0 ? 0 : idx[p];
    let rot = [0, 0, 0, 1];
    if (aRest && /UpperArm$/.test(BONE_NAMES[b])) rot = qRotZ(BONE_NAMES[b].startsWith('Left') ? -aRest : aRest); // brazos hacia abajo en el reposo
    if (BONE_NAMES[b] === 'Neck') {
      // Hueso extra entre el pecho y el cuello, como Spine2 de Mixamo (sin equivalente en el rig).
      const extra = add(`${style === 'vroid' ? 'J_Bip_C_UpperChest' : 'mixamorig:Spine2'}`, parentIdx, v3.mul(pos, 0.5));
      idx[b] = add(name(BONE_NAMES[b]), extra, v3.mul(pos, 0.5));
    } else {
      idx[b] = add(name(BONE_NAMES[b]), parentIdx, pos, rot);
    }
    if (BONE_NAMES[b].endsWith('Foot')) add(`${name(BONE_NAMES[b])}Toe`.replace('Foot', 'ToeBase'), idx[b], [0, -0.02 * S, 0.12 * S]);
    if (BONE_NAMES[b].endsWith('Hand')) add(`${name(BONE_NAMES[b])}Index1`, idx[b], [0.05 * S * (BONE_NAMES[b].startsWith('Left') ? 1 : -1), 0, 0]);
  }
  return { bones, idx, scale, yaw, S };
}

// Clip del «otro personaje» a partir de poses del rig (giros locales idénticos; las caderas se mueven en las unidades del Armature).
export function clipFromPoses(rig, src, poses, fps = 30, { aRest = 0 } = {}) {
  const times = poses.map((_, i) => i / fps);
  const tr = [];
  for (let b = 0; b < BONE_COUNT; b++) {
    const values = [];
    poses.forEach((p) => {
      const par = PARENTS[b];
      let q = par < 0 ? p.world[b] : qMul(qConj(p.world[par]), p.world[b]);
      if (aRest && /UpperArm$/.test(BONE_NAMES[b])) q = qMul(q, qRotZ(BONE_NAMES[b].startsWith('Left') ? -aRest : aRest));
      values.push(...q);
    });
    tr.push({ node: src.bones[src.idx[b]].name, prop: 'quaternion', times, values });
  }
  const hv = [];
  poses.forEach((p) => hv.push(...v3.mul(v3.add(rig.joints[0], p.root), src.S)));
  tr.push({ node: src.bones[src.idx[0]].name, prop: 'position', times, values: hv });
  return { name: 'marcha', duration: times[times.length - 1], tracks: tr };
}

export function gaitPoses(rig, { speedName = 'walk', seconds = 4, fps = 30 } = {}) {
  const an = createAnimator(rig);
  an.setSpeed(an.speeds[speedName]);
  const poses = [];
  for (let i = 0; i < 2 * fps; i++) an.update((1 / 60) * 2); // arranque
  for (let i = 0; i <= seconds * fps; i++) poses.push(an.update(1 / fps).pose);
  return { poses, an };
}

// Escena en JSON plano (lo que el navegador reconstruye como objetos tipo Three.js para probar la carga de archivos).
export function sceneJSON(src, clip) {
  return {
    nodes: src.bones.map((b, i) => ({ name: b.name, parent: b.parent, position: b.pos, quaternion: b.rot, scale: [b.scale, b.scale, b.scale], isBone: i > 0 })),
    animations: [{ name: clip.name, duration: clip.duration, tracks: clip.tracks.map((t) => ({ name: `${t.node}.${t.prop}`, times: Array.from(t.times), values: Array.from(t.values) })) }],
  };
}
