// Prueba de extremo a extremo en Chromium móvil (Playwright). Sirve el proyecto en local.
// Three.js y las fuentes viven en CDN: si el entorno no tiene red, se prueba la ruta sin motor 3D
// (miniaturas 2D, vista previa con mensaje de error). Con red, también se ejercita el visor.
// Ejecutar: node test/browser.mjs [carpeta-de-capturas]
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import zlib from 'node:zlib';
import { buildGlb } from '../js/import/sample.js';

const require = createRequire('/opt/npm-tools/noop.js');
const { chromium } = require('playwright');
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHOTS = process.argv[2] || path.join(os.tmpdir(), 'rigworld-shots');
fs.mkdirSync(SHOTS, { recursive: true });
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'rigworld-files-'));

const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json' };
const server = http.createServer((req, res) => {
  const url = decodeURIComponent(req.url.split('?')[0]);
  const file = path.join(ROOT, url === '/' ? 'index.html' : url);
  if (!file.startsWith(ROOT) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(404).end('no encontrado');
    return;
  }
  res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-store' });
  fs.createReadStream(file).pipe(res);
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const BASE = `http://127.0.0.1:${server.address().port}/`;

// ── archivos de prueba ─────────────────────────────────────────────────────────────────────────
const CUBE_V = [[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1]];
const QUADS = [[0,3,2,1],[4,5,6,7],[0,1,5,4],[2,3,7,6],[1,2,6,5],[0,4,7,3]];
const TRIS = QUADS.flatMap(([a, b, c, d]) => [[a, b, c], [a, c, d]]);
function stlBinary(tris, verts) {
  const buf = Buffer.alloc(84 + tris.length * 50);
  buf.writeUInt32LE(tris.length, 80);
  tris.forEach((t, i) => {
    let o = 84 + i * 50 + 12;
    for (const vi of t) for (const c of verts[vi]) { buf.writeFloatLE(c, o); o += 4; }
  });
  return buf;
}
function sphereStl(seg, rings) {
  const P = (a, b) => [Math.sin(b) * Math.cos(a), Math.cos(b), Math.sin(b) * Math.sin(a)];
  const n = seg * rings * 2;
  const buf = Buffer.alloc(84 + n * 50);
  buf.writeUInt32LE(n, 80);
  let o = 84;
  const tri = (a, b, c) => { o += 12; for (const p of [a, b, c]) for (const x of p) { buf.writeFloatLE(x, o); o += 4; } o += 2; };
  for (let i = 0; i < seg; i++) for (let j = 0; j < rings; j++) {
    const a0 = (i / seg) * 2 * Math.PI, a1 = ((i + 1) / seg) * 2 * Math.PI, b0 = (j / rings) * Math.PI, b1 = ((j + 1) / rings) * Math.PI;
    tri(P(a0, b0), P(a1, b0), P(a1, b1));
    tri(P(a0, b0), P(a1, b1), P(a0, b1));
  }
  return buf;
}

// PNG de prueba (gradiente) y un GLB con esa textura incrustada: esfera UV de seg×ring×2 triángulos.
function crc32(buf) {
  let crc = 0xffffffff;
  for (const b of buf) {
    crc ^= b;
    for (let k = 0; k < 8; k++) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
  }
  return (~crc) >>> 0;
}
function pngGradient(w, h) {
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 3 + 1)] = 0;
    for (let x = 0; x < w; x++) raw.set([Math.round((x / (w - 1)) * 255), Math.round((y / (h - 1)) * 255), 128], y * (w * 3 + 1) + 1 + x * 3);
  }
  const chunk = (type, data) => {
    const body = Buffer.concat([Buffer.from(type), data]);
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(crc32(body));
    return Buffer.concat([len, body, crc]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr.set([8, 2, 0, 0, 0], 8);
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}
function texturedSphereGlb(seg, ring) {
  const nv = (seg + 1) * (ring + 1);
  const positions = new Float32Array(nv * 3), normals = new Float32Array(nv * 3), uvs = new Float32Array(nv * 2);
  let o = 0, q = 0;
  for (let j = 0; j <= ring; j++) for (let i = 0; i <= seg; i++) {
    const th = (j / ring) * Math.PI, ph = (i / seg) * Math.PI * 2;
    const x = Math.sin(th) * Math.cos(ph), y = Math.cos(th), z = Math.sin(th) * Math.sin(ph);
    positions.set([x * 0.2, y * 0.6, z * 0.2], o);
    normals.set([x, y, z], o);
    uvs.set([i / seg, j / ring], q);
    o += 3;
    q += 2;
  }
  const indices = new Uint32Array(seg * ring * 6);
  let k = 0;
  for (let j = 0; j < ring; j++) for (let i = 0; i < seg; i++) {
    const a = j * (seg + 1) + i, b = a + 1, c = a + seg + 1, d = c + 1;
    indices.set([a, b, c, b, d, c], k);
    k += 6;
  }
  const png = pngGradient(64, 64);
  return Buffer.from(buildGlb([{ positions, normals, uvs, indices, color: [1, 1, 1], texture: { mime: 'image/png', bytes: new Uint8Array(png) } }], { name: 'texturizado' }));
}

const write = (name, data) => { const p = path.join(TMP, name); fs.writeFileSync(p, data); return p; };

let objText = 'mtllib cubo.mtl\nusemtl rojo\n';
for (const v of CUBE_V) objText += `v ${v.join(' ')}\n`;
for (const q of QUADS) objText += `f ${q.map((i) => i + 1).join(' ')}\n`;
const files = {
  stl: write('cubo.stl', stlBinary(TRIS, CUBE_V)),
  obj: write('cubo.obj', objText),
  mtl: write('cubo.mtl', 'newmtl rojo\nKd 0.9 0.2 0.1\n'),
  bad: write('cosa.xyz', 'no soy un modelo'),
  empty: write('vacio.glb', Buffer.alloc(0)),
  fakeGlb: write('roto.glb', 'esto no es un glb de verdad'),
  // Cabecera GLB correcta pero el bloque declarado es mayor que el archivo: pasa la detección y falla al analizar.
  truncGlb: write('danado.glb', (() => { const b = Buffer.alloc(40); b.write('glTF', 0); b.writeUInt32LE(2, 4); b.writeUInt32LE(5000, 8); b.writeUInt32LE(4000, 12); b.writeUInt32LE(0x4e4f534a, 16); return b; })()),
  sphere: write('esfera-grande.stl', sphereStl(400, 250)), // 200 000 triángulos → se simplifica
  texGlb: write('texturizado.glb', texturedSphereGlb(400, 300)), // 240 000 triángulos con textura incrustada
};

// ── navegador ──────────────────────────────────────────────────────────────────────────────────
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 412, height: 915 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, colorScheme: 'dark', locale: 'es-ES' });
const page = await ctx.newPage();
const problems = [];
const ignorable = (t) => /\[import\] danado|fonts\.g|cdn\.jsdelivr|ERR_TUNNEL|ERR_NAME|ERR_INTERNET|Failed to load resource|net::|three|motor 3D|Three\.js/i.test(t);
page.on('console', (m) => { if (m.type() === 'error' && !ignorable(m.text())) problems.push(`console: ${m.text()}`); });
page.on('pageerror', (e) => { if (!ignorable(e.message)) problems.push(`pageerror: ${e.message}`); });

const results = [];
const step = async (name, fn) => {
  const t0 = Date.now();
  try {
    await fn();
    results.push({ name, ok: true, ms: Date.now() - t0 });
    console.log(`  ✔ ${name} (${Date.now() - t0} ms)`);
  } catch (err) {
    results.push({ name, ok: false, err: err.message });
    console.log(`  ✘ ${name}\n      ${err.message.split('\n').slice(0, 6).join('\n      ')}`);
    await page.screenshot({ path: path.join(SHOTS, `FALLO-${results.length}.png`) }).catch(() => {});
  }
};
const shot = (n) => page.screenshot({ path: path.join(SHOTS, `${n}.png`) });
const cards = () => page.locator('.card').count();

console.log('Arranque');
await step('el splash aparece y avanza', async () => {
  await page.goto(BASE, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('.splash.is-active', { timeout: 8000 });
  await page.waitForTimeout(700);
  await shot('01-splash');
  const joints = await page.locator('.boot__count').textContent();
  assert.match(joints, /^\d\d$/);
  const hasPixels = await page.evaluate(() => {
    const c = document.querySelector('.splash__canvas');
    const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
    let n = 0;
    for (let i = 3; i < d.length; i += 16) if (d[i] > 0) n++;
    return n;
  });
  assert.ok(hasPixels > 500, `el canvas del splash está vacío (${hasPixels})`);
});
await step('el Hub se muestra tras el arranque', async () => {
  await page.waitForSelector('.hub.is-active', { timeout: 30000 });
  await page.waitForTimeout(500);
  await shot('02-hub-vacio');
  assert.equal(await page.locator('.empty').isVisible(), true);
  assert.equal(await cards(), 0);
  const persistent = await page.evaluate(() => window.rigworld.store.persistent);
  assert.equal(persistent, true, 'IndexedDB debe estar activo');
});
await step('el importador usa un Worker', async () => {
  const state = await page.evaluate(async () => (await import('/js/import/client.js')).workerState());
  assert.equal(state.broken, false);
  assert.equal(state.active, true);
});

console.log('Importación');
await step('maniquí de ejemplo: cola → guardado → biblioteca con miniatura', async () => {
  await page.getByRole('button', { name: 'Probar con el maniquí' }).click();
  await page.waitForSelector('.task--done', { timeout: 30000 });
  await page.waitForFunction(() => document.querySelectorAll('.card').length === 1);
  await shot('03-hub-maniqui');
  const px = await page.evaluate(async () => {
    const img = document.querySelector('.card__thumb img');
    await img.decode();
    const c = document.createElement('canvas');
    c.width = img.naturalWidth; c.height = img.naturalHeight;
    const ctx = c.getContext('2d');
    ctx.drawImage(img, 0, 0);
    const d = ctx.getImageData(0, 0, c.width, c.height).data;
    let n = 0;
    for (let i = 3; i < d.length; i += 4) if (d[i] > 20) n++;
    return { w: img.naturalWidth, n, total: d.length / 4 };
  });
  assert.ok(px.w >= 200, `miniatura de ${px.w}px`);
  assert.ok(px.n / px.total > 0.04 && px.n / px.total < 0.9, `la miniatura no parece un modelo (${(100 * px.n / px.total).toFixed(1)} % opaco)`);
});
await step('varios archivos a la vez: STL, OBJ+MTL, y rechazos con motivo', async () => {
  await page.setInputFiles('#file-input', [files.stl, files.obj, files.mtl, files.bad, files.empty, files.fakeGlb, files.truncGlb]);
  await page.waitForFunction(() => document.querySelectorAll('.task--done').length >= 3, null, { timeout: 30000 });
  await page.waitForFunction(() => document.querySelectorAll('.task--error').length >= 1, null, { timeout: 30000 });
  await shot('04-cola-mixta');
  const rejected = await page.locator('.rejected__item').allTextContents();
  assert.ok(rejected.some((t) => /cosa\.xyz/.test(t) && /no compatible/i.test(t)), `falta el rechazo de cosa.xyz: ${rejected.join(' | ')}`);
  assert.ok(rejected.some((t) => /vacio\.glb/.test(t) && /vacío/.test(t)), 'falta el rechazo del archivo vacío');
  assert.ok(rejected.some((t) => /roto\.glb/.test(t) && /cabecera glTF válida/.test(t)), 'falta el rechazo del GLB sin firma');
  const err = await page.locator('.task--error .task__error').first().textContent();
  assert.match(err, /truncado|dañado/i, `mensaje de error poco claro: ${err}`);
  assert.equal(await page.locator('.task--error').getByRole('button', { name: 'Reintentar' }).count(), 1, 'el error ofrece reintentar');
  assert.equal(await cards(), 3, 'maniquí + cubo STL + cubo OBJ');
  const mtl = await page.evaluate(async () => {
    const m = (await window.rigworld.store.listModels()).find((x) => x.format === 'obj');
    return { files: m.files.map((f) => `${f.role}:${f.name}`), mat: m.stats.materials };
  });
  assert.deepEqual(mtl.files, ['main:cubo.obj', 'material:cubo.mtl']);
});
await step('modelo de 200 000 triángulos: se simplifica la vista previa y se avisa', async () => {
  await page.setInputFiles('#file-input', [files.sphere]);
  await page.waitForFunction(() => [...document.querySelectorAll('.task')].some((t) => /esfera/.test(t.textContent) && t.classList.contains('task--done')), null, { timeout: 60000 });
  const info = await page.evaluate(async () => {
    const m = (await window.rigworld.store.listModels()).find((x) => x.name === 'esfera-grande');
    return { tris: m.stats.triangles, simplified: m.stats.simplified, preview: m.stats.previewTriangles, tier: window.rigworld.profile.tier };
  });
  assert.equal(info.tris, 200000);
  assert.equal(info.simplified, true);
  assert.ok(info.preview > 50000 && info.preview <= 230000, `previa: ${info.preview}`);
  const warn = await page.locator('.task--done', { hasText: 'esfera' }).locator('.task__warn summary').textContent();
  assert.match(warn, /aviso/);
});

console.log('Persistencia');
await step('los modelos sobreviven a recargar la página', async () => {
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForSelector('.hub.is-active', { timeout: 30000 });
  await page.waitForFunction(() => document.querySelectorAll('.card').length === 4);
  const names = await page.locator('.card__name').allTextContents();
  assert.ok(names.includes('Maniquí de ejemplo') && names.includes('cubo') && names.includes('esfera-grande'), names.join(','));
  await shot('05-hub-recargado');
});
await step('integridad: lo guardado es idéntico al original (byte a byte)', async () => {
  await page.setInputFiles('#file-input', [files.stl]); // re-importa el cubo para comparar
  await page.waitForFunction(() => document.querySelectorAll('.card').length === 5, null, { timeout: 30000 });
  const original = fs.readFileSync(files.stl);
  const got = await page.evaluate(async () => {
    const list = await window.rigworld.store.listModels();
    const m = list.find((x) => x.format === 'stl' && x.name === 'cubo');
    const buf = new Uint8Array(await window.rigworld.store.getFileBuffer(m.id, 0));
    let h = 2166136261;
    for (const b of buf) { h ^= b; h = Math.imul(h, 16777619) >>> 0; }
    return { len: buf.length, hash: h };
  });
  let h = 2166136261;
  for (const b of original) { h ^= b; h = Math.imul(h, 16777619) >>> 0; }
  assert.equal(got.len, original.length);
  assert.equal(got.hash, h);
});
await step('fragmentos de 10 MB: un archivo de 25 MB se guarda en 3 piezas y se reensambla igual', async () => {
  const r = await page.evaluate(async () => {
    const { LIMITS } = await import('/js/config.js');
    const store = window.rigworld.store;
    const size = 25 * 1024 * 1024;
    const data = new Uint8Array(size);
    for (let i = 0; i < size; i += 4096) data[i] = (i / 4096) & 255;
    data[size - 1] = 7;
    const rec = await store.saveModel({ name: 'trozos', format: 'stl', files: [{ name: 'g.bin', role: 'main', data: new Blob([data]) }], stats: {} });
    const back = new Uint8Array(await store.getFileBuffer(rec.id, 0));
    let same = back.length === size;
    for (let i = 0; same && i < size; i += 4096) if (back[i] !== data[i]) same = false;
    if (back[size - 1] !== 7) same = false;
    const db = await new Promise((res, rej) => { const q = indexedDB.open('rigworld3d'); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); });
    const keys = await new Promise((res) => { const q = db.transaction('chunks').objectStore('chunks').getAllKeys(IDBKeyRange.bound(`${rec.id}:`, `${rec.id}:￿`)); q.onsuccess = () => res(q.result); });
    db.close();
    await store.deleteModel(rec.id);
    const db2 = await new Promise((res) => { const q = indexedDB.open('rigworld3d'); q.onsuccess = () => res(q.result); });
    const left = await new Promise((res) => { const q = db2.transaction('chunks').objectStore('chunks').getAllKeys(IDBKeyRange.bound(`${rec.id}:`, `${rec.id}:￿`)); q.onsuccess = () => res(q.result.length); });
    db2.close();
    return { chunkBytes: LIMITS.chunkBytes, chunks: keys.length, meta: rec.files[0].chunks, same, left };
  });
  assert.equal(r.chunkBytes, 10 * 1024 * 1024);
  assert.equal(r.chunks, 3);
  assert.equal(r.meta, 3);
  assert.equal(r.same, true);
  assert.equal(r.left, 0, 'al borrar no deben quedar fragmentos');
});
await step('una importación interrumpida deja huérfanos y repairOrphans() los limpia', async () => {
  const r = await page.evaluate(async () => {
    const store = window.rigworld.store;
    const db = await new Promise((res) => { const q = indexedDB.open('rigworld3d'); q.onsuccess = () => res(q.result); });
    await new Promise((res) => { const tx = db.transaction('chunks', 'readwrite'); tx.objectStore('chunks').put(new ArrayBuffer(64), 'fantasma:0:000000'); tx.oncomplete = res; });
    db.close();
    const removed = await store.repairOrphans();
    const after = await store.repairOrphans();
    return { removed, after };
  });
  assert.equal(r.removed, 1);
  assert.equal(r.after, 0);
});

console.log('Detalle, ajustes y navegación');
await step('detalle: estadísticas, activar, renombrar y botón Atrás de Android', async () => {
  await page.locator('.card', { hasText: 'Maniquí de ejemplo' }).click();
  await page.waitForSelector('.sheet-wrap.is-open .stats');
  await page.waitForTimeout(900);
  await shot('06-detalle');
  const stats = await page.locator('.sheet .stats').textContent();
  assert.match(stats, /Triángulos/);
  assert.match(stats, /No \(estático\)/);
  const tri = await page.locator('.stats__row', { hasText: 'Triángulos' }).locator('dd').textContent();
  assert.match(tri.replace(/\s/g, ''), /^\d[\d.,]*$/);

  await page.getByRole('button', { name: /Usar como modelo activo/ }).click();
  await page.getByRole('button', { name: 'Renombrar' }).click();
  await page.locator('#prompt-input').fill('Maniquí A');
  await page.locator('.dialog button[type=submit]').click();
  await page.waitForFunction(() => document.querySelector('.sheet__title')?.textContent === 'Maniquí A' || [...document.querySelectorAll('.sheet__title')].some((e) => e.textContent === 'Maniquí A'));

  // Botón Atrás: cierra la hoja de detalle, no la app
  await page.goBack();
  await page.waitForFunction(() => !document.querySelector('.sheet-wrap.is-open'));
  assert.ok(page.url().startsWith(BASE), 'seguimos en la app');
  await page.waitForFunction(() => document.querySelector('.card.is-active .card__name')?.textContent === 'Maniquí A');
  assert.equal(await page.locator('.activebar').isVisible(), true);
});
await step('ajustes: presupuesto de triángulos y reducción de movimiento se guardan', async () => {
  await page.getByRole('button', { name: 'Ajustes' }).click();
  await page.waitForSelector('#set-tris');
  await page.locator('#set-tris').evaluate((el) => { el.value = '50000'; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); });
  await page.locator('#set-reduce').check();
  await page.waitForTimeout(300);
  await shot('07-ajustes');
  const s = await page.evaluate(async () => window.rigworld.store.getSetting('view'));
  assert.equal(s.budgetTris, 50000);
  assert.equal(s.reducedMotion, true);
  await page.keyboard.press('Escape');
  await page.waitForFunction(() => !document.querySelector('.sheet-wrap.is-open'));
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForSelector('.hub.is-active', { timeout: 30000 });
  const after = await page.evaluate(() => ({ b: window.rigworld.settings.get('budgetTris'), r: document.documentElement.classList.contains('reduce-motion') }));
  assert.equal(after.b, 50000);
  assert.equal(after.r, true);
  await page.evaluate(() => window.rigworld.settings.update({ budgetTris: 200000, reducedMotion: false }));
});
console.log('Texturas, vista completa y miniaturas');
const THREE_URL = 'https://cdn.jsdelivr.net/npm/three@0.186.1/build/three.module.js';
let page2 = null;
const shot2 = (n) => page2.screenshot({ path: path.join(SHOTS, `${n}.png`) });
await step('GLB con textura: la vista previa simplificada conserva imagen, UV y material', async () => {
  await page.evaluate(() => window.rigworld.settings.update({ budgetTris: 30000 }));
  await page.setInputFiles('#file-input', [files.texGlb]);
  await page.waitForFunction(() => [...document.querySelectorAll('.task')].some((t) => /texturizado/.test(t.textContent) && t.classList.contains('task--done')), null, { timeout: 90000 });
  const info = await page.evaluate(async () => {
    const { loadPreviewFor } = await import('/js/import/importer.js');
    const m = (await window.rigworld.store.listModels()).find((x) => x.name === 'texturizado');
    const { preview } = await loadPreviewFor(window.rigworld.store, m);
    const used = new Set(preview.meshes.map((x) => x.material));
    return {
      textures: m.stats.textures, simplified: m.stats.simplified, tris: m.stats.triangles, previewTris: m.stats.previewTriangles, thumbVersion: m.thumbVersion,
      images: preview.images.length, mime: preview.images[0]?.mime, imageBytes: preview.images[0]?.data?.byteLength,
      mapOk: [...used].every((i) => preview.materials[i].map === 0),
      uvOk: preview.meshes.every((x) => x.uvs && x.uvs.length / 2 === x.positions.length / 3),
    };
  });
  assert.equal(info.tris, 240000);
  assert.equal(info.textures, 1);
  assert.equal(info.simplified, true);
  assert.ok(info.previewTris > 15000 && info.previewTris <= 30000 * 1.15, `previa: ${info.previewTris}`);
  assert.equal(info.images, 1, 'la imagen sigue en la vista previa simplificada');
  assert.equal(info.mime, 'image/png');
  assert.ok(info.imageBytes > 100);
  assert.equal(info.mapOk, true, 'el material conserva su textura');
  assert.equal(info.uvOk, true, 'las mallas simplificadas conservan UV');
  assert.equal(info.thumbVersion, 2, 'las miniaturas nuevas llevan la versión 2');
});
await step('Three simulado: las miniaturas antiguas se regeneran sin reimportar ni reordenar la biblioteca', async () => {
  const fakeSrc = fs.readFileSync(path.join(ROOT, 'test/fakeThree.mjs'), 'utf8');
  await ctx.route(THREE_URL, (route) => route.fulfill({ status: 200, contentType: 'text/javascript', headers: { 'access-control-allow-origin': '*' }, body: fakeSrc }));
  // Simula una miniatura creada con la versión anterior (sin textura).
  const before = await page.evaluate(async () => {
    const s = window.rigworld.store;
    const m = (await s.listModels()).find((x) => x.name === 'texturizado');
    await s.updateModel(m.id, { thumbVersion: 1, thumbMode: '2d' }, { touch: false });
    const rec = await s.getModel(m.id);
    return { id: m.id, updatedAt: rec.updatedAt, stamp: rec.thumbStamp, order: (await s.listModels()).map((x) => x.name) };
  });
  page2 = await ctx.newPage();
  page2.on('console', (m) => { if (m.type() === 'error' && !ignorable(m.text())) problems.push(`console(2): ${m.text()}`); });
  page2.on('pageerror', (e) => { if (!ignorable(e.message)) problems.push(`pageerror(2): ${e.message}`); });
  await page2.goto(BASE, { waitUntil: 'domcontentloaded' });
  await page2.waitForSelector('.hub.is-active', { timeout: 30000 });
  await page2.waitForFunction(() => document.querySelectorAll('.card').length >= 4);
  assert.equal(await page2.locator('.note--action').isVisible(), true, 'debe ofrecer actualizar las miniaturas');
  assert.match(await page2.locator('.note--action').textContent(), /Una miniatura se creó sin textura/);
  await shot2('10-hub-miniaturas');
  await page2.getByRole('button', { name: 'Actualizar' }).click();
  await page2.waitForFunction(() => document.querySelector('#toasts')?.textContent.includes('Miniatura actualizada'), null, { timeout: 60000 });
  await page2.waitForFunction(() => document.querySelector('.note--action')?.closest('.notes').hidden === true);
  const after = await page2.evaluate(async (id) => {
    const s = window.rigworld.store;
    const rec = await s.getModel(id);
    return { updatedAt: rec.updatedAt, stamp: rec.thumbStamp, version: rec.thumbVersion, mode: rec.thumbMode, thumbBytes: rec.thumb?.data?.byteLength, order: (await s.listModels()).map((x) => x.name), fake: { thumbScenes: __fake.thumbScenes, renderers: __fake.renderers } };
  }, before.id);
  assert.equal(after.version, 2);
  assert.equal(after.mode, 'webgl');
  assert.ok(after.thumbBytes > 50, 'la miniatura nueva tiene contenido');
  assert.ok(after.stamp > before.stamp, 'la miniatura cambió');
  assert.equal(after.updatedAt, before.updatedAt, 'actualizar la miniatura no mueve el modelo en la biblioteca');
  assert.deepEqual(after.order, before.order, 'el orden de la biblioteca no cambia');
  assert.ok(after.fake.thumbScenes >= 1 && after.fake.renderers >= 1, 'se dibujó con el motor 3D');
});
await step('visor (Three simulado): Vista completa alterna simplificada y completa, ambas con textura', async () => {
  await page2.locator('.card', { hasText: 'texturizado' }).click();
  await page2.waitForSelector('.sheet-wrap.is-open .viewer-tools:not([hidden])', { timeout: 90000 });
  const fake = () => page2.evaluate(() => ({ tris: __fake.viewerTris, mapped: __fake.viewerMapped, renders: __fake.renders, scenes: __fake.viewerScenes }));
  let f = await fake();
  assert.ok(f.tris > 15000 && f.tris <= 30000 * 1.15, `triángulos en el visor: ${f.tris}`);
  assert.equal(f.mapped, true, 'la vista simplificada se dibuja con textura');
  const toolbar = page2.locator('.viewer-tools');
  assert.match(await toolbar.textContent(), /Vista completa/);
  await page2.getByRole('button', { name: 'Vista completa' }).click();
  await page2.waitForFunction(() => /Vista simplificada/.test(document.querySelector('.viewer-tools')?.textContent || ''), null, { timeout: 90000 });
  f = await fake();
  assert.equal(f.tris, 240000, 'la vista completa tiene toda la geometría');
  assert.equal(f.mapped, true, 'la vista completa se dibuja con textura');
  const notes = (await page2.locator('.sheet .note').allTextContents()).join(' | ');
  assert.match(notes, /Vista completa: 240[.\s]?000 triángulos/);
  assert.equal(await page2.locator('.sheet .note', { hasText: 'Vista previa simplificada' }).isVisible(), false, 'el aviso de simplificación se oculta en la vista completa');
  assert.equal(await page2.getByRole('button', { name: 'Vista simplificada' }).getAttribute('aria-pressed'), 'true');
  await shot2('09-vista-completa');
  await page2.getByRole('button', { name: 'Vista simplificada' }).click();
  await page2.waitForFunction(() => /Vista completa/.test(document.querySelector('.viewer-tools')?.textContent || ''), null, { timeout: 90000 }); // la etiqueta vuelve solo cuando terminó
  f = await fake();
  assert.ok(f.tris <= 30000 * 1.15, `vuelve a la simplificada: ${f.tris}`);
  assert.equal(f.mapped, true);
  assert.ok(f.renders > 0 && f.scenes >= 3, 'el visor dibujó cada cambio');
  assert.equal(await page2.locator('.sheet .note', { hasText: 'Vista completa:' }).count(), 0, 'el aviso de vista completa desaparece');
  assert.equal(await page2.locator('.sheet .note', { hasText: 'Vista previa simplificada' }).isVisible(), true, 'el aviso de simplificación vuelve');
  await page2.keyboard.press('Escape');
  await page2.waitForFunction(() => !document.querySelector('.sheet-wrap.is-open'));
});
await step('estudio de personaje (Three simulado): esqueleto automático, caminar, correr, saltar y guardado', async () => {
  const fake = () => page2.evaluate(() => ({ skinned: __fake.skinned, skinAttrOk: __fake.skinAttrOk, bones: __fake.bones, quats: __fake.boneQuatSets, rootY: __fake.lastRootY, rootYMax: __fake.rootYMax, overlay: __fake.overlayVisible, renders: __fake.renders }));
  await page2.locator('.card', { hasText: 'Maniquí A' }).click();
  await page2.waitForSelector('.sheet-wrap.is-open .stats');
  const open = page2.getByRole('button', { name: /Preparar personaje/ });
  assert.equal(await open.isEnabled(), true, 'el botón está disponible con WebGL');
  await open.click();
  await page2.waitForSelector('.studio:not([hidden])', { timeout: 90000 });
  await shot2('11-estudio');
  let f = await fake();
  assert.ok(f.skinned >= 1, 'se creó una malla con esqueleto');
  assert.equal(f.skinAttrOk, true, 'los atributos skinIndex y skinWeight cubren todos los vértices');
  assert.ok(f.bones >= 19 && f.bones % 19 === 0, `huesos creados: ${f.bones}`);
  assert.match(await page2.locator('.sheet').last().textContent(), /Esqueleto guardado en este dispositivo/);
  assert.equal(await page2.getByRole('button', { name: 'Quitar esqueleto guardado' }).isVisible(), true);
  const notes = (await page2.locator('.sheet .note').allTextContents()).join(' | ');
  assert.match(notes, /Calidad|calidad|Buena|Aceptable|Mejorable/i, `nota de calidad: ${notes}`);

  // La animación avanza sola: huesos y raíz cambian con el tiempo (en reposo respira, sin moverse del sitio).
  const q0 = f.quats;
  await page2.waitForTimeout(500);
  f = await fake();
  assert.ok(f.quats > q0 + 19, `la animación de reposo corre (${q0} → ${f.quats})`);
  const idleY = f.rootY;
  assert.ok(idleY > 0.3, `altura de caderas en reposo: ${idleY}`);

  // Caminar y correr: la velocidad mostrada sube y el botón queda marcado.
  const speed = async () => Number((await page2.locator('.studio__value').textContent()).replace(/[^\d.]/g, ''));
  await page2.getByRole('button', { name: 'Caminar', exact: true }).click();
  const kWalk = await speed();
  assert.equal(await page2.getByRole('button', { name: 'Caminar', exact: true }).getAttribute('aria-pressed'), 'true');
  await page2.getByRole('button', { name: 'Correr', exact: true }).click();
  const kRun = await speed();
  assert.equal(await page2.getByRole('button', { name: 'Correr', exact: true }).getAttribute('aria-pressed'), 'true');
  assert.equal(await page2.getByRole('button', { name: 'Caminar', exact: true }).getAttribute('aria-pressed'), 'false');
  assert.ok(kWalk > 3 && kWalk < 7, `caminar ≈ 5 km/h: ${kWalk}`);
  assert.ok(kRun > 9 && kRun < 20 && kRun > kWalk * 2, `correr ≈ 10–16 km/h (carrera, no trote): ${kRun}`);
  await page2.waitForTimeout(600);
  const q1 = (await fake()).quats;
  await page2.waitForTimeout(400);
  assert.ok((await fake()).quats > q1 + 19, 'corriendo, los huesos siguen actualizándose');
  await shot2('12-estudio-correr');

  // El deslizador manda sobre los botones: al moverlo se desmarcan.
  await page2.locator('#rig-speed').evaluate((el) => { el.value = '30'; el.dispatchEvent(new Event('input', { bubbles: true })); });
  assert.equal(await page2.getByRole('button', { name: 'Correr', exact: true }).getAttribute('aria-pressed'), 'false');
  assert.ok((await speed()) > 3);
  await page2.getByRole('button', { name: 'Quieto', exact: true }).click();
  assert.equal(await speed(), 0);

  // Saltar: las caderas suben claramente por encima de su altura en reposo y vuelven.
  await page2.waitForTimeout(500);
  const base = (await fake()).rootY;
  await page2.evaluate(() => { __fake.rootYMax = -Infinity; });
  await page2.getByRole('button', { name: 'Saltar', exact: true }).click();
  // El reloj de la animación avanza con los fotogramas reales (en un navegador sin GPU pueden ser pocos): se espera a que termine.
  await page2.waitForFunction(([b]) => __fake.rootYMax > b * 1.08, [base], { timeout: 15000 });
  await page2.waitForFunction(([b]) => Math.abs(__fake.lastRootY - b) < b * 0.08, [base], { timeout: 15000 });
  f = await fake();
  assert.ok(f.rootYMax > base * 1.08, `el salto levanta las caderas: ${base.toFixed(3)} → ${f.rootYMax.toFixed(3)}`);
  await page2.getByRole('button', { name: 'Saludar', exact: true }).click();
  await page2.waitForTimeout(400);

  // Esqueleto y malla: los interruptores se marcan y la superposición aparece.
  const bonesBtn = page2.getByRole('button', { name: 'Esqueleto', exact: true });
  await bonesBtn.click();
  assert.equal(await bonesBtn.getAttribute('aria-pressed'), 'true');
  assert.equal((await fake()).overlay, true, 'se muestra el esqueleto');
  await shot2('13-estudio-esqueleto');
  await bonesBtn.click();
  assert.equal((await fake()).overlay, false, 'se oculta el esqueleto');

  // Girar 90°: recalcula y deja el personaje animado de nuevo, guardando el nuevo ajuste.
  const skinnedBefore = (await fake()).skinned;
  const yaw0 = await page2.evaluate(async (name) => (await window.rigworld.store.getRig((await window.rigworld.store.listModels()).find((x) => x.name === name).id)).options.yawOffset, 'Maniquí A');
  await page2.getByRole('button', { name: 'Girar 90°' }).click();
  await page2.waitForFunction((n) => __fake.skinned > n, skinnedBefore, { timeout: 60000 });
  await page2.waitForFunction(() => !document.querySelector('.viewer-status:not([hidden])'), null, { timeout: 30000 });
  await page2.waitForFunction(() => document.querySelector('.studio button[disabled]') === null);
  const yaw1 = await page2.evaluate(async (name) => (await window.rigworld.store.getRig((await window.rigworld.store.listModels()).find((x) => x.name === name).id)).options.yawOffset, 'Maniquí A');
  assert.ok(Math.abs(yaw1 - yaw0 - Math.PI / 2) < 1e-6, `el giro se guarda: ${yaw0} → ${yaw1}`);
  const q2 = (await fake()).quats;
  await page2.waitForTimeout(400);
  assert.ok((await fake()).quats > q2, 'tras girar, el personaje sigue animado');
  await page2.getByRole('button', { name: 'Reajustar' }).click();
  await page2.waitForFunction(async (name) => {
    const s = window.rigworld.store;
    const r = await s.getRig((await s.listModels()).find((x) => x.name === name).id);
    return r && Math.abs(r.options.yawOffset) < 1e-6;
  }, 'Maniquí A', { timeout: 60000 });
  await page2.waitForFunction(() => document.querySelector('.studio button[disabled]') === null);

  // Datos guardados: solo el registro del rig (unos KB), nunca pesos ni mallas.
  const saved = await page2.evaluate(async (name) => {
    const s = window.rigworld.store;
    const m = (await s.listModels()).find((x) => x.name === name);
    const rig = await s.getRig(m.id);
    return { summary: m.rig, keys: Object.keys(rig).sort(), size: JSON.stringify(rig).length, hasWeights: 'weights' in rig, updatedAt: m.updatedAt, order: (await s.listModels()).map((x) => x.name) };
  }, 'Maniquí A');
  assert.ok(saved.summary && saved.summary.poseType, `resumen en el modelo: ${JSON.stringify(saved.summary)}`);
  assert.equal(saved.hasWeights, false, 'los pesos no se guardan: se recalculan al abrir');
  assert.ok(saved.size < 20000, `el registro del rig es pequeño: ${saved.size} bytes`);
  assert.ok(saved.keys.includes('rig') && saved.keys.includes('version'));

  // Cerrar y volver al Hub: la tarjeta muestra la insignia y el modelo no cambia de sitio.
  await page2.keyboard.press('Escape');
  await page2.waitForFunction(() => !document.querySelector('.studio'));
  await page2.waitForFunction(() => /Abrir personaje/.test(document.querySelector('.sheet-wrap.is-open')?.textContent || ''), null, { timeout: 10000 });
  await page2.keyboard.press('Escape');
  await page2.waitForFunction(() => !document.querySelector('.sheet-wrap.is-open'));
  await page2.waitForFunction(() => document.querySelectorAll('.card__rig').length >= 1);
  const badge = page2.locator('.card', { hasText: 'Maniquí A' }).locator('.card__rig');
  assert.equal(await badge.count(), 1, 'la tarjeta indica que el personaje tiene esqueleto');
  assert.match((await page2.locator('.card', { hasText: 'Maniquí A' }).getAttribute('aria-label')) || '', /esqueleto/i);
  const after = await page2.evaluate(async () => (await window.rigworld.store.listModels()).map((x) => x.name));
  assert.deepEqual(after, saved.order, 'guardar el rig no reordena la biblioteca');
  await shot2('14-hub-con-esqueleto');
});
await step('estudio de personaje: al reabrir carga el esqueleto guardado y se puede quitar', async () => {
  const fake = () => page2.evaluate(() => ({ skinned: __fake.skinned, quats: __fake.boneQuatSets }));
  const fits = await page2.evaluate(() => { window.__fitCalls = 0; return 0; });
  await page2.locator('.card', { hasText: 'Maniquí A' }).click();
  await page2.waitForSelector('.sheet-wrap.is-open .stats');
  await page2.getByRole('button', { name: /Abrir personaje/ }).click();
  await page2.waitForSelector('.studio:not([hidden])', { timeout: 90000 });
  assert.match(await page2.locator('.sheet').last().textContent(), /Esqueleto cargado del dispositivo/);
  const q0 = (await fake()).quats;
  await page2.waitForTimeout(400);
  assert.ok((await fake()).quats > q0, 'el personaje se anima desde el esqueleto guardado');
  await page2.getByRole('button', { name: 'Quitar esqueleto guardado' }).click();
  await page2.waitForFunction(() => /Esqueleto guardado eliminado/.test(document.body.textContent));
  const gone = await page2.evaluate(async () => {
    const s = window.rigworld.store;
    const m = (await s.listModels()).find((x) => x.name === 'Maniquí A');
    return { rig: await s.getRig(m.id), summary: m.rig ?? null };
  });
  assert.equal(gone.rig ?? null, null, 'el registro se borra');
  assert.equal(gone.summary, null, 'el resumen del modelo se borra');
  await page2.keyboard.press('Escape');
  await page2.waitForFunction(() => !document.querySelector('.studio'));
  await page2.waitForFunction(() => /Preparar personaje/.test(document.querySelector('.sheet-wrap.is-open')?.textContent || ''), null, { timeout: 10000 });
  await page2.keyboard.press('Escape');
  await page2.waitForFunction(() => !document.querySelector('.sheet-wrap.is-open'));
  await page2.waitForFunction(() => document.querySelectorAll('.card__rig').length === 0);
});
await step('animaciones de otros personajes (FBX simulado): se cargan, adaptan, reproducen, guardan y quitan', async () => {
  // Esqueleto estilo Mixamo con una marcha, generado en Node y entregado al navegador como JSON.
  const fx = await import('./retargetFixtures.mjs');
  const { makeHumanoid } = await import('./synth.mjs');
  const { fitRigRecord } = await import('../js/rig/service.js');
  const srcRig = fitRigRecord(makeHumanoid({ step: 0.03 }).meshes).rig;
  const src = fx.makeSource(srcRig, { scale: 1.1, yaw: Math.PI });
  const { poses } = fx.gaitPoses(srcRig, { speedName: 'walk', seconds: 2 });
  const json = fx.sceneJSON(src, fx.clipFromPoses(srcRig, src, poses));
  await page2.evaluate((j) => { window.__sceneJSON = j; }, json);
  // Cargador FBX simulado: reconstruye objetos con la forma de Object3D / AnimationClip a partir del JSON.
  const fakeFbx = `
    export class FBXLoader {
      constructor() {}
      parse() {
        const j = globalThis.__sceneJSON;
        const objs = j.nodes.map((n) => ({ name: n.name, children: [], isBone: n.isBone, position: { x: n.position[0], y: n.position[1], z: n.position[2] }, quaternion: { x: n.quaternion[0], y: n.quaternion[1], z: n.quaternion[2], w: n.quaternion[3] }, scale: { x: n.scale[0], y: n.scale[1], z: n.scale[2] } }));
        j.nodes.forEach((n, i) => n.parent >= 0 && objs[n.parent].children.push(objs[i]));
        const root = { name: 'Group', children: [objs[0], { name: 'Body', isSkinnedMesh: true, isMesh: true, children: [] }], position: { x: 0, y: 0, z: 0 }, quaternion: { x: 0, y: 0, z: 0, w: 1 }, scale: { x: 1, y: 1, z: 1 } };
        root.animations = j.animations.map((a) => ({ name: a.name, duration: a.duration, tracks: a.tracks.map((t) => ({ name: t.name, times: Float32Array.from(t.times), values: Float32Array.from(t.values) })) }));
        return root;
      }
    }`;
  await ctx.route(/three@0\.186\.1\/examples\/jsm\/loaders\/FBXLoader\.js$/, (route) => route.fulfill({ status: 200, contentType: 'text/javascript', headers: { 'access-control-allow-origin': '*' }, body: fakeFbx }));

  const fake = () => page2.evaluate(() => ({ quats: __fake.boneQuatSets, rootY: __fake.lastRootY }));
  const idOf = () => page2.evaluate(async () => (await window.rigworld.store.listModels()).find((x) => x.name === 'Maniquí A').id);
  const savedClips = async () => page2.evaluate(async (id) => { const r = await window.rigworld.store.getRig(id); return (r?.clips || []).map((c) => ({ label: c.label, frames: c.frames, loop: c.loop, finite: Array.from(c.quats.slice(0, 200)).every(Number.isFinite), bytes: c.quats.byteLength + c.root.byteLength })); }, await idOf());
  const openStudio = async () => {
    await page2.locator('.card', { hasText: 'Maniquí A' }).click();
    await page2.waitForSelector('.sheet-wrap.is-open .stats');
    await page2.getByRole('button', { name: /Preparar personaje|Abrir personaje/ }).click();
    await page2.waitForSelector('.studio:not([hidden])', { timeout: 90000 });
  };
  const closeStudio = async () => {
    await page2.keyboard.press('Escape');
    await page2.waitForFunction(() => !document.querySelector('.studio'));
    await page2.keyboard.press('Escape');
    await page2.waitForFunction(() => !document.querySelector('.sheet-wrap.is-open'));
  };
  const clipBtn = (name) => page2.locator('[aria-label="Animaciones importadas"]').getByRole('button', { name });

  await openStudio();
  assert.equal(await page2.getByRole('button', { name: 'Cargar animación (FBX/GLB)' }).isVisible(), true);
  assert.equal(await page2.locator('[aria-label="Animaciones importadas"]').isVisible(), false, 'sin animaciones, no hay lista');

  // Rechazos con motivo: formato no admitido y archivo sin animaciones.
  await page2.setInputFiles('.studio input[type=file]', { name: 'malla.obj', mimeType: 'text/plain', buffer: Buffer.from('v 0 0 0') });
  await page2.waitForFunction(() => /FBX, GLB/.test(document.querySelector('#toasts')?.textContent || ''), null, { timeout: 15000 });
  await page2.evaluate(() => { window.__sceneJSON = { ...window.__sceneJSON, animations: [] }; });
  await page2.setInputFiles('.studio input[type=file]', { name: 'sin-animacion.fbx', mimeType: 'application/octet-stream', buffer: Buffer.from('FBX') });
  await page2.waitForFunction(() => /no contiene animaciones/.test(document.querySelector('#toasts')?.textContent || ''), null, { timeout: 15000 });
  assert.equal((await savedClips()).length, 0);
  await page2.evaluate((j) => { window.__sceneJSON = j; }, json);

  // Carga correcta: se adapta, se guarda y empieza a reproducirse.
  await page2.setInputFiles('.studio input[type=file]', { name: 'caminar-mixamo.fbx', mimeType: 'application/octet-stream', buffer: Buffer.from('FBX') });
  await page2.waitForFunction(() => /Animación lista/.test(document.querySelector('.studio [role=status]')?.textContent || ''), null, { timeout: 30000 });
  assert.equal(await clipBtn('caminar-mixamo').getAttribute('aria-pressed'), 'true', 'empieza a reproducirse sola');
  assert.equal(await page2.getByRole('button', { name: 'Quieto', exact: true }).getAttribute('aria-pressed'), 'false');
  let c0 = await fake();
  await page2.waitForTimeout(500);
  let c1 = await fake();
  assert.ok(c1.quats > c0.quats + 19, 'la animación importada mueve los huesos');
  await shot2('15-estudio-animacion');
  const saved = await savedClips();
  assert.equal(saved.length, 1);
  assert.equal(saved[0].label, 'caminar-mixamo');
  assert.ok(saved[0].frames >= 30 && saved[0].finite, `clip guardado: ${JSON.stringify(saved[0])}`);
  assert.ok(saved[0].bytes < 200000, `tamaño del clip: ${saved[0].bytes} bytes`);

  // Alternar con el movimiento procedural: Correr detiene la animación importada; el botón la retoma; pulsarla de nuevo vuelve al reposo.
  await page2.getByRole('button', { name: 'Correr', exact: true }).click();
  assert.equal(await clipBtn('caminar-mixamo').getAttribute('aria-pressed'), 'false');
  await clipBtn('caminar-mixamo').click();
  assert.equal(await clipBtn('caminar-mixamo').getAttribute('aria-pressed'), 'true');
  assert.equal(await page2.getByRole('button', { name: 'Correr', exact: true }).getAttribute('aria-pressed'), 'false');
  await page2.getByRole('button', { name: 'Saltar', exact: true }).click();
  assert.equal(await clipBtn('caminar-mixamo').getAttribute('aria-pressed'), 'false', 'Saltar toma el control');
  await clipBtn('caminar-mixamo').click();
  await clipBtn('caminar-mixamo').click();
  assert.equal(await page2.getByRole('button', { name: 'Quieto', exact: true }).getAttribute('aria-pressed'), 'true', 'vuelve al reposo');
  assert.equal(await clipBtn('caminar-mixamo').getAttribute('aria-pressed'), 'false');

  // Persistencia: al cerrar y reabrir, la animación sigue ahí; se puede añadir otra y quitar todas.
  await closeStudio();
  await openStudio();
  assert.equal(await clipBtn('caminar-mixamo').count(), 1, 'la animación se conserva al reabrir');
  await clipBtn('caminar-mixamo').click();
  c0 = await fake();
  await page2.waitForTimeout(400);
  c1 = await fake();
  assert.ok(c1.quats > c0.quats + 19, 'reproduce desde lo guardado');
  await page2.setInputFiles('.studio input[type=file]', { name: 'otra.fbx', mimeType: 'application/octet-stream', buffer: Buffer.from('FBX') });
  await page2.waitForFunction(() => document.querySelectorAll('[aria-label="Animaciones importadas"] button').length === 2, null, { timeout: 30000 });
  assert.equal((await savedClips()).length, 2);
  await page2.getByRole('button', { name: 'Quitar animaciones importadas' }).click();
  await page2.waitForFunction(() => document.querySelector('[aria-label="Animaciones importadas"]')?.hidden === true);
  assert.equal((await savedClips()).length, 0);
  assert.equal(await page2.getByRole('button', { name: 'Quieto', exact: true }).getAttribute('aria-pressed'), 'true');

  // Girar 90° invalida las animaciones ya adaptadas y avisa.
  await page2.setInputFiles('.studio input[type=file]', { name: 'caminar-mixamo.fbx', mimeType: 'application/octet-stream', buffer: Buffer.from('FBX') });
  await page2.waitForFunction(() => document.querySelectorAll('[aria-label="Animaciones importadas"] button').length === 1, null, { timeout: 30000 });
  const sk = await page2.evaluate(() => __fake.skinned);
  await page2.getByRole('button', { name: 'Girar 90°' }).click();
  await page2.waitForFunction((n) => __fake.skinned > n, sk, { timeout: 60000 });
  await page2.waitForFunction(() => /Se quitaron las animaciones importadas/.test(document.querySelector('#toasts')?.textContent || ''), null, { timeout: 30000 });
  assert.equal((await savedClips()).length, 0);
  await page2.getByRole('button', { name: 'Reajustar' }).click();
  await page2.waitForFunction(() => document.querySelector('.studio button[disabled]') === null, null, { timeout: 60000 });
  await closeStudio();
  // Deja el modelo como estaba para el paso siguiente (sin esqueleto guardado).
  await openStudio();
  await page2.getByRole('button', { name: 'Quitar esqueleto guardado' }).click();
  await page2.waitForFunction(() => /Esqueleto guardado eliminado/.test(document.body.textContent));
  await closeStudio();
});
await step('base de datos: una biblioteca de la Fase 1 (versión 1) se actualiza sin perder nada', async () => {
  const r = await page2.evaluate(async () => {
    const NAME = 'rigworld-upgrade-test';
    await new Promise((res) => { const d = indexedDB.deleteDatabase(NAME); d.onsuccess = d.onerror = d.onblocked = () => res(); });
    // Base de la Fase 1: solo models, chunks y settings, versión 1.
    const v1 = await new Promise((res, rej) => {
      const q = indexedDB.open(NAME, 1);
      q.onupgradeneeded = () => {
        const db = q.result;
        db.createObjectStore('models', { keyPath: 'id' });
        db.createObjectStore('chunks');
        db.createObjectStore('settings');
      };
      q.onsuccess = () => res(q.result);
      q.onerror = () => rej(q.error);
    });
    await new Promise((res, rej) => {
      const tx = v1.transaction(['models', 'chunks', 'settings'], 'readwrite');
      tx.objectStore('models').put({ id: 'viejo-1', name: 'Modelo de la Fase 1', createdAt: 1, updatedAt: 2, files: [], stats: { triangles: 12 } });
      tx.objectStore('chunks').put(new ArrayBuffer(32), 'viejo-1:0:000000');
      tx.objectStore('settings').put({ keep: true }, 'view');
      tx.oncomplete = res;
      tx.onerror = () => rej(tx.error);
    });
    v1.close();
    const { openStore } = await import('/js/storage/db.js');
    const store = await openStore(NAME);
    const out = { persistent: store.persistent, version: null };
    const models = await store.listModels();
    out.models = models.map((m) => m.name);
    out.setting = await store.getSetting('view');
    out.rigBefore = (await store.getRig('viejo-1')) ?? null;
    await store.saveRig('viejo-1', { version: 1, rig: { height: 1.7 }, options: {} });
    out.rigAfter = (await store.getRig('viejo-1'))?.rig?.height;
    out.orphans = await store.repairOrphans();
    await store.deleteModel('viejo-1');
    out.rigDeleted = (await store.getRig('viejo-1')) ?? null;
    store.close?.();
    const raw = await new Promise((res) => { const q = indexedDB.open(NAME); q.onsuccess = () => { const v = q.result.version; const names = [...q.result.objectStoreNames].sort(); q.result.close(); res({ v, names }); }; });
    out.version = raw.v;
    out.stores = raw.names;
    await new Promise((res) => { const d = indexedDB.deleteDatabase(NAME); d.onsuccess = d.onerror = d.onblocked = () => res(); });
    return out;
  });
  assert.equal(r.persistent, true, 'se usa IndexedDB, no la memoria');
  assert.deepEqual(r.models, ['Modelo de la Fase 1'], 'el modelo antiguo sigue ahí');
  assert.deepEqual(r.setting, { keep: true }, 'los ajustes antiguos siguen ahí');
  assert.equal(r.rigBefore, null, 'sin esqueleto hasta que se prepara');
  assert.equal(r.rigAfter, 1.7, 'el almacén nuevo funciona');
  assert.equal(r.orphans, 0, 'el fragmento del modelo antiguo no se considera huérfano');
  assert.equal(r.rigDeleted, null, 'al borrar el modelo se borra su esqueleto');
  assert.equal(r.version, 2);
  assert.deepEqual(r.stores, ['chunks', 'models', 'rigs', 'settings']);
});
await step('un modelo sin simplificar no ofrece «Vista completa»', async () => {
  await page2.locator('.card', { hasText: 'cubo' }).first().click();
  await page2.waitForSelector('.sheet-wrap.is-open .viewer-tools:not([hidden])', { timeout: 60000 });
  assert.equal(await page2.locator('.sheet-wrap.is-open').getByRole('button', { name: 'Vista completa' }).count(), 0, 'el botón no se muestra');
  assert.equal(await page2.locator('.sheet-wrap.is-open').getByRole('button', { name: 'Encuadrar' }).count(), 1, 'el resto de controles sí');
  await page2.keyboard.press('Escape');
  await page2.waitForFunction(() => !document.querySelector('.sheet-wrap.is-open'));
  await page2.close();
  await page.evaluate(() => window.rigworld.settings.update({ budgetTris: 200000 }));
});
await step('eliminar con confirmación propia (sin confirm() del navegador) limpia modelo y datos', async () => {
  const before = await cards();
  await page.locator('.card', { hasText: 'cubo' }).first().click();
  await page.waitForSelector('.sheet-wrap.is-open');
  await page.getByRole('button', { name: 'Eliminar' }).click();
  await page.waitForSelector('.dialog .btn--danger');
  await page.locator('.dialog .btn--danger').click();
  await page.waitForFunction((n) => document.querySelectorAll('.card').length === n - 1, before);
  await page.waitForFunction(() => !document.querySelector('.sheet-wrap.is-open'));
  const orphans = await page.evaluate(async () => window.rigworld.store.repairOrphans());
  assert.equal(orphans, 0, 'no deben quedar fragmentos sueltos tras eliminar');
});
await step('tema claro: el Hub se ve legible', async () => {
  await page.emulateMedia({ colorScheme: 'light' });
  await page.waitForTimeout(400);
  await shot('08-hub-claro');
  const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  assert.notEqual(bg, 'rgb(10, 27, 48)', 'el fondo no cambió al tema claro');
  await page.emulateMedia({ colorScheme: 'dark' });
});
await step('sin desbordamiento horizontal a 412 px ni a 320 px', async () => {
  for (const w of [412, 320]) {
    await page.setViewportSize({ width: w, height: 915 });
    await page.waitForTimeout(250);
    const over = await page.evaluate(() => {
      const bad = [];
      const vw = document.documentElement.clientWidth;
      for (const el of document.querySelectorAll('.hub *')) {
        const r = el.getBoundingClientRect();
        if (r.width > 0 && (r.right > vw + 1 || r.left < -1)) {
          const scroller = el.closest('.viewer-tools');
          if (!scroller) bad.push(`${el.className || el.tagName}:${Math.round(r.right)}`);
        }
      }
      return { bad: bad.slice(0, 6), sw: document.documentElement.scrollWidth, vw, iw: innerWidth, scrolled: [...document.querySelectorAll('*')].filter((e) => e.scrollLeft > 0).map((e) => `${e.id || e.className || e.tagName}:${e.scrollLeft}`), tf: [...document.querySelectorAll('.layer')].map((e) => `${e.dataset.layer}:${getComputedStyle(e).transform}`), sh: document.documentElement.scrollHeight, ch: document.documentElement.clientHeight };
    });
    assert.deepEqual(over.bad, [], `elementos fuera de pantalla a ${w}px · ${JSON.stringify(over)}`);
    assert.ok(over.sw <= over.vw, `scrollWidth ${over.sw} > ${over.vw}`);
    if (w === 320) await shot('09-hub-320');
  }
  await page.setViewportSize({ width: 412, height: 915 });
});
await step('sin errores de JavaScript inesperados', async () => {
  assert.deepEqual(problems, []);
});

await browser.close();
server.close();
fs.rmSync(TMP, { recursive: true, force: true });

const failed = results.filter((r) => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} pasos correctos. Capturas en ${SHOTS}`);
process.exit(failed.length ? 1 : 0);
