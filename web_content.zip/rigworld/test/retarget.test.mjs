// Pruebas del retargeting (Node). Ejecutar: node --test test/retarget.test.mjs
// Método: se toma una marcha real del animador sobre el rig, se «exporta» a un esqueleto de otro personaje
// (nombres de Mixamo o VRoid, huesos extra, otra escala, mirando a −Z, pose A…) y se vuelve a llevar al rig. Con
// las mismas proporciones el resultado debe ser idéntico al original; con otras, los pies deben seguir en el suelo.
import test from 'node:test';
import assert from 'node:assert/strict';

import { makeHumanoid } from './synth.mjs';
import * as fx from './retargetFixtures.mjs';
import { qMul, qConj, qRotY, qRotZ, qRotate, v3, DEG } from '../js/rig/mathq.js';
import { fitRigRecord } from '../js/rig/service.js';
import { poseJoints, IDX, BONE_COUNT, PARENTS, BONE_NAMES } from '../js/rig/skeleton.js';
import { createAnimator } from '../js/rig/animator.js';
import { canonicalBoneFor, mapSourceBones, createRetargeter, createClipPlayer, isClipValid } from '../js/rig/retarget.js';
import { sourceFromObject3D, clipsFromThree } from '../js/rig/sourceScene.js';

const rigRecord = fitRigRecord(makeHumanoid({ step: 0.03 }).meshes);
const rig = rigRecord.rig;
const H = rig.height;

// ── Nombres ───────────────────────────────────────────────────────────────────────────────────
test('los nombres de Mixamo, VRoid y variantes comunes se reconocen', () => {
  const cases = {
    'mixamorig:Hips': 'Hips', mixamorigHips: 'Hips', 'mixamorig:Spine': 'Spine', 'mixamorig:Spine1': 'Chest', 'mixamorig:Neck': 'Neck', 'mixamorig:Head': 'Head',
    'mixamorig:LeftShoulder': 'LeftShoulder', mixamorigLeftArm: 'LeftUpperArm', mixamorigLeftForeArm: 'LeftLowerArm', mixamorigLeftHand: 'LeftHand',
    'mixamorig:RightUpLeg': 'RightUpperLeg', 'mixamorig:RightLeg': 'RightLowerLeg', 'mixamorig:RightFoot': 'RightFoot',
    J_Bip_C_Hips: 'Hips', J_Bip_C_Spine: 'Spine', J_Bip_C_Chest: 'Chest', J_Bip_L_UpperArm: 'LeftUpperArm', J_Bip_R_LowerArm: 'RightLowerArm', J_Bip_L_UpperLeg: 'LeftUpperLeg', J_Bip_R_Foot: 'RightFoot',
    'upper_arm.L': 'LeftUpperArm', 'thigh.R': 'RightUpperLeg', 'shin.L': 'LeftLowerLeg', 'DEF-forearm.R': 'RightLowerArm', pelvis: 'Hips', Head: 'Head',
    'Armature|LeftHand': 'LeftHand',
  };
  for (const [name, bone] of Object.entries(cases)) {
    const hit = canonicalBoneFor(name);
    assert.ok(hit, `se debía reconocer «${name}»`);
    assert.equal(BONE_NAMES[hit.bone], bone, name);
  }
  for (const name of ['mixamorig:LeftToeBase', 'mixamorig:LeftHandIndex1', 'Armature', 'Body', 'Hair_01', 'J_Bip_L_ToeBase', 'Arm', 'mixamorig:LeftHandThumb2', '']) {
    assert.equal(canonicalBoneFor(name), null, `no debía reconocerse «${name}»`);
  }
});

test('con varias candidatas gana la mejor: Spine1 de Mixamo es el pecho, no Spine2', () => {
  const src = { bones: ['Armature', 'mixamorig:Hips', 'mixamorig:Spine', 'mixamorig:Spine1', 'mixamorig:Spine2', 'mixamorig:Neck'].map((name, i) => ({ name, parent: i - 1 })) };
  const map = mapSourceBones(src);
  assert.equal(map[IDX.Chest], 3);
  assert.equal(map[IDX.Spine], 2);
  const vroid = { bones: ['J_Bip_C_Hips', 'J_Bip_C_Spine', 'J_Bip_C_Chest', 'J_Bip_C_UpperChest'].map((name, i) => ({ name, parent: i - 1 })) };
  assert.equal(mapSourceBones(vroid)[IDX.Chest], 2);
});

// ── Construcción de un «otro personaje» a partir del rig (ver retargetFixtures.mjs) ───────────────
const makeSource = (o) => fx.makeSource(rig, o);
const clipFromPoses = (src, poses, fps, o) => fx.clipFromPoses(rig, src, poses, fps, o);
const gaitPoses = (o) => fx.gaitPoses(rig, o);

const angleBetween = (a, b) => {
  const d = Math.abs(a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3]);
  return 2 * Math.acos(Math.min(1, d)) / DEG;
};

function compare(baked, poses, { rootScale = 1 } = {}) {
  const player = createClipPlayer(baked);
  let maxAng = 0, maxJoint = 0, maxRoot = 0;
  poses.forEach((p, i) => {
    const t = (i / (poses.length - 1)) * baked.duration;
    const q = player.sample(t);
    for (let b = 0; b < BONE_COUNT; b++) maxAng = Math.max(maxAng, angleBetween(q.world[b], p.world[b]));
    const ja = poseJoints(rig, { root: [0, p.root[1] * rootScale, 0], world: p.world });
    const jb = poseJoints(rig, { root: [0, q.root[1], 0], world: q.world });
    for (let b = 0; b < BONE_COUNT; b++) maxJoint = Math.max(maxJoint, v3.dist(ja[b], jb[b]));
    maxRoot = Math.max(maxRoot, Math.abs(q.root[1] - p.root[1] * rootScale));
  });
  return { maxAng, maxJoint, maxRoot };
}

// ── Ida y vuelta ──────────────────────────────────────────────────────────────────────────────
for (const [label, opts] of [
  ['Mixamo en cm, mirando a +Z', { scale: 1, yaw: 0 }],
  ['Mixamo girado 180° (mira a −Z) y escala 1,3', { scale: 1.3, yaw: Math.PI }],
  ['VRoid girado 90° y escala 0,8', { scale: 0.8, yaw: Math.PI / 2, armScale: 1, style: 'vroid' }],
]) {
  test(`ida y vuelta: ${label} reproduce la marcha original`, () => {
    const src = makeSource(opts);
    const rt = createRetargeter(rig, src);
    assert.equal(rt.missingOptional.length, 0, `huesos sin equivalente: ${rt.missingOptional}`);
    assert.ok(Math.abs(rt.scale - 1 / opts.scale) < 1e-6, `proporción de piernas ${rt.scale}`);
    for (const speedName of ['walk', 'run']) {
      const { poses } = gaitPoses({ speedName });
      const clip = clipFromPoses(src, poses);
      const baked = rt.bake(clip, { inPlace: false });
      assert.ok(isClipValid(baked));
      const r = compare(baked, poses);
      assert.ok(r.maxAng < 0.5, `${speedName}: giro máx. ${r.maxAng.toFixed(3)}°`);
      assert.ok(r.maxJoint < 0.003 * H, `${speedName}: articulaciones ${(r.maxJoint * 1000).toFixed(2)} mm`);
      assert.ok(r.maxRoot < 0.003 * H, `${speedName}: altura de caderas ${(r.maxRoot * 1000).toFixed(2)} mm`);
    }
  });
}

test('pose A en el origen: los brazos adoptan su dirección sin doblarse ni cruzarse', () => {
  const aRest = 40 * DEG;
  const src = makeSource({ aRest, yaw: Math.PI });
  const rt = createRetargeter(rig, src);
  // Reposo del origen sin ninguna pista: se debe ver su pose A.
  const rest = { name: 'quieto', duration: 1, tracks: [{ node: src.bones[src.idx[0]].name, prop: 'position', times: [0, 1], values: [...v3.mul(rig.joints[0], src.S), ...v3.mul(rig.joints[0], src.S)] }] };
  const baked = rt.bake(rest);
  const q = createClipPlayer(baked).sample(0.3);
  const J = poseJoints(rig, { root: [0, 0, 0], world: q.world });
  const dirL = v3.norm(v3.sub(J[IDX.LeftLowerArm], J[IDX.LeftUpperArm]));
  const dirR = v3.norm(v3.sub(J[IDX.RightLowerArm], J[IDX.RightUpperArm]));
  // Cada brazo queda como en el origen: su dirección de reposo (la del rig) bajada 40° respecto a la horizontal del lado.
  const t0 = (a, b) => v3.norm(v3.sub(rig.joints[b], rig.joints[a]));
  const wantL = qRotate(qRotZ(-aRest), t0(IDX.LeftUpperArm, IDX.LeftLowerArm));
  const wantR = qRotate(qRotZ(aRest), t0(IDX.RightUpperArm, IDX.RightLowerArm));
  assert.ok(v3.dist(dirL, wantL) < 1e-6, `izquierdo ${dirL} ≠ ${wantL}`);
  assert.ok(v3.dist(dirR, wantR) < 1e-6, `derecho ${dirR} ≠ ${wantR}`);
  assert.ok(dirL[1] < t0(IDX.LeftUpperArm, IDX.LeftLowerArm)[1] - 0.5, 'el brazo izquierdo bajó');
  // La mano sigue la dirección del antebrazo (conserva su orientación relativa) y las piernas no cambian.
  const foreL = v3.norm(v3.sub(J[IDX.LeftHand], J[IDX.LeftLowerArm]));
  const wantFore = qRotate(qRotZ(-aRest), t0(IDX.LeftLowerArm, IDX.LeftHand));
  assert.ok(v3.dist(foreL, wantFore) < 1e-6, `antebrazo como en el origen: ${foreL} ≠ ${wantFore}`);
  // La mano conserva su orientación respecto al antebrazo (en el origen, ninguna): gira con él, no se queda en T.
  const handDir = qRotate(q.world[IDX.LeftHand], [1, 0, 0]);
  const foreRot = qRotate(q.world[IDX.LeftLowerArm], [1, 0, 0]);
  assert.ok(v3.dist(handDir, foreRot) < 1e-6, 'la mano sigue al antebrazo');
  const legDir = v3.norm(v3.sub(J[IDX.LeftFoot], J[IDX.LeftUpperLeg]));
  assert.ok(legDir[1] < -0.99, 'las piernas siguen rectas');
  // Y con una marcha encima, brazos y piernas se mueven y siguen siendo válidos (sin NaN ni flip).
  const { poses } = gaitPoses({ speedName: 'run' });
  const b2 = rt.bake(clipFromPoses(src, poses, 30, { aRest }), { inPlace: false });
  assert.ok(isClipValid(b2));
  const p = createClipPlayer(b2);
  let jump = 0, prev = null;
  for (let t = 0; t <= b2.duration; t += 1 / 120) {
    const s = p.sample(t);
    if (prev) for (let b = 0; b < BONE_COUNT; b++) jump = Math.max(jump, angleBetween(s.world[b], prev.world[b]));
    prev = s;
  }
  assert.ok(jump < 12, `salto máximo de giro entre muestras de 8 ms: ${jump.toFixed(2)}°`);
});

test('piernas más largas en el origen: los pies siguen apoyados y la altura de las caderas se adapta', () => {
  const src = makeSource({ legStretch: 1.2, yaw: Math.PI });
  const rt = createRetargeter(rig, src);
  assert.ok(rt.scale < 0.95 && rt.scale > 0.75, `escala ${rt.scale}`);
  const { poses } = gaitPoses({ speedName: 'walk', seconds: 4 });
  // El origen camina con SU esqueleto: su cadera debe subir lo que sube una pierna más larga (aprox. proporcional).
  const clip = clipFromPoses(src, poses);
  const baked = rt.bake(clip, { inPlace: true });
  const p = createClipPlayer(baked);
  let minFoot = Infinity, maxFoot = -Infinity, nonFinite = 0;
  for (let t = 0; t <= baked.duration; t += 1 / 60) {
    const s = p.sample(t);
    if (!s.world.every((q) => q.every(Number.isFinite)) || !s.root.every(Number.isFinite)) nonFinite++;
    const J = poseJoints(rig, s);
    const low = Math.min(J[IDX.LeftFoot][1], J[IDX.RightFoot][1]);
    minFoot = Math.min(minFoot, low);
    maxFoot = Math.max(maxFoot, low);
  }
  assert.equal(nonFinite, 0);
  const rest = Math.min(rig.joints[IDX.LeftFoot][1], rig.joints[IDX.RightFoot][1]);
  // El pie más bajo no se hunde ni flota respecto al reposo del rig más allá de la propia oscilación de la marcha.
  assert.ok(minFoot > rest - 0.03 * H, `se hunde ${(rest - minFoot) * 1000} mm`);
  assert.ok(maxFoot < rest + 0.08 * H, `flota ${(maxFoot - rest) * 1000} mm`);
});

// ── Raíz, bucle y reproductor ─────────────────────────────────────────────────────────────────
test('«en el sitio»: se quita la deriva horizontal y se informa la velocidad del suelo', () => {
  const src = makeSource({ yaw: Math.PI });
  const rt = createRetargeter(rig, src);
  const { poses } = gaitPoses({ speedName: 'walk', seconds: 2 });
  const v = 1.4; // m/s de avance del origen en su Z canónico (a lo largo de 2 s)
  const moving = poses.map((p, i) => ({ ...p, root: [p.root[0], p.root[1], p.root[2] + (v * i) / 30] }));
  const baked = rt.bake(clipFromPoses(src, moving), { inPlace: true });
  assert.ok(Math.abs(baked.groundSpeed - v) < 0.05, `velocidad del suelo ${baked.groundSpeed}`);
  const first = createClipPlayer(baked).sample(0);
  const last = createClipPlayer(baked).sample(baked.duration);
  assert.ok(Math.abs(last.root[2] - first.root[2]) < 1e-3, 'no avanza');
  const free = rt.bake(clipFromPoses(src, moving), { inPlace: false });
  assert.ok(Math.abs(createClipPlayer(free).sample(free.duration).root[2] - v * 2) < 0.08, 'con movimiento de raíz sí avanza');
});

test('un ciclo de marcha completo se detecta como bucle y no da saltos al repetirse', () => {
  const src = makeSource({});
  const rt = createRetargeter(rig, src);
  const an = createAnimator(rig);
  an.setSpeed(an.speeds.walk);
  for (let i = 0; i < 400; i++) an.update(1 / 60);
  const cycle = an.gait.cycleTime(an.state.u);
  const fps = 60;
  const n = Math.round(cycle * fps);
  const start = an.state.phase;
  const poses = [];
  // Muestrea exactamente un ciclo: avanza hasta volver a la misma fase.
  let guard = 0;
  while (guard++ < 5000) {
    const r = an.update(1 / fps);
    poses.push(r.pose);
    if (poses.length > n / 2 && Math.abs(((r.phase - start + 1.5) % 1) - 0.5) < 0.5 / n) break;
  }
  const clip = clipFromPoses(src, poses, fps);
  const baked = rt.bake(clip, { inPlace: true });
  assert.equal(baked.loop, true, 'un ciclo de marcha es un bucle');
  const p = createClipPlayer(baked);
  const a = p.sample(baked.duration - 1e-6);
  const b = p.sample(0);
  let wrap = 0;
  for (let i = 0; i < BONE_COUNT; i++) wrap = Math.max(wrap, angleBetween(a.world[i], b.world[i]));
  assert.ok(wrap < 4, `salto al cerrar el bucle: ${wrap.toFixed(2)}°`);
  // update(): el tiempo da la vuelta y done queda en false.
  let r;
  for (let i = 0; i < 400; i++) r = p.update(1 / 60);
  assert.equal(r.done, false);
  assert.ok(r.time >= 0 && r.time < baked.duration);
});

test('un saludo (una sola vez) no es bucle, termina y mantiene el último fotograma', () => {
  const src = makeSource({});
  const rt = createRetargeter(rig, src);
  const an = createAnimator(rig);
  an.wave();
  const poses = [];
  for (let i = 0; i < 60; i++) poses.push(an.update(1 / 30).pose);
  const baked = rt.bake(clipFromPoses(src, poses), { inPlace: true });
  const p = createClipPlayer(baked);
  let r;
  for (let i = 0; i < 400 && !p.done; i++) r = p.update(1 / 30);
  assert.equal(p.done, true);
  assert.ok(Math.abs(r.time - baked.duration) < 1e-9);
  const again = p.update(1);
  assert.ok(again.pose.world.every((q) => q.every(Number.isFinite)));
  p.reset();
  assert.equal(p.done, false);
  assert.equal(p.time, 0);
});

// ── Errores con mensaje claro ──────────────────────────────────────────────────────────────────
test('un esqueleto al que le faltan huesos esenciales explica cuáles', () => {
  const src = makeSource({});
  const cut = { bones: src.bones.map((b) => (b.name === 'mixamorig:LeftForeArm' ? { ...b, name: 'Brazo_raro' } : b)) };
  assert.throws(() => createRetargeter(rig, cut), /LeftLowerArm/);
  assert.throws(() => createRetargeter(rig, { bones: [] }), /esqueleto utilizable/);
  const unordered = { bones: [{ name: 'a', parent: 1 }, { name: 'b', parent: -1 }, { name: 'c', parent: 0 }, { name: 'd', parent: 0 }, { name: 'e', parent: 0 }] };
  assert.throws(() => createRetargeter(rig, unordered), /ordenado/);
});

test('animaciones sin pistas del esqueleto, demasiado largas o vacías se rechazan con motivo', () => {
  const src = makeSource({});
  const rt = createRetargeter(rig, src);
  assert.throws(() => rt.bake({ name: 'x', duration: 2, tracks: [{ node: 'otro', prop: 'quaternion', times: [0, 1], values: new Array(8).fill(0) }] }), /no tiene pistas/);
  assert.throws(() => rt.bake({ name: 'x', duration: 0, tracks: [] }), /no tiene pistas/);
  const q = [0, 0, 0, 1];
  assert.throws(() => rt.bake({ name: 'x', duration: 100, tracks: [{ node: src.bones[src.idx[0]].name, prop: 'quaternion', times: [0, 100], values: [...q, ...q] }] }), /máximo/);
  // Valores no finitos en las pistas no pasan al resultado.
  assert.throws(() => rt.bake({ name: 'x', duration: 1, tracks: [{ node: src.bones[src.idx[0]].name, prop: 'quaternion', times: [0, 1], values: [NaN, 0, 0, 1, 0, 0, 0, 1] }] }), /no válidos/);
});

test('pistas con pocos fotogramas, tiempos irregulares y un solo fotograma funcionan', () => {
  const src = makeSource({});
  const rt = createRetargeter(rig, src);
  const hips = src.bones[src.idx[0]].name;
  const spine = src.bones[src.idx[IDX.Spine]].name;
  const lean = (a) => [Math.sin(a / 2), 0, 0, Math.cos(a / 2)];
  const baked = rt.bake({ name: 'inclinar', duration: 1.5, tracks: [
    { node: spine, prop: 'quaternion', times: [0, 0.2, 1.5], values: [...lean(0), ...lean(0.4), ...lean(0)] },
    { node: hips, prop: 'quaternion', times: [0.7], values: [0, 0, 0, 1] },
  ] }, { fps: 24 });
  assert.equal(baked.loop, true, 'empieza y termina igual');
  assert.equal(baked.frames, 36, 'un bucle de 1,5 s a 24 fps: el último fotograma coincide con el primero y no se repite');
  const p = createClipPlayer(baked);
  const mid = p.sample(0.2);
  const J = poseJoints(rig, mid);
  const J0 = poseJoints(rig, p.sample(0));
  assert.ok(v3.dist(J[IDX.Head], J0[IDX.Head]) > 0.05 * H, 'la columna se inclinó');
});

// ── Lectura de la escena de Three.js (con objetos simulados) ───────────────────────────────────
// Reconstruye, a partir del JSON plano, objetos con la forma de Object3D / AnimationClip de Three.js.
function fakeScene(json, { withMesh = true } = {}) {
  const objs = json.nodes.map((n) => ({
    name: n.name, children: [], isBone: n.isBone,
    position: { x: n.position[0], y: n.position[1], z: n.position[2] },
    quaternion: { x: n.quaternion[0], y: n.quaternion[1], z: n.quaternion[2], w: n.quaternion[3] },
    scale: { x: n.scale[0], y: n.scale[1], z: n.scale[2] },
  }));
  json.nodes.forEach((n, i) => n.parent >= 0 && objs[n.parent].children.push(objs[i]));
  const root = { name: 'Scene', children: [objs[0]], position: { x: 0, y: 0, z: 0 }, quaternion: { x: 0, y: 0, z: 0, w: 1 }, scale: { x: 1, y: 1, z: 1 } };
  if (withMesh) {
    root.children.push({ name: 'Body', isSkinnedMesh: true, isMesh: true, children: [{ name: 'Adorno', children: [] }] });
    root.children.push({ name: 'Luz', isLight: true, children: [] });
  }
  const animations = json.animations.map((a) => ({ name: a.name, duration: a.duration, tracks: [...a.tracks.map((t) => ({ ...t, times: Float32Array.from(t.times), values: Float32Array.from(t.values) })), { name: 'Body.morphTargetInfluences', times: [0], values: [0] }, { name: `${a.tracks[0].name.split('.')[0]}.scale`, times: [0], values: [1, 1, 1] }] }));
  return { root, animations };
}

test('escena de Three.js → datos planos: se conservan huesos y ancestros, se descartan mallas, luces y pistas ajenas', () => {
  const src = makeSource({ scale: 1.1, yaw: Math.PI });
  const { poses } = gaitPoses({ speedName: 'walk', seconds: 2 });
  const json = fx.sceneJSON(src, clipFromPoses(src, poses));
  const { root, animations } = fakeScene(json);
  const flat = sourceFromObject3D(root);
  const names = flat.bones.map((b) => b.name);
  assert.ok(names.includes('Scene') && names.includes('Armature') && names.includes('mixamorig:Hips'));
  assert.ok(!names.includes('Body') && !names.includes('Luz') && !names.includes('Adorno'));
  flat.bones.forEach((b, i) => assert.ok(b.parent < i, 'padres antes que hijos'));
  assert.equal(flat.bones.find((b) => b.name === 'Armature').parent, 0);
  const clips = clipsFromThree(animations);
  assert.equal(clips.length, 1);
  assert.ok(clips[0].tracks.every((t) => t.prop === 'quaternion' || t.prop === 'position'), 'solo giros y posiciones');
  // Todo el recorrido: escena → retargeter → clip cocido que reproduce la marcha del rig.
  const baked = createRetargeter(rig, flat).bake(clips[0], { inPlace: false });
  const r = compare(baked, poses);
  assert.ok(r.maxAng < 0.5 && r.maxJoint < 0.003 * H, `ang ${r.maxAng.toFixed(3)}° · art ${(r.maxJoint * 1000).toFixed(2)} mm`);
});

test('una escena sin huesos o con nombres ajenos da un mensaje claro', () => {
  assert.throws(() => sourceFromObject3D({ name: 'Scene', children: [{ name: 'Cubo', isMesh: true, children: [] }] }), /no contiene un esqueleto/);
  const chain = (names) => names.reduceRight((child, name) => ({ name, isBone: true, children: child ? [child] : [] }), null);
  const odd = { name: 'Scene', children: [chain(['A', 'B', 'C', 'D', 'E', 'F'])] };
  const flat = sourceFromObject3D(odd);
  assert.equal(flat.bones.length, 7);
  assert.throws(() => createRetargeter(rig, flat), /No se reconocen estos huesos/);
  const tiny = sourceFromObject3D({ name: 'Scene', children: [chain(['A', 'B'])] });
  assert.throws(() => createRetargeter(rig, tiny), /esqueleto utilizable/);
});
