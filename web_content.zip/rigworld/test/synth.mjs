// Humanoide sintético para pruebas: una malla de una sola piel (como un modelo real) obtenida con
// «marching tetrahedra» sobre una unión suave de cápsulas y elipsoides. Permite probar el ajuste del
// esqueleto y los pesos con poses distintas (T, A, brazos abajo), piernas juntas o abiertas, otra
// orientación (eje Z hacia arriba, mirando a otro lado), otra escala y otro desplazamiento.
import { computeNormals } from '../js/import/mesh.js';

const smin = (a, b, k) => {
  const h = Math.max(k - Math.abs(a - b), 0) / k;
  return Math.min(a, b) - h * h * k * 0.25;
};

// Cono redondeado: distancia a un segmento con radio que varía linealmente.
function roundCone(px, py, pz, a, b, ra, rb) {
  const bax = b[0] - a[0], bay = b[1] - a[1], baz = b[2] - a[2];
  const pax = px - a[0], pay = py - a[1], paz = pz - a[2];
  const t = Math.min(1, Math.max(0, (pax * bax + pay * bay + paz * baz) / (bax * bax + bay * bay + baz * baz)));
  const dx = pax - bax * t, dy = pay - bay * t, dz = paz - baz * t;
  return Math.hypot(dx, dy, dz) - (ra + (rb - ra) * t);
}

function ellipsoid(px, py, pz, c, r) {
  const x = (px - c[0]) / r[0], y = (py - c[1]) / r[1], z = (pz - c[2]) / r[2];
  const k = Math.hypot(x, y, z);
  return (k - 1) * Math.min(r[0], r[1], r[2]);
}

// Descripción del cuerpo en el marco canónico: Y arriba, +Z al frente, +X el lado izquierdo.
export function bodySpec({ H = 1.75, pose = 'T', legSplay = 4, elbowBend = 0, kneeBend = 0 } = {}) {
  const abd = { T: 90, A: 45, down: 9 }[pose] ?? pose;
  const hipY = 0.52 * H, ankleY = 0.045 * H;
  const spec = { H, parts: [], truth: {} };
  const head = [0, 0.935 * H, 0.012 * H];
  const sides = [1, -1];
  spec.truth.Head = [0, 0.885 * H, 0];
  spec.truth.Neck = [0, 0.82 * H, 0];
  spec.truth.Hips = [0, hipY, 0];

  const arms = [];
  const legs = [];
  for (const s of sides) {
    const name = s > 0 ? 'Left' : 'Right';
    const a = (abd * Math.PI) / 180;
    const sh = [s * 0.115 * H, 0.81 * H, 0];
    const dir = [s * Math.sin(a), -Math.cos(a), 0];
    const upper = 0.186 * H, fore = 0.146 * H, hand = 0.095 * H;
    const el = [sh[0] + dir[0] * upper, sh[1] + dir[1] * upper, sh[2] + dir[2] * upper];
    // El antebrazo se dobla hacia delante (+Z) el ángulo pedido.
    const b = (elbowBend * Math.PI) / 180;
    const fdir = [dir[0] * Math.cos(b), dir[1] * Math.cos(b), Math.sin(b) + dir[2] * Math.cos(b)];
    const fl = Math.hypot(...fdir);
    const fd = fdir.map((x) => x / fl);
    const wr = [el[0] + fd[0] * fore, el[1] + fd[1] * fore, el[2] + fd[2] * fore];
    const tip = [wr[0] + fd[0] * hand, wr[1] + fd[1] * hand, wr[2] + fd[2] * hand];
    arms.push({ sh, el, wr, tip, s });
    spec.truth[`${name}UpperArm`] = sh;
    spec.truth[`${name}LowerArm`] = el;
    spec.truth[`${name}Hand`] = wr;
    spec.truth[`${name}HandTip`] = tip;

    const p = (legSplay * Math.PI) / 180;
    const hip = [s * 0.065 * H, hipY, 0];
    const ldir = [s * Math.sin(p), -Math.cos(p), 0];
    const L = (hipY - ankleY) / Math.cos(p);
    const kb = (kneeBend * Math.PI) / 180;
    // Rodilla: punto medio desplazado hacia delante según kneeBend (el pie sigue en el suelo).
    const half = L / 2;
    const knee = [hip[0] + ldir[0] * half, hip[1] + ldir[1] * half, hip[2] + ldir[2] * half + Math.sin(kb) * half * 0.5];
    const ankle = [hip[0] + ldir[0] * L, ankleY, hip[2] + ldir[2] * L];
    legs.push({ hip, knee, ankle, s });
    spec.truth[`${name}UpperLeg`] = hip;
    spec.truth[`${name}LowerLeg`] = knee;
    spec.truth[`${name}Foot`] = ankle;
  }
  spec.arms = arms;
  spec.legs = legs;
  spec.head = head;
  return spec;
}

function makeSdf(spec) {
  const { H, arms, legs, head } = spec;
  const hipY = 0.52 * H;
  return (x, y, z) => {
    // Cabeza, cuello y torso
    let d = ellipsoid(x, y, z, head, [0.058 * H, 0.072 * H, 0.07 * H]);
    d = smin(d, roundCone(x, y, z, [0, 0.855 * H, 0], [0, 0.91 * H, 0.005 * H], 0.03 * H, 0.028 * H), 0.02 * H);
    // Tronco elíptico: se escala x y z antes de medir
    const tx = x / 1.55, tz = z / 1.0;
    const torso = roundCone(tx, y, tz, [0, 0.6 * H, 0], [0, 0.77 * H, 0], 0.066 * H, 0.068 * H) * 1.0;
    const chestW = ellipsoid(x, y, z, [0, 0.765 * H, 0], [0.12 * H, 0.06 * H, 0.07 * H]);
    const pelvis = ellipsoid(x, y, z, [0, hipY + 0.005 * H, 0], [0.098 * H, 0.075 * H, 0.068 * H]);
    d = smin(d, Math.min(torso, chestW), 0.03 * H);
    d = smin(d, pelvis, 0.04 * H);
    for (const a of arms) {
      let arm = roundCone(x, y, z, a.sh, a.el, 0.034 * H, 0.027 * H);
      arm = Math.min(arm, roundCone(x, y, z, a.el, a.wr, 0.027 * H, 0.02 * H));
      arm = Math.min(arm, roundCone(x, y, z, a.wr, a.tip, 0.021 * H, 0.012 * H));
      d = smin(d, arm, 0.012 * H);
    }
    // Cada pierna se une al cuerpo con suavidad, pero las dos piernas no se funden entre sí.
    let legsD = Infinity;
    for (const l of legs) {
      let leg = roundCone(x, y, z, l.hip, l.knee, 0.062 * H, 0.043 * H);
      leg = Math.min(leg, roundCone(x, y, z, l.knee, l.ankle, 0.043 * H, 0.026 * H));
      const foot = ellipsoid(x, y, z, [l.ankle[0], l.ankle[1] - 0.02 * H, l.ankle[2] + 0.04 * H], [0.036 * H, 0.025 * H, 0.088 * H]);
      leg = smin(leg, foot, 0.012 * H);
      legsD = Math.min(legsD, leg);
    }
    return smin(d, legsD, 0.03 * H);
  };
}

// ── Marching tetrahedra ──────────────────────────────────────────────────────────────────────
const CORNERS = [[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0], [0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]];
const TETS = [[0, 5, 1, 6], [0, 1, 2, 6], [0, 2, 3, 6], [0, 3, 7, 6], [0, 7, 4, 6], [0, 4, 5, 6]];

function polygonize(sdf, min, max, step) {
  const nx = Math.ceil((max[0] - min[0]) / step) + 1;
  const ny = Math.ceil((max[1] - min[1]) / step) + 1;
  const nz = Math.ceil((max[2] - min[2]) / step) + 1;
  const val = new Float32Array(nx * ny * nz);
  const id = (i, j, k) => i + nx * (j + ny * k);
  for (let k = 0; k < nz; k++) for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) val[id(i, j, k)] = sdf(min[0] + i * step, min[1] + j * step, min[2] + k * step);

  const verts = [];
  const edgeMap = new Map();
  const tris = [];
  const pos = (n) => {
    const i = n % nx, j = Math.floor(n / nx) % ny, k = Math.floor(n / (nx * ny));
    return [min[0] + i * step, min[1] + j * step, min[2] + k * step];
  };
  const edgeVertex = (na, nb) => {
    if (na > nb) [na, nb] = [nb, na];
    const key = na * val.length + nb;
    let v = edgeMap.get(key);
    if (v !== undefined) return v;
    const va = val[na], vb = val[nb];
    const t = va / (va - vb);
    const pa = pos(na), pb = pos(nb);
    verts.push(pa[0] + (pb[0] - pa[0]) * t, pa[1] + (pb[1] - pa[1]) * t, pa[2] + (pb[2] - pa[2]) * t);
    v = verts.length / 3 - 1;
    edgeMap.set(key, v);
    return v;
  };
  const P = (v) => [verts[v * 3], verts[v * 3 + 1], verts[v * 3 + 2]];
  const pushOriented = (a, b, c, outward) => {
    const pa = P(a), pb = P(b), pc = P(c);
    const u = [pb[0] - pa[0], pb[1] - pa[1], pb[2] - pa[2]], w = [pc[0] - pa[0], pc[1] - pa[1], pc[2] - pa[2]];
    const n = [u[1] * w[2] - u[2] * w[1], u[2] * w[0] - u[0] * w[2], u[0] * w[1] - u[1] * w[0]];
    if (n[0] * outward[0] + n[1] * outward[1] + n[2] * outward[2] >= 0) tris.push(a, b, c);
    else tris.push(a, c, b);
  };

  const nodes = new Array(8);
  for (let k = 0; k < nz - 1; k++) {
    for (let j = 0; j < ny - 1; j++) {
      for (let i = 0; i < nx - 1; i++) {
        let any = 0, all = 0;
        for (let c = 0; c < 8; c++) {
          const n = id(i + CORNERS[c][0], j + CORNERS[c][1], k + CORNERS[c][2]);
          nodes[c] = n;
          if (val[n] < 0) any++;
          else all++;
        }
        if (any === 0 || all === 0) continue;
        for (const tet of TETS) {
          const n4 = tet.map((c) => nodes[c]);
          const inside = n4.filter((n) => val[n] < 0);
          const outside = n4.filter((n) => val[n] >= 0);
          if (inside.length === 0 || outside.length === 0) continue;
          if (inside.length === 1) {
            const a = inside[0];
            const e = outside.map((b) => edgeVertex(a, b));
            const pa = pos(a), po = pos(outside[0]);
            pushOriented(e[0], e[1], e[2], [po[0] - pa[0], po[1] - pa[1], po[2] - pa[2]]);
          } else if (inside.length === 3) {
            const a = outside[0];
            const e = inside.map((b) => edgeVertex(a, b));
            const pa = pos(a), pi = pos(inside[0]);
            pushOriented(e[0], e[1], e[2], [pa[0] - pi[0], pa[1] - pi[1], pa[2] - pi[2]]);
          } else {
            const [i0, i1] = inside, [o0, o1] = outside;
            const e00 = edgeVertex(i0, o0), e01 = edgeVertex(i0, o1), e11 = edgeVertex(i1, o1), e10 = edgeVertex(i1, o0);
            const pi0 = pos(i0), pi1 = pos(i1), po0 = pos(o0), po1 = pos(o1);
            const dir = [(po0[0] + po1[0] - pi0[0] - pi1[0]) / 2, (po0[1] + po1[1] - pi0[1] - pi1[1]) / 2, (po0[2] + po1[2] - pi0[2] - pi1[2]) / 2];
            pushOriented(e00, e01, e11, dir);
            pushOriented(e00, e11, e10, dir);
          }
        }
      }
    }
  }
  return { positions: Float32Array.from(verts), indices: Uint32Array.from(tris) };
}

// Aplica orientación/escala/desplazamiento al resultado canónico.
function transform(positions, { yaw = 0, up = 'y', scale = 1, offset = [0, 0, 0] }) {
  const out = new Float32Array(positions.length);
  const c = Math.cos(yaw), s = Math.sin(yaw);
  for (let i = 0; i < positions.length; i += 3) {
    let x = positions[i], y = positions[i + 1], z = positions[i + 2];
    // yaw alrededor de Y (el personaje mira a +Z de partida)
    const rx = x * c + z * s, rz = -x * s + z * c;
    x = rx;
    z = rz;
    if (up === 'z') {
      const t = y;
      y = -z;
      z = t;
    }
    out[i] = x * scale + offset[0];
    out[i + 1] = y * scale + offset[1];
    out[i + 2] = z * scale + offset[2];
  }
  return out;
}

const cache = new Map();

// Devuelve { meshes, materials, truth, spec }.
export function makeHumanoid(opts = {}) {
  const { pose = 'T', H = 1.75, legSplay = 4, elbowBend = 0, kneeBend = 0, step = 0.018, yaw = 0, up = 'y', scale = 1, offset = [0, 0, 0] } = opts;
  const key = JSON.stringify({ pose, H, legSplay, elbowBend, kneeBend, step });
  let base = cache.get(key);
  if (!base) {
    const spec = bodySpec({ H, pose, legSplay, elbowBend, kneeBend });
    const sdf = makeSdf(spec);
    const pad = 0.1 * H;
    const span = pose === 'T' ? 0.62 * H : pose === 'A' ? 0.5 * H : 0.28 * H;
    const mesh = polygonize(sdf, [-span - pad, -0.02 * H, -0.2 * H], [span + pad, 1.02 * H, 0.26 * H], step);
    base = { ...mesh, spec };
    cache.set(key, base);
  }
  const positions = transform(base.positions, { yaw, up, scale, offset });
  const normals = computeNormals(positions, base.indices);
  return {
    meshes: [{ name: 'body', positions, normals, uvs: null, colors: null, indices: base.indices, material: 0 }],
    materials: [{ name: 'piel', color: [0.82, 0.68, 0.58], opacity: 1, map: -1, doubleSided: true, colorLinear: false }],
    images: [],
    truth: base.spec.truth,
    spec: base.spec,
    H: H * scale,
  };
}
