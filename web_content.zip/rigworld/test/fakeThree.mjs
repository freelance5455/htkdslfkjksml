// Three.js simulado SOLO para pruebas sin red. Implementa lo justo de la API que usan viewer3d.js,
// previewScene.js, thumbs.js y gl.js, y anota en globalThis.__fake lo que se "dibujaría".
// No comprueba que la API real de Three.js se use bien (eso lo cubre la revisión contra r186);
// comprueba la lógica propia: cambios de geometría, texturas asignadas, ciclo de vida y eventos.
const rec = (globalThis.__fake = { renders: 0, viewerTris: 0, viewerMapped: false, viewerScenes: 0, thumbScenes: 0, geometriesDisposed: 0, renderers: 0, skinned: 0, skinAttrOk: false, bones: 0, boneQuatSets: 0, lastRootY: null, rootYMax: -Infinity, overlayVisible: false, skeletonsDisposed: 0 });

export const SRGBColorSpace = 'srgb';
export const LinearSRGBColorSpace = 'srgb-linear';
export const DoubleSide = 2;
export const FrontSide = 0;

export class Vector3 {
  constructor(x = 0, y = 0, z = 0) {
    this.x = x;
    this.y = y;
    this.z = z;
  }
  set(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
    return this;
  }
  sub(v) {
    this.x -= v.x;
    this.y -= v.y;
    this.z -= v.z;
    return this;
  }
  addScaledVector(v, s) {
    this.x += v.x * s;
    this.y += v.y * s;
    this.z += v.z * s;
    return this;
  }
  length() {
    return Math.hypot(this.x, this.y, this.z);
  }
  clampLength() {
    return this;
  }
  setFromMatrixColumn() {
    return this;
  }
}
export class Color {
  setRGB() {
    return this;
  }
}
export class BufferAttribute {
  constructor(array, itemSize) {
    this.array = array;
    this.itemSize = itemSize;
    this.count = array.length / itemSize;
  }
}
export class BufferGeometry {
  constructor() {
    this.attributes = {};
    this.index = null;
  }
  setAttribute(name, attr) {
    this.attributes[name] = attr;
    return this;
  }
  setIndex(attr) {
    this.index = attr;
    return this;
  }
  computeBoundingSphere() {}
  dispose() {
    rec.geometriesDisposed++;
  }
}
export class MeshStandardMaterial {
  constructor(params = {}) {
    Object.assign(this, params);
  }
  dispose() {}
}
export class CanvasTexture {
  constructor(canvas) {
    this.image = canvas;
  }
  dispose() {}
}
export class Mesh {
  constructor(geometry, material) {
    this.geometry = geometry;
    this.material = material;
  }
}
export class Matrix4 {}
export class Uint16BufferAttribute extends BufferAttribute {
  constructor(array, itemSize) {
    if (!(array instanceof Uint16Array)) throw new Error('skinIndex debe ser Uint16Array');
    super(array, itemSize);
  }
}
export class Float32BufferAttribute extends BufferAttribute {
  constructor(array, itemSize) {
    if (!(array instanceof Float32Array)) throw new Error('skinWeight debe ser Float32Array');
    super(array, itemSize);
  }
}
class Quat {
  constructor() {
    this.x = this.y = this.z = 0;
    this.w = 1;
  }
  set(x, y, z, w) {
    Object.assign(this, { x, y, z, w });
    rec.boneQuatSets++;
    return this;
  }
}
// Posición de un hueso: la del hueso raíz (sin padre) anota su altura para comprobar saltos y marcha.
class BonePosition extends Vector3 {
  constructor(bone) {
    super();
    this.bone = bone;
  }
  set(x, y, z) {
    super.set(x, y, z);
    if (!this.bone.parent) {
      rec.lastRootY = y;
      if (y > rec.rootYMax) rec.rootYMax = y;
    }
    return this;
  }
}
export class Bone {
  constructor() {
    this.children = [];
    this.parent = null;
    this.position = new BonePosition(this);
    this.quaternion = new Quat();
    this.name = '';
    rec.bones++;
  }
  add(o) {
    o.parent = this;
    this.children.push(o);
    return this;
  }
  updateMatrixWorld() {}
}
export class Skeleton {
  constructor(bones) {
    if (!bones.length) throw new Error('Skeleton sin huesos');
    this.bones = bones;
  }
  dispose() {
    rec.skeletonsDisposed++;
  }
}
export class SkinnedMesh {
  constructor(geometry, material) {
    this.geometry = geometry;
    this.material = material;
    this.isSkinnedMesh = true;
  }
  bind(skeleton) {
    if (!skeleton?.bones?.length) throw new Error('bind sin esqueleto');
    this.skeleton = skeleton;
    rec.skinned++;
    const a = this.geometry.attributes;
    rec.skinAttrOk = !!a.skinIndex && !!a.skinWeight && a.skinIndex.count === a.position.count && a.skinWeight.count === a.position.count;
  }
}
export class LineBasicMaterial {
  constructor(p = {}) {
    Object.assign(this, p);
  }
  dispose() {}
}
export class PointsMaterial extends LineBasicMaterial {}
class Overlay {
  constructor(geometry, material) {
    this.geometry = geometry;
    this.material = material;
    this._visible = true;
  }
  get visible() {
    return this._visible;
  }
  set visible(v) {
    this._visible = v;
    rec.overlayVisible = v;
  }
}
export class LineSegments extends Overlay {}
export class Points extends Overlay {}

export class LoadingManager {
  setURLModifier() {
    return this;
  }
}

export class Group {
  constructor() {
    this.children = [];
    this.position = new Vector3();
  }
  add(...os) {
    this.children.push(...os);
    return this;
  }
}
export class Box3 {
  setFromObject(group) {
    this.min = new Vector3(Infinity, Infinity, Infinity);
    this.max = new Vector3(-Infinity, -Infinity, -Infinity);
    for (const mesh of group.children) {
      if (!mesh.geometry || mesh instanceof Overlay) continue; // huesos, líneas y puntos no cuentan para el encuadre
      const p = mesh.geometry.attributes.position.array;
      for (let i = 0; i < p.length; i += 3) {
        if (p[i] < this.min.x) this.min.x = p[i];
        if (p[i] > this.max.x) this.max.x = p[i];
        if (p[i + 1] < this.min.y) this.min.y = p[i + 1];
        if (p[i + 1] > this.max.y) this.max.y = p[i + 1];
        if (p[i + 2] < this.min.z) this.min.z = p[i + 2];
        if (p[i + 2] > this.max.z) this.max.z = p[i + 2];
      }
    }
    return this;
  }
  getCenter(t) {
    return t.set((this.min.x + this.max.x) / 2, (this.min.y + this.max.y) / 2, (this.min.z + this.max.z) / 2);
  }
  getSize(t) {
    return t.set(this.max.x - this.min.x, this.max.y - this.min.y, this.max.z - this.min.z);
  }
}
export class Scene {
  constructor() {
    this.children = [];
    this.hasCamera = false;
  }
  add(o) {
    this.children.push(o);
    if (o instanceof PerspectiveCamera) this.hasCamera = true;
    if (o instanceof Group) {
      const meshes = o.children.filter((m) => m.geometry && !(m instanceof Overlay));
      const tris = meshes.reduce((s, m) => s + (m.geometry.index ? m.geometry.index.count : m.geometry.attributes.position.count) / 3, 0);
      const mapped = meshes.some((m) => !!m.material.map);
      if (this.hasCamera) {
        rec.viewerTris = tris;
        rec.viewerMapped = mapped;
        rec.viewerScenes++;
      } else rec.thumbScenes++;
    }
    return this;
  }
  remove(o) {
    this.children = this.children.filter((c) => c !== o);
  }
}
export class PerspectiveCamera {
  constructor(fov = 50, aspect = 1, near = 0.1, far = 2000) {
    Object.assign(this, { fov, aspect, near, far });
    this.position = new Vector3();
    this.matrixWorld = { elements: new Float32Array(16) };
    this.children = [];
  }
  add(o) {
    this.children.push(o);
  }
  lookAt() {}
  updateProjectionMatrix() {}
  updateMatrixWorld() {}
}
export class HemisphereLight {}
export class DirectionalLight {
  constructor() {
    this.position = new Vector3();
  }
}
export class GridHelper {
  constructor() {
    this.position = new Vector3();
    this.material = { transparent: false, opacity: 1, dispose() {} };
    this.geometry = { dispose() {} };
    this.visible = true;
  }
}
export class WebGLRenderer {
  constructor(opts = {}) {
    rec.renderers++;
    this.canvas = opts.canvas;
  }
  setPixelRatio() {}
  setSize(w, h) {
    if (this.canvas) {
      this.canvas.width = w;
      this.canvas.height = h;
    }
  }
  setClearColor() {}
  render() {
    rec.renders++;
  }
  dispose() {}
  forceContextLoss() {}
}
