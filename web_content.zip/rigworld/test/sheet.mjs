// Hojas de contacto: dibuja varias poses de una malla (proyección ortográfica con sombreado plano,
// la misma que usan las miniaturas 2D) en una sola imagen PNG para revisarlas a ojo.
// No necesita WebGL ni Three.js: usa projectTriangles() y un SVG que Chromium convierte en PNG.
import fs from 'node:fs';
import { createRequire } from 'node:module';
import { projectTriangles } from '../js/import/thumbs.js';

const MARK = [0, 1, 0]; // color de los marcadores de suelo (no se dibujan)

// frames: [{ meshes, materials, label }]. opts: { view: 'side'|'front'|'three', size, cols, box }
// `box` = { min, max } fija el encuadre de todas las celdas (si no, se calcula con todas).
export function sheetSvg(frames, { view = 'side', size = 240, cols = 6, box = null, maxTris = 7000 } = {}) {
  const yaw = view === 'side' ? Math.PI / 2 : view === 'three' ? -0.7 : 0;
  const pitch = view === 'three' ? 0.18 : 0.02;
  let b = box;
  if (!b) {
    b = { min: [Infinity, Infinity, Infinity], max: [-Infinity, -Infinity, -Infinity] };
    for (const f of frames) {
      for (const m of f.meshes) {
        const p = m.positions;
        for (let i = 0; i < p.length; i += 3) {
          for (let k = 0; k < 3; k++) {
            if (p[i + k] < b.min[k]) b.min[k] = p[i + k];
            if (p[i + k] > b.max[k]) b.max[k] = p[i + k];
          }
        }
      }
    }
  }
  const markers = (y) => ({
    name: 'marca',
    positions: Float32Array.from([b.min[0], y, 0, b.min[0] + 1e-4, y, 0, b.min[0], y + 1e-4, 1e-4, b.max[0], y, 0, b.max[0] + 1e-4, y, 0, b.max[0], y + 1e-4, 1e-4,
      0, b.min[1], b.min[2], 1e-4, b.min[1], b.min[2], 0, b.min[1] + 1e-4, b.min[2] + 1e-4, 0, b.max[1], b.max[2], 1e-4, b.max[1], b.max[2], 0, b.max[1] + 1e-4, b.max[2] + 1e-4]),
    normals: null,
    uvs: null,
    colors: null,
    indices: null,
    material: 1,
  });
  const rows = Math.ceil(frames.length / cols);
  const W = cols * size, Hh = rows * (size + 18);
  const parts = [`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${Hh}" viewBox="0 0 ${W} ${Hh}"><rect width="100%" height="100%" fill="#eef2f6"/>`];
  frames.forEach((f, i) => {
    const ox = (i % cols) * size, oy = Math.floor(i / cols) * (size + 18);
    const mats = [...f.materials, { color: MARK, colorLinear: false }];
    const mesh = [...f.meshes, markers(0)];
    mats.length = Math.max(mats.length, 2);
    mats[1] = { color: MARK, colorLinear: false };
    // Los marcadores usan material 1; si el modelo tiene más de un material, se reserva el último índice.
    const markIdx = mats.length - 1;
    mats[markIdx] = { color: MARK, colorLinear: false };
    mesh[mesh.length - 1].material = markIdx;
    const tris = projectTriangles({ meshes: mesh, materials: mats }, size, { yaw, pitch, maxTris });
    const groundPts = [];
    parts.push(`<g transform="translate(${ox} ${oy})"><rect x="0.5" y="0.5" width="${size - 1}" height="${size + 17}" fill="none" stroke="#c9d3dd"/>`);
    for (const t of tris) {
      if (t.r === 0 && t.g === 1 && t.b === 0) {
        groundPts.push(t.p);
        continue;
      }
      const byte = (v) => Math.round(Math.min(1, Math.max(0, v * t.shade)) * 255);
      const col = `rgb(${byte(t.r)},${byte(t.g)},${byte(t.b)})`;
      parts.push(`<polygon points="${t.p.map((n) => n.toFixed(1)).join(' ')}" fill="${col}" stroke="${col}" stroke-width="0.6"/>`);
    }
    if (groundPts.length >= 2) {
      const y = groundPts[0][1].toFixed(1);
      parts.push(`<line x1="2" x2="${size - 2}" y1="${y}" y2="${y}" stroke="#7a8a9a" stroke-dasharray="4 3"/>`);
    }
    parts.push(`<text x="6" y="${size + 12}" font-family="monospace" font-size="11" fill="#334">${(f.label || '').replace(/[<&]/g, '')}</text></g>`);
  });
  parts.push('</svg>');
  return { svg: parts.join(''), width: W, height: Hh };
}

export async function writeSheet(file, frames, opts = {}) {
  const require = createRequire('/opt/npm-tools/noop.js');
  const { chromium } = require('playwright');
  const { svg, width, height } = sheetSvg(frames, opts);
  const browser = await chromium.launch();
  try {
    const page = await browser.newPage({ viewport: { width, height } });
    await page.setContent(`<body style="margin:0">${svg}</body>`);
    await page.screenshot({ path: file, clip: { x: 0, y: 0, width, height } });
  } finally {
    await browser.close();
  }
  return file;
}

export const ensureDir = (dir) => fs.mkdirSync(dir, { recursive: true });
