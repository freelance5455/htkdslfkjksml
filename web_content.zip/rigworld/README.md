# RigWorld 3D · Fases 1 a 3 (Splash, Hub de importación y estudio de personaje)

SPA en HTML/JS puro (módulos ES, sin compilar) pensada para Chrome en Android. Esta entrega cubre
la **Capa 1 (Splash)**, la **Capa 2 (Hub de importación)** y la **Capa 3 (estudio de personaje:
esqueleto automático de 19 huesos, skinning, marcha/carrera animadas y retargeting de animaciones
externas)**. Las capas 4 y 5 (mundo abierto con joystick y escenario realista) llegan en las fases siguientes.

## Cómo abrirla

Necesita servirse por HTTP(S) (los módulos ES y el Web Worker no funcionan desde `file://`).

```bash
cd rigworld
python3 -m http.server 8080        # o: npx serve .
```

En el móvil: abre `http://<IP-de-tu-PC>:8080` en Chrome (misma red wifi). Three.js se carga desde jsDelivr (versión fijada 0.186.1);
sin conexión la app sigue funcionando, solo que sin visor 3D (las miniaturas pasan a dibujarse en 2D).

## Qué hace

**Capa 1 · Splash.** Silueta de puntos que se ensambla en un esqueleto de 19 huesos. El progreso es
real: cada paso de arranque (dispositivo, base de datos, ajustes, worker, Three.js) enciende
articulaciones y el contador va de 00 a 19.

**Capa 2 · Hub.**
- Importación de **GLB, glTF, FBX, OBJ(+MTL), DAE, STL y PLY**, hasta **200 MB por archivo**. Se
  eligen varios archivos a la vez (glTF con su `.bin` y texturas; OBJ con su `.mtl`) o se arrastran.
- Cola secuencial con progreso, cancelar y reintentar. Cada archivo rechazado muestra el motivo.
- Biblioteca persistente en **IndexedDB**: cada archivo se parte en **fragmentos de 10 MB**; el
  registro del modelo se escribe al final, así una importación interrumpida no deja modelos a medias
  y `repairOrphans()` limpia los fragmentos huérfanos al arrancar.
- Detalle del modelo: vista previa 3D (1 dedo gira, 2 dedos acercan y desplazan, rueda en escritorio),
  estadísticas (triángulos, vértices, mallas, materiales, texturas, dimensiones, esqueleto), renombrar,
  marcar como **modelo activo** (el que usará la Fase 2) y eliminar con confirmación propia.
- Ajustes: presupuesto de triángulos de la vista previa (20 k a 600 k; por defecto según el equipo),
  límite de resolución de pantalla y reducción de movimiento.
- Los modelos grandes se guardan **íntegros**; solo la vista previa se simplifica (agrupación de
  vértices) cuando supera el presupuesto, y se avisa.
- **Texturas.** La vista previa simplificada conserva materiales, imagen y UV: cada material se
  simplifica por separado y los vértices se agrupan por posición *y* por zona de la textura, así las
  islas del atlas no se mezclan. Las normales se promedian de las originales y los triángulos
  plegados se reorientan (evita puntos oscuros en escaneos con ruido).
- **Vista completa.** En el detalle de un modelo simplificado, el botón «Vista completa» carga la
  geometría sin simplificar, con su textura (alterna con «Vista simplificada»). Por encima de
  2 millones de triángulos pide confirmación; no se guarda en memoria al volver a la simplificada.
- **Miniaturas con textura.** Los modelos importados con la versión anterior muestran un aviso en
  el Hub («Actualizar») que redibuja sus miniaturas desde el archivo guardado, sin reimportar y sin
  cambiar el orden de la biblioteca.
- Botón Atrás de Android cierra hojas y detalle en vez de salir de la app.
- Tema claro/oscuro automático, sin desbordes horizontales desde 320 px.

**Capa 3 · Estudio de personaje** (botón «Preparar personaje» en el detalle de cada modelo).
- **Esqueleto automático de 19 huesos.** Se detecta la orientación (arriba y de frente), el tipo de
  pose (T, A o brazos abajo) y las articulaciones a partir de la malla; si el modelo sale de lado o de
  espaldas, «Girar 90°» lo corrige y «Reajustar» vuelve al ajuste automático.
- **Skinning sin deformar pies ni piernas.** Los pesos se calculan por cápsulas de hueso con
  transiciones suaves, separación izquierda/derecha y como máximo 4 influencias por vértice. Se informa la
  calidad de la deformación (buena / aceptable / puede estirar la malla).
- **Marcha y carrera de verdad.** Quieto, caminar, trotar, correr y sprint salen de un mismo ciclo continuo
  (velocidad 0–100 %): las piernas se resuelven con IK para que el pie en apoyo recorra el suelo a la velocidad
  del cuerpo (no patina), el pie rueda sobre talón y punta, las rodillas se doblan hacia delante, los brazos
  se balancean en oposición a la pierna contraria y al correr hay fase de vuelo. Saltar y saludar se funden con
  cualquier velocidad. En el estudio el suelo se desliza como una cinta para que los pies se vean fijos.
- **Animaciones de otros personajes.** «Cargar animación (FBX/GLB)» lee un personaje animado (p. ej. de
  Mixamo, VRoid/VRM) y adapta su movimiento al esqueleto: reconoce los huesos por nombre, deduce hacia dónde
  mira y su escala, copia la dirección de cada hueso (así una pose A o T de origen no deforma tu personaje),
  escala las caderas por la proporción de piernas y mantiene los pies en el suelo. Cada animación se «cuece» a
  30 fotogramas por segundo y se guarda con el esqueleto (hasta 8 por personaje, de hasta 30 s). Se reproduce en
  bucle si empieza y termina igual y se funde con el movimiento normal.
- **Persistencia ligera.** Solo se guarda el esqueleto (≈ 3 KB) y las animaciones importadas; los pesos se
  recalculan al abrir (rápido, en un Worker). La base de datos pasó a la versión 2 (almacén `rigs`) y
  actualiza sola las bibliotecas de la Fase 1 sin perder nada. En el Hub, las tarjetas con esqueleto llevan la insignia «Rig».

## Estructura

```
index.html            entrada (importmap de Three.js)
css/app.css           estilos y tokens (plano técnico: azul de Prusia / papel de dibujo)
js/main.js            arranque y pasos reales del splash
js/config.js          límites (200 MB, 10 MB por fragmento, cola, miniaturas)
js/core/              bus, capas + Atrás, ajustes, dispositivo, carga perezosa de Three, plantilla de 19 huesos
js/storage/db.js      IndexedDB propia (modelos, fragmentos, ajustes, esqueletos) con reserva en memoria
js/rig/               matemática (mathq), plantilla y poses (skeleton), ajuste del esqueleto (fit), pesos (weights),
                      marcha con IK (gait), animador (animator), retargeting (retarget, sourceScene),
                      malla con esqueleto de Three (skinned), servicio y cliente del Worker (service, client)
js/import/            analizadores STL/PLY/OBJ/MTL/glTF/GLB sin dependencias, importador de Three (FBX/DAE),
                      decimación, miniaturas, cola
js/workers/           Workers: análisis de archivos y ajuste de esqueleto / pesos
js/layers/            splash, hub, detalle, ajustes, estudio de personaje (rigStudio)
js/ui/                hojas/diálogos, toasts, visor orbital
test/                 unitarias (Node) y de extremo a extremo (Playwright)
tools/make-artifact.mjs   genera la página publicable como artefacto
```

## Pruebas

```bash
node --test test/unit.test.mjs        # 39 pruebas: formatos, analizadores, decimación con UV, miniaturas
node --test test/rig.test.mjs         # 35 pruebas: esqueleto, pesos, marcha/carrera, animador, calidad, base de datos
node --test test/retarget.test.mjs    # 15 pruebas: nombres, ida y vuelta de animaciones, pose A, bucles, errores
node test/browser.mjs ./capturas      # 24 pasos en Chromium móvil (necesita Playwright)
```

## Lo que sí está verificado y lo que no

**Verificado** (Node y Chromium móvil de 412 px y 320 px, oscuro y claro):
- Fases 1 y 2: arranque y splash, importación de GLB/STL/OBJ+MTL con rechazos, simplificación de 200 000
  triángulos, persistencia tras recargar, integridad byte a byte, fragmentos de 10 MB, reparación de huérfanos,
  renombrar/activar/eliminar, botón Atrás, ajustes y ausencia de errores de JavaScript.
- Esqueleto: ajuste correcto en humanoides sintéticos en pose T, A y brazos abajo, girados, con eje Z hacia
  arriba, a otra escala, con piernas pegadas o abiertas y mirando a +Z o −Z (error de articulaciones < 6 % de la
  altura). Longitudes de hueso exactas.
- Marcha y carrera (con el mismo ciclo que se ve en el estudio): el pie en apoyo se desliza ≈ 0,1 mm en régimen
  continuo y ≤ 2,5 cm (1,5 % de la altura) durante todos los cambios de velocidad; la punta no atraviesa el suelo
  (≥ −5 mm); al correr hay fase de vuelo; el cambio máximo de ángulo de una articulación entre fotogramas es
  2,3° a 240 fotogramas por ciclo; el ciclo cierra con error ≈ 1e-5. Se revisaron hojas de contacto (siluetas
  ya deformadas con los pesos reales) de caminar y correr en las tres poses.
- Retargeting: ida y vuelta Mixamo/VRoid (girado 180° o 90°, escala 0,8–1,3, huesos extra) reproduce la marcha
  original con < 0,5° y < 0,3 % de la altura; una pose A de origen no cruza ni dobla los brazos; piernas más
  largas mantienen los pies en el suelo; los bucles cierran sin salto.
- Estudio en el navegador (con Three simulado): abrir, ajustar, caminar/correr/saltar/saludar, esqueleto
  visible, Girar 90°, guardar, reabrir con el esqueleto guardado, quitarlo, y cargar/reproducir/guardar/quitar
  animaciones (con un cargador FBX simulado). La actualización de la base de datos de la versión 1 a la 2.

**No se pudo probar aquí** (el entorno de desarrollo no tenía acceso a Three.js ni a las CDN):
- El dibujo real con WebGL: el visor del estudio, la malla con esqueleto de Three.js (`SkinnedMesh`) y las
  miniaturas. La lógica propia se probó con un **Three.js simulado** (`test/fakeThree.mjs`: cuenta huesos,
  atributos de pesos, poses aplicadas, esqueleto visible); no demuestra que Three dibuje bien. El código está
  revisado contra la API de Three r186, pero hace falta una prueba con red real.
- Los cargadores reales de **FBX, DAE y GLB/glTF** de Three.js (también al leer animaciones) y GLB con **Draco**
  (el decodificador se descarga de la CDN). La conversión de la escena a datos planos se probó con objetos
  simulados con la forma de los de Three.js.
- Las fuentes de Google (si no cargan, se usan fuentes del sistema).

## Límites conocidos

- **Esqueleto.** El ajuste espera un personaje humanoide con dos piernas, de pie. Piernas cruzadas, personajes
  en cuclillas o con cuatro extremidades no se soportan. Con brazos pegados al cuerpo (pose «brazos abajo») y
  manos fundidas con las caderas, la malla puede estirarse cerca de la cadera (se muestra «puede estirar la
  malla»). El pie no tiene hueso de dedos: rueda sobre talón y punta con un pivote.
- **Mallas con muchos triángulos.** El esqueleto y los pesos se calculan sobre la vista previa simplificada
  (con textura); el modelo original se guarda entero y no se modifica.
- **Retargeting.** Necesita huesos con nombres reconocibles de caderas, ambas piernas y ambos brazos (Mixamo, VRoid/VRM
  y nombres estándar similares); si falta alguno se indica cuál. Las manos y la cabeza copian el giro del origen;
  no se retargetean los dedos ni la cara. Si cambias el giro del esqueleto se quitan las animaciones importadas
  (se adaptaron al esqueleto anterior).
- La velocidad en km/h del estudio supone una persona de 1,75 m: «Caminar» ≈ 3,6 km/h (paso tranquilo), «Trotar» ≈ 8,5, «Correr» ≈ 11,5 y «Sprint» ≈ 17; el deslizador cubre todo lo intermedio (un paso ligero de ≈ 5 km/h está hacia el 30 % del deslizador). La cadencia es algo alta frente a la de una persona real (pasos un poco cortos y rápidos); es un ajuste de estilo que se puede cambiar en la tabla `KEYS` de `js/rig/gait.js`.

- Archivos de 200 MB: el OBJ se lee por ventanas de 4 MB, pero STL, PLY, glTF/GLB y los formatos que
  pasan por Three.js (FBX, DAE) necesitan el archivo completo en memoria. Al guardar, todo se fragmenta
  en piezas de 10 MB. En móviles con poca RAM, Chrome puede cerrar la pestaña con archivos muy grandes.
- El almacenamiento de IndexedDB depende de la cuota del navegador; si se agota, se muestra un aviso
  claro y no se guarda nada a medias.
- Solo se lee el **color base** de las texturas (glTF `baseColorTexture`, OBJ `map_Kd`, FBX/DAE `map`).
  No se usan todavía normales, rugosidad/metal, emisivo ni la transparencia de la textura; las
  texturas KTX2 se omiten. En la vista previa se reducen a 2048 px (1024 px en equipos de gama baja);
  el original se conserva sin cambios.
- Las texturas que son archivos aparte (glTF, OBJ, FBX, DAE) deben elegirse en la misma selección
  que el modelo. En FBX y DAE, si falta una, hoy no se avisa.
- GLB con Draco/Meshopt (que pasan por Three.js): sus UV no se voltean, así que la textura podría
  verse invertida verticalmente. Pendiente de corregir.
