// Deriva la página publicable como artefacto a partir de index.html + css/app.css.
//   node tools/make-artifact.mjs
// Genera dist/artifact.html (sin <html>/<head>/<body>: el visor aporta el esqueleto, las zonas
// seguras y [hidden]) y dist/artifact-files.json (mapa «ruta publicada → archivo fuente»).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');

const index = read('index.html');
const css = read('css/app.css');

const grab = (re, what) => {
  const m = index.match(re);
  if (!m) throw new Error(`index.html: no se encontró ${what}`);
  return m[0];
};
const fonts = grab(/<link rel="preconnect" href="https:\/\/fonts\.googleapis\.com">[\s\S]*?family=Big\+Shoulders[^>]*>/, 'el enlace de fuentes');
const importmap = grab(/<script type="importmap">[\s\S]*?<\/script>/, 'el importmap');
const title = grab(/<title>[^<]+<\/title>/, 'el título');
const app = grab(/<div id="app">[\s\S]*?<\/div>\s*<\/div>|<div id="app">[\s\S]*?<\/div>/, '#app');

const version = JSON.parse(read('package.json')).version;
const page = `<!-- RigWorld 3D v${version} · fases 1 a 3: importación, esqueleto automático, marcha/carrera y retargeting -->
${title}
<meta name="claude:viewport-fit-sides" content="cover">
${fonts}
<style>
${css.trim()}
</style>
${importmap}
${app}
<script type="module" src="js/main.js"></script>
`;

fs.mkdirSync(path.join(ROOT, 'dist'), { recursive: true });
fs.writeFileSync(path.join(ROOT, 'dist/artifact.html'), page);

const walk = (dir) =>
  fs.readdirSync(path.join(ROOT, dir), { withFileTypes: true }).flatMap((e) => {
    const rel = `${dir}/${e.name}`;
    return e.isDirectory() ? walk(rel) : [rel];
  });
const files = Object.fromEntries(walk('js').sort().map((f) => [f, f]));
fs.writeFileSync(path.join(ROOT, 'dist/artifact-files.json'), JSON.stringify(files, null, 2));

console.log(`dist/artifact.html: ${(page.length / 1024).toFixed(1)} KB · ${Object.keys(files).length} módulos JS`);
