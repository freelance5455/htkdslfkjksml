const messages = document.getElementById('messages');
const form = document.getElementById('chatForm');
const question = document.getElementById('question');

function say(text) {
  if (!('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'hi-IN';
  window.speechSynthesis.speak(utterance);
}
function addMessage(text) {
  messages.textContent += '\n\n' + text;
  messages.scrollTop = messages.scrollHeight;
}
function reply(q) {
  const s = q.toLowerCase();
  if (s.includes('नमस्ते') || s.includes('हेलो') || s.includes('hello')) return 'नमस्ते! मैं आपका JARVIS असिस्टेंट हूँ।';
  if (s.includes('समय') || s.includes('टाइम')) return 'सही समय देखने के लिए अपने फोन की घड़ी देखें।';
  if (s.includes('तुम कौन') || s.includes('नाम')) return 'मैं Spider JARVIS डेमो असिस्टेंट हूँ।';
  if (s.includes('मदद')) return 'आप मुझसे सवाल लिखकर पूछ सकते हैं या माइक बटन से बोल सकते हैं।';
  return 'मैंने आपका सवाल सुना: “' + q + '”। असली AI जवाब देने के लिए सुरक्षित AI API सर्वर जोड़ना होगा।';
}
form.addEventListener('submit', event => {
  event.preventDefault();
  const q = question.value.trim();
  if (!q) return;
  addMessage('आप: ' + q);
  const answer = reply(q);
  addMessage('JARVIS: ' + answer);
  question.value = '';
  say(answer);
});

document.getElementById('mic').addEventListener('click', () => {
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) {
    say('इस ब्राउज़र में आवाज पहचान उपलब्ध नहीं है। कृपया समर्थित ब्राउज़र में खोलें।');
    addMessage('JARVIS: इस ब्राउज़र में voice recognition उपलब्ध नहीं है।');
    return;
  }
  const recognition = new Recognition();
  recognition.lang = 'hi-IN';
  recognition.interimResults = false;
  recognition.onresult = event => {
    question.value = event.results[0][0].transcript;
    form.requestSubmit();
  };
  recognition.onerror = () => addMessage('JARVIS: माइक की अनुमति और इंटरनेट कनेक्शन जाँचें।');
  recognition.start();
});

document.getElementById('dial').addEventListener('click', () => { window.location.href = 'tel:'; });
document.getElementById('settings').addEventListener('click', () => {
  addMessage('JARVIS: फोन की सिस्टम सेटिंग्स खोलने के लिए APK में Android native integration चाहिए।');
  say('फोन की सिस्टम सेटिंग्स खोलने के लिए Android इंटीग्रेशन चाहिए।');
});
document.getElementById('browser').addEventListener('click', () => { window.open('https://www.google.com', '_blank', 'noopener'); });
