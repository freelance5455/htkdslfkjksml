/**
 * ADVANCE BUILDTRACK - Core Business & Construction Management Engine
 * Mobile-First, Multi-Tenant, Role-Based PWA Architecture
 */

// ==========================================================================
// 1. MULTI-LANGUAGE LOCALIZATION DICTIONARY
// ==========================================================================
const I18N = {
  en: {
    dashboard_title: "Construction Dashboard",
    dashboard_subtitle: "Real-time status of construction operations, cash flow & sites",
    btn_new_project: "New Project",
    btn_record_payment: "Record Payment",
    kpi_total_projects: "Total Projects",
    kpi_customers: "Customers",
    kpi_workers: "On-Site Workers",
    kpi_materials: "Materials",
    kpi_total_sales: "Total Sales",
    kpi_total_payments: "Payments Received",
    kpi_due_amount: "Outstanding Due",
    kpi_expenses: "Expenses Incurred",
    kpi_loans_emi: "Loans / EMI Balance",
    status_active: "Active",
    status_completed: "Done",
    status_planning: "Planning",
    status_in_progress: "In Progress",
    status_on_hold: "On Hold",
    present_today: "Present today",
    low_stock_warning: "Low Stock Alert",
    active_projects_status: "Active Projects Progress",
    financial_overview: "Financial Overview",
    recent_activities: "Recent Business Activities",
    projects_title: "Projects & Construction Sites",
    projects_subtitle: "Manage residential, commercial, and infrastructure builds",
    add_project: "Add Project",
    customers_title: "Customer Directory & Accounts",
    customers_subtitle: "Property buyers, corporate clients & site owners",
    add_customer: "Add Customer",
    workers_title: "Worker & Labor Management",
    workers_subtitle: "Contractors, masons, electricians, supervisors & attendance",
    mark_attendance: "Mark Today's Attendance",
    add_worker: "Add Worker",
    materials_title: "Material & Inventory Stock",
    materials_subtitle: "Cement, rebar steel, bricks, sand, tiles & stock alerts",
    add_material: "Add Material",
    sales_title: "Sales & Billing Records",
    sales_subtitle: "Material sales, unit bookings, contracts & auto-calculations",
    create_sale: "Create New Sale",
    payments_title: "Payments & Due Tracking",
    payments_subtitle: "Received settlements, payment modes & due auto-reconciliation",
    record_payment: "Record Payment",
    expenses_title: "Expense & Cost Management",
    expenses_subtitle: "Track project-wise direct costs, site fuel, machinery & overheads",
    add_expense: "Add Expense",
    loans_title: "Loans & EMI Schedules",
    loans_subtitle: "Commercial construction equipment loans & amortization",
    add_loan: "Add New Loan",
    documents_title: "Documents, Media & Blueprints",
    documents_subtitle: "CAD drawings, municipal sanction letters, tax receipts & contracts",
    upload_document: "Upload Document",
    reports_title: "Reports & Business Analytics",
    reports_subtitle: "Generate comprehensive audit reports, CSV downloads & print summaries",
    audit_title: "System Audit Log",
    audit_subtitle: "Immutable activity log of user logins, additions, edits, sales, and payments",
    backup_title: "Backup, Restore & Persistence",
    backup_subtitle: "Secure offline-first data management and JSON data portability",
    switch_role: "Switch Role / Demo Account",
    nav_dashboard: "Dashboard",
    nav_projects: "Projects",
    nav_customers: "Customers",
    nav_workers: "Workers & Labor",
    nav_materials: "Material Inventory",
    nav_sales: "Sales & Invoicing",
    nav_payments: "Payments & Dues",
    nav_expenses: "Expenses",
    nav_loans: "Loans & EMI",
    nav_documents: "Docs & Blueprints",
    nav_reports: "Reports & Analytics",
    nav_audit: "Audit Log",
    nav_backup: "Backup & Restore",
    btn_cancel: "Cancel",
    btn_save: "Save",
    btn_close: "Close",
    currency_symbol: "₹"
  },
  bn: {
    dashboard_title: "নির্মাণ ড্যাশবোর্ড",
    dashboard_subtitle: "নির্মাণ প্রকল্প, নগদ প্রবাহ এবং সাইটের রিয়েল-টাইম তথ্য",
    btn_new_project: "নতুন প্রকল্প",
    btn_record_payment: "পেমেন্ট রেকর্ড করুন",
    kpi_total_projects: "মোট প্রকল্প",
    kpi_customers: "গ্রাহকবৃন্দ",
    kpi_workers: "সাইট কর্মী",
    kpi_materials: "নির্মাণ সামগ্রী",
    kpi_total_sales: "মোট বিক্রয়",
    kpi_total_payments: "প্রাপ্ত পেমেন্ট",
    kpi_due_amount: "বকেয়া টাকা",
    kpi_expenses: "মোট খরচ",
    kpi_loans_emi: "ঋণ / ইএমআই ব্যালেন্স",
    status_active: "চলমান",
    status_completed: "সম্পন্ন",
    status_planning: "পরিকল্পনা",
    status_in_progress: "চলমান",
    status_on_hold: "স্থগিত",
    present_today: "আজ উপস্থিত",
    low_stock_warning: "কম মজুত সতর্কতা",
    active_projects_status: "চলমান প্রকল্পের অগ্রগতি",
    financial_overview: "আর্থিক সারসংক্ষেপ",
    recent_activities: "সাম্প্রতিক কার্যক্রম",
    projects_title: "প্রকল্প এবং সাইট",
    projects_subtitle: "আবাসিক ও বাণিজ্যিক নির্মাণ সাইট ব্যবস্থাপনা",
    add_project: "প্রকল্প যোগ করুন",
    customers_title: "গ্রাহক তালিকা ও অ্যাকাউন্ট",
    customers_subtitle: "সম্পত্তি ক্রেতা ও গ্রাহক তথ্য",
    add_customer: "গ্রাহক যোগ করুন",
    workers_title: "শ্রমিক ও কর্মী ব্যবস্থাপনা",
    workers_subtitle: "রাজমিস্ত্রি, ইলেকট্রিশিয়ান এবং দৈনিক উপস্থিতি",
    mark_attendance: "আজকের উপস্থিতি দিন",
    add_worker: "কর্মী যোগ করুন",
    materials_title: "উপকরণ ও ইনভেন্টরি",
    materials_subtitle: "সিমেন্ট, রড, ইট, বালির মজুত তথ্য",
    add_material: "উপকরণ যোগ করুন",
    sales_title: "বিক্রয় ও চালান",
    sales_subtitle: "উপাদান বিক্রয় এবং চুক্তি চালান",
    create_sale: "নতুন বিক্রয় তৈরি করুন",
    payments_title: "পেমেন্ট ও বকেয়া হিসাব",
    payments_subtitle: "প্রাপ্ত পেমেন্ট ও বকেয়া সমন্বয়",
    record_payment: "পেমেন্ট গ্রহণ করুন",
    expenses_title: "খরচ ব্যবস্থাপনা",
    expenses_subtitle: "সাইট খরচ, জ্বালানি, যন্ত্রপাতি ও বেতন",
    add_expense: "খরচ যোগ করুন",
    loans_title: "ঋণ ও ইএমআই সূচি",
    loans_subtitle: "ব্যবসায়িক ঋণ ও মাসিক কিস্তি",
    add_loan: "নতুন ঋণ যোগ করুন",
    documents_title: "নথিপত্র ও ব্লুপ্রিন্ট",
    documents_subtitle: "সিএডি অঙ্কন, অনুমোদন ও চুক্তিপত্র",
    upload_document: "নথি আপলোড করুন",
    reports_title: "রিপোর্ট ও বিশ্লেষণ",
    reports_subtitle: "সম্পূর্ণ রিপোর্ট ও সিএসভি ডাউনলোড",
    audit_title: "সিস্টেম অডিট লগ",
    audit_subtitle: "সকল পরিবর্তন ও লগইন কার্যক্রমের তালিকা",
    backup_title: "ব্যাকআপ ও রিস্টোর",
    backup_subtitle: "নিরাপদ অফলাইন ডেটা এবং ব্যাকআপ ফাইল",
    switch_role: "ভূমিকা পরিবর্তন করুন",
    nav_dashboard: "ড্যাশবোর্ড",
    nav_projects: "প্রকল্প",
    nav_customers: "গ্রাহক",
    nav_workers: "শ্রমিক",
    nav_materials: "উপকরণ",
    nav_sales: "বিক্রয়",
    nav_payments: "পেমেন্ট",
    nav_expenses: "খরচ",
    nav_loans: "ঋণ/ইএমআই",
    nav_documents: "নথিপত্র",
    nav_reports: "রিপোর্ট",
    nav_audit: "অডিট লগ",
    nav_backup: "ব্যাকআপ",
    btn_cancel: "বাতিল",
    btn_save: "সংরক্ষণ",
    btn_close: "বন্ধ",
    currency_symbol: "₹"
  },
  hi: {
    dashboard_title: "कंस्ट्रक्शन डैशबोर्ड",
    dashboard_subtitle: "निर्माण कार्यों, नकदी प्रवाह और साइटों की वास्तविक स्थिति",
    btn_new_project: "नया प्रोजेक्ट",
    btn_record_payment: "भुगतान दर्ज करें",
    kpi_total_projects: "कुल प्रोजेक्ट्स",
    kpi_customers: "कुल ग्राहक",
    kpi_workers: "साइट मजदूर",
    kpi_materials: "निर्माण सामग्री",
    kpi_total_sales: "कुल बिक्री",
    kpi_total_payments: "प्राप्त भुगतान",
    kpi_due_amount: "बकाया राशि",
    kpi_expenses: "कुल खर्चे",
    kpi_loans_emi: "ऋण / ईएमआई शेष",
    status_active: "सक्रिय",
    status_completed: "पूर्ण",
    status_planning: "योजना",
    status_in_progress: "प्रगति पर",
    status_on_hold: "रोका गया",
    present_today: "आज उपस्थित",
    low_stock_warning: "कम स्टॉक चेतावनी",
    active_projects_status: "प्रोजेक्ट प्रगति",
    financial_overview: "वित्तीय विवरण",
    recent_activities: "हाल की गतिविधियां",
    projects_title: "प्रोजेक्ट और निर्माण स्थल",
    projects_subtitle: "आवासीय और व्यावसायिक निर्माण स्थलों का प्रबंधन",
    add_project: "प्रोजेक्ट जोड़ें",
    customers_title: "ग्राहक डायरेक्टरी",
    customers_subtitle: "खरीदार, कॉर्पोरेट ग्राहक और खाते",
    add_customer: "ग्राहक जोड़ें",
    workers_title: "श्रमिक और मजदूर प्रबंधन",
    workers_subtitle: "मिस्त्री, इलेक्ट्रीशियन और दैनिक उपस्थिति",
    mark_attendance: "आज की हाजिरी लगाएं",
    add_worker: "श्रमिक जोड़ें",
    materials_title: "सामग्री और इन्वेंटरी",
    materials_subtitle: "सीमेंट, स्टील, ईंट, रेत का स्टॉक",
    add_material: "सामग्री जोड़ें",
    sales_title: "बिक्री और इनवॉइस",
    sales_subtitle: "सामग्री बिक्री व फ्लैट बुकिंग चालान",
    create_sale: "नई बिक्री बनाएं",
    payments_title: "भुगतान और बकाया ट्रैकिंग",
    payments_subtitle: "प्राप्त भुगतान और बकाया समायोजन",
    record_payment: "भुगतान दर्ज करें",
    expenses_title: "खर्च प्रबंधन",
    expenses_subtitle: "साइट खर्च, डीजल, मशीनरी और मजदूरी",
    add_expense: "खर्च जोड़ें",
    loans_title: "ऋण और ईएमआई शेड्यूल",
    loans_subtitle: "उपकरण लोन और मासिक किश्तें",
    add_loan: "नया लोन जोड़ें",
    documents_title: "दस्तावेज़ और नक्शे",
    documents_subtitle: "सीएडी मैप, नगर निगम स्वीकृति और अनुबंध",
    upload_document: "दस्तावेज़ अपलोड करें",
    reports_title: "रिपोर्ट और एनालिटिक्स",
    reports_subtitle: "पूर्ण वित्तीय रिपोर्ट और सीएसवी डाउनलोड",
    audit_title: "सिस्टम ऑडिट लॉग",
    audit_subtitle: "सभी उपयोगकर्ता गतिविधियों और रिकॉर्ड का इतिहास",
    backup_title: "बैकअप और रीस्टोर",
    backup_subtitle: "सुरक्षित डेटा बैकअप और जेसन पोर्टेबिलिटी",
    switch_role: "रोल बदलें",
    nav_dashboard: "डैशबोर्ड",
    nav_projects: "प्रोजेक्ट्स",
    nav_customers: "ग्राहक",
    nav_workers: "मजदूर",
    nav_materials: "सामग्री",
    nav_sales: "बिक्री",
    nav_payments: "भुगतान",
    nav_expenses: "खर्च",
    nav_loans: "लोन/EMI",
    nav_documents: "दस्तावेज़",
    nav_reports: "रिपोर्ट्स",
    nav_audit: "ऑडिट लॉग",
    nav_backup: "बैकअप",
    btn_cancel: "रद्द करें",
    btn_save: "सहेजें",
    btn_close: "बंद करें",
    currency_symbol: "₹"
  }
};

// ==========================================================================
// 2. DEMO SAMPLE DATABASE SEED
// ==========================================================================
const INITIAL_DB = {
  builders: [
    { id: "builder1", name: "Apex Infra Ltd", adminName: "Vikram Singhania", phone: "+91 98112 34567" },
    { id: "builder2", name: "Heritage Builders", adminName: "Karan Oberoi", phone: "+91 98223 45678" }
  ],
  customers: [
    { id: "cust-1", builderId: "builder1", name: "Mr. Rajesh Sharma", phone: "+91 98765 43210", email: "rajesh.sharma@example.com", address: "Flat 402, Royal Residency, Sector 45", creditScore: "A+" },
    { id: "cust-2", builderId: "builder1", name: "Mrs. Priya Mehta", phone: "+91 98980 11223", email: "priya.mehta@example.com", address: "Villa 12, Palm Meadows", creditScore: "A" },
    { id: "cust-3", builderId: "builder1", name: "Horizon Tech Logistics", phone: "+91 98334 55667", email: "procurement@horizonlogistics.in", address: "Plot 88, Industrial Corridor", creditScore: "B+" },
    { id: "cust-4", builderId: "builder2", name: "Sanjay Verma", phone: "+91 99112 88776", email: "sanjay@heritageclient.com", address: "Heritage Courtyard #5", creditScore: "A" }
  ],
  projects: [
    {
      id: "proj-1",
      builderId: "builder1",
      name: "Skyline Heights Phase 1",
      location: "Sector 45, Green Valley Expressway",
      customerId: "cust-1",
      status: "In Progress",
      progress: 68,
      startDate: "2025-04-10",
      endDate: "2026-12-30",
      budget: 18500000,
      spent: 12400000,
      assignedWorkers: ["w-1", "w-2", "w-5"],
      description: "Twin residential high-rise towers (G+14) with earthquake-resistant structure."
    },
    {
      id: "proj-2",
      builderId: "builder1",
      name: "Lotus Commercial Plaza",
      location: "Ring Road Business District",
      customerId: "cust-3",
      status: "In Progress",
      progress: 42,
      startDate: "2025-08-15",
      endDate: "2027-03-31",
      budget: 34000000,
      spent: 14200000,
      assignedWorkers: ["w-2", "w-3", "w-4"],
      description: "Modern glass-facade corporate tech park and retail arcade."
    },
    {
      id: "proj-3",
      builderId: "builder1",
      name: "Green Valley Luxury Villas",
      location: "Kharghar Hills View",
      customerId: "cust-2",
      status: "Planning",
      progress: 15,
      startDate: "2026-02-01",
      endDate: "2027-06-30",
      budget: 9500000,
      spent: 1420000,
      assignedWorkers: ["w-1", "w-4"],
      description: "8 G+2 contemporary smart villas with private pools."
    },
    {
      id: "proj-4",
      builderId: "builder2",
      name: "Heritage Royal Courtyard",
      location: "Old City Fort Road",
      customerId: "cust-4",
      status: "In Progress",
      progress: 80,
      startDate: "2025-01-10",
      endDate: "2026-10-15",
      budget: 12000000,
      spent: 9800000,
      assignedWorkers: ["w-6"],
      description: "Traditional stone architecture boutique suites."
    }
  ],
  workers: [
    { id: "w-1", builderId: "builder1", name: "Rameshwar Prasad", role: "Head Mason", phone: "+91 99201 10022", dailyRate: 950, projectId: "proj-1", statusToday: "Present", wagesPaid: 45600 },
    { id: "w-2", builderId: "builder1", name: "Sunil Verma", role: "Site Supervisor", phone: "+91 98111 22334", dailyRate: 1400, projectId: "proj-1", statusToday: "Present", wagesPaid: 72000 },
    { id: "w-3", builderId: "builder1", name: "Amit Patel", role: "Electrician", phone: "+91 97234 56789", dailyRate: 900, projectId: "proj-2", statusToday: "Present", wagesPaid: 36000 },
    { id: "w-4", builderId: "builder1", name: "Vikram Das", role: "Carpenter", phone: "+91 96123 45678", dailyRate: 850, projectId: "proj-2", statusToday: "Half-Day", wagesPaid: 31450 },
    { id: "w-5", builderId: "builder1", name: "Mohan Yadav", role: "General Laborer", phone: "+91 95111 88990", dailyRate: 650, projectId: "proj-1", statusToday: "Present", wagesPaid: 26000 },
    { id: "w-6", builderId: "builder2", name: "Deepak Rawat", role: "Site Supervisor", phone: "+91 98450 12345", dailyRate: 1300, projectId: "proj-4", statusToday: "Present", wagesPaid: 58000 }
  ],
  materials: [
    { id: "mat-1", builderId: "builder1", name: "UltraTech PPC Cement (50kg)", category: "Structural", unit: "Bags", qty: 1450, minQty: 200, purchasePrice: 380, sellingPrice: 420 },
    { id: "mat-2", builderId: "builder1", name: "TMT Rebar Fe550D Steel (12mm)", category: "Structural", unit: "Tons", qty: 28, minQty: 10, purchasePrice: 62000, sellingPrice: 68500 },
    { id: "mat-3", builderId: "builder1", name: "Red Clay Kiln Bricks", category: "Structural", unit: "Pcs", qty: 35000, minQty: 5000, purchasePrice: 8.5, sellingPrice: 10.5 },
    { id: "mat-4", builderId: "builder1", name: "Screened River Sand", category: "Aggregates", unit: "Cft", qty: 180, minQty: 250, purchasePrice: 48, sellingPrice: 60 }, // Low stock warning!
    { id: "mat-5", builderId: "builder1", name: "20mm Granite Aggregate (Grit)", category: "Aggregates", unit: "Cft", qty: 950, minQty: 200, purchasePrice: 38, sellingPrice: 46 },
    { id: "mat-6", builderId: "builder1", name: "Asian Paints Apex Ultima White", category: "Finishing", unit: "Liters", qty: 320, minQty: 50, purchasePrice: 310, sellingPrice: 380 },
    { id: "mat-7", builderId: "builder1", name: "Kajaria 600x600 Glazed Vitrified Tiles", category: "Finishing", unit: "Sq.Ft", qty: 45, minQty: 200, purchasePrice: 65, sellingPrice: 85 }, // Low stock!
    { id: "mat-8", builderId: "builder2", name: "Ambuja Cement 50kg", category: "Structural", unit: "Bags", qty: 800, minQty: 100, purchasePrice: 375, sellingPrice: 415 }
  ],
  sales: [
    { id: "inv-101", builderId: "builder1", invoiceNo: "INV-2026-001", date: "2026-01-15", customerId: "cust-1", projectId: "proj-1", itemDesc: "Flat 402 - 3rd Slab Milestone Booking", qty: 1, unitPrice: 3500000, totalAmount: 3500000, paidAmount: 2500000, dueAmount: 1000000 },
    { id: "inv-102", builderId: "builder1", invoiceNo: "INV-2026-002", date: "2026-02-04", customerId: "cust-2", projectId: "proj-3", itemDesc: "Villa 12 Foundation & Plinth Booking", qty: 1, unitPrice: 2000000, totalAmount: 2000000, paidAmount: 1800000, dueAmount: 200000 },
    { id: "inv-103", builderId: "builder1", invoiceNo: "INV-2026-003", date: "2026-02-20", customerId: "cust-3", projectId: "proj-2", itemDesc: "Direct Supply: 250 Bags UltraTech Cement", qty: 250, unitPrice: 420, totalAmount: 105000, paidAmount: 105000, dueAmount: 0 },
    { id: "inv-104", builderId: "builder2", invoiceNo: "INV-2026-004", date: "2026-01-28", customerId: "cust-4", projectId: "proj-4", itemDesc: "Suite #5 Second Installment", qty: 1, unitPrice: 1500000, totalAmount: 1500000, paidAmount: 1500000, dueAmount: 0 }
  ],
  payments: [
    { id: "pay-201", builderId: "builder1", receiptNo: "REC-8801", date: "2026-01-15", customerId: "cust-1", amount: 2500000, mode: "Bank Transfer (NEFT/RTGS)", refNo: "HDFC-N19827361", notes: "Slab booking NEFT transfer", customerRemainingDue: 1000000 },
    { id: "pay-202", builderId: "builder1", receiptNo: "REC-8802", date: "2026-02-04", customerId: "cust-2", amount: 1800000, mode: "Bank Transfer (NEFT/RTGS)", refNo: "ICICI-RTGS-99021", notes: "Plinth stage payment", customerRemainingDue: 200000 },
    { id: "pay-203", builderId: "builder1", receiptNo: "REC-8803", date: "2026-02-20", customerId: "cust-3", amount: 105000, mode: "UPI / QR", refNo: "UPI-402918239", notes: "Cement lot payment", customerRemainingDue: 0 },
    { id: "pay-204", builderId: "builder2", receiptNo: "REC-8804", date: "2026-01-28", customerId: "cust-4", amount: 1500000, mode: "Bank Transfer (NEFT/RTGS)", refNo: "SBI-RTGS-7728", notes: "Milestone payment", customerRemainingDue: 0 }
  ],
  expenses: [
    { id: "exp-301", builderId: "builder1", title: "Diesel fuel for JCB excavator & transit mixer", category: "Fuel & Machinery", projectId: "proj-1", amount: 24500, date: "2026-02-25", desc: "IOCL Petrol Pump invoice #9812" },
    { id: "exp-302", builderId: "builder1", title: "Site labor weekly muster payment", category: "Labor Wages", projectId: "proj-1", amount: 142000, date: "2026-02-28", desc: "Direct worker cash disbursal signed muster" },
    { id: "exp-303", builderId: "builder1", title: "Municipal site environmental inspection fee", category: "Permits & Legal", projectId: "proj-2", amount: 45000, date: "2026-02-14", desc: "Municipal receipt #PL-551" },
    { id: "exp-304", builderId: "builder1", title: "Site office broadband & electricals", category: "Office & Administration", projectId: "proj-1", amount: 6200, date: "2026-03-01", desc: "Monthly utility billing" },
    { id: "exp-305", builderId: "builder2", title: "Stone carving craftsman wages", category: "Labor Wages", projectId: "proj-4", amount: 75000, date: "2026-02-20", desc: "Heritage masonry artisan payout" }
  ],
  loans: [
    {
      id: "loan-401",
      builderId: "builder1",
      bank: "HDFC Commercial Infrastructure Loan",
      principal: 3000000,
      interestRate: 9.5,
      tenureMonths: 36,
      monthlyEmi: 96102,
      paidEmis: 8,
      remainingBalance: 2420000,
      disbursalDate: "2025-06-10",
      purpose: "Hydraulic Mobile Crane & Concrete Pump"
    },
    {
      id: "loan-402",
      builderId: "builder1",
      bank: "SBI Builder Working Capital Line",
      principal: 5000000,
      interestRate: 8.8,
      tenureMonths: 48,
      monthlyEmi: 123980,
      paidEmis: 12,
      remainingBalance: 3950000,
      disbursalDate: "2025-02-15",
      purpose: "Project Skyline Heights working capital"
    }
  ],
  documents: [
    { id: "doc-501", builderId: "builder1", title: "Skyline Phase 1 Municipal Sanction Drawing", category: "Blueprint", projectId: "proj-1", date: "2025-03-12", size: "4.8 MB", ext: "CAD/PDF" },
    { id: "doc-502", builderId: "builder1", title: "Fire Safety NOC Certificate", category: "Permit", projectId: "proj-1", date: "2025-04-02", size: "1.2 MB", ext: "PDF" },
    { id: "doc-503", builderId: "builder1", title: "Structural Steel Test Certificate (NABL)", category: "Permit", projectId: "proj-2", date: "2025-09-18", size: "850 KB", ext: "PDF" },
    { id: "doc-504", builderId: "builder1", title: "Customer Allotment Agreement - Rajesh Sharma", category: "Contract", projectId: "proj-1", date: "2026-01-15", size: "2.4 MB", ext: "PDF" }
  ],
  auditLogs: [
    { timestamp: "2026-03-01 10:15:20", user: "Vikram Singhania (Builder)", action: "LOGIN", details: "Signed into builder console from Android client", source: "Android App" },
    { timestamp: "2026-03-01 10:45:00", user: "Vikram Singhania (Builder)", action: "SALE_CREATED", details: "Invoice INV-2026-003 generated for Horizon Logistics", source: "Web/Android" },
    { timestamp: "2026-03-01 11:20:14", user: "Vikram Singhania (Builder)", action: "PAYMENT_RECORDED", details: "Receipt REC-8803 recorded (₹1,05,000 via UPI)", source: "Android App" },
    { timestamp: "2026-03-02 09:00:10", user: "System", action: "ATTENDANCE_MARKED", details: "Site daily muster logged: 4 Present, 1 Half-day", source: "System Automated" }
  ]
};

// ==========================================================================
// 3. STORAGE & REST API ABSTRACTION REPOSITORY
// ==========================================================================
class DataStore {
  static STORAGE_KEY = "advance_buildtrack_data_v1";

  static getDB() {
    try {
      const raw = localStorage.getItem(this.STORAGE_KEY);
      if (raw) {
        return JSON.parse(raw);
      }
    } catch (e) {
      console.warn("Could not parse stored DB, resetting to defaults", e);
    }
    this.saveDB(INITIAL_DB);
    return JSON.parse(JSON.stringify(INITIAL_DB));
  }

  static saveDB(data) {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
      console.error("LocalStorage save error", e);
    }
  }

  static resetToDemo() {
    this.saveDB(INITIAL_DB);
  }
}

/**
 * Future REST API Adapter Interface
 * When switching to a real PostgreSQL / Spring Boot / Node backend,
 * toggle USE_REST_API = true and update the endpoints below.
 */
class ApiAdapter {
  static USE_REST_API = false;
  static BASE_URL = "https://api.buildtrack.local/v1";

  static async logAudit(user, action, details) {
    const db = DataStore.getDB();
    const now = new Date();
    const ts = now.toISOString().replace('T', ' ').substring(0, 19);
    const entry = {
      timestamp: ts,
      user: user || "System",
      action: action,
      details: details,
      source: navigator.userAgent.includes("Android") ? "Android App" : "Web Client"
    };
    db.auditLogs.unshift(entry);
    if (db.auditLogs.length > 200) db.auditLogs.pop();
    DataStore.saveDB(db);
  }
}

// ==========================================================================
// 4. APPLICATION STATE & CONTROLLER
// ==========================================================================
const App = {
  currentLang: "en",
  currentRole: "BUILDER", // "ADMIN" | "BUILDER" | "CUSTOMER"
  currentSession: {
    userId: "user-vikram",
    name: "Vikram Singhania",
    builderId: "builder1",
    builderName: "Apex Infra Ltd",
    customerId: null
  },
  currentView: "dashboard",
  editingProject: null,
  editingCustomer: null,
  editingWorker: null,
  editingMaterial: null,
  activeDocBase64: null,

  init() {
    // 1. Language preference
    const savedLang = localStorage.getItem("advance_buildtrack_lang") || "en";
    this.setLanguage(savedLang, false);

    // 2. Load and verify Database
    const db = DataStore.getDB();

    // 3. Register DOM Events & Listeners
    this.setupEventListeners();

    // 4. Initial Render
    this.updateUserSessionUI();
    this.renderAll();

    // 5. Audit login
    ApiAdapter.logAudit(this.currentSession.name, "APP_LAUNCH", "Application initialized");
  },

  setupEventListeners() {
    // Top sidebar toggler
    const toggleBtn = document.getElementById("btn-sidebar-toggle");
    if (toggleBtn) {
      toggleBtn.addEventListener("click", () => this.toggleSidebar());
    }

    // Close sidebar
    const closeBtn = document.getElementById("btn-close-sidebar");
    if (closeBtn) {
      closeBtn.addEventListener("click", () => this.closeSidebar());
    }

    // Backdrop click
    const backdrop = document.getElementById("sidebar-backdrop");
    if (backdrop) {
      backdrop.addEventListener("click", () => this.closeSidebar());
    }

    // Language dropdown
    const langSelect = document.getElementById("select-language");
    if (langSelect) {
      langSelect.value = this.currentLang;
      langSelect.addEventListener("change", (e) => this.setLanguage(e.target.value));
    }

    // Role Dropdown Toggle
    const roleBtn = document.getElementById("btn-role-menu");
    const roleDropdown = document.getElementById("role-dropdown");
    if (roleBtn && roleDropdown) {
      roleBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        roleDropdown.classList.toggle("hidden");
      });
      document.addEventListener("click", () => {
        roleDropdown.classList.add("hidden");
      });
    }
  },

  // ========================================================================
  // NAVIGATION & VIEW SWITCHING
  // ========================================================================
  navigateTo(viewId) {
    this.currentView = viewId;

    // Update main views
    const views = document.querySelectorAll(".content-view");
    views.forEach(v => v.classList.remove("active"));
    const target = document.getElementById(`view-${viewId}`);
    if (target) target.classList.add("active");

    // Update sidebar nav items
    const navItems = document.querySelectorAll(".sidebar-nav .nav-item");
    navItems.forEach(item => {
      if (item.getAttribute("data-view") === viewId) {
        item.classList.add("active");
      } else {
        item.classList.remove("active");
      }
    });

    // Update bottom nav items
    const bNavItems = document.querySelectorAll(".mobile-bottom-nav .b-nav-item");
    bNavItems.forEach(item => {
      if (item.getAttribute("data-view") === viewId) {
        item.classList.add("active");
      } else {
        item.classList.remove("active");
      }
    });

    this.closeSidebar();
    window.scrollTo({ top: 0, behavior: "smooth" });

    // Trigger dedicated view re-render
    if (viewId === "dashboard") this.renderDashboard();
    if (viewId === "projects") this.renderProjects();
    if (viewId === "customers") this.renderCustomers();
    if (viewId === "workers") this.renderWorkers();
    if (viewId === "materials") this.renderMaterials();
    if (viewId === "sales") this.renderSales();
    if (viewId === "payments") this.renderPayments();
    if (viewId === "expenses") this.renderExpenses();
    if (viewId === "loans") this.renderLoans();
    if (viewId === "documents") this.renderDocuments();
    if (viewId === "audit") this.renderAuditLogs();
  },

  toggleSidebar() {
    const sidebar = document.getElementById("app-sidebar");
    const backdrop = document.getElementById("sidebar-backdrop");
    if (sidebar && backdrop) {
      const isOpen = sidebar.classList.contains("open");
      if (isOpen) {
        sidebar.classList.remove("open");
        backdrop.classList.add("hidden");
      } else {
        sidebar.classList.add("open");
        backdrop.classList.remove("hidden");
      }
    }
  },

  closeSidebar() {
    const sidebar = document.getElementById("app-sidebar");
    const backdrop = document.getElementById("sidebar-backdrop");
    if (sidebar) sidebar.classList.remove("open");
    if (backdrop) backdrop.classList.add("hidden");
  },

  // ========================================================================
  // ROLE & TENANT MANAGEMENT
  // ========================================================================
  switchAccount(accountKey) {
    if (accountKey === "admin") {
      this.currentRole = "ADMIN";
      this.currentSession = {
        userId: "user-admin",
        name: "Administrator",
        builderId: null, // access to all builders
        builderName: "System Master View",
        customerId: null
      };
    } else if (accountKey === "builder1") {
      this.currentRole = "BUILDER";
      this.currentSession = {
        userId: "user-vikram",
        name: "Vikram Singhania",
        builderId: "builder1",
        builderName: "Apex Infra Ltd",
        customerId: null
      };
    } else if (accountKey === "builder2") {
      this.currentRole = "BUILDER";
      this.currentSession = {
        userId: "user-karan",
        name: "Karan Oberoi",
        builderId: "builder2",
        builderName: "Heritage Builders",
        customerId: null
      };
    } else if (accountKey === "customer") {
      this.currentRole = "CUSTOMER";
      this.currentSession = {
        userId: "user-rajesh",
        name: "Rajesh Sharma",
        builderId: "builder1",
        builderName: "Apex Infra Ltd",
        customerId: "cust-1" // Mr. Rajesh Sharma
      };
    }

    ApiAdapter.logAudit(this.currentSession.name, "ROLE_SWITCH", `Switched to ${this.currentRole} view`);
    this.updateUserSessionUI();
    this.renderAll();
    this.showToast(`Switched to ${this.currentRole}: ${this.currentSession.name}`, "info");
    this.navigateTo("dashboard");
  },

  updateUserSessionUI() {
    const roleBadge = document.getElementById("badge-current-role");
    const userDisplay = document.getElementById("txt-user-display");
    const tenantName = document.getElementById("txt-tenant-name");
    const sidebarAvatar = document.getElementById("sidebar-user-avatar");
    const sidebarUserName = document.getElementById("sidebar-user-name");
    const sidebarRole = document.getElementById("sidebar-user-role");
    const roleNotice = document.getElementById("role-notice-banner");
    const txtRoleNotice = document.getElementById("txt-role-notice");

    if (roleBadge) roleBadge.textContent = this.currentRole;
    if (userDisplay) userDisplay.textContent = this.currentSession.name;
    if (tenantName) tenantName.textContent = this.currentSession.builderName;
    if (sidebarAvatar) sidebarAvatar.textContent = this.currentSession.name.charAt(0);
    if (sidebarUserName) sidebarUserName.textContent = this.currentSession.name;
    if (sidebarRole) sidebarRole.textContent = `${this.currentRole} • ${this.currentSession.builderName}`;

    // Customer View-Only Notice & Controls hiding
    const isCustomer = this.currentRole === "CUSTOMER";
    if (roleNotice) {
      if (isCustomer) {
        roleNotice.classList.remove("hidden");
        txtRoleNotice.textContent = "Customer View-Only Access: Viewing status for Rajesh Sharma (Skyline Heights Flat 402). Actions restricted.";
      } else {
        roleNotice.classList.add("hidden");
      }
    }

    // Toggle visibility of mutating action buttons for customer
    const mutateButtons = [
      "btn-quick-new-project", "btn-quick-record-payment", "btn-action-add-project",
      "btn-action-add-customer", "btn-action-add-worker", "btn-action-attendance",
      "btn-action-add-material", "btn-action-add-sale", "btn-action-add-payment",
      "btn-action-add-expense", "btn-action-add-loan", "btn-action-upload-doc"
    ];

    mutateButtons.forEach(id => {
      const btn = document.getElementById(id);
      if (btn) {
        if (isCustomer) {
          btn.style.display = "none";
        } else {
          btn.style.display = "inline-flex";
        }
      }
    });
  },

  // Helper to filter data by current builder/customer tenancy
  filterByTenancy(items) {
    if (this.currentRole === "ADMIN") {
      return items; // Admin sees all data
    }
    if (this.currentRole === "CUSTOMER") {
      // Customer sees items related to their customerId or assigned projects
      return items.filter(item => {
        if (item.customerId) return item.customerId === this.currentSession.customerId;
        if (item.assignedWorkers) return item.customerId === this.currentSession.customerId;
        return item.builderId === this.currentSession.builderId;
      });
    }
    // Builder sees only their builder's data
    return items.filter(item => item.builderId === this.currentSession.builderId);
  },

  // ========================================================================
  // 5. LOCALIZATION & TRANSLATION SYSTEM
  // ========================================================================
  setLanguage(lang, renderNow = true) {
    if (!I18N[lang]) lang = "en";
    this.currentLang = lang;
    localStorage.setItem("advance_buildtrack_lang", lang);

    const dict = I18N[lang];
    document.querySelectorAll("[data-i18n]").forEach(el => {
      const key = el.getAttribute("data-i18n");
      if (dict[key]) {
        el.textContent = dict[key];
      }
    });

    const langSelect = document.getElementById("select-language");
    if (langSelect) langSelect.value = lang;

    if (renderNow) {
      this.renderAll();
      this.showToast(`Language changed to ${lang === 'bn' ? 'বাংলা' : lang === 'hi' ? 'हिन्दी' : 'English'}`);
    }
  },

  t(key) {
    return I18N[this.currentLang][key] || I18N['en'][key] || key;
  },

  formatCurrency(amount) {
    const num = Number(amount) || 0;
    return "₹" + num.toLocaleString('en-IN');
  },

  // ========================================================================
  // 6. RENDERERS
  // ========================================================================
  renderAll() {
    this.renderDashboard();
    this.renderProjects();
    this.renderCustomers();
    this.renderWorkers();
    this.renderMaterials();
    this.renderSales();
    this.renderPayments();
    this.renderExpenses();
    this.renderLoans();
    this.renderDocuments();
    this.renderAuditLogs();
  },

  renderDashboard() {
    const db = DataStore.getDB();
    const projects = this.filterByTenancy(db.projects);
    const customers = this.filterByTenancy(db.customers);
    const workers = this.filterByTenancy(db.workers);
    const materials = this.filterByTenancy(db.materials);
    const sales = this.filterByTenancy(db.sales);
    const payments = this.filterByTenancy(db.payments);
    const expenses = this.filterByTenancy(db.expenses);
    const loans = this.filterByTenancy(db.loans);

    // KPI 1: Projects
    const totalProjects = projects.length;
    const activeProjects = projects.filter(p => p.status === "In Progress").length;
    const completedProjects = projects.filter(p => p.status === "Completed").length;
    document.getElementById("kpi-total-projects").textContent = totalProjects;
    document.getElementById("kpi-active-projects").textContent = activeProjects;
    document.getElementById("kpi-completed-projects").textContent = completedProjects;
    document.getElementById("badge-projects-count").textContent = totalProjects;

    // KPI 2: Customers
    document.getElementById("kpi-total-customers").textContent = customers.length;
    document.getElementById("kpi-active-clients").textContent = customers.length;

    // KPI 3: Workers
    const presentWorkers = workers.filter(w => w.statusToday === "Present" || w.statusToday === "Half-Day").length;
    document.getElementById("kpi-total-workers").textContent = workers.length;
    document.getElementById("kpi-present-workers").textContent = presentWorkers;

    // KPI 4: Materials & Low Stock
    const lowStockMaterials = materials.filter(m => m.qty <= m.minQty);
    document.getElementById("kpi-total-materials").textContent = materials.length;
    document.getElementById("kpi-low-stock-count").textContent = lowStockMaterials.length;

    // KPI 5 & 6 & 7: Financial Totals
    const totalSales = sales.reduce((acc, s) => acc + (Number(s.totalAmount) || 0), 0);
    const totalPayments = payments.reduce((acc, p) => acc + (Number(p.amount) || 0), 0);
    const totalDue = Math.max(0, totalSales - totalPayments);
    const totalExpenses = expenses.reduce((acc, e) => acc + (Number(e.amount) || 0), 0);
    const totalLoanBal = loans.reduce((acc, l) => acc + (Number(l.remainingBalance) || 0), 0);

    document.getElementById("kpi-total-sales").textContent = this.formatCurrency(totalSales);
    document.getElementById("kpi-total-payments").textContent = this.formatCurrency(totalPayments);
    document.getElementById("kpi-outstanding-due").textContent = this.formatCurrency(totalDue);
    document.getElementById("kpi-total-expenses").textContent = this.formatCurrency(totalExpenses);
    document.getElementById("kpi-loans-balance").textContent = this.formatCurrency(totalLoanBal);
    document.getElementById("kpi-active-loans-count").textContent = loans.length;

    // Cashflow Bars
    document.getElementById("cf-sales-amount").textContent = this.formatCurrency(totalSales);
    document.getElementById("cf-payments-amount").textContent = this.formatCurrency(totalPayments);
    document.getElementById("cf-due-amount").textContent = this.formatCurrency(totalDue);
    document.getElementById("cf-expenses-amount").textContent = this.formatCurrency(totalExpenses);

    const maxFinance = Math.max(totalSales, 1);
    document.getElementById("bar-cf-sales").style.width = "100%";
    document.getElementById("bar-cf-payments").style.width = `${Math.min(100, (totalPayments / maxFinance) * 100)}%`;
    document.getElementById("bar-cf-due").style.width = `${Math.min(100, (totalDue / maxFinance) * 100)}%`;
    document.getElementById("bar-cf-expenses").style.width = `${Math.min(100, (totalExpenses / maxFinance) * 100)}%`;

    const collectionRate = totalSales > 0 ? Math.round((totalPayments / totalSales) * 100) : 100;
    document.getElementById("cf-collection-rate").textContent = `${collectionRate}%`;

    const netMargin = totalSales > 0 ? Math.round(((totalSales - totalExpenses) / totalSales) * 100) : 0;
    document.getElementById("cf-net-margin").textContent = `${netMargin}%`;

    // Active Project Progress List
    const progressList = document.getElementById("dashboard-project-progress-list");
    if (progressList) {
      progressList.innerHTML = "";
      const activeList = projects.slice(0, 4);
      if (activeList.length === 0) {
        progressList.innerHTML = `<p class="text-muted">No projects found.</p>`;
      } else {
        activeList.forEach(p => {
          const div = document.createElement("div");
          div.className = "proj-progress-item";
          div.innerHTML = `
            <div class="proj-prog-header">
              <span class="proj-name-txt">${p.name}</span>
              <span class="proj-pct-txt">${p.progress}%</span>
            </div>
            <div class="progress-track">
              <div class="progress-fill bg-amber" style="width: ${p.progress}%;"></div>
            </div>
          `;
          progressList.appendChild(div);
        });
      }
    }

    // Recent Activities Feed
    const actFeed = document.getElementById("dashboard-recent-activities");
    if (actFeed) {
      actFeed.innerHTML = "";
      const recent = db.auditLogs.slice(0, 5);
      recent.forEach(a => {
        const item = document.createElement("div");
        item.className = "activity-item";
        item.innerHTML = `
          <div class="act-bullet"></div>
          <div class="act-content">
            <div class="act-desc"><b>${a.action.replace('_', ' ')}</b>: ${a.details}</div>
            <div class="act-meta">
              <span>${a.timestamp}</span> • <span>${a.user}</span>
            </div>
          </div>
        `;
        actFeed.appendChild(item);
      });
    }

    // Financial Banner in Payments view
    const bannerCollected = document.getElementById("banner-total-collected");
    const bannerDue = document.getElementById("banner-total-due");
    if (bannerCollected) bannerCollected.textContent = this.formatCurrency(totalPayments);
    if (bannerDue) bannerDue.textContent = this.formatCurrency(totalDue);
  },

  renderProjects() {
    const db = DataStore.getDB();
    let projects = this.filterByTenancy(db.projects);

    const search = (document.getElementById("filter-projects-search")?.value || "").toLowerCase();
    const statusFilter = document.getElementById("filter-projects-status")?.value || "ALL";

    if (search) {
      projects = projects.filter(p => p.name.toLowerCase().includes(search) || p.location.toLowerCase().includes(search));
    }
    if (statusFilter !== "ALL") {
      projects = projects.filter(p => p.status === statusFilter);
    }

    const grid = document.getElementById("projects-grid");
    if (!grid) return;
    grid.innerHTML = "";

    if (projects.length === 0) {
      grid.innerHTML = `<div class="card p-4 text-center text-muted w-full">No matching projects found.</div>`;
      return;
    }

    projects.forEach(p => {
      const card = document.createElement("div");
      card.className = "project-card";
      const statusClass = `status-${p.status.toLowerCase().replace(/\s+/g, '')}`;
      const customer = db.customers.find(c => c.id === p.customerId);
      const isCustomer = this.currentRole === "CUSTOMER";

      card.innerHTML = `
        <div class="p-card-header">
          <div>
            <div class="p-card-title">${p.name}</div>
            <div class="p-card-location">
              <svg class="svg-icon-xs" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
              ${p.location}
            </div>
          </div>
          <span class="status-pill ${statusClass}">${p.status}</span>
        </div>

        <div class="proj-progress-item">
          <div class="proj-prog-header">
            <span>Progress</span>
            <span class="font-bold text-amber">${p.progress}%</span>
          </div>
          <div class="progress-track">
            <div class="progress-fill bg-amber" style="width: ${p.progress}%;"></div>
          </div>
        </div>

        <div class="p-meta-grid">
          <div class="p-meta-item">
            <span>Client / Buyer</span>
            <strong>${customer ? customer.name : 'Unassigned'}</strong>
          </div>
          <div class="p-meta-item">
            <span>Budget</span>
            <strong class="currency">${this.formatCurrency(p.budget)}</strong>
          </div>
          <div class="p-meta-item">
            <span>Start Date</span>
            <strong>${p.startDate}</strong>
          </div>
          <div class="p-meta-item">
            <span>Target End</span>
            <strong>${p.endDate}</strong>
          </div>
        </div>

        <div class="p-card-footer">
          <span class="text-muted" style="font-size:11px;">Site Workers: ${(p.assignedWorkers || []).length} assigned</span>
          <div class="actions">
            ${!isCustomer ? `
              <button class="btn btn-sm btn-outline" onclick="App.editProject('${p.id}')">Edit</button>
              <button class="btn btn-sm btn-text text-danger" onclick="App.deleteProject('${p.id}')">Delete</button>
            ` : `<span class="badge-pill bg-blue-soft text-blue">Active Contract</span>`}
          </div>
        </div>
      `;
      grid.appendChild(card);
    });
  },

  renderCustomers() {
    const db = DataStore.getDB();
    let customers = this.filterByTenancy(db.customers);
    const search = (document.getElementById("filter-customers-search")?.value || "").toLowerCase();

    if (search) {
      customers = customers.filter(c => c.name.toLowerCase().includes(search) || c.phone.toLowerCase().includes(search) || (c.email && c.email.toLowerCase().includes(search)));
    }

    const tbody = document.getElementById("tbody-customers");
    if (!tbody) return;
    tbody.innerHTML = "";

    if (customers.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" class="text-center text-muted">No customers found.</td></tr>`;
      return;
    }

    customers.forEach(c => {
      // Calculate customer financial totals
      const custSales = db.sales.filter(s => s.customerId === c.id);
      const custPayments = db.payments.filter(p => p.customerId === c.id);
      const totalBilled = custSales.reduce((sum, s) => sum + (Number(s.totalAmount) || 0), 0);
      const totalPaid = custPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
      const due = Math.max(0, totalBilled - totalPaid);

      const custProjects = db.projects.filter(p => p.customerId === c.id).map(p => p.name).join(", ") || "None";
      const isCustomer = this.currentRole === "CUSTOMER";

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>
          <strong>${c.name}</strong>
          <div class="text-muted" style="font-size:11px;">${c.address || ''}</div>
        </td>
        <td>
          <div>${c.phone}</div>
          <div class="text-muted" style="font-size:11px;">${c.email || ''}</div>
        </td>
        <td><span class="badge-pill bg-blue-soft text-blue">${custProjects}</span></td>
        <td class="currency font-bold">${this.formatCurrency(totalBilled)}</td>
        <td class="currency text-success font-bold">${this.formatCurrency(totalPaid)}</td>
        <td class="currency text-danger font-bold">${this.formatCurrency(due)}</td>
        <td><span class="badge-pill bg-emerald-soft text-emerald font-bold">${c.creditScore || 'A'}</span></td>
        <td>
          <button class="btn btn-sm btn-outline" onclick="App.viewCustomerLedger('${c.id}')">Profile / Dues</button>
          ${!isCustomer ? `
            <button class="btn btn-sm btn-text text-danger" onclick="App.deleteCustomer('${c.id}')">✕</button>
          ` : ''}
        </td>
      `;
      tbody.appendChild(tr);
    });
  },

  renderWorkers() {
    const db = DataStore.getDB();
    let workers = this.filterByTenancy(db.workers);
    const search = (document.getElementById("filter-workers-search")?.value || "").toLowerCase();
    const roleFilter = document.getElementById("filter-workers-role")?.value || "ALL";

    if (search) {
      workers = workers.filter(w => w.name.toLowerCase().includes(search) || w.role.toLowerCase().includes(search) || w.phone.includes(search));
    }
    if (roleFilter !== "ALL") {
      workers = workers.filter(w => w.role === roleFilter);
    }

    const tbody = document.getElementById("tbody-workers");
    if (!tbody) return;
    tbody.innerHTML = "";

    if (workers.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" class="text-center text-muted">No workers found.</td></tr>`;
      return;
    }

    const isCustomer = this.currentRole === "CUSTOMER";

    workers.forEach(w => {
      const proj = db.projects.find(p => p.id === w.projectId);
      const statusColor = w.statusToday === "Present" ? "bg-emerald-soft text-emerald" : w.statusToday === "Half-Day" ? "bg-amber-soft text-amber" : "bg-danger-soft text-danger";

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td><strong>${w.name}</strong></td>
        <td><span class="badge-pill bg-slate text-white">${w.role}</span></td>
        <td>${w.phone || '-'}</td>
        <td class="currency">${this.formatCurrency(w.dailyRate)}/day</td>
        <td>${proj ? proj.name : 'Floating / Unassigned'}</td>
        <td><span class="badge-pill ${statusColor}">${w.statusToday || 'Present'}</span></td>
        <td class="currency text-success">${this.formatCurrency(w.wagesPaid || 0)}</td>
        <td>
          ${!isCustomer ? `
            <button class="btn btn-sm btn-outline" onclick="App.editWorker('${w.id}')">Edit</button>
            <button class="btn btn-sm btn-text text-danger" onclick="App.deleteWorker('${w.id}')">✕</button>
          ` : `<span class="text-muted">-</span>`}
        </td>
      `;
      tbody.appendChild(tr);
    });
  },

  renderMaterials() {
    const db = DataStore.getDB();
    let materials = this.filterByTenancy(db.materials);
    const search = (document.getElementById("filter-materials-search")?.value || "").toLowerCase();
    const catFilter = document.getElementById("filter-materials-category")?.value || "ALL";

    if (search) {
      materials = materials.filter(m => m.name.toLowerCase().includes(search));
    }
    if (catFilter !== "ALL") {
      materials = materials.filter(m => m.category === catFilter);
    }

    const tbody = document.getElementById("tbody-materials");
    if (!tbody) return;
    tbody.innerHTML = "";

    if (materials.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" class="text-center text-muted">No materials found.</td></tr>`;
      return;
    }

    const isCustomer = this.currentRole === "CUSTOMER";

    materials.forEach(m => {
      const isLowStock = m.qty <= m.minQty;
      const statusPill = isLowStock 
        ? `<span class="badge-pill bg-danger-soft text-danger font-bold">⚠️ Low Stock (${m.qty})</span>`
        : `<span class="badge-pill bg-emerald-soft text-emerald font-bold">In Stock</span>`;

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td><strong>${m.name}</strong></td>
        <td><span class="badge-pill bg-blue-soft text-blue">${m.category}</span></td>
        <td class="font-bold ${isLowStock ? 'text-danger' : ''}">${m.qty}</td>
        <td>${m.unit}</td>
        <td class="currency">${this.formatCurrency(m.purchasePrice)}</td>
        <td class="currency">${this.formatCurrency(m.sellingPrice)}</td>
        <td>${statusPill}</td>
        <td>
          ${!isCustomer ? `
            <button class="btn btn-sm btn-outline" onclick="App.editMaterial('${m.id}')">Edit</button>
            <button class="btn btn-sm btn-text text-danger" onclick="App.deleteMaterial('${m.id}')">✕</button>
          ` : `<span class="text-muted">-</span>`}
        </td>
      `;
      tbody.appendChild(tr);
    });
  },

  renderSales() {
    const db = DataStore.getDB();
    let sales = this.filterByTenancy(db.sales);
    const search = (document.getElementById("filter-sales-search")?.value || "").toLowerCase();

    if (search) {
      sales = sales.filter(s => s.invoiceNo.toLowerCase().includes(search) || (s.itemDesc && s.itemDesc.toLowerCase().includes(search)));
    }

    const tbody = document.getElementById("tbody-sales");
    if (!tbody) return;
    tbody.innerHTML = "";

    if (sales.length === 0) {
      tbody.innerHTML = `<tr><td colspan="9" class="text-center text-muted">No sales invoices found.</td></tr>`;
      return;
    }

    sales.forEach(s => {
      const customer = db.customers.find(c => c.id === s.customerId);
      const proj = db.projects.find(p => p.id === s.projectId);

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td><strong>${s.invoiceNo}</strong></td>
        <td>${s.date}</td>
        <td>${customer ? customer.name : 'Unknown'}</td>
        <td>
          <strong>${s.itemDesc || 'Item Sale'}</strong>
          <div class="text-muted" style="font-size:11px;">${proj ? proj.name : ''}</div>
        </td>
        <td>${s.qty}</td>
        <td class="currency font-bold">${this.formatCurrency(s.totalAmount)}</td>
        <td class="currency text-success">${this.formatCurrency(s.paidAmount)}</td>
        <td class="currency text-danger font-bold">${this.formatCurrency(s.dueAmount)}</td>
        <td>
          <button class="btn btn-sm btn-outline" onclick="App.viewSaleInvoice('${s.id}')">View Invoice</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  },

  renderPayments() {
    const db = DataStore.getDB();
    let payments = this.filterByTenancy(db.payments);
    const search = (document.getElementById("filter-payments-search")?.value || "").toLowerCase();

    if (search) {
      payments = payments.filter(p => p.receiptNo.toLowerCase().includes(search) || (p.refNo && p.refNo.toLowerCase().includes(search)));
    }

    const tbody = document.getElementById("tbody-payments");
    if (!tbody) return;
    tbody.innerHTML = "";

    if (payments.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" class="text-center text-muted">No payment records found.</td></tr>`;
      return;
    }

    payments.forEach(p => {
      const customer = db.customers.find(c => c.id === p.customerId);

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td><strong>${p.receiptNo}</strong></td>
        <td>${p.date}</td>
        <td>${customer ? customer.name : 'Unknown'}</td>
        <td><span class="badge-pill bg-purple-soft text-purple font-bold">${p.mode}</span></td>
        <td class="font-mono" style="font-size:12px;">${p.refNo || '-'}</td>
        <td class="currency text-success font-bold">${this.formatCurrency(p.amount)}</td>
        <td class="currency text-danger">${this.formatCurrency(p.customerRemainingDue || 0)}</td>
        <td>
          <button class="btn btn-sm btn-outline" onclick="App.viewPaymentReceipt('${p.id}')">Receipt</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  },

  renderExpenses() {
    const db = DataStore.getDB();
    let expenses = this.filterByTenancy(db.expenses);
    const search = (document.getElementById("filter-expenses-search")?.value || "").toLowerCase();
    const catFilter = document.getElementById("filter-expenses-category")?.value || "ALL";

    if (search) {
      expenses = expenses.filter(e => e.title.toLowerCase().includes(search) || (e.desc && e.desc.toLowerCase().includes(search)));
    }
    if (catFilter !== "ALL") {
      expenses = expenses.filter(e => e.category === catFilter);
    }

    const tbody = document.getElementById("tbody-expenses");
    if (!tbody) return;
    tbody.innerHTML = "";

    if (expenses.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted">No expense records found.</td></tr>`;
      return;
    }

    const isCustomer = this.currentRole === "CUSTOMER";

    expenses.forEach(e => {
      const proj = db.projects.find(p => p.id === e.projectId);

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${e.date}</td>
        <td><span class="badge-pill bg-slate text-white">${e.category}</span></td>
        <td>${proj ? proj.name : 'General Site Expense'}</td>
        <td>
          <strong>${e.title}</strong>
          <div class="text-muted" style="font-size:11px;">${e.desc || ''}</div>
        </td>
        <td class="currency font-bold">${this.formatCurrency(e.amount)}</td>
        <td>
          ${!isCustomer ? `
            <button class="btn btn-sm btn-text text-danger" onclick="App.deleteExpense('${e.id}')">✕</button>
          ` : `<span class="text-muted">-</span>`}
        </td>
      `;
      tbody.appendChild(tr);
    });
  },

  renderLoans() {
    const db = DataStore.getDB();
    const loans = this.filterByTenancy(db.loans);
    const grid = document.getElementById("loans-cards-grid");
    if (!grid) return;
    grid.innerHTML = "";

    if (loans.length === 0) {
      grid.innerHTML = `<div class="card p-4 text-center text-muted w-full">No active loans or EMI schedules.</div>`;
      return;
    }

    const isCustomer = this.currentRole === "CUSTOMER";

    loans.forEach(l => {
      const card = document.createElement("div");
      card.className = "card p-4";
      const totalRepayable = l.monthlyEmi * l.tenureMonths;
      const repaidSoFar = l.monthlyEmi * l.paidEmis;
      const progressPct = Math.round((repaidSoFar / totalRepayable) * 100);

      card.innerHTML = `
        <div class="card-header" style="padding:0 0 12px 0;">
          <div>
            <h3 class="card-title">${l.bank}</h3>
            <span class="card-hint">${l.purpose || 'Capital Expenditure'}</span>
          </div>
          <span class="badge-pill bg-indigo text-white font-bold">${l.interestRate}% p.a.</span>
        </div>
        <div class="card-body" style="padding:12px 0;">
          <div class="p-meta-grid">
            <div class="p-meta-item">
              <span>Principal Amount</span>
              <strong class="currency">${this.formatCurrency(l.principal)}</strong>
            </div>
            <div class="p-meta-item">
              <span>Monthly EMI</span>
              <strong class="currency text-danger">${this.formatCurrency(l.monthlyEmi)}</strong>
            </div>
            <div class="p-meta-item">
              <span>Remaining Balance</span>
              <strong class="currency text-amber">${this.formatCurrency(l.remainingBalance)}</strong>
            </div>
            <div class="p-meta-item">
              <span>Tenure Progress</span>
              <strong>${l.paidEmis} / ${l.tenureMonths} Months (${progressPct}%)</strong>
            </div>
          </div>
          <div class="progress-track mt-4">
            <div class="progress-fill bg-indigo" style="width: ${progressPct}%;"></div>
          </div>
          <div class="mt-4 flex justify-between align-center" style="display:flex; justify-content:space-between; align-items:center;">
            <span class="text-muted" style="font-size:12px;">Disbursed: ${l.disbursalDate || 'Active'}</span>
            ${!isCustomer ? `
              <button class="btn btn-sm btn-primary" onclick="App.payNextEmi('${l.id}')">Pay Next EMI</button>
            ` : ''}
          </div>
        </div>
      `;
      grid.appendChild(card);
    });
  },

  renderDocuments() {
    const db = DataStore.getDB();
    let docs = this.filterByTenancy(db.documents);
    const search = (document.getElementById("filter-docs-search")?.value || "").toLowerCase();
    const catFilter = document.getElementById("filter-docs-category")?.value || "ALL";

    if (search) {
      docs = docs.filter(d => d.title.toLowerCase().includes(search));
    }
    if (catFilter !== "ALL") {
      docs = docs.filter(d => d.category === catFilter);
    }

    const grid = document.getElementById("documents-grid");
    if (!grid) return;
    grid.innerHTML = "";

    if (docs.length === 0) {
      grid.innerHTML = `<div class="card p-4 text-center text-muted w-full">No documents found.</div>`;
      return;
    }

    docs.forEach(d => {
      const proj = db.projects.find(p => p.id === d.projectId);
      const card = document.createElement("div");
      card.className = "doc-card";
      card.innerHTML = `
        <div class="doc-preview">
          <svg class="svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
        </div>
        <div class="doc-title">${d.title}</div>
        <div class="text-muted" style="font-size:11px;">
          <span>${d.category}</span> • <span>${d.size}</span>
          ${proj ? `<div>Site: ${proj.name}</div>` : ''}
        </div>
        <div style="display:flex; justify-content:space-between; margin-top:8px;">
          <button class="btn btn-sm btn-outline" onclick="App.previewDocument('${d.title}')">View</button>
          <button class="btn btn-sm btn-secondary" onclick="App.downloadDocument('${d.title}')">Download</button>
        </div>
      `;
      grid.appendChild(card);
    });
  },

  renderAuditLogs() {
    const db = DataStore.getDB();
    const tbody = document.getElementById("tbody-audit");
    if (!tbody) return;
    tbody.innerHTML = "";

    const logs = db.auditLogs || [];
    if (logs.length === 0) {
      tbody.innerHTML = `<tr><td colspan="5" class="text-center text-muted">No audit records found.</td></tr>`;
      return;
    }

    logs.forEach(l => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="font-mono" style="font-size:11px;">${l.timestamp}</td>
        <td><strong>${l.user}</strong></td>
        <td><span class="badge-pill bg-slate text-white font-mono">${l.action}</span></td>
        <td>${l.details}</td>
        <td><span class="badge-pill bg-blue-soft text-blue">${l.source || 'App'}</span></td>
      `;
      tbody.appendChild(tr);
    });
  },

  // ========================================================================
  // 7. MODALS, CRUD HANDLERS & BUSINESS ACTIONS
  // ========================================================================
  openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (!modal) return;
    modal.classList.remove("hidden");

    // Populate dropdowns dynamically
    const db = DataStore.getDB();
    const projects = this.filterByTenancy(db.projects);
    const customers = this.filterByTenancy(db.customers);
    const workers = this.filterByTenancy(db.workers);
    const materials = this.filterByTenancy(db.materials);

    if (modalId === "modal-add-project") {
      const custSelect = document.getElementById("proj-customer");
      if (custSelect) {
        custSelect.innerHTML = customers.map(c => `<option value="${c.id}">${c.name} (${c.phone})</option>`).join("");
      }
      const workerSelect = document.getElementById("proj-workers");
      if (workerSelect) {
        workerSelect.innerHTML = workers.map(w => `<option value="${w.id}">${w.name} - ${w.role}</option>`).join("");
      }
      // Defaults
      if (!this.editingProject) {
        document.getElementById("title-modal-project").textContent = this.t("modal_new_project");
        document.getElementById("form-project").reset();
        document.getElementById("proj-id").value = "";
        document.getElementById("proj-start-date").value = new Date().toISOString().split('T')[0];
        const nextYear = new Date();
        nextYear.setFullYear(nextYear.getFullYear() + 1);
        document.getElementById("proj-end-date").value = nextYear.toISOString().split('T')[0];
      }
    }

    if (modalId === "modal-add-worker") {
      const projSelect = document.getElementById("worker-project");
      if (projSelect) {
        projSelect.innerHTML = `<option value="">-- Floating / All Sites --</option>` + 
          projects.map(p => `<option value="${p.id}">${p.name}</option>`).join("");
      }
    }

    if (modalId === "modal-add-sale") {
      const custSelect = document.getElementById("sale-customer");
      if (custSelect) {
        custSelect.innerHTML = customers.map(c => `<option value="${c.id}">${c.name}</option>`).join("");
      }
      const projSelect = document.getElementById("sale-project");
      if (projSelect) {
        projSelect.innerHTML = projects.map(p => `<option value="${p.id}">${p.name}</option>`).join("");
      }
      const matSelect = document.getElementById("sale-material");
      if (matSelect) {
        matSelect.innerHTML = `<option value="">-- Direct Milestone / Contract Billing --</option>` + 
          materials.map(m => `<option value="${m.id}" data-price="${m.sellingPrice}" data-name="${m.name}">${m.name} (₹${m.sellingPrice}/${m.unit})</option>`).join("");
      }
      this.calculateSaleTotals();
    }

    if (modalId === "modal-add-payment") {
      const custSelect = document.getElementById("pay-customer");
      if (custSelect) {
        custSelect.innerHTML = customers.map(c => `<option value="${c.id}">${c.name} (${c.phone})</option>`).join("");
      }
      document.getElementById("pay-date").value = new Date().toISOString().split('T')[0];
      this.handlePaymentCustomerChange();
    }

    if (modalId === "modal-add-expense") {
      const projSelect = document.getElementById("exp-project");
      if (projSelect) {
        projSelect.innerHTML = projects.map(p => `<option value="${p.id}">${p.name}</option>`).join("");
      }
      document.getElementById("exp-date").value = new Date().toISOString().split('T')[0];
    }

    if (modalId === "modal-upload-document") {
      const projSelect = document.getElementById("doc-project");
      if (projSelect) {
        projSelect.innerHTML = projects.map(p => `<option value="${p.id}">${p.name}</option>`).join("");
      }
    }

    if (modalId === "modal-quick-attendance") {
      this.renderQuickAttendanceModal();
    }
  },

  closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.add("hidden");
    this.editingProject = null;
    this.editingCustomer = null;
    this.editingWorker = null;
    this.editingMaterial = null;
  },

  // PROJECT SAVE / EDIT / DELETE
  handleSaveProject(event) {
    event.preventDefault();
    const db = DataStore.getDB();
    const id = document.getElementById("proj-id").value;

    const workerSelect = document.getElementById("proj-workers");
    const selectedWorkers = Array.from(workerSelect.selectedOptions).map(opt => opt.value);

    const projectData = {
      id: id || `proj-${Date.now()}`,
      builderId: this.currentSession.builderId || "builder1",
      name: document.getElementById("proj-name").value,
      location: document.getElementById("proj-location").value,
      customerId: document.getElementById("proj-customer").value,
      status: document.getElementById("proj-status").value,
      progress: Number(document.getElementById("proj-progress").value) || 0,
      startDate: document.getElementById("proj-start-date").value,
      endDate: document.getElementById("proj-end-date").value,
      budget: Number(document.getElementById("proj-budget").value) || 0,
      spent: id ? (db.projects.find(p => p.id === id)?.spent || 0) : 0,
      assignedWorkers: selectedWorkers,
      description: document.getElementById("proj-description").value
    };

    if (id) {
      const index = db.projects.findIndex(p => p.id === id);
      if (index !== -1) db.projects[index] = projectData;
      ApiAdapter.logAudit(this.currentSession.name, "PROJECT_UPDATED", `Updated project ${projectData.name}`);
    } else {
      db.projects.unshift(projectData);
      ApiAdapter.logAudit(this.currentSession.name, "PROJECT_CREATED", `Added project ${projectData.name}`);
    }

    DataStore.saveDB(db);
    this.closeModal("modal-add-project");
    this.renderAll();
    this.showToast(`Project "${projectData.name}" saved successfully!`, "success");
  },

  editProject(id) {
    const db = DataStore.getDB();
    const p = db.projects.find(proj => proj.id === id);
    if (!p) return;
    this.editingProject = p;
    this.openModal("modal-add-project");

    document.getElementById("title-modal-project").textContent = "Edit Project";
    document.getElementById("proj-id").value = p.id;
    document.getElementById("proj-name").value = p.name;
    document.getElementById("proj-location").value = p.location;
    document.getElementById("proj-customer").value = p.customerId;
    document.getElementById("proj-status").value = p.status;
    document.getElementById("proj-progress").value = p.progress;
    document.getElementById("proj-start-date").value = p.startDate;
    document.getElementById("proj-end-date").value = p.endDate;
    document.getElementById("proj-budget").value = p.budget;
    document.getElementById("proj-description").value = p.description || "";
  },

  deleteProject(id) {
    if (!confirm("Are you sure you want to delete this construction project? All linked data will remain.")) return;
    const db = DataStore.getDB();
    const p = db.projects.find(proj => proj.id === id);
    db.projects = db.projects.filter(proj => proj.id !== id);
    DataStore.saveDB(db);
    ApiAdapter.logAudit(this.currentSession.name, "PROJECT_DELETED", `Deleted project ${p ? p.name : id}`);
    this.renderAll();
    this.showToast("Project deleted.", "info");
  },

  // CUSTOMER SAVE / DELETE / LEDGER
  handleSaveCustomer(event) {
    event.preventDefault();
    const db = DataStore.getDB();
    const id = document.getElementById("cust-id").value;

    const customerData = {
      id: id || `cust-${Date.now()}`,
      builderId: this.currentSession.builderId || "builder1",
      name: document.getElementById("cust-name").value,
      phone: document.getElementById("cust-phone").value,
      email: document.getElementById("cust-email").value,
      address: document.getElementById("cust-address").value,
      creditScore: "A+"
    };

    if (id) {
      const idx = db.customers.findIndex(c => c.id === id);
      if (idx !== -1) db.customers[idx] = customerData;
    } else {
      db.customers.unshift(customerData);
    }

    DataStore.saveDB(db);
    ApiAdapter.logAudit(this.currentSession.name, "CUSTOMER_SAVED", `Customer ${customerData.name}`);
    this.closeModal("modal-add-customer");
    this.renderAll();
    this.showToast(`Customer "${customerData.name}" saved!`, "success");
  },

  deleteCustomer(id) {
    if (!confirm("Delete this customer record?")) return;
    const db = DataStore.getDB();
    db.customers = db.customers.filter(c => c.id !== id);
    DataStore.saveDB(db);
    this.renderAll();
    this.showToast("Customer removed.", "info");
  },

  viewCustomerLedger(customerId) {
    const db = DataStore.getDB();
    const customer = db.customers.find(c => c.id === customerId);
    if (!customer) return;

    const custSales = db.sales.filter(s => s.customerId === customerId);
    const custPayments = db.payments.filter(p => p.customerId === customerId);
    const custProjects = db.projects.filter(p => p.customerId === customerId);

    const totalBilled = custSales.reduce((sum, s) => sum + (Number(s.totalAmount) || 0), 0);
    const totalPaid = custPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    const due = Math.max(0, totalBilled - totalPaid);

    const body = document.getElementById("cust-modal-detail-body");
    const title = document.getElementById("cust-modal-detail-title");
    if (!body || !title) return;

    title.textContent = `Customer Account: ${customer.name}`;
    body.innerHTML = `
      <div class="finance-banner">
        <div class="fb-item">
          <span class="fb-label">Total Invoiced</span>
          <strong class="currency">${this.formatCurrency(totalBilled)}</strong>
        </div>
        <div class="fb-divider"></div>
        <div class="fb-item">
          <span class="fb-label">Total Paid</span>
          <strong class="currency text-success">${this.formatCurrency(totalPaid)}</strong>
        </div>
        <div class="fb-divider"></div>
        <div class="fb-item">
          <span class="fb-label">Net Outstanding Due</span>
          <strong class="currency text-danger">${this.formatCurrency(due)}</strong>
        </div>
      </div>

      <div class="mt-4">
        <h4 style="font-size:14px; font-weight:700; margin-bottom:8px;">Linked Construction Projects</h4>
        ${custProjects.length === 0 ? '<p class="text-muted">No linked active projects.</p>' : `
          <ul style="padding-left:20px; font-size:13px;">
            ${custProjects.map(p => `<li><b>${p.name}</b> (${p.status}) - Progress: ${p.progress}%</li>`).join('')}
          </ul>
        `}
      </div>

      <div class="mt-4">
        <h4 style="font-size:14px; font-weight:700; margin-bottom:8px;">Invoices & Billing History</h4>
        <div class="table-responsive-container">
          <table class="data-table">
            <thead>
              <tr><th>Invoice</th><th>Date</th><th>Item</th><th>Total</th><th>Paid</th><th>Due</th></tr>
            </thead>
            <tbody>
              ${custSales.map(s => `
                <tr>
                  <td><b>${s.invoiceNo}</b></td>
                  <td>${s.date}</td>
                  <td>${s.itemDesc}</td>
                  <td class="currency">${this.formatCurrency(s.totalAmount)}</td>
                  <td class="currency text-success">${this.formatCurrency(s.paidAmount)}</td>
                  <td class="currency text-danger">${this.formatCurrency(s.dueAmount)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>

      <div class="mt-4">
        <h4 style="font-size:14px; font-weight:700; margin-bottom:8px;">Payment Receipts</h4>
        <div class="table-responsive-container">
          <table class="data-table">
            <thead>
              <tr><th>Receipt #</th><th>Date</th><th>Mode</th><th>Ref/UTR</th><th>Amount Paid</th></tr>
            </thead>
            <tbody>
              ${custPayments.map(p => `
                <tr>
                  <td><b>${p.receiptNo}</b></td>
                  <td>${p.date}</td>
                  <td>${p.mode}</td>
                  <td>${p.refNo || '-'}</td>
                  <td class="currency text-success font-bold">${this.formatCurrency(p.amount)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;

    this.openModal("modal-customer-detail");
  },

  // WORKER MANAGEMENT & ATTENDANCE
  handleSaveWorker(event) {
    event.preventDefault();
    const db = DataStore.getDB();
    const id = document.getElementById("worker-id").value;

    const workerData = {
      id: id || `w-${Date.now()}`,
      builderId: this.currentSession.builderId || "builder1",
      name: document.getElementById("worker-name").value,
      role: document.getElementById("worker-role").value,
      phone: document.getElementById("worker-phone").value,
      dailyRate: Number(document.getElementById("worker-daily-rate").value) || 0,
      projectId: document.getElementById("worker-project").value,
      statusToday: "Present",
      wagesPaid: id ? (db.workers.find(w => w.id === id)?.wagesPaid || 0) : 0
    };

    if (id) {
      const idx = db.workers.findIndex(w => w.id === id);
      if (idx !== -1) db.workers[idx] = workerData;
    } else {
      db.workers.unshift(workerData);
    }

    DataStore.saveDB(db);
    ApiAdapter.logAudit(this.currentSession.name, "WORKER_SAVED", `Worker ${workerData.name}`);
    this.closeModal("modal-add-worker");
    this.renderAll();
    this.showToast(`Worker "${workerData.name}" saved!`, "success");
  },

  editWorker(id) {
    const db = DataStore.getDB();
    const w = db.workers.find(worker => worker.id === id);
    if (!w) return;
    this.editingWorker = w;
    this.openModal("modal-add-worker");
    document.getElementById("worker-id").value = w.id;
    document.getElementById("worker-name").value = w.name;
    document.getElementById("worker-role").value = w.role;
    document.getElementById("worker-phone").value = w.phone || "";
    document.getElementById("worker-daily-rate").value = w.dailyRate;
    document.getElementById("worker-project").value = w.projectId || "";
  },

  deleteWorker(id) {
    if (!confirm("Remove this worker?")) return;
    const db = DataStore.getDB();
    db.workers = db.workers.filter(w => w.id !== id);
    DataStore.saveDB(db);
    this.renderAll();
    this.showToast("Worker removed.", "info");
  },

  renderQuickAttendanceModal() {
    const db = DataStore.getDB();
    const workers = this.filterByTenancy(db.workers);
    const container = document.getElementById("attendance-workers-list");
    if (!container) return;
    container.innerHTML = "";

    workers.forEach(w => {
      const row = document.createElement("div");
      row.className = "att-worker-row";
      row.dataset.workerId = w.id;
      row.innerHTML = `
        <div class="att-worker-info">
          <strong>${w.name}</strong>
          <span class="text-muted" style="font-size:11px;">${w.role} (₹${w.dailyRate}/day)</span>
        </div>
        <div class="att-btn-group">
          <button type="button" class="att-btn ${w.statusToday === 'Present' ? 'active present' : ''}" onclick="App.setAttendanceRowStatus(this, 'Present')">Present</button>
          <button type="button" class="att-btn ${w.statusToday === 'Half-Day' ? 'active halfday' : ''}" onclick="App.setAttendanceRowStatus(this, 'Half-Day')">Half-Day</button>
          <button type="button" class="att-btn ${w.statusToday === 'Absent' ? 'active absent' : ''}" onclick="App.setAttendanceRowStatus(this, 'Absent')">Absent</button>
        </div>
      `;
      container.appendChild(row);
    });
  },

  setAttendanceRowStatus(btn, status) {
    const group = btn.closest(".att-btn-group");
    group.querySelectorAll(".att-btn").forEach(b => b.className = "att-btn");
    btn.className = `att-btn active ${status.toLowerCase().replace('-', '')}`;
  },

  saveAttendanceBatch() {
    const db = DataStore.getDB();
    const rows = document.querySelectorAll("#attendance-workers-list .att-worker-row");
    let presentCount = 0;

    rows.forEach(row => {
      const wId = row.dataset.workerId;
      const activeBtn = row.querySelector(".att-btn.active");
      const status = activeBtn ? activeBtn.textContent.trim() : "Present";
      const w = db.workers.find(worker => worker.id === wId);
      if (w) {
        w.statusToday = status;
        if (status === "Present" || status === "Half-Day") presentCount++;
      }
    });

    DataStore.saveDB(db);
    ApiAdapter.logAudit(this.currentSession.name, "ATTENDANCE_BATCH_SAVED", `Marked attendance for ${rows.length} workers`);
    this.closeModal("modal-quick-attendance");
    this.renderAll();
    this.showToast(`Attendance recorded! ${presentCount} workers on site today.`, "success");
  },

  // MATERIAL CRUD
  handleSaveMaterial(event) {
    event.preventDefault();
    const db = DataStore.getDB();
    const id = document.getElementById("mat-id").value;

    const materialData = {
      id: id || `mat-${Date.now()}`,
      builderId: this.currentSession.builderId || "builder1",
      name: document.getElementById("mat-name").value,
      category: document.getElementById("mat-category").value,
      unit: document.getElementById("mat-unit").value,
      qty: Number(document.getElementById("mat-qty").value) || 0,
      minQty: Number(document.getElementById("mat-min-qty").value) || 10,
      purchasePrice: Number(document.getElementById("mat-purchase-price").value) || 0,
      sellingPrice: Number(document.getElementById("mat-selling-price").value) || 0
    };

    if (id) {
      const idx = db.materials.findIndex(m => m.id === id);
      if (idx !== -1) db.materials[idx] = materialData;
    } else {
      db.materials.unshift(materialData);
    }

    DataStore.saveDB(db);
    ApiAdapter.logAudit(this.currentSession.name, "MATERIAL_SAVED", `Inventory ${materialData.name}`);
    this.closeModal("modal-add-material");
    this.renderAll();
    this.showToast(`Material "${materialData.name}" saved!`, "success");
  },

  editMaterial(id) {
    const db = DataStore.getDB();
    const m = db.materials.find(mat => mat.id === id);
    if (!m) return;
    this.editingMaterial = m;
    this.openModal("modal-add-material");
    document.getElementById("mat-id").value = m.id;
    document.getElementById("mat-name").value = m.name;
    document.getElementById("mat-category").value = m.category;
    document.getElementById("mat-unit").value = m.unit;
    document.getElementById("mat-qty").value = m.qty;
    document.getElementById("mat-min-qty").value = m.minQty;
    document.getElementById("mat-purchasePrice").value = m.purchasePrice;
    document.getElementById("mat-selling-price").value = m.sellingPrice;
  },

  deleteMaterial(id) {
    if (!confirm("Delete this inventory material?")) return;
    const db = DataStore.getDB();
    db.materials = db.materials.filter(m => m.id !== id);
    DataStore.saveDB(db);
    this.renderAll();
    this.showToast("Material removed.", "info");
  },

  // SALES CREATION & AUTOMATIC INVENTORY DEDUCTION
  handleSaleMaterialSelect() {
    const matSelect = document.getElementById("sale-material");
    const selected = matSelect.options[matSelect.selectedIndex];
    const price = selected.dataset.price;
    const name = selected.dataset.name;

    if (name) {
      document.getElementById("sale-item-desc").value = name;
    }
    if (price) {
      document.getElementById("sale-price").value = price;
    }
    this.calculateSaleTotals();
  },

  calculateSaleTotals() {
    const qty = Number(document.getElementById("sale-qty")?.value) || 1;
    const price = Number(document.getElementById("sale-price")?.value) || 0;
    const paid = Number(document.getElementById("sale-paid")?.value) || 0;

    const total = qty * price;
    const due = Math.max(0, total - paid);

    const totalInput = document.getElementById("sale-total");
    const dueDisplay = document.getElementById("sale-due-display");
    if (totalInput) totalInput.value = total;
    if (dueDisplay) dueDisplay.textContent = this.formatCurrency(due);
  },

  handleSaveSale(event) {
    event.preventDefault();
    const db = DataStore.getDB();

    const customerId = document.getElementById("sale-customer").value;
    const projectId = document.getElementById("sale-project").value;
    const materialId = document.getElementById("sale-material").value;
    const itemDesc = document.getElementById("sale-item-desc").value;
    const qty = Number(document.getElementById("sale-qty").value) || 1;
    const unitPrice = Number(document.getElementById("sale-price").value) || 0;
    const totalAmount = Number(document.getElementById("sale-total").value) || 0;
    const paidAmount = Number(document.getElementById("sale-paid").value) || 0;
    const dueAmount = Math.max(0, totalAmount - paidAmount);

    const invoiceNo = `INV-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newSale = {
      id: `inv-${Date.now()}`,
      builderId: this.currentSession.builderId || "builder1",
      invoiceNo: invoiceNo,
      date: new Date().toISOString().split('T')[0],
      customerId: customerId,
      projectId: projectId,
      itemDesc: itemDesc,
      qty: qty,
      unitPrice: unitPrice,
      totalAmount: totalAmount,
      paidAmount: paidAmount,
      dueAmount: dueAmount
    };

    // Deduct material inventory if material selected
    if (materialId) {
      const mat = db.materials.find(m => m.id === materialId);
      if (mat) {
        mat.qty = Math.max(0, mat.qty - qty);
      }
    }

    db.sales.unshift(newSale);

    // If paidAmount > 0, automatically generate a linked payment receipt!
    if (paidAmount > 0) {
      const newPayment = {
        id: `pay-${Date.now()}`,
        builderId: this.currentSession.builderId || "builder1",
        receiptNo: `REC-${Math.floor(8000 + Math.random() * 2000)}`,
        date: newSale.date,
        customerId: customerId,
        amount: paidAmount,
        mode: "Bank Transfer / Cash",
        refNo: `INV-SETTLE-${newSale.invoiceNo}`,
        notes: `Immediate payment on invoice ${newSale.invoiceNo}`,
        customerRemainingDue: dueAmount
      };
      db.payments.unshift(newPayment);
    }

    DataStore.saveDB(db);
    ApiAdapter.logAudit(this.currentSession.name, "SALE_CREATED", `Invoice ${invoiceNo} for ${this.formatCurrency(totalAmount)}`);
    this.closeModal("modal-add-sale");
    this.renderAll();
    this.showToast(`Invoice ${invoiceNo} generated!`, "success");
    this.viewSaleInvoice(newSale.id);
  },

  viewSaleInvoice(saleId) {
    const db = DataStore.getDB();
    const sale = db.sales.find(s => s.id === saleId);
    if (!sale) return;
    const customer = db.customers.find(c => c.id === sale.customerId);
    const builder = db.builders.find(b => b.id === sale.builderId) || { name: "Apex Infra Ltd" };

    const modal = document.getElementById("modal-receipt-view");
    const container = document.getElementById("receipt-printable-body");
    if (!modal || !container) return;

    container.innerHTML = `
      <div class="printable-receipt">
        <div class="receipt-head">
          <div class="receipt-title">${builder.name.toUpperCase()}</div>
          <div class="text-muted" style="font-size:11px;">CONSTRUCTION & REAL ESTATE CONTRACTOR</div>
          <div style="font-weight:700; margin-top:6px; font-size:15px;">TAX INVOICE: ${sale.invoiceNo}</div>
        </div>
        <div class="receipt-line">
          <span>Date:</span>
          <b>${sale.date}</b>
        </div>
        <div class="receipt-line">
          <span>Customer:</span>
          <b>${customer ? customer.name : 'Unknown'}</b>
        </div>
        <div class="receipt-line">
          <span>Contact:</span>
          <span>${customer ? customer.phone : '-'}</span>
        </div>
        <hr style="margin:10px 0; border:none; border-top:1px solid #E2E8F0;">
        <div class="receipt-line">
          <span>Item / Milestone:</span>
          <b>${sale.itemDesc}</b>
        </div>
        <div class="receipt-line">
          <span>Quantity & Rate:</span>
          <span>${sale.qty} x ${this.formatCurrency(sale.unitPrice)}</span>
        </div>
        <div class="receipt-total-box">
          <span>Total Invoiced:</span>
          <span>${this.formatCurrency(sale.totalAmount)}</span>
        </div>
        <div class="receipt-line">
          <span>Paid Amount:</span>
          <span class="text-success font-bold">${this.formatCurrency(sale.paidAmount)}</span>
        </div>
        <div class="receipt-line">
          <span>Remaining Balance Due:</span>
          <span class="text-danger font-bold">${this.formatCurrency(sale.dueAmount)}</span>
        </div>
        <div style="margin-top:20px; font-size:10px; color:#64748B; text-align:center;">
          Generated by ADVANCE BUILDTRACK Platform • Computer Generated Invoice
        </div>
      </div>
    `;

    this.openModal("modal-receipt-view");
  },

  // PAYMENT RECORDING & DUE AUTO-RECONCILIATION
  handlePaymentCustomerChange() {
    const custId = document.getElementById("pay-customer")?.value;
    const db = DataStore.getDB();
    if (!custId) return;

    const custSales = db.sales.filter(s => s.customerId === custId);
    const custPayments = db.payments.filter(p => p.customerId === custId);
    const totalBilled = custSales.reduce((sum, s) => sum + (Number(s.totalAmount) || 0), 0);
    const totalPaid = custPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    const due = Math.max(0, totalBilled - totalPaid);

    const dueVal = document.getElementById("pay-cust-due-val");
    if (dueVal) dueVal.textContent = this.formatCurrency(due);
  },

  handleSavePayment(event) {
    event.preventDefault();
    const db = DataStore.getDB();

    const customerId = document.getElementById("pay-customer").value;
    const amount = Number(document.getElementById("pay-amount").value) || 0;
    const mode = document.getElementById("pay-mode").value;
    const refNo = document.getElementById("pay-ref").value;
    const date = document.getElementById("pay-date").value;
    const notes = document.getElementById("pay-notes").value;

    // Calculate updated due
    const custSales = db.sales.filter(s => s.customerId === customerId);
    const custPayments = db.payments.filter(p => p.customerId === customerId);
    const totalBilled = custSales.reduce((sum, s) => sum + (Number(s.totalAmount) || 0), 0);
    const prevPaid = custPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    const remainingDue = Math.max(0, totalBilled - (prevPaid + amount));

    const receiptNo = `REC-${Math.floor(8000 + Math.random() * 2000)}`;

    const newPayment = {
      id: `pay-${Date.now()}`,
      builderId: this.currentSession.builderId || "builder1",
      receiptNo: receiptNo,
      date: date,
      customerId: customerId,
      amount: amount,
      mode: mode,
      refNo: refNo,
      notes: notes,
      customerRemainingDue: remainingDue
    };

    db.payments.unshift(newPayment);
    DataStore.saveDB(db);

    ApiAdapter.logAudit(this.currentSession.name, "PAYMENT_RECORDED", `Receipt ${receiptNo} for ${this.formatCurrency(amount)}`);
    this.closeModal("modal-add-payment");
    this.renderAll();
    this.showToast(`Payment recorded! Remaining Due: ${this.formatCurrency(remainingDue)}`, "success");
    this.viewPaymentReceipt(newPayment.id);
  },

  viewPaymentReceipt(paymentId) {
    const db = DataStore.getDB();
    const pay = db.payments.find(p => p.id === paymentId);
    if (!pay) return;
    const customer = db.customers.find(c => c.id === pay.customerId);
    const builder = db.builders.find(b => b.id === pay.builderId) || { name: "Apex Infra Ltd" };

    const container = document.getElementById("receipt-printable-body");
    if (!container) return;

    container.innerHTML = `
      <div class="printable-receipt">
        <div class="receipt-head">
          <div class="receipt-title">${builder.name.toUpperCase()}</div>
          <div class="text-muted" style="font-size:11px;">OFFICIAL PAYMENT SETTLEMENT RECEIPT</div>
          <div style="font-weight:700; margin-top:6px; font-size:15px;">RECEIPT NO: ${pay.receiptNo}</div>
        </div>
        <div class="receipt-line">
          <span>Date Received:</span>
          <b>${pay.date}</b>
        </div>
        <div class="receipt-line">
          <span>Received From:</span>
          <b>${customer ? customer.name : 'Unknown'}</b>
        </div>
        <div class="receipt-line">
          <span>Payment Mode:</span>
          <span>${pay.mode}</span>
        </div>
        <div class="receipt-line">
          <span>Transaction Ref / UTR:</span>
          <span class="font-mono">${pay.refNo || '-'}</span>
        </div>
        <div class="receipt-line">
          <span>Notes:</span>
          <span>${pay.notes || 'On account'}</span>
        </div>
        <div class="receipt-total-box">
          <span>Amount Received:</span>
          <span class="text-success">${this.formatCurrency(pay.amount)}</span>
        </div>
        <div class="receipt-line">
          <span>Customer Remaining Due Balance:</span>
          <span class="text-danger font-bold">${this.formatCurrency(pay.customerRemainingDue || 0)}</span>
        </div>
        <div style="margin-top:20px; font-size:10px; color:#64748B; text-align:center;">
          Verified and Settled on ADVANCE BUILDTRACK Core • Signature not required
        </div>
      </div>
    `;

    this.openModal("modal-receipt-view");
  },

  // EXPENSE MANAGEMENT
  handleSaveExpense(event) {
    event.preventDefault();
    const db = DataStore.getDB();

    const title = document.getElementById("exp-title").value;
    const category = document.getElementById("exp-category").value;
    const projectId = document.getElementById("exp-project").value;
    const amount = Number(document.getElementById("exp-amount").value) || 0;
    const date = document.getElementById("exp-date").value;
    const desc = document.getElementById("exp-desc").value;

    const newExpense = {
      id: `exp-${Date.now()}`,
      builderId: this.currentSession.builderId || "builder1",
      title: title,
      category: category,
      projectId: projectId,
      amount: amount,
      date: date,
      desc: desc
    };

    db.expenses.unshift(newExpense);

    // Update project spent
    const proj = db.projects.find(p => p.id === projectId);
    if (proj) {
      proj.spent = (proj.spent || 0) + amount;
    }

    DataStore.saveDB(db);
    ApiAdapter.logAudit(this.currentSession.name, "EXPENSE_LOGGED", `Site expense ${this.formatCurrency(amount)}: ${title}`);
    this.closeModal("modal-add-expense");
    this.renderAll();
    this.showToast(`Expense of ${this.formatCurrency(amount)} recorded!`, "success");
  },

  deleteExpense(id) {
    if (!confirm("Delete this expense record?")) return;
    const db = DataStore.getDB();
    db.expenses = db.expenses.filter(e => e.id !== id);
    DataStore.saveDB(db);
    this.renderAll();
    this.showToast("Expense removed.", "info");
  },

  // LOAN / EMI MANAGEMENT
  calculateLoanEmi() {
    const P = Number(document.getElementById("loan-principal")?.value) || 0;
    const annualRate = Number(document.getElementById("loan-rate")?.value) || 0;
    const N = Number(document.getElementById("loan-tenure")?.value) || 1;

    if (P <= 0 || annualRate <= 0 || N <= 0) {
      document.getElementById("loan-emi-display").value = "₹0";
      return;
    }

    const r = (annualRate / 12) / 100;
    const emi = Math.round((P * r * Math.pow(1 + r, N)) / (Math.pow(1 + r, N) - 1));
    document.getElementById("loan-emi-display").value = this.formatCurrency(emi);
  },

  handleSaveLoan(event) {
    event.preventDefault();
    const db = DataStore.getDB();

    const bank = document.getElementById("loan-bank").value;
    const principal = Number(document.getElementById("loan-principal").value) || 0;
    const interestRate = Number(document.getElementById("loan-rate").value) || 0;
    const tenureMonths = Number(document.getElementById("loan-tenure").value) || 1;
    const purpose = document.getElementById("loan-purpose").value;

    const r = (interestRate / 12) / 100;
    const monthlyEmi = Math.round((principal * r * Math.pow(1 + r, tenureMonths)) / (Math.pow(1 + r, tenureMonths) - 1));

    const newLoan = {
      id: `loan-${Date.now()}`,
      builderId: this.currentSession.builderId || "builder1",
      bank: bank,
      principal: principal,
      interestRate: interestRate,
      tenureMonths: tenureMonths,
      monthlyEmi: monthlyEmi,
      paidEmis: 0,
      remainingBalance: principal,
      disbursalDate: new Date().toISOString().split('T')[0],
      purpose: purpose
    };

    db.loans.unshift(newLoan);
    DataStore.saveDB(db);
    ApiAdapter.logAudit(this.currentSession.name, "LOAN_ADDED", `Equipment/Commercial loan ${bank}`);
    this.closeModal("modal-add-loan");
    this.renderAll();
    this.showToast("Loan schedule added!", "success");
  },

  payNextEmi(loanId) {
    const db = DataStore.getDB();
    const loan = db.loans.find(l => l.id === loanId);
    if (!loan) return;

    if (loan.paidEmis >= loan.tenureMonths || loan.remainingBalance <= 0) {
      alert("This loan has already been fully repaid!");
      return;
    }

    if (!confirm(`Confirm monthly EMI payment of ${this.formatCurrency(loan.monthlyEmi)} for ${loan.bank}?`)) return;

    loan.paidEmis += 1;
    // Approximate principal reduction
    const principalPortion = Math.round(loan.monthlyEmi * 0.85);
    loan.remainingBalance = Math.max(0, loan.remainingBalance - principalPortion);

    // Also record site expense for audit
    db.expenses.unshift({
      id: `exp-emi-${Date.now()}`,
      builderId: loan.builderId,
      title: `EMI Payment #${loan.paidEmis} - ${loan.bank}`,
      category: "Fuel & Machinery",
      projectId: db.projects[0]?.id || "",
      amount: loan.monthlyEmi,
      date: new Date().toISOString().split('T')[0],
      desc: `Auto logged monthly bank EMI amortization`
    });

    DataStore.saveDB(db);
    ApiAdapter.logAudit(this.currentSession.name, "EMI_PAID", `Paid EMI #${loan.paidEmis} for ${loan.bank}`);
    this.renderAll();
    this.showToast(`EMI #${loan.paidEmis} paid successfully!`, "success");
  },

  // DOCUMENTS UPLOAD SIMULATION
  handleDocFileSelection(event) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        this.activeDocBase64 = e.target.result;
      };
      reader.readAsDataURL(file);
    }
  },

  handleSaveDocument(event) {
    event.preventDefault();
    const db = DataStore.getDB();

    const title = document.getElementById("doc-title").value;
    const category = document.getElementById("doc-category").value;
    const projectId = document.getElementById("doc-project").value;
    const fileInput = document.getElementById("doc-file-input");
    const file = fileInput.files[0];

    const newDoc = {
      id: `doc-${Date.now()}`,
      builderId: this.currentSession.builderId || "builder1",
      title: title,
      category: category,
      projectId: projectId,
      date: new Date().toISOString().split('T')[0],
      size: file ? `${(file.size / (1024 * 1024)).toFixed(1)} MB` : "1.5 MB",
      ext: file ? file.name.split('.').pop().toUpperCase() : "PDF"
    };

    db.documents.unshift(newDoc);
    DataStore.saveDB(db);
    ApiAdapter.logAudit(this.currentSession.name, "DOCUMENT_UPLOADED", `Uploaded document ${title}`);
    this.closeModal("modal-upload-document");
    this.renderAll();
    this.showToast(`Document "${title}" uploaded!`, "success");
  },

  previewDocument(title) {
    alert(`Previewing Blueprint/Document: "${title}". File is verified and encrypted in application storage.`);
  },

  downloadDocument(title) {
    this.showToast(`Downloading file: "${title}"...`, "info");
  },

  // ========================================================================
  // 8. REPORTS & CSV EXPORT ENGINE
  // ========================================================================
  exportReport(reportType, format) {
    const db = DataStore.getDB();
    let csvContent = "";
    let filename = `advance_buildtrack_${reportType}_${new Date().toISOString().split('T')[0]}.csv`;

    if (reportType === "sales") {
      csvContent = "InvoiceNo,Date,Customer,Project,Item,Quantity,TotalAmount,PaidAmount,DueAmount\n";
      const sales = this.filterByTenancy(db.sales);
      sales.forEach(s => {
        const c = db.customers.find(cust => cust.id === s.customerId)?.name || "Unknown";
        const p = db.projects.find(proj => proj.id === s.projectId)?.name || "-";
        csvContent += `"${s.invoiceNo}","${s.date}","${c}","${p}","${s.itemDesc}",${s.qty},${s.totalAmount},${s.paidAmount},${s.dueAmount}\n`;
      });
    } else if (reportType === "payments") {
      csvContent = "ReceiptNo,Date,Customer,Mode,RefNo,AmountPaid,RemainingDue\n";
      const payments = this.filterByTenancy(db.payments);
      payments.forEach(p => {
        const c = db.customers.find(cust => cust.id === p.customerId)?.name || "Unknown";
        csvContent += `"${p.receiptNo}","${p.date}","${c}","${p.mode}","${p.refNo || ''}",${p.amount},${p.customerRemainingDue || 0}\n`;
      });
    } else if (reportType === "dues") {
      csvContent = "Customer,Phone,TotalBilled,TotalPaid,OutstandingDue,CreditRating\n";
      const customers = this.filterByTenancy(db.customers);
      customers.forEach(c => {
        const billed = db.sales.filter(s => s.customerId === c.id).reduce((sum, s) => sum + s.totalAmount, 0);
        const paid = db.payments.filter(p => p.customerId === c.id).reduce((sum, p) => sum + p.amount, 0);
        const due = Math.max(0, billed - paid);
        csvContent += `"${c.name}","${c.phone}",${billed},${paid},${due},"${c.creditScore || 'A'}"\n`;
      });
    } else if (reportType === "expenses") {
      csvContent = "Date,Category,Project,Title,Amount,Description\n";
      const expenses = this.filterByTenancy(db.expenses);
      expenses.forEach(e => {
        const p = db.projects.find(proj => proj.id === e.projectId)?.name || "General";
        csvContent += `"${e.date}","${e.category}","${p}","${e.title}",${e.amount},"${e.desc || ''}"\n`;
      });
    } else if (reportType === "materials") {
      csvContent = "MaterialName,Category,StockQty,Unit,PurchasePrice,SellingPrice,StockValue\n";
      const materials = this.filterByTenancy(db.materials);
      materials.forEach(m => {
        csvContent += `"${m.name}","${m.category}",${m.qty},"${m.unit}",${m.purchasePrice},${m.sellingPrice},${m.qty * m.purchasePrice}\n`;
      });
    } else if (reportType === "projects") {
      csvContent = "ProjectName,Location,Status,ProgressPct,Budget,Spent,StartDate,EndDate\n";
      const projects = this.filterByTenancy(db.projects);
      projects.forEach(p => {
        csvContent += `"${p.name}","${p.location}","${p.status}",${p.progress},${p.budget},${p.spent},"${p.startDate}","${p.endDate}"\n`;
      });
    }

    // Trigger CSV download
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    this.showToast(`Exported ${filename}!`, "success");
    ApiAdapter.logAudit(this.currentSession.name, "REPORT_EXPORTED", `Exported ${reportType} CSV`);
  },

  printReport(reportType) {
    this.navigateTo(reportType === 'dues' ? 'payments' : reportType);
    setTimeout(() => window.print(), 300);
  },

  // ========================================================================
  // 9. BACKUP & RESTORE
  // ========================================================================
  exportAllDataJson() {
    const db = DataStore.getDB();
    const jsonStr = JSON.stringify(db, null, 2);
    const blob = new Blob([jsonStr], { type: "application/json" });
    const filename = `advance_buildtrack_backup_${new Date().toISOString().split('T')[0]}.json`;

    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    this.showToast("Backup exported successfully!", "success");
    ApiAdapter.logAudit(this.currentSession.name, "BACKUP_EXPORTED", filename);
  },

  handleRestoreFile(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const parsed = JSON.parse(e.target.result);
        if (parsed.projects && parsed.customers && parsed.materials) {
          DataStore.saveDB(parsed);
          ApiAdapter.logAudit(this.currentSession.name, "BACKUP_RESTORED", `Restored backup from ${file.name}`);
          this.renderAll();
          this.showToast("Application data restored successfully!", "success");
        } else {
          alert("Invalid backup file structure. Missing required database collections.");
        }
      } catch (err) {
        alert("Error parsing backup JSON file.");
      }
    };
    reader.readAsText(file);
  },

  resetDemoDataConfirm() {
    if (!confirm("Are you sure you want to restore the factory demo data? Any new additions will be reset to default sample records.")) return;
    DataStore.resetToDemo();
    ApiAdapter.logAudit(this.currentSession.name, "FACTORY_RESET", "Restored demo database");
    this.renderAll();
    this.showToast("Factory demo data restored!", "success");
  },

  clearAuditLogConfirm() {
    if (!confirm("Clear immutable audit log records?")) return;
    const db = DataStore.getDB();
    db.auditLogs = [];
    DataStore.saveDB(db);
    this.renderAuditLogs();
    this.showToast("Audit log cleared.", "info");
  },

  // ========================================================================
  // 10. AUTH MODAL & OTP SIMULATION
  // ========================================================================
  openLoginModal() {
    this.openModal("modal-login");
  },

  switchAuthTab(tab) {
    document.getElementById("tab-quick-demo").classList.toggle("active", tab === "demo");
    document.getElementById("tab-otp-login").classList.toggle("active", tab === "otp");
    document.getElementById("auth-panel-demo").classList.toggle("hidden", tab !== "demo");
    document.getElementById("auth-panel-otp").classList.toggle("hidden", tab !== "otp");
  },

  loginAs(accountKey) {
    this.closeModal("modal-login");
    this.switchAccount(accountKey);
  },

  sendOtpSimulated() {
    const target = document.getElementById("otp-target-input").value.trim();
    if (!target) {
      alert("Please enter a mobile number or email address.");
      return;
    }
    document.getElementById("otp-step-1").classList.add("hidden");
    document.getElementById("otp-step-2").classList.remove("hidden");
    this.showToast(`OTP 123456 sent to ${target}!`, "info");
  },

  verifyOtpSimulated() {
    const code = document.getElementById("otp-code-input").value.trim();
    if (code === "123456" || code.length === 6) {
      this.closeModal("modal-login");
      this.switchAccount("builder1");
      this.showToast("OTP verified! Welcome back, Vikram.", "success");
    } else {
      alert("Invalid OTP. For demo purposes, please use code 123456.");
    }
  },

  resetOtpStep() {
    document.getElementById("otp-step-1").classList.remove("hidden");
    document.getElementById("otp-step-2").classList.add("hidden");
  },

  // ========================================================================
  // 11. TOAST NOTIFICATIONS
  // ========================================================================
  showToast(message, type = "info") {
    const container = document.getElementById("toast-container");
    if (!container) return;

    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateX(100%)";
      setTimeout(() => toast.remove(), 250);
    }, 3200);
  }
};

// Initialize Application on DOM Ready
document.addEventListener("DOMContentLoaded", () => {
  App.init();
});
