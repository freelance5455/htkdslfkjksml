BINDAS FF PANEL+ — ANDROID PROJECT

KYA HAI?
Yeh Android Studio project source hai. Isme pehle wale BINDAS FF PANEL+ web app ko Android WebView ke andar chalaya gaya hai. Yeh ZIP khud APK/AAB nahi hai.

FEATURES
- Home dashboard
- Sensitivity sliders aur local presets
- Aim Lab target practice
- Reaction test
- Player profile
- Local browser storage

ANDROID APP BANANE KE LIYE
1. Computer/laptop par Android Studio ka latest stable version install karo.
2. Is ZIP ko extract karo.
3. Android Studio mein Open par click karke BINDAS_FF_PANEL_ANDROID folder select karo.
4. Android SDK Platform 36 aur JDK 17 install/accept karo agar prompt aaye.
5. Gradle sync complete hone do.
6. Test karne ke liye Android phone ka USB debugging enable karke Run dabao, ya emulator use karo.
7. Release AAB banane ke liye Build > Generate Signed Bundle / APK > Android App Bundle select karo.
8. Apni private signing key securely save karo. Password/key kisi ko share mat karna.
9. Release AAB ko pehle internal testing track mein upload karke phone par test karo.
10. Play Console mein store listing, screenshots, content rating, Data safety, privacy policy URL aur contact details complete karke review ke liye submit karo.

IMPORTANT
- Is project ko is environment mein compile karke test nahi kiya gaya. Android Studio mein sync/build aur device testing zaroori hai.
- Google Play ke liye new apps ko 31 Aug 2026 se Android 16 / API 36 target karna hota hai; is project mein targetSdk 36 set hai. Play Console ki current requirements dobara check karna.
- Privacy policy draft mein placeholders hain: publication date aur real support email add karo; policy ko public HTTPS URL par host karo.
- Yeh app Free Fire ke game files modify nahi karta. Cheat, auto-headshot, flying, speed hack ya revival hack features shamil nahi hain.
- Play Store approval guaranteed nahi hai; Google review aur current policy compliance par depend karta hai.
