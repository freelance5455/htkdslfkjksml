# BINDAS FF PANEL+ Privacy Policy (Draft)

**Effective date:** [Add publication date]

BINDAS FF PANEL+ is an independent gaming companion app that offers local sensitivity presets, aim practice, reaction-time practice, and an optional player profile.

## Information and storage

The app stores sensitivity presets and profile details that you enter (such as nickname and optional game UID) locally on your device using the app's web storage. The current prototype does not send this information to our servers and does not include advertising or analytics SDKs.

## Permissions and third parties

The current build does not request access to contacts, location, camera, microphone, or files, and does not connect to or modify Free Fire. The app is not affiliated with or endorsed by Garena or Free Fire.

## Children's privacy

The app is not designed to collect information from children. Because the app stores profile information locally, please avoid entering personal or sensitive information.

## Data deletion

You can clear the app's storage or uninstall the app to remove locally stored data. If future versions add online services, analytics, ads, or other data collection, this policy must be updated before release.

## Contact

Developer contact: [Add a real support email before publishing]

---

**Publishing note:** This is a draft template, not legal advice. Review it for the final app's actual behavior, replace placeholders, host it at a publicly accessible HTTPS URL, and enter that URL in Play Console before publishing.
