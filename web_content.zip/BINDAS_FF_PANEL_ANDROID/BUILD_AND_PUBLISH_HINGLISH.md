# BINDAS FF PANEL+ — Build & Publish Checklist

## Part A — Build on a computer
1. Install the latest stable Android Studio from the official Android Developers website.
2. Extract this project ZIP, then in Android Studio choose **Open** and select the `BINDAS_FF_PANEL_ANDROID` folder.
3. Install Android SDK Platform 36 and JDK 17 if Android Studio asks. Accept the SDK licences.
4. Wait for Gradle Sync. If Android Studio reports a plugin/Gradle compatibility warning, use its suggested compatible Gradle version or update the Android Gradle Plugin to a current stable release.
5. Run on an emulator or a real Android phone. Test all tabs, sliders, preset save/reset, profile storage, app back button, and screen sizes.
6. Choose **Build → Generate Signed Bundle / APK → Android App Bundle**. Create a new upload key and save the keystore and passwords securely in at least two safe places. Never send the keystore or password to anyone.
7. The signed `.aab` is usually placed under `app/release/` after the wizard completes.

## Part B — Prepare Play Console
1. Create/verify a Google Play developer account at https://play.google.com/console/.
2. Create an app entry with the exact app name and default language.
3. Upload the signed AAB to **Internal testing** first. Add testers, install the test build, and fix issues.
4. Complete the store listing using `PLAY_STORE_LISTING.md`; add screenshots captured from the real app and the 512x512 icon in `store-assets/icon-512.png`.
5. Replace every placeholder in `privacy-policy.html`, especially the date and real support email. Host the page at a public HTTPS URL and add that URL in Play Console.
6. Complete Data safety, content rating, target audience, app access, ads declaration, and any other forms truthfully. Do not claim the app has no data collection unless that matches the final code.
7. Follow any testing requirement shown in your specific Play Console account, then apply for production access / submit the release for review.

## Important current policy note
As of 31 August 2026, new phone apps and updates submitted to Google Play must target Android 16 (API level 36) or higher. This project sets `targetSdk = 36`; confirm current requirements in Play Console before submitting.

## Before production
- This project source has not been compiled or tested in this workspace because Android SDK/Gradle build tools are not installed here.
- The privacy policy is a template. Check it against the final app behavior and your actual contact details.
- Play approval is not guaranteed. Review current Play policies and app quality requirements.
- This is an independent companion app; it does not modify Free Fire or provide cheats.
