# TİSA Takvim – arayüz onarımı ve TİSSA AI yardımcı prototipi

## Bu sürümde yapılanlar

- Takvim HTML yapısındaki fazladan kapanış etiketleri düzeltildi. Gün ızgarası artık `.cal-card` ve takvim sayfasının içinde kalıyor; bu, geniş boş/boş siyah takvim alanına neden olan yerleşim hatasını giderir.
- Takvim başlangıç ayı ve seçili gün cihazın güncel tarihine göre belirleniyor.
- İlk kurulum demo etkinlikleri sabit 2026 tarihleri yerine bugünden itibaren göreli tarihlerle hazırlanıyor.
- Ana sayfaya ve sol menüye TİSSA AI erişimi eklendi.
- TİSSA AI sayfası, mesaj alanı ve örnek komutlar eklendi.
- Cihaz içi yardımcı şu komutları destekler: bugünkü/yarınki programı özetleme, basit takvim/arama/mesaj hatırlatması kaydetme, seçilen şehir için güncel hava durumunu Open-Meteo servisinden getirme.
- Kişiselleştirme > Yapay Zekâ bölümü, mevcut prototipin ne yaptığını ve nelerin henüz bağlı olmadığını açıkça bildiriyor.
- Mevcut renk, görünüm ve takvim tercihleri korunuyor.

## Bilinmesi gerekenler

- Bu, gerçek bir üretken sohbet modeli değildir. Komut tabanlı yerel bir yardımcı prototipidir. Gerçek üretken AI için API anahtarını istemciye gömmeyen güvenli bir sunucu ve AI sağlayıcısı bağlantısı gerekir.
- Hatırlatmalar şu anda takvim etkinliği olarak kaydedilir. Android'in sistem bildirimi zamanlayıcısı henüz eklenmediği için zamanında bildirim gönderildiği iddia edilmez.
- Arama ve SMS işlemleri otomatik başlatılmaz; yalnızca hatırlatma kaydı oluşturulur.
- Hava durumu için internet gerekir; girilen şehir Open-Meteo geocoding servisine, koordinatlar ise hava durumu servisine gönderilir.
- HTML/JavaScript sözdizimi `node --check` ile kontrol edildi. Android cihazında görsel/işlevsel test ve APK derlemesi bu ortamda yapılmadı.
- Bu ZIP, APK değil Android Studio proje kaynaklarıdır. `gradle/wrapper/gradle-wrapper.jar` dosyası kaynak ZIP içinde bulunmadığından komut satırı wrapper derlemesi bu haliyle çalışmayabilir. APK oluşturulmadan önce Gradle wrapper dosyası Android Studio/uygun Gradle kurulumuyla tamamlanmalı ve proje gerçek cihazda test edilmelidir.
