# TİSA Takvim – keep WebView
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
