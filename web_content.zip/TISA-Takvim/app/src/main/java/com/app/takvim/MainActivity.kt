package com.app.takvim

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader

/**
 * TİSA Liquid Glass Takvim – tek Activity; tüm arayüz
 * app/src/main/assets/web/index.html dosyasından yüklenir.
 *
 * HATA DÜZELTMESİ (kök neden):
 * WebViewAssetLoader, kayıtlı yol önekini (prefix) gelen isteğin URL yolundan
 * KIRPAR. Bu yüzden:
 *
 *   addPathHandler("/web/", AssetsPathHandler(this))
 *   + istek: /web/index.html
 *   => aranan dosya: assets/index.html   (YOK!)
 *   => HTTP 404 => "Web page not available / net::ERR_HTTP_RESPONSE_CODE_FAILURE"
 *
 * Doğru kullanım, öneki dosya yoluyla aynı hizaya getirmektir:
 *
 *   addPathHandler("/", AssetsPathHandler(this))
 *   + istek: /web/index.html
 *   => aranan dosya: assets/web/index.html   (VAR) ✅
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var fallbackUsed = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Edge-to-edge (içerik sistem çubuklarının altına da çizilir)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        webView = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            // Cam (glass) efektleri için donanım hızlandırma
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
        }
        setContentView(webView)

        // Kök önek: URL yolu olduğu gibi assets köküne göre çözümlenir.
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webViewClient = object : WebViewClient() {

            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                // appassets.androidplatform.net istekleri yerel assets'ten karşılanır
                return assetLoader.shouldInterceptRequest(request.url)
                    ?: super.shouldInterceptRequest(view, request)
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                super.onReceivedError(view, request, error)
                if (request.isForMainFrame) loadLocalFallback()
            }

            override fun onReceivedHttpError(
                view: WebView,
                request: WebResourceRequest,
                errorResponse: WebResourceResponse
            ) {
                super.onReceivedHttpError(view, request, errorResponse)
                if (request.isForMainFrame && errorResponse.statusCode >= 400) {
                    loadLocalFallback()
                }
            }
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // localStorage (etkinlik kayıtları)
            databaseEnabled = true
            allowFileAccess = true            // file:// yedeği için gerekli
            allowContentAccess = false
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = true
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
        }

        if (savedInstanceState != null && webView.restoreState(savedInstanceState) != null) {
            // Önceki durum geri yüklendi
        } else {
            webView.loadUrl(ASSET_URL)
        }
    }

    /**
     * Asset servisi herhangi bir nedenle başarısız olursa (eksik dosya, bozuk
     * WebView vb.) arayüz yine de açılsın diye doğrudan dosya yolundan yükleme
     * yapılır; kullanıcıya "Web page not available" ekranı gösterilmez.
     */
    private fun loadLocalFallback() {
        if (fallbackUsed) return
        fallbackUsed = true
        webView.loadUrl(FILE_FALLBACK_URL)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (this::webView.isInitialized) {
            webView.destroy()
        }
        super.onDestroy()
    }

    companion object {
        private const val ASSET_URL = "https://appassets.androidplatform.net/web/index.html"
        private const val FILE_FALLBACK_URL = "file:///android_asset/web/index.html"
    }
}