package com.app.takvim

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader

/**
 * TİSA Liquid Glass Takvim – tek Activity; tüm arayüz
 * app/src/main/assets/web/index.html dosyasından yüklenir.
 *
 * HATA DÜZELTMESİ (kök neden):
 * WebViewAssetLoader, kayıtlı yol önekini (prefix) gelen isteğin URL yolundan
 * KIRPAR. Bu yüzden:
 *
 *   addPathHandler("/web/", AssetsPathHandler(this))
 *   + istek: /web/index.html
 *   => aranan dosya: assets/index.html   (YOK!)
 *   => HTTP 404 => "Web page not available / net::ERR_HTTP_RESPONSE_CODE_FAILURE"
 *
 * Doğru kullanım, öneki dosya yoluyla aynı hizaya getirmektir:
 *
 *   addPathHandler("/", AssetsPathHandler(this))
 *   + istek: /web/index.html
 *   => aranan dosya: assets/web/index.html   (VAR) ✅
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var fallbackUsed = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Edge-to-edge (içerik sistem çubuklarının altına da çizilir)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            // 3 düğmeli gezinmede sistemin otomatik koyu şeridini (scrim) kapat
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        // Son kullanılan tema (açık/koyu) ile ilk kareyi doğru çiz
        applySystemBars(getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_LIGHT, true))

        webView = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            // Cam (glass) efektleri için donanım hızlandırma
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
        }
        setContentView(webView)

        // Gerçek sistem çubuğu boşluklarını WebView'a CSS değişkeni olarak ilet
        // (env(safe-area-inset-*) bazı WebView sürümlerinde 0 döner).
        ViewCompat.setOnApplyWindowInsetsListener(webView) { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            lastInsets = intArrayOf(bars.top, bars.right, bars.bottom, bars.left)
            pushInsets()
            insets
        }
        webView.addJavascriptInterface(SystemBarsBridge(), "TisaNative")

        // Kök önek: URL yolu olduğu gibi assets köküne göre çözümlenir.
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webViewClient = object : WebViewClient() {

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                pushInsets()
            }

            // Köprü yalnızca yerel içeriğe açık: dış adreslere gezinmeyi engelle
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val u = request.url
                when (u.scheme?.lowercase()) {
                    "tel" -> {
                        return try {
                            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse(u.toString())))
                            true
                        } catch (_: Exception) { true }
                    }
                    "sms", "smsto" -> {
                        return try {
                            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse(u.toString())))
                            true
                        } catch (_: Exception) { true }
                    }
                }
                val local = (u.scheme == "https" && u.host == "appassets.androidplatform.net") ||
                    u.scheme == "file"
                return !local
            }

            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                // appassets.androidplatform.net istekleri yerel assets'ten karşılanır
                return assetLoader.shouldInterceptRequest(request.url)
                    ?: super.shouldInterceptRequest(view, request)
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                super.onReceivedError(view, request, error)
                if (request.isForMainFrame) loadLocalFallback()
            }

            override fun onReceivedHttpError(
                view: WebView,
                request: WebResourceRequest,
                errorResponse: WebResourceResponse
            ) {
                super.onReceivedHttpError(view, request, errorResponse)
                if (request.isForMainFrame && errorResponse.statusCode >= 400) {
                    loadLocalFallback()
                }
            }
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // localStorage (etkinlik + tema kayıtları)
            databaseEnabled = false           // kullanılmıyor – güvenlik
            allowFileAccess = true            // file:// yedeği için gerekli
            allowContentAccess = false
            // Güvenlik: universal access kapalı. Fallback için sadece file access açık tutulur.
            @Suppress("DEPRECATION")
            allowFileAccessFromFileURLs = true   // sadece yerel fallback
            @Suppress("DEPRECATION")
            allowUniversalAccessFromFileURLs = false
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true
            // Ek güvenlik katmanları
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            // Safe Browsing (API 26+)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                safeBrowsingEnabled = true
            }
        }
        // Tek JS köprüsü: TisaNative.setSystemBars(boolean) – yalnızca ikon rengi/zemin; veri okumaz.

        if (savedInstanceState != null && webView.restoreState(savedInstanceState) != null) {
            // Önceki durum geri yüklendi
        } else {
            webView.loadUrl(ASSET_URL)
        }
    }

    private var lastInsets: IntArray? = null

    private fun pushInsets() {
        val i = lastInsets ?: return
        if (!this::webView.isInitialized) return
        val d = resources.displayMetrics.density
        fun px(v: Int) = "${(v / d)}px"
        val js = "(function(){var r=document.documentElement.style;" +
            "r.setProperty('--safe-top','${px(i[0])}');r.setProperty('--safe-right','${px(i[1])}');" +
            "r.setProperty('--safe-bottom','${px(i[2])}');r.setProperty('--safe-left','${px(i[3])}');})()"
        webView.post { webView.evaluateJavascript(js, null) }
    }

    /** Açık zeminde koyu ikon, koyu zeminde açık ikon; pencere zemini de eşlenir. */
    private fun applySystemBars(isLight: Boolean) {
        window.setBackgroundDrawable(ColorDrawable(if (isLight) 0xFFB0E0E6.toInt() else 0xFF05050C.toInt()))
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = isLight
            isAppearanceLightNavigationBars = isLight
        }
    }

    private inner class SystemBarsBridge {
        @JavascriptInterface
        fun setSystemBars(isLight: Boolean) {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_LIGHT, isLight).apply()
            runOnUiThread { applySystemBars(isLight) }
        }

        /** "Sistem" tema modu için: telefonun gerçek karanlık mod durumu. */
        @JavascriptInterface
        fun isSystemDark(): Boolean =
            (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

        /**
         * Geliyor uygulaması için geçici köprü.
         * Paket adı ve kesin Play Store bağlantısı kullanıcıdan geldiğinde aşağıdaki
         * sabitler güncellenerek yüklüyse doğrudan uygulama, değilse mağaza açılır.
         * Şimdilik paket adı bilinmediği için Google Play araması açılır.
         */
        @JavascriptInterface
        fun openGeliyorApp() {
            runOnUiThread {
                val targetPackage = GELIYOR_PACKAGE_NAME
                val openedInstalledApp = if (targetPackage.isNotBlank()) {
                    try {
                        val launchIntent = packageManager.getLaunchIntentForPackage(targetPackage)
                        if (launchIntent != null) {
                            startActivity(launchIntent)
                            true
                        } else false
                    } catch (_: Exception) { false }
                } else false

                if (!openedInstalledApp) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(GELIYOR_PLAY_URL)))
                    } catch (_: Exception) {
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(GELIYOR_PLAY_WEB_URL)))
                        } catch (_: Exception) {
                            android.widget.Toast.makeText(
                                this@MainActivity,
                                "Google Play açılamadı. İnternet bağlantını kontrol et.",
                                android.widget.Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }
            }
        }
    }

    /**
     * Asset servisi herhangi bir nedenle başarısız olursa (eksik dosya, bozuk
     * WebView vb.) arayüz yine de açılsın diye doğrudan dosya yolundan yükleme
     * yapılır; kullanıcıya "Web page not available" ekranı gösterilmez.
     */
    private fun loadLocalFallback() {
        if (fallbackUsed) return
        fallbackUsed = true
        webView.loadUrl(FILE_FALLBACK_URL)
    }

    // uiMode configChanges'te olduğu için aktivite yeniden oluşmaz; JS'e haber ver.
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (this::webView.isInitialized) {
            webView.evaluateJavascript("window.onSystemThemeChanged&&window.onSystemThemeChanged()", null)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (this::webView.isInitialized) {
            webView.destroy()
        }
        super.onDestroy()
    }

    companion object {
        private const val PREFS = "tisa_ui"
        private const val KEY_LIGHT = "light_bars"
        private const val ASSET_URL = "https://appassets.androidplatform.net/web/index.html"
        private const val FILE_FALLBACK_URL = "file:///android_asset/web/index.html"
        // Kullanıcı kesin bağlantıyı/paket adını gönderince güncellenecek.
        private const val GELIYOR_PACKAGE_NAME = ""
        private const val GELIYOR_PLAY_URL = "market://search?q=Geliyor%20Uygulamas%C4%B1"
        private const val GELIYOR_PLAY_WEB_URL = "https://play.google.com/store/search?q=Geliyor%20Uygulamas%C4%B1&c=apps"
    }
}