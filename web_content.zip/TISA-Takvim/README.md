# TİSA Liquid Glass Takvim – Android Projesi

WebView tabanlı (assets içindeki HTML/CSS/JS arayüzü) tek aktiviteli Android uygulaması.
Bu sürümde **"Web page not available" (web sayfası mevcut değil)** hatası ve projedeki
diğer eksik/hatalı dosyalar giderilmiştir.

## Yeni Özellikler (v2 – Özelleştirme & Güvenlik)

- **Ayarlar** sekmesi (dock’ta dişli ikonu)
- **12 Apple tarzı cam (glassmorphism) renk teması**: Mavi, Indigo, Mor, Pembe, Kırmızı, Turuncu, Sarı, Yeşil, Nane, Turkuaz, Camgöbeği, Gri
- **6 arka plan preset’i** (Varsayılan, Okyanus, Günbatımı, Orman, Gece, Aurora)
- **Cam yoğunluğu** (blur) kaydırıcısı
- Tüm tercihler `localStorage` ile kalıcı
- **Güvenlik sıkılaştırması**: MIXED_CONTENT_NEVER_ALLOW, Safe Browsing, JS interface yok, multiple windows kapalı, databaseEnabled = false

---

## 1. Asıl hata: "Web page not available / net::ERR_HTTP_RESPONSE_CODE_FAILURE"

WebView şu adresi yüklüyordu:

```
https://appassets.androidplatform.net/web/index.html
```

`WebViewAssetLoader` bu özel adresi **yerel `assets/` klasörüne** bağlar. Ancak kritik
nokta şudur: **loader, kayıtlı yol önekini (prefix) isteğin yolundan KIRPAR.**

Eski kod:

```kotlin
WebViewAssetLoader.Builder()
    .addPathHandler("/web/", WebViewAssetLoader.AssetsPathHandler(this))  // ← prefix "/web/"
    .build()
webView.loadUrl("https://appassets.androidplatform.net/web/index.html")
```

Çalışma sırasında olan şey:

| Adım | Değer |
|---|---|
| İstek yolu | `/web/index.html` |
| Kayıtlı önek | `/web/` |
| Önek kırpıldıktan sonra kalan | `index.html` |
| Aranan dosya | `assets/index.html` ❌ **YOK** |
| Sonuç | HTTP 404 → **Web page not available / ERR_HTTP_RESPONSE_CODE_FAILURE** |

Yani dosya doğru yerdeydi (`assets/web/index.html`), hata **önek ile dosya yolu
uyuşmadığı** için oluşuyordu. (Doğrulama: `androidx.webkit.WebViewAssetLoader$PathMatcher.getSuffixPath()`
metodu `path.replaceFirst(registeredPrefix, "")` uygular; `AssetsPathHandler` de kalan yolu
`AssetManager.open()` ile `assets/` köküne göre açar.)

### Çözüm

Önek, gerçek klasör yapısıyla aynı hizaya getirildi:

```kotlin
WebViewAssetLoader.Builder()
    .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))  // ← kök önek
    .build()
webView.loadUrl("https://appassets.androidplatform.net/web/index.html")
```

| Adım | Değer |
|---|---|
| İstek yolu | `/web/index.html` |
| Kayıtlı önek | `/` |
| Kalan yol | `web/index.html` |
| Aranan dosya | `assets/web/index.html` ✅ **VAR** |

Ek olarak, herhangi bir nedenle (eksik dosya, bozuk WebView sürümü vb.) yine hata
oluşursa kullanıcıya boş hata ekranı göstermemek için **otomatik yedek yükleme**
eklendi: `onReceivedError` / `onReceivedHttpError` tetiklenirse sayfa
`file:///android_asset/web/index.html` üzerinden açılır (dosya erişim izinleri açık).

---

## 2. Düzeltilen diğer hatalar

| # | Sorun | Çözüm |
|---|---|---|
| 1 | `assets/web/index.html` ile `addPathHandler("/web/")` uyuşmazlığı → 404 | Önek `"/"` yapıldı, dosya yoluyla eşleşiyor |
| 2 | Hata durumunda boş "Web page not available" ekranı | `onReceivedError` + `onReceivedHttpError` → `file://` yedek yüklemesi |
| 3 | `allowFileAccess = false` iken yedek yükleme çalışmaz | Dosya erişimi açıldı, yedek yol için gerekli |
| 4 | **`gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar` yoktu** → `./gradlew assembleDebug` çalışmıyordu | Gradle 8.7 wrapper dosyaları eklendi |
| 5 | Manifest ikonları `@drawable/ic_launcher_foreground`'a bakıyordu; adaptive icon (v26+) tanımı kullanılmıyordu ve **API 24–25 için PNG ikon yoktu** | `@mipmap/ic_launcher` + `@mipmap/ic_launcher_round`; `mipmap-mdpi…xxxhdpi` PNG'leri üretildi (v26+ için adaptive icon korundu) |
| 6 | `targetSdk 34` ile `dataExtractionRules` / `fullBackupContent` eksikti | `res/xml/backup_rules.xml` ve `res/xml/data_extraction_rules.xml` eklendi |
| 7 | Dönüş/yeniden oluşturma sırasında WebView durumu kayboluyordu | `onSaveInstanceState` + `restoreState` eklendi |
| 8 | Boş `res/xml`, `res/layout`, `res/mipmap-hdpi` klasörleri | Gerekli kaynaklarla dolduruldu |
| 9 | Kullanılmayan `WindowManager` importu, `View` importu vb. | Importlar temizlendi |
| 10 | `onBackPressed` deprecated uyarısı | `@Deprecated`/`@Suppress("DEPRECATION")` ile belgelendi (legacy back davranışı korundu) |

> Not: `local.properties` **bilinçli olarak eklenmedi**; her makinede Android SDK yolu
> farklıdır. Android Studio açılışta otomatik oluşturur (`.gitignore` içinde).

---

## 3. Derleme

### Android Studio ile
1. **Open** → `TISA-Takvim` klasörünü seç
2. Gradle sync tamamlanana kadar bekle (SDK 34 gerekir)
3. Cihaz/emülatör seç → **Run** (▶)

### Terminal ile
```bash
cd TISA-Takvim
./gradlew assembleDebug        # Linux / macOS
gradlew.bat assembleDebug      # Windows
```

APK çıktısı: `app/build/outputs/apk/debug/app-debug.apk`

Gereksinimler: **JDK 17**, Android SDK **Platform 34** + **Build-Tools 34.0.0**,
Gradle **8.7** (wrapper dahil), AGP 8.5.2, Kotlin 1.9.24.

---

## 4. Proje yapısı

```
TISA-Takvim/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── assets/web/index.html          ← tüm arayüz (Liquid Glass takvim)
│       ├── java/com/app/takvim/MainActivity.kt
│       └── res/
│           ├── drawable/ic_launcher_background.xml
│           ├── drawable/ic_launcher_foreground.xml
│           ├── mipmap-anydpi-v26/ic_launcher(.round).xml   (API 26+)
│           ├── mipmap-mdpi…xxxhdpi/ic_launcher(_round).png (API 24–25)
│           ├── values/strings.xml, values/themes.xml
│           └── xml/backup_rules.xml, xml/data_extraction_rules.xml
├── gradle/wrapper/gradle-wrapper.jar, gradle-wrapper.properties
├── gradlew, gradlew.bat
├── build.gradle.kts, settings.gradle.kts, gradle.properties
└── README.md
```

## 5. Notlar

- `minSdk 24` (Android 7.0+), `targetSdk 34`
- Etkinlikler `localStorage` ile cihazda saklanır (`domStorageEnabled = true`)
- İnternet izni yalnızca Google Fonts (Inter) isteği içindir; font yüklenmezse
  sistem fontuna düşer, uygulama **offline** da sorunsuz çalışır
- Arayüz edge-to-edge (çentik/gesture bar) desteklidir ve telefon/tablet'te responsive'tir