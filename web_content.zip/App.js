"use strict";

/* =====================================================
   BOULANGERIE LA RACINE DE KENGE
   Gestion des commissions + verrouillage local
   ===================================================== */

const CONFIG = {
    painsParBaque: 12,
    prixBaque: 6000,
    tauxCommission: 0.25,
    cleMamans: "racine_mamans",
    cleAchats: "racine_achats",
    clePaiements: "racine_paiements",
    cleAuth: "racine_auth_hash",
    cleSession: "racine_session_active"
};

function lireDonnees(cle) {
    try {
        const valeur = localStorage.getItem(cle);
        if (!valeur) return [];
        const resultat = JSON.parse(valeur);
        return Array.isArray(resultat) ? resultat : [];
    } catch (erreur) {
        console.error("Erreur de lecture :", cle, erreur);
        return [];
    }
}

function enregistrerDonnees(cle, donnees) {
    try {
        localStorage.setItem(cle, JSON.stringify(donnees));
        return true;
    } catch (erreur) {
        console.error("Erreur de sauvegarde :", erreur);
        alert("Erreur de sauvegarde. Vérifiez l'espace disponible dans le navigateur.");
        return false;
    }
}

let mamans = lireDonnees(CONFIG.cleMamans);
let achats = lireDonnees(CONFIG.cleAchats);
let paiements = lireDonnees(CONFIG.clePaiements);

function genererId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
}

function dateLocale() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function moisCourant() {
    return dateLocale().slice(0, 7);
}

function formatFC(montant) {
    return new Intl.NumberFormat("fr-FR", {
        maximumFractionDigits: 0
    }).format(Number(montant) || 0) + " FC";
}

function echapper(texte) {
    return String(texte ?? "").replace(/[&<>"']/g, c => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[c]);
}

function dateDansMois(date, mois) {
    return String(date || "").slice(0, 7) === mois;
}

function calculerMontant(baques) {
    return Number(baques) * CONFIG.prixBaque;
}

function calculerCommission(baques) {
    return Math.round(
        calculerMontant(baques) * CONFIG.tauxCommission
    );
}

function afficherMessage(id, texte, succes = true) {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = texte;
    el.style.color = succes ? "#15803d" : "#dc2626";
    el.hidden = false;
}

function initialiserDonnees() {
    let modifie = false;

    mamans = mamans.map(m => {
        const x = { ...m };

        if (x.id === undefined || x.id === null || x.id === "") {
            x.id = genererId();
            modifie = true;
        }

        if (x.nom === undefined) {
            x.nom = x.nomMaman || "";
            modifie = true;
        }

        if (x.telephone === undefined) {
            x.telephone = x.telephoneMaman || "";
            modifie = true;
        }

        return x;
    });

    if (modifie) {
        enregistrerDonnees(CONFIG.cleMamans, mamans);
    }

    achats = achats.map(a => {
        const x = { ...a };

        if (x.id == null || x.id === "") {
            x.id = genererId();
        }

        if (x.mamanId == null) {
            x.mamanId = x.maman_id ?? "";
        }

        if (x.baques == null) {
            x.baques = Number(x.nombreBaques ?? x.quantite ?? 0);
        }

        if (x.date == null) {
            x.date = dateLocale();
        }

        if (x.montant == null) {
            x.montant = calculerMontant(x.baques);
        }

        if (x.commission == null) {
            x.commission = calculerCommission(x.baques);
        }

        return x;
    });

    enregistrerDonnees(CONFIG.cleAchats, achats);

    paiements = paiements.map(p => {
        const x = { ...p };

        if (x.id == null || x.id === "") {
            x.id = genererId();
        }

        if (x.mamanId == null) {
            x.mamanId = x.maman_id ?? "";
        }

        if (x.date == null) {
            x.date = dateLocale();
        }

        if (x.mois == null) {
            x.mois = x.moisConcerne || String(x.date).slice(0, 7);
        }

        if (x.montant == null) {
            x.montant = Number(x.montantPaye ?? 0);
        }

        if (x.mode == null) {
            x.mode = "Espèces";
        }

        return x;
    });

    enregistrerDonnees(CONFIG.clePaiements, paiements);
}

function obtenirNomMaman(id) {
    const m = mamans.find(x => String(x.id) === String(id));
    return m ? m.nom : "Maman inconnue";
}

/* =====================================================
   AUTHENTIFICATION LOCALE
   Note : protection locale de base, pas une sécurité serveur.
   ===================================================== */

function hashMotDePasse(mot) {
    // Empreinte locale non cryptographique.
    let h1 = 0x811c9dc5;

    for (let i = 0; i < mot.length; i++) {
        h1 ^= mot.charCodeAt(i);
        h1 = Math.imul(h1, 0x01000193);
    }

    return (h1 >>> 0).toString(16).padStart(8, "0") + ":" + mot.length;
}

function injecterEcranConnexion() {
    if (document.getElementById("racineAuthOverlay")) return;

    const style = document.createElement("style");
    style.id = "racineAuthStyle";

    style.textContent = `
      #racineAuthOverlay {
        position:fixed;
        inset:0;
        z-index:99999;
        display:flex;
        align-items:center;
        justify-content:center;
        padding:20px;
        background:linear-gradient(135deg,#064e3b,#15803d);
        font-family:inherit
      }
      #racineAuthCard {
        width:min(100%,420px);
        background:#fff;
        border-radius:20px;
        padding:28px;
        box-shadow:0 20px 60px #0004;
        color:#163326
      }
      #racineAuthCard h1 {
        font-size:1.45rem;
        margin:0 0 8px;
        color:#166534
      }
      #racineAuthCard p {
        line-height:1.5;
        color:#52635a
      }
      #racineAuthCard label {
        display:block;
        font-weight:600;
        margin:14px 0 6px
      }
      #racineAuthCard input {
        width:100%;
        box-sizing:border-box;
        padding:12px;
        border:1px solid #cbd5d1;
        border-radius:10px;
        font:inherit
      }
      #racineAuthCard button {
        cursor:pointer;
        border:0;
        border-radius:10px;
        padding:12px 14px;
        font:inherit;
        font-weight:700
      }
      #racineAuthSubmit {
        width:100%;
        margin-top:16px;
        background:#15803d;
        color:#fff
      }
      #racineAuthToggle {
        margin-top:8px;
        background:#e8f5ec;
        color:#166534;
        width:100%
      }
      #racineAuthError {
        color:#b91c1c!important;
        min-height:1.2em;
        font-weight:600
      }
      #racineLogoutBtn {
        margin-left:8px
      }
      @media(max-width:480px) {
        #racineAuthCard {
          padding:22px
        }
      }
    `;

    document.head.appendChild(style);

    const overlay = document.createElement("div");
    overlay.id = "racineAuthOverlay";

    overlay.innerHTML = `
      <div id="racineAuthCard" role="dialog" aria-modal="true" aria-labelledby="racineAuthTitle">
        <p style="font-weight:800;letter-spacing:.08em;color:#15803d;margin:0 0 8px">BOULANGERIE</p>
        <h1 id="racineAuthTitle">La Racine de Kenge</h1>
        <p id="racineAuthIntro">Créez un mot de passe pour protéger l'accès à cette application sur cet appareil.</p>

        <form id="racineAuthForm">
          <label for="racineAuthPassword" id="racineAuthLabel">Créer un mot de passe</label>

          <input
            id="racineAuthPassword"
            type="password"
            autocomplete="new-password"
            minlength="4"
            required
            placeholder="4 caractères minimum"
          >

          <div id="racineAuthConfirmWrap">
            <label for="racineAuthConfirm">Confirmer le mot de passe</label>

            <input
              id="racineAuthConfirm"
              type="password"
              autocomplete="new-password"
              minlength="4"
              placeholder="Répétez le mot de passe"
            >
          </div>

          <button id="racineAuthToggle" type="button">
            Afficher le mot de passe
          </button>

          <p id="racineAuthError" aria-live="polite"></p>

          <button id="racineAuthSubmit" type="submit">
            Créer le mot de passe
          </button>
        </form>
      </div>`;

    document.body.appendChild(overlay);

    const hasPassword = Boolean(localStorage.getItem(CONFIG.cleAuth));
    const intro = document.getElementById("racineAuthIntro");
    const label = document.getElementById("racineAuthLabel");
    const confirmWrap = document.getElementById("racineAuthConfirmWrap");
    const submit = document.getElementById("racineAuthSubmit");
    const password = document.getElementById("racineAuthPassword");

    if (hasPassword) {
        intro.textContent = "Entrez votre mot de passe pour accéder à l'application.";
        label.textContent = "Mot de passe";
        password.autocomplete = "current-password";
        password.placeholder = "Saisir le mot de passe";
        confirmWrap.hidden = true;
        submit.textContent = "Se connecter";

        document.getElementById("racineAuthTitle").textContent =
            "Connexion sécurisée";
    }

    document.getElementById("racineAuthToggle").addEventListener("click", () => {
        const fields = [
            password,
            document.getElementById("racineAuthConfirm")
        ];

        const afficher = password.type === "password";

        fields.forEach(f => {
            if (f) f.type = afficher ? "text" : "password";
        });

        document.getElementById("racineAuthToggle").textContent =
            afficher ? "Masquer le mot de passe" : "Afficher le mot de passe";
    });

    document.getElementById("racineAuthForm").addEventListener("submit", e => {
        e.preventDefault();

        const mot = password.value;
        const erreur = document.getElementById("racineAuthError");
        erreur.textContent = "";

        if (mot.length < 4) {
            erreur.textContent = "Le mot de passe doit contenir au moins 4 caractères.";
            return;
        }

        const empreinte = localStorage.getItem(CONFIG.cleAuth);

        if (!empreinte) {
            const confirmation =
                document.getElementById("racineAuthConfirm").value;

            if (mot !== confirmation) {
                erreur.textContent = "Les deux mots de passe ne correspondent pas.";
                return;
            }

            try {
                localStorage.setItem(CONFIG.cleAuth, hashMotDePasse(mot));
            } catch (_) {
                erreur.textContent =
                    "Impossible d'enregistrer le mot de passe dans ce navigateur.";
                return;
            }

            ouvrirApplication();
            return;
        }

        if (hashMotDePasse(mot) !== empreinte) {
            erreur.textContent = "Mot de passe incorrect.";
            password.value = "";
            password.focus();
            return;
        }

        ouvrirApplication();
    });
}
function ajouterBoutonDeconnexion() {
    if (document.getElementById("racineLogoutBtn")) return;

    const bouton = document.createElement("button");
    bouton.type = "button";
    bouton.id = "racineLogoutBtn";
    bouton.className = "btn btn-secondary";
    bouton.textContent = "Déconnexion";

    bouton.addEventListener("click", () => {
        sessionStorage.removeItem(CONFIG.cleSession);
        verrouillerApplication();
    });

    const nav =
        document.querySelector("nav") ||
        document.querySelector(".navbar") ||
        document.querySelector("header");

    if (nav) {
        nav.appendChild(bouton);
    } else {
        document.body.insertBefore(bouton, document.body.firstChild);
    }
}

function verrouillerApplication() {
    injecterEcranConnexion();

    const overlay = document.getElementById("racineAuthOverlay");

    if (overlay) {
        overlay.style.display = "flex";

        const hasPassword = Boolean(localStorage.getItem(CONFIG.cleAuth));

        document.getElementById("racineAuthIntro").textContent = hasPassword
            ? "Entrez votre mot de passe pour accéder à l'application."
            : "Créez un mot de passe pour protéger l'accès à cette application sur cet appareil.";

        document.getElementById("racineAuthLabel").textContent =
            hasPassword ? "Mot de passe" : "Créer un mot de passe";

        document.getElementById("racineAuthConfirmWrap").hidden = hasPassword;

        document.getElementById("racineAuthSubmit").textContent =
            hasPassword ? "Se connecter" : "Créer le mot de passe";

        document.getElementById("racineAuthTitle").textContent =
            hasPassword ? "Connexion sécurisée" : "La Racine de Kenge";

        document.getElementById("racineAuthPassword").value = "";
        document.getElementById("racineAuthConfirm").value = "";
        document.getElementById("racineAuthError").textContent = "";
    }
}

function ouvrirApplication() {
    sessionStorage.setItem(CONFIG.cleSession, "1");

    const overlay = document.getElementById("racineAuthOverlay");

    if (overlay) {
        overlay.style.display = "none";
    }

    ajouterBoutonDeconnexion();
    actualiserDashboard();
}

/* =====================================================
   NAVIGATION
   ===================================================== */

function afficherSection(id) {
    if (!sessionStorage.getItem(CONFIG.cleSession)) {
        verrouillerApplication();
        return;
    }

    const noms = [
        "dashboard",
        "mamans",
        "achats",
        "commissions",
        "paiements"
    ];

    if (!noms.includes(id)) {
        console.error("Section inconnue :", id);
        return;
    }

    noms.forEach(nom => {
        const section = document.getElementById(nom);
        if (section) section.hidden = nom !== id;
    });

    document.querySelectorAll(".nav-button").forEach(b => {
        b.classList.remove("active");
    });

    const actif = document.querySelector(
        `.nav-button[onclick*="'${id}'"]`
    );

    if (actif) actif.classList.add("active");

    if (id === "dashboard") actualiserDashboard();
    if (id === "mamans") afficherMamans();
    if (id === "achats") afficherAchats();
    if (id === "commissions") afficherCommissions();
    if (id === "paiements") afficherPaiements();
}

/* =====================================================
   INTERFACES DYNAMIQUES
   ===================================================== */

function initialiserInterface() {
    const sectionAchats = document.getElementById("achats");

    if (sectionAchats) {
        sectionAchats.innerHTML = `
          <div class="page-heading">
            <div>
              <p class="eyebrow">OPÉRATIONS COMMERCIALES</p>
              <h2>Gestion des achats</h2>
              <p class="subtitle">Enregistrement des achats de pains.</p>
            </div>
          </div>

          <div class="panel">
            <h3>Enregistrer un achat</h3>

            <form id="formAchat">
              <div class="form-grid">
                <div class="form-group">
                  <label for="achatMaman">Maman boulangère</label>
                  <select id="achatMaman" required>
                    <option value="">Sélectionner une maman</option>
                  </select>
                </div>

                <div class="form-group">
                  <label for="achatDate">Date</label>
                  <input type="date" id="achatDate" required>
                </div>

                <div class="form-group">
                  <label for="achatBaques">Nombre de baques</label>
                  <input type="number" id="achatBaques" min="1" step="1" required placeholder="Ex. : 5">
                </div>
              </div>

              <div class="panel">
                <p>Nombre de pains : <strong id="apercuPains">0</strong></p>
                <p>Montant : <strong id="apercuMontant">0 FC</strong></p>
                <p>Commission : <strong id="apercuCommission">0 FC</strong></p>
              </div>

              <button class="btn btn-primary" type="submit">
                Enregistrer l'achat
              </button>

              <p id="messageAchats" aria-live="polite"></p>
            </form>
          </div>

          <div class="panel">
            <h3>Historique des achats</h3>

            <div class="form-group">
              <label for="filtreAchats">Mois</label>
              <input type="month" id="filtreAchats">
            </div>

            <div class="table-container">
              <table>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Maman</th>
                    <th>Baques</th>
                    <th>Pains</th>
                    <th>Montant</th>
                    <th>Commission</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody id="listeAchats"></tbody>
              </table>
            </div>
          </div>`;
    }

    const sectionCommissions = document.getElementById("commissions");

    if (sectionCommissions) {
        sectionCommissions.innerHTML = `
          <div class="page-heading">
            <div>
              <p class="eyebrow">CALCUL DES DROITS</p>
              <h2>Gestion des commissions</h2>
              <p class="subtitle">Suivi des commissions mensuelles.</p>
            </div>
          </div>

          <div class="panel">
            <div class="form-group">
              <label for="filtreCommissions">Mois</label>
              <input type="month" id="filtreCommissions">
            </div>

            <div class="stats">
              <article class="card">
                <p>Commissions acquises</p>
                <h3 id="commissionsAcquises">0 FC</h3>
              </article>

              <article class="card">
                <p>Commissions payées</p>
                <h3 id="commissionsPayees">0 FC</h3>
              </article>

              <article class="card">
                <p>Solde impayé</p>
                <h3 id="commissionsImpayees">0 FC</h3>
              </article>
            </div>

            <div class="table-container">
              <table>
                <thead>
                  <tr>
                    <th>Maman</th>
                    <th>Baques</th>
                    <th>Commission</th>
                    <th>Payé</th>
                    <th>Solde</th>
                  </tr>
                </thead>
                <tbody id="listeCommissions"></tbody>
              </table>
            </div>
          </div>`;
    }

    const sectionPaiements = document.getElementById("paiements");

    if (sectionPaiements) {
        sectionPaiements.innerHTML = `
          <div class="page-heading">
            <div>
              <p class="eyebrow">SUIVI FINANCIER</p>
              <h2>Gestion des paiements</h2>
              <p class="subtitle">Enregistrement des versements.</p>
            </div>
          </div>

          <div class="panel">
            <h3>Enregistrer un paiement</h3>

            <form id="formPaiement">
              <div class="form-grid">
                <div class="form-group">
                  <label for="paiementMaman">Maman boulangère</label>
                  <select id="paiementMaman" required>
                    <option value="">Sélectionner une maman</option>
                  </select>
                </div>

                <div class="form-group">
                  <label for="paiementMois">Mois concerné</label>
                  <input type="month" id="paiementMois" required>
                </div>

                <div class="form-group">
                  <label for="paiementDate">Date du versement</label>
                  <input type="date" id="paiementDate" required>
                </div>

                <div class="form-group">
                  <label for="paiementMontant">Montant versé en FC</label>
                  <input type="number" id="paiementMontant" min="1" step="1" required>
                </div>

                <div class="form-group">
                  <label for="paiementMode">Mode de paiement</label>
                  <select id="paiementMode" required>
                    <option value="Espèces">Espèces</option>
                    <option value="M-Pesa">M-Pesa</option>
                    <option value="Airtel Money">Airtel Money</option>
                    <option value="Orange Money">Orange Money</option>
                    <option value="Autre">Autre</option>
                  </select>
                </div>

                <div class="form-group">
                  <label for="paiementNote">Observation</label>
                  <input type="text" id="paiementNote" maxlength="200">
                </div>
              </div>

              <p>Commission acquise : <strong id="dettePaiement">0 FC</strong></p>
              <p>Déjà payé : <strong id="dejaPaye">0 FC</strong></p>
              <p>Solde restant : <strong id="restePaiement">0 FC</strong></p>

              <button class="btn btn-primary" type="submit">
                Enregistrer le paiement
              </button>

              <p id="messagePaiements" aria-live="polite"></p>
            </form>
          </div>

          <div class="panel">
            <h3>Historique des paiements</h3>

            <div class="form-group">
              <label for="filtrePaiements">Mois du versement</label>
              <input type="month" id="filtrePaiements">
            </div>

            <div class="table-container">
              <table>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Maman</th>
                    <th>Mois concerné</th>
                    <th>Montant</th>
                    <th>Mode</th>
                    <th>Observation</th>
                  </tr>
                </thead>
                <tbody id="listePaiements"></tbody>
              </table>
            </div>
          </div>`;
    }

    const mamanSection = document.getElementById("mamans");

    if (mamanSection && !document.getElementById("rechercheMaman")) {
        const heading = mamanSection.querySelector(".page-heading");
        const searchWrap = document.createElement("div");

        searchWrap.className = "form-group";
        searchWrap.innerHTML =
            '<label for="rechercheMaman">Rechercher une maman</label><input type="search" id="rechercheMaman" placeholder="Nom ou téléphone">';

        if (heading) {
            heading.insertAdjacentElement("afterend", searchWrap);
        }
    }

    const achatDate = document.getElementById("achatDate");
    const paiementDate = document.getElementById("paiementDate");
    const filtreAchats = document.getElementById("filtreAchats");
    const filtreCommissions = document.getElementById("filtreCommissions");
    const filtrePaiements = document.getElementById("filtrePaiements");
    const paiementMois = document.getElementById("paiementMois");

    if (achatDate) achatDate.value = dateLocale();
    if (paiementDate) paiementDate.value = dateLocale();
    if (filtreAchats) filtreAchats.value = moisCourant();
    if (filtreCommissions) filtreCommissions.value = moisCourant();
    if (filtrePaiements) filtrePaiements.value = moisCourant();
    if (paiementMois) paiementMois.value = moisCourant();

    remplirSelecteurs();
    lierEvenements();
}

function lierEvenements() {
    const formMaman = document.getElementById("formMaman");
    if (formMaman) {
        formMaman.addEventListener("submit", enregistrerMaman);
    }

    const formAchat = document.getElementById("formAchat");
    if (formAchat) {
        formAchat.addEventListener("submit", enregistrerAchat);
    }

    const formPaiement = document.getElementById("formPaiement");
    if (formPaiement) {
        formPaiement.addEventListener("submit", enregistrerPaiement);
    }

    const recherche = document.getElementById("rechercheMaman");
    if (recherche) {
        recherche.addEventListener("input", afficherMamans);
    }

    ["filtreAchats", "filtreCommissions", "filtrePaiements"].forEach(id => {
        const el = document.getElementById(id);

        if (el) {
            el.addEventListener("change", () => {
                if (id === "filtreAchats") afficherAchats();
                if (id === "filtreCommissions") afficherCommissions();
                if (id === "filtrePaiements") afficherPaiements();
            });
        }
    });

    ["achatBaques"].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener("input", actualiserApercuAchat);
    });

    ["paiementMaman", "paiementMois"].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener("change", actualiserApercuPaiement);
    });

    document.addEventListener("click", e => {
        const supprimerMamanBtn = e.target.closest("[data-supprimer-maman]");

        if (supprimerMamanBtn) {
            supprimerMaman(supprimerMamanBtn.dataset.supprimerMaman);
        }

        const supprimerAchatBtn = e.target.closest("[data-supprimer-achat]");

        if (supprimerAchatBtn) {
            supprimerAchat(supprimerAchatBtn.dataset.supprimerAchat);
        }
    });
}

/* =====================================================
   MAMANS
   ===================================================== */

function afficherMamans() {
    const tbody = document.getElementById("listeMamans");
    if (!tbody) return;

    const recherche = (
        document.getElementById("rechercheMaman")?.value || ""
    ).trim().toLowerCase();

    const resultat = mamans.filter(m =>
        String(m.nom || "").toLowerCase().includes(recherche) ||
        String(m.telephone || "").toLowerCase().includes(recherche)
    );

    tbody.innerHTML = resultat.map((m, i) => `
        <tr>
            <td>${i + 1}</td>
            <td>${echapper(m.nom)}</td>
            <td>${echapper(m.telephone || "Non renseigné")}</td>
            <td>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-supprimer-maman="${echapper(m.id)}">
                    Supprimer
                </button>
            </td>
        </tr>
    `).join("");

    const compteur = document.getElementById("compteurMamans");

    if (compteur) {
        compteur.textContent =
            `${mamans.length} ${mamans.length > 1 ? "mamans" : "maman"}`;
    }

    const message = document.getElementById("messageMamans");

    if (message) {
        message.hidden = resultat.length > 0;
        message.textContent = recherche
            ? "Aucun résultat pour cette recherche."
            : "Aucune maman enregistrée.";
    }

    remplirSelecteurs();
    actualiserDashboard();
}

function enregistrerMaman(e) {
    e.preventDefault();

    const nomEl = document.getElementById("nomMaman");
    const telEl = document.getElementById("telephoneMaman");

    if (!nomEl || !telEl) return;

    const nom = nomEl.value.trim();
    const telephone = telEl.value.trim();

    if (!nom) {
        return afficherMessage(
            "messageMamans",
            "Veuillez saisir le nom complet.",
            false
        );
    }

    if (mamans.some(m => String(m.nom).toLowerCase() === nom.toLowerCase())) {
        return afficherMessage(
            "messageMamans",
            "Cette maman existe déjà.",
            false
        );
    }

    const ancien = [...mamans];

    mamans.push({
        id: genererId(),
        nom,
        telephone,
        dateCreation: dateLocale()
    });

    if (!enregistrerDonnees(CONFIG.cleMamans, mamans)) {
        mamans = ancien;
        return;
    }

    document.getElementById("formMaman").reset();
    afficherMamans();

    afficherMessage(
        "messageMamans",
        "Maman enregistrée avec succès."
    );
}

function supprimerMaman(id) {
    if (
        achats.some(a => String(a.mamanId) === String(id)) ||
        paiements.some(p => String(p.mamanId) === String(id))
    ) {
        alert("Suppression refusée : cette maman possède un historique financier.");
        return;
    }

    if (!confirm("Confirmer la suppression de cette maman ?")) return;

    const ancien = [...mamans];

    mamans = mamans.filter(m => String(m.id) !== String(id));

    if (!enregistrerDonnees(CONFIG.cleMamans, mamans)) {
        mamans = ancien;
        return;
    }

    afficherMamans();
}

function remplirSelecteurs() {
    ["achatMaman", "paiementMaman"].forEach(id => {
        const select = document.getElementById(id);
        if (!select) return;

        const ancienneValeur = select.value;

        select.innerHTML =
            '<option value="">Sélectionner une maman</option>' +
            mamans.map(m =>
                `<option value="${echapper(m.id)}">${echapper(m.nom)}</option>`
            ).join("");

        if (mamans.some(m => String(m.id) === ancienneValeur)) {
            select.value = ancienneValeur;
        }
    });
}
/* =====================================================
   ACHATS
   ===================================================== */

function actualiserApercuAchat() {
    const n = Math.max(
        0,
        Math.floor(Number(document.getElementById("achatBaques")?.value) || 0)
    );

    const pains = document.getElementById("apercuPains");
    const montant = document.getElementById("apercuMontant");
    const commission = document.getElementById("apercuCommission");

    if (pains) pains.textContent = String(n * CONFIG.painsParBaque);
    if (montant) montant.textContent = formatFC(calculerMontant(n));
    if (commission) commission.textContent = formatFC(calculerCommission(n));
}

function enregistrerAchat(e) {
    e.preventDefault();

    const mamanId = document.getElementById("achatMaman").value;
    const date = document.getElementById("achatDate").value;
    const baques = Number(document.getElementById("achatBaques").value);

    if (!mamans.some(m => String(m.id) === String(mamanId))) {
        return afficherMessage(
            "messageAchats",
            "Sélectionnez une maman valide.",
            false
        );
    }

    if (!date || date > dateLocale()) {
        return afficherMessage(
            "messageAchats",
            "Saisissez une date valide, qui ne se situe pas dans le futur.",
            false
        );
    }

    if (!Number.isInteger(baques) || baques < 1) {
        return afficherMessage(
            "messageAchats",
            "Le nombre de baques doit être un entier supérieur à zéro.",
            false
        );
    }

    const ancien = [...achats];

    achats.push({
        id: genererId(),
        mamanId,
        date,
        baques,
        pains: baques * CONFIG.painsParBaque,
        montant: calculerMontant(baques),
        commission: calculerCommission(baques)
    });

    if (!enregistrerDonnees(CONFIG.cleAchats, achats)) {
        achats = ancien;
        return;
    }

    document.getElementById("formAchat").reset();
    document.getElementById("achatDate").value = dateLocale();

    actualiserApercuAchat();
    afficherAchats();
    afficherCommissions();
    actualiserDashboard();

    afficherMessage(
        "messageAchats",
        "Achat enregistré avec succès."
    );
}

function supprimerAchat(id) {
    if (!confirm("Supprimer cet achat ? Le montant des commissions sera recalculé.")) {
        return;
    }

    const ancien = [...achats];
    achats = achats.filter(a => String(a.id) !== String(id));

    if (!enregistrerDonnees(CONFIG.cleAchats, achats)) {
        achats = ancien;
        return;
    }

    afficherAchats();
    afficherCommissions();
    afficherPaiements();
    actualiserDashboard();
}

function afficherAchats() {
    remplirSelecteurs();

    const tbody = document.getElementById("listeAchats");
    if (!tbody) return;

    const mois = document.getElementById("filtreAchats")?.value || moisCourant();

    const lignes = achats
        .filter(a => dateDansMois(a.date, mois))
        .sort((a, b) => String(b.date).localeCompare(String(a.date)));

    tbody.innerHTML = lignes.map(a => `
        <tr>
            <td>${echapper(a.date)}</td>
            <td>${echapper(obtenirNomMaman(a.mamanId))}</td>
            <td>${Number(a.baques) || 0}</td>
            <td>${Number(a.pains ?? (a.baques * CONFIG.painsParBaque)) || 0}</td>
            <td>${formatFC(a.montant ?? calculerMontant(a.baques))}</td>
            <td>${formatFC(a.commission ?? calculerCommission(a.baques))}</td>
            <td>
                <button
                    type="button"
                    class="btn btn-secondary"
                    data-supprimer-achat="${echapper(a.id)}">
                    Supprimer
                </button>
            </td>
        </tr>
    `).join("") || '<tr><td colspan="7">Aucun achat pour ce mois.</td></tr>';
}

/* =====================================================
   COMMISSIONS ET SOLDES
   ===================================================== */

function totalCommissionMaman(mamanId, mois) {
    return achats
        .filter(a =>
            String(a.mamanId) === String(mamanId) &&
            dateDansMois(a.date, mois)
        )
        .reduce(
            (s, a) => s + Number(a.commission ?? calculerCommission(a.baques) ?? 0),
            0
        );
}

function totalPaiementsMaman(mamanId, mois) {
    return paiements
        .filter(p =>
            String(p.mamanId) === String(mamanId) &&
            String(p.mois || "").slice(0, 7) === mois
        )
        .reduce((s, p) => s + (Number(p.montant) || 0), 0);
}

function afficherCommissions() {
    const mois = document.getElementById("filtreCommissions")?.value || moisCourant();

    let acquises = 0;
    let payees = 0;

    const lignes = mamans.map(m => {
        const baques = achats
            .filter(a =>
                String(a.mamanId) === String(m.id) &&
                dateDansMois(a.date, mois)
            )
            .reduce((s, a) => s + (Number(a.baques) || 0), 0);

        const commission = totalCommissionMaman(m.id, mois);
        const paye = totalPaiementsMaman(m.id, mois);
        const solde = commission - paye;

        acquises += commission;
        payees += paye;

        return `
            <tr>
                <td>${echapper(m.nom)}</td>
                <td>${baques}</td>
                <td>${formatFC(commission)}</td>
                <td>${formatFC(paye)}</td>
                <td>${formatFC(solde)}</td>
            </tr>`;
    });

    const tbody = document.getElementById("listeCommissions");

    if (tbody) {
        tbody.innerHTML = lignes.join("") ||
            '<tr><td colspan="5">Aucune maman enregistrée.</td></tr>';
    }

    const a = document.getElementById("commissionsAcquises");
    const p = document.getElementById("commissionsPayees");
    const s = document.getElementById("commissionsImpayees");

    if (a) a.textContent = formatFC(acquises);
    if (p) p.textContent = formatFC(payees);
    if (s) s.textContent = formatFC(acquises - payees);
}

/* =====================================================
   PAIEMENTS
   ===================================================== */

function actualiserApercuPaiement() {
    const mamanId = document.getElementById("paiementMaman")?.value;
    const mois = document.getElementById("paiementMois")?.value || moisCourant();

    const dette = mamanId ? totalCommissionMaman(mamanId, mois) : 0;
    const paye = mamanId ? totalPaiementsMaman(mamanId, mois) : 0;

    const d = document.getElementById("dettePaiement");
    const p = document.getElementById("dejaPaye");
    const r = document.getElementById("restePaiement");

    if (d) d.textContent = formatFC(dette);
    if (p) p.textContent = formatFC(paye);
    if (r) r.textContent = formatFC(dette - paye);

    const montant = document.getElementById("paiementMontant");

    if (montant) {
        montant.max = String(Math.max(0, dette - paye));
    }
}

function enregistrerPaiement(e) {
    e.preventDefault();

    const mamanId = document.getElementById("paiementMaman").value;
    const mois = document.getElementById("paiementMois").value;
    const date = document.getElementById("paiementDate").value;
    const montant = Number(document.getElementById("paiementMontant").value);
    const mode = document.getElementById("paiementMode").value;
    const note = document.getElementById("paiementNote").value.trim();

    if (!mamans.some(m => String(m.id) === String(mamanId))) {
        return afficherMessage(
            "messagePaiements",
            "Sélectionnez une maman valide.",
            false
        );
    }

    if (!mois || !date || date > dateLocale()) {
        return afficherMessage(
            "messagePaiements",
            "Vérifiez le mois concerné et la date du versement.",
            false
        );
    }

    if (!Number.isInteger(montant) || montant <= 0) {
        return afficherMessage(
            "messagePaiements",
            "Le montant doit être un nombre entier positif.",
            false
        );
    }

    const commission = totalCommissionMaman(mamanId, mois);
    const dejaPaye = totalPaiementsMaman(mamanId, mois);
    const solde = commission - dejaPaye;

    if (commission <= 0) {
        return afficherMessage(
            "messagePaiements",
            "Aucune commission n'est enregistrée pour cette maman et ce mois.",
            false
        );
    }

    if (montant > solde) {
        return afficherMessage(
            "messagePaiements",
            `Le montant dépasse le solde disponible (${formatFC(Math.max(0, solde))}).`,
            false
        );
    }

    const ancien = [...paiements];

    paiements.push({
        id: genererId(),
        mamanId,
        mois,
        date,
        montant,
        mode,
        note
    });

    if (!enregistrerDonnees(CONFIG.clePaiements, paiements)) {
        paiements = ancien;
        return;
    }

    document.getElementById("formPaiement").reset();
    document.getElementById("paiementDate").value = dateLocale();
    document.getElementById("paiementMois").value = moisCourant();

    actualiserApercuPaiement();
    afficherPaiements();
    afficherCommissions();
    actualiserDashboard();

    afficherMessage(
        "messagePaiements",
        "Paiement enregistré avec succès."
    );
}

function afficherPaiements() {
    remplirSelecteurs();

    const tbody = document.getElementById("listePaiements");
    if (!tbody) return;

    const mois = document.getElementById("filtrePaiements")?.value || moisCourant();

    const lignes = paiements
        .filter(p => dateDansMois(p.date, mois))
        .sort((a, b) => String(b.date).localeCompare(String(a.date)));

    tbody.innerHTML = lignes.map(p => `
        <tr>
            <td>${echapper(p.date)}</td>
            <td>${echapper(obtenirNomMaman(p.mamanId))}</td>
            <td>${echapper(p.mois || "")}</td>
            <td>${formatFC(p.montant)}</td>
            <td>${echapper(p.mode || "Espèces")}</td>
            <td>${echapper(p.note || "—")}</td>
        </tr>
    `).join("") || '<tr><td colspan="6">Aucun paiement pour ce mois.</td></tr>';

    actualiserApercuPaiement();
}

/* =====================================================
   TABLEAU DE BORD
   ===================================================== */

function actualiserDashboard() {
    const totalAchats = achats.reduce(
        (s, a) => s + (Number(a.montant ?? calculerMontant(a.baques)) || 0),
        0
    );

    const totalCommissions = achats.reduce(
        (s, a) => s + (Number(a.commission ?? calculerCommission(a.baques)) || 0),
        0
    );

    const totalPaye = paiements.reduce(
        (s, p) => s + (Number(p.montant) || 0),
        0
    );

    const valeurs = {
        totalMamans: mamans.length,
        totalAchats: formatFC(totalAchats),
        totalCommissions: formatFC(totalCommissions),
        totalPaye: formatFC(totalPaye),
        soldeGlobal: formatFC(totalCommissions - totalPaye)
    };

    Object.entries(valeurs).forEach(([id, valeur]) => {
        const el = document.getElementById(id);
        if (el) el.textContent = valeur;
    });
}

/* =====================================================
   DÉMARRAGE
   ===================================================== */

document.addEventListener("DOMContentLoaded", () => {
    try {
        initialiserDonnees();
        initialiserInterface();
        afficherMamans();
        afficherAchats();
        afficherCommissions();
        afficherPaiements();
        actualiserDashboard();
        injecterEcranConnexion();

        if (
            sessionStorage.getItem(CONFIG.cleSession) === "1" &&
            localStorage.getItem(CONFIG.cleAuth)
        ) {
            ouvrirApplication();
        } else {
            sessionStorage.removeItem(CONFIG.cleSession);
            verrouillerApplication();
        }
    } catch (erreur) {
        console.error("Erreur d'initialisation de l'application :", erreur);

        alert(
            "Une erreur est survenue au démarrage. Ouvrez la console du navigateur pour consulter le détail."
        );
    }
});