GURMU DESIGNED PERIODIC TABLE

HOW TO OPEN ON ANDROID
1. Extract the ZIP.
2. Open the extracted folder and tap index.html.
3. Choose Chrome or another modern browser.
4. Enable Auto-rotate and turn the phone sideways for the best view.
5. Tap an element to see its information.

FEATURES
- All 118 elements
- Responsive landscape-friendly layout
- Search by name, symbol, or atomic number
- Filter by element family and room-temperature state
- Color-coded element families
- Element details: atomic number, symbol, approximate atomic mass, family, group, period, block, state, shell distribution, protons, electrons, and study notes
- Full-screen and print buttons
- Runs offline with no external libraries

NOTE
This is an educational reference. Atomic masses are approximate. Some details of superheavy elements are uncertain. This compact edition includes electron configurations for the first 30 elements; for other elements it provides shell distribution and family information.
