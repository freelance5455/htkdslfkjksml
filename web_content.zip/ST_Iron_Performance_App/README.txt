ST | IRON PERFORMANCE — Offline-first web app

HOW TO USE
1. Extract the ZIP.
2. For best PWA/offline installation, host the folder on HTTPS (for example GitHub Pages), open it in Chrome on Android, then use the browser menu → Add to Home screen / Install.
3. The app stores clients and programs in this browser's localStorage. Export a JSON backup regularly.
4. Client session button immediately records a timestamp and reduces remaining sessions. Session history allows undoing the latest entry.
5. CSV import/export works offline. XLSX import is not bundled in this starter version; save Excel workbooks as CSV before importing. Excel exports are CSV files that open in Excel.
6. The landscape button changes the layout. Actual device rotation depends on Android's Auto-rotate setting and browser support.

CSV headers for clients:
ID,Name,Phone,Age,TotalSessions,Subscription,Date,Private,InBody

CSV headers for programs:
ClientID,ClientName,ProgramName,Day,Exercise,Sets,Reps,Weight,Notes

Privacy and backup:
Data stays in the browser on this device unless you export it. Clearing browser/site data may erase it. Keep backups safe.

V2 WORKOUT EDITOR IMPROVEMENTS
- Workout editor uses almost the full tablet viewport.
- Exercise-name column is wider.
- Day tabs let you filter rows by day; add a new day with the Day button.
- Editor navigation shows existing client programs and offers a quick client switch.

V3 FEATURES
- Each program card has separate View Program and Edit Program actions.
- View mode is read-only and shows each training day in a separate section.
- Exercise rows support Normal, Superset, and Circuit types. Superset/Circuit items are displayed in larger method cards in view mode.
- Excel/CSV program exports include a Type column.

V4: CSV/JSON file import handler is connected; paste from Excel (tab-separated clipboard) is supported; program view has a print button. Direct XLSX/XLS parsing is not included offline: save as CSV UTF-8 or paste copied cells.
