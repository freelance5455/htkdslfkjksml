ST ATHLETIX — Offline-first web app

HOW TO USE
1. Extract the ZIP.
2. For best PWA/offline installation, host the folder on HTTPS (for example GitHub Pages), open it in Chrome on Android, then use the browser menu → Add to Home screen / Install.
3. The app stores clients and programs in this browser's localStorage. Export a JSON backup regularly.
4. Client session button immediately records a timestamp and reduces remaining sessions. Session history allows undoing the latest entry.
5. CSV import/export works offline. XLSX import is not bundled in this starter version; save Excel workbooks as CSV before importing. Excel exports are CSV files that open in Excel.
6. The landscape button changes the layout. Actual device rotation depends on Android's Auto-rotate setting and browser support.

CSV headers for clients:
ID,Name,Phone,Age,TotalSessions,Subscription,Date,Private,InBody

CSV headers for programs:
ClientID,ClientName,ProgramName,Day,Exercise,Sets,Reps,Weight,Notes

Privacy and backup:
Data stays in the browser on this device unless you export it. Clearing browser/site data may erase it. Keep backups safe.

V2 WORKOUT EDITOR IMPROVEMENTS
- Workout editor uses almost the full tablet viewport.
- Exercise-name column is wider.
- Day tabs let you filter rows by day; add a new day with the Day button.
- Editor navigation shows existing client programs and offers a quick client switch.

V3 FEATURES
- Each program card has separate View Program and Edit Program actions.
- View mode is read-only and shows each training day in a separate section.
- Exercise rows support Normal, Superset, and Circuit types. Superset/Circuit items are displayed in larger method cards in view mode.
- Excel/CSV program exports include a Type column.

V4: CSV/JSON file import handler is connected; paste from Excel (tab-separated clipboard) is supported; program view has a print button. Direct XLSX/XLS parsing is not included offline: save as CSV UTF-8 or paste copied cells.

V5 PROFESSIONAL UPDATE
- Expanded InBody profile: measurement date, weight, height, body-fat percentage and mass, skeletal muscle mass, lean mass, BMI, visceral fat, BMR, body water and mineral/bone mass, plus notes. Previous measurement snapshots are retained locally.
- Workout rows now include Rest and RIR fields; these are included in CSV exports and read-only program view.
- Added Arabic/English toggle for main navigation and main page controls. Some detailed labels and messages remain Arabic.
- Back up data before replacing app files.

V6 SPORT LIBRARIES
- Added separate CrossFit WOD templates: AMRAP, For Time, EMOM, strength and skill.
- Added sports conditioning templates for football, basketball, combat sports, tennis, swimming and volleyball.
- Added calisthenics progressions from beginner to advanced.
- Added a searchable stretching reference for static and dynamic stretches across chest, back, shoulders, arms, hips, quads, hamstrings, glutes, calves, ankles and trunk.
- Each library has search/filter and a print-library button. These are starting templates; adjust exercises, volume and intensity to the athlete, equipment, sport calendar and injury status.

V7 EXPANDED SPORT CONDITIONING & STRETCH ILLUSTRATIONS
- The sports conditioning library now provides 50 exercise/drill cards for each of six sports: football, basketball, combat sports, tennis, swimming and volleyball (300 cards total), grouped by beginner/intermediate/advanced progression labels.
- Stretching cards now include offline embedded vector illustrations that remain available without an internet connection.
- The illustrations are schematic guides, not clinical/anatomical images. Adjust loading and exercise selection to the athlete and sport demands.


EXERCISE LIBRARY UPDATE (v8)
- Includes 600+ built-in exercises available offline.
- Muscle groups include chest, back, legs, biceps, triceps, shoulders, forearms, ankles, calves, and Core/ABS.
- Includes 50 CrossFit and 50 Calisthenics movements.
- Search and filter by group and level, then add directly to the open client program.
- Manual exercise entry, supersets, and circuits remain available.
- Exercise library descriptions and equipment/level tags are stored in app.js and do not require internet access.


ST ATHLETIX update: dedicated CrossFit and Calisthenics pages now include 50 movements each from the searchable built-in exercise library. New logo is used in the header and as a subtle, non-obstructive page watermark.
