const $=id=>document.getElementById(id);
const load=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}};
let clients=load('st_clients',[]), programs=load('st_programs',[]), activeDay='__all__';
function persist(){localStorage.setItem('st_clients',JSON.stringify(clients));localStorage.setItem('st_programs',JSON.stringify(programs))}
function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function toast(s){$('toast').textContent=s;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),2400)}
function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function switchPage(page){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===page));document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.page===page))}
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>switchPage(b.dataset.page));
$('rotateBtn').onclick=()=>{document.body.classList.toggle('landscape');toast('تم تبديل تخطيط العرض. لو التدوير التلقائي مقفول، فعّله من إعدادات الجهاز.')};
function renderClients(){let q=$('searchClients').value.toLowerCase();let list=clients.filter(c=>[c.id,c.name,c.phone].join(' ').toLowerCase().includes(q));$('clientList').innerHTML=list.length?list.map(c=>{let used=(c.sessions||[]).length,total=+c.total||0,remain=Math.max(0,total-used),pct=total?Math.min(100,used/total*100):0;return `<article class="client-card"><div class="client-top"><div><div class="client-id">ID ${esc(c.id)}</div><h3>${esc(c.name)}</h3><div class="meta">${esc(c.phone||'بدون هاتف')} · ${c.age?esc(c.age)+' سنة':'السن غير مسجل'}<br>${esc(c.subscription||'بدون نوع اشتراك')} ${c.date?'· '+esc(c.date):''}<br>برايفت: ${esc(c.private||'—')} · InBody: ${esc(c.inbody||'—')}</div></div></div><div class="session-row"><div><div class="session-count">${used} / ${total} سيشن</div><small>المتبقي: ${remain}</small></div><button class="session-btn" onclick="addSession('${c.key}')">＋ Session</button></div><div class="progress"><span style="width:${pct}%"></span></div><div class="card-actions" style="margin-top:12px"><button class="small-btn" onclick="editClient('${c.key}')">تعديل</button><button class="small-btn" onclick="showHistory('${c.key}')">سجل السيشنات</button><button class="small-btn" onclick="newProgramFor('${c.key}')">＋ جدول تمرين</button><button class="small-btn" onclick="deleteClient('${c.key}')">حذف</button></div></article>`}).join(''):'<div class="empty">لا يوجد عملاء حتى الآن. اضغط «عميل جديد» لإضافة أول عميل.</div>'}
function addSession(key){let c=clients.find(x=>x.key===key);if(!c)return;c.sessions=c.sessions||[];if(c.sessions.length>=(+c.total||0)){if(!confirm('العميل استهلك كل السيشنات المسجلة. تسجيل سيشن إضافية سيجعل الرصيد بالسالب. هل تريد المتابعة؟'))return}c.sessions.push({at:new Date().toISOString()});persist();renderClients();toast('تم تسجيل السيشن وخصمها فورًا.')}
function showHistory(key){let c=clients.find(x=>x.key===key);if(!c)return;let h=(c.sessions||[]).map((s,i)=>`${i+1}. ${new Date(s.at).toLocaleString()}`).join('\n')||'لا توجد سيشنات مسجلة';let undo=confirm(`سجل سيشنات ${c.name}:\n${h}\n\nاضغط موافق للتراجع عن آخر سيشن، أو إلغاء للإغلاق.`);if(undo&&c.sessions.length){c.sessions.pop();persist();renderClients();toast('تم إلغاء آخر سيشن وإرجاعها للرصيد.')} }
function openClient(c){$('clientForm').reset();$('editClientId').value=c?.key||'';$('clientDialogTitle').textContent=c?'تعديل بيانات العميل':'عميل جديد';$('cId').value=c?.id||'';$('cName').value=c?.name||'';$('cPhone').value=c?.phone||'';$('cAge').value=c?.age||'';$('cTotal').value=c?.total??0;$('cSubscription').value=c?.subscription||'';$('cDate').value=c?.date||'';$('cPrivate').value=c?.private||'';$('cInbody').value=c?.inbody||'';$('clientDialog').showModal()}
$('addClientBtn').onclick=()=>openClient(null);
window.editClient=key=>openClient(clients.find(c=>c.key===key));
$('saveClient').onclick=e=>{e.preventDefault();let key=$('editClientId').value,c=clients.find(x=>x.key===key);let obj={key:key||uid(),id:$('cId').value.trim(),name:$('cName').value.trim(),phone:$('cPhone').value.trim(),age:$('cAge').value,total:+$('cTotal').value||0,subscription:$('cSubscription').value.trim(),date:$('cDate').value,private:$('cPrivate').value.trim(),inbody:$('cInbody').value.trim(),sessions:c?.sessions||[]};if(!obj.id||!obj.name){toast('أدخل ID والاسم');return}if(c)Object.assign(c,obj);else clients.unshift(obj);persist();$('clientDialog').close();renderClients();renderPrograms();toast('تم حفظ بيانات العميل')}
window.deleteClient=key=>{let c=clients.find(x=>x.key===key);if(c&&confirm('حذف العميل؟ لن يتم حذف جداول التمرين المرتبطة تلقائيًا.')){clients=clients.filter(x=>x.key!==key);persist();renderClients()}};
$('searchClients').oninput=renderClients;
function exerciseRow(ex={}){let tr=document.createElement('tr');tr.innerHTML=`<td><input placeholder="Day 1" value="${esc(ex.day||(activeDay!=='__all__'?activeDay:'Day 1'))}"></td><td><div style="display:grid;gap:5px"><select class="exercise-type-select" aria-label="نوع التمرين"><option value="normal" ${(!ex.type||ex.type==='normal')?'selected':''}>تمرين عادي</option><option value="superset" ${ex.type==='superset'?'selected':''}>Superset</option><option value="circuit" ${ex.type==='circuit'?'selected':''}>Circuit</option></select><input placeholder="اسم التمرين" value="${esc(ex.exercise||'')}"></div></td><td><input type="number" min="0" value="${esc(ex.sets||'')}"></td><td><input value="${esc(ex.reps||'')}" placeholder="8-12"></td><td><input value="${esc(ex.weight||'')}" placeholder="kg"></td><td><input value="${esc(ex.notes||'')}" placeholder="ملاحظات"></td><td><button type="button" class="small-btn remove">×</button></td>`;tr.querySelector('.remove').onclick=()=>{tr.remove();renderDayTabs()};tr.querySelector('td:first-child input').onchange=renderDayTabs;$('exerciseRows').appendChild(tr)}
function fillClientSelect(selected){$('pClient').innerHTML=clients.map(c=>`<option value="${esc(c.key)}" ${c.key===selected?'selected':''}>${esc(c.id)} - ${esc(c.name)}</option>`).join('')}

function renderProgramNav(selectedKey){
  const nav=$('programNav');
  const current=programs.find(p=>p.key===selectedKey);
  const currentClient=current?current.clientKey:($('pClient').value||'');
  const client=clients.find(c=>c.key===currentClient);
  nav.innerHTML=`<button type="button" class="active" onclick="switchEditorClient()">↔ تغيير العميل</button>`+
    programs.map(p=>{let c=clients.find(x=>x.key===p.clientKey);return `<button type="button" class="${p.key===selectedKey?'active':''}" onclick="jumpProgram('${p.key}')">${esc(c?.name||'عميل')} · ${esc(p.name)}</button>`}).join('');
}
window.switchEditorClient=()=>{if(!clients.length)return;let current=$('pClient').value;let idx=clients.findIndex(c=>c.key===current);let next=clients[(idx+1)%clients.length];fillClientSelect(next.key);renderProgramNav($('editProgramId').value);toast('تم اختيار العميل: '+next.name)};
window.jumpProgram=key=>{let p=programs.find(x=>x.key===key);if(!p)return;openProgram(p)};
function renderDayTabs(){
  let rows=[...$('exerciseRows').querySelectorAll('tr')], days=[...new Set(rows.map(r=>r.querySelector('td input')?.value.trim()||'بدون يوم'))];
  if(!days.length)days=['Day 1'];
  $('dayTabs').innerHTML=`<button type="button" class="day-tab ${activeDay==='__all__'?'active':''}" onclick="filterEditorDay('__all__')">كل الأيام</button>`+days.map(d=>`<button type="button" class="day-tab ${activeDay===d?'active':''}" onclick="filterEditorDay('${esc(d).replace(/'/g,"&#39;")}')">${esc(d)}</button>`).join('')+
  `<button type="button" class="day-tab" onclick="addDayRow()">＋ يوم جديد</button>`;
  rows.forEach(r=>{let d=r.querySelector('td input')?.value.trim()||'بدون يوم';r.style.display=activeDay==='__all__'||activeDay===d?'':'none'});
}
window.filterEditorDay=d=>{activeDay=d;renderDayTabs()};
window.addDayRow=()=>{let day='Day '+([...new Set([...$('exerciseRows').querySelectorAll('tr td:first-child input')].map(x=>x.value))].length+1);exerciseRow({day});activeDay=day;renderDayTabs()};

function openProgram(p=null,clientKey=''){$('programForm').reset();activeDay='__all__';$('editProgramId').value=p?.key||'';$('programDialogTitle').textContent=p?'تعديل جدول':'جدول تمرين جديد';fillClientSelect(p?.clientKey||clientKey);$('pName').value=p?.name||'';$('exerciseRows').innerHTML='';(p?.exercises?.length?p.exercises:[{day:'Day 1'}]).forEach(exerciseRow);renderProgramNav(p?.key||'');renderDayTabs();$('programDialog').showModal()}
$('addProgramBtn').onclick=()=>{if(!clients.length){toast('أضف عميلًا أولًا');return}openProgram()};
window.newProgramFor=key=>openProgram(null,key);
$('addExercise').onclick=()=>{exerciseRow({day:activeDay!=='__all__'?activeDay:'Day 1'});renderDayTabs()};
$('addSuperset').onclick=()=>{exerciseRow({day:activeDay!=='__all__'?activeDay:'Day 1',type:'superset',exercise:'Superset A + B',notes:'Superset'});renderDayTabs()};
$('addCircuit').onclick=()=>{exerciseRow({day:activeDay!=='__all__'?activeDay:'Day 1',type:'circuit',exercise:'Circuit Station',notes:'Circuit Training'});renderDayTabs()};
$('saveProgram').onclick=e=>{e.preventDefault();let key=$('editProgramId').value,p=programs.find(x=>x.key===key),trs=[...$('exerciseRows').querySelectorAll('tr')],exercises=trs.map(tr=>{let a=[...tr.querySelectorAll('input')],type=tr.querySelector('select.exercise-type-select')?.value||'normal';return {day:a[0].value,type,exercise:a[1].value,sets:a[2].value,reps:a[3].value,weight:a[4].value,notes:a[5].value}}).filter(x=>x.exercise);let obj={key:key||uid(),clientKey:$('pClient').value,name:$('pName').value.trim(),exercises};if(!obj.name||!obj.clientKey){toast('اختر العميل واكتب اسم البرنامج');return}if(p)Object.assign(p,obj);else programs.unshift(obj);persist();$('programDialog').close();renderPrograms();toast('تم حفظ جدول التمرين')};
function renderPrograms(){let q=$('searchPrograms').value.toLowerCase(),list=programs.filter(p=>{let c=clients.find(x=>x.key===p.clientKey);return (p.name+' '+(c?.name||'')).toLowerCase().includes(q)});$('programList').innerHTML=list.length?list.map(p=>{let c=clients.find(x=>x.key===p.clientKey);return `<article class="program-card"><h3>${esc(p.name)}</h3><div class="meta">العميل: ${esc(c?.name||'عميل محذوف')} · ${p.exercises.length} تمرين</div><ul>${p.exercises.slice(0,5).map(x=>`<li>${esc(x.day)} — ${esc(x.exercise)} · ${esc(x.sets)} × ${esc(x.reps)} ${x.weight?'· '+esc(x.weight):''} ${x.notes?'('+esc(x.notes)+')':''}</li>`).join('')}${p.exercises.length>5?'<li>…</li>':''}</ul><div class="card-actions"><button class="small-btn" onclick="viewProgram('${p.key}')">عرض الجدول</button><button class="small-btn" onclick="editProgram('${p.key}')">تعديل الجدول</button><button class="small-btn" onclick="deleteProgram('${p.key}')">حذف</button></div></article>`}).join(''):'<div class="empty">لا توجد جداول بعد.</div>'}

let viewingProgramKey=null;
function methodLabel(type){return type==='superset'?'SUPERSET':type==='circuit'?'CIRCUIT TRAINING':'تمرين عادي'}
function renderReadOnlyProgram(p){
 const c=clients.find(x=>x.key===p.clientKey);
 $('viewProgramTitle').textContent=p.name;
 $('viewProgramSubtitle').textContent=`${c?.id||''} · ${c?.name||'عميل'} · ${p.exercises.length} تمرين`;
 const byDay={};(p.exercises||[]).forEach((x,i)=>{let d=x.day||'بدون يوم';(byDay[d] ||= []).push({...x,_i:i})});
 $('viewProgramContent').innerHTML=Object.entries(byDay).map(([day,items])=>{
   let out=`<section class="view-day"><h3 class="view-day-title">${esc(day)}</h3>`;
   let normal=items.filter(x=>!x.type||x.type==='normal');
   if(normal.length){out+=`<div class="view-exercise header"><div>التمرين</div><div>Sets</div><div>Reps</div><div>Weight</div><div class="view-notes">ملاحظات</div></div>`+normal.map(x=>`<div class="view-exercise"><div class="exercise-name">${esc(x.exercise)}</div><div>${esc(x.sets||'—')}</div><div>${esc(x.reps||'—')}</div><div>${esc(x.weight||'—')}</div><div class="view-notes">${esc(x.notes||'—')}</div></div>`).join('')}
   let special=items.filter(x=>x.type==='superset'||x.type==='circuit');
   special.forEach((x,i)=>{let cl=x.type==='circuit'?'circuit':'superset';out+=`<div class="method-card ${cl}"><div class="method-heading"><strong>${x.type==='circuit'?'Circuit Training':'Superset'} ${i+1}</strong><span>${x.type==='circuit'?'نفّذ المحطات بالتتابع':'نفّذ التمرينين بالتتابع'}</span></div><div class="method-items"><div class="method-item"><span class="method-badge">${methodLabel(x.type)}</span><b>${esc(x.exercise||'تمرين بدون اسم')}</b><div class="method-metrics">Sets: ${esc(x.sets||'—')}<br>Reps: ${esc(x.reps||'—')}<br>Weight: ${esc(x.weight||'—')}<br>${esc(x.notes||'')}</div></div></div></div>`});
   return out+'</section>'
 }).join('')||'<div class="empty">لا توجد تمارين في هذا الجدول.</div>';
}
window.viewProgram=key=>{let p=programs.find(x=>x.key===key);if(!p)return;viewingProgramKey=key;renderReadOnlyProgram(p);$('viewProgramDialog').showModal()};
$('closeViewProgram').onclick=()=>$('viewProgramDialog').close();
$('closeViewProgram2').onclick=()=>$('viewProgramDialog').close();
$('printViewProgram').onclick=()=>window.print();
$('viewToEdit').onclick=()=>{let p=programs.find(x=>x.key===viewingProgramKey);$('viewProgramDialog').close();if(p)openProgram(p)};

window.editProgram=key=>openProgram(programs.find(p=>p.key===key));window.deleteProgram=key=>{if(confirm('حذف الجدول؟')){programs=programs.filter(p=>p.key!==key);persist();renderPrograms()}};$('searchPrograms').oninput=renderPrograms;
function csvEscape(v){let s=String(v??'');return '"'+s.replace(/"/g,'""')+'"'}
function download(name,content,type='text/csv;charset=utf-8;'){let a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff',content],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
$('exportClients').onclick=()=>download('iron-performance-clients.csv',[['ID','Name','Phone','Age','TotalSessions','UsedSessions','RemainingSessions','Subscription','Date','Private','InBody'],...clients.map(c=>[c.id,c.name,c.phone,c.age,c.total,(c.sessions||[]).length,Math.max(0,(+c.total||0)-(c.sessions||[]).length),c.subscription,c.date,c.private,c.inbody])].map(r=>r.map(csvEscape).join(',')).join('\r\n'));
$('exportPrograms').onclick=()=>download('iron-performance-programs.csv',[['ClientID','ClientName','ProgramName','Day','Type','Exercise','Sets','Reps','Weight','Notes'],...programs.flatMap(p=>{let c=clients.find(x=>x.key===p.clientKey);return p.exercises.map(x=>[c?.id,c?.name,p.name,x.day,x.type||'normal',x.exercise,x.sets,x.reps,x.weight,x.notes])})].map(r=>r.map(csvEscape).join(',')).join('\r\n'));
$('backupBtn').onclick=()=>download('iron-performance-backup.json',JSON.stringify({version:1,createdAt:new Date().toISOString(),clients,programs},null,2),'application/json');
function parseCSV(text){let rows=[],row=[],field='',quoted=false;for(let i=0;i<text.length;i++){let ch=text[i],next=text[i+1];if(ch==='"'&&quoted&&next==='"'){field+='"';i++}else if(ch==='"')quoted=!quoted;else if(ch===','&&!quoted){row.push(field);field=''}else if((ch==='\n'||ch==='\r')&&!quoted){if(ch==='\r'&&next==='\n')i++;row.push(field);if(row.some(v=>v.trim()))rows.push(row);row=[];field=''}else field+=ch}row.push(field);if(row.some(v=>v.trim()))rows.push(row);return rows}
function val(row,i){return i>=0?(row[i]||'').trim():''}
function importRows(rows){
 if(!rows.length)throw Error('لا توجد بيانات في الملف');
 let heads=rows.shift().map(h=>h.trim().toLowerCase()),idx=k=>heads.indexOf(k.toLowerCase()),n=0;
 if(heads.includes('name')&&heads.includes('id')){
  rows.forEach(r=>{let id=val(r,idx('id'))||uid(),name=val(r,idx('name'));if(!name)return;let old=clients.find(c=>String(c.id)===String(id));let obj={key:old?.key||uid(),id,name,phone:val(r,idx('phone')),age:val(r,idx('age')),total:+(val(r,idx('totalsessions'))||val(r,idx('total sessions'))||val(r,idx('total'))||0),subscription:val(r,idx('subscription')),date:val(r,idx('date')),private:val(r,idx('private')),inbody:val(r,idx('inbody')),sessions:old?.sessions||[]};if(old)Object.assign(old,obj);else clients.push(obj);n++});
  persist();renderClients();return `تم استيراد/تحديث ${n} عميلًا.`;
 }
 if(heads.includes('exercise')&&heads.includes('programname')){
  rows.forEach(r=>{let id=val(r,idx('clientid')),c=clients.find(x=>String(x.id)===String(id));if(!c)return;let name=val(r,idx('programname'))||'Imported Program',p=programs.find(x=>x.clientKey===c.key&&x.name===name);if(!p){p={key:uid(),clientKey:c.key,name,exercises:[]};programs.push(p)}p.exercises.push({day:val(r,idx('day')),type:val(r,idx('type'))||'normal',exercise:val(r,idx('exercise')),sets:val(r,idx('sets')),reps:val(r,idx('reps')),weight:val(r,idx('weight')),notes:val(r,idx('notes'))});n++});
  persist();renderPrograms();return `تم استيراد ${n} تمرينًا. يجب أن يطابق ClientID قيمة ID لعميل موجود.`;
 }
 throw Error('عناوين الأعمدة غير معروفة. استخدم ID وName للعملاء، أو ClientID وProgramName وExercise للتمارين.');
}
$('importFile').onchange=async e=>{
 const f=e.target.files[0];if(!f)return;$('importStatus').textContent='جارٍ قراءة الملف…';
 try{
  if(/\.json$/i.test(f.name)){const d=JSON.parse(await f.text());if(!Array.isArray(d.clients))throw Error('ملف JSON غير صالح');clients=d.clients;programs=d.programs||[];persist();renderClients();renderPrograms();$('importStatus').textContent='تم استيراد النسخة الاحتياطية بنجاح.'}
  else if(/\.csv$/i.test(f.name))$('importStatus').textContent=importRows(parseCSV(await f.text()));
  else if(/\.(xlsx|xls)$/i.test(f.name))throw Error('ملفات XLSX/XLS غير مدعومة مباشرة في النسخة الأوفلاين الحالية. احفظها من Excel بصيغة CSV UTF-8 أو انسخ الخلايا والصقها في خانة النسخ واللصق.');
  else throw Error('نوع الملف غير مدعوم.');
 }catch(err){$('importStatus').textContent='لم يتم الاستيراد: '+err.message}e.target.value='';
};
$('downloadTemplateBtn').onclick=()=>download('iron-performance-clients-template.csv',[['ID','Name','Phone','Age','TotalSessions','Subscription','Date','Private','InBody'],['001','Ahmed','01000000000','25','20','Personal Training','2026-10-22','No','Weight 80 kg']].map(r=>r.map(csvEscape).join(',')).join('\r\n'));
$('pasteImportBtn').onclick=()=>{
 const raw=$('pasteArea').value.trim();if(!raw){$('pasteStatus').textContent='الصق البيانات أولًا.';return}
 try{let normalized=raw.includes('\t')?raw.replace(/\t/g,','):raw;$('pasteStatus').textContent=importRows(parseCSV(normalized));toast('تم استيراد البيانات الملصوقة')}
 catch(err){$('pasteStatus').textContent='لم يتم الاستيراد: '+err.message}
};
$('restoreFile').onchange=async e=>{let f=e.target.files[0];if(!f)return;try{let d=JSON.parse(await f.text());if(!Array.isArray(d.clients)||!Array.isArray(d.programs))throw Error('ملف النسخة الاحتياطية غير صالح');if(confirm('استبدال البيانات الحالية بالنسخة المحددة؟')){clients=d.clients;programs=d.programs;persist();renderClients();renderPrograms();toast('تمت استعادة النسخة الاحتياطية')}}catch(err){toast(err.message)}e.target.value=''};
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
renderClients();renderPrograms();