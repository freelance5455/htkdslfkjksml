package com.spidersystem.app

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var muted = false
    private var ttsReady = false
    private val handler = Handler(Looper.getMainLooper())
    private val restartListening = Runnable { if (listening) startRecognition() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.rgb(5, 8, 16)
        window.navigationBarColor = Color.rgb(5, 8, 16)
        hideSystemUi()
        tts = TextToSpeech(this, this)
        web = WebView(this)
        web.setBackgroundColor(Color.rgb(5, 8, 16))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            beginListening()
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41)
        }
    }

    private fun hideSystemUi() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("es", "ES"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            if (!ttsReady) tts?.setLanguage(Locale("es"))
            runOnUiThread { speak("KAREN en línea. Esperando instrucciones.") }
        }
    }

    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setUi("RECONOCIMIENTO NO DISPONIBLE", "Este dispositivo no tiene un servicio de reconocimiento de voz configurado.")
            speak("No encuentro un servicio de reconocimiento de voz en este dispositivo.")
            return
        }
        listening = true
        if (recognizer == null) recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = setUi("ESCUCHANDO", "Te escucho. Di KAREN y tu orden.")
            override fun onBeginningOfSpeech() = setUi("TE ESCUCHO", "Procesando voz…")
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() = setUi("PROCESANDO", "Interpretando instrucción…")
            override fun onError(error: Int) {
                if (listening) {
                    setUi("REINTENTANDO", errorLabel(error))
                    handler.removeCallbacks(restartListening)
                    handler.postDelayed(restartListening, 650)
                }
            }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (spoken.isNotBlank()) handleCommand(spoken)
                if (listening) {
                    handler.removeCallbacks(restartListening)
                    handler.postDelayed(restartListening, 450)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!partial.isNullOrBlank()) setUi("TE ESCUCHO", partial.uppercase(Locale.getDefault()))
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        startRecognition()
    }

    private fun startRecognition() {
        if (!listening || isFinishing) return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-PY")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-PY")
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            handler.postDelayed(restartListening, 1000)
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.lowercase(Locale.ROOT).replace(Regex("[áàä]"), "a")
            .replace(Regex("[éèë]"), "e").replace(Regex("[íìï]"), "i")
            .replace(Regex("[óòö]"), "o").replace(Regex("[úùü]"), "u")
            .replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
        setUi("COMANDO RECIBIDO", raw.uppercase(Locale.getDefault()))
        val clean = command.removePrefix("oye karen").removePrefix("karen").trim()
        if (clean.isBlank() && (command.contains("karen") || command.contains("oye"))) {
            speak("Dime, Peter."); return
        }
        when {
            clean.contains("silencio") || clean.contains("callate") || clean.contains("cancela voz") -> {
                muted = true; tts?.stop(); setUi("MODO SILENCIO", "La escucha continúa activa. Di KAREN, habla para reactivar mi voz.")
            }
            clean.contains("habla") || clean.contains("reactiva voz") -> { muted = false; speak("Voz reactivada.") }
            clean.contains("hora") -> speak("Son las ${SimpleDateFormat("HH:mm", Locale("es", "PY")).format(Date())}.")
            clean.contains("fecha") || clean.contains("dia es hoy") -> speak("Hoy es ${SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "PY")).format(Date())}.")
            clean.contains("estado") || clean.contains("como estas") -> speak("SPIDER SYSTEM activo. Reconocimiento de voz conectado. Interfaz lista.")
            clean.contains("ayuda") || clean.contains("que puedes hacer") || clean.contains("comandos") -> speak("Puedes pedirme la hora, la fecha, el estado del sistema, abrir la cámara, abrir ajustes, o activar el modo silencio. Di KAREN antes de cada orden.")
            clean.contains("camara") || clean.contains("camera") -> openCamera()
            clean.contains("ajustes") || clean.contains("configuracion") -> openSettings()
            clean.contains("reinicia escucha") || clean.contains("reanuda escucha") -> { listening = true; speak("Escucha activa.") }
            clean.contains("hola") || clean.contains("buenos dias") || clean.contains("buenas tardes") || clean.contains("buenas noches") -> speak("Hola, Peter. Estoy en línea.")
            else -> speak("No reconocí esa orden. Di KAREN, ayuda, para escuchar los comandos disponibles.")
        }
    }

    private fun openCamera() {
        try {
            startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
            speak("Abriendo cámara.")
        } catch (_: ActivityNotFoundException) { speak("No encuentro una aplicación de cámara.") }
    }

    private fun openSettings() {
        try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)); speak("Abriendo ajustes.") }
        catch (_: Exception) { speak("No pude abrir los ajustes.") }
    }

    private fun speak(message: String) {
        setUi("KAREN", message)
        if (!muted && ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "karen-${System.currentTimeMillis()}")
    }

    private fun setUi(state: String, message: String) {
        if (!::web.isInitialized) return
        val safeState = state.replace("\\", "\\\\").replace("'", "\\'")
        val safeMessage = message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
        runOnUiThread { web.evaluateJavascript("window.setSystemState('$safeState','$safeMessage')", null) }
    }

    private fun errorLabel(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Servicio de voz sin conexión; reintentando."
        SpeechRecognizer.ERROR_AUDIO -> "Problema de audio; reintentando."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Falta permiso para usar el micrófono."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Servicio ocupado; reintentando."
        else -> "No te escuché. Vuelve a hablar."
    }

    inner class Bridge {
        @JavascriptInterface fun ready() { runOnUiThread { setUi("SISTEMA INICIADO", "KAREN está preparando el reconocimiento de voz.") } }
        @JavascriptInterface fun speakTest() { runOnUiThread { speak("Prueba de audio. KAREN funciona.") } }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) beginListening()
        else { setUi("MICRÓFONO BLOQUEADO", "Necesito permiso de micrófono para obedecer comandos de voz."); speak("Necesito permiso de micrófono para funcionar.") }
    }

    override fun onPause() {
        super.onPause()
        try { recognizer?.cancel() } catch (_: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        if (listening && ::web.isInitialized) handler.postDelayed(restartListening, 500)
    }

    override fun onDestroy() {
        listening = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
