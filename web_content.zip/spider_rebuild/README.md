# SPIDER SYSTEM 1.0 — Android

Rebuild nativo para Android (minSdk 23) con interfaz HUD inspirada en la estética tecnológica roja/azul de Spider-Man: Homecoming. No contiene botones en pantalla: la interacción principal es por voz.

## Comandos implementados

Di “KAREN” y luego una orden:
- “ayuda” / “qué puedes hacer”
- “qué hora es”
- “qué fecha es”
- “estado del sistema”
- “abre cámara”
- “abre ajustes”
- “silencio”
- “KAREN, habla” / “reactiva voz”

## Requisitos y límites reales

- KAREN usa el motor TextToSpeech instalado en Android.
- El reconocimiento usa el servicio `SpeechRecognizer` del dispositivo y solicita preferencia sin conexión; que funcione totalmente offline depende de que Android tenga instalado un paquete de reconocimiento español offline. Algunos proveedores requieren internet.
- El permiso de micrófono se solicita al iniciar. Si se deniega, los comandos no pueden funcionar.
- No hay una IA conversacional conectada: las órdenes incluidas son comandos locales explícitos. No se envía audio a un servidor de SPIDER SYSTEM.

## Compilar

Abrir la carpeta en Android Studio y compilar `app` con JDK 17 / Gradle 8.9 / Android Gradle Plugin 8.7.3. También se incluye GitHub Actions para generar un APK debug al subir el proyecto a un repositorio.
