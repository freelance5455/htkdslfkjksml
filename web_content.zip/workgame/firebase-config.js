// Firebase web app configuration. Copy these values from Firebase Console > Project settings > Your apps.
// Do not paste private service-account keys here. These are public web-app identifiers; secure access with Firestore Rules.
export const firebaseConfig = {
  apiKey: "BURAYA_API_KEY",
  authDomain: "BURAYA_PROJECT_ID.firebaseapp.com",
  projectId: "BURAYA_PROJECT_ID",
  storageBucket: "BURAYA_PROJECT_ID.appspot.com",
  messagingSenderId: "BURAYA_MESSAGING_SENDER_ID",
  appId: "BURAYA_APP_ID"
};
