BLOCK ADVENTURE 3D — ÇEVRİMİÇİ SİSTEM KURULUMU

Bu paket, Firebase tabanlı hesap/oturum, kullanıcı adı dizini, arkadaşlık istekleri, oda katılımı, oda sohbeti ve konum senkronizasyonu istemci kodunu içerir. Ancak bir Firebase projesi bu sohbetten senin adına oluşturulmadı; bu nedenle yapılandırma yapılmadan çevrimiçi özellikler çalışmaz. Bu eksikliği gizlemiyoruz.

KURULUM
1. https://console.firebase.google.com/ adresinde yeni proje oluştur.
2. Project settings > General > Your apps bölümünden Web uygulaması ekle ve firebaseConfig değerlerini al.
3. firebase-config.js içindeki BURAYA_... değerlerini kendi projenin değerleriyle değiştir.
4. Firebase Console > Authentication > Sign-in method > Email/Password seçeneğini etkinleştir.
5. Firestore Database oluştur. firestore.rules dosyasının içeriğini Firestore > Rules alanına yapıştırıp yayımla.
6. index.html, online.js ve firebase-config.js dosyalarını aynı web kök klasöründe barındır. ES module ve Firebase SDK için oyunu file:// ile açmak yerine HTTPS üzerinden sun. APKForge içinde yerel HTML dosyasından modül/HTTPS erişimi kısıtlanırsa webview ayarı gerekir.
7. İki ayrı cihazdan iki farklı hesap oluştur, aynı oda koduyla aynı moda gir ve konum/sohbet senkronizasyonunu test et.

GÜVENLİK / SINIRLAR
- Şifreler Firebase Authentication tarafından tutulur; HTML/Firestore içinde düz metin şifre tutulmaz.
- Doğum yılı ve cinsiyet isteğe bağlı profil alanlarıdır; oyuncu listesinde gösterilmez. Gerçek yaş için doğum tarihini toplamıyoruz.
- Bu ilk entegrasyon gerçek zamanlı konum ve oda sohbeti temelini sağlar; rekabetçi Katil Kim? için rol ataması, vuruş doğrulaması, oda sahipliği ve hile önleme mutlaka sunucu tarafına taşınmalıdır. Bu örnek istemci tarafında güvenilir bir anti-cheat sunmaz.
- Firebase ücretsiz kullanım kotası değişebilir; kullanıcı/okuma-yazma artınca ücret doğabilir. Harcama uyarısı ayarla.
- Güvenlik kuralları başlangıç örneğidir; herkese açık yayın öncesi test edilmeli. Kullanıcı adı çakışması ve moderasyon için Cloud Functions gibi sunucu tarafı mantığı önerilir.
- Arkadaşına tıklayıp katılmak için listelenen arkadaş düğmesi aynı arkadaş odası kodunu kullanır. Oda kodu başkalarıyla paylaşılabilir.

ARKADAŞ LİSTESİ VE ODAYA KATILMA
- Oyuncu, oyun içindeki 🌐 Arkadaşlar düğmesinden arkadaşlık isteği gönderir.
- Gelen istekleri Kabul veya Reddet ile yönetebilir; kabul edilen oyuncular Arkadaş listem bölümünde görünür.
- Arkadaş aynı modda bir odaya girdiyse profilinde oda durumu görünür ve Katıl düğmesi çıkar. Katıl düğmesi arkadaşın mevcut oda kodunu kullanır.
- Arkadaş paneli sol üstte, sohbet paneliyle aynı anda açılmayacak şekilde yerleştirilmiştir; böylece Şehir RP'deki sağ taraftaki ev araçlarını kapatmaz.
- Çevrimiçi durumu yaklaşık 45 saniyelik son görülme bilgisiyle değerlendirilir. Tarayıcı/uygulama zorla kapatılırsa durum kısa bir süre gecikmeli güncellenebilir.

YAYINA ALMADAN ÖNCE
- Firestore Rules alanına firestore.rules dosyasını yayımla.
- İki farklı hesap/cihazla kayıt, istek kabulü, oda katılımı ve sohbeti test et.
- Firebase Console'da kullanım/bütçe uyarılarını ayarla. Oyuncu adı benzersizliği ve Katil Kim? oyun kuralları için Cloud Functions/başka sunucu tarafı doğrulaması önerilir.

YEREL HESAP MODU (FIREBASE AYARLANMADAN)
- Firebase ayarları doldurulmadığında artık Hesap oluştur / Giriş yap bu cihazın tarayıcısında yerel hesap açar; parola düz metin yerine Web Crypto PBKDF2 özetiyle saklanır.
- Yerel modda arkadaş listesi yalnızca aynı tarayıcıda oluşturulmuş hesaplar arasında çalışır. Başka cihazlara arkadaşlık isteği göndermez; oda, canlı sohbet ve oyuncu konumları internet üzerinden senkronize olmaz.
- Gerçek çevrimiçi hesap ve arkadaş sistemi için yukarıdaki Firebase kurulum adımları hâlâ gereklidir. Yerel hesaplar Firebase hesabına otomatik aktarılmaz.
