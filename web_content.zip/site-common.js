
/* =====================================================
   QUÉ BOLÁ SHOP 🛒
   NAVEGACIÓN + AVATAR DE PERFIL + BANNER COMÚN
   + INTEGRACIÓN DEL CONTADOR DE CHAT
   ===================================================== */

(function () {
    "use strict";

    /* =====================================================
       CONFIGURACIÓN
       ===================================================== */

    const ENLACES_PRINCIPALES = [
        ["🏠 Inicio / Feed", "feed.html"],
        ["🛒 Tienda Oficial", "tienda.html"],
        ["🏪 Negocios", "negocios.html"],
        ["🛠️ Servicios", "servicios.html"],
        ["💼 Busco Empleo", "empleo.html"],
        ["📋 Ofertas de empleo", "ofertas-empleo.html"],
        ["👥 Empleados", "empleados.html"],
        ["💬 Chat", "chat.html"],
        ["💳 Planes y servicios", "planes.html"]
    ];

    const BANNER_API =
        "https://que-bola-shop-banner.fonito93punk.workers.dev";

    const BANNER_DURACION = 15000;
    const PERFIL_FOTO_DEFAULT = "img/icon.jpg";

    let bannerActual = 0;
    let bannerIntervalo = null;

    /* =====================================================
       CARGAR COMPLEMENTO DEL CONTADOR DE CHAT
       ===================================================== */

    function cargarContadorChat() {
        if (
            document.getElementById("qbChatBadgeScript") ||
            document.getElementById("qbHeaderChat") ||
            document.getElementById("qbChatBadge")
        ) {
            return;
        }

        const script = document.createElement("script");

        script.id = "qbChatBadgeScript";
        script.src = "chat-badge.js";
        script.async = true;

        script.onerror = function () {
            console.warn(
                "No se pudo cargar chat-badge.js. " +
                "Comprueba que el archivo exista en la raíz del sitio."
            );
        };

        document.head.appendChild(script);
    }

    /* =====================================================
       OBTENER USUARIO GUARDADO
       ===================================================== */

    function obtenerUsuarioGuardado() {
        const usuarioGuardado =
            localStorage.getItem("que_bola_shop_usuario");

        if (!usuarioGuardado) {
            return null;
        }

        try {
            return JSON.parse(usuarioGuardado);
        } catch (error) {
            console.warn(
                "No se pudo leer el usuario guardado:",
                error
            );

            return null;
        }
    }

    /* =====================================================
       COMPROBAR SESIÓN ACTIVA
       ===================================================== */

    function haySesionActiva() {
        const usuario = obtenerUsuarioGuardado();

        const token =
            localStorage.getItem("que_bola_shop_token") ||
            localStorage.getItem("qbshop_token");

        const expiracion =
            localStorage.getItem("que_bola_shop_expiracion");

        if (!usuario || !token) {
            return false;
        }

        if (expiracion) {
            const fechaExpiracion = Number(expiracion);

            if (
                Number.isFinite(fechaExpiracion) &&
                Date.now() >= fechaExpiracion
            ) {
                return false;
            }
        }

        return true;
    }

    window.haySesionActiva = haySesionActiva;

    /* =====================================================
       DESTINO DEL PERFIL SEGÚN EL ROL
       ===================================================== */

    function obtenerDestinoPerfil(usuario) {
        if (!usuario) {
            return "perfil.html";
        }

        const rol = String(usuario.rol || "")
            .trim()
            .toUpperCase();

        if (rol === "NEGOCIO") {
            return "panel-negocio.html";
        }

        if (rol === "SERVICIO") {
            return "panel-servicio.html";
        }

        return "perfil.html";
    }

    /* =====================================================
       OBTENER FOTO DE PERFIL
       ===================================================== */

    function obtenerFotoPerfil(usuario) {
        if (!usuario) {
            return PERFIL_FOTO_DEFAULT;
        }

        const foto =
            usuario.foto_perfil_url ||
            usuario.fotoPerfilUrl ||
            usuario.foto_perfil ||
            usuario.fotoPerfil ||
            "";

        if (typeof foto === "string" && foto.trim()) {
            return foto.trim();
        }

        return PERFIL_FOTO_DEFAULT;
    }

    /* =====================================================
       CREAR BOTÓN MI PERFIL
       ===================================================== */

    function crearBotonPerfil() {
        const enlace = document.createElement("a");

        enlace.href = "perfil.html";
        enlace.id = "qbHeaderProfile";
        enlace.className = "qb-header-profile";

        enlace.setAttribute("aria-label", "Mi perfil");
        enlace.setAttribute("title", "Mi perfil");

        const imagen = document.createElement("img");

        imagen.id = "qbHeaderProfileImage";
        imagen.className = "qb-header-profile-image";
        imagen.alt = "Foto de perfil";
        imagen.loading = "eager";
        imagen.decoding = "async";

        const texto = document.createElement("span");

        texto.className = "qb-header-profile-text";
        texto.textContent = "MI PERFIL";

        enlace.appendChild(imagen);
        enlace.appendChild(texto);

        return enlace;
    }

    /* =====================================================
       ESTILOS DEL PERFIL, CHAT Y GRUPO DE BOTONES
       ===================================================== */

    function agregarEstilosAvatar() {
        if (
            document.getElementById("qbHeaderProfileStyles")
        ) {
            return;
        }

        const style = document.createElement("style");

        style.id = "qbHeaderProfileStyles";

        style.textContent = `
            /*
               GRUPO DEL PERFIL, CHAT Y MENÚ MÓVIL
            */

            #qbHeaderActions {
                display: flex;
                align-items: center;
                justify-content: flex-end;
                gap: 2px;
                flex: 0 0 auto;
                width: auto;
                min-width: 0;
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            #qbHeaderActions > #qbHeaderProfile,
            #qbHeaderActions > #qbHeaderChat {
                flex-shrink: 0;
            }

            /*
               BOTÓN MI PERFIL
            */

            .qb-header-profile {
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 5px;
                height: 42px;
                padding: 0;
                margin: 0 !important;
                box-sizing: border-box;
                border-radius: 8px;
                text-decoration: none;
                color: inherit;
                background: transparent;
                border: none;
                cursor: pointer;
                flex: 0 0 auto;
                transition:
                    background .2s ease,
                    transform .15s ease;
            }

            .qb-header-profile-image {
                width: 38px;
                height: 38px;
                min-width: 38px;
                min-height: 38px;
                display: block;
                object-fit: cover;
                border-radius: 50%;
                border: 2px solid #ff7a00;
                box-sizing: border-box;
            }

            .qb-header-profile-text {
                font-size: 14px;
                font-weight: 700;
                line-height: 1;
                white-space: nowrap;
                color: inherit;
                letter-spacing: .2px;
            }

            .qb-header-profile:hover {
                background: rgba(0,0,0,.06);
            }

            .qb-header-profile:active {
                transform: scale(.97);
            }

            /*
               BOTÓN DEL CHAT
               Mantenerlo junto al perfil.
            */

            #qbHeaderChat {
                margin: 0 !important;
                margin-left: 2px !important;
                margin-right: 0 !important;
                flex: 0 0 40px;
            }

            #qbHeaderProfile + #qbHeaderChat {
                margin-left: 2px !important;
            }

            /*
               BOTÓN DEL MENÚ MÓVIL
            */

            #qbHeaderActions > #menuButton {
                flex: 0 0 auto;
                margin-left: 2px !important;
            }

            /*
               EN ESCRITORIO SE CONSERVA EL COMPORTAMIENTO
               ANTERIOR: OCULTAR MI PERFIL EN EL ENCABEZADO.
            */

            @media (min-width: 992px) {
                .qb-header-profile {
                    display: none;
                }
            }

            /*
               AJUSTES PARA TELÉFONOS PEQUEÑOS
            */

            @media (max-width: 420px) {
                .qb-header-profile {
                    gap: 4px;
                    padding: 0;
                    margin: 0 !important;
                }

                .qb-header-profile-image {
                    width: 36px;
                    height: 36px;
                    min-width: 36px;
                    min-height: 36px;
                }

                .qb-header-profile-text {
                    font-size: 13px;
                }

                #qbHeaderActions {
                    gap: 2px;
                }
            }
        `;

        document.head.appendChild(style);
    }

    /* =====================================================
       AGRUPAR MI PERFIL, CHAT Y MENÚ MÓVIL
       ===================================================== */

    function agregarAvatarPerfil() {
        const menuButton =
            document.getElementById("menuButton");

        if (!menuButton || !menuButton.parentElement) {
            return;
        }

        agregarEstilosAvatar();

        const headerContainer = menuButton.parentElement;

        /*
           Crear o recuperar el grupo de botones.
        */

        let grupo =
            document.getElementById("qbHeaderActions");

        if (!grupo) {
            grupo = document.createElement("div");
            grupo.id = "qbHeaderActions";

            /*
               Insertar el grupo en la posición que
               ocupaba originalmente el botón del menú.
            */

            headerContainer.insertBefore(
                grupo,
                menuButton
            );
        }

        /*
           Crear o recuperar MI PERFIL.
        */

        let avatar =
            document.getElementById("qbHeaderProfile");

        if (!avatar) {
            avatar = crearBotonPerfil();
        }

        /*
           Colocar MI PERFIL al principio del grupo.
        */

        if (avatar.parentElement !== grupo) {
            grupo.insertBefore(
                avatar,
                grupo.firstChild
            );
        }

        /*
           Colocar el menú móvil dentro del mismo grupo.
           El botón del chat se insertará entre el perfil
           y el menú cuando se cargue chat-badge.js.
        */

        if (menuButton.parentElement !== grupo) {
            grupo.appendChild(menuButton);
        }

        /*
           Forzar el espacio pequeño entre los botones.
        */

        grupo.style.setProperty(
            "display",
            "flex",
            "important"
        );

        grupo.style.setProperty(
            "align-items",
            "center",
            "important"
        );

        grupo.style.setProperty(
            "justify-content",
            "flex-end",
            "important"
        );

        grupo.style.setProperty(
            "gap",
            "2px",
            "important"
        );

        avatar.style.setProperty(
            "margin",
            "0",
            "important"
        );

        menuButton.style.setProperty(
            "margin-left",
            "2px",
            "important"
        );

        actualizarAvatarPerfil();
    }

    /* =====================================================
       ACTUALIZAR FOTO Y DESTINO SEGÚN ROL
       ===================================================== */

    function actualizarAvatarPerfil() {
        const avatar =
            document.getElementById("qbHeaderProfile");

        const imagen =
            document.getElementById("qbHeaderProfileImage");

        if (!avatar || !imagen) {
            return;
        }

        if (!haySesionActiva()) {
            avatar.style.display = "none";
            return;
        }

        avatar.style.display = "flex";

        const usuario = obtenerUsuarioGuardado();

        avatar.href = obtenerDestinoPerfil(usuario);

        const foto = obtenerFotoPerfil(usuario);

        imagen.onerror = function () {
            imagen.onerror = null;
            imagen.src = PERFIL_FOTO_DEFAULT;
        };

        imagen.src = foto;
    }

    window.actualizarAvatarPerfil = actualizarAvatarPerfil;

    /* =====================================================
       ESCAPAR HTML
       ===================================================== */

    function escaparHTML(texto) {
        return String(texto ?? "").replace(
            /[&<>'"]/g,
            c => ({
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                "'": "&#39;",
                '"': "&quot;"
            }[c])
        );
    }

    /* =====================================================
       ESTILOS DEL MENÚ LATERAL DE ESCRITORIO
       ===================================================== */

    function agregarEstilosMenuLateral() {
        if (
            document.getElementById("qbDesktopSidebarStyles")
        ) {
            return;
        }

        const style = document.createElement("style");

        style.id = "qbDesktopSidebarStyles";

        style.textContent = `
            .qb-desktop-sidebar {
                position: fixed;
                top: 76px;
                left: 0;
                width: 230px;
                max-height: calc(100vh - 92px);
                overflow-y: auto;
                box-sizing: border-box;
                padding: 14px 12px;
                background: #ffffff;
                border-right: 1px solid #e2e8f0;
                box-shadow: 2px 0 10px rgba(0,0,0,.05);
                z-index: 900;
            }

            .qb-desktop-sidebar-title {
                padding: 8px 12px 10px;
                margin-bottom: 4px;
                color: #64748b;
                font-size: 11px;
                font-weight: 800;
                letter-spacing: .08em;
                text-transform: uppercase;
            }

            .qb-desktop-sidebar a,
            .qb-desktop-sidebar button {
                width: 100%;
                min-height: 42px;
                display: flex;
                align-items: center;
                box-sizing: border-box;
                padding: 10px 12px;
                margin: 2px 0;
                border: none;
                border-radius: 8px;
                background: transparent;
                color: #0f172a;
                font-family: inherit;
                font-size: 14px;
                font-weight: 600;
                line-height: 1.2;
                text-align: left;
                text-decoration: none;
                cursor: pointer;
                transition:
                    background .2s ease,
                    color .2s ease,
                    transform .15s ease;
            }

            .qb-desktop-sidebar a:hover,
            .qb-desktop-sidebar button:hover,
            .qb-desktop-sidebar a.qb-nav-current {
                background: #fff0e6;
                color: #cc5200;
            }

            nav.main-nav a.qb-nav-current,
            nav.mobile-menu a.qb-nav-current,
            #mobileMenu a.qb-nav-current {
                color: #cc5200;
                font-weight: 800;
            }

            .qb-desktop-sidebar a:active,
            .qb-desktop-sidebar button:active {
                transform: scale(.98);
            }

            .qb-desktop-sidebar .admin-panel-link {
                font-weight: 700;
            }

            .qb-desktop-sidebar .logout-button {
                margin-top: 12px;
                border-top: 1px solid #e2e8f0;
                border-radius: 8px;
                padding-top: 14px;
                color: #475569;
            }

            .qb-desktop-sidebar .logout-button:hover {
                color: #dc2626;
                background: #fef2f2;
            }

            @media (min-width: 992px) {
                body {
                    padding-left: 230px;
                    box-sizing: border-box;
                }

                .qb-desktop-sidebar {
                    display: block;
                }
            }

            @media (max-width: 991px) {
                .qb-desktop-sidebar {
                    display: none;
                }

                body {
                    padding-left: 0;
                }
            }
        `;

        document.head.appendChild(style);
    }

    /* =====================================================
       ELIMINAR MENÚ LATERAL
       ===================================================== */

    function eliminarMenuLateral() {
        const sidebar =
            document.getElementById("qbDesktopSidebar");

        if (sidebar) {
            sidebar.remove();
        }
    }

    window.eliminarMenuLateral = eliminarMenuLateral;

    /* =====================================================
       CREAR MENÚ LATERAL
       ===================================================== */

    function crearMenuLateral() {
        if (window.innerWidth < 992) {
            return;
        }

        if (!haySesionActiva()) {
            eliminarMenuLateral();
            return;
        }

        agregarEstilosMenuLateral();

        let sidebar =
            document.getElementById("qbDesktopSidebar");

        if (!sidebar) {
            sidebar = document.createElement("aside");
            sidebar.id = "qbDesktopSidebar";
            sidebar.className = "qb-desktop-sidebar";
        }

        if (sidebar.parentElement) {
            return;
        }

        const titulo = document.createElement("div");

        titulo.className = "qb-desktop-sidebar-title";
        titulo.textContent = "MENÚ";

        sidebar.appendChild(titulo);

        ENLACES_PRINCIPALES.forEach(([texto, href]) => {
            const enlace = document.createElement("a");

            enlace.href = href;
            enlace.textContent = texto;

            sidebar.appendChild(enlace);
        });

        const admin =
            document.getElementById("panelAdminLink");

        if (admin) {
            sidebar.appendChild(admin);
        }

        const miNegocio =
            document.getElementById("miNegocioLink");

        if (miNegocio) {
            sidebar.appendChild(miNegocio);
        }

        const logout =
            document.getElementById("logoutButton");

        if (logout) {
            sidebar.appendChild(logout);
        }

        document.body.appendChild(sidebar);
    }

    /* =====================================================
       OCULTAR MENÚ SUPERIOR DE ESCRITORIO
       ===================================================== */

    function prepararMenuSuperior() {
        const nav =
            document.querySelector("nav.main-nav");

        if (!nav) {
            return;
        }

        if (window.innerWidth >= 992) {
            nav.style.display = "none";
        }
    }

    /* =====================================================
       ACTUALIZAR BARRA LATERAL
       ===================================================== */

    function actualizarMenuLateral() {
        const sidebar =
            document.getElementById("qbDesktopSidebar");

        if (!sidebar) {
            return;
        }

        if (!haySesionActiva()) {
            eliminarMenuLateral();
            return;
        }

        const admin =
            document.getElementById("panelAdminLink");

        if (admin && admin.parentElement !== sidebar) {
            sidebar.appendChild(admin);
        }

        const miNegocio =
            document.getElementById("miNegocioLink");

        if (
            miNegocio &&
            miNegocio.parentElement !== sidebar
        ) {
            sidebar.appendChild(miNegocio);
        }

        const logout =
            document.getElementById("logoutButton");

        if (logout) {
            sidebar.appendChild(logout);
        }
    }

    /* =====================================================
       PÁGINAS SIN BANNER
       ===================================================== */

    const PAGINAS_SIN_BANNER = [
        "login.html",
        "registro.html",
        "planes.html"
    ];

    function paginaSinBanner() {
        const paginaActual =
            window.location.pathname
                .split("/")
                .pop()
                .toLowerCase();

        return PAGINAS_SIN_BANNER.includes(paginaActual);
    }

    /* =====================================================
       ESTILOS DEL BANNER
       ===================================================== */

    function agregarEstilosBanner() {
        if (
            document.getElementById("qbBannerCommonStyles")
        ) {
            return;
        }

        const style = document.createElement("style");

        style.id = "qbBannerCommonStyles";

        style.textContent = `
            .qb-banner-section {
                width: 100%;
                max-width: 1100px;
                margin: 18px auto 0;
                padding: 0 16px;
                box-sizing: border-box;
            }

            .qb-banner-container {
                position: relative;
                width: 100%;
                aspect-ratio: 16 / 6;
                overflow: hidden;
                border-radius: 16px;
                background: #e9e9e9;
            }

            .qb-banner-image {
                position: absolute;
                inset: 0;
                width: 100%;
                height: 100%;
                object-fit: cover;
                opacity: 0;
                transition: opacity 0.8s ease;
            }

            .qb-banner-image.active {
                opacity: 1;
            }

            .qb-banner-indicators {
                position: absolute;
                left: 50%;
                bottom: 12px;
                transform: translateX(-50%);
                display: flex;
                gap: 7px;
                z-index: 5;
            }

            .qb-banner-indicator {
                width: 8px;
                height: 8px;
                padding: 0;
                border: 0;
                border-radius: 50%;
                background: rgba(255,255,255,.55);
                cursor: pointer;
            }

            .qb-banner-indicator.active {
                background: #fff;
                transform: scale(1.25);
            }

            @media (max-width: 600px) {
                .qb-banner-section {
                    padding: 0 12px;
                    margin-top: 12px;
                }

                .qb-banner-container {
                    border-radius: 12px;
                }
            }
        `;

        document.head.appendChild(style);
    }

    /* =====================================================
       OBTENER BANNERS
       ===================================================== */

    async function obtenerBanners() {
        try {
            const respuesta = await fetch(
                BANNER_API + "/banners",
                {
                    method: "GET",
                    cache: "no-store"
                }
            );

            const datos = await respuesta.json();

            if (
                !respuesta.ok ||
                !datos ||
                !datos.ok
            ) {
                throw new Error(
                    datos?.error ||
                    "No se pudieron cargar los banners."
                );
            }

            return Array.isArray(datos.banners)
                ? datos.banners
                : [];

        } catch (error) {
            console.warn(
                "No se pudieron cargar los banners dinámicos:",
                error
            );

            return [
                {
                    id: "local-1",
                    url: "baner/baner1.jpg",
                    nombre: "Banner principal",
                    orden: 1
                }
            ];
        }
    }

    /* =====================================================
       OBTENER CONTENEDOR DEL BANNER
       ===================================================== */

    function obtenerContenedorBanner() {
        const feedContainer =
            document.getElementById("bannerContainer");

        if (feedContainer) {
            agregarEstilosBanner();

            feedContainer.classList.add(
                "qb-banner-container"
            );

            return feedContainer;
        }

        const existente =
            document.getElementById(
                "qbCommonBannerContainer"
            );

        if (existente) {
            return existente;
        }

        const header =
            document.querySelector("header");

        if (!header) {
            return null;
        }

        agregarEstilosBanner();

        const section = document.createElement("section");

        section.className = "qb-banner-section";

        section.setAttribute(
            "aria-label",
            "Promociones y anuncios"
        );

        const container = document.createElement("div");

        container.className = "qb-banner-container";
        container.id = "qbCommonBannerContainer";

        section.appendChild(container);

        header.insertAdjacentElement(
            "afterend",
            section
        );

        return container;
    }

    /* =====================================================
       MOSTRAR BANNER
       ===================================================== */

    function mostrarBanner(indice) {
        const container =
            document.getElementById("bannerContainer") ||
            document.getElementById(
                "qbCommonBannerContainer"
            );

        if (!container) {
            return;
        }

        const imagenes =
            container.querySelectorAll(".qb-banner-image");

        const indicadores =
            container.querySelectorAll(
                ".qb-banner-indicator"
            );

        if (!imagenes.length) {
            return;
        }

        bannerActual =
            (indice + imagenes.length) %
            imagenes.length;

        imagenes.forEach((img, i) => {
            img.classList.toggle(
                "active",
                i === bannerActual
            );
        });

        indicadores.forEach((btn, i) => {
            btn.classList.toggle(
                "active",
                i === bannerActual
            );
        });
    }

    /* =====================================================
       INICIAR CARRUSEL
       ===================================================== */

    function iniciarCarrusel(cantidad) {
        if (bannerIntervalo) {
            clearInterval(bannerIntervalo);
            bannerIntervalo = null;
        }

        if (cantidad <= 1) {
            return;
        }

        bannerIntervalo = window.setInterval(() => {
            mostrarBanner(bannerActual + 1);
        }, BANNER_DURACION);
    }

    /* =====================================================
       RENDERIZAR BANNERS
       ===================================================== */

    function renderizarBanners(banners) {
        const container = obtenerContenedorBanner();

        if (!container) {
            return;
        }

        container.innerHTML = "";

        if (!Array.isArray(banners) || !banners.length) {
            banners = [
                {
                    id: "local-1",
                    url: "baner/baner1.jpg",
                    nombre: "Banner principal",
                    orden: 1
                }
            ];
        }

        let cantidadBanners = 0;

        banners.forEach((banner) => {
            if (!banner || !banner.url) {
                return;
            }

            const imagen = document.createElement("img");

            imagen.className =
                "qb-banner-image banner-image";

            if (cantidadBanners === 0) {
                imagen.classList.add("active");
            }

            imagen.src = banner.url;

            imagen.alt =
                banner.nombre ||
                "Promoción de Qué Bolá SHOP";

            imagen.loading =
                cantidadBanners === 0
                    ? "eager"
                    : "lazy";

            imagen.addEventListener("error", () => {
                console.warn(
                    "No se pudo cargar el banner:",
                    banner.url
                );

                imagen.remove();
            });

            container.appendChild(imagen);

            cantidadBanners++;
        });

        if (cantidadBanners === 0) {
            const imagen = document.createElement("img");

            imagen.className =
                "qb-banner-image banner-image active";

            imagen.src = "baner/baner1.jpg";
            imagen.alt = "Banner principal";

            container.appendChild(imagen);

            cantidadBanners = 1;
        }

        if (cantidadBanners > 1) {
            const indicadores =
                document.createElement("div");

            indicadores.className =
                "qb-banner-indicators banner-indicators";

            for (
                let indice = 0;
                indice < cantidadBanners;
                indice++
            ) {
                const boton =
                    document.createElement("button");

                boton.type = "button";

                boton.className =
                    "qb-banner-indicator banner-indicator";

                if (indice === 0) {
                    boton.classList.add("active");
                }

                boton.setAttribute(
                    "aria-label",
                    `Mostrar banner ${indice + 1}`
                );

                boton.addEventListener("click", () => {
                    mostrarBanner(indice);
                });

                indicadores.appendChild(boton);
            }

            container.appendChild(indicadores);
        }

        bannerActual = 0;

        iniciarCarrusel(cantidadBanners);
    }

    /* =====================================================
       CREAR BANNER
       ===================================================== */

    async function crearBanner() {
        const banners = await obtenerBanners();

        renderizarBanners(banners);
    }

    /* =====================================================
       CONECTAR MENÚ MÓVIL
       ===================================================== */

    function conectarNavegacion() {
        const contenedores = [
            document.querySelector("nav.main-nav"),
            document.querySelector("nav.mobile-menu"),
            document.getElementById("mobileMenu")
        ].filter(Boolean);

        // Completar los menús existentes sin duplicar enlaces y normalizar
        // sus etiquetas para que todos muestren el icono de cada sección.
        contenedores.forEach((contenedor) => {
            ENLACES_PRINCIPALES.forEach(([texto, href]) => {
                let enlace = Array.from(contenedor.querySelectorAll("a")).find((a) => {
                    const actual = (a.getAttribute("href") || "")
                        .split("?")[0]
                        .split("#")[0];
                    return actual === href;
                });

                if (!enlace) {
                    enlace = crearEnlace(texto, href);
                    contenedor.appendChild(enlace);
                } else {
                    // Mantener href, permisos, clases y demás atributos existentes.
                    enlace.textContent = texto;
                }

                const paginaActual = window.location.pathname.split("/").pop().toLowerCase();
                if (paginaActual === href.toLowerCase()) {
                    enlace.setAttribute("aria-current", "page");
                    enlace.classList.add("qb-nav-current");
                } else {
                    enlace.removeAttribute("aria-current");
                    enlace.classList.remove("qb-nav-current");
                }
            });
        });
    }

    /* =====================================================
       COMPROBAR ENLACE
       ===================================================== */

    function enlaceExiste(contenedor, href) {
        if (!contenedor) {
            return false;
        }

        return Array.from(
            contenedor.querySelectorAll("a")
        ).some(a => {
            const actual =
                (a.getAttribute("href") || "")
                    .split("?")[0]
                    .split("#")[0];

            return actual === href;
        });
    }

    /* =====================================================
       CREAR ENLACE
       ===================================================== */

    function crearEnlace(texto, href) {
        const a = document.createElement("a");

        a.href = href;
        a.textContent = texto;

        return a;
    }

    /* =====================================================
       INICIO
       ===================================================== */

    function iniciar() {
        conectarNavegacion();

        /*
           Agrupar perfil y menú antes de cargar el chat.
        */

        agregarAvatarPerfil();

        crearMenuLateral();
        prepararMenuSuperior();

        setTimeout(actualizarMenuLateral, 300);
        setTimeout(actualizarAvatarPerfil, 500);

        /*
           El contador se carga después de crear el grupo.
        */

        cargarContadorChat();

        if (!paginaSinBanner()) {
            crearBanner();
        }
    }

    /* =====================================================
       DOM READY
       ===================================================== */

    if (document.readyState === "loading") {
        document.addEventListener(
            "DOMContentLoaded",
            iniciar
        );
    } else {
        iniciar();
    }

})();