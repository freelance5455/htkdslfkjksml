EVSL Auto Maintenance Management – Advanced Offline v5

Contents:
- EVSL_Auto_Maintenance_Advanced_v5_Offline.html: Offline web app, opens in a modern browser.
- README_EVSL_v5.txt: This guide.

Updates in v5:
- Vehicle Master now supports editing existing vehicle details, including current hour meter and basic PM values.
- Added separate item-wise PM schedule setup for each vehicle.
- Each PM item can be configured by hour meter, months, whichever earlier, or daily check.
- Stores independent hour/month interval, last service hour meter and last service date for each item.
- Retains Hindi/English, breakdown/welding/fabrication/new-part work entry, inventory, backup and restore features from v4.

Important:
- This is an offline HTML app ZIP, not an installable Android APK.
- Data is stored in the browser/app local storage on that device. Export a JSON backup before changing browser/app or clearing storage.
- This update does not modify or erase the old v4 ZIP/APK. To carry old data forward, export a JSON backup in the old app and restore it in the new app.
- Do not uninstall an existing APK until you have a verified backup. APK updates also require the same package name and signing key.
