تبدیل ریال به تومان - پروژه اندروید

ویژگی‌ها:
- ورود رقم فارسی، عربی و انگلیسی
- جداکننده سه‌رقمی خودکار
- نمایش مبلغ به ریال و تومان
- نوشتن مبلغ تومان به حروف فارسی
- کاملاً آفلاین

ساخت APK:
1) فایل ZIP را استخراج کن.
2) Android Studio را باز کن و Open را بزن.
3) پوشه RialToTomanAndroid را انتخاب کن.
4) صبر کن Gradle Sync تمام شود.
5) از منوی Build > Build Bundle(s) / APK(s) > Build APK(s) را بزن.
6) فایل خروجی معمولاً در مسیر app/build/outputs/apk/debug/app-debug.apk ساخته می‌شود.

نیازمندی:
- Android Studio
- نصب Android SDK Platform 35
- JDK 17 (معمولاً همراه Android Studio است)

نکته: این بسته پروژه آماده ساخت APK است، نه فایل APK کامپایل‌شده.
