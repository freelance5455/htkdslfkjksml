# Duniya Search — Setup Guide

Yeh ek responsive searching website hai. User sawal likhega, app Google Programmable Search se web pages dhoondegi, phir Gemini AI un results ki bunyaad par jawab banayega. Neeche original Google links bhi nazar aayenge.

## Zaroori baat
ZIP mein API keys shamil nahin hain. Google aur Gemini ki apni API keys lagani hongi. Google/Gemini ki free quota aur billing limits waqt ke sath badal sakti hain. Har website ya duniya ki har cheez ka result milne ki guarantee nahin hoti.

## Setup (Computer/Laptop)
1. Node.js install karein: https://nodejs.org/
2. Google Programmable Search Engine banayein: https://programmablesearchengine.google.com/
3. Google Cloud Console mein Custom Search JSON API enable karke API key banayein: https://console.cloud.google.com/
4. Gemini API key yahan se banayein: https://aistudio.google.com/app/apikey
5. Is project folder mein `.env.example` ki copy bana kar uska naam `.env` rakhein.
6. `.env` mein `GOOGLE_API_KEY`, `GOOGLE_CX`, aur `GEMINI_API_KEY` ki apni values daalein.
7. Terminal/Command Prompt mein project folder khol kar chalayein:

```bash
npm install
npm start
```

8. Browser mein `http://localhost:3000` kholein.

## Android par
Yeh ZIP ek web app project hai, direct APK nahin. Pehle ise Node.js hosting par deploy karna hoga. Phir website ko Android WebView app mein wrap karke APK banaya ja sakta hai. API keys ko Android app ke andar kabhi hard-code na karein; `.env` server par hi rakhein.

## Security
- `.env` file kisi ke saath share na karein.
- API keys ko GitHub/public ZIP mein upload na karein.
- Production use ke liye rate limiting, usage limits aur abuse protection add karein.
