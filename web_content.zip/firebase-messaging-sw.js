importScripts('https://www.gstatic.com/firebasejs/10.14.1/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.14.1/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: 'AIzaSyA03kNmOlF4ys0cVEAfbVFe60tqXyp-4AI',
  authDomain: 'our-universe-96cb1.firebaseapp.com',
  databaseURL: 'https://our-universe-96cb1-default-rtdb.firebaseio.com',
  projectId: 'our-universe-96cb1',
  storageBucket: 'our-universe-96cb1.firebasestorage.app',
  messagingSenderId: '979090394458',
  appId: '1:979090394458:web:a07a2f46ba6c9d8bfdb763',
  measurementId: 'G-RRQCLTH909'
});

const messaging = firebase.messaging();
messaging.onBackgroundMessage(function(payload) {
  const n = payload.notification || {};
  self.registration.showNotification(n.title || '❤️ Наш Всесвіт', {
    body: n.body || 'Нове повідомлення',
    icon: n.icon || './app_bg.jpg',
    badge: n.icon || './app_bg.jpg',
    data: payload.data || {}
  });
});
self.addEventListener('notificationclick', function(event) {
  event.notification.close();
  event.waitUntil(clients.matchAll({type:'window', includeUncontrolled:true}).then(function(list){
    for (const c of list) if ('focus' in c) return c.focus();
    return clients.openWindow('./');
  }));
});
