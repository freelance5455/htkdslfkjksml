importScripts(
  'https://www.gstatic.com/firebasejs/12.19.0/firebase-app-compat.js'
);

importScripts(
  'https://www.gstatic.com/firebasejs/12.19.0/firebase-messaging-compat.js'
);

firebase.initializeApp({

  apiKey:
  "AIzaSyCpaHGITu3Gr05NpkOnnMmIgYc--QJTlX4",

  authDomain:
  "chat-app-97353.firebaseapp.com",

  databaseURL:
  "https://chat-app-97353-default-rtdb.firebaseio.com",

  projectId:
  "chat-app-97353",

  storageBucket:
  "chat-app-97353.firebasestorage.app",

  messagingSenderId:
  "813179399013",

  appId:
  "1:813179399013:web:3e3069bdf6df4721c30f8c",

  measurementId:
  "G-N4WD0TW7KX"

});

const messaging = firebase.messaging();

messaging.onBackgroundMessage(
  function(payload){

    const title =
      payload.notification?.title ||
      "Musarof Chat";

    const body =
      payload.notification?.body ||
      "New message";

    self.registration.showNotification(
      title,
      {
        body:body
      }
    );

  }
);