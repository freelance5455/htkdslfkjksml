/* Firebase Cloud Messaging service worker.
   Replace YOUR_* values with the same Firebase web config. */
importScripts("https://www.gstatic.com/firebasejs/12.2.1/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/12.2.1/firebase-messaging-compat.js");
firebase.initializeApp({
  apiKey:"YOUR_API_KEY",
  authDomain:"YOUR_PROJECT.firebaseapp.com",
  projectId:"YOUR_PROJECT_ID",
  storageBucket:"YOUR_PROJECT.firebasestorage.app",
  messagingSenderId:"YOUR_SENDER_ID",
  appId:"YOUR_APP_ID"
});
const messaging=firebase.messaging();
messaging.onBackgroundMessage(payload=>{
  const n=payload.notification||{};
  self.registration.showNotification(n.title||"GBN PRESS24",{body:n.body||"",icon:"/icon-192.png"});
});