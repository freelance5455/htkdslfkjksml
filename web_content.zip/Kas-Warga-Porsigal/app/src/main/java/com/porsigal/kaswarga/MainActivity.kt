package com.porsigal.kaswarga

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback

class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true   // WAJIB: localStorage menyimpan seluruh data kas
            allowFileAccess = true     // memuat file:///android_asset/
        }

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()

        // Opening selalu tampil setiap aplikasi dibuka, jadi halaman dimuat ulang dari awal.
        webView.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Tanya halaman: tutup dialog / kembali ke Beranda. Jika tidak ada, keluar aplikasi.
                webView.evaluateJavascript(
                    "(window.App && App.onBack && App.onBack()) ? 'true' : 'false'"
                ) { result ->
                    if (result?.contains("true") != true) finish()
                }
            }
        })
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
