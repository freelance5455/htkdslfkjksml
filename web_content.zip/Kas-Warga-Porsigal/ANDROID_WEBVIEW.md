# Android / WebView

Project Gradle (Kotlin, `ComponentActivity` + WebView, portrait), paket `com.porsigal.kaswarga`.
- `javaScriptEnabled` dan `domStorageEnabled` aktif (localStorage menyimpan semua data).
- Tidak ada permission INTERNET.
- Tombol Back: menutup dialog, lalu kembali ke Beranda, lalu keluar aplikasi (lewat `App.onBack()`).
- Status: APK belum dibuild di sini (tidak ada Android SDK); logika web diuji lewat Chromium (`tests/e2e.py`).
