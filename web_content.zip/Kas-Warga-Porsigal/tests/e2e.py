"""Uji end-to-end Kas Warga (Playwright + Chromium). Jalankan: python3 tests/e2e.py"""
import os, sys, pathlib
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
URL = (ROOT / "index.html").as_uri()
results = []

def check(name, cond):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name)

def txt(page, sel):
    return page.inner_text(sel).strip()

def enter(page):
    page.click("#op-start")

with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/opt/pw-browsers/chromium" if os.path.exists("/opt/pw-browsers/chromium") else None)
    ctx = b.new_context(viewport={"width": 390, "height": 800}, locale="id-ID")
    errors = []
    page = ctx.new_page()
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    reqs = []
    page.on("request", lambda r: reqs.append(r.url))

    # FIRST LAUNCH
    page.goto(URL)
    check("opening tampil", page.is_visible("#opening") and "PORSIGAL" in txt(page, "#opening"))
    check("slogan tampil", "SUPEL DALAM BERGAUL TEGAS DALAM PRINSIP" in txt(page, "#opening"))
    enter(page)
    check("form nominal awal tampil", page.is_visible("#initial") and "TULIS NOMINAL AWAL" in txt(page, "#initial"))
    page.fill("#initial-amount", "1000000")
    check("format ribuan input", page.input_value("#initial-amount") == "1.000.000")
    page.click("#initial-form button")
    check("beranda tampil", page.is_visible("#main"))
    check("total uang = nominal awal", "Rp1.000.000" in txt(page, ".total-card"))
    check("pemasukan Rp0", "Rp0" in txt(page, ".pair .mini-card:nth-child(1)"))
    check("pengeluaran Rp0", "Rp0" in txt(page, ".pair .mini-card:nth-child(2)"))
    check("belum ada transaksi", "Belum ada transaksi" in txt(page, "#view"))
    import datetime
    now = datetime.date.today()
    bulan = ["JANUARI","FEBRUARI","MARET","APRIL","MEI","JUNI","JULI","AGUSTUS","SEPTEMBER","OKTOBER","NOVEMBER","DESEMBER"][now.month-1]
    check("periode aktif sesuai bulan perangkat", txt(page, "#tb-period") == f"{bulan} {now.year}")
    t1 = txt(page, "#tb-time"); page.wait_for_timeout(1300)
    check("jam live", txt(page, "#tb-time") != t1)
    check("tidak ada nama bawaan", not any(n in page.content() for n in ["Faris", "Budi", "Citra", "Dimas"]))

    # ANGGOTA KOSONG
    page.click("[data-nav=anggota]")
    check("anggota kosong", "Belum ada anggota" in txt(page, "#view"))
    page.click("[data-act=add-member]")
    check("tambah anggota tanpa letting ditolak", page.is_hidden("#sheet") or "Tambah Letting dulu" in txt(page, "#toast"))

    # TAMBAH LETTING
    page.click("[data-act=add-letting]")
    page.fill("#in-lname", "Letting A"); page.click("#f-letting button")
    page.click("[data-act=add-letting]")
    page.fill("#in-lname", "Letting B"); page.click("#f-letting button")
    check("letting tersimpan", page.locator("section.letting").count() == 2)

    # TAMBAH ANGGOTA
    page.click("[data-act=add-member]")
    page.fill("#in-mname", "Anggota Satu"); page.select_option("#in-mlet", label="Letting A"); page.click("#f-member button")
    page.click("[data-act=add-member]")
    page.fill("#in-mname", "Anggota Dua"); page.select_option("#in-mlet", label="Letting A"); page.click("#f-member button")
    page.click("[data-act=add-member]")
    page.fill("#in-mname", "Anggota Tiga"); page.select_option("#in-mlet", label="Letting B"); page.click("#f-member button")
    check("anggota tersimpan", page.locator(".member").count() == 3)

    # PEMBAYARAN
    first = page.locator(".member").nth(0)
    first.locator("input[data-act=paid]").click(force=True)
    check("bayar tanpa nominal ditolak", not page.locator(".member").nth(0).locator("input[data-act=paid]").is_checked())
    page.locator(".member").nth(0).locator("input.amt").fill("50000")
    page.locator(".member").nth(0).locator("input.amt").blur()
    page.locator(".member").nth(0).locator("input[data-act=paid]").check(force=True)
    check("anggota 1 sudah bayar", page.locator(".member").nth(0).locator("input[data-act=paid]").is_checked() and "Sudah Bayar" in page.locator(".member").nth(0).inner_text())
    check("letting A belum lengkap (☐)", "☐" in page.locator("section.letting").nth(0).locator(".l-chk").inner_text())
    page.locator(".member").nth(1).locator("input.amt").fill("25000")
    page.locator(".member").nth(1).locator("input[data-act=paid]").check(force=True)
    check("letting A lengkap (☑)", "☑" in page.locator("section.letting").nth(0).locator(".l-chk").inner_text())
    check("letting B tetap ☐", "☐" in page.locator("section.letting").nth(1).locator(".l-chk").inner_text())
    page.click("[data-nav=beranda]")
    check("pembayaran masuk pemasukan", "Rp75.000" in txt(page, ".pair .mini-card:nth-child(1)"))
    check("saldo naik", "Rp1.075.000" in txt(page, ".total-card"))
    check("transaksi pembayaran tampil +", "+Rp50.000" in txt(page, "#view"))

    # PEMASUKAN & PENGELUARAN
    page.click("[data-nav=catat]")
    page.fill(".in-amt", "100000")
    page.click("form.tx-form button[type=submit]")
    check("keterangan kosong ditolak", "Keterangan wajib" in txt(page, "#toast"))
    page.fill(".in-note", "Sumbangan tulisan sendiri"); page.click("form.tx-form button[type=submit]")
    page.click("[data-tab=expense]")
    page.fill(".in-amt", "30000"); page.fill(".in-note", "Beli kursi"); page.click("form.tx-form button[type=submit]")
    page.click("[data-nav=beranda]")
    check("saldo = 1.000.000+75.000+100.000-30.000", "Rp1.145.000" in txt(page, ".total-card"))
    check("pemasukan 175.000", "Rp175.000" in txt(page, ".pair .mini-card:nth-child(1)"))
    check("pengeluaran 30.000", "Rp30.000" in txt(page, ".pair .mini-card:nth-child(2)"))
    check("keterangan persis ketikan (tanpa '-' otomatis)", "Sumbangan tulisan sendiri" in txt(page, "#view") and "Beli kursi" in txt(page, "#view") and "-Rp30.000" in txt(page, "#view"))
    first_tx = page.locator(".tx").first
    check("urutan terbaru dulu", "Beli kursi" in first_tx.inner_text())

    # EDIT PENGELUARAN
    first_tx.click(); page.click("#d-edit")
    page.fill(".in-amt", "40000"); page.click("#sheet form.tx-form button[type=submit]")
    check("edit tersimpan", "Rp1.135.000" in txt(page, ".total-card"))

    # HAPUS DENGAN KONFIRMASI
    page.locator(".tx").first.click(); page.click("#d-del")
    check("konfirmasi hapus muncul", "Hapus data ini?" in txt(page, "#sheet") and page.is_visible("#c-no") and page.is_visible("#c-yes"))
    page.click("#c-no")
    check("batal: saldo tetap", "Rp1.135.000" in txt(page, ".total-card"))
    page.locator(".tx").first.click(); page.click("#d-del"); page.click("#c-yes")
    check("hapus: saldo kembali", "Rp1.175.000" in txt(page, ".total-card"))

    # REOPEN
    page.reload(); enter(page)
    check("reopen: langsung beranda tanpa form nominal awal", page.is_visible("#main") and page.is_hidden("#initial"))
    check("data tetap setelah buka ulang", "Rp1.175.000" in txt(page, ".total-card"))

    # PERIODE: simulasikan bulan lain via data
    page.evaluate("""() => {
      const d = Store.d, m = d.members[0];
      d.payments.push({memberId: m.id, periodId: '2020-01', amount: 20000, paid: true, paidAt: new Date(2020,0,5,10,0).getTime()});
      d.incomes.push({id:'old1', amount: 5000, note:'lama', ts: new Date(2020,0,6).getTime(), periodId:'2020-01'});
      Store.save();
    }""")
    page.reload(); enter(page)
    check("bulan lama tidak tercampur di beranda", "Rp175.000" in txt(page, ".pair .mini-card:nth-child(1)"))
    page.click("[data-nav=riwayat]")
    opts = page.eval_on_selector_all("#riw-period option", "els => els.map(e => e.value)")
    check("hanya periode yang ada (aktif + 2020-01)", len(opts) == 2 and "2020-01" in opts)
    page.select_option("#riw-period", "2020-01")
    check("riwayat periode lama benar", "+Rp25.000" in txt(page, ".card") and "Rp1.025.000" in txt(page, ".card"))
    check("riwayat lama tampil pembayaran", "Anggota Satu" in txt(page, "#view") and "lama" in txt(page, "#view"))
    # Anggota: periode aktif belum dibayar untuk bulan baru tidak dipengaruhi data lama
    page.click("[data-nav=anggota]")
    check("status pembayaran per periode", page.locator(".member").nth(0).locator("input[data-act=paid]").is_checked())

    # Simulasi pergantian bulan: ubah periode aktif -> pembayaran bulan baru kosong
    page.evaluate("() => { App.period = '2099-01'; App.render(); }")
    check("bulan baru: belum bayar & nominal kosong", not page.locator(".member").nth(0).locator("input[data-act=paid]").is_checked() and page.locator(".member").nth(0).locator("input.amt").input_value() == "")
    check("bulan baru: anggota & letting tetap ada", page.locator(".member").count() == 3 and page.locator("section.letting").count() == 2)
    page.evaluate("() => { App.period = U.nowPeriod(); App.render(); }")

    # EDIT LETTING / ANGGOTA
    page.locator("[data-act=edit-letting]").first.click()
    page.fill("#in-lname", "Letting Utama"); page.click("#f-letting button")
    check("edit letting tersimpan", "Letting Utama" in txt(page, "#view"))
    page.locator("[data-act=edit-member]").first.click()
    page.fill("#in-mname", "Nama Baru"); page.click("#f-member button")
    check("edit anggota tersimpan", "Nama Baru" in txt(page, "#view"))

    # HAPUS ANGGOTA: histori tetap
    saldo_before = txt(page, "[data-nav=beranda]")
    page.locator("[data-act=del-member]").first.click()
    check("hapus anggota ada konfirmasi", page.is_visible("#c-yes"))
    page.click("#c-yes")
    check("anggota hilang dari daftar", page.locator(".member").count() == 2)
    page.click("[data-nav=beranda]")
    check("histori pembayaran tetap (saldo sama)", "Rp1.200.000" in txt(page, ".total-card"))

    # HAPUS LETTING
    page.click("[data-nav=anggota]")
    page.locator("[data-act=del-letting]").nth(1).click()
    check("hapus letting ada konfirmasi", "Hapus data ini?" in txt(page, "#sheet"))
    page.click("#c-yes")
    check("letting terhapus", page.locator("section.letting").count() == 1)

    # PENGATURAN
    page.click("[data-nav=pengaturan]"); page.click("[data-act=edit-initial]")
    page.fill("#in-init", "2000000"); page.click("#f-init button")
    page.click("[data-nav=beranda]")
    check("ubah nominal awal memengaruhi saldo", "Rp2.200.000" in txt(page, ".total-card"))

    # OVERFLOW
    for v in ["beranda", "anggota", "catat", "riwayat", "pengaturan"]:
        page.click(f"[data-nav={v}]")
        ov = page.evaluate("() => document.documentElement.scrollWidth - document.documentElement.clientWidth")
        check(f"tanpa overflow horizontal: {v}", ov <= 0)

    # OFFLINE
    external = [u for u in reqs if not u.startswith("file://") and not u.startswith("data:")]
    check("tanpa request internet", not external)
    check("tanpa error JS", not errors)
    if errors: print(errors)

    # FRESH INSTALL
    page2 = ctx.new_page()
    page2.goto(URL)
    page2.evaluate("() => { localStorage.clear(); }")
    page2.reload(); page2.click("#op-start")
    page2.fill("#initial-amount", "0"); page2.click("#initial-form button")
    body = page2.inner_text("#view")
    check("fresh: semua Rp0 & kosong", body.count("Rp0") == 3 and "Belum ada transaksi" in body)
    page2.click("[data-nav=anggota]")
    check("fresh: Belum ada anggota", "Belum ada anggota" in page2.inner_text("#view"))
    page2.click("[data-nav=riwayat]")
    check("fresh: riwayat hanya periode aktif", page2.locator("#riw-period option").count() == 1)

    page.screenshot(path="/tmp/claude-0/-home-claude/5b0631ea-4370-5d95-aced-480c1fdb965c/scratchpad/beranda.png")
    b.close()

failed = [n for n, ok in results if not ok]
print(f"\n{len(results)-len(failed)}/{len(results)} lulus")
sys.exit(1 if failed else 0)
