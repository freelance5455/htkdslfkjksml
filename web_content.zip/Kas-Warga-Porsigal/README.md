# Kas Warga Porsigal Botoran

“SUPEL DALAM BERGAUL TEGAS DALAM PRINSIP”

Aplikasi kas warga offline (HTML/CSS/JS di dalam Android WebView). Data disimpan di `localStorage` perangkat, tanpa server dan tanpa internet.

## Struktur
- `index.html`, `css/style.css`
- `js/storage.js` (penyimpanan + utilitas), `js/anggota.js`, `js/transaksi.js`, `js/riwayat.js`, `js/app.js`
- `assets/opening-bg.jpg`: latar Opening dan latar semua halaman. Ganti file ini (nama sama) untuk mengganti latar.
- `assets/logo.png`: logo Porsigal (Opening, header, Nominal Awal). Ikon aplikasi Android ada di `app/src/main/res/mipmap-*`.
- `app/`, `build.gradle`, `settings.gradle`, `gradlew`: project Android (WebView memuat `index.html`).

## Aturan data
- Data awal kosong; tidak ada data contoh.
- Keterangan pemasukan/pengeluaran murni ketikan pengguna: tidak ada isian otomatis, tidak ada pilihan bawaan, dan tidak boleh kosong.
- Total uang = nominal awal + pembayaran anggota + tambahan − pengeluaran.
- Beranda: Total uang untuk seluruh waktu; Pemasukan dan Pengeluaran untuk periode aktif (bulan perangkat).
- Pembayaran dicatat per `memberId + periodId` (mis. `2026-10`). Pindah bulan: pembayaran baru kosong, anggota dan Letting tetap.
- Hapus anggota/Letting hanya menyembunyikan dari daftar; riwayat pembayaran lama tetap dihitung.
- Hapus transaksi pembayaran = membatalkan status bayar.

## Build APK
Buka folder ini di Android Studio, atau `./gradlew assembleDebug`. Folder `index.html`, `css`, `js`, `assets` disalin otomatis ke assets APK.

## Tes
`python3 tests/e2e.py` (butuh Playwright + Chromium): 61 pemeriksaan fungsi.
