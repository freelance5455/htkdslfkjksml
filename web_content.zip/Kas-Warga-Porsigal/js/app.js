/* Aplikasi Kas Warga Porsigal Botoran: kontrol utama, navigasi, dialog, Beranda, Pengaturan. */
(function () {
  'use strict';

  var App = { view: 'beranda', period: U.nowPeriod() };
  window.App = App;

  var $ = function (id) { return document.getElementById(id); };
  var sheetOpen = false, confirmYes = null, toastTimer = null;

  /* ---------- Sheet / konfirmasi / toast ---------- */
  App.sheet = function (title, html) {
    $('sheet-title').textContent = title;
    $('sheet-body').innerHTML = html;
    $('backdrop').classList.remove('hidden');
    $('sheet').classList.remove('hidden');
    $('sheet').scrollTop = 0;
    sheetOpen = true;
  };
  App.closeSheet = function () {
    $('backdrop').classList.add('hidden');
    $('sheet').classList.add('hidden');
    $('sheet-body').innerHTML = '';
    sheetOpen = false; confirmYes = null;
  };
  App.confirm = function (title, message, onYes) {
    App.sheet(title, '<p class="confirm-msg">' + U.esc(message) + '</p>' +
      '<div class="form-actions" style="grid-template-columns:1fr 1fr">' +
      '<button class="btn ghost" id="c-no" type="button">BATAL</button>' +
      '<button class="btn danger" id="c-yes" type="button">HAPUS</button></div>');
    $('c-no').onclick = App.closeSheet;
    $('c-yes').onclick = function () { App.closeSheet(); onYes(); };
  };
  App.toast = function (msg) {
    var t = $('toast');
    t.textContent = msg; t.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.add('hidden'); }, 2200);
  };

  /* ---------- Render ---------- */
  function berandaHtml() {
    var tot = Tx.totals(App.period);
    var recent = Tx.all().slice(0, 15);
    return '<div class="card total-card"><div class="lbl">TOTAL UANG</div><div class="val">' + U.rupiah(Tx.saldo()) + '</div></div>' +
      '<div class="pair"><div class="mini-card"><div class="lbl">PEMASUKAN</div><div class="val in">' + U.rupiah(tot.income) + '</div></div>' +
      '<div class="mini-card"><div class="lbl">PENGELUARAN</div><div class="val out">' + U.rupiah(tot.expense) + '</div></div></div>' +
      '<div class="section-title">TRANSAKSI TERBARU</div>' +
      (recent.length ? recent.map(Tx.rowHtml).join('') : '<div class="empty card">Belum ada transaksi</div>');
  }

  function pengaturanHtml() {
    return '<h2 class="page-title">PENGATURAN</h2>' +
      '<div class="card"><div class="sum-row"><span>Nominal awal</span><span>' + U.rupiah(Store.d.initialAmount) + '</span></div>' +
      '<div class="form-actions"><button class="btn" data-act="edit-initial" type="button">UBAH NOMINAL AWAL</button></div></div>' +
      '<div class="card"><p class="note" style="margin:0 0 10px">Hapus semua anggota, Letting, pembayaran, pemasukan, pengeluaran, dan nominal awal dari perangkat ini.</p>' +
      '<button class="btn danger block" data-act="reset-all" type="button">HAPUS SEMUA DATA</button></div>' +
      (Store.persistent ? '' : '<p class="note">Peringatan: penyimpanan perangkat tidak tersedia, data hilang saat aplikasi ditutup.</p>') +
      '<p class="note" style="text-align:center;margin-top:18px">Kas Warga Porsigal Botoran · data tersimpan di perangkat, tanpa internet</p>';
  }

  App.render = function () {
    var root = $('view');
    document.querySelectorAll('.bottomnav button').forEach(function (b) {
      b.classList.toggle('active', b.dataset.nav === App.view);
    });
    $('tb-period').textContent = U.periodLabel(App.period).toUpperCase();
    if (App.view === 'beranda') root.innerHTML = berandaHtml();
    else if (App.view === 'anggota') Anggota.render(root);
    else if (App.view === 'catat') Tx.renderCatat(root);
    else if (App.view === 'riwayat') Riwayat.render(root);
    else if (App.view === 'pengaturan') root.innerHTML = pengaturanHtml();
  };

  App.go = function (view) {
    App.view = view;
    App.render();
    window.scrollTo(0, 0);
  };

  /* ---------- Nominal awal ---------- */
  function initialSheet() {
    App.sheet('UBAH NOMINAL AWAL',
      '<form id="f-init" autocomplete="off"><label class="rp-field" style="margin-top:12px"><span class="rp-prefix">Rp</span>' +
      '<input id="in-init" type="text" inputmode="numeric" value="' + U.fmtNum(Store.d.initialAmount) + '"></label>' +
      '<div class="form-actions"><button class="btn primary block" type="submit">SIMPAN</button></div></form>');
    var inp = $('in-init'); U.bindMoney(inp); inp.focus();
    $('f-init').addEventListener('submit', function (e) {
      e.preventDefault();
      Store.d.initialAmount = U.parseNum(inp.value);
      Store.save(); App.closeSheet(); App.render(); App.toast('Tersimpan');
    });
  }

  /* ---------- Jam & periode (waktu perangkat) ---------- */
  function tick() {
    var now = Date.now();
    $('tb-time').textContent = U.timeStr(now, true);
    $('tb-date').textContent = U.dateStr(now);
    var p = U.nowPeriod();
    if (p !== App.period) {      // bulan berganti: periode aktif ikut berganti, data lama tetap
      App.period = p;
      Riwayat.selected = null;
      if (!sheetOpen) App.render();
    }
  }

  /* ---------- Event ---------- */
  function onViewClick(e) {
    var el = e.target.closest('[data-act]');
    if (!el || el.dataset.act === 'amt' || el.dataset.act === 'paid') return;
    var act = el.dataset.act;
    if (act === 'tx') return Tx.detail(el.dataset.kind, el.dataset.id);
    if (act === 'tab') return Tx.setTab(el.dataset.tab);
    if (act === 'edit-initial') return initialSheet();
    if (act === 'reset-all') {
      return App.confirm('Hapus data ini?', 'Semua data aplikasi di perangkat ini akan dihapus dan tidak bisa dikembalikan.', function () {
        Store.reset(); location.reload();
      });
    }
    Anggota.onClick(act, el);
  }

  function startMain() {
    $('opening').classList.add('hidden');
    $('initial').classList.add('hidden');
    $('main').classList.remove('hidden');
    App.period = U.nowPeriod();
    App.view = 'beranda';
    tick(); App.render();
    setInterval(tick, 1000);
  }

  function afterOpening() {
    $('opening').classList.add('hidden');
    if (Store.d.initialAmount === null) {
      $('initial').classList.remove('hidden');
      setTimeout(function () { $('initial-amount').focus(); }, 100);
    } else startMain();
  }

  /* Tombol Back Android: true = sudah ditangani di dalam halaman */
  App.onBack = function () {
    if (sheetOpen) { App.closeSheet(); return true; }
    if (!$('main').classList.contains('hidden') && App.view !== 'beranda') { App.go('beranda'); return true; }
    return false;
  };

  function init() {
    Store.load();

    var entered = false;
    function enter() { if (entered) return; entered = true; afterOpening(); }
    $('op-start').addEventListener('click', enter);
    $('opening').addEventListener('click', enter);
    setTimeout(enter, 3500);

    var amt = $('initial-amount');
    U.bindMoney(amt);
    $('initial-form').addEventListener('submit', function (e) {
      e.preventDefault();
      var n = U.parseNum(amt.value);
      Store.d.initialAmount = n;   // 0 diperbolehkan bila kas mulai dari nol
      Store.save();
      startMain();
    });

    document.querySelectorAll('.bottomnav button').forEach(function (b) {
      b.addEventListener('click', function () { App.go(b.dataset.nav); });
    });
    var view = $('view');
    view.addEventListener('click', onViewClick);
    view.addEventListener('change', function (e) {
      var t = e.target;
      if (t.dataset.act === 'amt') Anggota.onAmountChange(t);
      else if (t.dataset.act === 'paid') Anggota.onPaidToggle(t);
    });
    view.addEventListener('input', function (e) {
      if (e.target.dataset && e.target.dataset.act === 'amt') {
        var n = U.parseNum(e.target.value);
        e.target.value = n ? U.fmtNum(n) : '';
      }
    });
    $('backdrop').addEventListener('click', App.closeSheet);
  }

  init();
})();
