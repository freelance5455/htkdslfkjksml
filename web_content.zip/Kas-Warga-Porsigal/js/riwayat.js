/* Riwayat per periode (hanya periode yang benar-benar punya data + periode aktif). */
(function () {
  'use strict';

  var Riwayat = { selected: null };

  function availablePeriods() {
    var set = {};
    Tx.all().forEach(function (t) { set[t.periodId] = true; });
    set[App.period] = true;
    return Object.keys(set).sort().reverse();
  }

  function group(title, list, emptyText) {
    return '<div class="section-title">' + title + '</div>' +
      (list.length ? list.map(Tx.rowHtml).join('') : '<div class="empty">' + emptyText + '</div>');
  }

  Riwayat.render = function (root) {
    var periods = availablePeriods();
    if (!Riwayat.selected || periods.indexOf(Riwayat.selected) < 0) Riwayat.selected = App.period;
    var pid = Riwayat.selected;
    var list = Tx.all().filter(function (t) { return t.periodId === pid; });
    var tot = Tx.totals(pid);

    root.innerHTML =
      '<h2 class="page-title">RIWAYAT</h2>' +
      '<select id="riw-period" class="txt period" aria-label="Pilih periode">' +
      periods.map(function (p) { return '<option value="' + p + '"' + (p === pid ? ' selected' : '') + '>' + U.periodLabel(p) + '</option>'; }).join('') +
      '</select>' +
      '<div class="card">' +
      '<div class="sum-row"><span>Total pemasukan</span><span class="in">+' + U.rupiah(tot.income) + '</span></div>' +
      '<div class="sum-row"><span>Total pengeluaran</span><span class="out">-' + U.rupiah(tot.expense) + '</span></div>' +
      '<div class="sum-row"><span>Total uang</span><span>' + U.rupiah(Tx.saldo(pid)) + '</span></div>' +
      '<p class="note">Total uang = nominal awal + semua pemasukan − pengeluaran sampai akhir periode ini.</p></div>' +
      group('PEMBAYARAN ANGGOTA', list.filter(function (t) { return t.kind === 'payment'; }), 'Belum ada pembayaran anggota') +
      group('TAMBAHAN', list.filter(function (t) { return t.kind === 'income'; }), 'Belum ada tambahan') +
      group('PENGELUARAN', list.filter(function (t) { return t.kind === 'expense'; }), 'Belum ada pengeluaran');

    document.getElementById('riw-period').addEventListener('change', function (e) {
      Riwayat.selected = e.target.value; App.render();
    });
  };

  window.Riwayat = Riwayat;
})();
