/* Anggota Tetap: Letting, anggota, pembayaran per periode (memberId + periodId). */
(function () {
  'use strict';

  var Anggota = {};

  function activeLettings() { return Store.d.letting.filter(function (l) { return !l.archived; }); }
  function membersOf(lid) { return Store.d.members.filter(function (m) { return m.lettingId === lid && !m.archived; }); }
  function getPayment(mid, pid) {
    return Store.d.payments.find(function (p) { return p.memberId === mid && p.periodId === pid; });
  }
  function ensurePayment(mid, pid) {
    var p = getPayment(mid, pid);
    if (!p) { p = { memberId: mid, periodId: pid, amount: 0, paid: false, paidAt: null }; Store.d.payments.push(p); }
    return p;
  }
  function lettingDone(l, pid) {
    var ms = membersOf(l.id);
    return ms.length > 0 && ms.every(function (m) { var p = getPayment(m.id, pid); return p && p.paid; });
  }

  Anggota.getPayment = getPayment;
  Anggota.memberById = function (id) { return Store.d.members.find(function (m) { return m.id === id; }); };
  Anggota.lettingById = function (id) { return Store.d.letting.find(function (l) { return l.id === id; }); };

  /* ---------- Tampilan ---------- */
  function memberHtml(m, pid) {
    var p = getPayment(m.id, pid);
    var paid = !!(p && p.paid);
    return '<div class="member" data-mid="' + m.id + '">' +
      '<div class="m-top"><div class="m-name">' + U.esc(m.name) + '</div>' +
      '<div class="m-acts"><button class="chip" data-act="edit-member" type="button">Edit</button>' +
      '<button class="chip danger" data-act="del-member" type="button">Hapus</button></div></div>' +
      '<div class="m-pay">' +
      '<label class="rp-field"><span class="rp-prefix">Rp</span>' +
      '<input class="amt" type="text" inputmode="numeric" data-act="amt" aria-label="Nominal iuran ' + U.esc(m.name) + '" value="' + U.fmtNum(p ? p.amount : 0) + '"></label>' +
      '<label class="paid-toggle ' + (paid ? 'on' : '') + '"><input type="checkbox" data-act="paid"' + (paid ? ' checked' : '') + '>' +
      '<span>' + (paid ? 'Sudah Bayar' : 'Belum Bayar') + '</span></label>' +
      '</div></div>';
  }

  function lettingHtml(l, pid) {
    var ms = membersOf(l.id);
    var done = lettingDone(l, pid);
    var paidCount = ms.filter(function (m) { var p = getPayment(m.id, pid); return p && p.paid; }).length;
    return '<section class="card letting" data-lid="' + l.id + '">' +
      '<div class="l-head"><span class="l-chk ' + (done ? 'on' : '') + '">' + (done ? '☑' : '☐') + '</span>' +
      '<div class="l-name"><h3>' + U.esc(l.name) + '</h3><small>' + (ms.length ? paidCount + ' dari ' + ms.length + ' sudah bayar' : 'Belum ada anggota') + '</small></div>' +
      '<button class="chip" data-act="edit-letting" type="button">Edit</button>' +
      '<button class="chip danger" data-act="del-letting" type="button">Hapus</button></div>' +
      (ms.length ? ms.map(function (m) { return memberHtml(m, pid); }).join('') : '') +
      '</section>';
  }

  Anggota.render = function (root) {
    var pid = App.period;
    var ls = activeLettings();
    var html = '<h2 class="page-title">ANGGOTA TETAP</h2>' +
      '<div class="btn-row"><button class="btn" data-act="add-letting" type="button">+ TAMBAH LETTING</button>' +
      '<button class="btn" data-act="add-member" type="button">+ TAMBAH ANGGOTA</button></div>' +
      '<p class="note" style="margin:-4px 4px 12px">Pembayaran untuk periode ' + U.periodLabel(pid) + '</p>';
    if (!ls.length) html += '<div class="empty card">Belum ada anggota</div>';
    else {
      html += ls.map(function (l) { return lettingHtml(l, pid); }).join('');
      if (!Store.d.members.some(function (m) { return !m.archived; })) html += '<div class="empty">Belum ada anggota</div>';
    }
    root.innerHTML = html;
  };

  function refreshLettingCard(lid) {
    var l = Anggota.lettingById(lid);
    var el = document.querySelector('section.letting[data-lid="' + lid + '"]');
    if (!l || !el) { App.render(); return; }
    var tmp = document.createElement('div');
    tmp.innerHTML = lettingHtml(l, App.period);
    el.replaceWith(tmp.firstChild);
  }

  /* ---------- Form ---------- */
  function lettingForm(l) {
    var edit = !!l;
    App.sheet(edit ? 'EDIT LETTING' : 'TAMBAH LETTING',
      '<form id="f-letting" autocomplete="off"><label class="f" for="in-lname">Nama Letting</label>' +
      '<input id="in-lname" class="txt" type="text" maxlength="60" value="' + (edit ? U.esc(l.name) : '') + '">' +
      '<div class="form-actions"><button class="btn primary block" type="submit">SIMPAN</button></div></form>');
    var input = document.getElementById('in-lname');
    input.focus();
    document.getElementById('f-letting').addEventListener('submit', function (e) {
      e.preventDefault();
      var name = input.value.trim();
      if (!name) { App.toast('Nama Letting wajib diisi'); return; }
      var dup = activeLettings().some(function (x) { return x.name.toLowerCase() === name.toLowerCase() && (!edit || x.id !== l.id); });
      if (dup) { App.toast('Nama Letting sudah ada'); return; }
      if (edit) l.name = name;
      else Store.d.letting.push({ id: Store.uid(), name: name, archived: false });
      Store.save(); App.closeSheet(); App.render(); App.toast('Tersimpan');
    });
  }

  function memberForm(m, presetLid) {
    var edit = !!m;
    var ls = activeLettings();
    if (!ls.length) { App.toast('Tambah Letting dulu'); return; }
    var selected = edit ? m.lettingId : (presetLid || '');
    var opts = '<option value="">Pilih Letting</option>' + ls.map(function (l) {
      return '<option value="' + l.id + '"' + (l.id === selected ? ' selected' : '') + '>' + U.esc(l.name) + '</option>';
    }).join('');
    App.sheet(edit ? 'EDIT ANGGOTA' : 'TAMBAH ANGGOTA',
      '<form id="f-member" autocomplete="off"><label class="f" for="in-mname">Nama</label>' +
      '<input id="in-mname" class="txt" type="text" maxlength="60" value="' + (edit ? U.esc(m.name) : '') + '">' +
      '<label class="f" for="in-mlet">Letting</label><select id="in-mlet" class="txt">' + opts + '</select>' +
      '<div class="form-actions"><button class="btn primary block" type="submit">SIMPAN</button></div></form>');
    document.getElementById('in-mname').focus();
    document.getElementById('f-member').addEventListener('submit', function (e) {
      e.preventDefault();
      var name = document.getElementById('in-mname').value.trim();
      var lid = document.getElementById('in-mlet').value;
      if (!name) { App.toast('Nama wajib diisi'); return; }
      if (!lid) { App.toast('Pilih Letting dulu'); return; }
      if (edit) { m.name = name; m.lettingId = lid; }
      else Store.d.members.push({ id: Store.uid(), name: name, lettingId: lid, archived: false });
      Store.save(); App.closeSheet(); App.render(); App.toast('Tersimpan');
    });
  }

  /* ---------- Aksi ---------- */
  Anggota.onClick = function (act, el) {
    var card = el.closest('.letting');
    var lid = card ? card.dataset.lid : null;
    var row = el.closest('.member');
    var mid = row ? row.dataset.mid : null;

    if (act === 'add-letting') return lettingForm(null);
    if (act === 'add-member') return memberForm(null, null);
    if (act === 'edit-letting') return lettingForm(Anggota.lettingById(lid));
    if (act === 'edit-member') return memberForm(Anggota.memberById(mid));

    if (act === 'del-letting') {
      var l = Anggota.lettingById(lid);
      var n = membersOf(lid).length;
      App.confirm('Hapus data ini?', 'Letting “' + l.name + '”' + (n ? ' dan ' + n + ' anggotanya' : '') +
        ' akan dihapus dari daftar. Riwayat pembayaran lama tetap aman.', function () {
        l.archived = true;
        membersOf(lid).forEach(function (m) { m.archived = true; });
        Store.save(); App.render();
      });
    }
    if (act === 'del-member') {
      var m = Anggota.memberById(mid);
      App.confirm('Hapus data ini?', 'Anggota “' + m.name + '” akan dihapus dari daftar. Riwayat pembayaran lama tetap aman.', function () {
        m.archived = true; Store.save(); refreshLettingCard(m.lettingId);
      });
    }
  };

  /* Nominal diubah (tanpa render ulang agar fokus tidak hilang) */
  Anggota.onAmountChange = function (input) {
    var row = input.closest('.member');
    var mid = row.dataset.mid;
    var p = ensurePayment(mid, App.period);
    p.amount = U.parseNum(input.value);
    if (p.paid && p.amount <= 0) {   // nominal dikosongkan saat sudah bayar -> kembalikan ke nilai sebelumnya tidak mungkin; batalkan bayar
      p.paid = false; p.paidAt = null;
      Store.save(); refreshLettingCard(row.closest('.letting').dataset.lid);
      App.toast('Nominal kosong, status jadi Belum Bayar');
      return;
    }
    Store.save();
  };

  Anggota.onPaidToggle = function (box) {
    var row = box.closest('.member');
    var mid = row.dataset.mid;
    var lid = row.closest('.letting').dataset.lid;
    var amount = U.parseNum(row.querySelector('input.amt').value);
    var p = ensurePayment(mid, App.period);
    if (box.checked) {
      if (amount <= 0) { box.checked = false; App.toast('Isi nominal dulu'); row.querySelector('input.amt').focus(); return; }
      p.amount = amount; p.paid = true; p.paidAt = Date.now();
    } else {
      p.paid = false; p.paidAt = null; p.amount = amount;
    }
    Store.save();
    refreshLettingCard(lid);
  };

  window.Anggota = Anggota;
})();
