/* Transaksi: pemasukan tambahan, pengeluaran, perhitungan saldo, daftar & detail transaksi. */
(function () {
  'use strict';

  var Tx = {};

  /* Semua transaksi (pembayaran anggota yang sudah dibayar + tambahan + pengeluaran), terbaru dulu. */
  Tx.all = function () {
    var d = Store.d, list = [];
    d.payments.forEach(function (p) {
      if (!p.paid) return;
      var m = Anggota.memberById(p.memberId);
      var l = m ? Anggota.lettingById(m.lettingId) : null;
      list.push({
        kind: 'payment', type: 'in', id: p.memberId + '|' + p.periodId, amount: p.amount, ts: p.paidAt || 0,
        periodId: p.periodId, title: m ? m.name : '(anggota dihapus)', sub: (l ? l.name + ' · ' : '') + 'Iuran ' + U.periodLabel(p.periodId)
      });
    });
    d.incomes.forEach(function (x) {
      list.push({ kind: 'income', type: 'in', id: x.id, amount: x.amount, ts: x.ts, periodId: x.periodId, title: x.note, sub: 'Pemasukan' });
    });
    d.expenses.forEach(function (x) {
      list.push({ kind: 'expense', type: 'out', id: x.id, amount: x.amount, ts: x.ts, periodId: x.periodId, title: x.note, sub: 'Pengeluaran' });
    });
    list.sort(function (a, b) { return b.ts - a.ts; });
    return list;
  };

  function sum(list, type) {
    return list.reduce(function (s, t) { return t.type === type ? s + t.amount : s; }, 0);
  }

  /* TOTAL UANG = NOMINAL AWAL + PEMBAYARAN ANGGOTA + TAMBAHAN - PENGELUARAN (s/d periode tertentu bila diberikan) */
  Tx.saldo = function (uptoPeriod) {
    var list = Tx.all();
    if (uptoPeriod) list = list.filter(function (t) { return t.periodId <= uptoPeriod; });
    return (Store.d.initialAmount || 0) + sum(list, 'in') - sum(list, 'out');
  };
  Tx.totals = function (periodId) {
    var list = Tx.all().filter(function (t) { return t.periodId === periodId; });
    return { income: sum(list, 'in'), expense: sum(list, 'out') };
  };

  /* ---------- Tampilan baris ---------- */
  Tx.rowHtml = function (t) {
    var sign = t.type === 'in' ? '+' : '-';
    return '<button class="tx ' + t.type + '" data-act="tx" data-kind="' + t.kind + '" data-id="' + U.esc(t.id) + '" type="button">' +
      '<span class="dot">' + sign + '</span>' +
      '<span class="mid"><div class="t1">' + U.esc(t.title) + '</div>' +
      '<div class="t2">' + U.esc(t.sub) + ' · ' + U.dateStr(t.ts) + ' · ' + U.timeStr(t.ts) + '</div></span>' +
      '<span class="amt">' + sign + U.rupiah(t.amount) + '</span></button>';
  };

  Tx.find = function (kind, id) {
    return Tx.all().find(function (t) { return t.kind === kind && t.id === id; });
  };

  /* ---------- Detail / edit / hapus ---------- */
  Tx.detail = function (kind, id) {
    var t = Tx.find(kind, id);
    if (!t) return;
    var sign = t.type === 'in' ? '+' : '-';
    var canEdit = kind !== 'payment' || t.periodId === App.period;
    var html = '<div class="detail-amt ' + t.type + '">' + sign + U.rupiah(t.amount) + '</div>' +
      '<div class="detail-note">' + U.esc(t.title) + '</div>' +
      '<div class="detail-meta">' + U.esc(t.sub) + '<br>' + U.dateStr(t.ts) + ' · ' + U.timeStr(t.ts) + ' · Periode ' + t.periodId + '</div>' +
      '<div class="form-actions">' +
      (canEdit ? '<button class="btn" id="d-edit" type="button">EDIT</button>' : '') +
      '<button class="btn danger" id="d-del" type="button">HAPUS</button>' +
      '<button class="btn ghost" id="d-close" type="button">TUTUP</button></div>';
    App.sheet(kind === 'payment' ? 'PEMBAYARAN ANGGOTA' : (kind === 'income' ? 'PEMASUKAN' : 'PENGELUARAN'), html);
    document.getElementById('d-close').onclick = App.closeSheet;
    var ed = document.getElementById('d-edit');
    if (ed) ed.onclick = function () { Tx.edit(kind, id); };
    document.getElementById('d-del').onclick = function () { Tx.remove(kind, id); };
  };

  Tx.edit = function (kind, id) {
    if (kind === 'payment') { editPayment(id); return; }
    var coll = kind === 'income' ? Store.d.incomes : Store.d.expenses;
    var rec = coll.find(function (x) { return x.id === id; });
    if (rec) form(kind, rec);
  };

  function editPayment(id) {
    var parts = id.split('|');
    var p = Anggota.getPayment(parts[0], parts[1]);
    var m = Anggota.memberById(parts[0]);
    if (!p) return;
    App.sheet('EDIT PEMBAYARAN',
      '<form id="f-pay" autocomplete="off"><div class="detail-note">' + U.esc(m ? m.name : '') + ' · ' + U.periodLabel(p.periodId) + '</div>' +
      '<label class="f" for="in-amt">Nominal</label>' +
      '<label class="rp-field"><span class="rp-prefix">Rp</span><input id="in-amt" type="text" inputmode="numeric" value="' + U.fmtNum(p.amount) + '"></label>' +
      '<div class="form-actions"><button class="btn primary block" type="submit">SIMPAN</button></div></form>');
    var inp = document.getElementById('in-amt');
    U.bindMoney(inp);
    document.getElementById('f-pay').addEventListener('submit', function (e) {
      e.preventDefault();
      var n = U.parseNum(inp.value);
      if (n <= 0) { App.toast('Nominal wajib diisi'); return; }
      p.amount = n; Store.save(); App.closeSheet(); App.render(); App.toast('Tersimpan');
    });
  }

  Tx.remove = function (kind, id) {
    var msg = kind === 'payment'
      ? 'Pembayaran ini dibatalkan (status kembali Belum Bayar) dan dikeluarkan dari pemasukan.'
      : 'Transaksi ini akan dihapus dan saldo dihitung ulang.';
    App.confirm('Hapus data ini?', msg, function () {
      if (kind === 'payment') {
        var parts = id.split('|');
        var p = Anggota.getPayment(parts[0], parts[1]);
        if (p) { p.paid = false; p.paidAt = null; }
      } else {
        var key = kind === 'income' ? 'incomes' : 'expenses';
        Store.d[key] = Store.d[key].filter(function (x) { return x.id !== id; });
      }
      Store.save(); App.render();
    });
  };

  /* ---------- Form pemasukan / pengeluaran ---------- */
  function formHtml(kind, rec) {
    return '<form class="tx-form" data-kind="' + kind + '" autocomplete="off">' +
      '<label class="f">Nominal</label>' +
      '<label class="rp-field"><span class="rp-prefix">Rp</span><input class="in-amt" type="text" inputmode="numeric" value="' + (rec ? U.fmtNum(rec.amount) : '') + '"></label>' +
      '<label class="f">Keterangan</label>' +
      '<input class="txt in-note" type="text" maxlength="120" value="' + (rec ? U.esc(rec.note) : '') + '">' +
      '<div class="form-actions"><button class="btn primary block" type="submit">SIMPAN</button></div></form>';
  }

  function wireForm(scope, kind, rec, after) {
    var f = scope.querySelector('form.tx-form');
    var amt = f.querySelector('.in-amt');
    var note = f.querySelector('.in-note');
    U.bindMoney(amt);
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var n = U.parseNum(amt.value);
      var text = note.value.trim();   // keterangan murni ketikan pengguna, tanpa isian otomatis
      if (n <= 0) { App.toast('Nominal wajib diisi'); amt.focus(); return; }
      if (!text) { App.toast('Keterangan wajib ditulis'); note.focus(); return; }
      var key = kind === 'income' ? 'incomes' : 'expenses';
      if (rec) { rec.amount = n; rec.note = text; }
      else {
        var ts = Date.now();
        Store.d[key].push({ id: Store.uid(), amount: n, note: text, ts: ts, periodId: U.periodOf(ts) });
      }
      Store.save();
      after();
    });
    return f;
  }

  function form(kind, rec) {
    App.sheet(rec ? (kind === 'income' ? 'EDIT PEMASUKAN' : 'EDIT PENGELUARAN') : (kind === 'income' ? 'TAMBAH PEMASUKAN' : 'PENGELUARAN'), formHtml(kind, rec));
    wireForm(document.getElementById('sheet-body'), kind, rec, function () { App.closeSheet(); App.render(); App.toast('Tersimpan'); });
  }

  /* ---------- Halaman Catat ---------- */
  Tx.catatTab = 'income';

  Tx.renderCatat = function (root) {
    var kind = Tx.catatTab;
    var list = Tx.all().filter(function (t) { return t.kind === kind && t.periodId === App.period; });
    root.innerHTML =
      '<h2 class="page-title">CATAT</h2>' +
      '<div class="seg"><button data-act="tab" data-tab="income" type="button" class="' + (kind === 'income' ? 'active' : '') + '">+ PEMASUKAN</button>' +
      '<button data-act="tab" data-tab="expense" type="button" class="out ' + (kind === 'expense' ? 'active' : '') + '">− PENGELUARAN</button></div>' +
      '<div class="card"><h3 class="page-title" style="margin:0 0 2px;font-size:14px">' + (kind === 'income' ? 'TAMBAH PEMASUKAN' : 'PENGELUARAN') + '</h3>' + formHtml(kind, null) + '</div>' +
      '<div class="section-title">' + (kind === 'income' ? 'PEMASUKAN' : 'PENGELUARAN') + ' ' + U.periodLabel(App.period).toUpperCase() + '</div>' +
      (list.length ? list.map(Tx.rowHtml).join('') : '<div class="empty">' + (kind === 'income' ? 'Belum ada pemasukan' : 'Belum ada pengeluaran') + '</div>');
    wireForm(root, kind, null, function () { App.render(); App.toast('Tersimpan'); });
  };

  Tx.setTab = function (tab) { Tx.catatTab = tab; App.render(); };

  window.Tx = Tx;
})();
