/* Penyimpanan lokal (localStorage) + utilitas umum. Tanpa server, tanpa internet. */
(function () {
  'use strict';

  var KEY = 'kasWarga.porsigalBotoran.v1';

  function emptyData() {
    return {
      v: 1,
      initialAmount: null,   // null = belum pernah diisi
      letting: [],           // {id, name, archived}
      members: [],           // {id, name, lettingId, archived}
      payments: [],          // {memberId, periodId, amount, paid, paidAt}
      incomes: [],           // {id, amount, note, ts, periodId}
      expenses: []           // {id, amount, note, ts, periodId}
    };
  }

  var Store = { d: emptyData(), persistent: true };

  Store.load = function () {
    try {
      var raw = window.localStorage.getItem(KEY);
      if (raw) {
        var parsed = JSON.parse(raw);
        var base = emptyData();
        for (var k in base) { if (parsed[k] !== undefined) base[k] = parsed[k]; }
        Store.d = base;
      }
    } catch (e) {
      Store.persistent = false;
      Store.d = emptyData();
    }
  };

  Store.save = function () {
    try { window.localStorage.setItem(KEY, JSON.stringify(Store.d)); }
    catch (e) { Store.persistent = false; }
  };

  Store.reset = function () {
    Store.d = emptyData();
    try { window.localStorage.removeItem(KEY); } catch (e) {}
  };

  var seq = 0;
  Store.uid = function () {
    seq += 1;
    return Date.now().toString(36) + seq.toString(36) + Math.random().toString(36).slice(2, 6);
  };

  /* ---------- Utilitas ---------- */
  var BULAN = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
  var BLN_PENDEK = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
  function pad(n) { return n < 10 ? '0' + n : '' + n; }

  var U = {
    pad: pad,
    rupiah: function (n) {
      n = Math.round(Number(n) || 0);
      var neg = n < 0; if (neg) n = -n;
      return (neg ? '-Rp' : 'Rp') + String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    },
    /* "1.250.000" -> 1250000 */
    parseNum: function (s) {
      var digits = String(s == null ? '' : s).replace(/\D/g, '');
      if (!digits) return 0;
      var n = parseInt(digits, 10);
      return isFinite(n) ? Math.min(n, 999999999999) : 0;
    },
    fmtNum: function (n) {
      return n ? String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.') : '';
    },
    periodOf: function (ts) {
      var d = new Date(ts);
      return d.getFullYear() + '-' + pad(d.getMonth() + 1);
    },
    nowPeriod: function () { return U.periodOf(Date.now()); },
    periodLabel: function (pid) {
      var p = String(pid).split('-');
      return BULAN[parseInt(p[1], 10) - 1] + ' ' + p[0];
    },
    dateStr: function (ts) {
      var d = new Date(ts);
      return d.getDate() + ' ' + BLN_PENDEK[d.getMonth()] + ' ' + d.getFullYear();
    },
    timeStr: function (ts, withSec) {
      var d = new Date(ts);
      return pad(d.getHours()) + ':' + pad(d.getMinutes()) + (withSec ? ':' + pad(d.getSeconds()) : '');
    },
    esc: function (s) {
      return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
      });
    },
    /* Pasang format ribuan otomatis pada input nominal */
    bindMoney: function (input) {
      input.addEventListener('input', function () {
        var n = U.parseNum(input.value);
        input.value = n ? U.fmtNum(n) : '';
      });
    }
  };

  window.Store = Store;
  window.U = U;
})();
