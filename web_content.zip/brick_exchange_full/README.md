# BRICK EXCHANGE — Full Developer Source Package

Professional B2B brick marketplace & delivery platform.

Business flow:
Manufacturer → Wholesale Imarati Bhandar → Transporter → Customer

## Included
- Flutter Android application baseline with 47-screen navigation map and role-based UI
- Customer, Manufacturer, Wholesale and Driver modules
- NestJS REST API baseline
- PostgreSQL + Prisma schema
- Admin Web (React + TypeScript + Vite)
- Authentication, RBAC, product/inventory/order/transport/payment/commission/settlement models
- Docker Compose for PostgreSQL + Redis + API
- API documentation, screen map, deployment and integration guides
- English/Bengali/Hindi localization
- GitHub Actions CI starter
- Environment templates

## Important
This is a complete developer-ready source baseline, not a claim that external services are already connected.
You must add your own Firebase, SMS/OTP, payment, maps, storage and production credentials.
No real secrets are included.

## Demo
Development OTP: 123456
Demo phone: +919999999999

Run backend:
  cd backend
  npm install
  npx prisma generate
  npx prisma db push
  npm run start:dev

Run Flutter:
  cd flutter_app
  flutter pub get
  flutter run

Run Admin:
  cd admin_web
  npm install
  npm run dev

Docker:
  docker compose up -d postgres redis
  cd backend && npm install && npx prisma db push && npm run start:dev

APK/AAB:
  flutter build apk --release
  flutter build appbundle --release

Production integrations require real credentials and provider-side setup.
