import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import './style.css';

const menu = [
 'Dashboard','Users','Manufacturer Verification','Products','Orders','Transport',
 'Commissions','Payment & Settlement','Invoices','Complaints','Notifications','Staff','Settings'
];

function App(){
 const [page,setPage]=useState('Dashboard');
 return <div className="app">
  <aside><h1>BRICK<br/>EXCHANGE</h1><p>Admin Console</p>{menu.map(x=><button className={x===page?'active':''} onClick={()=>setPage(x)}>{x}</button>)}</aside>
  <main><header><div><small>Professional B2B Platform</small><h2>{page}</h2></div><span>Admin • Secure</span></header>
  <section className="grid">{['Users','Orders','Products','GMV','Commissions','Pending KYC'].map((x,i)=><article><small>{x}</small><strong>{i===0?'0':i===1?'0':i===2?'0':i===3?'₹0':'₹0'}</strong></article>)}</section>
  <section className="panel"><h3>{page}</h3><p>Connect this module to the NestJS API under <code>/api/v1/admin</code>. RBAC, audit logging, verification, settlement and complaint workflows are represented in the backend schema.</p></section>
  </main>
 </div>
}
createRoot(document.getElementById('root')!).render(<App/>);
