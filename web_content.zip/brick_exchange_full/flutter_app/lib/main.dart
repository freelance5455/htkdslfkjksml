import 'package:flutter/material.dart';

void main() => runApp(const BrickExchangeApp());

class BrickExchangeApp extends StatelessWidget {
  const BrickExchangeApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BRICK EXCHANGE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorSchemeSeed: const Color(0xFFE05A2A),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF101010),
      ),
      home: const ScreenHub(),
    );
  }
}

class ScreenHub extends StatefulWidget {
  const ScreenHub({super.key});
  @override State<ScreenHub> createState() => _ScreenHubState();
}
class _ScreenHubState extends State<ScreenHub> {
  int index = 0;
  final screens = const [
    'Splash','Language','Login','OTP','Profile Setup','Role Selection',
    'Customer Home','Product Search','Product Details','Cart','Checkout',
    'Order Confirmation','Live Order Tracking','Orders','Order Details',
    'Wallet','Profile','Manufacturer Dashboard','Add Product','Stock Management',
    'Manufacturer Orders','Order Processing','Manufacturer Earnings',
    'Wholesale Dashboard','Purchase Bricks','Wholesale Inventory','Wholesale Sales',
    'Profit Calculator','Driver Dashboard','Trip Request','Trip Details',
    'Loading Confirmation','Navigation','Delivery Confirmation','Driver Earnings',
    'Admin Login','Admin Dashboard','User Management','Manufacturer Verification',
    'Product Management','Order Management','Transport Management',
    'Commission Management','Payment & Settlement','Invoice Management',
    'Complaint Management','Notifications'
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('BRICK EXCHANGE')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: screens.length,
        itemBuilder: (_, i) => Card(
          child: ListTile(
            leading: CircleAvatar(child: Text('${i+1}')),
            title: Text(screens[i]),
            subtitle: Text('Screen ${i+1} • Build-ready feature route'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => FeaturePage(number: i+1, title: screens[i]))),
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.shopping_cart), label: 'Orders'),
          NavigationDestination(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class FeaturePage extends StatelessWidget {
  final int number; final String title;
  const FeaturePage({super.key, required this.number, required this.title});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Screen $number', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 12),
          Text(title, style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 20),
          const Text('BRICK EXCHANGE\nBuild Better. Buy Smarter.',
            style: TextStyle(fontSize: 18)),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.play_arrow),
            label: const Text('Connect API / Continue'),
          ),
        ]),
      ),
    );
  }
}
