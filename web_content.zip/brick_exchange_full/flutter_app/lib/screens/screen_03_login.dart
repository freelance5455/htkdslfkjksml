import 'package:flutter/material.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('BRICK EXCHANGE • Screen 3', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 16),
          Text('Login', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 16),
          const Text('Production implementation hook: connect repository/service, validation, API state and role permissions here.'),
          const SizedBox(height: 24),
          FilledButton(onPressed: () {}, child: const Text('Continue')),
        ],
      ),
    );
  }
}
