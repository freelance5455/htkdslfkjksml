import 'package:flutter/material.dart';

class PurchaseBricksScreen extends StatelessWidget {
  const PurchaseBricksScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('PurchaseBricks')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('BRICK EXCHANGE • Screen 25', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 16),
          Text('PurchaseBricks', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 16),
          const Text('Production implementation hook: connect repository/service, validation, API state and role permissions here.'),
          const SizedBox(height: 24),
          FilledButton(onPressed: () {}, child: const Text('Continue')),
        ],
      ),
    );
  }
}
