import 'package:flutter/material.dart';

class StockManagementScreen extends StatelessWidget {
  const StockManagementScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('StockManagement')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('BRICK EXCHANGE • Screen 20', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 16),
          Text('StockManagement', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 16),
          const Text('Production implementation hook: connect repository/service, validation, API state and role permissions here.'),
          const SizedBox(height: 24),
          FilledButton(onPressed: () {}, child: const Text('Continue')),
        ],
      ),
    );
  }
}
