Configure Android SDK, applicationId, Firebase google-services.json and release signing before production builds.
