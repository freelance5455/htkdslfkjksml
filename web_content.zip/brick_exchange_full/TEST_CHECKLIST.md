# Acceptance Test Checklist

[ ] OTP login
[ ] Role selection
[ ] Profile
[ ] Product search/filter
[ ] Product details
[ ] Cart
[ ] Checkout
[ ] Order creation
[ ] Manufacturer order processing
[ ] Inventory adjustment
[ ] Wholesale purchase/sales
[ ] Driver trip acceptance
[ ] Loading confirmation
[ ] Live location update
[ ] Delivery confirmation
[ ] Wallet
[ ] Payment webhook verification
[ ] Commission calculation
[ ] Settlement
[ ] Invoice
[ ] KYC documents
[ ] Admin user management
[ ] Complaint workflow
[ ] Notifications
[ ] Bengali/English/Hindi
[ ] HTTPS and production secrets
[ ] Database backups
[ ] Android release signing
