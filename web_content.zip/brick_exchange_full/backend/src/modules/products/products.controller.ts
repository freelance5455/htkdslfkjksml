import { Body, Controller, Get, Param, Post } from '@nestjs/common';
@Controller('products')
export class ProductsController {
  private products = [
    { id: 1, name: '1st Class Brick', pricePerThousand: 9500, stockQty: 50000, quality: 'Premium' },
    { id: 2, name: 'Fly Ash Brick', pricePerThousand: 8200, stockQty: 40000, quality: 'Standard' }
  ];
  @Get() list() { return this.products; }
  @Get(':id') get(@Param('id') id: string) { return this.products.find(x => x.id === Number(id)) || null; }
  @Post() create(@Body() body: any) { const item = { id: this.products.length + 1, ...body }; this.products.push(item); return item; }
}
