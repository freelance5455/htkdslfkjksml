import { Controller, Get } from '@nestjs/common';
@Controller('users')
export class UsersController {
  @Get('me') me() { return { id: 1, phone: '+919999999999', role: 'customer', name: 'Demo User' }; }
}
