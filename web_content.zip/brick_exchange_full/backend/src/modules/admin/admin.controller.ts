import { Controller, Get } from '@nestjs/common';
@Controller('admin')
export class AdminController {
  @Get('dashboard') dashboard() {
    return { users: 0, orders: 0, products: 0, gmv: 0, commissions: 0, pendingKyc: 0 };
  }
  @Get('users') users() { return []; }
  @Get('complaints') complaints() { return []; }
  @Get('audit-logs') logs() { return []; }
}
