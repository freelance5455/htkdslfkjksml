import { Body, Controller, Get, Param, Post } from '@nestjs/common';
@Controller('transport')
export class TransportController {
  private trips: any[] = [];
  @Get(':id') get(@Param('id') id: string) { return this.trips.find(t => t.id === Number(id)) || null; }
  @Post() create(@Body() body: any) {
    const trip = { id: Date.now(), status: 'REQUESTED', ...body, createdAt: new Date().toISOString() };
    this.trips.push(trip); return trip;
  }
  @Post(':id/accept') accept(@Param('id') id: string) {
    const t = this.trips.find(x => x.id === Number(id)); if (!t) return null;
    t.status = 'DRIVER_ASSIGNED'; return t;
  }
}
