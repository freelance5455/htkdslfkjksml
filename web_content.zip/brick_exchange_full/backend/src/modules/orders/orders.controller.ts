import { Body, Controller, Get, Param, Post, Patch } from '@nestjs/common';
@Controller('orders')
export class OrdersController {
  private orders: any[] = [];
  @Get() list() { return this.orders; }
  @Get(':id') get(@Param('id') id: string) { return this.orders.find(o => o.id === Number(id)) || null; }
  @Post() create(@Body() body: any) {
    const order = { id: Date.now(), orderNo: `BE-${Date.now()}`, status: 'PENDING', ...body, createdAt: new Date().toISOString() };
    this.orders.push(order); return order;
  }
  @Patch(':id/status') status(@Param('id') id: string, @Body() body: any) {
    const o = this.orders.find(x => x.id === Number(id)); if (!o) return null;
    o.status = body.status; return o;
  }
}
