import { Body, Controller, Post } from '@nestjs/common';
import { IsNotEmpty, IsString } from 'class-validator';
import { AuthService } from './auth.service';

class OtpDto {
  @IsString() @IsNotEmpty() phone!: string;
}
class VerifyDto extends OtpDto {
  @IsString() @IsNotEmpty() otp!: string;
}

@Controller('auth')
export class AuthController {
  constructor(private readonly auth: AuthService) {}
  @Post('send-otp') send(@Body() dto: OtpDto) { return this.auth.sendOtp(dto.phone); }
  @Post('verify-otp') verify(@Body() dto: VerifyDto) { return this.auth.verifyOtp(dto.phone, dto.otp); }
}
