import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AuthService {
  constructor(private readonly jwt: JwtService) {}
  async sendOtp(phone: string) {
    return { success: true, message: 'OTP sent', developmentOtp: process.env.OTP_DEV_MODE === 'true' ? (process.env.OTP_DEV_CODE || '123456') : undefined };
  }
  async verifyOtp(phone: string, otp: string) {
    const code = process.env.OTP_DEV_CODE || '123456';
    if (process.env.OTP_DEV_MODE === 'true' && otp === code) {
      const accessToken = await this.jwt.signAsync({ phone, role: 'customer' });
      return { accessToken, refreshToken: accessToken, user: { phone, role: 'customer' } };
    }
    throw new Error('Invalid OTP');
  }
}
