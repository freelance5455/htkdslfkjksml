import { JwtModule } from '@nestjs/jwt';
export const AuthProviders = [JwtModule.register({ secret: process.env.JWT_SECRET || 'dev-secret' })];
