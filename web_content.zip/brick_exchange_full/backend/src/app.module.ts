import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaService } from './prisma.service';
import { HealthController } from './health.controller';
import { AuthController } from './modules/auth/auth.controller';
import { AuthService } from './modules/auth/auth.service';
import { UsersController } from './modules/users/users.controller';
import { ProductsController } from './modules/products/products.controller';
import { OrdersController } from './modules/orders/orders.controller';
import { TransportController } from './modules/transport/transport.controller';
import { AdminController } from './modules/admin/admin.controller';

@Module({
  imports: [ConfigModule.forRoot({ isGlobal: true })],
  controllers: [
    HealthController, AuthController, UsersController, ProductsController,
    OrdersController, TransportController, AdminController
  ],
  providers: [PrismaService, AuthService],
})
export class AppModule {}
