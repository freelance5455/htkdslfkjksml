import { PrismaClient, RoleName } from '@prisma/client';
const prisma = new PrismaClient();
async function main(){
  await prisma.productCategory.upsert({where:{name:'Bricks'},update:{},create:{name:'Bricks'}});
  await prisma.user.upsert({where:{phone:'+919999999999'},update:{},create:{phone:'+919999999999',name:'Demo User',role:RoleName.CUSTOMER}});
}
main().finally(()=>prisma.$disconnect());
