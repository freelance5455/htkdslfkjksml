# BRICK EXCHANGE Screen Map

1 Splash
2 Language
3 Login
4 OTP
5 Profile Setup
6 Role Selection
7 Customer Home
8 Product Search
9 Product Details
10 Cart
11 Checkout
12 Order Confirmation
13 Live Order Tracking
14 Orders
15 Order Details
16 Wallet
17 Profile
18 Manufacturer Dashboard
19 Add Product
20 Stock Management
21 Manufacturer Orders
22 Order Processing
23 Manufacturer Earnings
24 Wholesale Dashboard
25 Purchase Bricks
26 Wholesale Inventory
27 Wholesale Sales
28 Profit Calculator
29 Driver Dashboard
30 Trip Request
31 Trip Details
32 Loading Confirmation
33 Navigation
34 Delivery Confirmation
35 Driver Earnings
36 Admin Login
37 Admin Dashboard
38 User Management
39 Manufacturer Verification
40 Product Management
41 Order Management
42 Transport Management
43 Commission Management
44 Payment & Settlement
45 Invoice Management
46 Complaint Management
47 Notifications
