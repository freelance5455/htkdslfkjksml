# Deployment

1. Provision PostgreSQL and Redis.
2. Configure backend/.env from .env.example.
3. Run `npm install`.
4. Run `npx prisma generate`.
5. Run migrations/push against the target database.
6. Configure Firebase/FCM, OTP provider, payment gateway, maps and object storage.
7. Build backend with `npm run build`.
8. Run backend behind HTTPS reverse proxy.
9. Configure Flutter Android signing and provider keys.
10. Build APK/AAB.
11. Build admin with `npm run build` and serve `dist/`.

Security:
- Never commit .env or signing keys.
- Use HTTPS.
- Verify payment webhook signatures server-side.
- Store OTPs hashed with expiry.
- Enable admin 2FA in production.
- Keep KYC documents private and use signed URLs.
- Configure daily database backups.
