# REST API v1

Base: /api/v1

## Auth
POST /auth/send-otp
POST /auth/verify-otp
POST /auth/refresh-token
POST /auth/logout

## Users
GET /users/me
PATCH /users/me
GET /users/:id
PATCH /users/:id

## Products
GET /products
GET /products/:id
POST /manufacturers/me/products
PATCH /manufacturers/me/products/:id
DELETE /manufacturers/me/products/:id

## Inventory
GET /inventory
POST /inventory/adjust

## Cart
GET /cart
POST /cart/items
PATCH /cart/items/:id
DELETE /cart/items/:id

## Orders
POST /orders
GET /orders
GET /orders/:id
PATCH /orders/:id/status

## Transport
POST /transport
POST /transport/:id/accept
POST /transport/:id/loading
POST /transport/:id/deliver
GET /transport/:id

## Tracking
POST /tracking/:transportId/location
GET /tracking/:transportId

## Payments
POST /payments/create
POST /payments/webhook
GET /payments/:id

## Finance
GET /wallet
GET /commissions
GET /settlements
POST /settlements/:id/process

## Admin
GET /admin/dashboard
GET /admin/users
POST /admin/users/:id/verify
GET /admin/products
GET /admin/orders
GET /admin/complaints
PATCH /admin/complaints/:id
GET /admin/audit-logs

All protected routes use Bearer JWT and role guards.
