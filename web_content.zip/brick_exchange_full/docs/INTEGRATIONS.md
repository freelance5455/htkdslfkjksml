# Integration Points

OTP/SMS:
- Implement provider in backend/src/integrations/otp.service.ts
- Provider credentials belong in .env

Payments:
- PaymentGateway interface supports Razorpay/Cashfree-style adapters.
- Never trust client payment success alone.
- Verify webhook signature on server.

Maps:
- Flutter map screen is integration-ready.
- Add Google Maps key or alternative provider configuration.

Push:
- Firebase Cloud Messaging token registration is represented by notification service.
- Add Firebase project files locally; do not commit secrets.

Storage:
- Use S3/GCS/Firebase Storage for KYC and product images.
- Keep buckets private for identity documents.

Email:
- Add SES/SendGrid/Mailgun adapter as required.
