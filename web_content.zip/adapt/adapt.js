
const campoURL = document.getElementById("urlJogo");
const botaoAbrir = document.getElementById("abrirJogo");
const botaoGoogle = document.getElementById("testarGoogle");
const mensagem = document.getElementById("mensagem");

function prepararURL(valor) {
  let url = valor.trim();

  if (!url) {
    throw new Error("Digite um endereço primeiro.");
  }

  if (!/^https?:\/\//i.test(url)) {
    url = "https://" + url;
  }

  let endereco;

  try {
    endereco = new URL(url);
  } catch {
    throw new Error("Endereço inválido.");
  }

  if (!["http:", "https:"].includes(endereco.protocol)) {
    throw new Error("Protocolo não permitido.");
  }

  return endereco.href;
}

function abrirDiretamente(endereco) {
  try {
    const url = prepararURL(endereco);

    mensagem.textContent = "Abrindo: " + url;

    // Navegação direta: sem iframe.
    
document.getElementById("abrir").addEventListener("click", () => {
  window.location.assign("https://www.google.com");
});


  } catch (erro) {
    mensagem.textContent = erro.message;
  }
}

botaoAbrir.addEventListener("click", () => {
  abrirDiretamente(campoURL.value);
});

botaoGoogle.addEventListener("click", () => {
  abrirDiretamente("https://www.google.com");
});

campoURL.addEventListener("keydown", (evento) => {
  if (evento.key === "Enter") {
    abrirDiretamente(campoURL.value);
  }
});
