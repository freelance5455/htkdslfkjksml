
const campoURL = document.getElementById("urlJogo");
const botaoAbrir = document.getElementById("abrir");
const mensagem = document.getElementById("mensagem");

function prepararURL(valor) {
  let url = valor.trim();

  if (!url) {
    throw new Error("Digite um endereço primeiro.");
  }

  if (!/^https?:\/\//i.test(url)) {
    url = "https://" + url;
  }

  const endereco = new URL(url);

  if (!["http:", "https:"].includes(endereco.protocol)) {
    throw new Error("Protocolo não permitido.");
  }

  return endereco.href;
}

function abrirDiretamente() {
  try {
    const url = prepararURL(campoURL.value);

    mensagem.textContent = "Abrindo " + url;

    window.location.assign(url);

  } catch (erro) {
    mensagem.textContent = erro.message;
  }
}

botaoAbrir.addEventListener("click", abrirDiretamente);

campoURL.addEventListener("keydown", (evento) => {
  if (evento.key === "Enter") {
    abrirDiretamente();
  }
});
