
console.log("Linix Adapt 0.2 iniciado.");

const $ = id => document.getElementById(id);

// ELEMENTOS

const campoURL = $("urlJogo");
const botaoAbrir = $("abrirJogo");

const frame = $("frameJogo");
const areaJogo = $("areaJogo");

const avisoInicial = $("avisoInicial");
const mensagem = $("mensagem");

const escala = $("escala");
const botaoResetar = $("resetarEscala");
const botaoTelaCheia = $("telaCheia");
const botaoOrientacao = $("orientacao");

const ativarControles = $("ativarControles");
const autoHide = $("autoHide");
const tempoHide = $("tempoHide");
const opacidade = $("opacidade");

let jogoAtual = "";


// MENSAGENS

function informar(texto, estado = texto) {

    mensagem.textContent = texto;

    $("estadoVisualizador").textContent = estado;

}


// VALIDAR ENDEREÇO

function validarURL(valor) {

    try {

        const url = new URL(valor.trim());

        if (
            url.protocol !== "https:" &&
            url.protocol !== "http:"
        ) {
            throw new Error("Protocolo não permitido.");
        }

        return url.href;

    } catch {

        throw new Error(
            "Endereço inválido. Utilize HTTP ou HTTPS."
        );

    }

}


// ABRIR JOGO

function abrirJogo() {

    let endereco;

    try {

        endereco = validarURL(campoURL.value);

    } catch (erro) {

        informar(erro.message);

        return;

    }

    jogoAtual = endereco;

    frame.hidden = false;
    avisoInicial.hidden = true;

    $("camadaControles").hidden = !ativarControles.checked;

    informar(
        "Solicitando abertura do jogo...",
        "Carregando"
    );

    frame.src = endereco;

    console.log("Abrindo jogo:", endereco);

}


// BOTÃO DE ABERTURA

botaoAbrir.addEventListener(
    "click",
    abrirJogo
);

campoURL.addEventListener("keydown", evento => {

    if (evento.key === "Enter") {
        abrirJogo();
    }

});


// EVENTO DE CARREGAMENTO

frame.addEventListener("load", () => {

    if (!jogoAtual) return;

    informar(
        "Navegação concluída. Verifique se o jogo apareceu.",
        "Página carregada"
    );

    if (ativarControles.checked) {

        $("camadaControles").hidden = false;

        window.LinixJoystick.mostrar();

    }

    console.log("Navegação do iframe concluída.");

});


// ESCALA

function atualizarEscala() {

    const valor = Number(escala.value);

    frame.style.transform =
        `scale(${valor / 100})`;

    $("valorEscala").textContent =
        valor + "%";

}

escala.addEventListener(
    "input",
    atualizarEscala
);

botaoResetar.addEventListener("click", () => {

    escala.value = 100;

    atualizarEscala();

});


// TELA CHEIA

botaoTelaCheia.addEventListener("click", async () => {

    try {

        if (!document.fullscreenElement) {

            await areaJogo.requestFullscreen();

        } else {

            await document.exitFullscreen();

        }

    } catch (erro) {

        informar(
            "Este aplicativo não permitiu ativar a tela cheia.",
            "Tela cheia indisponível"
        );

        console.error(erro);

    }

});


// ORIENTAÇÃO PAISAGEM

botaoOrientacao.addEventListener("click", async () => {

    try {

        if (
            screen.orientation &&
            screen.orientation.lock
        ) {

            await screen.orientation.lock("landscape");

            informar(
                "Orientação paisagem solicitada.",
                "Paisagem"
            );

        } else {

            informar(
                "Este ambiente não oferece bloqueio de orientação.",
                "Paisagem indisponível"
            );

        }

    } catch (erro) {

        informar(
            "O aplicativo não permitiu alterar a orientação.",
            "Paisagem recusada"
        );

        console.warn(erro);

    }

});


// CONFIGURAÇÕES DO JOYSTICK

ativarControles.addEventListener("change", evento => {

    window.LinixJoystick.definirAtivo(
        evento.target.checked
    );

});

autoHide.addEventListener("change", evento => {

    window.LinixJoystick.definirAutoHide(
        evento.target.checked
    );

});

tempoHide.addEventListener("change", evento => {

    const valor = Number(evento.target.value);

    $("valorTempo").textContent =
        valor + " segundos";

    window.LinixJoystick.definirTempo(valor);

});

opacidade.addEventListener("input", evento => {

    const valor = Number(evento.target.value);

    $("valorOpacidade").textContent =
        valor + "%";

    window.LinixJoystick.definirOpacidade(valor);

});


// INICIALIZAÇÃO

function iniciarLinix() {

    window.LinixJoystick.iniciar({

        ativo: ativarControles.checked,

        autoHide: autoHide.checked,

        tempo: Number(tempoHide.value)

    });

    atualizarEscala();

    window.LinixJoystick.definirOpacidade(
        Number(opacidade.value)
    );

    console.log("Todos os módulos foram inicializados.");

}

iniciarLinix();
