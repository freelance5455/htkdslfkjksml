const express = require('express');
const { v4: uuid } = require('uuid');
const { get, run, query } = require('../database');
const { verifyToken } = require('../middleware/auth');

const jobRouter = express.Router();

jobRouter.get('/', (req, res) => {
  const { district, city, category, employmentType, qualification, salaryMin } = req.query;
  let sql = 'SELECT * FROM jobs WHERE is_active = 1';
  const params = [];

  if (district) { sql += ' AND district = ?'; params.push(district); }
  if (city) { sql += ' AND city = ?'; params.push(city); }
  if (category) { sql += ' AND category = ?'; params.push(category); }
  if (employmentType) { sql += ' AND employment_type = ?'; params.push(employmentType); }
  if (qualification) { sql += ' AND qualification LIKE ?'; params.push(`%${qualification}%`); }
  if (salaryMin) { sql += ' AND salary_min >= ?'; params.push(Number(salaryMin)); }

  sql += ' ORDER BY created_at DESC';
  const jobs = query(sql, params);
  res.json({ jobs });
});

jobRouter.get('/:id', (req, res) => {
  const job = get('SELECT * FROM jobs WHERE id = ?', [req.params.id]);
  if (!job) return res.status(404).json({ message: 'Job not found.' });
  res.json({ job });
});

jobRouter.post('/', verifyToken, (req, res) => {
  const { title, company, district, city, category, salaryMin, salaryMax, employmentType, qualification, description, requirements } = req.body;
  if (!title || !company || !district || !category || !employmentType) {
    return res.status(400).json({ message: 'Missing required job details.' });
  }

  const id = uuid();
  run(`
    INSERT INTO jobs (id, employer_id, title, company, district, city, category, salary_min, salary_max, employment_type, qualification, description, requirements, is_verified)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
  `, [id, req.user.id, title, company, district, city || district, category, Number(salaryMin || 0), Number(salaryMax || 0), employmentType, qualification || 'open', description || '', requirements || '']);

  res.status(201).json({ message: 'Job posted successfully.', id });
});

jobRouter.post('/:id/apply', verifyToken, (req, res) => {
  const { coverLetter } = req.body;
  const job = get('SELECT * FROM jobs WHERE id = ?', [req.params.id]);
  if (!job) return res.status(404).json({ message: 'Job not found.' });

  run('INSERT INTO job_applications (id, job_id, applicant_id, cover_letter, status) VALUES (?, ?, ?, ?, ?)', [uuid(), req.params.id, req.user.id, coverLetter || '', 'submitted']);
  res.status(201).json({ message: 'Application submitted successfully.' });
});

jobRouter.get('/:id/applications', verifyToken, (req, res) => {
  const applications = query('SELECT * FROM job_applications WHERE job_id = ? ORDER BY created_at DESC', [req.params.id]);
  res.json({ applications });
});

module.exports = { jobRouter };
