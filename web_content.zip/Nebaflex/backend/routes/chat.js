const express = require('express');
const { v4: uuid } = require('uuid');
const { get, query, run } = require('../database');

const chatRouter = express.Router();

chatRouter.get('/conversations', (req, res) => {
  const rows = query(`
    SELECT c.*, u.first_name, u.last_name, u.profile_picture
    FROM conversations c
    JOIN users u ON u.id = CASE WHEN c.participant_a = ? THEN c.participant_b ELSE c.participant_a END
    WHERE c.participant_a = ? OR c.participant_b = ?
    ORDER BY c.updated_at DESC
  `, [req.user.id, req.user.id, req.user.id]);
  res.json({ conversations: rows });
});

chatRouter.post('/conversations', (req, res) => {
  const { userId } = req.body;
  const participantA = req.user.id;
  const participantB = userId;
  const existing = get(`SELECT * FROM conversations WHERE (participant_a = ? AND participant_b = ?) OR (participant_a = ? AND participant_b = ?)`, [participantA, participantB, participantB, participantA]);
  if (existing) return res.json({ conversation: existing, message: 'Conversation already exists.' });
  const conversationId = uuid();
  run('INSERT INTO conversations (id, participant_a, participant_b, last_message, updated_at) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)', [conversationId, participantA, participantB, '']);
  res.status(201).json({ conversation: { id: conversationId, participant_a: participantA, participant_b: participantB } });
});

chatRouter.get('/conversations/:conversationId/messages', (req, res) => {
  const rows = query('SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC', [req.params.conversationId]);
  res.json({ messages: rows });
});

chatRouter.post('/conversations/:conversationId/messages', (req, res) => {
  const { content, type = 'text' } = req.body;
  if (!content) return res.status(400).json({ message: 'Message content is required.' });
  const conversation = get('SELECT * FROM conversations WHERE id = ?', [req.params.conversationId]);
  if (!conversation) return res.status(404).json({ message: 'Conversation not found.' });
  const messageId = uuid();
  run('INSERT INTO messages (id, conversation_id, sender_id, receiver_id, content, type) VALUES (?, ?, ?, ?, ?, ?)', [messageId, req.params.conversationId, req.user.id, req.user.id === conversation.participant_a ? conversation.participant_b : conversation.participant_a, content, type]);
  run('UPDATE conversations SET last_message = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [content, req.params.conversationId]);
  req.io.to(req.params.conversationId).emit('new-message', { conversationId: req.params.conversationId, content, senderId: req.user.id });
  res.status(201).json({ message: { id: messageId, content, sender_id: req.user.id } });
});

module.exports = { chatRouter };
