const express = require('express');
const { v4: uuid } = require('uuid');
const { query, run } = require('../database');

const notificationRouter = express.Router();

notificationRouter.get('/', (req, res) => {
  const rows = query('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50', [req.user.id]);
  res.json({ notifications: rows });
});

notificationRouter.post('/mark-read/:id', (req, res) => {
  run('UPDATE notifications SET read_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
  res.json({ message: 'Notification marked as read.' });
});

notificationRouter.post('/send', (req, res) => {
  const { userId, title, message, type } = req.body;
  if (!userId || !title || !message) return res.status(400).json({ message: 'User ID, title, and message are required.' });
  run('INSERT INTO notifications (id, user_id, title, message, type) VALUES (?, ?, ?, ?, ?)', [uuid(), userId, title, message, type || 'info']);
  res.json({ message: 'Notification created.' });
});

module.exports = { notificationRouter };
