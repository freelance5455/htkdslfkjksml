const express = require('express');
const { v4: uuid } = require('uuid');
const { get, run, query } = require('../database');

const financeRouter = express.Router();

const getAccount = (userId) => get('SELECT * FROM financial_accounts WHERE user_id = ?', [userId]);

financeRouter.get('/balance', (req, res) => {
  const account = getAccount(req.user.id);
  res.json({ balance: account?.balance || 0, currency: account?.currency || 'MWK' });
});

financeRouter.get('/transactions', (req, res) => {
  const txns = query('SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50', [req.user.id]);
  res.json({ transactions: txns });
});

financeRouter.post('/deposit', (req, res) => {
  const { amount, provider, method } = req.body;
  if (!amount || Number(amount) <= 0) return res.status(400).json({ message: 'A valid amount is required.' });
  const reference = `DEP-${uuid()}`;
  const account = getAccount(req.user.id);
  const transactionId = uuid();
  run('INSERT INTO transactions (id, user_id, type, category, amount, currency, status, provider, provider_reference, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [transactionId, req.user.id, 'deposit', 'wallet', Number(amount), 'MWK', 'pending', provider || 'PayChangu', reference, `${method || 'mobile_money'} deposit`]);
  res.status(201).json({ message: 'Deposit initiated. Pending provider confirmation.', reference, amount });
});

financeRouter.post('/transfer', (req, res) => {
  const { recipientUsername, amount, description } = req.body;
  if (!recipientUsername || !amount || Number(amount) <= 0) return res.status(400).json({ message: 'Recipient and amount are required.' });

  const recipient = get('SELECT * FROM users WHERE username = ?', [recipientUsername]);
  if (!recipient) return res.status(404).json({ message: 'Recipient not found.' });
  const fromAccount = getAccount(req.user.id);
  if (!fromAccount || Number(fromAccount.balance) < Number(amount)) return res.status(400).json({ message: 'Insufficient balance.' });

  const nextBalance = Number(fromAccount.balance) - Number(amount);
  run('UPDATE financial_accounts SET balance = ? WHERE user_id = ?', [nextBalance, req.user.id]);
  const toAccount = getAccount(recipient.id);
  run('UPDATE financial_accounts SET balance = ? WHERE user_id = ?', [Number(toAccount.balance || 0) + Number(amount), recipient.id]);
  run('INSERT INTO transactions (id, user_id, counterparty_id, type, category, amount, currency, status, provider, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [uuid(), req.user.id, recipient.id, 'transfer', 'wallet', Number(amount), 'MWK', 'completed', 'Nebaflex', description || 'Peer-to-peer transfer']);
  res.json({ message: 'Transfer completed successfully.' });
});

financeRouter.post('/withdraw', (req, res) => {
  const { amount, provider, destination } = req.body;
  if (!amount || Number(amount) <= 0) return res.status(400).json({ message: 'A valid withdrawal amount is required.' });
  run('INSERT INTO transactions (id, user_id, type, category, amount, currency, status, provider, description, metadata) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [uuid(), req.user.id, 'withdrawal', 'wallet', Number(amount), 'MWK', 'pending', provider || 'Airtel Money', `Withdrawal to ${destination || 'mobile wallet'}`, JSON.stringify({ destination })]);
  res.json({ message: 'Withdrawal request received and is under review.' });
});

financeRouter.post('/assistance-requests', (req, res) => {
  const { title, description, amount, category, district } = req.body;
  if (!title || !description || !amount) {
    return res.status(400).json({ message: 'Title, description, and amount are required.' });
  }
  run('INSERT INTO assistance_requests (id, user_id, title, description, amount, category, district) VALUES (?, ?, ?, ?, ?, ?, ?)', [uuid(), req.user.id, title, description, Number(amount), category || 'general', district || 'Lilongwe']);
  res.json({ message: 'Assistance request submitted for review.' });
});

financeRouter.get('/assistance-requests', (req, res) => {
  const rows = query('SELECT * FROM assistance_requests WHERE user_id = ? ORDER BY created_at DESC', [req.user.id]);
  res.json({ requests: rows });
});

module.exports = { financeRouter };
