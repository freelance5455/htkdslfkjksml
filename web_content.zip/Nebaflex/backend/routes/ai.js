const express = require('express');
const { query } = require('../database');

const aiRouter = express.Router();

const generateReply = (prompt) => {
  const lowered = String(prompt || '').toLowerCase();
  if (lowered.includes('cv') || lowered.includes('cover letter')) {
    return 'Here is a concise suggestion: lead with a summary of your experience, highlight Malawi-relevant skills, and keep the CV to two pages. I can help draft a tailored CV if you share your background.';
  }
  if (lowered.includes('interview')) {
    return 'Prepare for the STAR method. Explain a situation, task, action, and result. Practice common hiring questions for customer service, ICT, and service roles.';
  }
  if (lowered.includes('chem') || lowered.includes('physics')) {
    return 'For Chemistry, revise mole concepts, bonding, organic chemistry, and practicals. For Physics, focus on measurements, electricity, waves, and Newtonian mechanics.';
  }
  if (lowered.includes('scholarship')) {
    return 'Check the eligibility requirements, supporting documents, deadlines, and institution-specific criteria. Prepare your transcripts, recommendation letter, and statement of purpose.';
  }
  if (lowered.includes('job')) {
    return 'Search by district, category, salary band, and qualifications. Keep your CV matched to the vacancy and apply early for roles in Lilongwe, Blantyre, and Mzuzu.';
  }
  return 'I can help with job search, CV drafting, interview prep, scholarship guidance, study support, and quick summaries. Tell me what you need in plain language.';
};

aiRouter.post('/assist', (req, res) => {
  const { prompt } = req.body;
  if (!prompt) return res.status(400).json({ message: 'Prompt is required.' });
  const jobs = query('SELECT * FROM jobs WHERE is_active = 1 ORDER BY created_at DESC LIMIT 3');
  res.json({
    answer: generateReply(prompt),
    suggestedJobs: jobs,
    prompt,
  });
});

module.exports = { aiRouter };
