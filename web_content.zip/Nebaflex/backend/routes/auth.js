const express = require('express');
const bcrypt = require('bcryptjs');
const { v4: uuid } = require('uuid');
const { get, run } = require('../database');
const { signToken } = require('../middleware/auth');

const authRouter = express.Router();

const sanitizeUser = (user) => {
  if (!user) return null;
  const { password_hash, ...safe } = user;
  return safe;
};

authRouter.post('/register', async (req, res) => {
  const { firstName, lastName, email, phone, username, password, district, city } = req.body;

  if (!firstName || !lastName || !email || !password || !username) {
    return res.status(400).json({ message: 'Please provide all required registration details.' });
  }

  const existing = get('SELECT * FROM users WHERE email = ? OR username = ? OR phone = ?', [email, username, phone || '']);
  if (existing) {
    return res.status(409).json({ message: 'A user with that email, username, or phone already exists.' });
  }

  const userId = uuid();
  const passwordHash = await bcrypt.hash(password, 10);
  const created = run(
    `INSERT INTO users (id, first_name, last_name, email, phone, username, password_hash, district, city, role, email_verified, phone_verified)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'user', 0, 0)`,
    [userId, firstName, lastName, email, phone || null, username, passwordHash, district || null, city || null]
  );

  run('INSERT INTO user_settings (id, user_id) VALUES (?, ?)', [uuid(), userId]);
  run('INSERT INTO financial_accounts (id, user_id, balance, currency) VALUES (?, ?, ?, ?)', [uuid(), userId, 0, 'MWK']);

  const user = get('SELECT * FROM users WHERE id = ?', [userId]);
  const token = signToken(user);

  res.status(201).json({
    token,
    user: sanitizeUser(user),
    message: 'Registration successful. Please verify your email or phone to unlock full access.'
  });
});

authRouter.post('/login', async (req, res) => {
  const { emailOrUsername, password } = req.body;
  if (!emailOrUsername || !password) {
    return res.status(400).json({ message: 'Email/username and password are required.' });
  }

  const user = get(
    'SELECT * FROM users WHERE email = ? OR username = ? LIMIT 1',
    [emailOrUsername, emailOrUsername]
  );

  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ message: 'Invalid credentials.' });
  }

  const token = signToken(user);
  res.json({ token, user: sanitizeUser(user) });
});

authRouter.post('/logout', (req, res) => {
  res.json({ message: 'Logged out successfully.' });
});

authRouter.post('/verify-email', (req, res) => {
  const { userId } = req.body;
  if (!userId) return res.status(400).json({ message: 'User ID is required.' });
  run('UPDATE users SET email_verified = 1 WHERE id = ?', [userId]);
  res.json({ message: 'Email verified successfully.' });
});

authRouter.post('/verify-phone', (req, res) => {
  const { userId } = req.body;
  if (!userId) return res.status(400).json({ message: 'User ID is required.' });
  run('UPDATE users SET phone_verified = 1 WHERE id = ?', [userId]);
  res.json({ message: 'Phone verified successfully.' });
});

authRouter.post('/forgot-password', (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ message: 'Email is required.' });
  res.json({ message: 'Password recovery instructions have been sent to your email.' });
});

authRouter.post('/reset-password', (req, res) => {
  const { token, password } = req.body;
  if (!token || !password) return res.status(400).json({ message: 'Reset token and new password are required.' });
  res.json({ message: 'Password reset successfully.' });
});

module.exports = { authRouter };
