const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const { get, run, query } = require('../database');
const { requireRole } = require('../middleware/auth');

const userRouter = express.Router();
const uploadDir = path.join(__dirname, '..', '..', process.env.UPLOAD_DIR || 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => cb(null, `${Date.now()}-${file.originalname.replace(/\s+/g, '-')}`),
});
const upload = multer({ storage, limits: { fileSize: Number(process.env.MAX_FILE_SIZE || 5242880) } });

const sanitizeUser = (user) => {
  if (!user) return null;
  const { password_hash, ...safe } = user;
  return safe;
};

userRouter.get('/me', async (req, res) => {
  const user = get('SELECT * FROM users WHERE id = ?', [req.user.id]);
  res.json({ user: sanitizeUser(user) });
});

userRouter.patch('/me', async (req, res) => {
  const { firstName, lastName, bio, city, district, username, phone, privacyMode, language } = req.body;
  const update = run(
    `UPDATE users SET first_name = ?, last_name = ?, bio = ?, city = ?, district = ?, username = ?, phone = ?, privacy_mode = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
    [firstName || null, lastName || null, bio || null, city || null, district || null, username || null, phone || null, privacyMode || 'friends', req.user.id]
  );
  if (language) {
    run('INSERT INTO user_settings (id, user_id, language) VALUES (?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET language = excluded.language', [req.user.id, req.user.id, language]);
  }
  res.json({ message: 'Profile updated successfully.', affected: update.changes });
});

userRouter.post('/me/avatar', upload.single('avatar'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: 'No avatar file uploaded.' });
  }
  const avatarUrl = `/uploads/${req.file.filename}`;
  run('UPDATE users SET profile_picture = ? WHERE id = ?', [avatarUrl, req.user.id]);
  res.json({ avatarUrl, message: 'Profile picture updated.' });
});

userRouter.get('/me/notifications', (req, res) => {
  const rows = query('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50', [req.user.id]);
  res.json({ notifications: rows });
});

userRouter.get('/me/saved-jobs', (req, res) => {
  const rows = query(`
    SELECT j.* FROM saved_jobs s
    JOIN jobs j ON j.id = s.job_id
    WHERE s.user_id = ?
    ORDER BY s.created_at DESC
  `, [req.user.id]);
  res.json({ jobs: rows });
});

userRouter.post('/me/save-job/:jobId', (req, res) => {
  const existing = get('SELECT * FROM saved_jobs WHERE user_id = ? AND job_id = ?', [req.user.id, req.params.jobId]);
  if (existing) return res.json({ message: 'Job already saved.' });
  run('INSERT INTO saved_jobs (id, user_id, job_id) VALUES (?, ?, ?)', [require('uuid').v4(), req.user.id, req.params.jobId]);
  res.json({ message: 'Job saved successfully.' });
});

userRouter.get('/me/settings', (req, res) => {
  const settings = get('SELECT * FROM user_settings WHERE user_id = ?', [req.user.id]);
  res.json({ settings });
});

userRouter.patch('/me/settings', (req, res) => {
  const { notificationsEnabled, lowDataMode, darkMode, language } = req.body;
  run(`
    INSERT INTO user_settings (id, user_id, notifications_enabled, low_data_mode, dark_mode, language)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(user_id) DO UPDATE SET notifications_enabled = excluded.notifications_enabled, low_data_mode = excluded.low_data_mode, dark_mode = excluded.dark_mode, language = excluded.language
  `, [req.user.id, req.user.id, notificationsEnabled ?? 1, lowDataMode ?? 0, darkMode ?? 0, language || 'en']);
  res.json({ message: 'Settings updated.' });
});

userRouter.get('/support-tickets', (req, res) => {
  const tickets = query('SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC', [req.user.id]);
  res.json({ tickets });
});

userRouter.post('/support-tickets', (req, res) => {
  const { subject, message } = req.body;
  if (!subject || !message) return res.status(400).json({ message: 'Subject and message are required.' });
  const result = run('INSERT INTO support_tickets (id, user_id, subject, message) VALUES (?, ?, ?, ?)', [require('uuid').v4(), req.user.id, subject, message]);
  res.status(201).json({ message: 'Support ticket created.', id: result.lastInsertRowid });
});

userRouter.get('/directory', (req, res) => {
  const rows = query('SELECT * FROM users WHERE status = ? ORDER BY created_at DESC LIMIT 100', ['active']);
  res.json({ users: rows.map(sanitizeUser) });
});

userRouter.use(requireRole('admin'));
userRouter.get('/', (req, res) => {
  const rows = query('SELECT * FROM users ORDER BY created_at DESC');
  res.json({ users: rows.map(sanitizeUser) });
});

module.exports = { userRouter };
