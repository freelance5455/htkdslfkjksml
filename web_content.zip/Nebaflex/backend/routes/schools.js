const express = require('express');
const { v4: uuid } = require('uuid');
const { query, get, run } = require('../database');

const schoolRouter = express.Router();

schoolRouter.get('/scholarships', (req, res) => {
  const { district, subject, institution, qualification } = req.query;
  let sql = 'SELECT * FROM scholarships WHERE is_active = 1';
  const params = [];
  if (district) { sql += ' AND district = ?'; params.push(district); }
  if (subject) { sql += ' AND subject LIKE ?'; params.push(`%${subject}%`); }
  if (institution) { sql += ' AND institution LIKE ?'; params.push(`%${institution}%`); }
  if (qualification) { sql += ' AND qualification LIKE ?'; params.push(`%${qualification}%`); }
  sql += ' ORDER BY deadline ASC';
  res.json({ scholarships: query(sql, params) });
});

schoolRouter.get('/scholarships/:id', (req, res) => {
  const scholarship = get('SELECT * FROM scholarships WHERE id = ?', [req.params.id]);
  if (!scholarship) return res.status(404).json({ message: 'Scholarship not found.' });
  res.json({ scholarship });
});

schoolRouter.post('/scholarships', (req, res) => {
  const { providerName, title, institution, qualification, subject, district, deadline, eligibility, description, applicationUrl } = req.body;
  if (!title || !institution || !deadline) return res.status(400).json({ message: 'Title, institution, and deadline are required.' });
  run(`INSERT INTO scholarships (id, provider_name, title, institution, qualification, subject, district, deadline, eligibility, description, application_url)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [uuid(), providerName || 'Nebaflex', title, institution, qualification || 'General', subject || '', district || 'Lilongwe', deadline, eligibility || '', description || '', applicationUrl || '']);
  res.status(201).json({ message: 'Scholarship opportunity added successfully.' });
});

module.exports = { schoolRouter };
