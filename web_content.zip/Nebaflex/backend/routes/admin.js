const express = require('express');
const { query, get, run } = require('../database');

const adminRouter = express.Router();

adminRouter.get('/overview', (req, res) => {
  const users = query('SELECT COUNT(*) as count FROM users');
  const jobs = query('SELECT COUNT(*) as count FROM jobs');
  const scholarships = query('SELECT COUNT(*) as count FROM scholarships');
  const transactions = query('SELECT SUM(amount) as total FROM transactions WHERE status = ?', ['completed']);
  res.json({ overview: { users: users[0].count, jobs: jobs[0].count, scholarships: scholarships[0].count, transactionVolume: transactions[0].total || 0 } });
});

adminRouter.get('/transactions', (req, res) => {
  const txns = query('SELECT * FROM transactions ORDER BY created_at DESC LIMIT 100');
  res.json({ transactions: txns });
});

adminRouter.get('/reports', (req, res) => {
  const rows = query('SELECT * FROM support_tickets ORDER BY created_at DESC');
  res.json({ reports: rows });
});

adminRouter.post('/jobs/:id/verify', (req, res) => {
  run('UPDATE jobs SET is_verified = 1 WHERE id = ?', [req.params.id]);
  res.json({ message: 'Job approved and marked as verified.' });
});

adminRouter.post('/users/:id/status', (req, res) => {
  const { status } = req.body;
  run('UPDATE users SET status = ? WHERE id = ?', [status || 'active', req.params.id]);
  res.json({ message: 'User status updated.' });
});

module.exports = { adminRouter };
