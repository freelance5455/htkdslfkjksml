const test = require('node:test');
const assert = require('node:assert/strict');
const { initializeDatabase, seedSampleData } = require('./database');

test('database initializes and seeds sample data', () => {
  initializeDatabase();
  seedSampleData();
  assert.doesNotThrow(() => initializeDatabase());
});
