const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const { v4: uuid } = require('uuid');

const dbPath = path.resolve(__dirname, '..', process.env.DB_PATH || './nebaflex.db');
const db = new Database(dbPath);

const initializeDatabase = () => {
  db.pragma('journal_mode = WAL');

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      first_name TEXT,
      last_name TEXT,
      email TEXT UNIQUE,
      phone TEXT UNIQUE,
      username TEXT UNIQUE,
      password_hash TEXT,
      profile_picture TEXT,
      district TEXT,
      city TEXT,
      bio TEXT,
      role TEXT DEFAULT 'user',
      email_verified INTEGER DEFAULT 0,
      phone_verified INTEGER DEFAULT 0,
      status TEXT DEFAULT 'active',
      privacy_mode TEXT DEFAULT 'friends',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS user_settings (
      id TEXT PRIMARY KEY,
      user_id TEXT UNIQUE,
      notifications_enabled INTEGER DEFAULT 1,
      low_data_mode INTEGER DEFAULT 0,
      dark_mode INTEGER DEFAULT 0,
      language TEXT DEFAULT 'en',
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      title TEXT,
      message TEXT,
      type TEXT,
      read_at TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS jobs (
      id TEXT PRIMARY KEY,
      employer_id TEXT,
      title TEXT,
      company TEXT,
      district TEXT,
      city TEXT,
      category TEXT,
      salary_min INTEGER,
      salary_max INTEGER,
      employment_type TEXT,
      qualification TEXT,
      description TEXT,
      requirements TEXT,
      is_verified INTEGER DEFAULT 0,
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (employer_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS job_applications (
      id TEXT PRIMARY KEY,
      job_id TEXT,
      applicant_id TEXT,
      cv_path TEXT,
      cover_letter TEXT,
      status TEXT DEFAULT 'submitted',
      notes TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (job_id) REFERENCES jobs(id),
      FOREIGN KEY (applicant_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS saved_jobs (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      job_id TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (job_id) REFERENCES jobs(id)
    );

    CREATE TABLE IF NOT EXISTS scholarships (
      id TEXT PRIMARY KEY,
      provider_name TEXT,
      title TEXT,
      institution TEXT,
      qualification TEXT,
      subject TEXT,
      district TEXT,
      deadline TEXT,
      eligibility TEXT,
      description TEXT,
      application_url TEXT,
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS financial_accounts (
      id TEXT PRIMARY KEY,
      user_id TEXT UNIQUE,
      balance REAL DEFAULT 0,
      currency TEXT DEFAULT 'MWK',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      counterparty_id TEXT,
      type TEXT,
      category TEXT,
      amount REAL,
      currency TEXT DEFAULT 'MWK',
      status TEXT DEFAULT 'pending',
      provider TEXT,
      provider_reference TEXT,
      description TEXT,
      metadata TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (counterparty_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS assistance_requests (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      title TEXT,
      description TEXT,
      amount REAL,
      category TEXT,
      district TEXT,
      status TEXT DEFAULT 'open',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS conversations (
      id TEXT PRIMARY KEY,
      participant_a TEXT,
      participant_b TEXT,
      last_message TEXT,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (participant_a) REFERENCES users(id),
      FOREIGN KEY (participant_b) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      conversation_id TEXT,
      sender_id TEXT,
      receiver_id TEXT,
      content TEXT,
      media_url TEXT,
      type TEXT DEFAULT 'text',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      read_at TEXT,
      FOREIGN KEY (conversation_id) REFERENCES conversations(id),
      FOREIGN KEY (sender_id) REFERENCES users(id),
      FOREIGN KEY (receiver_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS audits (
      id TEXT PRIMARY KEY,
      actor_id TEXT,
      action TEXT,
      entity_type TEXT,
      entity_id TEXT,
      details TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS support_tickets (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      subject TEXT,
      message TEXT,
      status TEXT DEFAULT 'open',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );
  `);

  const adminExists = db.prepare('SELECT id FROM users WHERE role = ?').get('admin');
  if (!adminExists) {
    const adminId = uuid();
    const passwordHash = bcrypt.hashSync('Admin@123', 10);
    db.prepare(`
      INSERT INTO users (id, first_name, last_name, email, username, password_hash, role, email_verified, phone_verified, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, 1, 1, 'active')
    `).run(adminId, 'Nebaflex', 'Admin', 'admin@nebaflex.mw', 'admin', passwordHash, 'admin');
    db.prepare('INSERT INTO financial_accounts (id, user_id, balance, currency) VALUES (?, ?, ?, ?)')
      .run(uuid(), adminId, 0, 'MWK');
  }
};

const seedSampleData = () => {
  const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
  if (userCount > 1) return;

  const userId = uuid();
  const passwordHash = bcrypt.hashSync('Password@123', 10);
  db.prepare(`
    INSERT INTO users (id, first_name, last_name, email, phone, username, password_hash, district, city, role, email_verified, phone_verified, bio)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, ?)
  `).run(
    userId,
    'Chimwemwe',
    'Kumwenda',
    'demo@nebaflex.mw',
    '+265912345678',
    'chimwemwe',
    passwordHash,
    'Lilongwe',
    'Lilongwe',
    'user',
    'Malawian professional exploring opportunities and support.'
  );

  db.prepare('INSERT INTO financial_accounts (id, user_id, balance, currency) VALUES (?, ?, ?, ?)')
    .run(uuid(), userId, 25000, 'MWK');

  db.prepare(`
    INSERT INTO jobs (id, employer_id, title, company, district, city, category, salary_min, salary_max, employment_type, qualification, description, requirements, is_verified, is_active)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1)
  `).run(
    uuid(),
    userId,
    'Customer Support Officer',
    'NBS Bank',
    'Lilongwe',
    'Lilongwe',
    'Customer Service',
    180000,
    260000,
    'full-time',
    'Diploma in Business Administration',
    'Support customers and resolve banking service issues.',
    'Strong communication skills; customer service experience preferred; computer literacy.',
  );

  db.prepare(`
    INSERT INTO scholarships (id, provider_name, title, institution, qualification, subject, district, deadline, eligibility, description, application_url, is_active)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
  `).run(
    uuid(),
    'Malawi Education Trust',
    'STEM Scholarship 2026',
    'University of Malawi',
    'Undergraduate',
    'Physics',
    'Blantyre',
    '2026-12-15',
    'Malawian students with strong academic merit and financial need',
    'Partial bursary support for physics and engineering students.',
    'https://example.com/scholarship',
  );
};

const query = (sql, params = []) => db.prepare(sql).all(...params);
const get = (sql, params = []) => db.prepare(sql).get(...params);
const run = (sql, params = []) => db.prepare(sql).run(...params);
const transaction = (fn) => db.transaction(fn);

module.exports = {
  db,
  initializeDatabase,
  seedSampleData,
  query,
  get,
  run,
  transaction,
  uuid,
};
