const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const dotenv = require('dotenv');
const path = require('path');
const fs = require('fs');
const { Server } = require('socket.io');
const http = require('http');
const { initializeDatabase, seedSampleData } = require('./database');
const { authRouter } = require('./routes/auth');
const { userRouter } = require('./routes/users');
const { jobRouter } = require('./routes/jobs');
const { financeRouter } = require('./routes/finance');
const { schoolRouter } = require('./routes/schools');
const { chatRouter } = require('./routes/chat');
const { notificationRouter } = require('./routes/notifications');
const { adminRouter } = require('./routes/admin');
const { aiRouter } = require('./routes/ai');
const { verifyToken, requireRole } = require('./middleware/auth');

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: process.env.CLIENT_URL || '*',
    methods: ['GET', 'POST']
  }
});

const uploadsDir = path.join(__dirname, '..', process.env.UPLOAD_DIR || 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const frontendDir = path.join(__dirname, '..', 'frontend');
app.use('/uploads', express.static(uploadsDir));
app.use(express.static(frontendDir));
app.use(cors({ origin: true, credentials: true }));
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('combined'));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 250, standardHeaders: true, legacyHeaders: false }));

app.use((req, res, next) => {
  req.io = io;
  next();
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok', app: 'Nebaflex', timestamp: new Date().toISOString() });
});

app.get('/', (req, res) => {
  res.sendFile(path.join(frontendDir, 'index.html'));
});

app.use('/api/auth', authRouter);
app.use('/api/users', verifyToken, userRouter);
app.use('/api/jobs', jobRouter);
app.use('/api/finance', verifyToken, financeRouter);
app.use('/api/schools', schoolRouter);
app.use('/api/chat', verifyToken, chatRouter);
app.use('/api/notifications', verifyToken, notificationRouter);
app.use('/api/admin', verifyToken, requireRole('admin'), adminRouter);
app.use('/api/ai', verifyToken, aiRouter);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({
    message: err.message || 'Internal server error',
    details: process.env.APP_ENV === 'development' ? err.stack : undefined
  });
});

const startServer = () => {
  const port = Number(process.env.PORT || 3000);
  initializeDatabase();
  seedSampleData();

  io.on('connection', (socket) => {
    socket.on('join-room', (roomId) => socket.join(roomId));
    socket.on('send-message', (payload) => {
      io.to(payload.roomId).emit('new-message', payload.message);
    });
  });

  server.listen(port, () => {
    console.log(`Nebaflex server listening on http://localhost:${port}`);
  });
};

startServer();

module.exports = { app, server, io };
