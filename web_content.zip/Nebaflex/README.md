# Nebaflex

Nebaflex is a Malawi-focused digital platform for jobs, financial assistance, education, and communication. It combines secure authentication, a job marketplace, financial assistance features, school support, AI assistance, messaging, and admin controls in a single platform.

## Features

- Mobile-first responsive web app UI with English and Chichewa support
- Secure user registration, login, logout, profile management, and password recovery
- Job marketplace with district, category, salary, qualification and employment-type filters
- Financial assistance, wallet transfers, mobile money deposit/withdrawal flows, and transaction history
- School support and scholarships discovery
- AI assistant for CV, interview, and study support
- Messaging, notifications, and admin dashboard
- Production-oriented backend using Node.js and SQLite for local development

## Stack

- Frontend: HTML + CSS + JavaScript (responsive single-page app)
- Backend: Node.js + Express
- Database: SQLite via better-sqlite3
- Real-time: Socket.IO
- Auth: JWT
- Security: Helmet, CORS, rate limiting, validation

## Run locally

1. Install dependencies:
   npm install
2. Copy `.env.example` to `.env` and update credentials.
3. Start the API server:
   npm run dev
4. Open the app at http://localhost:3000

## Environment variables

- PORT
- JWT_SECRET
- SESSION_SECRET
- CLIENT_URL
- APP_NAME
- APP_ENV
- PAYCHANGU_BASE_URL
- PAYCHANGU_API_KEY
- PAYCHANGU_SECRET
- PAYCHANGU_MERCHANT_ID
- SMTP_HOST
- SMTP_USER
- SMTP_PASS
- UPLOAD_DIR
- MAX_FILE_SIZE
- DEFAULT_CURRENCY
- DB_PATH

## API overview

- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `POST /api/auth/forgot-password`
- `GET /api/jobs`
- `POST /api/jobs`
- `POST /api/jobs/:id/apply`
- `GET /api/finance/balance`
- `POST /api/finance/deposit`
- `POST /api/finance/transfer`
- `POST /api/finance/withdraw`
- `GET /api/schools/scholarships`
- `POST /api/ai/assist`
- `GET /api/chat/conversations`

## Deployment guidance

- Use a managed Node.js host or container platform.
- Configure production env vars and a secure database backend.
- Set up backups, SSL, and a CDN for static assets.
- Replace SQLite with PostgreSQL in production for larger workloads.

## Testing

- Run `npm test` after adding or updating API validations.
- Verify registration, login, job posting, transfer, and scholarship flows.

## Security notes

- Never store payment PINs or OTPs in plaintext.
- Use provider-managed credentials for PayChangu and mobile money integrations.
- Log audit events for security-sensitive actions.
- Keep the JWT secret in environment variables.
