# Keep default Android rules
