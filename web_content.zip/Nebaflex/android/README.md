# Android app setup for Nebaflex

This folder contains the Android Studio project structure for packaging Nebaflex as an APK.

## Notes

- The app loads the Nebaflex web experience inside a `WebView`.
- Replace `https://localhost:3000` in `MainActivity.java` with your deployed production URL or the local network IP used while testing on an Android device.
- This is a production-ready starting point for Android packaging, but a full Play Store release should include digital asset generation, signing configuration, and testing across Android devices.

## Open in Android Studio

1. Open Android Studio.
2. Choose "Open" and select the `android` folder.
3. Let Gradle sync complete.
4. Build > Generate Signed Bundle / APK.

## Build a debug APK

- In Android Studio: Build > Build APK(s)
