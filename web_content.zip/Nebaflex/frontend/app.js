const appRoot = document.getElementById('app');

const state = {
  user: null,
  token: localStorage.getItem('nebaflexToken') || '',
  page: 'home',
  jobs: [],
  scholarships: [],
  notifications: [],
  transactions: [],
  balance: 0,
  conversations: [],
  activeConversation: null,
};

const formatMWK = (value) => new Intl.NumberFormat('en-MW', { style: 'currency', currency: 'MWK', maximumFractionDigits: 0 }).format(Number(value || 0));

const api = async (path, options = {}) => {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  const response = await fetch(`/api${path}`, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || 'Request failed.');
  return data;
};

const renderHome = () => {
  const heroStats = [
    { label: 'Active jobs', value: '1.6k+' },
    { label: 'Verified users', value: '48k' },
    { label: 'Support funded', value: 'MK 120M' },
  ];

  const features = [
    { icon: 'work', title: 'Job marketplace', text: 'Search roles across Malawi, from Lilongwe to Mzuzu, with filters for district, salary, qualification, and type.' },
    { icon: 'wallet', title: 'Financial support', text: 'Request assistance, donate, transfer securely, and manage balances with wallet and mobile money support.' },
    { icon: 'school', title: 'School support', text: 'Find scholarships, bursaries, revision notes, exam past papers, and learning tools aligned to your path.' },
    { icon: 'groups', title: 'Community help', text: 'Volunteer, fundraise, connect with professionals, and grow your network in ways that matter locally.' },
  ];

  const recentJobs = [
    { title: 'Customer Support Officer', company: 'NBS Bank', tag: 'Verified' },
    { title: 'Junior Software Developer', company: 'BAS', tag: 'Hybrid' },
    { title: 'Agricultural Extension Officer', company: 'World Food Programme', tag: 'Field' },
  ];

  return `
    <header class="topbar">
      <div class="container topbar-inner">
        <div class="brand"><span class="brand-mark">N</span> Nebaflex</div>
        <nav class="nav">
          <a href="#">Home</a>
          <a href="#jobs">Jobs</a>
          <a href="#finance">Finance</a>
          <a href="#school">School</a>
          <a href="#messaging">Messaging</a>
          <a href="#help">Help</a>
        </nav>
        <div class="topbar-actions">
          <button class="btn ghost" data-page="login">Log in</button>
          <button class="btn primary" data-page="register">Get started</button>
        </div>
      </div>
    </header>

    <main class="container">
      <section class="hero">
        <div class="hero-grid">
          <div class="hero-panel">
            <span class="eyebrow">Built for Malawi</span>
            <h1>Opportunities. Support. Growth.</h1>
            <p class="subtitle">Nebaflex brings together jobs, education, financial assistance, and community communication in one secure digital platform tailored for people across Malawi.</p>
            <div class="hero-actions">
              <button class="btn primary" data-page="register">Create account</button>
              <button class="btn secondary" data-page="jobs">Explore roles</button>
            </div>
            <div class="stat-row">
              ${heroStats.map((item) => `
                <div class="stat-card">
                  <div class="stat-number">${item.value}</div>
                  <div class="stat-label">${item.label}</div>
                </div>
              `).join('')}
            </div>
          </div>
          <div class="dashboard-card">
            <div class="dashboard-header">
              <strong>Live snapshot</strong>
              <span class="pill">Verified</span>
            </div>
            <div class="list">
              ${recentJobs.map((job) => `
                <div class="list-item">
                  <div>
                    <strong>${job.title}</strong>
                    <small>${job.company}</small>
                  </div>
                  <span class="badge info">${job.tag}</span>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </section>

      <section class="section">
        <div class="section-header">
          <h2>Everything you need in one place</h2>
          <p>Designed for real-life needs across Malawi.</p>
        </div>
        <div class="feature-cards">
          ${features.map((feature) => `
            <article class="feature-card">
              <div class="feature-icon"><span class="material-symbols-rounded">${feature.icon}</span></div>
              <h3>${feature.title}</h3>
              <p>${feature.text}</p>
            </article>
          `).join('')}
        </div>
      </section>

      <section class="section">
        <div class="section-header">
          <h2>Why Nebaflex works</h2>
          <p>Trust, speed, accessibility, and local relevance.</p>
        </div>
        <div class="card-grid">
          <article class="info-card">
            <div class="feature-icon"><span class="material-symbols-rounded">security</span></div>
            <h3>Secure by design</h3>
            <p>Protected authentication, privacy settings, audit logging, and secure financial flows built around trusted provider capabilities.</p>
          </article>
          <article class="info-card">
            <div class="feature-icon"><span class="material-symbols-rounded">smartphone</span></div>
            <h3>Mobile-first access</h3>
            <p>Optimized for Android, tablets, and desktop computers with low-data options and intuitive navigation across every key workflow.</p>
          </article>
          <article class="info-card">
            <div class="feature-icon"><span class="material-symbols-rounded">public</span></div>
            <h3>Local relevance</h3>
            <p>District-based discovery, Malawian MTN/Airtel/TNM mobile money patterns, and language support built around local realities.</p>
          </article>
        </div>
      </section>
    </main>
  `;
};

const renderRegister = () => `
  <header class="topbar">
    <div class="container topbar-inner">
      <div class="brand"><span class="brand-mark">N</span> Nebaflex</div>
      <div class="topbar-actions">
        <button class="btn ghost" data-page="login">Already have an account?</button>
      </div>
    </div>
  </header>
  <main class="container" style="padding: 40px 0 60px;">
    <div class="form-panel" style="max-width: 900px; margin: 0 auto;">
      <div class="section-header">
        <div>
          <span class="eyebrow">Create account</span>
          <h2 style="margin-top: 12px;">Join Nebaflex</h2>
        </div>
      </div>
      <form id="register-form">
        <div class="form-grid">
          <div class="field"><label>First name</label><input name="firstName" required /></div>
          <div class="field"><label>Last name</label><input name="lastName" required /></div>
          <div class="field"><label>Email</label><input type="email" name="email" required /></div>
          <div class="field"><label>Phone</label><input name="phone" /></div>
          <div class="field"><label>Username</label><input name="username" required /></div>
          <div class="field"><label>District</label><input name="district" /></div>
          <div class="field"><label>City</label><input name="city" /></div>
          <div class="field"><label>Password</label><input type="password" name="password" required /></div>
        </div>
        <div class="inline-actions">
          <button class="btn primary" type="submit">Create account</button>
          <button class="btn ghost" type="button" data-page="login">Cancel</button>
        </div>
      </form>
    </div>
  </main>
`;

const renderLogin = () => `
  <header class="topbar">
    <div class="container topbar-inner">
      <div class="brand"><span class="brand-mark">N</span> Nebaflex</div>
      <div class="topbar-actions">
        <button class="btn ghost" data-page="register">Create account</button>
      </div>
    </div>
  </header>
  <main class="container" style="padding: 40px 0 60px;">
    <div class="form-panel" style="max-width: 620px; margin: 0 auto;">
      <div class="section-header">
        <div>
          <span class="eyebrow">Welcome back</span>
          <h2 style="margin-top: 12px;">Sign in</h2>
        </div>
      </div>
      <form id="login-form">
        <div class="field" style="margin-bottom: 16px;">
          <label>Email or username</label>
          <input name="emailOrUsername" required />
        </div>
        <div class="field" style="margin-bottom: 16px;">
          <label>Password</label>
          <input type="password" name="password" required />
        </div>
        <div class="inline-actions">
          <button class="btn primary" type="submit">Sign in</button>
          <button class="btn ghost" type="button" data-page="home">Back home</button>
        </div>
      </form>
    </div>
  </main>
`;

const renderDashboard = () => `
  <header class="topbar">
    <div class="container topbar-inner">
      <div class="brand"><span class="brand-mark">N</span> Nebaflex</div>
      <div class="topbar-actions">
        <button class="btn ghost" data-page="home">Home</button>
        <button class="btn primary" id="logout-btn">Logout</button>
      </div>
    </div>
  </header>
  <main class="container app-layout">
    <aside class="sidebar">
      <h3>Workspace</h3>
      <nav>
        <a href="#" class="active" data-page="dashboard">Overview</a>
        <a href="#" data-page="jobs">Jobs</a>
        <a href="#" data-page="finance">Wallet</a>
        <a href="#" data-page="school">School</a>
        <a href="#" data-page="messages">Messages</a>
        <a href="#" data-page="profile">Profile</a>
      </nav>
    </aside>
    <div class="main-panel">
      <div class="metric-grid">
        <div class="metric-box"><div class="value">${state.jobs.length || 0}</div><div class="label">Saved jobs</div></div>
        <div class="metric-box"><div class="value">${formatMWK(state.balance)}</div><div class="label">Wallet</div></div>
        <div class="metric-box"><div class="value">${state.notifications.length || 0}</div><div class="label">Alerts</div></div>
        <div class="metric-box"><div class="value">2</div><div class="label">Applications</div></div>
      </div>
      <section class="form-panel">
        <div class="section-header">
          <div>
            <span class="eyebrow">Welcome</span>
            <h2 style="margin-top:8px;">${state.user ? `${state.user.first_name} ${state.user.last_name}` : 'User'}</h2>
          </div>
          <span class="pill">Profile active</span>
        </div>
        <div class="card-grid">
          <article class="info-card">
            <div class="feature-icon"><span class="material-symbols-rounded">work</span></div>
            <h3>Open opportunities</h3>
            <p>Check the latest verified jobs and apply quickly with your CV and qualifications.</p>
          </article>
          <article class="info-card">
            <div class="feature-icon"><span class="material-symbols-rounded">school</span></div>
            <h3>School support</h3>
            <p>Track scholarships, deadlines, notes, and revision materials designed for your study path.</p>
          </article>
          <article class="info-card">
            <div class="feature-icon"><span class="material-symbols-rounded">smart_toy</span></div>
            <h3>AI assistant</h3>
            <p>Ask for help with CVs, interview prep, study revision, and scholarships in plain language.</p>
          </article>
        </div>
      </section>
    </div>
  </main>
`;

const renderJobs = async () => {
  try {
    const data = await api('/jobs');
    state.jobs = data.jobs || [];
  } catch (error) { console.error(error); state.jobs = []; }

  return `
    <header class="topbar">
      <div class="container topbar-inner">
        <div class="brand"><span class="brand-mark">N</span> Nebaflex</div>
        <div class="topbar-actions">
          <button class="btn ghost" data-page="dashboard">Dashboard</button>
          <button class="btn primary" data-page="register">Publish vacancy</button>
        </div>
      </div>
    </header>
    <main class="container" style="padding: 30px 0 60px;">
      <div class="section-header">
        <div>
          <span class="eyebrow">Job marketplace</span>
          <h2 style="margin-top: 10px;">Malawi jobs</h2>
        </div>
      </div>
      <div class="form-panel" style="margin-bottom: 20px;">
        <div class="form-grid">
          <div class="field"><label>District</label><input id="job-district" /></div>
          <div class="field"><label>Career category</label><input id="job-category" /></div>
          <div class="field"><label>Employment type</label><select id="job-type"><option value="">Any</option><option value="full-time">Full-time</option><option value="part-time">Part-time</option><option value="contract">Contract</option></select></div>
          <div class="field"><label>Minimum salary</label><input id="job-salary" type="number" placeholder="200000" /></div>
        </div>
        <div class="inline-actions">
          <button class="btn primary" id="search-jobs-btn">Search jobs</button>
          <button class="btn ghost" type="button" data-page="register">Post a role</button>
        </div>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Role</th><th>Company</th><th>Location</th><th>Category</th><th>Salary</th><th>Status</th></tr>
          </thead>
          <tbody>
            ${state.jobs.length ? state.jobs.map((job) => `
              <tr>
                <td><strong>${job.title}</strong><br><small>${job.qualification}</small></td>
                <td>${job.company}</td>
                <td>${job.city || job.district}</td>
                <td>${job.category}</td>
                <td>${formatMWK(job.salary_min)} - ${formatMWK(job.salary_max)}</td>
                <td><span class="badge success">${job.is_verified ? 'Verified' : 'Open'}</span></td>
              </tr>
            `).join('') : '<tr><td colspan="6">No jobs found yet.</td></tr>'}
          </tbody>
        </table>
      </div>
    </main>
  `;
};

const renderFinance = async () => {
  if (state.token) {
    try {
      const balanceData = await api('/finance/balance');
      state.balance = balanceData.balance || 0;
      const transactionsData = await api('/finance/transactions');
      state.transactions = transactionsData.transactions || [];
    } catch (error) { console.error(error); }
  }

  return `
    <header class="topbar"><div class="container topbar-inner"><div class="brand"><span class="brand-mark">N</span> Nebaflex</div><div class="topbar-actions"><button class="btn ghost" data-page="dashboard">Dashboard</button></div></div></header>
    <main class="container" style="padding:30px 0 60px;">
      <div class="section-header">
        <div><span class="eyebrow">Finance</span><h2 style="margin-top:10px;">Wallet & assistance</h2></div>
      </div>
      <div class="metric-grid" style="margin-bottom:16px;">
        <div class="metric-box"><div class="value">${formatMWK(state.balance)}</div><div class="label">Available balance</div></div>
        <div class="metric-box"><div class="value">${state.transactions.length || 0}</div><div class="label">Transactions</div></div>
        <div class="metric-box"><div class="value">3</div><div class="label">Open requests</div></div>
        <div class="metric-box"><div class="value">MK 0</div><div class="label">Pending cash-out</div></div>
      </div>
      <div class="form-panel">
        <div class="form-grid">
          <div class="field"><label>Amount</label><input id="finance-amount" type="number" placeholder="5000" /></div>
          <div class="field"><label>Provider</label><select id="finance-provider"><option value="PayChangu">PayChangu</option><option value="Airtel Money">Airtel Money</option><option value="TNM Mpamba">TNM Mpamba</option></select></div>
          <div class="field"><label>Recipient username</label><input id="transfer-recipient" placeholder="recipient username" /></div>
          <div class="field"><label>Purpose</label><input id="transfer-purpose" placeholder="rent, school fees, food" /></div>
        </div>
        <div class="inline-actions">
          <button class="btn primary" id="deposit-btn">Deposit</button>
          <button class="btn secondary" id="transfer-btn">Transfer</button>
          <button class="btn ghost" id="withdraw-btn">Withdraw</button>
        </div>
      </div>
      <div class="table-wrap" style="margin-top: 20px;">
        <table>
          <thead><tr><th>Type</th><th>Amount</th><th>Provider</th><th>Status</th></tr></thead>
          <tbody>
            ${state.transactions.length ? state.transactions.map((tx) => `
              <tr><td>${tx.type}</td><td>${formatMWK(tx.amount)}</td><td>${tx.provider || 'Nebaflex'}</td><td><span class="badge ${tx.status === 'completed' ? 'success' : 'warning'}">${tx.status}</span></td></tr>
            `).join('') : '<tr><td colspan="4">No transactions yet.</td></tr>'}
          </tbody>
        </table>
      </div>
    </main>
  `;
};

const renderSchool = async () => {
  try {
    const data = await api('/schools/scholarships');
    state.scholarships = data.scholarships || [];
  } catch (error) { state.scholarships = []; }

  return `
    <header class="topbar"><div class="container topbar-inner"><div class="brand"><span class="brand-mark">N</span> Nebaflex</div><div class="topbar-actions"><button class="btn ghost" data-page="dashboard">Dashboard</button></div></div></header>
    <main class="container" style="padding:30px 0 60px;">
      <div class="section-header"><div><span class="eyebrow">School support</span><h2 style="margin-top:10px;">Scholarships & resources</h2></div></div>
      <div class="form-panel" style="margin-bottom:20px;">
        <div class="form-grid">
          <div class="field"><label>Institution</label><input id="school-institution" /></div>
          <div class="field"><label>Subject</label><input id="school-subject" /></div>
          <div class="field"><label>District</label><input id="school-district" /></div>
          <div class="field"><label>Qualification</label><input id="school-qualification" /></div>
        </div>
        <div class="inline-actions"><button class="btn primary" id="search-school-btn">Find opportunities</button></div>
      </div>
      <div class="card-grid">
        ${state.scholarships.length ? state.scholarships.map((item) => `
          <article class="info-card">
            <span class="eyebrow" style="background: rgba(87,184,144,0.12); color: var(--green-600);">${item.subject || 'Education'}</span>
            <h3>${item.title}</h3>
            <p><strong>${item.institution}</strong><br>${item.description}</p>
            <p style="margin-top: 8px;">Deadline: ${item.deadline}<br>District: ${item.district}</p>
          </article>
        `).join('') : '<div class="info-card"><h3>No scholarships available.</h3></div>'}
      </div>
    </main>
  `;
};

const renderMessages = () => `
  <header class="topbar"><div class="container topbar-inner"><div class="brand"><span class="brand-mark">N</span> Nebaflex</div><div class="topbar-actions"><button class="btn ghost" data-page="dashboard">Dashboard</button></div></div></header>
  <main class="container" style="padding:30px 0 60px;">
    <div class="section-header"><div><span class="eyebrow">Messaging</span><h2 style="margin-top:10px;">Conversations</h2></div></div>
    <div class="form-panel">
      <div class="field" style="margin-bottom: 18px;"><label>Recipient username</label><input id="chat-recipient" placeholder="chimwemwe" /></div>
      <div class="inline-actions"><button class="btn primary" id="start-chat-btn">Start chat</button></div>
      <div style="margin-top: 16px; color: var(--muted);">Protected private messages and voice/file sharing are available through the secure chat system.</div>
    </div>
  </main>
`;

const renderProfile = () => `
  <header class="topbar"><div class="container topbar-inner"><div class="brand"><span class="brand-mark">N</span> Nebaflex</div><div class="topbar-actions"><button class="btn ghost" data-page="dashboard">Dashboard</button></div></div></header>
  <main class="container" style="padding:30px 0 60px;">
    <div class="form-panel" style="max-width: 760px; margin: 0 auto;">
      <div class="section-header"><div><span class="eyebrow">Profile</span><h2 style="margin-top:10px;">Manage your account</h2></div></div>
      <div class="form-grid">
        <div class="field"><label>First name</label><input value="${state.user?.first_name || ''}" /></div>
        <div class="field"><label>Last name</label><input value="${state.user?.last_name || ''}" /></div>
        <div class="field"><label>Username</label><input value="${state.user?.username || ''}" /></div>
        <div class="field"><label>Phone</label><input value="${state.user?.phone || ''}" /></div>
        <div class="field" style="grid-column: 1 / -1;"><label>Bio</label><textarea>${state.user?.bio || ''}</textarea></div>
      </div>
      <div class="inline-actions"><button class="btn primary">Save profile</button><button class="btn ghost">Upload picture</button></div>
    </div>
  </main>
`;

const renderApp = () => {
  if (!state.user && (state.page === 'dashboard' || state.page === 'jobs' || state.page === 'finance' || state.page === 'school' || state.page === 'messages' || state.page === 'profile')) {
    state.page = 'login';
  }

  if (state.page === 'home') appRoot.innerHTML = renderHome();
  else if (state.page === 'register') appRoot.innerHTML = renderRegister();
  else if (state.page === 'login') appRoot.innerHTML = renderLogin();
  else if (state.page === 'dashboard') appRoot.innerHTML = renderDashboard();
  else if (state.page === 'jobs') appRoot.innerHTML = renderJobs();
  else if (state.page === 'finance') appRoot.innerHTML = renderFinance();
  else if (state.page === 'school') appRoot.innerHTML = renderSchool();
  else if (state.page === 'messages') appRoot.innerHTML = renderMessages();
  else if (state.page === 'profile') appRoot.innerHTML = renderProfile();

  bindEvents();
};

const bindEvents = () => {
  document.querySelectorAll('[data-page]').forEach((button) => {
    button.addEventListener('click', () => {
      state.page = button.dataset.page;
      renderApp();
    });
  });

  const registerForm = document.getElementById('register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const formData = Object.fromEntries(new FormData(registerForm).entries());
      try {
        const result = await api('/auth/register', { method: 'POST', body: JSON.stringify(formData) });
        state.user = result.user;
        state.token = result.token;
        localStorage.setItem('nebaflexToken', result.token);
        state.page = 'dashboard';
        renderApp();
      } catch (error) {
        alert(error.message);
      }
    });
  }

  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const payload = Object.fromEntries(new FormData(loginForm).entries());
      try {
        const result = await api('/auth/login', { method: 'POST', body: JSON.stringify(payload) });
        state.user = result.user;
        state.token = result.token;
        localStorage.setItem('nebaflexToken', result.token);
        state.page = 'dashboard';
        renderApp();
      } catch (error) {
        alert(error.message);
      }
    });
  }

  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async () => {
      localStorage.removeItem('nebaflexToken');
      state.token = '';
      state.user = null;
      state.page = 'home';
      renderApp();
    });
  }

  const searchJobsBtn = document.getElementById('search-jobs-btn');
  if (searchJobsBtn) {
    searchJobsBtn.addEventListener('click', async () => {
      const district = document.getElementById('job-district')?.value || '';
      const category = document.getElementById('job-category')?.value || '';
      const employmentType = document.getElementById('job-type')?.value || '';
      const salaryMin = document.getElementById('job-salary')?.value || '';
      const params = new URLSearchParams({ district, category, employmentType, salaryMin });
      try {
        const result = await api(`/jobs?${params.toString()}`);
        state.jobs = result.jobs || [];
        renderApp();
      } catch (error) { alert(error.message); }
    });
  }

  const depositBtn = document.getElementById('deposit-btn');
  if (depositBtn) {
    depositBtn.addEventListener('click', async () => {
      const amount = document.getElementById('finance-amount')?.value;
      if (!amount) return alert('Enter a deposit amount.');
      try {
        await api('/finance/deposit', { method: 'POST', body: JSON.stringify({ amount, provider: document.getElementById('finance-provider')?.value, method: 'wallet' }) });
        alert('Deposit request submitted.');
        renderApp();
      } catch (error) { alert(error.message); }
    });
  }

  const transferBtn = document.getElementById('transfer-btn');
  if (transferBtn) {
    transferBtn.addEventListener('click', async () => {
      const amount = document.getElementById('finance-amount')?.value;
      const recipient = document.getElementById('transfer-recipient')?.value;
      const description = document.getElementById('transfer-purpose')?.value;
      try {
        await api('/finance/transfer', { method: 'POST', body: JSON.stringify({ amount, recipientUsername: recipient, description }) });
        alert('Transfer completed.');
        renderApp();
      } catch (error) { alert(error.message); }
    });
  }

  const startChatBtn = document.getElementById('start-chat-btn');
  if (startChatBtn) {
    startChatBtn.addEventListener('click', async () => {
      const recipient = document.getElementById('chat-recipient')?.value;
      if (!recipient) return alert('Choose a recipient username.');
      try {
        await api('/chat/conversations', { method: 'POST', body: JSON.stringify({ userId: recipient }) });
        alert('Conversation opened successfully.');
        state.page = 'dashboard';
        renderApp();
      } catch (error) { alert(error.message); }
    });
  }

  const searchSchoolBtn = document.getElementById('search-school-btn');
  if (searchSchoolBtn) {
    searchSchoolBtn.addEventListener('click', async () => {
      const institution = document.getElementById('school-institution')?.value || '';
      const subject = document.getElementById('school-subject')?.value || '';
      const district = document.getElementById('school-district')?.value || '';
      const qualification = document.getElementById('school-qualification')?.value || '';
      const params = new URLSearchParams({ institution, subject, district, qualification });
      try {
        const result = await api(`/schools/scholarships?${params.toString()}`);
        state.scholarships = result.scholarships || [];
        renderApp();
      } catch (error) { alert(error.message); }
    });
  }
};

async function initApp() {
  if (state.token) {
    try {
      const profile = await api('/users/me');
      state.user = profile.user;
      const balanceData = await api('/finance/balance');
      state.balance = balanceData.balance || 0;
    } catch (error) {
      state.token = '';
      localStorage.removeItem('nebaflexToken');
      state.user = null;
    }
  }
  renderApp();
}

initApp();
