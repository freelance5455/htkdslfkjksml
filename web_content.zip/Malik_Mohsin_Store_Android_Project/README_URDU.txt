Malik Mohsin Store — Offline Android Project

اہم:
- یہ Android Studio کا source project ہے، ابھی تیار شدہ APK نہیں۔
- اس پروجیکٹ میں آپ کی updated HTML فائل شامل ہے اور ایپ انٹرنیٹ کے بغیر کھلنے کے لیے بنائی گئی ہے۔
- APK بنانے کے لیے کمپیوٹر پر Android Studio اور Android SDK درکار ہیں۔

APK بنانے کا طریقہ:
1. ZIP کو extract کریں۔
2. Android Studio کھولیں اور "Open" سے Malik_Mohsin_Store_Android_Project فولڈر منتخب کریں۔
3. Gradle sync مکمل ہونے دیں اور اگر Android SDK 35 مانگے تو SDK Manager سے install کریں۔
4. Build > Build Bundle(s) / APK(s) > Build APK(s) منتخب کریں۔
5. بننے والی APK عموماً app/build/outputs/apk/debug/app-debug.apk میں ہوگی۔

ڈیٹا کی حفاظت:
- کاروباری ریکارڈ داخل کرنے سے پہلے ایپ کے اندر backup بنائیں اور restore کا طریقہ ٹیسٹ کریں۔
- فون سے ایپ uninstall یا app data clear کرنے پر local data ضائع ہو سکتا ہے۔
- Backup فائل الگ محفوظ جگہ پر رکھیں۔
- یہ project ابھی Android Studio میں build اور فون پر مکمل test نہیں ہوا۔
