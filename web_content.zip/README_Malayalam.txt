GALLOP CHESS — STOCKFISH 19 ONLINE EDITION

ഈ പതിപ്പിൽ Stockfish.js 19.0.1 Lite Single-threaded Engine ഉപയോഗിക്കുന്നു.

പ്രധാന കാര്യങ്ങൾ:
• ആദ്യമായി Engine ലോഡ് ചെയ്യാൻ ഇന്റർനെറ്റ് ആവശ്യമാണ്.
• Engine ഫയലുകൾ jsDelivr CDN-ൽ നിന്ന് ലോഡ് ചെയ്യുന്നു.
• വിശകലനം നിങ്ങളുടെ ബ്രൗസറിനുള്ളിലാണ് നടക്കുന്നത്; ഓരോ നീക്കത്തിനും cloud API-യിലേക്ക് ഗെയിം അയയ്ക്കുന്ന രീതിയല്ല.
• Android Chrome, Windows Chrome/Edge പോലുള്ള പുതിയ ബ്രൗസറുകൾ ലക്ഷ്യമിടുന്നു.
• മികച്ച പിന്തുണയ്ക്കായി HTML ഫയൽ HTTPS വെബ് ഹോസ്റ്റിംഗിൽ തുറക്കുക. ചില Android file preview-കളിൽ Web Worker നിയന്ത്രണങ്ങൾ ഉണ്ടായേക്കാം.
• Stockfish ലോഡ് ആകാത്ത പക്ഷം ആപ്പിലെ Gallop Built-in Engine fallback ഉപയോഗിക്കാം.

ഉപയോഗം:
1. HTML ഫയൽ Chrome/Edge-ൽ തുറക്കുക.
2. ഇന്റർനെറ്റ് ഓൺ ആക്കുക.
3. Engine Settings-ൽ “Stockfish 19 Lite Single-threaded” തിരഞ്ഞെടുക്കുക.
4. ആദ്യ ലോഡിന് കുറച്ച് സമയം അനുവദിക്കുക.
5. Engine ready ആയാൽ കളി/വിശകലനം ആരംഭിക്കുക.

Engine വിവരങ്ങൾ:
Stockfish.js 19.0.1, Lite Single-threaded build.
Source: https://github.com/nmrugg/stockfish.js
Package: https://www.npmjs.com/package/stockfish
License: GPL-3.0 (Stockfish.js engine).

കുറിപ്പ്: ഈ പാക്കേജിൽ HTML ആപ്പാണ് ഉൾപ്പെടുത്തിയിരിക്കുന്നത്. Stockfish engine JS/WASM ഫയലുകൾ പ്രവർത്തിക്കുമ്പോൾ CDN-ൽ നിന്ന് ഡൗൺലോഡ് ചെയ്യും; അതിനാൽ ഇന്റർനെറ്റ്/ CDN ലഭ്യത ആവശ്യമാണ്.
