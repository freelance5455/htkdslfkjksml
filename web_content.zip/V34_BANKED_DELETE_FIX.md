V34 Banked Delete Fix

The Banked Delete button now uses an in-app confirmation modal instead of window.confirm, then calls the Supabase delete_banked_entry RPC. This avoids browser/Android WebView confirmation-dialog issues.

Supabase SQL remains the same: delete-banked-entry.sql from V33.
