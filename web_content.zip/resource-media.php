<?php
declare(strict_types=1);
require_once __DIR__.'/app/resources.php';
try {
 $user=auth_require_user();$type=(string)($_GET['type']??'tutorial-media');$id=(int)($_GET['id']??0);$row=null;$disk='';
 if($type==='tool-logo'){$s=db()->prepare('SELECT logo_path AS disk_path,status FROM tools WHERE id=? LIMIT 1');$s->execute([$id]);$row=$s->fetch();if(!$row||($row['status']!=='published'&&($user['role']??'')!=='admin'))throw new RuntimeException('not found');$disk=(string)$row['disk_path'];}
 elseif($type==='tutorial-thumb'){$s=db()->prepare('SELECT thumbnail_path AS disk_path,status FROM tutorials WHERE id=? LIMIT 1');$s->execute([$id]);$row=$s->fetch();if(!$row||($row['status']!=='published'&&($user['role']??'')!=='admin'))throw new RuntimeException('not found');$disk=(string)$row['disk_path'];}
 else{$s=db()->prepare('SELECT m.disk_path,m.mime_type,t.status FROM tutorial_media m JOIN tutorials t ON t.id=m.tutorial_id WHERE m.id=? LIMIT 1');$s->execute([$id]);$row=$s->fetch();if(!$row||($row['status']!=='published'&&($user['role']??'')!=='admin'))throw new RuntimeException('not found');$disk=(string)$row['disk_path'];}
 if($disk===''||basename($disk)!==$disk)throw new RuntimeException('not found');$path=APP_ROOT.'/storage/resources/'.$disk;if(!is_file($path)||is_link($path))throw new RuntimeException('not found');
 $mime=(string)($row['mime_type']??(new finfo(FILEINFO_MIME_TYPE))->file($path));if(!in_array($mime,['image/jpeg','image/png','image/webp','image/gif'],true))throw new RuntimeException('not found');
 header('Content-Type: '.$mime);header('X-Content-Type-Options: nosniff');header('Cache-Control: private, max-age=3600');header('Content-Length: '.filesize($path));header('Content-Disposition: inline');readfile($path);exit;
} catch(Throwable $e){http_response_code(404);header('Content-Type: text/plain; charset=utf-8');exit('Not found');}
