# محرك البناء المحلي — Termux

## 1) الإعداد
من داخل Termux، انتقل إلى هذا المجلد ثم:
`bash setup.sh`

## 2) الفحص
افتح جلسة جديدة:
`bash doctor.sh`

يجب أن تكون المعمارية `aarch64`، وأن تظهر Java وGradle وأدوات Android SDK.

## 3) بناء مشروع
انسخ مجلد مشروع Android إلى:
`~/AndroidProjects/MyApp`

ثم:
`bash build.sh "$HOME/AndroidProjects/MyApp"`

الناتج يوضع في:
`~/AndroidBuilds/`

## 4) البناء دون إنترنت
لا تفصل الإنترنت إلا بعد:
- تثبيت كل الحزم.
- تنزيل Gradle distribution.
- تنزيل Android Gradle Plugin واعتمادياته.
- تثبيت Android SDK Platform وBuild Tools المطابقة لقيم compileSdk/buildToolsVersion في المشروع.
- نجاح بناء واحد على الأقل.

قد يفشل البناء دون إنترنت إذا تغيرت الاعتماديات أو لم تكن مخزنة محلياً.
