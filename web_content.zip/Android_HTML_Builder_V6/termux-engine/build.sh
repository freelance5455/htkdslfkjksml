#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

if [ "$#" -lt 1 ]; then
  echo 'الاستخدام: bash build.sh "/مسار/مشروع-Android"'
  exit 2
fi

PROJECT="$(realpath "$1")"
if [ ! -f "$PROJECT/settings.gradle" ] && [ ! -f "$PROJECT/settings.gradle.kts" ]; then
  echo "لم يتم العثور على settings.gradle أو settings.gradle.kts داخل:"
  echo "$PROJECT"
  exit 3
fi

if ! command -v java >/dev/null 2>&1 || ! command -v gradle >/dev/null 2>&1; then
  echo "Java أو Gradle غير مثبت. نفّذ setup.sh ثم doctor.sh."
  exit 4
fi

mkdir -p "$HOME/AndroidBuilds"
cd "$PROJECT"

echo "بدء بناء نسخة Debug..."
gradle --no-daemon --stacktrace assembleDebug

APK="$(find "$PROJECT" -type f -path '*/build/outputs/apk/*/*.apk' | head -n 1 || true)"
if [ -z "$APK" ]; then
  echo "انتهى Gradle دون العثور على APK. راجع رسائل البناء أعلاه."
  exit 5
fi

OUT="$HOME/AndroidBuilds/$(basename "$PROJECT")-debug-$(date +%Y%m%d-%H%M%S).apk"
cp "$APK" "$OUT"
echo
echo "تم إنشاء APK:"
echo "$OUT"
