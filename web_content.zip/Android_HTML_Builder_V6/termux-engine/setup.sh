#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

echo "تحديث مستودعات Termux..."
pkg update -y
pkg upgrade -y

echo "تثبيت الأدوات الأساسية..."
pkg install -y openjdk-17 gradle android-sdk aapt2 apksigner zipalign unzip zip coreutils findutils

mkdir -p "$HOME/AndroidProjects" "$HOME/AndroidBuilds"

cat > "$HOME/.bashrc.builder-v4" <<'EOF'
export JAVA_HOME="$PREFIX/lib/jvm/java-17-openjdk"
export ANDROID_HOME="$PREFIX/opt/android-sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$JAVA_HOME/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/build-tools/$(ls "$ANDROID_HOME/build-tools" 2>/dev/null | sort -V | tail -n1):$PREFIX/bin:$PATH"
EOF

if ! grep -q "bashrc.builder-v4" "$HOME/.bashrc" 2>/dev/null; then
  echo '[ -f "$HOME/.bashrc.builder-v4" ] && source "$HOME/.bashrc.builder-v4"' >> "$HOME/.bashrc"
fi

echo
echo "اكتمل تثبيت الحزم الأساسية. افتح جلسة Termux جديدة ثم نفّذ doctor.sh."
echo "ملاحظة: قد تحتاج إلى تثبيت منصة Android SDK المطلوبة للمشروع عبر sdkmanager إذا لم تكن موجودة في مستودع جهازك."
