#!/data/data/com.termux/files/usr/bin/bash
set +e
echo "=== فحص معمارية الجهاز ==="
uname -m
echo
echo "=== Java ==="
java -version
echo
echo "=== Gradle ==="
gradle --version
echo
echo "=== Android SDK ==="
echo "ANDROID_HOME=${ANDROID_HOME:-غير مضبوط}"
[ -n "${ANDROID_HOME:-}" ] && ls "$ANDROID_HOME" 2>/dev/null
echo
echo "=== أدوات البناء ==="
for tool in aapt2 apksigner zipalign; do
  printf "%-12s" "$tool"
  command -v "$tool" || echo "غير موجود"
done
echo
echo "=== منصات SDK المتاحة ==="
if [ -d "${ANDROID_HOME:-/nonexistent}/platforms" ]; then
  ls "$ANDROID_HOME/platforms"
else
  echo "لم يتم العثور على مجلد platforms"
fi
echo
echo "إذا ظهرت أدوات ناقصة، لا تبدأ البناء قبل معالجة النقص."
