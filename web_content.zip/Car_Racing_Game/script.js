const road = document.getElementById('road');
const playerCar = document.getElementById('playerCar');
const scoreEl = document.getElementById('score');
const highScoreEl = document.getElementById('highScore');
const gameOverEl = document.getElementById('gameOver');
const finalScoreEl = document.getElementById('finalScore');
const startBtn = document.getElementById('startBtn');
const restartBtn = document.getElementById('restartBtn');
const playAgainBtn = document.getElementById('playAgainBtn');
const leftBtn = document.getElementById('leftBtn');
const rightBtn = document.getElementById('rightBtn');

let playerX = 125;
let score = 0;
let highScore = Number(localStorage.getItem('carHighScore') || 0);
let gameRunning = false;
let gameInterval = null;
let spawnInterval = null;
let speedInterval = null;
let speed = 5;
const carWidth = 50;
let roadWidth = road.clientWidth;
const keys = Object.create(null);
const enemyIntervals = new Set();

highScoreEl.textContent = highScore;

function updateRoadWidth() {
    roadWidth = road.clientWidth;
    playerX = Math.max(0, Math.min(playerX, roadWidth - carWidth));
    playerCar.style.left = (playerX + carWidth / 2) + 'px';
}
window.addEventListener('resize', updateRoadWidth);

document.addEventListener('keydown', (e) => {
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', ' '].includes(e.key)) {
        e.preventDefault();
    }
    keys[e.key] = true;
});
document.addEventListener('keyup', (e) => { keys[e.key] = false; });
window.addEventListener('blur', () => {
    Object.keys(keys).forEach(key => { keys[key] = false; });
});

function holdButton(button, key) {
    const start = (e) => { e.preventDefault(); keys[key] = true; };
    const stop = () => { keys[key] = false; };
    button.addEventListener('pointerdown', start);
    button.addEventListener('pointerup', stop);
    button.addEventListener('pointercancel', stop);
    button.addEventListener('pointerleave', stop);
    button.addEventListener('contextmenu', e => e.preventDefault());
}
holdButton(leftBtn, 'ArrowLeft');
holdButton(rightBtn, 'ArrowRight');

function movePlayer() {
    const step = 6;
    if (keys.ArrowLeft) playerX -= step;
    if (keys.ArrowRight) playerX += step;
    playerX = Math.max(0, Math.min(playerX, roadWidth - carWidth));
    playerCar.style.left = (playerX + carWidth / 2) + 'px';
}

function clearEnemyIntervals() {
    enemyIntervals.forEach(id => clearInterval(id));
    enemyIntervals.clear();
}

function spawnEnemy() {
    if (!gameRunning) return;
    const enemy = document.createElement('div');
    enemy.className = 'enemy-car';
    enemy.textContent = Math.random() < 0.5 ? '🚙' : '🚕';
    const enemyX = Math.floor(Math.random() * Math.max(1, roadWidth - carWidth));
    enemy.style.left = enemyX + 'px';
    enemy.style.top = '-60px';
    road.appendChild(enemy);

    let enemyY = -60;
    const moveInterval = setInterval(() => {
        if (!gameRunning) {
            clearInterval(moveInterval);
            enemyIntervals.delete(moveInterval);
            enemy.remove();
            return;
        }

        enemyY += speed;
        enemy.style.top = enemyY + 'px';

        const carRect = playerCar.getBoundingClientRect();
        const enemyRect = enemy.getBoundingClientRect();
        if (
            enemyRect.bottom > carRect.top + 10 &&
            enemyRect.top < carRect.bottom - 10 &&
            enemyRect.right > carRect.left + 10 &&
            enemyRect.left < carRect.right - 10
        ) {
            clearInterval(moveInterval);
            enemyIntervals.delete(moveInterval);
            endGame();
            return;
        }

        if (enemyY > road.clientHeight + 10) {
            clearInterval(moveInterval);
            enemyIntervals.delete(moveInterval);
            enemy.remove();
            if (gameRunning) {
                score++;
                scoreEl.textContent = score;
            }
        }
    }, 20);
    enemyIntervals.add(moveInterval);
}

function stopTimers() {
    clearInterval(gameInterval);
    clearInterval(spawnInterval);
    clearInterval(speedInterval);
    gameInterval = spawnInterval = speedInterval = null;
    clearEnemyIntervals();
}

function startGame() {
    if (gameRunning) return;
    stopTimers();
    document.querySelectorAll('.enemy-car').forEach(enemy => enemy.remove());
    updateRoadWidth();
    playerX = Math.max(0, (roadWidth - carWidth) / 2);
    playerCar.style.left = (playerX + carWidth / 2) + 'px';
    score = 0;
    speed = 5;
    scoreEl.textContent = score;
    gameOverEl.style.display = 'none';
    gameRunning = true;
    startBtn.disabled = true;

    gameInterval = setInterval(movePlayer, 16);
    spawnInterval = setInterval(spawnEnemy, 1200);
    speedInterval = setInterval(() => { speed = Math.min(speed + 0.5, 14); }, 5000);
}

function endGame() {
    if (!gameRunning) return;
    gameRunning = false;
    stopTimers();
    startBtn.disabled = false;
    finalScoreEl.textContent = score;
    gameOverEl.style.display = 'block';

    if (score > highScore) {
        highScore = score;
        try { localStorage.setItem('carHighScore', String(highScore)); } catch (_) {}
        highScoreEl.textContent = highScore;
    }
    Object.keys(keys).forEach(key => { keys[key] = false; });
}

startBtn.addEventListener('click', startGame);
restartBtn.addEventListener('click', () => {
    if (gameRunning) {
        gameRunning = false;
        stopTimers();
    }
    startGame();
});
playAgainBtn.addEventListener('click', startGame);

updateRoadWidth();
