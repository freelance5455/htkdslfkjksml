CAR RACING GAME

Files:
- index.html: game structure
- style.css: game design
- script.js: game logic

How to run on Android using Acode:
1. Extract this ZIP file into a folder.
2. Open Acode and open the extracted folder.
3. Open index.html.
4. Tap Preview (or open index.html in your browser).
5. Tap Start. Use the left/right arrow buttons on mobile.

On a computer, open index.html in a modern browser and use the left/right arrow keys.
The high score is saved in the browser's local storage.
