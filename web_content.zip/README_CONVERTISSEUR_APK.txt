=== INSTRUCTIONS CONVERTISSEUR HTML VERS APK ANDROID ===
Projet : NOVA Ultimate AI Studio (com.nova.ai.studio)

1. Ce fichier ZIP contient 'index.html' directement positionné à la racine (Mandatoire).
2. Transférez directement ce fichier ZIP dans votre outil de conversion (ex: Website2APK, Web2App, Website 2 APK Builder ou Ionic/Capacitor).
3. L'icône futuriste générée est stockée dans 'icon.png'.
4. AndroidManifest.xml est prêt pour la compilation Android Native.

Généré avec succès par NOVA ULTIMATE AI STUDIO.