# JARVIS Android app — version 45.2

This Kotlin Android WebView shell loads the shared JARVIS frontend from `app/src/main/assets/` and exposes the existing native Android handoffs: speech recognition/text-to-speech, dialer, SMS draft, app launch, volume, settings panels, alarm/timer drafts, maps, email draft, battery status, web search and HTTPS website opening.

Version 45.2 also supports the frontend's image picker through Android WebView's system file chooser. Select an image or choose a camera option if your Android picker provides one. Image analysis requires a configured backend and a vision-capable AI model.

Android package version: `versionName 45.2`, `versionCode 452`.

## Build

Open this folder in Android Studio, sync Gradle, then build an APK. Configure the backend URL and access token in the app's Settings. No APK is included in the source archive.

## Limitations

The optional “Hey JARVIS” feature is a foreground browser SpeechRecognition experiment and is not a native background wake-word service. Device actions are user-confirmed handoffs. JARVIS does not silently send messages, place calls, alter secure settings, or control arbitrary apps.
