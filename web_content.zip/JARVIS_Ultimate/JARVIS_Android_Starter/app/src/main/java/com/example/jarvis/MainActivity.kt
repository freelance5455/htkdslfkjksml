package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.BatteryManager
import android.content.IntentFilter
import android.media.AudioManager
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.webkit.WebChromeClient.FileChooserParams
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private lateinit var tts: TextToSpeech
    private val requestAudio = 41
    private val requestSpeech = 42
    private val requestFile = 43
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
                    startActivityForResult(intent, requestFile)
                    true
                } catch (_: Exception) {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = null
                    false
                }
            }
        }
        web.addJavascriptInterface(Bridge(), "JarvisNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale.getDefault()
    }

    inner class Bridge {
        @JavascriptInterface fun speak(text: String) {
            runOnUiThread { tts.speak(text.take(1500), TextToSpeech.QUEUE_FLUSH, null, "jarvis") }
        }
        @JavascriptInterface fun listen() {
            runOnUiThread {
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
                } else startSpeech()
            }
        }
        @JavascriptInterface fun openDialer(number: String) {
            val clean = number.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }
            if (clean.isBlank()) return
            runOnUiThread { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(clean)))) }
        }
        @JavascriptInterface fun composeSms(number: String, body: String) {
            val clean = number.filter { it.isDigit() || it == '+' }
            if (clean.isBlank()) return
            runOnUiThread {
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(clean)))
                intent.putExtra("sms_body", body.take(2000))
                startActivity(intent)
            }
        }
        @JavascriptInterface fun launchApp(packageName: String): Boolean {
            if (!packageName.matches(Regex("[A-Za-z0-9_.]{3,180}"))) return false
            return try {
                val intent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
                runOnUiThread { startActivity(intent) }
                true
            } catch (_: Exception) { false }
        }
        @JavascriptInterface fun adjustVolume(action: String) {
            runOnUiThread {
                val audio = getSystemService(AUDIO_SERVICE) as AudioManager
                when (action.lowercase()) {
                    "up" -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    "down" -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    "mute" -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                    "unmute" -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                }
            }
        }
        @JavascriptInterface fun openSystemPanel(panel: String) {
            val action = when (panel.lowercase()) {
                "wifi" -> if (android.os.Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> if (android.os.Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_BLUETOOTH else Settings.ACTION_BLUETOOTH_SETTINGS
                "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            runOnUiThread { try { startActivity(Intent(action)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
        }
        @JavascriptInterface fun setAlarm(hour: Int, minute: Int) {
            if (hour !in 0..23 || minute !in 0..59) return
            val intent = Intent(android.provider.AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(android.provider.AlarmClock.EXTRA_HOUR, hour)
                putExtra(android.provider.AlarmClock.EXTRA_MINUTES, minute)
                putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false)
            }
            runOnUiThread { try { startActivity(intent) } catch (_: Exception) {} }
        }
        @JavascriptInterface fun setTimer(seconds: Int) {
            if (seconds !in 1..86400) return
            val intent = Intent(android.provider.AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(android.provider.AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false)
            }
            runOnUiThread { try { startActivity(intent) } catch (_: Exception) {} }
        }
        @JavascriptInterface fun navigateTo(destination: String) {
            val uri = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(destination.take(300)))
            runOnUiThread { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        }
        @JavascriptInterface fun composeEmail(address: String, subject: String, body: String) {
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(address).matches()) return
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(address))).apply {
                putExtra(Intent.EXTRA_SUBJECT, subject.take(200))
                putExtra(Intent.EXTRA_TEXT, body.take(5000))
            }
            runOnUiThread { try { startActivity(intent) } catch (_: Exception) {} }
        }
        @JavascriptInterface fun batteryStatus(): String {
            val manager = getSystemService(BATTERY_SERVICE) as BatteryManager
            val level = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            val chargeText = if (charging) ", charging" else ""
            return if (level in 0..100) "$level percent$chargeText" else "unavailable"
        }
        @JavascriptInterface fun searchWeb(query: String) {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)))
            runOnUiThread { startActivity(intent) }
        }
        @JavascriptInterface fun openWebsite(url: String) {
            val safe = if (url.startsWith("https://")) url else "https://www.google.com"
            runOnUiThread { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(safe))) }
        }
        @JavascriptInterface fun saveData(key: String, value: String) {
            getSharedPreferences("jarvis_data", MODE_PRIVATE).edit().putString(key.take(80), value.take(10000)).apply()
        }
        @JavascriptInterface fun loadData(key: String): String {
            return getSharedPreferences("jarvis_data", MODE_PRIVATE).getString(key.take(80), "") ?: ""
        }
    }

    private fun startSpeech() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        try { startActivityForResult(intent, requestSpeech) } catch (_: Exception) {
            web.evaluateJavascript("showReply('Speech recognition is not available on this device.')", null)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestAudio && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startSpeech()
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestFile) {
            val result = if (resultCode == RESULT_OK) FileChooserParams.parseResult(resultCode, data) else null
            fileCallback?.onReceiveValue(result)
            fileCallback = null
            return
        }
        if (requestCode == requestSpeech && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            val escaped = org.json.JSONObject.quote(spoken)
            web.evaluateJavascript("handleVoiceResult($escaped)", null)
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
