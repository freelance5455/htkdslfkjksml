"""JARVIS 45.2 backend. External actions are proposed, never silently executed."""
import os, sqlite3, secrets, re
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from openai import OpenAI

BASE_DIR=Path(__file__).resolve().parent.parent
DB_PATH=os.getenv("JARVIS_DB_PATH",str(Path(__file__).resolve().parent/"jarvis.db"))
ACCESS_TOKEN=os.getenv("JARVIS_ACCESS_TOKEN","")
MODEL=os.getenv("OPENAI_MODEL","gpt-4.1-mini")
app=FastAPI(title="JARVIS AI Backend",version="45.2.0",description="Multi-platform personal AI assistant backend")
app.add_middleware(CORSMiddleware,allow_origins=os.getenv("CORS_ORIGINS","*").split(","),allow_credentials=False,allow_methods=["GET","POST","PATCH","DELETE"],allow_headers=["Authorization","Content-Type"])

def db():
    con=sqlite3.connect(DB_PATH);con.row_factory=sqlite3.Row;return con

def init_db():
    with db() as con:
        con.execute("CREATE TABLE IF NOT EXISTS memories(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,note TEXT NOT NULL,created_at TEXT NOT NULL)")
        con.execute("CREATE TABLE IF NOT EXISTS conversations(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,role TEXT NOT NULL,content TEXT NOT NULL,created_at TEXT NOT NULL)")
        con.execute("CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,title TEXT NOT NULL,done INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL)")
        con.execute("CREATE INDEX IF NOT EXISTS idx_memory_user ON memories(user_id,id)")
        con.execute("CREATE INDEX IF NOT EXISTS idx_tasks_user ON tasks(user_id,id)")
        con.execute("CREATE INDEX IF NOT EXISTS idx_conversations_user ON conversations(user_id,id)")
init_db()

def authorize(auth: Optional[str]):
    if not ACCESS_TOKEN: raise HTTPException(503,"Server administrator must configure JARVIS_ACCESS_TOKEN.")
    supplied=auth[7:] if auth and auth.startswith("Bearer ") else ""
    if not supplied or not secrets.compare_digest(supplied,ACCESS_TOKEN): raise HTTPException(401,"Invalid access token.")

def client():
    if not os.getenv("OPENAI_API_KEY"): raise HTTPException(503,"AI provider key is not configured on the server.")
    return OpenAI(api_key=os.environ["OPENAI_API_KEY"])

def assistant_instructions(user_id: str):
    with db() as con:
        rows=con.execute("SELECT note FROM memories WHERE user_id=? ORDER BY id DESC LIMIT 30",(user_id,)).fetchall()
    memory_text=" User-approved saved notes: "+"; ".join(r["note"] for r in rows) if rows else ""
    return ("You are JARVIS 45.2, a capable, calm, respectful multi-platform personal AI assistant. "
      "Help with reasoning, planning, research, coding, explanations and organizing work. Be clear about uncertainty. "
      "Never claim to control a device, send a message, make a call, or complete an external action unless a connected tool confirms it. "
      "Ask for confirmation before consequential actions. Treat device actions as proposals requiring user approval. "
      "Protect secrets and personal data. Do not claim persistent memory unless a note was explicitly saved."+memory_text)

class ChatRequest(BaseModel):
    message: str=Field(min_length=1,max_length=12000)
    history: list[dict]=Field(default_factory=list)
    preferred_name: str=Field(default="",max_length=48)
    user_id: str=Field(default="default",min_length=1,max_length=100)
class MemoryRequest(BaseModel):
    note: str=Field(min_length=1,max_length=4000); user_id: str=Field(default="default",min_length=1,max_length=100)
class TaskRequest(BaseModel):
    title: str=Field(min_length=1,max_length=240); done: bool=False; user_id: str=Field(default="default",min_length=1,max_length=100)
class VisionRequest(BaseModel):
    prompt: str=Field(default="Describe what you see.",min_length=1,max_length=3000)
    image_data_url: str=Field(min_length=30,max_length=8_000_000)
    user_id: str=Field(default="default",min_length=1,max_length=100)
class PlanRequest(BaseModel):
    goal: str=Field(min_length=1,max_length=5000); user_id: str=Field(default="default",min_length=1,max_length=100)

@app.get("/api/health")
def health(authorization: Optional[str]=Header(default=None)):
    authorize(authorization)
    return {"status":"online","version":"45.2.0","ai_configured":bool(os.getenv("OPENAI_API_KEY")),"model":MODEL,
      "capabilities":{"chat":True,"web_search":True,"vision":True,"planning":True,"tasks":True,"memory":True,"conversation_archive":True,"android_bridge":True,"pwa":True}}

@app.post("/api/chat")
def chat(req: ChatRequest, authorization: Optional[str]=Header(default=None)):
    authorize(authorization)
    try:
        history=[]
        for item in req.history[-16:]:
            role=item.get("role"); content=item.get("content")
            if role in ("user","assistant") and isinstance(content,str): history.append({"role":role,"content":content[:12000]})
        instructions=assistant_instructions(req.user_id)
        if req.preferred_name: instructions+=f" The user's preferred name is {req.preferred_name}."
        response=client().responses.create(model=MODEL,instructions=instructions,input=history+[{"role":"user","content":req.message}],tools=[{"type":"web_search"}])
        answer=response.output_text or "I could not produce a text response."
        with db() as con:
            now=datetime.now(timezone.utc).isoformat()
            con.execute("INSERT INTO conversations(user_id,role,content,created_at) VALUES(?,?,?,?)",(req.user_id,"user",req.message,now))
            con.execute("INSERT INTO conversations(user_id,role,content,created_at) VALUES(?,?,?,?)",(req.user_id,"assistant",answer,now))
        return {"answer":answer,"model":MODEL}
    except HTTPException: raise
    except Exception as exc: raise HTTPException(502,"AI request failed. Check model access, provider billing and server logs.") from exc

@app.post("/api/vision")
def vision(req: VisionRequest, authorization: Optional[str]=Header(default=None)):
    authorize(authorization)
    match=re.fullmatch(r"data:(image/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)",req.image_data_url)
    if not match: raise HTTPException(400,"Use a JPEG, PNG or WebP image data URL.")
    try:
        response=client().responses.create(model=MODEL,instructions=assistant_instructions(req.user_id)+" Analyze the supplied image carefully. Do not identify private people. State uncertainty when details are unclear.",input=[{"role":"user","content":[{"type":"input_text","text":req.prompt},{"type":"input_image","image_url":req.image_data_url}]}])
        return {"answer":response.output_text or "I could not analyze that image.","model":MODEL}
    except HTTPException: raise
    except Exception as exc: raise HTTPException(502,"Image analysis failed. Check whether the configured model supports image input.") from exc

@app.post("/api/agent/plan")
def agent_plan(req: PlanRequest, authorization: Optional[str]=Header(default=None)):
    authorize(authorization)
    try:
        response=client().responses.create(model=MODEL,instructions=assistant_instructions(req.user_id)+" Create a practical plan. Separate safe informational steps from external actions. Do not execute anything. Finish with a short list of actions that require the user's explicit approval.",input="Create an actionable plan for this goal: "+req.goal,tools=[{"type":"web_search"}])
        return {"plan":response.output_text or "No plan was generated.","execution":"not_performed","approval_required":True}
    except HTTPException: raise
    except Exception as exc: raise HTTPException(502,"Planning failed. Check model access and server logs.") from exc

@app.get("/api/conversations")
def list_conversations(user_id: str="default",limit: int=100,authorization: Optional[str]=Header(default=None)):
    authorize(authorization); limit=max(1,min(limit,300))
    with db() as con:
        rows=con.execute("SELECT id,role,content,created_at FROM conversations WHERE user_id=? ORDER BY id DESC LIMIT ?",(user_id,limit)).fetchall()
    return {"conversations":[dict(r) for r in reversed(rows)]}
@app.delete("/api/conversations")
def clear_conversations(user_id: str="default",authorization: Optional[str]=Header(default=None)):
    authorize(authorization)
    with db() as con: con.execute("DELETE FROM conversations WHERE user_id=?",(user_id,))
    return {"deleted":True}

@app.get("/api/tasks")
def list_tasks(user_id: str="default",authorization: Optional[str]=Header(default=None)):
    authorize(authorization)
    with db() as con: rows=con.execute("SELECT id,title,done,created_at FROM tasks WHERE user_id=? ORDER BY done ASC,id DESC LIMIT 200",(user_id,)).fetchall()
    return {"tasks":[dict(r) for r in rows]}
@app.post("/api/tasks")
def add_task(req: TaskRequest,authorization: Optional[str]=Header(default=None)):
    authorize(authorization)
    with db() as con: cur=con.execute("INSERT INTO tasks(user_id,title,done,created_at) VALUES(?,?,?,?)",(req.user_id,req.title.strip(),int(req.done),datetime.now(timezone.utc).isoformat()))
    return {"id":cur.lastrowid,"saved":True}
@app.patch("/api/tasks/{task_id}")
def update_task(task_id: int,req: TaskRequest,authorization: Optional[str]=Header(default=None)):
    authorize(authorization)
    with db() as con: cur=con.execute("UPDATE tasks SET title=?,done=? WHERE id=? AND user_id=?",(req.title.strip(),int(req.done),task_id,req.user_id))
    if not cur.rowcount: raise HTTPException(404,"Task not found.")
    return {"updated":True}
@app.delete("/api/tasks/{task_id}")
def delete_task(task_id: int,user_id: str="default",authorization: Optional[str]=Header(default=None)):
    authorize(authorization)
    with db() as con: cur=con.execute("DELETE FROM tasks WHERE id=? AND user_id=?",(task_id,user_id))
    if not cur.rowcount: raise HTTPException(404,"Task not found.")
    return {"deleted":True}
@app.get("/api/memory")
def list_memory(user_id: str="default",authorization: Optional[str]=Header(default=None)):
    authorize(authorization)
    with db() as con: rows=con.execute("SELECT id,note,created_at FROM memories WHERE user_id=? ORDER BY id DESC LIMIT 100",(user_id,)).fetchall()
    return {"memories":[dict(r) for r in rows]}
@app.post("/api/memory")
def add_memory(req: MemoryRequest,authorization: Optional[str]=Header(default=None)):
    authorize(authorization)
    with db() as con: cur=con.execute("INSERT INTO memories(user_id,note,created_at) VALUES(?,?,?)",(req.user_id,req.note,datetime.now(timezone.utc).isoformat()))
    return {"id":cur.lastrowid,"saved":True}
@app.delete("/api/memory/{memory_id}")
def delete_memory(memory_id: int,user_id: str="default",authorization: Optional[str]=Header(default=None)):
    authorize(authorization)
    with db() as con: cur=con.execute("DELETE FROM memories WHERE id=? AND user_id=?",(memory_id,user_id))
    if not cur.rowcount: raise HTTPException(404,"Memory not found.")
    return {"deleted":True}

desktop=BASE_DIR/"desktop"
if desktop.exists(): app.mount("/",StaticFiles(directory=str(desktop),html=True),name="desktop")
