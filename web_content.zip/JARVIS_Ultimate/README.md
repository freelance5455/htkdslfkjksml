# J.A.R.V.I.S. Ultimate — version 45.2

This release fixes the Android Gradle dependency-block placement, updates the Android package to versionCode 452 / versionName 45.2, synchronizes version branding, restores the Android WebView manifest asset, and uses `gpt-4.1-mini` as the default backend model (override with `OPENAI_MODEL`).

JARVIS 45.2 is an upgrade of the supplied 30.0 project. It retains the existing Android WebView app, desktop/PWA interface, FastAPI backend, SQLite tasks and notes, AI chat, web search, voice input/output, and Android system handoffs. It adds image understanding, an AI mission planner, a conversation archive API, a capability-aware health endpoint, and an optional foreground browser wake phrase.

This is a development project, not an unrestricted autonomous device-control system. External actions remain user-reviewed.

## What's new in 45.2

- **Image understanding:** choose or capture a JPEG, PNG or WebP image in the desktop/browser interface or Android app, ask a question, and send it to `/api/vision`. The configured model must support image input. Images are sent to the AI provider for analysis and are not stored by this application.
- **AI mission planner:** enter a goal and JARVIS returns an actionable plan through `/api/agent/plan`. Planning does not execute external actions; the user reviews and performs/approves them.
- **Optional “Hey JARVIS” foreground wake phrase:** the desktop/browser interface has an explicit start/stop control. It uses the browser's continuous SpeechRecognition implementation while the page is open and active. Browser support, microphone permission and internet/browser speech service may be required. This is not a background service and is not guaranteed to work in Android WebView.
- **Conversation archive API:** list and clear server-side conversation records using `/api/conversations`.
- **Capability-aware health endpoint:** `/api/health` reports version and enabled feature flags.
- **Android image picker handoff:** Android WebView file selection is bridged to the system picker/camera-capable chooser.
- **Versioned Android build:** app version is now 45.2 / versionCode 30.

## Retained from 20.0

- AI chat using the OpenAI Responses API and web search tool.
- Local command handling for date/time, battery status, media volume, settings panels, alarms/timers, navigation, email drafts, dialer/SMS drafts and launching supported apps.
- Speech recognition and text-to-speech.
- SQLite-backed tasks and saved notes/memory.
- Desktop/PWA interface and Android Kotlin/WebView application.
- Existing API routes for chat, tasks, memory and health.

## Requirements

- Python 3.11+
- An OpenAI API key and an API model enabled for your project. Set `OPENAI_MODEL` to a model that supports the Responses API, web search, and image input if you want every AI feature.
- Android Studio with a compatible Android SDK and Gradle plugin for APK builds.
- HTTPS for any deployment accessed over a network. Android's cleartext traffic remains disabled by default.

## Backend setup

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Set these values in `backend/.env` (or the server environment):

```dotenv
OPENAI_API_KEY=your-provider-key
OPENAI_MODEL=gpt-4.1-mini (or another model enabled for your API project)
JARVIS_ACCESS_TOKEN=replace-with-a-long-random-secret
CORS_ORIGINS=https://your-jarvis-domain.example
```

Never put the provider API key in the Android app or browser. Generate a strong access token, restrict CORS to the actual frontend origins, use HTTPS, and place the service behind a firewall/reverse proxy. Then run:

```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

The backend serves the desktop app from the same origin. Open the server URL, open Settings, and enter the server URL and access token.

## Android build

1. Open `JARVIS_Android_Starter/` in Android Studio.
2. Sync Gradle and allow the Android Gradle Plugin to download dependencies.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated debug APK on a test device.
5. In JARVIS Settings, configure the backend URL and access token.

No prebuilt APK is included. Android native shortcuts use intents and hand off to Android apps/settings. The image upload control uses the Android system file chooser; choose the camera option if the device's chooser offers it.

## Desktop / web

The `desktop/` folder is a Progressive Web App frontend served by FastAPI. It can also be hosted as static files on an HTTPS web host, provided its server URL, CORS policy and authentication are configured correctly. Browser voice recognition and wake phrase support varies by browser.

## API endpoints

- `GET /api/health` — authenticated service status, version and capabilities
- `POST /api/chat` — AI conversation with optional recent history
- `POST /api/vision` — image question/description; JSON fields: `prompt`, `image_data_url`, `user_id`
- `POST /api/agent/plan` — generate a plan without executing actions; JSON fields: `goal`, `user_id`
- `GET /api/conversations?user_id=default&limit=100` — retrieve conversation archive
- `DELETE /api/conversations?user_id=default` — clear conversation archive
- `GET|POST /api/memory`, `DELETE /api/memory/{memory_id}`
- `GET|POST /api/tasks`, `PATCH|DELETE /api/tasks/{task_id}`

All API routes require `Authorization: Bearer <JARVIS_ACCESS_TOKEN>`.

## Safety, privacy and limitations

- **Wake phrase is not always-on:** it is an optional foreground browser feature, requires explicit activation, and stops when unsupported or when the page/browser ends. It is not a native background wake-word service.
- **No arbitrary remote computer control:** JARVIS does not silently operate your desktop mouse/keyboard or run arbitrary shell commands.
- **No silent communications:** calls, SMS, email and WhatsApp handoffs require the user to review and confirm in the relevant app. No automatic WhatsApp sending or notification/message scraping is included.
- **No silent system-setting changes:** Android settings panels are opened for the user to make changes.
- **Image handling:** images are processed by the configured AI provider; use only images you have permission to share. The app does not save image uploads in its SQLite database.
- **Shared-token starter security:** `user_id` is a data partition label, not a login system. Anyone with the shared access token can call the API and may choose another user ID. Do not expose this starter publicly or use it for sensitive multi-user data without implementing real user authentication, authorization, rate limiting, token rotation, audit logs, encrypted backups and database access controls.
- **Browser storage:** the configured access token and local chat history are stored in browser localStorage. Use a trusted device/profile and sign out/clear browser data on shared devices.
- **Model capability:** image analysis requires a vision-capable model; web search availability depends on the model/API project. Check server logs and provider access if a capability fails.
- **Not a finished autonomous agent:** the mission planner proposes steps only. It does not execute workflows or bypass confirmations.

## Validation

The packaged source has been checked for Python syntax (`py_compile`) and JavaScript syntax (`node --check`). A full Android APK build still requires Android Studio/Gradle and an installed Android SDK; this environment did not include the Gradle command or Android SDK, so no APK is claimed as built or tested here.
