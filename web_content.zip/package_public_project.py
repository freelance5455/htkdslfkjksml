import os
import shutil
import subprocess
import zipfile

ROOT_DIR = "/app/applet"
TEMP_DIR = "/tmp/public-project"
PUBLIC_DIR = os.path.join(ROOT_DIR, "public")
ZIP_NAME = "public-project.zip"
ZIP_PATH = os.path.join(PUBLIC_DIR, ZIP_NAME)

print("1. Cleaning temp directory...")
if os.path.exists(TEMP_DIR):
    shutil.rmtree(TEMP_DIR)
os.makedirs(TEMP_DIR, exist_ok=True)

# 2. Copy root configuration files
ROOT_FILES = [
    "index.html",
    "package.json",
    "vite.config.ts",
    "tsconfig.json",
    "firebase.json",
    ".firebaserc",
    "firebase-applet-config.json",
    "firestore.rules",
    "firebase-blueprint.json",
    ".gitignore",
    ".env.example",
    "README.md",
]

for rf in ROOT_FILES:
    src_f = os.path.join(ROOT_DIR, rf)
    if os.path.exists(src_f):
        shutil.copy2(src_f, os.path.join(TEMP_DIR, rf))

# 3. Copy public assets (excluding zip files)
os.makedirs(os.path.join(TEMP_DIR, "public"), exist_ok=True)
for item in os.listdir(PUBLIC_DIR):
    if item.endswith(".zip"):
        continue
    src_item = os.path.join(PUBLIC_DIR, item)
    dest_item = os.path.join(TEMP_DIR, "public", item)
    if os.path.isdir(src_item):
        shutil.copytree(src_item, dest_item)
    else:
        shutil.copy2(src_item, dest_item)

# 4. Copy required src files (STRICTLY PUBLIC ONLY - NO ADMIN FILES)
SRC_DEST = os.path.join(TEMP_DIR, "src")
os.makedirs(SRC_DEST, exist_ok=True)

PUBLIC_SRC_FILES = [
    "main.tsx",
    "index.css",
    "types.ts",
    "data/initialData.ts",
    "context/AppContext.tsx",
    "context/AuthContext.tsx",
    "utils/firebase.ts",
    "utils/firestoreService.ts",
    "utils/storage.ts",
    "utils/deliveryLocationService.ts",
    "layouts/PublicLayout.tsx",
    "components/navigation/PublicNavbar.tsx",
    "pages/public/PublicHome.tsx",
    "pages/public/MerchantDashboardPage.tsx",
    "pages/public/StorefrontPage.tsx",
    "components/modals/CreateStoreWizardModal.tsx",
    "components/modals/AuthModal.tsx",
    "components/billing/PlanCheckoutModal.tsx",
    "components/support/LiveSupportChat.tsx",
    "components/storefront/LiveStorefront.tsx",
    "components/dashboard/MerchantDashboard.tsx",
    "components/dashboard/MerchantSidebar.tsx",
    "components/dashboard/MerchantTopNav.tsx",
    "components/dashboard/OrdersManager.tsx",
    "components/dashboard/DashboardOverview.tsx",
    "components/dashboard/CustomersManager.tsx",
    "components/dashboard/ProductsManager.tsx",
    "components/dashboard/products/ProductAnalyticsSummary.tsx",
    "components/dashboard/products/ProductImportModal.tsx",
    "components/dashboard/products/ProductEmailCampaignModal.tsx",
    "components/dashboard/products/SupplierIntegrationModal.tsx",
    "components/dashboard/products/ProductEditModal.tsx",
    "components/dashboard/DiscountsManager.tsx",
    "components/dashboard/ContentManager.tsx",
    "components/dashboard/MarketsManager.tsx",
    "components/dashboard/AnalyticsView.tsx",
    "components/dashboard/StoreSettingsView.tsx",
    "components/dashboard/SubscriptionBilling.tsx",
    "components/dashboard/StoreCustomizer.tsx",
    "components/dashboard/AICopilot.tsx",
    "components/dashboard/orders/OrderDetailsDrawer.tsx",
    "components/dashboard/orders/CreateOrderModal.tsx",
    "components/dashboard/orders/PrintInvoiceModal.tsx",
    "components/dashboard/orders/DraftOrdersManager.tsx",
    "components/dashboard/orders/AbandonedCheckoutsManager.tsx",
    "components/dashboard/orders/ReturnsRefundsManager.tsx",
    "components/dashboard/orders/ShippingDeliverySettings.tsx",
    "components/dashboard/collections/CollectionsManager.tsx",
    "components/dashboard/collections/CollectionEditModal.tsx",
    "components/dashboard/collections/DeleteCollectionConfirmModal.tsx",
    "components/dashboard/inventory/InventoryManager.tsx",
    "components/dashboard/inventory/BulkInventoryUpdateModal.tsx",
    "components/dashboard/inventory/InventoryImportModal.tsx",
    "components/common/ErrorBoundary.tsx",
]

for pf in PUBLIC_SRC_FILES:
    s = os.path.join(ROOT_DIR, "src", pf)
    d = os.path.join(SRC_DEST, pf)
    os.makedirs(os.path.dirname(d), exist_ok=True)
    shutil.copy2(s, d)

# 5. Create Standalone App.tsx (Pure Public Routing - No Admin Routes or Imports)
STANDALONE_APP_CONTENT = """/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { PublicLayout } from './layouts/PublicLayout';
import { PublicHome } from './pages/public/PublicHome';
import { MerchantDashboardPage } from './pages/public/MerchantDashboardPage';
import { StorefrontPage } from './pages/public/StorefrontPage';

/**
 * Standalone Public Application
 * Routes:
 *  - "/"           -> Public Landing Page (Zero Admin UI)
 *  - "/dashboard"  -> Merchant Dashboard Console
 *  - "/storefront" -> Public Customer Storefront
 */
export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <Routes>
          <Route path="/" element={<PublicLayout />}>
            <Route index element={<PublicHome />} />
            <Route path="dashboard" element={<MerchantDashboardPage />} />
            <Route path="storefront" element={<StorefrontPage />} />
          </Route>
          {/* Catch-all fallback redirects to public home */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AppProvider>
    </BrowserRouter>
  );
}
"""

with open(os.path.join(SRC_DEST, "App.tsx"), "w", encoding="utf-8") as f:
    f.write(STANDALONE_APP_CONTENT)

# 6. Verify with Symlinked node_modules
print("2. Symlinking node_modules for test build...")
os.symlink(os.path.join(ROOT_DIR, "node_modules"), os.path.join(TEMP_DIR, "node_modules"))

print("3. Testing TypeScript compilation (tsc --noEmit)...")
subprocess.run(["npx", "tsc", "--noEmit"], cwd=TEMP_DIR, check=True)
print("TypeScript test passed!")

print("4. Testing Vite build (vite build)...")
subprocess.run(["npx", "vite", "build"], cwd=TEMP_DIR, check=True)
print("Vite build passed!")

# Remove symlink before zip packaging
os.unlink(os.path.join(TEMP_DIR, "node_modules"))

# 7. Package standalone project into public-project.zip
print(f"5. Packaging into {ZIP_PATH}...")
if os.path.exists(ZIP_PATH):
    os.remove(ZIP_PATH)

with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(TEMP_DIR):
        # Ignore any hidden git/node_modules
        dirs[:] = [d for d in dirs if d not in [".git", "node_modules", ".idea", ".vscode", "__pycache__"]]
        for file in files:
            abs_path = os.path.join(root, file)
            rel_path = os.path.relpath(abs_path, TEMP_DIR)
            zipf.write(abs_path, arcname=os.path.join("public-project", rel_path))

# Also copy into dist/public-project.zip so it can be downloaded via Vite dev/preview server
DIST_DIR = os.path.join(ROOT_DIR, "dist")
if os.path.exists(DIST_DIR):
    shutil.copy2(ZIP_PATH, os.path.join(DIST_DIR, ZIP_NAME))

print(f"DONE! ZIP created at: {ZIP_PATH} (Size: {os.path.getsize(ZIP_PATH)} bytes)")
