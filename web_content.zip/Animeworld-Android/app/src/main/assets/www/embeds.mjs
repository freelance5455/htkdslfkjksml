// Genera episodios/<id>.js con el iframe de cada capítulo (AniSrc) para los animes de data.js
// Uso (en la carpeta de la página, donde está data.js):
//   node embeds.mjs            -> crea el archivo de los animes que todavía no tienen uno
//   node embeds.mjs --forzar   -> también reemplaza los que ya existen (guarda copia en episodios/_respaldo/)
//   node embeds.mjs --anime code-geass   -> solo ese anime
//
// Qué hace:
//  1. Lee tus animes de data.js
//  2. Busca cada uno en AniList (por título y año) y saca el ID y la cantidad de episodios
//  3. Escribe episodios/<id>.js con un iframe por episodio (tu página ya lo muestra con iframe: true)
//  4. Guarda embeds-log.txt con qué anime de AniList eligió para cada uno (revísalo por si se equivocó de temporada)
import { readFile, writeFile, mkdir, access, copyFile } from "node:fs/promises";
import vm from "node:vm";

// ====== AJUSTA ESTO ======
const BASE = "https://anisrc.ru/embed/anime";   // proveedor: AniSrc (si cambias de proveedor, cambia esto y la línea de armarUrl)
const IDIOMA = "sub";                           // "sub" o "dub"
const TEMA = "mono";                            // color del reproductor: mono (gris/negro), sakura, ocean, emerald, sunset, crimson, gold, mint, royal, neon
const AUTONEXT = 1;                             // 1 = pasa solo al siguiente capítulo al terminar
const SALTAR = 12;                              // segundos que se omiten al inicio de cada capítulo (0 = no omitir)
// =========================

const FORZAR = process.argv.includes("--forzar");
const SOLO = process.argv.includes("--anime") ? process.argv[process.argv.indexOf("--anime") + 1] : null;

const dormir = ms => new Promise(r => setTimeout(r, ms));
const existe = p => access(p).then(() => true, () => false);
// AniSrc: /embed/anime/{anilist}/{ep}  (sub)   o   /embed/anime/{anilist}/{ep}-dub  (doblado)
const armarUrl = (anilistId, n) =>
  `${BASE}/${anilistId}/${n}${IDIOMA === "dub" ? "-dub" : ""}?autoplay=0&autonext=${AUTONEXT}&theme=${TEMA}${SALTAR > 0 ? `&startAt=${SALTAR}` : ""}`;

const animes = vm.runInNewContext((await readFile("data.js", "utf8")) + "\n;ANIMES");

// Caché para no volver a preguntarle a AniList si cortas y repites
let cache = {};
if (await existe("anilist-cache.json")) cache = JSON.parse(await readFile("anilist-cache.json", "utf8"));

const consulta = `query($s:String){Page(perPage:6){media(search:$s,type:ANIME,sort:SEARCH_MATCH){
  id title{romaji english} seasonYear startDate{year} format episodes nextAiringEpisode{episode}}}}`;

async function buscar(s) {
  for (let i = 0; i < 4; i++) {
    const r = await fetch("https://graphql.anilist.co", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ query: consulta, variables: { s } })
    }).catch(e => { console.log("No pude conectar con AniList: " + (e.cause?.code ?? e.message)); return null; });
    if (!r) return [];
    if (r.status === 429) { await dormir((Number(r.headers.get("retry-after")) || 30) * 1000); continue; }
    if (!r.ok) { console.log(`AniList respondió con error ${r.status}`); return []; }
    return (await r.json()).data.Page.media;
  }
  return [];
}

const anioDe = m => m.seasonYear ?? m.startDate?.year ?? null;
function elegir(lista, anio) {
  if (!lista.length) return null;
  if (!anio) return lista[0];
  const d = m => (anioDe(m) ? Math.abs(anioDe(m) - anio) : 5);
  return [...lista].sort((a, b) => d(a) - d(b))[0];
}
const contar = m => (m.format === "MOVIE" ? 1 : m.episodes ?? (m.nextAiringEpisode ? m.nextAiringEpisode.episode - 1 : null));

function armar(a, anilistId, n, pelicula) {
  const filas = Array.from({ length: n }, (_, i) =>
    `  { n: ${i + 1}, t: 1, titulo: ${JSON.stringify(pelicula ? "Película" : "Episodio " + (i + 1))}, video: ${JSON.stringify(armarUrl(anilistId, i + 1))}, iframe: true }`);
  return `// ${a.titulo} (AniList ${anilistId})\nwindow.EPISODIOS = [\n${filas.join(",\n")}\n];\n`;
}

await mkdir("episodios", { recursive: true });
const log = [];
let hechos = 0, omitidos = 0; const sinDato = [];
let i = 0;

for (const a of animes) {
  i++;
  if (SOLO && a.id !== SOLO) continue;
  const destino = `episodios/${a.id}.js`;
  const yaExiste = await existe(destino);
  if (yaExiste && !FORZAR) { omitidos++; continue; }   // no pisa tus archivos de Livid ni otros ya hechos

  let dato = cache[a.id];
  if (!dato) {
    const lista = await buscar(a.titulo.replace(/\s*\(.*?\)\s*/g, " ").trim());
    await dormir(800); // AniList permite ~90 consultas por minuto
    const m = elegir(lista, a.anio || null);
    const n = m ? contar(m) : null;
    if (!m || !n || n < 1) { sinDato.push(a.id); console.log(`[${i}/${animes.length}] SIN DATO: ${a.id}`); continue; }
    dato = { anilist: m.id, nombre: m.title.romaji || m.title.english, anio: anioDe(m), episodios: n, pelicula: m.format === "MOVIE" };
    cache[a.id] = dato;
    await writeFile("anilist-cache.json", JSON.stringify(cache, null, 1));
  }

  if (yaExiste) {
    await mkdir("episodios/_respaldo", { recursive: true });
    await copyFile(destino, `episodios/_respaldo/${a.id}-${Date.now()}.js`);
  }
  await writeFile(destino, armar(a, dato.anilist, dato.episodios, dato.pelicula));
  hechos++;
  const linea = `${a.id}  ->  [${dato.anilist}] ${dato.nombre} (${dato.anio}) · ${dato.episodios} ${dato.pelicula ? "película" : "eps"}`;
  log.push(linea);
  console.log(`[${i}/${animes.length}] ${linea}`);
}

await writeFile("embeds-log.txt", log.join("\n") + (sinDato.length ? `\n\nSIN DATO:\n${sinDato.join("\n")}` : "") + "\n");
console.log(`\nListo: ${hechos} animes con su archivo en episodios/. Omitidos (ya tenían archivo): ${omitidos}.`);
if (sinDato.length) console.log(`Sin dato (${sinDato.length}): revisa embeds-log.txt`);
