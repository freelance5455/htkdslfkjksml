@echo off
cd /d "%~dp0"
node posters-anilist.mjs %*
pause
