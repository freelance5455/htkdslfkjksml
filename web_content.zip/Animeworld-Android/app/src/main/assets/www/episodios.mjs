// Crea el archivo de episodios de cada anime que todavía no tiene:  episodios/<id>.js
// Uso:  node episodios.mjs      (corre antes  node separar-episodios.mjs  una vez)
// - Busca cuántos episodios tiene cada anime en AniList y arma la lista completa.
// - Cada episodio apunta a  videos/<id>/ep01.mp4, ep02.mp4...  (y crea esas carpetas vacías).
// - Si el anime ya tiene su archivo en episodios/, no lo toca.
import { readFile, writeFile, mkdir, access } from "node:fs/promises";
import vm from "node:vm";

const CARPETA_VIDEOS = "videos";
const EXTENSION = "mp4";
const dormir = ms => new Promise(r => setTimeout(r, ms));
const existe = p => access(p).then(() => true, () => false);

const animes = vm.runInNewContext((await readFile("data.js", "utf8")) + "\n;ANIMES");

const consulta = `query($s:String){Page(perPage:6){media(search:$s,type:ANIME,sort:SEARCH_MATCH){
  seasonYear startDate{year} format episodes nextAiringEpisode{episode}}}}`;

async function buscar(s) {
  for (let i = 0; i < 4; i++) {
    const r = await fetch("https://graphql.anilist.co", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ query: consulta, variables: { s } })
    }).catch(e => { console.log("No pude conectar con AniList (¿sin internet o bloqueado?): " + (e.cause?.code ?? e.message)); return null; });
    if (!r) return [];
    if (r.status === 429) { await dormir((Number(r.headers.get("retry-after")) || 30) * 1000); continue; }
    if (!r.ok) { console.log(`AniList respondió con error ${r.status}: ${(await r.text()).slice(0, 200)}`); return []; }
    return (await r.json()).data.Page.media;
  }
  return [];
}

const anioDe = m => m.seasonYear ?? m.startDate?.year ?? null;
function elegir(lista, anio) {
  if (!lista.length) return null;
  if (!anio) return lista[0];
  const d = m => (anioDe(m) ? Math.abs(anioDe(m) - anio) : 5);
  return [...lista].sort((a, b) => d(a) - d(b))[0];
}
const contar = m => (m.format === "MOVIE" ? 1 : m.episodes ?? (m.nextAiringEpisode ? m.nextAiringEpisode.episode - 1 : null));

function armar(a, n, pelicula) {
  const ancho = Math.max(2, String(n).length);
  const filas = Array.from({ length: n }, (_, i) => {
    const video = `${CARPETA_VIDEOS}/${a.id}/` + (pelicula ? `pelicula.${EXTENSION}` : `ep${String(i + 1).padStart(ancho, "0")}.${EXTENSION}`);
    return `  { n: ${i + 1}, titulo: ${JSON.stringify(pelicula ? "Película" : "Episodio " + (i + 1))}, video: ${JSON.stringify(video)} }`;
  });
  return `// ${a.titulo}\n// Un episodio por línea. Para Livid: video: "https://livid.com/embed/CODIGO", iframe: true\nwindow.EPISODIOS = [\n${filas.join(",\n")}\n];\n`;
}

await mkdir("episodios", { recursive: true });
let hechos = 0; const sinDato = []; let i = 0;
for (const a of animes) {
  i++;
  if (await existe(`episodios/${a.id}.js`) || a.episodios?.length) continue;
  const m = elegir(await buscar(a.titulo.replace(/\s*\(.*?\)\s*/g, " ").trim()), a.anio || null);
  await dormir(800);
  const n = m ? contar(m) : null;
  if (!n || n < 1) { sinDato.push(a.id); console.log(`[${i}/${animes.length}] SIN DATO: ${a.id}`); continue; }
  await writeFile(`episodios/${a.id}.js`, armar(a, n, m.format === "MOVIE"));
  await mkdir(`${CARPETA_VIDEOS}/${a.id}`, { recursive: true });
  hechos++;
  console.log(`[${i}/${animes.length}] ${a.id}: ${n} ${m.format === "MOVIE" ? "película" : "episodios"}`);
}
console.log(`\nListo: ${hechos} animes con su archivo en episodios/.` + (sinDato.length ? `\nSin dato (crea su archivo a mano): ${sinDato.join(", ")}` : ""));
