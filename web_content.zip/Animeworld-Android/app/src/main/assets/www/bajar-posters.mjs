// Baja el póster de cada anime de data.js y lo guarda en img/<id>.jpg
// Uso (dentro de la carpeta de la página):  node bajar-posters.mjs
// Necesita Node 18 o más nuevo. Si un póster ya existe, lo salta (así no pisa los que pongas a mano).
import { readFile, writeFile, mkdir, access } from "node:fs/promises";

const dormir = ms => new Promise(r => setTimeout(r, ms));
const existe = p => access(p).then(() => true, () => false);

// Lee id, título y año de data.js
const texto = await readFile("data.js", "utf8");
const re = /["']?id["']?\s*:\s*"([^"]+)"\s*,\s*["']?titulo["']?\s*:\s*"((?:[^"\\]|\\.)*)"(?:\s*,\s*["']?anio["']?\s*:\s*(\d+|""))?/g;
const animes = [...texto.matchAll(re)].map(m => ({
  id: m[1],
  titulo: JSON.parse('"' + m[2] + '"'),
  anio: m[3] && m[3] !== '""' ? Number(m[3]) : null
}));

const consulta = `query($s:String){Page(perPage:6){media(search:$s,type:ANIME,sort:SEARCH_MATCH){
  seasonYear title{romaji english} coverImage{extraLarge large}}}}`;

async function buscar(s) {
  for (let intento = 0; intento < 4; intento++) {
    const r = await fetch("https://graphql.anilist.co", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ query: consulta, variables: { s } })
    });
    if (r.status === 429) { await dormir((Number(r.headers.get("retry-after")) || 30) * 1000); continue; }
    if (!r.ok) return [];
    return (await r.json()).data.Page.media;
  }
  return [];
}

// Entre los resultados, elige el que más se acerca al año del anime
const dist = (m, anio) => m.seasonYear ? Math.abs(m.seasonYear - anio) : 5;
function elegir(lista, anio) {
  if (!lista.length) return null;
  if (!anio) return lista[0];
  return [...lista].sort((a, b) => dist(a, anio) - dist(b, anio))[0];
}

await mkdir("img", { recursive: true });
const log = [];
let n = 0;
for (const a of animes) {
  n++;
  const destino = `img/${a.id}.jpg`;
  if (await existe(destino)) { console.log(`[${n}/${animes.length}] ya existe: ${a.id}`); continue; }

  const busqueda = a.titulo.replace(/\s*\(.*?\)\s*/g, " ").trim();
  const m = elegir(await buscar(busqueda), a.anio);
  if (!m) { const l = `NO ENCONTRADO: ${a.id}`; console.log(l); log.push(l); await dormir(800); continue; }

  const url = m.coverImage.extraLarge || m.coverImage.large;
  const img = await fetch(url);
  await writeFile(destino, Buffer.from(await img.arrayBuffer()));

  const nombre = m.title.romaji || m.title.english;
  const aviso = a.anio && dist(m, a.anio) > 1 ? "  ⚠ REVISAR" : "";
  const l = `${a.id} -> ${nombre} (${m.seasonYear ?? "?"})${aviso}`;
  console.log(`[${n}/${animes.length}] ${l}`);
  log.push(l);
  await dormir(800); // AniList permite ~90 consultas por minuto
}

await writeFile("posters-log.txt", log.join("\n"));
console.log("\nListo. Revisa posters-log.txt, sobre todo las líneas con ⚠ y las NO ENCONTRADO.");
