// Pone (o cambia) el inicio de cada capítulo en TODOS los archivos de episodios/ que usan AniSrc.
// No vuelve a consultar AniList y no toca los videos que no sean de AniSrc (por ejemplo los de Livid).
// Uso (en la carpeta donde está data.js):
//   node saltar.mjs        -> omite los primeros 12 segundos
//   node saltar.mjs 20     -> omite 20 segundos
//   node saltar.mjs 0      -> quita la omisión
// Antes de cambiar un archivo guarda copia en episodios/_respaldo/
import { readdir, readFile, writeFile, mkdir, copyFile } from "node:fs/promises";

const SEG = process.argv[2] !== undefined ? Number(process.argv[2]) : 12;
if (!Number.isFinite(SEG) || SEG < 0) { console.log("Escribe un número de segundos, por ejemplo: node saltar.mjs 12"); process.exit(1); }

const archivos = (await readdir("episodios")).filter(f => f.endsWith(".js"));
let cambiados = 0, omitidos = 0;

for (const f of archivos) {
  const ruta = `episodios/${f}`;
  const txt = await readFile(ruta, "utf8");
  if (!txt.includes("anisrc.ru/embed")) { omitidos++; continue; }   // no es de AniSrc: no se toca

  const nuevo = txt.replace(/"(https:\/\/anisrc\.ru\/embed\/[^"]*)"/g, (_, url) => {
    url = url.replace(/([?&])startAt=\d+(&|$)/, (m, a, b) => (b ? a : "")).replace(/[?&]$/, "");
    if (SEG > 0) url += (url.includes("?") ? "&" : "?") + "startAt=" + SEG;
    return `"${url}"`;
  });
  if (nuevo === txt) { omitidos++; continue; }

  await mkdir("episodios/_respaldo", { recursive: true });
  await copyFile(ruta, `episodios/_respaldo/${f.replace(/\.js$/, "")}-${Date.now()}.js`);
  await writeFile(ruta, nuevo);
  cambiados++;
}
console.log(`Listo: ${cambiados} archivos actualizados` + (SEG > 0 ? ` (se omiten los primeros ${SEG} s).` : " (sin omisión).") + ` Sin cambios: ${omitidos}.`);
