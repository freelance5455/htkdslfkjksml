@echo off
cd /d "%~dp0"
node agregar-animes.mjs
pause
