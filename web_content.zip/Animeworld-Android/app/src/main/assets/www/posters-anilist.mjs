// Pone el póster de AniList DIRECTO en data.js (la página lo carga desde AniList, no hay que bajar imágenes).
// Uso (en la carpeta de la página, donde está data.js):
//   node posters-anilist.mjs             -> cambia solo los animes que todavía tienen póster local (img/...)
//   node posters-anilist.mjs --todos     -> cambia TODOS (también refresca los que ya eran de AniList)
//   node posters-anilist.mjs --large     -> usa la versión "large" (más liviana) en vez de "extraLarge"
//   node posters-anilist.mjs --probar    -> solo muestra qué cambiaría; no escribe nada
//   node posters-anilist.mjs --anime code-geass   -> solo ese anime
//
// Qué hace:
//  1. Lee tus animes de data.js
//  2. Saca el ID de AniList de cada uno: de anilist-cache.json, o del póster que ya tenga, o buscándolo por título y año
//  3. Le pregunta a AniList por la portada de todos (50 por consulta, así que son pocas llamadas)
//  4. Cambia  "poster": "img/xxx.jpg"  por la dirección de AniList en data.js (antes guarda copia)
//  5. Guarda posters-anilist-log.txt con lo que hizo; revisa las líneas con ⚠ y las NO ENCONTRADO
// Se puede repetir sin problema: lo que ya quedó con póster de AniList se salta (salvo con --todos).
// Necesita Node 18 o más nuevo.
import { readFile, writeFile, copyFile, access } from "node:fs/promises";
import vm from "node:vm";

const ARG = process.argv.slice(2);
const TODOS = ARG.includes("--todos");
const PROBAR = ARG.includes("--probar");
const TAMANO = ARG.includes("--large") ? "large" : "extraLarge";
const SOLO = ARG.includes("--anime") ? ARG[ARG.indexOf("--anime") + 1] : null;

const dormir = ms => new Promise(r => setTimeout(r, ms));
const existe = p => access(p).then(() => true, () => false);
const esUrl = p => /^https?:\/\//.test(p || "");

const src = await readFile("data.js", "utf8");
const animes = vm.runInNewContext(src + "\n;ANIMES");

let cache = {};
if (await existe("anilist-cache.json")) cache = JSON.parse(await readFile("anilist-cache.json", "utf8"));

// ---------- AniList ----------
async function graphql(query, variables) {
  for (let intento = 0; intento < 5; intento++) {
    let r;
    try {
      r = await fetch("https://graphql.anilist.co", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ query, variables })
      });
    } catch (e) {
      console.log("No pude conectar con AniList: " + (e.cause?.code ?? e.message));
      await dormir(3000);
      continue;
    }
    if (r.status === 429) { await dormir((Number(r.headers.get("retry-after")) || 30) * 1000); continue; }
    if (!r.ok) { console.log(`AniList respondió con error ${r.status}`); return null; }
    return (await r.json()).data;
  }
  return null;
}

const Q_IDS = `query($ids:[Int]){Page(perPage:50){media(id_in:$ids,type:ANIME){id seasonYear coverImage{extraLarge large}}}}`;
const Q_BUSCAR = `query($s:String){Page(perPage:6){media(search:$s,type:ANIME,sort:SEARCH_MATCH){id seasonYear coverImage{extraLarge large}}}}`;

const portada = m => m?.coverImage?.[TAMANO] || m?.coverImage?.extraLarge || m?.coverImage?.large || null;
const dist = (m, anio) => (m.seasonYear ? Math.abs(m.seasonYear - anio) : 5);
const elegir = (lista, anio) => (!lista.length ? null : !anio ? lista[0] : [...lista].sort((a, b) => dist(a, anio) - dist(b, anio))[0]);

// ---------- Qué animes toca cambiar ----------
const pendientes = animes.filter(a => (!SOLO || a.id === SOLO) && (TODOS || !esUrl(a.poster)));
console.log(`${animes.length} animes en data.js, ${pendientes.length} por cambiar.`);

const log = [];
const nuevos = new Map();           // id de tu página -> dirección del póster
const porId = [];                   // los que ya tienen ID de AniList
const porBuscar = [];               // los que hay que buscar por título

for (const a of pendientes) {
  const deCache = cache[a.id]?.anilist ?? null;
  const dePoster = (/\/bx?(\d+)-/.exec(a.poster || "") || [])[1] ?? null;
  const id = deCache ?? (dePoster ? Number(dePoster) : null);
  (id ? porId : porBuscar).push({ a, id });
}

// ---------- 1) Por ID, de 50 en 50 ----------
const portadas = new Map();         // id de AniList -> media
for (let i = 0; i < porId.length; i += 50) {
  const lote = porId.slice(i, i + 50).map(x => x.id);
  const data = await graphql(Q_IDS, { ids: lote });
  for (const m of data?.Page?.media ?? []) portadas.set(m.id, m);
  console.log(`[por ID] ${Math.min(i + 50, porId.length)}/${porId.length}`);
  await dormir(800);
}
for (const { a, id } of porId) {
  const url = portada(portadas.get(id));
  if (!url) { log.push(`NO ENCONTRADO (AniList ${id}): ${a.id}`); continue; }
  nuevos.set(a.id, url);
  log.push(`${a.id} -> AniList ${id}`);
}

// ---------- 2) Por título y año (los que no tenían ID) ----------
let n = 0;
for (const { a } of porBuscar) {
  n++;
  const busqueda = String(a.titulo || a.id).replace(/\s*\(.*?\)\s*/g, " ").trim();
  const data = await graphql(Q_BUSCAR, { s: busqueda });
  const m = elegir(data?.Page?.media ?? [], a.anio);
  const url = portada(m);
  if (!url) { log.push(`NO ENCONTRADO: ${a.id}`); console.log(`[buscar ${n}/${porBuscar.length}] NO ENCONTRADO: ${a.id}`); await dormir(800); continue; }
  const aviso = a.anio && dist(m, a.anio) > 1 ? "  ⚠ REVISAR (año distinto)" : "";
  nuevos.set(a.id, url);
  log.push(`${a.id} -> AniList ${m.id} (${m.seasonYear ?? "?"})${aviso}`);
  console.log(`[buscar ${n}/${porBuscar.length}] ${a.id} -> AniList ${m.id}${aviso}`);
  await dormir(800);
}

// ---------- Escribir data.js ----------
const lineas = src.split("\n");
let cambiados = 0;
for (let i = 0; i < lineas.length; i++) {
  const m = /"id"\s*:\s*"([^"]+)"/.exec(lineas[i]);
  const url = m && nuevos.get(m[1]);
  if (!url) continue;
  const nueva = lineas[i].replace(/("poster"\s*:\s*)"[^"]*"/, (_, pre) => pre + JSON.stringify(url));
  if (nueva !== lineas[i]) { lineas[i] = nueva; cambiados++; }
}
const resultado = lineas.join("\n");

// Antes de guardar, comprueba que data.js sigue siendo válido y con los mismos animes
const comprobar = vm.runInNewContext(resultado + "\n;ANIMES");
if (!Array.isArray(comprobar) || comprobar.length !== animes.length) {
  console.log("Algo salió mal al armar data.js; no se guardó nada. Tu archivo sigue igual.");
  process.exit(1);
}

const sinCambio = pendientes.filter(a => !nuevos.has(a.id)).length;
if (PROBAR) {
  console.log(`\n(--probar) Cambiaría ${cambiados} pósters. Sin portada: ${sinCambio}. No se escribió nada.`);
} else if (cambiados > 0) {
  await copyFile("data.js", "data - respaldo antes de posters.js");
  await writeFile("data.js", resultado);
  console.log(`\nListo: ${cambiados} pósters ahora vienen directo de AniList (copia en "data - respaldo antes de posters.js").`);
} else {
  console.log("\nNo había nada que cambiar.");
}

await writeFile("posters-anilist-log.txt", log.join("\n"));
console.log(`Revisa posters-anilist-log.txt${sinCambio ? ` (${sinCambio} sin portada: se quedan como estaban)` : ""}, sobre todo las líneas con ⚠.`);
