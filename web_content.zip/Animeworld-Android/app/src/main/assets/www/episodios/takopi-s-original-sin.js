// Takopi's Original Sin (AniList 185407)
window.EPISODIOS = [
  { n: 1, t: 1, titulo: "Episodio 1", video: "https://embed.vidrift.net/embed/anilist/185407/1?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 2, t: 1, titulo: "Episodio 2", video: "https://embed.vidrift.net/embed/anilist/185407/2?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 3, t: 1, titulo: "Episodio 3", video: "https://embed.vidrift.net/embed/anilist/185407/3?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 4, t: 1, titulo: "Episodio 4", video: "https://embed.vidrift.net/embed/anilist/185407/4?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 5, t: 1, titulo: "Episodio 5", video: "https://embed.vidrift.net/embed/anilist/185407/5?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 6, t: 1, titulo: "Episodio 6", video: "https://embed.vidrift.net/embed/anilist/185407/6?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true }
];
