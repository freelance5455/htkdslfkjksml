// My Hero Academia Season 7 (AniList 163139)
window.EPISODIOS = [
  { n: 1, t: 1, titulo: "Episodio 1", video: "https://embed.vidrift.net/embed/anilist/163139/1?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 2, t: 1, titulo: "Episodio 2", video: "https://embed.vidrift.net/embed/anilist/163139/2?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 3, t: 1, titulo: "Episodio 3", video: "https://embed.vidrift.net/embed/anilist/163139/3?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 4, t: 1, titulo: "Episodio 4", video: "https://embed.vidrift.net/embed/anilist/163139/4?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 5, t: 1, titulo: "Episodio 5", video: "https://embed.vidrift.net/embed/anilist/163139/5?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 6, t: 1, titulo: "Episodio 6", video: "https://embed.vidrift.net/embed/anilist/163139/6?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 7, t: 1, titulo: "Episodio 7", video: "https://embed.vidrift.net/embed/anilist/163139/7?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 8, t: 1, titulo: "Episodio 8", video: "https://embed.vidrift.net/embed/anilist/163139/8?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 9, t: 1, titulo: "Episodio 9", video: "https://embed.vidrift.net/embed/anilist/163139/9?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 10, t: 1, titulo: "Episodio 10", video: "https://embed.vidrift.net/embed/anilist/163139/10?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 11, t: 1, titulo: "Episodio 11", video: "https://embed.vidrift.net/embed/anilist/163139/11?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 12, t: 1, titulo: "Episodio 12", video: "https://embed.vidrift.net/embed/anilist/163139/12?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 13, t: 1, titulo: "Episodio 13", video: "https://embed.vidrift.net/embed/anilist/163139/13?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 14, t: 1, titulo: "Episodio 14", video: "https://embed.vidrift.net/embed/anilist/163139/14?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 15, t: 1, titulo: "Episodio 15", video: "https://embed.vidrift.net/embed/anilist/163139/15?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 16, t: 1, titulo: "Episodio 16", video: "https://embed.vidrift.net/embed/anilist/163139/16?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 17, t: 1, titulo: "Episodio 17", video: "https://embed.vidrift.net/embed/anilist/163139/17?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 18, t: 1, titulo: "Episodio 18", video: "https://embed.vidrift.net/embed/anilist/163139/18?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 19, t: 1, titulo: "Episodio 19", video: "https://embed.vidrift.net/embed/anilist/163139/19?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 20, t: 1, titulo: "Episodio 20", video: "https://embed.vidrift.net/embed/anilist/163139/20?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 21, t: 1, titulo: "Episodio 21", video: "https://embed.vidrift.net/embed/anilist/163139/21?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true }
];
