// Myself; Yourself (AniList 2926)
window.EPISODIOS = [
  { n: 1, t: 1, titulo: "Episodio 1", video: "https://embed.vidrift.net/embed/anilist/2926/1?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 2, t: 1, titulo: "Episodio 2", video: "https://embed.vidrift.net/embed/anilist/2926/2?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 3, t: 1, titulo: "Episodio 3", video: "https://embed.vidrift.net/embed/anilist/2926/3?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 4, t: 1, titulo: "Episodio 4", video: "https://embed.vidrift.net/embed/anilist/2926/4?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 5, t: 1, titulo: "Episodio 5", video: "https://embed.vidrift.net/embed/anilist/2926/5?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 6, t: 1, titulo: "Episodio 6", video: "https://embed.vidrift.net/embed/anilist/2926/6?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 7, t: 1, titulo: "Episodio 7", video: "https://embed.vidrift.net/embed/anilist/2926/7?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 8, t: 1, titulo: "Episodio 8", video: "https://embed.vidrift.net/embed/anilist/2926/8?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 9, t: 1, titulo: "Episodio 9", video: "https://embed.vidrift.net/embed/anilist/2926/9?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 10, t: 1, titulo: "Episodio 10", video: "https://embed.vidrift.net/embed/anilist/2926/10?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 11, t: 1, titulo: "Episodio 11", video: "https://embed.vidrift.net/embed/anilist/2926/11?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 12, t: 1, titulo: "Episodio 12", video: "https://embed.vidrift.net/embed/anilist/2926/12?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 13, t: 1, titulo: "Episodio 13", video: "https://embed.vidrift.net/embed/anilist/2926/13?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true }
];
