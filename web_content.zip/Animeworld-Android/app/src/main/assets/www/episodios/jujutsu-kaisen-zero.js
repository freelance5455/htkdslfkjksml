// Jujutsu Kaisen 0 (AniList 131573)
window.EPISODIOS = [
  { n: 1, t: 1, titulo: "Película", video: "https://embed.vidrift.net/embed/anilist/131573/1?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true }
];
