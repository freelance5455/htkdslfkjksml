// The Devil is a Part-Timer! (AniList 15809)
window.EPISODIOS = [
  { n: 1, t: 1, titulo: "Episodio 1", video: "https://embed.vidrift.net/embed/anilist/15809/1?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 2, t: 1, titulo: "Episodio 2", video: "https://embed.vidrift.net/embed/anilist/15809/2?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 3, t: 1, titulo: "Episodio 3", video: "https://embed.vidrift.net/embed/anilist/15809/3?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 4, t: 1, titulo: "Episodio 4", video: "https://embed.vidrift.net/embed/anilist/15809/4?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 5, t: 1, titulo: "Episodio 5", video: "https://embed.vidrift.net/embed/anilist/15809/5?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 6, t: 1, titulo: "Episodio 6", video: "https://embed.vidrift.net/embed/anilist/15809/6?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 7, t: 1, titulo: "Episodio 7", video: "https://embed.vidrift.net/embed/anilist/15809/7?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 8, t: 1, titulo: "Episodio 8", video: "https://embed.vidrift.net/embed/anilist/15809/8?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 9, t: 1, titulo: "Episodio 9", video: "https://embed.vidrift.net/embed/anilist/15809/9?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 10, t: 1, titulo: "Episodio 10", video: "https://embed.vidrift.net/embed/anilist/15809/10?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 11, t: 1, titulo: "Episodio 11", video: "https://embed.vidrift.net/embed/anilist/15809/11?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 12, t: 1, titulo: "Episodio 12", video: "https://embed.vidrift.net/embed/anilist/15809/12?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 13, t: 1, titulo: "Episodio 13", video: "https://embed.vidrift.net/embed/anilist/15809/13?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true }
];
