// Re:ZERO -Starting Life in Another World- The Frozen Bond (AniList 100049)
window.EPISODIOS = [
  { n: 1, t: 1, titulo: "Episodio 1", video: "https://embed.vidrift.net/embed/anilist/100049/1?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true },
  { n: 2, t: 1, titulo: "Episodio 2", video: "https://embed.vidrift.net/embed/anilist/100049/2?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true }
];
