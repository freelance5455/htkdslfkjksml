// Memories (AniList 1462)
window.EPISODIOS = [
  { n: 1, t: 1, titulo: "Película", video: "https://embed.vidrift.net/embed/anilist/1462/1?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true }
];
