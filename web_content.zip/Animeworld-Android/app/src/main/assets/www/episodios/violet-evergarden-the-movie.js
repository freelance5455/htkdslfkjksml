// Violet Evergarden: the Movie (AniList 103047)
window.EPISODIOS = [
  { n: 1, t: 1, titulo: "Película", video: "https://embed.vidrift.net/embed/anilist/103047/1?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true }
];
