// Your Name. (AniList 21519)
window.EPISODIOS = [
  { n: 1, t: 1, titulo: "Película", video: "https://embed.vidrift.net/embed/anilist/21519/1?sub=es&autoplay=0&hide=server,next,episodes,settings,lock,pip,cast,title,pausecard", iframe: true }
];
