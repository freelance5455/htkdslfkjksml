#!/usr/bin/env python3
"""
Enciende el servidor de videos + el túnel, y conecta SOLO la página de Cloudflare Pages con la dirección nueva.

Qué hace, en orden:
  1. Arranca servidor.py (sirve la carpeta que contiene videos/)
  2. Arranca cloudflared y lee la dirección trycloudflare.com que le toca
  3. Escribe esa dirección en config.js
  4. Sube SOLO los archivos públicos a Cloudflare Pages (sin videos ni scripts)
  5. Se queda corriendo. Ctrl+C (o cerrar la ventana) apaga todo.

Úsalo en una ventana normal (publicar.bat), no en la terminal de VS Code.
"""
import os, re, shutil, subprocess, sys, tempfile, threading, time, urllib.request
from pathlib import Path

# ====== AJUSTA ESTO ======
CARPETA_VIDEOS = r""            # carpeta que CONTIENE a videos/ (vacío = la misma carpeta de este script)
PROYECTO = "animeworld"         # nombre del proyecto en Cloudflare Pages
RAMA = "production"
PUERTO = 8080
# =========================

SITIO = Path(__file__).resolve().parent
RAIZ_VIDEOS = Path(CARPETA_VIDEOS) if CARPETA_VIDEOS else SITIO
PUBLICO_ARCHIVOS = ["index.html", "anime.html", "style.css", "data.js", "app.js", "config.js"]
PUBLICO_CARPETAS = ["img", "episodios", "frames"]
URL_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")


def faltan_herramientas():
    f = [n for n in ("cloudflared", "npx") if not shutil.which(n)]
    if not (RAIZ_VIDEOS / "videos").is_dir():
        f.append(f"carpeta 'videos' dentro de {RAIZ_VIDEOS}")
    if not (SITIO / "servidor.py").exists():
        f.append("servidor.py junto a este script")
    return f


def leer_url_tunel(proc, espera=60):
    """Lee la salida de cloudflared hasta ver la dirección; sigue drenando la salida en segundo plano."""
    encontrada = []

    def lector():
        for linea in proc.stdout:
            m = URL_RE.search(linea)
            if m and not encontrada:
                encontrada.append(m.group(0))

    threading.Thread(target=lector, daemon=True).start()
    fin = time.time() + espera
    while time.time() < fin and not encontrada and proc.poll() is None:
        time.sleep(0.3)
    return encontrada[0] if encontrada else None


def escribir_config(url):
    """Cambia SOLO la línea VIDEO_BASE de config.js y deja intacto lo demás (Discord, donaciones, planes...)."""
    cfg = SITIO / "config.js"
    linea = f'window.VIDEO_BASE = "{url}";'
    if cfg.exists():
        shutil.copy2(cfg, SITIO / "config.js.bak")
        txt = cfg.read_text(encoding="utf-8")
        if re.search(r"^\s*window\.VIDEO_BASE\s*=.*$", txt, re.M):
            txt = re.sub(r"^\s*window\.VIDEO_BASE\s*=.*$", lambda m: linea, txt, count=1, flags=re.M)
        else:
            txt = linea + "\n" + txt
    else:
        txt = "// Dirección desde donde se cargan los VIDEOS.\n" + linea + "\n"
    cfg.write_text(txt, encoding="utf-8")


def preparar_carpeta_publica():
    """Copia solo lo público a una carpeta temporal (así nunca se suben videos ni scripts)."""
    tmp = Path(tempfile.mkdtemp(prefix="animeworld_"))
    for n in PUBLICO_ARCHIVOS:
        if (SITIO / n).exists():
            shutil.copy2(SITIO / n, tmp / n)
    for c in PUBLICO_CARPETAS:
        if (SITIO / c).is_dir():
            shutil.copytree(SITIO / c, tmp / c, ignore=shutil.ignore_patterns("_respaldo", "*.tmp", "__pycache__"))
    return tmp


def main():
    falta = faltan_herramientas()
    if falta:
        print("No puedo empezar, falta:", *falta, sep="\n  - "); return
    print("1/4 Encendiendo servidor de videos...")
    servidor = subprocess.Popen([sys.executable, str(SITIO / "servidor.py")], cwd=str(RAIZ_VIDEOS))
    tunel = None
    try:
        print("2/4 Encendiendo túnel (puede tardar unos segundos)...")
        tunel = subprocess.Popen(["cloudflared", "tunnel", "--protocol", "http2", "--url", f"http://localhost:{PUERTO}"],
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                 encoding="utf-8", errors="replace", bufsize=1)
        url = leer_url_tunel(tunel)
        if not url:
            print("No pude leer la dirección del túnel. Revisa tu internet y vuelve a intentar."); return
        print("    Dirección del túnel:", url)
        print("3/4 Escribiendo config.js...")
        escribir_config(url)
        print("4/4 Subiendo la página a Cloudflare Pages...")
        tmp = preparar_carpeta_publica()
        try:
            r = subprocess.run(f"npx wrangler pages deploy . --project-name {PROYECTO} --branch {RAMA}", shell=True, cwd=str(tmp))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        if r.returncode != 0:
            print("\nLa subida falló. Revisa el mensaje de arriba (¿sesión de wrangler vencida? prueba: npx wrangler login)."); return
        print("\n=== LISTO ===")
        print("Los videos salen de:", url)
        print("Deja esta ventana abierta. Ctrl+C para apagar todo.")
        while servidor.poll() is None and tunel.poll() is None:
            time.sleep(2)
        print("Algo se cerró (servidor o túnel). Apagando.")
    except KeyboardInterrupt:
        print("\nApagando...")
    finally:
        for p in (tunel, servidor):
            if p and p.poll() is None:
                p.terminate()


if __name__ == "__main__":
    main()
