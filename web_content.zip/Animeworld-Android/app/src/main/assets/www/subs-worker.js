// Endpoint de subtítulos bajo demanda para el parámetro sub_url de AniSrc.
//
//   GET https://TU-WORKER.workers.dev/subs/{anilistId}/{capitulo}.{idioma}.vtt      ej: /subs/1575/1.es.vtt
//
// Flujo:
//   1) ¿Ya está en caché (R2: cache/1575/1.es.vtt)?  -> se devuelve al instante
//   2) Si no: toma el subtítulo FUENTE que tú guardaste en R2 (src/1575/1.srt o .vtt), lo traduce por lotes
//      con Workers AI, arma el .vtt, lo guarda en caché y lo devuelve.
//   Solo se genera lo que alguien realmente pide, así que no hay que procesar los 458 animes de antemano.
//
// IMPORTANTE: el endpoint necesita una FUENTE de subtítulos que tengas derecho a usar (archivos .srt/.vtt tuyos,
// o pistas extraídas de tus propios videos). Este código no los busca por internet.

const SEPARADOR = "\n";
const LOTE = 15;                       // cuántas líneas se traducen por llamada (el plan gratis limita las llamadas por ejecución)
const IDIOMAS_DESTINO = ["es", "en", "pt", "fr", "de", "it"];

const CORS = {
  "Access-Control-Allow-Origin": "*",                       // el que pide el archivo es el reproductor (anisrc.ru), no tu página
  "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
  "Access-Control-Allow-Headers": "Range, Content-Type",
  "Cross-Origin-Resource-Policy": "cross-origin",
  "X-Content-Type-Options": "nosniff"
};

const texto = (msg, status) =>
  new Response(msg, { status, headers: { "Content-Type": "text/plain; charset=utf-8", ...CORS } });

// ---------- formato ----------
export function parsear(src) {
  const bloques = src.replace(/^\uFEFF/, "").replace(/\r/g, "").split(/\n{2,}/);
  const cues = [];
  for (const b of bloques) {
    const lineas = b.split("\n");
    const i = lineas.findIndex(l => l.includes("-->"));
    if (i === -1) continue;                                  // cabecera WEBVTT, NOTE, etc.
    const [ini, fin] = lineas[i].split("-->").map(s => s.trim().split(/\s+/)[0].replace(",", "."));
    const t = lineas.slice(i + 1).join(" ")
      .replace(/\{\\[^}]*\}/g, "")                           // códigos de posición de .ass ({\an8})
      .replace(/\s+/g, " ").trim();
    if (t) cues.push({ ini, fin, texto: t });
  }
  return cues;
}

export function construirVtt(cues, textos) {
  return "WEBVTT\n\n" + cues.map((c, i) => `${c.ini} --> ${c.fin}\n${textos[i] ?? c.texto}\n`).join("\n");
}

// ---------- traducción por lotes ----------
async function traducirUna(env, t, origen, destino) {
  const r = await env.AI.run("@cf/meta/m2m100-1.2b", { text: t, source_lang: origen, target_lang: destino });
  return (r?.translated_text || t).trim();
}

async function traducir(env, lineas, origen, destino) {
  if (origen === destino) return lineas;
  const out = [];
  for (let i = 0; i < lineas.length; i += LOTE) {
    const lote = lineas.slice(i, i + LOTE);
    const r = await traducirUna(env, lote.join(SEPARADOR), origen, destino);
    const partes = r.split(/\n+/).map(s => s.trim()).filter(Boolean);
    if (partes.length === lote.length) out.push(...partes);
    else out.push(...await Promise.all(lote.map(l => traducirUna(env, l, origen, destino))));   // el lote no cuadró: línea por línea
  }
  return out;
}

// ---------- endpoint ----------
export default {
  async fetch(request, env, ctx) {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
    if (request.method !== "GET" && request.method !== "HEAD") return texto("Método no permitido", 405);

    const m = new URL(request.url).pathname.match(/^\/subs\/(\d{1,7})\/(\d{1,4})\.([a-z]{2})\.vtt$/);
    if (!m) return texto("Ruta no válida. Usa /subs/{id}/{capitulo}.{idioma}.vtt", 404);
    const [, id, ep, lang] = m;
    if (!IDIOMAS_DESTINO.includes(lang)) return texto("Idioma no permitido", 400);
    if (env.IDS_PERMITIDOS && !env.IDS_PERMITIDOS.split(",").map(s => s.trim()).includes(id))
      return texto("Anime no registrado", 404);                // evita que gasten tu cuota pidiendo ids al azar

    const claveCache = `cache/${id}/${ep}.${lang}.vtt`;
    let vtt;
    const guardado = await env.SUBS.get(claveCache);
    if (guardado) vtt = await guardado.text();
    else {
      const fuente = (await env.SUBS.get(`src/${id}/${ep}.srt`)) || (await env.SUBS.get(`src/${id}/${ep}.vtt`));
      if (!fuente) return texto("No hay subtítulo fuente para este capítulo", 404);   // 404 real, nunca una página HTML
      const cues = parsear(await fuente.text());
      if (!cues.length) return texto("El subtítulo fuente está vacío o no se pudo leer", 422);
      try {
        const traducidos = await traducir(env, cues.map(c => c.texto), env.IDIOMA_FUENTE || "en", lang);
        vtt = construirVtt(cues, traducidos);
      } catch (e) {
        return texto("No se pudo traducir ahora (¿límite diario de Workers AI?)", 503);
      }
      ctx.waitUntil(env.SUBS.put(claveCache, vtt, { httpMetadata: { contentType: "text/vtt; charset=utf-8" } }));
    }

    return new Response(request.method === "HEAD" ? null : vtt, {
      status: 200,
      headers: { "Content-Type": "text/vtt; charset=utf-8", "Cache-Control": "public, max-age=86400", ...CORS }
    });
  }
};
