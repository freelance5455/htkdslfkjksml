// Comportamiento extra del modo APP (solo corre dentro del APK; en el navegador no hace nada).
(function () {
  const raiz = document.documentElement;
  if (!raiz.classList.contains("app")) return;

  const en = raiz.classList.contains("app-anime");
  const ic = {
    inicio: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9.5h4.5v-5h4v5h4.5V10"/>',
    buscar: '<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>',
    menu:   '<path d="M4 7h16M4 12h16M4 17h16"/>',
    perfil: '<circle cx="12" cy="8.5" r="3.8"/><path d="M4.5 20c.8-3.6 3.8-5.5 7.5-5.5s6.7 1.9 7.5 5.5"/>'
  };
  const tab = (id, txt, fn) => {
    const b = document.createElement("button"); b.dataset.id = id; b.setAttribute("aria-label", txt);
    b.innerHTML = `<svg viewBox="0 0 24 24">${ic[id]}</svg><span>${txt}</span>`; b.onclick = fn; return b;
  };

  const $q = document.getElementById("buscar");
  // Modo búsqueda: la barra de arriba cambia el logo por el campo de texto
  const ICO_LUPA = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></svg>';
  const ICO_X = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>';
  let lupa = null;
  function buscar(on) {
    if (!$q) return;
    raiz.classList.toggle("buscando", on);
    if (lupa) lupa.innerHTML = on ? ICO_X : ICO_LUPA;
    if (on) { window.scrollTo({ top: 0 }); setTimeout(() => $q.focus(), 60); }
    else { $q.blur(); if ($q.value) { $q.value = ""; $q.dispatchEvent(new Event("input")); } }
    nav.querySelector('[data-id="inicio"]')?.setAttribute("aria-current", on ? "false" : "true");
    nav.querySelector('[data-id="buscar"]')?.setAttribute("aria-current", on ? "true" : "false");
  }
  const nav = document.createElement("nav"); nav.className = "app-nav";
  nav.append(
    tab("inicio", "Inicio", () => { if (en) location.href = "index.html"; else { buscar(false); window.scrollTo({ top: 0, behavior: "smooth" }); } }),
    tab("buscar", "Buscar", () => { if (!$q) { location.href = "index.html?buscar=1"; return; } buscar(true); }),
    tab("menu", "Menú", () => document.getElementById("btn-menu")?.click()),
    tab("perfil", "Perfil", () => document.getElementById("btn-perfil")?.click())
  );
  document.body.append(nav);
  if (!en) nav.querySelector('[data-id="inicio"]').setAttribute("aria-current", "true");

  // Contador de géneros activos sobre "Menú" (lo copia del botón de las tres rayas)
  const hamb = document.getElementById("btn-menu");
  if (hamb) {
    const marca = () => {
      const t = nav.querySelector('[data-id="menu"]'); t.querySelector("b")?.remove();
      if (hamb.dataset.n) { const b = document.createElement("b"); b.textContent = hamb.dataset.n; t.append(b); }
    };
    new MutationObserver(marca).observe(hamb, { attributes: true, attributeFilter: ["data-n"] }); marca();
  }

  // Flecha de volver en la ficha del anime
  if (en) {
    const barra = document.querySelector(".barra");
    const a = document.createElement("button"); a.className = "app-atras"; a.setAttribute("aria-label", "Volver");
    a.innerHTML = '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 5-7 7 7 7"/></svg>';
    a.onclick = () => (history.length > 1 ? history.back() : (location.href = "index.html"));
    barra && barra.prepend(a);
    // Sinopsis: toque para abrir/cerrar
    const s = document.getElementById("sinopsis"); if (s) s.onclick = () => s.classList.toggle("abierta");
  }

  // Con el teclado abierto se oculta la barra de abajo
  addEventListener("focusin", e => { if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) raiz.classList.add("teclado"); });
  addEventListener("focusout", () => raiz.classList.remove("teclado"));

  if (!en && $q) {
    lupa = document.createElement("button"); lupa.className = "app-lupa"; lupa.setAttribute("aria-label", "Buscar"); lupa.innerHTML = ICO_LUPA;
    lupa.onclick = () => buscar(!raiz.classList.contains("buscando"));
    document.querySelector(".barra").append(lupa);
    // Viene de "Buscar" desde la ficha
    if (new URLSearchParams(location.search).get("buscar")) buscar(true);
    portada();
  }

  // ---------- Inicio estilo app: botón de favorito en el destacado, "Seguir viendo" y "Agregados recientemente" ----------
  function portada() {
    const lista = (typeof ANIMES !== "undefined" && ANIMES) || [];
    const dest = document.getElementById("destacado");
    const porId = id => lista.find(a => a.id === id);
    const mmss = t => `${Math.floor(t / 60)}:${String(t % 60).padStart(2, "0")}`;

    // Destacado: "Ver ahora" con ▶ y corazón (favorito). Se vuelve a poner cada vez que rota.
    if (dest) {
      const poner = () => {
        const btn = dest.querySelector("a.btn"); if (!btn || btn.parentElement.classList.contains("hero-acc")) return;
        const id = decodeURIComponent((/id=([^&]+)/.exec(btn.getAttribute("href")) || [])[1] || "");
        btn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg> Ver ahora';
        const fila = document.createElement("div"); fila.className = "hero-acc";
        const fav = document.createElement("button"); fav.className = "hero-fav"; fav.setAttribute("aria-label", "Favorito");
        const pintar = () => { const f = estadoDe(id).fav; fav.setAttribute("aria-pressed", f);
          fav.innerHTML = `<svg width="22" height="22" viewBox="0 0 24 24" fill="${f ? "currentColor" : "none"}" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="${ICONOS.corazon}"/></svg>`; };
        fav.onclick = () => { const on = alternarFav(id); pintar(); try { aviso(on ? "Añadido a favoritos" : "Quitado de favoritos"); } catch (e) {} };
        pintar(); btn.before(fila); fila.append(btn, fav);
      };
      new MutationObserver(poner).observe(dest, { childList: true }); poner();
    }

    const crear = (titulo, extra) => { const s = document.createElement("section"); s.className = "app-sec";
      const h = document.createElement("h2"); h.textContent = titulo; const f = document.createElement("div"); f.className = "app-fila"; s.append(h, f); return { s, f }; };

    // Seguir viendo
    const d = leer(), vistos = (d.historial || []).filter(h => porId(h.id) && !(d.listas?.terminados || []).includes(h.id)).slice(0, 10);
    const ancla = document.querySelector(".filtros");
    const antes = ancla || document.getElementById("catalogo");
    if (vistos.length) {
      const { s, f } = crear("Seguir viendo");
      vistos.forEach(h => {
        const a = porId(h.id), p = d.progreso?.[h.id] || {}, k = p.ep || h.ep || 1, n = k >= 1000 ? k % 1000 : k;
        const c = document.createElement("a"); c.className = "app-cont"; c.href = "anime.html?id=" + encodeURIComponent(a.id);
        c.style.backgroundImage = `url("${a.poster}")`;
        const em = document.createElement("em"); em.textContent = "EP. " + n;
        const t = document.createElement("strong"); t.textContent = a.titulo;
        const sm = document.createElement("small"); sm.textContent = p.t > 0 ? "Continuar en " + mmss(p.t) : "Continuar viendo";
        c.append(em, t, sm); f.append(c);
      });
      antes.before(s);
    }
    // Agregados recientemente (los últimos de data.js)
    const nuevos = lista.slice(-12).reverse();
    if (nuevos.length) {
      const { s, f } = crear("Agregados recientemente");
      nuevos.forEach(a => {
        const c = document.createElement("a"); c.className = "app-mini"; c.href = "anime.html?id=" + encodeURIComponent(a.id);
        const p = document.createElement("div"); p.className = "poster"; p.style.cssText = `background:#1a1a1a url("${a.poster}") center/cover`;
        const h = document.createElement("h3"); h.textContent = a.titulo; c.append(p, h); f.append(c);
      });
      antes.before(s);
    }
    // Título del catálogo completo
    const tit = document.createElement("h2"); tit.className = "app-tit";
    tit.innerHTML = `Catálogo <small>${lista.length} animes</small>`; antes.before(tit);
  }
})();
