package de.financeai.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.provider.CalendarContract
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URI
import java.net.URLEncoder
import java.security.KeyStore
import java.util.Calendar
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Finance AI: Die Oberfläche liegt als HTML in assets/index.html und läuft in einer WebView.
 * Diese Klasse stellt ihr über "Native" die Dinge bereit, die eine Webseite nicht darf:
 * Netzwerk-Abrufe (nur comdirect und Anthropic), verschlüsselte Zugangsdaten, Benachrichtigungen,
 * Kalender, App-Sperre. Es gibt keine Funktion zum Aufgeben von Orders.
 */
class MainActivity : Activity() {
    private lateinit var web: WebView
    private val pool = Executors.newCachedThreadPool()
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.MINUTES)
        .writeTimeout(60, TimeUnit.SECONDS)
        .callTimeout(12, TimeUnit.MINUTES)
        .build()
    private val allowedHosts = setOf("api.comdirect.de", "api.anthropic.com")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notify.ensureChannel(this)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                openExternal(request.url.toString())
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Native")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        js("window.__system&&window.__system()")
    }

    override fun onPause() {
        super.onPause()
        js("window.__pause&&window.__pause()")
    }

    override fun onResume() {
        super.onResume()
        js("window.__resume&&window.__resume()")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        js("window.__back?window.__back():Native.exit()")
    }

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    private fun openExternal(url: String) {
        if (!url.startsWith("https://")) return
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: ActivityNotFoundException) {
            js("window.__toast&&window.__toast('Kein Browser gefunden')")
        }
    }

    /**
     * Setzt gespeicherte Zugangsdaten erst hier in die Anfrage ein. Die Oberfläche schickt nur Platzhalter
     * wie {{secret:cd_pin}} und bekommt die Werte nie zu sehen. Jeder Schlüssel geht nur an seinen Dienst.
     */
    private fun fill(text: String, host: String): String =
        Regex("\\{\\{(secret|secretenc):([a-z_]+)\\}\\}").replace(text) { m ->
            val name = m.groupValues[2]
            val allowed = (name.startsWith("cd_") && host == "api.comdirect.de") ||
                (name.startsWith("claude_") && host == "api.anthropic.com")
            if (!allowed) throw IllegalArgumentException("Zugangsdaten nicht für $host freigegeben")
            val v = Secrets.get(this, name)
            if (m.groupValues[1] == "secretenc") URLEncoder.encode(v, "UTF-8") else v
        }

    private fun systemDark(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private fun doAuth() {
        val auths = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val bm = getSystemService(BiometricManager::class.java)
        if (bm == null || bm.canAuthenticate(auths) != BiometricManager.BIOMETRIC_SUCCESS) {
            // Keine Displaysperre eingerichtet: nicht aussperren, aber der Oberfläche melden.
            js("window.__auth(true,'none')")
            return
        }
        val prompt = BiometricPrompt.Builder(this)
            .setTitle("Finance AI entsperren")
            .setAllowedAuthenticators(auths)
            .build()
        prompt.authenticate(CancellationSignal(), mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                js("window.__auth(true,'ok')")
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                js("window.__auth(false,'error')")
            }
        })
    }

    inner class Bridge {
        /** Netzwerk-Abruf. Antwort kommt über window.__cb(id, {status, headers, body}) zurück. */
        @JavascriptInterface
        fun http(id: String, reqJson: String) {
            pool.execute {
                val out = JSONObject()
                try {
                    val r = JSONObject(reqJson)
                    val url = r.getString("url")
                    val host = URI(url).host ?: ""
                    if (!url.startsWith("https://") || host !in allowedHosts) {
                        throw IllegalArgumentException("Adresse nicht erlaubt: $host")
                    }
                    val method = r.optString("method", "GET").uppercase()
                    val b = Request.Builder().url(url)
                    var contentType = "application/json"
                    val headers = r.optJSONObject("headers")
                    if (headers != null) {
                        for (k in headers.keys()) {
                            val v = headers.getString(k)
                            if (k.equals("content-type", ignoreCase = true)) contentType = v else b.addHeader(k, fill(v, host))
                        }
                    }
                    val needsBody = method == "POST" || method == "PATCH" || method == "PUT"
                    val body = when {
                        r.has("body") && !r.isNull("body") -> fill(r.getString("body"), host).toRequestBody(contentType.toMediaTypeOrNull())
                        needsBody -> "".toRequestBody(null)
                        else -> null
                    }
                    b.method(method, body)
                    client.newCall(b.build()).execute().use { resp ->
                        out.put("status", resp.code)
                        val h = JSONObject()
                        for (n in resp.headers.names()) h.put(n.lowercase(), resp.header(n) ?: "")
                        out.put("headers", h)
                        out.put("body", resp.body?.string() ?: "")
                    }
                } catch (e: Exception) {
                    out.put("status", 0)
                    out.put("error", e.javaClass.simpleName + ": " + (e.message ?: ""))
                }
                js("window.__cb(" + JSONObject.quote(id) + "," + out.toString() + ")")
            }
        }

        @JavascriptInterface
        fun setSecret(key: String, value: String) {
            Secrets.put(this@MainActivity, key, value)
        }

        @JavascriptInterface
        fun hasSecret(key: String): Boolean = Secrets.get(this@MainActivity, key).isNotEmpty()

        @JavascriptInterface
        fun notify(title: String, text: String) {
            Notify.show(this@MainActivity, (System.currentTimeMillis() % 100000).toInt() + 10, title, text)
        }

        @JavascriptInterface
        fun schedule(hour: Int, minute: Int, on: Boolean) {
            Reminder.schedule(this@MainActivity, hour, minute, on)
        }

        @JavascriptInterface
        fun calendar(title: String, millis: Double) {
            runOnUiThread {
                try {
                    startActivity(
                        Intent(Intent.ACTION_INSERT)
                            .setData(CalendarContract.Events.CONTENT_URI)
                            .putExtra(CalendarContract.Events.TITLE, title)
                            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, millis.toLong())
                            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, millis.toLong())
                            .putExtra(CalendarContract.EXTRA_EVENT_ALL_DAY, true)
                    )
                } catch (e: ActivityNotFoundException) {
                    js("window.__toast&&window.__toast('Keine Kalender-App gefunden')")
                }
            }
        }

        @JavascriptInterface
        fun auth() {
            runOnUiThread { doAuth() }
        }

        @JavascriptInterface
        fun systemDark(): Boolean = this@MainActivity.systemDark()

        @JavascriptInterface
        fun bars(color: String, lightBackground: Boolean) {
            runOnUiThread {
                try {
                    val c = Color.parseColor(color)
                    window.statusBarColor = c
                    window.navigationBarColor = c
                    val mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                        WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                    window.insetsController?.setSystemBarsAppearance(if (lightBackground) mask else 0, mask)
                } catch (e: IllegalArgumentException) {
                    // unbekannte Farbe: Systemleisten bleiben, wie sie sind
                }
            }
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread { openExternal(url) }
        }

        @JavascriptInterface
        fun keepAwake(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        @JavascriptInterface
        fun exit() {
            runOnUiThread { moveTaskToBack(true) }
        }
    }
}

/** Zugangsdaten: AES-GCM mit einem Schlüssel, der den Android-Keystore nie verlässt. */
object Secrets {
    private const val ALIAS = "financeai_key"
    private const val PREFS = "financeai_secrets"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return kg.generateKey()
    }

    fun put(ctx: Context, k: String, v: String) {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (v.isEmpty()) {
            prefs.edit().remove(k).apply()
            return
        }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val ct = c.doFinal(v.toByteArray(Charsets.UTF_8))
        val packed = Base64.encodeToString(c.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP)
        prefs.edit().putString(k, packed).apply()
    }

    fun get(ctx: Context, k: String): String {
        val s = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(k, null) ?: return ""
        return try {
            val p = s.split(":")
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(p[0], Base64.NO_WRAP)))
            String(c.doFinal(Base64.decode(p[1], Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }
}

object Notify {
    private const val CHANNEL = "financeai"

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Finance AI", NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun show(ctx: Context, id: Int, title: String, text: String) {
        ensureChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(id, n)
    }
}

/** Tägliche Erinnerung. Sie startet keinen Abruf, sie erinnert nur ans Einloggen. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Notify.show(ctx, 1, "Finance AI", "Zeit für deine Depot-Analyse. Tippen, einloggen und freigeben.")
    }
}

object Reminder {
    fun schedule(ctx: Context, hour: Int, minute: Int, on: Boolean) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            ctx, 7, Intent(ctx, ReminderReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.cancel(pi)
        if (!on) return
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
            set(Calendar.MINUTE, minute.coerceIn(0, 59))
            set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
    }
}
