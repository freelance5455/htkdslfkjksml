# Finance AI

Android-App, die ein comdirect-Depot **nur liest** und mit der Claude-API auswertet.
Die App kann keine Orders aufgeben.

## APK bauen

- **GitHub:** Bei jedem Push auf `main` baut der Workflow „APK bauen“ die Datei.
  Unter *Actions → letzter Lauf → Artifacts* liegt `FinanceAI-apk` zum Herunterladen.
- **Android Studio:** Projekt öffnen, *Build → Build App Bundle(s) / APK(s) → Build APK(s)*.

## Aufbau

- `app/src/main/assets/index.html` – die gesamte Oberfläche und Logik (comdirect-Anmeldung, KI-Abfragen, Ansichten).
- `app/src/main/java/de/financeai/app/MainActivity.kt` – Android-Hülle: Netzwerk (nur `api.comdirect.de` und
  `api.anthropic.com`), verschlüsselte Zugangsdaten, Benachrichtigungen, Kalender, App-Sperre.

Zugangsdaten liegen verschlüsselt im Android-Keystore. Die Oberfläche sieht sie nie:
sie schickt Platzhalter, die Hülle setzt die Werte erst in der Anfrage ein.

## Einrichten in der App

1. *Mehr → Einstellungen*: comdirect Client-ID, Client-Secret, Zugangsnummer, PIN und den Claude-API-Schlüssel eintragen.
2. *Heute → Depot aktualisieren* und die TAN freigeben.
3. *KI-Analyse starten*.
