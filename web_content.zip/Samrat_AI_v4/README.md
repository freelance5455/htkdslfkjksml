# Samrat AI v5 — Hybrid Phone + Helmet Ready

This build keeps Gemini online for the full AI experience, while making a small set of important functions local/offline:

- 🎵 Offline playback of audio files saved in the phone browser (IndexedDB)
- 🪖 Helmet Open / Close commands through Bluetooth Low Energy (BLE)
- 🛑 Emergency STOP command
- 🔌 POWER_ON / POWER_OFF command channel for the helmet controller
- 🎙️ Voice-first local commands in the phone companion page; no typing is needed for those commands
- 🧠 Gemini remains available online for normal questions
- Existing Streamlit app remains available for Gemini, search grounding, memory, images, TTS and YouTube

## Phone companion

Open `phone.html` from a secure web origin (HTTPS) or a local web server. For BLE on Android, Chrome is the practical target. First press **Connect helmet** once to pair with the ESP32; after pairing, voice commands can send commands without typing.

Examples:

- “Samrat, helmet kholo” → `OPEN`
- “Samrat, helmet band karo” → `CLOSE`
- “Samrat, emergency stop” → `STOP`
- “Samrat, system on” → `POWER_ON`
- “Samrat, system off” → `POWER_OFF`
- “Samrat, music chalao” → local audio playback
- “next song” → next locally saved track
- “pause” → pause local audio

### BLE controller contract

The phone sends UTF-8 text to the configured BLE write characteristic:

`OPEN`, `CLOSE`, `STOP`, `POWER_ON`, `POWER_OFF`

The ESP32 firmware should implement the mechanical safety layer: limit switches, obstruction/current sensing, timeouts, watchdog and a physical emergency stop. Do not use software alone to protect the wearer.

The default UUIDs in `phone.html` are common ESP32 UART-style UUIDs. **Change them to the exact UUIDs used by your controller firmware.**

## Offline music

Tap **Add downloaded audio** and select MP3/WAV/etc. The browser stores the files locally in IndexedDB. Playback itself does not need internet.

## Existing Streamlit app

Run:

```bash
pip install -r requirements.txt
streamlit run app.py
```

The Streamlit app continues to provide the full Gemini experience. Voice transcription/TTS there still use Gemini and therefore need internet.

## Important limitation

A phone browser cannot safely bypass Android's power-management/security restrictions to physically switch the entire phone off, and a browser cannot guarantee background microphone listening on every device. The helmet's own electronics should therefore have their own power controller and wake/sleep logic. The phone sends commands to that controller.

For a production helmet, use a dedicated ESP32/other microcontroller, physical controls, limit switches and a fail-safe motor driver. Test the mechanism without a person wearing it first.
