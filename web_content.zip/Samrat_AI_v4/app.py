import base64
import io
import json
import os
import time
import wave
from pathlib import Path
from urllib.parse import quote_plus

import streamlit as st
from google import genai
from google.genai import types

APP_NAME = "Samrat AI v5"
MEMORY_FILE = Path("memory/memory.json")
MEMORY_BACKUP = Path("memory/memory.backup.json")
MAX_MEMORIES = 100
MAX_HISTORY = 20

DEFAULT_MODEL = "gemini-3.8-flash"
DEFAULT_IMAGE_MODEL = "gemini-3.1-flash-image"
DEFAULT_TTS_MODEL = "gemini-3.1-flash-tts-preview"

SYSTEM_PROMPT = """
You are Samrat AI, a personal AI assistant.
Be accurate, helpful, friendly and concise unless the user asks for detail.
Use Hinglish naturally when the user does.
Never invent facts.
When Google Search grounding is enabled, use it for current, changing, or explicitly searched information.
Prefer grounded sources over memory for fresh facts and do not claim that a source was checked unless grounding actually occurred.
Respect saved memory only as context. Never claim to remember something that is not saved.
You are designed for a phone-first assistant today and a future wearable/helmet interface tomorrow.
""".strip()


def load_memory():
    for path in (MEMORY_FILE, MEMORY_BACKUP):
        if not path.exists():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return [str(x).strip() for x in data if str(x).strip()][-MAX_MEMORIES:]
        except Exception:
            continue
    return []


def save_memory(items):
    MEMORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    clean = []
    seen = set()
    for item in items:
        value = str(item).strip()
        key = value.casefold()
        if value and key not in seen:
            seen.add(key)
            clean.append(value)
    clean = clean[-MAX_MEMORIES:]
    payload = json.dumps(clean, ensure_ascii=False, indent=2)

    # Keep a recovery copy and replace the main file atomically.
    if MEMORY_FILE.exists():
        try:
            MEMORY_BACKUP.write_text(MEMORY_FILE.read_text(encoding="utf-8"), encoding="utf-8")
        except Exception:
            pass
    tmp = MEMORY_FILE.with_suffix(".tmp")
    tmp.write_text(payload, encoding="utf-8")
    tmp.replace(MEMORY_FILE)
    return clean


def get_configured_key():
    # User-entered key wins, but it is only kept in the Streamlit session.
    key = st.session_state.get("api_key", "").strip()
    if key:
        return key
    # Optional deployment secret: useful for a privately hosted instance.
    for name in ("GEMINI_API_KEY", "GOOGLE_API_KEY"):
        try:
            value = st.secrets.get(name, "")
        except Exception:
            value = ""
        if value:
            return str(value).strip()
    return os.getenv("GEMINI_API_KEY", "").strip() or os.getenv("GOOGLE_API_KEY", "").strip()


def get_client(api_key):
    key = (api_key or "").strip()
    if not key:
        raise ValueError("Gemini API key is missing.")
    return genai.Client(api_key=key)


def is_key_error(exc):
    text = str(exc).lower()
    return any(x in text for x in (
        "api key", "apikey", "unauthenticated", "permission_denied",
        "permission denied", "invalid argument", "unauthorized", "401", "403"
    ))


def recent_history(history):
    return [
        msg for msg in history[-MAX_HISTORY:]
        if msg.get("role") in ("user", "assistant") and msg.get("content")
    ]


def build_prompt(prompt, history, memory):
    memory_context = ""
    if memory:
        memory_context = "\n\nSaved memory:\n- " + "\n- ".join(memory[-30:])

    conversation = "\n".join(
        f"{msg['role'].upper()}: {msg['content']}" for msg in recent_history(history)
    )
    return (
        SYSTEM_PROMPT
        + memory_context
        + "\n\nRecent conversation:\n"
        + conversation
        + "\n\nUSER'S NEW REQUEST:\n"
        + prompt
    )


def generate_text(client, prompt, history, memory, model, use_search):
    config_kwargs = {"temperature": 0.7}
    if use_search:
        # Gemini decides when Search improves the answer and returns grounding metadata.
        config_kwargs["tools"] = [types.Tool(google_search=types.GoogleSearch())]

    response = client.models.generate_content(
        model=model,
        contents=build_prompt(prompt, history, memory),
        config=types.GenerateContentConfig(**config_kwargs),
    )
    return response


def transcribe_with_gemini(client, audio_bytes, mime_type, model):
    prompt = """
Transcribe this audio exactly.
Keep the spoken language and code-switching (Hindi, English, Hinglish, etc.).
Do not translate, summarize, or add commentary.
Return only the transcription.
""".strip()
    mime = (mime_type or "audio/wav").split(";")[0].strip()
    last_error = None
    for attempt in range(2):
        try:
            response = client.models.generate_content(
                model=model,
                contents=[
                    types.Part.from_bytes(data=audio_bytes, mime_type=mime),
                    prompt,
                ],
                config=types.GenerateContentConfig(temperature=0),
            )
            text = (response.text or "").strip()
            if text:
                return text
            raise RuntimeError("Gemini returned an empty transcription.")
        except Exception as exc:
            last_error = exc
            if attempt == 0:
                time.sleep(0.8)
    raise last_error


def pcm_to_wav_bytes(pcm, sample_rate=24000):
    out = io.BytesIO()
    with wave.open(out, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(pcm)
    return out.getvalue()


def extract_audio_bytes_from_interaction(interaction):
    audio = getattr(interaction, "output_audio", None)
    if not audio:
        return None
    data = getattr(audio, "data", None)
    if not data:
        return None
    if isinstance(data, bytes):
        return data
    try:
        return base64.b64decode(data)
    except Exception:
        return None


def tts_with_gemini(client, text, model, voice):
    # TTS is a separate request so a failed voice response never loses the text answer.
    spoken = (
        "Synthesize only the text between SPOKEN TEXT markers. "
        "Do not read the markers or these instructions aloud. "
        "Speak naturally and clearly; preserve Hindi/Hinglish pronunciation.\n\n"
        "SPOKEN TEXT\n"
        + text
        + "\nEND SPOKEN TEXT"
    )
    last_error = None
    for attempt in range(2):
        try:
            interaction = client.interactions.create(
                model=model,
                input=spoken,
                response_format={"type": "audio"},
                generation_config={"speech_config": [{"voice": voice}]},
            )
            pcm = extract_audio_bytes_from_interaction(interaction)
            if pcm:
                return pcm_to_wav_bytes(pcm, 24000)
            raise RuntimeError("Gemini returned no audio data.")
        except Exception as exc:
            last_error = exc
            if attempt == 0:
                time.sleep(1.0)
    raise last_error


def generate_image(client, prompt, model):
    response = client.models.generate_content(
        model=model,
        contents=prompt,
        config=types.GenerateContentConfig(response_modalities=["IMAGE", "TEXT"]),
    )
    images, text_parts = [], []
    for candidate in response.candidates or []:
        for part in candidate.content.parts or []:
            inline = getattr(part, "inline_data", None)
            if inline and inline.data:
                images.append(inline.data)
            if getattr(part, "text", None):
                text_parts.append(part.text)
    return images, "\n".join(text_parts).strip()


def youtube_search_url(query):
    return "https://www.youtube.com/results?search_query=" + quote_plus(query)


def render_sources(response):
    grounding = getattr(response, "grounding_metadata", None)
    if not grounding:
        return False

    chunks = getattr(grounding, "grounding_chunks", None) or []
    web_items = []
    for chunk in chunks:
        web = getattr(chunk, "web", None)
        if web:
            title = getattr(web, "title", None) or "Google Search source"
            uri = getattr(web, "uri", None)
            if uri:
                web_items.append((title, uri))

    if not web_items:
        return False

    st.subheader("🔎 Google Search sources")
    seen = set()
    for title, uri in web_items:
        if uri in seen:
            continue
        seen.add(uri)
        st.markdown(f"- [{title}]({uri})")
    return True


st.set_page_config(
    page_title=APP_NAME,
    page_icon="🤖",
    layout="centered",
    initial_sidebar_state="collapsed",
)

st.title("🤖 Samrat AI v5")
st.caption("Gemini brain • Search • memory • voice • images • offline phone controls • helmet-ready")

if "messages" not in st.session_state:
    st.session_state.messages = []
if "api_key" not in st.session_state:
    st.session_state.api_key = ""

memory = load_memory()

with st.sidebar:
    st.header("⚙️ Samrat AI")
    configured = get_configured_key()
    if configured and not st.session_state.api_key:
        st.session_state.api_key = configured

    api_key = st.text_input(
        "Gemini API key",
        value=st.session_state.api_key,
        type="password",
        placeholder="Paste Gemini API key",
        help="Your pasted key is kept only in this browser session. For a hosted/private deployment, an administrator can provide GEMINI_API_KEY as a server secret.",
    )
    st.session_state.api_key = api_key.strip()

    if st.session_state.api_key:
        st.success("Gemini key loaded")
        if st.button("🔐 Forget key from this session", use_container_width=True):
            st.session_state.api_key = ""
            st.rerun()
    else:
        st.info("Add your Gemini API key to start.")

    model = st.selectbox("Brain model", [
        "gemini-3.8-flash", "gemini-3.7-flash", "gemini-2.5-flash"
    ], index=0)
    image_model = st.selectbox("Image model", [
        "gemini-3.1-flash-image", "gemini-3-pro-image"
    ], index=0)
    tts_model = st.selectbox("Voice output model", [
        "gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts"
    ], index=0)
    voice = st.selectbox("Voice", ["Kore", "Puck", "Aoede", "Charon", "Fenrir"], index=0)

    st.divider()
    speak = st.checkbox("🔊 Read answers aloud", value=True)
    use_search = st.checkbox("🌐 Google Search grounding", value=True)
    st.caption(f"Saved memories: **{len(memory)}**")

    if st.button("🧹 Clear conversation", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

    if st.button("🗑️ Clear saved memory", use_container_width=True):
        save_memory([])
        st.rerun()

    st.divider()
    st.subheader("🎬 Tools")
    st.caption("Ask naturally for images or YouTube searches. The core flow stays phone-first and can later move to a helmet.")

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("audio"):
            st.audio(msg["audio"], format="audio/wav")

try:
    audio = st.audio_input("🎤 Tap to speak", sample_rate=16000)
except Exception:
    audio = None

prompt = st.chat_input("Ask Samrat AI anything…")

if audio is not None and not prompt:
    api_key = get_configured_key()
    if not api_key:
        st.warning("First add your Gemini API key in ⚙️ settings.")
    else:
        try:
            client = get_client(api_key)
            with st.spinner("🎧 Understanding your voice…"):
                prompt = transcribe_with_gemini(
                    client,
                    audio.getvalue(),
                    getattr(audio, "type", None) or "audio/wav",
                    model,
                )
            if prompt:
                st.info(f"Recognized: {prompt}")
        except Exception as exc:
            st.error("Voice input failed. Please tap the microphone again and speak clearly.")
            if not is_key_error(exc):
                st.caption(str(exc))

if prompt:
    low = prompt.lower().strip()

    if low.startswith("remember that "):
        item = prompt.strip()[14:].strip()
        if item:
            memory = save_memory(memory + [item])
            answer = f"Saved to memory: **{item}**"
            st.session_state.messages.append({"role": "user", "content": prompt})
            st.session_state.messages.append({"role": "assistant", "content": answer})
            st.rerun()

    if low.startswith("forget that "):
        item = prompt.strip()[11:].strip()
        before = len(memory)
        memory = save_memory([x for x in memory if x.casefold() != item.casefold()])
        removed = before - len(memory)
        answer = "Removed from memory." if removed else "I couldn't find that exact memory."
        st.session_state.messages.append({"role": "user", "content": prompt})
        st.session_state.messages.append({"role": "assistant", "content": answer})
        st.rerun()

    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    api_key = get_configured_key()
    if not api_key:
        st.error("Add your Gemini API key in ⚙️ settings first.")
        st.stop()

    try:
        client = get_client(api_key)
        wants_image = any(x in low for x in [
            "generate image", "create image", "make image", "draw image",
            "image banao", "image bana", "picture banao", "photo banao"
        ])
        wants_youtube = any(x in low for x in [
            "youtube", "video search", "video dikhao", "youtube search"
        ])

        with st.chat_message("assistant"):
            if wants_image:
                with st.spinner("🎨 Generating image with Gemini…"):
                    images, image_text = generate_image(client, prompt, image_model)
                answer = image_text or "Image generated."
                st.markdown(answer)
                for data in images:
                    st.image(data, use_container_width=True)
                st.session_state.messages.append({"role": "assistant", "content": answer})

            elif wants_youtube:
                answer = f"Here are YouTube results for: **{prompt}**"
                st.markdown(answer)
                st.markdown(f"[▶️ Open YouTube search]({youtube_search_url(prompt)})")
                st.session_state.messages.append({"role": "assistant", "content": answer})

            else:
                with st.spinner("🧠 Thinking…"):
                    response = generate_text(
                        client, prompt, st.session_state.messages, memory, model, use_search
                    )
                answer = (response.text or "").strip() or "I couldn't generate a text response."
                st.markdown(answer)

                if use_search:
                    if not render_sources(response):
                        st.caption("Google Search was enabled, but this response did not return web sources.")

                audio_bytes = None
                if speak:
                    try:
                        with st.spinner("🔊 Preparing voice…"):
                            audio_bytes = tts_with_gemini(client, answer, tts_model, voice)
                        if audio_bytes:
                            st.audio(audio_bytes, format="audio/wav", autoplay=True)
                    except Exception as exc:
                        st.warning("Voice output could not be generated. The text answer is still available.")
                        if not is_key_error(exc):
                            st.caption(str(exc))

                st.session_state.messages.append({
                    "role": "assistant",
                    "content": answer,
                    "audio": audio_bytes,
                })

    except Exception as exc:
        if is_key_error(exc):
            st.error("Gemini rejected the API key. Check that the key is valid and restricted to the Gemini API.")
        else:
            st.error("Samrat AI could not complete that request. Please try again.")
            st.caption(str(exc))
