# v3 → v4.1 reliability update

## Removed

- Ollama
- llama3.2:3b
- faster-whisper
- pyttsx3
- DuckDuckGo HTML scraping
- Bing image scraping

## Improved

### Gemini API key handling
- User key is kept in the Streamlit session rather than written to the project files.
- Optional server-side `GEMINI_API_KEY` / `GOOGLE_API_KEY` secrets can preload a private deployment without exposing a key in the UI.
- Added a **Forget key from this session** control.
- API-key/auth failures are surfaced as a clear user-facing message instead of a traceback.

### Google Search grounding
- Uses Gemini's native `google_search` tool instead of scraping search-result HTML.
- Keeps grounding enabled as a model tool so Gemini can decide when fresh web retrieval is useful.
- Displays returned grounding sources and explicitly indicates when grounding was enabled but no sources were returned.

### Persistent memory
- Keeps the v3 JSON format compatible.
- Atomic writes reduce corruption risk.
- A backup copy is maintained.
- Duplicate memories are removed.
- Memory is capped at 100 entries.
- Added `forget that ...` for exact memory removal.

### Voice input
- Gemini remains the transcription engine; no local Whisper dependency is added.
- Preserves Hindi/English/Hinglish and avoids automatic translation.
- Uses the uploaded microphone MIME type when available.
- Retries transient transcription failures once.

### Voice output
- Uses Gemini's current Interactions API audio response format.
- Converts Gemini's 24 kHz PCM output into browser-playable WAV.
- Retries transient TTS failures once.
- TTS failures no longer discard the text answer.
- Uses an explicit spoken-text boundary so instruction text is less likely to be read aloud.

## Still phone-first

Normal users do not need to edit Python or install Ollama. They open the app, enter the Gemini API key in Settings, and use text/microphone controls.
