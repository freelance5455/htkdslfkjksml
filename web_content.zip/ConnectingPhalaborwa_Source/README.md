# Connecting Phalaborwa

A phone-friendly Android/iOS community marketplace and local information hub.

## Included in this build — Professional community hub v2.0
- Professional mobile-first interface with simple navigation and large touch targets.
- News and municipal/service-update area.
- Buy & Sell marketplace structure.
- Vendor/business profile workflow.
- Events and ticketing workflow placeholder.
- Rooms and guest-house listings.
- Public transport and ride-request workflow placeholder.
- Speak Out community discussions with moderation guidance.
- Safety/scam awareness.
- Notifications stored locally for prototype use.
- Community member free-access account flow and business/news contributor roles.
- Login/create-account screens with phone/email fields; live OTP delivery is intentionally marked as a production integration.
- Global keyboard search across the app.
- Services & Updates section for municipality/local services, with official-source verification guidance.
- Near Me area-based discovery flow with privacy-first location design.
- “I’m Stuck” community assistance request for fuel, breakdowns, flat tyres and similar non-emergency problems.
- Low Data Mode, 5 MB/day chat allowance display, Wi-Fi-only video preference and cache controls.
- Photo/video picker with previews for vendor, event, accommodation and news submissions.
- Professional settings, accessibility controls, privacy guidance and support/reporting paths.
- Basic profile editing stored locally on the device.
- Subscription plans: Business R20/month and News Contributor R30/month.
- Android WebView file-selection support for future photo uploads.
- Android app theme, launcher icon, versioning and release configuration.
- GitHub Actions workflow for phone-only cloud APK builds.
- Matching iOS bundled web interface.

## Production integrations still required
These cannot be truthfully completed without real accounts, credentials, policies and live infrastructure:
1. Secure user authentication.
2. Cloud database/API.
3. Real-time messaging and push notifications.
4. Moderation/admin dashboard.
5. Verified business/news/accommodation profiles.
6. Secure South African payment gateway and subscription webhooks.
7. Event ticket checkout and refunds.
8. Maps/geocoding/routing.
9. Ride-hailing driver/provider network.
10. WhatsApp/call contact numbers supplied by each verified listing.
11. Privacy policy, terms, consent, reporting and data-retention controls.
12. Signed Android release key and Google Play publishing.
13. Apple Developer account, signing and App Store publishing.

No passwords, private bank details, API secrets or payment credentials should be placed in the app source.
