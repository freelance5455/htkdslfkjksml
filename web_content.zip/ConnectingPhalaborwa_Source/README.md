# Connecting Phalaborwa — Android & iOS project source

This package contains starter source projects for both platforms, with the existing HTML prototype bundled in each.

## Android
Open the `android` folder in Android Studio. Let Gradle sync, then build/run the app. This starter project requires Android Studio and a compatible Android SDK/Gradle installation. A signed APK has not been built by this package.

## iOS
Open `ios/ConnectingPhalaborwa/ConnectingPhalaborwa.xcodeproj` in Xcode on a Mac. Select a development team and run on an iPhone simulator/device. A signed iOS app has not been built by this package.

## Important limitations
This is a UI prototype/starter project, not a production service. Live accounts, cloud database, real push notifications, WhatsApp integrations, maps/routing, ticket checkout, and payment-provider settlement must be implemented and tested before public launch. Payment plans shown in the prototype are not connected to live payments.

## Phone-only Android build
A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. Follow `PHONE_BUILD.md` to trigger a cloud build from your phone and download a debug APK. The workflow has not been executed from this chat, so the APK is not yet built or verified.

## Production status
This remains a prototype. Live payments, accounts/database, push notifications, maps, ticket checkout, moderation, legal pages and signed store releases require further implementation and testing. The iOS project requires an Apple build/signing environment.
