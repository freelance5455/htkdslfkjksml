# Connecting Phalaborwa — phone-only Android build

## Build a test APK using GitHub Actions
1. On your phone, create/sign in to a GitHub account.
2. Create a new repository and upload the contents of this folder (not the ZIP itself). Keep `.github/workflows/build-apk.yml` and the `android` folder at the repository root.
3. Open the repository's **Actions** tab.
4. Choose **Build Connecting Phalaborwa APK** and tap **Run workflow**.
5. Wait for the workflow to complete successfully.
6. Open that run and download the `ConnectingPhalaborwa-debug-apk` artifact.
7. Extract the downloaded artifact and install `app-debug.apk`. Android may ask you to allow installation from that source.

This workflow has been added to the source but has not been run from this chat. If the build fails, open the workflow log and share the error text so it can be fixed.

## Current scope and production work still required
This is a UI prototype packaged in a native WebView shell. The build workflow is for a test/debug APK, not a signed release. Before a professional public launch, add and test: real authentication and database; owner/admin permissions; moderation and reporting; push notifications; working WhatsApp/call links; location/maps; real ticket checkout; payment-provider onboarding and settlement to the owner's merchant account; subscription billing and receipts; privacy policy, terms and POPIA review; secure production signing; accessibility and low-data testing; and iOS signing/building via Xcode on a Mac or a suitable hosted macOS service.

Never put bank passwords, payment secrets, or release signing keys into public source code. This project does not yet collect real payments or deliver genuine push notifications.
