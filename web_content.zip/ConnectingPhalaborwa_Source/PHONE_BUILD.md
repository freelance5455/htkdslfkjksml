# Phone-only build

1. Create/sign in to GitHub on your phone.
2. Create a repository and upload this project's files.
3. Open **Actions**.
4. Select **Build Connecting Phalaborwa APK**.
5. Tap **Run workflow**.
6. When it finishes, open the workflow run and download **ConnectingPhalaborwa-debug-apk**.
7. Extract `app-debug.apk` and install it on your Android phone.

The debug APK is for testing. Public release requires a signed release build and store setup.
