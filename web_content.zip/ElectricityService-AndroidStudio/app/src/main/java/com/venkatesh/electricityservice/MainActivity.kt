package com.venkatesh.electricityservice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.location.LocationListener
import android.os.Looper
import android.net.Uri
import android.os.Bundle
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequestCode = 4102
    private val locationRequestCode = 4103

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.setGeolocationEnabled(true)
        webView.addJavascriptInterface(AndroidGpsBridge(), "AndroidGPS")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(webView: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
                return try { startActivityForResult(intent, fileChooserRequestCode); true } catch (_: Exception) {
                    filePathCallback = null
                    Toast.makeText(this@MainActivity, "ఫైల్ ఎంచుకునే యాప్ అందుబాటులో లేదు", Toast.LENGTH_SHORT).show(); false
                }
            }
            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                val allowed = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                callback?.invoke(origin, allowed, false)
            }
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidGpsBridge {
        @JavascriptInterface fun getLocation(): String {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread { requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), locationRequestCode) }
                return "PERMISSION_REQUIRED"
            }
            return try {
                val lm = getSystemService(LOCATION_SERVICE) as LocationManager
                val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                var best: Location? = null
                for (provider in providers) {
                    val loc = try { lm.getLastKnownLocation(provider) } catch (_: SecurityException) { null }
                    if (loc != null && (best == null || loc.time > best!!.time)) best = loc
                }
                if (best != null) "${best!!.latitude},${best!!.longitude}" else {
                    val listener = object : LocationListener {
                        override fun onLocationChanged(location: Location) {
                            val coords = "${location.latitude},${location.longitude}"
                            runOnUiThread { webView.evaluateJavascript("gps='" + coords + "'; if(document.getElementById('gpsText')) document.getElementById('gpsText').textContent='📍 '+gps; if(document.getElementById('egpsText')) document.getElementById('egpsText').textContent='📍 '+gps;", null) }
                            try { lm.removeUpdates(this) } catch (_: Exception) {}
                        }
                    }
                    try { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper()) } catch (_: Exception) {
                        try { lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper()) } catch (_: Exception) {}
                    }
                    "UNAVAILABLE"
                }
            } catch (_: Exception) { "UNAVAILABLE" }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationRequestCode) Toast.makeText(this, if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) "Location permission ఇచ్చారు. GPS బటన్ మళ్లీ నొక్కండి." else "Location permission అవసరం", Toast.LENGTH_LONG).show()
    }

    @Deprecated("Deprecated by Android; required for WebView file selection on older versions")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileChooserRequestCode) {
            val callback = filePathCallback ?: return
            val result = if (resultCode == RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            callback.onReceiveValue(result); filePathCallback = null
        }
    }
    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() { if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed() }
}
