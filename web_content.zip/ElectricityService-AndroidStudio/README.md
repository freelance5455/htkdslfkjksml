# Electricity Service — Android Studio project

This is an Android Studio project (Kotlin + WebView) for the Electricity Service HTML app.

- **App name:** Electricity Service
- **Application ID:** `com.venkatesh.electricityservice`
- **Minimum Android:** Android 6.0 (API 23)
- **Compile SDK:** 35
- **Main app page:** `app/src/main/assets/index.html`
- **Excel-import conversion:** `data-import/MACHAVARAM-LT4-compatible-upload.csv` (418 rows, for importing from inside the app under Reports → Upload)

## Open it in Android Studio

1. Extract the entire ZIP to a folder on your computer. Do not open the ZIP as if it were a project.
2. Open Android Studio → **Open** → select the extracted `ElectricityService-AndroidStudio` folder (the folder containing `settings.gradle`).
3. Allow Android Studio to sync/download the Android Gradle Plugin and dependencies. Use JDK 17 if Android Studio asks.
4. Install Android SDK Platform 35 from SDK Manager if prompted.
5. To build an installable debug APK, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. The APK is normally written to `app/build/outputs/apk/debug/app-debug.apk`.

## Import the supplied service list

Run the app first. In the app, open **Reports → Upload**, select the included CSV file (copy it to the phone first, or choose it from your computer/device), then tap **Import CSV**. Existing service numbers are skipped to avoid duplicates.

## Important notes

- This ZIP is source code, **not an APK**. It must be built in Android Studio.
- The HTML app stores its records in local browser storage on the device. It is not connected to official electricity-board servers.
- The included CSV is a conversion of the uploaded Excel workbook. It has 418 unique service records; blank source fields remain blank.
- The project has been assembled for Android Studio, but it has not been compiled or run on a physical Android device in this environment. Confirm Gradle sync/build succeeds in Android Studio before distributing the APK.
- GPS access depends on Android location permissions and WebView support; it may need additional permission handling before production use.
