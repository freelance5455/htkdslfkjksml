# Electricity Service — Updated Android project

ఈ ప్రాజెక్టులో:
- హోమ్ స్క్రీన్‌లో LT-I, LT-II, LT-III, LT-IV మరియు మొత్తం సర్వీసుల లెక్కలు
- 418 Machavaram LT-IV Excel రికార్డులు మొదటినుంచే లోడ్ అవుతాయి (మొత్తం 418 rows; కొత్త డేటా localStorageలో సేవ్ అవుతుంది)
- Reports‌లో Excel (.xlsx/.xls) మరియు CSV బల్క్ ఇంపోర్ట్; ఇప్పటికే ఉన్న Service Numberలు డూప్లికేట్ కాకుండా స్కిప్ అవుతాయి
- ప్రతి సర్వీస్ ఎడిట్ చేయడం, డిలీట్ చేయడం
- గ్రామం/కోడ్ ఆటో గుర్తింపు, Telugu/English settings, ఫోటో అటాచ్ చేయడం
- Android GPS permission మరియు WebView GPS bridge
- గ్రామపంచాయతీ/పంచాయితీ ప్రెసిడెంట్‌గా గుర్తించిన రికార్డులకు ఎరుపు గుర్తు

## ముఖ్య గమనికలు
- Excel (.xlsx/.xls) చదవడానికి SheetJS లైబ్రరీ CDN నుంచి లోడ్ అవుతుంది; అందుకు ఇంటర్నెట్ అవసరం. CSV దిగుమతి మాత్రం ఆఫ్‌లైన్‌లోనూ పనిచేయాలి.
- APK binary ఇక్కడ build చేయబడలేదు. ఈ source project ను GitHubలో పెట్టి `.github/workflows/android-apk.yml` workflow ద్వారా APK build చేయవచ్చు.
- Android Studioలో open చేసి Gradle sync చేయండి. Android location permission అడిగినప్పుడు Allow చేయాలి; GPS బటన్‌ను మళ్లీ నొక్కాలి.
