# CPLS Stage 1169 — Mainnet Lock Enforcement

- Active network: Ethereum Sepolia only.
- Chain ID: 11155111 (`0xAA36A7`).
- Mainnet Chain ID 1 is explicitly locked.
- `MAINNET_ENABLED` is a compile-time source constant set to `false`.
- Runtime network override is not exposed.
- `isSepoliaOnlyChain()` is the centralized chain-policy gate.
- `getMainnetLockState()` exposes only safe policy metadata.
- WebView receives no private key, seed, signing capability, or broadcast capability.
- This stage does not claim a live Sepolia connection or deployment.
- Releasing real mainnet functionality requires a separate security/compliance review and an intentional production build.
