# Carreira de Craque v1.53.15 — Correção de armazenamento e resultados

- O campeonato Sub-20 deixa de gravar cópias globais duplicadas dos mesmos dados em duas chaves legadas; a chave por carreira é a fonte principal.
- Escritas da tabela Sub-20 passam a tratar quota cheia sem interromper a abertura da tela.
- O salvamento da carreira tenta novamente após liberar somente as duas cópias globais redundantes do Sub-20; não apaga slots de carreira, histórico nem a chave de dados Sub-20 por carreira.
- Mensagem de erro mais explícita se o salvamento principal continuar impossível.
- Mantida a recuperação da partida salva no intervalo/segundo tempo e associação do resultado à rodada correta.
