SUMIT MOBILE SERVICE - Android App Project
==========================================

इस प्रोजेक्ट में वेबसाइट का वही index.html Android ऐप के अंदर WebView के जरिए खुलता है। ऐप का UI वेबसाइट जैसा रहेगा और WhatsApp/Google Maps जैसे बाहरी लिंक फोन में खुलेंगे।

महत्वपूर्ण:
- यह Android Studio/AndroidIDE में build करने योग्य source project है, तैयार APK नहीं।
- यहाँ APK compile/sign नहीं की गई है।
- वेबसाइट में मौजूद demo prices वास्तविक supplier quotes नहीं हैं।
- Demo price editor केवल इसी डिवाइस के browser/local storage में सेव होता है; यह online admin panel नहीं है।
- असली cloud admin panel और booking database अलग से बनाना होगा।

Android मोबाइल पर build करने का तरीका:
1. इस ZIP को डाउनलोड करके Extract करें।
2. AndroidIDE जैसे Android Gradle project support करने वाले IDE में project folder खोलें।
3. Gradle sync होने दें और app module चुनें।
4. Build > Assemble Debug APK (या IDE के equivalent Build APK विकल्प) चलाएँ।
5. APK आम तौर पर app/build/outputs/apk/debug/app-debug.apk में बनेगी।
6. APK केवल अपने फोन/टेस्टिंग डिवाइस पर इंस्टॉल करके जाँचें। अनजान साइट से build tools डाउनलोड न करें।

Google Play Store के लिए:
- app ID com.sumitmobileservice.app अभी default है; प्रकाशित करने से पहले इसे स्थायी unique application ID में बदलना चाहिए।
- Play Store के लिए signed Android App Bundle (AAB), store listing, privacy policy, testing और Google Play की वर्तमान requirements पूरी करनी होंगी।
- ऐप प्रकाशित होने की गारंटी नहीं है; Google review करेगा।

Project files:
- app/src/main/assets/index.html : वेबसाइट
- app/src/main/java/com/sumitmobileservice/app/MainActivity.java : WebView wrapper
- app/src/main/AndroidManifest.xml : app settings
