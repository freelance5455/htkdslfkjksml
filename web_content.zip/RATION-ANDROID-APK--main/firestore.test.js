const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ADMIN_UID = "admin_uid_1";
const USER_UID = "villager_uid_1";
const OTHER_UID = "villager_uid_2";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read schedules, banners, settings, or users", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("ration_schedules").where("isPublic", "==", true).get());
  await assertFails(unauthDb.collection("urgent_banners").where("isPublic", "==", true).get());
  await assertFails(unauthDb.collection("app_settings").doc("payment").get());
  await assertFails(unauthDb.collection("users").doc(USER_UID).get());
});

test("Authenticated non-admin user can read public schedules and payment settings but cannot write/delete them", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("ration_schedules").doc("sched_1").set({
      dayLabel: "আজ",
      dateLabel: "১৪ নভেম্বর, ২০২৬",
      location: "সীতানগর মোড়",
      address: "প্রধান সড়ক",
      statusText: "চলছে",
      statusTone: "EMERALD",
      sortOrder: 0,
      isPublic: true,
      createdBy: ADMIN_UID,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    await db.collection("app_settings").doc("payment").set({
      upiId: "ration@upi",
      isPublic: true,
      updatedBy: ADMIN_UID,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  });

  const userDb = testEnv.authenticatedContext(USER_UID, { email: "villager@gmail.com", email_verified: true }).firestore();
  await assertSucceeds(userDb.collection("ration_schedules").where("isPublic", "==", true).get());
  await assertSucceeds(userDb.collection("app_settings").doc("payment").get());

  // Cannot query without isPublic == true filter
  await assertFails(userDb.collection("ration_schedules").get());

  // Non-admin cannot create, update, or delete schedules, banners, or UPI payment settings
  await assertFails(userDb.collection("ration_schedules").doc("sched_1").delete());
  await assertFails(userDb.collection("app_settings").doc("payment").set({
    upiId: "attacker@upi",
    isPublic: true,
    updatedBy: USER_UID,
    createdAt: new Date(),
    updatedAt: new Date(),
  }));
});

test("Spoofed unverified admin email is rejected", async () => {
  const spoofDb = testEnv.authenticatedContext("spoof_uid", {
    email: "onlinekutir@gmail.com",
    email_verified: false,
  }).firestore();

  await assertFails(spoofDb.collection("app_settings").doc("payment").set({
    upiId: "spoof@upi",
    isPublic: true,
    updatedBy: "spoof_uid",
    createdAt: new Date(),
    updatedAt: new Date(),
  }));
});

test("Verified admin can create/delete schedules, banners, and update payment UPI ID", async () => {
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "onlinekutir@gmail.com",
    email_verified: true,
  }).firestore();

  await assertSucceeds(adminDb.collection("ration_schedules").doc("sched_admin_1").set({
    dayLabel: "মঙ্গলবার",
    dateLabel: "১৭ নভেম্বর, ২০২৬",
    location: "রক্সীমোড়",
    address: "বাজার সংলগ্ন",
    statusText: "চলছে",
    statusTone: "EMERALD",
    sortOrder: 0,
    isPublic: true,
    createdBy: ADMIN_UID,
    createdAt: new Date(),
    updatedAt: new Date(),
  }));
  await assertSucceeds(adminDb.collection("ration_schedules").doc("sched_admin_1").delete());

  await assertSucceeds(adminDb.collection("urgent_banners").doc("banner_1").set({
    bannerNumber: 1,
    isVisible: true,
    dateBadge: "আজ",
    headline: "জরুরি বিজ্ঞপ্তি",
    description: "বিস্তারিত",
    isPublic: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  }));
  await assertSucceeds(adminDb.collection("urgent_banners").doc("banner_1").delete());

  await assertSucceeds(adminDb.collection("app_settings").doc("payment").set({
    upiId: "admin@okaxis",
    isPublic: true,
    updatedBy: ADMIN_UID,
    createdAt: new Date(),
    updatedAt: new Date(),
  }));

  // Shadow update with ghost field rejected
  await assertFails(adminDb.collection("app_settings").doc("payment").set({
    upiId: "admin@okaxis",
    isPublic: true,
    updatedBy: ADMIN_UID,
    ghostField: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  }));
});

test("Users can only read/write their own user document (PII isolation)", async () => {
  const userDb = testEnv.authenticatedContext(USER_UID, { email: "u1@test.com", email_verified: true }).firestore();
  const otherDb = testEnv.authenticatedContext(OTHER_UID, { email: "u2@test.com", email_verified: true }).firestore();

  await assertSucceeds(userDb.collection("users").doc(USER_UID).set({
    userId: USER_UID,
    email: "u1@test.com",
    phoneNumber: "9876543210",
    isSubscribed: false,
    isTrialExpired: false,
    createdAt: new Date(),
    updatedAt: new Date(),
  }));

  await assertFails(otherDb.collection("users").doc(USER_UID).get());
  await assertFails(otherDb.collection("users").doc(USER_UID).set({
    userId: USER_UID,
    email: "u2@test.com",
    phoneNumber: "1111111111",
    isSubscribed: true,
    isTrialExpired: false,
    createdAt: new Date(),
    updatedAt: new Date(),
  }));
});
