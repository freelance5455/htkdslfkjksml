package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FirestoreRationRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun ensureUserAccount_and_updateSubscription_succeedsForOwner() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = FirestoreRationRepository(firestore, auth)

        val createResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.ensureUserAccount(ALICE_EMAIL, "9876543210")
        }
        assertTrue(createResult.isSuccess)

        val subResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.updateUserSubscription(true)
        }
        assertTrue(subResult.isSuccess)

        val account = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeUserAccount(uid).first { it != null && it.isSubscribed }
        }
        assertNotNull(account)
        assertEquals(uid, account?.userId)
        assertTrue(account?.isSubscribed == true)
    }

    @Test
    fun observeSchedules_authenticatedUser_returnsList() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val repository = FirestoreRationRepository(firestore, auth)

        val schedules = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeSchedules().first()
        }
        assertNotNull(schedules)
    }

    @Test
    fun savePaymentUpiId_and_deleteSchedule_nonAdminRejectedWithPermissionDenied() = runBlocking {
        signInTestUser(ALICE_EMAIL)
        val repository = FirestoreRationRepository(firestore, auth)

        val upiResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.savePaymentUpiId("attacker@upi")
        }
        assertTrue(upiResult.isFailure)
        val upiEx = upiResult.exceptionOrNull()?.unwrapFirestoreException()
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, upiEx?.code)

        val deleteResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.deleteSchedule("sched_nonexistent")
        }
        assertTrue(deleteResult.isFailure)
        val delEx = deleteResult.exceptionOrNull()?.unwrapFirestoreException()
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, delEx?.code)
    }

    @Test
    fun crossUserAccountRead_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = FirestoreRationRepository(firestore, auth)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.ensureUserAccount(ALICE_EMAIL, "9876543210").getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        var captured: FirebaseFirestoreException? = null
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("users").document(aliceUid).get().await()
            }
        } catch (e: Exception) {
            captured = e.unwrapFirestoreException()
        }
        assertNotNull(captured)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, captured?.code)
    }

    @Test
    fun observeSchedules_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = FirestoreRationRepository(firestore, auth)

        var captured: FirebaseFirestoreException? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeSchedules().first()
            }
        } catch (e: Exception) {
            captured = e.unwrapFirestoreException()
        }
        assertNotNull(captured)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, captured?.code)
    }

    @Test
    fun phoneOnlyUserAccount_createsProfileWithEmptyEmail_andRejectsAdminWrite() = runBlocking {
        val uid = signInTestUser(PHONE_TEST_EMAIL)
        val repository = FirestoreRationRepository(firestore, auth)

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.ensureUserAccount("", "+919876543210")
        }
        assertTrue(result.isSuccess)

        val account = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeUserAccount(uid).first { it != null && it.phoneNumber == "+919876543210" }
        }
        assertEquals("+919876543210", account?.phoneNumber)
        assertEquals("", account?.email)
        assertEquals(false, repository.isAdminAccount(uid, ""))
    }

    private companion object {
        const val ALICE_EMAIL = "alice_ration@test.com"
        const val BOB_EMAIL = "bob_ration@test.com"
        const val PHONE_TEST_EMAIL = "phone_user_ration@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
