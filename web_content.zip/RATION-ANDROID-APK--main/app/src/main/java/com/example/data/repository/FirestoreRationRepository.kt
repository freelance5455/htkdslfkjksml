package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.local.NewsCategoryTone
import com.example.data.local.StatusTone
import com.example.data.remote.NotificationDoc
import com.example.data.remote.OperationType
import com.example.data.remote.PaymentSettingsDoc
import com.example.data.remote.RationScheduleDoc
import com.example.data.remote.UrgentBannerDoc
import com.example.data.remote.UserAccountDoc
import com.example.data.remote.VillageNewsDoc
import com.example.data.remote.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class FirestoreRationRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        auth = Firebase.auth
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in before accessing Firestore.")
    }

    suspend fun isAdminAccount(uid: String, email: String): Boolean {
        if (email.equals("onlinekutir@gmail.com", ignoreCase = true)) return true
        return try {
            db.collection("admins").document(uid).get().await().exists()
        } catch (_: Exception) {
            false
        }
    }

    fun observeSchedules(): Flow<List<RationScheduleDoc>> =
        db.collection(COLLECTION_SCHEDULES)
            .whereEqualTo("isPublic", true)
            .snapshots()
            .map { snap ->
                snap.toObjects(RationScheduleDoc::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedWith(
                        compareBy<RationScheduleDoc> { it.sortOrder }
                            .thenBy { it.createdAt ?: Timestamp(0, 0) }
                    )
            }
            .catch { error ->
                logStreamError(error, OperationType.LIST, COLLECTION_SCHEDULES)
                throw error
            }

    fun observeUrgentBanners(): Flow<List<UrgentBannerDoc>> =
        db.collection(COLLECTION_BANNERS)
            .whereEqualTo("isPublic", true)
            .snapshots()
            .map { snap ->
                snap.toObjects(UrgentBannerDoc::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.bannerNumber }
            }
            .catch { error ->
                logStreamError(error, OperationType.LIST, COLLECTION_BANNERS)
                throw error
            }

    fun observeVillageNews(): Flow<List<VillageNewsDoc>> =
        db.collection(COLLECTION_NEWS)
            .whereEqualTo("isPublic", true)
            .snapshots()
            .map { snap ->
                snap.toObjects(VillageNewsDoc::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                logStreamError(error, OperationType.LIST, COLLECTION_NEWS)
                throw error
            }

    fun observeNotifications(): Flow<List<NotificationDoc>> =
        db.collection(COLLECTION_NOTIFICATIONS)
            .whereEqualTo("isPublic", true)
            .snapshots()
            .map { snap ->
                snap.toObjects(NotificationDoc::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                    .take(30)
            }
            .catch { error ->
                logStreamError(error, OperationType.LIST, COLLECTION_NOTIFICATIONS)
                throw error
            }

    fun observePaymentSettings(): Flow<PaymentSettingsDoc?> =
        db.collection(COLLECTION_SETTINGS)
            .document(DOC_PAYMENT)
            .snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(PaymentSettingsDoc::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            }
            .catch { error ->
                logStreamError(error, OperationType.GET, "$COLLECTION_SETTINGS/$DOC_PAYMENT")
                throw error
            }

    fun observeUserAccount(userId: String): Flow<UserAccountDoc?> =
        db.collection(COLLECTION_USERS)
            .document(userId)
            .snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(UserAccountDoc::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            }
            .catch { error ->
                logStreamError(error, OperationType.GET, "$COLLECTION_USERS/$userId")
                throw error
            }

    suspend fun ensureUserAccount(email: String, phoneNumber: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection(COLLECTION_USERS).document(uid)
        val snap = docRef.get().await()
        if (!snap.exists()) {
            val payload = mapOf(
                "userId" to uid,
                "email" to email,
                "phoneNumber" to phoneNumber,
                "isSubscribed" to false,
                "isTrialExpired" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
        } else if (phoneNumber.isNotBlank()) {
            docRef.update(
                mapOf(
                    "phoneNumber" to phoneNumber,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.WRITE, "$COLLECTION_USERS/${auth.currentUser?.uid}", auth)
    }

    suspend fun updateUserSubscription(subscribed: Boolean): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection(COLLECTION_USERS).document(uid)
        val snap = docRef.get().await()
        if (!snap.exists()) {
            val payload = mapOf(
                "userId" to uid,
                "email" to (auth.currentUser?.email ?: ""),
                "phoneNumber" to "",
                "isSubscribed" to subscribed,
                "isTrialExpired" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
        } else {
            docRef.update(
                mapOf(
                    "isSubscribed" to subscribed,
                    "isTrialExpired" to false,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "$COLLECTION_USERS/${auth.currentUser?.uid}", auth)
    }

    suspend fun updateUserTrialExpired(expired: Boolean): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection(COLLECTION_USERS).document(uid)
        val snap = docRef.get().await()
        if (!snap.exists()) {
            val payload = mapOf(
                "userId" to uid,
                "email" to (auth.currentUser?.email ?: ""),
                "phoneNumber" to "",
                "isSubscribed" to false,
                "isTrialExpired" to expired,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
        } else {
            docRef.update(
                mapOf(
                    "isTrialExpired" to expired,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.UPDATE, "$COLLECTION_USERS/${auth.currentUser?.uid}", auth)
    }

    suspend fun savePaymentUpiId(upiId: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection(COLLECTION_SETTINGS).document(DOC_PAYMENT)
        val snap = docRef.get().await()
        if (!snap.exists()) {
            val payload = mapOf(
                "upiId" to upiId.trim(),
                "isPublic" to true,
                "updatedBy" to uid,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
        } else {
            docRef.update(
                mapOf(
                    "upiId" to upiId.trim(),
                    "updatedBy" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.WRITE, "$COLLECTION_SETTINGS/$DOC_PAYMENT", auth)
    }

    suspend fun upsertPrimarySchedule(
        existingId: String?,
        statusText: String,
        statusTone: StatusTone,
        location: String,
        dateLabel: String,
        address: String
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val targetId = if (!existingId.isNullOrBlank()) existingId else db.collection(COLLECTION_SCHEDULES).document().id
        val docRef = db.collection(COLLECTION_SCHEDULES).document(targetId)
        val snap = if (!existingId.isNullOrBlank()) docRef.get().await() else null

        if (snap != null && snap.exists()) {
            docRef.update(
                mapOf(
                    "statusText" to statusText.trim(),
                    "statusTone" to statusTone.name,
                    "location" to location.trim(),
                    "dateLabel" to dateLabel.trim(),
                    "address" to address.trim(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } else {
            val payload = mapOf(
                "dayLabel" to "আজ",
                "dateLabel" to dateLabel.trim(),
                "location" to location.trim(),
                "address" to address.trim(),
                "statusText" to statusText.trim(),
                "statusTone" to statusTone.name,
                "sortOrder" to 0L,
                "isPublic" to true,
                "createdBy" to uid,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
        }
        publishNotification("রেশন ব্যানার লাইভ আপডেট!", "$location — $statusText")
        targetId
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.WRITE, COLLECTION_SCHEDULES, auth)
    }

    suspend fun addNewSchedule(
        dayLabel: String,
        dateLabel: String,
        location: String,
        address: String,
        statusText: String,
        statusTone: StatusTone = StatusTone.BLUE
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection(COLLECTION_SCHEDULES).document()
        val payload = mapOf(
            "dayLabel" to dayLabel.trim(),
            "dateLabel" to dateLabel.trim().ifBlank { "নভেম্বর, ২০২৬" },
            "location" to location.trim(),
            "address" to address.trim().ifBlank { "নতুন রেশন পয়েন্ট" },
            "statusText" to statusText.trim().ifBlank { "আসছে" },
            "statusTone" to statusTone.name,
            "sortOrder" to 10L,
            "isPublic" to true,
            "createdBy" to uid,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        docRef.set(payload).await()
        publishNotification("নতুন রেশন আপডেট", "${location.trim()} এ নতুন রেশনের তারিখ যোগ করা হয়েছে।")
        docRef.id
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.CREATE, COLLECTION_SCHEDULES, auth)
    }

    suspend fun deleteSchedule(scheduleId: String): Result<Unit> = runCatching {
        requireUserId()
        require(scheduleId.isNotBlank()) { "Schedule ID cannot be blank" }
        db.collection(COLLECTION_SCHEDULES).document(scheduleId).delete().await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.DELETE, "$COLLECTION_SCHEDULES/$scheduleId", auth)
    }

    suspend fun upsertUrgentBanner(
        bannerNumber: Int,
        isVisible: Boolean,
        dateBadge: String,
        headline: String,
        description: String,
        notifyUsers: Boolean
    ): Result<Unit> = runCatching {
        requireUserId()
        val docId = bannerDocId(bannerNumber)
        val docRef = db.collection(COLLECTION_BANNERS).document(docId)
        val snap = docRef.get().await()
        if (snap.exists()) {
            docRef.update(
                mapOf(
                    "isVisible" to isVisible,
                    "dateBadge" to dateBadge.trim(),
                    "headline" to headline.trim(),
                    "description" to description.trim(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } else {
            val payload = mapOf(
                "bannerNumber" to bannerNumber.toLong(),
                "isVisible" to isVisible,
                "dateBadge" to dateBadge.trim(),
                "headline" to headline.trim(),
                "description" to description.trim(),
                "isPublic" to true,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
        }
        if (notifyUsers && headline.isNotBlank()) {
            publishNotification("বিজ্ঞপ্তি ব্যানার $bannerNumber আপডেট", headline.trim())
        }
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.WRITE, "$COLLECTION_BANNERS/${bannerDocId(bannerNumber)}", auth)
    }

    suspend fun deleteUrgentBanner(bannerNumber: Int): Result<Unit> = runCatching {
        requireUserId()
        val docId = bannerDocId(bannerNumber)
        db.collection(COLLECTION_BANNERS).document(docId).delete().await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.DELETE, "$COLLECTION_BANNERS/${bannerDocId(bannerNumber)}", auth)
    }

    suspend fun addVillageNews(
        category: String,
        tone: NewsCategoryTone,
        dateLabel: String,
        title: String,
        description: String
    ): Result<String> = runCatching {
        requireUserId()
        val docRef = db.collection(COLLECTION_NEWS).document()
        val payload = mapOf(
            "category" to category.trim(),
            "categoryTone" to tone.name,
            "dateLabel" to dateLabel.trim(),
            "title" to title.trim(),
            "description" to description.trim(),
            "isPublic" to true,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        docRef.set(payload).await()
        publishNotification("নতুন গ্রামের খবর", title.trim())
        docRef.id
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.CREATE, COLLECTION_NEWS, auth)
    }

    suspend fun deleteVillageNews(newsId: String): Result<Unit> = runCatching {
        requireUserId()
        db.collection(COLLECTION_NEWS).document(newsId).delete().await()
        Unit
    }.onFailure { e ->
        if (e is CancellationException) throw e
        handleFirestoreError(e, OperationType.DELETE, "$COLLECTION_NEWS/$newsId", auth)
    }

    private suspend fun publishNotification(title: String, message: String) {
        val docRef = db.collection(COLLECTION_NOTIFICATIONS).document()
        val payload = mapOf(
            "title" to title,
            "message" to message,
            "timeLabel" to "এইমাত্র",
            "isPublic" to true,
            "createdAt" to FieldValue.serverTimestamp()
        )
        docRef.set(payload).await()
    }

    private fun logStreamError(error: Throwable, operationType: OperationType, path: String) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val exceptionToLog = firestoreError ?: (error as? Exception) ?: return
        if (auth.currentUser != null) {
            handleFirestoreError(exceptionToLog, operationType, path, auth)
        }
    }

    companion object {
        const val COLLECTION_USERS = "users"
        const val COLLECTION_SCHEDULES = "ration_schedules"
        const val COLLECTION_BANNERS = "urgent_banners"
        const val COLLECTION_NEWS = "village_news"
        const val COLLECTION_NOTIFICATIONS = "notifications"
        const val COLLECTION_SETTINGS = "app_settings"
        const val DOC_PAYMENT = "payment"

        fun bannerDocId(bannerNumber: Int): String = "banner_$bannerNumber"
    }
}
