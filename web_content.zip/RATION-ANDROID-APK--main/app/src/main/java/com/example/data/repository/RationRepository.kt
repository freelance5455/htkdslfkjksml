package com.example.data.repository

import com.example.data.local.NewsCategoryTone
import com.example.data.local.NotificationItemEntity
import com.example.data.local.RationDao
import com.example.data.local.RationScheduleEntity
import com.example.data.local.StatusTone
import com.example.data.local.UrgentBannerEntity
import com.example.data.local.UserPreferencesDataStore
import com.example.data.local.UserPrefs
import com.example.data.local.VillageNewsEntity
import kotlinx.coroutines.flow.Flow

class RationRepository(
    private val dao: RationDao,
    private val prefsDataStore: UserPreferencesDataStore
) {
    val schedules: Flow<List<RationScheduleEntity>> = dao.observeSchedules()
    val urgentBanners: Flow<List<UrgentBannerEntity>> = dao.observeUrgentBanners()
    val villageNews: Flow<List<VillageNewsEntity>> = dao.observeVillageNews()
    val notifications: Flow<List<NotificationItemEntity>> = dao.observeNotifications()
    val userPrefs: Flow<UserPrefs> = prefsDataStore.userPrefs

    suspend fun login(phone: String) {
        prefsDataStore.setLoggedIn(phone)
    }

    suspend fun logout() {
        prefsDataStore.logout()
    }

    suspend fun unlockSubscription() {
        prefsDataStore.setSubscribed(true)
        dao.insertNotification(
            NotificationItemEntity(
                title = "সাবস্ক্রিপশন সক্রিয় হয়েছে",
                message = "₹১০ মাসিক কমিউনিটি প্যাক চালু হয়েছে। রেশন ও গ্রামের সকল জরুরি আপডেট এখন পাবেন।",
                timeLabel = "এইমাত্র"
            )
        )
    }

    suspend fun setTrialExpiredSimulation(expired: Boolean) {
        prefsDataStore.setTrialExpired(expired)
    }

    suspend fun saveUpiId(upiId: String) {
        prefsDataStore.setUpiId(upiId)
    }

    suspend fun updatePrimaryRationBanner(
        statusText: String,
        statusTone: StatusTone,
        location: String,
        dateLabel: String,
        address: String
    ) {
        val current = dao.getPrimarySchedule()
        if (current != null) {
            dao.updateSchedule(
                current.copy(
                    statusText = statusText,
                    statusTone = statusTone.name,
                    location = location,
                    dateLabel = dateLabel,
                    address = address
                )
            )
        } else {
            dao.insertSchedule(
                RationScheduleEntity(
                    dayLabel = "আজ (শনিবার)",
                    dateLabel = dateLabel,
                    location = location,
                    address = address,
                    statusText = statusText,
                    statusTone = statusTone.name,
                    sortOrder = 0
                )
            )
        }
        dao.insertNotification(
            NotificationItemEntity(
                title = "রেশন ব্যানার লাইভ আপডেট!",
                message = "$location — $statusText",
                timeLabel = "এইমাত্র"
            )
        )
    }

    suspend fun addNewSchedule(
        dayLabel: String,
        location: String,
        timeRange: String
    ) {
        dao.insertSchedule(
            RationScheduleEntity(
                dayLabel = dayLabel,
                dateLabel = "নভেম্বর ২০২৬",
                location = location,
                address = "নতুন রেশন পয়েন্ট",
                statusText = if (timeRange.isNotBlank()) "আসছে ($timeRange)" else "আসছে",
                statusTone = StatusTone.BLUE.name,
                sortOrder = 10
            )
        )
        dao.insertNotification(
            NotificationItemEntity(
                title = "নতুন রেশন আপডেট",
                message = "$location এ নতুন রেশনের তারিখ যোগ করা হয়েছে।",
                timeLabel = "এইমাত্র"
            )
        )
    }

    suspend fun deleteSchedule(id: Int) {
        dao.deleteSchedule(id)
    }

    suspend fun updateUrgentBanner(banner: UrgentBannerEntity, notifyUsers: Boolean) {
        dao.upsertUrgentBanner(banner)
        if (notifyUsers) {
            dao.insertNotification(
                NotificationItemEntity(
                    title = if (banner.id == 1) "বিজ্ঞপ্তি ব্যানার ১ আপডেট" else "বিজ্ঞপ্তি ব্যানার ২ আপডেট",
                    message = banner.headline,
                    timeLabel = "এইমাত্র"
                )
            )
        }
    }

    suspend fun addVillageNews(
        category: String,
        tone: NewsCategoryTone,
        dateLabel: String,
        title: String,
        description: String
    ) {
        dao.insertNews(
            VillageNewsEntity(
                category = category,
                categoryTone = tone.name,
                dateLabel = dateLabel,
                title = title,
                description = description
            )
        )
        dao.insertNotification(
            NotificationItemEntity(
                title = "নতুন গ্রামের খবর",
                message = title,
                timeLabel = "এইমাত্র"
            )
        )
    }
}
