package com.example.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.Amber400
import com.example.ui.theme.Emerald500
import com.example.ui.theme.PureWhite
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate300
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950

@Composable
fun SubscriptionScreen(
    upiId: String,
    isSubscribed: Boolean,
    onPayClick: () -> Unit,
    onCopiedToast: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    @Suppress("DEPRECATION")
    val clipboardManager = LocalClipboardManager.current

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Subscription Pack Card linked directly to Admin's UPI ID
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(26.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Slate900, Slate800)
                        )
                    )
                    .padding(20.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.VerifiedUser,
                    contentDescription = null,
                    tint = PureWhite.copy(alpha = 0.08f),
                    modifier = Modifier
                        .size(148.dp)
                        .align(Alignment.TopEnd)
                        .offset(x = 24.dp, y = (-20).dp)
                )

                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Surface(
                        color = if (isSubscribed) Emerald500 else Amber400,
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = if (isSubscribed) "সাবস্ক্রিপশন চালু আছে" else "মাসিক কমিউনিটি প্যাক",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (isSubscribed) PureWhite else Slate950,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Text(
                        text = "মাত্র ১০ টাকা / মাস",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                        color = PureWhite
                    )

                    Text(
                        text = "রেশনের সঠিক তারিখ, গ্রামের জরুরি খবর এবং গুরুত্বপূর্ণ এসএমএস ও পুশ নোটিফিকেশন সরাসরি আপনার মোবাইলে পেতে আজই সাবস্ক্রিপশন চালু করুন।",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate300
                    )

                    // Official Admin-linked UPI Box
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(PureWhite.copy(alpha = 0.1f))
                            .border(1.dp, PureWhite.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "অ্যাডমিনের অফিশিয়াল ইউপিআই (UPI) আইডি:",
                                style = MaterialTheme.typography.labelSmall,
                                color = Emerald500
                            )
                            Text(
                                text = upiId,
                                style = MaterialTheme.typography.titleSmall.copy(fontFamily = FontFamily.Monospace),
                                color = PureWhite
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(upiId))
                                onCopiedToast()
                            },
                            color = PureWhite.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("copy_upi_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.ContentCopy,
                                    contentDescription = "ইউপিআই আইডি কপি করুন",
                                    tint = PureWhite,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "কপি করুন",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = PureWhite
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = Slate700)

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        FeatureRow("রেশন দেওয়ার সঠিক সময় ও লোকেশন অ্যালার্ট")
                        FeatureRow("জরুরি এসএমএস ও ইনস্ট্যান্ট পুশ নোটিফিকেশন")
                    }

                    Button(
                        onClick = {
                            val upiUri = Uri.parse(
                                "upi://pay?pa=${Uri.encode(upiId)}&am=10&cu=INR&tn=RationDokanSubscription"
                            )
                            val intent = Intent(Intent.ACTION_VIEW, upiUri)
                            try {
                                context.startActivity(intent)
                            } catch (_: ActivityNotFoundException) {
                                // Still show payment confirmation dialog if UPI app is unavailable in emulator
                            }
                            onPayClick()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Amber400,
                            contentColor = Slate950
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("upi_pay_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Bolt,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ইউপিআই (UPI) দিয়ে ১০ টাকা পে করুন",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureRow(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.Filled.CheckCircle,
            contentDescription = null,
            tint = Emerald500,
            modifier = Modifier.size(17.dp)
        )
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = Slate200
        )
    }
}
