package com.example.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.data.remote.RationScheduleDoc
import com.example.ui.theme.Emerald100
import com.example.ui.theme.Emerald200
import com.example.ui.theme.Emerald50
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Emerald700
import com.example.ui.theme.Emerald800
import com.example.ui.theme.PureWhite
import com.example.ui.theme.Rose500
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import kotlin.math.roundToInt

@Composable
fun MapScreen(
    schedules: List<RationScheduleDoc>,
    selectedSpotIndex: Int,
    onSelectSpot: (Int) -> Unit,
    onShowMessage: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activeSpot = schedules.getOrNull(selectedSpotIndex)

    val bounceTransition = rememberInfiniteTransition(label = "map_pin_bounce")
    val pinOffsetY by bounceTransition.animateFloat(
        initialValue = 0f,
        targetValue = -14f,
        animationSpec = infiniteRepeatable(
            animation = tween(650, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pin_y"
    )

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                color = PureWhite,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, Slate200),
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Map,
                            contentDescription = null,
                            tint = Emerald600,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "রেশন ও গ্রামসভার লাইভ ম্যাপ",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = Slate800
                        )
                    }

                    if (schedules.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            schedules.forEachIndexed { idx, spot ->
                                FilterChip(
                                    selected = idx == selectedSpotIndex,
                                    onClick = { onSelectSpot(idx) },
                                    label = {
                                        Text(
                                            text = spot.dayLabel,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Emerald100,
                                        selectedLabelColor = Emerald800
                                    )
                                )
                            }
                        }
                    }

                    // Stylized Village Map Preview Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(Emerald50)
                            .border(1.dp, Emerald200, RoundedCornerShape(18.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val step = 28.dp.toPx()
                            var x = step / 2f
                            while (x < size.width) {
                                var y = step / 2f
                                while (y < size.height) {
                                    drawCircle(
                                        color = Emerald600.copy(alpha = 0.22f),
                                        radius = 1.6.dp.toPx(),
                                        center = Offset(x, y)
                                    )
                                    y += step
                                }
                                x += step
                            }

                            // Stylized village main road & branch paths
                            val mainRoad = Path().apply {
                                moveTo(0f, size.height * 0.72f)
                                quadraticTo(
                                    size.width * 0.45f,
                                    size.height * 0.48f,
                                    size.width,
                                    size.height * 0.34f
                                )
                            }
                            drawPath(
                                path = mainRoad,
                                color = PureWhite.copy(alpha = 0.9f),
                                style = Stroke(width = 16.dp.toPx(), cap = StrokeCap.Round)
                            )
                            drawPath(
                                path = mainRoad,
                                color = Emerald600.copy(alpha = 0.25f),
                                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                            )

                            val branchRoad = Path().apply {
                                moveTo(size.width * 0.48f, size.height * 0.52f)
                                quadraticTo(
                                    size.width * 0.56f,
                                    size.height * 0.75f,
                                    size.width * 0.72f,
                                    size.height
                                )
                            }
                            drawPath(
                                path = branchRoad,
                                color = PureWhite.copy(alpha = 0.85f),
                                style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .offset { IntOffset(0, pinOffsetY.roundToInt()) }
                                    .size(50.dp)
                                    .shadow(8.dp, CircleShape)
                                    .clip(CircleShape)
                                    .background(Rose500),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.LocationOn,
                                    contentDescription = "রেশন স্পট পিন",
                                    tint = PureWhite,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                color = Slate900,
                                shape = RoundedCornerShape(50),
                                shadowElevation = 4.dp
                            ) {
                                Text(
                                    text = activeSpot?.location ?: "সীতানগর মোড় (আজকের রেশন স্পট)",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = PureWhite,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = activeSpot?.address ?: "গুগল ম্যাপ লোকেশন সক্রিয় আছে",
                                style = MaterialTheme.typography.labelSmall,
                                color = Slate700,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Button(
                        onClick = {
                            val query = activeSpot?.let { "${it.location}, ${it.address}" } ?: "সীতানগর মোড়, গ্রাম পঞ্চায়েত এলাকা"
                            val geoIntent = Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse("geo:0,0?q=${Uri.encode(query)}")
                            )
                            try {
                                context.startActivity(geoIntent)
                            } catch (_: ActivityNotFoundException) {
                                val webIntent = Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse("https://maps.google.com/?q=${Uri.encode(query)}")
                                )
                                try {
                                    context.startActivity(webIntent)
                                } catch (_: ActivityNotFoundException) {
                                    onShowMessage("ম্যাপ পাওয়া যায়নি", "আপনার ফোনে ম্যাপ অ্যাপ পাওয়া যায়নি।")
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald600),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("launch_google_maps_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Navigation,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "সরাসরি গুগল ম্যাপে নেভিগেশন চালু করুন",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}
