package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        RationScheduleEntity::class,
        UrgentBannerEntity::class,
        VillageNewsEntity::class,
        NotificationItemEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class RationDatabase : RoomDatabase() {
    abstract fun rationDao(): RationDao

    companion object {
        @Volatile
        private var INSTANCE: RationDatabase? = null

        fun getInstance(context: Context): RationDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RationDatabase::class.java,
                    "ration_dokan_db"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
