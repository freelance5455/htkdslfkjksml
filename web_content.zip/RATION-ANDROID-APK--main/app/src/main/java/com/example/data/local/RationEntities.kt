package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class StatusTone {
    EMERALD,
    AMBER,
    ORANGE,
    ROSE,
    BLUE
}

enum class NewsCategoryTone {
    ROSE,
    BLUE,
    EMERALD
}

@Entity(tableName = "ration_schedules")
data class RationScheduleEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val dayLabel: String,
    val dateLabel: String,
    val location: String,
    val address: String,
    val statusText: String,
    val statusTone: String = StatusTone.EMERALD.name,
    val sortOrder: Int = 0
)

@Entity(tableName = "urgent_banners")
data class UrgentBannerEntity(
    @PrimaryKey val id: Int, // 1 = Red Urgent Banner, 2 = Blue Special Notice
    val isVisible: Boolean,
    val dateBadge: String,
    val headline: String,
    val description: String
)

@Entity(tableName = "village_news")
data class VillageNewsEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String,
    val categoryTone: String = NewsCategoryTone.ROSE.name,
    val dateLabel: String,
    val title: String,
    val description: String,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class NotificationItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val message: String,
    val timeLabel: String,
    val createdAtMillis: Long = System.currentTimeMillis()
)
