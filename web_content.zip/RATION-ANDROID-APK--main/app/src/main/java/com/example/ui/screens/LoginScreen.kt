package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.ui.auth.onGoogleSignInClicked
import com.example.ui.auth.sendPhoneOtp
import com.example.ui.auth.verifyPhoneOtp
import com.example.ui.theme.Emerald100
import com.example.ui.theme.Emerald50
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Emerald700
import com.example.ui.theme.Emerald800
import com.example.ui.theme.PureWhite
import com.example.ui.theme.Rose100
import com.example.ui.theme.Rose700
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate50
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate900
import com.google.firebase.auth.PhoneAuthProvider
import kotlinx.coroutines.delay

private enum class PhoneLoginStep {
    ENTER_PHONE,
    ENTER_OTP
}

@Composable
fun LoginScreen(
    onAuthSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var step by rememberSaveable { mutableStateOf(PhoneLoginStep.ENTER_PHONE) }
    var phoneInput by rememberSaveable { mutableStateOf("") }
    var otpInput by rememberSaveable { mutableStateOf("") }
    var formattedTargetPhone by rememberSaveable { mutableStateOf("") }
    var verificationId by rememberSaveable { mutableStateOf("") }
    var resendToken by remember { mutableStateOf<PhoneAuthProvider.ForceResendingToken?>(null) }

    var isPhoneLoading by remember { mutableStateOf(false) }
    var isAdminLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var resendCooldown by remember { mutableIntStateOf(0) }

    LaunchedEffect(resendCooldown) {
        if (resendCooldown > 0) {
            delay(1000L)
            resendCooldown -= 1
        }
    }

    val triggerSendOtp = {
        errorMessage = null
        isPhoneLoading = true
        sendPhoneOtp(
            context = context,
            rawPhone = phoneInput,
            resendToken = resendToken,
            scope = scope,
            onCodeSent = { vId, token, formatted ->
                isPhoneLoading = false
                verificationId = vId
                resendToken = token
                formattedTargetPhone = formatted
                step = PhoneLoginStep.ENTER_OTP
                resendCooldown = 60
            },
            onAutoVerified = {
                isPhoneLoading = false
                onAuthSuccess()
            },
            onError = { msg ->
                isPhoneLoading = false
                errorMessage = msg
            }
        )
    }

    val triggerVerifyOtp = {
        errorMessage = null
        isPhoneLoading = true
        verifyPhoneOtp(
            verificationId = verificationId,
            rawOtp = otpInput,
            scope = scope,
            onSuccess = {
                isPhoneLoading = false
                onAuthSuccess()
            },
            onError = { msg ->
                isPhoneLoading = false
                errorMessage = msg
            }
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Emerald50.copy(alpha = 0.55f), PureWhite, PureWhite)
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 460.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Emerald100),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Storefront,
                        contentDescription = stringResource(R.string.cd_store_logo),
                        tint = Emerald700,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = stringResource(R.string.app_name),
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = Slate900
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = stringResource(R.string.login_subtitle),
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate500,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                // User Login Card (Mobile Number & OTP ONLY)
                Surface(
                    color = PureWhite,
                    shape = RoundedCornerShape(22.dp),
                    border = BorderStroke(1.dp, Slate200),
                    shadowElevation = 2.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (step == PhoneLoginStep.ENTER_PHONE) Icons.Filled.PhoneAndroid else Icons.Filled.Sms,
                                contentDescription = null,
                                tint = Emerald600,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "ইউজার লগইন (মোবাইল ও ওটিপি)",
                                style = MaterialTheme.typography.labelLarge,
                                color = Slate900
                            )
                        }

                        if (errorMessage != null) {
                            Surface(
                                color = Rose100,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = errorMessage ?: "",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Rose700,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }

                        AnimatedContent(
                            targetState = step,
                            label = "phone_otp_step"
                        ) { currentStep ->
                            if (currentStep == PhoneLoginStep.ENTER_PHONE) {
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    OutlinedTextField(
                                        value = phoneInput,
                                        onValueChange = { value ->
                                            if (value.length <= 15) {
                                                phoneInput = value
                                                errorMessage = null
                                            }
                                        },
                                        label = { Text(stringResource(R.string.login_phone_label)) },
                                        placeholder = { Text(stringResource(R.string.login_phone_placeholder)) },
                                        prefix = {
                                            Text(
                                                text = "+৯১ ",
                                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                color = Emerald700
                                            )
                                        },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(
                                            keyboardType = KeyboardType.Phone,
                                            imeAction = ImeAction.Done
                                        ),
                                        keyboardActions = KeyboardActions(
                                            onDone = { if (!isPhoneLoading) triggerSendOtp() }
                                        ),
                                        shape = RoundedCornerShape(14.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = Emerald600,
                                            unfocusedBorderColor = Slate200,
                                            focusedContainerColor = Slate50,
                                            unfocusedContainerColor = Slate50
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("phone_number_input")
                                    )

                                    Button(
                                        onClick = triggerSendOtp,
                                        enabled = !isPhoneLoading && !isAdminLoading,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Emerald600,
                                            contentColor = PureWhite
                                        ),
                                        shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(50.dp)
                                            .testTag("send_otp_button")
                                    ) {
                                        if (isPhoneLoading) {
                                            CircularProgressIndicator(
                                                color = PureWhite,
                                                strokeWidth = 2.dp,
                                                modifier = Modifier.size(22.dp)
                                            )
                                        } else {
                                            Text(
                                                text = stringResource(R.string.login_send_otp),
                                                style = MaterialTheme.typography.labelLarge
                                            )
                                        }
                                    }
                                }
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Surface(
                                        color = Emerald50,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "ওটিপি পাঠানো হয়েছে: $formattedTargetPhone",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Emerald800,
                                                modifier = Modifier.weight(1f)
                                            )
                                            TextButton(
                                                onClick = {
                                                    step = PhoneLoginStep.ENTER_PHONE
                                                    otpInput = ""
                                                    errorMessage = null
                                                },
                                                modifier = Modifier.testTag("back_to_phone_button")
                                            ) {
                                                Text(
                                                    text = stringResource(R.string.login_change_number),
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = Emerald700
                                                )
                                            }
                                        }
                                    }

                                    OutlinedTextField(
                                        value = otpInput,
                                        onValueChange = { value ->
                                            if (value.length <= 6) {
                                                otpInput = value
                                                errorMessage = null
                                            }
                                        },
                                        label = { Text(stringResource(R.string.login_otp_label)) },
                                        supportingText = {
                                            Text(
                                                text = stringResource(R.string.login_otp_hint),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Slate500
                                            )
                                        },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(
                                            keyboardType = KeyboardType.NumberPassword,
                                            imeAction = ImeAction.Done
                                        ),
                                        keyboardActions = KeyboardActions(
                                            onDone = { if (!isPhoneLoading) triggerVerifyOtp() }
                                        ),
                                        shape = RoundedCornerShape(14.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = Emerald600,
                                            unfocusedBorderColor = Slate200,
                                            focusedContainerColor = Slate50,
                                            unfocusedContainerColor = Slate50
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("otp_input")
                                    )

                                    Button(
                                        onClick = triggerVerifyOtp,
                                        enabled = !isPhoneLoading && !isAdminLoading,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Emerald600,
                                            contentColor = PureWhite
                                        ),
                                        shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(50.dp)
                                            .testTag("verify_otp_button")
                                    ) {
                                        if (isPhoneLoading) {
                                            CircularProgressIndicator(
                                                color = PureWhite,
                                                strokeWidth = 2.dp,
                                                modifier = Modifier.size(22.dp)
                                            )
                                        } else {
                                            Icon(
                                                imageVector = Icons.Filled.CheckCircle,
                                                contentDescription = null,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = stringResource(R.string.login_verify_enter),
                                                style = MaterialTheme.typography.labelLarge
                                            )
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        TextButton(
                                            onClick = triggerSendOtp,
                                            enabled = resendCooldown == 0 && !isPhoneLoading,
                                            modifier = Modifier.testTag("resend_otp_button")
                                        ) {
                                            Text(
                                                text = if (resendCooldown > 0) {
                                                    "পুনরায় ওটিপি পাঠান (${resendCooldown} সে.)"
                                                } else {
                                                    "পুনরায় ওটিপি পাঠান"
                                                },
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (resendCooldown == 0) Emerald700 else Slate400
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Admin-Only Gmail Login Section
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HorizontalDivider(modifier = Modifier.weight(1f), color = Slate200)
                    Text(
                        text = "শুধুমাত্র অ্যাডমিন লগইন",
                        style = MaterialTheme.typography.labelSmall,
                        color = Slate500
                    )
                    HorizontalDivider(modifier = Modifier.weight(1f), color = Slate200)
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = {
                        errorMessage = null
                        isAdminLoading = true
                        onGoogleSignInClicked(
                            context = context,
                            credentialManager = credentialManager,
                            onAuthSuccess = {
                                isAdminLoading = false
                                onAuthSuccess()
                            },
                            onAuthError = { msg ->
                                isAdminLoading = false
                                errorMessage = msg
                            },
                            scope = scope,
                            onAuthCancelled = {
                                isAdminLoading = false
                            },
                            requireAdminAccount = true
                        )
                    },
                    enabled = !isPhoneLoading && !isAdminLoading,
                    border = BorderStroke(1.dp, Slate200),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = PureWhite,
                        contentColor = Slate700
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("google_sign_in_button")
                ) {
                    if (isAdminLoading) {
                        CircularProgressIndicator(
                            color = Emerald600,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(20.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Filled.AdminPanelSettings,
                            contentDescription = null,
                            tint = Emerald700,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "অ্যাডমিন জিমেইল লগইন (Sign in with Google)",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }

            Text(
                text = stringResource(R.string.login_footer),
                style = MaterialTheme.typography.labelSmall,
                color = Slate400,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 20.dp, bottom = 8.dp)
            )
        }
    }
}
