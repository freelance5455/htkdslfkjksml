package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Emerald & Teal
val Emerald900 = Color(0xFF064E3B)
val Emerald800 = Color(0xFF065F46)
val Emerald700 = Color(0xFF047857)
val Emerald600 = Color(0xFF059669)
val Emerald500 = Color(0xFF10B981)
val Emerald200 = Color(0xFFA7F3D0)
val Emerald100 = Color(0xFFD1FAE5)
val Emerald50 = Color(0xFFECFDF5)
val Teal700 = Color(0xFF0F766E)

// Accents
val Amber400 = Color(0xFFFBBF24)
val Amber500 = Color(0xFFF59E0B)
val Amber200 = Color(0xFFFDE68A)
val Amber50 = Color(0xFFFFFBEB)
val Orange500 = Color(0xFFF97316)

// Urgent Red / Rose
val Red600 = Color(0xFFDC2626)
val Rose600 = Color(0xFFE11D48)
val Rose500 = Color(0xFFF43F5E)
val Rose100 = Color(0xFFFFE4E6)
val Rose700 = Color(0xFFBE123C)
val Amber600 = Color(0xFFD97706)

// Special Notice Blue / Indigo / Cyan
val Indigo600 = Color(0xFF4F46E5)
val Blue600 = Color(0xFF2563EB)
val Blue700 = Color(0xFF1D4ED8)
val Blue100 = Color(0xFFDBEAFE)
val Cyan600 = Color(0xFF0891B2)
val Cyan100 = Color(0xFFCFFAFE)

// Neutrals (Slate)
val Slate950 = Color(0xFF020617)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate300 = Color(0xFFCBD5E1)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)
val PureWhite = Color(0xFFFFFFFF)
