package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.repository.FirestoreRationRepository
import com.example.ui.auth.authStateFlow
import com.example.ui.auth.signOutFromFirebase
import com.example.ui.components.FloatingPushToast
import com.example.ui.components.NotificationCenterSheet
import com.example.ui.components.PaymentConfirmationDialog
import com.example.ui.components.RationBottomNavigationBar
import com.example.ui.components.RationNavigationRail
import com.example.ui.components.RationTopAppBar
import com.example.ui.components.SubscriptionLockOverlay
import com.example.ui.screens.AdminGateScreen
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MapScreen
import com.example.ui.screens.SubscriptionScreen
import com.example.ui.screens.VillageNewsScreen
import com.example.ui.theme.RationDokanTheme
import com.example.ui.theme.Slate100
import com.example.ui.viewmodel.AppTab
import com.example.ui.viewmodel.RationViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RationDokanTheme {
                RationDokanRoot()
            }
        }
    }
}

@Composable
fun RationDokanRoot() {
    val auth = remember { Firebase.auth }
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)

    if (currentUser == null) {
        LoginScreen(
            onAuthSuccess = {}
        )
    } else {
        val user = currentUser!!
        key(user.uid) {
            val viewModel: RationViewModel = viewModel(
                key = user.uid,
                factory = viewModelFactory {
                    initializer {
                        val app = checkNotNull(this[APPLICATION_KEY])
                        val dbId = app.getString(R.string.firestore_database_id)
                        val db = FirebaseFirestore.getInstance(dbId)
                        RationViewModel(
                            repository = FirestoreRationRepository(db, Firebase.auth),
                            currentUserId = user.uid,
                            userEmail = user.email ?: "",
                            userPhone = user.phoneNumber ?: ""
                        )
                    }
                }
            )
            RationDokanApp(viewModel = viewModel)
        }
    }
}

@Composable
fun RationDokanApp(
    viewModel: RationViewModel
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    // Back press on non-home tabs navigates cleanly back to Home
    if (state.currentTab != AppTab.HOME) {
        BackHandler {
            viewModel.switchTab(AppTab.HOME)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useNavigationRail = maxWidth >= 680.dp

            Row(modifier = Modifier.fillMaxSize()) {
                if (useNavigationRail) {
                    RationNavigationRail(
                        currentTab = state.currentTab,
                        onTabSelected = viewModel::switchTab
                    )
                }

                Scaffold(
                    containerColor = Slate100,
                    topBar = {
                        RationTopAppBar(
                            phoneLabel = state.phoneNumber,
                            isSubscribed = state.isSubscribed,
                            unreadCount = state.notifications.size,
                            onLogoutClick = {
                                signOutFromFirebase(
                                    credentialManager = credentialManager,
                                    scope = coroutineScope
                                )
                            },
                            onSubscriptionClick = { viewModel.switchTab(AppTab.SUBSCRIPTION) },
                            onNotificationClick = viewModel::openNotificationSheet
                        )
                    },
                    bottomBar = {
                        if (!useNavigationRail) {
                            RationBottomNavigationBar(
                                currentTab = state.currentTab,
                                onTabSelected = viewModel::switchTab
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (state.currentTab) {
                            AppTab.HOME -> HomeScreen(
                                schedules = state.schedules,
                                bannerIndex = state.bannerIndex,
                                urgentBanner1 = state.urgentBanner1,
                                urgentBanner2 = state.urgentBanner2,
                                onPrevBanner = viewModel::prevBanner,
                                onNextBanner = viewModel::nextBanner,
                                onSelectBanner = viewModel::selectBanner,
                                onOpenMap = viewModel::openMapForSpot
                            )

                            AppTab.SUBSCRIPTION -> SubscriptionScreen(
                                upiId = state.upiId,
                                isSubscribed = state.isSubscribed,
                                onPayClick = viewModel::triggerPaymentFlow,
                                onCopiedToast = {
                                    viewModel.showToast("কপি হয়েছে", "ইউপিআই আইডি ক্লিপবোর্ডে কপি করা হয়েছে।")
                                }
                            )

                            AppTab.MAP -> MapScreen(
                                schedules = state.schedules,
                                selectedSpotIndex = state.selectedMapSpotIndex,
                                onSelectSpot = viewModel::selectMapSpot,
                                onShowMessage = viewModel::showToast
                            )

                            AppTab.VILLAGE_NEWS -> VillageNewsScreen(
                                newsList = state.villageNews
                            )

                            AppTab.ADMIN -> if (state.isAdminUnlocked) {
                                AdminScreen(
                                    schedules = state.schedules,
                                    urgentBanner1 = state.urgentBanner1,
                                    urgentBanner2 = state.urgentBanner2,
                                    villageNews = state.villageNews,
                                    currentUpiId = state.upiId,
                                    isTrialExpiredSimulated = state.isTrialExpired,
                                    onUpdatePrimaryRation = viewModel::updatePrimaryRationBanner,
                                    onDeleteSchedule = viewModel::deleteSchedule,
                                    onToggleUrgentBanner = viewModel::toggleUrgentBanner,
                                    onUpdateUrgentBanner = viewModel::updateUrgentBanner,
                                    onDeleteUrgentBanner = viewModel::deleteUrgentBanner,
                                    onAddSchedule = viewModel::addNewSchedule,
                                    onAddNews = viewModel::addVillageNews,
                                    onDeleteNews = viewModel::deleteVillageNews,
                                    onSaveUpiId = viewModel::saveUpiId,
                                    onSimulateTrialExpired = {
                                        viewModel.toggleSimulateTrialExpired(true)
                                    }
                                )
                            } else {
                                AdminGateScreen(
                                    isAdminSession = state.isAdminSession,
                                    errorMessage = state.adminPinError,
                                    onVerifyPin = viewModel::verifyAdminPin,
                                    onSwitchToAdminLogin = {
                                        signOutFromFirebase(
                                            credentialManager = credentialManager,
                                            scope = coroutineScope
                                        )
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (state.isTrialExpired && !state.isSubscribed) {
            SubscriptionLockOverlay(
                onUnlockClick = {
                    viewModel.toggleSimulateTrialExpired(false)
                    viewModel.triggerPaymentFlow()
                }
            )
        }

        if (state.showNotificationSheet) {
            NotificationCenterSheet(
                notifications = state.notifications,
                onDismiss = viewModel::closeNotificationSheet
            )
        }

        if (state.showPaymentDialog) {
            PaymentConfirmationDialog(
                upiId = state.upiId,
                onConfirmPaid = viewModel::confirmSubscriptionUnlock,
                onDismiss = viewModel::dismissPaymentDialog
            )
        }

        FloatingPushToast(
            toast = state.activeToast,
            onDismiss = viewModel::dismissToast,
            modifier = Modifier.align(Alignment.TopCenter)
        )
    }
}
