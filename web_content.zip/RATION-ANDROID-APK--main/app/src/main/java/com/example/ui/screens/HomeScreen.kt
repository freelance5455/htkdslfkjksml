package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.StatusTone
import com.example.data.remote.RationScheduleDoc
import com.example.data.remote.UrgentBannerDoc
import com.example.ui.theme.Amber200
import com.example.ui.theme.Amber400
import com.example.ui.theme.Amber500
import com.example.ui.theme.Amber600
import com.example.ui.theme.Blue600
import com.example.ui.theme.Cyan100
import com.example.ui.theme.Cyan600
import com.example.ui.theme.Emerald100
import com.example.ui.theme.Emerald50
import com.example.ui.theme.Emerald500
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Emerald700
import com.example.ui.theme.Indigo600
import com.example.ui.theme.Orange500
import com.example.ui.theme.PureWhite
import com.example.ui.theme.Red600
import com.example.ui.theme.Rose600
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate300
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate950
import com.example.ui.theme.Teal700
import kotlin.math.roundToInt

@Composable
fun HomeScreen(
    schedules: List<RationScheduleDoc>,
    bannerIndex: Int,
    urgentBanner1: UrgentBannerDoc?,
    urgentBanner2: UrgentBannerDoc?,
    onPrevBanner: () -> Unit,
    onNextBanner: () -> Unit,
    onSelectBanner: (Int) -> Unit,
    onOpenMap: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val activeSchedule = schedules.getOrNull(bannerIndex)

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ১. রেশন শিডিউল স্লাইডার সেকশন
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CalendarMonth,
                                contentDescription = null,
                                tint = Emerald600,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "আজ কোথায় রেশন দেওয়া হচ্ছে?",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = Slate800
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            IconButton(
                                onClick = onPrevBanner,
                                modifier = Modifier
                                    .size(34.dp)
                                    .minimumInteractiveComponentSize()
                                    .clip(CircleShape)
                                    .background(Slate200.copy(alpha = 0.7f))
                                    .testTag("prev_banner_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                    contentDescription = stringResource(R.string.cd_prev_banner),
                                    tint = Slate700,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            IconButton(
                                onClick = onNextBanner,
                                modifier = Modifier
                                    .size(34.dp)
                                    .minimumInteractiveComponentSize()
                                    .clip(CircleShape)
                                    .background(Slate200.copy(alpha = 0.7f))
                                    .testTag("next_banner_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                    contentDescription = stringResource(R.string.cd_next_banner),
                                    tint = Slate700,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    if (activeSchedule != null) {
                        RationHeroSliderCard(
                            schedule = activeSchedule,
                            onOpenMap = { onOpenMap(bannerIndex) }
                        )
                    } else {
                        EmptyHomeCard(
                            title = "এখনো কোনো রেশন আপডেট নেই",
                            subtitle = "অ্যাডমিন নতুন রেশন শিডিউল প্রকাশ করলে এখানে দেখা যাবে।"
                        )
                    }

                    if (schedules.size > 1) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 2.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            schedules.forEachIndexed { idx, _ ->
                                val isSelected = idx == bannerIndex
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 3.dp)
                                        .size(width = if (isSelected) 16.dp else 8.dp, height = 8.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) Emerald600 else Slate300)
                                        .clickable { onSelectBanner(idx) }
                                )
                            }
                        }
                    }
                }
            }

            // ২. জরুরি আপডেট ব্যানার ১ (লাল)
            item {
                AnimatedVisibility(visible = urgentBanner1?.isVisible == true) {
                    urgentBanner1?.let { banner ->
                        UrgentRedBannerCard(banner = banner)
                    }
                }
            }

            // ৩. বিশেষ বিজ্ঞপ্তি ব্যানার ২ (নীল)
            item {
                AnimatedVisibility(visible = urgentBanner2?.isVisible == true) {
                    urgentBanner2?.let { banner ->
                        SpecialBlueBannerCard(banner = banner)
                    }
                }
            }

            // ৪. আসন্ন রেশন শিডিউল তালিকা
            item {
                Text(
                    text = "আগামী দিনগুলোর তালিকা",
                    style = MaterialTheme.typography.labelLarge,
                    color = Slate500,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            if (schedules.isEmpty()) {
                item {
                    EmptyHomeCard(
                        title = "আগামী দিনগুলোর তালিকা খালি",
                        subtitle = "কোনো আসন্ন রেশন শিডিউল এখনো যোগ করা হয়নি।"
                    )
                }
            } else {
                itemsIndexed(schedules, key = { _, item -> item.id }) { index, item ->
                    ScheduleListItemCard(
                        schedule = item,
                        onOpenMap = { onOpenMap(index) }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun RationHeroSliderCard(
    schedule: RationScheduleDoc,
    onOpenMap: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ration_hero_anim")
    val shimmerProgress by infiniteTransition.animateFloat(
        initialValue = -0.5f,
        targetValue = 1.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer"
    )
    val floatOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -10f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "float_icon"
    )

    val statusColors = statusBadgeColors(schedule.statusTone)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 14.dp,
                shape = RoundedCornerShape(24.dp),
                ambientColor = Emerald600,
                spotColor = Emerald600
            )
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(Emerald600, Teal700)
                )
            )
            .drawWithContent {
                drawContent()
                val startX = size.width * shimmerProgress
                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.Transparent,
                            PureWhite.copy(alpha = 0.14f),
                            Color.Transparent
                        ),
                        start = Offset(startX, 0f),
                        end = Offset(startX + size.width * 0.45f, size.height)
                    )
                )
            }
            .padding(20.dp)
    ) {
        Icon(
            imageVector = Icons.Filled.Inventory2,
            contentDescription = null,
            tint = PureWhite.copy(alpha = 0.14f),
            modifier = Modifier
                .size(132.dp)
                .align(Alignment.BottomEnd)
                .offset { IntOffset(28, 28 + floatOffset.roundToInt()) }
        )

        AnimatedContent(
            targetState = schedule,
            transitionSpec = { fadeIn(tween(240)) togetherWith fadeOut(tween(180)) },
            label = "banner_slide_content"
        ) { current ->
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = Amber400,
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = current.dayLabel,
                            style = MaterialTheme.typography.labelMedium,
                            color = Slate950,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Surface(
                        color = statusColors.first,
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.25f))
                    ) {
                        Text(
                            text = current.statusText,
                            style = MaterialTheme.typography.labelMedium,
                            color = statusColors.second,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = current.location,
                        style = MaterialTheme.typography.titleLarge,
                        color = PureWhite
                    )
                    Surface(
                        color = Color.Black.copy(alpha = 0.22f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CalendarMonth,
                                contentDescription = null,
                                tint = Amber400,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "তারিখ: ${current.dateLabel}",
                                style = MaterialTheme.typography.labelMedium,
                                color = PureWhite
                            )
                        }
                    }
                }

                HorizontalDivider(color = PureWhite.copy(alpha = 0.18f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.LocationOn,
                            contentDescription = null,
                            tint = Amber400,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = current.address,
                            style = MaterialTheme.typography.bodySmall,
                            color = Emerald100
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Surface(
                        onClick = onOpenMap,
                        color = PureWhite,
                        shape = RoundedCornerShape(12.dp),
                        shadowElevation = 4.dp,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("banner_open_map_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.cd_open_map),
                                style = MaterialTheme.typography.labelMedium,
                                color = Emerald700
                            )
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                                contentDescription = null,
                                tint = Emerald700,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UrgentRedBannerCard(banner: UrgentBannerDoc) {
    val transition = rememberInfiniteTransition(label = "urgent_red_anim")
    val pulseScale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.012f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "card_pulse"
    )
    val iconScale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "megaphone_pulse"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .scale(pulseScale)
            .shadow(
                elevation = 10.dp,
                shape = RoundedCornerShape(24.dp),
                ambientColor = Rose600,
                spotColor = Rose600
            )
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.horizontalGradient(
                    colors = listOf(Red600, Rose600, Amber600)
                )
            )
            .padding(16.dp)
            .testTag("urgent_banner_1")
    ) {
        Icon(
            imageVector = Icons.Filled.Campaign,
            contentDescription = null,
            tint = PureWhite.copy(alpha = 0.24f),
            modifier = Modifier
                .size(92.dp)
                .align(Alignment.BottomEnd)
                .offset(x = 12.dp, y = 12.dp)
                .scale(iconScale)
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = PureWhite.copy(alpha = 0.25f),
                    shape = RoundedCornerShape(50)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ErrorOutline,
                            contentDescription = null,
                            tint = PureWhite,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "জরুরি আপডেট ১",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = PureWhite
                        )
                    }
                }

                Surface(
                    color = Color.Black.copy(alpha = 0.25f),
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = banner.dateBadge,
                        style = MaterialTheme.typography.labelMedium,
                        color = Amber200,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Text(
                text = banner.headline,
                style = MaterialTheme.typography.titleMedium,
                color = PureWhite
            )

            Text(
                text = banner.description,
                style = MaterialTheme.typography.bodySmall,
                color = PureWhite.copy(alpha = 0.94f)
            )
        }
    }
}

@Composable
private fun SpecialBlueBannerCard(banner: UrgentBannerDoc) {
    val transition = rememberInfiniteTransition(label = "special_blue_anim")
    val waveY by transition.animateFloat(
        initialValue = 0f,
        targetValue = -4f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave_y"
    )
    val iconAngle by transition.animateFloat(
        initialValue = -6f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sparkles_spin"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .offset { IntOffset(0, waveY.roundToInt()) }
            .shadow(
                elevation = 10.dp,
                shape = RoundedCornerShape(24.dp),
                ambientColor = Blue600,
                spotColor = Blue600
            )
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.horizontalGradient(
                    colors = listOf(Indigo600, Blue600, Cyan600)
                )
            )
            .padding(16.dp)
            .testTag("urgent_banner_2")
    ) {
        Icon(
            imageVector = Icons.Filled.AutoAwesome,
            contentDescription = null,
            tint = PureWhite.copy(alpha = 0.24f),
            modifier = Modifier
                .size(92.dp)
                .align(Alignment.BottomEnd)
                .offset(x = 12.dp, y = 12.dp)
                .rotate(iconAngle)
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = PureWhite.copy(alpha = 0.25f),
                    shape = RoundedCornerShape(50)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Info,
                            contentDescription = null,
                            tint = PureWhite,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "বিশেষ বিজ্ঞপ্তি ২",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = PureWhite
                        )
                    }
                }

                Surface(
                    color = Color.Black.copy(alpha = 0.25f),
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = banner.dateBadge,
                        style = MaterialTheme.typography.labelMedium,
                        color = Cyan100,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Text(
                text = banner.headline,
                style = MaterialTheme.typography.titleMedium,
                color = PureWhite
            )

            Text(
                text = banner.description,
                style = MaterialTheme.typography.bodySmall,
                color = PureWhite.copy(alpha = 0.94f)
            )
        }
    }
}

@Composable
private fun ScheduleListItemCard(
    schedule: RationScheduleDoc,
    onOpenMap: () -> Unit
) {
    Surface(
        color = PureWhite,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, Slate200),
        shadowElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("schedule_card_${schedule.id}")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = schedule.dayLabel,
                        style = MaterialTheme.typography.labelLarge,
                        color = Emerald700
                    )
                    Text(
                        text = "(${schedule.dateLabel})",
                        style = MaterialTheme.typography.labelSmall,
                        color = Slate400
                    )
                }
                Text(
                    text = schedule.location,
                    style = MaterialTheme.typography.titleSmall,
                    color = Slate800
                )
                Text(
                    text = schedule.address,
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate500
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            IconButton(
                onClick = onOpenMap,
                modifier = Modifier
                    .size(44.dp)
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Emerald50)
                    .testTag("schedule_map_button_${schedule.id}")
            ) {
                Icon(
                    imageVector = Icons.Filled.LocationOn,
                    contentDescription = stringResource(R.string.cd_open_map),
                    tint = Emerald700,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun EmptyHomeCard(
    title: String,
    subtitle: String
) {
    Surface(
        color = PureWhite,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, Slate200),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.CalendarMonth,
                contentDescription = null,
                tint = Slate400,
                modifier = Modifier.size(28.dp)
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = Slate700
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = Slate500
            )
        }
    }
}

private fun statusBadgeColors(toneName: String): Pair<Color, Color> {
    return when (runCatching { StatusTone.valueOf(toneName) }.getOrDefault(StatusTone.EMERALD)) {
        StatusTone.EMERALD -> Emerald500.copy(alpha = 0.85f) to PureWhite
        StatusTone.AMBER -> Amber400 to Slate950
        StatusTone.ORANGE -> Orange500 to PureWhite
        StatusTone.ROSE -> Rose600 to PureWhite
        StatusTone.BLUE -> Blue600 to PureWhite
    }
}
