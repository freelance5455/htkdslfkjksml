package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "ration_dokan_prefs")

data class UserPrefs(
    val isLoggedIn: Boolean = false,
    val phoneNumber: String = "৯৮৭৬৫৪ ৩২১০",
    val isSubscribed: Boolean = false,
    val isTrialExpired: Boolean = false,
    val upiId: String = "rationdokan@upi"
)

class UserPreferencesDataStore(private val context: Context) {

    private object Keys {
        val IS_LOGGED_IN = booleanPreferencesKey("is_logged_in")
        val PHONE_NUMBER = stringPreferencesKey("phone_number")
        val IS_SUBSCRIBED = booleanPreferencesKey("is_subscribed")
        val IS_TRIAL_EXPIRED = booleanPreferencesKey("is_trial_expired")
        val UPI_ID = stringPreferencesKey("upi_id")
    }

    val userPrefs: Flow<UserPrefs> = context.dataStore.data.map { prefs ->
        UserPrefs(
            isLoggedIn = prefs[Keys.IS_LOGGED_IN] ?: false,
            phoneNumber = prefs[Keys.PHONE_NUMBER] ?: "৯৮৭৬৫৪ ৩২১০",
            isSubscribed = prefs[Keys.IS_SUBSCRIBED] ?: false,
            isTrialExpired = prefs[Keys.IS_TRIAL_EXPIRED] ?: false,
            upiId = prefs[Keys.UPI_ID] ?: "rationdokan@upi"
        )
    }

    suspend fun setLoggedIn(phone: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.IS_LOGGED_IN] = true
            prefs[Keys.PHONE_NUMBER] = phone
        }
    }

    suspend fun logout() {
        context.dataStore.edit { prefs ->
            prefs[Keys.IS_LOGGED_IN] = false
        }
    }

    suspend fun setSubscribed(subscribed: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.IS_SUBSCRIBED] = subscribed
            if (subscribed) {
                prefs[Keys.IS_TRIAL_EXPIRED] = false
            }
        }
    }

    suspend fun setTrialExpired(expired: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.IS_TRIAL_EXPIRED] = expired
        }
    }

    suspend fun setUpiId(upiId: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.UPI_ID] = upiId
        }
    }
}
