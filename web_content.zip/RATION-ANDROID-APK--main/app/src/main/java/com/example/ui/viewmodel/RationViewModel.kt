package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.NewsCategoryTone
import com.example.data.local.StatusTone
import com.example.data.remote.NotificationDoc
import com.example.data.remote.RationScheduleDoc
import com.example.data.remote.UrgentBannerDoc
import com.example.data.remote.VillageNewsDoc
import com.example.data.repository.FirestoreRationRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AppTab {
    HOME,
    SUBSCRIPTION,
    MAP,
    VILLAGE_NEWS,
    ADMIN
}

data class ToastMessage(
    val title: String,
    val message: String,
    val id: Long = System.currentTimeMillis()
)

data class RationUiState(
    val currentTab: AppTab = AppTab.HOME,
    val schedules: List<RationScheduleDoc> = emptyList(),
    val bannerIndex: Int = 0,
    val selectedMapSpotIndex: Int = 0,
    val urgentBanner1: UrgentBannerDoc? = null,
    val urgentBanner2: UrgentBannerDoc? = null,
    val villageNews: List<VillageNewsDoc> = emptyList(),
    val notifications: List<NotificationDoc> = emptyList(),
    val phoneNumber: String = "",
    val userEmail: String = "",
    val isSubscribed: Boolean = false,
    val isTrialExpired: Boolean = false,
    val upiId: String = "rationdokan@upi",
    val activeToast: ToastMessage? = null,
    val showNotificationSheet: Boolean = false,
    val showPaymentDialog: Boolean = false,
    val isAdminUnlocked: Boolean = false,
    val isAdminSession: Boolean = false,
    val adminPinError: String? = null
)

private data class LocalUiState(
    val currentTab: AppTab = AppTab.HOME,
    val bannerIndex: Int = 0,
    val selectedMapSpotIndex: Int = 0,
    val activeToast: ToastMessage? = null,
    val showNotificationSheet: Boolean = false,
    val showPaymentDialog: Boolean = false,
    val isAdminUnlocked: Boolean = false,
    val isAdminSession: Boolean = false,
    val adminPinError: String? = null
)

class RationViewModel(
    private val repository: FirestoreRationRepository,
    private val currentUserId: String,
    private val userEmail: String,
    private val userPhone: String = ""
) : ViewModel() {

    private val localState = MutableStateFlow(
        LocalUiState(isAdminSession = userEmail.equals("onlinekutir@gmail.com", ignoreCase = true))
    )
    private var toastJob: Job? = null

    init {
        viewModelScope.launch {
            repository.ensureUserAccount(userEmail, userPhone)
            val adminVerified = repository.isAdminAccount(currentUserId, userEmail)
            localState.update { it.copy(isAdminSession = adminVerified) }
        }
    }

    private val schedulesFlow = repository.observeSchedules().catch { error ->
        handleStreamFailure("schedules", error)
        emit(emptyList())
    }

    private val bannersFlow = repository.observeUrgentBanners().catch { error ->
        handleStreamFailure("banners", error)
        emit(emptyList())
    }

    private val newsFlow = repository.observeVillageNews().catch { error ->
        handleStreamFailure("news", error)
        emit(emptyList())
    }

    private val notificationsFlow = repository.observeNotifications().catch { error ->
        handleStreamFailure("notifications", error)
        emit(emptyList())
    }

    private val paymentSettingsFlow = repository.observePaymentSettings().catch { error ->
        handleStreamFailure("paymentSettings", error)
        emit(null)
    }

    private val userAccountFlow = repository.observeUserAccount(currentUserId).catch { error ->
        handleStreamFailure("userAccount", error)
        emit(null)
    }

    val uiState: StateFlow<RationUiState> = combine(
        schedulesFlow,
        bannersFlow,
        newsFlow,
        notificationsFlow,
        paymentSettingsFlow,
        userAccountFlow,
        localState
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val schedules = values[0] as List<RationScheduleDoc>
        @Suppress("UNCHECKED_CAST")
        val banners = values[1] as List<UrgentBannerDoc>
        @Suppress("UNCHECKED_CAST")
        val news = values[2] as List<VillageNewsDoc>
        @Suppress("UNCHECKED_CAST")
        val notifications = values[3] as List<NotificationDoc>
        val payment = values[4] as? com.example.data.remote.PaymentSettingsDoc
        val account = values[5] as? com.example.data.remote.UserAccountDoc
        val local = values[6] as LocalUiState

        val safeBannerIdx = if (schedules.isEmpty()) 0 else local.bannerIndex.coerceIn(0, schedules.lastIndex)
        val safeMapIdx = if (schedules.isEmpty()) 0 else local.selectedMapSpotIndex.coerceIn(0, schedules.lastIndex)

        RationUiState(
            currentTab = local.currentTab,
            schedules = schedules,
            bannerIndex = safeBannerIdx,
            selectedMapSpotIndex = safeMapIdx,
            urgentBanner1 = banners.firstOrNull { it.bannerNumber == 1L },
            urgentBanner2 = banners.firstOrNull { it.bannerNumber == 2L },
            villageNews = news,
            notifications = notifications,
            phoneNumber = account?.phoneNumber?.ifBlank { userPhone.ifBlank { userEmail } }
                ?: userPhone.ifBlank { userEmail },
            userEmail = userEmail,
            isSubscribed = account?.isSubscribed ?: false,
            isTrialExpired = account?.isTrialExpired ?: false,
            upiId = payment?.upiId?.ifBlank { "rationdokan@upi" } ?: "rationdokan@upi",
            activeToast = local.activeToast,
            showNotificationSheet = local.showNotificationSheet,
            showPaymentDialog = local.showPaymentDialog,
            isAdminUnlocked = local.isAdminUnlocked,
            isAdminSession = local.isAdminSession,
            adminPinError = local.adminPinError
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = RationUiState(
            userEmail = userEmail,
            phoneNumber = userPhone.ifBlank { userEmail },
            isAdminSession = userEmail.equals("onlinekutir@gmail.com", ignoreCase = true)
        )
    )

    fun switchTab(tab: AppTab) {
        localState.update { it.copy(currentTab = tab, adminPinError = null) }
    }

    fun verifyAdminPin(rawPin: String) {
        if (!localState.value.isAdminSession) {
            localState.update {
                it.copy(
                    isAdminUnlocked = false,
                    adminPinError = "শুধুমাত্র অনুমোদিত অ্যাডমিন জিমেইল একাউন্ট দিয়ে লগইন করলে অ্যাডমিন প্যানেল খোলা যাবে।"
                )
            }
            return
        }
        val normalized = extractDigits(rawPin)
        if (normalized == ADMIN_SECRET_PIN) {
            localState.update {
                it.copy(
                    isAdminUnlocked = true,
                    adminPinError = null
                )
            }
            showToast("অ্যাডমিন আনলক", "অ্যাডমিন প্যানেলে স্বাগতম!")
        } else {
            localState.update {
                it.copy(
                    isAdminUnlocked = false,
                    adminPinError = "ভুল অ্যাডমিন পিন! সাধারণ ইউজারদের প্রবেশ নিষেধ।"
                )
            }
        }
    }

    fun openMapForSpot(index: Int) {
        localState.update {
            it.copy(
                currentTab = AppTab.MAP,
                selectedMapSpotIndex = index
            )
        }
    }

    fun selectMapSpot(index: Int) {
        localState.update { it.copy(selectedMapSpotIndex = index) }
    }

    fun nextBanner() {
        val count = uiState.value.schedules.size
        if (count <= 1) return
        localState.update { it.copy(bannerIndex = (it.bannerIndex + 1) % count) }
    }

    fun prevBanner() {
        val count = uiState.value.schedules.size
        if (count <= 1) return
        localState.update { it.copy(bannerIndex = (it.bannerIndex - 1 + count) % count) }
    }

    fun selectBanner(index: Int) {
        localState.update { it.copy(bannerIndex = index) }
    }

    // Admin actions
    fun updatePrimaryRationBanner(
        statusText: String,
        statusTone: StatusTone,
        location: String,
        dateLabel: String,
        address: String
    ) {
        val cleanStatus = statusText.trim()
        val cleanLoc = location.trim()
        if (cleanStatus.isBlank() || cleanLoc.isBlank()) {
            showToast("সতর্কতা", "দয়া করে সময় এবং জায়গার নাম লিখুন।")
            return
        }
        val existingId = uiState.value.schedules.firstOrNull()?.id
        viewModelScope.launch {
            val result = repository.upsertPrimarySchedule(
                existingId = existingId,
                statusText = cleanStatus,
                statusTone = statusTone,
                location = cleanLoc,
                dateLabel = dateLabel.trim().ifBlank { "১৪ নভেম্বর, ২০২৬" },
                address = address.trim().ifBlank { "গ্রাম পঞ্চায়েত এলাকা" }
            )
            if (result.isSuccess) {
                localState.update { it.copy(bannerIndex = 0, currentTab = AppTab.HOME) }
                showToast("রেশন ব্যানার লাইভ আপডেট!", "$cleanLoc — $cleanStatus")
            } else {
                showPermissionOrErrorToast(result.exceptionOrNull())
            }
        }
    }

    fun deleteSchedule(scheduleId: String) {
        viewModelScope.launch {
            val result = repository.deleteSchedule(scheduleId)
            if (result.isSuccess) {
                showToast("ডিলিট সফল", "রেশন ব্যানার/শিডিউল মুছে ফেলা হয়েছে।")
            } else {
                showPermissionOrErrorToast(result.exceptionOrNull())
            }
        }
    }

    fun toggleUrgentBanner(bannerId: Int, visible: Boolean) {
        val existing = if (bannerId == 1) uiState.value.urgentBanner1 else uiState.value.urgentBanner2
        val headline = existing?.headline?.ifBlank { "জরুরি বিজ্ঞপ্তি" } ?: "জরুরি বিজ্ঞপ্তি"
        val dateBadge = existing?.dateBadge?.ifBlank { if (bannerId == 1) "আজ" else "বিশেষ বিজ্ঞপ্তি" }
            ?: if (bannerId == 1) "আজ" else "বিশেষ বিজ্ঞপ্তি"
        val description = existing?.description ?: ""

        viewModelScope.launch {
            val result = repository.upsertUrgentBanner(
                bannerNumber = bannerId,
                isVisible = visible,
                dateBadge = dateBadge,
                headline = headline,
                description = description,
                notifyUsers = visible && existing != null && existing.headline.isNotBlank()
            )
            if (result.isSuccess) {
                if (visible && existing != null && existing.headline.isNotBlank()) {
                    showToast("নতুন বিজ্ঞপ্তি প্রকাশিত", existing.headline)
                }
            } else {
                showPermissionOrErrorToast(result.exceptionOrNull())
            }
        }
    }

    fun updateUrgentBanner(
        bannerId: Int,
        dateBadge: String,
        headline: String,
        description: String
    ) {
        if (headline.trim().isBlank()) {
            showToast("সতর্কতা", "দয়া করে ব্যানারের শিরোনাম লিখুন।")
            return
        }
        viewModelScope.launch {
            val result = repository.upsertUrgentBanner(
                bannerNumber = bannerId,
                isVisible = true,
                dateBadge = dateBadge.trim().ifBlank { if (bannerId == 1) "আজ" else "বিশেষ বিজ্ঞপ্তি" },
                headline = headline.trim(),
                description = description.trim(),
                notifyUsers = true
            )
            if (result.isSuccess) {
                localState.update { it.copy(currentTab = AppTab.HOME) }
                showToast(
                    "বিজ্ঞপ্তি ব্যানার $bannerId আপডেট",
                    "সকল ইউজারের মোবাইলে লাইভ আপডেট ও নোটিফিকেশন পৌঁছে গেছে!"
                )
            } else {
                showPermissionOrErrorToast(result.exceptionOrNull())
            }
        }
    }

    fun deleteUrgentBanner(bannerNumber: Int) {
        viewModelScope.launch {
            val result = repository.deleteUrgentBanner(bannerNumber)
            if (result.isSuccess) {
                showToast("ব্যানার ডিলিট", "বিজ্ঞপ্তি ব্যানার $bannerNumber মুছে ফেলা হয়েছে।")
            } else {
                showPermissionOrErrorToast(result.exceptionOrNull())
            }
        }
    }

    fun addNewSchedule(
        dayLabel: String,
        dateLabel: String,
        location: String,
        address: String,
        timeRange: String
    ) {
        if (dayLabel.trim().isBlank() || location.trim().isBlank()) {
            showToast("সতর্কতা", "দয়া করে তারিখ/বার এবং লোকেশন লিখুন।")
            return
        }
        viewModelScope.launch {
            val statusText = if (timeRange.trim().isNotBlank()) "আসছে (${timeRange.trim()})" else "আসছে"
            val result = repository.addNewSchedule(
                dayLabel = dayLabel,
                dateLabel = dateLabel,
                location = location,
                address = address,
                statusText = statusText
            )
            if (result.isSuccess) {
                localState.update { it.copy(currentTab = AppTab.HOME) }
                showToast("নতুন রেশন আপডেট", "${location.trim()} এ নতুন রেশনের তারিখ যোগ করা হয়েছে।")
            } else {
                showPermissionOrErrorToast(result.exceptionOrNull())
            }
        }
    }

    fun addVillageNews(
        category: String,
        tone: NewsCategoryTone,
        dateLabel: String,
        title: String,
        description: String
    ) {
        if (title.trim().isBlank() || description.trim().isBlank()) {
            showToast("সতর্কতা", "দয়া করে খবরের শিরোনাম ও বিবরণ লিখুন।")
            return
        }
        viewModelScope.launch {
            val result = repository.addVillageNews(
                category = category.trim().ifBlank { "গ্রামের খবর" },
                tone = tone,
                dateLabel = dateLabel.trim().ifBlank { "আজ" },
                title = title,
                description = description
            )
            if (result.isSuccess) {
                localState.update { it.copy(currentTab = AppTab.VILLAGE_NEWS) }
                showToast("নতুন গ্রামের খবর", "${title.trim()} প্রকাশিত হয়েছে।")
            } else {
                showPermissionOrErrorToast(result.exceptionOrNull())
            }
        }
    }

    fun deleteVillageNews(newsId: String) {
        viewModelScope.launch {
            val result = repository.deleteVillageNews(newsId)
            if (result.isSuccess) {
                showToast("ডিলিট সফল", "গ্রামের খবরটি মুছে ফেলা হয়েছে।")
            } else {
                showPermissionOrErrorToast(result.exceptionOrNull())
            }
        }
    }

    // Subscription & UPI (Admin sets UPI ID, linked automatically to Subscription screen)
    fun saveUpiId(upiId: String) {
        val trimmed = upiId.trim()
        if (trimmed.isBlank() || !trimmed.contains("@")) {
            showToast("সতর্কতা", "দয়া করে সঠিক ইউপিআই আইডি লিখুন (যেমন: name@upi)।")
            return
        }
        viewModelScope.launch {
            val result = repository.savePaymentUpiId(trimmed)
            if (result.isSuccess) {
                showToast("ইউপিআই আপডেট সফল", "নতুন ইউপিআই আইডি: $trimmed লিংক করা হয়েছে।")
            } else {
                showPermissionOrErrorToast(result.exceptionOrNull())
            }
        }
    }

    fun triggerPaymentFlow() {
        localState.update { it.copy(showPaymentDialog = true) }
    }

    fun confirmSubscriptionUnlock() {
        viewModelScope.launch {
            val result = repository.updateUserSubscription(true)
            if (result.isSuccess) {
                localState.update { it.copy(showPaymentDialog = false) }
                showToast("সাবস্ক্রিপশন চালু!", "আপনার ₹১০ মাসিক কমিউনিটি প্যাক এখন সক্রিয় আছে।")
            } else {
                showPermissionOrErrorToast(result.exceptionOrNull())
            }
        }
    }

    fun dismissPaymentDialog() {
        localState.update { it.copy(showPaymentDialog = false) }
    }

    fun toggleSimulateTrialExpired(expired: Boolean) {
        viewModelScope.launch {
            repository.updateUserTrialExpired(expired)
        }
    }

    fun openNotificationSheet() {
        localState.update { it.copy(showNotificationSheet = true) }
    }

    fun closeNotificationSheet() {
        localState.update { it.copy(showNotificationSheet = false) }
    }

    fun showToast(title: String, message: String) {
        toastJob?.cancel()
        localState.update { it.copy(activeToast = ToastMessage(title, message)) }
        toastJob = viewModelScope.launch {
            delay(3800)
            localState.update { it.copy(activeToast = null) }
        }
    }

    fun dismissToast() {
        toastJob?.cancel()
        localState.update { it.copy(activeToast = null) }
    }

    private fun showPermissionOrErrorToast(error: Throwable?) {
        val firestoreEx = generateSequence(error) { it?.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreEx?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
            showToast("অনুমতি নেই", "শুধুমাত্র অ্যাডমিন একাউন্ট থেকে এটি পরিবর্তন করা যাবে।")
        } else {
            showToast("ত্রুটি", error?.localizedMessage ?: "ডেটা সেভ করা যায়নি।")
        }
    }

    private fun handleStreamFailure(streamName: String, error: Throwable) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        Log.w(TAG, "Error observing $streamName", firestoreError ?: error)
    }

    private fun extractDigits(input: String): String {
        val sb = StringBuilder()
        for (ch in input) {
            when (ch) {
                in '0'..'9' -> sb.append(ch)
                in '০'..'৯' -> sb.append(('0' + (ch - '০')))
            }
        }
        return sb.toString()
    }

    companion object {
        private const val TAG = "RationViewModel"
        private const val ADMIN_SECRET_PIN = "2580"
    }
}
