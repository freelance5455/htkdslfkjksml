package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.NewsCategoryTone
import com.example.data.local.StatusTone
import com.example.data.remote.RationScheduleDoc
import com.example.data.remote.UrgentBannerDoc
import com.example.data.remote.VillageNewsDoc
import com.example.ui.theme.Blue600
import com.example.ui.theme.Emerald100
import com.example.ui.theme.Emerald200
import com.example.ui.theme.Emerald50
import com.example.ui.theme.Emerald500
import com.example.ui.theme.Emerald600
import com.example.ui.theme.Emerald800
import com.example.ui.theme.Emerald900
import com.example.ui.theme.PureWhite
import com.example.ui.theme.Rose100
import com.example.ui.theme.Rose600
import com.example.ui.theme.Rose700
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate300
import com.example.ui.theme.Slate50
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900

private data class StatusPresetOption(
    val label: String,
    val statusText: String,
    val tone: StatusTone
)

private val StatusPresets = listOf(
    StatusPresetOption(
        label = "✅ রেশন চলছে (সকাল ১০:০০ - দুপুর ২:০০)",
        statusText = "চলছে (সকাল ১০:০০ - দুপুর ২:০০)",
        tone = StatusTone.EMERALD
    ),
    StatusPresetOption(
        label = "⏳ দেরি হচ্ছে: আজ সকাল ১১:০০ টায় শুরু",
        statusText = "দেরি হচ্ছে: আজ সকাল ১১:০০ টায় শুরু হবে",
        tone = StatusTone.AMBER
    ),
    StatusPresetOption(
        label = "⚠️ সময় পরিবর্তন: দুপুর ১২:০০ টা পর্যন্ত",
        statusText = "সময় পরিবর্তন: আজ দুপুর ১২:০০ টা পর্যন্ত চলবে",
        tone = StatusTone.ORANGE
    ),
    StatusPresetOption(
        label = "🛑 আজকের রেশন বিতরণ শেষ হয়েছে",
        statusText = "আজকের রেশন বিতরণ শেষ হয়েছে",
        tone = StatusTone.ROSE
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    schedules: List<RationScheduleDoc>,
    urgentBanner1: UrgentBannerDoc?,
    urgentBanner2: UrgentBannerDoc?,
    villageNews: List<VillageNewsDoc>,
    currentUpiId: String,
    isTrialExpiredSimulated: Boolean,
    onUpdatePrimaryRation: (String, StatusTone, String, String, String) -> Unit,
    onDeleteSchedule: (String) -> Unit,
    onToggleUrgentBanner: (Int, Boolean) -> Unit,
    onUpdateUrgentBanner: (Int, String, String, String) -> Unit,
    onDeleteUrgentBanner: (Int) -> Unit,
    onAddSchedule: (String, String, String, String, String) -> Unit,
    onAddNews: (String, NewsCategoryTone, String, String, String) -> Unit,
    onDeleteNews: (String) -> Unit,
    onSaveUpiId: (String) -> Unit,
    onSimulateTrialExpired: () -> Unit,
    modifier: Modifier = Modifier
) {
    val primarySchedule = schedules.firstOrNull()

    // Primary Ration Banner State
    var statusText by rememberSaveable { mutableStateOf(primarySchedule?.statusText ?: "চলছে (সকাল ১০:০০ - দুপুর ২:০০)") }
    var statusTone by rememberSaveable { mutableStateOf(StatusTone.EMERALD) }
    var locationInput by rememberSaveable { mutableStateOf(primarySchedule?.location ?: "") }
    var dateInput by rememberSaveable { mutableStateOf(primarySchedule?.dateLabel ?: "") }
    var addressInput by rememberSaveable { mutableStateOf(primarySchedule?.address ?: "") }
    var presetExpanded by remember { mutableStateOf(false) }
    var selectedPresetLabel by rememberSaveable { mutableStateOf(StatusPresets.first().label) }

    LaunchedEffect(primarySchedule?.id) {
        if (primarySchedule != null) {
            statusText = primarySchedule.statusText
            statusTone = runCatching { StatusTone.valueOf(primarySchedule.statusTone) }.getOrDefault(StatusTone.EMERALD)
            locationInput = primarySchedule.location
            dateInput = primarySchedule.dateLabel
            addressInput = primarySchedule.address
        }
    }

    // Banner 1 state
    var b1Date by rememberSaveable { mutableStateOf(urgentBanner1?.dateBadge ?: "") }
    var b1Title by rememberSaveable { mutableStateOf(urgentBanner1?.headline ?: "") }
    var b1Desc by rememberSaveable { mutableStateOf(urgentBanner1?.description ?: "") }
    LaunchedEffect(urgentBanner1) {
        if (urgentBanner1 != null) {
            b1Date = urgentBanner1.dateBadge
            b1Title = urgentBanner1.headline
            b1Desc = urgentBanner1.description
        } else {
            b1Date = ""
            b1Title = ""
            b1Desc = ""
        }
    }

    // Banner 2 state
    var b2Date by rememberSaveable { mutableStateOf(urgentBanner2?.dateBadge ?: "") }
    var b2Title by rememberSaveable { mutableStateOf(urgentBanner2?.headline ?: "") }
    var b2Desc by rememberSaveable { mutableStateOf(urgentBanner2?.description ?: "") }
    LaunchedEffect(urgentBanner2) {
        if (urgentBanner2 != null) {
            b2Date = urgentBanner2.dateBadge
            b2Title = urgentBanner2.headline
            b2Desc = urgentBanner2.description
        } else {
            b2Date = ""
            b2Title = ""
            b2Desc = ""
        }
    }

    // Add New Schedule state
    var newDay by rememberSaveable { mutableStateOf("") }
    var newDate by rememberSaveable { mutableStateOf("") }
    var newLoc by rememberSaveable { mutableStateOf("") }
    var newAddress by rememberSaveable { mutableStateOf("") }
    var newTime by rememberSaveable { mutableStateOf("") }

    // Add News state
    var newsCategory by rememberSaveable { mutableStateOf("গ্রাম্য অনুষ্ঠান") }
    var newsTone by rememberSaveable { mutableStateOf(NewsCategoryTone.ROSE) }
    var newsDate by rememberSaveable { mutableStateOf("") }
    var newsTitle by rememberSaveable { mutableStateOf("") }
    var newsDesc by rememberSaveable { mutableStateOf("") }

    // Admin UPI state
    var adminUpiInput by rememberSaveable { mutableStateOf(currentUpiId) }
    LaunchedEffect(currentUpiId) {
        adminUpiInput = currentUpiId
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .imePadding(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Admin Header Card
            item {
                Surface(
                    color = Slate900,
                    shape = RoundedCornerShape(24.dp),
                    shadowElevation = 4.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "অ্যাডমিন লাইভ কন্ট্রোল প্যানেল",
                                style = MaterialTheme.typography.titleSmall,
                                color = Emerald500
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "সকল ব্যানার ও রেশন শিডিউল সরাসরি লাইভ আপডেট করুন",
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate300
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Emerald500.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Shield,
                                contentDescription = stringResource(R.string.cd_admin_shield),
                                tint = Emerald500
                            )
                        }
                    }
                }
            }

            // ১. প্রধান রেশন ব্যানার লাইভ কন্ট্রোল + ডিলিট অপশন
            item {
                Surface(
                    color = Emerald50,
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, Emerald200),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(Emerald600)
                                )
                                Text(
                                    text = "রেশন ব্যানার (উপরের কার্ড) লাইভ আপডেট",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = Emerald900
                                )
                            }
                            Surface(color = Emerald600, shape = RoundedCornerShape(50)) {
                                Text(
                                    text = "লাইভ",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = PureWhite,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                                )
                            }
                        }

                        ExposedDropdownMenuBox(
                            expanded = presetExpanded,
                            onExpandedChange = { presetExpanded = !presetExpanded }
                        ) {
                            OutlinedTextField(
                                value = selectedPresetLabel,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("দ্রুত সময়/স্ট্যাটাস বেছে নিন") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = presetExpanded) },
                                colors = adminFieldColors(Emerald600),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                    .fillMaxWidth()
                            )
                            ExposedDropdownMenu(
                                expanded = presetExpanded,
                                onDismissRequest = { presetExpanded = false }
                            ) {
                                StatusPresets.forEach { preset ->
                                    DropdownMenuItem(
                                        text = { Text(preset.label, style = MaterialTheme.typography.bodySmall) },
                                        onClick = {
                                            selectedPresetLabel = preset.label
                                            statusText = preset.statusText
                                            statusTone = preset.tone
                                            presetExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = statusText,
                            onValueChange = { statusText = it },
                            label = { Text("সময় বা স্ট্যাটাস লিখুন") },
                            colors = adminFieldColors(Emerald600),
                            shape = RoundedCornerShape(14.dp),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_live_status_input")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = locationInput,
                                onValueChange = { locationInput = it },
                                label = { Text("জায়গার নাম") },
                                colors = adminFieldColors(Emerald600),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = dateInput,
                                onValueChange = { dateInput = it },
                                label = { Text("তারিখ") },
                                colors = adminFieldColors(Emerald600),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.weight(0.9f)
                            )
                        }

                        OutlinedTextField(
                            value = addressInput,
                            onValueChange = { addressInput = it },
                            label = { Text("ঠিকানা / বিবরণ") },
                            colors = adminFieldColors(Emerald600),
                            shape = RoundedCornerShape(14.dp),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = {
                                onUpdatePrimaryRation(
                                    statusText,
                                    statusTone,
                                    locationInput,
                                    dateInput,
                                    addressInput
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Emerald600),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("admin_update_ration_button")
                        ) {
                            Icon(Icons.Filled.Radio, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "রেশন ব্যানার লাইভ আপডেট করুন ও নোটিফিকেশন পাঠান",
                                style = MaterialTheme.typography.labelMedium
                            )
                        }

                        if (primarySchedule != null) {
                            OutlinedButton(
                                onClick = {
                                    onDeleteSchedule(primarySchedule.id)
                                    locationInput = ""
                                    dateInput = ""
                                    addressInput = ""
                                },
                                border = BorderStroke(1.dp, Rose600),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Rose700),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                                    .testTag("admin_delete_primary_ration_button")
                            ) {
                                Icon(Icons.Filled.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("প্রধান রেশন ব্যানার ডিলিট করুন", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }

            // ২. বিজ্ঞপ্তি ব্যানার ১ (লাল) + ডিলিট অপশন
            item {
                BannerAdminEditorCard(
                    title = "বিজ্ঞপ্তি ব্যানার ১ (লাল) লাইভ কন্ট্রোল",
                    dotColor = Rose600,
                    buttonColor = Rose600,
                    buttonText = "বিজ্ঞপ্তি ব্যানার ১ লাইভ আপডেট করুন",
                    deleteButtonText = "ব্যানার ১ ডিলিট করুন",
                    hasExistingBanner = urgentBanner1 != null,
                    isVisible = urgentBanner1?.isVisible ?: false,
                    dateBadge = b1Date,
                    headline = b1Title,
                    description = b1Desc,
                    onToggle = { onToggleUrgentBanner(1, it) },
                    onDateChange = { b1Date = it },
                    onHeadlineChange = { b1Title = it },
                    onDescChange = { b1Desc = it },
                    onSubmit = { onUpdateUrgentBanner(1, b1Date, b1Title, b1Desc) },
                    onDelete = { onDeleteUrgentBanner(1) },
                    testTagPrefix = "admin_banner_1"
                )
            }

            // ৩. বিজ্ঞপ্তি ব্যানার ২ (নীল) + ডিলিট অপশন
            item {
                BannerAdminEditorCard(
                    title = "বিজ্ঞপ্তি ব্যানার ২ (নীল) লাইভ কন্ট্রোল",
                    dotColor = Blue600,
                    buttonColor = Blue600,
                    buttonText = "বিজ্ঞপ্তি ব্যানার ২ লাইভ আপডেট করুন",
                    deleteButtonText = "ব্যানার ২ ডিলিট করুন",
                    hasExistingBanner = urgentBanner2 != null,
                    isVisible = urgentBanner2?.isVisible ?: false,
                    dateBadge = b2Date,
                    headline = b2Title,
                    description = b2Desc,
                    onToggle = { onToggleUrgentBanner(2, it) },
                    onDateChange = { b2Date = it },
                    onHeadlineChange = { b2Title = it },
                    onDescChange = { b2Desc = it },
                    onSubmit = { onUpdateUrgentBanner(2, b2Date, b2Title, b2Desc) },
                    onDelete = { onDeleteUrgentBanner(2) },
                    testTagPrefix = "admin_banner_2"
                )
            }

            // ৪. নতুন একটি শিডিউল লিখার অপশন + ডিলিট তালিকা
            item {
                Surface(
                    color = PureWhite,
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, Slate200),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "নতুন রেশন শিডিউল লিখুন",
                            style = MaterialTheme.typography.labelLarge,
                            color = Slate800
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = newDay,
                                onValueChange = { newDay = it },
                                label = { Text("বার / দিন") },
                                placeholder = { Text("যেমন: মঙ্গলবার") },
                                colors = adminFieldColors(Emerald600),
                                shape = RoundedCornerShape(14.dp),
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("admin_new_schedule_date")
                            )
                            OutlinedTextField(
                                value = newDate,
                                onValueChange = { newDate = it },
                                label = { Text("তারিখ") },
                                placeholder = { Text("১৭ নভেম্বর, ২০২৬") },
                                colors = adminFieldColors(Emerald600),
                                shape = RoundedCornerShape(14.dp),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        OutlinedTextField(
                            value = newLoc,
                            onValueChange = { newLoc = it },
                            label = { Text("এলাকা বা লোকেশনের নাম") },
                            placeholder = { Text("যেমন: রক্সীমোড় বাজার") },
                            colors = adminFieldColors(Emerald600),
                            shape = RoundedCornerShape(14.dp),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_new_schedule_location")
                        )
                        OutlinedTextField(
                            value = newAddress,
                            onValueChange = { newAddress = it },
                            label = { Text("ঠিকানা") },
                            placeholder = { Text("যেমন: পুরোনো বাসস্ট্যান্ড সংলগ্ন") },
                            colors = adminFieldColors(Emerald600),
                            shape = RoundedCornerShape(14.dp),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = newTime,
                            onValueChange = { newTime = it },
                            label = { Text("সময়") },
                            placeholder = { Text("যেমন: সকাল ১০:০০ - দুপুর ১:০০") },
                            colors = adminFieldColors(Emerald600),
                            shape = RoundedCornerShape(14.dp),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = {
                                onAddSchedule(newDay, newDate, newLoc, newAddress, newTime)
                                if (newDay.isNotBlank() && newLoc.isNotBlank()) {
                                    newDay = ""
                                    newDate = ""
                                    newLoc = ""
                                    newAddress = ""
                                    newTime = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Emerald600),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("admin_add_schedule_button")
                        ) {
                            Icon(Icons.Filled.AddCircleOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "নতুন শিডিউল সেভ ও নোটিফিকেশন পাঠান",
                                style = MaterialTheme.typography.labelMedium
                            )
                        }

                        if (schedules.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "প্রকাশিত রেশন শিডিউলসমূহ (${schedules.size})",
                                style = MaterialTheme.typography.labelMedium,
                                color = Slate700
                            )
                            schedules.forEach { item ->
                                Surface(
                                    color = Slate50,
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.dp, Slate200),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "${item.dayLabel} (${item.dateLabel})",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = Emerald800
                                            )
                                            Text(
                                                text = item.location,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Slate900
                                            )
                                        }
                                        IconButton(
                                            onClick = { onDeleteSchedule(item.id) },
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(Rose100)
                                                .testTag("admin_delete_schedule_${item.id}")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.DeleteOutline,
                                                contentDescription = "শিডিউল ডিলিট করুন",
                                                tint = Rose700,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ৫. অ্যাডমিনের অফিশিয়াল ইউপিআই (UPI) আইডি সেটিংস (সাবস্ক্রিপশন স্ক্রিনে লিংকড)
            item {
                Surface(
                    color = PureWhite,
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, Slate200),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CreditCard,
                                contentDescription = null,
                                tint = Emerald600,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "অফিশিয়াল ইউপিআই (UPI) আইডি সেট করুন",
                                style = MaterialTheme.typography.labelLarge,
                                color = Slate800
                            )
                        }
                        Text(
                            text = "এখানে সেট করা ইউপিআই আইডি সরাসরি সাবস্ক্রিপশন পেমেন্ট বাটনে লিংক হয়ে যাবে।",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate600
                        )
                        OutlinedTextField(
                            value = adminUpiInput,
                            onValueChange = { adminUpiInput = it },
                            label = { Text("ইউপিআই আইডি") },
                            placeholder = { Text("যেমন: yourname@paytm") },
                            singleLine = true,
                            colors = adminFieldColors(Emerald600),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_upi_input")
                        )
                        Button(
                            onClick = { onSaveUpiId(adminUpiInput) },
                            colors = ButtonDefaults.buttonColors(containerColor = Emerald600),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("save_upi_button")
                        ) {
                            Text("ইউপিআই আইডি সেভ ও লিংক করুন", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }

            // ৬. গ্রামের খবর পোস্ট ফর্ম + ডিলিট তালিকা
            item {
                Surface(
                    color = PureWhite,
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, Slate200),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "নতুন গ্রামের খবর প্রকাশ করুন",
                            style = MaterialTheme.typography.labelLarge,
                            color = Slate800
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(
                                "গ্রাম্য অনুষ্ঠান" to NewsCategoryTone.ROSE,
                                "স্বাস্থ্য ক্যাম্প" to NewsCategoryTone.BLUE,
                                "পঞ্চায়েত সংবাদ" to NewsCategoryTone.EMERALD
                            ).forEach { (cat, tone) ->
                                FilterChip(
                                    selected = newsCategory == cat,
                                    onClick = {
                                        newsCategory = cat
                                        newsTone = tone
                                    },
                                    label = { Text(cat, style = MaterialTheme.typography.labelSmall) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Emerald100,
                                        selectedLabelColor = Emerald800
                                    )
                                )
                            }
                        }
                        OutlinedTextField(
                            value = newsDate,
                            onValueChange = { newsDate = it },
                            label = { Text("তারিখ") },
                            placeholder = { Text("যেমন: আজ, ১৪ নভেম্বর") },
                            colors = adminFieldColors(Emerald600),
                            shape = RoundedCornerShape(14.dp),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = newsTitle,
                            onValueChange = { newsTitle = it },
                            label = { Text("খবরের শিরোনাম") },
                            colors = adminFieldColors(Emerald600),
                            shape = RoundedCornerShape(14.dp),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = newsDesc,
                            onValueChange = { newsDesc = it },
                            label = { Text("বিস্তারিত বিবরণ") },
                            colors = adminFieldColors(Emerald600),
                            shape = RoundedCornerShape(14.dp),
                            minLines = 2,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = {
                                onAddNews(newsCategory, newsTone, newsDate, newsTitle, newsDesc)
                                if (newsTitle.isNotBlank() && newsDesc.isNotBlank()) {
                                    newsDate = ""
                                    newsTitle = ""
                                    newsDesc = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Slate900),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("admin_add_news_button")
                        ) {
                            Icon(Icons.Filled.Newspaper, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("গ্রামের খবর প্রকাশ করুন", style = MaterialTheme.typography.labelMedium)
                        }

                        if (villageNews.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "প্রকাশিত গ্রামের খবর (${villageNews.size})",
                                style = MaterialTheme.typography.labelMedium,
                                color = Slate700
                            )
                            villageNews.forEach { news ->
                                Surface(
                                    color = Slate50,
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.dp, Slate200),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = news.title,
                                                style = MaterialTheme.typography.labelMedium,
                                                color = Slate900
                                            )
                                            Text(
                                                text = "${news.category} • ${news.dateLabel}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Slate600
                                            )
                                        }
                                        IconButton(
                                            onClick = { onDeleteNews(news.id) },
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(Rose100)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.DeleteOutline,
                                                contentDescription = "খবর ডিলিট করুন",
                                                tint = Rose700,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ৭. ট্রায়াল লক প্রিভিউ টেস্ট
            item {
                Surface(
                    color = Slate50,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Slate200),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "৭ দিনের ট্রায়াল লক স্ক্রিন প্রিভিউ",
                                style = MaterialTheme.typography.labelLarge,
                                color = Slate800
                            )
                            Text(
                                text = "মেয়াদ শেষ হলে ইউজার কেমন স্ক্রিন দেখবে তা পরীক্ষা করুন",
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate600
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedButton(
                            onClick = onSimulateTrialExpired,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("simulate_trial_lock_button")
                        ) {
                            Icon(Icons.Filled.LockClock, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isTrialExpiredSimulated) "লক চালু" else "প্রিভিউ", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun BannerAdminEditorCard(
    title: String,
    dotColor: Color,
    buttonColor: Color,
    buttonText: String,
    deleteButtonText: String,
    hasExistingBanner: Boolean,
    isVisible: Boolean,
    dateBadge: String,
    headline: String,
    description: String,
    onToggle: (Boolean) -> Unit,
    onDateChange: (String) -> Unit,
    onHeadlineChange: (String) -> Unit,
    onDescChange: (String) -> Unit,
    onSubmit: () -> Unit,
    onDelete: () -> Unit,
    testTagPrefix: String
) {
    Surface(
        color = PureWhite,
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, Slate200),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(dotColor)
                    )
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelLarge,
                        color = Slate800
                    )
                }
                Switch(
                    checked = isVisible,
                    onCheckedChange = onToggle,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = PureWhite,
                        checkedTrackColor = dotColor
                    ),
                    modifier = Modifier.testTag("${testTagPrefix}_switch")
                )
            }

            OutlinedTextField(
                value = dateBadge,
                onValueChange = onDateChange,
                label = { Text("তারিখ/সময় ব্যাজ") },
                colors = adminFieldColors(dotColor),
                shape = RoundedCornerShape(14.dp),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = headline,
                onValueChange = onHeadlineChange,
                label = { Text("শিরোনাম (Headline)") },
                colors = adminFieldColors(dotColor),
                shape = RoundedCornerShape(14.dp),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("${testTagPrefix}_headline")
            )
            OutlinedTextField(
                value = description,
                onValueChange = onDescChange,
                label = { Text("বিস্তারিত বিবরণ (Description)") },
                colors = adminFieldColors(dotColor),
                shape = RoundedCornerShape(14.dp),
                minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = onSubmit,
                colors = ButtonDefaults.buttonColors(containerColor = buttonColor),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("${testTagPrefix}_submit")
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = buttonText, style = MaterialTheme.typography.labelMedium)
            }

            if (hasExistingBanner) {
                OutlinedButton(
                    onClick = onDelete,
                    border = BorderStroke(1.dp, Rose600),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Rose700),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("${testTagPrefix}_delete")
                ) {
                    Icon(Icons.Filled.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = deleteButtonText, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
private fun adminFieldColors(accent: Color) = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = accent,
    unfocusedBorderColor = Slate200,
    focusedContainerColor = PureWhite,
    unfocusedContainerColor = PureWhite,
    focusedLabelColor = accent,
    unfocusedLabelColor = Slate700
)
