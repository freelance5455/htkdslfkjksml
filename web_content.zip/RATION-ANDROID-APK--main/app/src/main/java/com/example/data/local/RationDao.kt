package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RationDao {

    @Query("SELECT * FROM ration_schedules ORDER BY sortOrder ASC, id ASC")
    fun observeSchedules(): Flow<List<RationScheduleEntity>>

    @Query("SELECT * FROM ration_schedules ORDER BY sortOrder ASC, id ASC LIMIT 1")
    suspend fun getPrimarySchedule(): RationScheduleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: RationScheduleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedules(schedules: List<RationScheduleEntity>)

    @Update
    suspend fun updateSchedule(schedule: RationScheduleEntity)

    @Query("DELETE FROM ration_schedules WHERE id = :id")
    suspend fun deleteSchedule(id: Int)

    @Query("SELECT * FROM urgent_banners ORDER BY id ASC")
    fun observeUrgentBanners(): Flow<List<UrgentBannerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertUrgentBanner(banner: UrgentBannerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUrgentBanners(banners: List<UrgentBannerEntity>)

    @Query("SELECT * FROM village_news ORDER BY createdAtMillis DESC, id DESC")
    fun observeVillageNews(): Flow<List<VillageNewsEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNews(news: VillageNewsEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllNews(newsList: List<VillageNewsEntity>)

    @Query("SELECT * FROM notifications ORDER BY createdAtMillis DESC, id DESC LIMIT 30")
    fun observeNotifications(): Flow<List<NotificationItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationItemEntity)
}
