package com.example.data.remote

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserAccountDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    @get:PropertyName("isSubscribed") @field:PropertyName("isSubscribed")
    val isSubscribed: Boolean = false,
    @get:PropertyName("isTrialExpired") @field:PropertyName("isTrialExpired")
    val isTrialExpired: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class RationScheduleDoc(
    @DocumentId val id: String = "",
    val dayLabel: String = "",
    val dateLabel: String = "",
    val location: String = "",
    val address: String = "",
    val statusText: String = "",
    val statusTone: String = "EMERALD",
    val sortOrder: Long = 0L,
    @get:PropertyName("isPublic") @field:PropertyName("isPublic")
    val isPublic: Boolean = true,
    val createdBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class UrgentBannerDoc(
    @DocumentId val id: String = "",
    val bannerNumber: Long = 1L,
    @get:PropertyName("isVisible") @field:PropertyName("isVisible")
    val isVisible: Boolean = true,
    val dateBadge: String = "",
    val headline: String = "",
    val description: String = "",
    @get:PropertyName("isPublic") @field:PropertyName("isPublic")
    val isPublic: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class VillageNewsDoc(
    @DocumentId val id: String = "",
    val category: String = "",
    val categoryTone: String = "ROSE",
    val dateLabel: String = "",
    val title: String = "",
    val description: String = "",
    @get:PropertyName("isPublic") @field:PropertyName("isPublic")
    val isPublic: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class NotificationDoc(
    @DocumentId val id: String = "",
    val title: String = "",
    val message: String = "",
    val timeLabel: String = "",
    @get:PropertyName("isPublic") @field:PropertyName("isPublic")
    val isPublic: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PaymentSettingsDoc(
    @DocumentId val id: String = "",
    val upiId: String = "rationdokan@upi",
    @get:PropertyName("isPublic") @field:PropertyName("isPublic")
    val isPublic: Boolean = true,
    val updatedBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
