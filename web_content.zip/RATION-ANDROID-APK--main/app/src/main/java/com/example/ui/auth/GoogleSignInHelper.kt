package com.example.ui.auth

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.FirebaseException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

const val ADMIN_EMAIL = "onlinekutir@gmail.com"

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

fun extractAsciiDigits(input: String): String {
    val sb = StringBuilder(input.length)
    for (ch in input) {
        when (ch) {
            in '0'..'9' -> sb.append(ch)
            in '০'..'৯' -> sb.append(('0' + (ch - '০')))
        }
    }
    return sb.toString()
}

fun formatPhoneForFirebase(rawInput: String): String {
    val trimmed = rawInput.trim()
    val digits = extractAsciiDigits(trimmed)
    return when {
        trimmed.startsWith("+") && digits.length in 10..15 -> "+$digits"
        digits.length == 10 -> "+91$digits"
        digits.length == 12 && digits.startsWith("91") -> "+$digits"
        else -> ""
    }
}

fun sendPhoneOtp(
    context: Context,
    rawPhone: String,
    resendToken: PhoneAuthProvider.ForceResendingToken?,
    scope: CoroutineScope,
    onCodeSent: (verificationId: String, token: PhoneAuthProvider.ForceResendingToken, formattedPhone: String) -> Unit,
    onAutoVerified: () -> Unit,
    onError: (String) -> Unit
) {
    val formattedPhone = formatPhoneForFirebase(rawPhone)
    if (formattedPhone.isBlank()) {
        onError("দয়া করে সঠিক ১০ সংখ্যার মোবাইল নাম্বার লিখুন।")
        return
    }
    val activity = context.findActivity()
    if (activity == null) {
        onError("অ্যাক্টিভিটি পাওয়া যায়নি, আবার চেষ্টা করুন।")
        return
    }

    val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        override fun onVerificationCompleted(credential: PhoneAuthCredential) {
            scope.launch {
                try {
                    Firebase.auth.signInWithCredential(credential).await()
                    onAutoVerified()
                } catch (e: Exception) {
                    Log.e("PhoneAuth", "Auto sign-in with PhoneAuthCredential failed", e)
                    onError(mapPhoneAuthError(e))
                }
            }
        }

        override fun onVerificationFailed(e: FirebaseException) {
            Log.w("PhoneAuth", "Phone verification failed: ${e.message}", e)
            onError(mapPhoneAuthError(e))
        }

        override fun onCodeSent(
            verificationId: String,
            token: PhoneAuthProvider.ForceResendingToken
        ) {
            onCodeSent(verificationId, token, formattedPhone)
        }
    }

    val builder = PhoneAuthOptions.newBuilder(Firebase.auth)
        .setPhoneNumber(formattedPhone)
        .setTimeout(60L, TimeUnit.SECONDS)
        .setActivity(activity)
        .setCallbacks(callbacks)

    if (resendToken != null) {
        builder.setForceResendingToken(resendToken)
    }

    PhoneAuthProvider.verifyPhoneNumber(builder.build())
}

fun verifyPhoneOtp(
    verificationId: String,
    rawOtp: String,
    scope: CoroutineScope,
    onSuccess: () -> Unit,
    onError: (String) -> Unit
) {
    val cleanOtp = extractAsciiDigits(rawOtp)
    if (cleanOtp.length != 6) {
        onError("দয়া করে ৬ সংখ্যার সঠিক ওটিপি কোড লিখুন।")
        return
    }
    if (verificationId.isBlank()) {
        onError("ওটিপি সেশন পাওয়া যায়নি। অনুগ্রহ করে আবার ওটিপি পাঠান।")
        return
    }

    val credential = PhoneAuthProvider.getCredential(verificationId, cleanOtp)
    scope.launch {
        try {
            Firebase.auth.signInWithCredential(credential).await()
            onSuccess()
        } catch (e: Exception) {
            Log.w("PhoneAuth", "OTP verification failed", e)
            onError(mapPhoneAuthError(e))
        }
    }
}

private fun mapPhoneAuthError(error: Exception): String {
    return when (error) {
        is FirebaseAuthInvalidCredentialsException ->
            "ভুল ওটিপি বা মোবাইল নাম্বার। অনুগ্রহ করে সঠিক তথ্য দিন।"
        is FirebaseTooManyRequestsException ->
            "অনেকবার চেষ্টা করা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।"
        is FirebaseAuthException -> {
            val code = error.errorCode
            if (code.contains("OPERATION_NOT_ALLOWED") || code.contains("MISSING_CLIENT_IDENTIFIER")) {
                "ফায়ারবেস কনসোলে Phone Authentication চালু করা প্রয়োজন (Authentication -> Sign-in method -> Phone)।"
            } else {
                error.localizedMessage ?: "মোবাইল যাচাই ব্যর্থ হয়েছে।"
            }
        }
        else -> {
            val msg = error.localizedMessage ?: ""
            if (msg.contains("CONFIGURATION_NOT_FOUND", ignoreCase = true) ||
                msg.contains("not allowed", ignoreCase = true)
            ) {
                "ফায়ারবেস কনসোলে Phone Authentication চালু করুন এবং অ্যাপের SHA-1/SHA-256 কনফিগার করুন।"
            } else {
                msg.ifBlank { "ওটিপি যাচাই করা যায়নি। আবার চেষ্টা করুন।" }
            }
        }
    }
}

private fun resolveWebClientId(context: Context): String? {
    val resId = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
    if (resId == 0) return null
    return runCatching { context.getString(resId).trim() }
        .getOrNull()
        ?.takeIf { it.isNotEmpty() }
}

fun attemptAutoSignIn(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onUnauthenticated: () -> Unit,
    scope: CoroutineScope
) {
    if (Firebase.auth.currentUser != null) {
        onAuthSuccess()
        return
    }
    val clientId = resolveWebClientId(context)
    if (clientId == null) {
        onUnauthenticated()
        return
    }

    val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(true)
        .build()

    val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()

    scope.launch {
        try {
            val result = credentialManager.getCredential(context, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                Firebase.auth.signInWithCredential(authCredential).await()
                onAuthSuccess()
            } else {
                onUnauthenticated()
            }
        } catch (_: Exception) {
            onUnauthenticated()
        }
    }
}

fun onGoogleSignInClicked(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope,
    onAuthCancelled: () -> Unit = {},
    requireAdminAccount: Boolean = false
) {
    val clientId = resolveWebClientId(context)
    if (clientId == null) {
        onAuthError("গুগল সাইন-ইন কনফিগার করা নেই। Firebase Console-এ SHA-1 যুক্ত করে Google Sign-In চালু করুন এবং নতুন google-services.json আপলোড করুন।")
        return
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(signInOption)
        .build()

    scope.launch {
        try {
            val activityContext = context.findActivity()
                ?: throw IllegalStateException("Google Sign-In requires an Activity context.")
            val result = credentialManager.getCredential(activityContext, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                val authResult = Firebase.auth.signInWithCredential(authCredential).await()
                val signedInUser = authResult.user
                if (requireAdminAccount) {
                    val isAdmin = isAuthorizedAdminUser(context, signedInUser)
                    if (!isAdmin) {
                        signOutFromFirebase(credentialManager, scope)
                        onAuthError("জিমেইল দিয়ে শুধুমাত্র অ্যাডমিন লগইন করতে পারবেন। সাধারণ ইউজাররা মোবাইল নাম্বার ও ওটিপি ব্যবহার করুন।")
                        return@launch
                    }
                }
                onAuthSuccess()
            } else {
                onAuthError("Unexpected credential type")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("Auth", "Google Sign-In flow cancelled or dismissed: ${e.message}", e)
            onAuthCancelled()
        } catch (e: Exception) {
            Log.e("Auth", "Google Sign-In failed", e)
            onAuthError(e.localizedMessage ?: "Sign in failed")
        }
    }
}

private suspend fun isAuthorizedAdminUser(context: Context, user: FirebaseUser?): Boolean {
    if (user == null) return false
    if (user.email.equals(ADMIN_EMAIL, ignoreCase = true)) return true
    return try {
        val dbId = context.applicationContext.getString(R.string.firestore_database_id)
        val db = FirebaseFirestore.getInstance(dbId)
        db.collection("admins").document(user.uid).get().await().exists()
    } catch (_: Exception) {
        false
    }
}

fun signOutFromFirebase(
    credentialManager: CredentialManager,
    scope: CoroutineScope,
    onSignOutComplete: () -> Unit = {}
) {
    scope.launch {
        withContext(NonCancellable) {
            try {
                credentialManager.clearCredentialState(ClearCredentialStateRequest())
            } catch (e: Exception) {
                Log.w("Auth", "Failed to clear credential state: ${e.message}")
            } finally {
                Firebase.auth.signOut()
                onSignOutComplete()
            }
        }
    }
}
