# Vehicle Comparison 2025–2026 — Android Source Project

මෙය HONOR 400 ඇතුළු Android 10 (API 29) හෝ ඉහළ දුරකථන සඳහා Android Studio project එකකි.

## ඇතුළත් පහසුකම්
- 2025 සහ 2026 සඳහා වෙන වෙනම දෛනික වාහන ගණන ඇතුළත් කිරීම.
- එකම දිනයේ නැවත Save කළ විට එම දිනයේ පැරණි අගය යාවත්කාලීන කිරීම.
- තෝරාගත් මාසයක දිනෙන් දින දත්ත සැසඳීම.
- ජනවාරි සිට දෙසැම්බර් දක්වා මාසික එකතුව සහ වාර්ෂික එකතුව.
- 2026 - 2025 වෙනස සහ 2025 අගය පදනම් කරගත් ප්‍රතිශතය.
- 2025 අගයට සමාන වීමට 2026 දී තව අවශ්‍ය වාහන ගණන.
- Excel මඟින් විවෘත කළ හැකි UTF-8 CSV වාර්තාව.
- Android Print සේවාව හරහා PDF ලෙස Save කිරීම.
- JSON Backup සහ Restore.
- Internet අවශ්‍ය නොවන local storage.
- App icon.

## APK එක Build කිරීම (Windows)
1. Android Studio ස්ථාපනය කරන්න.
2. මෙම ZIP එක Extract කරන්න.
3. Android Studio → **Open** → `VehicleComparison2025_2026` folder එක තෝරන්න.
4. Gradle Sync සම්පූර්ණ වීමට ඉඩ දෙන්න. Android SDK Platform 35 සහ JDK 17 අවශ්‍ය විය හැක.
5. **Build → Build Bundle(s) / APK(s) → Build APK(s)** තෝරන්න.
6. Build සාර්ථක වූ විට `app/build/outputs/apk/debug/app-debug.apk` ගොනුව ලැබේ.
7. APK එක HONOR 400 වෙත යවා විවෘත කරන්න. අවශ්‍ය නම් Settings තුළින් ඔබ භාවිත කරන File Manager එකට Install unknown apps අවසරය දෙන්න.

## වැදගත් සටහන්
- මෙම ZIP එක Android Studio source project එකයි; මෙහි APK binary එක ඇතුළත් නොවේ.
- මෙම පරිසරයේ Android SDK/Gradle build chain නොමැති නිසා APK එක compile කර device එකකින් පරීක්ෂා කර නැත.
- Excel වාර්තාව `.csv` ආකාරයෙනි. Microsoft Excel සහ බොහෝ spreadsheet apps මඟින් විවෘත කළ හැකියි; මෙය native `.xlsx` ගොනුවක් නොවේ.
- PDF සඳහා Android Print dialog එකේ **Save as PDF** තෝරන්න.
- දත්ත WebView local storage තුළ දුරකථනයේම තබාගනී. App data clear කිරීම හෝ uninstall කිරීමෙන් ඒවා නැතිවිය හැකි බැවින් JSON Backup නිතර ගන්න.
- Restore කිරීමේදී Backup එකේ අගයන් දැනට ඇති දත්ත සමඟ merge වේ. එකම දිනයක් තිබේ නම් Backup අගය භාවිතා වේ.
