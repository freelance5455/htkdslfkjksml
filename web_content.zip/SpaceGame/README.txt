SPACE GAME - Android project (turns into an offline app: "Space Game")
=======================================================================
Result: a real APK. Tap the "Space Game" icon -> the game opens fullscreen, landscape.
The finished APK contains everything (even the 3D engine), so it works 100% OFFLINE.
Internet is needed ONLY while building the APK, never while playing.

I could not compile the APK inside the chat (no Android SDK there), so build it once:

OPTION A - on a PC (about 5 minutes)
1. Install Android Studio (free): https://developer.android.com/studio
2. Unzip, then File > Open > choose the "SpaceGame" folder. Wait for Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s) > "locate".
   APK = app/build/outputs/apk/debug/app-debug.apk
4. Send the APK to your phone and install it (allow "install unknown apps").

OPTION B - in the cloud with GitHub (no Android Studio)
1. Make a free GitHub account, create a new repository, upload ALL files of this
   folder (including the hidden .github folder).
2. Open the "Actions" tab > "Build APK" > Run workflow.
3. When finished, download "SpaceGame-APK" from the run page; unzip it to get the APK.

The game itself is app/src/main/assets/index.html

v3 NOTE: three.min.js is NOT in this zip. Put three.min.js (r128) into app/src/main/assets/ for 100% offline play; otherwise the game loads it from the internet.
