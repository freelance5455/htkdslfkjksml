KaamKartar Android project

یہ Android Studio project آپ کی فراہم کردہ flg.html فائل کو WebView میں چلاتا ہے۔

APK بنانے کا طریقہ:
1. کمپیوٹر پر Android Studio نصب کریں۔
2. اس ZIP کو extract کریں۔
3. Android Studio میں KaamKartar فولڈر کھولیں۔
4. Gradle sync مکمل ہونے دیں (انٹرنیٹ درکار ہوگا)۔
5. Build > Build Bundle(s) / APK(s) > Build APK(s) منتخب کریں۔
6. APK یہاں ملے گی: app/build/outputs/apk/debug/app-debug.apk

اہم:
- ایپ کو Firebase، Tailwind CDN، Font Awesome، Leaflet اور Google Fonts کے لیے انٹرنیٹ درکار ہے۔
- Firebase کی موجودہ configuration HTML میں جوں کی توں رکھی گئی ہے۔ حقیقی استعمال سے پہلے Firebase Console میں Authentication، Firestore rules اور authorized domains/configuration ضرور verify کریں۔
- یہ project source wrapper ہے، پہلے سے compiled APK نہیں۔ اس ماحول میں Android SDK/Gradle build tools دستیاب نہیں، اس لیے APK یہاں compile نہیں ہو سکی۔
