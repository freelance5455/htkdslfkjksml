plugins { id("com.android.application") }

android {
    namespace = "com.kaamkartar.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kaamkartar.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
