# Lost Prehistoria — terror e sobrevivência com dinossauros (Android)

Jogo em **primeira pessoa (3D por raycasting)**, escuro e tenso, feito para celulares intermediários (alvo: Galaxy A15 4G, 4 GB de RAM).
Caixotes, barris, consoles, blocos, contêineres e todos os itens são **objetos 3D de verdade** (laterais e topo, perspectiva correta). Os dinossauros são sprites 2D (renderizados a partir de modelos 3D). A câmera **olha para cima e para baixo**.
Cinco áreas, cinco dinossauros com IA diferente, documentos/gravações/terminais, esconderijos, itens limitados, checkpoints e dois finais.

## ⚠️ Estado honesto desta entrega
- **O APK NÃO foi compilado aqui.** O ambiente de desenvolvimento não tinha Android SDK, Gradle nem internet. O projeto Android está completo e há um workflow que gera o APK sozinho (abaixo).
- **Nada foi testado em celular real.** O jogo foi testado em Node e em Chromium headless (viewport do A15 em paisagem, toque multi-dedo simulado). Desempenho e sensação de controle no A15 ainda precisam ser confirmados por você.
- O `MainActivity.java` foi checado só contra *stubs* da API (sintaxe/consistência), não contra o `android.jar` real.

## Como gerar o APK (escolha um)
**A) GitHub Actions — não precisa instalar nada**
1. Crie um repositório no GitHub e envie o conteúdo desta pasta (todos os arquivos, incluindo `.github/`).
2. Aba **Actions → "Compilar APK (Lost Prehistoria)" → Run workflow**.
3. Ao terminar (uns 3–6 min), baixe o artefato **LostPrehistoria-apk** → `app-debug.apk`.
4. No celular: copie o APK, abra, permita "instalar apps desconhecidos" para o app usado e instale.

**B) Android Studio**
1. *File → Open* nesta pasta. O Studio baixa o Gradle 8.7 sozinho (usa `gradle/wrapper/gradle-wrapper.properties`).
2. *Build → Build Bundle(s)/APK(s) → Build APK(s)*. Saída: `app/build/outputs/apk/debug/app-debug.apk`.

**C) Linha de comando** (com JDK 17 + Android SDK 34 + Gradle 8.7): `gradle assembleDebug`

O `app-debug.apk` já sai assinado com a chave de depuração e instala direto. Compatível com Android 7.0+ (minSdk 24), qualquer arquitetura (sem código nativo). Requer o *Android System WebView* atualizado (vem com o sistema).

**Testar sem APK:** `cd app/src/main/assets/www && python3 -m http.server 8000` e abra `http://IP-DO-PC:8000` no Chrome do celular (paisagem, mesma rede Wi-Fi).

## Apareceu "Vire o celular de lado" e não gira?
- **No APK**, o app agora força a horizontal sozinho (`setRequestedOrientation` + `sensorLandscape`), mesmo com a rotação automática desligada. Se o aviso aparecer, você provavelmente está abrindo o jogo no **navegador** ou num APK gerado por outro conversor (que não trava a horizontal).
- O aviso agora tem **botões de verdade**: **"Jogar com a tela girada"** (o jogo gira por CSS e você só precisa deitar o celular, funciona com a rotação automática desligada; o menu de pausa tem "Girar a tela para o outro lado" se ficar de cabeça para baixo) e **"Tentar tela cheia e girar"** (funciona em alguns navegadores).
- Ou ligue a **rotação automática** no painel de notificações (arraste a tela de cima para baixo e toque no ícone de rotação).

## Controles (toque)
- **Metade esquerda:** joystick flutuante (andar). Empurrar até o fim = **correr** (faz barulho, gasta fôlego).
- **Metade direita:** arrastar para olhar, em qualquer direção (cima/baixo também). Há a opção "Inverter olhar vertical" nas configurações. Botões: **Usar** (contextual), **Correr** (trava), **Agachar**, **Lanterna**, **Lançar** (garrafa que cria ruído), **Curar** (kit médico), **II** (pausa).
- Teclado para testes no PC: WASD, Q/R girar, Z/X olhar para cima/baixo, Shift, C, E, F, G, H, Esc.
- Configurações: qualidade (Auto/Baixa/Média/Alta), 30/60 fps, sensibilidade, tamanho dos botões, volume, brilho, vibração, FPS na tela.

## O que é 3D (e o que não é)
- **Objetos 3D reais:** caixotes, barris (cilindros), consoles (mesa + monitor), blocos baixos de concreto/rocha, contêineres, cartões, kits médicos, baterias, garrafas, fusível, núcleo, documentos, gravadores e pontos de salvamento. Cada um é feito de caixas/cilindros com textura própria nas laterais e no topo, iluminados pela lanterna e pelas luzes do mapa. Você vê o topo das caixas ao olhar de cima e pode ver por cima dos blocos baixos.
- **Paredes e portas:** raycasting (colunas). **Dinossauros:** sprites 2D em 5 ângulos (+ espelho), gerados de modelos 3D de cápsulas; olhos e cristas brilham no escuro.
- **Olhar vertical** por deslocamento da linha do horizonte (como em Doom/Duke 3D, até ~±29°). Limite do método: as paredes continuam verticais, sem rampas, escadas ou andares; cada área tem uma altura de parede.

## O jogo
| Área | Ambiente | Dinossauros | Objetivo |
|---|---|---|---|
| 1 Centro de pesquisas | corredores, escritórios, laboratórios | Velociraptor | cartão nível 1 → código (post-it) → cartão nível 2 → doca |
| 2 Recintos de contenção | avenida larga + túnel de serviço estreito | Raptores, Carnotauro, **T-Rex** | código → alavanca de energia (solta o T-Rex) → portão leste |
| 3 Floresta | trilhas, emboscadas, neblina | Dilofossauros, Raptores, Carnotauro | cartão nível 3 (acampamento) + fusível (helicóptero) → bunker |
| 4 Subterrâneo | corredores estreitos, portas de energia | Raptor, **O Silêncio** (criatura original) | gerador (fusível) → Núcleo genético → elevador |
| 5 Área final | pátio, torre, heliponto | T-Rex, Carnotauro, Raptores | 2 alavancas → terminal (decisão: A transmitir / B entregar) → sobreviver 75 s → helicóptero |

**Comportamento por espécie:** *Raptor* — rápido, abre portas, flanqueia (intercepta a trajetória), chama os outros, checa esconderijos. *T-Rex* — enorme; visão por movimento (parado ele quase não vê), audição extrema, tremor de tela, quebra barricadas, **não passa por corredores estreitos**. *Dilofossauro* — camuflado na vegetação (só os olhos brilham), telegrafa com o babado, cospe veneno e recua para outro ponto. *Carnotauro* — corrida em linha reta com curva lenta; bate em pilares e fica atordoado. *O Silêncio* — cego, caça por som com cliques; parado/agachado você passa; sinais: sons ambientes somem, luzes tremem, pontos azuis.
IA: patrulha por território → investigar ruído → alerta → perseguição → perda de contato → procura (incluindo esconderijos) → volta à patrulha. Esconderijos usados durante uma caçada ficam "queimados" e são checados primeiro.

## Estrutura
```
app/src/main/AndroidManifest.xml, java/…/MainActivity.java   (WebView em tela cheia, paisagem, botão voltar, pausa)
app/src/main/assets/www/   index.html, css/style.css, js/*.js  (o jogo inteiro; sem arquivos de imagem/áudio, tudo procedural)
  util, textures, world, render, art, maps, ai, story, player, audio, input, ui, game
tools/   testes (Node + Playwright) e utilitários        .github/workflows/build-apk.yml
```
Para acrescentar uma área: um novo `buildAx()` + entrada em `LP.AREAS` (`js/maps.js`) e textos em `js/story.js`.

## Testes realizados (reproduzíveis em `tools/`)
- `node tools/test-maps.js` — as 5 áreas: tudo alcançável por simulação de progressão (cartões, códigos, alavancas), saídas, esconderijos, classes de tamanho dos dinossauros. **OK**
- `node tools/test-ai.js` — patrulha cobre o mapa sem atravessar paredes; investiga ruído; alerta→perseguição→ataque→dano; perde contato→procura→volta à patrulha; esconderijo queimado é descoberto; T-Rex quebra barricada e **não entra** no túnel; Carnotauro carrega; Dilofossauro emboscada→cuspe→recuo; Silêncio ignora quem está parado e pega quem se move. **OK**
- `NODE_PATH=$(npm root -g) node tools/test-browser.js` — Chromium, viewport 832×385 com toque: título, novo jogo, joystick, olhar com 2 dedos, **olhar vertical por arrasto (e invertido) e pelo teclado**, botões, pausa, 29 sons renderizados offline (audíveis, sem NaN), as 5 áreas renderizam sem erro. **OK**
- `NODE_PATH=$(npm root -g) node tools/test-3d.js` — captura de tela de caixote, console, item no chão, bloco e contêiner, em visão nivelada, de cima e de baixo (conferência visual; salvou imagens em `/tmp`).
- `NODE_PATH=$(npm root -g) node tools/test-rotate.js` — celular em retrato: aviso com botões, modo "tela girada" por CSS (joystick, olhar e pausa funcionam com as coordenadas giradas), troca de lado, e volta ao normal quando o aparelho gira de verdade. **OK**
- `node tools/test-flow.js` — um robô joga do início ao fim usando as interações reais (itens, código errado/certo, alavancas, evento do T-Rex, fusível, Núcleo, terminal, decisão, resgate, tela de final). **OK**
- `node tools/test-perf.js` — custo por quadro em CPU de servidor: 2–7 ms (312×144 / 388×180 / 466×216). No A15 espere várias vezes isso; o modo **Auto** reduz a resolução se passar de 30 ms.

## Limitações e pendências conhecidas
- Sem teste em aparelho real (toque, áudio, calor, bateria, notch). Se o desempenho cair, use Qualidade **Baixa** e 30 fps.
- Visual estilizado (texturas procedurais; objetos são caixas e cilindros; dinossauros são sprites pré-renderizados); não é realismo.
- Áudio 100% sintetizado: validado só por renderização offline, não por escuta.
- Dificuldade/balanceamento não foram testados com jogadores; a IA foi validada por simulação.
- O APK de depuração não é para loja. Para publicar: assinar um *release*, ícone adaptativo, política de privacidade.
