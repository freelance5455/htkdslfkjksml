/* Lost Prehistoria - objetos 3D (caixas e cilindros com topo e laterais): caixotes, barris, consoles, blocos, contêineres e todos os itens.
   Os dinossauros continuam sendo sprites 2D; o resto do cenário é geometria 3D renderizada pelo raycaster. */
(function (g) {
  'use strict';
  var LP = g.LP, X = LP.Tex, reg = X.reg, C = X.C, nz = X.nz, h = X.h, ID = X.ID;
  function bev(x, y) { return (x < 2 || y < 2 || x > 61 || y > 61) ? 0.55 : 1; }
  function disc(x, y) { var dx = x - 32, dy = y - 32; return Math.sqrt(dx * dx + dy * dy); }

  /* ---------- texturas dos objetos ---------- */
  reg('o_crate', function (x, y) {
    var pl = (y / 16) | 0, v = 80 + h(x >> 2, pl, 31) * 44 + nz(x, y, 8, 32) * 22;
    if (y % 16 < 2) v -= 38; if (x < 5 || x > 58) v -= 22;
    if ((x === 3 || x === 60) && y % 16 === 8) return C(176, 176, 166);
    var b = bev(x, y); return C(v * 1.15 * b, v * 0.82 * b, v * 0.5 * b);
  });
  reg('o_crate_top', function (x, y) {
    var v = 84 + h(x >> 3, y >> 3, 33) * 34; if (x < 6 || x > 57 || y < 6 || y > 57) v -= 24;
    if (Math.abs((x - 32) - (y - 32)) < 4 || Math.abs((x - 32) + (y - 32)) < 4) v -= 20;
    return C(v * 1.15, v * 0.82, v * 0.5);
  });
  reg('o_barrel', function (x, y) {
    var hoop = (y > 9 && y < 16) || (y > 47 && y < 54) || (y > 28 && y < 33), v = 80 + h(x >> 1, 0, 34) * 26 + (nz(x, y, 6, 35) - 0.5) * 30;
    if (hoop) { v = 46 + h(x, y, 36) * 14; return C(v, v * 1.02, v * 1.06); }
    if (nz(x, y, 10, 37) > 0.62) v -= 18; return C(v * 1.35, v * 0.5, v * 0.26);
  });
  reg('o_barrel_top', function (x, y) {
    var r = disc(x, y); if (r > 31) return C(24, 24, 24);
    var v = 72 + (r > 26 ? -28 : 0) + (Math.abs(r - 17) < 1.3 ? 34 : 0) + (nz(x, y, 6, 38) - 0.5) * 16; if (Math.abs(x - 44) < 3 && Math.abs(y - 24) < 3) v += 44;
    return C(v, v * 1.02, v * 1.06);
  });
  reg('o_desk', function (x, y) {
    var v = 74 + (nz(x, y, 4, 40) - 0.5) * 26; if (x % 32 < 2 || y < 3 || y > 60) v -= 34; if (y > 22 && y < 40 && x % 32 > 5 && x % 32 < 26) v += (y === 31 ? -30 : 8);
    if (x % 32 > 20 && x % 32 < 25 && y > 29 && y < 33) v += 60; var b = bev(x, y); return C(v * 0.86 * b, v * 0.98 * b, v * 1.08 * b);
  });
  reg('o_desk_top', function (x, y) {
    var v = 52 + (nz(x, y, 5, 41) - 0.5) * 20; if (y > 38 && y < 56 && x > 12 && x < 52) v = (x % 6 < 2 || y % 5 < 1) ? 26 : 70;
    if (x < 3 || y < 3 || x > 60 || y > 60) v -= 16; return C(v * 0.9, v * 1.0, v * 1.08);
  });
  reg('o_mon_back', function (x, y) { var v = 34 + (nz(x, y, 4, 42) - 0.5) * 14; if (x < 3 || y < 3 || x > 60 || y > 60) v -= 12; return C(v, v * 1.03, v * 1.06); });
  reg('o_screen', function (x, y) {
    if (x > 5 && x < 58 && y > 5 && y < 58) {
      var t = h(x >> 2, y >> 2, 43) > 0.6 ? 1 : 0.3, sl = (y & 1) ? 0.8 : 1;
      return C(30 * t * sl, 214 * t * sl, 172 * t * sl, true);
    }
    return C(20, 22, 24);
  });
  reg('o_block', function (x, y) {
    var v = X.concv(x, y, 11); if (y > 6 && y < 15) { return (((x + y) >> 3) & 1) ? C(206, 172, 22) : C(24, 24, 22); }
    var b = bev(x, y); return C(v * 0.96 * b, v * 1.0 * b, v * 1.04 * b);
  });
  reg('o_block_top', function (x, y) { var v = 96 + (nz(x, y, 5, 44) - 0.5) * 36 + (h(x, y, 45) - 0.5) * 14; if (x < 4 || y < 4 || x > 59 || y > 59) v -= 24; return C(v * 0.96, v, v * 1.04); });
  reg('o_rock', function (x, y) {
    var v = 70 + (nz(x, y, 4, 46) - 0.5) * 54 + (nz(x, y, 10, 47) - 0.5) * 24; if (Math.abs(nz(x, y, 6, 48) - 0.5) < 0.02) v -= 34; return C(v * 1.0, v * 0.97, v * 0.9);
  });
  reg('o_rock_top', function (x, y) { var v = 74 + (nz(x, y, 5, 49) - 0.5) * 40; var m = nz(x, y, 6, 50); if (m > 0.58) return C(30 + m * 20, 58 + m * 30, 30); return C(v, v * 0.98, v * 0.9); });
  reg('o_cont', function (x, y) {
    var rib = Math.sin(x * 1.05) * 14, v = 74 + rib + (nz(x, y, 4, 51) - 0.5) * 22; if (y < 4 || y > 59) v -= 34;
    if (nz(x, y, 8, 52) > 0.66) v -= 20; if (y > 20 && y < 28 && x > 14 && x < 50) v += 26; var b = bev(x, y); return C(v * 0.72 * b, v * 1.08 * b, v * 0.98 * b);
  });
  reg('o_cont_top', function (x, y) { var v = 60 + (nz(x, y, 5, 53) - 0.5) * 22 + (x % 12 < 2 ? -14 : 0); return C(v * 0.74, v * 1.04, v * 0.96); });
  /* itens */
  reg('i_med_top', function (x, y) {
    if ((Math.abs(x - 32) < 8 && Math.abs(y - 32) < 22) || (Math.abs(y - 32) < 8 && Math.abs(x - 32) < 22)) return C(210, 30, 30);
    var v = 226 * bev(x, y); return C(v, v, v * 0.98);
  });
  reg('i_med_side', function (x, y) { if (y > 22 && y < 40) return C(200, 34, 34); var v = 214 * bev(x, y); return C(v, v, v * 0.97); });
  reg('i_bat_side', function (x, y) {
    if (y < 10) { var s = 170 + h(x, y, 60) * 20; return C(s, s, s * 1.03); }
    if (y > 24 && y < 40) return C(250, 224, 60, true);
    var v = 40 + (x > 38 ? 18 : 0) + h(x >> 2, 0, 61) * 14; return C(v * 0.8, v * 3.2, v * 1.4);
  });
  reg('i_bat_top', function (x, y) { var r = disc(x, y); if (r > 31) return C(30, 30, 30); var v = 150 + (r < 12 ? 40 : 0) + (r > 26 ? -40 : 0); return C(v, v, v * 1.03); });
  reg('i_paper_side', function (x, y) { return C(206, 198, 178); });
  reg('i_doc_top', function (x, y) {
    var v = 214 - (nz(x, y, 4, 62) - 0.5) * 24; if (x < 6 || x > 57 || y < 6 || y > 57) v -= 20;
    if (y % 8 === 4 && x > 8 && x < 56 - ((y >> 3) & 1) * 14) return C(90, 88, 80); return C(v, v * 0.97, v * 0.86);
  });
  reg('i_doc_topk', function (x, y) { if (x > 42 && y < 22 && x < 60 && y > 4) return C(80, 240, 225, true); return X.ARR[ID.i_doc_top] ? X.ARR[ID.i_doc_top][y * 64 + x] : C(214, 208, 190); });
  [['1', [60, 140, 255]], ['2', [240, 200, 40]], ['3', [240, 50, 40]]].forEach(function (c) {
    reg('i_card_top' + c[0], function (x, y) {
      if (y > 12 && y < 24) return C(c[1][0], c[1][1], c[1][2], true);
      if (x > 8 && x < 22 && y > 34 && y < 48) return C(222, 192, 84);
      var v = 62 * bev(x, y); return C(v, v * 1.05, v * 1.12);
    });
  });
  reg('i_card_side', function (x, y) { return C(40, 44, 50); });
  reg('i_key_top', function (x, y) {
    var dx = x - 14, dy = y - 32, r = Math.sqrt(dx * dx + dy * dy), key = (r < 11 && r > 5) || (x > 22 && x < 58 && y > 28 && y < 36) || (x > 44 && x < 50 && y > 36 && y < 44) || (x > 52 && x < 57 && y > 36 && y < 42);
    return key ? C(214, 180, 70) : C(30, 32, 36);
  });
  reg('i_fuse_side', function (x, y) {
    if (y < 11 || y > 53) { var s = 168 + h(x, y, 63) * 20; return C(s, s, s * 1.04); }
    return Math.abs(x - 32) < 3 ? C(150, 110, 26, true) : C(252, 204, 62, true);
  });
  reg('i_fuse_top', function (x, y) { var r = disc(x, y); if (r > 31) return C(30, 30, 30); var v = 150 + (r < 10 ? 30 : 0); return C(v, v, v * 1.04); });
  reg('i_core_side', function (x, y) {
    if (y < 9 || y > 55) return C(54, 60, 64);
    return Math.abs(x - 24) < 4 ? C(220, 255, 250, true) : C(80, 240, 225, true);
  });
  reg('i_core_top', function (x, y) { var r = disc(x, y); if (r > 31) return C(30, 30, 30); return r < 12 ? C(230, 255, 250, true) : C(80, 240, 225, true); });
  reg('i_bottle_side', function (x, y) { var hl = (x > 14 && x < 24) ? 50 : 0; return C(46 + hl, 150 + hl, 88 + hl); });
  reg('i_bottle_top', function (x, y) { var r = disc(x, y); return r > 31 ? C(30, 30, 30) : C(86, 70, 44); });
  reg('i_log_top', function (x, y) {
    var d1 = Math.sqrt((x - 20) * (x - 20) + (y - 34) * (y - 34)), d2 = Math.sqrt((x - 44) * (x - 44) + (y - 34) * (y - 34));
    if (x > 50 && x < 58 && y > 8 && y < 16) return C(255, 50, 40, true); if (d1 < 11 || d2 < 11) return d1 < 4 || d2 < 4 ? C(30, 30, 32) : C(138, 138, 146);
    var v = 36 * bev(x, y); return C(v, v * 1.1, v * 1.2);
  });
  reg('i_log_side', function (x, y) { return C(34, 38, 42); });
  reg('i_save_side', function (x, y) { var v = 52 + (nz(x, y, 4, 64) - 0.5) * 16; if (x % 32 < 2 || y % 24 < 2) v -= 24; return C(v * 0.95, v * 1.03, v * 1.1); });
  reg('i_save_top', function (x, y) { var v = (y & 3) ? 1 : 0.7; if (x < 5 || y < 5 || x > 58 || y > 58) return C(60, 40, 12); return C(255 * v, 176 * v, 60 * v, true); });
  reg('i_lamp_top', function (x, y) { return C(255, 214, 120, true); });

  /* ---------- construtores de partes ---------- */
  function tid(n) { return ID[n]; }
  function box(x0, y0, x1, y1, z0, z1, tS, tT, faces) { return { x0: x0, y0: y0, x1: x1, y1: y1, z0: z0, z1: z1, tS: tid(tS), tT: tid(tT), faceTex: faces ? faces.map(function (f) { return f ? tid(f) : 0; }) : null }; }
  function cyl(cx, cy, r, z0, z1, tS, tT) { return { cyl: 1, cx: cx, cy: cy, r: r, z0: z0, z1: z1, tS: tid(tS), tT: tid(tT) }; }
  var FV = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  function rv(v, rot) { for (var i = 0; i < rot; i++) v = [-v[1], v[0]]; return v; }
  function rface(f, rot) { var v = rv(FV[f], rot); for (var i = 0; i < 4; i++) if (FV[i][0] === v[0] && FV[i][1] === v[1]) return i; return f; }
  function rbox(cx, cy, a, b, c, d, z0, z1, tS, tT, faces, rot) {
    var p = rv([a, b], rot), q = rv([c, d], rot), nf = null;
    if (faces) { nf = [0, 0, 0, 0]; for (var i = 0; i < 4; i++) nf[rface(i, rot)] = faces[i]; }
    return box(cx + Math.min(p[0], q[0]), cy + Math.min(p[1], q[1]), cx + Math.max(p[0], q[0]), cy + Math.max(p[1], q[1]), z0, z1, tS, tT, nf);
  }
  var O = LP.OBJ = {};
  function def(kind, tex, make) { O[kind] = { tex: tex, make: make }; }
  def('crate', ['o_crate', 'o_crate_top'], function (cx, cy) { return [box(cx - 0.42, cy - 0.42, cx + 0.42, cy + 0.42, 0, 0.5, 'o_crate', 'o_crate_top')]; });
  def('barrel', ['o_barrel', 'o_barrel_top'], function (cx, cy) { return [cyl(cx, cy, 0.3, 0, 0.5, 'o_barrel', 'o_barrel_top')]; });
  def('console', ['o_desk', 'o_desk_top', 'o_mon_back', 'o_screen'], function (cx, cy, rot) {
    return [rbox(cx, cy, -0.42, -0.32, 0.42, 0.32, 0, 0.36, 'o_desk', 'o_desk_top', null, rot),
      rbox(cx, cy, -0.26, -0.22, 0.26, -0.13, 0.36, 0.8, 'o_mon_back', 'o_mon_back', ['o_mon_back', 'o_mon_back', 'o_screen', 'o_mon_back'], rot)];
  });
  def('block', ['o_block', 'o_block_top', 'o_rock', 'o_rock_top'], function (cx, cy, rot, area) {
    var r = area && area.pal && area.pal.blk === 'rock'; return [box(cx - 0.46, cy - 0.46, cx + 0.46, cy + 0.46, 0, r ? 0.6 : 0.55, r ? 'o_rock' : 'o_block', r ? 'o_rock_top' : 'o_block_top')];
  });
  def('cont', ['o_cont', 'o_cont_top'], function (cx, cy) { return [box(cx - 0.47, cy - 0.47, cx + 0.47, cy + 0.47, 0, 0.98, 'o_cont', 'o_cont_top')]; });
  def('medkit', ['i_med_side', 'i_med_top'], function (cx, cy) { return [box(cx - 0.17, cy - 0.12, cx + 0.17, cy + 0.12, 0, 0.12, 'i_med_side', 'i_med_top')]; });
  def('battery', ['i_bat_side', 'i_bat_top'], function (cx, cy) { return [cyl(cx, cy, 0.075, 0, 0.22, 'i_bat_side', 'i_bat_top')]; });
  def('throw', ['i_bottle_side', 'i_bottle_top'], function (cx, cy) { return [cyl(cx, cy, 0.06, 0, 0.14, 'i_bottle_side', 'i_bottle_top'), cyl(cx, cy, 0.03, 0.14, 0.25, 'i_bottle_side', 'i_bottle_top')]; });
  [1, 2, 3].forEach(function (n) { def('card' + n, ['i_card_side', 'i_card_top' + n], function (cx, cy) { return [box(cx - 0.15, cy - 0.1, cx + 0.15, cy + 0.1, 0, 0.03, 'i_card_side', 'i_card_top' + n)]; }); });
  def('gatekey', ['i_card_side', 'i_key_top'], function (cx, cy) { return [box(cx - 0.17, cy - 0.06, cx + 0.17, cy + 0.06, 0, 0.035, 'i_card_side', 'i_key_top')]; });
  def('fuse', ['i_fuse_side', 'i_fuse_top'], function (cx, cy) { return [cyl(cx, cy, 0.065, 0, 0.26, 'i_fuse_side', 'i_fuse_top')]; });
  def('core', ['i_core_side', 'i_core_top'], function (cx, cy) { return [cyl(cx, cy, 0.11, 0, 0.32, 'i_core_side', 'i_core_top')]; });
  def('doc', ['i_paper_side', 'i_doc_top'], function (cx, cy) { return [box(cx - 0.15, cy - 0.11, cx + 0.15, cy + 0.11, 0, 0.018, 'i_paper_side', 'i_doc_top')]; });
  def('key_doc', ['i_paper_side', 'i_doc_top', 'i_doc_topk'], function (cx, cy) { return [box(cx - 0.15, cy - 0.11, cx + 0.15, cy + 0.11, 0, 0.018, 'i_paper_side', 'i_doc_topk')]; });
  def('log', ['i_log_side', 'i_log_top'], function (cx, cy) { return [box(cx - 0.15, cy - 0.11, cx + 0.15, cy + 0.11, 0, 0.07, 'i_log_side', 'i_log_top')]; });
  def('save', ['i_save_side', 'i_save_top', 'i_lamp_top'], function (cx, cy) {
    return [box(cx - 0.18, cy - 0.18, cx + 0.18, cy + 0.18, 0, 0.5, 'i_save_side', 'i_save_side'), box(cx - 0.15, cy - 0.15, cx + 0.15, cy + 0.15, 0.5, 0.56, 'i_save_side', 'i_save_top'), cyl(cx, cy, 0.05, 0.56, 0.7, 'i_lamp_top', 'i_lamp_top')];
  });
})(typeof window !== 'undefined' ? window : globalThis);
