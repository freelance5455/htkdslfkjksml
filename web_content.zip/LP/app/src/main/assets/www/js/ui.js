/* Lost Prehistoria - interface (DOM): telas, HUD e configurações */
(function (g) {
  'use strict';
  var LP = g.LP, UI = LP.UI = {}, doc = g.document;
  var $ = function (id) { return doc.getElementById(id); };
  var NAMES = ['title', 'settings', 'controls', 'pause', 'pack', 'doc', 'keypad', 'decide', 'dead', 'end', 'load'];
  var subT = 0, toastT = 0, last = {};

  UI.cur = null;
  UI.show = function (name) {
    NAMES.forEach(function (n) { var e = $('s-' + n); if (e) e.classList.toggle('hidden', n !== name); });
    UI.cur = name;
  };
  UI.hideAll = function () { UI.show(null); };
  UI.toast = function (t, ms) {
    var e = $('toast'); e.textContent = t; e.classList.remove('hidden'); clearTimeout(toastT);
    toastT = setTimeout(function () { e.classList.add('hidden'); }, ms || 2600);
  };
  UI.sub = function (t, ms) {
    var e = $('sub'); e.textContent = t; e.classList.add('on'); clearTimeout(subT);
    subT = setTimeout(function () { e.classList.remove('on'); }, ms || 5000);
  };
  UI.areaCard = function (a) {
    var e = $('areacard'); $('acN').textContent = 'Área ' + a.n + ' de 5'; $('acT').textContent = a.name; $('acS').textContent = a.sub;
    e.classList.add('hidden'); void e.offsetWidth; e.classList.remove('hidden'); setTimeout(function () { e.classList.add('hidden'); }, 4700);
  };
  UI.doc = function (d) {
    $('docKind').textContent = d.k === 'log' ? 'Gravação de áudio' : d.k === 'term' ? 'Terminal' : 'Documento';
    $('docTitle').textContent = d.t; $('docText').textContent = d.x;
    $('s-doc').querySelector('.paper').className = 'paper ' + d.k; UI.show('doc');
  };
  UI.keypad = function (cb) {
    var code = '', disp = $('kpDisp'), el = $('s-keypad');
    function draw() { disp.textContent = (code + '----').slice(0, 4); }
    draw(); UI.show('keypad');
    el.onclick = function (e) {
      var b = e.target.closest('button'); if (!b) return;
      if (b.dataset.k === 'x') { UI.hideAll(); cb(null); return; }
      if (b.dataset.k === 'c') { code = code.slice(0, -1); draw(); return; }
      if (code.length < 4) code += b.textContent.trim();
      draw(); LP.A.ui('ui', 0.6);
      if (code.length === 4) { var c = code; setTimeout(function () { UI.hideAll(); cb(c); }, 220); }
    };
  };
  UI.decide = function (a, b, x) { UI.show('decide'); $('dA').onclick = a; $('dB').onclick = b; $('dX').onclick = x; };
  UI.dead = function (why) { $('deadWhy').textContent = why; UI.show('dead'); };
  UI.end = function (e) { $('endT').textContent = e.t; $('endX').textContent = e.x; UI.show('end'); };
  UI.load = function (txt, p) { UI.show('load'); $('loadT').textContent = txt; $('loadBar').style.width = (p || 0) + '%'; };

  /* HUD: só escreve no DOM quando o valor muda */
  function set(id, key, v, fn) { if (last[key] !== v) { last[key] = v; fn($(id), v); } }
  UI.hud = function (P, S, o) {
    set('hp', 'hp', Math.round(P.hp), function (e, v) { e.style.width = v + '%'; });
    set('st', 'st', Math.round(P.stam), function (e, v) { e.style.width = v + '%'; });
    set('bt', 'bt', Math.round(P.bat), function (e, v) { e.style.width = v + '%'; });
    var inv = S.inv, sig = [inv.card1, inv.card2, inv.card3, inv.fuse, inv.gatekey, inv.core, inv.battery, inv.medkit, inv.throw].join();
    set('items', 'items', sig, function (e) {
      var h = '', add = function (t, c) { h += '<span class="chip" style="--c:' + c + '">' + t + '</span>'; };
      if (inv.card1) add('Cartão 1', '#3c8cff'); if (inv.card2) add('Cartão 2', '#f0c828'); if (inv.card3) add('Cartão 3', '#f03228');
      if (inv.fuse) add('Fusível', '#e0963a'); if (inv.gatekey) add('Chave', '#e0963a'); if (inv.core) add('Núcleo', '#58e1d2');
      if (inv.battery) add('Bateria ×' + inv.battery, '#58e1d2'); if (inv.medkit) add('Kit ×' + inv.medkit, '#c4473a');
      e.innerHTML = h;
    });
    set('obj', 'obj', o.obj, function (e, v) { e.textContent = v; });
    set('nThrow', 'nt', inv.throw, function (e, v) { e.textContent = v; $('bThrow').classList.toggle('hidden', !v); });
    set('nHeal', 'nh', inv.medkit, function (e, v) { e.textContent = v; $('bHeal').classList.toggle('hidden', !v); });
    set('bInteract', 'lab', o.label || '', function (e, v) { e.classList.toggle('ready', !!v); e.firstChild.textContent = v || 'Usar'; });
    set('aware', 'aw', Math.round(o.aware * 20), function (e, v) { e.classList.toggle('hidden', v < 2); e.firstChild.style.height = Math.min(100, v * 5) + '%'; e.firstChild.style.background = v > 18 ? '#c4473a' : '#e0963a'; });
    set('timer', 'tm', o.timer || '', function (e, v) { e.classList.toggle('hidden', !v); e.textContent = v ? 'Resgate em ' + v : ''; });
    set('bFlash', 'fl', P.flashOn, function (e, v) { e.classList.toggle('lit', v); });
    set('bCrouch', 'cr', P.crouch, function (e, v) { e.classList.toggle('lit', v); });
  };
  UI.pack = function (S, openDoc, objective) {
    $('packObj').textContent = objective;
    var inv = S.inv, rows = [['Cartão nível 1', inv.card1], ['Cartão nível 2', inv.card2], ['Cartão nível 3', inv.card3], ['Fusível principal', inv.fuse], ['Chave do portão', inv.gatekey], ['Núcleo genético', inv.core], ['Baterias reserva', inv.battery], ['Kits médicos', inv.medkit], ['Garrafas', inv.throw]];
    var h = ''; rows.forEach(function (r) { if (r[1]) h += '<div>' + r[0] + (r[1] > 1 ? ' ×' + r[1] : '') + '</div>'; });
    $('packItems').innerHTML = h || '<div>Vazia</div>';
    var dl = $('packDocs'); dl.innerHTML = '';
    S.docs.forEach(function (id) { var d = LP.DOCS[id], b = doc.createElement('button'); b.className = d.k; b.textContent = d.t; b.onclick = function () { openDoc(id); }; dl.appendChild(b); });
    if (!S.docs.length) dl.innerHTML = '<div style="color:#9b9784;font:500 3vh system-ui">Nenhum ainda. Explore e procure documentos, gravações e terminais.</div>';
    UI.show('pack');
  };
  UI.fx = function (id, v) { var e = $(id); if (e) e.style.opacity = v; };

  /* configurações */
  UI.bindSettings = function (st, apply) {
    function sync() {
      doc.querySelectorAll('#s-settings .seg').forEach(function (sg) {
        var k = sg.dataset.k; sg.querySelectorAll('button').forEach(function (b) { b.classList.toggle('on', String(st[k]) === b.dataset.v); });
      });
      $('rSens').value = st.sens; $('rUi').value = st.ui; $('rVol').value = st.vol; $('rBri').value = st.bright;
    }
    doc.querySelectorAll('#s-settings .seg').forEach(function (sg) {
      sg.onclick = function (e) { var b = e.target.closest('button'); if (!b) return; var k = sg.dataset.k, v = b.dataset.v; st[k] = (k === 'quality' && v === 'auto') ? 'auto' : +v; sync(); apply(); };
    });
    [['rSens', 'sens'], ['rUi', 'ui'], ['rVol', 'vol'], ['rBri', 'bright']].forEach(function (p) { $(p[0]).oninput = function () { st[p[1]] = +this.value; apply(); }; });
    sync(); UI.syncSettings = sync;
  };
})(typeof window !== 'undefined' ? window : globalThis);
