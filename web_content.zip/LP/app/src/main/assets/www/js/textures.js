/* Lost Prehistoria - texturas procedurais (sem arquivos de imagem, sem licenças) */
(function (g) {
  'use strict';
  var LP = g.LP, S = 64;
  var GEN = {}, ID = {}, ARR = [null], NAMES = [''];
  LP.Tex = { S: S, ID: ID, ARR: ARR, NAMES: NAMES };

  /* cor empacotada ABGR; e=true marca pixel emissivo (alpha 254, ignora iluminação) */
  function C(r, gg, b, e) {
    r = r < 0 ? 0 : r > 255 ? 255 : r | 0; gg = gg < 0 ? 0 : gg > 255 ? 255 : gg | 0; b = b < 0 ? 0 : b > 255 ? 255 : b | 0;
    return (((e ? 254 : 255) << 24) | (b << 16) | (gg << 8) | r) >>> 0;
  }
  function nz(x, y, P, s) { return LP.tf(x / S * P, y / S * P, P, s, 4); }
  function h(x, y, s) { return LP.hash(x, y, s); }
  function reg(name, fn) { GEN[name] = fn; ID[name] = ARR.length; ARR.push(null); NAMES.push(name); }
  LP.Tex.use = function (names) {
    for (var i = 0; i < names.length; i++) {
      var n = names[i], id = ID[n];
      if (!id) throw new Error('textura desconhecida: ' + n);
      if (ARR[id]) continue;
      var a = new Uint32Array(S * S), fn = GEN[n];
      for (var y = 0; y < S; y++) for (var x = 0; x < S; x++) a[y * S + x] = fn(x, y);
      ARR[id] = a;
    }
  };

  /* base de concreto reutilizada por várias texturas: devolve brilho */
  function concv(x, y, k) {
    var n = nz(x, y, 4, 1 + k), gr = nz(x, y, 16, 2 + k), st = nz(x, y, 3, 9 + k);
    var v = 100 + (n - 0.5) * 46 + (gr - 0.5) * 24;
    if (x % 32 === 0 || y % 32 === 0) v -= 30; else if (x % 32 === 1 || y % 32 === 1) v += 9;
    if (h(x, y, 7 + k) < 0.025) v -= 24;
    if (st > 0.6) v -= (st - 0.6) * 140;
    var dr = LP.tn(x / S * 20, 0.5, 20, 5 + k);
    if (dr > 0.72) v -= (dr - 0.72) * 120 * (y / S);
    return v;
  }
  function conc(x, y, k) { var v = concv(x, y, k || 0); return C(v * 0.93, v * 0.98, v * 1.04); }

  /* ---------- paredes ---------- */
  reg('conc', function (x, y) { return conc(x, y, 0); });
  reg('conc2', function (x, y) {
    var v = concv(x, y, 3) - 14, m = nz(x, y, 5, 33);
    if (y > 40 && m > 0.52) return C(30 + m * 40, 60 + m * 60, 28);
    return C(v * 0.9, v * 0.98, v * 0.92);
  });
  reg('conc_blood', function (x, y) {
    var v = concv(x, y, 1), b = nz(x, y, 3, 40);
    if (b > 0.56 && x > 10 && x < 54) {
      var a = Math.min(1, (b - 0.56) * 7), dr = 0.7 + 0.3 * h(x, y, 3);
      return C(v * 0.93 * (1 - a) + 112 * a * dr, v * 0.98 * (1 - a) + 14 * a, v * 1.04 * (1 - a) + 10 * a);
    }
    return conc(x, y, 1);
  });
  reg('conc_claw', function (x, y) {
    var v = concv(x, y, 2);
    for (var k = 0; k < 4; k++) {
      var cx = 16 + k * 9 + (y - 8) * 0.14, d = Math.abs(x - cx);
      if (y > 8 && y < 56 && d < 1.2) return C(v + 64, v + 60, v + 52);
      if (y > 8 && y < 56 && d < 2.4) return C(v * 0.55, v * 0.55, v * 0.58);
    }
    return conc(x, y, 2);
  });
  reg('metal', function (x, y) {
    var n = nz(x, y, 2, 3), v = 70 + (n - 0.5) * 30 + (h(0, y, 5) - 0.5) * 14;
    var mx = x % 32, my = y % 32;
    if (mx === 0 || my === 0) v -= 26;
    if ((mx === 3 || mx === 4 || mx === 28 || mx === 29) && (my === 3 || my === 4 || my === 28 || my === 29)) v += 34;
    if (h(x, y, 8) < 0.02) v -= 18;
    return C(v * 0.9, v * 0.96, v * 1.06);
  });
  reg('tile_wall', function (x, y) {
    var tx = x >> 3, ty = y >> 3, v = 150 + (h(tx, ty, 4) - 0.5) * 30 - (nz(x, y, 4, 12) - 0.4) * 60;
    if (x % 8 === 0 || y % 8 === 0) v -= 46;
    v -= (y / S) * 18;
    return C(v * 0.93, v * 1.0, v * 0.97);
  });
  reg('window', function (x, y) {
    if (x > 7 && x < 56 && y > 9 && y < 42) {
      var a = Math.atan2(y - 24, x - 30), r = Math.sqrt((x - 30) * (x - 30) + (y - 24) * (y - 24));
      var v = 18 + (y - 9) * 0.5;
      if (Math.abs(Math.sin(a * 5)) < 0.06 && r < 22) v += 70;
      if (Math.abs(Math.sin(r * 0.9)) < 0.05 && r < 14) v += 40;
      return C(v * 0.7, v * 0.95, v * 1.2);
    }
    if (x > 5 && x < 58 && y > 7 && y < 44) return C(36, 40, 42);
    return conc(x, y, 4);
  });
  reg('cage', function (x, y) {
    var bg = nz(x, y, 6, 50), mx = x % 8, bar = false;
    if (mx < 2 && h(x >> 3, y >> 4, 9) > 0.07) bar = true;
    if (y % 32 < 2) bar = true;
    if (bar) { var v = (mx === 0 ? 104 : 70) + h(x, y, 3) * 26; return C(v * 0.98, v * 0.9, v * 0.76); }
    return C(12 + bg * 26, 22 + bg * 38, 14 + bg * 18);
  });
  reg('rock', function (x, y) {
    var n = nz(x, y, 4, 60), c = nz(x, y, 10, 61), v = 74 + (n - 0.5) * 50 + (c - 0.5) * 22;
    if (Math.abs(nz(x, y, 6, 62) - 0.5) < 0.022) v -= 36;
    return C(v * 1.06, v * 0.96, v * 0.86);
  });
  reg('bark', function (x, y) {
    var bx = (x + Math.floor(nz(x, y, 4, 70) * 12)) & 63, v = 38 + h(bx >> 1, 0, 71) * 36 + (nz(x, y, 8, 72) - 0.5) * 24;
    var moss = (y > 38 ? 1 : 0) * Math.max(0, nz(x, y, 6, 73) - 0.5) * 3;
    return C(v * 1.1 * (1 - moss) + 20 * moss, v * 0.8 * (1 - moss) + 62 * moss, v * 0.56 * (1 - moss) + 20 * moss);
  });
  reg('leaves', function (x, y) {
    var n = nz(x, y, 8, 80), sp = h(x >> 1, y >> 1, 81), v = 20 + n * 56 + sp * 22;
    if (nz(x, y, 5, 82) > 0.64) v *= 0.35;
    return C(v * 0.5, v * 1.05, v * 0.42);
  });
  reg('brick', function (x, y) {
    var row = y >> 3, off = (row & 1) * 8, bx = ((x + off) >> 4), my = y % 8, mx = (x + off) % 16;
    var v = 82 + h(bx, row, 15) * 34 - (nz(x, y, 4, 16) - 0.4) * 50;
    if (my === 0 || mx === 0) return C(60, 58, 54);
    return C(v * 1.2, v * 0.62, v * 0.5);
  });
  reg('pipes', function (x, y) {
    var v = 44 + (nz(x, y, 4, 90) - 0.5) * 20, band = [[6, 14], [26, 36], [46, 58]];
    for (var i = 0; i < 3; i++) {
      var b = band[i];
      if (y >= b[0] && y < b[1]) {
        var t = (y - b[0]) / (b[1] - b[0]), sh = Math.sin(t * Math.PI);
        var w = 56 + 70 * sh * sh + (h(x >> 2, i, 91) - 0.5) * 8;
        if (x % 21 < 2) w *= 0.6;
        return C(w * 0.92, w * 1.0, w * 1.02);
      }
    }
    return C(v, v * 1.04, v * 1.06);
  });

  /* ---------- tiles especiais (usam só a parte baixa da parede) ---------- */
  var STRIPE = { door: null, door_c1: [60, 140, 255], door_c2: [240, 200, 40], door_c3: [240, 50, 40], door_code: [60, 220, 120], door_pwr: [240, 140, 30] };
  function doorTex(name, led) {
    reg(name, function (x, y) {
      var st = STRIPE[name];
      if (st && y >= 3 && y < 6 && x > 6 && x < 58) return C(st[0], st[1], st[2], true);
      if (x > 5 && x < 59 && y > 7) {
        var v = 92 + (nz(x, y, 3, 20) - 0.5) * 24 + (h(0, y, 21) - 0.5) * 8;
        if (x < 9 || x > 55 || y < 11) v -= 34;
        if (x === 31 || x === 32) v -= 46;
        if (x > 25 && x < 38 && y > 14 && y < 26) return C(10, 18 + (y - 14), 26 + (y - 14) * 2);
        if (x > 46 && x < 51 && y > 36 && y < 46) v += 60;
        if (led && x > 42 && x < 52 && y > 48 && y < 60) {
          if (name === 'door_code') { if (x % 3 !== 0 && y % 4 !== 0) return C(60, 220, 120, true); return C(18, 24, 20); }
          if (x > 44 && x < 50 && y > 50 && y < 56) return C(led[0], led[1], led[2], true);
          return C(22, 26, 28);
        }
        return C(v * 0.9, v * 0.97, v * 1.04);
      }
      return conc(x, y, 5);
    });
  }
  doorTex('door', null); doorTex('door_c1', [60, 140, 255]); doorTex('door_c2', [240, 200, 40]);
  doorTex('door_c3', [240, 50, 40]); doorTex('door_code', [60, 220, 120]); doorTex('door_pwr', [240, 140, 30]);

  reg('gate', function (x, y) {
    var v = 66 + (nz(x, y, 3, 30) - 0.5) * 22;
    if (y > 5 && y < 14) { var s = ((x + y) >> 3) & 1; return s ? C(220, 180, 20) : C(26, 26, 24); }
    if (x % 6 < 2) v += 36;
    if (y % 24 < 3) v -= 22;
    if (x > 27 && x < 37 && y > 28 && y < 40) { if (x > 30 && x < 34 && y > 33 && y < 37) return C(240, 40, 30, true); return C(30, 32, 34); }
    return C(v * 0.95, v, v * 0.95);
  });
  reg('barr', function (x, y) {
    var gap = 8 + nz(x, y, 3, 40) * 14;
    for (var i = 0; i < 6; i++) {
      var y0 = 4 + i * 10 + (h(i, 0, 41) - 0.5) * 3;
      if (y > y0 && y < y0 + 7) {
        var v = 70 + h(x >> 2, i, 42) * 40 + (h(0, y, 43)) * 18;
        if ((x === 6 || x === 57) && (y === (y0 | 0) + 3)) return C(160, 160, 150);
        return C(v * 1.2, v * 0.86, v * 0.55);
      }
    }
    var d = Math.abs((x - 32) - (y - 32) * 0.55); if (d < 3) return C(88, 62, 40);
    return C(gap * 0.5, gap * 0.6, gap * 0.5);
  });
  reg('locker', function (x, y) {
    var mx = x % 32, v = 76 + (nz(x, y, 4, 50) - 0.5) * 30;
    if (mx < 2 || y < 5 || y > 60) v -= 40;
    if (mx > 6 && mx < 26 && y > 9 && y < 22 && y % 3 === 0) v -= 46;
    if ((mx > 22 && mx < 26) && y > 30 && y < 38) v += 70;
    if (h(x >> 2, y >> 2, 51) < 0.03) v -= 22;
    return C(v * 0.78, v * 1.02, v * 1.08);
  });
  reg('bush', function (x, y) {
    var n = nz(x, y, 8, 100), sp = h(x >> 1, y >> 1, 101), v = 30 + n * 70 + sp * 30;
    if (nz(x, y, 6, 102) > 0.7) v *= 0.4;
    return C(v * 0.5, v * 1.1, v * 0.4);
  });
  reg('vent', function (x, y) {
    var v = 74 + (nz(x, y, 3, 110) - 0.5) * 24;
    if (x < 6 || x > 57 || y < 6 || y > 57) return C(v * 0.8, v * 0.85, v * 0.9);
    if (y % 6 < 3) return C(8, 10, 12);
    return C(v * 0.95, v, v * 1.02);
  });
  reg('term', function (x, y) {
    if (x > 13 && x < 51 && y > 9 && y < 35) {
      var v = 100 + 90 * (((y >> 1) & 1) ? 0.78 : 1), tx = h(x >> 2, y >> 2, 120) > 0.55 ? 1 : 0.28;
      return C(30 * tx * v / 150, 210 * tx * v / 150, 170 * tx * v / 150, true);
    }
    if (x > 11 && x < 53 && y > 7 && y < 37) return C(20, 22, 24);
    if (x > 9 && x < 55 && y > 38 && y < 48) return C(70 + (h(x, y, 121) * 20), 74, 76);
    return conc(x, y, 6);
  });
  reg('lever', function (x, y) {
    if (x > 17 && x < 47 && y > 13 && y < 51) {
      if (x > 30 && x < 34 && y > 20 && y < 44) {
        if (y < 30) return C(210 - (y - 20) * 3, 40, 34);
        return C(8, 8, 10);
      }
      if (x > 20 && x < 26 && y > 16 && y < 20) return C(240, 170, 40, true);
      return C(58 + h(x, y, 130) * 10, 62, 66);
    }
    return conc(x, y, 7);
  });
  reg('exit', function (x, y) {
    if (y >= 3 && y < 7 && x > 8 && x < 56) return C(70, 255, 130, true);
    if (x > 5 && x < 59 && y > 8) {
      var v = 82 + (nz(x, y, 3, 140) - 0.5) * 20;
      if (x === 31 || x === 32) v -= 40;
      if (x < 9 || x > 55) v -= 24;
      if (y > 52) return ((x + y) >> 2) & 1 ? C(200, 170, 20) : C(24, 24, 22);
      return C(v * 0.95, v * 1.06, v * 1.0);
    }
    return conc(x, y, 8);
  });

  LP.Tex.reg = reg; LP.Tex.C = C; LP.Tex.nz = nz; LP.Tex.h = h; LP.Tex.concv = concv;

  /* ---------- pisos ---------- */
  reg('f_tile', function (x, y) {
    var tx = x >> 4, ty = y >> 4, v = 92 + (h(tx, ty, 150) - 0.5) * 18 + (nz(x, y, 6, 151) - 0.5) * 34;
    if (x % 16 === 0 || y % 16 === 0) v -= 34;
    if (h(x, y, 152) < 0.02) v -= 18;
    return C(v * 0.92, v * 0.98, v * 1.02);
  });
  reg('f_stain', function (x, y) {
    var v = 84 + (nz(x, y, 6, 153) - 0.5) * 30, b = nz(x, y, 3, 154);
    if (x % 16 === 0 || y % 16 === 0) v -= 30;
    if (b > 0.55) { var a = Math.min(1, (b - 0.55) * 6); return C(v * (1 - a) + 96 * a, v * (1 - a) + 14 * a, v * (1 - a) + 12 * a); }
    return C(v * 0.92, v * 0.98, v);
  });
  reg('f_grate', function (x, y) {
    if (x % 8 < 2 || y % 8 < 2) { var v = 66 + h(x, y, 155) * 24; return C(v, v * 1.04, v * 1.06); }
    return C(10, 12, 14);
  });
  reg('f_conc', function (x, y) {
    var v = 78 + (nz(x, y, 5, 156) - 0.5) * 36 + (h(x, y, 157) - 0.5) * 10;
    if (x % 32 === 0 || y % 32 === 0) v -= 24;
    return C(v * 0.98, v * 0.98, v);
  });
  reg('f_grass', function (x, y) {
    var n = nz(x, y, 8, 158), b = h(x, y >> 2, 159), v = 22 + n * 40 + b * 18;
    if (nz(x, y, 4, 160) > 0.62) return C(54 + n * 20, 40 + n * 14, 26);
    return C(v * 0.5, v * 1.0, v * 0.42);
  });
  reg('f_dirt', function (x, y) {
    var v = 50 + (nz(x, y, 6, 161) - 0.5) * 40 + (h(x, y, 162) - 0.5) * 14;
    return C(v * 1.16, v * 0.86, v * 0.6);
  });
  reg('f_path', function (x, y) {
    var v = 84 + (nz(x, y, 6, 163) - 0.5) * 34 + (h(x, y, 164) < 0.04 ? 30 : 0);
    return C(v * 1.12, v * 0.92, v * 0.7);
  });
  reg('f_mud', function (x, y) {
    var n = nz(x, y, 6, 165), v = 26 + n * 30;
    if (nz(x, y, 3, 166) > 0.6) return C(14, 24 + n * 20, 30 + n * 26);
    return C(v * 1.05, v * 0.85, v * 0.66);
  });
  reg('f_metal', function (x, y) {
    var v = 62 + (nz(x, y, 4, 167) - 0.5) * 24 + (h(0, y, 168) - 0.5) * 8;
    if (x % 32 === 0 || y % 32 === 0) v -= 28;
    if ((x % 32 === 4 || x % 32 === 27) && (y % 32 === 4 || y % 32 === 27)) v += 40;
    return C(v * 0.9, v * 0.98, v * 1.08);
  });

  /* ---------- tetos ---------- */
  reg('c_lab', function (x, y) {
    var v = 58 + (nz(x, y, 4, 170) - 0.5) * 26;
    if (x % 32 < 2 || y % 32 < 2) v -= 26;
    return C(v * 0.92, v, v * 1.04);
  });
  reg('c_dark', function (x, y) { var v = 30 + (nz(x, y, 6, 171) - 0.5) * 26; return C(v, v * 1.02, v * 1.06); });
  reg('c_canopy', function (x, y) {
    var n = nz(x, y, 8, 172), v = 8 + n * 34 + h(x >> 1, y >> 1, 173) * 12;
    return C(v * 0.5, v, v * 0.5);
  });
  reg('c_sky', function (x, y) {
    var n = nz(x, y, 4, 174), v = 14 + n * 44;
    if (h(x, y, 175) < 0.006) return C(220, 230, 255);
    return C(v * 0.8, v * 0.92, v * 1.3);
  });
  reg('c_pipes', function (x, y) {
    var v = 40 + (nz(x, y, 4, 176) - 0.5) * 20;
    if (y % 21 > 14) { var s = Math.sin(((y % 21) - 14) / 7 * Math.PI); v = 44 + 50 * s; }
    return C(v, v * 1.03, v * 1.06);
  });
})(typeof window !== 'undefined' ? window : globalThis);
