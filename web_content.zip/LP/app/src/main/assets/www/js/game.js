/* Lost Prehistoria - núcleo do jogo */
(function (g) {
  'use strict';
  var LP = g.LP, In = LP.In, AI = LP.AI, UI = LP.UI, A = LP.A, Art = LP.Art, doc = g.document, clamp = LP.clamp;
  var G = LP.G = {}, $ = function (id) { return doc.getElementById(id); };
  var cv, cx, img, buf, RW = 0, RH = 0, autoQ = 2;
  var S = null, W = null, P = new LP.Player(), dinos = [], projs = [], statics = [], drawList = [], sheets = {}, delayed = [], actors = [];
  var cam = { x: 0, y: 0, a: 0, eyeH: 0.66, hor: 0, fov: 1.36 }, scene = { flash: 0, range: 14, bright: 1.2, fog: [8, 10, 12], dens: 0.06, wallH: 1.2, time: 0 };
  var state = 'boot', timeNow = 0, shakeAmt = 0, flickerT = 0, tension = 0, hurtFlash = 0, deadT = 0, target = null, backTo = 'title', tipT = 0, objT = 0, attractT = 0;
  var settings = { quality: 'auto', fps: 30, sens: 1, ui: 1, vol: 0.85, bright: 1.2, autoRun: 1, vib: 1, showFps: 0, invY: 0 };
  var ema = 16, emaT = 0, lastTs = 0, fpsC = 0, fpsT = 0, pendingSave = null;
  var aiCtx = { world: null, player: P, dinos: dinos, hides: [], time: 0, sfx: null, shake: null, hurt: null, pullOut: null, spawnProj: null };

  /* ---------- utilitários ---------- */
  function hyp(ax, ay, bx, by) { var dx = ax - bx, dy = ay - by; return Math.sqrt(dx * dx + dy * dy); }
  function vib(ms) { if (settings.vib && g.navigator && g.navigator.vibrate) { try { g.navigator.vibrate(ms); } catch (e) { /* ignora */ } } }
  function toast(t, ms) { UI.toast(t, ms); }
  G.get = function () { return { S: S, P: P, W: W, dinos: dinos, state: state, cam: cam, settings: settings, projs: projs, RW: RW, RH: RH, ema: ema, tension: tension }; };
  G.sfx = function (n, x, y, v) { A.play(n, x, y, v); };
  G.shake = function (a, x, y) { var k = x === undefined ? a : a * Math.max(0, 1 - hyp(P.x, P.y, x, y) / 24); if (k > shakeAmt) shakeAmt = k; };
  aiCtx.sfx = G.sfx; aiCtx.shake = G.shake;

  /* ---------- configurações ---------- */
  function applySettings() {
    doc.documentElement.style.setProperty('--ui', settings.ui); In.sens = settings.sens; In.invY = !!+settings.invY; In.autoRun = !!+settings.autoRun; A.setVolume(settings.vol);
    $('fps').classList.toggle('hidden', !+settings.showFps); LP.store.set('lp_settings', settings); resize();
  }
  function resize() {
    var q = settings.quality === 'auto' ? autoQ : +settings.quality, qh = { 1: 144, 2: 180, 3: 216 }[q] || 180;
    var asp = clamp(g.innerWidth / Math.max(1, g.innerHeight), 1.3, 2.5);
    var w = Math.round(qh * asp / 2) * 2;
    if (w === RW && qh === RH) return;
    RW = w; RH = qh; cv.width = RW; cv.height = RH; img = cx.createImageData(RW, RH); buf = new Uint32Array(img.data.buffer); LP.Render.setup(RW, RH, buf);
  }

  /* ---------- sprites de dinossauros (gerados em partes para não travar a tela) ---------- */
  G.prepare = function (kinds, cb, label) {
    var todo = kinds.filter(function (k, i) { return kinds.indexOf(k) === i && !(sheets[k] && sheets[k].done); }), total = todo.length * 5 || 1, done = 0;
    (function next() {
      if (!todo.length) { cb(); return; }
      var k = todo[0], sh = sheets[k] || (sheets[k] = Art.makeDino(k)), fin = sh.step(); done++;
      UI.load(label || 'Preparando as criaturas…', done / total * 100);
      if (fin) todo.shift();
      setTimeout(next, 0);
    })();
  };

  /* ---------- áreas ---------- */
  function buildStatics() {
    /* caixotes, barris, consoles, blocos e itens agora são objetos 3D do mundo; só a decoração miúda segue como sprite 2D */
    statics = [];
    W.ents.forEach(function (e) { if (e.type !== 'deco') return; var p = Art.prop(e.spr); statics.push({ x: e.x, y: e.y, img: p.img, sw: p.sw, sh: p.sh, lift: p.lift, l0: p.lift }); });
  }
  function loadArea(idx, spawn) {
    var Ar = LP.AREAS[idx]; if (!Ar.rows) Ar.rows = Ar.build();
    S.area = idx; W = new LP.World(Ar, S); aiCtx.world = W; aiCtx.hides = Object.keys(W.hides).map(function (k) { return W.hides[k]; });
    var kindCh = { raptor: 'R', trex: 'X', dilo: 'D', carno: 'K', special: 'S' }, dorm = Ar.dormant || {}, dil = W.spawns.filter(function (s) { return s.sp === 'dilo'; });
    dinos.length = 0; projs.length = 0; delayed.length = 0;
    W.spawns.forEach(function (s, i) {
      var key = dorm[kindCh[s.sp]], d = AI.create(s.sp, s.x, s.y, { dormant: !!(key && !S.flags[key]), spots: dil, uid: i });
      dinos.push(d);
    });
    buildStatics();
    var st = spawn || W.start; P.reset(st.x, st.y, st.a || Ar.startAngle || 0);
    if (spawn) { P.hp = spawn.hp || 100; P.bat = spawn.bat === undefined ? 100 : spawn.bat; }
    scene.fog = Ar.fog; scene.dens = Ar.dens; scene.wallH = Ar.wallH; W.lightMul = 1;
    A.setArea(Ar.sound); A.occ = function (x, y) { return W.los(P.x, P.y, x, y) ? 1 : 0.4; }; A.setSilence(0);
    flickerT = 0; shakeAmt = 0; tension = 0; hurtFlash = 0; target = null; In.resetLatch();
  }
  /* apoio a testes: carrega uma área direto */
  G.debugLoad = function (idx) { if (!S) S = freshState(); setState('loading'); G.prepare(G.kindsOf(idx), function () { startPlay(idx, null); }); };
  G.kindsOf = function (idx) {
    var Ar = LP.AREAS[idx]; if (!Ar.rows) Ar.rows = Ar.build();
    var set = {}; Ar.rows.forEach(function (r) { for (var i = 0; i < r.length; i++) { var k = ({ R: 'raptor', X: 'trex', D: 'dilo', K: 'carno', S: 'special' })[r[i]]; if (k) set[k] = 1; } });
    return Object.keys(set);
  };
  function freshState() {
    return { area: 0, inv: { card1: 0, card2: 0, card3: 0, fuse: 0, gatekey: 0, core: 0, battery: 1, medkit: 0, throw: 2 }, flags: {}, picked: {}, unlocked: {}, docs: [], tips: {}, deaths: 0, t: 0, ending: null, chopT: 0 };
  }
  G.save = function () {
    if (!S || !W) return;
    LP.store.set('lp_save', { S: JSON.parse(JSON.stringify(S)), x: P.x, y: P.y, a: P.a, hp: Math.max(40, P.hp), bat: P.bat, v: 1 });
  };
  G.hasSave = function () { return !!LP.store.get('lp_save', null); };
  G.newGame = function () {
    A.init(); A.resume(); S = freshState(); LP.store.del('lp_save'); In.resetLatch();
    G.prepare(G.kindsOf(0), function () { startPlay(0, null); }, 'Preparando a instalação…');
  };
  G.continueGame = function () {
    var sv = LP.store.get('lp_save', null); if (!sv) return;
    A.init(); A.resume(); S = sv.S;
    G.prepare(G.kindsOf(S.area), function () { startPlay(S.area, { x: sv.x, y: sv.y, a: sv.a, hp: sv.hp, bat: sv.bat }); }, 'Retomando…');
  };
  function startPlay(idx, spawn) {
    loadArea(idx, spawn); UI.hideAll(); setState('play'); UI.areaCard(LP.AREAS[idx]); G.save(); tipT = 0; objT = 0;
    $('fade').style.opacity = 0;
  }
  function setState(s) {
    state = s; In.active = (s === 'play');
    var playing = (s === 'play' || s === 'pause' || s === 'doc' || s === 'keypad' || s === 'decide' || s === 'pack' || s === 'dying');
    $('hud').classList.toggle('hidden', !playing); $('touch').classList.toggle('hidden', s !== 'play');
    if (s !== 'play') { In.mx = In.my = 0; }
  }
  function nextArea(idx) {
    setState('fading'); $('fade').style.opacity = 1;
    setTimeout(function () {
      G.prepare(G.kindsOf(idx), function () { startPlay(idx, null); }, 'Descendo…');
    }, 700);
  }

  /* ---------- interação ---------- */
  var LABEL = { medkit: 'Pegar', battery: 'Pegar', throw: 'Pegar', card1: 'Pegar', card2: 'Pegar', card3: 'Pegar', gatekey: 'Pegar', fuse: 'Pegar', core: 'Pegar', doc: 'Ler', log: 'Ouvir', save: 'Salvar' };
  function findTarget() {
    if (P.hidden) return { k: 'unhide', label: 'Sair' };
    var best = null, bd = 1.3, i, fx = Math.cos(P.a), fy = Math.sin(P.a);
    for (i = 0; i < W.ents.length; i++) {
      var e = W.ents[i]; if (!LABEL[e.type]) continue;
      var d = hyp(P.x, P.y, e.x, e.y); if (d >= bd) continue;
      var dot = ((e.x - P.x) * fx + (e.y - P.y) * fy) / Math.max(d, 0.01);
      if (d < 0.8 || dot > 0.25) { best = { k: 'ent', e: e, label: LABEL[e.type] }; bd = d; }
    }
    if (best) return best;
    var rt = W.rayTile(P.x, P.y, P.a, 1.45);
    if (rt) {
      if (rt.k === 2) { if (W.dOpen[rt.i] < 0.5) return { k: 'door', i: rt.i, label: W.doors[rt.i].lock ? 'Destrancar' : 'Abrir' }; }
      else if (rt.k === 5) return { k: 'hide', i: rt.i, label: 'Esconder' };
      else if (rt.k === 6) return { k: 'term', i: rt.i, label: 'Terminal' };
      else if (rt.k === 7) return { k: 'lever', i: rt.i, label: S.flags[(W.meta[rt.i] || {}).flag] ? '' : 'Acionar' };
      else if (rt.k === 3) return { k: 'exit', i: rt.i, label: 'Sair' };
    }
    return null;
  }
  function remove(e) { var i = W.ents.indexOf(e); if (i >= 0) W.ents.splice(i, 1); W.removeObj(e); statics = statics.filter(function (s) { return s.e !== e; }); }
  function pickup(e) {
    var inv = S.inv, m = '';
    switch (e.type) {
      case 'medkit': inv.medkit++; m = 'Kit médico'; break;
      case 'battery': inv.battery++; m = 'Bateria reserva'; break;
      case 'throw': inv.throw += 2; m = 'Garrafas para distrair (+2)'; G.tip('throw', 1); break;
      case 'card1': case 'card2': case 'card3': inv[e.type] = 1; m = 'Cartão de acesso nível ' + e.type[4]; break;
      case 'gatekey': inv.gatekey = 1; m = 'Chave do portão'; break;
      case 'fuse': inv.fuse = 1; m = 'Fusível principal'; break;
      case 'core': inv.core = 1; S.flags.a4_core = 1; m = 'Núcleo genético'; break;
    }
    S.picked[e.id] = 1; remove(e); A.ui('pick'); W.noise(P.x, P.y, 2, 'pick'); toast(m);
    if (e.type === 'core') { G.fire('a4_core'); G.save(); }
  }
  function readDoc(id, ent) {
    var d = LP.DOCS[id]; if (!d) return;
    if (S.docs.indexOf(id) < 0) S.docs.push(id);
    if (ent) { S.picked[ent.id] = 1; remove(ent); }
    A.ui(d.k === 'log' ? 'flash' : 'pick'); UI.doc(d); setState('doc'); backTo = 'play';
  }
  function unlockDoor(d) { d.lock = null; S.unlocked[W.area.id + ':' + d.i] = 1; }
  function tryDoor(i) {
    var d = W.doors[i]; if (!d) return;
    if (d.lock) {
      var l = d.lock;
      if (l.card) { if (!S.inv['card' + l.card]) { toast('Precisa do cartão de acesso nível ' + l.card); A.ui('ui'); return; } }
      else if (l.code) {
        setState('keypad');
        UI.keypad(function (c) { setState('play'); if (c === null) return; if (c === W.area.codes[d.ch]) { unlockDoor(d); W.openDoor(d); A.play('door', d.x + 0.5, d.y + 0.5, 1); toast('Código aceito'); } else { toast('Código incorreto'); A.ui('hurt', 0.2); } });
        return;
      } else if (l.flag) { if (!S.flags[W.area.powerFlag]) { toast('Porta sem energia'); A.ui('ui'); return; } }
      else if (l.item) { if (!S.inv[l.item]) { toast('Precisa da chave do portão'); return; } }
      unlockDoor(d);
    }
    W.openDoor(d); A.play('door', d.x + 0.5, d.y + 0.5, 1); W.noise(d.x + 0.5, d.y + 0.5, 5, 'door');
  }
  function lever(i) {
    var m = W.meta[i]; if (!m || S.flags[m.flag]) return;
    if (m.need && m.need.item) { if (!S.inv[m.need.item]) { toast('Falta o fusível principal (procure na floresta)'); return; } S.inv[m.need.item] = 0; }
    S.flags[m.flag] = 1; A.ui('door'); A.play('crash', P.x, P.y, 0.35); W.noise(P.x, P.y, 13, 'lever'); toast(m.msg, 4200); vib(60);
    if (m.ev) G.fire(m.ev); G.save();
  }
  function terminal(i) {
    var m = W.meta[i]; if (!m) return;
    if (m.id === 'a5_final') {
      if (!S.flags.a5_l1 || !S.flags.a5_l2) { toast('Terminal sem energia. Ligue as duas alavancas.'); return; }
      if (S.flags.a5_decided) { toast('Transmissão em andamento. Corra para o heliponto!'); return; }
      readDoc('a5_final'); backTo = 'decide';
      return;
    }
    readDoc(m.id);
  }
  function exitTry() {
    var ex = W.area.exit, need = ex.need || {};
    if ((need.card && !S.inv['card' + need.card]) || (need.flag && !S.flags[need.flag]) || (need.item && !S.inv[need.item])) { toast(ex.msg, 3600); A.ui('ui'); return; }
    if (ex.to === 'end') { G.endGame(); return; }
    A.ui('door'); nextArea(ex.to);
  }
  G.interact = function () {
    if (!target) return;
    var t = target;
    if (t.k === 'unhide') G.unhide();
    else if (t.k === 'ent') { var e = t.e; if (e.type === 'doc' || e.type === 'log') readDoc(e.doc, e); else if (e.type === 'save') { G.save(); A.ui('pick'); P.stam = 100; toast('Progresso salvo'); } else pickup(e); }
    else if (t.k === 'door') tryDoor(t.i);
    else if (t.k === 'hide') G.hide(t.i);
    else if (t.k === 'term') terminal(t.i);
    else if (t.k === 'lever') lever(t.i);
    else if (t.k === 'exit') exitTry();
  };

  /* ---------- esconderijos ---------- */
  G.hide = function (i) {
    var h = W.hides[i], px = P.x | 0, py = P.y | 0, fx, fy;
    if (Math.abs(h.x - px) + Math.abs(h.y - py) === 1) { fx = px; fy = py; } else { var f = AI.front(W, h); fx = f.x | 0; fy = f.y | 0; }
    var dx = fx - h.x, dy = fy - h.y;
    P.hidden = h; P.savedFlash = P.flashOn; P.flashOn = false; P.crouch = false; S.front = { x: fx, y: fy };
    P.x = h.x + 0.5 + dx * 0.3; P.y = h.y + 0.5 + dy * 0.3; P.hideFace = Math.atan2(dy, dx); P.a = P.hideFace;
    var hunted = dinos.some(function (d) { return !d.dormant && d.kind !== 'dilo' && hyp(d.x, d.y, P.x, P.y) < 16 && /chase|search|investigate|alert|rush|lock|charge/.test(d.state); });
    if (hunted) h.burned = true;
    UI.fx('fxh', 0.9); W.noise(P.x, P.y, 1.5, 'hide'); G.tip('hide', 1);
  };
  G.unhide = function () {
    var h = P.hidden; if (!h) return;
    P.hidden = null; P.x = S.front.x + 0.5; P.y = S.front.y + 0.5; P.flashOn = P.savedFlash && P.bat > 0; UI.fx('fxh', 0);
  };
  G.pullOut = function (h) { if (P.hidden === h) { G.unhide(); G.shake(0.6); } };
  aiCtx.pullOut = G.pullOut;

  /* ---------- ações do jogador ---------- */
  G.footstep = function (p) {
    var n = { a1: 'step_tile', a2: 'step_tile', a3: 'step_dirt', a4: 'step_metal', a5: 'step_dirt' }[W.area.id];
    A.play(n, p.x, p.y, p.crouch ? 0.25 : (p.sprint ? 1 : 0.55));
    W.noise(p.x, p.y, p.crouch ? 1.0 * Math.max(0.3, p.mag) : (p.sprint ? 8.5 : 2 + 2.4 * p.mag), 'step');
  };
  G.batteryOut = function () {
    if (S.inv.battery > 0) { S.inv.battery--; P.bat = 100; P.flashOn = true; toast('Bateria trocada'); A.ui('flash'); } else toast('Sem bateria. A lanterna apagou.', 3200);
  };
  function toggleFlash() {
    if (P.hidden) return;
    if (P.bat <= 0) { G.batteryOut(); return; }
    P.flashOn = !P.flashOn; A.ui('flash'); W.noise(P.x, P.y, 1.2, 'flash');
  }
  G.throwBottle = function () {
    if (S.inv.throw <= 0 || P.hidden) return;
    S.inv.throw--; var dx = Math.cos(P.a), dy = Math.sin(P.a), d = 0.5;
    while (d < 9.5) { if (W.solidAt(Math.floor(P.x + dx * d), Math.floor(P.y + dy * d))) { d -= 0.4; break; } d += 0.25; }
    var lx = P.x + dx * d, ly = P.y + dy * d; delayed.push({ t: 0.35, fn: function () { A.play('glass', lx, ly, 1); W.noise(lx, ly, 13, 'bottle'); } });
  };
  G.heal = function () {
    if (S.inv.medkit <= 0 || P.healT > 0 || P.dead || (P.hp >= 100 && P.poison <= 0)) return;
    S.inv.medkit--; P.healT = 1.3; A.ui('pick'); toast('Usando o kit médico…', 1400);
  };
  G.hurt = function (n, kind, src) {
    if (P.dead || state !== 'play') return;
    P.hp -= n; hurtFlash = 1; shakeAmt = Math.max(shakeAmt, 0.9); A.ui('hurt'); vib(90); W.noise(P.x, P.y, 10, 'hurt');
    if (kind === 'venom' || kind === 'dilo') { P.poison = Math.max(P.poison, 6); }
    if (kind === 'carno') P.stun = 1.6; else if (kind === 'trex') P.stun = 2.2;
    if (src && n < 900) { var a = Math.atan2(P.y - src.y, P.x - src.x); W.move(P, Math.cos(a) * 0.5, Math.sin(a) * 0.5, P.r); }
    if (P.hp <= 0) { P.hp = 0; G.die(kind); }
  };
  aiCtx.hurt = G.hurt;
  G.spawnProj = function (x, y, tx, ty) {
    var a = Math.atan2(ty - y, tx - x), sp = Art.prop('venom');
    projs.push({ x: x, y: y, vx: Math.cos(a) * 8, vy: Math.sin(a) * 8, life: 1.8, spr: { x: x, y: y, img: sp.img, sw: sp.sw, sh: sp.sh, lift: 0.32 } });
  };
  aiCtx.spawnProj = G.spawnProj;
  var WHY = { raptor: 'Despedaçado por um Velociraptor.', trex: 'Esmagado pelo Tiranossauro Rex.', carno: 'Atropelado pelo Carnotauro.', dilo: 'Envenenado pelo Dilofossauro.', venom: 'O veneno do Dilofossauro venceu você.', special: 'O Silêncio ouviu você se mexer.' };
  G.die = function (kind) {
    if (state === 'dying' || state === 'dead') return;
    P.dead = true; S.deaths++; deadT = 0; setState('dying'); UI.fx('fxh', 0); P.hidden = null; vib(300); G._why = WHY[kind] || 'Você não sobreviveu.';
  };
  G.retry = function () {
    UI.hideAll(); var sv = LP.store.get('lp_save', null);
    if (sv) { S = sv.S; S.deaths = (S.deaths || 0); G.prepare(G.kindsOf(S.area), function () { startPlay(S.area, { x: sv.x, y: sv.y, a: sv.a, hp: sv.hp, bat: sv.bat }); }); }
    else { var d = S.deaths; S = freshState(); S.deaths = d; G.prepare(G.kindsOf(0), function () { startPlay(0, null); }); }
  };
  G.endGame = function () {
    setState('end'); S.flags.finished = 1; UI.end(LP.ENDINGS[S.ending || 'A']); A.suspend();
  };
  G.tip = function (id, force) {
    if (S.tips[id]) return; S.tips[id] = 1; UI.sub(LP.TIPS[id], 6500);
  };

  /* ---------- eventos de roteiro ---------- */
  function farSpawn(d, minD, maxD) { var p = AI.pickGoal(d, aiCtx, P.x, P.y, minD, maxD); if (p) { d.x = p.x; d.y = p.y; } }
  G.fire = function (ev) {
    var i, d;
    if (ev === 'a1_shadow') {
      A.play('roar_raptor', P.x + 14, P.y, 0.9); flickerT = 3; UI.sub('Algo grande passou pelo corredor.', 3800);
      for (i = 0; i < dinos.length; i++) { d = dinos[i]; if (d.kind === 'raptor') { d.goal = { x: P.x, y: P.y }; d.state = 'investigate'; d.t = 0; } }
    } else if (ev === 'a2_trex') {
      for (i = 0; i < dinos.length; i++) { d = dinos[i]; if (d.kind === 'trex' && d.dormant) { AI.release(d, aiCtx, 500); A.play('roar_trex', d.x, d.y, 1); S.flags.a2_trex = 1; } }
      A.ui('hurt', 0.3); delayed.push({ t: 0.5, fn: function () { A.play('alarm', P.x, P.y, 0.7); } }); flickerT = 4; shakeAmt = 1; UI.sub('Ele quebrou a barricada. Entre no túnel de serviço e fique quieto!', 6000);
    } else if (ev === 'a4_power') {
      flickerT = 3; delayed.push({ t: 6, fn: function () { releaseSpecial(100); } });
    } else if (ev === 'a4_core') {
      flickerT = 3; delayed.push({ t: 3, fn: function () { releaseSpecial(130); } }); UI.sub('Os sons ambientes sumiram. Fique parado ou agache-se.', 6000);
    } else if (ev === 'a5_chase') {
      S.chopT = 75; S.flags.a5_decided = 1; A.play('alarm', P.x, P.y, 0.8); flickerT = 4;
      for (i = 0; i < dinos.length; i++) {
        d = dinos[i];
        if (d.kind === 'trex' && d.dormant) AI.release(d, aiCtx, 600);
        else if (!d.dormant) { d.last = { x: P.x, y: P.y }; d.goal = { x: P.x, y: P.y }; d.state = 'investigate'; d.t = 0; }
      }
      UI.sub('Corra para o heliponto, a leste! Siga pelo corredor estreito ao norte.', 7000);
    }
  };
  function releaseSpecial(life) {
    for (var i = 0; i < dinos.length; i++) {
      var d = dinos[i]; if (d.kind === 'special') { d.x = P.x; d.y = P.y; farSpawn(d, 16, 30); AI.release(d, aiCtx, life); A.play('click', d.x, d.y, 1); }
    }
  }

  /* ---------- atualização ---------- */
  function update(dt) {
    timeNow += dt; S.t += dt; aiCtx.time = timeNow; In.frame();
    if (In.take('pause')) { G.pause(); return; }
    if (In.take('flash')) toggleFlash();
    if (In.take('crouch') && !P.hidden) { P.crouch = !P.crouch; if (P.crouch) G.tip('crouch', 1); }
    if (In.take('throw')) G.throwBottle();
    if (In.take('heal')) G.heal();
    target = findTarget();
    if (In.take('interact')) G.interact();
    if (state !== 'play') return;
    P.update(dt, In, W, G);
    actors.length = 0; actors.push(P); for (var i = 0; i < dinos.length; i++) if (!dinos[i].dormant) actors.push(dinos[i]);
    W.update(dt, actors);
    if (flickerT > 0) { flickerT -= dt; W.lightMul = 0.25 + 0.75 * (((timeNow * 17) % 1) > 0.5 ? 1 : 0.1) * (flickerT > 0.4 ? 1 : 1); if (flickerT <= 0) W.lightMul = 1; }
    for (i = 0; i < delayed.length; i++) { delayed[i].t -= dt; if (delayed[i].t <= 0) { var f = delayed[i].fn; delayed.splice(i--, 1); f(); } }
    var maxAware = 0, tn = 0, spNear = 99;
    for (i = 0; i < dinos.length; i++) {
      var d = dinos[i]; if (d.dormant) continue;
      AI.update(d, aiCtx, dt);
      var st = d.state, w = /^(chase|attack|charge|rush|lock|alert|grab|bite|spit|telegraph)$/.test(st) ? 1 : /^(search|investigate|overshoot)$/.test(st) ? 0.45 : (d.dist < 12 && d.kind !== 'dilo' ? 0.15 : 0);
      var prox = clamp(1.15 - d.dist / 30, 0.15, 1); if (w * prox > tn) tn = w * prox;
      if (d.kind !== 'special' && d.kind !== 'dilo' && d.aware > maxAware) maxAware = d.aware;
      if (d.kind === 'dilo' && d.state !== 'ambush' && d.state !== 'retreat') maxAware = Math.max(maxAware, 1);
      if (d.kind === 'special') { spNear = Math.min(spNear, d.dist); if (d.state === 'rush' || d.state === 'lock') maxAware = 1; }
      if (/^(chase|rush|charge)$/.test(st)) G.tip('hide', 0);
    }
    if (spNear < 16) { var sil = clamp((16 - spNear) / 10, 0, 0.9); A.setSilence(sil); if (flickerT <= 0) W.lightMul = 0.6 + 0.4 * (Math.sin(timeNow * 31) > -0.6 ? 1 : 0.15); } else if (A.silence > 0) A.setSilence(0);
    tension += (tn - tension) * Math.min(1, dt * 2.5); G._aware = maxAware;
    /* projéteis de veneno */
    for (i = projs.length - 1; i >= 0; i--) {
      var pr = projs[i]; pr.x += pr.vx * dt; pr.y += pr.vy * dt; pr.life -= dt; pr.spr.x = pr.x; pr.spr.y = pr.y;
      if (W.solidAt(Math.floor(pr.x), Math.floor(pr.y)) || pr.life <= 0) { projs.splice(i, 1); continue; }
      if (!P.hidden && hyp(pr.x, pr.y, P.x, P.y) < 0.45) { projs.splice(i, 1); G.hurt(8, 'venom'); }
    }
    /* gatilhos de roteiro */
    for (i = 0; i < W.ents.length; i++) {
      var e = W.ents[i];
      if (e.type === 'trig' && hyp(P.x, P.y, e.x, e.y) < e.r && !S.picked['t:' + W.area.id + e.id]) { S.picked['t:' + W.area.id + e.id] = 1; G.fire(e.ev); }
    }
    /* contagem do resgate */
    if (S.chopT > 0) { S.chopT -= dt; if (S.chopT <= 0) { S.chopT = 0; S.flags.a5_chopper = 1; A.play('alarm', P.x, P.y, 0.5); toast('O helicóptero pousou! Embarque pela porta do heliponto.', 5000); } }
    /* dicas iniciais */
    tipT += dt; if (W.area.id === 'a1') { if (tipT > 2) G.tip('move'); else if (tipT > 40 && !P.flashOn) G.tip('flash'); }
    if (S.flags.a5_decided === undefined) { /* nada */ }
    if (P.healT > 0 && P.healT - dt <= 0) toast('Vida restaurada', 1500);
  }
  function objective() {
    var s = W.area.obj(S);
    if (W.area.id === 'a5' && S.flags.a5_chopper) return 'Embarque no helicóptero! Porta do heliponto, a leste.';
    return s;
  }

  /* ---------- desenho ---------- */
  function render(dt) {
    var k, i, d;
    if (state === 'title' || state === 'loading') {
      attractT += dt; cam.x = 12 + Math.sin(attractT * 0.15) * 3; cam.y = 16.5 + Math.sin(attractT * 0.31) * 0.35; cam.a = Math.sin(attractT * 0.2) * 0.12; cam.eyeH = 0.66; cam.hor = 0;
      scene.flash = 1.5; W.update(dt, []);
    } else {
      var bob = P.speed > 0.2 ? Math.sin(P.bob * 2) * Math.min(1, P.speed / 3) * 2.4 * (RH / 180) : 0;
      shakeAmt = Math.max(0, shakeAmt - dt * 1.4);
      cam.x = P.x; cam.y = P.y; cam.a = P.a; cam.eyeH = P.dead ? Math.max(0.14, P.eyeH - deadT * 0.5) : P.eyeH; cam.fov = 1.36 + (P.sprint && P.speed > 2 ? 0.07 : 0);
      cam.hor = bob + (Math.random() - 0.5) * shakeAmt * RH * 0.05 + (P.dead ? deadT * RH * 0.1 : 0) + P.pitch * RH;
      var fl = P.flashOn ? (P.bat < 18 && Math.random() < 0.18 ? 0.25 : 1) : 0; scene.flash = fl * 1.6;
    }
    scene.time = timeNow; scene.bright = settings.bright;
    drawList.length = 0;
    for (i = 0; i < statics.length; i++) { k = statics[i]; if (k.e) k.lift = k.l0 + Math.sin(timeNow * 2 + k.x * 3) * 0.012; drawList.push(k); }
    for (i = 0; i < dinos.length; i++) {
      d = dinos[i]; if (d.dormant) continue;
      var sh = sheets[d.kind]; if (!sh) continue;
      var an = AI.anim(d), rel = LP.angDiff(d.facing, Math.atan2(cam.y - d.y, cam.x - d.x)), pk = Art.pick(sh, an.a, an.f, rel);
      var s = d.spr || (d.spr = {}); s.x = d.x; s.y = d.y; s.img = pk.img; s.mirror = pk.mirror; s.sw = sh.sw; s.sh = sh.sh; s.lift = 0;
      s.dim = d.kind === 'dilo' ? 0.1 + 0.9 * (1 - d.camo) : 1; s.emis = 1; drawList.push(s);
    }
    for (i = 0; i < projs.length; i++) drawList.push(projs[i].spr);
    LP.Render.frame(W, cam, scene, drawList);
    cx.putImageData(img, 0, 0);
  }
  function hudFrame() {
    var lab = (state === 'play' && target) ? target.label : '';
    var tm = ''; if (S.chopT > 0) { var s = Math.ceil(S.chopT); tm = Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2); }
    UI.hud(P, S, { obj: objective(), label: lab, aware: G._aware || 0, timer: tm });
    UI.fx('fxd', Math.min(1, hurtFlash * 0.95 + (P.hp < 30 && !P.dead ? 0.22 + 0.14 * Math.sin(timeNow * 6) : 0)));
    UI.fx('fxp', P.poison > 0 ? 0.65 : 0);
    hurtFlash = Math.max(0, hurtFlash - 0.016 * 2.2);
  }

  /* ---------- loop ---------- */
  function loop(ts) {
    g.requestAnimationFrame(loop);
    var el = (ts - lastTs) / 1000, cap = 1 / settings.fps - 0.003;
    if (el < cap) return;
    lastTs = ts; var dt = Math.min(0.05, el), t0 = g.performance.now();
    try {
      if (state === 'play') { update(dt); }
      else if (state === 'dying') {
        deadT += dt; hurtFlash = Math.max(hurtFlash, 0.8); render(dt);
        if (deadT > 1.6) { setState('dead'); UI.dead(G._why); A.suspend(); }
      }
      if (state !== 'dead' && state !== 'end' && W) { if (state !== 'dying') render(dt); if (state === 'play' || state === 'pause') hudFrame(); else if (state === 'dying') hudFrame(); }
      if (state === 'play') A.update(dt, tension, G);
      if (state === 'play' || state === 'pause') A.setListener(P.x, P.y, P.a);
    } catch (err) { G.lastError = err; if (g.console) g.console.error(err); }
    var ms = g.performance.now() - t0; ema += (ms - ema) * 0.1;
    fpsC++; fpsT += el; if (fpsT >= 1) { if (settings.showFps) $('fps').textContent = Math.round(fpsC / fpsT) + ' fps · ' + ema.toFixed(1) + ' ms · ' + RW + 'x' + RH; G.fps = fpsC / fpsT; fpsC = 0; fpsT = 0; }
    emaT += el;
    if (emaT > 2.5 && state === 'play' && settings.quality === 'auto') { emaT = 0; if (ema > 30 && autoQ > 1) { autoQ--; resize(); } }
  }

  /* ---------- menus ---------- */
  G.pause = function () { if (state !== 'play') return; setState('pause'); UI.show('pause'); A.suspend(); In.resetLatch(); };
  G.resume = function () { UI.hideAll(); setState('play'); A.resume(); };
  G.toTitle = function () {
    UI.show('title'); setState('title'); $('mCont').disabled = !G.hasSave(); A.suspend(); if (!W || W.area.id !== 'a1') { var Ar = LP.AREAS[0]; if (!Ar.rows) Ar.rows = Ar.build(); W = new LP.World(Ar, { flags: {}, picked: {}, unlocked: {} }); scene.fog = Ar.fog; scene.dens = Ar.dens; scene.wallH = Ar.wallH; }
    statics = []; dinos.length = 0; projs.length = 0; drawList.length = 0; attractT = 0;
    G.prepare(['raptor'], function () {
      UI.show('title'); dinos.push(AI.create('raptor', 22.5, 16.5, { uid: 99 })); var d = dinos[0]; d.state = 'patrol'; d.wait = 99; d.facing = Math.PI; aiCtx.world = W;
    });
  };
  G.back = function () {
    if (state === 'doc') { UI.hideAll(); if (backTo === 'decide') { setState('decide'); UI.decide(function () { decide('A'); }, function () { decide('B'); }, function () { UI.hideAll(); setState('play'); }); } else setState('play'); backTo = 'play'; }
    else if (state === 'keypad') { UI.hideAll(); setState('play'); }
    else if (state === 'settings' || state === 'controls' || state === 'pack') { if (G.prev === 'pause') { UI.show('pause'); state = 'pause'; } else { UI.show('title'); state = 'title'; } }
    else if (state === 'decide') { UI.hideAll(); setState('play'); }
  };
  function decide(k) { S.ending = k; UI.hideAll(); setState('play'); G.fire('a5_chase'); G.save(); }
  function openPanel(name, from) { G.prev = from; state = name; UI.show(name); if (name === 'settings') UI.syncSettings(); }
  LP.onBack = function () {
    if (state === 'play') { G.pause(); return 'handled'; } if (state === 'pause') { G.resume(); return 'handled'; }
    if (state === 'settings' || state === 'controls' || state === 'pack' || state === 'doc' || state === 'keypad' || state === 'decide') { G.back(); return 'handled'; }
    if (state === 'title') return 'exit'; return 'handled';
  };
  LP.onAppPause = function () { if (state === 'play') G.pause(); };

  G.init = function () {
    cv = $('view'); cx = cv.getContext('2d', { alpha: false });
    var st = LP.store.get('lp_settings', null); if (st) for (var k in st) settings[k] = st[k];
    $('ver').textContent = LP.VER; resize();
    UI.bindSettings(settings, applySettings); applySettings();
    In.bind($('touch'));
    g.addEventListener('resize', resize);
    doc.addEventListener('visibilitychange', function () { if (doc.hidden && state === 'play') G.pause(); });
    var tap = function () { A.init(); A.resume(); };
    $('mNew').onclick = function () { tap(); G.newGame(); };
    $('mCont').onclick = function () { tap(); G.continueGame(); };
    $('mSet').onclick = function () { tap(); openPanel('settings', 'title'); };
    $('mCtl').onclick = function () { openPanel('controls', 'title'); };
    doc.querySelectorAll('[data-back]').forEach(function (b) { b.onclick = function () { G.back(); }; });
    $('pRes').onclick = G.resume; $('pSet').onclick = function () { openPanel('settings', 'pause'); };
    $('pPack').onclick = function () { G.prev = 'pause'; state = 'pack'; UI.pack(S, function (id) { var d = LP.DOCS[id]; UI.doc(d); state = 'doc'; backTo = 'pack'; }, objective()); };
    $('pMenu').onclick = function () { G.save(); G.toTitle(); };
    $('docClose').onclick = function () { if (backTo === 'pack') { backTo = 'play'; G.prev = 'pause'; state = 'pack'; UI.pack(S, function (id) { UI.doc(LP.DOCS[id]); state = 'doc'; backTo = 'pack'; }, objective()); } else G.back(); };
    $('dRetry').onclick = function () { A.resume(); G.retry(); };
    $('dMenu').onclick = function () { G.toTitle(); };
    $('endMenu').onclick = function () { G.toTitle(); };
    var d0 = LP.AREAS[0]; d0.rows = d0.build(); S = freshState(); W = new LP.World(d0, S); aiCtx.world = W;
    scene.fog = d0.fog; scene.dens = d0.dens; scene.wallH = d0.wallH; setState('title'); G.toTitle();
    g.requestAnimationFrame(loop);
  };
  LP.boot = function () { G.init(); };
})(typeof window !== 'undefined' ? window : globalThis);
