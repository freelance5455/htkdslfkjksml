/* Lost Prehistoria - jogador: movimento, fôlego, ruído, lanterna, veneno */
(function (g) {
  'use strict';
  var LP = g.LP, clamp = LP.clamp;
  var P = LP.Player = function () { this.reset(0, 0, 0); };
  P.prototype.reset = function (x, y, a) {
    this.x = x; this.y = y; this.a = a; this.hp = 100; this.stam = 100; this.bat = 100; this.crouch = false; this.sprint = false; this.flashOn = true; this.hidden = null; this.dead = false;
    this.poison = 0; this.vx = 0; this.vy = 0; this.speed = 0; this.stepD = 0; this.exhaust = false; this.stamDelay = 0; this.stun = 0; this.healT = 0; this.eyeH = 0.66;
    this.bob = 0; this.pitch = 0; this.hurtT = 0; this.r = 0.25; this.hideFace = 0; this.mag = 0; this.savedFlash = true; this.blur = 0;
  };
  P.prototype.visMul = function (W, sp) {
    var m = 1;
    if (this.crouch) m *= 0.6;
    if (this.sprint && this.speed > 2) m *= 1.25;
    if (this.flashOn) m *= 1.35; else if (W.lightAt(this.x, this.y) < 0.2) m *= 0.7;
    if (sp.motion && this.speed < 0.35) m *= 0.28;
    return m;
  };
  P.prototype.update = function (dt, In, W, G) {
    if (this.dead) return;
    var i;
    this.pitch = clamp(this.pitch + In.lookDY, -0.62, 0.62); In.lookDY = 0;
    if (this.hidden) { this.a += In.lookDX; var d = LP.angDiff(this.hideFace, this.a); this.a = this.hideFace + clamp(d, -0.75, 0.75); this.speed = 0; this.vx = this.vy = 0; In.lookDX = 0; this.sprint = false; }
    else { this.a += In.lookDX; In.lookDX = 0; }
    var mx = this.hidden ? 0 : In.mx, my = this.hidden ? 0 : In.my, mag = Math.min(1, Math.sqrt(mx * mx + my * my)); if (mag < 0.12) mag = 0;
    this.mag = mag;
    var want = (In.sprintLatch || In.sprintHold || (In.autoRun && mag > 0.9)) && mag > 0.5 && !this.crouch && !this.exhaust && this.stam > 0 && !this.hidden;
    this.sprint = want;
    var base = this.crouch ? 0.85 : (this.sprint ? 3.1 : 1.65), tv = base * (this.sprint || this.crouch ? mag : (0.3 + 0.7 * mag));
    if (mag === 0) tv = 0;
    if (this.stun > 0) { tv *= 0.35; this.stun -= dt; }
    if (this.healT > 0) tv *= 0.4;
    var fx = Math.cos(this.a), fy = Math.sin(this.a), rx = -fy, ry = fx, dx = fx * my + rx * mx, dy = fy * my + ry * mx, len = Math.sqrt(dx * dx + dy * dy);
    if (len > 1) { dx /= len; dy /= len; }
    if (!this.hidden) {
      var k = Math.min(1, dt * 12); this.vx += (dx * tv - this.vx) * k; this.vy += (dy * tv - this.vy) * k;
      var ox = this.x, oy = this.y; W.move(this, this.vx * dt, this.vy * dt, this.r);
      var mv = Math.sqrt((this.x - ox) * (this.x - ox) + (this.y - oy) * (this.y - oy));
      this.speed = mv / Math.max(dt, 1e-3); this.stepD += mv;
      if (this.speed > 0.2) this.bob += dt * (this.speed * 3.1 + 2); 
      var iv = this.crouch ? 0.75 : (this.sprint ? 1.05 : 0.9);
      if (this.stepD > iv) { this.stepD = 0; G.footstep(this); }
    }
    var te = this.crouch ? 0.42 : 0.66; this.eyeH += (te - this.eyeH) * Math.min(1, dt * 8);
    if (this.sprint && this.speed > 2) { this.stam -= 24 * dt; this.stamDelay = 1; }
    else { this.stamDelay -= dt; if (this.stamDelay <= 0) this.stam = Math.min(100, this.stam + 15 * dt); }
    if (this.stam <= 0) { this.stam = 0; this.exhaust = true; } else if (this.exhaust && this.stam >= 30) this.exhaust = false;
    if (this.flashOn) { this.bat -= 0.5 * dt; if (this.bat <= 0) { this.bat = 0; this.flashOn = false; G.batteryOut(); } }
    if (this.poison > 0) { this.poison -= dt; this.hp -= 3.2 * dt; this.blur = Math.min(1, this.blur + dt); if (this.hp <= 0) { this.hp = 0; G.die('venom'); } } else this.blur = Math.max(0, this.blur - dt * 0.5);
    if (this.healT > 0) { this.healT -= dt; if (this.healT <= 0) { this.hp = Math.min(100, this.hp + 45); this.poison = 0; } }
    if (this.hurtT > 0) this.hurtT -= dt;
  };
})(typeof window !== 'undefined' ? window : globalThis);
