/* Lost Prehistoria - construtor de mapas e as 5 áreas.
   Legenda: # = parede, = grade/metal, % sangue/janela, & garra/tronco, + porta, 1 2 3 cartão, C código, P energia, G portão,
   B barricada, h armário, H arbusto, v duto (esconderijos), t u terminal, L J alavanca, e saída, o c k props sólidos,
   @ início, s checkpoint, R X D K S dinossauros, m b z q w r g x n itens, I i E lâmpadas, 0-9 documentos (ver legend). */
(function (g) {
  'use strict';
  var LP = g.LP;

  function MB(w, h, seed) {
    this.w = w; this.h = h; this.R = {}; this.g = []; this.s = (seed || 1) >>> 0;
    for (var y = 0; y < h; y++) { var row = []; for (var x = 0; x < w; x++) row.push('#'); this.g.push(row); }
  }
  MB.prototype = {
    rnd: function () { this.s = (this.s + 0x6D2B79F5) >>> 0; var t = Math.imul(this.s ^ (this.s >>> 15), 1 | this.s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; },
    get: function (x, y) { return (x < 0 || y < 0 || x >= this.w || y >= this.h) ? '#' : this.g[y][x]; },
    put: function (x, y, c) { if (x >= 1 && y >= 1 && x < this.w - 1 && y < this.h - 1) this.g[y][x] = c; return this; },
    set: function (x, y, c) { if (x >= 0 && y >= 0 && x < this.w && y < this.h) this.g[y][x] = c; return this; },
    carve: function (x, y, w, h, f) { for (var j = 0; j < h; j++) for (var i = 0; i < w; i++) this.put(x + i, y + j, f || '.'); return this; },
    room: function (id, x, y, w, h, f) { this.carve(x, y, w, h, f); this.R[id] = { x: x, y: y, w: w, h: h }; return this; },
    isFloor: function (x, y) { var c = this.get(x, y); return c === '.' || c === ',' || c === '_'; },
    at: function (id, fx, fy) { var r = this.R[id]; return [r.x + Math.round((r.w - 1) * fx), r.y + Math.round((r.h - 1) * fy)]; },
    /* coloca um marcador no piso (procura o piso livre mais próximo se ocupado) */
    item: function (id, fx, fy, ch) {
      var p = this.at(id, fx, fy), r = this.R[id];
      for (var rad = 0; rad < 4; rad++) for (var dy = -rad; dy <= rad; dy++) for (var dx = -rad; dx <= rad; dx++) {
        var x = p[0] + dx, y = p[1] + dy;
        if (x < r.x || y < r.y || x >= r.x + r.w || y >= r.y + r.h) continue;
        if (this.isFloor(x, y)) { this.put(x, y, ch); return [x, y]; }
      }
      throw new Error('sem espaço para ' + ch + ' em ' + id);
    },
    lamp: function (id, ch, fx, fy) { return this.item(id, fx, fy, ch); },
    /* item na linha da parede da sala: n s w e */
    wallItem: function (id, side, t, ch) {
      var r = this.R[id], best = null;
      for (var k = 0; k < 40; k++) {
        var o = (k % 2 ? 1 : -1) * Math.ceil(k / 2), x, y, ix, iy;
        if (side === 'n') { x = r.x + Math.round((r.w - 1) * t) + o; y = r.y - 1; ix = x; iy = y + 1; }
        else if (side === 's') { x = r.x + Math.round((r.w - 1) * t) + o; y = r.y + r.h; ix = x; iy = y - 1; }
        else if (side === 'w') { x = r.x - 1; y = r.y + Math.round((r.h - 1) * t) + o; ix = x + 1; iy = y; }
        else { x = r.x + r.w; y = r.y + Math.round((r.h - 1) * t) + o; ix = x - 1; iy = y; }
        var inside = ix >= r.x && ix < r.x + r.w && iy >= r.y && iy < r.y + r.h;
        if (inside && this.get(x, y) === '#' && this.isFloor(ix, iy) && !this.doorNear(x, y, 1)) { this.set(x, y, ch); return [x, y]; }
      }
      throw new Error('sem parede para ' + ch + ' em ' + id);
    },
    doorNear: function (x, y, rad) {
      for (var dy = -rad; dy <= rad; dy++) for (var dx = -rad; dx <= rad; dx++) if ('+123CPGBeLJtuhHv'.indexOf(this.get(x + dx, y + dy)) >= 0) return true;
      return false;
    },
    /* props sólidos junto às paredes, longe de portas */
    scatter: function (id, ch, n) {
      var r = this.R[id], tries = 0;
      while (n > 0 && tries++ < 200) {
        var x = r.x + ((this.rnd() * r.w) | 0), y = r.y + ((this.rnd() * r.h) | 0);
        var edge = (x === r.x || y === r.y || x === r.x + r.w - 1 || y === r.y + r.h - 1);
        if (!edge || !this.isFloor(x, y) || this.doorNear(x, y, 2)) continue;
        var open = 0, dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
        for (var d = 0; d < 4; d++) if (this.isFloor(x + dirs[d][0], y + dirs[d][1])) open++;
        if (open < 2) continue;
        this.put(x, y, ch); n--;
      }
      return this;
    },
    pillar: function (id, fx, fy, ch) { var p = this.at(id, fx, fy); this.put(p[0], p[1], ch || '&'); return this; },
    link: function (a, b, o) {
      o = o || {}; var A = this.R[a], Bm = this.R[b], wd = o.wd || 1, door = o.door, k, i;
      if (A.x + A.w <= Bm.x || Bm.x + Bm.w <= A.x) {
        var L = A.x < Bm.x ? A : Bm, Rr = A.x < Bm.x ? Bm : A, gx0 = L.x + L.w, gx1 = Rr.x - 1;
        var oy0 = Math.max(A.y, Bm.y), oy1 = Math.min(A.y + A.h, Bm.y + Bm.h) - 1;
        var y = o.y !== undefined ? o.y : Math.floor((oy0 + oy1) / 2 - (wd - 1) / 2 + 0.5);
        for (i = gx0; i <= gx1; i++) for (k = 0; k < wd; k++) this.put(i, y + k, '.');
        if (door) for (k = 0; k < wd; k++) this.put(gx0, y + k, door);
      } else {
        var T = A.y < Bm.y ? A : Bm, Bt = A.y < Bm.y ? Bm : A, gy0 = T.y + T.h, gy1 = Bt.y - 1;
        var ox0 = Math.max(A.x, Bm.x), ox1 = Math.min(A.x + A.w, Bm.x + Bm.w) - 1;
        var x = o.x !== undefined ? o.x : Math.floor((ox0 + ox1) / 2 - (wd - 1) / 2 + 0.5);
        for (i = gy0; i <= gy1; i++) for (k = 0; k < wd; k++) this.put(x + k, i, '.');
        if (door) for (k = 0; k < wd; k++) this.put(x + k, gy0, door);
      }
      return this;
    },
    /* florestas e cavernas */
    blob: function (cx, cy, rx, ry, f) {
      for (var y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++) for (var x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) {
        var dx = (x - cx) / rx, dy = (y - cy) / ry; if (dx * dx + dy * dy <= 1) this.put(x, y, f || '.');
      }
      return this;
    },
    path: function (pts, wd, f) {
      for (var s = 0; s < pts.length - 1; s++) {
        var a = pts[s], b = pts[s + 1], n = Math.max(Math.abs(b[0] - a[0]), Math.abs(b[1] - a[1])) * 2 + 1;
        var px = null, py = null, self = this;
        var brush = function (x, y) { for (var dy = 0; dy < wd; dy++) for (var dx = 0; dx < wd; dx++) self.put(x - (wd >> 1) + dx, y - (wd >> 1) + dy, f || '.'); };
        for (var i = 0; i <= n; i++) {
          var x = Math.round(a[0] + (b[0] - a[0]) * i / n), y = Math.round(a[1] + (b[1] - a[1]) * i / n);
          if (px !== null && x !== px && y !== py) brush(x, py);
          brush(x, y); px = x; py = y;
        }
      }
      return this;
    },
    /* nichos: tiles de parede com uma única abertura para o piso (usados por emboscadas e arbustos) */
    nooks: function (n, ch, fx0, fx1) {
      var c = [], x, y, dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
      for (y = 2; y < this.h - 2; y++) for (x = Math.max(2, fx0 || 2); x < Math.min(this.w - 2, fx1 || this.w - 2); x++) {
        if (this.get(x, y) !== '#' && this.get(x, y) !== '&') continue;
        var open = 0, wall = 0;
        for (var d = 0; d < 4; d++) { if (this.isFloor(x + dirs[d][0], y + dirs[d][1])) open++; else wall++; }
        var diag = 0; for (var dx = -1; dx <= 1; dx += 2) for (var dy = -1; dy <= 1; dy += 2) if (this.isFloor(x + dx, y + dy)) diag++;
        if (open === 1 && diag <= 2 && !this.doorNear(x, y, 2)) c.push([x, y]);
      }
      var out = [], step = Math.max(1, Math.floor(c.length / n));
      for (var i = Math.floor(this.rnd() * step); i < c.length && out.length < n; i += step) out.push(c[i]);
      return out;
    },
    trees: function () {
      var out = this.g.map(function (r) { return r.slice(); }), x, y;
      for (y = 1; y < this.h - 1; y++) for (x = 1; x < this.w - 1; x++) {
        if (this.g[y][x] !== '#') continue;
        var near = false;
        for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) if (this.isFloor(x + dx, y + dy)) near = true;
        if (near && this.rnd() < 0.4) out[y][x] = '&';
      }
      this.g = out; return this;
    },
    rows: function () { return this.g.map(function (r) { return r.join(''); }); }
  };
  LP.MB = MB;

  /* ================= ÁREA 1 — Centro de pesquisas ================= */
  function buildA1() {
    var B = new MB(41, 26, 11);
    B.room('labA', 1, 1, 14, 7); B.room('labB', 16, 1, 12, 7); B.room('ctrl', 29, 1, 11, 7);
    B.room('offA', 1, 9, 8, 6); B.room('offB', 10, 9, 8, 6); B.room('copa', 19, 9, 7, 6); B.room('arch', 27, 9, 7, 6); B.room('vest', 35, 9, 5, 6);
    B.room('hall', 1, 16, 39, 2);
    B.room('lobby', 1, 19, 12, 6); B.room('sec', 14, 19, 8, 6); B.room('stor', 23, 19, 10, 6); B.room('dock', 34, 19, 6, 6);
    B.link('lobby', 'hall', { door: '+', x: 6 }).link('sec', 'hall', { door: '+', x: 17 }).link('stor', 'hall', { door: '+', x: 27 }).link('dock', 'hall', { door: '+', x: 36 });
    B.link('offA', 'hall', { door: '+', x: 4 }).link('offB', 'hall', { door: '+', x: 13 }).link('copa', 'hall', { door: '+', x: 22 }).link('arch', 'hall', { door: '+', x: 30 }).link('vest', 'hall', { door: '+', x: 37 });
    B.link('offA', 'offB', { door: '+', y: 11 }).link('offB', 'copa', { door: '+', y: 11 }).link('copa', 'arch', { door: '+', y: 11 }).link('arch', 'vest', { door: '+', y: 11 });
    B.link('labA', 'offA', { door: '1', x: 4 }).link('labB', 'offB', { door: '1', x: 17 });
    B.link('labA', 'labB', { door: '+', y: 4 }).link('labB', 'ctrl', { door: 'C', y: 4 });
    B.set(40, 22, 'e');
    /* início e recepção */
    B.item('lobby', 0.06, 0.78, '@'); B.item('lobby', 0.92, 0.12, 'b'); B.item('lobby', 0.5, 0.06, 'z'); B.item('lobby', 0.3, 0.9, '4');
    B.item('lobby', 0.5, 0.42, 'k'); B.item('lobby', 0.62, 0.42, 'k'); B.scatter('lobby', 'c', 2).scatter('lobby', 'o', 1).scatter('lobby', 'N', 2);
    B.lamp('lobby', 'I', 0.3, 0.5); B.lamp('lobby', 'i', 0.78, 0.5); B.wallItem('lobby', 'n', 0.12, 'h');
    /* segurança */
    B.item('sec', 0.5, 0.2, 'q'); B.item('sec', 0.5, 0.5, 'k'); B.item('sec', 0.1, 0.55, 's'); B.wallItem('sec', 'n', 0.85, 'h'); B.wallItem('sec', 's', 0.5, 'u');
    B.lamp('sec', 'I', 0.5, 0.75); B.scatter('sec', 'c', 1);
    /* corredor principal */
    B.item('hall', 0.5, 0.5, '^'); B.item('hall', 0.82, 0.5, 'R');
    B.lamp('hall', 'i', 0.12, 0.5); B.lamp('hall', 'I', 0.32, 0.5); B.lamp('hall', 'i', 0.52, 0.5); B.lamp('hall', 'E', 0.72, 0.5); B.lamp('hall', 'I', 0.92, 0.5);
    /* escritórios */
    B.item('offA', 0.5, 0.5, '5'); B.item('offA', 0.85, 0.15, 'm'); B.scatter('offA', 'c', 2); B.wallItem('offA', 'w', 0.5, 'h'); B.lamp('offA', 'i', 0.5, 0.5);
    B.item('offB', 0.2, 0.2, 'z'); B.scatter('offB', 'k', 2); B.wallItem('offB', 'n', 0.5, 'h'); B.lamp('offB', 'I', 0.5, 0.5);
    B.item('copa', 0.5, 0.5, '6'); B.item('copa', 0.15, 0.15, 'm'); B.scatter('copa', 'c', 2); B.wallItem('copa', 's', 0.5, 'h'); B.lamp('copa', 'i', 0.5, 0.5);
    B.item('arch', 0.5, 0.5, '7'); B.scatter('arch', 'c', 3); B.wallItem('arch', 'e', 0.5, 'h'); B.lamp('arch', 'I', 0.5, 0.5);
    B.item('vest', 0.5, 0.5, '9'); B.item('vest', 0.5, 0.9, 'b'); B.wallItem('vest', 'e', 0.3, 'h'); B.wallItem('vest', 'e', 0.8, 'h'); B.lamp('vest', 'E', 0.5, 0.3);
    /* laboratórios */
    B.item('labA', 0.5, 0.15, '8'); B.item('labA', 0.12, 0.85, 'z'); B.scatter('labA', 'k', 3).scatter('labA', 'c', 2); B.wallItem('labA', 'n', 0.3, 'h');
    B.lamp('labA', 'I', 0.25, 0.5); B.lamp('labA', 'i', 0.75, 0.5);
    B.item('labB', 0.5, 0.5, '0'); B.item('labB', 0.85, 0.8, 'm'); B.scatter('labB', 'k', 2).scatter('labB', 'c', 2); B.wallItem('labB', 'n', 0.7, 'h');
    B.lamp('labB', 'E', 0.5, 0.5); B.lamp('labB', 'i', 0.2, 0.3);
    B.item('ctrl', 0.5, 0.5, 'w'); B.item('ctrl', 0.12, 0.2, 's'); B.wallItem('ctrl', 'n', 0.7, 't'); B.scatter('ctrl', 'k', 3); B.lamp('ctrl', 'I', 0.5, 0.7); B.wallItem('ctrl', 's', 0.3, 'h');
    /* depósito e doca */
    B.item('stor', 0.1, 0.2, 'm'); B.item('stor', 0.9, 0.8, 'b'); B.item('stor', 0.5, 0.15, 'z'); B.scatter('stor', 'c', 3).scatter('stor', 'o', 3).scatter('stor', 'M', 2).scatter('stor', 'N', 1); B.lamp('stor', 'i', 0.5, 0.5); B.wallItem('stor', 's', 0.5, 'h');
    B.scatter('dock', 'c', 1).scatter('dock', 'N', 2); B.lamp('dock', 'I', 0.5, 0.5); B.item('dock', 0.4, 0.5, 'j');
    return B.rows();
  }

  /* ================= ÁREA 2 — Recintos de contenção ================= */
  function buildA2() {
    var B = new MB(48, 33, 22);
    B.room('entry', 1, 15, 6, 7); B.room('ave', 8, 17, 37, 5);
    B.room('n1', 8, 3, 13, 13); B.room('n2', 22, 3, 13, 13); B.room('n3', 36, 3, 9, 13);
    B.room('tun', 1, 23, 44, 1);
    B.room('ctrl', 8, 25, 13, 7); B.room('stor2', 22, 25, 13, 7); B.room('obs', 36, 25, 9, 7);
    B.link('entry', 'ave', { wd: 5, y: 17 });
    B.link('n1', 'ave', { wd: 3, x: 12 }).link('n2', 'ave', { wd: 3, x: 27 }).link('n3', 'ave', { wd: 5, x: 38, door: 'B' });
    B.link('ave', 'tun', { door: '+', x: 14 }).link('ave', 'tun', { door: '+', x: 28 }).link('ave', 'tun', { door: '+', x: 40 }).link('entry', 'tun', { door: '+', x: 3 });
    B.link('tun', 'ctrl', { door: 'C', x: 14 }).link('tun', 'stor2', { door: '+', x: 28 }).link('tun', 'obs', { door: '+', x: 40 });
    B.put(45, 19, 'e');
    B.item('entry', 0.15, 0.5, '@'); B.item('entry', 0.6, 0.9, 's'); B.lamp('entry', 'I', 0.5, 0.5); B.item('entry', 0.9, 0.1, 'z'); B.item('entry', 0.2, 0.1, 'm');
    B.item('n1', 0.5, 0.45, 'R'); B.item('n1', 0.92, 0.92, '4'); B.item('n1', 0.1, 0.1, 'b'); B.lamp('n1', 'i', 0.5, 0.2); B.lamp('n1', 'I', 0.5, 0.8); B.pillar('n1', 0.3, 0.6, 'M').pillar('n1', 0.75, 0.35, 'N').pillar('n1', 0.5, 0.8, 'N');
    B.item('n2', 0.5, 0.5, 'K'); B.lamp('n2', 'I', 0.5, 0.15); B.lamp('n2', 'i', 0.5, 0.85);
    B.pillar('n2', 0.2, 0.3, 'N').pillar('n2', 0.8, 0.3, 'M').pillar('n2', 0.35, 0.7, 'N').pillar('n2', 0.7, 0.75, 'M').pillar('n2', 0.5, 0.25, 'N'); B.item('n2', 0.92, 0.9, 'm'); B.item('n2', 0.08, 0.08, 'j');
    B.item('n3', 0.5, 0.4, 'X'); B.lamp('n3', 'E', 0.5, 0.3); B.item('n3', 0.2, 0.9, 'j'); B.item('n3', 0.85, 0.15, 'j');
    B.item('ave', 0.7, 0.5, 'R');
    B.lamp('ave', 'I', 0.06, 0.5); B.lamp('ave', 'i', 0.26, 0.5); B.lamp('ave', 'I', 0.46, 0.5); B.lamp('ave', 'i', 0.66, 0.5); B.lamp('ave', 'I', 0.86, 0.5);
    B.lamp('tun', 'E', 0.18, 0.5); B.lamp('tun', 'E', 0.5, 0.5); B.lamp('tun', 'E', 0.82, 0.5); B.item('tun', 0.35, 0.5, 'z');
    B.wallItem('tun', 's', 0.08, 'v'); B.wallItem('tun', 's', 0.36, 'v'); B.wallItem('tun', 's', 0.64, 'v'); B.wallItem('tun', 's', 0.92, 'v');
    B.wallItem('ctrl', 's', 0.5, 'L'); B.wallItem('ctrl', 's', 0.18, 't'); B.item('ctrl', 0.5, 0.4, '5'); B.item('ctrl', 0.9, 0.2, 's'); B.scatter('ctrl', 'k', 3); B.lamp('ctrl', 'I', 0.5, 0.5); B.wallItem('ctrl', 'e', 0.3, 'h');
    B.item('stor2', 0.5, 0.2, '6'); B.item('stor2', 0.1, 0.9, 'b'); B.item('stor2', 0.9, 0.8, 'm'); B.scatter('stor2', 'c', 3).scatter('stor2', 'o', 3).scatter('stor2', 'M', 1); B.lamp('stor2', 'i', 0.5, 0.5); B.wallItem('stor2', 's', 0.5, 'h');
    B.item('obs', 0.5, 0.3, '7'); B.item('obs', 0.2, 0.8, '0'); B.item('obs', 0.85, 0.2, 'z'); B.item('obs', 0.85, 0.85, 'm'); B.item('obs', 0.1, 0.2, 's'); B.scatter('obs', 'k', 2); B.lamp('obs', 'I', 0.5, 0.5); B.wallItem('obs', 'e', 0.5, 'h');
    return B.rows();
  }

  /* ================= ÁREA 3 — Floresta ================= */
  function buildA3() {
    var B = new MB(60, 44, 33);
    B.path([[3, 22], [12, 21], [20, 24], [30, 21], [40, 17], [50, 20], [56, 20]], 3, '_');
    B.blob(5, 22, 5, 4, '.'); B.blob(36, 20, 8, 6, '.'); B.blob(52, 20, 4, 3, '.');
    B.path([[14, 21], [15, 14]], 1, '_'); B.blob(17, 10, 5, 4, '.');
    B.path([[21, 25], [22, 28], [24, 33]], 1, '_'); B.blob(29, 35, 6, 4, '.');
    B.path([[22, 28], [30, 29], [40, 29], [46, 24], [46, 19]], 1, ',');
    B.blob(34, 29, 3, 2, ',');
    B.R.start = { x: 2, y: 20, w: 7, h: 5 }; B.R.camp = { x: 13, y: 7, w: 9, h: 7 }; B.R.wreck = { x: 24, y: 32, w: 11, h: 7 }; B.R.arena = { x: 29, y: 16, w: 15, h: 9 }; B.R.bunk = { x: 49, y: 18, w: 7, h: 5 };
    B.trees();
    var nk = B.nooks(14, 'D', 8, 54), i, p, ds = 0;
    for (i = 0; i < nk.length; i++) { p = nk[i]; if (ds < 5 && i % 2 === 0) { B.put(p[0], p[1], 'D'); ds++; } else if (i % 2 === 1) B.put(p[0], p[1], 'H'); }
    B.item('start', 0.15, 0.5, '@'); B.item('start', 0.8, 0.2, 'z');
    B.item('camp', 0.5, 0.45, 'r'); B.item('camp', 0.2, 0.7, 's'); B.item('camp', 0.8, 0.3, '4'); B.item('camp', 0.3, 0.2, '5'); B.item('camp', 0.8, 0.8, 'm'); B.lamp('camp', 'i', 0.5, 0.7); B.item('camp', 0.15, 0.15, 'j');
    B.item('wreck', 0.5, 0.5, 'x'); B.item('wreck', 0.2, 0.3, '6'); B.item('wreck', 0.85, 0.7, '0'); B.item('wreck', 0.1, 0.8, 'b'); B.item('wreck', 0.8, 0.15, 'm'); B.lamp('wreck', 'i', 0.4, 0.4); B.scatter('wreck', 'o', 2);
    B.item('arena', 0.5, 0.5, 'K'); B.pillar('arena', 0.25, 0.3, 'N').pillar('arena', 0.7, 0.25, '&').pillar('arena', 0.4, 0.75, 'N').pillar('arena', 0.8, 0.7, 'N').pillar('arena', 0.64, 0.56, 'N'); B.item('arena', 0.9, 0.9, 'm');
    B.item('bunk', 0.3, 0.5, 'b'); B.lamp('bunk', 'I', 0.6, 0.5);
    B.put(57, 20, 'e');
    B.item('start', 0.9, 0.9, 'z');
    var rp = [[16, 22], [34, 20]], k;
    for (k = 0; k < rp.length; k++) { var q = rp[k]; B.put(q[0], q[1], 'R'); }
    B.item('wreck', 0.65, 0.2, 'z'); B.item('arena', 0.1, 0.1, 'b'); B.item('camp', 0.9, 0.9, 'z');
    return B.rows();
  }

  /* ================= ÁREA 4 — Instalação subterrânea ================= */
  function buildA4() {
    var B = new MB(50, 34, 44);
    B.room('arr', 1, 14, 8, 7); B.room('c1', 10, 17, 12, 1);
    B.room('gen', 23, 12, 12, 10); B.room('exp1', 23, 2, 12, 8); B.room('exp2', 37, 12, 10, 10); B.room('cells', 37, 2, 10, 8); B.room('omega', 23, 24, 12, 8);
    B.link('arr', 'c1', { door: '+', y: 17 }); B.link('c1', 'gen', { door: '+', y: 17 });
    B.link('gen', 'exp1', { door: 'P', x: 28 }); B.link('gen', 'exp2', { door: 'P', y: 16 }); B.link('exp2', 'cells', { door: 'P', x: 41 }); B.link('exp1', 'cells', { door: '+', y: 5 });
    B.link('gen', 'omega', { door: 'P', x: 28 });
    B.set(35, 28, 'e');
    B.item('arr', 0.15, 0.5, '@'); B.item('arr', 0.85, 0.15, 'm'); B.item('arr', 0.85, 0.85, 'z'); B.item('arr', 0.5, 0.15, 's'); B.lamp('arr', 'E', 0.5, 0.5); B.wallItem('arr', 'n', 0.5, 'h');
    B.lamp('c1', 'E', 0.2, 0.5); B.lamp('c1', 'i', 0.7, 0.5); B.wallItem('c1', 'n', 0.5, 'v'); B.item('c1', 0.9, 0.5, 'z');
    B.wallItem('gen', 'n', 0.5, 'L'); B.item('gen', 0.5, 0.5, '4'); B.scatter('gen', 'o', 3).scatter('gen', 'c', 2).scatter('gen', 'N', 3); B.lamp('gen', 'i', 0.3, 0.5); B.lamp('gen', 'E', 0.75, 0.5); B.item('gen', 0.1, 0.9, 'b'); B.wallItem('gen', 'w', 0.2, 'h'); B.item('gen', 0.9, 0.15, 's');
    B.item('exp1', 0.5, 0.5, '5'); B.item('exp1', 0.9, 0.2, 'm'); B.scatter('exp1', 'k', 3); B.wallItem('exp1', 'n', 0.3, 'h'); B.lamp('exp1', 'I', 0.5, 0.5); B.wallItem('exp1', 'w', 0.5, 'v');
    B.item('exp2', 0.5, 0.5, '6'); B.item('exp2', 0.12, 0.85, 'b'); B.item('exp2', 0.88, 0.85, 'm'); B.item('exp2', 0.5, 0.15, 'R'); B.scatter('exp2', 'c', 2).scatter('exp2', 'M', 2); B.scatter('exp2', 'k', 2); B.wallItem('exp2', 'e', 0.5, 'h'); B.lamp('exp2', 'i', 0.5, 0.4);
    B.item('cells', 0.5, 0.5, 'S'); B.item('cells', 0.15, 0.2, '7'); B.item('cells', 0.9, 0.8, 'z'); B.scatter('cells', 'j', 2); B.lamp('cells', 'E', 0.5, 0.2); B.wallItem('cells', 'e', 0.3, 'h'); B.wallItem('cells', 's', 0.6, 'v');
    B.item('omega', 0.5, 0.3, 'n'); B.item('omega', 0.15, 0.8, '8'); B.item('omega', 0.85, 0.2, '9'); B.item('omega', 0.9, 0.85, 'm'); B.wallItem('omega', 's', 0.5, 't'); B.item('omega', 0.1, 0.15, 's'); B.scatter('omega', 'k', 3); B.lamp('omega', 'I', 0.5, 0.6); B.lamp('omega', 'i', 0.2, 0.3);
    return B.rows();
  }

  /* ================= ÁREA 5 — Área final ================= */
  function buildA5() {
    var B = new MB(58, 34, 55);
    B.room('elev', 1, 15, 5, 6); B.room('yard', 8, 10, 25, 16);
    B.room('tw1', 8, 2, 10, 6); B.room('comm', 20, 2, 10, 6); B.room('gen', 20, 28, 10, 4);
    B.room('pad', 38, 6, 19, 22);
    B.link('elev', 'yard', { door: '+', y: 17 }); B.link('tw1', 'yard', { door: '+', x: 12 }); B.link('tw1', 'comm', { door: 'P', y: 4 }); B.link('yard', 'gen', { door: '+', x: 24 });
    B.link('yard', 'pad', { wd: 5, y: 14, door: 'B' });
    B.path([[31, 4], [48, 4], [48, 5]], 1, '.'); B.put(30, 4, '+');
    B.item('elev', 0.3, 0.5, '@'); B.item('elev', 0.8, 0.2, 's'); B.lamp('elev', 'I', 0.5, 0.5); B.item('elev', 0.8, 0.8, 'm');
    B.item('yard', 0.5, 0.5, 'K'); B.item('yard', 0.85, 0.2, 'R'); B.item('yard', 0.2, 0.85, 'R'); B.item('yard', 0.1, 0.3, 'b');
    B.pillar('yard', 0.3, 0.3, 'M').pillar('yard', 0.65, 0.3, 'N').pillar('yard', 0.3, 0.7, 'N').pillar('yard', 0.65, 0.7, 'M'); B.scatter('yard', 'c', 3).scatter('yard', 'o', 3).scatter('yard', 'N', 3);
    B.lamp('yard', 'I', 0.2, 0.2); B.lamp('yard', 'i', 0.8, 0.2); B.lamp('yard', 'I', 0.2, 0.8); B.lamp('yard', 'i', 0.8, 0.8); B.lamp('yard', 'I', 0.5, 0.5);
    B.item('yard', 0.9, 0.55, 'm'); B.item('yard', 0.06, 0.1, 'z');
    B.item('tw1', 0.5, 0.5, '4'); B.wallItem('tw1', 'n', 0.5, 'L'); B.scatter('tw1', 'k', 2); B.lamp('tw1', 'i', 0.5, 0.5); B.wallItem('tw1', 'w', 0.5, 'h'); B.item('tw1', 0.9, 0.9, 'm');
    B.item('comm', 0.5, 0.5, '5'); B.wallItem('comm', 'n', 0.5, 't'); B.scatter('comm', 'k', 3); B.lamp('comm', 'I', 0.5, 0.5); B.item('comm', 0.9, 0.9, 'b'); B.wallItem('comm', 's', 0.3, 'h');
    B.wallItem('gen', 's', 0.5, 'J'); B.item('gen', 0.5, 0.3, '0'); B.lamp('gen', 'E', 0.5, 0.5); B.item('gen', 0.9, 0.5, 'm');
    B.item('pad', 0.5, 0.5, 'X'); B.lamp('pad', 'I', 0.2, 0.2); B.lamp('pad', 'I', 0.8, 0.2); B.lamp('pad', 'I', 0.2, 0.8); B.lamp('pad', 'I', 0.8, 0.8);
    B.pillar('pad', 0.3, 0.5, 'M').pillar('pad', 0.6, 0.3, 'N').pillar('pad', 0.6, 0.7, 'N'); B.scatter('pad', 'o', 2).scatter('pad', 'N', 2);
    B.set(57, 17, 'e');
    return B.rows();
  }

  /* ================= definições das áreas ================= */
  LP.AREAS = [
    {
      id: 'a1', n: 1, name: 'Centro de pesquisas', sub: 'Instalação Prehistoria-7, nível de superfície', wallH: 1.15, amb: [0.045, 0.05, 0.06], fog: [6, 9, 11], dens: 0.07,
      lampCol: [0.78, 0.9, 1], lampI: 0.9, lampRad: 5.5, sound: 'lab', startAngle: 0, build: buildA1,
      pal: { wa: 'conc', wb: 'metal', wc: 'conc_blood', wd: 'conc_claw', f0: 'f_tile', f1: 'f_stain', f2: 'f_grate', ceil: 'c_lab' },
      legend: {
        '4': { t: 'doc', id: 'a1_aviso' }, '5': { t: 'doc', id: 'a1_email' }, '6': { t: 'doc', id: 'a1_postit', key: 1 }, '7': { t: 'doc', id: 'a1_relatorio' }, '8': { t: 'doc', id: 'a1_lab' }, '9': { t: 'doc', id: 'a1_vest' },
        '0': { t: 'log', id: 'a1_helena' }, '^': { t: 'trig', ev: 'a1_shadow', id: 'a1_shadow' }, 't': { t: 'term', id: 'a1_ctrl' }, 'u': { t: 'term', id: 'a1_sec' }
      },
      codes: { C: '3147' }, exit: { need: { card: 2 }, to: 1, msg: 'A porta da doca exige o cartão de acesso nível 2.' },
      obj: function (S) { if (!S.inv.card1) return 'Encontre o cartão de acesso nível 1 (sala de segurança).'; if (!S.inv.card2) return 'Chegue à sala de controle auxiliar no laboratório. O código está em algum lugar dos escritórios.'; return 'Leve o cartão nível 2 até a saída da doca, no canto sudeste.'; }
    },
    {
      id: 'a2', n: 2, name: 'Recintos de contenção', sub: 'Avenida dos recintos, setor leste', wallH: 2.2, amb: [0.05, 0.05, 0.055], fog: [8, 11, 10], dens: 0.05,
      lampCol: [1, 0.72, 0.38], lampI: 0.85, lampRad: 7, sound: 'pens', startAngle: 0, build: buildA2,
      pal: { wa: 'conc2', wb: 'cage', wc: 'conc_blood', wd: 'metal', f0: 'f_conc', f1: 'f_stain', f2: 'f_grate', ceil: 'c_dark' },
      legend: {
        '4': { t: 'doc', id: 'a2_comport' }, '5': { t: 'doc', id: 'a2_trexdoc' }, '6': { t: 'doc', id: 'a2_codigo', key: 1 }, '7': { t: 'doc', id: 'a2_seg' }, '0': { t: 'log', id: 'a2_duarte' },
        't': { t: 'term', id: 'a2_ctrl' }, 'L': { t: 'lever', flag: 'a2_power', ev: 'a2_trex', msg: 'Energia dos portões restaurada. Algo enorme se move no recinto leste.' }
      },
      codes: { C: '5926' }, powerFlag: 'a2_power', dormant: { X: 'a2_trex' }, exit: { need: { flag: 'a2_power' }, to: 2, msg: 'O portão leste está sem energia. Ligue a alavanca na sala de controle.' },
      obj: function (S) { if (!S.flags.a2_power) return 'Chegue à sala de controle (túnel de serviço, sul). O código do painel está na sala de suprimentos.'; return 'Atravesse a avenida até o portão leste. Fuja do que quebrou a barricada.'; }
    },
    {
      id: 'a3', n: 3, name: 'Floresta', sub: 'Mata fechada, perímetro externo', wallH: 3, amb: [0.035, 0.05, 0.055], fog: [8, 14, 14], dens: 0.075,
      lampCol: [1, 0.66, 0.32], lampI: 0.95, lampRad: 7.5, sound: 'forest', startAngle: 0, build: buildA3,
      pal: { wa: 'leaves', wb: 'bark', wc: 'bush', wd: 'bark', f0: 'f_grass', f1: 'f_mud', f2: 'f_path', ceil: 'c_canopy', blk: 'rock' },
      legend: { '4': { t: 'doc', id: 'a3_equipe' }, '5': { t: 'doc', id: 'a3_diario' }, '6': { t: 'doc', id: 'a3_dilo' }, '0': { t: 'log', id: 'a3_helena2' } },
      exit: { need: { card: 3 }, to: 3, msg: 'A escotilha do bunker exige o cartão nível 3. A equipe de resgate pode ter um.' },
      obj: function (S) { if (!S.inv.card3) return 'Siga a trilha. Procure o acampamento da equipe de resgate (norte) e o cartão nível 3.'; if (!S.inv.fuse) return 'Encontre um fusível nos destroços do helicóptero (sul) antes de descer ao bunker.'; return 'Chegue à escotilha do bunker, no leste da trilha.'; }
    },
    {
      id: 'a4', n: 4, name: 'Instalação subterrânea', sub: 'Nível -3, ala experimental', wallH: 1.35, amb: [0.035, 0.045, 0.06], fog: [5, 9, 12], dens: 0.08,
      lampCol: [0.5, 0.82, 1], lampI: 0.85, lampRad: 5.5, sound: 'deep', startAngle: 0, build: buildA4,
      pal: { wa: 'rock', wb: 'pipes', wc: 'conc2', wd: 'metal', f0: 'f_metal', f1: 'f_stain', f2: 'f_grate', ceil: 'c_pipes', blk: 'rock' },
      legend: {
        '4': { t: 'doc', id: 'a4_ecos' }, '5': { t: 'doc', id: 'a4_exp1' }, '6': { t: 'doc', id: 'a4_omega' }, '7': { t: 'doc', id: 'a4_celas' }, '8': { t: 'doc', id: 'a4_fenix', key: 1 }, '9': { t: 'doc', id: 'a4_diretora' },
        't': { t: 'term', id: 'a4_term' }, 'L': { t: 'lever', flag: 'a4_power', need: { item: 'fuse' }, ev: 'a4_power', msg: 'Gerador de emergência ligado. As portas de energia destravaram. Algo respondeu ao ruído.' }
      },
      powerFlag: 'a4_power', dormant: { S: 'a4_power' }, exit: { need: { flag: 'a4_core' }, to: 4, msg: 'O elevador de carga só libera com o núcleo genético em mãos.' },
      obj: function (S) { if (!S.flags.a4_power) return 'Ligue o gerador na sala principal usando o fusível.'; if (!S.flags.a4_core) return 'Encontre o núcleo genético no Laboratório Ômega (sul). Fique em silêncio quando ouvir cliques.'; return 'Leve o núcleo ao elevador de carga, no laboratório Ômega.'; }
    },
    {
      id: 'a5', n: 5, name: 'Área final', sub: 'Superfície, torre de comunicações e heliponto', wallH: 2.4, amb: [0.05, 0.055, 0.075], fog: [10, 14, 22], dens: 0.045,
      lampCol: [0.85, 0.9, 1], lampI: 0.9, lampRad: 7, sound: 'storm', startAngle: 0, build: buildA5,
      pal: { wa: 'conc2', wb: 'brick', wc: 'conc_claw', wd: 'metal', f0: 'f_conc', f1: 'f_dirt', f2: 'f_grate', ceil: 'c_sky' },
      legend: {
        '4': { t: 'doc', id: 'a5_fenix' }, '5': { t: 'doc', id: 'a5_ordem' }, '0': { t: 'log', id: 'a5_piloto' }, 't': { t: 'term', id: 'a5_final' },
        'L': { t: 'lever', flag: 'a5_l1', msg: 'Antena principal energizada.' }, 'J': { t: 'lever', flag: 'a5_l2', msg: 'Gerador do heliponto ligado.' }
      },
      powerFlag: 'a5_l2', dormant: { X: 'a5_chase' }, exit: { need: { flag: 'a5_chopper' }, to: 'end', msg: 'O helicóptero ainda não pousou. Sobreviva até o resgate chegar.' },
      obj: function (S) { if (!S.flags.a5_l1 || !S.flags.a5_l2) return 'Ligue as duas alavancas: a antena na torre (norte) e o gerador (sul do pátio).'; if (!S.flags.a5_decided) return 'Use o terminal da sala de comunicações e decida o destino das provas.'; if (!S.flags.a5_chopper) return 'Corra até o heliponto (leste) e sobreviva até o helicóptero pousar.'; return 'O helicóptero pousou! Embarque na porta do heliponto.'; }
    }
  ];
})(typeof window !== 'undefined' ? window : globalThis);
