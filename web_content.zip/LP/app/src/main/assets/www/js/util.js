/* Lost Prehistoria - utilitários base */
(function (g) {
  'use strict';
  var LP = g.LP = g.LP || {};
  LP.VER = '0.1.0';
  LP.TAU = Math.PI * 2;
  LP.clamp = function (v, a, b) { return v < a ? a : v > b ? b : v; };
  LP.lerp = function (a, b, t) { return a + (b - a) * t; };
  LP.angNorm = function (a) {
    a = a % LP.TAU;
    if (a > Math.PI) a -= LP.TAU; else if (a < -Math.PI) a += LP.TAU;
    return a;
  };
  LP.angDiff = function (a, b) { return LP.angNorm(b - a); };
  LP.dist = function (ax, ay, bx, by) { var dx = ax - bx, dy = ay - by; return Math.sqrt(dx * dx + dy * dy); };
  LP.smooth = function (a, b, v) { var t = LP.clamp((v - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };

  /* RNG de jogo (pode ser semeado nos testes) */
  LP.rnd = Math.random;
  LP.seed = function (s) {
    s = s >>> 0;
    LP.rnd = function () {
      s = (s + 0x6D2B79F5) >>> 0;
      var t = Math.imul(s ^ (s >>> 15), 1 | s);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };
  LP.rr = function (a, b) { return a + (b - a) * LP.rnd(); };
  LP.ri = function (a, b) { return (a + LP.rnd() * (b - a + 1)) | 0; };
  LP.pick = function (arr) { return arr[(LP.rnd() * arr.length) | 0]; };

  /* hash/ruído determinístico (texturas e arte) */
  LP.hash = function (x, y, s) {
    var h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(s | 0, 1013904223);
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  };
  /* ruído de valor com repetição de período P (tileável) */
  LP.tn = function (x, y, P, s) {
    var xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
    var u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
    var x0 = ((xi % P) + P) % P, x1 = (x0 + 1) % P, y0 = ((yi % P) + P) % P, y1 = (y0 + 1) % P;
    var a = LP.hash(x0, y0, s), b = LP.hash(x1, y0, s), c = LP.hash(x0, y1, s), d = LP.hash(x1, y1, s);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  };
  LP.tf = function (x, y, P, s, o) {
    var t = 0, a = 0.5, f = 1, m = 0;
    for (var i = 0; i < (o || 4); i++) { t += a * LP.tn(x * f, y * f, P * f, s + i * 31); m += a; a *= 0.5; f *= 2; }
    return t / m;
  };
  LP.rgba = function (r, gg, b, a) {
    r = r < 0 ? 0 : r > 255 ? 255 : r | 0; gg = gg < 0 ? 0 : gg > 255 ? 255 : gg | 0; b = b < 0 ? 0 : b > 255 ? 255 : b | 0;
    return (((a === undefined ? 255 : a) << 24) | (b << 16) | (gg << 8) | r) >>> 0;
  };

  /* armazenamento seguro */
  LP.store = {
    get: function (k, d) { try { var v = g.localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set: function (k, v) { try { g.localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } },
    del: function (k) { try { g.localStorage.removeItem(k); } catch (e) { /* ignora */ } }
  };
})(typeof window !== 'undefined' ? window : globalThis);
