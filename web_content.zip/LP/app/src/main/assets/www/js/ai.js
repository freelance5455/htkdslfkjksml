/* Lost Prehistoria - IA dos dinossauros.
   Percepção: visão (alcance, cone, linha de visão, luz/agachado/correndo) e audição (ruídos com oclusão).
   Estados: patrulha, investigar, alerta, perseguir, atacar, procurar (inclui checar esconderijos), voltar à patrulha.
   Cada espécie tem regras próprias (ver updWalker/updDilo/updSpecial). */
(function (g) {
  'use strict';
  var LP = g.LP, AI = LP.AI = {}, clamp = LP.clamp, dAng = LP.angDiff, rr = function (a, b) { return LP.rr(a, b); };

  var SP = AI.SP = {
    raptor: {
      name: 'Velociraptor', r: 0.3, cls: 0, opens: 1, breaks: 0, sight: 13, fov: 2.2, hear: 1.0, turn: 7.5, react: 0.45, lose: 3.2, searchT: 15, terr: 40, stride: 0.9,
      spd: { patrol: 1.3, invest: 2.3, chase: 3.8, search: 2.0 }, atk: { range: 1.3, wind: 0.42, dmg: 26, cool: 1.1, reach: 1.8 }
    },
    trex: {
      name: 'Tiranossauro Rex', r: 1.05, cls: 2, opens: 0, breaks: 1, sight: 11, fov: 1.7, hear: 1.8, motion: 1, turn: 2.4, react: 1.1, lose: 4, searchT: 12, terr: 50, stride: 2.2,
      spd: { patrol: 1.0, invest: 1.9, chase: 3.3, search: 1.5 }, atk: { range: 2.7, wind: 0.8, dmg: 88, cool: 2.2, reach: 3.3 }
    },
    carno: {
      name: 'Carnotauro', r: 0.55, cls: 1, opens: 0, breaks: 0, sight: 14, fov: 1.9, hear: 1.1, turn: 1.9, react: 0.8, lose: 2.5, searchT: 9, terr: 40, stride: 1.3,
      spd: { patrol: 1.4, invest: 2.4, chase: 3.4, search: 1.9, charge: 4.8 }, atk: { range: 1.7, wind: 0.5, dmg: 50, cool: 1.5, reach: 2.1 }
    },
    dilo: {
      name: 'Dilofossauro', r: 0.3, cls: 0, opens: 0, breaks: 0, sight: 9, fov: 2.6, hear: 1.0, turn: 9, stride: 0.8, ambushR: 6.5,
      spd: { retreat: 3.5, walk: 2.0 }, atk: { range: 1.7, wind: 0.35, dmg: 14, cool: 0.8, reach: 1.9 }
    },
    special: {
      name: 'O Silêncio', r: 0.3, cls: 0, opens: 1, breaks: 0, sight: 0, fov: 6.28, hear: 2.4, turn: 6, stride: 1.1,
      spd: { stalk: 1.15, rush: 5.2, search: 1.7, leave: 2.2 }, atk: { range: 1.15, wind: 0.2, dmg: 999, cool: 1, reach: 1.3 }
    }
  };
  var STRIDE_SND = { raptor: 'step_raptor', trex: 'step_trex', carno: 'step_carno', dilo: 'step_raptor', special: 'step_special' };

  AI.create = function (kind, x, y, opts) {
    opts = opts || {};
    return {
      kind: kind, sp: SP[kind], x: x, y: y, facing: Math.random() * 6.28, state: kind === 'dilo' ? 'ambush' : 'patrol', t: 0, animT: 0, home: { x: x, y: y }, dormant: !!opts.dormant,
      goal: null, path: null, pi: 0, repT: 0, pt: { x: 0, y: 0 }, partial: false, last: null, seen: null, aware: 0, vis: 0, lost: 0, nseen: 0, wait: Math.random() * 2, ph: 0, checks: 0,
      stuckT: 0, lx: x, ly: y, stepD: 0, moving: false, speed: 0, struck: false, camo: kind === 'dilo' ? 1 : 0, cd: 0, spots: opts.spots || null, cs: 0, ping: rr(1, 2.5), life: 0,
      flank: Math.random() < 0.5 ? 1 : -1, dist: 99, hs: null, hsI: 0, uid: opts.uid || 0
    };
  };
  function setState(d, s) { d.state = s; d.t = 0; d.struck = false; d.ph = 0; }
  function hyp(ax, ay, bx, by) { var dx = ax - bx, dy = ay - by; return Math.sqrt(dx * dx + dy * dy); }

  /* ---------- percepção ---------- */
  function perceive(d, ctx, dt) {
    var P = ctx.player, W = ctx.world, sp = d.sp, vis = 0, dist = hyp(P.x, P.y, d.x, d.y);
    d.dist = dist;
    if (!P.hidden && !P.dead && sp.sight > 0) {
      var range = sp.sight * P.visMul(W, sp);
      if (dist <= range) {
        var ang = Math.abs(dAng(d.facing, Math.atan2(P.y - d.y, P.x - d.x)));
        if ((dist < 1.7 || ang <= sp.fov * 0.5) && W.los(d.x, d.y, P.x, P.y)) vis = 1 - dist / range;
      }
    }
    d.vis = vis;
    if (vis > 0) {
      d.aware = Math.min(1.2, d.aware + (0.7 + 2.6 * vis) * dt);
      if (dist < 2) d.aware = 1.2;
      d.seen = { x: P.x, y: P.y }; d.lost = Math.min(d.lost, 0);
    } else d.aware = Math.max(0, d.aware - 0.3 * dt);
    return vis;
  }
  function hearing(d, ctx) {
    var W = ctx.world, best = null, bs = 1e9, i, n;
    for (i = 0; i < W.noises.length; i++) {
      n = W.noises[i]; if (n.id <= d.nseen || n.owner === d) continue;
      var dd = hyp(d.x, d.y, n.x, n.y); if (dd > n.rad * 2) continue;
      var eff = dd * (W.los(d.x, d.y, n.x, n.y) ? 1 : 1.6) / d.sp.hear;
      if (eff <= n.rad && eff / n.rad < bs) { bs = eff / n.rad; best = n; }
    }
    if (W.noises.length) d.nseen = W.noises[W.noises.length - 1].id;
    return best;
  }

  /* ---------- movimento ---------- */
  function front(W, h) {
    var D = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    for (var i = 0; i < 4; i++) { var x = h.x + D[i][0], y = h.y + D[i][1]; if (W.kind[y * W.w + x] === 0) return { x: x + 0.5, y: y + 0.5 }; }
    return { x: h.x + 0.5, y: h.y + 0.5 };
  }
  AI.front = front;
  function walkStep(d, ctx, speed, dt, heading) {
    var W = ctx.world, sp = d.sp, i;
    /* portas e barricadas à frente */
    var ah = W.rayTile(d.x, d.y, d.facing, sp.r + 0.85);
    if (ah) {
      if (ah.k === 2 && sp.opens) { var door = W.doors[ah.i]; if (door && !door.lock && door.st !== 1 && W.dOpen[ah.i] < 0.85) { W.openDoor(door); W.noise(door.x + 0.5, door.y + 0.5, 4, 'door', d); ctx.sfx('door', door.x + 0.5, door.y + 0.5, 0.7); } }
      else if (ah.k === 4 && sp.breaks) {
        var bx = Math.floor(d.x + Math.cos(d.facing) * ah.d), by = Math.floor(d.y + Math.sin(d.facing) * ah.d), n = 0;
        for (var yy = by - 3; yy <= by + 3; yy++) for (var xx = bx - 3; xx <= bx + 3; xx++) if (W.breakBarr(xx, yy)) n++;
        if (n) { ctx.sfx('crash', d.x, d.y, 1); ctx.shake(1.3, d.x, d.y); W.noise(d.x, d.y, 18, 'crash'); }
      }
    }
    var mv = speed * dt, bx2 = Math.cos(d.facing) * mv, by2 = Math.sin(d.facing) * mv;
    var m = W.move(d, bx2, by2, sp.r);
    var moved = hyp(d.x, d.y, d.lx, d.ly); d.speed = moved / Math.max(dt, 1e-3);
    d.stepD += moved;
    if (d.stepD > sp.stride) {
      d.stepD = 0; ctx.sfx(STRIDE_SND[d.kind], d.x, d.y, 1);
      if (d.kind === 'trex') ctx.shake(0.55, d.x, d.y); else if (d.kind === 'carno' && speed > 3) ctx.shake(0.2, d.x, d.y);
    }
    d.moving = moved > 0.002;
    /* travado? */
    if (speed > 0.5 && moved < speed * dt * 0.25) d.stuckT += dt; else d.stuckT = Math.max(0, d.stuckT - dt * 2);
    if (d.stuckT > 0.9) { d.repT = 0; }
    if (d.stuckT > 1.6) { W.unstick(d, sp.r); d.facing += (Math.random() - 0.5) * 2.4; d.stuckT = 0.5; d.path = null; }
    d.lx = d.x; d.ly = d.y;
    return m;
  }
  /* segue um caminho A* até (tx,ty). devolve 'moving' | 'arrived' | 'nopath' | 'partial' */
  function follow(d, tx, ty, speed, dt, ctx) {
    var W = ctx.world, sp = d.sp;
    d.repT -= dt;
    if (!d.path || d.repT <= 0 || hyp(d.pt.x, d.pt.y, tx, ty) > 1.3) {
      d.path = W.findPath(d.x, d.y, tx, ty, sp); d.partial = W.pathPartial; d.pi = 0; d.pt.x = tx; d.pt.y = ty; d.repT = 0.4 + Math.random() * 0.25;
    }
    var wp = d.path && d.path[d.pi];
    if (!wp) { d.moving = false; return hyp(d.x, d.y, tx, ty) < 0.8 ? 'arrived' : (d.path ? (d.partial ? 'partial' : 'arrived') : 'nopath'); }
    var dx = wp.x - d.x, dy = wp.y - d.y, dist = Math.sqrt(dx * dx + dy * dy), last = d.pi >= d.path.length - 1;
    if (dist < (last ? 0.3 : 0.5)) { d.pi++; wp = d.path[d.pi]; if (!wp) { d.moving = false; return d.partial ? 'partial' : 'arrived'; } dx = wp.x - d.x; dy = wp.y - d.y; }
    var want = Math.atan2(dy, dx), da = dAng(d.facing, want), mt = sp.turn * dt;
    d.facing += clamp(da, -mt, mt);
    var f = Math.max(0.15, 1 - Math.abs(da) / 2.4);
    walkStep(d, ctx, speed * (sp.turn > 4 ? Math.max(f, 0.6) : f), dt);
    return 'moving';
  }
  function faceTo(d, x, y, dt, rate) { var da = dAng(d.facing, Math.atan2(y - d.y, x - d.x)), mt = (rate || d.sp.turn) * dt; d.facing += clamp(da, -mt, mt); }
  function pickGoal(d, ctx, cx, cy, minD, maxD) {
    var W = ctx.world, sp = d.sp;
    for (var a = 0; a < 8; a++) {
      var ang = Math.random() * 6.28, rad = minD + Math.random() * (maxD - minD), x = Math.floor(cx + Math.cos(ang) * rad), y = Math.floor(cy + Math.sin(ang) * rad);
      if (x < 1 || y < 1 || x >= W.w - 1 || y >= W.h - 1) continue;
      var i = y * W.w + x; if (W.kind[i] !== 0 || W.cls[i] < sp.cls || W.cls[i] === 255) continue;
      var p = W.findPath(d.x, d.y, x + 0.5, y + 0.5, sp);
      if (p && !W.pathPartial) return { x: x + 0.5, y: y + 0.5 };
    }
    return null;
  }
  AI.pickGoal = pickGoal;
  function spot(d, ctx) {
    var P = ctx.player; d.last = { x: P.x, y: P.y }; setState(d, 'alert');
    d.facing = Math.atan2(P.y - d.y, P.x - d.x); d.lost = 0; d.aware = 1.2;
    ctx.sfx('roar_' + d.kind, d.x, d.y, 1);
    if (d.kind === 'trex') ctx.shake(1.0, d.x, d.y);
    if (d.kind === 'raptor') for (var i = 0; i < ctx.dinos.length; i++) {
      var o = ctx.dinos[i]; if (o === d || o.kind !== 'raptor' || o.dormant || hyp(o.x, o.y, d.x, d.y) > 22) continue;
      if (o.state === 'patrol' || o.state === 'search') { o.goal = { x: P.x, y: P.y }; setState(o, 'investigate'); o.flank = -d.flank; }
    }
  }

  /* ---------- terópodes terrestres: raptor, trex, carno ---------- */
  function updWalker(d, ctx, dt) {
    var sp = d.sp, P = ctx.player, W = ctx.world, vis = perceive(d, ctx, dt), heard = hearing(d, ctx), dist = d.dist, r, i;
    d.t += dt; d.animT += dt; d.moving = false; d.speed = 0;
    if (P.dead) { if (d.state !== 'patrol') setState(d, 'patrol'); }
    switch (d.state) {
      case 'patrol':
        if (d.wait > 0) { d.wait -= dt; d.facing += Math.sin(d.t * 0.9 + d.uid) * 0.55 * dt; }
        else {
          if (!d.goal) d.goal = pickGoal(d, ctx, d.home.x, d.home.y, 6, sp.terr);
          if (!d.goal) { d.wait = 2; break; }
          r = follow(d, d.goal.x, d.goal.y, sp.spd.patrol, dt, ctx);
          if (r !== 'moving') { d.goal = null; d.wait = rr(1.2, 3.6); }
        }
        if (d.kind === 'trex') { d.roarT = (d.roarT === undefined ? rr(8, 16) : d.roarT) - dt; if (d.roarT <= 0) { d.roarT = rr(16, 30); ctx.sfx('roar_trex', d.x, d.y, 0.9); } }
        if (heard && (heard.src !== 'step' || dist < 40)) { d.goal = { x: heard.x, y: heard.y }; setState(d, 'investigate'); d.wait = 0; }
        if (d.aware >= 1) spot(d, ctx);
        break;
      case 'investigate':
        if (!d.goal) { setState(d, 'search'); break; }
        r = follow(d, d.goal.x, d.goal.y, sp.spd.invest, dt, ctx);
        if (heard && hyp(heard.x, heard.y, d.goal.x, d.goal.y) > 2) d.goal = { x: heard.x, y: heard.y };
        if (r !== 'moving' || d.t > 14) { d.last = d.goal; d.goal = null; setState(d, 'search'); d.ph = 1; }
        if (d.aware >= 1) spot(d, ctx);
        break;
      case 'alert':
        faceTo(d, P.x, P.y, dt, 9);
        if (d.t >= sp.react) {
          var clear = W.los(d.x, d.y, P.x, P.y);
          setState(d, d.kind === 'carno' && clear && dist > 4.5 ? 'charge' : 'chase'); d.lost = 0; d.cs = 1.0;
        }
        break;
      case 'chase': {
        if (vis > 0) { d.last = { x: P.x, y: P.y }; d.lost = 0; } else d.lost += dt;
        var tx = d.last.x, ty = d.last.y;
        if (d.kind === 'raptor' && vis > 0 && dist > 3.2) {
          var px = P.x + P.vx * 0.9, py = P.y + P.vy * 0.9, nx = -(P.y - d.y) / dist, ny = (P.x - d.x) / dist;
          px += nx * 1.6 * d.flank; py += ny * 1.6 * d.flank;
          if (W.los(P.x, P.y, px, py) && !W.collides(px, py, 0.25)) { tx = px; ty = py; }
        }
        if (!P.hidden && dist <= sp.atk.range && (vis > 0 || dist < 1.6) && W.los(d.x, d.y, P.x, P.y)) { setState(d, 'attack'); break; }
        r = follow(d, tx, ty, sp.spd.chase, dt, ctx);
        if (d.partial && (r === 'partial' || r === 'nopath') && vis > 0 && dist <= sp.atk.reach && !P.hidden) { setState(d, 'attack'); break; }
        if (d.lost > sp.lose || (r !== 'moving' && vis === 0)) { d.goal = null; setState(d, 'search'); }
        break;
      }
      case 'charge': {
        var cx = vis > 0 ? P.x : d.last.x, cy = vis > 0 ? P.y : d.last.y;
        if (vis > 0) d.last = { x: P.x, y: P.y };
        faceTo(d, cx, cy, dt, 1.25);
        d.cs = Math.min(sp.spd.charge, d.cs + 4.5 * dt);
        var m = walkStep(d, ctx, d.cs, dt);
        if (m && d.cs > 3.0 && d.t > 0.35) { ctx.sfx('crash', d.x, d.y, 1); ctx.shake(1.2, d.x, d.y); W.noise(d.x, d.y, 16, 'crash', d); d.cs = 0; setState(d, 'stun'); break; }
        if (!P.hidden && dist <= sp.atk.range && W.los(d.x, d.y, P.x, P.y)) { setState(d, 'attack'); break; }
        if (hyp(d.x, d.y, cx, cy) < 1.3 || d.t > 6) { setState(d, 'overshoot'); }
        break;
      }
      case 'overshoot':
        d.cs = Math.max(0, d.cs - 3.2 * dt); walkStep(d, ctx, d.cs, dt);
        if (d.t > 1.1) { d.goal = null; setState(d, 'search'); d.ph = 1; d.last = d.last || { x: d.x, y: d.y }; }
        break;
      case 'stun':
        if (d.t > 3.2) { d.last = { x: P.x, y: P.y }; setState(d, 'search'); d.ph = 1; }
        if (d.aware >= 1 && d.t > 2.4) { d.cs = 1; setState(d, 'chase'); }
        break;
      case 'attack': {
        var A = sp.atk;
        faceTo(d, P.x, P.y, dt, d.t < A.wind ? 10 : 0.5);
        if (d.t >= A.wind && !d.struck) {
          d.struck = true;
          if (!P.hidden && !P.dead && dist <= A.reach && (W.los(d.x, d.y, P.x, P.y) || dist < 1.2)) ctx.hurt(A.dmg, d.kind, d);
          if (d.kind === 'raptor') W.move(d, Math.cos(d.facing) * 0.5, Math.sin(d.facing) * 0.5, sp.r);
          ctx.sfx('bite_' + d.kind, d.x, d.y, 1);
        }
        if (d.t >= A.wind + A.cool) { var cl = W.los(d.x, d.y, P.x, P.y) && dist < 5 && !P.hidden && !P.dead; setState(d, cl ? 'chase' : 'search'); d.lost = 0; if (!cl) d.last = { x: P.x, y: P.y }; }
        break;
      }
      case 'search': {
        if (!d.last) d.last = { x: d.x, y: d.y };
        if (d.aware >= 1 && vis > 0) { d.cs = 1; d.lost = 0; setState(d, d.kind === 'carno' && dist > 5 ? 'charge' : 'chase'); break; }
        if (heard) { d.last = { x: heard.x, y: heard.y }; d.ph = 0; d.goal = null; }
        if (d.ph === 0) {
          r = follow(d, d.last.x, d.last.y, sp.spd.search, dt, ctx);
          if (r !== 'moving') { d.ph = 1; d.pt0 = d.t; }
        } else if (d.ph === 1) {
          d.facing += (d.kind === 'trex' ? 0.9 : 1.8) * dt * (Math.sin(d.t * 0.8) > 0 ? 1 : -1);
          if (d.t - (d.pt0 || 0) > 2.4) {
            d.ph = (sp.opens && ctx.hides.length) ? 2 : 3; d.hsI = 0;
            if (d.ph === 2) {
              var list = []; for (i = 0; i < ctx.hides.length; i++) { var h = ctx.hides[i]; var dd = hyp(h.x + 0.5, h.y + 0.5, d.last.x, d.last.y); if (dd < 9 && !h.checked) list.push({ h: h, k: dd - (h.burned ? 6 : 0) }); }
              list.sort(function (a, b) { return a.k - b.k; }); d.hs = list.slice(0, 2).map(function (e) { return e.h; });
              if (!d.hs.length) d.ph = 3;
            }
          }
        } else if (d.ph === 2) {
          var hs = d.hs[d.hsI];
          if (!hs) { d.ph = 3; break; }
          var fp = front(W, hs); r = follow(d, fp.x, fp.y, sp.spd.search, dt, ctx);
          if (r !== 'moving' || hyp(d.x, d.y, fp.x, fp.y) < 0.7) {
            faceTo(d, hs.x + 0.5, hs.y + 0.5, dt, 10); d.peek = (d.peek || 0) + dt;
            if (d.peek > 1.1) {
              d.peek = 0; hs.checked = ctx.time; d.hsI++;
              if (P.hidden && P.hidden === hs && Math.random() < (hs.burned ? 0.92 : 0.5)) { ctx.pullOut(hs, d); setState(d, 'attack'); d.t = sp.atk.wind; break; }
            }
          }
        } else {
          if (!d.goal) d.goal = pickGoal(d, ctx, d.last.x, d.last.y, 3, 10);
          if (!d.goal) { d.wait = 1; d.goal = null; }
          else { r = follow(d, d.goal.x, d.goal.y, sp.spd.search, dt, ctx); if (r !== 'moving') d.goal = null; }
        }
        /* T-Rex e Carnotauro não abrem armários, mas farejam jogador escondido muito perto */
        if (!sp.opens && P.hidden && dist < 2.6) { d.smell = (d.smell || 0) + dt; if (d.smell > 4) { d.smell = 0; ctx.pullOut(P.hidden, d); setState(d, 'attack'); d.t = sp.atk.wind; } } else d.smell = 0;
        if (d.t > sp.searchT) { d.goal = null; d.hs = null; for (i = 0; i < ctx.hides.length; i++) ctx.hides[i].checked = 0; setState(d, 'patrol'); d.wait = 0; d.aware = 0; }
        break;
      }
    }
  }

  /* ---------- Dilofossauro: emboscada, cuspe, recuo ---------- */
  function updDilo(d, ctx, dt) {
    var sp = d.sp, P = ctx.player, W = ctx.world, vis = perceive(d, ctx, dt), dist = d.dist, r;
    d.t += dt; d.animT += dt; d.moving = false; d.speed = 0; d.cd -= dt;
    var target = (d.state === 'ambush') ? 1 : 0; d.camo += clamp(target - d.camo, -dt * 2.2, dt * 0.8);
    switch (d.state) {
      case 'ambush':
        if (vis > 0 && dist < 8) faceTo(d, P.x, P.y, dt, 2);
        if (d.cd <= 0 && !P.dead && ((vis > 0 && d.aware >= 0.85 && dist < sp.ambushR) || (dist < 2.2 && !P.hidden && W.los(d.x, d.y, P.x, P.y)))) { setState(d, 'telegraph'); ctx.sfx('hiss_dilo', d.x, d.y, 1); }
        break;
      case 'telegraph':
        faceTo(d, P.x, P.y, dt, 12);
        if (d.t > 0.85) setState(d, dist < 1.9 ? 'bite' : 'spit');
        break;
      case 'spit':
        faceTo(d, P.x, P.y, dt, 12);
        if (d.t > 0.22 && !d.struck) { d.struck = true; ctx.sfx('spit_dilo', d.x, d.y, 1); ctx.spawnProj(d.x, d.y, P.x, P.y); }
        if (d.t > 0.6) { d.goal = null; setState(d, 'retreat'); }
        break;
      case 'bite':
        faceTo(d, P.x, P.y, dt, 12);
        if (d.t > sp.atk.wind && !d.struck) { d.struck = true; if (dist < sp.atk.reach && !P.hidden) ctx.hurt(sp.atk.dmg, 'dilo', d); ctx.sfx('bite_dilo', d.x, d.y, 1); }
        if (d.t > 0.8) { d.goal = null; setState(d, 'retreat'); }
        break;
      case 'retreat': {
        if (!d.goal) {
          var best = null, bd = -1;
          if (d.spots) for (var i = 0; i < d.spots.length; i++) {
            var s = d.spots[i], sd = hyp(s.x, s.y, P.x, P.y); if (sd < 12 || sd > 40 || hyp(s.x, s.y, d.x, d.y) < 4) continue;
            var sc = sd + Math.random() * 10; if (sc > bd) { bd = sc; best = s; }
          }
          d.goal = best || { x: d.home.x, y: d.home.y };
        }
        r = follow(d, d.goal.x, d.goal.y, sp.spd.retreat, dt, ctx);
        if (r !== 'moving' || d.t > 14) { d.goal = null; d.home = { x: d.x, y: d.y }; setState(d, 'ambush'); d.cd = 7; d.aware = 0; }
        break;
      }
    }
  }

  /* ---------- O Silêncio: caça por som, cliques de ecolocalização ---------- */
  function updSpecial(d, ctx, dt) {
    var sp = d.sp, P = ctx.player, W = ctx.world, dist = hyp(P.x, P.y, d.x, d.y), r, heard = hearing(d, ctx);
    d.dist = dist; d.t += dt; d.animT += dt; d.moving = false; d.speed = 0; d.life -= dt; d.ping -= dt;
    if (d.state !== 'grab' && d.state !== 'dead' && d.ping <= 0) {
      d.ping = d.state === 'rush' ? 0.8 : (d.state === 'search' ? 1.3 : rr(2.1, 3.2));
      ctx.sfx('click', d.x, d.y, 1);
      var moving = P.speed > 0.9, range = 6 + P.speed * 2.4;
      if (!P.hidden && !P.dead && ((moving && dist < range && (W.los(d.x, d.y, P.x, P.y) || dist < 5)) || dist < 2.2)) {
        d.last = { x: P.x, y: P.y };
        if (d.state === 'stalk' || d.state === 'search' || d.state === 'investigate' || d.state === 'leave') { setState(d, 'lock'); ctx.sfx('roar_special', d.x, d.y, 1); }
      }
    }
    if (heard && heard.rad >= 6 && (d.state === 'stalk' || d.state === 'search' || d.state === 'leave') && heard.src !== 'step') { d.goal = { x: heard.x, y: heard.y }; setState(d, 'investigate'); }
    switch (d.state) {
      case 'stalk':
        if (d.life <= 0) { setState(d, 'leave'); break; }
        if (!d.goal) d.goal = pickGoal(d, ctx, P.x, P.y, 7, 22);
        if (!d.goal) { d.wait = 1; break; }
        r = follow(d, d.goal.x, d.goal.y, sp.spd.stalk, dt, ctx); if (r !== 'moving') d.goal = null;
        break;
      case 'lock':
        faceTo(d, d.last.x, d.last.y, dt, 12);
        if (d.t > 0.7) { setState(d, 'rush'); d.goal = null; }
        break;
      case 'rush':
        if (P.speed > 0.9 && !P.hidden) d.last = { x: P.x, y: P.y };
        r = follow(d, d.last.x, d.last.y, sp.spd.rush, dt, ctx);
        if (!P.hidden && !P.dead && dist < sp.atk.range) { setState(d, 'grab'); ctx.sfx('roar_special', d.x, d.y, 1); break; }
        if (r !== 'moving' || d.t > 10) { d.goal = null; setState(d, 'search'); }
        break;
      case 'investigate':
        if (!d.goal) { setState(d, 'search'); break; }
        r = follow(d, d.goal.x, d.goal.y, sp.spd.search + 1.2, dt, ctx);
        if (r !== 'moving' || d.t > 12) { d.last = d.goal; d.goal = null; setState(d, 'search'); }
        break;
      case 'search':
        if (!d.goal) d.goal = pickGoal(d, ctx, d.x, d.y, 3, 9);
        if (d.goal) { r = follow(d, d.goal.x, d.goal.y, sp.spd.search, dt, ctx); if (r !== 'moving') d.goal = null; }
        if (P.hidden && dist < 3 && (d.smell = (d.smell || 0) + dt) > 3) { d.smell = 0; ctx.pullOut(P.hidden, d); setState(d, 'grab'); }
        if (d.t > 9) { d.goal = null; setState(d, 'stalk'); }
        break;
      case 'grab':
        faceTo(d, P.x, P.y, dt, 12);
        if (d.t > sp.atk.wind && !d.struck) { d.struck = true; ctx.hurt(999, 'special', d); }
        if (d.t > 3) setState(d, 'search');
        break;
      case 'leave':
        if (!d.goal) { var best = null, bd = -1; for (var k = 0; k < 6; k++) { var g2 = pickGoal(d, ctx, d.x, d.y, 15, 40); if (g2) { var gd = hyp(g2.x, g2.y, P.x, P.y); if (gd > bd) { bd = gd; best = g2; } } } d.goal = best || { x: d.home.x, y: d.home.y }; }
        r = follow(d, d.goal.x, d.goal.y, sp.spd.leave, dt, ctx);
        if ((dist > 14 && !W.los(d.x, d.y, P.x, P.y)) || r !== 'moving') { d.dormant = true; d.state = 'stalk'; d.goal = null; ctx.sfx('click', d.x, d.y, 0.5); }
        break;
    }
  }

  AI.update = function (d, ctx, dt) {
    if (d.dormant) return;
    if (d.kind === 'dilo') updDilo(d, ctx, dt); else if (d.kind === 'special') updSpecial(d, ctx, dt); else updWalker(d, ctx, dt);
  };
  /* libera um dinossauro dormente (evento de roteiro). breakout = persegue já com a posição do jogador */
  AI.release = function (d, ctx, life) {
    d.dormant = false; d.life = life || 100; d.goal = null; d.path = null; d.ping = 1.5;
    if (d.kind === 'trex' || d.kind === 'carno' || d.kind === 'raptor') { d.last = { x: ctx.player.x, y: ctx.player.y }; setState(d, 'chase'); d.lost = -9; d.cs = 1; }
    else if (d.kind === 'special') setState(d, 'stalk');
  };
  /* animação e quadro atual */
  AI.anim = function (d) {
    var s = d.state, t = d.animT, A = d.sp.atk, f;
    if (s === 'attack' || s === 'bite') { f = d.t < A.wind ? 0 : d.t < A.wind + 0.25 ? 1 : 2; return { a: 'attack', f: f }; }
    if (s === 'spit') return { a: 'attack', f: d.t < 0.22 ? 0 : d.t < 0.5 ? 1 : 2 };
    if (s === 'alert' || s === 'telegraph' || s === 'lock' || s === 'grab') return { a: 'alert', f: Math.floor(t * 4) & 1 };
    if (s === 'chase' || s === 'charge' || s === 'rush' || s === 'retreat') return { a: 'run', f: Math.floor(t * (7 + d.speed * 1.6)) % 6 };
    if (s === 'overshoot') return { a: 'run', f: Math.floor(t * 8) % 6 };
    if (d.moving) return { a: 'walk', f: Math.floor(t * (3 + d.speed * 2.4)) % 6 };
    return { a: 'idle', f: Math.floor(t * 1.6) & 1 };
  };
})(typeof window !== 'undefined' ? window : globalThis);
