/* Lost Prehistoria - áudio 100% procedural (sem arquivos de áudio, sem licenças). Espacializado por pan/distância/oclusão. */
(function (g) {
  'use strict';
  var LP = g.LP, A = LP.A = { ctx: null, ok: false, vol: { master: 0.85, fx: 1, amb: 0.8 }, listener: { x: 0, y: 0, a: 0 }, occ: null, silence: 0, area: null, enabled: true };
  var C, master, busFx, busAmb, V = {}, amb = null, hbT = 0, evT = 0;

  function noiseBuf(c) {
    if (c._nb) return c._nb;
    var len = c.sampleRate * 2, b = c.createBuffer(1, len, c.sampleRate), d = b.getChannelData(0);
    for (var i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    return (c._nb = b);
  }
  function env(p, t, a, h, d, pk) { pk = Math.max(pk, 0.0002); p.cancelScheduledValues(t); p.setValueAtTime(0.0001, t); p.exponentialRampToValueAtTime(pk, t + a); p.setValueAtTime(pk, t + a + h); p.exponentialRampToValueAtTime(0.0001, t + a + h + d); }
  function osc(c, type, f, t, dur) { var o = c.createOscillator(); o.type = type; o.frequency.setValueAtTime(f, t); o.start(t); o.stop(t + dur + 0.05); return o; }
  function filt(c, type, f, q) { var n = c.createBiquadFilter(); n.type = type; n.frequency.value = f; n.Q.value = q || 0.7; return n; }
  function gain(c, v) { var n = c.createGain(); n.gain.value = v === undefined ? 1 : v; return n; }
  function burst(c, dest, t, dur, vol, type, f0, f1, q) {
    var s = c.createBufferSource(); s.buffer = noiseBuf(c); var fl = filt(c, type, f0, q); if (f1) fl.frequency.exponentialRampToValueAtTime(f1, t + dur);
    var gn = gain(c, 0); env(gn.gain, t, 0.006, dur * 0.25, dur * 0.75, vol); s.connect(fl); fl.connect(gn); gn.connect(dest); s.start(t, Math.random()); s.stop(t + dur + 0.05);
  }
  function thump(c, dest, t, f0, f1, dur, vol) {
    var o = osc(c, 'sine', f0, t, dur); o.frequency.exponentialRampToValueAtTime(f1, t + dur); var gn = gain(c, 0); env(gn.gain, t, 0.004, 0.01, dur, vol); o.connect(gn); gn.connect(dest);
  }
  function tone(c, dest, t, type, f0, f1, dur, vol, lpf) {
    var o = osc(c, type, f0, t, dur); if (f1) o.frequency.exponentialRampToValueAtTime(f1, t + dur); var gn = gain(c, 0); env(gn.gain, t, 0.01, dur * 0.4, dur * 0.6, vol);
    if (lpf) { var f = filt(c, 'lowpass', lpf, 0.8); o.connect(f); f.connect(gn); } else o.connect(gn); gn.connect(dest);
  }

  /* ---------- vozes: (contexto, destino, tempo, {vol}) ---------- */
  V.step_tile = function (c, d, t, p) { burst(c, d, t, 0.08, 0.5 * p.vol, 'bandpass', 1500, 900, 0.9); };
  V.step_dirt = function (c, d, t, p) { burst(c, d, t, 0.1, 0.5 * p.vol, 'lowpass', 520, 300, 0.7); };
  V.step_metal = function (c, d, t, p) { burst(c, d, t, 0.07, 0.4 * p.vol, 'bandpass', 2400, 1800, 1); thump(c, d, t, 440, 300, 0.12, 0.08 * p.vol); };
  V.step_raptor = function (c, d, t, p) { burst(c, d, t, 0.035, 0.45 * p.vol, 'highpass', 2600, 0, 0.7); burst(c, d, t + 0.05, 0.035, 0.3 * p.vol, 'highpass', 2200, 0, 0.7); };
  V.step_carno = function (c, d, t, p) { thump(c, d, t, 90, 45, 0.22, 0.7 * p.vol); burst(c, d, t, 0.12, 0.3 * p.vol, 'lowpass', 500, 200, 0.8); };
  V.step_trex = function (c, d, t, p) { thump(c, d, t, 58, 28, 0.5, 1.0 * p.vol); thump(c, d, t, 110, 40, 0.3, 0.4 * p.vol); burst(c, d, t, 0.3, 0.45 * p.vol, 'lowpass', 300, 90, 0.7); };
  V.step_special = function (c, d, t, p) { burst(c, d, t, 0.06, 0.18 * p.vol, 'bandpass', 3000, 2000, 2); };
  V.door = function (c, d, t, p) { burst(c, d, t, 0.45, 0.4 * p.vol, 'bandpass', 700, 260, 1); thump(c, d, t + 0.35, 120, 60, 0.18, 0.5 * p.vol); };
  V.pick = function (c, d, t, p) { tone(c, d, t, 'triangle', 880, 0, 0.09, 0.25 * p.vol); tone(c, d, t + 0.08, 'triangle', 1320, 0, 0.14, 0.25 * p.vol); };
  V.flash = function (c, d, t, p) { tone(c, d, t, 'square', 1800, 0, 0.03, 0.16 * p.vol); };
  V.hurt = function (c, d, t, p) { burst(c, d, t, 0.3, 0.7 * p.vol, 'lowpass', 600, 180, 0.8); thump(c, d, t, 95, 45, 0.3, 0.9 * p.vol); };
  V.heart = function (c, d, t, p) { thump(c, d, t, 64, 38, 0.13, 0.9 * p.vol); thump(c, d, t + 0.19, 56, 34, 0.12, 0.7 * p.vol); };
  V.glass = function (c, d, t, p) { burst(c, d, t, 0.15, 0.5 * p.vol, 'highpass', 3000, 0, 0.7); tone(c, d, t, 'sine', 3300, 0, 0.12, 0.2 * p.vol); tone(c, d, t + 0.03, 'sine', 4300, 0, 0.1, 0.15 * p.vol); tone(c, d, t + 0.07, 'sine', 2700, 0, 0.1, 0.12 * p.vol); };
  V.click = function (c, d, t, p) { var o = osc(c, 'sine', 3300, t, 0.03), f = filt(c, 'bandpass', 3300, 9), gn = gain(c, 0); env(gn.gain, t, 0.001, 0.004, 0.02, 0.8 * p.vol); o.connect(f); f.connect(gn); gn.connect(d); };
  V.bite_raptor = function (c, d, t, p) { burst(c, d, t, 0.14, 0.7 * p.vol, 'highpass', 1400, 0, 0.8); thump(c, d, t, 140, 70, 0.14, 0.6 * p.vol); };
  V.bite_trex = function (c, d, t, p) { burst(c, d, t, 0.4, 0.9 * p.vol, 'lowpass', 900, 200, 0.8); thump(c, d, t, 70, 30, 0.5, 1.1 * p.vol); };
  V.bite_carno = function (c, d, t, p) { burst(c, d, t, 0.25, 0.8 * p.vol, 'lowpass', 1100, 300, 0.8); thump(c, d, t, 90, 40, 0.3, 0.9 * p.vol); };
  V.bite_dilo = V.bite_raptor;
  V.crash = function (c, d, t, p) { burst(c, d, t, 0.9, 0.9 * p.vol, 'lowpass', 1400, 200, 0.8); thump(c, d, t, 70, 26, 1.0, 1.2 * p.vol); };
  V.alarm = function (c, d, t, p) { for (var i = 0; i < 6; i++) tone(c, d, t + i * 0.4, 'square', i % 2 ? 640 : 480, 0, 0.36, 0.14 * p.vol, 1400); };
  V.thunder = function (c, d, t, p) { burst(c, d, t, 2.4, 0.9 * p.vol, 'lowpass', 500, 60, 0.6); thump(c, d, t, 50, 25, 1.8, 0.7 * p.vol); };
  V.hiss_dilo = function (c, d, t, p) {
    var s = c.createBufferSource(); s.buffer = noiseBuf(c); var f = filt(c, 'bandpass', 3600, 1.4), gn = gain(c, 0), lf = osc(c, 'sine', 26, t, 1), lg = gain(c, 0.35);
    env(gn.gain, t, 0.05, 0.5, 0.35, 0.55 * p.vol); lf.connect(lg); lg.connect(gn.gain); s.connect(f); f.connect(gn); gn.connect(d); s.start(t, Math.random()); s.stop(t + 1);
  };
  V.spit_dilo = function (c, d, t, p) { burst(c, d, t, 0.2, 0.7 * p.vol, 'bandpass', 1900, 600, 1.2); thump(c, d, t, 260, 120, 0.1, 0.4 * p.vol); };
  V.roar_raptor = function (c, d, t, p) {
    for (var k = 0; k < 3; k++) {
      var tt = t + k * 0.23, o = osc(c, 'sawtooth', 1300, tt, 0.2), f = filt(c, 'bandpass', 2100, 3), gn = gain(c, 0);
      o.frequency.exponentialRampToValueAtTime(2900, tt + 0.07); o.frequency.exponentialRampToValueAtTime(1700, tt + 0.2); env(gn.gain, tt, 0.01, 0.07, 0.12, 0.45 * p.vol); o.connect(f); f.connect(gn); gn.connect(d);
    }
  };
  V.roar_trex = function (c, d, t, p) {
    var dur = 2.6, o1 = osc(c, 'sawtooth', 70, t, dur), o2 = osc(c, 'sawtooth', 73, t, dur), lfo = osc(c, 'sine', 9, t, dur), lg = gain(c, 7), lp = filt(c, 'lowpass', 900, 1.2), gn = gain(c, 0);
    o1.frequency.exponentialRampToValueAtTime(135, t + 0.5); o1.frequency.exponentialRampToValueAtTime(46, t + dur); o2.frequency.exponentialRampToValueAtTime(140, t + 0.5); o2.frequency.exponentialRampToValueAtTime(48, t + dur);
    lfo.connect(lg); lg.connect(o1.frequency); lg.connect(o2.frequency); lp.frequency.exponentialRampToValueAtTime(260, t + dur); env(gn.gain, t, 0.12, 1.2, 1.3, 0.6 * p.vol);
    o1.connect(lp); o2.connect(lp); lp.connect(gn); gn.connect(d); burst(c, d, t, dur, 0.3 * p.vol, 'lowpass', 700, 200, 0.7); thump(c, d, t, 48, 30, 1.6, 0.6 * p.vol);
  };
  V.roar_carno = function (c, d, t, p) {
    var dur = 1.5, o = osc(c, 'sawtooth', 95, t, dur), lf = osc(c, 'sine', 14, t, dur), lg = gain(c, 0.4), gn = gain(c, 0), lp = filt(c, 'lowpass', 750, 1);
    o.frequency.exponentialRampToValueAtTime(155, t + 0.4); o.frequency.exponentialRampToValueAtTime(80, t + dur); env(gn.gain, t, 0.08, 0.7, 0.7, 0.55 * p.vol); lf.connect(lg); lg.connect(gn.gain); o.connect(lp); lp.connect(gn); gn.connect(d);
    burst(c, d, t, 1.2, 0.2 * p.vol, 'lowpass', 500, 180, 0.7);
  };
  V.roar_dilo = V.hiss_dilo;
  V.roar_special = function (c, d, t, p) {
    var dur = 1.1, o = osc(c, 'sawtooth', 62, t, dur), o2 = osc(c, 'triangle', 124, t, dur), gn = gain(c, 0), lp = filt(c, 'lowpass', 500, 1.5);
    env(gn.gain, t, 0.15, 0.5, 0.45, 0.5 * p.vol); o.connect(lp); o2.connect(lp); lp.connect(gn); gn.connect(d); for (var k = 0; k < 4; k++) V.click(c, d, t + k * 0.09, p);
  };
  V.ui = function (c, d, t, p) { tone(c, d, t, 'sine', 520, 0, 0.06, 0.18 * p.vol); };
  var FAR = { roar_trex: 0.05, roar_raptor: 0.1, roar_carno: 0.08, roar_special: 0.09, crash: 0.07, thunder: 0.02, alarm: 0.03, hiss_dilo: 0.2, click: 0.11, step_trex: 0.09, glass: 0.16 };
  A.voices = V;

  /* ---------- núcleo ---------- */
  A.init = function () {
    if (A.ctx) { A.resume(); return; }
    var AC = g.AudioContext || g.webkitAudioContext; if (!AC) return;
    try { C = A.ctx = new AC(); } catch (e) { return; }
    master = C.createGain(); master.gain.value = A.vol.master; var comp = C.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 6; master.connect(comp); comp.connect(C.destination);
    busFx = C.createGain(); busFx.gain.value = A.vol.fx; busFx.connect(master);
    busAmb = C.createGain(); busAmb.gain.value = A.vol.amb; busAmb.connect(master); A.ok = true;
  };
  A.resume = function () { if (C && C.state === 'suspended') C.resume(); };
  A.suspend = function () { if (C && C.state === 'running') C.suspend(); };
  A.setVolume = function (v) { A.vol.master = v; if (master) master.gain.setTargetAtTime(v, C.currentTime, 0.05); };
  A.setListener = function (x, y, a) { A.listener.x = x; A.listener.y = y; A.listener.a = a; };
  /* toca um som no mundo */
  A.play = function (name, x, y, vol) {
    if (!A.ok || !A.enabled || !V[name]) return;
    var L = A.listener, dx = x - L.x, dy = y - L.y, dist = Math.sqrt(dx * dx + dy * dy), t = C.currentTime + 0.005;
    var far = FAR[name] || 0.2, att = 1 / (1 + far * Math.pow(dist, 1.35)), occ = A.occ ? A.occ(x, y) : 1;
    var v = (vol === undefined ? 1 : vol) * att * (0.35 + 0.65 * occ);
    if (v < 0.01) return;
    var node = gain(C, 1), lp = filt(C, 'lowpass', Math.max(500, 15000 / (1 + dist * 0.22) * (0.3 + 0.7 * occ)), 0.5);
    var out = lp; node.connect(lp);
    if (C.createStereoPanner) { var pn = C.createStereoPanner(); pn.pan.value = dist < 0.4 ? 0 : Math.sin(Math.atan2(dy, dx) - L.a); lp.connect(pn); out = pn; }
    out.connect(busFx);
    V[name](C, node, t, { vol: v });
  };
  A.ui = function (name, vol) { if (!A.ok || !V[name]) return; var n = gain(C, 1); n.connect(busFx); V[name](C, n, C.currentTime + 0.005, { vol: vol === undefined ? 1 : vol }); };

  /* ---------- ambientes ---------- */
  function loopNoise(f0, type, q, vol, lfoF, lfoD) {
    var s = C.createBufferSource(); s.buffer = noiseBuf(C); s.loop = true; var f = filt(C, type, f0, q), gn = gain(C, vol);
    if (lfoF) { var l = osc(C, 'sine', lfoF, C.currentTime, 36000), lg = gain(C, lfoD); l.connect(lg); lg.connect(f.frequency); amb.push(l); }
    s.connect(f); f.connect(gn); gn.connect(amb.bus); s.start(0, Math.random()); amb.push(s); return gn;
  }
  function loopOsc(type, f, vol, lp) { var o = osc(C, type, f, C.currentTime, 36000), gn = gain(C, vol), fl = filt(C, 'lowpass', lp || 400, 0.7); o.connect(fl); fl.connect(gn); gn.connect(amb.bus); amb.push(o); return o; }
  A.setArea = function (kind) {
    if (!A.ok) { A.area = kind; return; }
    if (amb) { amb.bus.gain.setTargetAtTime(0, C.currentTime, 0.3); var old = amb; setTimeout(function () { old.forEach(function (n) { try { n.stop(); } catch (e) { /* ok */ } }); }, 1500); }
    amb = []; amb.bus = gain(C, 0); amb.bus.connect(busAmb); amb.bus.gain.setTargetAtTime(1 - A.silence, C.currentTime, 1.2); A.area = kind;
    if (kind === 'lab') { loopOsc('sine', 100, 0.016, 400); loopOsc('sine', 50, 0.03, 200); loopNoise(160, 'lowpass', 0.5, 0.06); }
    else if (kind === 'pens') { loopNoise(420, 'bandpass', 0.8, 0.07, 0.06, 160); loopOsc('sine', 60, 0.025, 200); }
    else if (kind === 'forest') {
      loopNoise(5200, 'highpass', 0.5, 0.012, 0.3, 300); var cr = loopNoise(4200, 'bandpass', 6, 0.03); var l2 = osc(C, 'square', 22, C.currentTime, 36000), lg2 = gain(C, 0.03); l2.connect(lg2); lg2.connect(cr.gain); amb.push(l2);
      loopNoise(320, 'bandpass', 0.6, 0.05, 0.08, 120);
    } else if (kind === 'deep') { loopOsc('sawtooth', 38, 0.05, 110); loopOsc('sawtooth', 38.8, 0.05, 110); loopNoise(90, 'lowpass', 0.5, 0.05); }
    else if (kind === 'storm') { loopNoise(500, 'bandpass', 0.5, 0.1, 0.1, 220); loopOsc('sine', 45, 0.03, 200); }
  };
  A.setSilence = function (f) { A.silence = f; if (amb) amb.bus.gain.setTargetAtTime(1 - f, C.currentTime, 0.4); };
  /* eventos aleatórios do ambiente + batimento cardíaco */
  A.update = function (dt, tension, G) {
    if (!A.ok) return;
    if (tension > 0.12) { hbT -= dt; if (hbT <= 0) { hbT = 60 / (56 + 78 * tension); var n = gain(C, 1); n.connect(busFx); V.heart(C, n, C.currentTime + 0.005, { vol: 0.5 * Math.min(1, tension + 0.2) }); } }
    evT -= dt;
    if (evT > 0 || A.silence > 0.5) return;
    evT = 3 + Math.random() * 8;
    var L = A.listener, ang = Math.random() * 6.28, r = 14 + Math.random() * 16, x = L.x + Math.cos(ang) * r, y = L.y + Math.sin(ang) * r, k = A.area;
    if (k === 'lab') A.play(Math.random() < 0.5 ? 'door' : 'crash', x, y, 0.25);
    else if (k === 'pens') A.play(Math.random() < 0.55 ? 'roar_trex' : 'roar_carno', x, y, 0.55);
    else if (k === 'forest') A.play(['roar_raptor', 'roar_trex', 'glass', 'hiss_dilo'][(Math.random() * 4) | 0], x, y, 0.5);
    else if (k === 'deep') A.play(Math.random() < 0.5 ? 'glass' : 'door', x, y, 0.3);
    else if (k === 'storm') A.play(Math.random() < 0.6 ? 'thunder' : 'roar_trex', x, y, 0.6);
  };
  /* teste offline: renderiza uma voz e devolve estatísticas */
  A.renderVoice = function (name, secs) {
    var OC = g.OfflineAudioContext; if (!OC) return Promise.reject(new Error('sem OfflineAudioContext'));
    var c = new OC(1, Math.floor(44100 * secs), 44100), out = c.createGain(); out.connect(c.destination); V[name](c, out, 0.01, { vol: 1 });
    return c.startRendering().then(function (buf) {
      var d = buf.getChannelData(0), peak = 0, sum = 0, nan = 0, last = 0;
      for (var i = 0; i < d.length; i++) { var v = d[i]; if (v !== v) nan++; else { var a = Math.abs(v); if (a > peak) peak = a; sum += v * v; if (a > 0.005) last = i; } }
      return { name: name, peak: peak, rms: Math.sqrt(sum / d.length), nan: nan, activeSecs: last / 44100 };
    });
  };
})(typeof window !== 'undefined' ? window : globalThis);
