/* Lost Prehistoria - entrada: joystick virtual flutuante, olhar por arrasto, botões e teclado (para testes no PC) */
(function (g) {
  'use strict';
  var LP = g.LP, In = LP.In = { mx: 0, my: 0, lookDX: 0, lookDY: 0, invY: false, sprintLatch: false, sprintHold: false, autoRun: true, sens: 1, press: {}, keys: {}, active: false, touching: false };
  In.take = function (n) { var v = In.press[n]; In.press[n] = false; return !!v; };
  var T = {}, stickId = null, lookId = null, ox = 0, oy = 0, lx = 0, ly = 0, base, knob, doc = g.document;
  function R() { var s = LP.stage; return Math.min((s ? s.h : g.innerHeight) * 0.17, 74); }
  /* converte coordenadas da tela física para as do palco (que pode estar girado por CSS) */
  function mp(t) {
    var s = LP.stage;
    if (!s || !s.rot) return { x: t.clientX, y: t.clientY };
    return s.rot === 1 ? { x: t.clientY, y: s.W - t.clientX } : { x: s.H - t.clientY, y: t.clientX };
  }
  function act(a, el) {
    if (a === 'sprint') { In.sprintLatch = !In.sprintLatch; if (el) el.classList.toggle('lit', In.sprintLatch); }
    else In.press[a] = true;
  }
  In.resetLatch = function () { In.sprintLatch = false; var b = doc.querySelector('[data-act=sprint]'); if (b) b.classList.remove('lit'); };
  In.bind = function (root) {
    base = doc.getElementById('stick'); knob = doc.getElementById('knob');
    root.addEventListener('touchstart', function (e) {
      if (!In.active) return;
      for (var i = 0; i < e.changedTouches.length; i++) {
        var t = e.changedTouches[i], el = doc.elementFromPoint(t.clientX, t.clientY), b = el && el.closest ? el.closest('[data-act]') : null;
        In.touching = true;
        if (b) { T[t.identifier] = { b: b }; b.classList.add('on'); act(b.dataset.act, b); continue; }
        var m0 = mp(t), sw0 = LP.stage ? LP.stage.w : g.innerWidth;
        if (m0.x < sw0 * 0.5 && stickId === null) {
          stickId = t.identifier; ox = m0.x; oy = m0.y; base.style.left = ox + 'px'; base.style.top = oy + 'px'; base.classList.add('show'); knob.style.transform = 'translate(0,0)';
        } else if (lookId === null) { lookId = t.identifier; lx = m0.x; ly = m0.y; }
      }
      if (e.cancelable) e.preventDefault();
    }, { passive: false });
    root.addEventListener('touchmove', function (e) {
      for (var i = 0; i < e.changedTouches.length; i++) {
        var t = e.changedTouches[i];
        var mm = mp(t);
        if (t.identifier === stickId) {
          var dx = mm.x - ox, dy = mm.y - oy, r = R(), d = Math.sqrt(dx * dx + dy * dy), k = d > r ? r / d : 1;
          In.mx = dx * k / r; In.my = -dy * k / r; knob.style.transform = 'translate(' + (dx * k) + 'px,' + (dy * k) + 'px)';
        } else if (t.identifier === lookId) { In.lookDX += (mm.x - lx) * 0.0046 * In.sens; In.lookDY += (ly - mm.y) * 0.0030 * In.sens * (In.invY ? -1 : 1); lx = mm.x; ly = mm.y; }
      }
      if (e.cancelable) e.preventDefault();
    }, { passive: false });
    function end(e) {
      for (var i = 0; i < e.changedTouches.length; i++) {
        var t = e.changedTouches[i];
        if (t.identifier === stickId) { stickId = null; In.mx = 0; In.my = 0; base.classList.remove('show'); }
        else if (t.identifier === lookId) lookId = null;
        else if (T[t.identifier]) { T[t.identifier].b.classList.remove('on'); delete T[t.identifier]; }
      }
      if (!e.touches.length) In.touching = false;
    }
    root.addEventListener('touchend', end); root.addEventListener('touchcancel', end);
    /* teclado e mouse (PC) */
    g.addEventListener('keydown', function (e) {
      if (!In.active) return;
      var c = e.code; In.keys[c] = true;
      if (c === 'KeyE') In.press.interact = true; else if (c === 'KeyF') In.press.flash = true; else if (c === 'KeyC' || c === 'ControlLeft') In.press.crouch = true;
      else if (c === 'KeyG') In.press.throw = true; else if (c === 'KeyH') In.press.heal = true; else if (c === 'Escape' || c === 'KeyP') In.press.pause = true;
      if (c.indexOf('Arrow') === 0 || c === 'Space') e.preventDefault();
    });
    g.addEventListener('keyup', function (e) { In.keys[e.code] = false; });
    var drag = false, mxp = 0, myp = 0;
    root.addEventListener('mousedown', function (e) { if (In.active && !In.touching) { drag = true; mxp = e.clientX; myp = e.clientY; } });
    g.addEventListener('mouseup', function () { drag = false; });
    g.addEventListener('mousemove', function (e) { if (drag && In.active) { In.lookDX += (e.clientX - mxp) * 0.004 * In.sens; In.lookDY += (myp - e.clientY) * 0.0028 * In.sens * (In.invY ? -1 : 1); mxp = e.clientX; myp = e.clientY; } });
  };
  /* chamado todo quadro: combina teclado com o joystick */
  In.frame = function () {
    var k = In.keys, kx = (k.KeyD || k.ArrowRight ? 1 : 0) - (k.KeyA || k.ArrowLeft ? 1 : 0), ky = (k.KeyW || k.ArrowUp ? 1 : 0) - (k.KeyS || k.ArrowDown ? 1 : 0);
    if (kx || ky) { In.mx = kx; In.my = ky; In.kbd = true; } else if (In.kbd) { In.mx = 0; In.my = 0; In.kbd = false; }
    if (k.ArrowLeft && !k.KeyA) In.lookDX -= 0.0; 
    In.sprintHold = !!(k.ShiftLeft || k.ShiftRight);
    if (k.KeyQ) In.lookDX -= 0.035; if (k.KeyR) In.lookDX += 0.035; if (k.KeyZ) In.lookDY += 0.012; if (k.KeyX) In.lookDY -= 0.012;
  };
})(typeof window !== 'undefined' ? window : globalThis);
