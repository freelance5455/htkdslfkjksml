/* Lost Prehistoria - arte procedural. Os dinossauros são modelos 3D de cápsulas pré-renderizados
   em sprites (ângulos 0..180° + espelho), com olhos/cristas emissivos (brilham no escuro). */
(function (g) {
  'use strict';
  var LP = g.LP, Art = LP.Art = {}, TAU = Math.PI * 2, cl = LP.clamp;

  function Buf(w, h) {
    this.w = w; this.h = h; var n = w * h;
    this.r = new Float32Array(n); this.g = new Float32Array(n); this.b = new Float32Array(n); this.a = new Float32Array(n); this.e = new Uint8Array(n);
  }
  Buf.prototype.put = function (i, r, gg, b, cov, emis) {
    if (cov >= 0.98) { this.r[i] = r; this.g[i] = gg; this.b[i] = b; this.a[i] = 1; this.e[i] = emis ? 1 : 0; return; }
    var oa = this.a[i], na = cov + oa * (1 - cov), k = oa * (1 - cov);
    this.r[i] = (r * cov + this.r[i] * k) / na; this.g[i] = (gg * cov + this.g[i] * k) / na; this.b[i] = (b * cov + this.b[i] * k) / na;
    this.a[i] = na; if (cov > 0.5) this.e[i] = emis ? 1 : 0;
  };
  Buf.prototype.pack = function (outline) {
    var n = this.w * this.h, d = new Uint32Array(n), W = this.w;
    for (var i = 0; i < n; i++) {
      if (this.a[i] < 0.5) continue;
      var r = this.r[i], gg = this.g[i], b = this.b[i];
      if (outline && !this.e[i]) {
        var x = i % W, y = (i / W) | 0;
        if (x === 0 || y === 0 || x === W - 1 || y === this.h - 1 || this.a[i - 1] < 0.5 || this.a[i + 1] < 0.5 || this.a[i - W] < 0.5 || this.a[i + W] < 0.5) { r *= 0.42; gg *= 0.42; b *= 0.42; }
      }
      r = r < 0 ? 0 : r > 255 ? 255 : r | 0; gg = gg < 0 ? 0 : gg > 255 ? 255 : gg | 0; b = b < 0 ? 0 : b > 255 ? 255 : b | 0;
      d[i] = (((this.e[i] ? 254 : 255) << 24) | (b << 16) | (gg << 8) | r) >>> 0;
    }
    return { w: this.w, h: this.h, d: d };
  };

  var LX = -0.5, LY = -0.55, LZ = 0.67;
  /* cápsula sombreada (pseudo-normal) */
  function cap(B, ax, ay, bx, by, ra, rb, col, o) {
    o = o || {};
    var minx = Math.max(0, Math.floor(Math.min(ax - ra, bx - rb) - 1)), maxx = Math.min(B.w - 1, Math.ceil(Math.max(ax + ra, bx + rb) + 1));
    var miny = Math.max(0, Math.floor(Math.min(ay - ra, by - rb) - 1)), maxy = Math.min(B.h - 1, Math.ceil(Math.max(ay + ra, by + rb) + 1));
    var abx = bx - ax, aby = by - ay, l2 = abx * abx + aby * aby, sk = o.sk === undefined ? 0.2 : o.sk, seed = o.seed || 1;
    for (var y = miny; y <= maxy; y++) for (var x = minx; x <= maxx; x++) {
      var px = x + 0.5, py = y + 0.5;
      var t = l2 > 0 ? cl(((px - ax) * abx + (py - ay) * aby) / l2, 0, 1) : 0;
      var cx = ax + abx * t, cy = ay + aby * t, r = ra + (rb - ra) * t, dx = px - cx, dy = py - cy, d2 = dx * dx + dy * dy;
      if (r <= 0.2 || d2 >= (r + 0.7) * (r + 0.7)) continue;
      var d = Math.sqrt(d2), cov = cl(r - d + 0.5, 0, 1);
      if (cov <= 0) continue;
      var i = y * B.w + x;
      if (o.emis) { B.put(i, col[0], col[1], col[2], cov, true); continue; }
      var nx = dx / r, ny = dy / r, nz = Math.sqrt(Math.max(0, 1 - nx * nx - ny * ny));
      var lam = Math.max(0, nx * LX + ny * LY + nz * LZ), f = o.flat ? 1 : 0.3 + 0.95 * lam;
      var cr = col[0], cg = col[1], cb = col[2];
      if (o.belly && ny > 0.05) { var k = LP.smooth(0.05, 0.9, ny) * 0.85; cr += (o.belly[0] - cr) * k; cg += (o.belly[1] - cg) * k; cb += (o.belly[2] - cb) * k; }
      if (o.stripe) {
        var s = o.stripe, ph = t * s.n + (s.off || 0), fr = ph - Math.floor(ph);
        if (fr < s.w && ny < 0.35) { cr += (s.col[0] - cr) * s.k; cg += (s.col[1] - cg) * s.k; cb += (s.col[2] - cb) * s.k; }
      }
      if (o.spots && LP.hash(x >> 1, y >> 1, seed + 7) < o.spots.p) { cr *= 0.45; cg *= 0.45; cb *= 0.45; }
      var nzs = 1 + (LP.hash(x >> 1, y >> 1, seed) - 0.5) * sk;
      f *= nzs * (0.84 + 0.16 * cl((r - d) / 2.5, 0, 1));
      B.put(i, cr * f, cg * f, cb * f, cov, false);
    }
  }
  /* retângulo sombreado para props */
  function box(B, x, y, w, h, col, o) {
    o = o || {};
    var x0 = Math.floor(x), x1 = Math.ceil(x + w), y0 = Math.floor(y), y1 = Math.ceil(y + h);
    for (var yy = Math.max(0, y0); yy < Math.min(B.h, y1); yy++) for (var xx = Math.max(0, x0); xx < Math.min(B.w, x1); xx++) {
      var u = (xx + 0.5 - x) / w, v = (yy + 0.5 - y) / h; if (u < 0 || u > 1 || v < 0 || v > 1) continue;
      var f = 1;
      if (o.cyl) f = 0.35 + 0.8 * Math.cos((u - 0.42) * 2.4);
      else if (!o.emis) f = 1.05 - 0.4 * v + (u < 0.15 ? 0.15 : 0);
      var edge = (u * w < 1 || (1 - u) * w < 1 || v * h < 1 || (1 - v) * h < 1) ? 0.62 : 1;
      var nz = 1 + (LP.hash(xx >> 1, yy >> 1, o.seed || 5) - 0.5) * (o.sk === undefined ? 0.18 : o.sk);
      f *= edge * nz;
      if (o.emis) B.put(yy * B.w + xx, col[0] * (0.8 + 0.2 * (1 - v)), col[1] * (0.8 + 0.2 * (1 - v)), col[2] * (0.8 + 0.2 * (1 - v)), 1, true);
      else B.put(yy * B.w + xx, col[0] * f, col[1] * f, col[2] * f, 1, false);
    }
  }
  function ik(hx, hy, ax, ay, l1, l2) {
    var dx = ax - hx, dy = ay - hy, d = Math.sqrt(dx * dx + dy * dy), maxd = (l1 + l2) * 0.985;
    if (d > maxd) { ax = hx + dx / d * maxd; ay = hy + dy / d * maxd; dx = ax - hx; dy = ay - hy; d = maxd; }
    if (d < 0.05) d = 0.05;
    var a = (l1 * l1 - l2 * l2 + d * d) / (2 * d), hh = Math.sqrt(Math.max(0, l1 * l1 - a * a)), ux = dx / d, uy = dy / d;
    var kx = hx + ux * a, ky = hy + uy * a, k1x = kx - uy * hh, k1y = ky + ux * hh, k2x = kx + uy * hh, k2y = ky - ux * hh;
    return k1x > k2x ? [k1x, k1y, ax, ay] : [k2x, k2y, ax, ay];
  }

  /* ---------- construtor genérico de terópode ---------- */
  function build(P, ps) {
    var prims = [], ph = ps.phase || 0, A = ps.amp || 0, C = P.col, i;
    function add(a, b, ra, rb, col, o) { prims.push({ a: a, b: b, ra: ra, rb: rb, col: col, o: o }); }
    var crouch = ps.crouch || 0, lunge = ps.lunge || 0, roar = ps.roar || 0, jaw = ps.jaw || 0;
    var hipY = P.hipH + P.bob * A * Math.cos(2 * ph) * 0.5 - crouch * P.hipH * 0.2;
    var lean = P.lean + (ps.lean || 0);
    var hip = [0, hipY, 0], sh = [P.bodyL * Math.cos(lean), hipY + P.bodyL * Math.sin(lean), 0];
    var J = { hip: hip, sh: sh };
    var stT = P.stripe ? { n: P.stripe.nT || 3, w: P.stripe.w, k: P.stripe.k, col: P.stripe.col } : null;
    add(hip, sh, P.bodyR, P.bodyR * (P.chest || 1.05), C.body, { belly: C.belly, stripe: stT, seed: 1, spots: P.spots });
    var tn = 8, prev = hip, tl = P.tailL / tn, R0 = P.bodyR * 0.92; J.tail = [];
    function trad(f) { return P.tailR + (R0 - P.tailR) * Math.pow(1 - f, 1.35); }
    for (i = 1; i <= tn; i++) {
      var f = i / tn, tp = [-tl * i, hipY + (P.tailUp || 0) * f + (ps.tailUp || 0) * f, (P.tailSway || 0.1) * (0.3 + A) * Math.sin(ph + i * 0.8) * f];
      add(prev, tp, trad((i - 1) / tn), trad(f), C.body, { belly: C.belly, stripe: P.stripe, seed: 2, spots: P.spots });
      prev = tp; J.tail.push(tp);
    }
    var a0 = P.neckUp * (1 - 0.55 * lunge) + roar * 0.25, a1 = a0 * 0.5, a2 = a0 * 0.08 - 0.06 * lunge, ns = P.neckL / 3;
    var n1 = [sh[0] + ns * Math.cos(a0), sh[1] + ns * Math.sin(a0), 0], n2 = [n1[0] + ns * Math.cos(a1), n1[1] + ns * Math.sin(a1), 0], n3 = [n2[0] + ns * Math.cos(a2) + 0.06 * lunge, n2[1] + ns * Math.sin(a2), 0];
    add(sh, n1, P.neckR * 1.3, P.neckR * 1.1, C.body, { belly: C.belly, seed: 3, spots: P.spots });
    add(n1, n2, P.neckR * 1.1, P.neckR, C.body, { belly: C.belly, seed: 3, spots: P.spots });
    add(n2, n3, P.neckR, P.neckR * 0.9, C.body, { belly: C.belly, seed: 3, spots: P.spots });
    var hp = -0.14 + roar * 0.75 - lunge * 0.28, hc = Math.cos(hp), hs = Math.sin(hp), HL = P.headL, HR = P.headR;
    var tip = [n3[0] + hc * HL, n3[1] + hs * HL, 0];
    add(n3, tip, HR, HR * (P.snout || 0.55), C.head, { belly: C.belly, seed: 4, sk: 0.14 });
    var hx = n3[0] + hc * HL * 0.22 + hs * HR * 0.5, hy = n3[1] + hs * HL * 0.22 - hc * HR * 0.5, ja = hp - jaw * 0.75;
    var jtip = [hx + Math.cos(ja) * HL * 0.82, hy + Math.sin(ja) * HL * 0.82, 0];
    add([hx, hy, 0], jtip, HR * 0.4, HR * 0.24, C.jaw || C.head, { seed: 5, sk: 0.1 });
    var nt = P.nTeeth || 5, tl2 = P.tooth;
    for (i = 0; i < nt; i++) {
      var t = 0.38 + i * (0.55 / nt), bx = n3[0] + hc * HL * t + hs * HR * 0.35, by = n3[1] + hs * HL * t - hc * HR * 0.35;
      var rt = HR * (1 - (1 - (P.snout || 0.55)) * t) * 0.55;
      for (var sd = -1; sd <= 1; sd += 2) {
        add([bx, by - rt * 0.3, sd * rt], [bx + hs * 0.0, by - tl2 - rt * 0.3, sd * rt], tl2 * 0.28, tl2 * 0.04, C.tooth, { flat: 1, sk: 0, dfwd: 0.3 });
        var jt = 0.3 + i * (0.55 / nt), jx = hx + Math.cos(ja) * HL * 0.82 * jt, jy = hy + Math.sin(ja) * HL * 0.82 * jt;
        add([jx, jy + HR * 0.12, sd * HR * 0.3], [jx, jy + HR * 0.12 + tl2 * 0.8, sd * HR * 0.3], tl2 * 0.24, tl2 * 0.04, C.tooth, { flat: 1, sk: 0, dfwd: 0.3 });
      }
    }
    var ex = n3[0] + hc * HL * 0.34 - hs * HR * 0.45, ey = n3[1] + hs * HL * 0.34 + hc * HR * 0.45;
    if (!P.noEyes) for (var se = -1; se <= 1; se += 2) add([ex, ey, se * HR * 0.78], [ex, ey, se * HR * 0.78], P.eyeR, P.eyeR, C.eye, { emis: 1, dfwd: 0.6 });
    J.n2 = n2; J.n3 = n3; J.hp = hp; J.hc = hc; J.hs = hs; J.tip = tip; J.ex = ex; J.ey = ey; J.jtip = jtip;
    /* pernas */
    var stride = P.stride * A, lift = P.lift * A, ankleH = P.footL * 0.4;
    for (var s = -1; s <= 1; s += 2) {
      var phs = ph + (s > 0 ? 0 : Math.PI), z = s * P.legZ, ax = P.footX + stride * Math.cos(phs), ay = ankleH + lift * Math.max(0, -Math.sin(phs));
      var kn = ik(0, hipY - P.bodyR * 0.3, ax, ay, P.legL1, P.legL2), zk = z * 1.05;
      add([0, hipY - P.bodyR * 0.3, z], [kn[0], kn[1], zk], P.legR * 1.35, P.legR * 0.9, C.body, { belly: C.belly, seed: 6, spots: P.spots });
      add([kn[0], kn[1], zk], [kn[2], kn[3], z], P.legR * 0.85, P.legR * 0.5, C.body, { seed: 7 });
      var gy = Math.max(0.02, kn[3] - ankleH + 0.03);
      add([kn[2], kn[3], z], [kn[2] + P.footL, gy, z], P.legR * 0.5, P.legR * 0.42, C.dark, { seed: 8, sk: 0.1 });
      add([kn[2] + P.footL, gy, z], [kn[2] + P.footL + 0.04, gy, z], P.legR * 0.3, P.legR * 0.1, C.claw, { flat: 1, sk: 0 });
      if (P.sickle) add([kn[2] + P.footL * 0.3, gy + 0.01, z], [kn[2] + P.footL * 0.6, gy + 0.09, z], P.legR * 0.2, P.legR * 0.04, C.claw, { flat: 1, sk: 0 });
    }
    /* braços */
    var sw = 0.35 * A * Math.sin(ph), ar = P.armPose || 0;
    for (var sa = -1; sa <= 1; sa += 2) {
      var sz = sa * P.armZ, sp = sw * sa, a1x = P.armL * 0.5, up = [sh[0] + 0.02, sh[1] - P.bodyR * 0.3, sz];
      var el = [up[0] + a1x * Math.cos(-0.9 + sp + ar), up[1] + a1x * Math.sin(-0.9 + sp + ar), sz * 1.1];
      var hn = [el[0] + a1x * Math.cos(-0.25 + sp * 0.5 + ar + (ps.reach || 0)), el[1] + a1x * Math.sin(-0.25 + sp * 0.5 + ar + (ps.reach || 0)), sz * 1.15];
      add(up, el, P.armR * 1.2, P.armR * 0.9, C.body, { seed: 9 });
      add(el, hn, P.armR * 0.9, P.armR * 0.6, C.body, { seed: 9 });
      for (var cf = -1; cf <= 1; cf++) add(hn, [hn[0] + 0.05 * (P.fingerL || 1) * Math.cos(-0.5), hn[1] + 0.05 * (P.fingerL || 1) * Math.sin(-0.5) - 0.01, hn[2] + cf * 0.012], P.armR * 0.35, P.armR * 0.1, C.claw, { flat: 1, sk: 0 });
    }
    if (P.extra) P.extra(add, J, ps, P);
    return prims;
  }

  function project(prims, theta, S, ch, ppu, cxm, margin) {
    var B = new Buf(S, ch), s = Math.sin(theta), c = Math.cos(theta), arr = [], i;
    for (i = 0; i < prims.length; i++) {
      var p = prims[i], a = p.a, b = p.b;
      arr.push({
        ax: ((a[0] - cxm) * s - a[2] * c) * ppu + S / 2, ay: ch - margin - a[1] * ppu, bx: ((b[0] - cxm) * s - b[2] * c) * ppu + S / 2, by: ch - margin - b[1] * ppu,
        ra: p.ra * ppu, rb: p.rb * ppu, dep: (a[0] + b[0]) * 0.5 * c + (a[2] + b[2]) * 0.5 * s + ((p.o && p.o.dfwd) ? p.o.dfwd * c : 0), p: p
      });
    }
    arr.sort(function (u, v) { return u.dep - v.dep; });
    for (i = 0; i < arr.length; i++) { var q = arr[i]; cap(B, q.ax, q.ay, q.bx, q.by, q.ra, q.rb, q.p.col, q.p.o); }
    return B.pack(true);
  }

  /* ---------- espécies ---------- */
  var COL = { tooth: [232, 226, 200], claw: [40, 34, 28] };
  function sp(o) { o.col.tooth = o.col.tooth || COL.tooth; o.col.claw = o.col.claw || COL.claw; return o; }
  var SPEC = {
    raptor: sp({
      cw: 112, hipH: 0.42, bodyL: 0.34, bodyR: 0.115, lean: 0.08, tailL: 0.8, tailR: 0.04, tailSway: 0.1, neckL: 0.32, neckR: 0.052, neckUp: 1.05,
      headL: 0.26, headR: 0.068, legL1: 0.27, legL2: 0.28, footL: 0.12, legR: 0.058, legZ: 0.08, footX: 0.02, stride: 0.2, lift: 0.1, bob: 0.02, armL: 0.2, armR: 0.026, armZ: 0.085, armPose: 0.3,
      tooth: 0.026, eyeR: 0.017, sickle: 1, snout: 0.5,
      col: { body: [66, 76, 58], belly: [150, 138, 104], head: [78, 78, 56], dark: [38, 40, 30], jaw: [150, 118, 96], eye: [255, 196, 40] },
      stripe: { n: 1.1, nT: 3.5, w: 0.4, k: 0.65, col: [158, 92, 38] }
    }),
    trex: sp({
      cw: 160, hipH: 1.02, bodyL: 0.62, bodyR: 0.36, chest: 1.1, lean: 0.14, tailL: 1.55, tailR: 0.07, tailSway: 0.1, neckL: 0.52, neckR: 0.22, neckUp: 0.85,
      headL: 0.8, headR: 0.27, legL1: 0.68, legL2: 0.64, footL: 0.3, legR: 0.17, legZ: 0.25, footX: 0.05, stride: 0.34, lift: 0.14, bob: 0.03, armL: 0.3, armR: 0.05, armZ: 0.26, armPose: 0.4, fingerL: 1.5,
      tooth: 0.075, eyeR: 0.045, nTeeth: 6, snout: 0.6,
      col: { body: [82, 76, 52], belly: [150, 134, 98], head: [94, 82, 58], dark: [46, 40, 30], jaw: [120, 98, 78], eye: [255, 110, 28] },
      spots: { p: 0.02 }
    }),
    dilo: sp({
      cw: 112, hipH: 0.5, bodyL: 0.4, bodyR: 0.12, lean: 0.1, tailL: 0.88, tailR: 0.04, tailSway: 0.12, neckL: 0.48, neckR: 0.055, neckUp: 1.15,
      headL: 0.24, headR: 0.062, legL1: 0.3, legL2: 0.32, footL: 0.13, legR: 0.055, legZ: 0.08, footX: 0.03, stride: 0.22, lift: 0.1, bob: 0.02, armL: 0.2, armR: 0.026, armZ: 0.09, armPose: 0.3,
      tooth: 0.03, eyeR: 0.02, snout: 0.5,
      col: { body: [96, 102, 52], belly: [168, 158, 108], head: [108, 106, 58], dark: [48, 50, 30], jaw: [140, 120, 90], eye: [255, 236, 60] },
      spots: { p: 0.12 },
      extra: function (add, J, ps, P) {
        var fr = ps.frill === undefined ? 0.2 : ps.frill, ang = Math.atan2(J.n2[1] - J.sh[1], J.n2[0] - J.sh[0]), ux = -Math.sin(ang), uy = Math.cos(ang), dx = Math.cos(ang), dy = Math.sin(ang);
        for (var k = 0; k < 12; k++) {
          var ph = k / 12 * TAU, cu = Math.cos(ph), cz = Math.sin(ph), L = 0.05 + 0.2 * fr;
          add([J.n2[0], J.n2[1], 0], [J.n2[0] + ux * cu * L - dx * 0.3 * L, J.n2[1] + uy * cu * L - dy * 0.3 * L, cz * L], 0.03 + 0.012 * fr, 0.02 + 0.01 * fr, k % 2 ? [226, 98, 32] : [150, 52, 24], { seed: 11, sk: 0.1 });
        }
        for (var cz2 = -1; cz2 <= 1; cz2 += 2) add([J.n3[0] + J.hc * 0.05, J.n3[1] + J.hs * 0.05 + 0.05, cz2 * 0.02], [J.n3[0] + J.hc * 0.19, J.n3[1] + J.hs * 0.19 + 0.09, cz2 * 0.02], 0.012, 0.01, [230, 100, 40], { seed: 12 });
      }
    }),
    carno: sp({
      cw: 136, hipH: 0.78, bodyL: 0.5, bodyR: 0.3, chest: 1.1, lean: 0.1, tailL: 1.15, tailR: 0.06, tailSway: 0.1, neckL: 0.3, neckR: 0.2, neckUp: 0.7,
      headL: 0.42, headR: 0.2, legL1: 0.46, legL2: 0.45, footL: 0.2, legR: 0.13, legZ: 0.2, footX: 0.04, stride: 0.3, lift: 0.12, bob: 0.03, armL: 0.12, armR: 0.035, armZ: 0.2, armPose: 0.5,
      tooth: 0.05, eyeR: 0.034, nTeeth: 5, snout: 0.62,
      col: { body: [126, 52, 38], belly: [176, 124, 90], head: [136, 60, 42], dark: [62, 28, 24], jaw: [150, 96, 72], eye: [255, 64, 36] },
      stripe: { n: 1.0, nT: 3, w: 0.4, k: 0.6, col: [58, 24, 22] },
      extra: function (add, J) {
        for (var s = -1; s <= 1; s += 2) add([J.n3[0] + J.hc * 0.13 - J.hs * 0.1, J.n3[1] + J.hs * 0.13 + 0.14, s * 0.1], [J.n3[0] + J.hc * 0.1 - J.hs * 0.1, J.n3[1] + J.hs * 0.1 + 0.3, s * 0.15], 0.045, 0.006, [214, 204, 178], { seed: 13 });
      }
    }),
    special: sp({
      cw: 128, hipH: 0.8, bodyL: 0.5, bodyR: 0.15, chest: 1.15, lean: 0.55, tailL: 0.75, tailR: 0.028, tailSway: 0.18, neckL: 0.72, neckR: 0.06, neckUp: 0.8,
      headL: 0.42, headR: 0.07, legL1: 0.5, legL2: 0.5, footL: 0.16, legR: 0.05, legZ: 0.07, footX: 0.05, stride: 0.26, lift: 0.12, bob: 0.02, armL: 0.85, armR: 0.046, armZ: 0.11, armPose: 0.1, fingerL: 4,
      tooth: 0.045, eyeR: 0, nTeeth: 8, snout: 0.45, noEyes: 1,
      col: { body: [168, 178, 180], belly: [214, 220, 218], head: [188, 196, 198], dark: [104, 112, 116], jaw: [60, 48, 56], eye: [0, 0, 0], tooth: [238, 238, 226], claw: [70, 70, 76] },
      extra: function (add, J) {
        var cy = [90, 240, 225];
        add([J.hip[0], J.hip[1] + 0.12, 0], [J.sh[0], J.sh[1] + 0.13, 0], 0.016, 0.016, cy, { emis: 1 });
        for (var i = 0; i < J.tail.length - 1; i++) add([J.tail[i][0], J.tail[i][1] + 0.07 - i * 0.01, J.tail[i][2]], [J.tail[i][0], J.tail[i][1] + 0.07 - i * 0.01, J.tail[i][2]], 0.015, 0.015, cy, { emis: 1 });
        for (var k = 0; k < 4; k++) { var t = 0.25 + k * 0.2; add([J.n3[0] + J.hc * 0.42 * t, J.n3[1] + J.hs * 0.42 * t + 0.07, 0], [J.n3[0] + J.hc * 0.42 * t - 0.02, J.n3[1] + J.hs * 0.42 * t + 0.1, 0], 0.014, 0.01, cy, { emis: 1 }); }
        for (var s = -1; s <= 1; s += 2) for (var p = 0; p < 3; p++) add([J.n3[0] + J.hc * 0.12 * (p + 1), J.n3[1] + J.hs * 0.12 * (p + 1) + 0.01, s * 0.065], [J.n3[0] + J.hc * 0.12 * (p + 1), J.n3[1] + J.hs * 0.12 * (p + 1) + 0.01, s * 0.065], 0.009, 0.009, cy, { emis: 1 });
      }
    })
  };
  Art.SPEC = SPEC;
  var ANIMS = {
    walk: { n: 6, f: function (i) { return { phase: i / 6 * TAU, amp: 0.55 }; } },
    run: { n: 6, f: function (i) { return { phase: i / 6 * TAU, amp: 1, lean: 0.12, tailUp: 0.06, lunge: 0.3 }; } },
    idle: { n: 2, f: function (i) { return { amp: 0, jaw: i * 0.04, crouch: i * 0.03 }; } },
    alert: { n: 2, f: function (i) { return { amp: 0, roar: 0.55 + i * 0.3, jaw: 0.5 + i * 0.5, frill: 1, reach: 0.4 }; } },
    attack: { n: 3, f: function (i) { return [{ lunge: -0.4, jaw: 0.2, crouch: 0.3, frill: 1 }, { lunge: 1, jaw: 1, crouch: 0.05, frill: 1, reach: 0.8 }, { lunge: 0.4, jaw: 0.5, frill: 0.6 }][i]; } }
  };
  Art.ANIMS = ANIMS;
  var ORDER = ['walk', 'run', 'idle', 'alert', 'attack'];

  /* gera a folha de sprites de uma espécie, uma animação por chamada de step() */
  function fit(P) {
    var xmin = 1e9, xmax = -1e9, ymax = 0, poses = [ANIMS.walk.f(0), ANIMS.run.f(2), ANIMS.attack.f(1), ANIMS.alert.f(1), ANIMS.idle.f(0), ANIMS.walk.f(3)];
    poses.forEach(function (ps) {
      build(P, ps).forEach(function (p) {
        [p.a, p.b].forEach(function (q, i) { var r = i ? p.rb : p.ra; xmin = Math.min(xmin, q[0] - r); xmax = Math.max(xmax, q[0] + r); ymax = Math.max(ymax, q[1] + r); });
      });
    });
    P.ppu = (P.cw - 10) / (xmax - xmin); P.cxm = (xmin + xmax) / 2; P.ch = Math.ceil(ymax * P.ppu) + 8; P.sw = P.cw / P.ppu; P.sh = P.ch / P.ppu;
  }
  Art.makeDino = function (name) {
    var P = SPEC[name]; if (!P.ppu) fit(P);
    var sheet = { name: name, frames: {}, sw: P.sw, sh: P.sh, done: false, k: 0 };
    sheet.step = function () {
      var an = ORDER[sheet.k++], A = ANIMS[an], list = [];
      for (var i = 0; i < A.n; i++) {
        var prims = build(P, A.f(i)), views = [];
        for (var v = 0; v < 5; v++) views.push(project(prims, v * Math.PI / 4, P.cw, P.ch, P.ppu, P.cxm, 3));
        list.push(views);
      }
      sheet.frames[an] = list;
      if (sheet.k >= ORDER.length) sheet.done = true;
      return sheet.done;
    };
    sheet.all = function () { while (!sheet.step()); return sheet; };
    return sheet;
  };
  /* escolhe o quadro: rel = ângulo da câmera relativo ao focinho do animal */
  Art.pick = function (sheet, anim, fi, rel) {
    var list = sheet.frames[anim] || sheet.frames.idle, a = Math.abs(rel), v = Math.round(a / (Math.PI / 4)); if (v > 4) v = 4;
    return { img: list[fi % list.length][v], mirror: rel < 0 };
  };

  /* ---------- itens e props ---------- */
  var PR = {
    barrel: { w: 36, h: 44, sw: 0.55, sh: 0.62, d: function (B) { box(B, 4, 4, 28, 38, [128, 52, 30], { cyl: 1 }); box(B, 4, 11, 28, 3, [58, 58, 60], { cyl: 1 }); box(B, 4, 30, 28, 3, [58, 58, 60], { cyl: 1 }); box(B, 6, 2, 24, 4, [80, 76, 70], { cyl: 1 }); } },
    crate: { w: 44, h: 40, sw: 0.85, sh: 0.7, d: function (B) { box(B, 3, 4, 38, 34, [112, 84, 52]); for (var i = 0; i < 4; i++) box(B, 3, 4 + i * 9, 38, 1.5, [60, 44, 28]); box(B, 3, 4, 3, 34, [74, 54, 34]); box(B, 38, 4, 3, 34, [74, 54, 34]); box(B, 18, 2, 8, 3, [180, 170, 150]); } },
    console: { w: 52, h: 44, sw: 0.95, sh: 0.75, d: function (B) { box(B, 3, 22, 46, 20, [58, 64, 68]); box(B, 6, 4, 40, 20, [24, 26, 30]); box(B, 9, 7, 34, 14, [40, 210, 170], { emis: 1 }); for (var i = 0; i < 4; i++) box(B, 11, 9 + i * 3, 12 + (i * 7) % 16, 1, [10, 90, 70], { emis: 1 }); box(B, 8, 28, 36, 4, [90, 96, 100]); } },
    medkit: { w: 34, h: 26, sw: 0.34, sh: 0.26, lift: 0.04, d: function (B) { box(B, 2, 4, 30, 20, [230, 230, 226]); box(B, 14, 6, 6, 16, [200, 30, 30]); box(B, 9, 11, 16, 6, [200, 30, 30]); box(B, 12, 1, 10, 4, [150, 150, 150]); } },
    battery: { w: 22, h: 34, sw: 0.18, sh: 0.28, lift: 0.04, d: function (B) { box(B, 4, 6, 14, 26, [40, 150, 60], { cyl: 1 }); box(B, 8, 2, 6, 5, [170, 170, 170], { cyl: 1 }); box(B, 4, 14, 14, 5, [240, 220, 60], { emis: 1 }); } },
    throw: { w: 18, h: 34, sw: 0.14, sh: 0.28, lift: 0.04, d: function (B) { box(B, 4, 12, 10, 20, [60, 150, 90], { cyl: 1 }); box(B, 6, 4, 6, 9, [80, 170, 110], { cyl: 1 }); box(B, 7, 2, 4, 3, [120, 100, 60]); } },
    card1: { w: 32, h: 22, sw: 0.28, sh: 0.2, lift: 0.05, d: function (B) { box(B, 2, 3, 28, 17, [60, 64, 70]); box(B, 2, 6, 28, 4, [60, 140, 255], { emis: 1 }); box(B, 5, 13, 7, 5, [220, 190, 80]); } },
    card2: { w: 32, h: 22, sw: 0.28, sh: 0.2, lift: 0.05, d: function (B) { box(B, 2, 3, 28, 17, [60, 64, 70]); box(B, 2, 6, 28, 4, [240, 200, 40], { emis: 1 }); box(B, 5, 13, 7, 5, [220, 190, 80]); } },
    card3: { w: 32, h: 22, sw: 0.28, sh: 0.2, lift: 0.05, d: function (B) { box(B, 2, 3, 28, 17, [60, 64, 70]); box(B, 2, 6, 28, 4, [240, 50, 40], { emis: 1 }); box(B, 5, 13, 7, 5, [220, 190, 80]); } },
    gatekey: { w: 30, h: 22, sw: 0.26, sh: 0.2, lift: 0.05, d: function (B) { cap(B, 7, 11, 7, 11, 5, 5, [200, 170, 70], {}); box(B, 10, 9.5, 17, 3, [190, 160, 60]); box(B, 22, 12, 3, 5, [190, 160, 60]); box(B, 17, 12, 3, 4, [190, 160, 60]); } },
    fuse: { w: 20, h: 34, sw: 0.17, sh: 0.3, lift: 0.04, d: function (B) { box(B, 3, 4, 14, 5, [170, 170, 176], { cyl: 1 }); box(B, 3, 25, 14, 5, [170, 170, 176], { cyl: 1 }); box(B, 4, 9, 12, 16, [250, 200, 60], { emis: 1 }); box(B, 9, 10, 2, 14, [120, 90, 20], { emis: 1 }); } },
    core: { w: 28, h: 40, sw: 0.24, sh: 0.34, lift: 0.04, d: function (B) { box(B, 3, 2, 22, 6, [50, 56, 60], { cyl: 1 }); box(B, 3, 32, 22, 6, [50, 56, 60], { cyl: 1 }); box(B, 6, 8, 16, 24, [80, 240, 225], { emis: 1 }); box(B, 12, 10, 4, 20, [220, 255, 250], { emis: 1 }); } },
    doc: { w: 28, h: 24, sw: 0.26, sh: 0.22, lift: 0.04, d: function (B) { box(B, 3, 3, 22, 18, [214, 208, 190]); for (var i = 0; i < 4; i++) box(B, 6, 6 + i * 4, 16 - (i % 2) * 5, 1, [90, 88, 80]); } },
    key_doc: { w: 28, h: 24, sw: 0.26, sh: 0.22, lift: 0.04, d: function (B) { box(B, 3, 3, 22, 18, [214, 208, 190]); for (var i = 0; i < 4; i++) box(B, 6, 6 + i * 4, 16 - (i % 2) * 5, 1, [90, 88, 80]); box(B, 19, 3, 6, 5, [80, 240, 225], { emis: 1 }); } },
    log: { w: 30, h: 24, sw: 0.26, sh: 0.22, lift: 0.04, d: function (B) { box(B, 3, 4, 24, 17, [40, 44, 48]); cap(B, 10, 11, 10, 11, 4, 4, [140, 140, 146], {}); cap(B, 20, 11, 20, 11, 4, 4, [140, 140, 146], {}); box(B, 22, 5, 3, 3, [255, 50, 40], { emis: 1 }); } },
    save: { w: 36, h: 56, sw: 0.5, sh: 0.78, d: function (B) { box(B, 7, 22, 22, 32, [56, 62, 66]); box(B, 9, 12, 18, 12, [255, 176, 60], { emis: 1 }); box(B, 11, 14, 14, 2, [120, 70, 10], { emis: 1 }); cap(B, 18, 7, 18, 7, 4, 4, [255, 200, 90], { emis: 1 }); box(B, 11, 30, 14, 5, [30, 32, 36]); } },
    bones: { w: 44, h: 22, sw: 0.7, sh: 0.3, d: function (B) { for (var i = 0; i < 5; i++) cap(B, 8 + i * 6, 14, 12 + i * 6, 6, 1.6, 1.2, [214, 206, 184], {}); cap(B, 6, 15, 38, 15, 1.8, 1.8, [200, 192, 170], {}); cap(B, 38, 12, 38, 12, 5, 5, [220, 212, 190], {}); box(B, 40, 12, 4, 3, [196, 188, 166]); } },
    venom: { w: 20, h: 20, sw: 0.26, sh: 0.26, lift: 0.3, d: function (B) { cap(B, 10, 10, 10, 10, 8, 8, [60, 255, 90], { emis: 1 }); cap(B, 10, 10, 10, 10, 4, 4, [220, 255, 200], { emis: 1 }); } }
  };
  var cache = {};
  Art.prop = function (name) {
    if (cache[name]) return cache[name];
    var d = PR[name]; if (!d) throw new Error('prop desconhecido ' + name);
    var B = new Buf(d.w, d.h); d.d(B);
    return (cache[name] = { img: B.pack(), sw: d.sw, sh: d.sh, lift: d.lift || 0 });
  };
  Art.propNames = Object.keys(PR);
})(typeof window !== 'undefined' ? window : globalThis);
