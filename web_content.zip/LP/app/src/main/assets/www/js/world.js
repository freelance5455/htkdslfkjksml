/* Lost Prehistoria - mundo (grade de tiles, portas, colisão, LOS, A*, luz) */
(function (g) {
  'use strict';
  var LP = g.LP;
  var K = LP.K = { FLOOR: 0, WALL: 1, DOOR: 2, EXIT: 3, BARR: 4, HIDE: 5, TERM: 6, LEVER: 7, PROP: 8 };
  var TD = LP.TD = {
    '.': { k: 0 }, ',': { k: 0, fv: 1 }, '_': { k: 0, fv: 2 },
    '#': { k: 1, slot: 'wa' }, '=': { k: 1, slot: 'wb' }, '%': { k: 1, slot: 'wc' }, '&': { k: 1, slot: 'wd' },
    '+': { k: 2, tex: 'door' }, '1': { k: 2, tex: 'door_c1', lock: { card: 1 } }, '2': { k: 2, tex: 'door_c2', lock: { card: 2 } },
    '3': { k: 2, tex: 'door_c3', lock: { card: 3 } }, 'C': { k: 2, tex: 'door_code', lock: { code: 1 } },
    'P': { k: 2, tex: 'door_pwr', lock: { flag: 1 } }, 'G': { k: 2, tex: 'gate', lock: { item: 'gatekey' } },
    'e': { k: 3, tex: 'exit' }, 'B': { k: 4, tex: 'barr' },
    'h': { k: 5, tex: 'locker', hide: 'locker' }, 'H': { k: 5, tex: 'bush', hide: 'bush' }, 'v': { k: 5, tex: 'vent', hide: 'vent' },
    't': { k: 6, tex: 'term' }, 'u': { k: 6, tex: 'term' }, 'L': { k: 7, tex: 'lever' }, 'J': { k: 7, tex: 'lever' },
    'o': { k: 8, prop: 'barrel' }, 'c': { k: 8, prop: 'crate' }, 'k': { k: 8, prop: 'console' }, 'N': { k: 8, prop: 'block' }, 'M': { k: 8, prop: 'cont' }
  };
  var ENT = {
    '@': 'start', 's': 'save', 'R': 'raptor', 'X': 'trex', 'D': 'dilo', 'K': 'carno', 'S': 'special', 'm': 'medkit', 'b': 'battery',
    'z': 'throw', 'q': 'card1', 'w': 'card2', 'r': 'card3', 'g': 'gatekey', 'x': 'fuse', 'n': 'core', 'I': 'lamp1', 'i': 'lamp2', 'E': 'lamp3', 'j': 'bones'
  };
  var DINO = { raptor: 1, trex: 1, dilo: 1, carno: 1, special: 1 };
  LP.DINO_CH = DINO;

  var World = LP.World = function (area, P) {
    var rows = area.rows, w = 0, y, x, i;
    for (y = 0; y < rows.length; y++) if (rows[y].length > w) w = rows[y].length;
    var h = rows.length, n = w * h;
    this.area = area; this.w = w; this.h = h; this.P = P || { flags: {}, picked: {}, unlocked: {} };
    this.kind = new Uint8Array(n); this.tex = new Uint8Array(n); this.texBase = new Uint8Array(n); this.special = new Uint8Array(n);
    this.ftex = new Uint8Array(n); this.dOpen = new Float32Array(n); this.lamp = new Uint8Array(n); this.lampLvl = new Float32Array(n).fill(1);
    this.cls = new Uint8Array(n); this.objAt = new Int16Array(n); this.objs = [];
    this.doors = {}; this.doorList = []; this.hides = {}; this.meta = {}; this.ents = []; this.props = []; this.spawns = []; this.lights = []; this.fl = [];
    this.noises = []; this.nid = 0; this.time = 0; this.lightMul = 1; this.start = { x: 1.5, y: 1.5, a: 0 }; this.lampList = [];
    var pal = area.pal, ID = LP.Tex.ID, need = [pal.wa, pal.wb, pal.wc, pal.wd, pal.f0, pal.f1, pal.f2, pal.ceil];
    var fl = [ID[pal.f0], ID[pal.f1], ID[pal.f2]];
    var used = {};
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
      var ch = (rows[y][x] || '#'); if (ch === ' ') ch = '#';
      i = y * w + x; this.ftex[i] = fl[0];
      var td = TD[ch], lg = area.legend && area.legend[ch];
      if (td) {
        this.kind[i] = td.k;
        if (td.k === K.FLOOR) { this.ftex[i] = fl[td.fv || 0]; continue; }
        var tn = td.slot ? pal[td.slot] : td.tex;
        if (tn) { need.push(tn); this.texBase[i] = this.tex[i] = ID[tn]; }
        if (td.k !== K.WALL && td.k !== K.PROP) this.special[i] = 1;
        if (td.k === K.PROP) { this.tex[i] = 0; this.props.push({ x: x + 0.5, y: y + 0.5, spr: td.prop, solid: true }); }
        if (td.k === K.DOOR) {
          var d = { i: i, x: x, y: y, ch: ch, lock: td.lock ? JSON.parse(JSON.stringify(td.lock)) : null, st: 0, t: 0 };
          if (this.P.unlocked[area.id + ':' + i]) d.lock = null;
          this.doors[i] = d; this.doorList.push(d);
        }
        if (td.k === K.HIDE) this.hides[i] = { i: i, x: x, y: y, type: td.hide, heat: 0, burned: false };
        if (lg) this.meta[i] = lg;
        used[ch] = 1;
        continue;
      }
      this.kind[i] = K.FLOOR;
      var et = ENT[ch];
      if (et) {
        if (et === 'start') this.start = { x: x + 0.5, y: y + 0.5, a: (area.startAngle || 0) };
        else if (DINO[et]) this.spawns.push({ sp: et, x: x + 0.5, y: y + 0.5 });
        else if (et === 'lamp1' || et === 'lamp2' || et === 'lamp3') {
          var lt = et === 'lamp1' ? 1 : et === 'lamp2' ? 2 : 3; this.lamp[i] = lt;
          this.lampList.push({ i: i, type: lt, seed: (x * 7 + y * 13) % 97 });
          var c = lt === 3 ? [1, 0.12, 0.07] : (area.lampCol || [0.8, 0.9, 1]);
          this.lights.push({ x: x + 0.5, y: y + 0.5, r: c[0], g: c[1], b: c[2], rad: lt === 3 ? 6 : (area.lampRad || 6), I: lt === 3 ? 0.8 : (area.lampI || 0.85), type: lt, seed: (x * 7 + y * 13) % 97 });
        } else {
          var id = area.id + ':' + ch + x + ',' + y;
          if (et === 'save') this.ents.push({ type: 'save', x: x + 0.5, y: y + 0.5, spr: 'save', id: id });
          else if (et === 'bones') this.ents.push({ type: 'deco', x: x + 0.5, y: y + 0.5, spr: 'bones', id: id });
          else if (!this.P.picked[id]) this.ents.push({ type: et, x: x + 0.5, y: y + 0.5, spr: et, id: id });
        }
      } else if (lg) {
        var id2 = area.id + ':' + (lg.id || ch) + ':' + x + ',' + y;
        if (lg.t === 'trig') this.ents.push({ type: 'trig', x: x + 0.5, y: y + 0.5, ev: lg.ev, id: lg.id || id2, once: lg.once !== false, r: lg.r || 0.8 });
        else if (!this.P.picked[lg.id]) this.ents.push({ type: lg.t, x: x + 0.5, y: y + 0.5, spr: lg.t === 'doc' ? (lg.key ? 'key_doc' : 'doc') : 'log', id: lg.id, doc: lg.id });
      }
    }
    /* objetos 3D: props sólidos (caixotes, barris, consoles, blocos, contêineres) e todos os itens */
    var self = this;
    function addObj(kind, x, y, ent, rot) {
      var df = LP.OBJ[kind]; if (!df) return null;
      var o = { kind: kind, x: x, y: y, ent: ent || null, parts: df.make(x, y, rot || 0, area) };
      for (var q = 0; q < df.tex.length; q++) need.push(df.tex[q]);
      self.objs.push(o); self.objAt[(y | 0) * w + (x | 0)] = self.objs.length; return o;
    }
    function consoleRot(x, y) {
      var D = [[0, 1], [-1, 0], [0, -1], [1, 0]];
      for (var r = 0; r < 4; r++) if (self.kind[((y | 0) + D[r][1]) * w + ((x | 0) + D[r][0])] === 0) return r;
      return 0;
    }
    this.props.forEach(function (p) { addObj(p.spr, p.x, p.y, null, p.spr === 'console' ? consoleRot(p.x, p.y) : 0); });
    var IL = { medkit: [1, 0.45, 0.45], battery: [0.45, 1, 0.55], throw: [0.5, 1, 0.75], card1: [0.3, 0.6, 1], card2: [1, 0.85, 0.2], card3: [1, 0.3, 0.2], gatekey: [1, 0.8, 0.3], fuse: [1, 0.8, 0.3], core: [0.3, 1, 0.9], doc: [0.9, 0.9, 0.8], key_doc: [0.4, 1, 0.9], log: [1, 0.4, 0.3] };
    this.ents.forEach(function (e) {
      if (e.type === 'trig' || e.type === 'deco' || !LP.OBJ[e.spr]) return;
      addObj(e.spr, e.x, e.y, e);
      var c = IL[e.spr]; if (c) { var L = { x: e.x, y: e.y, r: c[0], g: c[1], b: c[2], rad: 2.4, I: 0.26, type: 0 }; self.lights.push(L); e.light = L; }
    });
    LP.Tex.use(need);
    this._buildCls(); this._buildLights();
    this.lm = new Float32Array(this.lmS.length);
    this.lm.set(this.lmS);
  };
  var W = World.prototype;

  W.solidAt = function (tx, ty) {
    if (tx < 0 || ty < 0 || tx >= this.w || ty >= this.h) return true;
    var i = ty * this.w + tx, k = this.kind[i];
    if (k === 0) return false;
    if (k === 2) return this.dOpen[i] < 0.85;
    return true;
  };
  W.opaque = function (tx, ty) {
    if (tx < 0 || ty < 0 || tx >= this.w || ty >= this.h) return true;
    var i = ty * this.w + tx, k = this.kind[i];
    if (k === 0 || k === 8) return false;
    if (k === 2) return this.dOpen[i] < 0.5;
    return true;
  };
  W.collides = function (x, y, r) {
    var x0 = Math.floor(x - r), x1 = Math.floor(x + r), y0 = Math.floor(y - r), y1 = Math.floor(y + r);
    for (var ty = y0; ty <= y1; ty++) for (var tx = x0; tx <= x1; tx++) {
      if (!this.solidAt(tx, ty)) continue;
      var cx = x < tx ? tx : x > tx + 1 ? tx + 1 : x, cy = y < ty ? ty : y > ty + 1 ? ty + 1 : y, dx = x - cx, dy = y - cy;
      if (dx * dx + dy * dy < r * r) return true;
    }
    return false;
  };
  /* move com deslizamento; devolve máscara de bloqueio (1=x, 2=y) */
  W.move = function (e, dx, dy, r) {
    var m = 0, nx = e.x + dx, ny;
    if (!this.collides(nx, e.y, r)) e.x = nx; else m |= 1;
    ny = e.y + dy;
    if (!this.collides(e.x, ny, r)) e.y = ny; else m |= 2;
    return m;
  };
  W.unstick = function (e, r) {
    if (!this.collides(e.x, e.y, r)) return false;
    for (var rad = 0.25; rad < 3; rad += 0.25) for (var a = 0; a < 6.28; a += 0.5) {
      var nx = e.x + Math.cos(a) * rad, ny = e.y + Math.sin(a) * rad;
      if (!this.collides(nx, ny, r)) { e.x = nx; e.y = ny; return true; }
    }
    return false;
  };
  W.los = function (x0, y0, x1, y1) {
    var dx = x1 - x0, dy = y1 - y0;
    if (dx * dx + dy * dy < 1e-9) return true;
    var tx = Math.floor(x0), ty = Math.floor(y0), ex = Math.floor(x1), ey = Math.floor(y1);
    var sx = dx > 0 ? 1 : -1, sy = dy > 0 ? 1 : -1, tDx = dx === 0 ? 1e30 : Math.abs(1 / dx), tDy = dy === 0 ? 1e30 : Math.abs(1 / dy);
    var tMx = dx === 0 ? 1e30 : (dx > 0 ? tx + 1 - x0 : x0 - tx) * tDx, tMy = dy === 0 ? 1e30 : (dy > 0 ? ty + 1 - y0 : y0 - ty) * tDy, n = 0;
    while (n++ < 90) {
      if (tMx < tMy) { tMx += tDx; tx += sx; } else { tMy += tDy; ty += sy; }
      if (tx === ex && ty === ey) return true;
      if (this.opaque(tx, ty)) return false;
    }
    return true;
  };
  /* primeiro tile não-vazio ao longo de um raio curto (interação) */
  W.rayTile = function (x, y, a, maxd) {
    var dx = Math.cos(a), dy = Math.sin(a), d;
    for (d = 0.15; d <= maxd; d += 0.1) {
      var tx = Math.floor(x + dx * d), ty = Math.floor(y + dy * d);
      if (tx < 0 || ty < 0 || tx >= this.w || ty >= this.h) return null;
      var i = ty * this.w + tx, k = this.kind[i];
      if (k !== 0 && k !== 8) return { i: i, d: d, k: k };
      if (k === 8) return null;
    }
    return null;
  };

  /* ---------- portas ---------- */
  W.openDoor = function (d) { if (d.st === 0 || d.st === 3) d.st = 1; };
  W.updateDoors = function (dt, actors) {
    for (var n = 0; n < this.doorList.length; n++) {
      var d = this.doorList[n], i = d.i;
      if (d.st === 1) { this.dOpen[i] += dt * 2.2; if (this.dOpen[i] >= 1) { this.dOpen[i] = 1; d.st = 2; d.t = 0; } }
      else if (d.st === 2) {
        d.t += dt;
        if (d.t > 5) {
          var busy = false;
          for (var a = 0; a < actors.length; a++) { var A = actors[a]; if (Math.abs(A.x - d.x - 0.5) < 1 && Math.abs(A.y - d.y - 0.5) < 1) { busy = true; break; } }
          if (!busy) d.st = 3; else d.t = 3;
        }
      } else if (d.st === 3) { this.dOpen[i] -= dt * 2.2; if (this.dOpen[i] <= 0) { this.dOpen[i] = 0; d.st = 0; } }
      this.tex[i] = this.dOpen[i] >= 0.98 ? 0 : this.texBase[i];
    }
  };
  W.breakBarr = function (tx, ty) {
    var i = ty * this.w + tx;
    if (this.kind[i] !== K.BARR) return false;
    this.kind[i] = K.FLOOR; this.tex[i] = 0; this.special[i] = 0;
    this._buildCls();
    return true;
  };

  /* ---------- ruído ---------- */
  W.noise = function (x, y, rad, src, owner) {
    this.noises.push({ x: x, y: y, rad: rad, t: this.time, id: ++this.nid, src: src || 'misc', owner: owner || null });
    if (this.noises.length > 40) this.noises.shift();
  };

  /* ---------- navegação (classe de tamanho: 0 = 1 tile, 1 = 3x3 livre, 2 = 5x5 livre) ---------- */
  W._buildCls = function () {
    var w = this.w, h = this.h, x, y, i;
    var stat = function (self, tx, ty) {
      if (tx < 0 || ty < 0 || tx >= w || ty >= h) return true;
      var k = self.kind[ty * w + tx];
      return k === 1 || k === 3 || k === 5 || k === 6 || k === 7 || k === 8;
    };
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
      i = y * w + x;
      if (stat(this, x, y)) { this.cls[i] = 255; continue; }
      var c = 0;
      for (var r = 1; r <= 2; r++) {
        var ok = true;
        for (var dy = -r; dy <= r && ok; dy++) for (var dx = -r; dx <= r; dx++) if (stat(this, x + dx, y + dy)) { ok = false; break; }
        if (ok) c = r; else break;
      }
      this.cls[i] = c;
    }
  };
  W.passable = function (i, sp) {
    var c = this.cls[i];
    if (c === 255) return false;
    var k = this.kind[i];
    if (k === 2) {
      if (this.dOpen[i] >= 0.85) return sp.cls <= 0;
      var d = this.doors[i];
      return !d.lock && !!sp.opens && sp.cls <= 0;
    }
    if (k === 4) return !!sp.breaks;
    if (k !== 0) return false;
    return c >= sp.cls;
  };
  W.walkable = function (ax, ay, bx, by, r) {
    var dx = bx - ax, dy = by - ay, d = Math.sqrt(dx * dx + dy * dy), n = Math.ceil(d / 0.25);
    for (var s = 1; s < n; s++) { if (this.collides(ax + dx * s / n, ay + dy * s / n, r * 0.95)) return false; }
    return true;
  };
  W.findPath = function (sx, sy, gx, gy, sp) {
    var w = this.w, h = this.h, n = w * h;
    if (!this._gs) { this._gs = new Float32Array(n); this._par = new Int32Array(n); this._sm = new Int32Array(n); this._st = 0; this._hi = []; this._hf = []; }
    var st = ++this._st, gs = this._gs, par = this._par, sm = this._sm, hi = this._hi, hf = this._hf;
    var s = (sy | 0) * w + (sx | 0), gi = (gy | 0) * w + (gx | 0), GX = gi % w, GY = (gi / w) | 0;
    hi.length = 0; hf.length = 0;
    var DX = [1, -1, 0, 0, 1, 1, -1, -1], DY = [0, 0, 1, -1, 1, -1, 1, -1];
    function hh(i) { var dx = Math.abs((i % w) - GX), dy = Math.abs(((i / w) | 0) - GY); return (dx + dy) + (1.414 - 2) * Math.min(dx, dy); }
    function push(id, f) {
      var k = hi.length; hi.push(id); hf.push(f);
      while (k > 0) { var p = (k - 1) >> 1; if (hf[p] <= hf[k]) break; var ti = hi[p], tf = hf[p]; hi[p] = hi[k]; hf[p] = hf[k]; hi[k] = ti; hf[k] = tf; k = p; }
    }
    function pop() {
      var top = hi[0], li = hi.pop(), lf = hf.pop();
      if (hi.length) {
        hi[0] = li; hf[0] = lf; var k = 0, L = hi.length;
        for (;;) {
          var a = k * 2 + 1, b = a + 1, m = k;
          if (a < L && hf[a] < hf[m]) m = a; if (b < L && hf[b] < hf[m]) m = b;
          if (m === k) break;
          var ti = hi[m], tf = hf[m]; hi[m] = hi[k]; hf[m] = hf[k]; hi[k] = ti; hf[k] = tf; k = m;
        }
      }
      return top;
    }
    sm[s] = st; gs[s] = 0; par[s] = -1; push(s, hh(s));
    var best = s, bestH = hh(s), found = false, iter = 0, closed = new Set();
    while (hi.length && iter++ < 2500) {
      var cur = pop();
      if (closed.has(cur)) continue;
      closed.add(cur);
      if (cur === gi) { found = true; break; }
      var cx = cur % w, cy = (cur / w) | 0, ch = hh(cur);
      if (ch < bestH) { bestH = ch; best = cur; }
      for (var k = 0; k < 8; k++) {
        var nx = cx + DX[k], ny = cy + DY[k];
        if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
        var ni = ny * w + nx;
        if (!this.passable(ni, sp)) continue;
        if (k > 3 && (!this.passable(cy * w + nx, sp) || !this.passable(ny * w + cx, sp))) continue;
        var ng = gs[cur] + (k > 3 ? 1.414 : 1);
        if (sm[ni] !== st || ng < gs[ni]) { sm[ni] = st; gs[ni] = ng; par[ni] = cur; push(ni, ng + hh(ni)); }
      }
    }
    var end = found ? gi : best;
    this.pathPartial = !found;
    if (end === s) return found ? [] : null;
    var tiles = [], c2 = end;
    while (c2 !== s && c2 !== -1) { tiles.push(c2); c2 = par[c2]; }
    tiles.reverse();
    var pts = [], p, px = sx, py = sy;
    for (p = 0; p < tiles.length; p++) pts.push({ x: (tiles[p] % w) + 0.5, y: ((tiles[p] / w) | 0) + 0.5 });
    if (found) pts[pts.length - 1] = { x: gx, y: gy };
    /* suavização por linha de visão (anda em linha reta quando livre) */
    var out = [], ax = sx, ay = sy, idx = 0;
    while (idx < pts.length) {
      var far = idx;
      for (var q = pts.length - 1; q > idx; q--) { if (this.walkable(ax, ay, pts[q].x, pts[q].y, sp.r)) { far = q; break; } }
      out.push(pts[far]); ax = pts[far].x; ay = pts[far].y; idx = far + 1;
    }
    return out;
  };

  /* ---------- luz ---------- */
  W._buildLights = function () {
    var w = this.w, h = this.h, LW = w * 2, LH = h * 2, i, area = this.area;
    this.LW = LW; this.LH = LH;
    var amb = area.amb || [0.04, 0.045, 0.05];
    /* luzes automáticas de painéis (calculadas uma única vez) */
    if (!this._autoDone) { this._autoDone = true;
    for (i = 0; i < w * h; i++) {
      var k = this.kind[i], x = i % w, y = (i / w) | 0, d = this.doors[i];
      if (k === K.TERM) this.lights.push({ x: x + 0.5, y: y + 0.5, r: 0.1, g: 0.8, b: 0.65, rad: 3.6, I: 0.55, type: 0 });
      else if (k === K.LEVER) this.lights.push({ x: x + 0.5, y: y + 0.5, r: 1, g: 0.65, b: 0.2, rad: 3, I: 0.4, type: 0 });
      else if (k === K.EXIT) this.lights.push({ x: x + 0.5, y: y + 0.5, r: 0.2, g: 1, b: 0.5, rad: 4.2, I: 0.6, type: 0 });
      else if (d && d.ch !== '+') {
        var col = d.ch === '1' ? [0.25, 0.55, 1] : d.ch === '2' ? [1, 0.8, 0.15] : d.ch === '3' ? [1, 0.2, 0.15] : d.ch === 'C' ? [0.25, 1, 0.5] : d.ch === 'P' ? [1, 0.55, 0.12] : [1, 0.8, 0.2];
        this.lights.push({ x: x + 0.5, y: y + 0.5, r: col[0], g: col[1], b: col[2], rad: 2.8, I: 0.4, type: 0 });
      }
    }
    for (i = 0; i < this.ents.length; i++) {
      var e = this.ents[i];
      if (e.type === 'save') this.lights.push({ x: e.x, y: e.y, r: 1, g: 0.7, b: 0.25, rad: 5, I: 0.75, type: 0 });
    }
    for (i = 0; i < this.props.length; i++) {
      var pr = this.props[i];
      if (pr.spr === 'console') this.lights.push({ x: pr.x, y: pr.y, r: 0.2, g: 0.9, b: 0.7, rad: 3.4, I: 0.5, type: 0 });
    }
    }
    this.lmS = new Float32Array(LW * LH * 3);
    this.fl.length = 0;
    for (var li = 0; li < this.lights.length; li++) {
      var L = this.lights[li], R = L.rad, cx0 = Math.max(0, Math.floor((L.x - R) * 2)), cx1 = Math.min(LW - 1, Math.ceil((L.x + R) * 2));
      var cy0 = Math.max(0, Math.floor((L.y - R) * 2)), cy1 = Math.min(LH - 1, Math.ceil((L.y + R) * 2));
      var cells = [], vals = [];
      for (var cy = cy0; cy <= cy1; cy++) for (var cx = cx0; cx <= cx1; cx++) {
        var px = (cx + 0.5) / 2, py = (cy + 0.5) / 2, dd = Math.sqrt((px - L.x) * (px - L.x) + (py - L.y) * (py - L.y));
        if (dd > R) continue;
        var tx = cx >> 1, ty = cy >> 1, kk = this.kind[ty * w + tx];
        if (kk !== 0 && kk !== 8 && kk !== 2) continue;
        if (!this.los(L.x, L.y, px, py)) continue;
        var f = 1 - dd / R, v = L.I * f * f;
        cells.push(cy * LW + cx); vals.push(v);
      }
      if (L.type === 2 || L.type === 3) { L.cells = cells; L.vals = vals; this.fl.push(L); }
      else for (var q = 0; q < cells.length; q++) { var c3 = cells[q] * 3; this.lmS[c3] += vals[q] * L.r; this.lmS[c3 + 1] += vals[q] * L.g; this.lmS[c3 + 2] += vals[q] * L.b; }
    }
    for (i = 0; i < LW * LH; i++) { this.lmS[i * 3] += amb[0]; this.lmS[i * 3 + 1] += amb[1]; this.lmS[i * 3 + 2] += amb[2]; }
  };
  var lampFac = function (type, t, seed) {
    if (type === 1) return 1;
    if (type === 3) return 0.3 + 0.7 * (0.5 + 0.5 * Math.sin(t * 2.6 + seed));
    var q = Math.floor(t * 9 + seed), hq = LP.hash(q, seed, 1);
    if (((t * 0.11 + seed * 0.37) % 1) < 0.035) return 0.04;
    return hq < 0.16 ? 0.1 : hq < 0.28 ? 0.55 : 1;
  };
  W.updateLights = function (dt) {
    var lm = this.lm, k, q, t = this.time, mul = this.lightMul;
    lm.set(this.lmS);
    for (k = 0; k < this.fl.length; k++) {
      var L = this.fl[k], f = lampFac(L.type, t, L.seed) * mul;
      for (q = 0; q < L.cells.length; q++) { var c = L.cells[q] * 3, v = L.vals[q] * f; lm[c] += v * L.r; lm[c + 1] += v * L.g; lm[c + 2] += v * L.b; }
    }
    for (k = 0; k < this.lampList.length; k++) { var lp = this.lampList[k]; this.lampLvl[lp.i] = lampFac(lp.type, t, lp.seed) * mul; }
  };
  /* destrói luz difusa de áreas "apagadas" (evento de apagão): reduz todas as lâmpadas */
  W.update = function (dt, actors) {
    this.time += dt;
    this.updateDoors(dt, actors);
    this.updateLights(dt);
    if (this.noises.length && this.noises[0].t < this.time - 6) this.noises.shift();
  };
  W.lightAt = function (x, y) {
    var c = (((y * 2) | 0) * this.LW + ((x * 2) | 0)) * 3, lm = this.lm;
    if (c < 0 || c >= lm.length) return 0;
    return (lm[c] + lm[c + 1] + lm[c + 2]) / 3;
  };
  /* remove o objeto 3D de um item coletado e refaz a luz (o brilho do item some) */
  W.removeObj = function (e) {
    for (var i = 0; i < this.objs.length; i++) if (this.objs[i].ent === e) { var o = this.objs[i]; this.objAt[(o.y | 0) * this.w + (o.x | 0)] = 0; o.dead = true; break; }
    if (e.light) { var k = this.lights.indexOf(e.light); if (k >= 0) this.lights.splice(k, 1); e.light = null; this._buildLights(); this.lm.set(this.lmS); }
  };
  W.tileAt = function (x, y) { return this.kind[(y | 0) * this.w + (x | 0)]; };
})(typeof window !== 'undefined' ? window : globalThis);
