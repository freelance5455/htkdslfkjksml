/* Lost Prehistoria - raycaster por software. Paredes e portas em colunas; caixotes, barris, consoles, blocos e itens são
   objetos 3D (caixas/cilindros com laterais e TOPO), desenhados com perspectiva real. Dinossauros: sprites 2D. Suporta olhar vertical. */
(function (g) {
  'use strict';
  var LP = g.LP, R = LP.Render = {};
  var W = 0, H = 0, data = null, zbuf = null, flash = null, rdF = null, rdC = null, faF = null, faC = null, fgF = null, fgC = null, occD = null, occY0 = null, occY1 = null;
  var IH = 1.15; /* altura (em tiles) da parte "especial" das paredes: portas, painéis, armários */
  var TA = null, gHor = 0, gEye = 0, gProj = 1, gDens = 0, gRange = 14, gBr = 1, gFR = 0, gFG = 0, gFB = 0, gfR = 0, gfG = 0, gfB = 0, gLM = null, gLW = 0;
  var HP = [], HT0 = new Float32Array(12), HT1 = new Float32Array(12), HU = new Float32Array(12), HS = new Float32Array(12), HF = new Int8Array(12), ORD = new Int8Array(12), nh = 0;

  R.setup = function (w, h, buf32) {
    W = w; H = h; data = buf32;
    zbuf = new Float32Array(w); flash = new Float32Array(w * h); occD = new Float32Array(w); occY0 = new Int16Array(w); occY1 = new Int16Array(w);
    rdF = new Float32Array(h); rdC = new Float32Array(h); faF = new Float32Array(h); faC = new Float32Array(h); fgF = new Float32Array(h); fgC = new Float32Array(h);
    var cx = w / 2, cy = h * 0.54, ax = h * 0.9, ay = h * 0.66;
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) {
      var dx = (x - cx) / ax, dy = (y - cy) / ay, d = Math.sqrt(dx * dx + dy * dy);
      flash[y * w + x] = 1 - LP.smooth(0.1, 1, d);
    }
  };
  R.size = function () { return { w: W, h: H }; };
  function fa(d, range) { var a = 1 / (1 + 0.07 * d * d), k = 1 - d / range; return k <= 0 ? 0 : a * k; }

  /* trecho vertical texturizado (paredes e laterais de objetos) */
  function span(x, y0, y1, ta, tx, v, vs, lr, lg, lb, fat, fogF, fR, fG, fB, FR, FG, FB) {
    var mi = y0 * W + x, y;
    for (y = y0; y <= y1; y++, mi += W, v += vs) {
      var c = ta[(((v | 0) & 63) << 6) + tx], r, gg, b;
      if ((c >>> 24) === 254) { r = c & 255; gg = (c >> 8) & 255; b = (c >> 16) & 255; }
      else {
        var m = flash[mi] * fat;
        r = (c & 255) * (lr + m * FR) * fogF + fR * (1 + m * 1.6);
        gg = ((c >> 8) & 255) * (lg + m * FG) * fogF + fG * (1 + m * 1.6);
        b = ((c >> 16) & 255) * (lb + m * FB) * fogF + fB * (1 + m * 1.6);
      }
      data[mi] = 0xff000000 | ((b > 255 ? 255 : b) << 16) | ((gg > 255 ? 255 : gg) << 8) | (r > 255 ? 255 : r);
    }
  }

  /* ---- objetos 3D: interseção do raio com a caixa/cilindro de cada parte ---- */
  function collect(o, cx0, cy0, rdx, rdy, rlen) {
    var parts = o.parts, k, p, hx, hy;
    for (k = 0; k < parts.length && nh < 11; k++) {
      p = parts[k];
      if (p.cyl) {
        var ox = cx0 - p.cx, oy = cy0 - p.cy, a = rdx * rdx + rdy * rdy, b = ox * rdx + oy * rdy, c = ox * ox + oy * oy - p.r * p.r, disc = b * b - a * c;
        if (disc <= 0) continue;
        var sq = Math.sqrt(disc), t0 = (-b - sq) / a, t1 = (-b + sq) / a;
        if (t0 <= 0.03) continue;
        hx = cx0 + t0 * rdx - p.cx; hy = cy0 + t0 * rdy - p.cy;
        var fc = -(hx * rdx + hy * rdy) / (p.r * rlen);
        HP[nh] = p; HT0[nh] = t0; HT1[nh] = t1; HU[nh] = Math.atan2(hy, hx) * 0.15915494 + 0.5; HS[nh] = 0.55 + 0.45 * (fc > 0 ? fc : 0); HF[nh] = 0; nh++;
      } else {
        var ix = rdx !== 0 ? 1 / rdx : 1e30, iy = rdy !== 0 ? 1 / rdy : 1e30;
        var tx0 = (p.x0 - cx0) * ix, tx1 = (p.x1 - cx0) * ix, ty0 = (p.y0 - cy0) * iy, ty1 = (p.y1 - cy0) * iy;
        var txn = tx0 < tx1 ? tx0 : tx1, txf = tx0 < tx1 ? tx1 : tx0, tyn = ty0 < ty1 ? ty0 : ty1, tyf = ty0 < ty1 ? ty1 : ty0;
        var tn = txn > tyn ? txn : tyn, tf = txf < tyf ? txf : tyf;
        if (tn >= tf || tf <= 0 || tn <= 0.03) continue;
        hx = cx0 + tn * rdx; hy = cy0 + tn * rdy;
        HP[nh] = p; HT0[nh] = tn; HT1[nh] = tf;
        if (txn > tyn) { HF[nh] = rdx > 0 ? 1 : 0; HU[nh] = (hy - p.y0) / (p.y1 - p.y0); HS[nh] = 1; }
        else { HF[nh] = rdy > 0 ? 3 : 2; HU[nh] = (hx - p.x0) / (p.x1 - p.x0); HS[nh] = 0.8; }
        nh++;
      }
    }
  }
  function drawObjs(x, cx0, cy0, rdx, rdy, rlen) {
    var i, j, n = nh;
    for (i = 0; i < n; i++) ORD[i] = i;
    for (i = 1; i < n; i++) { var key = ORD[i]; j = i - 1; while (j >= 0 && HT0[ORD[j]] < HT0[key]) { ORD[j + 1] = ORD[j]; j--; } ORD[j + 1] = key; } /* do mais longe ao mais perto */
    var horizon = gHor, eye = gEye, proj = gProj;
    for (i = 0; i < n; i++) {
      var q = ORD[i], p = HP[q], d0 = HT0[q], d1 = HT1[q];
      var ysT = horizon - (p.z1 - eye) * proj / d0, ysB = horizon - (p.z0 - eye) * proj / d0;
      var fogF = Math.exp(-d0 * gDens), fat = fa(d0, gRange), ffR = gfR * (1 - fogF), ffG = gfG * (1 - fogF), ffB = gfB * (1 - fogF);
      var hx = cx0 + d0 * rdx - rdx / rlen * 0.07, hy = cy0 + d0 * rdy - rdy / rlen * 0.07;
      var li = ((((hy * 2) | 0) * gLW) + ((hx * 2) | 0)) * 3, sh = HS[q] * gBr;
      if (li < 0) li = 0;
      var lr = gLM[li] * sh, lg = gLM[li + 1] * sh, lb = gLM[li + 2] * sh;
      var top = Math.ceil(ysT), bot = Math.floor(ysB);
      /* topo (visível quando o olho está acima da caixa) */
      var k0 = eye - p.z1, yTopStart = top;
      if (k0 > 0.02) {
        var yFar = Math.ceil(horizon + k0 * proj / d1); yTopStart = yFar;
        var ya = yFar < 0 ? 0 : yFar, yb = top > H ? H : top, tt = TA[p.tT], cyl = p.cyl;
        for (var yy = ya; yy < yb; yy++) {
          var dist = k0 * proj / (yy - horizon), px = cx0 + dist * rdx, py = cy0 + dist * rdy, u, v;
          if (cyl) { u = 0.5 + (px - p.cx) / (2 * p.r); v = 0.5 + (py - p.cy) / (2 * p.r); } else { u = (px - p.x0) / (p.x1 - p.x0); v = (py - p.y0) / (p.y1 - p.y0); }
          var ui = (u * 64) | 0, vi = (v * 64) | 0; if (ui < 0) ui = 0; else if (ui > 63) ui = 63; if (vi < 0) vi = 0; else if (vi > 63) vi = 63;
          var c = tt[(vi << 6) + ui], mi = yy * W + x, r, gg, b;
          if ((c >>> 24) === 254) { r = c & 255; gg = (c >> 8) & 255; b = (c >> 16) & 255; }
          else {
            var l2 = (((py * 2) | 0) * gLW + ((px * 2) | 0)) * 3, f2 = Math.exp(-dist * gDens), m = flash[mi] * fa(dist, gRange), bb = gBr * 0.95;
            r = (c & 255) * (gLM[l2] * bb + m * gFR) * f2 + gfR * (1 - f2) * (1 + m * 1.6);
            gg = ((c >> 8) & 255) * (gLM[l2 + 1] * bb + m * gFG) * f2 + gfG * (1 - f2) * (1 + m * 1.6);
            b = ((c >> 16) & 255) * (gLM[l2 + 2] * bb + m * gFB) * f2 + gfB * (1 - f2) * (1 + m * 1.6);
          }
          data[mi] = 0xff000000 | ((b > 255 ? 255 : b) << 16) | ((gg > 255 ? 255 : gg) << 8) | (r > 255 ? 255 : r);
        }
      }
      /* lateral */
      var s0 = top < 0 ? 0 : top, s1 = bot > H - 1 ? H - 1 : bot;
      if (s1 >= s0 && ysB > ysT) {
        var vs = 64 / (ysB - ysT), tex = (p.faceTex && p.faceTex[HF[q]]) || p.tS, tx = ((HU[q] * 64) | 0) & 63;
        span(x, s0, s1, TA[tex], tx, (s0 - ysT) * vs, vs, lr, lg, lb, fat, fogF, ffR, ffG, ffB, gFR, gFG, gFB);
      }
      if (d0 < occD[x]) { occD[x] = d0; occY0[x] = yTopStart < top ? yTopStart : top; occY1[x] = bot; }
    }
  }

  /* quadro principal. cam={x,y,a,eyeH,hor(px),fov}; S={flash,range,bright,fog:[r,g,b],dens,wallH,time} */
  R.frame = function (world, cam, S, sprites) {
    TA = LP.Tex.ARR;
    var tiles = world.tex, kinds = world.kind, spec = world.special, dOpen = world.dOpen, lm = world.lm, LW = world.LW, objAt = world.objAt, objs = world.objs;
    var fov = cam.fov || 1.36, planeLen = Math.tan(fov / 2), proj = (W * 0.5) / planeLen;
    var dirX = Math.cos(cam.a), dirY = Math.sin(cam.a), plX = -dirY * planeLen, plY = dirX * planeLen;
    var eyeH = cam.eyeH, wallH = S.wallH, horizon = H * 0.5 + (cam.hor || 0), bright = S.bright || 1;
    var fR = S.fog[0], fG = S.fog[1], fB = S.fog[2], dens = S.dens, fl = S.flash, range = S.range || 14;
    var FR = 1.0 * fl, FG = 0.95 * fl, FB = 0.82 * fl;
    gHor = horizon; gEye = eyeH; gProj = proj; gDens = dens; gRange = range; gBr = bright; gFR = FR; gFG = FG; gFB = FB; gfR = fR; gfG = fG; gfB = fB; gLM = lm; gLW = LW;
    var ceilTex = TA[LP.Tex.ID[world.area.pal.ceil]], ftexArr = world.ftex, lampArr = world.lamp, lampLvl = world.lampLvl;
    var rep = Math.max(1, Math.round(wallH / IH)), sky = world.area.pal.ceil === 'c_sky', skyOff = ((S.time * 0.4) | 0) & 63, baseTex = TA[LP.Tex.ID[world.area.pal.wa]];
    var y, x;
    for (y = 0; y < H; y++) {
      var p = y - horizon;
      if (p > 0.5) { rdF[y] = eyeH * proj / p; var d1 = rdF[y]; faF[y] = fa(d1, range); fgF[y] = Math.exp(-d1 * dens); }
      else { rdF[y] = 1e9; faF[y] = 0; fgF[y] = 0; }
      var q = horizon - y;
      if (q > 0.5) { rdC[y] = (wallH - eyeH) * proj / q; var d2 = rdC[y]; faC[y] = fa(d2, range); fgC[y] = Math.exp(-d2 * dens); }
      else { rdC[y] = 1e9; faC[y] = 0; fgC[y] = 0; }
    }
    var mapW = world.w, mapH = world.h, cx0 = cam.x, cy0 = cam.y;
    for (x = 0; x < W; x++) {
      var camX = 2 * x / W - 1, rdx = dirX + plX * camX, rdy = dirY + plY * camX, rlen = Math.sqrt(rdx * rdx + rdy * rdy);
      var mx = cx0 | 0, my = cy0 | 0;
      var ddx = rdx === 0 ? 1e30 : Math.abs(1 / rdx), ddy = rdy === 0 ? 1e30 : Math.abs(1 / rdy);
      var stx, sty, sdx, sdy, side = 0, ti = 0, perp = 0, wx = 0, guard = 0, idx = 0;
      nh = 0; occD[x] = 1e9;
      if (rdx < 0) { stx = -1; sdx = (cx0 - mx) * ddx; } else { stx = 1; sdx = (mx + 1 - cx0) * ddx; }
      if (rdy < 0) { sty = -1; sdy = (cy0 - my) * ddy; } else { sty = 1; sdy = (my + 1 - cy0) * ddy; }
      for (;;) {
        if (sdx < sdy) { sdx += ddx; mx += stx; side = 0; } else { sdy += ddy; my += sty; side = 1; }
        if (mx < 0 || my < 0 || mx >= mapW || my >= mapH) { ti = 0; perp = 40; break; }
        idx = my * mapW + mx;
        if (objAt[idx]) collect(objs[objAt[idx] - 1], cx0, cy0, rdx, rdy, rlen);
        ti = tiles[idx];
        if (ti) {
          perp = side === 0 ? sdx - ddx : sdy - ddy;
          wx = side === 0 ? cy0 + perp * rdy : cx0 + perp * rdx; wx -= Math.floor(wx);
          if (kinds[idx] === 2 && dOpen[idx] > 0) { if (wx < dOpen[idx]) { ti = 0; if (++guard > 40) break; continue; } wx -= dOpen[idx]; }
          break;
        }
        if (++guard > 80) { perp = 40; break; }
      }
      if (perp < 0.05) perp = 0.05;
      zbuf[x] = perp;
      var top = horizon - (wallH - eyeH) * proj / perp, bot = horizon + eyeH * proj / perp;
      var y0 = Math.ceil(top), y1 = Math.floor(bot);
      if (y0 < 0) y0 = 0; if (y1 > H - 1) y1 = H - 1;
      var wfog = Math.exp(-perp * dens), wfa = fa(perp, range);
      /* parede */
      if (ti && y1 >= y0) {
        var hx = cx0 + perp * rdx, hy = cy0 + perp * rdy;
        var lx = ((hx - rdx / rlen * 0.14) * 2) | 0, ly = ((hy - rdy / rlen * 0.14) * 2) | 0;
        if (lx < 0) lx = 0; if (ly < 0) ly = 0; if (lx >= LW) lx = LW - 1; if (ly >= world.LH) ly = world.LH - 1;
        var lc = (ly * LW + lx) * 3, sh = (side ? 0.8 : 1) * bright;
        var lr = lm[lc] * sh, lg = lm[lc + 1] * sh, lb = lm[lc + 2] * sh;
        var tx = (wx * 64) | 0; if ((side === 0 && rdx > 0) || (side === 1 && rdy < 0)) tx = 63 - tx;
        var ffR = fR * (1 - wfog), ffG = fG * (1 - wfog), ffB = fB * (1 - wfog), tcol = TA[ti], height = bot - top;
        if (spec[idx] && wallH > IH + 0.05) {
          var top2 = bot - IH * proj / perp, vs2 = 64 / (bot - top2), s0 = Math.max(y0, Math.ceil(top2));
          if (y1 >= s0) span(x, s0, y1, tcol, tx, (s0 - top2) * vs2, vs2, lr, lg, lb, wfa, wfog, ffR, ffG, ffB, FR, FG, FB);
          var ub = Math.min(y1, Math.floor(top2) - 1);
          if (ub >= y0) {
            var rep2 = Math.max(1, Math.round((wallH - IH) / IH)), vs3 = 64 * rep2 / (top2 - top);
            span(x, y0, ub, baseTex, tx, (y0 - top) * vs3, vs3, lr, lg, lb, wfa, wfog, ffR, ffG, ffB, FR, FG, FB);
          }
        } else {
          var r2 = spec[idx] ? 1 : rep, vs4 = 64 * r2 / height;
          span(x, y0, y1, tcol, tx, (y0 - top) * vs4, vs4, lr, lg, lb, wfa, wfog, ffR, ffG, ffB, FR, FG, FB);
        }
      }
      var yt = ti ? y0 : Math.floor(horizon), yb2 = ti ? y1 + 1 : Math.floor(horizon) + 1;
      /* teto */
      var yc, mi;
      for (yc = 0, mi = x; yc < yt && yc < H; yc++, mi += W) {
        var dd = rdC[yc]; if (dd > 60) { data[mi] = 0xff000000 | (fB << 16) | (fG << 8) | fR; continue; }
        var px = cx0 + dd * rdx, py = cy0 + dd * rdy, tix = px | 0, tiy = py | 0, ti2 = tiy * mapW + tix;
        var lcl = lampArr[ti2];
        if (lcl) {
          var ax = px - tix - 0.5, ay = py - tiy - 0.5;
          if (ax < 0.2 && ax > -0.2 && ay < 0.1 && ay > -0.1) {
            var lv = lampLvl[ti2];
            data[mi] = lcl === 3 ? (0xff000000 | (((28 * lv) | 0) << 16) | (((40 * lv) | 0) << 8) | ((255 * lv) | 0)) : (0xff000000 | (((255 * lv) | 0) << 16) | (((250 * lv) | 0) << 8) | ((235 * lv) | 0));
            continue;
          }
        }
        var fg2 = fgC[yc], m2 = flash[mi] * faC[yc];
        var cp = sky ? ceilTex[((((py * 64) | 0) + skyOff) & 63) * 64 + (((px * 64) | 0) & 63)] : ceilTex[(((py - tiy) * 64 | 0) << 6) + (((px - tix) * 64) | 0)];
        var li = (((py * 2) | 0) * LW + ((px * 2) | 0)) * 3, sb = bright * 0.8;
        var r3 = (cp & 255) * (lm[li] * sb + m2 * FR) * fg2 + fR * (1 - fg2) * (1 + m2 * 1.6);
        var g3 = ((cp >> 8) & 255) * (lm[li + 1] * sb + m2 * FG) * fg2 + fG * (1 - fg2) * (1 + m2 * 1.6);
        var b3 = ((cp >> 16) & 255) * (lm[li + 2] * sb + m2 * FB) * fg2 + fB * (1 - fg2) * (1 + m2 * 1.6);
        data[mi] = 0xff000000 | ((b3 > 255 ? 255 : b3) << 16) | ((g3 > 255 ? 255 : g3) << 8) | (r3 > 255 ? 255 : r3);
      }
      /* piso */
      var ys = yb2 < 0 ? 0 : yb2;
      for (yc = ys, mi = ys * W + x; yc < H; yc++, mi += W) {
        var df = rdF[yc]; if (df > 60) { data[mi] = 0xff000000 | (fB << 16) | (fG << 8) | fR; continue; }
        var fx = cx0 + df * rdx, fy = cy0 + df * rdy, ftx = fx | 0, fty = fy | 0, fti = fty * mapW + ftx;
        var fc = TA[ftexArr[fti]][(((fy - fty) * 64 | 0) << 6) + (((fx - ftx) * 64) | 0)];
        var li2 = (((fy * 2) | 0) * LW + ((fx * 2) | 0)) * 3, fg3 = fgF[yc], m3 = flash[mi] * faF[yc];
        var r4 = (fc & 255) * (lm[li2] * bright + m3 * FR) * fg3 + fR * (1 - fg3) * (1 + m3 * 1.6);
        var g4 = ((fc >> 8) & 255) * (lm[li2 + 1] * bright + m3 * FG) * fg3 + fG * (1 - fg3) * (1 + m3 * 1.6);
        var b4 = ((fc >> 16) & 255) * (lm[li2 + 2] * bright + m3 * FB) * fg3 + fB * (1 - fg3) * (1 + m3 * 1.6);
        data[mi] = 0xff000000 | ((b4 > 255 ? 255 : b4) << 16) | ((g4 > 255 ? 255 : g4) << 8) | (r4 > 255 ? 255 : r4);
      }
      if (!ti) { for (yc = yt; yc < yb2 && yc < H; yc++) { if (yc >= 0) data[yc * W + x] = 0xff000000 | (fB << 16) | (fG << 8) | fR; } }
      if (nh) drawObjs(x, cx0, cy0, rdx, rdy, rlen);
    }
    /* sprites 2D (dinossauros, projéteis, decoração), do mais distante ao mais próximo */
    if (sprites && sprites.length) {
      var n = sprites.length, i, j;
      for (i = 0; i < n; i++) { var s0 = sprites[i], ddx2 = s0.x - cx0, ddy2 = s0.y - cy0; s0.d2 = ddx2 * ddx2 + ddy2 * ddy2; }
      for (i = 1; i < n; i++) { var key = sprites[i]; j = i - 1; while (j >= 0 && sprites[j].d2 < key.d2) { sprites[j + 1] = sprites[j]; j--; } sprites[j + 1] = key; }
      var inv = 1 / (plX * dirY - dirX * plY);
      for (i = 0; i < n; i++) {
        var sp = sprites[i], img = sp.img; if (!img) continue;
        var dx = sp.x - cx0, dy = sp.y - cy0, tX = inv * (dirY * dx - dirX * dy), tY = inv * (-plY * dx + plX * dy);
        if (tY < 0.15) continue;
        var scrX = (W / 2) * (1 + tX / tY), sH = proj * sp.sh / tY, sW = proj * sp.sw / tY;
        var floorY = horizon + (eyeH - (sp.lift || 0)) * proj / tY, topY = floorY - sH;
        var sx0 = Math.round(scrX - sW / 2), sx1 = Math.round(scrX + sW / 2), sy0 = Math.round(topY), sy1 = Math.round(floorY) - 1;
        if (sx1 < 0 || sx0 >= W || sy1 < 0 || sy0 >= H || sx1 <= sx0 || sy1 <= sy0) continue;
        var lcs = (((sp.y * 2) | 0) * LW + ((sp.x * 2) | 0)) * 3, dim = sp.dim === undefined ? 1 : sp.dim;
        var sfog = Math.exp(-tY * dens), sfa = fa(tY, range) * dim, sbr = bright * dim;
        var slr = lm[lcs] * sbr, slg = lm[lcs + 1] * sbr, slb = lm[lcs + 2] * sbr, sfR = fR * (1 - sfog), sfG = fG * (1 - sfog), sfB = fB * (1 - sfog);
        var iw = img.w, ih = img.h, id = img.d, cxa = Math.max(0, sx0), cxb = Math.min(W - 1, sx1 - 1), cya = Math.max(0, sy0), cyb = Math.min(H - 1, sy1);
        var inW = 1 / (sx1 - sx0), inH = 1 / (sy1 - sy0 + 1), emi = sp.emis === undefined ? 1 : sp.emis, tint = sp.tint;
        for (var cx = cxa; cx <= cxb; cx++) {
          if (tY >= zbuf[cx]) continue;
          var u = ((cx - sx0 + 0.5) * inW * iw) | 0; if (sp.mirror) u = iw - 1 - u;
          var mi2 = cya * W + cx, hasOcc = occD[cx] < tY, o0 = occY0[cx], o1 = occY1[cx];
          for (var cy = cya; cy <= cyb; cy++, mi2 += W) {
            if (hasOcc && cy >= o0 && cy <= o1) continue;
            var v = ((cy - sy0 + 0.5) * inH * ih) | 0, c = id[v * iw + u], a = c >>> 24;
            if (a === 0) continue;
            var r5, g5, b5;
            if (a === 254) { r5 = (c & 255) * emi * (0.55 + 0.45 * sfog) + sfR * 0.4; g5 = ((c >> 8) & 255) * emi * (0.55 + 0.45 * sfog) + sfG * 0.4; b5 = ((c >> 16) & 255) * emi * (0.55 + 0.45 * sfog) + sfB * 0.4; }
            else {
              var m5 = flash[mi2] * sfa;
              r5 = (c & 255) * (slr + m5 * FR) * sfog + sfR * (1 + m5 * 1.6);
              g5 = ((c >> 8) & 255) * (slg + m5 * FG) * sfog + sfG * (1 + m5 * 1.6);
              b5 = ((c >> 16) & 255) * (slb + m5 * FB) * sfog + sfB * (1 + m5 * 1.6);
            }
            if (tint) { r5 = r5 * tint[0] + tint[3]; g5 = g5 * tint[1]; b5 = b5 * tint[2]; }
            data[mi2] = 0xff000000 | ((b5 > 255 ? 255 : b5) << 16) | ((g5 > 255 ? 255 : g5) << 8) | (r5 > 255 ? 255 : r5);
          }
        }
      }
    }
  };
  R.zAt = function (x) { return zbuf[x]; };
})(typeof window !== 'undefined' ? window : globalThis);
