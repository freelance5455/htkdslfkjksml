const load = require('./load'), png = require('./png');
const LP = load(['util', 'art']);
const names = process.argv.slice(2).length ? process.argv.slice(2) : Object.keys(LP.Art.SPEC);
for (const n of names) {
  const t0 = Date.now(), sh = LP.Art.makeDino(n).all(), ms = Date.now() - t0;
  let cnt = 0, bytes = 0; for (const a in sh.frames) for (const f of sh.frames[a]) for (const v of f) { cnt++; bytes += v.d.length * 4; }
  console.log(n, 'gerado em', ms, 'ms;', cnt, 'sprites;', (bytes / 1048576).toFixed(1), 'MB');
  const rows = [['walk', 1], ['walk', 4], ['run', 2], ['idle', 0], ['alert', 1], ['attack', 1]];
  const P = LP.Art.SPEC[n], cw = P.cw, ch = P.ch, S = 2, W = cw * 5 * S, H = ch * rows.length * S, buf = Buffer.alloc(W * H * 4);
  for (let i = 0; i < W * H; i++) { const y = (i / W) | 0; buf[i * 4] = 28 + y * 0.01; buf[i * 4 + 1] = 32; buf[i * 4 + 2] = 38; buf[i * 4 + 3] = 255; }
  rows.forEach((r, ri) => {
    for (let v = 0; v < 5; v++) {
      const img = sh.frames[r[0]][r[1]][v];
      for (let y = 0; y < ch; y++) for (let x = 0; x < cw; x++) {
        const c = img.d[y * cw + x]; if (!(c >>> 24)) continue;
        for (let sy = 0; sy < S; sy++) for (let sx = 0; sx < S; sx++) {
          const o = ((ri * ch + y) * S + sy) * W * 4 + ((v * cw + x) * S + sx) * 4;
          buf[o] = c & 255; buf[o + 1] = (c >> 8) & 255; buf[o + 2] = (c >> 16) & 255; buf[o + 3] = 255;
        }
      }
    }
  });
  png('/tmp/art_' + n + '.png', W, H, buf);
}
