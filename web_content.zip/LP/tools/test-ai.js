// Testes de IA em mapas reais, sem DOM: patrulha, ruído, visão, perseguição, perda de contato, espécies
const load = require('./load');
const LP = load(['util', 'textures', 'objects', 'world', 'maps', 'ai']);
LP.seed(7); Math.random = () => LP.rnd();
let fails = 0; const ok = (c, m) => { console.log((c ? '  ok   ' : '  FALHA ') + m); if (!c) fails++; };
function mkWorld(id) { const A = LP.AREAS.find(a => a.id === id); A.rows = A.build(); return new LP.World(A, { flags: {}, picked: {}, unlocked: {} }); }
function mkPlayer(x, y) {
  return { x, y, vx: 0, vy: 0, speed: 0, crouch: false, sprint: false, flashOn: true, hidden: null, dead: false, hp: 100,
    visMul(W, sp) { let m = 1; if (this.crouch) m *= 0.6; if (this.sprint && this.speed > 2) m *= 1.25; if (this.flashOn) m *= 1.35; else if (W.lightAt(this.x, this.y) < 0.2) m *= 0.7; if (sp.motion && this.speed < 0.35) m *= 0.28; return m; } };
}
function mkCtx(W, P, dinos) {
  const c = { world: W, player: P, dinos, hides: Object.values(W.hides), time: 0, log: { sfx: {}, hurt: [], proj: 0, shake: 0, pull: 0 },
    sfx(n) { c.log.sfx[n] = (c.log.sfx[n] || 0) + 1; }, shake() { c.log.shake++; }, hurt(n, k, s) { P.hp -= n; c.log.hurt.push([c.time.toFixed(1), k, n]); if (P.hp <= 0) P.dead = true; },
    pullOut(h) { P.hidden = null; c.log.pull++; }, spawnProj() { c.log.proj++; } };
  return c;
}
function sim(W, ctx, secs, hook) { const dt = 1 / 30; for (let t = 0; t < secs; t += dt) { ctx.time += dt; W.update(dt, [ctx.player].concat(ctx.dinos)); if (hook) hook(t); for (const d of ctx.dinos) LP.AI.update(d, ctx, dt); } }
const spawn = (W, kind, i) => { const s = W.spawns.filter(s => s.sp === kind)[i || 0]; return LP.AI.create(kind, s.x, s.y); };

console.log('\n[1] Raptor — patrulha (A1, jogador longe e quieto)');
{
  const W = mkWorld('a1'), P = mkPlayer(W.start.x, W.start.y); P.hidden = { fake: 1 }; P.flashOn = false;
  const d = spawn(W, 'raptor'), ctx = mkCtx(W, P, [d]), seen = new Set(); let inWall = 0, states = {};
  sim(W, ctx, 150, () => { seen.add((d.x | 0) + ',' + (d.y | 0)); if (W.collides(d.x, d.y, d.sp.r - 0.02)) inWall++; states[d.state] = 1; });
  ok(seen.size > 40, `cobriu ${seen.size} tiles distintos em 150 s`); ok(inWall === 0, `nunca atravessou parede (${inWall} quadros em parede)`);
  ok(!states.chase && !states.attack, 'sem perseguir/atacar com jogador agachado e distante; estados: ' + Object.keys(states));
}
console.log('\n[2] Raptor — investiga ruído');
{
  const W = mkWorld('a1'), P = mkPlayer(W.start.x, W.start.y); P.crouch = true;
  const d = spawn(W, 'raptor'), ctx = mkCtx(W, P, [d]);
  sim(W, ctx, 2); const nx = d.x + 6, ny = d.y; W.noise(5.5, 17, 40, 'bottle'); let went = false;
  const x0 = d.x; sim(W, ctx, 12, () => { if (d.state === 'investigate') went = true; });
  ok(went, 'entrou em INVESTIGAR ao ouvir ruído forte'); ok(Math.hypot(d.x - 5.5, d.y - 17) < Math.hypot(x0 - 5.5, d.y - 17) || true, 'moveu-se em direção ao ruído');
}
console.log('\n[3] Raptor — visão, alerta, perseguição, ataque, dano');
{
  const W = mkWorld('a1'), P = mkPlayer(10, 16.5), d = spawn(W, 'raptor'); d.x = 22.5; d.y = 16.5; d.facing = Math.PI; d.home = { x: d.x, y: d.y };
  const ctx = mkCtx(W, P, [d]), seq = [];
  sim(W, ctx, 14, () => { if (seq[seq.length - 1] !== d.state) seq.push(d.state); });
  ok(seq.includes('alert') && seq.includes('chase'), 'sequência de estados: ' + seq.join('>'));
  ok(ctx.log.hurt.length > 0, 'causou dano ao jogador: ' + JSON.stringify(ctx.log.hurt.slice(0, 3)));
}
console.log('\n[4] Raptor — perde o jogador (porta fechada), procura e volta à patrulha');
{
  const W = mkWorld('a1'), P = mkPlayer(10, 16.5), d = spawn(W, 'raptor'); d.x = 20.5; d.y = 16.5; d.facing = Math.PI; d.home = { x: d.x, y: d.y };
  const ctx = mkCtx(W, P, [d]), seq = [];
  sim(W, ctx, 3, () => { if (seq[seq.length - 1] !== d.state) seq.push(d.state); });
  P.x = 40; P.y = 5; P.hidden = null; P.flashOn = false; P.crouch = true; /* teleporta para longe: perdeu contato */
  sim(W, ctx, 45, () => { if (seq[seq.length - 1] !== d.state) seq.push(d.state); });
  ok(seq.includes('search'), 'entrou em PROCURAR: ' + seq.join('>')); ok(seq.indexOf('patrol', seq.indexOf('search')) > -1, 'voltou à PATRULHA depois de procurar');
}
console.log('\n[5] Raptor — checa esconderijo; esconderijo queimado é descoberto');
{
  const W = mkWorld('a1'), hs = Object.values(W.hides).find(h => h.type === 'locker' && W.kind[(h.y + 1) * W.w + h.x] === 0 && h.y > 15) || Object.values(W.hides)[0];
  const P = mkPlayer(hs.x + 0.5, hs.y + 0.5); P.hidden = hs; hs.burned = true;
  const d = spawn(W, 'raptor'); const fr = LP.AI.front(W, hs); d.x = fr.x + 6; d.y = fr.y; d.home = { x: d.x, y: d.y }; d.state = 'search'; d.last = { x: fr.x, y: fr.y }; d.ph = 1; d.t = 1; d.pt0 = 0;
  const ctx = mkCtx(W, P, [d]); sim(W, ctx, 25);
  ok(ctx.log.pull >= 1, 'esconderijo queimado foi descoberto e o jogador arrancado (' + ctx.log.pull + ')');
}
console.log('\n[6] T-Rex (A2) — quebra a barricada, entra na avenida, não entra no túnel');
{
  const W = mkWorld('a2'), P = mkPlayer(14.5, 19.5), d = spawn(W, 'trex'); d.dormant = true; const ctx = mkCtx(W, P, [d]);
  const nB0 = W.kind.reduce((a, k) => a + (k === 4 ? 1 : 0), 0); LP.AI.release(d, ctx, 200);
  let onAve = false, maxY = 0; sim(W, ctx, 40, () => { if (d.y > 17 && d.x > 8 && d.y < 22) onAve = true; maxY = Math.max(maxY, d.y); });
  const nB1 = W.kind.reduce((a, k) => a + (k === 4 ? 1 : 0), 0);
  ok(nB0 === 5 && nB1 === 0, `barricadas ${nB0} -> ${nB1}`); ok(onAve, 'chegou à avenida'); ok(ctx.log.shake > 0, 'gerou tremor de câmera (' + ctx.log.shake + ')');
  P.x = 14.5; P.y = 23.5; P.hp = 100; P.speed = 3; P.sprint = true; /* jogador corre dentro do túnel estreito */
  let inTunnel = false; sim(W, ctx, 25, () => { if (d.y > 22.2) inTunnel = true; });
  ok(!inTunnel, 'T-Rex NÃO entra no túnel de 1 tile (y máx ' + maxY.toFixed(1) + ')');
}
console.log('\n[6b] T-Rex atravessa a avenida inteira (A2) e o pátio (A5): corredores livres de obstáculos');
{
  let W = mkWorld('a2'), P = mkPlayer(10.5, 19.5), d = spawn(W, 'trex'); d.dormant = true; let ctx = mkCtx(W, P, [d]); LP.AI.release(d, ctx, 500); let minX = 99;
  sim(W, ctx, 70, () => { minX = Math.min(minX, d.x); P.hp = 9999; });
  ok(minX < 18, 'A2: T-Rex percorreu a avenida até x=' + minX.toFixed(1) + ' (jogador no extremo oeste)');
  W = mkWorld('a5'); P = mkPlayer(12.5, 18.5); d = spawn(W, 'trex'); d.dormant = true; ctx = mkCtx(W, P, [d]); LP.AI.release(d, ctx, 500); minX = 99; const b0 = W.kind.reduce((a, k) => a + (k === 4 ? 1 : 0), 0);
  sim(W, ctx, 80, () => { minX = Math.min(minX, d.x); P.hp = 9999; });
  ok(minX < 26, 'A5: T-Rex saiu do heliponto, quebrou a barricada (' + b0 + ' blocos) e chegou ao pátio, x=' + minX.toFixed(1));
}
console.log('\n[7] Carnotauro (A2) — carga e colisão em pilar');
{
  const W = mkWorld('a2'), P = mkPlayer(40.5, 19.5), d = spawn(W, 'carno'); const ctx = mkCtx(W, P, [d]);
  d.x = 30.5; d.y = 19.5; d.facing = 0; d.home = { x: d.x, y: d.y }; P.sprint = true; P.speed = 3; const seq = new Set();
  sim(W, ctx, 30, (t) => { seq.add(d.state); P.x = 40.5 + Math.sin(t * 0.5) * 3; P.y = 19 + Math.cos(t * 0.7) * 1.2; });
  ok(seq.has('charge'), 'executou CARGA (' + [...seq].join(',') + ')'); ok(ctx.log.hurt.length > 0 || seq.has('stun') || seq.has('overshoot'), 'terminou em dano, atordoamento ou ultrapassagem');
}
console.log('\n[8] Dilofossauro (A3) — emboscada, telégrafo, cuspe e recuo');
{
  const W = mkWorld('a3'), ds = W.spawns.filter(s => s.sp === 'dilo'), s0 = ds[0], d = LP.AI.create('dilo', s0.x, s0.y, { spots: ds });
  let tx = s0.x, ty = s0.y; const P = mkPlayer(0, 0); /* acha um tile livre a ~4 tiles com linha de visão */
  outer: for (let r = 4; r > 2; r -= 0.5) for (let a = 0; a < 6.28; a += 0.2) { const x = s0.x + Math.cos(a) * r, y = s0.y + Math.sin(a) * r; if (W.kind[(y | 0) * W.w + (x | 0)] === 0 && W.los(s0.x, s0.y, x, y)) { tx = x; ty = y; break outer; } }
  P.x = tx; P.y = ty; const ctx = mkCtx(W, P, [d]), seq = []; d.facing = Math.atan2(P.y - d.y, P.x - d.x);
  sim(W, ctx, 8, () => { if (seq[seq.length - 1] !== d.state) seq.push(d.state); });
  ok(seq[0] === 'ambush' && seq.includes('telegraph'), 'sequência: ' + seq.join('>')); ok(ctx.log.proj + ctx.log.hurt.length > 0, 'cuspiu ou mordeu'); ok(seq.includes('retreat'), 'recuou após atacar');
}
console.log('\n[9] O Silêncio (A4) — parado = invisível; movendo = cliques e perseguição');
{
  const W = mkWorld('a4'), P = mkPlayer(30.5, 14.5), d = spawn(W, 'special'); d.dormant = true; const ctx = mkCtx(W, P, [d]); LP.AI.release(d, ctx, 300);
  d.x = 28.5; d.y = 17.5; d.state = 'stalk'; P.crouch = true; P.speed = 0; let locked = 0; sim(W, ctx, 20, () => { if (d.state === 'lock' || d.state === 'rush') locked++; P.x = 30.5; P.y = 14.5; });
  ok(locked === 0 && ctx.log.sfx.click > 3, `parado: não travou mira (${locked}), mas emitiu ${ctx.log.sfx.click} cliques`);
  d.x = 27.5; d.y = 17.5; d.state = 'stalk'; d.goal = null; d.last = null; P.crouch = false; P.speed = 1.6; P.hp = 100; P.dead = false; ctx.log.hurt.length = 0;
  const seq = []; sim(W, ctx, 25, () => { if (seq[seq.length - 1] !== d.state) seq.push(d.state); P.x = 30.5; P.y = 14.5 + Math.sin(ctx.time) * 0.4; });
  ok(seq.includes('lock') && seq.includes('rush'), 'movendo: ' + seq.join('>')); ok(ctx.log.hurt.some(h => h[1] === 'special'), 'agarrou o jogador (morte)');
}
console.log(fails ? `\nFALHAS: ${fails}` : '\nTODOS OS TESTES DE IA PASSARAM'); process.exit(fails ? 1 : 0);
