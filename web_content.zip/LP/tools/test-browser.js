// Teste no Chromium headless (viewport do Galaxy A15 em paisagem, toque habilitado): menus, jogo, toque multi-dedo, desempenho, áudio
const { chromium } = require('playwright');
const path = require('path'), url = 'file://' + path.resolve(__dirname, '../app/src/main/assets/www/index.html');
let fails = 0; const ok = (c, m) => { console.log((c ? '  ok   ' : '  FALHA ') + m); if (!c) fails++; };
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=swiftshader', '--autoplay-policy=no-user-gesture-required'] });
  const ctx = await browser.newContext({ viewport: { width: 832, height: 385 }, deviceScaleFactor: 1, hasTouch: true, isMobile: true, userAgent: 'Mozilla/5.0 (Linux; Android 14; SM-A155M) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36' });
  const page = await ctx.newPage(), errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.goto(url); await page.waitForFunction(() => window.LP && LP.G && LP.G.get().state === 'title', null, { timeout: 15000 });
  await page.waitForTimeout(1200); await page.screenshot({ path: '/tmp/shot_title.png' });
  ok(true, 'título carregou');
  await page.click('#mNew'); await page.waitForFunction(() => LP.G.get().state === 'play', null, { timeout: 30000 });
  await page.waitForTimeout(1500); await page.screenshot({ path: '/tmp/shot_play1.png' });
  const g0 = await page.evaluate(() => { const s = LP.G.get(); return { x: s.P.x, y: s.P.y, a: s.P.a, ema: s.ema, RW: s.RW, RH: s.RH, err: LP.G.lastError && LP.G.lastError.message }; });
  ok(!g0.err, 'sem exceção no loop: ' + g0.err); console.log('  resolução interna', g0.RW + 'x' + g0.RH, 'ms/quadro (CPU de servidor, sem GPU):', g0.ema.toFixed(1));
  /* toque multi-dedo via CDP: joystick esquerdo para frente + arrasto de olhar à direita */
  const cdp = await ctx.newCDPSession(page);
  const touch = (type, pts) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: pts.map((p, i) => ({ x: p[0], y: p[1], id: p[2] === undefined ? i : p[2] })) });
  await touch('touchStart', [[120, 280, 0]]); await touch('touchMove', [[120, 230, 0]]); await page.waitForTimeout(1600);
  const g1 = await page.evaluate(() => { const s = LP.G.get(); return { x: s.P.x, y: s.P.y, a: s.P.a, sprint: s.P.sprint, mag: s.P.mag }; });
  ok(Math.hypot(g1.x - g0.x, g1.y - g0.y) > 1.0, `joystick andou ${Math.hypot(g1.x - g0.x, g1.y - g0.y).toFixed(2)} tiles (sprint=${g1.sprint})`);
  await touch('touchStart', [[120, 230, 0], [600, 200, 1]]); await touch('touchMove', [[120, 230, 0], [680, 200, 1]]); await touch('touchEnd', [[600, 200, 1]]); await page.waitForTimeout(200);
  const g2 = await page.evaluate(() => LP.G.get().P.a); ok(Math.abs(g2 - g1.a) > 0.15, `arrastar à direita girou a câmera ${(g2 - g1.a).toFixed(2)} rad com o joystick ativo (multitoque)`);
  await touch('touchEnd', [[120, 230, 0]]);
  /* olhar vertical por arrasto (cima = olhar para cima) e opção de inverter */
  const pv0 = await page.evaluate(() => LP.G.get().P.pitch);
  await touch('touchStart', [[600, 220, 1]]); await touch('touchMove', [[600, 130, 1]]); await touch('touchEnd', [[600, 130, 1]]); await page.waitForTimeout(200);
  const pv1 = await page.evaluate(() => LP.G.get().P.pitch); ok(pv1 - pv0 > 0.1, `arrastar para cima olhou para cima (pitch ${pv0.toFixed(2)} → ${pv1.toFixed(2)})`);
  await touch('touchStart', [[600, 120, 1]]); await touch('touchMove', [[600, 300, 1]]); await touch('touchEnd', [[600, 300, 1]]); await page.waitForTimeout(200);
  const pv2 = await page.evaluate(() => LP.G.get().P.pitch); ok(pv2 < pv1 - 0.2, `arrastar para baixo olhou para baixo (pitch ${pv2.toFixed(2)})`);
  await page.evaluate(() => { LP.G.get().settings.invY = 1; LP.In.invY = true; });
  await touch('touchStart', [[600, 220, 1]]); await touch('touchMove', [[600, 130, 1]]); await touch('touchEnd', [[600, 130, 1]]); await page.waitForTimeout(200);
  const pv3 = await page.evaluate(() => LP.G.get().P.pitch); ok(pv3 < pv2, `com "inverter olhar vertical", arrastar para cima olha para baixo (${pv3.toFixed(2)})`);
  await page.evaluate(() => { LP.G.get().settings.invY = 0; LP.In.invY = false; LP.G.get().P.pitch = 0; });
  await page.keyboard.down('KeyZ'); await page.waitForTimeout(300); await page.keyboard.up('KeyZ'); ok(await page.evaluate(() => LP.G.get().P.pitch) > 0.05, 'teclado Z olha para cima'); await page.evaluate(() => { LP.G.get().P.pitch = 0; });
  /* botões de toque */
  const tapBtn = async sel => { const b = await page.locator(sel).boundingBox(); await touch('touchStart', [[b.x + b.width / 2, b.y + b.height / 2, 5]]); await touch('touchEnd', [[b.x + b.width / 2, b.y + b.height / 2, 5]]); await page.waitForTimeout(150); };
  const f0 = await page.evaluate(() => LP.G.get().P.flashOn); await tapBtn('#bFlash'); const f1 = await page.evaluate(() => LP.G.get().P.flashOn); ok(f0 !== f1, 'botão Lanterna alterna (' + f0 + '→' + f1 + ')');
  await tapBtn('#bFlash');
  await tapBtn('#bCrouch'); ok(await page.evaluate(() => LP.G.get().P.crouch), 'botão Agachar ativa'); await tapBtn('#bCrouch');
  await tapBtn('.btn.pause'); await page.waitForTimeout(200); ok(await page.evaluate(() => LP.G.get().state) === 'pause', 'botão Pausa abre o menu'); await page.screenshot({ path: '/tmp/shot_pause.png' });
  await page.click('#pRes'); await page.waitForTimeout(200);
  /* áudio: renderização offline de cada voz */
  const au = await page.evaluate(async () => { const out = []; for (const n of Object.keys(LP.A.voices)) out.push(await LP.A.renderVoice(n, 3.2)); return out; });
  const bad = au.filter(v => v.nan || v.peak < 0.01 || v.peak > 8); ok(bad.length === 0, `${au.length} vozes de áudio renderizadas, todas audíveis e sem NaN` + (bad.length ? ' ruins: ' + bad.map(b => b.name + ':' + b.peak.toFixed(3)).join(',') : ''));
  console.log('  duração: roar_trex', au.find(v => v.name === 'roar_trex').activeSecs.toFixed(2) + 's, roar_raptor', au.find(v => v.name === 'roar_raptor').activeSecs.toFixed(2) + 's, click', au.find(v => v.name === 'click').activeSecs.toFixed(3) + 's');
  /* vistas de cada área: teleporta e captura quadros para inspeção visual */
  const spots = [['a1', 0, 8, 16.5, 0.0, 'hall'], ['a2', 1, 14, 19.5, 0.0, 'ave'], ['a3', 2, 8, 22, 0.0, 'forest'], ['a4', 3, 27, 17.5, 0.0, 'gen'], ['a5', 4, 12, 18, 0.0, 'yard']];
  for (const [id, idx, x, y, a, nm] of spots) {
    await page.evaluate(([idx]) => { const g = LP.G.get(); LP.G.debugLoad(idx); }, [idx]);
    await page.waitForFunction(() => LP.G.get().state === 'play', null, { timeout: 30000 });
    await page.evaluate(([x, y, a]) => { const s = LP.G.get(); s.P.x = x; s.P.y = y; s.P.a = a; }, [x, y, a]);
    await page.waitForTimeout(900); await page.screenshot({ path: '/tmp/shot_' + id + '.png' });
    const e = await page.evaluate(() => LP.G.lastError && LP.G.lastError.message); ok(!e, `área ${id} renderiza sem erro` + (e ? ': ' + e : ''));
  }
  ok(errors.length === 0, 'sem erros de console/página' + (errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''));
  await browser.close(); console.log(fails ? `\nFALHAS: ${fails}` : '\nTESTE DE NAVEGADOR OK'); process.exit(fails ? 1 : 0);
})().catch(e => { console.error('ERRO', e); process.exit(2); });
