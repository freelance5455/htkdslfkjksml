// Custo por quadro (lógica + render + HUD) em 3 resoluções internas, em CPU de servidor (referência relativa, NÃO é o A15)
const { chromium } = require('playwright'); const path = require('path');
const url = 'file://' + path.resolve(__dirname, '../app/src/main/assets/www/index.html');
(async () => {
  const browser = await chromium.launch(), ctx = await browser.newContext({ viewport: { width: 832, height: 385 }, hasTouch: true, isMobile: true });
  const page = await ctx.newPage(); await page.goto(url); await page.waitForFunction(() => window.LP && LP.G && LP.G.get().state === 'title', null, { timeout: 15000 });
  await page.evaluate(() => { LP.G.get().settings.fps = 60; });
  for (const [idx, nm, x, y] of [[0, 'A1 corredor', 8, 16.5], [2, 'A3 floresta', 8, 22], [1, 'A2 avenida (3 dinos)', 14, 19.5]]) {
    await page.evaluate(i => LP.G.debugLoad(i), idx); await page.waitForFunction(() => LP.G.get().state === 'play', null, { timeout: 30000 });
    await page.evaluate(([x, y]) => { const s = LP.G.get(); s.P.x = x; s.P.y = y; s.P.hp = 99999; s.P.flashOn = true; }, [x, y]);
    const row = [];
    for (const q of [1, 2, 3]) {
      await page.evaluate(q => { LP.G.get().settings.quality = q; window.dispatchEvent(new Event('resize')); }, q); await page.waitForTimeout(2500);
      row.push(await page.evaluate(() => { const s = LP.G.get(); return s.RW + 'x' + s.RH + ' ' + s.ema.toFixed(1) + ' ms'; }));
    }
    console.log(nm.padEnd(22), row.join('  |  '));
  }
  const mem = await page.evaluate(() => { let b = 0; for (const k in LP.G.get().W ? {} : {}) b += 0; return performance.memory ? (performance.memory.usedJSHeapSize / 1048576).toFixed(0) + ' MB heap JS' : 'n/d'; }); console.log('heap JS após 3 áreas:', mem);
  await browser.close();
})();
