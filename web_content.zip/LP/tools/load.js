// Carrega os módulos do jogo no Node (sem DOM)
const fs = require('fs'), vm = require('vm'), path = require('path');
global.window = global;
const dir = path.join(__dirname, '../app/src/main/assets/www/js/');
module.exports = function load(files) {
  for (const f of files) vm.runInThisContext(fs.readFileSync(dir + f + '.js', 'utf8'), { filename: f + '.js' });
  return global.LP;
};
