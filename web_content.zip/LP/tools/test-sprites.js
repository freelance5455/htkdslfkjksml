// Captura os dinossauros dentro do jogo (orientação, espelhamento, iluminação) para inspeção visual
const { chromium } = require('playwright'); const path = require('path');
const url = 'file://' + path.resolve(__dirname, '../app/src/main/assets/www/index.html');
(async () => {
  const browser = await chromium.launch(), ctx = await browser.newContext({ viewport: { width: 832, height: 385 }, hasTouch: true, isMobile: true });
  const page = await ctx.newPage(); page.on('pageerror', e => console.log('ERRO', e.message));
  await page.goto(url); await page.waitForFunction(() => window.LP && LP.G && LP.G.get().state === 'title', null, { timeout: 15000 });
  await page.evaluate(() => LP.G.debugLoad(1)); await page.waitForFunction(() => LP.G.get().state === 'play', null, { timeout: 30000 });
  const place = async (kind, x, y, facing, px, py, pa, name) => {
    await page.evaluate(([kind, x, y, facing, px, py, pa]) => {
      const g = LP.G.get(); g.dinos.forEach(d => { if (d.kind !== kind) d.dormant = true; });
      const d = g.dinos.find(d => d.kind === kind); d.dormant = false; d.x = x; d.y = y; d.facing = facing; d.state = 'patrol'; d.wait = 999; d.aware = 0; d.dist = 99;
      g.P.x = px; g.P.y = py; g.P.a = pa; g.P.hp = 9999; g.P.flashOn = true; g.P.hidden = null;
    }, [kind, x, y, facing, px, py, pa]);
    await page.waitForTimeout(500); await page.screenshot({ path: '/tmp/spr_' + name + '.png' });
  };
  await place('raptor', 22, 19.5, Math.PI / 2, 17, 19.5, 0, 'raptor_side');     /* de perfil */
  await place('raptor', 24, 19.5, Math.PI, 17, 19.5, 0, 'raptor_front');        /* de frente para o jogador */
  await place('trex', 28, 19.5, Math.PI, 17, 19.5, 0, 'trex_front');
  await place('carno', 26, 19.5, -Math.PI / 2, 18, 19.5, 0, 'carno_side');
  await browser.close();
})();
