// Montagem de conferência: uma linha por espécie (walk, alert, attack) em 5 ângulos
const load = require('./load'), png = require('./png');
const LP = load(['util', 'art']);
const names = Object.keys(LP.Art.SPEC), S = 1;
const cells = [['walk', 1], ['alert', 1], ['attack', 1]];
const sheets = names.map(n => LP.Art.makeDino(n).all());
let maxW = 0, totH = 0;
sheets.forEach((sh, i) => { const P = LP.Art.SPEC[names[i]]; maxW = Math.max(maxW, P.cw * 5 * cells.length / 1); totH += P.ch; });
// duas colunas de poses por linha para caber: layout simples = cada espécie numa linha com 3 poses x 5 vistas, escala 0.5 por amostragem
const sc = 0.55, W = Math.ceil(maxW * sc), H = Math.ceil(totH * sc) + 10, buf = Buffer.alloc(W * H * 4);
for (let i = 0; i < W * H; i++) { buf[i * 4] = 30; buf[i * 4 + 1] = 34; buf[i * 4 + 2] = 40; buf[i * 4 + 3] = 255; }
let oy = 0;
sheets.forEach((sh, si) => {
  const P = LP.Art.SPEC[names[si]];
  cells.forEach((cell, ci) => {
    for (let v = 0; v < 5; v++) {
      const img = sh.frames[cell[0]][cell[1]][v], ox = Math.floor((ci * 5 + v) * P.cw * sc);
      for (let y = 0; y < Math.floor(P.ch * sc); y++) for (let x = 0; x < Math.floor(P.cw * sc); x++) {
        const c = img.d[Math.floor(y / sc) * P.cw + Math.floor(x / sc)]; if (!(c >>> 24)) continue;
        const o = ((oy + y) * W + ox + x) * 4; buf[o] = c & 255; buf[o + 1] = (c >> 8) & 255; buf[o + 2] = (c >> 16) & 255;
      }
    }
  });
  oy += Math.floor(P.ch * sc);
});
png('/tmp/art_all.png', W, H, buf);
console.log('ok', W, H, names.map(n => n + ':' + LP.Art.SPEC[n].cw + 'x' + LP.Art.SPEC[n].ch).join(' '));
