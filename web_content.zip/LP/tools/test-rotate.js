// Celular em retrato (rotação automática desligada): aviso com botões reais, modo "tela girada" por CSS, toque mapeado, e volta ao normal ao girar de verdade
const { chromium } = require('playwright'); const path = require('path');
const url = 'file://' + path.resolve(__dirname, '../app/src/main/assets/www/index.html'); let fails = 0; const ok = (c, m) => { console.log((c ? '  ok   ' : '  FALHA ') + m); if (!c) fails++; };
(async () => {
  const browser = await chromium.launch(), ctx = await browser.newContext({ viewport: { width: 385, height: 832 }, hasTouch: true, isMobile: true });
  const page = await ctx.newPage(), errs = []; page.on('pageerror', e => errs.push(e.message)); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await page.goto(url); await page.waitForFunction(() => window.LP && LP.G && LP.G.get().state === 'title', null, { timeout: 15000 });
  ok(await page.isVisible('#rotate'), 'em retrato aparece o aviso para virar o aparelho'); ok(await page.isVisible('#rotMode') && await page.isVisible('#rotFull'), 'o aviso tem botões de verdade (jogar girado / tentar tela cheia)');
  await page.screenshot({ path: '/tmp/rot_aviso.png' });
  await page.click('#rotFull'); await page.waitForTimeout(400); ok(true, 'botão "tela cheia e girar" não quebra o jogo (headless não permite travar a orientação)');
  await page.click('#rotMode'); await page.waitForTimeout(500);
  ok(!(await page.isVisible('#rotate')), 'modo girado esconde o aviso'); ok((await page.evaluate(() => document.getElementById('stage').style.transform)).includes('rotate(90deg)'), 'o palco do jogo foi girado 90° por CSS');
  const st = await page.evaluate(() => LP.stage); ok(st.w === 832 && st.h === 385 && st.rot === 1, `palco lógico ${st.w}x${st.h} (horizontal) sobre a tela física ${st.W}x${st.H}`);
  await page.waitForTimeout(800); await page.screenshot({ path: '/tmp/rot_titulo.png' });
  await page.click('#mNew'); await page.waitForFunction(() => LP.G.get().state === 'play', null, { timeout: 30000 }); await page.waitForTimeout(1200); await page.screenshot({ path: '/tmp/rot_jogo.png' });
  const cdp = await ctx.newCDPSession(page), touch = (type, pts) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: pts.map((p, i) => ({ x: p[0], y: p[1], id: p[2] === undefined ? i : p[2] })) });
  const p0 = await page.evaluate(() => ({ x: LP.G.get().P.x, y: LP.G.get().P.y, a: LP.G.get().P.a }));
  /* na tela física, "para cima no palco" = dedo para a direita; metade esquerda do palco = metade de cima da tela */
  await touch('touchStart', [[300, 200, 0]]); await touch('touchMove', [[368, 200, 0]]); await page.waitForTimeout(1500);
  const p1 = await page.evaluate(() => ({ x: LP.G.get().P.x, y: LP.G.get().P.y, a: LP.G.get().P.a }));
  ok(Math.hypot(p1.x - p0.x, p1.y - p0.y) > 0.8, `joystick no modo girado andou ${Math.hypot(p1.x - p0.x, p1.y - p0.y).toFixed(2)} tiles para frente`);
  await touch('touchStart', [[300, 200, 0], [300, 620, 1]]); await touch('touchMove', [[300, 200, 0], [300, 720, 1]]); await touch('touchEnd', [[300, 720, 1]]); await page.waitForTimeout(200);
  const p2 = await page.evaluate(() => LP.G.get().P.a); ok(Math.abs(p2 - p1.a) > 0.15, `arrastar no lado direito do palco girou a câmera ${(p2 - p1.a).toFixed(2)} rad`); await touch('touchEnd', [[300, 200, 0]]);
  const btn = await page.locator('.btn.pause').boundingBox(); await touch('touchStart', [[btn.x + btn.width / 2, btn.y + btn.height / 2, 7]]); await touch('touchEnd', [[btn.x + btn.width / 2, btn.y + btn.height / 2, 7]]); await page.waitForTimeout(300);
  ok(await page.evaluate(() => LP.G.get().state) === 'pause', 'botão de pausa (no canto do palco girado) funciona'); ok(await page.isVisible('#pRot'), 'menu de pausa oferece "girar para o outro lado"');
  await page.click('#pRot'); await page.waitForTimeout(300); ok((await page.evaluate(() => document.getElementById('stage').style.transform)).includes('rotate(-90deg)'), 'girar para o outro lado funciona'); await page.screenshot({ path: '/tmp/rot_pausa.png' });
  await page.setViewportSize({ width: 832, height: 385 }); await page.waitForTimeout(500);
  ok(await page.evaluate(() => document.getElementById('stage').style.transform) === 'none' && !(await page.isVisible('#rotate')), 'ao girar o aparelho de verdade, o modo girado se desliga sozinho');
  await page.click('#pRes'); await page.waitForTimeout(300); ok(await page.evaluate(() => LP.G.get().state) === 'play', 'o jogo continua normalmente em horizontal');
  await page.setViewportSize({ width: 385, height: 832 }); await page.waitForTimeout(500);
  ok(await page.evaluate(() => LP.G.get().state) === 'pause' && await page.isVisible('#rotate'), 'voltar para retrato durante o jogo pausa e mostra o aviso');
  ok(errs.length === 0, 'sem erros de console/página' + (errs.length ? ': ' + errs.slice(0, 3).join(' | ') : ''));
  await browser.close(); console.log(fails ? `\nFALHAS: ${fails}` : '\nTESTE DE ROTAÇÃO OK'); process.exit(fails ? 1 : 0);
})().catch(e => { console.error('ERRO', e); process.exit(2); });
