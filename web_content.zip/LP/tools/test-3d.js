// Capturas dos objetos 3D (caixotes, barris, consoles, blocos, contêineres, itens) e do olhar vertical
const { chromium } = require('playwright'); const path = require('path');
const url = 'file://' + path.resolve(__dirname, '../app/src/main/assets/www/index.html');
(async () => {
  const browser = await chromium.launch(), ctx = await browser.newContext({ viewport: { width: 832, height: 385 }, hasTouch: true, isMobile: true });
  const page = await ctx.newPage(), errs = []; page.on('pageerror', e => errs.push(e.message)); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await page.goto(url); await page.waitForFunction(() => window.LP && LP.G && LP.G.get().state === 'title', null, { timeout: 15000 });
  const shots = [
    ['a1_crate_level', 0, 'crate', 2.3, 0.0], ['a1_crate_down', 0, 'crate', 2.3, -0.38], ['a1_console_down', 0, 'console', 2.0, -0.3],
    ['a1_item_down', 0, 'card1', 1.6, -0.5], ['a2_blocks', 1, 'block', 3.2, -0.12], ['a2_cont_up', 1, 'cont', 3.2, 0.3]
  ];
  let cur = -1;
  for (const [name, area, kind, dist, pitch] of shots) {
    if (cur !== area) { await page.evaluate(i => LP.G.debugLoad(i), area); await page.waitForFunction(() => LP.G.get().state === 'play', null, { timeout: 30000 }); cur = area; await page.waitForTimeout(5200); }
    const info = await page.evaluate(([kind, dist, pitch]) => {
      const g = LP.G.get(), W = g.W; g.dinos.forEach(d => { d.dormant = true; });
      const objs = W.objs.filter(o => o.kind === kind && !o.dead); if (!objs.length) return 'sem ' + kind;
      const o = objs[Math.min(1, objs.length - 1)];
      for (let a = 0; a < 6.28; a += 0.4) { const x = o.x + Math.cos(a) * dist, y = o.y + Math.sin(a) * dist; if (!W.collides(x, y, 0.3) && W.los(x, y, o.x, o.y)) { g.P.x = x; g.P.y = y; g.P.a = Math.atan2(o.y - y, o.x - x); g.P.pitch = pitch; g.P.hp = 9999; g.P.flashOn = true; g.P.crouch = false; return 'ok ' + kind + ' em ' + o.x + ',' + o.y; } }
      return 'sem ângulo livre';
    }, [kind, dist, pitch]);
    await page.waitForTimeout(700); await page.screenshot({ path: '/tmp/d3_' + name + '.png' }); console.log(name, info);
  }
  console.log('erros:', errs.length ? errs.slice(0, 3) : 'nenhum'); await browser.close();
})();
