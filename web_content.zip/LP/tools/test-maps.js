// Validador de mapas: conectividade, itens alcançáveis, progressão (cartões/códigos/energia) e classes de tamanho dos dinossauros
const load = require('./load');
const LP = load(['util', 'textures', 'objects', 'world', 'maps']);
const show = process.argv.includes('--show'); const onlyArg = (process.argv.find(a => a.startsWith('--only=')) || '').slice(7);
let fail = 0;
function err(m) { console.log('  ERRO:', m); fail++; }
LP.AREAS.forEach((A, ai) => {
  if (onlyArg && A.id !== onlyArg) return;
  A.rows = A.build();
  const w = new LP.World(A, { flags: {}, picked: {}, unlocked: {} });
  console.log(`\n== ${A.id} ${A.name}: ${w.w}x${w.h}, portas ${w.doorList.length}, esconderijos ${Object.keys(w.hides).length}, luzes ${w.lights.length}, ents ${w.ents.length}, spawns ${w.spawns.map(s => s.sp).join(',')}`);
  if (show) A.rows.forEach((r, y) => console.log(String(y).padStart(2) + ' ' + r));
  const K = LP.K, W = w.w, H = w.h;
  const st = { card: {}, item: (A.id === 'a4' ? { fuse: 1 } : {}), flags: {}, code: false };
  const powerFlag = A.powerFlag || 'a4_power';
  function lockOK(d) {
    if (!d.lock) return true; const l = d.lock;
    if (l.card) return !!st.card[l.card]; if (l.code) return st.code; if (l.flag) return !!st.flags[powerFlag]; if (l.item) return !!st.item[l.item]; return false;
  }
  function reach() {
    const seen = new Uint8Array(W * H), q = [], s = { x: w.start.x | 0, y: w.start.y | 0 }; q.push(s.y * W + s.x); seen[q[0]] = 1;
    while (q.length) {
      const c = q.pop(), x = c % W, y = (c / W) | 0;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue; const i = ny * W + nx; if (seen[i]) continue;
        const k = w.kind[i]; let ok = k === K.FLOOR; if (k === K.DOOR) ok = lockOK(w.doors[i]);
        if (ok) { seen[i] = 1; q.push(i); }
      }
    }
    return seen;
  }
  const adjSeen = (seen, x, y) => [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => { const nx = x + dx, ny = y + dy; return nx >= 0 && ny >= 0 && nx < W && ny < H && seen[ny * W + nx]; });
  let changed = true, seen = reach(), guard = 0;
  while (changed && guard++ < 20) {
    changed = false;
    for (const e of w.ents) {
      const i = (e.y | 0) * W + (e.x | 0); if (!seen[i]) continue;
      if (/^card[123]$/.test(e.type) && !st.card[e.type[4]]) { st.card[e.type[4]] = 1; changed = true; }
      if (e.type === 'fuse' && !st.item.fuse) { st.item.fuse = 1; changed = true; }
      if (e.type === 'gatekey' && !st.item.gatekey) { st.item.gatekey = 1; changed = true; }
      if (e.type === 'core' && !st.flags.a4_core) { st.flags.a4_core = 1; changed = true; }
      if (e.type === 'doc' && A.legend && Object.values(A.legend).some(l => l.id === e.id && l.key) && !st.code) { st.code = true; changed = true; }
    }
    for (let i = 0; i < W * H; i++) {
      if (w.kind[i] === K.LEVER && adjSeen(seen, i % W, (i / W) | 0)) {
        const m = w.meta[i]; if (m && m.flag && !st.flags[m.flag] && (!m.need || !m.need.item || st.item[m.need.item])) { st.flags[m.flag] = 1; changed = true; }
      }
      if (w.kind[i] === K.TERM && adjSeen(seen, i % W, (i / W) | 0) && w.meta[i] && w.meta[i].id === 'a5_final' && st.flags.a5_l1 && st.flags.a5_l2 && !st.flags.a5_chopper) { st.flags.a5_chopper = 1; changed = true; }
    }
    seen = reach();
  }
  let items = 0;
  for (const e of w.ents) { if (e.type === 'deco') continue; const i = (e.y | 0) * W + (e.x | 0); if (!seen[i]) err(`${e.type} (${e.x | 0},${e.y | 0}) id=${e.id} inalcançável`); else items++; }
  for (const s of w.spawns) { const i = (s.y | 0) * W + (s.x | 0); const need = { raptor: 0, dilo: 0, special: 0, carno: 1, trex: 2 }[s.sp]; if (w.cls[i] < need || w.cls[i] === 255) err(`${s.sp} (${s.x | 0},${s.y | 0}) em tile de classe ${w.cls[i]} (precisa ${need})`); }
  const ex = [];
  for (let i = 0; i < W * H; i++) if (w.kind[i] === K.EXIT) ex.push(i);
  if (ex.length !== 1) err('saída: ' + ex.length); else if (!adjSeen(seen, ex[0] % W, (ex[0] / W) | 0)) err('saída inalcançável após progressão');
  const need = A.exit.need; if (need.card && !st.card[need.card]) err('cartão da saída não obtido'); if (need.flag && !st.flags[need.flag]) err('flag da saída não obtida: ' + need.flag);
  let free = 0, reached = 0; for (let i = 0; i < W * H; i++) { if (w.kind[i] === K.FLOOR) { free++; if (seen[i]) reached++; } }
  console.log(`  entidades alcançáveis: ${items}/${w.ents.length}; piso alcançado ${reached}/${free}; cartões ${Object.keys(st.card)}; flags ${Object.keys(st.flags)}`);
  if (reached < free) { const miss = []; for (let i = 0; i < W * H; i++) if (w.kind[i] === K.FLOOR && !seen[i]) miss.push((i % W) + ',' + ((i / W) | 0)); console.log('  tiles de piso isolados (' + miss.length + '):', miss.slice(0, 14).join(' ')); }
  /* hide spots precisam de piso vizinho acessível */
  for (const k in w.hides) { const h = w.hides[k]; if (!adjSeen(seen, h.x, h.y)) err(`esconderijo (${h.x},${h.y}) inacessível`); }
});
console.log(fail ? `\nFALHAS: ${fail}` : '\nTODOS OS MAPAS OK');
process.exit(fail ? 1 : 0);
