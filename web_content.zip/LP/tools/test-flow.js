// Fluxo completo do início ao fim: um "robô" teleporta até cada objetivo e usa a interação do jogo (itens, códigos, alavancas, terminal, saídas, finais)
const { chromium } = require('playwright'); const path = require('path');
const url = 'file://' + path.resolve(__dirname, '../app/src/main/assets/www/index.html'); let fails = 0; const ok = (c, m) => { console.log((c ? '  ok   ' : '  FALHA ') + m); if (!c) fails++; };
(async () => {
  const browser = await chromium.launch(), ctx = await browser.newContext({ viewport: { width: 832, height: 385 }, hasTouch: true, isMobile: true });
  const page = await ctx.newPage(), errors = []; page.on('pageerror', e => errors.push(e.message)); page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto(url); await page.waitForFunction(() => window.LP && LP.G && LP.G.get().state === 'title', null, { timeout: 15000 });
  await page.evaluate(() => {
    const sleep = ms => new Promise(r => setTimeout(r, ms)); window.sleep = sleep;
    window.bot = {
      G: () => LP.G.get(),
      async freeze() { const g = LP.G.get(); g.dinos.forEach(d => { d.dormant = d.dormant; }); },
      stand(tx, ty) { const W = LP.G.get().W; for (const [dx, dy] of [[0, 1], [0, -1], [1, 0], [-1, 0]]) { const x = tx + dx, y = ty + dy; if (W.kind[y * W.w + x] === 0) return [x + 0.5, y + 0.5]; } return null; },
      async tile(tx, ty) { const g = LP.G.get(), s = this.stand(tx, ty); if (!s) throw new Error('sem piso ao lado de ' + tx + ',' + ty); g.P.x = s[0]; g.P.y = s[1]; g.P.a = Math.atan2(ty + 0.5 - s[1], tx + 0.5 - s[0]); g.P.hp = 99999; g.P.hidden = null; await sleep(220); LP.In.press.interact = true; await sleep(220); },
      async ent(type) { const g = LP.G.get(), e = g.W.ents.find(e => e.type === type || e.id === type); if (!e) throw new Error('ent ausente ' + type); g.P.x = e.x; g.P.y = e.y; g.P.hp = 99999; g.P.hidden = null; await sleep(220); LP.In.press.interact = true; await sleep(220); if (LP.G.get().state === 'doc') { document.getElementById('docClose').click(); await sleep(150); } return e; },
      kindTile(k, pred) { const W = LP.G.get().W; for (let i = 0; i < W.w * W.h; i++) if (W.kind[i] === k && (!pred || pred(W, i))) return [i % W.w, (i / W.w) | 0]; return null; },
      async keypad(code) { await sleep(200); for (const c of code) { [...document.querySelectorAll('#s-keypad .keys button')].find(b => b.textContent.trim() === c).click(); await sleep(60); } await sleep(500); },
      async waitPlay() { for (let i = 0; i < 200; i++) { if (LP.G.get().state === 'play') return true; await sleep(100); } return false; }
    };
  });
  const R = async fn => page.evaluate(fn);
  await page.click('#mNew'); await page.waitForFunction(() => LP.G.get().state === 'play', null, { timeout: 30000 });
  /* ===== ÁREA 1 ===== */
  console.log('\n[Área 1]');
  await R(async () => { await bot.ent('card1'); }); ok(await R(() => LP.G.get().S.inv.card1 === 1), 'pegou cartão nível 1');
  await R(async () => { const t = bot.kindTile(2, (W, i) => W.doors[i].ch === '1'); await bot.tile(t[0], t[1]); }); await page.waitForTimeout(500);
  ok(await R(() => LP.G.get().W.dOpen[bot.kindTile(2, (W, i) => W.doors[i].ch === '1').reduce((a, b, k, arr) => arr[1] * LP.G.get().W.w + arr[0])] > 0), 'porta de cartão nível 1 abriu');
  await R(async () => { await bot.ent('a1_postit'); }); ok(await R(() => LP.G.get().S.docs.includes('a1_postit')), 'leu o post-it com o código');
  await R(async () => { const t = bot.kindTile(2, (W, i) => W.doors[i].ch === 'C'); await bot.tile(t[0], t[1]); }); await page.waitForTimeout(300);
  ok(await R(() => LP.G.get().state) === 'keypad', 'porta de código abriu o teclado'); await R(() => bot.keypad('1111')); ok(await R(() => { const W = LP.G.get().W; return Object.values(W.doors).find(d => d.ch === 'C').lock !== null; }), 'código errado (1111) não destranca a porta');
  await R(async () => { const t = bot.kindTile(2, (W, i) => W.doors[i].ch === 'C'); await bot.tile(t[0], t[1]); await bot.keypad('3147'); }); await page.waitForTimeout(300);
  ok(await R(() => Object.keys(LP.G.get().S.unlocked).length > 0), 'código 3147 destrancou a porta');
  await R(async () => { await bot.ent('card2'); }); ok(await R(() => LP.G.get().S.inv.card2 === 1), 'pegou cartão nível 2');
  await R(async () => { await bot.ent('save'); }); ok(await page.evaluate(() => LP.G.hasSave()), 'checkpoint salvou o jogo');
  await R(async () => { const t = bot.kindTile(3); await bot.tile(t[0], t[1]); }); await R(() => bot.waitPlay());
  ok(await R(() => LP.G.get().S.area) === 1, 'saída da doca levou à Área 2');
  /* ===== ÁREA 2 ===== */
  console.log('\n[Área 2]');
  await R(async () => { await bot.ent('a2_codigo'); }); await R(async () => { const t = bot.kindTile(2, (W, i) => W.doors[i].ch === 'C'); await bot.tile(t[0], t[1]); await bot.keypad('5926'); });
  ok(await R(() => Object.keys(LP.G.get().S.unlocked).length > 0), 'código 5926 destrancou a sala de controle');
  const rexBefore = await R(() => LP.G.get().dinos.find(d => d.kind === 'trex').dormant);
  await R(async () => { const t = bot.kindTile(7); await bot.tile(t[0], t[1]); }); await page.waitForTimeout(700);
  ok(rexBefore === true && await R(() => !LP.G.get().dinos.find(d => d.kind === 'trex').dormant), 'alavanca liberou o T-Rex (evento de roteiro)');
  await page.waitForTimeout(6000); ok(await R(() => LP.G.get().W.kind.filter(k => k === 4).length) === 0, 'T-Rex quebrou a barricada');
  await R(async () => { LP.G.get().dinos.forEach(d => { d.dormant = true; }); const t = bot.kindTile(3); await bot.tile(t[0], t[1]); }); await R(() => bot.waitPlay()); ok(await R(() => LP.G.get().S.area) === 2, 'saída leste levou à Área 3');
  /* ===== ÁREA 3 ===== */
  console.log('\n[Área 3]');
  await R(async () => { await bot.ent('card3'); await bot.ent('fuse'); }); ok(await R(() => LP.G.get().S.inv.card3 === 1 && LP.G.get().S.inv.fuse === 1), 'pegou cartão 3 e fusível');
  await R(async () => { LP.G.get().dinos.forEach(d => { d.dormant = true; }); const t = bot.kindTile(3); await bot.tile(t[0], t[1]); }); await R(() => bot.waitPlay()); ok(await R(() => LP.G.get().S.area) === 3, 'bunker levou à Área 4');
  /* ===== ÁREA 4 ===== */
  console.log('\n[Área 4]');
  await R(async () => { const t = bot.kindTile(7); await bot.tile(t[0], t[1]); }); ok(await R(() => LP.G.get().S.flags.a4_power === 1 && LP.G.get().S.inv.fuse === 0), 'fusível ligou o gerador (consumido)');
  await page.waitForTimeout(7500); ok(await R(() => !LP.G.get().dinos.find(d => d.kind === 'special').dormant), 'O Silêncio apareceu após o gerador');
  await R(async () => { LP.G.get().dinos.forEach(d => { d.dormant = true; }); await bot.ent('core'); }); ok(await R(() => LP.G.get().S.flags.a4_core === 1), 'pegou o Núcleo genético');
  await R(async () => { LP.G.get().dinos.forEach(d => { d.dormant = true; }); }); await page.waitForTimeout(3500); await R(async () => { LP.G.get().dinos.forEach(d => { d.dormant = true; }); const t = bot.kindTile(3); await bot.tile(t[0], t[1]); }); await R(() => bot.waitPlay()); ok(await R(() => LP.G.get().S.area) === 4, 'elevador levou à Área 5');
  /* ===== ÁREA 5 ===== */
  console.log('\n[Área 5]');
  await R(async () => { const ls = []; const W = LP.G.get().W; for (let i = 0; i < W.w * W.h; i++) if (W.kind[i] === 7) ls.push([i % W.w, (i / W.w) | 0]); for (const t of ls) await bot.tile(t[0], t[1]); });
  ok(await R(() => LP.G.get().S.flags.a5_l1 === 1 && LP.G.get().S.flags.a5_l2 === 1), 'ligou as duas alavancas');
  await R(async () => { const t = bot.kindTile(6); await bot.tile(t[0], t[1]); }); await page.waitForTimeout(300); ok(await R(() => LP.G.get().state) === 'doc', 'terminal final abriu o texto'); await page.click('#docClose'); await page.waitForTimeout(300);
  ok(await R(() => LP.G.get().state) === 'decide', 'tela de decisão apareceu'); await page.click('#dA'); await page.waitForTimeout(400);
  ok(await R(() => LP.G.get().S.chopT > 70 && LP.G.get().S.ending === 'A'), 'decisão iniciou a contagem do resgate (final A)');
  ok(await R(() => !LP.G.get().dinos.find(d => d.kind === 'trex').dormant), 'T-Rex foi liberado na perseguição final');
  await R(async () => { const g = LP.G.get(); g.S.chopT = 0.3; g.dinos.forEach(d => { d.dormant = true; }); await sleep(900); const t = bot.kindTile(3); await bot.tile(t[0], t[1]); }); await page.waitForTimeout(600);
  ok(await R(() => LP.G.get().state) === 'end', 'embarcou no helicóptero: tela de final'); await page.screenshot({ path: '/tmp/shot_end.png' });
  ok(errors.length === 0, 'sem erros de console/página no fluxo completo' + (errors.length ? ': ' + errors.slice(0, 3).join(' | ') : ''));
  await browser.close(); console.log(fails ? `\nFALHAS: ${fails}` : '\nFLUXO COMPLETO OK'); process.exit(fails ? 1 : 0);
})().catch(e => { console.error('ERRO', e); process.exit(2); });
