# Panduan Build APK Android — Aetherion

Game ini berbasis HTML5 dan dapat dibungkus menjadi APK menggunakan **Capacitor**.

## Prasyarat
- Node.js 18+
- Android Studio (dengan SDK & emulator atau device)
- JDK 17

## Langkah Build

### 1. Siapkan proyek Capacitor di folder client

```bash
cd fantasy-rpg/client
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init Aetherion com.aetherion.game --web-dir .
```

### 2. Tambah platform Android

```bash
npx cap add android
npx cap sync
```

### 3. Buka di Android Studio

```bash
npx cap open android
```

Di Android Studio:
- Tunggu Gradle sync
- Build → Generate Signed Bundle / APK
- Atau Run ke device/emulator

### 4. Konfigurasi penting (android/app/src/main/AndroidManifest.xml)

Pastikan permission jika voice chat / multiplayer:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
```

### 5. Orientasi Landscape

Di `AndroidManifest.xml` activity:

```xml
android:screenOrientation="sensorLandscape"
```

### 6. Optimasi performa Android

- Gunakan `settings.quality = 'low'` atau `'medium'` default
- Pixel ratio dibatasi di kode (sudah ada)
- Shadow map hanya aktif di medium/high

### Catatan
- Multiplayer Online membutuhkan server Node.js yang dapat diakses dari internet (bukan hanya localhost).
- Voice chat membutuhkan HTTPS atau context aman + izin mikrofon.
- Data LocalStorage tersimpan per aplikasi; clear data aplikasi = hilang progress.

## Alternatif: TWA / PWA
Anda juga bisa deploy sebagai PWA dan "Add to Home Screen", atau gunakan Trusted Web Activity.
