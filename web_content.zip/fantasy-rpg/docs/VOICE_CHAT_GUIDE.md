# Voice Chat Guide — Aetherion

## Teknologi
- **WebRTC** untuk media peer-to-peer
- **Signaling** melalui WebSocket server game (sudah ada)
- **STUN** publik (Google) untuk NAT traversal
- **TURN** (opsional, diperlukan di jaringan ketat)

## Status Saat Ini
Tombol mikrofon sudah ada di HUD. Implementasi penuh WebRTC peer connection akan dilengkapi di **Tahap 7**.

## Persyaratan
1. **Secure context**: HTTPS atau `localhost`
2. Izin mikrofon dari user (`getUserMedia`)
3. Server signaling aktif
4. Untuk cross-network: TURN server (coturn atau layanan pihak ketiga)

## Alur Singkat (rencana implementasi)
1. User tekan tombol mic → minta `getUserMedia({ audio: true })`
2. Buat `RTCPeerConnection` dengan STUN
3. Tukar SDP/ICE candidate via WebSocket room
4. Stream audio ke peer di room yang sama
5. Indikator “sedang bicara” via volume analyser
6. Mute per-player & push-to-talk opsional

## Catatan Privasi
- Tidak merekam atau menyimpan percakapan
- Voice hanya live di dalam room
- User dapat mematikan mic kapan saja
