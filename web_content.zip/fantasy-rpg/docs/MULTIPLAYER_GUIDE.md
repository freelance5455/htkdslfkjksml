# Multiplayer Guide — Aetherion

## Arsitektur
- **Offline / Solo**: LocalStorage, AI enemies
- **LAN**: Host menjalankan server Node.js di jaringan lokal; klien connect via `ws://IP_HOST:3001`
- **Online**: Server Node.js di VPS/hosting yang support WebSocket; klien connect via `ws://domain:port` atau `wss://`

**Tidak menggunakan Firebase.**

## Menjalankan Server Lokal

```bash
cd fantasy-rpg/server
npm install
node server.js
```

Server default: `ws://localhost:3001`

## LAN
1. Host: jalankan server di PC/laptop yang terhubung Wi-Fi yang sama.
2. Cari IP lokal host (mis. `ipconfig` / `ifconfig` → 192.168.x.x)
3. Di device lain, masukkan `ws://192.168.x.x:3001` di kolom server.
4. Buat / gabung room dengan kode.

**Catatan browser Android**: beberapa browser membatasi WebSocket non-HTTPS. Untuk production gunakan `wss://` dengan sertifikat.

## Online
1. Deploy `server/` ke VPS (DigitalOcean, Railway, Render, Fly.io, dll) yang support WebSocket.
2. Buka port 3001 (atau set `PORT` env).
3. Di game, masukkan alamat `ws://your-server:3001` atau `wss://...`.

## Fitur Server Saat Ini (Tahap 1–6 foundation)
- Create / Join room dengan kode
- Sinkronisasi posisi & rotasi pemain
- Broadcast combat events (dasar)
- Chat text
- Host transfer jika host disconnect
- Validasi posisi (clamp bounds)
- Max 8 pemain per room

## Yang masih perlu pengembangan lanjutan
- Full authoritative combat damage validation
- Enemy sync
- Loot / inventory sync dengan validasi server
- Party system lengkap
- Reconnect token
- Rate limiting lebih ketat
- Database untuk akun & progress online (opsional)

## Voice Chat
Lihat `VOICE_CHAT_GUIDE.md`. Membutuhkan WebRTC + signaling lewat server yang sama.
