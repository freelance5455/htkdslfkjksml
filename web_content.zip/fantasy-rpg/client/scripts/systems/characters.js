/**
 * Aetherion — Playable Characters
 */

export const CHARACTERS = {
  kael: {
    id: 'kael',
    name: 'Kael of Ember',
    role: 'DPS / Mage',
    element: 'fire',
    description: 'Echo Walker yang terlahir kembali dari sisa-sisa Kristal Api. Menguasai api dengan intensitas tinggi.',
    baseStats: {
      hp: 100,
      maxHp: 100,
      energy: 100,
      maxEnergy: 100,
      attack: 18,
      defense: 8,
      speed: 6.5,
      critRate: 0.12
    },
    color: 0xff6b35,
    unlocked: true
  },
  lyra: {
    id: 'lyra',
    name: 'Lyra of Tides',
    role: 'Support / Healer',
    element: 'water',
    description: 'Penjaga oasis kuno. Sihir airnya dapat menyembuhkan dan melindungi sekutu.',
    baseStats: {
      hp: 110,
      maxHp: 110,
      energy: 120,
      maxEnergy: 120,
      attack: 12,
      defense: 10,
      speed: 5.8,
      critRate: 0.08
    },
    color: 0x3b82f6,
    unlocked: false
  },
  zephyr: {
    id: 'zephyr',
    name: 'Zephyr the Swift',
    role: 'Assassin',
    element: 'wind',
    description: 'Pemburu bayangan dari Kepulauan Badai. Kecepatannya hampir tak tertandingi.',
    baseStats: {
      hp: 85,
      maxHp: 85,
      energy: 90,
      maxEnergy: 90,
      attack: 22,
      defense: 6,
      speed: 8.5,
      critRate: 0.22
    },
    color: 0x67e8f9,
    unlocked: false
  },
  terra: {
    id: 'terra',
    name: 'Terra the Bulwark',
    role: 'Tank',
    element: 'earth',
    description: 'Pelindung reruntuhan kuno. Tubuhnya setangguh batu gunung.',
    baseStats: {
      hp: 160,
      maxHp: 160,
      energy: 80,
      maxEnergy: 80,
      attack: 14,
      defense: 18,
      speed: 4.5,
      critRate: 0.05
    },
    color: 0xa3e635,
    unlocked: false
  }
};

export function getCharacter(id) {
  return CHARACTERS[id] || CHARACTERS.kael;
}

export function createPlayerState(charId, level = 1) {
  const char = getCharacter(charId);
  const stats = { ...char.baseStats };
  // Simple level scaling
  const scale = 1 + (level - 1) * 0.08;
  stats.maxHp = Math.floor(stats.maxHp * scale);
  stats.hp = stats.maxHp;
  stats.attack = Math.floor(stats.attack * scale);
  stats.defense = Math.floor(stats.defense * scale);
  return {
    charId,
    name: char.name,
    element: char.element,
    level,
    ...stats,
    cooldowns: [0, 0, 0, 0],
    isAlive: true,
    invincibleUntil: 0
  };
}
