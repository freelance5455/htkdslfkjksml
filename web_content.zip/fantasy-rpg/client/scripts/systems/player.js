/**
 * Aetherion — Player Controller
 */

import * as THREE from 'three';
import { createPlayerState, getCharacter } from './characters.js';
import { getElementSkills } from './elements.js';

export class Player {
  constructor(scene, saveData) {
    this.scene = scene;
    this.state = createPlayerState(saveData.activeCharacter, saveData.level);
    this.state.element = saveData.activeElement || this.state.element;

    this.mesh = this._createMesh();
    scene.add(this.mesh);

    this.velocity = new THREE.Vector3();
    this.facing = new THREE.Vector3(0, 0, 1);
    this.isDashing = false;
    this.dashUntil = 0;
    this.attackCooldown = 0;
    this.groundY = 0;

    // Skills
    this.skills = getElementSkills(this.state.element);
    this.projectiles = [];
    this.aoeZones = [];

    this.target = null;
  }

  _createMesh() {
    const group = new THREE.Group();
    const char = getCharacter(this.state.charId);
    const color = char.color;

    // Body
    const body = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.35, 0.9, 4, 8),
      new THREE.MeshStandardMaterial({ color, roughness: 0.6 })
    );
    body.position.y = 1.0;
    body.castShadow = true;
    group.add(body);

    // Head
    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.32, 8, 8),
      new THREE.MeshStandardMaterial({ color: 0xf5d0c5 })
    );
    head.position.y = 1.85;
    head.castShadow = true;
    group.add(head);

    // Simple weapon (staff)
    const staff = new THREE.Mesh(
      new THREE.CylinderGeometry(0.04, 0.04, 1.6, 6),
      new THREE.MeshStandardMaterial({ color: 0x5c4033 })
    );
    staff.position.set(0.4, 1.2, 0);
    staff.rotation.z = 0.2;
    group.add(staff);

    // Crystal on staff
    const crystal = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.15, 0),
      new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.6 })
    );
    crystal.position.set(0.45, 2.0, 0);
    group.add(crystal);

    group.userData.radius = 0.6;
    return group;
  }

  setPosition(x, y, z) {
    this.mesh.position.set(x, y, z);
  }

  getPosition() {
    return this.mesh.position;
  }

  update(dt, input, cameraYaw, world, enemies, now) {
    if (!this.state.isAlive) return;

    // Cooldowns
    this.attackCooldown = Math.max(0, this.attackCooldown - dt);
    for (let i = 0; i < 4; i++) {
      this.state.cooldowns[i] = Math.max(0, this.state.cooldowns[i] - dt);
    }

    // Energy regen
    this.state.energy = Math.min(this.state.maxEnergy, this.state.energy + 8 * dt);

    // Movement
    const moveSpeed = this.isDashing ? this.state.speed * 2.8 : this.state.speed;
    let mx = input.moveX;
    let mz = input.moveY;

    if (mx !== 0 || mz !== 0) {
      // Camera-relative movement
      const sin = Math.sin(cameraYaw);
      const cos = Math.cos(cameraYaw);
      const dx = mx * cos + mz * sin;
      const dz = -mx * sin + mz * cos;
      const len = Math.sqrt(dx * dx + dz * dz) || 1;
      this.velocity.x = (dx / len) * moveSpeed;
      this.velocity.z = (dz / len) * moveSpeed;
      this.facing.set(dx / len, 0, dz / len);
      this.mesh.rotation.y = Math.atan2(dx, dz);
    } else {
      this.velocity.x *= 0.8;
      this.velocity.z *= 0.8;
    }

    // Dash
    if (input.consumeDash() && !this.isDashing && this.state.energy >= 15) {
      this.isDashing = true;
      this.dashUntil = now + 0.35;
      this.state.energy -= 15;
      this.state.invincibleUntil = now + 0.35;
    }
    if (this.isDashing && now > this.dashUntil) {
      this.isDashing = false;
    }

    // Apply movement + bounds + simple collision
    const next = this.mesh.position.clone();
    next.x += this.velocity.x * dt;
    next.z += this.velocity.z * dt;
    next.x = Math.max(world.bounds.minX + 1, Math.min(world.bounds.maxX - 1, next.x));
    next.z = Math.max(world.bounds.minZ + 1, Math.min(world.bounds.maxZ - 1, next.z));

    // Obstacle avoidance (trees/rocks)
    for (const obj of world.objects) {
      if (!obj.userData.isObstacle) continue;
      const dx = next.x - obj.position.x;
      const dz = next.z - obj.position.z;
      const dist = Math.sqrt(dx * dx + dz * dz);
      const minDist = (obj.userData.radius || 1) + 0.6;
      if (dist < minDist && dist > 0.01) {
        const push = (minDist - dist) / dist;
        next.x += dx * push;
        next.z += dz * push;
      }
    }

    this.mesh.position.copy(next);

    // Attack
    if (input.consumeAttack() && this.attackCooldown <= 0) {
      this._basicAttack(enemies, now);
      this.attackCooldown = 0.45;
    }

    // Skills
    for (let i = 0; i < 4; i++) {
      if (input.consumeSkill(i)) {
        this._useSkill(i, enemies, now);
      }
    }

    // Update projectiles
    this._updateProjectiles(dt, enemies, now);

    // Update AOE
    this._updateAoe(dt, enemies, now);

    // Find nearest target for indicator
    this._updateTarget(enemies);
  }

  _basicAttack(enemies, now) {
    const origin = this.mesh.position.clone();
    origin.y += 1.2;
    const dir = this.facing.clone();
    const range = 3.5;

    for (const e of enemies) {
      if (!e.isAlive) continue;
      const toE = e.mesh.position.clone().sub(this.mesh.position);
      toE.y = 0;
      const dist = toE.length();
      if (dist < range && toE.normalize().dot(dir) > 0.3) {
        const dmg = this.state.attack + Math.floor(Math.random() * 6);
        e.takeDamage(dmg, now);
        this._spawnHitEffect(e.mesh.position);
        break;
      }
    }
  }

  _useSkill(index, enemies, now) {
    const skill = this.skills[index];
    if (!skill) return;
    if (this.state.cooldowns[index] > 0) return;
    if (this.state.energy < skill.energy) return;

    this.state.energy -= skill.energy;
    this.state.cooldowns[index] = skill.cooldown;

    const origin = this.mesh.position.clone();
    origin.y += 1.3;

    if (skill.type === 'projectile') {
      this.projectiles.push({
        mesh: this._createProjectileMesh(skill),
        dir: this.facing.clone(),
        speed: 22,
        damage: skill.damage + this.state.attack * 0.5,
        life: 1.5,
        area: skill.area,
        element: this.state.element
      });
      this.projectiles[this.projectiles.length - 1].mesh.position.copy(origin);
      this.scene.add(this.projectiles[this.projectiles.length - 1].mesh);
    } else if (skill.type === 'dash') {
      this.isDashing = true;
      this.dashUntil = now + 0.4;
      this.state.invincibleUntil = now + 0.4;
      // Damage along path
      for (const e of enemies) {
        if (!e.isAlive) continue;
        const dist = e.mesh.position.distanceTo(this.mesh.position);
        if (dist < skill.range) {
          e.takeDamage(skill.damage, now);
        }
      }
    } else if (skill.type === 'aoe' || skill.type === 'ultimate') {
      this.aoeZones.push({
        position: this.mesh.position.clone(),
        radius: skill.area,
        damage: skill.damage + (skill.type === 'ultimate' ? this.state.attack : 0),
        duration: skill.duration || 0.8,
        tick: 0.4,
        lastTick: 0,
        element: this.state.element,
        mesh: this._createAoeMesh(skill)
      });
      const aoe = this.aoeZones[this.aoeZones.length - 1];
      aoe.mesh.position.copy(aoe.position);
      aoe.mesh.position.y = 0.1;
      this.scene.add(aoe.mesh);
      // Immediate hit
      this._aoeDamage(aoe, enemies, now);
    } else if (skill.type === 'heal') {
      const heal = Math.abs(skill.damage);
      this.state.hp = Math.min(this.state.maxHp, this.state.hp + heal);
    }
  }

  _createProjectileMesh(skill) {
    const color = 0xff6b35;
    const mesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.35, 8, 8),
      new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.8 })
    );
    return mesh;
  }

  _createAoeMesh(skill) {
    const color = skill.type === 'ultimate' ? 0xff4500 : 0xff6b35;
    const mesh = new THREE.Mesh(
      new THREE.CircleGeometry(skill.area, 24),
      new THREE.MeshBasicMaterial({
        color,
        transparent: true,
        opacity: 0.35,
        side: THREE.DoubleSide
      })
    );
    mesh.rotation.x = -Math.PI / 2;
    return mesh;
  }

  _updateProjectiles(dt, enemies, now) {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.mesh.position.addScaledVector(p.dir, p.speed * dt);
      p.life -= dt;
      let hit = false;
      for (const e of enemies) {
        if (!e.isAlive) continue;
        if (p.mesh.position.distanceTo(e.mesh.position) < p.area + 0.8) {
          e.takeDamage(Math.floor(p.damage), now);
          this._spawnHitEffect(e.mesh.position);
          hit = true;
          break;
        }
      }
      if (p.life <= 0 || hit) {
        this.scene.remove(p.mesh);
        this.projectiles.splice(i, 1);
      }
    }
  }

  _updateAoe(dt, enemies, now) {
    for (let i = this.aoeZones.length - 1; i >= 0; i--) {
      const a = this.aoeZones[i];
      a.duration -= dt;
      a.lastTick += dt;
      if (a.lastTick >= a.tick) {
        a.lastTick = 0;
        this._aoeDamage(a, enemies, now);
      }
      if (a.mesh.material) {
        a.mesh.material.opacity = Math.max(0.1, a.duration * 0.15);
      }
      if (a.duration <= 0) {
        this.scene.remove(a.mesh);
        this.aoeZones.splice(i, 1);
      }
    }
  }

  _aoeDamage(aoe, enemies, now) {
    for (const e of enemies) {
      if (!e.isAlive) continue;
      const dist = e.mesh.position.distanceTo(aoe.position);
      if (dist < aoe.radius) {
        e.takeDamage(Math.floor(aoe.damage * (aoe.tick || 1)), now);
      }
    }
  }

  _spawnHitEffect(pos) {
    // Simple flash — can be expanded with particles
  }

  _updateTarget(enemies) {
    let nearest = null;
    let minD = 15;
    for (const e of enemies) {
      if (!e.isAlive) continue;
      const d = e.mesh.position.distanceTo(this.mesh.position);
      if (d < minD) {
        minD = d;
        nearest = e;
      }
    }
    this.target = nearest;
  }

  takeDamage(amount, now) {
    if (now < this.state.invincibleUntil) return 0;
    const reduced = Math.max(1, amount - this.state.defense * 0.4);
    this.state.hp -= reduced;
    if (this.state.hp <= 0) {
      this.state.hp = 0;
      this.state.isAlive = false;
    }
    this.state.invincibleUntil = now + 0.4;
    return reduced;
  }

  heal(amount) {
    this.state.hp = Math.min(this.state.maxHp, this.state.hp + amount);
  }

  switchElement(elementId) {
    this.state.element = elementId;
    this.skills = getElementSkills(elementId);
    this.state.cooldowns = [0, 0, 0, 0];
  }

  dispose() {
    this.projectiles.forEach(p => this.scene.remove(p.mesh));
    this.aoeZones.forEach(a => this.scene.remove(a.mesh));
    this.scene.remove(this.mesh);
  }
}
