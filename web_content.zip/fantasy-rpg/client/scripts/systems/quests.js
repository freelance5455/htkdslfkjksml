/**
 * Aetherion — Quest System
 */

export const QUESTS = {
  main_01: {
    id: 'main_01',
    name: 'Benih Cahaya',
    description: 'Kumpulkan 5 Benih Cahaya di Padang Rumput untuk Elder Mira.',
    type: 'collect',
    target: 'light_seed',
    amount: 5,
    rewards: { exp: 50, coins: 30, items: { potion: 2 } },
    dialogueStart: {
      speaker: 'Elder Mira',
      text: 'Anak muda... Kristal Asal pecah, dan benih cahaya tersebar. Kumpulkan lima benih di padang rumput ini agar aku bisa merasakan denyut Aetherion kembali.'
    },
    dialogueComplete: {
      speaker: 'Elder Mira',
      text: 'Bagus sekali. Dengan benih ini, jalan menuju wilayah lain akan mulai terbuka. Jadilah Echo Walker yang sejati.'
    }
  }
};

export class QuestManager {
  constructor(saveData) {
    this.active = [...(saveData.quests?.active || [])];
    this.completed = [...(saveData.quests?.completed || [])];
    this.progress = { ...(saveData.quests?.progress || {}) };
  }

  getActiveQuest() {
    if (this.active.length === 0) return null;
    const id = this.active[0];
    const q = QUESTS[id];
    if (!q) return null;
    const prog = this.progress[id] || { collected: 0, target: q.amount };
    return { ...q, progress: prog };
  }

  onCollect(itemType) {
    for (const id of this.active) {
      const q = QUESTS[id];
      if (!q || q.type !== 'collect') continue;
      if (q.target !== itemType) continue;
      if (!this.progress[id]) this.progress[id] = { collected: 0, target: q.amount };
      this.progress[id].collected = Math.min(q.amount, this.progress[id].collected + 1);
      return this.progress[id];
    }
    return null;
  }

  onKill() {
    // Future: hunt quests
  }

  canComplete(id) {
    const q = QUESTS[id];
    if (!q) return false;
    const p = this.progress[id];
    if (!p) return false;
    return p.collected >= q.amount;
  }

  complete(id) {
    if (!this.canComplete(id)) return null;
    this.active = this.active.filter(x => x !== id);
    this.completed.push(id);
    return QUESTS[id].rewards;
  }

  toSave() {
    return {
      active: this.active,
      completed: this.completed,
      progress: this.progress
    };
  }
}
