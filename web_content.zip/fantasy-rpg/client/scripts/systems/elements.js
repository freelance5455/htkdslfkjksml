/**
 * Aetherion — Elemental Magic System
 * 12 Elements × 4 Skills = 48 Skills
 * Stage 1 implements Fire fully; others have data ready.
 */

export const ELEMENTS = {
  fire: {
    id: 'fire',
    name: 'Api',
    color: 0xff6b35,
    skills: [
      {
        id: 'fireball',
        name: 'Fireball',
        icon: '🔥',
        damage: 28,
        range: 18,
        area: 1.5,
        cooldown: 1.8,
        energy: 12,
        type: 'projectile',
        description: 'Meluncurkan bola api ke arah musuh.'
      },
      {
        id: 'flame_dash',
        name: 'Flame Dash',
        icon: '💨',
        damage: 15,
        range: 8,
        area: 2,
        cooldown: 4,
        energy: 18,
        type: 'dash',
        description: 'Bergerak cepat dengan jejak api.'
      },
      {
        id: 'inferno_field',
        name: 'Inferno Field',
        icon: '🌋',
        damage: 12,
        range: 0,
        area: 6,
        cooldown: 8,
        energy: 25,
        type: 'aoe',
        duration: 4,
        description: 'Menciptakan area api yang memberikan damage.'
      },
      {
        id: 'phoenix_cataclysm',
        name: 'Phoenix Cataclysm',
        icon: '☀️',
        damage: 85,
        range: 12,
        area: 10,
        cooldown: 22,
        energy: 50,
        type: 'ultimate',
        description: 'Serangan api berskala besar.'
      }
    ]
  },
  water: {
    id: 'water', name: 'Air', color: 0x3b82f6,
    skills: [
      { id: 'water_lance', name: 'Water Lance', icon: '💧', damage: 26, range: 16, area: 1, cooldown: 1.6, energy: 10, type: 'projectile', description: 'Tombak air.' },
      { id: 'tidal_wave', name: 'Tidal Wave', icon: '🌊', damage: 22, range: 10, area: 8, cooldown: 6, energy: 22, type: 'aoe', description: 'Gelombang air.' },
      { id: 'aqua_prison', name: 'Aqua Prison', icon: '🔵', damage: 8, range: 12, area: 3, cooldown: 9, energy: 20, type: 'cc', duration: 2.5, description: 'Menahan target.' },
      { id: 'oceans_wrath', name: "Ocean's Wrath", icon: '🌊', damage: 80, range: 14, area: 12, cooldown: 24, energy: 55, type: 'ultimate', description: 'Gelombang besar.' }
    ]
  },
  wind: {
    id: 'wind', name: 'Angin', color: 0x67e8f9,
    skills: [
      { id: 'wind_blade', name: 'Wind Blade', icon: '🍃', damage: 24, range: 20, area: 1.2, cooldown: 1.5, energy: 10, type: 'projectile', description: 'Tebasan angin.' },
      { id: 'gale_step', name: 'Gale Step', icon: '💨', damage: 10, range: 10, area: 2, cooldown: 3.5, energy: 15, type: 'dash', description: 'Dash kecepatan tinggi.' },
      { id: 'tornado', name: 'Tornado', icon: '🌪', damage: 14, range: 8, area: 5, cooldown: 7, energy: 24, type: 'aoe', duration: 3.5, description: 'Pusaran angin.' },
      { id: 'sky_tempest', name: 'Sky Tempest', icon: '🌀', damage: 75, range: 15, area: 14, cooldown: 20, energy: 50, type: 'ultimate', description: 'Badai angin.' }
    ]
  },
  earth: {
    id: 'earth', name: 'Tanah', color: 0xa3e635,
    skills: [
      { id: 'stone_spike', name: 'Stone Spike', icon: '🪨', damage: 32, range: 10, area: 2, cooldown: 2.2, energy: 14, type: 'projectile', description: 'Duri batu.' },
      { id: 'earth_wall', name: 'Earth Wall', icon: '🧱', damage: 0, range: 6, area: 4, cooldown: 8, energy: 20, type: 'shield', duration: 5, description: 'Dinding pelindung.' },
      { id: 'seismic_slam', name: 'Seismic Slam', icon: '💥', damage: 35, range: 0, area: 7, cooldown: 7, energy: 25, type: 'aoe', description: 'Gelombang kejut.' },
      { id: 'titans_wrath', name: "Titan's Wrath", icon: '⛰', damage: 95, range: 8, area: 12, cooldown: 25, energy: 55, type: 'ultimate', description: 'Hantaman tanah besar.' }
    ]
  },
  ice: {
    id: 'ice', name: 'Es', color: 0x93c5fd,
    skills: [
      { id: 'ice_shard', name: 'Ice Shard', icon: '❄', damage: 27, range: 17, area: 1.2, cooldown: 1.7, energy: 11, type: 'projectile', description: 'Pecahan es.' },
      { id: 'frost_dash', name: 'Frost Dash', icon: '🧊', damage: 12, range: 8, area: 2.5, cooldown: 4.5, energy: 16, type: 'dash', description: 'Dash membekukan.' },
      { id: 'frozen_ground', name: 'Frozen Ground', icon: '❄', damage: 10, range: 0, area: 7, cooldown: 9, energy: 22, type: 'aoe', duration: 4, description: 'Lantai beku.' },
      { id: 'absolute_zero', name: 'Absolute Zero', icon: '🥶', damage: 70, range: 10, area: 9, cooldown: 23, energy: 50, type: 'ultimate', description: 'Pembekuan total.' }
    ]
  },
  lightning: {
    id: 'lightning', name: 'Petir', color: 0xfacc15,
    skills: [
      { id: 'lightning_bolt', name: 'Lightning Bolt', icon: '⚡', damage: 30, range: 22, area: 1, cooldown: 1.9, energy: 13, type: 'projectile', description: 'Sambaran petir.' },
      { id: 'thunder_step', name: 'Thunder Step', icon: '⚡', damage: 18, range: 9, area: 3, cooldown: 4, energy: 18, type: 'dash', description: 'Langkah guntur.' },
      { id: 'chain_lightning', name: 'Chain Lightning', icon: '⛓', damage: 20, range: 14, area: 8, cooldown: 7, energy: 26, type: 'chain', description: 'Petir berantai.' },
      { id: 'storm_judgment', name: 'Storm Judgment', icon: '⛈', damage: 90, range: 16, area: 11, cooldown: 22, energy: 55, type: 'ultimate', description: 'Penghakiman badai.' }
    ]
  },
  sand: {
    id: 'sand', name: 'Pasir', color: 0xfbbf24,
    skills: [
      { id: 'sand_bullet', name: 'Sand Bullet', icon: '🏜️', damage: 25, range: 15, area: 1.3, cooldown: 1.6, energy: 10, type: 'projectile', description: 'Peluru pasir.' },
      { id: 'sand_veil', name: 'Sand Veil', icon: '🌫️', damage: 0, range: 0, area: 5, cooldown: 10, energy: 20, type: 'buff', duration: 4, description: 'Tabir pasir.' },
      { id: 'quicksand_trap', name: 'Quicksand Trap', icon: '⌛', damage: 15, range: 12, area: 4, cooldown: 8, energy: 22, type: 'cc', duration: 3, description: 'Perangkap pasir.' },
      { id: 'desert_colossus', name: 'Desert Colossus', icon: '🗿', damage: 88, range: 10, area: 10, cooldown: 24, energy: 52, type: 'ultimate', description: 'Colossus pasir.' }
    ]
  },
  light: {
    id: 'light', name: 'Cahaya', color: 0xfef08a,
    skills: [
      { id: 'light_arrow', name: 'Light Arrow', icon: '✨', damage: 26, range: 20, area: 1, cooldown: 1.5, energy: 10, type: 'projectile', description: 'Panah cahaya.' },
      { id: 'radiant_shield', name: 'Radiant Shield', icon: '🛡', damage: 0, range: 0, area: 0, cooldown: 9, energy: 22, type: 'shield', duration: 5, description: 'Perisai cahaya.' },
      { id: 'flash_strike', name: 'Flash Strike', icon: '💫', damage: 40, range: 8, area: 3, cooldown: 6, energy: 20, type: 'melee', description: 'Serangan kilat.' },
      { id: 'solar_judgment', name: 'Solar Judgment', icon: '☀', damage: 92, range: 14, area: 12, cooldown: 25, energy: 55, type: 'ultimate', description: 'Penghakiman matahari.' }
    ]
  },
  darkness: {
    id: 'darkness', name: 'Kegelapan', color: 0xa855f7,
    skills: [
      { id: 'shadow_bolt', name: 'Shadow Bolt', icon: '🌑', damage: 29, range: 16, area: 1.4, cooldown: 1.8, energy: 12, type: 'projectile', description: 'Bolt bayangan.' },
      { id: 'dark_step', name: 'Dark Step', icon: '👤', damage: 14, range: 9, area: 2, cooldown: 4, energy: 16, type: 'dash', description: 'Langkah gelap.' },
      { id: 'abyssal_chains', name: 'Abyssal Chains', icon: '⛓', damage: 18, range: 11, area: 5, cooldown: 8, energy: 24, type: 'cc', duration: 2.8, description: 'Rantai abyssal.' },
      { id: 'eclipse', name: 'Eclipse', icon: '🌑', damage: 82, range: 12, area: 11, cooldown: 23, energy: 50, type: 'ultimate', description: 'Gerhana.' }
    ]
  },
  nature: {
    id: 'nature', name: 'Alam', color: 0x4ade80,
    skills: [
      { id: 'thorn_shot', name: 'Thorn Shot', icon: '🌿', damage: 24, range: 15, area: 1.2, cooldown: 1.6, energy: 10, type: 'projectile', description: 'Tembakan duri.' },
      { id: 'natures_grasp', name: "Nature's Grasp", icon: '🌱', damage: 10, range: 10, area: 4, cooldown: 7, energy: 18, type: 'cc', duration: 2.5, description: 'Cengkeraman alam.' },
      { id: 'healing_bloom', name: 'Healing Bloom', icon: '🌸', damage: -35, range: 0, area: 6, cooldown: 10, energy: 25, type: 'heal', description: 'Penyembuhan bunga.' },
      { id: 'ancient_forest', name: 'Ancient Forest', icon: '🌳', damage: 70, range: 10, area: 12, cooldown: 24, energy: 50, type: 'ultimate', description: 'Hutan kuno.' }
    ]
  },
  crystal: {
    id: 'crystal', name: 'Kristal', color: 0xe879f9,
    skills: [
      { id: 'crystal_spear', name: 'Crystal Spear', icon: '💎', damage: 31, range: 18, area: 1.3, cooldown: 2, energy: 13, type: 'projectile', description: 'Tombak kristal.' },
      { id: 'crystal_armor', name: 'Crystal Armor', icon: '🔷', damage: 0, range: 0, area: 0, cooldown: 11, energy: 22, type: 'shield', duration: 6, description: 'Armor kristal.' },
      { id: 'shard_explosion', name: 'Shard Explosion', icon: '💥', damage: 38, range: 8, area: 6, cooldown: 7, energy: 24, type: 'aoe', description: 'Ledakan pecahan.' },
      { id: 'crystal_dominion', name: 'Crystal Dominion', icon: '💠', damage: 95, range: 12, area: 10, cooldown: 26, energy: 55, type: 'ultimate', description: 'Dominasi kristal.' }
    ]
  },
  gravity: {
    id: 'gravity', name: 'Gravitasi', color: 0xc084fc,
    skills: [
      { id: 'gravity_orb', name: 'Gravity Orb', icon: '🟣', damage: 22, range: 14, area: 2.5, cooldown: 2.2, energy: 14, type: 'projectile', description: 'Orb gravitasi.' },
      { id: 'gravity_pull', name: 'Gravity Pull', icon: '⬇️', damage: 12, range: 12, area: 7, cooldown: 8, energy: 22, type: 'cc', duration: 2, description: 'Tarikan gravitasi.' },
      { id: 'gravity_crush', name: 'Gravity Crush', icon: '⬇️', damage: 45, range: 8, area: 5, cooldown: 9, energy: 28, type: 'aoe', description: 'Penghancur gravitasi.' },
      { id: 'singularity', name: 'Singularity', icon: '⚫', damage: 100, range: 10, area: 9, cooldown: 28, energy: 60, type: 'ultimate', description: 'Singularitas.' }
    ]
  }
};

/** Elemental reaction map (simplified) */
export const REACTIONS = {
  'fire+wind': { name: 'Spread', multiplier: 1.25, status: 'burning' },
  'water+ice': { name: 'Freeze', multiplier: 1.1, status: 'frozen' },
  'water+lightning': { name: 'Electrocute', multiplier: 1.35, status: 'shocked' },
  'earth+fire': { name: 'Magma', multiplier: 1.3, status: 'melt' },
  'sand+wind': { name: 'Sandstorm', multiplier: 1.2, status: 'blind' },
  'nature+water': { name: 'Bloom', multiplier: 1.15, status: 'growth' },
  'light+darkness': { name: 'Annihilation', multiplier: 1.5, status: 'void' }
};

export function getReaction(el1, el2) {
  const key1 = `${el1}+${el2}`;
  const key2 = `${el2}+${el1}`;
  return REACTIONS[key1] || REACTIONS[key2] || null;
}

export function getElementSkills(elementId) {
  return ELEMENTS[elementId]?.skills || ELEMENTS.fire.skills;
}
