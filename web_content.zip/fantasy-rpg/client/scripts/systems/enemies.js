/**
 * Aetherion — Enemy AI System
 */

import * as THREE from 'three';

export const ENEMY_TYPES = {
  slime: {
    name: 'Meadow Slime',
    hp: 45,
    damage: 8,
    speed: 3.2,
    aggroRange: 12,
    attackRange: 2.2,
    attackCd: 1.4,
    exp: 12,
    color: 0x4ade80
  },
  wolf: {
    name: 'Grass Wolf',
    hp: 70,
    damage: 14,
    speed: 5.5,
    aggroRange: 16,
    attackRange: 2.5,
    attackCd: 1.1,
    exp: 22,
    color: 0x78716c
  },
  elemental: {
    name: 'Ember Wisp',
    hp: 55,
    damage: 12,
    speed: 4.0,
    aggroRange: 14,
    attackRange: 8,
    attackCd: 1.8,
    exp: 18,
    color: 0xff6b35
  }
};

export class Enemy {
  constructor(scene, type, position) {
    this.scene = scene;
    this.type = type;
    this.config = ENEMY_TYPES[type] || ENEMY_TYPES.slime;
    this.hp = this.config.hp;
    this.maxHp = this.config.hp;
    this.isAlive = true;
    this.state = 'patrol';
    this.attackCooldown = 0;
    this.patrolTarget = null;
    this.patrolTimer = 0;
    this.aggroRange = this.config.aggroRange;
    this.attackRange = this.config.attackRange;
    this.speed = this.config.speed;
    this.damage = this.config.damage;
    this.expReward = this.config.exp;
    this.mesh = this._createMesh();
    this.mesh.position.copy(position);
    this.homePosition = position.clone();
    scene.add(this.mesh);
  }

  _createMesh() {
    const group = new THREE.Group();
    const c = this.config.color;

    if (this.type === 'slime') {
      const body = new THREE.Mesh(
        new THREE.SphereGeometry(0.7, 10, 8),
        new THREE.MeshStandardMaterial({ color: c, transparent: true, opacity: 0.85, roughness: 0.3 })
      );
      body.position.y = 0.7;
      body.castShadow = true;
      group.add(body);
      const eyeMat = new THREE.MeshBasicMaterial({ color: 0x111111 });
      const eye1 = new THREE.Mesh(new THREE.SphereGeometry(0.12, 6, 6), eyeMat);
      eye1.position.set(-0.25, 0.95, 0.5);
      const eye2 = eye1.clone();
      eye2.position.x = 0.25;
      group.add(eye1, eye2);
    } else if (this.type === 'wolf') {
      const body = new THREE.Mesh(
        new THREE.CapsuleGeometry(0.4, 0.8, 4, 8),
        new THREE.MeshStandardMaterial({ color: c, roughness: 0.8 })
      );
      body.position.y = 0.7;
      body.rotation.z = Math.PI / 2;
      body.castShadow = true;
      group.add(body);
      const head = new THREE.Mesh(
        new THREE.SphereGeometry(0.35, 8, 8),
        new THREE.MeshStandardMaterial({ color: c })
      );
      head.position.set(0.7, 0.9, 0);
      group.add(head);
    } else {
      const body = new THREE.Mesh(
        new THREE.BoxGeometry(1, 1.4, 0.8),
        new THREE.MeshStandardMaterial({ color: c })
      );
      body.position.y = 0.9;
      body.castShadow = true;
      group.add(body);
    }
    group.userData.radius = 0.9;
    return group;
  }

  update(dt, player, now) {
    if (!this.isAlive) return;
    this.attackCooldown = Math.max(0, this.attackCooldown - dt);
    const toPlayer = player.getPosition().clone().sub(this.mesh.position);
    toPlayer.y = 0;
    const dist = toPlayer.length();

    if (this.state === 'patrol') {
      if (dist < this.aggroRange) this.state = 'chase';
      else this._patrol(dt);
    } else if (this.state === 'chase') {
      if (dist > this.aggroRange * 1.8) {
        this.state = 'patrol';
        this.patrolTarget = null;
      } else if (dist < this.attackRange) {
        this.state = 'attack';
      } else {
        toPlayer.normalize();
        this.mesh.position.x += toPlayer.x * this.speed * dt;
        this.mesh.position.z += toPlayer.z * this.speed * dt;
        this.mesh.rotation.y = Math.atan2(toPlayer.x, toPlayer.z);
      }
    } else if (this.state === 'attack') {
      if (dist > this.attackRange * 1.3) this.state = 'chase';
      else if (this.attackCooldown <= 0) {
        const dmg = this.damage + Math.floor(Math.random() * 4);
        player.takeDamage(dmg, now);
        this.attackCooldown = this.config.attackCd;
        this.mesh.rotation.y = Math.atan2(toPlayer.x, toPlayer.z);
      }
    }
  }

  _patrol(dt) {
    this.patrolTimer -= dt;
    if (!this.patrolTarget || this.patrolTimer <= 0) {
      const angle = Math.random() * Math.PI * 2;
      const r = 4 + Math.random() * 6;
      this.patrolTarget = new THREE.Vector3(
        this.homePosition.x + Math.cos(angle) * r,
        0,
        this.homePosition.z + Math.sin(angle) * r
      );
      this.patrolTimer = 3 + Math.random() * 3;
    }
    const to = this.patrolTarget.clone().sub(this.mesh.position);
    to.y = 0;
    if (to.length() > 0.5) {
      to.normalize();
      this.mesh.position.x += to.x * this.speed * 0.5 * dt;
      this.mesh.position.z += to.z * this.speed * 0.5 * dt;
      this.mesh.rotation.y = Math.atan2(to.x, to.z);
    }
  }

  takeDamage(amount) {
    if (!this.isAlive) return;
    this.hp -= amount;
    this.mesh.traverse(c => {
      if (c.isMesh && c.material && c.material.emissive) {
        c.material.emissive.setHex(0xffffff);
        setTimeout(() => { if (c.material) c.material.emissive.setHex(0x000000); }, 80);
      }
    });
    if (this.hp <= 0) {
      this.hp = 0;
      this.isAlive = false;
      this.state = 'dead';
      this.mesh.visible = false;
    } else {
      this.state = 'chase';
    }
  }

  dispose() {
    this.scene.remove(this.mesh);
  }
}

export function spawnMeadowEnemies(scene) {
  const enemies = [];
  const positions = [
    [20, 10], [-15, 18], [30, -12], [-25, -8],
    [10, -30], [-30, 25], [40, 20], [-5, 35]
  ];
  positions.forEach(([x, z], i) => {
    const type = i % 3 === 0 ? 'wolf' : 'slime';
    enemies.push(new Enemy(scene, type, new THREE.Vector3(x, 0, z)));
  });
  return enemies;
}
