/**
 * Aetherion — Touch Input + Virtual Joystick + Camera Drag
 */

export class InputManager {
  constructor(canvas) {
    this.canvas = canvas;
    this.moveX = 0;
    this.moveY = 0;
    this.cameraDeltaX = 0;
    this.cameraDeltaY = 0;
    this.attackPressed = false;
    this.dashPressed = false;
    this.interactPressed = false;
    this.skillPressed = [false, false, false, false];

    this._joystickActive = false;
    this._joystickId = null;
    this._cameraId = null;
    this._lastCamX = 0;
    this._lastCamY = 0;
    this._joyCenter = { x: 0, y: 0 };
    this._joyRadius = 48;
    this.cameraSensitivity = 0.004;
    this.joystickSensitivity = 1.0;

    this._setupJoystick();
    this._setupCameraDrag();
    this._setupButtons();
  }

  _setupJoystick() {
    const zone = document.getElementById('joystick-zone');
    const base = document.getElementById('joystick-base');
    const knob = document.getElementById('joystick-knob');
    if (!zone || !base || !knob) return;

    const onStart = (e) => {
      e.preventDefault();
      const t = e.changedTouches ? e.changedTouches[0] : e;
      if (this._joystickActive) return;
      this._joystickActive = true;
      this._joystickId = t.identifier ?? 'mouse';
      const rect = base.getBoundingClientRect();
      this._joyCenter.x = rect.left + rect.width / 2;
      this._joyCenter.y = rect.top + rect.height / 2;
      this._updateKnob(t.clientX, t.clientY, knob);
    };

    const onMove = (e) => {
      if (!this._joystickActive) return;
      const touches = e.changedTouches || [e];
      for (const t of touches) {
        if ((t.identifier ?? 'mouse') === this._joystickId) {
          this._updateKnob(t.clientX, t.clientY, knob);
          break;
        }
      }
    };

    const onEnd = (e) => {
      const touches = e.changedTouches || [e];
      for (const t of touches) {
        if ((t.identifier ?? 'mouse') === this._joystickId) {
          this._joystickActive = false;
          this._joystickId = null;
          this.moveX = 0;
          this.moveY = 0;
          knob.style.transform = 'translate(-50%, -50%)';
          break;
        }
      }
    };

    zone.addEventListener('touchstart', onStart, { passive: false });
    zone.addEventListener('mousedown', onStart);
    window.addEventListener('touchmove', onMove, { passive: false });
    window.addEventListener('mousemove', onMove);
    window.addEventListener('touchend', onEnd);
    window.addEventListener('mouseup', onEnd);
    window.addEventListener('touchcancel', onEnd);
  }

  _updateKnob(clientX, clientY, knob) {
    let dx = clientX - this._joyCenter.x;
    let dy = clientY - this._joyCenter.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const max = this._joyRadius;
    if (dist > max) {
      dx = (dx / dist) * max;
      dy = (dy / dist) * max;
    }
    knob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
    this.moveX = (dx / max) * this.joystickSensitivity;
    this.moveY = (dy / max) * this.joystickSensitivity;
  }

  _setupCameraDrag() {
    const canvas = this.canvas;

    const onStart = (e) => {
      // Ignore if touching joystick or action buttons
      if (e.target.closest('#joystick-zone') || e.target.closest('#action-buttons') || e.target.closest('.hud-icon-btn')) return;
      const t = e.changedTouches ? e.changedTouches[0] : e;
      if (this._cameraId !== null) return;
      this._cameraId = t.identifier ?? 'mouse';
      this._lastCamX = t.clientX;
      this._lastCamY = t.clientY;
    };

    const onMove = (e) => {
      if (this._cameraId === null) return;
      const touches = e.changedTouches || [e];
      for (const t of touches) {
        if ((t.identifier ?? 'mouse') === this._cameraId) {
          this.cameraDeltaX += (t.clientX - this._lastCamX) * this.cameraSensitivity;
          this.cameraDeltaY += (t.clientY - this._lastCamY) * this.cameraSensitivity;
          this._lastCamX = t.clientX;
          this._lastCamY = t.clientY;
          break;
        }
      }
    };

    const onEnd = (e) => {
      const touches = e.changedTouches || [e];
      for (const t of touches) {
        if ((t.identifier ?? 'mouse') === this._cameraId) {
          this._cameraId = null;
          break;
        }
      }
    };

    canvas.addEventListener('touchstart', onStart, { passive: true });
    canvas.addEventListener('mousedown', onStart);
    window.addEventListener('touchmove', onMove, { passive: true });
    window.addEventListener('mousemove', onMove);
    window.addEventListener('touchend', onEnd);
    window.addEventListener('mouseup', onEnd);
  }

  _setupButtons() {
    const bind = (id, prop) => {
      const el = document.getElementById(id);
      if (!el) return;
      const down = (e) => { e.preventDefault(); this[prop] = true; };
      const up = () => { this[prop] = false; };
      el.addEventListener('touchstart', down, { passive: false });
      el.addEventListener('mousedown', down);
      el.addEventListener('touchend', up);
      el.addEventListener('mouseup', up);
      el.addEventListener('touchcancel', up);
    };

    bind('btn-attack', 'attackPressed');
    bind('btn-dash', 'dashPressed');
    bind('btn-interact', 'interactPressed');

    for (let i = 0; i < 4; i++) {
      const id = i === 3 ? 'btn-ultimate' : `btn-skill${i + 1}`;
      const el = document.getElementById(id);
      if (!el) continue;
      const down = (e) => { e.preventDefault(); this.skillPressed[i] = true; };
      const up = () => { this.skillPressed[i] = false; };
      el.addEventListener('touchstart', down, { passive: false });
      el.addEventListener('mousedown', down);
      el.addEventListener('touchend', up);
      el.addEventListener('mouseup', up);
    }
  }

  consumeCameraDelta() {
    const dx = this.cameraDeltaX;
    const dy = this.cameraDeltaY;
    this.cameraDeltaX = 0;
    this.cameraDeltaY = 0;
    return { dx, dy };
  }

  consumeAttack() {
    if (this.attackPressed) {
      this.attackPressed = false;
      return true;
    }
    return false;
  }

  consumeDash() {
    if (this.dashPressed) {
      this.dashPressed = false;
      return true;
    }
    return false;
  }

  consumeInteract() {
    if (this.interactPressed) {
      this.interactPressed = false;
      return true;
    }
    return false;
  }

  consumeSkill(index) {
    if (this.skillPressed[index]) {
      this.skillPressed[index] = false;
      return true;
    }
    return false;
  }

  setSensitivity(cam, joy) {
    this.cameraSensitivity = 0.001 + cam * 0.001;
    this.joystickSensitivity = 0.6 + joy * 0.08;
  }
}
