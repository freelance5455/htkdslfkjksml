/**
 * Aetherion — Local Storage System
 * LocalStorage + simple validation. No sensitive data stored.
 */

const STORAGE_KEY = 'aetherion_save_v1';
const SETTINGS_KEY = 'aetherion_settings_v1';

const DEFAULT_SAVE = {
  version: 1,
  playerName: 'Echo Walker',
  level: 1,
  exp: 0,
  coins: 50,
  unlockedCharacters: ['kael'],
  activeCharacter: 'kael',
  unlockedElements: ['fire'],
  activeElement: 'fire',
  inventory: {
    items: { potion: 3, ether: 1 },
    materials: { light_seed: 0, fire_crystal: 0 },
    quest: {}
  },
  quests: {
    active: ['main_01'],
    completed: [],
    progress: { main_01: { collected: 0, target: 5 } }
  },
  teleports: ['meadow_start'],
  storyFlags: {},
  stats: {
    monstersDefeated: 0,
    questsCompleted: 0,
    dungeonsCleared: 0
  },
  position: null // { x, y, z, region }
};

const DEFAULT_SETTINGS = {
  quality: 'medium',
  viewDistance: 120,
  particles: true,
  masterVolume: 70,
  musicVolume: 50,
  sfxVolume: 80,
  cameraSensitivity: 4,
  joystickSensitivity: 5
};

export function loadSave() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return structuredClone(DEFAULT_SAVE);
    const data = JSON.parse(raw);
    // Merge with defaults to handle missing keys after updates
    return deepMerge(structuredClone(DEFAULT_SAVE), data);
  } catch (e) {
    console.warn('[Storage] Failed to load save, using default:', e);
    return structuredClone(DEFAULT_SAVE);
  }
}

export function saveGame(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    return true;
  } catch (e) {
    console.error('[Storage] Save failed:', e);
    return false;
  }
}

export function loadSettings() {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return structuredClone(DEFAULT_SETTINGS);
    return deepMerge(structuredClone(DEFAULT_SETTINGS), JSON.parse(raw));
  } catch {
    return structuredClone(DEFAULT_SETTINGS);
  }
}

export function saveSettings(settings) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    return true;
  } catch {
    return false;
  }
}

export function resetSave() {
  localStorage.removeItem(STORAGE_KEY);
  return structuredClone(DEFAULT_SAVE);
}

function deepMerge(target, source) {
  for (const key of Object.keys(source)) {
    if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
      if (!target[key]) target[key] = {};
      deepMerge(target[key], source[key]);
    } else {
      target[key] = source[key];
    }
  }
  return target;
}
