/**
 * Aetherion — World / Scene Builder (Stage 1: Meadow region)
 */

import * as THREE from 'three';

export function createWorld(scene) {
  const world = {
    region: 'meadow',
    bounds: { minX: -80, maxX: 80, minZ: -80, maxZ: 80 },
    objects: [],
    collectibles: [],
    teleports: [],
    npcs: [],
    spawnPoint: new THREE.Vector3(0, 0, 0)
  };

  // Ground
  const groundGeo = new THREE.PlaneGeometry(200, 200, 32, 32);
  // Slight height variation
  const pos = groundGeo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const y = pos.getY(i);
    pos.setZ(i, Math.sin(x * 0.08) * Math.cos(y * 0.08) * 1.2 + Math.random() * 0.3);
  }
  groundGeo.computeVertexNormals();
  const groundMat = new THREE.MeshStandardMaterial({
    color: 0x3d7a4a,
    roughness: 0.9,
    flatShading: true
  });
  const ground = new THREE.Mesh(groundGeo, groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);
  world.ground = ground;

  // Sky-ish fog
  scene.fog = new THREE.FogExp2(0x87aacc, 0.012);
  scene.background = new THREE.Color(0x87aacc);

  // Ambient + directional light (sun)
  const ambient = new THREE.AmbientLight(0xb0c4de, 0.55);
  scene.add(ambient);
  const sun = new THREE.DirectionalLight(0xfff5e0, 1.1);
  sun.position.set(40, 60, 20);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.camera.near = 1;
  sun.shadow.camera.far = 150;
  sun.shadow.camera.left = -50;
  sun.shadow.camera.right = 50;
  sun.shadow.camera.top = 50;
  sun.shadow.camera.bottom = -50;
  scene.add(sun);
  world.sun = sun;

  // Trees (simple cones + cylinders)
  const treePositions = [
    [15, 12], [-20, 8], [25, -18], [-12, -25], [35, 5],
    [-30, 20], [8, 30], [-35, -10], [40, -30], [-8, 40],
    [50, 15], [-45, -25], [22, 45], [-28, 35], [5, -40]
  ];
  treePositions.forEach(([x, z]) => {
    const tree = createTree();
    tree.position.set(x, 0, z);
    scene.add(tree);
    world.objects.push(tree);
  });

  // Rocks
  for (let i = 0; i < 12; i++) {
    const rock = createRock();
    rock.position.set(
      (Math.random() - 0.5) * 100,
      0.3,
      (Math.random() - 0.5) * 100
    );
    rock.rotation.y = Math.random() * Math.PI;
    scene.add(rock);
    world.objects.push(rock);
  }

  // Collectible: Light Seeds (for main quest)
  for (let i = 0; i < 8; i++) {
    const seed = createCollectible(0xfef08a, 'light_seed');
    const angle = (i / 8) * Math.PI * 2;
    const r = 18 + Math.random() * 25;
    seed.position.set(Math.cos(angle) * r, 0.8, Math.sin(angle) * r);
    scene.add(seed);
    world.collectibles.push(seed);
  }

  // Teleport pad
  const tp = createTeleportPad();
  tp.position.set(0, 0.05, -15);
  tp.userData.teleportId = 'meadow_start';
  tp.userData.label = 'Meadow Gate';
  scene.add(tp);
  world.teleports.push(tp);

  // Second teleport (locked initially visual)
  const tp2 = createTeleportPad(0x555577);
  tp2.position.set(45, 0.05, 30);
  tp2.userData.teleportId = 'meadow_east';
  tp2.userData.label = 'East Ridge';
  tp2.userData.locked = true;
  scene.add(tp2);
  world.teleports.push(tp2);

  // Simple NPC marker
  const npc = createNPC();
  npc.position.set(-8, 0, -5);
  npc.userData.npcId = 'elder_mira';
  npc.userData.name = 'Elder Mira';
  scene.add(npc);
  world.npcs.push(npc);

  // Boundary markers (subtle)
  const edgeMat = new THREE.MeshBasicMaterial({ color: 0x445566, transparent: true, opacity: 0.3 });
  [-80, 80].forEach(v => {
    const wall1 = new THREE.Mesh(new THREE.BoxGeometry(2, 8, 160), edgeMat);
    wall1.position.set(v, 4, 0);
    scene.add(wall1);
    const wall2 = new THREE.Mesh(new THREE.BoxGeometry(160, 8, 2), edgeMat);
    wall2.position.set(0, 4, v);
    scene.add(wall2);
  });

  return world;
}

function createTree() {
  const group = new THREE.Group();
  const trunk = new THREE.Mesh(
    new THREE.CylinderGeometry(0.3, 0.5, 2.5, 6),
    new THREE.MeshStandardMaterial({ color: 0x5c4033, roughness: 0.9 })
  );
  trunk.position.y = 1.25;
  trunk.castShadow = true;
  group.add(trunk);

  const leaves = new THREE.Mesh(
    new THREE.ConeGeometry(2.2, 4, 7),
    new THREE.MeshStandardMaterial({ color: 0x2d6a3e, roughness: 0.85 })
  );
  leaves.position.y = 4.2;
  leaves.castShadow = true;
  group.add(leaves);

  // Collision radius
  group.userData.radius = 1.5;
  group.userData.isObstacle = true;
  return group;
}

function createRock() {
  const geo = new THREE.DodecahedronGeometry(0.6 + Math.random() * 0.8, 0);
  const mat = new THREE.MeshStandardMaterial({ color: 0x6b7280, roughness: 0.95, flatShading: true });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.castShadow = true;
  mesh.userData.radius = 1;
  mesh.userData.isObstacle = true;
  return mesh;
}

function createCollectible(color, type) {
  const geo = new THREE.OctahedronGeometry(0.4, 0);
  const mat = new THREE.MeshStandardMaterial({
    color,
    emissive: color,
    emissiveIntensity: 0.5,
    transparent: true,
    opacity: 0.9
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.userData.collectible = true;
  mesh.userData.type = type;
  mesh.userData.radius = 1.2;
  mesh.userData.bobOffset = Math.random() * Math.PI * 2;
  return mesh;
}

function createTeleportPad(color = 0x7b5cff) {
  const group = new THREE.Group();
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(1.2, 2.0, 24),
    new THREE.MeshStandardMaterial({
      color,
      emissive: color,
      emissiveIntensity: 0.4,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.85
    })
  );
  ring.rotation.x = -Math.PI / 2;
  group.add(ring);

  const center = new THREE.Mesh(
    new THREE.CircleGeometry(1.0, 24),
    new THREE.MeshStandardMaterial({
      color: 0x1e1b4b,
      emissive: color,
      emissiveIntensity: 0.2,
      side: THREE.DoubleSide
    })
  );
  center.rotation.x = -Math.PI / 2;
  center.position.y = 0.02;
  group.add(center);

  group.userData.isTeleport = true;
  group.userData.radius = 2.2;
  return group;
}

function createNPC() {
  const group = new THREE.Group();
  const body = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.4, 1.0, 4, 8),
    new THREE.MeshStandardMaterial({ color: 0xc4b5fd })
  );
  body.position.y = 1.1;
  group.add(body);
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.35, 8, 8),
    new THREE.MeshStandardMaterial({ color: 0xf5d0c5 })
  );
  head.position.y = 2.0;
  group.add(head);
  // Marker
  const marker = new THREE.Mesh(
    new THREE.ConeGeometry(0.2, 0.4, 4),
    new THREE.MeshBasicMaterial({ color: 0xfbbf24 })
  );
  marker.position.y = 2.7;
  marker.rotation.x = Math.PI;
  group.add(marker);
  group.userData.isNPC = true;
  group.userData.radius = 1.5;
  return group;
}

export function updateWorldVisuals(world, time) {
  // Bob collectibles
  world.collectibles.forEach(c => {
    if (!c.visible) return;
    c.position.y = 0.8 + Math.sin(time * 2 + c.userData.bobOffset) * 0.25;
    c.rotation.y += 0.02;
  });
  // Pulse teleports
  world.teleports.forEach(tp => {
    const ring = tp.children[0];
    if (ring && ring.material) {
      ring.material.emissiveIntensity = 0.3 + Math.sin(time * 3) * 0.2;
    }
  });
}
