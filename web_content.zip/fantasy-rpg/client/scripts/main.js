/**
 * Aetherion — Main Entry & Game Loop
 * Stage 1 Foundation
 */

import * as THREE from 'three';
import { loadSave, saveGame, loadSettings, saveSettings } from './core/storage.js';
import { InputManager } from './core/input.js';
import { createWorld, updateWorldVisuals } from './core/world.js';
import { Player } from './systems/player.js';
import { spawnMeadowEnemies } from './systems/enemies.js';
import { QuestManager, QUESTS } from './systems/quests.js';
import { CHARACTERS, getCharacter } from './systems/characters.js';
import { ELEMENTS, getElementSkills } from './systems/elements.js';

// ===== State =====
let saveData = loadSave();
let settings = loadSettings();
let scene, camera, renderer, player, enemies, world, input, quests;
let cameraYaw = 0;
let cameraPitch = 0; // FPP horizontal
let isPlaying = false;
let lastTime = 0;
let animId = null;
const EYE_HEIGHT = 1.65;

// ===== DOM =====
const $ = (id) => document.getElementById(id);
const loadingScreen = $('loading-screen');
const loadingFill = $('loading-fill');
const loadingText = $('loading-text');
const lobby = $('lobby');
const gameContainer = $('game-container');

// ===== Boot =====
async function boot() {
  setLoading(20, 'Menyiapkan renderer...');
  await delay(200);
  setLoading(40, 'Memuat dunia...');
  await delay(150);
  setLoading(60, 'Menyiapkan kontrol...');
  await delay(100);
  setLoading(80, 'Hampir siap...');
  await delay(150);
  setLoading(100, 'Selesai!');
  await delay(300);

  loadingScreen.classList.add('hidden');
  lobby.classList.remove('hidden');
  updateLobbyUI();
  bindLobbyButtons();
  bindOverlays();
  lockLandscape();
  preventBrowserChrome();
}

/** Paksa landscape + cegah perilaku browser */
function lockLandscape() {
  const tryLock = () => {
    const o = screen.orientation || screen.mozOrientation || screen.msOrientation;
    if (o && o.lock) {
      o.lock('landscape').catch(() => {});
    } else if (screen.lockOrientation) {
      try { screen.lockOrientation('landscape'); } catch (_) {}
    } else if (screen.mozLockOrientation) {
      try { screen.mozLockOrientation('landscape'); } catch (_) {}
    }
  };
  tryLock();
  window.addEventListener('orientationchange', tryLock);
  document.addEventListener('click', tryLock, { once: true });
  document.addEventListener('touchstart', tryLock, { once: true });
}

function preventBrowserChrome() {
  // Blok scroll / pull-to-refresh / gesture browser
  document.addEventListener('touchmove', (e) => {
    if (e.target.closest('.menu-panel, .overlay, #dialog-box')) return;
    e.preventDefault();
  }, { passive: false });
  document.addEventListener('gesturestart', (e) => e.preventDefault());
  document.addEventListener('gesturechange', (e) => e.preventDefault());
  // Cegah double-tap zoom
  let lastTouch = 0;
  document.addEventListener('touchend', (e) => {
    const now = Date.now();
    if (now - lastTouch <= 300) e.preventDefault();
    lastTouch = now;
  }, { passive: false });
}

function setLoading(pct, text) {
  loadingFill.style.width = pct + '%';
  loadingText.textContent = text;
}

function delay(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// ===== Lobby =====
function updateLobbyUI() {
  $('lobby-player-name').textContent = saveData.playerName;
  $('lobby-level').textContent = saveData.level;
  $('lobby-coins').textContent = saveData.coins;
  const char = getCharacter(saveData.activeCharacter);
  $('lobby-char-name').textContent = char.name;
}

function bindLobbyButtons() {
  $('btn-start').onclick = startGame;
  $('btn-characters').onclick = () => openCharSelect();
  $('btn-elements').onclick = () => showToast('Elemen & Skill — buka dari dalam game (Tahap 2)');
  $('btn-inventory').onclick = () => openInventory();
  $('btn-quests').onclick = () => {
    const q = new QuestManager(saveData).getActiveQuest();
    if (q) showToast(`${q.name}: ${q.progress.collected}/${q.progress.target}`);
    else showToast('Tidak ada misi aktif');
  };
  $('btn-profile').onclick = () => {
    showToast(`${saveData.playerName} | Lv.${saveData.level} | EXP ${saveData.exp} | Monster: ${saveData.stats.monstersDefeated}`);
  };
  $('btn-settings').onclick = () => openSettings();
  $('btn-multiplayer').onclick = () => openMultiplayer();
  $('btn-events').onclick = () => showToast('Event akan tersedia di tahap berikutnya');
}

// ===== Start Game =====
function startGame() {
  lobby.classList.add('hidden');
  gameContainer.classList.remove('hidden');

  // Renderer
  const canvas = $('game-canvas');
  renderer = new THREE.WebGLRenderer({ canvas, antialias: settings.quality !== 'low', powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, settings.quality === 'high' ? 2 : 1.5));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.shadowMap.enabled = settings.quality !== 'low';
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  scene = new THREE.Scene();
  // FPP: FOV lebih lebar, near clip kecil
  camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.05, settings.viewDistance || 120);

  world = createWorld(scene);
  player = new Player(scene, saveData);
  // First-person: sembunyikan badan pemain (hanya "mata")
  if (player.mesh) player.mesh.visible = false;
  if (saveData.position) {
    player.setPosition(saveData.position.x, saveData.position.y, saveData.position.z);
  } else {
    player.setPosition(0, 0, 5);
  }

  enemies = spawnMeadowEnemies(scene);
  quests = new QuestManager(saveData);
  input = new InputManager(canvas);
  input.setSensitivity(settings.cameraSensitivity, settings.joystickSensitivity);

  updateQuestUI();
  updateSkillUI();
  updateHUD();

  // Auto-save interval
  setInterval(() => {
    if (isPlaying) persistSave();
  }, 20000);

  isPlaying = true;
  lastTime = performance.now();
  animId = requestAnimationFrame(gameLoop);

  // Show starting dialog if first time
  if (!saveData.storyFlags?.met_mira) {
    setTimeout(() => {
      showDialog('Elder Mira', QUESTS.main_01.dialogueStart.text, () => {
        saveData.storyFlags = saveData.storyFlags || {};
        saveData.storyFlags.met_mira = true;
        persistSave();
      });
    }, 800);
  }

  window.addEventListener('resize', onResize);
  showToast('FPP: geser layar untuk melihat. Joystick untuk bergerak.');
}

function onResize() {
  if (!camera || !renderer) return;
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

// ===== Game Loop =====
function gameLoop(now) {
  if (!isPlaying) return;
  animId = requestAnimationFrame(gameLoop);

  const dt = Math.min(0.05, (now - lastTime) / 1000);
  lastTime = now;
  const t = now / 1000;

  // ===== FPP Camera (first-person) =====
  const { dx, dy } = input.consumeCameraDelta();
  cameraYaw -= dx;
  // Pitch FPP: geser jari ke atas = lihat ke atas
  cameraPitch = Math.max(-1.2, Math.min(1.2, cameraPitch - dy));

  const pos = player.getPosition();
  camera.position.set(pos.x, pos.y + EYE_HEIGHT, pos.z);

  // Arah pandang dari yaw + pitch
  const lookX = pos.x - Math.sin(cameraYaw) * Math.cos(cameraPitch);
  const lookY = pos.y + EYE_HEIGHT + Math.sin(cameraPitch);
  const lookZ = pos.z - Math.cos(cameraYaw) * Math.cos(cameraPitch);
  camera.lookAt(lookX, lookY, lookZ);

  // Karakter menghadap arah kamera (untuk skill/projectile)
  player.facing.set(-Math.sin(cameraYaw), 0, -Math.cos(cameraYaw));
  if (player.mesh) player.mesh.rotation.y = cameraYaw + Math.PI;

  // Update systems
  player.update(dt, input, cameraYaw, world, enemies, t);
  enemies.forEach(e => e.update(dt, player, t));
  updateWorldVisuals(world, t);

  // Collectibles
  checkCollectibles();
  // Interact
  if (input.consumeInteract()) handleInteract();

  // Check enemy deaths for rewards
  enemies.forEach(e => {
    if (!e.isAlive && !e._rewarded) {
      e._rewarded = true;
      saveData.exp += e.expReward;
      saveData.stats.monstersDefeated++;
      checkLevelUp();
      showFloatingText(e.mesh.position, `+${e.expReward} EXP`, 'heal');
    }
  });

  // Respawn player if dead
  if (!player.state.isAlive) {
    player.state.hp = player.state.maxHp;
    player.state.isAlive = true;
    player.setPosition(0, 0, 5);
    showToast('Kamu bangkit kembali di Meadow Gate');
  }

  updateHUD();
  updateCooldowns();
  updateTargetUI();

  renderer.render(scene, camera);
}

// ===== Collectibles & Interact =====
function checkCollectibles() {
  const pos = player.getPosition();
  for (const c of world.collectibles) {
    if (!c.visible) continue;
    if (pos.distanceTo(c.position) < 1.5) {
      c.visible = false;
      const type = c.userData.type;
      // Inventory
      saveData.inventory.materials[type] = (saveData.inventory.materials[type] || 0) + 1;
      const prog = quests.onCollect(type);
      if (prog) {
        updateQuestUI();
        showToast(`Benih Cahaya: ${prog.collected}/${prog.target}`);
        if (quests.canComplete('main_01')) {
          showToast('Misi siap diserahkan ke Elder Mira!');
        }
      } else {
        showToast('Mengumpulkan material');
      }
    }
  }
}

function handleInteract() {
  const pos = player.getPosition();

  // NPC
  for (const npc of world.npcs) {
    if (pos.distanceTo(npc.position) < 2.5) {
      if (quests.canComplete('main_01')) {
        const rewards = quests.complete('main_01');
        if (rewards) {
          saveData.exp += rewards.exp || 0;
          saveData.coins += rewards.coins || 0;
          if (rewards.items) {
            for (const [k, v] of Object.entries(rewards.items)) {
              saveData.inventory.items[k] = (saveData.inventory.items[k] || 0) + v;
            }
          }
          saveData.stats.questsCompleted++;
          saveData.quests = quests.toSave();
          // Unlock second teleport
          const tp2 = world.teleports.find(t => t.userData.teleportId === 'meadow_east');
          if (tp2) {
            tp2.userData.locked = false;
            tp2.children[0].material.color.setHex(0x7b5cff);
            tp2.children[0].material.emissive.setHex(0x7b5cff);
            if (!saveData.teleports.includes('meadow_east')) saveData.teleports.push('meadow_east');
          }
          checkLevelUp();
          persistSave();
          updateQuestUI();
          showDialog('Elder Mira', QUESTS.main_01.dialogueComplete.text);
        }
      } else {
        const q = quests.getActiveQuest();
        const text = q
          ? `Masih kurang... ${q.progress.collected}/${q.progress.target} Benih Cahaya.`
          : 'Selamat datang, Echo Walker.';
        showDialog('Elder Mira', text);
      }
      return;
    }
  }

  // Teleport
  for (const tp of world.teleports) {
    if (pos.distanceTo(tp.position) < 2.5) {
      if (tp.userData.locked) {
        showToast('Teleportasi masih terkunci');
        return;
      }
      // Simple teleport to other pad or stay
      const other = world.teleports.find(t => t !== tp && !t.userData.locked);
      if (other) {
        player.setPosition(other.position.x, 0, other.position.z + 2);
        showToast(`Teleportasi ke ${other.userData.label}`);
      }
      return;
    }
  }

  showToast('Tidak ada yang bisa diinteraksi');
}

function checkLevelUp() {
  const need = saveData.level * 80;
  if (saveData.exp >= need) {
    saveData.exp -= need;
    saveData.level++;
    player.state.level = saveData.level;
    player.state.maxHp = Math.floor(player.state.maxHp * 1.08);
    player.state.hp = player.state.maxHp;
    player.state.attack = Math.floor(player.state.attack * 1.06);
    showToast(`Level Up! Sekarang Lv.${saveData.level}`);
  }
}

// ===== HUD Updates =====
function updateHUD() {
  const s = player.state;
  $('hp-fill').style.width = (s.hp / s.maxHp * 100) + '%';
  $('hp-text').textContent = `${Math.ceil(s.hp)} / ${s.maxHp}`;
  $('energy-fill').style.width = (s.energy / s.maxEnergy * 100) + '%';
  $('energy-text').textContent = `${Math.floor(s.energy)} / ${s.maxEnergy}`;
  $('hud-char-name').textContent = s.name.split(' ')[0];
  $('hud-element').textContent = ELEMENTS[s.element]?.name || s.element;
}

function updateCooldowns() {
  const cds = player.state.cooldowns;
  const ids = ['cd-skill1', 'cd-skill2', 'cd-skill3', 'cd-ultimate'];
  ids.forEach((id, i) => {
    const el = $(id);
    if (!el) return;
    if (cds[i] > 0) {
      el.classList.add('active');
      el.textContent = Math.ceil(cds[i]);
    } else {
      el.classList.remove('active');
      el.textContent = '';
    }
  });
}

function updateTargetUI() {
  const ind = $('target-indicator');
  if (player.target && player.target.isAlive) {
    ind.classList.remove('hidden');
    $('target-name').textContent = player.target.config.name;
    $('target-hp-fill').style.width = (player.target.hp / player.target.maxHp * 100) + '%';
  } else {
    ind.classList.add('hidden');
  }
}

function updateQuestUI() {
  const q = quests.getActiveQuest();
  const tracker = $('quest-tracker');
  if (q) {
    tracker.classList.remove('hidden');
    $('quest-title').textContent = q.name;
    $('quest-desc').textContent = q.description;
    $('quest-progress').textContent = `${q.progress.collected} / ${q.progress.target}`;
  } else {
    tracker.classList.add('hidden');
  }
}

function updateSkillUI() {
  const skills = player.skills;
  const icons = document.querySelectorAll('.skill-btn .skill-icon, .ultimate-btn .skill-icon');
  skills.forEach((s, i) => {
    if (icons[i]) icons[i].textContent = s.icon;
  });
}

// ===== Dialog =====
function showDialog(name, text, onDone) {
  const box = $('dialog-box');
  $('dialog-name').textContent = name;
  $('dialog-text').textContent = text;
  $('dialog-choices').innerHTML = '';
  box.classList.remove('hidden');
  const next = $('dialog-next');
  next.onclick = () => {
    box.classList.add('hidden');
    if (onDone) onDone();
  };
}

// ===== Overlays =====
function bindOverlays() {
  $('btn-pause').onclick = () => $('pause-menu').classList.remove('hidden');
  $('btn-resume').onclick = () => $('pause-menu').classList.add('hidden');
  $('btn-to-lobby').onclick = returnToLobby;
  $('btn-settings-pause').onclick = () => {
    $('pause-menu').classList.add('hidden');
    openSettings();
  };

  $('btn-map').onclick = openMap;
  $('btn-close-map').onclick = () => $('map-overlay').classList.add('hidden');
  $('btn-inv').onclick = openInventory;
  $('btn-close-inv').onclick = () => $('inventory-overlay').classList.add('hidden');
  $('btn-char-switch').onclick = openCharSelect;
  $('btn-close-char').onclick = () => $('char-select-overlay').classList.add('hidden');
  $('btn-chat').onclick = () => showToast('Chat tersedia di mode multiplayer');
  $('btn-mic').onclick = () => showToast('Voice chat membutuhkan multiplayer + izin mikrofon');

  $('btn-save-settings').onclick = () => {
    settings.quality = $('setting-quality').value;
    settings.viewDistance = +$('setting-viewdist').value;
    settings.particles = $('setting-particles').checked;
    settings.masterVolume = +$('setting-master').value;
    settings.musicVolume = +$('setting-music').value;
    settings.sfxVolume = +$('setting-sfx').value;
    settings.cameraSensitivity = +$('setting-camsens').value;
    settings.joystickSensitivity = +$('setting-joysens').value;
    saveSettings(settings);
    if (input) input.setSensitivity(settings.cameraSensitivity, settings.joystickSensitivity);
    if (camera) camera.far = settings.viewDistance;
    showToast('Pengaturan disimpan');
    $('settings-overlay').classList.add('hidden');
  };
  $('btn-close-settings').onclick = () => $('settings-overlay').classList.add('hidden');
  $('btn-close-mp').onclick = () => $('mp-overlay').classList.add('hidden');

  // MP buttons (placeholder functional UI)
  $('btn-lan-create').onclick = () => showToast('LAN: Buat room — butuh WebSocket lokal (lihat server/)');
  $('btn-lan-join').onclick = () => showToast('LAN: Masukkan kode lalu hubungkan ke host');
  $('btn-online-create').onclick = () => tryOnlineConnect(true);
  $('btn-online-join').onclick = () => tryOnlineConnect(false);
}

function openSettings() {
  $('setting-quality').value = settings.quality;
  $('setting-viewdist').value = settings.viewDistance;
  $('setting-particles').checked = settings.particles;
  $('setting-master').value = settings.masterVolume;
  $('setting-music').value = settings.musicVolume;
  $('setting-sfx').value = settings.sfxVolume;
  $('setting-camsens').value = settings.cameraSensitivity;
  $('setting-joysens').value = settings.joystickSensitivity;
  $('settings-overlay').classList.remove('hidden');
}

function openInventory() {
  const content = $('inv-content');
  content.innerHTML = '';
  const mats = saveData.inventory.materials || {};
  const items = saveData.inventory.items || {};
  const all = { ...items, ...mats };
  if (Object.keys(all).length === 0) {
    content.innerHTML = '<p style="color:#94a3b8;grid-column:1/-1;text-align:center">Inventaris kosong</p>';
  } else {
    for (const [k, v] of Object.entries(all)) {
      if (v <= 0) continue;
      const div = document.createElement('div');
      div.className = 'inv-item';
      div.innerHTML = `<div>${k.replace(/_/g, ' ')}</div><div class="qty">×${v}</div>`;
      content.appendChild(div);
    }
  }
  $('inventory-overlay').classList.remove('hidden');
}

function openCharSelect() {
  const list = $('char-list');
  list.innerHTML = '';
  for (const [id, c] of Object.entries(CHARACTERS)) {
    const unlocked = saveData.unlockedCharacters.includes(id) || c.unlocked;
    const card = document.createElement('div');
    card.className = 'char-card' + (saveData.activeCharacter === id ? ' selected' : '') + (unlocked ? '' : ' locked');
    card.innerHTML = `
      <div class="char-icon" style="background:linear-gradient(135deg, #${c.color.toString(16).padStart(6,'0')}, #333)"></div>
      <div>${c.name}</div>
      <div style="font-size:0.75rem;color:#94a3b8">${c.role}</div>
      ${unlocked ? '' : '<div style="color:#f87171;font-size:0.75rem">Terkunci</div>'}
    `;
    if (unlocked) {
      card.onclick = () => {
        saveData.activeCharacter = id;
        if (player) {
          // Simple switch — full remesh in later stage
          player.state.charId = id;
          player.state.name = c.name;
          player.switchElement(c.element);
          saveData.activeElement = c.element;
        }
        persistSave();
        updateLobbyUI();
        $('char-select-overlay').classList.add('hidden');
        showToast(`Karakter: ${c.name}`);
      };
    }
    list.appendChild(card);
  }
  $('char-select-overlay').classList.remove('hidden');
}

function openMap() {
  const canvas = $('map-canvas');
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(0, 0, 600, 400);
  // Simple region
  ctx.fillStyle = '#1a3a2a';
  ctx.fillRect(50, 50, 500, 300);
  ctx.strokeStyle = '#4ade80';
  ctx.strokeRect(50, 50, 500, 300);
  ctx.fillStyle = '#e2e8f0';
  ctx.font = '14px sans-serif';
  ctx.fillText('Padang Rumput (Meadow)', 60, 40);
  // Player pos
  if (player) {
    const px = 50 + ((player.getPosition().x + 80) / 160) * 500;
    const pz = 50 + ((player.getPosition().z + 80) / 160) * 300;
    ctx.fillStyle = '#7b5cff';
    ctx.beginPath();
    ctx.arc(px, pz, 6, 0, Math.PI * 2);
    ctx.fill();
  }
  // Teleports
  world?.teleports.forEach(tp => {
    const tx = 50 + ((tp.position.x + 80) / 160) * 500;
    const tz = 50 + ((tp.position.z + 80) / 160) * 300;
    ctx.fillStyle = tp.userData.locked ? '#555' : '#a78bfa';
    ctx.fillRect(tx - 4, tz - 4, 8, 8);
  });
  $('map-overlay').classList.remove('hidden');
}

function openMultiplayer() {
  $('server-status').textContent = 'Tidak terhubung';
  $('mp-overlay').classList.remove('hidden');
}

function tryOnlineConnect(create) {
  const url = $('online-server').value || 'ws://localhost:3001';
  showToast('Menghubungkan ke ' + url + '...');
  try {
    const ws = new WebSocket(url);
    ws.onopen = () => {
      $('server-status').textContent = 'Terhubung';
      showToast('Terhubung ke server!');
      ws.send(JSON.stringify({ type: create ? 'create_room' : 'join_room', code: $('online-code').value, name: saveData.playerName }));
    };
    ws.onerror = () => {
      $('server-status').textContent = 'Gagal';
      showToast('Server tidak tersedia. Jalankan: cd server && npm install && node server.js');
    };
    ws.onclose = () => {
      $('server-status').textContent = 'Terputus';
    };
  } catch (e) {
    showToast('WebSocket error: ' + e.message);
  }
}

function returnToLobby() {
  isPlaying = false;
  if (animId) cancelAnimationFrame(animId);
  persistSave();
  if (player) player.dispose();
  enemies?.forEach(e => e.dispose());
  $('pause-menu').classList.add('hidden');
  gameContainer.classList.add('hidden');
  lobby.classList.remove('hidden');
  updateLobbyUI();
  window.removeEventListener('resize', onResize);
}

function persistSave() {
  if (player) {
    const p = player.getPosition();
    saveData.position = { x: p.x, y: p.y, z: p.z, region: 'meadow' };
    saveData.quests = quests.toSave();
  }
  saveGame(saveData);
}

// ===== Helpers =====
function showToast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.add('hidden'), 2800);
}

function showFloatingText(worldPos, text, type) {
  // Screen-space approximation
  const el = document.createElement('div');
  el.className = `float-text ${type}`;
  el.textContent = text;
  el.style.left = '50%';
  el.style.top = '40%';
  $('floating-texts').appendChild(el);
  setTimeout(() => el.remove(), 1000);
}

// ===== Start =====
boot();
