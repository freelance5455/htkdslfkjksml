# Aetherion: Echoes of the Primordial Crystal

**Open-World Fantasy RPG** — HTML5 / Three.js / Node.js WebSocket

Game fantasi open-world orisinal dengan sistem 12 elemen sihir, eksplorasi, dungeon, misi, multiplayer LAN & Online, serta voice chat.

## Identitas Orisinal
- **Dunia**: Aetherion
- **Premis**: Kristal Asal pecah, 12 kekuatan elemental tersebar. Pemain adalah Echo Walker yang harus menyeimbangkan kembali dunia.
- **Elemen**: Fire, Water, Wind, Earth, Ice, Lightning, Sand, Light, Darkness, Nature, Crystal, Gravity
- **Tidak ada aset berhak cipta dari game lain.**

## Arsitektur Teknis

| Komponen              | Teknologi                          | Alasan |
|-----------------------|------------------------------------|--------|
| Rendering 3D          | Three.js (r160+)                   | Ringan, mobile-friendly, WebGL |
| Physics sederhana     | Custom + Three.js Raycasting       | Performa Android menengah |
| UI & Touch Controls   | Vanilla JS + CSS                   | Kontrol penuh, tanpa library berat |
| Local Storage         | LocalStorage + IndexedDB           | Offline progress |
| Multiplayer Online    | Node.js + ws (WebSocket)           | Server otoritatif sendiri |
| Multiplayer LAN       | WebSocket + local signaling        | Peer discovery via host |
| Voice Chat            | WebRTC + signaling via game server | Real-time audio |
| APK Wrapper           | Capacitor                          | HTML5 → Android native |

## Struktur Proyek

```
fantasy-rpg/
├── client/                 # Frontend game
│   ├── index.html
│   ├── styles/
│   ├── scripts/
│   │   ├── core/           # Engine, scene, input, camera
│   │   ├── systems/        # Combat, elements, enemies, quests, inventory
│   │   ├── ui/             # Lobby, HUD, menus
│   │   └── multiplayer/    # Network client
│   └── assets/
├── server/                 # Backend multiplayer
│   ├── server.js
│   ├── rooms.js
│   ├── players.js
│   └── package.json
├── docs/
│   ├── APK_BUILD_GUIDE.md
│   ├── MULTIPLAYER_GUIDE.md
│   └── VOICE_CHAT_GUIDE.md
└── README.md
```

## Cara Menjalankan (Development)

### Client (Browser)
```bash
cd client
# Buka index.html dengan live server atau:
npx serve .
# atau python -m http.server 8080
```

### Server Multiplayer
```bash
cd server
npm install
node server.js
# Default: ws://localhost:3001
```

## Status Fitur (Tahap Saat Ini)

### ✅ Tahap 1 – Fondasi (Selesai)
- [x] Struktur proyek modular
- [x] Lobby profesional tema fantasi
- [x] Kontrol touchscreen + Virtual Joystick
- [x] Kamera orbit (geser layar)
- [x] Karakter 3D sederhana + animasi dasar
- [x] Dunia awal (Padang Rumput + elemen lingkungan)
- [x] Sistem HP / Energy
- [x] Basic combat (serangan + 4 skill Fire)
- [x] 1 musuh AI (patrol, chase, attack)
- [x] 1 misi utama yang bisa diselesaikan
- [x] Sistem teleportasi dasar
- [x] LocalStorage progress
- [x] Menu Settings, Inventory, Character, Map
- [x] Audio system (placeholder + siap aset)

### 🔄 Tahap Selanjutnya
- Tahap 2: Full lobby, profil, 12 elemen (48 skill), dialog
- Tahap 3–4: Dunia multi-wilayah, dungeon, boss, material, crafting
- Tahap 5–6: Multiplayer LAN & Online penuh + PvP
- Tahap 7: Voice Chat WebRTC
- Tahap 8: Optimasi + APK build

## Catatan Penting
- Multiplayer Online **membutuhkan server Node.js aktif**.
- Voice Chat membutuhkan HTTPS (atau localhost) + izin mikrofon.
- Data lokal hilang jika cache browser / data aplikasi dihapus.
- Tidak menggunakan Firebase.

---

**Dikembangkan sebagai proyek open-source fondasi.**  
Lanjutkan pengembangan sesuai roadmap tahap di atas.
