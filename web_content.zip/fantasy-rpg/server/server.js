/**
 * Aetherion Multiplayer Server
 * Authoritative WebSocket server — NO Firebase
 *
 * Run: npm install && node server.js
 * Default port: 3001
 */

const { WebSocketServer } = require('ws');
const http = require('http');
const { randomBytes } = require('crypto');

const PORT = process.env.PORT || 3001;
const MAX_PLAYERS_PER_ROOM = 8;
const TICK_RATE = 20; // Hz

const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('Aetherion Multiplayer Server OK\n');
});

const wss = new WebSocketServer({ server });

/** @type {Map<string, Room>} */
const rooms = new Map();

class Room {
  constructor(code, hostId) {
    this.code = code;
    this.hostId = hostId;
    this.players = new Map(); // id -> player state
    this.started = false;
    this.tick = 0;
  }

  addPlayer(id, name, ws) {
    if (this.players.size >= MAX_PLAYERS_PER_ROOM) return false;
    this.players.set(id, {
      id,
      name: sanitizeName(name),
      ws,
      x: 0, y: 0, z: 5,
      rotY: 0,
      hp: 100,
      maxHp: 100,
      element: 'fire',
      charId: 'kael',
      lastInput: 0
    });
    return true;
  }

  removePlayer(id) {
    this.players.delete(id);
    if (this.players.size === 0) {
      rooms.delete(this.code);
      return;
    }
    if (id === this.hostId) {
      // Transfer host
      this.hostId = this.players.keys().next().value;
    }
  }

  broadcast(msg, excludeId = null) {
    const data = JSON.stringify(msg);
    for (const [id, p] of this.players) {
      if (id === excludeId) continue;
      if (p.ws.readyState === 1) p.ws.send(data);
    }
  }

  getPlayerList() {
    return [...this.players.values()].map(p => ({
      id: p.id,
      name: p.name,
      hp: p.hp,
      maxHp: p.maxHp,
      element: p.element,
      charId: p.charId
    }));
  }
}

function generateCode() {
  return randomBytes(3).toString('hex').toUpperCase();
}

function sanitizeName(name) {
  if (!name || typeof name !== 'string') return 'Player';
  return name.replace(/[<>\"\'&]/g, '').slice(0, 16) || 'Player';
}

function validatePosition(x, y, z) {
  // Basic anti-cheat: clamp to world bounds
  return {
    x: Math.max(-80, Math.min(80, Number(x) || 0)),
    y: Math.max(0, Math.min(20, Number(y) || 0)),
    z: Math.max(-80, Math.min(80, Number(z) || 0))
  };
}

wss.on('connection', (ws) => {
  let playerId = randomBytes(8).toString('hex');
  let roomCode = null;

  ws.send(JSON.stringify({ type: 'welcome', playerId }));

  ws.on('message', (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      return;
    }

    switch (msg.type) {
      case 'create_room': {
        const code = generateCode();
        const room = new Room(code, playerId);
        room.addPlayer(playerId, msg.name, ws);
        rooms.set(code, room);
        roomCode = code;
        ws.send(JSON.stringify({
          type: 'room_created',
          code,
          players: room.getPlayerList()
        }));
        break;
      }

      case 'join_room': {
        const code = (msg.code || '').toUpperCase();
        const room = rooms.get(code);
        if (!room) {
          ws.send(JSON.stringify({ type: 'error', message: 'Room tidak ditemukan' }));
          return;
        }
        if (room.started) {
          ws.send(JSON.stringify({ type: 'error', message: 'Game sudah dimulai' }));
          return;
        }
        if (!room.addPlayer(playerId, msg.name, ws)) {
          ws.send(JSON.stringify({ type: 'error', message: 'Room penuh' }));
          return;
        }
        roomCode = code;
        room.broadcast({ type: 'player_joined', players: room.getPlayerList() });
        ws.send(JSON.stringify({
          type: 'room_joined',
          code,
          players: room.getPlayerList()
        }));
        break;
      }

      case 'start_game': {
        const room = rooms.get(roomCode);
        if (!room || room.hostId !== playerId) return;
        room.started = true;
        room.broadcast({ type: 'game_start' });
        break;
      }

      case 'player_state': {
        const room = rooms.get(roomCode);
        if (!room) return;
        const p = room.players.get(playerId);
        if (!p) return;
        const pos = validatePosition(msg.x, msg.y, msg.z);
        p.x = pos.x;
        p.y = pos.y;
        p.z = pos.z;
        p.rotY = Number(msg.rotY) || 0;
        p.hp = Math.max(0, Math.min(p.maxHp, Number(msg.hp) || p.hp));
        p.element = msg.element || p.element;
        p.lastInput = Date.now();
        // Broadcast to others (not self)
        room.broadcast({
          type: 'player_update',
          id: playerId,
          x: p.x, y: p.y, z: p.z,
          rotY: p.rotY, hp: p.hp, element: p.element
        }, playerId);
        break;
      }

      case 'combat_event': {
        // Server validates basic combat events
        const room = rooms.get(roomCode);
        if (!room) return;
        // Rate limit simple
        room.broadcast({
          type: 'combat_event',
          from: playerId,
          skill: msg.skill,
          targetId: msg.targetId,
          x: msg.x, z: msg.z
        }, playerId);
        break;
      }

      case 'chat': {
        const room = rooms.get(roomCode);
        if (!room) return;
        const text = String(msg.text || '').slice(0, 120);
        if (!text) return;
        room.broadcast({
          type: 'chat',
          from: playerId,
          name: room.players.get(playerId)?.name,
          text
        });
        break;
      }

      case 'leave': {
        cleanup();
        break;
      }
    }
  });

  ws.on('close', cleanup);
  ws.on('error', cleanup);

  function cleanup() {
    if (roomCode) {
      const room = rooms.get(roomCode);
      if (room) {
        room.removePlayer(playerId);
        room.broadcast({ type: 'player_left', id: playerId, players: room.getPlayerList() });
      }
      roomCode = null;
    }
  }
});

// Heartbeat / stale cleanup
setInterval(() => {
  const now = Date.now();
  for (const room of rooms.values()) {
    for (const [id, p] of room.players) {
      if (p.lastInput && now - p.lastInput > 60000) {
        // Stale player
        room.removePlayer(id);
        room.broadcast({ type: 'player_left', id, players: room.getPlayerList() });
      }
    }
  }
}, 15000);

server.listen(PORT, () => {
  console.log(`Aetherion Server listening on port ${PORT}`);
  console.log(`WebSocket: ws://localhost:${PORT}`);
  console.log('No Firebase. Own authoritative backend.');
});
