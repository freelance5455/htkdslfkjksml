D3R COMPLEANNI - D3R CyberTech

Contenuto:
- index.html: app web responsive e utilizzabile offline dopo averla salvata localmente.

Avvio:
1. Estrai lo ZIP.
2. Apri index.html con Chrome, Edge o un browser moderno.
3. Aggiungi compleanni. I dati vengono salvati nel browser/dispositivo.
4. Usa Esporta backup per salvare i dati in un file JSON e Importa backup per ripristinarli.

Nota notifiche:
Questa versione web può richiedere il permesso notifiche del browser, ma non garantisce promemoria quando il browser/app è chiuso. Per notifiche Android affidabili è necessario confezionare una versione APK con notifiche locali.
