const {onSchedule}=require('firebase-functions/v2/scheduler');
const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {defineSecret}=require('firebase-functions/params');
const admin=require('firebase-admin');admin.initializeApp();
const KEY=defineSecret('ANTHROPIC_API_KEY');
const M={
 en:{c:'Class soon',d0:'Due today',d1:'Due tomorrow',x:'Exam in # days'},
 bn:{c:'ক্লাস শুরু হচ্ছে',d0:'আজ জমা',d1:'কাল জমা',x:'# দিন পরে পরীক্ষা'},
 hi:{c:'क्लास शुरू होने वाली है',d0:'आज जमा करें',d1:'कल जमा करें',x:'# दिन में परीक्षा'}};
const hash=s=>{let x=0;for(const ch of s)x=(x*31+ch.codePointAt(0))|0;return (x>>>0).toString(36)};
const days=(a,b)=>Math.round((Date.parse(a)-Date.parse(b))/864e5);

// Runs every 5 minutes: class in next 15 min; deadlines/exams once a day after 8:00 (user's local time)
exports.remind=onSchedule({schedule:'every 5 minutes',timeZone:'UTC'},async()=>{
 const snap=await admin.firestore().collection('users').get();
 for(const d of snap.docs){
  const u=d.data();if(!u.token)continue;
  const m=M[u.lang]||M.en,S=u.data||{},sent=u.sent||{};
  const now=new Date(Date.now()+(u.off||0)*6e4);
  const day=now.getUTCDay(),min=now.getUTCHours()*60+now.getUTCMinutes(),ds=now.toISOString().slice(0,10),out=[];
  (S.tt||[]).forEach(c=>{if(c.d!==day)return;const p=c.t.split(':'),df=p[0]*60+ +p[1]-min;
   if(df>=0&&df<=15)out.push([ds+c.t+c.s,m.c+': '+c.t+' — '+c.s])});
  if(min>=480&&min<540){
   (S.tasks||[]).forEach(x=>{if(x.ok||!x.d)return;const n=days(x.d,ds);if(n===0||n===1)out.push([ds+'t'+x.n,(n?m.d1:m.d0)+': '+x.n])});
   (S.exams||[]).forEach(e=>{const n=days(e.d,ds);if(n>=0&&n<=3)out.push([ds+'e'+e.s,e.s+': '+m.x.replace('#',n)])});
  }
  for(const [k,body] of out){
   const key='k'+hash(k);if(sent[key])continue;
   try{
    await admin.messaging().send({token:u.token,notification:{title:'CampusMate AI',body}});
    await d.ref.set({sent:{[key]:1}},{merge:true});
   }catch(e){
    if(/registration-token|not-registered/.test(e.code||''))await d.ref.update({token:admin.firestore.FieldValue.delete()});
   }
  }
 }
});

// ---- AI Buddy (text, photo question, PDF/notes). Key stays on the server. ----
const MODEL='claude-haiku-4-5-20251001'; // swap for a stronger model if you want better answers
const LN={bn:'Bengali',en:'English',hi:'Hindi'};
const MODE={
 S:'Explain the topic in very simple words with one everyday example.',
 T:'The student gives English text. Explain its meaning in simple language (not word-by-word translation), then list difficult words with meanings.',
 X:'Write exam-ready answers: a short answer (2-3 lines), a 5-mark long answer, and the important points.',
 C:'This is a coding question. Use this order: Code, Output, Explanation, Common mistakes.'};
exports.askAI=onCall({region:'asia-south1',secrets:[KEY],maxInstances:10,timeoutSeconds:90,memory:'512MiB'},async req=>{
 if(!req.auth)throw new HttpsError('unauthenticated','login');
 const {mode,lang,text,hist,file}=req.data||{};
 if(typeof text!=='string'||!text.trim()||text.length>4000)throw new HttpsError('invalid-argument','text');
 const ref=admin.firestore().doc('users/'+req.auth.uid),ds=new Date().toISOString().slice(0,10);
 const u=(await ref.get()).data()||{},use=u.ai&&u.ai.d===ds?u.ai.n:0;
 if(use>=40)throw new HttpsError('resource-exhausted','limit'); // 40 AI requests per user per day
 await ref.set({ai:{d:ds,n:use+1}},{merge:true});
 const sys='You are CampusMate AI, a friendly study buddy for college students in India and Bangladesh. Reply in '+(LN[lang]||'English')+'; keep technical terms in English. Use simple words and short steps. Plain text only, no markdown symbols like ** or #. Help the student understand instead of only giving the answer. If asked who created or built you, say (in the reply language): I am CampusMate AI, created and designed by Imran Hossain. Add nothing else about the creator. '+(MODE[mode]||'')+(file?' If the attachment shows a question, first write the question, then explain step by step, then give the final answer.':'');
 const msgs=[];
 (Array.isArray(hist)?hist:[]).slice(-6).forEach(h=>{
  if(!h||typeof h.c!=='string'||(h.r!=='u'&&h.r!=='a'))return;
  const role=h.r==='u'?'user':'assistant';
  if(!msgs.length&&role!=='user')return;
  if(msgs.length&&msgs[msgs.length-1].role===role)return;
  msgs.push({role,content:h.c.slice(0,3000)});
 });
 if(msgs.length&&msgs[msgs.length-1].role==='user')msgs.pop();
 const content=[];
 if(file&&typeof file.data==='string'&&file.data.length<7e6)content.push(file.type==='application/pdf'
  ?{type:'document',source:{type:'base64',media_type:'application/pdf',data:file.data}}
  :{type:'image',source:{type:'base64',media_type:'image/jpeg',data:file.data}});
 content.push({type:'text',text});msgs.push({role:'user',content});
 const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'x-api-key':KEY.value(),'anthropic-version':'2023-06-01','content-type':'application/json'},body:JSON.stringify({model:MODEL,max_tokens:1200,system:sys,messages:msgs})});
 if(!r.ok){console.error(await r.text());throw new HttpsError('internal','ai')}
 const j=await r.json();
 return {text:(j.content||[]).map(b=>b.text||'').join('').trim()};
});
