# CampusMate AI (Firebase)

1. Firebase Console: create project, upgrade to Blaze plan (needed for Cloud Functions).
2. Authentication > Sign-in method > enable Phone. Add your hosting domain under Authorized domains.
3. Firestore Database > create database.
4. Project settings > Add web app. Copy the config into BOTH public/index.html and public/firebase-messaging-sw.js (replace every PASTE_...).
5. Project settings > Cloud Messaging > Web Push certificates > Generate key pair. Paste it as VAPID_KEY in public/index.html.
6. AI Buddy key: get an API key from console.anthropic.com, then run `firebase functions:secrets:set ANTHROPIC_API_KEY` and paste it. (Key stays on the server, never in the app.)
7. In this folder: `npm i -g firebase-tools`, `firebase login`, `firebase use --add`, `(cd functions && npm i)`, `firebase deploy`.
8. Open the hosted URL, log in with OTP, press "Turn on notifications".

- Data: Firestore users/{uid}. Reminders: `remind` function (every 5 min). AI: `askAI` function (asia-south1, 40 requests per user per day; change in functions/index.js).
- Model is set by MODEL in functions/index.js.
