package com.sareedelivery.app;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.content.ComponentName;
import android.os.Environment;
import android.widget.Toast;
import android.util.Base64;
import java.io.OutputStream;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.PermissionRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import java.util.ArrayList;
import java.util.Locale;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.view.Gravity;
import android.graphics.Color;

public class MainActivity extends Activity {
    private static final int NOTIFICATION_PERMISSION_REQUEST = 301;
    private static final String CHANNEL_ID = "saree_delivery_updates";
    private WebView webView;
    private SpeechRecognizer speechRecognizer;
    private boolean keepListening = false;
    private TextToSpeech textToSpeech;
    private static final int OVERLAY_REQUEST = 7441;
    private boolean pendingOverlayStart = false;
    private boolean pendingVoiceOpen = false;
    private boolean webReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(232, 245, 255));
        getWindow().setNavigationBarColor(Color.rgb(232, 245, 255));
        getWindow().getDecorView().setSystemUiVisibility(
                android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR |
                android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        );
        createNotificationChannel();
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS && textToSpeech != null) textToSpeech.setLanguage(new Locale("ar", "YE"));
        });
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 302);
        }
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 303);
        }

        FrameLayout splash = new FrameLayout(this);
        splash.setBackgroundColor(Color.rgb(245, 250, 255));
        ImageView logo = new ImageView(this);
        logo.setImageResource(com.sareedelivery.app.R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams logoParams = new FrameLayout.LayoutParams(
                (int)(240 * getResources().getDisplayMetrics().density),
                (int)(240 * getResources().getDisplayMetrics().density), Gravity.CENTER);
        splash.addView(logo, logoParams);
        setContentView(splash);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (isFinishing() || isDestroyed()) return;
            webView = new WebView(this);
            webView.setBackgroundColor(Color.rgb(245, 250, 255));
            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setAllowFileAccess(true);
            settings.setAllowContentAccess(true);
            settings.setJavaScriptCanOpenWindowsAutomatically(false);
            settings.setSupportMultipleWindows(false);
            webView.addJavascriptInterface(new SareeBridge(), "SareeNative");
            webView.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    webReady = true;
                    if (pendingVoiceOpen) {
                        pendingVoiceOpen = false;
                        view.evaluateJavascript("if(window.openFloatingVoiceAssistant){window.openFloatingVoiceAssistant();}", null);
                    }
                }
            });
            webView.setWebChromeClient(new WebChromeClient() {
                @Override public void onPermissionRequest(PermissionRequest request) {
                    runOnUiThread(() -> {
                        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 302);
                        } else {
                            for (String resource : request.getResources()) {
                                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                                    request.grant(new String[]{resource});
                                    return;
                                }
                            }
                            request.deny();
                        }
                    });
                }
            });
            setContentView(webView);
            webView.loadUrl("file:///android_asset/index.html");
            handleAssistantIntent(getIntent());
        }, 500);
    }

    private void handleAssistantIntent(Intent intent) {
        if (intent != null && intent.getBooleanExtra("OPEN_VOICE_ASSISTANT", false)) {
            intent.removeExtra("OPEN_VOICE_ASSISTANT");
            pendingVoiceOpen = true;
            if (webView != null && webReady) {
                webView.evaluateJavascript("if(window.openFloatingVoiceAssistant){window.openFloatingVoiceAssistant();}", null);
                pendingVoiceOpen = false;
            }
        }
    }

    private void enableFloatingAssistant() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            pendingOverlayStart = true;
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, OVERLAY_REQUEST);
            return;
        }
        Intent service = new Intent(this, FloatingAssistantService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        getSharedPreferences("saree_assistant", MODE_PRIVATE).edit().putBoolean("enabled", true).apply();
        runJs("if(window.onFloatingAssistantState){window.onFloatingAssistantState(true)}");
    }

    private void disableFloatingAssistant() {
        stopService(new Intent(this, FloatingAssistantService.class));
        getSharedPreferences("saree_assistant", MODE_PRIVATE).edit().putBoolean("enabled", false).apply();
        runJs("if(window.onFloatingAssistantState){window.onFloatingAssistantState(false)}");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST) {
            if (pendingOverlayStart && Build.VERSION.SDK_INT >= 23 && Settings.canDrawOverlays(this)) enableFloatingAssistant();
            else runJs("if(window.onFloatingAssistantState){window.onFloatingAssistantState(false)}");
            pendingOverlayStart = false;
        }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent); handleAssistantIntent(intent);
    }

    private void startNativeRecognition(String language) {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 302);
            runJs("window.onNativeSpeechError && window.onNativeSpeechError('permission');");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            runJs("window.onNativeSpeechError && window.onNativeSpeechError('unavailable');");
            return;
        }
        try {
            if (speechRecognizer != null) { speechRecognizer.destroy(); speechRecognizer = null; }
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { runJs("window.onNativeSpeechReady && window.onNativeSpeechReady();"); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onError(int error) {
                    if (keepListening && error != SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS && error != SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                        new Handler(Looper.getMainLooper()).postDelayed(() -> startNativeRecognition(language), 650);
                    } else runJs("window.onNativeSpeechError && window.onNativeSpeechError('recognition');");
                }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) {
                        String value = matches.get(0).replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
                        runJs("window.onNativeSpeechResult && window.onNativeSpeechResult('" + value + "');");
                    }
                    if (keepListening) new Handler(Looper.getMainLooper()).postDelayed(() -> startNativeRecognition(language), 350);
                }
                @Override public void onPartialResults(Bundle partialResults) {
                    ArrayList<String> matches = partialResults == null ? null : partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) {
                        String value = matches.get(0).replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
                        runJs("window.onNativeSpeechPartial && window.onNativeSpeechPartial('" + value + "');");
                    }
                }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language == null ? "ar-SA" : language);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language == null ? "ar-SA" : language);
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            speechRecognizer.startListening(intent);
        } catch (Exception ex) {
            runJs("window.onNativeSpeechError && window.onNativeSpeechError('start');");
        }
    }

    private void runJs(String script) {
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(script, null); });
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "تنبيهات سريع دليفري", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("تنبيهات الطلبات والحركات المالية والمزامنة");
            channel.enableVibration(true);
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private class SareeBridge {
        @JavascriptInterface public void enableFloatingAssistant() { runOnUiThread(() -> MainActivity.this.enableFloatingAssistant()); }
        @JavascriptInterface public void disableFloatingAssistant() { runOnUiThread(() -> MainActivity.this.disableFloatingAssistant()); }
        @JavascriptInterface public boolean hasOverlayPermission() { return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(MainActivity.this); }
        @JavascriptInterface public boolean isFloatingAssistantRunning() { return getSharedPreferences("saree_assistant", MODE_PRIVATE).getBoolean("enabled", false); }

        @JavascriptInterface
        public void notify(String title, String body) {
            runOnUiThread(() -> showAppNotification(title, body));
        }

        @JavascriptInterface
        public void openExternal(String url) {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void speakText(String text, float rate, float pitch, String language) {
            runOnUiThread(() -> {
                try {
                    if (textToSpeech == null) return;
                    Locale locale = "ar-YE".equals(language) ? new Locale("ar", "YE") : new Locale("ar", "SA");
                    textToSpeech.setLanguage(locale);
                    textToSpeech.setSpeechRate(Math.max(0.7f, Math.min(1.4f, rate)));
                    textToSpeech.setPitch(Math.max(0.7f, Math.min(1.4f, pitch)));
                    textToSpeech.speak(text == null ? "" : text, TextToSpeech.QUEUE_FLUSH, null, "saree-voice");
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void startListening(boolean continuous, String language) {
            runOnUiThread(() -> {
                keepListening = continuous;
                startNativeRecognition(language);
            });
        }

        @JavascriptInterface
        public void stopListening() {
            runOnUiThread(() -> {
                keepListening = false;
                if (speechRecognizer != null) try { speechRecognizer.cancel(); speechRecognizer.stopListening(); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void saveInvoiceImage(String base64, String filename, String caption) {
            runOnUiThread(() -> {
                try {
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, filename == null ? "saree-invoice.png" : filename);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Saree Delivery");
                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("تعذر إنشاء ملف الصورة");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) { if (out == null) throw new Exception("تعذر حفظ الصورة"); out.write(bytes); }
                    Toast.makeText(MainActivity.this, "تم حفظ الفاتورة في معرض الصور", Toast.LENGTH_LONG).show();
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("image/png"); share.putExtra(Intent.EXTRA_STREAM, uri); share.putExtra(Intent.EXTRA_TEXT, caption == null ? "" : caption);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, "مشاركة فاتورة سريع دليفري"));
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this, "تعذر حفظ الفاتورة: " + ex.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void shareText(String text) {
            runOnUiThread(() -> {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain"); share.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                startActivity(Intent.createChooser(share, "مشاركة سريع دليفري"));
            });
        }

        @JavascriptInterface
        public void vibrate(int milliseconds) {
            runOnUiThread(() -> {
                try {
                    Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    if (vibrator != null && vibrator.hasVibrator()) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            vibrator.vibrate(VibrationEffect.createOneShot(
                                    Math.max(30, Math.min(milliseconds, 500)),
                                    VibrationEffect.DEFAULT_AMPLITUDE));
                        } else {
                            vibrator.vibrate(Math.max(30, Math.min(milliseconds, 500)));
                        }
                    }
                } catch (Exception ignored) { }
            });
        }
    }

    private void showAppNotification(String title, String body) {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
            return;
        }
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(com.sareedelivery.app.R.mipmap.ic_launcher)
                .setContentTitle(title == null ? "سريع دليفري" : title)
                .setContentText(body == null ? "" : body)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_STATUS);
        manager.notify((int) (System.currentTimeMillis() & 0x7fffffff), builder.build());
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        keepListening = false;
        if (speechRecognizer != null) { speechRecognizer.destroy(); speechRecognizer = null; }
        if (textToSpeech != null) { textToSpeech.stop(); textToSpeech.shutdown(); textToSpeech = null; }
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
