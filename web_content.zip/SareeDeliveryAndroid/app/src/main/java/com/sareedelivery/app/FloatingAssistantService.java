package com.sareedelivery.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.content.Context;
import android.content.pm.ServiceInfo;

/** User-enabled, draggable launcher bubble. Speech is handled by MainActivity after opening. */
public class FloatingAssistantService extends Service {
    private static final String CHANNEL = "saree_floating_assistant";
    private static final int NOTIFICATION_ID = 7412;
    private WindowManager windowManager;
    private View bubble;
    private WindowManager.LayoutParams params;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Intent open = new Intent(this, MainActivity.class).putExtra("OPEN_VOICE_ASSISTANT", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pending = PendingIntent.getActivity(this, 7413, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        builder.setSmallIcon(com.sareedelivery.app.R.mipmap.ic_launcher)
                .setContentTitle("مساعد سريع دليفري العائم")
                .setContentText("الفقاعة مفعّلة. اضغط عليها لفتح المساعد الصوتي.")
                .setOngoing(true).setCategory(Notification.CATEGORY_SERVICE).setContentIntent(pending);
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, builder.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else startForeground(NOTIFICATION_ID, builder.build());
        showBubble();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "المساعد العائم", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("إشعار دائم عند تفعيل فقاعة سريع دليفري");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private void showBubble() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { stopSelf(); return; }
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        TextView v = new TextView(this);
        v.setText("🎙"); v.setTextSize(25); v.setTextColor(Color.WHITE); v.setGravity(Gravity.CENTER);
        v.setBackground(makeBubbleBackground()); v.setElevation(12f);
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(dp(58), dp(58), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END; params.x = dp(12); params.y = dp(220);
        v.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY; boolean moved;
            @Override public boolean onTouch(View view, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN: downX=e.getRawX(); downY=e.getRawY(); startX=params.x; startY=params.y; moved=false; return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx=(int)(downX-e.getRawX()), dy=(int)(e.getRawY()-downY);
                        if (Math.abs(dx)+Math.abs(dy)>10) moved=true;
                        params.x=Math.max(0,startX+dx); params.y=Math.max(0,startY+dy);
                        try { windowManager.updateViewLayout(bubble,params); } catch(Exception ignored){}
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) openAssistant();
                        return true;
                }
                return true;
            }
        });
        bubble = v;
        try { windowManager.addView(bubble, params); } catch (Exception e) { stopSelf(); }
    }

    private android.graphics.drawable.GradientDrawable makeBubbleBackground() {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        d.setColors(new int[]{Color.rgb(23,72,116), Color.rgb(91,180,228)});
        d.setGradientType(android.graphics.drawable.GradientDrawable.LINEAR_GRADIENT);
        d.setStroke(dp(2), Color.WHITE); return d;
    }
    private int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private void openAssistant() {
        Intent i = new Intent(this, MainActivity.class).putExtra("OPEN_VOICE_ASSISTANT", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() {
        if (windowManager != null && bubble != null) try { windowManager.removeView(bubble); } catch(Exception ignored){}
        bubble=null; super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
