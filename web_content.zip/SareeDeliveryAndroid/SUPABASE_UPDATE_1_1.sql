-- تحديث قاعدة بيانات سريع دليفري لإضافات الإصدار 1.1
-- شغّل هذا الملف مرة واحدة من Supabase > SQL Editor > New query.
-- لا يحذف أي جدول أو سجل موجود.

ALTER TABLE public.orders
ADD COLUMN IF NOT EXISTS shop_name text;

CREATE TABLE IF NOT EXISTS public.shops (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    name text NOT NULL,
    phone text,
    address text,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.cash_movements (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    movement_type text NOT NULL CHECK (movement_type IN ('in', 'out')),
    description text NOT NULL DEFAULT '',
    amount numeric NOT NULL CHECK (amount >= 0),
    movement_date date NOT NULL DEFAULT CURRENT_DATE,
    created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.shops ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cash_movements ENABLE ROW LEVEL SECURITY;

GRANT USAGE ON SCHEMA public TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.orders TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.shops TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.cash_movements TO authenticated;

DROP POLICY IF EXISTS "Users manage own shops" ON public.shops;
CREATE POLICY "Users manage own shops"
ON public.shops
FOR ALL TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users manage own cash movements" ON public.cash_movements;
CREATE POLICY "Users manage own cash movements"
ON public.cash_movements
FOR ALL TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);
