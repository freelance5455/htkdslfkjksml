Kisan Mitra WhatsApp Routing

9304493273: Purchase and General Enquiry only.
8210769716: Purchase, General Enquiry, Service and Complaint.

For Purchase/Enquiry, the app prepares WhatsApp messages for both numbers. The user must press Send in WhatsApp; websites cannot silently send WhatsApp messages.
Service/Complaint open WhatsApp only for 8210769716.
