PORSCHE LEGENDS — MYTHOLOGY BORSCH
===================================
هذه حزمة موحدة تجمع النسخ التي أرسلها المستخدم والأنظمة التي أضيفت للمشروع.

1) PORSCHE_LEGENDS_WEB/
   - نسخة HTML الحالية V4 القابلة للتغليف كتطبيق WebView/HTML-to-APK.
   - تشمل index.html وconfig.xml وmanifest.json والأيقونة والصورة.

2) PORSCHE_LEGENDS_UNITY/
   - هيكل مشروع Unity ومجموعة سكربتات القيادة والكاميرا والتحكم والطقس والضرر والصوت والخريطة والأداء.
   - تمت إضافة MobileCameraSystem وMobileTouchController وMythologyBorschMobile وMythologyBorschSetup وSafeCore.

ملاحظة مهمة:
هذه الحزمة ليست APK بحد ذاتها. HTML يمكن تغليفه عبر أداة HTML/WebView مناسبة، بينما Unity يحتاج Unity Editor/Build Automation لبناء APK.
لم يتم اختراع أصول 3D أو أصوات حقيقية غير موجودة في الملفات الأصلية.
