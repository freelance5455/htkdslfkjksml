using UnityEngine;
using UnityEngine.EventSystems;
namespace MythologyBorsch {
    public class MB_MobileControls : MonoBehaviour, IPointerDownHandler, IPointerUpHandler {
        public enum ActionType { Gas, Brake, Handbrake, Left, Right }
        public ActionType action;
        public MB_CarController car;
        public void OnPointerDown(PointerEventData e) { Set(true); }
        public void OnPointerUp(PointerEventData e) { Set(false); }
        void Set(bool down) {
            if(!car) return;
            switch(action) {
                case ActionType.Gas: car.SetGas(down?1:0); break;
                case ActionType.Brake: car.SetBrake(down?1:0); break;
                case ActionType.Handbrake: car.SetHandbrake(down?1:0); break;
                case ActionType.Left: car.SetSteering(down?-1:0); break;
                case ActionType.Right: car.SetSteering(down?1:0); break;
            }
        }
    }
}