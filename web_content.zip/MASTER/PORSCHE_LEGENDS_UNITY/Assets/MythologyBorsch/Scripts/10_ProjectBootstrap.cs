using UnityEngine;
namespace MythologyBorsch {
    public class MB_ProjectBootstrap : MonoBehaviour {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void Boot() {
            Application.targetFrameRate=60;
            QualitySettings.vSyncCount=0;
            Time.fixedDeltaTime=0.02f;
        }
    }
}