using UnityEngine;
namespace MythologyBorsch {
    public class MB_CameraRig : MonoBehaviour {
        public Transform target;
        public Vector3 offset = new Vector3(0,3.8f,8.5f);
        public float smooth = 6f;
        public float lookHeight = 1f;
        void LateUpdate() {
            if(!target) return;
            Vector3 desired = target.TransformPoint(offset);
            transform.position = Vector3.Lerp(transform.position, desired, 1-Mathf.Exp(-smooth*Time.deltaTime));
            transform.LookAt(target.position + Vector3.up*lookHeight);
        }
    }
}