using UnityEngine;
namespace MythologyBorsch {
    public class MB_WorldBootstrap : MonoBehaviour {
        public int roadLength = 1200;
        public int sideRoads = 8;
        public Material roadMaterial;
        void Start() {
            for(int i=-sideRoads;i<=sideRoads;i++) {
                if(i==0) continue;
                CreateRoad(new Vector3(i*70f,0,0), new Vector3(8,0.1f,roadLength), "SideRoad_"+i);
            }
            CreateRoad(Vector3.zero, new Vector3(18,0.1f,roadLength), "MainRoad");
        }
        void CreateRoad(Vector3 pos, Vector3 scale, string n) {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name=n; go.transform.SetParent(transform); go.transform.position=pos; go.transform.localScale=scale;
            if(roadMaterial) go.GetComponent<Renderer>().sharedMaterial=roadMaterial;
        }
    }
}