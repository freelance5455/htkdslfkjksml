using UnityEngine;
namespace MythologyBorsch {
    public class MB_Damage : MonoBehaviour {
        public float maxHealth=100f;
        public float health=100f;
        public GameObject impactFX;
        public AudioSource crashAudio;
        void OnCollisionEnter(Collision c) {
            float force=c.relativeVelocity.magnitude;
            if(force<3f) return;
            health=Mathf.Max(0,health-force*1.5f);
            if(impactFX) Instantiate(impactFX,c.contacts[0].point,Quaternion.identity);
            if(crashAudio) crashAudio.Play();
            if(health<=0) SendMessage("OnVehicleDestroyed",SendMessageOptions.DontRequireReceiver);
        }
        public void Repair(){health=maxHealth;}
    }
}