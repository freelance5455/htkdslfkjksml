using UnityEngine;
namespace MythologyBorsch {
    public class MB_Weather : MonoBehaviour {
        public enum Weather { Clear, Rain, Storm, Fog }
        public Weather current = Weather.Clear;
        public Light sun;
        public ParticleSystem rain;
        public ParticleSystem storm;
        public float dayLengthMinutes = 10f;
        float timer;
        void Update() {
            timer += Time.deltaTime;
            float cycle = Mathf.Repeat(timer/(dayLengthMinutes*60f),2f);
            bool day = cycle < 1f;
            if(sun) sun.intensity = Mathf.Lerp(sun.intensity, day?1.15f:0.08f, Time.deltaTime*0.5f);
        }
        public void SetWeather(int value) {
            current=(Weather)Mathf.Clamp(value,0,3);
            if(rain) rain.gameObject.SetActive(current==Weather.Rain || current==Weather.Storm);
            if(storm) storm.gameObject.SetActive(current==Weather.Storm);
            RenderSettings.fog = current==Weather.Fog || current==Weather.Storm;
        }
    }
}