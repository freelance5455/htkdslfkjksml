using UnityEngine;
using UnityEngine.UI;
namespace MythologyBorsch {
    public class MB_Minimap : MonoBehaviour {
        public Transform player;
        public RectTransform marker;
        public float worldRadius=500f;
        public float mapRadius=100f;
        void Update(){
            if(!player || !marker) return;
            Vector3 p=player.position;
            float x=Mathf.Clamp(p.x/worldRadius,-1,1)*mapRadius;
            float y=Mathf.Clamp(p.z/worldRadius,-1,1)*mapRadius;
            marker.anchoredPosition=new Vector2(x,y);
        }
    }
}