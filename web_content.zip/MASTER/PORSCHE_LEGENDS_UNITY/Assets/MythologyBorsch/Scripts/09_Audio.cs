using UnityEngine;
namespace MythologyBorsch {
    public class MB_Audio : MonoBehaviour {
        public AudioSource engine;
        public AudioSource tires;
        public AudioSource collision;
        public float engineBasePitch=0.75f;
        Rigidbody rb;
        void Awake(){rb=GetComponentInParent<Rigidbody>();}
        void Update(){
            float speed=rb?rb.velocity.magnitude*3.6f:0;
            if(engine){engine.pitch=engineBasePitch+speed/180f; engine.volume=Mathf.Clamp01(.2f+speed/180f);}
        }
        public void PlayCollision(){if(collision) collision.Play();}
    }
}