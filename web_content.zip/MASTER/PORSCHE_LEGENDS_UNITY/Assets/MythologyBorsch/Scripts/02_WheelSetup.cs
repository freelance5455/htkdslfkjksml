using UnityEngine;
namespace MythologyBorsch {
    public class MB_WheelSetup : MonoBehaviour {
        public WheelCollider frontLeft, frontRight, rearLeft, rearRight;
        public Transform visualFL, visualFR, visualRL, visualRR;
        public float suspensionDistance = 0.18f;
        void Start() {
            Setup(frontLeft); Setup(frontRight); Setup(rearLeft); Setup(rearRight);
        }
        void Setup(WheelCollider w) {
            if (!w) return;
            w.suspensionDistance = suspensionDistance;
            w.mass = 20f;
            var f = w.forwardFriction; f.stiffness = 1.6f; w.forwardFriction = f;
            var s = w.sidewaysFriction; s.stiffness = 1.8f; w.sidewaysFriction = s;
        }
        void LateUpdate() {
            Pose(frontLeft,visualFL); Pose(frontRight,visualFR); Pose(rearLeft,visualRL); Pose(rearRight,visualRR);
        }
        void Pose(WheelCollider w, Transform t) {
            if (!w || !t) return;
            w.GetWorldPose(out var p, out var q); t.SetPositionAndRotation(p,q);
        }
    }
}