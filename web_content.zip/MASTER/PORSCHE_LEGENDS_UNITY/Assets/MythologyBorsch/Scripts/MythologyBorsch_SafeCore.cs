using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace MythologyBorsch
{
    public sealed class BridgeBarrierSafe : MonoBehaviour
    {
        [Min(0f)] public float breakForceThreshold = 80f;
        public GameObject brokenBarrierPrefab;
        public AudioSource crashSound;
        private bool broken;

        private void OnCollisionEnter(Collision collision)
        {
            if (broken || collision == null) return;
            float impact = collision.impulse.magnitude;
            if (impact <= 0.001f) impact = collision.relativeVelocity.magnitude;
            if (impact >= breakForceThreshold) BreakBarrier(collision);
        }

        private void BreakBarrier(Collision collision)
        {
            if (broken) return;
            broken = true;
            if (crashSound != null) crashSound.Play();

            if (brokenBarrierPrefab != null)
            {
                GameObject obj = Instantiate(brokenBarrierPrefab, transform.position, transform.rotation);
                Rigidbody[] bodies = obj.GetComponentsInChildren<Rigidbody>(true);
                Vector3 impulse = collision.relativeVelocity * 2f;
                foreach (Rigidbody body in bodies)
                    if (body != null && !body.isKinematic && impulse.sqrMagnitude > 0f)
                        body.AddForce(impulse, ForceMode.Impulse);
            }
            Destroy(gameObject);
        }
    }

    public sealed class SeaAndCanyonSafe : MonoBehaviour
    {
        public GameObject waterSplashVFX;
        public GameObject explosionVFX;
        public Camera cinematicSlowCam;
        public Camera mainFollowCam;
        public GameObject repairNotificationUI;
        public Button repairButton;
        public Text repairText;
        public Transform safeSpawnPoint;
        public Vector3 fallbackSpawnPosition = new Vector3(0f, 5f, 0f);

        private Coroutine activeSequence;
        private GameObject disabledVehicle;

        private void Awake()
        {
            if (repairNotificationUI != null) repairNotificationUI.SetActive(false);
            if (cinematicSlowCam != null) cinematicSlowCam.gameObject.SetActive(false);
        }

        private void OnEnable() { Time.timeScale = 1f; }

        private void OnTriggerEnter(Collider other)
        {
            if (other == null || activeSequence != null) return;

            GameObject vehicle = other.attachedRigidbody != null
                ? other.attachedRigidbody.gameObject
                : other.transform.root.gameObject;

            if (!vehicle.CompareTag("Player") && !vehicle.CompareTag("Police")) return;
            activeSequence = StartCoroutine(CinematicFallSequence(vehicle));
        }

        private IEnumerator CinematicFallSequence(GameObject vehicle)
        {
            disabledVehicle = vehicle;
            Time.timeScale = 0.3f;

            if (mainFollowCam != null) mainFollowCam.gameObject.SetActive(false);
            if (cinematicSlowCam != null)
            {
                cinematicSlowCam.gameObject.SetActive(true);
                cinematicSlowCam.transform.LookAt(vehicle.transform);
            }

            yield return new WaitForSecondsRealtime(1.8f);
            Time.timeScale = 1f;

            Vector3 pos = vehicle != null ? vehicle.transform.position : transform.position;
            if (waterSplashVFX != null) Instantiate(waterSplashVFX, pos, Quaternion.identity);
            if (explosionVFX != null) Instantiate(explosionVFX, pos, Quaternion.identity);
            if (vehicle != null) vehicle.SetActive(false);

            ShowRepairUI();
            activeSequence = null;
        }

        private void ShowRepairUI()
        {
            if (repairNotificationUI == null) return;
            repairNotificationUI.SetActive(true);

            if (repairText != null)
                repairText.text = "⚠️ تحطمت السيارة في البحر/الوادي!\nإعادة السيارة إلى نقطة الأمان؟";

            if (repairButton != null)
            {
                repairButton.onClick.RemoveListener(RepairCurrentVehicle);
                repairButton.onClick.AddListener(RepairCurrentVehicle);
            }
        }

        private void RepairCurrentVehicle() { RespawnVehicle(disabledVehicle); }

        public void RespawnVehicle(GameObject vehicle)
        {
            Time.timeScale = 1f;
            if (repairNotificationUI != null) repairNotificationUI.SetActive(false);
            if (cinematicSlowCam != null) cinematicSlowCam.gameObject.SetActive(false);
            if (mainFollowCam != null) mainFollowCam.gameObject.SetActive(true);
            if (vehicle == null) return;

            Vector3 pos = safeSpawnPoint != null ? safeSpawnPoint.position : fallbackSpawnPosition;
            Quaternion rot = safeSpawnPoint != null ? safeSpawnPoint.rotation : Quaternion.identity;
            vehicle.transform.SetPositionAndRotation(pos, rot);

            foreach (Rigidbody body in vehicle.GetComponentsInChildren<Rigidbody>(true))
            {
                if (body == null) continue;
                body.velocity = Vector3.zero;
                body.angularVelocity = Vector3.zero;
            }

            vehicle.SetActive(true);
            vehicle.SendMessage("ResetDamage", SendMessageOptions.DontRequireReceiver);
            vehicle.SendMessage("RepairFull", SendMessageOptions.DontRequireReceiver);
            disabledVehicle = null;
        }

        private void OnDisable()
        {
            Time.timeScale = 1f;
            activeSequence = null;
        }
    }

    public sealed class DynamicWeatherSafe : MonoBehaviour
    {
        public enum WeatherState { Clear, Rainy, Stormy }

        public Light sunDirectionalLight;
        [Min(0.1f)] public float cycleDurationMinutes = 10f;
        public ParticleSystem rainParticles;
        public ParticleSystem stormWindParticles;
        public AudioSource weatherAudioSource;
        public AudioClip rainSound;
        public AudioClip stormSound;
        public WeatherState currentWeather = WeatherState.Clear;
        [Min(1f)] public float minimumWeatherChangeSeconds = 120f;
        [Min(1f)] public float maximumWeatherChangeSeconds = 300f;

        private float dayNightTimer;
        private bool isDaytime = true;
        private Coroutine weatherRoutine;

        private void OnEnable()
        {
            dayNightTimer = 0f;
            weatherRoutine = StartCoroutine(WeatherRoutine());
            ApplyWeatherState(currentWeather);
        }

        private void OnDisable()
        {
            if (weatherRoutine != null) StopCoroutine(weatherRoutine);
            weatherRoutine = null;
            if (weatherAudioSource != null) weatherAudioSource.Stop();
            if (rainParticles != null) rainParticles.Stop(true, ParticleSystemStopBehavior.StopEmitting);
            if (stormWindParticles != null) stormWindParticles.Stop(true, ParticleSystemStopBehavior.StopEmitting);
        }

        private void Update()
        {
            float duration = Mathf.Max(0.1f, cycleDurationMinutes * 60f);
            dayNightTimer += Time.deltaTime;
            if (dayNightTimer >= duration)
            {
                dayNightTimer -= duration;
                isDaytime = !isDaytime;
            }

            if (sunDirectionalLight == null) return;

            float targetRotation = isDaytime ? 50f : -50f;
            float targetIntensity = isDaytime ? 1.2f : 0.05f;
            float blend = 1f - Mathf.Exp(-Time.deltaTime * 2f);
            sunDirectionalLight.transform.rotation =
                Quaternion.Slerp(sunDirectionalLight.transform.rotation,
                                 Quaternion.Euler(targetRotation, -30f, 0f), blend);
            sunDirectionalLight.intensity =
                Mathf.Lerp(sunDirectionalLight.intensity, targetIntensity, blend);
        }

        private IEnumerator WeatherRoutine()
        {
            while (enabled)
            {
                float min = Mathf.Min(minimumWeatherChangeSeconds, maximumWeatherChangeSeconds);
                float max = Mathf.Max(minimumWeatherChangeSeconds, maximumWeatherChangeSeconds);
                yield return new WaitForSeconds(Random.Range(min, max));
                ApplyWeatherState((WeatherState)Random.Range(0, 3));
            }
        }

        public void SetWeather(WeatherState state) { ApplyWeatherState(state); }

        private void ApplyWeatherState(WeatherState state)
        {
            currentWeather = state;
            if (rainParticles != null) rainParticles.Stop(true, ParticleSystemStopBehavior.StopEmitting);
            if (stormWindParticles != null) stormWindParticles.Stop(true, ParticleSystemStopBehavior.StopEmitting);
            if (weatherAudioSource != null) weatherAudioSource.Stop();

            switch (state)
            {
                case WeatherState.Clear:
                    RenderSettings.fog = false;
                    break;
                case WeatherState.Rainy:
                    if (rainParticles != null) rainParticles.Play();
                    PlaySound(rainSound);
                    RenderSettings.fog = true;
                    RenderSettings.fogDensity = 0.015f;
                    break;
                case WeatherState.Stormy:
                    if (rainParticles != null) rainParticles.Play();
                    if (stormWindParticles != null) stormWindParticles.Play();
                    PlaySound(stormSound);
                    RenderSettings.fog = true;
                    RenderSettings.fogDensity = 0.035f;
                    break;
            }
        }

        private void PlaySound(AudioClip clip)
        {
            if (weatherAudioSource == null || clip == null) return;
            weatherAudioSource.clip = clip;
            weatherAudioSource.loop = true;
            weatherAudioSource.Play();
        }
    }
}
