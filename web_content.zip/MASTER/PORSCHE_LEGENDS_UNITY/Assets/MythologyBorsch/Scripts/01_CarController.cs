using UnityEngine;
namespace MythologyBorsch {
    [RequireComponent(typeof(Rigidbody))]
    public class MB_CarController : MonoBehaviour {
        public float maxSpeedKmh = 330f;
        public float acceleration = 32f;
        public float brake = 45f;
        public float steering = 55f;
        public float reverseSpeedKmh = 35f;
        public float sideGrip = 7f;
        public float downforce = 35f;
        Rigidbody rb;
        float steer, gas, brakeInput, handbrake;
        void Awake() {
            rb = GetComponent<Rigidbody>();
            rb.mass = 1380f;
            rb.interpolation = RigidbodyInterpolation.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            rb.centerOfMass = new Vector3(0,-0.45f,0);
        }
        void FixedUpdate() {
            float forward = Vector3.Dot(rb.velocity, transform.forward);
            float speed = rb.velocity.magnitude * 3.6f;
            if (gas > 0f && speed < maxSpeedKmh) rb.AddForce(transform.forward * acceleration * gas, ForceMode.Acceleration);
            if (brakeInput > 0f) rb.AddForce(-rb.velocity.normalized * brake * brakeInput, ForceMode.Acceleration);
            if (gas < 0f && forward < 0.5f) rb.AddForce(-transform.forward * acceleration * 0.4f, ForceMode.Acceleration);
            float steerFactor = Mathf.Lerp(steering, 25f, Mathf.Clamp01(speed/220f));
            if (Mathf.Abs(steer) > 0.01f)
                rb.MoveRotation(rb.rotation * Quaternion.Euler(0, steer * steerFactor * Time.fixedDeltaTime, 0));
            Vector3 local = transform.InverseTransformDirection(rb.velocity);
            float grip = handbrake > 0.5f ? sideGrip * 0.25f : sideGrip;
            local.x = Mathf.Lerp(local.x, 0, grip * Time.fixedDeltaTime);
            rb.velocity = transform.TransformDirection(local);
            rb.AddForce(-transform.up * downforce * rb.velocity.magnitude, ForceMode.Force);
            if (speed > maxSpeedKmh) rb.velocity = rb.velocity.normalized * (maxSpeedKmh/3.6f);
        }
        public void SetSteering(float v) => steer = Mathf.Clamp(v,-1,1);
        public void SetGas(float v) => gas = Mathf.Clamp01(v);
        public void SetBrake(float v) => brakeInput = Mathf.Clamp01(v);
        public void SetHandbrake(float v) => handbrake = Mathf.Clamp01(v);
    }
}