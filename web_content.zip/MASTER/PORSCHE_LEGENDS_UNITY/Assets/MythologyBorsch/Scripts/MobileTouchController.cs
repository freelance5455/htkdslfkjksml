using UnityEngine;
using UnityEngine.EventSystems;
namespace MythologyBorschMobile {
public class MobileTouchController : MonoBehaviour {
    public PorscheCarreraGTMobile car;
    public bool useGyro=true;
    public float gyroSensitivity=1.5f;
    public void GasDown()=>car?.SetThrottle(true);
    public void GasUp()=>car?.SetThrottle(false);
    public void BrakeDown()=>car?.SetBrake(true);
    public void BrakeUp()=>car?.SetBrake(false);
    public void HandbrakeDown()=>car?.SetHandbrake(true);
    public void HandbrakeUp()=>car?.SetHandbrake(false);
    public void Steer(float value)=>car?.SetSteerInput(value);
    public void CameraButton()=>car?.SwitchCameraView();
    void Update(){ if(useGyro && car!=null) car.SetSteerInput(Mathf.Clamp(Input.acceleration.x*gyroSensitivity,-1f,1f)); }
}
}