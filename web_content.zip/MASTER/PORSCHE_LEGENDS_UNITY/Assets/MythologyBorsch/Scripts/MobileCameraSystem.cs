using UnityEngine;
namespace MythologyBorschMobile {
public class MobileCameraSystem : MonoBehaviour {
    public Transform target;
    public float distance=7f, height=2.5f, followSpeed=8f, rotationSpeed=8f;
    public enum CameraMode { NFS_Chase, DirtGround, GlassCockpit }
    public CameraMode mode=CameraMode.NFS_Chase;
    private Camera cam;
    void Awake(){cam=GetComponent<Camera>(); if(cam==null) cam=Camera.main;}
    void LateUpdate(){
        if(target==null || cam==null) return;
        Vector3 offset = mode==CameraMode.DirtGround ? new Vector3(0,1.1f,-4.5f) :
                         mode==CameraMode.GlassCockpit ? new Vector3(0,1.25f,0.5f) :
                         new Vector3(0,height,-distance);
        Vector3 desired = target.TransformPoint(offset);
        cam.transform.position=Vector3.Lerp(cam.transform.position,desired,1f-Mathf.Exp(-followSpeed*Time.deltaTime));
        Quaternion look = Quaternion.LookRotation((target.position+Vector3.up*(mode==CameraMode.DirtGround?0.7f:1f))-cam.transform.position);
        cam.transform.rotation=Quaternion.Slerp(cam.transform.rotation,look,1f-Mathf.Exp(-rotationSpeed*Time.deltaTime));
    }
    public void CycleNextCamera(){mode=(CameraMode)(((int)mode+1)%3);}
}
}