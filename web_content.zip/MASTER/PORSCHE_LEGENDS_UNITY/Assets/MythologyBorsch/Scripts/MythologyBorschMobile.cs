using UnityEngine;
using UnityEngine.UI;

namespace MythologyBorschMobile
{
    public class SmartMobilePerformance : MonoBehaviour
    {
        public static SmartMobilePerformance Instance;
        public int maximumTargetFPS = 60;
        public int minimumTargetFPS = 30;
        public float sampleTime = 1.0f;
        public float downgradeFPS = 48f;
        public float upgradeFPS = 57f;
        public float downgradeDelay = 3f;
        public float upgradeDelay = 8f;
        [Range(0, 2)] public int startingQuality = 2;
        public bool useDynamicShadows = true;
        public Text performanceText;
        private float fpsTimer, lowFPSTimer, highFPSTimer, fpsAverage;
        private int frameCounter, qualityLevel;

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);
            qualityLevel = Mathf.Clamp(startingQuality, 0, Mathf.Max(0, QualitySettings.names.Length - 1));
            Time.fixedDeltaTime = 0.02f;
            ApplyQuality();
            Application.targetFrameRate = Mathf.Clamp(maximumTargetFPS, minimumTargetFPS, 120);
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
        }

        private void Update() => MonitorFPS();

        private void MonitorFPS()
        {
            fpsTimer += Time.unscaledDeltaTime;
            frameCounter++;
            if (fpsTimer < sampleTime) return;
            fpsAverage = frameCounter / Mathf.Max(fpsTimer, 0.001f);
            fpsTimer = 0f; frameCounter = 0;
            EvaluatePerformance();
            if (performanceText != null)
                performanceText.text = $"FPS: {Mathf.RoundToInt(fpsAverage)}\nQuality: {QualityName()}";
        }

        private void EvaluatePerformance()
        {
            if (fpsAverage < downgradeFPS)
            {
                lowFPSTimer += sampleTime; highFPSTimer = 0f;
                if (lowFPSTimer >= downgradeDelay && qualityLevel > 0)
                { qualityLevel--; lowFPSTimer = 0f; ApplyQuality(); }
            }
            else if (fpsAverage >= upgradeFPS)
            {
                highFPSTimer += sampleTime; lowFPSTimer = 0f;
                if (highFPSTimer >= upgradeDelay && qualityLevel < Mathf.Min(2, QualitySettings.names.Length - 1))
                { qualityLevel++; highFPSTimer = 0f; ApplyQuality(); }
            }
            else { lowFPSTimer = 0f; highFPSTimer = 0f; }
        }

        private void ApplyQuality()
        {
            int max = Mathf.Max(0, QualitySettings.names.Length - 1);
            int index = Mathf.Clamp(qualityLevel, 0, max);
            qualityLevel = Mathf.Clamp(index, 0, 2);
            QualitySettings.SetQualityLevel(index, true);
            if (qualityLevel == 2) ApplyHigh();
            else if (qualityLevel == 1) ApplyMedium();
            else ApplyLow();
            Time.fixedDeltaTime = 0.02f;
        }

        private void ApplyHigh()
        {
            QualitySettings.shadows = useDynamicShadows ? ShadowQuality.All : ShadowQuality.Disable;
            QualitySettings.shadowResolution = ShadowResolution.High;
            QualitySettings.shadowDistance = 100f;
            QualitySettings.shadowCascades = 2;
        }

        private void ApplyMedium()
        {
            QualitySettings.shadows = useDynamicShadows ? ShadowQuality.HardOnly : ShadowQuality.Disable;
            QualitySettings.shadowResolution = ShadowResolution.Medium;
            QualitySettings.shadowDistance = 55f;
            QualitySettings.shadowCascades = 1;
        }

        private void ApplyLow()
        {
            QualitySettings.shadows = useDynamicShadows ? ShadowQuality.HardOnly : ShadowQuality.Disable;
            QualitySettings.shadowResolution = ShadowResolution.Low;
            QualitySettings.shadowDistance = 30f;
            QualitySettings.shadowCascades = 1;
        }

        public void ResetAutomaticQuality()
        {
            qualityLevel = Mathf.Clamp(startingQuality, 0, Mathf.Min(2, QualitySettings.names.Length - 1));
            lowFPSTimer = highFPSTimer = 0f; ApplyQuality();
        }
        public int GetQualityLevel() => qualityLevel;
        public float GetAverageFPS() => fpsAverage;
        private string QualityName() => qualityLevel == 2 ? "HIGH" : qualityLevel == 1 ? "MEDIUM" : "LOW";
    }

    public class PorscheCarreraGTMobile : MonoBehaviour
    {
        public Rigidbody carRigidbody;
        public MobileCameraSystem cameraSystem;
        public float topSpeedKmh = 330f, reverseTopSpeedKmh = 35f;
        public float acceleration = 32f, reverseAcceleration = 12f, brakePower = 38f;
        public float lowSpeedSteering = 70f, highSpeedSteering = 28f, steeringSmoothness = 7f;
        public float sidewaysGrip = 9f, handbrakeGrip = 2.2f, forwardGrip = 7f;
        public float downforce = 35f, rollingResistance = 1.2f;
        public Vector3 centerOfMass = new Vector3(0f, -0.45f, 0f);
        public Text mobileSpeedometerText;
        public AudioSource engineAudioSource, tireAudioSource, collisionAudioSource;
        public AudioClip engineAudioClip, tireAudioClip, collisionAudioClip;
        public MeshFilter carMeshFilter;
        public ParticleSystem collisionSparkFX;
        public float minCollisionForce = 5f, maxDeformationImpact = 0.5f;
        public System.Collections.Generic.List<GameObject> detachableParts;

        private float steeringInput, smoothSteering;
        private bool throttlePressed, brakePressed, handbrakePressed;

        private void Awake()
        {
            if (carRigidbody == null) carRigidbody = GetComponent<Rigidbody>();
            if (carRigidbody == null) { Debug.LogError("PorscheCarreraGTMobile requires Rigidbody."); enabled = false; return; }
            SetupPhysics(); SetupAudio();
        }

        private void SetupPhysics()
        {
            carRigidbody.mass = 1380f;
            carRigidbody.interpolation = RigidbodyInterpolation.Interpolate;
            carRigidbody.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            carRigidbody.centerOfMass = centerOfMass;
            carRigidbody.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
        }

        private void SetupAudio()
        {
            if (engineAudioSource != null) {
                engineAudioSource.loop = true; engineAudioSource.playOnAwake = false;
                if (engineAudioClip != null) engineAudioSource.clip = engineAudioClip;
                if (engineAudioSource.clip != null) engineAudioSource.Play();
            }
            if (tireAudioSource != null) {
                tireAudioSource.loop = true; tireAudioSource.playOnAwake = false;
                if (tireAudioClip != null) tireAudioSource.clip = tireAudioClip;
            }
        }

        private void FixedUpdate()
        {
            if (carRigidbody == null) return;
            smoothSteering = Mathf.Lerp(smoothSteering, steeringInput, steeringSmoothness * Time.fixedDeltaTime);
            float speedKmh = carRigidbody.velocity.magnitude * 3.6f;
            float forwardSpeed = Vector3.Dot(carRigidbody.velocity, transform.forward);
            HandleAcceleration(forwardSpeed); HandleBraking(forwardSpeed); HandleSteering(speedKmh);
            ApplyGrip(); ApplyDownforce(); ApplyRollingResistance(); LimitSpeed();
            UpdateSpeedometer(speedKmh); UpdateEngineSound(speedKmh); UpdateTireSound(speedKmh);
        }

        private void HandleAcceleration(float forwardSpeed)
        {
            if (!throttlePressed) return;
            if (forwardSpeed < -1f) { ApplyBrake(); return; }
            float speedKmh = carRigidbody.velocity.magnitude * 3.6f;
            if (speedKmh >= topSpeedKmh) return;
            float speedFactor = 1f - Mathf.Clamp01(speedKmh / topSpeedKmh);
            float force = acceleration * Mathf.Lerp(0.25f, 1f, speedFactor);
            carRigidbody.AddForce(transform.forward * force, ForceMode.Acceleration);
        }

        private void HandleBraking(float forwardSpeed)
        {
            if (!brakePressed) return;
            if (forwardSpeed > 1f) { ApplyBrake(); return; }
            ApplyReverse();
        }

        private void ApplyBrake()
        {
            Vector3 velocity = carRigidbody.velocity;
            if (velocity.sqrMagnitude < 0.05f) return;
            carRigidbody.AddForce(-velocity.normalized * brakePower, ForceMode.Acceleration);
        }

        private void ApplyReverse()
        {
            float reverseSpeed = Mathf.Max(0f, -Vector3.Dot(carRigidbody.velocity, transform.forward));
            float maxReverse = reverseTopSpeedKmh / 3.6f;
            if (reverseSpeed >= maxReverse) return;
            carRigidbody.AddForce(-transform.forward * reverseAcceleration, ForceMode.Acceleration);
        }

        private void HandleSteering(float speedKmh)
        {
            if (speedKmh < 0.5f) return;
            float speedFactor = Mathf.Clamp01(speedKmh / topSpeedKmh);
            float steeringPower = Mathf.Lerp(lowSpeedSteering, highSpeedSteering, speedFactor);
            float direction = Vector3.Dot(carRigidbody.velocity, transform.forward) >= 0f ? 1f : -1f;
            float rotation = smoothSteering * steeringPower * direction * Time.fixedDeltaTime;
            carRigidbody.MoveRotation(carRigidbody.rotation * Quaternion.Euler(0f, rotation, 0f));
        }

        private void ApplyGrip()
        {
            Vector3 localVelocity = transform.InverseTransformDirection(carRigidbody.velocity);
            float grip = handbrakePressed ? handbrakeGrip : sidewaysGrip;
            carRigidbody.AddForce(-transform.right * localVelocity.x * grip, ForceMode.Acceleration);
            Vector3 forwardCorrection = transform.forward * localVelocity.z * forwardGrip * 0.02f;
            carRigidbody.AddForce(forwardCorrection, ForceMode.Acceleration);
        }

        private void ApplyDownforce()
        {
            float speed = carRigidbody.velocity.magnitude;
            if (speed < 5f) return;
            carRigidbody.AddForce(-transform.up * speed * downforce * 0.01f, ForceMode.Acceleration);
        }

        private void ApplyRollingResistance()
        {
            if (throttlePressed || brakePressed) return;
            Vector3 velocity = carRigidbody.velocity;
            if (velocity.sqrMagnitude < 0.1f) return;
            carRigidbody.AddForce(-velocity * rollingResistance * 0.05f, ForceMode.Acceleration);
        }

        private void LimitSpeed()
        {
            float maxSpeed = topSpeedKmh / 3.6f;
            if (carRigidbody.velocity.magnitude > maxSpeed)
                carRigidbody.velocity = carRigidbody.velocity.normalized * maxSpeed;
        }

        private void UpdateSpeedometer(float speedKmh)
        {
            if (mobileSpeedometerText != null) mobileSpeedometerText.text = "CARRERA GT\n" + Mathf.RoundToInt(speedKmh) + " KM/H";
        }

        private void UpdateEngineSound(float speedKmh)
        {
            if (engineAudioSource == null) return;
            float speedPercent = Mathf.Clamp01(speedKmh / topSpeedKmh);
            float throttle = throttlePressed ? 1f : 0f;
            float targetPitch = Mathf.Lerp(0.7f, 1.9f, Mathf.Max(speedPercent, throttle * 0.35f));
            engineAudioSource.pitch = Mathf.Lerp(engineAudioSource.pitch, targetPitch, Time.fixedDeltaTime * 6f);
            engineAudioSource.volume = Mathf.Lerp(0.35f, 1f, throttle);
        }

        private void UpdateTireSound(float speedKmh)
        {
            if (tireAudioSource == null) return;
            bool drifting = handbrakePressed && speedKmh > 12f;
            if (drifting) {
                if (!tireAudioSource.isPlaying) tireAudioSource.Play();
                tireAudioSource.volume = Mathf.Clamp01(speedKmh / 80f);
            } else {
                tireAudioSource.volume = Mathf.Lerp(tireAudioSource.volume, 0f, Time.fixedDeltaTime * 8f);
                if (tireAudioSource.isPlaying && tireAudioSource.volume < 0.02f) tireAudioSource.Stop();
            }
        }

        private void OnCollisionEnter(Collision collision)
        {
            float impact = collision.relativeVelocity.magnitude;
            if (impact < minCollisionForce) return;
            if (collisionAudioSource != null && collisionAudioClip != null)
                collisionAudioSource.PlayOneShot(collisionAudioClip, Mathf.Clamp01(impact / 30f));
            if (collisionSparkFX != null && collision.contacts.Length > 0) {
                collisionSparkFX.transform.position = collision.contacts[0].point;
                collisionSparkFX.Play();
            }
            DamageMesh(collision, impact); DetachPartIfNeeded(collision, impact);
        }

        private void DamageMesh(Collision collision, float impact)
        {
            if (carMeshFilter == null) return;
            Mesh mesh = carMeshFilter.mesh; Vector3[] vertices = mesh.vertices;
            foreach (ContactPoint contact in collision.contacts) {
                Vector3 localPoint = transform.InverseTransformPoint(contact.point);
                for (int i = 0; i < vertices.Length; i++) {
                    float distance = Vector3.SqrMagnitude(vertices[i] - localPoint);
                    if (distance < 2f) {
                        Vector3 direction = (vertices[i] - localPoint).normalized;
                        Vector3 deformation = direction * impact * 0.01f;
                        vertices[i] -= Vector3.ClampMagnitude(deformation, maxDeformationImpact);
                    }
                }
            }
            mesh.vertices = vertices; mesh.RecalculateNormals(); mesh.RecalculateBounds();
        }

        private void DetachPartIfNeeded(Collision collision, float impact)
        {
            if (impact < 15f || detachableParts == null || detachableParts.Count == 0) return;
            GameObject part = detachableParts[0]; detachableParts.RemoveAt(0);
            if (part == null) return;
            part.transform.SetParent(null);
            Rigidbody rb = part.GetComponent<Rigidbody>() ?? part.AddComponent<Rigidbody>();
            if (collision.contacts.Length > 0) rb.AddExplosionForce(impact * 20f, collision.contacts[0].point, 3f);
            Destroy(part, 10f);
        }

        public void SetThrottle(bool active) => throttlePressed = active;
        public void SetBrake(bool active) => brakePressed = active;
        public void SetHandbrake(bool active) => handbrakePressed = active;
        public void SetSteerInput(float value) => steeringInput = Mathf.Clamp(value, -1f, 1f);
        public void SwitchCameraView() { if (cameraSystem != null) cameraSystem.CycleNextCamera(); }
    }
}
