MYTHOLOGY BORSCH — COMPLETE UNITY PROJECT SHELL

هذه الحزمة هي هيكل مشروع Unity كامل (Assets + Packages + ProjectSettings)
ومجلد Scripts جاهز لوضع أنظمة اللعبة داخله.

مهم:
- هذه ليست APK.
- لا تحتوي تلقائياً على موديل Porsche ثلاثي الأبعاد احترافي أو أصوات/خامات خارجية غير موجودة.
- لا تحذف ملفات مشروعك القديم.
- إذا كان لديك مشروع Unity قائم، لا تستبدلي ProjectSettings به عشوائياً.
- هذه الحزمة تصلح كأساس لتجميع المشروع، ثم فتحه في Unity وبناء Android.

المكان:
Assets/MythologyBorsch/Scripts
