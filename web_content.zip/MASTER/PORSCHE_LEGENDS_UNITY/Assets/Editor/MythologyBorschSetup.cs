using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using MythologyBorschMobile;
public static class MythologyBorschSetup {
 [MenuItem("Mythology Borsch/Create Demo Scene")]
 public static void Create(){
  var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
  var light=new GameObject("Directional Light"); var dl=light.AddComponent<Light>(); dl.type=LightType.Directional; dl.intensity=1.2f; light.transform.rotation=Quaternion.Euler(50,-30,0);
  var ground=GameObject.CreatePrimitive(PrimitiveType.Plane); ground.name="Demo Ground"; ground.transform.localScale=new Vector3(50,1,50);
  var car=GameObject.CreatePrimitive(PrimitiveType.Cube); car.name="Carrera GT Prototype"; car.transform.position=new Vector3(0,0.6f,0); car.transform.localScale=new Vector3(1.9f,0.55f,4.5f);
  var rb=car.AddComponent<Rigidbody>(); rb.mass=1380;
  var pc=car.AddComponent<PorscheCarreraGTMobile>();
  var camObj=new GameObject("Main Camera"); var cam=camObj.AddComponent<Camera>(); camObj.tag="MainCamera"; var cs=camObj.AddComponent<MobileCameraSystem>(); cs.target=car.transform; pc.cameraSystem=cs;
  var perf=new GameObject("SmartMobilePerformance"); perf.AddComponent<SmartMobilePerformance>();
  EditorSceneManager.SaveScene(scene,"Assets/Scenes/MythologyBorsch_Demo.unity");
  Selection.activeGameObject=car;
  Debug.Log("Demo scene created. Replace the cube with your Porsche model and add mobile UI.");
 }
}