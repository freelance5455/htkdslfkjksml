# AI Mobile Security — Netlify starter

This ZIP contains a responsive static website with a security checklist, basic URL heuristics, file metadata review, account-security links, and safe-response guidance.

## Deploy to Netlify
1. Download and extract this ZIP.
2. Sign in to your own Netlify account: https://app.netlify.com/drop
3. Drag the extracted `ai_mobile_security` folder (the one containing `index.html`) onto the deploy area.
4. Netlify will publish a `*.netlify.app` address with HTTPS.
5. To change the free subdomain, open Site configuration → General → Site details → Change site name. Choose an available name.

## What this project can and cannot do
- It can calculate a checklist score from answers selected by the visitor.
- It can flag a few suspicious URL patterns using local heuristics.
- It can show file name, extension and size, but does not upload or scan file contents.
- It provides links to official account-security pages and basic response guidance.
- It cannot scan every installed app, inspect private files or operating-system processes, monitor network traffic, detect a live intruder, confirm that a phone is hacked, or block attacks. A normal website has no such device-wide access.
- Do not advertise this starter as antivirus, live hacking detection, or a tool that prevents a stated percentage of attacks.

For genuine device-wide protection, build a separately installed native Android app and use supported Android security APIs, Play Protect and carefully reviewed permissions. Native apps still have platform restrictions and cannot guarantee detection of every attack.

## Ownership
Deploy this to a Netlify account you control. Keep account passwords and any future API keys private. This ZIP contains no third-party analytics, no login form, and no server-side collection of visitor data.
