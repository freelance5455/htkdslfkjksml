const $=id=>document.getElementById(id);
function result(id,msg,kind=''){const e=$(id);e.className='result '+kind;e.textContent=msg}
function updateScore(){
 const boxes=[...document.querySelectorAll('#privacyList input')],done=boxes.filter(x=>x.checked).length,score=Math.round(done/boxes.length*100);
 $('score').textContent=score;$('meterFill').style.width=score+'%';$('statusPill').textContent='CHECKLIST SCORE';
 $('statusTitle').textContent=score>=80?'Good checklist coverage':score>=50?'Some improvements recommended':'More protection steps recommended';
 $('scoreNote').textContent=`${done} of ${boxes.length} recommended practices marked complete. This is not a device scan and does not prove your phone is safe.`;
 $('checkResults').replaceChildren();
 [['Privacy practices',`${done}/${boxes.length} marked complete`],['Link checker','Basic URL warning signs only'],['Device integrity','Not accessible from this browser']].forEach(([a,b])=>{const d=document.createElement('div');d.className='result';const strong=document.createElement('b');strong.textContent=a+' — ';d.append(strong,document.createTextNode(b));$('checkResults').append(d)});
}
$('runChecks').addEventListener('click',updateScore);
$('saveChecklist').addEventListener('click',()=>{updateScore();result('privacyResult','Checklist score updated. Your answers are processed in this browser only.','good')});
$('checkUrl').addEventListener('click',()=>{
 const raw=$('urlInput').value.trim();if(!raw)return result('urlResult','Enter a URL first.','warn');
 let u;try{u=new URL(raw)}catch{return result('urlResult','This does not look like a valid URL.','bad')}
 const f=[];if(!['http:','https:'].includes(u.protocol))f.push('Unexpected URL protocol.');
 if(u.protocol!=='https:')f.push('The link does not use HTTPS.');
 if(u.username||u.password)f.push('The URL embeds username or password text.');
 if(u.hostname.startsWith('xn--')||u.hostname.includes('.xn--'))f.push('The domain uses punycode; check for lookalike characters.');
 if(/^\d{1,3}(\.\d{1,3}){3}$/.test(u.hostname))f.push('The host is an IP address rather than a domain name.');
 if(u.hostname.split('.').length>5)f.push('The hostname has many subdomains.');
 if(/login|verify|account|secure|wallet|password|gift|prize/i.test(u.href))f.push('The URL includes words sometimes used in deceptive messages.');
 result('urlResult',f.length?'Potential warning signs:\n• '+f.join('\n• ')+'\nDo not enter sensitive information unless you independently verify the official website.':'No basic warning signs found. This does NOT prove the website is safe; this tool does not check reputation or page contents.',f.length?'warn':'good');
});
$('checkFile').addEventListener('click',()=>{
 const f=$('fileInput').files[0];if(!f)return result('fileResult','Choose a file first.','warn');
 const ext=(f.name.split('.').pop()||'').toLowerCase(),risky=['apk','xapk','apks','exe','msi','bat','cmd','scr','js','vbs','ps1','jar'];
 result('fileResult',`Name: ${f.name}\nSize: ${(f.size/1048576).toFixed(2)} MB\nExtension: .${ext||'(none)'}\n\n`+(risky.includes(ext)?'This file type can install software or run code. Only use it if you trust its source.':'No file-extension warning from this basic review.')+'\nFile contents have NOT been scanned for malware.',risky.includes(ext)?'warn':'good');
});
$('reviewSymptoms').addEventListener('click',()=>{
 const n=[...document.querySelectorAll('.symptoms input')].filter(x=>x.checked).length;
 result('symptomResult',n?`${n} possible warning sign(s) selected. They do not prove hacking. Use a different trusted device to secure your main email, review active sessions, update your phone and ask a qualified technician or trusted adult for help. Contact your bank through its official channel if money may be at risk.`:'No listed warning signs selected. This does not prove the device is safe.',n?'warn':'good');
});
if('serviceWorker' in navigator && location.protocol.startsWith('http')) window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
