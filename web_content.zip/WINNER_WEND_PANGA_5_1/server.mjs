import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
loadEnv(path.join(__dirname, '.env'));
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '127.0.0.1';
const API_KEY = process.env.DEEPSEEK_API_KEY || '';
const API_URL = process.env.DEEPSEEK_BASE_URL || 'https://api.deepseek.com/chat/completions';
const MODEL = process.env.DEEPSEEK_MODEL || 'deepseek-chat';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '';
const MAX_BODY = 1024 * 1024;
const requests = new Map();

function loadEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
}
function json(res, status, obj) {
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});
  res.end(JSON.stringify(obj));
}
function readBody(req) {
  return new Promise((resolve,reject)=>{
    let raw=''; req.on('data',chunk=>{raw+=chunk; if(raw.length>MAX_BODY){reject(new Error('Taille maximale dépassée'));req.destroy();}});
    req.on('end',()=>{try{resolve(JSON.parse(raw||'{}'));}catch{reject(new Error('JSON invalide'));}});
    req.on('error',reject);
  });
}
function allowed(req) {
  const origin=req.headers.origin;
  if (!origin) return true;
  if (ALLOWED_ORIGIN) return origin===ALLOWED_ORIGIN;
  const host=req.headers.host || '';
  try { const u=new URL(origin); return u.host===host || u.hostname==='localhost' || u.hostname==='127.0.0.1'; } catch { return false; }
}
function rateLimit(req) {
  const ip=req.socket.remoteAddress || 'unknown'; const now=Date.now();
  const x=requests.get(ip) || {start:now,count:0};
  if(now-x.start>60000){x.start=now;x.count=0;} x.count++; requests.set(ip,x); return x.count<=20;
}
function safeMessages(input) {
  if(!Array.isArray(input) || input.length<1 || input.length>20) throw new Error('Historique invalide (1 à 20 messages).');
  return input.map(m=>{
    if(!m || !['user','assistant'].includes(m.role) || typeof m.content!=='string') throw new Error('Message invalide.');
    const content=m.content.trim(); if(!content || content.length>12000) throw new Error('Message vide ou trop long.');
    return {role:m.role,content};
  });
}
const server=http.createServer(async(req,res)=>{
  try {
    if(!allowed(req)){json(res,403,{error:'Origine non autorisée.'});return;}
    if(req.headers.origin) res.setHeader('Access-Control-Allow-Origin',req.headers.origin);
    res.setHeader('Vary','Origin');
    res.setHeader('Access-Control-Allow-Methods','GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers','Content-Type');
    if(req.method==='OPTIONS'){res.writeHead(204);res.end();return;}
    const url=new URL(req.url,'http://localhost');
    if(req.method==='GET' && url.pathname==='/api/health'){
      json(res,200,{ok:true,aiReady:Boolean(API_KEY),provider:'DeepSeek',model:MODEL,version:'5.1'});return;
    }
    if(req.method==='POST' && url.pathname==='/api/chat'){
      if(!rateLimit(req)){json(res,429,{error:'Trop de demandes. Réessayez dans une minute.'});return;}
      if(!API_KEY){json(res,503,{error:'Moteur IA non configuré : ajoutez DEEPSEEK_API_KEY dans le fichier .env du serveur.'});return;}
      const body=await readBody(req);
      const system=typeof body.system==='string'?body.system.slice(0,8000):'Tu es WINNER AI, assistant utile, fiable et prudent.';
      const messages=safeMessages(body.messages);
      const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),55000);
      try {
        const upstream=await fetch(API_URL,{method:'POST',headers:{'Authorization':`Bearer ${API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:MODEL,messages:[{role:'system',content:system},...messages],temperature:0.4,stream:false}),signal:controller.signal});
        const data=await upstream.json().catch(()=>({}));
        if(!upstream.ok){const status=upstream.status===401?502:upstream.status;json(res,status,{error:data.error?.message || `Le fournisseur IA a répondu HTTP ${upstream.status}.`});return;}
        const answer=data.choices?.[0]?.message?.content;
        if(typeof answer!=='string'||!answer.trim()){json(res,502,{error:'Le fournisseur IA a retourné une réponse vide.'});return;}
        json(res,200,{answer:answer.trim(),model:data.model||MODEL,provider:'DeepSeek'});
      } catch(e){json(res, e.name==='AbortError'?504:502,{error:e.name==='AbortError'?'Délai de réponse dépassé.':'Connexion au fournisseur IA impossible.'});}
      finally{clearTimeout(timer);} return;
    }
    if(req.method==='POST' && url.pathname==='/api/editorial/gate'){
      const b=await readBody(req); const reasons=[];
      if(!String(b.claim||'').trim()) reasons.push('Affirmation absente.');
      if(!String(b.original||'').trim()) reasons.push('Source originale absente.');
      const sources=Array.isArray(b.sources)?b.sources.filter(x=>typeof x==='string'&&x.trim()):[];
      if(sources.length<2) reasons.push('Deux sources indépendantes au minimum sont requises.');
      if(!b.independent) reasons.push('Indépendance des sources non confirmée.');
      if(!b.humanApproved) reasons.push('Validation humaine obligatoire.');
      if(!['CONFIRMÉE','CORROBORÉE'].includes(String(b.status||'').toUpperCase())) reasons.push('Statut de vérification insuffisant.');
      json(res,200,{eligible:reasons.length===0,message:reasons.length?'Publication bloquée : contrôles incomplets.':'Contrôles déclaratifs satisfaits ; vérification éditoriale humaine toujours requise.',reasons});return;
    }
    if(req.method==='GET' && (url.pathname==='/'||url.pathname==='/index.html')){
      res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});
      fs.createReadStream(path.join(__dirname,'index.html')).pipe(res);return;
    }
    json(res,404,{error:'Route introuvable.'});
  } catch(e){ if(!res.headersSent) json(res,400,{error:e.message||'Requête invalide.'}); }
});
server.listen(PORT,HOST,()=>console.log(`WINNER WEND-PANGA 5.1 actif : http://${HOST}:${PORT} | IA ${API_KEY?'configurée':'non configurée'}`));
