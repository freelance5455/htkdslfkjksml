
const menuBtn=document.getElementById('menuBtn'),navLinks=document.getElementById('navLinks');
if(menuBtn&&navLinks){menuBtn.addEventListener('click',()=>{navLinks.classList.toggle('open');menuBtn.textContent=navLinks.classList.contains('open')?'✕':'☰'});navLinks.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{navLinks.classList.remove('open');menuBtn.textContent='☰'}))}
document.querySelectorAll('#year').forEach(el=>el.textContent=new Date().getFullYear());
const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target)}}),{threshold:.12});
document.querySelectorAll('.reveal,.glass').forEach(el=>{el.classList.add('reveal');observer.observe(el)});
const form=document.getElementById('inquiryForm');
if(form){form.addEventListener('submit',e=>{e.preventDefault();const v=id=>document.getElementById(id).value.trim();const subject=encodeURIComponent('Sports Town — Manufacturing Inquiry: '+v('service'));const body=encodeURIComponent('Name: '+v('name')+'\\nCompany: '+v('company')+'\\nEmail: '+v('email')+'\\nService: '+v('service')+'\\nEstimated quantity: '+v('quantity')+'\\n\\nProject details:\\n'+v('message'));document.getElementById('formNote').textContent='Email draft tayyar hai. Apni email app mein recipient address add karke send karein.';window.location.href='mailto:?subject='+subject+'&body='+body})}
