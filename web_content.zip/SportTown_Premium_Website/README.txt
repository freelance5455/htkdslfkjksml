SPORTS TOWN — PREMIUM 7-PAGE WEBSITE
=====================================

FILES
- index.html          Home
- about.html          About Sports Town
- capabilities.html   OEM / ODM capabilities
- products.html       Product categories
- process.html        Manufacturing workflow
- sustainability.html Responsible production
- contact.html        Inquiry form
- styles.css          Shared responsive styling, glassmorphism and animations
- script.js           Mobile navigation, scroll reveal, inquiry email draft
- assets/sport-town-logo.jpg  Provided logo

HOW TO OPEN
1. Extract the ZIP file.
2. Open the SportTown_Premium_Website folder.
3. Tap/double-click index.html to open the home page in a browser.
4. Use the navigation to visit the seven separate HTML pages.

IMPORTANT BEFORE PUBLISHING
- Replace abstract product category panels with approved product photography.
- Add verified business email, phone, address and WhatsApp link to contact.html.
- The contact form uses a mailto draft. It does not store or transmit data to a backend.
- Google Fonts require internet access; system fallbacks are included.
