# NOVA Messenger — Android project

Это Android Studio / Gradle проект NOVA Messenger. Внутри Android-приложения запускается локальный интерфейс NOVA из `app/src/main/assets/index.html`.

## Сборка APK в GitHub

1. Создайте новый GitHub repository.
2. Загрузите в него все файлы этого проекта.
3. Откройте вкладку **Actions**.
4. Workflow `Build NOVA APK` соберёт debug APK.
5. Готовый APK появится в Artifacts как `NOVA-debug-apk`.

## Сборка локально

Откройте папку проекта в Android Studio и выполните:

```bash
./gradlew assembleDebug
```

APK будет в `app/build/outputs/apk/debug/app-debug.apk`.

## Что внутри

- NOVA Messenger UI;
- светлая серо-сине-белая тема;
- тёмная графитово-синяя тема без белого фона;
- чаты и сообщения;
- профиль, никнейм, описание и баннер;
- локальное хранение данных;
- загрузка изображений через браузерный интерфейс;
- Android WebView-обёртка;
- GitHub Actions для автоматической сборки APK.

## Важно

Настоящая регистрация по SMS, серверные чаты между разными телефонами, push-уведомления и синхронизация требуют backend/API и базы данных. Текущая версия — автономный клиент/демо.
