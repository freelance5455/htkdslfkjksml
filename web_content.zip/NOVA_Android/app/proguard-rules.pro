# NOVA Messenger release rules
