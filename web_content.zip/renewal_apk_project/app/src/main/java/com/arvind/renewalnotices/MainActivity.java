package com.arvind.renewalnotices;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.content.Intent;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.graphics.pdf.PdfRenderer;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.util.Base64;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_POLICY = 7001;
    private WebView webView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new PolicyBridge(), "AndroidPolicy");
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    public void pickPolicyDocument() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf", "image/jpeg", "image/png", "image/webp"});
        startActivityForResult(intent, PICK_POLICY);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_POLICY || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        String mime = getContentResolver().getType(uri);
        String name = getDisplayName(uri);
        Toast.makeText(this, "Policy पढ़ी जा रही है…", Toast.LENGTH_SHORT).show();
        if ("application/pdf".equalsIgnoreCase(mime) || name.toLowerCase(Locale.ROOT).endsWith(".pdf")) {
            processPdf(uri, name);
        } else {
            processImage(uri, name);
        }
    }

    private String getDisplayName(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {} finally { if (c != null) c.close(); }
        return "Policy Document";
    }

    private void processImage(Uri uri, String name) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            Bitmap bitmap = BitmapFactory.decodeStream(in);
            if (bitmap == null) throw new Exception("Image could not be decoded");
            runOcr(bitmap, name, null, null);
        } catch (Exception e) {
            sendError("Image open failed: " + e.getMessage());
        }
    }

    private void processPdf(Uri uri, String name) {
        new Thread(() -> {
            File temp = null;
            ParcelFileDescriptor pfd = null;
            PdfRenderer renderer = null;
            try {
                temp = new File(getCacheDir(), "policy_upload.pdf");
                try (InputStream in = getContentResolver().openInputStream(uri); FileOutputStream out = new FileOutputStream(temp)) {
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                }
                pfd = ParcelFileDescriptor.open(temp, ParcelFileDescriptor.MODE_READ_ONLY);
                renderer = new PdfRenderer(pfd);
                int pages = Math.min(renderer.getPageCount(), 10);
                StringBuilder all = new StringBuilder();
                for (int i = 0; i < pages; i++) {
                    PdfRenderer.Page page = renderer.openPage(i);
                    int width = Math.min(page.getWidth() * 2, 2200);
                    int height = Math.min(page.getHeight() * 2, 3000);
                    Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    page.close();
                    String pageText = recognizeBlocking(bitmap);
                    all.append("\n--- PAGE ").append(i + 1).append(" ---\n").append(pageText);
                    bitmap.recycle();
                }
                final String text = all.toString();
                mainHandler.post(() -> sendOcrResult(name, text, pages));
            } catch (Exception e) {
                sendError("PDF processing failed: " + e.getMessage());
            } finally {
                try { if (renderer != null) renderer.close(); } catch (Exception ignored) {}
                try { if (pfd != null) pfd.close(); } catch (Exception ignored) {}
                if (temp != null) temp.delete();
            }
        }).start();
    }

    private String recognizeBlocking(Bitmap bitmap) throws Exception {
        InputImage image = InputImage.fromBitmap(bitmap, 0);
        TextRecognizer latin = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        TextRecognizer devanagari = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build());
        try {
            Text a = com.google.android.gms.tasks.Tasks.await(latin.process(image));
            StringBuilder result = new StringBuilder(a.getText());
            try {
                Text d = com.google.android.gms.tasks.Tasks.await(devanagari.process(image));
                if (!d.getText().trim().isEmpty() && !d.getText().trim().equals(a.getText().trim())) result.append("\n").append(d.getText());
            } catch (Exception ignored) {}
            return result.toString();
        } finally {
            latin.close();
            devanagari.close();
        }
    }

    private void runOcr(Bitmap bitmap, String name, String unused, Integer unused2) {
        new Thread(() -> {
            try {
                String text = recognizeBlocking(bitmap);
                bitmap.recycle();
                mainHandler.post(() -> sendOcrResult(name, text, 1));
            } catch (Exception e) { sendError("OCR failed: " + e.getMessage()); }
        }).start();
    }

    private void sendOcrResult(String name, String raw, int pages) {
        try {
            JSONObject o = new JSONObject();
            o.put("name", name);
            o.put("pages", pages);
            o.put("text", raw);
            String json = JSONObject.quote(o.toString());
            webView.evaluateJavascript("window.receivePolicyOCR(" + json + ");", null);
        } catch (Exception e) { sendError("Result error: " + e.getMessage()); }
    }

    private void sendError(String message) {
        mainHandler.post(() -> webView.evaluateJavascript("window.receivePolicyOCRError(" + JSONObject.quote(message) + ");", null));
    }

    public class PolicyBridge {
        @JavascriptInterface public void choosePolicy() { runOnUiThread(() -> pickPolicyDocument()); }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
