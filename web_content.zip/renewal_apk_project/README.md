# Renewal Notices — Android project

App name: Renewal Notices
Package: com.arvind.renewalnotices
Theme/icon: Vehicle

## Build APK
1. Open this folder in Android Studio.
2. Let Gradle sync/download Android Gradle Plugin 8.6.1.
3. Build > Build APK(s).
4. The debug APK will be under app/build/outputs/apk/debug/app-debug.apk.

The original HTML prototype is bundled as a local WebView asset, so its JavaScript/localStorage data stays inside the app.
