# Renewal Notices Android Project v2.0

Insurance Renewal Manager with **Policy Upload -> OCR -> Auto Fill**.

## Advanced policy upload
- Upload PDF, JPG, PNG or WebP from the Android app.
- PDF pages are rendered on-device (up to 10 pages) and processed with Google ML Kit OCR.
- Latin and Devanagari OCR models are bundled.
- The OCR result is parsed for customer name, mobile, vehicle number, policy number, insurer, policy type, start/expiry date, premium and agent/RM.
- The form is auto-filled, but the user must verify the extracted values before saving.
- Raw OCR text and uploaded document name are stored with the customer record in localStorage.

## Build
Open the `renewal_apk_project` folder in Android Studio and sync Gradle. Then use **Build > Build APK(s)**.

The project currently uses ML Kit Text Recognition bundled models. The OCR dependency versions are based on Google's current Android ML Kit documentation/release information.

## Important limitation
OCR is not guaranteed to read every insurer's layout perfectly. Policy formats vary, so the app intentionally shows the extracted fields for review before saving.
