Exam G9220 Android project (source code, NOT an APK)

Important: Do not rename this ZIP file to .apk. A ZIP/project must be built to produce an APK.

This project includes a GitHub Actions workflow at .github/workflows/build-apk.yml to build a debug APK in the cloud.

Mobile-only outline:
1. Extract this ZIP on your phone using a file manager/archive app.
2. Create a GitHub repository in your phone browser.
3. Upload the extracted project files and folders to the repository, keeping the folder structure and the .github/workflows/build-apk.yml file.
4. Open the repository's Actions tab and run “Build Exam G9220 APK” (or wait for the push workflow to run).
5. When the run completes successfully, open that run and download the “Exam-G9220-debug-apk” artifact ZIP.
6. Extract the artifact ZIP. Inside it is app-debug.apk. Install that APK on your Android phone.

Note: GitHub's mobile website may make uploading a folder tree difficult. If you cannot upload folders while preserving their structure, use an Android app that can upload a repository/folder tree, or use AndroidIDE to build locally. Never rename a ZIP to .apk.
