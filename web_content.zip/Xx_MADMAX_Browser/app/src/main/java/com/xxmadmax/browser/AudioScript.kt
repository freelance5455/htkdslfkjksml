// Reserved for future WebAudio processing. The current app exposes basic controls;
// processing is best-effort and depends on the website's media and browser security rules.
