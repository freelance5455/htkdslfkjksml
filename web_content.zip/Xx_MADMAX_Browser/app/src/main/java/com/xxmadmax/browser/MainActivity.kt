package com.xxmadmax.browser

import android.content.Intent
import android.graphics.Color
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import android.app.DownloadManager
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.webkit.WebViewAssetLoader
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var status: TextView
    private lateinit var desktopButton: Button
    private lateinit var tabCount: Button
    private lateinit var webHost: FrameLayout
    private val tabs = mutableListOf<WebView>()
    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }
    private val homeUrl = "https://appassets.androidplatform.net/assets/www/index.html"
    private var desktop = false
    private val extensionRoot by lazy { File(filesDir, "extensions").apply { mkdirs() } }
    private val bookmarks by lazy { getSharedPreferences("bookmarks", MODE_PRIVATE) }

    private val zipPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importExtension(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 10, 20)
        window.navigationBarColor = Color.rgb(12, 10, 20)
        buildUi()
        newTab(homeUrl)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun button(label: String) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 11f
        setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(38, 27, 55))
        minWidth = dp(40); minHeight = dp(42); setPadding(dp(5), 0, dp(5), 0)
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(10, 9, 17))
        }
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(8), 0)
            setBackgroundColor(Color.rgb(15, 12, 25))
        }
        val brand = TextView(this).apply {
            text = "✦ Xx MADMAX"; textSize = 19f
            setTextColor(Color.rgb(219, 145, 255)); typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        header.addView(brand, LinearLayout.LayoutParams(0, dp(48), 1f))
        tabCount = button("1 ▢")
        tabCount.setOnClickListener { showTabs() }
        header.addView(tabCount)
        page.addView(header)

        val addressRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6)); setBackgroundColor(Color.rgb(15, 12, 25))
        }
        address = EditText(this).apply {
            hint = "Search or enter website"; singleLine = true; textSize = 14f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setBackgroundColor(Color.rgb(39, 34, 49)); setPadding(dp(12), 0, dp(8), 0)
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO) { navigate(text.toString()); true } else false
            }
        }
        addressRow.addView(address, LinearLayout.LayoutParams(0, dp(44), 1f))
        val go = button("GO"); go.setOnClickListener { navigate(address.text.toString()) }
        addressRow.addView(go)
        page.addView(addressRow)

        webHost = FrameLayout(this)
        page.addView(webHost, LinearLayout.LayoutParams(-1, 0, 1f))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(dp(4), dp(4), dp(4), dp(4)); setBackgroundColor(Color.rgb(17, 14, 27))
        }
        val back = button("‹"); back.setOnClickListener { if (web.canGoBack()) web.goBack() }
        val forward = button("›"); forward.setOnClickListener { if (web.canGoForward()) web.goForward() }
        val home = button("⌂"); home.setOnClickListener { newTab(homeUrl) }
        val reload = button("↻"); reload.setOnClickListener { web.reload() }
        desktopButton = button("Desktop"); desktopButton.setOnClickListener { toggleDesktop() }
        val menu = button("⋮"); menu.setOnClickListener { showBrowserMenu() }
        listOf(back, forward, home, reload, desktopButton, menu).forEach {
            controls.addView(it, LinearLayout.LayoutParams(0, dp(44), 1f).apply {
                setMargins(dp(2), 0, dp(2), 0)
            })
        }
        page.addView(controls)
        status = TextView(this).apply {
            text = "Ready"; textSize = 10f; setTextColor(Color.LTGRAY)
            setPadding(dp(10), dp(3), dp(10), dp(5)); setBackgroundColor(Color.rgb(17, 14, 27))
        }
        page.addView(status)
        setContentView(page)
    }

    @Suppress("SetJavaScriptEnabled")
    private fun createWebView(): WebView {
        val view = WebView(this)
        view.setBackgroundColor(Color.WHITE)
        view.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            blockNetworkImage = false
            useWideViewPort = true
            loadWithOverviewMode = false
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = false
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            builtInZoomControls = true
            displayZoomControls = false
            textZoom = 100
            if (android.os.Build.VERSION.SDK_INT >= 26) safeBrowsingEnabled = true
        }
        view.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, request: WebResourceRequest): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }
            override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                return when (uri.scheme?.lowercase()) {
                    "http", "https", "file", "about", "data", "blob" -> false
                    else -> {
                        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) { }
                        true
                    }
                }
            }
            override fun onPageStarted(v: WebView, url: String, favicon: Bitmap?) {
                if (v == web) { address.setText(url); status.text = "Loading…" }
            }
            override fun onPageFinished(v: WebView, url: String) {
                if (v == web) {
                    address.setText(url); status.text = "Loaded"
                    installAudioController(v)
                    injectImportedScripts(v, url)
                }
            }
            override fun onReceivedError(v: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (v == web && request.isForMainFrame) status.text = "Could not load page • ${error.description}"
            }
            override fun onRenderProcessGone(v: WebView, detail: RenderProcessGoneDetail): Boolean {
                val wasActive = v == web
                val index = tabs.indexOf(v)
                if (index >= 0) tabs.removeAt(index)
                webHost.removeView(v)
                v.destroy()
                if (tabs.isEmpty()) newTab(homeUrl)
                else if (wasActive) switchTab((index - 1).coerceAtLeast(0))
                Toast.makeText(this@MainActivity, "A page was restarted to recover memory", Toast.LENGTH_SHORT).show()
                return true
            }
        }
        view.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, progress: Int) {
                if (v == web && progress < 100) status.text = "Loading $progress%"
            }
            override fun onReceivedTitle(v: WebView, title: String?) {
                if (v == web && !title.isNullOrBlank()) status.text = title.take(55)
            }
        }
        view.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val request = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mimeType)
                    .addRequestHeader("User-Agent", userAgent)
                    .setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS,
                        URLUtil.guessFileName(url, contentDisposition, mimeType))
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { Toast.makeText(this, "Download failed: ${e.message}", Toast.LENGTH_LONG).show() }
        }
        return view
    }

    private fun newTab(url: String) {
        val v = createWebView()
        tabs.add(v)
        webHost.addView(v, FrameLayout.LayoutParams(-1, -1))
        switchTab(tabs.lastIndex)
        v.loadUrl(url)
    }

    private fun switchTab(index: Int) {
        if (tabs.isEmpty()) return
        val safe = index.coerceIn(0, tabs.lastIndex)
        tabs.forEachIndexed { i, v -> v.visibility = if (i == safe) View.VISIBLE else View.GONE }
        web = tabs[safe]
        address.setText(web.url ?: "")
        tabCount.text = "${tabs.size} ▢"
        desktopButton.text = if (desktop) "Mobile" else "Desktop"
    }

    private fun showTabs() {
        val labels = tabs.mapIndexed { i, v -> "${i + 1}. ${v.title ?: v.url ?: "New tab"}" }.toTypedArray()
        android.app.AlertDialog.Builder(this)
            .setTitle("Open tabs")
            .setItems(labels) { _, which -> switchTab(which) }
            .setPositiveButton("New tab") { _, _ -> newTab(homeUrl) }
            .setNegativeButton("Close current") { _, _ -> closeCurrentTab() }
            .show()
    }

    private fun closeCurrentTab() {
        if (tabs.size <= 1) { web.loadUrl(homeUrl); return }
        val index = tabs.indexOf(web)
        webHost.removeView(web); web.stopLoading(); web.destroy(); tabs.remove(web)
        switchTab((index - 1).coerceAtLeast(0))
    }

    private fun showBrowserMenu() {
        val options = arrayOf("New tab", "Bookmarks", "Add bookmark", "Import extension ZIP", "Audio controls", "Downloads", "Reload page")
        android.app.AlertDialog.Builder(this).setTitle("Xx MADMAX menu").setItems(options) { _, which ->
            when (which) {
                0 -> newTab(homeUrl)
                1 -> showBookmarks()
                2 -> addBookmark()
                3 -> zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "*/*"))
                4 -> showEqualizer()
                5 -> startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
                6 -> web.reload()
            }
        }.show()
    }

    private fun navigate(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        val target = if (text.matches(Regex("(?i)^[a-z][a-z0-9+.-]*://.*"))) text
        else if (text.contains(".") && !text.contains(" ")) "https://$text"
        else "https://www.google.com/search?q=" + Uri.encode(text)
        web.loadUrl(target)
    }

    private fun toggleDesktop() {
        desktop = !desktop
        web.settings.userAgentString = if (desktop)
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
        else WebSettings.getDefaultUserAgent(this)
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = false
        web.settings.textZoom = 100
        desktopButton.text = if (desktop) "Mobile" else "Desktop"
        web.reload()
    }

    private fun addBookmark() {
        val url = web.url ?: return
        val title = web.title ?: url
        val all = bookmarks.getStringSet("items", emptySet())!!.toMutableSet()
        all.add("$title\n$url")
        bookmarks.edit().putStringSet("items", all).apply()
        Toast.makeText(this, "Bookmark saved", Toast.LENGTH_SHORT).show()
    }

    private fun showBookmarks() {
        val items = bookmarks.getStringSet("items", emptySet())!!.toList()
        if (items.isEmpty()) { Toast.makeText(this, "No bookmarks yet", Toast.LENGTH_SHORT).show(); return }
        android.app.AlertDialog.Builder(this).setTitle("Bookmarks")
            .setItems(items.map { it.substringBefore('\n') }.toTypedArray()) { _, which ->
                val url = items[which].substringAfter('\n', "")
                if (url.isNotBlank()) web.loadUrl(url)
            }.setNegativeButton("Close", null).show()
    }

    private fun importExtension(uri: Uri) {
        try {
            val name = "ext_" + System.currentTimeMillis()
            val dest = File(extensionRoot, name).apply { mkdirs() }
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Could not open ZIP" }
                ZipInputStream(input).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        val out = File(dest, entry.name).canonicalFile
                        require(out.path.startsWith(dest.canonicalPath + File.separator) || out == dest) { "Unsafe ZIP entry" }
                        if (entry.isDirectory) out.mkdirs() else {
                            out.parentFile?.mkdirs()
                            out.outputStream().use { output -> zis.copyTo(output) }
                        }
                        zis.closeEntry(); entry = zis.nextEntry
                    }
                }
            }
            val manifest = File(dest, "manifest.json")
            require(manifest.exists()) { "ZIP must contain manifest.json" }
            val json = JSONObject(manifest.readText())
            status.text = "Imported: ${json.optString("name", name)} • limited support"
            Toast.makeText(this, "ZIP imported (limited extension support)", Toast.LENGTH_LONG).show()
            web.reload()
        } catch (e: Exception) {
            Toast.makeText(this, "Import failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun injectImportedScripts(view: WebView, url: String) {
        extensionRoot.listFiles()?.forEach { dir ->
            try {
                val manifestFile = File(dir, "manifest.json")
                if (!manifestFile.isFile) return@forEach
                val manifest = JSONObject(manifestFile.readText())
                val scripts = manifest.optJSONArray("content_scripts") ?: return@forEach
                for (i in 0 until scripts.length()) {
                    val item = scripts.getJSONObject(i)
                    if (!matches(item.optJSONArray("matches"), url.lowercase())) continue
                    val js = item.optJSONArray("js") ?: JSONArray()
                    for (j in 0 until js.length()) {
                        val script = File(dir, js.getString(j)).canonicalFile
                        if (script.path.startsWith(dir.canonicalPath + File.separator) && script.isFile) {
                            val encoded = JSONObject.quote(script.readText())
                            view.evaluateJavascript("(function(){try{(new Function($encoded))()}catch(e){console.warn(e)}})();", null)
                        }
                    }
                }
            } catch (_: Exception) { }
        }
    }

    private fun matches(patterns: JSONArray?, url: String): Boolean {
        if (patterns == null) return false
        for (i in 0 until patterns.length()) {
            val pattern = patterns.optString(i)
            if (pattern == "<all_urls>" || pattern == "*://*/*") return true
            val host = pattern.substringAfter("://", "").substringBefore("/")
            if (host.isNotBlank() && url.contains(host.removePrefix("*"))) return true
        }
        return false
    }

    private fun installAudioController(view: WebView) {
        val script = """
          (function(){
            if(window.__madmaxAudioInstalled)return;
            window.__madmaxAudioInstalled=true;
            const state={gain:1,bass:0,treble:0}, nodes=new WeakMap();
            function attach(el){
              if(nodes.has(el))return;
              try{
                const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
                const ctx=new C(),src=ctx.createMediaElementSource(el);
                const low=ctx.createBiquadFilter();low.type='lowshelf';low.frequency.value=180;
                const high=ctx.createBiquadFilter();high.type='highshelf';high.frequency.value=3500;
                const gain=ctx.createGain(),comp=ctx.createDynamicsCompressor();
                src.connect(low);low.connect(high);high.connect(gain);gain.connect(comp);comp.connect(ctx.destination);
                const n={ctx,low,high,gain};nodes.set(el,n);
                el.addEventListener('play',()=>ctx.resume().catch(()=>{}),{once:false});
                apply(n);
              }catch(e){}
            }
            function apply(n){n.gain.gain.value=state.gain;n.low.gain.value=state.bass;n.high.gain.value=state.treble;}
            window.__madmaxAudio=function(k,v){
              if(k==='gain')state.gain=Math.max(0,Math.min(3,v));
              if(k==='bass')state.bass=Math.max(-12,Math.min(12,v));
              if(k==='treble')state.treble=Math.max(-12,Math.min(12,v));
              document.querySelectorAll('audio,video').forEach(attach);
            };
            document.querySelectorAll('audio,video').forEach(attach);
            const observer=new MutationObserver(records=>{
              for(const r of records)for(const n of r.addedNodes){
                if(n.nodeType!==1)continue;
                if(n.matches&&n.matches('audio,video'))attach(n);
                if(n.querySelectorAll)n.querySelectorAll('audio,video').forEach(attach);
              }
            });
            observer.observe(document.documentElement,{childList:true,subtree:true});
          })();
        """.trimIndent()
        view.evaluateJavascript(script, null)
    }

    private fun showEqualizer() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(8))
            setBackgroundColor(Color.rgb(24, 20, 38))
        }
        panel.addView(TextView(this).apply {
            text = "AUDIO CONTROL • WEB MEDIA"; setTextColor(Color.rgb(220, 130, 255)); textSize = 16f
        })
        fun slider(label: String, min: Int, max: Int, start: Int, callback: (Int) -> Unit) {
            val title = TextView(this).apply { text = "$label: $start"; setTextColor(Color.WHITE) }
            panel.addView(title)
            panel.addView(SeekBar(this).apply {
                this.max = max - min; progress = start - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                        val value = p + min; title.text = "$label: $value"; callback(value)
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }
        slider("Gain", 0, 300, 100) { applyAudio("gain", it / 100.0) }
        slider("Bass", -12, 12, 0) { applyAudio("bass", it.toDouble()) }
        slider("Treble", -12, 12, 0) { applyAudio("treble", it.toDouble()) }
        android.app.AlertDialog.Builder(this).setView(panel).setPositiveButton("Close", null).show()
    }

    private fun applyAudio(key: String, value: Double) {
        web.evaluateJavascript("window.__madmaxAudio&&window.__madmaxAudio('$key',$value);", null)
    }

    override fun onPause() { tabs.forEach { it.onPause() }; super.onPause() }
    override fun onResume() { super.onResume(); if (::web.isInitialized) web.onResume() }
    override fun onDestroy() {
        tabs.forEach { it.stopLoading(); it.loadUrl("about:blank"); it.destroy() }
        tabs.clear()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack()
        else if (tabs.size > 1) closeCurrentTab()
        else super.onBackPressed()
    }
}
