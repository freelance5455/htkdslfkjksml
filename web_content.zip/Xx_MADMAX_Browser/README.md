# Xx MADMAX Browser — Quetta-inspired Android browser

## Included
- Dark neon browser UI with address/search field
- Multi-tab switching and new/close tab
- Desktop-site user-agent toggle
- Bookmarks
- Download manager handoff
- ZIP import and limited best-effort content-script support
- Web media gain, bass and treble controls
- WebView rendering recovery and performance-oriented settings

## Build APK
Open this project in Android Studio, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Important limitations
This is a Quetta-inspired starter browser, not a copy of Quetta. Android System WebView does not support the complete Chrome extension platform. ZIP import only provides limited content-script injection; browser APIs, service workers/background scripts, extension popups, and many Manifest V3 features are not supported. Audio controls only affect compatible HTML audio/video elements on pages that permit WebAudio processing; they cannot increase Android's hardware volume.

This is source code, not a compiled APK. Test on your Android device before daily use. The browser has not been device-tested in this environment.
