import os, io, csv, sqlite3, secrets, string, shutil
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file, Response
from werkzeug.security import generate_password_hash, check_password_hash

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(APP_DIR, "data", "raseel_mian.db")
BACKUP_DIR = os.path.join(APP_DIR, "backups")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
os.makedirs(BACKUP_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("RASEEL_SECRET_KEY", secrets.token_hex(32))
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS staff(
          id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL,
          password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'admin',
          active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS packages(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, quota_gb REAL NOT NULL,
          validity_hours INTEGER NOT NULL, price REAL NOT NULL, active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS customers(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, phone TEXT, address TEXT, notes TEXT,
          created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS vouchers(
          id INTEGER PRIMARY KEY, package_id INTEGER, username TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'available',
          batch TEXT, created_at TEXT NOT NULL, sold_at TEXT,
          FOREIGN KEY(package_id) REFERENCES packages(id));
        CREATE TABLE IF NOT EXISTS sales(
          id INTEGER PRIMARY KEY, voucher_id INTEGER, customer_id INTEGER,
          package_name TEXT NOT NULL, amount REAL NOT NULL, quantity INTEGER NOT NULL DEFAULT 1,
          payment_method TEXT DEFAULT 'cash', seller TEXT, created_at TEXT NOT NULL,
          FOREIGN KEY(voucher_id) REFERENCES vouchers(id),
          FOREIGN KEY(customer_id) REFERENCES customers(id));
        CREATE TABLE IF NOT EXISTS expenses(
          id INTEGER PRIMARY KEY, title TEXT NOT NULL, category TEXT, amount REAL NOT NULL,
          notes TEXT, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS routers(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, model TEXT, host TEXT,
          api_port INTEGER DEFAULT 8729, username TEXT, notes TEXT,
          status TEXT DEFAULT 'not_connected', created_at TEXT NOT NULL);
        """)
        count = c.execute("SELECT COUNT(*) n FROM staff").fetchone()["n"]
        if not count:
            pwd = os.environ.get("RASEEL_ADMIN_PASSWORD", "ChangeMe-123!")
            c.execute("INSERT INTO staff(username,password_hash,role,created_at) VALUES(?,?,?,?)",
                      ("admin", generate_password_hash(pwd), "admin", now()))
        if c.execute("SELECT COUNT(*) n FROM packages").fetchone()["n"] == 0:
            c.executemany("INSERT INTO packages(name,quota_gb,validity_hours,price) VALUES(?,?,?,?)", [
                ("1GB",1,12,500),("2GB",2,24,1000),("5GB",5,168,2500),("10GB",10,720,5000)
            ])

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def login_required(f):
    @wraps(f)
    def wrapper(*a, **kw):
        if not session.get("uid"):
            return redirect(url_for("login"))
        return f(*a, **kw)
    return wrapper

def admin_required():
    return session.get("role") == "admin"

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        u = request.form.get("username","").strip()
        p = request.form.get("password","")
        with db() as c:
            user = c.execute("SELECT * FROM staff WHERE username=? AND active=1",(u,)).fetchone()
        if user and check_password_hash(user["password_hash"],p):
            session.clear()
            session.update(uid=user["id"], username=user["username"], role=user["role"])
            return redirect(url_for("index"))
        flash("بيانات الدخول غير صحيحة")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/")
@login_required
def index():
    with db() as c:
        stats = {
          "vouchers": c.execute("SELECT COUNT(*) n FROM vouchers").fetchone()["n"],
          "available": c.execute("SELECT COUNT(*) n FROM vouchers WHERE status='available'").fetchone()["n"],
          "customers": c.execute("SELECT COUNT(*) n FROM customers").fetchone()["n"],
          "sales": c.execute("SELECT COALESCE(SUM(amount),0) n FROM sales").fetchone()["n"],
          "expenses": c.execute("SELECT COALESCE(SUM(amount),0) n FROM expenses").fetchone()["n"],
          "routers": c.execute("SELECT COUNT(*) n FROM routers").fetchone()["n"],
          "today_sales": c.execute("SELECT COALESCE(SUM(amount),0) n FROM sales WHERE date(created_at)=date('now','localtime')").fetchone()["n"]
        }
        recent = c.execute("SELECT * FROM sales ORDER BY id DESC LIMIT 8").fetchall()
    stats["profit"] = stats["sales"] - stats["expenses"]
    return render_template("index.html", stats=stats, recent=recent)

@app.route("/packages", methods=["GET","POST"])
@login_required
def packages():
    with db() as c:
        if request.method == "POST":
            c.execute("INSERT INTO packages(name,quota_gb,validity_hours,price) VALUES(?,?,?,?)",
              (request.form["name"],float(request.form["quota_gb"]),int(request.form["validity_hours"]),float(request.form["price"])))
            flash("تمت إضافة الباقة")
            return redirect(url_for("packages"))
        rows = c.execute("SELECT * FROM packages ORDER BY id DESC").fetchall()
    return render_template("packages.html", rows=rows)

@app.route("/packages/<int:pid>/delete", methods=["POST"])
@login_required
def delete_package(pid):
    with db() as c:
        c.execute("UPDATE packages SET active=0 WHERE id=?",(pid,))
    flash("تم إيقاف الباقة")
    return redirect(url_for("packages"))

def token(n=8):
    alphabet = string.ascii_uppercase + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(n))

@app.route("/vouchers", methods=["GET","POST"])
@login_required
def vouchers():
    with db() as c:
        if request.method == "POST":
            pid = int(request.form["package_id"])
            qty = max(1,min(500,int(request.form["quantity"])))
            batch = "RM-" + datetime.now().strftime("%y%m%d%H%M%S")
            for _ in range(qty):
                username = token(8)
                password = token(6)
                while c.execute("SELECT 1 FROM vouchers WHERE username=?",(username,)).fetchone():
                    username = token(8)
                c.execute("INSERT INTO vouchers(package_id,username,password,batch,created_at) VALUES(?,?,?,?,?)",
                          (pid,username,password,batch,now()))
            flash(f"تم إنشاء {qty} كرت")
            return redirect(url_for("vouchers"))
        rows = c.execute("""SELECT v.*,p.name package_name,p.price FROM vouchers v
                          LEFT JOIN packages p ON p.id=v.package_id ORDER BY v.id DESC LIMIT 300""").fetchall()
        packs = c.execute("SELECT * FROM packages WHERE active=1 ORDER BY quota_gb").fetchall()
    return render_template("vouchers.html", rows=rows, packs=packs)

@app.route("/vouchers/export")
@login_required
def export_vouchers():
    with db() as c:
        rows = c.execute("""SELECT v.username,v.password,p.name,v.status,v.batch,v.created_at
          FROM vouchers v LEFT JOIN packages p ON p.id=v.package_id ORDER BY v.id DESC""").fetchall()
    out=io.StringIO()
    w=csv.writer(out); w.writerow(["username","password","package","status","batch","created_at"])
    for r in rows: w.writerow(list(r))
    return Response("\ufeff"+out.getvalue(), mimetype="text/csv; charset=utf-8",
                    headers={"Content-Disposition":"attachment; filename=raseel_vouchers.csv"})

@app.route("/vouchers/<int:vid>/sell", methods=["POST"])
@login_required
def sell_voucher(vid):
    with db() as c:
        v = c.execute("""SELECT v.*,p.name package_name,p.price FROM vouchers v
                         LEFT JOIN packages p ON p.id=v.package_id WHERE v.id=?""",(vid,)).fetchone()
        if not v or v["status"] != "available":
            flash("الكرت غير متاح للبيع")
        else:
            customer_id = request.form.get("customer_id") or None
            c.execute("UPDATE vouchers SET status='sold',sold_at=? WHERE id=?",(now(),vid))
            c.execute("""INSERT INTO sales(voucher_id,customer_id,package_name,amount,seller,created_at)
                         VALUES(?,?,?,?,?,?)""",(vid,customer_id,v["package_name"],v["price"],session.get("username"),now()))
            flash("تم تسجيل بيع الكرت")
    return redirect(url_for("vouchers"))

@app.route("/customers", methods=["GET","POST"])
@login_required
def customers():
    with db() as c:
        if request.method == "POST":
            c.execute("INSERT INTO customers(name,phone,address,notes,created_at) VALUES(?,?,?,?,?)",
              (request.form["name"],request.form.get("phone"),request.form.get("address"),request.form.get("notes"),now()))
            flash("تمت إضافة العميل")
            return redirect(url_for("customers"))
        rows=c.execute("SELECT * FROM customers ORDER BY id DESC").fetchall()
    return render_template("customers.html",rows=rows)

@app.route("/expenses", methods=["GET","POST"])
@login_required
def expenses():
    with db() as c:
        if request.method=="POST":
            c.execute("INSERT INTO expenses(title,category,amount,notes,created_at) VALUES(?,?,?,?,?)",
              (request.form["title"],request.form.get("category"),float(request.form["amount"]),request.form.get("notes"),now()))
            flash("تم تسجيل المصروف")
            return redirect(url_for("expenses"))
        rows=c.execute("SELECT * FROM expenses ORDER BY id DESC").fetchall()
    return render_template("expenses.html",rows=rows)

@app.route("/routers", methods=["GET","POST"])
@login_required
def routers():
    with db() as c:
        if request.method=="POST":
            c.execute("""INSERT INTO routers(name,model,host,api_port,username,notes,created_at)
              VALUES(?,?,?,?,?,?,?)""",(request.form["name"],request.form.get("model"),request.form.get("host"),
              int(request.form.get("api_port") or 8729),request.form.get("username"),request.form.get("notes"),now()))
            flash("تم حفظ بيانات الراوتر. الاتصال الفعلي غير مفعّل بعد.")
            return redirect(url_for("routers"))
        rows=c.execute("SELECT * FROM routers ORDER BY id DESC").fetchall()
    return render_template("routers.html",rows=rows)

@app.route("/staff", methods=["GET","POST"])
@login_required
def staff():
    if not admin_required():
        flash("هذه الصفحة للمدير فقط"); return redirect(url_for("index"))
    with db() as c:
        if request.method=="POST":
            try:
                c.execute("INSERT INTO staff(username,password_hash,role,created_at) VALUES(?,?,?,?)",
                  (request.form["username"],generate_password_hash(request.form["password"]),
                   request.form["role"],now()))
                flash("تم إنشاء حساب الموظف")
            except sqlite3.IntegrityError:
                flash("اسم المستخدم مستخدم مسبقاً")
            return redirect(url_for("staff"))
        rows=c.execute("SELECT id,username,role,active,created_at FROM staff ORDER BY id").fetchall()
    return render_template("staff.html",rows=rows)

@app.route("/reports")
@login_required
def reports():
    with db() as c:
        monthly=c.execute("""SELECT strftime('%Y-%m',created_at) month, SUM(amount) total
          FROM sales GROUP BY month ORDER BY month DESC LIMIT 12""").fetchall()
        by_package=c.execute("""SELECT package_name, SUM(quantity) qty, SUM(amount) total
          FROM sales GROUP BY package_name ORDER BY total DESC""").fetchall()
        totals=c.execute("""SELECT
          (SELECT COALESCE(SUM(amount),0) FROM sales) sales,
          (SELECT COALESCE(SUM(amount),0) FROM expenses) expenses""").fetchone()
    return render_template("reports.html",monthly=monthly,by_package=by_package,totals=totals)

@app.route("/backup")
@login_required
def backup():
    if not admin_required():
        flash("النسخ الاحتياطي للمدير فقط"); return redirect(url_for("index"))
    name="raseel_mian_backup_"+datetime.now().strftime("%Y%m%d_%H%M%S")+".db"
    target=os.path.join(BACKUP_DIR,name)
    shutil.copy2(DB_PATH,target)
    return send_file(target,as_attachment=True,download_name=name)

@app.route("/change-password", methods=["GET","POST"])
@login_required
def change_password():
    if request.method=="POST":
        old=request.form["old_password"]; new=request.form["new_password"]
        with db() as c:
            u=c.execute("SELECT * FROM staff WHERE id=?",(session["uid"],)).fetchone()
            if not check_password_hash(u["password_hash"],old):
                flash("كلمة المرور الحالية غير صحيحة")
            elif len(new)<10:
                flash("اجعل كلمة المرور 10 أحرف على الأقل")
            else:
                c.execute("UPDATE staff SET password_hash=? WHERE id=?",(generate_password_hash(new),session["uid"]))
                flash("تم تغيير كلمة المرور")
                return redirect(url_for("index"))
    return render_template("change_password.html")

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT",5000)), debug=False)
