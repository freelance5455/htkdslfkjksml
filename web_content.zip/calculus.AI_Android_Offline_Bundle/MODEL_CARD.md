# Local Tutor Model Card

Name: calculus.AI Local Tutor v1
Type: deterministic rule-based question matcher + arithmetic evaluator
Network: no network calls
Training: no machine-learning training was performed
Knowledge: bundled JSON examples and formulas
Capabilities: simple arithmetic expressions, percentage-of calculations, a limited linear-equation pattern, selected maths/physics/biology/chemistry explanations
Limitations: no general reasoning, no broad natural-language understanding, no adaptive learning, no reliable multi-step symbolic algebra, no guarantee of correctness outside its narrow rules
Privacy: user prompts are processed in the browser by local JavaScript; the bundled engine does not transmit them.
