from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
web=root/'www'
assert (web/'index.html').exists()
assert (web/'data/offline-ai.js').exists()
assert (web/'data/knowledge.json').exists()
json.loads((web/'data/knowledge.json').read_text(encoding='utf-8'))
json.loads((web/'data/formulas.json').read_text(encoding='utf-8'))
assert 'purple' not in (web/'index.html').read_text(encoding='utf-8').lower()
print('Bundle checks passed.')
print('Knowledge entries:', len(json.loads((web/'data/knowledge.json').read_text(encoding='utf-8'))))
