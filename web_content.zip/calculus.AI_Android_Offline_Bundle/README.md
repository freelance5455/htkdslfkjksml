# calculus.AI — Android Offline Bundle

This ZIP combines the previous UI project and a new lightweight offline tutor engine into one package.

## What this is
- A web UI bundle that can be wrapped in an Android WebView.
- A rule-based/local knowledge tutor with simple arithmetic and selected worked examples.
- A bundled maths/physics formula reference and short knowledge entries.
- No external AI model, cloud API, account, or API key is connected.

## Important limitation
This is **not a newly trained large language model**. Training a capable language model from scratch typically requires a very large dataset, substantial compute, and a training/inference runtime. This bundle uses local rules and curated knowledge so it can run without internet, and it will have limited coverage.

## Preview
Open `www/index.html` in a browser. The offline tutor panel is appended near the bottom of the page. To test offline web app caching, serve the `www` folder over HTTPS or localhost.

## Convert to APK on Android
1. Extract this ZIP.
2. Use a trusted Android WebView wrapper / web-to-APK builder that accepts local HTML assets.
3. Package the **contents of the `www` folder** as local assets (not just `index.html`; include `data/` and `assets/`).
4. Enable JavaScript in the WebView.
5. Build and install the APK, then test in airplane mode.
6. If using a cloud-based builder, upload only files you are comfortable sharing.

This ZIP does not include Android SDK, Gradle, a compiled APK, or APK-signing keys.
