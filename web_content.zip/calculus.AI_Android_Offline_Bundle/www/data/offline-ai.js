(function(){
'use strict';
const $ = id => document.getElementById(id);
async function loadKnowledge(){
 try { const r = await fetch('data/knowledge.json'); return await r.json(); }
 catch(e) { return []; }
}
function normalize(s){return String(s||'').toLowerCase().replace(/[^\p{L}\p{N}+\-*/=().²√π]/gu,' ').replace(/\s+/g,' ').trim();}
function safeCalc(input){
 let s=String(input).toLowerCase().replace(/,/g,'').replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-').replace(/π/g,'Math.PI').replace(/\^/g,'**').trim();
 if(!s || s.length>120) return null;
 if(!/^[0-9+\-*/().\s%*]+$/.test(s.replace(/\*\*/g,'**'))) return null;
 if(/\/\s*0(?![0-9.])/.test(s)) return {error:'Division by zero is undefined.'};
 try{
   const v=Function('"use strict";return ('+s+')')();
   if(typeof v!=='number'||!Number.isFinite(v)) return {error:'That expression does not have a finite real-number result.'};
   return {value:v};
 }catch(e){return null;}
}
function solveLinear(q){
 const m=q.match(/solve\s+([+-]?\d*\.?\d*)\s*x\s*([+-]\s*\d+\.?\d*)?\s*=\s*([+-]?\d+\.?\d*)/i);
 if(!m)return null;
 let a=m[1]; a=(a===''||a==='+')?1:(a==='-'?-1:Number(a));
 const b=m[2]?Number(m[2].replace(/\s/g,'')):0, c=Number(m[3]);
 if(!a)return 'This equation has no unique solution because the coefficient of x is zero.';
 const x=(c-b)/a;
 return `Let's solve ${m[0].replace(/^solve\s+/i,'')}.\\n1. Move the constant term to the other side: ${a}x = ${c-b}.\\n2. Divide both sides by ${a}.\\nAnswer: x = ${Number(x.toPrecision(10))}.\\nCheck by substituting the value back into the original equation.`;
}
function simpleMath(q){
 const m=q.match(/(?:what is|calculate|compute|evaluate|solve)?\s*(-?\d+(?:\.\d+)?(?:\s*[\+\-*\/]\s*-?\d+(?:\.\d+)?)+)\s*\??$/i);
 if(m){
  const r=safeCalc(m[1]);
  if(r?.error)return r.error;
  if(r)return `Calculation: ${m[1]} = ${Number(r.value.toPrecision(12))}.\\nI evaluated the arithmetic expression locally on your device.`;
 }
 const percent=q.match(/(\d+(?:\.\d+)?)\s*%\s*(?:of)\s*(\d+(?:\.\d+)?)/i);
 if(percent){const v=Number(percent[1])*Number(percent[2])/100;return `${percent[1]}% of ${percent[2]} = (${percent[1]} ÷ 100) × ${percent[2]} = ${v}.`;}
 const linear=solveLinear(q); if(linear)return linear;
 return null;
}
async function answer(question){
 const q=normalize(question);
 if(!q)return 'Type a question first.';
 const math=simpleMath(q); if(math)return math;
 const data=await loadKnowledge();
 let best=null,score=0;
 for(const item of data){
  for(const phrase of item.q||[]){
   const p=normalize(phrase);
   if(q===p){best=item;score=Math.max(score,100);}
   else if(q.includes(p)||p.includes(q)){let n=Math.min(p.length,q.length)/Math.max(p.length,q.length);if(n*80>score){best=item;score=n*80;}}
   else {
    const tokens=p.split(' ').filter(t=>t.length>2);
    const matches=tokens.filter(t=>q.includes(t)).length;
    const s=tokens.length?matches/tokens.length*55:0;
    if(s>score){best=item;score=s;}
   }
  }
 }
 if(best && score>=28)return best.a;
 return "I’m running fully offline, so my knowledge is limited to built-in topics and simple calculations. Try a clearer question such as “solve 2x + 1 = 7”, “what is Newton’s second law?”, “percentage formula”, or “what is a derivative?”. This local engine is not a newly trained large language model.";
}
window.CalculusOfflineAI={answer,engineName:'calculus.AI Local Tutor v1',offline:true};
document.addEventListener('DOMContentLoaded',()=>{
 const candidates=[...document.querySelectorAll('textarea,input[type="text"],input:not([type])')];
 const sendButtons=[...document.querySelectorAll('button')].filter(b=>/send|ask|submit/i.test((b.innerText||'')+' '+(b.getAttribute('aria-label')||'')));
 // Bind the existing AI chat composer where recognizable.
 let input=candidates.find(el=>/ask|message|question|anything/i.test((el.placeholder||''))) || candidates.find(el=>el.offsetParent!==null && el.type!=='password');
 let output=document.querySelector('[data-ai-output],.messages,.chat-messages,.message-list');
 if(!output){
   output=document.createElement('section'); output.id='offline-ai-panel';
   output.style.cssText='margin:14px auto;padding:14px;max-width:980px;border:1px solid #28343D;border-radius:16px;background:#10161D;color:#F5F8FA';
   output.innerHTML='<div style="font-weight:700;margin-bottom:8px">⚡ Local Offline Tutor <small style="color:#55D6A5">● no API connected</small></div><div id="offline-ai-log" aria-live="polite" style="white-space:pre-wrap;font-size:14px;line-height:1.55">Built-in maths and physics answers + simple arithmetic. This is a compact offline engine, not an LLM.</div><form id="offline-ai-form" style="display:flex;gap:8px;margin-top:12px"><input id="offline-ai-input" placeholder="Ask maths or physics…" style="flex:1;min-width:0;padding:12px;border-radius:10px;border:1px solid #28343D;background:#080B0F;color:#fff"><button style="padding:12px 16px;border:0;border-radius:10px;background:#27C7D4;color:#071116;font-weight:700">Ask</button></form>';
   document.body.appendChild(output);
 }
 const form=$('offline-ai-form'), localInput=$('offline-ai-input'), log=$('offline-ai-log');
 if(form)form.addEventListener('submit',async e=>{e.preventDefault();const q=localInput.value.trim();if(!q)return;log.textContent='You: '+q+'\\n\\ncalculus.AI: Thinking locally…';localInput.value='';log.textContent='You: '+q+'\\n\\ncalculus.AI: '+await answer(q);});
});
})();