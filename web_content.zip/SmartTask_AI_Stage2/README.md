# SmartTask AI Stage 2 — multi-user backend and connected portal

This stage adds a central API, PostgreSQL persistence, user accounts, role checks, manager approval, employee task visibility, and audit history.

## Included
- `portal.html`: browser portal for first-admin setup, sign-in, task creation, AI recommendation, manager approve/reject, employee directory and reports.
- `backend/app.py`: FastAPI REST API with JWT sessions, password hashing, role-based access, task and employee endpoints, AI-style recommendation endpoint and audit log.
- `docker-compose.yml`: PostgreSQL + API + portal services.
- `.env.example`: environment variable template.

## Run locally with Docker
1. Install Docker Desktop or Docker Engine with Compose.
2. Copy `.env.example` to `.env`.
3. Replace `POSTGRES_PASSWORD` and `SECRET_KEY` with strong random values. Do not commit `.env`.
4. Run `docker compose up --build`.
5. Open `http://localhost:8080`.
6. On first launch, select **Create the first administrator**. This bootstrap endpoint closes automatically after the first account exists.
7. Sign in as the administrator. Use the API endpoint `/docs` at `http://localhost:8000/docs` for interactive API documentation.

## Create employee accounts
After signing in, use the API `POST /auth/register` as an authenticated manager/admin. The payload includes name, email, password, role (`employee`, `supervisor`, or `manager`), department, skills array and daily capacity. The connected portal lists employee accounts.

## Workflow
1. Manager creates a task in the portal.
2. The portal requests an AI-style recommendation from `/tasks/{id}/recommend`.
3. The engine checks active employee, availability, required skill, department and remaining capacity.
4. The proposal enters `Pending approval`.
5. A manager/supervisor approves or rejects it.
6. Approved task appears for the assigned employee at their next refresh; employee can update status.
7. Manager reviews summary and audit events.

## Production deployment checklist — required before real employee data
- Deploy behind HTTPS on a managed host; use a real domain and configure `CORS_ORIGINS` to the exact portal origin.
- Use a managed PostgreSQL database with encrypted storage, automated backups and restore tests.
- Store secrets in the hosting provider's secret manager; rotate keys and database credentials.
- Add rate limiting, login lockout/MFA, password reset, email verification and session revocation.
- Add tenant/organisation isolation before hosting more than one organisation in the same service. This starter is intended for one organisation deployment.
- Add database migrations (Alembic), monitoring, error reporting, audit retention and data export/deletion policies.
- Restrict bootstrap after first use at infrastructure level too; the API already refuses bootstrap when any user exists.
- Review labour laws, staff privacy, retention and allocation fairness. Keep manager approval mandatory.
- Configure employee onboarding and account invitations; do not distribute shared passwords.

## Important limitations
- This is a runnable development-stage implementation, not a live hosted production service. No hosting account, domain, email/SMS provider or credentials were supplied, so it has not been deployed publicly.
- Recommendation logic is transparent deterministic scoring, not a trained generative AI model. It currently requires an exact skill match and department match (or Operations/Management generalist).
- The portal is a simple functional admin/employee web client. It is responsive, but push notifications, real-time WebSockets and native mobile packaging are not included in this stage.
- For a production-grade mobile experience, reuse the API with the PWA or build a native app; all users share data through the central API.
