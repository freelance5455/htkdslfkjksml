import os, enum, uuid
from datetime import datetime, timedelta, date
from typing import Optional, List
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import jwt, JWTError
from passlib.context import CryptContext
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import create_engine, String, Integer, Boolean, DateTime, Date, ForeignKey, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker, Session

DATABASE_URL=os.getenv("DATABASE_URL","sqlite:///./smarttask.db")
SECRET_KEY=os.getenv("SECRET_KEY")
if not SECRET_KEY:
    raise RuntimeError("Set a strong SECRET_KEY environment variable before starting the API.")
ALGORITHM="HS256"
ACCESS_TOKEN_MINUTES=int(os.getenv("ACCESS_TOKEN_MINUTES","480"))
engine=create_engine(DATABASE_URL,connect_args={"check_same_thread":False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal=sessionmaker(bind=engine,autoflush=False,autocommit=False)
pwd=CryptContext(schemes=["bcrypt"],deprecated="auto")
oauth2=OAuth2PasswordBearer(tokenUrl="/auth/token")

class Base(DeclarativeBase): pass
class User(Base):
    __tablename__="users"
    id:Mapped[str]=mapped_column(String,primary_key=True,default=lambda:str(uuid.uuid4()))
    name:Mapped[str]=mapped_column(String(120))
    email:Mapped[str]=mapped_column(String(255),unique=True,index=True)
    password_hash:Mapped[str]=mapped_column(String(255))
    role:Mapped[str]=mapped_column(String(30),default="employee")
    active:Mapped[bool]=mapped_column(Boolean,default=True)
    department:Mapped[str]=mapped_column(String(100),default="Operations")
    skills:Mapped[str]=mapped_column(Text,default="")
    daily_capacity:Mapped[int]=mapped_column(Integer,default=8)
    availability:Mapped[str]=mapped_column(String(30),default="Available")
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
class Task(Base):
    __tablename__="tasks"
    id:Mapped[str]=mapped_column(String,primary_key=True,default=lambda:str(uuid.uuid4()))
    title:Mapped[str]=mapped_column(String(240))
    description:Mapped[str]=mapped_column(Text,default="")
    department:Mapped[str]=mapped_column(String(100))
    required_skill:Mapped[str]=mapped_column(String(100))
    priority:Mapped[str]=mapped_column(String(20),default="Medium")
    estimated_hours:Mapped[int]=mapped_column(Integer,default=1)
    due_date:Mapped[date]=mapped_column(Date)
    status:Mapped[str]=mapped_column(String(30),default="Unassigned")
    assigned_to:Mapped[Optional[str]]=mapped_column(ForeignKey("users.id"),nullable=True)
    proposed_to:Mapped[Optional[str]]=mapped_column(ForeignKey("users.id"),nullable=True)
    created_by:Mapped[str]=mapped_column(ForeignKey("users.id"))
    approved_by:Mapped[Optional[str]]=mapped_column(ForeignKey("users.id"),nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)
    updated_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)
class Audit(Base):
    __tablename__="audit_log"
    id:Mapped[int]=mapped_column(Integer,primary_key=True,autoincrement=True)
    actor_id:Mapped[str]=mapped_column(String, index=True)
    action:Mapped[str]=mapped_column(String(80))
    entity_id:Mapped[str]=mapped_column(String(80))
    detail:Mapped[str]=mapped_column(Text,default="")
    created_at:Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

Base.metadata.create_all(engine)
app=FastAPI(title="SmartTask AI API",version="2.0.0",description="Multi-user workforce operations API")
origins=os.getenv("CORS_ORIGINS","http://localhost:8000,http://127.0.0.1:8000").split(",")
app.add_middleware(CORSMiddleware,allow_origins=origins,allow_credentials=True,allow_methods=["*"],allow_headers=["*"])

def db():
    s=SessionLocal()
    try: yield s
    finally: s.close()
def audit(s,actor,action,entity,detail=""):
    s.add(Audit(actor_id=actor.id,action=action,entity_id=entity,detail=detail));s.commit()
def token_for(u):
    exp=datetime.utcnow()+timedelta(minutes=ACCESS_TOKEN_MINUTES)
    return jwt.encode({"sub":u.id,"role":u.role,"exp":exp},SECRET_KEY,algorithm=ALGORITHM)
def current_user(token:str=Depends(oauth2),s:Session=Depends(db)):
    try: payload=jwt.decode(token,SECRET_KEY,algorithms=[ALGORITHM]); uid=payload.get("sub")
    except JWTError: raise HTTPException(401,"Invalid or expired session")
    u=s.get(User,uid)
    if not u or not u.active: raise HTTPException(401,"Account unavailable")
    return u
def roles(*allowed):
    def check(u:User=Depends(current_user)):
        if u.role not in allowed: raise HTTPException(403,"Insufficient permissions")
        return u
    return check

class Register(BaseModel):
    name:str=Field(min_length=2,max_length=120)
    email:EmailStr
    password:str=Field(min_length=10,max_length=128)
    role:str="employee"
    department:str="Operations"
    skills:List[str]=[]
    daily_capacity:int=Field(default=8,ge=1,le=16)
class TaskIn(BaseModel):
    title:str=Field(min_length=2,max_length=240)
    description:str=""
    department:str
    required_skill:str
    priority:str="Medium"
    estimated_hours:int=Field(ge=1,le=16)
    due_date:date
class TaskStatus(BaseModel):
    status:str
class Approval(BaseModel):
    decision:str
class Availability(BaseModel):
    availability:str
    daily_capacity:int=Field(ge=1,le=16)

@app.get("/health")
def health(): return {"status":"ok","service":"SmartTask AI API","version":"2.0.0"}
@app.post("/auth/register")
def register(data:Register,s:Session=Depends(db),admin:User=Depends(roles("admin","manager"))):
    if data.role not in ("employee","supervisor","manager"): raise HTTPException(400,"Invalid role")
    if s.query(User).filter_by(email=data.email.lower()).first(): raise HTTPException(409,"Email already registered")
    u=User(name=data.name,email=data.email.lower(),password_hash=pwd.hash(data.password),role=data.role,department=data.department,skills=",".join(data.skills),daily_capacity=data.daily_capacity)
    s.add(u);s.commit();s.refresh(u);audit(s,admin,"user.created",u.id,u.email)
    return user_view(u)
@app.post("/auth/bootstrap")
def bootstrap(data:Register,s:Session=Depends(db)):
    # First administrator only; disable/remove this endpoint after initial setup in a controlled production deployment.
    if s.query(User).count(): raise HTTPException(403,"Bootstrap is already closed")
    u=User(name=data.name,email=data.email.lower(),password_hash=pwd.hash(data.password),role="admin",department=data.department,skills=",".join(data.skills),daily_capacity=data.daily_capacity)
    s.add(u);s.commit();s.refresh(u)
    return {"user":user_view(u),"access_token":token_for(u),"token_type":"bearer"}
@app.post("/auth/token")
def login(form:OAuth2PasswordRequestForm=Depends(),s:Session=Depends(db)):
    u=s.query(User).filter_by(email=form.username.lower()).first()
    if not u or not pwd.verify(form.password,u.password_hash) or not u.active: raise HTTPException(401,"Incorrect email or password",headers={"WWW-Authenticate":"Bearer"})
    return {"access_token":token_for(u),"token_type":"bearer","user":user_view(u)}
def user_view(u):
    return {"id":u.id,"name":u.name,"email":u.email,"role":u.role,"department":u.department,"skills":[x for x in u.skills.split(",") if x],"daily_capacity":u.daily_capacity,"availability":u.availability}
@app.get("/auth/me")
def me(u:User=Depends(current_user)): return user_view(u)
@app.get("/employees")
def employees(s:Session=Depends(db),u:User=Depends(current_user)):
    q=s.query(User)
    if u.role=="employee": q=q.filter(User.id==u.id)
    return [user_view(x) for x in q.order_by(User.name).all()]
@app.patch("/employees/{uid}/availability")
def set_availability(uid:str,data:Availability,s:Session=Depends(db),u:User=Depends(current_user)):
    if u.role not in ("admin","manager","supervisor") and uid!=u.id: raise HTTPException(403,"Not permitted")
    target=s.get(User,uid)
    if not target: raise HTTPException(404,"Employee not found")
    target.availability=data.availability;target.daily_capacity=data.daily_capacity;s.commit();audit(s,u,"employee.availability.updated",uid,data.availability)
    return user_view(target)
@app.post("/tasks")
def create_task(data:TaskIn,s:Session=Depends(db),u:User=Depends(roles("admin","manager","supervisor"))):
    t=Task(**data.model_dump(),created_by=u.id)
    s.add(t);s.commit();s.refresh(t);audit(s,u,"task.created",t.id,t.title)
    return task_view(t,s)
def task_view(t,s):
    return {"id":t.id,"title":t.title,"description":t.description,"department":t.department,"required_skill":t.required_skill,"priority":t.priority,"estimated_hours":t.estimated_hours,"due_date":t.due_date.isoformat(),"status":t.status,"assigned_to":t.assigned_to,"proposed_to":t.proposed_to,"employee":user_view(s.get(User,t.assigned_to)) if t.assigned_to else None,"proposed_employee":user_view(s.get(User,t.proposed_to)) if t.proposed_to else None}
@app.get("/tasks")
def tasks(s:Session=Depends(db),u:User=Depends(current_user)):
    q=s.query(Task)
    if u.role=="employee": q=q.filter((Task.assigned_to==u.id)|(Task.proposed_to==u.id))
    return [task_view(t,s) for t in q.order_by(Task.due_date,Task.priority).all()]
def workload(s,uid):
    rows=s.query(Task).filter(Task.assigned_to==uid,Task.status.in_(["Assigned","In progress"])).all()
    return sum(x.estimated_hours for x in rows)
def recommend(s,t):
    people=s.query(User).filter(User.active==True,User.availability=="Available").all()
    ranked=[]
    for p in people:
        if t.department and p.department not in (t.department,"Operations","Management"): continue
        skills=[x.strip().lower() for x in p.skills.split(",") if x.strip()]
        match=t.required_skill.lower() in skills
        load=workload(s,p.id)
        if not match or load+t.estimated_hours>p.daily_capacity: continue
        score=40+25+max(0,20-(load*3))+({"High":15,"Medium":10,"Low":5}.get(t.priority,5))
        ranked.append((score,load,p))
    ranked.sort(key=lambda x:(-x[0],x[1],x[2].name))
    return ranked
@app.post("/tasks/{tid}/recommend")
def recommend_task(tid:str,s:Session=Depends(db),u:User=Depends(roles("admin","manager","supervisor"))):
    t=s.get(Task,tid)
    if not t: raise HTTPException(404,"Task not found")
    if t.status=="Completed": raise HTTPException(409,"Completed task cannot be allocated")
    ranked=recommend(s,t)
    if not ranked: raise HTTPException(409,"No eligible employee matches the required skill, department and capacity")
    t.proposed_to=ranked[0][2].id;t.status="Pending approval";s.commit();audit(s,u,"task.recommendation.generated",tid,f"proposed={t.proposed_to};score={ranked[0][0]}")
    return {"task":task_view(t,s),"recommendations":[{"employee":user_view(p),"score":score,"current_workload_hours":load,"reason":"Required skill match; employee available; capacity and task priority considered."} for score,load,p in ranked[:5]]}
@app.post("/tasks/{tid}/decision")
def decide(tid:str,data:Approval,s:Session=Depends(db),u:User=Depends(roles("admin","manager","supervisor"))):
    t=s.get(Task,tid)
    if not t: raise HTTPException(404,"Task not found")
    if data.decision=="approve":
        if not t.proposed_to: raise HTTPException(409,"No AI proposal is awaiting approval")
        p=s.get(User,t.proposed_to)
        if not p or p.availability!="Available" or workload(s,p.id)+t.estimated_hours>p.daily_capacity: raise HTTPException(409,"Proposed employee is no longer eligible")
        t.assigned_to=t.proposed_to;t.proposed_to=None;t.status="Assigned";t.approved_by=u.id
        action="task.assignment.approved"
    elif data.decision=="reject":
        t.proposed_to=None;t.assigned_to=None;t.status="Unassigned";action="task.assignment.rejected"
    else: raise HTTPException(400,"Decision must be approve or reject")
    s.commit();audit(s,u,action,tid,data.decision);return task_view(t,s)
@app.patch("/tasks/{tid}/status")
def update_status(tid:str,data:TaskStatus,s:Session=Depends(db),u:User=Depends(current_user)):
    allowed=["Assigned","In progress","Completed","Blocked"]
    if data.status not in allowed: raise HTTPException(400,"Invalid task status")
    t=s.get(Task,tid)
    if not t: raise HTTPException(404,"Task not found")
    if u.role=="employee" and t.assigned_to!=u.id: raise HTTPException(403,"This task is not assigned to you")
    if u.role not in ("admin","manager","supervisor","employee"): raise HTTPException(403,"Not permitted")
    t.status=data.status;s.commit();audit(s,u,"task.status.updated",tid,data.status);return task_view(t,s)
@app.get("/reports/summary")
def summary(s:Session=Depends(db),u:User=Depends(roles("admin","manager","supervisor"))):
    all_tasks=s.query(Task).all()
    return {"total":len(all_tasks),"completed":sum(t.status=="Completed" for t in all_tasks),"pending_approval":sum(t.status=="Pending approval" for t in all_tasks),"unassigned":sum(t.status=="Unassigned" for t in all_tasks),"blocked":sum(t.status=="Blocked" for t in all_tasks),"open_hours":sum(t.estimated_hours for t in all_tasks if t.status!="Completed")}
@app.get("/audit")
def audit_log(s:Session=Depends(db),u:User=Depends(roles("admin","manager"))):
    return [{"actor_id":a.actor_id,"action":a.action,"entity_id":a.entity_id,"detail":a.detail,"created_at":a.created_at.isoformat()} for a in s.query(Audit).order_by(Audit.created_at.desc()).limit(200).all()]
