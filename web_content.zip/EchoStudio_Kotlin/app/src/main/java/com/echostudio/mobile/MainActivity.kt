package com.echostudio.mobile

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.media.*
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max
import kotlin.math.min

/** Native Kotlin starter implementation. DSP is intentionally simple and must be device-tested. */
class MainActivity : Activity() {
    private val bg = 0xFF07111F.toInt(); private val panel = 0xFF11243A.toInt(); private val cyan = 0xFF43E6FF.toInt(); private val pale = 0xFFEEF7FF.toInt()
    private lateinit var root: LinearLayout; private lateinit var body: LinearLayout; private var status: TextView? = null
    @Volatile private var recording = false
    private var audioThread: Thread? = null; private var input: AudioRecord? = null; private var output: AudioTrack? = null
    private var wav: RandomAccessFile? = null; private var wavFile: File? = null; private var rate = 44100; private var buf = 8192
    @Volatile private var echo = .25f; @Volatile private var delay = .30f; @Volatile private var reverb = .20f; @Volatile private var bass = .50f; @Volatile private var treble = .50f
    private var delayLine = FloatArray(rate); private var delayPos = 0; private var reverbState = 0f; private var bassPrev = 0f; private var treblePrev = 0f
    private val micReq = 71; private val videoReq = 72

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); home() }
    private fun label(s: String, size: Float = 14f, bold: Boolean = false): TextView = TextView(this).apply { text=s; textSize=size; setTextColor(pale); if (bold) setTypeface(null, 1); setPadding(0, 7, 0, 7) }
    private fun page(title: String) {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,18,16,10); setBackgroundColor(bg) }; setContentView(root)
        root.addView(label("🎙  ECHO STUDIO MOBILE", 22f, true)); root.addView(label(title, 14f).apply { setTextColor(cyan) })
        val sc = ScrollView(this); body = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,12,0,12) }; sc.addView(body); root.addView(sc, LinearLayout.LayoutParams(-1,0,1f))
        val nav = LinearLayout(this).apply { gravity=Gravity.CENTER; setPadding(0,4,0,0) }
        listOf("Home" to ::home, "Audio" to ::audioPage, "Video" to ::videoPage, "Files" to ::filesPage, "Settings" to ::settingsPage).forEach { (t, action) ->
            val b=Button(this).apply { text=t; textSize=9f; isAllCaps=false; setOnClickListener { action() } }; nav.addView(b, LinearLayout.LayoutParams(0,48,1f))
        }; root.addView(nav)
    }
    private fun card(title: String, desc: String) { val c=LinearLayout(this).apply { orientation=1; setPadding(14,10,14,10); setBackgroundColor(panel) }; c.addView(label(title,17f,true)); c.addView(label(desc,13f)); val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=10; body.addView(c,lp) }
    private fun button(text: String, action: () -> Unit) { body.addView(Button(this).apply { this.text=text; isAllCaps=false; setOnClickListener { action() } }, LinearLayout.LayoutParams(-1,-2)) }
    private fun home() { page("Your mobile recording studio"); card("आपका अपना मोबाइल स्टूडियो", "आवाज़ रिकॉर्ड करें, effects लगाएँ और वीडियो रिकॉर्ड करें।"); button("🎤 Audio Recording",::audioPage); button("🎚 Studio Effects",::effectsPage); button("🎬 Video Recording",::videoPage); button("📁 My Recordings",::filesPage); button("⚙ Settings",::settingsPage); card("Formats", "इस starter build में WAV audio रिकॉर्डिंग उपलब्ध कराने का कोड है। MP3 export अभी शामिल नहीं है।") }
    private fun audioPage() { page("Audio Recording"); status=label(if(recording) "● Recording and monitoring" else "Ready — headphones recommended",16f,true); body.addView(status); button(if(recording) "■ Stop and save WAV" else "● Start recording") { if(recording) stopAudio() else startAudio() }; button("Open effect controls",::effectsPage); card("Live monitoring", "हेडफोन लगाएँ। स्पीकर पर मॉनिटर करने से feedback हो सकता है। Effects recording और monitor दोनों पर लागू किए जाते हैं।") }
    private fun startAudio() {
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),micReq); return }
        try {
            val minBuf=AudioRecord.getMinBufferSize(rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT); if(minBuf<=0) throw IllegalStateException("Audio input not supported")
            buf=max(minBuf,8192)
            input=AudioRecord(MediaRecorder.AudioSource.MIC,rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,buf*2)
            output=AudioTrack(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build(),AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),buf*2,AudioTrack.MODE_STREAM,AudioManager.AUDIO_SESSION_ID_GENERATE)
            val dir=getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: filesDir; dir.mkdirs(); val stamp=SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(Date()); wavFile=File(dir,"EchoStudio_$stamp.wav"); wav=RandomAccessFile(wavFile,"rw"); writeHeader(wav!!,0)
            delayLine=FloatArray(rate); delayPos=0; reverbState=0f; bassPrev=0f; treblePrev=0f
            input!!.startRecording(); output!!.play(); recording=true; audioThread=Thread { processAudio() }.also { it.start() }; audioPage()
        } catch(e: Exception) { recording=false; cleanup(); message("Could not start recording: ${e.message}") }
    }
    private fun processAudio() {
        val ins=ShortArray(buf/2); val outs=ShortArray(buf/2)
        try { while(recording) { val n=input?.read(ins,0,ins.size) ?: -1; if(n<=0) continue; val bytes=ByteArray(n*2)
            for(i in 0 until n) { val x=ins[i]/32768f; val low=.965f*bassPrev+.035f*x; bassPrev=low; var y=x+(bass-.5f)*2f*(x-low); val high=x-treblePrev; treblePrev=x; y+=(treble-.5f)*1.5f*high
                val d=(rate*(.08f+delay*.42f)).toInt().coerceIn(1,delayLine.size-1); val read=(delayPos-delayLine.size+d+delayLine.size)%delayLine.size; val delayed=delayLine[read]; var wet=y+delayed*echo*.85f; reverbState=.72f*reverbState+.28f*delayed; wet+=reverbState*reverb*.55f; delayLine[delayPos]=y+delayed*(.15f+echo*.55f); delayPos=(delayPos+1)%delayLine.size; val s=(wet.coerceIn(-.98f,.98f)*32767).toInt().toShort(); outs[i]=s; bytes[i*2]=(s.toInt() and 255).toByte(); bytes[i*2+1]=((s.toInt() shr 8) and 255).toByte() }
            output?.write(outs,0,n); synchronized(this) { wav?.write(bytes) }
        } } catch(e: Exception) { runOnUiThread { message("Audio stopped: ${e.message}") } }
    }
    private fun stopAudio() { recording=false; try { audioThread?.join(800) } catch(_:Exception){}; cleanup(); message("WAV saved: ${wavFile?.name ?: "recording"}"); audioPage() }
    private fun cleanup() { try { input?.stop() } catch(_:Exception){}; try { input?.release() } catch(_:Exception){}; input=null; try { output?.stop() } catch(_:Exception){}; try { output?.release() } catch(_:Exception){}; output=null; try { wav?.let { val size=(it.length()-44).coerceAtLeast(0).coerceAtMost(Int.MAX_VALUE.toLong()).toInt(); it.seek(0); writeHeader(it,size); it.close() } } catch(_:Exception){}; wav=null }
    private fun writeHeader(f: RandomAccessFile, n: Int) { f.writeBytes("RIFF"); le32(f,36+n); f.writeBytes("WAVEfmt "); le32(f,16); le16(f,1); le16(f,1); le32(f,rate); le32(f,rate*2); le16(f,2); le16(f,16); f.writeBytes("data"); le32(f,n) }
    private fun le32(f:RandomAccessFile,v:Int) { f.write(v and 255); f.write(v ushr 8 and 255); f.write(v ushr 16 and 255); f.write(v ushr 24 and 255) }; private fun le16(f:RandomAccessFile,v:Int) { f.write(v and 255); f.write(v ushr 8 and 255) }
    private fun effectsPage() { page("Studio Effects"); slider("Echo",echo) { echo=it }; slider("Delay",delay) { delay=it }; slider("Reverb",reverb) { reverb=it }; slider("Bass",bass) { bass=it }; slider("Treble",treble) { treble=it }; card("Processing", "ये controls DSP signal को बदलते हैं। Algorithm basic है; professional mastering नहीं। Device latency/quality को real hardware पर जाँचना बाकी है।"); button(if(recording) "Return to recording" else "Start recording with effects") { if(recording) audioPage() else startAudio() } }
    private fun slider(name:String, initial:Float, changed:(Float)->Unit) { val c=LinearLayout(this).apply { orientation=1; setPadding(12,8,12,8); setBackgroundColor(panel) }; c.addView(label("$name: ${(initial*100).toInt()}%",15f,true)); val sb=SeekBar(this).apply { max=100; progress=(initial*100).toInt() }; sb.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean) { changed(p/100f); (c.getChildAt(0) as TextView).text="$name: $p%" }; override fun onStartTrackingTouch(s:SeekBar?){}; override fun onStopTrackingTouch(s:SeekBar?){} }); c.addView(sb); body.addView(c,LinearLayout.LayoutParams(-1,-2)) }
    private fun videoPage() { page("Video Recording"); card("Camera", "System camera से video record करें; camera app खुद MP4/अन्य format चुन सकती है। वापस आने पर video library scan में दिख सकता है अगर app के private folder में न हो तो नहीं।"); button("🎬 Open phone camera to record video") { val i=Intent(MediaStore.ACTION_VIDEO_CAPTURE); if(i.resolveActivity(packageManager)!=null) startActivityForResult(i,videoReq) else message("No camera app available") }; button("Refresh recordings",::filesPage) }
    private fun recordings(): List<File> { val dirs=listOf(getExternalFilesDir(Environment.DIRECTORY_MUSIC),getExternalFilesDir(Environment.DIRECTORY_MOVIES)); return dirs.filterNotNull().flatMap { it.listFiles()?.filter { f -> f.isFile && (f.extension.lowercase() in listOf("wav","mp4","3gp","m4v","mp3")) } ?: emptyList() }.sortedByDescending { it.lastModified() } }
    private fun filesPage() { page("My Recordings"); val fs=recordings(); if(fs.isEmpty()) card("No recordings yet", "पहले audio record करें या camera से video बनाएँ।"); fs.forEach { f -> val c=LinearLayout(this).apply { orientation=1; setPadding(12,8,12,8); setBackgroundColor(panel) }; c.addView(label(f.name,14f,true)); c.addView(label("${f.extension.uppercase()} • ${f.length()/1024} KB",12f)); if(f.extension.lowercase()=="wav" || f.extension.lowercase()=="mp3") c.addView(Button(this).apply { text="Play"; setOnClickListener { try { val mp=MediaPlayer(); mp.setDataSource(f.absolutePath); mp.setOnCompletionListener { it.release() }; mp.prepare(); mp.start() } catch(e:Exception){message("Playback error: ${e.message}")} } }); c.addView(Button(this).apply { text="Rename"; setOnClickListener { val edit=EditText(this@MainActivity).apply { setText(f.nameWithoutExtension) }; AlertDialog.Builder(this@MainActivity).setTitle("Rename recording").setView(edit).setNegativeButton("Cancel",null).setPositiveButton("Save") { _,_ -> val newName=edit.text.toString().trim().replace(Regex("[^A-Za-z0-9 _.-]"),""); if(newName.isNotBlank()) { val dest=File(f.parentFile,"$newName.${f.extension}"); if(!dest.exists() && f.renameTo(dest)) filesPage() else message("Rename failed or name already exists") } }.show() } }); c.addView(Button(this).apply { text="Delete"; setOnClickListener { AlertDialog.Builder(this@MainActivity).setMessage("Delete ${f.name}?").setNegativeButton("Cancel",null).setPositiveButton("Delete") { _,_ -> if(f.delete()) filesPage() else message("Delete failed") }.show() } }); body.addView(c,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=8 }) }; card("MP3 export", "MP3 encoding/export is not implemented in this source version. WAV recordings are saved in the app's Music folder.") }
    private fun settingsPage() { page("Settings"); card("Echo Studio Mobile", "Native Android Kotlin app starter. Minimum Android 8.0 (API 26). Microphone permission is requested when recording starts; video uses the installed camera app."); card("Audio", "Mono PCM, 44.1 kHz. Headphones recommended. Echo, delay, reverb and simple bass/treble filters are implemented in the live processing loop, but require device testing."); card("Privacy", "Audio WAV files are stored in app-specific external Music storage. Uninstalling the app may remove these files.") }
    private fun message(s:String) = Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray) { super.onRequestPermissionsResult(r,p,g); if(r==micReq && g.isNotEmpty() && g[0]==PackageManager.PERMISSION_GRANTED) startAudio() else if(r==micReq) message("Microphone permission is required") }
    override fun onActivityResult(r:Int,result:Int,data:Intent?) { super.onActivityResult(r,result,data); if(r==videoReq && result==Activity.RESULT_OK) { message("Camera returned a video. Camera save location depends on your device."); filesPage() } }
    override fun onDestroy() { recording=false; cleanup(); super.onDestroy() }
}
