Echo Studio Mobile — Kotlin Android source project
==================================================

IMPORTANT: यह SOURCE PROJECT है, APK नहीं। इस environment में Android SDK/Gradle build उपलब्ध नहीं था, इसलिए APK compile या device testing का दावा नहीं किया जा रहा है।

Included:
- Native Android app written in Kotlin
- Dark navy/cyan visual styling inspired by the supplied HTML prototype
- HTML prototype preserved at app/src/main/assets/design_reference.html
- Runtime microphone permission request
- PCM WAV recording (44.1 kHz mono)
- Live audio output through Android AudioTrack
- Basic real-time echo, delay, reverb, bass and treble signal processing
- System camera launch for video recording; when the camera returns a content URI, the app copies the video into its app-specific Movies folder
- Library scan for WAV and video files that are in app-specific Music/Movies folders; play audio; rename/delete listed files
- Settings screen

Not yet implemented / limitations:
- MP3 encoding/export is NOT implemented.
- Video is recorded by the system camera app, not an in-app CameraX recorder. The app now attempts to copy the returned video URI into its app-specific Movies folder; if the camera app returns no URI, check the phone Gallery. This needs physical-device testing.
- HTML/CSS prototype is preserved as a design reference; the app currently uses native Kotlin UI, not the HTML rendered directly.
- DSP is a simple starter algorithm, not a studio-grade audio engine. Real devices, headphones, latency, lifecycle and error recovery require testing.
- No debug APK is included. This ZIP contains source code only and has not been compiled or device-tested in this environment.

Build a debug APK:
1. On a computer, install Android Studio and Android SDK Platform 35, plus JDK 17.
2. Extract this ZIP.
3. Open the extracted EchoStudio_Kotlin folder in Android Studio (Open project).
4. Allow Gradle sync to finish; if asked, install the Android Gradle Plugin / SDK components.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build succeeds, Android Studio shows a notification with “locate”. The APK should be at app/build/outputs/apk/debug/app-debug.apk.
7. Transfer that APK to the phone and install it. Android may ask to allow installation from that file manager/browser.

Command line alternative (from the project folder, with JDK 17 and Android SDK configured):
    gradle assembleDebug

The project does not include a Gradle wrapper, so use Android Studio's Gradle integration or install a compatible Gradle version. Build errors must be fixed before the APK can be considered ready. Test on a physical phone and grant microphone permission when prompted.
