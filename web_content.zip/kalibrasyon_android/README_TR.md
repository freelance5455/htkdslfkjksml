# Kalibrasyon Envanteri - Android APK Projesi

Bu proje mevcut `kalibrasyon_envanter_FRM17684_QR.html` dosyasını Android WebView içinde çalıştırır ve QR okuma işlemini Android'in native kamerası + ZXing ile yapar.

## Android Studio ile APK oluşturma

1. Android Studio'yu kurun.
2. `KalibrasyonEnvanteri` klasörünü **Open** ile açın.
3. Gradle senkronizasyonunun tamamlanmasını bekleyin. İlk açılışta internet bağlantısı gerekir; Android Gradle Plugin ve ZXing bağımlılıkları indirilebilir.
4. Telefonu USB ile bağlayın veya Android Emulator kullanın.
5. `Run` ile uygulamayı çalıştırın.
6. APK için: **Build > Build APK(s)**.

APK genellikle `app/build/outputs/apk/debug/app-debug.apk` altında oluşur.

## QR davranışı

HTML içindeki her cihazın `id` değeri (D001, D002, ...) QR kimliğidir. Uygulamadaki **QR Kod Oku** düğmesi native tarayıcıyı açar. QR okutulduğunda sonuç HTML'deki cihaz eşleştirme fonksiyonuna gönderilir ve yalnızca ilgili cihazın FRM-17684 kaydı açılır.

## Not

Mevcut HTML'deki QR görselleri için QRServer adresi kullanılıyor. QR etiketlerini internet gerektirmeden üretmek isterseniz sonraki sürümde QR üretimini de APK içine alabiliriz.
