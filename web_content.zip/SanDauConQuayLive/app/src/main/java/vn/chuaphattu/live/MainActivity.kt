package vn.chuaphattu.live

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private val ui = Handler(Looper.getMainLooper())

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tts = TextToSpeech(this, this)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            Toast.makeText(this, "Máy không có bộ đọc giọng nói (TTS)", Toast.LENGTH_LONG).show()
            return
        }
        val r = t.setLanguage(Locale("vi", "VN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            Toast.makeText(this, "Hãy cài giọng tiếng Việt: Cài đặt → Chuyển văn bản thành giọng nói", Toast.LENGTH_LONG).show()
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { js("PhatTu.ttsDone()") }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { js("PhatTu.ttsDone()") }
        })
    }

    private fun js(code: String) { ui.post { web.evaluateJavascript(code, null) } }

    /** Cầu nối JS <-> Android. Module kết nối LIVE sau này chỉ cần gọi emit(json). */
    fun emit(json: String) = js("PhatTu.event(" + org.json.JSONObject.quote(json) + ")")

    inner class Bridge {
        @JavascriptInterface
        fun speak(text: String, volume: Float) {
            ui.post {
                val p = Bundle().apply {
                    putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.coerceIn(0f, 1f))
                }
                tts?.speak(text, TextToSpeech.QUEUE_ADD, p, "u" + System.nanoTime())
            }
        }

        @JavascriptInterface
        fun connect(user: String) {
            js("PhatTu.status('error:Bản 0.1 chưa có module kết nối LIVE thật. Hãy dùng DEMO.')")
        }

        @JavascriptInterface
        fun disconnect() {}
    }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown()
        web.destroy()
        super.onDestroy()
    }
}
