# Sàn Đấu Con Quay LIVE – Android

Game: app/src/main/assets/index.html (canvas 2D, MC giọng AI, kết nối LIVE qua Euler Stream).
Phần Android: WebView + Android TextToSpeech (MainActivity.kt).

## Cách 1 – Android Studio (máy tính)
1. Cài Android Studio mới nhất (có sẵn JDK 17).
2. File > Open > chọn thư mục này. Lần đầu cần mạng, chờ Gradle sync (vài phút).
   Nếu hỏi Gradle: chọn "Use Gradle from gradle-wrapper.properties" (Gradle 8.7).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk

## Cách 2 – GitHub Actions
Đẩy cả thư mục này (giữ nguyên .github) lên repo > tab Actions > Build APK > Run workflow > tải artifact.

## Cài đặt
Chép APK vào điện thoại, cho phép cài từ nguồn không rõ.
Giọng MC: Cài đặt > Chuyển văn bản thành giọng nói > Google > tải tiếng Việt.

## Kết nối LIVE
Nhập @username và API key Euler Stream (eulerstream.com > Dashboard > API Keys), bấm KẾT NỐI.
Dịch vụ bên thứ ba, không chính thức của TikTok. Có thể hỏng nếu TikTok thay đổi.
Mở ⚙ > "Nhật ký LIVE" để xem dữ liệu thô khi cần gỡ lỗi.
