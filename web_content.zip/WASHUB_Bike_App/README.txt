WASHUB BIKE CARE — STARTER PROJECT

This ZIP contains a responsive booking web app with:
- Basic Bike Wash ₹350
- Premium Bike Wash ₹480
- Bike Detailing ₹700
- Superbike Care ₹2,400
- Pickup & drop or self drop-off
- HSR Layout, BTM Layout, Haralur, Koramangala and other-area enquiry
- Address, preferred date/time, customer and bike details
- WhatsApp booking to +91 8431180345

IMPORTANT: This is a web app/PWA starter project, NOT a compiled Android APK or iOS IPA. It has not been published or store-tested. It does not include online payment, live tracking, a booking database, or admin dashboard.

To install as a home-screen app:
1. Upload index.html and manifest.json to an HTTPS hosting service.
2. Android: open the HTTPS site in Chrome > menu > Install app / Add to Home screen.
3. iPhone: open the HTTPS site in Safari > Share > Add to Home Screen.
Install options vary by browser/device.

A true APK needs an Android build process and testing. An iPhone app needs a separate iOS build and Apple signing/distribution.
