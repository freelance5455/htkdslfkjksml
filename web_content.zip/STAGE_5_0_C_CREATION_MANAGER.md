# CGD V117 — Socle 5.0-C : création du manager

## Objectif
Créer l'identité du manager avant le choix de la galaxie et du club. La carrière n'est pas encore lancée à cette étape.

## Livré
- Identité : prénom, nom, nationalité et profil.
- Six avatars prédéfinis sélectionnables.
- Cinq niveaux d'expérience.
- Quatre philosophies de management.
- Enregistrement local du brouillon dans `career.managerDraft`.
- La carrière reste non démarrée tant que l'univers et le club ne sont pas choisis à l'étape 5.0-D.
- L'interface du jeu est masquée tant qu'aucun manager n'a été confirmé.
- Les sauvegardes antérieures sans `managerDraft` sont migrées sans perte.

## Limites assumées
- L'import d'une photo personnelle n'est pas encore inclus ; les avatars sont des choix intégrés.
- La nationalité et le profil sont enregistrés ; leurs effets seront définis lors de l'intégration complète.
- Le choix de la galaxie, du club et la confirmation de carrière relèvent de l'étape 5.0-D.

## Vérification
Tests dédiés à la validation des champs, au catalogue d'avatars et à la sauvegarde du brouillon sans lancement prématuré de la carrière.
