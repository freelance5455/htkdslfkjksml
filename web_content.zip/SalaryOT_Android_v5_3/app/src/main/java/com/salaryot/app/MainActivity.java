package com.salaryot.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_STORAGE = 7001;
    private static final String DATA_FILE = "salary_ot_state_v5_3.json";
    private static final int A4_W = 595;
    private static final int A4_H = 842;
    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        webView.setBackgroundColor(Color.rgb(16, 11, 28));
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.loadUrl("file:///android_asset/salary_ot_calculator.html");
    }

    private void toast(String msg) {
        runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show());
    }

    private boolean ensureLegacyStoragePermission() {
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            toast("กรุณาอนุญาตการจัดเก็บไฟล์ แล้วกดส่งออกอีกครั้ง");
            return false;
        }
        return true;
    }

    private Uri beginDownloadFile(String name, String mime) throws Exception {
        if (!ensureLegacyStoragePermission()) return null;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, name);
            v.put(MediaStore.Downloads.MIME_TYPE, mime);
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Salary_OT");
            v.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new Exception("สร้างไฟล์ใน Downloads ไม่สำเร็จ");
            return uri;
        }
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Salary_OT");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("สร้างโฟลเดอร์ Downloads/Salary_OT ไม่สำเร็จ");
        return Uri.fromFile(new File(dir, name));
    }

    private void finishDownloadFile(Uri uri, String name, String mime) {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.IS_PENDING, 0);
            getContentResolver().update(uri, v, null, null);
        }
    }

    private void deleteDownloadFile(Uri uri) {
        if (uri != null) try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
    }

    private void exportPrepared(final boolean png) {
        runOnUiThread(() -> {
            String js = "prepareAndroidExport(); JSON.stringify({w:Math.max(document.documentElement.scrollWidth,document.body.scrollWidth),h:Math.max(document.documentElement.scrollHeight,document.body.scrollHeight)});";
            webView.evaluateJavascript(js, value -> webView.postDelayed(() -> {
                try {
                    String raw = value == null ? "{}" : value;
                    if (raw.startsWith("\"") && raw.endsWith("\"")) raw = raw.substring(1, raw.length() - 1).replace("\\\"", "\"");
                    JSONObject dims = new JSONObject(raw);
                    int w = Math.max(360, dims.optInt("w", webView.getWidth()));
                    int h = Math.max(400, dims.optInt("h", 800));
                    if (w > 1440) w = 1440;
                    webView.measure(android.view.View.MeasureSpec.makeMeasureSpec(w, android.view.View.MeasureSpec.EXACTLY), android.view.View.MeasureSpec.makeMeasureSpec(h, android.view.View.MeasureSpec.EXACTLY));
                    webView.layout(0, 0, w, h);
                    if (png) savePng("salary-" + System.currentTimeMillis() + ".png", w, h);
                    else savePdf("salary-" + System.currentTimeMillis() + ".pdf", w, h);
                } catch (Exception e) {
                    toast("ส่งออกไฟล์ไม่สำเร็จ: " + e.getMessage());
                } finally {
                    webView.evaluateJavascript("finishAndroidExport();true;", null);
                }
            }, 300));
        });
    }

    private void savePng(String name, int w, int h) throws Exception {
        Bitmap bmp = null;
        Uri uri = null;
        try {
            bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bmp);
            canvas.drawColor(Color.WHITE);
            webView.draw(canvas);
            uri = beginDownloadFile(name, "image/png");
            if (uri == null) return;
            try (OutputStream out = Build.VERSION.SDK_INT >= 29 ? getContentResolver().openOutputStream(uri) : new FileOutputStream(new File(uri.getPath()))) {
                if (out == null) throw new Exception("เปิดไฟล์ปลายทางไม่ได้");
                if (!bmp.compress(Bitmap.CompressFormat.PNG, 100, out)) throw new Exception("สร้าง PNG ไม่สำเร็จ");
            }
            finishDownloadFile(uri, name, "image/png");
            toast("บันทึก PNG แล้ว • Downloads/Salary_OT");
        } catch (Exception e) {
            deleteDownloadFile(uri);
            throw e;
        } finally {
            if (bmp != null) bmp.recycle();
        }
    }

    private void savePdf(String name, int sourceW, int sourceH) throws Exception {
        PdfDocument doc = new PdfDocument();
        Uri uri = null;
        try {
            float scale = A4_W / (float) sourceW;
            float pageSourceH = A4_H / scale;
            int pages = Math.max(1, (int) Math.ceil(sourceH / pageSourceH));
            for (int i = 0; i < pages; i++) {
                PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(A4_W, A4_H, i + 1).create();
                PdfDocument.Page page = doc.startPage(info);
                Canvas c = page.getCanvas();
                c.drawColor(Color.WHITE);
                c.save();
                c.scale(scale, scale);
                c.translate(0, -i * pageSourceH);
                webView.draw(c);
                c.restore();
                doc.finishPage(page);
            }
            uri = beginDownloadFile(name, "application/pdf");
            if (uri == null) return;
            try (OutputStream out = Build.VERSION.SDK_INT >= 29 ? getContentResolver().openOutputStream(uri) : new FileOutputStream(new File(uri.getPath()))) {
                if (out == null) throw new Exception("เปิดไฟล์ปลายทางไม่ได้");
                doc.writeTo(out);
            }
            finishDownloadFile(uri, name, "application/pdf");
            toast("บันทึก PDF A4 แล้ว • Downloads/Salary_OT");
        } catch (Exception e) {
            deleteDownloadFile(uri);
            throw e;
        } finally {
            doc.close();
        }
    }

    private void saveBytes(String name, String mime, byte[] data) throws Exception {
        Uri uri = null;
        try {
            uri = beginDownloadFile(name, mime);
            if (uri == null) return;
            try (OutputStream out = Build.VERSION.SDK_INT >= 29 ? getContentResolver().openOutputStream(uri) : new FileOutputStream(new File(uri.getPath()))) {
                if (out == null) throw new Exception("เปิดไฟล์ปลายทางไม่ได้");
                out.write(data);
            }
            finishDownloadFile(uri, name, mime);
            toast("บันทึก CSV แล้ว • Downloads/Salary_OT");
        } catch (Exception e) {
            deleteDownloadFile(uri);
            throw e;
        }
    }

    private File dataFile() { return new File(getFilesDir(), DATA_FILE); }

    private String readSavedData() {
        File f = dataFile();
        if (!f.exists()) return "";
        try (InputStream in = new FileInputStream(f)) {
            byte[] b = new byte[(int) f.length()];
            int n = in.read(b);
            return new String(b, 0, Math.max(0, n), StandardCharsets.UTF_8);
        } catch (Exception e) { return ""; }
    }

    private void writeSavedData(String json) throws Exception {
        File tmp = new File(getFilesDir(), DATA_FILE + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.flush();
            out.getFD().sync();
        }
        File target = dataFile();
        if (!tmp.renameTo(target)) {
            try (FileOutputStream out = new FileOutputStream(target)) {
                out.write(json.getBytes(StandardCharsets.UTF_8));
                out.flush(); out.getFD().sync();
            }
            tmp.delete();
        }
    }

    private class Bridge {
        @JavascriptInterface public String getSavedData() { return readSavedData(); }

        @JavascriptInterface public boolean saveData(String json) {
            try { writeSavedData(json); return true; }
            catch (Exception e) { return false; }
        }

        @JavascriptInterface public void exportPNG() { exportPrepared(true); }
        @JavascriptInterface public void exportPDF() { exportPrepared(false); }

        @JavascriptInterface public void saveTextFile(String name, String mime, String b64) {
            try {
                byte[] data = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
                saveBytes(name, mime, data);
            } catch (Exception e) { toast("บันทึก CSV ไม่สำเร็จ: " + e.getMessage()); }
        }

        @JavascriptInterface public void printReport() {
            runOnUiThread(() -> {
                webView.evaluateJavascript("prepareAndroidExport();true;", value -> webView.postDelayed(() -> {
                    try {
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        PrintAttributes attrs = new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
                        pm.print("Salary_OT_Report", webView.createPrintDocumentAdapter("Salary_OT_Report"), attrs);
                    } catch (Exception e) { toast("เปิดหน้าพิมพ์ไม่สำเร็จ: " + e.getMessage()); }
                    finally { webView.postDelayed(() -> webView.evaluateJavascript("finishAndroidExport();true;", null), 1200); }
                }, 300));
            });
        }
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("Android"); webView.destroy(); }
        super.onDestroy();
    }
}
