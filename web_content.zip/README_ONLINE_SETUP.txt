THE MANAGEMENT - MULTI-PHONE INTERNET MESSAGING

This version uses Firebase Firestore for real-time internet messaging.
To make it actually work between phones:
1. Create a Firebase project.
2. Enable Authentication > Anonymous.
3. Create Firestore Database.
4. Create a Web App and copy its config into index.html, replacing the PASTE_YOUR_... values.
5. Deploy the folder to an HTTPS host such as Firebase Hosting, Netlify or Vercel.
6. For production, replace anonymous auth with proper verified accounts and add Firestore security rules.

Once configured and hosted, members on different phones can send/receive GENERAL GROUP messages in real time over the internet.
Photos/videos, status synchronization, notifications and WebRTC calls require additional Firebase Storage/Cloud Functions/signaling configuration.
