THE MANAGEMENT — ONLINE REAL-TIME VERSION

This package adds:
- Real-time online messages using Firebase Firestore
- GENERAL GROUP message synchronization between different phones
- Message deletion
- Voice notes using microphone + Firebase Storage
- Existing call interface / PeerJS calling
- Visible + button for adding status

IMPORTANT:
The website is online-ready, but it cannot become a public website by itself. You must connect it to a Firebase project and deploy the files to a web host.

SETUP:
1. Open Firebase Console: https://console.firebase.google.com/
2. Create a project.
3. Add a Web App.
4. Enable Authentication > Anonymous.
5. Create Firestore Database.
6. Enable Storage.
7. Copy the Web App config into firebase-config.js.
8. Deploy the folder to a host such as Firebase Hosting, Netlify, Vercel, or another HTTPS host.

For Firestore, create a messages collection. The website writes:
  room, name, phone, text, type, audioUrl, at

For Storage, voice notes are stored under:
  voice-notes/<firebase-user-id>/<timestamp>.webm

SECURITY:
For a real production app, replace anonymous sign-in with verified phone authentication and add proper Firestore/Storage security rules. Do not put a Firebase service-account key in the website.
