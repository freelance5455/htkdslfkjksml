MIS TARJETAS Y MIS CREDITOS

Archivo principal: index.html
Incluye manifest.json y sw.js para facilitar su conversión a APK/PWA.

CAMBIO DE ESTA VERSION
- Cargos recurrentes con duración Ilimitada o Por meses.
- Duraciones: 1, 2, 3, 6, 12 y 24 meses.
- Fecha de inicio y fecha de término calculada automáticamente.
- Los cargos de duración fija se detienen automáticamente al terminar.
- Los cargos ilimitados continúan hasta que se cancelen.
- Se puede editar importe, fecha, tarjeta, duración y estado.
- Se conserva la información de cargos recurrentes anteriores; los cargos antiguos sin duración quedan como Ilimitados.

IMPORTANTE
Al convertir a APK, conserva los cuatro archivos en la misma carpeta/paquete y usa index.html como página inicial.
