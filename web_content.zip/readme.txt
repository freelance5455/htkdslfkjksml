Mis Tarjetas y Mis Créditos

Incluye detalle de pagos por fecha y por tarjeta o crédito. Mantiene corte, gastos posteriores al corte y cargos recurrentes con duración.

Archivos: index.html, manifest.json, sw.js, readme.txt
