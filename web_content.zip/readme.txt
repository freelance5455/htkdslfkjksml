Mis Tarjetas – versión 6

Incluye registro rápido de compras y pagos, selección de tarjeta o crédito, compras de contado o MSI, edición, respaldo/importación y resumen separado de deudas de tarjetas y créditos.

Para probar: abre index.html en Chrome. Conserva tu versión anterior hasta comprobar que todo funciona correctamente.
