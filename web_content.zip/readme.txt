VERSIÓN PUENTE - Mis Tarjetas

IMPORTANTE: no desinstales la APK anterior ni borres sus datos. Esta versión conserva la misma estructura de datos y añade un respaldo más robusto. Para recuperar los datos de la APK anterior, esta versión debe instalarse como actualización de la misma aplicación; una APK distinta no puede leer el almacenamiento privado de otra aplicación.

Si el teléfono permite compartir el archivo, guárdalo como mis_tarjetas_respaldo.json.
