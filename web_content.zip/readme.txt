JOGO DAS 140 CASAS — VERSÃO ANDROID TV

Configuração:
- Interface 16:9, referência 1920x1080.
- Layout responsivo para 720p/1080p/4K.
- Margem de segurança nas bordas.
- Sem scroll durante o jogo.
- 140 casas.
- 2 jogadores.
- 2 dados simultâneos.
- Chegada exata à casa 140; se passar, recua o excesso.
- 60 casas coloridas (10 de cada cor) para as cartas físicas.
- 10 bombas até à casa 135.
- 6 escadas.
- Avançar/recuar manualmente pelo número indicado.
- Botão Passar vez.
- Funciona offline.

TESTE:
1. Extraia o ZIP.
2. Abra index.html num navegador Android.
3. Para Android TV, a página foi desenhada para ocupar o ecrã inteiro em 16:9.

NOTA:
Este ZIP é a versão web/offline do jogo. Para criar um APK instalável, é necessário empacotar estes ficheiros num projeto Android/WebView ou num conversor HTML->APK.
