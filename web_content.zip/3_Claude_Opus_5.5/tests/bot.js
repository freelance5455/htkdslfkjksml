/* ==========================================================================
   tests/bot.js — автотесты через window.game (не подключается к игре).
   Использование в консоли браузера на открытой игре:
     var s = document.createElement('script'); s.src = 'tests/bot.js'; document.body.appendChild(s);
     // затем: TEST.all()  → сводка результатов в консоли
   ========================================================================== */
'use strict';
var TEST = (function () {
  var V = TH.Input.virtual;
  function clear() { for (var k in V) V[k] = false; }
  function start() { clear(); if (game.state !== 'play') { TH.Input.tap('start'); game.step(); game.step(); } game.checkpoint = null; game.lives = 3; game.startAct(); game.cardT = 170; }

  /** Простой бот: держит «вправо», прыгает у препятствий и перед пропастями */
  function run(maxFrames, opt) {
    opt = opt || {};
    var T = game.terrain, stuck = 0, jh = 0, lastX = game.player.x, deaths = [], log = [];
    var wallX = -1, wallTries = 0, back = 0;
    for (var i = 0; i < maxFrames; i++) {
      var p = game.player;
      if (opt.invuln) p.invuln = Math.max(p.invuln, 5);
      clear();
      if (back > 0) { back--; V.left = true; } else V.right = true;
      if (jh > 0) { jh--; V.jump = true; }
      if (p.ground && jh === 0 && back === 0) {
        if (Math.abs(p.x - lastX) < 0.3) stuck++; else stuck = 0;
        var ahead = T.sensor(p.x + 40 + Math.max(0, p.gsp) * 6, p.y, 0, p.layer, true, 80);
        if (stuck > 12) {
          // Повторно упёрлись в то же место — отходим назад (к пружине) и пробуем снова
          if (Math.abs(p.x - wallX) < 24) wallTries++; else { wallX = p.x; wallTries = 0; }
          if (wallTries >= 2) { back = 45 + (wallTries % 3) * 20; stuck = 0; }
          else { jh = 22; stuck = 0; }
        } else if (ahead === null && p.mode === 0) { jh = 22; stuck = 0; }
      }
      lastX = p.x;
      game.step();
      if (game.dying) {
        deaths.push([Math.round(p.x), Math.round(p.y)]);
        for (var k = 0; k < 300 && game.state === 'play' && game.dying; k++) game.step();
        if (game.state !== 'play') break;
      }
      if (i % 600 === 0) log.push([i, Math.round(p.x), Math.round(p.y)]);
      if (opt.untilX && p.x > opt.untilX) break;
      if (game.tally || game.state !== 'play') break;
    }
    clear();
    return { frames: i, x: Math.round(game.player.x), deaths: deaths, log: log };
  }

  /** Бой с боссом: держимся под кабиной и прыгаем; после победы — к капсуле и табличке */
  function boss(maxF, invuln) {
    var jh = 0, hits = 0;
    for (var i = 0; i < maxF; i++) {
      var p = game.player, b = game.boss;
      if (invuln) p.invuln = Math.max(p.invuln, 5);
      clear();
      if (b && b.state === 'fight') {
        // Держимся под кабиной, но отходим от шара; прыгаем, когда шар далеко
        var dx = b.x - p.x, bd = b.bx - p.x;
        var ballNear = Math.abs(bd) < 34 && b.by > p.y - 60;
        if (ballNear) V[bd > 0 ? 'left' : 'right'] = true;
        else if (Math.abs(dx) > 6) V[dx > 0 ? 'right' : 'left'] = true;
        if (p.ground && Math.abs(dx) < 30 && Math.abs(bd) > 44 && jh === 0) jh = 30;
      } else if (game.bossDefeated && !game.capsuleDone) {
        // Идём к капсуле и запрыгиваем на кнопку
        var cap = game.objects.filter(function (o) { return o.type === 'capsule'; })[0];
        var side = p.x < cap.x ? -1 : 1;
        var cdx = cap.x + side * 44 - p.x;
        if (p.ground && Math.abs(cdx) > 4) V[cdx > 0 ? 'right' : 'left'] = true;
        else if (!p.ground && Math.abs(p.x - cap.x) > 6) V[p.x < cap.x ? 'right' : 'left'] = true;
        if (p.ground && Math.abs(cdx) <= 4 && Math.abs(p.gsp) < 0.3 && jh === 0) jh = 30;
      } else {
        V.right = true;
        if (p.ground && Math.abs(p.gsp) < 0.5 && jh === 0) jh = 25;
      }
      if (jh > 0) { V.jump = true; jh--; }
      var hp = b ? b.hp : 0;
      game.step();
      if (b && b.hp < hp) hits++;
      if (game.dying) return { ok: false, reason: 'died', frames: i, hits: hits };
      if (game.tally) break;
    }
    clear();
    return { ok: !!game.tally, frames: i, hits: hits, capsule: game.capsuleDone, animals: game.animalsSaved };
  }

  /** Петля: с вершины горки бегом вправо — герой должен пройти через верх петли */
  function loop(x, y, cx, cy) {
    start(); game.teleport(x, y); clear(); V.right = true;
    var top = false;
    for (var i = 0; i < 900; i++) {
      game.player.invuln = 5; game.step();
      var p = game.player;
      if (Math.abs(p.x - cx) < 20 && p.y < cy - 40 && p.ground) top = true;
      if (p.x > cx + 200) break;
    }
    clear();
    return { ok: top && game.player.x > cx + 200, top: top, x: Math.round(game.player.x) };
  }
  /** Петля без разгона — пройти не должна */
  function loopNoSpeed(x, cx, cy) {
    start(); game.teleport(x, 1381 - 100); clear();
    for (var i = 0; i < 60; i++) game.step();
    V.right = true;
    var top = false;
    for (i = 0; i < 400; i++) { game.player.invuln = 5; game.step(); var p = game.player; if (Math.abs(p.x - cx) < 20 && p.y < cy - 40 && p.ground) top = true; }
    clear();
    return { ok: !top, top: top };
  }
  /** Continue: смерть без колец при 1 жизни → экран CONTINUE → старт с начала, очки 0 */
  function cont() {
    start();
    game.lives = 1; game.rings = 0; game.score = 1234; game.player.invuln = 0; game.player.invincible = 0; game.player.shield = false;
    game.hurtPlayer(game.player.x + 10);
    for (var i = 0; i < 300 && game.state === 'play'; i++) game.step();
    var s1 = game.state;
    for (i = 0; i < 30; i++) game.step();
    TH.Input.tap('start'); game.step();
    var res = { ok: s1 === 'continue' && game.state === 'play' && game.score === 0 && game.lives === 3 && game.player.x < 200, after: game.state, s1: s1, score: game.score, lives: game.lives };
    // Таймер continue до 0 → game over
    game.lives = 1; game.player.invuln = 0; game.cardT = 170;
    game.hurtPlayer(game.player.x + 10);
    for (i = 0; i < 300 && game.state === 'play'; i++) game.step();
    for (i = 0; i < 620; i++) game.step();
    res.gameover = game.state === 'gameover';
    for (i = 0; i < 400; i++) game.step();
    res.backToTitle = game.state === 'title';
    res.ok = res.ok && res.gameover && res.backToTitle;
    return res;
  }
  /** Разлёт колец: удар с кольцами не убивает, кольца падают и не проваливаются */
  function ringScatter() {
    start(); game.teleport(500, 1300);
    for (var i = 0; i < 40; i++) game.step();
    game.rings = 32; game.player.invuln = 0;
    game.hurtPlayer(game.player.x + 10);
    var loose = game.objects.filter(function (o) { return o.type === 'loosering'; });
    for (i = 0; i < 120; i++) game.step();
    var below = loose.filter(function (o) { return o.alive && o.y > 1400 + 2; }).length;
    return { ok: loose.length === 32 && below === 0 && !game.dying, spawned: loose.length, fellThrough: below, alive: !game.dying };
  }
  /** Врагов рядом с чекпоинтами быть не должно */
  function cpEnemies() {
    var objs = game.level.objects, bad = [];
    objs.filter(function (o) { return o.type === 'checkpoint'; }).forEach(function (c) {
      objs.forEach(function (o) { if (o.type === 'enemy' && Math.abs(o.x - c.x) < 300) bad.push([c.x, o.kind, o.x]); });
    });
    return { ok: bad.length === 0, bad: bad };
  }

  function all() {
    var r = {};
    r.cpEnemies = cpEnemies();
    r.loop1 = loop(2600, 1150, 3264, 1320);
    r.loop1NoSpeed = loopNoSpeed(3110, 3264, 1320);
    r.loop2 = loop(10500, 1290, 11360, 1424);
    r.ringScatter = ringScatter();
    start(); game.teleport(96, 1370);
    r.fullRun = run(12000, { invuln: true });
    r.boss = boss(6000, false);
    r.cont = cont();
    console.log('TEST RESULTS', JSON.stringify(r));
    return r;
  }
  return { run: run, boss: boss, loop: loop, loopNoSpeed: loopNoSpeed, cont: cont, ringScatter: ringScatter, cpEnemies: cpEnemies, all: all, start: start };
})();
