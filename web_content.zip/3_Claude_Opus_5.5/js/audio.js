/* ==========================================================================
   audio.js — звук: синтез эффектов и FM-подобная музыка через WebAudio
   Вся музыка оригинальная. Можно подменить mp3-файлами (см. CONFIG.MUSIC_FILES).
   ========================================================================== */
'use strict';

TH.Audio = (function () {
  var ctx = null, master = null, sfxBus = null, musicBus = null, noiseBuf = null;
  var muted = TH.store.get('th_muted', '0') === '1';
  var musicOn = TH.store.get('th_music', '1') === '1';
  var ringPan = 1;
  var lastPlay = {};

  /** Создание аудиоконтекста по первому пользовательскому жесту */
  function unlock() {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = muted ? 0 : 0.8;
    var comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -12; comp.ratio.value = 4;
    master.connect(comp); comp.connect(ctx.destination);
    sfxBus = ctx.createGain(); sfxBus.gain.value = 0.55; sfxBus.connect(master);
    musicBus = ctx.createGain(); musicBus.gain.value = musicOn ? 0.42 : 0; musicBus.connect(master);
    // Буфер белого шума для ударных и шипящих эффектов
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
    var d = noiseBuf.getChannelData(0);
    for (var i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    if (Music.pending) Music.play(Music.pending);
  }

  /* ------------------------ Примитивы синтеза ------------------------ */
  function tone(o) {
    // o: {f, f2, t(длительность), type, vol, delay, attack, pan, bus, vib}
    if (!ctx) return;
    var t0 = ctx.currentTime + (o.delay || 0);
    var dur = o.t || 0.1;
    var osc = ctx.createOscillator();
    var g = ctx.createGain();
    osc.type = o.type || 'square';
    osc.frequency.setValueAtTime(o.f, t0);
    if (o.f2) osc.frequency.exponentialRampToValueAtTime(Math.max(20, o.f2), t0 + dur);
    if (o.vib) {
      var lfo = ctx.createOscillator(), lg = ctx.createGain();
      lfo.frequency.value = o.vib; lg.gain.value = o.vibDepth || 30;
      lfo.connect(lg); lg.connect(osc.frequency); lfo.start(t0); lfo.stop(t0 + dur + 0.05);
    }
    var v = o.vol === undefined ? 0.3 : o.vol;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(v, t0 + (o.attack || 0.005));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g);
    var out = g;
    if (o.pan && ctx.createStereoPanner) {
      var p = ctx.createStereoPanner(); p.pan.value = o.pan; g.connect(p); out = p;
    }
    out.connect(o.bus || sfxBus);
    osc.start(t0); osc.stop(t0 + dur + 0.02);
  }
  function noise(o) {
    // o: {t, vol, f (частота фильтра), f2, q, type ('lowpass'|'bandpass'|'highpass'), delay}
    if (!ctx) return;
    var t0 = ctx.currentTime + (o.delay || 0);
    var dur = o.t || 0.2;
    var src = ctx.createBufferSource(); src.buffer = noiseBuf; src.loop = true;
    var flt = ctx.createBiquadFilter(); flt.type = o.type || 'lowpass';
    flt.frequency.setValueAtTime(o.f || 2000, t0);
    if (o.f2) flt.frequency.exponentialRampToValueAtTime(o.f2, t0 + dur);
    flt.Q.value = o.q || 1;
    var g = ctx.createGain();
    var v = o.vol === undefined ? 0.3 : o.vol;
    g.gain.setValueAtTime(v, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(flt); flt.connect(g); g.connect(o.bus || sfxBus);
    src.start(t0, Math.random() * 0.5); src.stop(t0 + dur + 0.02);
  }

  /* ------------------------ Звуковые эффекты ------------------------ */
  var SFX = {
    ring: function () {
      // Звонкий двухтоновый «динь», чередуя каналы как в 16-битных играх
      ringPan = -ringPan;
      tone({ f: 1318, t: 0.07, type: 'square', vol: 0.13, pan: ringPan * 0.6 });
      tone({ f: 1975, t: 0.45, type: 'square', vol: 0.12, delay: 0.06, pan: ringPan * 0.6 });
      tone({ f: 3951, t: 0.3, type: 'sine', vol: 0.05, delay: 0.06, pan: ringPan * 0.6 });
    },
    jump: function () { tone({ f: 260, f2: 820, t: 0.16, type: 'square', vol: 0.14 }); },
    spring: function () {
      tone({ f: 220, f2: 1100, t: 0.32, type: 'square', vol: 0.14, vib: 28, vibDepth: 60 });
      tone({ f: 440, f2: 2200, t: 0.25, type: 'triangle', vol: 0.08 });
    },
    charge: function (rev) {
      var b = 380 + (rev || 0) * 70;
      tone({ f: b, f2: b * 2.4, t: 0.22, type: 'sawtooth', vol: 0.09 });
      noise({ t: 0.18, vol: 0.12, f: 3000, type: 'bandpass', q: 2 });
    },
    release: function () {
      tone({ f: 1400, f2: 180, t: 0.3, type: 'sawtooth', vol: 0.12 });
      noise({ t: 0.35, vol: 0.25, f: 4000, f2: 300 });
    },
    roll: function () { noise({ t: 0.22, vol: 0.14, f: 1500, f2: 5000, type: 'bandpass', q: 3 }); },
    skid: function () {
      noise({ t: 0.28, vol: 0.18, f: 2500, type: 'bandpass', q: 4 });
      for (var i = 0; i < 4; i++) tone({ f: 900, t: 0.03, type: 'square', vol: 0.04, delay: i * 0.06 });
    },
    pop: function () {
      noise({ t: 0.35, vol: 0.35, f: 1800, f2: 120 });
      tone({ f: 180, f2: 50, t: 0.25, type: 'square', vol: 0.18 });
    },
    animal: function () {
      tone({ f: 1500, f2: 2200, t: 0.06, type: 'square', vol: 0.06 });
      tone({ f: 1800, f2: 2600, t: 0.06, type: 'square', vol: 0.06, delay: 0.09 });
    },
    hurt: function () {
      // «Рассыпание» колец: быстрые звонкие тоны вниз
      for (var i = 0; i < 9; i++) tone({ f: 2600 - i * 160, t: 0.09, type: 'square', vol: 0.07, delay: i * 0.035, pan: (i % 2 ? -0.5 : 0.5) });
      noise({ t: 0.3, vol: 0.12, f: 6000, type: 'highpass' });
    },
    hurtNoRing: function () { tone({ f: 600, f2: 200, t: 0.3, type: 'sawtooth', vol: 0.15 }); },
    monitor: function () {
      noise({ t: 0.25, vol: 0.3, f: 2500, f2: 200 });
      tone({ f: 120, f2: 60, t: 0.2, type: 'square', vol: 0.15 });
    },
    powerup: function () {
      [523, 659, 784, 1046].forEach(function (f, i) { tone({ f: f, t: 0.12, type: 'square', vol: 0.09, delay: i * 0.05 }); });
    },
    shield: function () { tone({ f: 300, f2: 900, t: 0.35, type: 'triangle', vol: 0.18, vib: 18, vibDepth: 40 }); },
    checkpoint: function () {
      tone({ f: 784, t: 0.12, type: 'square', vol: 0.1 });
      tone({ f: 1175, t: 0.4, type: 'square', vol: 0.1, delay: 0.1 });
      tone({ f: 1568, t: 0.4, type: 'sine', vol: 0.06, delay: 0.1 });
    },
    bossHit: function () {
      tone({ f: 160, f2: 70, t: 0.35, type: 'square', vol: 0.25 });
      tone({ f: 1250, f2: 600, t: 0.2, type: 'square', vol: 0.12 });
      noise({ t: 0.25, vol: 0.25, f: 5000, f2: 800, type: 'bandpass', q: 2 });
    },
    explosion: function () {
      noise({ t: 0.6, vol: 0.4, f: 1200, f2: 60 });
      tone({ f: 90, f2: 30, t: 0.5, type: 'sine', vol: 0.3 });
    },
    signpost: function () {
      for (var i = 0; i < 16; i++) tone({ f: 1200 + (i % 2) * 300, t: 0.04, type: 'square', vol: 0.06, delay: i * 0.05 });
    },
    death: function () {
      tone({ f: 900, f2: 120, t: 0.7, type: 'square', vol: 0.15 });
      tone({ f: 450, f2: 60, t: 0.7, type: 'triangle', vol: 0.12 });
    },
    splash: function () { noise({ t: 0.45, vol: 0.3, f: 3000, f2: 400, type: 'bandpass', q: 1 }); },
    crumble: function () { noise({ t: 0.4, vol: 0.25, f: 700, f2: 150 }); },
    tally: function () { tone({ f: 1760, t: 0.03, type: 'square', vol: 0.06 }); },
    cash: function () {
      [1046, 1318, 1568, 2093].forEach(function (f, i) { tone({ f: f, t: 0.25, type: 'square', vol: 0.08, delay: i * 0.04 }); });
    },
    shoot: function () { tone({ f: 900, f2: 300, t: 0.12, type: 'square', vol: 0.08 }); },
    beep: function () { tone({ f: 880, t: 0.06, type: 'square', vol: 0.08 }); },
    select: function () { tone({ f: 660, t: 0.06, type: 'square', vol: 0.1 }); tone({ f: 990, t: 0.1, type: 'square', vol: 0.1, delay: 0.06 }); },
    bumper: function () { tone({ f: 500, f2: 1500, t: 0.12, type: 'triangle', vol: 0.15 }); },
    capsule: function () {
      noise({ t: 0.8, vol: 0.35, f: 2000, f2: 100 });
      [392, 523, 659, 784].forEach(function (f, i) { tone({ f: f, t: 0.2, type: 'square', vol: 0.08, delay: 0.3 + i * 0.08 }); });
    },
    button: function () { tone({ f: 300, f2: 150, t: 0.1, type: 'square', vol: 0.15 }); }
  };

  function play(name, arg) {
    if (!ctx || muted || !SFX[name]) return;
    // Защита от «пулемёта» одинаковых звуков в одном кадре
    var now = ctx.currentTime;
    if (lastPlay[name] && now - lastPlay[name] < 0.025) return;
    lastPlay[name] = now;
    SFX[name](arg);
  }

  /* ============================ МУЗЫКА ============================ */
  var NOTE = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
  function noteFreq(tok) {
    var m = /^([A-G])([#b]?)(\d)$/.exec(tok);
    if (!m) return 0;
    var n = NOTE[m[1]] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0);
    var midi = 12 * (+m[3] + 1) + n;
    return 440 * Math.pow(2, (midi - 69) / 12);
  }
  /** Разбор строки шагов: нота, «-» продление, «.» пауза → [{step, f, len}] */
  function parse(str) {
    var toks = str.trim().split(/\s+/), out = [], cur = null;
    for (var i = 0; i < toks.length; i++) {
      var t = toks[i];
      if (t === '-') { if (cur) cur.len++; }
      else if (t === '.') cur = null;
      else { cur = { step: i, f: noteFreq(t), len: 1 }; out.push(cur); }
    }
    return { notes: out, steps: toks.length };
  }

  var CH = {
    C: ['C', 'E', 'G'], Am: ['A', 'C', 'E'], F: ['F', 'A', 'C'], G: ['G', 'B', 'D'],
    Em: ['E', 'G', 'B'], Dm: ['D', 'F', 'A'], Bb: ['Bb', 'D', 'F'], E: ['E', 'G#', 'B'],
    D: ['D', 'F#', 'A'], Gm: ['G', 'Bb', 'D']
  };
  /** Бас и аккомпанемент генерируются из последовательности аккордов (по полтакта) */
  function bassFromChords(chords, style) {
    var t = [];
    for (var i = 0; i < chords.length; i++) {
      var r = CH[chords[i]][0], f = CH[chords[i]][2];
      if (style === 'drive') t.push(r + '2', r + '2', r + '3', r + '2', r + '2', r + '3', r + '2', f + '2');
      else t.push(r + '2', '.', r + '3', '.', r + '2', r + '2', r + '3', '.');
    }
    return t.join(' ');
  }
  function stabsFromChords(chords, idx, oct) {
    var t = [];
    for (var i = 0; i < chords.length; i++) {
      var n = CH[chords[i]][idx] + oct;
      t.push('.', '.', n, '.', '.', '.', n, '-');
    }
    return t.join(' ');
  }
  function arpFromChords(chords, oct) {
    var t = [];
    for (var i = 0; i < chords.length; i++) {
      var c = CH[chords[i]];
      t.push(c[0] + oct, c[1] + oct, c[2] + oct, c[1] + oct, c[0] + oct, c[1] + oct, c[2] + oct, c[1] + oct);
    }
    return t.join(' ');
  }

  // ---- Тема уровня «Palm Valley» (оригинальная мелодия, до мажор, 144 BPM) ----
  var LV_CHORDS = ['C', 'C', 'Am', 'Am', 'F', 'F', 'G', 'G', 'C', 'C', 'Am', 'Am', 'F', 'G', 'C', 'C',
    'F', 'F', 'G', 'G', 'Em', 'Em', 'Am', 'Am', 'Dm', 'Dm', 'G', 'G', 'C', 'C', 'G', 'G'];
  var LV_LEAD = [
    'E5 - G5 - C6 - - - B5 - G5 - E5 - G5 -', 'A5 - - - G5 - E5 - C5 - D5 - E5 - - -',
    'F5 - A5 - C6 - A5 - D6 - C6 - A5 - F5 -', 'G5 - - - - - D5 - G5 - A5 - B5 - D6 -',
    'E6 - D6 - C6 - - - G5 - - - E5 - G5 -', 'A5 - C6 - E6 - D6 - C6 - A5 - - - . .',
    'F5 - A5 - C6 - A5 - B5 - D6 - G6 - F6 -', 'E6 - - - - - - - C6 . E6 . G6 - - -',
    'A5 - - C6 - - F6 - E6 - - D6 - - C6 -', 'D6 - - - B5 - - - G5 - A5 - B5 - D6 -',
    'E6 - - D6 - - B5 - G5 - - - E5 - G5 -', 'A5 - - - C6 - - - E6 - - - A6 - - -',
    'F6 - E6 - D6 - C6 - A5 - - - F5 - A5 -', 'G5 - B5 - D6 - G6 - F6 - D6 - B5 - G5 -',
    'C6 - G5 - E5 - G5 - C6 - E6 - G6 - - -', 'D6 - - - B5 - - - G5 . A5 . B5 . D6 .'
  ].join(' ');
  var LV_DRUMS = { kick: [0, 7, 8], snare: [4, 12], hat: [0, 2, 4, 6, 8, 10, 12, 14], open: [14] };

  // ---- Тема босса (ля минор, 168 BPM) ----
  var BS_CHORDS = ['Am', 'Am', 'Am', 'Am', 'F', 'F', 'G', 'G', 'Am', 'Am', 'Am', 'Am', 'Bb', 'Bb', 'E', 'E'];
  var BS_LEAD = [
    'A4 - - - C5 - - - E5 - D5 - C5 - B4 -', 'A4 - - - - - - - E4 - - - A4 - B4 -',
    'C5 - - - A4 - - - F5 - E5 - C5 - A4 -', 'B4 - - - G4 - - - D5 - C5 - B4 - G4 -',
    'A5 - G5 - E5 - - - A5 - G5 - E5 - D5 -', 'C5 - D5 - E5 - - - - - - - . . . .',
    'F5 - - - D5 - - - Bb4 - - - D5 - F5 -', 'E5 - - - G#4 - - - B4 - - - E5 - G#5 -'
  ].join(' ');
  var BS_DRUMS = { kick: [0, 4, 8, 10, 12], snare: [4, 12], hat: [0, 2, 4, 6, 8, 10, 12, 14], open: [6, 14] };

  // ---- Джинглы ----
  var JINGLES = {
    clear: { bpm: 150, lead: 'G5 - C6 - E6 - G6 - - - E6 - G6 - - - - - - - . . A5 - B5 - C6 - D6 - E6 - - - - - - - - - - - - - - -', bass: 'C3 - - - - - - - - - - - - - - - F2 - - - G2 - - - C3 - - - - - - - - - - - - - - -' },
    oneup: { bpm: 160, lead: 'C6 - E6 - G6 - C6 E6 G6 - - - C7 - - - - - - -', bass: 'C3 - - - G3 - - - C3 - - - - - - - - - - -' },
    gameover: { bpm: 100, lead: 'G5 - - F#5 - - F5 - - E5 - - - - - D#5 - - - - - - - - - - - - - - -', bass: 'C3 - - - - - B2 - - - - - Bb2 - - - - - A2 - - - - - - - - - - - - -' },
    continue: { bpm: 120, lead: 'E5 - G5 - C6 - - - D6 - - - C6 - - -', bass: 'C3 - - - - - - - G2 - - - C3 - - -' }
  };

  function makeSong(o) {
    return {
      bpm: o.bpm,
      tracks: [
        { inst: 'lead', pat: parse(o.lead), vol: 0.16 },
        { inst: 'lead2', pat: parse(o.lead), vol: 0.05, detune: 1.006 },
        { inst: 'bass', pat: parse(o.bass), vol: 0.3 },
        o.stab1 ? { inst: 'stab', pat: parse(o.stab1), vol: 0.06 } : null,
        o.stab2 ? { inst: 'stab', pat: parse(o.stab2), vol: 0.06 } : null,
        o.arp ? { inst: 'arp', pat: parse(o.arp), vol: 0.035 } : null
      ].filter(Boolean),
      drums: o.drums,
      loop: o.loop !== false
    };
  }
  var SONGS = {
    level: makeSong({
      bpm: 144, lead: LV_LEAD, bass: bassFromChords(LV_CHORDS),
      stab1: stabsFromChords(LV_CHORDS, 1, 4), stab2: stabsFromChords(LV_CHORDS, 2, 4), drums: LV_DRUMS
    }),
    boss: makeSong({
      bpm: 168, lead: BS_LEAD, bass: bassFromChords(BS_CHORDS, 'drive'),
      arp: arpFromChords(BS_CHORDS, 5), stab1: stabsFromChords(BS_CHORDS, 1, 4), drums: BS_DRUMS
    }),
    invincible: makeSong({
      bpm: 176, lead: LV_LEAD, bass: bassFromChords(LV_CHORDS, 'drive'),
      arp: arpFromChords(LV_CHORDS, 5), drums: BS_DRUMS
    }),
    clear: makeSong({ bpm: JINGLES.clear.bpm, lead: JINGLES.clear.lead, bass: JINGLES.clear.bass, loop: false }),
    oneup: makeSong({ bpm: JINGLES.oneup.bpm, lead: JINGLES.oneup.lead, bass: JINGLES.oneup.bass, loop: false }),
    gameover: makeSong({ bpm: JINGLES.gameover.bpm, lead: JINGLES.gameover.lead, bass: JINGLES.gameover.bass, loop: false }),
    continue: makeSong({ bpm: JINGLES.continue.bpm, lead: JINGLES.continue.lead, bass: JINGLES.continue.bass, loop: true })
  };

  /* ---- Инструменты: 2-операторный FM (модулятор → частота несущей) ---- */
  function fmNote(inst, f, t0, dur, vol) {
    var car = ctx.createOscillator(), mod = ctx.createOscillator();
    var mg = ctx.createGain(), g = ctx.createGain();
    var ratio = 1, index = 1, ctype = 'sine', rel = 0.05, decay = dur;
    if (inst === 'lead' || inst === 'lead2') { ratio = 2; index = 2.2; ctype = inst === 'lead' ? 'sine' : 'triangle'; rel = 0.06; }
    else if (inst === 'bass') { ratio = 1; index = 3.2; ctype = 'sine'; decay = Math.min(dur, 0.35); }
    else if (inst === 'stab') { ratio = 3; index = 1.2; ctype = 'triangle'; decay = Math.min(dur, 0.18); }
    else if (inst === 'arp') { ratio = 4; index = 0.8; ctype = 'square'; decay = Math.min(dur, 0.09); }
    car.type = ctype; car.frequency.value = f;
    mod.frequency.value = f * ratio;
    mg.gain.setValueAtTime(f * index, t0);
    mg.gain.exponentialRampToValueAtTime(Math.max(1, f * index * 0.25), t0 + Math.max(0.05, decay));
    mod.connect(mg); mg.connect(car.frequency);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(vol, t0 + 0.008);
    g.gain.setValueAtTime(vol * 0.8, t0 + Math.max(0.01, decay * 0.6));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + decay + rel);
    car.connect(g); g.connect(musicBus);
    car.start(t0); mod.start(t0);
    car.stop(t0 + decay + rel + 0.02); mod.stop(t0 + decay + rel + 0.02);
  }
  function drum(kind, t0) {
    if (kind === 'kick') {
      var o = ctx.createOscillator(), g = ctx.createGain();
      o.frequency.setValueAtTime(150, t0); o.frequency.exponentialRampToValueAtTime(40, t0 + 0.12);
      g.gain.setValueAtTime(0.5, t0); g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.16);
      o.connect(g); g.connect(musicBus); o.start(t0); o.stop(t0 + 0.18);
    } else {
      var src = ctx.createBufferSource(); src.buffer = noiseBuf;
      var flt = ctx.createBiquadFilter(), ng = ctx.createGain();
      var len = kind === 'snare' ? 0.14 : kind === 'open' ? 0.12 : 0.035;
      flt.type = kind === 'snare' ? 'bandpass' : 'highpass';
      flt.frequency.value = kind === 'snare' ? 1800 : 7000;
      ng.gain.setValueAtTime(kind === 'snare' ? 0.32 : 0.09, t0);
      ng.gain.exponentialRampToValueAtTime(0.0001, t0 + len);
      src.connect(flt); flt.connect(ng); ng.connect(musicBus);
      src.start(t0, Math.random() * 0.5); src.stop(t0 + len + 0.01);
      if (kind === 'snare') {
        var o2 = ctx.createOscillator(), g2 = ctx.createGain();
        o2.frequency.setValueAtTime(220, t0); o2.frequency.exponentialRampToValueAtTime(120, t0 + 0.08);
        g2.gain.setValueAtTime(0.18, t0); g2.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.1);
        o2.connect(g2); g2.connect(musicBus); o2.start(t0); o2.stop(t0 + 0.12);
      }
    }
  }

  /* ---- Секвенсор с упреждающим планированием ---- */
  var Music = {
    current: null, song: null, step: 0, nextTime: 0, timer: null, tempoMul: 1, pending: null,
    audioEl: null, onEnd: null,
    play: function (name, onEnd) {
      this.stop();
      this.current = name; this.onEnd = onEnd || null;
      if (!ctx) { this.pending = name; return; }
      this.pending = null;
      var file = TH.CONFIG.MUSIC_FILES[name];
      if (file) { this.playFile(name, file); return; }
      this.startSynth(name);
    },
    startSynth: function (name) {
      this.song = SONGS[name];
      if (!this.song) return;
      this.step = 0;
      this.nextTime = ctx.currentTime + 0.06;
      var self = this;
      this.timer = setInterval(function () { self.schedule(); }, 25);
      this.schedule();
    },
    playFile: function (name, file) {
      var self = this, el = new Audio();
      el.loop = name === 'level' || name === 'boss' || name === 'invincible';
      el.volume = musicOn && !muted ? 0.6 : 0;
      el.addEventListener('error', function () { if (self.audioEl === el && self.current === name) { self.audioEl = null; self.startSynth(name); } });
      el.addEventListener('ended', function () { if (self.onEnd) self.onEnd(); });
      el.src = file;
      this.audioEl = el;
      var p = el.play();
      if (p && p.catch) p.catch(function () { /* автоплей запрещён — ждём жеста */ });
    },
    schedule: function () {
      if (!this.song) return;
      var s = this.song;
      var stepDur = 60 / (s.bpm * this.tempoMul) / 4;
      var total = s.tracks[0].pat.steps;
      while (this.nextTime < ctx.currentTime + 0.15) {
        var st = this.step % total;
        if (!s.loop && this.step >= total) {
          var cb = this.onEnd; this.stopSynth(); this.current = null;
          if (cb) cb();
          return;
        }
        for (var i = 0; i < s.tracks.length; i++) {
          var tr = s.tracks[i], pat = tr.pat;
          var lst = this.step % pat.steps;
          for (var j = 0; j < pat.notes.length; j++) {
            var n = pat.notes[j];
            if (n.step === lst && n.f) fmNote(tr.inst, n.f * (tr.detune || 1), this.nextTime, n.len * stepDur * 0.95, tr.vol);
          }
        }
        if (s.drums) {
          var b = st % 16;
          if (s.drums.kick.indexOf(b) >= 0) drum('kick', this.nextTime);
          if (s.drums.snare.indexOf(b) >= 0) drum('snare', this.nextTime);
          if (s.drums.open.indexOf(b) >= 0) drum('open', this.nextTime);
          else if (s.drums.hat.indexOf(b) >= 0) drum('hat', this.nextTime);
        }
        this.step++;
        this.nextTime += stepDur;
      }
    },
    stopSynth: function () { if (this.timer) clearInterval(this.timer); this.timer = null; this.song = null; },
    stop: function () {
      this.stopSynth();
      if (this.audioEl) { this.audioEl.pause(); this.audioEl = null; }
      this.current = null; this.pending = null;
    },
    setTempo: function (m) { this.tempoMul = m; if (this.audioEl) this.audioEl.playbackRate = m; }
  };

  function applyGain() {
    if (!ctx) return;
    master.gain.setTargetAtTime(muted ? 0 : 0.8, ctx.currentTime, 0.02);
    musicBus.gain.setTargetAtTime(musicOn ? 0.42 : 0, ctx.currentTime, 0.02);
    if (Music.audioEl) Music.audioEl.volume = musicOn && !muted ? 0.6 : 0;
  }

  document.addEventListener('visibilitychange', function () {
    if (!ctx) return;
    if (document.hidden) ctx.suspend(); else ctx.resume();
  });

  return {
    unlock: unlock,
    play: play,
    music: Music,
    get muted() { return muted; },
    get musicOn() { return musicOn; },
    toggleMute: function () { muted = !muted; TH.store.set('th_muted', muted ? '1' : '0'); applyGain(); return muted; },
    toggleMusic: function () { musicOn = !musicOn; TH.store.set('th_music', musicOn ? '1' : '0'); applyGain(); return musicOn; },
    get ready() { return !!ctx; }
  };
})();
