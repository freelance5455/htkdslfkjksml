/* ==========================================================================
   util.js — общее пространство имён TH, математика, пиксельный шрифт
   ========================================================================== */
'use strict';
var TH = window.TH || {};
window.TH = TH;

TH.W = 424;   // ретро-разрешение игрового поля
TH.H = 240;

/* ---------------- Математика ---------------- */
TH.clamp = function (v, a, b) { return v < a ? a : v > b ? b : v; };
TH.lerp = function (a, b, t) { return a + (b - a) * t; };
TH.sign = function (v) { return v > 0 ? 1 : v < 0 ? -1 : 0; };
TH.approach = function (v, target, step) {
  if (v < target) return Math.min(v + step, target);
  return Math.max(v - step, target);
};
/** Нормализация угла в (-PI, PI] */
TH.wrapAngle = function (a) {
  while (a <= -Math.PI) a += Math.PI * 2;
  while (a > Math.PI) a -= Math.PI * 2;
  return a;
};
/** Кратчайшая разница углов b - a */
TH.angleDiff = function (a, b) { return TH.wrapAngle(b - a); };
TH.rand = function (a, b) { return a + Math.random() * (b - a); };
TH.irand = function (a, b) { return Math.floor(a + Math.random() * (b - a + 1)); };
TH.ease = function (t) { return 0.5 - 0.5 * Math.cos(Math.PI * TH.clamp(t, 0, 1)); };
TH.rectsOverlap = function (ax0, ay0, ax1, ay1, bx0, by0, bx1, by1) {
  return ax0 < bx1 && ax1 > bx0 && ay0 < by1 && ay1 > by0;
};
TH.makeCanvas = function (w, h) {
  var c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
};
/** Безопасный доступ к localStorage (в приватном режиме может бросать исключение) */
TH.store = {
  get: function (k, d) { try { var v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } },
  set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) { /* игнорируем */ } }
};

/* ---------------- Пиксельный шрифт 5×7 (нарисован в коде) ----------------
   Каждый глиф — 7 строк, биты 16..1 — пиксели слева направо. */
TH.Font = (function () {
  var G = {
    '0': [14, 17, 19, 21, 25, 17, 14], '1': [4, 12, 4, 4, 4, 4, 14], '2': [14, 17, 1, 2, 4, 8, 31],
    '3': [31, 2, 4, 2, 1, 17, 14], '4': [2, 6, 10, 18, 31, 2, 2], '5': [31, 16, 30, 1, 1, 17, 14],
    '6': [6, 8, 16, 30, 17, 17, 14], '7': [31, 1, 2, 4, 8, 8, 8], '8': [14, 17, 17, 14, 17, 17, 14],
    '9': [14, 17, 17, 15, 1, 2, 12],
    'A': [14, 17, 17, 31, 17, 17, 17], 'B': [30, 17, 17, 30, 17, 17, 30], 'C': [14, 17, 16, 16, 16, 17, 14],
    'D': [28, 18, 17, 17, 17, 18, 28], 'E': [31, 16, 16, 30, 16, 16, 31], 'F': [31, 16, 16, 30, 16, 16, 16],
    'G': [14, 17, 16, 23, 17, 17, 15], 'H': [17, 17, 17, 31, 17, 17, 17], 'I': [14, 4, 4, 4, 4, 4, 14],
    'J': [7, 2, 2, 2, 2, 18, 12], 'K': [17, 18, 20, 24, 20, 18, 17], 'L': [16, 16, 16, 16, 16, 16, 31],
    'M': [17, 27, 21, 21, 17, 17, 17], 'N': [17, 17, 25, 21, 19, 17, 17], 'O': [14, 17, 17, 17, 17, 17, 14],
    'P': [30, 17, 17, 30, 16, 16, 16], 'Q': [14, 17, 17, 17, 21, 18, 13], 'R': [30, 17, 17, 30, 20, 18, 17],
    'S': [15, 16, 16, 14, 1, 1, 30], 'T': [31, 4, 4, 4, 4, 4, 4], 'U': [17, 17, 17, 17, 17, 17, 14],
    'V': [17, 17, 17, 17, 17, 10, 4], 'W': [17, 17, 17, 21, 21, 21, 10], 'X': [17, 17, 10, 4, 10, 17, 17],
    'Y': [17, 17, 10, 4, 4, 4, 4], 'Z': [31, 1, 2, 4, 8, 16, 31],
    ' ': [0, 0, 0, 0, 0, 0, 0], '!': [4, 4, 4, 4, 4, 0, 4], '?': [14, 17, 1, 2, 4, 0, 4],
    '.': [0, 0, 0, 0, 0, 12, 12], ',': [0, 0, 0, 0, 12, 4, 8], ':': [0, 12, 12, 0, 12, 12, 0],
    '-': [0, 0, 0, 31, 0, 0, 0], '+': [0, 4, 4, 31, 4, 4, 0], '×': [0, 17, 10, 4, 10, 17, 0],
    '/': [1, 1, 2, 4, 8, 16, 16], "'": [4, 4, 8, 0, 0, 0, 0], '"': [10, 10, 0, 0, 0, 0, 0],
    '©': [14, 17, 23, 25, 23, 17, 14], '(': [2, 4, 8, 8, 8, 4, 2], ')': [8, 4, 2, 2, 2, 4, 8],
    // Кириллица (заглавные, что используются в игре)
    'А': [14, 17, 17, 31, 17, 17, 17], 'Б': [31, 16, 16, 30, 17, 17, 30], 'В': [30, 17, 17, 30, 17, 17, 30],
    'Г': [31, 16, 16, 16, 16, 16, 16], 'Д': [6, 10, 10, 10, 10, 31, 17], 'Е': [31, 16, 16, 30, 16, 16, 31],
    'Ж': [21, 21, 21, 14, 21, 21, 21], 'З': [14, 17, 1, 6, 1, 17, 14], 'И': [17, 17, 19, 21, 25, 17, 17],
    'Й': [10, 4, 17, 19, 21, 25, 17], 'К': [17, 18, 20, 24, 20, 18, 17], 'Л': [7, 9, 9, 9, 9, 9, 17],
    'М': [17, 27, 21, 21, 17, 17, 17], 'Н': [17, 17, 17, 31, 17, 17, 17], 'О': [14, 17, 17, 17, 17, 17, 14],
    'П': [31, 17, 17, 17, 17, 17, 17], 'Р': [30, 17, 17, 30, 16, 16, 16], 'С': [14, 17, 16, 16, 16, 17, 14],
    'Т': [31, 4, 4, 4, 4, 4, 4], 'У': [17, 17, 17, 15, 1, 17, 14], 'Ф': [4, 14, 21, 21, 21, 14, 4],
    'Х': [17, 17, 10, 4, 10, 17, 17], 'Ц': [18, 18, 18, 18, 18, 31, 1], 'Ч': [17, 17, 17, 15, 1, 1, 1],
    'Ш': [21, 21, 21, 21, 21, 21, 31], 'Ы': [17, 17, 17, 29, 19, 19, 29], 'Ь': [16, 16, 16, 30, 17, 17, 30],
    'Э': [14, 17, 1, 7, 1, 17, 14], 'Ю': [18, 21, 21, 29, 21, 21, 18], 'Я': [15, 17, 17, 15, 5, 9, 17]
  };
  var chars = Object.keys(G);
  var index = {};
  for (var i = 0; i < chars.length; i++) index[chars[i]] = i;
  var atlasCache = {};

  /** Атлас глифов для заданного цвета (кэшируется) */
  function atlas(color) {
    if (atlasCache[color]) return atlasCache[color];
    var c = TH.makeCanvas(chars.length * 6, 7);
    var g = c.getContext('2d');
    g.fillStyle = color;
    for (var i = 0; i < chars.length; i++) {
      var rows = G[chars[i]];
      for (var y = 0; y < 7; y++) for (var x = 0; x < 5; x++) {
        if (rows[y] & (16 >> x)) g.fillRect(i * 6 + x, y, 1, 1);
      }
    }
    atlasCache[color] = c;
    return c;
  }

  function measure(str, scale) { return str.length * 6 * (scale || 1) - (scale || 1); }

  /**
   * Рисует строку. opts: {scale, shadow (цвет тени), align: 'left'|'center'|'right'}
   */
  function draw(ctx, str, x, y, color, opts) {
    opts = opts || {};
    var s = opts.scale || 1;
    str = String(str).toUpperCase();
    var w = measure(str, s);
    if (opts.align === 'center') x -= Math.floor(w / 2);
    else if (opts.align === 'right') x -= w;
    x = Math.round(x); y = Math.round(y);
    if (opts.shadow) drawRaw(ctx, str, x + s, y + s, opts.shadow, s);
    if (opts.outline) {
      drawRaw(ctx, str, x - s, y, opts.outline, s); drawRaw(ctx, str, x + s, y, opts.outline, s);
      drawRaw(ctx, str, x, y - s, opts.outline, s); drawRaw(ctx, str, x, y + s, opts.outline, s);
    }
    drawRaw(ctx, str, x, y, color, s);
    return w;
  }
  function drawRaw(ctx, str, x, y, color, s) {
    var a = atlas(color);
    for (var i = 0; i < str.length; i++) {
      var gi = index[str[i]];
      if (gi === undefined) gi = index['?'];
      ctx.drawImage(a, gi * 6, 0, 5, 7, x + i * 6 * s, y, 5 * s, 7 * s);
    }
  }
  return { draw: draw, measure: measure, glyphs: G };
})();
