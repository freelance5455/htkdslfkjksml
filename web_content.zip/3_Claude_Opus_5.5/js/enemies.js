/* ==========================================================================
   enemies.js — бадники (жук, оса, краб, рыба), снаряды и спасённые зверьки
   ========================================================================== */
'use strict';

/* =============================== БАДНИК =============================== */
TH.Obj.enemy = function (d, game) {
  this.kind = d.kind; this.x = d.x; this.y = d.y; this.ox = d.x; this.oy = d.y;
  this.range = d.range || 80; this.facing = -1; this.t = 0; this.wait = 0; this.cool = 60;
  this.vy = 0; this.state = 'move';
  // Хитбоксы (полуразмеры) и центр относительно точки x,y
  switch (this.kind) {
    case 'beetle': this.hw = 14; this.hh = 11; this.cyOff = -12; break;
    case 'wasp': this.hw = 14; this.hh = 8; this.cyOff = 0; break;
    case 'crab': this.hw = 15; this.hh = 9; this.cyOff = -10; break;
    case 'fish': this.hw = 9; this.hh = 11; this.cyOff = 0; this.timer = 60 + Math.floor(Math.random() * 60); this.y = this.oy + 30; this.state = 'under'; break;
  }
};
TH.Obj.enemy.prototype = {
  update: function (game) {
    var p = game.player;
    // Активны только рядом с экраном
    if (Math.abs(this.x - game.camera.x - TH.W / 2) > TH.W) return;
    this.t++;
    var T = game.terrain;
    switch (this.kind) {
      case 'beetle': this.beetle(game, T); break;
      case 'wasp': this.wasp(game, p); break;
      case 'crab': this.crab(game, T, p); break;
      case 'fish': this.fish(game); break;
    }
    // Столкновение с героем
    if (p.dead || (this.kind === 'fish' && this.state === 'under')) return;
    var cy = this.y + this.cyOff;
    var hb = p.hitbox();
    if (TH.rectsOverlap(hb[0], hb[1], hb[2], hb[3], this.x - this.hw, cy - this.hh, this.x + this.hw, cy + this.hh)) {
      if (p.isAttacking()) this.destroy(game);
      else game.hurtPlayer(this.x);
    }
  },
  /** Жук патрулирует, следуя рельефу; разворачивается у края, стены или границы участка */
  beetle: function (game, T) {
    if (this.wait > 0) { this.wait--; if (this.wait === 0) this.facing = -this.facing; return; }
    var nx = this.x + this.facing * 0.8;
    var d = T.sensor(nx, this.y - 12, 0, 0, true, 28);
    var wall = T.solid(nx + this.facing * 14, this.y - 10, 0, false);
    if (d === null || Math.abs(T.hy - this.y) > 10 || wall || Math.abs(nx - this.ox) > this.range) { this.wait = 40; return; }
    this.x = nx; this.y = T.hy;
    if (this.t % 10 === 0) game.particles.add({ k: 'smoke', x: this.x - this.facing * 16, y: this.y - 8, vx: -this.facing * 0.3, vy: -0.4, life: 20, r: 2 });
  },
  /** Оса летает туда-сюда; заметив героя — зависает и стреляет */
  wasp: function (game, p) {
    var dx = p.x - this.x;
    if (this.state === 'move') {
      this.x += this.facing * 1.2;
      this.y = this.oy + Math.sin(this.t * 0.06) * 6;
      if (Math.abs(this.x - this.ox) > 90) { this.facing = -this.facing; this.x = this.ox + TH.sign(this.x - this.ox) * 90; }
      if (this.cool > 0) this.cool--;
      if (this.cool <= 0 && Math.abs(dx) < 130 && Math.abs(dx) > 24 && p.y > this.y - 20 && !p.dead) {
        this.facing = TH.sign(dx) || 1; this.state = 'aim'; this.wait = 40;
      }
    } else if (this.state === 'aim') {
      this.wait--;
      if (this.wait === 20) {
        var ang = Math.atan2(p.y - this.y, p.x - this.x);
        ang = TH.clamp(ang, 0.35, Math.PI - 0.35);
        game.spawn(new TH.Projectile(this.x - this.facing * 10, this.y + 8, Math.cos(ang) * 2, Math.sin(ang) * 2, 0));
        TH.Audio.play('shoot');
      }
      if (this.wait <= 0) { this.state = 'move'; this.cool = 150; }
    }
  },
  /** Краб ходит, останавливается и стреляет вверх двумя снарядами по дуге */
  crab: function (game, T, p) {
    if (this.state === 'move') {
      var nx = this.x + this.facing * 0.5;
      var d = T.sensor(nx, this.y - 12, 0, 0, true, 28);
      if (d === null || Math.abs(T.hy - this.y) > 10 || Math.abs(nx - this.ox) > this.range) this.facing = -this.facing;
      else { this.x = nx; this.y = T.hy; }
      if (this.t % 150 === 0) { this.state = 'fire'; this.wait = 50; }
    } else {
      this.wait--;
      if (this.wait === 25) {
        game.spawn(new TH.Projectile(this.x - 16, this.y - 26, -1.4, -4.4, 0.12));
        game.spawn(new TH.Projectile(this.x + 16, this.y - 26, 1.4, -4.4, 0.12));
        TH.Audio.play('shoot');
      }
      if (this.wait <= 0) this.state = 'move';
    }
  },
  /** Рыба выпрыгивает из воды */
  fish: function (game) {
    if (this.state === 'under') {
      if (--this.timer <= 0) { this.state = 'jump'; this.y = this.oy + 8; this.vy = -7.2; game.particles.splash(this.x, this.oy); TH.Audio.play('splash'); }
      return;
    }
    this.y += this.vy; this.vy += 0.16;
    if (this.vy > 0 && this.y > this.oy + 10) {
      this.state = 'under'; this.timer = 90; this.y = this.oy + 30;
      game.particles.splash(this.x, this.oy);
    }
  },
  destroy: function (game) {
    this.alive = false;
    var p = game.player, cy = this.y + this.cyOff;
    TH.Audio.play('pop');
    game.particles.explosion(this.x, cy, false);
    game.chainKill(this.x, cy - 10, false);
    // Отскок героя
    if (!p.ground) {
      if (p.y < cy && p.ysp > 0) p.ysp = -p.ysp;
      else if (p.ysp < 0) p.ysp += 1;   // снизу — слегка гасим подъём
    }
    // Освобождаем зверька
    game.spawn(new TH.Animal(this.x, cy, Math.floor(Math.random() * 3), 0, false));
    game.animalsSaved++;
    TH.Audio.play('animal');
  },
  draw: function (g, cx, cy, game) {
    var x = this.x - cx, y = this.y - cy;
    if (x < -40 || x > TH.W + 40) return;
    var S = TH.Sprites;
    switch (this.kind) {
      case 'beetle': S.beetle(g, x, y - 13, this.facing, this.t); break;
      case 'wasp': S.wasp(g, x, y, this.facing, this.t, this.state === 'aim'); break;
      case 'crab': S.crab(g, x, y - 10, this.facing, this.t, this.state === 'fire' && this.wait < 30); break;
      case 'fish': if (this.state !== 'under') S.fish(g, x, y, 1, this.t, this.vy < 0); break;
    }
  }
};

/* =============================== СНАРЯД =============================== */
TH.Projectile = function (x, y, vx, vy, grav) {
  this.x = x; this.y = y; this.vx = vx; this.vy = vy; this.g = grav || 0; this.t = 0; this.alive = true; this.dyn = true;
};
TH.Projectile.prototype = {
  update: function (game) {
    this.t++;
    this.x += this.vx; this.y += this.vy; this.vy += this.g;
    if (this.t > 240 || game.terrain.solidAny(this.x, this.y)) { this.alive = false; return; }
    var p = game.player, hb = p.hitbox();
    if (!p.dead && TH.rectsOverlap(hb[0], hb[1], hb[2], hb[3], this.x - 3, this.y - 3, this.x + 3, this.y + 3)) {
      if (p.shield) { this.vx = -this.vx; this.vy = -Math.abs(this.vy) - 2; return; } // щит отражает
      game.hurtPlayer(this.x);
      this.alive = false;
    }
  },
  draw: function (g, cx, cy, game) {
    var x = this.x - cx, y = this.y - cy;
    TH.Sprites.ell(g, x, y, 3.5, 3.5, (game.frame >> 2) % 2 ? '#ff6020' : '#ffe040', '#600');
  }
};

/* =============================== ЗВЕРЁК =============================== */
TH.Animal = function (x, y, kind, delay, fromCapsule) {
  this.x = x; this.y = y; this.kind = kind; this.delay = delay || 0; this.alive = true; this.dyn = true;
  this.vx = 0; this.vy = -4; this.t = 0; this.state = 'pop';
  this.facing = Math.random() < 0.5 ? -1 : 1;
  this.fromCapsule = fromCapsule; this.hearted = false;
};
TH.Animal.prototype = {
  update: function (game) {
    if (this.delay > 0) { this.delay--; return; }
    this.t++;
    if (!this.hearted) { this.hearted = true; game.particles.heart(this.x, this.y - 12); game.particles.sparkle(this.x, this.y, 3); }
    var T = game.terrain;
    this.x += this.vx; this.y += this.vy;
    if (this.kind === 0 && this.state === 'run') {
      // Птичка улетает, взмахивая крыльями
      this.vy += 0.09; if (this.vy > 1) this.vy = -1.6;
    } else this.vy += 0.21875;
    if (this.vy > 0 && (T.solidAny(this.x, this.y + 6, true) || game.objectFloorAt(this.x, this.y + 6 - this.vy, this.y + 6))) {
      while (T.solidAny(this.x, this.y + 5, true)) this.y--;
      if (this.state === 'pop') { this.state = 'run'; }
      this.vx = this.facing * (this.kind === 1 ? 2.5 : 2);
      this.vy = this.kind === 1 ? -4 : -3;
    }
    if (T.solidAny(this.x + this.facing * 6, this.y - 2)) { this.facing = -this.facing; this.vx = -this.vx; }
    if (this.t > 600 || this.y > game.level.H + 40) this.alive = false;
    if (this.t > 200 && Math.abs(this.x - game.camera.x - TH.W / 2) > TH.W) this.alive = false;
  },
  draw: function (g, cx, cy, game) {
    if (this.delay > 0) return;
    TH.Sprites.animal(g, this.x - cx, this.y - cy, this.kind, this.facing, this.t, this.vy < 0);
  }
};
