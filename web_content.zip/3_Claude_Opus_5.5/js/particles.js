/* ==========================================================================
   particles.js — частицы: пыль, искры, взрывы, обломки, брызги, сердечки, очки
   ========================================================================== */
'use strict';

TH.Particles = function () { this.list = []; };
TH.Particles.prototype = {
  add: function (p) {
    p.t = 0; p.vx = p.vx || 0; p.vy = p.vy || 0; p.g = p.g || 0; p.life = p.life || 30;
    if (this.list.length < 600) this.list.push(p);
    return p;
  },
  dust: function (x, y, dir) {
    this.add({ k: 'dust', x: x, y: y, vx: -dir * TH.rand(0.3, 1.2), vy: -TH.rand(0.2, 0.8), life: 18, r: TH.rand(2, 4) });
  },
  sparkle: function (x, y, n) {
    for (var i = 0; i < (n || 4); i++) this.add({ k: 'spark', x: x + TH.rand(-6, 6), y: y + TH.rand(-6, 6), vx: TH.rand(-0.6, 0.6), vy: TH.rand(-0.6, 0.6), life: 16 + i * 2 });
  },
  explosion: function (x, y, big) {
    var n = big ? 10 : 5;
    for (var i = 0; i < n; i++) {
      var a = Math.random() * Math.PI * 2, s = TH.rand(0.3, big ? 2.4 : 1.5);
      this.add({ k: 'puff', x: x, y: y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: TH.irand(18, 30), r: TH.rand(5, big ? 13 : 9), delay: i });
    }
    this.add({ k: 'flash', x: x, y: y, life: 8, r: big ? 26 : 16 });
  },
  debris: function (x, y, col, n) {
    for (var i = 0; i < (n || 6); i++) this.add({ k: 'debris', x: x, y: y, vx: TH.rand(-2.5, 2.5), vy: TH.rand(-5, -1.5), g: 0.2, life: 60, col: col || '#888', s: TH.irand(2, 5), rot: Math.random() * 6 });
  },
  splash: function (x, y) {
    for (var i = 0; i < 14; i++) this.add({ k: 'drop', x: x + TH.rand(-8, 8), y: y, vx: TH.rand(-1.6, 1.6), vy: TH.rand(-5, -1.5), g: 0.22, life: 50 });
  },
  heart: function (x, y) { this.add({ k: 'heart', x: x, y: y, vy: -0.6, life: 50 }); },
  score: function (x, y, v) { this.add({ k: 'score', x: x, y: y, vy: -1.5, life: 50, v: v }); },
  smoke: function (x, y) { this.add({ k: 'smoke', x: x, y: y, vx: TH.rand(-0.3, 0.3), vy: -TH.rand(0.4, 1), life: 40, r: TH.rand(3, 6) }); },
  speedLine: function (x, y, dir) { this.add({ k: 'line', x: x, y: y, vx: -dir * 2, life: 10, len: TH.rand(8, 18) }); },

  update: function () {
    var L = this.list, j = 0;
    for (var i = 0; i < L.length; i++) {
      var p = L[i];
      if (p.delay) { p.delay--; L[j++] = p; continue; }
      p.t++;
      p.x += p.vx; p.y += p.vy; p.vy += p.g;
      if (p.k === 'score') p.vy *= 0.93;
      if (p.t < p.life) L[j++] = p;
    }
    L.length = j;
  },
  draw: function (g, cx, cy) {
    var L = this.list, S = TH.Sprites;
    for (var i = 0; i < L.length; i++) {
      var p = L[i];
      if (p.delay) continue;
      var x = p.x - cx, y = p.y - cy, f = p.t / p.life;
      if (x < -40 || x > TH.W + 40 || y < -40 || y > TH.H + 40) continue;
      switch (p.k) {
        case 'dust':
          S.ell(g, x, y, p.r * (1 + f), p.r * (1 + f), 'rgba(240,230,210,' + (0.8 * (1 - f)) + ')');
          break;
        case 'spark':
          g.fillStyle = (p.t >> 1) % 2 ? '#fff' : '#ffe860';
          var s = 3 * (1 - f) + 1;
          g.fillRect(x - s, y - 0.5, s * 2, 1); g.fillRect(x - 0.5, y - s, 1, s * 2);
          break;
        case 'puff':
          var col = f < 0.25 ? '#fff6c0' : f < 0.5 ? '#ffb030' : f < 0.75 ? '#e05010' : '#704030';
          S.ell(g, x, y, p.r * (0.6 + f * 0.6), p.r * (0.6 + f * 0.6), col);
          break;
        case 'flash':
          S.ell(g, x, y, p.r * (1 - f), p.r * (1 - f), 'rgba(255,255,255,' + (1 - f) + ')');
          break;
        case 'debris':
          g.save(); g.translate(x, y); g.rotate(p.rot + p.t * 0.2);
          g.fillStyle = p.col; g.fillRect(-p.s / 2, -p.s / 2, p.s, p.s); g.restore();
          break;
        case 'drop':
          g.fillStyle = 'rgba(200,235,255,.9)'; g.fillRect(x - 1, y - 1, 2, 3);
          break;
        case 'heart':
          g.fillStyle = (p.t >> 2) % 2 ? '#ff4070' : '#ff90b0';
          g.beginPath(); g.moveTo(x, y + 3); g.bezierCurveTo(x - 5, y - 1, x - 2, y - 5, x, y - 2); g.bezierCurveTo(x + 2, y - 5, x + 5, y - 1, x, y + 3); g.fill();
          break;
        case 'score':
          TH.Font.draw(g, String(p.v), x, y, '#fff', { align: 'center', shadow: '#000' });
          break;
        case 'smoke':
          S.ell(g, x, y, p.r * (1 + f), p.r * (1 + f), 'rgba(90,90,100,' + (0.6 * (1 - f)) + ')');
          break;
        case 'line':
          g.fillStyle = 'rgba(255,255,255,' + (0.6 * (1 - f)) + ')'; g.fillRect(x, y, p.len, 1);
          break;
      }
    }
  }
};
