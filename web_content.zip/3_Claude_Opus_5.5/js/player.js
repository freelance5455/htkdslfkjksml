/* ==========================================================================
   player.js — герой: физика в духе 16-битной классики
   • Скорость по поверхности (gsp) + угол поверхности (angle) → xsp/ysp.
   • Режимы: пол / правая стена / потолок / левая стена (по углу).
   • Сенсоры A/B («лучи от ступней») в системе координат режима.
   • Склоны, перекат, spin dash, прыжок перпендикулярно поверхности.
   • Переключение слоёв коллизий для петель, «езда» по штопору.
   Угол: касательная = (cos a, sin a) в экранных координатах (y вниз).
   ========================================================================== */
'use strict';

TH.Player = function (game) {
  this.game = game;
  this.reset(0, 0);
};

TH.Player.prototype = {
  reset: function (x, y) {
    this.x = x; this.y = y;
    this.xsp = 0; this.ysp = 0; this.gsp = 0;
    this.angle = 0; this.mode = 0; this.layer = 0;
    this.ground = true; this.groundObj = null;
    this.state = 'normal';
    this.hr = 19; this.wr = 9;
    this.facing = 1;
    this.spinrev = 0; this.controlLock = 0;
    this.invuln = 0; this.invincible = 0; this.shoes = 0; this.shield = false;
    this.dead = false; this.deadT = 0; this.hurtTimer = 0;
    this.t = 0; this.phase = 0; this.idleT = 0; this.lookT = 0; this.pushing = 0;
    this.chain = 0; this.drawAngle = 0; this.cork = null; this.balance = 0;
    this.inWater = false; this.skidDust = 0; this.camLag = 0;
    this.jumpHeldFrames = 0;
  },
  get ball() { return this.state === 'jump' || this.state === 'roll' || this.state === 'spindash'; },
  isAttacking: function () { return this.ball || this.invincible > 0; },
  hitbox: function () {
    var h = this.hr - 3;
    return [this.x - 8, this.y - h, this.x + 8, this.y + h];
  },
  phys: function () {
    var P = TH.CONFIG.PHYS;
    if (this.shoes > 0) return { acc: P.shoesAcc, top: P.shoesTop, frc: P.shoesFrc, air: P.shoesAir };
    return { acc: P.acc, top: P.top, frc: P.frc, air: P.air };
  },

  /** Смена состояния с изменением радиуса (ступни остаются на месте, если на земле) */
  setState: function (s) {
    var wasBall = this.ball;
    this.state = s;
    var isBall = this.ball;
    if (wasBall === isBall) return;
    var newHr = isBall ? 14 : 19, d = this.hr - newHr;
    if (this.ground && !this.groundObj) {
      this.x += TH.DX[this.mode] * d; this.y += TH.DY[this.mode] * d;
    } else if (this.groundObj) {
      this.y += d;
    }
    this.hr = newHr; this.wr = isBall ? 7 : 9;
  },

  /* ============================ ГЛАВНЫЙ ШАГ ============================ */
  update: function (inp) {
    var P = TH.CONFIG.PHYS;
    this.t++;
    if (this.invuln > 0) this.invuln--;
    if (this.invincible > 0) this.invincible--;
    if (this.shoes > 0) this.shoes--;
    if (this.pushing > 0) this.pushing--;
    if (this.dead) { this.updateDead(); return; }

    if (this.state === 'hurt') this.updateHurt();
    else if (this.ground) this.updateGround(inp);
    else this.updateAir(inp);

    this.updateLoops();
    this.updateCork();
    this.updateWater();
    this.updateAnim(inp);
    // Падение в пропасть
    if (this.y > this.game.level.H + 24) this.die(true);
  },

  /* ---------------------------- НА ЗЕМЛЕ ---------------------------- */
  updateGround: function (inp) {
    var P = TH.CONFIG.PHYS, ph = this.phys(), T = this.game.terrain;
    var L = inp.held.left, R = inp.held.right, D = inp.held.down, U = inp.held.up;
    if (this.groundObj) { this.angle = 0; this.mode = 0; }

    // --- Spin dash: накрутка и рывок
    if (this.state === 'spindash') {
      if (inp.pressed.jump) {
        this.spinrev = Math.min(this.spinrev + 2, 8);
        TH.Audio.play('charge', this.spinrev);
        this.game.particles.dust(this.x - this.facing * 10, this.y + this.hr - 2, this.facing);
      }
      this.spinrev -= Math.floor(this.spinrev / 0.125) / 256;
      if (this.t % 3 === 0) this.game.particles.dust(this.x - this.facing * 12, this.y + this.hr - 1, this.facing);
      if (!D) {
        this.gsp = (8 + Math.floor(this.spinrev) / 2) * this.facing;
        if (this.shoes > 0) this.gsp *= 1.15;
        this.setState('roll');
        this.camLag = 16;
        TH.Audio.play('release');
      } else { this.gsp = 0; this.groundCheck(); return; }
    }
    // --- Присед → spin dash
    if (this.state === 'crouch' && inp.pressed.jump) {
      this.setState('spindash'); this.spinrev = 0;
      TH.Audio.play('charge', 0);
      this.groundCheck();
      return;
    }
    // --- Прыжок (перпендикулярно поверхности)
    if (inp.pressed.jump && this.state !== 'crouch') {
      this.jump();
      this.x += this.xsp; this.y += this.ysp;
      return;
    }
    // --- Фактор склона
    if (!this.groundObj) {
      var s = Math.sin(this.angle);
      if (this.state === 'roll') {
        var downhill = TH.sign(this.gsp) === TH.sign(s);
        this.gsp += (downhill ? P.slpRollDown : P.slpRollUp) * s;
      } else if (this.gsp !== 0 || Math.abs(s) > 0.33) {
        this.gsp += P.slp * s;
      }
    }
    var lock = this.controlLock > 0;
    if (lock) this.controlLock--;
    // --- Управление
    if (this.state === 'roll') {
      if (!lock) {
        if (L && this.gsp > 0) this.gsp = Math.max(0, this.gsp - P.rollDec);
        if (R && this.gsp < 0) this.gsp = Math.min(0, this.gsp + P.rollDec);
      }
      this.gsp -= Math.min(Math.abs(this.gsp), P.rollFrc) * TH.sign(this.gsp);
      if (Math.abs(this.gsp) < 0.5) { this.setState('normal'); }
    } else {
      var moving = false;
      if (this.state === 'crouch' || this.state === 'lookup') { L = R = false; }
      if (!lock && L && !R) {
        moving = true;
        if (this.gsp > 0) {
          this.gsp -= P.dec;
          if (this.gsp <= 0) this.gsp = -0.5;
          this.startSkid(1);
        } else if (this.gsp > -ph.top) {
          this.gsp -= ph.acc; if (this.gsp < -ph.top) this.gsp = -ph.top;
        }
        if (this.gsp <= 0) this.facing = -1;
      } else if (!lock && R && !L) {
        moving = true;
        if (this.gsp < 0) {
          this.gsp += P.dec;
          if (this.gsp >= 0) this.gsp = 0.5;
          this.startSkid(-1);
        } else if (this.gsp < ph.top) {
          this.gsp += ph.acc; if (this.gsp > ph.top) this.gsp = ph.top;
        }
        if (this.gsp >= 0) this.facing = 1;
      }
      if (!moving) this.gsp -= Math.min(Math.abs(this.gsp), ph.frc) * TH.sign(this.gsp);
      // Торможение (skid) заканчивается при развороте или отпускании
      if (this.state === 'skid') {
        if (!((L && this.gsp > 0) || (R && this.gsp < 0)) || Math.abs(this.gsp) < 0.6) this.state = 'normal';
        else if (this.t % 4 === 0) this.game.particles.dust(this.x + TH.sign(this.gsp) * 4, this.y + this.hr - 2, -TH.sign(this.gsp));
      }
      // Присед / перекат / взгляд вверх
      if (D && !L && !R && this.state !== 'skid') {
        if (Math.abs(this.gsp) >= 1) { this.setState('roll'); TH.Audio.play('roll'); }
        else if (this.mode === 0 && Math.abs(this.angle) < 0.6) { if (this.state !== 'crouch') this.setState('crouch'); }
      } else if (this.state === 'crouch') this.state = 'normal';
      if (U && Math.abs(this.gsp) < 0.05 && this.state === 'normal') this.state = 'lookup';
      else if (this.state === 'lookup' && (!U || Math.abs(this.gsp) >= 0.05)) this.state = 'normal';
    }
    this.gsp = TH.clamp(this.gsp, -P.maxGsp, P.maxGsp);

    // --- Перемещение
    this.xsp = this.gsp * Math.cos(this.angle);
    this.ysp = this.gsp * Math.sin(this.angle);
    this.groundWalls();
    this.x += this.xsp; this.y += this.ysp;
    if (!this.groundObj) this.groundCheck();

    // --- Отрыв от стен/потолка при малой скорости, соскальзывание с крутизны
    if (this.ground && !this.groundObj && Math.abs(this.gsp) < P.fallSpeed) {
      var deg = Math.abs(this.angle) * 180 / Math.PI;
      if (deg > 67) { this.detach(); this.controlLock = 30; }        // стена/потолок — отрыв
      else if (deg > 46 && this.controlLock === 0) this.controlLock = 30; // крутой склон — соскальзывание
    }
  },

  startSkid: function (dir) {
    if (this.state === 'normal' && this.mode === 0 && Math.abs(this.gsp) >= 4 && !this.groundObj) {
      this.state = 'skid';
      TH.Audio.play('skid');
    }
  },

  /** Боковые сенсоры на земле (в системе координат режима) */
  groundWalls: function () {
    if (this.gsp === 0) return;
    var T = this.game.terrain, m = this.mode;
    var fdir = this.gsp > 0 ? (m + 1) % 4 : (m + 3) % 4;
    var ox = this.x + this.xsp, oy = this.y + this.ysp;
    if (m === 0 && Math.abs(this.angle) < 0.05 && !this.groundObj) oy += 8;
    var d = T.sensor(ox, oy, fdir, this.layer, false, 16);
    if (d === null || d > 12) return;
    // Ограничиваем перемещение по дробным координатам (без дрожания у стены)
    var wx = T.hx, wy = T.hy, hit = false, lim;
    if (fdir === 1) { lim = wx - 11 - this.x; if (this.xsp > lim) { this.xsp = lim; hit = true; } }
    else if (fdir === 3) { lim = wx + 11 - this.x; if (this.xsp < lim) { this.xsp = lim; hit = true; } }
    else if (fdir === 0) { lim = wy - 11 - this.y; if (this.ysp > lim) { this.ysp = lim; hit = true; } }
    else { lim = wy + 11 - this.y; if (this.ysp < lim) { this.ysp = lim; hit = true; } }
    if (hit) {
      this.gsp = 0;
      this.pushing = 3;
      if (this.state === 'roll') this.setState('normal');
    }
  },

  /** Сенсоры A/B под ступнями: прилипание к поверхности и расчёт угла */
  groundCheck: function () {
    var T = this.game.terrain, m = this.mode;
    var dx = TH.DX[m], dy = TH.DY[m], tx = TH.TX[m], ty = TH.TY[m];
    var best = null, bx = 0, by = 0, miss = 0;
    for (var s = -1; s <= 1; s += 2) {
      var ox = this.x + tx * this.wr * s + dx * this.hr;
      var oy = this.y + ty * this.wr * s + dy * this.hr;
      var d = T.sensor(ox, oy, m, this.layer, m === 0, 32);
      if (d === null) { miss |= (s < 0 ? 1 : 2); continue; }
      if (d > 14) miss |= (s < 0 ? 1 : 2);
      if (best === null || d < best) { best = d; bx = T.hx; by = T.hy; }
    }
    var limit = Math.min(Math.abs(this.gsp) + 4, 14);
    if (best === null || best > limit) {
      this.detach();
      return;
    }
    this.x += dx * best; this.y += dy * best;
    var a = T.angleAt(bx, by, m, this.layer, m === 0);
    // Защита от резких скачков угла на стыках
    if (Math.abs(TH.angleDiff(this.angle, a)) > 1.2 && Math.abs(this.gsp) < 2) a = this.angle;
    this.angle = a;
    this.mode = T.modeFor(a);
    this.balance = (Math.abs(this.gsp) < 0.05 && m === 0) ? miss : 0;
  },

  detach: function () {
    this.ground = false; this.groundObj = null;
    this.xsp = this.gsp * Math.cos(this.angle);
    this.ysp = this.gsp * Math.sin(this.angle);
    this.mode = 0;
    if (this.state === 'normal' || this.state === 'skid' || this.state === 'crouch' || this.state === 'lookup') this.state = 'fall';
    if (this.state === 'spindash') this.setState('roll');
  },

  jump: function () {
    var P = TH.CONFIG.PHYS, a = this.angle;
    var j = P.jmp;
    this.xsp = this.gsp * Math.cos(a) + j * Math.sin(a);
    this.ysp = this.gsp * Math.sin(a) - j * Math.cos(a);
    this.ground = false; this.groundObj = null;
    var wasBall = this.ball;
    this.state = 'jump';
    if (!wasBall) { this.hr = 14; this.wr = 7; }
    this.mode = 0;
    this.chain = 0;
    TH.Audio.play('jump');
  },

  /* ---------------------------- В ВОЗДУХЕ ---------------------------- */
  updateAir: function (inp) {
    var P = TH.CONFIG.PHYS, ph = this.phys();
    // Короткий прыжок при отпускании кнопки
    if (this.state === 'jump' && !inp.held.jump && this.ysp < -P.jmpCut) this.ysp = -P.jmpCut;
    if (this.state === 'spring' && this.ysp >= 0) this.state = 'fall';
    var L = inp.held.left, R = inp.held.right;
    if (L && !R) { if (this.xsp > -ph.top) { this.xsp -= ph.air; if (this.xsp < -ph.top) this.xsp = -ph.top; } this.facing = -1; }
    if (R && !L) { if (this.xsp < ph.top) { this.xsp += ph.air; if (this.xsp > ph.top) this.xsp = ph.top; } this.facing = 1; }
    // Сопротивление воздуха у вершины прыжка
    if (this.ysp < 0 && this.ysp > -4) this.xsp -= Math.trunc(this.xsp / 0.125) / 256;
    this.x += this.xsp; this.y += this.ysp;
    this.ysp += P.grav;
    if (this.ysp > P.maxFall) this.ysp = P.maxFall;
    // Угол плавно возвращается к нулю
    this.angle = TH.approach(this.angle, 0, 0.08);
    this.airCollide();
  },

  updateHurt: function () {
    var P = TH.CONFIG.PHYS;
    this.hurtTimer++;
    this.x += this.xsp; this.y += this.ysp;
    this.ysp += P.hurtGrav;
    if (this.ysp > P.maxFall) this.ysp = P.maxFall;
    this.angle = 0;
    this.airCollide();
  },

  /** Коллизии в воздухе: стены, потолок, пол */
  airCollide: function () {
    var T = this.game.terrain, Ly = this.layer;
    var d = T.sensor(this.x, this.y, 1, Ly, false, 16);
    if (d !== null && this.x > T.hx - 11) { this.x = T.hx - 11; if (this.xsp > 0) this.xsp = 0; }
    d = T.sensor(this.x, this.y, 3, Ly, false, 16);
    if (d !== null && this.x < T.hx + 11) { this.x = T.hx + 11; if (this.xsp < 0) this.xsp = 0; }
    var s, best, bx, by;
    // Потолок
    if (this.ysp < 0) {
      best = null;
      for (s = -1; s <= 1; s += 2) {
        d = T.sensor(this.x + s * this.wr, this.y - this.hr, 2, Ly, false, 24);
        if (d !== null && (best === null || d < best)) { best = d; bx = T.hx; by = T.hy; }
      }
      if (best !== null && best <= 0) {
        var a = T.angleAt(bx, by, 2, Ly, false);
        var deg = Math.abs(a) * 180 / Math.PI;
        if (deg > 91 && deg < 135 && this.state !== 'hurt') {
          // Приземление на крутой потолок (продолжаем бег по поверхности)
          this.y -= best;
          this.angle = a; this.mode = this.game.terrain.modeFor(a);
          this.gsp = this.xsp * Math.cos(a) + this.ysp * Math.sin(a);
          this.landed();
        } else {
          this.y += 1 - best;
          if (this.ysp < 0) this.ysp = 0;
        }
      }
    }
    // Пол
    if (this.ysp >= 0) {
      best = null;
      for (s = -1; s <= 1; s += 2) {
        d = T.sensor(this.x + s * this.wr, this.y + this.hr, 0, Ly, true, 32);
        if (d !== null && (best === null || d < best)) { best = d; bx = T.hx; by = T.hy; }
      }
      if (best !== null && best <= 0 && best >= -(this.ysp + 8)) {
        this.y += best;
        var an = T.angleAt(bx, by, 0, Ly, true);
        if (Math.abs(an) > Math.PI / 2) an = 0;
        this.angle = an; this.mode = T.modeFor(an);
        var dg = Math.abs(an) * 180 / Math.PI, sn = Math.sin(an);
        if (this.state === 'hurt') this.gsp = 0;
        else if (dg < 23) this.gsp = this.xsp;
        else if (dg < 46) this.gsp = Math.abs(this.xsp) > Math.abs(this.ysp) ? this.xsp : this.ysp * 0.5 * TH.sign(sn);
        else this.gsp = Math.abs(this.xsp) > Math.abs(this.ysp) ? this.xsp : this.ysp * TH.sign(sn);
        this.landed();
      }
    }
  },

  /** Общая логика приземления */
  landed: function () {
    this.ground = true;
    this.chain = 0;
    if (this.state === 'hurt') {
      this.gsp = 0; this.xsp = 0; this.ysp = 0;
      this.invuln = TH.CONFIG.INVULN_FRAMES;
    }
    if (this.state !== 'normal') this.setState('normal');
    this.ysp = 0;
  },
  landObject: function (o, top) {
    this.groundObj = o;
    this.ground = true;
    this.angle = 0; this.mode = 0;
    if (this.state === 'hurt') { this.xsp = 0; this.invuln = TH.CONFIG.INVULN_FRAMES; }
    this.gsp = this.xsp;
    this.chain = 0;
    if (this.state !== 'normal' && this.state !== 'roll' && this.state !== 'spindash' && this.state !== 'crouch' && this.state !== 'skid' && this.state !== 'lookup') this.setState('normal');
    this.ysp = 0;
    this.y = top - this.hr;
  },
  leaveObject: function () {
    if (!this.groundObj) return;
    this.groundObj = null;
    if (this.ground) {
      this.ground = false;
      this.xsp = this.gsp;
      this.ysp = 0;
      if (this.state === 'normal' || this.state === 'skid' || this.state === 'crouch' || this.state === 'lookup') this.state = 'fall';
      if (this.state === 'spindash') this.setState('roll');
    }
  },

  /* ---------------------------- ВЗАИМОДЕЙСТВИЯ ---------------------------- */
  spring: function (power) {
    this.leaveObject();
    this.ground = false; this.groundObj = null;
    if (this.ball) { this.hr = 19; this.wr = 9; }
    this.state = 'spring';
    this.ysp = -power;
    this.angle = 0; this.mode = 0;
    this.chain = 0;
  },
  springSide: function (dir, power) {
    this.facing = dir;
    this.xsp = dir * power;
    this.gsp = dir * power;
    this.controlLock = 16;
    if (this.state === 'skid') this.state = 'normal';
  },
  hurt: function (srcX) {
    this.leaveObject();
    this.ground = false; this.groundObj = null;
    if (this.ball) { this.hr = 19; this.wr = 9; }
    this.state = 'hurt'; this.hurtTimer = 0;
    this.ysp = -4;
    this.xsp = (this.x < srcX ? -2 : 2);
    this.angle = 0; this.mode = 0;
  },
  die: function (pit) {
    if (this.dead) return;
    this.dead = true; this.deadT = 0;
    this.groundObj = null; this.ground = false;
    this.state = 'dead';
    this.shield = false; this.invincible = 0; this.shoes = 0;
    this.xsp = 0;
    this.ysp = pit ? 0 : -7;
    this.pit = !!pit;
    this.game.onPlayerDeath(pit);
  },
  updateDead: function () {
    this.deadT++;
    if (this.pit) return;
    this.y += this.ysp;
    this.ysp += TH.CONFIG.PHYS.grav;
  },

  /* ---------------------------- ПЕТЛИ, ШТОПОР, ВОДА ---------------------------- */
  updateLoops: function () {
    var loops = this.game.level.loops;
    for (var i = 0; i < loops.length; i++) {
      var Lp = loops[i];
      var ext = Lp.R + Lp.T;
      if (Math.abs(this.x - Lp.cx) > ext + 96 || this.y < Lp.cy - ext - 64 || this.y > Lp.floorY + 48) continue;
      // Вход/выход: слой определяется направлением движения
      if (this.x < Lp.cx - ext - 4 && this.x > Lp.cx - ext - 96) this.layer = (this.ground ? this.gsp : this.xsp) >= 0 ? 0 : 1;
      else if (this.x > Lp.cx + ext + 4 && this.x < Lp.cx + ext + 96) this.layer = (this.ground ? this.gsp : this.xsp) > 0 ? 0 : 1;
      // Верх петли: переключение при проходе центра
      if (this.y < Lp.cy && Math.abs(this.x - Lp.cx) < 16) {
        if (this.xsp < -0.5) this.layer = 1;
        else if (this.xsp > 0.5) this.layer = 0;
      }
    }
  },
  updateCork: function () {
    this.cork = null;
    if (!this.ground || this.groundObj || this.mode !== 0) return;
    var cs = this.game.level.corks;
    for (var i = 0; i < cs.length; i++) {
      var c = cs[i];
      if (this.x >= c.x0 && this.x <= c.x1 && Math.abs(this.y + this.hr - c.y) < 6 && Math.abs(this.gsp) >= 3.5) {
        this.cork = { t: (this.x - c.x0) / (c.x1 - c.x0), h: c.h };
      }
    }
  },
  updateWater: function () {
    var ws = this.game.level.water, inW = false;
    for (var i = 0; i < ws.length; i++) {
      var w = ws[i];
      if (this.x > w.x0 && this.x < w.x1 && this.y > w.y) {
        inW = true;
        if (!this.inWater) { this.game.particles.splash(this.x, w.y); TH.Audio.play('splash'); }
        this.xsp *= 0.94;
        if (this.ysp > 1.5) this.ysp = 1.5;
        if (this.y > w.y + 48) this.die(true);
      }
    }
    this.inWater = inW;
  },

  /* ---------------------------- АНИМАЦИЯ ---------------------------- */
  updateAnim: function (inp) {
    var sp = Math.abs(this.gsp);
    if (this.ground && sp < 0.05 && this.state === 'normal' && !inp.held.left && !inp.held.right) this.idleT++;
    else this.idleT = 0;
    if (this.ball) this.phase += (this.ground ? Math.max(0.25, sp * 0.09) : 0.45) * (this.facing);
    else this.phase += this.ground ? 0.08 + sp * 0.1 : 0.2;
    // Плавный поворот спрайта по углу поверхности
    var target = (this.ground && !this.ball) ? this.angle : 0;
    if (this.ground && !this.ball && Math.abs(this.angle) < 0.12 && sp < 1) target = 0;
    var k = this.ground ? 0.4 : 0.15;
    this.drawAngle = TH.wrapAngle(this.drawAngle + TH.angleDiff(this.drawAngle, target) * k);
    // Эффект скорости
    if (this.ground && sp > 9 && this.t % 3 === 0) this.game.particles.speedLine(this.x - this.facing * 20, this.y + TH.rand(-12, 12), TH.sign(this.gsp));
    if (this.lookT !== undefined) {
      if (this.state === 'lookup') this.lookT++;
      else if (this.state === 'crouch') this.lookT--;
      else this.lookT = 0;
    }
  },
  pose: function () {
    if (this.dead) return 'dead';
    if (this.state === 'hurt') return 'hurt';
    if (this.state === 'spindash') return 'spindash';
    if (this.ball) return 'ball';
    if (!this.ground) return this.state === 'spring' && this.ysp < 0 ? 'spring' : 'fall';
    if (this.state === 'skid') return 'skid';
    if (this.state === 'crouch') return 'crouch';
    if (this.state === 'lookup') return 'lookup';
    var sp = Math.abs(this.gsp);
    if (sp < 0.05) {
      if (this.balance === 1 || this.balance === 2) return 'balance';
      if (this.idleT > 200) return 'wait';
      return 'stand';
    }
    if (this.pushing > 0 && sp < 1) return 'push';
    return sp >= 5.8 ? 'run' : 'walk';
  },
  draw: function (g, cx, cy) {
    if (this.invuln > 0 && !this.dead && (this.t >> 1) % 2) return;
    var pose = this.pose();
    var x = this.x - cx, y = this.y - cy, ang = this.drawAngle, facing = this.facing;
    if (pose === 'balance') facing = this.balance === 2 ? 1 : -1;
    // Штопор: псевдо-3D смещение и вращение
    if (this.cork) {
      var t = this.cork.t;
      y -= this.cork.h * (1 - Math.cos(t * Math.PI * 2)) / 2;
      ang = (this.gsp > 0 ? 1 : -1) * t * Math.PI * 2;
    }
    TH.Sprites.hero(g, x, y, { pose: pose, t: this.t, facing: facing, angle: (pose === 'wait' || pose === 'dead' || this.ball) ? 0 : ang, phase: this.phase });
    // Щит
    if (this.shield) {
      var r = 21 + Math.sin(this.t * 0.2);
      g.globalAlpha = 0.45 + 0.15 * Math.sin(this.t * 0.3);
      TH.Sprites.ell(g, x, y, r, r, 'rgba(120,200,255,.35)', '#d0f4ff');
      g.globalAlpha = 1;
      TH.Sprites.ell(g, x - 8, y - 9, 4, 2.5, 'rgba(255,255,255,.7)');
    }
    // Неуязвимость — вращающиеся звёздочки
    if (this.invincible > 0) {
      for (var i = 0; i < 4; i++) {
        var a = this.t * 0.25 + i * Math.PI / 2, rr = 18 + Math.sin(this.t * 0.3 + i) * 3;
        g.fillStyle = ['#fff', '#ff0', '#0ff', '#f6f'][(i + (this.t >> 2)) % 4];
        TH.Sprites.star(g, x + Math.cos(a) * rr, y + Math.sin(a) * rr, 3.5, 1.5);
      }
    }
  }
};
