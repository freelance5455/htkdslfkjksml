/* ==========================================================================
   input.js — клавиатура, тач-кнопки (мультитач), геймпад, виртуальный ввод
   Состояние опрашивается один раз за шаг симуляции (60 Гц): held / pressed.
   ========================================================================== */
'use strict';

TH.Input = (function () {
  var ACTIONS = ['left', 'right', 'up', 'down', 'jump', 'start'];
  var KEYMAP = {
    ArrowLeft: 'left', KeyA: 'left',
    ArrowRight: 'right', KeyD: 'right',
    ArrowDown: 'down', KeyS: 'down',
    KeyW: 'up',                                    // смотреть вверх
    Space: 'jump', KeyZ: 'jump', KeyX: 'jump', KeyC: 'jump', ArrowUp: 'jump', KeyK: 'jump',
    Enter: 'start', NumpadEnter: 'start', Escape: 'start', KeyP: 'start'
  };

  var kb = {}, touch = {}, pad = {}, tapped = {};
  var prev = {};
  var state = { held: {}, pressed: {} };
  var virtual = {};               // для автотестов: window.game.input.virtual.right = true
  var hotkeys = [];               // колбэки для M / F2 и т.п. (не зависят от шага)

  function reset(o) { for (var i = 0; i < ACTIONS.length; i++) o[ACTIONS[i]] = false; }
  reset(kb); reset(touch); reset(pad); reset(tapped); reset(prev); reset(virtual);
  reset(state.held); reset(state.pressed);

  window.addEventListener('keydown', function (e) {
    var a = KEYMAP[e.code];
    if (a) {
      if (!kb[a]) tapped[a] = true;
      kb[a] = true;
      e.preventDefault();
    }
    if (!e.repeat) for (var i = 0; i < hotkeys.length; i++) hotkeys[i](e.code, e);
    if (TH.Audio) TH.Audio.unlock();
  });
  window.addEventListener('keyup', function (e) {
    var a = KEYMAP[e.code];
    if (a) { kb[a] = false; e.preventDefault(); }
  });
  window.addEventListener('blur', function () { reset(kb); reset(touch); });

  /* ---------- Тач: по каждому касанию определяем кнопку под пальцем ---------- */
  function setupTouch() {
    var layer = document.getElementById('touch');
    if (!layer) return;
    var isTouch = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0 && matchMedia('(pointer: coarse)').matches);
    if (isTouch) document.body.classList.add('touch');
    function update(e) {
      var now = {}; reset(now);
      for (var i = 0; i < e.touches.length; i++) {
        var t = e.touches[i];
        var el = document.elementFromPoint(t.clientX, t.clientY);
        var act = el && el.getAttribute && el.getAttribute('data-act');
        if (act) now[act] = true;
      }
      for (var k in now) {
        if (now[k] && !touch[k]) tapped[k] = true;
        touch[k] = now[k];
      }
      var btns = layer.querySelectorAll('.tbtn');
      for (var j = 0; j < btns.length; j++) btns[j].classList.toggle('on', !!now[btns[j].getAttribute('data-act')]);
      if (TH.Audio) TH.Audio.unlock();
    }
    ['touchstart', 'touchmove', 'touchend', 'touchcancel'].forEach(function (ev) {
      layer.addEventListener(ev, function (e) { e.preventDefault(); update(e); }, { passive: false });
    });
    // Касание по самому полю на стартовых экранах = START
    var cv = document.getElementById('game');
    cv.addEventListener('touchstart', function (e) {
      document.body.classList.add('touch');
      tapped.start = true;
      if (TH.Audio) TH.Audio.unlock();
      e.preventDefault();
    }, { passive: false });
    cv.addEventListener('mousedown', function () { if (TH.Audio) TH.Audio.unlock(); });
  }

  /* ---------- Геймпад ---------- */
  function pollPad() {
    reset(pad);
    var pads = navigator.getGamepads ? navigator.getGamepads() : [];
    for (var i = 0; i < pads.length; i++) {
      var p = pads[i];
      if (!p || !p.connected) continue;
      var b = p.buttons, ax = p.axes;
      var bp = function (n) { return b[n] && (b[n].pressed || b[n].value > 0.5); };
      if (bp(14) || ax[0] < -0.4) pad.left = true;
      if (bp(15) || ax[0] > 0.4) pad.right = true;
      if (bp(13) || ax[1] > 0.5) pad.down = true;
      if (bp(12) || ax[1] < -0.6) pad.up = true;
      if (bp(0) || bp(1) || bp(2) || bp(3)) pad.jump = true;
      if (bp(9) || bp(8)) pad.start = true;
    }
  }

  /** Вызывается в начале каждого шага симуляции */
  function update() {
    pollPad();
    for (var i = 0; i < ACTIONS.length; i++) {
      var a = ACTIONS[i];
      var h = kb[a] || touch[a] || pad[a] || virtual[a];
      state.pressed[a] = (h && !prev[a]) || tapped[a];
      state.held[a] = h || tapped[a];
      prev[a] = h;
      tapped[a] = false;
    }
  }

  return {
    state: state,
    virtual: virtual,
    update: update,
    setupTouch: setupTouch,
    onHotkey: function (fn) { hotkeys.push(fn); },
    held: function (a) { return state.held[a]; },
    pressed: function (a) { return state.pressed[a]; },
    /** Для тестов: «нажать» действие на один шаг */
    tap: function (a) { tapped[a] = true; }
  };
})();
