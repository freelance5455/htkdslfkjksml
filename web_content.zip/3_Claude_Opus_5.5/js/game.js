/* ==========================================================================
   game.js — главный цикл (фиксированный шаг 60 Гц с аккумулятором),
   состояния игры, правила (кольца, жизни, чекпоинты, Continue, итоги),
   масштабирование экрана, горячие клавиши. Состояние доступно как window.game.
   ========================================================================== */
'use strict';

TH.Game = function () {
  var self = this;
  this.canvas = document.getElementById('game');
  this.ctx = this.canvas.getContext('2d');
  this.ctx.imageSmoothingEnabled = false;

  this.act = TH.getSelectedAct ? TH.getSelectedAct() : 1;
  this.level = TH.buildAct ? TH.buildAct(this.act) : TH.buildPalmValley();
  this.terrain = this.level.terrain;
  this.renderer = new TH.Renderer(this.ctx, this.level);
  this.particles = new TH.Particles();
  this.camera = new TH.Camera(this.level);
  this.player = new TH.Player(this);
  this.input = TH.Input;
  this.objects = [];

  this.state = 'title'; this.t = 0; this.frame = 0;
  this.lives = TH.CONFIG.START_LIVES; this.score = 0; this.rings = 0; this.time = 0;
  this.animalsSaved = 0; this.checkpoint = null;
  this.debug = TH.CONFIG.DEBUG;
  this.paused = false;
  this.fps = 60; this._fpsN = 0; this._fpsT = performance.now();
  this.emptyInput = { held: { left: false, right: false, up: false, down: false, jump: false, start: false }, pressed: { left: false, right: false, up: false, down: false, jump: false, start: false } };

  TH.Input.setupTouch();
  TH.Input.onHotkey(function (code, e) {
    if (code === 'KeyM') self.toggleSound();
    if (code === 'KeyN') TH.Audio.toggleMusic();
    if (code === 'F2') { self.debug = !self.debug; e.preventDefault(); }
  });
  this.setupPage();
  window.addEventListener('resize', function () { self.resize(); });
  window.addEventListener('orientationchange', function () { setTimeout(function () { self.resize(); }, 200); });
  if (window.ResizeObserver) new ResizeObserver(function () { self.resize(); }).observe(document.getElementById('stage'));
  this.resize();

  // Тёплый старт: растеризуем начало уровня заранее
  this.terrain.prefetch(200, 1300, 400, 300);

  this.acc = 0; this.last = performance.now();
  requestAnimationFrame(function loop(now) { self.frameLoop(now); requestAnimationFrame(loop); });
  window.game = this;
};

TH.Game.prototype = {
  /* ======================== ЦИКЛ ======================== */
  frameLoop: function (now) {
    var dt = (now - this.last) / 1000;
    this.last = now;
    if (dt > 0.25) dt = 0.25;           // после сворачивания вкладки — не «догоняем» минуты
    this.acc += dt;
    var step = 1 / 60, n = 0;
    while (this.acc >= step && n < 6) { this.step(); this.acc -= step; n++; }
    if (n >= 6) this.acc = 0;
    this.render();
    this._fpsN++;
    if (now - this._fpsT >= 1000) { this.fps = this._fpsN; this._fpsN = 0; this._fpsT = now; }
  },

  step: function () {
    TH.Input.update();
    var inp = TH.Input.state;
    this.t++;
    switch (this.state) {
      case 'title':
        if (inp.pressed.start || inp.pressed.jump) { TH.Audio.unlock(); TH.Audio.play('select'); this.newGame(); }
        break;
      case 'play': this.stepPlay(inp); break;
      case 'continue':
        if (this.t % 60 === 1 && this.t > 1) TH.Audio.play('beep');
        if ((inp.pressed.start || inp.pressed.jump) && this.t > 20) { TH.Audio.play('select'); this.continueGame(); }
        else if (this.t >= 600) { this.state = 'gameover'; this.t = 0; TH.Audio.music.play('gameover'); }
        break;
      case 'gameover':
        if (this.t > 360 || (this.t > 90 && inp.pressed.start)) this.toTitle();
        break;
      case 'ending':
        this.frame++;
        this.particles.update();
        if (this.t > 60 && (inp.pressed.start || inp.pressed.jump)) this.toTitle();
        break;
    }
    document.getElementById('disclaimer').classList.toggle('show', this.state === 'title');
  },

  stepPlay: function (inp) {
    if (inp.pressed.start && !this.dying && !this.tally && this.cardT > 40) {
      this.paused = !this.paused;
      TH.Audio.play('beep');
    }
    if (this.paused) return;
    if (this.cardT < 170) this.cardT++;
    if (this.banner) { this.banner.t++; if (this.banner.t > this.banner.life) this.banner = null; }

    // Итоги акта
    if (this.tallyDelay > 0 && --this.tallyDelay === 0) this.startTally();
    if (this.tally) this.stepTally(inp);

    if (this.dying) {
      this.deathT++;
      // Замедление мира в начале потери жизни
      if (this.deathT < 70 && this.deathT % 2 === 0) this.worldStep(this.emptyInput);
      if (this.deathT === 100) { this.lives--; }
      if (this.deathT === 240) {
        if (this.lives > 0) this.startAct();
        else { this.state = 'continue'; this.t = 0; TH.Audio.music.play('continue'); }
      }
      return;
    }
    var useInp = (this.cardT < 50 || this.inputLocked) ? this.emptyInput : inp;
    this.worldStep(useInp);
  },

  worldStep: function (inp) {
    this.frame++;
    var p = this.player;
    if (!this.timeStopped && !this.dying) {
      this.time++;
      if (this.time >= TH.CONFIG.TIME_LIMIT && !p.dead) { this.deathReason = 'TIME OVER'; p.die(false); }
    }
    p.update(inp);
    // Объекты (только рядом с экраном, кроме «всегда активных»)
    var cx = this.camera.x + TH.W / 2;
    var objs = this.objects;
    for (var i = 0; i < objs.length; i++) {
      var o = objs[i];
      if (!o.alive) continue;
      if (o.alwaysActive || o.dyn || Math.abs(o.x - cx) < TH.W) o.update(this);
    }
    var j = 0;
    for (i = 0; i < objs.length; i++) if (objs[i].alive) objs[j++] = objs[i];
    objs.length = j;
    // На арене герой не может уйти за края экрана
    if (this.arenaLock && !p.dead) {
      var l = this.camera.minX + 14, r = this.camera.maxX + TH.W - 14;
      if (p.x < l) { p.x = l; if (p.xsp < 0) p.xsp = 0; if (p.gsp < 0 && p.ground) p.gsp = 0; }
      if (p.x > r) { p.x = r; if (p.xsp > 0) p.xsp = 0; if (p.gsp > 0 && p.ground) p.gsp = 0; }
    }
    this.camera.update(p);
    this.particles.update();
    // Музыка: окончание неуязвимости / кроссовок
    if (p.invincible === 1 && !this.bossActive) TH.Audio.music.play('level');
    if (p.shoes === 1) TH.Audio.music.setTempo(1);
    // Подгружаем коллизии впереди
    this.terrain.prefetch(this.camera.x + TH.W / 2 + TH.sign(p.xsp) * 300, this.camera.y + TH.H / 2, 420, 260);
  },

  /* ======================== ПРАВИЛА ======================== */
  newGame: function () {
    this.lives = TH.CONFIG.START_LIVES; this.score = 0; this.checkpoint = null;
    this.nextLifeAt = 100;
    this.startAct();
  },
  continueGame: function () {
    // Continue: в начало акта, очки и кольца обнуляются
    this.lives = TH.CONFIG.START_LIVES; this.score = 0; this.checkpoint = null;
    this.startAct();
  },
  toTitle: function () {
    this.state = 'title'; this.t = 0;
    TH.Audio.music.stop();
  },
  /** Старт акта / рестарт с чекпоинта */
  startAct: function () {
    this.act = TH.getSelectedAct ? TH.getSelectedAct() : (this.act || 1);
    if (TH.buildAct) { this.level = TH.buildAct(this.act); this.terrain = this.level.terrain; this.renderer = new TH.Renderer(this.ctx, this.level); this.camera = new TH.Camera(this.level); }
    this.state = 'play'; this.t = 0;
    this.rings = 0; this.nextLifeAt = 100;
    this.time = this.checkpoint ? this.checkpoint.time : 0;
    this.animalsSaved = this.checkpoint ? this.checkpoint.animals : 0;
    this.paused = false; this.dying = false; this.deathT = 0; this.deathReason = '';
    this.bossActive = false; this.bossDefeated = false; this.capsuleDone = false; this.boss = null; this.arenaLock = false;
    this.banner = null; this.tally = null; this.tallyDelay = 0; this.timeStopped = false; this.inputLocked = false;
    this.cardT = 0;
    this.particles.list.length = 0;
    // Объекты пересоздаются из описаний уровня
    this.objects = [];
    for (var i = 0; i < this.level.objects.length; i++) {
      var o = TH.makeObject(this.level.objects[i], this);
      if (o) this.objects.push(o);
    }
    for (i = 0; i < this.level.secrets.length; i++) this.level.secrets[i].alpha = 1;
    var p = this.player;
    var sx = this.checkpoint ? this.checkpoint.x : this.level.start.x;
    var sy = this.checkpoint ? this.checkpoint.y : this.level.start.y;
    p.reset(sx, sy);
    if (this.checkpoint) p.invuln = TH.CONFIG.INVULN_FRAMES;   // рестарт с неуязвимостью ~2 с
    this.camera.setBounds(0, this.level.W - TH.W, true);
    this.camera.fixY = null;
    this.camera.snap(p);
    this.terrain.prefetch(sx, sy, 500, 300);
    TH.Audio.music.setTempo(1);
    TH.Audio.music.play('level');
  },
  spawn: function (o) { if (o.alive === undefined) o.alive = true; this.objects.push(o); return o; },
  /** Есть ли пол объекта (мост, платформа, монитор) между yPrev и yNext в точке x */
  objectFloorAt: function (x, yPrev, yNext) {
    for (var i = 0; i < this.objects.length; i++) {
      var o = this.objects[i];
      if (!o.alive || !o.floorAt || Math.abs(o.x - x) > 600) continue;
      var fy = o.floorAt(x);
      if (fy !== null && yPrev <= fy + 1 && yNext >= fy) return true;
    }
    return false;
  },
  addRings: function (n) {
    this.rings += n;
    if (this.rings >= this.nextLifeAt) { this.nextLifeAt += 100; this.extraLife(); }
  },
  extraLife: function () {
    this.lives++;
    var self = this, cur = TH.Audio.music.current;
    if (cur === 'level' || cur === 'boss' || cur === 'invincible') {
      TH.Audio.music.play('oneup', function () { if (self.state === 'play' && !self.dying && !self.tally) TH.Audio.music.play(self.bossActive && !self.bossDefeated ? 'boss' : (self.player.invincible > 0 ? 'invincible' : 'level')); });
    }
  },
  addScore: function (v, x, y) {
    var before = this.score;
    this.score += v;
    // Жизнь за каждые 50000 очков
    if (Math.floor(this.score / 50000) > Math.floor(before / 50000)) this.extraLife();
    if (x !== null && x !== undefined) this.particles.score(x, y, v);
  },
  /** Очки за серию уничтожений без приземления */
  chainKill: function (x, y, monitor) {
    if (monitor) return;
    var p = this.player;
    var table = [100, 200, 500, 1000];
    var idx = p.ground ? 0 : Math.min(p.chain, 3);
    var pts = p.chain >= 15 ? 10000 : table[idx];
    if (!p.ground) p.chain++;
    this.addScore(pts, x, y);
  },
  giveItem: function (item) {
    var p = this.player;
    switch (item) {
      case 'rings': this.addRings(10); TH.Audio.play('ring'); break;
      case 'shield': p.shield = true; TH.Audio.play('shield'); break;
      case 'shoes': p.shoes = 20 * 60; TH.Audio.play('powerup'); TH.Audio.music.setTempo(1.25); break;
      case 'invincible':
        p.invincible = 20 * 60; TH.Audio.play('powerup');
        if (!this.bossActive) TH.Audio.music.play('invincible');
        break;
      case 'life': this.extraLife(); TH.Audio.play('powerup'); break;
    }
  },
  /** Урон: щит → без потерь; кольца → разлёт; иначе смерть */
  hurtPlayer: function (srcX, spikes) {
    var p = this.player;
    if (p.dead || p.invuln > 0 || p.invincible > 0 || p.state === 'hurt') return;
    if (p.shield) {
      p.shield = false; p.hurt(srcX); TH.Audio.play('hurtNoRing');
      return;
    }
    if (this.rings > 0) {
      this.scatterRings();
      p.hurt(srcX);
      TH.Audio.play('hurt');
      return;
    }
    this.deathReason = '';
    p.die(false);
  },
  /** Разлёт колец (до 32) по классической схеме двух кругов */
  scatterRings: function () {
    var p = this.player;
    var n = Math.min(this.rings, 32);
    var angle = 101.25 * Math.PI / 180, speed = 4, flip = false;
    for (var i = 0; i < n; i++) {
      if (i === 16) { speed = 2; angle = 101.25 * Math.PI / 180; }
      var xs = Math.cos(angle) * speed, ys = -Math.sin(angle) * speed;
      if (flip) { xs = -xs; angle += 22.5 * Math.PI / 180; }
      flip = !flip;
      this.spawn(TH.makeObject({ type: 'loosering', x: p.x, y: p.y - 4, vx: xs, vy: ys }, this));
    }
    this.rings = 0;
  },
  onPlayerDeath: function (pit) {
    this.dying = true; this.deathT = 0;
    TH.Audio.play('death');
    TH.Audio.music.stop();
    if (pit) TH.Audio.play('splash');
  },
  reachCheckpoint: function (cp) {
    this.checkpoint = { x: cp.x, y: cp.y - 19, time: this.time, animals: this.animalsSaved };
    for (var i = 0; i < this.objects.length; i++) {
      var o = this.objects[i];
      if (o.type === 'checkpoint' && o.x < cp.x) o.on = true;
    }
  },
  /* ---- Босс ---- */
  startBoss: function (boss) {
    this.bossActive = true; this.boss = boss; this.arenaLock = true;
    this.camera.setBounds(boss.ax0, boss.ax1 - TH.W);
    this.camera.fixY = boss.floorY - 200;
    TH.Audio.music.play('boss');
  },
  bossDefeatedEvt: function () {
    this.bossDefeated = true;
    this.camera.shake = 40;
    TH.Audio.music.stop();
  },
  bossGone: function () {
    // Камера сдвигается к капсуле; дальше не пройти, пока зверьки не спасены
    var cap = null;
    for (var i = 0; i < this.objects.length; i++) if (this.objects[i].type === 'capsule') cap = this.objects[i];
    this.camera.setBounds(this.boss.ax0, cap ? Math.min(this.level.W - TH.W, cap.x + 150 - TH.W) : this.level.W - TH.W);
    if (!cap) this.arenaLock = false;
    TH.Audio.music.play('level');
  },
  capsuleOpened: function () {
    this.capsuleDone = true;
    this.arenaLock = false;
    this.camera.fixY = null;
    this.camera.setBounds(this.camera.minX, this.level.W - TH.W);
    this.animalsSaved += 10;
    this.banner = { text: 'ЗВЕРИ СПАСЕНЫ!', t: 0, life: 220 };
    this.addScore(1000, null, null);
  },
  signpostHit: function (sign) {
    this.timeStopped = true;
    this.camera.setBounds(this.camera.minX, Math.min(this.level.W - TH.W, sign.x - TH.W / 2 + 60));
    TH.Audio.music.stop();
  },
  signpostDone: function () {
    this.inputLocked = true;
    this.tallyDelay = 60;
  },
  startTally: function () {
    var s = Math.floor(this.time / 60);
    var tb = s < 90 ? 50000 : s < 120 ? 10000 : s < 150 ? 5000 : s < 180 ? 4000 : s < 210 ? 3000 : s < 240 ? 2000 : s < 300 ? 1000 : s < 360 ? 500 : 0;
    this.tally = { t: 0, timeBonus: tb, ringBonus: this.rings * 100, animalBonus: this.animalsSaved * 100, done: false };
    TH.Audio.music.play('clear');
  },
  stepTally: function (inp) {
    var T = this.tally;
    T.t++;
    if (T.t < 180 || T.done) {
      if (T.done && T.t > T.doneAt + 40 && (inp.pressed.start || inp.pressed.jump)) { this.state = 'ending'; this.t = 0; }
      return;
    }
    var moved = 0;
    ['timeBonus', 'ringBonus', 'animalBonus'].forEach(function (k) {
      var d = Math.min(100, T[k]);
      T[k] -= d; moved += d;
    });
    if (moved > 0) { this.addScore(moved, null, null); if (T.t % 4 === 0) TH.Audio.play('tally'); }
    else { T.done = true; T.doneAt = T.t; TH.Audio.play('cash'); }
  },

  /* ======================== ОТРИСОВКА ======================== */
  render: function () {
    var g = this.ctx, H = TH.HUD;
    g.setTransform(1, 0, 0, 1, 0, 0);
    switch (this.state) {
      case 'title': H.title(g, this, this.t); break;
      case 'play':
      case 'ending':
        this.renderer.draw(this);
        if (this.state === 'ending') { H.ending(g, this, this.t); break; }
        H.hud(g, this);
        if (this.bossActive && this.boss && this.boss.state !== 'gone' && this.boss.state !== 'flee') H.bossBar(g, this.boss, this.frame);
        if (this.banner) H.banner(g, this.banner.text, this.banner.t);
        if (this.tally) H.tally(g, this, this.tally);
        if (this.cardT < 170) H.titleCard(g, this.cardT);
        if (this.dying) {
          if (this.deathT > 50 && this.deathT < 100) { g.fillStyle = 'rgba(0,0,0,' + ((this.deathT - 50) / 50 * 0.85) + ')'; g.fillRect(0, 0, TH.W, TH.H); }
          if (this.deathT >= 100) H.deathCard(g, this, this.deathT - 85);
        }
        if (this.paused) H.pause(g, this);
        break;
      case 'continue': H.cont(g, this, this.t); break;
      case 'gameover':
        this.renderer.draw(this);
        H.gameOver(g, this, this.t);
        break;
    }
  },

  /* ======================== СТРАНИЦА ======================== */
  resize: function () {
    var stage = document.getElementById('stage');
    var w = stage.clientWidth, h = stage.clientHeight;
    var fit = Math.min(w / TH.W, h / TH.H);
    var touch = document.body.classList.contains('touch');
    // Целочисленный масштаб для чётких пикселей; на телефоне — на весь экран
    var s = Math.floor(fit);
    // Целочисленно при 2× и больше; на маленьких экранах и телефонах — вписываем во весь экран
    if (s < 2 || touch) s = Math.max(0.5, fit);
    this.canvas.style.width = Math.floor(TH.W * s) + 'px';
    this.canvas.style.height = Math.floor(TH.H * s) + 'px';
  },
  toggleSound: function () {
    TH.Audio.unlock();
    var m = TH.Audio.toggleMute();
    var b = document.getElementById('soundBtn');
    if (b) b.textContent = m ? '✕ ЗВУК' : '♪ ЗВУК';
  },
  setupPage: function () {
    var self = this;
    var theme = TH.store.get('th_theme', 'dark');
    document.body.classList.toggle('theme-light', theme === 'light');
    document.body.classList.toggle('theme-dark', theme !== 'light');
    var tb = document.getElementById('themeBtn');
    function upd() { tb.textContent = document.body.classList.contains('theme-light') ? '☾ ТЕМА' : '☀ ТЕМА'; }
    upd();
    tb.addEventListener('click', function () {
      var light = !document.body.classList.contains('theme-light');
      document.body.classList.toggle('theme-light', light);
      document.body.classList.toggle('theme-dark', !light);
      TH.store.set('th_theme', light ? 'light' : 'dark');
      upd(); tb.blur();
    });
    var sb = document.getElementById('soundBtn');
    sb.textContent = TH.Audio.muted ? '✕ ЗВУК' : '♪ ЗВУК';
    sb.addEventListener('click', function () { self.toggleSound(); sb.blur(); });
    document.getElementById('fsBtn').addEventListener('click', function (e) {
      e.target.blur();
      var el = document.documentElement;
      if (!document.fullscreenElement && el.requestFullscreen) el.requestFullscreen().catch(function () {});
      else if (document.exitFullscreen) document.exitFullscreen().catch(function () {});
    });
    document.addEventListener('fullscreenchange', function () {
      document.body.classList.toggle('fullscreen', !!document.fullscreenElement);
      setTimeout(function () { self.resize(); }, 50);
    });
  },

  /* ======================== ДЛЯ АВТОТЕСТОВ ======================== */
  /** Прогнать n шагов симуляции синхронно (без отрисовки) */
  stepFrames: function (n) { for (var i = 0; i < n; i++) this.step(); return this.snapshot(); },
  snapshot: function () {
    var p = this.player;
    return { state: this.state, x: +p.x.toFixed(1), y: +p.y.toFixed(1), gsp: +p.gsp.toFixed(2), angle: +(p.angle * 180 / Math.PI).toFixed(1), ground: p.ground, mode: p.mode, pstate: p.state, rings: this.rings, lives: this.lives, score: this.score, dying: !!this.dying, layer: p.layer };
  },
  teleport: function (x, y) {
    var p = this.player;
    p.x = x; p.y = y; p.xsp = p.ysp = p.gsp = 0; p.ground = false; p.groundObj = null; p.state = 'fall'; p.hr = 19; p.wr = 9; p.layer = 0;
    this.camera.snap(p);
    this.cardT = 170;
  }
};

window.addEventListener('load', function () { new TH.Game(); });
