(function(){'use strict';window.addEventListener('DOMContentLoaded',function(){
var panel=document.getElementById('actPanel'),grid=document.getElementById('actGrid'),open=document.getElementById('actSelectBtn'),close=document.getElementById('actClose'),label=document.getElementById('actLabel');
if(!panel||!grid)return;
function updateLabel(){var n=TH.getSelectedAct?TH.getSelectedAct():1;if(label)label.textContent='АКТ '+n;}
for(var i=1;i<=20;i++){(function(n){var b=document.createElement('button');b.className='act-button';b.textContent=n===1?'1 · Palm Valley':'Акт '+n;b.onclick=function(){TH.selectAct(n);if(window.game){window.game.act=n;window.game.checkpoint=null;window.game.startAct();}panel.classList.add('shop-hidden');updateLabel();};grid.appendChild(b);})(i);}
if(open)open.onclick=function(){updateLabel();panel.classList.toggle('shop-hidden');};
if(close)close.onclick=function(){panel.classList.add('shop-hidden')};
panel.onclick=function(e){if(e.target===panel)panel.classList.add('shop-hidden')};
updateLabel();
});})();