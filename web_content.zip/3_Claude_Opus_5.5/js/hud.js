/* ==========================================================================
   hud.js — интерфейс в стиле 16-бит: HUD, полоска босса, баннеры и экраны
   (титул, карточка зоны, пауза, потеря жизни, CONTINUE, GAME OVER, итоги)
   ========================================================================== */
'use strict';

TH.HUD = (function () {
  var F = TH.Font, S = TH.Sprites;
  var YEL = '#ffe030', WHT = '#ffffff', RED = '#ff3030', SH = '#000000';

  function txt(g, s, x, y, col, scale, align, outline) {
    return F.draw(g, s, x, y, col, { scale: scale || 1, shadow: outline ? null : SH, outline: outline, align: align });
  }
  function fmtTime(frames) {
    var s = Math.floor(frames / 60), m = Math.floor(s / 60);
    s %= 60;
    return m + ':' + (s < 10 ? '0' : '') + s;
  }

  /* ---------------- HUD во время игры ---------------- */
  function hud(g, game) {
    var flash0 = game.rings === 0 && (game.frame >> 4) % 2 === 0;
    txt(g, 'SCORE', 12, 9, YEL, 1, null, SH);
    txt(g, String(game.score), 118, 9, WHT, 1, 'right', SH);
    var tcol = game.time > TH.CONFIG.TIME_LIMIT - 60 * 60 && (game.frame >> 4) % 2 === 0 ? RED : YEL;
    txt(g, 'TIME', 12, 20, tcol, 1, null, SH);
    txt(g, fmtTime(game.time), 118, 20, WHT, 1, 'right', SH);
    txt(g, 'RINGS', 12, 31, flash0 ? RED : YEL, 1, null, SH);
    txt(g, String(game.rings), 118, 31, WHT, 1, 'right', SH);
    // Жизни
    g.fillStyle = 'rgba(0,0,40,.45)'; g.fillRect(8, 216, 62, 18);
    S.heroHead(g, 20, 224, 0.62);
    txt(g, 'TURBO', 32, 218, YEL, 1, null, SH);
    txt(g, '×' + game.lives, 32, 226, WHT, 1, null, SH);
    // Индикаторы бонусов
    var ix = 80;
    var p = game.player;
    if (p.shoes > 0 && (p.shoes > 120 || (game.frame >> 3) % 2)) { S.shoe(g, ix, 227, 0); ix += 16; }
    if (p.invincible > 0 && (p.invincible > 120 || (game.frame >> 3) % 2)) { g.fillStyle = YEL; S.star(g, ix, 226, 5, 2); ix += 16; }
    if (p.shield) S.ell(g, ix, 226, 5, 5, 'rgba(120,200,255,.6)', '#bff');
  }

  /* ---------------- Полоска здоровья босса ---------------- */
  function bossBar(g, boss, frame) {
    var x0 = TH.W / 2 - 68, y = 8;
    g.fillStyle = 'rgba(0,0,30,.6)'; g.fillRect(x0 - 4, y - 3, 144, 22);
    txt(g, TH.BOSS_NAME, TH.W / 2, y, '#ff80ff', 1, 'center', SH);
    for (var i = 0; i < TH.BOSS_HP; i++) {
      var on = i < boss.hp;
      var blink = boss.segBlink[i] > 0 && (frame >> 2) % 2;
      var sx = x0 + i * 17, sy = y + 9;
      g.fillStyle = '#000'; g.fillRect(sx, sy, 15, 6);
      g.fillStyle = blink ? '#ffffff' : on ? (boss.hp <= 2 ? '#ff4040' : boss.hp <= 4 ? '#ffc020' : '#40e040') : '#303040';
      g.fillRect(sx + 1, sy + 1, 13, 4);
      if (on && !blink) { g.fillStyle = 'rgba(255,255,255,.5)'; g.fillRect(sx + 1, sy + 1, 13, 1); }
    }
  }

  /* ---------------- Титульная карточка зоны ---------------- */
  function titleCard(g, t) {
    // t: 0..170
    var inK = TH.ease(t / 22), outK = t > 130 ? TH.ease((t - 130) / 30) : 0;
    var k = inK - outK * 1.6;
    // Синяя панель сверху, жёлтая снизу, красная слева
    g.fillStyle = '#1a3cc8'; g.fillRect(0, -TH.H / 2 + TH.H / 2 * Math.min(1, k) - 40 * outK, TH.W, 90);
    g.fillStyle = '#ffd000'; g.fillRect(0, TH.H - 70 * Math.min(1, k) + 60 * outK, TH.W, 70);
    g.fillStyle = '#e02020'; g.fillRect(-110 + 110 * Math.min(1, k) - 140 * outK, 0, 100, TH.H);
    g.fillStyle = '#ffffff';
    for (var i = 0; i < 8; i++) g.fillRect(-110 + 110 * Math.min(1, k) - 140 * outK + 86, i * 30 + (t % 30), 6, 14);
    var tx = TH.W + 20 - (TH.W - 120) * Math.min(1, k) + 400 * outK;
    txt(g, 'PALM VALLEY', tx, 92, WHT, 3, null, '#000');
    txt(g, 'ZONE', tx + 140, 122, WHT, 3, null, '#000');
    var ax = -80 + 300 * Math.min(1, k) - 400 * outK;
    txt(g, 'ACT', ax, 168, '#ffffff', 2, null, '#000');
    txt(g, '1', ax + 48, 160, '#ffe030', 4, null, '#000');
  }

  /* ---------------- Титульный экран ---------------- */
  function title(g, game, t) {
    game.renderer.bg.draw(g, t * 1.5, 1160, t);
    g.fillStyle = 'rgba(0,0,40,.15)'; g.fillRect(0, 0, TH.W, TH.H);
    var cx = TH.W / 2, cy = 96;
    // Эмблема: круг со звёздами и крыльями
    g.save();
    g.translate(cx, cy);
    for (var side = -1; side <= 1; side += 2) {
      g.fillStyle = '#ffffff'; g.strokeStyle = '#1a2a80'; g.lineWidth = 2;
      g.beginPath(); g.moveTo(side * 52, -10);
      g.quadraticCurveTo(side * 100, -40, side * 120, -20);
      g.quadraticCurveTo(side * 96, -14, side * 108, 0);
      g.quadraticCurveTo(side * 86, 4, side * 96, 16);
      g.quadraticCurveTo(side * 70, 14, side * 52, 14);
      g.closePath(); g.fill(); g.stroke();
    }
    S.ell(g, 0, 0, 58, 58, '#1a3cc8', '#0a1450');
    S.ell(g, 0, 0, 52, 52, null, '#ffd000');
    g.strokeStyle = '#ffd000'; g.lineWidth = 3; g.beginPath(); g.arc(0, 0, 54, 0, Math.PI * 2); g.stroke();
    g.fillStyle = '#ffe030';
    for (var i = 0; i < 8; i++) { var a = i / 8 * Math.PI * 2 + t * 0.01; S.star(g, Math.cos(a) * 44, Math.sin(a) * 44, 4, 1.8); }
    g.restore();
    // Ёж с поднятым большим пальцем
    g.save(); g.translate(cx, cy + 2); g.scale(2.4, 2.4);
    S.hero(g, 0, 0, { pose: 'thumb', t: t, facing: 1 });
    g.restore();
    // Лента с названием
    g.save(); g.translate(cx, 150);
    g.fillStyle = '#8a1010';
    g.beginPath(); g.moveTo(-150, -6); g.lineTo(-170, 10); g.lineTo(-150, 26); g.lineTo(-130, 26); g.lineTo(-130, -6); g.fill();
    g.beginPath(); g.moveTo(150, -6); g.lineTo(170, 10); g.lineTo(150, 26); g.lineTo(130, 26); g.lineTo(130, -6); g.fill();
    g.fillStyle = '#e02020'; g.fillRect(-140, -18, 280, 38);
    g.fillStyle = '#ff6060'; g.fillRect(-140, -18, 280, 3);
    g.fillStyle = '#700808'; g.fillRect(-140, 17, 280, 3);
    g.restore();
    // Логотип текстом пиксельного шрифта с обводкой и «градиентом» из двух слоёв
    var lx = cx;
    F.draw(g, 'TURBO', lx + 2, 128, '#3a1000', { scale: 4, align: 'center' });
    F.draw(g, 'TURBO', lx, 126, '#ffd000', { scale: 4, align: 'center', outline: '#5a1a00' });
    F.draw(g, 'TURBO', lx, 126, '#fff27a', { scale: 4, align: 'center' });
    g.save(); g.beginPath(); g.rect(0, 141, TH.W, 20); g.clip();
    F.draw(g, 'TURBO', lx, 126, '#ffb000', { scale: 4, align: 'center' });
    g.restore();
    F.draw(g, 'HEDGEHOG', lx, 158, '#ffffff', { scale: 2, align: 'center', outline: '#1a2a80' });
    if ((t >> 5) % 2 === 0) txt(g, 'PRESS START', cx, 184, WHT, 2, 'center', '#000');
    txt(g, 'PALM VALLEY ZONE', cx, 205, '#c0e0ff', 1, 'center', '#000');
  }

  /* ---------------- Пауза ---------------- */
  function pause(g, game) {
    g.fillStyle = 'rgba(0,0,30,.5)'; g.fillRect(0, 0, TH.W, TH.H);
    txt(g, 'PAUSE', TH.W / 2, 96, YEL, 3, 'center', '#000');
    txt(g, 'ENTER - CONTINUE', TH.W / 2, 130, WHT, 1, 'center', '#000');
    txt(g, 'M - SOUND ' + (TH.Audio.muted ? 'OFF' : 'ON') + '   N - MUSIC ' + (TH.Audio.musicOn ? 'ON' : 'OFF'), TH.W / 2, 144, WHT, 1, 'center', '#000');
  }

  /* ---------------- Карточка потери жизни ---------------- */
  function deathCard(g, game, t) {
    var a = TH.clamp(t / 20, 0, 1);
    g.fillStyle = 'rgba(0,0,0,' + (0.85 * a) + ')'; g.fillRect(0, 0, TH.W, TH.H);
    if (t < 15) return;
    var cx = TH.W / 2, cy = TH.H / 2;
    var slide = TH.ease((t - 15) / 15);
    g.save(); g.globalAlpha = slide;
    g.fillStyle = '#1a3cc8'; g.fillRect(cx - 80, cy - 26, 160, 52);
    g.fillStyle = '#ffd000'; g.fillRect(cx - 80, cy - 26, 160, 3); g.fillRect(cx - 80, cy + 23, 160, 3);
    S.heroHead(g, cx - 44, cy, 1.5);
    txt(g, '×', cx - 10, cy - 8, WHT, 2, null, '#000');
    txt(g, String(game.lives), cx + 8, cy - 14, YEL, 4, null, '#000');
    txt(g, game.deathReason || '', cx, cy + 34, WHT, 1, 'center', '#000');
    g.restore();
  }

  /* ---------------- CONTINUE? ---------------- */
  function cont(g, game, t) {
    g.fillStyle = '#000018'; g.fillRect(0, 0, TH.W, TH.H);
    // Звёздное небо
    for (var i = 0; i < 40; i++) { g.fillStyle = (i + (t >> 4)) % 5 ? '#334' : '#99c'; g.fillRect((i * 97) % TH.W, (i * 53) % TH.H, 1, 1); }
    txt(g, 'CONTINUE?', TH.W / 2, 40, YEL, 3, 'center', '#000');
    var n = Math.max(0, 9 - Math.floor(t / 60));
    txt(g, String(n), TH.W / 2, 140, WHT, 5, 'center', '#1a3cc8');
    g.save(); g.translate(TH.W / 2, 110); g.scale(2, 2);
    S.hero(g, 0, 0, { pose: 'wait', t: t, facing: 1 });
    g.restore();
    if ((t >> 5) % 2 === 0) txt(g, 'PRESS START', TH.W / 2, 196, WHT, 1, 'center', '#000');
  }

  /* ---------------- GAME OVER ---------------- */
  function gameOver(g, game, t) {
    g.fillStyle = 'rgba(0,0,0,.8)'; g.fillRect(0, 0, TH.W, TH.H);
    var k = TH.ease(t / 40);
    txt(g, 'GAME', -100 + (TH.W / 2 - 60 + 100) * k, 100, WHT, 4, null, '#1a3cc8');
    txt(g, 'OVER', TH.W + 20 - (TH.W + 20 - TH.W / 2 - 8) * k, 100, WHT, 4, null, '#1a3cc8');
  }

  /* ---------------- Итоги акта ---------------- */
  function tally(g, game, T) {
    var t = T.t;
    var k1 = TH.ease(t / 30), k2 = TH.ease((t - 15) / 30);
    txt(g, 'TURBO HEDGEHOG', TH.W / 2 - 300 + 300 * k1, 44, WHT, 2, 'center', '#000');
    txt(g, 'GOT THROUGH', TH.W / 2 + 300 - 300 * k1, 64, WHT, 2, 'center', '#000');
    txt(g, 'PALM VALLEY ZONE  ACT 1', TH.W / 2, 86, YEL, 1, 'center', '#000');
    var rows = [
      ['SCORE', game.score],
      ['TIME BONUS', T.timeBonus],
      ['RING BONUS', T.ringBonus],
      ['ANIMALS SAVED ' + game.animalsSaved, T.animalBonus]
    ];
    for (var i = 0; i < rows.length; i++) {
      var rx = -260 + 260 * k2;
      if (t < 30 + i * 8) continue;
      txt(g, rows[i][0], 92 + rx, 112 + i * 18, YEL, 1, null, '#000');
      txt(g, String(rows[i][1]), 332 + rx, 112 + i * 18, WHT, 1, 'right', '#000');
    }
    if (T.done && t % 60 < 40) txt(g, 'PRESS START', TH.W / 2, 200, WHT, 1, 'center', '#000');
  }

  function ending(g, game, t) {
    g.fillStyle = 'rgba(0,0,40,.7)'; g.fillRect(0, 0, TH.W, TH.H);
    txt(g, 'THANKS FOR PLAYING!', TH.W / 2, 70, YEL, 2, 'center', '#000');
    txt(g, 'FINAL SCORE ' + game.score, TH.W / 2, 100, WHT, 1, 'center', '#000');
    txt(g, 'TIME ' + fmtTime(game.time) + '   ANIMALS ' + game.animalsSaved, TH.W / 2, 114, WHT, 1, 'center', '#000');
    g.save(); g.translate(TH.W / 2, 158); g.scale(1.8, 1.8);
    S.hero(g, 0, 0, { pose: 'thumb', t: t, facing: 1 });
    g.restore();
    if ((t >> 5) % 2 === 0) txt(g, 'PRESS START', TH.W / 2, 210, WHT, 1, 'center', '#000');
  }

  /* ---------------- Баннер по центру ---------------- */
  function banner(g, text, t) {
    var k = TH.ease(t / 15);
    var y = 60;
    g.fillStyle = 'rgba(0,0,40,' + (0.5 * k) + ')'; g.fillRect(0, y - 8, TH.W, 30);
    var col = (t >> 3) % 2 ? '#ffe030' : '#ffffff';
    txt(g, text, TH.W / 2, y, col, 2, 'center', '#000');
  }

  return { hud: hud, bossBar: bossBar, titleCard: titleCard, title: title, pause: pause, deathCard: deathCard, cont: cont, gameOver: gameOver, tally: tally, ending: ending, banner: banner, fmtTime: fmtTime };
})();
