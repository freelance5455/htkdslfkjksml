/* ==========================================================================
   level.js — строитель уровня и данные акта «PALM VALLEY ZONE»
   Геометрия задаётся «пером» (полилинии холмов), петлями, блоками и
   островами; объекты — списком описаний (создаются заново при рестарте).
   ========================================================================== */
'use strict';

TH.LevelBuilder = function (W, H) {
  this.W = W; this.H = H;
  this.terrain = new TH.Terrain(W, H);
  this.objects = [];   // описания объектов {type, x, y, ...}
  this.decor = [];     // декор за героем (пальмы, цветы, водопады)
  this.loops = [];     // петли (для переключения слоёв коллизий)
  this.corks = [];     // штопоры
  this.water = [];     // водоёмы
  this.secrets = [];   // накладки, скрывающие секретные комнаты
  this.lines = [];     // поверхности «главной» земли для расчёта высоты при расстановке
};

/* ---------------- «Перо» для рисования холмов ---------------- */
TH.Pen = function (b, x, y) { this.b = b; this.pts = [[x, y]]; };
TH.Pen.prototype = {
  last: function () { return this.pts[this.pts.length - 1]; },
  flat: function (len) { var p = this.last(); this.pts.push([p[0] + len, p[1]]); return this; },
  /** Плавный (косинусный) переход по высоте на длине len */
  curve: function (len, dy) {
    var p = this.last(), x0 = p[0], y0 = p[1];
    var n = Math.max(2, Math.ceil(len / 8));
    for (var i = 1; i <= n; i++) {
      var t = i / n;
      this.pts.push([x0 + len * t, y0 + dy * (1 - Math.cos(Math.PI * t)) / 2]);
    }
    return this;
  },
  /** Прямая к точке */
  to: function (x, y) { this.pts.push([x, y]); return this; },
  /** Дуга окружности (для трамплинов): центр, радиус, углы в градусах (экранные, y вниз) */
  arc: function (cx, cy, r, a0, a1) {
    var n = Math.max(4, Math.ceil(Math.abs(a1 - a0) / 4));
    for (var i = 1; i <= n; i++) {
      var a = (a0 + (a1 - a0) * i / n) * Math.PI / 180;
      this.pts.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]);
    }
    return this;
  },
  /** Замыкает фигуру вниз до дна уровня и регистрирует её */
  end: function (opts) {
    opts = opts || {};
    var b = this.b, pts = this.pts.slice(), H = b.H + 32;
    var x0 = pts[0][0], x1 = pts[pts.length - 1][0];
    var minY = Infinity;
    for (var i = 0; i < pts.length; i++) minY = Math.min(minY, pts[i][1]);
    // Поверхности для травы: без крутых обрывов
    var surfaces = [], cur = [pts[0]];
    for (i = 1; i < pts.length; i++) {
      var dx = pts[i][0] - pts[i - 1][0], dy = pts[i][1] - pts[i - 1][1];
      if (Math.abs(dy) > Math.abs(dx) * 2.2) {
        if (cur.length > 1) surfaces.push(cur);
        cur = [pts[i]];
      } else cur.push(pts[i]);
    }
    if (cur.length > 1) surfaces.push(cur);
    b.terrain.add({
      bbox: [x0 - 2, minY - 2, x1 + 2, H],
      flag: TH.SOLID, style: opts.style || 'ground', surfaces: surfaces,
      path: function (g) {
        g.moveTo(pts[0][0], H);
        for (var k = 0; k < pts.length; k++) g.lineTo(pts[k][0], pts[k][1]);
        g.lineTo(pts[pts.length - 1][0], H);
        g.closePath();
      }
    });
    if (!opts.noLine) b.lines.push(pts);
    return this;
  }
};

TH.LevelBuilder.prototype = {
  pen: function (x, y) { return new TH.Pen(this, x, y); },
  /** Высота главной земли в точке x (для расстановки объектов) */
  gy: function (x) {
    for (var i = 0; i < this.lines.length; i++) {
      var p = this.lines[i];
      if (x < p[0][0] || x > p[p.length - 1][0]) continue;
      for (var k = 1; k < p.length; k++) {
        if (x >= p[k - 1][0] && x <= p[k][0] && p[k][0] > p[k - 1][0]) {
          var t = (x - p[k - 1][0]) / (p[k][0] - p[k - 1][0]);
          return p[k - 1][1] + (p[k][1] - p[k - 1][1]) * t;
        }
      }
    }
    return 1400;
  },
  /** Твёрдый блок с травой сверху */
  block: function (x, y, w, h, style) {
    this.terrain.add({
      bbox: [x, y, x + w, y + h], flag: TH.SOLID, style: style || 'ground',
      surfaces: style === 'rock' ? null : [[[x - 8, y], [x + w + 8, y]]],
      path: function (g) { g.rect(x, y, w, h); }
    });
  },
  /** Парящий остров / уступ: твёрдый только сверху (можно запрыгнуть снизу) */
  ledge: function (x, y, w, thick) {
    thick = thick || 30;
    var r = 10;
    this.terrain.add({
      bbox: [x, y, x + w, y + thick], flag: TH.SOLID, noCollide: true, style: 'ground', under: true,
      surfaces: [[[x - 8, y], [x + w + 8, y]]],
      path: function (g) {
        g.moveTo(x, y);
        g.lineTo(x + w, y);
        g.lineTo(x + w, y + thick - r);
        g.quadraticCurveTo(x + w, y + thick, x + w - r, y + thick);
        g.lineTo(x + r, y + thick);
        g.quadraticCurveTo(x, y + thick, x, y + thick - r);
        g.closePath();
      }
    });
    this.terrain.add({
      bbox: [x, y, x + w, y + 16], flag: TH.TOPONLY, noDraw: true,
      path: function (g) { g.rect(x, y, w, 16); }
    });
  },
  /** Петля 360°: правая половина — слой A, левая — слой B (переключаются триггерами) */
  loop: function (cx, floorY, R, T) {
    T = T || 24;
    var cy = floorY - R;
    var Ro = R + T;
    function half(a0, a1) {
      var pts = [], n = 48, i, a;
      for (i = 0; i <= n; i++) { a = (a0 + (a1 - a0) * i / n) * Math.PI / 180; pts.push([cx + Math.cos(a) * Ro, cy + Math.sin(a) * Ro]); }
      for (i = n; i >= 0; i--) { a = (a0 + (a1 - a0) * i / n) * Math.PI / 180; pts.push([cx + Math.cos(a) * R, cy + Math.sin(a) * R]); }
      return pts;
    }
    var right = half(-104, 90), left = half(90, 284);
    function polyPath(pts) { return function (g) { g.moveTo(pts[0][0], pts[0][1]); for (var i = 1; i < pts.length; i++) g.lineTo(pts[i][0], pts[i][1]); g.closePath(); }; }
    var bbox = [cx - Ro - 2, cy - Ro - 2, cx + Ro + 2, floorY + T];
    this.terrain.add({ bbox: bbox, flag: TH.LAYER_A, noDraw: true, path: polyPath(right) });
    this.terrain.add({ bbox: bbox, flag: TH.LAYER_B, noDraw: true, path: polyPath(left) });
    // Визуальное кольцо петли
    this.terrain.add({
      bbox: bbox, flag: TH.SOLID, noCollide: true, style: 'loop', rule: 'evenodd',
      surfaces: [{ circle: [cx, cy, R], rim: true }],
      path: function (g) {
        g.moveTo(cx + Ro, cy); g.arc(cx, cy, Ro, 0, Math.PI * 2);
        g.moveTo(cx + R, cy); g.arc(cx, cy, R, 0, Math.PI * 2);
      }
    });
    this.loops.push({ cx: cx, cy: cy, R: R, T: T, floorY: floorY });
  },
  /** Вырез в земле (секретная комната/тоннель), рисуется как пещера */
  cut: function (x, y, w, h) {
    this.terrain.add({ bbox: [x, y, x + w, y + h], flag: TH.SOLID, cut: true, style: 'cave', path: function (g) { g.rect(x, y, w, h); } });
  },
  /** Накладка, скрывающая секрет (исчезает, когда герой внутри) */
  secret: function (x, y, w, h) { this.secrets.push({ x: x, y: y, w: w, h: h, alpha: 1 }); },

  /* ---------------- Объекты ---------------- */
  obj: function (type, x, y, o) {
    var d = o || {};
    d.type = type; d.x = x; d.y = (y === undefined || y === null) ? this.gy(x) : y;
    this.objects.push(d);
    return d;
  },
  ring: function (x, y) { this.objects.push({ type: 'ring', x: x, y: y }); },
  ringLine: function (x, y, n, dx, dy) {
    dx = dx === undefined ? 24 : dx; dy = dy || 0;
    for (var i = 0; i < n; i++) this.ring(x + i * dx, y + i * dy);
  },
  /** Кольца над землёй вдоль маршрута */
  ringTrail: function (x, n, off, dx) {
    dx = dx || 24; off = off === undefined ? 22 : off;
    for (var i = 0; i < n; i++) this.ring(x + i * dx, this.gy(x + i * dx) - off);
  },
  /** Дуга колец — подсказка траектории прыжка */
  ringArc: function (x0, y0, x1, y1, h, n) {
    for (var i = 0; i < n; i++) {
      var t = n === 1 ? 0.5 : i / (n - 1);
      this.ring(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t - h * 4 * t * (1 - t));
    }
  },
  ringCircle: function (cx, cy, r, n, a0) {
    for (var i = 0; i < n; i++) {
      var a = (a0 || 0) + i / n * Math.PI * 2;
      this.ring(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
    }
  },
  ringGrid: function (x, y, cols, rows, dx, dy) {
    for (var r = 0; r < rows; r++) for (var c = 0; c < cols; c++) this.ring(x + c * dx, y + r * dy);
  },
  deco: function (kind, x, y, o) {
    var d = o || {};
    d.kind = kind; d.x = x; d.y = (y === undefined || y === null) ? this.gy(x) : y;
    this.decor.push(d);
  }
};

/* ==========================================================================
   PALM VALLEY ZONE — ACT 1
   Обзор маршрута (x):
     0–2650     старт, плавный подъём, остров с щитом (без пропастей)
     2650–3800  спуск с горки → ПЕТЛЯ 1 → чекпоинт 1
     3760–4280  МОСТ из брёвен над оврагом (дно твёрдое)
     4400–5800  РАЗВИЛКА 1: верх (красная пружина, острова) / низ (шипы, краб)
     5800–7070  плато с СЕКРЕТНОЙ КОМНАТОЙ, чекпоинт 2, спуск и ТРАМПЛИН
     7070–9300  РАЗВИЛКА 2: верх (уступы после трамплина) / низ (долина и ОЗЕРО с рушащимися платформами)
     9300–12400 чекпоинт 3, ШТОПОР, спуск → ПЕТЛЯ 2
     12400–14000 РАЗВИЛКА 3: верх (движущиеся платформы) / низ (яма, шипы, оса)
     14000–15900 финальный отрезок, боковая пружина, чекпоинты 4–5
     15900–16330 АРЕНА БОССА → капсула → финишная табличка
   ========================================================================== */
TH.buildPalmValley = function () {
  var W = 57600, H = 1664;
  var B = new TH.LevelBuilder(W, H);
  var G = 1400;

  /* ======================= ЗЕМЛЯ ======================= */
  // --- Секция 1–3: старт, петля 1, овраг под мостом, нижняя дорога развилки 1
  var p = B.pen(-32, G);
  p.flat(672)            // → 640
    .curve(384, -80)     // → 1024, 1320
    .flat(192)           // → 1216
    .curve(256, 40)      // → 1472, 1360
    .flat(96)            // → 1568
    .curve(480, -120)    // → 2048, 1240
    .flat(160)           // → 2208
    .curve(320, -64)     // → 2528, 1176  вершина перед петлёй
    .flat(128)           // → 2656
    .curve(384, 224)     // → 3040, 1400  спуск-разгон
    .flat(720)           // → 3760        петля 1 (cx 3264)
    .curve(128, 112)     // → 3888, 1512  овраг под мостом
    .flat(256)           // → 4144
    .curve(128, -112)    // → 4272, 1400
    .flat(428)           // → 4700        развилка 1 (низ)
    .curve(200, 40)      // → 4900, 1440
    .flat(300)           // → 5200
    .curve(200, -40)     // → 5400, 1400
    .flat(600)           // → 6000
    .to(6000, 1240)      // обрыв вверх — плато
    .flat(560)           // → 6560
    .curve(320, 160)     // → 6880, 1400  спуск к трамплину
    .flat(96)            // → 6976
    .arc(6976, 1280, 120, 90, 38) // трамплин
    .to(7072, 1520)      // обрыв в долину
    .flat(1168)          // → 8240        долина (низ развилки 2)
    .end();
  // --- Озеро 8240–9200 (пропасть с водой). Дальше — новая земля
  p = B.pen(9200, H);
  p.to(9200, 1500)
    .flat(120)           // → 9320
    .curve(400, -100)    // → 9720, 1400
    .flat(200)           // → 9920
    .curve(240, -80)     // → 10160, 1320
    .flat(560)           // → 10720       штопор 10240–10640
    .curve(400, 200)     // → 11120, 1520 спуск к петле 2
    .flat(800)           // → 11920       петля 2 (cx 11360)
    .curve(480, -120)    // → 12400, 1400
    .flat(500)           // → 12900       яма нижней дороги развилки 3
    .end();
  p = B.pen(13030, H);
  p.to(13030, 1400)
    .flat(1170)          // → 14200
    .curve(320, -96)     // → 14520, 1304
    .flat(160)           // → 14680
    .curve(320, 96)      // → 15000, 1400
    .flat(160)           // → 15160       маленькая яма
    .end();
  // --- Утёсы-ступени и S-образный спуск
  p = B.pen(15288, H);
  p.to(15288, 1400)
    .flat(232)           // → 15520
    .to(15520, 1320)     // уступ 1 (берётся прыжком)
    .flat(368)           // → 15888
    .to(15888, 1240)     // уступ 2
    .flat(400)           // → 16288
    .curve(448, 80)      // → 16736, 1320
    .flat(96)            // → 16832
    .curve(448, 80)      // → 17280, 1400
    .flat(320)           // → 17600       яма A (движущаяся платформа)
    .end();
  p = B.pen(17760, H);
  p.to(17760, 1400)
    .flat(240)           // → 18000       яма B (островок посередине)
    .end();
  p = B.pen(18200, H);
  p.to(18200, 1400)
    .flat(10200)         // → 28400       непрерывный проход к большой дополнительной зоне
    .end();

  /* ======================= ПЕТЛИ И ШТОПОР ======================= */
  B.loop(3264, 1400, 80, 24);
  B.loop(11360, 1520, 96, 24);
  B.loop(20480, 1400, 88, 22);
  B.loop(24680, 1224, 104, 24);
  B.corks.push({ x0: 10240, x1: 10640, y: 1320, h: 72 });

  /* ======================= СЕКРЕТНАЯ КОМНАТА ======================= */
  // Внутри плато: вход через «фальшивую» стену в основании обрыва, выход — пружина в шахту
  B.cut(6000, 1324, 352, 76);
  B.cut(6300, 1240, 52, 90);
  B.terrain.add({ bbox: [6300, 1240, 6352, 1256], flag: TH.TOPONLY, noDraw: true, path: function (g) { g.rect(6300, 1240, 52, 16); } });
  B.secret(6000, 1240, 352, 160);

  /* ======================= ВЕРХНИЕ МАРШРУТЫ ======================= */
  // Остров над стартовой зоной (щит)
  B.ledge(1040, 1184, 176);
  // Развилка 1 — верх
  B.ledge(4360, 1120, 360);
  B.ledge(4800, 1088, 280);
  B.ledge(5160, 1120, 280);
  // Новые высокие маршруты дополнительной зоны
  B.ledge(19840, 1120, 220); B.ledge(20120, 1000, 240);
  B.ledge(20720, 1080, 300); B.ledge(21200, 1160, 220);
  B.ledge(22440, 1080, 260); B.ledge(22820, 960, 260);
  B.ledge(23300, 1080, 260); B.ledge(24040, 1040, 260);
  B.ledge(24440, 920, 280); B.ledge(25000, 1080, 260);
  B.ledge(25880, 1080, 260); B.ledge(26320, 960, 300);
  B.ledge(5520, 1150, 200);
  // Развилка 2 — верх (после трамплина над долиной и озером)
  B.ledge(7240, 1290, 560);
  B.ledge(7880, 1290, 360);
  B.ledge(8330, 1290, 300);
  B.ledge(8720, 1290, 300);
  B.ledge(9110, 1290, 200);
  // Развилка 3 — верх
  B.ledge(12680, 1120, 500);
  B.ledge(13380, 1120, 540);
  // Финальный отрезок: островок в яме B и верхний уступ у лифта
  B.ledge(18060, 1360, 80);
  B.ledge(18280, 1180, 190);
  // Каменные столбы-опоры под арену (декор не нужен) — край уровня справа уже стена

  /* ======================= ВОДА ======================= */
  B.water.push({ x0: 8240, x1: 9200, y: 1530 });

  /* ======================= ОБЪЕКТЫ ======================= */
  var o = B;
  // ---- Секция 1: старт
  o.ringLine(240, G - 24, 5);
  o.obj('monitor', 420, null, { item: 'rings' });
  o.ringArc(560, G - 24, 720, 1380 - 24, 40, 5);
  o.ringTrail(760, 6, 24, 28);
  o.obj('spring', 1112, null, { color: 'yellow' });       // на остров
  o.obj('monitor', 1170, 1184, { item: 'shield' });
  o.ringLine(1060, 1160, 3);
  o.obj('enemy', 1330, null, { kind: 'beetle', range: 110 });
  o.ringTrail(1520, 5, 24);
  o.obj('enemy', 1820, null, { kind: 'beetle', range: 100 });
  o.ringArc(1950, 1236, 2150, 1216, 40, 5);
  o.obj('enemy', 2300, 1150, { kind: 'wasp' });
  o.obj('monitor', 2600, null, { item: 'shoes' });
  o.ringTrail(2700, 6, 22, 40);          // ведут по спуску к петле
  // ---- Петля 1
  o.ringCircle(3264, 1320, 56, 10, -Math.PI / 2);
  o.ringLine(3400, G - 24, 4);
  o.obj('checkpoint', 3600);
  // ---- Мост и овраг
  o.obj('bridge', 3760, 1400, { x1: 4272 });
  o.ringArc(3800, 1376, 4230, 1376, 60, 9);
  o.obj('enemy', 3960, null, { kind: 'crab', range: 60 });
  o.obj('spring', 4016, null, { color: 'yellow' });      // выход из оврага
  o.obj('spring', 3906, null, { color: 'yellow', dir: 1 }); // боковая пружина у левого склона оврага
  o.obj('monitor', 4100, null, { item: 'rings' });
  // ---- Развилка 1: верх (красная пружина)
  o.obj('spring', 4440, null, { color: 'red' });
  o.ringLine(4440, 1300, 4, 0, -40);
  o.ringLine(4560, 1096, 5);
  o.ringArc(4700, 1100, 4820, 1064, 40, 4);
  o.obj('monitor', 4980, 1088, { item: 'shoes' });
  o.ringArc(5080, 1064, 5180, 1096, 40, 4);
  o.ringLine(5220, 1096, 6);
  o.obj('enemy', 5300, 1060, { kind: 'wasp' });
  o.ringArc(5440, 1096, 5540, 1126, 40, 4);
  // ---- Развилка 1: низ (шипы, краб, жук)
  o.obj('spikes', 4620, null, { n: 3 });
  o.ringArc(4590, 1376, 4690, 1376, 50, 4);
  o.obj('enemy', 5000, null, { kind: 'crab', range: 70 });
  o.obj('spikes', 5140, null, { n: 2 });
  o.obj('monitor', 5260, null, { item: 'rings' });
  o.obj('enemy', 5580, null, { kind: 'beetle', range: 120 });
  o.ringTrail(5700, 4, 24);
  // ---- Плато и секретная комната
  o.obj('spring', 5880, null, { color: 'yellow' });
  o.ringLine(5880, 1330, 3, 0, -36);
  o.ringGrid(6040, 1340, 6, 3, 24, 18);   // награда в секретной комнате
  o.obj('monitor', 6210, 1400, { item: 'life' });
  o.obj('monitor', 6260, 1400, { item: 'rings' });
  o.obj('spring', 6326, 1400, { color: 'yellow' });       // выход из комнаты
  o.obj('monitor', 6150, 1240, { item: 'invincible' });
  o.obj('checkpoint', 6460, 1240);
  o.ringTrail(6580, 8, 22, 36);
  // ---- Трамплин → развилка 2
  o.ringArc(7090, 1330, 7330, 1260, 70, 6);
  o.ringLine(7400, 1266, 6);
  o.obj('enemy', 7700, 1250, { kind: 'wasp' });
  o.ringArc(7800, 1266, 7880, 1266, 40, 3);
  o.obj('monitor', 8100, 1290, { item: 'rings' });
  o.ringArc(8240, 1266, 8330, 1266, 40, 4);
  o.ringLine(8400, 1266, 5);
  o.ringArc(8630, 1266, 8720, 1266, 40, 4);
  o.obj('monitor', 8900, 1290, { item: 'shield' });
  o.ringArc(9020, 1266, 9110, 1266, 40, 4);
  o.ringArc(9310, 1266, 9500, 1400 - 30, 30, 5);
  // Долина (низ развилки 2)
  o.ringTrail(7120, 5, 22);
  o.obj('enemy', 7460, null, { kind: 'crab', range: 70 });
  o.obj('spikes', 7680, null, { n: 3 });
  o.ringArc(7650, 1496, 7760, 1496, 50, 4);
  o.obj('enemy', 7940, null, { kind: 'beetle', range: 120 });
  o.ringTrail(8120, 4, 22);
  // Озеро с рушащимися платформами
  var cx;
  for (cx = 8300; cx <= 9140; cx += 120) {
    o.obj('collapse', cx, 1496, { w: 64 });
    if (cx < 9140) o.ringArc(cx + 20, 1474, cx + 100, 1474, 40, 3);
  }
  o.obj('enemy', 8480, 1530, { kind: 'fish' });
  o.obj('enemy', 8840, 1530, { kind: 'fish' });
  // ---- После озера
  o.obj('monitor', 9560, null, { item: 'rings' });
  o.obj('checkpoint', 9850);
  o.ringTrail(10000, 6, 24, 30);
  // ---- Штопор
  for (cx = 10260; cx < 10640; cx += 32) {
    var t = (cx - 10240) / 400;
    o.ring(cx, 1320 - 24 - 72 * (1 - Math.cos(t * Math.PI * 2)) / 2);
  }
  // ---- Спуск и петля 2
  o.ringTrail(10760, 6, 22, 48);
  o.ringCircle(11360, 1424, 72, 12, -Math.PI / 2);
  o.obj('monitor', 11640, null, { item: 'rings' });
  o.obj('enemy', 11800, null, { kind: 'crab', range: 70 });
  o.ringTrail(11950, 6, 24, 30);
  o.obj('enemy', 12250, null, { kind: 'beetle', range: 100 });
  // ---- Развилка 3: верх (движущиеся платформы)
  o.obj('mover', 12480, 1376, { w: 64, dx: 0, dy: -200, period: 240 });
  o.obj('mover', 12600, 1240, { w: 64, dx: 0, dy: -150, period: 240, phase: 0.5 });
  o.ringLine(12480, 1240, 3, 0, -40);
  o.ringLine(12720, 1096, 6);
  o.obj('monitor', 13000, 1120, { item: 'shoes' });
  o.obj('enemy', 12900, 1120, { kind: 'beetle', range: 60 });
  o.obj('mover', 13280, 1120, { w: 72, dx: 60, dy: 0, period: 200 });
  o.ringLine(13240, 1090, 4, 28);
  o.ringLine(13440, 1096, 8, 28);
  o.ringArc(13900, 1100, 14040, 1376, 20, 5);
  // Развилка 3: низ (яма, шипы, оса)
  o.ringArc(12880, 1376, 13050, 1376, 70, 6);
  o.obj('spikes', 13200, null, { n: 3 });
  o.obj('enemy', 13420, 1330, { kind: 'wasp' });
  o.obj('monitor', 13500, null, { item: 'rings' });
  o.obj('spikes', 13620, null, { n: 2 });
  o.obj('enemy', 13700, null, { kind: 'beetle', range: 60 });
  // ---- Финальный отрезок
  o.obj('checkpoint', 14100);
  o.ringTrail(14240, 6, 24, 40);
  o.obj('spring', 14600, null, { color: 'red' });        // тайник колец в небе
  o.ringLine(14600, 1240, 6, 0, -44);
  o.obj('enemy', 14880, null, { kind: 'beetle', range: 60 });
  o.ringArc(15140, 1376, 15310, 1376, 60, 6);
  // ---- Утёсы-ступени
  o.ringArc(15440, 1376, 15560, 1296, 50, 5);
  o.obj('enemy', 15720, null, { kind: 'beetle', range: 60 });
  o.ringArc(15808, 1296, 15928, 1216, 50, 5);
  o.obj('spring', 16000, null, { color: 'red' });           // тайник колец над уступом
  o.ringLine(16000, 1120, 5, 0, -44);
  o.obj('enemy', 16120, 1180, { kind: 'wasp' });
  o.obj('monitor', 16220, null, { item: 'rings' });
  // ---- S-образный спуск
  o.ringTrail(16320, 10, 22, 44);
  o.obj('enemy', 16640, 1190, { kind: 'wasp' });
  o.ringTrail(16860, 8, 22, 44);
  o.obj('enemy', 17440, null, { kind: 'crab', range: 60 });
  // ---- Ямы: платформа-челнок и островок
  o.obj('mover', 17640, 1400, { w: 64, dx: 80, dy: 0, period: 200 });
  o.ringArc(17580, 1376, 17780, 1376, 50, 7);
  o.ringArc(18000, 1376, 18100, 1336, 40, 4);
  o.ringArc(18100, 1336, 18210, 1376, 40, 4);
  o.obj('mover', 18240, 1376, { w: 64, dx: 0, dy: -200, period: 260 });
  o.ringLine(18300, 1156, 6);
  o.obj('monitor', 18420, 1180, { item: 'shield' });
  o.obj('checkpoint', 18360);
  o.obj('monitor', 18440, null, { item: 'rings' });
  // ---- Дополнительная зона: длинные развилки и новые испытания
  o.obj('checkpoint', 19800); o.ringTrail(19920, 8, 24, 34);
  o.obj('enemy', 20200, null, { kind: 'beetle', range: 90 });
  o.obj('spring', 20340, null, { color: 'red' }); o.ringArc(20360, 1300, 20520, 1160, 72, 7);
  o.obj('monitor', 20740, 1080, { item: 'shield' }); o.obj('enemy', 21040, 1160, { kind: 'wasp' });
  o.ringTrail(21320, 9, 24, 36); o.obj('spikes', 21720, null, { n: 4 });
  o.obj('mover', 22000, 1370, { w: 76, dx: 100, dy: -120, period: 220 });
  o.obj('checkpoint', 22400); o.ringLine(22480, 1040, 7, 30, -8);
  o.obj('enemy', 22920, 960, { kind: 'wasp' }); o.obj('monitor', 23120, null, { item: 'rings' });
  o.obj('spikes', 23480, null, { n: 3 }); o.obj('enemy', 23600, null, { kind: 'crab', range: 100 });
  o.ringTrail(23960, 8, 24, 34); o.obj('spring', 24200, null, { color: 'yellow' });
  o.obj('enemy', 24780, 1200, { kind: 'beetle', range: 80 }); o.obj('monitor', 25040, 1080, { item: 'shoes' });
  o.obj('checkpoint', 25580); o.ringArc(25720, 1376, 25920, 1290, 68, 8);
  o.obj('mover', 26120, 1200, { w: 84, dx: 120, dy: 0, period: 180 });
  o.obj('enemy', 26500, null, { kind: 'wasp' }); o.ringTrail(26620, 8, 24, 38);
  // ---- Финальная арена босса, капсула и табличка в конце большой карты
  // Продолжение уровня после прежнего финального участка.
  // Ровная базовая трасса с уступами, кольцами, пружинами и противниками.
  B.pen(28400, 1400).flat(29200).end();
  for (var zone = 0; zone < 8; zone++) {
    var zx = 29000 + zone * 3400;
    o.ringTrail(zx, 12, 34, 34);
    o.obj('checkpoint', zx + 520);
    o.obj('enemy', zx + 900, null, { kind: zone % 2 ? 'wasp' : 'beetle', range: 100 });
    o.obj('spring', zx + 1320, null, { color: zone % 2 ? 'red' : 'yellow' });
    o.ringArc(zx + 1340, 1320, zx + 1600, 1120, 80, 9);
    o.obj('spikes', zx + 2050, null, { n: 3 + (zone % 2) });
    o.obj('monitor', zx + 2450, 1080, { item: zone % 2 ? 'shield' : 'rings' });
    o.obj('mover', zx + 2850, 1260, { w: 90, dx: 110, dy: -90, period: 180 + zone * 8 });
  }
  o.obj('boss', 54800, 1400, { arenaX0: 54580, arenaX1: 55140 });
  o.obj('capsule', 56200, 1400);
  o.obj('signpost', 56800, 1400);

  /* ======================= ДЕКОР ======================= */
  var palms = [180, 880, 1640, 2420, 3520, 4330, 5660, 6520, 7160, 9420, 9980, 11060, 11980, 12320, 14260, 14700, 15460, 16240, 17200, 18160, 19020, 19580, 20120, 20880, 21560, 22480, 23240, 24080, 24920, 25840, 26640, 27680, 28240];
  for (var px = 30000; px < 56800; px += 720) palms.push(px);
  palms.forEach(function (x, i) { o.deco('palm', x, null, { h: 70 + (i * 37) % 40, flip: i % 2 }); });
  for (var x = 120; x < 56800; x += 150) {
    if ((x > 17580 && x < 17780) || (x > 17980 && x < 18220) || (x > 15120 && x < 15300)) continue;
    if (x > 8200 && x < 9300) continue;            // озеро
    if (x > 3740 && x < 4300) continue;            // мост
    if (x > 10200 && x < 10680) continue;          // штопор
    var k = (x * 7) % 5;
    o.deco(k < 2 ? 'sunflower' : 'flower', x + (k * 13) % 40, null, { phase: x * 0.013 });
  }
  o.deco('waterfall', 7080, 1340, { h: 180 });
  o.deco('waterfall', 9206, 1490, { h: 80 });
  o.deco('waterfall', 3772, 1404, { h: 108, w: 14 });
  o.deco('totem', 2660, null, {});
  o.deco('totem', 6560, 1240, {});
  o.deco('totem', 12420, null, {});
  o.deco('totem', 18468, null, {});
  o.deco('totem', 18932, null, {});

  // Нижняя страховочная плита: не даёт камере/герою провалиться в пустоту при пропущенной коллизии.
  B.pen(-32, H - 28).flat(W + 64).end({ style: 'rock', noLine: true });

  return {
    W: W, H: H, name: 'PALM VALLEY + LOST COAST + MEGA ROUTE',
    terrain: B.terrain,
    objects: B.objects,
    decor: B.decor,
    loops: B.loops,
    corks: B.corks,
    water: B.water,
    secrets: B.secrets,
    start: { x: 96, y: G - 19 },
    camMaxY: H - TH.H,
    builder: B
  };
};
