/* ==========================================================================
   camera.js — камера: опережение по скорости, вертикальная «мёртвая зона»,
   взгляд вверх/вниз, плавно сдвигающиеся границы (арена, финиш)
   ========================================================================== */
'use strict';

TH.Camera = function (level) {
  this.level = level;
  this.x = 0; this.y = 0;
  this.look = 0;          // текущее опережение по горизонтали
  this.lookV = 0;         // смещение при взгляде вверх/вниз
  // Границы (текущие и целевые — сдвигаются плавно)
  this.minX = 0; this.maxX = level.W - TH.W; this.minY = 0; this.maxY = level.camMaxY;
  this.tMinX = this.minX; this.tMaxX = this.maxX;
  this.shake = 0;
  this.fixY = null;       // фиксированная высота (арена босса)
};
TH.Camera.prototype = {
  snap: function (p) {
    this.look = 0; this.lookV = 0;
    this.x = TH.clamp(p.x - TH.W / 2, this.minX, this.maxX);
    this.y = TH.clamp(p.y - TH.H / 2 + 8, this.minY, this.maxY);
  },
  setBounds: function (minX, maxX, instant) {
    this.tMinX = minX; this.tMaxX = maxX;
    if (instant) { this.minX = minX; this.maxX = maxX; return; }
    // Текущая граница сразу «подтягивается» к камере, дальше сдвигается плавно
    if (minX > this.minX) this.minX = Math.min(minX, Math.max(this.minX, this.x));
    if (maxX < this.maxX) this.maxX = Math.max(maxX, Math.min(this.maxX, this.x));
  },
  update: function (p) {
    // Границы приближаются к целевым плавно (без рывков)
    this.minX = TH.approach(this.minX, this.tMinX, 4);
    this.maxX = TH.approach(this.maxX, this.tMaxX, 4);
    if (this.shake > 0) this.shake--;
    if (p.dead) return;

    // --- Горизонталь: опережение в сторону движения
    var spd = p.ground ? p.gsp * Math.cos(p.angle) : p.xsp;
    var targetLook = TH.clamp(spd * 10, -72, 72);
    this.look += (targetLook - this.look) * 0.05;
    if (p.camLag > 0) { p.camLag--; }
    else {
      var tx = p.x - TH.W / 2 + this.look;
      var dx = tx - this.x;
      var maxStep = 24;
      // Мёртвая зона по горизонтали ±8 пикселей
      if (Math.abs(dx) > 8) this.x += TH.clamp(dx - TH.sign(dx) * 8, -maxStep, maxStep);
    }

    // --- Вертикаль: взгляд вверх/вниз
    var y0 = this.y;
    if (p.state === 'lookup' && p.lookT > 60) this.lookV = Math.max(this.lookV - 2, -88);
    else if (p.state === 'crouch' && p.lookT < -60) this.lookV = Math.min(this.lookV + 2, 88);
    else this.lookV = TH.approach(this.lookV, 0, 2);
    var cyTarget = p.y + (p.ball ? -5 : 0) + this.lookV;
    var screenY = cyTarget - this.y;
    var center = TH.H / 2 - 8;
    if (p.ground) {
      // На земле — держим героя по центру, скорость ограничена
      var dy = screenY - center;
      var lim = Math.abs(p.ysp) > 6 ? 24 : 6;
      if (this.lookV !== 0) lim = 6;
      this.y += TH.clamp(dy, -lim, lim);
    } else {
      // В воздухе — «мёртвая зона» ±32 пикселя
      if (screenY < center - 32) this.y += Math.max(screenY - (center - 32), -24);
      else if (screenY > center + 32) this.y += Math.min(screenY - (center + 32), 24);
    }
    if (this.fixY !== null) this.y = TH.approach(y0, this.fixY, 3);
    this.x = TH.clamp(this.x, this.minX, this.maxX);
    this.y = TH.clamp(this.y, this.minY, this.maxY);
  },
  /** Смещение для дрожания экрана */
  offset: function () {
    if (this.shake <= 0) return [0, 0];
    return [Math.round(TH.rand(-2, 2)), Math.round(TH.rand(-2, 2))];
  }
};
