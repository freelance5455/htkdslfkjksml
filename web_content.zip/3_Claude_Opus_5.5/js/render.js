/* ==========================================================================
   render.js — отрисовка мира: фон, декор, ландшафт, объекты, герой,
   передний план (штопор, вода, секретные накладки), отладочный оверлей (F2)
   ========================================================================== */
'use strict';

TH.Renderer = function (ctx, level) {
  this.ctx = ctx;
  this.level = level;
  this.bg = new TH.Background();
  this.art = new TH.TerrainArt(level.terrain);
  // Узор земли для накладок секретов (создаётся на основном контексте)
  var c = TH.makeCanvas(32, 32), g = c.getContext('2d');
  for (var y = 0; y < 2; y++) for (var x = 0; x < 2; x++) {
    g.fillStyle = (x + y) % 2 ? '#8f4519' : '#c46a2e'; g.fillRect(x * 16, y * 16, 16, 16);
    g.fillStyle = 'rgba(255,220,160,.22)'; g.fillRect(x * 16, y * 16, 16, 2); g.fillRect(x * 16, y * 16, 2, 16);
    g.fillStyle = 'rgba(60,20,0,.28)'; g.fillRect(x * 16, y * 16 + 14, 16, 2); g.fillRect(x * 16 + 14, y * 16, 2, 16);
  }
  this.groundPat = ctx.createPattern(c, 'repeat');
};

TH.Renderer.prototype = {
  draw: function (game) {
    var g = this.ctx, cam = game.camera;
    var sh = cam.offset();
    var cx = Math.round(cam.x) + sh[0], cy = Math.round(cam.y) + sh[1];
    var f = game.frame;
    this.bg.draw(g, cx, cy, f);
    this.drawDecor(g, cx, cy, f, game);
    this.drawCork(g, cx, cy, false);
    this.art.draw(g, cx, cy);
    // Объекты (с отсечением по экрану)
    var objs = game.objects;
    for (var i = 0; i < objs.length; i++) {
      var o = objs[i];
      if (!o.alive || !o.draw) continue;
      if (o.type !== 'boss' && (o.x < cx - 96 || o.x > cx + TH.W + 96)) continue;
      o.draw(g, cx, cy, game);
    }
    game.player.draw(g, cx, cy);
    this.drawCork(g, cx, cy, true);
    this.drawWater(g, cx, cy, f);
    this.drawSecrets(g, cx, cy, game);
    game.particles.draw(g, cx, cy);
    if (game.debug) this.drawDebug(g, cx, cy, game);
  },

  /* ---------------- Декор ---------------- */
  drawDecor: function (g, cx, cy, f, game) {
    var D = this.level.decor, S = TH.Sprites;
    for (var i = 0; i < D.length; i++) {
      var d = D[i], x = Math.round(d.x - cx), y = Math.round(d.y - cy);
      if (x < -80 || x > TH.W + 80 || y < -20 || y > TH.H + 200) continue;
      switch (d.kind) {
        case 'palm': {
          var h = d.h, sway = Math.sin(f * 0.03 + d.x) * 2;
          g.strokeStyle = '#5a3a1a'; g.lineWidth = 6; g.lineCap = 'round';
          g.beginPath(); g.moveTo(x, y + 4); g.quadraticCurveTo(x + (d.flip ? -12 : 12), y - h / 2, x + sway, y - h); g.stroke();
          g.strokeStyle = '#9a6a3a'; g.lineWidth = 2;
          for (var s = 8; s < h; s += 8) {
            var t = s / h, px = x * (1 - t) * (1 - t) + 2 * t * (1 - t) * (x + (d.flip ? -12 : 12)) + t * t * (x + sway);
            g.beginPath(); g.moveTo(px - 3, y - s); g.lineTo(px + 3, y - s + 1); g.stroke();
          }
          var tx = x + sway, ty = y - h;
          for (var k = 0; k < 7; k++) {
            var a = -Math.PI / 2 + (k - 3) * 0.5 + Math.sin(f * 0.04 + k) * 0.05;
            var lx = tx + Math.cos(a) * 34, ly = ty + Math.sin(a) * 20 + 16;
            g.fillStyle = k % 2 ? '#1f8a2a' : '#2fae3a';
            g.beginPath(); g.moveTo(tx, ty);
            g.quadraticCurveTo(tx + Math.cos(a) * 20, ty + Math.sin(a) * 22 - 8, lx, ly);
            g.quadraticCurveTo(tx + Math.cos(a) * 18, ty + Math.sin(a) * 12, tx, ty + 3);
            g.fill();
          }
          S.ell(g, tx - 3, ty + 3, 3, 3, '#6a3a10'); S.ell(g, tx + 3, ty + 4, 3, 3, '#7a4a18');
          break;
        }
        case 'sunflower': {
          var sw = Math.sin(f * 0.05 + d.phase) * 0.15;
          g.save(); g.translate(x, y); g.rotate(sw);
          g.strokeStyle = '#1d7a1d'; g.lineWidth = 2; g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -26); g.stroke();
          S.ell(g, -4, -12, 4, 2, '#2fae3a', null, -0.5);
          g.translate(0, -30);
          g.rotate(f * 0.01 + d.phase);
          g.fillStyle = '#ffd000';
          for (var pp = 0; pp < 8; pp++) { g.rotate(Math.PI / 4); g.fillRect(-1.5, -9, 3, 5); }
          S.ell(g, 0, 0, 4.5, 4.5, '#8a4a10', '#3a1a00');
          g.restore();
          break;
        }
        case 'flower': {
          var b = Math.sin(f * 0.07 + d.phase) * 1.5;
          g.strokeStyle = '#1d7a1d'; g.lineWidth = 1; g.beginPath(); g.moveTo(x, y); g.lineTo(x + b, y - 11); g.stroke();
          var col = (Math.floor(d.x) % 3) === 0 ? '#d040ff' : '#ff5090';
          for (var q = 0; q < 4; q++) S.ell(g, x + b + Math.cos(q * 1.57 + f * 0.02) * 3, y - 12 + Math.sin(q * 1.57 + f * 0.02) * 3, 2, 2, col);
          S.ell(g, x + b, y - 12, 1.5, 1.5, '#fff070');
          break;
        }
        case 'waterfall': {
          var w = d.w || 20, hh = d.h;
          g.fillStyle = 'rgba(180,225,255,.85)'; g.fillRect(x, y, w, hh);
          g.fillStyle = 'rgba(255,255,255,.8)';
          for (var r = 0; r < hh; r += 6) {
            var o = (r + f * 2) % hh;
            g.fillRect(x + ((r * 7) % (w - 2)), y + o, 2, 5);
          }
          g.fillStyle = '#5aa8e8'; g.fillRect(x, y, 2, hh); g.fillRect(x + w - 2, y, 2, hh);
          // Пена внизу
          for (var fo = 0; fo < 4; fo++) S.ell(g, x + w / 2 + Math.sin(f * 0.3 + fo) * w * 0.4, y + hh, 4 + fo % 2 * 2, 3, 'rgba(255,255,255,.85)');
          break;
        }
        case 'totem': {
          for (var tt = 0; tt < 3; tt++) {
            var ty2 = y - 16 - tt * 16;
            g.fillStyle = tt % 2 ? '#c06020' : '#e08a30'; g.fillRect(x - 8, ty2, 16, 16);
            g.fillStyle = '#3a1a08'; g.fillRect(x - 5, ty2 + 4, 3, 3); g.fillRect(x + 2, ty2 + 4, 3, 3); g.fillRect(x - 4, ty2 + 10, 8, 2);
            g.fillStyle = 'rgba(255,255,255,.25)'; g.fillRect(x - 8, ty2, 16, 2);
          }
          g.fillStyle = '#2fae3a'; g.fillRect(x - 12, y - 52, 24, 4);
          break;
        }
      }
    }
  },

  /* ---------------- Штопор (задняя и передняя половины) ---------------- */
  drawCork: function (g, cx, cy, front) {
    var cs = this.level.corks;
    for (var i = 0; i < cs.length; i++) {
      var c = cs[i];
      if (c.x1 < cx - 20 || c.x0 > cx + TH.W + 20) continue;
      var L = c.x1 - c.x0;
      for (var x = c.x0 - 16; x < c.x1 + 16; x += 4) {
        var t = TH.clamp((x - c.x0) / L, 0, 1), phi = t * Math.PI * 2;
        var isFront = Math.cos(phi) > 0;     // нижняя часть витка — перед героем
        if (isFront !== front) continue;
        var y = c.y - c.h * (1 - Math.cos(phi)) / 2;
        var sx = Math.round(x - cx), sy = Math.round(y - cy);
        var chk = ((x >> 4) % 2) === 0;
        g.fillStyle = front ? (chk ? '#c46a2e' : '#8f4519') : (chk ? '#7a4018' : '#5a2c10');
        g.fillRect(sx, sy, 4, 14);
        g.fillStyle = front ? '#38a92a' : '#1d6b16';
        g.fillRect(sx, sy, 4, 4);
        if (front) { g.fillStyle = '#7ee05a'; g.fillRect(sx, sy, 4, 1); }
      }
      // Опоры
      if (!front) {
        [c.x0 + L * 0.5].forEach(function (px) {
          var sx = Math.round(px - cx), top = Math.round(c.y - c.h - cy + 14);
          g.fillStyle = '#5a3a1a'; g.fillRect(sx - 3, top, 6, c.h - 14);
        });
      }
    }
  },

  /* ---------------- Вода ---------------- */
  drawWater: function (g, cx, cy, f) {
    var ws = this.level.water;
    for (var i = 0; i < ws.length; i++) {
      var w = ws[i];
      var x0 = Math.round(w.x0 - cx), x1 = Math.round(w.x1 - cx), y = Math.round(w.y - cy);
      if (x1 < 0 || x0 > TH.W || y > TH.H) continue;
      x0 = Math.max(x0, 0); x1 = Math.min(x1, TH.W);
      g.fillStyle = 'rgba(40,120,220,.55)'; g.fillRect(x0, y, x1 - x0, TH.H - y + 2);
      g.fillStyle = 'rgba(20,70,170,.35)'; g.fillRect(x0, y + 24, x1 - x0, TH.H);
      // Волнистая поверхность и блики
      for (var x = x0; x < x1; x += 2) {
        var wy = Math.round(Math.sin((x + cx) * 0.08 + f * 0.1) * 1.5);
        g.fillStyle = 'rgba(220,245,255,.9)'; g.fillRect(x, y + wy - 1, 2, 2);
      }
      for (var k = 0; k < 10; k++) {
        var gx = ((k * 53 + f * 0.6 - cx * 0.2) % (x1 - x0 + 1) + (x1 - x0 + 1)) % (x1 - x0 + 1) + x0;
        if ((f + k * 7) % 40 < 20) { g.fillStyle = '#fff'; g.fillRect(Math.round(gx), y + 6 + (k * 5) % 20, 4, 1); }
      }
    }
  },

  /* ---------------- Накладки секретов ---------------- */
  drawSecrets: function (g, cx, cy, game) {
    var p = game.player;
    var S = this.level.secrets;
    for (var i = 0; i < S.length; i++) {
      var s = S[i];
      var inside = p.x > s.x - 6 && p.x < s.x + s.w + 6 && p.y > s.y - 4 && p.y < s.y + s.h + 4;
      s.alpha = TH.approach(s.alpha, inside ? 0 : 1, 0.08);
      if (s.alpha <= 0) continue;
      var x = Math.round(s.x - cx), y = Math.round(s.y - cy);
      if (x > TH.W || x + s.w < 0 || y > TH.H || y + s.h < 0) continue;
      g.save();
      g.globalAlpha = s.alpha;
      g.translate(-cx, -cy);
      g.fillStyle = this.groundPat;
      g.fillRect(s.x, s.y, s.w, s.h);
      // Трава по верхнему краю
      g.fillStyle = '#4a240c'; g.fillRect(s.x, s.y, s.w, 17);
      g.fillStyle = '#1d6b16'; g.fillRect(s.x, s.y, s.w, 13);
      g.fillStyle = '#38a92a'; g.fillRect(s.x, s.y, s.w, 9);
      g.fillStyle = '#7ee05a'; g.fillRect(s.x, s.y, s.w, 3);
      g.fillStyle = 'rgba(50,20,5,.55)'; g.fillRect(s.x, s.y, 2, s.h);
      g.restore();
    }
  },

  /* ---------------- Отладка (F2) ---------------- */
  drawDebug: function (g, cx, cy, game) {
    var p = game.player, T = game.terrain;
    // Хитбокс героя
    var hb = p.hitbox();
    g.strokeStyle = '#ff00ff'; g.lineWidth = 1;
    g.strokeRect(Math.round(hb[0] - cx) + 0.5, Math.round(hb[1] - cy) + 0.5, hb[2] - hb[0], hb[3] - hb[1]);
    // Сенсоры A/B в системе режима
    var m = p.ground ? p.mode : 0;
    var dx = TH.DX[m], dy = TH.DY[m], tx = TH.TX[m], ty = TH.TY[m];
    for (var s = -1; s <= 1; s += 2) {
      var ox = p.x + tx * p.wr * s, oy = p.y + ty * p.wr * s;
      var ex = ox + dx * (p.hr + 14), ey = oy + dy * (p.hr + 14);
      g.strokeStyle = s < 0 ? '#00ff60' : '#30c0ff';
      g.beginPath(); g.moveTo(ox - cx, oy - cy); g.lineTo(ex - cx, ey - cy); g.stroke();
    }
    // Боковые сенсоры
    g.strokeStyle = '#ff4040';
    g.beginPath(); g.moveTo(p.x - 10 - cx, p.y - cy); g.lineTo(p.x + 10 - cx, p.y - cy); g.stroke();
    // Хитбоксы врагов и босса
    g.strokeStyle = '#ffff00';
    for (var i = 0; i < game.objects.length; i++) {
      var o = game.objects[i];
      if (!o.alive) continue;
      if (o.type === 'enemy') g.strokeRect(Math.round(o.x - o.hw - cx) + 0.5, Math.round(o.y + o.cyOff - o.hh - cy) + 0.5, o.hw * 2, o.hh * 2);
      if (o.type === 'boss' && o.state === 'fight') {
        g.strokeRect(Math.round(o.x - 26 - cx) + 0.5, Math.round(o.y - 22 - cy) + 0.5, 52, 36);
        g.beginPath(); g.arc(o.bx - cx, o.by - cy, o.ballR, 0, Math.PI * 2); g.stroke();
      }
    }
    var F = TH.Font, y = 30, lines = [
      'FPS ' + game.fps,
      'X ' + p.x.toFixed(1) + ' Y ' + p.y.toFixed(1),
      'GSP ' + p.gsp.toFixed(3),
      'XSP ' + p.xsp.toFixed(2) + ' YSP ' + p.ysp.toFixed(2),
      'ANGLE ' + (-p.angle * 180 / Math.PI).toFixed(1),
      'MODE ' + (p.ground ? TH.MODE_NAMES[p.mode] : 'AIR'),
      'STATE ' + p.state + ' ' + p.pose(),
      'LAYER ' + (p.layer ? 'B' : 'A') + (p.groundObj ? ' OBJ ' + p.groundObj.type : ''),
      'OBJS ' + game.objects.length + ' MASKS ' + T.masks.length
    ];
    g.fillStyle = 'rgba(0,0,0,.55)'; g.fillRect(TH.W - 158, y - 3, 156, lines.length * 9 + 4);
    for (i = 0; i < lines.length; i++) F.draw(g, lines[i], TH.W - 154, y + i * 9, '#a0ffa0');
  }
};
