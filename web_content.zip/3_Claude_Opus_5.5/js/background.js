/* ==========================================================================
   background.js — параллакс: небо, облака, дальние горы с водопадами,
   зелёные холмы, океан с бликами (построчный сдвиг), ближние пальмы.
   Статичные слои заранее отрисованы в offscreen-canvas.
   ========================================================================== */
'use strict';

TH.Background = function () {
  this.SW = 512;
  this.sky = this.makeSky();
  this.clouds = this.makeClouds();
  this.mount = this.makeMountains();
  this.hills = this.makeHills();
  this.ocean = [0, 1, 2, 3].map(this.makeOcean, this);
  this.palms = this.makePalms();
};
TH.Background.prototype = {
  makeSky: function () {
    var c = TH.makeCanvas(TH.W, TH.H), g = c.getContext('2d');
    var gr = g.createLinearGradient(0, 0, 0, TH.H);
    gr.addColorStop(0, '#1d58d8'); gr.addColorStop(0.35, '#3d86f0'); gr.addColorStop(0.6, '#8cc8ff'); gr.addColorStop(0.75, '#e0f4ff'); gr.addColorStop(1, '#e0f4ff');
    g.fillStyle = gr; g.fillRect(0, 0, TH.W, TH.H);
    // Полосы в стиле 16-бит (дизеринг горизонта)
    for (var y = 100; y < 150; y += 4) { g.fillStyle = 'rgba(255,255,255,' + ((y - 100) / 200) + ')'; g.fillRect(0, y, TH.W, 2); }
    return c;
  },
  makeClouds: function () {
    var c = TH.makeCanvas(this.SW, 90), g = c.getContext('2d');
    var cl = [[40, 30, 1], [170, 55, 0.7], [300, 20, 1.2], [420, 60, 0.8], [480, 35, 0.6]];
    cl.forEach(function (k) {
      var x = k[0], y = k[1], s = k[2];
      for (var i = 0; i < 6; i++) {
        var px = x + (i - 2.5) * 12 * s, py = y + Math.sin(i * 1.7) * 4 * s, r = (10 + (i % 3) * 4) * s;
        g.fillStyle = '#b8d8f8'; g.beginPath(); g.arc(px, py + 3, r, 0, Math.PI * 2); g.fill();
      }
      for (i = 0; i < 6; i++) {
        var qx = x + (i - 2.5) * 12 * s, qy = y + Math.sin(i * 1.7) * 4 * s, rr = (10 + (i % 3) * 4) * s;
        g.fillStyle = '#ffffff'; g.beginPath(); g.arc(qx, qy, rr * 0.9, 0, Math.PI * 2); g.fill();
      }
    });
    return c;
  },
  makeMountains: function () {
    var c = TH.makeCanvas(this.SW, 120), g = c.getContext('2d');
    // Дальний ряд
    g.fillStyle = '#7c88d8';
    g.beginPath(); g.moveTo(0, 120);
    for (var x = 0; x <= this.SW; x += 8) g.lineTo(x, 50 + Math.sin(x * 0.02) * 18 + Math.sin(x * 0.053) * 10);
    g.lineTo(this.SW, 120); g.fill();
    // Ближний ряд — бирюзово-зелёные скалы
    g.fillStyle = '#3c9a8a';
    g.beginPath(); g.moveTo(0, 120);
    for (x = 0; x <= this.SW; x += 8) g.lineTo(x, 70 + Math.sin(x * 0.0245 + 1) * 16 + Math.sin(x * 0.07) * 6);
    g.lineTo(this.SW, 120); g.fill();
    g.fillStyle = '#5ab89c';
    for (x = 0; x <= this.SW; x += 8) { var yy = 70 + Math.sin(x * 0.0245 + 1) * 16 + Math.sin(x * 0.07) * 6; g.fillRect(x, yy, 8, 3); }
    // Полосы-страты
    g.fillStyle = 'rgba(0,40,60,.18)';
    for (var y = 84; y < 120; y += 7) g.fillRect(0, y, this.SW, 2);
    return c;
  },
  makeHills: function () {
    var c = TH.makeCanvas(this.SW, 70), g = c.getContext('2d');
    g.fillStyle = '#1f8a3a';
    g.beginPath(); g.moveTo(0, 70);
    for (var x = 0; x <= this.SW; x += 4) g.lineTo(x, 26 + Math.sin(x * 0.03) * 12 + Math.sin(x * 0.011) * 8);
    g.lineTo(this.SW, 70); g.fill();
    g.fillStyle = '#2fb04a';
    for (x = 0; x <= this.SW; x += 4) g.fillRect(x, 26 + Math.sin(x * 0.03) * 12 + Math.sin(x * 0.011) * 8, 4, 3);
    // Шахматный обрыв холмов (отсылка к земле уровня)
    for (var yy = 44; yy < 70; yy += 8) for (x = 0; x < this.SW; x += 8) {
      if (((x + yy) / 8) % 2 === 0) { g.fillStyle = 'rgba(120,60,20,.35)'; g.fillRect(x, yy, 8, 8); }
    }
    return c;
  },
  makeOcean: function (f) {
    var c = TH.makeCanvas(this.SW, 48), g = c.getContext('2d');
    var gr = g.createLinearGradient(0, 0, 0, 48);
    gr.addColorStop(0, '#5aa8f0'); gr.addColorStop(1, '#1a58c0');
    g.fillStyle = gr; g.fillRect(0, 0, this.SW, 48);
    for (var y = 2; y < 48; y += 5) { g.fillStyle = 'rgba(255,255,255,.12)'; g.fillRect(0, y, this.SW, 1); }
    // Блики (4 кадра анимации)
    for (var i = 0; i < 70; i++) {
      var x = (i * 97 + f * 23) % this.SW, yy = (i * 37) % 46 + 1;
      var w = 2 + (i + f) % 5;
      g.fillStyle = (i + f) % 3 === 0 ? '#ffffff' : 'rgba(220,240,255,.7)';
      g.fillRect(x, yy, w, 1);
    }
    return c;
  },
  makePalms: function () {
    var c = TH.makeCanvas(this.SW, 110), g = c.getContext('2d');
    // Кусты
    g.fillStyle = '#145a24';
    for (var x = -20; x < this.SW + 20; x += 26) { g.beginPath(); g.arc(x, 104 + Math.sin(x) * 3, 18, 0, Math.PI * 2); g.fill(); }
    // Пальмы-силуэты
    [60, 200, 330, 450].forEach(function (px, k) {
      var h = 60 + (k * 13) % 25;
      g.strokeStyle = '#6a4a2a'; g.lineWidth = 4;
      g.beginPath(); g.moveTo(px, 110); g.quadraticCurveTo(px + 8, 110 - h / 2, px + 4, 110 - h); g.stroke();
      g.fillStyle = '#1a7a30';
      for (var i = 0; i < 6; i++) {
        var a = -Math.PI / 2 + (i - 2.5) * 0.55;
        g.beginPath(); g.moveTo(px + 4, 110 - h);
        g.quadraticCurveTo(px + 4 + Math.cos(a) * 18, 110 - h + Math.sin(a) * 14 - 6, px + 4 + Math.cos(a) * 30, 110 - h + Math.sin(a) * 10 + 10);
        g.quadraticCurveTo(px + 4 + Math.cos(a) * 16, 110 - h + Math.sin(a) * 10, px + 4, 110 - h + 2);
        g.fill();
      }
    });
    return c;
  },
  /** Повторяющаяся по горизонтали полоса */
  strip: function (g, img, sx, y) {
    var w = this.SW;
    var off = -(((sx % w) + w) % w);
    for (var x = Math.round(off); x < TH.W; x += w) g.drawImage(img, x, Math.round(y));
  },
  draw: function (g, camX, camY, frame) {
    var vy = TH.clamp(-(camY - 1160) * 0.07, -28, 28);
    g.drawImage(this.sky, 0, 0);
    this.strip(g, this.clouds, camX * 0.05 + frame * 0.12, 4 + vy * 0.3);
    this.strip(g, this.mount, camX * 0.1, 40 + vy * 0.5);
    // Водопады в горах (анимированные)
    for (var k = 0; k < 3; k++) {
      var wx = ((k * 190 + 90 - camX * 0.1) % this.SW + this.SW) % this.SW;
      for (var rep = wx; rep < TH.W; rep += this.SW) {
        var top = 40 + vy * 0.5 + 64, h = 46;
        g.fillStyle = '#cfefff'; g.fillRect(Math.round(rep), Math.round(top), 6, h);
        g.fillStyle = '#7ec8f0';
        for (var s = 0; s < 6; s++) g.fillRect(Math.round(rep) + (s % 3) * 2, Math.round(top + ((frame * 1.5 + s * 9) % h)), 2, 4);
      }
    }
    var oceanY = 150 + vy * 0.7;
    this.strip(g, this.hills, camX * 0.16, oceanY - 52);
    // Океан: построчный сдвиг для глубины (эффект line scroll)
    var oc = this.ocean[(frame >> 3) % 4];
    for (var row = 0; row < 48; row += 3) {
      var f = 0.18 + row / 48 * 0.3;
      var off = -((((camX * f) % this.SW) + this.SW) % this.SW);
      for (var x = Math.round(off); x < TH.W; x += this.SW) g.drawImage(oc, 0, row, this.SW, 3, x, Math.round(oceanY + row), this.SW, 3);
    }
    g.fillStyle = '#1a58c0';
    g.fillRect(0, Math.round(oceanY + 48), TH.W, TH.H);
    this.strip(g, this.palms, camX * 0.4, oceanY + 2);
    g.fillStyle = '#145a24';
    g.fillRect(0, Math.round(oceanY + 110), TH.W, TH.H);
  }
};
