/* ==========================================================================
   boss.js — БАРОН БОЛТ: безумный учёный в летающей машине «Болт-коптер»
   с шаром-маятником на цепи. 8 попаданий; полоска здоровья в HUD.
   ========================================================================== */
'use strict';

TH.BOSS_NAME = 'BARON BOLT';
TH.BOSS_HP = 8;

TH.Obj.boss = function (d) {
  this.ax0 = d.arenaX0; this.ax1 = d.arenaX1; this.floorY = d.y;
  this.homeY = d.y - 128;
  this.x = this.ax1 + 120; this.y = this.homeY - 140;
  this.act = Math.max(1, Number(d.act || (game && game.act) || 1));
  this.maxHp = Math.max(8, Math.round(TH.BOSS_HP * (1 + (this.act - 1) * 0.32)));
  this.state = 'idle'; this.t = 0; this.hp = this.maxHp; this.flash = 0; this.dir = -1;
  this.swing = 0; this.chainLen = 70; this.ballR = 12;
  this.bx = this.x; this.by = this.y + 80;
  this.segBlink = new Array(this.maxHp).fill(0);
  this.alwaysActive = true;
  this.prop = 0; this.mood = 'normal';
};
TH.Obj.boss.prototype = {
  get anchorX() { return this.x; },
  get anchorY() { return this.y + 16; },
  update: function (game) {
    var p = game.player;
    this.t++; this.prop += 0.6;
    if (this.flash > 0) this.flash--;
    for (var i = 0; i < this.segBlink.length; i++) if (this.segBlink[i] > 0) this.segBlink[i]--;
    switch (this.state) {
      case 'idle':
        if (p.x > this.ax0 + 40 && !p.dead) {
          this.state = 'enter'; this.t = 0;
          game.startBoss(this);
        }
        break;
      case 'enter':
        // Вылетает справа сверху и занимает позицию
        this.x = TH.approach(this.x, this.ax1 - 90, 1.6);
        this.y = TH.approach(this.y, this.homeY, 1.2);
        this.swing = Math.sin(this.t * 0.04) * 0.3;
        if (this.x === this.ax1 - 90 && this.y === this.homeY) { this.state = 'fight'; this.t = 0; this.mood = 'laugh'; }
        break;
      case 'fight':
        if (this.t > 60) this.mood = 'normal';
        // Медленный полёт по арене; маятник раскачивается
        var speed = (this.hp <= this.maxHp * 0.5 ? 0.9 : 0.6) + this.act * 0.025;
        this.x += this.dir * speed;
        if (this.x < this.ax0 + 70) { this.x = this.ax0 + 70; this.dir = 1; }
        if (this.x > this.ax1 - 70) { this.x = this.ax1 - 70; this.dir = -1; }
        this.y = this.homeY + Math.sin(this.t * 0.05) * 6;
        var w = (this.hp <= this.maxHp * 0.5 ? 0.042 : 0.034) + this.act * 0.001;
        this.swing = Math.sin(this.t * w) * 1.15;
        this.collide(game, p);
        break;
      case 'defeated':
        // Серия взрывов
        if (this.t % 7 === 0) {
          game.particles.explosion(this.x + TH.rand(-28, 28), this.y + TH.rand(-24, 16), Math.random() < 0.4);
          TH.Audio.play('explosion');
        }
        this.y += 0.15;
        if (this.t > 150) { this.state = 'flee'; this.t = 0; this.mood = 'hurt'; }
        break;
      case 'flee':
        // Злодей улетает, дымя
        this.x += 2.2; this.y -= 0.9 + Math.sin(this.t * 0.2) * 0.4;
        if (this.t % 4 === 0) game.particles.smoke(this.x - 20, this.y + 6);
        if (this.t > 220) { this.state = 'gone'; game.bossGone(); }
        break;
    }
    // Положение шара
    if (this.state !== 'defeated' && this.state !== 'flee' && this.state !== 'gone') {
      this.bx = this.anchorX + Math.sin(this.swing) * this.chainLen;
      this.by = this.anchorY + Math.cos(this.swing) * this.chainLen;
    } else if (this.ballFall !== undefined) {
      this.ballVy += 0.25; this.by += this.ballVy;
      if (this.by > this.floorY - this.ballR) { this.by = this.floorY - this.ballR; this.ballVy = -this.ballVy * 0.4; }
    }
  },
  collide: function (game, p) {
    if (p.dead) return;
    var hb = p.hitbox();
    // Шар — опасен всегда
    var nx = TH.clamp(this.bx, hb[0], hb[2]), ny = TH.clamp(this.by, hb[1], hb[3]);
    if ((nx - this.bx) * (nx - this.bx) + (ny - this.by) * (ny - this.by) < this.ballR * this.ballR) game.hurtPlayer(this.bx);
    // Кабина
    if (this.flash > 0) return;
    if (TH.rectsOverlap(hb[0], hb[1], hb[2], hb[3], this.x - 26, this.y - 22, this.x + 26, this.y + 14)) {
      if (p.isAttacking()) this.hit(game, p);
      else game.hurtPlayer(this.x);
    }
  },
  hit: function (game, p) {
    this.hp--;
    this.flash = 40;
    this.segBlink[this.hp] = 40;
    this.mood = 'hurt';
    TH.Audio.play('bossHit');
    game.particles.sparkle(p.x, p.y, 6);
    game.addScore(100, null, null);
    // Отскок героя от кабины
    p.xsp = TH.sign(p.x - this.x) * 3.2 || 3.2;
    p.ysp = p.y < this.y ? -4.5 : 2;
    p.gsp = p.xsp;
    if (this.hp <= 0) {
      this.state = 'defeated'; this.t = 0;
      this.ballFall = true; this.ballVy = 0;
      game.addScore(1000, this.x, this.y - 30);
      game.bossDefeatedEvt(this);
    }
  },
  draw: function (g, cx, cy, game) {
    if (this.state === 'idle' || this.state === 'gone') return;
    var x = Math.round(this.x - cx), y = Math.round(this.y - cy);
    var S = TH.Sprites;
    // Цепь и шар
    if (this.state !== 'flee' || this.ballFall) {
      var ax = this.anchorX - cx, ay = this.anchorY - cy, bx = this.bx - cx, by = this.by - cy;
      if (!this.ballFall) {
        for (var i = 1; i < 8; i++) {
          var t = i / 8;
          S.ell(g, ax + (bx - ax) * t, ay + (by - ay) * t, 2.2, 2.2, '#9aa0b0', '#30343e');
        }
      }
      S.ell(g, bx, by, this.ballR, this.ballR, '#3a3e4a', '#0c0e14');
      // Шипы на шаре
      g.fillStyle = '#c8ccd8';
      for (i = 0; i < 8; i++) {
        var a = i * Math.PI / 4 + this.t * 0.02;
        g.beginPath();
        g.moveTo(bx + Math.cos(a) * 16, by + Math.sin(a) * 16);
        g.lineTo(bx + Math.cos(a + 0.25) * 10, by + Math.sin(a + 0.25) * 10);
        g.lineTo(bx + Math.cos(a - 0.25) * 10, by + Math.sin(a - 0.25) * 10);
        g.fill();
      }
      S.ell(g, bx - 4, by - 4, 4, 3, 'rgba(255,255,255,.35)');
    }
    var fl = this.flash > 0 && (this.flash >> 1) % 2;
    // Реактивное пламя снизу
    var fh = 6 + Math.sin(this.t * 0.8) * 3;
    g.fillStyle = '#ffb000';
    g.beginPath(); g.moveTo(x - 14, y + 12); g.lineTo(x - 10, y + 14 + fh); g.lineTo(x - 6, y + 12); g.fill();
    g.beginPath(); g.moveTo(x + 6, y + 12); g.lineTo(x + 10, y + 14 + fh); g.lineTo(x + 14, y + 12); g.fill();
    // Стеклянный купол и злодей
    g.save();
    g.beginPath(); g.ellipse(x, y - 8, 18, 18, 0, Math.PI, 0); g.closePath();
    g.fillStyle = 'rgba(160,220,255,.25)'; g.fill();
    g.clip();
    // Плечи: фиолетовый плащ с высоким воротником
    S.ell(g, x, y + 2, 13, 9, fl ? '#fff' : '#6a2aa8', '#2a0a50');
    g.fillStyle = fl ? '#fff' : '#ffcc00'; g.fillRect(x - 2, y - 6, 4, 8);
    S.villainFace(g, x + this.dirFace(), y - 12, 0.95, this.state === 'flee' || this.flash > 0 ? 'hurt' : this.mood);
    g.restore();
    g.strokeStyle = 'rgba(255,255,255,.7)'; g.lineWidth = 1;
    g.beginPath(); g.arc(x, y - 8, 18, Math.PI * 1.15, Math.PI * 1.45); g.stroke();
    // Корпус машины
    g.fillStyle = fl ? '#ffffff' : '#20242e';
    g.beginPath(); g.ellipse(x, y + 2, 29, 13, 0, 0, Math.PI * 2); g.fill();
    g.fillStyle = fl ? '#ffffff' : '#b8c0d4';
    g.beginPath(); g.ellipse(x, y + 1, 27, 11, 0, 0, Math.PI * 2); g.fill();
    g.fillStyle = fl ? '#ffe0e0' : '#e8ecf8'; g.fillRect(x - 22, y - 7, 44, 2);
    g.fillStyle = fl ? '#fff' : '#d01818'; g.fillRect(x - 27, y + 1, 54, 4);
    g.fillStyle = '#ffcc00';
    for (i = -2; i <= 2; i++) g.fillRect(x + i * 10 - 1, y + 7, 3, 2);
    // Лампочки
    g.fillStyle = (this.t >> 3) % 2 ? '#ff4040' : '#40ff60';
    g.fillRect(x - 25, y - 2, 3, 3); g.fillRect(x + 22, y - 2, 3, 3);
    // Пропеллер сверху
    var pw = Math.abs(Math.sin(this.prop)) * 20;
    g.fillStyle = '#555'; g.fillRect(x - 1, y - 30, 2, 5);
    g.fillStyle = 'rgba(80,80,90,.8)'; g.fillRect(x - pw, y - 31, pw * 2, 2);
  },
  dirFace: function () { return this.state === 'fight' ? this.dir * 1.5 : 0; }
};
