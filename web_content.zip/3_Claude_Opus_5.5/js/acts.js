/* Acts 1-20. Act 1 retains the authored Palm Valley map; later acts are generated as distinct routes. */
(function(){'use strict';
TH.ACT_COUNT=20;
TH.getSelectedAct=function(){var n=1;try{n=parseInt(localStorage.getItem('th_act')||'1',10)}catch(e){}return Math.max(1,Math.min(20,n||1))};
TH.selectAct=function(n){n=Math.max(1,Math.min(20,Math.floor(Number(n)||1)));try{localStorage.setItem('th_act',String(n))}catch(e){}return n};
TH.buildAct=function(n){n=Math.max(1,Math.min(20,Number(n)||1));if(n===1)return TH.buildPalmValley();
 var W=18000+n*420,H=1664,B=new TH.LevelBuilder(W,H),G=1400,o=B;
 // Solid continuous base prevents holes in the route; elevated ledges add variation.
 B.pen(-32,G).flat(W+64).end();
 for(var i=0;i<24+n;i++){
  var x=500+i*(W-1000)/(24+n), y=G-((i*37+n*53)%260), width=90+(i*29+n*17)%180;
  if(i%4===1)B.block(x,y,width,32,'rock');
  if(i%3===0)o.obj('enemy',x+width+70,null,{kind:['crab','beetle','wasp'][i%3],range:45+n*2});
  if(i%2===0)o.ringTrail(x+20,4+(n%4),22,24);
  if(i%5===0)o.obj('checkpoint',x+width+160);
  if(i%6===2)o.obj('spring',x+width+220,null,{color:i%2?'red':'yellow'});
  if(i%7===3)o.obj('spikes',x+width+290,null,{n:2+n%3});
 }
 // Guaranteed safe start, arena floor and boss encounter near the end.
 o.obj('checkpoint',W-2200);o.ringTrail(W-1900,8,28,26);
 o.obj('boss',W-1050,G,{arenaX0:W-1500,arenaX1:W-250,act:n});
 o.obj('capsule',W-150,G);o.obj('signpost',W-80,G);
 for(var d=300;d<W;d+=420)o.deco('palm',d,null,{h:65+(d%40)});
 return {W:W,H:H,name:'ACT '+n+' — '+['DARK HILL','SHADOW COAST','CHAOS RUINS','NIGHT FOREST','DEMON VALLEY'][((n-2)%5)],terrain:B.terrain,objects:B.objects,decor:B.decor,loops:B.loops,corks:B.corks,water:B.water,secrets:B.secrets,start:{x:96,y:G-19},camMaxY:H-TH.H,builder:B,act:n};
};
})();
