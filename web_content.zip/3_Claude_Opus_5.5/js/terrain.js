/* ==========================================================================
   terrain.js — твёрдая геометрия уровня
   • Уровень описан векторными фигурами (полилинии холмов, петли, блоки).
   • Фигуры лениво растеризуются в тайловую карту 16×16: каждый тайл ссылается
     на дедуплицированную маску 16×16 (карту высот) с флагами слоёв.
   • Сенсоры сканируют маски в 4 направлениях (пол / правая стена / потолок /
     левая стена) — как лучи от ступней в классических играх.
   • Отдельно — визуальные куски 256×256 (шахматная земля + трава), тоже лениво.
   ========================================================================== */
'use strict';

/* Флаги пикселя */
TH.SOLID = 1;     // твёрдое для всех
TH.LAYER_A = 2;   // твёрдое только на слое A (правые половины петель)
TH.LAYER_B = 4;   // твёрдое только на слое B (левые половины петель)
TH.TOPONLY = 8;   // твёрдое только сверху (парящие острова, тонкие платформы)

/* Направления: 0 вниз, 1 вправо, 2 вверх, 3 влево */
TH.DX = [0, 1, 0, -1];
TH.DY = [1, 0, -1, 0];
/* Касательная (направление «вперёд» при положительной скорости) для каждого режима */
TH.TX = [1, 0, -1, 0];
TH.TY = [0, -1, 0, 1];
TH.MODE_ANGLE = [0, -Math.PI / 2, Math.PI, Math.PI / 2];
TH.MODE_NAMES = ['FLOOR', 'RIGHT WALL', 'CEILING', 'LEFT WALL'];

TH.Terrain = function (W, H) {
  this.W = W; this.H = H;
  this.shapes = [];
  this.CS = 256;                         // размер куска растеризации
  this.tw = Math.ceil(W / 16); this.th = Math.ceil(H / 16);
  this.tiles = new Uint16Array(this.tw * this.th);
  this.cw = Math.ceil(W / this.CS); this.ch = Math.ceil(H / this.CS);
  this.loaded = new Uint8Array(this.cw * this.ch);
  this.masks = [null, null];             // 0 — пусто, 1 — полностью твёрдый
  this.maskMap = new Map();
  this.canvas = TH.makeCanvas(this.CS, this.CS);
  this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });
  this.hx = 0; this.hy = 0;              // координаты последнего попадания сенсора
  this.extraSolids = null;               // функция для подвижных твёрдых объектов (не используется сенсорами героя)
};

TH.Terrain.prototype = {
  /** shape: {bbox:[x0,y0,x1,y1], flag, cut, path(ctx), style, surfaces} */
  add: function (s) { this.shapes.push(s); return s; },

  /** Растеризация куска коллизий 256×256 и разбиение на тайлы с дедупликацией */
  raster: function (cx, cy) {
    var CS = this.CS, ctx = this.ctx, ox = cx * CS, oy = cy * CS;
    this.loaded[cy * this.cw + cx] = 1;
    var flags = new Uint8Array(CS * CS);
    var x0 = ox, y0 = oy, x1 = ox + CS, y1 = oy + CS;
    var i, s, any = false, anyTop = false;
    // Проход 1: R — общий слой, G — слой A, B — слой B. Вырезы — чёрным поверх.
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, CS, CS);
    ctx.setTransform(1, 0, 0, 1, -ox, -oy);
    for (i = 0; i < this.shapes.length; i++) {
      s = this.shapes[i];
      if (s.noCollide) continue;
      var b = s.bbox;
      if (b[0] >= x1 || b[2] <= x0 || b[1] >= y1 || b[3] <= y0) continue;
      if (s.flag === TH.TOPONLY) { anyTop = true; continue; }
      ctx.beginPath(); s.path(ctx);
      if (s.cut) { ctx.globalCompositeOperation = 'source-over'; ctx.fillStyle = '#000'; }
      else {
        ctx.globalCompositeOperation = 'lighter';
        ctx.fillStyle = s.flag === TH.LAYER_A ? '#00ff00' : s.flag === TH.LAYER_B ? '#0000ff' : '#ff0000';
      }
      ctx.fill(s.rule || 'nonzero');
      any = true;
    }
    if (any) {
      var d = ctx.getImageData(0, 0, CS, CS).data;
      for (i = 0; i < CS * CS; i++) {
        var f = 0, k = i * 4;
        if (d[k] > 127) f |= 1;
        if (d[k + 1] > 127) f |= 2;
        if (d[k + 2] > 127) f |= 4;
        flags[i] = f;
      }
    }
    // Проход 2: платформы «только сверху»
    if (anyTop) {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = '#000'; ctx.fillRect(0, 0, CS, CS);
      ctx.setTransform(1, 0, 0, 1, -ox, -oy);
      ctx.fillStyle = '#ff0000';
      for (i = 0; i < this.shapes.length; i++) {
        s = this.shapes[i];
        if (s.flag !== TH.TOPONLY || s.noCollide) continue;
        var bb = s.bbox;
        if (bb[0] >= x1 || bb[2] <= x0 || bb[1] >= y1 || bb[3] <= y0) continue;
        ctx.beginPath(); s.path(ctx); ctx.fill();
      }
      var d2 = ctx.getImageData(0, 0, CS, CS).data;
      for (i = 0; i < CS * CS; i++) if (d2[i * 4] > 127 && !(flags[i] & 1)) flags[i] |= 8;
    }
    // Разбиение на тайлы 16×16
    var tpc = CS / 16;
    for (var ty = 0; ty < tpc; ty++) for (var tx = 0; tx < tpc; tx++) {
      var gtx = cx * tpc + tx, gty = cy * tpc + ty;
      if (gtx >= this.tw || gty >= this.th) continue;
      var allZero = true, allOne = true, h = 2166136261;
      var m = new Uint8Array(256);
      for (var py = 0; py < 16; py++) {
        var row = (ty * 16 + py) * CS + tx * 16;
        for (var px = 0; px < 16; px++) {
          var v = flags[row + px];
          m[py * 16 + px] = v;
          if (v !== 0) allZero = false;
          if (v !== 1) allOne = false;
          h = Math.imul(h ^ v, 16777619);
        }
      }
      var idx;
      if (allZero) idx = 0;
      else if (allOne) idx = 1;
      else idx = this.dedup(m, h >>> 0);
      this.tiles[gty * this.tw + gtx] = idx;
    }
  },
  dedup: function (m, h) {
    var list = this.maskMap.get(h);
    if (list) {
      for (var i = 0; i < list.length; i++) {
        var o = this.masks[list[i]], same = true;
        for (var j = 0; j < 256; j++) if (o[j] !== m[j]) { same = false; break; }
        if (same) return list[i];
      }
    } else { list = []; this.maskMap.set(h, list); }
    var idx = this.masks.length;
    if (idx >= 65535) return 1;
    this.masks.push(m);
    list.push(idx);
    return idx;
  },
  /** Флаги пикселя (с ленивой растеризацией) */
  pix: function (x, y) {
    x = Math.floor(x); y = Math.floor(y);
    if (x < 0 || x >= this.W) return 1;      // края уровня — стены
    if (y < 0 || y >= this.H) return 0;
    var ci = (y >> 8) * this.cw + (x >> 8);
    if (!this.loaded[ci]) this.raster(x >> 8, y >> 8);
    var t = this.tiles[(y >> 4) * this.tw + (x >> 4)];
    if (t < 2) return t;
    return this.masks[t][((y & 15) << 4) | (x & 15)];
  },
  /** Твёрдость пикселя для слоя (0=A, 1=B) */
  solid: function (x, y, layer, top) {
    var f = this.pix(x, y);
    if (f & 1) return true;
    if (f & (layer ? 4 : 2)) return true;
    return !!(top && (f & 8));
  },
  /** Твёрдость для колец/частиц: оба слоя петли */
  solidAny: function (x, y, top) {
    var f = this.pix(x, y);
    return (f & 7) !== 0 || !!(top && (f & 8));
  },
  /** Предзагрузка кусков вокруг точки (чтобы не было подтормаживаний) */
  prefetch: function (x, y, rx, ry) {
    var cx0 = Math.max(0, Math.floor((x - rx) / 256)), cx1 = Math.min(this.cw - 1, Math.floor((x + rx) / 256));
    var cy0 = Math.max(0, Math.floor((y - ry) / 256)), cy1 = Math.min(this.ch - 1, Math.floor((y + ry) / 256));
    var n = 0;
    for (var cy = cy0; cy <= cy1; cy++) for (var cx = cx0; cx <= cx1; cx++) {
      if (!this.loaded[cy * this.cw + cx]) { this.raster(cx, cy); if (++n >= 2) return; }
    }
  },

  /**
   * Сенсор: расстояние от (x,y) до первого твёрдого пикселя в направлении dir.
   * Отрицательное — точка внутри твёрдого (до поверхности назад). null — промах.
   * Координаты поверхности → this.hx, this.hy.
   */
  sensor: function (x, y, dir, layer, top, range) {
    x = Math.floor(x); y = Math.floor(y);
    range = range || 32;
    var dx = TH.DX[dir], dy = TH.DY[dir];
    var tp = !!top && dir === 0;
    var i;
    if (this.solid(x, y, layer, tp)) {
      for (i = 1; i <= range; i++) {
        if (!this.solid(x - dx * i, y - dy * i, layer, tp)) {
          this.hx = x - dx * (i - 1); this.hy = y - dy * (i - 1);
          return -(i - 1);
        }
      }
      this.hx = x - dx * range; this.hy = y - dy * range;
      return -range;
    }
    for (i = 1; i <= range; i++) {
      if (this.solid(x + dx * i, y + dy * i, layer, tp)) {
        this.hx = x + dx * i; this.hy = y + dy * i;
        return i;
      }
    }
    return null;
  },

  /** Угол поверхности в точке попадания (по двум пробам вдоль касательной) */
  angleAt: function (hx, hy, dir, layer, top) {
    var tx = TH.TX[dir], ty = TH.TY[dir], s = 6;
    var p1x = hx, p1y = hy, p2x = hx, p2y = hy, ok1 = false, ok2 = false;
    var d1 = this.sensor(hx - tx * s, hy - ty * s, dir, layer, top, 14);
    if (d1 !== null && d1 > -14) { p1x = this.hx; p1y = this.hy; ok1 = true; }
    var d2 = this.sensor(hx + tx * s, hy + ty * s, dir, layer, top, 14);
    if (d2 !== null && d2 > -14) { p2x = this.hx; p2y = this.hy; ok2 = true; }
    if (!ok1 && !ok2) return TH.MODE_ANGLE[dir];
    // Если одна проба промахнулась (край), используем точку попадания
    if (!ok1) { p1x = hx; p1y = hy; }
    if (!ok2) { p2x = hx; p2y = hy; }
    if (p1x === p2x && p1y === p2y) return TH.MODE_ANGLE[dir];
    return Math.atan2(p2y - p1y, p2x - p1x);
  },

  /** Режим (пол/стена/потолок/стена) по углу */
  modeFor: function (a) {
    var d = a * 180 / Math.PI;
    if (d >= -45 && d <= 45) return 0;
    if (d < -45 && d > -135) return 1;
    if (d > 45 && d < 135) return 3;
    return 2;
  }
};

/* ==========================================================================
   Визуальный рендер ландшафта: ленивые куски 256×256 с LRU-кэшем
   ========================================================================== */
TH.TerrainArt = function (terrain) {
  this.t = terrain;
  this.cache = new Map();
  this.max = 110;
  this.SZ = 256;
  this.pat = {};
  this.makePatterns();
};
TH.TerrainArt.prototype = {
  makePatterns: function () {
    // Шахматная земля 16×16 с объёмными гранями (16-битный стиль)
    function checker(c1, c2, hl, sh) {
      var c = TH.makeCanvas(32, 32), g = c.getContext('2d');
      for (var y = 0; y < 2; y++) for (var x = 0; x < 2; x++) {
        var col = (x + y) % 2 ? c2 : c1;
        g.fillStyle = col; g.fillRect(x * 16, y * 16, 16, 16);
        g.fillStyle = hl; g.fillRect(x * 16, y * 16, 16, 2); g.fillRect(x * 16, y * 16, 2, 16);
        g.fillStyle = sh; g.fillRect(x * 16, y * 16 + 14, 16, 2); g.fillRect(x * 16 + 14, y * 16, 2, 16);
      }
      return c;
    }
    var g = this.t.ctx;
    this.pat.ground = g.createPattern(checker('#c46a2e', '#8f4519', 'rgba(255,220,160,.22)', 'rgba(60,20,0,.28)'), 'repeat');
    this.pat.cave = g.createPattern(checker('#5c2d14', '#45200d', 'rgba(255,200,150,.08)', 'rgba(0,0,0,.25)'), 'repeat');
    this.pat.loop = g.createPattern(checker('#d07a36', '#9a4c1e', 'rgba(255,230,170,.25)', 'rgba(60,20,0,.3)'), 'repeat');
    this.pat.rock = g.createPattern(checker('#8d8d9e', '#6d6d80', 'rgba(255,255,255,.18)', 'rgba(0,0,0,.25)'), 'repeat');
  },
  get: function (cx, cy) {
    var key = cx + ',' + cy;
    var c = this.cache.get(key);
    if (c) { this.cache.delete(key); this.cache.set(key, c); return c; }
    c = this.render(cx, cy);
    this.cache.set(key, c);
    if (this.cache.size > this.max) this.cache.delete(this.cache.keys().next().value);
    return c;
  },
  render: function (cx, cy) {
    var SZ = this.SZ, ox = cx * SZ, oy = cy * SZ;
    var c = TH.makeCanvas(SZ, SZ), g = c.getContext('2d');
    g.translate(-ox, -oy);
    var x0 = ox - 32, y0 = oy - 32, x1 = ox + SZ + 32, y1 = oy + SZ + 32;
    var shapes = this.t.shapes, any = false;
    for (var i = 0; i < shapes.length; i++) {
      var s = shapes[i], b = s.bbox;
      if (s.noDraw) continue;
      if (b[0] >= x1 || b[2] <= x0 || b[1] >= y1 || b[3] <= y0) continue;
      this.drawShape(g, s);
      any = true;
    }
    c.empty = !any;
    return c;
  },
  drawShape: function (g, s) {
    var style = s.style || 'ground';
    g.save();
    g.beginPath(); s.path(g);
    g.fillStyle = style === 'cave' ? this.pat.cave : style === 'loop' ? this.pat.loop : style === 'rock' ? this.pat.rock : this.pat.ground;
    g.fill(s.rule || 'nonzero');
    if (style === 'cave') {
      // Тень по краю пещеры для объёма
      g.clip(s.rule || 'nonzero');
      g.strokeStyle = 'rgba(0,0,0,.45)'; g.lineWidth = 10; g.stroke();
      g.restore();
      return;
    }
    g.clip(s.rule || 'nonzero');
    // Тёмная кайма по краю фигуры
    g.strokeStyle = 'rgba(50,20,5,.55)'; g.lineWidth = 4;
    g.stroke();
    // Трава вдоль поверхностей (видна только внутренняя половина обводки — по клипу)
    if (s.surfaces) {
      for (var k = 0; k < s.surfaces.length; k++) this.drawGrass(g, s.surfaces[k], style);
    }
    if (s.under) this.drawUnder(g, s);
    g.restore();
  },
  surfPath: function (g, sf) {
    g.beginPath();
    if (sf.circle) { g.arc(sf.circle[0], sf.circle[1], sf.circle[2], 0, Math.PI * 2); return; }
    var p = sf.pts || sf;
    g.moveTo(p[0][0], p[0][1]);
    for (var i = 1; i < p.length; i++) g.lineTo(p[i][0], p[i][1]);
  },
  drawGrass: function (g, sf, style) {
    g.lineJoin = 'round'; g.lineCap = 'butt';
    if (style === 'loop' || (sf.rim)) {
      this.surfPath(g, sf);
      g.strokeStyle = '#5a2a0e'; g.lineWidth = 16; g.stroke();
      g.strokeStyle = '#f0b060'; g.lineWidth = 8; g.stroke();
      g.strokeStyle = '#fff0c0'; g.lineWidth = 3; g.stroke();
      return;
    }
    this.surfPath(g, sf);
    g.strokeStyle = '#4a240c'; g.lineWidth = 34; g.stroke();     // полоса почвы
    g.strokeStyle = '#1d6b16'; g.lineWidth = 26; g.stroke();     // тёмная трава
    g.strokeStyle = '#38a92a'; g.lineWidth = 18; g.stroke();     // трава
    g.strokeStyle = '#7ee05a'; g.lineWidth = 6; g.stroke();      // блик
    // Зубчики травы вниз
    var p = sf.pts || sf;
    if (!p.length) return;
    g.fillStyle = '#1d6b16';
    for (var i = 0; i < p.length - 1; i++) {
      var ax = p[i][0], ay = p[i][1], bx = p[i + 1][0], by = p[i + 1][1];
      var len = Math.hypot(bx - ax, by - ay);
      if (len < 1) continue;
      var nx = -(by - ay) / len, ny = (bx - ax) / len; // нормаль внутрь (вниз для пола)
      for (var t = 4; t < len; t += 8) {
        var x = ax + (bx - ax) * t / len, y = ay + (by - ay) * t / len;
        g.beginPath();
        g.moveTo(x - 4 * (bx - ax) / len + nx * 12, y - 4 * (by - ay) / len + ny * 12);
        g.lineTo(x + nx * 17, y + ny * 17);
        g.lineTo(x + 4 * (bx - ax) / len + nx * 12, y + 4 * (by - ay) / len + ny * 12);
        g.fill();
      }
    }
  },
  drawUnder: function (g, s) {
    // Нижняя кромка парящих островов — тёмная тень
    var b = s.bbox;
    var grd = g.createLinearGradient(0, b[3] - 14, 0, b[3]);
    grd.addColorStop(0, 'rgba(0,0,0,0)'); grd.addColorStop(1, 'rgba(30,10,0,.55)');
    g.fillStyle = grd; g.fillRect(b[0], b[3] - 14, b[2] - b[0], 14);
  },
  /** Отрисовка видимых кусков */
  draw: function (ctx, camX, camY) {
    var SZ = this.SZ;
    var cx0 = Math.floor(camX / SZ), cx1 = Math.floor((camX + TH.W) / SZ);
    var cy0 = Math.floor(camY / SZ), cy1 = Math.floor((camY + TH.H) / SZ);
    for (var cy = cy0; cy <= cy1; cy++) for (var cx = cx0; cx <= cx1; cx++) {
      if (cx < 0 || cy < 0 || cx * SZ >= this.t.W || cy * SZ >= this.t.H) continue;
      var c = this.get(cx, cy);
      if (!c.empty) ctx.drawImage(c, Math.round(cx * SZ - camX), Math.round(cy * SZ - camY));
    }
  }
};
