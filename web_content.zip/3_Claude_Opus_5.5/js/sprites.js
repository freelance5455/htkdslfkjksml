/* ==========================================================================
   sprites.js — вся графика персонажей рисуется программно (16-битный стиль)
   Герой (синий ёж), бадники, зверьки, иконки мониторов, лицо злодея.
   ========================================================================== */
'use strict';

TH.Sprites = (function () {
  // Реальные PNG-анимации из папки assets/sonic (загружаются локально, без сети).
  var spriteSets = { idle: ['spr_sonic_idle.png'], walk: [], run: [], jump: [], balance: [], dead: [], lookup: ['spr_sonic_lookup.png'], lookdown: ['spr_sonic_lookdown.png'], fall: ['spr_sonic_fall.png'], hurt: ['spr_sonic_hurt.png'] };
  function numbered(prefix, count) { var a = []; for (var i = 0; i < count; i++) a.push('spr_sonic_' + prefix + (i ? '_' + i : '') + '.png'); return a; }
  spriteSets.walk = numbered('walk', 8); spriteSets.run = numbered('run', 4); spriteSets.jump = numbered('jump', 8);
  spriteSets.balance = numbered('balancing', 6); spriteSets.dead = numbered('dead', 4);
  var spriteImages = {}, spriteReady = false;
  Object.keys(spriteSets).forEach(function (set) { spriteSets[set].forEach(function (file) {
    if (spriteImages[file]) return; var im = new Image(); im.src = 'assets/sonic/' + file; spriteImages[file] = im;
    im.onload = function () { spriteReady = true; };
  }); });
  function drawRealHero(g, x, y, o) {
    var pose = o.pose || 'stand', t = o.t || 0, list, frame, file, im;
    if (pose === 'ball' || pose === 'roll' || pose === 'spindash' || pose === 'spring') { list = spriteSets.jump; frame = Math.floor(t / 4) % list.length; }
    else if (pose === 'stand' || pose === 'wait' || pose === 'thumb') { list = spriteSets.idle; frame = 0; }
    else if (pose === 'walk' || pose === 'run') { list = spriteSets[pose]; frame = Math.floor(t / (pose === 'run' ? 3 : 5)) % list.length; }
    else if (pose === 'lookup') { list = spriteSets.lookup; frame = 0; }
    else if (pose === 'crouch') { list = spriteSets.lookdown; frame = 0; }
    else if (pose === 'fall') { list = spriteSets.fall; frame = 0; }
    else if (pose === 'balance') { list = spriteSets.balance; frame = Math.floor(t / 7) % list.length; }
    else if (pose === 'dead') { list = spriteSets.dead; frame = Math.floor(t / 8) % list.length; }
    else if (pose === 'hurt') { list = spriteSets.hurt; frame = 0; }
    else { list = spriteSets.idle; frame = 0; }
    file = list[frame] || list[0]; im = spriteImages[file];
    if (!im || !im.complete || !im.naturalWidth) return false;
    var w = im.naturalWidth, h = im.naturalHeight;
    g.save(); g.translate(Math.round(x), Math.round(y));
    try { var hue = Number(localStorage.getItem('th_palette_hue') || 0); if (hue) g.filter = 'hue-rotate(' + hue + 'deg) saturate(1.35)'; } catch (e) {}
    if (o.angle) g.rotate(o.angle); if (o.facing < 0) g.scale(-1, 1);
    // Player coordinates are the physics-body center (feet are at y + hr).
    // Ball poses are centered; upright PNGs must be anchored at the feet.
    if (pose === 'ball' || pose === 'roll' || pose === 'spindash' || pose === 'spring') {
      g.drawImage(im, -w / 2, -h / 2, w, h);
    } else {
      // hr=19 for upright Sonic; align visible soles with the collision ground.
      g.drawImage(im, -w / 2, -h + 19, w, h);
    }
    g.restore(); return true;
  }

  var C = {
    blue: '#1f5ee6', blueL: '#4f8cff', blueD: '#0d2f96', out: '#06123c',
    skin: '#f7c98f', skinD: '#c98d55', white: '#ffffff', grey: '#c8cde0',
    red: '#e82a2a', redD: '#8e1010', eye: '#0b1630', green: '#20c040'
  };

  function ell(g, x, y, rx, ry, fill, stroke, rot) {
    g.beginPath(); g.ellipse(x, y, rx, ry, rot || 0, 0, Math.PI * 2);
    if (fill) { g.fillStyle = fill; g.fill(); }
    if (stroke) { g.strokeStyle = stroke; g.lineWidth = 1; g.stroke(); }
  }
  function limb(g, x1, y1, x2, y2, w, col) {
    g.lineCap = 'round';
    g.strokeStyle = C.out; g.lineWidth = w + 2;
    g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke();
    g.strokeStyle = col; g.lineWidth = w;
    g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke();
  }
  /** Кроссовка: красная с белой полосой, носок по направлению rot */
  function shoe(g, x, y, rot) {
    g.save(); g.translate(x, y); g.rotate(rot || 0);
    ell(g, 2.5, 0, 5.5, 3.2, C.red, C.out);
    g.fillStyle = C.white; g.fillRect(0, -3, 2, 6);
    ell(g, 4.5, -1, 1.6, 0.9, 'rgba(255,255,255,.55)');
    g.fillStyle = C.redD; g.fillRect(-2.5, 2, 9, 1.2);
    g.restore();
  }
  function glove(g, x, y, r) { ell(g, x, y, r || 2.6, r || 2.6, C.white, C.out); }

  /* ---------- Голова в профиль ---------- */
  function headSide(g, o) {
    o = o || {};
    // Иглы назад
    g.fillStyle = C.blue; g.strokeStyle = C.out; g.lineWidth = 1;
    g.beginPath();
    g.moveTo(-1, -16);
    g.lineTo(-17, -19); g.lineTo(-6, -11.5);
    g.lineTo(-20, -9);  g.lineTo(-6, -6);
    g.lineTo(-17, 1);   g.lineTo(-3, -1);
    g.closePath(); g.fill(); g.stroke();
    // Блик на иглах
    g.strokeStyle = C.blueL; g.beginPath(); g.moveTo(-4, -14); g.lineTo(-13, -17); g.stroke();
    // Голова
    ell(g, 1, -8, 9.2, 9, C.blue, C.out);
    ell(g, -1, -12, 4, 2.5, C.blueL);
    // Ухо
    g.fillStyle = C.blue; g.beginPath(); g.moveTo(-3, -15); g.lineTo(-1, -21); g.lineTo(3, -15.5); g.closePath(); g.fill(); g.strokeStyle = C.out; g.stroke();
    g.fillStyle = C.skin; g.beginPath(); g.moveTo(-1.5, -15.5); g.lineTo(-0.8, -19); g.lineTo(1.5, -15.7); g.closePath(); g.fill();
    // Мордочка
    ell(g, 6.5, -4, 5.6, 3.9, C.skin, C.out);
    ell(g, 3, -6.5, 3, 2.5, C.skin);
    // Глаза
    if (o.closed) {
      g.strokeStyle = C.eye; g.lineWidth = 1.2; g.beginPath(); g.moveTo(3, -10); g.lineTo(8, -10); g.stroke();
    } else if (o.hurt) {
      ell(g, 5.5, -10.5, 3.6, 4.8, C.white, C.out);
      g.strokeStyle = C.eye; g.lineWidth = 1; g.beginPath(); g.moveTo(4, -12); g.lineTo(8, -9); g.moveTo(8, -12); g.lineTo(4, -9); g.stroke();
    } else {
      ell(g, 5.5, -10.5, 3.6, 4.8, C.white, C.out);
      ell(g, 7 + (o.look || 0), -10 + (o.lookY || 0), 1.5, 2.2, C.eye);
      g.fillStyle = C.white; g.fillRect(7 + (o.look || 0), -11.5 + (o.lookY || 0), 0.8, 0.8);
    }
    // Нос и рот
    ell(g, 11.6, -6, 1.7, 1.5, C.eye);
    g.strokeStyle = C.skinD; g.lineWidth = 0.8;
    g.beginPath();
    if (o.mouthOpen) { ell(g, 8, -2, 1.6, 1.2, '#7a1a1a'); }
    else { g.moveTo(5.5, -2); g.quadraticCurveTo(8, -0.5, 10, -2.5); g.stroke(); }
  }

  /* ---------- Тело ---------- */
  function body(g) {
    ell(g, -1, 3, 5.5, 6, C.blue, C.out);
    ell(g, 1.2, 4, 3.6, 4.6, C.skin);
  }

  /* ---------- Герой: главная функция ----------
     o: {pose, t (кадры), facing, angle, phase, speed} */
  function hero(g, x, y, o) {
    if (drawRealHero(g, x, y, o || {})) return;
    g.save();
    g.translate(Math.round(x), Math.round(y));
    if (o.angle) g.rotate(o.angle);
    if (o.facing < 0) g.scale(-1, 1);
    var t = o.t || 0, pose = o.pose;
    switch (pose) {
      case 'ball': case 'roll': ball(g, o.phase || 0); break;
      case 'spindash': spindash(g, t); break;
      case 'wait': front(g, 'wait', t); break;
      case 'dead': front(g, 'dead', t); break;
      case 'thumb': front(g, 'thumb', t); break;
      default: side(g, pose, o);
    }
    g.restore();
  }

  function side(g, pose, o) {
    var t = o.t || 0, ph = o.phase || 0;
    var lean = 0, headO = {}, legs, arms, headRot = 0, bodyDy = 0, wheel = false;
    var sw = Math.sin(ph), cw = Math.cos(ph);
    switch (pose) {
      case 'stand':
        legs = [[-2, 17, 0], [2.5, 17, 0]]; arms = [[-4, 7], [5, 7]];
        if ((t % 200) > 190) headO.closed = true;
        break;
      case 'walk':
        lean = 0.08;
        legs = [[sw * 6, 17 - Math.max(0, cw) * 3, sw * 0.3], [-sw * 6, 17 - Math.max(0, -cw) * 3, -sw * 0.3]];
        arms = [[-sw * 5 - 1, 7], [sw * 5 + 1, 7]];
        bodyDy = Math.abs(sw) * -0.8;
        break;
      case 'run':
        lean = 0.22; wheel = true; arms = [[-7, 3], [9, 2]];
        bodyDy = -1;
        break;
      case 'fall':
        legs = [[-4 + sw * 2, 16, 0.4], [4 - sw * 2, 15, -0.3]]; arms = [[-8, -2 + sw * 2], [9, -3 - sw * 2]];
        break;
      case 'skid':
        lean = -0.32; legs = [[9, 16, -0.2], [2, 17, 0]]; arms = [[-9, 1], [-6, 3]];
        headO.mouthOpen = true;
        break;
      case 'crouch':
        bodyDy = 6; legs = [[-1, 17, 0], [4, 17, 0]]; arms = [[3, 11], [7, 11]]; headRot = 0.15;
        break;
      case 'lookup':
        legs = [[-2, 17, 0], [2.5, 17, 0]]; arms = [[-4, 7], [5, 7]]; headRot = -0.35; headO.lookY = -1.2;
        break;
      case 'balance':
        lean = 0.35 + Math.sin(t * 0.25) * 0.08;
        legs = [[-4, 17, 0], [-1, 17, 0]]; arms = [[-10, -6 + Math.sin(t * 0.5) * 3], [11, -8 - Math.sin(t * 0.5) * 3]];
        headO.mouthOpen = true; headO.look = 1;
        break;
      case 'spring':
        legs = [[-1, 18, 1.2], [2, 18, 1.1]]; arms = [[-3, -16], [5, -17]]; headRot = -0.15;
        break;
      case 'hurt':
        lean = -0.4; legs = [[8, 13, -0.6], [-6, 15, 0.5]]; arms = [[-9, -4], [10, -6]]; headO.hurt = true; headO.mouthOpen = true;
        break;
      case 'push':
        lean = 0.35; legs = [[-7, 17, 0], [0, 17, 0]]; arms = [[10, 1], [11, 3]];
        break;
      default:
        legs = [[-2, 17, 0], [2.5, 17, 0]]; arms = [[-4, 7], [5, 7]];
    }
    g.save();
    g.translate(0, bodyDy);
    g.rotate(lean);
    // Задняя рука
    if (arms) { limb(g, -1, 1, arms[0][0], arms[0][1], 2, C.skin); glove(g, arms[0][0], arms[0][1]); }
    // Ноги
    if (wheel) {
      // «Колесо» ног на максимальной скорости
      g.save(); g.translate(1, 14); g.rotate(-lean);
      var a = (o.t || 0) * 0.9;
      ell(g, 0, 0, 7.5, 6, 'rgba(232,42,42,.35)');
      for (var i = 0; i < 3; i++) {
        var aa = a + i * 2.1;
        ell(g, Math.cos(aa) * 5, Math.sin(aa) * 4, 3.4, 2.4, i === 0 ? C.red : 'rgba(232,42,42,.6)', i === 0 ? C.out : null, aa);
      }
      g.strokeStyle = 'rgba(255,255,255,.7)'; g.lineWidth = 1;
      g.beginPath(); g.ellipse(0, 0, 6.5, 5, 0, a, a + 1.6); g.stroke();
      g.restore();
    } else if (legs) {
      limb(g, -1, 8, legs[0][0] - 1, legs[0][1] - 2, 2.4, C.blue);
      shoe(g, legs[0][0] - 1, legs[0][1], legs[0][2] - lean);
    }
    body(g);
    if (!wheel && legs) {
      limb(g, 1, 8, legs[1][0], legs[1][1] - 2, 2.4, C.blue);
      shoe(g, legs[1][0], legs[1][1], legs[1][2] - lean);
    }
    // Голова
    g.save(); g.translate(0, -2); g.rotate(headRot); g.translate(0, 2);
    headSide(g, headO);
    g.restore();
    // Передняя рука
    if (arms) { limb(g, 1, 1, arms[1][0], arms[1][1], 2, C.skin); glove(g, arms[1][0], arms[1][1]); }
    g.restore();
  }

  /** Клубок (прыжок / перекат) */
  function ball(g, phase) {
    g.save();
    g.rotate(phase);
    ell(g, 0, 0, 12, 12, C.blue, C.out);
    // Иглы-завитки
    g.fillStyle = C.blueD;
    for (var i = 0; i < 4; i++) {
      g.save(); g.rotate(i * Math.PI / 2);
      g.beginPath(); g.moveTo(-2, -4); g.quadraticCurveTo(4, -13, 11, -6); g.quadraticCurveTo(4, -9, -2, -4); g.fill();
      g.restore();
    }
    ell(g, -3, -4, 4, 3, C.blueL);
    // Проблеск мордочки
    ell(g, 6, 3, 4, 3, C.skin);
    ell(g, 4, -2, 2, 2.6, C.white);
    g.restore();
  }
  function spindash(g, t) {
    g.save();
    var sq = 1 + Math.sin(t * 1.3) * 0.08;
    g.translate(0, 2);
    g.scale(1.15 * sq, 0.9 / sq);
    ball(g, -t * 0.9);
    g.restore();
    // Хвост ускорения
    g.fillStyle = 'rgba(255,255,255,.5)';
    for (var i = 0; i < 3; i++) g.fillRect(-14 - i * 4 - (t % 3), -4 + i * 4, 6, 1);
  }

  /** Вид анфас: ожидание (постукивает ногой), смерть, «палец вверх» */
  function front(g, mode, t) {
    var tap = mode === 'wait' && (Math.floor(t / 8) % 2 === 0);
    // Иглы по бокам
    g.fillStyle = C.blue; g.strokeStyle = C.out; g.lineWidth = 1;
    g.beginPath();
    g.moveTo(-6, -15); g.lineTo(-15, -16); g.lineTo(-8, -10); g.lineTo(-17, -7); g.lineTo(-8, -4); g.lineTo(-13, 1); g.lineTo(-4, -2);
    g.lineTo(4, -2); g.lineTo(13, 1); g.lineTo(8, -4); g.lineTo(17, -7); g.lineTo(8, -10); g.lineTo(15, -16); g.lineTo(6, -15);
    g.closePath(); g.fill(); g.stroke();
    // Ноги
    var lf = tap ? 15 : 17;
    limb(g, -2, 8, -3, 15, 2.4, C.blue); limb(g, 2, 8, 3, lf - 2, 2.4, C.blue);
    shoe(g, -5, 17, Math.PI); shoe(g, 5, lf, 0);
    body(g);
    // Руки
    if (mode === 'wait') { limb(g, -4, 1, -8, 6, 2, C.skin); limb(g, 4, 1, 8, 6, 2, C.skin); glove(g, -7, 6); glove(g, 7, 6); }
    else if (mode === 'dead') { limb(g, -4, 1, -10, -10, 2, C.skin); limb(g, 4, 1, 10, -10, 2, C.skin); glove(g, -10, -10); glove(g, 10, -10); }
    // Голова
    ell(g, 0, -8, 9.5, 9, C.blue, C.out);
    g.fillStyle = C.blue; g.beginPath(); g.moveTo(-8, -12); g.lineTo(-9, -20); g.lineTo(-3, -16); g.closePath(); g.fill(); g.stroke();
    g.beginPath(); g.moveTo(8, -12); g.lineTo(9, -20); g.lineTo(3, -16); g.closePath(); g.fill(); g.stroke();
    ell(g, 0, -3.5, 6.5, 4.2, C.skin, C.out);
    if (mode === 'dead') {
      g.strokeStyle = C.eye; g.lineWidth = 1.2; g.beginPath();
      g.moveTo(-5, -12); g.lineTo(-1.5, -8.5); g.moveTo(-1.5, -12); g.lineTo(-5, -8.5);
      g.moveTo(1.5, -12); g.lineTo(5, -8.5); g.moveTo(5, -12); g.lineTo(1.5, -8.5); g.stroke();
      ell(g, 0, -1.5, 2, 1.6, '#7a1a1a');
    } else {
      ell(g, -3, -10, 3, 4.2, C.white, C.out); ell(g, 3, -10, 3, 4.2, C.white, C.out);
      var lx = mode === 'wait' ? Math.sin(t * 0.03) * 0.8 : 0;
      ell(g, -2.5 + lx, -9.5, 1.3, 2, C.eye); ell(g, 2.5 + lx, -9.5, 1.3, 2, C.eye);
      ell(g, 0, -5.5, 1.6, 1.3, C.eye);
      g.strokeStyle = C.skinD; g.lineWidth = 0.8; g.beginPath(); g.moveTo(-3, -2); g.quadraticCurveTo(0, mode === 'thumb' ? 1 : 0, 3.5, -2.5); g.stroke();
    }
    if (mode === 'thumb') {
      limb(g, -4, 1, -8, 6, 2, C.skin); glove(g, -7, 6);
      limb(g, 4, 1, 12, -6, 2, C.skin);
      // Кулак с поднятым большим пальцем
      ell(g, 12.5, -7, 3.4, 3, C.white, C.out);
      g.fillStyle = C.white; g.strokeStyle = C.out;
      g.beginPath(); g.rect(11.3, -15, 2.6, 6); g.fill(); g.stroke();
    }
  }

  /* ---------- Иконка головы героя (жизни, монитор) ---------- */
  function heroHead(g, x, y, s) {
    g.save(); g.translate(x, y); g.scale(s || 1, s || 1);
    g.translate(0, 8);
    headSide(g, {});
    g.restore();
  }

  /* ================= Бадники ================= */
  function beetle(g, x, y, f, t) {
    // «Божья коровка» на колёсах: красный панцирь, металлическая голова
    g.save(); g.translate(Math.round(x), Math.round(y)); if (f < 0) g.scale(-1, 1);
    // Колесо
    var wa = t * 0.3;
    ell(g, -2, 9, 5, 5, '#333', '#000');
    g.strokeStyle = '#999'; g.lineWidth = 1; g.beginPath(); g.moveTo(-2 + Math.cos(wa) * 4, 9 + Math.sin(wa) * 4); g.lineTo(-2 - Math.cos(wa) * 4, 9 - Math.sin(wa) * 4); g.stroke();
    // Корпус-панцирь
    g.fillStyle = '#d62020'; g.strokeStyle = '#400'; g.beginPath();
    g.moveTo(-13, 6); g.quadraticCurveTo(-12, -11, 3, -10); g.quadraticCurveTo(12, -8, 11, 4); g.lineTo(-13, 6); g.fill(); g.stroke();
    ell(g, -6, -3, 2.6, 2.6, '#111'); ell(g, 1, -6, 2.2, 2.2, '#111'); ell(g, -1, 2, 2.4, 2.4, '#111');
    ell(g, -4, -7, 4, 1.6, 'rgba(255,255,255,.5)');
    // Голова
    ell(g, 12, 0, 6, 6, '#b8c0d8', '#223');
    ell(g, 14, -1, 2.4, 2.4, '#fff'); ell(g, 15, -1, 1.2, 1.2, '#e00');
    g.strokeStyle = '#223'; g.beginPath(); g.moveTo(10, -6); g.lineTo(8, -11); g.stroke(); ell(g, 8, -11, 1.3, 1.3, '#ff0');
    // Выхлоп
    if ((t >> 2) % 2) ell(g, -16, 4, 2.5, 2, 'rgba(200,200,200,.7)');
    g.restore();
  }
  function wasp(g, x, y, f, t, aiming) {
    g.save(); g.translate(Math.round(x), Math.round(y)); if (f < 0) g.scale(-1, 1);
    // Крылья
    var wf = Math.sin(t * 1.4) * 4;
    ell(g, -2, -8 - wf * 0.3, 7, 3 + wf * 0.4, 'rgba(220,240,255,.7)', '#88a', -0.3);
    ell(g, 4, -8 + wf * 0.3, 6, 2.5, 'rgba(220,240,255,.6)', '#88a', 0.3);
    // Тело-полосы
    ell(g, -2, 0, 11, 5, '#ffcc00', '#432');
    g.fillStyle = '#222'; g.fillRect(-7, -4, 3, 8); g.fillRect(-1, -5, 3, 10);
    // Жало-пушка
    g.save(); g.translate(-11, 2); g.rotate(aiming ? 0.9 : 0.3);
    g.fillStyle = '#9aa'; g.fillRect(-1, 0, 3, 8); g.restore();
    // Голова
    ell(g, 10, -1, 5, 4.5, '#556', '#112');
    ell(g, 12, -2, 2.4, 2.2, '#ff3030');
    g.restore();
  }
  function crab(g, x, y, f, t, firing) {
    g.save(); g.translate(Math.round(x), Math.round(y));
    var step = Math.sin(t * 0.3) * 2;
    // Ноги
    g.strokeStyle = '#7a1c00'; g.lineWidth = 2; g.lineCap = 'round';
    for (var i = -1; i <= 1; i += 2) {
      g.beginPath(); g.moveTo(i * 6, 4); g.lineTo(i * 12, 9 + step * i); g.stroke();
      g.beginPath(); g.moveTo(i * 3, 5); g.lineTo(i * 8, 10 - step * i); g.stroke();
    }
    // Клешни-пушки
    var up = firing ? -6 : 0;
    for (i = -1; i <= 1; i += 2) {
      g.strokeStyle = '#7a1c00'; g.beginPath(); g.moveTo(i * 8, 0); g.lineTo(i * 15, -6 + up); g.stroke();
      ell(g, i * 16, -9 + up, 5, 4.5, '#ff5a1a', '#5a1000');
      g.fillStyle = '#ddd'; g.fillRect(i * 16 - 1.5, -16 + up, 3, 4);
    }
    // Тело
    ell(g, 0, 0, 11, 7, '#f0461a', '#5a1000');
    ell(g, -3, -3, 5, 2, 'rgba(255,255,255,.35)');
    ell(g, -4, -7, 2.4, 2.4, '#fff', '#000'); ell(g, 4, -7, 2.4, 2.4, '#fff', '#000');
    ell(g, -4, -7, 1, 1, '#000'); ell(g, 4, -7, 1, 1, '#000');
    g.restore();
  }
  function fish(g, x, y, f, t, upward) {
    g.save(); g.translate(Math.round(x), Math.round(y));
    g.rotate(upward ? -Math.PI / 2 : Math.PI / 2);
    // Хвост
    g.fillStyle = '#2a6bd0'; g.beginPath(); g.moveTo(-9, 0); g.lineTo(-16, -6 + Math.sin(t) * 2); g.lineTo(-16, 6 + Math.sin(t) * 2); g.fill();
    ell(g, 0, 0, 11, 8, '#3c8cf0', '#0a2a60');
    ell(g, -1, 3, 8, 4, '#cfe3ff');
    // Челюсть с зубами
    var jaw = Math.abs(Math.sin(t * 0.4)) * 3;
    g.fillStyle = '#fff';
    for (var i = 0; i < 3; i++) { g.beginPath(); g.moveTo(5 + i * 2, -1 - jaw * 0.3); g.lineTo(6 + i * 2, 2); g.lineTo(7 + i * 2, -1 - jaw * 0.3); g.fill(); }
    ell(g, 4, -4, 2.6, 2.6, '#fff', '#000'); ell(g, 5, -4, 1.2, 1.2, '#e00');
    g.fillStyle = '#9aa'; g.fillRect(-4, -9, 5, 3);
    g.restore();
  }

  /* ================= Зверьки ================= */
  function animal(g, x, y, kind, f, t, inAir) {
    g.save(); g.translate(Math.round(x), Math.round(y)); if (f < 0) g.scale(-1, 1);
    if (kind === 0) {
      // Птичка
      var w = Math.sin(t * 0.8) * 4;
      ell(g, 0, 0, 5, 4.5, '#2a7cff', '#0a2a70');
      ell(g, 1, 1.5, 3, 2.5, '#fff');
      g.fillStyle = '#ffb000'; g.beginPath(); g.moveTo(4, -1); g.lineTo(8, 0); g.lineTo(4, 1); g.fill();
      ell(g, 2, -2, 1, 1, '#000');
      ell(g, -3, -2 - (inAir ? w : 0), 4, 2, '#1c5cd0', null, -0.5);
    } else if (kind === 1) {
      // Зайчик
      ell(g, -1, 0, 5, 4.5, '#f4f0e8', '#776');
      ell(g, 3, -4, 3.6, 3.4, '#f4f0e8', '#776');
      ell(g, 2, -10, 1.3, 4, '#f4f0e8', '#776'); ell(g, 4, -10, 1.3, 4, '#f4f0e8', '#776');
      ell(g, 2, -10, 0.6, 2.5, '#f8b0c0');
      ell(g, 4.5, -4.5, 0.9, 0.9, '#000');
      ell(g, -1, 4, 2.4, 1.2, '#ddd');
    } else {
      // Белочка
      ell(g, -6, -4, 4, 6, '#c87830', '#5a3010', -0.4);
      ell(g, 0, 0, 5, 4.5, '#e08a3a', '#5a3010');
      ell(g, 3, -4, 3.4, 3.2, '#e08a3a', '#5a3010');
      ell(g, 1.5, 0.5, 2.5, 2.5, '#fbe0b0');
      ell(g, 4, -4.5, 0.9, 0.9, '#000');
    }
    g.restore();
  }

  /* ================= Иконки мониторов ================= */
  function monitorIcon(g, x, y, item, t) {
    g.save(); g.translate(x, y);
    switch (item) {
      case 'rings':
        g.strokeStyle = '#ffd800'; g.lineWidth = 2.5; g.beginPath(); g.arc(0, 0, 5, 0, Math.PI * 2); g.stroke();
        g.strokeStyle = '#fff6a0'; g.lineWidth = 1; g.beginPath(); g.arc(-1, -1, 4.5, Math.PI, Math.PI * 1.6); g.stroke();
        break;
      case 'shield':
        ell(g, 0, 0, 6.5, 6.5, 'rgba(120,200,255,.6)', '#bff');
        ell(g, -2, -2, 2, 1.5, '#fff');
        break;
      case 'shoes':
        shoe(g, -3, 1, 0);
        g.fillStyle = '#fff'; g.fillRect(-7, -5, 4, 1); g.fillRect(-8, -2, 3, 1);
        break;
      case 'invincible':
        g.fillStyle = ['#ff0', '#fff', '#0ff', '#f0f'][(t >> 2) % 4];
        star(g, 0, 0, 6.5, 3);
        break;
      case 'life':
        heroHead(g, 0, -1, 0.55);
        break;
    }
    g.restore();
  }
  function star(g, x, y, R, r) {
    g.beginPath();
    for (var i = 0; i < 10; i++) {
      var a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r : R;
      g.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr);
    }
    g.closePath(); g.fill();
  }

  /* ================= Злодей: Барон Болт ================= */
  /** Лицо злодея: лысина, растрёпанные седые волосы, зелёные очки-гогглы, острые усы */
  function villainFace(g, x, y, s, mood) {
    g.save(); g.translate(x, y); g.scale(s || 1, s || 1);
    // Волосы
    g.fillStyle = '#e8e8f0';
    for (var i = -1; i <= 1; i += 2) {
      g.beginPath(); g.moveTo(i * 6, -4); g.lineTo(i * 12, -8); g.lineTo(i * 10, -3); g.lineTo(i * 13, -1); g.lineTo(i * 8, 2); g.closePath(); g.fill();
    }
    // Голова
    ell(g, 0, -1, 8, 8.5, '#f2c7a0', '#5a3020');
    ell(g, -2, -6, 3, 1.5, 'rgba(255,255,255,.6)');
    // Очки
    g.fillStyle = '#333'; g.fillRect(-8, -4, 16, 2);
    ell(g, -3.5, -2.5, 3, 3, mood === 'hurt' ? '#ff4040' : '#30e060', '#111');
    ell(g, 3.5, -2.5, 3, 3, mood === 'hurt' ? '#ff4040' : '#30e060', '#111');
    ell(g, -4.3, -3.4, 1, 1, '#fff'); ell(g, 2.7, -3.4, 1, 1, '#fff');
    // Нос и усы
    ell(g, 0, 1.5, 2, 2.2, '#e8a080');
    g.fillStyle = '#333';
    g.beginPath(); g.moveTo(0, 3); g.quadraticCurveTo(-6, 2, -10, 0 + (mood === 'hurt' ? 3 : 0)); g.quadraticCurveTo(-5, 5, 0, 4.5); g.fill();
    g.beginPath(); g.moveTo(0, 3); g.quadraticCurveTo(6, 2, 10, 0 + (mood === 'hurt' ? 3 : 0)); g.quadraticCurveTo(5, 5, 0, 4.5); g.fill();
    if (mood === 'laugh') ell(g, 0, 6, 2.5, 1.5, '#600');
    g.restore();
  }

  return {
    C: C, hero: hero, heroHead: heroHead, beetle: beetle, wasp: wasp, crab: crab, fish: fish,
    animal: animal, monitorIcon: monitorIcon, villainFace: villainFace, star: star, ell: ell, shoe: shoe
  };
})();
