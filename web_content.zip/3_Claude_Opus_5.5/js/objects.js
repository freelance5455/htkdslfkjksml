/* ==========================================================================
   objects.js — объекты уровня
   Кольца, разлетевшиеся кольца, мониторы, пружины, шипы, чекпоинты, мост,
   рушащиеся и движущиеся платформы, финишная табличка, капсула со зверьками.
   ========================================================================== */
'use strict';

/* ---------------- Твёрдость объектов для героя ---------------- */
TH.Solid = {
  /** Твёрдый прямоугольник (центр cx,cy, полуразмеры hw,hh). Возвращает сторону касания. */
  box: function (game, o, cx, cy, hw, hh) {
    var p = game.player;
    if (p.dead) return null;
    var top = cy - hh;
    if (p.groundObj === o) {
      if (Math.abs(p.x - cx) > hw + 6) { p.leaveObject(); return null; }
      p.y = top - p.hr;
      return 'stand';
    }
    var dx = p.x - cx, dy = p.y - cy;
    var cw = hw + 10, ch = hh + p.hr;
    if (Math.abs(dx) >= cw || Math.abs(dy) >= ch) return null;
    var pen = (p.y + p.hr) - top;
    if (dy < 0 && p.ysp >= 0 && pen <= Math.max(5, p.ysp + 5) && Math.abs(dx) < hw + 6) {
      p.landObject(o, top);
      return 'top';
    }
    var ox = dx < 0 ? -(cw + dx) : (cw - dx);
    var oy = dy < 0 ? -(ch + dy) : (ch - dy);
    if (Math.abs(ox) <= Math.abs(oy) + 2) {
      p.x += ox;
      if ((ox < 0 && p.xsp > 0) || (ox > 0 && p.xsp < 0)) { p.xsp = 0; if (p.ground) { p.gsp = 0; p.pushing = 2; } }
      return ox < 0 ? 'left' : 'right';
    }
    if (dy > 0) { p.y += oy; if (p.ysp < 0) p.ysp = 0; return 'bottom'; }
    return null;
  },
  /** Платформа «только сверху» (x0..x1, высота поверхности topFn(x) или число) */
  top: function (game, o, x0, x1, topY) {
    var p = game.player;
    if (p.dead) return false;
    var ty = typeof topY === 'function' ? topY(p.x) : topY;
    if (p.groundObj === o) {
      if (p.x < x0 - 6 || p.x > x1 + 6) { p.leaveObject(); return false; }
      p.y = ty - p.hr;
      return true;
    }
    if (p.x < x0 - 4 || p.x > x1 + 4 || p.ysp < 0) return false;
    var pen = (p.y + p.hr) - ty;
    var ok = p.ground ? (pen >= -1 && pen <= 14) : (pen >= 0 && pen <= p.ysp + 8);
    if (ok) { p.landObject(o, ty); return true; }
    return false;
  }
};

/* ---------------- Базовый конструктор ---------------- */
TH.Obj = {};
TH.makeObject = function (d, game) {
  var C = TH.Obj[d.type];
  if (!C) return null;
  var o = new C(d, game);
  o.type = d.type; o.def = d;
  if (o.alive === undefined) o.alive = true;
  return o;
};

/* =============================== КОЛЬЦО =============================== */
TH.Obj.ring = function (d) { this.x = d.x; this.y = d.y; };
TH.Obj.ring.prototype = {
  update: function (game) {
    var p = game.player;
    if (p.dead || p.state === 'hurt' && p.hurtTimer > 90) return;
    if (Math.abs(p.x - this.x) < 15 && Math.abs(p.y - this.y) < p.hr + 5) {
      this.alive = false;
      game.addRings(1);
      TH.Audio.play('ring');
      game.particles.sparkle(this.x, this.y, 4);
    }
  },
  draw: function (g, cx, cy, game) { TH.drawRing(g, this.x - cx, this.y - cy, game.frame); }
};
TH.drawRing = function (g, x, y, frame, alpha) {
  var w = Math.abs(Math.cos(frame * 0.08)) * 5.5 + 0.8;
  x = Math.round(x); y = Math.round(y);
  if (alpha !== undefined) g.globalAlpha = alpha;
  g.lineWidth = 2.4;
  g.strokeStyle = '#a06800';
  g.beginPath(); g.ellipse(x + 0.5, y + 0.5, w, 6, 0, 0, Math.PI * 2); g.stroke();
  g.strokeStyle = '#ffd200';
  g.beginPath(); g.ellipse(x, y, w, 6, 0, 0, Math.PI * 2); g.stroke();
  g.lineWidth = 1; g.strokeStyle = '#fff8b0';
  g.beginPath(); g.ellipse(x - 0.5, y - 0.5, Math.max(0.5, w - 1.5), 4.5, 0, Math.PI * 1.05, Math.PI * 1.6); g.stroke();
  // Блеск
  if ((frame + Math.floor(x * 3)) % 90 < 6) {
    g.fillStyle = '#fff'; g.fillRect(x - 3, y - 6, 1, 3); g.fillRect(x - 4, y - 5, 3, 1);
  }
  if (alpha !== undefined) g.globalAlpha = 1;
};

/* ======================= РАЗЛЕТЕВШЕЕСЯ КОЛЬЦО ======================= */
TH.Obj.loosering = function (d) {
  this.x = d.x; this.y = d.y; this.vx = d.vx; this.vy = d.vy; this.t = 0; this.dyn = true;
};
TH.Obj.loosering.prototype = {
  update: function (game) {
    this.t++;
    if (this.t > TH.CONFIG.RING_LIFETIME) { this.alive = false; return; }
    var T = game.terrain, r = 6;
    this.vy += 0.09375;
    if (this.vy > 8) this.vy = 8;
    // Подшаги, чтобы кольцо никогда не «пролетало» сквозь тонкие поверхности
    var steps = Math.ceil(Math.max(Math.abs(this.vx), Math.abs(this.vy)) / 3) || 1;
    for (var s = 0; s < steps; s++) {
      var nx = this.x + this.vx / steps;
      var sx = this.vx > 0 ? r : -r;
      if (T.solidAny(nx + sx, this.y) || T.solidAny(nx + sx, this.y - 3) || T.solidAny(nx + sx, this.y + 3)) this.vx = -this.vx * 0.75;
      else this.x = nx;
      var ny = this.y + this.vy / steps;
      if (this.vy > 0) {
        var floor = T.solidAny(this.x, ny + r, true) || T.solidAny(this.x - 3, ny + r, true) || T.solidAny(this.x + 3, ny + r, true);
        // Платформы-объекты (мост, острова, мониторы, пружины)
        if (!floor) floor = game.objectFloorAt(this.x, this.y + r, ny + r);
        if (floor) { this.vy = -Math.max(this.vy * 0.75, 1.2); if (Math.abs(this.vy) < 1.3) this.vy = -1.6; }
        else this.y = ny;
      } else {
        if (T.solidAny(this.x, ny - r) || T.solidAny(this.x - 3, ny - r) || T.solidAny(this.x + 3, ny - r)) this.vy = -this.vy * 0.75;
        else this.y = ny;
      }
    }
    // Если всё же застряло в земле — выталкиваем вверх
    var guard = 0;
    while (T.solidAny(this.x, this.y) && guard++ < 24) this.y -= 1;
    if (this.y > game.level.H + 32) { this.alive = false; return; }
    // Подбор (через 64 кадра после рассыпания)
    var p = game.player;
    if (this.t > 64 && !p.dead && Math.abs(p.x - this.x) < 15 && Math.abs(p.y - this.y) < p.hr + 5) {
      this.alive = false; game.addRings(1); TH.Audio.play('ring'); game.particles.sparkle(this.x, this.y, 3);
    }
  },
  draw: function (g, cx, cy, game) {
    var left = TH.CONFIG.RING_LIFETIME - this.t;
    if (left < 64 && (this.t >> 1) % 2) return; // мигание перед исчезновением
    TH.drawRing(g, this.x - cx, this.y - cy, game.frame * 2 + this.t);
  }
};

/* =============================== МОНИТОР =============================== */
TH.Obj.monitor = function (d) { this.x = d.x; this.y = d.y; this.item = d.item; this.broken = false; this.icon = null; this.dy = 0; this.vy = 0; };
TH.Obj.monitor.prototype = {
  hw: 14, hh: 15,
  update: function (game) {
    if (this.icon) {
      this.icon.t++;
      if (this.icon.t < 30) this.icon.y -= 1.2;
      if (this.icon.t === 30) game.giveItem(this.item);
      if (this.icon.t > 60) this.icon = null;
    }
    if (this.broken) return;
    var p = game.player, cx = this.x, cy = this.y - this.hh;
    if (p.dead) return;
    // Атака клубком: сверху — с отскоком; сбоку — перекатом или в прыжке
    if (p.ball && Math.abs(p.x - cx) < this.hw + 10 && Math.abs(p.y - cy) < this.hh + p.hr) {
      var fromTop = p.y < cy - 4 && p.ysp >= 0;
      var fromBelow = p.y > cy + 6 && p.ysp < 0 && !p.ground;
      if (!fromBelow) {
        this.breakIt(game);
        if (fromTop && !p.ground) p.ysp = -p.ysp;
        return;
      }
    }
    TH.Solid.box(game, this, cx, cy, this.hw, this.hh);
  },
  breakIt: function (game) {
    this.broken = true;
    if (game.player.groundObj === this) game.player.leaveObject();
    this.icon = { y: this.y - this.hh, t: 0 };
    TH.Audio.play('monitor');
    game.particles.explosion(this.x, this.y - 14, false);
    game.particles.debris(this.x, this.y - 14, '#b0b8c8', 6);
    game.addScore(10, null, null);
    game.chainKill(this.x, this.y - 20, true);
  },
  floorAt: function (x) { return (!this.broken && Math.abs(x - this.x) < this.hw) ? this.y - this.hh * 2 : null; },
  draw: function (g, cx, cy, game) {
    var x = Math.round(this.x - cx), y = Math.round(this.y - cy);
    if (this.broken) {
      g.fillStyle = '#6a7080'; g.fillRect(x - 13, y - 6, 26, 6);
      g.fillStyle = '#3a3f4c'; g.fillRect(x - 10, y - 9, 20, 4);
    } else {
      // Корпус телевизора
      g.fillStyle = '#20242e'; g.fillRect(x - 15, y - 31, 30, 31);
      g.fillStyle = '#c8cedc'; g.fillRect(x - 14, y - 30, 28, 28);
      g.fillStyle = '#eef2ff'; g.fillRect(x - 14, y - 30, 28, 2);
      g.fillStyle = '#7a8090'; g.fillRect(x - 14, y - 4, 28, 4);
      g.fillStyle = '#1a2040'; g.fillRect(x - 11, y - 27, 22, 19);
      // Экран с иконкой и помехами
      if ((game.frame >> 2) % 8 !== 0) TH.Sprites.monitorIcon(g, x, y - 17.5, this.item, game.frame);
      else { g.fillStyle = '#fff'; for (var i = 0; i < 6; i++) g.fillRect(x - 11, y - 27 + i * 3 + (game.frame % 3), 22, 1); }
      g.fillStyle = 'rgba(255,255,255,.18)'; g.fillRect(x - 11, y - 27, 22, 6);
    }
    if (this.icon) {
      var iy = Math.round(this.icon.y - cy);
      g.fillStyle = '#1a2040'; g.fillRect(x - 10, iy - 9, 20, 18);
      TH.Sprites.monitorIcon(g, x, iy, this.item, game.frame);
    }
  }
};

/* =============================== ПРУЖИНА =============================== */
TH.Obj.spring = function (d) { this.x = d.x; this.y = d.y; this.color = d.color || 'yellow'; this.dir = d.dir || 0; this.anim = 0; };
TH.Obj.spring.prototype = {
  update: function (game) {
    if (this.anim > 0) this.anim--;
    var p = game.player, power = this.color === 'red' ? 16 : 10;
    if (this.dir === 0) {
      var r = TH.Solid.box(game, this, this.x, this.y - 8, 14, 8);
      if (r === 'top' || r === 'stand') {
        p.spring(power);
        this.anim = 12;
        TH.Audio.play('spring');
      }
    } else {
      var res = TH.Solid.box(game, this, this.x, this.y - 14, 8, 14);
      if ((this.dir > 0 && res === 'right') || (this.dir < 0 && res === 'left')) {
        p.springSide(this.dir, power);
        this.anim = 12;
        TH.Audio.play('spring');
      }
    }
  },
  floorAt: function (x) { return Math.abs(x - this.x) < 14 ? this.y - 16 : null; },
  draw: function (g, cx, cy) {
    var x = Math.round(this.x - cx), y = Math.round(this.y - cy);
    var col = this.color === 'red' ? '#e02020' : '#ffd000', colD = this.color === 'red' ? '#801010' : '#a07800';
    var ext = this.anim > 6 ? 8 : this.anim > 0 ? 4 : 0;
    g.save(); g.translate(x, y);
    if (this.dir !== 0) { g.translate(0, -14); g.rotate(this.dir > 0 ? Math.PI / 2 : -Math.PI / 2); g.translate(0, 14); }
    g.fillStyle = '#555c6a'; g.fillRect(-13, -4, 26, 4);
    g.fillStyle = '#aab'; g.fillRect(-13, -4, 26, 1);
    // Пружинка
    g.strokeStyle = '#ccd'; g.lineWidth = 2;
    g.beginPath();
    var h = 6 + ext;
    for (var i = 0; i <= 4; i++) { var yy = -4 - i * h / 4; g.lineTo(i % 2 ? 6 : -6, yy); }
    g.stroke();
    // Площадка
    g.fillStyle = colD; g.fillRect(-14, -14 - ext, 28, 6);
    g.fillStyle = col; g.fillRect(-14, -16 - ext, 28, 5);
    g.fillStyle = 'rgba(255,255,255,.6)'; g.fillRect(-12, -15 - ext, 10, 1);
    g.restore();
  }
};

/* =============================== ШИПЫ =============================== */
TH.Obj.spikes = function (d) { this.x = d.x; this.y = d.y; this.n = d.n || 3; this.w = this.n * 16; };
TH.Obj.spikes.prototype = {
  update: function (game) {
    var p = game.player;
    var r = TH.Solid.box(game, this, this.x, this.y - 8, this.w / 2, 8);
    if ((r === 'top' || r === 'stand') && p.invuln <= 0 && p.invincible <= 0) {
      p.leaveObject();
      game.hurtPlayer(this.x, true);
    }
  },
  floorAt: function (x) { return Math.abs(x - this.x) < this.w / 2 ? this.y - 16 : null; },
  draw: function (g, cx, cy) {
    var x0 = Math.round(this.x - this.w / 2 - cx), y = Math.round(this.y - cy);
    g.fillStyle = '#555'; g.fillRect(x0, y - 3, this.w, 3);
    for (var i = 0; i < this.n; i++) {
      var sx = x0 + i * 16;
      g.fillStyle = '#e8ecf4';
      g.beginPath(); g.moveTo(sx + 1, y - 3); g.lineTo(sx + 8, y - 17); g.lineTo(sx + 8, y - 3); g.fill();
      g.fillStyle = '#8a90a0';
      g.beginPath(); g.moveTo(sx + 8, y - 17); g.lineTo(sx + 15, y - 3); g.lineTo(sx + 8, y - 3); g.fill();
    }
  }
};

/* =============================== ЧЕКПОИНТ =============================== */
TH.Obj.checkpoint = function (d, game) {
  this.x = d.x; this.y = d.y; this.on = game.checkpoint && game.checkpoint.x >= d.x - 1; this.spin = 0;
};
TH.Obj.checkpoint.prototype = {
  update: function (game) {
    if (this.spin > 0) this.spin--;
    var p = game.player;
    if (!this.on && !p.dead && Math.abs(p.x - this.x) < 12 && p.y > this.y - 64 && p.y < this.y + 8) {
      this.on = true; this.spin = 60;
      game.reachCheckpoint(this);
      TH.Audio.play('checkpoint');
      game.particles.sparkle(this.x, this.y - 46, 8);
    }
  },
  draw: function (g, cx, cy, game) {
    var x = Math.round(this.x - cx), y = Math.round(this.y - cy);
    g.fillStyle = '#1838a0'; g.fillRect(x - 2, y - 40, 4, 40);
    g.fillStyle = '#5a80ff'; g.fillRect(x - 2, y - 40, 1, 40);
    g.fillStyle = '#333'; g.fillRect(x - 5, y - 3, 10, 3);
    var a = this.spin > 0 ? this.spin * 0.35 : 0;
    var bx = x + Math.sin(a) * 6, by = y - 44 - Math.cos(a) * 2;
    var col = this.on ? ((game.frame >> 3) % 2 ? '#ff3030' : '#ffa0a0') : '#3a70ff';
    TH.Sprites.ell(g, bx, by, 4.5, 4.5, col, '#101830');
    TH.Sprites.ell(g, bx - 1.5, by - 1.5, 1.5, 1.2, '#fff');
  }
};

/* =============================== МОСТ ИЗ БРЁВЕН =============================== */
TH.Obj.bridge = function (d) {
  this.x = d.x; this.x1 = d.x1; this.y = d.y;
  this.n = Math.round((this.x1 - this.x) / 16);
  this.sag = new Float32Array(this.n);   // текущий прогиб каждого бревна
  this.alwaysActive = false;
};
TH.Obj.bridge.prototype = {
  surface: function (x) {
    var i = TH.clamp(Math.floor((x - this.x) / 16), 0, this.n - 1);
    return this.y + this.sag[i];
  },
  update: function (game) {
    var p = game.player, self = this;
    var on = TH.Solid.top(game, this, this.x, this.x1, function (x) { return self.surface(x); });
    // Целевой прогиб: синусоида с максимумом под героем
    var k = on ? TH.clamp(Math.floor((p.x - this.x) / 16), 0, this.n - 1) : -1;
    var maxD = on ? Math.min(k + 1, this.n - k) * 1.2 : 0;
    maxD = Math.min(maxD, 14);
    for (var i = 0; i < this.n; i++) {
      var target = 0;
      if (on) {
        if (i <= k) target = maxD * Math.sin(Math.PI / 2 * (i + 1) / (k + 1));
        else target = maxD * Math.sin(Math.PI / 2 * (this.n - i) / (this.n - k));
      }
      this.sag[i] += (target - this.sag[i]) * 0.25;
    }
    if (on) p.y = this.surface(p.x) - p.hr;
  },
  floorAt: function (x) { return (x >= this.x && x <= this.x1) ? this.surface(x) : null; },
  draw: function (g, cx, cy) {
    var y0 = this.y - cy;
    // Канаты
    g.strokeStyle = '#6a4020'; g.lineWidth = 1;
    g.beginPath();
    for (var i = 0; i < this.n; i++) {
      var lx = this.x + i * 16 + 8 - cx, ly = y0 + this.sag[i] + 3;
      if (i === 0) g.moveTo(lx, ly); else g.lineTo(lx, ly);
    }
    g.stroke();
    for (i = 0; i < this.n; i++) {
      var x = Math.round(this.x + i * 16 - cx), y = Math.round(y0 + this.sag[i]);
      if (x < -20 || x > TH.W + 20) continue;
      g.fillStyle = '#5a3010'; g.fillRect(x, y, 16, 9);
      g.fillStyle = '#b06a2a'; g.fillRect(x + 1, y, 14, 8);
      g.fillStyle = '#d89050'; g.fillRect(x + 1, y + 1, 14, 2);
      g.fillStyle = '#7a4418'; g.fillRect(x + 4, y + 4, 8, 1);
    }
    // Столбы
    [this.x - 4, this.x1 - 4].forEach(function (px) {
      var sx = Math.round(px - cx);
      g.fillStyle = '#6a3a14'; g.fillRect(sx, y0 - 14, 8, 24);
      g.fillStyle = '#a86a30'; g.fillRect(sx + 1, y0 - 14, 3, 24);
    });
  }
};

/* =============================== РУШАЩАЯСЯ ПЛАТФОРМА =============================== */
TH.Obj.collapse = function (d) { this.x = d.x; this.y = d.y; this.w = d.w || 64; this.timer = -1; this.gone = false; this.shake = 0; };
TH.Obj.collapse.prototype = {
  update: function (game) {
    if (this.gone) return;
    var x0 = this.x - this.w / 2, x1 = this.x + this.w / 2;
    var on = TH.Solid.top(game, this, x0, x1, this.y);
    if (on && this.timer < 0) this.timer = 28;
    if (this.timer > 0) {
      this.timer--;
      this.shake = (this.timer >> 1) % 2 ? 1 : -1;
      if (this.timer === 0) {
        this.gone = true;
        if (game.player.groundObj === this) game.player.leaveObject();
        TH.Audio.play('crumble');
        for (var i = 0; i < this.w / 16; i++) {
          game.particles.add({ k: 'debris', x: x0 + i * 16 + 8, y: this.y + 6, vx: TH.rand(-0.4, 0.4), vy: TH.rand(-0.5, 0.5), g: 0.25, life: 70, col: i % 2 ? '#8f4519' : '#38a92a', s: 12, rot: 0 });
        }
      }
    }
  },
  floorAt: function (x) { return (!this.gone && Math.abs(x - this.x) < this.w / 2) ? this.y : null; },
  draw: function (g, cx, cy) {
    if (this.gone) return;
    var x = Math.round(this.x - this.w / 2 - cx + this.shake), y = Math.round(this.y - cy);
    for (var i = 0; i < this.w / 16; i++) {
      g.fillStyle = i % 2 ? '#8f4519' : '#c46a2e'; g.fillRect(x + i * 16, y + 4, 16, 12);
    }
    g.fillStyle = '#1d6b16'; g.fillRect(x, y, this.w, 6);
    g.fillStyle = '#38a92a'; g.fillRect(x, y, this.w, 4);
    g.fillStyle = '#7ee05a'; g.fillRect(x, y, this.w, 1);
    g.fillStyle = 'rgba(0,0,0,.3)';
    for (i = 1; i < this.w / 16; i++) g.fillRect(x + i * 16, y + 4, 1, 12);
  }
};

/* =============================== ДВИЖУЩАЯСЯ ПЛАТФОРМА =============================== */
TH.Obj.mover = function (d, game) {
  this.bx = d.x; this.by = d.y; this.w = d.w || 64; this.mx = d.dx || 0; this.my = d.dy || 0;
  this.period = d.period || 240; this.phase = d.phase || 0;
  this.x = this.bx; this.y = this.by; this.alwaysActive = true;
};
TH.Obj.mover.prototype = {
  update: function (game) {
    var k = 0.5 - 0.5 * Math.cos(Math.PI * 2 * (game.frame / this.period + this.phase));
    var nx = this.bx + this.mx * k, ny = this.by + this.my * k;
    var dx = nx - this.x;
    this.x = nx; this.y = ny;
    var p = game.player;
    if (p.groundObj === this) p.x += dx;
    TH.Solid.top(game, this, this.x - this.w / 2, this.x + this.w / 2, this.y);
  },
  floorAt: function (x) { return Math.abs(x - this.x) < this.w / 2 ? this.y : null; },
  draw: function (g, cx, cy) {
    var x = Math.round(this.x - this.w / 2 - cx), y = Math.round(this.y - cy);
    g.fillStyle = '#8f4519'; g.fillRect(x + 4, y + 6, this.w - 8, 10);
    g.fillStyle = '#c46a2e'; g.fillRect(x + 4, y + 6, this.w - 8, 3);
    g.fillStyle = '#1d6b16'; g.fillRect(x, y, this.w, 7);
    g.fillStyle = '#38a92a'; g.fillRect(x, y, this.w, 5);
    g.fillStyle = '#7ee05a'; g.fillRect(x, y, this.w, 1);
    // Подвесные камешки
    g.fillStyle = '#6a3410'; g.fillRect(x + this.w / 2 - 6, y + 16, 12, 4);
  }
};

/* =============================== ФИНИШНАЯ ТАБЛИЧКА =============================== */
TH.Obj.signpost = function (d) { this.x = d.x; this.y = d.y; this.state = 'idle'; this.rot = 0; this.spinT = 0; };
TH.Obj.signpost.prototype = {
  update: function (game) {
    var p = game.player;
    if (this.state === 'idle' && game.capsuleDone && p.x > this.x - 8 && !p.dead) {
      this.state = 'spin'; this.spinT = 150;
      TH.Audio.play('signpost');
      game.signpostHit(this);
    }
    if (this.state === 'spin') {
      this.spinT--;
      var sp = Math.max(0.05, this.spinT / 150 * 0.5);
      this.rot += sp;
      if (this.spinT % 30 === 0 && this.spinT > 0) TH.Audio.play('signpost');
      if (this.spinT % 8 === 0) game.particles.sparkle(this.x + TH.rand(-20, 20), this.y - 60 + TH.rand(-10, 10), 1);
      if (this.spinT <= 0) {
        // Останавливаемся лицом героя
        var k = Math.round(this.rot / Math.PI);
        if (k % 2) k++;
        this.rot = k * Math.PI;
        this.state = 'done';
        game.signpostDone();
      }
    }
  },
  draw: function (g, cx, cy, game) {
    var x = Math.round(this.x - cx), y = Math.round(this.y - cy);
    g.fillStyle = '#444'; g.fillRect(x - 2, y - 40, 4, 40);
    g.fillStyle = '#999'; g.fillRect(x - 2, y - 40, 1, 40);
    var c = Math.cos(this.rot), w = Math.abs(c) * 22;
    var ty = y - 64;
    g.fillStyle = '#2a2a40'; g.fillRect(x - w - 2, ty - 22, w * 2 + 4, 44);
    g.fillStyle = '#e8e8f8'; g.fillRect(x - w, ty - 20, w * 2, 40);
    if (w > 4) {
      g.save(); g.translate(x, ty); g.scale(Math.max(0.05, Math.abs(c)), 1);
      if (Math.cos(this.rot) > 0 && (Math.round(this.rot / Math.PI) % 2 === 0)) TH.Sprites.heroHead(g, -1, 0, 1.1);
      else TH.Sprites.villainFace(g, 0, 2, 1.25);
      g.restore();
    }
  }
};

/* =============================== КАПСУЛА СО ЗВЕРЬКАМИ =============================== */
TH.Obj.capsule = function (d) { this.x = d.x; this.y = d.y; this.state = 'closed'; this.t = 0; this.btn = 0; };
TH.Obj.capsule.prototype = {
  update: function (game) {
    var p = game.player;
    // Корпус
    var r = TH.Solid.box(game, this, this.x, this.y - 26, 30, 26);
    if (this.state === 'closed') {
      // Кнопка сверху
      if ((r === 'top' || r === 'stand') && game.bossDefeated) {
        this.state = 'pressed'; this.t = 0; this.btn = 4;
        TH.Audio.play('button');
      }
    } else if (this.state === 'pressed') {
      this.t++;
      if (this.t % 6 === 0) game.particles.explosion(this.x + TH.rand(-24, 24), this.y - TH.rand(10, 46), false);
      if (this.t === 40) {
        this.state = 'open'; this.t = 0;
        TH.Audio.play('capsule');
        game.particles.debris(this.x, this.y - 24, '#c0c8d8', 12);
        for (var i = 0; i < 10; i++) {
          game.spawn(new TH.Animal(this.x + TH.rand(-18, 18), this.y - 20, i % 3, i * 6, true));
        }
        game.capsuleOpened();
      }
    } else {
      this.t++;
    }
  },
  floorAt: function (x) { return Math.abs(x - this.x) < 30 ? this.y - 52 : null; },
  draw: function (g, cx, cy, game) {
    var x = Math.round(this.x - cx), y = Math.round(this.y - cy);
    // Опоры
    g.fillStyle = '#556'; g.fillRect(x - 28, y - 8, 8, 8); g.fillRect(x + 20, y - 8, 8, 8);
    // Корпус
    g.fillStyle = '#2a2e3c'; g.fillRect(x - 31, y - 49, 62, 42);
    g.fillStyle = '#9aa2b8'; g.fillRect(x - 30, y - 48, 60, 40);
    g.fillStyle = '#d0d6e8'; g.fillRect(x - 30, y - 48, 60, 4);
    g.fillStyle = '#ffcc00'; g.fillRect(x - 30, y - 20, 60, 4);
    if (this.state !== 'open') {
      // Стеклянное окошко с силуэтами зверьков
      g.fillStyle = '#1a2a50'; g.fillRect(x - 20, y - 42, 40, 18);
      for (var i = 0; i < 4; i++) TH.Sprites.animal(g, x - 14 + i * 9, y - 30 + ((game.frame >> 4) + i) % 2, i % 3, 1, game.frame, false);
      g.fillStyle = 'rgba(170,220,255,.35)'; g.fillRect(x - 20, y - 42, 40, 18);
    } else {
      g.fillStyle = '#10141e'; g.fillRect(x - 20, y - 42, 40, 18);
    }
    // Кнопка
    var bp = this.state === 'closed' ? 0 : 4;
    g.fillStyle = '#333'; g.fillRect(x - 10, y - 52, 20, 3);
    g.fillStyle = '#e02020'; g.fillRect(x - 8, y - 57 + bp, 16, 6 - bp);
    g.fillStyle = '#ff9090'; g.fillRect(x - 7, y - 57 + bp, 6, 1);
  }
};
