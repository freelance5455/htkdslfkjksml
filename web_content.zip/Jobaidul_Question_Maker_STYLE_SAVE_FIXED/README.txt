জোবাইদুল প্রশ্ন মেকার HD — Screenshot Style Edition

এই সংস্করণটি ব্যবহারকারীর দেওয়া মোবাইল স্ক্রিনশটের UI অনুসরণ করে সাজানো হয়েছে।

মূল পরিবর্তন:
- মোবাইল এডিটর Chrome toolbar-এর মতো horizontal controls
- মাদ্রাসা/পরীক্ষা/শ্রেণির horizontal header fields
- প্রশ্নসমূহ section ও প্রশ্ন entry card স্ক্রিনশটের কাছাকাছি layout
- “প্রশ্ন যোগ করুন” dashed button
- লাইভ Preview + A4 + PNG bar
- Header Customization একটি tall rounded bottom-sheet এবং radio-list
- ১০টি header style
- Header style localStorage-এ persistent
- Draft auto-save
- Save Paper IndexedDB-তে persistent, localStorage fallback সহ
- Saved Paper load/delete/delete-all
- Backup/Restore

ফাইল: index.html

নোট: ওয়েব ব্রাউজারের font rendering/viewport অনুযায়ী ১-২ পিক্সেল বা ফন্টের আকারে পার্থক্য হতে পারে।
