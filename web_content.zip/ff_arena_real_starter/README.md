# FF Arena Tournament Hub — deployable starter

This is a **server-backed starter project**, not a published app or production-certified service. It includes a Node.js HTTP server, server-side tournament/player storage, a private admin login, tournament creation, free UID registration, result recording (7 points per kill), and an audit log. Payments and cash prizes are intentionally disabled.

## Run locally
Requires Node.js 20+; no npm packages are needed.

Linux/macOS:
```sh
export ADMIN_USER=admin
export ADMIN_PASSWORD='replace-with-a-long-random-secret-14-chars-minimum'
node server.js
```
Windows PowerShell:
```powershell
$env:ADMIN_USER='admin'
$env:ADMIN_PASSWORD='replace-with-a-long-random-secret-14-chars-minimum'
node server.js
```
Open `http://localhost:8080` in a browser. Keep the terminal running. The default admin username is `admin`; password must be set through the environment variable. Do not deploy with a shared/default password.

## Before any real public launch
- Deploy behind HTTPS on a maintained server; set secrets in the hosting provider, not source code.
- Replace the in-memory session store with a persistent, secure session store; add rate limits, CSRF protection, secure proxy cookie settings, password hashing / managed identity, and monitoring.
- Add backups, retention/deletion policies, privacy notice and consent for player UID data, and independent security testing.
- The current JSON data store is only for a small test; it is not a production database and should not be used for public scale.
- A PWA manifest alone does not make this installable from a local file. Browser installation normally requires an HTTPS-hosted site. An Android APK/AAB has not been built by this project.
- No official Garena API integration is included. Only use Free Fire branding/assets within applicable permissions and terms.
- No payment gateway, UPI collection, paid entry, cash payout, or redeemable coins are implemented. Any future monetization must be reviewed independently for current Indian law, payment-provider rules, platform policies, and required approvals before development or activation.
