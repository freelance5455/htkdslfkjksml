const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ROOT = __dirname;
const PUB = path.join(ROOT, 'public');
const DATA = path.join(ROOT, 'data.json');
const PORT = Number(process.env.PORT || 8080);
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
if (!ADMIN_PASSWORD || ADMIN_PASSWORD.length < 14) {
  console.error('Set ADMIN_PASSWORD to a strong password of at least 14 characters before starting.');
  process.exit(1);
}
const sessions = new Map();
function load(){try{return JSON.parse(fs.readFileSync(DATA,'utf8'))}catch{return {players:[], tournaments:[{id:crypto.randomUUID(),title:'Squad Showdown',mode:'Squad',date:'Set match date/time',slots:48,joined:[],status:'Open',roomId:'',roomPassword:''}],results:[],audit:[]}}}
let db=load(); function save(){fs.writeFileSync(DATA,JSON.stringify(db,null,2),{mode:0o600})}
function send(res,status,obj){res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff','content-security-policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'"});res.end(JSON.stringify(obj))}
function cookie(req){return (req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('ffa_session='))?.slice(12)}
function admin(req){const token=cookie(req);return token && sessions.has(token) && sessions.get(token).role==='admin'}
function audit(action,detail,req){db.audit.unshift({id:crypto.randomUUID(),at:new Date().toISOString(),action,detail,ip:(req.socket.remoteAddress||'').slice(0,64)});db.audit=db.audit.slice(0,1000);save()}
function body(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>100000)reject(Error('too large'))});req.on('end',()=>{try{resolve(JSON.parse(s||'{}'))}catch{reject(Error('invalid json'))}});req.on('error',reject)})}
const server=http.createServer(async(req,res)=>{const url=new URL(req.url,'http://localhost');const p=url.pathname;
 if(req.method==='GET' && p==='/api/health')return send(res,200,{ok:true,app:'FF Arena',payments:'disabled'});
 if(req.method==='POST' && p==='/api/admin/login'){try{const b=await body(req);const a=crypto.timingSafeEqual(Buffer.from(String(b.username||'')),Buffer.from(ADMIN_USER));const pass=String(b.password||'');const validLength=pass.length===ADMIN_PASSWORD.length;const match=validLength&&crypto.timingSafeEqual(Buffer.from(pass),Buffer.from(ADMIN_PASSWORD));if(!a||!match){audit('admin_login_failed','Invalid credentials',req);return send(res,401,{error:'Invalid credentials'})}const token=crypto.randomBytes(32).toString('hex');sessions.set(token,{role:'admin',at:Date.now()});res.writeHead(200,{'content-type':'application/json','set-cookie':`ffa_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800`,'cache-control':'no-store'});return res.end(JSON.stringify({ok:true}))}catch{return send(res,400,{error:'Bad request'})}}
 if(req.method==='POST' && p==='/api/admin/logout'){const t=cookie(req);if(t)sessions.delete(t);res.writeHead(200,{'content-type':'application/json','set-cookie':'ffa_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});return res.end('{"ok":true}')}
 if(p.startsWith('/api/admin/')){if(!admin(req))return send(res,401,{error:'Admin login required'});
  if(req.method==='GET'&&p==='/api/admin/data')return send(res,200,{players:db.players,tournaments:db.tournaments,results:db.results,audit:db.audit,paymentsEnabled:false});
  try{const b=await body(req);
   if(req.method==='POST'&&p==='/api/admin/tournaments'){if(!String(b.title||'').trim())return send(res,400,{error:'Title required'});const t={id:crypto.randomUUID(),title:String(b.title).slice(0,80),mode:['Solo','Duo','Squad','Lone Wolf'].includes(b.mode)?b.mode:'Squad',date:String(b.date||'').slice(0,40),slots:Math.max(2,Math.min(500,Number(b.slots)||48)),joined:[],status:'Open',roomId:'',roomPassword:''};db.tournaments.unshift(t);audit('tournament_created',t.title,req);return send(res,201,{tournament:t})}
   if(req.method==='POST'&&p==='/api/admin/results'){const name=String(b.playerName||'').trim().slice(0,50),k=Math.floor(Number(b.kills));if(!name||!Number.isFinite(k)||k<0||k>1000)return send(res,400,{error:'Valid player name and kills required'});let r=db.results.find(x=>x.playerName.toLowerCase()===name.toLowerCase());if(!r){r={playerName:name,kills:0,points:0};db.results.push(r)}r.kills+=k;r.points+=k*7;audit('result_recorded',`${name}: ${k} kills, ${k*7} points`,req);return send(res,200,{result:r})}
   if(req.method==='POST'&&p==='/api/admin/room'){const t=db.tournaments.find(x=>x.id===b.id);if(!t)return send(res,404,{error:'Tournament not found'});t.roomId=String(b.roomId||'').slice(0,50);t.roomPassword=String(b.roomPassword||'').slice(0,50);audit('room_details_updated',t.title,req);return send(res,200,{ok:true})}
   return send(res,404,{error:'Not found'});
  }catch{return send(res,400,{error:'Bad request'})}}
 if(req.method==='GET'&&p==='/api/tournaments')return send(res,200,{tournaments:db.tournaments.map(t=>({...t,roomId:undefined,roomPassword:undefined,joinedCount:t.joined.length}))});
 if(req.method==='POST'&&p==='/api/register'){try{const b=await body(req);const name=String(b.name||'').trim().slice(0,40),uid=String(b.uid||'').trim().slice(0,24),tid=String(b.tournamentId||'');if(name.length<2||!/^[0-9]{5,24}$/.test(uid))return send(res,400,{error:'Enter a name and numeric game UID'});const t=db.tournaments.find(x=>x.id===tid);if(!t||t.status!=='Open')return send(res,404,{error:'Tournament unavailable'});if(t.joined.length>=t.slots)return send(res,409,{error:'Tournament is full'});if(t.joined.some(x=>x.uid===uid))return send(res,409,{error:'UID already registered'});const player={id:crypto.randomUUID(),name,uid,createdAt:new Date().toISOString()};db.players.push(player);t.joined.push({name,uid,at:new Date().toISOString()});audit('player_registered',`${name} registered for ${t.title}`,req);return send(res,201,{ok:true})}catch{return send(res,400,{error:'Bad request'})}}
 const file=p==='/'?path.join(PUB,'index.html'):path.join(PUB,path.normalize(p).replace(/^([.][.][/\\])+/,''));if(!file.startsWith(PUB))return send(res,403,{error:'Forbidden'});fs.readFile(file,(err,data)=>{if(err)return send(res,404,{error:'Not found'});const ext=path.extname(file);res.writeHead(200,{'content-type':({'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.webmanifest':'application/manifest+json'}[ext]||'application/octet-stream'),'x-content-type-options':'nosniff'});res.end(data)})
});server.listen(PORT,()=>console.log(`FF Arena starter running on http://localhost:${PORT}`));
