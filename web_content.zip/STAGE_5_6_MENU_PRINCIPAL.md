# CGD — Étape 5.6 : menu principal

L'écran de lancement remplace le bouton unique « Entrer dans l'univers » par un menu principal en paysage :
- **Nouvelle carrière** : ouvre la création du manager (demande confirmation si une carrière existe déjà).
- **Continuer** : reprend la carrière enregistrée (désactivé s'il n'y en a pas).
- **Charger une sauvegarde** : affiche l'emplacement enregistré (manager, club, saison) et le charge.
- **Paramètres** : ouvre l'écran Réglages.
- **Quitter** : message de sauvegarde automatique, fermeture si le navigateur l'autorise.

Le menu s'affiche à chaque ouverture du jeu ; un choix le masque jusqu'à la fermeture de l'onglet.
Vérifié en 895 × 393 px (paysage) : aucun débordement du menu.

# Étape 5.7 : configuration de carrière

Nouvelle étape entre la création du profil et le choix de la galaxie / du club :
- Mode de carrière, niveau de l'IA et réputation de départ se choisissent maintenant sur un écran dédié.
- Le choix du club n'affiche plus que le récapitulatif (avec un bouton « Modifier ») ; en mode « Sans emploi », la liste des clubs est désactivée.
- La sauvegarde automatique reste toujours active (information affichée, pas d'interrupteur).
- Les règles existantes (réputation, mode, niveau de l'IA) ne changent pas.

# Étape 5.8 : compétition officielle, prise de fonction, onglets et sous-menus

- **Compétition officielle** : étape ajoutée entre la configuration et le choix du club (9 cartes, jours de match tirés de `COMPETITION_MATCH_DAYS`).
- **Prise de fonction** : écran d'accueil une seule fois après la nomination (message de la présidence, six domaines du conseil, objectifs réels du conseil, délégation du staff — les trois tâches existantes).
- **Navigation façon FM27** : les neuf rubriques en onglets en haut, sous-menu sous les onglets. Sous-menus réels : Compétitions (vue d'ensemble, championnats, Coupe Galactique, Coupe Fédéral, Coupe des Clubs, Champions League, Intergalactique des Clubs, Coupe Intergalactique, Coupe Lunaire, Dame d'Or), Club (contrats, recherche et recrutement, éditeur d'identité), Calendrier (central, administration), Gestion (bureau, offres commerciales).
- Déplacés : l'éditeur d'identité (de Plus / Paramètres vers Club), Dame d'Or (de Club vers Compétitions), Divisions (d'Accueil vers Compétitions > Championnats).
- Nouveaux panneaux Coupe Galactique, Coupe Fédéral, Coupe des Clubs (autorité, jour de match, prochaines rencontres).

# Étape 5.9 : tableau de bord en une seule vue (portail)

- Accueil > **Tableau de bord** : six tuiles (Messages, Prochain match, Classement, Calendrier et résultats, Effectif et finances, Conseil et objectifs) calculées avec les données réelles de la carrière ; chaque tuile ouvre la rubrique correspondante.
- La hauteur du portail s'ajuste à l'écran (`fitPortal`) : aucun défilement ni texte coupé vérifié en 895 × 393 et 844 × 390 (paysage).
- Accueil > **Détails du club et carrière** : l'ancien tableau de bord complet (marché des emplois, classement étendu, statistiques) reste disponible, avec défilement.
- Sans club (mode « Sans emploi »), le portail renvoie vers les détails de la carrière.

# Étape 5.10 : parcours de création en une seule vue et aperçu autonome

- Profil, configuration, compétition officielle et choix du club tiennent chacun sur un seul écran en paysage (vérifié en 895 × 393). Chaque étape masque les précédentes ; l'en-tête et le pied de page sont réduits pendant la création.
- `tools/bundle-apercu.mjs` regroupe `index.html` et tous les modules `src/*.js` dans un seul fichier HTML qui s'ouvre directement, sans serveur : `node tools/bundle-apercu.mjs . CGD_apercu.html`.
