# ANONYMOUX STUDIO — BILLING & PRICING PLAN 2.5.4

## Commercial defaults

- One shared customer credit wallet across all workspaces.
- Standard target markup: 100% over verified provider cost.
- Planning conversion: 1 credit = ₦10. This is a configurable commercial assumption, not a live FX feed.
- Formula: `ceil(provider_cost_NGN * (1 + markup_percent / 100) / credit_value_NGN)`.
- Always round up to a whole credit; enforce a minimum charge of 1 credit.
- Recalculate using current provider prices and a refreshed USD/NGN conversion before activation.
- No volume discounts until actual provider cost, refunds, payment fees and gross margin have been measured.

## Existing server enforcement in this release

The shared wallet reservation ledger in `app/credits.php` currently accepts only the `image` and `video` workspace identifiers. The Admin > Models panel stores one image price and one video price in SQLite (`credit_price_image`, `credit_price_video`). Those two values are server-side enforced for the generation paths that call the shared billing functions.

This is not yet a complete cross-workspace billing engine. In particular, the current Video price is a flat job amount rather than a duration/model-aware settlement. Do not advertise per-second video billing as active until the endpoint calculates and settles the actual provider usage.

## Proposed charge basis by workspace

| Workspace | Charge basis | Activation requirement |
|---|---|---|
| Image Studio | Per output, model and resolution | Model-specific price lookup, reserve before provider call, settle/refund |
| Video Studio | Per generated second and model | Estimate duration, reserve, settle actual provider duration |
| Realtime Studio | Per second, reserved in short intervals | Server-authoritative session meter, heartbeat, graceful stop, reconciliation |
| Voice Studio | Actual provider billable bytes/characters or request units | Capture provider usage and route all paid operations through shared wallet |
| Lip Sync Studio | Model and processed duration / provider request units | Record duration/options, provider cost, reserve/settle/refund |
| Agent Studio | Actual provider USD usage converted to credits | Enable charging only when actual usage is returned and validated |
| Restyle | Per processed second and model | Verify current provider endpoint and enforce shared wallet |

## Previously discussed Decart starting rates (not a substitute for live verification)

The following customer rates were previously discussed as an initial rate card: Lucy 2.5 Realtime 6 credits/second; Fast 11 credits/second; Video 11 credits/generated second; Restyle 3 credits/second; Image 480p 3 credits/output; Image 720p 6 credits/output.

Treat these as candidate selling rates only. Before enabling them, verify current Decart model IDs, provider prices, billing units and account entitlement against the official provider documentation and the exact production model route. The current image/video wallet configuration remains separate and must not be silently overwritten by this proposal.

## Customer credit packages — proposed, not currently activated

| Package | Credits | Price |
|---|---:|---:|
| Starter | 250 | ₦2,500 |
| Creator | 600 | ₦6,000 |
| Studio | 1,500 | ₦15,000 |
| Professional | 3,500 | ₦35,000 |

The 250-credit welcome grant remains subject to the platform's existing eligibility and abuse controls. Package prices and grants must be configured through admin settings/payment code before being shown as live offers.

## Required settlement behavior

1. Validate the authenticated user, model, operation and requested maximum usage.
2. Reserve credits atomically before starting paid provider work.
3. Persist provider job/session ID, model, provider cost, currency, estimated usage and reservation reference.
4. On completion, calculate the final charge from verified usage; debit any difference or refund unused reserved credits.
5. Refund confirmed provider failures idempotently.
6. Keep timeouts/unknown submissions pending reconciliation. Do not automatically refund a request that may have completed upstream.
7. Record every adjustment in the credit transaction ledger and admin audit log.
8. Never trust client-submitted duration, cost, model price or final credit amount.

## Profit and safety dashboard requirements

Show gross sales, provider costs, payment processing fees, refunds, net contribution, gross margin percentage, workspace/model breakdown, and per-user spend. Alert admins when provider costs rise, FX assumptions age, margin falls below target, or a provider's usage response is missing.

## Scope and verification note

This release adds the proposed cross-workspace billing rollout matrix to Admin > Models and documents the rate policy. It does **not** falsely enable wallet charging for Realtime, Voice, Lip Sync, Agent or Restyle. Those routes require workspace-specific integration and end-to-end tests before being billed. The existing Image and Video server-side price controls are preserved.


## 2.5.9 pricing recheck (2026-11-15)

The default credit-package rows are **seeded as active** by `payments_schema()` when a package name is missing; they are not merely a proposal in the current code. Default seeded values (zero bonus credits) are Starter 250 / ₦2,500, Creator 600 / ₦6,000, Studio 1,500 / ₦15,000, and Professional 3,500 / ₦35,000. Administrators can edit package amounts and active status. With those default rows, the nominal purchase rate is ₦10 per ANONYMOUX credit; bonus credits or admin price changes alter the effective rate.

Decart's official pricing page, checked 2026-11-15, lists Lucy 2.5 and Lucy 2.6 realtime at **US$0.02 per active second at 720p**, and Fast mode at **US$0.04 per second**. Decart states that US$1 equals 100 Decart provider credits. These are provider costs, not ANONYMOUX wallet rates. Source: https://docs.platform.decart.ai/getting-started/pricing

The earlier 6 ANONYMOUX credits/sec standard and 11 credits/sec Fast figures remain **candidate retail rates only**. At the default nominal ₦10 per ANONYMOUX credit, they would represent ₦60/sec (₦3,600/min) and ₦110/sec (₦6,600/min), respectively, before package bonuses/discounts. The corresponding simple FX break-even points against Decart's published provider rates are ₦3,000/USD for standard and ₦2,750/USD for Fast, before Flutterwave fees, hosting, taxes, support, failed-session leakage or desired margin. This is arithmetic, not a recommended current selling price. Recalculate using a current FX rate and actual package economics before activation.

**Implementation status remains not billable:** the default `sdk-direct` browser path mints a short-lived model-scoped client token and connects directly to Decart. It does not create an ANONYMOUX realtime wallet reservation, receive a trusted server-side usage meter, or settle/refund realtime credits. The existing `billing_price()` / `billing_reserve()` functions intentionally accept only `image` and `video`. Do not show the 6/11 credit candidate as an active rate and do not treat wallet balance as a realtime spending cap.


## 2.6.4 implemented pricing update

- Image Studio: 20 ANON credits per generation by default. The first runtime migration updates a stored legacy default of 10 to 20 once; a custom Admin price other than 10 is preserved.
- Realtime Studio: 10 ANON credits per provider-billed active second by default. The workspace now uses server-signaled Decart sessions and settles only the `billed_seconds` value returned by Decart. The server records each session's measured quote and uses a unique wallet reference for retry-safe settlement. If the wallet cannot cover the measured charge, usage is recorded as unpaid and can be reconciled after a top-up. If Decart omits billed_seconds, no guessed charge is applied.
- Voice cloning: clone cost is debited before provider creation; confirmed failures are refunded idempotently. Ambiguous provider outcomes retain a pending/uncertain status for manual checking rather than creating unpaid provider-side models.
- AI Agent: simultaneous session starts are serialized in the browser, provider session identifiers are validated, and credits-per-USD conversion defaults to 0 (record usage without wallet deduction) until explicitly enabled in Admin. Provider usage remains settled only from Fish Audio's measured usage response.

These paths have static and source-level regression checks only. Live Decart/Fish Audio behavior and InfinityFree deployment still require testing with the production credentials and host.
