# FOREVER CALCS — prototipo web móvil

Este ZIP contiene una primera base HTML/CSS/JavaScript para abrir en una app constructora que importe proyectos HTML/ZIP.

## Archivos
- `index.html`: estructura de pantallas.
- `styles.css`: interfaz móvil oscura.
- `app.js`: importación local, vista previa, controles iniciales y asistente de planificación.

## Cómo probar
1. Descomprime el ZIP o importa el ZIP en tu constructor de apps.
2. Configura `index.html` como página de inicio.
3. Ejecuta la vista previa.
4. Pulsa `Crear proyecto` e importa un video desde el dispositivo.

## Estado real de esta versión
Implementado: navegación inicial/editor, importación local de video/audio/imagen, reproducción de video, paneles de herramientas, controles iniciales de velocidad, texto superpuesto de previsualización, selección visual de stickers y botón flotante movible.

Pendiente: motor de composición y renderizado, exportación real, recorte exportable, división de clips, keyframes, efectos aplicados al archivo, chroma key real, transiciones renderizables y conexión de IA. Los botones que muestran avisos no simulan que esas funciones estén terminadas.

## Nota técnica
Una aplicación HTML puede servir como interfaz o editor web. Para obtener una experiencia equivalente a un editor nativo como CapCut se necesita integrar un motor multimedia compatible con Android, por ejemplo FFmpeg u otro SDK de edición, además de permisos de archivos y pruebas de rendimiento. La disponibilidad de esas integraciones depende de la app constructora que uses.
