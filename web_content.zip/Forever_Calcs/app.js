const $=s=>document.querySelector(s);
const home=$("#home"),editor=$("#editor"),video=$("#video"),preview=$("#preview");
let videoURL=null,audioURL=null,undoStack=[],redoStack=[],fabDrag=false,offset={x:0,y:0};
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function openEditor(){home.classList.add("hidden");editor.classList.remove("hidden");$("#importModal").classList.remove("hidden")}
$("#startProject").onclick=openEditor;$("#newProject").onclick=openEditor;
$("#backHome").onclick=()=>{editor.classList.add("hidden");home.classList.remove("hidden")};
$("#importMore").onclick=()=>$("#importModal").classList.remove("hidden");
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>$("#"+b.dataset.close).classList.add("hidden"));
function formatTime(s){if(!isFinite(s))s=0;let m=Math.floor(s/60),sec=Math.floor(s%60);return String(m).padStart(2,"0")+":"+String(sec).padStart(2,"0")}
function updateTime(){$("#timeReadout").textContent=`${formatTime(video.currentTime)} / ${formatTime(video.duration)}`}
video.addEventListener("timeupdate",updateTime);video.addEventListener("loadedmetadata",()=>{updateTime();$("#videoTrack").innerHTML=`<div class="clip-block">VIDEO · ${formatTime(video.duration)}</div>`});
$("#videoInput").onchange=e=>{const f=e.target.files[0];if(!f)return;if(videoURL)URL.revokeObjectURL(videoURL);videoURL=URL.createObjectURL(f);video.src=videoURL;video.style.display="block";$("#previewEmpty").style.display="none";$("#importModal").classList.add("hidden");toast("Video importado. Ya puedes previsualizarlo.");};
$("#imageInput").onchange=e=>{const f=e.target.files[0];if(!f)return;const url=URL.createObjectURL(f);$("#previewEmpty").style.display="none";video.pause();video.style.display="none";preview.style.background=`center/contain no-repeat url("${url}")`;$("#importModal").classList.add("hidden");toast("Imagen añadida a la vista previa. Esta versión inicial no la renderiza aún.");};
$("#audioInput").onchange=e=>{const f=e.target.files[0];if(!f)return;audioURL=URL.createObjectURL(f);$("#audioTrack").innerHTML=`<div class="clip-block">♫ ${f.name}</div>`;$("#importModal").classList.add("hidden");toast("Audio cargado como recurso local.");};
$("#playBtn").onclick=()=>{if(!video.src){toast("Primero importa un video.");return}if(video.paused){video.play();$("#playBtn").textContent="Ⅱ"}else{video.pause();$("#playBtn").textContent="▶"}};
video.onended=()=>$("#playBtn").textContent="▶";
$("#fitBtn").onclick=()=>{preview.requestFullscreen?.()};
function setPanel(title,html){$("#panelTitle").textContent=title;$("#panelContent").innerHTML=html}
const toolContent={
trim:`<div class="control"><label>Inicio (segundos)<input id="trimStart" type="number" min="0" step=".1" value="0"></label><label>Fin (segundos)<input id="trimEnd" type="number" min="0" step=".1" value="0"></label><button class="primary" id="applyTrim">Aplicar rango de vista previa</button></div>`,
split:`<button class="tool" id="splitHere"><i>⫶</i>Marcar división aquí</button>`,
speed:`<div class="control"><label>Velocidad <b id="speedVal">1.0×</b><input id="speedRange" type="range" min=".25" max="3" step=".05" value="1"></label></div>`,
text:`<div class="control"><label>Texto<input id="textValue" placeholder="Escribe tu título"></label><label>Tamaño<input id="textSize" type="range" min="14" max="56" value="26"></label><button class="primary" id="applyText">Añadir texto a vista previa</button></div>`,
stickers:`<div class="sticker-grid">${["⚡","👑","🏆","💎","🚀","🎮","✦","🔥","FC","FPS+","VIP","PRO"].map(x=>`<button class="sticker-choice">${x}</button>`).join("")}</div>`,
effects:`<div class="effect-grid">${["Glow","RGB Split","Glitch","Motion Blur","Flash","Shake","Zoom Blur","Neon"].map(x=>`<button class="effect-choice">${x}</button>`).join("")}</div>`,
transitions:`<div class="effect-grid">${["Flash","Zoom","Desenfoque","Deslizar","Glitch","Giro","Barrido","Distorsión"].map(x=>`<button class="effect-choice">${x}</button>`).join("")}</div>`,
chroma:`<div class="control"><label>Color a retirar <input id="chromaColor" type="color" value="#00ff00"></label><label>Tolerancia<input type="range" min="0" max="100" value="35"></label><p class="muted">Herramienta visual de configuración. El recorte real requiere integrar un motor de composición.</p></div>`,
audio:`<button class="primary" id="chooseAudio">＋ Importar audio</button>`,
crop:`<div class="effect-grid">${["9:16","16:9","1:1","4:5","Girar 90°","Voltear"].map(x=>`<button class="effect-choice">${x}</button>`).join("")}</div>`,
filters:`<div class="effect-grid">${["Original","Cálido","Frío","Contraste","Cine","B&N","Saturado","Suave"].map(x=>`<button class="effect-choice">${x}</button>`).join("")}</div>`,
ai:`<p class="muted">Forever AI puede ayudarte a planificar efectos y estructura. Para modificar clips automáticamente hay que conectar un modelo de IA y un motor de edición.</p><button class="primary" id="openAIFromPanel">Abrir asistente</button>`
};
document.addEventListener("click",e=>{
 const t=e.target.closest("[data-tool]");if(t){const name=t.dataset.tool;setPanel(name[0].toUpperCase()+name.slice(1),toolContent[name]||"");wirePanel(name);return}
 const s=e.target.closest(".sticker-choice");if(s){$("#stickerOverlay").textContent=s.textContent;toast("Sticker colocado en la vista previa.");return}
 const ef=e.target.closest(".effect-choice");if(ef){toast(ef.textContent+" seleccionado. El efecto necesita motor de renderizado para aplicarse al archivo.");return}
});
function wirePanel(name){
 if(name==="speed"){const r=$("#speedRange");if(r)r.oninput=()=>{let v=+r.value;$("#speedVal").textContent=v.toFixed(2)+"×";video.playbackRate=v}}
 if(name==="text"){$("#applyText")?.addEventListener("click",()=>{const v=$("#textValue").value;$("#textOverlay").textContent=v;$("#textOverlay").style.fontSize=$("#textSize").value+"px";$("#textTrack").innerHTML=`<div class="clip-block">T ${v||"Texto"}</div>`;toast("Texto agregado a la vista previa.")})}
 if(name==="trim"){$("#trimEnd").value=video.duration||0;$("#applyTrim")?.addEventListener("click",()=>{let a=+$("#trimStart").value,b=+$("#trimEnd").value;if(!video.src){toast("Importa un video primero.");return}if(a<0||b<=a||b>video.duration){toast("Comprueba el inicio y el final.");return}video.currentTime=a;video.dataset.trimEnd=b;toast("Rango de reproducción marcado. Exportación recortada aún no integrada.")})}
 if(name==="split")$("#splitHere")?.addEventListener("click",()=>toast("Marca de división: "+formatTime(video.currentTime)+". La división exportable se integrará con el motor de edición."));
 if(name==="audio")$("#chooseAudio")?.addEventListener("click",()=>$("#audioInput").click());
 if(name==="ai")$("#openAIFromPanel")?.addEventListener("click",()=>$("#aiModal").classList.remove("hidden"));
}
$("#closePanel").onclick=()=>setPanel("Herramientas",`<button class="tool" data-tool="trim"><i>✂</i>Recortar</button><button class="tool" data-tool="split"><i>⫶</i>Dividir</button><button class="tool" data-tool="speed"><i>◷</i>Velocidad</button><button class="tool" data-tool="text"><i>T</i>Texto</button><button class="tool" data-tool="stickers"><i>✦</i>Stickers</button><button class="tool" data-tool="effects"><i>✧</i>Efectos</button><button class="tool" data-tool="transitions"><i>⇄</i>Transiciones</button><button class="tool" data-tool="chroma"><i>◉</i>Chroma key</button><button class="tool" data-tool="audio"><i>♫</i>Audio</button><button class="tool" data-tool="crop"><i>▣</i>Transformar</button><button class="tool" data-tool="filters"><i>◐</i>Filtros</button><button class="tool" data-tool="ai"><i>✦</i>Asistente IA</button>`);
$("#aiFab").onclick=()=>$("#aiModal").classList.remove("hidden");
$("#sendAI").onclick=()=>{const q=$("#aiInput").value.trim();if(!q)return;$("#aiReply").textContent="Solicitud recibida: “"+q+"”\n\nPuedo ayudarte a planificar los pasos. Para ejecutar ediciones automáticas reales, conecta un proveedor de IA y un motor de renderizado al proyecto.";$("#aiInput").value=""};
document.querySelectorAll(".suggestion").forEach(b=>b.onclick=()=>{$("#aiInput").value=b.textContent});
$("#exportBtn").onclick=()=>toast("Exportación de video todavía no está implementada en esta versión inicial.");
$("#undoBtn").onclick=()=>toast("Todavía no hay acciones de edición exportables para deshacer.");
$("#redoBtn").onclick=()=>toast("No hay acciones para rehacer.");
// Arrastrar el asistente flotante
const fab=$("#aiFab");
fab.addEventListener("pointerdown",e=>{fabDrag=true;const r=fab.getBoundingClientRect();offset.x=e.clientX-r.left;offset.y=e.clientY-r.top;fab.setPointerCapture(e.pointerId)});
fab.addEventListener("pointermove",e=>{if(!fabDrag)return;fab.style.left=(e.clientX-offset.x)+"px";fab.style.top=(e.clientY-offset.y)+"px";fab.style.right="auto";fab.style.bottom="auto"});
fab.addEventListener("pointerup",()=>fabDrag=false);
