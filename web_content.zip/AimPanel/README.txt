AIM PANEL Android project

WHAT THIS IS
- A simple Android WebView wrapper for the included HTML demo.
- The buttons and slider only change the visual demo.
- It does not connect to or control Free Fire.

BUILD
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio, choose Open and select the extracted AimPanel folder.
4. Allow Gradle sync and install any SDK components Android Studio requests.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the generated APK location when the build finishes.

Requirements:
- Android Studio and a compatible JDK (Android Studio's bundled JDK is recommended).
- Internet may be required the first time Gradle downloads build dependencies.

No Gradle wrapper is included in this starter project; Android Studio can open it and use its configured Gradle installation.
