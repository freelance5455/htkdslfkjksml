# Slam Afrique – projet Android Studio

1. Installez Android Studio, puis Fichier > Ouvrir et choisissez ce dossier.
2. Laissez la synchronisation Gradle se terminer (si Android Studio signale un « wrapper » manquant, acceptez qu’il utilise sa propre version de Gradle).
3. Branchez un téléphone (débogage USB activé) ou lancez un émulateur, puis appuyez sur Run.
4. Pour obtenir un APK : Build > Build APK(s).
5. Pour le Play Store : Build > Generate Signed App Bundle (compte développeur Google Play requis).

Le jeu se modifie dans app/src/main/assets/index.html (mots, couleurs, paysages).

Note : le paysage 3D charge la bibliothèque three.js depuis Internet. Hors connexion, le jeu affiche automatiquement les paysages 2D. Pour un 3D 100 % hors ligne, placez three.min.js (r128) dans app/src/main/assets et changez l’adresse du script dans index.html.
