PARKING POS MANAGEMENT — STARTER PROJECT

Purpose: manage a real parking area, vehicle entries, parking fees and checkout receipts.

Included files:
- index.html: app screens
- style.css: responsive blue-and-white design
- app.js: vehicle entry, hourly fee calculation, checkout, receipts, history, settings and backup/restore

Run on Android:
1. Download and extract this ZIP in your phone's Files app.
2. Open the extracted folder in Acode.
3. Preview index.html in Acode or a browser.
4. To create an APK, package the web app in an Android WebView wrapper or a suitable HTML-to-APK builder. This ZIP itself is not an APK.

Data and limitations:
- Records are saved locally in the same browser/WebView using localStorage.
- Clearing app/browser data may erase records; download JSON backups regularly.
- Fees are calculated from whole hours (minimum one hour) and marked paid after checkout confirmation.
- No online payment gateway, server, user accounts or cloud sync is included.
- Test the app and backup/restore flow before using it for real parking operations.
