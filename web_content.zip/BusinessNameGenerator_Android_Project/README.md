# Business Name Generator — Android Studio project

This project wraps the supplied `assets/index.html` business-name generator in an Android WebView so it can be built as an Android app.

## Build an APK
1. Install Android Studio on a computer and install Android SDK Platform 35 (or adjust `compileSdk` / `targetSdk` to an installed SDK).
2. Open this folder (`BusinessNameGenerator_Android_Project`) in Android Studio.
3. Allow Gradle sync to finish. An internet connection may be required the first time to download the Android Gradle Plugin.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- This is the Android project source, not a compiled APK.
- The original uploaded file contained only an HTML asset and README, not Android's compiled app components, so it was not an installable APK.
- The app uses the bundled HTML locally and does not request internet permission.
