Neko v0.1 Offline

Abre index.html en un navegador compatible.

Sprites de Neko integrados:
- normal / feliz / triste / hambriento / enojado
- dormido
- caminar (2 frames)
- salto
- vista lateral
- vista trasera

Audio local:
- audio/house_background.ogg: menú, bucle
- audio/game_time.ogg: minijuego, bucle
- audio/sleep_time.ogg: dormir, bucle
- audio/pat_pat.ogg: acariciar, una vez
- audio/level_up.ogg: nivel/recompensa, una vez

El progreso se guarda localmente.
