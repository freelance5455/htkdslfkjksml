// Configuración del juego. Cambia aquí la fuente propia (ej. "MiFuente") tras añadir el TTF en Assets/Fonts y @font-face en index.html.
window.CONFIG = {
  font: "'Courier New', monospace",   // FUENTE TEMPORAL - sustituir por la fuente propia de AbisaiGames
  width: 320, height: 180, groundY: 160,
  walkSpeed: 55, runSpeed: 105, jumpV: -170, gravity: 520,
  jumpscareMs: 50,
  volume: { music: 0.5, ambient: 0.5, sfx: 0.8, interactions: 0.8, cinematics: 1.0 }
};
