// Diálogos editables sin tocar el código principal.
window.DIALOGUES = {
  wake: ["Mierda, otra pesadilla. Mejor iré por un vaso de agua."],
  bed: { question: "¿Quieres dormir?", yes: ["Todavía no puedo dormir... Primero el agua."], no: ["Mejor no."] },
  room: ["Mi cuarto. Todo está demasiado silencioso."],
  wardrobe_empty: ["Solo ropa y sombras."],
  wardrobe_flashlight: ["Una linterna. Con la tecla Q (o el botón Q) la enciendo."],
  desk: ["Mi escritorio. Nada raro... eso creo."],
  door_closed: ["La puerta está cerrada."],
  tv: ["La tele está apagada."],
  fridge: ["La nevera zumba en la oscuridad. No hay nada que me interese."],
  cabinet_glass: ["Un vaso. Perfecto."],
  cabinet_empty: ["Platos y utensilios."],
  sink_noglass: ["Necesito un vaso primero."],
  sink_fill: ["El agua suena demasiado fuerte..."],
  end: ["Listo. Ahora a volver a la cama..."]
};
