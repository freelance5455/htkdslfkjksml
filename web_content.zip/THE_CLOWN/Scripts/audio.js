// Audio sintetizado (provisional). Categorías con volumen independiente.
const AudioSys = (() => {
  let ctx, gains = {};
  function init(){
    if(ctx) return;
    ctx = new (window.AudioContext||window.webkitAudioContext)();
    for(const k in CONFIG.volume){ gains[k]=ctx.createGain(); gains[k].gain.value=CONFIG.volume[k]; gains[k].connect(ctx.destination); }
    ambient();
  }
  function setVolume(cat,v){ if(gains[cat]) gains[cat].gain.value=v; }
  function tone(cat,f,d,type='sine',vol=0.2,slide=0){
    if(!ctx) return; const o=ctx.createOscillator(), g=ctx.createGain();
    o.type=type; o.frequency.value=f; if(slide) o.frequency.exponentialRampToValueAtTime(Math.max(20,f+slide),ctx.currentTime+d);
    g.gain.setValueAtTime(vol,ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.0001,ctx.currentTime+d);
    o.connect(g); g.connect(gains[cat]); o.start(); o.stop(ctx.currentTime+d);
  }
  function noise(cat,d,vol=0.2,freq=800){
    if(!ctx) return; const n=ctx.sampleRate*d, b=ctx.createBuffer(1,n,ctx.sampleRate), a=b.getChannelData(0);
    for(let i=0;i<n;i++) a[i]=(Math.random()*2-1)*(1-i/n);
    const s=ctx.createBufferSource(); s.buffer=b; const f=ctx.createBiquadFilter(); f.type='lowpass'; f.frequency.value=freq;
    const g=ctx.createGain(); g.gain.value=vol; s.connect(f); f.connect(g); g.connect(gains[cat]); s.start();
  }
  function ambient(){ // zumbido grave constante muy suave (el silencio también es ambiente)
    const o=ctx.createOscillator(), g=ctx.createGain(); o.type='sine'; o.frequency.value=48; g.gain.value=0.025; o.connect(g); g.connect(gains.ambient); o.start();
  }
  return { init, setVolume,
    step(){ noise('sfx',0.06,0.15,500); }, stepRun(){ noise('sfx',0.05,0.22,700); },
    door(){ tone('interactions',110,0.35,'sawtooth',0.12,-50); noise('interactions',0.2,0.1,300); },
    open(){ noise('interactions',0.25,0.12,600); tone('interactions',200,0.2,'square',0.05,-80); },
    pick(){ tone('interactions',880,0.08,'triangle',0.15); tone('interactions',1320,0.1,'triangle',0.1); },
    click(){ tone('sfx',600,0.05,'square',0.08); },
    switch_(){ tone('interactions',300,0.04,'square',0.15); },
    water(){ noise('interactions',1.6,0.18,2500); },
    bed(){ tone('interactions',90,0.4,'sawtooth',0.1,-30); },
    scare(){ noise('cinematics',0.5,0.9,6000); tone('cinematics',70,0.5,'sawtooth',0.6,-40); tone('cinematics',1500,0.3,'square',0.4,-1000); },
    breath(){ noise('ambient',1.2,0.04,400); }
  };
})();
