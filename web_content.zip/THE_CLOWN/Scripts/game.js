(() => {
const C = CONFIG, W = C.width, H = C.height, GY = C.groundY, D = DIALOGUES;
document.documentElement.style.setProperty('--font', C.font);
const $ = id => document.getElementById(id);
const cv = $('c'), ctx = cv.getContext('2d'); ctx.imageSmoothingEnabled = false;
const dark = document.createElement('canvas'); dark.width = W; dark.height = H; const dctx = dark.getContext('2d');
const show = (id, on = true, disp = 'block') => $(id).style.display = on ? disp : 'none';
const img = src => { const i = new Image(); i.src = src; return i; };
const A = {
  bed: img('Assets/Environments/Bedroom_Night.png'), hall: img('Assets/Environments/Hallway_PROVISIONAL.png'),
  living: img('Assets/Environments/LivingRoom_PROVISIONAL.png'), kitchen: img('Assets/Environments/Kitchen_PROVISIONAL.png'),
  idle: img('Assets/Characters/Kenneth/Kenneth_idle.png'), walk: img('Assets/Characters/Kenneth/Kenneth_walk.png'), run: img('Assets/Characters/Kenneth/Kenneth_run.png')
};
const FR = { idle: [3, 2], walk: [6, 8], run: [3, 10] }; // frames, fps
const CW = 96, CH = 160, SC = 0.5;

// ---------- Estado ----------
const S = { mode: 'title', room: 'bedroom', px: 70, jy: 0, vy: 0, dir: 1, anim: 'idle', t: 0, lastStep: -1,
  hasFlash: false, flashOn: false, wardrobeOpen: false, cabOpen: false, hasGlass: false, glassFull: false, fridgeOpen: false,
  dialog: null, choice: false, paused: false, ended: false, flick: 0 };
const ROOMS = {
  bedroom: { w: 650, bg: A.bed }, hallway: { w: W, bg: A.hall }, living: { w: W, bg: A.living }, kitchen: { w: W, bg: A.kitchen }
};
const keys = {}, pressed = {};
const press = k => { pressed[k] = true; };

// ---------- UI helpers ----------
function say(lines, cb) { S.dialog = { lines: lines.slice(), i: 0, cb }; renderDialog(); }
function renderDialog() { const d = S.dialog; if (!d) { show('dialog', false); return; } $('dialog').innerHTML = d.lines[d.i] + '<i>▼ E</i>'; show('dialog', true); }
function advance() { const d = S.dialog; if (!d) return; d.i++; if (d.i >= d.lines.length) { S.dialog = null; show('dialog', false); d.cb && d.cb(); } else renderDialog(); AudioSys.click(); }
function ask(q, opts, cb) {
  S.dialog = { lines: [q], i: 0, waiting: true }; renderDialog(); $('dialog').querySelector('i').remove();
  const ch = $('choice'); ch.innerHTML = ''; S.choice = true;
  opts.forEach((o, n) => { const b = document.createElement('button'); b.textContent = o;
    const pick = e => { e.preventDefault(); e.stopPropagation(); ch.style.display = 'none'; S.choice = false; S.dialog = null; show('dialog', false); AudioSys.click(); cb(n); };
    b.addEventListener('pointerdown', pick); ch.appendChild(b); });
  ch.style.display = 'flex';
}
function hud() {
  let t = '';
  if (S.hasFlash) t += '🔦 Linterna ' + (S.flashOn ? '[ON]' : '[off]') + '  ';
  if (S.hasGlass) t += '🥛 Vaso' + (S.glassFull ? ' (con agua)' : '');
  $('hud').textContent = t; show('hud', !!t);
}
function fade(to, ms = 500) { $('fade').style.transition = 'opacity ' + ms / 1000 + 's'; show('fade', true); void $('fade').offsetWidth; $('fade').style.opacity = to; }
const wait = ms => new Promise(r => setTimeout(r, ms));
function center(t) { $('center').textContent = t || ''; show('center', !!t, 'flex'); }

// ---------- Objetos interactivos ----------
// key: 'E' interactuar | 'F' recoger. Posiciones en coordenadas del cuarto.
const OBJ = [
  { room: 'bedroom', x: 78, r: 40, key: 'E', label: 'Cama', act() { AudioSys.bed(); ask(D.bed.question, ['Sí', 'No'], n => say(n === 0 ? D.bed.yes : D.bed.no)); } },
  { room: 'bedroom', x: 320, r: 38, key: 'E', label: 'Escritorio', act() { say(D.desk); } },
  { room: 'bedroom', x: 435, r: 36, key: 'E', label: 'Armario', show: () => !S.wardrobeOpen, act() {
      AudioSys.open(); S.wardrobeOpen = true; say(S.hasFlash ? D.wardrobe_empty : D.wardrobe_flashlight); } },
  { room: 'bedroom', x: 435, r: 36, key: 'F', label: 'Linterna', show: () => S.wardrobeOpen && !S.hasFlash, act() { AudioSys.pick(); S.hasFlash = true; hud(); } },
  { room: 'bedroom', x: 526, r: 30, key: 'E', label: 'Puerta', act() { go('hallway', 30, 'Puerta'); } },
  { room: 'hallway', x: 22, r: 28, key: 'E', label: 'Dormitorio', act() { go('bedroom', 500, 'Puerta'); } },
  { room: 'hallway', x: 298, r: 28, key: 'E', label: 'Sala', act() { go('living', 30, 'Puerta'); } },
  { room: 'living', x: 22, r: 28, key: 'E', label: 'Pasillo', act() { go('hallway', 280, 'Puerta'); } },
  { room: 'living', x: 298, r: 28, key: 'E', label: 'Cocina', act() { go('kitchen', 30, 'Puerta'); } },
  { room: 'living', x: 170, r: 40, key: 'E', label: 'Televisión', act() { AudioSys.switch_(); say(D.tv); } },
  { room: 'kitchen', x: 22, r: 24, key: 'E', label: 'Sala', act() { go('living', 280, 'Puerta'); } },
  { room: 'kitchen', x: 70, r: 28, key: 'E', label: 'Nevera', act() { S.fridgeOpen = !S.fridgeOpen; AudioSys.open(); if (S.fridgeOpen) say(D.fridge); } },
  { room: 'kitchen', x: 160, r: 30, key: 'E', label: 'Gabinete', show: () => !S.cabOpen, act() { AudioSys.open(); S.cabOpen = true; say(S.hasGlass ? D.cabinet_empty : D.cabinet_glass); } },
  { room: 'kitchen', x: 160, r: 30, key: 'F', label: 'Vaso', show: () => S.cabOpen && !S.hasGlass, act() { AudioSys.pick(); S.hasGlass = true; hud(); } },
  { room: 'kitchen', x: 255, r: 30, key: 'E', label: 'Fregadero', show: () => !S.glassFull, act() {
      if (!S.hasGlass) { say(D.sink_noglass); return; }
      AudioSys.water(); S.glassFull = true; hud();
      say(D.sink_fill, () => setTimeout(() => endLevel(), 800)); } },
];
const near = key => OBJ.filter(o => o.room === S.room && o.key === key && (!o.show || o.show()) && Math.abs(o.x - S.px) < o.r)
  .sort((a, b) => Math.abs(a.x - S.px) - Math.abs(b.x - S.px))[0];
async function go(room, x, snd) {
  S.mode = 'trans'; AudioSys.door(); fade(1, 300); await wait(350);
  S.room = room; S.px = x; S.fridgeOpen = false; fade(0, 400); await wait(400); show('fade', false); S.mode = 'play';
}
async function endLevel() {
  S.mode = 'trans'; fade(1, 1500); await wait(1700);
  center('THE CLOWN\n\nFin del Nivel 1\nKenneth vuelve a su cuarto...\n\n[ Toca para reiniciar ]'); S.ended = true;
}

// ---------- Intro ----------
async function startGame() {
  AudioSys.init(); show('title', false); S.mode = 'intro';
  center('...'); await wait(1600);
  center('No mires atrás.'); AudioSys.breath(); await wait(2200);
  center(''); await wait(1200);
  show('scare', true); AudioSys.scare(); await wait(C.jumpscareMs); show('scare', false);
  await wait(1400);
  S.room = 'bedroom'; S.px = 70; S.dir = 1; S.mode = 'wake';
  show('fade', true); $('fade').style.opacity = 1; await wait(100); fade(0, 2500); AudioSys.breath(); await wait(2600); show('fade', false);
  say(D.wake, () => { S.mode = 'play'; });
}

// ---------- Input ----------
const KM = { ArrowLeft: 'left', a: 'left', ArrowRight: 'right', d: 'right', Shift: 'run', ArrowUp: 'jump', w: 'jump', ' ': 'jump', ArrowDown: 'crouch', s: 'crouch', e: 'E', f: 'F', q: 'Q' };
addEventListener('keydown', e => {
  if (S.mode === 'title') { startGame(); return; }
  if (e.key === 'Escape') { togglePause(); return; }
  const k = KM[e.key] || KM[e.key.toLowerCase()]; if (!k) return; e.preventDefault();
  if (!keys[k]) press(k); keys[k] = true;
});
addEventListener('keyup', e => { const k = KM[e.key] || KM[e.key.toLowerCase()]; if (k) keys[k] = false; });
document.querySelectorAll('#touch .b').forEach(b => {
  const k = b.dataset.k;
  b.addEventListener('pointerdown', e => { e.preventDefault(); b.setPointerCapture(e.pointerId); keys[k] = true; press(k); b.classList.add('on'); });
  const up = () => { keys[k] = false; b.classList.remove('on'); };
  b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); b.addEventListener('lostpointercapture', up);
});
$('dialog').addEventListener('pointerdown', e => { e.preventDefault(); if (!S.choice) advance(); });
$('title').addEventListener('pointerdown', () => startGame());
$('center').addEventListener('pointerdown', () => { if (S.ended) location.reload(); });
$('center').style.pointerEvents = 'auto';
document.addEventListener('contextmenu', e => e.preventDefault());

function togglePause() {
  if (S.mode === 'title' || S.mode === 'intro') return;
  S.paused = !S.paused; const p = $('pause');
  if (S.paused) {
    p.innerHTML = '<h2 style="margin:0 0 1vmin">PAUSA</h2>' + Object.keys(C.volume).map(k =>
      `<label>${{ music: 'Música', ambient: 'Ambiente', sfx: 'Efectos', interactions: 'Interacciones', cinematics: 'Cinemáticas' }[k]}<input type="range" min="0" max="1" step="0.05" value="${C.volume[k]}" data-v="${k}"></label>`).join('') +
      '<button id="resume">Continuar</button>';
    p.querySelectorAll('input').forEach(i => i.addEventListener('input', () => { C.volume[i.dataset.v] = +i.value; AudioSys.setVolume(i.dataset.v, +i.value); }));
    p.querySelector('#resume').addEventListener('pointerdown', () => togglePause());
    p.style.display = 'flex';
  } else p.style.display = 'none';
}
$('pbtn').addEventListener('pointerdown', e => { e.preventDefault(); togglePause(); });

// ---------- Loop ----------
let last = performance.now(), camX = 0;
const dust = Array.from({ length: 28 }, () => ({ x: Math.random() * 700, y: Math.random() * H, s: 4 + Math.random() * 8 }));
function update(dt) {
  S.t += dt;
  if (S.mode !== 'play' && S.mode !== 'wake') { if (pressed.E || pressed.F || pressed.jump) { if (S.dialog && !S.choice) advance(); } return; }
  if (S.dialog) { if ((pressed.E || pressed.F || pressed.jump) && !S.choice) advance(); return; }
  if (S.mode === 'wake') return;
  const room = ROOMS[S.room]; let mv = 0;
  if (keys.left) mv -= 1; if (keys.right) mv += 1;
  const crouch = keys.crouch && S.jy === 0; const run = keys.run && !crouch;
  if (mv && !crouch) { S.dir = mv; S.px += mv * (run ? C.runSpeed : C.walkSpeed) * dt; }
  S.px = Math.max(10, Math.min(room.w - 10, S.px));
  if (pressed.jump && S.jy === 0 && !crouch) S.vy = C.jumpV;
  if (S.jy < 0 || S.vy < 0) { S.vy += C.gravity * dt; S.jy += S.vy * dt; if (S.jy >= 0) { S.jy = 0; S.vy = 0; } }
  S.anim = (mv && !crouch) ? (run ? 'run' : 'walk') : 'idle'; S.crouch = crouch;
  // pasos
  const fr = Math.floor(S.t * FR[S.anim][1]) % FR[S.anim][0];
  if (mv && S.jy === 0 && (fr === 0 || fr === (S.anim === 'walk' ? 3 : 1)) && S.lastStep !== fr + S.anim) { S.lastStep = fr + S.anim; run ? AudioSys.stepRun() : AudioSys.step(); }
  if (!(fr === 0 || fr === 3 || fr === 1)) S.lastStep = -1;
  if (pressed.Q) { if (S.hasFlash) { S.flashOn = !S.flashOn; AudioSys.switch_(); hud(); } }
  if (pressed.E) { const o = near('E'); o && o.act(); }
  if (pressed.F) { const o = near('F'); o && o.act(); }
}
function drawPlayer() {
  const f = Math.floor(S.t * FR[S.anim][1]) % FR[S.anim][0];
  const a = A[S.anim]; if (!a.complete) return;
  const w = CW * SC, h = CH * SC * (S.crouch ? 0.75 : 1);
  const x = Math.round(S.px - camX), y = Math.round(GY + S.jy + 2);
  ctx.save(); ctx.translate(x, y); ctx.scale(S.dir, 1);
  ctx.drawImage(a, f * CW, 0, CW, CH, -w / 2, -h, w, h); ctx.restore();
}
function drawProps() {
  const o = x => Math.round(x - camX);
  if (S.room === 'kitchen') { // fregadero provisional + indicadores
    ctx.fillStyle = '#3b4a5e'; ctx.fillRect(o(235), GY - 30, 42, 30); ctx.fillStyle = '#1b2433'; ctx.fillRect(o(240), GY - 28, 32, 8);
    ctx.fillStyle = '#8a97aa'; ctx.fillRect(o(252), GY - 42, 3, 12); ctx.fillRect(o(252), GY - 42, 10, 3);
    if (S.fridgeOpen) { ctx.fillStyle = 'rgba(200,230,255,.35)'; ctx.fillRect(o(50), GY - 70, 40, 70); }
    if (S.cabOpen && !S.hasGlass) { ctx.fillStyle = 'rgba(190,220,255,.9)'; ctx.fillRect(o(158), GY - 60, 5, 8); }
  }
  if (S.room === 'bedroom' && S.wardrobeOpen && !S.hasFlash) { ctx.fillStyle = '#ffd966'; ctx.fillRect(o(435), GY - 40, 8, 3); }
}
function drawLight() {
  const o = Math.round(S.px - camX), cy = GY - 38 + S.jy;
  dctx.globalCompositeOperation = 'source-over'; dctx.clearRect(0, 0, W, H);
  dctx.fillStyle = 'rgba(2,2,14,' + (S.flashOn ? 0.62 : 0.4) + ')'; dctx.fillRect(0, 0, W, H);
  if (S.flashOn) {
    if (Math.random() < 0.015) S.flick = 4; const fl = S.flick > 0 ? (S.flick-- , 0.5) : 1;
    dctx.globalCompositeOperation = 'destination-out';
    const L = [60, 100, 140], SP = [14, 24, 34];
    for (let i = 2; i >= 0; i--) {
      dctx.fillStyle = 'rgba(0,0,0,' + 0.3 * fl + ')'; dctx.beginPath(); dctx.moveTo(o + S.dir * 6, cy);
      dctx.lineTo(o + S.dir * L[i], cy - SP[i]); dctx.lineTo(o + S.dir * L[i], cy + SP[i]); dctx.closePath(); dctx.fill();
    }
    dctx.beginPath(); dctx.arc(o, cy + 6, 16, 0, 7); dctx.fillStyle = 'rgba(0,0,0,.2)'; dctx.fill();
  }
  ctx.drawImage(dark, 0, 0);
}
function drawPrompts() {
  const o = near('F') || near('E'); if (!o || S.dialog || S.mode !== 'play') return;
  const x = Math.round(o.x - camX), y = GY - 92;
  ctx.fillStyle = 'rgba(5,5,14,.85)'; ctx.fillRect(x - 6, y - 6, 12, 12); ctx.strokeStyle = '#fff'; ctx.strokeRect(x - 5.5, y - 5.5, 11, 11);
  ctx.fillStyle = '#fff'; ctx.font = '9px ' + C.font; ctx.textAlign = 'center'; ctx.fillText(o.key, x, y + 3.5);
  ctx.font = '7px ' + C.font; ctx.fillText(o.label, x, y - 9);
}
function draw() {
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
  if (S.mode === 'title' || S.mode === 'intro') return;
  const r = ROOMS[S.room]; camX = Math.max(0, Math.min(r.w - W, S.px - W / 2)); camX = Math.round(camX);
  if (r.bg.complete) ctx.drawImage(r.bg, -camX, 0, r.w, H);
  drawProps(); drawPlayer();
  // polvo
  ctx.fillStyle = 'rgba(200,200,255,.35)';
  dust.forEach(d => { d.x += d.s * 0.02; d.y += Math.sin(S.t + d.s) * 0.05; if (d.x > r.w) d.x = 0; ctx.fillRect(Math.round(d.x - camX), Math.round(d.y), 1, 1); });
  drawLight(); drawPrompts();
}
function loop(now) {
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  if (!S.paused) { update(dt); } for (const k in pressed) pressed[k] = false;
  draw(); requestAnimationFrame(loop);
}
show('title', true, 'flex'); $('fade').style.display = 'none';
requestAnimationFrame(loop);
})();
