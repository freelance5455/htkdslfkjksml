# THE CLOWN — Nivel 1 (versión jugable provisional) · AbisaiGames

## Cómo jugar
Abre `index.html` en el navegador (PC o móvil). En móvil, ponlo en horizontal.
Para probar en el teléfono, sube la carpeta a un hosting o ábrelo desde un servidor local.

## Controles
| Acción | PC | Móvil |
|---|---|---|
| Mover | A/D o flechas | ◀ ▶ |
| Correr | Shift | RUN (mantener) |
| Saltar | W / Espacio | ▲ |
| Agacharse | S / ↓ | ▼ |
| Interactuar | E | E |
| Recoger | F | F |
| Linterna | Q | Q (tras recogerla en el armario) |
| Pausa / volumen | Esc | II |

## Recorrido
Pesadilla → jumpscare (50 ms, imagen original del Payaso) → despertar → dormitorio (cama, escritorio, armario con linterna)
→ pasillo → sala → cocina (nevera, gabinete con vaso, fregadero) → llenar el vaso → fin del nivel.

## Qué es original y qué es provisional
- ORIGINAL (recortado de tus referencias): Kenneth (idle 3, caminar 6, correr 3 cuadros), imagen del Payaso, fondo del dormitorio nocturno.
- PROVISIONAL: pasillo, sala y cocina (miniaturas de tu hoja de escenarios, estiradas y borrosas: sustituir por fondos completos);
  fregadero dibujado por código; sonidos sintetizados; fuente temporal.
- FALTA (no hay sprites en las referencias): animaciones de despertar, saltar, agacharse, interactuar y recoger de Kenneth.
  Ahora el salto usa los cuadros de correr y agacharse comprime el sprite. Carta, teléfono y baño/almacén/patio quedan pendientes.

## Cambiar cosas sin tocar el código
- Diálogos: `Dialogues/dialogues.js` (copia en `.json`).
- Fuente propia: copia el TTF a `Assets/Fonts/`, activa `@font-face` en `index.html` y cambia `CONFIG.font` en `Config/config.js`.
- Volúmenes, velocidades, duración del jumpscare: `Config/config.js`.
- Para sustituir un fondo, reemplaza el PNG en `Assets/Environments/` conservando el nombre.
