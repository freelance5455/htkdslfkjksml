<?php
// Central branding + platform settings (easy to change before launch).
return [
    'brand' => [
        'name' => env('APP_NAME', 'AmlakPro'),
        'colors' => ['navy' => '#0B1F3A', 'emerald' => '#0E9F6E', 'gold' => '#C9A24B', 'bg' => '#FFFFFF'],
    ],
    'locales' => ['prs' => 'دری', 'ps' => 'پښتو', 'en' => 'English'],
    'default_locale' => 'prs',
    'self_register_roles' => ['user', 'owner', 'agent', 'agency', 'developer'], // never 'admin'
    'otp' => ['ttl_minutes' => 5, 'max_attempts' => 5, 'length' => 6],
    'support' => ['phone' => env('SUPPORT_PHONE'), 'email' => env('SUPPORT_EMAIL')],
];
