# Stage 2 setup (backend)

These are Stage 2 files only. They are NOT a complete Laravel app: drop them into a fresh project.

    composer create-project laravel/laravel backend && cd backend
    composer require laravel/sanctum
    php artisan install:api            # Laravel 11+: publishes routes/api.php + Sanctum migration
    # copy this folder's app/, config/, database/, routes/api.php, tests/ over the project
    cp .env.example .env && php artisan key:generate   # fill DB_* in .env
    php artisan migrate && php artisan db:seed --class=RoleSeeder
    php artisan test --filter=AuthTest

Bind the SMS gateway in AppServiceProvider::register():
    $this->app->bind(\App\Services\Sms\SmsGateway::class, \App\Services\Sms\NullSmsGateway::class);
(replace with a real provider class once the owner chooses one).
