<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Role;
use App\Models\User;
use App\Services\Otp\OtpService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class AuthController extends Controller
{
    public function __construct(private OtpService $otp) {}

    /** Normalise to E.164: "0700123456" or "93700123456" -> "+93700123456". */
    private function normalizePhone(?string $raw): string
    {
        $d = preg_replace('/\D+/', '', (string) $raw);
        if (str_starts_with($d, '00')) $d = substr($d, 2);
        if (str_starts_with($d, '0')) $d = '93' . substr($d, 1);   // default country: Afghanistan
        return '+' . $d;
    }

    private function prepare(Request $r): void
    {
        $r->merge(['phone' => $this->normalizePhone($r->input('phone'))]);
    }

    public function register(Request $r): JsonResponse
    {
        $this->prepare($r);
        $data = $r->validate([
            'phone' => ['required', 'regex:/^\+[1-9]\d{7,14}$/', 'unique:users,phone'],
            'name' => ['required', 'string', 'max:100'],
            'password' => ['required', 'string', 'min:8', 'max:72'],
            'role' => ['sometimes', Rule::in(config('amlakpro.self_register_roles'))],
            'preferred_locale' => ['sometimes', Rule::in(array_keys(config('amlakpro.locales')))],
        ]);

        $user = DB::transaction(function () use ($data) {
            $user = User::create([
                'phone' => $data['phone'],
                'name' => $data['name'],
                'password' => $data['password'],
                'preferred_locale' => $data['preferred_locale'] ?? config('amlakpro.default_locale'),
            ]);
            $user->profile()->create([]);
            // Role comes from an allow-list; 'admin' can never be self-assigned.
            $role = Role::where('key', $data['role'] ?? 'user')->first();
            if ($role) $user->roles()->attach($role->id);
            return $user;
        });

        $sent = $this->otp->issue($user, 'verify_phone');

        return response()->json([
            'message' => 'registered',
            'otp_available' => $this->otp->available(),
            'otp_sent' => $sent,
            'token' => $user->createToken('mobile')->plainTextToken,
            'user' => $this->present($user),
        ], 201);
    }

    public function verifyPhone(Request $r): JsonResponse
    {
        $r->validate(['code' => ['required', 'digits:' . config('amlakpro.otp.length')]]);
        $user = $r->user();
        if (! $this->otp->verify($user, 'verify_phone', $r->input('code'))) {
            return response()->json(['message' => 'invalid_or_expired_code'], 422);
        }
        $user->forceFill(['phone_verified_at' => now()])->save();
        return response()->json(['user' => $this->present($user->fresh())]);
    }

    public function resendOtp(Request $r): JsonResponse
    {
        if (! $this->otp->available()) {
            return response()->json(['message' => 'otp_unavailable'], 503);
        }
        $this->otp->issue($r->user(), 'verify_phone');
        return response()->json(['message' => 'otp_sent']);
    }

    public function login(Request $r): JsonResponse
    {
        $this->prepare($r);
        $r->validate(['phone' => ['required', 'string'], 'password' => ['required', 'string']]);
        $user = User::where('phone', $r->input('phone'))->first();

        // Same response for unknown phone and wrong password (no account enumeration).
        if (! $user || ! Hash::check($r->input('password'), $user->password)) {
            return response()->json(['message' => 'invalid_credentials'], 422);
        }
        if (! $user->isActive()) {
            return response()->json(['message' => 'account_not_active'], 403);
        }
        $user->forceFill(['last_login_at' => now()])->save();

        return response()->json(['token' => $user->createToken('mobile')->plainTextToken, 'user' => $this->present($user)]);
    }

    public function logout(Request $r): JsonResponse
    {
        $r->user()->currentAccessToken()->delete();
        return response()->json(['message' => 'logged_out']);
    }

    public function me(Request $r): JsonResponse
    {
        return response()->json(['user' => $this->present($r->user())]);
    }

    public function forgotPassword(Request $r): JsonResponse
    {
        $this->prepare($r);
        $r->validate(['phone' => ['required', 'string']]);
        if (! $this->otp->available()) {
            return response()->json(['message' => 'otp_unavailable'], 503);
        }
        $user = User::where('phone', $r->input('phone'))->first();
        if ($user && $user->isActive()) $this->otp->issue($user, 'reset_password');
        // Identical answer whether or not the phone exists.
        return response()->json(['message' => 'if_account_exists_code_sent']);
    }

    public function resetPassword(Request $r): JsonResponse
    {
        $this->prepare($r);
        $r->validate([
            'phone' => ['required', 'string'],
            'code' => ['required', 'digits:' . config('amlakpro.otp.length')],
            'password' => ['required', 'string', 'min:8', 'max:72'],
        ]);
        $user = User::where('phone', $r->input('phone'))->first();
        if (! $user || ! $this->otp->verify($user, 'reset_password', $r->input('code'))) {
            return response()->json(['message' => 'invalid_or_expired_code'], 422);
        }
        $user->forceFill(['password' => $r->input('password')])->save();
        $user->tokens()->delete();   // sign out all other sessions
        return response()->json(['message' => 'password_reset']);
    }

    public function requestDeletion(Request $r): JsonResponse
    {
        $r->user()->forceFill(['status' => 'pending_deletion', 'deletion_requested_at' => now()])->save();
        $r->user()->tokens()->delete();
        return response()->json(['message' => 'deletion_requested']);
    }

    private function present(User $u): array
    {
        return [
            'id' => $u->id,
            'name' => $u->name,
            'phone' => $u->phone,
            'phone_verified' => $u->phone_verified_at !== null,
            'locale' => $u->preferred_locale,
            'roles' => $u->roles()->pluck('key'),
        ];
    }
}
