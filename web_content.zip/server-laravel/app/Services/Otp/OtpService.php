<?php
namespace App\Services\Otp;

use App\Models\OtpCode;
use App\Models\User;
use App\Services\Sms\SmsGateway;
use Illuminate\Support\Facades\Hash;

class OtpService
{
    public function __construct(private SmsGateway $sms) {}

    public function available(): bool
    {
        return $this->sms->isConfigured();
    }

    /** Returns false (and sends nothing) when no SMS provider is configured or sending fails. */
    public function issue(User $user, string $purpose): bool
    {
        if (! $this->available()) {
            return false;
        }
        $len = config('amlakpro.otp.length');
        $code = str_pad((string) random_int(0, 10 ** $len - 1), $len, '0', STR_PAD_LEFT);

        OtpCode::where('user_id', $user->id)->where('purpose', $purpose)->whereNull('used_at')->delete();
        OtpCode::create([
            'user_id' => $user->id,
            'purpose' => $purpose,
            'code_hash' => Hash::make($code),
            'expires_at' => now()->addMinutes(config('amlakpro.otp.ttl_minutes')),
        ]);

        return $this->sms->send($user->phone, "AmlakPro: {$code}");
    }

    public function verify(User $user, string $purpose, string $code): bool
    {
        $otp = OtpCode::where('user_id', $user->id)->where('purpose', $purpose)
            ->whereNull('used_at')->where('expires_at', '>', now())
            ->latest('id')->first();

        if (! $otp || $otp->attempts >= config('amlakpro.otp.max_attempts')) {
            return false;
        }
        if (! Hash::check($code, $otp->code_hash)) {
            $otp->increment('attempts');
            return false;
        }
        $otp->update(['used_at' => now()]);
        return true;
    }
}
