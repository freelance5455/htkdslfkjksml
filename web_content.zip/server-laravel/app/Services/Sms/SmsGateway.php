<?php
namespace App\Services\Sms;

interface SmsGateway
{
    /** False when no SMS provider is configured: OTP features are then reported as unavailable. */
    public function isConfigured(): bool;

    public function send(string $phone, string $message): bool;
}
