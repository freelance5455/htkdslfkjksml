<?php
namespace App\Services\Sms;

/** Default binding until the owner configures a real provider (SMS_DRIVER). Sends nothing. */
class NullSmsGateway implements SmsGateway
{
    public function isConfigured(): bool { return false; }
    public function send(string $phone, string $message): bool { return false; }
}
