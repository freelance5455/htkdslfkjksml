<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserProfile extends Model
{
    protected $fillable = ['user_id', 'avatar_path', 'city_id', 'show_phone_publicly', 'allow_search_alerts'];
    protected $casts = ['show_phone_publicly' => 'boolean', 'allow_search_alerts' => 'boolean'];
}
