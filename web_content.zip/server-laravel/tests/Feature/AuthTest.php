<?php
namespace Tests\Feature;

use App\Models\User;
use App\Services\Sms\SmsGateway;
use Database\Seeders\RoleSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class FakeSms implements SmsGateway
{
    public array $sent = [];
    public function isConfigured(): bool { return true; }
    public function send(string $phone, string $message): bool { $this->sent[] = [$phone, $message]; return true; }
    public function lastCode(): string { preg_match('/(\d{6})/', end($this->sent)[1], $m); return $m[1]; }
}

class AuthTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RoleSeeder::class);
    }

    private function fakeSms(): FakeSms
    {
        $fake = new FakeSms();
        $this->app->instance(SmsGateway::class, $fake);
        return $fake;
    }

    private function payload(array $o = []): array
    {
        return array_merge(['phone' => '0700000001', 'name' => 'Test User', 'password' => 'secret-pass-1'], $o);
    }

    public function test_register_normalizes_phone_and_hashes_password(): void
    {
        $this->postJson('/api/v1/auth/register', $this->payload())->assertCreated()->assertJsonPath('user.phone', '+93700000001');
        $u = User::first();
        $this->assertNotSame('secret-pass-1', $u->password);
    }

    public function test_cannot_self_register_as_admin(): void
    {
        $this->postJson('/api/v1/auth/register', $this->payload(['role' => 'admin']))->assertStatus(422);
        $this->assertSame(0, User::count());
    }

    public function test_without_sms_provider_otp_is_reported_unavailable(): void
    {
        $this->postJson('/api/v1/auth/register', $this->payload())
            ->assertCreated()->assertJsonPath('otp_available', false)->assertJsonPath('otp_sent', false)
            ->assertJsonPath('user.phone_verified', false);
    }

    public function test_phone_verification_with_correct_and_wrong_code(): void
    {
        $sms = $this->fakeSms();
        $token = $this->postJson('/api/v1/auth/register', $this->payload())->json('token');
        $h = ['Authorization' => "Bearer $token"];

        $this->postJson('/api/v1/auth/verify-phone', ['code' => '000000'], $h)->assertStatus(422);
        $code = $sms->lastCode() === '000000' ? '111111' : $sms->lastCode();
        $this->postJson('/api/v1/auth/verify-phone', ['code' => $code], $h)->assertOk()->assertJsonPath('user.phone_verified', true);
    }

    public function test_login_failures_are_indistinguishable_and_suspended_blocked(): void
    {
        $this->postJson('/api/v1/auth/register', $this->payload());
        $a = $this->postJson('/api/v1/auth/login', ['phone' => '0700000001', 'password' => 'wrong-pass-1']);
        $b = $this->postJson('/api/v1/auth/login', ['phone' => '0799999999', 'password' => 'wrong-pass-1']);
        $a->assertStatus(422); $b->assertStatus(422);
        $this->assertSame($a->json(), $b->json());

        User::first()->forceFill(['status' => 'suspended'])->save();
        $this->postJson('/api/v1/auth/login', ['phone' => '0700000001', 'password' => 'secret-pass-1'])->assertStatus(403);
    }

    public function test_me_requires_auth_and_logout_revokes_token(): void
    {
        $this->getJson('/api/v1/auth/me')->assertUnauthorized();
        $token = $this->postJson('/api/v1/auth/register', $this->payload())->json('token');
        $this->getJson('/api/v1/auth/me', ['Authorization' => "Bearer $token"])->assertOk();
        $this->postJson('/api/v1/auth/logout', [], ['Authorization' => "Bearer $token"])->assertOk();
        $this->assertSame(0, \Laravel\Sanctum\PersonalAccessToken::count());
    }

    public function test_password_reset_flow(): void
    {
        $sms = $this->fakeSms();
        $this->postJson('/api/v1/auth/register', $this->payload());
        $this->postJson('/api/v1/auth/forgot-password', ['phone' => '0700000001'])->assertOk();
        $this->postJson('/api/v1/auth/reset-password', ['phone' => '0700000001', 'code' => $sms->lastCode(), 'password' => 'new-secret-22'])->assertOk();
        $this->postJson('/api/v1/auth/login', ['phone' => '0700000001', 'password' => 'new-secret-22'])->assertOk();
    }

    public function test_account_deletion_request_marks_user_and_revokes_tokens(): void
    {
        $token = $this->postJson('/api/v1/auth/register', $this->payload())->json('token');
        $this->postJson('/api/v1/account/delete-request', [], ['Authorization' => "Bearer $token"])->assertOk();
        $this->assertSame('pending_deletion', User::first()->status);
    }
}
