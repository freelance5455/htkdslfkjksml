<?php
namespace Database\Seeders;

use App\Models\Role;
use Illuminate\Database\Seeder;

class RoleSeeder extends Seeder
{
    public function run(): void
    {
        foreach (['user' => 'Regular user', 'owner' => 'Property owner', 'agent' => 'Real estate agent',
                  'agency' => 'Real estate agency', 'developer' => 'Property developer', 'admin' => 'Administrator'] as $k => $n) {
            Role::firstOrCreate(['key' => $k], ['name_en' => $n]);
        }
    }
}
