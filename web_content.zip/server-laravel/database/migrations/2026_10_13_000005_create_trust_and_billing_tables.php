<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('verification_requests', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->enum('type', ['identity', 'business']);
            $t->string('document_path');                  // private disk only, never public
            $t->enum('status', ['pending', 'approved', 'rejected'])->default('pending');
            $t->foreignId('reviewed_by')->nullable()->constrained('users')->nullOnDelete();
            $t->text('checks_performed')->nullable();     // what was checked
            $t->timestamp('reviewed_at')->nullable();     // when
            $t->text('reviewer_note')->nullable();
            $t->timestamps();
        });
        Schema::create('audit_logs', function (Blueprint $t) {
            $t->id();
            $t->foreignId('actor_id')->nullable()->constrained('users')->nullOnDelete();
            $t->string('action', 64);
            $t->string('subject_type', 64)->nullable();
            $t->unsignedBigInteger('subject_id')->nullable();
            $t->json('meta')->nullable();
            $t->string('ip', 45)->nullable();
            $t->timestamp('created_at')->useCurrent();
            $t->index(['subject_type', 'subject_id']);
        });
        Schema::create('plans', function (Blueprint $t) {
            $t->id();
            $t->string('key', 48)->unique();
            $t->string('name_en');
            $t->decimal('price', 12, 2)->default(0);
            $t->char('currency', 3)->default('AFN');
            $t->unsignedSmallInteger('duration_days')->nullable();
            $t->unsignedInteger('max_active_listings')->nullable();
            $t->boolean('is_active')->default(false);     // monetization off until owner enables
            $t->timestamps();
        });
        Schema::create('subscriptions', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('plan_id')->constrained();
            $t->enum('status', ['pending_payment', 'active', 'expired', 'cancelled'])->default('pending_payment');
            $t->timestamp('starts_at')->nullable();
            $t->timestamp('ends_at')->nullable();
            $t->timestamps();
        });
        Schema::create('payments', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('subscription_id')->nullable()->constrained()->nullOnDelete();
            $t->string('provider', 32);
            $t->string('provider_reference')->nullable()->unique();
            $t->decimal('amount', 12, 2);
            $t->char('currency', 3);
            // 'succeeded' may ONLY be set after server-side provider confirmation
            $t->enum('status', ['initiated', 'succeeded', 'failed', 'refunded'])->default('initiated');
            $t->timestamp('confirmed_at')->nullable();
            $t->timestamps();
        });
        Schema::create('featured_listings', function (Blueprint $t) {
            $t->id();
            $t->foreignId('property_id')->constrained()->cascadeOnDelete();
            $t->foreignId('payment_id')->nullable()->constrained()->nullOnDelete();
            $t->enum('kind', ['featured', 'sponsored']);
            $t->timestamp('starts_at'); $t->timestamp('ends_at');
            $t->timestamps();
            $t->index(['ends_at', 'kind']);
        });
        Schema::create('app_notifications', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('type', 48);   // new_message, listing_approved, listing_rejected, search_match, listing_expiring
            $t->json('data')->nullable();
            $t->timestamp('read_at')->nullable();
            $t->timestamps();
            $t->index(['user_id', 'read_at']);
        });
    }
    public function down(): void
    {
        foreach (['app_notifications', 'featured_listings', 'payments', 'subscriptions', 'plans', 'audit_logs', 'verification_requests'] as $t) Schema::dropIfExists($t);
    }
};
