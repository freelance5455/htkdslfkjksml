<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('users', function (Blueprint $t) {
            $t->id();
            $t->string('phone', 20)->unique();          // E.164
            $t->string('name');
            $t->string('email')->nullable()->unique();
            $t->string('password');                       // hashed
            $t->timestamp('phone_verified_at')->nullable();
            $t->enum('status', ['active', 'suspended', 'pending_deletion'])->default('active');
            $t->enum('preferred_locale', ['prs', 'ps', 'en'])->default('prs');
            $t->timestamp('deletion_requested_at')->nullable();
            $t->timestamp('last_login_at')->nullable();
            $t->timestamps();
            $t->softDeletes();
            $t->index('status');
        });
        Schema::create('roles', function (Blueprint $t) {
            $t->id();
            $t->string('key', 32)->unique();
            $t->string('name_en');
            $t->timestamps();
        });
        Schema::create('permissions', function (Blueprint $t) {
            $t->id();
            $t->string('key', 64)->unique();
            $t->timestamps();
        });
        Schema::create('permission_role', function (Blueprint $t) {
            $t->foreignId('permission_id')->constrained()->cascadeOnDelete();
            $t->foreignId('role_id')->constrained()->cascadeOnDelete();
            $t->primary(['permission_id', 'role_id']);
        });
        Schema::create('role_user', function (Blueprint $t) {
            $t->foreignId('role_id')->constrained()->cascadeOnDelete();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->primary(['role_id', 'user_id']);
        });
        Schema::create('user_profiles', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->unique()->constrained()->cascadeOnDelete();
            $t->string('avatar_path')->nullable();
            $t->foreignId('city_id')->nullable()->constrained()->nullOnDelete();
            $t->boolean('show_phone_publicly')->default(false);
            $t->boolean('allow_search_alerts')->default(true);
            $t->timestamps();
        });
        Schema::create('agencies', function (Blueprint $t) {
            $t->id();
            $t->foreignId('owner_user_id')->constrained('users')->cascadeOnDelete();
            $t->string('name');
            $t->string('logo_path')->nullable();
            $t->string('contact_phone', 20)->nullable();
            $t->string('contact_email')->nullable();
            $t->string('office_address')->nullable();
            $t->foreignId('city_id')->nullable()->constrained()->nullOnDelete();
            $t->timestamps();
        });
        Schema::create('otp_codes', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->enum('purpose', ['verify_phone', 'reset_password']);
            $t->string('code_hash');                      // never store plain OTP
            $t->unsignedTinyInteger('attempts')->default(0);
            $t->timestamp('expires_at');
            $t->timestamp('used_at')->nullable();
            $t->timestamps();
            $t->index(['user_id', 'purpose']);
        });
    }
    public function down(): void
    {
        foreach (['otp_codes', 'agencies', 'user_profiles', 'role_user', 'permission_role', 'permissions', 'roles', 'users'] as $t) Schema::dropIfExists($t);
    }
};
