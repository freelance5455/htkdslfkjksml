<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('favorites', function (Blueprint $t) {
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('property_id')->constrained()->cascadeOnDelete();
            $t->timestamps();
            $t->primary(['user_id', 'property_id']);
        });
        Schema::create('saved_searches', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->string('name');
            $t->json('filters');
            $t->boolean('alerts_enabled')->default(false);
            $t->timestamps();
        });
        Schema::create('conversations', function (Blueprint $t) {
            $t->id();
            $t->foreignId('property_id')->nullable()->constrained()->nullOnDelete();
            $t->foreignId('buyer_id')->constrained('users')->cascadeOnDelete();
            $t->foreignId('seller_id')->constrained('users')->cascadeOnDelete();
            $t->timestamp('last_message_at')->nullable();
            $t->timestamps();
            $t->unique(['property_id', 'buyer_id', 'seller_id']);
        });
        Schema::create('messages', function (Blueprint $t) {
            $t->id();
            $t->foreignId('conversation_id')->constrained()->cascadeOnDelete();
            $t->foreignId('sender_id')->constrained('users')->cascadeOnDelete();
            $t->text('body');
            $t->timestamp('read_at')->nullable();
            $t->timestamps();
            $t->index(['conversation_id', 'created_at']);
        });
        Schema::create('viewing_requests', function (Blueprint $t) {
            $t->id();
            $t->foreignId('property_id')->constrained()->cascadeOnDelete();
            $t->foreignId('requester_id')->constrained('users')->cascadeOnDelete();
            $t->dateTime('preferred_at');
            $t->text('note')->nullable();
            $t->enum('status', ['pending', 'accepted', 'declined', 'cancelled'])->default('pending');
            $t->timestamps();
        });
        Schema::create('reviews', function (Blueprint $t) {
            $t->id();
            $t->foreignId('reviewer_id')->constrained('users')->cascadeOnDelete();
            $t->foreignId('reviewed_user_id')->constrained('users')->cascadeOnDelete();
            $t->unsignedTinyInteger('rating');
            $t->text('comment')->nullable();
            $t->enum('status', ['visible', 'hidden', 'flagged'])->default('visible');
            $t->timestamps();
            $t->unique(['reviewer_id', 'reviewed_user_id']);
        });
        Schema::create('reports', function (Blueprint $t) {
            $t->id();
            $t->foreignId('reporter_id')->constrained('users')->cascadeOnDelete();
            $t->foreignId('property_id')->nullable()->constrained()->cascadeOnDelete();
            $t->foreignId('reported_user_id')->nullable()->constrained('users')->cascadeOnDelete();
            $t->enum('reason', ['fraud', 'advance_payment_scam', 'duplicate', 'wrong_info', 'abuse', 'other']);
            $t->text('details')->nullable();
            $t->enum('status', ['open', 'investigating', 'resolved', 'dismissed'])->default('open');
            $t->timestamps();
        });
        Schema::create('blocks', function (Blueprint $t) {
            $t->foreignId('blocker_id')->constrained('users')->cascadeOnDelete();
            $t->foreignId('blocked_id')->constrained('users')->cascadeOnDelete();
            $t->timestamps();
            $t->primary(['blocker_id', 'blocked_id']);
        });
        // Only real recorded views; dashboards must never show invented numbers.
        Schema::create('property_views', function (Blueprint $t) {
            $t->id();
            $t->foreignId('property_id')->constrained()->cascadeOnDelete();
            $t->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $t->timestamp('viewed_at')->useCurrent();
            $t->index(['property_id', 'viewed_at']);
        });
    }
    public function down(): void
    {
        foreach (['property_views', 'blocks', 'reports', 'reviews', 'viewing_requests', 'messages', 'conversations', 'saved_searches', 'favorites'] as $t) Schema::dropIfExists($t);
    }
};
