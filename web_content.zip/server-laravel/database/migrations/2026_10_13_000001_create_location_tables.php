<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('countries', function (Blueprint $t) {
            $t->id();
            $t->char('iso2', 2)->unique();
            $t->string('name_prs'); $t->string('name_ps'); $t->string('name_en');
            $t->boolean('is_active')->default(true);
            $t->timestamps();
        });
        Schema::create('provinces', function (Blueprint $t) {
            $t->id();
            $t->foreignId('country_id')->constrained()->cascadeOnDelete();
            $t->string('name_prs'); $t->string('name_ps'); $t->string('name_en');
            $t->boolean('is_active')->default(true);
            $t->timestamps();
            $t->index(['country_id', 'is_active']);
        });
        Schema::create('cities', function (Blueprint $t) {
            $t->id();
            $t->foreignId('province_id')->constrained()->cascadeOnDelete();
            $t->string('name_prs'); $t->string('name_ps'); $t->string('name_en');
            $t->boolean('is_active')->default(true);
            $t->timestamps();
            $t->index(['province_id', 'is_active']);
        });
        Schema::create('neighborhoods', function (Blueprint $t) {
            $t->id();
            $t->foreignId('city_id')->constrained()->cascadeOnDelete();
            $t->string('name_prs'); $t->string('name_ps'); $t->string('name_en');
            $t->boolean('is_active')->default(true);
            $t->timestamps();
            $t->index(['city_id', 'is_active']);
        });
    }
    public function down(): void
    {
        foreach (['neighborhoods', 'cities', 'provinces', 'countries'] as $t) Schema::dropIfExists($t);
    }
};
