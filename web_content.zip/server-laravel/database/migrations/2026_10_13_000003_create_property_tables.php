<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('categories', function (Blueprint $t) {
            $t->id();
            $t->foreignId('parent_id')->nullable()->constrained('categories')->nullOnDelete();
            $t->string('key', 48)->unique();
            $t->enum('group', ['residential', 'commercial', 'land']);
            $t->string('name_prs'); $t->string('name_ps'); $t->string('name_en');
            $t->boolean('is_active')->default(true);
            $t->timestamps();
        });
        Schema::create('amenities', function (Blueprint $t) {
            $t->id();
            $t->string('key', 48)->unique();
            $t->string('name_prs'); $t->string('name_ps'); $t->string('name_en');
            $t->timestamps();
        });
        Schema::create('properties', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('agency_id')->nullable()->constrained()->nullOnDelete();
            $t->foreignId('category_id')->constrained();
            $t->string('title');
            $t->text('description');
            $t->foreignId('country_id')->constrained();
            $t->foreignId('province_id')->constrained();
            $t->foreignId('city_id')->constrained();
            $t->foreignId('neighborhood_id')->nullable()->constrained()->nullOnDelete();
            $t->string('exact_address')->nullable();
            $t->boolean('show_exact_address')->default(false);
            $t->decimal('latitude', 10, 7)->nullable();
            $t->decimal('longitude', 10, 7)->nullable();
            $t->decimal('area_sqm', 12, 2)->nullable();
            $t->unsignedTinyInteger('bedrooms')->nullable();
            $t->unsignedTinyInteger('bathrooms')->nullable();
            $t->smallInteger('floor_number')->nullable();
            $t->unsignedSmallInteger('total_floors')->nullable();
            $t->unsignedSmallInteger('year_built')->nullable();
            $t->enum('condition', ['new', 'used', 'under_construction'])->nullable();
            $t->boolean('is_furnished')->default(false);
            $t->boolean('is_commercial_use')->default(false);
            $t->enum('lister_type', ['owner', 'agent'])->default('owner');
            $t->string('authorization_info')->nullable();   // owner-declared; NOT proof of verification
            $t->enum('status', ['draft', 'pending_review', 'active', 'paused', 'rejected', 'sold', 'rented', 'unavailable', 'expired'])->default('draft');
            $t->text('review_note')->nullable();
            $t->timestamp('published_at')->nullable();
            $t->timestamp('expires_at')->nullable();
            $t->string('content_hash', 64)->nullable()->index();  // duplicate detection
            $t->timestamps();
            $t->softDeletes();
            $t->index(['status', 'published_at']);
            $t->index(['city_id', 'category_id', 'status']);
        });
        // Separate price rows: purchase / rent / gorawi are never one ambiguous field.
        Schema::create('listing_prices', function (Blueprint $t) {
            $t->id();
            $t->foreignId('property_id')->constrained()->cascadeOnDelete();
            $t->enum('transaction_type', ['sale', 'rent', 'gorawi', 'rent_with_deposit', 'commercial_lease']);
            $t->decimal('amount', 16, 2);
            $t->char('currency', 3);
            $t->enum('period', ['one_time', 'monthly', 'yearly'])->default('one_time');
            $t->timestamps();
            $t->unique(['property_id', 'transaction_type']);
            $t->index(['transaction_type', 'currency', 'amount']);
        });
        Schema::create('gorawi_terms', function (Blueprint $t) {
            $t->id();
            $t->foreignId('property_id')->unique()->constrained()->cascadeOnDelete();
            $t->decimal('total_gorawi_amount', 16, 2);
            $t->char('currency', 3);
            $t->decimal('monthly_rent', 16, 2)->nullable();
            $t->unsignedSmallInteger('duration_months')->nullable();
            $t->text('refund_settlement_terms')->nullable();
            $t->text('additional_conditions')->nullable();
            $t->text('required_documents')->nullable();
            $t->boolean('disclaimer_accepted')->default(false);
            $t->timestamp('disclaimer_accepted_at')->nullable();
            $t->timestamps();
        });
        Schema::create('property_images', function (Blueprint $t) {
            $t->id();
            $t->foreignId('property_id')->constrained()->cascadeOnDelete();
            $t->string('path');
            $t->string('thumb_path')->nullable();
            $t->unsignedSmallInteger('sort_order')->default(0);
            $t->boolean('is_cover')->default(false);
            $t->timestamps();
            $t->index(['property_id', 'sort_order']);
        });
        Schema::create('property_amenity', function (Blueprint $t) {
            $t->foreignId('property_id')->constrained()->cascadeOnDelete();
            $t->foreignId('amenity_id')->constrained()->cascadeOnDelete();
            $t->primary(['property_id', 'amenity_id']);
        });
    }
    public function down(): void
    {
        foreach (['property_amenity', 'property_images', 'gorawi_terms', 'listing_prices', 'properties', 'amenities', 'categories'] as $t) Schema::dropIfExists($t);
    }
};
