/* Single-page download flow: interstitial ad -> download unlocked */
function omniDownloadStep() {
  var id = qsId(), el = document.getElementById("content");
  var back = document.getElementById("backGame");
  if (back) back.href = "game.html?id=" + encodeURIComponent(id);

  fetchGame(id).then(function (g) {
    var icon = gameIcon(g);
    el.innerHTML =
      (icon ? '<img src="' + icon + '" alt="' + gameTitle(g) + ' icon" style="width:96px;height:96px;object-fit:cover" />' : '') +
      '<h1 style="font-size:18px">' + gameTitle(g) + '</h1>' +
      '<p class="meta">' + (g.version ? 'v' + String(g.version).replace(/^v/, "") + ' · ' : '') + (g.category || '') + '</p>' +
      '<p id="timer">Please wait <b>5</b> seconds…</p>' +
      '<div id="adcount">Download နှိပ်လိုက်ရင် ကြော်ငြာတစ်ခုပြပြီး Download ရပါမယ်</div>' +
      '<p id="linkBox"></p>' +
      '<div id="adnote"><b>သတိပေးချက်:</b> ကြော်ငြာ website ထဲ ရောက်သွားရင် <b>Back</b> နှိပ်ပြီး ပြန်ထွက်ကာ ဆက်ဒေါင်းလို့ရပါတယ်။<br/>If an ad page opens, just press Back and continue downloading.</div>' +
      '<p><button type="button" class="share" data-share="game.html?id=' + encodeURIComponent(id) + '" data-share-title="' + gameTitle(g) + '">Share this game</button></p>' +
      '<div class="foot">' + omniSocialHTML() + '</div>';

    var n = 5;
    var iv = setInterval(function () {
      n--;
      var b = document.querySelector("#timer b");
      if (n > 0) { if (b) b.textContent = n; return; }
      clearInterval(iv);
      document.getElementById("timer").textContent = "Ready — ကြော်ငြာကြည့်ပြီး Download လုပ်ပါ။";
      showButton(g);
    }, 1000);
  }).catch(function () {
    el.innerHTML = '<p class="err">Game not found.</p><p><a href="index.html">Back to home</a></p>';
  });

  function showButton(g) {
    var busy = false;
    var box = document.getElementById("linkBox");
    box.innerHTML = '<button type="button" id="dlbtn" class="dlbtn"><b>⬇ Download</b></button>';

    document.getElementById("dlbtn").addEventListener("click", function () {
      if (busy) return;
      busy = true;
      try { if (window.OmniAclib) window.OmniAclib.interstitial(); } catch (e) {}
      var unlock = function () {
        busy = false;
        var url = g.direct_download_link || g.download_link || g.apk_url || "#";
        incrementDownload(id);
        box.innerHTML = '<div id="adcount">Unlocked — Download link အောက်မှာ ရပါပြီ။</div>' +
          '<p><a id="dl" class="dlbtn" href="' + url + '" rel="nofollow">Download ' + gameTitle(g) + ' APK</a></p>';
        setTimeout(function () { try { location.href = url; } catch (e) {} }, 400);
      };
      if (window.OmniAds && window.OmniAds.serveAd) window.OmniAds.serveAd(unlock);
      else unlock();
    });
  }
}
