require('dotenv').config();
const express=require('express');
const cors=require('cors');
const path=require('path');
const Database=require('better-sqlite3');
const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');

const app=express();
app.disable('x-powered-by');
app.use(cors({origin:true,credentials:false}));
app.use(express.json({limit:'100kb'}));

const PORT=Number(process.env.PORT||3000);
const SECRET=process.env.JWT_SECRET;
const OWNER_PHONE=(process.env.OWNER_PHONE||'9229801440').replace(/\D/g,'');
const OWNER_EMAIL=(process.env.OWNER_EMAIL||'ranveerjaiswal282@gmail.com').trim().toLowerCase();
const OWNER_PASSWORD=process.env.OWNER_PASSWORD;
if(!SECRET||SECRET.length<32){console.error('JWT_SECRET must be set and at least 32 characters.');process.exit(1)}
if(!OWNER_PASSWORD||OWNER_PASSWORD.length<10){console.error('OWNER_PASSWORD must be set and at least 10 characters.');process.exit(1)}

const db=new Database(process.env.DB_FILE||path.join(__dirname,'grothe.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT UNIQUE,
 phone TEXT UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user',
 wallet REAL NOT NULL DEFAULT 0,
 blocked INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS deposits(
 id TEXT PRIMARY KEY,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 amount REAL NOT NULL,
 utr TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'Pending',
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS orders(
 id TEXT PRIMARY KEY,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 service TEXT NOT NULL,
 link TEXT NOT NULL,
 quantity INTEGER NOT NULL,
 price REAL NOT NULL,
 status TEXT NOT NULL DEFAULT 'Pending',
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_orders_user_created ON orders(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_deposits_user_created ON deposits(user_id,created_at DESC);
`);

// Safe migration for databases created by the earlier package.
try{db.exec("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'")}catch(e){if(!String(e.message).includes('duplicate column'))throw e}
try{db.exec("ALTER TABLE users ADD COLUMN phone TEXT")}catch(e){if(!String(e.message).includes('duplicate column'))throw e}
try{db.prepare("UPDATE users SET phone=? WHERE lower(email)=? AND (phone IS NULL OR phone='')").run(OWNER_PHONE,OWNER_EMAIL)}catch(e){}

db.prepare("UPDATE users SET role='owner' WHERE lower(email)=?").run(OWNER_EMAIL);
const existingOwner=db.prepare('SELECT id FROM users WHERE lower(email)=? OR phone=?').get(OWNER_EMAIL,OWNER_PHONE);
if(!existingOwner){
  const hash=bcrypt.hashSync(OWNER_PASSWORD,12);
  db.prepare('INSERT INTO users(name,email,phone,password_hash,role,created_at) VALUES(?,?,?,?,?,?)').run('Owner',OWNER_EMAIL,OWNER_PHONE,hash,'owner',new Date().toISOString());
}

const SERVICES={
 'Instagram Followers':118.75,'Instagram Likes':71.25,'Instagram Views':47.50,
 'YouTube Views':118.75,'YouTube Subscribers':237.50,
 'Facebook Followers':178.60,'Facebook Likes':95.00,'Facebook Views':59.85,
 'TikTok Followers':130.00,'TikTok Likes':78.00,'TikTok Views':52.00,
 'Telegram Members':160.00,'WhatsApp Channel Followers':145.00,'Discord Members':175.00,
 'Spotify Followers':210.00,'Spotify Plays':55.00,'Snapchat Followers':190.00,
 'Twitter Followers':155.00,'LinkedIn Followers':225.00,'Pinterest Followers':185.00
};
const STATUSES=['Pending','Processing','Completed'];
const DEPOSIT_STATUSES=['Approved','Rejected'];
const uid=(p)=>p+Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const cleanEmail=e=>String(e||'').trim().toLowerCase();
const cleanPhone=p=>String(p||'').replace(/\D/g,'');
const publicUser=u=>({id:u.id,name:u.name,email:u.email||null,phone:u.phone||null,role:u.role,wallet:Number(u.wallet),blocked:!!u.blocked});

function auth(req,res,next){
  const raw=String(req.headers.authorization||'');
  const token=raw.startsWith('Bearer ')?raw.slice(7):'';
  if(!token)return res.status(401).json({error:'Login required'});
  try{req.user=jwt.verify(token,SECRET)}catch(e){return res.status(401).json({error:'Session expired. Login again.'})}
  const u=db.prepare('SELECT id,name,email,role,wallet,blocked FROM users WHERE id=?').get(req.user.id);
  if(!u)return res.status(401).json({error:'User not found'});
  if(u.blocked)return res.status(403).json({error:'Account blocked by owner'});
  req.dbUser=u; next();
}
function owner(req,res,next){if(req.dbUser?.role!=='owner')return res.status(403).json({error:'Owner access only'});next()}

app.get('/api/health',(req,res)=>res.json({ok:true,service:'Grothe Saller',database:'sqlite',time:new Date().toISOString()}));
app.get('/api/services',(req,res)=>res.json({services:Object.entries(SERVICES).map(([name,rate])=>({name,rate}))}));
app.post('/api/register',(req,res)=>{
  const name=String(req.body?.name||'').trim(); const phone=cleanPhone(req.body?.phone); const password=String(req.body?.password||'');
  if(name.length<2||name.length>80||!/^[6-9]\d{9}$/.test(phone)||password.length<6)return res.status(400).json({error:'Valid name, 10-digit mobile number and password (min 6) required'});
  if(phone===OWNER_PHONE)return res.status(403).json({error:'Owner number cannot be registered here'});
  try{
    const hash=bcrypt.hashSync(password,12); const internalEmail=phone+'@local.grothe'; const info=db.prepare('INSERT INTO users(name,email,phone,password_hash,role,created_at) VALUES(?,?,?,?,?,?)').run(name,internalEmail,phone,hash,'user',new Date().toISOString());
    const u=db.prepare('SELECT * FROM users WHERE id=?').get(info.lastInsertRowid); const token=jwt.sign({id:u.id,role:u.role},SECRET,{expiresIn:'7d'});
    res.status(201).json({token,user:publicUser(u),owner:false});
  }catch(e){res.status(400).json({error:String(e.message).includes('UNIQUE')?'Mobile number already registered':'Registration failed'})}
});
app.post('/api/login',(req,res)=>{
  const phone=cleanPhone(req.body?.phone); const email=cleanEmail(req.body?.email); const password=String(req.body?.password||'');
  const u=phone?db.prepare('SELECT * FROM users WHERE phone=?').get(phone):db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if(!u||!bcrypt.compareSync(password,u.password_hash))return res.status(401).json({error:'Invalid mobile number or password'});
  if(u.blocked)return res.status(403).json({error:'Account blocked by owner'});
  const token=jwt.sign({id:u.id,role:u.role},SECRET,{expiresIn:'7d'}); res.json({token,user:publicUser(u),owner:u.role==='owner'});
});
app.get('/api/me',auth,(req,res)=>res.json({user:publicUser(req.dbUser),owner:req.dbUser.role==='owner'}));
app.get('/api/orders',auth,(req,res)=>res.json({orders:db.prepare('SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC').all(req.dbUser.id)}));
app.post('/api/orders',auth,(req,res)=>{
  if(req.dbUser.role==='owner')return res.status(403).json({error:'Owner account cannot place customer orders'});
  const service=String(req.body?.service||''); const link=String(req.body?.link||'').trim(); const quantity=Number(req.body?.quantity);
  const rate=SERVICES[service];
  if(!rate||!link||!Number.isInteger(quantity)||quantity<10||quantity>1000000)return res.status(400).json({error:'Invalid service, link or quantity'});
  const price=Math.round((quantity/1000*rate)*100)/100; const id=uid('ORD'); const now=new Date().toISOString();
  try{
    const tx=db.transaction(()=>{
      const u=db.prepare('SELECT wallet FROM users WHERE id=?').get(req.dbUser.id);
      if(Number(u.wallet)<price)throw new Error(`Insufficient wallet balance. Required ₹${price.toFixed(2)}`);
      db.prepare('UPDATE users SET wallet=wallet-? WHERE id=?').run(price,req.dbUser.id);
      db.prepare('INSERT INTO orders(id,user_id,service,link,quantity,price,status,created_at) VALUES(?,?,?,?,?,?,?,?)').run(id,req.dbUser.id,service,link,quantity,price,'Pending',now);
    }); tx();
    res.status(201).json({order:db.prepare('SELECT * FROM orders WHERE id=?').get(id)});
  }catch(e){res.status(400).json({error:e.message||'Order failed'})}
});
app.get('/api/deposits',auth,(req,res)=>res.json({deposits:db.prepare('SELECT * FROM deposits WHERE user_id=? ORDER BY created_at DESC').all(req.dbUser.id)}));
app.post('/api/demo/wallet-credit',auth,(req,res)=>{
  if(req.dbUser.role==='owner')return res.status(403).json({error:'Owner account cannot use demo customer credit'});
  const amount=Number(req.body?.amount);
  if(amount!==100)return res.status(400).json({error:'Demo credit is fixed at ₹100'});
  db.prepare('UPDATE users SET wallet=wallet+? WHERE id=?').run(amount,req.dbUser.id);
  const u=db.prepare('SELECT wallet FROM users WHERE id=?').get(req.dbUser.id);
  res.json({demo:true,amount,wallet:Number(u.wallet)});
});
app.post('/api/deposits',auth,(req,res)=>{
  const amount=Number(req.body?.amount); const utr=String(req.body?.utr||'').trim();
  if(!Number.isFinite(amount)||amount<1||amount>100000000||utr.length<3||utr.length>120)return res.status(400).json({error:'Valid amount and UTR/reference required'});
  const id=uid('DEP'); const now=new Date().toISOString();
  db.prepare('INSERT INTO deposits(id,user_id,amount,utr,status,created_at) VALUES(?,?,?,?,?,?)').run(id,req.dbUser.id,Math.round(amount*100)/100,utr,'Pending',now);
  res.status(201).json({deposit:db.prepare('SELECT * FROM deposits WHERE id=?').get(id)});
});
app.get('/api/owner/overview',auth,owner,(req,res)=>{
  const users=db.prepare('SELECT id,name,email,phone,role,wallet,blocked,created_at FROM users ORDER BY id DESC').all();
  const orders=db.prepare('SELECT o.*,u.email,u.phone FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.created_at DESC').all();
  const deposits=db.prepare('SELECT d.*,u.email,u.phone FROM deposits d JOIN users u ON u.id=d.user_id ORDER BY d.created_at DESC').all();
  res.json({ownerEmail:OWNER_EMAIL,ownerPhone:OWNER_PHONE,summary:{users:users.length,orders:orders.length,deposits:deposits.length},users:users.map(publicUser),orders,deposits});
});
app.patch('/api/owner/orders/:id/status',auth,owner,(req,res)=>{
  const status=String(req.body?.status||''); if(!STATUSES.includes(status))return res.status(400).json({error:'Invalid order status'});
  const info=db.prepare('UPDATE orders SET status=? WHERE id=?').run(status,req.params.id); if(!info.changes)return res.status(404).json({error:'Order not found'}); res.json({ok:true});
});
app.patch('/api/owner/deposits/:id/status',auth,owner,(req,res)=>{
  const status=String(req.body?.status||''); if(!DEPOSIT_STATUSES.includes(status))return res.status(400).json({error:'Invalid deposit status'});
  const d=db.prepare('SELECT * FROM deposits WHERE id=?').get(req.params.id); if(!d)return res.status(404).json({error:'Deposit not found'});
  try{
    db.transaction(()=>{
      if(d.status==='Pending'&&status==='Approved')db.prepare('UPDATE users SET wallet=wallet+? WHERE id=?').run(d.amount,d.user_id);
      db.prepare('UPDATE deposits SET status=? WHERE id=?').run(status,d.id);
    })(); res.json({ok:true});
  }catch(e){res.status(400).json({error:'Deposit update failed'})}
});
app.patch('/api/owner/users/:id/block',auth,owner,(req,res)=>{
  const target=db.prepare('SELECT id,email,role FROM users WHERE id=?').get(req.params.id); if(!target)return res.status(404).json({error:'User not found'});
  if(target.role==='owner')return res.status(400).json({error:'Owner cannot be blocked'});
  db.prepare('UPDATE users SET blocked=? WHERE id=?').run(req.body?.blocked?1:0,target.id); res.json({ok:true});
});
app.use(express.static(path.join(__dirname,'public'),{extensions:['html']}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public/index.html')));
const server=app.listen(PORT,()=>console.log(`Grothe Saller running on http://localhost:${PORT}`));
process.on('SIGINT',()=>{server.close(()=>{db.close();process.exit(0)})});
