# Grothe Saller — Full Backend + Database

This package uses a real server-side SQLite database. Accounts, password hashes, wallets, deposits, orders, order status, and owner controls live on the server. The browser is only the UI.

## First run
1. Install Node.js 18+ (Node 20 LTS recommended).
2. Copy `.env.example` to `.env`.
3. Set a strong `JWT_SECRET` (32+ characters) and a strong `OWNER_PASSWORD` (10+ characters).
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

The owner email defaults to `ranveerjaiswal282@gmail.com`. The owner password is **not hard-coded**; it comes from `OWNER_PASSWORD`.

## Database
The database is `grothe.db` (SQLite) and is created automatically. WAL mode and indexes are enabled. Never put the `.db` file in a public web folder.

## Wallet/deposits
A user creates a Pending deposit with a UTR/reference. The owner approves it; only then does the server transaction add the amount to the wallet. Orders deduct wallet balance server-side.

**Important:** this is not a payment-gateway verifier. A real UPI/payment gateway must be integrated before treating a payment as automatically verified. Do not trust a screenshot or client-side “paid” flag.

## Owner controls
The owner can see user email/name/wallet, block/unblock users, see each order and its link, change order status between Pending/Processing/Completed, and approve/reject deposits. Passwords are never exposed.

## Production
Use HTTPS, a strong secret, backups, restricted database access, and a persistent server/volume. If deploying to a serverless platform such as Vercel, do not rely on a local SQLite file for durable multi-user production data; use a managed database such as Postgres.
