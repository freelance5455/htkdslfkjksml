# Grothe Saller — Full-stack package

This package is a real server-backed web app: authentication, wallets, deposits, orders and owner controls are stored server-side in SQLite. The HTML file by itself is only the frontend; run the Node server to use the real features.

## Requirements
- Node.js 18+
- npm

## Run locally
1. Copy `.env.example` to `.env`.
2. Set a strong `JWT_SECRET` (32+ random characters).
3. Set `OWNER_PASSWORD` to the password you want for the owner account. Do not put it in the HTML.
4. Keep `OWNER_PHONE=9229801440` unless you want to change the owner number.
5. Run `npm install`.
6. Run `npm start`.
7. Open `http://localhost:3000`.

## Owner
- Owner mobile: `9229801440`
- Owner login password: the value you set in `.env` as `OWNER_PASSWORD`.
- Owner Advanced is protected by the server role, not by a frontend-only flag.

## Back button
The dashboard includes a visible Back button, a mobile floating Back button, and browser/device history support using the History API.

## Data
The server creates `grothe.db` automatically. Passwords are stored as bcrypt hashes. Wallet changes and deposit approvals are performed server-side.

## Wallet instant credit (demo only)
- The **Instant Wallet Credit** button adds a fixed ₹100 test credit to the signed-in user account.
- It is explicitly marked DEMO ONLY and is not a payment, UPI verification, withdrawal, or real money credit.
- All normal deposit requests remain server-side and require owner/payment verification before wallet approval.

## Deposits
The deposit screen accepts an amount and UTR/reference. A deposit remains Pending until the owner approves it. This package does not pretend that a QR scan is automatically verified. For automatic payment confirmation, connect a real payment gateway and verify webhooks server-side.

## Services
Orders are recorded server-side and can be controlled by the owner. Actual fulfillment/delivery of any social-media service must be handled through a legitimate provider/API and must comply with the relevant platform's rules; this package does not include bots, fake accounts, or automated engagement manipulation.
