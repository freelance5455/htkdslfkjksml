# Keep WebView JS bridge safe
-keepattributes *Annotation*
