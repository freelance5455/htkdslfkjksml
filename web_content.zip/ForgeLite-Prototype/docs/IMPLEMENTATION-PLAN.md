# ZYRUU APK MAKER implementation plan

## Phase 1 — Project configuration prototype (included)
- Dark, responsive UI.
- ZIP validation with limits and traversal checks.
- App name/package ID validation.
- Select requested permissions.
- Select icon file (metadata only).
- Save project metadata locally and export JSON.
- Honest build status: NOT_BUILT.

## Phase 2 — Real project import
- Parse ZIP entries with a maintained ZIP library.
- Stream extraction to app-private storage.
- Enforce entry count, total expansion and per-file limits during extraction.
- Reject symlinks, duplicate/conflicting paths, path traversal and unsupported features.
- Persist imported project files, not only metadata.

## Phase 3 — Android project generation
- Generate manifest and resource files from validated configuration.
- Create launcher icon densities from uploaded icon.
- Explain dangerous permissions and require explicit confirmation.
- Set package ID, app label, min/target SDK intentionally.

## Phase 4 — Build engine research
- Evaluate whether a supported ARM64 Android/Termux toolchain can run locally.
- Verify compatible JDK, Gradle, Android Gradle Plugin, SDK platform and ARM64 AAPT2.
- Build a minimal sample first; then compile generated projects.
- Never use an x86-64 AAPT2 binary on ARM64 Android.
- Keep build output marked as not built until all tasks complete.

## Phase 5 — APK output
- Align APK, sign with a generated or user-provided key.
- Keep private keys in app-private storage; never upload them.
- Verify signature and APK package metadata before offering installation.
- Show build logs, errors, output size and output path.

## Security and privacy
- No ads, trackers or telemetry.
- ZIP validation must be followed by safe extraction limits; validation alone is not extraction safety.
- Treat uploaded projects as untrusted code.
- Warn users that building and installing unknown APKs can be risky.
