# ZYRUU APK MAKER prototype 0.1

An original, ad-free UI prototype for managing Android app project configuration from a phone.

## Implemented
- Dark mobile-friendly interface.
- ZIP input selection and central-directory validation.
- Rejects absolute paths, `..` traversal, encrypted archives, unsupported compression, malformed local headers, suspicious compression ratios, too many entries and excessive expanded size.
- Requires `index.html` or `www/index.html`.
- App display name and package ID validation.
- Icon file selection/type/size checks (metadata only; icon image is not persisted yet).
- Permission selection.
- Save up to 30 configuration records in browser localStorage.
- Export configuration as JSON.
- No ads, analytics, tracking, or network requests in this prototype.

## Not implemented yet
- Actual extraction/import and persistent storage of ZIP contents.
- Native Android icon/manifest generation.
- Runtime permission integration.
- Android SDK/Gradle compilation, APK alignment and signing.
- Secure signing-key storage.

The app deliberately does not claim to build APKs. A compatible local Android toolchain is a separate engineering phase.

## Run as a web preview
Use a modern browser to open `www/index.html`, or run `npm install` then `npm run start`.

## Capacitor Android wrapper
On a compatible computer or build environment:
1. `npm install`
2. `npx cap add android`
3. `npx cap sync android`
4. Open/build the Android project with a compatible Android SDK.

Building the wrapper does not make the APK compiler feature work; the compiler engine is not included.

## Phone-only next steps
The first phase is a UI/configuration prototype. For an all-on-phone installable app, the next step is to create a Capacitor Android wrapper using a compatible build environment once, then investigate a local ARM64 build toolchain for the actual APK compilation engine.
