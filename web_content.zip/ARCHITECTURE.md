# TwinPane — Ultimate File Manager (mimari + yol haritası)

Kotlin · Jetpack Compose (Material 3) · MVI · min SDK 24 / target 35 · Room · DataStore · WorkManager

## 1. Özgün farklar (MT Manager'da olmayanlar)
1. **Workspace'ler**: iki panenin yol/sıralama/seçim durumunu isimli olarak kaydet, tek dokunuşla geri yükle.
2. **Pre-flight özeti**: kopyalamadan önce "3 üzerine yazılır, 5 yeni, 1 atlanır" önizlemesi ve klasör diff'i.
3. **Undo Journal**: sadece çöp kutusu değil; taşıma, yeniden adlandırma, toplu regex rename dahil her işlem Room'da günlüklenir, tek dokunuşla geri alınır.
4. **Tepsi (Tray)**: farklı klasörlerden dosyaları tepsiye topla, sonra tek seferde bırak.
5. **Pane Link**: iki panenin gezinmesini kilitle (karşılaştırmalı klasör gezintisi).

## 2. Katmanlar
```
ui/        Compose ekranlar + UiIntent/UiState/UiEffect (MVI)
domain/    use-case'ler (Faz 1+): RenameBatch, Checksum, Search, Archive...
core/fs/   VFS: FileProvider arayüzü + sağlayıcılar + TransferEngine
data/      Room (yer imi, geçmiş, undo journal), DataStore (ayarlar)
work/      WorkManager + foreground service (uzun işler)
```
**Anahtar fikir:** her depolama türü `FileProvider` uygular (local, root, SAF, archive, sftp, smb, webdav, ftp).
UI ve TransferEngine hangisiyle konuştuğunu bilmez → "arşivi klasör gibi aç", "SFTP'den yerel'e direkt kopyala"
ve "panel arası paste'siz aktarım" aynı kodla çalışır. Yol şeması: `/...` yerel, `root://`, `saf://`,
`archive://<kaynak>!/<iç yol>`, `sftp://host/...`.

## 3. Ekran haritası
- **DualPaneScreen** (ana): iki pane + aksiyon rayı. Geniş ekran (≥600dp, tablet/katlanabilir/yatay): yan yana, dikey ray.
  Telefon dikey: üst-alt, yatay ray. Aktif pane vurgulu çerçeveli; her pane'in kendi yol çubuğu, geri/ileri/üst, geçmişi, filtresi, sıralaması var.
- Aksiyon rayı: karşıya kopyala · karşıya taşı · eşitle · tümünü seç · ters seç · gizli · sil (+ Faz 1'de yeniden adlandır, yeni, daha fazla).
- **PropertiesSheet**, **SearchScreen**, **BookmarksDrawer**, **TrashScreen**, **TaskManagerSheet**,
  **TextEditorScreen**, **HexEditorScreen**, **DiffScreen**, **ArchiveBrowser** (aynı DualPane, farklı provider),
  **ApkToolsScreen**, **MediaViewer** (resim/video/müzik/PDF/font/SQLite), **TerminalScreen**,
  **RemoteConnectionsScreen**, **HttpServerScreen**, **SettingsScreen**.

## 4. Ayarlar ve tema
- `ThemeMode {SYSTEM, LIGHT, DARK}` + `dynamicColor` (Android 12+ Material You, altında özel açık/koyu şema) → DataStore.
- Tema, uygulama içinden sistemden bağımsız değiştirilebilir; durum/gezinme çubuğu ikonları da buna göre ayarlanır.
- Faz 1 ayar grupları: Görünüm (tema, vurgu rengi, ikon seti, liste/ızgara, boyut birimi, tarih formatı) · Dosyalar (gizli, sıralama,
  çöp kutusu süresi) · Root/Shizuku · Ağ · Editör (yazı tipi, sekme, kelime kaydırma) · Dil (TR/EN/sistem) · Hakkında.

## 5. Kritik sınıflar
| Sınıf | Sorumluluk |
|---|---|
| `FileProvider` / `ProviderRegistry` | VFS sözleşmesi, yola göre sağlayıcı seçimi |
| `LocalFileProvider` | java.io.File, symlink güvenli silme, Os.symlink |
| `TransferEngine` | kopyala/taşı/sil, ilerleme akışı, çakışmada "ad (1)", kendi içine kopyalama koruması |
| `DualPaneViewModel` | MVI reducer: gezinme, geçmiş, seçim, filtre/sıralama, aktarım, eşitleme |
| `PaneState` / `DualPaneState` | değişmez UI durumu (`visible` önceden hesaplanır → büyük klasörde lag yok) |
| `SettingsRepository` | tema ve tercihler (DataStore) |
| `AppDatabase` / `BookmarkDao` | yer imleri; Faz 1: geçmiş, undo journal, workspace |
| (Faz 1) `BatchRenameUseCase` | regex/sayaç/tarih şablonlu toplu yeniden adlandırma, önizlemeli |
| (Faz 1) `ChecksumUseCase` | MD5/SHA1/SHA256 akışlı hesaplama |
| (Faz 1) `TrashManager` | silinenleri `.twinpane-trash/` altına metadata ile taşır, geri yükler |
| (Faz 1) `TransferService` + `TransferWorker` | uzun aktarımlar süreç ölümüne dayanıklı, bildirimli |
| (Faz 2) `ArchiveProvider` | zip/tar/gz/7z (okuma-yazma), rar (salt okuma), apk; şifreli zip (AES) |
| (Faz 4) `RootProvider` / `ShizukuProvider` | su ile ls/cp/chmod/chown/mount; Shizuku ile root'suz ayrıcalıklı erişim |
| (Faz 5) `SftpProvider`, `FtpProvider`, `SmbProvider`, `WebDavProvider` | uzak depolama |
| (Faz 5) `HttpServerService` | tarayıcıdan telefona erişim (NanoHTTPD), `NsdManager` ile ağ keşfi |
| (Faz 6) `ApkToolkit` | imzalama, hizalama, klonlama, AXML/ARSC/DEX düzenleme |

## 6. Faz planı
| Faz | İçerik |
|---|---|
| **0 (bu teslimat)** | Çift pencere, VFS, yerel sağlayıcı, paneller arası kopyala/taşı, eşitle, seçim (uzun bas/hepsi/ters/aynı tür), gizli göster/gizle, gerçek zamanlı filtre ve sıralama (VM'de hazır), açık/koyu/sistem/dinamik tema, izin akışı, Room+DataStore iskeleti, TR/EN |
| 1 | Yeniden adlandır, yeni dosya/klasör, toplu regex rename, symlink UI, özellikler + checksum, çöp kutusu, kaydırarak seç, filtre/arama UI, yer imleri, liste/ızgara, ayarlar ekranı, foreground service + WorkManager |
| 2 | Arşiv: klasör gibi gezinme, içinden ekle/sil/yeniden adlandır/çıkar, arşiv içi arama, şifreli arşiv |
| 3 | Metin editörü (Sora Editor, TextMate sözdizimi: Java/Kotlin/XML/JSON/Smali/Python/HTML/CSS/JS/MD), regex bul-değiştir, büyük dosya, Markdown önizleme, Hex editör (mmap), diff |
| 4 | Root algılama, /system /data /vendor, mount rw/ro, chmod/chown, Shizuku |
| 5 | SFTP/FTPS/FTP, SMB, WebDAV, HTTP sunucu, yerel ağ keşfi |
| 6 | APK araçları: klasör gibi gez, DEX (smali) düzenleme, ARSC/AXML, V1/V2/V3 imza, zipalign, klonlama, kaynak değiştirme, yüklü uygulamadan APK çıkarma |
| 7 | Resim/video/müzik/PDF/font/SQLite önizleme, terminal, script çalıştırıcı, color picker, kısayol (özel ikon), şifreleme (AES-GCM) |
| 8 | Tablet/katlanabilir cilası (WindowSizeClass), jest/haptik, baseline profile, test, performans |

## 7. Önerilen kütüphaneler (Faz 1+)
Sora Editor (editör) · commons-compress + zip4j + sevenzipjbinding (arşiv; RAR yazma açık kaynak olarak mümkün değil)
· libsu (root) · Shizuku-API · sshj (SFTP) · commons-net (FTP) · smbj (SMB) · sardine-android (WebDAV) · NanoHTTPD
· apksig + ARSCLib + smali/baksmali (dexlib2) (APK) · Media3 (video/müzik) · Coil (resim) · PdfRenderer.

## 8. Dürüst notlar
- MT Manager'ın tam kapsamı (özellikle DEX/ARSC düzenleme ve APK araçları) aylarca süren bir iştir; bu depo temeli ve doğru mimariyi verir.
- `MANAGE_EXTERNAL_STORAGE` Google Play'de özel izin beyanı ister; root/APK araçları Play politikalarına sürtünebilir (F-Droid / doğrudan APK dağıtımı düşünülmeli).
- Android 11+ cihazlarda `Android/data` ve `Android/obb` yalnızca root, Shizuku veya SAF ile erişilebilir (Faz 4).
