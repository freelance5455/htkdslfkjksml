# Architecture map (read this first)

Static site, no build step. All JS files are classic scripts that share one global scope and load in this order (see index.html). Edit only the file you need.

| File | Contains |
| --- | --- |
| config.js | Supabase URL and anon key |
| js/core.js | constants (STORES, GENRES, STATUSES), state variables, freshDraft/newTrack, esc, $, icon, toast |
| js/boot.js | setup screen, boot(), loadProfile, loadApp |
| js/data.js | loadReleases (also loads release_tasks), loadInvites, rollout task UI (taskRow, todoCard, rolloutCard) |
| js/audio.js | checkAudio (FLAC/MP3 rules), rnProblems (distributor title/artist rules) |
| js/extras.js | notifications, announcements, earnings, command palette, modal, bands, users |
| js/views.js | screens: renderAuth, nav, render, dashboard, builder, detail, settings, roster |
| js/profiles.js | Discover (search), public account pages, profile editor, audio player (uses RPCs search_profiles, get_profile, profile_discography) |
| js/release.js | createRelease, saveDraft, openDraft, submitRelease, setStatus, downloads, per-release loaders |
| js/discography.js | Discography page, per-release Stats card (release_stats), draft delete, Request update, progress steps, cover thumbnails, back-navigation state (backView). Loaded after profiles.js |
| js/captcha.js | Cloudflare Turnstile widget and token helpers (needs TURNSTILE_SITE_KEY in config.js) |
| js/events.js | bind() (all data-action click handlers), wizard next(), startup call |
| sw.js, manifest.webmanifest | installable app and cache. Bump the cache name in sw.js when files change |
| img/ | logo and app icons |

Rules of thumb: UI is template strings in views.js; every button uses data-action and is handled in events.js bind(); database calls live in release.js, data.js and extras.js.

Release flow: Draft -> Submitted -> (Changes Requested) -> Approved -> Sent to distributor -> Live. Artists create and edit drafts; label members review and move the later statuses.
