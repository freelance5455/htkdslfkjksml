# Arquitetura JARVIS

User
  |
  v
Voice / Text UI
  |
  v
Command Router
  +--> Local Commands
  +--> Plugin Manager
  +--> AI Gateway
  |
  v
Planner
  |
  +--> Permission Manager
  |
  +--> Android Action Layer
          +--> Intents
          +--> Accessibility
          +--> Notifications
          +--> Files
          +--> Other approved APIs
  |
  v
Memory

## Regra central
Nenhum módulo deve assumir que possui uma permissão. Ele verifica a capacidade e, se necessário, leva o usuário para a tela apropriada.

## Para IA generativa
O caminho recomendado é:
APK -> HTTPS -> seu backend -> provedor/modelo de IA.

Isso impede que uma chave privada seja extraída facilmente do APK.
