# BLOODLUST Android App

Ragdoll physics sandbox game packaged for Android.

## Quickest way to get an APK (no install required)

1. Zip the `www` folder (or the whole project).
2. Go to one of these free online converters:
   - https://www.htmltoapk.com/
   - https://html2app.dev/
   - https://www.htmltoapp.net/
3. Upload the ZIP (make sure `index.html` is at the root of the ZIP).
4. Set:
   - App name: BLOODLUST
   - Package name: com.bloodlust.game
   - Orientation: Landscape (recommended) or Sensor
   - Fullscreen: Yes
5. Download the signed APK and install it on your Android phone.

## Build locally with Capacitor (recommended for proper apps)

Requirements on your computer:
- Node.js 18+
- Android Studio + Android SDK
- Java 17 or 21

```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init BLOODLUST com.bloodlust.game --web-dir www
npx cap add android
npx cap sync
npx cap open android
```

Then in Android Studio: Build → Build Bundle(s) / APK(s) → Build APK(s).

## Controls
Same as the web version (touch controls appear automatically on mobile).
