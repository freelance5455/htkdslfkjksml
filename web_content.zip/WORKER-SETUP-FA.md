# درست کردن ۴ سرور ابری داخل برنامه (workers.dev) — بدون ساخت دوبارهٔ APK

مشکل قبلی: کد قدیمی داده را در سرویس عمومی textdb.dev می‌گذاشت (حجم محدود، بدون ادغام) و تیکت/کاربر گم می‌شد.
کد جدید: فایل `cloudflare-worker-sync-v2.js` (ذخیرهٔ دائمی در KV + ادغام + بکاپ ساعتی). آدرس‌ها همان می‌مانند.

## یک بار (۵ دقیقه)
1. Cloudflare Dashboard ← Storage & Databases ← KV ← **Create namespace** با نام `TRADYAR_KV`.
2. برای **هر چهار Worker** (square-wind-j49bc, shy-cherry-bfe3, blue-water-294c, calm-water-6d77):
   - Worker ← **Settings ← Bindings ← Add ← KV namespace** ← Variable name: `TRADYAR_KV` ← همان namespace (برای هر چهار تا یکی باشد، تا داده یکی بماند).
   - Worker ← **Edit code** ← کل کد را با `cloudflare-worker-sync-v2.js` جایگزین کن ← **Deploy**.
3. تست: باز کردن `https://square-wind-j49bc.lyakbrrytpyshh.workers.dev/health` باید `"ok":true` و `"kv":true` بدهد.
   اگر `kv:false` بود، مرحلهٔ Binding را دوباره بررسی کن.

## محدودیت پلن رایگان
KV رایگان روزی حدود ۱۰۰۰ نوشتن دارد. کد فقط وقتی داده واقعاً عوض شده بنویسد، می‌نویسد؛ ولی با کاربر زیاد، پلن Workers Paid (۵ دلار) یا سرور اختصاصی (`START-HERE-FA.md`) بهتر است.

## افزودن سرور از پنل مدیریت
پنل مدیریت ← سرورها ← آدرس + (توکن اگر دارد) ← تست اتصال ← افزودن. آدرس‌ها ذخیره و برای همهٔ گوشی‌ها همگام می‌شوند.
