# Socle 3.0 — Modèles 3D des damistes et animations de déplacement

## Objectif
Remplacer les jetons cylindriques simples par des figurines humanoïdes stylisées construites directement en géométrie WebGL, sans bibliothèque externe et sans modifier le moteur réglementaire des dames.

## Modèle des damistes
- Socle de jeu conservé pour rappeler la nature du jeu de dames.
- Silhouette humanoïde composée d'une tunique, d'une tête sphérique, de bras, de mains et de jambes.
- Palette rouge et bleue différenciée selon le camp.
- Modèle de dame couronnée, avec couronne dorée et pointes distinctes.
- Géométrie générée localement dans le moteur WebGL ; aucun téléchargement de modèle ou dépendance CDN.

## Animations
- Déplacement interpolé sur chaque segment du chemin légal.
- Impulsion verticale et légère inclinaison pendant le déplacement.
- Les prises multiples restent animées segment par segment.
- Le modèle transmis à l'animation est la pièce réellement arrivée sur la case : le couronnement acquis pendant le coup est donc représenté correctement.

## Préservation
- Les règles, les coups légaux, les prises obligatoires, les prises multiples, les dames volantes, les effets d'arène et les horloges restent gérés par les moteurs existants.
- Les huit moteurs de compétition ne sont pas modifiés dans cette étape.
- Le rendu est une figurine 3D stylisée, pas un personnage humain photoréaliste. Les modèles sculptés, visages détaillés, vêtements texturés, animations squelettiques et foule animée restent à développer.

## Vérifications
- 174 tests automatisés réussis.
- Vérification syntaxique de tous les fichiers JavaScript de `src/` et `tests/`.
- Comparaison des huit moteurs de compétition avec le Socle 2.9 : fichiers inchangés.
- Le test visuel réel dans un navigateur et sur appareil mobile reste à effectuer.
