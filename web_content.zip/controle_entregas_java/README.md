# Controle de Entregas — projeto Android Java (teste de compilação)

Este projeto é uma **versão de teste compilável como projeto Android**, com `MainActivity.java` em Java e a interface atual v18 carregada offline dentro de um WebView. Isso permite testar a compilação/instalação no Android Studio sem perder a interface atual.

**Importante:** esta primeira versão NÃO é uma migração completa da lógica para Java nativo. A interface e as regras existentes continuam em `app/src/main/assets/index.html` (HTML/JavaScript); o contêiner Android é Java. Os recursos de backup que já existiam no HTML não são corrigidos apenas por este empacotamento.

## Como compilar
1. Extraia o ZIP.
2. Abra a pasta `controle_entregas_java` no Android Studio.
3. Aguarde o Gradle sincronizar. Use JDK 17 e Android SDK Platform 35.
4. Se solicitado, aceite instalar o Android Gradle Plugin 8.6.1 e as ferramentas do SDK.
5. Use **Build > Build APK(s)**. O APK de depuração normalmente aparece em `app/build/outputs/apk/debug/app-debug.apk`.

O projeto precisa baixar as ferramentas Gradle/Android na primeira compilação, portanto a compilação exige internet e Android Studio/SDK configurados. O app em execução não precisa de internet para abrir a interface.
