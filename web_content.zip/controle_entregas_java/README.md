# Controle de Entregas — projeto Android Java v19 (teste de persistência)

Esta versão mantém a interface v18, mas altera o modo como o Android hospeda os arquivos:
- usa `WebViewAssetLoader` e uma origem HTTPS local estável (`appassets.androidplatform.net`);
- ativa DOM Storage e banco de dados do WebView;
- desativa acesso a arquivos locais desnecessário.

A mudança busca corrigir a persistência do `localStorage` ao abrir o app em diferentes sessões. **Não é uma prova de que os dados já estão recuperados nem uma garantia de backup externo.** Faça um teste com um registro fictício antes de voltar a confiar no histórico.

## Teste recomendado
1. Instale esta compilação de teste sem desinstalar primeiro a versão anterior, se o Android permitir atualizar com a mesma assinatura. Se não permitir, NÃO desinstale a versão antiga antes de exportar/recuperar os dados.
2. Adicione uma entrega fictícia.
3. Feche o app completamente e abra de novo.
4. Confira se a entrega continua no histórico.
5. Teste a exportação de backup e confirme que o arquivo JSON aparece em Downloads/Arquivos e que pode ser aberto.

## Compilar
1. Extraia o ZIP e abra a pasta `controle_entregas_java` no Android Studio.
2. Use JDK 17 e Android SDK Platform 35.
3. Sincronize o Gradle e selecione Build > Build APK(s).
4. APK de depuração normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.

A primeira compilação precisa de internet para baixar dependências. O app não precisa de internet para executar a interface.

## Limitações conhecidas
- A interface e as regras de negócio continuam no arquivo `app/src/main/assets/index.html` (HTML/JavaScript); o invólucro Android é Java.
- Esta versão ainda não substitui os botões de backup do HTML por operações nativas Android. A exportação externa precisa ser testada separadamente; a mensagem atual do HTML pode indicar apenas que o backup foi preparado.
- Se os dados já desapareceram na instalação anterior, esta mudança não os recupera automaticamente.
