# boss Server Ter — Prototype 0.1

This is a local, mobile-friendly HTML prototype. Open `index.html` in a browser.

## Included
- Arabic RTL black/green interface
- CCcam, Newcamd, SOCKS5, HTTP Proxy and generic TCP entry forms
- Local host/port syntax validation
- Temporary in-memory list (not persisted; refresh clears it)

## Important limitations
This prototype does NOT perform real Ping, TCP, SOCKS5, HTTP proxy, CCcam or Newcamd authentication tests. A browser page cannot open arbitrary raw TCP sockets. It does not verify subscriptions or channel access.

## Android APK
No APK is included. Building a real APK requires an Android project/build environment and a native networking layer. The next implementation stage can wrap this UI in an Android WebView and add explicit, authorized connectivity checks (TCP connect, HTTP proxy test, SOCKS5 handshake). Protocol/account checks should only be run against servers you own or are authorized to test.
