# Safar Accounts — Travel Agency MVP

## What this MVP does
- Offline-first browser app using IndexedDB (local browser database) with a localStorage fallback.
- Separate company data records, with company switcher and create-company button.
- Agents, customers/passengers, bookings/invoices, currency-specific ledger, simple reports.
- Invoice detail page can be printed or saved as PDF from the browser print dialog.
- Share invoice/statement text through the device share sheet (choose WhatsApp when available).
- JSON export/import backup.
- English/Urdu language selector (core UI translation is partial in this MVP).
- Responsive layout for mobile and desktop.

## Run it
For the best PWA/offline experience, serve this folder from localhost or HTTPS:
1. Unzip the project.
2. On a computer, run `python -m http.server 8080` inside this folder.
3. Open `http://localhost:8080` in a browser. For Android testing, deploy to an HTTPS host or use an Android development environment.
Opening index.html directly also works for most screens, but service-worker installation generally requires localhost/HTTPS.

## Important limitations — not production-ready
- This is a functional local prototype, not a production accounting system.
- No real user authentication or role-based server security yet.
- Companies are separated in the app UI/data model but share the same browser database; not suitable for confidential multi-tenant use without server-side isolation.
- No multi-device sync, cloud backup, bank reconciliation, double-entry ledger posting, FX rate history, or real payment collection workflow.
- Multi-currency amounts are intentionally not converted automatically; reports are filtered by currency. Do not add totals across different currencies.
- WhatsApp share sends text via the native share sheet; attaching a PDF automatically depends on browser/device capabilities and is not guaranteed.
- Back up data regularly. Clearing browser data may delete local records.
- Urdu translations are partial; have a native speaker review before commercial use.

## Suggested next production phase
Flutter Android/web client, local SQLite database, encrypted/signed backup, sync engine, PostgreSQL backend, Supabase Auth + Row Level Security, double-entry accounting, immutable posted vouchers/audit log, exchange-rate records and tests.


## Database schema proposal
See `schema.sql` for a PostgreSQL production-schema starting point covering companies, memberships, agents, customers, currencies, exchange rates, bookings, invoices, payments, vouchers, journal lines, and audit logs. It is a schema proposal, not a secured/deployed database; RLS policies and validation triggers still need to be implemented and tested.


## WhatsApp link fix
The invoice and ledger share actions now open the HTTPS `https://wa.me/?text=...` endpoint rather than relying on a `whatsapp://` scheme or the Web Share API. This avoids the `ERR_UNKNOWN_URL_SCHEME` error in many preview webviews. To attach the actual invoice PDF, save it using PDF / Print first and attach the saved file inside WhatsApp; text sharing cannot attach a PDF by itself.
