-- PostgreSQL production schema proposal for Safar Accounts
-- Tenant isolation: every business record carries company_id.
-- Enforce tenant membership and company_id with server-side RLS policies before production.

CREATE TABLE companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  base_currency CHAR(3) NOT NULL DEFAULT 'PKR',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  auth_user_id UUID UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE company_memberships (
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('owner','admin','accountant','agent','viewer')),
  is_active BOOLEAN NOT NULL DEFAULT true,
  PRIMARY KEY (company_id, user_id)
);

CREATE TABLE agents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id),
  agent_code TEXT,
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  address TEXT,
  opening_balance NUMERIC(18,2) NOT NULL DEFAULT 0,
  opening_currency CHAR(3) NOT NULL DEFAULT 'PKR',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(company_id, agent_code)
);

CREATE TABLE customers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  passport_number TEXT,
  cnic TEXT,
  address TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE currencies (
  code CHAR(3) PRIMARY KEY,
  name TEXT NOT NULL,
  symbol TEXT
);

INSERT INTO currencies(code,name,symbol) VALUES
 ('PKR','Pakistani Rupee','Rs'),
 ('USD','US Dollar','$'),
 ('SAR','Saudi Riyal','SAR'),
 ('AED','UAE Dirham','AED'),
 ('GBP','British Pound','£'),
 ('EUR','Euro','€')
ON CONFLICT (code) DO NOTHING;

CREATE TABLE exchange_rates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  from_currency CHAR(3) NOT NULL REFERENCES currencies(code),
  to_currency CHAR(3) NOT NULL REFERENCES currencies(code),
  rate NUMERIC(20,8) NOT NULL CHECK (rate > 0),
  effective_date DATE NOT NULL,
  source TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(company_id, from_currency, to_currency, effective_date)
);

CREATE TABLE chart_of_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  account_code TEXT NOT NULL,
  name TEXT NOT NULL,
  account_type TEXT NOT NULL CHECK (account_type IN ('asset','liability','equity','income','expense')),
  parent_id UUID REFERENCES chart_of_accounts(id),
  currency CHAR(3) REFERENCES currencies(code),
  is_active BOOLEAN NOT NULL DEFAULT true,
  UNIQUE(company_id, account_code)
);

CREATE TABLE bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  booking_no TEXT NOT NULL,
  booking_type TEXT NOT NULL CHECK (booking_type IN ('air_ticket','visa','hotel','tour_package','umrah_package','general','quick')),
  customer_id UUID REFERENCES customers(id),
  agent_id UUID REFERENCES agents(id),
  booking_date DATE NOT NULL DEFAULT CURRENT_DATE,
  travel_date DATE,
  return_date DATE,
  supplier_name TEXT,
  ticket_number TEXT,
  pnr TEXT,
  visa_reference TEXT,
  hotel_name TEXT,
  check_in DATE,
  check_out DATE,
  status TEXT NOT NULL DEFAULT 'draft',
  notes TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(company_id, booking_no)
);

CREATE TABLE invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  invoice_no TEXT NOT NULL,
  booking_id UUID REFERENCES bookings(id),
  customer_id UUID REFERENCES customers(id),
  agent_id UUID REFERENCES agents(id),
  invoice_date DATE NOT NULL DEFAULT CURRENT_DATE,
  currency CHAR(3) NOT NULL REFERENCES currencies(code),
  subtotal NUMERIC(18,2) NOT NULL DEFAULT 0,
  discount NUMERIC(18,2) NOT NULL DEFAULT 0,
  tax NUMERIC(18,2) NOT NULL DEFAULT 0,
  total NUMERIC(18,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','posted','part_paid','paid','void')),
  notes TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(company_id, invoice_no)
);

CREATE TABLE invoice_lines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  quantity NUMERIC(12,3) NOT NULL DEFAULT 1,
  unit_price NUMERIC(18,2) NOT NULL DEFAULT 0,
  cost_price NUMERIC(18,2) NOT NULL DEFAULT 0,
  line_total NUMERIC(18,2) NOT NULL DEFAULT 0
);

CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  payment_no TEXT NOT NULL,
  customer_id UUID REFERENCES customers(id),
  agent_id UUID REFERENCES agents(id),
  invoice_id UUID REFERENCES invoices(id),
  payment_date DATE NOT NULL DEFAULT CURRENT_DATE,
  direction TEXT NOT NULL CHECK (direction IN ('received','paid')),
  method TEXT NOT NULL DEFAULT 'cash' CHECK (method IN ('cash','bank','card','online','other')),
  currency CHAR(3) NOT NULL REFERENCES currencies(code),
  amount NUMERIC(18,2) NOT NULL CHECK (amount > 0),
  reference TEXT,
  notes TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(company_id, payment_no)
);

CREATE TABLE vouchers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  voucher_no TEXT NOT NULL,
  voucher_type TEXT NOT NULL CHECK (voucher_type IN ('journal','cash_receipt','cash_payment','bank_receipt','bank_payment','expense','recovery')),
  voucher_date DATE NOT NULL DEFAULT CURRENT_DATE,
  narration TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','posted','void')),
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(company_id, voucher_no)
);

CREATE TABLE journal_lines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  voucher_id UUID NOT NULL REFERENCES vouchers(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES chart_of_accounts(id),
  customer_id UUID REFERENCES customers(id),
  agent_id UUID REFERENCES agents(id),
  currency CHAR(3) NOT NULL REFERENCES currencies(code),
  debit NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (debit >= 0),
  credit NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (credit >= 0),
  base_debit NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (base_debit >= 0),
  base_credit NUMERIC(18,2) NOT NULL DEFAULT 0 CHECK (base_credit >= 0),
  exchange_rate NUMERIC(20,8) NOT NULL DEFAULT 1 CHECK (exchange_rate > 0),
  CHECK (NOT (debit > 0 AND credit > 0))
);

CREATE TABLE audit_log (
  id BIGSERIAL PRIMARY KEY,
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id),
  action TEXT NOT NULL,
  table_name TEXT NOT NULL,
  record_id UUID,
  old_values JSONB,
  new_values JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_bookings_company_date ON bookings(company_id, booking_date);
CREATE INDEX idx_invoices_company_date ON invoices(company_id, invoice_date);
CREATE INDEX idx_invoices_customer ON invoices(company_id, customer_id);
CREATE INDEX idx_invoices_agent ON invoices(company_id, agent_id);
CREATE INDEX idx_payments_company_date ON payments(company_id, payment_date);
CREATE INDEX idx_journal_lines_account ON journal_lines(account_id);

-- Production requirements:
-- 1) Enable RLS on every tenant table.
-- 2) Add policies checking authenticated membership for the row's company_id.
-- 3) Validate that linked customer/agent/account records belong to the same company.
-- 4) Post vouchers atomically only when total base debits equal total base credits.
-- 5) Prevent edits/deletes to posted vouchers; use reversal vouchers instead.
-- 6) Add SQLite equivalent for offline local storage and a tested conflict-resolution sync layer.
