// سرور واسط: کلید API فقط اینجا نگه داشته می‌شود، نه داخل اپ.
// اجرا: ANTHROPIC_API_KEY=sk-... node server.js   (نیازمند Node 18 به بالا)
const http = require("http");
const KEY = process.env.ANTHROPIC_API_KEY;
const TOKEN = process.env.APP_TOKEN || "";
const MODEL = process.env.MODEL || "claude-sonnet-5-5";
const PORT = process.env.PORT || 3000;
const LIMIT = Number(process.env.LIMIT_PER_HOUR || 30);
const hits = new Map();

function send(res, code, obj) {
  res.writeHead(code, {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, x-app-token",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  });
  res.end(JSON.stringify(obj));
}

function limited(ip) {
  const now = Date.now(), h = (hits.get(ip) || []).filter(t => now - t < 3600e3);
  h.push(now); hits.set(ip, h);
  return h.length > LIMIT;
}

http.createServer((req, res) => {
  if (req.method === "OPTIONS") return send(res, 204, {});
  if (req.method !== "POST" || req.url !== "/api/generate") return send(res, 404, { error: "not found" });
  if (TOKEN && req.headers["x-app-token"] !== TOKEN) return send(res, 401, { error: "unauthorized" });
  const ip = req.headers["x-forwarded-for"] || req.socket.remoteAddress;
  if (limited(ip)) return send(res, 429, { error: "rate limited" });
  let body = "";
  req.on("data", c => { body += c; if (body.length > 20000) req.destroy(); });
  req.on("end", async () => {
    try {
      const { prompt } = JSON.parse(body);
      if (!prompt || typeof prompt !== "string") return send(res, 400, { error: "bad request" });
      const r = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": KEY, "anthropic-version": "2023-06-01" },
        body: JSON.stringify({ model: MODEL, max_tokens: 2000, messages: [{ role: "user", content: prompt }] })
      });
      const j = await r.json();
      if (!r.ok) return send(res, 502, { error: (j.error && j.error.message) || "upstream error" });
      send(res, 200, { text: j.content.filter(b => b.type === "text").map(b => b.text).join("\n") });
    } catch (e) { send(res, 500, { error: "server error" }); }
  });
}).listen(PORT, () => console.log("listening on " + PORT));
