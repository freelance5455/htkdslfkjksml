# استودیوی خلاقیت هوشمند: پروژه APK

## ساختار
- `www/`: خود اپ (HTML). فایل `config.js` آدرس سرور را نگه می‌دارد.
- `server/`: سرور کوچک Node که به Claude API وصل می‌شود. کلید API فقط اینجاست.
- `capacitor.config.json`، `package.json`: برای تبدیل `www` به اپ اندروید.

## مرحله ۱: سرور
1. کلید API را از console.anthropic.com بگیر.
2. پوشه `server` را روی یک سرویس میزبانی Node مثل Render، Railway یا Fly.io بگذار.
3. متغیرهای محیطی را تنظیم کن:
   - `ANTHROPIC_API_KEY` (الزامی)
   - `APP_TOKEN` (یک رمز دلخواه، پیشنهادی)
   - `LIMIT_PER_HOUR` (پیش‌فرض ۳۰ درخواست در ساعت برای هر IP)
4. بعد از انتشار، آدرس سرور را در `www/config.js` بنویس.

تست محلی: `cd server && ANTHROPIC_API_KEY=... node server.js`

## مرحله ۲: ساخت APK
نیازمند Node 18+، Android Studio و JDK 17.
```
npm install
npx cap add android
npx cap sync android
npx cap open android
```
در Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
برای انتشار در فروشگاه از Generate Signed Bundle / APK استفاده کن.

## راه سریع‌تر بدون Android Studio
`www/` را روی یک هاست HTTPS بگذار (مثلاً Netlify یا GitHub Pages) و آدرسش را به pwabuilder.com بده تا APK بسازد.

## نکات
- `APP_TOKEN` داخل اپ قابل استخراج است. این فقط جلوی استفاده تصادفی را می‌گیرد، پس محدودیت ساعتی و سقف هزینه در کنسول API را هم تنظیم کن.
- مدل پیش‌فرض `claude-sonnet-5-5` است و با متغیر `MODEL` عوض می‌شود.
- سرور باید HTTPS باشد، وگرنه اندروید درخواست‌ها را مسدود می‌کند.
