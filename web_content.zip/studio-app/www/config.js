// آدرس سروری که server/server.js روی آن اجرا می‌شود (بدون / در انتها)
window.CFG = {
  API_URL: "https://YOUR-SERVER.example.com",
  APP_TOKEN: "" // اگر در سرور APP_TOKEN گذاشتی همان را اینجا بنویس
};
