package com.zentrya.loans.printer;

// ═══════════════════════════════════════════════════════════════════════
// ZentryaPrinterBridge.java
// Android JavascriptInterface for Zentrya Loans APK
// Compatible: Android 6+ (API 23+), Bluetooth Classic SPP
// ═══════════════════════════════════════════════════════════════════════

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Base64;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ZentryaPrinterBridge {

    private static final String TAG = "ZentryaPrinter";
    // SPP UUID — standard for Bluetooth serial printers
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

    private final Activity activity;
    private final WebView webView;
    private final BluetoothAdapter btAdapter;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private BluetoothSocket btSocket;
    private OutputStream btOutputStream;
    private String connectedDeviceAddress = null;
    private String connectedDeviceName = null;

    // Saved printer preference key
    private static final String PREF_PRINTER_ADDR = "zentrya_printer_addr";
    private static final String PREF_PRINTER_NAME = "zentrya_printer_name";

    public ZentryaPrinterBridge(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
        this.btAdapter = BluetoothAdapter.getDefaultAdapter();
    }

    // ── Register with WebView ──
    public void register() {
        webView.addJavascriptInterface(this, "AndroidPrinter");
        Log.d(TAG, "ZentryaPrinterBridge registered as 'AndroidPrinter'");
    }

    // ── Check & Request Bluetooth Permissions ──
    @SuppressLint("MissingPermission")
    private boolean hasBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Android 12+
            return ContextCompat.checkSelfPermission(activity, Manifest.permission.BLUETOOTH_SCAN)
                    == PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(activity, Manifest.permission.BLUETOOTH_CONNECT)
                    == PackageManager.PERMISSION_GRANTED;
        } else {
            // Android < 12
            return ContextCompat.checkSelfPermission(activity, Manifest.permission.BLUETOOTH)
                    == PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED;
        }
    }

    public void requestBluetoothPermissions(int requestCode) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.requestPermissions(activity, new String[]{
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT,
            }, requestCode);
        } else {
            ActivityCompat.requestPermissions(activity, new String[]{
                    Manifest.permission.BLUETOOTH,
                    Manifest.permission.BLUETOOTH_ADMIN,
                    Manifest.permission.ACCESS_FINE_LOCATION,
            }, requestCode);
        }
    }

    // ── JS Interface: Get paired/bonded devices ──
    @JavascriptInterface
    @SuppressLint("MissingPermission")
    public String getPairedDevices() {
        JSONArray result = new JSONArray();
        if (btAdapter == null || !btAdapter.isEnabled()) {
            return result.toString();
        }
        try {
            Set<BluetoothDevice> paired = btAdapter.getBondedDevices();
            for (BluetoothDevice dev : paired) {
                JSONObject obj = new JSONObject();
                obj.put("name", dev.getName() != null ? dev.getName() : "Unknown");
                obj.put("address", dev.getAddress());
                result.put(obj);
            }
        } catch (Exception e) {
            Log.e(TAG, "getPairedDevices error: " + e.getMessage());
        }
        return result.toString();
    }

    // ── JS Interface: Scan = returns paired devices (discovery requires more setup) ──
    @JavascriptInterface
    public String scanDevices() {
        return getPairedDevices();
    }

    // ── JS Interface: Connect to printer by MAC address ──
    @JavascriptInterface
    @SuppressLint("MissingPermission")
    public boolean connect(final String address) {
        if (!hasBluetoothPermission()) {
            requestBluetoothPermissions(1001);
            return false;
        }
        if (btAdapter == null || !btAdapter.isEnabled()) return false;

        // Disconnect existing
        disconnect();

        try {
            BluetoothDevice device = btAdapter.getRemoteDevice(address);
            BluetoothSocket socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
            btAdapter.cancelDiscovery();
            socket.connect(); // Blocking — runs on caller's thread
            btSocket = socket;
            btOutputStream = socket.getOutputStream();
            connectedDeviceAddress = address;
            connectedDeviceName = device.getName();
            // Save preference
            activity.getSharedPreferences("zentrya_prefs", 0)
                    .edit()
                    .putString(PREF_PRINTER_ADDR, address)
                    .putString(PREF_PRINTER_NAME, device.getName())
                    .apply();
            Log.d(TAG, "Connected to: " + connectedDeviceName);
            return true;
        } catch (IOException e) {
            Log.e(TAG, "connect error: " + e.getMessage());
            btSocket = null; btOutputStream = null;
            return false;
        }
    }

    // ── JS Interface: Disconnect ──
    @JavascriptInterface
    public void disconnect() {
        try {
            if (btOutputStream != null) btOutputStream.close();
            if (btSocket != null) btSocket.close();
        } catch (IOException e) {
            Log.e(TAG, "disconnect error: " + e.getMessage());
        } finally {
            btSocket = null; btOutputStream = null;
            connectedDeviceAddress = null; connectedDeviceName = null;
        }
    }

    // ── JS Interface: Print raw ESC/POS data (base64 encoded) ──
    @JavascriptInterface
    public boolean printRaw(final String base64Data) {
        if (btOutputStream == null) {
            Log.e(TAG, "printRaw: not connected");
            return false;
        }
        try {
            byte[] data = Base64.decode(base64Data, Base64.DEFAULT);
            btOutputStream.write(data);
            btOutputStream.flush();
            Log.d(TAG, "printRaw: " + data.length + " bytes sent");
            return true;
        } catch (IOException e) {
            Log.e(TAG, "printRaw error: " + e.getMessage());
            // Try to reconnect
            if (connectedDeviceAddress != null) {
                connect(connectedDeviceAddress);
            }
            return false;
        }
    }

    // ── JS Interface: Check connection status ──
    @JavascriptInterface
    public boolean isConnected() {
        return btSocket != null && btSocket.isConnected();
    }

    // ── JS Interface: Get connected device name ──
    @JavascriptInterface
    public String getConnectedDeviceName() {
        return connectedDeviceName != null ? connectedDeviceName : "";
    }

    // ── JS Interface: Get saved printer address ──
    @JavascriptInterface
    public String getSavedPrinterAddress() {
        return activity.getSharedPreferences("zentrya_prefs", 0)
                .getString(PREF_PRINTER_ADDR, "");
    }

    // ── JS Interface: Get saved printer name ──
    @JavascriptInterface
    public String getSavedPrinterName() {
        return activity.getSharedPreferences("zentrya_prefs", 0)
                .getString(PREF_PRINTER_NAME, "");
    }

    // ── Auto-reconnect to saved printer ──
    public void autoReconnect() {
        String savedAddr = getSavedPrinterAddress();
        if (!savedAddr.isEmpty()) {
            executor.submit(() -> {
                boolean ok = connect(savedAddr);
                String name = getSavedPrinterName();
                // Notify JS
                final String js = ok
                    ? "if(typeof _ZPrinterSetStatus==='function')_ZPrinterSetStatus('" + name + "','Reconectada automáticamente',true);"
                    : "if(typeof _ZPrinterSetStatus==='function')_ZPrinterSetStatus('" + name + "','Reconectar para imprimir',false);";
                activity.runOnUiThread(() -> webView.evaluateJavascript(js, null));
            });
        }
    }
}
