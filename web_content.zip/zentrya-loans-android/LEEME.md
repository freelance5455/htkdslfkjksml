# Zentrya Loans Mobile — proyecto Android (AAB)

Incluye: `MainActivity` (WebView), el puente de impresora `ZentryaPrinterBridge` (Bluetooth clásico SPP), el AndroidManifest con los permisos de Bluetooth, el ícono con tu logo y `index.html` (la app, en `app/src/main/assets/`).

> Este proyecto no se pudo compilar desde donde lo preparé (sin SDK de Android). Compila siguiendo una de las dos opciones; si marca un error, envíame el mensaje exacto.

## Paso 0 — Crear tu llave de firma (una sola vez)
Necesitas Java (keytool). En una terminal:
```
keytool -genkeypair -v -keystore zentrya.jks -alias zentrya -keyalg RSA -keysize 2048 -validity 10000
```
Guarda `zentrya.jks` y las contraseñas en un lugar seguro. **Si la pierdes no podrás actualizar la app en Google Play.** No la subas a ningún sitio público.

## Opción A — Gratis en la nube con GitHub (sin instalar nada)
1. Crea una cuenta en github.com y un repositorio **privado** nuevo.
2. Sube **todo el contenido** de esta carpeta (incluida la carpeta oculta `.github`). Lo más fácil es con GitHub Desktop; en la web, arrastra la carpeta completa.
3. En el repositorio: *Settings › Secrets and variables › Actions › New repository secret*. Crea estos 4:
   - `KEYSTORE_BASE64` → el contenido de `zentrya.jks` en base64 (Mac/Linux: `base64 -i zentrya.jks`; Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("zentrya.jks"))`)
   - `KEYSTORE_PASSWORD` → la contraseña del keystore
   - `KEY_ALIAS` → `zentrya`
   - `KEY_PASSWORD` → la contraseña de la llave
4. Pestaña **Actions › Construir AAB (Zentrya Loans) › Run workflow**. A los pocos minutos descarga el artefacto **zentrya-loans-aab**: ahí viene `app-release.aab`.

## Opción B — Android Studio (en tu PC)
1. Instala Android Studio y abre esta carpeta (*Open*). Deja que termine de sincronizar Gradle.
2. Crea `keystore.properties` en la carpeta raíz:
   ```
   storeFile=C:/ruta/zentrya.jks
   storePassword=TU_CLAVE
   keyAlias=zentrya
   keyPassword=TU_CLAVE
   ```
3. Menú **Build › Generate Signed App Bundle / APK › Android App Bundle** (o en terminal: `./gradlew bundleRelease`).
4. El archivo queda en `app/build/outputs/bundle/release/app-release.aab`.

## Subir a Google Play
Play Console (cuenta de desarrollador, pago único de 25 USD) › Crear app › Producción o Prueba interna › sube el `.aab`. Usa *Play App Signing* cuando lo pida.
Si quieres un APK para instalar directo en un teléfono, usa Android Studio: *Build › Build APK(s)*.

## Notas
- Al abrir la app se muestra tu logo centrado sobre fondo blanco durante 2 segundos. Para cambiar la duración edita `2000` (milisegundos) en `MainActivity.java`.
- `icono-google-play-512.png` es el ícono de 512×512 que Play Console pide al crear la ficha de la app.
- `versionCode` / `versionName` están en `app/build.gradle`. Súbelos cada vez que publiques una versión nueva.
- Apunta a la API 36, la que Google Play exige hoy para apps nuevas. Si tu consola pide otra, cámbiala en `compileSdk` y `targetSdk`.
- La impresora usa Bluetooth clásico (SPP): empareja la impresora primero en Ajustes de Android y luego elige *Conectar* dentro de la app.
- La app carga el HTML incluido en el paquete. Cuando cambie el HTML, reemplaza `app/src/main/assets/index.html` y sube una nueva versión.
