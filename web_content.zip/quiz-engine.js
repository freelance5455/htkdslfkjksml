/* JOSTECH — MOTEUR D'ÉVALUATIONS ET NOTATION SUR 20 (PHASE 3) */
let activeQuizState = null;
let quizTimerInterval = null;

function qEscape(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function normalizeShort(str) {
  return String(str || "")
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .toLowerCase().replace(/\s+/g, " ").trim();
}

function shuffleArr(arr) {
  const copy = arr.slice();
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function getQuizHistory() {
  try {
    const raw = localStorage.getItem("jostech_quiz_history");
    return raw ? JSON.parse(raw) : [];
  } catch (e) { return []; }
}

function saveQuizResult(entry) {
  const hist = getQuizHistory();
  hist.unshift(entry);
  try { localStorage.setItem("jostech_quiz_history", JSON.stringify(hist.slice(0, 30))); } catch (e) {}
}

function getOverallAverage20() {
  const hist = getQuizHistory();
  if (!hist.length) return null;
  const sum = hist.reduce((acc, h) => acc + Number(h.score20 || 0), 0);
  return (sum / hist.length).toFixed(1);
}

function getMention(note20) {
  if (note20 >= 18) return "Excellent — Félicitations";
  if (note20 >= 16) return "Très Bien";
  if (note20 >= 14) return "Bien";
  if (note20 >= 12) return "Assez Bien";
  if (note20 >= 10) return "Passable — Admis";
  return "Insuffisant — À réviser";
}

function stopQuizTimer() {
  if (quizTimerInterval) {
    clearInterval(quizTimerInterval);
    quizTimerInterval = null;
  }
}

// 1. LISTE DES QUIZ, EXAMENS ET HISTORIQUE
function renderExamsScreen() {
  stopQuizTimer();
  const listBox = document.getElementById("exams-list-container");
  const histBox = document.getElementById("exams-history-container");
  const avgBadge = document.getElementById("exams-avg-badge");
  if (!listBox || typeof QUIZZES === "undefined") return;

  const avg = getOverallAverage20();
  if (avgBadge) avgBadge.textContent = avg !== null ? `Moyenne : ${avg}/20` : "Aucune note";

  const hist = getQuizHistory();
  listBox.innerHTML = "";

  QUIZZES.forEach(q => {
    const isExam = q.mode === "exam";
    const lastTry = hist.find(h => h.quizId === q.id);
    const card = document.createElement("div");
    card.className = "disc-card";
    card.onclick = () => startQuiz(q.id);
    card.innerHTML = `
      <div class="disc-top">
        <span class="disc-num">${isExam ? "EXAMEN OFFICIEL" : "ENTRAÎNEMENT"}</span>
        <span class="${isExam ? "pill-badge pilot" : "pill-badge"}">${q.questions.length} questions • ${q.durationMin} min</span>
      </div>
      <h4>${qEscape(q.title)}</h4>
      <p>${qEscape(q.subtitle)}</p>
      <div class="disc-footer">
        <span>${lastTry ? `Dernière note : ${lastTry.score20}/20` : "Pas encore passé"}</span>
        <span>Commencer →</span>
      </div>
    `;
    listBox.appendChild(card);
  });

  if (histBox) {
    if (!hist.length) {
      histBox.innerHTML = `<div class="info-banner">Vous n'avez encore passé aucune évaluation. Vos notes sur 20 et mentions apparaîtront ici.</div>`;
    } else {
      histBox.innerHTML = "";
      hist.slice(0, 8).forEach(h => {
        const row = document.createElement("div");
        row.className = "recent-item";
        const color = h.score20 >= 10 ? "var(--success)" : "#ef4444";
        row.innerHTML = `
          <div>
            <strong>${qEscape(h.title)}</strong>
            <span>${qEscape(h.dateLabel)} • ${qEscape(h.mention)}</span>
          </div>
          <strong style="color:${color}; font-size:1rem;">${h.score20}/20</strong>
        `;
        histBox.appendChild(row);
      });
    }
  }
}

// 2. PRÉPARATION ET LANCEMENT D'UN QUIZ (MÉLANGE ALÉATOIRE)
function startQuiz(quizId) {
  if (typeof QUIZZES === "undefined") return;
  const quiz = QUIZZES.find(q => q.id === quizId);
  if (!quiz) return;

  stopQuizTimer();

  const preparedQuestions = shuffleArr(quiz.questions).map(q => {
    const copy = Object.assign({}, q);
    if (q.type === "single") {
      const opts = q.options.map((txt, idx) => ({ txt, ok: idx === q.answer }));
      copy._opts = shuffleArr(opts);
    } else if (q.type === "multi") {
      const opts = q.options.map((txt, idx) => ({ txt, ok: q.answers.includes(idx) }));
      copy._opts = shuffleArr(opts);
    }
    return copy;
  });

  activeQuizState = {
    quiz,
    questions: preparedQuestions,
    currentIdx: 0,
    userAnswers: new Array(preparedQuestions.length).fill(null),
    secondsLeft: quiz.durationMin * 60,
    submitted: false
  };

  document.getElementById("quiz-runner-title").textContent = quiz.title;
  document.getElementById("quiz-runner-mode").textContent = quiz.mode === "exam" ? "Examen noté /20" : "Entraînement /20";
  document.getElementById("quiz-question-panel").style.display = "block";
  document.getElementById("quiz-result-panel").style.display = "none";

  startQuizTimer();
  renderQuizQuestion();
  if (typeof navigateTo === "function") navigateTo("quiz-runner");
}

function startQuizTimer() {
  const badge = document.getElementById("quiz-timer-badge");
  function updateBadge() {
    if (!activeQuizState || !badge) return;
    const m = Math.floor(activeQuizState.secondsLeft / 60);
    const s = activeQuizState.secondsLeft % 60;
    badge.textContent = `⏱ ${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  updateBadge();
  quizTimerInterval = setInterval(() => {
    if (!activeQuizState || activeQuizState.submitted) { stopQuizTimer(); return; }
    activeQuizState.secondsLeft--;
    updateBadge();
    if (activeQuizState.secondsLeft <= 0) {
      stopQuizTimer();
      if (typeof showToast === "function") showToast("Temps écoulé ! Copie remise.");
      submitActiveQuiz();
    }
  }, 1000);
}

// 3. AFFICHAGE D'UNE QUESTION
function renderQuizQuestion() {
  if (!activeQuizState) return;
  const { questions, currentIdx, userAnswers } = activeQuizState;
  const q = questions[currentIdx];
  const total = questions.length;

  document.getElementById("quiz-progress-text").textContent = `Question ${currentIdx + 1} sur ${total}`;
  document.getElementById("quiz-progress-fill").style.width = `${Math.round(((currentIdx + 1) / total) * 100)}%`;

  const card = document.getElementById("quiz-question-card");
  card.innerHTML = "";

  const typeLabels = {
    single: "Choix unique (1 seule réponse)",
    multi: "Choix multiples (cochez toutes les bonnes réponses)",
    tf: "Vrai ou Faux",
    short: "Réponse courte"
  };

  const tag = document.createElement("span");
  tag.className = "pill-badge";
  tag.textContent = typeLabels[q.type] || "Question";
  card.appendChild(tag);

  const qTitle = document.createElement("h3");
  qTitle.className = "quiz-q-text";
  qTitle.textContent = q.q;
  card.appendChild(qTitle);

  const optsWrap = document.createElement("div");
  optsWrap.className = "quiz-options";

  if (q.type === "single") {
    q._opts.forEach((opt, i) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = userAnswers[currentIdx] === i ? "quiz-opt-btn selected" : "quiz-opt-btn";
      btn.textContent = opt.txt;
      btn.onclick = () => { userAnswers[currentIdx] = i; renderQuizQuestion(); };
      optsWrap.appendChild(btn);
    });
  } else if (q.type === "multi") {
    const selectedArr = Array.isArray(userAnswers[currentIdx]) ? userAnswers[currentIdx] : [];
    q._opts.forEach((opt, i) => {
      const isSel = selectedArr.includes(i);
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = isSel ? "quiz-opt-btn selected" : "quiz-opt-btn";
      btn.innerHTML = `<span class="chk-box">${isSel ? "☑" : "☐"}</span> ${qEscape(opt.txt)}`;
      btn.onclick = () => {
        const next = selectedArr.includes(i) ? selectedArr.filter(x => x !== i) : [...selectedArr, i];
        userAnswers[currentIdx] = next;
        renderQuizQuestion();
      };
      optsWrap.appendChild(btn);
    });
  } else if (q.type === "tf") {
    [{ val: true, lbl: "Vrai" }, { val: false, lbl: "Faux" }].forEach(item => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = userAnswers[currentIdx] === item.val ? "quiz-opt-btn selected" : "quiz-opt-btn";
      btn.textContent = item.lbl;
      btn.onclick = () => { userAnswers[currentIdx] = item.val; renderQuizQuestion(); };
      optsWrap.appendChild(btn);
    });
  } else if (q.type === "short") {
    const inp = document.createElement("input");
    inp.type = "text";
    inp.className = "quiz-short-input";
    inp.placeholder = "Tapez votre réponse ici...";
    inp.value = userAnswers[currentIdx] || "";
    inp.oninput = (e) => { userAnswers[currentIdx] = e.target.value; };
    optsWrap.appendChild(inp);
  }

  card.appendChild(optsWrap);

  const prevBtn = document.getElementById("quiz-prev-btn");
  const nextBtn = document.getElementById("quiz-next-btn");
  const submitBtn = document.getElementById("quiz-submit-btn");

  prevBtn.disabled = currentIdx === 0;
  prevBtn.onclick = () => { if (currentIdx > 0) { activeQuizState.currentIdx--; renderQuizQuestion(); } };

  const isLast = currentIdx === total - 1;
  nextBtn.style.display = isLast ? "none" : "inline-block";
  submitBtn.style.display = isLast ? "inline-block" : "none";
  nextBtn.onclick = () => { if (!isLast) { activeQuizState.currentIdx++; renderQuizQuestion(); } };
  submitBtn.onclick = submitActiveQuiz;
}

// 4. CORRECTION AUTOMATIQUE & CALCUL SUR 20
function submitActiveQuiz() {
  if (!activeQuizState || activeQuizState.submitted) return;
  activeQuizState.submitted = true;
  stopQuizTimer();

  const { quiz, questions, userAnswers } = activeQuizState;
  let earned = 0;
  const corrections = [];

  questions.forEach((q, idx) => {
    const ans = userAnswers[idx];
    let isOk = false;
    let userLabel = "Aucune réponse";
    let rightLabel = "";

    if (q.type === "single") {
      const okIdx = q._opts.findIndex(o => o.ok);
      rightLabel = q._opts[okIdx].txt;
      if (ans !== null && q._opts[ans]) {
        userLabel = q._opts[ans].txt;
        isOk = ans === okIdx;
      }
    } else if (q.type === "multi") {
      const okIdxs = q._opts.map((o, i) => o.ok ? i : -1).filter(i => i !== -1);
      rightLabel = okIdxs.map(i => q._opts[i].txt).join(" | ");
      const sel = Array.isArray(ans) ? ans.slice().sort() : [];
      if (sel.length) userLabel = sel.map(i => q._opts[i].txt).join(" | ");
      isOk = sel.length === okIdxs.length && sel.every((v, k) => v === okIdxs[k]);
    } else if (q.type === "tf") {
      rightLabel = q.answer ? "Vrai" : "Faux";
      if (ans !== null) {
        userLabel = ans ? "Vrai" : "Faux";
        isOk = ans === q.answer;
      }
    } else if (q.type === "short") {
      rightLabel = q.displayAnswer;
      const norm = normalizeShort(ans);
      if (norm) {
        userLabel = ans;
        isOk = q.accepted.some(acc => normalizeShort(acc) === norm);
      }
    }

    if (isOk) earned++;
    corrections.push({ q: q.q, isOk, userLabel, rightLabel, explanation: q.explanation });
  });

  const note20 = Math.round((earned / questions.length) * 20 * 10) / 10;
  const mention = getMention(note20);
  const now = new Date();
  const dateLabel = now.toLocaleDateString("fr-FR") + " " + now.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });

  saveQuizResult({
    quizId: quiz.id,
    title: quiz.title,
    mode: quiz.mode,
    score20: note20,
    earned,
    total: questions.length,
    mention,
    dateLabel
  });

  if (typeof updateDashboardStats === "function") updateDashboardStats();

  document.getElementById("quiz-question-panel").style.display = "none";
  document.getElementById("quiz-result-panel").style.display = "block";
  document.getElementById("quiz-score-value").textContent = `${note20} / 20`;
  document.getElementById("quiz-score-mention").textContent = mention;
  document.getElementById("quiz-score-detail").textContent = `${earned} bonne(s) réponse(s) sur ${questions.length}`;

  const corrList = document.getElementById("quiz-corrections-list");
  corrList.innerHTML = "";
  corrections.forEach((c, i) => {
    const box = document.createElement("div");
    box.className = "lesson-box";
    box.style.borderLeft = c.isOk ? "4px solid var(--success)" : "4px solid #ef4444";
    box.innerHTML = `
      <h4>${c.isOk ? "✓" : "✕"} Question ${i + 1}</h4>
      <p style="color:var(--text-main); margin-bottom:6px;">${qEscape(c.q)}</p>
      <p style="font-size:0.84rem;"><strong>Votre réponse :</strong> ${qEscape(c.userLabel)}</p>
      ${!c.isOk ? `<p style="font-size:0.84rem; color:var(--success);"><strong>Bonne réponse :</strong> ${qEscape(c.rightLabel)}</p>` : ""}
      <p style="font-size:0.83rem; margin-top:6px;"><em>Explication :</em> ${qEscape(c.explanation)}</p>
    `;
    corrList.appendChild(box);
  });

  document.getElementById("quiz-retry-btn").onclick = () => startQuiz(quiz.id);
  window.scrollTo({ top: 0, behavior: "smooth" });
}