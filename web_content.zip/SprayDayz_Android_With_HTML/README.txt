SPRAYDAYZ ANDROID + HTML BUILD
Open this project in Android Studio and build an APK with:
Build > Generate App Bundles or APKs > Generate APKs

SprayDayz.html is a lightweight browser prototype included for testing.
