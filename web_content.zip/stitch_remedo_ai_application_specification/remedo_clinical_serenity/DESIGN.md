---
name: Remedo Clinical Serenity
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#3e4946'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#6e7a75'
  outline-variant: '#bdc9c4'
  surface-tint: '#006b5b'
  primary: '#005f50'
  on-primary: '#ffffff'
  primary-container: '#0d7a68'
  on-primary-container: '#aaffe9'
  inverse-primary: '#7cd7c1'
  secondary: '#006b5f'
  on-secondary: '#ffffff'
  secondary-container: '#6df5e1'
  on-secondary-container: '#006f64'
  tertiary: '#096045'
  on-tertiary: '#ffffff'
  tertiary-container: '#2d795d'
  on-tertiary-container: '#b2ffdb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#99f3dd'
  primary-fixed-dim: '#7cd7c1'
  on-primary-fixed: '#00201a'
  on-primary-fixed-variant: '#005144'
  secondary-fixed: '#71f8e4'
  secondary-fixed-dim: '#4fdbc8'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#a6f2cf'
  tertiary-fixed-dim: '#8bd6b4'
  on-tertiary-fixed: '#002115'
  on-tertiary-fixed-variant: '#00513a'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1.25rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system embodies an empathetic, clinical yet human companion designed to dismantle medical anxiety. It pairs the clinical rigor of modern digital health with the organic warmth of restorative wellness.

### Aesthetic Foundation
- **Modern Restorative**: Marries soft, humanized contours with precise data density and medical clarity.
- **Atmospheric Quietude**: Employs ample negative space, gentle tinting, and balanced contrast to eliminate cognitive overload during stressful health incidents.
- **Tactile Trust**: Generous touch targets, pilliform micro-interactions, and supportive visual cues ensure effortless navigation across diverse age groups and physiological conditions.

## Colors

The palette establishes an immediate sense of biological calm while adhering strictly to WCAG 2.1 AA/AAA contrast ratios for clinical legibility.

### Palette Architecture
- **Deep Eucalyptus (`#0D7A68`)**: Primary brand anchor. Used for critical CTAs, active states, key interactive indicators, and primary navigation headers.
- **Teal Aura (`#14B8A6`)**: Secondary energetic hue. Applied to secondary interactions, progress bars, active toggles, and generative AI highlights.
- **Soft Mint / Sage (`#A7F3D0`)**: Tertiary grounding tone. Deployed for subtle icon containers, pill badges, active card highlights, and AI conversational bubbles.
- **Slate Ground (`#0F172A`)**: Primary neutral text color, ensuring razor-sharp clarity without the harshness of pure black.
- **Base Canvas (`#F8FAFC`)**: Crisp, warm slate-tinted white base surface that avoids clinical sterility while preserving optical freshness.

### Clinical Triage & Semantic Tokens
- **Mild / Stable**: Emerald base (`#059669`) over soft mint tint (`#ECFDF5`).
- **Moderate / Caution**: Amber base (`#D97706`) over warm chamois tint (`#FFFBEB`).
- **Urgent / Critical**: Crimson base (`#DC2626`) over soft rose tint (`#FEF2F2`).

## Typography

Plus Jakarta Sans provides geometric balance alongside humanist warmth, creating high legibility for critical vitals and symptom reporting.

### Typographic Hierarchy
- **Display & Headlines**: Generous weights (`600`, `700`) paired with subtle negative tracking ground patient metrics and screen anchors firmly.
- **Body Copy**: Set at default line-height ratios between 140% and 150% to prevent visual friction during extended diagnostic symptom assessments.
- **Labels & Microcopy**: Structured with positive letter spacing to maintain clarity on dense mobile triage tags and biometric monitoring modules.

## Layout & Spacing

The layout philosophy follows a mobile-first fluid grid structured around 4 columns on hand-held devices and 8 columns on expanded tablet canvases.

### Rhythm & Alignment
- **Margins**: Mobile canvases implement a `1rem` baseline outer safe-area margin, expanding to `1.25rem` or `1.5rem` on larger portrait displays.
- **Gutters**: Consistent `1rem` column gutters ensure modular assessment cards never visually bleed into neighboring metrics.
- **Vertical Flow**: Screen sections stack using standard rhythm intervals (`space-md` between inline elements, `space-xl` between major assessment domains).

## Elevation & Depth

Visual hierarchy is maintained via gentle tonal layer stacking and low-contrast ambient shadows tinted with eucalyptus undertones, rejecting harsh drop shadows in favor of a soft, therapeutic environment.

### Depth Hierarchy
- **Level 0 (Canvas Surface)**: `#F8FAFC` base layer.
- **Level 1 (Card & Module Foundation)**: Pure white `#FFFFFF` paired with an ambient tinted shadow: `0 4px 20px -2px rgba(13, 122, 104, 0.05)`.
- **Level 2 (Interactive Floating Elements & Trays)**: Elevated drawers and pinned bottom sheets: `0 12px 32px -4px rgba(15, 23, 42, 0.08)`.
- **Level 3 (Modals & Urgent Overlays)**: Triage warnings and system dialogs: `0 20px 48px -6px rgba(15, 23, 42, 0.16)`.
- **Subtle Surface Definition**: All elevated surfaces feature an internal border trace (`1px solid rgba(13, 122, 104, 0.08)`) to preserve definition across edge cases in display brightness.

## Shapes

The design system embraces an organic, non-threatening geometry centered on level 2 roundedness to soften the perception of clinical data.

### Structural Radius Application
- **Core Components (`rounded-2xl` / 1rem)**: Inputs, segmented chips, health metric modules, and standard listing rows.
- **Hero Containers (`rounded-3xl` / 1.5rem)**: Daily wellness overview containers, symptom checker intake prompts, and floating action panels.
- **Pills (`rounded-full`)**: Primary action triggers, conversational AI triage bubbles, and quick-filter pills.

## Components

### Buttons & Interactive Controls
- **Primary Action**: Pill-shaped (`rounded-full`), `#0D7A68` background, white text, 48px standard height, providing steady finger-friendly touch zones. Active state applies `#0A5C4F`.
- **Secondary Action**: Soft mint surface (`#E6F4F1`) with deep eucalyptus label (`#0D7A68`), devoid of harsh borders.
- **Ghost/Tertiary**: No background, medium weight slate label with a contextual chevron or icon trailing.

### Triage & Health Status Badges
- **Structure**: Compact pill structure with an internal 6px status indicator dot.
- **Mild Condition**: Pale mint background (`#ECFDF5`), forest text (`#059669`), emerald indicator dot.
- **Moderate Condition**: Warm amber background (`#FFFBEB`), burnt ochre text (`#B45309`), amber indicator dot.
- **Urgent Action Needed**: Delicate rose background (`#FEF2F2`), crimson text (`#B91C1C`), pulsing ruby indicator dot.

### Input Fields & Selectors
- Background is tinted neutral white (`#FFFFFF`) framed with a 1px border (`#E2E8F0`).
- Focus state highlights with a 2px `#0D7A68` outline and a soft `#0D7A6815` exterior halo.
- Generous inner padding (`12px 16px`) with helper labels situated outside the input box to avoid field occlusion.

### Patient & Metric Cards
- Crafted using `rounded-2xl` or `rounded-3xl` radii, pure white background, and ambient eucalyptus shadow.
- Divided into structured sub-zones using hairline dividers (`rgba(226, 232, 240, 0.6)`), ensuring medical metrics remain systematically compartmentalized.

### Conversational Remedo AI Bubble
- Distinct soft gradient/tint (`#F0FDF4` to `#F8FAFC`) with a subtle 1px border (`#A7F3D0`).
- Features dedicated clinical confirmation indicators (e.g., "Verified clinical prompt") rendered in `label-sm`.