package com.kistikhata.lock

import android.app.Activity
import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.os.UserManager
import android.telecom.TelecomManager
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.work.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

// ফোনে জমা থাকা তথ্য: সার্ভারের ঠিকানা, টোকেন, লকের অবস্থা (0 চালু, 1 লক, 2 মুক্ত)
object Store {
    private fun p(c: Context) = c.getSharedPreferences("s", Context.MODE_PRIVATE)
    fun save(c: Context, server: String, token: String) =
        p(c).edit().putString("server", server).putString("token", token).apply()
    fun server(c: Context) = p(c).getString("server", "") ?: ""
    fun token(c: Context) = p(c).getString("token", "") ?: ""
    fun state(c: Context) = p(c).getInt("state", 0)
    fun msg(c: Context) = p(c).getString("msg", "") ?: ""
    fun phone(c: Context) = p(c).getString("phone", "") ?: ""
    fun set(c: Context, s: Int, m: String, ph: String) =
        p(c).edit().putInt("state", s).putString("msg", m).putString("phone", ph).apply()
}

object Policy {
    private fun dpm(c: Context) = c.getSystemService(DevicePolicyManager::class.java)
    private fun admin(c: Context) = ComponentName(c, AdminReceiver::class.java)

    fun apply(c: Context) {
        val d = dpm(c); val a = admin(c)
        if (!d.isDeviceOwnerApp(c.packageName)) return
        d.setUninstallBlocked(a, c.packageName, true)
        d.addUserRestriction(a, UserManager.DISALLOW_FACTORY_RESET)
        d.addUserRestriction(a, UserManager.DISALLOW_SAFE_BOOT)
        val dialer = c.getSystemService(TelecomManager::class.java).defaultDialerPackage
        d.setLockTaskPackages(a, listOfNotNull(c.packageName, dialer).toTypedArray())
        d.setLockTaskFeatures(a, 0)
    }

    // সব কিস্তি শেষ হলে ফোন পুরোপুরি ক্রেতার হাতে ছেড়ে দেওয়া হয়
    fun release(c: Context) {
        val d = dpm(c); val a = admin(c)
        if (!d.isDeviceOwnerApp(c.packageName)) return
        d.setUninstallBlocked(a, c.packageName, false)
        d.clearUserRestriction(a, UserManager.DISALLOW_FACTORY_RESET)
        d.clearUserRestriction(a, UserManager.DISALLOW_SAFE_BOOT)
        d.clearDeviceOwnerApp(c.packageName)
    }
}

object Sync {
    fun fetch(c: Context): Boolean {
        val s = Store.server(c); val t = Store.token(c)
        if (s.isEmpty() || t.isEmpty()) return false
        return try {
            val h = URL("$s?r=device&token=$t").openConnection() as HttpURLConnection
            h.connectTimeout = 10000; h.readTimeout = 10000
            val j = JSONObject(h.inputStream.bufferedReader().use { it.readText() })
            Store.set(c, j.getInt("state"), j.optString("msg"), j.optString("phone"))
            true
        } catch (e: Exception) { false }
    }

    fun sync(c: Context) {
        if (!fetch(c)) return
        when (Store.state(c)) {
            1 -> c.startActivity(Intent(c, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            2 -> { WorkManager.getInstance(c).cancelUniqueWork("poll"); Policy.release(c) }
        }
    }

    fun schedule(c: Context) {
        val net = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val wm = WorkManager.getInstance(c)
        wm.enqueueUniquePeriodicWork("poll", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<Poll>(15, TimeUnit.MINUTES).setConstraints(net).build())
        wm.enqueue(OneTimeWorkRequestBuilder<Poll>().setConstraints(net).build())
    }
}

class Poll(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result { Sync.sync(applicationContext); return Result.success() }
}

class AdminReceiver : DeviceAdminReceiver() {
    override fun onProfileProvisioningComplete(c: Context, i: Intent) {
        @Suppress("DEPRECATION")
        val ex = i.getParcelableExtra<PersistableBundle>(DevicePolicyManager.EXTRA_PROVISIONING_ADMIN_EXTRAS_BUNDLE)
        Store.save(c, ex?.getString("server") ?: "", ex?.getString("token") ?: "")
        Policy.apply(c)
        Sync.schedule(c)
    }
}

class ProvisionActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (intent.action == DevicePolicyManager.ACTION_GET_PROVISIONING_MODE) {
            setResult(RESULT_OK, Intent().putExtra(DevicePolicyManager.EXTRA_PROVISIONING_MODE,
                DevicePolicyManager.PROVISIONING_MODE_FULLY_MANAGED_DEVICE))
        } else setResult(RESULT_OK)
        finish()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Sync.schedule(c)
        if (Store.state(c) == 1)
            c.startActivity(Intent(c, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

class LockActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var tv: TextView

    // লক অবস্থায় প্রতি ২০ সেকেন্ডে সার্ভার দেখে, তাই আনলক দ্রুত হয়
    private val tick = object : Runnable {
        override fun run() {
            Thread {
                Sync.fetch(applicationContext)
                runOnUiThread {
                    when (Store.state(this@LockActivity)) {
                        1 -> { tv.text = Store.msg(this@LockActivity); h.postDelayed(this, 20000) }
                        else -> {
                            if (Store.state(this@LockActivity) == 2) Thread { Policy.release(applicationContext) }.start()
                            try { stopLockTask() } catch (e: Exception) {}
                            finish()
                        }
                    }
                }
            }.start()
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL; l.gravity = Gravity.CENTER
        l.setPadding(60, 60, 60, 60); l.setBackgroundColor(0xFF0B5D4B.toInt())
        fun t(s: String, sp: Float) = TextView(this).apply {
            text = s; textSize = sp; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER; setPadding(0, 16, 0, 16)
        }
        fun btn(s: String, num: () -> String) = Button(this).apply {
            text = s
            setOnClickListener { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + num()))) }
        }
        l.addView(t("ফোন লক করা হয়েছে", 26f))
        tv = t(Store.msg(this), 18f); l.addView(tv)
        l.addView(btn("দোকানে কল করুন") { Store.phone(this) })
        l.addView(btn("জরুরি কল (৯৯৯)") { "999" })
        setContentView(l)
        try { startLockTask() } catch (e: Exception) {}
        h.post(tick)
    }

    override fun onDestroy() { h.removeCallbacks(tick); super.onDestroy() }
    @Deprecated("lock screen: back is disabled")
    override fun onBackPressed() {}
}
