কিস্তি খাতা + ফোন লক : বসানোর ধাপ
=================================

ক) সার্ভার (cPanel)
 1. phpMyAdmin-এ নতুন ডাটাবেস বানিয়ে server/schema.sql ইমপোর্ট করুন।
 2. server/api.php খুলে উপরের DB_*, ADMIN_KEY, SHOP_PHONE বদলান।
 3. api.php ও index.html একই ফোল্ডারে আপলোড করুন (যেমন yourshop.com/khata/)। HTTPS চালু থাকতে হবে।
 4. yourshop.com/khata/ খুলে ADMIN_KEY দিয়ে ঢুকুন।

খ) ফোনের অ্যাপ (Android Studio)
 1. New Project > "No Activity", package: com.kistikhata.lock, Minimum SDK: API 29।
 2. app/build.gradle-এ dependencies-এ যোগ করুন:  implementation("androidx.work:work-runtime:2.9.0")
 3. android/Lock.kt  -> app/src/main/java/com/kistikhata/lock/Lock.kt
    android/AndroidManifest.xml -> app/src/main/AndroidManifest.xml (পুরোনোটা বদলে)
    android/device_admin.xml -> app/src/main/res/xml/device_admin.xml (xml ফোল্ডার না থাকলে বানান)
 4. Build > Build APK। APK-র নাম lock.apk করে সার্ভারে আপলোড করুন।
 5. checksum বের করুন (কম্পিউটারে):
    openssl dgst -binary -sha256 lock.apk | openssl base64 | tr '+/' '-_' | tr -d '='
 6. খাতার "সেটিংস"-এ APK লিংক ও checksum বসান।

গ) ফোনে বসানো
 1. ফোন ফ্যাক্টরি রিসেট করুন (অথবা নতুন ফোন)। প্রথম "Welcome" স্ক্রিনে ৬ বার টোকা দিন।
 2. Wi-Fi যুক্ত করুন, QR স্ক্যানার খুলবে। খাতায় ওই গ্রাহকের পাতার "ফোনে অ্যাপ বসানোর QR" স্ক্যান করুন।
 3. আগে একটা পুরোনো ফোনে পরীক্ষা করুন। Device Owner শুধু রিসেট করা ফোনেই বসে।

ঘ) জরুরি নিয়ম
 - বিক্রির আগে ক্রেতার লিখিত সম্মতি নিন: ফোন কিস্তি বাকি থাকলে লক হতে পারে, শেষ কিস্তির পর পুরোপুরি মুক্ত হবে।
 - সব কিস্তি শেষ হলে খাতায় "ফোন চিরতরে মুক্ত করুন" চাপুন। তখন অ্যাপের নিয়ন্ত্রণ সরে যায়।
 - লক স্ক্রিনে দোকানের কল ও জরুরি কল সবসময় খোলা থাকে।
 - লক কার্যকর হতে ফোনে ইন্টারনেট লাগে, সর্বোচ্চ প্রায় ১৫ মিনিট দেরি হতে পারে।
