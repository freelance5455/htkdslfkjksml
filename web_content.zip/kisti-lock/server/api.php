<?php
// ===== শুধু এই অংশ বদলান =====
const DB_HOST='localhost', DB_NAME='your_db', DB_USER='your_user', DB_PASS='your_pass';
const ADMIN_KEY='CHANGE-THIS-LONG-SECRET';   // কমপক্ষে ২০ অক্ষরের গোপন চাবি
const SHOP_PHONE='01XXXXXXXXX';
const DEFAULT_MSG='কিস্তি বাকি আছে। দয়া করে দোকানে যোগাযোগ করুন।';
// ============================
header('Content-Type: application/json; charset=utf-8');
function out($d,$c=200){http_response_code($c);echo json_encode($d,JSON_UNESCAPED_UNICODE);exit;}
try{$pdo=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);}
catch(Exception $e){out(['error'=>'db'],500);}
$r=$_GET['r']??'';

if($r==='device'){ // ফোনের অ্যাপ এটা ডাকে
  $t=$_GET['token']??'';
  $s=$pdo->prepare('SELECT lock_state,lock_msg FROM customers WHERE device_token=?');$s->execute([$t]);$c=$s->fetch();
  if(!$c)out(['error'=>'unknown'],404);
  $pdo->prepare('UPDATE customers SET last_seen=NOW() WHERE device_token=?')->execute([$t]);
  out(['state'=>(int)$c['lock_state'],'msg'=>$c['lock_msg']?:DEFAULT_MSG,'phone'=>SHOP_PHONE]);
}

if(ADMIN_KEY==='CHANGE-THIS-LONG-SECRET'||!hash_equals(ADMIN_KEY,$_SERVER['HTTP_X_ADMIN_KEY']??''))out(['error'=>'auth'],401);
$in=json_decode(file_get_contents('php://input'),true)?:[];

switch($r){
case 'list':
  $cs=$pdo->query('SELECT id,name,phone,addr,model,imei,total,down,n,first_due AS startd,lock_state AS lk,lock_msg,device_token AS token,last_seen AS seen FROM customers ORDER BY id')->fetchAll();
  $by=[];foreach($pdo->query('SELECT id,customer_id,d,amt FROM payments ORDER BY d,id')->fetchAll() as $p)$by[$p['customer_id']][]=['id'=>$p['id'],'d'=>$p['d'],'amt'=>$p['amt']];
  foreach($cs as &$c)$c['pays']=$by[$c['id']]??[];
  out(['customers'=>$cs]);
case 'save':
  $pdo->prepare('INSERT INTO customers(name,phone,addr,model,imei,total,down,n,first_due,device_token) VALUES(?,?,?,?,?,?,?,?,?,?)')
      ->execute([$in['name']??'',$in['phone']??'',$in['addr']??'',$in['model']??'',$in['imei']??'',(int)($in['total']??0),(int)($in['down']??0),max(1,(int)($in['n']??1)),$in['start']??date('Y-m-d'),bin2hex(random_bytes(16))]);
  out(['id'=>(int)$pdo->lastInsertId()]);
case 'pay':
  $pdo->prepare('INSERT INTO payments(customer_id,d,amt) VALUES(?,?,?)')->execute([(int)$in['id'],$in['d'],(int)$in['amt']]);out(['ok'=>1]);
case 'delpay':
  $pdo->prepare('DELETE FROM payments WHERE id=?')->execute([(int)$in['id']]);out(['ok'=>1]);
case 'lock':
  $st=(int)($in['state']??0);if(!in_array($st,[0,1,2],true))out(['error'=>'bad'],400);
  $pdo->prepare('UPDATE customers SET lock_state=?,lock_msg=? WHERE id=?')->execute([$st,(string)($in['msg']??''),(int)$in['id']]);out(['ok'=>1]);
case 'del':
  $pdo->prepare('DELETE FROM customers WHERE id=?')->execute([(int)$in['id']]);out(['ok'=>1]);
default: out(['error'=>'not found'],404);
}
