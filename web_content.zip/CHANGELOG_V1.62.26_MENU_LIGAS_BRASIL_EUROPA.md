# v1.62.26 — Menu Ligas: Brasil e Europa

- Menu principal reorganizado em apenas duas entradas: BRASIL e EUROPA.
- BRASIL lista Série A, Série B, Série C, Copa do Brasil e Sub-20.
- EUROPA lista Premier League e LaLiga como ligas disponíveis.
- Serie A TIM, Ligue 1 e Bundesliga aparecem como EM BREVE e não abrem telas incompletas.
- O seletor interno europeu também mostra somente Premier League e LaLiga.
- Preservados motores, calendários, tabelas, elencos, IDs permanentes, escudos e dados de carreira.
- LaLiga pode ser consultada pelo menu Europa sem alterar a liga da carreira atual.
