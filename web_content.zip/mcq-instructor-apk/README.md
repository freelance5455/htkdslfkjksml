# MCQ Instructor — APK বানানোর প্রজেক্ট

এই প্রজেক্ট থেকে GitHub নিজে নিজেই APK বানিয়ে দেবে (বিনামূল্যে, কম্পিউটারে কিছু ইনস্টল করতে হবে না)।

## APK বানানোর ধাপ
1. https://github.com এ লগইন করে **New repository** বানাও (নাম যেমন `mcq-instructor`, Public বা Private যেকোনো)।
2. এই ZIP এক্সট্রাক্ট করে ভেতরের **সব ফাইল ও ফোল্ডার** রিপোজিটরিতে আপলোড করো (**Add file → Upload files**)।
3. ফোল্ডার `.github` (লুকানো ফোল্ডার) আপলোড না হলে: **Add file → Create new file** চেপে নাম লেখো
   `.github/workflows/build-apk.yml` এবং এই ফোল্ডারের `build-apk.yml` ফাইলের লেখা পেস্ট করে **Commit** করো।
4. উপরের **Actions** ট্যাবে যাও → **Build APK** → (প্রয়োজনে **Run workflow**) → ৩–৬ মিনিট অপেক্ষা করো।
5. সবুজ ✔ হলে সেই রানে ঢুকে নিচে **Artifacts → MCQ-Instructor-APK** ডাউনলোড করো, ZIP খুললে `app-debug.apk` পাবে।
6. ফোনে APK ইনস্টল করো (প্রথমবার "Unknown sources / অজানা উৎস" অনুমতি দিতে হবে)।
7. APK ফাইলটি WhatsApp / Telegram / Google Drive দিয়ে অন্যদের শেয়ার করা যাবে।

## অ্যাপে যা কাজ করবে
- গ্যালারি / ফাইল / Google Drive থেকে ছবি বাছাই (ফোনের নিজস্ব ফাইল-পিকার)।
- alert / confirm বার্তা।
- প্রশ্নগুলো অটো-সেভ (অ্যাপ বন্ধ করলেও থাকবে)। ছবি বেশি হলে ফোনের সীমা (~৫MB) পেরোতে পারে।
- "কোড দেখাও" চেপে **📤 ফাইল সেভ / শেয়ার করুন** দিয়ে `mcq-quiz.html` ফাইলটি Drive/WhatsApp ইত্যাদিতে পাঠানো যাবে।

## আইকন / নাম বদলাতে
- নাম: `app/src/main/res/values/strings.xml`
- আইকন: `app/src/main/res/drawable/ic_launcher.xml`
- প্যানেল আপডেট করলে `app/src/main/assets/index.html` ফাইলটি বদলে আবার Commit করো।

## Play Store?
এই APK সরাসরি ইনস্টল ও শেয়ার করার জন্য (debug-সাইন করা)। Play Store-এ দিতে হলে Google Play ডেভেলপার অ্যাকাউন্ট ও নিজের কী-স্টোরে সাইন করা release AAB লাগবে।
