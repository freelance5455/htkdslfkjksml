# EuroPath Pro 🧭
**Explore Europe. Plan Smarter. Travel Better.**

یک پلتفرم سفر اروپایی چندزبانه (وب، PWA، اندروید) — اسکلت حرفه‌ای مرحلهٔ ۱ همراه با زیرساخت مراحل بعدی.
A multilingual European travel platform — production-minded scaffold: Phase 1 implemented, later phases wired for.

## ⚡ نمایش سریع بدون نصب / Instant preview (no install)
فایل **`START-HERE.html`** را مستقیم در مرورگر باز کنید (دابل‌کلیک). نسخهٔ دمو است و داده‌ها فقط در همان مرورگر ذخیره می‌شوند.
> فایل `apps/web/index.html` را مستقیم باز نکنید: آن سورس Vite است و بدون `npm run dev` یا `npm run build` فقط صفحهٔ سفید نشان می‌دهد.

## شروع سریع / Quick start

```bash
cp .env.example .env            # مقادیر JWT_ACCESS_SECRET و رمز دیتابیس را عوض کنید
docker compose up -d --build    # PostGIS + Redis + API + Web
make seed                       # (اختیاری) داده‌های نمونهٔ مکان‌ها
```
- Web: http://localhost:8080 · API: http://localhost:3000 · Swagger: http://localhost:3000/docs (فقط غیر production)

### توسعه بدون Docker برای برنامه‌ها / Local dev
```bash
docker compose up -d db redis
npm install
npm run migrate
npm run dev:api     # http://localhost:3000
npm run dev:web     # http://localhost:5173  (proxy /api → :3000)
npm test            # تست‌های واحد API
```

### اندروید / Android
```bash
cd apps/web && npm run android:init && npm run android:sync   # Capacitor
```

## چه چیزی پیاده‌سازی شده است / What's included
- **Auth**: argon2id، access token کوتاه‌مدت، refresh token چرخشی با تشخیص استفادهٔ مجدد، RBAC
- **Trips / Itinerary / Budget**: بررسی مالکیت روی هر منبع خصوصی، محدودیت‌های پلن، تفکیک «تخمین» از «هزینهٔ واقعی»
- **Places**: PostgreSQL + PostGIS (WGS84)، جست‌وجوی جغرافیایی، فیلتر دسترس‌پذیری و خانواده، ذکر منبع داده
- **Plans**: Free / Pro / Travel Plus با guard سمت سرور
- **AI planner**: فقط سمت سرور، سهمیهٔ ماهانه اتمیک، خروجی sanitize‌شده و همیشه `verified:false`
- **Provider layer**: timeout، retry، circuit breaker و fallback — بدون ساختن داده
- **GDPR**: export و حذف حساب، ثبت رضایت، audit log
- **Web**: ۷ زبان (EN/FR/DE/ES/IT/FA/AR)، RTL، PWA، تاریخ/ارز محلی‌شده
- **Infra**: Docker Compose، nginx، CI (GitHub Actions)، اسکریپت backup/restore، health check

## چه چیزی هنوز باید ساخته شود / Still to build
نقشهٔ تعاملی (MapLibre) و routing · ارائه‌دهندگان واقعی (پرواز/قطار/هتل/رستوران) · Stripe و webhook‌ها · هشدار قیمت و اعلان‌ها · نقشهٔ آفلاین · سفر گروهی · پنل ادمین. جزئیات: `docs/ROADMAP.md`.

> ⚠️ این اسکلت در محیط بدون اینترنت ساخته شد؛ `npm install` و build کامل اجرا نشده است. بعد از نصب، `npm run lint && npm test && npm run build` را اجرا کنید.

## مستندات / Docs
`docs/PRODUCT_SPEC.md` · `ARCHITECTURE.md` · `SECURITY.md` · `DATA_INTEGRITY.md` · `API.md` · `ROADMAP.md` · `LAUNCH_CHECKLIST.md`

## اصل محصول / Product principle
ابتدا یک دستیار سفر قابل‌اعتماد؛ بازار رزرو کامل فقط وقتی که دسترسی به داده، قراردادها، الزامات قانونی و اقتصاد واحد آن را توجیه کنند.
