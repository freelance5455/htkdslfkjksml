# API overview (Swagger UI at `/docs` in non-production)

All routes require `Authorization: Bearer <accessToken>` unless marked public.

| Method & path | Notes |
|---|---|
| `POST /auth/register` · `/auth/login` | public, throttled; returns `accessToken`, sets httpOnly refresh cookie |
| `POST /auth/refresh` · `/auth/logout` | public; cookie or `refreshToken` body (native apps) |
| `GET/PATCH /users/me` | profile (locale, currency, name) |
| `GET /users/me/export` · `DELETE /users/me` | GDPR portability / erasure |
| `GET /plans` | public plan catalogue (prices are hypotheses) |
| `GET/POST /trips` · `GET/PATCH/DELETE /trips/:id` | plan limit enforced on create |
| `GET/POST /trips/:id/items` · `DELETE /trips/:id/items/:itemId` | itinerary |
| `GET/POST /trips/:id/expenses` · `DELETE …/:id` | expenses |
| `GET /trips/:id/budget-summary` | planned (estimates) vs spent |
| `GET /trips/:id/expenses-report.csv` | **Pro** |
| `GET /places/search?q=&lat=&lng=&radius=&category=&accessible=&familyFriendly=` | PostGIS search with source info |
| `POST /ai/itinerary` · `GET /ai/usage` | **Pro**; quota per plan |
| `GET /health` | public liveness + DB check |
