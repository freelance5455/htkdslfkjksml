# Architecture

```
 Browser / PWA / Android (Capacitor)
            │  HTTPS
        ┌───▼───┐        /api/*        ┌──────────────┐
        │ nginx │ ───────────────────► │  NestJS API  │──► Anthropic API (server-side only)
        └───┬───┘                      │  (stateless) │──► Travel providers (via ProviderRegistry)
   static PWA bundle                   └──┬────────┬──┘
                                          │        │
                                ┌─────────▼──┐  ┌──▼────┐
                                │ PostgreSQL │  │ Redis │  (cache / queues — wired in Phase 3+)
                                │  + PostGIS │  └───────┘
                                └────────────┘
```

## Repo layout
| Path | Purpose |
|---|---|
| `apps/api` | NestJS API: auth, users (GDPR), trips, itinerary, budget, places (PostGIS), plans, AI, providers, health |
| `apps/web` | React + Vite PWA, 7 languages, RTL, Capacitor config for Android |
| `infra/` | nginx config, DB init + demo seed |
| `docs/` | Spec, security, data integrity, roadmap, launch checklist |

## Key design decisions
- **Stateless API** — scale horizontally behind a load balancer; all state in Postgres/Redis.
- **Global guards** — JWT, roles, plan entitlements and throttling apply to *every* route by default; routes opt out with `@Public()`. Forgetting a decorator fails closed.
- **Ownership in one place** — `TripsService.findOwned()` is the single gate for trip-scoped resources (items, expenses, budget). It returns 404 for foreign IDs.
- **Entitlements from the DB** — the JWT strategy reloads role/plan per request, so upgrades/downgrades/bans apply immediately. Limits live in `plan-limits.ts`.
- **Provider layer** — `ProviderRegistry` adds timeout, bounded retry with backoff, circuit breaker and ordered fallback. Failure yields an explicit `unavailable`, never invented data.
- **AI guard** — quota is reserved atomically in SQL; output is JSON-only, sanitized, forced to `verified:false`, and every cost is an estimate.
- **Migrations, not `synchronize`** — schema changes are versioned in `apps/api/src/database/migrations`.

## Environments
`docker compose up` = local/staging. For production use managed Postgres with PITR, managed Redis, a container platform behind a TLS-terminating load balancer, and a secrets manager (never `.env` files on disk).
