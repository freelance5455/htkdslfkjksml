# Roadmap & current status

| Phase | Scope | Status in this scaffold |
|---|---|---|
| 1 | Auth, trips, itinerary, destinations, budget | **Implemented** (API + web UI) |
| 2 | Interactive map (MapLibre), location DB, routing | PostGIS schema + search endpoint done; map UI & routing engine (e.g. OSRM/Valhalla) to build |
| 3 | Provider integrations (transport, stays, restaurants) | Provider abstraction, fallback & circuit breaker done; concrete providers to build |
| 4 | Subscriptions, billing, usage limits | Plan limits, plan guard and entitlements done; Stripe checkout + webhooks to build |
| 5 | AI planning, alerts, offline, group travel | AI endpoint with quotas + guard done; alerts, offline packs, group/shared budgets to build |
| 6 | Security/accessibility testing, localization, launch | Checklist in `LAUNCH_CHECKLIST.md` |

## Suggested next steps
1. `npm install`, `docker compose up`, run the app, write e2e tests (supertest) for cross-user access.
2. Add MapLibre map + OSM import for `places` (with ODbL attribution).
3. Pick first real provider (trains or hotels) and implement `TravelProvider`.
4. Stripe subscriptions → update `users.plan` from webhooks.
5. Admin dashboard & provider-cost analytics.
