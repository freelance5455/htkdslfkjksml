# EuroPath Pro — Product Master Specification

**Tagline:** Explore Europe. Plan Smarter. Travel Better.

## 1. Vision
A professional multilingual European travel platform: discover destinations, plan trips, compare transportation, find accommodation and restaurants, manage reservations, navigate maps, control expenses, and receive AI-assisted recommendations.

## 2. Platforms
Responsive web · PWA · Android · future iOS · secure cloud sync.

## 3. Languages
English, French, German, Spanish, Italian, Persian, Arabic. RTL layouts, localized dates/time zones/numbers/currencies/units. New languages must be easy to add.

## 4. Plans
| | FREE €0 | PRO €7.99/mo | TRAVEL PLUS €14.99/mo |
|---|---|---|---|
| Discovery, map, location search | ✔ | ✔ | ✔ |
| Active trips | 1 | multiple | multiple |
| Itinerary | basic | advanced builder | advanced builder |
| Budget | basic planner | tracking + reports | + shared budgets / expense splitting |
| Saved places | limited | unlimited | unlimited |
| Booking links | external | + document management, price alerts | same |
| Offline maps, cloud sync, export | – | ✔ | ✔ |
| AI itinerary | – | ✔ | higher allowance |
| Group trips, family profiles, priority support | – | – | ✔ |

Pricing, taxes, usage limits, provider costs and payment fees must be validated before commercial launch.

## 5. Core modules
Accounts · Trips & itineraries · Destinations · Maps & navigation · Flights · Trains · Bus/ground · Hotels · Restaurants · Budget & expenses · Currency · Weather & alerts · Translation assistant · Emergency info · Documents & bookings · AI planner · Subscription & billing · Notifications · Admin dashboard · Analytics & provider cost monitoring.

## 6. Mapping
PostgreSQL + PostGIS, WGS84, POIs, walking/driving/cycling/public-transport routes where supported, distance & duration estimates, offline packages where licensing permits, accessibility and family filters, provider attribution, accurate timestamps for dynamic data.

## 7. Booking & data integrity
Prices only from authorised sources · show source and last-update time · distinguish estimates from confirmed prices · an external link is never a completed reservation · confirm direct reservations only after provider confirmation · show cancellation/baggage/tax/fee details · provider secrets stay on the server · retries, rate limits, fallbacks.

## 8. AI planner
Inputs: destination, dates, budget, currency, travellers, interests, pace, accommodation, mobility needs. Outputs: itinerary, daily schedule, travel-time and expense estimates, alternatives, weather-aware suggestions, warnings about unverified information. AI must not fabricate prices, schedules, availability or booking confirmations; validate against provider data when possible.

## 9. Architecture
NestJS + Node.js · PostgreSQL + PostGIS · password hashing, short-lived access tokens, protected refresh tokens, RBAC · responsive web/PWA · MapLibre · Redis · queues & scheduled jobs · server-side AI with quotas, logging, cost control · error tracking, audit logs, backups, health checks.

## 10. Security & privacy
Ownership checks on every private resource · TLS · encrypt sensitive data · no plaintext passwords · no API keys in frontend · rate limiting · account deletion & data export · minimise location/passport retention · consent controls · GDPR & consumer/payment regulation review · tested backups.

## 11. Revenue
Monthly/annual subscriptions · affiliate commissions · direct partnerships · optional paid packages · clearly disclosed commercial recommendations · track AI cost per user, map usage, provider API cost, payment fees, refunds, revenue.

## 12. Roadmap
1. Auth, trips, itinerary, destinations, budget
2. Interactive map, location DB, routing
3. Real provider integrations
4. Subscriptions, billing, usage limits
5. AI planning, alerts, offline, group travel
6. Security & accessibility testing, localization, launch

## 13. Launch criteria
No cross-user data access · no exposed secrets · tested backup/recovery · verified entitlements · accurate attribution · clear pricing & cancellation info · tested language/currency handling · reliable external-service error handling · privacy & security review · documented provider limitations.

## Product principle
Build a reliable travel assistant first. Expand into a booking marketplace only when real data access, partnerships, legal requirements and unit economics support it.
