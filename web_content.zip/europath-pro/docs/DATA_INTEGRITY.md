# Booking & data-integrity rules (enforced in code where possible)

1. **Prices only from authorised sources.** Provider results are typed `Sourced<T>` with `source`, `fetchedAt`, `isEstimate`.
2. **Estimates ≠ confirmed prices.** Itinerary items default to `cost_is_estimate = true`; only a provider integration may flip it. Budget summary reports *planned (estimate)* and *spent* separately.
3. **External link ≠ reservation.** `bookingUrl` is a link only; there is no "booked" state without a provider confirmation record (to be added in Phase 3/4).
4. **AI never fabricates.** System prompt forbids exact prices/schedules; `sanitizeItinerary()` strips invalid costs, flags booking language, forces `verified:false`, and always returns warnings.
5. **Failures are visible.** `ProviderRegistry` returns `{ ok:false, unavailable:true }`; the UI must show this instead of stale or guessed data.
6. **Timestamps everywhere** for dynamic data (`updated_at`, `fetchedAt`).
7. **Map data attribution** — `places.source` / `source_url` are mandatory fields; the seed data is labelled `demo-seed` and must be replaced with a licensed dataset.
