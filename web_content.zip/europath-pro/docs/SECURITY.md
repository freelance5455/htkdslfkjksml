# Security & privacy controls

| Control | Implementation |
|---|---|
| Password storage | argon2id; constant-time-ish login (dummy hash) to resist user enumeration |
| Sessions | 15-min access JWT (memory only on web) + rotating refresh token, hashed (SHA-256) in DB, httpOnly SameSite=Strict cookie; reuse detection revokes the whole token family |
| Authorization | Global JWT guard, RBAC (`@Roles`), plan guard (`@RequirePlan`), ownership via `findOwned()` |
| Input validation | `ValidationPipe` with whitelist + forbidNonWhitelisted; UUID pipes on all IDs; parameterised SQL only |
| Abuse protection | Global throttler (120/min) + stricter limits on login/register/refresh/AI |
| Transport | TLS terminated at the load balancer; HSTS to be enabled there; helmet + security headers in nginx |
| Secrets | Server-side env only; startup fails on weak/placeholder JWT secret in production; no keys in the web bundle |
| Privacy | Consent timestamp at signup; `GET /users/me/export` (portability); `DELETE /users/me` (erasure, cascades); audit log keeps no personal data after deletion |
| CSV export | Formula-injection neutralised |
| AI | Prompt-injection-aware system prompt; user text passed as JSON data; output sanitized; quotas and token logging |
| Auditing | `audit_logs` for register/login/failed login/export/delete/refresh-reuse |

## Before launch
- [ ] Independent penetration test; dependency audit in CI (included) reviewed
- [ ] Encrypt sensitive columns (e.g. passport numbers) with envelope encryption if/when stored — default is *do not store*
- [ ] Enable HSTS, set `Secure` cookies (automatic when `NODE_ENV=production`)
- [ ] Rotate secrets via a secrets manager; set up error tracking (Sentry or similar) and alerting
- [ ] DPIA / GDPR review, privacy policy, cookie/consent UX, data-processing agreements with providers
- [ ] Payment compliance review (Stripe handles card data; never store card numbers)
