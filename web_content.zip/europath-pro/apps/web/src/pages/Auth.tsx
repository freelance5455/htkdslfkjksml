import { FormEvent, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { api, setToken } from '../api';

export default function Auth({ onAuthed }: { onAuthed: () => void }) {
  const { t, i18n } = useTranslation();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [err, setErr] = useState(false);

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const body = mode === 'login'
      ? { email: f.get('email'), password: f.get('password') }
      : { email: f.get('email'), password: f.get('password'), displayName: f.get('name') || undefined, locale: i18n.language, acceptTerms: f.get('terms') === 'on' };
    try {
      const r = await api<{ accessToken: string }>(`/auth/${mode}`, { method: 'POST', body: JSON.stringify(body) });
      setToken(r.accessToken);
      onAuthed();
    } catch { setErr(true); }
  }

  return (
    <section className="auth">
      <h1>{t('tagline')}</h1>
      <form onSubmit={submit} className="card stack">
        <div className="tabs" role="tablist">
          {(['login', 'register'] as const).map((m) => (
            <button key={m} type="button" role="tab" aria-selected={mode === m} className={mode === m ? 'tab on' : 'tab'} onClick={() => { setMode(m); setErr(false); }}>
              {t(m)}
            </button>
          ))}
        </div>
        {mode === 'register' && <label>{t('name')}<input name="name" autoComplete="name" /></label>}
        <label>{t('email')}<input name="email" type="email" required autoComplete="email" /></label>
        <label>{t('password')}<input name="password" type="password" required minLength={mode === 'register' ? 10 : 1} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} /></label>
        {mode === 'register' && <label className="check"><input name="terms" type="checkbox" required /> {t('terms')}</label>}
        {err && <p role="alert" className="error">{t('error')}</p>}
        <button className="primary">{t(mode)}</button>
      </form>
    </section>
  );
}
