import { FormEvent, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { api, Trip } from '../api';
import { fmtDate } from '../i18n';

export default function Trips() {
  const { t } = useTranslation();
  const [trips, setTrips] = useState<Trip[] | null>(null);
  const [err, setErr] = useState(false);
  const load = () => api<Trip[]>('/trips').then(setTrips).catch(() => setErr(true));
  useEffect(() => { load(); }, []);

  async function create(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const f = new FormData(form);
    try {
      await api('/trips', { method: 'POST', body: JSON.stringify({
        title: f.get('title'), destination: f.get('destination'), startDate: f.get('start'), endDate: f.get('end'),
        travelers: Number(f.get('travelers') || 1), budget: f.get('budget') ? Number(f.get('budget')) : undefined,
      }) });
      form.reset(); setErr(false); load();
    } catch { setErr(true); }
  }

  return (
    <>
      <h1>{t('trips')}</h1>
      <div className="split">
        <ul className="trips">
          {trips?.length === 0 && <li className="empty">{t('noTrips')}</li>}
          {trips?.map((x) => (
            <li key={x.id}>
              <Link to={`/trips/${x.id}`}>
                <strong>{x.title}</strong>
                <span>{x.destination}</span>
                <small>{fmtDate(x.startDate)} – {fmtDate(x.endDate)}</small>
              </Link>
            </li>
          ))}
        </ul>
        <form onSubmit={create} className="card stack">
          <h2>{t('newTrip')}</h2>
          <label>{t('title')}<input name="title" required maxLength={120} /></label>
          <label>{t('destination')}<input name="destination" required maxLength={120} /></label>
          <div className="row">
            <label>{t('start')}<input name="start" type="date" required /></label>
            <label>{t('end')}<input name="end" type="date" required /></label>
          </div>
          <div className="row">
            <label>{t('travelers')}<input name="travelers" type="number" min={1} max={50} defaultValue={1} /></label>
            <label>{t('budget')}<input name="budget" type="number" min={0} step="0.01" /></label>
          </div>
          {err && <p role="alert" className="error">{t('error')}</p>}
          <button className="primary">{t('create')}</button>
        </form>
      </div>
    </>
  );
}
