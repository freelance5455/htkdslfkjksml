import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Link, useParams } from 'react-router-dom';
import { api, Expense, Item, Summary, Trip } from '../api';
import { fmtDate, fmtMoney } from '../i18n';

export default function TripDetail() {
  const { id } = useParams();
  const { t } = useTranslation();
  const [trip, setTrip] = useState<Trip | null>(null);
  const [items, setItems] = useState<Item[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [sum, setSum] = useState<Summary | null>(null);
  const [err, setErr] = useState(false);

  const load = useCallback(async () => {
    try {
      const [tr, it, ex, su] = await Promise.all([
        api<Trip>(`/trips/${id}`), api<Item[]>(`/trips/${id}/items`),
        api<Expense[]>(`/trips/${id}/expenses`), api<Summary>(`/trips/${id}/budget-summary`),
      ]);
      setTrip(tr); setItems(it); setExpenses(ex); setSum(su);
    } catch { setErr(true); }
  }, [id]);
  useEffect(() => { load(); }, [load]);

  const byDay = useMemo(() => {
    const m = new Map<string, Item[]>();
    items.forEach((i) => m.set(i.day, [...(m.get(i.day) ?? []), i]));
    return [...m.entries()];
  }, [items]);

  async function addItem(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget; const f = new FormData(form);
    try {
      await api(`/trips/${id}/items`, { method: 'POST', body: JSON.stringify({
        day: f.get('day'), title: f.get('title'),
        startTime: f.get('time') || undefined, estimatedCost: f.get('cost') ? Number(f.get('cost')) : undefined,
      }) });
      form.reset(); setErr(false); load();
    } catch { setErr(true); }
  }
  async function addExpense(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget; const f = new FormData(form);
    try {
      await api(`/trips/${id}/expenses`, { method: 'POST', body: JSON.stringify({
        amount: Number(f.get('amount')), category: f.get('category') || undefined, spentAt: f.get('date'),
      }) });
      form.reset(); setErr(false); load();
    } catch { setErr(true); }
  }
  const delItem = async (itemId: string) => { await api(`/trips/${id}/items/${itemId}`, { method: 'DELETE' }); load(); };
  const delExpense = async (eid: string) => { await api(`/trips/${id}/expenses/${eid}`, { method: 'DELETE' }); load(); };

  if (!trip) return err ? <p role="alert" className="error">{t('error')}</p> : null;

  return (
    <>
      <Link to="/" className="back">{t('back')}</Link>
      <h1>{trip.title}</h1>
      <p className="muted">{trip.destination} · {fmtDate(trip.startDate)} – {fmtDate(trip.endDate)}</p>

      <div className="split">
        <section>
          <h2>{t('itinerary')}</h2>
          <form onSubmit={addItem} className="card stack">
            <div className="row">
              <label>{t('day')}<input name="day" type="date" required min={trip.startDate.slice(0, 10)} max={trip.endDate.slice(0, 10)} /></label>
              <label>{t('time')}<input name="time" type="time" /></label>
            </div>
            <label>{t('itemTitle')}<input name="title" required maxLength={160} /></label>
            <label>{t('cost')} ({trip.currency}, {t('estimate')})<input name="cost" type="number" min={0} step="0.01" /></label>
            <button className="primary">{t('addItem')}</button>
          </form>

          {byDay.length === 0 && <p className="empty">{t('noItems')}</p>}
          <ol className="route">
            {byDay.map(([day, list]) => (
              <li key={day}>
                <h3>{fmtDate(day)}</h3>
                <ul>
                  {list.map((i) => (
                    <li key={i.id}>
                      <span className="stop-time">{i.startTime?.slice(0, 5) ?? ''}</span>
                      <span className="stop-title">{i.title}</span>
                      {i.estimatedCost && <span className="chip">~{fmtMoney(Number(i.estimatedCost), trip.currency)} {i.costIsEstimate && t('estimate')}</span>}
                      <button className="ghost small" onClick={() => delItem(i.id)}>{t('delete')}</button>
                    </li>
                  ))}
                </ul>
              </li>
            ))}
          </ol>
        </section>

        <section>
          <h2>{t('expenses')}</h2>
          {sum && (
            <dl className="summary">
              <div><dt>{t('planned')}</dt><dd>{fmtMoney(sum.plannedEstimate.amount, sum.currency)}</dd></div>
              <div><dt>{t('spent')}</dt><dd>{fmtMoney(sum.spent.amount, sum.currency)}</dd></div>
              {sum.remaining !== null && <div><dt>{t('remaining')}</dt><dd className={sum.remaining < 0 ? 'neg' : ''}>{fmtMoney(sum.remaining, sum.currency)}</dd></div>}
            </dl>
          )}
          <p className="muted small-text">{t('estimateNote')}</p>
          <form onSubmit={addExpense} className="card stack">
            <div className="row">
              <label>{t('amount')} ({trip.currency})<input name="amount" type="number" min={0} step="0.01" required /></label>
              <label>{t('day')}<input name="date" type="date" required /></label>
            </div>
            <label>{t('category')}<input name="category" maxLength={40} /></label>
            <button className="primary">{t('addExpense')}</button>
          </form>
          {expenses.length === 0 && <p className="empty">{t('noExpenses')}</p>}
          <ul className="ledger">
            {expenses.map((x) => (
              <li key={x.id}>
                <span>{fmtDate(x.spentAt)} · {x.category}</span>
                <strong>{fmtMoney(Number(x.amount), x.currency.trim())}</strong>
                <button className="ghost small" onClick={() => delExpense(x.id)}>{t('delete')}</button>
              </li>
            ))}
          </ul>
        </section>
      </div>
      {err && <p role="alert" className="error">{t('error')}</p>}
    </>
  );
}
