import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Navigate, Route, Routes } from 'react-router-dom';
import { api, setToken, tryRefresh } from './api';
import { applyLang, Lang, LANGS } from './i18n';
import Auth from './pages/Auth';
import TripDetail from './pages/TripDetail';
import Trips from './pages/Trips';

export default function App() {
  const { t, i18n } = useTranslation();
  const [ready, setReady] = useState(false);
  const [authed, setAuthed] = useState(false);

  useEffect(() => { tryRefresh().then((ok) => { setAuthed(ok); setReady(true); }); }, []);

  const logout = async () => { await api('/auth/logout', { method: 'POST', body: '{}' }).catch(() => {}); setToken(null); setAuthed(false); };
  if (!ready) return null;

  return (
    <>
      <header className="bar">
        <a className="brand" href="/">
          <svg width="28" height="28" viewBox="0 0 512 512" aria-hidden="true"><rect width="512" height="512" rx="112" fill="#0B5C7A" /><path d="M120 360 C 190 360 190 240 256 240 S 322 152 392 152" fill="none" stroke="#FFB703" strokeWidth="34" strokeLinecap="round" /></svg>
          EuroPath Pro
        </a>
        <div className="bar-actions">
          <label className="visually-hidden" htmlFor="lang">{t('language')}</label>
          <select id="lang" value={i18n.language} onChange={(e) => applyLang(e.target.value as Lang)}>
            {Object.entries(LANGS).map(([k, v]) => <option key={k} value={k}>{v.lang}</option>)}
          </select>
          {authed && <button className="ghost" onClick={logout}>{t('logout')}</button>}
        </div>
      </header>
      <main>
        <Routes>
          <Route path="/" element={authed ? <Trips /> : <Auth onAuthed={() => setAuthed(true)} />} />
          <Route path="/trips/:id" element={authed ? <TripDetail /> : <Navigate to="/" />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>
    </>
  );
}
