import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import ar from './locales/ar.json';
import de from './locales/de.json';
import en from './locales/en.json';
import es from './locales/es.json';
import fa from './locales/fa.json';
import fr from './locales/fr.json';
import it from './locales/it.json';

/** Add a language: drop locales/xx.json, import it here, add to RTL if needed. */
export const LANGS = { en, fr, de, es, it, fa, ar } as const;
export type Lang = keyof typeof LANGS;
const RTL: Lang[] = ['fa', 'ar'];

const saved = localStorage.getItem('lang') as Lang | null;
const browser = navigator.language.slice(0, 2) as Lang;
const initial: Lang = saved && saved in LANGS ? saved : browser in LANGS ? browser : 'en';

i18n.use(initReactI18next).init({
  resources: Object.fromEntries(Object.entries(LANGS).map(([k, v]) => [k, { translation: v }])),
  lng: initial,
  fallbackLng: 'en',
  interpolation: { escapeValue: false },
});

export function applyLang(lang: Lang) {
  i18n.changeLanguage(lang);
  localStorage.setItem('lang', lang);
  document.documentElement.lang = lang;
  document.documentElement.dir = RTL.includes(lang) ? 'rtl' : 'ltr';
}
applyLang(initial);

export const fmtMoney = (n: number, currency: string) =>
  new Intl.NumberFormat(i18n.language, { style: 'currency', currency }).format(n);
export const fmtDate = (iso: string) =>
  new Intl.DateTimeFormat(i18n.language, { dateStyle: 'medium', timeZone: 'UTC' }).format(new Date(iso));
export default i18n;
