// Access token lives in memory only. The refresh token is an httpOnly cookie managed by the server.
let accessToken: string | null = null;
export const setToken = (t: string | null) => { accessToken = t; };
export const hasToken = () => !!accessToken;

const BASE = '/api';

async function raw(path: string, init: RequestInit = {}) {
  return fetch(BASE + path, {
    ...init,
    credentials: 'include',
    headers: {
      'content-type': 'application/json',
      ...(accessToken ? { authorization: `Bearer ${accessToken}` } : {}),
      ...init.headers,
    },
  });
}

export async function tryRefresh(): Promise<boolean> {
  const r = await raw('/auth/refresh', { method: 'POST', body: '{}' });
  if (!r.ok) { setToken(null); return false; }
  setToken((await r.json()).accessToken);
  return true;
}

export async function api<T = unknown>(path: string, init: RequestInit = {}): Promise<T> {
  let r = await raw(path, init);
  if (r.status === 401 && !path.startsWith('/auth/') && (await tryRefresh())) r = await raw(path, init);
  if (!r.ok) throw new Error(String(r.status));
  return r.status === 204 ? (undefined as T) : r.json();
}

export interface Trip { id: string; title: string; destination: string; startDate: string; endDate: string; currency: string; travelers: number; budget: string | null }
export interface Item { id: string; day: string; startTime: string | null; title: string; kind: string; estimatedCost: string | null; costIsEstimate: boolean }
export interface Expense { id: string; amount: string; currency: string; category: string; note: string | null; spentAt: string }
export interface Summary { currency: string; budget: number | null; plannedEstimate: { amount: number }; spent: { amount: number }; remaining: number | null }
