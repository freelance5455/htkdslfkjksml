// Android (and later iOS) shell around the same web build. Run: npm run android:init && npm run android:sync
const config = {
  appId: 'eu.europath.app',
  appName: 'EuroPath Pro',
  webDir: 'dist',
  server: { androidScheme: 'https' },
};
export default config;
