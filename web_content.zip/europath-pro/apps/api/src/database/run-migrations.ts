import { makeDataSource } from './data-source';

(async () => {
  const ds = makeDataSource(process.env.DATABASE_URL!);
  await ds.initialize();
  const ran = await ds.runMigrations();
  console.log(`Migrations applied: ${ran.map((m) => m.name).join(', ') || 'none'}`);
  await ds.destroy();
})().catch((e) => { console.error(e); process.exit(1); });
