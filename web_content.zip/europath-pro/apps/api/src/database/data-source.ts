import { DataSource } from 'typeorm';
import * as E from './entities';
import { Init1700000000000 } from './migrations/1700000000000-init';

export const entities = [E.UserEntity, E.RefreshTokenEntity, E.TripEntity, E.ItineraryItemEntity, E.ExpenseEntity];
export const migrations = [Init1700000000000];

export const makeDataSource = (url: string) =>
  new DataSource({ type: 'postgres', url, entities, migrations, synchronize: false });
