import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Entity('users')
export class UserEntity {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index({ unique: true }) @Column({ type: 'citext' }) email: string;
  @Column({ name: 'password_hash' }) passwordHash: string;
  @Column({ name: 'display_name', type: 'text', nullable: true }) displayName: string | null;
  @Column({ default: 'en' }) locale: string;
  @Column({ default: 'EUR' }) currency: string;
  @Column({ default: 'user' }) role: 'user' | 'admin' | 'support';
  @Column({ default: 'FREE' }) plan: 'FREE' | 'PRO' | 'TRAVEL_PLUS';
  @Column({ name: 'consent_at', type: 'timestamptz', nullable: true }) consentAt: Date | null;
  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' }) createdAt: Date;
  @Column({ name: 'deleted_at', type: 'timestamptz', nullable: true }) deletedAt: Date | null;
}

@Entity('refresh_tokens')
export class RefreshTokenEntity {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column({ name: 'user_id', type: 'uuid' }) userId: string;
  @Index() @Column({ name: 'family_id', type: 'uuid' }) familyId: string;
  @Index({ unique: true }) @Column({ name: 'token_hash' }) tokenHash: string;
  @Column({ name: 'expires_at', type: 'timestamptz' }) expiresAt: Date;
  @Column({ name: 'revoked_at', type: 'timestamptz', nullable: true }) revokedAt: Date | null;
  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' }) createdAt: Date;
}

@Entity('trips')
export class TripEntity {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column({ name: 'owner_id', type: 'uuid' }) ownerId: string;
  @Column() title: string;
  @Column() destination: string;
  @Column({ name: 'start_date', type: 'date' }) startDate: string;
  @Column({ name: 'end_date', type: 'date' }) endDate: string;
  @Column({ length: 3, default: 'EUR' }) currency: string;
  @Column({ type: 'int', default: 1 }) travelers: number;
  @Column({ type: 'numeric', precision: 12, scale: 2, nullable: true }) budget: string | null;
  @Column({ default: 'active' }) status: 'active' | 'archived';
  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' }) createdAt: Date;
}

@Entity('itinerary_items')
export class ItineraryItemEntity {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column({ name: 'trip_id', type: 'uuid' }) tripId: string;
  @Column({ type: 'date' }) day: string;
  @Column({ name: 'start_time', type: 'time', nullable: true }) startTime: string | null;
  @Column() title: string;
  @Column({ type: 'text', nullable: true }) notes: string | null;
  @Column({ default: 'activity' }) kind: 'activity' | 'transport' | 'stay' | 'meal';
  @Column({ name: 'place_id', type: 'uuid', nullable: true }) placeId: string | null;
  @Column({ name: 'estimated_cost', type: 'numeric', precision: 12, scale: 2, nullable: true }) estimatedCost: string | null;
  /** Data-integrity rule: costs are estimates unless confirmed by a provider. */
  @Column({ name: 'cost_is_estimate', default: true }) costIsEstimate: boolean;
  @Column({ name: 'cost_source', type: 'text', nullable: true }) costSource: string | null;
  @Column({ type: 'int', default: 0 }) position: number;
}

@Entity('expenses')
export class ExpenseEntity {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index() @Column({ name: 'trip_id', type: 'uuid' }) tripId: string;
  @Column({ name: 'paid_by', type: 'uuid' }) paidBy: string;
  @Column({ type: 'numeric', precision: 12, scale: 2 }) amount: string;
  @Column({ length: 3 }) currency: string;
  @Column({ default: 'other' }) category: string;
  @Column({ type: 'text', nullable: true }) note: string | null;
  @Column({ name: 'spent_at', type: 'date' }) spentAt: string;
}
