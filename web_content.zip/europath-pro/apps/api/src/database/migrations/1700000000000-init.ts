import { MigrationInterface, QueryRunner } from 'typeorm';

export class Init1700000000000 implements MigrationInterface {
  name = 'Init1700000000000';

  async up(q: QueryRunner): Promise<void> {
    await q.query(`CREATE EXTENSION IF NOT EXISTS postgis`);
    await q.query(`CREATE EXTENSION IF NOT EXISTS citext`);
    await q.query(`CREATE EXTENSION IF NOT EXISTS "uuid-ossp"`);
    await q.query(`CREATE EXTENSION IF NOT EXISTS pg_trgm`);

    await q.query(`CREATE TABLE users (
      id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
      email citext NOT NULL UNIQUE,
      password_hash text NOT NULL,
      display_name text,
      locale text NOT NULL DEFAULT 'en',
      currency text NOT NULL DEFAULT 'EUR',
      role text NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin','support')),
      plan text NOT NULL DEFAULT 'FREE' CHECK (plan IN ('FREE','PRO','TRAVEL_PLUS')),
      consent_at timestamptz,
      created_at timestamptz NOT NULL DEFAULT now(),
      deleted_at timestamptz
    )`);

    await q.query(`CREATE TABLE refresh_tokens (
      id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
      user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      family_id uuid NOT NULL,
      token_hash text NOT NULL UNIQUE,
      expires_at timestamptz NOT NULL,
      revoked_at timestamptz,
      created_at timestamptz NOT NULL DEFAULT now()
    )`);
    await q.query(`CREATE INDEX ON refresh_tokens(user_id)`);
    await q.query(`CREATE INDEX ON refresh_tokens(family_id)`);

    await q.query(`CREATE TABLE trips (
      id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
      owner_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title text NOT NULL,
      destination text NOT NULL,
      start_date date NOT NULL,
      end_date date NOT NULL CHECK (end_date >= start_date),
      currency char(3) NOT NULL DEFAULT 'EUR',
      travelers int NOT NULL DEFAULT 1 CHECK (travelers BETWEEN 1 AND 50),
      budget numeric(12,2),
      status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
      created_at timestamptz NOT NULL DEFAULT now()
    )`);
    await q.query(`CREATE INDEX ON trips(owner_id)`);

    await q.query(`CREATE TABLE places (
      id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
      name text NOT NULL,
      category text NOT NULL,
      country_code char(2) NOT NULL,
      city text,
      location geography(Point,4326) NOT NULL,
      accessible boolean NOT NULL DEFAULT false,
      family_friendly boolean NOT NULL DEFAULT false,
      source text NOT NULL,
      source_url text,
      updated_at timestamptz NOT NULL DEFAULT now()
    )`);
    await q.query(`CREATE INDEX places_location_gix ON places USING GIST (location)`);
    await q.query(`CREATE INDEX places_name_trgm ON places USING GIN (name gin_trgm_ops)`);

    await q.query(`CREATE TABLE itinerary_items (
      id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
      trip_id uuid NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
      day date NOT NULL,
      start_time time,
      title text NOT NULL,
      notes text,
      kind text NOT NULL DEFAULT 'activity' CHECK (kind IN ('activity','transport','stay','meal')),
      place_id uuid REFERENCES places(id) ON DELETE SET NULL,
      estimated_cost numeric(12,2),
      cost_is_estimate boolean NOT NULL DEFAULT true,
      cost_source text,
      position int NOT NULL DEFAULT 0
    )`);
    await q.query(`CREATE INDEX ON itinerary_items(trip_id, day, position)`);

    await q.query(`CREATE TABLE expenses (
      id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
      trip_id uuid NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
      paid_by uuid NOT NULL REFERENCES users(id),
      amount numeric(12,2) NOT NULL CHECK (amount >= 0),
      currency char(3) NOT NULL,
      category text NOT NULL DEFAULT 'other',
      note text,
      spent_at date NOT NULL
    )`);
    await q.query(`CREATE INDEX ON expenses(trip_id)`);

    await q.query(`CREATE TABLE ai_usage (
      user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      month char(7) NOT NULL,
      requests int NOT NULL DEFAULT 0,
      input_tokens int NOT NULL DEFAULT 0,
      output_tokens int NOT NULL DEFAULT 0,
      PRIMARY KEY (user_id, month)
    )`);

    await q.query(`CREATE TABLE audit_logs (
      id bigserial PRIMARY KEY,
      user_id uuid,
      action text NOT NULL,
      entity text,
      entity_id text,
      ip text,
      created_at timestamptz NOT NULL DEFAULT now()
    )`);
    await q.query(`CREATE INDEX ON audit_logs(user_id, created_at DESC)`);
  }

  async down(q: QueryRunner): Promise<void> {
    for (const t of ['audit_logs','ai_usage','expenses','itinerary_items','places','trips','refresh_tokens','users'])
      await q.query(`DROP TABLE IF EXISTS ${t} CASCADE`);
  }
}
