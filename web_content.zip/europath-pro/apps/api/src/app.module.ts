import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_GUARD } from '@nestjs/core';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { TypeOrmModule } from '@nestjs/typeorm';
import { JwtAuthGuard, RolesGuard } from './common/guards';
import { PlanGuard } from './common/plan';
import { validateEnv } from './config/env';
import { entities } from './database/data-source';
import { AiModule } from './modules/ai/ai.module';
import { AuditModule } from './modules/audit/audit.module';
import { AuthModule } from './modules/auth/auth.module';
import { BudgetModule } from './modules/budget/budget.module';
import { DestinationsModule } from './modules/destinations/destinations.module';
import { HealthModule } from './modules/health/health.module';
import { PlansModule } from './modules/plans/plans.module';
import { ProvidersModule } from './modules/providers/providers.module';
import { TripsModule } from './modules/trips/trips.module';
import { UsersModule } from './modules/users/users.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, validate: validateEnv }),
    TypeOrmModule.forRoot({ type: 'postgres', url: process.env.DATABASE_URL, entities, synchronize: false }),
    ThrottlerModule.forRoot([{ ttl: 60_000, limit: 120 }]),
    AuditModule, ProvidersModule, AuthModule, UsersModule, PlansModule, TripsModule,
    BudgetModule, DestinationsModule, AiModule, HealthModule,
  ],
  providers: [
    { provide: APP_GUARD, useClass: ThrottlerGuard },
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    { provide: APP_GUARD, useClass: RolesGuard },
    { provide: APP_GUARD, useClass: PlanGuard },
  ],
})
export class AppModule {}
