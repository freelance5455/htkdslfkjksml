import { Injectable } from '@nestjs/common';
import { DataSource } from 'typeorm';

@Injectable()
export class AuditService {
  constructor(private ds: DataSource) {}
  async log(userId: string | null, action: string, entity?: string, entityId?: string, ip?: string) {
    await this.ds.query(
      `INSERT INTO audit_logs (user_id, action, entity, entity_id, ip) VALUES ($1,$2,$3,$4,$5)`,
      [userId, action, entity ?? null, entityId ?? null, ip ?? null],
    );
  }
}
