import { Controller, Get } from '@nestjs/common';
import { Public } from '../../common/decorators';
import { PLAN_LIMITS } from './plan-limits';

@Controller('plans')
export class PlansController {
  /** Public plan catalogue. Prices are hypotheses until validated. */
  @Public() @Get()
  list() {
    const prices = { FREE: 0, PRO: 7.99, TRAVEL_PLUS: 14.99 } as const;
    return (Object.keys(PLAN_LIMITS) as (keyof typeof PLAN_LIMITS)[]).map((plan) => ({
      plan,
      monthlyPriceEur: prices[plan],
      priceIsHypothesis: true,
      limits: Object.fromEntries(Object.entries(PLAN_LIMITS[plan]).map(([k, v]) => [k, v === Infinity ? null : v])),
    }));
  }
}
