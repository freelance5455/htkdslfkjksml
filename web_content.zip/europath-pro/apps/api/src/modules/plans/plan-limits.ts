import { Plan } from '../../common/decorators';

/** Single source of truth for entitlements. Validate before commercial launch. */
export interface PlanLimits {
  activeTrips: number;
  savedPlaces: number;
  aiRequestsPerMonth: number;
  offlineMaps: boolean;
  groupTrips: boolean;
}

export const PLAN_LIMITS: Record<Plan, PlanLimits> = {
  FREE:        { activeTrips: 1,        savedPlaces: 20,       aiRequestsPerMonth: 0,   offlineMaps: false, groupTrips: false },
  PRO:         { activeTrips: Infinity, savedPlaces: Infinity, aiRequestsPerMonth: 100, offlineMaps: true,  groupTrips: false },
  TRAVEL_PLUS: { activeTrips: Infinity, savedPlaces: Infinity, aiRequestsPerMonth: 500, offlineMaps: true,  groupTrips: true  },
};
