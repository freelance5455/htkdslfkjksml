import { Body, Controller, Delete, Get, HttpCode, Ip, Patch } from '@nestjs/common';
import { IsIn, IsOptional, IsString, Length, MaxLength } from 'class-validator';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import { AuthUser, CurrentUser } from '../../common/decorators';
import { AuditService } from '../audit/audit.service';
import { LOCALES } from '../auth/dto/auth.dto';

class UpdateProfileDto {
  @IsOptional() @IsString() @MaxLength(80) displayName?: string;
  @IsOptional() @IsIn(LOCALES as unknown as string[]) locale?: string;
  @IsOptional() @IsString() @Length(3, 3) currency?: string;
}

@Controller('users/me')
export class UsersController {
  constructor(@InjectDataSource() private ds: DataSource, private audit: AuditService) {}

  @Get()
  async me(@CurrentUser() u: AuthUser) {
    const [row] = await this.ds.query(
      `SELECT id, email, display_name AS "displayName", locale, currency, plan, role FROM users WHERE id=$1`, [u.id]);
    return row;
  }

  @Patch()
  async update(@CurrentUser() u: AuthUser, @Body() dto: UpdateProfileDto) {
    await this.ds.query(
      `UPDATE users SET display_name=COALESCE($2,display_name), locale=COALESCE($3,locale), currency=COALESCE($4,currency) WHERE id=$1`,
      [u.id, dto.displayName ?? null, dto.locale ?? null, dto.currency?.toUpperCase() ?? null]);
    return this.me(u);
  }

  /** GDPR Art. 20 — portable export of everything we hold on the user. */
  @Get('export')
  async export(@CurrentUser() u: AuthUser, @Ip() ip: string) {
    const q = (sql: string) => this.ds.query(sql, [u.id]);
    const data = {
      exportedAt: new Date().toISOString(),
      profile: (await q(`SELECT id,email,display_name,locale,currency,plan,consent_at,created_at FROM users WHERE id=$1`))[0],
      trips: await q(`SELECT * FROM trips WHERE owner_id=$1`),
      itineraryItems: await q(`SELECT i.* FROM itinerary_items i JOIN trips t ON t.id=i.trip_id WHERE t.owner_id=$1`),
      expenses: await q(`SELECT e.* FROM expenses e JOIN trips t ON t.id=e.trip_id WHERE t.owner_id=$1`),
    };
    await this.audit.log(u.id, 'user.export', 'user', u.id, ip);
    return data;
  }

  /** GDPR Art. 17 — permanent erasure; related rows cascade. Audit entry is kept without personal data. */
  @Delete() @HttpCode(204)
  async remove(@CurrentUser() u: AuthUser, @Ip() ip: string) {
    await this.audit.log(null, 'user.deleted', 'user', u.id, undefined);
    await this.ds.query(`DELETE FROM users WHERE id=$1`, [u.id]);
  }
}
