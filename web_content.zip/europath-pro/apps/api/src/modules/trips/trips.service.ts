import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AuthUser } from '../../common/decorators';
import { ItineraryItemEntity, TripEntity } from '../../database/entities';
import { PLAN_LIMITS } from '../plans/plan-limits';
import { CreateTripDto, ItemDto, UpdateTripDto } from './dto/trip.dto';

@Injectable()
export class TripsService {
  constructor(
    @InjectRepository(TripEntity) private trips: Repository<TripEntity>,
    @InjectRepository(ItineraryItemEntity) private items: Repository<ItineraryItemEntity>,
  ) {}

  /**
   * Ownership check used by EVERY private trip route (and by the budget module).
   * Returns 404 — not 403 — so IDs of other users' trips can't be probed.
   */
  async findOwned(tripId: string, userId: string): Promise<TripEntity> {
    const trip = await this.trips.findOneBy({ id: tripId, ownerId: userId });
    if (!trip) throw new NotFoundException('Trip not found');
    return trip;
  }

  list(userId: string) {
    return this.trips.find({ where: { ownerId: userId }, order: { startDate: 'ASC' } });
  }

  async create(user: AuthUser, dto: CreateTripDto) {
    if (dto.endDate < dto.startDate) throw new BadRequestException('endDate must be on or after startDate');
    const limit = PLAN_LIMITS[user.plan].activeTrips;
    const active = await this.trips.countBy({ ownerId: user.id, status: 'active' });
    if (active >= limit)
      throw new ForbiddenException(`Your plan allows ${limit} active trip(s). Archive one or upgrade to Pro.`);
    return this.trips.save(
      this.trips.create({
        ownerId: user.id,
        title: dto.title,
        destination: dto.destination,
        startDate: dto.startDate,
        endDate: dto.endDate,
        currency: (dto.currency ?? 'EUR').toUpperCase(),
        travelers: dto.travelers ?? 1,
        budget: dto.budget != null ? String(dto.budget) : null,
      }),
    );
  }

  async update(user: AuthUser, id: string, dto: UpdateTripDto) {
    const trip = await this.findOwned(id, user.id);
    if (dto.status === 'active' && trip.status === 'archived') {
      const active = await this.trips.countBy({ ownerId: user.id, status: 'active' });
      if (active >= PLAN_LIMITS[user.plan].activeTrips) throw new ForbiddenException('Active trip limit reached for your plan');
    }
    const { budget, ...rest } = dto;
    Object.assign(trip, rest);
    if (budget !== undefined) trip.budget = String(budget);
    if (trip.endDate < trip.startDate) throw new BadRequestException('endDate must be on or after startDate');
    return this.trips.save(trip);
  }

  async remove(userId: string, id: string) {
    await this.findOwned(id, userId);
    await this.trips.delete({ id, ownerId: userId });
  }

  // ---- itinerary ----
  async itinerary(userId: string, tripId: string) {
    await this.findOwned(tripId, userId);
    return this.items.find({ where: { tripId }, order: { day: 'ASC', position: 'ASC', startTime: 'ASC' } });
  }

  async addItem(userId: string, tripId: string, dto: ItemDto) {
    const trip = await this.findOwned(tripId, userId);
    if (dto.day < trip.startDate || dto.day > trip.endDate) throw new BadRequestException('Day is outside the trip dates');
    return this.items.save(
      this.items.create({
        tripId,
        day: dto.day,
        startTime: dto.startTime ?? null,
        title: dto.title,
        notes: dto.notes ?? null,
        kind: dto.kind ?? 'activity',
        placeId: dto.placeId ?? null,
        estimatedCost: dto.estimatedCost != null ? String(dto.estimatedCost) : null,
        costIsEstimate: true, // only a provider integration may ever set this to false
        position: dto.position ?? 0,
      }),
    );
  }

  async removeItem(userId: string, tripId: string, itemId: string) {
    await this.findOwned(tripId, userId);
    const res = await this.items.delete({ id: itemId, tripId });
    if (!res.affected) throw new NotFoundException('Item not found');
  }
}
