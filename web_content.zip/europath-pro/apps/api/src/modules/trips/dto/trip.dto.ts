import { Type } from 'class-transformer';
import { IsDateString, IsIn, IsInt, IsNumber, IsOptional, IsString, IsUUID, Length, Matches, Max, MaxLength, Min } from 'class-validator';

export class CreateTripDto {
  @IsString() @Length(1, 120) title: string;
  @IsString() @Length(1, 120) destination: string;
  @IsDateString() startDate: string;
  @IsDateString() endDate: string;
  @IsOptional() @IsString() @Length(3, 3) currency?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(50) travelers?: number;
  @IsOptional() @Type(() => Number) @IsNumber() @Min(0) budget?: number;
}

export class UpdateTripDto {
  @IsOptional() @IsString() @Length(1, 120) title?: string;
  @IsOptional() @IsString() @Length(1, 120) destination?: string;
  @IsOptional() @IsDateString() startDate?: string;
  @IsOptional() @IsDateString() endDate?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(50) travelers?: number;
  @IsOptional() @Type(() => Number) @IsNumber() @Min(0) budget?: number;
  @IsOptional() @IsIn(['active', 'archived']) status?: 'active' | 'archived';
}

export class ItemDto {
  @IsDateString() day: string;
  @IsOptional() @Matches(/^([01]\d|2[0-3]):[0-5]\d$/) startTime?: string;
  @IsString() @Length(1, 160) title: string;
  @IsOptional() @IsString() @MaxLength(2000) notes?: string;
  @IsOptional() @IsIn(['activity', 'transport', 'stay', 'meal']) kind?: 'activity' | 'transport' | 'stay' | 'meal';
  @IsOptional() @IsUUID() placeId?: string;
  @IsOptional() @Type(() => Number) @IsNumber() @Min(0) estimatedCost?: number;
  @IsOptional() @Type(() => Number) @IsInt() @Min(0) position?: number;
}
