import { Injectable, Logger } from '@nestjs/common';
import { ProviderKind, ProviderResult, TravelProvider } from './provider.types';

interface Breaker { failures: number; openUntil: number }

/**
 * Calls providers in priority order with timeout, bounded retry (exponential backoff)
 * and a simple circuit breaker, then falls back to the next provider.
 * If all fail the caller gets an explicit "unavailable" — never invented data.
 */
@Injectable()
export class ProviderRegistry {
  private log = new Logger('Providers');
  private providers = new Map<ProviderKind, TravelProvider[]>();
  private breakers = new Map<string, Breaker>();

  constructor(
    private opts = { timeoutMs: 8000, retries: 2, backoffMs: 300, breakerThreshold: 5, breakerCooldownMs: 60_000 },
  ) {}

  register(p: TravelProvider) {
    this.providers.set(p.kind, [...(this.providers.get(p.kind) ?? []), p]);
  }

  async search<Q, R>(kind: ProviderKind, query: Q): Promise<ProviderResult<R>> {
    const list = (this.providers.get(kind) ?? []) as TravelProvider<Q, R>[];
    const tried: string[] = [];
    for (const p of list) {
      const b = this.breakers.get(p.name) ?? { failures: 0, openUntil: 0 };
      if (b.openUntil > Date.now()) continue;
      tried.push(p.name);
      for (let attempt = 0; attempt <= this.opts.retries; attempt++) {
        const ctl = new AbortController();
        const timer = setTimeout(() => ctl.abort(), this.opts.timeoutMs);
        try {
          const result = await p.search(query, ctl.signal);
          this.breakers.set(p.name, { failures: 0, openUntil: 0 });
          return { ok: true, result };
        } catch (e) {
          this.log.warn(`${p.name} attempt ${attempt + 1} failed: ${(e as Error).message}`);
          if (attempt < this.opts.retries) await new Promise((r) => setTimeout(r, this.opts.backoffMs * 2 ** attempt));
        } finally {
          clearTimeout(timer);
        }
      }
      b.failures++;
      if (b.failures >= this.opts.breakerThreshold) b.openUntil = Date.now() + this.opts.breakerCooldownMs;
      this.breakers.set(p.name, b);
    }
    return { ok: false, unavailable: true, reason: list.length ? 'All providers failed' : 'No provider configured', triedProviders: tried };
  }
}
