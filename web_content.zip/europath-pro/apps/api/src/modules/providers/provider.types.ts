/**
 * Provider abstraction for flights, trains, buses, hotels and restaurants (Phase 3).
 * Rule: a result may only carry a price if it came from an authorised provider, and it must
 * always say where and when it was fetched. Estimates are labelled as such.
 */
export type ProviderKind = 'flights' | 'trains' | 'ground' | 'hotels' | 'restaurants';

export interface Sourced<T> {
  data: T;
  source: string;        // provider name
  fetchedAt: string;     // ISO timestamp
  isEstimate: boolean;   // false only for confirmed provider prices
  bookingUrl?: string;   // external link — NEVER a completed reservation
}

export interface TravelProvider<Q = unknown, R = unknown> {
  readonly name: string;
  readonly kind: ProviderKind;
  search(query: Q, signal: AbortSignal): Promise<Sourced<R>>;
}

export type ProviderResult<R> =
  | { ok: true; result: Sourced<R> }
  | { ok: false; unavailable: true; reason: string; triedProviders: string[] };
