import { Global, Module } from '@nestjs/common';
import { ProviderRegistry } from './provider-registry';

/** Register concrete providers here once contracts/API keys exist (Phase 3). */
@Global()
@Module({ providers: [{ provide: ProviderRegistry, useFactory: () => new ProviderRegistry() }], exports: [ProviderRegistry] })
export class ProvidersModule {}
