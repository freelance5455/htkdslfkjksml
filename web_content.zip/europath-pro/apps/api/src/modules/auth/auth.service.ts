import { BadRequestException, ConflictException, Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import * as argon2 from 'argon2';
import { createHash, randomBytes, randomUUID } from 'crypto';
import { IsNull, Repository } from 'typeorm';
import { RefreshTokenEntity, UserEntity } from '../../database/entities';
import { AuditService } from '../audit/audit.service';
import { LoginDto, RegisterDto } from './dto/auth.dto';

export const sha256 = (s: string) => createHash('sha256').update(s).digest('hex');

export interface Tokens { accessToken: string; refreshToken: string; refreshExpiresAt: Date }

@Injectable()
export class AuthService {
  // Constant-time-ish defence against user enumeration on login.
  private dummyHash: Promise<string>;

  constructor(
    @InjectRepository(UserEntity) private users: Repository<UserEntity>,
    @InjectRepository(RefreshTokenEntity) private tokens: Repository<RefreshTokenEntity>,
    private jwt: JwtService,
    private cfg: ConfigService,
    private audit: AuditService,
  ) {
    this.dummyHash = argon2.hash('dummy-password-for-timing', { type: argon2.argon2id });
  }

  async register(dto: RegisterDto, ip?: string) {
    if (!dto.acceptTerms) throw new BadRequestException('You must accept the terms and privacy policy');
    const email = dto.email.trim().toLowerCase();
    if (await this.users.findOneBy({ email })) throw new ConflictException('Email already registered');
    const user = await this.users.save(
      this.users.create({
        email,
        passwordHash: await argon2.hash(dto.password, { type: argon2.argon2id }),
        displayName: dto.displayName ?? null,
        locale: dto.locale ?? 'en',
        consentAt: new Date(),
      }),
    );
    await this.audit.log(user.id, 'auth.register', 'user', user.id, ip);
    return { user: this.publicUser(user), tokens: await this.issue(user) };
  }

  async login(dto: LoginDto, ip?: string) {
    const user = await this.users.findOneBy({ email: dto.email.trim().toLowerCase(), deletedAt: IsNull() });
    const ok = await argon2.verify(user?.passwordHash ?? (await this.dummyHash), dto.password).catch(() => false);
    if (!user || !ok) {
      await this.audit.log(user?.id ?? null, 'auth.login_failed', 'user', user?.id, ip);
      throw new UnauthorizedException('Invalid email or password');
    }
    await this.audit.log(user.id, 'auth.login', 'user', user.id, ip);
    return { user: this.publicUser(user), tokens: await this.issue(user) };
  }

  /** Rotating refresh tokens with reuse detection: replaying an old token revokes the whole family. */
  async refresh(raw: string | undefined, ip?: string): Promise<Tokens> {
    if (!raw) throw new UnauthorizedException();
    const row = await this.tokens.findOneBy({ tokenHash: sha256(raw) });
    if (!row) throw new UnauthorizedException();
    if (row.revokedAt) {
      await this.tokens.update({ familyId: row.familyId, revokedAt: IsNull() }, { revokedAt: new Date() });
      await this.audit.log(row.userId, 'auth.refresh_reuse_detected', 'refresh_token', row.familyId, ip);
      throw new UnauthorizedException();
    }
    if (row.expiresAt < new Date()) throw new UnauthorizedException();
    const user = await this.users.findOneBy({ id: row.userId, deletedAt: IsNull() });
    if (!user) throw new UnauthorizedException();
    await this.tokens.update(row.id, { revokedAt: new Date() });
    return this.issue(user, row.familyId);
  }

  async logout(raw: string | undefined) {
    if (!raw) return;
    const row = await this.tokens.findOneBy({ tokenHash: sha256(raw) });
    if (row) await this.tokens.update({ familyId: row.familyId, revokedAt: IsNull() }, { revokedAt: new Date() });
  }

  private async issue(user: UserEntity, familyId: string = randomUUID()): Promise<Tokens> {
    const accessToken = await this.jwt.signAsync({ sub: user.id, role: user.role, plan: user.plan });
    const refreshToken = randomBytes(48).toString('base64url');
    const days = this.cfg.get<number>('REFRESH_TOKEN_TTL_DAYS', 30);
    const refreshExpiresAt = new Date(Date.now() + days * 86_400_000);
    await this.tokens.save(
      this.tokens.create({ userId: user.id, familyId, tokenHash: sha256(refreshToken), expiresAt: refreshExpiresAt, revokedAt: null }),
    );
    return { accessToken, refreshToken, refreshExpiresAt };
  }

  publicUser(u: UserEntity) {
    return { id: u.id, email: u.email, displayName: u.displayName, locale: u.locale, currency: u.currency, plan: u.plan, role: u.role };
  }
}
