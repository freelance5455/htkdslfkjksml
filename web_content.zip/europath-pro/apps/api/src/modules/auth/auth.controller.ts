import { Body, Controller, HttpCode, Ip, Post, Req, Res } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Throttle } from '@nestjs/throttler';
import { Request, Response } from 'express';
import { Public } from '../../common/decorators';
import { AuthService, Tokens } from './auth.service';
import { LoginDto, RefreshDto, RegisterDto } from './dto/auth.dto';

const COOKIE = 'ep_refresh';

@Controller('auth')
export class AuthController {
  constructor(private auth: AuthService, private cfg: ConfigService) {}

  private setCookie(res: Response, t: Tokens) {
    res.cookie(COOKIE, t.refreshToken, {
      httpOnly: true,
      secure: this.cfg.get('NODE_ENV') === 'production',
      sameSite: 'strict',
      expires: t.refreshExpiresAt,
      path: '/',
    });
  }

  @Public() @Throttle({ default: { limit: 5, ttl: 60_000 } }) @Post('register')
  async register(@Body() dto: RegisterDto, @Ip() ip: string, @Res({ passthrough: true }) res: Response) {
    const { user, tokens } = await this.auth.register(dto, ip);
    this.setCookie(res, tokens);
    return { user, accessToken: tokens.accessToken, refreshToken: tokens.refreshToken };
  }

  @Public() @Throttle({ default: { limit: 10, ttl: 60_000 } }) @HttpCode(200) @Post('login')
  async login(@Body() dto: LoginDto, @Ip() ip: string, @Res({ passthrough: true }) res: Response) {
    const { user, tokens } = await this.auth.login(dto, ip);
    this.setCookie(res, tokens);
    return { user, accessToken: tokens.accessToken, refreshToken: tokens.refreshToken };
  }

  /** Web uses the httpOnly cookie; native apps may send refreshToken in the body (store in Keychain/Keystore). */
  @Public() @Throttle({ default: { limit: 30, ttl: 60_000 } }) @HttpCode(200) @Post('refresh')
  async refresh(@Req() req: Request, @Body() body: RefreshDto, @Ip() ip: string, @Res({ passthrough: true }) res: Response) {
    const tokens = await this.auth.refresh(req.cookies?.[COOKIE] ?? body.refreshToken, ip);
    this.setCookie(res, tokens);
    return { accessToken: tokens.accessToken, refreshToken: tokens.refreshToken };
  }

  @Public() @HttpCode(204) @Post('logout')
  async logout(@Req() req: Request, @Body() body: RefreshDto, @Res({ passthrough: true }) res: Response) {
    await this.auth.logout(req.cookies?.[COOKIE] ?? body.refreshToken);
    res.clearCookie(COOKIE, { path: '/' });
  }
}
