import { IsBoolean, IsEmail, IsIn, IsOptional, IsString, Length, MaxLength } from 'class-validator';

export const LOCALES = ['en', 'fr', 'de', 'es', 'it', 'fa', 'ar'] as const;

export class RegisterDto {
  @IsEmail() @MaxLength(254) email: string;
  @IsString() @Length(10, 128) password: string;
  @IsOptional() @IsString() @MaxLength(80) displayName?: string;
  @IsOptional() @IsIn(LOCALES as unknown as string[]) locale?: string;
  /** GDPR: explicit consent to the privacy policy / terms. */
  @IsBoolean() acceptTerms: boolean;
}

export class LoginDto {
  @IsEmail() email: string;
  @IsString() @MaxLength(128) password: string;
}

export class RefreshDto {
  @IsOptional() @IsString() refreshToken?: string;
}
