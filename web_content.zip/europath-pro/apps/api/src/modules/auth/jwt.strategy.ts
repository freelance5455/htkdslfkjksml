import { Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PassportStrategy } from '@nestjs/passport';
import { InjectRepository } from '@nestjs/typeorm';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { IsNull, Repository } from 'typeorm';
import { AuthUser } from '../../common/decorators';
import { UserEntity } from '../../database/entities';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(cfg: ConfigService, @InjectRepository(UserEntity) private users: Repository<UserEntity>) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: cfg.getOrThrow<string>('JWT_ACCESS_SECRET'),
    });
  }
  /** Role and plan are re-read from the DB so entitlement changes apply immediately. */
  async validate(payload: { sub: string }): Promise<AuthUser> {
    const u = await this.users.findOneBy({ id: payload.sub, deletedAt: IsNull() });
    if (!u) throw new UnauthorizedException();
    return { id: u.id, role: u.role, plan: u.plan };
  }
}
