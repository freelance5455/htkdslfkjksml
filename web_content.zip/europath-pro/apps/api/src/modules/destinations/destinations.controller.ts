import { Controller, Get, Query } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { Transform, Type } from 'class-transformer';
import { IsBoolean, IsLatitude, IsLongitude, IsNumber, IsOptional, IsString, Max, MaxLength, Min } from 'class-validator';
import { DataSource } from 'typeorm';

const bool = () => Transform(({ value }) => value === 'true' || value === true);

class SearchPlacesDto {
  @IsOptional() @IsString() @MaxLength(80) q?: string;
  @IsOptional() @IsString() @MaxLength(40) category?: string;
  @IsOptional() @Type(() => Number) @IsLatitude() lat?: number;
  @IsOptional() @Type(() => Number) @IsLongitude() lng?: number;
  /** metres, capped to keep queries cheap */
  @IsOptional() @Type(() => Number) @IsNumber() @Min(100) @Max(100_000) radius?: number;
  @IsOptional() @bool() @IsBoolean() accessible?: boolean;
  @IsOptional() @bool() @IsBoolean() familyFriendly?: boolean;
}

@Controller('places')
export class DestinationsController {
  constructor(@InjectDataSource() private ds: DataSource) {}

  /** WGS84 geography search with distance, accessibility and family filters. Every row carries its data source. */
  @Get('search')
  async search(@Query() p: SearchPlacesDto) {
    const where: string[] = [];
    const args: unknown[] = [];
    const arg = (v: unknown) => { args.push(v); return `$${args.length}`; };
    let distance = 'NULL::float';

    if (p.lat != null && p.lng != null) {
      const pt = `ST_SetSRID(ST_MakePoint(${arg(p.lng)}, ${arg(p.lat)}),4326)::geography`;
      distance = `ST_Distance(location, ${pt})`;
      where.push(`ST_DWithin(location, ${pt}, ${arg(p.radius ?? 5000)})`);
    }
    if (p.q) where.push(`(name ILIKE ${arg('%' + p.q + '%')} OR city ILIKE ${arg('%' + p.q + '%')})`);
    if (p.category) where.push(`category = ${arg(p.category)}`);
    if (p.accessible) where.push(`accessible = true`);
    if (p.familyFriendly) where.push(`family_friendly = true`);

    return this.ds.query(
      `SELECT id, name, category, country_code AS "countryCode", city,
              ST_Y(location::geometry) AS lat, ST_X(location::geometry) AS lng,
              accessible, family_friendly AS "familyFriendly",
              source, source_url AS "sourceUrl", updated_at AS "updatedAt",
              ${distance} AS "distanceMetres"
         FROM places ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
        ORDER BY "distanceMetres" NULLS LAST, name LIMIT 50`,
      args,
    );
  }
}
