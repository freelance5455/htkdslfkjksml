import { Body, Controller, Get, Post } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { AuthUser, CurrentUser } from '../../common/decorators';
import { RequirePlan } from '../../common/plan';
import { AiService } from './ai.service';
import { PlanTripDto } from './plan-trip.dto';

@RequirePlan('PRO')
@Controller('ai')
export class AiController {
  constructor(private ai: AiService) {}

  @Throttle({ default: { limit: 5, ttl: 60_000 } }) @Post('itinerary')
  itinerary(@CurrentUser() u: AuthUser, @Body() dto: PlanTripDto) { return this.ai.planTrip(u, dto); }

  @Get('usage') usage(@CurrentUser() u: AuthUser) { return this.ai.usage(u); }
}
