import { Type } from 'class-transformer';
import { ArrayMaxSize, IsArray, IsDateString, IsIn, IsInt, IsNumber, IsOptional, IsString, Length, Max, MaxLength, Min } from 'class-validator';

export class PlanTripDto {
  @IsString() @Length(1, 120) destination: string;
  @IsDateString() startDate: string;
  @IsDateString() endDate: string;
  @IsOptional() @Type(() => Number) @IsNumber() @Min(0) budget?: number;
  @IsString() @Length(3, 3) currency: string;
  @Type(() => Number) @IsInt() @Min(1) @Max(50) travelers: number;
  @IsOptional() @IsArray() @ArrayMaxSize(10) @IsString({ each: true }) @MaxLength(40, { each: true }) interests?: string[];
  @IsOptional() @IsIn(['relaxed', 'balanced', 'packed']) pace?: 'relaxed' | 'balanced' | 'packed';
  @IsOptional() @IsString() @MaxLength(200) accommodation?: string;
  @IsOptional() @IsString() @MaxLength(300) mobilityNeeds?: string;
}
