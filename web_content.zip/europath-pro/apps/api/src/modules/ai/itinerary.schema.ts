export interface AiActivity {
  time?: string;
  title: string;
  kind?: 'activity' | 'transport' | 'stay' | 'meal';
  estimatedCost?: number | null;
  notes?: string;
}
export interface AiDay { date: string; summary?: string; activities: AiActivity[] }
export interface AiItinerary { days: AiDay[]; alternatives?: string[]; weatherNotes?: string[] }

export interface SafeItinerary extends AiItinerary {
  verified: false;
  warnings: string[];
}

/**
 * Post-processing guard. Whatever the model returns:
 *  - every cost is forced to be an estimate (never a confirmed price),
 *  - negative / absurd numbers are dropped,
 *  - booking/confirmation language is flagged,
 *  - the response is marked unverified until provider data validates it.
 */
export function sanitizeItinerary(raw: unknown): SafeItinerary {
  const warnings = [
    'AI suggestions are not verified against live provider data. Prices are rough estimates; schedules and availability must be checked before booking.',
  ];
  const input = (raw && typeof raw === 'object' ? raw : {}) as Partial<AiItinerary>;
  const days = Array.isArray(input.days) ? input.days : [];
  const bookingWords = /\b(booked|confirmed|reservation (is )?confirmed|ticket(s)? (is|are) reserved)\b/i;

  const cleanDays: AiDay[] = days.slice(0, 31).map((d) => ({
    date: String(d?.date ?? '').slice(0, 10),
    summary: typeof d?.summary === 'string' ? d.summary.slice(0, 500) : undefined,
    activities: (Array.isArray(d?.activities) ? d.activities : []).slice(0, 20).map((a) => {
      const cost = typeof a?.estimatedCost === 'number' && a.estimatedCost >= 0 && a.estimatedCost < 100_000 ? a.estimatedCost : null;
      const text = `${a?.title ?? ''} ${a?.notes ?? ''}`;
      if (bookingWords.test(text) && !warnings.some((w) => w.includes('booking language')))
        warnings.push('Some text used booking language. Nothing here has been booked or reserved.');
      return {
        time: typeof a?.time === 'string' && /^\d{2}:\d{2}$/.test(a.time) ? a.time : undefined,
        title: String(a?.title ?? 'Untitled').slice(0, 160),
        kind: (['activity', 'transport', 'stay', 'meal'] as const).includes(a?.kind as never) ? a.kind : 'activity',
        estimatedCost: cost,
        notes: typeof a?.notes === 'string' ? a.notes.slice(0, 500) : undefined,
      };
    }),
  }));
  if (!cleanDays.length) warnings.push('The model returned no usable itinerary. Please try again.');
  return {
    days: cleanDays,
    alternatives: Array.isArray(input.alternatives) ? input.alternatives.slice(0, 5).map((s) => String(s).slice(0, 300)) : [],
    weatherNotes: Array.isArray(input.weatherNotes) ? input.weatherNotes.slice(0, 5).map((s) => String(s).slice(0, 300)) : [],
    verified: false,
    warnings,
  };
}
