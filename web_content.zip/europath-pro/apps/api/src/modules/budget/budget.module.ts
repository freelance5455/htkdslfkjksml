import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ExpenseEntity } from '../../database/entities';
import { TripsModule } from '../trips/trips.module';
import { BudgetController } from './budget.controller';

@Module({ imports: [TypeOrmModule.forFeature([ExpenseEntity]), TripsModule], controllers: [BudgetController] })
export class BudgetModule {}
