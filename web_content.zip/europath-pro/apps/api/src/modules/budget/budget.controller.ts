import { Body, Controller, Delete, Get, HttpCode, Param, ParseUUIDPipe, Post } from '@nestjs/common';
import { InjectDataSource, InjectRepository } from '@nestjs/typeorm';
import { Type } from 'class-transformer';
import { IsDateString, IsNumber, IsOptional, IsString, Length, MaxLength, Min } from 'class-validator';
import { DataSource, Repository } from 'typeorm';
import { AuthUser, CurrentUser } from '../../common/decorators';
import { RequirePlan } from '../../common/plan';
import { ExpenseEntity } from '../../database/entities';
import { TripsService } from '../trips/trips.service';

class ExpenseDto {
  @Type(() => Number) @IsNumber({ maxDecimalPlaces: 2 }) @Min(0) amount: number;
  @IsOptional() @IsString() @Length(3, 3) currency?: string;
  @IsOptional() @IsString() @MaxLength(40) category?: string;
  @IsOptional() @IsString() @MaxLength(300) note?: string;
  @IsDateString() spentAt: string;
}

@Controller('trips/:tripId')
export class BudgetController {
  constructor(
    private trips: TripsService,
    @InjectRepository(ExpenseEntity) private expenses: Repository<ExpenseEntity>,
    @InjectDataSource() private ds: DataSource,
  ) {}

  @Get('expenses')
  async list(@CurrentUser() u: AuthUser, @Param('tripId', ParseUUIDPipe) tripId: string) {
    await this.trips.findOwned(tripId, u.id);
    return this.expenses.find({ where: { tripId }, order: { spentAt: 'DESC' } });
  }

  @Post('expenses')
  async add(@CurrentUser() u: AuthUser, @Param('tripId', ParseUUIDPipe) tripId: string, @Body() dto: ExpenseDto) {
    const trip = await this.trips.findOwned(tripId, u.id);
    return this.expenses.save(
      this.expenses.create({
        tripId, paidBy: u.id, amount: dto.amount.toFixed(2),
        currency: (dto.currency ?? trip.currency).toUpperCase(),
        category: dto.category ?? 'other', note: dto.note ?? null, spentAt: dto.spentAt,
      }),
    );
  }

  @Delete('expenses/:id') @HttpCode(204)
  async remove(@CurrentUser() u: AuthUser, @Param('tripId', ParseUUIDPipe) tripId: string, @Param('id', ParseUUIDPipe) id: string) {
    await this.trips.findOwned(tripId, u.id);
    await this.expenses.delete({ id, tripId });
  }

  /**
   * Planned (estimates) and actual (recorded) spending are reported separately and never mixed.
   * Totals are only summed for items in the trip currency; other currencies are listed untouched
   * until a sourced exchange-rate provider is wired in.
   */
  @Get('budget-summary')
  async summary(@CurrentUser() u: AuthUser, @Param('tripId', ParseUUIDPipe) tripId: string) {
    const trip = await this.trips.findOwned(tripId, u.id);
    const spent = await this.ds.query(
      `SELECT category, currency, SUM(amount)::float AS total FROM expenses WHERE trip_id=$1 GROUP BY category, currency ORDER BY total DESC`, [tripId]);
    const [{ planned }] = await this.ds.query(
      `SELECT COALESCE(SUM(estimated_cost),0)::float AS planned FROM itinerary_items WHERE trip_id=$1`, [tripId]);
    const spentInTripCurrency = spent.filter((s: any) => s.currency.trim() === trip.currency.trim()).reduce((a: number, s: any) => a + s.total, 0);
    return {
      currency: trip.currency,
      budget: trip.budget ? Number(trip.budget) : null,
      plannedEstimate: { amount: planned, isEstimate: true },
      spent: { amount: spentInTripCurrency, byCategory: spent },
      remaining: trip.budget ? Number(trip.budget) - spentInTripCurrency : null,
      note: 'Planned amounts are user or AI estimates, not confirmed prices.',
    };
  }

  /** Pro: CSV expense report. */
  @RequirePlan('PRO') @Get('expenses-report.csv')
  async report(@CurrentUser() u: AuthUser, @Param('tripId', ParseUUIDPipe) tripId: string) {
    await this.trips.findOwned(tripId, u.id);
    const rows = await this.expenses.find({ where: { tripId }, order: { spentAt: 'ASC' } });
    const esc = (s: string | null) => `"${(s ?? '').replace(/"/g, '""').replace(/^[=+\-@]/, "'$&")}"`;
    return ['date,category,amount,currency,note', ...rows.map((r) => [r.spentAt, esc(r.category), r.amount, r.currency, esc(r.note)].join(','))].join('\n');
  }
}
