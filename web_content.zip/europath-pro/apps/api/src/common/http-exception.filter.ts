import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';

/** Uniform error shape; never leaks stack traces or SQL details. */
@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  private log = new Logger('Errors');
  catch(e: unknown, host: ArgumentsHost) {
    const res = host.switchToHttp().getResponse();
    const status = e instanceof HttpException ? e.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR;
    if (status >= 500) this.log.error(e instanceof Error ? e.stack : String(e));
    const body = e instanceof HttpException ? e.getResponse() : null;
    res.status(status).json({
      statusCode: status,
      message: status >= 500 ? 'Internal server error' : (typeof body === 'object' && body ? (body as any).message : body),
      timestamp: new Date().toISOString(),
    });
  }
}
