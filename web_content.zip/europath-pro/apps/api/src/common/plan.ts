import { CanActivate, ExecutionContext, ForbiddenException, Injectable, SetMetadata } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Plan } from './decorators';

export const PLAN_RANK: Record<Plan, number> = { FREE: 0, PRO: 1, TRAVEL_PLUS: 2 };
export const REQUIRE_PLAN = 'requirePlan';
/** Gate a route by subscription tier. Entitlements are checked server-side only. */
export const RequirePlan = (min: Plan) => SetMetadata(REQUIRE_PLAN, min);

@Injectable()
export class PlanGuard implements CanActivate {
  constructor(private reflector: Reflector) {}
  canActivate(ctx: ExecutionContext): boolean {
    const min = this.reflector.getAllAndOverride<Plan>(REQUIRE_PLAN, [ctx.getHandler(), ctx.getClass()]);
    if (!min) return true;
    const user = ctx.switchToHttp().getRequest().user;
    if (user && PLAN_RANK[user.plan as Plan] >= PLAN_RANK[min]) return true;
    throw new ForbiddenException(`This feature requires the ${min} plan or higher`);
  }
}
