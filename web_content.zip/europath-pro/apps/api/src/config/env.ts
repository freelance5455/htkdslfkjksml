export interface Env {
  NODE_ENV: string;
  PORT: number;
  WEB_ORIGIN: string;
  DATABASE_URL: string;
  JWT_ACCESS_SECRET: string;
  ACCESS_TOKEN_TTL: string;
  REFRESH_TOKEN_TTL_DAYS: number;
  ANTHROPIC_API_KEY?: string;
  AI_MODEL: string;
  AI_MAX_OUTPUT_TOKENS: number;
}

/** Fail fast on missing or weak secrets. */
export function validateEnv(raw: Record<string, unknown>): Env {
  const need = (k: string) => {
    const v = raw[k];
    if (typeof v !== 'string' || !v) throw new Error(`Missing required env var: ${k}`);
    return v;
  };
  const secret = need('JWT_ACCESS_SECRET');
  if (secret.length < 32) throw new Error('JWT_ACCESS_SECRET must be at least 32 characters');
  if (raw.NODE_ENV === 'production' && secret.startsWith('change_me'))
    throw new Error('Refusing to start in production with a placeholder JWT secret');
  return {
    NODE_ENV: String(raw.NODE_ENV ?? 'development'),
    PORT: Number(raw.PORT ?? 3000),
    WEB_ORIGIN: need('WEB_ORIGIN'),
    DATABASE_URL: need('DATABASE_URL'),
    JWT_ACCESS_SECRET: secret,
    ACCESS_TOKEN_TTL: String(raw.ACCESS_TOKEN_TTL ?? '15m'),
    REFRESH_TOKEN_TTL_DAYS: Number(raw.REFRESH_TOKEN_TTL_DAYS ?? 30),
    ANTHROPIC_API_KEY: (raw.ANTHROPIC_API_KEY as string) || undefined,
    AI_MODEL: String(raw.AI_MODEL ?? 'claude-sonnet-5-5'),
    AI_MAX_OUTPUT_TOKENS: Number(raw.AI_MAX_OUTPUT_TOKENS ?? 1500),
  };
}
