import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import { AppModule } from './app.module';
import { AllExceptionsFilter } from './common/http-exception.filter';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const origin = process.env.WEB_ORIGIN!;
  const prod = process.env.NODE_ENV === 'production';

  (app.getHttpAdapter().getInstance() as any).set('trust proxy', 1);
  app.use(helmet());
  app.use(cookieParser());
  app.enableCors({ origin: origin.split(','), credentials: true });
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }));
  app.useGlobalFilters(new AllExceptionsFilter());
  app.enableShutdownHooks();

  if (!prod) {
    const doc = SwaggerModule.createDocument(app, new DocumentBuilder().setTitle('EuroPath Pro API').setVersion('0.1').addBearerAuth().build());
    SwaggerModule.setup('docs', app, doc);
  }
  await app.listen(Number(process.env.PORT ?? 3000), '0.0.0.0');
}
bootstrap();
