import { sanitizeItinerary } from '../src/modules/ai/itinerary.schema';

describe('AI output guard', () => {
  it('always marks output unverified and keeps costs as estimates', () => {
    const out = sanitizeItinerary({
      days: [{ date: '2027-05-01', activities: [{ title: 'Louvre', estimatedCost: 22 }, { title: 'Bad', estimatedCost: -5 }] }],
    });
    expect(out.verified).toBe(false);
    expect(out.warnings.length).toBeGreaterThan(0);
    expect(out.days[0].activities[0].estimatedCost).toBe(22);
    expect(out.days[0].activities[1].estimatedCost).toBeNull();
  });

  it('flags booking language and survives garbage input', () => {
    const flagged = sanitizeItinerary({ days: [{ date: '2027-05-01', activities: [{ title: 'Hotel confirmed for 2 nights' }] }] });
    expect(flagged.warnings.join(' ')).toMatch(/booking language/i);
    expect(sanitizeItinerary('nonsense').days).toEqual([]);
  });
});
