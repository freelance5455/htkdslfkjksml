import { validateEnv } from '../src/config/env';

const base = { JWT_ACCESS_SECRET: 'x'.repeat(40), WEB_ORIGIN: 'http://localhost', DATABASE_URL: 'postgres://u:p@h/db' };

describe('env validation', () => {
  it('accepts a valid config', () => expect(validateEnv(base).PORT).toBe(3000));
  it('rejects short secrets', () => expect(() => validateEnv({ ...base, JWT_ACCESS_SECRET: 'short' })).toThrow());
  it('rejects placeholder secrets in production', () =>
    expect(() => validateEnv({ ...base, NODE_ENV: 'production', JWT_ACCESS_SECRET: 'change_me_' + 'x'.repeat(30) })).toThrow());
});
