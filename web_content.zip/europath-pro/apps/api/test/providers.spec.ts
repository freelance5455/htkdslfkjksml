import { ProviderRegistry } from '../src/modules/providers/provider-registry';

const opts = { timeoutMs: 100, retries: 1, backoffMs: 1, breakerThreshold: 2, breakerCooldownMs: 1000 };

describe('ProviderRegistry', () => {
  it('falls back to the next provider and never fabricates data', async () => {
    const reg = new ProviderRegistry(opts);
    reg.register({ name: 'bad', kind: 'trains', search: async () => { throw new Error('down'); } });
    reg.register({ name: 'good', kind: 'trains', search: async () => ({ data: [1], source: 'good', fetchedAt: 'now', isEstimate: false }) });
    const r = await reg.search('trains', {});
    expect(r.ok && r.result.source).toBe('good');
  });

  it('reports unavailable when everything fails', async () => {
    const reg = new ProviderRegistry(opts);
    reg.register({ name: 'bad', kind: 'hotels', search: async () => { throw new Error('down'); } });
    const r = await reg.search('hotels', {});
    expect(r.ok).toBe(false);
  });
});
