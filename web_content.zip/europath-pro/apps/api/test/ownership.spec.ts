import { ForbiddenException, NotFoundException } from '@nestjs/common';
import { TripsService } from '../src/modules/trips/trips.service';

const repo = (over: any = {}) => ({ findOneBy: jest.fn(), countBy: jest.fn(), ...over });

describe('Trip ownership & plan limits', () => {
  it('returns 404 when a trip belongs to another user', async () => {
    const trips = repo({ findOneBy: jest.fn().mockResolvedValue(null) });
    const svc = new TripsService(trips as any, repo() as any);
    await expect(svc.findOwned('00000000-0000-0000-0000-000000000001', 'attacker')).rejects.toBeInstanceOf(NotFoundException);
    expect(trips.findOneBy).toHaveBeenCalledWith({ id: '00000000-0000-0000-0000-000000000001', ownerId: 'attacker' });
  });

  it('FREE plan cannot create a second active trip', async () => {
    const trips = repo({ countBy: jest.fn().mockResolvedValue(1) });
    const svc = new TripsService(trips as any, repo() as any);
    const dto = { title: 't', destination: 'Rome', startDate: '2027-05-01', endDate: '2027-05-05' };
    await expect(svc.create({ id: 'u1', role: 'user', plan: 'FREE' }, dto)).rejects.toBeInstanceOf(ForbiddenException);
  });
});
