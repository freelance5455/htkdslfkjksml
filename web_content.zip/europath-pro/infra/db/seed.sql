-- DEMO DATA ONLY. Replace with a licensed dataset (e.g. OpenStreetMap import with attribution) before launch.
INSERT INTO places (name, category, country_code, city, location, accessible, family_friendly, source) VALUES
 ('Eiffel Tower',          'landmark', 'FR', 'Paris',     ST_SetSRID(ST_MakePoint(2.2945, 48.8584),4326)::geography, true,  true,  'demo-seed'),
 ('Colosseum',             'landmark', 'IT', 'Rome',      ST_SetSRID(ST_MakePoint(12.4922,41.8902),4326)::geography, true,  true,  'demo-seed'),
 ('Sagrada Família',       'landmark', 'ES', 'Barcelona', ST_SetSRID(ST_MakePoint(2.1744, 41.4036),4326)::geography, true,  true,  'demo-seed'),
 ('Brandenburg Gate',      'landmark', 'DE', 'Berlin',    ST_SetSRID(ST_MakePoint(13.3777,52.5163),4326)::geography, true,  true,  'demo-seed'),
 ('Rijksmuseum',           'museum',   'NL', 'Amsterdam', ST_SetSRID(ST_MakePoint(4.8852, 52.3600),4326)::geography, true,  true,  'demo-seed')
ON CONFLICT DO NOTHING;
