const LOCALES = __LOCALES__;
const RTL = ['fa', 'ar'];
let store;
try { localStorage.setItem('ep_t', '1'); localStorage.removeItem('ep_t'); store = localStorage; }
catch (e) { const m = {}; store = { getItem: k => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = v; } }; }

let state;
try { state = JSON.parse(store.getItem('ep_state') || 'null'); } catch (e) { state = null; }
state = state || { trips: [], lang: null };
const save = () => store.setItem('ep_state', JSON.stringify(state));

let lang = state.lang || (navigator.language || 'en').slice(0, 2);
if (!LOCALES[lang]) lang = 'en';
const t = k => (LOCALES[lang] && LOCALES[lang][k]) || LOCALES.en[k] || k;
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = (n, c) => new Intl.NumberFormat(lang, { style: 'currency', currency: c || 'EUR' }).format(n);
const fdate = d => new Intl.DateTimeFormat(lang, { dateStyle: 'medium', timeZone: 'UTC' }).format(new Date(d));
const uid = () => Math.random().toString(36).slice(2, 10);
const sum = a => a.reduce((x, y) => x + y, 0);

function applyLang() {
  document.documentElement.lang = lang;
  document.documentElement.dir = RTL.includes(lang) ? 'rtl' : 'ltr';
}

function shell(inner) {
  const opts = Object.keys(LOCALES).map(k => `<option value="${k}"${k === lang ? ' selected' : ''}>${esc(LOCALES[k].lang)}</option>`).join('');
  return `<header class="bar"><a class="brand" href="#/">
    <svg width="28" height="28" viewBox="0 0 512 512" aria-hidden="true"><rect width="512" height="512" rx="112" fill="#0B5C7A"/><path d="M120 360 C 190 360 190 240 256 240 S 322 152 392 152" fill="none" stroke="#FFB703" stroke-width="34" stroke-linecap="round"/></svg>
    EuroPath Pro</a>
    <div class="bar-actions"><label class="visually-hidden" for="lang">${esc(t('language'))}</label><select id="lang">${opts}</select></div></header>
    <main>${inner}</main>`;
}

function homeView() {
  const list = state.trips.length
    ? state.trips.map(x => `<li><a href="#/trip/${x.id}"><strong>${esc(x.title)}</strong><span>${esc(x.destination)}</span><small>${fdate(x.startDate)} – ${fdate(x.endDate)}</small></a></li>`).join('')
    : `<li class="empty">${esc(t('noTrips'))}</li>`;
  return shell(`<h1>${esc(t('tagline'))}</h1><h2>${esc(t('trips'))}</h2>
    <div class="split"><ul class="trips">${list}</ul>
    <form class="card stack" data-form="trip"><h2>${esc(t('newTrip'))}</h2>
      <label>${esc(t('title'))}<input name="title" required maxlength="120"></label>
      <label>${esc(t('destination'))}<input name="destination" required maxlength="120"></label>
      <div class="row"><label>${esc(t('start'))}<input name="start" type="date" required></label><label>${esc(t('end'))}<input name="end" type="date" required></label></div>
      <div class="row"><label>${esc(t('travelers'))}<input name="travelers" type="number" min="1" max="50" value="1"></label><label>${esc(t('budget'))} (EUR)<input name="budget" type="number" min="0" step="0.01"></label></div>
      <button class="primary">${esc(t('create'))}</button></form></div>`);
}

function tripView(id) {
  const trip = state.trips.find(x => x.id === id);
  if (!trip) { location.hash = '#/'; return homeView(); }
  const items = trip.items.slice().sort((a, b) => (a.day + (a.time || '')).localeCompare(b.day + (b.time || '')));
  const days = {};
  items.forEach(i => (days[i.day] = days[i.day] || []).push(i));
  const planned = sum(trip.items.map(i => Number(i.cost) || 0));
  const spent = sum(trip.expenses.map(e => Number(e.amount) || 0));
  const remaining = trip.budget ? trip.budget - spent : null;
  const route = Object.keys(days).length
    ? `<ol class="route">${Object.keys(days).map(d => `<li><h3>${fdate(d)}</h3><ul>${days[d].map(i => `<li><span class="stop-time">${esc(i.time || '')}</span><span class="stop-title">${esc(i.title)}</span>${i.cost ? `<span class="chip">~${money(i.cost, trip.currency)} ${esc(t('estimate'))}</span>` : ''}<button class="ghost small" data-act="delitem" data-id="${i.id}">${esc(t('delete'))}</button></li>`).join('')}</ul></li>`).join('')}</ol>`
    : `<p class="empty">${esc(t('noItems'))}</p>`;
  const ledger = trip.expenses.length
    ? `<ul class="ledger">${trip.expenses.slice().sort((a, b) => b.date.localeCompare(a.date)).map(e => `<li><span>${fdate(e.date)} · ${esc(e.category)}</span><strong>${money(e.amount, trip.currency)}</strong><button class="ghost small" data-act="delexp" data-id="${e.id}">${esc(t('delete'))}</button></li>`).join('')}</ul>`
    : `<p class="empty">${esc(t('noExpenses'))}</p>`;
  return shell(`<a href="#/" class="back">${esc(t('back'))}</a><h1>${esc(trip.title)}</h1>
    <p class="muted">${esc(trip.destination)} · ${fdate(trip.startDate)} – ${fdate(trip.endDate)}</p>
    <div class="split"><section><h2>${esc(t('itinerary'))}</h2>
      <form class="card stack" data-form="item">
        <div class="row"><label>${esc(t('day'))}<input name="day" type="date" required min="${trip.startDate}" max="${trip.endDate}"></label><label>${esc(t('time'))}<input name="time" type="time"></label></div>
        <label>${esc(t('itemTitle'))}<input name="title" required maxlength="160"></label>
        <label>${esc(t('cost'))} (${esc(trip.currency)}, ${esc(t('estimate'))})<input name="cost" type="number" min="0" step="0.01"></label>
        <button class="primary">${esc(t('addItem'))}</button></form>${route}</section>
    <section><h2>${esc(t('expenses'))}</h2>
      <dl class="summary"><div><dt>${esc(t('planned'))}</dt><dd>${money(planned, trip.currency)}</dd></div><div><dt>${esc(t('spent'))}</dt><dd>${money(spent, trip.currency)}</dd></div>
      ${remaining !== null ? `<div><dt>${esc(t('remaining'))}</dt><dd class="${remaining < 0 ? 'neg' : ''}">${money(remaining, trip.currency)}</dd></div>` : ''}</dl>
      <p class="muted small-text">${esc(t('estimateNote'))}</p>
      <form class="card stack" data-form="expense"><div class="row"><label>${esc(t('amount'))} (${esc(trip.currency)})<input name="amount" type="number" min="0" step="0.01" required></label><label>${esc(t('day'))}<input name="date" type="date" required></label></div>
        <label>${esc(t('category'))}<input name="category" maxlength="40"></label><button class="primary">${esc(t('addExpense'))}</button></form>${ledger}</section></div>
    <p class="muted small-text demo-note">Demo: data is stored only in this browser.</p>`);
}

function render() {
  applyLang();
  const m = location.hash.match(/^#\/trip\/(\w+)/);
  document.getElementById('app').innerHTML = m ? tripView(m[1]) : homeView();
}

document.addEventListener('change', e => {
  if (e.target.id === 'lang') { lang = e.target.value; state.lang = lang; save(); render(); }
});
document.addEventListener('submit', e => {
  const form = e.target.closest('form[data-form]'); if (!form) return;
  e.preventDefault();
  const f = new FormData(form), kind = form.dataset.form;
  const m = location.hash.match(/^#\/trip\/(\w+)/);
  const trip = m && state.trips.find(x => x.id === m[1]);
  if (kind === 'trip') {
    if (f.get('end') < f.get('start')) { alert(t('error')); return; }
    state.trips.push({ id: uid(), title: f.get('title'), destination: f.get('destination'), startDate: f.get('start'), endDate: f.get('end'), currency: 'EUR', travelers: Number(f.get('travelers') || 1), budget: f.get('budget') ? Number(f.get('budget')) : null, items: [], expenses: [] });
  } else if (trip && kind === 'item') {
    trip.items.push({ id: uid(), day: f.get('day'), time: f.get('time') || '', title: f.get('title'), cost: f.get('cost') ? Number(f.get('cost')) : null });
  } else if (trip && kind === 'expense') {
    trip.expenses.push({ id: uid(), amount: Number(f.get('amount')), date: f.get('date'), category: f.get('category') || '—' });
  }
  save(); render();
});
document.addEventListener('click', e => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  const m = location.hash.match(/^#\/trip\/(\w+)/);
  const trip = m && state.trips.find(x => x.id === m[1]); if (!trip) return;
  if (b.dataset.act === 'delitem') trip.items = trip.items.filter(i => i.id !== b.dataset.id);
  if (b.dataset.act === 'delexp') trip.expenses = trip.expenses.filter(i => i.id !== b.dataset.id);
  save(); render();
});
window.addEventListener('hashchange', render);
render();
