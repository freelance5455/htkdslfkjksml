WHISPERING PINES - HTML game

Open index.html in a modern browser or import the ZIP into an HTML5 game wrapper/editor.

Controls:
- Drag and drop matching items (same chain and level) onto each other to merge.
- Tap Buyum olish to spawn a level-1 item (costs 1 energy).
- Complete the customer order to earn coins.
- Spend coins on cabin renovations.
- Energy regenerates by 1 point every 2 minutes, including while the game is closed.

Save data is stored in the browser's localStorage for the same browser/app origin.
