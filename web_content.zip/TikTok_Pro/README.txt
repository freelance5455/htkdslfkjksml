TikTok Pro - Preview Package

FILES
- index.html: single-file mobile-friendly web preview.

HOW TO PREVIEW
1. Open index.html in a browser, or paste its contents into the HTML panel of an HTML preview/editor app.
2. Test the bottom-center + upload button, Like, Comments, Save, Download, Share, Profile and Followers · View.
3. To package as an Android APK, use an Android WebView wrapper or a trusted HTML-to-APK builder and load index.html as the app's start page.

IMPORTANT SECURITY / PRODUCTION NOTES
This is a front-end preview, not a production social network.
- Demo profile data is kept in memory only; it does not create real accounts.
- Never enter a real password or sensitive personal information in this preview.
- Real users, followers, likes across devices, video hosting, login, password reset, admin controls and blocking require a backend.
- For production, use Firebase Authentication or another established identity provider, server-side authorization rules, HTTPS, secure storage, upload validation, rate limits, abuse reporting and audit logs.
- Never put admin secrets, service-account keys, database admin credentials or private API keys in HTML/JavaScript or an APK.
- Enforce owner/admin permissions on the server for every privileged action. Hiding an admin button in the app is not security.
- Review privacy, moderation, copyright and platform-store requirements before public release.

The APK builder only packages the front-end. It does not turn the preview into a real online multi-user service.
