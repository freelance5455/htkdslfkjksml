---
name: Terracotta & Chalk Clay Step Counter
colors:
  surface: '#fcf9f3'
  surface-dim: '#dcdad4'
  surface-bright: '#fcf9f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ed'
  surface-container: '#f0eee8'
  surface-container-high: '#ebe8e2'
  surface-container-highest: '#e5e2dc'
  on-surface: '#1c1c18'
  on-surface-variant: '#55423e'
  inverse-surface: '#31312d'
  inverse-on-surface: '#f3f0ea'
  outline: '#88726d'
  outline-variant: '#dbc1ba'
  surface-tint: '#9a442d'
  primary: '#9a442d'
  on-primary: '#ffffff'
  primary-container: '#e07a5f'
  on-primary-container: '#5b1604'
  inverse-primary: '#ffb4a1'
  secondary: '#3a6758'
  on-secondary: '#ffffff'
  secondary-container: '#bcedda'
  on-secondary-container: '#406d5e'
  tertiary: '#5e5e5c'
  on-tertiary: '#ffffff'
  tertiary-container: '#979693'
  on-tertiary-container: '#2e2f2c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd2'
  primary-fixed-dim: '#ffb4a1'
  on-primary-fixed: '#3c0800'
  on-primary-fixed-variant: '#7c2e19'
  secondary-fixed: '#bcedda'
  secondary-fixed-dim: '#a1d1be'
  on-secondary-fixed: '#002118'
  on-secondary-fixed-variant: '#214f41'
  tertiary-fixed: '#e4e2de'
  tertiary-fixed-dim: '#c8c6c3'
  on-tertiary-fixed: '#1b1c1a'
  on-tertiary-fixed-variant: '#474744'
  background: '#fcf9f3'
  on-background: '#1c1c18'
  surface-variant: '#e5e2dc'
typography:
  display-stat:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 60px
    letterSpacing: -0.03em
  display-stat-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 44px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1.25rem
  margin-lg: 2rem
  space-xs: 0.375rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.25rem
---

## Brand & Style

This design system expresses tactile warmth, calm discipline, and mindful physical movement. Built specifically for a premium health and activity tracking experience, it departs entirely from sterile, hyper-technical athletic dashboards and neon gamification. Instead, it invites physical touch through bespoke claymorphism—transforming daily walking metrics into matte, physical objects sculpted from soft chalk and earthen pigments.

### Aesthetic Foundation
- **Tactile Claymorphism (Soft UI 3D):** Surfaces look hand-sculpted, velvety, and matte. They possess visible volume, gentle heft, and natural daylight highlights.
- **Organic Earthiness:** The environment feels like high-grade unglazed ceramic, terracotta pottery, and river stones resting under soft north-facing skylight.
- **Anti-Gloss Rigor:** Strictly void of semi-transparent glass, backdrop blurs, refractive reflections, and hard 1px vector hairpins. Depth is established purely through volume, underside shading, and soft drop shadows.
- **Physical Dynamics:** Interactive elements compress on press like dense sculpting clay, rebounding with elastic physical weight (`cubic-bezier(0.34, 1.56, 0.64, 1)`).

## Colors

The palette is tuned around matte minerals, porcelain chalk, and baked clay. Every tint retains low saturation to maintain an editorial, grounding presence.

### Functional Palette
- **Canvas Base (`#F3F0EA`):** Warm Alabaster canvas. All clay objects rest upon or recess into this foundational tone.
- **Primary Clay Surface (`#FAF8F4`):** Soft Chalk. The default physical surface for main cards, modular dials, and floating containers.
- **Primary Active Accent (`#E07A5F`):** Soft Terracotta. Reserved for main activity step goals, primary completion rings, and primary action buttons.
- **Complementary Accent (`#6E9C8B`):** Muted Sage. Used for secondary milestone achievements, pacing indicators, and balanced completion states.
- **Deep Slate Text (`#1F2430`):** High-contrast, warm dark slate for big numerical statistics and titles. Never pure pitch black.
- **Muted Slate Text (`#6B7280`):** Secondary typographic tone for measurement units, dates, and subheaders.

### Semantic Metric Clay Tints
Modular metric modules use dedicated pastel clay bodies:
- **Distance:** Pale Sage (`#E4ECE6`)
- **Active Calories:** Soft Peach (`#F4E5DC`)
- **Active Duration:** Dusty Periwinkle (`#E6E8F2`)

## Typography

Typography balances sculptural confidence with utilitarian micro-legibility. 

- **Primary Display & Headings (Plus Jakarta Sans):** Weighted heavily at 700 and 800 weights. Numerals feature tight geometric spacing to feel carved into their clay backdrops.
- **Body & Micro-Metrics (Inter):** Set at weights 500 and 600. Neutral, structured, and legible at small scale for units (`km`, `kcal`, `steps`, `min/mi`), preserving functional legibility against colored clay fields.

## Layout & Spacing

The layout philosophy follows a tactile pod architecture. Elements do not abut one another; they sit as self-contained volumes with ample negative space around their perimeters to allow simulated shadows to fall uninterrupted.

- **Mobile Viewport Structure:** Standard 4-column fluid mobile grid with `1.25rem` outer canvas padding.
- **Vertical Rhythm:** Components stack with `1rem` to `1.5rem` vertical spacing, preventing shadow collisions while maintaining an ergonomic, thumb-reachable hierarchy.
- **Pod Grouping:** Metrics and actions are clustered into discrete multi-column modular pods using 2-column or 3-column subgrids with `0.75rem` internal gutters.

## Elevation & Depth

Volume is generated through an authentic three-dimensional physical stack simulating a diffused top-down daylight source.

### The Clay Light Model
1. **Top Skylight Crest (Inset Highlight):**
   `inset 0 6px 10px rgba(255, 255, 255, 0.85)`
   Simulates daylight striking the rounded, soft upward bevel of the clay.
2. **Sculpted Underside Core (Inset Shadow):**
   `inset 0 -8px 14px rgba(166, 154, 138, 0.22)`
   Simulates light occlusion beneath the lower curvature of the shape, giving it internal mass.
3. **Warm Floor Cast Shadow (Drop Shadow):**
   `0 14px 24px -4px rgba(166, 154, 138, 0.28), 0 4px 8px -2px rgba(166, 154, 138, 0.16)`
   Grounds the object onto the `#F3F0EA` Warm Alabaster floor without muddy gray degradation.

### Depressed & Inset States (Pits and Tracks)
For uncompleted progress tracks, input troughs, and switch valleys:
- `box-shadow: inset 0 4px 8px rgba(166, 154, 138, 0.32), inset 0 -2px 4px rgba(255, 255, 255, 0.9);`
- Background tone dips slightly darker than the canvas base (`#EAE5DC`).

## Shapes

The design system exclusively adopts deep, doughy curvatures. Sharp corners destroy the clay metaphor and are prohibited.

- **Primary Cards & Large Pods:** `32px` to `40px` corner radius.
- **Secondary Tiles & Small Modules:** `24px` to `28px` corner radius.
- **Interactive Controls (Pills, Buttons, Chips):** `9999px` fully rounded capsule geometry.
- **Zero Borders:** 1px vector borders are prohibited. Silhouettes are defined exclusively by their volumetric lighting and contact shadows.

## Components

### 1. Main Step Progress Ring & Central Dial
- **Construction:** A thick, rounded clay torus. The inactive track is sculpted inward as a smooth trench.
- **Active Path:** Soft Terracotta (`#E07A5F`) with its own top highlight (`inset 0 4px 6px rgba(255, 255, 255, 0.6)`) and soft underside bevel, creating an extruded tubular cylinder.
- **Core Pod:** Soft Chalk (`#FAF8F4`) circular medallion sitting centered inside the ring, housing the `display-stat` step counter in Deep Slate (`#1F2430`).

### 2. Metric Pods (Distance, Calories, Time)
- **Base Surfaces:** Sculpted pods matching dedicated clay tints (`#E4ECE6`, `#F4E5DC`, `#E6E8F2`).
- **Internal Content:** Icon molded in matching high-contrast tinted clay tone, paired with Plus Jakarta Sans bold counters and muted metric units.

### 3. Primary Action & Quick-Log Buttons
- **Default State:** Pill geometry (`rounded-full`), Terracotta `#E07A5F`, white bold typography, dual-layer clay lighting.
- **Active/Pressed State:** Transforms with spring physics `transform: scale(0.96) translateY(3px)`. The outer drop shadow compresses from `14px` down to `4px`, and the bottom rim inner shadow reduces, conveying physical compaction.

### 4. Interactive Clay Chips & Period Filters (Day / Week / Month)
- **Inactive:** Flat Soft Chalk capsules level with the canvas floor.
- **Selected:** Extruded forward with Terracotta text, elevated cast shadow, and chalk surface sheen.

### 5. Checkboxes, Toggles & Milestones
- **Toggle Track:** Depressed trench in canvas floor.
- **Toggle Thumb:** Pure chalk marble sphere resting inside the trench that glides across with rubberized spring tension.