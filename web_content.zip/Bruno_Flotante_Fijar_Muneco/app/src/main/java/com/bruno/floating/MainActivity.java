package com.bruno.floating;
import android.app.*; import android.os.*; import android.content.*; import android.provider.Settings; import android.net.Uri; import android.widget.*;
public class MainActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b); Button x=new Button(this);x.setText("Abrir Bruno flotante");setContentView(x);
 x.setOnClickListener(v->{if(!Settings.canDrawOverlays(this)){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));return;}startService(new Intent(this,FloatingService.class));});}
}