package com.bruno.floating;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.PixelFormat;import android.view.*;import android.webkit.*;import android.widget.*;
public class FloatingService extends Service{
 WindowManager wm; View win; WindowManager.LayoutParams p;
 public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);
 LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(8,8,8,8);box.setBackgroundColor(0xEE101827);
 LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);
 TextView t=new TextView(this);t.setText("  🎯 Bruno");t.setTextColor(0xffffffff);t.setTextSize(16);t.setLayoutParams(new LinearLayout.LayoutParams(0,48,1));
 Button c=new Button(this);c.setText("✕");c.setOnClickListener(v->stopSelf());bar.addView(t);bar.addView(c);box.addView(bar);
 WebView w=new WebView(this);w.getSettings().setJavaScriptEnabled(true);w.getSettings().setDomStorageEnabled(true);w.loadUrl("file:///android_asset/index.html");box.addView(w,new LinearLayout.LayoutParams(520,650));
 p=new WindowManager.LayoutParams(540,700,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.START;p.x=20;p.y=120;
 t.setOnTouchListener(new View.OnTouchListener(){float dx,dy;int sx,sy;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==0){dx=e.getRawX();dy=e.getRawY();sx=p.x;sy=p.y;return true;}if(e.getAction()==2){p.x=sx+(int)(e.getRawX()-dx);p.y=sy+(int)(e.getRawY()-dy);wm.updateViewLayout(win,p);return true;}return false;}});
 win=box;wm.addView(win,p);}
 public void onDestroy(){if(wm!=null&&win!=null)wm.removeView(win);super.onDestroy();}
 public IBinder onBind(Intent i){return null;}
}