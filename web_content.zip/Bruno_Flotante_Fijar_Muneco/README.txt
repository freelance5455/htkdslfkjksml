BRUNO FLOTANTE 1.1
Incluye:
- Ventana flotante movible.
- Botón Fijar muñeco.
- Botón Soltar muñeco.
- La mira sigue al muñeco dentro del simulador.
- Botón Mover muñeco.
- Disparo simulado local.

Es un simulador independiente. No controla ni automatiza otras aplicaciones.
