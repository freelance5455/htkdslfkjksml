# Carreira de Craque v1.57.0 — Motor de Eventos e Desempenho

- Base: v1.56.4, preservando a correção de desbloqueio da rodada 5 do Sub-20.
- Refeito o perfil de elenco para montar titulares por setores/posições antes de completar vagas por overall; reservas passam a ser medidos separadamente.
- Motor Realismo v2 organiza cada minuto em posse, progressão, chance, finalização, precisão e resolução contra o goleiro. O placar é a soma dos eventos de gol.
- Estatísticas de finalizações, no alvo, para fora, defesas, faltas, cartões e escanteios são atualizadas durante a simulação; eventos de gol/defesa/falta/cartão/escanteio acompanham os contadores.
- A narração aleatória decorativa não é acrescentada quando o motor de eventos está ativo.
- Nota pós-jogo no Realismo deixa de incluir ruído aleatório e passa a considerar prontidão, gols, assistências, contribuição coletiva e cartões.
- Modo Realismo desativado continua usando o simulador anterior.
- Nenhuma chave de save, calendário, elenco ou estrutura de armazenamento foi alterada.

## Verificações executadas
- `node --check` no JavaScript embutido: aprovado.
- 10.000 simulações sintéticas 5★ x 1★: placar e estatísticas coerentes em 100% dos casos; gols nunca excederam finalizações no alvo; finalizações no alvo + para fora = total.
- Não foi possível validar a interface em Android nem executar temporada completa nesta sessão.
