if (typeof COURSES !== "undefined") {
  COURSES.push({
    id: "eng-1",
    category: "Anglais Technique",
    level: "Universitaire / Tous niveaux",
    title: "Anglais Technique & Informatique",
    duration: "1h 15",
    description: "Manuel complet : vocabulaire matériel, réseau et code, faux-amis à éviter, lecture de documentation, erreurs et communication IT.",
    chapters: [
      {
        id: "eng-c1",
        title: "Chapitre 1 : Matériel, Systèmes & Réseaux",
        html: `
          <h3>1.1 Pourquoi l'anglais est indispensable en IT ?</h3>
          <p>Plus de <strong>90 %</strong> des langages de programmation, des documentations officielles, des messages d'erreur et des certifications internationales (Cisco, AWS, CompTIA) sont rédigés en anglais.</p>

          <h3>1.2 Vocabulaire Matériel & Système (Hardware & OS)</h3>
          <table>
            <tr><th>Terme anglais</th><th>Traduction exacte</th><th>Contexte d'utilisation</th></tr>
            <tr><td><strong>Hardware / Software</strong></td><td>Matériel / Logiciel</td><td>Composants physiques vs programmes</td></tr>
            <tr><td><strong>Motherboard</strong></td><td>Carte mère</td><td>Carte principale reliant CPU, RAM, SSD</td></tr>
            <tr><td><strong>Storage vs Memory</strong></td><td>Stockage vs Mémoire vive</td><td>SSD/Disque dur vs RAM</td></tr>
            <tr><td><strong>Boot / Reboot</strong></td><td>Démarrer / Redémarrer</td><td>Lancement du système d'exploitation</td></tr>
            <tr><td><strong>Kernel / Driver</strong></td><td>Noyau / Pilote</td><td>Cœur de l'OS / Logiciel d'un périphérique</td></tr>
            <tr><td><strong>Backup / Restore</strong></td><td>Sauvegarde / Restaurer</td><td>Copie de sécurité des données</td></tr>
          </table>

          <h3>1.3 Vocabulaire Réseau (Networking)</h3>
          <ul>
            <li><strong>Bandwidth :</strong> Bande passante (débit maximal d'une connexion).</li>
            <li><strong>Latency / Lag :</strong> Latence / Retard (temps de réponse réseau en ms).</li>
            <li><strong>Gateway :</strong> Passerelle par défaut (souvent votre routeur).</li>
            <li><strong>Firewall :</strong> Pare-feu (filtre les connexions entrantes/sortantes).</li>
            <li><strong>Throughput :</strong> Débit réel effectif mesuré sur le réseau.</li>
            <li><strong>Wireless / Wired :</strong> Sans-fil (Wi-Fi) / Filaire (Câble Ethernet).</li>
          </ul>
        `
      },
      {
        id: "eng-c2",
        title: "Chapitre 2 : Programmation, Données & Faux-amis",
        html: `
          <h3>2.1 Vocabulaire du code et des bases de données</h3>
          <table>
            <tr><th>Terme anglais</th><th>Signification technique</th><th>Exemple</th></tr>
            <tr><td><strong>Array / List</strong></td><td>Tableau / Liste</td><td>Collection ordonnée d'éléments</td></tr>
            <tr><td><strong>Loop / Iteration</strong></td><td>Boucle / Tour de boucle</td><td><code>for</code>, <code>while</code></td></tr>
            <tr><td><strong>Statement / Condition</strong></td><td>Instruction / Condition</td><td><code>if ... else</code></td></tr>
            <tr><td><strong>String / Integer / Float</strong></td><td>Chaîne / Entier / Flottant (réel)</td><td><code>"abc"</code>, <code>42</code>, <code>3.14</code></td></tr>
            <tr><td><strong>Parameter vs Argument</strong></td><td>Paramètre (définition) vs Valeur passée</td><td><code>def f(x):</code> vs <code>f(5)</code></td></tr>
            <tr><td><strong>Query / Table / Row</strong></td><td>Requête / Table / Ligne</td><td><code>SELECT * FROM users;</code></td></tr>
          </table>

          <h3>2.2 Les faux-amis informatiques (Pièges classiques !)</h3>
          <div class="warn-box">
            <strong>⚠️ Attention aux faux-amis :</strong><br/>
            • <strong>Library</strong> = Une <em>bibliothèque</em> de code (et non une « librairie » = bookshop).<br/>
            • <strong>File</strong> = Un <em>fichier</em> (et non une « file d'attente » = queue).<br/>
            • <strong>Folder / Directory</strong> = Un <em>dossier / répertoire</em>.<br/>
            • <strong>Actually</strong> = <em>En fait / En réalité</em> (et non « actuellement » = currently).<br/>
            • <strong>Character</strong> = Un <em>caractère</em> (lettre/chiffre).<br/>
            • <strong>To compile / To run</strong> = <em>Compiler / Exécuter</em> un programme.
          </div>
        `
      },
      {
        id: "eng-c3",
        title: "Chapitre 3 : Lire la Doc & Décoder les Erreurs",
        html: `
          <h3>3.1 Mots clés des documentations techniques</h3>
          <ul>
            <li><strong>Prerequisites / Requirements :</strong> Prérequis à installer avant de commencer.</li>
            <li><strong>Deprecated :</strong> Obsolète (fonction ancienne déconseillée, bientôt supprimée).</li>
            <li><strong>Case-sensitive :</strong> Sensible à la casse (<code>Nom</code> est différent de <code>nom</code>).</li>
            <li><strong>Read-only :</strong> Lecture seule (modification interdite).</li>
            <li><strong>Path :</strong> Chemin d'accès d'un fichier (ex: <code>/home/jos/app.js</code>).</li>
            <li><strong>Troubleshooting :</strong> Dépannage / Résolution de problèmes.</li>
          </ul>

          <h3>3.2 Décoder les messages d'erreur courants</h3>
          <div class="code-box">
            <div class="code-header"><span>Erreurs fréquentes & Signification</span><button class="copy-btn" onclick="copyCode(this)">Copier</button></div>
<pre><span class="kw">SyntaxError</span>: unexpected end of input
<span class="cmt">-> Erreur de syntaxe : accolade }, parenthèse ) ou guillemet manquant à la fin.</span>

<span class="kw">ReferenceError</span>: x is not defined
<span class="cmt">-> Variable x utilisée avant d'avoir été déclarée (ou faute d'orthographe).</span>

<span class="kw">Connection timed out</span>
<span class="cmt">-> Délai d'attente dépassé : le serveur est éteint, bloqué par pare-feu ou hors ligne.</span>

<span class="kw">Permission denied</span> (403 Forbidden)
<span class="cmt">-> Accès refusé : droits insuffisants pour lire ou modifier cette ressource.</span>

<span class="kw">Out of memory</span> (OOM)
<span class="cmt">-> Mémoire RAM saturée par le programme (ex: boucle infinie ou trop de données).</span></pre>
          </div>
        `
      },
      {
        id: "eng-c4",
        title: "Chapitre 4 : Communication Pro (Git, Bugs & Travail)",
        html: `
          <h3>4.1 Écrire des messages Git professionnels</h3>
          <p>Dans les équipes informatiques, l'historique de code (Git) s'écrit presque toujours à l'impératif en anglais :</p>
          <ul>
            <li><code>feat: add offline quiz module</code> → Ajouter une nouvelle fonctionnalité.</li>
            <li><code>fix: resolve login crash on Android</code> → Corriger un bug.</li>
            <li><code>docs: update README installation steps</code> → Mettre à jour la documentation.</li>
            <li><code>refactor: simplify SQL query</code> → Améliorer le code sans changer le comportement.</li>
          </ul>

          <h3>4.2 Rédiger un rapport de bug (Bug Report)</h3>
          <p>Pour signaler un problème clairement sur GitHub ou à un collègue, utilisez cette structure en 3 points :</p>
          <div class="note-box">
            <strong>📌 Modèle de Bug Report en anglais :</strong><br/>
            1. <strong>Steps to reproduce :</strong> <em>"Open Profile tab and tap Dark Mode."</em> (Étapes pour reproduire)<br/>
            2. <strong>Expected behavior :</strong> <em>"The theme should switch to Night Blue."</em> (Comportement attendu)<br/>
            3. <strong>Actual behavior :</strong> <em>"The screen turns blank."</em> (Comportement constaté)
          </div>
        `
      }
    ],
    exercises: [
      {
        title: "Chasse aux faux-amis et traduction",
        prompt: "Traduisez correctement cette phrase technique en évitant les faux-amis :<br/><em>« Currently, we need to import a new library to read this binary file from the root directory and save a backup. »</em>",
        solution: "« <strong>Actuellement</strong> (Currently), nous devons importer une nouvelle <strong>bibliothèque</strong> (library) pour lire ce <strong>fichier</strong> (file) binaire depuis le <strong>répertoire</strong> (directory) racine et enregistrer une <strong>sauvegarde</strong> (backup). »"
      },
      {
        title: "Diagnostic de 3 messages d'erreur",
        prompt: "Expliquez en français la cause probable de chacun de ces messages :<br/>1) <code>FileNotFoundError: No such file or directory: 'cours.js'</code><br/>2) <code>SyntaxError: missing ) after argument list</code><br/>3) <code>Error 401: Unauthorized — Invalid credentials</code>",
        solution: "1) <strong>Fichier introuvable :</strong> <code>cours.js</code> n'est pas dans le bon dossier ou son nom est mal orthographié.<br/>2) <strong>Parenthèse manquante :</strong> Il manque une parenthèse fermante <code>)</code> à la fin d'un appel de fonction.<br/>3) <strong>Non autorisé :</strong> Identifiants (e-mail ou mot de passe) invalides."
      },
      {
        title: "Rédiger un commit Git en anglais",
        prompt: "Vous venez de corriger un bug qui empêchait d'afficher le score du quiz quand il vaut 0%. Proposez un message de commit Git court et professionnel en anglais.",
        solution: "<code>fix: display quiz score properly when score is 0%</code> (ou <code>fix: handle zero score display in quiz results</code>)."
      }
    ],
    quiz: [
      {
        q: "En programmation, que signifie correctement le mot anglais 'Library' ?",
        options: ["Une librairie commerciale", "Une bibliothèque de code réutilisable", "Un dossier caché", "Une boucle infinie"],
        answer: 1,
        explanation: "Attention au faux-ami : une library est une bibliothèque de fonctions/modules prêts à l'emploi."
      },
      {
        q: "Que signifie l'indication 'Case-sensitive' dans un système Linux ou un langage de code ?",
        options: [
          "Le système est protégé par mot de passe",
          "Il fait la différence entre MAJUSCULES et minuscules",
          "Le fichier est en lecture seule",
          "Le câble réseau est débranché"
        ],
        answer: 1,
        explanation: "Case-sensitive signifie sensible à la casse : Cours.js et cours.js sont deux fichiers différents !"
      },
      {
        q: "Quel terme désigne l'espace de stockage permanent (SSD/HDD) par opposition à la RAM (Memory) ?",
        options: ["Bandwidth", "Storage", "Latency", "Kernel"],
        answer: 1,
        explanation: "En anglais IT, Memory désigne généralement la RAM, tandis que Storage désigne le stockage permanent."
      },
      {
        q: "Que veut dire l'erreur 'Connection timed out' ?",
        options: [
          "Le mot de passe est trop court",
          "Le délai d'attente est dépassé : le serveur ne répond pas à temps",
          "Le fichier a été supprimé",
          "La batterie est faible"
        ],
        answer: 1,
        explanation: "Timed out indique que la requête réseau n'a reçu aucune réponse dans le délai imparti."
      },
      {
        q: "Dans un rapport de bug, que décrit la section 'Expected behavior' ?",
        options: [
          "Le prix du logiciel",
          "Ce que l'application devrait faire normalement",
          "La liste des utilisateurs connectés",
          "Le nom du développeur"
        ],
        answer: 1,
        explanation: "Expected behavior = comportement attendu ; Actual behavior = comportement réel (le bug constaté)."
      }
    ]
  });
}