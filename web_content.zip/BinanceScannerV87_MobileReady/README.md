# Binance Scanner V87 — Android source project

This is an Android Studio project scaffold based on the supplied V87 HTML. The V87 strategy/scoring logic is preserved; the integration adds an Android notification bridge for newly inserted, validated Futures tracker entries whose category is `READY` or `STRONG READY`. It does not force signals to READY and does not submit real orders.

## What is included
- `app/src/main/assets/scanner.html` — V87 scanner with a small native-notification callback at the point a new qualifying Futures tracker entry is inserted.
- `MainActivity.kt` — WebView host, JavaScript bridge, Android notification channel, Android 13+ notification-permission handling, and persistent duplicate suppression.
- Android manifest and Gradle Kotlin DSL configuration.

## Important limitations
- This ZIP is **source code, not a built or device-tested APK**. Build and test it in Android Studio or a compatible Android IDE before relying on it.
- Notification callback currently attaches to the shared Futures `storeSignal` path. Spot rows are deliberately excluded from that function in the original scanner; Spot-specific notification wiring must be added separately after confirming the exact Spot signal insertion path.
- This version does **not** promise scanning every five minutes with the screen off or while the app is closed. The WebView scan needs the app running; dependable background scanning requires a separate Android service/scheduling design and device testing.
- The app remains paper-trading/research only. Signals are not guarantees of profit. No live order placement is implemented.
- Internet permission is used for Binance public market-data endpoints. Do not add exchange API keys or secrets to the HTML.

## Build on a computer
1. Extract the ZIP.
2. Open the `BinanceScannerV87Android` folder in Android Studio.
3. Allow Gradle sync and install any SDK components Android Studio requests.
4. Build an APK, install it on a test Android device, and grant notification permission.
5. Confirm public data loads, scan behavior is normal, and a newly created test READY signal causes one Android notification. Verify repeated refreshes do not repeat the same notification.

## Phone-only note
If using an Android IDE on the phone, open/import the extracted project folder (not the HTML file alone). Mobile IDE compatibility with Android Gradle Plugin 8.7.3 varies; if it cannot sync/build, keep this ZIP as the project source and build it later on a computer. The previous simple HTML-to-APK wrapper is not enough for native Android notifications unless it supports a JavaScript-to-native bridge.
