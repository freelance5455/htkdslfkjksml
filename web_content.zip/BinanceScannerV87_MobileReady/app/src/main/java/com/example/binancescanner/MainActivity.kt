package com.example.binancescanner

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.security.MessageDigest

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val channelId = "v87_qualified_signals"
    private val permissionRequestCode = 8701

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.addJavascriptInterface(AndroidNotifications(this), "AndroidNotifications")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                android.util.Log.d("ScannerV87", "${consoleMessage.message()} (${consoleMessage.lineNumber()})")
                return true
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "file" && uri.host == null) return false
                val host = uri.host ?: return true
                return !(host == "api.binance.com" || host == "fapi.binance.com" || host == "www.binance.com" || host == "binance.com")
            }
        }
        setContentView(webView)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), permissionRequestCode)
        }
        webView.loadUrl("file:///android_asset/scanner.html")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "V87 READY signals", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "New validated READY and STRONG READY scanner signals"
                enableVibration(true)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    inner class AndroidNotifications(private val context: Context) {
        @JavascriptInterface
        fun showSignal(titleInput: String?, bodyInput: String?, keyInput: String?) {
            val title = titleInput.orEmpty().take(120)
            val body = bodyInput.orEmpty().take(450)
            val key = keyInput.orEmpty().take(300)
            if (title.isBlank() || body.isBlank() || key.isBlank()) return
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(context, "Enable notification permission for V87 signal alerts.", Toast.LENGTH_LONG).show()
                    return@runOnUiThread
                }
                val prefs = getSharedPreferences("v87_signal_notifications", Context.MODE_PRIVATE)
                val digest = MessageDigest.getInstance("SHA-256").digest(key.toByteArray()).joinToString("") { "%02x".format(it) }
                if (prefs.getBoolean(digest, false)) return@runOnUiThread
                val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
                val pendingIntent = launchIntent?.let {
                    PendingIntent.getActivity(this@MainActivity, digest.hashCode(), it, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                }
                val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(context, channelId) else Notification.Builder(context)
                builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(Notification.BigTextStyle().bigText(body))
                    .setAutoCancel(true)
                    .setCategory(Notification.CATEGORY_STATUS)
                if (pendingIntent != null) builder.setContentIntent(pendingIntent)
                val notificationId = digest.hashCode()
                getSystemService(NotificationManager::class.java).notify(notificationId, builder.build())
                prefs.edit().putBoolean(digest, true).apply()
            }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.removeJavascriptInterface("AndroidNotifications")
            webView.destroy()
        }
        super.onDestroy()
    }
}
