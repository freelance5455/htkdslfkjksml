plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.binancescanner"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.binancescanner"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "87.0"
    }
}
