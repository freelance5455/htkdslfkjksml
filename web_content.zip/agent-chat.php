<?php
declare(strict_types=1);
require_once __DIR__.'/app/bootstrap.php';
workspace_legacy_redirect('agents/chat.php');
require_once __DIR__.'/app/agent.php';
$u=auth_require_user();
agent_schema();
$id=(int)($_GET['id']??0);
$agent=agent_owned($id,(int)$u['id']);
if($agent['publication_state']!=='published'){http_response_code(403);exit('This agent must be published before conversations can start.');}
$pageTitle='AI Agent Conversation';
$csrf=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8');
$agentName=htmlspecialchars((string)$agent['name'],ENT_QUOTES,'UTF-8');
require __DIR__.'/app/platform_header.php';
?>
<link rel="stylesheet" href="assets/agent-studio.css?v=1.4.0">
<link rel="stylesheet" href="assets/agent-chat.css?v=1.0.0">
<main class="anx-chat-shell" id="anxAgentChat">
 <header class="anx-chat-heading">
  <div><span class="agent-kicker">ANONYMOUX STUDIOS / AI AGENT</span><h1>AI Assistant</h1><p>Your intelligent creative companion. Continue by text or switch to voice at any time.</p></div>
  <div class="anx-agent-online"><i></i><span>Agent ready</span></div>
 </header>
 <div class="anx-chat-layout">
  <aside class="anx-chat-sidebar">
   <a class="agent-secondary anx-back" href="agents/">← Agent Studio</a>
   <button type="button" class="agent-primary anx-new-chat" id="newConversation">＋ New conversation</button>
   <div class="anx-history-heading"><b>Recent conversations</b><button type="button" id="refreshHistory" aria-label="Refresh history">↻</button></div>
   <nav id="conversationHistory" class="anx-history-list" aria-label="Conversation history"><p class="agent-form-hint">Loading conversations…</p></nav>
   <div class="anx-sidebar-agent"><span class="anx-agent-avatar">✦</span><div><b><?=$agentName?></b><small>Published AI agent</small></div></div>
  </aside>
  <section class="agent-conversation-panel anx-chat-panel" id="chatPanel">
   <div class="anx-chat-top"><div><span class="agent-kicker">YOUR ASSISTANT</span><h2><?=$agentName?></h2><p id="conversationSubhead">A new conversation is ready</p></div><span class="agent-live-state" id="voiceStatus">READY</span></div>
   <div id="chatMessages" class="agent-chat-feed anx-chat-feed" aria-live="polite"><div class="agent-chat-empty"><span>✦</span><b>Hello! What would you like to create today?</b><small>Ask a question, plan a project, or start a voice conversation.</small></div></div>
   <div class="anx-voice-dock" id="voiceDock" hidden>
    <div class="anx-voice-orb" id="voiceOrb"><span>◉</span></div>
    <div class="anx-voice-copy"><b id="voiceModeTitle">Voice conversation</b><small id="voiceModeHint">Ready to listen</small></div>
    <div class="anx-voice-tools"><label class="anx-speech-voice" id="speechVoiceWrap" hidden><span>Voice</span><select id="speechVoice" aria-label="Choose speech voice"><option value="">System default voice</option></select></label><label class="anx-speech-voice"><span>Language</span><select id="speechLanguage" aria-label="Speech recognition language"><option value="en-US">English</option><option value="en-GB">English (UK)</option><option value="en-NG">English (Nigeria)</option><option value="fr-FR">French</option><option value="es-ES">Spanish</option><option value="ar-SA">Arabic</option></select></label><button type="button" class="agent-secondary" id="interruptSpeech" title="Stop speaking">■</button><button type="button" class="agent-secondary" id="muteVoice" aria-pressed="false">Mute</button><button type="button" class="agent-secondary" id="stopVoice">End voice</button></div>
   </div>
   <div class="anx-composer-wrap">
    <textarea id="chatInput" rows="1" placeholder="Message your AI assistant…" aria-label="Write a message"></textarea>
    <div class="anx-composer-bottom"><span>Enter to send · Shift + Enter for a new line</span><div><button type="button" class="agent-secondary" id="startVoice">◉ Voice</button><button class="agent-primary" id="sendText" type="button">Send ↗</button></div></div>
   </div>
   <div class="anx-chat-foot"><span id="chatError" role="status" aria-live="polite"></span><button class="agent-secondary" id="retryUsage" type="button" hidden>Retry usage reconciliation</button></div>
  </section>
 </div>
 <p class="anx-chat-disclaimer">Voice availability depends on your browser and the configured Fish Audio agent. If live voice cannot connect, the page can use browser speech recognition and speech synthesis as a clearly labelled fallback.</p>
</main>
<script>window.ANON_AGENT_ID=<?=$id?>;window.ANON_AGENT_CSRF=<?=$csrf?>;</script>
<script type="module" src="assets/agent-chat.js?v=1.1.0"></script>
<?php require __DIR__.'/app/platform_footer.php'; ?>
