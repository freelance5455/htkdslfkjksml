# V81 — Excel Preview-First Fix

This version fixes the Excel import workflow at the web/HTML level rather than relying on custom Android URL schemes or the AndroidDPM bridge.

Changes:
- Choose File now uses the standard HTML file input (`input[type=file]`) directly.
- Removed the `https://dpm.local/pick` command from the web UI.
- Download Excel template now uses an embedded copy of the bundled XLSX template and a normal download action, avoiding `dpm-template://`.
- XLSX parsing now tries the existing SheetJS loader first. The previous code defined `loadXLSX()` but did not use it for normal XLSX files.
- Existing offline XLSX parser remains as fallback.
- Android native code, Supabase, Balance, Banked, Productive Days, login, and permissions are otherwise left intact.
