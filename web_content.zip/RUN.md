# NIVEX V3.2 — Run guide

## Development
Requires Node 20.19+.

```bash
npm install
npm run dev
```

Build:

```bash
npm run build
```

Diagnostics:

```bash
npm run doctor
npm test
```

## Supplied Vite source
The uploaded source archive was inspected. `create-vite` 9.2.1 and its package metadata are preserved under `vendor/create-vite-9.2.1/`; the Vite package is pinned at 8.3.0 in `package.json`, with its core dependency set recorded explicitly.

## AI builder workflow
Open the repository in Cursor or Windsurf for code changes. Bolt.new, Lovable and Muse can be used for UI/design exploration. None of these services is required for the shipped runtime.
