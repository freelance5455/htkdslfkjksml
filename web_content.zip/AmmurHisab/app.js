"use strict";

const KEY = "ammurhisab_transactions_v2";
const BUDGET_KEY = "ammurhisab_monthly_budget_v1";
const THEME_KEY = "ammurhisab_theme_v1";
const QUOTE_KEY = "ammurhisab_quotes_enabled_v1";
const $ = id => document.getElementById(id);

let transactions = [];
let currentFilter = "all";
let editingId = null;
let quoteIndex = -1;
let quoteTimer = null;
let toastTimer = null;

const quotes = [
  "ফ্রি ফায়ার খেলা পাপ — আম্মু! 😄",
  "ও ধ্বংসের শেষ প্রান্তে পৌঁছে গেছে! 😂",
  "আমি ওর বিষয়ে কিচ্ছু জানি না! 🙈",
  "আমার আর এ বিষয়ে কোনো ফেইথ নাই! 😏",
  "হিসাব দাও, গল্প পরে হবে! 🧾",
  "টাকা কি গাছে ধরে নাকি? 🌳",
  "আম্মুর হিসাবের খাতা সব মনে রাখে! 👀",
  "খরচের হিসাব কোথায়, জনাব? 🧐",
  "বাজেট আছে, বাহাদুরি কমাও! 😆",
  "ব্যালেন্স দেখেই আসল সত্য জানা যায়! 😅"
];

const categories = ["খাবার","পড়াশোনা","যাতায়াত","বাজার","গেমিং","বিল","বেতন/অন্যান্য আয়","ধার/ফেরত","অন্যান্য"];
const categoryColors = ["#77bfc3","#78a9d1","#d7a6ba","#9b9cdb","#e5bd77","#84b89c","#79a9b8","#c49bda","#a5b4bd"];

function localDate(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`;
}
function money(paisa) {
  return "৳ " + (paisa / 100).toLocaleString("en-BD",{minimumFractionDigits:2,maximumFractionDigits:2});
}
function parseMoney(value) {
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0 || n > 100000000) return null;
  const p = Math.round((n + Number.EPSILON) * 100);
  return Number.isSafeInteger(p) && p > 0 ? p : null;
}
function showToast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}
function safeLoad() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || !parsed.every(validTransaction)) {
      showToast("সংরক্ষিত ডেটা যাচাই করা যায়নি। ব্যাকআপ পরীক্ষা করো।");
      return [];
    }
    return parsed;
  } catch {
    showToast("সংরক্ষিত হিসাব পড়া যায়নি।");
    return [];
  }
}
function validTransaction(t) {
  return t && typeof t.id === "string" &&
    (t.type === "income" || t.type === "expense") &&
    Number.isSafeInteger(t.paisa) && t.paisa > 0 &&
    typeof t.category === "string" && t.category.length <= 80 &&
    typeof t.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(t.date) &&
    typeof t.note === "string" && t.note.length <= 120 &&
    Number.isFinite(t.createdAt);
}
function saveAll() {
  try { localStorage.setItem(KEY, JSON.stringify(transactions)); return true; }
  catch { showToast("ডেটা সেভ হয়নি। জায়গা/ব্রাউজার স্টোরেজ পরীক্ষা করো।"); return false; }
}
function budgetValue() {
  try {
    const n = Number(localStorage.getItem(BUDGET_KEY) || 0);
    return Number.isFinite(n) && n > 0 ? Math.round(n * 100) : 0;
  } catch { return 0; }
}
function monthKey(date) { return date.slice(0,7); }
function monthItems(key = localDate().slice(0,7)) {
  return transactions.filter(t => monthKey(t.date) === key);
}
function sumType(items, type) {
  return items.reduce((sum,t) => sum + (t.type === type ? t.paisa : 0), 0);
}
function svgUse(name, cls = "icon") {
  const svg = document.createElementNS("http://www.w3.org/2000/svg","svg");
  svg.setAttribute("class",cls);
  svg.setAttribute("aria-hidden","true");
  const use = document.createElementNS("http://www.w3.org/2000/svg","use");
  use.setAttribute("href",`#i-${name}`);
  svg.append(use);
  return svg;
}
function createEl(tag, cls, text) {
  const el = document.createElement(tag);
  if (cls) el.className = cls;
  if (text !== undefined) el.textContent = text;
  return el;
}
function sortedItems(items = transactions) {
  return [...items].sort((a,b) => b.date.localeCompare(a.date) || b.createdAt-a.createdAt);
}

function render() {
  const income = sumType(transactions,"income");
  const expense = sumType(transactions,"expense");
  $("income").textContent = money(income);
  $("expense").textContent = money(expense);
  $("balance").textContent = money(income-expense);
  $("todayDate").textContent = new Intl.DateTimeFormat("bn-BD",{day:"numeric",month:"short"}).format(new Date());
  renderTransactionLists();
  renderCategoryChart();
  renderBudget();
  renderAnalytics();
}
function buildTransaction(item) {
  const row = createEl("article","transaction");
  const iconBox = createEl("div","tx-icon");
  iconBox.append(svgUse(item.type === "income" ? "download" : "receipt"));
  const info = createEl("div","tx-info");
  info.append(createEl("strong","",item.category));
  const meta = createEl("small","",item.note ? `${item.date} · ${item.note}` : item.date);
  info.append(meta);
  const right = createEl("div","tx-right");
  const amount = createEl("span",`tx-amount ${item.type === "income" ? "income-text" : "expense-text"}`,
    `${item.type === "income" ? "+" : "−"}${money(item.paisa)}`);
  const actions = createEl("div","tx-actions");
  const edit = createEl("button","mini-action");
  edit.type = "button"; edit.setAttribute("aria-label","সম্পাদনা"); edit.append(svgUse("edit"));
  edit.addEventListener("click",() => openEditor(item.id));
  const del = createEl("button","mini-action");
  del.type = "button"; del.setAttribute("aria-label","মুছে ফেলুন"); del.append(svgUse("trash"));
  del.addEventListener("click",() => deleteTransaction(item.id));
  actions.append(edit,del);
  right.append(amount,actions);
  row.append(iconBox,info,right);
  return row;
}
function renderTransactionLists() {
  const recent = $("recentList");
  recent.replaceChildren();
  const latest = sortedItems().slice(0,4);
  if (!latest.length) recent.append(createEl("p","empty-state","এখনো কোনো হিসাব যোগ করা হয়নি। প্রথম লেনদেনটি যোগ করো।"));
  latest.forEach(t => recent.append(buildTransaction(t)));

  const list = $("transactionList");
  list.replaceChildren();
  const query = $("search").value.trim().toLocaleLowerCase();
  const filtered = sortedItems().filter(t => {
    const typeMatches = currentFilter === "all" || t.type === currentFilter;
    const haystack = `${t.category} ${t.note} ${t.date}`.toLocaleLowerCase();
    return typeMatches && haystack.includes(query);
  });
  $("emptyState").classList.toggle("hidden",filtered.length !== 0);
  $("emptyState").textContent = query || currentFilter !== "all"
    ? "এই খোঁজের সঙ্গে মেলে এমন কোনো হিসাব নেই।"
    : "এখনো কোনো লেনদেন নেই। + বাটনে চাপ দিয়ে যোগ করো।";
  filtered.forEach(t => list.append(buildTransaction(t)));
}
function renderCategoryChart() {
  const root = $("categoryChart");
  root.replaceChildren();
  const expenses = transactions.filter(t => t.type === "expense");
  const total = sumType(expenses,"expense");
  if (!total) {
    root.append(createEl("p","empty-state","এখনো খরচের ডেটা নেই। খরচ যোগ করলে ক্যাটাগরি চার্ট এখানে দেখা যাবে।"));
    return;
  }
  const sums = new Map();
  expenses.forEach(t => sums.set(t.category,(sums.get(t.category)||0)+t.paisa));
  [...sums.entries()].sort((a,b)=>b[1]-a[1]).slice(0,6).forEach(([name,value]) => {
    const row = createEl("div","category-row");
    row.append(createEl("span","category-name",name));
    const track = createEl("div","track");
    const fill = createEl("div","track-fill");
    fill.style.width = `${Math.max(2,value/total*100)}%`;
    fill.style.background = categoryColors[categories.indexOf(name)%categoryColors.length] || categoryColors[8];
    track.append(fill);
    row.append(track,createEl("span","category-value",money(value)));
    root.append(row);
  });
}
function renderBudget() {
  const root = $("budgetSummary");
  root.replaceChildren();
  const budget = budgetValue();
  const spent = sumType(monthItems(),"expense");
  if (!budget) {
    root.append(createEl("p","budget-help","এখনো মাসিক বাজেট সেট করা হয়নি। সেটিংস থেকে বাজেট যোগ করো।"));
    return;
  }
  const pct = spent / budget * 100;
  const top = createEl("div","budget-copy");
  top.append(createEl("span","muted",`খরচ ${money(spent)}`),createEl("strong","",`${Math.round(pct)}%`));
  const track = createEl("div","budget-track");
  const fill = createEl("div",`budget-fill${pct>100?" over":""}`);
  fill.style.width = `${Math.min(100,pct)}%`;
  track.append(fill);
  root.append(top,track,createEl("p","budget-help",pct>100
    ? `বাজেট ${money(budget)} ছাড়িয়েছে ${money(spent-budget)}।`
    : `বাজেট বাকি ${money(budget-spent)}।`));
}
function renderAnalytics() {
  const month = monthItems();
  const inc = sumType(month,"income");
  const exp = sumType(month,"expense");
  $("monthIncome").textContent = money(inc);
  $("monthExpense").textContent = money(exp);
  $("monthNet").textContent = money(inc-exp);
  $("txCount").textContent = String(transactions.length);

  const chart = $("monthlyChart");
  chart.replaceChildren();
  const months = [];
  const now = new Date();
  for (let i=5;i>=0;i--) {
    const d = new Date(now.getFullYear(),now.getMonth()-i,1);
    months.push({key:localDate(d).slice(0,7),label:new Intl.DateTimeFormat("bn-BD",{month:"short"}).format(d)});
  }
  const vals = months.map(m => sumType(transactions.filter(t=>monthKey(t.date)===m.key),"expense"));
  const max = Math.max(...vals,1);
  months.forEach((m,i) => {
    const wrap = createEl("div","month-bar-wrap");
    wrap.append(createEl("span","month-value",vals[i] ? compactMoney(vals[i]) : "—"));
    const bar = createEl("div","month-bar");
    bar.style.height = `${Math.max(3,vals[i]/max*100)}%`;
    bar.title = `${m.label}: ${money(vals[i])}`;
    wrap.append(bar,createEl("span","month-label",m.label));
    chart.append(wrap);
  });

  const report = $("analyticsCategories");
  report.replaceChildren();
  const sums = new Map();
  transactions.filter(t=>t.type==="expense").forEach(t=>sums.set(t.category,(sums.get(t.category)||0)+t.paisa));
  const total = [...sums.values()].reduce((a,b)=>a+b,0);
  if (!total) {
    report.append(createEl("p","empty-state","খরচের ক্যাটাগরি রিপোর্ট দেখাতে আগে খরচ যোগ করো।"));
    return;
  }
  [...sums.entries()].sort((a,b)=>b[1]-a[1]).forEach(([name,value])=>{
    const row = createEl("div","report-row");
    const top = createEl("div","report-top");
    top.append(createEl("span","",name),createEl("span","",`${money(value)} · ${Math.round(value/total*100)}%`));
    const track = createEl("div","track");
    const fill = createEl("div","track-fill");
    fill.style.width = `${value/total*100}%`;
    fill.style.background = categoryColors[categories.indexOf(name)] || categoryColors[8];
    track.append(fill); row.append(top,track); report.append(row);
  });
}
function compactMoney(paisa) {
  const n = paisa/100;
  return n >= 100000 ? `৳${(n/100000).toFixed(1)}L` : n >= 1000 ? `৳${(n/1000).toFixed(1)}k` : `৳${Math.round(n)}`;
}
function openEditor(id = null, quickType = "expense") {
  editingId = id;
  const form = $("entryForm");
  form.reset();
  const item = id ? transactions.find(t=>t.id===id) : null;
  $("dialogTitle").textContent = item ? "হিসাব সম্পাদনা" : "নতুন হিসাব";
  $("type").value = item ? item.type : quickType;
  $("amount").value = item ? (item.paisa/100).toFixed(2) : "";
  $("category").value = item ? item.category : (quickType==="income" ? "বেতন/অন্যান্য আয়" : "খাবার");
  $("date").value = item ? item.date : localDate();
  $("note").value = item ? item.note : "";
  $("entryDialog").showModal();
  setTimeout(()=>$("amount").focus(),100);
}
function submitEntry(event) {
  event.preventDefault();
  const paisa = parseMoney($("amount").value);
  if (!paisa) { showToast("সঠিক টাকার পরিমাণ লিখো।"); return; }
  const type = $("type").value;
  const date = $("date").value;
  const category = $("category").value;
  const note = $("note").value.trim();
  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) { showToast("সঠিক তারিখ বেছে নাও।"); return; }
  const old = editingId ? transactions.find(t=>t.id===editingId) : null;
  const item = {id:old ? old.id : (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`),type,paisa,date,category,note,createdAt:old ? old.createdAt : Date.now(),updatedAt:Date.now()};
  const previous = transactions;
  transactions = old ? transactions.map(t=>t.id===old.id?item:t) : [...transactions,item];
  if (!saveAll()) { transactions = previous; return; }
  $("entryDialog").close();
  editingId = null;
  render();
  showToast(old ? "হিসাব আপডেট হয়েছে।" : type==="income" ? "আয়ের হিসাব যোগ হয়েছে।" : "খরচ যোগ হয়েছে।");
}
function deleteTransaction(id) {
  const item = transactions.find(t=>t.id===id);
  if (!item || !confirm(`“${item.category}” হিসাবটি মুছে ফেলবে?`)) return;
  const previous = transactions;
  transactions = transactions.filter(t=>t.id!==id);
  if (!saveAll()) { transactions = previous; return; }
  render();
  showToast("হিসাব মুছে ফেলা হয়েছে।");
}
function goToPage(pageId) {
  document.querySelectorAll(".page").forEach(p=>p.classList.toggle("hidden",p.id!==pageId));
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===pageId));
  $("addFab").classList.toggle("hidden",pageId==="settingsPage");
  if (pageId==="settingsPage") {
    const b=budgetValue();
    $("budgetInput").value=b ? (b/100).toFixed(2) : "";
  }
  window.scrollTo({top:0,behavior:"smooth"});
}
function toggleTheme() {
  const dark = !document.body.classList.contains("dark");
  document.body.classList.toggle("dark",dark);
  const icon = dark ? "sun" : "moon";
  $("themeBtn").replaceChildren(svgUse(icon));
  $("settingsThemeBtn").replaceChildren(svgUse(icon),document.createTextNode(dark?" Light থিম":" Dark থিম"));
  try { localStorage.setItem(THEME_KEY,dark?"dark":"light"); } catch {}
}
function loadTheme() {
  let dark=false;
  try { dark=localStorage.getItem(THEME_KEY)==="dark"; } catch {}
  document.body.classList.toggle("dark",dark);
  $("themeBtn").replaceChildren(svgUse(dark?"sun":"moon"));
  $("settingsThemeBtn").replaceChildren(svgUse(dark?"sun":"moon"),document.createTextNode(dark?" Light থিম":" Dark থিম"));
}
function nextQuote() {
  if (!getQuotesEnabled()) return;
  let next=Math.floor(Math.random()*quotes.length);
  if (quotes.length>1) while(next===quoteIndex) next=Math.floor(Math.random()*quotes.length);
  quoteIndex=next;
  const el=$("quoteText");
  el.classList.add("fade-out");
  setTimeout(()=>{el.textContent=quotes[quoteIndex];el.classList.remove("fade-out");},350);
}
function getQuotesEnabled() {
  try { return localStorage.getItem(QUOTE_KEY)!=="false"; } catch { return true; }
}
function setQuoteEnabled(enabled) {
  try { localStorage.setItem(QUOTE_KEY,String(enabled)); } catch {}
  $("quoteText").parentElement.classList.toggle("hidden",!enabled);
  if (quoteTimer) clearInterval(quoteTimer);
  quoteTimer=enabled ? setInterval(nextQuote,9000) : null;
  if (enabled) nextQuote();
}
function downloadFile(filename,content,type) {
  const blob=new Blob([content],{type});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a");a.href=url;a.download=filename;
  document.body.append(a);a.click();a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),1200);
}
function exportJSON() {
  const backup={app:"AmmurHisab",version:2,exportedAt:new Date().toISOString(),transactions};
  downloadFile(`ammur-hisab-backup-${localDate()}.json`,JSON.stringify(backup,null,2),"application/json;charset=utf-8");
  showToast("JSON ব্যাকআপ তৈরি হয়েছে।");
}
function importJSON(file) {
  if (!file) return;
  const reader=new FileReader();
  reader.onload=()=>{
    try {
      const data=JSON.parse(reader.result);
      const incoming=Array.isArray(data)?data:data.transactions;
      if (!Array.isArray(incoming)||!incoming.every(validTransaction)) throw new Error("invalid");
      if (!confirm(`ব্যাকআপে ${incoming.length}টি লেনদেন আছে। এটি বর্তমান লেনদেন প্রতিস্থাপন করবে। চালিয়ে যাবে?`)) return;
      const previous=transactions;transactions=incoming;
      if (!saveAll()) {transactions=previous;return;}
      render();showToast("ব্যাকআপ ফেরত আনা হয়েছে।");
    } catch { showToast("ফাইলটি সঠিক JSON ব্যাকআপ নয়।"); }
    finally { $("importFile").value=""; }
  };
  reader.onerror=()=>showToast("ফাইল পড়া যায়নি।");
  reader.readAsText(file);
}
function csvCell(v) { return `"${String(v).replace(/"/g,'""')}"`; }
function exportCSV() {
  const rows=[["তারিখ","ধরন","ক্যাটাগরি","টাকার পরিমাণ","বিবরণ"],...sortedItems().map(t=>[t.date,t.type==="income"?"আয়":"খরচ",t.category,(t.paisa/100).toFixed(2),t.note])];
  const csv="\uFEFF"+rows.map(r=>r.map(csvCell).join(",")).join("\r\n");
  downloadFile(`ammur-hisab-${localDate()}.csv`,csv,"text/csv;charset=utf-8");
  showToast("CSV ফাইল তৈরি হয়েছে।");
}
function bindEvents() {
  document.querySelectorAll("[data-page]").forEach(btn=>btn.addEventListener("click",()=>goToPage(btn.dataset.page)));
  document.querySelectorAll("[data-quick]").forEach(btn=>btn.addEventListener("click",()=>openEditor(null,btn.dataset.quick)));
  document.querySelectorAll("[data-filter]").forEach(btn=>btn.addEventListener("click",()=>{
    currentFilter=btn.dataset.filter;
    document.querySelectorAll("[data-filter]").forEach(b=>b.classList.toggle("active",b===btn));
    renderTransactionLists();
  }));
  $("addFab").addEventListener("click",()=>openEditor());
  $("closeDialog").addEventListener("click",()=>$("entryDialog").close());
  $("entryForm").addEventListener("submit",submitEntry);
  $("search").addEventListener("input",renderTransactionLists);
  $("themeBtn").addEventListener("click",toggleTheme);
  $("settingsThemeBtn").addEventListener("click",toggleTheme);
  $("saveBudget").addEventListener("click",()=>{
    const value=Number($("budgetInput").value);
    if (!Number.isFinite(value)||value<0||value>100000000) {showToast("সঠিক বাজেট লিখো।");return;}
    try { if(value===0)localStorage.removeItem(BUDGET_KEY);else localStorage.setItem(BUDGET_KEY,String(value)); }
    catch {showToast("বাজেট সেভ করা যায়নি।");return;}
    renderBudget();showToast(value===0?"বাজেট সরানো হয়েছে।":"মাসিক বাজেট সেভ হয়েছে।");
  });
  $("exportBtn").addEventListener("click",exportJSON);
  $("importBtn").addEventListener("click",()=>$("importFile").click());
  $("importFile").addEventListener("change",e=>importJSON(e.target.files[0]));
  $("csvBtn").addEventListener("click",exportCSV);
  $("quotesToggle").checked=getQuotesEnabled();
  $("quotesToggle").addEventListener("change",e=>setQuoteEnabled(e.target.checked));
  $("entryDialog").addEventListener("click",e=>{if(e.target===$("entryDialog"))$("entryDialog").close();});
}
function startApp() {
  transactions=safeLoad();
  loadTheme();
  bindEvents();
  $("date").value=localDate();
  render();
  if (getQuotesEnabled()) {
    $("quoteText").textContent=quotes[0];
    quoteTimer=setInterval(nextQuote,9000);
  } else $("quoteText").parentElement.classList.add("hidden");
  setTimeout(()=>{$("splash").classList.add("hidden");$("app").classList.remove("hidden");},1100);
  if ("serviceWorker" in navigator && (location.protocol==="https:"||location.hostname==="localhost")) {
    navigator.serviceWorker.register("./sw.js").catch(()=>{});
  }
}
startApp();
