STARLETTE LAB — Android Studio Project

Is ZIP mein aapki Offline Pathology LIS HTML file ko Android WebView app ke roop mein package kiya gaya hai.

Features included:
- Offline HTML app (internet ki zaroorat nahi)
- JavaScript aur local browser storage enabled
- Lab setup aur reference ranges local device par save
- Patient entry, report generation aur history (HTML app ke existing features)
- Android native print dialog integration; wahan Save as PDF choose karein

IMPORTANT / BUILD STATUS:
Yeh Android Studio source project hai, compiled/tested APK nahi. Is environment mein Android SDK/Gradle build tool available nahi tha, isliye main verified APK banne ka dawa nahi kar sakta.

APK banane ke liye:
1. ZIP ko Android Studio wale computer par extract karein.
2. Android Studio mein StarletteLab folder open karein.
3. Gradle sync complete hone dein (internet aur Android SDK required).
4. Build > Build Bundle(s) / APK(s) > Build APK(s) choose karein.
5. APK app/build/outputs/apk/debug/app-debug.apk mein milega.

Clinical safety:
Default reference ranges examples hain. Apne lab ke method/analyzer aur patient demographics ke mutabik qualified lab personnel se verify karna zaroori hai. Patient data is device/browser storage mein rahega; app data clear/uninstall hone par data loss ho sakta hai. Regular backup rakhein.
