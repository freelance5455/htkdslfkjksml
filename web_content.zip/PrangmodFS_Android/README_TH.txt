PrangmodFS Android Project (ต้นแบบ UI)
======================================

สิ่งที่มี:
- แอป Android แบบ WebView ชื่อ PrangmodFS
- หน้าจอเลือกไฟล์ ZIP และปุ่มตรวจ/แปลงต้นแบบ
- ทำงานแบบออฟไลน์ในหน้าจอ

ข้อจำกัด:
- นี่เป็นโปรเจกต์ต้นทาง ไม่ใช่ไฟล์ APK ที่ติดตั้งได้ทันที
- ปุ่มตรวจยังไม่ได้อ่านเนื้อหา ZIP จริง
- ปุ่มแปลงยังไม่ได้แก้ไข/สร้างไฟล์มอด FS20
- ต้องสร้าง APK ด้วย Android Studio และติดตั้ง Android SDK/Gradle ที่เข้ากันได้

วิธีสร้าง APK:
1. เปิดโฟลเดอร์ PrangmodFS_Android ด้วย Android Studio
2. รอ Gradle Sync และติดตั้ง SDK ที่ระบบร้องขอ
3. เลือก Build > Build APK(s)
4. ไฟล์ APK มักอยู่ที่ app/build/outputs/apk/debug/app-debug.apk

แนะนำให้สำรองมอดต้นฉบับก่อนทดลองทุกครั้ง
