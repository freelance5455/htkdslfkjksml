"""
School attendance SMS backend starter.
IMPORTANT:
- This is a safe integration scaffold, NOT a working ZudSMS adapter yet.
- Obtain the official API URL, auth method, request fields and sender approval from ZudSMS.
- Keep API secrets on the server in environment variables. Never place them in the Android/HTML app.
"""
import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="School Attendance SMS Gateway")

class SMSRequest(BaseModel):
    phone: str = Field(min_length=8, max_length=20)
    text: str = Field(min_length=1, max_length=1000)
    student: str = Field(min_length=1, max_length=120)
    status: str
    date: str

@app.get("/health")
def health():
    return {"ok": True, "provider_configured": bool(os.getenv("ZUDSMS_API_URL") and os.getenv("ZUDSMS_API_TOKEN"))}

@app.post("/api/send-sms")
def send_sms(req: SMSRequest):
    api_url = os.getenv("ZUDSMS_API_URL")
    api_token = os.getenv("ZUDSMS_API_TOKEN")
    sender = os.getenv("ZUDSMS_SENDER")
    if not api_url or not api_token or not sender:
        raise HTTPException(
            status_code=503,
            detail="ZudSMS танзим нашудааст. API URL, API token ва sender-и тасдиқшуда аз провайдер лозим аст."
        )

    # ZudSMS's current public landing page confirms REST API availability,
    # but the exact endpoint and payload are not publicly described there.
    # Implement the provider-specific request here after receiving its API documentation.
    raise HTTPException(
        status_code=501,
        detail="Ҳоло адаптери ZudSMS ба API-и расмӣ пайваст нашудааст. Документацияи техникӣ лозим аст."
    )
