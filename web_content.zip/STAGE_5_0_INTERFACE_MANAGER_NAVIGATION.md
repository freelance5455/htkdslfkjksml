# CGD V117 — Socle 5.0, étape A : navigation Manager Galactique

## Objectif
Poser le premier socle visuel de l'interface inspirée des jeux de management sportif, sans remplacer les moteurs métier ni supprimer les écrans historiques.

## Réalisé
- En-tête CGD V117 retravaillé avec identité bleu nuit / or.
- Barre de navigation horizontale à défilement, adaptée au téléphone en paysage et utilisable au doigt.
- Présence des 18 rubriques principales du cahier des charges.
- Navigation raccordée aux écrans existants : accueil/carrière, club, damistes, recherche/academie, compétitions/sélections, arène/matchs/tactiques, messagerie/médias et réglages.
- État actif visuel propre à la rubrique sélectionnée.
- Transitions légères et respect du réglage système « réduire les animations ».
- Conservation des modules sportifs, du moteur de dames, de l'IA, des sauvegardes et de l'éditeur d'identité existants.

## Limites connues de cette étape
Les rubriques qui partagent actuellement un même écran sont des points d'entrée provisoires vers les fonctionnalités existantes. Les sous-menus spécialisés (par exemple académie, staff, finances détaillées, infrastructures et historique complet) restent à construire dans les étapes suivantes. La maquette de tableau de bord complète n'est pas encore reproduite : cette étape établit d'abord la coque et la navigation.

## Vérification
- Suite automatisée : 240 tests réussis, 0 échec.
- Vérification statique de la navigation : 18 liens principaux déclarés.
- Tests visuels réels sur plusieurs téléphones : à effectuer avant validation finale de compatibilité.

## Protection du patrimoine
Aucune donnée de club, de damiste, de compétition ou de carrière n'a été volontairement supprimée. Les changements sont limités à la présentation générale et au routage visuel des rubriques.
