DYNAMIC GOOGLE SHEETS EDITOR — ANDROID SOURCE PACKAGE

What it does
- Android app with dynamic Google Sheets URL entry
- Google account authorization using the native Google Identity authorization flow
- Loads worksheet names, headings and values using Google Sheets API
- Builds a searchable table and a popup editor for every record
- Saves the edited row back into the original worksheet
- No website hosting, GitHub, or Apps Script is used

IMPORTANT SETUP REQUIRED BEFORE BUILDING
This package is source code, not a precompiled APK. Google requires an OAuth configuration for the app to access private/editable Sheets.

1. Open this project in Android Studio.
2. In Google Cloud Console, create/select a project and enable Google Sheets API.
3. Configure OAuth consent screen and add the Google account(s) that will use the app as test users if the app remains in testing.
4. Create an Android OAuth client using package name: com.gondal.sheetedit and the SHA-1 signing certificate fingerprint of the build key.
5. Ensure the authorization configuration allows the Sheets scope: https://www.googleapis.com/auth/spreadsheets
6. Build and install the APK. Sign in with an account that has Editor access to the target spreadsheet.

Use
- Paste any Google Sheets URL the signed-in account can edit.
- The first worksheet row is treated as headings; tap any subsequent row to edit.
- Use the worksheet dropdown to switch tabs.
- Save updates that row in the original sheet.

Limitations
- Google Sheets must be accessible to the Google account used in the app; a URL by itself does not grant write access.
- This initial version edits existing rows and does not add/delete rows or change formatting/formulas intentionally.
- It treats the first row as column headings. Sheets with title rows above the headings need adjustment.
- This package has not been compiled or tested on a device in this environment; complete the OAuth setup and test on a copy of the spreadsheet before operational use.
