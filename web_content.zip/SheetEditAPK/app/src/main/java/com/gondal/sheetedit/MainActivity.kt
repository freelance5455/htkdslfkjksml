package com.gondal.sheetedit

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.util.Base64
import android.webkit.*
import android.widget.Toast
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val client = OkHttpClient()
    private val executor = Executors.newSingleThreadExecutor()
    private var accessToken: String? = null
    private var pendingSheetId: String? = null
    private var sheetTitle = ""
    private var sheetNames = mutableListOf<String>()
    private var selectedTab = ""
    private var values = JSONArray()
    private val scope = Scope("https://www.googleapis.com/auth/spreadsheets")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun authorizeAndLoad(url: String) {
            val id = Regex("/spreadsheets/d/([a-zA-Z0-9_-]+)").find(url)?.groupValues?.get(1)
            if (id == null) { sendError("Please enter a valid Google Sheets URL."); return }
            pendingSheetId = id
            runOnUiThread {
                val request = AuthorizationRequest.builder().setRequestedScopes(listOf(scope)).build()
                Identity.getAuthorizationClient(this@MainActivity).authorize(request)
                    .addOnSuccessListener { result ->
                        if (result.hasResolution()) {
                            try { startIntentSenderForResult(result.pendingIntent!!.intentSender, 2001, null, 0, 0, 0) }
                            catch (e: Exception) { sendError("Authorization could not be started: ${e.message}") }
                        } else { accessToken = result.accessToken; loadSpreadsheet() }
                    }
                    .addOnFailureListener { sendError("Google authorization failed. Check account access and API setup: ${it.message}") }
            }
        }

        @JavascriptInterface fun reload() { loadSpreadsheet() }

        @JavascriptInterface fun selectTab(tab: String) { if (tab in sheetNames) { selectedTab = tab; loadSpreadsheet() } }

        @JavascriptInterface fun saveRow(rowIndex: Int, rowJson: String) {
            val token = accessToken; val id = pendingSheetId; val tab = selectedTab
            if (token == null || id == null || tab.isBlank()) { sendError("Load a sheet and authorize first."); return }
            try {
                val row = JSONArray(rowJson)
                val endCol = columnName(row.length())
                val range = "'${tab.replace("'", "''")}'!A${rowIndex + 1}:${endCol}${rowIndex + 1}"
                val body = JSONObject().put("range", range).put("majorDimension", "ROWS").put("values", JSONArray().put(row))
                val request = Request.Builder().url("https://sheets.googleapis.com/v4/spreadsheets/$id/values/${enc(range)}?valueInputOption=USER_ENTERED")
                    .put(body.toString().toRequestBody("application/json".toMediaType()))
                    .header("Authorization", "Bearer $token").build()
                executor.execute {
                    try {
                        client.newCall(request).execute().use { response ->
                            if (!response.isSuccessful) sendError("Save failed (${response.code}): ${response.body?.string()?.take(300)}")
                            else { sendJs("saveSuccess()") ; loadSpreadsheet() }
                        }
                    } catch (e: Exception) { sendError("Save failed: ${e.message}") }
                }
            } catch (e: Exception) { sendError("Invalid row data: ${e.message}") }
        }

        @JavascriptInterface fun toast(message: String) { runOnUiThread { Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show() } }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2001 && resultCode == Activity.RESULT_OK && data != null) {
            Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data)
                .addOnSuccessListener { accessToken = it.accessToken; loadSpreadsheet() }
                .addOnFailureListener { sendError("Authorization failed: ${it.message}") }
        } else if (requestCode == 2001) sendError("Google authorization was cancelled.")
    }

    private fun loadSpreadsheet() {
        val id = pendingSheetId ?: return
        val token = accessToken ?: return
        executor.execute {
            try {
                val metaReq = Request.Builder().url("https://sheets.googleapis.com/v4/spreadsheets/$id?fields=properties.title,sheets.properties.title")
                    .header("Authorization", "Bearer $token").build()
                client.newCall(metaReq).execute().use { r ->
                    if (!r.isSuccessful) throw IOException("Cannot read spreadsheet (${r.code}): ${r.body?.string()?.take(250)}")
                    val meta = JSONObject(r.body!!.string()); sheetTitle = meta.optJSONObject("properties")?.optString("title", "Google Sheet") ?: "Google Sheet"
                    sheetNames.clear(); val arr = meta.optJSONArray("sheets") ?: JSONArray()
                    for (i in 0 until arr.length()) sheetNames.add(arr.getJSONObject(i).getJSONObject("properties").getString("title"))
                    if (sheetNames.isEmpty()) throw IOException("No worksheets found.")
                    if (selectedTab !in sheetNames) selectedTab = sheetNames.first()
                }
                val range = "'${selectedTab.replace("'", "''")}'!A:ZZ"
                val valReq = Request.Builder().url("https://sheets.googleapis.com/v4/spreadsheets/$id/values/${enc(range)}?valueRenderOption=FORMATTED_VALUE")
                    .header("Authorization", "Bearer $token").build()
                client.newCall(valReq).execute().use { r ->
                    if (!r.isSuccessful) throw IOException("Cannot read worksheet (${r.code}): ${r.body?.string()?.take(250)}")
                    values = JSONObject(r.body!!.string()).optJSONArray("values") ?: JSONArray()
                }
                val payload = JSONObject().put("title", sheetTitle).put("tabs", JSONArray(sheetNames)).put("tab", selectedTab).put("values", values)
                sendJs("renderSheet(${JSONObject.quote(payload.toString())})")
            } catch (e: Exception) { sendError(e.message ?: "Unable to load sheet.") }
        }
    }

    private fun columnName(n: Int): String { var x = n; var out = ""; while (x > 0) { val r = (x - 1) % 26; out = ('A'.code + r).toChar() + out; x = (x - 1) / 26 }; return out }
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
    private fun sendError(s: String) = sendJs("showError(${JSONObject.quote(s)})")
    private fun sendJs(s: String) { runOnUiThread { web.evaluateJavascript("(function(){ $s })()", null) } }
}
