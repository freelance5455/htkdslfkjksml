package ir.nabz.pos;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends Activity {
    WebView w;
    ValueCallback<Uri[]> fc;
    byte[] pend;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        w = new WebView(this);
        setContentView(w);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        w.addJavascriptInterface(new Br(), "NabzNative");
        w.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fc != null) fc.onReceiveValue(null);
                fc = cb;
                try { startActivityForResult(p.createIntent(), 1); }
                catch (Exception e) { fc = null; return false; }
                return true;
            }
        });
        w.loadUrl("file:///android_asset/www/index.html");
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        if (r == 1 && fc != null) {
            fc.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c, d));
            fc = null;
        }
    }

    @Override public void onBackPressed() {
        if (w.canGoBack()) w.goBack(); else super.onBackPressed();
    }

    void toast(String m) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show());
    }

    class Br {
        @JavascriptInterface public void save(String name, String b64) {
            try {
                byte[] d = Base64.decode(b64, 0);
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                OutputStream o = getContentResolver().openOutputStream(u);
                o.write(d);
                o.close();
                toast("ذخیره شد در پوشه Downloads: " + name);
            } catch (Exception e) { toast("ذخیره فایل ناموفق بود"); }
        }
        @JavascriptInterface public void print(String b64) {
            pend = Base64.decode(b64, 0);
            runOnUiThread(() -> go());
        }
    }

    void go() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 2);
            return;
        }
        BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
        if (a == null || !a.isEnabled()) { toast("بلوتوث را روشن کنید"); return; }
        final List<BluetoothDevice> L = new ArrayList<>(a.getBondedDevices());
        if (L.isEmpty()) { toast("ابتدا چاپگر را در تنظیمات بلوتوث گوشی جفت کنید"); return; }
        String sv = getPreferences(0).getString("pr", null);
        for (BluetoothDevice d : L) if (d.getAddress().equals(sv)) { send(d); return; }
        String[] n = new String[L.size()];
        for (int i = 0; i < n.length; i++) n[i] = L.get(i).getName();
        new AlertDialog.Builder(this).setTitle("انتخاب چاپگر").setItems(n, (x, i) -> {
            getPreferences(0).edit().putString("pr", L.get(i).getAddress()).apply();
            send(L.get(i));
        }).show();
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        if (r == 2 && g.length > 0 && g[0] == 0 && pend != null) go();
    }

    void send(final BluetoothDevice d) {
        new Thread(() -> {
            try {
                BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                BluetoothSocket s = d.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
                s.connect();
                OutputStream o = s.getOutputStream();
                o.write(pend);
                o.flush();
                Thread.sleep(800);
                s.close();
                toast("✓ چاپ شد");
            } catch (Exception e) {
                getPreferences(0).edit().remove("pr").apply();
                toast("اتصال به چاپگر ممکن نشد؛ دوباره تلاش کنید");
            }
        }).start();
    }
}
