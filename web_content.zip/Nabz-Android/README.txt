نبض - پروژه اندروید (Android Studio)
1) Android Studio (نسخه Koala یا جدیدتر) را باز کنید و پوشه Nabz-Android را Open کنید؛ منتظر Sync بمانید.
2) برای فایل APK: Build > Build Bundle(s)/APK(s) > Build APK(s).
3) برای انتشار: Build > Generate Signed Bundle / APK.
- ظاهر و منطق برنامه در app/src/main/assets/www/index.html است.
- چاپگر بلوتوثی: ابتدا چاپگر را در تنظیمات بلوتوث گوشی جفت کنید؛ بار اول نام چاپگر پرسیده می‌شود.
- خروجی فایل‌ها در پوشه Downloads گوشی ذخیره می‌شود.
- کتابخانه اکسل (XLSX) و فونت وزیرمتن از اینترنت بارگذاری می‌شوند؛ بدون اینترنت بقیه بخش‌ها کار می‌کنند.
