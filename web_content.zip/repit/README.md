# REPIT — Windows desktop trading terminal

Electron app that talks to **your Repit API**. It shows no fake prices, no fake accounts and never reports an order as placed unless the API confirms it.

## 1. Install Node.js
Install the current **LTS** from https://nodejs.org (includes npm). Check: `node -v` and `npm -v` (Node 18+).

## 2. Install dependencies
```
cd repit
npm install
```
This downloads Electron, Electron Builder and the chart library (TradingView Lightweight Charts).

## 3. Configure `.env`
Copy `.env.example` to `.env` and fill in:
```
REPIT_API_URL=https://api.your-repit-host.com
REPIT_API_KEY=your-key
REPIT_AUTH_URL=https://auth.your-repit-host.com
```
Optional: `REPIT_SYMBOLS=BTCUSDT,ETHUSDT,BNBUSDT,SOLUSDT` (the asset list), `REPIT_API_KEY_HEADER=X-API-Key`, `REPIT_AUTH_REQUIRED=false` (skip sign-in and use the API key only).

`.env` is read by the main process only. It is **not** packaged into the build. The first file found is used:
1. `%APPDATA%\Repit\.env` (best for installed/portable builds)
2. next to `Repit.exe`
3. the project folder (development)

Restart Repit after editing `.env`. URLs must be `https://` (plain `http://` is accepted for `localhost` only).

## 4. Run in development
```
npm run dev      # with DevTools
npm start        # without
```

## 5. Build the Windows version
```
npm install
npm run build:win
```

## 6. Find `Repit.exe`
After the build, open the `dist` folder:
- `dist\Repit.exe` — single-file portable app (double-click to run)
- `dist\Repit-Setup-1.0.0.exe` — installer
- `dist\win-unpacked\Repit.exe` — unpacked app folder

Put your `.env` in `%APPDATA%\Repit\` (or next to `Repit.exe`) so the built app can find it. Optional: add `assets\icons\icon.ico` (256×256) and set `"icon": "assets/icons/icon.ico"` under `build.win` in `package.json`.

## 7. Connect to the Repit API
All paths live in `electron/lib/endpoints.js`; request/response shapes are normalised in `electron/ipc/*.js`. The app expects JSON:

| Purpose | Request | Expected response |
|---|---|---|
| Health | `GET /health` | any 2xx |
| Login | `POST {AUTH}/login` `{email,password}` | `{token, user:{id,email,name}}` |
| Register | `POST {AUTH}/register` `{email,password,name?}` | 2xx, optional `{token}` |
| Logout | `POST {AUTH}/logout` | any 2xx (best effort) |
| Prices | `GET /market/tickers?symbols=A,B` | `[{symbol, price, change24hPct, volume24h}]` |
| Candles | `GET /market/klines?symbol&interval&limit` | `[{time,open,high,low,close,volume}]` or `[t,o,h,l,c,v]` |
| Order book | `GET /market/orderbook?symbol&depth` | `{bids:[[price,qty]], asks:[[price,qty]]}` |
| Balance | `GET /account/balance` | `{total, available, unrealizedPnl, currency}` |
| Positions | `GET /positions` | `[{symbol, side, size, entryPrice, markPrice, unrealizedPnl}]` |
| Open orders / history | `GET /orders/open`, `/orders/history` | `[{id, symbol, side, type, amount, price, filled, status, createdAt}]` |
| Trades | `GET /trades/history` | `[{id, orderId, symbol, side, amount, price, fee, time}]` |
| Place order | `POST /orders` `{symbol, side, type, amount, price?, clientOrderId}` | `{orderId|id, status}` — **no id = not confirmed** |
| Cancel | `DELETE /orders/{id}` | any 2xx |

The API key is sent in the `X-API-Key` header and the session token as `Authorization: Bearer …`. If your backend uses other paths, headers or field names, change them in the files above.

## 8. Troubleshooting
- **"API not configured"** — `.env` not found or `REPIT_API_URL` empty. Settings → API connection shows which file was loaded.
- **"API unreachable"** — check the URL, internet/VPN/firewall, and that the server is up. Plain `http://` to a remote host is refused.
- **"API responding with errors"** — the server answered but rejected the request (often a wrong or missing key). Check `REPIT_API_KEY` and `REPIT_API_KEY_HEADER`.
- **"Authentication service is not configured"** — set `REPIT_AUTH_URL`, or set `REPIT_AUTH_REQUIRED=false`.
- **"Market data unavailable"** — the market endpoints failed or returned an unexpected format; the message beside it says why.
- **Order "not confirmed" / timeout** — check *Orders → Open orders* before retrying; the order may have been placed.
- **Build error about symbolic links / winCodeSign** — run the terminal as Administrator or enable Windows *Developer Mode*, then rebuild.
- **Blank chart** — run `npm install` again (the chart library comes from `node_modules`).

## Security notes
`contextIsolation: true`, `nodeIntegration: false`, `sandbox: true`, strict CSP, a private `app://` scheme, a fixed preload API (no generic IPC), IPC sender checks, input validation in the main process, API key and session token kept in the main process, no `eval`, no secrets in `localStorage` (only the theme choice is stored).
