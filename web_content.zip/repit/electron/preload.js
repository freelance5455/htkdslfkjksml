'use strict';

const { contextBridge, ipcRenderer } = require('electron');

// Minimal bridge: a fixed list of named calls. No generic invoke, no Node access, no secrets.
const GROUPS = {
  auth: ['session', 'login', 'register', 'logout'],
  market: ['config', 'status', 'tickers', 'klines', 'orderbook'],
  trading: ['balance', 'positions', 'openOrders', 'orderHistory', 'tradeHistory', 'placeOrder', 'cancelOrder'],
};

const plain = (payload) => (payload && typeof payload === 'object' ? JSON.parse(JSON.stringify(payload)) : {});

const bridge = {};
for (const [group, names] of Object.entries(GROUPS)) {
  bridge[group] = Object.freeze(
    Object.fromEntries(names.map((n) => [n, (payload) => ipcRenderer.invoke(`${group}:${n}`, plain(payload))]))
  );
}

contextBridge.exposeInMainWorld('repit', Object.freeze(bridge));
