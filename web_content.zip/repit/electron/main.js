'use strict';

const { app, BrowserWindow, protocol, session, Menu, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const { loadEnv } = require('./lib/env');

const isDev = process.argv.includes('--dev');
loadEnv(app);

// The UI is served from a private app:// scheme so a strict CSP (default-src 'self') can be used.
protocol.registerSchemesAsPrivileged([
  { scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true } },
]);

const ROOT = path.join(__dirname, '..');
const SRC_DIR = path.join(ROOT, 'src');
const ASSETS_DIR = path.join(ROOT, 'assets');
const LWC_FILE = path.join(ROOT, 'node_modules', 'lightweight-charts', 'dist', 'lightweight-charts.standalone.production.js');
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
};

function resolveAppPath(urlString) {
  let p = decodeURIComponent(new URL(urlString).pathname);
  if (p === '/') p = '/index.html';
  if (p === '/vendor/lightweight-charts.js') return LWC_FILE;
  const isAsset = p.startsWith('/assets/');
  const base = isAsset ? ASSETS_DIR : SRC_DIR;
  const full = path.normalize(path.join(base, isAsset ? p.slice('/assets/'.length) : p.slice(1)));
  return full.startsWith(base + path.sep) ? full : null; // blocks ../ traversal
}

let mainWindow = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1100,
    minHeight: 700,
    backgroundColor: '#0b0e17',
    title: 'Repit',
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
      devTools: isDev,
    },
  });
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  mainWindow.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('app://repit/')) e.preventDefault();
  });
  mainWindow.webContents.on('will-attach-webview', (e) => e.preventDefault());
  mainWindow.loadURL('app://repit/index.html');
  if (isDev) mainWindow.webContents.openDevTools({ mode: 'detach' });
  mainWindow.on('closed', () => { mainWindow = null; });
}

function start() {
  protocol.handle('app', async (request) => {
    const file = resolveAppPath(request.url);
    if (!file) return new Response('Forbidden', { status: 403 });
    try {
      const data = await fs.promises.readFile(file);
      return new Response(data, {
        headers: { 'content-type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream' },
      });
    } catch {
      return new Response('Not found', { status: 404 });
    }
  });

  session.defaultSession.setPermissionRequestHandler((_wc, _perm, cb) => cb(false));
  session.defaultSession.setPermissionCheckHandler(() => false);

  require('./ipc/auth').register(ipcMain);
  require('./ipc/market').register(ipcMain);
  require('./ipc/trading').register(ipcMain);

  if (!isDev) Menu.setApplicationMenu(null);
  createWindow();
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
  app.whenReady().then(start);
  app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
}
