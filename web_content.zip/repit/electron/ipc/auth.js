'use strict';

const { getConfig } = require('../lib/config');
const { request } = require('../lib/client');
const { ApiError } = require('../lib/errors');
const { handle } = require('../lib/ipc');
const { str } = require('../lib/normalize');
const session = require('../lib/session');
const EP = require('../lib/endpoints');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const invalid = (m) => new ApiError('INVALID_INPUT', m);

function authBase() {
  const { authUrl } = getConfig();
  if (!authUrl) {
    throw new ApiError('NOT_CONFIGURED', 'The authentication service is not configured. Set REPIT_AUTH_URL in your .env file.');
  }
  return authUrl;
}

function cleanUser(u, fallbackEmail) {
  const o = u && typeof u === 'object' ? u : {};
  return { id: str(o.id), email: str(o.email) || fallbackEmail || '', name: str(o.name || o.username) };
}

function credentials(p, minPassword) {
  const email = String(p.email || '').trim();
  const password = String(p.password || '');
  if (!EMAIL_RE.test(email) || email.length > 254) throw invalid('Enter a valid email address.');
  if (!password || password.length > 256) throw invalid('Enter your password.');
  if (minPassword && password.length < minPassword) throw invalid(`Password must be at least ${minPassword} characters.`);
  return { email, password };
}

const tokenOf = (data) => {
  const t = data && (data.token || data.accessToken);
  return typeof t === 'string' && t ? t : null;
};

function register(ipcMain) {
  handle(ipcMain, 'auth:session', async () => {
    const cfg = getConfig();
    return {
      authRequired: cfg.authRequired,
      authConfigured: Boolean(cfg.authUrl),
      signedIn: !cfg.authRequired || Boolean(session.getToken()),
      user: session.getUser(),
    };
  });

  handle(ipcMain, 'auth:login', async (p) => {
    const { email, password } = credentials(p);
    const data = await request({ base: authBase(), path: EP.auth.login, method: 'POST', body: { email, password }, useToken: false });
    const token = tokenOf(data);
    if (!token) throw new ApiError('BAD_RESPONSE', 'The authentication service did not return a session.');
    const user = cleanUser(data.user, email);
    session.set(token, user);
    return { user }; // the token never leaves the main process
  });

  handle(ipcMain, 'auth:register', async (p) => {
    const { email, password } = credentials(p, 8);
    const name = String(p.name || '').trim().slice(0, 80);
    const data = await request({
      base: authBase(), path: EP.auth.register, method: 'POST',
      body: name ? { name, email, password } : { email, password }, useToken: false,
    });
    const token = tokenOf(data);
    if (token) session.set(token, cleanUser(data && data.user, email));
    return { signedIn: Boolean(token) };
  });

  handle(ipcMain, 'auth:logout', async () => {
    const { authUrl } = getConfig();
    try {
      if (authUrl && session.getToken()) await request({ base: authUrl, path: EP.auth.logout, method: 'POST' });
    } catch { /* best effort: the local session is cleared regardless */ }
    session.clear();
    return {};
  });
}

module.exports = { register };
