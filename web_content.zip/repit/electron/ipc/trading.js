'use strict';

const crypto = require('crypto');
const { getConfig } = require('../lib/config');
const { request } = require('../lib/client');
const { ApiError } = require('../lib/errors');
const { handle, requireAuth } = require('../lib/ipc');
const { num, str, ts, asArray, asObject } = require('../lib/normalize');
const { validateSymbol, parsePositive, validateOrderId, validateLimit } = require('../lib/validate');
const EP = require('../lib/endpoints');

const REJECTED = ['REJECTED', 'FAILED', 'CANCELED', 'CANCELLED', 'EXPIRED', 'ERROR'];
let submitting = false;

const order = (o) => ({
  id: str(o.id ?? o.orderId),
  symbol: str(o.symbol).toUpperCase(),
  side: str(o.side).toLowerCase(),
  type: str(o.type).toLowerCase(),
  amount: num(o.amount ?? o.quantity),
  price: num(o.price),
  filled: num(o.filled),
  status: str(o.status),
  createdAt: ts(o.createdAt ?? o.time),
});

const position = (p) => ({
  symbol: str(p.symbol).toUpperCase(),
  side: str(p.side).toLowerCase(),
  size: num(p.size ?? p.amount),
  entryPrice: num(p.entryPrice),
  markPrice: num(p.markPrice),
  unrealizedPnl: num(p.unrealizedPnl),
});

const trade = (t) => ({
  id: str(t.id ?? t.tradeId),
  orderId: str(t.orderId),
  symbol: str(t.symbol).toUpperCase(),
  side: str(t.side).toLowerCase(),
  amount: num(t.amount ?? t.quantity),
  price: num(t.price),
  fee: num(t.fee),
  time: ts(t.time ?? t.createdAt),
});

function register(ipcMain) {
  const list = (channel, path, key, map) =>
    handle(ipcMain, channel, async (p) => {
      requireAuth();
      const data = await request({ base: getConfig().apiUrl, path, query: { limit: validateLimit(p.limit) } });
      return asArray(data, key).map(map);
    });

  list('trading:positions', EP.positions, 'positions', position);
  list('trading:openOrders', EP.openOrders, 'orders', order);
  list('trading:orderHistory', EP.orderHistory, 'orders', order);
  list('trading:tradeHistory', EP.tradeHistory, 'trades', trade);

  handle(ipcMain, 'trading:balance', async () => {
    requireAuth();
    const b = asObject(await request({ base: getConfig().apiUrl, path: EP.balance }));
    return {
      total: num(b.total),
      available: num(b.available),
      unrealizedPnl: num(b.unrealizedPnl),
      currency: str(b.currency),
    };
  });

  handle(ipcMain, 'trading:placeOrder', async (p) => {
    requireAuth();
    const cfg = getConfig();
    const symbol = validateSymbol(p.symbol, cfg.symbols);
    const side = String(p.side || '').toLowerCase();
    const type = String(p.type || '').toLowerCase();
    if (!['buy', 'sell'].includes(side)) throw new ApiError('INVALID_INPUT', 'Side must be buy or sell.');
    if (!['market', 'limit'].includes(type)) throw new ApiError('INVALID_INPUT', 'Order type must be market or limit.');
    const amount = parsePositive(p.amount, 'Amount');

    // Request body sent to POST /orders (adjust here if your backend expects a different shape)
    const body = { symbol, side, type, amount, clientOrderId: crypto.randomUUID() };
    if (type === 'limit') body.price = parsePositive(p.price, 'Price');

    if (submitting) throw new ApiError('BUSY', 'Another order is still being submitted. Wait for it to finish.');
    submitting = true;
    try {
      let data;
      try {
        data = await request({ base: cfg.apiUrl, path: EP.placeOrder, method: 'POST', body });
      } catch (e) {
        if (e instanceof ApiError && ['TIMEOUT', 'NETWORK'].includes(e.code)) {
          throw new ApiError(e.code, `${e.message} The order may or may not have been placed. Check Open Orders before trying again.`);
        }
        throw e;
      }
      const id = data && typeof data === 'object' ? (data.orderId ?? data.id) : null;
      const status = data && typeof data.status === 'string' ? data.status : '';
      if (id === null || id === undefined || id === '' || REJECTED.includes(status.toUpperCase())) {
        throw new ApiError('NOT_CONFIRMED', 'The Repit API did not confirm this order. Check Open Orders before trying again.');
      }
      return { orderId: str(id), status: str(status) };
    } finally {
      submitting = false;
    }
  });

  handle(ipcMain, 'trading:cancelOrder', async (p) => {
    requireAuth();
    const id = validateOrderId(p.orderId);
    await request({ base: getConfig().apiUrl, path: EP.cancelOrder(id), method: 'DELETE' });
    return { orderId: id };
  });
}

module.exports = { register };
