'use strict';

const { getConfig, getEnvFile } = require('../lib/config');
const { request } = require('../lib/client');
const { ApiError } = require('../lib/errors');
const { handle, requireAuth } = require('../lib/ipc');
const { num, ts, asArray } = require('../lib/normalize');
const { validateSymbol } = require('../lib/validate');
const EP = require('../lib/endpoints');

const INTERVALS = ['1m', '5m', '15m', '1h', '4h', '1d'];

function candle(c) {
  let t, o, h, l, cl, v;
  if (Array.isArray(c)) [t, o, h, l, cl, v] = c;
  else ({ time: t, open: o, high: h, low: l, close: cl, volume: v } = c);
  let time = ts(t);
  if (time === null) return null;
  time = Math.floor(time / 1000);
  const out = { time, open: num(o), high: num(h), low: num(l), close: num(cl), volume: num(v) };
  return [out.open, out.high, out.low, out.close].some((x) => x === null) ? null : out;
}

function book(rows) {
  return (Array.isArray(rows) ? rows : [])
    .map((r) => (Array.isArray(r) ? [num(r[0]), num(r[1])] : r && typeof r === 'object' ? [num(r.price), num(r.amount ?? r.quantity)] : [null, null]))
    .filter(([p, q]) => p !== null && q !== null);
}

function register(ipcMain) {
  handle(ipcMain, 'market:config', async () => ({ symbols: getConfig().symbols }));

  // Connection status for the header and Settings. Exposes no secrets (origin only, key as a boolean).
  handle(ipcMain, 'market:status', async () => {
    const cfg = getConfig();
    const base = {
      configured: Boolean(cfg.apiUrl),
      keyConfigured: Boolean(cfg.apiKey),
      authConfigured: Boolean(cfg.authUrl),
      authRequired: cfg.authRequired,
      symbols: cfg.symbols,
      envFile: getEnvFile(),
      origin: '',
      state: 'not_configured',
      message: 'Set REPIT_API_URL in your .env file.',
      latencyMs: null,
    };
    if (!cfg.apiUrl) return base;
    try { base.origin = new URL(cfg.apiUrl).origin; } catch { base.message = 'REPIT_API_URL is not a valid URL.'; return base; }
    const started = Date.now();
    try {
      await request({ base: cfg.apiUrl, path: EP.health, useToken: false });
      return { ...base, state: 'connected', message: 'Connected', latencyMs: Date.now() - started };
    } catch (e) {
      const unreachable = !(e instanceof ApiError) || ['NETWORK', 'TIMEOUT', 'INSECURE_URL', 'NOT_CONFIGURED'].includes(e.code);
      return { ...base, state: unreachable ? 'unreachable' : 'degraded', message: e.message || 'Unavailable' };
    }
  });

  handle(ipcMain, 'market:tickers', async () => {
    requireAuth();
    const cfg = getConfig();
    const data = await request({ base: cfg.apiUrl, path: EP.tickers, query: { symbols: cfg.symbols.join(',') } });
    return asArray(data, 'tickers')
      .map((t) => ({
        symbol: String(t.symbol || '').toUpperCase(),
        price: num(t.price ?? t.last),
        change24hPct: num(t.change24hPct),
        volume24h: num(t.volume24h),
      }))
      .filter((t) => cfg.symbols.includes(t.symbol) && t.price !== null);
  });

  handle(ipcMain, 'market:klines', async (p) => {
    requireAuth();
    const cfg = getConfig();
    const symbol = validateSymbol(p.symbol, cfg.symbols);
    const interval = INTERVALS.includes(p.interval) ? p.interval : '15m';
    const data = await request({ base: cfg.apiUrl, path: EP.klines, query: { symbol, interval, limit: 300 } });
    const byTime = new Map();
    for (const c of asArray(data, 'candles')) {
      const k = candle(c);
      if (k) byTime.set(k.time, k);
    }
    return [...byTime.values()].sort((a, b) => a.time - b.time);
  });

  handle(ipcMain, 'market:orderbook', async (p) => {
    requireAuth();
    const cfg = getConfig();
    const symbol = validateSymbol(p.symbol, cfg.symbols);
    const data = await request({ base: cfg.apiUrl, path: EP.orderbook, query: { symbol, depth: 12 } });
    if (!data || typeof data !== 'object') throw new ApiError('BAD_RESPONSE', 'The Repit API returned an unexpected response format.');
    return {
      bids: book(data.bids).sort((a, b) => b[0] - a[0]).slice(0, 12),
      asks: book(data.asks).sort((a, b) => a[0] - b[0]).slice(0, 12),
    };
  });
}

module.exports = { register };
