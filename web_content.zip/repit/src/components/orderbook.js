import { api } from '../js/api.js';
import { h, fmtPrice, fmtAmount } from '../js/ui.js';

export function createOrderBook(root) {
  const asks = h('div', {});
  const bids = h('div', {});
  const mid = h('div', { class: 'ob-mid muted' }, '—');
  const msg = h('div', { class: 'empty', hidden: true }, 'Order book unavailable');
  root.replaceChildren(
    h('div', { class: 'ob-head' }, h('span', {}, 'Price'), h('span', {}, 'Amount')), asks, mid, bids, msg);

  const rowsFor = (levels, cls) => {
    const max = Math.max(...levels.map((l) => l[1]), 0) || 1;
    return levels.map(([price, qty]) => {
      const row = h('div', { class: `ob-row ${cls}` }, h('span', {}, fmtPrice(price)), h('span', {}, fmtAmount(qty)));
      row.style.setProperty('--depth', `${Math.round((qty / max) * 100)}%`);
      return row;
    });
  };

  return {
    async update(symbol) {
      try {
        const ob = await api.market.orderbook({ symbol });
        msg.hidden = true;
        asks.replaceChildren(...rowsFor(ob.asks.slice(0, 10).reverse(), 'ask'));
        bids.replaceChildren(...rowsFor(ob.bids.slice(0, 10), 'bid'));
        mid.textContent = ob.asks[0] && ob.bids[0] ? `Spread ${fmtPrice(ob.asks[0][0] - ob.bids[0][0])}` : '—';
      } catch (e) {
        asks.replaceChildren(); bids.replaceChildren(); mid.textContent = '—';
        msg.textContent = `Order book unavailable. ${e.message}`;
        msg.hidden = false;
      }
    },
  };
}
