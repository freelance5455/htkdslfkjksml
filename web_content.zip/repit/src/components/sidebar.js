import { h } from '../js/ui.js';

const ITEMS = [
  ['dashboard', 'Dashboard'], ['markets', 'Markets'], ['trading', 'Trading'],
  ['orders', 'Orders & positions'], ['history', 'History'], ['settings', 'Settings'],
];

export function createSidebar(slot) {
  const links = new Map();
  const nav = h('nav', { class: 'sidebar', 'aria-label': 'Main' },
    h('div', { class: 'brand' }, h('img', { src: 'assets/logo.svg', alt: '', width: '28', height: '28' }), h('span', {}, 'REPIT')),
    h('ul', {}, ITEMS.map(([id, label]) => {
      const a = h('a', { href: `#/${id}` }, h('i', { class: `ico ico-${id === 'orders' ? 'orders' : id}` }), label);
      links.set(id, a);
      return h('li', {}, a);
    })));
  slot.replaceChildren(nav);
  return {
    setActive(id) {
      links.forEach((a, k) => (k === id ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current')));
    },
  };
}
