import { api } from '../js/api.js';
import { h, fmtPrice, fmtSigned, signClass } from '../js/ui.js';

const money = (v, cur) => (v === null || v === undefined ? '—' : `${fmtPrice(v)} ${cur || ''}`.trim());

export function createStatCards(root) {
  const mk = (label) => {
    const value = h('div', { class: 'value' }, '—');
    return { node: h('div', { class: 'stat' }, h('div', { class: 'label' }, label), value), value };
  };
  const total = mk('Total balance');
  const avail = mk('Available balance');
  const pnl = mk('Unrealized PnL');
  const pos = mk('Open positions');
  const note = h('div', { class: 'notice error', role: 'alert', hidden: true });
  root.replaceChildren(total.node, avail.node, pnl.node, pos.node, note);

  async function refresh() {
    const [b, p] = await Promise.allSettled([api.trading.balance(), api.trading.positions()]);
    const errors = [];
    if (b.status === 'fulfilled') {
      const { total: t, available, unrealizedPnl, currency } = b.value;
      total.value.textContent = money(t, currency);
      avail.value.textContent = money(available, currency);
      pnl.value.textContent = unrealizedPnl === null ? '—' : `${fmtSigned(unrealizedPnl)} ${currency || ''}`.trim();
      pnl.value.className = `value ${signClass(unrealizedPnl)}`;
    } else {
      [total, avail, pnl].forEach((x) => { x.value.textContent = '—'; x.value.className = 'value'; });
      errors.push(`Balance unavailable: ${b.reason.message}`);
    }
    if (p.status === 'fulfilled') pos.value.textContent = String(p.value.length);
    else { pos.value.textContent = '—'; errors.push(`Positions unavailable: ${p.reason.message}`); }
    note.textContent = errors.join(' ');
    note.hidden = errors.length === 0;
  }
  return { refresh };
}
