import { api } from '../js/api.js';
import { h, table, renderAsync, fmtPrice, fmtAmount, fmtSigned, signClass } from '../js/ui.js';

export function loadPositions(el) {
  return renderAsync(el, () => api.trading.positions(), (rows) => table({
    rows,
    empty: 'No open positions.',
    columns: [
      { label: 'Symbol', key: 'symbol' },
      { label: 'Side', render: (r) => h('span', { class: r.side === 'buy' || r.side === 'long' ? 'pos' : 'neg' }, r.side || '—') },
      { label: 'Size', align: 'right', render: (r) => fmtAmount(r.size) },
      { label: 'Entry price', align: 'right', render: (r) => fmtPrice(r.entryPrice) },
      { label: 'Mark price', align: 'right', render: (r) => fmtPrice(r.markPrice) },
      { label: 'Unrealized PnL', align: 'right', render: (r) => fmtSigned(r.unrealizedPnl), cls: (r) => signClass(r.unrealizedPnl) },
    ],
  }));
}
