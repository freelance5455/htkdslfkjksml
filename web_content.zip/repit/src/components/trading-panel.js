import { api } from '../js/api.js';
import { h, toast, confirmModal, fmtPrice, fmtAmount } from '../js/ui.js';

const NUM_RE = /^\d+(\.\d{1,8})?$/;
const parsePositive = (s) => {
  const t = String(s).trim();
  if (!NUM_RE.test(t)) return null;
  const n = Number(t);
  return n > 0 ? n : null;
};

export function createTradingPanel(root, { getSymbol, getPrice, onPlaced }) {
  let side = 'buy';
  let type = 'market';
  let busy = false;
  let currency = '';

  const sideBtn = (s, label) => h('button', { type: 'button', class: `side-tab ${s}`, 'aria-pressed': String(s === side), onClick: () => setSide(s) }, label);
  const buyTab = sideBtn('buy', 'Buy');
  const sellTab = sideBtn('sell', 'Sell');
  const typeBtn = (t, label) => h('button', { type: 'button', 'aria-pressed': String(t === type), onClick: () => setType(t) }, label);
  const marketTab = typeBtn('market', 'Market');
  const limitTab = typeBtn('limit', 'Limit');

  const amount = h('input', { id: 'op-amount', inputmode: 'decimal', autocomplete: 'off', placeholder: '0.00' });
  const price = h('input', { id: 'op-price', inputmode: 'decimal', autocomplete: 'off', placeholder: '0.00' });
  const priceField = h('label', { class: 'field', hidden: true }, h('span', {}, 'Price'), price);
  const total = h('dd', {}, '—');
  const avail = h('dd', {}, '—');
  const err = h('div', { class: 'notice error', role: 'alert', hidden: true });
  const submit = h('button', { type: 'submit', class: 'btn buy block' }, 'Buy');

  const form = h('form', { novalidate: true, onSubmit: onSubmit },
    h('div', { class: 'side-tabs' }, buyTab, sellTab),
    h('div', { class: 'seg', role: 'group', 'aria-label': 'Order type' }, marketTab, limitTab),
    h('label', { class: 'field' }, h('span', {}, 'Amount'), amount),
    priceField,
    h('dl', { class: 'kv' }, h('dt', {}, 'Estimated total'), total, h('dt', {}, 'Available balance'), avail),
    err, submit);
  root.replaceChildren(h('h2', {}, 'Place order'), form);
  root.classList.add('order-panel');

  function setSide(s) {
    side = s;
    buyTab.setAttribute('aria-pressed', String(s === 'buy'));
    sellTab.setAttribute('aria-pressed', String(s === 'sell'));
    recalc();
  }
  function setType(t) {
    type = t;
    marketTab.setAttribute('aria-pressed', String(t === 'market'));
    limitTab.setAttribute('aria-pressed', String(t === 'limit'));
    priceField.hidden = t !== 'limit';
    recalc();
  }
  function recalc() {
    const a = parsePositive(amount.value);
    const p = type === 'limit' ? parsePositive(price.value) : getPrice();
    total.textContent = a && p ? `${fmtPrice(a * p)} ${currency}`.trim() : '—';
    submit.className = `btn ${side} block`;
    submit.textContent = `${side === 'buy' ? 'Buy' : 'Sell'} ${getSymbol()}`;
    submit.disabled = busy;
  }
  function showError(message) { err.textContent = message; err.hidden = !message; }

  async function loadAvailable() {
    try {
      const b = await api.trading.balance();
      currency = b.currency || '';
      avail.textContent = b.available === null ? '—' : `${fmtPrice(b.available)} ${currency}`.trim();
    } catch {
      avail.textContent = 'Unavailable';
    }
    recalc();
  }

  async function onSubmit(e) {
    e.preventDefault();
    if (busy) return;
    showError('');
    const symbol = getSymbol();
    const amt = parsePositive(amount.value);
    if (!amt) return showError('Enter an amount greater than zero (up to 8 decimals).');
    let limitPrice = null;
    if (type === 'limit') {
      limitPrice = parsePositive(price.value);
      if (!limitPrice) return showError('Enter a limit price greater than zero (up to 8 decimals).');
    }
    const refPrice = type === 'limit' ? limitPrice : getPrice();
    const ok = await confirmModal({
      title: `Confirm ${side} order`,
      rows: [
        ['Symbol', symbol], ['Side', side.toUpperCase()], ['Type', type],
        ['Amount', fmtAmount(amt)],
        ['Price', type === 'limit' ? fmtPrice(limitPrice) : 'Market (best available)'],
        ['Estimated total', refPrice ? `${fmtPrice(amt * refPrice)} ${currency}`.trim() : 'Unavailable'],
      ],
      confirmText: `${side === 'buy' ? 'Buy' : 'Sell'} ${symbol}`,
      tone: side,
    });
    if (!ok) return;

    busy = true;
    submit.disabled = true;
    submit.textContent = 'Submitting…';
    try {
      const res = await api.trading.placeOrder({ symbol, side, type, amount: amount.value.trim(), price: type === 'limit' ? price.value.trim() : undefined });
      toast(`Order ${res.orderId} confirmed by the Repit API${res.status ? ` (${res.status})` : ''}.`, 'success');
      amount.value = '';
      if (onPlaced) onPlaced();
    } catch (ex) {
      showError(ex.message);
      toast(ex.message, 'error');
    } finally {
      busy = false;
      loadAvailable();
    }
  }

  amount.addEventListener('input', recalc);
  price.addEventListener('input', recalc);
  loadAvailable();
  return { recalc, refresh: loadAvailable };
}
