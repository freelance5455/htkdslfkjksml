import { api } from '../js/api.js';
import { h } from '../js/ui.js';

const PILL = {
  connected: ['ok', 'API connected'],
  degraded: ['warn', 'API responding with errors'],
  unreachable: ['bad', 'API unreachable'],
  not_configured: ['bad', 'API not configured'],
};

export function createHeader(slot, { session, onLogout }) {
  const title = h('h1', {}, '');
  const pill = h('span', { class: 'pill', role: 'status' }, 'Checking API…');
  const user = session.user;
  const account = h('span', { class: 'account' }, user ? (user.name || user.email || 'Signed in') : 'API key account');
  const bar = h('header', { class: 'topbar' }, title, pill, account,
    session.authRequired ? h('button', { class: 'btn ghost sm', type: 'button', onClick: onLogout }, 'Log out') : null);
  slot.replaceChildren(bar);

  async function poll() {
    try {
      const s = await api.market.status();
      const [cls, text] = PILL[s.state] || PILL.unreachable;
      pill.className = `pill ${cls}`;
      pill.textContent = text;
      pill.title = s.message || '';
    } catch {
      pill.className = 'pill bad';
      pill.textContent = 'API unreachable';
    }
  }
  poll();
  const timer = setInterval(poll, 15000);

  return {
    setTitle(t) { title.textContent = t; },
    destroy() { clearInterval(timer); },
  };
}
