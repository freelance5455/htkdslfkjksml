import { h } from './ui.js';

// Candlestick + volume chart using TradingView Lightweight Charts (loaded from node_modules via app://repit/vendor/).
export function createPriceChart(el) {
  const LW = window.LightweightCharts;
  const msg = h('div', { class: 'chart-msg', hidden: true });
  const setMessage = (text) => { msg.textContent = text || ''; msg.hidden = !text; };

  if (!LW) {
    el.append(msg);
    setMessage('The chart library failed to load. Run npm install and restart.');
    return { setData() {}, setMessage, destroy() {} };
  }

  const css = getComputedStyle(document.documentElement);
  const c = (name) => css.getPropertyValue(name).trim();
  const chart = LW.createChart(el, {
    autoSize: true,
    layout: { background: { type: 'solid', color: 'transparent' }, textColor: c('--muted') },
    grid: { vertLines: { color: c('--grid') }, horzLines: { color: c('--grid') } },
    rightPriceScale: { borderColor: c('--border') },
    timeScale: { borderColor: c('--border'), timeVisible: true, secondsVisible: false },
    crosshair: { mode: LW.CrosshairMode.Normal },
  });
  const candles = chart.addCandlestickSeries({
    upColor: c('--buy'), downColor: c('--sell'), borderVisible: false, wickUpColor: c('--buy'), wickDownColor: c('--sell'),
  });
  const volume = chart.addHistogramSeries({ priceFormat: { type: 'volume' }, priceScaleId: '' });
  volume.priceScale().applyOptions({ scaleMargins: { top: 0.82, bottom: 0 } });
  el.append(msg);

  return {
    setMessage,
    setData(data) {
      if (!data.length) {
        candles.setData([]); volume.setData([]);
        setMessage('No candle data returned for this market.');
        return;
      }
      setMessage('');
      candles.setData(data.map(({ time, open, high, low, close }) => ({ time, open, high, low, close })));
      volume.setData(data.map((k) => ({
        time: k.time, value: k.volume || 0,
        color: k.close >= k.open ? 'rgba(34,192,122,.35)' : 'rgba(240,80,110,.35)',
      })));
      chart.timeScale().fitContent();
    },
    destroy() { chart.remove(); },
  };
}
