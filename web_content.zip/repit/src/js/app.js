import { api } from './api.js';
import { h, $, clear, toast, getTheme, setTheme } from './ui.js';
import { createSidebar } from '../components/sidebar.js';
import { createHeader } from '../components/header.js';
import { initLogin, initRegister } from './auth.js';
import { initDashboard } from './dashboard.js';
import { initMarkets } from './market.js';
import { initTrading, initOrders, initHistory } from './trading.js';
import { initSettings } from './settings.js';

setTheme(getTheme());

const ROUTES = {
  login: { file: 'login.html', title: 'Sign in', bare: true, init: initLogin },
  register: { file: 'register.html', title: 'Create account', bare: true, init: initRegister },
  dashboard: { file: 'dashboard.html', title: 'Dashboard', init: initDashboard },
  markets: { file: 'markets.html', title: 'Markets', init: initMarkets },
  trading: { file: 'trading.html', title: 'Trading', init: initTrading },
  orders: { file: 'orders.html', title: 'Orders & positions', init: initOrders },
  history: { file: 'history.html', title: 'History', init: initHistory },
  settings: { file: 'settings.html', title: 'Settings', init: initSettings },
};

const state = { session: null };
let shell = null; // { sidebar, header }
let cleanup = null;
let renderToken = 0;

const navigate = (name) => {
  const target = `#/${name}`;
  if (location.hash === target) render();
  else location.hash = target;
};

async function loadSession() {
  try {
    return await api.auth.session();
  } catch (e) {
    return { signedIn: false, authRequired: true, authConfigured: false, user: null, error: e.message };
  }
}

const ctx = {
  state,
  navigate,
  logout: doLogout,
  async refreshSession() { state.session = await loadSession(); return state.session; },
};

async function doLogout() {
  try { await api.auth.logout(); } catch { /* local session is cleared by the main process regardless */ }
  state.session = null;
  navigate('login');
}

function mountLayout(route, name) {
  const app = $('#app');
  if (route.bare) {
    if (shell) { shell.header.destroy(); shell = null; }
    const view = h('main', { id: 'view', class: 'auth-view' });
    app.replaceChildren(h('div', { class: 'auth-layout' },
      h('div', { class: 'auth-brand' }, h('img', { src: 'assets/logo.svg', alt: '', width: '40', height: '40' }), h('span', {}, 'REPIT')),
      view));
    return view;
  }
  if (!shell) {
    app.replaceChildren(h('div', { class: 'shell' },
      h('div', { id: 'sidebar-slot' }),
      h('div', { class: 'main-col' }, h('div', { id: 'header-slot' }), h('main', { id: 'view', class: 'view' }))));
    shell = {
      sidebar: createSidebar($('#sidebar-slot')),
      header: createHeader($('#header-slot'), { session: state.session, onLogout: doLogout }),
    };
  }
  shell.sidebar.setActive(name);
  shell.header.setTitle(route.title);
  const view = $('#view');
  clear(view);
  return view;
}

async function render() {
  const mine = ++renderToken;
  if (cleanup) { try { cleanup(); } catch { /* ignore */ } cleanup = null; }

  const name = (location.hash.replace(/^#\/?/, '') || 'dashboard').split('?')[0];
  const route = ROUTES[name];
  if (!route) return navigate('dashboard');

  if (!state.session) state.session = await loadSession();
  if (mine !== renderToken) return;
  const signedIn = state.session.signedIn;
  if (!route.bare && !signedIn) return navigate('login');
  if (route.bare && signedIn) return navigate('dashboard');

  const view = mountLayout(route, name);
  let html;
  try {
    const res = await fetch(`pages/${route.file}`);
    if (!res.ok) throw new Error('missing');
    html = await res.text();
  } catch {
    view.textContent = 'This page could not be loaded.';
    return;
  }
  if (mine !== renderToken) return;
  view.innerHTML = html; // trusted, packaged page fragment; no user or API data is ever inserted this way
  const out = await route.init(view, ctx);
  if (mine !== renderToken) { if (typeof out === 'function') out(); return; }
  cleanup = typeof out === 'function' ? out : null;
}

window.addEventListener('hashchange', render);
window.addEventListener('repit:unauthorized', () => {
  if (state.session && state.session.authRequired && location.hash !== '#/login') {
    state.session = null;
    toast('Your session ended. Sign in again.', 'error');
    navigate('login');
  }
});

render();
