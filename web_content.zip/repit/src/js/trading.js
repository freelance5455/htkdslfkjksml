import { api } from './api.js';
import {
  $, h, table, tabs, renderAsync, toast, confirmModal,
  fmtPrice, fmtAmount, fmtPct, fmtTime, signClass,
} from './ui.js';
import { createPriceChart } from './chart.js';
import { createOrderBook } from '../components/orderbook.js';
import { createTradingPanel } from '../components/trading-panel.js';
import { loadPositions } from '../components/positions.js';

const INTERVALS = ['1m', '5m', '15m', '1h', '4h', '1d'];
const sideCell = (r) => h('span', { class: r.side === 'buy' ? 'pos' : 'neg' }, r.side ? r.side.toUpperCase() : '—');

async function cancelOrder(order, reload) {
  const ok = await confirmModal({
    title: 'Cancel order',
    rows: [['Order', order.id], ['Symbol', order.symbol], ['Side', (order.side || '').toUpperCase()], ['Amount', fmtAmount(order.amount)]],
    confirmText: 'Cancel order',
    tone: 'sell',
  });
  if (!ok) return;
  try {
    await api.trading.cancelOrder({ orderId: order.id });
    toast(`The Repit API accepted the cancel request for order ${order.id}.`, 'success');
  } catch (e) {
    toast(e.message, 'error');
  }
  reload();
}

const orderColumns = (withCancel, reload) => {
  const cols = [
    { label: 'Time', render: (r) => fmtTime(r.createdAt) },
    { label: 'Symbol', key: 'symbol' },
    { label: 'Side', render: sideCell },
    { label: 'Type', key: 'type' },
    { label: 'Amount', align: 'right', render: (r) => fmtAmount(r.amount) },
    { label: 'Price', align: 'right', render: (r) => fmtPrice(r.price) },
    { label: 'Filled', align: 'right', render: (r) => fmtAmount(r.filled) },
    { label: 'Status', key: 'status' },
  ];
  if (withCancel) {
    cols.push({ label: '', align: 'right', render: (r) => h('button', { class: 'btn ghost sm', type: 'button', onClick: () => cancelOrder(r, reload) }, 'Cancel') });
  }
  return cols;
};

const KINDS = {
  open: { fetch: (p) => api.trading.openOrders(p), empty: 'No open orders.' },
  history: { fetch: (p) => api.trading.orderHistory(p), empty: 'No order history yet.' },
  trades: { fetch: (p) => api.trading.tradeHistory(p), empty: 'No trades yet.' },
};

export function loadOrders(el, kind, opts = {}) {
  const def = KINDS[kind];
  const reload = () => loadOrders(el, kind, opts);
  return renderAsync(el, () => def.fetch({ limit: opts.limit }), (rows) => {
    const shown = opts.limit ? rows.slice(0, opts.limit) : rows;
    if (kind === 'trades') {
      return table({
        rows: shown, empty: def.empty,
        columns: [
          { label: 'Time', render: (r) => fmtTime(r.time) },
          { label: 'Symbol', key: 'symbol' },
          { label: 'Side', render: sideCell },
          { label: 'Amount', align: 'right', render: (r) => fmtAmount(r.amount) },
          { label: 'Price', align: 'right', render: (r) => fmtPrice(r.price) },
          { label: 'Fee', align: 'right', render: (r) => fmtAmount(r.fee) },
          { label: 'Order', key: 'orderId' },
        ],
      });
    }
    return table({ rows: shown, empty: def.empty, columns: orderColumns(kind === 'open', reload) });
  });
}

export function initOrders(view) {
  tabs($('#orders-tabs', view), [
    { id: 'open', label: 'Open orders', load: (el) => loadOrders(el, 'open') },
    { id: 'positions', label: 'Positions', load: (el) => loadPositions(el) },
  ]);
}

export function initHistory(view) {
  tabs($('#history-tabs', view), [
    { id: 'history', label: 'Order history', load: (el) => loadOrders(el, 'history') },
    { id: 'trades', label: 'Trade history', load: (el) => loadOrders(el, 'trades') },
  ]);
}

export async function initTrading(view) {
  let symbols = [];
  try { symbols = (await api.market.config()).symbols; } catch { /* handled below */ }
  if (!symbols.length) {
    view.replaceChildren(h('div', { class: 'notice error' }, 'No trading symbols are configured.'));
    return null;
  }
  const wanted = new URLSearchParams(location.hash.split('?')[1] || '').get('symbol');
  let symbol = symbols.includes(wanted) ? wanted : symbols[0];
  let interval = '15m';
  let lastPrice = null;
  let destroyed = false;

  const pair = $('#pair-select', view);
  symbols.forEach((s) => pair.append(h('option', { value: s }, s)));
  pair.value = symbol;
  const priceEl = $('#price-now', view);
  const changeEl = $('#price-change', view);

  const chart = createPriceChart($('#chart', view));
  const book = createOrderBook($('#ob-body', view));
  const panel = createTradingPanel($('#order-panel', view), {
    getSymbol: () => symbol,
    getPrice: () => lastPrice,
    onPlaced: () => { lower.reload(); },
  });
  const lower = tabs($('#lower-tabs', view), [
    { id: 'positions', label: 'Open positions', load: (el) => loadPositions(el) },
    { id: 'open', label: 'Open orders', load: (el) => loadOrders(el, 'open') },
    { id: 'history', label: 'Order history', load: (el) => loadOrders(el, 'history', { limit: 20 }) },
  ]);

  const group = $('#interval-group', view);
  const intervalButtons = INTERVALS.map((iv) => h('button', {
    type: 'button', 'aria-pressed': String(iv === interval),
    onClick: () => { interval = iv; intervalButtons.forEach((b, i) => b.setAttribute('aria-pressed', String(INTERVALS[i] === iv))); loadCandles(); },
  }, iv));
  group.append(...intervalButtons);

  async function tick() {
    const sym = symbol;
    try {
      const rows = await api.market.tickers();
      if (destroyed || sym !== symbol) return;
      const t = rows.find((r) => r.symbol === sym);
      lastPrice = t ? t.price : null;
      priceEl.className = t ? 'price-big' : 'price-big unavailable';
      priceEl.textContent = t ? fmtPrice(t.price) : 'Market data unavailable';
      changeEl.textContent = t ? `${fmtPct(t.change24hPct)} (24h)` : '';
      changeEl.className = `small ${t ? signClass(t.change24hPct) : 'muted'}`;
    } catch (e) {
      if (destroyed) return;
      lastPrice = null;
      priceEl.className = 'price-big unavailable';
      priceEl.textContent = 'Market data unavailable';
      changeEl.textContent = e.message;
      changeEl.className = 'muted small';
    }
    panel.recalc();
    book.update(sym);
  }

  async function loadCandles() {
    const sym = symbol;
    const iv = interval;
    try {
      const data = await api.market.klines({ symbol: sym, interval: iv });
      if (destroyed || sym !== symbol || iv !== interval) return;
      chart.setData(data);
    } catch (e) {
      if (!destroyed) { chart.setData([]); chart.setMessage(`Market data unavailable. ${e.message}`); }
    }
  }

  pair.addEventListener('change', () => {
    symbol = pair.value;
    lastPrice = null;
    priceEl.textContent = '—';
    changeEl.textContent = '';
    panel.recalc();
    tick();
    loadCandles();
  });

  panel.recalc();
  tick();
  loadCandles();
  const t1 = setInterval(tick, 4000);
  const t2 = setInterval(loadCandles, 15000);
  return () => { destroyed = true; clearInterval(t1); clearInterval(t2); chart.destroy(); };
}
