// Renderer-side API layer. Talks ONLY to the secure preload bridge (window.repit); the API key never reaches this process.

function fail(code, message) {
  const e = new Error(message);
  e.code = code;
  return e;
}

async function call(group, name, payload) {
  if (!window.repit) throw fail('BRIDGE', 'The secure bridge is unavailable. Restart Repit.');
  const res = await window.repit[group][name](payload);
  if (res && res.ok) return res.data;
  const err = fail((res && res.error && res.error.code) || 'ERROR', (res && res.error && res.error.message) || 'Request failed.');
  if (err.code === 'UNAUTHORIZED') window.dispatchEvent(new CustomEvent('repit:unauthorized'));
  throw err;
}

const group = (g, names) => Object.fromEntries(names.map((n) => [n, (payload) => call(g, n, payload)]));

export const api = {
  auth: group('auth', ['session', 'login', 'register', 'logout']),
  market: group('market', ['config', 'status', 'tickers', 'klines', 'orderbook']),
  trading: group('trading', ['balance', 'positions', 'openOrders', 'orderHistory', 'tradeHistory', 'placeOrder', 'cancelOrder']),
};
