import { api } from './api.js';
import { $, h, table, renderAsync, fmtPrice, fmtPct, fmtCompact, signClass } from './ui.js';

export function marketUnavailable(el, err) {
  el.replaceChildren(h('div', { class: 'notice warn', role: 'alert' },
    h('span', {}, h('strong', {}, 'Market data unavailable'), err && err.message ? ` — ${err.message}` : '')));
}

export function tickerTable(rows, { withTrade = false } = {}) {
  const columns = [
    { label: 'Symbol', key: 'symbol' },
    { label: 'Last price', align: 'right', render: (r) => fmtPrice(r.price) },
    { label: '24h change', align: 'right', render: (r) => fmtPct(r.change24hPct), cls: (r) => signClass(r.change24hPct) },
    { label: '24h volume', align: 'right', render: (r) => fmtCompact(r.volume24h) },
  ];
  if (withTrade) {
    columns.push({ label: '', align: 'right', render: (r) => h('a', { class: 'btn ghost sm', href: `#/trading?symbol=${encodeURIComponent(r.symbol)}` }, 'Trade') });
  }
  return table({ columns, rows, empty: 'No market data was returned for the configured symbols.' });
}

export function loadTickers(el, opts = {}) {
  return renderAsync(
    el,
    () => api.market.tickers(),
    (rows) => (opts.filter ? tickerTable(rows.filter((r) => r.symbol.includes(opts.filter())), opts) : tickerTable(rows, opts)),
    (e) => marketUnavailable(el, e)
  );
}

export function initMarkets(view) {
  const body = $('#markets-body', view);
  const filter = $('#market-filter', view);
  const load = () => loadTickers(body, { withTrade: true, filter: () => filter.value.trim().toUpperCase() });
  filter.addEventListener('input', load);
  load();
  const timer = setInterval(load, 5000);
  return () => clearInterval(timer);
}
