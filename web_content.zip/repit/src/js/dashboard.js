import { $ } from './ui.js';
import { createStatCards } from '../components/balance.js';
import { loadPositions } from '../components/positions.js';
import { loadTickers } from './market.js';
import { loadOrders } from './trading.js';

export function initDashboard(view) {
  const cards = createStatCards($('#stat-cards', view));
  const refresh = () => {
    cards.refresh();
    loadTickers($('#dash-markets', view));
    loadOrders($('#dash-orders', view), 'history', { limit: 8 });
    loadPositions($('#dash-positions', view));
  };
  refresh();
  const timer = setInterval(refresh, 10000);
  return () => clearInterval(timer);
}
