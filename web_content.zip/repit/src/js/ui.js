// Small DOM helpers. All dynamic content goes through textContent / text nodes (no innerHTML with data).

export function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else el.setAttribute(k, v === true ? '' : String(v));
  }
  for (const kid of kids.flat(Infinity)) {
    if (kid === null || kid === undefined || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return el;
}

export const $ = (sel, root = document) => root.querySelector(sel);
export const clear = (el) => el.replaceChildren();

const valid = (v) => typeof v === 'number' && Number.isFinite(v);
export function fmtPrice(v) {
  if (!valid(v)) return '—';
  const a = Math.abs(v);
  const max = a >= 1000 ? 2 : a >= 1 ? 4 : 6;
  return new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: max }).format(v);
}
export const fmtAmount = (v) => (valid(v) ? new Intl.NumberFormat('en-US', { maximumFractionDigits: 8 }).format(v) : '—');
export const fmtSigned = (v) => (valid(v) ? (v > 0 ? '+' : '') + new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(v) : '—');
export const fmtPct = (v) => (valid(v) ? `${v > 0 ? '+' : ''}${v.toFixed(2)}%` : '—');
export const fmtCompact = (v) => (valid(v) ? new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 2 }).format(v) : '—');
export const fmtTime = (ms) => (valid(ms) ? new Date(ms).toLocaleString() : '—');
export const signClass = (v) => (valid(v) ? (v > 0 ? 'pos' : v < 0 ? 'neg' : '') : '');

export function toast(message, type = 'info') {
  let box = document.getElementById('toasts');
  if (!box) {
    box = h('div', { id: 'toasts', class: 'toasts', 'aria-live': 'polite' });
    document.body.append(box);
  }
  const t = h('div', { class: `toast ${type}`, role: type === 'error' ? 'alert' : 'status' }, message);
  box.append(t);
  setTimeout(() => t.remove(), type === 'error' ? 8000 : 5000);
}

export function confirmModal({ title, rows, confirmText = 'Confirm', tone = 'primary' }) {
  return new Promise((resolve) => {
    const previous = document.activeElement;
    const done = (value) => {
      document.removeEventListener('keydown', onKey);
      back.remove();
      if (previous && previous.focus) previous.focus();
      resolve(value);
    };
    const onKey = (e) => { if (e.key === 'Escape') done(false); };
    const ok = h('button', { class: `btn ${tone}`, type: 'button', onClick: () => done(true) }, confirmText);
    const back = h('div', { class: 'modal-back', onClick: (e) => { if (e.target === back) done(false); } },
      h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
        h('h2', {}, title),
        h('dl', { class: 'kv' }, rows.map(([k, v]) => [h('dt', {}, k), h('dd', {}, v)])),
        h('div', { class: 'modal-actions' },
          h('button', { class: 'btn ghost', type: 'button', onClick: () => done(false) }, 'Cancel'), ok)));
    document.addEventListener('keydown', onKey);
    document.body.append(back);
    ok.focus();
  });
}

export function table({ columns, rows, empty = 'Nothing to show.' }) {
  if (!rows.length) return h('div', { class: 'empty' }, empty);
  return h('div', { class: 'table-wrap' },
    h('table', { class: 'tbl' },
      h('thead', {}, h('tr', {}, columns.map((c) => h('th', { class: c.align === 'right' ? 'r' : '' }, c.label)))),
      h('tbody', {}, rows.map((r) => h('tr', {}, columns.map((c) => {
        const v = c.render ? c.render(r) : r[c.key];
        const cls = [c.align === 'right' ? 'r' : '', c.cls ? c.cls(r) : ''].filter(Boolean).join(' ');
        return h('td', { class: cls }, v === null || v === undefined || v === '' ? '—' : v);
      }))))));
}

export function showError(el, message, onRetry) {
  el.replaceChildren(h('div', { class: 'notice error', role: 'alert' },
    h('span', {}, message),
    onRetry ? h('button', { class: 'btn ghost sm', type: 'button', onClick: onRetry }, 'Retry') : null));
}

// Fetch -> render with loading and error states. Keeps old content visible while polling.
export async function renderAsync(el, fetcher, render, onError) {
  if (!el.hasChildNodes()) el.replaceChildren(h('div', { class: 'empty' }, 'Loading…'));
  try {
    const data = await fetcher();
    if (!el.isConnected) return;
    el.replaceChildren(render(data));
  } catch (e) {
    if (!el.isConnected) return;
    if (onError) onError(e);
    else showError(el, e.message, () => renderAsync(el, fetcher, render, onError));
  }
}

export function tabs(root, items) {
  const bar = h('div', { class: 'tabs', role: 'tablist' });
  const panel = h('div', { class: 'tab-panel', role: 'tabpanel' });
  const buttons = new Map();
  let current = null;
  const select = (id) => {
    const item = items.find((i) => i.id === id);
    if (!item) return;
    current = id;
    buttons.forEach((b, k) => b.setAttribute('aria-selected', String(k === id)));
    panel.replaceChildren();
    item.load(panel);
  };
  items.forEach((it) => {
    const b = h('button', { class: 'tab', type: 'button', role: 'tab', onClick: () => select(it.id) }, it.label);
    buttons.set(it.id, b);
    bar.append(b);
  });
  root.append(bar, panel);
  select(items[0].id);
  return { select, reload: () => current && items.find((i) => i.id === current).load(panel) };
}

export function getTheme() {
  try { return localStorage.getItem('repit.theme') === 'light' ? 'light' : 'dark'; } catch { return 'dark'; }
}
export function setTheme(theme) {
  document.documentElement.dataset.theme = theme;
  try { localStorage.setItem('repit.theme', theme); } catch { /* theme is not a secret; ignore storage failures */ }
}
