import { api } from './api.js';
import { $, h, toast } from './ui.js';

function banner(view, session) {
  const slot = $('#auth-banner', view);
  if (session.error) slot.append(h('div', { class: 'notice error' }, session.error));
  else if (!session.authConfigured) {
    slot.append(h('div', { class: 'notice warn' }, 'The authentication service is not configured. Set REPIT_AUTH_URL in your .env file and restart Repit.'));
  }
}

function bindForm(form, button, errorEl, task) {
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorEl.hidden = true;
    button.disabled = true;
    const label = button.textContent;
    button.textContent = 'Please wait…';
    try {
      await task();
    } catch (ex) {
      errorEl.textContent = ex.message;
      errorEl.hidden = false;
    } finally {
      button.disabled = false;
      button.textContent = label;
    }
  });
}

export function initLogin(view, ctx) {
  banner(view, ctx.state.session);
  const form = $('#login-form', view);
  bindForm(form, $('button[type=submit]', form), $('#form-error', view), async () => {
    await api.auth.login({ email: $('#email', view).value, password: $('#password', view).value });
    $('#password', view).value = '';
    await ctx.refreshSession();
    ctx.navigate('dashboard');
  });
  $('#email', view).focus();
}

export function initRegister(view, ctx) {
  banner(view, ctx.state.session);
  const form = $('#register-form', view);
  bindForm(form, $('button[type=submit]', form), $('#form-error', view), async () => {
    const password = $('#password', view).value;
    if (password !== $('#confirm', view).value) throw new Error('The passwords do not match.');
    const res = await api.auth.register({ name: $('#name', view).value, email: $('#email', view).value, password });
    $('#password', view).value = '';
    $('#confirm', view).value = '';
    if (res.signedIn) {
      await ctx.refreshSession();
      ctx.navigate('dashboard');
    } else {
      toast('Account created by the Repit backend. Sign in to continue.', 'success');
      ctx.navigate('login');
    }
  });
  $('#email', view).focus();
}
