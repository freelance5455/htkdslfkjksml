import { api } from './api.js';
import { $, h, getTheme, setTheme, renderAsync } from './ui.js';

const kv = (pairs) => h('dl', { class: 'kv' }, pairs.map(([k, v]) => [h('dt', {}, k), h('dd', {}, v)]));
const STATE_TEXT = {
  connected: 'Connected', degraded: 'Reachable, but returning errors',
  unreachable: 'Unreachable', not_configured: 'Not configured',
};

export function initSettings(view, ctx) {
  const s = ctx.state.session;
  $('#set-account', view).append(kv([
    ['Name', s.user && s.user.name ? s.user.name : '—'],
    ['Email', s.user && s.user.email ? s.user.email : '—'],
    ['Sign-in', s.authRequired ? 'Required' : 'Disabled (REPIT_AUTH_REQUIRED=false)'],
  ]));

  const apiEl = $('#set-api', view);
  const loadApi = () => renderAsync(apiEl, () => api.market.status(), (st) => h('div', {},
    kv([
      ['Status', STATE_TEXT[st.state] || st.state],
      ['Detail', st.message || '—'],
      ['API server', st.origin || 'Not set'],
      ['Latency', st.latencyMs === null ? '—' : `${st.latencyMs} ms`],
      ['API key', st.keyConfigured ? 'Configured (hidden)' : 'Not configured'],
      ['Auth service', st.authConfigured ? 'Configured' : 'Not configured'],
      ['Symbols', st.symbols.join(', ')],
      ['Config file', st.envFile || 'No .env file found'],
    ]),
    h('button', { class: 'btn ghost sm', type: 'button', onClick: loadApi }, 'Check again')));
  loadApi();

  const themeEl = $('#set-theme', view);
  const buttons = ['dark', 'light'].map((t) => h('button', {
    type: 'button', 'aria-pressed': String(getTheme() === t),
    onClick: () => { setTheme(t); buttons.forEach((b, i) => b.setAttribute('aria-pressed', String(['dark', 'light'][i] === t))); },
  }, t === 'dark' ? 'Dark' : 'Light'));
  themeEl.append(h('div', { class: 'seg', role: 'group', 'aria-label': 'Theme' }, buttons));

  $('#set-security', view).append(h('ul', {},
    h('li', {}, 'The API key is read by the main process and is never sent to the interface.'),
    h('li', {}, 'Your sign-in session is held in memory only and ends when Repit closes.'),
    h('li', {}, 'Credentials are only sent over https:// (plain http is allowed for localhost only).'),
    h('li', {}, 'Orders are only reported as placed after the Repit API confirms them.')));

  const logoutPanel = $('#set-logout-panel', view);
  if (!s.authRequired) logoutPanel.hidden = true;
  else $('#set-logout', view).append(h('button', { class: 'btn primary', type: 'button', onClick: () => ctx.logout() }, 'Log out'));
}
