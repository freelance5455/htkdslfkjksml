# V123 — Time Visited column and visit-time ordering

- Added a Time Visited column to the main item list. It displays the most recent saved visit time for each item in the device's local time zone.
- Each newly recorded visit stores an ISO timestamp (`created_at`) and updates that date's `last_visited_at` value automatically when the visit is saved.
- Added Time Visited to the VIEW VISITS TODAY results.
- VIEW VISITS TODAY sorts by the actual visit timestamp, newest first. For records that contain only banked/MTN activity and no visit timestamp, the existing activity timestamp is used as a fallback so those activity-only rows remain ordered.
- Applied the change to both web and Android app assets. No Supabase schema change is required because timestamps are stored inside the existing `daily_progress` JSON data.

Older visits that were saved before this update may not have an exact time; they will show a dash unless a timestamp was already stored.
