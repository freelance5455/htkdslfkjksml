// Runs after "npm install". Copies the PDF library and fonts into src/vendor so the app works offline.
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const vendor = path.join(root, 'src', 'vendor');
fs.mkdirSync(path.join(vendor, 'files'), { recursive: true });

const pdf = path.join(root, 'node_modules', 'jspdf', 'dist', 'jspdf.umd.min.js');
if (fs.existsSync(pdf)) fs.copyFileSync(pdf, path.join(vendor, 'jspdf.umd.min.js'));
else console.warn('jsPDF not found. PDF export will use the internet copy.');

const families = { '@fontsource/dm-sans': [400, 500, 600, 700], '@fontsource/outfit': [500, 600, 700] };
let css = '';
for (const [pkg, weights] of Object.entries(families)) {
  const base = path.join(root, 'node_modules', pkg);
  for (const w of weights) {
    const f = path.join(base, `latin-${w}.css`);
    if (!fs.existsSync(f)) { console.warn('Missing font css', f); continue; }
    css += fs.readFileSync(f, 'utf8') + '\n';
  }
  const files = path.join(base, 'files');
  if (fs.existsSync(files)) {
    for (const n of fs.readdirSync(files)) {
      if (/-latin-(400|500|600|700)-normal\.(woff2|woff)$/.test(n)) fs.copyFileSync(path.join(files, n), path.join(vendor, 'files', n));
    }
  }
}
fs.writeFileSync(path.join(vendor, 'fonts.css'), css);
console.log('Offline libraries and fonts copied to src/vendor');
