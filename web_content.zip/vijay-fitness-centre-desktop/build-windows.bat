@echo off
title Build Vijay Fitness Centre for Windows
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Download the LTS version from https://nodejs.org , install it, then run this file again.
  pause
  exit /b 1
)
echo Installing parts (internet needed, takes a few minutes the first time)...
call npm install
if errorlevel 1 ( echo Install failed. & pause & exit /b 1 )
echo Building the Windows installer...
call npm run dist
if errorlevel 1 ( echo Build failed. & pause & exit /b 1 )
echo.
echo Done. Your installer and portable program are in the "dist" folder.
start "" "%~dp0dist"
pause
