/* ---------- Content: workouts and diets ---------- */
const WK = {
  beginner: { label: 'Beginner', lvl: 1, when: '3 days a week, full body, 45 minutes',
    blurb: 'Learn the movements with light loads. Build the habit first, then add weight every two weeks.',
    items: [
      ['Bodyweight squat', '3 × 12', '60s', 'Quads, glutes', 'Sit back, keep your chest up and knees over your toes.'],
      ['Incline push-up', '3 × 10', '60s', 'Chest, triceps', 'Hands on a bench. Body stays in one straight line.'],
      ['Seated dumbbell row', '3 × 12', '60s', 'Back, biceps', 'Pull elbows past your ribs and squeeze for one second.'],
      ['Glute bridge', '3 × 15', '45s', 'Glutes, hamstrings', 'Push through your heels and pause at the top.'],
      ['Light lat pulldown', '3 × 12', '60s', 'Lats', 'Pull the bar to your upper chest, not behind your neck.'],
      ['Dumbbell shoulder press', '3 × 10', '60s', 'Shoulders', 'Use a light weight and keep your ribs down.'],
      ['Plank', '3 × 20 sec', '45s', 'Core', 'Squeeze glutes and breathe. Stop when your hips sag.'],
      ['Brisk treadmill walk', '15 min', '-', 'Heart, legs', 'Slight incline, a pace where you can still talk.']
    ] },
  regular: { label: 'Regular', lvl: 2, when: '4 to 5 days a week, push, pull and legs split',
    blurb: 'For members with six months of training. Heavier compound lifts with a few isolation moves.',
    items: [
      ['Barbell bench press', '4 × 8-10', '90s', 'Chest, triceps', 'Shoulder blades pinched, feet planted, bar touches mid chest.'],
      ['Barbell back squat', '4 × 8', '120s', 'Quads, glutes', 'Break at hips and knees together. Hit parallel or lower.'],
      ['Pull-up or assisted pull-up', '4 × 8', '90s', 'Lats, biceps', 'Start from a dead hang and lead with your chest.'],
      ['Standing overhead press', '3 × 10', '90s', 'Shoulders', 'Squeeze glutes so your lower back stays neutral.'],
      ['Romanian deadlift', '3 × 10', '90s', 'Hamstrings, glutes', 'Push hips back, keep the bar close to your legs.'],
      ['Seated cable row', '3 × 12', '75s', 'Mid back', 'Do not rock your torso. Pause when the handle touches you.'],
      ['Dumbbell curl', '3 × 12', '60s', 'Biceps', 'Elbows pinned to your sides, control the way down.'],
      ['Triceps rope pushdown', '3 × 12', '60s', 'Triceps', 'Spread the rope at the bottom and lock out.'],
      ['Hanging knee raise', '3 × 12', '60s', 'Abs', 'Curl your pelvis up, do not just swing your legs.']
    ] },
  advanced: { label: 'Advanced', lvl: 3, when: '5 to 6 days a week, heavy blocks with a deload every fourth week',
    blurb: 'For members with two or more years of training. Heavy low-rep work plus high-intensity finishers.',
    items: [
      ['Conventional deadlift', '5 × 5', '180s', 'Back, glutes, legs', 'Wedge into the bar, push the floor away, lock out tall.'],
      ['Incline barbell bench press', '5 × 5', '150s', 'Upper chest', 'Bar to upper chest, forearms vertical at the bottom.'],
      ['Weighted pull-up', '4 × 6', '120s', 'Lats, biceps', 'Add weight on a belt only when you can do 10 clean reps.'],
      ['Front squat', '4 × 6', '150s', 'Quads, core', 'Elbows high, torso upright, drive straight up.'],
      ['Standing barbell press', '4 × 6', '120s', 'Shoulders, triceps', 'Move your head back, press the bar over mid foot.'],
      ['Pendlay row', '4 × 6', '120s', 'Back', 'Bar returns to the floor on every rep. Keep your back flat.'],
      ['Bulgarian split squat', '3 × 8 each leg', '90s', 'Quads, glutes', 'Back foot on a bench, lean slightly forward for glutes.'],
      ['Weighted dips', '3 × 8', '90s', 'Chest, triceps', 'Lean forward for chest, stay upright for triceps.'],
      ['Lateral raise drop set', '3 × 10 + 2 drops', '60s', 'Side delts', 'Cut the weight by a third after each failure and keep going.']
    ] },
  cardio: { label: 'Cardio', lvl: 2, when: '3 sessions a week, or 2 after a strength day',
    blurb: 'Build your heart and stamina. Mix one long easy session with one interval session each week.',
    items: [
      ['Zone 2 treadmill jog', '30 min', '-', 'Heart, legs', 'Hold a pace where you can speak in full sentences.'],
      ['Cycling intervals', '10 × (30s hard, 60s easy)', '-', 'Legs, lungs', 'Push the hard rounds to about 8 out of 10 effort.'],
      ['Rowing machine', '4 × 500 m', '90s', 'Full body', 'Legs, then back, then arms. Reverse on the way in.'],
      ['Skipping rope', '5 × 2 min', '45s', 'Calves, coordination', 'Small hops, wrists do the turning.'],
      ['Stair climber', '15 min', '-', 'Glutes, legs', 'Stand tall and do not lean on the rails.'],
      ['Battle ropes', '6 × 30 sec', '45s', 'Shoulders, core', 'Stay in a half squat and make big waves.'],
      ['Shadow boxing', '5 × 3 min', '60s', 'Shoulders, heart', 'Rotate through your hips on every punch.']
    ] },
  loss: { label: 'Weight loss', lvl: 3, when: '3 strength days and 3 conditioning days, one rest day',
    blurb: 'Circuits and intervals that keep your heart rate high. Pair this with the weight loss diet for a steady 0.5 kg a week.',
    items: [
      ['Burpees', '4 × 12', '40s', 'Full body', 'Land softly. Step back if your form breaks down.'],
      ['Kettlebell swing', '4 × 15', '45s', 'Glutes, hamstrings', 'Hinge, snap your hips, let the bell float.'],
      ['Jump squats', '4 × 15', '40s', 'Legs', 'Land on the balls of your feet and sink into the next rep.'],
      ['Mountain climbers', '4 × 40 sec', '20s', 'Core, shoulders', 'Hips low, drive knees to your chest quickly.'],
      ['Walking lunges', '3 × 20 steps', '45s', 'Legs, glutes', 'Long steps, back knee kisses the floor.'],
      ['Plank to push-up', '3 × 12', '45s', 'Core, chest', 'Keep hips still as you move from elbows to hands.'],
      ['Incline treadmill walk', '30 min', '-', 'Heart, glutes', '10 to 12 percent incline, no handrail holding.'],
      ['Sprint intervals', '8 × (20s on, 40s off)', '-', 'Whole body', 'Warm up for 10 minutes first. Stop if a muscle pulls.']
    ] },
  gain: { label: 'Weight gain', lvl: 4, when: '4 days a week, heavy compound lifts, minimal cardio',
    blurb: 'Lift heavy, rest well and eat above maintenance. Add 2.5 kg to a lift whenever you hit every rep.',
    items: [
      ['Barbell back squat', '5 × 5', '180s', 'Legs, glutes', 'Add weight each week. Film a set to check depth.'],
      ['Barbell bench press', '4 × 6-8', '120s', 'Chest, triceps', 'Ask for a spotter on your last set.'],
      ['Conventional deadlift', '4 × 5', '180s', 'Back, legs', 'Reset the bar on the floor between reps.'],
      ['Standing overhead press', '4 × 8', '120s', 'Shoulders', 'Do not lean back. Press straight overhead.'],
      ['Barbell row', '4 × 8', '90s', 'Back, biceps', 'Pull to your belly button, keep your torso still.'],
      ['Leg press', '4 × 10', '90s', 'Quads, glutes', 'Lower until your knees reach 90 degrees.'],
      ['Parallel bar dips', '3 × 10', '90s', 'Chest, triceps', 'Go slow on the way down and drive up hard.'],
      ['Barbell curl', '3 × 10', '60s', 'Biceps', 'No swinging. Squeeze at the top for one second.']
    ] }
};
const WK_ORDER = ['beginner', 'regular', 'advanced', 'cardio', 'loss', 'gain'];

const DIET = {
  loss: { label: 'Weight loss', kcal: 1720, p: 130, c: 175, f: 55, water: '3.5 L',
    why: 'A deficit of about 500 kcal a day with high protein to keep your muscle.',
    meals: [
      ['6:30 AM', 'Wake-up', 'Warm water with lemon and 5 soaked almonds.', 40, ''],
      ['8:00 AM', 'Breakfast', 'Omelette of 3 egg whites and 1 whole egg, 2 multigrain toast slices, green tea.', 340, 'Veg swap: 2 moong dal chillas with mint chutney.'],
      ['10:30 AM', 'Mid-morning', '1 apple or a bowl of papaya and a handful of roasted makhana.', 130, ''],
      ['1:00 PM', 'Lunch', '2 rotis, 1 bowl dal, 120 g grilled chicken, a large salad and a small bowl of curd.', 520, 'Veg swap: 100 g paneer or 1 cup rajma instead of chicken.'],
      ['4:30 PM', 'Evening snack', 'Sprouts chaat or 30 g roasted chana with black coffee.', 150, ''],
      ['7:30 PM', 'Post-workout', '1 scoop whey in water, or 3 boiled egg whites and half a banana.', 150, 'Veg swap: 1 scoop whey or a glass of buttermilk with roasted chana.'],
      ['9:00 PM', 'Dinner', '120 g grilled fish or chicken, sautéed vegetables, 1 roti and clear soup.', 290, 'Veg swap: 120 g tofu or paneer tikka.'],
      ['10:30 PM', 'Bedtime', '1 glass warm toned milk with a pinch of turmeric.', 100, '']
    ],
    tips: ['Drink a glass of water before each meal.', 'Keep sugar, fried snacks and sweet drinks to one small serving a week.', 'Sleep 7 to 8 hours. Poor sleep raises hunger.', 'Weigh yourself once a week, same day, same time.', 'Walk 8,000 to 10,000 steps on non-gym days.'] },
  gain: { label: 'Weight gain', kcal: 3050, p: 160, c: 400, f: 90, water: '4 L',
    why: 'A surplus of about 400 kcal a day with enough protein to turn the extra food into muscle.',
    meals: [
      ['6:30 AM', 'Wake-up', '1 banana and 8 soaked almonds.', 250, ''],
      ['8:30 AM', 'Breakfast', '3 scrambled whole eggs, 2 parathas with a little ghee and 1 glass whole milk.', 600, 'Veg swap: 100 g paneer bhurji instead of eggs.'],
      ['11:30 AM', 'Mid-morning', 'Smoothie of whole milk, banana, 40 g oats and 1 tbsp peanut butter.', 400, ''],
      ['2:00 PM', 'Lunch', '3 rotis and 1 cup rice, dal, 150 g chicken curry, curd and salad.', 700, 'Veg swap: 100 g paneer or a bowl of soya chunks curry.'],
      ['5:30 PM', 'Evening snack', '2 boiled eggs, 1 small sweet potato and a handful of dry fruits.', 250, ''],
      ['7:30 PM', 'Post-workout', '1 scoop whey in milk and 1 banana.', 250, ''],
      ['9:00 PM', 'Dinner', '2 rotis, 150 g fish or chicken, vegetable sabzi and a bowl of dal.', 450, 'Veg swap: 120 g paneer and a bowl of rajma.'],
      ['10:30 PM', 'Bedtime', '1 glass warm whole milk with 2 dates.', 150, '']
    ],
    tips: ['Eat every 3 hours. Do not skip a meal even if you are not hungry.', 'Add a tablespoon of ghee or peanut butter to meals to raise calories easily.', 'Keep cardio to 2 short sessions a week.', 'Sleep 8 hours. Muscle grows while you rest.', 'Aim for 0.25 to 0.5 kg gain per week. Faster gain is mostly fat.'] }
};

const PLANS = [
  { id: 'monthly', name: 'Monthly', days: 30, price: 1500 },
  { id: 'quarterly', name: 'Quarterly', days: 90, price: 4000 },
  { id: 'half', name: 'Half-yearly', days: 180, price: 7200 },
  { id: 'annual', name: 'Annual', days: 365, price: 12000 }
];

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const DEFAULT_PLAN = [
  { focus: 'Chest and triceps', min: 60, ex: 'Barbell bench press 4 × 8-10\nIncline push-up 3 × 10\nTriceps rope pushdown 3 × 12' },
  { focus: 'Back and biceps', min: 60, ex: 'Pull-up or assisted pull-up 4 × 8\nSeated cable row 3 × 12\nDumbbell curl 3 × 12' },
  { focus: 'Legs and glutes', min: 65, ex: 'Barbell back squat 4 × 8\nRomanian deadlift 3 × 10\nWalking lunges 3 × 20 steps' },
  { focus: 'Shoulders and abs', min: 55, ex: 'Standing overhead press 3 × 10\nDumbbell shoulder press 3 × 10\nHanging knee raise 3 × 12\nPlank 3 × 20 sec' },
  { focus: 'Cardio and conditioning', min: 45, ex: 'Zone 2 treadmill jog 30 min\nSkipping rope 5 × 2 min\nBattle ropes 6 × 30 sec' },
  { focus: 'Full body circuit', min: 50, ex: 'Kettlebell swing 4 × 15\nBurpees 4 × 12\nMountain climbers 4 × 40 sec' },
  { focus: 'Rest and mobility', min: 20, ex: 'Light walk 20 min\nHip and shoulder stretching 10 min' }
];
