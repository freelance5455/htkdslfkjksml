/* ---------- Helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const DAYMS = 86400000;
const today0 = () => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); };
const pad = n => String(n).padStart(2, '0');
const iso = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const parseISO = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const diffDays = (a, b) => Math.round((a - b) / DAYMS);
const mkey = d => d.getFullYear() + '-' + pad(d.getMonth() + 1);
const fmtD = d => d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
const MONS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const money = n => (n < 0 ? '-' : '') + '₹' + Math.abs(Math.round(n)).toLocaleString('en-IN');
const compact = n => { const a = Math.abs(n); return (n < 0 ? '-' : '') + (a >= 100000 ? (a / 100000).toFixed(1).replace(/\.0$/, '') + 'L' : a >= 1000 ? Math.round(a / 1000) + 'k' : Math.round(a)); };
const mulberry = a => () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
const reduceMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ---------- State ---------- */
const KEY = 'vfc.v2';
function loadState() { try { return JSON.parse(localStorage.getItem(KEY)); } catch (e) { return null; } }
let saveT = 0;
function save() { clearTimeout(saveT); saveT = setTimeout(() => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { } }, 250); }

function seedState() {
  const rnd = mulberry(20261015);
  const first = ['Arjun', 'Karthik', 'Rahul', 'Suresh', 'Vikram', 'Manoj', 'Naveen', 'Prakash', 'Ramesh', 'Sanjay', 'Deepak', 'Harish', 'Ganesh', 'Mohan', 'Dinesh', 'Ajay', 'Bala', 'Ravi', 'Surya', 'Vignesh', 'Priya', 'Divya', 'Anitha', 'Meena', 'Kavya', 'Lakshmi'];
  const last = ['Kumar', 'Raj', 'Murugan', 'Babu', 'Nair', 'Reddy', 'Iyer', 'Pillai', 'Sharma', 'Naidu', 'Selvam', 'Das'];
  const t = today0(), members = [], pay = [];
  for (let i = 0; i < 68; i++) {
    const r = rnd(), plan = r < .5 ? PLANS[0] : r < .75 ? PLANS[1] : r < .9 ? PLANS[2] : PLANS[3];
    const paidOn = addDays(t, -Math.floor(rnd() * (plan.days + 11)));
    const m = { id: 'm' + i, name: first[Math.floor(rnd() * first.length)] + ' ' + last[Math.floor(rnd() * last.length)], phone: String(9000010000 + i), plan: plan.id, paidOn: iso(paidOn), joined: iso(addDays(paidOn, -Math.floor(rnd() * 420))) };
    members.push(m);
    pay.push({ id: 'p' + i, mid: m.id, date: m.paidOn, amt: plan.price, plan: plan.name });
  }
  const hist = {}, seas = [1.10, 1.08, .98, .96, .94, .92, .93, .97, 1.02, 1.04, 1.06, 1.12];
  for (let k = 23; k >= 1; k--) {
    const d = new Date(t.getFullYear(), t.getMonth() - k, 1), i = 23 - k;
    hist[mkey(d)] = {
      rev: Math.round((50000 + i * 1300) * seas[d.getMonth()] / 100 + (rnd() - .5) * 50) * 100,
      exp: Math.round((38000 + i * 500) / 100 + (rnd() - .5) * 30) * 100,
      nm: Math.round(9 + i * .25 + rnd() * 5)
    };
  }
  return {
    v: 2, members, pay, hist, curExp: 50000,
    rem: { before: true, beforeDays: 3, onDue: true, overdue: true, repeat: 3, tpl: 'Hi {name}, this is Vijay Fitness Centre. Your {plan} membership fee of {amount} {when} {date}. Please pay at the front desk or by UPI. Thank you.' },
    log: [], sent: {},
    plan: { name: '', goal: 'Weight loss', level: 'Beginner', days: JSON.parse(JSON.stringify(DEFAULT_PLAN)) },
    wTab: 'beginner', dTab: 'loss', eaten: null, filter: 'all', range: 12, addDay: 0
  };
}
let S = loadState();
if (!S || S.v !== 2) S = seedState();

/* ---------- Derived numbers ---------- */
function info(m) {
  const p = PLANS.find(x => x.id === m.plan) || PLANS[0];
  const due = addDays(parseISO(m.paidOn), p.days);
  const days = diffDays(due, today0());
  return { p, due, days, st: days < 0 ? 'od' : days <= 5 ? 'soon' : 'ok' };
}
function monthStats() {
  const t = today0(), key = mkey(t), dim = new Date(t.getFullYear(), t.getMonth() + 1, 0).getDate();
  const rev = S.pay.filter(p => p.date.startsWith(key)).reduce((a, p) => a + p.amt, 0);
  const exp = Math.round(S.curExp * t.getDate() / dim);
  const nm = S.members.filter(m => m.joined.startsWith(key)).length;
  return { key, rev, exp, profit: rev - exp, nm };
}
function series() {
  const t = today0(), cur = monthStats(), out = [];
  Object.keys(S.hist).sort().forEach(k => { const [y, m] = k.split('-').map(Number); out.push({ key: k, y, m: m - 1, rev: S.hist[k].rev, exp: S.hist[k].exp, nm: S.hist[k].nm, partial: false }); });
  out.push({ key: cur.key, y: t.getFullYear(), m: t.getMonth(), rev: cur.rev, exp: cur.exp, nm: cur.nm, partial: true });
  out.forEach(d => d.profit = d.rev - d.exp);
  return out;
}
function dueTotals() {
  const r = { od: 0, odAmt: 0, soon: 0, soonAmt: 0 };
  S.members.forEach(m => { const i = info(m); if (i.st === 'od') { r.od++; r.odAmt += i.p.price; } else if (i.st === 'soon') { r.soon++; r.soonAmt += i.p.price; } });
  return r;
}

/* ---------- Toast and navigation ---------- */
let toastT = 0;
function toast(msg) { const el = $('#toast'); el.textContent = msg; el.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('on'), 2800); }

const pagesEl = $('#pages');
let curPage = 0;
function goPage(i) { pagesEl.scrollTo({ left: i * pagesEl.clientWidth, behavior: reduceMotion ? 'auto' : 'smooth' }); }
function updateTabs() {
  const w = pagesEl.clientWidth || 1, idx = Math.max(0, Math.min(4, Math.round(pagesEl.scrollLeft / w)));
  curPage = idx;
  const btns = $$('#tabs button');
  btns.forEach((b, i) => i === idx ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current'));
  const b = btns[idx], ind = $('#ind');
  if (b) { ind.style.width = (b.offsetWidth - 12) + 'px'; ind.style.left = (b.offsetLeft + 6) + 'px'; }
}
let tiltRaf = 0;
function tiltPages() {
  tiltRaf = 0;
  const w = pagesEl.clientWidth || 1;
  $$('.page').forEach((el, i) => {
    const off = (i * w - pagesEl.scrollLeft) / w, a = Math.abs(off);
    if (a < .002 || reduceMotion) { el.style.transform = ''; el.style.opacity = ''; return; }
    el.style.transform = `rotateY(${(off * -18).toFixed(2)}deg) scale(${(1 - a * .06).toFixed(3)})`;
    el.style.opacity = (1 - Math.min(1, a) * .55).toFixed(2);
  });
}
pagesEl.addEventListener('scroll', () => { updateTabs(); if (!tiltRaf) tiltRaf = requestAnimationFrame(tiltPages); }, { passive: true });
window.addEventListener('resize', () => { updateTabs(); pagesEl.scrollTo({ left: curPage * pagesEl.clientWidth, behavior: 'auto' }); });
document.addEventListener('keydown', e => {
  if (/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) return;
  if (e.key === 'ArrowRight') goPage(Math.min(4, curPage + 1));
  if (e.key === 'ArrowLeft') goPage(Math.max(0, curPage - 1));
  if (e.key === 'Escape') closeMenu();
});

/* ---------- Home ---------- */
function ringSVG(pct, color, size, stroke) {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r, h = size / 2;
  return `<svg viewBox="0 0 ${size} ${size}" aria-hidden="true"><circle cx="${h}" cy="${h}" r="${r}" fill="none" stroke="rgba(29,44,41,.09)" stroke-width="${stroke}"/><circle cx="${h}" cy="${h}" r="${r}" fill="none" stroke="${color}" stroke-width="${stroke}" stroke-linecap="round" stroke-dasharray="${(c * Math.max(0, Math.min(100, pct)) / 100).toFixed(1)} ${c.toFixed(1)}"/></svg>`;
}
function rHome() {
  const h = new Date().getHours();
  $('#greet').textContent = (h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening') + ', champion';
  const ms = monthStats(), dt = dueTotals(), total = S.members.length || 1, tl = todayLog().length;
  const pct = Math.round((total - dt.od) / total * 100);
  $('#homeRing').innerHTML = ringSVG(pct, 'var(--teal)', 112, 12) + `<b>${pct}%</b>`;
  $('#homeStats').innerHTML = [['var(--teal)', 'Paid up', S.members.length - dt.od - dt.soon], ['#f0aa3c', 'Due in 5 days', dt.soon], ['var(--coral)', 'Overdue', dt.od], ['var(--grey)', 'Reminders today', tl]]
    .map(s => `<div><span><i style="background:${s[0]}"></i>${s[1]}</span><b class="num">${s[2]}</b></div>`).join('');
  const t = today0(), days = [];
  for (let i = 6; i >= 0; i--) { const d = addDays(t, -i), k = iso(d); days.push({ l: 'SMTWTFS'[d.getDay()], amt: S.pay.filter(p => p.date === k).reduce((a, p) => a + p.amt, 0), today: i === 0, d }); }
  const mx = Math.max(1, ...days.map(d => d.amt));
  $('#wbars').innerHTML = days.map(d => `<div class="${d.today ? 'today' : ''}" title="${fmtD(d.d)}: ${money(d.amt)}"><span class="num">${d.amt ? compact(d.amt) : ''}</span><i style="height:${Math.max(8, d.amt / mx * 70)}px"></i><span>${d.l}</span></div>`).join('');
  $('#homeKpis').innerHTML = [
    ['Active members', S.members.length, S.members.length - dt.od + ' paid up'],
    ['Collected this month', money(ms.rev), 'to date'],
    ['Overdue fees', money(dt.odAmt), dt.od + ' members', dt.od ? 'dn' : ''],
    ['Profit this month', money(ms.profit), 'to date', ms.profit >= 0 ? 'up' : 'dn']
  ].map(k => `<div class="card kpi tilt"><span class="k">${k[0]}</span><span class="v num">${k[1]}</span><span class="d ${k[3] || ''}">${k[2]}</span></div>`).join('');
  $('#quickDues').textContent = dt.od ? `${dt.od} overdue, ${money(dt.odAmt)}` : 'Everyone is paid up';
  $('#bellCount').textContent = tl; $('#bellCount').hidden = !tl;
}

/* ---------- Dashboard ---------- */
function rDash() {
  const ser = series(), cur = ser[ser.length - 1], prev = ser[ser.length - 2];
  const margin = cur.rev ? Math.round(cur.profit / cur.rev * 100) : 0;
  const tot12 = ser.slice(-12).reduce((a, d) => a + d.profit, 0);
  $('#dashKpis').innerHTML = [
    ['Revenue', money(cur.rev), 'Last month ' + money(prev.rev)],
    ['Expenses', money(cur.exp), 'Monthly budget ' + money(S.curExp)],
    ['Profit', money(cur.profit), margin + '% margin, month to date', cur.profit >= 0 ? 'up' : 'dn'],
    ['12-month profit', money(tot12), 'Including this month', tot12 >= 0 ? 'up' : 'dn']
  ].map(k => `<div class="card kpi tilt"><span class="k">${k[0]}</span><span class="v num">${k[1]}</span><span class="d ${k[3] || ''}">${k[2]}</span></div>`).join('');

  $('#rangeChips').innerHTML = [[6, '6 months'], [12, '12 months'], [25, 'All history']].map(r => `<button class="chip" aria-pressed="${S.range === r[0]}" data-range="${r[0]}">${r[1]}</button>`).join('');
  drawTrend();

  const counts = PLANS.map(p => S.members.filter(m => m.plan === p.id).length), total = S.members.length || 1;
  const cols = ['var(--teal)', '#7fd3bd', 'var(--coral)', 'var(--grey)'];
  $('#mix').innerHTML = counts.map((c, i) => `<i style="width:${c / total * 100}%;background:${cols[i]}"></i>`).join('');
  $('#mixl').innerHTML = PLANS.map((p, i) => `<div><span><i style="background:${cols[i]}"></i>${p.name}</span><span class="num">${counts[i]} members · ${money(p.price)}</span></div>`).join('');

  const names = Object.fromEntries(S.members.map(m => [m.id, m.name]));
  $('#recentPay').innerHTML = S.pay.slice().sort((a, b) => b.date < a.date ? -1 : b.date > a.date ? 1 : 0).slice(0, 6)
    .map(p => `<div><span>${esc(names[p.mid] || 'Former member')}<small>${p.plan} · ${fmtD(parseISO(p.date))}</small></span><b class="num">${money(p.amt)}</b></div>`).join('') || '<div class="note">No payments yet.</div>';

  const rows = ser.slice().reverse().map(d => {
    const mg = d.rev ? Math.round(d.profit / d.rev * 100) : 0, label = MONS[d.m] + ' ' + d.y + (d.partial ? ' (to date)' : '');
    const rev = d.partial ? `<td class="num">${money(d.rev)}</td>` : `<td><input type="number" min="0" step="100" value="${d.rev}" data-h="${d.key}" data-f="rev" aria-label="Revenue ${label}"></td>`;
    const exp = d.partial ? `<td><input type="number" min="0" step="100" value="${S.curExp}" data-h="cur" data-f="exp" aria-label="Monthly expenses this month" title="Monthly budget. Shown pro rata to date."></td>` : `<td><input type="number" min="0" step="100" value="${d.exp}" data-h="${d.key}" data-f="exp" aria-label="Expenses ${label}"></td>`;
    return `<tr class="${d.partial ? 'cur' : ''}"><td>${label}</td>${rev}${exp}<td class="num ${d.profit >= 0 ? 'pos' : 'neg'}">${money(d.profit)}</td><td class="num">${mg}%</td><td class="num">${d.nm}</td></tr>`;
  }).join('');
  $('#histTbl').innerHTML = `<thead><tr><th>Month</th><th>Revenue</th><th>Expenses</th><th>Profit</th><th>Margin</th><th>New members</th></tr></thead><tbody>${rows}</tbody>`;
}

function drawTrend() {
  const all = series(), ser = all.slice(-S.range);
  const W = 720, H = 300, L = 54, R = 14, T = 14, B = 30;
  const maxV = Math.max(...ser.map(d => Math.max(d.rev, d.exp)));
  const nice = Math.max(20000, Math.ceil(maxV / 20000) * 20000);
  const x = i => L + (ser.length === 1 ? 0 : i * (W - L - R) / (ser.length - 1));
  const y = v => T + (1 - v / nice) * (H - T - B);
  const line = k => ser.slice(0, -1).map((d, i) => (i ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(d[k]).toFixed(1)).join(' ');
  const n = ser.length, last = (k) => `M${x(n - 2).toFixed(1)} ${y(ser[n - 2][k]).toFixed(1)} L${x(n - 1).toFixed(1)} ${y(ser[n - 1][k]).toFixed(1)}`;
  const area = ser.slice(0, -1).map((d, i) => (i ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(Math.max(0, d.profit)).toFixed(1)).join(' ') + ` L${x(n - 2).toFixed(1)} ${y(0)} L${x(0).toFixed(1)} ${y(0)} Z`;
  let grid = '';
  for (let i = 0; i <= 4; i++) { const v = nice / 4 * i, yy = y(v); grid += `<line x1="${L}" x2="${W - R}" y1="${yy}" y2="${yy}" style="stroke:var(--line)" stroke-dasharray="${i ? '3 5' : '0'}"/><text x="${L - 8}" y="${yy + 4}" text-anchor="end">${compact(v)}</text>`; }
  const step = Math.ceil(n / 8); let xl = '';
  ser.forEach((d, i) => { if (i % step === 0 || (i === n - 1 && (n - 1) % step >= Math.ceil(step / 2))) xl += `<text x="${x(i)}" y="${H - 8}" text-anchor="middle">${MONS[d.m]}${d.m === 0 || i === 0 ? ' ’' + String(d.y).slice(2) : ''}</text>`; });
  const dot = (k, c) => `<circle cx="${x(n - 1)}" cy="${y(ser[n - 1][k])}" r="5.5" style="fill:var(--card-solid);stroke:${c};stroke-width:3"/>`;
  $('#trend').innerHTML = `
    <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Revenue, expenses and profit by month">
      <defs><linearGradient id="pg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--coral);stop-opacity:.45"/><stop offset="1" style="stop-color:var(--coral);stop-opacity:0"/></linearGradient></defs>
      ${grid}${xl}
      <path d="${area}" fill="url(#pg)"/>
      <path d="${line('exp')}" fill="none" style="stroke:var(--grey)" stroke-width="2.5" stroke-linejoin="round"/>
      <path d="${line('rev')}" fill="none" style="stroke:var(--teal)" stroke-width="3" stroke-linejoin="round"/>
      <path d="${line('profit')}" fill="none" style="stroke:var(--coral)" stroke-width="3" stroke-linejoin="round"/>
      ${dot('exp', 'var(--grey)')}${dot('rev', 'var(--teal)')}${dot('profit', 'var(--coral)')}
      <g id="hov" style="display:none"><line id="hl" y1="${T}" y2="${H - B}" style="stroke:var(--mute)" stroke-dasharray="2 4"/><circle id="h1" r="5" style="fill:var(--teal)"/><circle id="h2" r="5" style="fill:var(--grey)"/><circle id="h3" r="5" style="fill:var(--coral)"/></g>
      <rect id="hit" x="${L}" y="0" width="${W - L - R}" height="${H}" fill="transparent"/>
    </svg><div class="tip" id="tip"></div>`;
  $('#trendNote').textContent = `${MONS[ser[0].m]} ${ser[0].y} to ${MONS[ser[n - 1].m]} ${ser[n - 1].y}. Hollow dots show this month so far.`;
  const svg = $('#trend svg'), tip = $('#tip'), hov = $('#hov');
  const move = ev => {
    const r = svg.getBoundingClientRect(), px = (ev.clientX - r.left) / r.width * W;
    const i = Math.max(0, Math.min(n - 1, Math.round((px - L) / ((W - L - R) / Math.max(1, n - 1)))));
    const d = ser[i], xx = x(i);
    hov.style.display = ''; $('#hl').setAttribute('x1', xx); $('#hl').setAttribute('x2', xx);
    [['h1', 'rev'], ['h2', 'exp'], ['h3', 'profit']].forEach(([id, k]) => { const c = $('#' + id); c.setAttribute('cx', xx); c.setAttribute('cy', y(Math.max(0, d[k]))); });
    tip.style.display = 'block';
    tip.innerHTML = `<b>${MONS[d.m]} ${d.y}${d.partial ? ' (to date)' : ''}</b><div><span>Revenue</span><span class="num">${money(d.rev)}</span></div><div><span>Expenses</span><span class="num">${money(d.exp)}</span></div><div><span>Profit</span><span class="num">${money(d.profit)}</span></div>`;
    const wpx = r.width, left = Math.max(84, Math.min(wpx - 84, xx / W * wpx));
    tip.style.left = left + 'px';
  };
  svg.addEventListener('pointermove', move); svg.addEventListener('pointerdown', move);
  svg.addEventListener('pointerleave', () => { hov.style.display = 'none'; tip.style.display = 'none'; });
}

/* ---------- Members, dues, reminders ---------- */
function rDueKpis() {
  const dt = dueTotals(), ms = monthStats();
  $('#dueKpis').innerHTML = [
    ['Overdue', money(dt.odAmt), dt.od + ' members', dt.od ? 'dn' : ''],
    ['Due in 5 days', money(dt.soonAmt), dt.soon + ' members'],
    ['Collected this month', money(ms.rev), 'to date', 'up'],
    ['Queued today', todayLog().length, 'reminder messages']
  ].map(k => `<div class="card kpi tilt"><span class="k">${k[0]}</span><span class="v num">${k[1]}</span><span class="d ${k[3] || ''}">${k[2]}</span></div>`).join('');
}
function rFilters() {
  const dt = dueTotals(), c = { all: S.members.length, od: dt.od, soon: dt.soon, ok: S.members.length - dt.od - dt.soon };
  $('#filterChips').innerHTML = [['all', 'All'], ['od', 'Overdue'], ['soon', 'Due soon'], ['ok', 'Paid up']].map(f => `<button class="chip" aria-pressed="${S.filter === f[0]}" data-filter="${f[0]}">${f[1]} ${c[f[0]]}</button>`).join('');
}
function waLink(phone, msg) {
  const d = String(phone || '').replace(/\D/g, '');
  const num = d.length === 10 ? '91' + d : d;
  return 'https://wa.me/' + num + '?text=' + encodeURIComponent(msg);
}
function buildMsg(m, when) {
  const i = info(m);
  return S.rem.tpl.replace(/\{name\}/g, m.name.split(' ')[0]).replace(/\{plan\}/g, i.p.name).replace(/\{amount\}/g, money(i.p.price)).replace(/\{date\}/g, fmtD(i.due)).replace(/\{when\}/g, when || (i.days < 0 ? 'was due on' : 'is due on'));
}
function rMembers() {
  rDueKpis(); rFilters();
  const q = $('#search').value.trim().toLowerCase();
  const list = S.members.map(m => ({ m, i: info(m) })).filter(o => (S.filter === 'all' || o.i.st === S.filter) && (!q || o.m.name.toLowerCase().includes(q) || o.m.phone.includes(q)))
    .sort((a, b) => a.i.days - b.i.days);
  $('#mgrid').innerHTML = list.map(({ m, i }) => {
    const pill = i.st === 'od' ? `<span class="pill bad">Overdue ${-i.days}d</span>` : i.st === 'soon' ? `<span class="pill warn">${i.days === 0 ? 'Due today' : 'Due in ' + i.days + 'd'}</span>` : `<span class="pill ok">Paid up</span>`;
    const ini = m.name.split(' ').map(w => w[0]).join('').slice(0, 2);
    return `<div class="mem ${i.st === 'od' ? 'od' : ''}"><div class="av">${esc(ini)}</div><div style="min-width:0"><div class="nm">${esc(m.name)}</div><div class="mt">${i.p.name} · ${fmtD(i.due)}</div></div>
      <div class="row">${pill}<span class="num"><b>${money(i.p.price)}</b></span><div class="acts">
        ${i.st !== 'ok' ? `<button class="btn sm red" data-act="pay" data-id="${m.id}">Mark paid</button>` : `<button class="btn sm" data-act="pay" data-id="${m.id}">Renew</button>`}
        <a class="btn sm" style="display:inline-flex;align-items:center" target="_blank" rel="noopener" href="${esc(waLink(m.phone, buildMsg(m)))}">Remind</a>
        <button class="btn sm ghost" data-act="rm" data-id="${m.id}">Remove</button></div></div></div>`;
  }).join('') || '<div class="note">No members match.</div>';
}
function rRules() {
  const r = S.rem;
  $('#remRules').innerHTML = `
    <div class="switch"><span>Remind before the due date<br><span class="note">Days before:</span> <input class="n num" type="number" min="1" max="14" id="rBeforeN" value="${r.beforeDays}"></span><input type="checkbox" id="rBefore" ${r.before ? 'checked' : ''} aria-label="Remind before due date"></div>
    <div class="switch"><span>Remind on the due date</span><input type="checkbox" id="rOn" ${r.onDue ? 'checked' : ''} aria-label="Remind on due date"></div>
    <div class="switch"><span>Remind when overdue<br><span class="note">Repeat every</span> <input class="n num" type="number" min="1" max="14" id="rRepN" value="${r.repeat}"> <span class="note">days</span></span><input type="checkbox" id="rOver" ${r.overdue ? 'checked' : ''} aria-label="Remind when overdue"></div>`;
  $('#tpl').value = r.tpl;
}
function todayLog() { const k = iso(today0()); return S.log.filter(l => l.day === k); }
const TYPE = { soon: ['Due soon', 'warn'], today: ['Due today', 'warn'], od: ['Overdue', 'bad'] };
function scan(manual) {
  const k = iso(today0()), r = S.rem; let added = 0;
  Object.keys(S.sent).forEach(s => { if (!s.endsWith('|' + k)) delete S.sent[s]; });
  S.members.forEach(m => {
    const i = info(m); let type = '';
    if (r.before && i.days === r.beforeDays) type = 'soon';
    else if (r.onDue && i.days === 0) type = 'today';
    else if (r.overdue && i.days < 0 && (-i.days) % Math.max(1, r.repeat) === 0) type = 'od';
    if (!type) return;
    const key = m.id + '|' + type + '|' + k;
    if (S.sent[key]) return;
    S.sent[key] = 1;
    S.log.unshift({ ts: Date.now(), day: k, mid: m.id, name: m.name, phone: m.phone, type, msg: buildMsg(m, type === 'od' ? 'was due on' : 'is due on') });
    added++;
  });
  S.log = S.log.slice(0, 80);
  if (added) save();
  rLog(); rDueKpis(); rHome();
  if (manual) toast(added ? added + ' reminders queued' : 'Nothing new to queue right now');
}
function rLog() {
  $('#remLog').innerHTML = S.log.slice(0, 40).map(l => {
    const t = TYPE[l.type], d = new Date(l.ts), when = (l.day === iso(today0()) ? 'Today ' : fmtD(d) + ' ') + pad(d.getHours()) + ':' + pad(d.getMinutes());
    return `<div><span><b>${esc(l.name)}</b> <span class="pill ${t[1]}">${t[0]}</span> <span class="note">${when}</span></span><a class="btn sm" style="display:inline-flex;align-items:center" target="_blank" rel="noopener" href="${esc(waLink(l.phone, l.msg))}">Open in WhatsApp</a><span class="m">${esc(l.msg)}</span></div>`;
  }).join('') || '<div class="note" style="padding:10px 0">No reminders queued yet. Members who are due soon, due today or overdue will appear here.</div>';
}

/* ---------- Workouts ---------- */
function rWork() {
  $('#wTabs').innerHTML = WK_ORDER.map(k => `<button class="chip" role="tab" aria-pressed="${S.wTab === k}" data-wtab="${k}">${WK[k].label}</button>`).join('');
  const w = WK[S.wTab], q = (($('#wSearch') || {}).value || '').trim().toLowerCase();
  const rows = w.items.map((e, i) => [e, i]).filter(([e]) => !q || e[0].toLowerCase().includes(q) || e[3].toLowerCase().includes(q));
  const bars = [1, 2, 3, 4].map(n => `<i class="${n <= w.lvl ? 'on' : ''}" style="height:${8 + n * 5}px"></i>`).join('');
  const dayOpts = DAYS.map((d, i) => `<option value="${i}" ${S.addDay === i ? 'selected' : ''}>${d}</option>`).join('');
  $('#wBody').innerHTML = `
    <div class="cat-head"><div><h3>${w.label} workout</h3><div class="note" style="margin-top:4px">${w.when}</div></div><div class="lvl" title="Intensity ${w.lvl} of 4" aria-label="Intensity ${w.lvl} of 4">${bars}</div></div>
    <p class="sub" style="margin-bottom:12px">${w.blurb}</p>
    <div class="addto"><span class="note">Add to plan day:</span><select id="addDay" aria-label="Day to add exercises to">${dayOpts}</select></div>
    <div style="height:8px"></div>
    ${(rows.map(([e, i]) => `<div class="ex" id="ex-${S.wTab}-${i}"><div><div class="t">${e[0]}</div><div class="meta"><span class="sr">${e[1]}</span><span>Rest ${e[2]}</span><span>${e[3]}</span></div></div><button class="btn sm" data-act="addplan" data-k="${S.wTab}" data-i="${i}">+ Plan</button><p>${e[4]}</p></div>`).join('')) || '<p class="note" style="padding:10px 0">No workouts match your search.</p>'}`;
}

/* ---------- Diet ---------- */
function ensureEaten() { const k = iso(today0()); if (!S.eaten || S.eaten.day !== k) S.eaten = { day: k, loss: [], gain: [] }; }
function rDiet() {
  ensureEaten();
  $('#dTabs').innerHTML = ['loss', 'gain'].map(k => `<button class="chip" role="tab" aria-pressed="${S.dTab === k}" data-dtab="${k}">${DIET[k].label}</button>`).join('');
  const d = DIET[S.dTab], kc = d.meals.reduce((a, m) => a + m[3], 0), eaten = S.eaten[S.dTab];
  const done = d.meals.reduce((a, m, i) => a + (eaten.includes(i) ? m[3] : 0), 0);
  const pk = d.p * 4, ck = d.c * 4, fk = d.f * 9, tk = pk + ck + fk, pc = v => Math.round(v / tk * 100);
  $('#dBody').innerHTML = `
    <div class="cal"><div class="top2"><span class="note">Calorie goal</span><span class="num note">${done.toLocaleString('en-IN')} / ${kc.toLocaleString('en-IN')} kcal eaten today</span></div>
    <div class="top2"><b class="num">${kc.toLocaleString('en-IN')} kcal</b><span class="pill ok">${d.label}</span></div>
    <div class="bar" role="progressbar" aria-valuenow="${done}" aria-valuemin="0" aria-valuemax="${kc}"><i style="width:${Math.min(100, done / kc * 100)}%"></i></div>
    <div class="note">${d.why}</div></div>
    <div style="height:14px"></div>
    <div class="macros">
      <div><span class="mr">${ringSVG(pc(ck), 'var(--teal)', 34, 5)}</span><b class="num">${d.c} g</b><span>Carbs · ${pc(ck)}%</span></div>
      <div><span class="mr">${ringSVG(pc(pk), 'var(--coral)', 34, 5)}</span><b class="num">${d.p} g</b><span>Protein · ${pc(pk)}%</span></div>
      <div><span class="mr">${ringSVG(pc(fk), '#f0aa3c', 34, 5)}</span><b class="num">${d.f} g</b><span>Fat · ${pc(fk)}%</span></div>
      <div><span class="mr">${ringSVG(100, '#6ec5e9', 34, 5)}</span><b class="num">${d.water}</b><span>Water a day</span></div>
    </div>
    <div style="height:10px"></div><h3>Today's meals</h3><div class="note" style="margin-bottom:4px">Tick each meal as you eat it. Ticks reset every day.</div>
    ${d.meals.map((m, i) => `<div class="meal"><span class="tm">${m[0]}</span><div><b>${m[1]}</b><p>${m[2]}</p>${m[4] ? `<small>${m[4]}</small>` : ''}</div><span class="kc num">${m[3]} kcal</span><button class="chk" data-act="eat" data-i="${i}" aria-pressed="${eaten.includes(i)}" aria-label="Mark ${m[1]} as eaten">✓</button></div>`).join('')}
    <div style="height:12px"></div><h3 style="margin-bottom:8px">Rules that make it work</h3>
    <ul class="tips">${d.tips.map(t => `<li>${t}</li>`).join('')}</ul>`;
}

/* ---------- Weekly plan ---------- */
function rPlan() {
  $('#plName').value = S.plan.name; $('#plGoal').value = S.plan.goal; $('#plLevel').value = S.plan.level;
  $('#planGrid').innerHTML = S.plan.days.map((d, i) => `<div class="day"><div class="dn">${DAYS[i].slice(0, 3)}<small>${DAYS[i]}</small></div>
    <div style="display:grid;gap:8px;min-width:0"><div class="fld"><label class="f">Focus<input data-pd="${i}" data-pf="focus" value="${esc(d.focus)}" maxlength="50"></label><label class="f">Minutes<input type="number" min="0" max="240" data-pd="${i}" data-pf="min" value="${d.min}"></label></div>
    <label class="f">Exercises, one per line<textarea data-pd="${i}" data-pf="ex" rows="4">${esc(d.ex)}</textarea></label></div></div>`).join('');
}
function planText() {
  const p = S.plan;
  return ['VIJAY FITNESS CENTRE - Weekly Workout Plan', `Member: ${p.name || '-'}   Goal: ${p.goal}   Level: ${p.level}`, ''].concat(p.days.map((d, i) => `${DAYS[i]} - ${d.focus} (${d.min} min)\n${d.ex}\n`)).join('\n');
}
function makePDF() {
  const lib = window.jspdf;
  if (!lib) { toast('The PDF tool did not load. Check your internet connection.'); return; }
  const clean = s => String(s).replace(/[–—]/g, '-').replace(/[^\n\x20-\x7E\xA0-\xFF]/g, '');
  const doc = new lib.jsPDF({ unit: 'pt', format: 'a4' }), W = 595, H = 842, M = 36, p = S.plan;
  let page = 1;
  const footer = () => { doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(130); doc.text('Vijay Fitness Centre. Warm up for 10 minutes before every session and stop if something hurts.', M, H - 22); doc.text('Page ' + page, W - M, H - 22, { align: 'right' }); };
  doc.setFillColor(43, 156, 132); doc.rect(0, 0, W, 96, 'F'); doc.setFillColor(244, 120, 95); doc.rect(0, 96, W, 5, 'F');
  doc.setTextColor(255); doc.setFont('helvetica', 'bold'); doc.setFontSize(25); doc.text('VIJAY FITNESS CENTRE', M, 48);
  doc.setFontSize(11); doc.setTextColor(255, 255, 255); doc.text('WEEKLY WORKOUT PLAN', M, 70);
  doc.setTextColor(230, 250, 244); doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.text('Printed ' + fmtD(today0()), W - M, 70, { align: 'right' });
  const info3 = [['MEMBER', p.name || '-'], ['GOAL', p.goal], ['LEVEL', p.level]];
  info3.forEach((f, i) => { const xx = M + i * 180; doc.setFontSize(8); doc.setTextColor(130); doc.setFont('helvetica', 'bold'); doc.text(f[0], xx, 128); doc.setFontSize(13); doc.setTextColor(20); doc.text(clean(f[1]), xx, 145); });
  let y = 168;
  p.days.forEach((d, i) => {
    const lines = doc.splitTextToSize(clean(d.ex || '-'), W - 2 * M - 130), h = 34 + lines.length * 13 + 8;
    if (y + h > H - 44) { footer(); doc.addPage(); page++; y = 40; }
    doc.setDrawColor(215); doc.setLineWidth(.8); doc.roundedRect(M, y, W - 2 * M, h, 4, 4, 'S');
    doc.setFillColor(43, 156, 132); doc.rect(M, y, 6, h, 'F');
    doc.setFont('helvetica', 'bold'); doc.setFontSize(14); doc.setTextColor(29, 44, 41); doc.text(DAYS[i].toUpperCase(), M + 18, y + 22);
    doc.setFontSize(10); doc.setTextColor(31, 127, 107); doc.text(clean(d.focus).toUpperCase(), M + 130, y + 22);
    doc.setTextColor(110); doc.setFont('helvetica', 'normal'); doc.text(d.min + ' min', W - M - 12, y + 22, { align: 'right' });
    doc.setFontSize(10.5); doc.setTextColor(30); doc.text(lines, M + 130, y + 40);
    y += h + 10;
  });
  footer();
  try { doc.save('Vijay-Fitness-Weekly-Plan.pdf'); toast('PDF created. If no download starts, use Copy as text.'); } catch (e) { toast('Could not save the PDF here. Use Copy as text.'); }
}
function copyText(t) {
  const fallback = () => { const ta = document.createElement('textarea'); ta.value = t; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.select(); let ok = false; try { ok = document.execCommand('copy'); } catch (e) { } ta.remove(); toast(ok ? 'Plan copied' : 'Select the text in the plan and copy it'); };
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(() => toast('Plan copied'), fallback); else fallback();
}

/* ---------- Exploded menu ---------- */
const FX = ['-140px', '0px', '140px', '-140px', '0px', '140px'], FY = ['-90px', '-140px', '-90px', '90px', '140px', '90px'], RY = ['-30deg', '0deg', '30deg', '-30deg', '0deg', '30deg'];
function rExplode() {
  const labels = [['Home', 'Welcome and 3D trainer'], ['Dashboard', 'Profit and history'], ['Dues', 'Members and reminders'], ['Workouts', 'Six programmes'], ['Diet', 'Meals and weekly plan']];
  $('#exnav').innerHTML = labels.map((l, i) => `<button data-go="${i}">${l[0]}<small>${l[1]}</small></button>`).join('');
  $('#exgrid').innerHTML = WK_ORDER.map((k, n) => `<div class="excard" style="--i:${n};--fx:${FX[n]};--fy:${FY[n]};--ry:${RY[n]}"><h3>${WK[k].label}<small>${WK[k].items.length} exercises</small></h3><ul>${WK[k].items.map((e, i) => `<li><button data-jump="${k}:${i}">${e[0]}<span>${e[1]}</span></button></li>`).join('')}</ul></div>`).join('');
}
let menuOpen = false, menuT = 0;
function openMenu() {
  if (menuOpen) return; menuOpen = true; clearTimeout(menuT);
  const ex = $('#explode'); ex.hidden = false; ex.scrollTop = 0;
  $('#menuBtn').setAttribute('aria-expanded', 'true');
  requestAnimationFrame(() => requestAnimationFrame(() => ex.classList.add('open')));
}
function closeMenu() {
  if (!menuOpen) return; menuOpen = false;
  const ex = $('#explode'); ex.classList.remove('open'); $('#menuBtn').setAttribute('aria-expanded', 'false');
  menuT = setTimeout(() => { ex.hidden = true; }, reduceMotion ? 0 : 450);
}
function jumpTo(k, i) {
  S.wTab = k; save(); rWork(); closeMenu(); goPage(3);
  setTimeout(() => { const el = $('#ex-' + k + '-' + i); if (el) { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 1800); } }, 500);
}

/* ---------- Events ---------- */
document.addEventListener('click', e => {
  const t = e.target.closest('[data-go],[data-act],[data-range],[data-filter],[data-wtab],[data-dtab],[data-jump],[data-ex]');
  if (!t) return;
  if (t.dataset.go != null) { closeMenu(); goPage(+t.dataset.go); return; }
  if (t.dataset.range) { S.range = +t.dataset.range; save(); rDash(); return; }
  if (t.dataset.filter) { S.filter = t.dataset.filter; save(); rMembers(); return; }
  if (t.dataset.wtab) { S.wTab = t.dataset.wtab; save(); rWork(); return; }
  if (t.dataset.dtab) { S.dTab = t.dataset.dtab; save(); rDiet(); return; }
  if (t.dataset.jump) { const [k, i] = t.dataset.jump.split(':'); jumpTo(k, +i); return; }
  const a = t.dataset.act;
  if (a === 'pay') {
    const m = S.members.find(x => x.id === t.dataset.id); if (!m) return;
    const i = info(m);
    m.paidOn = i.days <= 0 ? iso(today0()) : iso(i.due);
    S.pay.push({ id: 'p' + Date.now(), mid: m.id, date: iso(today0()), amt: i.p.price, plan: i.p.name });
    save(); rMembers(); rDash(); rHome(); toast('Payment of ' + money(i.p.price) + ' recorded for ' + m.name);
  } else if (a === 'rm') {
    if (t.dataset.arm) { S.members = S.members.filter(x => x.id !== t.dataset.id); save(); rMembers(); rDash(); rHome(); toast('Member removed'); }
    else { t.dataset.arm = '1'; t.textContent = 'Confirm?'; t.classList.add('danger'); setTimeout(() => { if (t.isConnected) { delete t.dataset.arm; t.textContent = 'Remove'; t.classList.remove('danger'); } }, 3000); }
  } else if (a === 'eat') {
    ensureEaten(); const arr = S.eaten[S.dTab], i = +t.dataset.i, at = arr.indexOf(i);
    if (at < 0) arr.push(i); else arr.splice(at, 1);
    save(); rDiet();
  } else if (a === 'addplan') {
    const ex = WK[t.dataset.k].items[+t.dataset.i], day = S.plan.days[S.addDay];
    day.ex = (day.ex ? day.ex.replace(/\s+$/, '') + '\n' : '') + ex[0] + ' ' + ex[1];
    save(); rPlan(); toast(ex[0] + ' added to ' + DAYS[S.addDay]);
  }
});
$('#menuBtn').addEventListener('click', () => menuOpen ? closeMenu() : openMenu());
$('#exClose').addEventListener('click', closeMenu);
$('#bellBtn').addEventListener('click', () => { goPage(2); setTimeout(() => $('#remPanel').scrollIntoView({ behavior: 'smooth', block: 'start' }), 450); });
$('#scanNow').addEventListener('click', () => scan(true));
$('#search').addEventListener('input', rMembers);
$('#wSearch').addEventListener('input', rWork);
$('#addForm').addEventListener('submit', e => {
  e.preventDefault();
  const name = $('#nName').value.trim(); if (!name) return;
  const plan = PLANS.find(p => p.id === $('#nPlan').value) || PLANS[0], id = 'm' + Date.now(), t = iso(today0());
  S.members.push({ id, name, phone: $('#nPhone').value.replace(/\D/g, ''), plan: plan.id, paidOn: t, joined: t });
  S.pay.push({ id: 'p' + Date.now(), mid: id, date: t, amt: plan.price, plan: plan.name });
  save(); e.target.reset(); rMembers(); rDash(); rHome(); toast(name + ' added. ' + money(plan.price) + ' recorded.');
});
document.addEventListener('change', e => {
  const t = e.target;
  if (t.id === 'rBefore') S.rem.before = t.checked; else if (t.id === 'rOn') S.rem.onDue = t.checked; else if (t.id === 'rOver') S.rem.overdue = t.checked;
  else if (t.id === 'rBeforeN') S.rem.beforeDays = Math.max(1, Math.min(14, +t.value || 3));
  else if (t.id === 'rRepN') S.rem.repeat = Math.max(1, Math.min(14, +t.value || 3));
  else if (t.id === 'addDay') { S.addDay = +t.value; }
  else if (t.dataset.h) {
    const v = Math.max(0, +t.value || 0);
    if (t.dataset.h === 'cur') S.curExp = v; else S.hist[t.dataset.h][t.dataset.f] = v;
    save(); rDash(); rHome(); return;
  } else return;
  save(); if (t.id.startsWith('r')) scan(false);
});
$('#tpl').addEventListener('input', e => { S.rem.tpl = e.target.value; save(); });
$('#tpl').addEventListener('change', () => { S.log = []; S.sent = {}; scan(false); rMembers(); });
document.addEventListener('input', e => {
  const t = e.target;
  if (t.dataset.pd != null) { const d = S.plan.days[+t.dataset.pd]; d[t.dataset.pf] = t.dataset.pf === 'min' ? (+t.value || 0) : t.value; save(); }
  else if (t.id === 'plName') { S.plan.name = t.value; save(); }
  else if (t.id === 'plGoal') { S.plan.goal = t.value; save(); }
  else if (t.id === 'plLevel') { S.plan.level = t.value; save(); }
});
$('#pdfBtn').addEventListener('click', makePDF);
$('#copyBtn').addEventListener('click', () => copyText(planText()));
$('#resetPlan').addEventListener('click', () => { S.plan.days = JSON.parse(JSON.stringify(DEFAULT_PLAN)); save(); rPlan(); toast('Plan reset to the default week'); });
let resetArm = 0;
$('#resetAll').addEventListener('click', e => {
  if (!resetArm) { resetArm = 1; e.target.textContent = 'Tap again to erase everything'; e.target.classList.add('danger'); setTimeout(() => { resetArm = 0; e.target.textContent = 'Reset all app data'; e.target.classList.remove('danger'); }, 3500); return; }
  try { localStorage.removeItem(KEY); } catch (er) { }
  S = seedState(); resetArm = 0; e.target.textContent = 'Reset all app data'; e.target.classList.remove('danger'); renderAll(); toast('App data reset to the sample set');
});
/* card tilt */
document.addEventListener('pointermove', e => {
  if (reduceMotion || e.pointerType === 'touch') return;
  const c = e.target.closest && e.target.closest('.tilt');
  $$('.tilt').forEach(x => { if (x !== c && x.style.transform) x.style.transform = ''; });
  if (!c) return;
  const r = c.getBoundingClientRect(), px = (e.clientX - r.left) / r.width - .5, py = (e.clientY - r.top) / r.height - .5;
  c.style.transform = `perspective(700px) rotateX(${(-py * 9).toFixed(1)}deg) rotateY(${(px * 9).toFixed(1)}deg) translateZ(6px)`;
});

/* ---------- Boot ---------- */
function renderAll() {
  $('#nPlan').innerHTML = PLANS.map(p => `<option value="${p.id}">${p.name} · ${money(p.price)}</option>`).join('');
  rRules(); scan(false); rHome(); rDash(); rMembers(); rWork(); rDiet(); rPlan(); rExplode();
}
renderAll();
updateTabs();
setInterval(() => scan(false), 60000);
