@echo off
rem Quick start with no install. Opens the app in your default browser.
start "" "%~dp0src\index.html"
