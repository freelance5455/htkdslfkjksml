VIJAY FITNESS CENTRE - Windows desktop software
===============================================

OPTION 1 - Make the Windows installer (recommended)
  1. Install Node.js (LTS) from https://nodejs.org (one time).
  2. Double-click  build-windows.bat  (internet needed).
  3. When it finishes, open the "dist" folder:
       Vijay Fitness Centre Setup 1.0.0.exe   -> installs the program with a desktop shortcut
       Vijay Fitness Centre 1.0.0.exe          -> portable version, runs from a USB stick
  The installed program works offline.

OPTION 2 - Run it without building
  Double-click  run-app.bat  (needs Node.js, installs once, then opens the program window).

OPTION 3 - No install at all
  Double-click  open-in-browser.bat  (opens in your browser; needs internet for fonts and PDF).

Using the program
  - Press F11 for full screen.
  - Your members, payments and plan edits are saved on this computer.
  - Reminders: the program checks every minute while it is open and shows a Windows
    notification when new fee reminders are ready. Tap "Open in WhatsApp" on a reminder to send it.
  - Download PDF on the Diet page saves the weekly workout plan.
  - Members, phone numbers and figures shown at first are SAMPLE data. Replace them with your own,
    or tap "Reset all app data" at the bottom of the Diet page to return to the sample set.

Files
  main.js            program window (Electron)
  src/index.html     the whole app (HTML, CSS, JavaScript)
  app-parts/         the same code split into styles, markup, data and logic
  build/icon.png     program icon
  scripts/           copies fonts and the PDF tool for offline use
