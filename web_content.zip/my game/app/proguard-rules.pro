# Glitch Arcade does not require custom ProGuard rules.
