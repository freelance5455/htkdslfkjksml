# Glitch Arcade — Android Project

This project wraps the supplied **Glitch Arcade** HTML game in a native Android WebView.

## App details

- App name: **Glitch Arcade**
- Application ID: `com.glitcharcade.game`
- Orientation: portrait
- Runtime network access: **none** — the manifest intentionally declares no `INTERNET` permission
- Game source: `app/src/main/assets/game.html`
- Native entry point: `app/src/main/java/com/glitcharcade/game/MainActivity.java`
- Launcher icon: vector/adaptive Android resources

## Preserved game features

The supplied game remains a local HTML/Canvas game. Its two games, animations, sounds, scoring, localStorage best scores, touch/pointer controls, keyboard/Space controls, menus, overlays, and game-over screens are retained.

The only game-source compatibility addition is `window.goToMenuFromAndroid()`. Android calls this when Back is pressed. While inside a game it returns to the existing HTML menu; while already on the menu it allows Android to close the app.

## Offline behavior

The app loads only:

`file:///android_asset/game.html`

There are no network requests, server endpoints, APIs, accounts, or login flow. The Android manifest contains no Internet permission.

## Build with Android Studio

1. Open this folder as an existing Gradle project.
2. Allow Android Studio/Gradle to download the Android Gradle Plugin and Gradle distribution if they are not already cached.
3. Select **Build > Build APK(s)**.
4. For a debug APK, the output is:

   `app/build/outputs/apk/debug/app-debug.apk`

5. For a release APK, use **Build > Generate Signed App Bundle / APK > APK**. The output is normally under:

   `app/build/outputs/apk/release/`

## Build directly from an Android phone

A phone-only option is an Android IDE such as **AndroidIDE** (if available for your Android version). Install the IDE from its official/current distribution, import this project folder, let it install/download the required Gradle/SDK components, then run the project's Gradle build or APK build action.

For a phone-only workflow:

1. Extract the `GlitchArcade-Android-Project.zip` file.
2. Open/import the extracted `GlitchArcade` folder in the Android IDE.
3. Wait for Gradle sync to finish. The first sync may require Internet access to download build tools; that is build-time only.
4. Run the debug APK build.
5. Install the generated `app-debug.apk` on the phone.

After the APK is installed, **the game itself does not require Internet**.

## Important build note

This environment does not have a usable Android SDK/Gradle installation, so an APK was **not** falsely claimed or fabricated here. The project is supplied as source and is intended to be compiled by Android Studio or a compatible Android IDE.
