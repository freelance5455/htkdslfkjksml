# Cayo Verde — source (HEAD 73be944, after R4)

Game GTA 6 untuk make.fun gta6-01. Repo git lengkap (termasuk .git).

## Cara jalanin
```
cd game
python3 -m http.server 8123
```
Buka http://localhost:8123 — main.js, three.js sudah di-vendor di game/vendor/.

## File yang relevan buat revisi bundaran
- `game/src/roads.js` — semua geometri jalan: ribbon aspal, zebra, trotoar
  (termasuk 4 arc trotoar bundaran 14–17 m), curb, tiang lampu lalu lintas.
- `game/src/npcs.js` — graph pejalan kaki; 16 ring node bundaran HARUS cocok
  persis dengan geometri arc di roads.js (x = r*sin, z = r*cos, radius 15.5 m,
  berhenti ~36 derajat sebelum tiap lengan). Kalau arc berubah, ring node harus
  ikut berubah supaya NPC tetap di trotoar.
- `game/src/layout.js` — data graph jalan (NODES 28, EDGES 43, CROSSINGS 82,
  SIDEWALKS 84), ROUNDABOUT = { x: 0, z: 0, radius: 14 }.

## 4 revisi bundaran (dari Farhan, 2026-11-19)
1. Hapus potongan trotoar baji/segitiga di mulut bundaran; ganti trotoar yang
   mengikuti lengkungan tepi bundaran dan menyambung mulus ke trotoar jalan masuk.
2. Trotoar menerus di kedua sisi semua jalan sampai ke bundaran; jangan ada
   rumput yang langsung nempel ke aspal.
3. Tambah curb (tinggi 0.15) mengelilingi pulau tengah (r6) dan tepi luar
   lingkar bundaran (r14).
4. Tiang lampu lalu lintas pindah ke trotoar di dekat zebra cross; NPC berjalan
   di trotoar dan menyeberang lewat zebra, bukan di rumput.

## Catatan
- Y layers: aspal 0.70, patch persimpangan 0.725, ring bundaran 0.738,
  marking 0.74, zebra 0.76, trotoar atas 0.805.
- Zebra bundaran di 16 m dari pusat, di 4 lengan (0,-16), (-16,0), (0,16), (16,0).
- Kalau sudah diperbaiki, kirim file roads.js + npcs.js (dan layout.js kalau
  ikut berubah) balik ke emon — emon akan masukkan lewat sesi agen yang
  terekam supaya authorship entry tetap bersih.
