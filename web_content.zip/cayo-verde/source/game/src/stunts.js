// stunts.js — revision 3 stunt jumps. Four wedge ramps (places.js RAMPS)
// with chevrons and a glowing lip. Hit one fast in a car: slow-motion
// while airborne, then a payout on landing — the first jump off each
// ramp is a UNIQUE STUNT JUMP ($500 + 60 respect), repeats pay $50 + a
// bonus for distance. Found ramps are saved (state.stunts).

import * as THREE from 'three';
import { RAMPS } from './places.js';
import { groundHeightAt } from './player.js';

export function createStunts(scene, { state, player, ui }) {
  if (!Array.isArray(state.stunts)) state.stunts = [];
  const stripe = new THREE.MeshStandardMaterial({ color: 0xffc12e, flatShading: true, roughness: 0.6 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x2a2630, flatShading: true, roughness: 0.8 });
  const lipMat = new THREE.MeshStandardMaterial({ color: 0xff3b8a, emissive: 0xff3b8a, emissiveIntensity: 1.4 });

  for (const r of RAMPS) {
    const g = new THREE.Group();
    // Wedge: triangle profile (len x h) extruded across w.
    const shape = new THREE.Shape();
    shape.moveTo(-r.len / 2, 0);
    shape.lineTo(r.len / 2, 0);
    shape.lineTo(r.len / 2, r.h);
    shape.closePath();
    const geo = new THREE.ExtrudeGeometry(shape, { depth: r.w, bevelEnabled: false });
    geo.translate(0, 0, -r.w / 2);
    geo.rotateY(-Math.PI / 2); // profile axis -> +z (along heading)
    const wedge = new THREE.Mesh(geo, dark);
    wedge.castShadow = true;
    wedge.receiveShadow = true;
    g.add(wedge);
    // Chevrons on the slope.
    const ang = Math.atan2(r.h, r.len);
    for (let k = 0; k < 3; k++) {
      const t = (k + 0.6) / 3.6;
      const c = new THREE.Mesh(new THREE.BoxGeometry(r.w * 0.8, 0.03, 0.35), stripe);
      c.position.set(0, t * r.h + 0.03, -r.len / 2 + t * r.len);
      c.rotation.x = -ang;
      g.add(c);
    }
    const lip = new THREE.Mesh(new THREE.BoxGeometry(r.w, 0.12, 0.15), lipMat);
    lip.position.set(0, r.h + 0.02, r.len / 2 - 0.05);
    g.add(lip);
    g.position.set(r.x, groundHeightAt(r.x, r.z) - 0.02, r.z);
    g.rotation.y = r.heading;
    scene.add(g);
  }

  let slowT = 0;
  player.onStunt = (ev, d) => {
    if (ev === 'takeoff') {
      slowT = 1.8;
      state.emit('stuntTakeoff', d);
      return;
    }
    slowT = 0;
    if (!d.ramp || d.dist < 6) return;
    const first = !state.stunts.includes(d.ramp.id);
    if (first) {
      state.stunts.push(d.ramp.id);
      state.addMoney(500);
      state.addXP(60, 'stunt');
      ui.big('UNIQUE STUNT JUMP', `${d.ramp.name} · ${d.dist.toFixed(1)} m · $500 · ${state.stunts.length}/${RAMPS.length} found`, '#ff7ad9', 3.5);
    } else {
      const pay = 50 + Math.round(d.dist * 3);
      state.addMoney(pay);
      state.addXP(10, 'stunt');
      ui.notify(`STUNT JUMP · ${d.dist.toFixed(1)} m · ${d.air.toFixed(1)} s air · +$${pay}`, 'good', 3, true);
    }
    state.emit('stunt', { first, dist: d.dist, air: d.air });
  };

  return {
    update(dt) { slowT = Math.max(0, slowT - dt); },
    // Global time scale for the main loop (slow-mo while flying).
    get timeScale() { return slowT > 0 && player.airborne ? 0.4 : 1; },
    ramps: RAMPS,
  };
}
