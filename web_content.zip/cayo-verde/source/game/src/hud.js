// hud.js — revision 2 HUD (DOM over the canvas, no images).
//  top-left     mission card: JOB n/N + title + contact, objective, green
//               progress line, stage bar (STAGE i/n), NEXT line, timer
//  left-middle  CVPD RESPONSE panel while wanted: callsigns, distance,
//               live status pills (PURSUIT / SEARCHING / RAMMING / ...)
//  top-centre   big "WANTED ★★★" banner when the level rises, radio card
//  top-right    clock + weather, money ($41,900), stars, IN SIGHT /
//               SEARCHING tag, weapon slots 1-5 (ammo / price / LOCKED),
//               current weapon line
//  right-middle notifications (VEHICLE STOLEN, witnesses, pickups ...)
//  bottom-left  under the minimap: district + street, health / armour,
//               respect rank badge + XP bar
//  bottom-centre dialogue box with a pixel portrait of the contact
//  bottom-right radio now-playing + vehicle panel (name, condition, km/h,
//               gear) while in a vehicle
//  overlays     BUSTED / WASTED / MISSION PASSED / RANK UP, shop and
//               Rico's Paint & Tune screens, crosshair, "Press E" prompt
// Icons are inline SVG / CSS; portraits are drawn on small canvases.

import { MAX_WANTED } from './state.js';
import { clockText } from './daynight.js';
import { WEAPONS, WEAPON, rankOf } from './weapons.js';

const CSS = `
#hud { position: fixed; inset: 0; pointer-events: none; z-index: 25; color: #fff; user-select: none;
  font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif; }
#hud .panel { background: rgba(20,18,30,0.82); border-radius: 10px; box-shadow: 0 4px 18px rgba(0,0,0,0.35); }
#hud .num { font-family: Impact, "Arial Black", "Segoe UI", Arial, sans-serif; }

/* mission card */
#hud .card { position: absolute; left: 18px; top: 16px; width: 360px; padding: 12px 16px 12px 18px;
  border-left: 5px solid #ffc12e; }
#hud .card .row1 { display: flex; align-items: center; gap: 8px; font-weight: 800; font-size: 13px; letter-spacing: 0.5px; }
#hud .card .job { background: #ffc12e; color: #1a1420; padding: 2px 7px; border-radius: 4px; font-size: 12px; }
#hud .card .ttl { color: #ffc12e; text-transform: uppercase; flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
#hud .card .ttl i { color: #ffe39a; font-style: normal; font-weight: 600; text-transform: none; }
#hud .card .tmr { border: 1px solid rgba(255,255,255,0.45); border-radius: 5px; padding: 1px 7px; font-size: 13px; }
#hud .card .tmr.low { color: #ff6b5a; border-color: #ff6b5a; }
#hud .card .obj { font-size: 19px; font-weight: 800; margin-top: 6px; line-height: 1.2; }
#hud .card .sub { font-size: 13px; color: #4be3a0; font-weight: 700; margin-top: 3px; min-height: 2px; }
#hud .card .stage { display: flex; align-items: center; gap: 6px; margin-top: 8px; font-size: 11px;
  font-weight: 800; letter-spacing: 1px; color: #c9c3d6; }
#hud .card .bars { display: flex; gap: 4px; flex: 1; }
#hud .card .bars i { flex: 1; height: 5px; border-radius: 3px; background: rgba(255,255,255,0.18); }
#hud .card .bars i.on { background: linear-gradient(90deg, #ffc12e, #ff8f3a); }
#hud .card .bars i.cur { background: linear-gradient(90deg, #ff8f3a, rgba(255,143,58,0.35)); }
#hud .card .next { font-size: 12px; margin-top: 6px; color: #d9d3e6; }
#hud .card .next b { font-size: 11px; letter-spacing: 1px; margin-right: 8px; color: #fff; }
#hud .card.idle .obj { font-size: 17px; }
#hud .card .dist { float: right; font-size: 12px; color: #c9c3d6; font-weight: 700; }

/* police response */
#hud .cvpd { position: absolute; left: 18px; top: 200px; width: 330px; padding: 10px 14px;
  border-top: 3px solid #3a7bff; display: none; }
#hud .cvpd .hd { display: flex; align-items: center; font-weight: 800; font-size: 13px; letter-spacing: 1px; }
#hud .cvpd .hd .dots i { display: inline-block; width: 7px; height: 7px; border-radius: 50%; margin-right: 3px; }
#hud .cvpd .hd .dots i:first-child { background: #ff3b3b; }
#hud .cvpd .hd .dots i:last-child { background: #3a7bff; }
#hud .cvpd .hd .code { margin-left: auto; font-size: 11px; color: #c9c3d6; }
#hud .cvpd .u { display: flex; align-items: center; gap: 8px; font-size: 12px; font-weight: 700; margin-top: 6px; }
#hud .cvpd .u .ic { width: 12px; color: #8fb3ff; text-align: center; }
#hud .cvpd .u .cs { flex: 1; letter-spacing: 0.5px; }
#hud .cvpd .u .d { width: 44px; text-align: right; color: #c9c3d6; }
#hud .cvpd .u .st { width: 92px; text-align: center; border-radius: 4px; font-size: 11px; padding: 2px 0; }
#hud .cvpd .ft { font-size: 11px; color: #a9a3b6; margin-top: 7px; }
.st-PURSUIT { background: #ff8a1e; color: #1a1420; } .st-SEARCHING { background: #4a4560; }
.st-RAMMING, .st-FIRING { background: #ff3b4e; } .st-SPOTLIGHT { background: #3a7bff; }
.st-ROADBLOCK { background: #ffd21a; color: #1a1420; } .st-ARRESTING { background: #b04bff; }
.st-DEPLOYED { background: #2f8f6a; } .st-CLEAR, .st-DOWN, .st-WRECKED, .st-BURNING { background: #333; color: #aaa; }

/* right column */
#hud .rc { position: absolute; right: 18px; top: 12px; display: flex; flex-direction: column; align-items: flex-end; gap: 3px; }
#hud .clock { font-weight: 800; font-size: 15px; text-shadow: 1px 1px 2px #000; }
#hud .clock small { font-size: 10px; letter-spacing: 2px; margin-left: 6px; opacity: 0.85; }
#hud .money { font-size: 46px; line-height: 1; color: #5dff8f; letter-spacing: 0.5px;
  -webkit-text-stroke: 2px #0b3a1c; text-shadow: 0 3px 0 #0b3a1c, 0 0 18px rgba(93,255,143,0.35); }
#hud .money.flash { color: #fff27d; }
#hud .stars { display: flex; gap: 3px; }
#hud .stars svg { width: 30px; height: 30px; filter: drop-shadow(0 2px 0 rgba(0,0,0,0.6)); }
#hud .stars.blink svg.on { animation: hudblink 0.5s steps(2) infinite; }
@keyframes hudblink { 50% { opacity: 0.25; } }
#hud .sight { display: flex; align-items: center; gap: 8px; font-size: 11px; min-height: 18px; }
#hud .sight b { padding: 2px 8px; border-radius: 4px; font-size: 11px; letter-spacing: 1px; }
#hud .sight b.in { background: #e8263a; } #hud .sight b.out { background: #3a4a8a; }
#hud .sight span { opacity: 0.8; text-shadow: 1px 1px 2px #000; }
#hud .slots { display: flex; gap: 5px; margin-top: 4px; }
#hud .slot { width: 74px; height: 46px; border-radius: 7px; background: rgba(20,18,30,0.82);
  border: 2px solid rgba(255,255,255,0.12); padding: 3px 5px; box-sizing: border-box; position: relative; }
#hud .slot .k { font-size: 9px; color: #a9a3b6; }
#hud .slot .n { font-size: 10px; letter-spacing: -0.2px; font-weight: 800; text-align: center; margin-top: -2px; white-space: nowrap; overflow: hidden; }
#hud .slot .a { font-size: 11px; text-align: center; font-weight: 700; color: #ffd27a; }
#hud .slot.sel { background: #d6365f; border-color: #ffc12e; }
#hud .slot.sel .a { color: #fff; }
#hud .slot.lock { opacity: 0.55; }
#hud .slot.lock .a { color: #ff8f8f; font-size: 9px; letter-spacing: 1px; }
#hud .wname { font-size: 12px; font-weight: 800; letter-spacing: 1px; color: #ffc12e; text-shadow: 1px 1px 2px #000; }
#hud .wname small { color: #fff; margin-left: 6px; }

/* notifications */
#hud .notes { position: absolute; right: 18px; top: 240px; display: flex; flex-direction: column;
  align-items: flex-end; gap: 6px; max-width: 380px; }
#hud .note { background: rgba(14,12,22,0.86); padding: 7px 12px; font-size: 14px; font-weight: 700;
  border-radius: 5px; transition: opacity 0.4s, transform 0.3s; border-right: 4px solid #6cb8ff; }
#hud .note.good { border-color: #4be3a0; } #hud .note.money { border-color: #5dff8f; color: #b9ffc8; }
#hud .note.crime { border-color: #ff3b4e; } #hud .note.warn { border-color: #ffb02e; }
#hud .note.big { font-size: 17px; letter-spacing: 0.5px; }

/* bottom-left status block */
#hud .bl { position: absolute; left: 18px; bottom: 14px; width: 214px; }
#hud .loc { padding: 5px 10px; border-radius: 6px; display: flex; align-items: baseline; gap: 8px; overflow: hidden; }
#hud .loc .dn { font-family: "Brush Script MT", "Segoe Script", "Lucida Handwriting", cursive; font-size: 20px;
  color: #ffc77a; white-space: nowrap; }
#hud .loc .sn { font-size: 11px; color: #ddd; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
#hud .hpar { display: flex; gap: 5px; margin-top: 6px; }
#hud .bar { height: 10px; background: rgba(0,0,0,0.6); border-radius: 3px; overflow: hidden;
  border: 1px solid rgba(255,255,255,0.15); }
#hud .bar i { display: block; height: 100%; transition: width 0.2s; }
#hud .bar.hp { flex: 1.6; } #hud .bar.hp i { background: linear-gradient(#5dff8f, #24b45a); }
#hud .bar.hp.low i { background: linear-gradient(#ff6b5a, #b8261a); }
#hud .bar.ar { flex: 1; } #hud .bar.ar i { background: linear-gradient(#7fb8ff, #3a6fd0); }
#hud .resp { display: flex; align-items: center; gap: 8px; margin-top: 6px; padding: 5px 10px 6px 6px; border-radius: 8px; }
#hud .resp .lv { width: 26px; height: 26px; border-radius: 50%; background: #ffc12e; color: #1a1420;
  display: flex; align-items: center; justify-content: center; font-weight: 900; font-size: 14px; }
#hud .resp .rt { flex: 1; }
#hud .resp .rn { font-size: 10px; font-weight: 800; letter-spacing: 1px; color: #ffc12e; display: flex; }
#hud .resp .rn span { margin-left: auto; color: #c9c3d6; letter-spacing: 0; }
#hud .resp .xb { height: 5px; background: rgba(255,255,255,0.15); border-radius: 3px; margin-top: 3px; overflow: hidden; }
#hud .resp .xb i { display: block; height: 100%; background: linear-gradient(90deg, #ffc12e, #ff8f3a); }

/* dialogue */
#hud .dlg { position: absolute; left: 50%; bottom: 16px; transform: translateX(-50%) translateY(20px); width: 460px;
  display: flex; gap: 12px; padding: 10px 14px 10px 10px; border-left: 4px solid #5ac8fa; opacity: 0;
  transition: opacity 0.3s, transform 0.3s; }
#hud .dlg.show { opacity: 1; transform: translateX(-50%) translateY(0); }
#hud .dlg canvas { width: 76px; height: 76px; border-radius: 6px; image-rendering: pixelated; flex: none;
  border: 2px solid rgba(255,255,255,0.25); }
#hud .dlg .who { font-weight: 900; font-size: 16px; }
#hud .dlg .who small { font-size: 10px; letter-spacing: 1px; color: #a9a3b6; margin-left: 6px; font-weight: 800; }
#hud .dlg .txt { font-size: 14.5px; font-weight: 600; line-height: 1.35; margin-top: 3px; }

/* bottom-right */
#hud .br { position: absolute; right: 18px; bottom: 16px; width: 232px; display: flex; flex-direction: column; gap: 6px; }
#hud .radio { padding: 7px 12px; border-left: 4px solid #ff7ad9; display: none; }
#hud .radio .st { font-weight: 900; font-size: 15px; color: #ff9ae3; }
#hud .radio .sg { font-size: 11px; color: #ddd; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
#hud .veh { padding: 9px 14px 8px; border-left: 4px solid #ffc12e; display: none; }
#hud .veh .vn { font-weight: 900; font-size: 15px; color: #ffc12e; text-transform: uppercase; }
#hud .veh .cond { display: flex; align-items: center; gap: 8px; font-size: 10px; font-weight: 800; letter-spacing: 1px;
  color: #c9c3d6; margin-top: 4px; }
#hud .veh .cond .bar { flex: 1; height: 7px; }
#hud .veh .cond .bar i { background: linear-gradient(90deg, #24b45a, #5dff8f); }
#hud .veh .cond .bar.mid i { background: linear-gradient(90deg, #d68a1a, #ffc12e); }
#hud .veh .cond .bar.bad i { background: linear-gradient(90deg, #b8261a, #ff6b5a); }
#hud .veh .spd { display: flex; align-items: flex-end; gap: 4px; }
#hud .veh .spd b { font-size: 52px; line-height: 0.95; font-weight: normal; }
#hud .veh .spd span { font-size: 15px; margin-bottom: 6px; font-weight: 800; }
#hud .veh .gear { margin-left: auto; margin-bottom: 6px; background: #ffc12e; color: #1a1420; font-weight: 900;
  font-size: 15px; padding: 2px 8px; border-radius: 5px; }
#hud .veh .nos .bar i { background: linear-gradient(90deg, #2ee6ff, #b45cff) !important; }
#hud .veh .nos.on span { color: #2ee6ff; }
#hud .walk { text-align: right; font-size: 13px; font-weight: 800; text-shadow: 1px 1px 2px #000; opacity: 0.85; }

/* big centre texts */
#hud .big { position: absolute; left: 0; right: 0; top: 36%; text-align: center; opacity: 0; transition: opacity 0.35s; }
#hud .big .h { font-family: Impact, "Arial Black", sans-serif; font-size: 96px; letter-spacing: 3px;
  -webkit-text-stroke: 3px #1a1420; text-shadow: 5px 5px 0 rgba(0,0,0,0.6); }
#hud .big .s { font-size: 24px; margin-top: 4px; font-weight: 800; text-shadow: 2px 2px 0 #000; }
#hud .big.show { opacity: 1; }
#hud .wanted { position: absolute; left: 0; right: 0; top: 70px; text-align: center; opacity: 0; transition: opacity 0.3s;
  font-family: Impact, "Arial Black", sans-serif; font-size: 44px; color: #ffc12e; letter-spacing: 3px;
  -webkit-text-stroke: 2px #3a1a00; text-shadow: 3px 3px 0 rgba(0,0,0,0.5); }
#hud .wanted.show { opacity: 1; }
#hud .rcard { position: absolute; left: 50%; top: 18px; transform: translateX(-50%); text-align: center; opacity: 0;
  transition: opacity 0.4s; text-shadow: 2px 2px 0 #000; }
#hud .rcard.show { opacity: 1; }
#hud .rcard b { display: block; font-size: 28px; color: #ff9ae3; font-family: Impact, "Arial Black", sans-serif; letter-spacing: 1px; }
#hud .rcard span { font-size: 13px; letter-spacing: 1px; }

#hud .prompt { position: absolute; left: 50%; bottom: 120px; transform: translateX(-50%); background: rgba(14,12,22,0.86);
  padding: 8px 16px; border-radius: 6px; font-size: 15px; font-weight: 700; display: none; }
#hud .prompt kbd { display: inline-block; background: #ffc12e; color: #1a1420; border-radius: 4px; padding: 0 7px;
  margin: 0 3px; font-family: inherit; font-weight: 900; }
#hud .xhair { position: absolute; width: 26px; height: 26px; margin: -13px 0 0 -13px; display: none;
  border: 2px solid rgba(255,255,255,0.9); border-radius: 50%; box-shadow: 0 0 3px rgba(0,0,0,0.6); }
#hud .xhair::after { content: ''; position: absolute; left: 10px; top: 10px; width: 2px; height: 2px; background: #fff; border-radius: 50%; }
#hud .xhair.hit { border-color: #ff3b4e; }
#hud .vignette { position: absolute; inset: 0; box-shadow: inset 0 0 160px rgba(220,0,0,0.75); opacity: 0; transition: opacity 0.25s; }
#hud .keys { position: absolute; left: 50%; top: 50%; transform: translate(-50%,-50%); padding: 18px 24px; display: none;
  font-size: 14px; line-height: 1.7; min-width: 420px; }
#hud .keys.show { display: block; }
#hud .keys h3 { margin: 0 0 8px; color: #ffc12e; letter-spacing: 1px; }
#hud .keys kbd { display: inline-block; min-width: 18px; text-align: center; background: rgba(255,255,255,0.15);
  border-radius: 4px; padding: 0 6px; margin-right: 8px; font-family: inherit; font-weight: 800; }
#hud .hint { position: absolute; left: 50%; top: 10px; transform: translateX(-50%); font-size: 11px; opacity: 0.7;
  text-shadow: 1px 1px 2px #000; }

/* shops + garage */
.mshop { position: fixed; inset: 0; z-index: 40; display: none; align-items: center; justify-content: flex-end;
  padding-right: 6vw; background: linear-gradient(90deg, rgba(0,0,0,0) 30%, rgba(0,0,0,0.55));
  font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif; color: #fff; pointer-events: auto; }
.mshop .pn { width: 460px; background: rgba(20,18,30,0.94); border-radius: 10px; overflow: hidden;
  box-shadow: 0 10px 50px rgba(0,0,0,0.7); border-left: 6px solid var(--c); }
.mshop .hd { padding: 16px 22px 4px; font-family: Impact, "Arial Black", sans-serif; font-size: 34px; color: var(--c); }
.mshop .sb { padding: 0 22px 10px; font-size: 18px; font-weight: 800; color: #ffc12e; }
.mshop .stats { padding: 4px 22px 10px; }
.mshop .stat { display: flex; align-items: center; gap: 12px; font-size: 14px; font-weight: 700; margin: 6px 0; }
.mshop .stat span { width: 120px; }
.mshop .stat .sbar { flex: 1; height: 12px; background: rgba(255,255,255,0.12); border-radius: 3px; position: relative; overflow: hidden; }
.mshop .stat .sbar i { position: absolute; left: 0; top: 0; bottom: 0; background: #ffc12e; }
.mshop .stat .sbar u { position: absolute; top: 0; bottom: 0; background: #4be3a0; }
.mshop .it { display: flex; align-items: center; justify-content: space-between; padding: 11px 22px;
  border-top: 1px solid rgba(255,255,255,0.08); cursor: pointer; font-size: 17px; font-weight: 700; }
.mshop .it:hover { background: rgba(255,255,255,0.06); }
.mshop .it.dis { opacity: 0.45; }
.mshop .it .k { color: #ffc12e; margin-right: 12px; font-weight: 900; }
.mshop .it .pips { display: inline-flex; gap: 4px; margin-left: 10px; vertical-align: middle; }
.mshop .it .pips i { width: 11px; height: 11px; border-radius: 2px; background: rgba(255,255,255,0.2); }
.mshop .it .pips i.on { background: #4be3a0; }
.mshop .it .why { font-size: 11px; color: #ffb02e; margin-left: 8px; }
.mshop .pr { color: #5dff8f; font-weight: 900; }
.mshop .msg { min-height: 18px; padding: 6px 22px; font-size: 13px; font-weight: 700; }
.mshop .msg.good { color: #4be3a0; } .mshop .msg.bad { color: #ff6b5a; }
.mshop .ft { padding: 10px 22px 14px; font-size: 12px; color: #a9a3b6; }
.mshop .ft b { color: #5dff8f; }
`;

const STAR = (on) => `<svg viewBox="0 0 24 24" class="${on ? 'on' : ''}"><polygon points="12,1.5 15,8.6 22.6,9.2 16.8,14.2 18.6,21.8 12,17.7 5.4,21.8 7.2,14.2 1.4,9.2 9,8.6"
  fill="${on ? '#ffc12e' : 'rgba(20,18,30,0.55)'}" stroke="${on ? '#3a1a00' : 'rgba(255,255,255,0.55)'}" stroke-width="1.4"/></svg>`;
const money = (n) => '$' + Math.floor(n).toLocaleString('en-US');
// Revision 4: DOM writes only when a value actually changes (the HUD
// updates every frame; rewriting unchanged text forces layout work).
const setT = (n, v) => { if (n._t !== v) { n._t = v; n.textContent = v; } };
const setH = (n, v) => { if (n._h !== v) { n._h = v; n.innerHTML = v; } };
const setW = (n, v) => { if (n._w !== v) { n._w = v; n.style.width = v; } };

// 16x16 pixel portrait from a contact's colours.
export function drawPortrait(cv, c) {
  const g = cv.getContext('2d');
  const P = (x, y, w, h, col) => { g.fillStyle = col; g.fillRect(x, y, w, h); };
  g.clearRect(0, 0, 16, 16);
  P(0, 0, 16, 16, c.accent || '#5ac8fa');
  for (let y = 0; y < 16; y += 2) P(0, y, 16, 1, 'rgba(255,255,255,0.12)');
  P(3, 12, 10, 4, c.shirt);                               // shoulders
  P(6, 11, 4, 2, c.skin);                                 // neck
  P(4, 3, 8, 9, c.skin);                                  // face
  P(3, 6, 1, 2, c.skin); P(12, 6, 1, 2, c.skin);          // ears
  const h = c.hair;
  if (c.hairStyle === 'bob' || c.hairStyle === 'long') {
    P(3, 2, 10, 3, h); P(3, 4, 2, c.hairStyle === 'long' ? 9 : 6, h); P(11, 4, 2, c.hairStyle === 'long' ? 9 : 6, h);
  } else if (c.hairStyle === 'bun') {
    P(4, 2, 8, 2, h); P(6, 0, 4, 2, h); P(3, 3, 1, 3, h); P(12, 3, 1, 3, h);
  } else if (c.hairStyle === 'buzz') {
    P(4, 2, 8, 2, h);
  } else { P(4, 1, 8, 3, h); P(5, 0, 2, 1, h); P(9, 0, 2, 1, h); }
  P(5, 6, 2, 2, '#fff'); P(9, 6, 2, 2, '#fff');            // eyes
  P(6, 7, 1, 1, '#141414'); P(10, 7, 1, 1, '#141414');
  P(5, 5, 2, 1, h); P(9, 5, 2, 1, h);                     // brows
  P(6, 10, 4, 1, '#5a2a24');                              // mouth
  P(4, 13, 8, 1, 'rgba(0,0,0,0.25)');
}

export function createHUD({ state, player, police, missions, combat, camera, weather, audio, where }) {
  const style = document.createElement('style');
  style.textContent = CSS;
  document.head.appendChild(style);

  const root = document.createElement('div');
  root.id = 'hud';
  root.innerHTML = `
    <div class="vignette"></div>
    <div class="card panel"><div class="row1"><span class="job"></span><span class="ttl"></span><span class="tmr"></span></div>
      <div class="obj"></div><div class="sub"></div>
      <div class="stage"><span class="sl"></span><div class="bars"></div></div>
      <div class="next"><b>NEXT</b><span></span></div></div>
    <div class="cvpd panel"><div class="hd"><span class="dots"><i></i><i></i></span>&nbsp;CVPD RESPONSE<span class="code"></span></div>
      <div class="rows"></div><div class="ft"></div></div>
    <div class="rc">
      <div class="clock"></div>
      <div class="money num">$0</div>
      <div class="stars"></div>
      <div class="sight"></div>
      <div class="slots"></div>
      <div class="wname"></div>
    </div>
    <div class="notes"></div>
    <div class="wanted"></div>
    <div class="rcard"><b></b><span></span></div>
    <div class="bl">
      <div class="loc panel"><span class="dn"></span><span class="sn"></span></div>
      <div class="hpar"><div class="bar hp"><i></i></div><div class="bar ar"><i></i></div></div>
      <div class="resp panel"><div class="lv"></div><div class="rt"><div class="rn"><b></b><span></span></div><div class="xb"><i></i></div></div></div>
    </div>
    <div class="dlg panel"><canvas width="16" height="16"></canvas><div><div class="who"></div><div class="txt"></div></div></div>
    <div class="br">
      <div class="radio panel"><div class="st"></div><div class="sg"></div></div>
      <div class="veh panel"><div class="vn"></div>
        <div class="cond">CONDITION<div class="bar"><i></i></div><span class="cp"></span></div>
        <div class="cond nos">NITRO&nbsp;&nbsp;&nbsp;&nbsp;<div class="bar"><i></i></div><span class="np">SHIFT</span></div>
        <div class="spd"><b class="num">0</b><span>km/h</span><span class="gear">G1</span></div></div>
    </div>
    <div class="big"><div class="h"></div><div class="s"></div></div>
    <div class="prompt"></div>
    <div class="xhair"></div>
    <div class="hint">H — controls</div>
    <div class="keys panel"><h3>CONTROLS</h3>
      <div><kbd>W A S D</kbd>move / drive · <kbd>Shift</kbd>sprint · <kbd>Space</kbd>jump / handbrake</div>
      <div><kbd>E</kbd>steal / enter / exit a car, mount the bike, enter shops &amp; the garage</div>
      <div><kbd>F</kbd>punch / shoot (hold for SMG + rifle) · click also fires</div>
      <div><kbd>1-5</kbd>pick a weapon · <kbd>Q</kbd>next weapon · <kbd>R</kbd>reload</div>
      <div><kbd>T</kbd>next radio station · <kbd>V</kbd>sound on/off</div>
      <div><kbd>M</kbd>map · <kbd>K</kbd>save · <kbd>O</kbd>free camera · <kbd>Shift+N</kbd>×2 new game</div>
      <div><kbd>Mouse</kbd>drag to look · wheel to zoom</div></div>`;
  document.body.appendChild(root);
  const $ = (s) => root.querySelector(s);
  const el = {
    card: $('.card'), job: $('.card .job'), ttl: $('.card .ttl'), tmr: $('.card .tmr'), obj: $('.card .obj'),
    sub: $('.card .sub'), sl: $('.card .sl'), bars: $('.card .bars'), next: $('.card .next span'), nextRow: $('.card .next'),
    stageRow: $('.card .stage'),
    cvpd: $('.cvpd'), code: $('.cvpd .code'), rows: $('.cvpd .rows'), cft: $('.cvpd .ft'),
    clock: $('.clock'), money: $('.money'), stars: $('.stars'), sight: $('.sight'), slots: $('.slots'), wname: $('.wname'),
    notes: $('.notes'), wanted: $('.wanted'), rcard: $('.rcard'), rcB: $('.rcard b'), rcS: $('.rcard span'),
    dn: $('.loc .dn'), sn: $('.loc .sn'), hp: $('.bar.hp i'), hpBar: $('.bar.hp'), ar: $('.bar.ar i'),
    lv: $('.resp .lv'), rn: $('.resp .rn b'), rx: $('.resp .rn span'), xb: $('.resp .xb i'),
    dlg: $('.dlg'), dcv: $('.dlg canvas'), who: $('.dlg .who'), txt: $('.dlg .txt'),
    radio: $('.radio'), rst: $('.radio .st'), rsg: $('.radio .sg'),
    veh: $('.veh'), vn: $('.veh .vn'), cbar: $('.veh .cond .bar'), ci: $('.veh .cond .bar i'), cp: $('.veh .cp'),
    spd: $('.veh .spd b'), gear: $('.veh .gear'), nos: $('.veh .nos'), nosI: $('.veh .nos .bar i'),
    big: $('.big'), bigH: $('.big .h'), bigS: $('.big .s'), prompt: $('.prompt'), xhair: $('.xhair'),
    vignette: $('.vignette'), keys: $('.keys'), hint: $('.hint'),
  };
  // The page title / help line are replaced by the HUD.
  const title = document.getElementById('title');
  const help = document.getElementById('help');
  if (help) help.style.display = 'none';
  if (title) { title.style.transition = 'opacity 1s'; setTimeout(() => { title.style.opacity = '0'; }, 2500); }
  window.addEventListener('keydown', (e) => {
    if (e.key.toLowerCase() === 'h' && !e.repeat) el.keys.classList.toggle('show');
  });
  setTimeout(() => { el.hint.style.opacity = '0'; el.hint.style.transition = 'opacity 1s'; }, 12000);

  // ---- notifications
  function notify(text, kind = 'info', secs = 3.5, bigNote = false) {
    const n = document.createElement('div');
    n.className = `note ${kind}${bigNote ? ' big' : ''}`;
    n.textContent = text;
    el.notes.appendChild(n);
    while (el.notes.children.length > 5) el.notes.firstChild.remove();
    setTimeout(() => { n.style.opacity = '0'; }, secs * 1000);
    setTimeout(() => n.remove(), secs * 1000 + 450);
  }
  let bigTimer = null;
  function big(head, sub, color = '#fff', secs = 3) {
    setT(el.bigH, head);
    el.bigH.style.color = color;
    setT(el.bigS, sub || '');
    el.big.classList.add('show');
    clearTimeout(bigTimer);
    bigTimer = setTimeout(() => el.big.classList.remove('show'), secs * 1000);
  }
  function prompt(text) {
    if (!text) { el.prompt.style.display = 'none'; return; }
    setH(el.prompt, text.replace(/\bE\b/, '<kbd>E</kbd>'));
    el.prompt.style.display = 'block';
  }

  // ---- dialogue queue (typewriter)
  const queue = [];
  let line = null;
  function pushDialogue(lines) {
    // A new conversation replaces whatever was still waiting.
    queue.length = 0;
    for (const l of lines) queue.push(l);
  }
  function stepDialogue(dt) {
    if (!line && queue.length) {
      line = { ...queue.shift(), t: 0, shown: 0 };
      drawPortrait(el.dcv, line);
      setH(el.who, `<span style="color:${line.accent || '#5ac8fa'}">${line.name}</span><small>${line.role || ''}</small>`);
      el.dlg.style.borderLeftColor = line.accent || '#5ac8fa';
      el.dlg.classList.add('show');
      state.emit('dialogueLine', line);
    }
    if (!line) return;
    line.t += dt;
    const n = Math.min(line.text.length, Math.floor(line.t * 55));
    if (n !== line.shown) { line.shown = n; el.txt.textContent = line.text.slice(0, n); }
    const hold = 1.6 + line.text.length / 22;
    if (line.t > line.text.length / 55 + hold) {
      line = null;
      if (!queue.length) el.dlg.classList.remove('show');
    }
  }

  // ---- shop + garage screens
  function makeScreen(id) {
    const s = document.createElement('div');
    s.className = 'mshop';
    s.id = id;
    document.body.appendChild(s);
    return s;
  }
  const shopEl = makeScreen('shop');
  const garEl = makeScreen('garage');
  let shopHandlers = null;
  let garHandlers = null;
  let lastShopMsg = null;
  let lastGarMsg = null;
  function renderShop(shop, canBuy) {
    shopEl.innerHTML = `<div class="pn" style="--c:${shop.color}">
      <div class="hd">${shop.name}</div><div class="sb" style="color:#ddd;font-size:14px">${shop.blurb}</div>
      ${shop.items.map((it, i) => {
    const why = canBuy(it);
    return `<div class="it ${why ? 'dis' : ''}" data-i="${i}"><span><span class="k">${i + 1}</span>${it.label}${why ? `<span class="why">${why}</span>` : ''}</span>
          <span class="pr">${money(it.price)}</span></div>`;
  }).join('')}
      <div class="msg"></div>
      <div class="ft">Number keys or click to buy · E / Esc to leave · Cash <b>${money(state.money)}</b> · HP ${Math.round(state.hp)} · Armour ${Math.round(state.armor)}</div></div>`;
    shopEl.querySelectorAll('.it').forEach((n) => {
      n.addEventListener('click', () => shopHandlers.buy(shop.items[+n.dataset.i]));
    });
  }
  function renderGarage(v) {
    garEl.innerHTML = `<div class="pn" style="--c:#4be3a0">
      <div class="hd">Rico's Paint &amp; Tune</div><div class="sb">${v.name} · ${v.condition}%</div>
      <div class="stats">${v.stats.map((s) => `<div class="stat"><span>${s.label}</span><div class="sbar"><i style="width:${s.v * 100}%"></i>${s.up ? `<u style="left:${s.v * 100}%;width:${(s.up - s.v) * 100}%"></u>` : ''}</div></div>`).join('')}</div>
      ${v.items.map((it, i) => `<div class="it ${it.dis ? 'dis' : ''}" data-id="${it.id}"><span><span class="k">${i + 1}</span>${it.label}${it.max ? `<span class="pips">${Array.from({ length: it.max }, (_, k) => `<i class="${k < it.level ? 'on' : ''}"></i>`).join('')}</span>` : ''}${it.dis ? `<span class="why">${it.dis}</span>` : ''}</span><span class="pr">${money(it.price)}</span></div>`).join('')}
      <div class="msg"></div>
      <div class="ft">Number keys or click to buy · E / Esc to leave · Cash <b>${money(v.cash)}</b></div></div>`;
    garEl.querySelectorAll('.it').forEach((n) => n.addEventListener('click', () => garHandlers.buy(n.dataset.id)));
  }
  const setMsg = (scr, text, kind) => {
    const m = scr.querySelector('.msg');
    if (m) { m.textContent = text; m.className = `msg ${kind}`; }
  };
  const ui = {
    notify, big, prompt,
    openShop(shop, handlers) { shopHandlers = handlers; renderShop(shop, handlers.canBuy); shopEl.style.display = 'flex'; prompt(null); },
    refreshShop(shop, canBuy) { renderShop(shop, canBuy); if (lastShopMsg) setMsg(shopEl, ...lastShopMsg); },
    closeShop() { shopEl.style.display = 'none'; shopHandlers = null; lastShopMsg = null; },
    shopMessage(text, kind) { lastShopMsg = [text, kind]; setMsg(shopEl, text, kind); },
    openGarage(v, handlers) { garHandlers = handlers; renderGarage(v); garEl.style.display = 'flex'; prompt(null); },
    refreshGarage(v) { renderGarage(v); if (lastGarMsg) setMsg(garEl, ...lastGarMsg); },
    closeGarage() { garEl.style.display = 'none'; garHandlers = null; lastGarMsg = null; },
    garageMessage(text, kind) { lastGarMsg = [text, kind]; setMsg(garEl, text, kind); },
    flashDamage() { el.vignette.style.opacity = '1'; setTimeout(() => { el.vignette.style.opacity = '0'; }, 180); },
    dialogue: pushDialogue,
  };

  // ---- events
  let moneyFlash = 0;
  let wantedTimer = null;
  let rcTimer = null;
  function radioCard(name, sub) {
    setT(el.rcB, name);
    setT(el.rcS, sub);
    el.rcard.classList.add('show');
    clearTimeout(rcTimer);
    rcTimer = setTimeout(() => el.rcard.classList.remove('show'), 2600);
  }
  state.on((type, d) => {
    if (type === 'money') moneyFlash = 0.6;
    if (type === 'pause') {
      root.style.display = d ? 'none' : '';
      const mm = document.getElementById('minimap');
      if (mm) mm.style.display = d ? 'none' : '';
      const cr = document.getElementById('crime');
      if (cr) cr.style.visibility = d ? 'hidden' : '';
    }
    if (type === 'notify') notify(d.text, d.kind);
    if (type === 'saved') notify('Game saved', 'info', 2);
    if (type === 'hurt') ui.flashDamage();
    if (type === 'dialogue') pushDialogue(d.lines);
    if (type === 'wanted') {
      if (state.wanted > d.before && d.why !== 'clear') {
        setH(el.wanted, `WANTED ${'★'.repeat(state.wanted)}`);
        el.wanted.classList.add('show');
        clearTimeout(wantedTimer);
        wantedTimer = setTimeout(() => el.wanted.classList.remove('show'), 2200);
      }
      if (d.why === 'decay' && state.wanted === 0) notify('You lost the cops', 'good');
    }
    if (type === 'carStolen') {
      notify(`VEHICLE ${d.jacked ? 'JACKED' : 'STOLEN'} · ${d.name}`, 'warn', 3.5, true);
      if (d.witness) setTimeout(() => notify('A witness called the CVPD', 'crime', 3.5), 600);
    }
    if (type === 'radio') radioCard(d.name, d.genre ? `${d.genre}${player.inVehicle ? '' : ' · plays in vehicles'}` : '');
    if (type === 'weather') notify(`Weather: ${d.label}`, 'info', 3);
    if (type === 'radioSong' && player.inVehicle) radioCard(d.station, `${d.song} · ${d.artist}`);
    if (type === 'xp' && d.n >= 20) notify(`+${d.n} RESPECT`, 'good', 2.5);
    if (type === 'rankup') big('RANK UP', `${d.rank} · ${d.name}`, '#ffc12e', 3.5);
    if (type === 'weaponGet' && d.first) notify(`New weapon: ${WEAPON[d.id].label}`, 'good', 3);
  });

  // ---- per-frame
  let lastStars = -1;
  let slotKey = '';
  let rowsKey = '';
  let barsKey = '';
  function update(dt) {
    stepDialogue(dt);

    // Mission card.
    const tr = missions.tracker();
    el.card.classList.toggle('idle', tr.idle);
    setT(el.job, tr.idle ? 'NEXT' : tr.job);
    setH(el.ttl, `${tr.title}${tr.contact ? ` <i>· ${tr.contact}</i>` : ''}`);
    if (tr.timer !== null && tr.timer !== undefined) {
      const s = Math.max(0, Math.ceil(tr.timer));
      el.tmr.style.display = '';
      setT(el.tmr, `⏱ ${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`);
      el.tmr.classList.toggle('low', s <= 15);
    } else el.tmr.style.display = 'none';
    setH(el.obj, `${tr.text}${tr.dist !== null && tr.dist !== undefined ? `<span class="dist">${Math.round(tr.dist)} m</span>` : ''}`);
    setT(el.sub, tr.sub || '');
    const bk = `${tr.idle}|${tr.stage}|${tr.stages}`;
    if (bk !== barsKey) {
      barsKey = bk;
      setH(el.bars, Array.from({ length: tr.stages }, (_, i) => `<i class="${i + 1 < tr.stage ? 'on' : i + 1 === tr.stage ? 'cur' : ''}"></i>`).join(''));
    }
    el.stageRow.style.display = tr.idle ? 'none' : '';
    setT(el.sl, `STAGE ${tr.stage}/${tr.stages}`);
    setT(el.next, tr.idle ? `First: ${tr.next}` : tr.next);

    // Right column.
    setH(el.clock, `${clockText(state.clock)}<small>${weather ? weather.label : ''}</small>`);
    moneyFlash -= dt;
    setT(el.money, money(state.money));
    el.money.classList.toggle('flash', moneyFlash > 0);
    if (state.wanted !== lastStars) {
      lastStars = state.wanted;
      setH(el.stars, Array.from({ length: MAX_WANTED }, (_, i) => STAR(i < state.wanted)).join(''));
    }
    el.stars.classList.toggle('blink', state.wanted > 0 && !police.inSight && police.decayLeft < 8);
    if (state.wanted > 0) {
      const ap = police.arrestProgress;
      el.sight.innerHTML = ap > 0.05 ? `<b class="in">ARRESTING ${Math.round(ap * 100)}%</b>`
        : police.inSight ? '<b class="in">IN SIGHT</b><span>search zone follows you</span>'
          : `<b class="out">SEARCHING</b><span>hide · ${Math.max(0, Math.ceil(police.decayLeft))}s to lose a star</span>`;
    } else el.sight.innerHTML = '';

    // Weapon slots.
    const rank = state.rankInfo.rank;
    const sk = WEAPONS.map((w) => {
      const s = state.weapons[w.id];
      return `${w.id}:${state.weapon === w.id}:${s ? `${s.owned}:${s.clip + s.ammo}` : ''}`;
    }).join('|') + rank;
    if (sk !== slotKey) {
      slotKey = sk;
      el.slots.innerHTML = WEAPONS.map((w) => {
        const s = state.weapons[w.id];
        const owned = w.melee || (s && s.owned);
        const sel = state.weapon === w.id;
        const a = w.melee ? '∞' : owned ? String(s.clip + s.ammo)
          : rank >= w.rank ? money(w.price) : `RANK ${w.rank}`;
        return `<div class="slot ${sel ? 'sel' : ''} ${owned ? '' : 'lock'}"><div class="k">${w.slot}</div><div class="n">${w.name}</div><div class="a">${owned ? a : (rank >= w.rank ? a : 'LOCKED')}</div></div>`;
      }).join('');
    }
    const w = WEAPON[state.weapon] || WEAPON.fist;
    setH(el.wname, w.melee ? 'FISTS' : `${w.name}<small>${combat.reloading ? 'RELOADING' : `${state.clip} / ${state.ammo}`}</small>`);

    // Police response panel.
    if (state.wanted > 0) {
      el.cvpd.style.display = 'block';
      const u = police.units();
      const rows = u.slice(0, 5);
      const key = rows.map((r) => `${r.callsign}${r.status}${Math.round(r.dist)}`).join();
      if (key !== rowsKey) {
        rowsKey = key;
        setH(el.rows, rows.map((r) => `<div class="u"><span class="ic">${r.kind === 'heli' ? '✚' : r.kind === 'car' ? '▬' : '●'}</span><span class="cs">${r.callsign}</span><span class="d">${Math.round(r.dist)} m</span><span class="st st-${r.status}">${r.status}</span></div>`).join(''));
      }
      setT(el.code, `${u.length} UNIT${u.length === 1 ? '' : 'S'} · CODE ${state.wanted}`);
      el.cft.textContent = u.length > 5 ? `+${u.length - 5} more units${police.heli ? ' · air support up' : ''}`
        : police.inSight ? 'units have eyes on you' : 'search grid active';
    } else el.cvpd.style.display = 'none';

    // Bottom-left.
    const wh = where ? where() : null;
    if (wh) { el.dn.textContent = wh.district; el.sn.textContent = wh.street; }
    setW(el.hp, `${Math.max(0, state.hp)}%`);
    el.hpBar.classList.toggle('low', state.hp < 30);
    setW(el.ar, `${state.armor}%`);
    const ri = state.rankInfo;
    setT(el.lv, ri.rank);
    setT(el.rn, `RESPECT · ${ri.name}`);
    setT(el.rx, ri.next ? `${ri.xp} / ${ri.next}` : `${ri.xp}`);
    setW(el.xb, ri.next ? `${((ri.xp - ri.floor) / (ri.next - ri.floor)) * 100}%` : '100%');

    // Bottom-right: radio + vehicle.
    const inV = player.inVehicle;
    const np = audio && audio.nowPlaying;
    el.radio.style.display = inV && np ? 'block' : 'none';
    if (inV && np) { el.rst.textContent = `♪ ${np.station}`; el.rsg.textContent = np.song ? `${np.song} · ${np.artist}` : ''; }
    el.veh.style.display = inV ? 'block' : 'none';
    if (inV) {
      const car = player.car;
      const sp = Math.abs(player.speed);
      const kmh = Math.round(sp * 3.6);
      setT(el.spd, kmh);
      let name = 'Vespa Bike';
      let cond = 100;
      let gears = 4;
      let top = 14;
      if (car) { name = car.name; cond = Math.max(0, Math.round(car.hp)); gears = car.stats.gears; top = car.stats.top * (1 + 0.08 * (car.tune || 0)); }
      setT(el.vn, name);
      setW(el.ci, `${cond}%`);
      el.cbar.classList.toggle('mid', cond < 60 && cond >= 30);
      el.cbar.classList.toggle('bad', cond < 30);
      setT(el.cp, `${cond}%`);
      const gear = player.speed < -0.5 ? 'R' : sp < 0.5 ? 'N' : `G${Math.min(gears, 1 + Math.floor((sp / top) * gears))}`;
      setT(el.gear, gear);
      el.nos.style.display = car ? '' : 'none';
      if (car) { el.nosI.style.width = `${Math.round(player.nitro * 100)}%`; el.nos.classList.toggle('on', player.boosting); }
    }

    // Crosshair on the gun ray.
    const gun = !w.melee && state.weapons[state.weapon] && state.weapons[state.weapon].owned;
    const showX = gun && (!player.inVehicle || ['pistol', 'smg'].includes(state.weapon)) && player.followActive && !player.frozen;
    el.xhair.style.display = showX ? 'block' : 'none';
    if (showX) {
      const p = combat.aimPoint.clone().project(camera);
      el.xhair.style.left = `${(p.x * 0.5 + 0.5) * window.innerWidth}px`;
      el.xhair.style.top = `${(-p.y * 0.5 + 0.5) * window.innerHeight}px`;
      el.xhair.classList.toggle('hit', combat.hitMarker);
    }
  }

  void rankOf;
  return { update, ui, root };
}
