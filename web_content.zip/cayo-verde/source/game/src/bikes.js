// bikes.js — F5c: a low-poly motorbike for CAYO VERDE.
// Primitives only, flatShading (blueprint §8B). Local +z is forward.
// The bike stands on its kickstand when parked; the rider code in
// player.js moves it (group position + rotation) while riding.

import * as THREE from 'three';
import { groundHeightAt } from './player.js';

function stdMat(color, extra = {}) {
  return new THREE.MeshStandardMaterial({
    color, flatShading: true, roughness: 0.85, ...extra,
  });
}

function box(w, h, d, mat, x, y, z) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(x, y, z);
  m.castShadow = true;
  return m;
}

// Wheel: dark tyre (low-segment cylinder, axis along X) + lighter hub disc.
function wheel(x, y, z) {
  const g = new THREE.Group();
  const tyre = new THREE.Mesh(
    new THREE.CylinderGeometry(0.32, 0.32, 0.13, 10),
    stdMat(0x1a1a1a),
  );
  tyre.rotation.z = Math.PI / 2;
  tyre.castShadow = true;
  g.add(tyre);
  const hub = new THREE.Mesh(
    new THREE.CylinderGeometry(0.14, 0.14, 0.15, 8),
    stdMat(0x9aa0a6),
  );
  hub.rotation.z = Math.PI / 2;
  g.add(hub);
  g.position.set(x, y, z);
  return g;
}

export function createBike(scene, x, z, rotY) {
  const group = new THREE.Group();
  const blue = stdMat(0x2b6fd6);   // avatar-bike blue
  const dark = stdMat(0x22242a);
  const chrome = stdMat(0xb9bec6, { roughness: 0.4 });

  // Wheels (front +z, rear -z), 1.5 m wheelbase.
  group.add(wheel(0, 0.32, 0.75));
  group.add(wheel(0, 0.32, -0.75));
  // Frame + body: low spine, blue tank, dark seat, tail.
  group.add(box(0.16, 0.14, 1.3, dark, 0, 0.55, 0));
  group.add(box(0.34, 0.26, 0.5, blue, 0, 0.78, 0.22));
  group.add(box(0.3, 0.12, 0.62, dark, 0, 0.82, -0.32));
  group.add(box(0.26, 0.1, 0.3, blue, 0, 0.78, -0.72));
  // Front fork + handlebar (grips at the ends, bar at ~1.0 m).
  const forkL = box(0.06, 0.62, 0.06, chrome, -0.12, 0.62, 0.72);
  forkL.rotation.x = 0.18;
  group.add(forkL);
  const forkR = box(0.06, 0.62, 0.06, chrome, 0.12, 0.62, 0.72);
  forkR.rotation.x = 0.18;
  group.add(forkR);
  group.add(box(0.62, 0.06, 0.06, dark, 0, 0.98, 0.68));
  group.add(box(0.12, 0.08, 0.08, dark, -0.32, 0.98, 0.68));
  group.add(box(0.12, 0.08, 0.08, dark, 0.32, 0.98, 0.68));
  // Headlight (light yellow, slightly emissive) + front fender.
  group.add(box(0.22, 0.16, 0.08,
    stdMat(0xfff2b0, { emissive: 0x554400 }), 0, 0.82, 0.86));
  group.add(box(0.2, 0.05, 0.4, blue, 0, 0.62, 0.78));
  // Exhaust pipe along the right side + foot pegs.
  const pipe = new THREE.Mesh(
    new THREE.CylinderGeometry(0.06, 0.06, 0.9, 8), chrome,
  );
  pipe.rotation.x = Math.PI / 2;
  pipe.position.set(0.2, 0.35, -0.1);
  pipe.castShadow = true;
  group.add(pipe);
  group.add(box(0.1, 0.04, 0.22, dark, -0.22, 0.38, 0.05));
  group.add(box(0.1, 0.04, 0.22, dark, 0.22, 0.38, 0.05));
  // Kickstand: small angled box on the left, bike leans on it when parked.
  const stand = box(0.05, 0.42, 0.05, dark, -0.2, 0.2, -0.1);
  stand.rotation.z = 0.35;
  group.add(stand);

  const y = groundHeightAt(x, z);
  group.position.set(x, y, z);
  group.rotation.y = rotY;
  scene.add(group);

  return {
    group,
    x,
    z,
    heading: rotY,
    get position() { return group.position; },
    // Move the bike (called by the rider code while riding).
    setPose(nx, nz, nHeading, lean = 0) {
      this.x = nx;
      this.z = nz;
      this.heading = nHeading;
      group.position.set(nx, groundHeightAt(nx, nz), nz);
      group.rotation.order = 'YXZ';
      group.rotation.y = nHeading;
      group.rotation.z = lean; // revision 4: leans into turns
    },
  };
}
