// traffic.js — civilian traffic. ~18 cars of 7 types (vehicles.js) drive
// the road graph (layout.js NODES / EDGES) in the right-hand lane, turn at
// intersections (random exit, no U-turns except at dead ends), circulate
// the roundabout with the island on their left, and brake for anything in
// their lane: other cars, police cars, pedestrians on the zebras, cops and
// the player (they honk if you block them). Cars are solid: the player is
// pushed out, and riding into one at speed is a crash (damage, bike stops).
// Shooting a car damages it; at 0 HP it is wrecked (blackened, smoking,
// stopped) and respawns elsewhere later. Deadlocks at junctions are broken
// by letting a car that has waited 4 s ignore other cars briefly.

import * as THREE from 'three';
import { NODES, EDGES, LAYOUT, pointInPolygon } from './layout.js';
import { buildCar, CAR_TYPES, TYPE_WEIGHTS, animateWheels } from './vehicles.js';
import { groundHeightAt } from './player.js';

const CAR_COUNT = 18;
const RING_R = 10.5;

// ---------------------------------------------------------------- graph
const NODE = new Map(NODES.map((n) => [n.id, n]));
const ADJ = new Map(NODES.map((n) => [n.id, []]));
for (const e of EDGES) {
  if (!ADJ.has(e.from) || !ADJ.has(e.to)) continue;
  ADJ.get(e.from).push({ id: e.to, width: e.width });
  ADJ.get(e.to).push({ id: e.from, width: e.width });
}
const widthBetween = (a, b) => (ADJ.get(a).find((x) => x.id === b) || { width: 10 }).width;
// Corner radius: how far before a node the turn starts.
const NODE_R = new Map(NODES.map((n) => [n.id,
  Math.max(...ADJ.get(n.id).map((x) => x.width), 8) / 2 + 2.5]));

function dir(a, b) {
  const dx = b.x - a.x;
  const dz = b.z - a.z;
  const l = Math.hypot(dx, dz) || 1;
  return [dx / l, dz / l];
}
// Driver's right for travel direction (dx, dz): (-dz, dx).
const right = ([dx, dz]) => [-dz, dx];

function pickWeighted() {
  const tot = TYPE_WEIGHTS.reduce((s, [, w]) => s + w, 0);
  let r = Math.random() * tot;
  for (const [t, w] of TYPE_WEIGHTS) { r -= w; if (r <= 0) return t; }
  return 'sedan';
}

export function createTraffic(scene, { state, player, npcs, getPolice }) {
  const cars = [];
  const smokeGeo = new THREE.IcosahedronGeometry(0.5, 0);
  const smokeMat = new THREE.MeshBasicMaterial({ color: 0x333333, transparent: true, opacity: 0.6, depthWrite: false });
  const smoke = [];

  // Waypoints for the turn through node `toId`, arriving from `fromId`
  // and leaving toward `nextId`.
  function turnPoints(fromId, toId, nextId) {
    const P = NODE.get(fromId);
    const A = NODE.get(toId);
    const N = NODE.get(nextId);
    const dIn = dir(P, A);
    const dOut = dir(A, N);
    const oIn = widthBetween(fromId, toId) / 4;
    const oOut = widthBetween(toId, nextId) / 4;
    const rIn = right(dIn);
    const rOut = right(dOut);
    if (A.type === 'roundabout') {
      const ang = (p) => Math.atan2(p.x - A.x, p.z - A.z);
      const a0 = ang(P) + 0.45;
      let a1 = ang(N) - 0.45;
      while (a1 <= a0) a1 += Math.PI * 2;
      const pts = [[A.x - dIn[0] * 19 + rIn[0] * oIn, A.z - dIn[1] * 19 + rIn[1] * oIn]];
      const steps = Math.max(2, Math.ceil((a1 - a0) / 0.4));
      for (let k = 0; k <= steps; k++) {
        const t = a0 + ((a1 - a0) * k) / steps;
        pts.push([A.x + Math.sin(t) * RING_R, A.z + Math.cos(t) * RING_R]);
      }
      pts.push([A.x + dOut[0] * 19 + rOut[0] * oOut, A.z + dOut[1] * 19 + rOut[1] * oOut]);
      return pts;
    }
    const R = NODE_R.get(toId);
    const inPt = [A.x - dIn[0] * R + rIn[0] * oIn, A.z - dIn[1] * R + rIn[1] * oIn];
    const outPt = [A.x + dOut[0] * R + rOut[0] * oOut, A.z + dOut[1] * R + rOut[1] * oOut];
    if (nextId === fromId) {
      // U-turn at a dead end: swing wide around the node.
      return [inPt, [A.x + dIn[0] * 2 + rIn[0] * oIn * 0.2, A.z + dIn[1] * 2 + rIn[1] * oIn * 0.2], outPt];
    }
    // Quadratic Bezier through the lane crossing point.
    const ctrl = [A.x + rIn[0] * oOut + rOut[0] * oIn, A.z + rIn[1] * oOut + rOut[1] * oIn];
    const straight = dIn[0] * dOut[0] + dIn[1] * dOut[1] > 0.9;
    if (straight) return [inPt, outPt];
    const pts = [];
    for (const t of [0, 0.33, 0.66, 1]) {
      const u = 1 - t;
      pts.push([u * u * inPt[0] + 2 * u * t * ctrl[0] + t * t * outPt[0],
        u * u * inPt[1] + 2 * u * t * ctrl[1] + t * t * outPt[1]]);
    }
    return pts;
  }

  function planAhead(car) {
    while (car.wps.length < 6) {
      const opts = ADJ.get(car.to).map((x) => x.id).filter((id) => id !== car.from);
      const next = opts.length ? opts[Math.floor(Math.random() * opts.length)] : car.from;
      car.wps.push(...turnPoints(car.from, car.to, next));
      car.from = car.to;
      car.to = next;
    }
  }

  function spawnCar(farFromPlayer = false, typeOverride = null) {
    const pp = player.position;
    let e = null;
    let t = 0;
    for (let k = 0; k < 40; k++) {
      e = EDGES[Math.floor(Math.random() * EDGES.length)];
      t = 0.25 + Math.random() * 0.5;
      const a = NODE.get(e.from);
      const b = NODE.get(e.to);
      if (!a || !b || a.type === 'roundabout' || b.type === 'roundabout') continue;
      const x = a.x + (b.x - a.x) * t;
      const z = a.z + (b.z - a.z) * t;
      if (!pointInPolygon(x, z, LAYOUT.coastline)) continue;
      if (farFromPlayer && Math.hypot(x - pp.x, z - pp.z) < 60) continue;
      if (cars.some((c) => Math.hypot(c.x - x, c.z - z) < 12)) continue;
      break;
    }
    const flip = Math.random() < 0.5;
    const from = flip ? e.to : e.from;
    const to = flip ? e.from : e.to;
    const A = NODE.get(from);
    const Bn = NODE.get(to);
    const d = dir(A, Bn);
    const o = widthBetween(from, to) / 4;
    const r = right(d);
    const x = A.x + (Bn.x - A.x) * t + r[0] * o;
    const z = A.z + (Bn.z - A.z) * t + r[1] * o;
    const type = typeOverride || pickWeighted();
    const T = CAR_TYPES[type];
    const color = T.colors[Math.floor(Math.random() * T.colors.length)];
    const m = buildCar(type, color);
    m.group.position.set(x, groundHeightAt(x, z), z);
    scene.add(m.group);
    const car = {
      kind: 'traffic', ...m, x, z, heading: Math.atan2(d[0], d[1]), speed: T.cruise * 0.6,
      cruise: T.cruise * (0.9 + Math.random() * 0.2), from, to, wps: [],
      hp: 100, wrecked: false, wreckT: 0, waitT: 0, ignoreCarsT: 0, honkCd: 0,
      panicT: 0, tag: null, stats: T, driver: null, parked: false, parkedT: 0,
      tune: 0, armorLvl: 0, burning: undefined,
    };
    planAhead(car);
    cars.push(car);
    return car;
  }

  function removeCar(car) {
    scene.remove(car.group);
    car.group.traverse((o) => { if (o.isMesh) o.geometry.dispose(); });
    car.bodyMat.dispose();
    cars.splice(cars.indexOf(car), 1);
  }

  for (let i = 0; i < CAR_COUNT; i++) spawnCar(false);

  // Damage from bullets (combat.js) / scripted.
  // Damage scales with the type's toughness and Sully's armour plating.
  // At 0 HP the car catches fire for 5 s, then explodes (fx.js applies
  // the blast) and stays as a burnt-out wreck.
  function damageCar(car, amount) {
    if (car.wrecked || car.burning !== undefined) return null;
    car.hp -= amount * car.stats.armor * (1 - 0.22 * (car.armorLvl || 0));
    car.panicT = 10;
    if (car.hp <= 0) {
      car.hp = 0;
      car.burning = 5;
      state.emit('carBurning', { car });
      return 'burning';
    }
    return 'hit';
  }
  function explodeCar(car) {
    car.burning = undefined;
    car.wrecked = true;
    car.wreckT = 30;
    car.speed = 0;
    car.bodyMat.color.copy(car.baseColor).multiplyScalar(0.18);
    state.emit('carWrecked', { car });
    state.emit('explosion', { x: car.x, z: car.z, y: car.group.position.y, source: car });
  }
  const fireGeo = new THREE.IcosahedronGeometry(0.45, 0);
  const fireMat = new THREE.MeshBasicMaterial({ color: 0xff8a1e, transparent: true, opacity: 0.9, depthWrite: false });
  function burnStep(car, dt) {
    car.burning -= dt;
    if (Math.random() < dt * 14) {
      const f = new THREE.Mesh(fireGeo, fireMat.clone());
      f.material.color.setHSL(0.05 + Math.random() * 0.07, 1, 0.55);
      f.position.set(car.x + (Math.random() - 0.5) * car.W * 0.6, car.group.position.y + 1.0,
        car.z + (Math.random() - 0.5) * car.L * 0.5);
      scene.add(f);
      smoke.push({ s: f, t: 0.8, fire: true });
    }
    if (car.burning <= 0) explodeCar(car);
  }

  // Obstacles a car must not drive into: { x, z, half-width, isCar }.
  function obstacles() {
    const out = [];
    const pp = player.position;
    if (!player.driving) out.push({ x: pp.x, z: pp.z, w: 0.9, who: 'player' });
    for (const c of cars) out.push({ x: c.x, z: c.z, w: c.W / 2 + 0.3, car: c });
    const pol = getPolice();
    if (pol) {
      for (const c of pol.cars) out.push({ x: c.x, z: c.z, w: 1.3, car: c });
      for (const c of pol.cops) if (c.state !== 'down') out.push({ x: c.x, z: c.z, w: 0.6 });
    }
    for (const n of npcs.people) {
      if (n.kind !== 'walker') continue;
      const p = n.mesh.position;
      out.push({ x: p.x, z: p.z, w: 0.6 });
    }
    return out;
  }

  function stepCar(car, dt, obs) {
    car.honkCd -= dt;
    if (car.burning !== undefined) burnStep(car, dt);
    if (car.driver === 'player') return;  // player.js drives it
    if (car.burning !== undefined && !car.wrecked) {
      car.speed *= Math.exp(-2 * dt);
      car.x += Math.sin(car.heading) * car.speed * dt;
      car.z += Math.cos(car.heading) * car.speed * dt;
      car.group.position.set(car.x, groundHeightAt(car.x, car.z) - 0.05, car.z);
      return;
    }
    if (car.parked && !car.wrecked) {
      // Abandoned by the player: stays put; recycled when far away.
      car.parkedT += dt;
      if (car.parkedT > 90 && Math.hypot(car.x - player.position.x, car.z - player.position.z) > 90) {
        removeCar(car);
        spawnCar(true);
      }
      return;
    }
    if (car.wrecked) {
      car.wreckT -= dt;
      if (Math.random() < dt * 6) {
        const s = new THREE.Mesh(smokeGeo, smokeMat.clone());
        s.position.set(car.x + (Math.random() - 0.5), car.group.position.y + 1.2, car.z + (Math.random() - 0.5));
        scene.add(s);
        smoke.push({ s, t: 2.2 });
      }
      if (car.wreckT <= 0 && Math.hypot(car.x - player.position.x, car.z - player.position.z) > 50) {
        removeCar(car);
        spawnCar(true);
      }
      return;
    }
    // Next waypoint (skip ones we have reached or passed).
    while (car.wps.length) {
      const [wx, wz] = car.wps[0];
      const dx = wx - car.x;
      const dz = wz - car.z;
      const ahead = dx * Math.sin(car.heading) + dz * Math.cos(car.heading);
      if (Math.hypot(dx, dz) < 2.2 || (ahead < 0 && Math.hypot(dx, dz) < 6)) car.wps.shift(); else break;
    }
    planAhead(car);
    const [tx, tz] = car.wps[0];
    const want = Math.atan2(tx - car.x, tz - car.z);
    let dh = want - car.heading;
    while (dh > Math.PI) dh -= Math.PI * 2;
    while (dh < -Math.PI) dh += Math.PI * 2;

    let target = car.cruise * (car.panicT > 0 ? 1.5 : 1);
    if (Math.abs(dh) > 0.35) target = Math.min(target, 5.5);
    // Look ahead in the lane.
    const hx = Math.sin(car.heading);
    const hz = Math.cos(car.heading);
    const look = 6 + car.speed * 1.1 + car.L / 2;
    let nearest = Infinity;
    let nearestWho = null;
    for (const o of obs) {
      if (o.car === car) continue;
      if (o.car && car.ignoreCarsT > 0 && o.car.driver !== 'player') continue;
      const dx = o.x - car.x;
      const dz = o.z - car.z;
      const f = dx * hx + dz * hz;
      if (f <= 0 || f > look) continue;
      const l = Math.abs(-dx * hz + dz * hx);
      if (l > car.W / 2 + o.w) continue;
      if (f < nearest) { nearest = f; nearestWho = o; }
    }
    const gap = car.L / 2 + 2.2;
    if (nearest < Infinity) target = Math.min(target, Math.max(0, (nearest - gap) * 1.3));
    car.ignoreCarsT -= dt;
    if (car.speed < 0.5 && nearestWho) {
      car.waitT += dt;
      if ((nearestWho.who === 'player' || (nearestWho.car && nearestWho.car.driver === 'player'))
        && car.waitT > 1.5 && car.honkCd <= 0) {
        car.honkCd = 3 + Math.random() * 2;
        state.emit('horn', { x: car.x, z: car.z });
      }
      if (nearestWho.car && car.waitT > 4) { car.ignoreCarsT = 2.5; car.waitT = 0; }
    } else car.waitT = 0;

    const accel = target > car.speed ? 3 : 9;
    car.speed += THREE.MathUtils.clamp(target - car.speed, -accel * dt, accel * dt);
    const turnRate = 1.6 * Math.min(1, 0.35 + car.speed / 8);
    car.heading += THREE.MathUtils.clamp(dh, -turnRate * dt, turnRate * dt);
    car.panicT -= dt;
    car.x += Math.sin(car.heading) * car.speed * dt;
    car.z += Math.cos(car.heading) * car.speed * dt;
    car.group.position.set(car.x, groundHeightAt(car.x, car.z) - 0.05, car.z);
    car.group.rotation.y = car.heading;
  }

  // Solid cars: push the player out of the car's two body circles.
  let crashCd = 0;
  function collidePlayer(dt) {
    crashCd -= dt;
    const pp = player.position;
    const mine = player.car;
    const pr = mine ? mine.W / 2 : player.riding ? 0.9 : 0.45;
    for (const c of cars) {
      if (c === mine) continue;
      const hx = Math.sin(c.heading);
      const hz = Math.cos(c.heading);
      const n = Math.max(2, Math.ceil(c.L / (c.W * 0.8)));
      for (let k = 0; k < n; k++) {
        const off = n === 1 ? 0 : (-c.L / 2 + c.W / 2) + (k * (c.L - c.W)) / (n - 1);
        const cx = c.x + hx * off;
        const cz = c.z + hz * off;
        const dx = pp.x - cx;
        const dz = pp.z - cz;
        const d = Math.hypot(dx, dz);
        const R = c.W / 2 + pr;
        if (d >= R || d < 1e-4) continue;
        if (mine && crashCd <= 0) {
          // Car vs car: the faster you hit, the more both cars take.
          const rel = Math.abs(player.speed - c.speed * Math.cos(c.heading - player.facing));
          if (rel > 6) {
            crashCd = 0.8;
            state.emit('crash', { speed: rel });
            damageCar(mine, rel * 1.6);
            damageCar(c, rel * 1.4);
            c.panicT = 8;
          }
          player.crash(0.5);
        } else if (player.riding && Math.abs(player.speed) > 8 && crashCd <= 0) {
          crashCd = 1.2;
          const dmg = Math.round(Math.abs(player.speed) * 0.8);
          state.emit('playerShot', { damage: dmg });
          state.emit('crash', { speed: player.speed });
          state.emit('notify', { text: 'Crash!', kind: 'warn' });
          player.crash(0);
          c.panicT = 6;
        }
        player.nudge(cx + (dx / d) * R, cz + (dz / d) * R);
      }
    }
  }

  function update(dt) {
    const obs = obstacles();
    for (let i = cars.length - 1; i >= 0; i--) stepCar(cars[i], dt, obs);
    // Revision 5: wheels + driver visibility (abandoned / wrecked = empty).
    const pp = player.position;
    for (const c of cars) {
      const near = Math.abs(c.x - pp.x) < 90 && Math.abs(c.z - pp.z) < 90;
      if (near) animateWheels(c, dt);
      if (c.driverMesh) c.driverMesh.visible = !c.wrecked && (c.driver === 'player' || !c.parked);
    }
    collidePlayer(dt);
    for (let i = smoke.length - 1; i >= 0; i--) {
      const s = smoke[i];
      s.t -= dt;
      s.s.position.y += dt * (s.fire ? 2.2 : 1.4);
      s.s.scale.multiplyScalar(s.fire ? 1 - dt * 0.8 : 1 + dt * 0.6);
      s.s.material.opacity = s.fire ? Math.max(0, s.t / 0.8) : Math.max(0, s.t / 2.2) * 0.6;
      if (s.t <= 0) { scene.remove(s.s); s.s.material.dispose(); smoke.splice(i, 1); }
    }
  }

  return {
    update,
    cars,
    damageCar,
    explodeCar,
    spawnCar,
    removeCar,
    // Nearest moving car to a point (audio engine hum).
    nearest(x, z) {
      let best = null;
      let bd = Infinity;
      for (const c of cars) {
        if (c.driver === 'player') continue;
        const d = Math.hypot(c.x - x, c.z - z);
        if (d < bd) { bd = d; best = c; }
      }
      return best ? { car: best, dist: bd } : null;
    },
  };
}
