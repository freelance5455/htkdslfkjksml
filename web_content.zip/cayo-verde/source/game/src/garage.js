// garage.js — Rico's Paint & Tune (revision 2 mod shop). Drive any car
// onto the orange pad in front of the B4 warehouse and press E.
//  1 Repair            restores the car to 100% condition
//  2 Respray           new colour; if the cops cannot see you right now
//                      the wanted level is wiped ("loses unseen heat")
//  3 Engine tune       3 levels: +8% top speed and acceleration each
//  4 Armour plating    3 levels: -22% damage taken each
// Upgrades stay on that car (car.tune / car.armorLvl).

import * as THREE from 'three';
import { GARAGE } from './places.js';
import { groundHeightAt } from './player.js';

const PAD_R = 3.2;
const COLORS = ['#ff2d55', '#ffcc00', '#00d2d3', '#111111', '#ff6b00', '#2ecc71', '#8e44ad', '#ecf0f1', '#2980b9', '#c0392b'];

export function createGarage(scene, { state, player, police, ui }) {
  const [gx, gz] = GARAGE.pos;
  const pad = new THREE.Group();
  pad.position.set(gx, groundHeightAt(gx, gz) + 0.03, gz);
  const ring = new THREE.Mesh(new THREE.RingGeometry(PAD_R - 0.4, PAD_R, 32),
    new THREE.MeshBasicMaterial({ color: 0xff8c1a, transparent: true, opacity: 0.85, side: THREE.DoubleSide }));
  ring.rotation.x = -Math.PI / 2;
  pad.add(ring);
  const icon = new THREE.Mesh(new THREE.TorusGeometry(0.45, 0.12, 6, 12),
    new THREE.MeshStandardMaterial({ color: 0xff8c1a, emissive: 0xff8c1a, emissiveIntensity: 0.7 }));
  icon.position.y = 3;
  pad.add(icon);
  scene.add(pad);

  let open = false;
  const near = () => player.driving && Math.hypot(player.position.x - gx, player.position.z - gz) < PAD_R + 1;

  function price(id, car) {
    if (id === 'repair') return 150;
    if (id === 'respray') return 300;
    if (id === 'tune') return 1000 * ((car.tune || 0) + 1);
    if (id === 'armor') return 800 * ((car.armorLvl || 0) + 1);
    return 0;
  }
  function view() {
    const car = player.car;
    const T = car.stats;
    const tune = car.tune || 0;
    const arm = car.armorLvl || 0;
    const stat = (v) => Math.max(0.05, Math.min(1, v));
    return {
      name: car.name,
      condition: Math.round(Math.max(0, car.hp)),
      stats: [
        { label: 'Top speed', v: stat(T.top * (1 + 0.08 * tune) / 52), up: tune < 3 ? stat(T.top * (1 + 0.08 * (tune + 1)) / 52) : null },
        { label: 'Acceleration', v: stat(T.accel * (1 + 0.08 * tune) / 16), up: tune < 3 ? stat(T.accel * (1 + 0.08 * (tune + 1)) / 16) : null },
        { label: 'Armour', v: stat((1 / T.armor) * (1 + 0.3 * arm) / 4), up: arm < 3 ? stat((1 / T.armor) * (1 + 0.3 * (arm + 1)) / 4) : null },
        { label: 'Handling', v: stat(T.grip / 1.4), up: null },
      ],
      items: [
        { id: 'repair', label: 'Repair', price: price('repair', car), dis: car.hp >= 100 ? 'Like new' : null },
        { id: 'respray', label: 'Respray (loses unseen heat)', price: price('respray', car), dis: null },
        { id: 'tune', label: 'Engine tune', level: tune, max: 3, price: price('tune', car), dis: tune >= 3 ? 'Maxed' : null },
        { id: 'armor', label: 'Armour plating', level: arm, max: 3, price: price('armor', car), dis: arm >= 3 ? 'Maxed' : null },
      ],
      cash: state.money,
    };
  }
  function buy(id) {
    const car = player.car;
    if (!car) return;
    const v = view().items.find((i) => i.id === id);
    if (!v || v.dis) { ui.garageMessage(v ? v.dis : '', 'bad'); return; }
    if (!state.charge(v.price)) { ui.garageMessage('Not enough cash', 'bad'); return; }
    if (id === 'repair') car.hp = 100;
    if (id === 'tune') car.tune = (car.tune || 0) + 1;
    if (id === 'armor') car.armorLvl = (car.armorLvl || 0) + 1;
    if (id === 'respray') {
      const c = COLORS[Math.floor(Math.random() * COLORS.length)];
      car.bodyMat.color.set(c);
      car.baseColor.set(c);
      if (state.wanted > 0 && !police.inSight) {
        police.despawnAll();
        state.clearWanted();
        ui.garageMessage('New paint — the cops lost you!', 'good');
        state.emit('purchase', { shop: 'garage', item: id });
        ui.refreshGarage(view());
        return;
      }
    }
    state.emit('purchase', { shop: 'garage', item: id });
    ui.garageMessage(`${v.label} done  -$${v.price}`, 'good');
    ui.refreshGarage(view());
  }
  function enter() {
    open = true;
    player.frozen = true;
    ui.openGarage(view(), { buy, leave });
  }
  function leave() {
    if (!open) return;
    open = false;
    ui.closeGarage();
    player.frozen = false;
  }
  function interact() {
    if (open) { leave(); return true; }
    if (!near()) return false;
    enter();
    return true;
  }
  let swallow = false;
  window.addEventListener('keydown', (e) => {
    if (!open) return;
    const k = e.key.toLowerCase();
    if (k === 'e' && !swallow) { swallow = true; return; }
    if (k === 'escape' || k === 'e') { leave(); return; }
    const ids = ['repair', 'respray', 'tune', 'armor'];
    const n = parseInt(k, 10);
    if (n >= 1 && n <= 4) buy(ids[n - 1]);
  });
  const origEnter = enter;
  void origEnter;

  let prompted = false;
  function update(dt) {
    icon.rotation.y += dt * 2;
    icon.position.y = 3 + Math.sin(performance.now() / 400) * 0.15;
    ring.material.opacity = 0.55 + Math.sin(performance.now() / 300) * 0.3;
    const n = near() && !open;
    if (n !== prompted) {
      prompted = n;
      ui.prompt(n ? "Press E for Rico's Paint & Tune" : null);
    }
    if (!open) swallow = false;
  }

  return { update, interact, get open() { return open; }, pos: GARAGE.pos, buy, enter, leave };
}
