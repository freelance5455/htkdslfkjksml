// buildings.js — F3a + F3b builders, R3 placement: low-poly buildings
// rendered FROM the BUILDINGS list below, generated from the layout.js
// parcels (never hard-coded positions). Flat shading, simple primitives
// only (blueprint §8B). F3a: houses + apartments + shops. F3b: downtown
// towers, beachfront hotels, warehouses, sheds, airport terminal + hangars
// + control tower. R3: every building is placed per parcel — facing the
// road, aligned to the parcel edges, inset 8 m (3 m sidewalk floor + the
// street-tree ring at 5 m + 2.5 m crown clearance), clear of SPAWN_CLEAR.
import * as THREE from 'three';
import {
  BLOCKS, DETAILS, SPAWN_CLEAR, LAYOUT, ROUNDABOUT,
} from './layout.js';
import { SHOPS, HOSPITAL, POLICE_STATION } from './places.js';

// G4/G2/G3: gameplay buildings get their own signs (places.js).
const pinned = (b, place) => b.parcel === place.parcel && b.x === place.bx;
function signFor(b, i) {
  const shop = SHOPS.find((s) => b.type === 'shop' && pinned(b, s));
  return shop ? shop.sign : SHOP_NAMES[i % SHOP_NAMES.length];
}

const FLOOR_H = 3; // metres per floor
const BASE_Y = 0.15; // island grass top is 0.20; sink bases 0.05 so nothing floats

const matCache = new Map();
function mat(color, opts = {}) {
  const key = color + '|' + (opts.roughness ?? 0.9);
  if (!matCache.has(key)) {
    matCache.set(key, new THREE.MeshStandardMaterial({
      color, flatShading: true, roughness: opts.roughness ?? 0.9,
      metalness: 0, ...opts.extra,
    }));
  }
  return matCache.get(key);
}
const WIN_MAT = () => mat('#16222e', { roughness: 0.35 });
// G5: the day/night cycle lights the (shared) window material at night.
export const windowMaterial = () => WIN_MAT();
const TRIM_MAT = () => mat('#f5f0e6');
const ROOF_MATS = ['#8a4a3a', '#5a6b7c', '#7a5a3a'].map((c) => mat(c));

function box(parent, w, h, d, x, y, z, material, shadow = false) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  m.position.set(x, y, z);
  if (shadow) { m.castShadow = true; m.receiveShadow = true; }
  parent.add(m);
  return m;
}

// Flat dark window rectangles on a wall. `face` is +1 (south/+z) or -1
// (north/-z); `cols` windows per floor, `rows` floors, starting at floor 0
// (ground floor skipped for shops — they get shopfront glass instead).
// `spacing` is the horizontal pitch (2.4 default; towers use 1.8, denser).
function windowGrid(parent, b, face, cols, rows, y0, h, w, winW = 1.1, winH = 1.5, spacing = 2.4) {
  const z = b.z + face * (b.d / 2 + 0.06);
  const span = (cols - 1) * spacing;
  for (let f = 0; f < rows; f++) {
    for (let c = 0; c < cols; c++) {
      const x = b.x - span / 2 + c * spacing;
      const y = y0 + f * FLOOR_H + FLOOR_H / 2 + 0.2;
      box(parent, winW, winH, 0.12, x, y, z, WIN_MAT());
    }
  }
  return { z };
}

// Narrow side windows (one column per floor on each short side).
function sideWindows(parent, b, rows, y0) {
  for (const s of [-1, 1]) {
    const x = b.x + s * (b.w / 2 + 0.06);
    for (let f = 0; f < rows; f++) {
      const y = y0 + f * FLOOR_H + FLOOR_H / 2 + 0.2;
      box(parent, 0.12, 1.5, 1.1, x, y, b.z, WIN_MAT());
    }
  }
}

function door(parent, b, y0) {
  const z = b.z + b.front * (b.d / 2 + 0.07);
  box(parent, 1.2, 2.2, 0.14, b.x, y0 + 1.1, z, mat('#4a3525'));
}

// Balcony slab + one front rail bar, on the front face at the given floor.
function balcony(parent, b, floor, xOff) {
  const y = BASE_Y + floor * FLOOR_H + 0.15;
  const z = b.z + b.front * (b.d / 2 + 0.55);
  box(parent, 2.2, 0.15, 1.0, b.x + xOff, y, z, TRIM_MAT());
  box(parent, 2.2, 0.55, 0.07, b.x + xOff, y + 0.55,
    z + b.front * 0.48, mat('#3a3a3a'));
}

// One roof prop per building (deterministic by index): AC box, water tank,
// or small vent — plus solar panels on some flat roofs.
function roofProp(parent, b, topY, i) {
  const kind = i % 3;
  const px = b.x - b.w / 4, pz = b.z - b.d / 4;
  if (kind === 0) {
    box(parent, 0.9, 0.7, 0.9, px, topY + 0.35, pz, TRIM_MAT());
  } else if (kind === 1) {
    const tank = new THREE.Mesh(
      new THREE.CylinderGeometry(0.6, 0.6, 1.2, 8), mat('#7a4a2a'));
    tank.position.set(px, topY + 0.6, pz);
    tank.castShadow = true;
    parent.add(tank);
  } else {
    const vent = new THREE.Mesh(
      new THREE.CylinderGeometry(0.25, 0.35, 0.9, 6), mat('#9aa0a6'));
    vent.position.set(px, topY + 0.45, pz);
    parent.add(vent);
  }
  if (i % 4 === 0) {
    const panel = mat('#1a2a5a', { roughness: 0.3 });
    box(parent, 1.6, 0.08, 1.1, b.x + b.w / 4, topY + 0.15, b.z + b.d / 4, panel);
    box(parent, 1.6, 0.08, 1.1, b.x + b.w / 4, topY + 0.15, b.z - b.d / 4, panel);
  }
}

// Roofs: 0 flat slab, 1 low hip pyramid, 2 gabled prism (ExtrudeGeometry).
function roof(parent, b, topY, kind, i) {
  const roofMat = ROOF_MATS[i % ROOF_MATS.length];
  if (kind === 0) {
    box(parent, b.w + 0.5, 0.3, b.d + 0.5, b.x, topY + 0.15, b.z, roofMat, true);
    return topY + 0.3;
  }
  if (kind === 1) {
    const hipH = 1.8;
    const cone = new THREE.Mesh(new THREE.ConeGeometry(1, hipH, 4), roofMat);
    cone.rotation.y = Math.PI / 4;
    cone.scale.set(b.w / Math.SQRT2 + 0.3, 1, b.d / Math.SQRT2 + 0.3);
    cone.position.set(b.x, topY + hipH / 2, b.z);
    cone.castShadow = true;
    parent.add(cone);
    return topY + hipH;
  }
  const gableH = 1.6;
  const shape = new THREE.Shape();
  shape.moveTo(-b.w / 2 - 0.2, 0);
  shape.lineTo(b.w / 2 + 0.2, 0);
  shape.lineTo(0, gableH);
  shape.closePath();
  const prism = new THREE.Mesh(
    new THREE.ExtrudeGeometry(shape, { depth: b.d + 0.4, bevelEnabled: false }),
    roofMat);
  prism.position.set(b.x, topY, b.z - (b.d + 0.4) / 2);
  prism.castShadow = true;
  parent.add(prism);
  return topY + gableH;
}

// Shop sign names (canvas texture on a plane in front of the sign board).
const SHOP_NAMES = ['CAFE', 'MARKET', 'BAKERY', 'PIZZA', 'BARBER', 'PHARMACY', 'HOTEL', 'TATTOO'];
const SIGN_COLORS = ['#ff2a9a', '#00c8e8', '#ffd21a', '#39d353'];
// Revision 3: night-time neon. Every glowing sign material is registered
// here; daynight.js drives emissiveIntensity (day ~0, night bright, with
// an occasional flicker on some of them).
export const NEON = [];
function neonMat(map, color = 0xffffff, night = 1.6, flicker = false) {
  const m = new THREE.MeshStandardMaterial({
    map, roughness: 0.8, emissive: color, emissiveMap: map || null, emissiveIntensity: 0,
  });
  NEON.push({ mat: m, night, flicker, seed: Math.random() * 100 });
  return m;
}
// Glowing neon text on a dark backing (hotel rooftops, the beach arch).
function neonTexture(text, color, w = 512, h = 112) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const g = c.getContext('2d');
  g.fillStyle = '#120c1c';
  g.fillRect(0, 0, w, h);
  g.font = `italic bold ${Math.round(h * 0.62)}px "Brush Script MT", "Segoe Script", cursive, sans-serif`;
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.shadowColor = color;
  g.shadowBlur = 18;
  g.fillStyle = color;
  g.fillText(text, w / 2, h / 2 + 4);
  g.shadowBlur = 0;
  g.fillStyle = '#ffffff';
  g.globalAlpha = 0.85;
  g.fillText(text, w / 2, h / 2 + 4);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function signTexture(text, bg) {
  const c = document.createElement('canvas');
  c.width = 256; c.height = 64;
  const g = c.getContext('2d');
  g.fillStyle = bg;
  g.fillRect(0, 0, 256, 64);
  g.fillStyle = '#ffffff';
  g.font = `bold ${text.length > 8 ? 26 : 34}px sans-serif`;
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.fillText(text, 128, 34);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

// Shop name boards glow softly at night (emissive = their own texture).
function neonShop(opts) {
  const m = new THREE.MeshStandardMaterial({ ...opts, emissiveMap: opts.map, emissiveIntensity: 0 });
  NEON.push({ mat: m, night: 0.9, flicker: false, seed: 0 });
  return m;
}

function shopFront(parent, b, i, y0) {
  const f = b.front;
  const zf = b.z + f * (b.d / 2);
  // Sign board + name plane above the shopfront.
  const shop = SHOPS.find((s) => b.type === 'shop' && pinned(b, s));
  const signColor = shop ? shop.color : SIGN_COLORS[i % SIGN_COLORS.length];
  const signMat = mat(signColor);
  box(parent, b.w * 0.9, 1.0, 0.18, b.x, y0 + 2.9, zf + f * 0.1, signMat);
  const name = new THREE.Mesh(
    new THREE.PlaneGeometry(b.w * 0.85, 0.85),
    neonShop({
      map: signTexture(signFor(b, i), signColor),
      emissive: 0xffffff,
      flatShading: true, roughness: 0.8,
    }));
  name.position.set(b.x, y0 + 2.9, zf + f * 0.21);
  if (f < 0) name.rotation.y = Math.PI;
  parent.add(name);
  // Angled awning slab over the entrance + big shopfront glass.
  const awning = box(parent, b.w * 0.8, 0.1, 1.4, b.x, y0 + 2.45,
    zf + f * 0.75, mat('#ff7a3a'));
  awning.rotation.x = f * 0.35;
  const glass = WIN_MAT();
  box(parent, b.w * 0.32, 1.9, 0.12, b.x - b.w * 0.24, y0 + 1.15, zf + f * 0.07, glass);
  box(parent, b.w * 0.32, 1.9, 0.12, b.x + b.w * 0.24, y0 + 1.15, zf + f * 0.07, glass);
  door(parent, b, y0);
}

// F3b — downtown towers: tall box, dense window grids on all four faces,
// flat roof with props; the tallest (12 floors) gets a helipad (orange
// roof, yellow circle, black H) and towers of 10+ floors get an antenna.
function buildTower(parent, b, i, y0) {
  const h = b.floors * FLOOR_H;
  const topY = y0 + h;
  box(parent, b.w, h, b.d, b.x, y0 + h / 2, b.z, mat(b.color), true);
  const cols = Math.max(3, Math.floor(b.w / 1.8));
  const sideCols = Math.max(3, Math.floor(b.d / 1.8));
  windowGrid(parent, b, 1, cols, b.floors, y0, h, b.w, 0.9, 1.2, 1.8);
  windowGrid(parent, b, -1, cols, b.floors, y0, h, b.w, 0.9, 1.2, 1.8);
  for (const s of [-1, 1]) {
    const x = b.x + s * (b.w / 2 + 0.06);
    const span = (sideCols - 1) * 1.8;
    for (let f = 0; f < b.floors; f++) {
      for (let c = 0; c < sideCols; c++) {
        box(parent, 0.12, 1.2, 0.9, x, y0 + f * FLOOR_H + FLOOR_H / 2 + 0.2,
          b.z - span / 2 + c * 1.8, WIN_MAT());
      }
    }
  }
  door(parent, b, y0);
  if (b.floors >= 12) {
    box(parent, b.w + 0.5, 0.3, b.d + 0.5, b.x, topY + 0.15, b.z, mat('#e86a2a'), true);
    const pad = new THREE.Mesh(new THREE.CylinderGeometry(3, 3, 0.08, 12), mat('#ffd21a'));
    pad.position.set(b.x, topY + 0.34, b.z);
    parent.add(pad);
    box(parent, 0.5, 0.06, 2.0, b.x - 0.7, topY + 0.4, b.z, mat('#1a1a1a'));
    box(parent, 0.5, 0.06, 2.0, b.x + 0.7, topY + 0.4, b.z, mat('#1a1a1a'));
    box(parent, 1.9, 0.06, 0.5, b.x, topY + 0.4, b.z, mat('#1a1a1a'));
  } else {
    box(parent, b.w + 0.5, 0.3, b.d + 0.5, b.x, topY + 0.15, b.z,
      ROOF_MATS[i % ROOF_MATS.length], true);
    roofProp(parent, b, topY + 0.3, i);
  }
  if (b.floors >= 10) {
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.14, 4, 6), mat('#3a3a3a'));
    mast.position.set(b.x + b.w / 4, topY + 2.3, b.z + b.d / 4);
    parent.add(mast);
    box(parent, 0.3, 0.3, 0.3, b.x + b.w / 4, topY + 4.4, b.z + b.d / 4, mat('#ff2a2a'));
  }
}

// F3b — beachfront hotels: mid-rise box, balcony strips + name sign on the
// east (+x, beach) face, entrance on the west face. The tallest hotel gets
// a rooftop pool slab (flat blue rectangle, no water sim).
const HOTEL_NAMES = ['PALMA', 'SOL MAR', 'CORAL', 'BRISA', 'LUNA'];
const HOTEL_SIGN_COLORS = ['#00c8e8', '#ff2a9a', '#ffd21a', '#39d353', '#c9a7eb'];

function buildHotel(parent, b, i, y0) {
  const h = b.floors * FLOOR_H;
  const topY = y0 + h;
  box(parent, b.w, h, b.d, b.x, y0 + h / 2, b.z, mat(b.color), true);
  const cols = Math.max(3, Math.floor(b.w / 2.4));
  windowGrid(parent, b, 1, cols, b.floors, y0, h, b.w);
  windowGrid(parent, b, -1, cols, b.floors, y0, h, b.w);
  sideWindows(parent, b, b.floors, y0);
  const xe = b.x + b.w / 2;
  for (let f = 1; f < b.floors; f++) {
    const y = y0 + f * FLOOR_H + 0.15;
    box(parent, 1.0, 0.15, b.d * 0.8, xe + 0.5, y, b.z, TRIM_MAT());
    box(parent, 0.07, 0.55, b.d * 0.8, xe + 0.98, y + 0.55, b.z, mat('#3a3a3a'));
  }
  const signColor = HOTEL_SIGN_COLORS[i % HOTEL_SIGN_COLORS.length];
  const signY = topY - 1.6;
  box(parent, 0.18, 1.0, b.d * 0.7, xe + 0.1, signY, b.z, mat(signColor));
  const name = new THREE.Mesh(
    new THREE.PlaneGeometry(b.d * 0.65, 0.85),
    new THREE.MeshStandardMaterial({
      map: signTexture(HOTEL_NAMES[i % HOTEL_NAMES.length], signColor),
      flatShading: true, roughness: 0.8,
    }));
  name.position.set(xe + 0.21, signY, b.z);
  name.rotation.y = Math.PI / 2;
  name.material.emissive = new THREE.Color(0xffffff);
  name.material.emissiveMap = name.material.map;
  name.material.emissiveIntensity = 0;
  NEON.push({ mat: name.material, night: 1.2, flicker: false, seed: 0 });
  parent.add(name);
  // Revision 3 neon: glowing corner strips on the beach face and a big
  // script sign on the roof facing the boulevard (west).
  const strip = neonMat(null, new THREE.Color(signColor), 2.2, i === 2);
  strip.color.set(signColor);
  for (const zz of [b.z - b.d / 2 + 0.1, b.z + b.d / 2 - 0.1]) {
    box(parent, 0.16, h - 0.6, 0.16, xe + 0.06, y0 + h / 2 + 0.2, zz, strip);
    box(parent, 0.16, h - 0.6, 0.16, b.x - b.w / 2 - 0.06, y0 + h / 2 + 0.2, zz, strip);
  }
  box(parent, 0.16, 0.16, b.d - 0.2, b.x - b.w / 2 - 0.06, y0 + FLOOR_H + 0.1, b.z, strip);
  const roofSign = new THREE.Mesh(new THREE.PlaneGeometry(11, 2.4),
    neonMat(neonTexture(HOTEL_NAMES[i % HOTEL_NAMES.length], signColor), 0xffffff, 1.8, i === 3));
  roofSign.position.set(b.x - b.w / 2 + 0.6, topY + 1.7, b.z);
  roofSign.rotation.y = -Math.PI / 2;
  parent.add(roofSign);
  box(parent, 0.2, 2.6, 11.4, b.x - b.w / 2 + 0.75, topY + 1.7, b.z, mat('#1a1424'));
  box(parent, 0.14, 2.2, 1.2, b.x - b.w / 2 - 0.07, y0 + 1.1, b.z, mat('#4a3525'));
  box(parent, b.w + 0.5, 0.3, b.d + 0.5, b.x, topY + 0.15, b.z,
    ROOF_MATS[i % ROOF_MATS.length], true);
  roofProp(parent, b, topY + 0.3, i);
  if (b.floors >= 6) {
    box(parent, 4, 0.08, 3, b.x + b.w / 4, topY + 0.34, b.z,
      mat('#2f9fd8', { roughness: 0.3 }));
  }
}

// F3b — port/industrial warehouses: long low box, gabled roof, big doors
// on the front face, one row of small high windows.
function buildWarehouse(parent, b, i, y0) {
  const h = b.floors * FLOOR_H;
  const topY = y0 + h;
  box(parent, b.w, h, b.d, b.x, y0 + h / 2, b.z, mat(b.color), true);
  roof(parent, b, topY, 2, i);
  const f = b.front;
  const zf = b.z + f * (b.d / 2 + 0.06);
  const nDoors = b.w >= 18 ? 2 : 1;
  for (let k = 0; k < nDoors; k++) {
    const x = b.x + (nDoors === 1 ? 0 : (k === 0 ? -b.w / 4 : b.w / 4));
    box(parent, 3.5, 2.8, 0.12, x, y0 + 1.4, zf, mat('#2a2a2e', { roughness: 0.6 }));
  }
  const cols = Math.max(2, Math.floor(b.w / 3));
  windowGrid(parent, b, f, cols, 1, y0 + FLOOR_H, h, b.w, 0.9, 0.8);
  windowGrid(parent, b, -f, cols, 1, y0 + FLOOR_H, h, b.w, 0.9, 0.8);
}

// F3b — airport terminal: long low box, wide glass bands on both long
// faces, AIRPORT sign on the north face, flat roof with props.
function buildTerminal(parent, b, i, y0) {
  const h = b.floors * FLOOR_H;
  const topY = y0 + h;
  box(parent, b.w, h, b.d, b.x, y0 + h / 2, b.z, mat(b.color), true);
  for (const f of [1, -1]) {
    const zf = b.z + f * (b.d / 2 + 0.06);
    box(parent, b.w * 0.85, 2.2, 0.12, b.x, y0 + 1.3, zf, WIN_MAT());
    windowGrid(parent, b, f, Math.floor(b.w / 2.4), 1, y0 + FLOOR_H, h, b.w);
  }
  const signY = y0 + h - 0.7;
  box(parent, b.w * 0.4, 1.0, 0.18, b.x, signY, b.z - b.d / 2 - 0.1, mat('#00c8e8'));
  const name = new THREE.Mesh(
    new THREE.PlaneGeometry(b.w * 0.38, 0.85),
    new THREE.MeshStandardMaterial({
      map: signTexture('AIRPORT', '#00c8e8'),
      flatShading: true, roughness: 0.8,
    }));
  name.position.set(b.x, signY, b.z - b.d / 2 - 0.21);
  name.rotation.y = Math.PI;
  parent.add(name);
  door(parent, b, y0);
  box(parent, b.w + 0.5, 0.3, b.d + 0.5, b.x, topY + 0.15, b.z,
    ROOF_MATS[i % ROOF_MATS.length], true);
  roofProp(parent, b, topY + 0.3, i);
}

// F3b — hangar: tall box (floors: 3 = 9 m), shallow gabled roof, one huge
// dark door on the front face.
function buildHangar(parent, b, i, y0) {
  const h = b.floors * FLOOR_H;
  const topY = y0 + h;
  box(parent, b.w, h, b.d, b.x, y0 + h / 2, b.z, mat(b.color), true);
  roof(parent, b, topY, 2, i);
  const f = b.front;
  box(parent, b.w * 0.7, h * 0.7, 0.12, b.x, y0 + h * 0.35,
    b.z + f * (b.d / 2 + 0.06), mat('#2a2a2e', { roughness: 0.6 }));
}

// F3b — control tower: thin shaft (floors: 10 = 30 m), wider cab on top
// with a dark glass band, flat roof slab + antenna.
function buildControlTower(parent, b, i, y0) {
  const h = b.floors * FLOOR_H;
  const topY = y0 + h;
  box(parent, b.w, h, b.d, b.x, y0 + h / 2, b.z, mat(b.color), true);
  door(parent, b, y0);
  const cabW = b.w + 4;
  const cabD = b.d + 4;
  box(parent, cabW, 3, cabD, b.x, topY + 1.5, b.z, mat(b.color), true);
  box(parent, cabW + 0.3, 1.4, cabD + 0.3, b.x, topY + 1.7, b.z, WIN_MAT());
  box(parent, cabW + 0.5, 0.3, cabD + 0.5, b.x, topY + 3.15, b.z,
    ROOF_MATS[i % ROOF_MATS.length], true);
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.14, 3, 6), mat('#3a3a3a'));
  mast.position.set(b.x, topY + 4.8, b.z);
  parent.add(mast);
}

// F3b — industrial shed: 1-floor box, flat roof with props, vent pipe on
// the roof, door + small windows on the front face.
function buildShed(parent, b, i, y0) {
  const h = b.floors * FLOOR_H;
  const topY = y0 + h;
  box(parent, b.w, h, b.d, b.x, y0 + h / 2, b.z, mat(b.color), true);
  box(parent, b.w + 0.5, 0.3, b.d + 0.5, b.x, topY + 0.15, b.z,
    ROOF_MATS[i % ROOF_MATS.length], true);
  roofProp(parent, b, topY + 0.3, i);
  const vent = new THREE.Mesh(
    new THREE.CylinderGeometry(0.3, 0.35, 2.5, 6), mat('#9aa0a6'));
  vent.position.set(b.x + b.w / 4, topY + 1.55, b.z - b.d / 4);
  parent.add(vent);
  door(parent, b, y0);
  const cols = Math.max(2, Math.floor(b.w / 3));
  windowGrid(parent, b, b.front, cols, 1, y0, h, b.w, 0.9, 0.8);
}

function buildBuilding(parent, b, i) {
  // Base height: hotels on the beach sand sit higher (baseY 0.35); every
  // other type sinks 0.05 into the grass (BASE_Y 0.15).
  const y0 = b.baseY ?? BASE_Y;
  if (b.type === 'tower') return buildTower(parent, b, i, y0);
  if (b.type === 'hotel') return buildHotel(parent, b, i, y0);
  if (b.type === 'warehouse') return buildWarehouse(parent, b, i, y0);
  if (b.type === 'terminal') return buildTerminal(parent, b, i, y0);
  if (b.type === 'hangar') return buildHangar(parent, b, i, y0);
  if (b.type === 'control-tower') return buildControlTower(parent, b, i, y0);
  if (b.type === 'shed') return buildShed(parent, b, i, y0);
  const h = b.floors * FLOOR_H;
  const topY = y0 + h;
  const bodyMat = mat(b.color);
  // Body (sunk 0.05 into the ground so the base never floats).
  box(parent, b.w, h, b.d, b.x, y0 + h / 2, b.z, bodyMat, true);
  // Roof (kind varies deterministically; shops always get a flat roof).
  const kind = b.type === 'shop' ? 0 : i % 3;
  const peakY = roof(parent, b, topY, kind, i);
  // Roof props sit on flat roofs only — on hip/gabled slopes they would sink
  // into the roof surface.
  if (kind === 0) roofProp(parent, b, topY + 0.3, i);
  if (b.type === 'shop') {
    shopFront(parent, b, i, y0);
    if (b.floors > 1) {
      windowGrid(parent, b, b.front, 3, b.floors - 1, y0 + FLOOR_H, h, b.w);
      windowGrid(parent, b, -b.front, 3, b.floors - 1, y0 + FLOOR_H, h, b.w);
    }
    return;
  }
  // Residential: window grids both long faces + side windows + door.
  const cols = Math.max(2, Math.floor(b.w / 2.4));
  windowGrid(parent, b, b.front, cols, b.floors, y0, h, b.w);
  windowGrid(parent, b, -b.front, cols, b.floors, y0, h, b.w);
  sideWindows(parent, b, b.floors, y0);
  door(parent, b, y0);
  // Balconies on upper floors (apartments always, houses on even indexes).
  if (b.type === 'apartments' || i % 2 === 0) {
    for (let f = 1; f < b.floors; f++) {
      balcony(parent, b, f, -b.w / 4);
      if (b.w >= 8) balcony(parent, b, f, b.w / 4);
    }
  }
  void peakY;
}

// ------------------------------------------------------- R3 placement
// Buildings are GENERATED from the parcels (BLOCKS), one record per
// building in the shape the builders / maps / collision expect:
// { x, z, w, d, floors, type, color, front, rot, baseY?, parcel }.
// `front` is the parcel's front side (scalar, same convention as the
// parcels: -1 faces north/-z, +1 faces south/+z).
//
// Inset: 8 m from every parcel edge. The brief's 3 m is the sidewalk
// floor; the street trees stand 5 m inside each parcel edge (road
// half-width + 3 m sidewalk + 2 m), and buildings must clear every tree
// by 2.5 m (crown radius + margin) — 5 + 2.5 = 7.5, so 8 m clears the
// whole tree ring with 0.5 m to spare. SPAWN_CLEAR (5 m around the spawn
// and the bike) is satisfied by the same inset: parcel C2's buildings
// start 9.5 m east of the bike. The roundabout circle (r14) is clear
// because the downtown parcels are clipped to ±14 and the inset pushes
// buildings to >=22 m from the centre.

const PALETTE = LAYOUT.palette.buildings;

function parcelById(id) {
  return BLOCKS.find((p) => p.id === id);
}

// Buildable interior of a parcel: 8 m inset on every side.
function interiorOf(p, inset = 8) {
  return {
    x0: p.x0 + inset, z0: p.z0 + inset,
    x1: p.x1 - inset, z1: p.z1 - inset,
  };
}

let colorIdx = 0;
function rec(p, type, cx, cz, w, d, floors, extra = {}) {
  return {
    x: +cx.toFixed(2), z: +cz.toFixed(2), w, d, floors, type,
    color: PALETTE[colorIdx++ % PALETTE.length],
    front: p.front, rot: 0, parcel: p.id, ...extra,
  };
}

// Regular cols×rows grid inside a parcel's interior, cells centred —
// rows run parallel to the parcel edges, never piled in a corner.
function grid(p, cols, rows, w, d, type, floorsFn) {
  const it = interiorOf(p);
  const out = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const cx = it.x0 + ((c + 0.5) / cols) * (it.x1 - it.x0);
      const cz = it.z0 + ((r + 0.5) / rows) * (it.z1 - it.z0);
      out.push(rec(p, type, cx, cz, w, d, floorsFn(c, r)));
    }
  }
  return out;
}

// Downtown parcel (41×41, interior 25×25): one tower at the back corner
// (away from the front road) + two shops in a row along the front edge.
function downtown(p, towerFloors) {
  const it = interiorOf(p);
  const f = p.front; // +1 faces south, -1 faces north
  const towerZ = f === 1 ? it.z0 + 7 : it.z1 - 7;
  const shopZ = f === 1 ? it.z1 - 5 : it.z0 + 5;
  return [
    rec(p, 'tower', it.x0 + 7, towerZ, 14, 14, towerFloors),
    rec(p, 'shop', it.x0 + 7, shopZ, 8, 10, 2),
    rec(p, 'shop', it.x1 - 4, shopZ, 8, 10, 1),
  ];
}

// Eastside parcel D3: two apartment blocks at the back + two shops along
// the front (north) edge.
function eastside(p) {
  const it = interiorOf(p);
  return [
    // Revision 5: taller pastel mid-rises so the beach boulevard skyline
    // reads as a Miami strip from the road.
    rec(p, 'apartments', it.x0 + 6, it.z1 - 6, 12, 12, 9, { color: '#f7c6a3' }),
    rec(p, 'apartments', it.x1 - 6, it.z1 - 6, 12, 12, 11, { color: '#b9e4f2' }),
    rec(p, 'shop', it.x0 + 4, it.z0 + 5, 8, 10, 1),
    rec(p, 'shop', it.x1 - 4, it.z0 + 5, 8, 10, 2),
  ];
}

// Industrial parcel: one warehouse along the back (north) edge + two
// sheds along the front (south) edge.
function industrial(p) {
  const it = interiorOf(p);
  const midX = (it.x0 + it.x1) / 2;
  return [
    rec(p, 'warehouse', midX, it.z0 + 7, 18, 14, 2),
    rec(p, 'shed', it.x0 + 4, it.z1 - 4, 8, 8, 1),
    rec(p, 'shed', it.x1 - 4, it.z1 - 4, 8, 8, 1),
  ];
}

// Airport parcel A4: terminal along the north edge (its centre matches
// the Airport Terminal place label at (-88, 80)), control tower in the
// middle, two hangars along the south edge.
function airport(p) {
  return [
    rec(p, 'terminal', -88, 78, 24, 10, 2),
    rec(p, 'control-tower', -88, 87.5, 6, 6, 10),
    rec(p, 'hangar', -96, 98, 12, 12, 3),
    rec(p, 'hangar', -80, 98, 12, 12, 3),
  ];
}

// Vice Beach hotels: no grid parcel — they stand on the sand east of the
// ring road, facing the sea (+x). baseY 0.35 (sand top 0.40, sunk 0.05).
// Centre x 142: west face at 136, 3 m clear of the ring's east-side tree
// line (x 133) and 5 m clear of its sidewalk (ends at 131). The z slots
// keep the pier (z -3..3) and the ferris wheel's gondola sweep (a thin
// vertical disc at x ≈ 144, z 19..31) clear: three hotels south of the
// pier, two north of the wheel. The five names cycle by index
// (HOTEL_NAMES in buildHotel), so the hotels sit consecutively in the
// list and get all five names.
const BEACH = { id: 'vice-beach', front: 1 };
function hotels() {
  const zs = [-70, -48, -26, 44, 66];
  // Revision 3: taller Miami-style hotels in pastel art-deco colours.
  const floors = [9, 11, 8, 10, 12];
  const pastel = ['#f6b8c8', '#a8e6cf', '#c9b6f2', '#ffd3a5', '#9fdcf0'];
  return zs.map((z, i) =>
    rec(BEACH, 'hotel', 142, z, 12, 16, floors[i], { baseY: 0.35, color: pastel[i] }));
}

// Safety filter: drop any building that violates a clearance (tree,
// spawn, roundabout). Placement is by construction, so this should never
// fire — it guards against a future layout change moving a tree into a
// building footprint. (The R3 import test verifies zero drops.)
const TREES = DETAILS.filter((d) => d.type === 'tree' || d.type === 'palm');
function rectPointDist(b, px, pz) {
  const dx = Math.max(b.x - b.w / 2 - px, 0, px - (b.x + b.w / 2));
  const dz = Math.max(b.z - b.d / 2 - pz, 0, pz - (b.z + b.d / 2));
  return Math.hypot(dx, dz);
}
function clearancesOk(b) {
  if (!TREES.every((t) => rectPointDist(b, t.x, t.z) >= 2.5)) return false;
  if (![SPAWN_CLEAR.spawn, SPAWN_CLEAR.bike].every(([px, pz]) =>
    rectPointDist(b, px, pz) >= SPAWN_CLEAR.radius)) return false;
  if (rectPointDist(b, ROUNDABOUT.x, ROUNDABOUT.z) < ROUNDABOUT.radius) return false;
  return true;
}

export const BUILDINGS = [
  ...['A1', 'C1', 'D1'].flatMap((id) =>
    grid(parcelById(id), 3, 2, 8, 9, 'house', (c, r) => 1 + ((c + r) % 2))),
  ...downtown(parcelById('B2'), 8),
  ...downtown(parcelById('C2'), 10),
  ...downtown(parcelById('B3'), 6),
  ...downtown(parcelById('C3'), 12), // landmark: 12 floors + helipad
  ...eastside(parcelById('D3')),
  ...industrial(parcelById('B4')),
  ...industrial(parcelById('C4')),
  ...industrial(parcelById('D4')),
  ...airport(parcelById('A4')),
  ...hotels(),
  // Park parcels (B1, A2, D2, A3) and the Port get NO buildings by design.
].filter(clearancesOk);

function hospitalTexture() {
  const c = document.createElement('canvas');
  c.width = 256; c.height = 80;
  const g = c.getContext('2d');
  g.fillStyle = '#ffffff';
  g.fillRect(0, 0, 256, 80);
  g.fillStyle = '#e02424';
  g.fillRect(24, 16, 16, 48);
  g.fillRect(8, 32, 48, 16);
  g.font = 'bold 34px sans-serif';
  g.textBaseline = 'middle';
  g.fillText('HOSPITAL', 66, 42);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

// G2/G3 landmark signs: a HOSPITAL board with a red cross on the D3
// apartment front, a POLICE board on the C2 tower's east face.
function landmarkSign(parent, text, bg, w, x, y, z, rotY, cross) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.rotation.y = rotY;
  box(g, w, 1.3, 0.2, 0, 0, 0, mat(bg));
  const plane = new THREE.Mesh(new THREE.PlaneGeometry(w * 0.94, 1.15),
    new THREE.MeshStandardMaterial({ map: signTexture(text, bg), roughness: 0.8,
      emissive: 0xffffff, emissiveIntensity: 0.15 }));
  plane.position.z = 0.11;
  g.add(plane);
  if (cross) plane.material.map = hospitalTexture();
  parent.add(g);
}
// Revision 3: a neon "VICE BEACH" arch spanning the beach boulevard.
function buildArch(parent) {
  const z = -12;
  const pm = mat('#2a2236');
  for (const x of [110.3, 129.7]) box(parent, 0.5, 8.2, 0.5, x, BASE_Y + 4.1, z, pm, true);
  box(parent, 20, 0.5, 0.5, 120, BASE_Y + 8.1, z, pm, true);
  const tex = neonTexture('Vice Beach', '#ff4fd8', 768, 128);
  for (const side of [-1, 1]) {
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(14, 2.3), neonMat(tex, 0xffffff, 2.0, true));
    sign.position.set(120, BASE_Y + 9.6, z + side * 0.27);
    sign.rotation.y = side > 0 ? 0 : Math.PI;
    parent.add(sign);
  }
  box(parent, 14.4, 2.6, 0.5, 120, BASE_Y + 9.6, z, mat('#120c1c'));
  const tube = neonMat(null, new THREE.Color('#2ee6ff'), 2.4, false);
  tube.color.set('#2ee6ff');
  box(parent, 19.6, 0.12, 0.6, 120, BASE_Y + 7.75, z, tube);
}

function buildLandmarks(parent) {
  buildArch(parent);
  const hosp = BUILDINGS.find((b) => pinned(b, HOSPITAL));
  if (hosp) {
    const z = hosp.z + hosp.front * (hosp.d / 2 + 0.12);
    landmarkSign(parent, 'HOSPITAL', '#ffffff', 3.6, hosp.x, BASE_Y + 3.0, z,
      hosp.front < 0 ? Math.PI : 0, true);
  }
  const pol = BUILDINGS.find((b) => pinned(b, POLICE_STATION) && b.type === 'tower');
  if (pol) {
    landmarkSign(parent, 'POLICE', '#1b3a8a', 5, pol.x + pol.w / 2 + 0.12, BASE_Y + 4.0, pol.z,
      Math.PI / 2, false);
    // Blue lamp over the entrance.
    box(parent, 0.5, 0.5, 0.5, pol.x + pol.w / 2 + 0.4, BASE_Y + 2.9, pol.z,
      new THREE.MeshStandardMaterial({ color: 0x2050ff, emissive: 0x2050ff, emissiveIntensity: 1.5 }));
  }
}

export function buildBuildings(scene) {
  const group = new THREE.Group();
  group.name = 'buildings';
  BUILDINGS.forEach((b, i) => buildBuilding(group, b, i));
  buildLandmarks(group);
  scene.add(group);
  return group;
}
