// fx.js — explosions (revision 2). Listens for 'explosion' events
// (traffic.js emits one when a burning car blows up) and plays a fireball,
// flying debris, a light flash and a smoke column, then applies the blast:
// people within 7 m are knocked down (within 3.5 m killed), cops go down,
// nearby cars take heavy damage (chain reactions), and the player loses
// health with distance — or is WASTED if they were still in the car.

import * as THREE from 'three';

const BLAST_R = 7;

export function createFX(scene, { state, player, npcs, getPolice, traffic }) {
  const parts = [];
  const fireGeo = new THREE.IcosahedronGeometry(1, 1);
  const debrisGeo = new THREE.BoxGeometry(0.35, 0.2, 0.5);
  const debrisMat = new THREE.MeshStandardMaterial({ color: 0x1a1a1a, flatShading: true });
  const smokeGeo = new THREE.IcosahedronGeometry(1, 0);
  const flash = new THREE.PointLight(0xffa040, 0, 60, 1.4);
  scene.add(flash);
  let flashT = 0;

  function explode(x, y, z, source) {
    // Fireball: a few expanding, fading orange/yellow balls.
    // Revision 5: bigger, HDR-bright fireball (colour > 1 so it blooms),
    // white-hot core, ground shockwave ring, lingering flames + scorch.
    for (let i = 0; i < 16; i++) {
      // Inner: small white-yellow additive core. Outer: orange -> deep red
      // puffs, spread wider, rising, so the blast reads as layered flame.
      const hot = i < 4;
      const hue = 0.015 + Math.random() * 0.06;
      const c = hot ? new THREE.Color(3.2, 2.4, 1.2) : new THREE.Color().setHSL(hue, 1, 0.42 + Math.random() * 0.12).multiplyScalar(1.7);
      const m = new THREE.Mesh(fireGeo, new THREE.MeshBasicMaterial({
        color: c, transparent: true, opacity: hot ? 0.9 : 0.7, depthWrite: false,
        blending: hot ? THREE.AdditiveBlending : THREE.NormalBlending,
      }));
      const spread = hot ? 1.2 : 3.6;
      m.position.set(x + (Math.random() - 0.5) * spread, y + 0.8 + Math.random() * (hot ? 1 : 2.6), z + (Math.random() - 0.5) * spread);
      m.scale.setScalar(0.3);
      scene.add(m);
      parts.push({ m, t: hot ? 0.4 : 0.7 + Math.random() * 0.5, max: hot ? 0.4 : 1.2, kind: 'fire', grow: hot ? 2.4 : 1.8 + Math.random() * 2, delay: hot ? 0 : 0.03 + Math.random() * 0.15 });
    }
    {
      const ring = new THREE.Mesh(new THREE.RingGeometry(0.6, 1.1, 32),
        new THREE.MeshBasicMaterial({ color: new THREE.Color(3, 2.2, 1.2), transparent: true, opacity: 0.9, depthWrite: false, side: THREE.DoubleSide }));
      ring.rotation.x = -Math.PI / 2;
      ring.position.set(x, y + 0.15, z);
      scene.add(ring);
      parts.push({ m: ring, t: 0.5, max: 0.5, kind: 'ring' });
      const scorch = new THREE.Mesh(new THREE.CircleGeometry(3.4, 20),
        new THREE.MeshBasicMaterial({ color: 0x0c0a08, transparent: true, opacity: 0.65, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -3 }));
      scorch.rotation.x = -Math.PI / 2;
      scorch.position.set(x, y + 0.04, z);
      scene.add(scorch);
      parts.push({ m: scorch, t: 25, max: 25, kind: 'scorch' });
    }
    for (let i = 0; i < 10; i++) {
      const m = new THREE.Mesh(fireGeo, new THREE.MeshBasicMaterial({ color: new THREE.Color(2.4, 0.9, 0.2), transparent: true, opacity: 0.8, depthWrite: false }));
      m.position.set(x + (Math.random() - 0.5) * 2.4, y + 0.6, z + (Math.random() - 0.5) * 2.4);
      m.scale.setScalar(0.3);
      m.visible = false;
      scene.add(m);
      parts.push({ m, t: 0.7, max: 0.7, kind: 'flame', delay: 0.5 + i * 0.35, bx: m.position.x, bz: m.position.z, by: m.position.y });
    }
    for (let i = 0; i < 10; i++) {
      const m = new THREE.Mesh(debrisGeo, debrisMat);
      m.position.set(x, y + 1, z);
      scene.add(m);
      const a = Math.random() * Math.PI * 2;
      const s = 5 + Math.random() * 7;
      parts.push({ m, t: 2.5, max: 2.5, kind: 'debris', vx: Math.cos(a) * s, vy: 6 + Math.random() * 6, vz: Math.sin(a) * s, gy: y });
    }
    for (let i = 0; i < 8; i++) {
      const m = new THREE.Mesh(smokeGeo, new THREE.MeshBasicMaterial({ color: 0x2a2a2a, transparent: true, opacity: 0.55, depthWrite: false }));
      m.position.set(x + (Math.random() - 0.5) * 2, y + 1.5, z + (Math.random() - 0.5) * 2);
      m.scale.setScalar(0.8);
      scene.add(m);
      parts.push({ m, t: 3 + Math.random() * 2, max: 5, kind: 'smoke', delay: 0.2 + i * 0.12 });
    }
    flash.position.set(x, y + 3, z);
    flashT = 0.5;

    // ---- blast damage
    const pp = player.position;
    const pd = Math.hypot(pp.x - x, pp.z - z);
    if (player.car && player.car === source) {
      state.emit('playerShot', { damage: 999 });
    } else if (pd < BLAST_R) {
      state.emit('playerShot', { damage: Math.round(70 * (1 - pd / BLAST_R)) + 10 });
      if (player.inVehicle) player.crash(0.2);
    }
    for (const n of npcs.people) {
      if (!npcs.alive(n)) continue;
      const p = n.mesh.position;
      const d = Math.hypot(p.x - x, p.z - z);
      if (d < BLAST_R) npcs.knock(n, x, z, d < BLAST_R / 2);
      else if (d < 25) npcs.scare(n, x, z, 7);
    }
    const pol = getPolice();
    if (pol) {
      for (const c of pol.cops) {
        if (c.state === 'down') continue;
        if (Math.hypot(c.x - x, c.z - z) < BLAST_R) {
          c.state = 'down'; c.timer = 12; c.fall = 0;
        }
      }
    }
    for (const c of traffic.cars) {
      if (c === source || c.wrecked) continue;
      const d = Math.hypot(c.x - x, c.z - z);
      if (d < BLAST_R) traffic.damageCar(c, 90 * (1 - d / BLAST_R) + 20);
    }
  }

  state.on((type, d) => {
    if (type === 'explosion') explode(d.x, d.y || 0, d.z, d.source);
  });

  function update(dt) {
    if (flashT > 0) { flashT -= dt; flash.intensity = Math.max(0, flashT / 0.5) * 400; } else flash.intensity = 0;
    for (let i = parts.length - 1; i >= 0; i--) {
      const p = parts[i];
      if (p.delay > 0) { p.delay -= dt; p.m.visible = false; continue; }
      p.m.visible = true;
      p.t -= dt;
      const k = Math.max(0, p.t / p.max);
      if (p.kind === 'fire') {
        p.m.scale.setScalar(0.5 + (1 - k) * p.grow);
        p.m.material.opacity = k;
        p.m.position.y += dt * 1.5;
      } else if (p.kind === 'ring') {
        p.m.scale.setScalar(1 + (1 - k) * 11);
        p.m.material.opacity = 0.9 * k;
      } else if (p.kind === 'scorch') {
        p.m.material.opacity = 0.65 * Math.min(1, k * 3);
      } else if (p.kind === 'flame') {
        p.m.scale.setScalar(0.3 + (1 - k) * 0.9);
        p.m.position.set(p.bx, p.by + (1 - k) * 1.6, p.bz);
        p.m.material.opacity = 0.8 * k;
        if (p.t <= 0 && p.loops === undefined) p.loops = 0;
      } else if (p.kind === 'debris') {
        p.vy -= 18 * dt;
        p.m.position.x += p.vx * dt;
        p.m.position.y = Math.max(p.gy + 0.8, p.m.position.y + p.vy * dt);
        p.m.position.z += p.vz * dt;
        p.m.rotation.x += dt * 8; p.m.rotation.y += dt * 6;
        if (p.m.position.y <= p.gy + 0.8) { p.vx *= 0.9; p.vz *= 0.9; }
      } else {
        p.m.position.y += dt * 2;
        p.m.scale.multiplyScalar(1 + dt * 0.5);
        p.m.material.opacity = 0.55 * k;
      }
      if (p.t <= 0) {
        scene.remove(p.m);
        if (p.kind !== 'debris') p.m.material.dispose();
        if (p.kind === 'ring' || p.kind === 'scorch') p.m.geometry.dispose();
        parts.splice(i, 1);
      }
    }
  }

  return { update, explode };
}
