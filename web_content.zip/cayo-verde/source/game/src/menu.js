// menu.js — revision 3 pause menu (Esc or P). The world freezes while it
// is open. Tabs:
//  STATS     career stats (saved with the game) + progress
//  SETTINGS  master / radio volume, glow, shadows, camera shake, speed FOV
//  CONTROLS  key list
// Buttons: Resume, Save game, Open map.

import { RAMPS } from './places.js';

const CSS = `
#pause { position: fixed; inset: 0; z-index: 60; display: none; pointer-events: auto; backdrop-filter: blur(6px);
  background: radial-gradient(ellipse at 30% 40%, rgba(60,20,70,0.78), rgba(8,6,14,0.92));
  font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif; color: #fff; }
#pause.show { display: flex; }
#pause .side { width: 300px; padding: 48px 32px; display: flex; flex-direction: column; gap: 8px; }
#pause .logo { font-family: Impact, "Arial Black", sans-serif; font-size: 36px; white-space: nowrap; color: #ff7ad9; letter-spacing: 2px;
  text-shadow: 0 3px 0 #7c2d6e; line-height: 1; }
#pause .logo small { display: block; font-family: inherit; font-size: 13px; letter-spacing: 6px; color: #ffd9ec; margin: 6px 0 28px; }
#pause .tab, #pause .btn { text-align: left; background: rgba(255,255,255,0.06); border: 0; color: #fff; font: inherit;
  font-weight: 800; font-size: 16px; letter-spacing: 1px; padding: 12px 16px; border-radius: 8px; cursor: pointer; }
#pause .tab.on { background: #ffc12e; color: #1a1420; }
#pause .btn { background: transparent; border: 1px solid rgba(255,255,255,0.25); margin-top: 4px; }
#pause .btn:hover, #pause .tab:hover { filter: brightness(1.15); }
#pause .main { flex: 1; padding: 56px 48px; overflow: auto; }
#pause h2 { margin: 0 0 18px; font-size: 26px; letter-spacing: 1px; }
#pause .grid { display: grid; grid-template-columns: repeat(3, minmax(180px, 1fr)); gap: 12px; max-width: 860px; }
#pause .stat { background: rgba(20,18,30,0.75); border-radius: 10px; padding: 14px 16px; border-left: 4px solid #ffc12e; }
#pause .stat b { display: block; font-size: 26px; font-family: Impact, "Arial Black", sans-serif; letter-spacing: 0.5px; }
#pause .stat span { font-size: 11px; letter-spacing: 1.5px; color: #c9c3d6; font-weight: 800; }
#pause .row { display: flex; align-items: center; gap: 18px; max-width: 620px; padding: 12px 0;
  border-bottom: 1px solid rgba(255,255,255,0.08); font-weight: 700; }
#pause .row label { flex: 1; }
#pause input[type=range] { width: 260px; accent-color: #ffc12e; }
#pause .tog { width: 58px; height: 28px; border-radius: 14px; background: #444; position: relative; cursor: pointer; border: 0; }
#pause .tog::after { content: ''; position: absolute; left: 4px; top: 4px; width: 20px; height: 20px; border-radius: 50%;
  background: #fff; transition: left 0.15s; }
#pause .tog.on { background: #4be3a0; } #pause .tog.on::after { left: 34px; }
#pause .keys div { padding: 7px 0; font-size: 15px; }
#pause kbd { display: inline-block; min-width: 22px; text-align: center; background: rgba(255,255,255,0.14);
  border-radius: 5px; padding: 1px 8px; margin-right: 10px; font-family: inherit; font-weight: 800; }
#pause .note { margin-top: 18px; font-size: 12px; color: #a9a3b6; }
`;

export function createMenu({ state, player, settings, audio, maps, missions, isBlocked }) {
  const style = document.createElement('style');
  style.textContent = CSS;
  document.head.appendChild(style);
  const el = document.createElement('div');
  el.id = 'pause';
  el.innerHTML = `<div class="side">
      <div class="logo">CAYO VERDE<small>PAUSED</small></div>
      <button class="tab on" data-t="stats">STATS</button>
      <button class="tab" data-t="settings">SETTINGS</button>
      <button class="tab" data-t="controls">CONTROLS</button>
      <div style="flex:1"></div>
      <button class="btn" data-a="resume">▶ RESUME</button>
      <button class="btn" data-a="save">SAVE GAME</button>
      <button class="btn" data-a="map">OPEN MAP</button>
    </div><div class="main"></div>`;
  document.body.appendChild(el);
  const main = el.querySelector('.main');
  let tab = 'stats';
  let open = false;

  const fmtTime = (s) => `${Math.floor(s / 3600)}h ${String(Math.floor((s % 3600) / 60)).padStart(2, '0')}m`;
  function render() {
    el.querySelectorAll('.tab').forEach((b) => b.classList.toggle('on', b.dataset.t === tab));
    const st = state.stats;
    if (tab === 'stats') {
      const ri = state.rankInfo;
      const items = [
        ['RESPECT RANK', `${ri.rank} · ${ri.name}`], ['STORY JOBS', `${Math.min(state.missionIndex, missions.chainLength)} / ${missions.chainLength}`],
        ['TIME PLAYED', fmtTime(st.playTime)], ['CASH EARNED', `$${Math.round(st.cashEarned).toLocaleString('en-US')}`],
        ['CARS STOLEN', st.carsStolen], ['DISTANCE DRIVEN', `${(st.distance / 1000).toFixed(1)} km`],
        ['COPS TAKEN DOWN', st.copsDown], ['HIGHEST WANTED', '★'.repeat(st.maxWanted) || '—'],
        ['SHOTS FIRED', st.shotsFired], ['EXPLOSIONS', st.explosions],
        ['STUNT JUMPS', `${state.stunts.length} / ${RAMPS.length}`], ['STREET CRIMES STOPPED', st.crimesStopped],
        ['WASTED', st.deaths], ['BUSTED', st.busts], ['DAY', state.day],
      ];
      main.innerHTML = `<h2>Career</h2><div class="grid">${items.map(([k, v]) => `<div class="stat"><b>${v}</b><span>${k}</span></div>`).join('')}</div>`;
    } else if (tab === 'settings') {
      const tog = (k, label) => `<div class="row"><label>${label}</label><button class="tog ${settings.get(k) ? 'on' : ''}" data-k="${k}"></button></div>`;
      const sl = (k, label) => `<div class="row"><label>${label}</label><input type="range" min="0" max="100" value="${Math.round(settings.get(k) * 100)}" data-k="${k}"></div>`;
      main.innerHTML = `<h2>Settings</h2>${sl('master', 'Master volume')}${sl('music', 'Radio volume')}
        ${tog('bloom', 'Glow &amp; colour grade (turn off on slow PCs)')}${tog('shadows', 'Sun shadows')}
        ${tog('shake', 'Camera shake')}${tog('speedFov', 'Speed field of view')}
        ${tog('adaptiveRes', 'Adaptive resolution (keeps the frame rate smooth)')}${tog('showFps', 'Show FPS counter')}
        <div class="note">Settings are remembered on this browser.</div>`;
      main.querySelectorAll('.tog').forEach((b) => b.addEventListener('click', () => {
        settings.set(b.dataset.k, !settings.get(b.dataset.k));
        render();
      }));
      main.querySelectorAll('input[type=range]').forEach((r) => r.addEventListener('input', () => {
        settings.set(r.dataset.k, r.value / 100);
      }));
    } else {
      main.innerHTML = `<h2>Controls</h2><div class="keys">
        <div><kbd>W A S D</kbd>move · drive (W gas, S brake / reverse, A D steer)</div>
        <div><kbd>Shift</kbd>sprint on foot · <b>nitro</b> in a car</div>
        <div><kbd>Space</kbd>jump · handbrake in a car</div>
        <div><kbd>E</kbd>steal / enter / exit cars · bike · shops · Rico's garage</div>
        <div><kbd>F</kbd>punch / shoot (hold for SMG + rifle) · <b>drive-by</b> with pistol or SMG</div>
        <div><kbd>1-5</kbd>weapons · <kbd>Q</kbd>next weapon · <kbd>R</kbd>reload</div>
        <div><kbd>T</kbd>radio station · <kbd>V</kbd>sound on / off</div>
        <div><kbd>M</kbd>map · <kbd>K</kbd>save · <kbd>Esc</kbd>/<kbd>P</kbd>pause · <kbd>O</kbd>free camera · <kbd>H</kbd>controls</div>
        <div><kbd>Mouse</kbd>drag to look · wheel to zoom · click to shoot</div></div>`;
    }
  }

  function setOpen(v) {
    open = v;
    el.classList.toggle('show', open);
    if (open) { render(); state.emit('pause', true); } else state.emit('pause', false);
  }
  el.querySelectorAll('.tab').forEach((b) => b.addEventListener('click', () => { tab = b.dataset.t; render(); }));
  el.querySelector('[data-a=resume]').addEventListener('click', () => setOpen(false));
  el.querySelector('[data-a=save]').addEventListener('click', () => { state.save(player); setOpen(false); });
  el.querySelector('[data-a=map]').addEventListener('click', () => { setOpen(false); maps.toggleFullMap(true); });

  window.addEventListener('keydown', (e) => {
    const k = e.key.toLowerCase();
    if (k === 'p' || k === 'escape') {
      if (open) { setOpen(false); e.preventDefault(); return; }
      if (k === 'escape' && isBlocked()) return; // Esc closes the map / shop first
      if (isBlocked()) return;
      setOpen(true);
      e.preventDefault();
    }
  }, true); // capture: decide before the map / shop handlers close themselves
  // Auto-pause when the tab loses focus.
  document.addEventListener('visibilitychange', () => { if (document.hidden && !open && !isBlocked()) setOpen(true); });

  // Apply audio settings.
  const applyAudio = () => audio.setVolumes && audio.setVolumes(settings.get('master'), settings.get('music'));
  settings.on((k) => { if (k === 'master' || k === 'music') applyAudio(); });
  applyAudio();

  return { get open() { return open; }, setOpen };
}
