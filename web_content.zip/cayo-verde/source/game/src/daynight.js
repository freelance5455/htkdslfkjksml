// daynight.js — G5: day/night cycle. One game minute per real second
// (a full day = 24 minutes). The clock lives in state.clock (minutes
// since midnight) so it is saved with the game.
//  * Sky colour blends night navy -> dawn peach -> day blue -> dusk peach.
//  * The sun swings across the sky (rises 06:00, sets 19:00); at night a
//    dim blue moonlight takes over the same light.
//  * Street lamps: emissive heads switch on at dusk, warm light pools
//    appear under every lamp, and a handful of real point lights follow
//    the player's nearest lamps. Building windows glow at night.

import * as THREE from 'three';
import { LAYOUT } from './layout.js';
import { LAMP_HEADS } from './roads.js';
import { windowMaterial, NEON } from './buildings.js';

export const MIN_PER_SEC = 1;
const SUNRISE = 6 * 60;
const SUNSET = 19 * 60;
const POINT_LIGHTS = 4;

const C = {
  night: new THREE.Color(LAYOUT.palette.skyNight),
  dusk: new THREE.Color(LAYOUT.palette.skyDusk),
  day: new THREE.Color(LAYOUT.palette.skyDay),
};
const SUN_DAY = new THREE.Color(0xfff2dd);
const SUN_LOW = new THREE.Color(0xffb070);
const MOON = new THREE.Color(0x8aa2ff);

const smooth = (a, b, x) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};

// 0 = full day, 1 = full night (lamps on from ~18:45 to ~06:15).
export function nightFactor(clock) {
  const m = ((clock % 1440) + 1440) % 1440;
  return Math.max(1 - smooth(SUNRISE - 30, SUNRISE + 30, m), smooth(SUNSET - 30, SUNSET + 45, m));
}

export function createDayNight(scene, { state, sun, hemi, roads }) {
  const lampMat = roads.userData.lampHeadMat;
  const winMat = windowMaterial();
  winMat.emissive = new THREE.Color(0xffc870);

  // Light pools: one instanced additive disc under each lamp head.
  const poolGeo = new THREE.CircleGeometry(4.2, 20);
  poolGeo.rotateX(-Math.PI / 2);
  // Soft radial falloff so the pools fade out instead of hard discs.
  const pc = document.createElement('canvas');
  pc.width = pc.height = 64;
  const pg = pc.getContext('2d');
  const grad = pg.createRadialGradient(32, 32, 0, 32, 32, 32);
  grad.addColorStop(0, 'rgba(255,255,255,1)');
  grad.addColorStop(0.5, 'rgba(255,255,255,0.45)');
  grad.addColorStop(1, 'rgba(255,255,255,0)');
  pg.fillStyle = grad;
  pg.fillRect(0, 0, 64, 64);
  const poolTex = new THREE.CanvasTexture(pc);
  const poolMat = new THREE.MeshBasicMaterial({
    map: poolTex,
    color: 0xffd9a0, transparent: true, opacity: 0, depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const pools = new THREE.InstancedMesh(poolGeo, poolMat, LAMP_HEADS.length);
  const mtx = new THREE.Matrix4();
  LAMP_HEADS.forEach(([x, , z], i) => {
    mtx.makeTranslation(x, 0.83, z);
    pools.setMatrixAt(i, mtx);
  });
  pools.renderOrder = 2;
  scene.add(pools);

  // Real point lights, re-assigned to the lamps nearest the player.
  const lights = [];
  for (let i = 0; i < POINT_LIGHTS; i++) {
    const l = new THREE.PointLight(0xffc06a, 0, 16, 1.6);
    scene.add(l);
    lights.push(l);
  }
  let reassign = 0;
  // Revision 3: city-glow ambient after dark so streets and people stay
  // readable at night (moonlight alone left the asphalt pitch black).
  const cityGlow = new THREE.AmbientLight(0x8090d0, 0);
  scene.add(cityGlow);

  // Revision 2: gradient sky dome (zenith colour -> warm horizon band) with
  // a soft sun glow + disc. It follows the camera; weather.js tints it via
  // syncSky() after it has greyed scene.background.
  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: {
      top: { value: new THREE.Color() }, horizon: { value: new THREE.Color() },
      sunDir: { value: new THREE.Vector3(0, 1, 0) }, sunCol: { value: new THREE.Color(0xffe2b0) },
      sunAmt: { value: 1 },
    },
    vertexShader: `varying vec3 vDir; void main() { vDir = normalize(position);
      vec4 p = modelViewMatrix * vec4(position, 1.0); gl_Position = projectionMatrix * p; }`,
    fragmentShader: `uniform vec3 top; uniform vec3 horizon; uniform vec3 sunDir; uniform vec3 sunCol; uniform float sunAmt;
      varying vec3 vDir;
      void main() {
        vec3 d = normalize(vDir);
        float h = clamp(d.y, 0.0, 1.0);
        vec3 col = mix(horizon, top, pow(h, 0.55));
        if (d.y < 0.0) col = horizon * (1.0 + d.y * 0.4);
        float s = max(dot(d, normalize(sunDir)), 0.0);
        col += sunCol * (pow(s, 8.0) * 0.35 + pow(s, 64.0) * 0.6) * sunAmt;
        col = mix(col, sunCol * 1.25, smoothstep(0.9993, 0.9997, s) * sunAmt);
        gl_FragColor = vec4(col, 1.0);
        #include <colorspace_fragment>
      }`,
  });
  const sky = new THREE.Mesh(new THREE.SphereGeometry(700, 32, 16), skyMat);
  sky.renderOrder = -10;
  sky.frustumCulled = false;
  scene.add(sky);
  const H = {
    day: new THREE.Color(0xd8ecf8), dusk: new THREE.Color(0xffa36b), night: new THREE.Color(0x2c3868),
  };
  const horizonNow = new THREE.Color();
  // Revision 4: the sun's shadow box follows the player (180 m instead of
  // 480 m: 2.7x sharper shadows, and only nearby casters are drawn). The
  // centre snaps to whole shadow texels in light space so edges never
  // shimmer while you move.
  const sunOff = new THREE.Vector3(-180, 70, 60);
  const SH = 90;
  sun.shadow.camera.left = -SH; sun.shadow.camera.right = SH;
  sun.shadow.camera.top = SH; sun.shadow.camera.bottom = -SH;
  sun.shadow.camera.far = 500;
  sun.shadow.camera.updateProjectionMatrix();
  const _f = new THREE.Vector3();
  const _r = new THREE.Vector3();
  const _u = new THREE.Vector3();
  const _c = new THREE.Vector3();
  function placeSun(p) {
    const texel = (2 * SH) / sun.shadow.mapSize.x;
    _f.copy(sunOff).normalize().negate();
    _r.crossVectors(_f, new THREE.Vector3(0, 1, 0)).normalize();
    _u.crossVectors(_r, _f).normalize();
    _c.set(p.x, 0, p.z);
    const a = Math.round(_c.dot(_r) / texel) * texel;
    const b = Math.round(_c.dot(_u) / texel) * texel;
    const d = _c.dot(_f);
    _c.copy(_r).multiplyScalar(a).addScaledVector(_u, b).addScaledVector(_f, d);
    sun.target.position.copy(_c);
    sun.position.copy(_c).add(sunOff);
    sun.target.updateMatrixWorld();
  }
  function syncSky(camera, cloud = 0) {
    sky.position.copy(camera.position);
    const bg = scene.background;
    skyMat.uniforms.top.value.copy(bg).multiplyScalar(0.92);
    skyMat.uniforms.horizon.value.copy(horizonNow).lerp(bg.clone().multiplyScalar(1.15), cloud * 0.8);
    skyMat.uniforms.sunDir.value.copy(sunOff).normalize();
    skyMat.uniforms.sunCol.value.copy(sun.color);
    const n = nightFactor(state.clock);
    skyMat.uniforms.sunAmt.value = (1 - n) * (1 - cloud * 0.9) * (sunOff.y > 0 ? 1 : 0);
  }

  function update(dt, playerPos) {
    state.clock += dt * MIN_PER_SEC;
    if (state.clock >= 1440) { state.clock -= 1440; state.day += 1; }
    const m = state.clock;
    const night = nightFactor(m);

    // Sky: day <-> dusk near sunrise/sunset, dusk <-> night after dark.
    const duskness = Math.max(
      1 - Math.min(1, Math.abs(m - SUNSET) / 70),
      1 - Math.min(1, Math.abs(m - SUNRISE) / 60),
    );
    const top = C.day.clone().lerp(new THREE.Color(0x6a7fd0), duskness * 0.8).lerp(C.night, night);
    scene.background = top;
    horizonNow.copy(H.day).lerp(H.dusk, duskness).lerp(H.night, night);

    // Sun arc: angle 0 at sunrise (east, +x), PI at sunset (west).
    const dayT = (m - SUNRISE) / (SUNSET - SUNRISE);
    if (dayT >= 0 && dayT <= 1) {
      const a = dayT * Math.PI;
      sunOff.set(Math.cos(a) * 200, Math.max(25, Math.sin(a) * 220), 70);
      const low = 1 - Math.sin(a);
      sun.color.copy(SUN_DAY).lerp(SUN_LOW, Math.min(1, low * 1.4));
      sun.intensity = 0.5 + 1.4 * Math.sin(a) * (1 - night);
    } else {
      sunOff.set(-120, 160, -80);
      sun.color.copy(MOON);
      sun.intensity = 0.55;
    }
    if (playerPos) placeSun(playerPos);
    hemi.intensity = 0.9 - night * 0.22;
    // Golden hour: warm pink-orange fill around sunrise / sunset.
    hemi.color.set(0xffd9c0).lerp(new THREE.Color(0xff9a7a), duskness * 0.75).lerp(new THREE.Color(0x8a9ae0), night);
    hemi.intensity += duskness * (1 - night) * 0.25;

    cityGlow.intensity = night * 0.9;
    lampMat.emissiveIntensity = 0.15 + night * 2.6;
    poolMat.opacity = night * 0.32;
    winMat.emissiveIntensity = night * 0.55;
    // Neon: off by day, glowing at dusk/night; flicker signs buzz now and then.
    const tt = performance.now() / 1000;
    const glow = Math.max(0, night * 1.15 - 0.1);
    for (const n of NEON) {
      let k = glow * n.night;
      if (n.flicker && glow > 0) {
        const ph = (tt + n.seed) % 7;
        if (ph < 0.35) k *= (Math.sin(ph * 90) > 0 ? 1 : 0.15);
      }
      n.mat.emissiveIntensity = k;
    }

    // Nearest lamps get real point lights at night.
    reassign -= dt;
    if (reassign <= 0 && playerPos) {
      reassign = 0.5;
      const sorted = LAMP_HEADS
        .map((h) => [h, Math.hypot(h[0] - playerPos.x, h[2] - playerPos.z)])
        .sort((a, b) => a[1] - b[1]);
      lights.forEach((l, i) => {
        const h = sorted[i] ? sorted[i][0] : null;
        if (h) l.position.set(h[0], h[1] - 0.4, h[2]);
      });
    }
    for (const l of lights) l.intensity = night * 22;
  }

  return {
    update,
    syncSky,
    get night() { return nightFactor(state.clock); },
    lampCount: LAMP_HEADS.length,
  };
}

export function clockText(clock) {
  const m = Math.floor(((clock % 1440) + 1440) % 1440);
  return `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
}
