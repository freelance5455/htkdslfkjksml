// missions.js — story jobs + HUD mission card (revision 2).
// Four contacts give 12 story jobs, each with dialogue (portrait box on
// the HUD), stages (stage bar + NEXT line) and cash + respect rewards.
// Walk/drive into the yellow marker to start. Passing pays out, awards
// XP and auto-saves. BUSTED / WASTED / timers / job-specific failures
// fail the job; its marker comes back so it can be retried. After the
// story, endless courier jobs with rising pay.
//
// Step kinds: goto, ride, wanted, clear, pistol, targets (bottles),
// collect (cash bundles), tail (follow a taxi), brawl (fists gang),
// shootout (armed gang), steal (take a specific car), deliver (bring that
// car to a point), wreck (destroy the gang van), survive (hold a wanted
// level).

import * as THREE from 'three';
import { SPOTS, PISTOL_CRATE } from './places.js';
import { groundHeightAt, BOXES, LAKE_BOX, pushOut } from './player.js';
import { buildCharacter } from './characters.js';
import { lineOfSight } from './police.js';

const MARK_R = 2.5;

// ---------------------------------------------------------------- contacts
// Portrait colours drive the pixel portraits drawn by hud.js.
export const CONTACTS = {
  lu: { name: 'Mama Lu', role: 'PIZZERIA · FIXER', skin: '#c98f62', hair: '#d9d2c5', hairStyle: 'bun', shirt: '#e74c3c', accent: '#ffd21a' },
  rico: { name: 'Rico', role: 'MECHANIC · ARMS', skin: '#8d5b3a', hair: '#141414', hairStyle: 'buzz', shirt: '#2c3e50', accent: '#e67e22' },
  dani: { name: 'Dani', role: 'STREET RACER', skin: '#f1c7a1', hair: '#e84393', hairStyle: 'bob', shirt: '#00d2d3', accent: '#00d2d3' },
  sofia: { name: 'Sofia', role: 'SMUGGLER', skin: '#e2b08a', hair: '#2a1a10', hairStyle: 'long', shirt: '#8e44ad', accent: '#c39bd3' },
};

// say: { at: 'start' | step index | 'pass', lines: [[who, text], ...] }
const CHAIN = [
  {
    id: 'pizza-run', title: 'Pizza Run', who: 'lu', start: SPOTS.pizzaDoor, reward: 150, xp: 60,
    steps: [{ kind: 'goto', at: SPOTS.pier, text: 'Deliver the pizza to Vice Pier', time: 120 }],
    say: {
      start: [['lu', 'You the new kid? My driver quit. Pizza to Vice Pier, still hot, two minutes.'],
        ['lu', 'Take the bike if you want — just bring it back in one piece.']],
      pass: [['lu', 'Customer tipped! Come back, Mama Lu always has work.']],
    },
  },
  {
    id: 'armed', title: 'Armed & Dangerous', who: 'rico', start: SPOTS.shootingRange, reward: 200, xp: 80,
    steps: [
      { kind: 'pistol', text: 'Get a pistol (free crate in Downtown, or AMMU-NATION)' },
      { kind: 'goto', at: SPOTS.shootingRange, text: 'Go back to the warehouse yard' },
      { kind: 'targets', spots: SPOTS.bottles, time: 60, text: 'Shoot the bottles' },
    ],
    say: {
      start: [['rico', 'Lu says you can drive. Can you shoot? Get yourself a piece and come back.']],
      2: [['rico', 'Five bottles, sixty seconds. Breathe out, then squeeze.']],
      pass: [['rico', 'Not bad. My garage is open to you — paint, engine, armour. Cash only.']],
    },
  },
  {
    id: 'checkpoint-rush', title: 'Checkpoint Rush', who: 'dani', start: SPOTS.roundaboutEast, reward: 250, xp: 90,
    steps: [
      { kind: 'ride', text: 'Get on a vehicle (bike or car)' },
      { kind: 'goto', at: [0, -40], text: 'Checkpoint 1/6', time: 60, race: true },
      { kind: 'goto', at: [0, -60], text: 'Checkpoint 2/6', race: true },
      { kind: 'goto', at: [60, -60], text: 'Checkpoint 3/6', race: true },
      { kind: 'goto', at: [60, 60], text: 'Checkpoint 4/6', race: true },
      { kind: 'goto', at: [0, 60], text: 'Checkpoint 5/6', race: true },
      { kind: 'goto', at: [0, 24], text: 'Checkpoint 6/6 — finish', race: true },
    ],
    say: {
      start: [['dani', 'Heard you can drive. Six checkpoints around Downtown. Beat my time.']],
      1: [['dani', 'GO GO GO!']],
      pass: [['dani', 'Okay... you are fast. Maybe I have bigger jobs for you.']],
    },
  },
  {
    id: 'cash-grab', title: 'Cash Grab', who: 'lu', start: SPOTS.parkGate, reward: 300, xp: 90,
    steps: [{ kind: 'collect', spots: SPOTS.parkCash, time: 75, text: 'Collect the cash bundles' }],
    say: {
      start: [['lu', 'My courier dropped a bag in Central Park. Six bundles. Get them before the joggers do.']],
      pass: [['lu', 'All of it? Good. You keep a little for your trouble.']],
    },
  },
  {
    id: 'joyride', title: 'Joyride', who: 'dani', start: SPOTS.roundaboutEast, reward: 400, xp: 110,
    steps: [
      { kind: 'steal', type: 'sports', text: 'Steal the Relampago GT' },
      { kind: 'deliver', at: SPOTS.garage, text: "Bring it to Rico's Paint & Tune", time: 150 },
    ],
    say: {
      start: [['dani', 'A rich kid parks his Relampago GT around here. Borrow it. Rico wants to look under the hood.']],
      1: [['dani', 'Nice! Now get it to Rico — scratches come out of your cut.']],
      pass: [['rico', 'Beautiful machine. Bring any ride here for paint, tune or armour.']],
    },
  },
  {
    id: 'heat-wave', title: 'Heat Wave', who: 'sofia', start: SPOTS.parkGate, reward: 400, xp: 120,
    steps: [
      { kind: 'wanted', stars: 2, text: 'Get a 2-star wanted level' },
      { kind: 'clear', text: 'Lose the cops — break line of sight' },
    ],
    say: {
      start: [['sofia', 'I need someone who keeps their head with the cops on them. Make some noise. Then vanish.']],
      1: [['sofia', 'Now get out of sight. They only search where they last saw you.']],
      pass: [['sofia', 'Cool under pressure. I like that.']],
    },
  },
  {
    id: 'tail-taxi', title: 'Tail the Taxi', who: 'sofia', start: SPOTS.roundaboutEast, reward: 350, xp: 120,
    steps: [{ kind: 'tail', secs: 50, max: 65, min: 7, text: 'Follow the taxi' }],
    say: {
      start: [['sofia', 'A snitch just got in a Verde Cab. Follow him. Not too close — he knows faces.']],
      pass: [['sofia', 'He went to the docks. That tells me everything.']],
    },
  },
  {
    id: 'street-brawl', title: 'Street Brawl', who: 'rico', start: SPOTS.brawlStart, reward: 450, xp: 140,
    steps: [{ kind: 'brawl', spawns: SPOTS.brawlThugs, text: 'Beat up the Red Bandanas' }],
    say: {
      start: [['rico', 'The Red Bandanas are squeezing the warehouses. No guns — send a message.']],
      pass: [['rico', 'They will think twice. Watch your back though.']],
    },
  },
  {
    id: 'airport-courier', title: 'Airport Courier', who: 'sofia', start: SPOTS.terminal, reward: 350, xp: 130,
    steps: [{ kind: 'goto', at: SPOTS.portDocks, text: 'Deliver the package to the Port Docks', time: 150 }],
    say: {
      start: [['sofia', 'Package off the last flight. Port Docks, two and a half minutes. Do not open it.']],
      pass: [['sofia', 'Clean delivery. The Bandanas are moving on the docks though...']],
    },
  },
  {
    id: 'dockside', title: 'Dockside Shootout', who: 'rico', start: SPOTS.dockStart, reward: 700, xp: 180,
    steps: [{ kind: 'shootout', spawns: SPOTS.dockGunmen, text: 'Clear the Red Bandanas from the docks' }],
    say: {
      start: [['rico', 'They took the docks and they are armed. Bring something bigger than fists.'],
        ['rico', 'Use the containers for cover. Go!']],
      pass: [['rico', 'Docks are ours again. You are a real soldier now.']],
    },
  },
  {
    id: 'wreck-van', title: 'Wreck the Van', who: 'dani', start: SPOTS.pizzaDoor, reward: 600, xp: 170,
    steps: [
      { kind: 'wreck', text: 'Destroy the purple gang van' },
      { kind: 'clear', text: 'Lose the cops' },
    ],
    say: {
      start: [['dani', 'The Bandanas move their stash in a purple Mula Van. Shoot it until it blows.']],
      1: [['dani', 'BOOM! Now get lost before the cops connect the dots.']],
      pass: [['dani', 'That was beautiful. Sofia wants to see you.']],
    },
  },
  {
    id: 'most-wanted', title: 'Most Wanted', who: 'sofia', start: SPOTS.terminal, reward: 1500, xp: 300,
    steps: [
      { kind: 'wanted', stars: 4, text: 'Get a 4-star wanted level' },
      { kind: 'survive', secs: 45, stars: 3, text: 'Survive the manhunt' },
      { kind: 'clear', text: 'Shake the chopper and lose the cops' },
      { kind: 'goto', at: SPOTS.pier, text: 'Reach my boat at Vice Pier' },
    ],
    say: {
      start: [['sofia', 'Last job. I need the whole PD looking one way while my boat leaves the other.'],
        ['sofia', 'Four stars. Then survive, then disappear, then meet me at the pier.']],
      1: [['sofia', 'They are all on you. Keep moving — roadblocks on the boulevards!']],
      2: [['sofia', 'Now break line of sight. Lose that chopper!']],
      3: [['sofia', 'Clean. Pier. Now.']],
      pass: [['sofia', 'You did it. Cayo Verde is yours, legend.']],
    },
  },
];

const COURIER_SPOTS = [
  ['Vice Pier', SPOTS.pier], ['the Port Docks', SPOTS.portDocks],
  ['the Airport Terminal', SPOTS.terminal], ['PIZZA', SPOTS.pizzaDoor],
  ['the park gate', SPOTS.parkGate], ['the roundabout', SPOTS.roundaboutEast],
];
function courierJob(n) {
  const a = COURIER_SPOTS[(n * 7) % COURIER_SPOTS.length];
  let b = COURIER_SPOTS[(n * 3 + 2) % COURIER_SPOTS.length];
  if (b === a) b = COURIER_SPOTS[(n * 3 + 3) % COURIER_SPOTS.length];
  const dist = Math.hypot(a[1][0] - b[1][0], a[1][1] - b[1][1]);
  return {
    id: `courier-${n}`, title: `Courier Job #${n + 1}`, who: 'lu', start: a[1], reward: 150 + 50 * n, xp: 50,
    steps: [{ kind: 'goto', at: b[1], text: `Deliver the parcel to ${b[0]}`, time: Math.round(30 + dist / 3.5) }],
    say: { start: [['lu', `Parcel for ${b[0]}. Quick, quick.`]] },
  };
}
export function missionAt(index) {
  return index < CHAIN.length ? CHAIN[index] : courierJob(index - CHAIN.length);
}
export const CHAIN_LENGTH = CHAIN.length;

export function createMissions(scene, { state, player, combat, traffic }) {
  function column(color) {
    const g = new THREE.Group();
    const cyl = new THREE.Mesh(new THREE.CylinderGeometry(MARK_R * 0.7, MARK_R * 0.7, 2.4, 20, 1, true),
      new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.35, side: THREE.DoubleSide, depthWrite: false }));
    cyl.position.y = 1.2;
    g.add(cyl);
    const ring = new THREE.Mesh(new THREE.RingGeometry(MARK_R * 0.6, MARK_R * 0.75, 28),
      new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.9, side: THREE.DoubleSide }));
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.04;
    g.add(ring);
    const arrow = new THREE.Mesh(new THREE.ConeGeometry(0.35, 0.7, 4),
      new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.7 }));
    arrow.rotation.x = Math.PI;
    arrow.position.y = 3.4;
    g.add(arrow);
    g.visible = false;
    scene.add(g);
    return { g, cyl, ring, arrow };
  }
  const startMark = column(0xffd21a);
  const goalMark = column(0xffd21a);
  const overArrow = new THREE.Mesh(new THREE.ConeGeometry(0.5, 1.0, 4),
    new THREE.MeshStandardMaterial({ color: 0xff3b3b, emissive: 0xff3b3b, emissiveIntensity: 0.8 }));
  overArrow.rotation.x = Math.PI;
  overArrow.visible = false;
  scene.add(overArrow);

  let active = null;
  let failCooldown = 0;
  const current = () => missionAt(state.missionIndex);

  function place(mark, at) {
    mark.g.position.set(at[0], groundHeightAt(at[0], at[1]), at[1]);
    mark.g.visible = true;
  }
  function colorMark(mark, c) {
    mark.cyl.material.color.set(c);
    mark.ring.material.color.set(c);
    mark.arrow.material.color.set(c);
    mark.arrow.material.emissive.set(c);
  }
  function say(m, key) {
    const lines = m.say && m.say[key];
    if (lines) state.emit('dialogue', { lines: lines.map(([who, text]) => ({ who, text, ...CONTACTS[who] })) });
  }

  // ---------------------------------------------------- live chatter
  // Revision 5: the contact talks DURING the job, reacting to what
  // happens (enemies down, time running out, cops, low health, a crash).
  // One line at most every 6 s; each trigger fires once per step.
  const CHAT = {
    down: [
      (n) => (n === 1 ? 'One left! Finish it!' : `${n} left — keep pushing!`),
      (n) => (n === 1 ? 'Last one, make it count.' : `Good hit! ${n} to go.`),
      (n) => (n === 1 ? "Just one more and we're clear." : `They're breaking — ${n} still standing.`),
    ],
    lowTime: ['Clock is ticking — move it!', 'Thirty seconds! Floor it!', "We're running out of time!"],
    cops: ['Cops on you! Lose them or this falls apart.', 'Heat incoming — watch your back!', 'Sirens! Keep your head down.'],
    lowHp: ["You're bleeding out there — grab cover!", 'Careful, you look rough. Pharmacy after this.', "Don't die on me now!"],
    crash: ['Easy on the paint!', 'Whoa — eyes on the road!', 'You drive like my grandmother. Faster!'],
    close: ['Almost there!', 'Nearly done, keep going.', 'I can see you on the map — close!'],
  };
  let chatCd = 0;
  let chatFired = new Set();
  let lastDown = -1;
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  function chat(key, text, force = false) {
    if (!active) return;
    if (!force && (chatCd > 0 || chatFired.has(key))) return;
    chatFired.add(key);
    chatCd = 6;
    const who = active.m.who;
    state.emit('dialogue', { lines: [{ who, text, ...CONTACTS[who] }] });
  }
  state.on((type, d) => {
    if (!active) return;
    if (type === 'wanted' && state.wanted > d.before && d.why !== 'clear') {
      const st = active.m.steps[active.step];
      if (st.kind !== 'wanted' && st.kind !== 'survive') chat('cops', pick(CHAT.cops));
    }
    if (type === 'crash' && (d.speed || 0) > 10) chat(`crash${Math.floor(state.time / 20)}`, pick(CHAT.crash));
    if (type === 'hurt' && state.hp < 35) chat('lowhp', pick(CHAT.lowHp));
  });
  function chatterStep(dt) {
    chatCd -= dt;
    const st = active.m.steps[active.step];
    if (active.timer !== null && active.timer < 30 && active.timer > 25) chat('lowtime', pick(CHAT.lowTime));
    if (st.kind === 'brawl' || st.kind === 'shootout' || st.kind === 'targets' || st.kind === 'collect') {
      const left = active.ents.filter((e) => e.alive).length;
      if (lastDown !== -1 && left < lastDown && left > 0) chat(`down${left}`, pick(CHAT.down)(left), true);
      lastDown = left;
    } else lastDown = -1;
    if ((st.kind === 'goto' || st.kind === 'deliver') && !st.race) {
      const pp = player.position;
      const d0 = Math.hypot(pp.x - st.at[0], pp.z - st.at[1]);
      if (d0 < 40 && d0 > 10) chat('close', pick(CHAT.close));
    }
  }

  // ---------------------------------------------------- mission entities
  const bottleGlass = new THREE.MeshStandardMaterial({ color: 0x3fae5a, roughness: 0.2, metalness: 0.1, emissive: 0x0f3f1a, emissiveIntensity: 0.6 });
  const postMat = new THREE.MeshStandardMaterial({ color: 0x7a5a3a, flatShading: true });
  function makeBottle(x, z) {
    const g = new THREE.Group();
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 1.1, 6), postMat);
    post.position.y = 0.55;
    const b = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.11, 0.32, 8), bottleGlass);
    b.position.y = 1.26;
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.05, 0.14, 6), bottleGlass);
    neck.position.y = 1.48;
    g.add(post, b, neck);
    g.position.set(x, groundHeightAt(x, z), z);
    scene.add(g);
    const ent = {
      kind: 'bottle', g, bottle: [b, neck], alive: true, p: g.position, r: 0.35,
      hit() {
        if (!ent.alive) return null;
        ent.alive = false;
        for (const m of ent.bottle) m.visible = false;
        state.emit('punchHit', { kind: 'bottle' });
        return 'dead';
      },
    };
    return ent;
  }
  const bundleMat = new THREE.MeshStandardMaterial({ color: 0x46d26a, emissive: 0x2fbf4f, emissiveIntensity: 0.9 });
  function makeBundle(x, z) {
    const g = new THREE.Group();
    const box = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.35, 0.45), bundleMat);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.7, 0.05, 6, 20), new THREE.MeshBasicMaterial({ color: 0x9cff9c }));
    ring.rotation.x = Math.PI / 2;
    ring.position.y = -0.5;
    g.add(box, ring);
    g.position.set(x, groundHeightAt(x, z) + 0.7, z);
    scene.add(g);
    return { kind: 'bundle', g, alive: true, x, z };
  }
  // Red Bandanas. armed = shoots from range, else chases and punches.
  const gunMat = new THREE.MeshStandardMaterial({ color: 0x222428, roughness: 0.5 });
  function makeThug(x, z, i, armed) {
    const c = buildCharacter({
      skin: ['#c98f62', '#8d5b3a', '#e2b08a'][i % 3], hair: 'cap', capColor: '#c0392b',
      hairColor: '#141414', eyes: 'sleepy', smirk: true,
      top: '#1d1d22', jacket: '#c0392b', bottom: '#2b3142', shoes: '#141414',
    });
    c.group.rotation.order = 'YXZ';
    if (armed) {
      const gun = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.3, 0.08), gunMat);
      gun.position.set(0, -0.76, 0.02);
      c.armR.add(gun);
    }
    c.group.position.set(x, groundHeightAt(x, z), z);
    scene.add(c.group);
    const ent = {
      kind: armed ? 'gunman' : 'thug', armed, g: c.group, parts: c, x, z, heading: 0, phase: 0, hp: 100,
      alive: true, fall: 0, attackCd: 1 + i * 0.5, p: c.group.position, r: 0.45, punchT: 0, aimT: 0,
      hit(amount, fx, fz) {
        if (!ent.alive) return null;
        ent.hp -= amount;
        ent.aggro = true;
        if (ent.hp <= 0) {
          ent.alive = false;
          ent.heading = Math.atan2(fx - ent.x, fz - ent.z);
          ent.g.rotation.y = ent.heading;
          return 'dead';
        }
        return 'hit';
      },
    };
    return ent;
  }
  function stepThug(t, dt) {
    if (!t.alive) {
      t.fall = Math.min(1, t.fall + dt / 0.35);
      t.g.rotation.x = -Math.PI / 2 * t.fall;
      return;
    }
    const pp = player.position;
    let dx = pp.x - t.x;
    let dz = pp.z - t.z;
    const d = Math.hypot(dx, dz) || 1;
    dx /= d; dz /= d;
    let sp = 0;
    if (t.armed) {
      // Keep 8-16 m, strafe a little, fire with line of sight.
      const sees = d < 40 && lineOfSight(t.x, t.z, pp.x, pp.z);
      if (d < 45) t.aggro = true;
      if (t.aggro) {
        if (d > 16 || !sees) sp = 3.6; else if (d < 8) sp = -2.5;
        t.attackCd -= dt;
        if (sees && d < 30 && t.attackCd <= 0 && !player.frozen) {
          t.attackCd = 1.1 + Math.random() * 0.9;
          t.aimT = 0.6;
          const hit = Math.random() < 0.3 - d * 0.004;
          state.emit('copShot', {
            from: [t.x, groundHeightAt(t.x, t.z) + 1.35, t.z],
            to: [pp.x + (hit ? 0 : (Math.random() - 0.5) * 2), pp.y + 1.2, pp.z + (hit ? 0 : (Math.random() - 0.5) * 2)],
          });
          if (hit) state.emit(player.driving ? 'policeHitCar' : 'playerShot', { damage: 6 });
        }
      }
    } else {
      sp = d > 1.2 ? 4.4 : 0;
      t.attackCd -= dt;
      if (d < 1.5 && t.attackCd <= 0 && !player.frozen) {
        t.attackCd = 1.1 + Math.random() * 0.5;
        t.punchT = 0.25;
        state.emit('punchHit', { kind: 'player' });
        state.emit('playerShot', { damage: 7 });
      }
    }
    const p = { x: t.x + dx * sp * dt, z: t.z + dz * sp * dt };
    pushOut(p, BOXES, LAKE_BOX);
    t.x = p.x; t.z = p.z;
    t.heading = Math.atan2(dx, dz);
    t.phase += dt * Math.abs(sp) * 2.4;
    const s = Math.sin(t.phase) * (sp ? 0.9 : 0);
    t.parts.armL.rotation.x = s;
    t.parts.armR.rotation.x = -s;
    t.parts.legL.rotation.x = -s;
    t.parts.legR.rotation.x = s;
    if (t.punchT > 0) { t.punchT -= dt; t.parts.armR.rotation.x = -1.5; }
    if (t.aimT > 0) { t.aimT -= dt; t.parts.armR.rotation.x = -Math.PI / 2; }
    if (t.armed && t.aggro && !t.punchT) t.parts.armR.rotation.x = -Math.PI / 2;
    t.g.position.set(t.x, groundHeightAt(t.x, t.z), t.z);
    t.g.rotation.y = t.heading;
  }

  function cleanup() {
    if (!active) return;
    for (const e of active.ents) if (e.g) scene.remove(e.g);
    active.ents = [];
    if (active.car) { active.car.tag = null; active.car = null; }
    overArrow.visible = false;
    goalMark.g.visible = false;
  }

  combat.addTargets(() => {
    if (!active) return [];
    return active.ents.filter((e) => e.alive && e.hit).map((e) => ({
      kind: 'extra', tkind: e.kind, p: e.p, r: e.r,
      hit: (amount, fx, fz, kind) => e.hit(amount, fx, fz, kind),
      melee: e.kind === 'thug' || e.kind === 'gunman',
    }));
  });

  // ---------------------------------------------------- lifecycle
  function start() {
    const m = current();
    active = { m, step: 0, timer: null, ents: [], data: {}, car: null };
    state.emit('mission', { type: 'start', title: m.title, who: m.who });
    say(m, 'start');
    enterStep();
  }
  function enterStep() {
    const st = active.m.steps[active.step];
    chatFired = new Set();
    lastDown = -1;
    active.timer = st.time || null;
    active.data = {};
    goalMark.g.visible = false;
    if (active.step > 0) say(active.m, active.step);
    if (st.kind === 'goto' || st.kind === 'deliver') {
      place(goalMark, st.at);
      colorMark(goalMark, st.race ? 0x3ad1ff : 0xffd21a);
    } else if (st.kind === 'targets') {
      active.ents.push(...st.spots.map(([x, z]) => makeBottle(x, z)));
    } else if (st.kind === 'collect') {
      active.ents.push(...st.spots.map(([x, z]) => makeBundle(x, z)));
    } else if (st.kind === 'brawl' || st.kind === 'shootout') {
      active.ents.push(...st.spawns.map(([x, z], i) => makeThug(x, z, i, st.kind === 'shootout')));
    } else if (st.kind === 'tail') {
      const car = traffic.spawnCar(true, 'taxi');
      car.tag = 'tail';
      car.cruise = 8.5;
      active.car = car;
      active.data = { found: false, left: st.secs, closeT: 0 };
    } else if (st.kind === 'wreck') {
      const car = traffic.spawnCar(true, 'van');
      car.tag = 'gang';
      car.bodyMat.color.set('#5b2a86');
      car.baseColor.set('#5b2a86');
      car.hp = 150;
      active.car = car;
    } else if (st.kind === 'steal') {
      const car = traffic.spawnCar(false, st.type);
      car.parked = true;
      car.speed = 0;
      car.tag = 'steal';
      active.car = car;
    } else if (st.kind === 'survive') {
      active.data = { left: st.secs };
    }
  }
  function nextStep() {
    const st = active.m.steps[active.step];
    if (['targets', 'collect'].includes(st.kind)) {
      for (const e of active.ents) if (e.g) scene.remove(e.g);
      active.ents = [];
    }
    if (st.kind === 'tail' || st.kind === 'wreck') {
      if (active.car) active.car.tag = null;
      active.car = null;
      overArrow.visible = false;
    }
    active.step += 1;
    if (active.step >= active.m.steps.length) { pass(); return; }
    enterStep();
  }
  function pass() {
    const m = active.m;
    cleanup();
    active = null;
    state.addMoney(m.reward);
    state.addXP(m.xp, 'mission');
    state.missionIndex += 1;
    state.missionsDone += 1;
    say(m, 'pass');
    state.emit('mission', { type: 'pass', title: m.title, reward: m.reward, xp: m.xp });
    state.save(player);
  }
  function fail(reason) {
    if (!active) return;
    const m = active.m;
    cleanup();
    active = null;
    failCooldown = 4;
    state.emit('mission', { type: 'fail', title: m.title, reason });
  }

  // ---------------------------------------------------- update
  function update(dt) {
    const t = performance.now() / 1000;
    for (const mk of [startMark, goalMark]) {
      mk.arrow.position.y = 3.4 + Math.sin(t * 2.4) * 0.2;
      mk.arrow.rotation.y += dt * 2;
    }
    const pp = player.position;
    failCooldown -= dt;
    if (!active) {
      const m = current();
      place(startMark, m.start);
      if (failCooldown <= 0 && !player.frozen
        && Math.hypot(pp.x - m.start[0], pp.z - m.start[1]) < MARK_R + (player.inVehicle ? 1.5 : 0)) {
        startMark.g.visible = false;
        start();
      }
      return;
    }
    startMark.g.visible = false;
    const st = active.m.steps[active.step];
    if (active.timer !== null) {
      active.timer -= dt;
      if (active.timer <= 0) { fail('Out of time'); return; }
    }
    chatterStep(dt);
    if (!active) return;
    const near = (at, extra = 0) => Math.hypot(pp.x - at[0], pp.z - at[1]) < MARK_R + extra;
    const car = active.car;
    if (car && !car.wrecked && player.car !== car) {
      overArrow.visible = true;
      overArrow.position.set(car.x, car.group.position.y + (car.type === 'bus' ? 4.5 : 3.2) + Math.sin(t * 3) * 0.2, car.z);
      overArrow.rotation.y += dt * 2;
    } else overArrow.visible = false;

    switch (st.kind) {
      case 'goto':
        if (near(st.at, player.inVehicle ? 2 : 0)) nextStep();
        break;
      case 'ride': if (player.inVehicle) nextStep(); break;
      case 'wanted': if (state.wanted >= st.stars) nextStep(); break;
      case 'clear': if (state.wanted === 0) nextStep(); break;
      case 'pistol': if (state.hasPistol) nextStep(); break;
      case 'targets': if (active.ents.every((e) => !e.alive)) nextStep(); break;
      case 'collect':
        for (const e of active.ents) {
          if (!e.alive) continue;
          e.g.rotation.y += dt * 2;
          e.g.position.y = groundHeightAt(e.x, e.z) + 0.7 + Math.sin(t * 3 + e.x) * 0.1;
          if (Math.hypot(pp.x - e.x, pp.z - e.z) < 1.8) {
            e.alive = false;
            e.g.visible = false;
            state.addMoney(25);
            state.emit('notify', { text: '+$25', kind: 'money' });
          }
        }
        if (active.ents.every((e) => !e.alive)) nextStep();
        break;
      case 'brawl':
      case 'shootout':
        for (const e of active.ents) stepThug(e, dt);
        if (active.ents.every((e) => !e.alive)) nextStep();
        break;
      case 'tail': {
        if (!car || car.wrecked) { fail('The taxi got wrecked'); return; }
        const d = Math.hypot(pp.x - car.x, pp.z - car.z);
        const D = active.data;
        if (!D.found) { if (d < st.max) D.found = true; break; }
        if (d > st.max + 45) { fail('You lost the taxi'); return; }
        if (d < st.min) {
          D.closeT += dt;
          if (D.closeT > 3) { fail('You got too close — the snitch spotted you'); return; }
        } else D.closeT = Math.max(0, D.closeT - dt);
        if (d <= st.max) D.left -= dt;
        if (D.left <= 0) nextStep();
        break;
      }
      case 'steal':
        if (!car || car.wrecked || car.burning !== undefined) { fail('The car got wrecked'); return; }
        if (player.car === car) nextStep();
        break;
      case 'deliver':
        if (!car || car.wrecked || car.burning !== undefined) { fail('The car got wrecked'); return; }
        if (player.car === car && near(st.at, 2)) {
          player.exitCar();
          car.tag = null;
          active.car = null;
          nextStep();
        }
        break;
      case 'wreck':
        if (!car) { fail('The van got away'); return; }
        if (car.wrecked || car.burning !== undefined) nextStep();
        break;
      case 'survive':
        active.data.left -= dt;
        if (state.wanted < st.stars) { fail('The heat died down too early'); return; }
        if (active.data.left <= 0) nextStep();
        break;
      default:
    }
  }

  // HUD mission card data.
  function tracker() {
    const pp = player.position;
    const jobOf = (idx) => (idx < CHAIN.length ? `JOB ${idx + 1}/${CHAIN.length}` : 'SIDE JOB');
    if (!active) {
      const m = current();
      const c = CONTACTS[m.who];
      return {
        idle: true, job: jobOf(state.missionIndex), title: m.title, contact: c ? c.name : '',
        text: `Meet ${c ? c.name : 'your contact'} at the yellow marker`,
        dist: Math.hypot(pp.x - m.start[0], pp.z - m.start[1]), timer: null, target: m.start,
        stage: 0, stages: m.steps.length, next: m.steps[0].text, sub: '',
      };
    }
    const m = active.m;
    const st = m.steps[active.step];
    let text = st.text;
    let sub = '';
    let target = st.kind === 'goto' || st.kind === 'deliver' ? st.at : null;
    let timer = active.timer;
    if (st.kind === 'pistol') target = PISTOL_CRATE.pos;
    if (st.kind === 'targets') {
      const left = active.ents.filter((e) => e.alive).length;
      sub = `${st.spots.length - left}/${st.spots.length} bottles`;
    }
    if (st.kind === 'collect') {
      const got = active.ents.filter((e) => !e.alive).length;
      sub = `${got}/${st.spots.length} collected`;
      const next = active.ents.find((e) => e.alive);
      if (next) target = [next.x, next.z];
    }
    if (st.kind === 'brawl' || st.kind === 'shootout') {
      const down = active.ents.filter((e) => !e.alive).length;
      sub = `${down}/${active.ents.length} down`;
      const next = active.ents.find((e) => e.alive);
      if (next) target = [next.x, next.z];
    }
    if (['tail', 'wreck', 'steal'].includes(st.kind) && active.car) {
      target = [active.car.x, active.car.z];
      if (st.kind === 'tail') {
        const D = active.data;
        text = D.found ? 'Follow the taxi' : 'Find the taxi';
        sub = D.found ? `stay between ${st.min} and ${st.max} m` : '';
        timer = D.found ? D.left : null;
      }
      if (st.kind === 'wreck') sub = `van condition ${Math.max(0, Math.round(active.car.hp / 1.5))}%`;
    }
    if (st.kind === 'survive') { sub = `keep ${st.stars}+ stars`; timer = active.data.left; }
    if (st.kind === 'clear' || st.kind === 'wanted') sub = st.kind === 'clear' ? 'break line of sight' : '';
    const nx = m.steps[active.step + 1];
    return {
      idle: false, job: jobOf(state.missionIndex), title: m.title,
      contact: CONTACTS[m.who] ? CONTACTS[m.who].name : '', text, sub,
      dist: target ? Math.hypot(pp.x - target[0], pp.z - target[1]) : null,
      timer, target, stage: active.step + 1, stages: m.steps.length, next: nx ? nx.text : 'Get paid',
    };
  }

  return {
    update,
    fail,
    tracker,
    get active() { return active; },
    get chainLength() { return CHAIN.length; },
  };
}
