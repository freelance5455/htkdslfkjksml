// characters.js — stylised cartoon characters for CAYO VERDE.
// Look: tall egg-shaped heads, big 3D eyeballs with heavy lids and small
// pupils, thin brows, a line mouth, chunky low-poly hair, tapered torso,
// rounded limbs. One builder serves the player (player.js) and every NPC
// (npcs.js) so they all share the same style.
//
// buildCharacter(spec) returns
//   { group, upper, head, armL, armR, legL, legR }
// group  — root, origin at the feet, character faces +z
// upper  — hip pivot (y = HIP_Y) carrying torso, arms and head
// arm*/leg* — shoulder / hip pivots (rotate .x for swing)

import * as THREE from 'three';

export const HIP_Y = 0.9;

// ------------------------------------------------------------- palettes
export const SKIN_TONES = ['#f1c7a1', '#e2b08a', '#c98f62', '#8d5b3a', '#b9a587', '#f6d5bd'];
export const HAIR_COLORS = ['#f2c230', '#3b2416', '#6b3f22', '#141414', '#a8552a', '#2a1a10', '#4a2c1a', '#c9c2b5'];
export const TOPS = ['#1f8fe0', '#1d2433', '#e8e4da', '#e9573f', '#2fae7a', '#f2b632', '#8e5bd6', '#ff7aa8'];
export const BOTTOMS = ['#2b3142', '#3d4a63', '#1e1e24', '#6d5a45', '#4a6b8a'];
export const SHOES = ['#f0f0ea', '#222222', '#b8322a', '#5a3b24'];

// ---------------------------------------------------- shared resources
// Geometries/materials are cached so 40+ characters stay cheap.
const matCache = new Map();
function mat(color, opts = {}) {
  const key = color + JSON.stringify(opts);
  if (!matCache.has(key)) {
    matCache.set(key, new THREE.MeshStandardMaterial({
      color, roughness: opts.roughness ?? 0.85, metalness: 0,
      flatShading: !!opts.flat, side: opts.double ? THREE.DoubleSide : THREE.FrontSide,
    }));
  }
  return matCache.get(key);
}
function darken(hex, k) {
  return '#' + new THREE.Color(hex).multiplyScalar(k).getHexString();
}

const geoCache = new Map();
function geo(key, make) {
  if (!geoCache.has(key)) geoCache.set(key, make());
  return geoCache.get(key);
}

// Head shape: an egg — ellipsoid, wider cranium, narrower jaw.
const HEAD = { rx: 0.19, ry: 0.25, rz: 0.2 };
function taper(yn) { // yn in [-1, 1], 1 = crown
  return yn < 0 ? 1 - 0.22 * yn * yn : 1 + 0.03 * yn;
}
function eggGeometry(sx, sy, sz, wSeg, hSeg, phiStart, phiLen, thStart, thLen) {
  const g = new THREE.SphereGeometry(1, wSeg, hSeg, phiStart, phiLen, thStart, thLen);
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const y = p.getY(i);
    const t = taper(y);
    p.setXYZ(i, p.getX(i) * sx * t, y * sy, p.getZ(i) * sz * t);
  }
  g.computeVertexNormals();
  return g;
}
// z of the head surface at (x, y) — used to sit features on the face.
function faceZ(x, y) {
  const t = taper(y / HEAD.ry);
  const u = 1 - (x / (HEAD.rx * t)) ** 2 - (y / HEAD.ry) ** 2;
  return HEAD.rz * t * Math.sqrt(Math.max(0, u));
}

function mesh(g, m, x = 0, y = 0, z = 0, shadow = true) {
  const o = new THREE.Mesh(g, m);
  o.position.set(x, y, z);
  o.castShadow = shadow;
  return o;
}

// ------------------------------------------------------------------ face
// eyes: 'sleepy' (heavy lids, like the blond guy), 'wide' (round staring
// eyes with reddish rims, like the bob-haired girl), 'normal'.
function buildFace(head, s) {
  const skin = s.skin;
  const eyeR = 0.056;
  const ex = 0.078;
  const ey = 0.035;
  const white = mat('#fbfbf7', { roughness: 0.35 });
  const pupil = mat('#15131a', { roughness: 0.3 });
  const rim = mat(s.eyes === 'wide' ? '#d98a7a' : darken(skin, 0.72));
  const lidMat = mat(skin, { double: true });
  const eyeG = geo('eye', () => new THREE.SphereGeometry(eyeR, 16, 12));
  const rimG = geo('eyeRim', () => new THREE.SphereGeometry(eyeR * 1.13, 16, 12));
  const pupilG = geo('pupil', () => {
    const pg = new THREE.SphereGeometry(eyeR * 0.3, 10, 8);
    pg.scale(1, 1, 0.3);
    return pg;
  });
  const lidG = geo('lid', () => new THREE.SphereGeometry(eyeR * 1.06, 16, 8, 0, Math.PI * 2, 0, Math.PI * 0.5));
  // Upper lid: hemisphere whose rim sits on the eye centre at 0; negative
  // tilts it back (more open). Lower lid: flipped, rim below the centre.
  const lidAngle = s.eyes === 'sleepy' ? -0.08 : s.eyes === 'wide' ? -0.95 : -0.5;
  const look = s.look ?? 0; // pupils glance sideways a bit
  for (const side of [-1, 1]) {
    const x = side * ex;
    const z = faceZ(x, ey) - eyeR * 0.45;
    const eye = new THREE.Group();
    eye.position.set(x, ey, z);
    eye.add(mesh(rimG, rim, 0, 0, -0.012, false));
    eye.add(mesh(eyeG, white, 0, 0, 0, false));
    const pdir = new THREE.Vector3(look * 0.35, -0.05, 1).normalize();
    const pm = mesh(pupilG, pupil, pdir.x * eyeR, pdir.y * eyeR, pdir.z * eyeR, false);
    pm.lookAt(pdir.x * 2, pdir.y * 2, pdir.z * 2);
    eye.add(pm);
    const lid = mesh(lidG, lidMat, 0, 0, 0, false);
    lid.rotation.x = lidAngle;
    eye.add(lid);
    if (s.eyes !== 'wide') { // lower lid / eye bag
      const low = mesh(lidG, lidMat, 0, 0, 0, false);
      low.rotation.x = Math.PI + (s.eyes === 'sleepy' ? 0.7 : 0.8);
      eye.add(low);
    }
    head.add(eye);
    // Brow: thin bar, slightly arched, hair-coloured.
    const brow = mesh(geo('brow', () => new THREE.BoxGeometry(0.075, 0.013, 0.02)),
      mat(darken(s.hairColor, 0.85)), x, ey + 0.085, faceZ(x, ey + 0.085) + 0.002, false);
    brow.rotation.z = side * (s.eyes === 'wide' ? 0.12 : -0.05);
    brow.rotation.y = side * 0.25;
    head.add(brow);
  }
  // Mouth: a short dark line, tilted for a smirk on some faces.
  const my = -0.105;
  const mouth = mesh(geo('mouth', () => new THREE.BoxGeometry(0.065, 0.007, 0.01)),
    mat('#2b1a16'), s.smirk ? 0.01 : 0, my, faceZ(0, my) + 0.001, false);
  mouth.rotation.z = s.smirk ? 0.12 : 0;
  head.add(mouth);
  // Tiny nose shadow line (the girl in the reference has one).
  if (s.nose) {
    head.add(mesh(geo('nose', () => new THREE.BoxGeometry(0.018, 0.006, 0.008)),
      mat(darken(skin, 0.6)), 0, -0.055, faceZ(0, -0.055) + 0.004, false));
  }
}

// ------------------------------------------------------------------ hair
const UP = new THREE.Vector3(0, 1, 0);
function aim(o, x, y, z) { // point a cone's tip along (x, y, z)
  o.quaternion.setFromUnitVectors(UP, new THREE.Vector3(x, y, z).normalize());
  return o;
}
const H = 1.07; // hair shell scale over the head
function shell(key, thLen, phiGap) {
  return geo(key, () => eggGeometry(HEAD.rx * H, HEAD.ry * H, HEAD.rz * H, 12, 9,
    phiGap ? Math.PI / 2 + phiGap : 0, phiGap ? Math.PI * 2 - 2 * phiGap : Math.PI * 2,
    0, thLen));
}
function buildHair(head, s) {
  const m = mat(s.hairColor, { flat: true, double: true, roughness: 0.9 });
  const add = (o) => { head.add(o); return o; };
  switch (s.hair) {
    case 'spiky': { // blond low-poly crown
      add(mesh(shell('capTop', Math.PI * 0.3), m));
      const spikeG = geo('spike', () => new THREE.ConeGeometry(0.075, 0.14, 4));
      const n = 11;
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2;
        const r = i % 2 ? 0.1 : 0.14;
        const sp = mesh(spikeG, m, Math.sin(a) * r, HEAD.ry * 0.88, Math.cos(a) * r * 1.05);
        aim(sp, Math.sin(a) * 0.75, 1, Math.cos(a) * 0.75);
        add(sp);
      }
      aim(add(mesh(spikeG, m, 0, HEAD.ry * 1.02, 0.02)), 0, 1, 0.3);
      // Fringe tufts over the forehead.
      for (const fx of [-0.08, 0, 0.08]) {
        const f = add(mesh(spikeG, m, fx, HEAD.ry * 0.62, faceZ(fx, HEAD.ry * 0.62) + 0.02));
        aim(f, fx * 2, -0.35, 1);
        f.scale.set(0.9, 0.8, 0.9);
      }
      break;
    }
    case 'bob': { // chin-length bob with straight bangs
      add(mesh(shell('capBangs', Math.PI * 0.33), m));
      add(mesh(shell('bobBack', Math.PI * 0.74, 0.62), m));
      break;
    }
    case 'long': {
      add(mesh(shell('capBangs', Math.PI * 0.33), m));
      add(mesh(shell('longBack', Math.PI * 0.82, 0.58), m));
      add(mesh(geo('longTail', () => new THREE.BoxGeometry(0.34, 0.32, 0.08)), m, 0, -HEAD.ry * 0.95, -0.13));
      break;
    }
    case 'ponytail': {
      add(mesh(shell('capPony', Math.PI * 0.42), m));
      const tail = add(mesh(geo('pony', () => new THREE.ConeGeometry(0.07, 0.32, 6)), m, 0, 0.02, -0.24));
      tail.rotation.x = Math.PI - 0.35;
      add(mesh(geo('tie', () => new THREE.SphereGeometry(0.05, 8, 6)), m, 0, 0.13, -0.21));
      break;
    }
    case 'bun': {
      add(mesh(shell('capBun', Math.PI * 0.4), m));
      add(mesh(geo('bun', () => new THREE.IcosahedronGeometry(0.085, 0)), m, 0, HEAD.ry * 1.05, -0.06));
      break;
    }
    case 'cap': { // baseball cap
      const cm = mat(s.capColor || '#d23b2e', { roughness: 0.8 });
      add(mesh(shell('capDome', Math.PI * 0.4), cm));
      const visor = add(mesh(geo('visor', () => new THREE.CylinderGeometry(0.15, 0.15, 0.02, 12, 1, false, -Math.PI / 2, Math.PI)),
        cm, 0, HEAD.ry * 0.5, 0.12));
      visor.rotation.x = 0.12;
      visor.scale.z = 1.1;
      add(mesh(shell('shortBack', Math.PI * 0.55, 0.9), m)); // hair peeking out the back
      break;
    }
    case 'buzz': {
      add(mesh(shell('buzz', Math.PI * 0.38), m));
      break;
    }
    case 'short':
    default: {
      add(mesh(shell('capShort', Math.PI * 0.42), m));
      add(mesh(shell('shortBack', Math.PI * 0.55, 0.9), m));
      const q = add(mesh(geo('quiff', () => new THREE.IcosahedronGeometry(0.09, 0)), m,
        0.03, HEAD.ry * 0.82, 0.08));
      q.scale.set(1.5, 0.7, 1);
      break;
    }
  }
}

// ------------------------------------------------------------------ body
export function buildCharacter(s) {
  const skinM = mat(s.skin);
  const topM = mat(s.top);
  const bottomM = mat(s.bottom);
  const shoeM = mat(s.shoes);
  const g = new THREE.Group();

  // ---- legs (hip pivots on the root so the walk swing is unchanged)
  const legLen = HIP_Y - 0.07;
  const leg = (x) => {
    const p = new THREE.Group();
    p.position.set(x, HIP_Y, 0);
    if (s.shorts) {
      p.add(mesh(geo('shortsLeg', () => new THREE.CylinderGeometry(0.1, 0.095, 0.32, 10)), bottomM, 0, -0.14, 0));
      p.add(mesh(geo('shin', () => new THREE.CylinderGeometry(0.062, 0.05, legLen - 0.26, 10)), skinM,
        0, -0.28 - (legLen - 0.26) / 2 + 0.02, 0));
    } else {
      p.add(mesh(geo('leg', () => new THREE.CylinderGeometry(0.088, 0.072, legLen, 10)), bottomM, 0, -legLen / 2, 0));
    }
    const shoe = mesh(geo('shoe', () => {
      const sg = new THREE.SphereGeometry(1, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.55);
      sg.scale(0.075, 0.1, 0.14);
      return sg;
    }), shoeM, 0, -HIP_Y + 0.005, 0.045);
    p.add(shoe);
    g.add(p);
    return p;
  };
  const legL = leg(-0.1);
  const legR = leg(0.1);

  // ---- upper body (hip pivot)
  const upper = new THREE.Group();
  upper.position.y = HIP_Y;
  g.add(upper);
  upper.add(mesh(geo('pelvis', () => {
    const pg = new THREE.CylinderGeometry(0.19, 0.18, 0.16, 12);
    pg.scale(1, 1, 0.7);
    return pg;
  }), bottomM, 0, 0.0, 0));
  if (s.skirt) {
    upper.add(mesh(geo('skirt', () => {
      const sk = new THREE.CylinderGeometry(0.19, 0.29, 0.38, 12, 1, true);
      sk.scale(1, 1, 0.8);
      return sk;
    }), mat(s.bottom, { double: true }), 0, -0.14, 0));
  }
  const torsoH = 0.52;
  const torsoY = 0.07 + torsoH / 2;
  const torsoG = geo('torso', () => {
    const tg = new THREE.CylinderGeometry(0.23, 0.19, torsoH, 14);
    tg.scale(1, 1, 0.66);
    return tg;
  });
  const shoulderG = geo('shoulders', () => {
    const sg = new THREE.SphereGeometry(1, 14, 6, 0, Math.PI * 2, 0, Math.PI / 2);
    sg.scale(0.23, 0.09, 0.23 * 0.66);
    return sg;
  });
  const shellM = s.jacket ? mat(s.jacket) : topM;
  upper.add(mesh(torsoG, shellM, 0, torsoY, 0));
  upper.add(mesh(shoulderG, shellM, 0, torsoY + torsoH / 2, 0));
  if (s.jacket) {
    // Open jacket: the tee shows through a strip down the front + collar.
    const tee = mesh(geo('teeStrip', () => new THREE.BoxGeometry(0.15, torsoH * 0.98, 0.02)), topM,
      0, torsoY, 0.122, false);
    tee.rotation.x = -0.07;
    upper.add(tee);
    const lapelG = geo('lapel', () => new THREE.BoxGeometry(0.035, torsoH * 0.96, 0.03));
    for (const side of [-1, 1]) {
      const lp = mesh(lapelG, mat(darken(s.jacket, 0.75)), side * 0.085, torsoY, 0.128, false);
      lp.rotation.x = -0.07;
      upper.add(lp);
    }
    upper.add(mesh(geo('collar', () => {
      const cg = new THREE.TorusGeometry(0.085, 0.022, 6, 14, Math.PI * 1.3);
      cg.rotateX(Math.PI / 2);
      cg.rotateY(Math.PI * 0.85);
      return cg;
    }), shellM, 0, torsoY + torsoH / 2 + 0.06, -0.01, false));
  }
  // Neck + head.
  upper.add(mesh(geo('neck', () => new THREE.CylinderGeometry(0.058, 0.064, 0.14, 10)), skinM,
    0, torsoY + torsoH / 2 + 0.07, 0));
  const head = new THREE.Group();
  head.position.set(0, torsoY + torsoH / 2 + 0.1 + HEAD.ry * 0.92, 0.01);
  head.add(mesh(geo('head', () => eggGeometry(HEAD.rx, HEAD.ry, HEAD.rz, 20, 16)), skinM));
  // Ears: small flattened spheres.
  for (const side of [-1, 1]) {
    const ear = mesh(geo('ear', () => {
      const eg = new THREE.SphereGeometry(1, 8, 6);
      eg.scale(0.022, 0.045, 0.035);
      return eg;
    }), skinM, side * HEAD.rx * 0.98, -0.01, 0, false);
    head.add(ear);
  }
  buildFace(head, s);
  buildHair(head, s);
  upper.add(head);

  // ---- arms (shoulder pivots)
  const armLen = 0.62;
  const sleeveM = s.jacket ? mat(s.jacket) : topM;
  const arm = (side) => {
    const p = new THREE.Group();
    p.position.set(side * 0.27, torsoY + torsoH / 2 - 0.05, 0);
    p.rotation.z = side * 0.06; // arms hang slightly away from the body
    const long = s.jacket || s.longSleeves;
    if (long) {
      p.add(mesh(geo('armLong', () => new THREE.CylinderGeometry(0.068, 0.055, armLen, 10)), sleeveM, 0, -armLen / 2, 0));
    } else {
      p.add(mesh(geo('sleeve', () => new THREE.CylinderGeometry(0.078, 0.07, 0.2, 10)), sleeveM, 0, -0.08, 0));
      p.add(mesh(geo('forearm', () => new THREE.CylinderGeometry(0.052, 0.045, armLen - 0.14, 10)), skinM,
        0, -0.14 - (armLen - 0.14) / 2 + 0.03, 0));
    }
    p.add(mesh(geo('hand', () => {
      const hg = new THREE.SphereGeometry(1, 10, 8);
      hg.scale(0.048, 0.06, 0.052);
      return hg;
    }), skinM, 0, -armLen - 0.03, 0.005));
    upper.add(p);
    return p;
  };
  const armL = arm(-1);
  const armR = arm(1);

  const out = { group: g, upper, head, armL, armR, legL, legR };
  bake(out);
  return out;
}

// Revision 4 performance: every rigid part of the body (root, hips/torso,
// head + face + hair, each arm, each leg) is merged into ONE mesh with
// the colours baked into vertex colours, all characters sharing a single
// material. ~35 draw calls per person -> 7, with the same look and the
// same pivots for animation.
const BAKED_MAT = new THREE.MeshStandardMaterial({
  vertexColors: true, roughness: 0.8, metalness: 0, side: THREE.DoubleSide,
});
const _inv = new THREE.Matrix4();
const _mm = new THREE.Matrix4();
const _col = new THREE.Color();
function bake(c) {
  const pivots = [c.group, c.upper, c.head, c.armL, c.armR, c.legL, c.legR];
  const set = new Set(pivots);
  const byPivot = new Map(pivots.map((p) => [p, []]));
  c.group.updateMatrixWorld(true);
  c.group.traverse((o) => {
    if (!o.isMesh) return;
    let p = o.parent;
    while (p && !set.has(p)) p = p.parent;
    if (p) byPivot.get(p).push(o);
  });
  for (const [pivot, meshes] of byPivot) {
    if (!meshes.length) continue;
    _inv.copy(pivot.matrixWorld).invert();
    const parts = meshes.map((m) => {
      let gg = m.geometry.index ? m.geometry.toNonIndexed() : m.geometry.clone();
      _mm.multiplyMatrices(_inv, m.matrixWorld);
      gg.applyMatrix4(_mm);
      if (m.material.flatShading) gg.computeVertexNormals(); // faceted hair stays faceted
      gg = { pos: gg.attributes.position.array, nor: gg.attributes.normal.array, n: gg.attributes.position.count };
      return { gg, color: _col.copy(m.material.color).clone() };
    });
    let n = 0;
    for (const p of parts) n += p.gg.n;
    const pos = new Float32Array(n * 3);
    const nor = new Float32Array(n * 3);
    const col = new Float32Array(n * 3);
    let o = 0;
    for (const p of parts) {
      pos.set(p.gg.pos, o * 3);
      nor.set(p.gg.nor, o * 3);
      for (let k = 0; k < p.gg.n; k++) {
        col[(o + k) * 3] = p.color.r; col[(o + k) * 3 + 1] = p.color.g; col[(o + k) * 3 + 2] = p.color.b;
      }
      o += p.gg.n;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
    geo.computeBoundingSphere();
    for (const m of meshes) m.parent.remove(m);
    const merged = new THREE.Mesh(geo, BAKED_MAT);
    merged.castShadow = true;
    pivot.add(merged);
  }
  // Drop the now-empty helper groups (eye sockets etc.).
  const empties = [];
  c.group.traverse((o) => { if (!set.has(o) && o.type === 'Group' && o.children.length === 0) empties.push(o); });
  for (const e of empties) e.parent.remove(e);
}

// ------------------------------------------------------------- presets
// The two characters from the reference image.
export const PRESETS = {
  // Blond spiky hair, sleepy eyes, open navy jacket over a white tee.
  hero: {
    skin: '#e9bd94', hair: 'spiky', hairColor: '#f2c230', eyes: 'sleepy', smirk: true,
    top: '#e8e4da', jacket: '#1d2433', bottom: '#2b3142', shoes: '#f0f0ea',
  },
  // Brown bob with bangs, wide staring eyes, bright blue tee.
  bobGirl: {
    skin: '#b9a587', hair: 'bob', hairColor: '#3b2416', eyes: 'wide', nose: true,
    top: '#1f8fe0', bottom: '#2b3142', shoes: '#222222', look: 0.3,
  },
};

// Deterministic NPC look from an index: varied hair, eyes, outfits.
const HAIR_STYLES = ['bob', 'short', 'spiky', 'ponytail', 'long', 'buzz', 'cap', 'bun'];
const EYE_STYLES = ['wide', 'sleepy', 'normal'];
function hash(i, k) { // integer hash -> [0, 1)
  let h = Math.imul(i + 1, 0x9e3779b1) ^ Math.imul(k + 7, 0x85ebca77);
  h = Math.imul(h ^ (h >>> 15), 0x2c1b3c6d);
  h = Math.imul(h ^ (h >>> 12), 0x297a2d39);
  return ((h ^ (h >>> 15)) >>> 0) / 4294967296;
}
function pick(arr, i, k) { return arr[Math.floor(hash(i, k) * arr.length)]; }

export function npcSpec(i) {
  if (i === 0) return { ...PRESETS.bobGirl };
  if (i === 1) return { ...PRESETS.hero, hairColor: '#6b3f22', jacket: '#4a6b8a' };
  const hair = HAIR_STYLES[i % HAIR_STYLES.length];
  const feminine = ['bob', 'ponytail', 'long', 'bun'].includes(hair);
  const s = {
    skin: pick(SKIN_TONES, i, 1),
    hair,
    hairColor: pick(HAIR_COLORS, i, 2),
    eyes: EYE_STYLES[(i + Math.floor(i / 3)) % EYE_STYLES.length],
    top: TOPS[(i * 3) % TOPS.length],
    bottom: pick(BOTTOMS, i, 4),
    shoes: pick(SHOES, i, 5),
    smirk: hash(i, 6) < 0.35,
    nose: hash(i, 7) < 0.5,
    look: (hash(i, 8) - 0.5) * 0.8,
    capColor: pick(['#d23b2e', '#1f8fe0', '#2fae7a', '#1d2433'], i, 9),
  };
  const r = hash(i, 10);
  if (r < 0.22) s.jacket = pick(['#1d2433', '#5a3b24', '#3d4a63', '#7a2e3a', '#2f5e44'], i, 11);
  else if (r < 0.35) s.longSleeves = true;
  if (hash(i, 12) < 0.18) s.shorts = true;
  else if (feminine && hash(i, 13) < 0.35) s.skirt = true;
  return s;
}
