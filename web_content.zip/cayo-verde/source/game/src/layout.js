// layout.js — THE UNIFIED LAYOUT MODULE for CAYO VERDE.
// Every system (roads, buildings, NPCs, traffic, minimap, city map, missions)
// reads its geography from this one module. Nothing re-derives it, nothing
// keeps a hand-maintained copy. If a coordinate lives anywhere else, that is
// a bug — fix it by moving the data here.
//
// Coordinate convention: -x is west, +x is east, -z is north, +z is south.
// 1 unit = 1 metre. The paved city is 256 x 256 (x and z in [-128, 128]).
// The island sits on a ~560 x 560 ground plane, sea on all four sides.
//
// Source of truth: Farhan's reference map (island: Port north, Central Park +
// lake west, Downtown centre, Vice Beach + pier + ferris wheel east, Airport
// south-west, Industrial District south, ring road + roundabout), merged with
// the Halcyon top-1 foundation measurements (road widths, zebra spec, palette).

// ============================================================== ROAD GRAPH
// R1a: the road system is a GRAPH. NODES are intersections / the roundabout
// / terminal junctions; EDGES are the road segments between two nodes.
// Every edge ends at a node — no dangling ends, no diagonals. LAYOUT.roads
// is DERIVED from EDGES (grouped by name), so renderers and maps keep
// reading LAYOUT.roads unchanged.
//
// Grid skeleton (60-unit pitch): N-S centrelines x = -120, -60, 0, 60, 120;
// E-W centrelines z = -120, -60, 0, 60, 120. The ring (±120) and the
// central cross (x=0 Cayo Blvd, z=0 Main St) are MAIN (16 m); the ±60
// lines are COLLECTOR (10 m); the three access stubs are LOCAL (8 m).
// The roundabout sits at the grid centre (0, 0), radius 14 m, with 4 arms.

export const ROUNDABOUT = { x: 0, z: 0, radius: 14 };

// Node ids: `n<x>_<z>` for grid nodes, 'roundabout' for (0, 0), a named id
// for each access terminal. type: 'intersection' | 'roundabout' |
// 'junction' (terminal — a deliberate dead end, not a dangling edge).
export const NODES = [];
for (const x of [-120, -60, 0, 60, 120]) {
  for (const z of [-120, -60, 0, 60, 120]) {
    if (x === 0 && z === 0) NODES.push({ id: 'roundabout', x, z, type: 'roundabout' });
    else NODES.push({ id: `n${x}_${z}`, x, z, type: 'intersection' });
  }
}
NODES.push(
  { id: 'port-dock', x: 0, z: -130, type: 'junction' },
  { id: 'airport-apron', x: -140, z: 60, type: 'junction' },
  { id: 'pier-end', x: 140, z: 0, type: 'junction' },
);

const nodeById = new Map(NODES.map((n) => [n.id, n]));

// Edge ids are sequential (e1..eN). `name` is the road the edge belongs to;
// `roadId` is that road's id in LAYOUT.roads (kept stable for consumers:
// details.js reads 'causeway', the DETAILS tree loop reads the avenue ids).
export const EDGES = [];
{
  const nid = (x, z) => (x === 0 && z === 0 ? 'roundabout' : `n${x}_${z}`);
  const XS = [-120, -60, 0, 60, 120];
  let n = 0;
  const edge = (from, to, cls, width, name, roadId) =>
    EDGES.push({ id: `e${++n}`, from, to, cls, width, name, roadId });
  for (let i = 0; i < 4; i++) {
    // Ring road — 4 sides, 4 segments each (MAIN, 16 m).
    edge(nid(XS[i], -120), nid(XS[i + 1], -120), 'main', 16, 'Ring Road', 'ring');
    edge(nid(XS[i], 120), nid(XS[i + 1], 120), 'main', 16, 'Ring Road', 'ring');
    edge(nid(-120, XS[i]), nid(-120, XS[i + 1]), 'main', 16, 'Ring Road', 'ring');
    edge(nid(120, XS[i]), nid(120, XS[i + 1]), 'main', 16, 'Ring Road', 'ring');
    // Central cross (MAIN, 16 m).
    edge(nid(0, XS[i]), nid(0, XS[i + 1]), 'main', 16, 'Cayo Blvd', 'cayo-blvd');
    edge(nid(XS[i], 0), nid(XS[i + 1], 0), 'main', 16, 'Main St', 'main-st');
    // Inner collectors (10 m).
    edge(nid(-60, XS[i]), nid(-60, XS[i + 1]), 'collector', 10, 'Parkside Ave', 'parkside-ave');
    edge(nid(60, XS[i]), nid(60, XS[i + 1]), 'collector', 10, 'Eastside Ave', 'eastside-ave');
    edge(nid(XS[i], -60), nid(XS[i + 1], -60), 'collector', 10, 'North Avenue', 'north-ave');
    edge(nid(XS[i], 60), nid(XS[i + 1], 60), 'collector', 10, 'South Avenue', 'south-ave');
  }
  // Access stubs (LOCAL, 8 m). The causeway runs dock-first so its derived
  // road starts at the water (details.js builds the port dock from
  // points[0]).
  edge('port-dock', 'n0_-120', 'local', 8, 'Port Causeway', 'causeway');
  edge('airport-apron', 'n-120_60', 'local', 8, 'Airport Link', 'airport-link');
  edge('n120_0', 'pier-end', 'local', 8, 'Beach Access', 'beach-access');
}

// Group the graph's edges into named roads: walk each road's edges end to
// end (the ring closes back on itself) and emit the ROADS shape
// { id, name, cls, width, points, closed? } that every consumer reads.
function deriveRoads() {
  const byName = new Map();
  for (const e of EDGES) {
    if (!byName.has(e.name)) byName.set(e.name, []);
    byName.get(e.name).push(e);
  }
  const roads = [];
  for (const [name, edges] of byName) {
    const adj = new Map();
    const link = (a, b, e) => {
      if (!adj.has(a)) adj.set(a, []);
      adj.get(a).push({ edge: e, other: b });
    };
    for (const e of edges) { link(e.from, e.to, e); link(e.to, e.from, e); }
    // Open roads start at a degree-1 node; a closed loop has none.
    let start = [...adj.keys()].find((id) => adj.get(id).length === 1);
    const closed = start === undefined;
    if (closed) start = [...adj.keys()][0];
    const points = [];
    const used = new Set();
    let cur = start;
    for (;;) {
      const node = nodeById.get(cur);
      points.push([node.x, node.z]);
      const next = adj.get(cur).find(({ edge }) => !used.has(edge.id));
      if (!next) break;
      used.add(next.edge.id);
      cur = next.other;
      if (closed && cur === start) break;
    }
    const first = edges[0];
    roads.push({
      id: first.roadId, name, cls: first.cls, width: first.width,
      points, ...(closed ? { closed: true } : {}),
    });
  }
  return roads;
}

export const LAYOUT = {
  meta: {
    name: 'CAYO VERDE',
    units: '1 unit = 1 metre',
    axes: '-x west, +x east, -z north, +z south',
  },

  // Paved city extent and ground extent, in world units.
  city: { minX: -128, maxX: 128, minZ: -128, maxZ: 128 },
  ground: { size: 560 },

  // ---------------------------------------------------------------- districts
  // Polygons are arrays of [x, z] corners (clockwise). `label` is where the
  // district name sits on the map. `color` is the map tint for the district.
  // R1b: polygons redrawn on the new grid — each district covers its blocks
  // plus the roads between them, edges shared (never overlapping) so zoneAt
  // is unambiguous. Midtown + Westside are gone: their land is Downtown /
  // Industrial / Central Park in the new grid (no other file references
  // them). Port / Vice Beach / South Shore are the non-block districts
  // (docks, hotels, sand). The park polygon drives the lawn in ground.js.
  districts: [
    {
      id: 'port', name: 'Port',
      polygon: [[-48, -140], [48, -140], [48, -120], [-48, -120]],
      label: [0, -130], color: '#7d8aa0',
    },
    {
      id: 'northside', name: 'Northside',
      polygon: [[-120, -120], [120, -120], [120, -60], [-120, -60]],
      label: [-80, -90], color: '#a8b8a0',
    },
    {
      id: 'central-park', name: 'Central Park',
      polygon: [[-120, -60], [-60, -60], [-60, 60], [-120, 60]],
      label: [-90, 0], color: '#58b368',
    },
    {
      id: 'downtown', name: 'Downtown Cayo Verde',
      polygon: [[-60, -60], [60, -60], [60, 60], [-60, 60]],
      label: [30, -30], color: '#5a6b7c',
    },
    {
      id: 'eastside', name: 'Eastside',
      polygon: [[60, -60], [120, -60], [120, 60], [60, 60]],
      label: [90, 30], color: '#c9b8a8',
    },
    {
      id: 'vice-beach', name: 'Vice Beach',
      polygon: [[120, -84], [164, -84], [164, 84], [120, 84]],
      label: [140, 0], color: '#f2e3b3',
    },
    {
      id: 'airport', name: 'Cayo Verde International Airport',
      polygon: [[-140, 60], [-60, 60], [-60, 120], [-140, 120]],
      label: [-90, 90], color: '#8a8f7a',
    },
    {
      id: 'industrial', name: 'Industrial District',
      polygon: [[-60, 60], [120, 60], [120, 120], [-60, 120]],
      label: [30, 90], color: '#9a8f7a',
    },
    {
      id: 'south-shore', name: 'South Shore',
      polygon: [[-128, 120], [128, 120], [128, 146], [-128, 146]],
      label: [0, 128], color: '#f2e3b3',
    },
  ],

  // -------------------------------------------------------------------- roads
  // R1a: roads are DERIVED from the graph (NODES + EDGES above) — grouped
  // by name into { id, name, cls, width, points, closed? }. Three classes:
  // 'main' 16 m (ring + central cross), 'collector' 10 m (the ±60 lines),
  // 'local' 8 m (port / airport / beach access stubs). Every road runs
  // node to node on the orthogonal 60-unit grid; no diagonals, no breaks.
  roads: deriveRoads(),

  // Roundabout — the graph node at the grid centre (0, 0), radius 14 m,
  // with 4 arms (Cayo Blvd N/S + Main St E/W). Single source of truth is
  // the ROUNDABOUT export above; this mirrors it in the legacy shape.
  roundabout: { pos: [ROUNDABOUT.x, ROUNDABOUT.z], radius: ROUNDABOUT.radius },

  // ----------------------------------------------------------------- coastline
  // Organic island outline, clockwise from the north-west. Sea on all four
  // sides. Features: north bay/inlet at the port (the dent around x 0,
  // z -124), north-east palm headland, curving east beach, smooth convex
  // south coast, squared-off airport point south-west.
  coastline: [
    [-150, -120], [-120, -142], [-80, -152], [-40, -146],
    [-30, -128], [0, -124], [30, -128], [50, -148],
    [90, -152], [130, -142], [160, -122], [176, -92],
    [186, -42], [180, 0], [176, 42], [166, 92],
    [142, 130], [92, 156], [32, 166], [-28, 162],
    [-88, 152], [-128, 132], [-158, 112], [-170, 82],
    [-166, 42], [-160, 0], [-156, -48], [-150, -90],
  ],

  // Beach: the sand band between the coastline and an inner polygon. The
  // inner polygon is the coastline scaled toward the island centre (see
  // beachInner() below). Vice Beach and South Shore are also sand (their
  // district polygons render as sand in ground.js), so the east and south
  // beaches read widest, as on the reference.
  beach: { innerScale: 0.88, sandDistricts: ['vice-beach', 'south-shore'] },

  // Central Park lake — kidney/bean shape around (-72, -32). The dent on the
  // north-east side is what makes it a kidney rather than an oval.
  lake: [
    [-90, -36], [-88, -44], [-80, -49], [-70, -48], [-62, -42],
    [-58, -34], [-62, -27], [-68, -24], [-70, -28], [-76, -30],
    [-82, -28], [-88, -30],
  ],

  // -------------------------------------------------------------- named places
  // R1b: the roundabout label moves to the new roundabout (0, 0) — it still
  // sat at (-82, 0) from the old layout. Terminal + apron move into the new
  // airport block A4 / the west apron (the old spots sat on South Ave /
  // outside the new airport). Port Docks sits on the dock node (0, -130).
  places: [
    { id: 'port-docks', name: 'Port Docks', pos: [0, -130], kind: 'port' },
    { id: 'cargo-ship', name: 'Cargo Ship', pos: [24, -134], kind: 'port' },
    { id: 'yacht', name: 'Yacht', pos: [64, -146], kind: 'port' },
    { id: 'pier', name: 'Vice Pier', pos: [140, 0], kind: 'landmark' },
    { id: 'ferris-wheel', name: 'Ferris Wheel', pos: [144, 25], kind: 'landmark' },
    { id: 'airport-terminal', name: 'Airport Terminal', pos: [-88, 80], kind: 'airport' },
    { id: 'airport-apron', name: 'Airport Apron', pos: [-130, 85], kind: 'airport' },
    { id: 'roundabout', name: 'Roundabout', pos: [0, 0], kind: 'junction' },
    { id: 'park-lake', name: 'Central Park Lake', pos: [-72, -28], kind: 'park' },
    { id: 'downtown', name: 'Downtown', pos: [24, -24], kind: 'district' },
  ],

  // ------------------------------------------------------- sidewalks + markings
  // Sidewalk spec (Halcyon + street visual): 3 m wide tiled paving, curb
  // 0.1 m high, curb face flush with the road edge — never overlapping the
  // road. Pedestrian targets live ON the walkable strip (between curb edge
  // and building faces); walkers cross only at zebra crossings.
  sidewalk: { width: 3, curbHeight: 0.1 },
  // Road markings (Farhan's decision 2026-11-18: uniform white dashed centre
  // line on ALL roads). Zebra spec (Halcyon): 0.6 m stripes, 0.5 m gaps.
  markings: {
    centerLine: { color: '#ffffff', dash: 3, gap: 4.5, width: 0.15, style: 'dashed' },
    laneLine: { color: '#ffffff', dash: 1.5, gap: 3, width: 0.12 },
    edgeLine: { color: '#ffffff', width: 0.1 },
    zebra: { stripeWidth: 0.6, stripeGap: 0.5, color: '#ffffff' },
  },

  // ------------------------------------------------------------------- palette
  // Halcyon-proven sunset palette, reference-matched.
  palette: {
    skyDusk: 0xf3b8a6,        // peach-pink dusk sky
    skyDay: 0x87bfe8,         // clear-day blue
    skyNight: 0x1a2340,       // navy night
    waterShallow: '#35a8e0',  // bright blue near shore (roadfix: was turquoise)
    waterDeep: '#0a4a8c',     // deep blue mid-sea (roadfix: was deep teal)
    lake: '#2f9fd8',          // park lake blue
    sand: '#f2e3b3',          // cream sand
    grass: '#69b455',         // bright green ground
    parkLawn: '#58b368',      // park green
    asphalt: '#3a3d47',       // dark slate road (revision 3: lighter so night streets read)
    sidewalk: '#cfc8c4',      // light grey/mauve tile
    curb: '#b8b0aa',          // curb face
    buildings: ['#f7a8b8', '#c9a7eb', '#f9e3ae', '#f7c873', '#f49c6b', '#8fd3c7'],
    neon: ['#22d3ee', '#f472b6', '#facc15', '#4ade80'],
  },
};

// ------------------------------------------------------------------ helpers

// Ray-casting point-in-polygon test. Polygon is an array of [x, z] corners.
export function pointInPolygon(x, z, polygon) {
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const [xi, zi] = polygon[i];
    const [xj, zj] = polygon[j];
    if ((zi > z) !== (zj > z) && x < ((xj - xi) * (z - zi)) / (zj - zi) + xi) {
      inside = !inside;
    }
  }
  return inside;
}

// District name for a world point. Districts first, then sea (outside the
// coastline), then the generic island name for unzoned land.
export function zoneAt(x, z) {
  for (const d of LAYOUT.districts) {
    if (pointInPolygon(x, z, d.polygon)) return d.name;
  }
  if (!pointInPolygon(x, z, LAYOUT.coastline)) return 'Sea';
  return 'Cayo Verde';
}

export function districtById(id) {
  return LAYOUT.districts.find((d) => d.id === id) || null;
}

export function roadById(id) {
  return LAYOUT.roads.find((r) => r.id === id) || null;
}

export function placeById(id) {
  return LAYOUT.places.find((p) => p.id === id) || null;
}

// Inner edge of the sand ring: the coastline scaled toward the island centre
// (0, 0) by LAYOUT.beach.innerScale.
export function beachInnerPolygon() {
  const s = LAYOUT.beach.innerScale;
  return LAYOUT.coastline.map(([x, z]) => [x * s, z * s]);
}

// Intersection of two line segments, or null if they do not cross.
function segmentIntersection(a, b, c, d) {
  const [ax, az] = a; const [bx, bz] = b;
  const [cx, cz] = c; const [dx, dz] = d;
  const den = (bx - ax) * (dz - cz) - (bz - az) * (dx - cx);
  if (Math.abs(den) < 1e-9) return null; // parallel
  const t = ((cx - ax) * (dz - cz) - (cz - az) * (dx - cx)) / den;
  const u = ((cx - ax) * (bz - az) - (cz - az) * (bx - ax)) / den;
  if (t < 0 || t > 1 || u < 0 || u > 1) return null;
  return [ax + t * (bx - ax), az + t * (bz - az)];
}

// All road crossings, for zebra placement (F2) and pedestrian crossings (F5).
// Returns [{ x, z, roads: [idA, idB] }], de-duplicated within 1 m.
export function computeIntersections() {
  const found = [];
  const roads = LAYOUT.roads;
  const segmentsOf = (road) => {
    const pts = road.points;
    const segs = [];
    for (let i = 0; i < pts.length - 1; i++) segs.push([pts[i], pts[i + 1]]);
    if (road.closed) segs.push([pts[pts.length - 1], pts[0]]);
    return segs;
  };
  for (let i = 0; i < roads.length; i++) {
    for (let j = i + 1; j < roads.length; j++) {
      for (const [a, b] of segmentsOf(roads[i])) {
        for (const [c, d] of segmentsOf(roads[j])) {
          const hit = segmentIntersection(a, b, c, d);
          if (!hit) continue;
          const [x, z] = hit;
          const dup = found.some((f) => Math.hypot(f.x - x, f.z - z) < 1);
          if (!dup) found.push({ x, z, roads: [roads[i].id, roads[j].id] });
        }
      }
    }
  }
  return found;
}

// ------------------------------------------- sidewalk graph + crossings (F2)
// Derived from the graph (NODES + EDGES). F5's NPCs walk this graph;
// roads.js renders the sidewalks FROM it, so data and render always match.
// Sidewalk width: uniform 3 m on every road class (R1a).

export function sidewalkWidthFor(_road) {
  return 3;
}


// One sidewalk strip per side of each graph edge. Uniform 3 m wide; the
// strip centreline sits half the road width + 1.5 m from the edge
// centreline, and each end stops at the intersection boundary (cross
// half-width + 1.5 m from the node) — never crossing the road body or an
// intersection patch. The 1.5 m trim equals the sidewalk half-width, so
// perpendicular strips meet exactly at intersection corners. Edges too
// short for their trims get no strips (the 10 m Port Causeway: the ring's
// asphalt leaves no room). Same shape as before:
// { roadId, side, width, points }.
export const SIDEWALKS = [];
{
  // Edge direction (unit vector) away from a node on that edge.
  const edgeDirFrom = (edge, nodeId) => {
    const a = nodeById.get(nodeId);
    const b = nodeById.get(edge.from === nodeId ? edge.to : edge.from);
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    const len = Math.hypot(dx, dz) || 1;
    return [dx / len, dz / len];
  };
  // Intersection half-width along an edge at a node: the widest road
  // crossing there (its half-width), the roundabout radius at the
  // roundabout node, 0 at a terminal (the strip runs to the road end).
  const halfAt = (nodeId, edge) => {
    const node = nodeById.get(nodeId);
    if (node.type === 'junction') return 0;
    if (node.type === 'roundabout') return ROUNDABOUT.radius;
    const [dx, dz] = edgeDirFrom(edge, nodeId);
    let half = 0;
    for (const e of EDGES) {
      if (e === edge) continue;
      if (e.from !== nodeId && e.to !== nodeId) continue;
      const [ox, oz] = edgeDirFrom(e, nodeId);
      if (Math.abs(dx * ox + dz * oz) < 0.5) half = Math.max(half, e.width / 2);
    }
    return half;
  };
  for (const edge of EDGES) {
    const a = nodeById.get(edge.from);
    const b = nodeById.get(edge.to);
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    const len = Math.hypot(dx, dz) || 1;
    const ux = dx / len;
    const uz = dz / len;
    const nx = -uz; // left normal (walking from `from` to `to`)
    const nz = ux;
    const off = edge.width / 2 + 1.5; // strip centreline offset
    const trimA = halfAt(edge.from, edge) + 1.5;
    const trimB = halfAt(edge.to, edge) + 1.5;
    if (trimA + trimB + 2 > len) continue; // no room for a strip
    const p0 = [a.x + ux * trimA, a.z + uz * trimA];
    const p1 = [b.x - ux * trimB, b.z - uz * trimB];
    for (const side of [1, -1]) {
      SIDEWALKS.push({
        roadId: edge.roadId,
        side: side === 1 ? 'left' : 'right',
        width: 3,
        points: [
          [p0[0] + nx * off * side, p0[1] + nz * off * side],
          [p1[0] + nx * off * side, p1[1] + nz * off * side],
        ],
      });
    }
  }
}

// Distance from a point to a polyline (minimum over its segments).
function distanceToPolyline(x, z, points, closed) {
  let best = Infinity;
  const n = points.length;
  const count = closed ? n : n - 1;
  for (let i = 0; i < count; i++) {
    const a = points[i];
    const b = points[(i + 1) % n];
    const dx = b[0] - a[0];
    const dz = b[1] - a[1];
    const len2 = dx * dx + dz * dz || 1;
    let t = ((x - a[0]) * dx + (z - a[1]) * dz) / len2;
    t = Math.max(0, Math.min(1, t));
    best = Math.min(best, Math.hypot(x - (a[0] + t * dx), z - (a[1] + t * dz)));
  }
  return best;
}

// Road direction (unit vector) at a point on the road: the direction of the
// segment nearest the point. Exported — roads.js orients lights from it.
export function roadDirectionAt(road, x, z) {
  let best = Infinity;
  let dir = [1, 0];
  const n = road.points.length;
  const count = road.closed ? n : n - 1;
  for (let i = 0; i < count; i++) {
    const a = road.points[i];
    const b = road.points[(i + 1) % n];
    const dx = b[0] - a[0];
    const dz = b[1] - a[1];
    const len = Math.hypot(dx, dz) || 1;
    const len2 = len * len;
    let t = ((x - a[0]) * dx + (z - a[1]) * dz) / len2;
    t = Math.max(0, Math.min(1, t));
    const d = Math.hypot(x - (a[0] + t * dx), z - (a[1] + t * dz));
    if (d < best) { best = d; dir = [dx / len, dz / len]; }
  }
  return dir;
}

// Zebra crossings: one per intersection approach, on every arm that exists.
// Derived from the graph (NODES + EDGES), never hand-placed: each crossing
// sits on its arm just outside the intersection area — offset from the node
// by the cross road's half-width + 2 m, so the 2.5 m zebra band sits fully
// clear of the intersection patch. The roundabout's 4 arms cross just
// outside its circle (radius 14 + 2 = 16 m). No mid-block crossings, and
// no crossing on an arm too short for its band (the 10 m Port Causeway:
// the ring's asphalt leaves only 2 m of clean road). Same shape as
// before: { intersectionId, roadId, position [x, z], direction }, where
// direction is the pedestrian's walking direction (across the road).
export const CROSSINGS = [];
{
  // Arms per node: [{ edge, dir, len }] where dir is the unit vector from
  // the node OUT along the arm and len is the arm's length in metres.
  const arms = new Map();
  const addArm = (nodeId, edge, otherId) => {
    const a = nodeById.get(nodeId);
    const b = nodeById.get(otherId);
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    const len = Math.hypot(dx, dz) || 1;
    if (!arms.has(nodeId)) arms.set(nodeId, []);
    arms.get(nodeId).push({ edge, dir: [dx / len, dz / len], len });
  };
  for (const e of EDGES) {
    addArm(e.from, e, e.to);
    addArm(e.to, e, e.from);
  }
  for (const node of NODES) {
    if (node.type === 'junction') continue; // terminals: no road to cross to
    const nodeArms = arms.get(node.id) || [];
    for (const { edge, dir, len } of nodeArms) {
      // The intersection's half-width along this arm: the widest road
      // crossing this arm at the node (its half-width), or the roundabout
      // radius at the roundabout node.
      let crossHalf = 0;
      if (node.type === 'roundabout') {
        crossHalf = ROUNDABOUT.radius;
      } else {
        for (const other of nodeArms) {
          if (other.edge === edge) continue;
          const dot = Math.abs(dir[0] * other.dir[0] + dir[1] * other.dir[1]);
          if (dot < 0.5) crossHalf = Math.max(crossHalf, other.edge.width / 2);
        }
      }
      const off = crossHalf + 2;
      if (off + 1.25 > len) continue; // band would overhang the arm's end
      CROSSINGS.push({
        intersectionId: node.id,
        roadId: edge.roadId,
        position: [node.x + dir[0] * off, node.z + dir[1] * off],
        direction: [-dir[1], dir[0]],
      });
    }
  }
}

// --------------------------------------------- building blocks (R1b).
// R1b REDEFINES BLOCKS: they are no longer per-building footprints but the
// land PARCELS of the new grid — the rectangles between adjacent roads.
// Derived from the graph: each parcel runs road edge to road edge (pitch
// 60 minus the neighbouring roads' half-widths), so every parcel is 47 x 47
// except the 4 downtown parcels around the roundabout, clipped to 41 x 41
// (inner edges at ±14, the roundabout radius — their inner corners sit
// 19.8 m from the centre, clear of the 14 m circle). Shape:
// { id, x0, z0, x1, z1, district, front [, park] [, airport] }.
// `front` is the street-facing side, same scalar convention as before:
// -1 faces north (-z), +1 faces south (+z) — every parcel faces its nearest
// MAIN road (the ring or the central cross). `park: true` parcels get NO
// buildings (the two Central Park parcels hold the kidney lake; B1 and D2
// are the north/east neighbourhood parks). `airport: true` (A4) holds the
// terminal + hangars + apron in R3, no regular buildings. R3 fills each
// parcel with buildings facing the road, aligned to the parcel edges, and
// must (a) inset buildings ~3 m from parcel edges for the sidewalk,
// (b) keep buildings clear of DETAILS trees, and (c) respect SPAWN_CLEAR
// (parcel C2's west edge is 1.5 m from the parked bike). No parcel overlaps
// a road, the roundabout circle, or — for buildable parcels — the lake.
// (The park parcels contain the lake by design; the lake's east tip pokes
// 3 m into the Parkside Ave road band — pre-existing, flagged for R2.)
// IDs are grid cells: columns A–D west→east, rows 1–4 north→south.
export const BLOCKS = [
  // Row 1 (north) — Northside residential; B1 is the north park.
  { id: 'A1', x0: -112, z0: -112, x1: -65, z1: -65, district: 'northside', front: -1 },
  { id: 'B1', x0: -55, z0: -112, x1: -8, z1: -65, district: 'northside', front: -1, park: true },
  { id: 'C1', x0: 8, z0: -112, x1: 55, z1: -65, district: 'northside', front: -1 },
  { id: 'D1', x0: 65, z0: -112, x1: 112, z1: -65, district: 'northside', front: -1 },
  // Row 2 — Central Park west (A2, lake inside); Downtown around the
  // roundabout (B2, C2, clipped to ±14); D2 is the east park.
  { id: 'A2', x0: -112, z0: -55, x1: -65, z1: -8, district: 'central-park', front: 1, park: true },
  { id: 'B2', x0: -55, z0: -55, x1: -14, z1: -14, district: 'downtown', front: 1 },
  { id: 'C2', x0: 14, z0: -55, x1: 55, z1: -14, district: 'downtown', front: 1 },
  { id: 'D2', x0: 65, z0: -55, x1: 112, z1: -8, district: 'eastside', front: 1, park: true },
  // Row 3 — Central Park west (A3); Downtown (B3, C3, clipped); Eastside.
  { id: 'A3', x0: -112, z0: 8, x1: -65, z1: 55, district: 'central-park', front: -1, park: true },
  { id: 'B3', x0: -55, z0: 14, x1: -14, z1: 55, district: 'downtown', front: -1 },
  { id: 'C3', x0: 14, z0: 14, x1: 55, z1: 55, district: 'downtown', front: -1 },
  { id: 'D3', x0: 65, z0: 8, x1: 112, z1: 55, district: 'eastside', front: -1 },
  // Row 4 (south) — Airport west (A4); Industrial District.
  { id: 'A4', x0: -112, z0: 65, x1: -65, z1: 112, district: 'airport', front: 1, airport: true },
  { id: 'B4', x0: -55, z0: 65, x1: -8, z1: 112, district: 'industrial', front: 1 },
  { id: 'C4', x0: 8, z0: 65, x1: 55, z1: 112, district: 'industrial', front: 1 },
  { id: 'D4', x0: 65, z0: 65, x1: 112, z1: 112, district: 'industrial', front: 1 },
];

// Spawn clearance (R1b) — no building, no tree, no detail within `radius`
// metres of the player spawn or the parked bike. R3 reads this when
// filling parcel C2 (its west edge is 1.5 m from the bike) and DETAILS
// enforces the tree half of it via clearSpawn().
export const SPAWN_CLEAR = { spawn: [9.5, -20], bike: [12.5, -17], radius: 5 };

// --------------------------------------------- street details (F4). DETAILS
// entries: { type, x, z, rot, scale, ground }. `ground` is the surface the
// item stands on — 'grass' (island top 0.20), 'sand' (sand district 0.40),
// 'ring' (sand ring 0.35), 'lawn' (park lawn 0.50), 'walk' (sidewalk top
// 0.80) — details.js sinks each base 0.05 into its surface. Trees and palms
// are generated from the road graph; furniture, beach and port items are
// hand-placed. Every entry was verified clear of roads, building footprints,
// zebra crossings and the lake by the F4 smoke test. The pier + ferris
// wheel are hand-placed landmarks (PIER / FERRIS_WHEEL below), not DETAILS.
export const DETAILS = [];
export const PIER = { x0: 136, x1: 200, z: 0, width: 6, deckY: 1.2 };
export const FERRIS_WHEEL = { x: 144, z: 25, radius: 6, hubY: 7 };
{
  const beachInner = beachInnerPolygon();
  const park = districtById('central-park');
  const intersections = computeIntersections();
  const [rx, rz] = LAYOUT.roundabout.pos;
  const nearIx = (x, z, r) =>
    intersections.some((ix) => Math.hypot(ix.x - x, ix.z - z) < r);
  const clearRoads = (x, z, m) =>
    LAYOUT.roads.every((r) => distanceToPolyline(x, z, r.points, !!r.closed) > r.width / 2 + m);
  const clearCross = (x, z, r) =>
    CROSSINGS.every((c) => Math.hypot(x - c.position[0], z - c.position[1]) > r);
  // Spawn clearance (roadfix lesson: the taller tree crowns blocked the
  // follow camera at spawn). No detail within 6 m of the player spawn
  // (9.5, -20), and no tree within 4 m of the spawn sidewalk strip — the
  // Cayo Blvd east sidewalk the player spawns on (x 8..11, z -54..-15).
  const clearSpawn = (x, z) => {
    if (Math.hypot(x - 9.5, z + 20) < 6) return false;
    const dx = Math.max(8 - x, 0, x - 11);
    const dz = Math.max(-54 - z, 0, z + 15);
    return Math.hypot(dx, dz) >= 4;
  };
  const onLand = (x, z) => pointInPolygon(x, z, LAYOUT.coastline);
  const inLake = (x, z) => pointInPolygon(x, z, LAYOUT.lake);
  const groundAt = (x, z) => {
    if (pointInPolygon(x, z, park.polygon)) return 'lawn';
    for (const id of LAYOUT.beach.sandDistricts) {
      const d = districtById(id);
      if (d && pointInPolygon(x, z, d.polygon)) return 'sand';
    }
    if (pointInPolygon(x, z, beachInner)) return 'grass';
    return 'ring';
  };
  // R1b: no block check here — BLOCKS are parcels now, and street trees
  // stand INSIDE parcels (2 m past the sidewalk, on the verge in front of
  // the buildings). Building-vs-tree clearance is R3's job: R3 reads
  // DETAILS and places buildings clear of trees. (`blockM` is kept so the
  // park/palm call sites need no change; it is no longer consulted.)
  const ok = (x, z, blockM = 3) =>
    onLand(x, z) && !inLake(x, z) &&
    Math.hypot(x - rx, z - rz) >= 26 &&
    !nearIx(x, z, 6) && clearSpawn(x, z) &&
    clearRoads(x, z, 0.5) && clearCross(x, z, 2.5);
  const add = (type, x, z, ground, rot = 0, scale = 1) =>
    DETAILS.push({ type, x: +x.toFixed(1), z: +z.toFixed(1), rot, scale, ground });

  // Street trees along the new grid roads — both sides of every main and
  // collector, ~12 m apart, 2 m outside the sidewalk edge (offset =
  // half-width + sidewalk 3 m + 2 m). The spawn clearance in ok() keeps
  // crowns off the follow camera. Closed roads (the ring) plant their
  // closing segment too.
  for (const id of ['ring', 'cayo-blvd', 'main-st', 'parkside-ave',
    'eastside-ave', 'north-ave', 'south-ave']) {
    const road = roadById(id);
    if (!road) continue; // R1a: old road id not in the new graph (R1b regenerates DETAILS)
    const off = road.width / 2 + sidewalkWidthFor(road) + 2;
    const segCount = road.closed ? road.points.length : road.points.length - 1;
    for (let i = 0; i < segCount; i++) {
      const [ax, az] = road.points[i];
      const [bx, bz] = road.points[(i + 1) % road.points.length];
      const len = Math.hypot(bx - ax, bz - az);
      const nx = -(bz - az) / len;
      const nz = (bx - ax) / len;
      for (let d = 10; d < len - 3; d += 12) {
        const px = ax + (bx - ax) * (d / len);
        const pz = az + (bz - az) * (d / len);
        for (const s of [1, -1]) {
          const x = px + nx * off * s;
          const z = pz + nz * off * s;
          // Revision 2: the beach boulevard (ring road east of x 100 and
          // the south-shore stretch) is lined with palms instead of trees.
          const palm = id === 'ring' && (x > 100 || z > 100);
          if (ok(x, z)) add(palm ? 'palm' : 'tree', x, z, groundAt(x, z));
        }
      }
    }
  }

  // Park trees: a ring around the lake + lawn clusters. Only positions
  // inside the Central Park polygon are planted — the old ring poked east
  // of the new park edge into the Parkside Ave road band, and two old
  // cluster spots sat ON North Ave / Main St.
  for (let a = 0; a < 12; a++) {
    const t = (a / 12) * Math.PI * 2;
    const x = -72 + Math.cos(t) * 21;
    const z = -32 + Math.sin(t) * 21;
    if (pointInPolygon(x, z, park.polygon) && ok(x, z, 1)) add('tree', x, z, 'lawn');
  }
  for (const [x, z] of [[-100, -40], [-82, -52], [-100, -15], [-80, -15], [-100, 25], [-80, 45]]) {
    if (pointInPolygon(x, z, park.polygon) && ok(x, z, 1)) add('tree', x, z, 'lawn');
  }

  // Palms: east beach row (east of the hotels) + south beach row.
  for (let z = -72; z <= 72; z += 16) {
    if (ok(156, z, 1)) add('palm', 156, z, 'sand');
  }
  for (let x = -96; x <= 96; x += 24) {
    if (ok(x, 132, 1)) add('palm', x, 132, 'sand');
  }
  // (roadfix) Second palm rows — the owner wanted more palms: a beachfront
  // row further east (near the waterline) and a second south-shore row.
  // Both reuse ok(), so any spot off the sand or too close to a road,
  // building or crossing is skipped automatically.
  for (let z = -72; z <= 72; z += 16) {
    if (ok(170, z, 1)) add('palm', 170, z, 'sand');
  }
  for (let x = -96; x <= 96; x += 24) {
    if (ok(x, 141, 1)) add('palm', x, 141, 'sand');
  }

  // Street furniture — hand-placed on sidewalk edges / lawn / sand, 2 m+
  // clear of every zebra crossing (verified by the smoke test).
  const FURN = [
    // benches: Main St south sidewalk (z 9.5 centreline) + park lawn.
    // The south-sidewalk strips run x -53.5..-15.5 / 15.5..53.5 /
    // 66.5..113.5 (trims stop at intersections) — every bench sits on a
    // strip, not in a junction. The (-60,-20) bench sat ON Parkside Ave.
    ['bench', -27, 9.5, 'walk'], ['bench', -18, 9.5, 'walk'],
    ['bench', 18, 9.5, 'walk'], ['bench', 27, 9.5, 'walk'],
    ['bench', 75, 9.5, 'walk'], ['bench', 85, 9.5, 'walk'],
    ['bench', -70, -20, 'lawn'], ['bench', -94, -48, 'lawn'],
    // hydrants: Cayo Blvd east sidewalk (x 11 edge) + North Ave south
    // sidewalk (z -54.5). Skipped: the roundabout approach (z -8, inside
    // the circle) and the South Ave junction (z 56, on the road band).
    ['hydrant', 11, -40, 'walk'], ['hydrant', 11, -25, 'walk'],
    ['hydrant', 11, 24, 'walk'], ['hydrant', 11, 40, 'walk'],
    ['hydrant', 11, 88, 'walk'],
    ['hydrant', -20, -54.5, 'walk'], ['hydrant', 20, -54.5, 'walk'],
    ['hydrant', 40, -54.5, 'walk'],
    // mailboxes: Main St north sidewalk (z -11 edge) + North Ave north
    // sidewalk (z -66.5 centreline). The old Market St three sat inside
    // downtown block B2 on the new grid.
    ['mailbox', -22, -11, 'walk'], ['mailbox', 22, -11, 'walk'],
    ['mailbox', 75, -11, 'walk'],
    ['mailbox', -30, -66.5, 'walk'], ['mailbox', 30, -66.5, 'walk'],
    ['mailbox', 70, -66.5, 'walk'],
    // round street signs: the (±11,±11) four moved OFF the roundabout
    // island into Central Park (nearest park block); the rest stay on
    // intersection corners (n60_-60 and n0_60). (43,-43) sat inside
    // downtown block C2 — moved to the SE corner (67,-53).
    ['sign', -70, -12, 'lawn'], ['sign', -100, -12, 'lawn'],
    ['sign', -70, 12, 'lawn'], ['sign', -100, 12, 'lawn'],
    ['sign', 53, -53, 'walk'], ['sign', 43, -53, 'walk'],
    ['sign', 53, -43, 'walk'], ['sign', 67, -53, 'walk'],
    ['sign', 11, 53, 'walk'], ['sign', -11, 53, 'walk'],
    // planters: Main St south sidewalk + park lawn. (-58,-54) sat ON
    // Parkside Ave and (-50,-32) inside downtown block B2 — both moved.
    ['planter', -40, 11, 'walk'], ['planter', -32, 11, 'walk'],
    ['planter', 32, 11, 'walk'], ['planter', 38, 11, 'walk'],
    ['planter', 55, 11, 'walk'], ['planter', 90, 11, 'walk'],
    ['planter', -75, -50, 'lawn'], ['planter', -90, -26, 'lawn'],
    ['planter', -94, -32, 'lawn'], ['planter', -100, -40, 'lawn'],
    // pergolas: park lawn. (-60,-60) sat on the Parkside/North Ave
    // intersection; (-108,-8) sat on the Main St road edge.
    ['pergola', -85, -50, 'lawn'], ['pergola', -108, -14, 'lawn'],
    // beach umbrellas + lifeguard tower: east beach sand
    ['umbrella', 152, -60, 'sand'], ['umbrella', 152, -47, 'sand'],
    ['umbrella', 152, -34, 'sand'], ['umbrella', 152, -21, 'sand'],
    ['umbrella', 152, -8, 'sand'], ['umbrella', 152, 5, 'sand'],
    ['umbrella', 152, 18, 'sand'], ['umbrella', 152, 31, 'sand'],
    ['umbrella', 152, 44, 'sand'], ['umbrella', 152, 57, 'sand'],
    ['lifeguard', 152, -30, 'sand'],
    // port cranes + container stacks: north coast, either side of the
    // causeway. The z -126 rows sat ON the new ring road (z -120, spans
    // -128..-112) — moved north to z -134, on the sand ring.
    ['crane', -35, -130, 'ring'], ['crane', 35, -130, 'ring'],
    ['container', -48, -134, 'ring'], ['container', -44, -134, 'ring'],
    ['container', -40, -134, 'ring'],
    ['container', -48, -132, 'ring'], ['container', -44, -132, 'ring'],
    ['container', -40, -132, 'ring'],
    ['container', 40, -134, 'ring'], ['container', 44, -134, 'ring'],
    ['container', 48, -134, 'ring'],
    ['container', 40, -132, 'ring'], ['container', 44, -132, 'ring'],
    ['container', 48, -132, 'ring'],
  ];
  for (const [type, x, z, ground] of FURN) add(type, x, z, ground);
}
