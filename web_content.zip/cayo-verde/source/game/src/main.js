// main.js — minimal runnable scaffold for CAYO VERDE.
// Renderer + dusk lighting + a small custom orbit control (written here,
// no three/examples imports) + the ground built from layout.js.
// Gameplay systems (player, traffic, NPCs, missions, HUD) arrive in later
// rounds; this round only proves the island renders and the camera works.

import * as THREE from 'three';
import { LAYOUT } from './layout.js';
import { buildGround } from './ground.js';
import { buildRoads } from './roads.js';
import { buildBuildings } from './buildings.js';
import { buildDetails, updateDetails, animatedDetails, FOLIAGE } from './details.js';
import { batchStatic } from './batch.js';
import { createPlayer } from './player.js';
import { createNPCs } from './npcs.js';
import { createMaps } from './maps.js';
import { createGame } from './game.js';
import { createSettings } from './settings.js';
import { createPost } from './post.js';

// ------------------------------------------------------------- orbit control
// Drag (left button) to orbit, wheel to zoom, right-drag or WASD/arrows to
// pan across the ground. Spherical coordinates around a ground target.
class OrbitControl {
  constructor(camera, dom) {
    this.camera = camera;
    this.dom = dom;
    this.target = new THREE.Vector3(0, 0, 0);
    this.radius = 340;
    this.theta = 0.55; // azimuth
    this.phi = 0.95;   // polar angle from +y (0 = top-down)
    this.dragging = null;
    this.keys = new Set();
    this.enabled = true; // F5a: the player disables orbit in follow mode.

    dom.addEventListener('pointerdown', (e) => {
      if (!this.enabled) return;
      dom.setPointerCapture(e.pointerId);
      this.dragging = { button: e.button, x: e.clientX, y: e.clientY };
    });
    dom.addEventListener('pointermove', (e) => {
      if (!this.dragging) return;
      const dx = e.clientX - this.dragging.x;
      const dy = e.clientY - this.dragging.y;
      this.dragging.x = e.clientX;
      this.dragging.y = e.clientY;
      if (this.dragging.button === 0) {
        this.theta -= dx * 0.005;
        this.phi = THREE.MathUtils.clamp(this.phi - dy * 0.005, 0.12, 1.45);
      } else if (this.dragging.button === 2) {
        this.panBy(-dx, -dy);
      }
    });
    const endDrag = () => { this.dragging = null; };
    dom.addEventListener('pointerup', endDrag);
    dom.addEventListener('pointercancel', endDrag);
    dom.addEventListener('contextmenu', (e) => e.preventDefault());
    dom.addEventListener('wheel', (e) => {
      if (!this.enabled) return;
      e.preventDefault();
      this.radius = THREE.MathUtils.clamp(
        this.radius * Math.exp(e.deltaY * 0.001), 40, 700,
      );
    }, { passive: false });

    window.addEventListener('keydown', (e) => this.keys.add(e.key.toLowerCase()));
    window.addEventListener('keyup', (e) => this.keys.delete(e.key.toLowerCase()));
    window.addEventListener('blur', () => this.keys.clear());
  }

  // Pan the target across the ground plane, screen-relative.
  panBy(sx, sy) {
    const scale = this.radius * 0.0016;
    const forward = new THREE.Vector3();
    this.camera.getWorldDirection(forward);
    forward.y = 0;
    forward.normalize();
    const right = new THREE.Vector3().crossVectors(forward, new THREE.Vector3(0, 1, 0)).negate();
    this.target.addScaledVector(right, sx * scale);
    this.target.addScaledVector(forward, sy * scale);
    this.target.x = THREE.MathUtils.clamp(this.target.x, -280, 280);
    this.target.z = THREE.MathUtils.clamp(this.target.z, -280, 280);
  }

  update(dt) {
    if (!this.enabled) return;
    // WASD / arrow-key panning (one code path, directly on the target).
    const step = this.radius * 0.9 * dt;
    let kx = 0;
    let kz = 0;
    if (this.keys.has('w') || this.keys.has('arrowup')) kz += 1;
    if (this.keys.has('s') || this.keys.has('arrowdown')) kz -= 1;
    if (this.keys.has('a') || this.keys.has('arrowleft')) kx -= 1;
    if (this.keys.has('d') || this.keys.has('arrowright')) kx += 1;
    if (kx !== 0 || kz !== 0) {
      const forward = new THREE.Vector3();
      this.camera.getWorldDirection(forward);
      forward.y = 0;
      forward.normalize();
      const right = new THREE.Vector3().crossVectors(forward, new THREE.Vector3(0, 1, 0)).negate();
      this.target.addScaledVector(forward, kz * step);
      this.target.addScaledVector(right, kx * step);
      this.target.x = THREE.MathUtils.clamp(this.target.x, -280, 280);
      this.target.z = THREE.MathUtils.clamp(this.target.z, -280, 280);
    }

    const sinPhi = Math.sin(this.phi);
    this.camera.position.set(
      this.target.x + this.radius * sinPhi * Math.sin(this.theta),
      this.target.y + this.radius * Math.cos(this.phi),
      this.target.z + this.radius * sinPhi * Math.cos(this.theta),
    );
    this.camera.lookAt(this.target);
  }
}

// ------------------------------------------------------------------- setup
const container = document.getElementById('app');
const renderer = new THREE.WebGLRenderer({ antialias: true });
// Revision 4: start at up to 1.5x; adaptive resolution tunes it live.
const MAX_PR = Math.min(window.devicePixelRatio || 1, 1.5);
let pixelRatio = MAX_PR;
renderer.setPixelRatio(pixelRatio);
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
container.appendChild(renderer.domElement);

const scene = new THREE.Scene();
// Dusk sky (blueprint palette): peach-lavender. No fog — distant towers
// must stay clear, as in the top-1 reference.
scene.background = new THREE.Color(LAYOUT.palette.skyDusk);

const camera = new THREE.PerspectiveCamera(
  55, window.innerWidth / window.innerHeight, 0.5, 2000,
);

// Lighting: warm hemisphere + low western sun for long dusk shadows.
const hemi = new THREE.HemisphereLight(0xffd9c0, 0x5a7a4a, 0.9);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffd9a0, 1.7);
sun.position.set(-180, 70, 60);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -240;
sun.shadow.camera.right = 240;
sun.shadow.camera.top = 240;
sun.shadow.camera.bottom = -240;
sun.shadow.camera.near = 1;
sun.shadow.camera.far = 600;
sun.shadow.bias = -0.0005;
scene.add(sun);
scene.add(sun.target);

const groundGroup = buildGround(scene);
const roads = buildRoads(scene);
const buildingsGroup = buildBuildings(scene);
const detailsGroup = buildDetails(scene);
// Revision 4: merge the static city into a few hundred draw calls.
{
  const keep = new Set([...animatedDetails(), ...FOLIAGE.flatMap((f) => f.meshes)]);
  const stats = [groundGroup, roads, buildingsGroup, detailsGroup]
    .map((g) => batchStatic(g, { exclude: keep }));
  window.__batchStats = stats;
}

const controls = new OrbitControl(camera, renderer.domElement);
controls.update(0);

// F5a: playable core — third-person player (follow camera is the default;
// press O to toggle the orbit camera). The player disables the orbit
// control while follow mode is active.
const player = createPlayer(scene, camera, renderer.domElement, controls);

// F5b: NPC pedestrians (sidewalk-graph walkers + sitters + beach people).
const npcs = createNPCs(scene, { player });

// F6: minimap HUD + full city map (M key), both drawn from layout.js.
const maps = createMaps({ player, npcs: npcs.npcs, bike: player.bike });

// G2-G5: police / wanted, combat, shops + cash + missions, HUD + save +
// day/night (game.js wires them together).
const settings = createSettings();
const game = createGame({ scene, camera, renderer, player, npcs, maps, sun, hemi, roads, settings });
// Revision 3: bloom + colour grade post-process, shadows setting.
const post = createPost(renderer, scene, camera, settings);
const applyShadows = () => { sun.castShadow = !!settings.get('shadows'); };
settings.on((k) => { if (k === 'shadows') applyShadows(); });
applyShadows();

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

// Expose a small debug handle for verification runs.
window.CAYO = { scene, camera, renderer, controls, LAYOUT, player, npcs, bike: player.bike, maps, game, settings };

// ------------------------------------------------- revision 4: smoothness
// Adaptive resolution: an EMA of the frame time steers the pixel ratio
// (0.6 .. MAX_PR) so the frame rate stays near 60 instead of stuttering.
const fpsEl = document.createElement('div');
Object.assign(fpsEl.style, {
  position: 'fixed', top: '4px', left: '50%', transform: 'translateX(-50%)', zIndex: 70,
  font: 'bold 12px monospace', color: '#5dff8f', textShadow: '0 1px 2px #000', pointerEvents: 'none', display: 'none',
});
document.body.appendChild(fpsEl);
let ema = 1 / 60;
let resT = 0;
let fpsT = 0;
let frames = 0;
let frameNo = 0;
function tuneResolution(raw) {
  ema += (raw - ema) * 0.05;
  resT += raw;
  fpsT += raw;
  frames += 1;
  if (fpsT >= 0.5) {
    fpsEl.style.display = settings.get('showFps') ? 'block' : 'none';
    fpsEl.textContent = `${Math.round(frames / fpsT)} FPS · ${Math.round(pixelRatio * 100)}% res`;
    fpsT = 0; frames = 0;
  }
  if (resT < 1.5) return;
  resT = 0;
  let next = pixelRatio;
  if (!settings.get('adaptiveRes')) next = MAX_PR;
  else if (ema > 1 / 45 && pixelRatio > 0.6) next = Math.max(0.6, pixelRatio - 0.1);
  else if (ema < 1 / 57 && pixelRatio < MAX_PR) next = Math.min(MAX_PR, pixelRatio + 0.1);
  if (Math.abs(next - pixelRatio) > 0.01) {
    pixelRatio = next;
    renderer.setPixelRatio(pixelRatio);
    renderer.setSize(window.innerWidth, window.innerHeight);
    post.resize();
  }
}

// --------------------------------------------------------------------- loop
const clock = new THREE.Clock();
function animate() {
  requestAnimationFrame(animate);
  const raw = Math.min(clock.getDelta(), 0.05);
  tuneResolution(raw);
  frameNo += 1;
  if (!game.paused) {
    // Slow motion during stunt jumps (game.timeScale < 1).
    const dt = raw * game.timeScale;
    if (player.followActive) player.update(dt);
    else controls.update(dt);
    updateDetails(dt);
    npcs.update(dt);
    game.update(dt);
    if (frameNo % 2 === 0) maps.update(); // minimap at 30 Hz is plenty
  }
  post.render();
}
animate();
