// camfx.js — revision 3 camera polish, applied after player.js has placed
// the follow camera each frame:
//  * Foliage fade: tree crowns / palm fronds between the camera and the
//    player turn see-through, so the view is never blocked by a tree.
//  * Shake: explosions (by distance), crashes, heavy guns, taking hits.
//  * Speed FOV: the field of view widens with speed (and more on nitro).

import * as THREE from 'three';
import { FOLIAGE } from './details.js';

const BASE_FOV = 55;

export function createCamFX({ camera, player, state, settings }) {
  const fadedOf = new Map();   // original material -> faded clone
  const faded = new Set();     // meshes currently faded
  let trauma = 0;
  let fov = BASE_FOV;
  let t = 0;

  function fadedMat(m) {
    if (!fadedOf.has(m)) {
      const c = m.clone();
      c.transparent = true;
      c.opacity = 0.22;
      c.depthWrite = false;
      fadedOf.set(m, c);
    }
    return fadedOf.get(m);
  }

  state.on((type, d) => {
    if (type === 'explosion') {
      const p = player.position;
      const dist = Math.hypot(d.x - p.x, d.z - p.z);
      trauma = Math.min(1, trauma + Math.max(0, 1 - dist / 60));
    }
    if (type === 'crash') trauma = Math.min(1, trauma + Math.min(0.6, (d.speed || 8) / 30));
    if (type === 'shot' && d && (d.weapon === 'shotgun' || d.weapon === 'rifle')) trauma = Math.min(1, trauma + 0.12);
    if (type === 'hurt') trauma = Math.min(1, trauma + 0.15);
  });

  // Distance from point P to segment AB (3D).
  const segDist = (px, py, pz, ax, ay, az, bx, by, bz) => {
    const dx = bx - ax; const dy = by - ay; const dz = bz - az;
    const l2 = dx * dx + dy * dy + dz * dz || 1;
    const k = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy + (pz - az) * dz) / l2));
    return Math.hypot(px - ax - k * dx, py - ay - k * dy, pz - az - k * dz);
  };

  function update(dt) {
    t += dt;
    if (!player.followActive) return;
    const c = camera.position;
    const p = player.position;
    const hy = p.y + (player.driving ? 1.2 : 1.5);

    // Foliage between camera and player.
    const now = new Set();
    const span = Math.hypot(c.x - p.x, c.z - p.z) + 4;
    for (const f of FOLIAGE) {
      if (Math.abs(f.x - p.x) > span || Math.abs(f.z - p.z) > span) continue;
      if (f.tall) {
        // Trunk: 2D distance to the camera->player line, within its height.
        if (segDist(f.x, 0, f.z, c.x, 0, c.z, p.x, 0, p.z) < f.r && Math.min(c.y, hy) < f.base + f.tall) for (const m of f.meshes) now.add(m);
        continue;
      }
      if (segDist(f.x, f.y, f.z, c.x, c.y, c.z, p.x, hy, p.z) < f.r) for (const m of f.meshes) now.add(m);
    }
    for (const m of now) {
      if (!faded.has(m)) { m.userData.solidMat = m.material; m.material = fadedMat(m.material); faded.add(m); }
    }
    for (const m of faded) {
      if (!now.has(m)) { m.material = m.userData.solidMat; faded.delete(m); }
    }

    // Speed FOV.
    const sp = Math.abs(player.speed);
    let target = BASE_FOV;
    if (settings.get('speedFov') && player.inVehicle) {
      target += Math.max(0, Math.min(1, (sp - 10) / 30)) * 11 + (player.boosting ? 7 : 0);
    }
    fov += (target - fov) * (1 - Math.exp(-4 * dt));
    if (Math.abs(camera.fov - fov) > 0.01) { camera.fov = fov; camera.updateProjectionMatrix(); }

    // Shake (trauma^2, smooth pseudo-noise).
    trauma = Math.max(0, trauma - dt * 1.4);
    if (settings.get('shake') && trauma > 0.001) {
      const s = trauma * trauma;
      const n = (k) => Math.sin(t * (23 + k * 7.1)) * 0.6 + Math.sin(t * (41 + k * 3.3)) * 0.4;
      c.x += n(1) * s * 0.5;
      c.y += n(2) * s * 0.35;
      c.z += n(3) * s * 0.5;
      camera.rotateZ(n(4) * s * 0.05);
    }
  }

  return { update, get trauma() { return trauma; }, addTrauma(v) { trauma = Math.min(1, trauma + v); } };
}

export { BASE_FOV, THREE };
