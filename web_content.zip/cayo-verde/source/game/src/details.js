// details.js — F4: low-poly street details rendered FROM layout.js DETAILS
// data + the PIER / FERRIS_WHEEL landmarks (never hard-coded positions).
// Flat shading, simple primitives only (blueprint §8B). The ferris wheel
// rotates slowly; updateDetails(dt) keeps its gondolas level.
import * as THREE from 'three';
import { DETAILS, PIER, FERRIS_WHEEL, LAYOUT } from './layout.js';

// Base y per ground type: each surface top minus 0.05 so nothing floats.
// (grass 0.20, sand district 0.40, sand ring 0.35, park lawn 0.50,
// sidewalk top 0.80 — see ground.js / roads.js.)
const BASE_Y = { grass: 0.15, sand: 0.35, ring: 0.30, lawn: 0.45, walk: 0.80 };

const matCache = new Map();
function mat(color, opts = {}) {
  const key = color + '|' + (opts.roughness ?? 0.9);
  if (!matCache.has(key)) {
    matCache.set(key, new THREE.MeshStandardMaterial({
      color, flatShading: true, roughness: opts.roughness ?? 0.9,
      metalness: 0,
    }));
  }
  return matCache.get(key);
}

function box(parent, w, h, d, x, y, z, material, shadow = false) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  m.position.set(x, y, z);
  if (shadow) { m.castShadow = true; m.receiveShadow = true; }
  parent.add(m);
  return m;
}

function cyl(parent, rTop, rBot, h, x, y, z, material, seg = 8, shadow = false) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(rTop, rBot, h, seg), material);
  m.position.set(x, y, z);
  if (shadow) { m.castShadow = true; m.receiveShadow = true; }
  parent.add(m);
  return m;
}

function cone(parent, r, h, x, y, z, material, seg = 8, shadow = false) {
  const m = new THREE.Mesh(new THREE.ConeGeometry(r, h, seg), material);
  m.position.set(x, y, z);
  if (shadow) { m.castShadow = true; m.receiveShadow = true; }
  parent.add(m);
  return m;
}

const TRUNK = () => mat('#7a5230');
const CROWNS = ['#2e8b3a', '#3aa84a', '#277a32'].map((c) => mat(c));
const WOOD = () => mat('#8a6a42');
const DARK = () => mat('#2a2a2e');

// Revision 3: foliage registry for the camera fade (camfx.js): each entry
// is { meshes, x, y, z, r } — the crown centre / radius in world space.
export const FOLIAGE = [];

// Round-crowned street tree: trunk + faceted icosahedron canopy.
// (roadfix) Taller than the F4 original — the owner said the trees were
// too short: ~1.5x the old height (trunk 3.0 m, crown centre 4.4 m,
// crown radius 2.0 m; total ~6.4 m vs ~4.4 m before).
function buildTree(parent, d, i) {
  const y = BASE_Y[d.ground];
  const s = d.scale * (0.9 + (i % 5) * 0.05);
  const g = new THREE.Group();
  g.position.set(d.x, y, d.z);
  cyl(g, 0.18 * s, 0.26 * s, 3.0 * s, 0, 1.5 * s, 0, TRUNK(), 7, true);
  const crown = new THREE.Mesh(
    new THREE.IcosahedronGeometry(2.0 * s, 0), CROWNS[i % 3]);
  crown.position.set(0, 4.4 * s, 0);
  crown.castShadow = true;
  crown.receiveShadow = true;
  g.add(crown);
  parent.add(g);
  FOLIAGE.push({ meshes: [crown], x: d.x, y: y + 4.4 * s, z: d.z, r: 2.3 * s });
}

// Palm: leaning trunk + 7 drooping cone fronds + a few coconuts.
function buildPalm(parent, d, i) {
  const y = BASE_Y[d.ground];
  const h = 7 + (i % 3); // 7–9 m tall
  const g = new THREE.Group();
  g.position.set(d.x, y, d.z);
  g.rotation.y = (i % 8) * 0.8; // vary the lean direction
  const trunk = cyl(g, 0.14, 0.2, h, 0, h / 2, 0, TRUNK(), 7, true);
  trunk.rotation.z = 0.1;
  const fronds = [];
  const top = new THREE.Group();
  top.position.set(-0.35, h, 0);
  g.add(top);
  for (let f = 0; f < 7; f++) {
    const holder = new THREE.Group();
    holder.rotation.y = (f / 7) * Math.PI * 2;
    top.add(holder);
    const frond = cone(holder, 0.32, 3.4, 0, -0.35, 1.35, CROWNS[i % 3], 6, true);
    frond.rotation.x = 2.0; // tip points outward and down
    fronds.push(frond);
  }
  for (let c = 0; c < 3; c++) {
    const nut = new THREE.Mesh(new THREE.SphereGeometry(0.16, 6, 5), mat('#6a4a26'));
    nut.position.set(Math.cos(c * 2.1) * 0.3, -0.25, Math.sin(c * 2.1) * 0.3);
    top.add(nut);
  }
  // Revision 4: the 7 fronds become ONE mesh (one draw call per palm
  // crown, and one object for the camera fade).
  g.updateMatrixWorld(true);
  const inv = new THREE.Matrix4().copy(top.matrixWorld).invert();
  const geos = fronds.map((fr) => {
    const gg = fr.geometry.index ? fr.geometry.toNonIndexed() : fr.geometry.clone();
    gg.applyMatrix4(new THREE.Matrix4().multiplyMatrices(inv, fr.matrixWorld));
    return gg;
  });
  let n = 0;
  for (const gg of geos) n += gg.attributes.position.count;
  const pos = new Float32Array(n * 3);
  const nor = new Float32Array(n * 3);
  let o = 0;
  for (const gg of geos) {
    pos.set(gg.attributes.position.array, o * 3);
    nor.set(gg.attributes.normal.array, o * 3);
    o += gg.attributes.position.count;
  }
  const mg = new THREE.BufferGeometry();
  mg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  mg.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  const crownMesh = new THREE.Mesh(mg, CROWNS[i % 3]);
  crownMesh.castShadow = true;
  for (const fr of fronds) fr.parent.parent.remove(fr.parent);
  top.add(crownMesh);
  parent.add(g);
  FOLIAGE.push({ meshes: [crownMesh], x: d.x, y: y + h - 0.4, z: d.z, r: 3.2 });
  // Revision 5: the trunk fades too (vertical test, see camfx.js).
  FOLIAGE.push({ meshes: [trunk], x: d.x, y: y + h / 2, z: d.z, r: 0.9, tall: h, base: y });
}

// Bench: legs + seat + back, facing -z (toward the street) by default.
function buildBench(parent, d) {
  const y = BASE_Y[d.ground];
  const g = new THREE.Group();
  g.position.set(d.x, y, d.z);
  g.rotation.y = d.rot;
  box(g, 0.12, 0.45, 0.5, -0.8, 0.22, 0, DARK());
  box(g, 0.12, 0.45, 0.5, 0.8, 0.22, 0, DARK());
  box(g, 1.9, 0.1, 0.5, 0, 0.5, 0, WOOD(), true);
  const back = box(g, 1.9, 0.55, 0.08, 0, 0.85, 0.24, WOOD(), true);
  back.rotation.x = -0.15;
  parent.add(g);
}

// Red hydrant: body + cap + side nozzle.
function buildHydrant(parent, d) {
  const y = BASE_Y[d.ground];
  const g = new THREE.Group();
  g.position.set(d.x, y, d.z);
  cyl(g, 0.16, 0.19, 0.6, 0, 0.3, 0, mat('#d43a2a'), 8, true);
  cyl(g, 0.2, 0.2, 0.12, 0, 0.66, 0, mat('#b83024'), 8);
  const nozzle = cyl(g, 0.07, 0.07, 0.24, 0.2, 0.42, 0, mat('#b83024'), 6);
  nozzle.rotation.z = Math.PI / 2;
  parent.add(g);
}

// Blue mailbox on a post, with a white slot stripe.
function buildMailbox(parent, d) {
  const y = BASE_Y[d.ground];
  const g = new THREE.Group();
  g.position.set(d.x, y, d.z);
  g.rotation.y = d.rot;
  box(g, 0.14, 0.35, 0.14, 0, 0.17, 0, DARK());
  box(g, 0.62, 0.85, 0.45, 0, 0.78, 0, mat('#2456c8'), true);
  box(g, 0.5, 0.12, 0.38, 0, 1.26, 0, mat('#1a40a0'));
  box(g, 0.3, 0.05, 0.03, 0, 0.95, 0.24, mat('#f5f0e6'));
  parent.add(g);
}

// Round street sign: pole + blue disc with a white face.
function buildSign(parent, d) {
  const y = BASE_Y[d.ground];
  const g = new THREE.Group();
  g.position.set(d.x, y, d.z);
  cyl(g, 0.05, 0.05, 2.7, 0, 1.35, 0, DARK(), 6);
  const disc = cyl(g, 0.45, 0.45, 0.08, 0, 2.75, 0, mat('#2456c8'), 16);
  disc.rotation.x = Math.PI / 2;
  const face = cyl(g, 0.32, 0.32, 0.1, 0, 2.75, 0, mat('#f5f0e6'), 16);
  face.rotation.x = Math.PI / 2;
  parent.add(g);
}

// Planter: terracotta box + bush sphere.
function buildPlanter(parent, d) {
  const y = BASE_Y[d.ground];
  const g = new THREE.Group();
  g.position.set(d.x, y, d.z);
  box(g, 1.0, 0.5, 1.0, 0, 0.25, 0, mat('#b06040'), true);
  const bush = new THREE.Mesh(new THREE.IcosahedronGeometry(0.55, 0), CROWNS[1]);
  bush.position.set(0, 0.85, 0);
  bush.castShadow = true;
  g.add(bush);
  parent.add(g);
}

// Pergola: 4 posts + a slatted top.
function buildPergola(parent, d) {
  const y = BASE_Y[d.ground];
  const g = new THREE.Group();
  g.position.set(d.x, y, d.z);
  g.rotation.y = d.rot;
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      box(g, 0.18, 2.6, 0.18, sx * 2.1, 1.3, sz * 1.6, WOOD(), true);
    }
  }
  for (let i = 0; i < 5; i++) {
    box(g, 4.6, 0.12, 0.28, 0, 2.7, -1.4 + i * 0.7, WOOD(), true);
  }
  box(g, 0.25, 0.14, 3.6, -2.1, 2.82, 0, WOOD());
  box(g, 0.25, 0.14, 3.6, 2.1, 2.82, 0, WOOD());
  parent.add(g);
}

// Beach umbrella: pole + bright cone canopy.
const UMBRELLA_COLORS = ['#e84a3a', '#f5c542', '#3a7bd5', '#f07f2e', '#e87ab0']
  .map((c) => mat(c));
function buildUmbrella(parent, d, i) {
  const y = BASE_Y[d.ground];
  const g = new THREE.Group();
  g.position.set(d.x, y, d.z);
  cyl(g, 0.05, 0.05, 2.2, 0, 1.1, 0, mat('#f5f0e6'), 6);
  cone(g, 1.6, 0.7, 0, 2.45, 0, UMBRELLA_COLORS[i % 5], 8, true);
  parent.add(g);
}

// Lifeguard tower: splayed legs + white cabin + red roof.
function buildLifeguard(parent, d) {
  const y = BASE_Y[d.ground];
  const g = new THREE.Group();
  g.position.set(d.x, y, d.z);
  g.rotation.y = d.rot;
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      box(g, 0.16, 2.9, 0.16, sx * 0.8, 1.45, sz * 0.8, WOOD(), true);
    }
  }
  box(g, 1.9, 1.6, 1.7, 0, 3.7, 0, mat('#f5f0e6'), true);
  box(g, 1.94, 0.35, 1.74, 0, 3.9, 0, mat('#d43a2a'));
  box(g, 2.1, 0.14, 1.9, 0, 4.6, 0, mat('#d43a2a'), true);
  box(g, 0.7, 1.0, 0.06, 0, 3.6, 0.88, DARK());
  parent.add(g);
}

// Port crane: base + tall mast + jib / counter-jib + hanging hook line.
function buildCrane(parent, d) {
  const y = BASE_Y[d.ground];
  const g = new THREE.Group();
  g.position.set(d.x, y, d.z);
  g.rotation.y = d.rot;
  const yellow = mat('#f5b81e');
  box(g, 4, 0.8, 4, 0, 0.4, 0, DARK(), true);
  box(g, 1.2, 14, 1.2, 0, 7.8, 0, yellow, true);
  box(g, 1.9, 1.7, 1.9, 0, 15.2, 0.6, mat('#f5f0e6'), true);
  box(g, 10, 0.5, 0.5, 5, 15.8, 0, yellow, true); // jib (+x)
  box(g, 4, 0.5, 0.5, -2.6, 15.8, 0, yellow, true); // counter-jib
  box(g, 1.5, 1.6, 1.1, -4.4, 15.2, 0, DARK(), true); // counterweight
  cyl(g, 0.03, 0.03, 4.5, 9.6, 13.5, 0, DARK(), 5);
  box(g, 0.45, 0.45, 0.45, 9.6, 11.1, 0, DARK());
  parent.add(g);
}

// Shipping container: coloured box + darker door end; every third one is
// stacked two-high (deterministic by index).
const CONTAINER_COLORS = ['#a84a3a', '#3a6aa8', '#4a8a5a', '#c87830']
  .map((c) => mat(c));
function buildContainer(parent, d, i) {
  const y = BASE_Y[d.ground];
  const g = new THREE.Group();
  g.position.set(d.x, y, d.z);
  g.rotation.y = d.rot;
  const levels = i % 3 === 0 ? 2 : 1;
  for (let l = 0; l < levels; l++) {
    const color = CONTAINER_COLORS[(i + l) % 4];
    box(g, 6, 2.6, 2.5, 0, 1.3 + l * 2.6, 0, color, true);
    box(g, 0.14, 2.3, 2.2, 3.02, 1.3 + l * 2.6, 0, DARK());
  }
  parent.add(g);
}

// The pier: wooden deck on posts over the sea, railings, a hut at the end
// and two lamps. Deck runs from PIER.x0 (on the beach) to PIER.x1 (in the
// sea); the coastline at z 0 is x 180, so ~20 m of deck stands over water.
function buildPier(parent) {
  const len = PIER.x1 - PIER.x0;
  const cx = (PIER.x0 + PIER.x1) / 2;
  const g = new THREE.Group();
  box(g, len, 0.4, PIER.width, cx, PIER.deckY, PIER.z, mat('#9a744a'), true);
  for (let x = PIER.x0 + 4; x < PIER.x1; x += 8) {
    for (const s of [-1, 1]) {
      cyl(g, 0.25, 0.25, PIER.deckY, x, PIER.deckY / 2, PIER.z + s * 2.5,
        mat('#6a4a26'), 7);
    }
  }
  for (const s of [-1, 1]) {
    box(g, len, 0.08, 0.08, cx, PIER.deckY + 0.95, PIER.z + s * 2.9, WOOD());
    for (let x = PIER.x0 + 2; x < PIER.x1; x += 4) {
      box(g, 0.08, 0.9, 0.08, x, PIER.deckY + 0.5, PIER.z + s * 2.9, WOOD());
    }
  }
  // Hut at the end: box + pyramid roof + door.
  const hx = PIER.x1 - 8;
  box(g, 4, 3, 4, hx, PIER.deckY + 1.5, PIER.z, mat('#f2e3b3'), true);
  const roof = cone(g, 3.1, 1.8, hx, PIER.deckY + 3.9, PIER.z, mat('#8a4a3a'), 4, true);
  roof.rotation.y = Math.PI / 4;
  box(g, 1.0, 1.9, 0.12, hx - 2.02, PIER.deckY + 0.95, PIER.z, DARK());
  // Two lamps on the deck.
  for (const lx of [PIER.x0 + 16, PIER.x1 - 24]) {
    cyl(g, 0.06, 0.06, 3, lx, PIER.deckY + 1.5, PIER.z - 2.5, DARK(), 6);
    box(g, 0.5, 0.3, 0.3, lx, PIER.deckY + 3.1, PIER.z - 2.5, mat('#ffe08a'));
  }
  parent.add(g);
}

// The ferris wheel: A-frame legs + a slowly rotating wheel with 8 gondolas.
// The wheel group spins around the x-axis (axle); updateDetails() below
// counter-rotates each gondola so the cabins stay level.
let ferris = null;
function buildFerrisWheel(parent) {
  const { x, z, radius, hubY } = FERRIS_WHEEL;
  const g = new THREE.Group();
  g.position.set(x, 0.35, z); // sand district top is 0.40; sink 0.05
  box(g, 1.2, 0.6, radius * 2 + 2, 0, 0.3, 0, DARK(), true); // base beam
  const legLen = Math.hypot(hubY, radius * 0.8);
  for (const s of [-1, 1]) {
    const leg = box(g, 0.5, legLen, 0.5, 0, hubY / 2, s * radius * 0.4,
      mat('#f5f0e6'), true);
    leg.rotation.x = s * Math.atan2(radius * 0.8, hubY);
  }
  const hub = cyl(g, 0.6, 0.6, 1.4, 0, hubY, 0, DARK(), 10);
  hub.rotation.z = Math.PI / 2;

  const wheel = new THREE.Group();
  wheel.position.set(0, hubY, 0);
  g.add(wheel);
  const rim = new THREE.Mesh(
    new THREE.TorusGeometry(radius, 0.18, 6, 24), mat('#e84a3a'));
  rim.castShadow = true;
  wheel.add(rim);
  for (let s = 0; s < 4; s++) {
    const spoke = box(wheel, 0.15, radius * 2, 0.15, 0, 0, 0, mat('#f5f0e6'));
    spoke.rotation.x = (s / 4) * Math.PI;
  }
  const gondolas = [];
  const cabinColors = ['#22d3ee', '#f472b6', '#facc15', '#4ade80']
    .map((c) => mat(c));
  for (let k = 0; k < 8; k++) {
    const a = (k / 8) * Math.PI * 2;
    const holder = new THREE.Group();
    holder.position.set(0, Math.cos(a) * radius, Math.sin(a) * radius);
    wheel.add(holder);
    box(holder, 0.08, 0.9, 0.08, 0, -0.45, 0, DARK());
    box(holder, 1.2, 1.0, 1.0, 0, -1.35, 0, cabinColors[k % 4], true);
    gondolas.push(holder);
  }
  ferris = { wheel, gondolas };
  parent.add(g);
}

// Port dock (F7 fix): the causeway's north end used to read as a black
// asphalt half-disc floating on the water — the shared road-end joint disc
// at the causeway's terminal point. Instead of touching the shared road
// code, a proper wooden dock covers it: a deck over the disc, piles under
// the outer edge, bollards on top. Deck top 0.80 = sidewalk height, so it
// meets the causeway end flush. Position + width come from the causeway
// road in layout.js, never hard-coded.
function buildPortDock(parent) {
  const causeway = LAYOUT.roads.find((r) => r.id === 'causeway');
  const [ex, ez] = causeway.points[0]; // north end, at the water
  const hw = causeway.width / 2;
  const g = new THREE.Group();
  // Deck: wide enough to cover the joint disc (radius hw) with margin,
  // long enough to reach past the disc's water edge and overlap the road.
  const deckW = hw * 2 + 1;
  const deckL = hw * 2 - 1;
  const deckTop = 0.8;
  box(g, deckW, 0.5, deckL, ex, deckTop - 0.25, ez - 2, WOOD(), true);
  // Piles under the outer (north) edge, standing on the seabed.
  for (const px of [-7.5, -2.5, 2.5, 7.5]) {
    cyl(g, 0.3, 0.3, deckTop, ex + px, deckTop / 2, ez - 9, TRUNK(), 6);
  }
  // Bollards on the deck near the outer edge.
  for (const bx of [-6, 0, 6]) {
    box(g, 0.5, 0.5, 0.5, ex + bx, deckTop + 0.25, ez - 6, DARK(), true);
  }
  parent.add(g);
}

const BUILDERS = {
  tree: buildTree, palm: buildPalm, bench: buildBench,
  hydrant: buildHydrant, mailbox: buildMailbox, sign: buildSign,
  planter: buildPlanter, pergola: buildPergola, umbrella: buildUmbrella,
  lifeguard: buildLifeguard, crane: buildCrane, container: buildContainer,
};

export function buildDetails(scene) {
  const group = new THREE.Group();
  DETAILS.forEach((d, i) => {
    const build = BUILDERS[d.type];
    if (build) build(group, d, i);
  });
  buildPier(group);
  buildFerrisWheel(group);
  buildPortDock(group);
  scene.add(group);
  return group;
}
// Revision 4: animated subtree that static batching must leave alone.
export function animatedDetails() { return ferris ? [ferris.wheel] : []; }

// Slow wheel spin; gondolas counter-rotate so the cabins stay level.
export function updateDetails(dt) {
  if (!ferris) return;
  ferris.wheel.rotation.x += dt * 0.12;
  for (const holder of ferris.gondolas) {
    holder.rotation.x = -ferris.wheel.rotation.x;
  }
}
