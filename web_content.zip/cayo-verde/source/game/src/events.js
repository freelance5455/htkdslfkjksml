// events.js — revision 3 random street crimes (between jobs, while you
// are not wanted). One at a time, every ~2 minutes:
//  * PURSE SNATCHER — a thief in a red hoodie sprints away along the
//    sidewalks. Punch him, shoot him or run him down within 45 s:
//    $200 + 40 respect.
//  * ARMORED VAN — a cash van drives the streets. Wreck it within 75 s:
//    it bursts open and drops $600 in cash bundles, but it is a heist:
//    +2 wanted stars.
// A small red card under the job card shows the objective, distance and
// timer; the minimap gets a red blip.

import * as THREE from 'three';
import { buildCharacter } from './characters.js';
import { groundHeightAt, BOXES, LAKE_BOX, pushOut } from './player.js';

const CARD_CSS = `
#crime { position: fixed; left: 18px; top: 150px; width: 300px; z-index: 26; pointer-events: none; display: none;
  background: rgba(20,18,30,0.86); border-left: 5px solid #ff3b4e; border-radius: 9px; padding: 8px 14px;
  color: #fff; font-family: "Segoe UI", Arial, sans-serif; box-shadow: 0 4px 18px rgba(0,0,0,0.35); }
#crime b { color: #ff6b7a; font-size: 11px; letter-spacing: 1.5px; }
#crime .o { font-size: 15px; font-weight: 800; margin-top: 2px; }
#crime .m { font-size: 12px; color: #c9c3d6; margin-top: 2px; display: flex; justify-content: space-between; }
`;

export function createEvents(scene, { state, player, npcs, traffic, combat, economy, missions }) {
  const style = document.createElement('style');
  style.textContent = CARD_CSS;
  document.head.appendChild(style);
  const card = document.createElement('div');
  card.id = 'crime';
  card.innerHTML = '<b>STREET CRIME</b><div class="o"></div><div class="m"><span class="d"></span><span class="t"></span></div>';
  document.body.appendChild(card);
  const $o = card.querySelector('.o');
  const $d = card.querySelector('.d');
  const $t = card.querySelector('.t');

  let ev = null;
  let nextAt = 70 + Math.random() * 40;

  // ---- purse snatcher
  function startSnatcher() {
    const pp = player.position;
    const nodes = npcs.nodes.filter((n) => !n.onRoad && n.next.length
      && Math.hypot(n.x - pp.x, n.z - pp.z) > 30 && Math.hypot(n.x - pp.x, n.z - pp.z) < 60);
    if (!nodes.length) return false;
    const n0 = nodes[Math.floor(Math.random() * nodes.length)];
    const c = buildCharacter({
      skin: '#c98f62', hair: 'buzz', hairColor: '#141414', eyes: 'sleepy', smirk: true,
      top: '#c0392b', jacket: '#c0392b', bottom: '#1d1d22', shoes: '#f0f0ea',
    });
    c.group.rotation.order = 'YXZ';
    c.group.position.set(n0.x, groundHeightAt(n0.x, n0.z), n0.z);
    scene.add(c.group);
    const th = {
      g: c.group, parts: c, x: n0.x, z: n0.z, node: n0, next: n0.next[0], phase: 0, heading: 0,
      alive: true, fall: 0, hp: 60, p: c.group.position, r: 0.45,
    };
    ev = { kind: 'snatcher', th, t: 45, text: 'Stop the purse snatcher' };
    state.emit('notify', { text: 'STREET CRIME · Purse snatcher nearby!', kind: 'crime' });
    return true;
  }
  function stepSnatcher(dt) {
    const th = ev.th;
    if (!th.alive) {
      th.fall = Math.min(1, th.fall + dt / 0.35);
      th.g.rotation.x = -Math.PI / 2 * th.fall;
      return;
    }
    const pp = player.position;
    const dPlayer = Math.hypot(th.x - pp.x, th.z - pp.z);
    // Run node to node, always choosing the exit that leads away.
    const dx = th.next.x - th.x;
    const dz = th.next.z - th.z;
    const d = Math.hypot(dx, dz);
    const sp = dPlayer < 25 ? 5.6 : 3.2;
    if (d < 0.4) {
      th.node = th.next;
      const opts = th.node.next.length ? th.node.next : [th.node];
      th.next = opts.reduce((a, b) => (Math.hypot(b.x - pp.x, b.z - pp.z) > Math.hypot(a.x - pp.x, a.z - pp.z) ? b : a));
    } else {
      const p = { x: th.x + (dx / d) * sp * dt, z: th.z + (dz / d) * sp * dt };
      pushOut(p, BOXES, LAKE_BOX);
      th.x = p.x; th.z = p.z;
      th.heading = Math.atan2(dx, dz);
    }
    th.phase += dt * sp * 2.4;
    const s = Math.sin(th.phase) * 0.95;
    th.parts.armL.rotation.x = s; th.parts.armR.rotation.x = -s;
    th.parts.legL.rotation.x = -s; th.parts.legR.rotation.x = s;
    th.g.position.set(th.x, groundHeightAt(th.x, th.z), th.z);
    th.g.rotation.y = th.heading;
    // Run down by a vehicle.
    if (player.inVehicle && Math.abs(player.speed) > 5 && dPlayer < (player.driving ? 2.4 : 1.2)) catchThief();
  }
  function catchThief() {
    const th = ev.th;
    if (!th.alive) return;
    th.alive = false;
    th.heading = Math.atan2(player.position.x - th.x, player.position.z - th.z);
    th.g.rotation.y = th.heading;
    finish(true, 'Purse recovered', 200, 40);
  }

  // ---- armored van
  function startVan() {
    const car = traffic.spawnCar(true, 'van');
    car.tag = 'armored';
    car.bodyMat.color.set('#2f4f3a');
    car.baseColor.set('#2f4f3a');
    car.name = 'Armored Van';
    car.hp = 220;
    car.cruise = 10;
    ev = { kind: 'van', car, t: 75, text: 'Wreck the armored cash van' };
    state.emit('notify', { text: 'STREET CRIME · Armored cash van spotted', kind: 'crime' });
    return true;
  }

  function finish(ok, msg, cash, xp) {
    if (!ev) return;
    const e = ev;
    ev = null;
    card.style.display = 'none';
    nextAt = state.time + 110 + Math.random() * 60;
    if (ok) {
      if (cash) state.addMoney(cash);
      if (xp) state.addXP(xp, 'crime');
      state.emit('notify', { text: `STREET CRIME STOPPED · ${msg}${cash ? ` · +$${cash}` : ''}`, kind: 'good' });
      state.stats.crimesStopped = (state.stats.crimesStopped || 0) + 1;
    } else state.emit('notify', { text: `Street crime: ${msg}`, kind: 'warn' });
    // Clean the thief body away after a while.
    if (e.kind === 'snatcher') setTimeout(() => scene.remove(e.th.g), 12000);
    if (e.kind === 'van' && e.car) e.car.tag = null;
  }

  combat.addTargets(() => {
    if (!ev || ev.kind !== 'snatcher' || !ev.th.alive) return [];
    const th = ev.th;
    return [{
      kind: 'extra', p: th.p, r: th.r, melee: true,
      hit: (amount, fx, fz, kind) => {
        th.hp -= kind === 'bullet' ? 100 : amount;
        if (th.hp <= 0) { catchThief(); return 'dead'; }
        return 'hit';
      },
    }];
  });

  function update(dt) {
    if (!ev) {
      if (state.time < nextAt || missions.active || state.wanted > 0 || player.frozen) return;
      const ok = Math.random() < 0.55 ? startSnatcher() : startVan();
      if (!ok) nextAt = state.time + 20;
      return;
    }
    ev.t -= dt;
    if (ev.kind === 'snatcher') {
      stepSnatcher(dt);
      if (ev && ev.t <= 0) { scene.remove(ev.th.g); finish(false, 'the thief got away', 0, 0); }
    } else if (ev.kind === 'van') {
      const c = ev.car;
      if (!traffic.cars.includes(c)) { finish(false, 'the van got away', 0, 0); }
      else if (c.burning !== undefined || c.wrecked) {
        for (let k = 0; k < 4; k++) economy.dropCash(c.x + Math.cos(k * 1.6) * 2.5, c.z + Math.sin(k * 1.6) * 2.5, 150);
        state.crime(2, 'heist');
        finish(true, 'Armored van cracked — grab the cash!', 0, 60);
      } else if (ev.t <= 0) { c.tag = null; finish(false, 'the van got away', 0, 0); }
    }
    if (ev) {
      const tg = target();
      card.style.display = 'block';
      $o.textContent = ev.text;
      $d.textContent = tg ? `${Math.round(Math.hypot(tg[0] - player.position.x, tg[1] - player.position.z))} m` : '';
      const s = Math.max(0, Math.ceil(ev.t));
      $t.textContent = `⏱ ${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
    }
  }
  function target() {
    if (!ev) return null;
    if (ev.kind === 'snatcher') return [ev.th.x, ev.th.z];
    return ev.car ? [ev.car.x, ev.car.z] : null;
  }

  return {
    update,
    target,
    get active() { return ev; },
    force(kind) { if (ev) finish(false, 'cancelled', 0, 0); return kind === 'van' ? startVan() : startSnatcher(); },
  };
}

export { THREE };
