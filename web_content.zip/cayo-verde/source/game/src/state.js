// state.js — G2-G5 shared game state: money, health, armour, weapons,
// wanted level, clock and mission progress, plus localStorage save/load.
// Every gameplay module reads and writes this one object; the HUD draws
// from it every frame.

import { GUN_IDS, WEAPON, rankOf } from './weapons.js';

export const SAVE_KEY = 'cayoverde.save.v1';
export const MAX_HP = 100;
export const MAX_ARMOR = 100;
export const MAX_WANTED = 5;
export const CLIP_SIZE = 12;

export function createState() {
  const s = {
    money: 100,
    hp: MAX_HP,
    armor: 0,
    weapon: 'fist',     // weapons.js id of the weapon in hand
    // Revision 2 arsenal: { owned, clip, ammo } per gun.
    weapons: Object.fromEntries(GUN_IDS.map((id) => [id, { owned: false, clip: 0, ammo: 0 }])),
    xp: 0,              // respect XP (weapons.js RANKS)
    stunts: [],         // revision 3: unique stunt jumps found (ramp ids)
    // Revision 3 career stats (pause menu -> Stats).
    stats: {
      playTime: 0, cashEarned: 0, carsStolen: 0, copsDown: 0, maxWanted: 0, distance: 0,
      shotsFired: 0, explosions: 0, crimesStopped: 0, deaths: 0, busts: 0, peopleHit: 0,
    },
    wanted: 0,          // 0..5 stars
    lastCrime: -1e9,    // game-seconds of the last crime
    clock: 16 * 60,     // minutes since midnight (starts 16:00)
    day: 1,
    missionIndex: 0,    // next mission in the chain
    missionsDone: 0,
    weather: 'clear',  // weather.js
    time: 0,            // real seconds since load (crime timers)
    listeners: new Set(),
  };

  s.emit = (type, data) => { for (const fn of s.listeners) fn(type, data); };

  // Compatibility: hasPistol / clip / ammo map onto the arsenal. clip and
  // ammo refer to the gun in hand (the pistol while on fists).
  const gunInHand = () => s.weapons[s.weapon] || s.weapons.pistol;
  Object.defineProperty(s, 'hasPistol', {
    get: () => s.weapons.pistol.owned, set: (v) => { s.weapons.pistol.owned = !!v; },
  });
  Object.defineProperty(s, 'clip', { get: () => gunInHand().clip, set: (v) => { gunInHand().clip = v; } });
  Object.defineProperty(s, 'ammo', { get: () => gunInHand().ammo, set: (v) => { gunInHand().ammo = v; } });
  Object.defineProperty(s, 'rankInfo', { get: () => rankOf(s.xp) });

  s.giveWeapon = (id, rounds) => {
    const w = s.weapons[id];
    const first = !w.owned;
    w.owned = true;
    if (first) { w.clip = Math.min(WEAPON[id].clip, rounds); w.ammo += rounds - w.clip; } else w.ammo += rounds;
    s.weapon = id;
    s.emit('weaponGet', { id, first });
  };
  s.addXP = (n, why = '') => {
    const before = rankOf(s.xp).rank;
    s.xp = Math.max(0, Math.round(s.xp + n));
    s.emit('xp', { n, why });
    const after = rankOf(s.xp);
    if (after.rank > before) s.emit('rankup', after);
  };
  s.on = (fn) => { s.listeners.add(fn); return () => s.listeners.delete(fn); };

  s.addMoney = (n) => {
    s.money = Math.max(0, Math.round(s.money + n));
    s.emit('money', n);
  };
  s.charge = (n) => { // spend if affordable
    if (s.money < n) return false;
    s.addMoney(-n);
    return true;
  };
  s.heal = (n) => { s.hp = Math.min(MAX_HP, s.hp + n); };
  s.addArmor = (n) => { s.armor = Math.min(MAX_ARMOR, s.armor + n); };

  // Damage soaks into armour first. Returns true when it was lethal.
  s.hurt = (n) => {
    if (s.hp <= 0) return false;
    const soak = Math.min(s.armor, n);
    s.armor -= soak;
    s.hp = Math.max(0, s.hp - (n - soak));
    s.emit('hurt', n);
    return s.hp <= 0;
  };

  // A crime raises the wanted level (capped at 5) and restarts the
  // 30-second cool-down.
  s.crime = (stars = 1, why = '') => {
    const before = s.wanted;
    s.wanted = Math.min(MAX_WANTED, s.wanted + stars);
    s.lastCrime = s.time;
    if (s.wanted !== before) s.emit('wanted', { before, why });
  };
  s.clearWanted = () => {
    const before = s.wanted;
    s.wanted = 0;
    if (before) s.emit('wanted', { before, why: 'clear' });
  };

  s.givePistol = (rounds) => s.giveWeapon('pistol', rounds);

  // ------------------------------------------------------------ save/load
  s.serialize = (player) => ({
    v: 1,
    money: s.money, hp: s.hp, armor: s.armor,
    weapons: JSON.parse(JSON.stringify(s.weapons)), weapon: s.weapon, xp: s.xp,
    stunts: [...s.stunts], stats: { ...s.stats },
    clock: s.clock, day: s.day,
    missionIndex: s.missionIndex, missionsDone: s.missionsDone, weather: s.weather,
    pos: player ? { x: +player.position.x.toFixed(2), z: +player.position.z.toFixed(2) } : null,
    savedAt: new Date().toISOString(),
  });
  s.save = (player) => {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(s.serialize(player)));
      s.emit('saved');
      return true;
    } catch (e) { return false; }
  };
  s.readSave = () => {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      const d = raw ? JSON.parse(raw) : null;
      return d && d.v === 1 ? d : null;
    } catch (e) { return null; }
  };
  s.load = (d) => {
    for (const k of ['money', 'hp', 'armor', 'clock', 'day', 'missionIndex', 'missionsDone', 'weather', 'xp']) {
      if (d[k] !== undefined) s[k] = d[k];
    }
    if (Array.isArray(d.stunts)) s.stunts = [...d.stunts];
    if (d.stats) Object.assign(s.stats, d.stats);
    if (d.weapons) {
      for (const id of GUN_IDS) if (d.weapons[id]) Object.assign(s.weapons[id], d.weapons[id]);
    } else if (d.hasPistol) { // revision-1 save
      Object.assign(s.weapons.pistol, { owned: true, clip: d.clip || 0, ammo: d.ammo || 0 });
    }
    s.weapon = d.weapon && (d.weapon === 'fist' || (s.weapons[d.weapon] && s.weapons[d.weapon].owned)) ? d.weapon : 'fist';
    if (s.hp <= 0) s.hp = MAX_HP;
  };
  s.deleteSave = () => { try { localStorage.removeItem(SAVE_KEY); } catch (e) { /* private mode */ } };
  return s;
}
