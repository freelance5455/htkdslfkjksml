// vehicles.js — low-poly civilian car models (traffic.js).
// Seven types: sedan, hatchback, taxi, pickup, van, sports, bus. Each car
// is built from boxes/cylinders that are MERGED per material (body
// colour, dark trim + wheels, glass, lights), so a car is 4-5 draw calls.
// Front = +z, origin at road level, centred.

import * as THREE from 'three';

// name: shown on the vehicle HUD panel. top: top speed (m/s) when the
// player drives, accel (m/s^2), grip: steering response, armor: damage
// taken multiplier (lower = tougher), gears: gear count for the HUD.
export const CAR_TYPES = {
  sedan:  { name: 'Brisa Sedan',   L: 4.4, W: 1.85, cruise: 11,  top: 33, accel: 9,  grip: 1.0,  armor: 1.0, gears: 5, colors: ['#c0392b', '#2c3e50', '#ecf0f1', '#7f8c8d', '#2e86de', '#16a085'] },
  hatch:  { name: 'Pico Hatch',    L: 3.6, W: 1.75, cruise: 10,  top: 29, accel: 9.5, grip: 1.15, armor: 1.1, gears: 5, colors: ['#e67e22', '#9b59b6', '#f1c40f', '#1abc9c', '#e84393', '#dfe6e9'] },
  taxi:   { name: 'Verde Cab',     L: 4.4, W: 1.85, cruise: 11.5, top: 32, accel: 8.5, grip: 1.0, armor: 0.95, gears: 5, colors: ['#f6c90e'] },
  pickup: { name: 'Ranchero 4x4',  L: 5.0, W: 1.95, cruise: 10,  top: 30, accel: 8,  grip: 0.85, armor: 0.75, gears: 5, colors: ['#8e5b3a', '#34495e', '#c0392b', '#ecf0f1', '#27ae60'] },
  van:    { name: 'Mula Van',      L: 5.0, W: 2.0, cruise: 9,    top: 26, accel: 6.5, grip: 0.75, armor: 0.7, gears: 4, colors: ['#ecf0f1', '#95a5a6', '#2980b9', '#d35400'] },
  cabrio: { name: 'Sol Cabrio',    L: 4.4, W: 1.9, cruise: 12,   top: 40, accel: 11.5, grip: 1.15, armor: 1.15, gears: 6, colors: ['#ff7aa8', '#f2f2ee', '#2ec4d6', '#ffcc00', '#e8573f'] },
  sports: { name: 'Relampago GT',  L: 4.3, W: 1.95, cruise: 14,  top: 46, accel: 14, grip: 1.3,  armor: 1.2, gears: 6, colors: ['#ff2d55', '#ffcc00', '#00d2d3', '#111111', '#ff6b00'] },
  bus:    { name: 'Cayo Transit',  L: 10, W: 2.5, cruise: 8,     top: 22, accel: 4.5, grip: 0.55, armor: 0.5, gears: 4, colors: ['#e1b12c', '#0097e6'] },
};

// type -> relative spawn weight
export const TYPE_WEIGHTS = [['sedan', 5], ['hatch', 3], ['taxi', 3], ['pickup', 2], ['van', 2], ['sports', 2], ['cabrio', 2], ['bus', 1]];

const mats = new Map();
function mat(color, opts = {}) {
  const key = color + JSON.stringify(opts);
  if (!mats.has(key)) {
    mats.set(key, new THREE.MeshStandardMaterial({
      color, flatShading: true, roughness: opts.r ?? 0.55, metalness: opts.m ?? 0.1,
      emissive: opts.e || 0x000000, emissiveIntensity: opts.e ? (opts.ei ?? 1) : 0,
    }));
  }
  return mats.get(key);
}

// Merge transformed primitives into one non-indexed geometry.
function merge(parts) {
  const geos = parts.map(({ g, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0 }) => {
    const c = g.index ? g.toNonIndexed() : g.clone();
    const m = new THREE.Matrix4().compose(
      new THREE.Vector3(x, y, z),
      new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz)),
      new THREE.Vector3(1, 1, 1));
    c.applyMatrix4(m);
    return c;
  });
  let n = 0;
  for (const g of geos) n += g.attributes.position.count;
  const pos = new Float32Array(n * 3);
  const nor = new Float32Array(n * 3);
  let o = 0;
  for (const g of geos) {
    pos.set(g.attributes.position.array, o * 3);
    nor.set(g.attributes.normal.array, o * 3);
    o += g.attributes.position.count;
    g.dispose();
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  return out;
}

const B = (w, h, d) => new THREE.BoxGeometry(w, h, d);

// Extruded side profile: pts are [z, y] (z forward), extruded across x.
function side(pts, width) {
  const sh = new THREE.Shape();
  pts.forEach(([z, y], i) => (i ? sh.lineTo(z, y) : sh.moveTo(z, y)));
  sh.closePath();
  const geo = new THREE.ExtrudeGeometry(sh, { depth: width, bevelEnabled: false });
  geo.rotateY(-Math.PI / 2);   // shape x -> world z
  geo.translate(width / 2, 0, 0);
  geo.deleteAttribute('uv');
  return geo;
}

// Shared vertex-coloured material for wheels + drivers.
const WHEEL_MAT = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.6, metalness: 0.25, flatShading: true });
function colored(geo, hex) {
  const g = geo.index ? geo.toNonIndexed() : geo;
  const c = new THREE.Color(hex);
  const n = g.attributes.position.count;
  const a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(a, 3));
  if (g.attributes.uv) g.deleteAttribute('uv');
  return g;
}
function joinColored(list) {
  let n = 0;
  for (const g of list) n += g.attributes.position.count;
  const pos = new Float32Array(n * 3); const nor = new Float32Array(n * 3); const col = new Float32Array(n * 3);
  let o = 0;
  for (const g of list) {
    pos.set(g.attributes.position.array, o * 3);
    nor.set(g.attributes.normal.array, o * 3);
    col.set(g.attributes.color.array, o * 3);
    o += g.attributes.position.count;
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  out.setAttribute('color', new THREE.BufferAttribute(col, 3));
  out.computeBoundingSphere();
  return out;
}
const wheelCache = new Map();
function wheelGeo(r, outSide) {
  const key = `${r}|${outSide}`;
  if (wheelCache.has(key)) return wheelCache.get(key);
  const tyre = colored(new THREE.CylinderGeometry(r, r, 0.28, 14).rotateZ(Math.PI / 2), '#15161a');
  const rim = colored(new THREE.CylinderGeometry(r * 0.62, r * 0.62, 0.05, 10).rotateZ(Math.PI / 2).translate(outSide * 0.13, 0, 0), '#c9ccd2');
  const hub = colored(new THREE.CylinderGeometry(r * 0.18, r * 0.18, 0.07, 6).rotateZ(Math.PI / 2).translate(outSide * 0.15, 0, 0), '#4a4d55');
  // Spokes make the spin visible.
  const spokes = [];
  for (let k = 0; k < 5; k++) {
    const sp = new THREE.BoxGeometry(0.03, r * 1.15, 0.07);
    sp.rotateX((k / 5) * Math.PI);
    sp.translate(outSide * 0.155, 0, 0);
    spokes.push(colored(sp, '#8d9099'));
  }
  const g = joinColored([tyre, rim, hub, ...spokes]);
  wheelCache.set(key, g);
  return g;
}
const DRIVER_SKINS = ['#f1c7a1', '#c98f62', '#8d5b3a', '#e2b08a'];
const DRIVER_TOPS = ['#1f8fe0', '#e8e4da', '#e9573f', '#2fae7a', '#1d2433', '#f2b632'];
let driverN = 0;
function driverGeo() {
  const skin = DRIVER_SKINS[driverN % 4];
  const top = DRIVER_TOPS[driverN % 6];
  const hair = ['#3b2416', '#141414', '#f2c230', '#6b3f22'][driverN % 4];
  driverN += 1;
  const torso = colored(new THREE.BoxGeometry(0.38, 0.5, 0.24).translate(0, 0.3, 0), top);
  const head = colored(new THREE.SphereGeometry(0.15, 10, 8).scale(1, 1.2, 1.05).translate(0, 0.72, 0.02), skin);
  const hr = colored(new THREE.SphereGeometry(0.16, 8, 6, 0, Math.PI * 2, 0, Math.PI * 0.5).scale(1, 1.1, 1.08).translate(0, 0.76, 0), hair);
  const armL = colored(new THREE.BoxGeometry(0.09, 0.09, 0.42).translate(-0.17, 0.42, 0.22), top);
  const armR = colored(new THREE.BoxGeometry(0.09, 0.09, 0.42).translate(0.17, 0.42, 0.22), top);
  const wheelRing = colored(new THREE.TorusGeometry(0.15, 0.025, 5, 12).rotateX(-0.4).translate(0, 0.45, 0.44), '#1a1a1a');
  return joinColored([torso, head, hr, armL, armR, wheelRing]);
}

// Spin wheels by distance travelled; steer the front pair by turn rate.
export function animateWheels(car, dt) {
  if (!car.wheels || dt <= 0) return;
  let dh = car.heading - car.prevHeading;
  while (dh > Math.PI) dh -= Math.PI * 2;
  while (dh < -Math.PI) dh += Math.PI * 2;
  car.prevHeading = car.heading;
  const sp = car.speed || 0;
  const steer = Math.abs(sp) > 0.5 ? THREE.MathUtils.clamp((dh / dt) / Math.max(1, Math.abs(sp)) * 6, -0.5, 0.5) : 0;
  for (const w of car.wheels) {
    w.mesh.rotation.x += (sp * dt) / w.r;
    if (w.front) w.pivot.rotation.y += (steer * Math.sign(sp || 1) - w.pivot.rotation.y) * Math.min(1, dt * 10);
  }
}

// Returns { group, bodyMat, L, W, type }.
export function buildCar(type, color) {
  const T = CAR_TYPES[type];
  const { L, W } = T;
  const body = [];
  const dark = [];
  const glass = [];
  const lights = [];
  const tail = [];
  const wheelSpots = [];
  const wheel = (r, x, z) => { wheelSpots.push({ r, x, z }); };
  let seat = { x: -0.38, y: 0.62, z: -0.2 }; // driver hip position
  const wheelsAt = (r, zs) => { for (const z of zs) { wheel(r, -W / 2 + 0.1, z); wheel(r, W / 2 - 0.1, z); } };
  const headTail = (y, zf, zb, wide = 0.55) => {
    lights.push({ g: B(0.42, 0.14, 0.06), x: -W / 2 + wide / 2 + 0.1, y, z: zf });
    lights.push({ g: B(0.42, 0.14, 0.06), x: W / 2 - wide / 2 - 0.1, y, z: zf });
    tail.push({ g: B(0.38, 0.14, 0.06), x: -W / 2 + 0.3, y, z: zb });
    tail.push({ g: B(0.38, 0.14, 0.06), x: W / 2 - 0.3, y, z: zb });
  };

  if (type === 'sedan' || type === 'taxi') {
    body.push({ g: B(W, 0.55, L), y: 0.62 });
    body.push({ g: B(W - 0.14, 0.52, 2.2), y: 1.15, z: -0.25 });
    glass.push({ g: B(W - 0.1, 0.4, 2.0), y: 1.15, z: -0.25 });
    dark.push({ g: B(W + 0.02, 0.14, L + 0.04), y: 0.38 });
    wheelsAt(0.34, [L / 2 - 0.85, -L / 2 + 0.85]);
    headTail(0.72, L / 2 + 0.02, -L / 2 - 0.02);
    if (type === 'taxi') {
      lights.push({ g: B(0.7, 0.22, 0.3), y: 1.53, z: -0.25 });
      dark.push({ g: B(W + 0.03, 0.12, 0.9), y: 0.7, z: 0.0 }); // checker band
    }
  } else if (type === 'hatch') {
    body.push({ g: B(W, 0.55, L), y: 0.6 });
    body.push({ g: B(W - 0.12, 0.55, 2.1), y: 1.12, z: -0.45 });
    glass.push({ g: B(W - 0.08, 0.42, 1.9), y: 1.12, z: -0.42 });
    dark.push({ g: B(W + 0.02, 0.14, L + 0.04), y: 0.36 });
    wheelsAt(0.32, [L / 2 - 0.7, -L / 2 + 0.7]);
    headTail(0.7, L / 2 + 0.02, -L / 2 - 0.02);
  } else if (type === 'pickup') {
    body.push({ g: B(W, 0.6, L), y: 0.72 });
    body.push({ g: B(W - 0.1, 0.62, 1.8), y: 1.33, z: 0.55 });
    glass.push({ g: B(W - 0.06, 0.44, 1.6), y: 1.35, z: 0.58 });
    // Open bed: side walls.
    body.push({ g: B(0.1, 0.38, 2.0), x: -W / 2 + 0.05, y: 1.2, z: -1.4 });
    body.push({ g: B(0.1, 0.38, 2.0), x: W / 2 - 0.05, y: 1.2, z: -1.4 });
    body.push({ g: B(W, 0.38, 0.1), y: 1.2, z: -L / 2 + 0.05 });
    dark.push({ g: B(W - 0.2, 0.05, 2.0), y: 1.04, z: -1.4 });
    dark.push({ g: B(W + 0.04, 0.16, L + 0.06), y: 0.42 });
    wheelsAt(0.4, [L / 2 - 0.9, -L / 2 + 0.95]);
    headTail(0.85, L / 2 + 0.02, -L / 2 - 0.02);
  } else if (type === 'van') {
    body.push({ g: B(W, 1.7, L - 0.6), y: 1.3, z: -0.3 });
    body.push({ g: B(W, 0.9, 0.9), y: 0.85, z: L / 2 - 0.45 });
    glass.push({ g: B(W - 0.1, 0.55, 0.06), y: 1.65, z: L / 2 - 0.62, rx: -0.35 });
    glass.push({ g: B(0.04, 0.45, 0.9), x: -W / 2 - 0.01, y: 1.6, z: 1.4 });
    glass.push({ g: B(0.04, 0.45, 0.9), x: W / 2 + 0.01, y: 1.6, z: 1.4 });
    dark.push({ g: B(W + 0.04, 0.16, L + 0.04), y: 0.42 });
    wheelsAt(0.36, [L / 2 - 0.85, -L / 2 + 0.9]);
    headTail(0.85, L / 2 + 0.02, -L / 2 - 0.02);
  } else if (type === 'sports') {
    // Revision 5: wedge profile (low nose, raked windscreen, fastback).
    body.push({ g: side([[-L / 2, 0.3], [L / 2, 0.3], [L / 2, 0.55], [L / 2 - 1.3, 0.78], [-L / 2 + 0.3, 0.86], [-L / 2, 0.8]], W) });
    body.push({ g: side([[0.75, 0.78], [-0.15, 1.18], [-1.25, 1.12], [-1.9, 0.86], [-L / 2 + 0.6, 0.84]], W - 0.34) });
    glass.push({ g: side([[0.68, 0.82], [-0.1, 1.15], [-1.2, 1.09], [-1.75, 0.88]], W - 0.3) });
    seat = { x: -0.36, y: 0.42, z: -0.35 };
    dark.push({ g: B(W, 0.06, 0.5), y: 1.12, z: -L / 2 + 0.3 });            // spoiler wing
    dark.push({ g: B(0.08, 0.3, 0.1), x: -0.6, y: 0.85, z: -L / 2 + 0.3 });
    dark.push({ g: B(0.08, 0.3, 0.1), x: 0.6, y: 0.85, z: -L / 2 + 0.3 });
    dark.push({ g: B(W + 0.02, 0.12, L + 0.04), y: 0.3 });
    wheelsAt(0.33, [L / 2 - 0.85, -L / 2 + 0.8]);
    headTail(0.55, L / 2 + 0.02, -L / 2 - 0.02, 0.7);
  } else if (type === 'cabrio') {
    // Open-top convertible: low tub, windscreen frame, seats, roll bar.
    body.push({ g: side([[-L / 2, 0.32], [L / 2, 0.32], [L / 2, 0.62], [L / 2 - 1.1, 0.8], [-L / 2 + 0.2, 0.84], [-L / 2, 0.76]], W) });
    dark.push({ g: B(W - 0.3, 0.08, 1.9), y: 0.66, z: -0.35 });                // cabin floor
    glass.push({ g: B(W - 0.2, 0.42, 0.05), y: 1.0, z: 0.55, rx: -0.5 });       // windscreen
    dark.push({ g: B(W - 0.16, 0.05, 0.06), y: 1.2, z: 0.45 });                // screen frame top
    for (const sx of [-0.4, 0.4]) {
      dark.push({ g: B(0.5, 0.08, 0.5), x: sx, y: 0.72, z: -0.35 });           // seat base
      dark.push({ g: B(0.5, 0.55, 0.1), x: sx, y: 0.98, z: -0.62, rx: 0.15 }); // seat back
    }
    seat = { x: -0.4, y: 0.6, z: -0.35 };
    wheelsAt(0.34, [L / 2 - 0.85, -L / 2 + 0.85]);
    headTail(0.6, L / 2 + 0.02, -L / 2 - 0.02, 0.65);
  } else if (type === 'bus') {
    body.push({ g: B(W, 2.3, L), y: 1.65 });
    glass.push({ g: B(W + 0.03, 0.75, L - 1.6), y: 2.05, z: -0.4 });
    glass.push({ g: B(W - 0.2, 0.9, 0.06), y: 1.95, z: L / 2 + 0.01 });
    dark.push({ g: B(W + 0.04, 0.25, L + 0.04), y: 0.55 });
    body.push({ g: B(W - 0.3, 0.15, L - 1), y: 2.88 });
    wheelsAt(0.5, [L / 2 - 1.6, -L / 2 + 1.8]);
    headTail(0.95, L / 2 + 0.02, -L / 2 - 0.02);
    lights.push({ g: B(1.4, 0.25, 0.06), y: 2.6, z: L / 2 + 0.02 }); // route sign
  }

  const bodyMat = new THREE.MeshStandardMaterial({ color, flatShading: true, roughness: 0.45, metalness: 0.2 });
  const g = new THREE.Group();
  const add = (parts, m, shadow = true) => {
    if (!parts.length) return;
    const mesh = new THREE.Mesh(merge(parts), m);
    mesh.castShadow = shadow;
    g.add(mesh);
  };
  add(body, bodyMat);
  add(dark, mat('#16171b', { r: 0.8 }));
  add(glass, mat('#1c2733', { r: 0.2, m: 0.4 }), false);
  add(lights, mat('#fff6cc', { e: 0xfff1b0, ei: 0.8 }), false);
  add(tail, mat('#8a1010', { e: 0xff2020, ei: 0.6 }), false);
  // Revision 5: real wheels (tyre + silver rim + hub), front pair steers,
  // all spin with speed (animateWheels).
  const wheels = wheelSpots.map((w) => {
    const pivot = new THREE.Group();
    pivot.position.set(w.x, w.r, w.z);
    const m = new THREE.Mesh(wheelGeo(w.r, w.x < 0 ? -1 : 1), WHEEL_MAT);
    m.castShadow = true;
    pivot.add(m);
    g.add(pivot);
    return { pivot, mesh: m, front: w.z > 0, r: w.r };
  });
  // Driver: a seated low-poly person (head, torso, arms on the wheel).
  let driver = null;
  if (type !== 'bus' || true) {
    driver = new THREE.Mesh(driverGeo(), WHEEL_MAT);
    driver.position.set(seat.x, seat.y, seat.z);
    g.add(driver);
    if (type === 'bus') driver.position.set(-0.7, 1.0, L / 2 - 1.2);
  }
  return {
    group: g, bodyMat, L, W, type, name: T.name, baseColor: new THREE.Color(color),
    wheels, driverMesh: driver, prevHeading: 0, wheelSpin: 0,
  };
}
