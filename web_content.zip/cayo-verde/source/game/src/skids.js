// skids.js — revision 4 driving feel: tyre marks + tyre smoke.
// While the player's car slides (player.slip: handbrake drifts, fast
// cornering) the rear wheels lay dark rubber strips on the ground (a ring
// buffer of 700 quads in ONE mesh, oldest overwritten) and puff grey
// smoke. Burnouts at low speed smoke too.

import * as THREE from 'three';
import { groundHeightAt } from './player.js';

const MAX = 700;
const HALF_W = 0.13;

export function createSkids(scene, { player }) {
  const pos = new Float32Array(MAX * 4 * 3);
  const idx = [];
  for (let i = 0; i < MAX; i++) {
    const b = i * 4;
    idx.push(b, b + 1, b + 2, b, b + 2, b + 3);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setIndex(idx);
  const mat = new THREE.MeshBasicMaterial({
    color: 0x111114, transparent: true, opacity: 0.55, depthWrite: false,
    polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2,
  });
  const marks = new THREE.Mesh(geo, mat);
  marks.frustumCulled = false;
  marks.renderOrder = 1;
  scene.add(marks);
  let head = 0;
  const last = [null, null];

  // Smoke pool.
  const puffGeo = new THREE.IcosahedronGeometry(0.32, 1);
  const puffs = [];
  for (let i = 0; i < 48; i++) {
    const m = new THREE.Mesh(puffGeo, new THREE.MeshBasicMaterial({ color: 0xd8d8d8, transparent: true, opacity: 0, depthWrite: false }));
    m.visible = false;
    scene.add(m);
    puffs.push({ m, t: 0 });
  }
  let puffI = 0;
  let puffCd = 0;

  function quad(a, b) {
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    const l = Math.hypot(dx, dz);
    if (l < 0.05) return false;
    const nx = (-dz / l) * HALF_W;
    const nz = (dx / l) * HALF_W;
    const o = head * 12;
    const pts = [[a.x - nx, a.y, a.z - nz], [a.x + nx, a.y, a.z + nz], [b.x + nx, b.y, b.z + nz], [b.x - nx, b.y, b.z - nz]];
    pts.forEach((p, k) => { pos[o + k * 3] = p[0]; pos[o + k * 3 + 1] = p[1]; pos[o + k * 3 + 2] = p[2]; });
    head = (head + 1) % MAX;
    geo.attributes.position.needsUpdate = true;
    return true;
  }

  function update(dt) {
    puffCd -= dt;
    const car = player.car;
    const sp = Math.abs(player.speed);
    const skidding = car && !player.airborne && ((player.slip > 0.16 && sp > 5) || (player.boosting && sp < 8));
    if (skidding) {
      const hx = Math.sin(car.heading);
      const hz = Math.cos(car.heading);
      const back = car.L / 2 - 0.8;
      for (let w = 0; w < 2; w++) {
        const side = (w ? 1 : -1) * (car.W / 2 - 0.3);
        const x = car.x - hx * back + hz * side;
        const z = car.z - hz * back - hx * side;
        const p = { x, y: groundHeightAt(x, z) + 0.035, z };
        if (last[w] && Math.hypot(p.x - last[w].x, p.z - last[w].z) > 0.35) {
          quad(last[w], p);
          last[w] = p;
        } else if (!last[w]) last[w] = p;
        if (puffCd <= 0) {
          const pf = puffs[puffI++ % puffs.length];
          pf.m.position.set(x, p.y + 0.3, z);
          pf.m.scale.setScalar(0.6);
          pf.m.visible = true;
          pf.t = 1.1;
        }
      }
      if (puffCd <= 0) puffCd = 0.06;
    } else { last[0] = null; last[1] = null; }

    for (const pf of puffs) {
      if (pf.t <= 0) continue;
      pf.t -= dt;
      pf.m.position.y += dt * 0.9;
      pf.m.scale.multiplyScalar(1 + dt * 1.6);
      pf.m.material.opacity = Math.max(0, pf.t / 1.1) * 0.32;
      if (pf.t <= 0) pf.m.visible = false;
    }
  }

  return { update, get skidding() { return !!(player.car && player.slip > 0.16); } };
}
