// settings.js — revision 3 player settings (pause menu -> Settings tab),
// persisted in localStorage separately from the save game.

const KEY = 'cayoverde.settings.v1';
const DEFAULTS = {
  master: 0.8,     // 0..1 overall volume
  music: 0.7,      // 0..1 radio volume
  bloom: true,     // glow + colour grade post-process
  shadows: true,   // sun shadows
  shake: true,     // camera shake on explosions / crashes / big guns
  speedFov: true,  // field of view widens with speed and nitro
  adaptiveRes: true, // revision 4: lower the render resolution when the frame rate drops
  showFps: false,  // revision 4: frame-rate counter
};

export function createSettings() {
  let data = { ...DEFAULTS };
  try { Object.assign(data, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) { /* ignore */ }
  const listeners = new Set();
  return {
    get: (k) => data[k],
    set(k, v) {
      data[k] = v;
      try { localStorage.setItem(KEY, JSON.stringify(data)); } catch (e) { /* private mode */ }
      for (const fn of listeners) fn(k, v);
    },
    on(fn) { listeners.add(fn); },
    get all() { return { ...data }; },
  };
}
