// player.js — F5a playable core for CAYO VERDE.
// Third-person player: cartoon character (characters.js), WASD movement
// relative to the follow camera, AABB push-out collision vs the BUILDINGS
// list (R3: BLOCKS are parcels now, not footprints), ground height from
// the layout (roads / sidewalks / districts), and a no-clip follow camera
// (segment-vs-AABB against building boxes). O toggles the orbit camera
// (verification mode); the player stands still in orbit mode.

import * as THREE from 'three';
import {
  LAYOUT, SIDEWALKS, pointInPolygon, districtById, roadById,
} from './layout.js';
import { BUILDINGS } from './buildings.js';
import { buildCharacter, PRESETS } from './characters.js';
import { createBike } from './bikes.js';
import { RAMPS } from './places.js';

const RADIUS = 0.4;   // player collision radius (m)
const RIDE_RADIUS = 0.6; // bike + rider collision radius (m)
const WALK = 5;       // walk speed (m/s)
const SPRINT = 9;     // sprint speed with Shift (m/s)
const RIDE = 15;      // bike cruise speed (m/s)
const RIDE_SPRINT = 22; // bike top speed with Shift (m/s)
const RIDE_REVERSE = 3; // bike reverse speed (m/s)
const MOUNT_RADIUS = 2.5; // max distance to mount the bike (m)
const FLOOR_H = 3;    // metres per building floor (matches buildings.js)
const EYE_Y = 1.55;   // camera look-at height above the feet
const CAM_MIN = 4, CAM_MAX = 14, CAM_DIST = 8;

// Spawn: east sidewalk of Cayo Blvd, downtown (between Market St z=-48 and
// Main St z=0; x=9.5 is the sidewalk centreline: half-width 7 + 5/2).
export const SPAWN = { x: 9.5, z: -20 };

// ------------------------------------------- geometry helpers (local copies)
// layout.js keeps distanceToPolyline private; this is a fresh implementation.
function distToPolyline(x, z, pts, closed) {
  let best = Infinity;
  const n = pts.length;
  const count = closed ? n : n - 1;
  for (let i = 0; i < count; i++) {
    const a = pts[i];
    const b = pts[(i + 1) % n];
    const dx = b[0] - a[0];
    const dz = b[1] - a[1];
    const len2 = dx * dx + dz * dz || 1;
    let t = ((x - a[0]) * dx + (z - a[1]) * dz) / len2;
    t = Math.max(0, Math.min(1, t));
    const d = Math.hypot(x - (a[0] + t * dx), z - (a[1] + t * dz));
    if (d < best) best = d;
  }
  return best;
}

// Building AABBs, expanded by a collision radius. R3: the boxes come
// from the BUILDINGS list (buildings.js), generated from the parcels —
// BLOCKS are parcels now, not footprints. All buildings have rot 0; a
// 90-degree rot swaps w/d (handled defensively). Two sets: on foot
// (RADIUS) and on the bike (RIDE_RADIUS — the bike is wider).
export function buildBoxes(radius) {
  return BUILDINGS.map((b) => {
    const swap = b.rot % 180 === 90;
    const hw = (swap ? b.d : b.w) / 2 + radius;
    const hd = (swap ? b.w : b.d) / 2 + radius;
    return {
      minX: b.x - hw, maxX: b.x + hw,
      minZ: b.z - hd, maxZ: b.z + hd,
      top: b.floors * FLOOR_H + 0.5,
    };
  });
}
export const BOXES = buildBoxes(RADIUS);
const RIDE_BOXES = buildBoxes(RIDE_RADIUS);
const CAR_RADIUS = 1.15;
const CAR_BOXES = buildBoxes(CAR_RADIUS);

// Lake bounding box (the kidney polygon; the bbox over-blocks two small
// lawn corners — acceptable, the player just walks around them).
function buildLakeBox(radius) {
  let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
  for (const [x, z] of LAYOUT.lake) {
    if (x < minX) minX = x;
    if (x > maxX) maxX = x;
    if (z < minZ) minZ = z;
    if (z > maxZ) maxZ = z;
  }
  return {
    minX: minX - radius, maxX: maxX + radius,
    minZ: minZ - radius, maxZ: maxZ + radius,
  };
}
export const LAKE_BOX = buildLakeBox(RADIUS);
const RIDE_LAKE_BOX = buildLakeBox(RIDE_RADIUS);
const CAR_LAKE_BOX = buildLakeBox(CAR_RADIUS);

const SAND_POLYS = ['vice-beach', 'south-shore']
  .map((id) => districtById(id).polygon);
const PARK_POLY = districtById('central-park').polygon;

// Ground height under a point: district base (island 0.20, sand 0.40,
// park lawn 0.50), overridden by road asphalt (0.70) and sidewalk tops
// (0.80). Ground y values match ground.js / roads.js.
export function groundHeightAt(x, z) {
  let y = 0.2;
  if (SAND_POLYS.some((p) => pointInPolygon(x, z, p))) y = 0.4;
  else if (pointInPolygon(x, z, PARK_POLY)) y = 0.5;
  for (const r of LAYOUT.roads) {
    if (distToPolyline(x, z, r.points, !!r.closed) <= r.width / 2) return 0.7;
  }
  for (const s of SIDEWALKS) {
    const road = roadById(s.roadId);
    if (distToPolyline(x, z, s.points, !!(road && road.closed)) <= s.width / 2) return 0.8;
  }
  return y;
}

export function insideBox(x, z, b) {
  return x > b.minX && x < b.maxX && z > b.minZ && z < b.maxZ;
}

export function insideAnyCollider(x, z, boxes, lakeBox) {
  if (insideBox(x, z, lakeBox)) return true;
  for (const b of boxes) if (insideBox(x, z, b)) return true;
  return false;
}

// Push a point out of every collider it sits inside (shortest exit side).
// Mutates pos ({x, z}) in place; returns true if it moved.
export function pushOut(pos, boxes, lakeBox) {
  let moved = false;
  const push = (b) => {
    if (!insideBox(pos.x, pos.z, b)) return;
    const dxl = pos.x - b.minX;
    const dxr = b.maxX - pos.x;
    const dzl = pos.z - b.minZ;
    const dzr = b.maxZ - pos.z;
    const m = Math.min(dxl, dxr, dzl, dzr);
    if (m === dxl) pos.x = b.minX;
    else if (m === dxr) pos.x = b.maxX;
    else if (m === dzl) pos.z = b.minZ;
    else pos.z = b.maxZ;
    moved = true;
  };
  for (const b of boxes) push(b);
  push(lakeBox);
  return moved;
}

// Segment-vs-AABB entry t in [0, 1], or null. The box spans y 0..top.
// Slab method, pure math — no raycaster needed.
export function segmentBoxT(ax, ay, az, bx, by, bz, b) {
  let tmin = 0;
  let tmax = 1;
  const axes = [
    [ax, bx - ax, b.minX, b.maxX],
    [ay, by - ay, 0, b.top],
    [az, bz - az, b.minZ, b.maxZ],
  ];
  for (const [o, d, lo, hi] of axes) {
    if (Math.abs(d) < 1e-9) {
      if (o < lo || o > hi) return null;
    } else {
      let t1 = (lo - o) / d;
      let t2 = (hi - o) / d;
      if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
      if (t1 > tmin) tmin = t1;
      if (t2 < tmax) tmax = t2;
      if (tmin > tmax) return null;
    }
  }
  return tmin;
}

// ------------------------------------------------------------------ player
export function createPlayer(scene, camera, dom, orbitControls) {
  // ---- character mesh (stylised cartoon person, see characters.js) ----
  // Blond spiky hair, sleepy eyes, open navy jacket over a white tee.
  // upper = hip pivot (the rider pose leans it forward); arms hang from
  // shoulder pivots on it, legs from hip pivots on the root group.
  const hero = buildCharacter(PRESETS.hero);
  const { group, upper, armL, armR, legL, legR } = hero;
  // Pistol prop in the right hand (G3), hidden until equipped. With the
  // arm raised forward (rotation.x = -PI/2) the arm's local -y points
  // forward, so the barrel runs along -y and the grip hangs along -z.
  const gun = new THREE.Group();
  const gunMat = new THREE.MeshStandardMaterial({ color: 0x222428, roughness: 0.5, metalness: 0.3 });
  const barrel = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.24, 0.07), gunMat);
  barrel.position.set(0, -0.74, 0.02);
  const grip = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.06, 0.13), gunMat);
  grip.position.set(0, -0.66, -0.06);
  gun.add(barrel, grip);
  gun.visible = false;
  armR.add(gun);
  // Muzzle point (local to armR) for tracers / flashes.
  const muzzle = new THREE.Object3D();
  muzzle.position.set(0, -0.88, 0.02);
  armR.add(muzzle);
  scene.add(group);

  // ---- state ----
  const pos = { x: SPAWN.x, z: SPAWN.z };
  let groundY = groundHeightAt(pos.x, pos.z);
  let jumpH = 0;      // jump height above the ground (0 when grounded)
  let jumpV = 0;      // jump vertical velocity
  let velX = 0;
  let velZ = 0;
  let facing = Math.PI; // face north (-z) at spawn
  let phase = 0;      // walk-cycle phase
  let swing = 0;      // current limb swing amplitude
  let lastSafe = { x: pos.x, z: pos.z };
  let yaw = 0;        // follow-camera azimuth (0 = camera south of player)
  let pitch = 0.42;   // follow-camera elevation above horizontal
  let camDist = CAM_DIST;
  let followActive = true;

  // ---- bike (F5c) ----
  // Parked on the grass strip east of the spawn sidewalk, facing north,
  // ~3 m from the spawn — clear of the road and of tower t08 (x >= 14).
  const bike = createBike(scene, 12.5, -17, Math.PI);
  let riding = false;
  let rideBlend = 0;  // 0 = standing pose, 1 = rider pose (lerped)
  let bikeSpeed = 0;  // signed speed along the bike heading (m/s)
  // ---- cars (revision 2): any traffic car can be driven ----
  let car = null;     // the traffic car object being driven
  let carSpeed = 0;   // signed speed along the car heading (m/s)
  let lastDrag = -10; // time of the last camera drag (auto camera waits)
  // Revision 3: nitro (hold Shift in a car) + stunt-ramp air time.
  let nitro = 1;      // 0..1 tank
  let boosting = false;
  let airY = 0;       // car height above the ground (ramps / jumps)
  let airVy = 0;
  let airborne = false;
  let lastRamp = null;
  let takeoff = null; // { x, z, t, ramp }
  // Revision 4 smoothness: damped camera, vehicle body roll / pitch, lean.
  const camPos = new THREE.Vector3();
  const camLook = new THREE.Vector3();
  let camSnap = true;
  let bodyRoll = 0;
  let bodyPitch = 0;
  let lean = 0;
  let prevCarSpeed = 0;
  let steerIn = 0;
  // Drift: the car's travel direction lags its heading (slip angle).
  let moveDir = 0;
  let slip = 0;
  let clock = 0;

  const keys = new Set();
  let dragging = null;
  let frozen = false;   // G2-G5: shops, BUSTED / WASTED screens freeze input
  let punchT = 0;       // > 0 while the punch animation plays
  let aimT = 0;         // > 0 while the pistol is raised

  const api = {
    group,
    get position() { return group.position; },
    get followActive() { return followActive; },
    get riding() { return riding; },
    get driving() { return !!car; },
    get car() { return car; },
    get inVehicle() { return riding || !!car; },
    get nitro() { return nitro; },
    get boosting() { return boosting; },
    get slip() { return car ? slip : 0; },
    get airborne() { return airborne; },
    onStunt: null,      // (event, data) => void — 'takeoff' / 'land'
    onCrash: null,      // (impactSpeed) => void, set by game.js
    bike: {
      group: bike.group,
      get riding() { return riding; },
      get position() { return bike.group.position; },
    },
    spawn: { ...SPAWN },
    update,
    // ---- gameplay hooks (G2-G5) ----
    interactHook: null, // () => true when E was consumed (shop door, ...)
    get speed() { return car ? carSpeed : riding ? bikeSpeed : Math.hypot(velX, velZ); },
    get facing() { return facing; },
    get yaw() { return yaw; },
    // Horizontal aim direction = the follow camera's forward on the ground.
    get aimDir() { return { x: -Math.sin(yaw), z: -Math.cos(yaw) }; },
    get frozen() { return frozen; },
    set frozen(v) { frozen = !!v; if (frozen) { keys.clear(); velX = 0; velZ = 0; bikeSpeed = 0; carSpeed = 0; } },
    set weaponVisible(v) { gun.visible = !!v; },
    // Longer barrel for SMG / shotgun / rifle (weapons.js barrel factor).
    setGunModel(k) {
      if (barrel.scale.y === k) return;
      barrel.scale.y = k;
      barrel.position.y = -0.62 - 0.12 * k;
      muzzle.position.y = -0.64 - 0.24 * k;
    },
    muzzleWorld(out) { return muzzle.getWorldPosition(out); },
    punch() { punchT = 0.32; },
    aim(dirX, dirZ) { // raise the pistol and turn to face (dirX, dirZ)
      aimT = 1.4;
      if (!riding && !car) { facing = Math.atan2(dirX, dirZ); group.rotation.y = facing; }
    },
    teleport(x, z, face = facing) {
      if (riding) toggleRide();
      if (car) exitCar();
      pos.x = x; pos.z = z; lastSafe.x = x; lastSafe.z = z;
      velX = 0; velZ = 0; jumpH = 0; jumpV = 0;
      facing = face; group.rotation.y = face; yaw = face + Math.PI;
      groundY = groundHeightAt(x, z);
      group.position.set(x, groundY, z);
      camSnap = true;
    },
    dismount() { if (riding) toggleRide(); if (car) exitCar(); },
    enterCar(c) { return enterCar(c); },
    exitCar() { exitCar(); },
    // Shove the player (or the bike + rider) to (x, z) without dismounting.
    nudge(x, z) {
      pos.x = x; pos.z = z; lastSafe.x = x; lastSafe.z = z;
      if (riding) bike.setPose(x, z, facing);
      if (car) { car.x = x; car.z = z; }
    },
    // Crash: scale the bike speed (0 = dead stop) / kill on-foot velocity.
    crash(k = 0) { bikeSpeed *= k; carSpeed *= k; velX *= k; velZ *= k; },
    get bikeObj() { return bike; },
  };

  // Mount (E near the bike) / dismount (E while riding). On mount the
  // rider snaps onto the seat; on dismount they step off to the right.
  function toggleRide() {
    if (!riding) {
      if (Math.hypot(pos.x - bike.x, pos.z - bike.z) > MOUNT_RADIUS) return;
      riding = true;
      bikeSpeed = 0;
      pos.x = bike.x;
      pos.z = bike.z;
      facing = bike.heading;
      group.rotation.y = facing;
      velX = 0;
      velZ = 0;
      jumpH = 0;
      jumpV = 0;
    } else {
      riding = false;
      bikeSpeed = 0;
      const rx = Math.cos(facing);
      const rz = -Math.sin(facing);
      pos.x = bike.x + rx * 1.2;
      pos.z = bike.z + rz * 1.2;
      pushOut(pos, BOXES, LAKE_BOX);
      lastSafe.x = pos.x;
      lastSafe.z = pos.z;
    }
  }

  // Enter a car (driver seat): the character is hidden inside, the car
  // stops being driven by the traffic AI.
  function enterCar(c) {
    if (riding || car || !c || c.wrecked) return false;
    car = c;
    c.driver = 'player';
    c.parked = false;
    carSpeed = 0;
    pos.x = c.x; pos.z = c.z;
    facing = c.heading;
    yaw = facing + Math.PI;
    group.visible = false;
    velX = 0; velZ = 0; jumpH = 0; jumpV = 0;
    prevCarSpeed = 0; bodyRoll = 0; bodyPitch = 0; moveDir = facing; slip = 0;
    return true;
  }
  // Step out on the driver's side (left), the car stays parked.
  function exitCar() {
    if (!car) return;
    const c = car;
    airY = 0; airVy = 0; airborne = false; boosting = false;
    c.group.rotation.x = 0;
    c.group.rotation.z = 0;
    c.group.position.y = groundHeightAt(c.x, c.z) - 0.05;
    car = null;
    c.driver = null;
    c.parked = true;
    c.speed = 0;
    carSpeed = 0;
    const lx = -Math.cos(facing);
    const lz = Math.sin(facing);
    pos.x = c.x + lx * (c.W / 2 + 0.7);
    pos.z = c.z + lz * (c.W / 2 + 0.7);
    pushOut(pos, BOXES, LAKE_BOX);
    lastSafe.x = pos.x; lastSafe.z = pos.z;
    group.visible = true;
    group.rotation.y = facing;
  }

  function setMode(follow) {
    followActive = follow;
    if (follow) camSnap = true;
    if (orbitControls) orbitControls.enabled = !follow;
    if (!follow && orbitControls) {
      // Frame the player when returning to orbit mode.
      orbitControls.target.set(pos.x, groundY + 1, pos.z);
    }
  }

  // ---- input (follow camera owns drag + wheel while active) ----
  window.addEventListener('keydown', (e) => {
    const k = e.key.toLowerCase();
    if (k === 'o') { setMode(!followActive); return; }
    if (frozen) return;
    if (k === 'e' && followActive) {
      if (e.repeat) return;
      if (car) { if (!(api.interactHook && api.interactHook())) exitCar(); return; }
      if (!(api.interactHook && api.interactHook())) toggleRide();
      return;
    }
    keys.add(k);
    if (k === ' ' && followActive) e.preventDefault();
  });
  window.addEventListener('keyup', (e) => keys.delete(e.key.toLowerCase()));
  window.addEventListener('blur', () => keys.clear());
  dom.addEventListener('pointerdown', (e) => {
    if (!followActive || e.button !== 0) return;
    dragging = { x: e.clientX, y: e.clientY };
  });
  dom.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    yaw -= (e.clientX - dragging.x) * 0.005;
    lastDrag = clock;
    pitch = THREE.MathUtils.clamp(pitch + (e.clientY - dragging.y) * 0.005, 0.12, 1.25);
    dragging.x = e.clientX;
    dragging.y = e.clientY;
  });
  const endDrag = () => { dragging = null; };
  dom.addEventListener('pointerup', endDrag);
  dom.addEventListener('pointercancel', endDrag);
  dom.addEventListener('wheel', (e) => {
    if (!followActive) return;
    e.preventDefault();
    camDist = THREE.MathUtils.clamp(camDist * Math.exp(e.deltaY * 0.001), CAM_MIN, CAM_MAX);
  }, { passive: false });

  // ---- per-frame update (follow mode only) ----
  function update(dt) {
    clock += dt;
    if (car && car.wrecked && car.burning === undefined) exitCar();
    // Collider set: wider boxes while riding (the bike is wider) / driving.
    const boxes = car ? CAR_BOXES : riding ? RIDE_BOXES : BOXES;
    const lakeBox = car ? CAR_LAKE_BOX : riding ? RIDE_LAKE_BOX : LAKE_BOX;

    if (car) {
      // Arcade car: W throttle, S brake / reverse, A/D steer, Space
      // handbrake (sharper turns, sliding stop). Stats from vehicles.js
      // plus Sully's engine tune.
      const T = car.stats;
      boosting = keys.has('shift') && nitro > 0.02 && !airborne && (keys.has('w') || keys.has('arrowup'));
      nitro = Math.max(0, Math.min(1, nitro + (boosting ? -0.3 : 0.06) * dt));
      const tune = (1 + 0.08 * (car.tune || 0)) * (boosting ? 1.35 : 1);
      const top = T.top * tune;
      const steer = (keys.has('d') || keys.has('arrowright') ? 1 : 0)
        - (keys.has('a') || keys.has('arrowleft') ? 1 : 0);
      const hand = keys.has(' ');
      const dead = car.burning !== undefined || car.wrecked || airborne;
      if (!dead && (keys.has('w') || keys.has('arrowup'))) {
        carSpeed += (carSpeed < 0 ? 18 : T.accel * tune * (1 - Math.max(0, carSpeed) / (top * 1.05))) * dt;
      } else if (!dead && (keys.has('s') || keys.has('arrowdown'))) {
        carSpeed -= (carSpeed > 0.5 ? 22 : 5) * dt;
        carSpeed = Math.max(carSpeed, -8);
      } else {
        carSpeed -= Math.sign(carSpeed) * Math.min(Math.abs(carSpeed), (3 + Math.abs(carSpeed) * 0.04) * dt);
      }
      if (hand) carSpeed -= Math.sign(carSpeed) * Math.min(Math.abs(carSpeed), 14 * dt);
      const sp = Math.abs(carSpeed);
      const turn = T.grip * Math.min(1, sp / 5) * (1.9 / (1 + sp / 28)) * (hand ? 1.7 : 1);
      if (!airborne) facing -= steer * turn * Math.sign(carSpeed || 1) * dt;
      steerIn += (steer * Math.min(1, sp / 18) - steerIn) * (1 - Math.exp(-6 * dt));
      // Revision 4 drift: travel direction chases the heading; the
      // handbrake (and very fast cornering) lets the tail slide out.
      let d = facing - moveDir;
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      const gripK = airborne ? 0 : hand ? 1.6 : (sp > 28 && steer ? 5 : 9) * T.grip;
      moveDir += d * (1 - Math.exp(-gripK * dt));
      slip = Math.abs(d) * Math.min(1, sp / 10);
      if (hand && sp > 6) carSpeed -= Math.sign(carSpeed) * Math.abs(Math.sin(d)) * 6 * dt;
      velX = Math.sin(moveDir) * carSpeed;
      velZ = Math.cos(moveDir) * carSpeed;
    } else if (riding) {
      // Bike-relative steering (GTA-style): W accelerates along the bike
      // heading, S brakes / reverses slowly, A/D steer the heading.
      // Steering only bites while moving (no spinning on the spot).
      const steer = (keys.has('d') || keys.has('arrowright') ? 1 : 0)
        - (keys.has('a') || keys.has('arrowleft') ? 1 : 0);
      const top = keys.has('shift') ? RIDE_SPRINT : RIDE;
      let targetSpeed = bikeSpeed;
      if (keys.has('w') || keys.has('arrowup')) targetSpeed = top;
      else if (keys.has('s') || keys.has('arrowdown')) {
        targetSpeed = bikeSpeed > 0.5 ? 0 : -RIDE_REVERSE;
      } else targetSpeed = 0; // coast to a stop (engine braking)
      const accel = 1 - Math.exp(-3.5 * dt);
      bikeSpeed += (targetSpeed - bikeSpeed) * accel;
      const grip = Math.min(1, Math.abs(bikeSpeed) / 5);
      facing -= steer * 1.9 * grip * dt;
      lean += (-steer * grip * Math.min(1, Math.abs(bikeSpeed) / 10) * 0.32 - lean) * (1 - Math.exp(-7 * dt));
      velX = Math.sin(facing) * bikeSpeed;
      velZ = Math.cos(facing) * bikeSpeed;
      group.rotation.y = facing;
    } else {
      // Input vector, camera-relative: W = away from the camera.
      let ix = 0;
      let iz = 0;
      if (keys.has('w') || keys.has('arrowup')) iz += 1;
      if (keys.has('s') || keys.has('arrowdown')) iz -= 1;
      if (keys.has('a') || keys.has('arrowleft')) ix -= 1;
      if (keys.has('d') || keys.has('arrowright')) ix += 1;
      const fx = -Math.sin(yaw);
      const fz = -Math.cos(yaw);
      const rx = -fz;
      const rz = fx;
      let mx = fx * iz + rx * ix;
      let mz = fz * iz + rz * ix;
      const mLen = Math.hypot(mx, mz);
      const moving = mLen > 0;
      if (moving) { mx /= mLen; mz /= mLen; }
      const speed = keys.has('shift') ? SPRINT : WALK;
      const accel = 1 - Math.exp(-10 * dt);
      velX += (mx * speed - velX) * accel;
      velZ += (mz * speed - velZ) * accel;
      // Face the movement direction (shortest-path lerp).
      if (moving) {
        const target = Math.atan2(mx, mz);
        let d = target - facing;
        while (d > Math.PI) d -= Math.PI * 2;
        while (d < -Math.PI) d += Math.PI * 2;
        facing += d * (1 - Math.exp(-12 * dt));
        group.rotation.y = facing;
      }
    }

    // Move, then collide: push out of buildings/lake, stay on the island.
    // If still inside a collider after push-out, snap back to last safe —
    // the player can never get stuck on a wall.
    pos.x += velX * dt;
    pos.z += velZ * dt;
    const preX = pos.x;
    const preZ = pos.z;
    pushOut(pos, boxes, lakeBox);
    if ((car || riding) && Math.hypot(pos.x - preX, pos.z - preZ) > 0.02) {
      // Hit a wall: impact = speed into the wall; slows the vehicle.
      const imp = Math.abs(car ? carSpeed : bikeSpeed);
      if (imp > 7 && api.onCrash) api.onCrash(imp);
      if (car) carSpeed *= 0.35; else bikeSpeed *= 0.5;
    }
    if (insideAnyCollider(pos.x, pos.z, boxes, lakeBox)
      || !pointInPolygon(pos.x, pos.z, LAYOUT.coastline)) {
      pos.x = lastSafe.x;
      pos.z = lastSafe.z;
      velX = 0;
      velZ = 0;
      bikeSpeed = 0;
      carSpeed = 0;
    } else {
      lastSafe.x = pos.x;
      lastSafe.z = pos.z;
    }
    if (riding) bike.setPose(pos.x, pos.z, facing, lean);
    else lean *= Math.exp(-8 * dt);
    if (car) {
      car.x = pos.x; car.z = pos.z; car.heading = facing; car.speed = carSpeed;
      // Stunt ramps: drive up the wedge, fly off the lip, land.
      let rampH = 0;
      let slope = 0;
      let onRamp = null;
      for (const r of RAMPS) {
        const dx = pos.x - r.x;
        const dz = pos.z - r.z;
        const along = dx * Math.sin(r.heading) + dz * Math.cos(r.heading);
        const side = dx * Math.cos(r.heading) - dz * Math.sin(r.heading);
        if (Math.abs(side) < r.w / 2 && Math.abs(along) < r.len / 2) {
          rampH = ((along + r.len / 2) / r.len) * r.h;
          slope = Math.atan2(r.h, r.len) * Math.cos(facing - r.heading);
          onRamp = r;
        }
      }
      if (airborne) {
        airVy -= 20 * dt;
        airY += airVy * dt;
        if (airY <= rampH) {
          airY = rampH;
          airborne = false;
          const dist = takeoff ? Math.hypot(pos.x - takeoff.x, pos.z - takeoff.z) : 0;
          if (api.onStunt) api.onStunt('land', { dist, air: clock - (takeoff ? takeoff.t : clock), ramp: takeoff && takeoff.ramp, speed: carSpeed });
          if (Math.abs(airVy) > 9) carSpeed *= 0.75;
          takeoff = null;
        }
      } else if (onRamp) {
        airY = rampH;
        lastRamp = onRamp;
      } else if (airY > 0.05) {
        if (Math.abs(carSpeed) > 8 && lastRamp) {
          airborne = true;
          airVy = Math.abs(carSpeed) * Math.sin(Math.atan2(lastRamp.h, lastRamp.len)) * 1.5 + 2.5;
          takeoff = { x: pos.x, z: pos.z, t: clock, ramp: lastRamp };
          if (api.onStunt) api.onStunt('takeoff', { ramp: lastRamp, speed: carSpeed });
        } else airY = 0;
        lastRamp = null;
      }
      car.group.position.set(pos.x, groundHeightAt(pos.x, pos.z) - 0.05 + airY, pos.z);
      car.group.rotation.order = 'YXZ';
      car.group.rotation.y = facing;
      // Body roll into turns + pitch under braking / throttle.
      const acc = dt > 0 ? (carSpeed - prevCarSpeed) / dt : 0;
      prevCarSpeed = carSpeed;
      bodyRoll += (steerIn * 0.07 + Math.min(0.04, slip * 0.05) * Math.sign(steerIn) - bodyRoll) * (1 - Math.exp(-8 * dt));
      bodyPitch += (THREE.MathUtils.clamp(acc * 0.004, -0.05, 0.04) - bodyPitch) * (1 - Math.exp(-6 * dt));
      car.group.rotation.x = (airborne ? THREE.MathUtils.clamp(-airVy * 0.035, -0.4, 0.5) : -slope) - bodyPitch;
      car.group.rotation.z = airborne ? 0 : bodyRoll;
    }

    // Ground height (smooth steps over curbs) + jump (on foot only).
    const targetY = groundHeightAt(pos.x, pos.z);
    groundY += (targetY - groundY) * (1 - Math.exp(-12 * dt));
    if (!riding && !car && keys.has(' ') && jumpH <= 0) jumpV = 5.2;
    if (jumpH > 0 || jumpV > 0) {
      jumpV -= 18 * dt;
      jumpH += jumpV * dt;
      if (jumpH <= 0) { jumpH = 0; jumpV = 0; }
    }
    // Blend the rider pose in/out (0 = standing, 1 = seated on the bike).
    rideBlend += ((riding ? 1 : 0) - rideBlend) * (1 - Math.exp(-8 * dt));
    // Seated: hips on the seat (group origin drops 0.05 m — the hip pivot
    // (0.9 m) sits at seat height, feet rest on the pegs instead of the ground).
    group.position.set(pos.x, groundY + jumpH - 0.05 * rideBlend, pos.z);

    // Walk cycle (on foot) blended into the rider pose (on the bike):
    // torso leans forward ~31°, arms reach the handlebars, legs bend
    // onto the pegs. The swing fades out as the rider pose fades in.
    const runSpeed = Math.hypot(velX, velZ);
    phase += runSpeed * dt * 2.2;
    const targetSwing = (!riding && runSpeed > 0.3) ? 0.55 : 0;
    swing += (targetSwing - swing) * (1 - Math.exp(-8 * dt));
    const s = Math.sin(phase) * swing;
    const rb = rideBlend;
    armL.rotation.x = s * (1 - rb) - 1.15 * rb;
    armR.rotation.x = -s * (1 - rb) - 1.15 * rb;
    // Punch (fast jab forward) / pistol aim (arm straight forward).
    if (punchT > 0) {
      punchT -= dt;
      const k = Math.sin(Math.max(0, punchT) / 0.32 * Math.PI);
      armR.rotation.x = -1.6 * k + armR.rotation.x * (1 - k);
    } else if (aimT > 0 && !riding) {
      aimT -= dt;
      armR.rotation.x = -Math.PI / 2;
    }
    legL.rotation.x = -s * (1 - rb) - 0.9 * rb;
    legR.rotation.x = s * (1 - rb) - 0.9 * rb;
    upper.rotation.x = 0.55 * rb;
    group.rotation.z = riding ? lean : 0;

    // Follow camera: spherical around the head, no-clip vs building boxes.
    // Pulls back 2 m while riding so the bike stays in frame.
    const effDist = car ? camDist + 3.5 + (car.L > 6 ? 4 : 0) : riding ? camDist + 2 : camDist;
    // In a vehicle the camera swings back behind it unless you dragged
    // the view in the last 1.5 s (GTA-style chase cam).
    if ((car || riding) && clock - lastDrag > 1.5 && Math.abs(api.speed) > 2) {
      let d = (facing + (api.speed < 0 ? 0 : Math.PI)) - yaw;
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      yaw += d * (1 - Math.exp(-2.5 * dt));
    }
    const hx = pos.x;
    const hy = groundY + jumpH + EYE_Y + (car ? 0.3 + airY : 0);
    const hz = pos.z;
    const hDist = effDist * Math.cos(pitch);
    let cx = hx + Math.sin(yaw) * hDist;
    let cy = hy + effDist * Math.sin(pitch);
    let cz = hz + Math.cos(yaw) * hDist;
    let bestT = 1;
    for (const b of BOXES) {
      const t = segmentBoxT(hx, hy, hz, cx, cy, cz, b);
      if (t !== null && t < bestT) bestT = t;
    }
    if (bestT < 1) {
      const t = Math.max(bestT - 0.3 / effDist, 0.08);
      cx = hx + (cx - hx) * t;
      cy = hy + (cy - hy) * t;
      cz = hz + (cz - hz) * t;
    }
    const floorY = groundHeightAt(cx, cz) + 0.4;
    if (cy < floorY) cy = floorY;
    // Damped follow: smooth on foot, softer in vehicles; a wall pulling the
    // camera in snaps fast so you never see through it. Vehicles look a
    // little ahead along the velocity.
    const inV = car || riding;
    const ahead = inV ? Math.min(6, Math.abs(api.speed) * 0.18) * Math.sign(api.speed || 1) : 0;
    const lx = hx + Math.sin(facing) * ahead;
    const lz = hz + Math.cos(facing) * ahead;
    if (camSnap || dt <= 0) {
      camPos.set(cx, cy, cz);
      camLook.set(lx, hy, lz);
      camSnap = false;
    } else {
      const k = bestT < 1 ? 30 : inV ? 10 : 16;
      camPos.lerp(new THREE.Vector3(cx, cy, cz), 1 - Math.exp(-k * dt));
      camLook.lerp(new THREE.Vector3(lx, hy, lz), 1 - Math.exp(-(inV ? 12 : 20) * dt));
      // Never let the smoothed camera dip under the ground.
      const fy = groundHeightAt(camPos.x, camPos.z) + 0.4;
      if (camPos.y < fy) camPos.y = fy;
    }
    camera.position.copy(camPos);
    camera.lookAt(camLook);
  }

  // Initial placement + camera framing.
  group.position.set(pos.x, groundY, pos.z);
  group.rotation.y = facing;
  update(0);
  return api;
}
