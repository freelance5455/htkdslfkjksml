// weather.js — dynamic weather on top of the day/night cycle.
// States: CLEAR, CLOUDY, RAIN, STORM (rain + lightning + thunder), FOG.
// Every 2-4 game hours a new state is rolled (weighted toward clear) and
// the scene eases into it over ~20 s: sky greys out, sunlight dims, fog
// closes in, rain streaks fall around the camera. Storm lightning flashes
// the sky and emits 'thunder' for the audio module. state.weather is
// saved with the game.

import * as THREE from 'three';

export const WEATHERS = {
  clear:  { label: 'CLEAR',  cloud: 0,    rain: 0,   fog: 0,   w: 5 },
  cloudy: { label: 'CLOUDY', cloud: 0.55, rain: 0,   fog: 0.1, w: 3 },
  rain:   { label: 'RAIN',   cloud: 0.8,  rain: 0.7, fog: 0.35, w: 2 },
  storm:  { label: 'STORM',  cloud: 1,    rain: 1,   fog: 0.45, w: 1 },
  fog:    { label: 'FOG',    cloud: 0.5,  rain: 0,   fog: 1,   w: 1 },
};
const ORDER = Object.keys(WEATHERS);
const DROPS = 2600;
const BOX = { x: 44, y: 26, z: 44 };

export function createWeather(scene, { state, camera, sun, hemi }) {
  if (!state.weather || !WEATHERS[state.weather]) state.weather = 'clear';
  const cur = { ...WEATHERS[state.weather] };
  let nextChange = state.clock + 120 + Math.random() * 120; // game minutes
  let flash = 0;
  let boltCd = 4;

  // Rain: short line segments in a box that follows the camera.
  const pos = new Float32Array(DROPS * 6);
  const seeds = new Float32Array(DROPS * 3);
  for (let i = 0; i < DROPS; i++) {
    seeds[i * 3] = Math.random() * BOX.x;
    seeds[i * 3 + 1] = Math.random() * BOX.y;
    seeds[i * 3 + 2] = Math.random() * BOX.z;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const rainMat = new THREE.LineBasicMaterial({ color: 0xbfd4ee, transparent: true, opacity: 0, depthWrite: false });
  const rain = new THREE.LineSegments(geo, rainMat);
  rain.frustumCulled = false;
  scene.add(rain);

  const fog = new THREE.Fog(0x9aa4b0, 60, 900);
  const grey = new THREE.Color(0x8d96a2);
  const stormGrey = new THREE.Color(0x4a525e);
  let fall = 0;

  function set(name) {
    if (!WEATHERS[name]) return;
    state.weather = name;
    state.emit('weather', { name, label: WEATHERS[name].label });
  }
  function roll() {
    const tot = ORDER.reduce((s, k) => s + WEATHERS[k].w, 0);
    let r = Math.random() * tot;
    for (const k of ORDER) { r -= WEATHERS[k].w; if (r <= 0) return k; }
    return 'clear';
  }

  function update(dt) {
    // Scheduled change (game time).
    let ahead = nextChange - state.clock;
    if (ahead < -720) ahead += 1440;
    if (ahead <= 0) {
      nextChange = (state.clock + 120 + Math.random() * 120) % 1440;
      const n = roll();
      if (n !== state.weather) set(n);
    }
    // Ease toward the target state.
    const tgt = WEATHERS[state.weather];
    const k = 1 - Math.exp(-dt / 6);
    for (const key of ['cloud', 'rain', 'fog']) cur[key] += (tgt[key] - cur[key]) * k;

    // Sky / light (daynight.js already set them this frame).
    const bg = scene.background;
    if (bg && bg.isColor) {
      const g = state.weather === 'storm' ? stormGrey : grey;
      const night = Math.max(0, 1 - bg.getHSL({}).l * 2.2);
      bg.lerp(g.clone().multiplyScalar(1 - night * 0.75), cur.cloud * 0.75);
    }
    sun.intensity *= 1 - cur.cloud * 0.65;
    hemi.intensity *= 1 - cur.cloud * 0.25;

    // Fog distance: off when clear, ~45 m in thick fog.
    if (cur.fog > 0.02) {
      scene.fog = fog;
      fog.color.copy(scene.background);
      fog.near = 8 + (1 - cur.fog) * 120;
      fog.far = 45 + (1 - cur.fog) * 700;
    } else scene.fog = null;

    // Lightning.
    if (state.weather === 'storm' && cur.rain > 0.6) {
      boltCd -= dt;
      if (boltCd <= 0) {
        boltCd = 5 + Math.random() * 9;
        flash = 0.35;
        state.emit('thunder', { delay: 0.3 + Math.random() * 1.5 });
      }
    }
    if (flash > 0) {
      flash -= dt;
      const f = Math.max(0, flash / 0.35);
      hemi.intensity += 2.5 * f * (Math.random() < 0.7 ? 1 : 0.3);
      scene.background.lerp(new THREE.Color(0xe8ecff), f * 0.6);
    }

    // Rain drops.
    rainMat.opacity = cur.rain * 0.55;
    rain.visible = cur.rain > 0.03;
    if (rain.visible) {
      fall += dt * 26;
      const cx = camera.position.x - BOX.x / 2;
      const cy = camera.position.y - BOX.y / 2;
      const cz = camera.position.z - BOX.z / 2;
      const len = 0.7;
      const active = Math.floor(DROPS * cur.rain);
      for (let i = 0; i < DROPS; i++) {
        const o = i * 6;
        if (i >= active) { pos[o + 1] = pos[o + 4] = -1000; continue; }
        // Wrap each drop inside the camera-centred box.
        const x = cx + ((seeds[i * 3] - cx) % BOX.x + BOX.x) % BOX.x;
        const z = cz + ((seeds[i * 3 + 2] - cz) % BOX.z + BOX.z) % BOX.z;
        const y = cy + (((seeds[i * 3 + 1] - fall - cy) % BOX.y) + BOX.y) % BOX.y;
        pos[o] = x; pos[o + 1] = y; pos[o + 2] = z;
        pos[o + 3] = x + 0.08; pos[o + 4] = y + len; pos[o + 5] = z + 0.05;
      }
      geo.attributes.position.needsUpdate = true;
    }
  }

  return {
    update,
    set,
    get label() { return WEATHERS[state.weather].label; },
    get rain() { return cur.rain; },
    get cloud() { return cur.cloud; },
    get name() { return state.weather; },
  };
}
