// police.js — G2 + revision 2: wanted level + a full police response.
//  * Wanted 0-5 stars (state.js). Crimes: hitting people with a vehicle,
//    assault, shooting, stealing a car in front of witnesses.
//  * Every unit has a callsign and a live status for the HUD response
//    panel: PURSUIT, SEARCHING, FIRING, ARRESTING, RAMMING, ROADBLOCK,
//    SPOTLIGHT.
//  * Line of sight: while any unit can see you the HUD says IN SIGHT and
//    the search zone (minimap circle) follows you. Out of sight, units
//    sweep the zone around your last known position instead of homing in.
//  * Foot cops: 1-2 per star. 3+ stars: patrol cars (they ram you when
//    you are in a vehicle, drop off cops when you are on foot) and cops
//    shoot. 4+: police helicopter with a spotlight + roadblocks ahead of
//    you. 5: the chopper's gunner opens fire.
//  * Decay (handoff rule): no crime for 30 s = one star less. The timer
//    only runs while no unit can see you.
//  * Standing still (or crawling) next to a cop for 1 s = BUSTED.

import * as THREE from 'three';
import { NODES, EDGES, LAYOUT, pointInPolygon } from './layout.js';
import { buildCharacter, HIP_Y } from './characters.js';
import {
  groundHeightAt, BOXES, LAKE_BOX, pushOut, buildBoxes, segmentBoxT,
} from './player.js';

export const WANTED_DECAY_S = 30;
export const BUST_FINE_PER_STAR = 50;
const COP_RUN = 5.6;
const ARREST_RANGE = 1.4;
const ARREST_TIME = 1.0;
const CAR_SPEED = 17;
const CAR_BOXES = buildBoxes(1.4);
const MAX_COPS = 14;
const SIGHT_FOOT = 45;
const SIGHT_CAR = 60;
const SIGHT_HELI = 75;

export function footCopsFor(stars) { return stars <= 0 ? 0 : Math.ceil(stars * 1.5); }
export function carsFor(stars) { return stars >= 3 ? stars - 2 : 0; }
export function searchRadiusFor(stars) { return 25 + stars * 12; }

export function lineOfSight(ax, az, bx, bz) {
  for (const b of BOXES) {
    if (segmentBoxT(ax, 1.3, az, bx, 1.3, bz, b) !== null) return false;
  }
  return true;
}

const COP_SPEC = {
  skin: '#c98f62', hair: 'cap', capColor: '#1b2742', hairColor: '#2a1a10', eyes: 'normal',
  top: '#3d5f95', bottom: '#1b2742', shoes: '#141414', longSleeves: true,
};
const COP_SKINS = ['#c98f62', '#f1c7a1', '#8d5b3a', '#e2b08a'];
const CAR_SIGNS = ['CONDOR', 'TUCAN', 'IGUANA', 'JAGUAR', 'MANTA', 'COYOTE'];

// ---------------------------------------------------------------- road graph
const NODE_BY_ID = new Map(NODES.map((n) => [n.id, n]));
const ADJ = new Map(NODES.map((n) => [n.id, []]));
for (const e of EDGES) {
  if (!ADJ.has(e.from) || !ADJ.has(e.to)) continue;
  ADJ.get(e.from).push(e.to);
  ADJ.get(e.to).push(e.from);
}
function nearestNode(x, z) {
  let best = null;
  let bd = Infinity;
  for (const n of NODES) {
    const d = Math.hypot(n.x - x, n.z - z);
    if (d < bd) { bd = d; best = n; }
  }
  return best;
}
export function bfsPath(fromId, toId) {
  const prev = new Map([[fromId, null]]);
  const q = [fromId];
  while (q.length) {
    const id = q.shift();
    if (id === toId) break;
    for (const nb of ADJ.get(id)) if (!prev.has(nb)) { prev.set(nb, id); q.push(nb); }
  }
  if (!prev.has(toId)) return [fromId];
  const path = [];
  for (let id = toId; id; id = prev.get(id)) path.unshift(id);
  return path;
}
function waypoints(pathIds) {
  const out = [];
  for (let i = 0; i < pathIds.length; i++) {
    const n = NODE_BY_ID.get(pathIds[i]);
    if (n.type !== 'roundabout') { out.push([n.x, n.z]); continue; }
    const a = pathIds[i - 1] ? NODE_BY_ID.get(pathIds[i - 1]) : null;
    const b = pathIds[i + 1] ? NODE_BY_ID.get(pathIds[i + 1]) : null;
    const ang = (p) => Math.atan2(p.x - n.x, p.z - n.z);
    const a0 = a ? ang(a) : 0;
    let a1 = b ? ang(b) : a0 + Math.PI;
    while (a1 <= a0) a1 += Math.PI * 2;
    const steps = Math.max(1, Math.ceil((a1 - a0) / (Math.PI / 4)));
    for (let k = 0; k <= steps; k++) {
      const t = a0 + ((a1 - a0) * k) / steps;
      out.push([n.x + Math.sin(t) * 10, n.z + Math.cos(t) * 10]);
    }
  }
  return out;
}

// ---------------------------------------------------------------- meshes
function carMesh() {
  const g = new THREE.Group();
  const m = (c, e) => new THREE.MeshStandardMaterial({
    color: c, flatShading: true, roughness: 0.6,
    emissive: e || 0x000000, emissiveIntensity: e ? 1.6 : 0,
  });
  const white = m(0xf2f2ee);
  const black = m(0x15161a);
  const glass = m(0x1e2a36);
  const add = (geo, mat, x, y, z) => {
    const o = new THREE.Mesh(geo, mat);
    o.position.set(x, y, z);
    o.castShadow = true;
    g.add(o);
    return o;
  };
  add(new THREE.BoxGeometry(1.9, 0.55, 4.3), black, 0, 0.6, 0);
  add(new THREE.BoxGeometry(1.92, 0.5, 2.0), white, 0, 0.62, 0.05);
  add(new THREE.BoxGeometry(1.7, 0.55, 2.2), white, 0, 1.15, -0.2);
  add(new THREE.BoxGeometry(1.72, 0.42, 2.0), glass, 0, 1.16, -0.2);
  add(new THREE.BoxGeometry(1.74, 0.08, 2.24), white, 0, 1.45, -0.2);
  const red = m(0x550000, 0xff2020);
  const blue = m(0x000055, 0x2050ff);
  add(new THREE.BoxGeometry(0.6, 0.14, 0.3), red, -0.33, 1.56, -0.2);
  add(new THREE.BoxGeometry(0.6, 0.14, 0.3), blue, 0.33, 1.56, -0.2);
  const wheelG = new THREE.CylinderGeometry(0.36, 0.36, 0.28, 10);
  wheelG.rotateZ(Math.PI / 2);
  for (const [x, z] of [[-0.92, 1.35], [0.92, 1.35], [-0.92, -1.35], [0.92, -1.35]]) add(wheelG, black, x, 0.36, z);
  add(new THREE.BoxGeometry(0.5, 0.12, 0.05), m(0xffffcc, 0xffffaa), -0.6, 0.7, 2.16);
  add(new THREE.BoxGeometry(0.5, 0.12, 0.05), m(0xffffcc, 0xffffaa), 0.6, 0.7, 2.16);
  return { group: g, red, blue, white };
}

function heliMesh() {
  const g = new THREE.Group();
  const m = (c, o = {}) => new THREE.MeshStandardMaterial({ color: c, flatShading: true, roughness: 0.5, ...o });
  const body = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.8, 4.2), m(0xf2f2ee));
  g.add(body);
  const nose = new THREE.Mesh(new THREE.BoxGeometry(2.0, 1.3, 1.2), m(0x1e2a36, { metalness: 0.4 }));
  nose.position.set(0, -0.15, 2.5);
  g.add(nose);
  const band = new THREE.Mesh(new THREE.BoxGeometry(2.25, 0.5, 4.25), m(0x1b3a8a));
  band.position.y = -0.3;
  g.add(band);
  const tail = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.45, 4.5), m(0xf2f2ee));
  tail.position.set(0, 0.35, -4.2);
  g.add(tail);
  const fin = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.2, 0.8), m(0x1b3a8a));
  fin.position.set(0, 0.9, -6.2);
  g.add(fin);
  for (const x of [-0.9, 0.9]) {
    const skid = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 3.6), m(0x222222));
    skid.position.set(x, -1.25, 0.2);
    g.add(skid);
  }
  const rotor = new THREE.Group();
  for (const r of [0, Math.PI / 2]) {
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.06, 10), m(0x222222));
    blade.rotation.y = r;
    rotor.add(blade);
  }
  rotor.position.y = 1.15;
  g.add(rotor);
  const tailRotor = new THREE.Mesh(new THREE.BoxGeometry(0.06, 1.6, 0.2), m(0x222222));
  tailRotor.position.set(0.3, 0.6, -6.3);
  g.add(tailRotor);
  // Spotlight: a real spot light + a soft visible cone.
  const spot = new THREE.SpotLight(0xfff6d8, 0, 60, 0.32, 0.5, 1);
  spot.position.set(0, -1.2, 1.5);
  g.add(spot);
  g.add(spot.target);
  const cone = new THREE.Mesh(new THREE.ConeGeometry(5, 26, 20, 1, true),
    new THREE.MeshBasicMaterial({ color: 0xfff3c4, transparent: true, opacity: 0.0, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending }));
  cone.position.set(0, -14, 0);
  g.add(cone);
  return { group: g, rotor, tailRotor, spot, cone };
}

// ------------------------------------------------------------------ module
export function createPolice(scene, { state, player, npcs, onBusted }) {
  const cops = [];
  const cars = [];
  let heli = null;
  let spawnCooldown = 0;
  let arrestT = 0;
  let decayFrom = 0;
  let copSeq = 0;
  let carSeq = 0;
  let flash = 0;
  let inSight = false;
  let sightT = 0;
  const lastSeen = { x: 0, z: 0 };
  let roadblockCd = 0;
  let wasWanted = 0;

  // ---- cops on foot
  function makeCop(x, z, opts = {}) {
    const c = buildCharacter({ ...COP_SPEC, skin: COP_SKINS[copSeq % COP_SKINS.length] });
    c.group.rotation.order = 'YXZ';
    const badge = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.07, 0.02),
      new THREE.MeshStandardMaterial({ color: 0xf2c230, metalness: 0.6, roughness: 0.3 }));
    badge.position.set(-0.09, HIP_Y + 0.45, 0.14);
    c.group.add(badge);
    c.group.position.set(x, groundHeightAt(x, z), z);
    scene.add(c.group);
    copSeq += 1;
    const cop = {
      kind: 'cop', mesh: c.group, parts: c, x, z, heading: 0, phase: 0,
      hp: 100, state: 'chase', timer: 0, fall: 0, fireCd: 1 + Math.random() * 1.5, firedT: 0,
      stuck: 0, side: 0, sideT: 0, callsign: opts.callsign || `UNIT-${10 + copSeq}`,
      search: null, guard: opts.guard || null,
    };
    cops.push(cop);
    return cop;
  }
  function removeCop(c) {
    scene.remove(c.mesh);
    cops.splice(cops.indexOf(c), 1);
  }

  // ---- cars
  function makeCar(x, z, heading, opts = {}) {
    const cm = carMesh();
    scene.add(cm.group);
    carSeq += 1;
    const car = {
      kind: 'pcar', ...cm, x, z, heading, speed: 0, path: [], pathT: 0,
      deployed: false, state: 'chase', timer: 0, hitCd: 0, hp: 120, burning: undefined, wrecked: false,
      callsign: `${CAR_SIGNS[carSeq % CAR_SIGNS.length]}-${10 + ((carSeq * 7) % 40)}`,
      roadblock: !!opts.roadblock, status: 'PURSUIT', L: 4.3, W: 1.9,
    };
    cm.group.position.set(x, groundHeightAt(x, z), z);
    cm.group.rotation.y = heading;
    cars.push(car);
    return car;
  }
  function removeCar(c) {
    scene.remove(c.group);
    cars.splice(cars.indexOf(c), 1);
  }
  function damageCar(c, amount) {
    if (c.wrecked || c.burning !== undefined) return null;
    c.hp -= amount;
    if (c.hp <= 0) { c.burning = 4; return 'burning'; }
    return 'hit';
  }

  function footSpawnPoint(cx, cz) {
    const aim = player.aimDir;
    const pp = player.position;
    let best = null;
    let bestScore = -Infinity;
    for (let t = 0; t < 40; t++) {
      const n = npcs.nodes[Math.floor(Math.random() * npcs.nodes.length)];
      if (n.onRoad) continue;
      const dx = n.x - cx;
      const dz = n.z - cz;
      const d = Math.hypot(dx, dz);
      if (d < 26 || d > 58) continue;
      if (Math.hypot(n.x - pp.x, n.z - pp.z) < 22) continue;
      const behind = -(dx * aim.x + dz * aim.z) / d;
      const score = behind + Math.random() * 0.3;
      if (score > bestScore) { bestScore = score; best = n; }
    }
    return best;
  }
  function carSpawnPoint(cx, cz) {
    const pp = player.position;
    const cands = NODES.filter((n) => {
      const d = Math.hypot(n.x - cx, n.z - cz);
      return d > 55 && d < 140 && Math.hypot(n.x - pp.x, n.z - pp.z) > 45
        && n.type !== 'roundabout' && pointInPolygon(n.x, n.z, LAYOUT.coastline);
    });
    if (!cands.length) return null;
    cands.sort((a, b) => Math.hypot(a.x - cx, a.z - cz) - Math.hypot(b.x - cx, b.z - cz));
    return cands[Math.floor(Math.random() * Math.min(3, cands.length))];
  }

  function despawnAll() {
    while (cops.length) removeCop(cops[0]);
    while (cars.length) removeCar(cars[0]);
    if (heli) { scene.remove(heli.group); heli = null; }
    arrestT = 0;
    inSight = false;
  }

  function damageCop(c, amount, fromX, fromZ, kind) {
    if (c.state === 'down') return null;
    c.hp -= amount;
    state.crime(1, 'assault-cop');
    if (c.hp <= 0) {
      c.state = 'down';
      c.timer = 12;
      c.fall = 0;
      c.heading = Math.atan2(fromX - c.x, fromZ - c.z);
      c.mesh.rotation.y = c.heading;
      return 'dead';
    }
    void kind;
    return 'hit';
  }

  // ---- vehicle hits on people (bike or car)
  let hitCd = 0;
  function checkVehicleHits(dt) {
    hitCd -= dt;
    if (!player.inVehicle || Math.abs(player.speed) < 4) return;
    const pp = player.position;
    const R = player.driving ? Math.max(1.6, player.car.L / 2) : 1.1;
    for (const n of npcs.people) {
      if (!npcs.alive(n)) continue;
      const p = n.mesh.position;
      if (Math.hypot(p.x - pp.x, p.z - pp.z) > R) continue;
      if (npcs.knock(n, pp.x, pp.z, Math.abs(player.speed) > 16)) {
        state.crime(1, 'hit-pedestrian');
        npcs.panic(p.x, p.z, 12);
        if (hitCd <= 0) { hitCd = 1; state.emit('notify', { text: 'Pedestrian hit!', kind: 'crime' }); }
      }
    }
    for (const c of cops) {
      if (c.state === 'down') continue;
      if (Math.hypot(c.x - pp.x, c.z - pp.z) > R) continue;
      damageCop(c, 100, pp.x, pp.z, 'vehicle');
    }
  }

  // Can any unit see the player right now?
  function updateSight(dt) {
    const pp = player.position;
    let seen = false;
    for (const c of cops) {
      if (c.state === 'down') continue;
      const d = Math.hypot(c.x - pp.x, c.z - pp.z);
      c.sees = d < SIGHT_FOOT && lineOfSight(c.x, c.z, pp.x, pp.z);
      seen = seen || c.sees;
    }
    for (const c of cars) {
      const d = Math.hypot(c.x - pp.x, c.z - pp.z);
      c.sees = !c.wrecked && d < SIGHT_CAR && lineOfSight(c.x, c.z, pp.x, pp.z);
      seen = seen || c.sees;
    }
    if (heli) {
      const d = Math.hypot(heli.x - pp.x, heli.z - pp.z);
      heli.sees = d < SIGHT_HELI;
      seen = seen || heli.sees;
    }
    // Brief grace so a single frame behind a lamp post does not flicker.
    if (seen) { sightT = 1.2; lastSeen.x = pp.x; lastSeen.z = pp.z; } else sightT -= dt;
    inSight = sightT > 0;
  }

  // Where a unit heads: the player when seen, else a point in the zone.
  function goalFor(u) {
    if (inSight) return [player.position.x, player.position.z];
    const R = searchRadiusFor(state.wanted);
    if (!u.search || Math.hypot(u.search[0] - (u.x), u.search[1] - (u.z)) < 4 || Math.random() < 0.002) {
      const a = Math.random() * Math.PI * 2;
      const r = Math.sqrt(Math.random()) * R;
      u.search = [lastSeen.x + Math.cos(a) * r, lastSeen.z + Math.sin(a) * r];
    }
    return u.search;
  }

  // ---- per-frame cop on foot
  function stepCop(c, dt, chasing) {
    if (c.state === 'down') {
      c.fall = Math.min(1, c.fall + dt / 0.35);
      c.mesh.rotation.x = -Math.PI / 2 * c.fall;
      c.timer -= dt;
      c.status = 'DOWN';
      if (c.timer <= 0) removeCop(c);
      return;
    }
    c.firedT -= dt;
    const pp = player.position;
    let tx;
    let tz;
    let speed;
    if (chasing) {
      if (c.guard && !inSight) { [tx, tz] = c.guard; speed = 2; } else { [tx, tz] = goalFor(c); speed = inSight ? COP_RUN : 3.4; }
      c.status = c.firedT > 0 ? 'FIRING' : (arrestT > 0.05 && Math.hypot(c.x - pp.x, c.z - pp.z) < ARREST_RANGE) ? 'ARRESTING'
        : c.guard ? 'ROADBLOCK' : inSight ? 'PURSUIT' : 'SEARCHING';
    } else {
      tx = c.x + (c.x - pp.x); tz = c.z + (c.z - pp.z); speed = 1.6;
      c.status = 'CLEAR';
      c.timer += dt;
      if (Math.hypot(c.x - pp.x, c.z - pp.z) > 70 || c.timer > 25) { removeCop(c); return; }
    }
    let dx = tx - c.x;
    let dz = tz - c.z;
    const d = Math.hypot(dx, dz);
    const dPlayer = Math.hypot(pp.x - c.x, pp.z - c.z);
    if (chasing && inSight && dPlayer < ARREST_RANGE * 0.8) { dx = 0; dz = 0; } else if (d > 0.3) { dx /= d; dz /= d; } else { dx = 0; dz = 0; }
    if (c.side) {
      const sx = -dz * c.side;
      const sz = dx * c.side;
      dx = dx * 0.3 + sx; dz = dz * 0.3 + sz;
      const l = Math.hypot(dx, dz) || 1;
      dx /= l; dz /= l;
      c.sideT -= dt;
      if (c.sideT <= 0) c.side = 0;
    }
    const pos = { x: c.x + dx * speed * dt, z: c.z + dz * speed * dt };
    pushOut(pos, BOXES, LAKE_BOX);
    const moved = Math.hypot(pos.x - c.x, pos.z - c.z);
    if (chasing && d > 2 && (dx || dz) && moved < speed * dt * 0.3) {
      c.stuck += dt;
      if (c.stuck > 0.4 && !c.side) { c.side = Math.random() < 0.5 ? -1 : 1; c.sideT = 1.2; c.stuck = 0; }
    } else c.stuck = 0;
    c.x = pos.x; c.z = pos.z;
    if (dx || dz) {
      const target = Math.atan2(dx, dz);
      let dh = target - c.heading;
      while (dh > Math.PI) dh -= Math.PI * 2;
      while (dh < -Math.PI) dh += Math.PI * 2;
      c.heading += dh * Math.min(1, dt * 10);
    }
    c.phase += dt * speed * 2.4;
    const amp = moved > 0.001 ? (speed > 3 ? 0.9 : 0.5) : 0;
    const s = Math.sin(c.phase) * amp;
    c.parts.armL.rotation.x = s;
    c.parts.armR.rotation.x = -s;
    c.parts.legL.rotation.x = -s;
    c.parts.legR.rotation.x = s;
    c.mesh.position.set(c.x, groundHeightAt(c.x, c.z), c.z);
    c.mesh.rotation.y = c.heading;

    if (!chasing || !c.sees) return;
    c.fireCd -= dt;
    if (state.wanted >= 3 && dPlayer < 24 && dPlayer > 2.5 && c.fireCd <= 0) {
      c.fireCd = Math.max(0.8, 2.0 - (state.wanted - 3) * 0.4) + Math.random() * 0.6;
      c.firedT = 1;
      c.parts.armR.rotation.x = -Math.PI / 2;
      c.heading = Math.atan2(pp.x - c.x, pp.z - c.z);
      c.mesh.rotation.y = c.heading;
      fireAt(c.x, groundHeightAt(c.x, c.z) + 1.35, c.z, dPlayer, 7);
    }
  }
  function fireAt(fx, fy, fz, dist, damage) {
    const pp = player.position;
    const chance = 0.28 + (state.wanted - 3) * 0.07 - dist * 0.006;
    const hit = Math.random() < chance;
    state.emit('copShot', {
      from: [fx, fy, fz],
      to: [pp.x + (hit ? 0 : (Math.random() - 0.5) * 2), pp.y + 1.2, pp.z + (hit ? 0 : (Math.random() - 0.5) * 2)],
    });
    if (!hit) return;
    if (player.driving) state.emit('policeHitCar', { damage: damage * 1.5 });
    else state.emit('playerShot', { damage });
  }

  // ---- per-frame car
  function stepCar(car, dt, chasing) {
    const on = Math.floor(flash * 4) % 2 === 0;
    car.red.emissiveIntensity = on ? 2.2 : 0.2;
    car.blue.emissiveIntensity = on ? 0.2 : 2.2;
    car.hitCd -= dt;
    if (car.burning !== undefined) {
      car.burning -= dt;
      car.speed *= Math.exp(-2 * dt);
      car.status = 'BURNING';
      if (car.burning <= 0) {
        car.burning = undefined;
        car.wrecked = true;
        car.timer = 0;
        car.white.color.set(0x222222);
        state.emit('explosion', { x: car.x, z: car.z, y: car.group.position.y, source: car });
        state.emit('takedown', { kind: 'pcar' });
      }
    }
    if (car.wrecked) {
      car.status = 'WRECKED';
      car.red.emissiveIntensity = 0;
      car.blue.emissiveIntensity = 0;
      car.timer += dt;
      if (car.timer > 30 && Math.hypot(car.x - player.position.x, car.z - player.position.z) > 60) removeCar(car);
      return;
    }
    const pp = player.position;
    const dPlayer = Math.hypot(pp.x - car.x, pp.z - car.z);
    if (car.roadblock) {
      car.status = chasing ? 'ROADBLOCK' : 'CLEAR';
      car.timer += dt;
      if ((!chasing && dPlayer > 40) || car.timer > 70) removeCar(car);
      return;
    }
    let tx;
    let tz;
    let target = CAR_SPEED;
    if (!chasing) {
      car.timer += dt;
      car.status = 'CLEAR';
      if (car.timer > 20 || dPlayer > 150) { removeCar(car); return; }
    }
    const goal = chasing ? goalFor(car) : [car.x + (car.x - pp.x) * 3, car.z + (car.z - pp.z) * 3];
    car.pathT -= dt;
    if (car.pathT <= 0) {
      car.pathT = 1;
      const gn = nearestNode(goal[0], goal[1]);
      car.path = waypoints(bfsPath(nearestNode(car.x, car.z).id, gn.id));
      while (car.path.length > 1) {
        const [wx, wz] = car.path[0];
        const [nx, nz] = car.path[1];
        const toW = (wx - car.x) * (nx - wx) + (wz - car.z) * (nz - wz);
        if (toW < 0 || Math.hypot(wx - car.x, wz - car.z) < 4) car.path.shift(); else break;
      }
    }
    const direct = chasing && inSight && car.sees && dPlayer < 45;
    const ramming = direct && player.inVehicle && dPlayer < 25;
    if (direct) {
      tx = pp.x; tz = pp.z;
      if (ramming) target = CAR_SPEED * 1.15;
      else if (dPlayer < 9) target = 0;
      else if (dPlayer < 18) target = 6;
    } else if (car.path.length) {
      [tx, tz] = car.path[0];
      if (Math.hypot(tx - car.x, tz - car.z) < 4) car.path.shift();
      if (!inSight) target = 11;
    } else { tx = car.x; tz = car.z; target = 0; }
    car.status = !chasing ? 'CLEAR' : ramming ? 'RAMMING' : car.deployed && car.speed < 1 ? 'DEPLOYED'
      : inSight ? 'PURSUIT' : 'SEARCHING';
    const want = Math.atan2(tx - car.x, tz - car.z);
    let dh = want - car.heading;
    while (dh > Math.PI) dh -= Math.PI * 2;
    while (dh < -Math.PI) dh += Math.PI * 2;
    if (Math.abs(dh) > 1.2) target = Math.min(target, 5);
    car.heading += THREE.MathUtils.clamp(dh, -2.2 * dt, 2.2 * dt);
    car.speed += (target - car.speed) * (1 - Math.exp(-2.5 * dt));
    const pos = {
      x: car.x + Math.sin(car.heading) * car.speed * dt,
      z: car.z + Math.cos(car.heading) * car.speed * dt,
    };
    pushOut(pos, CAR_BOXES, LAKE_BOX);
    car.x = pos.x; car.z = pos.z;
    car.group.position.set(car.x, groundHeightAt(car.x, car.z) - 0.05, car.z);
    car.group.rotation.y = car.heading;

    if (chasing && !car.deployed && dPlayer < 12 && car.speed < 3 && !player.inVehicle) {
      car.deployed = true;
      for (const side of [-1, 1]) {
        if (cops.length >= MAX_COPS) break;
        const p = { x: car.x + Math.cos(car.heading) * 1.6 * side, z: car.z - Math.sin(car.heading) * 1.6 * side };
        pushOut(p, BOXES, LAKE_BOX);
        makeCop(p.x, p.z, { callsign: `${car.callsign}${side < 0 ? 'A' : 'B'}` });
      }
    }
    // Contact with the player: ramming hurts the vehicle / the player.
    const reach = player.driving ? 2.6 : 2.0;
    if (car.speed > 6 && dPlayer < reach && car.hitCd <= 0 && !player.frozen) {
      car.hitCd = 1.2;
      if (player.driving) {
        state.emit('policeHitCar', { damage: car.speed * 1.6 });
        state.emit('crash', { speed: car.speed });
        player.crash(0.4);
      } else state.emit('playerShot', { damage: 12 });
      car.speed *= 0.3;
    }
    for (const n of npcs.people) {
      if (car.speed < 5 || !npcs.alive(n)) continue;
      const p = n.mesh.position;
      if (Math.hypot(p.x - car.x, p.z - car.z) < 2.0) npcs.knock(n, car.x, car.z, false);
    }
  }

  // ---- roadblock: two cruisers across the road ahead of the player
  function placeRoadblock() {
    const pp = player.position;
    const vx = Math.sin(player.facing);
    const vz = Math.cos(player.facing);
    let best = null;
    let bs = -Infinity;
    for (const n of NODES) {
      if (n.type === 'roundabout') continue;
      const dx = n.x - pp.x;
      const dz = n.z - pp.z;
      const d = Math.hypot(dx, dz);
      if (d < 45 || d > 110) continue;
      const ahead = (dx * vx + dz * vz) / d;
      if (ahead < 0.5) continue;
      const sc = ahead * 2 - d / 110;
      if (sc > bs) { bs = sc; best = n; }
    }
    if (!best) return false;
    const toward = Math.atan2(pp.x - best.x, pp.z - best.z);
    const side = toward + Math.PI / 2;
    for (const k of [-1, 1]) {
      const x = best.x + Math.sin(side) * 2.6 * k + Math.sin(toward) * 6;
      const z = best.z + Math.cos(side) * 2.6 * k + Math.cos(toward) * 6;
      makeCar(x, z, side + (k > 0 ? Math.PI : 0), { roadblock: true });
    }
    for (const k of [-1, 1]) {
      if (cops.length >= MAX_COPS) break;
      const gx = best.x + Math.sin(side) * 5 * k + Math.sin(toward) * 9;
      const gz = best.z + Math.cos(side) * 5 * k + Math.cos(toward) * 9;
      makeCop(gx, gz, { callsign: `BLOCK-${k < 0 ? 1 : 2}`, guard: [gx, gz] });
    }
    state.emit('notify', { text: 'Roadblock ahead!', kind: 'crime' });
    return true;
  }

  // ---- helicopter
  function stepHeli(dt, chasing) {
    if (!heli) return;
    heli.rotor.rotation.y += dt * 28;
    heli.tailRotor.rotation.x += dt * 30;
    const pp = player.position;
    const [gx, gz] = chasing ? (inSight ? [pp.x, pp.z] : goalFor(heli)) : [heli.x + (heli.x - pp.x), heli.z + (heli.z - pp.z)];
    const dx = gx - heli.x;
    const dz = gz - heli.z;
    const d = Math.hypot(dx, dz);
    const sp = chasing ? Math.min(20, d * 0.9) : 18;
    if (d > 1) {
      heli.x += (dx / d) * sp * dt;
      heli.z += (dz / d) * sp * dt;
      const want = Math.atan2(dx, dz);
      let dh = want - heli.heading;
      while (dh > Math.PI) dh -= Math.PI * 2;
      while (dh < -Math.PI) dh += Math.PI * 2;
      heli.heading += dh * Math.min(1, dt * 1.5);
    }
    heli.alt += ((chasing ? 24 : 40) - heli.alt) * dt * 0.5;
    heli.group.position.set(heli.x, heli.alt, heli.z);
    heli.group.rotation.set(Math.min(0.25, sp / 80), heli.heading, 0, 'YXZ');
    // Spotlight on the player (or the search point).
    const lit = chasing && heli.sees;
    heli.spot.intensity = lit ? 900 : 0;
    heli.spot.target.position.set(0, -heli.alt, 0);
    heli.cone.material.opacity = lit ? 0.09 : 0.0;
    heli.status = !chasing ? 'CLEAR' : lit ? 'SPOTLIGHT' : 'SEARCHING';
    if (!chasing) {
      heli.timer += dt;
      if (heli.timer > 15) { scene.remove(heli.group); heli = null; }
      return;
    }
    // 5 stars: door gunner.
    heli.fireCd -= dt;
    if (state.wanted >= 5 && lit && heli.fireCd <= 0) {
      heli.fireCd = 1.4 + Math.random();
      heli.status = 'FIRING';
      fireAt(heli.x, heli.alt - 1, heli.z, d, 6);
    }
  }

  // ---- main update
  function update(dt) {
    const chasing = state.wanted > 0;
    flash += dt;
    checkVehicleHits(dt);
    updateSight(dt);
    if (chasing && !wasWanted) { lastSeen.x = player.position.x; lastSeen.z = player.position.z; sightT = 2; }
    wasWanted = state.wanted;

    // Decay: one star per 30 s without a crime, counted while unseen.
    if (state.wanted > 0) {
      if (state.lastCrime > decayFrom) decayFrom = state.lastCrime;
      if (inSight) decayFrom += dt; // the clock pauses while you are seen
      if (state.time - decayFrom >= WANTED_DECAY_S) {
        decayFrom = state.time;
        const before = state.wanted;
        state.wanted -= 1;
        state.emit('wanted', { before, why: 'decay' });
      }
    } else decayFrom = state.time;

    // Spawns, centred on the search zone.
    spawnCooldown -= dt;
    roadblockCd -= dt;
    const cx = inSight ? player.position.x : lastSeen.x;
    const cz = inSight ? player.position.z : lastSeen.z;
    if (chasing && spawnCooldown <= 0) {
      const footAlive = cops.filter((c) => c.state !== 'down' && !c.guard).length;
      const chaseCars = cars.filter((c) => c.state === 'chase' && !c.roadblock && !c.wrecked).length;
      if (state.wanted >= 4 && !heli && footAlive >= 2) {
        const h = heliMesh();
        scene.add(h.group);
        const a = Math.random() * Math.PI * 2;
        heli = { ...h, x: cx + Math.cos(a) * 120, z: cz + Math.sin(a) * 120, alt: 45, heading: 0,
          callsign: 'EAGLE-1', status: 'SEARCHING', timer: 0, fireCd: 3, sees: false };
        state.emit('notify', { text: 'Police helicopter inbound', kind: 'crime' });
        spawnCooldown = 2;
      } else if (footAlive < footCopsFor(state.wanted) && cops.length < MAX_COPS) {
        const n = footSpawnPoint(cx, cz);
        if (n) makeCop(n.x, n.z);
        spawnCooldown = 1.6;
      } else if (chaseCars < carsFor(state.wanted)) {
        const n = carSpawnPoint(cx, cz);
        if (n) makeCar(n.x, n.z, Math.atan2(cx - n.x, cz - n.z));
        spawnCooldown = 3;
      } else if (state.wanted >= 4 && !heli) {
        const h = heliMesh();
        scene.add(h.group);
        const a = Math.random() * Math.PI * 2;
        heli = { ...h, x: cx + Math.cos(a) * 120, z: cz + Math.sin(a) * 120, alt: 45, heading: 0,
          callsign: 'EAGLE-1', status: 'SEARCHING', timer: 0, fireCd: 3, sees: false };
        state.emit('notify', { text: 'Police helicopter inbound', kind: 'crime' });
        spawnCooldown = 3;
      } else if (state.wanted >= 4 && roadblockCd <= 0 && player.inVehicle && Math.abs(player.speed) > 8) {
        if (placeRoadblock()) roadblockCd = 40;
        spawnCooldown = 3;
      }
    }
    if (!chasing) {
      for (const c of cops) if (c.state === 'chase') { c.state = 'leave'; c.timer = 0; }
      for (const c of cars) if (c.state === 'chase') { c.state = 'leave'; c.timer = 0; }
      if (heli && heli.status !== 'CLEAR') heli.timer = 0;
    }

    for (let i = cops.length - 1; i >= 0; i--) stepCop(cops[i], dt, chasing && cops[i].state !== 'leave');
    for (let i = cars.length - 1; i >= 0; i--) stepCar(cars[i], dt, chasing && cars[i].state !== 'leave');
    stepHeli(dt, chasing);

    // Solid police cars: push the player (on foot / bike / car) out.
    const pp = player.position;
    for (const car of cars) {
      const dx = pp.x - car.x;
      const dz = pp.z - car.z;
      const d = Math.hypot(dx, dz);
      const R = player.driving ? 2.6 : player.riding ? 2.0 : 1.8;
      if (d < R && d > 0.01) player.nudge(car.x + (dx / d) * R, car.z + (dz / d) * R);
    }

    if (chasing && !player.frozen) {
      const slow = Math.abs(player.speed) < 2.5;
      const near = cops.some((c) => c.state === 'chase' && Math.hypot(c.x - pp.x, c.z - pp.z) < ARREST_RANGE);
      if (near && slow) arrestT += dt; else arrestT = Math.max(0, arrestT - dt * 2);
      if (arrestT >= ARREST_TIME) {
        arrestT = 0;
        const stars = state.wanted;
        onBusted(stars, stars * BUST_FINE_PER_STAR);
      }
    } else arrestT = 0;
  }

  // HUD response panel rows, nearest first.
  function units() {
    const pp = player.position;
    const rows = [];
    for (const c of cars) rows.push({ kind: 'car', callsign: c.callsign, status: c.status, dist: Math.hypot(c.x - pp.x, c.z - pp.z) });
    if (heli) rows.push({ kind: 'heli', callsign: heli.callsign, status: heli.status, dist: Math.hypot(heli.x - pp.x, heli.z - pp.z) });
    for (const c of cops) if (c.state !== 'down') rows.push({ kind: 'foot', callsign: c.callsign, status: c.status || 'PURSUIT', dist: Math.hypot(c.x - pp.x, c.z - pp.z) });
    rows.sort((a, b) => a.dist - b.dist);
    return rows;
  }

  return {
    update,
    cops,
    cars,
    damageCop,
    damageCar,
    despawnAll,
    units,
    get heli() { return heli; },
    get inSight() { return inSight; },
    get lastSeen() { return lastSeen; },
    get searchRadius() { return searchRadiusFor(state.wanted); },
    get arrestProgress() { return arrestT / ARREST_TIME; },
    get decayLeft() { return WANTED_DECAY_S - (state.time - Math.max(decayFrom, state.lastCrime)); },
  };
}
