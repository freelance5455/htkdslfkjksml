// combat.js — G3 + revision 2 arsenal (weapons.js).
//  1-5 pick a weapon you own (Q cycles), F attacks (hold F for automatic
//  weapons), a left click without dragging fires one shot, R reloads.
//  * Fists: jab, 60-degree cone, 1.8 m. Punched civilians run away (third
//    punch knocks them down); assaulting a civilian or a cop is a crime.
//  * Guns: hitscan along the camera's ground-plane forward from chest
//    height (the HUD crosshair sits on that ray), blocked by buildings,
//    small aim assist on people. Shotgun = 7-pellet cone. Cars soak
//    bullets (and catch fire / explode at 0 HP). Firing = +1 star (once
//    per 4 s burst) and scares everyone within 25 m.
//  * Pistol crate in Downtown (places.js) gives the Hornet 9 + 24 rounds,
//    refilling 90 s after pickup.

import * as THREE from 'three';
import { PISTOL_CRATE } from './places.js';
import { groundHeightAt, BOXES, segmentBoxT } from './player.js';
import { WEAPONS, WEAPON, GUN_IDS } from './weapons.js';

const PUNCH_RANGE = 1.8;
const PUNCH_CD = 0.45;
const BODY_R = 0.45;
const ASSIST = 0.06;
const CRIME_WINDOW = 4;

export const DRIVEBY = ['pistol', 'smg'];
let driveByWarned = false;

export function createCombat(scene, { state, player, npcs, police, camera, dom, traffic }) {
  void camera;
  const extraSources = []; // missions.js registers shootable entities here
  let punchCd = 0;
  let shotCd = 0;
  let reloadT = 0;
  let lastShootCrime = -1e9;
  let lastAssault = -1e9;
  let hitMarker = 0;
  let holding = false; // F held (automatic fire)
  const fx = [];

  // ------------------------------------------------------------ crate
  const crate = new THREE.Group();
  {
    const wood = new THREE.MeshStandardMaterial({ color: 0x9a6a3a, flatShading: true, roughness: 0.9 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x5a3a1e, flatShading: true, roughness: 0.9 });
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.7, 0.7), wood);
    body.position.y = 0.35;
    body.castShadow = true;
    crate.add(body);
    for (const x of [-0.42, 0.42]) {
      const slat = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.72, 0.72), dark);
      slat.position.set(x, 0.35, 0);
      crate.add(slat);
    }
    const [cx, cz] = PISTOL_CRATE.pos;
    crate.position.set(cx, groundHeightAt(cx, cz) - 0.02, cz);
    scene.add(crate);
  }
  const pickup = new THREE.Group();
  {
    const m = new THREE.MeshStandardMaterial({ color: 0x2b2d33, emissive: 0x3388ff, emissiveIntensity: 0.25, roughness: 0.4 });
    const b = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.11, 0.09), m);
    const g = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.22, 0.08), m);
    g.position.set(-0.13, -0.12, 0);
    g.rotation.z = -0.25;
    pickup.add(b, g);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.55, 0.04, 6, 24),
      new THREE.MeshBasicMaterial({ color: 0x55aaff }));
    ring.rotation.x = Math.PI / 2;
    ring.position.y = -0.55;
    pickup.add(ring);
    pickup.position.set(crate.position.x, crate.position.y + 1.45, crate.position.z);
    scene.add(pickup);
  }
  let crateRefill = 0;

  // ------------------------------------------------------------ effects
  const flashGeo = new THREE.IcosahedronGeometry(0.12, 0);
  const sparkGeo = new THREE.IcosahedronGeometry(0.08, 0);
  function tracer(from, to, color = 0xfff1a8) {
    const g = new THREE.BufferGeometry().setFromPoints([from, to]);
    const line = new THREE.Line(g, new THREE.LineBasicMaterial({ color, transparent: true }));
    scene.add(line);
    fx.push({ obj: line, t: 0.08, max: 0.08, own: true });
  }
  function flash(at, geo = flashGeo, color = 0xffd25a) {
    const s = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color, transparent: true }));
    s.position.copy(at);
    scene.add(s);
    fx.push({ obj: s, t: 0.06, max: 0.06, own: false });
  }
  state.on((type, d) => {
    if (type === 'copShot') {
      const a = new THREE.Vector3(...d.from);
      tracer(a, new THREE.Vector3(...d.to), 0xff9a7a);
      flash(a);
    }
  });

  // ------------------------------------------------------------ targets
  function targets() {
    const out = [];
    for (const n of npcs.people) {
      if (npcs.alive(n)) out.push({ ref: n, kind: 'civ', p: n.mesh.position });
    }
    for (const c of police.cops) {
      if (c.state !== 'down') out.push({ ref: c, kind: 'cop', p: c.mesh.position });
    }
    for (const src of extraSources) out.push(...src());
    return out;
  }
  // Cars only stop bullets (a row of circles along the body).
  function carTargets() {
    const out = [];
    const lists = [traffic ? traffic.cars : [], police.cars.map((c) => ({ ...c, police: c, L: 4.3, W: 1.9 }))];
    for (const list of lists) {
      for (const c of list) {
        if (c.wrecked || c.driver === 'player') continue;
        const hx = Math.sin(c.heading);
        const hz = Math.cos(c.heading);
        const n = Math.max(2, Math.ceil(c.L / (c.W * 0.8)));
        const y = c.group ? c.group.position.y : 0;
        for (let k = 0; k < n; k++) {
          const off = -c.L / 2 + c.W / 2 + (k * (c.L - c.W)) / (n - 1);
          out.push({ ref: c.police || c, kind: c.police ? 'pcar' : 'car', r: c.W / 2 + 0.15,
            p: { x: c.x + hx * off, y, z: c.z + hz * off } });
        }
      }
    }
    return out;
  }
  function applyDamage(t, amount, fromX, fromZ, kind) {
    let r;
    if (t.kind === 'extra') r = t.hit(amount, fromX, fromZ, kind);
    else if (t.kind === 'car') r = traffic.damageCar(t.ref, kind === 'bullet' ? amount * 0.3 : 0);
    else if (t.kind === 'pcar') r = police.damageCar ? police.damageCar(t.ref, amount * 0.3) : null;
    else if (t.kind === 'cop') r = police.damageCop(t.ref, amount, fromX, fromZ, kind);
    else r = npcs.damage(t.ref, amount, fromX, fromZ, kind);
    if (r === 'dead') state.emit('takedown', { kind: t.kind === 'extra' ? (t.tkind || 'extra') : t.kind });
    return r;
  }

  // ------------------------------------------------------------ fists
  function doPunch() {
    if (punchCd > 0 || player.inVehicle) return;
    punchCd = PUNCH_CD;
    player.punch();
    const pp = player.position;
    const f = player.facing;
    const fx0 = Math.sin(f);
    const fz0 = Math.cos(f);
    let best = null;
    let bd = Infinity;
    for (const t of targets()) {
      if (t.kind === 'extra' && !t.melee) continue;
      const dx = t.p.x - pp.x;
      const dz = t.p.z - pp.z;
      const d = Math.hypot(dx, dz);
      if (d > PUNCH_RANGE || d < 0.01) continue;
      if ((dx * fx0 + dz * fz0) / d < 0.5) continue;
      if (d < bd) { bd = d; best = t; }
    }
    if (best) {
      applyDamage(best, 30, pp.x, pp.z, 'punch');
      hitMarker = 0.2;
      state.emit('punchHit', { kind: best.kind });
      if (best.kind === 'civ') {
        if (state.time - lastAssault > CRIME_WINDOW) {
          lastAssault = state.time;
          state.crime(1, 'assault');
        } else state.lastCrime = state.time;
      }
    } else state.emit('punchMiss');
  }

  // ------------------------------------------------------------ guns
  function castRay(angleOff, range) {
    const pp = player.position;
    const base = player.aimDir;
    const ca = Math.cos(angleOff);
    const sa = Math.sin(angleOff);
    const dir = { x: base.x * ca - base.z * sa, z: base.x * sa + base.z * ca };
    const out = player.driving ? player.car.W / 2 + 0.8 : player.riding ? 1.0 : 0.5;
    const ox = pp.x + dir.x * out;
    const oz = pp.z + dir.z * out;
    const oy = pp.y + (player.inVehicle ? 1.2 : 1.3);
    let wallT = range;
    const ex = ox + dir.x * range;
    const ez = oz + dir.z * range;
    for (const b of BOXES) {
      const t = segmentBoxT(ox, oy, oz, ex, oy, ez, b);
      if (t !== null && t * range < wallT) wallT = t * range;
    }
    let hit = null;
    let hitT = wallT;
    for (const t of [...targets(), ...carTargets()]) {
      const dx = t.p.x - ox;
      const dz = t.p.z - oz;
      const along = dx * dir.x + dz * dir.z;
      if (along <= 0 || along > hitT) continue;
      const perp = Math.abs(dx * dir.z - dz * dir.x);
      const assist = t.r ? along * 0.01 : along * ASSIST;
      if (perp > (t.r || BODY_R) + assist) continue;
      hit = t;
      hitT = along;
    }
    return { hit, t: hitT, ox, oy, oz, dir };
  }
  function castShot() { return castRay(0, (WEAPON[state.weapon] && WEAPON[state.weapon].range) || 45); }

  function doShoot() {
    const W = WEAPON[state.weapon];
    const g = state.weapons[state.weapon];
    if (!W || !g || !g.owned) return;
    // Revision 3 drive-by: one-handed guns (pistol, SMG) fire from a car or
    // the bike, aimed with the camera; two-handed guns need you on foot.
    const driveBy = player.inVehicle;
    if (driveBy && !DRIVEBY.includes(W.id)) {
      if (!driveByWarned) { driveByWarned = true; state.emit('notify', { text: 'Drive-by: switch to the pistol (2) or SMG (3)', kind: 'warn' }); }
      return;
    }
    if (shotCd > 0 || reloadT > 0) return;
    if (g.clip <= 0) {
      if (g.ammo > 0) startReload();
      else { holding = false; state.emit('notify', { text: `${W.name}: out of ammo — AMMU-NATION sells more`, kind: 'warn' }); }
      return;
    }
    shotCd = W.rate;
    g.clip -= 1;
    const dir = player.aimDir;
    player.aim(dir.x, dir.z);
    player.group.updateMatrixWorld(true);
    const muzzle = driveBy
      ? new THREE.Vector3(player.position.x + dir.x * 1.3, player.position.y + 1.25, player.position.z + dir.z * 1.3)
      : player.muzzleWorld(new THREE.Vector3());
    flash(muzzle);
    const pp = player.position;
    // One ray per pellet; damage per target accumulates (shotgun).
    const hits = new Map();
    for (let i = 0; i < W.pellets; i++) {
      const off = (Math.random() - 0.5) * 2 * W.spread;
      const r = castRay(off, W.range);
      const end = new THREE.Vector3(r.ox + r.dir.x * r.t, r.oy, r.oz + r.dir.z * r.t);
      if (r.hit) end.y = (r.hit.p.y || pp.y) + (r.hit.kind === 'car' || r.hit.kind === 'pcar' ? 0.9 : 1.2);
      tracer(muzzle, end);
      flash(end, sparkGeo, 0xffffff);
      if (r.hit) {
        const key = r.hit.ref || r.hit;
        const h = hits.get(key) || { t: r.hit, dmg: 0 };
        h.dmg += W.dmg;
        hits.set(key, h);
      }
    }
    for (const { t, dmg } of hits.values()) applyDamage(t, dmg, pp.x, pp.z, 'bullet');
    if (hits.size) hitMarker = 0.25;
    npcs.panic(pp.x, pp.z, 25);
    if (state.time - lastShootCrime > CRIME_WINDOW) {
      lastShootCrime = state.time;
      state.crime(1, 'shooting');
    } else state.lastCrime = state.time;
    state.emit('shot', { weapon: W.id });
    if (g.clip === 0 && g.ammo > 0) startReload();
  }

  function startReload() {
    const W = WEAPON[state.weapon];
    const g = state.weapons[state.weapon];
    if (!W || !g || reloadT > 0 || g.clip >= W.clip || g.ammo <= 0) return;
    reloadT = W.id === 'shotgun' ? 1.6 : 1.2;
    state.emit('reload');
  }

  function attack() {
    if (player.frozen || !player.followActive) return;
    if (state.weapon === 'fist' || !WEAPON[state.weapon]) doPunch(); else doShoot();
  }
  function select(id) {
    if (id !== 'fist' && !(state.weapons[id] && state.weapons[id].owned)) {
      const W = WEAPON[id];
      if (W) state.emit('notify', { text: `${W.name} — buy it at AMMU-NATION (rank ${W.rank})`, kind: 'info' });
      return;
    }
    if (state.weapon !== id) { state.weapon = id; reloadT = 0; state.emit('weaponSwitch', { id }); }
  }
  function cycleWeapon() {
    const owned = ['fist', ...GUN_IDS.filter((id) => state.weapons[id].owned)];
    select(owned[(owned.indexOf(state.weapon) + 1) % owned.length]);
  }

  // ------------------------------------------------------------ input
  window.addEventListener('keydown', (e) => {
    if (player.frozen) return;
    const k = e.key.toLowerCase();
    if (k === 'f') {
      if (!e.repeat) attack();
      holding = true;
      return;
    }
    if (e.repeat) return;
    if (k === 'q') cycleWeapon();
    else if (k === 'r') startReload();
    else if (k >= '1' && k <= '5') {
      const w = WEAPONS.find((x) => x.slot === +k);
      if (w) select(w.id);
    }
  });
  window.addEventListener('keyup', (e) => { if (e.key.toLowerCase() === 'f') holding = false; });
  window.addEventListener('blur', () => { holding = false; });
  let down = null;
  dom.addEventListener('pointerdown', (e) => {
    if (e.button === 0) down = { x: e.clientX, y: e.clientY, t: performance.now() };
  });
  dom.addEventListener('pointerup', (e) => {
    if (e.button !== 0 || !down) return;
    const moved = Math.hypot(e.clientX - down.x, e.clientY - down.y);
    const quick = performance.now() - down.t < 350;
    down = null;
    if (moved < 6 && quick && state.weapon !== 'fist') attack();
  });

  // ------------------------------------------------------------ update
  const aimPoint = new THREE.Vector3();
  function update(dt) {
    punchCd -= dt;
    shotCd -= dt;
    hitMarker -= dt;
    if (holding && WEAPON[state.weapon] && WEAPON[state.weapon].auto && shotCd <= 0) attack();
    if (reloadT > 0) {
      reloadT -= dt;
      if (reloadT <= 0) {
        const W = WEAPON[state.weapon];
        const g = state.weapons[state.weapon];
        if (W && g) {
          const take = Math.min(W.clip - g.clip, g.ammo);
          g.clip += take;
          g.ammo -= take;
        }
      }
    }
    const W = WEAPON[state.weapon];
    player.weaponVisible = !!(W && !W.melee) && !player.inVehicle;
    if (player.setGunModel) player.setGunModel(W && W.barrel ? W.barrel : 1);

    const stocked = crateRefill <= 0;
    pickup.visible = stocked;
    if (!stocked) crateRefill -= dt;
    pickup.rotation.y += dt * 1.8;
    pickup.position.y = crate.position.y + 1.45 + Math.sin(performance.now() / 400) * 0.08;
    const pp = player.position;
    if (stocked && !player.inVehicle && Math.hypot(pp.x - crate.position.x, pp.z - crate.position.z) < 1.6) {
      const first = !state.hasPistol;
      state.giveWeapon('pistol', PISTOL_CRATE.rounds);
      crateRefill = PISTOL_CRATE.respawn;
      state.emit('notify', {
        text: first ? 'Hornet 9 picked up! F / click to shoot · R reload · 1-5 or Q switch weapon'
          : `+${PISTOL_CRATE.rounds} Hornet 9 rounds`,
        kind: 'good',
      });
    }

    for (let i = fx.length - 1; i >= 0; i--) {
      const f = fx[i];
      f.t -= dt;
      f.obj.material.opacity = Math.max(0, f.t / f.max);
      if (f.t <= 0) {
        scene.remove(f.obj);
        if (f.own) f.obj.geometry.dispose();
        f.obj.material.dispose();
        fx.splice(i, 1);
      }
    }
    const d = player.aimDir;
    aimPoint.set(pp.x + d.x * 25, pp.y + 1.3, pp.z + d.z * 25);
  }

  return {
    update,
    attack,
    select,
    cycleWeapon,
    startReload,
    get reloading() { return reloadT > 0; },
    get hitMarker() { return hitMarker > 0; },
    get aimPoint() { return aimPoint; },
    cratePos: PISTOL_CRATE.pos,
    get crateStocked() { return crateRefill <= 0; },
    castShot,
    addTargets(fn) { extraSources.push(fn); },
  };
}
