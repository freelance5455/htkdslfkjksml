// economy.js — G4: shops you can enter with E + cash pickups on the street.
//  * 4 shops (places.js): AMMU-NATION (pistol $500, ammo, armour),
//    PHARMACY (health), PIZZA and 24/7 (food = health). Walk up to the
//    door, press E: the shop interior screen opens and the game pauses
//    the player; buy with 1-4 or a click, leave with E / ESC.
//  * Cash pickups: green banknote bundles on the sidewalks ($10-$60),
//    respawning elsewhere 45 s after pickup. Shot civilians drop a little
//    cash too.

import * as THREE from 'three';
import { SHOPS } from './places.js';
import { groundHeightAt } from './player.js';
import { WEAPON } from './weapons.js';

const DOOR_RADIUS = 2.2;
const CASH_COUNT = 14;
const CASH_RESPAWN = 45;

export function createEconomy(scene, { state, player, npcs, ui }) {
  // ------------------------------------------------------------ door markers
  // A pulsing ring + floating arrow at every shop door.
  const doorFx = SHOPS.map((shop) => {
    const [x, z] = shop.door;
    const y = groundHeightAt(x, z);
    const g = new THREE.Group();
    g.position.set(x, y + 0.03, z);
    const ring = new THREE.Mesh(new THREE.RingGeometry(0.75, 0.95, 24),
      new THREE.MeshBasicMaterial({ color: shop.color, transparent: true, opacity: 0.85, side: THREE.DoubleSide }));
    ring.rotation.x = -Math.PI / 2;
    g.add(ring);
    const arrow = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.4, 4),
      new THREE.MeshStandardMaterial({ color: shop.color, emissive: shop.color, emissiveIntensity: 0.6 }));
    arrow.rotation.x = Math.PI;
    arrow.position.y = 2.6;
    g.add(arrow);
    scene.add(g);
    return { shop, g, ring, arrow };
  });

  let openShop = null;
  let swallowE = false; // the E press that opened the shop must not close it

  function nearShop() {
    const pp = player.position;
    if (player.inVehicle) return null;
    return SHOPS.find((s) => Math.hypot(pp.x - s.door[0], pp.z - s.door[1]) < DOOR_RADIUS) || null;
  }

  // ------------------------------------------------------------ buying
  // Revision 2: guns are rank-gated; the ammo item prices itself from the
  // gun in hand (weapons.js ammoPack / ammoPrice).
  function priceOf(item) {
    if (item.give.weapon) return WEAPON[item.give.weapon].price;
    if (item.give.ammoInHand) { const w = WEAPON[state.weapon]; return w && !w.melee ? w.ammoPrice : 0; }
    return item.price;
  }
  function canBuy(item) {
    item.price = priceOf(item);
    if (item.give.weapon) {
      const w = WEAPON[item.give.weapon];
      if (state.rankInfo.rank < w.rank) return `Needs respect rank ${w.rank}`;
      if (state.weapons[w.id].owned) { item.label = `${w.label} — ${w.ammoPack} rounds`; item.price = w.ammoPrice; }
    }
    if (item.give.ammoInHand) {
      const w = WEAPON[state.weapon];
      if (!w || w.melee) return 'Hold a gun first (1-5)';
      item.label = `${w.name} ammo x${w.ammoPack}`;
    }
    if (item.needs === 'pistol' && !state.hasPistol) return 'Needs a pistol';
    if (item.give.hp && state.hp >= 100) return 'Health full';
    if (item.give.armor && state.armor >= 100) return 'Armour full';
    if (item.give.pistol && state.hasPistol) return null; // re-buy = more rounds
    if (state.money < item.price) return 'Not enough cash';
    return null;
  }
  function buy(item) {
    const why = canBuy(item);
    if (why) { ui.shopMessage(why, 'bad'); return false; }
    if (!state.charge(item.price)) { ui.shopMessage('Not enough cash', 'bad'); return false; }
    const g = item.give;
    if (g.hp) state.heal(g.hp);
    if (g.armor) state.addArmor(g.armor);
    if (g.ammo) state.ammo += g.ammo;
    if (g.pistol) state.givePistol(g.pistol);
    if (g.weapon) {
      const w = WEAPON[g.weapon];
      state.giveWeapon(w.id, state.weapons[w.id].owned ? w.ammoPack : w.clip + w.ammoPack);
    }
    if (g.ammoInHand) { const w = WEAPON[state.weapon]; state.weapons[w.id].ammo += w.ammoPack; }
    ui.shopMessage(`Bought ${item.label}  -$${item.price}`, 'good');
    state.emit('purchase', { shop: openShop && openShop.id, item: item.id });
    return true;
  }

  function enter(shop) {
    openShop = shop;
    swallowE = true;
    player.frozen = true;
    ui.openShop(shop, {
      buy: (item) => { buy(item); ui.refreshShop(shop, canBuy); },
      leave: () => leave(),
      canBuy,
    });
  }
  function leave() {
    if (!openShop) return;
    const shop = openShop;
    openShop = null;
    ui.closeShop();
    player.frozen = false;
    // Step back out onto the street, facing away from the door.
    const b = shop.door;
    const away = shop.door[1] > 0 ? Math.PI : 0; // shops face the road
    player.teleport(b[0], b[1] + (away === 0 ? 1.2 : -1.2), away);
  }

  // E near a door = enter (returns true so the bike toggle is skipped).
  function interact() {
    if (openShop) { leave(); return true; }
    const s = nearShop();
    if (!s) return false;
    enter(s);
    return true;
  }
  window.addEventListener('keydown', (e) => {
    if (!openShop) return;
    const k = e.key.toLowerCase();
    if (k === 'e' && swallowE) { swallowE = false; return; }
    swallowE = false;
    if (k === 'escape' || k === 'e') { e.preventDefault(); leave(); return; }
    const n = parseInt(k, 10);
    if (n >= 1 && n <= openShop.items.length) {
      buy(openShop.items[n - 1]);
      ui.refreshShop(openShop, canBuy);
    }
  });

  // ------------------------------------------------------------ cash
  const cashGeo = new THREE.BoxGeometry(0.42, 0.16, 0.22);
  const cashMat = new THREE.MeshStandardMaterial({
    color: 0x3fbf5f, emissive: 0x1f8f3f, emissiveIntensity: 0.5, roughness: 0.6,
  });
  const bandMat = new THREE.MeshStandardMaterial({ color: 0xf5f0e0, roughness: 0.6 });
  const bandGeo = new THREE.BoxGeometry(0.08, 0.17, 0.23);
  const cash = [];
  function makeCash(x, z, amount, temporary) {
    const g = new THREE.Group();
    g.add(new THREE.Mesh(cashGeo, cashMat));
    g.add(new THREE.Mesh(bandGeo, bandMat));
    const base = groundHeightAt(x, z) + 0.45;
    g.position.set(x, base, z);
    scene.add(g);
    const c = { g, x, z, base, amount, temporary, respawn: 0, life: temporary ? 40 : Infinity };
    cash.push(c);
    return c;
  }
  function randomSidewalkSpot() {
    const pp = player.position;
    for (let t = 0; t < 50; t++) {
      const n = npcs.nodes[Math.floor(Math.random() * npcs.nodes.length)];
      if (n.onRoad) continue;
      if (Math.hypot(n.x - pp.x, n.z - pp.z) < 25 && t < 40) continue;
      return [n.x + (Math.random() - 0.5) * 1.2, n.z + (Math.random() - 0.5) * 1.2];
    }
    return [0, 20];
  }
  const cashAmount = () => 10 + Math.floor(Math.random() * 6) * 10;
  for (let i = 0; i < CASH_COUNT; i++) {
    const [x, z] = randomSidewalkSpot();
    makeCash(x, z, cashAmount(), false);
  }
  // Shot civilians drop $5-$25.
  function dropCash(x, z, amount) {
    makeCash(x + 0.6, z + 0.3, amount || 5 + Math.floor(Math.random() * 5) * 5, true);
  }

  // ------------------------------------------------------------ update
  let promptShop = null;
  function update(dt) {
    const t = performance.now() / 1000;
    for (const d of doorFx) {
      d.ring.material.opacity = 0.55 + Math.sin(t * 3) * 0.3;
      d.arrow.position.y = 2.6 + Math.sin(t * 2.5) * 0.15;
      d.arrow.rotation.y += dt * 2;
    }
    const s = openShop ? null : nearShop();
    if (s !== promptShop) {
      promptShop = s;
      ui.prompt(s ? `Press E to enter ${s.name}` : null);
    }

    const pp = player.position;
    for (let i = cash.length - 1; i >= 0; i--) {
      const c = cash[i];
      if (c.respawn > 0) {
        c.respawn -= dt;
        if (c.respawn <= 0) {
          const [x, z] = randomSidewalkSpot();
          c.x = x; c.z = z;
          c.base = groundHeightAt(x, z) + 0.45;
          c.amount = cashAmount();
          c.g.visible = true;
        }
        continue;
      }
      c.g.rotation.y += dt * 2;
      c.g.position.set(c.x, c.base + Math.sin(t * 3 + i) * 0.08, c.z);
      if (c.temporary) {
        c.life -= dt;
        if (c.life <= 0) { scene.remove(c.g); cash.splice(i, 1); continue; }
      }
      if (Math.hypot(pp.x - c.x, pp.z - c.z) < 1.3) {
        state.addMoney(c.amount);
        state.emit('notify', { text: `+$${c.amount}`, kind: 'money' });
        if (c.temporary) { scene.remove(c.g); cash.splice(i, 1); } else {
          c.g.visible = false;
          c.respawn = CASH_RESPAWN;
        }
      }
    }
  }

  return {
    update,
    interact,
    dropCash,
    get openShop() { return openShop; },
    shops: SHOPS,
    cash,
    enter,
    leave,
    buy,
  };
}
