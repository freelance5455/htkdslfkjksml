// game.js — glue for the G2-G5 gameplay systems.
// Creates the shared state, police (G2), combat (G3), shops + cash +
// missions (G4), HUD + save + day/night (G5), and runs the BUSTED /
// WASTED flows:
//  * BUSTED: fine $50 per star, wanted cleared, respawn at the police
//    station.
//  * WASTED: fine $100, health restored, wanted cleared, respawn at the
//    hospital.
// Both fail the active mission. Save: K saves to localStorage, every
// mission passed auto-saves, the save loads on start; Shift+N twice
// starts a new game.

import { createState } from './state.js';
import { createPolice } from './police.js';
import { createCombat } from './combat.js';
import { createEconomy } from './economy.js';
import { createMissions } from './missions.js';
import { createDayNight } from './daynight.js';
import { createHUD } from './hud.js';
import { createTraffic } from './traffic.js';
import { createWeather } from './weather.js';
import { createAudio } from './audio.js';
import { createGarage } from './garage.js';
import { createFX } from './fx.js';
import { createCamFX } from './camfx.js';
import { createSkids } from './skids.js';
import { createStunts } from './stunts.js';
import { createEvents } from './events.js';
import { createMenu } from './menu.js';
import { createSettings } from './settings.js';
import * as THREE from 'three';
import { lineOfSight } from './police.js';
import { LAYOUT, zoneAt, NODES, EDGES } from './layout.js';
import { SHOPS, HOSPITAL, POLICE_STATION } from './places.js';

const WASTED_FINE = 100;

export function createGame({ scene, camera, renderer, player, npcs, maps, sun, hemi, roads, settings = createSettings() }) {
  const state = createState();
  npcs.setPlayer(player);

  // HUD first: its ui object is shared with the shops.
  let hud = null;
  const uiProxy = {
    notify: (...a) => hud.ui.notify(...a),
    big: (...a) => hud.ui.big(...a),
    get notifyRaw() { return hud.ui.notify; },
    prompt: (...a) => hud.ui.prompt(...a),
    openShop: (...a) => hud.ui.openShop(...a),
    refreshShop: (...a) => hud.ui.refreshShop(...a),
    closeShop: (...a) => hud.ui.closeShop(...a),
    shopMessage: (...a) => hud.ui.shopMessage(...a),
    openGarage: (...a) => hud.ui.openGarage(...a),
    refreshGarage: (...a) => hud.ui.refreshGarage(...a),
    closeGarage: (...a) => hud.ui.closeGarage(...a),
    garageMessage: (...a) => hud.ui.garageMessage(...a),
  };

  let respawning = false;
  let police = null;
  const traffic = createTraffic(scene, { state, player, npcs, getPolice: () => police });
  police = createPolice(scene, { state, player, npcs, onBusted: busted });
  const combat = createCombat(scene, { state, player, npcs, police, camera, dom: renderer.domElement, traffic });
  const economy = createEconomy(scene, { state, player, npcs, ui: uiProxy });
  const missions = createMissions(scene, { state, player, combat, traffic });
  const daynight = createDayNight(scene, { state, sun, hemi, roads });
  const weather = createWeather(scene, { state, camera, sun, hemi });
  const audio = createAudio({ state, player, getPolice: () => police, traffic, weather });
  const garage = createGarage(scene, { state, player, police, ui: uiProxy });
  const fx = createFX(scene, { state, player, npcs, getPolice: () => police, traffic });
  const camfx = createCamFX({ camera, player, state, settings });
  const skids = createSkids(scene, { player });
  const stunts = createStunts(scene, { state, player, ui: uiProxy });
  const events = createEvents(scene, { state, player, npcs, traffic, combat, economy, missions });
  const menu = createMenu({
    state, player, settings, audio, maps, missions,
    isBlocked: () => maps.fullMapOpen || !!economy.openShop || garage.open || respawning,
  });
  // Player car headlights (one shared spot light, night only).
  const headlight = new THREE.SpotLight(0xfff1c8, 0, 38, 0.55, 0.6, 1.2);
  scene.add(headlight);
  scene.add(headlight.target);
  hud = createHUD({ state, player, police, missions, combat, camera, weather, audio, where: () => whereAmI() });

  // ---- where am I: district + nearest street (HUD under the minimap)
  function whereAmI() {
    const p = player.position;
    let best = null;
    let bd = Infinity;
    for (const r of LAYOUT.roads) {
      const pts = r.points;
      for (let i = 0; i < pts.length - 1; i++) {
        const [ax, az] = pts[i];
        const [bx, bz] = pts[i + 1];
        const dx = bx - ax;
        const dz = bz - az;
        const l2 = dx * dx + dz * dz || 1;
        const t = Math.max(0, Math.min(1, ((p.x - ax) * dx + (p.z - az) * dz) / l2));
        const d = Math.hypot(p.x - ax - t * dx, p.z - az - t * dz);
        if (d < bd) { bd = d; best = r; }
      }
    }
    return { district: zoneAt(p.x, p.z), street: best && bd < 40 ? best.name : '' };
  }

  // ---- stealing cars (E next to any car)
  function tryEnterCar() {
    if (player.driving || player.riding || player.frozen) return false;
    const pp = player.position;
    let best = null;
    let bd = Infinity;
    for (const c of traffic.cars) {
      if (c.wrecked || c.burning !== undefined) continue;
      const d = Math.hypot(c.x - pp.x, c.z - pp.z) - Math.max(c.W, c.L * 0.5) / 2;
      if (d < 2.2 && d < bd) { bd = d; best = c; }
    }
    if (!best) return false;
    const occupied = !best.parked;
    // Carjack: pull the driver out (a far-away walker is borrowed and
    // dropped by the driver's door, running for it).
    if (occupied) {
      const pool = npcs.people.filter((n) => n.kind === 'walker' && npcs.alive(n)
        && Math.hypot(n.mesh.position.x - pp.x, n.mesh.position.z - pp.z) > 60);
      const w = pool[Math.floor(Math.random() * pool.length)];
      if (w) {
        const lx = -Math.cos(best.heading);
        const lz = Math.sin(best.heading);
        w.x = best.x + lx * (best.W / 2 + 0.8);
        w.z = best.z + lz * (best.W / 2 + 0.8);
        w.mesh.position.set(w.x, w.mesh.position.y, w.z);
        npcs.scare(w, pp.x, pp.z, 8);
      }
    }
    // Witnesses: civilians with line of sight within 30 m, any cop in 45 m.
    const witness = npcs.people.some((n) => npcs.alive(n)
      && Math.hypot(n.mesh.position.x - best.x, n.mesh.position.z - best.z) < 30
      && lineOfSight(n.mesh.position.x, n.mesh.position.z, best.x, best.z))
      || police.cops.some((c) => c.state !== 'down' && Math.hypot(c.x - best.x, c.z - best.z) < 45);
    player.enterCar(best);
    state.emit('carStolen', { name: best.name, jacked: occupied, witness });
    if (occupied || witness) {
      if (witness) state.crime(1, 'car-theft');
    }
    state.addXP(occupied ? 6 : 3, 'car');
    return true;
  }

  // ---- vehicle damage
  player.onCrash = (imp) => {
    state.emit('crash', { speed: imp });
    if (player.driving) traffic.damageCar(player.car, imp * 1.3);
    else if (player.riding && imp > 10) state.emit('playerShot', { damage: Math.round(imp * 0.7) });
  };
  let fireWarned = null;

  // E: shop doors take priority over the bike.
  player.interactHook = () => economy.interact() || garage.interact() || tryEnterCar();

  // ---- respawn flows
  function respawnSequence(head, sub, color, place, after) {
    respawning = true;
    player.frozen = true;
    player.dismount();
    hud.ui.big(head, sub, color, 3.2);
    renderer.domElement.style.transition = 'filter 0.6s';
    renderer.domElement.style.filter = head === 'WASTED' ? 'grayscale(1) brightness(0.8)' : 'saturate(0.4)';
    setTimeout(() => {
      police.despawnAll();
      state.clearWanted();
      after();
      player.teleport(place.respawn[0], place.respawn[1], place.face);
      renderer.domElement.style.filter = '';
      player.frozen = false;
      respawning = false;
    }, 3200);
  }
  function busted(stars, fine) {
    if (respawning) return;
    const paid = Math.min(state.money, fine);
    state.addMoney(-paid);
    missions.fail('Busted');
    state.emit('busted');
    respawnSequence('BUSTED', `Fine: $${paid}  (${stars} star${stars === 1 ? '' : 's'} x $50)`, '#5ab0ff',
      POLICE_STATION, () => {});
  }
  function wasted() {
    if (respawning) return;
    const paid = Math.min(state.money, WASTED_FINE);
    state.addMoney(-paid);
    missions.fail('Wasted');
    state.emit('wasted');
    respawnSequence('WASTED', `Hospital bill: $${paid}`, '#ff4b4b', HOSPITAL, () => {
      state.hp = 100;
      state.armor = 0;
    });
  }

  // Revision 3 career stats.
  state.on((type, d) => {
    const st = state.stats;
    if (type === 'money' && d > 0) st.cashEarned += d;
    if (type === 'carStolen') st.carsStolen += 1;
    if (type === 'shot') st.shotsFired += 1;
    if (type === 'explosion') st.explosions += 1;
    if (type === 'wasted') st.deaths += 1;
    if (type === 'busted') st.busts += 1;
    if (type === 'wanted') st.maxWanted = Math.max(st.maxWanted, state.wanted);
  });
  const origDamageCop = police.damageCop;
  police.damageCop = (...a) => {
    const r = origDamageCop(...a);
    if (r === 'dead') state.stats.copsDown += 1;
    return r;
  };

  state.on((type, d) => {
    if (type === 'policeHitCar' && player.driving) traffic.damageCar(player.car, d.damage);
    if (type === 'takedown') state.addXP(12, 'takedown');
    if (type === 'playerShot' && !respawning) {
      if (state.hurt(d.damage)) wasted();
    }
    if (type === 'wanted' && d.why !== 'decay' && d.why !== 'clear' && state.wanted > d.before) {
      hud.ui.notify(`Wanted level ${state.wanted}`, 'crime', 2);
    }
    if (type === 'mission') {
      if (d.type === 'start') hud.ui.big(d.title, d.intro, '#ffd21a', 3.5);
      if (d.type === 'pass') hud.ui.big('MISSION PASSED', `+$${d.reward}`, '#ffd21a', 4);
      if (d.type === 'fail') hud.ui.big('MISSION FAILED', d.reason, '#ff4b4b', 3);
    }
  });
  // Shot civilians drop a little cash.
  const origDamage = npcs.damage;
  npcs.damage = (n, amount, fx, fz, kind) => {
    const r = origDamage(n, amount, fx, fz, kind);
    if (r === 'dead' && n.kind === 'walker') economy.dropCash(n.mesh.position.x, n.mesh.position.z);
    return r;
  };

  // ---- save / load
  let newGameArm = 0;
  window.addEventListener('keydown', (e) => {
    if (e.repeat) return;
    if (e.key.toLowerCase() === 'k' && !player.frozen) state.save(player);
    if (e.key === 'N' && e.shiftKey) {
      if (performance.now() - newGameArm < 3000) {
        state.deleteSave();
        location.reload();
      } else {
        newGameArm = performance.now();
        hud.ui.notify('Press Shift+N again to start a new game (deletes the save)', 'warn', 3);
      }
    }
  });
  const saved = state.readSave();
  if (saved) {
    state.load(saved);
    if (saved.pos) player.teleport(saved.pos.x, saved.pos.z, player.facing);
    hud.ui.notify(`Save loaded · Day ${state.day}, $${state.money}`, 'info', 4);
  } else {
    hud.ui.notify('Welcome to Cayo Verde. Follow the yellow marker for your first job.', 'info', 6);
    hud.ui.notify('Free pistol crate in Downtown, west of the roundabout.', 'info', 6);
  }

  // ---- GPS route along the road graph (recomputed twice a second)
  const NODE_BY = new Map(NODES.map((n) => [n.id, n]));
  const ADJ = new Map(NODES.map((n) => [n.id, []]));
  for (const e of EDGES) {
    if (ADJ.has(e.from) && ADJ.has(e.to)) { ADJ.get(e.from).push(e.to); ADJ.get(e.to).push(e.from); }
  }
  const nearestNode = (x, z) => {
    let b = null; let bd = Infinity;
    for (const n of NODES) { const d = Math.hypot(n.x - x, n.z - z); if (d < bd) { bd = d; b = n; } }
    return b;
  };
  function dijkstra(a, b) {
    const dist = new Map([[a, 0]]);
    const prev = new Map();
    const open = new Set([a]);
    while (open.size) {
      let u = null; let ud = Infinity;
      for (const id of open) if (dist.get(id) < ud) { ud = dist.get(id); u = id; }
      open.delete(u);
      if (u === b) break;
      const U = NODE_BY.get(u);
      for (const v of ADJ.get(u)) {
        const V = NODE_BY.get(v);
        const nd = ud + Math.hypot(U.x - V.x, U.z - V.z);
        if (nd < (dist.has(v) ? dist.get(v) : Infinity)) { dist.set(v, nd); prev.set(v, u); open.add(v); }
      }
    }
    const path = [];
    for (let id = b; id !== undefined; id = prev.get(id)) { path.unshift(id); if (id === a) break; }
    return path[0] === a ? path : [a, b];
  }
  let route = [];
  let routeT = 0;
  function updateRoute(dt) {
    routeT -= dt;
    if (routeT > 0) return;
    routeT = 0.5;
    const tr = missions.tracker();
    if (!tr.target) { route = []; return; }
    const pp = player.position;
    const [tx, tz] = tr.target;
    if (Math.hypot(tx - pp.x, tz - pp.z) < 25) { route = [[pp.x, pp.z], [tx, tz]]; return; }
    const ids = dijkstra(nearestNode(pp.x, pp.z).id, nearestNode(tx, tz).id);
    route = [[pp.x, pp.z], ...ids.map((id) => [NODE_BY.get(id).x, NODE_BY.get(id).z]), [tx, tz]];
  }

  // ---- map blips (minimap rotates: letters stay upright via p.rot)
  maps.setExtraMarkers((ctx, p, big) => {
    const S = big ? 1.5 : 1;
    const rot = p.rot || 0;
    // Clamp far targets to the minimap rim (in world space).
    const clampW = (wx, wz) => {
      if (big || !p.center) return [wx, wz];
      const dx = wx - p.center.x;
      const dz = wz - p.center.z;
      const d = Math.hypot(dx, dz);
      return d > p.worldR ? [p.center.x + (dx / d) * p.worldR, p.center.z + (dz / d) * p.worldR] : [wx, wz];
    };
    const blip = (wx, wz, color, letter, clamp) => {
      if (clamp) [wx, wz] = clampW(wx, wz);
      const x = p.x(wx);
      const y = p.y(wz);
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(-rot);
      ctx.beginPath();
      ctx.arc(0, 0, 7 * S, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = '#141220';
      ctx.stroke();
      if (letter) {
        ctx.fillStyle = '#fff';
        ctx.font = `bold ${Math.round(9 * S)}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(letter, 0, 0.5);
      }
      ctx.restore();
    };
    // Police search zone.
    if (state.wanted > 0) {
      const ls = police.inSight ? player.position : police.lastSeen;
      ctx.beginPath();
      ctx.arc(p.x(ls.x), p.y(ls.z), police.searchRadius * p.scale, 0, Math.PI * 2);
      ctx.fillStyle = police.inSight ? 'rgba(255,40,60,0.16)' : 'rgba(80,110,255,0.14)';
      ctx.fill();
      ctx.setLineDash([6, 5]);
      ctx.strokeStyle = police.inSight ? 'rgba(255,60,70,0.9)' : 'rgba(120,150,255,0.9)';
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.setLineDash([]);
    }
    // GPS route.
    if (route.length > 1) {
      ctx.beginPath();
      route.forEach(([x, z], i) => (i ? ctx.lineTo(p.x(x), p.y(z)) : ctx.moveTo(p.x(x), p.y(z))));
      ctx.strokeStyle = 'rgba(20,18,32,0.7)';
      ctx.lineWidth = 6 * S;
      ctx.stroke();
      ctx.strokeStyle = '#ffc12e';
      ctx.lineWidth = 3.5 * S;
      ctx.stroke();
    }
    for (const s of SHOPS) blip(s.door[0], s.door[1], s.color, s.id === 'ammu' ? 'A' : '$', false);
    blip(HOSPITAL.respawn[0], HOSPITAL.respawn[1], '#e02424', 'H', false);
    blip(POLICE_STATION.respawn[0], POLICE_STATION.respawn[1], '#1b3a8a', 'P', false);
    blip(garage.pos[0], garage.pos[1], '#4be3a0', 'R', false);
    if (combat.crateStocked) blip(combat.cratePos[0], combat.cratePos[1], '#3a86ff', 'G', false);
    // Traffic: small grey squares.
    ctx.fillStyle = 'rgba(235,235,235,0.85)';
    for (const c of traffic.cars) ctx.fillRect(p.x(c.x) - 2 * S, p.y(c.z) - 2 * S, 4 * S, 4 * S);
    // Police: flashing red/blue.
    const on = Math.floor(performance.now() / 250) % 2 === 0;
    for (const c of police.cops) {
      if (c.state === 'down') continue;
      ctx.beginPath();
      ctx.arc(p.x(c.x), p.y(c.z), 3.4 * S, 0, Math.PI * 2);
      ctx.fillStyle = on ? '#ff3030' : '#3060ff';
      ctx.fill();
    }
    for (const c of police.cars) {
      if (c.wrecked) continue;
      ctx.fillStyle = on ? '#3060ff' : '#ff3030';
      ctx.fillRect(p.x(c.x) - 4 * S, p.y(c.z) - 4 * S, 8 * S, 8 * S);
    }
    if (police.heli) {
      ctx.beginPath();
      ctx.arc(p.x(police.heli.x), p.y(police.heli.z), 6 * S, 0, Math.PI * 2);
      ctx.strokeStyle = on ? '#ff3030' : '#3060ff';
      ctx.lineWidth = 2.5;
      ctx.stroke();
    }
    // Street crime target + unfound stunt ramps.
    const et = events.target();
    if (et) blip(et[0], et[1], '#ff3b4e', '!', true);
    for (const r of stunts.ramps) if (!state.stunts.includes(r.id)) blip(r.x, r.z, '#ff7ad9', 'S', false);
    // Mission target.
    const tr = missions.tracker();
    if (tr.target) blip(tr.target[0], tr.target[1], '#ffc12e', tr.idle ? 'M' : '!', true);
  });

  // ---- update
  function update(dt) {
    state.time += dt;
    daynight.update(dt, player.position);
    weather.update(dt);
    daynight.syncSky(camera, weather.cloud);
    traffic.update(dt);
    updateRoute(dt);
    garage.update(dt);
    fx.update(dt);
    const pc = player.car;
    if (pc && pc.burning !== undefined && fireWarned !== pc) {
      fireWarned = pc;
      hud.ui.notify('Your car is on fire — get out (E)!', 'crime', 4);
    }
    police.update(dt);
    combat.update(dt);
    economy.update(dt);
    missions.update(dt);
    stunts.update(dt);
    skids.update(dt);
    events.update(dt);
    hud.update(dt);
    audio.update(dt);
    camfx.update(dt);
    state.stats.playTime += dt;
    if (player.inVehicle) state.stats.distance += Math.abs(player.speed) * dt;
    // Headlights after dark.
    const pcar = player.car;
    if (pcar && daynight.night > 0.25) {
      const hx = Math.sin(pcar.heading);
      const hz = Math.cos(pcar.heading);
      headlight.position.set(pcar.x + hx * (pcar.L / 2), pcar.group.position.y + 0.9, pcar.z + hz * (pcar.L / 2));
      headlight.target.position.set(pcar.x + hx * 16, pcar.group.position.y, pcar.z + hz * 16);
      headlight.intensity = daynight.night * 120;
    } else headlight.intensity = 0;
  }

  // Debug / verification handle.
  return {
    state, police, combat, economy, missions, daynight, weather, traffic, audio, hud, garage, fx,
    camfx, stunts, events, menu, settings, update, busted, wasted, tryEnterCar, whereAmI,
    get paused() { return menu.open; },
    get timeScale() { return stunts.timeScale; },
  };
}
