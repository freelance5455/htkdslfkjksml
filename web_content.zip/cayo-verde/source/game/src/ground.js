// ground.js — renders the terrain FROM layout.js data.
// Every coordinate comes from LAYOUT (coastline, beach, lake, districts).
// Nothing here hard-codes a position that layout.js owns.
//
// Layer stack (y heights keep the flat layers from z-fighting):
//   water 0.00 -> island 0.20 -> sand ring 0.35 -> sand districts 0.40
//   -> park lawn 0.50 -> lake 0.65
// Flat colours only, no external textures. The water gradient is a small
// canvas texture made at runtime (bright blue near shore -> deep blue far out).

import * as THREE from 'three';
import { LAYOUT, beachInnerPolygon } from './layout.js';

// Convert a layout polygon ([x, z] points) into a THREE.Shape.
// ShapeGeometry lies in the XY plane; after rotateX(-PI/2) a shape point
// (x, y) lands at world (x, 0, -y), so we feed (x, -z) to land on (x, z).
function polygonToShape(polygon) {
  const shape = new THREE.Shape();
  polygon.forEach(([x, z], i) => {
    if (i === 0) shape.moveTo(x, -z);
    else shape.lineTo(x, -z);
  });
  shape.closePath();
  return shape;
}

function polygonToPath(polygon) {
  const path = new THREE.Path();
  polygon.forEach(([x, z], i) => {
    if (i === 0) path.moveTo(x, -z);
    else path.lineTo(x, -z);
  });
  path.closePath();
  return path;
}

function flatMesh(shape, color, y, opts = {}) {
  const geo = new THREE.ShapeGeometry(shape);
  geo.rotateX(-Math.PI / 2);
  const mat = new THREE.MeshStandardMaterial({
    color,
    roughness: opts.roughness ?? 0.9,
    metalness: 0,
    side: THREE.DoubleSide,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = y;
  mesh.receiveShadow = opts.receiveShadow ?? true;
  return mesh;
}

// Radial-gradient water texture: bright blue near the shore (the island edge
// sits at ~0.55 of the half-width) grading to deep blue at the horizon.
function makeWaterTexture() {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  const g = ctx.createRadialGradient(
    size / 2, size / 2, 0,
    size / 2, size / 2, size / 2,
  );
  g.addColorStop(0.0, LAYOUT.palette.waterShallow);
  g.addColorStop(0.58, LAYOUT.palette.waterShallow);
  g.addColorStop(0.78, '#1b6fc4'); // (roadfix) mid blue — was teal
  g.addColorStop(1.0, LAYOUT.palette.waterDeep);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function buildGround(scene) {
  const group = new THREE.Group();
  group.name = 'ground';
  const P = LAYOUT.palette;

  // Sea — one large plane with the gradient texture, under everything.
  const waterGeo = new THREE.PlaneGeometry(LAYOUT.ground.size, LAYOUT.ground.size);
  waterGeo.rotateX(-Math.PI / 2);
  const water = new THREE.Mesh(
    waterGeo,
    new THREE.MeshStandardMaterial({
      map: makeWaterTexture(),
      roughness: 0.45,
      metalness: 0,
    }),
  );
  water.position.y = 0;
  water.receiveShadow = true;
  water.name = 'sea';
  group.add(water);

  // Island landmass — the coastline polygon, grass green.
  const island = flatMesh(polygonToShape(LAYOUT.coastline), P.grass, 0.2);
  island.name = 'island';
  group.add(island);

  // Sand ring — coastline outline with the inner polygon cut out as a hole.
  const ringShape = polygonToShape(LAYOUT.coastline);
  ringShape.holes.push(polygonToPath(beachInnerPolygon()));
  const sandRing = flatMesh(ringShape, P.sand, 0.35);
  sandRing.name = 'sand-ring';
  group.add(sandRing);

  // Sand districts (Vice Beach, South Shore) — full sand, so the east and
  // south beaches read widest, as on the reference map.
  for (const id of LAYOUT.beach.sandDistricts) {
    const d = LAYOUT.districts.find((x) => x.id === id);
    if (!d) continue;
    const sand = flatMesh(polygonToShape(d.polygon), P.sand, 0.4);
    sand.name = `sand-${id}`;
    group.add(sand);
  }

  // Central Park lawn — brighter green than the base grass.
  const park = LAYOUT.districts.find((d) => d.id === 'central-park');
  if (park) {
    const lawn = flatMesh(polygonToShape(park.polygon), P.parkLawn, 0.5);
    lawn.name = 'park-lawn';
    group.add(lawn);
  }

  // Central Park lake — kidney shape, blue, slight sheen.
  const lake = flatMesh(
    polygonToShape(LAYOUT.lake),
    P.lake,
    0.65,
    { roughness: 0.3 },
  );
  lake.name = 'park-lake';
  group.add(lake);

  scene.add(group);
  return group;
}
