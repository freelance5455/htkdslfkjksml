// maps.js — F6: minimap (HUD) + full city map (M key).
// ONE shared draw function renders both from layout.js — the same data the
// 3D world is built from — so the map and the world can never disagree.
// North-up on both; the player arrow rotates with the player heading.

import {
  LAYOUT, BLOCKS, PIER, FERRIS_WHEEL, beachInnerPolygon, districtById,
} from './layout.js';
import { BUILDINGS } from './buildings.js';

// Map bounds, derived from the coastline (never hardcoded): the whole
// island plus a sea margin, so the framing matches the reference map.
const BOUNDS = (() => {
  let minX = Infinity; let maxX = -Infinity;
  let minZ = Infinity; let maxZ = -Infinity;
  for (const [x, z] of LAYOUT.coastline) {
    if (x < minX) minX = x;
    if (x > maxX) maxX = x;
    if (z < minZ) minZ = z;
    if (z > maxZ) maxZ = z;
  }
  const m = 24;
  return { minX: minX - m, maxX: maxX + m, minZ: minZ - m, maxZ: maxZ + m };
})();

const PAL = LAYOUT.palette;

// World -> canvas projection for a square canvas of `size` px.
// North (-z) is up; the view is centred with equal x/z scale.
// `bounds` defaults to the whole island (full map); the minimap passes a
// small box around the player instead (roadfix: zoomed local view).
function projector(size, bounds) {
  const b = bounds || BOUNDS;
  const w = b.maxX - b.minX;
  const h = b.maxZ - b.minZ;
  const scale = size / Math.max(w, h);
  const ox = (size - w * scale) / 2;
  const oy = (size - h * scale) / 2;
  return {
    scale,
    x: (wx) => ox + (wx - b.minX) * scale,
    y: (wz) => oy + (wz - b.minZ) * scale,
  };
}

function tracePoly(ctx, p, poly) {
  ctx.beginPath();
  poly.forEach(([x, z], i) => {
    if (i === 0) ctx.moveTo(p.x(x), p.y(z));
    else ctx.lineTo(p.x(x), p.y(z));
  });
  ctx.closePath();
}

// Shared draw: every layer reads layout.js. `opts.labels` adds district +
// place text (full map only); `opts.detail` scales line widths and dots.
function drawMap(ctx, size, opts) {
  const p = projector(size, opts.bounds);
  const s = p.scale;
  const labels = !!opts.labels;

  // Sea.
  ctx.fillStyle = PAL.waterDeep;
  ctx.fillRect(0, 0, size, size);

  // Island: sand ring (coastline filled sand, inner polygon grass on top).
  tracePoly(ctx, p, LAYOUT.coastline);
  ctx.fillStyle = PAL.sand;
  ctx.fill();
  tracePoly(ctx, p, beachInnerPolygon());
  ctx.fillStyle = PAL.grass;
  ctx.fill();

  // District tints (full map only) + sand districts + park lawn.
  for (const d of LAYOUT.districts) {
    tracePoly(ctx, p, d.polygon);
    if (d.id === 'central-park') {
      ctx.fillStyle = PAL.parkLawn;
      ctx.fill();
    } else if (LAYOUT.beach.sandDistricts.includes(d.id)) {
      ctx.fillStyle = PAL.sand;
      ctx.fill();
    } else if (labels) {
      ctx.globalAlpha = 0.28;
      ctx.fillStyle = d.color;
      ctx.fill();
      ctx.globalAlpha = 1;
    }
  }

  // Park lake.
  tracePoly(ctx, p, LAYOUT.lake);
  ctx.fillStyle = PAL.lake;
  ctx.fill();

  // Roads: polylines, width from the road's own width, charcoal asphalt.
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  for (const r of LAYOUT.roads) {
    ctx.beginPath();
    r.points.forEach(([x, z], i) => {
      if (i === 0) ctx.moveTo(p.x(x), p.y(z));
      else ctx.lineTo(p.x(x), p.y(z));
    });
    if (r.closed) ctx.closePath();
    ctx.strokeStyle = PAL.asphalt;
    ctx.lineWidth = Math.max(1, r.width * s);
    ctx.stroke();
  }

  // Roundabout: asphalt ring around the island circle.
  const [rx, rz] = LAYOUT.roundabout.pos;
  ctx.beginPath();
  ctx.arc(p.x(rx), p.y(rz), (LAYOUT.roundabout.radius + 4) * s, 0, Math.PI * 2);
  ctx.strokeStyle = PAL.asphalt;
  ctx.lineWidth = Math.max(1.5, 8 * s);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(p.x(rx), p.y(rz), LAYOUT.roundabout.radius * s, 0, Math.PI * 2);
  ctx.fillStyle = PAL.grass;
  ctx.fill();

  // Parcels: the new BLOCKS are land parcels {x0,z0,x1,z1} — fill each
  // with its district colour at low alpha so the block structure reads
  // on both maps (on the minimap the district tints are off, so this is
  // the only block shading). Park parcels read as lawn.
  for (const b of BLOCKS) {
    const d = districtById(b.district);
    ctx.fillStyle = b.park ? PAL.parkLawn : (d ? d.color : '#888888');
    ctx.globalAlpha = 0.15;
    ctx.fillRect(p.x(b.x0), p.y(b.z0), (b.x1 - b.x0) * s, (b.z1 - b.z0) * s);
    ctx.globalAlpha = 1;
  }

  // Buildings: BUILDINGS footprints in their own colours (full map) or
  // one dark pastel (minimap, where tiny colours turn to noise).
  for (const b of BUILDINGS) {
    const w = (b.rot === 90 ? b.d : b.w) * s;
    const d = (b.rot === 90 ? b.w : b.d) * s;
    ctx.fillStyle = labels ? b.color : '#4a4a55';
    ctx.fillRect(p.x(b.x) - w / 2, p.y(b.z) - d / 2, w, d);
  }

  // Pier: a line out to sea; ferris wheel: a ring + hub dot.
  ctx.beginPath();
  ctx.moveTo(p.x(PIER.x0), p.y(PIER.z));
  ctx.lineTo(p.x(PIER.x1), p.y(PIER.z));
  ctx.strokeStyle = '#8a6f4d';
  ctx.lineWidth = Math.max(1.5, PIER.width * s);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(p.x(FERRIS_WHEEL.x), p.y(FERRIS_WHEEL.z), FERRIS_WHEEL.radius * s, 0, Math.PI * 2);
  ctx.strokeStyle = '#e05252';
  ctx.lineWidth = Math.max(1, 1.2 * s);
  ctx.stroke();

  // Labels (full map only): district names + named places.
  if (labels) {
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (const d of LAYOUT.districts) {
      const [lx, lz] = d.label;
      ctx.font = `bold ${Math.max(9, size * 0.016)}px Arial, sans-serif`;
      ctx.lineWidth = 3;
      ctx.strokeStyle = 'rgba(255,255,255,0.85)';
      ctx.strokeText(d.name.toUpperCase(), p.x(lx), p.y(lz));
      ctx.fillStyle = '#22222a';
      ctx.fillText(d.name.toUpperCase(), p.x(lx), p.y(lz));
    }
    for (const pl of LAYOUT.places) {
      const [px, pz] = pl.pos;
      ctx.beginPath();
      ctx.arc(p.x(px), p.y(pz), Math.max(2, size * 0.004), 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      ctx.font = `${Math.max(8, size * 0.013)}px Arial, sans-serif`;
      ctx.lineWidth = 3;
      ctx.strokeStyle = 'rgba(255,255,255,0.85)';
      // Place text sits below its dot. Offset 0.036 (F7 fix): places that
      // sit just north of their district label (Port Docks, Airport
      // Terminal) used to overlap it at 0.022 — the north offset ate the
      // gap. 0.036 clears every district label without pushing any place
      // text into the label below it.
      ctx.strokeText(pl.name, p.x(px), p.y(pz) + size * 0.036);
      ctx.fillStyle = '#33333d';
      ctx.fillText(pl.name, p.x(px), p.y(pz) + size * 0.036);
    }
  }
  return p;
}

// ------------------------------------------------------------------ markers
// Player arrow: a triangle pointing along the heading. Facing convention
// (player.js): velocity = (sin(f), cos(f)), f = PI faces north (-z). On the
// canvas north is up, so the rotation is PI - f (f = PI -> 0 -> arrow up).
function drawPlayerArrow(ctx, p, size, px, pz, facing, arrowSize) {
  ctx.save();
  ctx.translate(p.x(px), p.y(pz));
  ctx.rotate(Math.PI - facing);
  ctx.beginPath();
  ctx.moveTo(0, -arrowSize);
  ctx.lineTo(arrowSize * 0.7, arrowSize * 0.8);
  ctx.lineTo(-arrowSize * 0.7, arrowSize * 0.8);
  ctx.closePath();
  ctx.fillStyle = '#ffffff';
  ctx.fill();
  ctx.strokeStyle = '#2ec4b6';
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();
}

// ------------------------------------------------------------------- create
export function createMaps({ player, npcs, bike }) {
  const extra = { draw: null };
  const MINI_SIZE = 180;

  // Minimap canvas: bottom-left HUD corner, above the help line, circular.
  const mini = document.createElement('canvas');
  mini.width = MINI_SIZE;
  mini.height = MINI_SIZE;
  mini.id = 'minimap';
  Object.assign(mini.style, {
    position: 'fixed', left: '35px', bottom: '118px', zIndex: 20,
    width: `${MINI_SIZE}px`, height: `${MINI_SIZE}px`,
    borderRadius: '50%', border: '3px solid rgba(20,18,30,0.9)',
    boxShadow: '0 2px 12px rgba(0,0,0,0.5)', pointerEvents: 'none',
  });
  document.body.appendChild(mini);
  const miniCtx = mini.getContext('2d');

  // Full-map overlay: dark backdrop + large centred canvas, hidden by default.
  const overlay = document.createElement('div');
  overlay.id = 'fullmap-overlay';
  Object.assign(overlay.style, {
    position: 'fixed', inset: '0', zIndex: 30, display: 'none',
    background: 'rgba(10,10,18,0.72)',
    alignItems: 'center', justifyContent: 'center',
  });
  const full = document.createElement('canvas');
  full.id = 'fullmap';
  Object.assign(full.style, {
    borderRadius: '10px', border: '2px solid rgba(255,255,255,0.6)',
    boxShadow: '0 8px 40px rgba(0,0,0,0.7)', maxWidth: '86vmin', maxHeight: '86vmin',
  });
  const hint = document.createElement('div');
  hint.textContent = 'M / ESC — close map';
  Object.assign(hint.style, {
    position: 'absolute', bottom: '4vmin', left: '0', right: '0',
    textAlign: 'center', fontFamily: 'Arial, sans-serif', fontSize: '13px',
    color: 'rgba(255,255,255,0.8)', textShadow: '0 1px 4px rgba(0,0,0,0.8)',
    pointerEvents: 'none',
  });
  overlay.appendChild(full);
  overlay.appendChild(hint);
  document.body.appendChild(overlay);
  const fullCtx = full.getContext('2d');

  let fullOpen = false;
  let lastMarker = { x: 0, y: 0, heading: Math.PI };

  function sizeFullCanvas() {
    const side = Math.floor(Math.min(window.innerWidth, window.innerHeight) * 0.86);
    full.width = side;
    full.height = side;
    full.style.width = `${side}px`;
    full.style.height = `${side}px`;
  }

  function drawMarkers(ctx, p, size, big) {
    // NPC walkers as tiny dots (cheap: one arc each).
    if (npcs) {
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      for (const n of npcs) {
        if (n.kind !== 'walker') continue;
        const mp = n.mesh ? n.mesh.position : null;
        if (!mp) continue;
        ctx.beginPath();
        ctx.arc(p.x(mp.x), p.y(mp.z), big ? 2.5 : 1.5, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    // Parked bike as a blue dot (hidden while ridden — it is the player).
    if (bike && !player.riding && bike.position) {
      ctx.beginPath();
      ctx.arc(p.x(bike.position.x), p.y(bike.position.z), big ? 4 : 3, 0, Math.PI * 2);
      ctx.fillStyle = '#3a86ff';
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    // G2-G5 blips (police, shops, mission target, ...) from game.js.
    if (extra.draw) extra.draw(ctx, p, big);
    // Player arrow.
    const pp = player.position;
    const facing = player.group ? player.group.rotation.y : Math.PI;
    drawPlayerArrow(ctx, p, size, pp.x, pp.z, facing, big ? 12 : 8);
    lastMarker = { x: p.x(pp.x), y: p.y(pp.z), heading: facing };
  }

  // Minimap: a LOCAL view centred on the player (~140 m box, ~3-4x zoom
  // vs the old whole-island view), so the streets around the player are
  // readable. The player arrow sits in the centre; the map scrolls as
  // the player moves. The full map (M key) keeps the whole-island view.
  // Revision 2: the minimap rotates with the camera (forward = up, like
  // GTA). A square rotated about its centre always covers its inscribed
  // circle, so the round minimap never shows empty corners. Blip letters
  // are drawn upright via p.rot; an N badge rides the rim.
  function drawMini() {
    const pp = player.position;
    const half = 70;
    const local = {
      minX: pp.x - half, maxX: pp.x + half,
      minZ: pp.z - half, maxZ: pp.z + half,
    };
    const rot = player.yaw || 0;
    const c = MINI_SIZE / 2;
    miniCtx.save();
    miniCtx.translate(c, c);
    miniCtx.rotate(rot);
    miniCtx.translate(-c, -c);
    const p = drawMap(miniCtx, MINI_SIZE, { labels: false, bounds: local });
    p.rot = rot;
    p.worldR = half * 0.9;
    p.center = pp;
    drawMarkers(miniCtx, p, MINI_SIZE, false);
    miniCtx.restore();
    // North badge.
    const nx = c + Math.sin(rot) * (c - 11);
    const ny = c - Math.cos(rot) * (c - 11);
    miniCtx.beginPath();
    miniCtx.arc(nx, ny, 9, 0, Math.PI * 2);
    miniCtx.fillStyle = '#141220';
    miniCtx.fill();
    miniCtx.strokeStyle = '#fff';
    miniCtx.lineWidth = 1.5;
    miniCtx.stroke();
    miniCtx.fillStyle = '#fff';
    miniCtx.font = 'bold 11px Arial';
    miniCtx.textAlign = 'center';
    miniCtx.textBaseline = 'middle';
    miniCtx.fillText('N', nx, ny + 0.5);
  }

  function drawFull() {
    if (full.width === 0) sizeFullCanvas();
    const p = drawMap(fullCtx, full.width, { labels: true });
    p.rot = 0;
    drawMarkers(fullCtx, p, full.width, true);
  }

  function toggleFullMap(force) {
    fullOpen = force !== undefined ? force : !fullOpen;
    if (fullOpen) {
      sizeFullCanvas();
      overlay.style.display = 'flex';
      drawFull();
    } else {
      overlay.style.display = 'none';
    }
  }

  // M toggles the full map; ESC closes it; clicking the backdrop closes it.
  // (No clash with the O-key camera toggle or WASD movement.)
  window.addEventListener('keydown', (e) => {
    if (e.code === 'KeyM') toggleFullMap();
    else if (e.code === 'Escape' && fullOpen) toggleFullMap(false);
  });
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) toggleFullMap(false);
  });
  window.addEventListener('resize', () => { if (fullOpen) { sizeFullCanvas(); drawFull(); } });

  drawMini();
  return {
    update() {
      drawMini();
      if (fullOpen) drawFull();
    },
    toggleFullMap,
    setExtraMarkers(fn) { extra.draw = fn; },
    get fullMapOpen() { return fullOpen; },
    get playerMarker() { return { ...lastMarker }; },
    miniCanvas: mini,
    fullCanvas: full,
  };
}
