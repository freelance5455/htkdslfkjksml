// post.js — revision 3 post-processing (no three.js addons needed):
// HDR scene target (half float, MSAA) -> bright pass -> two-level
// separable Gaussian bloom (1/2 and 1/4 res) -> composite with a light
// cinematic grade (contrast, saturation, warm tint, vignette).
// Street lamps, neon, headlights, the sun disc, muzzle flashes and fire
// glow; daylight stays crisp because only values above ~1 bloom.
// Toggle: Settings -> Glow (settings 'bloom'). Off = plain render.

import * as THREE from 'three';

const VS = `varying vec2 vUv; void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`;

export function createPost(renderer, scene, camera, settings) {
  const quadCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  const quadScene = new THREE.Scene();
  const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2));
  quad.frustumCulled = false;
  quadScene.add(quad);

  const mkRT = (w, h, samples = 0) => new THREE.WebGLRenderTarget(w, h, {
    type: THREE.HalfFloatType, samples, depthBuffer: samples > 0,
    minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter,
  });
  let rtScene;
  let a1;
  let b1;
  let a2;
  let b2;
  const size = new THREE.Vector2();
  function alloc() {
    renderer.getDrawingBufferSize(size);
    const w = Math.max(2, size.x);
    const h = Math.max(2, size.y);
    for (const r of [rtScene, a1, b1, a2, b2]) if (r) r.dispose();
    rtScene = mkRT(w, h, 4);
    a1 = mkRT(w >> 1, h >> 1); b1 = mkRT(w >> 1, h >> 1);
    a2 = mkRT(w >> 2, h >> 2); b2 = mkRT(w >> 2, h >> 2);
  }
  alloc();
  window.addEventListener('resize', () => setTimeout(alloc, 0));

  const bright = new THREE.ShaderMaterial({
    uniforms: { tex: { value: null }, threshold: { value: 0.95 }, knee: { value: 0.35 } },
    vertexShader: VS,
    fragmentShader: `uniform sampler2D tex; uniform float threshold; uniform float knee; varying vec2 vUv;
      void main() {
        vec3 c = texture2D(tex, vUv).rgb;
        float l = max(c.r, max(c.g, c.b));
        float soft = clamp(l - threshold + knee, 0.0, 2.0 * knee);
        soft = soft * soft / (4.0 * knee + 1e-4);
        float w = max(soft, l - threshold) / max(l, 1e-4);
        gl_FragColor = vec4(c * w, 1.0);
      }`,
    depthTest: false, depthWrite: false,
  });
  const blur = new THREE.ShaderMaterial({
    uniforms: { tex: { value: null }, dir: { value: new THREE.Vector2() } },
    vertexShader: VS,
    fragmentShader: `uniform sampler2D tex; uniform vec2 dir; varying vec2 vUv;
      void main() {
        vec3 c = texture2D(tex, vUv).rgb * 0.2270270;
        c += texture2D(tex, vUv + dir * 1.3846154).rgb * 0.3162162;
        c += texture2D(tex, vUv - dir * 1.3846154).rgb * 0.3162162;
        c += texture2D(tex, vUv + dir * 3.2307692).rgb * 0.0702703;
        c += texture2D(tex, vUv - dir * 3.2307692).rgb * 0.0702703;
        gl_FragColor = vec4(c, 1.0);
      }`,
    depthTest: false, depthWrite: false,
  });
  const comp = new THREE.ShaderMaterial({
    uniforms: {
      scene: { value: null }, bloom1: { value: null }, bloom2: { value: null },
      strength: { value: 0.75 }, vignette: { value: 0.28 },
    },
    vertexShader: VS,
    fragmentShader: `uniform sampler2D scene; uniform sampler2D bloom1; uniform sampler2D bloom2;
      uniform float strength; uniform float vignette; varying vec2 vUv;
      void main() {
        vec3 c = texture2D(scene, vUv).rgb;
        c += (texture2D(bloom1, vUv).rgb * 0.6 + texture2D(bloom2, vUv).rgb * 0.9) * strength;
        // grade: gentle contrast + saturation, a touch warm
        // (grading in linear space: a contrast pivot at 0.5 crushed dark
        // surfaces like asphalt to black, so use a gentle power curve)
        float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
        c = mix(vec3(l), c, 1.1);
        c = pow(max(c, 0.0), vec3(1.03));
        c *= vec3(1.02, 1.0, 0.98);
        vec2 q = vUv - 0.5;
        c *= 1.0 - dot(q, q) * vignette * 1.6;
        gl_FragColor = vec4(max(c, 0.0), 1.0);
        #include <colorspace_fragment>
      }`,
    depthTest: false, depthWrite: false,
  });

  function pass(mat, target) {
    quad.material = mat;
    renderer.setRenderTarget(target);
    renderer.render(quadScene, quadCam);
  }

  function render() {
    if (!settings.get('bloom')) {
      renderer.setRenderTarget(null);
      renderer.render(scene, camera);
      return;
    }
    renderer.setRenderTarget(rtScene);
    renderer.render(scene, camera);
    bright.uniforms.tex.value = rtScene.texture;
    pass(bright, a1);
    blur.uniforms.tex.value = a1.texture; blur.uniforms.dir.value.set(1 / a1.width, 0); pass(blur, b1);
    blur.uniforms.tex.value = b1.texture; blur.uniforms.dir.value.set(0, 1 / b1.height); pass(blur, a1);
    blur.uniforms.tex.value = a1.texture; blur.uniforms.dir.value.set(1 / a2.width, 0); pass(blur, b2);
    blur.uniforms.tex.value = b2.texture; blur.uniforms.dir.value.set(0, 1 / a2.height); pass(blur, a2);
    comp.uniforms.scene.value = rtScene.texture;
    comp.uniforms.bloom1.value = a1.texture;
    comp.uniforms.bloom2.value = a2.texture;
    pass(comp, null);
  }

  return { render, resize: alloc, setStrength(v) { comp.uniforms.strength.value = v; } };
}
