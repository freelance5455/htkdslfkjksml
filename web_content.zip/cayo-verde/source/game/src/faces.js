// faces.js — canvas-generated face textures for CAYO VERDE characters.
// One clean API for F5a (player) and F5b (NPCs): makeFaceTexture(variant)
// returns a THREE.CanvasTexture with simple, readable eyes + mouth on a
// skin-tone background. Low-poly rule: canvas patterns only, no image files.

import * as THREE from 'three';

const SKINS = ['#f2c29b', '#e8b08a', '#c98d5f', '#8a5a34'];
const MOUTHS = ['smile', 'flat', 'grin'];

function drawEyes(ctx, style, w) {
  ctx.fillStyle = '#1c1c22';
  const y = 52;
  const xs = [38, 90];
  if (style === 'happy') {
    // Closed happy eyes: upward arcs.
    ctx.strokeStyle = '#1c1c22';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    for (const x of xs) {
      ctx.beginPath();
      ctx.arc(x, y + 4, 10, Math.PI * 1.15, Math.PI * 1.85);
      ctx.stroke();
    }
    return;
  }
  // Open eyes: dark rounded rects with a white glint dot.
  for (const x of xs) {
    ctx.fillRect(x - 7, y - 10, 14, 20);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x - 2, y - 6, 4, 4);
    ctx.fillStyle = '#1c1c22';
  }
  // Eyebrows above open eyes.
  ctx.fillRect(28, 30, 20, 5);
  ctx.fillRect(80, 30, 20, 5);
}

function drawMouth(ctx, kind) {
  ctx.strokeStyle = '#5a2a22';
  ctx.fillStyle = '#5a2a22';
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';
  if (kind === 'flat') {
    ctx.beginPath();
    ctx.moveTo(48, 96);
    ctx.lineTo(80, 96);
    ctx.stroke();
  } else if (kind === 'grin') {
    ctx.beginPath();
    ctx.moveTo(44, 90);
    ctx.lineTo(84, 90);
    ctx.lineTo(78, 102);
    ctx.lineTo(50, 102);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(48, 90, 32, 5);
  } else {
    // Smile: downward arc.
    ctx.beginPath();
    ctx.arc(64, 88, 18, Math.PI * 0.15, Math.PI * 0.85);
    ctx.stroke();
  }
}

// variant: 0 = open eyes + smile, 1 = open eyes + flat mouth,
// 2 = happy closed eyes + grin. options.skin overrides the skin tone.
export function makeFaceTexture(variant = 0, options = {}) {
  const v = ((variant % 3) + 3) % 3;
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = options.skin || SKINS[v % SKINS.length];
  ctx.fillRect(0, 0, 128, 128);
  drawEyes(ctx, v === 2 ? 'happy' : 'open', 128);
  drawMouth(ctx, MOUTHS[v]);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export const FACE_VARIANT_COUNT = 3;
