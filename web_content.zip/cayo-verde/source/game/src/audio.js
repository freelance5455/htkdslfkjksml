// audio.js — all sound is synthesised with WebAudio (no audio files).
// SFX: pistol shots (yours + police, distance-scaled), punches, cash,
// purchases, horns, crashes, wrecks, thunder, mission pass / fail jingles,
// BUSTED / WASTED stings.
// Loops: bike engine (pitch follows speed), nearby traffic engine hum,
// police siren wail (louder as patrol cars get closer), rain noise.
// Radio (GTA-style, heard in any vehicle): three generative stations —
//   VICE VERDE FM  synthwave, 104 bpm
//   BAHIA BEATS    dembow / reggaeton, 96 bpm
//   LO-FI LAGUNA   lo-fi hip hop, 76 bpm swung
// plus RADIO OFF. T = next station, V = mute everything.
// Browsers only allow audio after a user gesture: the context starts on
// the first key press or click.

const mtof = (m) => 440 * Math.pow(2, (m - 69) / 12);

// Tiny seeded RNG so a station's melodies vary per bar but repeat per song.
function rng(seed) {
  let s = seed >>> 0;
  return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
}

const STATIONS = [
  {
    name: 'VICE VERDE 104.1', genre: 'Synthwave', bpm: 104, swing: 0,
    songs: [['Neon Undertow', 'Laguna Drive'], ['Palms After Midnight', 'The Coral Static'],
      ['Chrome Sunset', 'Mira Vale'], ['Highway to Isla', 'Night Pelican']],
    // Am F C G
    chords: [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]],
    scale: [57, 60, 62, 64, 67, 69, 72, 74, 76],
  },
  {
    name: 'BAHIA 96.3', genre: 'Dembow / Reggaeton', bpm: 96, swing: 0,
    songs: [["Pa' la Playa", 'DJ Caracol'], ['Malecón Fuego', 'La Brisa'],
      ['Calor de Cayo', 'Tito Marea'], ['Ritmo Verde', 'Sonia Sol']],
    // Cm Ab Bb Gm
    chords: [[48, 51, 55], [44, 48, 51], [46, 50, 53], [43, 46, 50]],
    scale: [60, 63, 65, 67, 70, 72, 75],
  },
  {
    name: 'LAGUNA 88.7', genre: 'Lo-fi', bpm: 76, swing: 0.16,
    songs: [['Rain on Ocean Ave', 'sleepy mango'], ['Ferris Wheel at 3AM', 'kumo & tide'],
      ['Soft Tide', 'lo.verde'], ['Paper Lanterns', 'Nami Haze']],
    // Dm9 G13 Cmaj9 Am7
    chords: [[50, 53, 57, 60, 64], [43, 53, 57, 59, 64], [48, 52, 55, 59, 62], [45, 52, 55, 60, 64]],
    scale: [62, 64, 65, 67, 69, 72, 74],
  },
];

export function createAudio({ state, player, getPolice, traffic, weather }) {
  let ctx = null;
  let master;
  let sfx;
  let music;
  let radioBus;
  let noiseBuf;
  let muted = false;
  let masterLevel = 0.75;
  let musicLevel = 1;
  let station = 0;            // index into STATIONS, STATIONS.length = off
  const loops = {};

  // ------------------------------------------------------------ setup
  function ensure() {
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = muted ? 0 : masterLevel;
      master.connect(ctx.destination);
      sfx = gain(0.9, master);
      music = gain(0.42 * musicLevel, master);
      // Radio through a soft low-pass ("car speakers").
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 6500;
      lp.connect(music);
      radioBus = gain(0, lp);
      noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
      const d = noiseBuf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      buildLoops();
      setInterval(schedule, 25);
    }
    if (ctx.state === 'suspended') ctx.resume();
  }
  window.addEventListener('keydown', ensure);
  window.addEventListener('pointerdown', ensure);

  function gain(v, to) {
    const g = ctx.createGain();
    g.gain.value = v;
    if (to) g.connect(to);
    return g;
  }
  function osc(type, f, to) {
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.value = f;
    if (to) o.connect(to);
    return o;
  }
  function filter(type, f, q = 1, to) {
    const b = ctx.createBiquadFilter();
    b.type = type;
    b.frequency.value = f;
    b.Q.value = q;
    if (to) b.connect(to);
    return b;
  }
  function noise(to) {
    const s = ctx.createBufferSource();
    s.buffer = noiseBuf;
    s.loop = true;
    s.loopStart = Math.random();
    if (to) s.connect(to);
    return s;
  }
  // Envelope helper: attack to `peak`, exponential decay to silence.
  function env(g, t, peak, a, d) {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + a + d);
  }
  const distVol = (x, z, range = 90) => {
    const p = player.position;
    return Math.max(0, 1 - Math.hypot(x - p.x, z - p.z) / range);
  };

  // ------------------------------------------------------------ SFX
  const S = {
    gunshot(vol = 1, bright = 6000, len = 0.28) {
      const t = ctx.currentTime;
      const g = gain(0, sfx);
      const f = filter('lowpass', 5000, 0.7, g);
      f.frequency.setValueAtTime(bright, t);
      f.frequency.exponentialRampToValueAtTime(400, t + len * 0.9);
      const n = noise(f);
      env(g, t, Math.min(1.2, 0.9 * vol), 0.002, len);
      n.start(t); n.stop(t + 0.35);
      const tg = gain(0, sfx);
      const o = osc('sine', 150, tg);
      o.frequency.exponentialRampToValueAtTime(40, t + 0.15);
      env(tg, t, 0.8 * vol, 0.002, 0.18);
      o.start(t); o.stop(t + 0.22);
    },
    click(delay = 0) {
      const t = ctx.currentTime + delay;
      const g = gain(0, sfx);
      const n = noise(filter('bandpass', 3200, 3, g));
      env(g, t, 0.35, 0.001, 0.04);
      n.start(t); n.stop(t + 0.06);
    },
    door() {
      const t = ctx.currentTime;
      const g = gain(0, sfx);
      const o = osc('sine', 120, g);
      o.frequency.exponentialRampToValueAtTime(50, t + 0.1);
      env(g, t, 0.6, 0.002, 0.15);
      o.start(t); o.stop(t + 0.2);
      S.click(0.02);
    },
    punch() {
      const t = ctx.currentTime;
      const g = gain(0, sfx);
      const o = osc('sine', 110, g);
      o.frequency.exponentialRampToValueAtTime(45, t + 0.12);
      env(g, t, 0.9, 0.003, 0.14);
      o.start(t); o.stop(t + 0.2);
      const ng = gain(0, sfx);
      const n = noise(filter('lowpass', 900, 1, ng));
      env(ng, t, 0.5, 0.002, 0.06);
      n.start(t); n.stop(t + 0.1);
    },
    whoosh() {
      const t = ctx.currentTime;
      const g = gain(0, sfx);
      const f = filter('bandpass', 600, 2, g);
      f.frequency.exponentialRampToValueAtTime(2500, t + 0.15);
      const n = noise(f);
      env(g, t, 0.18, 0.03, 0.12);
      n.start(t); n.stop(t + 0.2);
    },
    cash() {
      const t = ctx.currentTime;
      [1318, 1760, 2637].forEach((f, i) => {
        const g = gain(0, sfx);
        const o = osc('sine', f, g);
        env(g, t + i * 0.06, 0.22, 0.005, 0.18);
        o.start(t + i * 0.06); o.stop(t + i * 0.06 + 0.25);
      });
    },
    register() {
      const t = ctx.currentTime;
      [880, 1175].forEach((f, i) => {
        const g = gain(0, sfx);
        const o = osc('square', f, filter('lowpass', 3000, 1, g));
        env(g, t + i * 0.09, 0.12, 0.005, 0.12);
        o.start(t + i * 0.09); o.stop(t + i * 0.09 + 0.2);
      });
      S.cash();
    },
    horn(vol) {
      const t = ctx.currentTime;
      const g = gain(0, sfx);
      const f = filter('lowpass', 1800, 1, g);
      const a = osc('square', 392, f);
      const b = osc('square', 494, f);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.16 * vol, t + 0.02);
      g.gain.setValueAtTime(0.16 * vol, t + 0.38);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.48);
      a.start(t); b.start(t); a.stop(t + 0.5); b.stop(t + 0.5);
    },
    crash() {
      const t = ctx.currentTime;
      const g = gain(0, sfx);
      const n = noise(filter('lowpass', 2500, 0.8, g));
      env(g, t, 0.9, 0.003, 0.5);
      n.start(t); n.stop(t + 0.6);
      const tg = gain(0, sfx);
      const o = osc('sine', 90, tg);
      o.frequency.exponentialRampToValueAtTime(30, t + 0.3);
      env(tg, t, 0.9, 0.003, 0.35);
      o.start(t); o.stop(t + 0.4);
    },
    explosion(vol = 1) {
      const t = ctx.currentTime;
      const g = gain(0, sfx);
      const f = filter('lowpass', 1200, 0.7, g);
      f.frequency.exponentialRampToValueAtTime(120, t + 1.6);
      const n = noise(f);
      env(g, t, 1.0 * vol, 0.01, 1.8);
      n.start(t); n.stop(t + 2);
    },
    thunder(delay = 0.5) {
      const t = ctx.currentTime + delay;
      const g = gain(0, sfx);
      const f = filter('lowpass', 380, 0.8, g);
      const n = noise(f);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.9, t + 0.08);
      g.gain.linearRampToValueAtTime(0.5, t + 0.5);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 3.2);
      n.start(t); n.stop(t + 3.4);
    },
    jingle(notes, type = 'triangle', step = 0.12, vol = 0.25) {
      const t = ctx.currentTime;
      notes.forEach((m, i) => {
        const g = gain(0, sfx);
        const o = osc(type, mtof(m), g);
        env(g, t + i * step, vol, 0.01, step * 2.5);
        o.start(t + i * step); o.stop(t + i * step + step * 3);
      });
    },
    sting(wasted) {
      const t = ctx.currentTime;
      const g = gain(0, sfx);
      const o = osc('sawtooth', wasted ? 110 : 330, filter('lowpass', 1400, 1, g));
      o.frequency.exponentialRampToValueAtTime(wasted ? 45 : 160, t + 1.4);
      env(g, t, 0.35, 0.02, 1.6);
      o.start(t); o.stop(t + 1.8);
    },
  };

  // ------------------------------------------------------------ loops
  function buildLoops() {
    // Bike engine: saw + sub square through a low-pass.
    const eg = gain(0, sfx);
    const ef = filter('lowpass', 700, 2, eg);
    const e1 = osc('sawtooth', 50, ef);
    const e2 = osc('square', 25, ef);
    e1.start(); e2.start();
    loops.engine = { g: eg, f: ef, o: [e1, e2] };
    // Traffic hum: low saw for the nearest car.
    const tg = gain(0, sfx);
    const tf = filter('lowpass', 300, 1, tg);
    const t1 = osc('sawtooth', 40, tf);
    t1.start();
    loops.traffic = { g: tg, o: t1 };
    // Siren: sine whose pitch is swept by a slow LFO (wail).
    const sg = gain(0, sfx);
    const so = osc('triangle', 900, sg);
    const lfo = osc('sine', 0.35);
    const depth = gain(330);
    lfo.connect(depth);
    depth.connect(so.frequency);
    so.start(); lfo.start();
    loops.siren = { g: sg };
    // Helicopter: low noise chopped by a fast LFO (rotor thump).
    const hg = gain(0, sfx);
    const hamp = gain(0.5, hg);
    const hn = noise(filter('lowpass', 420, 1, hamp));
    const hl = osc('square', 11);
    const hd = gain(0.5);
    hl.connect(hd); hd.connect(hamp.gain);
    hn.start(); hl.start();
    loops.heli = { g: hg };
    // Tyre screech: band-passed noise, gain follows the car's slip.
    const kg = gain(0, sfx);
    const kn = noise(filter('bandpass', 1900, 6, kg));
    kn.start();
    loops.skid = { g: kg };
    // Rain: high-passed noise.
    const rg = gain(0, sfx);
    const rn = noise(filter('highpass', 900, 0.5, filter('lowpass', 7000, 0.5, rg)));
    rn.start();
    loops.rain = { g: rg };
    // Vinyl crackle for the lo-fi station.
    const cg = gain(0, radioBus);
    const cn = noise(filter('highpass', 3000, 0.7, cg));
    cn.start();
    loops.crackle = { g: cg };
  }

  // ------------------------------------------------------------ radio
  // Instruments (scheduled at absolute time t on the radio bus).
  const I = {
    kick(t, v = 1) {
      const g = gain(0, radioBus);
      const o = osc('sine', 140, g);
      o.frequency.exponentialRampToValueAtTime(42, t + 0.12);
      env(g, t, 0.9 * v, 0.002, 0.25);
      o.start(t); o.stop(t + 0.3);
    },
    snare(t, v = 1, big = false) {
      const g = gain(0, radioBus);
      const n = noise(filter('bandpass', big ? 1800 : 2600, 0.7, g));
      env(g, t, 0.45 * v, 0.002, big ? 0.32 : 0.14);
      n.start(t); n.stop(t + 0.4);
      const tg = gain(0, radioBus);
      const o = osc('triangle', 190, tg);
      env(tg, t, 0.25 * v, 0.002, 0.08);
      o.start(t); o.stop(t + 0.12);
    },
    hat(t, v = 1, open = false) {
      const g = gain(0, radioBus);
      const n = noise(filter('highpass', 7500, 0.8, g));
      env(g, t, 0.16 * v, 0.001, open ? 0.18 : 0.04);
      n.start(t); n.stop(t + 0.22);
    },
    bass(t, m, dur, type = 'sawtooth', v = 1) {
      const g = gain(0, radioBus);
      const f = filter('lowpass', 500, 4, g);
      f.frequency.setValueAtTime(900, t);
      f.frequency.exponentialRampToValueAtTime(200, t + dur);
      const o = osc(type, mtof(m), f);
      env(g, t, 0.32 * v, 0.005, dur);
      o.start(t); o.stop(t + dur + 0.05);
    },
    pad(t, notes, dur, v = 1) {
      const g = gain(0, radioBus);
      const f = filter('lowpass', 1400, 0.6, g);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.07 * v, t + 0.3);
      g.gain.setValueAtTime(0.07 * v, t + dur - 0.3);
      g.gain.linearRampToValueAtTime(0.0001, t + dur);
      for (const m of notes) {
        for (const det of [-7, 7]) {
          const o = osc('sawtooth', mtof(m + 12), f);
          o.detune.value = det;
          o.start(t); o.stop(t + dur + 0.05);
        }
      }
    },
    keys(t, notes, dur, v = 1) { // Rhodes-ish: sine + octave, slow decay, tremolo
      const g = gain(0, radioBus);
      const trem = gain(1, null);
      trem.connect(g);
      const lfo = osc('sine', 4.5);
      const ld = gain(0.25);
      lfo.connect(ld); ld.connect(trem.gain);
      lfo.start(t); lfo.stop(t + dur + 0.1);
      env(g, t, 0.09 * v, 0.01, dur);
      for (const m of notes) {
        const o = osc('sine', mtof(m + 12), trem);
        const o2 = osc('triangle', mtof(m + 24), gain(0.15, trem));
        o.start(t); o2.start(t); o.stop(t + dur + 0.1); o2.stop(t + dur + 0.1);
      }
    },
    lead(t, m, dur, type = 'square', v = 1) {
      const g = gain(0, radioBus);
      const f = filter('lowpass', 2600, 1, g);
      const o = osc(type, mtof(m), f);
      const vib = osc('sine', 5.5);
      const vd = gain(6);
      vib.connect(vd); vd.connect(o.detune);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.09 * v, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.start(t); vib.start(t); o.stop(t + dur + 0.05); vib.stop(t + dur + 0.05);
    },
    pluck(t, m, v = 1) { // marimba-like
      const g = gain(0, radioBus);
      const o = osc('sine', mtof(m), g);
      const o2 = osc('sine', mtof(m) * 4, gain(0.2, g));
      env(g, t, 0.22 * v, 0.002, 0.35);
      o.start(t); o2.start(t); o.stop(t + 0.4); o2.stop(t + 0.4);
    },
  };

  let step = 0;
  let nextT = 0;
  let songIdx = 0;
  let melody = [];
  const SONG_BARS = 32;
  function makeMelody(st, bar) {
    const r = rng(bar * 977 + st.bpm + songIdx * 7919);
    const out = [];
    let idx = Math.floor(r() * st.scale.length);
    for (let s = 0; s < 16; s += 2) {
      if (r() < 0.35) { out.push(null); continue; }
      idx = Math.max(0, Math.min(st.scale.length - 1, idx + Math.floor(r() * 5) - 2));
      out.push(st.scale[idx]);
    }
    return out;
  }
  function playStep(st, s, bar, t, sd) {
    const chord = st.chords[Math.floor(bar / 1) % st.chords.length];
    const root = chord[0] - 12;
    if (s === 0) melody = (bar % 8) >= 4 ? makeMelody(st, bar) : (bar % 2 ? melody : makeMelody(st, bar));
    if (st.bpm === 104) {
      if (s % 4 === 0) I.kick(t);
      if (s === 4 || s === 12) I.snare(t, 1, true);
      if (s % 2 === 0) I.hat(t, 0.7);
      if (s % 2 === 0) I.bass(t, root, sd * 1.8, 'sawtooth', 0.9);
      if (s === 0) I.pad(t, chord, sd * 16);
      if (bar % 2 === 1) I.pluck(t, chord[s % 3] + 12 * (1 + Math.floor((s % 6) / 3)), 0.6);
      if (bar % 8 >= 4 && s % 2 === 0 && melody[s / 2]) I.lead(t, melody[s / 2], sd * 2.2, 'sawtooth', 0.9);
    } else if (st.bpm === 96) {
      if (s % 4 === 0) I.kick(t);
      if (s === 3 || s === 6 || s === 11 || s === 14) I.snare(t, 0.8);
      if (s % 2 === 1) I.hat(t, 0.5);
      if (s === 0 || s === 3 || s === 8 || s === 11) I.bass(t, root, sd * 2.5, 'square', 0.8);
      if (s % 2 === 0 && melody[s / 2]) I.pluck(t, melody[s / 2]);
      if (s === 0 && bar % 2 === 0) I.pad(t, chord, sd * 32, 0.6);
    } else {
      if (s === 0 || s === 7 || s === 10) I.kick(t, 0.8);
      if (s === 4 || s === 12) I.snare(t, 0.6);
      if (s % 2 === 0) I.hat(t, 0.4, s === 14);
      if (s === 0) { I.keys(t, chord, sd * 15); I.bass(t, root, sd * 6, 'sine', 1.1); }
      if (s === 8) I.bass(t, root + 7, sd * 4, 'sine', 0.9);
      if (bar % 4 >= 2 && s % 4 === 2 && melody[s / 2]) I.keys(t, [melody[s / 2] - 12], sd * 3, 0.7);
    }
  }
  function schedule() {
    if (!ctx || station >= STATIONS.length) return;
    const st = STATIONS[station];
    const sd = 60 / st.bpm / 4;
    if (nextT < ctx.currentTime) nextT = ctx.currentTime + 0.05;
    while (nextT < ctx.currentTime + 0.12) {
      const s = step % 16;
      const bar = Math.floor(step / 16);
      if (s === 0 && bar > 0 && bar % SONG_BARS === 0) {
        songIdx = (songIdx + 1) % st.songs.length;
        state.emit('radioSong', nowPlaying());
      }
      const swing = s % 2 === 1 ? st.swing * sd * 2 : 0;
      playStep(st, s, bar, nextT + swing, sd);
      nextT += sd;
      step++;
    }
  }
  function nowPlaying() {
    const st = STATIONS[station];
    if (!st) return null;
    const [song, artist] = st.songs[songIdx % st.songs.length];
    return { station: st.name, genre: st.genre, song, artist };
  }
  function setStation(i) {
    songIdx = Math.floor(Math.random() * 4);
    station = ((i % (STATIONS.length + 1)) + STATIONS.length + 1) % (STATIONS.length + 1);
    step = 0;
    if (ctx) nextT = ctx.currentTime + 0.05;
    const s = STATIONS[station];
    state.emit('radio', s ? { name: s.name, genre: `${s.genre} · ${s.songs[songIdx][0]}` } : { name: 'RADIO OFF', genre: '' });
  }

  window.addEventListener('keydown', (e) => {
    if (e.repeat) return;
    const k = e.key.toLowerCase();
    if (k === 't') setStation(station + 1);
    if (k === 'v') {
      muted = !muted;
      if (master) master.gain.setTargetAtTime(muted ? 0 : masterLevel, ctx.currentTime, 0.05);
      state.emit('notify', { text: muted ? 'Sound off (V)' : 'Sound on (V)', kind: 'info' });
    }
  });

  // ------------------------------------------------------------ events
  state.on((type, d) => {
    if (!ctx || ctx.state !== 'running') return;
    switch (type) {
      case 'shot': {
        const w = d && d.weapon;
        if (w === 'smg') S.gunshot(0.55, 7000, 0.12);
        else if (w === 'shotgun') { S.gunshot(1.4, 2500, 0.45); S.explosion(0.12); }
        else if (w === 'rifle') S.gunshot(0.95, 8000, 0.2);
        else S.gunshot(1);
        break;
      }
      case 'reload': S.click(0); S.click(0.35); break;
      case 'weaponSwitch': S.click(0); break;
      case 'carStolen': S.door(); break;
      case 'stuntTakeoff': S.whoosh(); S.whoosh(); break;
      case 'stunt': S.jingle(d.first ? [72, 76, 79, 84, 88] : [76, 84], 'triangle', 0.08, 0.16); break;
      case 'dialogueLine': S.jingle([79], 'sine', 0.05, 0.06); break;
      case 'rankup': S.jingle([60, 67, 72, 76, 79, 84], 'square', 0.09, 0.08); break;
      case 'explosion': S.explosion(0.5 + 0.6 * distVol(d.x, d.z, 120)); break;
      case 'copShot': S.gunshot(0.25 + 0.6 * distVol(d.from[0], d.from[2])); break;
      case 'punchHit': S.punch(); break;
      case 'punchMiss': S.whoosh(); break;
      case 'money': if (d > 0) S.cash(); break;
      case 'purchase': S.register(); break;
      case 'horn': { const v = distVol(d.x, d.z, 70); if (v > 0.05) S.horn(v); break; }
      case 'crash': S.crash(); break;
      case 'thunder': S.thunder(d.delay); break;
      case 'busted': S.sting(false); break;
      case 'wasted': S.sting(true); break;
      case 'mission':
        if (d.type === 'pass') S.jingle([60, 64, 67, 72, 76, 79, 84], 'triangle', 0.1, 0.22);
        if (d.type === 'fail') S.jingle([67, 63, 60, 55], 'sawtooth', 0.18, 0.12);
        if (d.type === 'start') S.jingle([72, 79], 'triangle', 0.12, 0.15);
        break;
      case 'wanted': if (d.before < state.wanted) S.jingle([84, 80], 'square', 0.08, 0.06); break;
      default:
    }
  });

  // ------------------------------------------------------------ update
  function update() {
    if (!ctx) return;
    const t = ctx.currentTime;
    const riding = player.inVehicle;
    const sp = Math.abs(player.speed);
    const E = loops.engine;
    let f0 = 42 + sp * 4.2;
    if (player.driving && player.car) {
      // Car: RPM climbs through each gear then drops on the shift.
      const T = player.car.stats;
      const gp = (sp / T.top) * T.gears;
      const frac = gp - Math.floor(gp);
      f0 = (T.top > 40 ? 60 : 45) + frac * 70 + Math.floor(gp) * 6;
    }
    E.o[0].frequency.setTargetAtTime(f0, t, 0.06);
    E.o[1].frequency.setTargetAtTime(f0 / 2, t, 0.06);
    E.f.frequency.setTargetAtTime(500 + f0 * 8, t, 0.1);
    E.g.gain.setTargetAtTime(riding ? 0.07 + Math.min(0.08, sp * 0.004) : 0, t, 0.15);

    const near = traffic.nearest(player.position.x, player.position.z);
    const tv = near ? Math.max(0, 1 - near.dist / 30) : 0;
    loops.traffic.o.frequency.setTargetAtTime(35 + (near ? near.car.speed * 3 : 0), t, 0.2);
    loops.traffic.g.gain.setTargetAtTime(tv * 0.09, t, 0.2);

    const pol = getPolice();
    let sv = 0;
    if (pol && state.wanted > 0) {
      for (const c of pol.cars) sv = Math.max(sv, distVol(c.x, c.z, 140));
    }
    loops.siren.g.gain.setTargetAtTime(sv * 0.07, t, 0.2);
    const hv = pol && pol.heli ? distVol(pol.heli.x, pol.heli.z, 160) : 0;
    loops.heli.g.gain.setTargetAtTime(hv * 0.35, t, 0.3);
    loops.rain.g.gain.setTargetAtTime(weather.rain * 0.22, t, 0.5);
    const sl = player.driving && !player.airborne ? Math.max(0, (player.slip || 0) - 0.16) : 0;
    loops.skid.g.gain.setTargetAtTime(Math.min(0.12, sl * 0.25) * Math.min(1, sp / 8), t, 0.06);

    // Radio is heard on the bike (fades out on foot).
    const on = riding && station < STATIONS.length;
    radioBus.gain.setTargetAtTime(on ? 1 : 0, t, on ? 0.3 : 0.6);
    loops.crackle.g.gain.setTargetAtTime(station === 2 ? 0.012 : 0, t, 0.3);
  }

  return {
    update,
    setStation,
    get station() { return STATIONS[station] ? STATIONS[station].name : 'RADIO OFF'; },
    get nowPlaying() { return nowPlaying(); },
    setVolumes(m, mu) {
      masterLevel = m * 0.95;
      musicLevel = mu;
      if (ctx) {
        master.gain.setTargetAtTime(muted ? 0 : masterLevel, ctx.currentTime, 0.05);
        music.gain.setTargetAtTime(0.42 * musicLevel, ctx.currentTime, 0.05);
      }
    },
    get running() { return !!ctx && ctx.state === 'running'; },
    get muted() { return muted; },
  };
}
