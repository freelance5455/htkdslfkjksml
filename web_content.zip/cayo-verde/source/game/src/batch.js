// batch.js — revision 4 performance: static geometry batching.
// The city was ~6,600 separate meshes (every window, trim, lamp, bench,
// tree trunk...). Each one is a draw call in the main pass AND in the sun
// shadow pass. batchStatic() merges the static meshes of a group into one
// mesh per (material, shadow flags, 80 m map cell): same look, same
// materials (so night emissives / neon still animate), but a few hundred
// draw calls instead of thousands. The cell split keeps frustum culling
// useful. Anything animated or referenced elsewhere is excluded.

import * as THREE from 'three';

const _m = new THREE.Matrix4();
const _inv = new THREE.Matrix4();
const _v = new THREE.Vector3();

function excluded(o, exclude) {
  for (let p = o; p; p = p.parent) if (exclude.has(p)) return true;
  return false;
}

export function batchStatic(root, { exclude = new Set(), cell = 80 } = {}) {
  root.updateMatrixWorld(true);
  _inv.copy(root.matrixWorld).invert();
  const buckets = new Map();
  root.traverse((o) => {
    if (!o.isMesh || o.isInstancedMesh || o.isSkinnedMesh) return;
    if (Array.isArray(o.material) || excluded(o, exclude)) return;
    o.getWorldPosition(_v);
    const key = `${o.material.uuid}|${o.castShadow ? 1 : 0}${o.receiveShadow ? 1 : 0}|${Math.floor(_v.x / cell)},${Math.floor(_v.z / cell)}`;
    if (!buckets.has(key)) buckets.set(key, []);
    buckets.get(key).push(o);
  });

  let before = 0;
  let after = 0;
  for (const list of buckets.values()) {
    before += list.length;
    if (list.length < 2) { after += 1; continue; }
    const mat = list[0].material;
    const wantUV = !!(mat.map || mat.emissiveMap || mat.alphaMap);
    let count = 0;
    const parts = list.map((o) => {
      const g = o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone();
      _m.multiplyMatrices(_inv, o.matrixWorld);
      g.applyMatrix4(_m);
      if (!g.attributes.normal) g.computeVertexNormals();
      count += g.attributes.position.count;
      return g;
    });
    const pos = new Float32Array(count * 3);
    const nor = new Float32Array(count * 3);
    const uv = wantUV ? new Float32Array(count * 2) : null;
    let off = 0;
    for (const g of parts) {
      const n = g.attributes.position.count;
      pos.set(g.attributes.position.array, off * 3);
      nor.set(g.attributes.normal.array, off * 3);
      if (uv && g.attributes.uv) uv.set(g.attributes.uv.array, off * 2);
      off += n;
      g.dispose();
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
    if (uv) geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    geo.computeBoundingSphere();
    const merged = new THREE.Mesh(geo, mat);
    merged.castShadow = list[0].castShadow;
    merged.receiveShadow = list[0].receiveShadow;
    merged.matrixAutoUpdate = false;
    root.add(merged);
    for (const o of list) o.parent.remove(o);
    after += 1;
  }
  // Static: no per-frame matrix recompute for the whole tree.
  root.traverse((o) => { if (!excluded(o, exclude)) { o.updateMatrix(); o.matrixAutoUpdate = false; } });
  root.updateMatrixWorld(true);
  return { before, after };
}
