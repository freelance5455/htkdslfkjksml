// places.js — G2-G4 gameplay locations (data only, no three.js).
// Each one is pinned to an existing building from buildings.js (by parcel
// and centre x), so the doors line up with the shopfronts. Coordinates
// were checked clear of trees, buildings and roads.

// Enterable shops: the door point is just in front of the shopfront door
// (shops are 8 x 10 m; door on the road-facing side). `sign` replaces the
// shop's generic sign text in buildings.js.
export const SHOPS = [
  {
    id: 'ammu', name: 'AMMU-NATION', sign: 'AMMU-NATION', parcel: 'C2', bx: 29,
    door: [29, -20.9], color: '#c0392b',
    blurb: 'Firearms, ammunition and body armour.',
    items: [
      { id: 'pistol', label: 'Hornet 9 pistol', price: 500, give: { weapon: 'pistol' } },
      { id: 'smg', label: 'Viper SMG', price: 1500, give: { weapon: 'smg' } },
      { id: 'shotgun', label: 'Thunder 12 shotgun', price: 2500, give: { weapon: 'shotgun' } },
      { id: 'rifle', label: 'Marlin AR rifle', price: 4000, give: { weapon: 'rifle' } },
      { id: 'ammo', label: 'Ammo for the gun in hand', price: 0, give: { ammoInHand: true } },
      { id: 'armor50', label: 'Light body armour (+50)', price: 60, give: { armor: 50 } },
      { id: 'armor100', label: 'Heavy body armour (+100)', price: 100, give: { armor: 100 } },
    ],
  },
  {
    id: 'pharmacy', name: 'PHARMACY', sign: 'PHARMACY', parcel: 'C3', bx: 43,
    door: [43, 20.9], color: '#27ae60',
    blurb: 'Patch yourself up.',
    items: [
      { id: 'bandage', label: 'Bandages (+25 HP)', price: 20, give: { hp: 25 } },
      { id: 'painkillers', label: 'Painkillers (+50 HP)', price: 35, give: { hp: 50 } },
      { id: 'medkit', label: 'Medkit (full health)', price: 60, give: { hp: 100 } },
    ],
  },
  {
    id: 'pizza', name: 'PIZZA', sign: 'PIZZA', parcel: 'B2', bx: -40,
    door: [-40, -20.9], color: '#e67e22',
    blurb: 'Hot slices, cold drinks.',
    items: [
      { id: 'soda', label: 'Soda (+5 HP)', price: 2, give: { hp: 5 } },
      { id: 'slice', label: 'Pizza slice (+15 HP)', price: 6, give: { hp: 15 } },
      { id: 'large', label: 'Large pizza (+40 HP)', price: 15, give: { hp: 40 } },
    ],
  },
  {
    id: 'market', name: '24/7', sign: '24/7', parcel: 'B3', bx: -40,
    door: [-40, 20.9], color: '#2980b9',
    blurb: 'Open all night.',
    items: [
      { id: 'chips', label: 'Chips (+8 HP)', price: 3, give: { hp: 8 } },
      { id: 'sandwich', label: 'Sandwich (+20 HP)', price: 8, give: { hp: 20 } },
      { id: 'energy', label: 'Energy drink (+12 HP)', price: 5, give: { hp: 12 } },
    ],
  },
];

// Where you wake up after WASTED (in front of the Eastside apartment block
// that carries the HOSPITAL sign) and after BUSTED (beside the C2 tower
// with the POLICE sign on its east face). `face` is the player heading.
export const HOSPITAL = { name: 'HOSPITAL', parcel: 'D3', bx: 79, respawn: [88.5, 30], face: Math.PI };
export const POLICE_STATION = { name: 'POLICE', parcel: 'C2', bx: 29, respawn: [39.5, -40], face: Math.PI / 2 };

// G3: free pistol crate in Downtown (B2 plaza corner, by the roundabout).
export const PISTOL_CRATE = { pos: [-19, -19], rounds: 24, respawn: 90 };

// G4: mission chain (missions.js). Points are walkable ground spots.
export const SPOTS = {
  pizzaDoor: [-40, -19.5],
  pier: [133, 5],
  roundaboutEast: [10, 13],
  terminal: [-88, 70],
  portDocks: [0, -117],
  parkGate: [-58, -6],
  // Armed & Dangerous: stand in the C4 warehouse yard, bottles on posts.
  shootingRange: [30, 90.5],
  bottles: [[20, 93], [40, 93], [31, 101], [52, 90], [33, 96]],
  // Cash Grab: bundles on the Central Park lawn (checked clear of trees).
  parkCash: [[-95, 12], [-78, 22], [-100, 20], [-90, 35], [-72, 40], [-105, 45]],
  // Street Brawl: D4 industrial yard.
  brawlStart: [75, 92],
  brawlThugs: [[88, 95], [95, 92], [86, 99]],
  // Dockside Shootout: armed gang on the port strip.
  dockStart: [0, -100],
  dockGunmen: [[15, -126], [40, -122], [-40, -122], [10, -121], [-10, -121], [20, -121]],
  // Rico's Paint & Tune (mod shop): in front of the B4 warehouse door.
  garage: [-31.5, 69.5],
};

// Rico's Paint & Tune: drive in and press E (revision 2 mod shop).
export const GARAGE = { name: "RICO'S PAINT & TUNE", parcel: 'B4', bx: -31.5, pos: [-31.5, 69.5] };

// Revision 3: stunt ramps (wedges: len along `heading`, rising toward the
// lip). Each spot and its 22 m run-up was checked clear of trees, palms,
// buildings, the lake and the sea.
export const RAMPS = [
  { id: 'vb-south', name: 'Vice Beach South', x: 163, z: -40, heading: 0, len: 7, w: 4.2, h: 1.7 },
  { id: 'vb-north', name: 'Vice Beach North', x: 163, z: 40, heading: Math.PI, len: 7, w: 4.2, h: 1.7 },
  { id: 'park', name: 'Central Park Lawn', x: -90, z: 40, heading: 0, len: 7, w: 4.2, h: 1.5 },
  { id: 'apron', name: 'Airport Apron', x: -128, z: 90, heading: -Math.PI / 2, len: 8, w: 4.6, h: 2.0 },
];
