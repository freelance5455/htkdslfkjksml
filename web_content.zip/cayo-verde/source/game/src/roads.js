// roads.js — renders ALL road infrastructure FROM the layout graph.
// Roads, intersection patches, markings, zebra crossings, sidewalks +
// curbs, traffic lights and street lamps. Every coordinate comes from
// layout.js (NODES / EDGES / ROADS / CROSSINGS / SIDEWALKS / ROUNDABOUT).
// R2: the mesh is GENERATED from the graph — one ribbon per edge, one
// asphalt patch per intersection node, zebras only from CROSSINGS. No
// hand-placed segments, no joint discs on asphalt, no medians, no tan
// strips: the asphalt is ONE continuous surface, intersection to
// intersection. Low-poly (§8B): flat shading, simple primitives, canvas
// flat patterns only (the sidewalk tile texture).
//
// Y layer stack (ground tops out at the lake, 0.65):
//   ribbons 0.70 (+0.0005 per edge index, max 0.7215)
//   -> intersection patches 0.725 -> manholes/grates 0.73
//   -> roundabout ring 0.738 -> markings 0.74 -> zebra 0.76
//   -> sidewalk tops 0.805 (curb 0.10 above the road)

import * as THREE from 'three';
import {
  LAYOUT, NODES, EDGES, SIDEWALKS, CROSSINGS, ROUNDABOUT,
  computeIntersections, roadById, roadDirectionAt, sidewalkWidthFor,
} from './layout.js';

const Y_ROAD = 0.7;
const Y_PATCH = 0.725;
const Y_DARK = 0.73;
const Y_ROUNDABOUT = 0.738;
const Y_MARK = 0.74;
const Y_ZEBRA = 0.76;
const Y_WALK = 0.805;
// Roundabout geometry (R2): grass island to 6 m, circulating asphalt
// ring 6–14 m, arm zebras at 16 m (from CROSSINGS data).
const RA_ISLAND_R = 6;
const RA_RING_R = 14;

// Flat-shaded materials (low-poly §8B). Shared across the whole module.
function flatMat(color, opts = {}) {
  return new THREE.MeshStandardMaterial({
    color,
    roughness: opts.roughness ?? 0.9,
    metalness: 0,
    flatShading: true,
    side: THREE.DoubleSide,
    ...(opts.emissive ? { emissive: opts.emissive, emissiveIntensity: opts.emissiveIntensity ?? 1 } : {}),
  });
}

// Accumulates flat quads / discs / rings into ONE BufferGeometry (one draw
// call per material). All geometry is horizontal; y is baked per vertex.
class FlatBatch {
  constructor() {
    this.pos = [];
    this.uv = [];
    this.idx = [];
  }

  // Quad from four [x, z] corners. `uvs` is [[u, v] x 4], default unit square.
  quad(a, b, c, d, y, uvs) {
    const base = this.pos.length / 3;
    for (const [x, z] of [a, b, c, d]) this.pos.push(x, y, z);
    const u = uvs || [[0, 0], [1, 0], [1, 1], [0, 1]];
    for (const [s, t] of u) this.uv.push(s, t);
    this.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
  }

  // Flat disc (triangle fan) centred at [x, z], radius r, 12 segments.
  disc(x, z, r, y) {
    const base = this.pos.length / 3;
    this.pos.push(x, y, z);
    this.uv.push(0.5, 0.5);
    const seg = 12;
    for (let i = 0; i <= seg; i++) {
      const a = (i / seg) * Math.PI * 2;
      this.pos.push(x + Math.cos(a) * r, y, z + Math.sin(a) * r);
      this.uv.push(0.5 + Math.cos(a) * 0.5, 0.5 + Math.sin(a) * 0.5);
    }
    for (let i = 0; i < seg; i++) this.idx.push(base, base + 1 + i, base + 2 + i);
  }

  // Flat ring (annulus) centred at [x, z], inner r0, outer r1, 24 segments.
  ring(x, z, r0, r1, y) {
    const seg = 24;
    const base = this.pos.length / 3;
    for (let i = 0; i <= seg; i++) {
      const a = (i / seg) * Math.PI * 2;
      const c = Math.cos(a);
      const s = Math.sin(a);
      this.pos.push(x + c * r0, y, z + s * r0, x + c * r1, y, z + s * r1);
      this.uv.push(0, 0, 1, 0);
    }
    for (let i = 0; i < seg; i++) {
      const k = base + i * 2;
      this.idx.push(k, k + 1, k + 3, k, k + 3, k + 2);
    }
  }

  build(material, name) {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(this.uv, 2));
    geo.setIndex(this.idx);
    // Revision 4: every FlatBatch piece is horizontal, but the quads were
    // wound clockwise from above so computed normals pointed DOWN — the
    // HDR post-process path then lit the asphalt from below (near black).
    // Force straight-up normals.
    const n = new Float32Array(this.pos.length);
    for (let i = 1; i < n.length; i += 3) n[i] = 1;
    geo.setAttribute('normal', new THREE.BufferAttribute(n, 3));
    const mesh = new THREE.Mesh(geo, material);
    mesh.receiveShadow = true;
    mesh.name = name;
    return mesh;
  }
}

// ---------------------------------------------------------------- graph helpers
// The mesh is generated FROM NODES + EDGES. Every helper here reads the
// graph; nothing is hand-placed.

const nodeById = new Map(NODES.map((n) => [n.id, n]));

// Intersection patch half-size at a node: half the widest entering road.
// The patch is a square of that half-size, so it covers the whole junction
// and joins every entering arm.
function patchHalfAt(nodeId) {
  let half = 0;
  for (const e of EDGES) {
    if (e.from === nodeId || e.to === nodeId) half = Math.max(half, e.width / 2);
  }
  return half;
}

// Intersection nodes (type 'intersection') + their patch half-sizes, for
// the marking skip (no dashes on a patch) and the patch builder.
const INTERSECTION_NODES = NODES.filter((n) => n.type === 'intersection');
const PATCH_HALF = new Map(
  INTERSECTION_NODES.map((n) => [n.id, patchHalfAt(n.id)]),
);

// True if (x, z) lies inside any intersection patch (axis-aligned square
// test — every road here is orthogonal, so the patch is axis-aligned).
function inPatch(x, z) {
  for (const n of INTERSECTION_NODES) {
    const h = PATCH_HALF.get(n.id) + 0.5;
    if (Math.abs(x - n.x) < h && Math.abs(z - n.z) < h) return true;
  }
  return false;
}

// True if (x, z) lies within r of any zebra crossing centre.
function nearCrossing(x, z, r) {
  for (const c of CROSSINGS) {
    if (Math.hypot(x - c.position[0], z - c.position[1]) < r) return true;
  }
  return false;
}

// --- road surfaces: ONE asphalt ribbon per EDGE (width = edge.width),
// node to node, no gaps; ONE full asphalt square per intersection node,
// joining all entering arms; the roundabout's circulating ring (6–14 m).
// Ribbons overlap INTO the patches (never a gap); the patches sit above
// the ribbons, so the junction reads as ONE continuous asphalt surface.
function buildRoadSurfaces(group, asphaltMat) {
  const batch = new FlatBatch();
  const [rx, rz] = [ROUNDABOUT.x, ROUNDABOUT.z];

  EDGES.forEach((edge, ei) => {
    const a = nodeById.get(edge.from);
    const b = nodeById.get(edge.to);
    if (!a || !b) return;
    const y = Y_ROAD + ei * 0.0005;
    const hw = edge.width / 2;
    let [ax, az] = [a.x, a.z];
    let [bx, bz] = [b.x, b.z];
    const dx = bx - ax;
    const dz = bz - az;
    const len = Math.hypot(dx, dz) || 1;
    const ux = dx / len;
    const uz = dz / len;
    // Edges ending at the roundabout stop 1 m INSIDE the circulating ring
    // (13 m from the centre) instead of running to the node — the ring
    // (6–14 m, built below at a higher y) joins the arms, and the island
    // stays clear of asphalt.
    if (a.type === 'roundabout') { ax += ux * (RA_RING_R - 1); az += uz * (RA_RING_R - 1); }
    if (b.type === 'roundabout') { bx -= ux * (RA_RING_R - 1); bz -= uz * (RA_RING_R - 1); }
    const nx = -uz * hw;
    const nz = ux * hw;
    batch.quad(
      [ax - nx, az - nz], [bx - nx, bz - nz],
      [bx + nx, bz + nz], [ax + nx, az + nz],
      y,
    );
  });

  // Intersection patches: one full asphalt square per intersection node,
  // sized to the largest entering road. Same asphalt as the ribbons.
  for (const n of INTERSECTION_NODES) {
    const h = PATCH_HALF.get(n.id);
    batch.quad(
      [n.x - h, n.z - h], [n.x + h, n.z - h],
      [n.x + h, n.z + h], [n.x - h, n.z + h],
      Y_PATCH,
    );
  }

  // Roundabout: circulating asphalt ring, island edge (6 m) to outer edge
  // (14 m). The arm zebras at 16 m clear it; no lines on the ring.
  batch.ring(rx, rz, RA_ISLAND_R, RA_RING_R, Y_ROUNDABOUT);
  group.add(batch.build(asphaltMat, 'road-surfaces'));
}

// Walk a polyline, calling fn(pos, dir, distance) every `step` metres from
// `startOffset` along the whole polyline (phase carries across vertices).
function walkPolyline(points, closed, step, startOffset, fn) {
  const n = points.length;
  const segCount = closed ? n : n - 1;
  let dist = 0;
  let next = startOffset;
  for (let i = 0; i < segCount; i++) {
    const a = points[i];
    const b = points[(i + 1) % n];
    const dx = b[0] - a[0];
    const dz = b[1] - a[1];
    const len = Math.hypot(dx, dz);
    if (len < 1e-6) continue;
    const ux = dx / len;
    const uz = dz / len;
    while (next <= dist + len) {
      const s = next - dist;
      fn([a[0] + ux * s, a[1] + uz * s], [ux, uz], next);
      next += step;
    }
    dist += len;
  }
}

// A flat quad centred at `pos`, `len` along `dir`, `wid` across it.
function dashQuad(batch, pos, dir, len, wid, y) {
  const [dx, dz] = dir;
  const nx = -dz;
  const nz = dx;
  const hl = len / 2;
  const hw = wid / 2;
  const [px, pz] = pos;
  batch.quad(
    [px - dx * hl - nx * hw, pz - dz * hl - nz * hw],
    [px + dx * hl - nx * hw, pz + dz * hl - nz * hw],
    [px + dx * hl + nx * hw, pz + dz * hl + nz * hw],
    [px - dx * hl + nx * hw, pz - dz * hl + nz * hw],
    y,
  );
}

// Along-road distance of each crossing on its road (for the marking
// skip): project each crossing onto its road's polyline and record the
// distance from the polyline start. The skip is measured ALONG the road
// (not Euclidean) so laterally-offset markings (lane dashes, edge lines)
// stop before zebras too.
const CROSSING_DIST = new Map(); // roadId -> [along-road distances]
for (const road of LAYOUT.roads) {
  const dists = [];
  const pts = road.points;
  const n = pts.length;
  const segCount = road.closed ? n : n - 1;
  const cum = [0];
  for (let i = 0; i < segCount; i++) {
    const a = pts[i];
    const b = pts[(i + 1) % n];
    cum.push(cum[i] + Math.hypot(b[0] - a[0], b[1] - a[1]));
  }
  for (const c of CROSSINGS) {
    if (c.roadId !== road.id) continue;
    let best = Infinity;
    let bestDist = 0;
    for (let i = 0; i < segCount; i++) {
      const a = pts[i];
      const b = pts[(i + 1) % n];
      const dx = b[0] - a[0];
      const dz = b[1] - a[1];
      const l2 = dx * dx + dz * dz || 1;
      let t = ((c.position[0] - a[0]) * dx + (c.position[1] - a[1]) * dz) / l2;
      t = Math.max(0, Math.min(1, t));
      const d = Math.hypot(c.position[0] - (a[0] + t * dx), c.position[1] - (a[1] + t * dz));
      if (d < best) { best = d; bestDist = cum[i] + t * Math.sqrt(l2); }
    }
    dists.push(bestDist);
  }
  CROSSING_DIST.set(road.id, dists);
}

// --- markings: UNIFORM white dashed centre line on ALL roads (Farhan's
// locked decision), white dashed lane lines on MAIN roads only (4-lane),
// solid white edge lines. All dashes STOP before each zebra (skip radius =
// zebra half-band 1.25 m + 1 m clearance + half the marking length,
// measured ALONG the road) and never land on an intersection patch or on
// the roundabout ring. No lines on the roundabout ring.
function buildMarkings(group, whiteMat, darkMat) {
  const M = LAYOUT.markings;
  const white = new FlatBatch();
  const dark = new FlatBatch();
  // Zebra skip radii per marking type (band 2.5 m + 1 m clearance + half
  // the marking's own length, so no marking ever touches a zebra).
  const SKIP_CENTRE = 1.25 + 1 + M.centerLine.dash / 2;
  const SKIP_LANE = 1.25 + 1 + M.laneLine.dash / 2;
  const SKIP_EDGE = 1.25 + 1 + 2; // edge chunks are 4 m long
  const clearForMarking = (x, z, skip, road, dist) => {
    if (inPatch(x, z)) return false;
    // Roundabout: no markings inside the ring + 2 m margin (the road
    // polylines run through the centre, so the zebra skip alone does not
    // clear the interior).
    if (Math.hypot(x - ROUNDABOUT.x, z - ROUNDABOUT.z) < RA_RING_R + 2) return false;
    for (const cd of CROSSING_DIST.get(road.id) || []) {
      if (Math.abs(dist - cd) < skip) return false;
    }
    return true;
  };

  for (const road of LAYOUT.roads) {
    const hw = road.width / 2;
    const closed = !!road.closed;
    // Centre dashes: 3 m dash, 4.5 m gap, 0.15 m wide, on every road.
    walkPolyline(road.points, closed, M.centerLine.dash + M.centerLine.gap,
      M.centerLine.dash / 2, (pos, dir, dist) => {
        if (!clearForMarking(pos[0], pos[1], SKIP_CENTRE, road, dist)) return;
        dashQuad(white, pos, dir, M.centerLine.dash, M.centerLine.width, Y_MARK);
      });
    // Lane lines on MAIN roads only (4-lane): two dashed lines at +/- width/4.
    if (road.cls === 'main') {
      const off = road.width / 4;
      for (const s of [1, -1]) {
        walkPolyline(road.points, closed, M.laneLine.dash + M.laneLine.gap,
          M.laneLine.dash / 2, (pos, dir, dist) => {
            if (!clearForMarking(pos[0], pos[1], SKIP_LANE, road, dist)) return;
            const nx = -dir[1];
            const nz = dir[0];
            dashQuad(white, [pos[0] + nx * off * s, pos[1] + nz * off * s],
              dir, M.laneLine.dash, M.laneLine.width, Y_MARK);
          });
      }
    }
    // Edge lines: solid, 0.1 m, at the road edge — laid in 4 m chunks
    // so they break cleanly before zebras and patches.
    for (const s of [1, -1]) {
      walkPolyline(road.points, closed, 4, 2, (pos, dir, dist) => {
        if (!clearForMarking(pos[0], pos[1], SKIP_EDGE, road, dist)) return;
        const nx = -dir[1];
        const nz = dir[0];
        dashQuad(white,
          [pos[0] + nx * (hw - 0.15) * s, pos[1] + nz * (hw - 0.15) * s],
          dir, 4, M.edgeLine.width, Y_MARK);
      });
    }
    // Manhole covers: round dark discs every ~40 m, alternating sides,
    // mid-block only (never on a patch, a zebra, or near an intersection).
    let manholeSide = 1;
    walkPolyline(road.points, closed, 40, 20, (pos, dir) => {
      if (inPatch(pos[0], pos[1]) || nearCrossing(pos[0], pos[1], 4)) return;
      const nearNode = NODES.some((n) =>
        n.type !== 'junction' && Math.hypot(n.x - pos[0], n.z - pos[1]) < 11);
      if (nearNode) return;
      const nx = -dir[1];
      const nz = dir[0];
      dark.disc(pos[0] + nx * 2 * manholeSide, pos[1] + nz * 2 * manholeSide,
        0.6, Y_DARK);
      manholeSide *= -1;
    });
  }

  // Zebra crossings (ONLY from the CROSSINGS graph — they exist only at
  // intersections, never mid-block): stripes 2.5 m long ALONG the road,
  // 0.6 m wide, 0.5 m gaps, spanning the FULL road width — the street
  // visual's continental style (long axis parallel to traffic). No zebra
  // on the roundabout ring and none on the Port Causeway stub (R1a left
  // both bare deliberately, so CROSSINGS simply has no entries there).
  for (const c of CROSSINGS) {
    const road = roadById(c.roadId);
    if (!road) continue;
    const hw = road.width / 2;
    const [nx, nz] = c.direction; // pedestrian direction (across the road)
    const dir = [nz, -nx]; // road direction (perpendicular to it)
    const [px, pz] = c.position;
    for (let off = -hw + 0.55; off <= hw - 0.55; off += 1.1) {
      dashQuad(white, [px + nx * off, pz + nz * off], dir, 2.5, 0.6, Y_ZEBRA);
    }
    // Drain grate beside the crossing, on the road near the curb.
    dashQuad(dark, [px + nx * (hw - 0.9), pz + nz * (hw - 0.9)],
      dir, 1.2, 0.5, Y_DARK);
  }

  group.add(white.build(whiteMat, 'road-markings'));
  group.add(dark.build(darkMat, 'manholes-grates'));
}

// Sidewalk tile texture: one 1.2 m canvas tile, thin dark joints.
function makeTileTexture() {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = LAYOUT.palette.sidewalk;
  ctx.fillRect(0, 0, size, size);
  ctx.strokeStyle = '#a89e98';
  ctx.lineWidth = 3;
  ctx.strokeRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

// --- sidewalks + curbs, rendered FROM the SIDEWALKS graph. Each strip is
// a solid box (0.2 -> 0.80, top 0.10 above the road = the curb) with the
// road-facing side in the lighter curb colour, plus a tiled top ribbon.
// The strips are already trimmed to stop at intersection boundaries, so
// they NEVER cross a road or a patch — and there are NO joint discs at
// all (the old build's beige discs landing on asphalt were the tan-strip
// bug this rebuild kills; the strips butt at corners instead).
function buildSidewalks(group, mats) {
  const tileMat = new THREE.MeshStandardMaterial({
    map: makeTileTexture(),
    roughness: 0.95,
    metalness: 0,
    flatShading: true,
    side: THREE.DoubleSide,
  });
  const tops = new FlatBatch();
  const TILE = 1.2; // metres per texture tile
  const [rx, rz] = [ROUNDABOUT.x, ROUNDABOUT.z];

  for (const walk of SIDEWALKS) {
    const pts = walk.points;
    const w = walk.width;
    const hw = w / 2;
    // Box materials: [px, nx, py, ny, pz, nz]. Local +Z maps to the left
    // normal, so a 'left' strip faces the road on -Z (index 5) and a
    // 'right' strip on +Z (index 4).
    const boxMats = [mats.walkSide, mats.walkSide, mats.walkSide,
      mats.walkSide, mats.walkSide, mats.walkSide];
    boxMats[walk.side === 'left' ? 5 : 4] = mats.curb;
    const a = pts[0];
    const b = pts[1];
    const dx = b[0] - a[0];
    const dz = b[1] - a[1];
    const len = Math.hypot(dx, dz);
    if (len < 1e-6) continue;
    const ux = dx / len;
    const uz = dz / len;
    const nx = -uz;
    const nz = ux;
    // Solid base box: top at 0.80, sides down to 0.20 (below the grass).
    const box = new THREE.Mesh(
      new THREE.BoxGeometry(len, 0.6, w), boxMats);
    box.position.set((a[0] + b[0]) / 2, 0.5, (a[1] + b[1]) / 2);
    box.rotation.y = Math.atan2(-uz, ux);
    box.receiveShadow = true;
    box.name = `sidewalk-${walk.roadId}-${walk.side}`;
    group.add(box);
    // Tiled top ribbon, UVs in metres so tiles stay 1.2 m everywhere.
    tops.quad(
      [a[0] - nx * hw, a[1] - nz * hw], [b[0] - nx * hw, b[1] - nz * hw],
      [b[0] + nx * hw, b[1] + nz * hw], [a[0] + nx * hw, a[1] + nz * hw],
      Y_WALK,
      [[0, 0], [len / TILE, 0], [len / TILE, w / TILE], [0, w / TILE]],
    );
  }

  // Ring-road outer corner connectors (R1a flag): the outer strips stop
  // 9.5 m short of each ring corner, so the corners get an L-shaped
  // connector (two axis-aligned rectangles) joining the two strips around
  // the corner. Both legs stay OUTSIDE the corner's intersection patch
  // (which spans 8 m from the corner node) — no sidewalk over asphalt.
  const cornerBox = (x0, z0, x1, z1, curbFace) => {
    const lenX = Math.abs(x1 - x0);
    const lenZ = Math.abs(z1 - z0);
    const boxMats = [mats.walkSide, mats.walkSide, mats.walkSide,
      mats.walkSide, mats.walkSide, mats.walkSide];
    boxMats[curbFace] = mats.curb;
    const box = new THREE.Mesh(
      new THREE.BoxGeometry(lenX, 0.6, lenZ), boxMats);
    box.position.set((x0 + x1) / 2, 0.5, (z0 + z1) / 2);
    box.receiveShadow = true;
    box.name = 'sidewalk-corner';
    group.add(box);
    tops.quad([x0, z0], [x1, z0], [x1, z1], [x0, z1], Y_WALK,
      [[0, 0], [lenX / TILE, 0], [lenX / TILE, lenZ / TILE], [0, lenZ / TILE]]);
  };
  for (const [cx, cz] of [[-120, -120], [120, -120], [-120, 120], [120, 120]]) {
    const sx = Math.sign(cx); // outward x (+1 east, -1 west)
    const sz = Math.sign(cz); // outward z (+1 south, -1 north)
    // E-W leg: extends the E-W outer strip to the corner (road face: the
    // side toward the city centre in z).
    cornerBox(cx + sx * 8, cz + sz * 8, cx - sx * 9.5, cz + sz * 11,
      sz === -1 ? 4 : 5);
    // N-S leg: extends the N-S outer strip to the corner, including the
    // 3x3 corner square (road face: toward the city centre in x).
    cornerBox(cx + sx * 8, cz + sz * 11, cx + sx * 11, cz - sz * 9.5,
      sx === -1 ? 0 : 1);
  }

  // Roundabout sidewalk arcs: the sidewalk ring around the roundabout,
  // broken at the 4 arms (the arms' roads + zebras cross it). Each arc
  // spans one quadrant between adjacent arms, inner radius 14 m (the
  // ring's outer edge) to outer radius 17 m, stopping 36° short of each
  // arm centreline so it never overlaps a road. Angles use the cylinder
  // convention (x = r·sin θ, z = r·cos θ): arms at θ = 0° (S), 90° (E),
  // 180° (N), 270° (W).
  const RA_WALK_IN = RA_RING_R;
  const RA_WALK_OUT = RA_RING_R + 3;
  const MARGIN = Math.asin(8 / RA_RING_R) + 0.02; // ~36° from each arm
  for (let q = 0; q < 4; q++) {
    const t0 = (q * Math.PI) / 2 + MARGIN;
    const t1 = ((q + 1) * Math.PI) / 2 - MARGIN;
    const pt = (r, t) => [rx + r * Math.sin(t), rz + r * Math.cos(t)];
    const midR = (RA_WALK_IN + RA_WALK_OUT) / 2;
    const arcLen = midR * (t1 - t0);
    tops.quad(
      pt(RA_WALK_IN, t0), pt(RA_WALK_IN, t1),
      pt(RA_WALK_OUT, t1), pt(RA_WALK_OUT, t0),
      Y_WALK,
      [[0, 0], [arcLen / TILE, 0],
        [arcLen / TILE, 3 / TILE], [0, 3 / TILE]],
    );
    // Solid curb faces, inner (road-facing) and outer, 0.20 -> 0.80.
    for (const [r, mat, name] of [
      [RA_WALK_IN, mats.curb, 'roundabout-walk-kerb'],
      [RA_WALK_OUT, mats.walkSide, 'roundabout-walk-side'],
    ]) {
      const wall = new THREE.Mesh(
        new THREE.CylinderGeometry(r, r, 0.6, 2, 1, true, t0, t1 - t0), mat);
      wall.position.set(rx, 0.5, rz);
      wall.receiveShadow = true;
      wall.name = name;
      group.add(wall);
    }
  }
  group.add(tops.build(tileMat, 'sidewalk-tops'));
}

// --- traffic lights: black gantry arms over MAIN roads (pole + square base
// + horizontal arm + two vertical heads, red/amber/green, green lit),
// simple pole-mounted heads at collector/local intersections.
function makeSignalHead(mats, geos) {
  const g = new THREE.Group();
  const box = new THREE.Mesh(geos.headBox, mats.black);
  box.castShadow = true;
  g.add(box);
  const lampY = [0.32, 0, -0.32];
  const lampMats = [mats.redOff, mats.amberOff, mats.greenOn];
  lampY.forEach((y, i) => {
    const lamp = new THREE.Mesh(geos.lampDisc, lampMats[i]);
    lamp.position.set(0, y, 0.14);
    g.add(lamp);
  });
  return g;
}

function buildTrafficLights(group, mats) {
  const geos = {
    pole: new THREE.CylinderGeometry(0.12, 0.14, 6.5, 6),
    base: new THREE.BoxGeometry(0.6, 0.3, 0.6),
    arm: new THREE.BoxGeometry(1, 0.25, 0.25),
    headBox: new THREE.BoxGeometry(0.35, 1.0, 0.25),
    lampDisc: new THREE.CircleGeometry(0.11, 8),
  };
  const [rx, rz] = [ROUNDABOUT.x, ROUNDABOUT.z];
  const faceAngle = (dir) => Math.atan2(dir[0], dir[1]); // local +Z -> dir

  // One pole: base + pole + head at the top, facing `facing`.
  const poleLight = (pos, facing) => {
    const g = new THREE.Group();
    g.position.set(pos[0], 0, pos[1]);
    const base = new THREE.Mesh(geos.base, mats.black);
    base.position.y = 0.95;
    g.add(base);
    const pole = new THREE.Mesh(geos.pole, mats.black);
    pole.position.y = 0.8 + 3.25;
    pole.castShadow = true;
    g.add(pole);
    const head = makeSignalHead(mats, geos);
    head.position.y = 7.0;
    head.rotation.y = faceAngle(facing);
    g.add(head);
    group.add(g);
  };

  for (const ix of computeIntersections()) {
    if (Math.hypot(ix.x - rx, ix.z - rz) < 24) continue; // roundabout: own poles
    const [ra, rb] = ix.roads.map(roadById);
    if (!ra || !rb) continue;
    const dirA = roadDirectionAt(ra, ix.x, ix.z);
    const dirB = roadDirectionAt(rb, ix.x, ix.z);
    const hwA = ra.width / 2;
    const hwB = rb.width / 2;
    // Corner of the junction, on the sidewalk.
    const cx = ix.x + dirA[0] * (hwB + 2.5) + dirB[0] * (hwA + 2.5);
    const cz = ix.z + dirA[1] * (hwB + 2.5) + dirB[1] * (hwA + 2.5);
    const wideA = ra.cls === 'main';
    const wideB = rb.cls === 'main';
    if (!wideA && !wideB) {
      poleLight([cx, cz], dirA);
      continue;
    }
    // Gantry over the wide road (A preferred): arm reaches from the corner
    // pole across the road; two heads face the two traffic directions.
    const wide = wideA ? ra : rb;
    const dirW = wideA ? dirA : dirB;
    const dirAcross = wideA ? dirB : dirA;
    const hwW = wide.width / 2;
    const armLen = hwW + 2.5 + 1;
    const g = new THREE.Group();
    g.position.set(cx, 0, cz);
    const base = new THREE.Mesh(geos.base, mats.black);
    base.position.y = 0.95;
    g.add(base);
    const pole = new THREE.Mesh(geos.pole, mats.black);
    pole.position.y = 0.8 + 3.25;
    pole.castShadow = true;
    g.add(pole);
    const arm = new THREE.Mesh(geos.arm, mats.black);
    arm.scale.x = armLen;
    arm.rotation.y = Math.atan2(-dirAcross[1], dirAcross[0]);
    arm.position.set(
      -dirAcross[0] * armLen / 2, 7.1, -dirAcross[1] * armLen / 2);
    arm.castShadow = true;
    g.add(arm);
    for (const [frac, facing] of [[1 / 3, dirW], [2 / 3, [-dirW[0], -dirW[1]]]]) {
      const head = makeSignalHead(mats, geos);
      head.position.set(
        -dirAcross[0] * armLen * frac, 6.4, -dirAcross[1] * armLen * frac);
      head.rotation.y = faceAngle(facing);
      g.add(head);
    }
    group.add(g);
  }

  // Roundabout approaches: one pole light each, 20 m out on the sidewalk
  // (9.5 m to the driver's right of the arm centreline), head facing the
  // traffic coming into the roundabout.
  const approachDirs = [];
  for (const road of LAYOUT.roads) {
    const idx = road.points.findIndex(([x, z]) => x === rx && z === rz);
    if (idx === -1) continue;
    const neighbours = [];
    if (idx > 0) neighbours.push(road.points[idx - 1]);
    if (idx < road.points.length - 1) neighbours.push(road.points[idx + 1]);
    if (road.closed && idx === 0) neighbours.push(road.points[road.points.length - 1]);
    if (road.closed && idx === road.points.length - 1) neighbours.push(road.points[0]);
    for (const [nx, nz] of neighbours) {
      const dx = nx - rx;
      const dz = nz - rz;
      const len = Math.hypot(dx, dz) || 1;
      approachDirs.push([dx / len, dz / len]);
    }
  }
  for (const dir of approachDirs) {
    const px = rx + dir[0] * 20;
    const pz = rz + dir[1] * 20;
    poleLight([px + dir[1] * 9.5, pz - dir[0] * 9.5], dir);
  }
}

// --- street lamps: curved-arm lamps on the sidewalk, arm overhanging the
// road, warm emissive head (dusk look — no real point lights). Spaced 18 m,
// alternating sides, clear of intersections and the roundabout.
// G5: world positions of every lamp head (day/night light pools).
export const LAMP_HEADS = [];
function buildStreetLamps(group, mats) {
  const geos = {
    pole: new THREE.CylinderGeometry(0.09, 0.12, 6, 6),
    arm: new THREE.BoxGeometry(0.12, 0.12, 2.2),
    head: new THREE.BoxGeometry(0.6, 0.12, 0.28),
  };
  const [rx, rz] = [ROUNDABOUT.x, ROUNDABOUT.z];
  const nearNode = (x, z, r) =>
    NODES.some((n) => n.type !== 'junction' && Math.hypot(n.x - x, n.z - z) < r);

  for (const road of LAYOUT.roads) {
    const hw = road.width / 2;
    const sw = sidewalkWidthFor(road);
    let side = 1;
    walkPolyline(road.points, !!road.closed, 18, 9, (pos, dir) => {
      if (nearNode(pos[0], pos[1], 10)) return;
      if (Math.hypot(pos[0] - rx, pos[1] - rz) < 22) return;
      const nx = -dir[1];
      const nz = dir[0];
      const lx = pos[0] + nx * (hw + sw / 2) * side;
      const lz = pos[1] + nz * (hw + sw / 2) * side;
      // Lamp group: local +Z points toward the road centre.
      const toward = [-nx * side, -nz * side];
      const g = new THREE.Group();
      g.position.set(lx, 0, lz);
      g.rotation.y = Math.atan2(toward[0], toward[1]);
      const pole = new THREE.Mesh(geos.pole, mats.lampPole);
      pole.position.y = 0.8 + 3;
      pole.castShadow = true;
      g.add(pole);
      const arm = new THREE.Mesh(geos.arm, mats.lampPole);
      arm.position.set(0, 6.6, 0.9);
      arm.rotation.x = 0.5; // tilts the far end down toward the road
      arm.castShadow = true;
      g.add(arm);
      const head = new THREE.Mesh(geos.head, mats.lampHead);
      head.position.set(0, 6.2, 1.85);
      g.add(head);
      LAMP_HEADS.push([lx + toward[0] * 1.85, 6.2, lz + toward[1] * 1.85]);
      group.add(g);
      side *= -1;
    });
  }
}

// --- roundabout centre island: a low-poly grass-topped cylinder (6 m
// radius) with a kerb-coloured side, rising just above the circulating
// asphalt ring. The ring itself (6–14 m) is built in buildRoadSurfaces.
function buildRoundaboutIsland(group, mats) {
  const [rx, rz] = [ROUNDABOUT.x, ROUNDABOUT.z];
  const island = new THREE.Mesh(
    new THREE.CylinderGeometry(RA_ISLAND_R, RA_ISLAND_R, 0.55, 24),
    [mats.curb, mats.grass, mats.grass]);
  island.position.set(rx, 0.5, rz);
  island.receiveShadow = true;
  island.name = 'roundabout-island';
  group.add(island);
}

// --- entry point: build every road system into one group, from graph data.
export function buildRoads(scene) {
  const P = LAYOUT.palette;
  const mats = {
    asphalt: flatMat(P.asphalt, { roughness: 0.95 }),
    white: flatMat('#ffffff', { roughness: 0.6 }),
    dark: flatMat('#15161a', { roughness: 0.9 }),
    walkSide: flatMat(P.sidewalk, { roughness: 0.95 }),
    curb: flatMat(P.curb, { roughness: 0.9 }),
    grass: flatMat(P.grass, { roughness: 0.95 }),
    black: flatMat('#1a1a1e', { roughness: 0.6 }),
    lampPole: flatMat('#3a3f44', { roughness: 0.6 }),
    redOff: flatMat('#5a1a1a', { roughness: 0.5 }),
    amberOff: flatMat('#5a4a1a', { roughness: 0.5 }),
    greenOn: flatMat('#1a5a2a', {
      roughness: 0.5, emissive: '#22ff66', emissiveIntensity: 1.5,
    }),
    lampHead: flatMat('#665533', {
      roughness: 0.5, emissive: '#ffd27a', emissiveIntensity: 1.2,
    }),
  };
  const group = new THREE.Group();
  group.name = 'roads';
  buildRoadSurfaces(group, mats.asphalt);
  buildMarkings(group, mats.white, mats.dark);
  buildSidewalks(group, mats);
  buildTrafficLights(group, mats);
  buildStreetLamps(group, mats);
  buildRoundaboutIsland(group, mats);
  group.userData.lampHeadMat = mats.lampHead; // G5 day/night toggles it
  scene.add(group);
  return group;
}
