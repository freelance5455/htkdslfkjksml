// weapons.js — revision 2 arsenal (data only). Slots 1-5 on the number
// keys. dmg = damage per hit (civilians always go down from a bullet),
// rate = seconds between shots, auto = hold F to keep firing, pellets /
// spread = shotgun cone (radians), rank = respect rank needed to buy it
// at AMMU-NATION (the pistol is also free from the Downtown crate).

export const WEAPONS = [
  { id: 'fist', slot: 1, name: 'FISTS', label: 'Fists', melee: true },
  {
    id: 'pistol', slot: 2, name: 'HORNET 9', label: 'Hornet 9 pistol', dmg: 50, rate: 0.28, clip: 12,
    pellets: 1, spread: 0.0, range: 45, auto: false, price: 500, rank: 1, ammoPack: 24, ammoPrice: 40, barrel: 1,
  },
  {
    id: 'smg', slot: 3, name: 'VIPER SMG', label: 'Viper SMG', dmg: 30, rate: 0.085, clip: 30,
    pellets: 1, spread: 0.035, range: 40, auto: true, price: 1500, rank: 3, ammoPack: 90, ammoPrice: 70, barrel: 1.5,
  },
  {
    id: 'shotgun', slot: 4, name: 'THUNDER 12', label: 'Thunder 12 shotgun', dmg: 34, rate: 0.85, clip: 6,
    pellets: 7, spread: 0.11, range: 22, auto: false, price: 2500, rank: 4, ammoPack: 18, ammoPrice: 60, barrel: 2.1,
  },
  {
    id: 'rifle', slot: 5, name: 'MARLIN AR', label: 'Marlin assault rifle', dmg: 55, rate: 0.14, clip: 24,
    pellets: 1, spread: 0.012, range: 70, auto: true, price: 4000, rank: 6, ammoPack: 72, ammoPrice: 90, barrel: 2.4,
  },
];
export const WEAPON = Object.fromEntries(WEAPONS.map((w) => [w.id, w]));
export const GUN_IDS = WEAPONS.filter((w) => !w.melee).map((w) => w.id);

// Respect ranks (XP thresholds). Rank number = index + 1.
export const RANKS = [
  [0, 'ROOKIE'], [120, 'RUNNER'], [300, 'PROSPECT'], [550, 'SOLDIER'],
  [900, 'FIXER'], [1400, 'LIEUTENANT'], [2100, 'CAPO'], [3000, 'LEGEND'],
];
export function rankOf(xp) {
  let r = 0;
  for (let i = 0; i < RANKS.length; i++) if (xp >= RANKS[i][0]) r = i;
  const next = RANKS[r + 1];
  return {
    rank: r + 1, name: RANKS[r][1], xp, floor: RANKS[r][0],
    next: next ? next[0] : null, nextName: next ? next[1] : null,
  };
}
