// npcs.js — F5b: pedestrians (cartoon characters), walking the sidewalk graph.
// Walkers move node-to-node along SIDEWALKS centrelines and cross roads
// ONLY on CROSSINGS zebras — never in the middle of a road. Bench sitters
// and beach people are placed statically. Ground
// height reuses player.js groundHeightAt. Bodies come from characters.js.

import * as THREE from 'three';
import { LAYOUT, SIDEWALKS, CROSSINGS, DETAILS, ROUNDABOUT, computeIntersections } from './layout.js';
import { buildCharacter, npcSpec, HIP_Y } from './characters.js';
import { groundHeightAt, BOXES, LAKE_BOX, pushOut } from './player.js';

const WALKER_COUNT = 48; // revision 5: busier sidewalks (characters are cheap now)

function flatMat(color) {
  return new THREE.MeshStandardMaterial({ color, flatShading: true, roughness: 0.9 });
}

// ------------------------------------------------------------ sidewalk graph
// Nodes: every SIDEWALKS centreline point + every CROSSINGS zebra centre +
// nodes on the roundabout sidewalk arcs. Edges: consecutive points on a
// strip; strip points from different roads within 7 m (intersection
// corners — opposite sides of a road are >= 11 m apart, so a 7 m link can
// never jump a road); each zebra links the nearest sidewalk node on either
// side of its road; the roundabout ring nodes chain around the arcs and
// join the arm strips via the corner links.
// R4: the old code skipped every node within 24 m of the centre and capped
// zebra links at 12 m, which left the roundabout arm zebras (at 16 m)
// unlinked — the nearest kept node was ~13 m away. The skip is now only
// the circulating circle itself (r < 14 m, where no strip reaches anyway),
// and the ring arcs carry the nodes the arm zebras link to.
export function buildGraph() {
  const nodes = [];
  const [rx, rz] = LAYOUT.roundabout.pos;
  const addNode = (x, z, onRoad) => {
    const n = { x, z, onRoad: !!onRoad, next: [] };
    nodes.push(n);
    return n;
  };
  // Resample a strip centreline at ~10 m so walkers can turn at
  // intersections and every zebra has a sidewalk node nearby (raw strips
  // are just 2-point lines on straight roads — too sparse to link to).
  const resample = (points, closed, step) => {
    const out = [points[0]];
    const n = points.length;
    const count = closed ? n : n - 1;
    for (let i = 0; i < count; i++) {
      const a = points[i];
      const b = points[(i + 1) % n];
      const len = Math.hypot(b[0] - a[0], b[1] - a[1]);
      const k = Math.max(1, Math.floor(len / step));
      for (let j = 1; j <= k; j++) {
        out.push([a[0] + (b[0] - a[0]) * j / k, a[1] + (b[1] - a[1]) * j / k]);
      }
    }
    if (closed && out.length > 1 &&
      Math.hypot(out[out.length - 1][0] - out[0][0], out[out.length - 1][1] - out[0][1]) < 0.01) out.pop();
    return out;
  };
  for (const strip of SIDEWALKS) {
    const road = LAYOUT.roads.find((r) => r.id === strip.roadId);
    let prev = null;
    for (const [x, z] of resample(strip.points, !!(road && road.closed), 10)) {
      // No nodes inside the roundabout's circulating circle (r < 14 m).
      // The arm strips end 15.5 m from the centre, so in practice no
      // strip point is ever skipped — this is purely defensive. A gap
      // breaks the strip so no edge jumps across the roundabout.
      if (Math.hypot(x - rx, z - rz) < ROUNDABOUT.radius) { prev = null; continue; }
      const n = addNode(x, z, false);
      if (prev) { prev.next.push(n); n.next.push(prev); }
      prev = n;
    }
  }
  // Roundabout ring nodes: the sidewalk arcs around the roundabout
  // (inner radius 14 m, outer 17 m — the SAME geometry as roads.js:
  // cylinder convention x = r·sin θ, z = r·cos θ, arms at θ = 0°/90°/
  // 180°/270°, each arc stopping MARGIN (~36°) short of its arm
  // centrelines). Nodes sit on the arc centreline (r 15.5 m), ~2 m
  // apart, chained in order; the corner-link pass below joins each arc
  // end to the nearest arm sidewalk strip (~3 m away), so walkers can
  // go all the way around the roundabout and reach every arm zebra.
  const MARGIN = Math.asin(8 / ROUNDABOUT.radius) + 0.02;
  const midR = ROUNDABOUT.radius + 1.5;
  for (let q = 0; q < 4; q++) {
    const t0 = (q * Math.PI) / 2 + MARGIN;
    const t1 = ((q + 1) * Math.PI) / 2 - MARGIN;
    const arcLen = midR * (t1 - t0);
    const steps = Math.max(1, Math.ceil(arcLen / 2));
    let prev = null;
    for (let j = 0; j <= steps; j++) {
      const t = t0 + ((t1 - t0) * j) / steps;
      const n = addNode(rx + midR * Math.sin(t), rz + midR * Math.cos(t), false);
      if (prev) { prev.next.push(n); n.next.push(prev); }
      prev = n;
    }
  }
  // Corner links between strips (different roads meeting at intersections).
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      const a = nodes[i];
      const b = nodes[j];
      if (Math.hypot(a.x - b.x, a.z - b.z) > 7) continue;
      if (!a.next.includes(b)) { a.next.push(b); b.next.push(a); }
    }
  }
  // Zebra links: nearest sidewalk node on each side of the road.
  for (const c of CROSSINGS) {
    const [cx, cz] = c.position;
    const [dx, dz] = c.direction;
    let bestA = null;
    let bestB = null;
    let dA = Infinity;
    let dB = Infinity;
    for (const n of nodes) {
      if (n.onRoad) continue;
      const d = Math.hypot(n.x - cx, n.z - cz);
      if (d > 12) continue;
      const side = (n.x - cx) * dx + (n.z - cz) * dz;
      if (side >= 0 && d < dA) { dA = d; bestA = n; }
      if (side < 0 && d < dB) { dB = d; bestB = n; }
    }
    if (!bestA || !bestB) continue;
    const z = addNode(cx, cz, true);
    z.next.push(bestA, bestB);
    bestA.next.push(z);
    bestB.next.push(z);
  }
  return nodes;
}

// ------------------------------------------------------------ character mesh
// Stylised cartoon person (characters.js): egg head, big lidded eyes,
// low-poly hair. The look is picked deterministically from the index so
// the crowd is varied (hair, eyes, outfit, skin). Returns
// { group, armL, armR, legL, legR } with shoulder/hip pivots.
function buildPerson(i) {
  const c = buildCharacter(npcSpec(i));
  // Yaw first, then the fall tilt about the body's own x axis.
  c.group.rotation.order = 'YXZ';
  return { group: c.group, armL: c.armL, armR: c.armR, legL: c.legL, legR: c.legR };
}

// ------------------------------------------------------------ NPC behaviours
// States: walk / cross (sidewalk graph), sit / lie / stand (static),
// flee (G3: punched or scared by gunfire — runs away from the threat),
// return (walks back to the nearest graph node after fleeing),
// down (G2/G3: knocked over by the bike or a punch — gets up and flees),
// dead (shot — lies still, then respawns somewhere out of sight).
function makeWalker(scene, nodes, i) {
  const p = buildPerson(i);
  scene.add(p.group);
  // Spawn on a random node that has somewhere to go.
  let node = nodes[Math.floor(Math.random() * nodes.length)];
  while (node.next.length === 0) node = nodes[Math.floor(Math.random() * nodes.length)];
  let next = node.next[Math.floor(Math.random() * node.next.length)];
  const speed = 1.2 + Math.random() * 0.4;
  const w = {
    kind: 'walker',
    mesh: p.group,
    parts: p,
    node,
    next,
    speed,
    phase: Math.random() * Math.PI * 2,
    x: node.x,
    z: node.z,
    heading: 0,
    state: 'walk',
    timer: 0,
    fall: 0,
  };
  p.group.position.set(w.x, groundHeightAt(w.x, w.z), w.z);
  return w;
}

function swingLimbs(w, amp) {
  const s = Math.sin(w.phase) * amp;
  w.parts.armL.rotation.x = s;
  w.parts.armR.rotation.x = -s;
  w.parts.legL.rotation.x = -s;
  w.parts.legR.rotation.x = s;
}

function turnTo(w, dx, dz, dt, rate = 8) {
  const target = Math.atan2(dx, dz);
  let d = target - w.heading;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  w.heading += d * Math.min(1, dt * rate);
}

function stepWalker(w, dt) {
  const dx = w.next.x - w.x;
  const dz = w.next.z - w.z;
  const dist = Math.hypot(dx, dz);
  const move = w.speed * dt;
  if (dist <= Math.max(move, 0.05)) {
    // Arrived: pick a random neighbour, not the one we came from (dead-end
    // strips and the roundabout trims force a turn-around instead).
    const prev = w.node;
    w.node = w.next;
    w.x = w.node.x;
    w.z = w.node.z;
    const options = w.node.next.filter((n) => n !== prev);
    w.next = (options.length ? options : w.node.next)[
      Math.floor(Math.random() * (options.length ? options.length : w.node.next.length))];
    w.state = w.node.onRoad || w.next.onRoad ? 'cross' : 'walk';
    return;
  }
  w.x += (dx / dist) * move;
  w.z += (dz / dist) * move;
  turnTo(w, dx, dz, dt);
  w.phase += dt * w.speed * 4.2;
  swingLimbs(w, 0.55);
  w.mesh.position.set(w.x, groundHeightAt(w.x, w.z), w.z);
  w.mesh.rotation.y = w.heading;
}

const FLEE_SPEED = 4.6;
function stepFlee(w, dt, nodes) {
  w.timer -= dt;
  let dx = w.x - w.threatX;
  let dz = w.z - w.threatZ;
  const d = Math.hypot(dx, dz) || 1;
  dx /= d; dz /= d;
  const pos = { x: w.x + dx * FLEE_SPEED * dt, z: w.z + dz * FLEE_SPEED * dt };
  pushOut(pos, BOXES, LAKE_BOX);
  w.x = pos.x; w.z = pos.z;
  turnTo(w, dx, dz, dt, 12);
  w.phase += dt * FLEE_SPEED * 2.6;
  swingLimbs(w, 0.95);
  w.mesh.position.set(w.x, groundHeightAt(w.x, w.z), w.z);
  w.mesh.rotation.y = w.heading;
  if (w.timer <= 0) {
    // Head back to the nearest sidewalk node, then resume the graph walk.
    let best = null;
    let bd = Infinity;
    for (const n of nodes) {
      if (n.onRoad || n.next.length === 0) continue;
      const dd = Math.hypot(n.x - w.x, n.z - w.z);
      if (dd < bd) { bd = dd; best = n; }
    }
    w.node = best;
    w.next = best;
    w.state = 'return';
  }
}

function stepReturn(w, dt) {
  const dx = w.next.x - w.x;
  const dz = w.next.z - w.z;
  const dist = Math.hypot(dx, dz);
  if (dist < 0.2) {
    w.next = w.node.next[Math.floor(Math.random() * w.node.next.length)];
    w.state = 'walk';
    return;
  }
  const move = Math.min(dist, w.speed * 1.4 * dt);
  const pos = { x: w.x + (dx / dist) * move, z: w.z + (dz / dist) * move };
  pushOut(pos, BOXES, LAKE_BOX);
  w.x = pos.x; w.z = pos.z;
  turnTo(w, dx, dz, dt);
  w.phase += dt * w.speed * 5;
  swingLimbs(w, 0.6);
  w.mesh.position.set(w.x, groundHeightAt(w.x, w.z), w.z);
  w.mesh.rotation.y = w.heading;
}

// Knocked over / shot: the body tips backwards around the feet over
// ~0.35 s and lies flat. Down = gets up after `timer` and flees; dead =
// lies `timer` seconds then respawns out of sight (walkers) or is
// restored to its original pose (sitters / sunbathers / beach people).
function stepDown(w, dt, ctx) {
  w.fall = Math.min(1, w.fall + dt / 0.35);
  w.mesh.rotation.x = -Math.PI / 2 * w.fall;
  w.timer -= dt;
  if (w.timer > 0) return;
  w.mesh.rotation.x = 0;
  w.fall = 0;
  if (w.kind !== 'walker') { restoreHome(w); return; }
  if (w.state === 'dead') { respawnWalker(w, ctx); return; }
  w.state = 'flee';
  w.timer = 6;
}

function restoreHome(w) {
  const h = w.home;
  w.mesh.position.copy(h.pos);
  w.mesh.rotation.copy(h.rot);
  for (const k of ['armL', 'armR', 'legL', 'legR']) w.parts[k].rotation.x = h.limbs[k];
  w.state = h.state;
}

function respawnWalker(w, ctx) {
  const { nodes, player } = ctx;
  const pp = player ? player.position : { x: 0, z: 0 };
  let node = null;
  for (let tries = 0; tries < 60; tries++) {
    const n = nodes[Math.floor(Math.random() * nodes.length)];
    if (n.onRoad || n.next.length === 0) continue;
    node = n;
    if (Math.hypot(n.x - pp.x, n.z - pp.z) > 45) break;
  }
  w.node = node;
  w.next = node.next[Math.floor(Math.random() * node.next.length)];
  w.x = node.x; w.z = node.z;
  w.state = 'walk';
  w.hp = 100;
  w.mesh.rotation.set(0, 0, 0);
  w.mesh.position.set(w.x, groundHeightAt(w.x, w.z), w.z);
}

function rememberHome(n) {
  n.home = {
    pos: n.mesh.position.clone(),
    rot: n.mesh.rotation.clone(),
    limbs: Object.fromEntries(['armL', 'armR', 'legL', 'legR'].map((k) => [k, n.parts[k].rotation.x])),
    state: n.state,
  };
  return n;
}

function makeSitter(scene, bench, i) {
  const p = buildPerson(i);
  scene.add(p.group);
  // Sit on the bench facing away from its backrest. The seat top is
  // 0.55 m above the bench base; the hips rest just above it.
  p.group.position.set(bench.x, groundHeightAt(bench.x, bench.z) + 0.55 + 0.1 - HIP_Y, bench.z);
  p.group.rotation.y = (bench.rot || 0) + Math.PI;
  p.legL.rotation.x = -1.4;
  p.legR.rotation.x = -1.4;
  p.armL.rotation.x = -0.3;
  p.armR.rotation.x = -0.3;
  return rememberHome({ kind: 'sitter', mesh: p.group, parts: p, x: bench.x, z: bench.z, state: 'sit' });
}

function makeSunbather(scene, umbrella, i) {
  const p = buildPerson(i);
  scene.add(p.group);
  const towel = new THREE.Mesh(
    new THREE.BoxGeometry(1.0, 0.05, 2.2),
    flatMat(['#ff5a5a', '#3a86ff', '#ffd23e', '#2ec4b6'][i % 4]),
  );
  const gy = groundHeightAt(umbrella.x, umbrella.z);
  towel.position.set(umbrella.x + 1.5, gy + 0.03, umbrella.z);
  towel.receiveShadow = true;
  scene.add(towel);
  // Lie flat, face up, head toward the north end of the towel.
  p.group.rotation.x = -Math.PI / 2;
  p.group.position.set(umbrella.x + 1.5, gy + 0.22, umbrella.z + 0.9);
  return rememberHome({ kind: 'sunbather', mesh: p.group, parts: p, x: umbrella.x + 1.5, z: umbrella.z, state: 'lie' });
}

function makeBeachStand(scene, x, z, i) {
  const p = buildPerson(i);
  scene.add(p.group);
  p.group.position.set(x, groundHeightAt(x, z), z);
  p.group.rotation.y = Math.PI / 2; // face the sea
  return rememberHome({ kind: 'beach', mesh: p.group, parts: p, x, z, state: 'stand' });
}

// ------------------------------------------------------------------ entry
export function createNPCs(scene, opts = {}) {
  const nodes = buildGraph();
  const npcs = [];
  for (let i = 0; i < WALKER_COUNT; i++) npcs.push(makeWalker(scene, nodes, i));
  const benches = DETAILS.filter((d) => d.type === 'bench').slice(0, 4);
  benches.forEach((b, k) => npcs.push(makeSitter(scene, b, 30 + k)));
  const umbrellas = DETAILS.filter((d) => d.type === 'umbrella').slice(0, 4);
  umbrellas.forEach((u, k) => npcs.push(makeSunbather(scene, u, 34 + k)));
  npcs.push(makeBeachStand(scene, 166, -30, 38));
  npcs.push(makeBeachStand(scene, 168, 12, 39));
  for (const n of npcs) n.hp = 100;
  const ctx = { nodes, player: opts.player || null };

  // Expose positions for verification: each entry carries a live getter.
  const exposed = npcs.map((n) => ({
    kind: n.kind,
    get state() { return n.state; },
    mesh: n.mesh,
    get position() { return n.mesh.position; },
  }));

  const alive = (n) => n.state !== 'down' && n.state !== 'dead';
  const worldXZ = (n) => n.mesh.position;

  // Make an NPC run from (fromX, fromZ). Static NPCs only flinch: sitters
  // and sunbathers have no sidewalk node to return to.
  function scare(n, fromX, fromZ, secs = 6) {
    if (!alive(n) || n.kind !== 'walker') return;
    n.threatX = fromX; n.threatZ = fromZ;
    n.state = 'flee';
    n.timer = Math.max(n.timer || 0, secs);
  }
  // Knock over (bike hit / heavy punch) or kill (gunshot).
  function knock(n, fromX, fromZ, kill = false) {
    if (!alive(n)) return false;
    if (n.kind === 'walker') {
      const p = worldXZ(n);
      n.x = p.x; n.z = p.z;
      // Face the threat so falling backwards falls away from it.
      n.heading = Math.atan2(fromX - p.x, fromZ - p.z);
      n.mesh.rotation.y = n.heading;
      swingLimbs(n, 0);
    } else {
      n.mesh.rotation.copy(n.home.rot);
      n.mesh.position.copy(n.home.pos);
    }
    n.state = kill ? 'dead' : 'down';
    n.timer = kill ? 18 : 3.5;
    n.fall = n.kind === 'sunbather' ? 1 : 0;
    n.threatX = fromX; n.threatZ = fromZ;
    return true;
  }

  return {
    npcs: exposed,
    people: npcs,
    nodes,
    setPlayer(p) { ctx.player = p; },
    alive,
    scare,
    knock,
    // Punch / bullet damage. Returns 'flee' | 'down' | 'dead'.
    damage(n, amount, fromX, fromZ, kind) {
      if (!alive(n)) return null;
      n.hp -= amount;
      if (kind === 'bullet' || n.hp <= 0) { knock(n, fromX, fromZ, true); return 'dead'; }
      if (n.hp <= 40) { knock(n, fromX, fromZ, false); n.hp = 100; return 'down'; }
      scare(n, fromX, fromZ);
      return 'flee';
    },
    // Everyone alive within `radius` of a gunshot runs away from it.
    panic(x, z, radius) {
      for (const n of npcs) {
        const p = worldXZ(n);
        if (Math.hypot(p.x - x, p.z - z) < radius) scare(n, x, z, 7);
      }
    },
    update(dt) {
      for (const w of npcs) {
        if (w.state === 'down' || w.state === 'dead') {
          if (w.kind === 'walker' || w.kind === 'sitter' || w.kind === 'beach' || w.kind === 'sunbather') stepDown(w, dt, ctx);
        } else if (w.kind !== 'walker') continue;
        else if (w.state === 'flee') stepFlee(w, dt, nodes);
        else if (w.state === 'return') stepReturn(w, dt);
        else stepWalker(w, dt);
      }
    },
  };
}
