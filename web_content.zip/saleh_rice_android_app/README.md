# Saleh Rice Traders — Android-ready business manager

This is an installable, mobile-first offline web app (PWA) designed for Android phones. It includes the data imported from `Saleh_Rice_Business_Manager_Expenses_Report_Fixed.xlsm`.

## Included imported workbook data
- Rice varieties and standard purchase costs
- Buyer directory
- Sales Log
- Purchases Log
- Payments Log
- Expenses Log
- Unified Business Log combining sales, purchases, payments and expenses

## Features
- Dashboard totals for sales, receipts, outstanding amounts, expenses and bags sold
- Add new sales, purchases, payments, expenses and buyers
- Combined searchable/filterable business log
- Rice variety stock movement estimate based on recorded purchases minus sales
- JSON backup export/import and business log CSV export
- Offline-capable after first load; app records are stored in browser local storage on the device

## Install on Android
1. Host the contents of this folder on an HTTPS static host (for example, your own website or a static hosting service). PWA install and offline service-worker support require HTTPS or localhost.
2. Open the hosted URL in Chrome on the Android phone.
3. Use Chrome's menu → **Install app** or **Add to Home screen**.
4. Open the installed app. Export backups regularly.

## Run locally for testing
From this folder run a local static server, then open the URL on the same device/network:
`python -m http.server 8080`
Service workers may require HTTPS for installation/offline use.

## Important notes
- This package is not a signed APK. It is a working installable PWA source package; no Android SDK/signing credentials were provided.
- Data is saved on the device/browser that is using the app. It does not automatically synchronize across multiple phones. Use Export full backup and Import backup to move data between devices.
- Existing workbook records are imported as initial data. Check totals against Excel before relying on reports; spreadsheet formulas/macros may not all be replicated.
- The stock estimate uses recorded purchases minus sales; if opening stock was maintained separately in the workbook, add that opening stock separately when validating quantities.
