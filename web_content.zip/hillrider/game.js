(function () {
'use strict';
const cv = document.getElementById('c'), ctx = cv.getContext('2d');
const sky = new Image(); sky.src = 'assets/sky.png';
const lc = document.createElement('canvas'), lx = lc.getContext('2d'); // night light mask
let W = 0, H = 0, sc = 1, DPR = 1;
let settings = { graphics: 2, fps: 60, soundVol: 0.7, musicVol: 0.4, engineOn: true, vibrate: true, camera: 0, sensitivity: 1.0, lang: 0,
  ctrlSize: 1.0, ctrlOpacity: 0.9, ctrlLayout: 0 };
try { Object.assign(settings, JSON.parse(localStorage.getItem('hr_settings') || '{}')); } catch (e) {}
function resize() {
  const maxD = [1, 1.25, 1.75, 2.5][settings.graphics] || 2;
  DPR = Math.min(maxD, window.devicePixelRatio || 1);
  W = innerWidth; H = innerHeight;
  cv.width = W * DPR; cv.height = H * DPR; lc.width = cv.width; lc.height = cv.height; sc = H / 400;
}
addEventListener('resize', resize); resize();

const rnd = n => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
const M = 40;            // world units per metre
const BIOME_LEN = 16000; // 400 m per biome
const VEH = Phys.VEH;
let S, state = 'ready', camX, camY, coins, fuel, best = 0, items, nextGen, idle, got, bank = 0;
let fsPending = 0, nit = 0, nitCap = 60, nitOn = false, sel = 0, own = [0], rv = VEH[0], lastBio = 0;
// Levels & Maps – 50 progressive levels, each 550 m
const NUM_LEVELS = 50;
// 50 unique maps: name, bio index (0-26 cycle with variants), unlockAt level
const MAPS = [
  { id: 0,  name: 'Countryside',       bio: 0,  unlockAt: 0  },
  { id: 1,  name: 'Desert',            bio: 1,  unlockAt: 1  },
  { id: 2,  name: 'Arctic',            bio: 2,  unlockAt: 2  },
  { id: 3,  name: 'Highway',           bio: 3,  unlockAt: 3  },
  { id: 4,  name: 'Cave',              bio: 4,  unlockAt: 4  },
  { id: 5,  name: 'Moon',              bio: 5,  unlockAt: 5  },
  { id: 6,  name: 'Mars',              bio: 6,  unlockAt: 6  },
  { id: 7,  name: 'Forest',            bio: 7,  unlockAt: 7  },
  { id: 8,  name: 'Mountain',          bio: 8,  unlockAt: 8  },
  { id: 9,  name: 'Volcano',           bio: 9,  unlockAt: 9  },
  { id: 10, name: 'Beach',             bio: 10, unlockAt: 10 },
  { id: 11, name: 'Jungle',            bio: 11, unlockAt: 11 },
  { id: 12, name: 'City',              bio: 12, unlockAt: 12 },
  { id: 13, name: 'Night Road',        bio: 13, unlockAt: 13 },
  { id: 14, name: 'Haunted Forest',    bio: 14, unlockAt: 14 },
  { id: 15, name: 'Tropical Island',   bio: 15, unlockAt: 15 },
  { id: 16, name: 'Snow Village',      bio: 16, unlockAt: 16 },
  { id: 17, name: 'Dangerous Jungle',  bio: 17, unlockAt: 17 },
  // --- 32 new levels (18–49) ---
  { id: 18, name: 'Lava Mountain',     bio: 18, unlockAt: 18 },
  { id: 19, name: 'Underwater Tunnel', bio: 19, unlockAt: 19 },
  { id: 20, name: 'Ghost Valley',      bio: 20, unlockAt: 20 },
  { id: 21, name: 'Grand Canyon',      bio: 21, unlockAt: 21 },
  { id: 22, name: 'Airport Runway',    bio: 22, unlockAt: 22 },
  { id: 23, name: 'Industrial City',   bio: 23, unlockAt: 23 },
  { id: 24, name: 'Green Valley',      bio: 24, unlockAt: 24 },
  { id: 25, name: 'Sky Island',        bio: 25, unlockAt: 25 },
  { id: 26, name: 'Railway Mountain',  bio: 26, unlockAt: 26 },
  { id: 27, name: 'Storm Plains',      bio: 0,  unlockAt: 27 },
  { id: 28, name: 'Sand Dunes',        bio: 1,  unlockAt: 28 },
  { id: 29, name: 'Glacier Pass',      bio: 2,  unlockAt: 29 },
  { id: 30, name: 'Night Highway',     bio: 3,  unlockAt: 30 },
  { id: 31, name: 'Crystal Cave',      bio: 4,  unlockAt: 31 },
  { id: 32, name: 'Lunar Crater',      bio: 5,  unlockAt: 32 },
  { id: 33, name: 'Red Canyon',        bio: 6,  unlockAt: 33 },
  { id: 34, name: 'Deep Forest',       bio: 7,  unlockAt: 34 },
  { id: 35, name: 'Alpine Ridge',      bio: 8,  unlockAt: 35 },
  { id: 36, name: 'Ash Fields',        bio: 9,  unlockAt: 36 },
  { id: 37, name: 'Coral Coast',       bio: 10, unlockAt: 37 },
  { id: 38, name: 'Rainforest',        bio: 11, unlockAt: 38 },
  { id: 39, name: 'Neon City',         bio: 12, unlockAt: 39 },
  { id: 40, name: 'Midnight Run',      bio: 13, unlockAt: 40 },
  { id: 41, name: 'Cursed Woods',      bio: 14, unlockAt: 41 },
  { id: 42, name: 'Palm Atoll',        bio: 15, unlockAt: 42 },
  { id: 43, name: 'Frozen Lake',       bio: 16, unlockAt: 43 },
  { id: 44, name: 'Viper Jungle',      bio: 17, unlockAt: 44 },
  { id: 45, name: 'Magma Peak',        bio: 18, unlockAt: 45 },
  { id: 46, name: 'Abyss Tunnel',      bio: 19, unlockAt: 46 },
  { id: 47, name: 'Spirit Gorge',      bio: 20, unlockAt: 47 },
  { id: 48, name: 'Mesa Trail',        bio: 21, unlockAt: 48 },
  { id: 49, name: 'Final Summit',      bio: 26, unlockAt: 49 }
];
let selMap = 0, selLevel = 1, completed = 0, levelTarget = 150;
try { best = +localStorage.getItem('hr_best') || 0; bank = +localStorage.getItem('hr_coins') || 0; } catch (e) {}
try {
  completed = +localStorage.getItem('hr_completed') || 0;
  selMap = +localStorage.getItem('hr_map') || 0;
  selLevel = +localStorage.getItem('hr_level') || 1;
  if (selLevel < 1) selLevel = 1; if (selLevel > NUM_LEVELS) selLevel = NUM_LEVELS;
  if (!MAPS[selMap] || completed < MAPS[selMap].unlockAt) selMap = 0;
} catch (e) {}
const keys = {}, ptr = new Map(), nptr = new Set();
const UP = [['Engine', 'eng'], ['Tires', 'tire'], ['Brake', 'brake'], ['Suspension', 'susp'], ['Fuel', 'tank'], ['Nitro', 'nit']], MAXL = 6;
let lv = { eng: 0, tire: 0, susp: 0, tank: 0, nit: 0, brake: 0 }, parts = [], pops = [], airT = 0, rot = 0, cap = 100, wasAir = false, overT = 0;
let garagePage = 0;
const CARS_PER_PAGE = 8;
let mapPage = 0;
let levelPage = 0;
const LEVELS_PER_PAGE = 15; // 5×3 grid
const MAPS_PER_PAGE = 15; // 5×3 grid
// Swipe controls for garage vehicle selection
let swipe = { active: false, startX: 0, startY: 0, dx: 0, dy: 0, moved: false, id: null };
let slideX = 0;          // current visual offset (px)
let slideTarget = 0;     // target offset for animation
let slideAnimating = false;
const SWIPE_THRESH = 40; // min horizontal px to count as swipe
const TAP_SLOP = 14;     // max movement still considered a tap
try { Object.assign(lv, JSON.parse(localStorage.getItem('hr_lv') || '{}')); } catch (e) {}
try {
  const o = JSON.parse(localStorage.getItem('hr_own') || '[0]');
  if (Array.isArray(o)) own = o.filter(i => VEH[i]);
  if (!own.includes(0)) own.push(0);
  sel = +localStorage.getItem('hr_car') || 0; if (!own.includes(sel)) sel = 0;
} catch (e) {}
// Driver characters (male / female variants) – canvas layered characters for mobile performance
const DRIVERS = [
  { id: 0, name: 'Alex',   gender: 'male',   skin: '#e0b090', hair: '#3d2314', shirt: '#2b4fa0', pants: '#1a1a2e', price: 0 },
  { id: 1, name: 'Maya',   gender: 'female', skin: '#d4a574', hair: '#1a1a1a', shirt: '#e03131', pants: '#343a40', price: 0 },
  { id: 2, name: 'Jake',   gender: 'male',   skin: '#c68642', hair: '#0d0d0d', shirt: '#2f9e44', pants: '#212529', price: 500 },
  { id: 3, name: 'Sofia',  gender: 'female', skin: '#f0c8a0', hair: '#8b4513', shirt: '#7048e8', pants: '#2b1a6b', price: 500 },
  { id: 4, name: 'Ryan',   gender: 'male',   skin: '#f5d0a9', hair: '#ffd43b', shirt: '#e67700', pants: '#495057', price: 800 },
  { id: 5, name: 'Lina',   gender: 'female', skin: '#8d5524', hair: '#2c1810', shirt: '#15aabf', pants: '#1a1b1e', price: 800 }
];
let selDriver = 0, ownDrivers = [0, 1];
try {
  selDriver = +localStorage.getItem('hr_driver') || 0;
  const od = JSON.parse(localStorage.getItem('hr_own_drv') || '[0,1]');
  if (Array.isArray(od)) ownDrivers = od.filter(i => DRIVERS[i]);
  if (!ownDrivers.includes(0)) ownDrivers.push(0);
  if (!ownDrivers.includes(selDriver)) selDriver = 0;
} catch (e) {}
const cost = l => Math.round(150 * Math.pow(1.8, l));
function save() { try { localStorage.setItem('hr_best', best); localStorage.setItem('hr_coins', bank);
  localStorage.setItem('hr_lv', JSON.stringify(lv)); localStorage.setItem('hr_own', JSON.stringify(own)); localStorage.setItem('hr_car', sel);
  localStorage.setItem('hr_completed', completed); localStorage.setItem('hr_map', selMap); localStorage.setItem('hr_level', selLevel);
  localStorage.setItem('hr_driver', selDriver); localStorage.setItem('hr_own_drv', JSON.stringify(ownDrivers)); } catch (e) {} }

// ---------- Settings helpers (free upgrade) ----------
function saveSettings() {
  try { localStorage.setItem('hr_settings', JSON.stringify(settings)); } catch (e) {}
}
const LANG = {
  0: { settings: 'SETTINGS', resume: 'RESUME', restart: 'RESTART', menu: 'MAIN MENU', graphics: 'Graphics', fps: 'FPS', sound: 'Sound', music: 'Music', engine: 'Engine Sound', vibrate: 'Vibration', camera: 'Camera', sens: 'Sensitivity', lang: 'Language', on: 'ON', off: 'OFF', low: 'Low', med: 'Medium', high: 'High', ultra: 'Ultra', normal: 'Normal', far: 'Far', close: 'Close', lowcam: 'Low',
    ctrlSize: 'Control Size', ctrlOpac: 'Button Opacity', ctrlLayout: 'Control Layout', resetCtrl: 'RESET CONTROLS', classic: 'Classic', wide: 'Wide', compact: 'Compact', high: 'High' },
  1: { settings: 'सेटिंग्स', resume: 'जारी रखें', restart: 'रीस्टार्ट', menu: 'मुख्य मेनू', graphics: 'ग्राफिक्स', fps: 'FPS', sound: 'ध्वनि', music: 'संगीत', engine: 'इंजन साउंड', vibrate: 'वाइब्रेशन', camera: 'कैमरा', sens: 'संवेदनशीलता', lang: 'भाषा', on: 'चालू', off: 'बंद', low: 'कम', med: 'मध्यम', high: 'उच्च', ultra: 'अल्ट्रा', normal: 'सामान्य', far: 'दूर', close: 'पास', lowcam: 'निचला' },
  2: { settings: 'ସେଟିଂସ', resume: 'ଜାରି ରଖନ୍ତୁ', restart: 'ରିଷ୍ଟାର୍ଟ', menu: 'ମୁଖ୍ୟ ମେନୁ', graphics: 'ଗ୍ରାଫିକ୍ସ', fps: 'FPS', sound: 'ସାଉଣ୍ଡ', music: 'ସଙ୍ଗୀତ', engine: 'ଇଞ୍ଜିନ ସାଉଣ୍ଡ', vibrate: 'ଭାଇବ୍ରେସନ', camera: 'କ୍ୟାମେରା', sens: 'ସେନ୍ସିଟିଭିଟି', lang: 'ଭାଷା', on: 'ଚାଲୁ', off: 'ବନ୍ଦ', low: 'କମ', med: 'ମଧ୍ୟମ', high: 'ଉଚ୍ଚ', ultra: 'ଅଲ୍ଟ୍ରା', normal: 'ସାଧାରଣ', far: 'ଦୂର', close: 'ନିକଟ', lowcam: 'ତଳ' }
};
function L() { return LANG[settings.lang] || LANG[0]; }
function vibrate(ms) {
  if (!settings.vibrate) return;
  try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {}
}
let frameSkip = 0, lastFrameDraw = 0;
const hit = (r, x, y) => r && x >= r[0] && x <= r[0] + r[2] && y >= r[1] && y <= r[1] + r[3];
// Reliable touch/mouse coordinates for mobile fullscreen (handles visualViewport offset)
function ptrXY(e) {
  let x = e.clientX, y = e.clientY;
  try {
    if (window.visualViewport) {
      // Some Android fullscreen modes report client coords relative to layout viewport
      // while canvas is sized to visual viewport – normalize when offset is significant
      const vv = window.visualViewport;
      if (Math.abs(vv.offsetLeft) > 0.5 || Math.abs(vv.offsetTop) > 0.5) {
        x = e.clientX - vv.offsetLeft;
        y = e.clientY - vv.offsetTop;
      }
    }
  } catch (err) {}
  return { x, y };
}
function levelTargetM(lvl) { return 550; } // every level requires 550 m

// ---------- biomes / maps (15 unique environments) ----------
const hx = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
// colour order: 0 skyTop 1 skyBottom 2 hill1 3 hill2 4 dirt 5 crater1 6 crater2 7 crater3 8 edge 9 surfaceDark 10 surfaceLight 11 tuft1 12 tuft2
// weather: none | rain | snow | dust | ash | fog | leaves
const BIO = [
  { n: 'Countryside', night: 0,   snow: 0,   mu: 1.00, weather: 'none',   c: ['#1eb5fe','#8ee6ff','#7fd4c1','#5fc486','#6b3913','#4f2a0d','#7b4520','#8a5128','#5a2d0e','#3f8f00','#a6f000','#4c9a00','#3d8a00'] },
  { n: 'Desert',      night: 0,   snow: 0,   mu: 0.88, weather: 'dust',   c: ['#f6a93b','#ffe2a0','#e9b96e','#d99f4f','#c28a45','#a8742f','#cf9a57','#daa965','#9c6b2a','#d9a441','#f3cf74','#b88a2f','#a97b25'] },
  { n: 'Arctic',      night: 0.15,snow: 1,   mu: 0.72, weather: 'snow',   c: ['#8fb8e8','#e6f2ff','#cfe3f5','#b4d2ee','#7d8aa0','#5f6b82','#94a1b8','#a7b3c8','#aab6c9','#dfeaf5','#ffffff','#c5d6e8','#b3c8de'] },
  { n: 'Highway',     night: 0,   snow: 0,   mu: 1.08, weather: 'none',   c: ['#6ec6ff','#c8e8ff','#8a9aaa','#6a7a88','#4a4a4a','#3a3a3a','#5a5a5a','#6a6a6a','#2a2a2a','#5a5a5a','#7a7a7a','#3a3a3a','#2a2a2a'] },
  { n: 'Cave',        night: 0.85,snow: 0,   mu: 0.95, weather: 'none',   c: ['#1a1520','#2a2535','#3a3545','#2a2a38','#4a3a2a','#3a2a1a','#5a4a3a','#6a5a4a','#2a1a10','#3a4a3a','#4a5a4a','#2a3a2a','#1a2a1a'] },
  { n: 'Moon',        night: 0.9, snow: 0,   mu: 0.55, weather: 'none',   c: ['#0a0a18','#1a1a30','#6a6a7a','#5a5a6a','#8a8a9a','#6a6a7a','#9a9aaa','#aaaaba','#5a5a6a','#9a9aaa','#babaca','#7a7a8a','#6a6a7a'] },
  { n: 'Mars',        night: 0.3, snow: 0,   mu: 0.82, weather: 'dust',   c: ['#c45a2a','#e89a5a','#c07040','#a05830','#8a4020','#6a3018','#a05030','#b06040','#5a2810','#b06030','#d08050','#904020','#803018'] },
  { n: 'Forest',      night: 0.1, snow: 0,   mu: 0.96, weather: 'leaves', c: ['#4a8a40','#8aba70','#3a6a30','#2a5a20','#4a3020','#3a2010','#5a4030','#6a5040','#2a1808','#2a6a18','#4a9a28','#1a5a10','#0a4a08'] },
  { n: 'Mountain',    night: 0,   snow: 0.35,mu: 0.90, weather: 'none',   c: ['#6aa0d0','#c0d8f0','#7a8a9a','#5a6a7a','#6a5a4a','#4a3a2a','#7a6a5a','#8a7a6a','#3a2a1a','#8a9aaa','#c0d0e0','#6a7a8a','#5a6a7a'] },
  { n: 'Volcano',     night: 0.4, snow: 0,   mu: 0.85, weather: 'ash',    c: ['#2a1010','#5a2020','#4a2a2a','#3a1a1a','#3a2a2a','#2a1a1a','#5a3a3a','#6a4a4a','#1a0a0a','#4a3030','#6a4040','#3a2020','#2a1010'] },
  { n: 'Beach',       night: 0,   snow: 0,   mu: 0.78, weather: 'none',   c: ['#40b0e8','#a0e0ff','#e8d0a0','#d0b880','#d0c090','#b0a070','#e0d0a0','#f0e0b0','#a09060','#e8d8a8','#f8f0c8','#c8b888','#b8a878'] },
  { n: 'Jungle',      night: 0.2, snow: 0,   mu: 0.94, weather: 'rain',   c: ['#1a4a20','#3a7a40','#1a5a18','#0a4a10','#3a2810','#2a1808','#4a3820','#5a4830','#1a1005','#1a6a12','#2a9a22','#0a5a08','#004a00'] },
  { n: 'City',        night: 0.25,snow: 0,   mu: 1.05, weather: 'none',   c: ['#5a7a9a','#a0b8d0','#6a7a8a','#4a5a6a','#4a4a52','#3a3a42','#5a5a62','#6a6a72','#2a2a32','#5a5a62','#7a7a82','#3a3a42','#2a2a32'] },
  { n: 'Night Road',  night: 1,   snow: 0,   mu: 1.00, weather: 'none',   c: ['#0a1030','#1a2848','#2b3f6e','#1f3a5a','#3a2410','#2a190a','#4a2f17','#573a1e','#2a1608','#2a4a18','#4a7a28','#1a3a10','#0a2a08'] },
  { n: 'Haunted',     night: 0.95,snow: 0,   mu: 0.90, weather: 'fog',    c: ['#0a0a14','#1a1a28','#2a2a3a','#1a1a28','#2a2a20','#1a1a14','#3a3a30','#4a4a40','#12120c','#1a2a1a','#2a4a2a','#0a1a0a','#051005'] },
  // --- 12 new unique biomes ---
  { n: 'Tropical',    night: 0,   snow: 0,   mu: 0.86, weather: 'none',   c: ['#20c0e8','#90e8ff','#30c090','#20a070','#d0b878','#b09858','#e0c888','#f0d898','#a08848','#e8d890','#f8e8a8','#c8b878','#b8a868'] },
  { n: 'SnowVillage', night: 0.2, snow: 1,   mu: 0.70, weather: 'snow',   c: ['#a0c8f0','#e8f4ff','#d0e4f8','#b8d0e8','#c8d0d8','#a8b0b8','#d8e0e8','#e8f0f8','#b8c0c8','#f0f4f8','#ffffff','#d0d8e0','#c0c8d0'] },
  { n: 'DangJungle',  night: 0.35,snow: 0,   mu: 0.92, weather: 'rain',   c: ['#0a3020','#1a5030','#0a4020','#053018','#2a2010','#1a1008','#3a3020','#4a4030','#100805','#0a5010','#1a7020','#054008','#003000'] },
  { n: 'LavaMount',   night: 0.5, snow: 0,   mu: 0.80, weather: 'ash',    c: ['#3a1018','#6a2028','#5a2830','#4a1820','#4a2a28','#3a1a18','#6a3a38','#7a4a48','#2a0a08','#5a3030','#7a4040','#3a1818','#2a1010'] },
  { n: 'Underwater',  night: 0.55,snow: 0,   mu: 0.75, weather: 'none',   c: ['#0a2850','#1a4880','#0a3860','#052840','#1a3a50','#0a2a40','#2a4a60','#3a5a70','#0a1a30','#1a4a60','#2a6a80','#0a3a50','#052a40'] },
  { n: 'GhostValley', night: 0.9, snow: 0,   mu: 0.88, weather: 'fog',    c: ['#101018','#202030','#2a2a40','#1a1a28','#2a2a28','#1a1a18','#3a3a38','#4a4a48','#121210','#2a3a2a','#3a5a3a','#1a2a1a','#0a1a0a'] },
  { n: 'GrandCanyon', night: 0.05,snow: 0,   mu: 0.95, weather: 'dust',   c: ['#e89050','#f8c890','#d07040','#b05830','#a05030','#804028','#c06840','#d07850','#603020','#c06838','#e08858','#a05028','#904020'] },
  { n: 'Airport',     night: 0.1, snow: 0,   mu: 1.12, weather: 'none',   c: ['#70b0e0','#c0e0f8','#8a98a8','#6a7888','#5a5a62','#4a4a52','#6a6a72','#7a7a82','#3a3a42','#6a6a72','#8a8a92','#4a4a52','#3a3a42'] },
  { n: 'Industrial',  night: 0.3, snow: 0,   mu: 1.02, weather: 'dust',   c: ['#5a6878','#8a98a8','#4a5868','#3a4858','#4a4a48','#3a3a38','#5a5a58','#6a6a68','#2a2a28','#5a5a58','#7a7a78','#3a3a38','#2a2a28'] },
  { n: 'GreenValley', night: 0,   snow: 0,   mu: 1.00, weather: 'leaves', c: ['#48b0f0','#a0e0ff','#60c870','#40a850','#5a3820','#3a2810','#6a4830','#7a5840','#2a1808','#30a030','#50c850','#208020','#106010'] },
  { n: 'SkyIsland',   night: 0,   snow: 0,   mu: 0.92, weather: 'none',   c: ['#60a8f0','#b0d8ff','#90c0e8','#70a0d0','#c8d0a0','#a8b080','#d8e0b0','#e8f0c0','#889060','#d0d890','#e8f0b0','#b0b870','#a0a860'] },
  { n: 'RailwayMtn',  night: 0.15,snow: 0.2, mu: 0.98, weather: 'none',   c: ['#6890b8','#b0c8e0','#6a7a8a','#4a5a6a','#5a4a3a','#3a2a1a','#6a5a4a','#7a6a5a','#2a1a10','#6a7a8a','#9aaaba','#4a5a6a','#3a4a5a'] }
];
BIO.forEach(b => { b.rgb = b.c.map(hx); });
const cur = { col: [], night: 0, snow: 0, mu: 1, i: 0, weather: 'none', name: '' };
function updBio(x) {
  // Each selected map uses its own fixed biome (fully playable unique environment)
  const bi = MAPS[selMap] ? MAPS[selMap].bio : 0;
  const a = BIO[bi] || BIO[0];
  cur.col = a.c.map((h, j) => {
    // slight distance tint so long runs still feel alive
    const rgb = a.rgb[j];
    const pulse = 1 + Math.sin((x - Phys.P.start) * 0.00015 + j) * 0.03;
    return 'rgb(' + Math.round(rgb[0] * pulse) + ',' + Math.round(rgb[1] * pulse) + ',' + Math.round(rgb[2] * pulse) + ')';
  });
  cur.night = a.night; cur.snow = a.snow;
  // Slightly lower grip on higher levels for progressive challenge
  const gripScale = Math.max(0.78, 1 - (selLevel - 1) * 0.0035);
  cur.mu = a.mu * gripScale; cur.i = bi;
  cur.weather = a.weather; cur.name = a.n;
}
updBio(0);

// ---------- layout / UI ----------
function layout() {
  const pw = Math.min(W * 0.96, 920), x0 = (W - pw) / 2;
  const cols = 4, rows = 2;
  // Vehicle grid BELOW the large showcase so selected car is never covered
  const vw = (pw - 36) / cols, vh = H * 0.085, vy0 = H * 0.56;
  const start = garagePage * CARS_PER_PAGE;
  const pageVeh = [];
  for (let i = 0; i < CARS_PER_PAGE; i++) {
    const idx = start + i;
    if (idx >= VEH.length) break;
    const col = i % cols, row = Math.floor(i / cols);
    pageVeh.push({ idx, r: [x0 + col * (vw + 8), vy0 + row * (vh + 4), vw, vh] });
  }
  const dy = H * 0.745, dw = (pw - 40) / DRIVERS.length, dh = H * 0.055;
  const drivers = DRIVERS.map((d, i) => [x0 + i * (dw + 6), dy, dw, dh]);
  const cw = (pw - 50) / UP.length, ch = H * 0.09, y0 = H * 0.81;
  const maxPage = Math.max(0, Math.ceil(VEH.length / CARS_PER_PAGE) - 1);
  return {
    cars: pageVeh,
    drivers,
    cards: UP.map((u, i) => [x0 + i * (cw + 8), y0, cw, ch]),
    btn: [W / 2 - pw * 0.14, H * 0.915, pw * 0.28, H * 0.065],
    home: [W * 0.02, H * 0.012, Math.max(64, W * 0.11), H * 0.055],
    prev: [x0, H * 0.012, 70, H * 0.05],
    next: [x0 + pw - 70, H * 0.012, 70, H * 0.05],
    maxPage
  };
}
function homeLay() {
  const bw = Math.min(W * 0.34, 360), cx = W / 2;
  return {
    play: [cx - bw / 2, H * 0.42, bw, H * 0.14],
    maps: [cx - bw / 2, H * 0.58, bw * 0.48, H * 0.10],
    garage: [cx + bw / 2 - bw * 0.48, H * 0.58, bw * 0.48, H * 0.10],
    full: [cx - bw / 2, H * 0.71, bw, H * 0.09]
  };
}
function mapsLay() {
  const pw = Math.min(W * 0.96, 900), x0 = (W - pw) / 2;
  const cols = 5, rows = 3;
  const mw = (pw - (cols - 1) * 8) / cols, mh = H * 0.105, my = H * 0.125;
  const start = mapPage * MAPS_PER_PAGE;
  const maps = [];
  for (let i = 0; i < MAPS_PER_PAGE; i++) {
    const idx = start + i;
    if (idx >= MAPS.length) break;
    const col = i % cols, row = Math.floor(i / cols);
    maps.push({ idx, r: [x0 + col * (mw + 8), my + row * (mh + 4), mw, mh] });
  }
  const maxMapPage = Math.max(0, Math.ceil(MAPS.length / MAPS_PER_PAGE) - 1);
  // Level grid: 5×3, paginated across all 50 levels
  const lcols = 5;
  const lw = (pw - (lcols - 1) * 6) / lcols, lh = H * 0.07, ly = H * 0.52;
  const lvlStart = levelPage * LEVELS_PER_PAGE;
  const levels = [];
  for (let i = 0; i < LEVELS_PER_PAGE; i++) {
    const lvl = lvlStart + i + 1;
    if (lvl > NUM_LEVELS) break;
    const col = i % lcols, row = Math.floor(i / lcols);
    levels.push({ lvl, r: [x0 + col * (lw + 6), ly + row * (lh + 4), lw, lh] });
  }
  const maxLevelPage = Math.max(0, Math.ceil(NUM_LEVELS / LEVELS_PER_PAGE) - 1);
  return {
    maps,
    maxMapPage,
    levels,
    maxLevelPage,
    back: [W * 0.02, H * 0.01, Math.max(64, W * 0.11), H * 0.055],
    prev: [x0, H * 0.01, 56, H * 0.05],
    next: [x0 + pw - 56, H * 0.01, 56, H * 0.05],
    lvlPrev: [x0, H * 0.465, 56, H * 0.045],
    lvlNext: [x0 + pw - 56, H * 0.465, 56, H * 0.045],
    start: [W / 2 - pw * 0.16, H * 0.90, pw * 0.32, H * 0.065]
  };
}
const isFull = () => !!(document.fullscreenElement || document.webkitFullscreenElement);
function goFull(toggle) {
  try {
    const d = document.documentElement;
    if (isFull()) { if (toggle) (document.exitFullscreen || document.webkitExitFullscreen).call(document); return; }
    const rq = d.requestFullscreen || d.webkitRequestFullscreen; if (!rq) return;
    const lock = () => { try { screen.orientation && screen.orientation.lock && screen.orientation.lock('landscape').catch(() => {}); } catch (e) {} };
    const r = rq.call(d, { navigationUI: 'hide' }); if (r && r.then) r.then(lock).catch(() => {}); else lock();
  } catch (e) {}
}
function geo() {
  const u = Math.max(14, H / 28);
  const size = Math.max(0.65, Math.min(1.45, settings.ctrlSize || 1));
  const layout = settings.ctrlLayout | 0;
  // Safe-area inset (notch / status bar) – keep HUD buttons reachable in fullscreen
  let safeTop = 0, safeBottom = 0, safeLeft = 0, safeRight = 0;
  try {
    const cs = getComputedStyle(document.documentElement);
    safeTop = parseFloat(cs.getPropertyValue('env(safe-area-inset-top)')) || 0;
    safeBottom = parseFloat(cs.getPropertyValue('env(safe-area-inset-bottom)')) || 0;
    safeLeft = parseFloat(cs.getPropertyValue('env(safe-area-inset-left)')) || 0;
    safeRight = parseFloat(cs.getPropertyValue('env(safe-area-inset-right)')) || 0;
  } catch (e) {}
  // Fallback: give a few px on landscape phones when inset env is 0
  if (safeTop < 4 && H < W) safeTop = 6;

  // Base pedal dimensions – large premium feel
  let ph = H * (0.26 + 0.04 * size) * size;
  let pw = Math.min(W * (0.18 + 0.03 * size), ph * 0.95) * size;
  // Layout presets: 0 Classic corners, 1 Wide, 2 Compact, 3 High
  let marginX = u * 0.7 + safeLeft * 0.5, marginY = u * 0.55 + safeBottom * 0.5;
  if (layout === 1) { marginX = u * 0.35 + safeLeft * 0.3; pw *= 1.08; }
  else if (layout === 2) { marginX = u * 1.4; ph *= 0.92; pw *= 0.92; }
  else if (layout === 3) { marginY = u * 1.15 + safeBottom * 0.3; }
  const brakeRect = [marginX, H - ph - marginY, pw, ph];
  const gasRect   = [W - pw - marginX - safeRight * 0.3, H - ph - marginY, pw, ph];
  const r = Math.min(ph * 0.36, W * 0.085);
  // Larger touch-friendly HUD buttons (min ~48px)
  const btn = Math.max(48, Math.min(u * 3.2, H * 0.14));
  const sideR = Math.min(u * 1.8, 42);
  const topY = safeTop + Math.max(6, u * 0.35);
  return {
    u, ph, pw, size, layout, safeTop, safeBottom,
    brake: brakeRect, gas: gasRect,
    pause: [W / 2 - btn - u * 0.45, topY, btn, btn],
    settings: [W / 2 + u * 0.45, topY, btn, btn],
    nit: { x: W / 2, y: H - u - r - safeBottom * 0.3, r },
    horn: { x: W / 2 - r * 2.2, y: H - u - r - safeBottom * 0.3, r: sideR },
    lights: { x: W / 2 + r * 2.2, y: H - u - r - safeBottom * 0.3, r: sideR }
  };
}

// --- Horn / Headlights / Crash Replay state ---
let hornOn = false, lightsOn = false, lightsAuto = true;
let hornOsc = null, hornGain = null;
const REPLAY_BUF = 90; // ~0.75s at 120Hz stored as samples
let replayBuf = [], replayIdx = 0, replayCam = 0, replayT = 0;
let wasCrashed = false;
function uiTap(x, y) {
  if (H > W) return;
  if (state === 'home') { const h = homeLay();
    if (hit(h.play, x, y)) { fsPending = 'enter'; reset(); state = 'play'; blip(800, 0.12); }
    else if (hit(h.maps, x, y)) { state = 'maps'; blip(700, 0.1); }
    else if (hit(h.garage, x, y)) { state = 'ready'; blip(700, 0.1); }
    else if (hit(h.full, x, y)) fsPending = 'toggle';
    return; }
  if (state === 'maps') {
    const L = mapsLay();
    if (hit(L.back, x, y)) { state = 'home'; blip(600, 0.08); return; }
    if (L.prev && hit(L.prev, x, y) && mapPage > 0) { mapPage--; blip(600, 0.08); return; }
    if (L.next && hit(L.next, x, y) && mapPage < L.maxMapPage) { mapPage++; blip(600, 0.08); return; }
    if (L.lvlPrev && hit(L.lvlPrev, x, y) && levelPage > 0) { levelPage--; blip(600, 0.08); return; }
    if (L.lvlNext && hit(L.lvlNext, x, y) && levelPage < L.maxLevelPage) { levelPage++; blip(600, 0.08); return; }
    L.maps.forEach(item => {
      if (!hit(item.r, x, y)) return;
      const i = item.idx;
      if (completed >= MAPS[i].unlockAt) { selMap = i; save(); blip(900, 0.1); }
      else blip(150, 0.1);
    });
    L.levels.forEach(item => {
      if (!hit(item.r, x, y)) return;
      const lvl = item.lvl;
      if (lvl <= completed + 1) {
        selLevel = lvl;
        // Auto-select matching map environment for this level
        if (MAPS[lvl - 1] && completed >= MAPS[lvl - 1].unlockAt) selMap = lvl - 1;
        save(); blip(850, 0.1);
      } else blip(150, 0.1);
    });
    if (hit(L.start, x, y)) { reset(); state = 'play'; blip(800, 0.12); }
    return;
  }
  if (state === 'pause') { state = 'play'; return; }
  if (state === 'settings') { settingsTap(x, y); return; }
  if (state === 'celebrate') return; // wait for celebration to finish
  if (state === 'win') {
    if (overT < 0.25) return;
    const n = drawWinScreen._next, r = drawWinScreen._replay, m = drawWinScreen._menu;
    if (n && hit(n, x, y)) {
      if (selLevel < NUM_LEVELS) {
        selLevel++;
        if (MAPS[selLevel - 1] && completed >= MAPS[selLevel - 1].unlockAt) selMap = selLevel - 1;
        save();
      }
      reset(); state = 'play'; blip(900, 0.12); return;
    }
    if (r && hit(r, x, y)) { reset(); state = 'play'; blip(800, 0.12); return; }
    if (m && hit(m, x, y)) { reset(); state = 'home'; blip(600, 0.1); return; }
    return;
  }
  if (state === 'over' && overT < 0.4) return;
  const L = layout();
  if (hit(L.home, x, y)) { reset(); state = 'home'; return; }
  if (L.prev && hit(L.prev, x, y) && garagePage > 0) { garagePage--; blip(600, 0.08); return; }
  if (L.next && hit(L.next, x, y) && garagePage < L.maxPage) { garagePage++; blip(600, 0.08); return; }
  L.cars.forEach(item => {
    if (!hit(item.r, x, y)) return;
    const i = item.idx, v = VEH[i];
    if (own.includes(i)) { sel = i; save(); blip(900, 0.1); if (state === 'ready') reset(); }
    else if (bank >= v.price) { bank -= v.price; own.push(i); sel = i; save(); blip(1000, 0.2); if (state === 'ready') reset(); }
    else blip(150, 0.1);
  });
  if (L.drivers) L.drivers.forEach((r, i) => {
    if (!hit(r, x, y)) return;
    const d = DRIVERS[i];
    if (ownDrivers.includes(i)) { selDriver = i; save(); blip(900, 0.1); }
    else if (bank >= d.price) { bank -= d.price; ownDrivers.push(i); selDriver = i; save(); blip(1000, 0.2); }
    else blip(150, 0.1);
  });
  L.cards.forEach((r, i) => { if (!hit(r, x, y)) return; const k = UP[i][1], l = lv[k] || 0;
    if (l < MAXL && bank >= cost(l)) { bank -= cost(l); lv[k] = l + 1; save(); blip(800, 0.15); } else blip(150, 0.1); });
  if (hit(L.btn, x, y)) {
    reset(); state = 'play';
  }
}
function pop(s, n) { coins += n; pops.push({ s, t: 2.2 }); blip(700, 0.2); }
function landing() {
  vibrate(S.crashed ? 40 : 18);
  if (S.crashed) { airT = 0; rot = 0; return; }
  const f = Math.sign(rot) * Math.floor(Math.abs(rot) / (2 * Math.PI) + 0.25);
  if (airT > 0.8) pop('AIR TIME +' + Math.round(airT * 10), Math.round(airT * 10));
  if (f) { pop((f > 0 ? 'BACK' : 'FRONT') + ' FLIP' + (Math.abs(f) > 1 ? ' x' + Math.abs(f) : '') + ' +' + Math.abs(f) * 100, Math.abs(f) * 100);
    nit = Math.min(nitCap, nit + 25 * Math.abs(f)); }
  airT = 0; rot = 0;
}
let gas = false, brake = false;
let gasPress = 0, brakePress = 0; // 0..1 smooth press animation
const ptrPos = new Map(); // pointerId -> {x,y} for precise multitouch

let finishTriggered = false, celebT = 0, celebParts = [], winReward = 0, winCoins = 0;
function finishWorldX() { return Phys.P.start + levelTarget * M; }

function reset() {
  rv = VEH[sel]; Phys.setLevels(lv, rv); cap = 100 + 25 * lv.tank; nitCap = 60 + 20 * lv.nit; nit = nitCap;
  // Progressive difficulty: steeper / sharper terrain as level rises (1.0 → ~1.65)
  if (Phys.setDifficulty) Phys.setDifficulty(1 + (selLevel - 1) * 0.013);
  parts = []; pops = []; airT = 0; rot = 0; wasAir = false; lastBio = -1;
  S = Phys.create(); camX = S.x + 150; camY = S.y + 60; coins = 0; fuel = cap; items = []; nextGen = 500; idle = 0; got = 0;
  levelTarget = levelTargetM(selLevel);
  finishTriggered = false; celebT = 0; celebParts = []; winReward = 0; winCoins = 0;
  wasCrashed = false; replayBuf = []; replayIdx = 0; stopHorn();
  state = 'ready';
  updBio(S.x);
  pops.push({ s: MAPS[selMap].name.toUpperCase(), t: 2.8 });
}
function gen(upTo) {
  while (nextGen < upTo) {
    const k = Math.floor(nextGen / 700), x0 = k * 700 + 100;
    if (k > 0) {
      if (rnd(k * 3.1) < 0.07) items.push({ x: x0 + 350, y: Phys.height(x0 + 350) + 70, t: 'fuel' });
      if (rnd(k * 11.3) < 0.12) items.push({ x: x0 + 520, y: Phys.height(x0 + 520) + 70, t: 'nitro' });
      if (rnd(k * 7.7) < 0.10) items.push({ x: x0 + 450, y: Phys.height(x0 + 450) + 95, t: 'gem' });
      const n = 3 + Math.floor(rnd(k * 5.7) * 5), arc = rnd(k * 9.3) < 0.5;
      for (let i = 0; i < n; i++) { const x = x0 + 60 + i * 42;
        items.push({ x, y: Phys.height(x) + 55 + (arc ? Math.sin(i / (n - 1) * Math.PI) * 45 : 0), t: 'coin' }); }
    }
    nextGen += 700;
  }
}

// ---------- audio ----------
let AC, osc, og, started = false;
function audioStart() {
  if (started) return; started = true;
  try { AC = new (window.AudioContext || window.webkitAudioContext)();
    osc = AC.createOscillator(); og = AC.createGain(); osc.type = 'sawtooth'; osc.frequency.value = 50; og.gain.value = 0;
    osc.connect(og); og.connect(AC.destination); osc.start(); } catch (e) {}
}
function blip(f, d) {
  if (!AC || settings.soundVol < 0.02) return;
  const o = AC.createOscillator(), g = AC.createGain(); o.type = 'square'; o.frequency.value = f;
  const vol = 0.06 * settings.soundVol;
  g.gain.setValueAtTime(vol, AC.currentTime); g.gain.exponentialRampToValueAtTime(0.001, AC.currentTime + d);
  o.connect(g); g.connect(AC.destination); o.start(); o.stop(AC.currentTime + d);
}
// Bridge sounds – different character per type (mobile-friendly short one-shots)
let lastCreak = 0;
function bridgeSound(type, intensity) {
  if (!AC || intensity < 0.12 || settings.soundVol < 0.02) return;
  const now = AC.currentTime;
  if (now - lastCreak < 0.11) return;
  lastCreak = now;
  try {
    const o = AC.createOscillator(), g = AC.createGain(), f = AC.createBiquadFilter();
    const inv = Math.min(1, intensity) * settings.soundVol;
    // 0 Wooden, 1 Rope, 2 Broken, 3 Steel, 4 Stone, 5 Hanging, 6 Railway, 7 Concrete, 8 Log, 9 Suspension
    if (type === 3 || type === 6 || type === 7) { // metal / steel / railway / concrete
      o.type = 'square';
      o.frequency.setValueAtTime(120 + Math.random() * 90, now);
      o.frequency.exponentialRampToValueAtTime(50 + Math.random() * 40, now + 0.12);
      f.type = 'bandpass'; f.frequency.value = 600 + inv * 1200; f.Q.value = 2.5;
      g.gain.setValueAtTime(0.025 * inv, now);
    } else if (type === 1 || type === 5 || type === 9) { // rope / hanging / suspension
      o.type = 'sine';
      o.frequency.setValueAtTime(60 + Math.random() * 40, now);
      o.frequency.linearRampToValueAtTime(35 + Math.random() * 25, now + 0.25);
      f.type = 'lowpass'; f.frequency.value = 280 + inv * 200;
      g.gain.setValueAtTime(0.035 * inv, now);
    } else if (type === 4) { // stone
      o.type = 'triangle';
      o.frequency.setValueAtTime(70 + Math.random() * 30, now);
      f.type = 'lowpass'; f.frequency.value = 200 + inv * 150;
      g.gain.setValueAtTime(0.028 * inv, now);
    } else { // wood / broken / log
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(75 + Math.random() * 55, now);
      o.frequency.exponentialRampToValueAtTime(38 + Math.random() * 28, now + 0.18);
      f.type = 'lowpass'; f.frequency.value = 350 + inv * 700;
      g.gain.setValueAtTime(0.032 * inv, now);
    }
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
    o.connect(f); f.connect(g); g.connect(AC.destination);
    o.start(now); o.stop(now + 0.25);
  } catch (e) {}
}
function creakSound(intensity) { bridgeSound(0, intensity); }

function startHorn() {
  if (!AC || settings.soundVol < 0.02 || hornOn) return;
  hornOn = true;
  try {
    audioStart();
    if (hornOsc) { try { hornOsc.stop(); } catch (e) {} }
    const now = AC.currentTime;
    hornOsc = AC.createOscillator();
    hornGain = AC.createGain();
    const f = AC.createBiquadFilter();
    hornOsc.type = 'sawtooth';
    hornOsc.frequency.setValueAtTime(380, now);
    hornOsc.frequency.linearRampToValueAtTime(420, now + 0.08);
    f.type = 'bandpass'; f.frequency.value = 500; f.Q.value = 3;
    hornGain.gain.setValueAtTime(0.0001, now);
    hornGain.gain.exponentialRampToValueAtTime(0.12 * settings.soundVol, now + 0.04);
    hornOsc.connect(f); f.connect(hornGain); hornGain.connect(AC.destination);
    hornOsc.start(now);
  } catch (e) {}
}
function stopHorn() {
  if (!hornOn) return;
  hornOn = false;
  try {
    if (hornGain && AC) {
      const now = AC.currentTime;
      hornGain.gain.cancelScheduledValues(now);
      hornGain.gain.setValueAtTime(hornGain.gain.value, now);
      hornGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.08);
    }
    if (hornOsc) { const o = hornOsc; setTimeout(() => { try { o.stop(); } catch (e) {} }, 120); hornOsc = null; }
  } catch (e) {}
}
function lightsActive() {
  // Manual toggle OR auto on night maps
  if (lightsOn) return true;
  if (lightsAuto && cur.night > 0.35) return true;
  return false;
}
function pushReplaySample() {
  if (!S || state !== 'play') return;
  replayBuf.push({
    x: S.x, y: S.y, th: S.th, vx: S.vx, vy: S.vy, om: S.om,
    air: !!S.air, crashed: !!S.crashed,
    w: S.w.map(w => ({ x: w.x, y: w.y, ang: w.ang }))
  });
  if (replayBuf.length > REPLAY_BUF) replayBuf.shift();
}
function startCrashReplay() {
  if (replayBuf.length < 10) { state = 'over'; overT = 0; return; }
  state = 'replay';
  replayIdx = 0;
  replayCam = 0;
  replayT = 0;
  ptr.clear(); nptr.clear(); stopHorn(); upd();
  blip(200, 0.3);
}
function skipReplay() {
  state = 'over'; overT = 0.5;
  if (og) og.gain.value = 0;
}

function victorySound() {
  if (!AC || settings.soundVol < 0.02) return;
  try {
    const now = AC.currentTime, vol = 0.08 * settings.soundVol;
    // Fanfare
    [[523, 0], [659, 0.12], [784, 0.24], [1046, 0.4]].forEach(([f, t]) => {
      const o = AC.createOscillator(), g = AC.createGain();
      o.type = 'square'; o.frequency.value = f;
      g.gain.setValueAtTime(vol, now + t);
      g.gain.exponentialRampToValueAtTime(0.001, now + t + 0.35);
      o.connect(g); g.connect(AC.destination); o.start(now + t); o.stop(now + t + 0.4);
    });
    // Crowd cheer (noise-ish layered sines)
    for (let i = 0; i < 6; i++) {
      const o = AC.createOscillator(), g = AC.createGain();
      o.type = 'sawtooth'; o.frequency.value = 80 + Math.random() * 120;
      g.gain.setValueAtTime(0.015 * settings.soundVol, now + 0.3);
      g.gain.exponentialRampToValueAtTime(0.001, now + 1.8);
      o.connect(g); g.connect(AC.destination); o.start(now + 0.3); o.stop(now + 2);
    }
  } catch (e) {}
}

function spawnCelebration(wx, wy) {
  celebParts = [];
  // Confetti
  for (let i = 0; i < 80; i++) {
    celebParts.push({
      kind: 'confetti',
      x: wx + (Math.random() - 0.5) * 200,
      y: wy + 40 + Math.random() * 80,
      vx: (Math.random() - 0.5) * 280,
      vy: 80 + Math.random() * 220,
      life: 2.5 + Math.random() * 1.5,
      max: 3,
      col: ['#ff6b6b', '#ffd43b', '#69db7c', '#4dabf7', '#da77f2', '#fff'][i % 6],
      size: 4 + Math.random() * 6,
      rot: Math.random() * 6,
      spin: (Math.random() - 0.5) * 10
    });
  }
  // Fireworks bursts
  for (let b = 0; b < 5; b++) {
    const bx = wx + (Math.random() - 0.5) * 300;
    const by = wy + 120 + Math.random() * 100;
    const col = ['#ff6b6b', '#ffd43b', '#69db7c', '#4dabf7', '#faa2c1'][b % 5];
    for (let i = 0; i < 18; i++) {
      const a = (i / 18) * Math.PI * 2;
      const sp = 60 + Math.random() * 140;
      celebParts.push({
        kind: 'spark',
        x: bx, y: by,
        vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
        life: 1.2 + Math.random() * 0.8,
        max: 2,
        col, size: 3 + Math.random() * 3
      });
    }
  }
}

function updateCeleb(dt) {
  for (const p of celebParts) {
    p.x += p.vx * dt; p.y += p.vy * dt;
    p.vy -= 180 * dt;
    p.vx *= 0.98;
    p.life -= dt;
    if (p.spin) p.rot += p.spin * dt;
  }
  celebParts = celebParts.filter(p => p.life > 0);
}

function drawCelebWorld() {
  for (const p of celebParts) {
    const a = Math.max(0, p.life / (p.max || 2));
    ctx.globalAlpha = a;
    ctx.fillStyle = p.col;
    if (p.kind === 'confetti') {
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot || 0);
      ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
      ctx.restore();
    } else {
      ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, 7); ctx.fill();
    }
  }
  ctx.globalAlpha = 1;
}

function drawFinishLine() {
  const fx = finishWorldX();
  const fy = Phys.height(fx);
  // Checkered band across the road surface
  const half = 55;
  for (let i = -6; i < 6; i++) {
    const px = fx + i * 10;
    const py = Phys.height(px);
    ctx.fillStyle = ((i + 20) % 2 === 0) ? '#111' : '#f8f9fa';
    ctx.beginPath();
    ctx.moveTo(px - 5, py - 2);
    ctx.lineTo(px + 5, py - 2);
    ctx.lineTo(px + 5, py + 14);
    ctx.lineTo(px - 5, py + 14);
    ctx.closePath();
    ctx.fill();
  }
  // Flag pole
  ctx.strokeStyle = '#adb5bd'; ctx.lineWidth = 4;
  ctx.beginPath(); ctx.moveTo(fx, fy); ctx.lineTo(fx, fy + 90); ctx.stroke();
  // Checkered flag
  const fw = 48, fh = 32, cols = 4, rows = 3;
  const cw = fw / cols, ch = fh / rows;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      ctx.fillStyle = (r + c) % 2 === 0 ? '#111' : '#fff';
      ctx.fillRect(fx + 2 + c * cw, fy + 55 + r * ch, cw + 0.5, ch + 0.5);
    }
  }
  // Flag wave outline
  ctx.strokeStyle = '#333'; ctx.lineWidth = 1.5;
  ctx.strokeRect(fx + 2, fy + 55, fw, fh);
  // Pole ball
  ctx.fillStyle = '#ffd43b';
  ctx.beginPath(); ctx.arc(fx, fy + 92, 5, 0, 7); ctx.fill();
  // FINISH text on ground
  ctx.save();
  ctx.translate(fx, fy + 28);
  ctx.scale(1, -1);
  ctx.font = 'bold 14px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillStyle = '#ffd43b';
  ctx.fillText('FINISH', 0, 0);
  ctx.restore();
}

function drawWinScreen() {
  // Dim
  ctx.fillStyle = 'rgba(0,0,0,0.75)'; ctx.fillRect(0, 0, W, H);
  // Panel
  const pw = Math.min(W * 0.7, 420), ph = Math.min(H * 0.72, 340);
  const x0 = (W - pw) / 2, y0 = (H - ph) / 2;
  ctx.fillStyle = 'rgba(20,28,48,0.97)';
  ctx.beginPath(); ctx.roundRect(x0, y0, pw, ph, 18); ctx.fill();
  ctx.strokeStyle = '#ffd43b'; ctx.lineWidth = 3; ctx.stroke();

  // Trophy
  const tx = W / 2, ty = y0 + 58;
  ctx.fillStyle = '#ffd43b';
  ctx.beginPath(); ctx.arc(tx, ty, 28, 0, 7); ctx.fill();
  ctx.fillStyle = '#f59f00';
  ctx.fillRect(tx - 8, ty + 20, 16, 18);
  ctx.fillRect(tx - 16, ty + 36, 32, 8);
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 22px sans-serif'; ctx.textAlign = 'center';
  ctx.fillText('🏆', tx, ty + 10);

  txt('LEVEL COMPLETE!', W / 2, y0 + 110, Math.min(28, H / 14), '#ffd43b', 'center');
  txt('Level ' + selLevel + '  ·  ' + MAPS[selMap].name, W / 2, y0 + 140, 16, '#9ad8ff', 'center');
  txt('Coins collected:  +' + winCoins, W / 2, y0 + 175, 18, '#fff', 'center');
  txt('Level reward:  +' + winReward, W / 2, y0 + 200, 18, '#69db7c', 'center');
  txt('Total:  +' + (winCoins + winReward) + ' coins', W / 2, y0 + 228, 20, '#ffd43b', 'center');

  // Buttons
  const bw = pw * 0.38, bh = 44;
  const nextR = [x0 + pw * 0.08, y0 + ph - 70, bw, bh];
  const replayR = [x0 + pw * 0.54, y0 + ph - 70, bw, bh];
  btnDraw(nextR, '#2f9e44', selLevel < NUM_LEVELS ? 'NEXT LEVEL' : 'FINISH', 16);
  btnDraw(replayR, '#e67700', 'REPLAY', 16);
  // Store for hit testing
  drawWinScreen._next = nextR;
  drawWinScreen._replay = replayR;
  drawWinScreen._menu = [x0 + pw * 0.25, y0 + ph - 28, pw * 0.5, 22];
  txt('Main Menu', W / 2, y0 + ph - 12, 13, '#9ad8ff', 'center');
}

// ---------- input ----------
function hitPedal(rect, x, y, pad) {
  if (!rect) return false;
  const p = pad == null ? 18 : pad;
  return x >= rect[0] - p && x <= rect[0] + rect[2] + p && y >= rect[1] - p && y <= rect[1] + rect[3] + p;
}
function upd() {
  gas = !!(keys.ArrowRight || keys.d || keys.D);
  brake = !!(keys.ArrowLeft || keys.a || keys.A);
  nitOn = !!(keys.ArrowUp || keys.w || keys.W || keys.Shift || keys[' '] || keys.n || keys.N || nptr.size);
  // Multitouch: any pointer over gas/brake pedal (or generous fallback half-screen)
  if (ptrPos.size || ptr.size) {
    const g = geo();
    let anyGas = false, anyBrake = false;
    for (const p of ptrPos.values()) {
      if (hitPedal(g.gas, p.x, p.y, 22)) anyGas = true;
      else if (hitPedal(g.brake, p.x, p.y, 22)) anyBrake = true;
      else if (p.x > W * 0.55) anyGas = true;
      else if (p.x < W * 0.45) anyBrake = true;
    }
    // legacy ptr (x only) fallback
    for (const v of ptr.values()) {
      if (typeof v === 'number') {
        if (v > W * 0.55) anyGas = true;
        else if (v < W * 0.45) anyBrake = true;
      }
    }
    if (anyGas) gas = true;
    if (anyBrake) brake = true;
  }
}
function begin() { audioStart(); if (AC && AC.state === 'suspended') AC.resume();
  if (state === 'pause') { state = 'play'; return; }
  if (H > W) return;
  if (state === 'home' || state === 'maps') { reset(); state = 'play'; goFull(false); return; }
  if ((state === 'over' || state === 'win') && overT > 0.4) reset(); if (state === 'ready') state = 'play'; }
function openSettings() {
  if (state === 'play') {
    state = 'settings';
    ptr.clear(); ptrPos.clear(); nptr.clear(); upd();
    gas = false; brake = false; gasPress = 0; brakePress = 0;
    blip(600, 0.08);
  } else if (state === 'settings') {
    state = 'play';
  }
}
function togglePause() {
  if (state === 'play') openSettings();
  else if (state === 'settings' || state === 'pause') state = 'play';
}
addEventListener('pointerdown', e => {
  audioStart(); if (AC && AC.state === 'suspended') AC.resume();
  const { x: px, y: py } = ptrXY(e);
  // Garage: start swipe tracking – do NOT select yet (prevents accidental buy while scrolling)
  if (state === 'ready' || state === 'over' || state === 'win') {
    swipe.active = true; swipe.id = e.pointerId;
    swipe.startX = px; swipe.startY = py;
    swipe.dx = 0; swipe.dy = 0; swipe.moved = false;
    try { e.target.setPointerCapture && e.target.setPointerCapture(e.pointerId); } catch (err) {}
    return;
  }
  if (state === 'settings') { uiTap(px, py); return; }
  if (state === 'replay') {
    const rb = replayButtons();
    if (hit(rb.skip, px, py)) { skipReplay(); return; }
    if (hit(rb.again, px, py)) { startCrashReplay(); return; }
    return;
  }
  if (state !== 'play') { uiTap(px, py); return; }
  if (H > W) return;
  const g = geo();
  if (Math.hypot(px - g.nit.x, py - g.nit.y) <= g.nit.r * 1.25) { nptr.add(e.pointerId); upd(); return; }
  if (Math.hypot(px - g.horn.x, py - g.horn.y) <= g.horn.r * 1.25) { startHorn(); return; }
  if (Math.hypot(px - g.lights.x, py - g.lights.y) <= g.lights.r * 1.25) {
    lightsOn = !lightsOn; blip(lightsOn ? 900 : 400, 0.08); return;
  }
  // Generous hit padding so HUD buttons are easy on touchscreens (landscape fullscreen)
  if (hitPedal(g.pause, px, py, 16)) { togglePause(); return; }
  if (hitPedal(g.settings, px, py, 16)) { openSettings(); return; }
  ptr.set(e.pointerId, px); ptrPos.set(e.pointerId, { x: px, y: py }); upd();
});
addEventListener('pointermove', e => {
  const { x: px, y: py } = ptrXY(e);
  if (ptrPos.has(e.pointerId) || ptr.has(e.pointerId)) {
    ptrPos.set(e.pointerId, { x: px, y: py });
    if (ptr.has(e.pointerId)) ptr.set(e.pointerId, px);
    if (state === 'play') upd();
  }
  if (!swipe.active || e.pointerId !== swipe.id) return;
  swipe.dx = px - swipe.startX;
  swipe.dy = py - swipe.startY;
  if (Math.abs(swipe.dx) > TAP_SLOP || Math.abs(swipe.dy) > TAP_SLOP) swipe.moved = true;
  // Live drag feedback while swiping horizontally on garage
  if ((state === 'ready' || state === 'over' || state === 'win') && Math.abs(swipe.dx) > Math.abs(swipe.dy)) {
    slideX = swipe.dx * 0.55; // parallax drag
  }
});
addEventListener('pointerup', e => {
  ptr.delete(e.pointerId); ptrPos.delete(e.pointerId); nptr.delete(e.pointerId); upd();
  stopHorn();
  if (fsPending) { const m = fsPending; fsPending = 0; goFull(m === 'toggle'); }

  // Finish garage swipe
  if (swipe.active && e.pointerId === swipe.id) {
    const dx = swipe.dx, dy = swipe.dy, moved = swipe.moved;
    swipe.active = false; swipe.id = null;

    if ((state === 'ready' || state === 'over' || state === 'win') && moved && Math.abs(dx) > SWIPE_THRESH && Math.abs(dx) > Math.abs(dy) * 1.2) {
      // Swipe RIGHT (finger moves left→right, dx > 0) → NEXT vehicle/page
      // Swipe LEFT  (finger moves right→left, dx < 0) → PREVIOUS vehicle/page
      const L = layout();
      if (dx > 0) {
        // next
        if (garagePage < L.maxPage) {
          garagePage++;
          slideX = -W * 0.35; slideTarget = 0; slideAnimating = true;
          blip(700, 0.08);
        } else {
          slideX = 0; slideTarget = 0; slideAnimating = true;
        }
      } else {
        // previous
        if (garagePage > 0) {
          garagePage--;
          slideX = W * 0.35; slideTarget = 0; slideAnimating = true;
          blip(700, 0.08);
        } else {
          slideX = 0; slideTarget = 0; slideAnimating = true;
        }
      }
    } else if ((state === 'ready' || state === 'over' || state === 'win') && !moved) {
      // Clean tap – process selection / buy / upgrades
      slideX = 0; slideTarget = 0;
      uiTap(e.clientX, e.clientY);
    } else {
      // Cancelled / vertical scroll – snap back
      slideX = 0; slideTarget = 0; slideAnimating = true;
    }
    return;
  }
});
addEventListener('pointercancel', e => {
  ptr.delete(e.pointerId); ptrPos.delete(e.pointerId); nptr.delete(e.pointerId); upd();
  stopHorn();
  if (swipe.active && e.pointerId === swipe.id) {
    swipe.active = false; swipe.id = null;
    slideX = 0; slideTarget = 0; slideAnimating = true;
  }
});
function replayButtons() {
  const bw = Math.min(160, W * 0.28), bh = 44;
  return {
    again: [W / 2 - bw - 12, H * 0.88, bw, bh],
    skip: [W / 2 + 12, H * 0.88, bw, bh]
  };
}
addEventListener('keydown', e => { keys[e.key] = true; upd(); if (e.key === ' ' || e.key.startsWith('Arrow')) e.preventDefault();
  if (e.key === 'f' || e.key === 'F') { goFull(true); return; }
  if (e.key === 'p' || e.key === 'P' || e.key === 'Escape') { togglePause(); return; }
  // Garage: arrow keys also change vehicle page (same direction as swipe)
  if (state === 'ready' || state === 'over' || state === 'win') {
    const L = layout();
    if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
      if (garagePage < L.maxPage) { garagePage++; slideX = -W * 0.35; slideTarget = 0; slideAnimating = true; blip(700, 0.08); }
      return;
    }
    if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
      if (garagePage > 0) { garagePage--; slideX = W * 0.35; slideTarget = 0; slideAnimating = true; blip(700, 0.08); }
      return;
    }
  }
  if (['ArrowRight', 'ArrowLeft', 'd', 'a', ' ', 'Enter'].includes(e.key)) begin();
});
addEventListener('keyup', e => { keys[e.key] = false; upd(); });
document.addEventListener('visibilitychange', () => { if (document.hidden && state === 'play') togglePause(); });

// ---------- drawing ----------
function drawSky() {
  const c = cur.col, g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, c[0]); g.addColorStop(1, c[1]);
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  if (cur.night > 0.02) {
    ctx.fillStyle = '#fff';
    for (let i = 0; i < 70; i++) { ctx.globalAlpha = cur.night * (0.5 + 0.5 * Math.sin(T * 2 + i * 7)); ctx.fillRect(rnd(i) * W, rnd(i + 100) * H * 0.55, 2, 2); }
    ctx.globalAlpha = cur.night;
    if (cur.i === 5) { // Moon – Earth
      ctx.fillStyle = '#4a7ab0'; ctx.beginPath(); ctx.arc(W * 0.78, H * 0.14, H * 0.05, 0, 7); ctx.fill();
      ctx.fillStyle = '#3a9a40'; ctx.beginPath(); ctx.arc(W * 0.76, H * 0.13, H * 0.018, 0, 7); ctx.fill();
    } else if (cur.i === 6) { // Mars sun
      ctx.fillStyle = '#ffaa44'; ctx.beginPath(); ctx.arc(W * 0.85, H * 0.12, H * 0.032, 0, 7); ctx.fill();
    } else if (cur.i === 9) { // Volcano red sun
      ctx.fillStyle = '#ff4422'; ctx.beginPath(); ctx.arc(W * 0.8, H * 0.15, H * 0.05, 0, 7); ctx.fill();
    } else {
      ctx.fillStyle = '#f4f1d0'; ctx.beginPath(); ctx.arc(W * 0.82, H * 0.16, H * 0.06, 0, 7); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }
  if (sky.complete && sky.naturalWidth && cur.night < 0.7) {
    ctx.globalAlpha = 1 - cur.night * 0.9;
    const dh = H * 0.45, dw = dh * sky.naturalWidth / sky.naturalHeight, off = -((camX * 0.06 * sc) % dw + dw) % dw;
    for (let x = off - dw; x < W; x += dw) ctx.drawImage(sky, x, 0, dw + 1, dh);
    ctx.globalAlpha = 1;
  }
  for (const [p, col, a, h] of [[0.12, c[2], 0.5, 70], [0.25, c[3], 0.55, 45]]) {
    ctx.fillStyle = col; ctx.globalAlpha = a; ctx.beginPath(); ctx.moveTo(0, H); const base = H * 0.78 + camY * sc * 0.1;
    for (let x = 0; x <= W + 20; x += 20) { const t = (x + camX * sc * p) / (sc * 160); ctx.lineTo(x, base - sc * h * (0.5 * Math.sin(t) + 0.3 * Math.sin(t * 2.3 + 1) + 0.8)); }
    ctx.lineTo(W + 20, H); ctx.fill(); ctx.globalAlpha = 1;
  }
}
function drawTerrain(x0, x1, yb) {
  // Original road/hill geometry – unchanged. Bridge decks draw on top later.
  const c = cur.col, pts = [];
  for (let x = x0; x <= x1; x += 10) pts.push([x, Phys.height(x)]);
  ctx.beginPath(); ctx.moveTo(x0, yb); for (const p of pts) ctx.lineTo(p[0], p[1]); ctx.lineTo(x1, yb); ctx.closePath();
  ctx.fillStyle = c[4]; ctx.fill();
  // craters
  for (let i = Math.floor(x0 / 160) - 1; i <= Math.floor(x1 / 160); i++) for (let j = 0; j < 3; j++) {
    const cx = (i + rnd(i * 7 + j)) * 160, r = 10 + rnd(i * 13 + j * 5) * 38, cy = Phys.height(cx) - 45 - r - rnd(i * 29 + j * 3) * 200;
    ctx.fillStyle = c[5]; ctx.beginPath(); ctx.arc(cx + r * 0.14, cy - r * 0.1, r, 0, 7); ctx.fill();
    ctx.fillStyle = c[6]; ctx.beginPath(); ctx.arc(cx, cy, r * 0.9, 0, 7); ctx.fill();
    ctx.fillStyle = c[7]; ctx.beginPath(); ctx.arc(cx - r * 0.1, cy + r * 0.12, r * 0.55, 0, 7); ctx.fill();
  }
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  const band = (off, w, col) => {
    ctx.beginPath();
    pts.forEach((p, k) => k ? ctx.lineTo(p[0], p[1] - off) : ctx.moveTo(p[0], p[1] - off));
    ctx.strokeStyle = col; ctx.lineWidth = w; ctx.stroke();
  };
  band(28, 22, c[8]); band(11, 26, c[9]); band(10, 16, c[10]);
  // surface tufts
  for (let i = Math.floor(x0 / 300) - 1; i <= Math.floor(x1 / 300); i++) {
    const x = i * 300 + rnd(i * 3.3) * 140, y = Phys.height(x) - 2;
    for (let b = -2; b <= 2; b++) {
      ctx.fillStyle = b % 2 ? c[11] : c[12];
      ctx.beginPath();
      ctx.moveTo(x + b * 4 - 4, y - 2); ctx.lineTo(x + b * 6, y + 16 - Math.abs(b) * 3); ctx.lineTo(x + b * 4 + 4, y - 2); ctx.fill();
    }
  }
  drawMapDecor(x0, x1);
}

// Realistic 3D-style pine tree (side-view). Purely visual – no physics impact.
// seed drives size/variation, scale for foreground/background depth, windAmt for sway.
function drawPineTree(x, y, seed, scale, windAmt, dead) {
  const g = settings.graphics | 0;
  const s = scale * (0.85 + rnd(seed * 1.7) * 0.45); // height variation
  const trunkH = 22 * s + rnd(seed * 2.3) * 18 * s;
  const trunkW = (3.2 + rnd(seed * 3.1) * 2.2) * s;
  const wind = windAmt * (0.6 + rnd(seed) * 0.8) * Math.sin(T * (1.1 + rnd(seed * 0.9) * 0.7) + seed * 4.2);
  const lean = wind * 0.35; // subtle trunk lean
  const layers = g >= 2 ? 5 + (rnd(seed * 5) * 2 | 0) : (g >= 1 ? 4 : 3);
  const baseGreen = dead ? ['#3a3a28', '#2a2a1a', '#4a4a30'] : ['#1a5a18', '#2a7a28', '#0f4a10', '#3a9a30', '#1a6a20'];
  const tipGreen = dead ? '#5a5a40' : '#4aba40';
  const bark = dead ? '#3a3020' : '#4a3020';
  const barkDark = dead ? '#2a2010' : '#2f1c0e';

  // Soft ground shadow (depth + lighting)
  ctx.globalAlpha = 0.22 * Math.min(1, s);
  ctx.fillStyle = '#0a1008';
  ctx.beginPath();
  ctx.ellipse(x + lean * 0.4, y - 1, trunkW * 2.8 + layers * 3 * s, 4 * s, 0, 0, 7);
  ctx.fill();
  ctx.globalAlpha = 1;

  // Trunk with simple bark striations
  ctx.fillStyle = bark;
  ctx.beginPath();
  ctx.moveTo(x - trunkW + lean * 0.15, y);
  ctx.lineTo(x - trunkW * 0.7 + lean, y + trunkH);
  ctx.lineTo(x + trunkW * 0.7 + lean, y + trunkH);
  ctx.lineTo(x + trunkW, y);
  ctx.closePath();
  ctx.fill();
  if (g >= 1) {
    ctx.strokeStyle = barkDark;
    ctx.lineWidth = 1 * s;
    for (let b = 0; b < 3; b++) {
      const by = y + trunkH * (0.25 + b * 0.22);
      ctx.beginPath();
      ctx.moveTo(x - trunkW * 0.55 + lean * (by - y) / trunkH, by);
      ctx.lineTo(x + trunkW * 0.45 + lean * (by - y) / trunkH, by + 2 * s);
      ctx.stroke();
    }
  }

  // Layered pine foliage (triangular tiers) with wind sway
  const folStart = y + trunkH * 0.55;
  for (let L = 0; L < layers; L++) {
    const t = L / (layers - 0.5);
    const ly = folStart + (trunkH * 0.55 + 28 * s) * t;
    const lw = (22 + 18 * (1 - t) + rnd(seed + L * 7) * 8) * s;
    const sway = lean + wind * (0.4 + t * 1.6);
    const col = dead ? baseGreen[L % 3] : (L === layers - 1 ? tipGreen : baseGreen[L % baseGreen.length]);
    // slightly darker underside for volume
    ctx.fillStyle = col;
    ctx.beginPath();
    ctx.moveTo(x + sway, ly + 8 * s);
    ctx.lineTo(x - lw + sway * 0.7, ly - 2 * s);
    ctx.lineTo(x + lw + sway * 0.7, ly - 2 * s);
    ctx.closePath();
    ctx.fill();
    // inner highlight / needle suggestion
    if (g >= 2 && !dead) {
      ctx.fillStyle = 'rgba(120,200,80,0.25)';
      ctx.beginPath();
      ctx.moveTo(x + sway * 0.9, ly + 4 * s);
      ctx.lineTo(x - lw * 0.55 + sway * 0.6, ly);
      ctx.lineTo(x + lw * 0.55 + sway * 0.6, ly);
      ctx.closePath();
      ctx.fill();
    }
    // sparse branch lines for detail
    if (g >= 2) {
      ctx.strokeStyle = barkDark;
      ctx.lineWidth = 1.1 * s;
      ctx.globalAlpha = 0.55;
      ctx.beginPath();
      ctx.moveTo(x + sway * 0.5, ly - 1);
      ctx.lineTo(x - lw * 0.7 + sway, ly + 3 * s);
      ctx.moveTo(x + sway * 0.5, ly - 1);
      ctx.lineTo(x + lw * 0.7 + sway, ly + 3 * s);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }
  }

  // Small bushes / undergrowth around base (natural look)
  if (g >= 1 && !dead) {
    const bushN = 2 + (rnd(seed * 9) * 3 | 0);
    for (let b = 0; b < bushN; b++) {
      const bx = x + (rnd(seed + b * 11) - 0.5) * 28 * s;
      const by = y + rnd(seed + b) * 4 * s;
      const br = (4 + rnd(seed + b * 3) * 6) * s;
      ctx.fillStyle = b % 2 ? '#1a6a18' : '#2a8a28';
      ctx.beginPath();
      ctx.arc(bx, by + br * 0.3, br, 0, 7);
      ctx.fill();
    }
    // tiny grass tufts
    ctx.fillStyle = '#2f9e44';
    for (let g2 = -2; g2 <= 2; g2++) {
      if (rnd(seed + g2 * 13) < 0.35) continue;
      const gx = x + g2 * 5 * s + (rnd(seed + g2) - 0.5) * 4;
      ctx.beginPath();
      ctx.moveTo(gx, y);
      ctx.lineTo(gx + (rnd(seed + g2) - 0.5) * 3, y + 6 * s + rnd(seed) * 4);
      ctx.lineTo(gx + 2, y);
      ctx.fill();
    }
  }
}

function drawMapDecor(x0, x1) {
  const id = cur.i;
  const g = settings.graphics | 0;
  // Density & spacing by biome: dense forest, medium mountain/countryside, sparse elsewhere
  const isForest = (id === 7 || id === 11 || id === 17); // Forest, Jungle, DangJungle
  const isPineMap = (id === 0 || id === 7 || id === 8 || id === 11 || id === 14 || id === 17 || id === 24 || id === 26); // + Countryside, Mountain, Haunted, GreenValley, RailwayMtn
  const spacing = isForest ? 210 : (isPineMap ? 310 : 380);
  const maxExtra = isForest ? (g >= 2 ? 3 : 2) : (isPineMap ? (g >= 2 ? 2 : 1) : 0);

  for (let i = Math.floor(x0 / spacing) - 1; i <= Math.floor(x1 / spacing) + 1; i++) {
    const baseX = i * spacing + rnd(i * 4.1) * (spacing * 0.45);
    if (baseX < x0 - 80 || baseX > x1 + 80) continue;
    const info0 = Phys.getTerrain(baseX);
    if (info0.onBridge) continue; // no trees floating on bridge decks
    const y = info0.h;

    // --- Pine / forest biomes: multi-layer realistic trees for depth ---
    if (isPineMap) {
      // Background (far) trees first – smaller, slightly transparent, more wind
      if (g >= 1 && maxExtra >= 1) {
        for (let e = 0; e < (isForest ? 2 : 1); e++) {
          const ox = baseX + (rnd(i * 7.3 + e) - 0.5) * 90;
          if (ox < x0 - 50 || ox > x1 + 50) continue;
          const oy = Phys.height(ox);
          ctx.globalAlpha = 0.55 + rnd(i + e) * 0.25;
          drawPineTree(ox, oy, i * 13 + e * 17, 0.55 + rnd(i + e * 3) * 0.25, 1.4, id === 14);
          ctx.globalAlpha = 1;
        }
      }
      // Main tree
      const mainScale = isForest ? 1.05 + rnd(i) * 0.35 : 0.9 + rnd(i) * 0.4;
      drawPineTree(baseX, y, i * 11.7, mainScale, 1.0, id === 14);
      // Foreground / side trees for density (sparse on non-forest)
      if (maxExtra >= 2) {
        const fx = baseX + (rnd(i * 9.1) - 0.5) * 55;
        if (fx > x0 - 40 && fx < x1 + 40) {
          const fy = Phys.height(fx);
          drawPineTree(fx, fy, i * 19 + 3, 0.75 + rnd(i * 2) * 0.35, 0.85, id === 14);
        }
      }
      // Extra dense cluster only on true forest maps
      if (isForest && g >= 2 && rnd(i * 2.7) > 0.45) {
        const cx = baseX + (rnd(i * 5.5) - 0.5) * 40;
        const cy = Phys.height(cx);
        drawPineTree(cx, cy, i * 23 + 5, 0.65 + rnd(i) * 0.3, 1.1, false);
      }
      continue;
    }

    // --- Non-pine maps keep original (or lightly upgraded) decorations ---
    const x = baseX;
    if (id === 1 || id === 6) { // desert / mars cactus or rock
      ctx.fillStyle = id === 1 ? '#2f9e44' : '#8a4030';
      ctx.fillRect(x - 3, y, 6, 22 + rnd(i) * 10);
      ctx.fillRect(x - 12, y + 12, 10, 5); ctx.fillRect(x + 4, y + 8, 10, 5);
    } else if (id === 2) { // arctic – ice rocks
      ctx.fillStyle = '#d0e0f0';
      ctx.beginPath(); ctx.moveTo(x - 14, y); ctx.lineTo(x, y + 22); ctx.lineTo(x + 14, y); ctx.fill();
    } else if (id === 3 || id === 12 || id === 13) { // highway / city / night – poles or buildings
      ctx.fillStyle = '#555'; ctx.fillRect(x - 3, y, 6, 40);
      if (id === 12) {
        ctx.fillStyle = '#6a7a8a'; ctx.fillRect(x - 20, y + 20, 40, 50 + rnd(i) * 30);
        ctx.fillStyle = '#ffe066'; for (let w = 0; w < 3; w++) ctx.fillRect(x - 14 + w * 12, y + 30, 6, 6);
      }
    } else if (id === 4) { // cave – stalactite shadow rocks
      ctx.fillStyle = '#3a3545';
      ctx.beginPath(); ctx.moveTo(x - 10, y + 50); ctx.lineTo(x, y); ctx.lineTo(x + 10, y + 50); ctx.fill();
    } else if (id === 5) { // moon – craters already drawn; small rocks
      ctx.fillStyle = '#9a9aaa'; ctx.beginPath(); ctx.arc(x, y + 6, 8 + rnd(i) * 6, 0, 7); ctx.fill();
    } else if (id === 9) { // volcano – lava rocks
      ctx.fillStyle = '#5a2020'; ctx.beginPath(); ctx.arc(x, y + 8, 10, 0, 7); ctx.fill();
      ctx.fillStyle = '#ff4400'; ctx.globalAlpha = 0.6 + Math.sin(T * 4 + i) * 0.2;
      ctx.beginPath(); ctx.arc(x, y + 10, 4, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
    } else if (id === 10) { // beach – palms
      ctx.fillStyle = '#6b4226'; ctx.fillRect(x - 3, y, 6, 32);
      ctx.fillStyle = '#2f9e44';
      for (let p = 0; p < 4; p++) {
        const a = -0.8 + p * 0.5;
        ctx.beginPath(); ctx.moveTo(x, y + 32); ctx.quadraticCurveTo(x + Math.cos(a) * 30, y + 40, x + Math.cos(a) * 28, y + 28); ctx.strokeStyle = '#2f9e44'; ctx.lineWidth = 4; ctx.stroke();
      }
    } else if (id === 15) { // tropical island – palm + hut
      ctx.fillStyle = '#6b4226'; ctx.fillRect(x - 3, y, 6, 30);
      ctx.strokeStyle = '#2f9e44'; ctx.lineWidth = 3;
      for (let p = 0; p < 5; p++) {
        const a = -1 + p * 0.5;
        ctx.beginPath(); ctx.moveTo(x, y + 30); ctx.lineTo(x + Math.cos(a) * 26, y + 38); ctx.stroke();
      }
    } else if (id === 16) { // snow village – cabin
      ctx.fillStyle = '#8a5a30'; ctx.fillRect(x - 16, y, 32, 22);
      ctx.fillStyle = '#c04040'; ctx.beginPath(); ctx.moveTo(x - 20, y + 22); ctx.lineTo(x, y + 38); ctx.lineTo(x + 20, y + 22); ctx.fill();
      ctx.fillStyle = '#ffe066'; ctx.fillRect(x - 6, y + 6, 8, 8);
    } else if (id === 18) { // lava mountain – glowing rocks
      ctx.fillStyle = '#4a1818'; ctx.beginPath(); ctx.arc(x, y + 8, 12, 0, 7); ctx.fill();
      ctx.fillStyle = '#ff5500'; ctx.globalAlpha = 0.5 + Math.sin(T * 5 + i) * 0.3;
      ctx.beginPath(); ctx.arc(x, y + 10, 5, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
    } else if (id === 19) { // underwater – kelp / bubbles
      ctx.strokeStyle = '#2a8a6a'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + 8, y + 20, x - 4, y + 40); ctx.stroke();
      ctx.fillStyle = 'rgba(180,220,255,0.4)';
      ctx.beginPath(); ctx.arc(x + 10, y + 15 + Math.sin(T * 3 + i) * 8, 4, 0, 7); ctx.fill();
    } else if (id === 20) { // ghost valley – ruins
      ctx.fillStyle = '#3a3a48'; ctx.fillRect(x - 12, y, 8, 28); ctx.fillRect(x + 4, y, 8, 22);
      ctx.fillStyle = 'rgba(200,200,255,0.15)'; ctx.beginPath(); ctx.arc(x, y + 40, 16, 0, 7); ctx.fill();
    } else if (id === 21) { // grand canyon – layered rock
      ctx.fillStyle = '#c06030'; ctx.fillRect(x - 18, y, 36, 10);
      ctx.fillStyle = '#a04828'; ctx.fillRect(x - 14, y + 10, 28, 10);
      ctx.fillStyle = '#804020'; ctx.fillRect(x - 10, y + 20, 20, 12);
    } else if (id === 22) { // airport – runway lights / hangar
      ctx.fillStyle = '#6a7080'; ctx.fillRect(x - 22, y, 44, 18);
      ctx.fillStyle = '#ffe066'; ctx.fillRect(x - 18, y + 4, 6, 6); ctx.fillRect(x + 12, y + 4, 6, 6);
      ctx.fillStyle = '#fff'; ctx.fillRect(x - 2, y - 2, 4, 8);
    } else if (id === 23) { // industrial – chimney / factory
      ctx.fillStyle = '#5a5a58'; ctx.fillRect(x - 18, y, 36, 28);
      ctx.fillStyle = '#3a3a38'; ctx.fillRect(x + 8, y + 20, 10, 40);
      ctx.fillStyle = 'rgba(80,80,80,0.4)'; ctx.beginPath(); ctx.arc(x + 13, y + 55 + Math.sin(T + i) * 4, 8, 0, 7); ctx.fill();
    } else if (id === 25) { // sky island – floating rocks / clouds
      ctx.fillStyle = '#c8d0a0'; ctx.beginPath(); ctx.ellipse(x, y + 8, 22, 10, 0, 0, 7); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.beginPath(); ctx.arc(x - 8, y + 30, 12, 0, 7); ctx.fill();
    }
  }
}
// --- Interactive wooden bridges + river ---
// 10 bridge types (cycle by index). All solid + continuous height.
const BRIDGE_NAMES = ['Wooden','Rope','Broken','Steel','Stone','Hanging','Railway','Concrete','Log','Suspension'];
function drawRiverAndBridges(x0, x1) {
  // Bridges sit ON the existing road. Water is visual only, below the deck.
  // Road/hill elevations are never modified.
  const BP = Phys.BRIDGE_PERIOD || 3200, BS = Phys.BRIDGE_START_OFF || 1800, BL = Phys.BRIDGE_LEN || 520;
  const first = Math.floor((x0 - BS) / BP) - 1;
  const last = Math.floor((x1 - BS) / BP) + 1;
  for (let bi = first; bi <= last; bi++) {
    const bx = BS + bi * BP;
    if (bx + BL < x0 - 40 || bx > x1 + 40) continue;
    const type = ((bi % 10) + 10) % 10;
    const mid = bx + BL * 0.5;

    // Road heights at ends and middle (existing terrain – unchanged)
    const hL = Phys.height(bx);
    const hR = Phys.height(bx + BL);
    const hM = Phys.height(mid);
    // Visual water surface sits well below the road
    const riverY = Math.min(hL, hR, hM) - 72;

    // ---- FLOWING RIVER (visual only, under the bridge) ----
    const waterCol = (cur.i === 9 || cur.i === 18) ? '#c04018'
      : cur.i === 5 ? '#2a2a40'
      : cur.i === 6 ? '#8a4030'
      : (cur.i === 4 || cur.i === 19) ? '#0a3860'
      : cur.i === 20 ? '#2a2a48'
      : '#1a7ec0';
    const waterHighlight = (cur.i === 9 || cur.i === 18) ? 'rgba(255,120,40,0.35)' : 'rgba(140,210,255,0.40)';

    // Water body under span
    ctx.fillStyle = waterCol;
    ctx.beginPath();
    ctx.moveTo(bx - 16, riverY + 6);
    for (let x = bx - 16; x <= bx + BL + 16; x += 12) {
      const wave = Math.sin(x * 0.045 + T * 3.2) * 3.2 + Math.sin(x * 0.09 + T * 2.1) * 1.8;
      ctx.lineTo(x, riverY + 4 + wave);
    }
    ctx.lineTo(bx + BL + 16, riverY - 55);
    ctx.lineTo(bx - 16, riverY - 55);
    ctx.closePath();
    ctx.fill();

    // Flow highlight
    ctx.fillStyle = waterHighlight;
    ctx.beginPath();
    for (let x = bx; x <= bx + BL; x += 10) {
      const wave = Math.sin(x * 0.06 + T * 4.0) * 2.2;
      if (x === bx) ctx.moveTo(x, riverY + 2 + wave); else ctx.lineTo(x, riverY + 2 + wave);
    }
    ctx.lineTo(bx + BL, riverY - 14);
    ctx.lineTo(bx, riverY - 14);
    ctx.closePath();
    ctx.fill();

    // Flow lines
    ctx.strokeStyle = 'rgba(200,230,255,0.25)';
    ctx.lineWidth = 1.4;
    for (let k = 0; k < 3; k++) {
      ctx.beginPath();
      for (let x = bx + 8; x <= bx + BL - 8; x += 14) {
        const wave = Math.sin(x * 0.07 + T * 2.8 + k * 1.7) * 1.8;
        const y = riverY + wave - k * 3.5;
        if (x === bx + 8) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }

    // Bank rocks (visual, on the existing slopes near ends)
    ctx.fillStyle = '#5a4a3a';
    for (let s = 0; s < 2; s++) {
      const bankX = s === 0 ? bx - 6 : bx + BL + 6;
      for (let r = 0; r < 4; r++) {
        const rx = bankX + (rnd(bi * 11 + r + s * 7) - 0.5) * 18;
        const ry = Phys.height(rx) - 3 - rnd(bi + r) * 6;
        const rr = 4 + rnd(bi * 3 + r) * 6;
        ctx.beginPath(); ctx.ellipse(rx, ry, rr, rr * 0.55, 0, 0, 7); ctx.fill();
      }
    }

    // ---- BRIDGE STRUCTURE (aligned to existing road height) ----
    const carNear = Math.abs(S.x - mid) < BL * 0.8 && !S.air;
    const sway = (type === 1 || type === 5 || type === 9) ? Math.sin(T * 2.0 + bi) * (carNear ? 2.0 : 1.0) : 0;

    if (type === 0) drawBridgeWooden(bx, BL, riverY, sway);
    else if (type === 1) drawBridgeRope(bx, BL, riverY, sway);
    else if (type === 2) drawBridgeBroken(bx, BL, riverY, sway);
    else if (type === 3) drawBridgeSteel(bx, BL, riverY, sway);
    else if (type === 4) drawBridgeStone(bx, BL, riverY, sway);
    else if (type === 5) drawBridgeHanging(bx, BL, riverY, sway);
    else if (type === 6) drawBridgeRailway(bx, BL, riverY, sway);
    else if (type === 7) drawBridgeConcrete(bx, BL, riverY, sway);
    else if (type === 8) drawBridgeLog(bx, BL, riverY, sway);
    else drawBridgeSuspension(bx, BL, riverY, sway);
  }
}

// Deck follows exact Phys.height – same as car collision surface
function _plankShake(px, py, info, mul) {
  const dist = Math.abs(px - S.x);
  const carW = Math.max(0, 1 - dist / 150) * (S.air ? 0 : 1);
  return Math.sin(T * 12 + px * 0.06) * carW * 1.0 * mul + (info.shake || 0) * 0.12;
}
function _drawSolidDeck(bx, BL, colorA, colorB, thickness, railCol, railH) {
  const steps = Math.max(28, Math.floor(BL / 12));
  const pts = [];
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const px = bx + t * BL;
    const info = Phys.getTerrain(px);
    const sy = _plankShake(px, info.h, info, 0.25);
    pts.push({ x: px, y: info.h + sy });
  }
  // Under-shadow
  ctx.fillStyle = 'rgba(0,0,0,0.30)';
  ctx.beginPath();
  ctx.moveTo(pts[0].x - 3, pts[0].y);
  for (const p of pts) ctx.lineTo(p.x, p.y);
  ctx.lineTo(pts[pts.length - 1].x + 3, pts[pts.length - 1].y);
  for (let i = pts.length - 1; i >= 0; i--) ctx.lineTo(pts[i].x, pts[i].y - thickness - 4);
  ctx.closePath();
  ctx.fill();
  // Deck body
  ctx.fillStyle = colorA;
  ctx.beginPath();
  ctx.moveTo(pts[0].x, pts[0].y + 2);
  for (const p of pts) ctx.lineTo(p.x, p.y + 2);
  for (let i = pts.length - 1; i >= 0; i--) ctx.lineTo(pts[i].x, pts[i].y - thickness);
  ctx.closePath();
  ctx.fill();
  // Surface strips
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i], p1 = pts[i + 1];
    ctx.fillStyle = (i % 2) ? colorA : colorB;
    ctx.beginPath();
    ctx.moveTo(p0.x, p0.y + 1); ctx.lineTo(p1.x, p1.y + 1);
    ctx.lineTo(p1.x, p1.y - 2); ctx.lineTo(p0.x, p0.y - 2);
    ctx.closePath(); ctx.fill();
  }
  // Edge bevel
  ctx.strokeStyle = 'rgba(255,255,255,0.12)';
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(pts[0].x, pts[0].y - 1);
  for (const p of pts) ctx.lineTo(p.x, p.y - 1);
  ctx.stroke();
  // Rails
  if (railCol) {
    ctx.strokeStyle = railCol; ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y + railH);
    for (const p of pts) ctx.lineTo(p.x, p.y + railH);
    ctx.stroke();
    for (let i = 0; i < pts.length; i += 3) {
      const p = pts[i];
      ctx.fillStyle = railCol;
      ctx.fillRect(p.x - 2, p.y + 1, 4, railH + 2);
    }
  }
  // End connectors flush with road
  const pad = 16;
  [[bx - pad, bx + 4], [bx + BL - 4, bx + BL + pad]].forEach(([xA, xB]) => {
    const ha = Phys.height(xA), hb = Phys.height(xB);
    ctx.fillStyle = colorA;
    ctx.beginPath();
    ctx.moveTo(xA, ha + 2); ctx.lineTo(xB, hb + 2);
    ctx.lineTo(xB, hb - thickness); ctx.lineTo(xA, ha - thickness);
    ctx.closePath(); ctx.fill();
  });
}
function _drawPillars(bx, BL, riverY, color, dark, width, positions, sway) {
  for (const off of positions) {
    const px = bx + off;
    const ty = Phys.height(px); // exact road height
    const lean = (sway || 0) * 0.2;
    // Foundation in water
    ctx.fillStyle = dark;
    ctx.fillRect(px - width - 4 + lean, riverY - 8, width * 2 + 8, 12);
    // Column from water up to road deck
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(px - width + lean * 0.2, riverY + 2);
    ctx.lineTo(px - width * 0.65 + lean, ty - 4);
    ctx.lineTo(px + width * 0.65 + lean, ty - 4);
    ctx.lineTo(px + width, riverY + 2);
    ctx.closePath();
    ctx.fill();
    // Cap under deck
    ctx.fillStyle = dark;
    ctx.fillRect(px - width - 2 + lean, ty - 6, width * 2 + 4, 8);
  }
}

function drawBridgeWooden(bx, BL, riverY, sway) {
  _drawPillars(bx, BL, riverY, '#5c3a1e', '#3d2410', 8, [45, 155, 265, 375, 475], sway);
  ctx.strokeStyle = '#4a2e14'; ctx.lineWidth = 4;
  [[45, 155], [155, 265], [265, 375], [375, 475]].forEach(([a, b]) => {
    const x0 = bx + a, x1 = bx + b;
    ctx.beginPath(); ctx.moveTo(x0, Phys.height(x0) - 14); ctx.lineTo(x1, Phys.height(x1) - 14); ctx.stroke();
  });
  _drawSolidDeck(bx, BL, '#8B5A2B', '#A06A2F', 10, '#5c3a1e', 13);
}
function drawBridgeRope(bx, BL, riverY, sway) {
  [[28, 0], [BL - 28, 0]].forEach(([off]) => {
    const px = bx + off, ty = Phys.height(px);
    ctx.fillStyle = '#4a3020'; ctx.fillRect(px - 7 + sway, riverY - 4, 14, ty - riverY + 8);
    ctx.fillStyle = '#2e1c10'; ctx.fillRect(px - 9 + sway, ty - 5, 18, 9);
  });
  ctx.strokeStyle = '#c4a574'; ctx.lineWidth = 3;
  ctx.beginPath();
  for (let i = 0; i <= 22; i++) {
    const t = i / 22, px = bx + t * BL;
    const py = Phys.height(px) + 18 + Math.sin(t * Math.PI) * 4 + sway;
    if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
  }
  ctx.stroke();
  _drawSolidDeck(bx, BL, '#7a5a30', '#8f6a3a', 9, '#5a4020', 15);
}
function drawBridgeBroken(bx, BL, riverY, sway) {
  _drawPillars(bx, BL, riverY, '#4a2e14', '#2c1a0c', 7, [55, 175, 305, 435], sway);
  _drawSolidDeck(bx, BL, '#6e4420', '#7a4e28', 9, null, 0);
  ctx.strokeStyle = '#3a2010'; ctx.lineWidth = 1.5;
  for (let k = 0; k < 5; k++) {
    const px = bx + 50 + k * 85, py = Phys.height(px);
    ctx.beginPath(); ctx.moveTo(px - 8, py - 1); ctx.lineTo(px + 10, py + 2); ctx.stroke();
  }
}
function drawBridgeSteel(bx, BL, riverY, sway) {
  _drawPillars(bx, BL, riverY, '#4a5560', '#2d343c', 9, [55, 190, 330, 460], sway);
  ctx.strokeStyle = '#6a7580'; ctx.lineWidth = 3;
  [[55, 190], [190, 330], [330, 460]].forEach(([a, b]) => {
    const x0 = bx + a, x1 = bx + b;
    ctx.beginPath(); ctx.moveTo(x0 - 10, riverY + 18); ctx.lineTo(x1 + 10, Phys.height(x1) - 18); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x0 + 10, riverY + 18); ctx.lineTo(x1 - 10, Phys.height(x1) - 18); ctx.stroke();
  });
  _drawSolidDeck(bx, BL, '#5c6770', '#6a7580', 11, '#8a95a0', 11);
}
function drawBridgeStone(bx, BL, riverY, sway) {
  [60, 180, 300, 420].forEach(off => {
    const px = bx + off, ty = Phys.height(px);
    ctx.fillStyle = '#6a6a5a'; ctx.fillRect(px - 13, riverY - 4, 26, ty - riverY + 6);
    ctx.strokeStyle = '#4a4a3a'; ctx.lineWidth = 1;
    for (let by = riverY; by < ty; by += 12) ctx.strokeRect(px - 13, by, 26, 12);
    ctx.fillStyle = '#5a5a4a'; ctx.fillRect(px - 15, ty - 6, 30, 8);
  });
  _drawSolidDeck(bx, BL, '#8a8a7a', '#9a9a8a', 11, '#6a6a5a', 9);
}
function drawBridgeHanging(bx, BL, riverY, sway) {
  [[32, 0], [BL - 32, 0]].forEach(([off]) => {
    const px = bx + off, ty = Phys.height(px);
    ctx.fillStyle = '#3a2a1a'; ctx.fillRect(px - 6 + sway * 0.3, riverY - 2, 12, ty - riverY + 8);
    ctx.fillStyle = '#2a1a0a'; ctx.fillRect(px - 8 + sway * 0.3, ty - 4, 16, 7);
  });
  ctx.strokeStyle = '#a09070'; ctx.lineWidth = 2.4;
  for (let side = -1; side <= 1; side += 2) {
    ctx.beginPath();
    for (let i = 0; i <= 20; i++) {
      const t = i / 20, px = bx + t * BL;
      const py = Phys.height(px) + 16 + Math.sin(t * Math.PI) * 8 + sway * side;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.stroke();
  }
  _drawSolidDeck(bx, BL, '#6a5030', '#7a6040', 9, '#4a3020', 14);
}
function drawBridgeRailway(bx, BL, riverY, sway) {
  _drawPillars(bx, BL, riverY, '#5a4030', '#3a2a1a', 8, [50, 180, 310, 450], sway);
  _drawSolidDeck(bx, BL, '#4a4a4a', '#5a5a5a', 10, null, 0);
  ctx.strokeStyle = '#999'; ctx.lineWidth = 3;
  for (const yOff of [3, 10]) {
    ctx.beginPath();
    for (let i = 0; i <= 30; i++) {
      const t = i / 30, px = bx + t * BL, py = Phys.height(px) + yOff;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.stroke();
  }
  ctx.fillStyle = '#5a4030';
  for (let i = 0; i < BL; i += 26) {
    const px = bx + i, py = Phys.height(px);
    ctx.fillRect(px, py - 2, 15, 5);
  }
}
function drawBridgeConcrete(bx, BL, riverY, sway) {
  [45, 160, 280, 400, 490].forEach(off => {
    const px = bx + off, ty = Phys.height(px);
    ctx.fillStyle = '#5a6a7a'; ctx.fillRect(px - 11, riverY - 4, 22, ty - riverY + 8);
    ctx.fillStyle = '#3a4a5a'; ctx.fillRect(px - 13, ty - 6, 26, 8);
    ctx.fillStyle = '#6a7a8a'; ctx.fillRect(px - 20, ty - 12, 40, 5);
  });
  _drawSolidDeck(bx, BL, '#6a7a8a', '#7a8a9a', 12, '#8a9aaa', 10);
  ctx.strokeStyle = 'rgba(30,40,50,0.4)'; ctx.lineWidth = 2;
  for (let k = 1; k < 5; k++) {
    const px = bx + k * (BL / 5), py = Phys.height(px);
    ctx.beginPath(); ctx.moveTo(px, py + 2); ctx.lineTo(px, py - 11); ctx.stroke();
  }
}
function drawBridgeLog(bx, BL, riverY, sway) {
  _drawPillars(bx, BL, riverY, '#5a3a1a', '#3a2a10', 7, [42, 165, 295, 425], sway);
  _drawSolidDeck(bx, BL, '#7a4e28', '#8f5c30', 10, null, 0);
  ctx.strokeStyle = '#4a2e14'; ctx.lineWidth = 1.4;
  for (let i = 0; i < BL; i += 34) {
    const px = bx + i + 10, py = Phys.height(px);
    ctx.beginPath(); ctx.ellipse(px, py - 1, 9, 4.5, 0, 0, 7); ctx.stroke();
  }
}
function drawBridgeSuspension(bx, BL, riverY, sway) {
  [[36, 0], [BL - 36, 0]].forEach(([off]) => {
    const px = bx + off, ty = Phys.height(px);
    ctx.fillStyle = '#3a4550'; ctx.fillRect(px - 10 + sway * 0.1, riverY - 10, 20, ty - riverY + 55);
    ctx.fillStyle = '#2a3238'; ctx.fillRect(px - 14 + sway * 0.1, ty + 40, 28, 10);
    ctx.fillStyle = '#4a5560'; ctx.fillRect(px - 17 + sway * 0.1, ty + 46, 34, 6);
  });
  ctx.strokeStyle = '#d0c8b0'; ctx.lineWidth = 4.5;
  ctx.beginPath();
  for (let i = 0; i <= 24; i++) {
    const t = i / 24, px = bx + t * BL;
    const dip = Math.sin(t * Math.PI) * 22;
    const py = Phys.height(px) + 42 - dip + sway * 0.3;
    if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
  }
  ctx.stroke();
  for (let i = 1; i < 20; i++) {
    const t = i / 20, px = bx + t * BL;
    const py = Phys.height(px);
    const cableY = py + 42 - Math.sin(t * Math.PI) * 22 + sway * 0.3;
    ctx.strokeStyle = '#b0a890'; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.moveTo(px, cableY); ctx.lineTo(px, py + 3); ctx.stroke();
  }
  _drawSolidDeck(bx, BL, '#6a7280', '#7a8290', 10, '#9aa2b0', 11);
}
const nightAt = x => cur.night > 0.5;
function lampXs(x0, x1) { const r = []; for (let k = Math.floor((x0 - 60) / 520); k <= Math.floor(x1 / 520) + 1; k++) { const x = k * 520 + 130; if (nightAt(x)) r.push(x); } return r; }
function drawLamps(x0, x1) {
  for (const x of lampXs(x0, x1)) { const y = Phys.height(x), c = ctx;
    c.strokeStyle = '#2b2f3a'; c.lineWidth = 5; c.lineCap = 'round'; c.beginPath(); c.moveTo(x, y - 4); c.lineTo(x, y + 72); c.lineTo(x + 16, y + 77); c.stroke();
    c.fillStyle = cur.night > 0.3 ? '#fff0a8' : '#8a8f99'; c.beginPath(); c.roundRect(x + 10, y + 72, 16, 6, 3); c.fill(); }
}
const worldTx = c => c.setTransform(DPR * sc, 0, 0, -DPR * sc, DPR * (W / 2 - camX * sc), DPR * (H / 2 + camY * sc));
function blob(c, x, y, r, rgb, a) { const g = c.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, 'rgba(' + rgb + ',' + a + ')'); g.addColorStop(1, 'rgba(' + rgb + ',0)'); c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); }
function beam(c, len, up, down) { c.beginPath(); c.moveTo(58, -4); c.lineTo(len, -up); c.lineTo(len, down); c.closePath(); c.fill(); }
function drawNight(x0, x1) {
  const n = cur.night;
  const hl = lightsActive();
  // Always draw headlight beams when lights on (even daytime dimmer)
  if (n < 0.03 && !hl) return;
  const dark = n > 0.03;
  const lamps = lampXs(x0 - 300, x1 + 300);
  if (dark) {
    lx.setTransform(1, 0, 0, 1, 0, 0); lx.globalCompositeOperation = 'source-over'; lx.clearRect(0, 0, lc.width, lc.height);
    lx.fillStyle = 'rgba(4,8,28,' + (0.66 * n) + ')'; lx.fillRect(0, 0, lc.width, lc.height);
    worldTx(lx); lx.globalCompositeOperation = 'destination-out';
    blob(lx, S.x, S.y, 100, '0,0,0', 0.6);
    if (hl) {
      lx.save(); lx.translate(S.x, S.y); lx.rotate(S.th);
      const gr = lx.createLinearGradient(58, 0, 560, 0);
      gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(0.5, 'rgba(0,0,0,0.85)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
      lx.fillStyle = gr; beam(lx, 560, 180, 110); lx.restore();
    }
    for (const x of lamps) blob(lx, x + 18, Phys.height(x) + 70, 200, '0,0,0', 0.95);
    lx.globalCompositeOperation = 'source-over';
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(lc, 0, 0);
  }
  // Additive headlights + lamps
  worldTx(ctx); ctx.globalCompositeOperation = 'lighter';
  if (hl) {
    ctx.save(); ctx.translate(S.x, S.y); ctx.rotate(S.th);
    const inten = dark ? 0.5 : 0.22;
    const g2 = ctx.createLinearGradient(58, 0, 500, 0);
    g2.addColorStop(0, 'rgba(255,235,160,' + inten + ')'); g2.addColorStop(1, 'rgba(255,228,140,0)');
    ctx.fillStyle = g2; beam(ctx, 500, 130, 90);
    blob(ctx, 62, -4, 36, '255,245,180', 0.95 * (dark ? n : 0.5));
    // dual bulbs
    blob(ctx, 58, 4, 14, '255,250,200', 0.9);
    blob(ctx, 58, -10, 14, '255,250,200', 0.9);
    ctx.restore();
  }
  if (dark) for (const x of lamps) blob(ctx, x + 18, Phys.height(x) + 70, 170, '255,214,120', 0.28 * n);
  ctx.globalCompositeOperation = 'source-over';
}
function drawParts() { for (const p of parts) { ctx.fillStyle = 'rgba(205,160,100,' + (p.l * 0.9) + ')'; ctx.beginPath(); ctx.arc(p.x, p.y, 3 + (0.6 - p.l) * 14, 0, 7); ctx.fill(); } }
function drawDriver(c, anim) {
  // =====================================================================
  // 2D ANIMATED SIDE-VIEW DRIVER SPRITE
  // Clear cartoon/sprite style — faces vehicle FRONT (+X). Not 3D, not camera-facing.
  // Pose states: idle / drive / bump / uphill / downhill / jump / crash
  // =====================================================================
  const d = DRIVERS[selDriver] || DRIVERS[0];
  const isF = d.gender === 'female';
  const steer = anim.steer || 0;
  const lean = anim.lean || 0;
  const bounce = anim.bounce || 0;
  const air = anim.air || 0;
  const crash = anim.crash || 0;
  const flip = anim.flip || 0;

  // Resolve animation pose from physics
  let pose = 'idle';
  if (crash > 0.4) pose = 'crash';
  else if (air > 0.5) pose = 'jump';
  else if (lean > 0.45) pose = 'uphill';
  else if (lean < -0.45) pose = 'downhill';
  else if (Math.abs(bounce) > 1.2) pose = 'bump';
  else if (Math.abs(steer) > 0.15 || (typeof gas !== 'undefined' && gas) || (typeof brake !== 'undefined' && brake)) pose = 'drive';

  // Pose offsets
  let bodyRot = lean * 0.1 + flip * 0.04;
  let bodyY = bounce * 0.6;
  let headRot = steer * 0.18 + lean * 0.08;
  let headY = 0;
  let armSpread = steer * 0.8;
  let legKick = 0;
  if (pose === 'jump') {
    bodyY += 4; headY = 2; bodyRot += Math.sin(T * 6) * 0.06;
    headRot += Math.sin(T * 8) * 0.1; armSpread += Math.sin(T * 7) * 0.3;
  } else if (pose === 'crash') {
    bodyY += 3; bodyRot += 0.25; headRot += Math.sin(T * 14) * 0.35;
    armSpread = Math.sin(T * 12) * 0.8; legKick = Math.sin(T * 10) * 3;
  } else if (pose === 'uphill') {
    bodyRot += 0.12; headRot += 0.08; bodyY += 1;
  } else if (pose === 'downhill') {
    bodyRot -= 0.1; headRot -= 0.06; bodyY -= 0.5;
  } else if (pose === 'bump') {
    bodyY += bounce * 0.4; headY += Math.sin(T * 16) * 1.5;
  } else if (pose === 'drive') {
    headRot += Math.sin(T * 2) * 0.03;
  } else {
    // idle micro-motion
    headRot += Math.sin(T * 1.5) * 0.04;
    bodyY += Math.sin(T * 2) * 0.4;
  }

  // Seat fit per vehicle
  const st = (rv && rv.style) || 'jeep';
  let seatX = 2, seatY = 6, sc = 1;
  if (st === 'bike' || st === 'mbike' || st === 'quad' || st === 'chopper') { seatX = 0; seatY = 16; sc = 0.9; }
  else if (st === 'bus' || st === 'sbus' || st === 'fire' || st === 'mil' || st === 'tank' || st === 'van') { seatX = -8; seatY = 12; sc = 1.02; }
  else if (st === 'f1' || st === 'race' || st === 'super' || st === 'sport' || st === 'rally' || st === 'electric' || st === 'rocket') { seatX = 6; seatY = 2; sc = 0.88; }
  else if (st === 'suv' || st === 'pickup' || st === 'monster' || st === 'lowrider' || st === 'hotrod' || st === 'classic') { seatX = 0; seatY = 9; sc = 1; }
  else if (st === 'tractor' || st === 'exca' || st === 'moon' || st === 'finger') { seatX = -4; seatY = 14; sc = 0.95; }
  else if (st === 'police' || st === 'ambu') { seatX = 2; seatY = 5; sc = 0.96; }
  else if (st === 'hover' || st === 'onewheel' || st === 'rc') { seatX = 0; seatY = 10; sc = 0.92; }

  const skin = d.skin, hair = d.hair, shirt = d.shirt, pants = d.pants;

  c.save();
  c.translate(seatX + lean * 1.5, seatY + bodyY);
  c.scale(sc, sc);
  c.rotate(bodyRot);

  // ---- SEAT (simple 2D) ----
  c.fillStyle = '#1e1e28';
  c.fillRect(-14, 2, 6, 26);
  c.fillStyle = '#2a2a38';
  c.fillRect(-10, -2, 20, 6);

  // ---- LEGS (2D side-view, knees forward) ----
  c.fillStyle = pants;
  // Thigh
  c.beginPath();
  c.moveTo(-4, 2); c.lineTo(12, 0 + legKick * 0.3); c.lineTo(14, 7); c.lineTo(-2, 8); c.closePath();
  c.fill();
  // Shin toward pedals
  c.beginPath();
  c.moveTo(12, 1); c.lineTo(22, -4 + legKick); c.lineTo(24, 0); c.lineTo(14, 7); c.closePath();
  c.fill();
  // Shoe
  c.fillStyle = '#1a1a1a';
  c.beginPath(); c.ellipse(23, -2 + legKick * 0.5, 5.5, 2.8, 0.2, 0, 7); c.fill();
  // Far leg hint
  c.globalAlpha = 0.55;
  c.fillStyle = pants;
  c.beginPath();
  c.moveTo(-2, 4); c.lineTo(10, 2); c.lineTo(12, 7); c.lineTo(0, 8); c.closePath();
  c.fill();
  c.globalAlpha = 1;

  // ---- HIPS ----
  c.fillStyle = pants;
  c.fillRect(-8, 2, 14, 8);
  // Belt
  c.fillStyle = '#2c1810'; c.fillRect(-7, 8, 12, 2);
  c.fillStyle = '#c9a227'; c.fillRect(-1, 7.5, 3, 3);

  // ---- TORSO (2D chest facing forward) ----
  c.fillStyle = shirt;
  c.beginPath();
  c.moveTo(-7, 8);
  c.lineTo(-6, 26);
  c.lineTo(5, 27);
  c.lineTo(7, 12);
  c.lineTo(3, 8);
  c.closePath();
  c.fill();
  // Simple chest highlight strip (front plane)
  c.fillStyle = 'rgba(255,255,255,0.15)';
  c.fillRect(2, 12, 3, 12);
  // Collar
  c.fillStyle = shadeColor(shirt, -25);
  c.beginPath();
  c.moveTo(-3, 24); c.lineTo(0, 28); c.lineTo(4, 25); c.lineTo(2, 23); c.closePath();
  c.fill();

  // ---- NECK ----
  c.fillStyle = skin;
  c.fillRect(-1, 26, 5, 6);

  // ---- HEAD (2D side-view face sprite) ----
  c.save();
  c.translate(1 + lean * 0.8, 36 + headY);
  c.rotate(headRot);

  // Head circle
  c.fillStyle = skin;
  c.beginPath(); c.arc(2, 0, 8, 0, 7); c.fill();

  // Face plane toward +X (simple profile wedge)
  c.beginPath();
  c.moveTo(6, -5);
  c.lineTo(11, -1);   // nose tip
  c.lineTo(10, 3);
  c.lineTo(7, 6);
  c.lineTo(4, 6);
  c.closePath();
  c.fill();

  // Nose
  c.beginPath();
  c.moveTo(9, -1); c.lineTo(12, 0.5); c.lineTo(9, 2); c.closePath();
  c.fill();

  // Eye
  if (pose === 'crash') {
    c.strokeStyle = '#222'; c.lineWidth = 1.6; c.lineCap = 'round';
    c.beginPath(); c.moveTo(7, -2); c.lineTo(10, 1); c.moveTo(10, -2); c.lineTo(7, 1); c.stroke();
  } else {
    c.fillStyle = '#fff';
    c.beginPath(); c.ellipse(8.5, -0.5, 2.2, 2.5, 0, 0, 7); c.fill();
    c.fillStyle = '#1a1008';
    c.beginPath(); c.arc(9.2, -0.2, 1.1, 0, 7); c.fill();
    // Blink occasionally
    if (Math.sin(T * 0.7) > 0.92) {
      c.fillStyle = skin;
      c.fillRect(6.5, -1.5, 4, 2);
    }
  }

  // Mouth
  c.strokeStyle = pose === 'jump' || pose === 'crash' ? '#a04040' : '#6b3a2a';
  c.lineWidth = 1.3; c.lineCap = 'round';
  c.beginPath();
  if (pose === 'jump' || pose === 'crash') {
    c.fillStyle = '#5a2020';
    c.beginPath(); c.ellipse(9, 4, 2, 1.5, 0, 0, 7); c.fill();
  } else {
    c.moveTo(7.5, 4); c.quadraticCurveTo(9, 5, 10.5, 4); c.stroke();
  }

  // Ear
  c.fillStyle = shadeColor(skin, -10);
  c.beginPath(); c.ellipse(-3, 0, 2, 2.8, 0, 0, 7); c.fill();

  // Hair (2D sprite style)
  c.fillStyle = hair;
  if (isF) {
    c.beginPath(); c.ellipse(1, -4, 8, 5.5, 0, Math.PI, 0); c.fill();
    c.beginPath();
    c.moveTo(-5, -2); c.lineTo(-7, 10); c.lineTo(-3, 8); c.lineTo(-1, 0); c.closePath();
    c.fill();
  } else {
    c.beginPath(); c.ellipse(1, -5, 7.5, 5, 0, Math.PI * 1.05, 0); c.fill();
    c.fillRect(-4, -6, 10, 4);
  }

  c.restore(); // head

  // ---- ARMS → steering wheel (2D) ----
  const wx = 14, wy = 10;
  const aOff = armSpread;

  // Far arm
  c.globalAlpha = 0.7;
  c.strokeStyle = shirt; c.lineWidth = 5; c.lineCap = 'round';
  c.beginPath();
  c.moveTo(1, 22);
  c.quadraticCurveTo(6 + aOff * 4, 16, wx + 2, wy - 6 + aOff * 2);
  c.stroke();
  c.strokeStyle = skin; c.lineWidth = 3.5;
  c.beginPath();
  c.moveTo(wx + 2, wy - 6 + aOff * 2); c.lineTo(wx + 1, wy - 1); c.stroke();
  c.globalAlpha = 1;

  // Near arm
  c.strokeStyle = shirt; c.lineWidth = 5.5; c.lineCap = 'round';
  c.beginPath();
  c.moveTo(2, 23);
  c.quadraticCurveTo(8 + aOff * 5, 17, wx - 2, wy + 7 + aOff * 3);
  c.stroke();
  c.strokeStyle = skin; c.lineWidth = 4;
  c.beginPath();
  c.moveTo(wx - 2, wy + 7 + aOff * 3); c.lineTo(wx - 1, wy + 2); c.stroke();

  // ---- STEERING WHEEL (2D ellipse) + hands ----
  c.save();
  c.translate(wx, wy);
  c.rotate(steer * 0.6 + (air > 0.2 ? Math.sin(T * 9) * 0.05 : 0));

  c.strokeStyle = '#1a1a1a'; c.lineWidth = 3;
  c.beginPath(); c.ellipse(0, 0, 5, 10.5, 0, 0, 7); c.stroke();
  c.strokeStyle = '#444'; c.lineWidth = 1.5;
  c.beginPath(); c.ellipse(0, 0, 3.5, 8.5, 0, 0, 7); c.stroke();
  c.fillStyle = '#2a2a2a';
  c.beginPath(); c.arc(0, 0, 2.2, 0, 7); c.fill();
  c.strokeStyle = '#555'; c.lineWidth = 1.8;
  c.beginPath(); c.moveTo(0, -8); c.lineTo(0, 8); c.stroke();

  // Hands on wheel
  c.fillStyle = skin;
  c.beginPath(); c.ellipse(-1, 8 + aOff * 1.5, 3.5, 2.6, 0.25, 0, 7); c.fill();
  c.beginPath(); c.ellipse(0, -8 + aOff * 1.5, 3.5, 2.6, -0.25, 0, 7); c.fill();

  c.restore(); // wheel
  c.restore(); // driver root
}

function shadeColor(hex, amt) {
  if (!hex || hex[0] !== '#' || hex.length < 7) return hex || '#888';
  let r = parseInt(hex.slice(1, 3), 16);
  let g = parseInt(hex.slice(3, 5), 16);
  let b = parseInt(hex.slice(5, 7), 16);
  r = Math.max(0, Math.min(255, r + amt));
  g = Math.max(0, Math.min(255, g + amt));
  b = Math.max(0, Math.min(255, b + amt));
  return '#' + (r | 0).toString(16).padStart(2, '0') + (g | 0).toString(16).padStart(2, '0') + (b | 0).toString(16).padStart(2, '0');
}

function paintGrad(c, x0, y0, x1, y1, c0, c1) {
  const g = c.createLinearGradient(x0, y0, x1, y1);
  g.addColorStop(0, c0); g.addColorStop(1, c1);
  return g;
}
function glassGrad(c, x, y, w, h) {
  const g = c.createLinearGradient(x, y, x, y + h);
  g.addColorStop(0, 'rgba(180,220,255,0.85)');
  g.addColorStop(0.5, 'rgba(100,160,210,0.7)');
  g.addColorStop(1, 'rgba(40,80,120,0.55)');
  return g;
}
function drawBody(c, v) {
  const st = v.style || 'jeep';
  const crashed = S && S.crashed;
  const col = v.color, dark = v.dark, stripe = v.stripe;
  const bodyPaint = () => paintGrad(c, 0, 28, 0, -12, col, dark);
  const metalHi = () => paintGrad(c, 0, 20, 0, -5, 'rgba(255,255,255,0.28)', 'rgba(255,255,255,0)');
  const chrome = '#c0c8d0';

  // Shared under-chassis shadow
  c.fillStyle = 'rgba(0,0,0,0.22)';
  c.beginPath(); c.ellipse(0, -6, 58, 8, 0, 0, 7); c.fill();

  // ========== JEEP / SUV / PICKUP (Hill Climber family) ==========
  if (st === 'jeep' || st === 'suv' || st === 'pickup') {
    // Frame rails
    c.fillStyle = '#1a1a1a';
    c.fillRect(-56, -8, 112, 5);
    // Main body shell
    c.beginPath();
    c.moveTo(-58, -8);
    c.lineTo(50, -10);
    c.quadraticCurveTo(62, -6, 64, 2);
    c.lineTo(48, 10);
    c.lineTo(30, 28);
    c.lineTo(-16, 28);
    c.lineTo(-30, 12);
    c.lineTo(-58, 6);
    c.closePath();
    c.fillStyle = bodyPaint(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2.2; c.stroke();
    // Roof panel
    c.fillStyle = metalHi();
    c.beginPath();
    c.moveTo(-18, 14); c.lineTo(28, 14); c.lineTo(26, 26); c.lineTo(-14, 26); c.closePath();
    c.fill();
    // Body stripe
    c.fillStyle = stripe; c.globalAlpha = 0.85; c.fillRect(-50, 0, 100, 3.5); c.globalAlpha = 1;
    // Fender arches
    c.strokeStyle = dark; c.lineWidth = 2.5;
    c.beginPath(); c.arc(-42, -6, 16, 0.2, Math.PI - 0.2); c.stroke();
    c.beginPath(); c.arc(38, -6, 16, 0.2, Math.PI - 0.2); c.stroke();
    // Windshield
    c.fillStyle = glassGrad(c, 12, 12, 18, 14);
    c.beginPath(); c.moveTo(30, 12); c.lineTo(24, 26); c.lineTo(8, 26); c.lineTo(12, 12); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.4)'; c.lineWidth = 1.2; c.stroke();
    // Side window
    c.fillStyle = 'rgba(100,170,220,0.5)';
    c.fillRect(-10, 15, 18, 9);
    c.strokeStyle = 'rgba(255,255,255,0.25)'; c.lineWidth = 1; c.strokeRect(-10, 15, 18, 9);
    // Door line
    c.strokeStyle = 'rgba(0,0,0,0.25)'; c.lineWidth = 1.2;
    c.beginPath(); c.moveTo(-6, -6); c.lineTo(-6, 14); c.stroke();
    // Door handle
    c.fillStyle = chrome; c.fillRect(-4, 4, 5, 2);
    // Bumpers
    c.fillStyle = '#2a2a2a';
    c.fillRect(58, -3, 10, 9);
    c.fillRect(-64, -1, 8, 7);
    // Grill
    c.fillStyle = '#1a1a1a'; c.fillRect(52, -2, 6, 8);
    c.strokeStyle = chrome; c.lineWidth = 0.8;
    for (let i = 0; i < 4; i++) { c.beginPath(); c.moveTo(53, -1 + i * 2); c.lineTo(57, -1 + i * 2); c.stroke(); }
    // Headlights
    c.fillStyle = '#fff8dc'; c.beginPath(); c.arc(60, 2, 4.5, 0, 7); c.fill();
    c.fillStyle = 'rgba(255,255,200,0.5)'; c.beginPath(); c.arc(60, 2, 6, 0, 7); c.fill();
    // Taillight
    c.fillStyle = '#ff3b30'; c.beginPath(); c.arc(-58, 2, 3.5, 0, 7); c.fill();
    // Side mirror
    c.fillStyle = '#333'; c.fillRect(22, 18, 6, 3);
    if (st === 'pickup') {
      c.fillStyle = dark; c.globalAlpha = 0.65;
      c.fillRect(-20, 6, 52, 16); c.globalAlpha = 1;
      c.strokeStyle = 'rgba(0,0,0,0.3)'; c.strokeRect(-20, 6, 52, 16);
    }
    if (st === 'suv') {
      c.fillStyle = 'rgba(0,0,0,0.12)'; c.fillRect(-36, 8, 70, 16);
      // Roof rails
      c.strokeStyle = '#555'; c.lineWidth = 2;
      c.beginPath(); c.moveTo(-14, 28); c.lineTo(24, 28); c.stroke();
    }
  }

  // ========== SPORTS / SUPER / RACE ==========
  else if (st === 'sport' || st === 'super' || st === 'race') {
    c.beginPath();
    c.moveTo(-54, -4);
    c.quadraticCurveTo(-40, -10, 20, -12);
    c.quadraticCurveTo(50, -10, 64, -2);
    c.lineTo(56, 8);
    c.quadraticCurveTo(40, 16, 28, 18);
    c.lineTo(-10, 18);
    c.quadraticCurveTo(-30, 10, -54, 4);
    c.closePath();
    c.fillStyle = bodyPaint(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2; c.stroke();
    // Hood highlight
    c.fillStyle = metalHi();
    c.beginPath(); c.moveTo(-30, 2); c.lineTo(40, 0); c.lineTo(36, 10); c.lineTo(-26, 10); c.closePath(); c.fill();
    // Stripe
    c.fillStyle = stripe; c.fillRect(-48, 2, 92, 2.5);
    // Cabin / canopy
    c.fillStyle = glassGrad(c, 6, 6, 18, 12);
    c.beginPath(); c.moveTo(26, 6); c.lineTo(18, 17); c.lineTo(2, 17); c.lineTo(8, 6); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.35)'; c.lineWidth = 1; c.stroke();
    // Side intake
    c.fillStyle = '#1a1a1a';
    c.beginPath(); c.moveTo(-20, 0); c.lineTo(-8, 0); c.lineTo(-10, 8); c.lineTo(-22, 6); c.closePath(); c.fill();
    // Spoiler
    if (st !== 'sport') {
      c.fillStyle = dark;
      c.fillRect(-54, 12, 18, 3.5);
      c.fillRect(-52, 8, 3, 8);
      c.fillRect(-40, 8, 3, 8);
    }
    // Diffuser vents
    c.fillStyle = '#111';
    for (let i = 0; i < 4; i++) c.fillRect(-50 + i * 4, -2, 2, 5);
    // Headlights (slim)
    c.fillStyle = '#e8f4ff';
    c.beginPath(); c.ellipse(56, 0, 6, 3, 0, 0, 7); c.fill();
    c.fillStyle = '#ff3b30';
    c.beginPath(); c.ellipse(-52, 2, 4, 2.5, 0, 0, 7); c.fill();
    // Side skirt
    c.fillStyle = dark; c.fillRect(-48, -6, 96, 3);
  }

  // ========== FORMULA ==========
  else if (st === 'f1') {
    // Nose cone
    c.beginPath();
    c.moveTo(-48, 0); c.lineTo(30, -6); c.lineTo(58, 0); c.lineTo(40, 6);
    c.lineTo(16, 12); c.lineTo(-16, 12); c.lineTo(-36, 4); c.closePath();
    c.fillStyle = bodyPaint(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 1.5; c.stroke();
    c.fillStyle = stripe; c.fillRect(-36, 3, 64, 2);
    // Front wing
    c.fillStyle = dark;
    c.fillRect(40, -6, 26, 3);
    c.fillRect(42, -10, 3, 8);
    c.fillRect(60, -10, 3, 8);
    // Rear wing
    c.fillRect(-60, 6, 22, 3.5);
    c.fillRect(-58, 2, 3, 10);
    c.fillRect(-42, 2, 3, 10);
    // Cockpit
    c.fillStyle = '#0a0a0a'; c.fillRect(-12, 8, 20, 12);
    c.fillStyle = 'rgba(80,140,200,0.4)'; c.fillRect(-10, 10, 16, 8);
    // Side pods
    c.fillStyle = dark;
    c.beginPath(); c.ellipse(-8, 2, 14, 6, 0, 0, 7); c.fill();
    c.beginPath(); c.ellipse(18, 0, 12, 5, 0, 0, 7); c.fill();
    // Halo
    c.strokeStyle = chrome; c.lineWidth = 2.5;
    c.beginPath(); c.arc(0, 16, 10, 0.4, Math.PI - 0.4); c.stroke();
  }

  // ========== MONSTER TRUCK ==========
  else if (st === 'monster') {
    // Heavy chassis
    c.fillStyle = '#1a1a1a';
    c.fillRect(-54, -10, 108, 8);
    // Body
    c.beginPath();
    c.moveTo(-54, -6); c.lineTo(54, -6); c.lineTo(58, 8); c.lineTo(34, 14);
    c.lineTo(20, 30); c.lineTo(-14, 30); c.lineTo(-30, 14); c.lineTo(-54, 8); c.closePath();
    c.fillStyle = bodyPaint(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2.5; c.stroke();
    c.fillStyle = stripe; c.fillRect(-46, 2, 92, 4);
    // Massive suspension arms
    c.strokeStyle = '#555'; c.lineWidth = 4;
    c.beginPath(); c.moveTo(-40, -6); c.lineTo(-48, -22); c.stroke();
    c.beginPath(); c.moveTo(36, -6); c.lineTo(44, -22); c.stroke();
    c.strokeStyle = '#888'; c.lineWidth = 2.5;
    c.beginPath(); c.moveTo(-36, -6); c.lineTo(-42, -20); c.stroke();
    c.beginPath(); c.moveTo(32, -6); c.lineTo(38, -20); c.stroke();
    // Shock absorbers
    c.fillStyle = '#c00'; c.fillRect(-45, -18, 5, 12); c.fillRect(39, -18, 5, 12);
    // Roll cage
    c.strokeStyle = '#d0d4d8'; c.lineWidth = 3.5;
    c.beginPath(); c.moveTo(-18, 10); c.lineTo(-18, 32); c.lineTo(16, 32); c.lineTo(16, 10); c.stroke();
    c.beginPath(); c.moveTo(-18, 22); c.lineTo(16, 22); c.stroke();
    // Cabin glass
    c.fillStyle = glassGrad(c, -12, 14, 24, 12);
    c.fillRect(-14, 14, 28, 12);
    c.strokeStyle = 'rgba(255,255,255,0.3)'; c.strokeRect(-14, 14, 28, 12);
    // Headlights
    c.fillStyle = '#fff8dc'; c.beginPath(); c.arc(54, 4, 5, 0, 7); c.fill();
    c.fillStyle = '#ff3b30'; c.beginPath(); c.arc(-52, 4, 4, 0, 7); c.fill();
  }

  // ========== TRACTOR ==========
  else if (st === 'tractor') {
    // Engine hood
    c.beginPath();
    c.moveTo(-20, -4); c.lineTo(44, -4); c.quadraticCurveTo(52, 0, 50, 10);
    c.lineTo(20, 14); c.lineTo(-16, 14); c.closePath();
    c.fillStyle = bodyPaint(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2.2; c.stroke();
    // Hood vents
    c.strokeStyle = dark; c.lineWidth = 1.2;
    for (let i = 0; i < 5; i++) {
      c.beginPath(); c.moveTo(0 + i * 7, 0); c.lineTo(0 + i * 7, 8); c.stroke();
    }
    // Exhaust stack
    c.fillStyle = '#333'; c.fillRect(30, 10, 5, 22);
    c.fillStyle = '#555'; c.beginPath(); c.arc(32.5, 32, 4, 0, 7); c.fill();
    // Cabin
    c.fillStyle = '#2a2a2a';
    c.beginPath(); c.moveTo(-20, 8); c.lineTo(-18, 30); c.lineTo(12, 30); c.lineTo(16, 8); c.closePath(); c.fill();
    c.fillStyle = glassGrad(c, -16, 12, 26, 14);
    c.fillRect(-16, 12, 26, 14);
    c.strokeStyle = chrome; c.lineWidth = 1.5; c.strokeRect(-16, 12, 26, 14);
    // Front weight / grill
    c.fillStyle = '#1a1a1a'; c.fillRect(44, -2, 10, 12);
    c.strokeStyle = chrome; c.lineWidth = 1;
    for (let i = 0; i < 4; i++) { c.beginPath(); c.moveTo(45, i * 3); c.lineTo(53, i * 3); c.stroke(); }
    // Headlight
    c.fillStyle = '#fff8dc'; c.fillRect(48, 2, 5, 4);
    // Hitch
    c.fillStyle = '#444'; c.fillRect(-28, 0, 10, 6);
  }

  // ========== DIRT BIKE / MONSTER BIKE ==========
  else if (st === 'bike' || st === 'mbike') {
    // Frame
    c.strokeStyle = col; c.lineWidth = 4; c.lineCap = 'round';
    c.beginPath(); c.moveTo(-28, 2); c.lineTo(8, 10); c.lineTo(28, 2); c.stroke();
    c.beginPath(); c.moveTo(8, 10); c.lineTo(8, -4); c.stroke();
    c.beginPath(); c.moveTo(-28, 2); c.lineTo(-10, -6); c.lineTo(8, -4); c.stroke();
    // Engine block
    c.fillStyle = '#2a2a2a';
    c.beginPath(); c.roundRect(-8, -2, 18, 12, 2); c.fill();
    c.fillStyle = '#444'; c.fillRect(-6, 2, 14, 4);
    // Fuel tank
    c.fillStyle = bodyPaint();
    c.beginPath();
    c.moveTo(-12, 4); c.quadraticCurveTo(0, 14, 14, 6); c.lineTo(12, 2); c.quadraticCurveTo(0, 8, -10, 2); c.closePath();
    c.fill();
    c.strokeStyle = dark; c.lineWidth = 1.5; c.stroke();
    // Seat
    c.fillStyle = '#1a1a1a';
    c.beginPath(); c.moveTo(-20, 6); c.lineTo(6, 8); c.lineTo(4, 12); c.lineTo(-18, 10); c.closePath(); c.fill();
    // Forks
    c.strokeStyle = chrome; c.lineWidth = 3;
    c.beginPath(); c.moveTo(28, 2); c.lineTo(36, -12); c.stroke();
    c.beginPath(); c.moveTo(30, 2); c.lineTo(38, -12); c.stroke();
    // Handlebars
    c.strokeStyle = '#333'; c.lineWidth = 2.5;
    c.beginPath(); c.moveTo(34, -10); c.lineTo(42, -6); c.stroke();
    c.beginPath(); c.moveTo(34, -10); c.lineTo(28, -4); c.stroke();
    // Exhaust
    c.fillStyle = '#555';
    c.beginPath(); c.moveTo(0, -2); c.lineTo(-32, -8); c.lineTo(-30, -4); c.lineTo(2, 0); c.closePath(); c.fill();
    // Chain
    c.strokeStyle = '#888'; c.lineWidth = 1.5;
    c.beginPath(); c.moveTo(-24, 0); c.lineTo(4, 4); c.stroke();
    if (st === 'mbike') {
      // Oversized fenders
      c.fillStyle = dark;
      c.fillRect(-40, -8, 16, 8);
      c.fillRect(24, -6, 18, 6);
    }
    // Headlight
    c.fillStyle = '#fff8dc'; c.beginPath(); c.arc(34, 0, 3.5, 0, 7); c.fill();
  }

  // ========== QUAD / DUNE BUGGY ==========
  else if (st === 'quad') {
    // Roll cage
    c.strokeStyle = chrome; c.lineWidth = 3.5;
    c.beginPath(); c.moveTo(-30, 0); c.lineTo(-28, 22); c.lineTo(28, 22); c.lineTo(30, 0); c.stroke();
    c.beginPath(); c.moveTo(-28, 12); c.lineTo(28, 12); c.stroke();
    c.beginPath(); c.moveTo(0, 0); c.lineTo(0, 22); c.stroke();
    // Body tub
    c.fillStyle = bodyPaint();
    c.beginPath();
    c.moveTo(-42, -2); c.lineTo(42, -2); c.lineTo(46, 8); c.lineTo(16, 14);
    c.lineTo(-16, 14); c.lineTo(-46, 8); c.closePath(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2; c.stroke();
    // Seat
    c.fillStyle = '#1a1a1a'; c.fillRect(-12, 4, 24, 8);
    // Front bumper / A-arm hint
    c.fillStyle = '#333'; c.fillRect(40, 0, 10, 6);
    c.strokeStyle = '#555'; c.lineWidth = 2.5;
    c.beginPath(); c.moveTo(36, -2); c.lineTo(48, -10); c.stroke();
    c.beginPath(); c.moveTo(-36, -2); c.lineTo(-48, -10); c.stroke();
    c.fillStyle = '#fff8dc'; c.fillRect(44, 2, 5, 3);
  }

  // ========== BUS / SCHOOL BUS ==========
  else if (st === 'bus' || st === 'sbus') {
    c.fillStyle = bodyPaint();
    c.beginPath();
    c.moveTo(-74, -8); c.lineTo(70, -8); c.lineTo(74, 4); c.lineTo(70, 22);
    c.lineTo(-74, 22); c.closePath(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2.5; c.stroke();
    // Stripe
    c.fillStyle = stripe; c.fillRect(-70, 4, 140, 5);
    // Windows
    c.fillStyle = glassGrad(c, -60, 2, 20, 12);
    for (let i = 0; i < 5; i++) {
      c.fillRect(-60 + i * 26, 8, 20, 10);
      c.strokeStyle = 'rgba(255,255,255,0.25)'; c.lineWidth = 1;
      c.strokeRect(-60 + i * 26, 8, 20, 10);
    }
    // Door
    c.strokeStyle = 'rgba(0,0,0,0.3)'; c.lineWidth = 1.5;
    c.strokeRect(48, -6, 16, 26);
    // Bumpers
    c.fillStyle = '#2a2a2a';
    c.fillRect(70, -4, 8, 12); c.fillRect(-78, -2, 6, 10);
    c.fillStyle = '#fff8dc'; c.fillRect(72, 2, 5, 5);
    c.fillStyle = '#ff3b30'; c.fillRect(-76, 4, 4, 4);
    if (st === 'sbus') {
      c.fillStyle = '#1a1a1a';
      c.font = 'bold 8px sans-serif'; c.textAlign = 'center';
      c.fillText('SCHOOL', 0, 2);
    }
  }

  // ========== POLICE ==========
  else if (st === 'police') {
    c.beginPath();
    c.moveTo(-56, -8); c.lineTo(54, -10); c.lineTo(62, 2); c.lineTo(42, 10);
    c.lineTo(26, 24); c.lineTo(-14, 24); c.lineTo(-30, 10); c.lineTo(-56, 4); c.closePath();
    c.fillStyle = bodyPaint(); c.fill();
    c.strokeStyle = '#339af0'; c.lineWidth = 2.2; c.stroke();
    // White doors panel
    c.fillStyle = 'rgba(255,255,255,0.15)'; c.fillRect(-20, -4, 40, 16);
    // Light bar
    const blink = Math.sin(T * 14) > 0;
    c.fillStyle = blink ? '#e03131' : '#1a1a1a'; c.fillRect(-16, 18, 12, 5);
    c.fillStyle = blink ? '#1a1a1a' : '#339af0'; c.fillRect(4, 18, 12, 5);
    // Glass
    c.fillStyle = glassGrad(c, 12, 10, 16, 12);
    c.beginPath(); c.moveTo(28, 10); c.lineTo(22, 22); c.lineTo(6, 22); c.lineTo(10, 10); c.closePath(); c.fill();
    c.fillStyle = '#fff8dc'; c.beginPath(); c.arc(58, 0, 4, 0, 7); c.fill();
  }

  // ========== AMBULANCE ==========
  else if (st === 'ambu') {
    c.fillStyle = bodyPaint();
    c.fillRect(-64, -10, 128, 30);
    c.strokeStyle = dark; c.lineWidth = 2; c.strokeRect(-64, -10, 128, 30);
    // Red cross
    c.fillStyle = '#e03131';
    c.fillRect(-18, -4, 36, 8);
    c.fillRect(-6, -14, 12, 28);
    // Cabin glass
    c.fillStyle = glassGrad(c, 30, 0, 24, 14);
    c.fillRect(30, 0, 24, 14);
    c.fillStyle = '#fff8dc'; c.fillRect(58, -2, 6, 5);
    // Emergency light
    const ab = Math.sin(T * 12) > 0;
    c.fillStyle = ab ? '#e03131' : '#fff'; c.fillRect(-8, 18, 16, 4);
  }

  // ========== FIRE TRUCK ==========
  else if (st === 'fire') {
    c.fillStyle = bodyPaint();
    c.fillRect(-68, -10, 136, 30);
    c.strokeStyle = dark; c.lineWidth = 2.5; c.strokeRect(-68, -10, 136, 30);
    // Cabin windows
    c.fillStyle = '#f8f9fa';
    c.fillRect(-54, 2, 30, 12); c.fillRect(6, 2, 30, 12);
    c.fillStyle = glassGrad(c, -50, 4, 22, 8);
    c.fillRect(-50, 4, 22, 8); c.fillRect(10, 4, 22, 8);
    // Ladder
    c.fillStyle = '#495057'; c.fillRect(48, -22, 8, 26);
    c.strokeStyle = '#888'; c.lineWidth = 1.5;
    for (let i = 0; i < 5; i++) {
      c.beginPath(); c.moveTo(48, -18 + i * 5); c.lineTo(56, -18 + i * 5); c.stroke();
    }
    c.fillStyle = '#fff8dc'; c.fillRect(62, 0, 6, 5);
  }

  // ========== MILITARY TRUCK ==========
  else if (st === 'mil') {
    c.fillStyle = bodyPaint();
    c.fillRect(-64, -8, 128, 26);
    c.strokeStyle = dark; c.lineWidth = 2; c.strokeRect(-64, -8, 128, 26);
    c.fillStyle = stripe; c.fillRect(-58, 4, 116, 3);
    // Canvas cover
    c.fillStyle = '#3a4a2a';
    c.beginPath(); c.moveTo(-30, 8); c.lineTo(-28, 24); c.lineTo(40, 24); c.lineTo(42, 8); c.closePath(); c.fill();
    // Cabin
    c.fillStyle = '#2a2a2a'; c.fillRect(-20, 8, 28, 14);
    c.fillStyle = glassGrad(c, -16, 10, 20, 10); c.fillRect(-16, 10, 20, 10);
    c.fillStyle = '#fff8dc'; c.fillRect(58, 0, 5, 4);
  }

  // ========== TANK ==========
  else if (st === 'tank') {
    // Hull
    c.fillStyle = bodyPaint();
    c.beginPath();
    c.moveTo(-58, -4); c.lineTo(58, -4); c.lineTo(62, 8); c.lineTo(50, 18);
    c.lineTo(-50, 18); c.lineTo(-62, 8); c.closePath(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2.5; c.stroke();
    // Turret
    c.fillStyle = dark;
    c.beginPath(); c.ellipse(0, 12, 20, 14, 0, 0, 7); c.fill();
    // Barrel
    c.fillStyle = '#3a4a20';
    c.fillRect(12, 10, 54, 6);
    c.fillStyle = '#2a3514'; c.beginPath(); c.arc(66, 13, 4, 0, 7); c.fill();
    // Tracks hint
    c.fillStyle = '#1a1a1a'; c.fillRect(-56, -6, 112, 5);
    c.fillRect(-56, 16, 112, 5);
    // Road wheels under hull
    c.fillStyle = '#333';
    for (let i = 0; i < 5; i++) {
      c.beginPath(); c.arc(-40 + i * 20, -2, 5, 0, 7); c.fill();
    }
  }

  // ========== EXCAVATOR / BULLDOZER ==========
  else if (st === 'exca' || st === 'dozer') {
    c.fillStyle = bodyPaint();
    c.fillRect(-52, -6, 94, 24);
    c.strokeStyle = dark; c.lineWidth = 2; c.strokeRect(-52, -6, 94, 24);
    // Cabin
    c.fillStyle = '#2a2a2a'; c.fillRect(-16, 8, 30, 16);
    c.fillStyle = glassGrad(c, -12, 10, 22, 12); c.fillRect(-12, 10, 22, 12);
    if (st === 'dozer') {
      // Blade
      c.fillStyle = '#555'; c.fillRect(42, -16, 10, 36);
      c.fillStyle = '#888'; c.fillRect(50, -20, 22, 12);
      c.strokeStyle = '#333'; c.lineWidth = 2; c.strokeRect(50, -20, 22, 12);
    } else {
      // Boom + arm + bucket
      c.strokeStyle = '#555'; c.lineWidth = 6; c.lineCap = 'round';
      c.beginPath(); c.moveTo(28, 8); c.lineTo(52, 28); c.stroke();
      c.strokeStyle = '#666'; c.lineWidth = 5;
      c.beginPath(); c.moveTo(52, 28); c.lineTo(72, 14); c.stroke();
      c.fillStyle = '#777';
      c.beginPath(); c.moveTo(68, 10); c.lineTo(80, 8); c.lineTo(78, 20); c.lineTo(66, 18); c.closePath(); c.fill();
    }
  }

  // ========== CEMENT MIXER ==========
  else if (st === 'mixer') {
    c.fillStyle = bodyPaint();
    c.fillRect(-56, -8, 100, 26);
    c.strokeStyle = dark; c.lineWidth = 2; c.strokeRect(-56, -8, 100, 26);
    // Drum
    const drumG = paintGrad(c, 20, 22, 20, -4, '#ced4da', '#868e96');
    c.fillStyle = drumG;
    c.beginPath(); c.ellipse(24, 10, 32, 18, 0.3, 0, 7); c.fill();
    c.strokeStyle = '#495057'; c.lineWidth = 2; c.stroke();
    c.strokeStyle = 'rgba(0,0,0,0.2)'; c.lineWidth = 1.5;
    for (let i = -2; i <= 2; i++) {
      c.beginPath(); c.ellipse(24, 10, 32, 18, 0.3 + i * 0.12, 0, 7); c.stroke();
    }
    // Cabin
    c.fillStyle = glassGrad(c, -50, 0, 20, 12); c.fillRect(-50, 2, 18, 12);
  }

  // ========== SNOWMOBILE ==========
  else if (st === 'snow') {
    c.fillStyle = bodyPaint();
    c.beginPath();
    c.moveTo(-44, 0); c.lineTo(38, -6); c.lineTo(50, 4); c.lineTo(16, 12);
    c.lineTo(-30, 12); c.closePath(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2; c.stroke();
    // Windshield
    c.fillStyle = glassGrad(c, -6, 6, 18, 6); c.fillRect(-6, 6, 18, 6);
    // Ski tips hint
    c.strokeStyle = '#888'; c.lineWidth = 2.5;
    c.beginPath(); c.moveTo(40, 0); c.lineTo(54, -4); c.stroke();
    c.fillStyle = '#1a1a1a'; c.fillRect(-10, 2, 18, 6);
  }

  // ========== HELICOPTER ==========
  else if (st === 'heli') {
    c.fillStyle = bodyPaint();
    c.beginPath();
    c.moveTo(-36, 0); c.lineTo(28, -6); c.lineTo(48, 4); c.lineTo(16, 16);
    c.lineTo(-28, 16); c.closePath(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2; c.stroke();
    // Tail boom
    c.fillStyle = dark; c.fillRect(-58, 4, 24, 4);
    c.fillRect(-62, -8, 4, 20);
    // Main rotor
    const ang = T * 20;
    c.save(); c.translate(0, 18); c.rotate(ang);
    c.strokeStyle = '#adb5bd'; c.lineWidth = 3.5;
    c.beginPath(); c.moveTo(-56, 0); c.lineTo(56, 0); c.stroke();
    c.beginPath(); c.moveTo(0, -56); c.lineTo(0, 56); c.stroke();
    c.restore();
    // Skids
    c.strokeStyle = '#495057'; c.lineWidth = 3;
    c.beginPath(); c.moveTo(-28, -6); c.lineTo(-28, -14); c.lineTo(22, -14); c.lineTo(22, -6); c.stroke();
    // Cabin glass
    c.fillStyle = glassGrad(c, -10, 4, 26, 10); c.fillRect(-10, 4, 26, 10);
  }

  // ========== HOVERCRAFT / SWAMP BOAT ==========
  else if (st === 'hover') {
    // Skirt
    c.fillStyle = '#2a2a2a';
    c.beginPath(); c.ellipse(0, -4, 58, 12, 0, 0, 7); c.fill();
    // Body
    c.fillStyle = bodyPaint();
    c.beginPath();
    c.moveTo(-48, 0); c.lineTo(44, -2); c.lineTo(52, 10); c.lineTo(16, 16);
    c.lineTo(-20, 16); c.lineTo(-52, 8); c.closePath(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2; c.stroke();
    // Fan / propeller cage
    c.strokeStyle = chrome; c.lineWidth = 2.5;
    c.beginPath(); c.arc(-40, 8, 12, 0, 7); c.stroke();
    const fang = T * 14;
    c.save(); c.translate(-40, 8); c.rotate(fang);
    c.strokeStyle = '#888'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(-10, 0); c.lineTo(10, 0); c.stroke();
    c.beginPath(); c.moveTo(0, -10); c.lineTo(0, 10); c.stroke();
    c.restore();
    c.fillStyle = glassGrad(c, 8, 6, 20, 8); c.fillRect(8, 6, 20, 8);
    c.fillStyle = stripe; c.fillRect(-30, 4, 60, 2.5);
  }

  // ========== HIPPIE VAN ==========
  else if (st === 'van') {
    c.fillStyle = bodyPaint();
    c.beginPath();
    c.moveTo(-58, -6); c.lineTo(50, -6); c.lineTo(56, 6); c.lineTo(50, 24);
    c.lineTo(-58, 24); c.closePath(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2.2; c.stroke();
    // Flower stripe
    c.fillStyle = stripe; c.fillRect(-52, 2, 100, 4);
    // Windows
    c.fillStyle = glassGrad(c, -40, 8, 16, 12);
    c.fillRect(-48, 8, 18, 12); c.fillRect(-24, 8, 18, 12); c.fillRect(0, 8, 18, 12);
    c.fillRect(30, 8, 16, 12);
    c.fillStyle = '#fff8dc'; c.fillRect(50, 0, 5, 4);
  }

  // ========== RALLY CAR ==========
  else if (st === 'rally') {
    c.beginPath();
    c.moveTo(-52, -6); c.lineTo(48, -10); c.lineTo(60, 0); c.lineTo(48, 10);
    c.lineTo(28, 20); c.lineTo(-12, 20); c.lineTo(-30, 8); c.lineTo(-52, 4); c.closePath();
    c.fillStyle = bodyPaint(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2; c.stroke();
    c.fillStyle = stripe; c.fillRect(-44, 2, 84, 3);
    // Hood vents
    c.fillStyle = '#1a1a1a';
    for (let i = 0; i < 3; i++) c.fillRect(10 + i * 8, 4, 5, 6);
    c.fillStyle = glassGrad(c, 8, 8, 16, 10);
    c.beginPath(); c.moveTo(26, 8); c.lineTo(18, 18); c.lineTo(4, 18); c.lineTo(8, 8); c.closePath(); c.fill();
    // Roof scoop
    c.fillStyle = dark; c.fillRect(-4, 18, 14, 4);
    c.fillStyle = '#fff8dc'; c.beginPath(); c.arc(56, 0, 4, 0, 7); c.fill();
  }

  // ========== CHOPPER ==========
  else if (st === 'chopper') {
    // Long frame
    c.strokeStyle = col; c.lineWidth = 4; c.lineCap = 'round';
    c.beginPath(); c.moveTo(-36, 0); c.lineTo(10, 6); c.lineTo(34, -2); c.stroke();
    c.beginPath(); c.moveTo(-20, 2); c.lineTo(-8, -8); c.lineTo(10, 6); c.stroke();
    // Fuel tank
    c.fillStyle = bodyPaint();
    c.beginPath(); c.ellipse(0, 4, 12, 6, 0, 0, 7); c.fill();
    // Seat
    c.fillStyle = '#1a1a1a';
    c.beginPath(); c.moveTo(-18, 4); c.lineTo(4, 8); c.lineTo(2, 12); c.lineTo(-16, 8); c.closePath(); c.fill();
    // Ape hangers
    c.strokeStyle = chrome; c.lineWidth = 2.5;
    c.beginPath(); c.moveTo(30, 0); c.lineTo(36, 14); c.lineTo(42, 12); c.stroke();
    // Forks extended
    c.strokeStyle = chrome; c.lineWidth = 3;
    c.beginPath(); c.moveTo(34, -2); c.lineTo(48, -16); c.stroke();
    // Engine
    c.fillStyle = '#333'; c.fillRect(-6, -4, 12, 8);
    c.fillStyle = '#fff8dc'; c.beginPath(); c.arc(34, 0, 3, 0, 7); c.fill();
  }

  // ========== LOWRIDER ==========
  else if (st === 'lowrider') {
    c.beginPath();
    c.moveTo(-54, -2); c.lineTo(52, -4); c.lineTo(60, 6); c.lineTo(40, 12);
    c.lineTo(24, 20); c.lineTo(-16, 20); c.lineTo(-32, 10); c.lineTo(-54, 6); c.closePath();
    c.fillStyle = bodyPaint(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2; c.stroke();
    // Chrome stripe
    c.fillStyle = chrome; c.fillRect(-48, 4, 96, 2);
    c.fillStyle = stripe; c.fillRect(-48, 6, 96, 2);
    // Wire wheels hint via body low stance
    c.fillStyle = glassGrad(c, 10, 8, 16, 10);
    c.beginPath(); c.moveTo(26, 8); c.lineTo(18, 18); c.lineTo(4, 18); c.lineTo(8, 8); c.closePath(); c.fill();
    // Hydraulics hint
    c.fillStyle = '#c00'; c.fillRect(-40, -4, 4, 6); c.fillRect(32, -4, 4, 6);
    c.fillStyle = '#fff8dc'; c.beginPath(); c.arc(56, 2, 4, 0, 7); c.fill();
  }

  // ========== HOT ROD ==========
  else if (st === 'hotrod') {
    c.beginPath();
    c.moveTo(-48, 0); c.lineTo(40, -8); c.lineTo(58, 0); c.lineTo(48, 10);
    c.lineTo(20, 14); c.lineTo(-20, 14); c.lineTo(-48, 8); c.closePath();
    c.fillStyle = bodyPaint(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2; c.stroke();
    // Exposed engine
    c.fillStyle = '#444';
    c.beginPath(); c.roundRect(8, 4, 22, 12, 2); c.fill();
    c.fillStyle = chrome;
    c.fillRect(12, 12, 4, 6); c.fillRect(22, 12, 4, 6);
    // Flat windshield
    c.fillStyle = glassGrad(c, -8, 8, 14, 6); c.fillRect(-8, 10, 14, 6);
    c.fillStyle = stripe; c.fillRect(-40, 2, 70, 2);
    c.fillStyle = '#fff8dc'; c.beginPath(); c.arc(54, 0, 3.5, 0, 7); c.fill();
  }

  // ========== MOON ROVER ==========
  else if (st === 'moon') {
    c.fillStyle = bodyPaint();
    c.beginPath();
    c.moveTo(-50, 0); c.lineTo(46, 0); c.lineTo(52, 12); c.lineTo(20, 18);
    c.lineTo(-20, 18); c.lineTo(-54, 10); c.closePath(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2; c.stroke();
    // Antenna
    c.strokeStyle = '#888'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(0, 18); c.lineTo(0, 32); c.stroke();
    c.fillStyle = '#e03131'; c.beginPath(); c.arc(0, 34, 3, 0, 7); c.fill();
    // Solar panel
    c.fillStyle = '#1c7ed6'; c.fillRect(-16, 14, 32, 6);
    c.strokeStyle = '#74c0fc'; c.lineWidth = 1;
    for (let i = 0; i < 4; i++) { c.beginPath(); c.moveTo(-16 + i * 8, 14); c.lineTo(-16 + i * 8, 20); c.stroke(); }
    c.fillStyle = glassGrad(c, -10, 4, 20, 8); c.fillRect(-10, 4, 20, 8);
    c.fillStyle = stripe; c.fillRect(-40, 6, 80, 2);
  }

  // ========== BIG FINGER ==========
  else if (st === 'finger') {
    // Giant finger-shaped body (fun vehicle)
    c.fillStyle = bodyPaint();
    c.beginPath();
    c.moveTo(-40, -4);
    c.quadraticCurveTo(-20, 30, 0, 36);
    c.quadraticCurveTo(20, 30, 40, -4);
    c.lineTo(48, 4); c.lineTo(30, 14); c.lineTo(-30, 14); c.lineTo(-48, 4);
    c.closePath(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2.5; c.stroke();
    // Knuckle lines
    c.strokeStyle = 'rgba(0,0,0,0.2)'; c.lineWidth = 2;
    c.beginPath(); c.moveTo(-15, 10); c.lineTo(-10, 28); c.stroke();
    c.beginPath(); c.moveTo(5, 12); c.lineTo(8, 30); c.stroke();
    c.fillStyle = glassGrad(c, -12, 4, 24, 8); c.fillRect(-12, 4, 24, 8);
  }

  // ========== ONE WHEELER ==========
  else if (st === 'onewheel') {
    // Platform over single big wheel (wheel drawn by physics)
    c.fillStyle = bodyPaint();
    c.beginPath();
    c.moveTo(-30, 4); c.lineTo(30, 4); c.lineTo(28, 14); c.lineTo(-28, 14); c.closePath();
    c.fill();
    c.strokeStyle = dark; c.lineWidth = 2; c.stroke();
    // Handlebar
    c.strokeStyle = chrome; c.lineWidth = 3;
    c.beginPath(); c.moveTo(0, 14); c.lineTo(0, 28); c.lineTo(12, 26); c.stroke();
    c.fillStyle = '#1a1a1a'; c.fillRect(-10, 6, 20, 6);
    c.fillStyle = stripe; c.fillRect(-24, 8, 48, 2);
  }

  // ========== RC BUGGY ==========
  else if (st === 'rc') {
    c.fillStyle = bodyPaint();
    c.beginPath();
    c.moveTo(-36, 0); c.lineTo(36, -2); c.lineTo(40, 8); c.lineTo(16, 14);
    c.lineTo(-16, 14); c.lineTo(-40, 6); c.closePath(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2; c.stroke();
    // Wing
    c.fillStyle = dark; c.fillRect(-32, 12, 20, 3);
    c.fillStyle = '#1a1a1a'; c.fillRect(-8, 4, 16, 6);
    c.fillStyle = '#fff8dc'; c.fillRect(34, 2, 4, 3);
    // Antenna
    c.strokeStyle = '#888'; c.lineWidth = 1.5;
    c.beginPath(); c.moveTo(8, 14); c.lineTo(8, 24); c.stroke();
  }

  // ========== ELECTRIC GT ==========
  else if (st === 'electric') {
    c.beginPath();
    c.moveTo(-52, -4); c.quadraticCurveTo(-20, -12, 40, -10);
    c.quadraticCurveTo(58, -6, 62, 2); c.lineTo(50, 10);
    c.quadraticCurveTo(30, 18, 16, 18); c.lineTo(-12, 18);
    c.quadraticCurveTo(-36, 10, -52, 4); c.closePath();
    c.fillStyle = bodyPaint(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2; c.stroke();
    // Light bar
    c.fillStyle = '#74c0fc'; c.fillRect(48, 0, 12, 3);
    c.fillStyle = glassGrad(c, 6, 6, 18, 10);
    c.beginPath(); c.moveTo(24, 6); c.lineTo(16, 16); c.lineTo(2, 16); c.lineTo(8, 6); c.closePath(); c.fill();
    c.fillStyle = stripe; c.fillRect(-40, 2, 76, 2);
    // Charge port
    c.fillStyle = '#333'; c.fillRect(-50, 2, 4, 6);
  }

  // ========== CLASSIC COUPE ==========
  else if (st === 'classic') {
    c.beginPath();
    c.moveTo(-52, -4); c.lineTo(48, -6); c.lineTo(58, 4); c.lineTo(40, 12);
    c.lineTo(22, 22); c.lineTo(-14, 22); c.lineTo(-30, 10); c.lineTo(-52, 6); c.closePath();
    c.fillStyle = bodyPaint(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2.2; c.stroke();
    // Running board
    c.fillStyle = chrome; c.fillRect(-44, -2, 88, 2.5);
    c.fillStyle = glassGrad(c, 8, 10, 16, 10);
    c.beginPath(); c.moveTo(26, 10); c.lineTo(18, 20); c.lineTo(4, 20); c.lineTo(8, 10); c.closePath(); c.fill();
    c.fillStyle = '#fff8dc'; c.beginPath(); c.arc(54, 2, 4, 0, 7); c.fill();
    c.fillStyle = '#ff3b30'; c.beginPath(); c.arc(-50, 4, 3, 0, 7); c.fill();
  }

  // ========== ROCKET RACER ==========
  else if (st === 'rocket') {
    c.beginPath();
    c.moveTo(-40, 0); c.lineTo(30, -8); c.lineTo(58, 0); c.lineTo(40, 8);
    c.lineTo(16, 14); c.lineTo(-20, 14); c.lineTo(-40, 6); c.closePath();
    c.fillStyle = bodyPaint(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2; c.stroke();
    // Rocket nozzles
    c.fillStyle = '#333';
    c.beginPath(); c.ellipse(-42, 2, 8, 5, 0, 0, 7); c.fill();
    c.beginPath(); c.ellipse(-42, 8, 6, 4, 0, 0, 7); c.fill();
    // Flame when boosting
    if (typeof nitOn !== 'undefined' && nitOn) {
      c.fillStyle = '#ff7a1a';
      c.beginPath(); c.moveTo(-50, 2); c.lineTo(-70 - Math.random() * 10, 4); c.lineTo(-50, 8); c.closePath(); c.fill();
    }
    c.fillStyle = glassGrad(c, 4, 4, 16, 8); c.fillRect(4, 4, 16, 8);
    c.fillStyle = stripe; c.fillRect(-30, 4, 56, 2);
    // Fin
    c.fillStyle = dark;
    c.beginPath(); c.moveTo(-20, 14); c.lineTo(-28, 26); c.lineTo(-12, 14); c.closePath(); c.fill();
  }

  // ========== DEFAULT FALLBACK ==========
  else {
    c.beginPath();
    c.moveTo(-55, -10); c.lineTo(55, -10); c.lineTo(60, 4); c.lineTo(32, 12);
    c.lineTo(18, 24); c.lineTo(-14, 24); c.lineTo(-28, 10); c.lineTo(-55, 6); c.closePath();
    c.fillStyle = bodyPaint(); c.fill();
    c.strokeStyle = dark; c.lineWidth = 2.5; c.stroke();
    c.fillStyle = glassGrad(c, 10, 10, 16, 12);
    c.beginPath(); c.moveTo(28, 10); c.lineTo(20, 22); c.lineTo(6, 22); c.lineTo(10, 10); c.closePath(); c.fill();
    c.fillStyle = stripe; c.fillRect(-48, 0, 96, 3);
    c.fillStyle = '#fff8dc'; c.beginPath(); c.arc(56, 0, 4, 0, 7); c.fill();
  }

  // Crash damage overlay
  if (crashed) {
    c.fillStyle = 'rgba(40,20,10,0.4)';
    c.beginPath(); c.moveTo(-24, 4); c.lineTo(-6, 16); c.lineTo(12, 8); c.lineTo(6, -2); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(0,0,0,0.45)'; c.lineWidth = 2.2;
    c.beginPath(); c.moveTo(-32, 0); c.lineTo(-8, 14); c.moveTo(18, 6); c.lineTo(36, -4); c.stroke();
    // Scratches
    c.strokeStyle = 'rgba(255,255,255,0.15)'; c.lineWidth = 1;
    c.beginPath(); c.moveTo(-20, 8); c.lineTo(10, 12); c.stroke();
  }
}

function drawWheel(c, R) {
  // Outer tire
  const g = c.createRadialGradient(-R * 0.15, R * 0.1, R * 0.15, 0, 0, R);
  g.addColorStop(0, '#3a3a3a');
  g.addColorStop(0.55, '#1c1c1c');
  g.addColorStop(0.85, '#0e0e0e');
  g.addColorStop(1, '#080808');
  c.fillStyle = g;
  c.beginPath(); c.arc(0, 0, R, 0, 7); c.fill();

  // Sidewall
  c.strokeStyle = '#151515'; c.lineWidth = Math.max(2, R * 0.1);
  c.beginPath(); c.arc(0, 0, R * 0.9, 0, 7); c.stroke();

  // Tread blocks (rotates with wheel via parent transform)
  c.strokeStyle = '#0a0a0a'; c.lineWidth = Math.max(1.5, R * 0.07);
  const nTread = Math.max(8, Math.floor(R * 0.7));
  for (let k = 0; k < nTread; k++) {
    const a = (k / nTread) * Math.PI * 2;
    c.beginPath();
    c.moveTo(Math.cos(a) * R * 0.72, Math.sin(a) * R * 0.72);
    c.lineTo(Math.cos(a) * R * 0.95, Math.sin(a) * R * 0.95);
    c.stroke();
  }
  // Circumferential tread grooves
  c.strokeStyle = 'rgba(0,0,0,0.5)'; c.lineWidth = 1.2;
  c.beginPath(); c.arc(0, 0, R * 0.78, 0, 7); c.stroke();
  c.beginPath(); c.arc(0, 0, R * 0.85, 0, 7); c.stroke();

  // Alloy rim
  const rim = c.createRadialGradient(-R * 0.2, R * 0.2, 0, 0, 0, R * 0.58);
  rim.addColorStop(0, '#e8ecf0');
  rim.addColorStop(0.4, '#a0a8b0');
  rim.addColorStop(0.8, '#5a6068');
  rim.addColorStop(1, '#3a4048');
  c.fillStyle = rim;
  c.beginPath(); c.arc(0, 0, R * 0.58, 0, 7); c.fill();

  // Rim lip
  c.strokeStyle = '#d0d4d8'; c.lineWidth = Math.max(1.5, R * 0.05);
  c.beginPath(); c.arc(0, 0, R * 0.58, 0, 7); c.stroke();

  // Spokes (5-spoke alloy)
  c.strokeStyle = '#6a7078'; c.lineWidth = Math.max(2, R * 0.09);
  c.lineCap = 'round';
  for (let k = 0; k < 5; k++) {
    const a = k * 1.2566;
    c.beginPath();
    c.moveTo(Math.cos(a) * R * 0.12, Math.sin(a) * R * 0.12);
    c.lineTo(Math.cos(a) * R * 0.52, Math.sin(a) * R * 0.52);
    c.stroke();
  }

  // Center hub / cap
  c.fillStyle = '#2a2a30';
  c.beginPath(); c.arc(0, 0, R * 0.2, 0, 7); c.fill();
  c.fillStyle = '#8a9098';
  c.beginPath(); c.arc(0, 0, R * 0.1, 0, 7); c.fill();
  // Hub bolts
  c.fillStyle = '#555';
  for (let k = 0; k < 5; k++) {
    const a = k * 1.2566 + 0.3;
    c.beginPath();
    c.arc(Math.cos(a) * R * 0.14, Math.sin(a) * R * 0.14, Math.max(1, R * 0.03), 0, 7);
    c.fill();
  }

  // Brake disc
  c.strokeStyle = 'rgba(180,70,40,0.4)'; c.lineWidth = Math.max(1.5, R * 0.06);
  c.beginPath(); c.arc(0, 0, R * 0.38, 0, 7); c.stroke();
}

function driverAnimState() {
  if (!S) return { steer: 0, lean: 0, bounce: 0, air: 0, crash: 0, flip: 0 };
  // Steering: controls + idle micro-motion; struggle in air; thrash on crash
  let steer = gas ? 0.22 : brake ? -0.4 : Math.sin(T * 1.6) * 0.08;
  if (S.air) steer += Math.sin(T * 7.5) * 0.4;
  if (S.crashed) steer += Math.sin(T * 16) * 0.6;
  // Body lean: slope + accel (back) / brake (forward) + angular velocity
  const lean = Math.max(-1.3, Math.min(1.3, S.th * 1.7 + (gas ? 0.3 : 0) - (brake ? 0.45 : 0) + S.om * 0.06));
  // Bounce: road vibration when grounded, float when airborne
  const speed = Math.hypot(S.vx, S.vy);
  const bounce = S.air
    ? Math.sin(T * 4.5) * 2.2 + Math.sin(T * 9) * 0.8
    : Math.sin(T * 15) * Math.min(1.4, speed / 320) * 1.9;
  const air = S.air ? 1 : 0;
  const crash = S.crashed ? 1 : 0;
  const flip = S.air ? S.om * 0.22 : S.om * 0.05;
  return { steer, lean, bounce, air, crash, flip };
}
function drawCar() {
  const c = ctx, R = Phys.P.rw;
  // Ground shadow (world space, under vehicle)
  if (!S.crashed) {
    c.save();
    c.translate(S.x, S.y - 8);
    c.scale(1, 0.35);
    c.fillStyle = 'rgba(0,0,0,0.28)';
    c.beginPath(); c.ellipse(0, 0, 70, 28, 0, 0, 7); c.fill();
    c.restore();
  }
  c.save(); c.translate(S.x, S.y); c.rotate(S.th);
  // Exhaust / nitro flame
  if ((state === 'play' || state === 'replay') && !S.crashed) {
    if (nitOn && nit > 0) {
      const L = 30 + Math.random() * 24;
      c.fillStyle = '#ff7a1a'; c.beginPath(); c.moveTo(-60, -1); c.lineTo(-60 - L, -6); c.lineTo(-60, -12); c.fill();
      c.fillStyle = '#fff3a0'; c.beginPath(); c.moveTo(-60, -3); c.lineTo(-60 - L * 0.55, -6); c.lineTo(-60, -10); c.fill();
    } else if (gas && fuel > 0 && Math.random() < 0.4) {
      // Soft exhaust puff
      const ex = -58 - Math.random() * 12;
      c.fillStyle = 'rgba(80,80,80,0.25)';
      c.beginPath(); c.arc(ex, -2, 4 + Math.random() * 4, 0, 7); c.fill();
    }
  }
  drawBody(c, rv);
  drawDriver(c, driverAnimState());
  // Headlights
  if (lightsActive()) {
    c.fillStyle = '#fff8dc';
    c.beginPath(); c.arc(56, 2, 5, 0, 7); c.fill();
    c.beginPath(); c.arc(56, -8, 5, 0, 7); c.fill();
    c.fillStyle = 'rgba(255,240,180,0.45)';
    c.beginPath(); c.arc(62, -3, 12, 0, 7); c.fill();
  } else {
    c.fillStyle = '#c9a227';
    c.beginPath(); c.arc(56, 2, 3.5, 0, 7); c.fill();
    c.beginPath(); c.arc(56, -8, 3.5, 0, 7); c.fill();
  }
  // Taillights
  c.fillStyle = brake ? '#ff3333' : '#a01010';
  c.beginPath(); c.arc(-56, 0, brake ? 5 : 4, 0, 7); c.fill();
  c.beginPath(); c.arc(-56, -8, brake ? 5 : 4, 0, 7); c.fill();
  if (brake) {
    c.fillStyle = 'rgba(255,40,40,0.35)';
    c.beginPath(); c.arc(-58, -4, 10, 0, 7); c.fill();
  }
  c.restore();
  // Wheels in world space (already have correct positions from physics)
  for (const w of S.w) {
    c.save(); c.translate(w.x, w.y); c.rotate(w.ang); drawWheel(c, R); c.restore();
  }
}
function mini(r, v, locked, opts) {
  // Draw vehicle preview inside rect r = [x,y,w,h]. Always in front (caller controls order).
  opts = opts || {};
  const pad = opts.pad != null ? opts.pad : 0.55;
  const s = Math.min(r[2] * pad / 150, r[3] * pad / 90);
  const cx = r[0] + r[2] / 2, cy = r[1] + r[3] * (opts.cy || 0.58);
  ctx.save();
  ctx.globalAlpha = locked ? 0.4 : 1;
  ctx.translate(cx, cy);
  ctx.scale(s, -s);
  // Ground shadow (in local vehicle space, under chassis)
  ctx.fillStyle = 'rgba(0,0,0,0.35)';
  ctx.beginPath(); ctx.ellipse(0, -10, 62, 10, 0, 0, 7); ctx.fill();
  // Body + driver + wheels (full vehicle)
  drawBody(ctx, v);
  drawDriver(ctx, { steer: 0.12, lean: 0, bounce: 0, air: 0, crash: 0, flip: 0 });
  const R = v.rw || 20;
  for (const sx of [-1, 1]) {
    ctx.save();
    ctx.translate(sx * (v.ax || 42), (v.wy || -28) + R * 0.15);
    drawWheel(ctx, R);
    ctx.restore();
  }
  ctx.restore();
}

// Large centered garage showcase of the currently selected vehicle
function drawGarageShowcase() {
  const v = VEH[sel] || VEH[0];
  // Showcase panel behind vehicle
  const pw = Math.min(W * 0.72, 520), ph = Math.min(H * 0.34, 200);
  const px = (W - pw) / 2, py = H * 0.20;
  ctx.fillStyle = 'rgba(12, 18, 32, 0.92)';
  ctx.beginPath(); ctx.roundRect(px, py, pw, ph, 14); ctx.fill();
  ctx.strokeStyle = '#4cd137'; ctx.lineWidth = 2.5;
  ctx.beginPath(); ctx.roundRect(px, py, pw, ph, 14); ctx.stroke();
  // Soft floor gradient
  const g = ctx.createLinearGradient(px, py + ph * 0.55, px, py + ph);
  g.addColorStop(0, 'rgba(30,50,80,0)');
  g.addColorStop(1, 'rgba(20,40,70,0.5)');
  ctx.fillStyle = g; ctx.fillRect(px + 4, py + ph * 0.5, pw - 8, ph * 0.5 - 4);
  // Large vehicle centered in panel (drawn ON TOP of panel background)
  mini([px, py, pw, ph], v, false, { pad: 0.72, cy: 0.62 });
  // Name + status
  txt(v.name, W / 2, py + ph - 14, Math.min(18, H / 28), '#fff', 'center');
}
function drawItems(t, x0, x1) {
  for (const it of items) { if (it.got || it.x < x0 - 40 || it.x > x1 + 40) continue; const c = ctx;
    if (it.t === 'coin') { const sq = Math.abs(Math.cos(t * 4 + it.x * 0.05)) * 0.8 + 0.2;
      c.save(); c.translate(it.x, it.y + Math.sin(t * 3 + it.x) * 3); c.scale(sq, 1);
      c.fillStyle = '#f5a300'; c.beginPath(); c.arc(0, 0, 13, 0, 7); c.fill(); c.fillStyle = '#ffd84a'; c.beginPath(); c.arc(0, 0, 9, 0, 7); c.fill();
      c.restore(); }
    else if (it.t === 'gem') { const sq = Math.abs(Math.cos(t * 3 + it.x * 0.05)) * 0.7 + 0.3;
      c.save(); c.translate(it.x, it.y + Math.sin(t * 3 + it.x) * 3); c.scale(sq, 1);
      c.fillStyle = '#16b6d9'; c.beginPath(); c.moveTo(0, 17); c.lineTo(14, 0); c.lineTo(0, -17); c.lineTo(-14, 0); c.closePath(); c.fill();
      c.fillStyle = '#9af0ff'; c.beginPath(); c.moveTo(0, 11); c.lineTo(7, 0); c.lineTo(0, -9); c.lineTo(-7, 0); c.closePath(); c.fill();
      c.restore(); }
    else if (it.t === 'nitro') { c.save(); c.translate(it.x, it.y + Math.sin(t * 3 + it.x) * 3);
      c.fillStyle = '#1a8cff'; c.beginPath(); c.arc(0, 0, 16, 0, 7); c.fill(); c.strokeStyle = '#0b4a99'; c.lineWidth = 3; c.stroke();
      c.fillStyle = '#ffe14a'; c.beginPath(); c.moveTo(3, 11); c.lineTo(-7, -1); c.lineTo(-1, -1); c.lineTo(-3, -11); c.lineTo(7, 2); c.lineTo(1, 2); c.closePath(); c.fill();
      c.restore(); }
    else { c.save(); c.translate(it.x, it.y); c.fillStyle = '#d82020'; c.fillRect(-12, -15, 24, 30); c.fillStyle = '#fff'; c.fillRect(-7, -4, 14, 9);
      c.fillStyle = '#222'; c.fillRect(-5, 15, 10, 4); c.restore(); } }
}
function drawSnow() {
  // Unified weather particles – snow / rain / dust / ash / leaves / fog
  const w = cur.weather || 'none';
  if (w === 'none' && cur.snow < 0.05) return;
  const gMul = [0.35, 0.6, 1, 1.25][settings.graphics] || 1;
  const n = Math.floor(gMul * (w === 'snow' || cur.snow > 0.2 ? Math.floor(70 + cur.snow * 40)
    : w === 'rain' ? 55 : w === 'dust' || w === 'ash' ? 40 : w === 'leaves' ? 25 : w === 'fog' ? 18 : 0));
  if (n < 1) return;
  for (let i = 0; i < n; i++) {
    const x = (((rnd(i) * W + Math.sin(T * 0.9 + i) * 18 - camX * sc * 0.35) % W) + W) % W;
    const speed = w === 'rain' ? 180 : w === 'dust' || w === 'ash' ? 40 : 55;
    const y = (rnd(i + 50) * H + T * (speed + rnd(i + 9) * 40)) % H;
    if (w === 'rain') {
      ctx.strokeStyle = 'rgba(180,210,255,0.45)'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - 2, y + 10); ctx.stroke();
    } else if (w === 'dust') {
      ctx.fillStyle = 'rgba(210,170,100,0.35)'; ctx.beginPath(); ctx.arc(x, y, 1.5 + rnd(i) * 2, 0, 7); ctx.fill();
    } else if (w === 'ash') {
      ctx.fillStyle = 'rgba(80,60,60,0.5)'; ctx.beginPath(); ctx.arc(x, y, 1 + rnd(i) * 2, 0, 7); ctx.fill();
    } else if (w === 'leaves') {
      ctx.fillStyle = 'rgba(40,120,30,0.55)'; ctx.fillRect(x, y, 4, 2);
    } else if (w === 'fog') {
      ctx.fillStyle = 'rgba(180,180,200,0.08)'; ctx.beginPath(); ctx.arc(x, y, 20 + rnd(i) * 30, 0, 7); ctx.fill();
    } else {
      ctx.fillStyle = 'rgba(255,255,255,0.85)'; ctx.beginPath(); ctx.arc(x, y, 1.5 + rnd(i + 77) * 2, 0, 7); ctx.fill();
    }
  }
}
function pedal(x, y, w, h, label, on, kind, press) {
  // AAA-quality 3D pedal: kind = 'gas' (premium orange) or 'brake' (metallic blue)
  const opac = Math.max(0.35, Math.min(1, settings.ctrlOpacity == null ? 0.9 : settings.ctrlOpacity));
  const p = Math.max(0, Math.min(1, press || (on ? 1 : 0)));
  const sink = p * Math.min(8, h * 0.06); // press-in animation
  const glow = 0.35 + p * 0.65;
  ctx.save();
  ctx.globalAlpha = opac;

  // Soft outer glow
  const isGas = kind === 'gas';
  const glowCol = isGas ? 'rgba(255,140,20,' : 'rgba(40,140,255,';
  ctx.shadowColor = glowCol + (0.45 * glow) + ')';
  ctx.shadowBlur = 18 + p * 14;

  // Pedal base (3D trapezoid-ish rounded rect)
  const r = Math.min(14, w * 0.12, h * 0.1);
  const px = x, py = y + sink, pw = w, ph = h - sink * 0.6;

  // Bottom bevel / shadow plate
  ctx.fillStyle = isGas ? '#6a2800' : '#0a2040';
  ctx.beginPath(); ctx.roundRect(px + 3, py + 6, pw - 6, ph - 4, r); ctx.fill();

  // Main body gradient
  const g = ctx.createLinearGradient(px, py, px, py + ph);
  if (isGas) {
    g.addColorStop(0, p > 0.5 ? '#ffb347' : '#ff9f1a');
    g.addColorStop(0.35, '#ff7a00');
    g.addColorStop(0.7, '#e85d04');
    g.addColorStop(1, '#9a3400');
  } else {
    g.addColorStop(0, p > 0.5 ? '#7ec8ff' : '#4dabf7');
    g.addColorStop(0.3, '#1c7ed6');
    g.addColorStop(0.65, '#1864ab');
    g.addColorStop(1, '#0b3d6b');
  }
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.roundRect(px, py, pw, ph, r); ctx.fill();

  // Top highlight edge
  ctx.shadowBlur = 0;
  const hg = ctx.createLinearGradient(px, py, px, py + ph * 0.35);
  hg.addColorStop(0, 'rgba(255,255,255,0.55)');
  hg.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = hg;
  ctx.beginPath(); ctx.roundRect(px + 2, py + 2, pw - 4, ph * 0.28, r - 2); ctx.fill();

  // Metallic side edge lines
  ctx.strokeStyle = isGas ? 'rgba(255,200,120,0.7)' : 'rgba(160,210,255,0.75)';
  ctx.lineWidth = 2.5;
  ctx.beginPath(); ctx.roundRect(px + 1.5, py + 1.5, pw - 3, ph - 3, r - 1); ctx.stroke();

  // Glowing rim when pressed
  if (p > 0.05) {
    ctx.strokeStyle = isGas ? 'rgba(255,180,40,' + (0.5 + p * 0.5) + ')' : 'rgba(80,180,255,' + (0.5 + p * 0.5) + ')';
    ctx.lineWidth = 3 + p * 2;
    ctx.beginPath(); ctx.roundRect(px - 1, py - 1, pw + 2, ph + 2, r + 2); ctx.stroke();
  }

  // Rubber grip texture (raised rubber pads)
  ctx.fillStyle = isGas ? 'rgba(40,15,0,0.45)' : 'rgba(5,20,45,0.5)';
  const cols = 3, rows = 4;
  const padW = pw * 0.18, padH = ph * 0.11, gapX = (pw - cols * padW) / (cols + 1), gapY = (ph * 0.55 - rows * padH) / (rows + 1);
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const rx = px + gapX + col * (padW + gapX);
      const ry = py + ph * 0.12 + gapY + row * (padH + gapY);
      ctx.beginPath(); ctx.roundRect(rx, ry, padW, padH, 3); ctx.fill();
    }
  }

  // Label
  ctx.shadowBlur = 0;
  ctx.fillStyle = '#fff';
  ctx.font = 'bold ' + Math.max(11, ph * 0.16) + 'px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.strokeStyle = 'rgba(0,0,0,0.55)';
  ctx.lineWidth = 3;
  const lx = px + pw / 2, ly = py + ph * 0.82;
  ctx.strokeText(label, lx, ly);
  ctx.fillText(label, lx, ly);

  // Tiny status LED
  ctx.beginPath();
  ctx.arc(px + pw * 0.12, py + ph * 0.12, Math.max(3, ph * 0.035), 0, 7);
  ctx.fillStyle = on ? (isGas ? '#ffe066' : '#74c0fc') : 'rgba(0,0,0,0.35)';
  ctx.fill();

  ctx.restore();
}
function txt(s, x, y, sz, col, al) { ctx.font = 'bold ' + sz + 'px sans-serif'; ctx.textAlign = al || 'left'; ctx.lineWidth = sz / 6; ctx.strokeStyle = '#0006';
  ctx.strokeText(s, x, y); ctx.fillStyle = col || '#fff'; ctx.fillText(s, x, y); }
function hud() {
  const g = geo(), u = g.u, m = Math.max(0, (S.x - Phys.P.start) / M);
  // fuel
  ctx.fillStyle = '#0006'; ctx.fillRect(u, u, u * 7, u * 1.3);
  ctx.fillStyle = fuel / cap > 0.3 ? '#4cd137' : fuel / cap > 0.12 ? '#f5a300' : '#e03030'; ctx.fillRect(u + 3, u + 3, (u * 7 - 6) * fuel / cap, u * 1.3 - 6);
  txt('FUEL', u * 8.4, u * 2.15, u * 1.1);
  // nitro
  ctx.fillStyle = '#0006'; ctx.fillRect(u, u * 2.7, u * 7, u * 0.9);
  ctx.fillStyle = '#2aa7ff'; ctx.fillRect(u + 3, u * 2.7 + 3, Math.max(0, (u * 7 - 6) * nit / nitCap), u * 0.9 - 6);
  txt('NITRO', u * 8.4, u * 3.5, u * 0.9);
  // coins
  ctx.fillStyle = '#f5a300'; ctx.beginPath(); ctx.arc(u * 1.7, u * 5.4, u * 0.8, 0, 7); ctx.fill();
  txt(String(state === 'over' ? bank : bank + coins), u * 3, u * 6, u * 1.5);
  txt(Math.floor(m) + ' / ' + levelTarget + ' m', W - u, u * 2.2, u * 1.6, '#fff', 'right');
  txt('LVL ' + selLevel + '  BEST ' + Math.floor(Math.max(best, m)) + ' m', W - u, u * 4.0, u * 1.0, '#fff', 'right');
  txt(MAPS[selMap].name, W - u, u * 5.5, u * 0.9, '#ffffffcc', 'right');
  // pause button – large, high-contrast, easy to tap in landscape fullscreen
  const p = g.pause;
  ctx.globalAlpha = 0.92;
  ctx.fillStyle = '#0d1520';
  ctx.beginPath(); ctx.roundRect(p[0], p[1], p[2], p[3], 12); ctx.fill();
  ctx.strokeStyle = '#ffffff55'; ctx.lineWidth = 2; ctx.stroke();
  ctx.fillStyle = '#fff';
  ctx.fillRect(p[0] + p[2] * 0.28, p[1] + p[3] * 0.26, p[2] * 0.16, p[3] * 0.48);
  ctx.fillRect(p[0] + p[2] * 0.56, p[1] + p[3] * 0.26, p[2] * 0.16, p[3] * 0.48);
  // settings gear button – permanent, clearly visible
  const sg = g.settings;
  ctx.fillStyle = '#0d1520';
  ctx.beginPath(); ctx.roundRect(sg[0], sg[1], sg[2], sg[3], 12); ctx.fill();
  ctx.strokeStyle = '#ffd43baa'; ctx.lineWidth = 2; ctx.stroke();
  ctx.fillStyle = '#ffd43b';
  ctx.font = 'bold ' + Math.floor(sg[3] * 0.58) + 'px sans-serif';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText('⚙', sg[0] + sg[2] / 2, sg[1] + sg[3] * 0.52);
  ctx.textBaseline = 'alphabetic';
  ctx.globalAlpha = 1;
  pops.forEach((q, i) => { ctx.globalAlpha = Math.min(1, q.t); txt(q.s, W / 2, H * 0.22 + i * H / 13, H / 14, '#ffe27a', 'center'); ctx.globalAlpha = 1; });
  // Smooth press animation
  gasPress += ((gas ? 1 : 0) - gasPress) * 0.28;
  brakePress += ((brake ? 1 : 0) - brakePress) * 0.28;
  const br = g.brake, gs = g.gas;
  pedal(br[0], br[1], br[2], br[3], 'BRAKE', brake, 'brake', brakePress);
  pedal(gs[0], gs[1], gs[2], gs[3], 'GAS', gas, 'gas', gasPress);
  // nitro button
  const n = g.nit, on = nitOn && nit > 0;
  ctx.globalAlpha = on ? 0.95 : 0.75; ctx.fillStyle = on ? '#6cc4ff' : '#1a8cff'; ctx.strokeStyle = '#0b4a99'; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.arc(n.x, n.y, n.r, 0, 7); ctx.fill(); ctx.stroke(); ctx.globalAlpha = 1;
  ctx.fillStyle = '#ffe14a'; ctx.beginPath(); const k = n.r / 30;
  ctx.moveTo(n.x + 5 * k, n.y - 20 * k); ctx.lineTo(n.x - 12 * k, n.y + 3 * k); ctx.lineTo(n.x - 1 * k, n.y + 3 * k);
  ctx.lineTo(n.x - 5 * k, n.y + 20 * k); ctx.lineTo(n.x + 12 * k, n.y - 3 * k); ctx.lineTo(n.x + 1 * k, n.y - 3 * k); ctx.closePath(); ctx.fill();
  // Horn button
  const hb = g.horn;
  ctx.globalAlpha = hornOn ? 0.95 : 0.75;
  ctx.fillStyle = hornOn ? '#ff922b' : '#e8590c'; ctx.strokeStyle = '#d9480f'; ctx.lineWidth = 2.5;
  ctx.beginPath(); ctx.arc(hb.x, hb.y, hb.r, 0, 7); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#fff'; ctx.font = 'bold ' + (hb.r * 0.7) + 'px sans-serif'; ctx.textAlign = 'center';
  ctx.fillText('🔊', hb.x, hb.y + hb.r * 0.28);
  // Headlights button
  const lb = g.lights, lon = lightsActive();
  ctx.globalAlpha = lon ? 0.95 : 0.75;
  ctx.fillStyle = lon ? '#ffd43b' : '#5c5f66'; ctx.strokeStyle = lon ? '#f59f00' : '#373a40'; ctx.lineWidth = 2.5;
  ctx.beginPath(); ctx.arc(lb.x, lb.y, lb.r, 0, 7); ctx.fill(); ctx.stroke();
  ctx.fillStyle = lon ? '#212529' : '#dee2e6';
  ctx.font = 'bold ' + (lb.r * 0.65) + 'px sans-serif';
  ctx.fillText('💡', lb.x, lb.y + lb.r * 0.28);
  ctx.globalAlpha = 1;
}
function btnDraw(r, col, label, sz) { ctx.fillStyle = col; ctx.beginPath(); ctx.roundRect(r[0], r[1], r[2], r[3], 14); ctx.fill();
  ctx.strokeStyle = '#fff6'; ctx.lineWidth = 3; ctx.stroke(); txt(label, r[0] + r[2] / 2, r[1] + r[3] * 0.64, sz, '#fff', 'center'); }

// ---------- Settings panel layout & UI ----------
function settingsLay() {
  // Fit comfortably on short landscape screens (phones in landscape ~360–420 CSS px tall)
  const pw = Math.min(W * 0.96, 860);
  const ph = Math.min(H * 0.94, Math.max(H * 0.88, 340));
  const x0 = (W - pw) / 2, y0 = (H - ph) / 2;
  const bottomH = 44;
  const topH = 32;
  const rowH = Math.max(18, (ph - topH - bottomH - 8) / 12);
  const pad = 8;
  const rows = [];
  for (let i = 0; i < 12; i++) rows.push(y0 + topH + i * rowH);
  const colW = (pw - pad * 3) / 4;
  return {
    panel: [x0, y0, pw, ph],
    rows, x0, pw, pad, colW, rowH,
    resume: [x0 + pad, y0 + ph - bottomH + 4, (pw - pad * 4) / 3, 34],
    restart: [x0 + pad + (pw - pad * 4) / 3 + pad, y0 + ph - bottomH + 4, (pw - pad * 4) / 3, 34],
    menu: [x0 + pad + 2 * ((pw - pad * 4) / 3 + pad), y0 + ph - bottomH + 4, (pw - pad * 4) / 3, 34],
    resetR: [x0 + pw - pad - 118, y0 + 4, 110, 26]
  };
}
function chip(x, y, w, h, label, on) {
  ctx.fillStyle = on ? '#2f9e44' : '#2a3344';
  ctx.beginPath(); ctx.roundRect(x, y, w, h, 8); ctx.fill();
  if (on) { ctx.strokeStyle = '#69db7c'; ctx.lineWidth = 2; ctx.stroke(); }
  txt(label, x + w / 2, y + h * 0.68, Math.min(14, h * 0.45), '#fff', 'center');
}
function sliderTrack(x, y, w, h, val) {
  ctx.fillStyle = '#1a2030'; ctx.beginPath(); ctx.roundRect(x, y + h * 0.35, w, h * 0.3, 4); ctx.fill();
  ctx.fillStyle = '#4dabf7'; ctx.beginPath(); ctx.roundRect(x, y + h * 0.35, w * val, h * 0.3, 4); ctx.fill();
  ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x + w * val, y + h * 0.5, h * 0.35, 0, 7); ctx.fill();
}
function settingsTap(x, y) {
  const lay = settingsLay();
  if (hit(lay.resume, x, y)) { state = 'play'; blip(700, 0.1); return; }
  if (hit(lay.restart, x, y)) { reset(); state = 'play'; blip(800, 0.12); return; }
  if (hit(lay.menu, x, y)) { reset(); state = 'home'; blip(600, 0.1); return; }

  const fpsOpts = [30, 60, 90, 120];
  // Graphics row
  for (let i = 0; i < 4; i++) {
    const cx = lay.x0 + lay.pad + i * (lay.colW + 6);
    if (hit([cx, lay.rows[0], lay.colW, lay.rowH * 0.95], x, y)) {
      settings.graphics = i; saveSettings(); applyGraphics(); blip(800, 0.08); return;
    }
  }
  // FPS row
  for (let i = 0; i < 4; i++) {
    const cx = lay.x0 + lay.pad + i * (lay.colW + 6);
    if (hit([cx, lay.rows[1], lay.colW, lay.rowH * 0.95], x, y)) {
      settings.fps = fpsOpts[i]; saveSettings(); blip(800, 0.08); return;
    }
  }
  // Sound volume slider
  const sx = lay.x0 + lay.pw * 0.28, sw = lay.pw * 0.55;
  if (hit([sx, lay.rows[2], sw, lay.rowH * 0.8], x, y)) {
    settings.soundVol = Math.max(0, Math.min(1, (x - sx) / sw));
    saveSettings(); blip(900, 0.06); return;
  }
  // Music volume slider
  if (hit([sx, lay.rows[3], sw, lay.rowH * 0.8], x, y)) {
    settings.musicVol = Math.max(0, Math.min(1, (x - sx) / sw));
    saveSettings(); blip(900, 0.06); return;
  }
  // Engine ON/OFF
  for (let i = 0; i < 2; i++) {
    const cx = lay.x0 + lay.pad + i * (lay.colW + 6);
    if (hit([cx, lay.rows[4], lay.colW, lay.rowH * 0.95], x, y)) {
      settings.engineOn = i === 0; saveSettings(); blip(800, 0.08); return;
    }
  }
  // Vibration ON/OFF
  for (let i = 0; i < 2; i++) {
    const cx = lay.x0 + lay.pad + i * (lay.colW + 6);
    if (hit([cx, lay.rows[5], lay.colW, lay.rowH * 0.95], x, y)) {
      settings.vibrate = i === 0; saveSettings(); if (settings.vibrate) vibrate(30); blip(800, 0.08); return;
    }
  }
  // Camera
  for (let i = 0; i < 4; i++) {
    const cx = lay.x0 + lay.pad + i * (lay.colW + 6);
    if (hit([cx, lay.rows[6], lay.colW, lay.rowH * 0.95], x, y)) {
      settings.camera = i; saveSettings(); blip(800, 0.08); return;
    }
  }
  // Sensitivity slider
  if (hit([sx, lay.rows[7], sw, lay.rowH * 0.8], x, y)) {
    settings.sensitivity = 0.5 + Math.max(0, Math.min(1, (x - sx) / sw)) * 1.0;
    saveSettings(); blip(900, 0.06); return;
  }
  // Language
  for (let i = 0; i < 3; i++) {
    const cx = lay.x0 + lay.pad + i * (lay.colW + 6);
    if (hit([cx, lay.rows[8], lay.colW, lay.rowH * 0.95], x, y)) {
      settings.lang = i; saveSettings(); blip(800, 0.08); return;
    }
  }
  // Control Size slider (row 9)
  if (hit([sx, lay.rows[9], sw, lay.rowH * 0.8], x, y)) {
    settings.ctrlSize = 0.7 + Math.max(0, Math.min(1, (x - sx) / sw)) * 0.7;
    saveSettings(); blip(900, 0.05); return;
  }
  // Button Opacity slider (row 10)
  if (hit([sx, lay.rows[10], sw, lay.rowH * 0.8], x, y)) {
    settings.ctrlOpacity = 0.4 + Math.max(0, Math.min(1, (x - sx) / sw)) * 0.6;
    saveSettings(); blip(900, 0.05); return;
  }
  // Control Layout chips (row 11)
  for (let i = 0; i < 4; i++) {
    const cx = lay.x0 + lay.pad + i * (lay.colW + 6);
    if (hit([cx, lay.rows[11], lay.colW, lay.rowH * 0.95], x, y)) {
      settings.ctrlLayout = i; saveSettings(); blip(800, 0.08); return;
    }
  }
  // Reset controls button
  if (hit(lay.resetR || [lay.x0 + lay.pw - lay.pad - 118, lay.panel[1] + 4, 110, 26], x, y)) {
    settings.ctrlSize = 1.0; settings.ctrlOpacity = 0.9; settings.ctrlLayout = 0;
    saveSettings(); blip(700, 0.12); if (settings.vibrate) vibrate(40); return;
  }
}
function applyGraphics() {
  // 0 Low 1 Med 2 High 3 Ultra → devicePixelRatio clamp
  const maxD = [1, 1.25, 1.75, 2.5][settings.graphics] || 2;
  DPR = Math.min(maxD, window.devicePixelRatio || 1);
  cv.width = W * DPR; cv.height = H * DPR;
}
function drawSettings() {
  const t = L(), lay = settingsLay();
  ctx.fillStyle = 'rgba(0,0,0,0.72)'; ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = 'rgba(18,24,38,0.96)';
  ctx.beginPath(); ctx.roundRect(lay.panel[0], lay.panel[1], lay.panel[2], lay.panel[3], 16); ctx.fill();
  ctx.strokeStyle = '#4dabf7'; ctx.lineWidth = 2; ctx.stroke();
  txt('⚙️  ' + t.settings, W / 2, lay.panel[1] + 26, 20, '#fff', 'center');

  const labelX = lay.x0 + lay.pad;
  const fs = 13;
  txt(t.graphics, labelX, lay.rows[0] + 14, fs, '#9ad8ff');
  ['low', 'med', 'high', 'ultra'].forEach((k, i) => {
    chip(lay.x0 + lay.pad + i * (lay.colW + 6), lay.rows[0] + 2, lay.colW, lay.rowH * 0.7, t[k], settings.graphics === i);
  });
  txt(t.fps, labelX, lay.rows[1] + 14, fs, '#9ad8ff');
  [30, 60, 90, 120].forEach((v, i) => {
    chip(lay.x0 + lay.pad + i * (lay.colW + 6), lay.rows[1] + 2, lay.colW, lay.rowH * 0.7, String(v), settings.fps === v);
  });
  txt(t.sound, labelX, lay.rows[2] + 14, fs, '#9ad8ff');
  sliderTrack(lay.x0 + lay.pw * 0.28, lay.rows[2], lay.pw * 0.55, lay.rowH * 0.75, settings.soundVol);
  txt(Math.round(settings.soundVol * 100) + '%', lay.x0 + lay.pw - lay.pad, lay.rows[2] + 16, 12, '#fff', 'right');
  txt(t.music, labelX, lay.rows[3] + 14, fs, '#9ad8ff');
  sliderTrack(lay.x0 + lay.pw * 0.28, lay.rows[3], lay.pw * 0.55, lay.rowH * 0.75, settings.musicVol);
  txt(Math.round(settings.musicVol * 100) + '%', lay.x0 + lay.pw - lay.pad, lay.rows[3] + 16, 12, '#fff', 'right');
  txt(t.engine, labelX, lay.rows[4] + 14, fs, '#9ad8ff');
  chip(lay.x0 + lay.pad, lay.rows[4] + 2, lay.colW, lay.rowH * 0.7, t.on, settings.engineOn);
  chip(lay.x0 + lay.pad + lay.colW + 6, lay.rows[4] + 2, lay.colW, lay.rowH * 0.7, t.off, !settings.engineOn);
  txt(t.vibrate, labelX, lay.rows[5] + 14, fs, '#9ad8ff');
  chip(lay.x0 + lay.pad, lay.rows[5] + 2, lay.colW, lay.rowH * 0.7, t.on, settings.vibrate);
  chip(lay.x0 + lay.pad + lay.colW + 6, lay.rows[5] + 2, lay.colW, lay.rowH * 0.7, t.off, !settings.vibrate);
  txt(t.camera, labelX, lay.rows[6] + 14, fs, '#9ad8ff');
  ['normal', 'far', 'close', 'lowcam'].forEach((k, i) => {
    chip(lay.x0 + lay.pad + i * (lay.colW + 6), lay.rows[6] + 2, lay.colW, lay.rowH * 0.7, t[k], settings.camera === i);
  });
  txt(t.sens, labelX, lay.rows[7] + 14, fs, '#9ad8ff');
  sliderTrack(lay.x0 + lay.pw * 0.28, lay.rows[7], lay.pw * 0.55, lay.rowH * 0.75, (settings.sensitivity - 0.5) / 1.0);
  txt(settings.sensitivity.toFixed(1) + 'x', lay.x0 + lay.pw - lay.pad, lay.rows[7] + 16, 12, '#fff', 'right');
  txt(t.lang, labelX, lay.rows[8] + 14, fs, '#9ad8ff');
  ['EN', 'HI', 'OR'].forEach((v, i) => {
    chip(lay.x0 + lay.pad + i * (lay.colW + 6), lay.rows[8] + 2, lay.colW, lay.rowH * 0.7, v, settings.lang === i);
  });
  // Control Size
  txt(t.ctrlSize || 'Control Size', labelX, lay.rows[9] + 14, fs, '#9ad8ff');
  sliderTrack(lay.x0 + lay.pw * 0.28, lay.rows[9], lay.pw * 0.55, lay.rowH * 0.75, ((settings.ctrlSize || 1) - 0.7) / 0.7);
  txt(Math.round((settings.ctrlSize || 1) * 100) + '%', lay.x0 + lay.pw - lay.pad, lay.rows[9] + 16, 12, '#fff', 'right');
  // Button Opacity
  txt(t.ctrlOpac || 'Button Opacity', labelX, lay.rows[10] + 14, fs, '#9ad8ff');
  sliderTrack(lay.x0 + lay.pw * 0.28, lay.rows[10], lay.pw * 0.55, lay.rowH * 0.75, ((settings.ctrlOpacity == null ? 0.9 : settings.ctrlOpacity) - 0.4) / 0.6);
  txt(Math.round((settings.ctrlOpacity == null ? 0.9 : settings.ctrlOpacity) * 100) + '%', lay.x0 + lay.pw - lay.pad, lay.rows[10] + 16, 12, '#fff', 'right');
  // Control Layout
  txt(t.ctrlLayout || 'Control Layout', labelX, lay.rows[11] + 14, fs, '#9ad8ff');
  const layouts = [t.classic || 'Classic', t.wide || 'Wide', t.compact || 'Compact', t.high || 'High'];
  layouts.forEach((lab, i) => {
    chip(lay.x0 + lay.pad + i * (lay.colW + 6), lay.rows[11] + 2, lay.colW, lay.rowH * 0.7, lab, (settings.ctrlLayout | 0) === i);
  });
  // Reset controls button (top-right of panel)
  const resetR = lay.resetR || [lay.x0 + lay.pw - lay.pad - 118, lay.panel[1] + 4, 110, 26];
  ctx.fillStyle = '#c92a2a';
  ctx.beginPath(); ctx.roundRect(resetR[0], resetR[1], resetR[2], resetR[3], 8); ctx.fill();
  txt(t.resetCtrl || 'RESET CONTROLS', resetR[0] + resetR[2] / 2, resetR[1] + resetR[3] * 0.68, 11, '#fff', 'center');

  btnDraw(lay.resume, '#2f9e44', t.resume, 15);
  btnDraw(lay.restart, '#e67700', t.restart, 15);
  btnDraw(lay.menu, '#2b6fd6', t.menu, 14);
}
function drawHome() {
  ctx.fillStyle = '#0005'; ctx.fillRect(0, 0, W, H);
  txt('HILL RIDER', W / 2, H * 0.14, Math.min(W / 8, H / 5), '#fff', 'center');
  txt('Climb  -  Flip  -  Survive the night', W / 2, H * 0.22, H / 26, '#ffe27a', 'center');
  // selected vehicle preview
  const prevR = [W / 2 - 90, H * 0.26, 180, 70];
  ctx.fillStyle = '#1b2a3acc'; ctx.beginPath(); ctx.roundRect(prevR[0], prevR[1], prevR[2], prevR[3], 10); ctx.fill();
  ctx.strokeStyle = '#4cd137'; ctx.lineWidth = 2; ctx.stroke();
  mini(prevR, VEH[sel] || VEH[0], false);
  txt((VEH[sel] || VEH[0]).name, W / 2, H * 0.385, H / 30, '#9ad8ff', 'center');
  txt('Level ' + selLevel + ' | ' + MAPS[selMap].name + ' | Unlocked: ' + own.length + '/' + VEH.length, W / 2, H * 0.42, H / 32, '#aaa', 'center');
  const h = homeLay();
  btnDraw(h.play, '#2fbf3a', 'PLAY', H / 12);
  btnDraw(h.maps, '#e67e22', 'MAPS / LEVELS', H / 28);
  btnDraw(h.garage, '#2b6fd6', 'GARAGE (' + own.length + ')', H / 28);
  btnDraw(h.full, '#8a5cf0', isFull() ? 'EXIT FULL' : 'FULLSCREEN', H / 30);
  txt('BEST ' + Math.floor(best) + ' m      COINS ' + bank, W / 2, H * 0.94, H / 26, '#fff', 'center');
}
function drawMaps() {
  ctx.fillStyle = '#0008'; ctx.fillRect(0, 0, W, H);
  txt('SELECT MAP & LEVEL', W / 2, H * 0.045, Math.min(W / 16, H / 16), '#fff', 'center');
  const L = mapsLay();
  txt('Cleared: ' + completed + '/' + NUM_LEVELS + '  ·  Maps p.' + (mapPage + 1) + '/' + (L.maxMapPage + 1) + '  ·  Target 550 m', W / 2, H * 0.09, H / 38, '#ffe27a', 'center');
  L.maps.forEach(item => {
    const r = item.r, i = item.idx, m = MAPS[i], unlocked = completed >= m.unlockAt, on = selMap === i;
    const bio = BIO[m.bio] || BIO[0];
    ctx.fillStyle = unlocked ? bio.c[0] + 'cc' : '#1118';
    ctx.beginPath(); ctx.roundRect(r[0], r[1], r[2], r[3], 8); ctx.fill();
    ctx.strokeStyle = on ? '#4cd137' : unlocked ? '#ffffff88' : '#333'; ctx.lineWidth = on ? 3 : 1.5; ctx.stroke();
    const fs = Math.min(H / 42, r[2] / 9);
    txt(m.name, r[0] + r[2] / 2, r[1] + r[3] * 0.42, fs, unlocked ? '#fff' : '#666', 'center');
    if (!unlocked) txt('Lvl ' + (m.unlockAt + 1), r[0] + r[2] / 2, r[1] + r[3] * 0.78, fs * 0.85, '#999', 'center');
    else txt(on ? 'SELECTED' : 'OPEN', r[0] + r[2] / 2, r[1] + r[3] * 0.78, fs * 0.85, on ? '#4cd137' : '#dff', 'center');
  });
  txt('LEVELS  ·  page ' + (levelPage + 1) + '/' + (L.maxLevelPage + 1), W / 2, H * 0.485, H / 36, '#fff', 'center');
  if (L.lvlPrev) btnDraw(L.lvlPrev, levelPage > 0 ? '#3a5a8a' : '#222', '◀', H / 28);
  if (L.lvlNext) btnDraw(L.lvlNext, levelPage < L.maxLevelPage ? '#3a5a8a' : '#222', '▶', H / 28);
  L.levels.forEach(item => {
    const r = item.r, lvl = item.lvl;
    const canPlay = lvl <= completed + 1, done = lvl <= completed, on = selLevel === lvl;
    ctx.fillStyle = done ? '#14532dcc' : canPlay ? '#1b2a3add' : '#1118';
    ctx.beginPath(); ctx.roundRect(r[0], r[1], r[2], r[3], 8); ctx.fill();
    ctx.strokeStyle = on ? '#4cd137' : done ? '#22c55e' : canPlay ? '#9ad8ff' : '#333';
    ctx.lineWidth = on ? 3 : 2; ctx.stroke();
    txt(String(lvl), r[0] + r[2] / 2, r[1] + r[3] * 0.42, H / 32, canPlay ? '#fff' : '#555', 'center');
    const status = done ? '✓' : (canPlay ? '550m' : '🔒');
    txt(status, r[0] + r[2] / 2, r[1] + r[3] * 0.78, H / 42, done ? '#69db7c' : canPlay ? '#9ad8ff' : '#666', 'center');
  });
  btnDraw(L.back, '#2b6fd6', 'BACK', H / 30);
  if (L.prev) btnDraw(L.prev, mapPage > 0 ? '#3a5a8a' : '#222', '◀', H / 26);
  if (L.next) btnDraw(L.next, mapPage < L.maxMapPage ? '#3a5a8a' : '#222', '▶', H / 26);
  btnDraw(L.start, '#2fbf3a', 'START LVL ' + selLevel, H / 24);
}
function rotateMsg() {
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0); ctx.fillStyle = '#0b1226'; ctx.fillRect(0, 0, W, H);
  const s = Math.min(W, H) * 0.22, a = -Math.PI / 2 * Math.min(1, (T % 2.6) / 1.2);
  ctx.save(); ctx.translate(W / 2, H * 0.38); ctx.rotate(a); ctx.strokeStyle = '#fff'; ctx.lineWidth = 5;
  ctx.beginPath(); ctx.roundRect(-s / 2, -s * 0.9, s, s * 1.8, 14); ctx.stroke(); ctx.fillStyle = '#fff'; ctx.fillRect(-s * 0.12, s * 0.7, s * 0.24, 5); ctx.restore();
  txt('Rotate your phone', W / 2, H * 0.68, Math.min(W / 12, 34), '#fff', 'center');
  txt('Hill Rider plays in landscape', W / 2, H * 0.75, Math.min(W / 20, 20), '#ffe27a', 'center');
}
function overlay(title, sub) {
  // Opaque garage background so world never shows through
  ctx.fillStyle = 'rgba(8, 12, 24, 0.94)'; ctx.fillRect(0, 0, W, H);
  txt(title, W / 2, H * 0.055, Math.min(W / 12, H / 12), '#fff', 'center');
  if (sub && sub.length) sub.forEach((s, i) => txt(s, W / 2, H * (0.095 + i * 0.028), H / 36, '#ffe27a', 'center'));
  txt('Coins: ' + bank + '   |   Page ' + (garagePage + 1) + '/' + (Math.ceil(VEH.length / CARS_PER_PAGE)) + '   |   ' + own.length + '/' + VEH.length + ' owned', W / 2, H * 0.155, H / 34, '#fff', 'center');
  const L = layout();
  btnDraw(L.home, '#2b6fd6', 'HOME', H / 28);
  if (L.prev) btnDraw(L.prev, garagePage > 0 ? '#3a5a8a' : '#222', '◀', H / 24);
  if (L.next) btnDraw(L.next, garagePage < L.maxPage ? '#3a5a8a' : '#222', '▶', H / 24);
  // --- Selected vehicle SHOWCASE (always in front, large, centered) ---
  drawGarageShowcase();

  // --- Vehicle grid cards (below showcase) with swipe ---
  ctx.save();
  ctx.beginPath();
  const clipY = H * 0.55, clipH = H * 0.18;
  ctx.rect(0, clipY - 4, W, clipH + 8); ctx.clip();
  L.cars.forEach(item => {
    const r = item.r, i = item.idx, v = VEH[i], ow = own.includes(i), on = sel === i, ok = bank >= v.price;
    const rx = r[0] + slideX, ry = r[1];
    // Card background first
    ctx.fillStyle = on ? '#1a3a2add' : '#1b2a3add';
    ctx.beginPath(); ctx.roundRect(rx, ry, r[2], r[3], 8); ctx.fill();
    ctx.strokeStyle = on ? '#4cd137' : ow ? '#9ad8ff' : ok ? '#ffd84a' : '#556';
    ctx.lineWidth = on ? 3 : 2; ctx.stroke();
    // Vehicle drawn ON TOP of card background
    mini([rx, ry + r[3] * 0.05, r[2], r[3] * 0.75], v, !ow, { pad: 0.5, cy: 0.55 });
    const fs = Math.min(H / 40, r[2] / 9);
    txt(v.name, rx + r[2] / 2, ry + r[3] * 0.12, fs, '#fff', 'center');
    txt(on ? 'SELECTED' : ow ? 'OWNED' : v.price, rx + r[2] / 2, ry + r[3] * 0.92, fs * 0.9, on ? '#4cd137' : ow ? '#9ad8ff' : ok ? '#ffd84a' : '#889', 'center');
  });
  ctx.restore();
  // Driver selection row
  if (L.drivers) {
    txt('DRIVER', W / 2, H * 0.425, H / 36, '#9ad8ff', 'center');
    L.drivers.forEach((r, i) => {
      const d = DRIVERS[i], ow = ownDrivers.includes(i), on = selDriver === i, ok = bank >= d.price;
      ctx.fillStyle = '#1b2a3add'; ctx.beginPath(); ctx.roundRect(r[0], r[1], r[2], r[3], 6); ctx.fill();
      ctx.strokeStyle = on ? '#4cd137' : ow ? '#9ad8ff' : ok ? '#ffd84a' : '#556'; ctx.lineWidth = on ? 2.5 : 1.5; ctx.stroke();
      // Mini head preview
      ctx.fillStyle = d.skin; ctx.beginPath(); ctx.arc(r[0] + r[2] * 0.22, r[1] + r[3] * 0.5, r[3] * 0.28, 0, 7); ctx.fill();
      ctx.fillStyle = d.hair; ctx.beginPath(); ctx.arc(r[0] + r[2] * 0.22, r[1] + r[3] * 0.38, r[3] * 0.26, Math.PI, 0); ctx.fill();
      const fs = Math.min(H / 42, r[2] / 6);
      txt(d.name, r[0] + r[2] * 0.62, r[1] + r[3] * 0.38, fs, '#fff', 'center');
      txt(on ? 'SEL' : ow ? (d.gender === 'female' ? '♀' : '♂') : d.price, r[0] + r[2] * 0.62, r[1] + r[3] * 0.72, fs * 0.9, on ? '#4cd137' : ow ? '#9ad8ff' : ok ? '#ffd84a' : '#889', 'center');
    });
  }
  L.cards.forEach((r, i) => {
    const n = UP[i][0], key = UP[i][1], l = lv[key] || 0, mx = l >= MAXL, ok = bank >= cost(l);
    ctx.fillStyle = '#1b2a3add'; ctx.beginPath(); ctx.roundRect(r[0], r[1], r[2], r[3], 8); ctx.fill();
    ctx.strokeStyle = mx ? '#4cd137' : ok ? '#ffd84a' : '#556'; ctx.lineWidth = 2; ctx.stroke();
    const fs = Math.min(H / 30, r[2] / 5.5);
    txt(n, r[0] + r[2] / 2, r[1] + r[3] * 0.28, fs, '#fff', 'center');
    for (let j = 0; j < MAXL; j++) {
      ctx.fillStyle = j < l ? '#4cd137' : '#445';
      ctx.fillRect(r[0] + r[2] * 0.08 + j * r[2] * 0.84 / MAXL, r[1] + r[3] * 0.48, r[2] * 0.84 / MAXL - 2, r[3] * 0.12);
    }
    txt(mx ? 'MAX' : cost(l), r[0] + r[2] / 2, r[1] + r[3] * 0.85, fs * 0.9, ok || mx ? '#ffd84a' : '#889', 'center');
  });
  ctx.fillStyle = '#2fbf3a'; ctx.beginPath(); ctx.roundRect(L.btn[0], L.btn[1], L.btn[2], L.btn[3], 14); ctx.fill();
  let btnLabel = 'START';
  if (state === 'over') btnLabel = 'RETRY';
  if (state === 'win') btnLabel = selLevel < NUM_LEVELS ? 'NEXT LEVEL' : 'FINISH';
  txt(btnLabel, L.btn[0] + L.btn[2] / 2, L.btn[1] + L.btn[3] * 0.72, H / 17, '#fff', 'center');
}

// ---------- loop (120 FPS) ----------
let last = performance.now(), acc = 0, T = 0;
const PHYS_DT = 1 / 120;
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (now - last) / 1000); last = now; T += dt;
  // Smooth garage slide animation
  if (slideAnimating || Math.abs(slideX - slideTarget) > 0.5) {
    slideX += (slideTarget - slideX) * Math.min(1, dt * 12);
    if (Math.abs(slideX - slideTarget) < 0.5) { slideX = slideTarget; slideAnimating = false; }
  }
  updBio(S.x);
  if (H > W && state === 'play') togglePause();
  if (state === 'play') {
    Phys.P.muMul = cur.mu;
    acc += dt; while (acc >= PHYS_DT) { acc -= PHYS_DT;
      const bo = nitOn && nit > 0;
      Phys.P.sens = settings.sensitivity || 1;
      Phys.step(S, PHYS_DT, gas && fuel > 0, brake, 8, bo);
      if (bo) nit = Math.max(0, nit - 20 * PHYS_DT);
      fuel = Math.max(0, fuel - (gas ? 2.2 : 0.8) * PHYS_DT);
      if (S.air) { airT += PHYS_DT; rot += S.om * PHYS_DT; } if (wasAir && !S.air) landing(); wasAir = S.air; }
    for (const w of S.w) if (w.hit && gas && fuel > 0 && Math.random() < 0.6) parts.push({ x: w.x - 6, y: w.y - 16, vx: -S.vx * 0.12 + (Math.random() - 0.5) * 50, vy: 20 + Math.random() * 60, l: 0.6 });
    for (const q of parts) { q.x += q.vx * dt; q.y += q.vy * dt; q.l -= dt; } parts = parts.filter(q => q.l > 0);
    pops.forEach(q => q.t -= dt); pops = pops.filter(q => q.t > 0);
    if (cur.i !== lastBio) { lastBio = cur.i; pops.push({ s: (BIO[cur.i] || BIO[0]).n.toUpperCase(), t: 2.5 }); }
    gen(S.x + 2500);
    for (const it of items) { if (it.got) continue; if (Math.hypot(it.x - S.x, it.y - S.y) < 40 || S.w.some(w => Math.hypot(it.x - w.x, it.y - w.y) < 36)) {
      it.got = true;
      if (it.t === 'coin') { coins++; blip(1100, 0.12); }
      else if (it.t === 'gem') { coins += 25; blip(1400, 0.15); }
      else if (it.t === 'nitro') { nit = Math.min(nitCap, nit + 35); blip(600, 0.2); }
      else { fuel = Math.min(cap, fuel + 50); blip(500, 0.25); } } }
    idle = (fuel <= 0 && Math.hypot(S.vx, S.vy) < 25) ? idle + dt : 0;
    const dist = (S.x - Phys.P.start) / M;
    // Finish line trigger (once)
    if (!finishTriggered && dist >= levelTarget && !S.crashed) {
      finishTriggered = true;
      winCoins = coins;
      winReward = 50 + selLevel * 10;
      bank += winCoins + winReward;
      if (dist > best) best = dist;
      if (selLevel > completed) completed = selLevel;
      save();
      spawnCelebration(S.x, S.y);
      victorySound();
      vibrate(40);
      celebT = 0;
      state = 'celebrate';
      ptr.clear(); nptr.clear(); upd();
    } else if (!finishTriggered && (S.crashed || idle > 1.2)) {
      if (dist > best) best = dist;
      bank += coins; save();
      if (S.crashed && !wasCrashed) {
        wasCrashed = true;
        pushReplaySample();
        startCrashReplay();
      } else if (!S.crashed) {
        state = 'over'; overT = 0; blip(120, 0.5);
      }
    }
    // Continuous replay sampling while playing
    if (state === 'play' && !finishTriggered) {
      // sample every other physics step effectively via frame
      if ((replayBuf.length === 0) || Math.hypot(S.x - replayBuf[replayBuf.length - 1].x, S.y - replayBuf[replayBuf.length - 1].y) > 8) {
        pushReplaySample();
      }
    }
    if (og) {
      const bo = nitOn && nit > 0;
      const eng = settings.engineOn ? settings.soundVol : 0;
      og.gain.value = eng * (gas && fuel > 0 ? (bo ? 0.06 : 0.04) : 0.015);
      osc.frequency.value = 45 + Math.min(1, Math.abs(S.vx) / 600) * 70 + (gas ? 20 : 0) + (bo ? 25 : 0);
    }
  } else if (state === 'replay') {
    if (og) og.gain.value = 0;
    stopHorn();
    replayT += dt;
    // Slow-motion: advance ~20 samples/sec
    const stepEvery = 0.045;
    while (replayT >= stepEvery && replayIdx < replayBuf.length - 1) {
      replayT -= stepEvery;
      replayIdx++;
      // Switch camera angle every ~0.7s
      if (replayIdx % 16 === 0) replayCam = (replayCam + 1) % 3;
    }
    const snap = replayBuf[Math.min(replayIdx, replayBuf.length - 1)];
    if (snap) {
      S.x = snap.x; S.y = snap.y; S.th = snap.th;
      S.vx = snap.vx; S.vy = snap.vy; S.om = snap.om;
      S.air = snap.air; S.crashed = snap.crashed;
      if (snap.w && S.w) for (let i = 0; i < S.w.length && i < snap.w.length; i++) {
        S.w[i].x = snap.w[i].x; S.w[i].y = snap.w[i].y; S.w[i].ang = snap.w[i].ang;
      }
    }
    if (replayIdx >= replayBuf.length - 1) {
      // End of buffer → show over after brief hold
      if (replayT > 0.6) skipReplay();
    }
  } else if (state === 'celebrate') {
    if (og) og.gain.value = 0;
    celebT += dt;
    updateCeleb(dt);
    // Spawn extra fireworks during celebration
    if (Math.random() < dt * 2.5) {
      const fx = finishWorldX() + (Math.random() - 0.5) * 250;
      const fy = Phys.height(fx) + 80 + Math.random() * 60;
      const col = ['#ff6b6b', '#ffd43b', '#69db7c', '#4dabf7', '#faa2c1'][(Math.random() * 5) | 0];
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * Math.PI * 2, sp = 50 + Math.random() * 100;
        celebParts.push({ kind: 'spark', x: fx, y: fy, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 1 + Math.random(), max: 1.5, col, size: 3 });
      }
    }
    // After 3s → win screen
    if (celebT >= 3) { state = 'win'; overT = 0; }
  } else { if (og) og.gain.value = 0; overT += dt; if (state === 'ready' || state === 'home' || state === 'maps' || state === 'settings') gen(S.x + 2500); }

  // Camera modes: 0 Normal 1 Far 2 Close 3 Low + victory zoom
  let camZoom = [1, 0.78, 1.22, 1.05][settings.camera] || 1;
  let camYOff = [55, 80, 40, 25][settings.camera] || 55;
  let camXOff = [0.22, 0.18, 0.28, 0.22][settings.camera] || 0.22;
  if (state === 'celebrate') {
    const t = Math.min(1, celebT / 3);
    camZoom = 1 + t * 0.35;
    camXOff = 0.08;
    camYOff = 40 + t * 20;
  } else if (state === 'replay') {
    // Cinematic angles: 0 close side, 1 far wide, 2 low chase
    if (replayCam === 0) { camZoom = 1.45; camXOff = 0.05; camYOff = 30; }
    else if (replayCam === 1) { camZoom = 0.72; camXOff = 0.25; camYOff = 70; }
    else { camZoom = 1.2; camXOff = 0.35; camYOff = 20; }
  }
  const drawSc = sc * camZoom;
  const vw = W / drawSc, tx = S.x + vw * camXOff, ty = S.y + camYOff;
  camX += (tx - camX) * Math.min(1, dt * (state === 'celebrate' ? 3 : 6));
  camY += (ty - camY) * Math.min(1, dt * (state === 'celebrate' ? 2 : 3));

  // FPS limiter (still run physics every frame for consistency)
  const minFrame = 1000 / (settings.fps || 60);
  const nowMs = performance.now();
  const skipDraw = (nowMs - lastFrameDraw) < minFrame * 0.92 && (state === 'play');
  if (!skipDraw) lastFrameDraw = nowMs;

  if (!skipDraw) {
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0); drawSky();
    // Garage / home / maps: solid dim overlay only — do NOT draw world car on top of UI
    const uiOnly = (state === 'ready' || state === 'home' || state === 'maps' || state === 'settings');
    if (!uiOnly) {
      ctx.setTransform(DPR * drawSc, 0, 0, -DPR * drawSc, DPR * (W / 2 - camX * drawSc), DPR * (H / 2 + camY * drawSc));
      const x0 = camX - vw / 2 - 30, x1 = camX + vw / 2 + 30;
      drawTerrain(x0, x1, camY - 400);
      drawRiverAndBridges(x0, x1);
      drawLamps(x0, x1); drawItems(T, x0, x1); drawParts();
      if (finishWorldX() > x0 - 80 && finishWorldX() < x1 + 80) drawFinishLine();
      drawCar();
      if (state === 'celebrate' || state === 'win') drawCelebWorld();
      drawNight(x0, x1);
    }
  }
  // bridge sounds when driving on any bridge type
  if (state === 'play' && !S.air) {
    const ti = Phys.getTerrain(S.x);
    if (ti.onBridge && ti.bridgeType >= 0) {
      const speed = Math.hypot(S.vx, S.vy);
      bridgeSound(ti.bridgeType, 0.28 + Math.min(1, speed / 380) * 0.7 + Math.abs(ti.shake) * 0.15);
    }
  }
  if (!skipDraw) {
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0); drawSnow();
    if (state !== 'home' && state !== 'maps' && state !== 'settings') hud();
    if (state === 'home') drawHome();
    if (state === 'maps') drawMaps();
    if (state === 'ready') overlay('GARAGE', ['Swipe RIGHT → next vehicles   |   Swipe LEFT → previous', 'Tap a vehicle to buy / select   ·   Upgrades below']);
    if (state === 'over') overlay(S.crashed ? 'CRASHED!' : 'OUT OF FUEL', [Math.floor((S.x - Phys.P.start) / M) + ' m   +' + coins + ' coins', 'Target: ' + levelTarget + ' m']);
    if (state === 'win') drawWinScreen();
    if (state === 'replay') {
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(0, 0, W, H * 0.12);
      txt('CRASH REPLAY', W / 2, H * 0.06, Math.min(28, H / 14), '#ff6b6b', 'center');
      txt('SLOW-MOTION  ·  CAM ' + (replayCam + 1) + '/3', W / 2, H * 0.105, 14, '#ffd43b', 'center');
      const rb = replayButtons();
      btnDraw(rb.again, '#e67700', 'REPLAY', 15);
      btnDraw(rb.skip, '#2b6fd6', 'SKIP', 15);
    }
    if (state === 'celebrate') {
      // Floating LEVEL COMPLETE text during camera celebration
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      const pulse = 1 + Math.sin(celebT * 6) * 0.06;
      txt('LEVEL COMPLETE!', W / 2, H * 0.22, Math.min(36, H / 10) * pulse, '#ffd43b', 'center');
      txt('+' + (winCoins + winReward) + ' coins', W / 2, H * 0.32, 22, '#69db7c', 'center');
    }
    if (state === 'pause') { ctx.fillStyle = '#000a'; ctx.fillRect(0, 0, W, H); txt('PAUSED', W / 2, H * 0.48, H / 7, '#fff', 'center'); txt('Tap or press P to continue', W / 2, H * 0.58, H / 22, '#ffe27a', 'center'); }
    if (state === 'settings') drawSettings();
    if (H > W) rotateMsg();
  }
}
reset(); state = 'home'; requestAnimationFrame(frame);
})();
