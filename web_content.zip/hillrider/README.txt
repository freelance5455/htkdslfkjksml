HILL RIDER v4.4 – Garage Selection Fix
Open index.html in any browser (phone or PC). Landscape only.

GARAGE FIX
- Selected vehicle shown LARGE in the center, always in front of background
- Opaque garage panel — world/terrain no longer covers vehicles
- Full vehicle preview including wheels + ground shadow
- Grid of vehicles below for browsing / buying (swipe pages)
- Instant update when you tap a vehicle
- 44 vehicles, upgrades, drivers, coins, save progress

Maps, levels, gameplay camera unchanged.
Android: Add to Home screen for fullscreen.
