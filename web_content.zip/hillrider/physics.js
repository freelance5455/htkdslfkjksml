// Hill Rider physics (pure JS, y-up world). Chassis = rigid body, wheels = sprung particles on a heightfield.
(function (root) {
'use strict';
const P = { g: 900, mc: 8, Ic: 8700, mw: 1.2, Iw: 240, rw: 20, ax: 42, wy: -28,
  ky: 450, cy: 55, kx: 20000, cx: 120, mu: 1.1, drag: 0.12, wmax: 30, tq: 30000, lim: 14,
  airT: 90000, reac: 0.35, start: 100, muMul: 1, boostF: 380 };

// Vehicles – unique mass, torque, grip, suspension, wheel size. style used for drawing.
// Iw derived as 0.5*mw*rw^2 in setLevels
const VEH = [
  // --- existing 24 ---
  { id: 0,  name: 'Offroad Jeep',   price: 0,     style: 'jeep',   color: '#d8262a', dark: '#6e0d10', stripe: '#ff6b5a',
    mc: 8.0, Ic: 8700,  mw: 1.2, rw: 20, ax: 42, wy: -28, ky: 450, cy: 55, tq: 30000, wmax: 30, mu: 1.10, lim: 14 },
  { id: 1,  name: 'Sports Car',     price: 900,   style: 'sport',  color: '#e03131', dark: '#7a1010', stripe: '#ff8787',
    mc: 6.8, Ic: 6800,  mw: 1.0, rw: 18, ax: 44, wy: -26, ky: 480, cy: 52, tq: 34000, wmax: 42, mu: 1.05, lim: 13 },
  { id: 2,  name: 'Supercar',       price: 2200,  style: 'super',  color: '#f08c00', dark: '#7a4500', stripe: '#ffd43b',
    mc: 6.2, Ic: 6200,  mw: 0.95,rw: 17, ax: 45, wy: -25, ky: 520, cy: 50, tq: 38000, wmax: 48, mu: 1.08, lim: 12 },
  { id: 3,  name: 'Racing Car',     price: 2800,  style: 'race',   color: '#1c7ed6', dark: '#0b3d6b', stripe: '#74c0fc',
    mc: 6.0, Ic: 6000,  mw: 0.9, rw: 17, ax: 46, wy: -24, ky: 540, cy: 48, tq: 36000, wmax: 52, mu: 1.12, lim: 11 },
  { id: 4,  name: 'Formula Car',    price: 4500,  style: 'f1',     color: '#ae3ec9', dark: '#5f1a75', stripe: '#e599f7',
    mc: 5.5, Ic: 5200,  mw: 0.85,rw: 16, ax: 48, wy: -22, ky: 560, cy: 46, tq: 32000, wmax: 58, mu: 1.18, lim: 10 },
  { id: 5,  name: 'Monster Truck',  price: 1800,  style: 'monster',color: '#2f9e44', dark: '#0f4a1c', stripe: '#8ce99a',
    mc: 11,  Ic: 12500, mw: 1.8, rw: 28, ax: 48, wy: -26, ky: 650, cy: 85, tq: 52000, wmax: 24, mu: 1.30, lim: 19 },
  { id: 6,  name: 'SUV',            price: 1200,  style: 'suv',    color: '#495057', dark: '#212529', stripe: '#adb5bd',
    mc: 9.5, Ic: 10500, mw: 1.4, rw: 22, ax: 44, wy: -28, ky: 500, cy: 62, tq: 36000, wmax: 32, mu: 1.15, lim: 15 },
  { id: 7,  name: 'Pickup Truck',   price: 1100,  style: 'pickup', color: '#e67700', dark: '#7a3b00', stripe: '#ffc078',
    mc: 9.0, Ic: 9800,  mw: 1.35,rw: 21, ax: 46, wy: -27, ky: 480, cy: 58, tq: 34000, wmax: 33, mu: 1.12, lim: 15 },
  { id: 8,  name: 'Tractor',        price: 1600,  style: 'tractor',color: '#2b8a3e', dark: '#0f3d1a', stripe: '#8ce99a',
    mc: 12,  Ic: 14000, mw: 2.0, rw: 26, ax: 40, wy: -30, ky: 700, cy: 90, tq: 48000, wmax: 18, mu: 1.35, lim: 20 },
  { id: 9,  name: 'Dirt Bike',      price: 800,   style: 'bike',   color: '#f76707', dark: '#7a3200', stripe: '#ffc078',
    mc: 4.2, Ic: 3800,  mw: 0.7, rw: 16, ax: 38, wy: -22, ky: 380, cy: 42, tq: 22000, wmax: 45, mu: 0.95, lim: 16 },
  { id: 10, name: 'Quad Bike',      price: 1400,  style: 'quad',   color: '#12b886', dark: '#087f5b', stripe: '#96f2d7',
    mc: 5.5, Ic: 5200,  mw: 0.9, rw: 17, ax: 36, wy: -24, ky: 420, cy: 48, tq: 28000, wmax: 38, mu: 1.05, lim: 15 },
  { id: 11, name: 'Monster Bike',   price: 3200,  style: 'mbike',  color: '#c2255c', dark: '#6b1030', stripe: '#f783ac',
    mc: 6.8, Ic: 7200,  mw: 1.3, rw: 24, ax: 42, wy: -25, ky: 580, cy: 70, tq: 40000, wmax: 36, mu: 1.20, lim: 17 },
  { id: 12, name: 'Bus',            price: 2000,  style: 'bus',    color: '#1971c2', dark: '#0b3d6b', stripe: '#74c0fc',
    mc: 14,  Ic: 18000, mw: 1.6, rw: 22, ax: 55, wy: -30, ky: 550, cy: 70, tq: 42000, wmax: 26, mu: 1.05, lim: 14 },
  { id: 13, name: 'School Bus',     price: 1900,  style: 'sbus',   color: '#f59f00', dark: '#7a4d00', stripe: '#ffe066',
    mc: 13.5,Ic: 17000, mw: 1.55,rw: 21, ax: 54, wy: -30, ky: 540, cy: 68, tq: 40000, wmax: 25, mu: 1.05, lim: 14 },
  { id: 14, name: 'Police Car',     price: 2500,  style: 'police', color: '#1a1b1e', dark: '#000',    stripe: '#339af0',
    mc: 7.5, Ic: 7800,  mw: 1.1, rw: 19, ax: 44, wy: -26, ky: 500, cy: 55, tq: 36000, wmax: 46, mu: 1.15, lim: 13 },
  { id: 15, name: 'Ambulance',      price: 2400,  style: 'ambu',   color: '#f8f9fa', dark: '#495057', stripe: '#e03131',
    mc: 9.0, Ic: 9500,  mw: 1.25,rw: 20, ax: 46, wy: -28, ky: 490, cy: 58, tq: 34000, wmax: 38, mu: 1.10, lim: 14 },
  { id: 16, name: 'Fire Truck',     price: 3000,  style: 'fire',   color: '#c92a2a', dark: '#6b1010', stripe: '#ffc9c9',
    mc: 13,  Ic: 16000, mw: 1.7, rw: 23, ax: 52, wy: -29, ky: 600, cy: 75, tq: 45000, wmax: 28, mu: 1.18, lim: 16 },
  { id: 17, name: 'Military Truck', price: 3500,  style: 'mil',    color: '#5c7c3a', dark: '#2b3a1a', stripe: '#a3c46e',
    mc: 12.5,Ic: 15000, mw: 1.6, rw: 23, ax: 50, wy: -28, ky: 620, cy: 78, tq: 48000, wmax: 27, mu: 1.25, lim: 17 },
  { id: 18, name: 'Tank',           price: 6000,  style: 'tank',   color: '#4a5d23', dark: '#2a3514', stripe: '#8ba35a',
    mc: 18,  Ic: 22000, mw: 2.2, rw: 24, ax: 45, wy: -26, ky: 800, cy: 100,tq: 55000, wmax: 16, mu: 1.40, lim: 22 },
  { id: 19, name: 'Excavator',      price: 4200,  style: 'exca',   color: '#e67700', dark: '#7a3b00', stripe: '#ffc078',
    mc: 15,  Ic: 19000, mw: 2.0, rw: 24, ax: 42, wy: -28, ky: 720, cy: 95, tq: 50000, wmax: 14, mu: 1.30, lim: 20 },
  { id: 20, name: 'Bulldozer',      price: 4800,  style: 'dozer',  color: '#f08c00', dark: '#7a4500', stripe: '#ffd43b',
    mc: 16,  Ic: 20000, mw: 2.1, rw: 25, ax: 40, wy: -28, ky: 750, cy: 98, tq: 52000, wmax: 12, mu: 1.35, lim: 21 },
  { id: 21, name: 'Cement Mixer',   price: 3800,  style: 'mixer',  color: '#868e96', dark: '#343a40', stripe: '#ced4da',
    mc: 14,  Ic: 17500, mw: 1.8, rw: 22, ax: 48, wy: -29, ky: 580, cy: 72, tq: 43000, wmax: 22, mu: 1.12, lim: 15 },
  { id: 22, name: 'Snowmobile',     price: 1700,  style: 'snow',   color: '#339af0', dark: '#0b3d6b', stripe: '#a5d8ff',
    mc: 5.0, Ic: 4500,  mw: 0.8, rw: 16, ax: 40, wy: -22, ky: 400, cy: 45, tq: 26000, wmax: 40, mu: 0.90, lim: 14 },
  { id: 23, name: 'Helicopter',     price: 8000,  style: 'heli',   color: '#212529', dark: '#000',    stripe: '#ffd43b',
    mc: 7.0, Ic: 9000,  mw: 1.0, rw: 18, ax: 40, wy: -20, ky: 350, cy: 40, tq: 28000, wmax: 35, mu: 0.85, lim: 12 },
  // --- 20 new original vehicles (inspired by classic hill-climb categories) ---
  { id: 24, name: 'Dune Buggy',     price: 1500,  style: 'quad',   color: '#fab005', dark: '#e67700', stripe: '#ffe066',
    mc: 5.2, Ic: 4800,  mw: 0.85,rw: 18, ax: 38, wy: -24, ky: 430, cy: 50, tq: 29000, wmax: 40, mu: 1.08, lim: 15 },
  { id: 25, name: 'Mini Bike',      price: 600,   style: 'bike',   color: '#82c91e', dark: '#5c940d', stripe: '#c0eb75',
    mc: 3.5, Ic: 2800,  mw: 0.55,rw: 14, ax: 32, wy: -18, ky: 320, cy: 36, tq: 16000, wmax: 38, mu: 0.88, lim: 14 },
  { id: 26, name: 'Super Diesel',   price: 2800,  style: 'pickup', color: '#7048e8', dark: '#4c2a9e', stripe: '#b197fc',
    mc: 11,  Ic: 13000, mw: 1.6, rw: 23, ax: 48, wy: -28, ky: 560, cy: 70, tq: 50000, wmax: 28, mu: 1.22, lim: 17 },
  { id: 27, name: 'Hovercraft',     price: 5500,  style: 'hover',  color: '#15aabf', dark: '#0b7285', stripe: '#66d9e8',
    mc: 7.5, Ic: 8500,  mw: 1.0, rw: 16, ax: 40, wy: -18, ky: 280, cy: 30, tq: 32000, wmax: 36, mu: 0.70, lim: 11 },
  { id: 28, name: 'Hippie Van',     price: 2100,  style: 'van',    color: '#e64980', dark: '#a61e4d', stripe: '#ffc9e0',
    mc: 10,  Ic: 11500, mw: 1.4, rw: 21, ax: 46, wy: -28, ky: 470, cy: 58, tq: 33000, wmax: 30, mu: 1.08, lim: 15 },
  { id: 29, name: 'Rally Car',      price: 2600,  style: 'rally',  color: '#fd7e14', dark: '#d9480f', stripe: '#ffc078',
    mc: 6.5, Ic: 6500,  mw: 1.0, rw: 18, ax: 44, wy: -25, ky: 510, cy: 55, tq: 37000, wmax: 46, mu: 1.20, lim: 13 },
  { id: 30, name: 'Chopper',        price: 2300,  style: 'chopper',color: '#212529', dark: '#000',    stripe: '#ffd43b',
    mc: 5.0, Ic: 5000,  mw: 0.85,rw: 18, ax: 42, wy: -22, ky: 360, cy: 40, tq: 25000, wmax: 42, mu: 0.92, lim: 15 },
  { id: 31, name: 'Lowrider',       price: 2700,  style: 'lowrider',color:'#9c36b5', dark: '#5f1a75', stripe: '#e599f7',
    mc: 7.8, Ic: 8200,  mw: 1.15,rw: 19, ax: 44, wy: -20, ky: 380, cy: 42, tq: 31000, wmax: 34, mu: 1.00, lim: 12 },
  { id: 32, name: 'Hot Rod',        price: 3100,  style: 'hotrod', color: '#c92a2a', dark: '#6b1010', stripe: '#ffc9c9',
    mc: 6.0, Ic: 5800,  mw: 0.95,rw: 17, ax: 46, wy: -24, ky: 490, cy: 50, tq: 40000, wmax: 50, mu: 1.05, lim: 12 },
  { id: 33, name: 'Super Offroad',  price: 3600,  style: 'monster',color: '#2b8a3e', dark: '#0f3d1a', stripe: '#8ce99a',
    mc: 10.5,Ic: 12000, mw: 1.7, rw: 26, ax: 48, wy: -27, ky: 620, cy: 80, tq: 48000, wmax: 26, mu: 1.28, lim: 18 },
  { id: 34, name: 'Moon Rover',     price: 7000,  style: 'moon',   color: '#dee2e6', dark: '#868e96', stripe: '#ffd43b',
    mc: 8.0, Ic: 9500,  mw: 1.3, rw: 22, ax: 44, wy: -26, ky: 400, cy: 48, tq: 30000, wmax: 28, mu: 0.75, lim: 14 },
  { id: 35, name: 'Big Finger',     price: 5000,  style: 'finger', color: '#ff6b6b', dark: '#c92a2a', stripe: '#ffc9c9',
    mc: 9.0, Ic: 11000, mw: 1.5, rw: 30, ax: 50, wy: -28, ky: 600, cy: 75, tq: 45000, wmax: 22, mu: 1.25, lim: 20 },
  { id: 36, name: 'One Wheeler',    price: 3300,  style: 'onewheel',color:'#20c997', dark: '#0ca678', stripe: '#96f2d7',
    mc: 4.0, Ic: 3500,  mw: 1.5, rw: 28, ax: 20, wy: -24, ky: 500, cy: 60, tq: 28000, wmax: 32, mu: 1.10, lim: 16 },
  { id: 37, name: 'RC Buggy',       price: 1900,  style: 'rc',     color: '#ff922b', dark: '#d9480f', stripe: '#ffc078',
    mc: 3.8, Ic: 3200,  mw: 0.6, rw: 14, ax: 30, wy: -18, ky: 450, cy: 48, tq: 20000, wmax: 44, mu: 1.15, lim: 12 },
  { id: 38, name: 'Electric GT',    price: 4000,  style: 'electric',color:'#339af0', dark: '#1864ab', stripe: '#a5d8ff',
    mc: 7.2, Ic: 7200,  mw: 1.05,rw: 18, ax: 45, wy: -25, ky: 530, cy: 52, tq: 42000, wmax: 55, mu: 1.16, lim: 12 },
  { id: 39, name: 'Classic Coupe',  price: 2400,  style: 'classic',color: '#e8590c', dark: '#d9480f', stripe: '#ffc078',
    mc: 7.0, Ic: 7500,  mw: 1.1, rw: 19, ax: 43, wy: -26, ky: 460, cy: 50, tq: 30000, wmax: 36, mu: 1.02, lim: 13 },
  { id: 40, name: 'Cargo Hauler',   price: 2900,  style: 'mil',    color: '#868e96', dark: '#343a40', stripe: '#ced4da',
    mc: 13,  Ic: 16000, mw: 1.7, rw: 23, ax: 52, wy: -29, ky: 580, cy: 72, tq: 44000, wmax: 24, mu: 1.15, lim: 16 },
  { id: 41, name: 'Swamp Boat',     price: 3400,  style: 'hover',  color: '#37b24d', dark: '#2b8a3e', stripe: '#8ce99a',
    mc: 6.5, Ic: 7000,  mw: 0.9, rw: 15, ax: 42, wy: -16, ky: 300, cy: 32, tq: 30000, wmax: 34, mu: 0.65, lim: 10 },
  { id: 42, name: 'Safari Jeep',    price: 2000,  style: 'jeep',   color: '#e67700', dark: '#9c4a00', stripe: '#ffd8a8',
    mc: 8.5, Ic: 9200,  mw: 1.3, rw: 21, ax: 43, wy: -28, ky: 480, cy: 58, tq: 35000, wmax: 32, mu: 1.18, lim: 15 },
  { id: 43, name: 'Rocket Racer',   price: 9000,  style: 'rocket', color: '#fa5252', dark: '#c92a2a', stripe: '#ffd43b',
    mc: 5.8, Ic: 5500,  mw: 0.9, rw: 16, ax: 46, wy: -22, ky: 500, cy: 45, tq: 60000, wmax: 65, mu: 1.10, lim: 11 }
];

// Bridge system: every ~3200 units a bridge marker on the EXISTING road
// 10 types: 0 Wooden, 1 Rope, 2 Broken, 3 Steel, 4 Stone,
// 5 Hanging, 6 Railway, 7 Concrete, 8 Log, 9 Suspension
// IMPORTANT: does NOT modify hill/road geometry. Deck follows exact terrain height.
// Returns { h, onBridge, isGap, shake, bridgeType }
const BRIDGE_PERIOD = 3200;
const BRIDGE_START_OFF = 1800;
const BRIDGE_LEN = 520;
function bridgeIndex(x) {
  return Math.floor((x - BRIDGE_START_OFF) / BRIDGE_PERIOD);
}
// Difficulty scale (grip only from game.js; terrain shape stays identical)
function setDifficulty(d) { /* no terrain change – shape preserved */ }
function terrainInfo(x) {
  if (x < -100) return { h: (-100 - x) * 6, onBridge: false, isGap: false, shake: 0, bridgeType: -1 };
  // Original hill/road formula – UNCHANGED
  const d = Math.max(0, x - 350), r = Math.min(1, d / 4000);
  const e = Math.min(1, d / 300), s = e * e * (3 - 2 * e);
  const a = 28 + r * 55, b = 45 + r * 85;
  let h = a * (Math.sin(x / 300) * 0.55 + Math.sin(x / 130 + 1.7) * 0.3 + Math.sin(x / 61 + 0.4) * 0.12) + b * Math.sin(x / 900 + 0.5);
  const k0 = Math.floor(x / 2400);
  for (let k = k0 - 1; k <= k0; k++) {
    const u = (x - (k * 2400 + 1700 + 500 * Math.sin(k * 12.9898))) / 90;
    h += (45 + 20 * r) * Math.exp(-u * u);
  }
  h = s * h;

  const local = ((x - BRIDGE_START_OFF) % BRIDGE_PERIOD + BRIDGE_PERIOD) % BRIDGE_PERIOD;
  let onBridge = false, isGap = false, shake = 0;
  let bridgeType = -1;

  // Bridge marker only – height stays the original road height (no valley, no arch rewrite)
  if (x > BRIDGE_START_OFF - 20 && local >= 0 && local <= BRIDGE_LEN) {
    const bi = bridgeIndex(x);
    bridgeType = ((bi % 10) + 10) % 10;
    onBridge = true;
    // Tiny surface feedback only (does not change road elevation profile)
    const shakeMul = [0.4, 0.7, 0.65, 0.25, 0.2, 0.8, 0.3, 0.15, 0.55, 0.65][bridgeType];
    shake = (Math.sin(local * 0.3) * 0.7 + Math.sin(local * 1.0) * 0.3) * shakeMul;
    h += shake * 0.03;
  }
  return { h, onBridge, isGap, shake, bridgeType };
}

function height(x) {
  return terrainInfo(x).h;
}
const slope = x => (height(x + 1) - height(x - 1)) / 2;
// expose for rendering
const getTerrain = terrainInfo;

function create() {
  const S = { x: P.start, y: 40, vx: 0, vy: 0, th: 0, om: 0, air: false, crashed: false,
    w: [0, 1].map(i => ({ x: P.start + (i ? 1 : -1) * P.ax, y: 20, vx: 0, vy: 0, w: 0, ang: 0, Jp: 0, hit: false })) };
  S.y = height(P.start) + P.rw - P.wy - P.mc * P.g / (2 * P.ky);
  S.w.forEach(W => { W.y = height(W.x) + P.rw; });
  return S;
}

function pointContact(S, lx, ly, rad, e) {
  const c = Math.cos(S.th), s = Math.sin(S.th);
  const rx = lx * c - ly * s, ry = lx * s + ly * c, px = S.x + rx, py = S.y + ry;
  const sl = slope(px), ny = 1 / Math.sqrt(1 + sl * sl), nx = -sl * ny;
  const pen = rad - (py - height(px)) * ny;
  if (pen <= 0) return false;
  S.x += nx * pen * 0.8; S.y += ny * pen * 0.8;
  const vn = (S.vx - S.om * ry) * nx + (S.vy + S.om * rx) * ny;
  if (vn < 0) {
    const rn = rx * ny - ry * nx, J = -(1 + e) * vn / (1 / P.mc + rn * rn / P.Ic);
    S.vx += J * nx / P.mc; S.vy += J * ny / P.mc; S.om += J * rn / P.Ic;
    S.vx *= 0.995;
  }
  return true;
}

function sub(S, dt, gas, brake, boost) {
  const c = Math.cos(S.th), s = Math.sin(S.th);
  let fcx = 0, fcy = -P.mc * P.g, tq = 0, dOm = 0;
  for (let i = 0; i < 2; i++) {
    const W = S.w[i], sx = i ? 1 : -1, a = sx * P.ax;
    const rx = a * c - P.wy * s, ry = a * s + P.wy * c;
    const ox = a * c + 4 * s, oy = a * s - 4 * c;
    const dx = W.x - (S.x + rx), dy = W.y - (S.y + ry);
    const rvx = W.vx - (S.vx - S.om * ry), rvy = W.vy - (S.vy + S.om * rx);
    const lx = dx * c + dy * s, ly = -dx * s + dy * c;
    const lvx = rvx * c + rvy * s, lvy = -rvx * s + rvy * c;
    let fx = -P.kx * lx - P.cx * lvx, fy = -P.ky * ly - P.cy * lvy;
    if (ly > P.lim) fy -= 6000 * (ly - P.lim); else if (ly < -P.lim) fy -= 6000 * (ly + P.lim);
    const Fx = fx * c - fy * s, Fy = fx * s + fy * c;
    W.fx = Fx; W.fy = Fy - P.mw * P.g;
    fcx -= Fx; fcy -= Fy; tq += ox * -Fy - oy * -Fx;
    // motor / brake on wheel spin
    const w0 = W.w;
    if (gas) W.w += P.tq * (P.sens || 1) * (boost ? 1.2 : 1) * Math.max(0, 1 - W.w / (P.wmax * (boost ? 1.2 : 1))) / P.Iw * dt;
    if (brake) {
      const bm = P.brakeMul || 0.5;
      if (W.w > 0.5) W.w = Math.max(0, W.w - 600 * (bm / 0.5) * dt);
      else W.w -= P.tq * bm * Math.max(0, 1 + W.w / 12) / P.Iw * dt;
    }
    dOm += P.reac * P.Iw * (W.w - w0) / P.Ic;
  }
  S.om += dOm;
  if (S.air) { S.om += (gas - brake) * P.airT / P.Ic * dt; S.om *= 1 - 1.0 * dt; }
  else S.om *= 1 - 0.3 * dt;
  S.vx += fcx / P.mc * dt; S.vy += fcy / P.mc * dt; S.om += tq / P.Ic * dt;
  S.vx *= 1 - P.drag * dt;
  if (boost) { S.vx += Math.cos(S.th) * P.boostF * dt; S.vy += Math.sin(S.th) * P.boostF * dt; }
  S.x += S.vx * dt; S.y += S.vy * dt; S.th += S.om * dt;

  let touch = false;
  for (const W of S.w) {
    W.vx += W.fx / P.mw * dt; W.vy += W.fy / P.mw * dt;
    W.x += W.vx * dt; W.y += W.vy * dt;
    const sl = slope(W.x), ny = 1 / Math.sqrt(1 + sl * sl), nx = -sl * ny;
    const pen = P.rw - (W.y - height(W.x)) * ny;
    W.hit = pen > 0;
    if (W.hit) {
      touch = true;
      W.x += nx * pen; W.y += ny * pen;
      const vn = W.vx * nx + W.vy * ny;
      let Jn = 0;
      if (vn < 0) { Jn = -vn * P.mw; W.vx -= vn * nx; W.vy -= vn * ny; }
      W.Jp = Math.max(Jn, W.Jp * 0.9);
      const tx = ny, ty = sl * ny, u = W.vx * tx + W.vy * ty - W.w * P.rw;
      const Jm = P.mu * P.muMul * W.Jp, k = 1 / P.mw + P.rw * P.rw / P.Iw;
      const J = -Math.max(-Jm, Math.min(Jm, u / k));
      W.vx += J * tx / P.mw; W.vy += J * ty / P.mw; W.w -= J * P.rw / P.Iw;
    } else W.Jp = 0;
    W.ang -= W.w * dt;
  }
  S.air = !touch;
  for (const p of [[-58, -16], [58, -16], [-44, 20], [44, 20]]) pointContact(S, p[0], p[1], 3, 0.2);
  if (pointContact(S, 2, 34, 9, 0)) S.crashed = true;
}

function step(S, dt, gas, brake, n, boost) {
  n = n || 8;
  for (let i = 0; i < n; i++) sub(S, dt / n, gas ? 1 : 0, brake ? 1 : 0, boost ? 1 : 0);
}

function setLevels(l, v) {
  v = v || VEH[0];
  P.mc = v.mc; P.Ic = v.Ic; P.mw = v.mw; P.rw = v.rw; P.Iw = 0.5 * v.mw * v.rw * v.rw;
  P.ax = v.ax; P.wy = v.wy; P.ky = v.ky;
  // Engine / Speed upgrade
  P.tq = v.tq * (1 + 0.18 * (l.eng || 0));
  P.wmax = v.wmax + 1.6 * (l.eng || 0);
  // Tires / grip
  P.mu = v.mu + 0.07 * (l.tire || 0);
  // Suspension
  P.cy = v.cy + 5 * (l.susp || 0);
  P.lim = v.lim + 1.4 * (l.susp || 0);
  // Brake power multiplier (used in sub())
  P.brakeMul = 0.5 + 0.12 * (l.brake || 0);
  P.muMul = 1;
  // Helicopter gets extra air control
  P.airT = (v.style === 'heli') ? 140000 : 90000;
}
const api = { P, VEH, height, slope, create, step, setLevels, setDifficulty, getTerrain, BRIDGE_PERIOD, BRIDGE_START_OFF, BRIDGE_LEN, bridgeIndex };
if (typeof module !== 'undefined') module.exports = api; else root.Phys = api;
})(this);
