Banana Bird: Night Terrors - Level transition repair

1. Extract this ZIP into a new folder.
2. Open index.html in Chrome.
3. Collect all five tapes. On non-boss levels, a NEXT LEVEL button will appear as a backup way to advance if the exit trigger does not fire.
4. On boss levels, defeat the boss first, then use the exit or NEXT LEVEL button.

This is a browser game, not an APK. Test on your device; the complete game has not been device-tested.
