# VICE LEONIDA 3D

Jogo 3D em navegador feito em HTML5 + JavaScript + Three.js, com modo paisagem e controles touch e teclado/mouse.

## Como jogar
1. Extraia o arquivo ZIP e abra o `index.html` em um navegador moderno (Chrome, Edge, Safari ou Firefox).
2. Escolha **Lucia** ou **Jason** e clique em **JOGAR AGORA**.
3. Use o analógico esquerdo para mover e arraste a área direita da tela para girar a câmera em 360°.

## Recursos incluídos
- **Loja de Armas ($100 cada):** Armas por $100 (via NPC Vendedor no calçadão ou botão `LOJA ($100)`), atingindo apenas pessoas/NPCs.
- **Avião:** Entre no avião na pista e use **`▲ SUBIR`** e **`▼ DESCER`** para controlar a altitude.
- **Condomínio ($11.000 por casa):** Compre as casas (`Casa 01`, `Casa 02`, `Casa 03`) por $11.000 e entre para explorar sala com TV e sofá, cozinha, banheiro e quarto.
- **Mar Nadável (5 minutos):** Nade na água além da faixa da praia; se ficar 5 minutos (`05:00`) sem sair, você morre afogado.
- **Atropelamento sem sangue e colisões:** Carros derrubam NPCs sem sangue, colisão carro com carro gera explosão, e bater em prédios aciona a tela **SE FODEU** (toque em qualquer lugar para reviver).
