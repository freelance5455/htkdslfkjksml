/**
 * ULTRA DEEP STATIC ANALYSIS & HEURISTIC ENGINE
 * Compatible with MT Manager & Obfuscated DEX Binary Inspection
 */
window.Analysis = {
    // 1. قواعد الكشف للأسماء المباشرة والمموهة
    HEURISTIC_RULES: [
        // --- الفئة الأولى: اشتراكات وحسابات مدفوعة (Pro / VIP / Subscriptions) ---
        {
            regex: /(is_?pro|is_?vip|is_?premium|is_?subscribed|has_?paid|unlock_?all|is_?license_?valid|check_?subscription|get_?subscription_?status|is_?feature_?unlocked)/i,
            tag: "VIP_FEATURE",
            impact: "تغيير القيمة الإرجاعية إلى true لتفعيل الاشتراك أو الميزة فوراً.",
            score: 1000
        },
        // --- الفئة الثانية: كتل الشراء ومتاجر التطبيقات (Billing & Paywall) ---
        {
            regex: /(com\.android\.vending\.billing|com\.revenuecat|com\.purchases|com\.stripe|InAppPurchase|BillingClient|PaywallActivity)/i,
            tag: "BILLING_SDK",
            impact: "هدف أساسي لتجاوز فحص الاستجابة القادمة من جوجل بلاي أو السيرفر.",
            score: 950
        },
        // --- الفئة الثالثة: تعطيل الإعلانات (Ads Disabling) ---
        {
            regex: /(is_?ad_?enabled|should_?show_?ad|is_?banner_?visible|load_?interstitial)/i,
            tag: "DISABLE_ADS",
            impact: "تغيير القيمة الإرجاعية إلى false لإيقاف عرض كافة الإعلانات داخل التطبيق.",
            score: 900
        },
        // --- الفئة الرابعة: تجاوز الحماية والـ Root/Debugger ---
        {
            regex: /(is_?rooted|is_?tampered|is_?debugger_?present|check_?signature|verify_?installer)/i,
            tag: "BYPASS_SECURITY",
            impact: "تغيير القيمة الإرجاعية إلى false لتجاوز فحوصات البيئة وتعديل APK.",
            score: 850
        },
        // --- الفئة الخامسة: حدود الاستخدام والمهل الزمانية (Trial / Limits) ---
        {
            regex: /(get_?remaining_?trial|is_?trial_?expired|get_?max_?usage_?count|check_?limit)/i,
            tag: "TRIAL_LIMIT",
            impact: "تعديل القيمة لإرجاع قيمة زمنية ممتدة أو عدد استخدامات غير محدود.",
            score: 800
        }
    ],

    // دالة تحويل وتنسيق مسارات Smali لتكون جاهزة للنسخ المباشر والبحث في MT Manager
    formatForMTManager(rawText) {
        if (!rawText || typeof rawText !== 'string') return rawText;
        let clean = rawText.trim();

        if (clean.includes('->')) {
            const parts = clean.split('->');
            let classPart = parts[0].replace(/^L|;$/g, '').replace(/\//g, '.');
            let methodPart = parts[1].split('(')[0];
            return `${classPart} -> ${methodPart}`;
        }

        if (clean.startsWith('L') && clean.endsWith(';')) {
            return clean.substring(1, clean.length - 1).replace(/\//g, '.');
        }

        return clean.replace(/\//g, '.');
    },

    // المحرك الذكي لاستخراج الأهداف القابلة للتعديل
    extractEditableTargets(methods, classes, strings) {
        const results = [];
        const seenTargets = new Set();

        // المستوى 1: البحث المباشر بالدوال المطابقة للقواعد
        methods.forEach(method => {
            const cleanMethod = this.formatForMTManager(method);
            for (const rule of this.HEURISTIC_RULES) {
                if (rule.regex.test(method)) {
                    if (!seenTargets.has(cleanMethod)) {
                        seenTargets.add(cleanMethod);
                        results.push({
                            target: cleanMethod,
                            tag: rule.tag,
                            impact: rule.impact,
                            score: rule.score
                        });
                    }
                    break;
                }
            }
        });

        // المستوى 2 (معد للتطبيقات المموهة): إذا كانت النتائج قليلة، ابحث داخل الكلاسات والنصوص
        if (results.length < 5) {
            classes.forEach(cls => {
                const cleanCls = this.formatForMTManager(cls);
                for (const rule of this.HEURISTIC_RULES) {
                    if (rule.regex.test(cls)) {
                        if (!seenTargets.has(cleanCls)) {
                            seenTargets.add(cleanCls);
                            results.push({
                                target: `${cleanCls} (Class كامل)`,
                                tag: `${rule.tag}_CLASS`,
                                impact: `كلاس يحتوي على شفرات حساسة. ابحث عن الدوال بداخله وعدل قيم الإرجاع Boolean.`,
                                score: rule.score - 100
                            });
                        }
                        break;
                    }
                }
            });
        }

        // المستوى 3 (Deep Fallback): البحث عن النصوص الإشارية وتحويلها لأهداف بحث
        if (results.length === 0) {
            strings.forEach(str => {
                if (/is_?pro|is_?vip|premium|billing|subscription|paywall/i.test(str) && str.length < 60) {
                    const targetStr = `[نص إشاري للبحث] "${str}"`;
                    if (!seenTargets.has(targetStr)) {
                        seenTargets.add(targetStr);
                        results.push({
                            target: targetStr,
                            tag: "STRING_REFERENCE",
                            impact: "ابحث عن هذا النص داخل Smali لتصل الميثود الذي يتحكم بالصلاحية وتعديله.",
                            score: 500
                        });
                    }
                }
            });
        }

        // ترتيب الأهداف تنازلياً حسب الأهمية والأولوية
        return results.sort((a, b) => b.score - a.score);
    },

    processDexFiles(dexFiles) {
        const rawStrings = new Set();
        const rawClasses = new Set();
        const rawMethods = new Set();

        dexFiles.forEach(file => {
            const parsed = DexParser.parse(file.buffer);
            if (parsed.strings) parsed.strings.forEach(s => rawStrings.add(s));
            if (parsed.classes) parsed.classes.forEach(c => rawClasses.add(c));
            if (parsed.methods) parsed.methods.forEach(m => rawMethods.add(m));
        });

        UI.log('🔥 بدء تشغيل محرك التحليل الاستاتيكي العميق المتدرج...', 'info');

        const stringsList = Array.from(rawStrings);
        const classesList = Array.from(rawClasses);
        const methodsList = Array.from(rawMethods);

        // معالجة البيانات العامة
        AppState.parsedData.strings = stringsList;
        AppState.parsedData.classes = classesList.map(c => this.formatForMTManager(c));
        AppState.parsedData.methods = methodsList.map(m => this.formatForMTManager(m));

        // استخراج الأهداف القابلة للتعديل عبر المحرك المتدرج
        const editables = this.extractEditableTargets(methodsList, classesList, stringsList);

        if (editables.length > 0) {
            AppState.parsedData.editable = editables.map((item, idx) => 
                `⚡ [${idx + 1}] الأسلوب: ${item.target}\n` +
                `🏷️ التصنيف: ${item.tag}\n` +
                `💡 الأثر والوظيفة: ${item.impact}\n` +
                `--------------------------------------------------`
            );
        } else {
            AppState.parsedData.editable = [
                "⚠️ لم يتم العثور على أهداف واضحة بالأسماء المباشرة نظرًا للتشفير العالي.",
                "💡 نصيحة: انتقل لتبويب Strings وابحث عن كلمات مثل 'pro' أو 'vip' لربط الاستدعاءات."
            ];
        }

        UI.updateStats(
            dexFiles.length,
            AppState.parsedData.strings.length,
            AppState.parsedData.classes.length,
            AppState.parsedData.methods.length
        );
    }
};
