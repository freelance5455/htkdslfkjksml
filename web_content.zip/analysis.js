/**
 * المحلل الذهبي لملفات الأندرويد (GOLDEN DEX ANALYZER)
 * المحرك العميق المتقدم الهجين (ULTRA-DEEP HEURISTIC & STRUCTURAL ANALYZER V5.2 - مع الباتش التلقائي)
 */

window.Analysis = {
    RULES: [
        {
            id: 'VIP_SUBSCRIPTION',
            category: '💎 إدارة الاشتراكات والتراخيص (VIP/PRO)',
            patterns: [
                /is_?(pro|vip|premium|subscribed|paid|unlocked)/i,
                /check_?(license|subscription|purchase|billing)/i,
                /unlock_?all_?features/i,
                /get_?subscription_?status/i
            ],
            type: 'LOGIC_CHECK',
            level: 'سطحي (Level 1)',
            patchType: 'FORCE_TRUE'
        },
        {
            id: 'BILLING_GATEWAYS',
            category: '💳 بوابات الشراء وشبكات الدفع',
            patterns: [
                /com\.android\.vending\.billing/i,
                /com\.revenuecat/i,
                /com\.purchases/i,
                /com\.stripe/i,
                /com\.paddle/i,
                /BillingClient/i
            ],
            type: 'SDK_INTEGRATION',
            level: 'متوسط (Level 2)',
            patchType: 'FORCE_TRUE'
        },
        {
            id: 'NATIVE_REFLECT',
            category: '⚡ تقنيات الانعكاس والتحميل الديناميكي (Dynamic Loading & Reflection)',
            patterns: [
                /java\.lang\.reflect\.(Method|Field|Class)/i,
                /DexClassLoader/i,
                /PathClassLoader/i,
                /System\.loadLibrary/i
            ],
            type: 'ADVANCED_CORE',
            level: 'عميق (Level 3)',
            patchType: 'NONE'
        },
        {
            id: 'SECURITY_BYPASS',
            category: '🛡️ كشف الحمايات، الروت والأجهزة الوهمية (Anti-Analysis)',
            patterns: [
                /is_?rooted/i,
                /is_?debugger_?present/i,
                /check_?signature/i,
                /detect_?frida/i,
                /is_?emulator/i,
                /check_?xposed/i
            ],
            type: 'SECURITY_CORE',
            level: 'خارق (Level 4)',
            patchType: 'FORCE_FALSE'
        }
    ],

    deepDecodeString(str) {
        if (!str || typeof str !== 'string' || str.length < 16) return null;

        if (str.startsWith('eyJ') && str.includes('.')) {
            try {
                const parts = str.split('.');
                if (parts.length >= 2) {
                    const payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
                    return { type: 'JWT_PAYLOAD', decoded: payload };
                }
            } catch (e) {}
        }

        const b64Regex = /^([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{2}==)?$/;
        if (b64Regex.test(str.trim())) {
            try {
                const decoded = atob(str.trim());
                if (/^[\x20-\x7E]+$/.test(decoded) && (decoded.includes('http') || decoded.includes('{') || decoded.includes('='))) {
                    return { type: 'BASE64_DECODED', decoded: decoded };
                }
            } catch (e) {}
        }

        return null;
    },

    formatSmaliPath(raw) {
        if (!raw || typeof raw !== 'string') return raw;
        let clean = raw.trim();

        if (clean.includes('->')) {
            const parts = clean.split('->');
            let classPart = parts[0].replace(/^L|;$/g, '').replace(/\//g, '.');
            let methodPart = parts[1].split('(')[0];
            return `${classPart} -> ${methodPart}`;
        }

        if (clean.startsWith('L') && clean.endsWith(';')) {
            return clean.substring(1, clean.length - 1).replace(/\//g, '.');
        }

        return clean.replace(/\//g, '.');
    },

    generateAutoPatch(patchType, targetName) {
        if (patchType === 'FORCE_TRUE') {
            return `[Auto-Patch]: ${targetName}\n-> const/4 v0, 0x1\n-> return v0  (تحويل إلى مدفوع دائم / مجاني)`;
        } else if (patchType === 'FORCE_FALSE') {
            return `[Auto-Patch]: ${targetName}\n-> const/4 v0, 0x0\n-> return v0  (تجاوز كشف الحماية/الروت)`;
        }
        return `[Auto-Patch]: ${targetName}\n-> NOP / Bypass Checked`;
    },

    analyzeArtifactsAndNetwork(strings) {
        const results = { endpoints: [], keysAndTokens: [], decodedPayloads: [] };
        const urlRegex = /(https?:\/\/[^\s"'<>\\]+|api\.[a-z0-9\.\-]+\.[a-z]{2,})/gi;
        const keyRegex = /(bearer\s+[a-z0-9\-\._~\+\/]+=*|AIzaSy[a-zA-Z0-9_\-]{33}|access_token\$[a-z0-9_]+)/gi;

        strings.forEach(str => {
            if (urlRegex.test(str)) results.endpoints.push(`🌐 رابط خادم استدعاء: ${str}`);
            if (keyRegex.test(str)) results.keysAndTokens.push(`🔑 مفتاح أمني/توكن حساس: ${str}`);
            const decodedObj = this.deepDecodeString(str);
            if (decodedObj) {
                if (decodedObj.type === 'JWT_PAYLOAD') {
                    results.decodedPayloads.push(`🔓 توكن JWT مفكوك: ${JSON.stringify(decodedObj.decoded)}`);
                } else if (decodedObj.type === 'BASE64_DECODED') {
                    results.decodedPayloads.push(`📦 نص Base64 محمول مفكوك: ${decodedObj.decoded}`);
                }
            }
        });
        return results;
    },

    analyzeDeepTargets(methods, classes, strings) {
        const targets = [];
        const visited = new Set();
        const methodsArray = Array.isArray(methods) ? methods : Array.from(methods);
        const classesArray = Array.isArray(classes) ? classes : Array.from(classes);

        methodsArray.forEach(method => {
            const formatted = this.formatSmaliPath(method);
            for (const rule of this.RULES) {
                if (rule.patterns.some(p => p.test(method))) {
                    if (!visited.has(formatted)) {
                        visited.add(formatted);
                        targets.push({
                            target: formatted,
                            category: rule.category,
                            level: rule.level,
                            type: rule.type,
                            patchType: rule.patchType,
                            score: 900
                        });
                    }
                    break;
                }
            }
        });

        classesArray.forEach(cls => {
            const formatted = this.formatSmaliPath(cls);
            for (const rule of this.RULES) {
                if (rule.patterns.some(p => p.test(cls))) {
                    if (!visited.has(formatted)) {
                        visited.add(formatted);
                        targets.push({
                            target: `[Class] ${formatted}`,
                            category: `${rule.category} (فئة كاملة)`,
                            level: rule.level,
                            type: 'CLASS_CONTAINER',
                            patchType: rule.patchType,
                            score: 750
                        });
                    }
                    break;
                }
            }
        });

        return targets.sort((a, b) => b.score - a.score);
    },

    processDexFiles(dexFiles) {
        const stringsSet = new Set();
        const classesSet = new Set();
        const methodsSet = new Set();

        dexFiles.forEach(file => {
            const parsed = DexParser.parse(file.buffer);
            if (parsed.strings) parsed.strings.forEach(s => stringsSet.add(s));
            if (parsed.classes) parsed.classes.forEach(c => classesSet.add(c));
            if (parsed.methods) parsed.methods.forEach(m => methodsSet.add(m));
        });

        if (window.UI) UI.log('🚀 بدء التحليل التدريجي الخارق V5.2 وإعداد باتشات التحرير...', 'info');

        const strings = Array.from(stringsSet);
        const classes = Array.from(classesSet).map(c => this.formatSmaliPath(c));
        const methods = Array.from(methodsSet).map(m => this.formatSmaliPath(m));

        AppState.parsedData.strings = strings;
        AppState.parsedData.classes = classes;
        AppState.parsedData.methods = methods;
        AppState.parsedData.dexCount = dexFiles.length;

        const artifacts = this.analyzeArtifactsAndNetwork(strings);
        const deepTargets = this.analyzeDeepTargets(methods, classes, strings);

        AppState.parsedData.sensitiveData = [
            ...artifacts.endpoints,
            ...artifacts.keysAndTokens,
            ...artifacts.decodedPayloads
        ];

        if (deepTargets.length > 0) {
            AppState.parsedData.editable = deepTargets.map((item, idx) => {
                const patchCode = this.generateAutoPatch(item.patchType, item.target);
                return `⚡ [باتش تلقائي #${idx + 1}] المسار: ${item.target}\n` +
                       `📌 التصنيف: ${item.category}\n` +
                       `🛠️ كود الحقن المقترح:\n${patchCode}\n` +
                       `--------------------------------------------------`;
            });
        } else {
            AppState.parsedData.editable = [
                "⚠️ لم يتم العثور على توقيعات اشتراك صريحة (التطبيق محمي بتمويه مكثف).",
                "💡 نصيحة الأستاذ: افحص تبويب SENSITIVE DATA لمتابعة طلبات الشبكة."
            ];
        }

        if (window.UI) {
            UI.updateStats(dexFiles.length, strings.length, classes.length, methods.length);
            UI.log('✅ اكتمل استخراج ملفات الـ DEX وبناء حزم الباتشات بنجاح.', 'success');
        }
    }
};
