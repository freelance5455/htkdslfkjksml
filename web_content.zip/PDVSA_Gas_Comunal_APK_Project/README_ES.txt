PROYECTO ANDROID - PDVSA GAS COMUNAL CONTROL CISTERNA

Este ZIP contiene el proyecto fuente para abrir en Android Studio y compilar la APK.
La aplicación carga el archivo HTML local desde app/src/main/assets/index.html.

ACTUALIZACIÓN:
- Capacidad nominal de la cisterna ingresada en galones.
- Porcentaje inicial editable de 0 a 100.
- Cálculo automático de litros iniciales: galones × porcentaje / 100 × 3,7854.
- El balance de litros disponibles parte de los litros iniciales y descuenta los despachos.

Para generar la APK:
1. Abra la carpeta del proyecto en Android Studio.
2. Espere a que Gradle termine la sincronización.
3. Seleccione Build > Build APK(s).
4. La APK de depuración se encontrará normalmente en app/build/outputs/apk/debug/app-debug.apk.

Este archivo ZIP es el proyecto fuente, no una APK compilada.
