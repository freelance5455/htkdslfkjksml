/* INJAZ 4.1 additive features — keeps the injaz_ storage namespace and original records. */
(() => {
  'use strict';
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const read = (k, fallback) => { try { const raw=localStorage.getItem('injaz_'+k); return raw===null?fallback:JSON.parse(raw); } catch { return fallback; } };
  const write = (k,v) => { try { localStorage.setItem('injaz_'+k,JSON.stringify(v)); return true; } catch { window.toast?.('تعذر حفظ البيانات. صدّر نسخة احتياطية وتأكد من مساحة الجهاز.'); return false; } };
  const arr = x => Array.isArray(x)?x:[];
  const today = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
  const shift = (k,n) => { const d=new Date(k+'T12:00:00');d.setDate(d.getDate()+n);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
  const uid = p => `${p}_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
  const toast = m => window.toast?.(m);
  const pageIds = ['rewards','weekly-review','garden'];
  const page = (id,title,desc,icon,body) => `<section class="page injaz-extra-page" id="page-${id}"><div class="page-title"><div><span class="eyebrow">إنجاز | خطوة جديدة في رحلتك</span><h2>${title}</h2><p>${desc}</p></div><div class="title-emoji">${icon}</div></div>${body}</section>`;

  function injectFeatures(){
    const nav=$('.nav'),main=$('.main'); if(!nav||!main)return;
    const navWrap=document.createElement('div');navWrap.id='injazNewNav';
    navWrap.innerHTML='<div class="nav-group-label">مكافآتك وتقدمك</div><button class="nav-item" data-page="rewards"><span>🎁</span> متجر المكافآت</button><button class="nav-item" data-page="weekly-review"><span>🗓️</span> المراجعة الأسبوعية</button><button class="nav-item" data-page="garden"><span>🌷</span> حديقة الإنجاز</button><button class="nav-item injaz-mobile-profile" data-page="profile"><span>👤</span> مساحتي</button>';
    nav.append(navWrap);
    const html=[
      page('rewards','متجر المكافآت الشخصية','حوّل نقاط إنجازك إلى مكافآت حقيقية تختارها لنفسك.','🎁',`<section class="panel reward-wallet"><div><small>رصيدك المتاح</small><strong id="shopBalance">0</strong><small>نقطة قابلة للاستبدال</small></div><div><small>إجمالي ما كسبته</small><strong id="shopLifetime">0</strong><small>نقطة خبرة</small></div><div><small>مكافآت استلمتها</small><strong id="shopRedeemed">0</strong><small>مرة</small></div></section><section class="panel"><div class="panel-head"><div><h3>أضف مكافأتك الخاصة</h3><p>اكتب مكافأة تحب تكافئ نفسك بيها وحدد تكلفتها.</p></div><span>✨</span></div><form id="personalRewardForm" class="v4-form reward-form"><input id="personalRewardName" maxlength="70" placeholder="مثلاً: ساعة لعب أو خروجة" required><input id="personalRewardCost" type="number" min="1" max="100000" value="50" required placeholder="تكلفة النقاط"><button class="primary-btn">إضافة المكافأة</button></form></section><section class="panel"><div class="panel-head"><div><h3>المكافآت المتاحة</h3><p>استبدل نقاطك عندما يكون رصيدك كافيًا.</p></div></div><div id="rewardCatalog" class="reward-catalog"></div></section><section class="panel"><h3>سجل المكافآت المستبدلة</h3><div id="rewardHistory" class="feature-list"></div></section>`),
      page('weekly-review','مراجعتك الأسبوعية','راجع أسبوعك بهدوء، احتفل بما أنجزته، وحدد تركيزك للأسبوع القادم.','🗓️',`<section class="panel"><div class="panel-head"><div><h3>ملخص آخر 7 أيام</h3><p id="reviewPeriod"></p></div><span>📊</span></div><div id="reviewStats" class="report-stats"></div></section><section class="panel"><h3>مراجعة الأسبوع</h3><form id="weeklyReviewForm" class="review-form"><label>أكبر إنجاز حققته<textarea id="reviewWin" maxlength="500" rows="3" placeholder="اكتب حاجة فخور إنك عملتها..."></textarea></label><label>أكبر تحدي واجهك<textarea id="reviewChallenge" maxlength="500" rows="3" placeholder="إيه اللي كان صعب؟ وإيه اللي اتعلمته؟"></textarea></label><label>أهم أولوية للأسبوع القادم<textarea id="reviewNext" maxlength="500" rows="3" placeholder="اختار حاجة واحدة تركز عليها..."></textarea></label><button class="primary-btn">حفظ المراجعة الأسبوعية</button></form><p id="reviewSaved" class="muted-line"></p></section><section class="panel"><h3>مراجعاتك السابقة</h3><div id="reviewHistory" class="feature-list"></div></section>`),
      page('garden','حديقة الإنجاز','كل مهمة وعادة ودقيقة تركيز بتسقي حديقتك وتساعدها تكبر.','🌷',`<section class="panel garden-hero"><div class="garden-sky"><div class="garden-sun">☀️</div><div class="garden-cloud">☁️</div><div class="garden-plants" id="gardenPlants">🌱</div><div class="garden-ground"></div></div><div class="garden-caption"><div><small>مرحلة حديقتك</small><h3 id="gardenStage">بذرة البداية</h3><p id="gardenMessage">ابدأ بخطوة صغيرة واسقِ حديقتك بالإنجاز.</p></div><strong id="gardenXP">0 XP</strong></div><div class="progress-track"><i id="gardenProgress"></i></div></section><section class="panel"><h3>إيه اللي فتحته؟</h3><div id="gardenMilestones" class="garden-milestones"></div></section><section class="panel"><h3>زينة حديقتك</h3><p class="muted-line">تقدر تفتح خلفيات وزينة إضافية من «عالم إنجاز» مع زيادة نقاطك.</p><button class="secondary-btn" data-go="plus">افتح عالم إنجاز</button></section>`)
    ].join('');
    const footer=$('footer',main); if(!$('#page-rewards'))footer?.insertAdjacentHTML('beforebegin',html);
    const timerTip=$('#page-timer .timer-tip');
    if(timerTip&&!$('#deepFocusPanel'))timerTip.insertAdjacentHTML('afterend',`<section class="panel deep-focus-panel" id="deepFocusPanel"><div class="panel-head"><div><h3>وضع الإنجاز العميق</h3><p>اخفِ القوائم والمشتتات وخلّي المؤقت قدامك.</p></div><span>🎯</span></div><input id="deepFocusIntent" maxlength="100" placeholder="أنا مركز الآن على..." aria-label="هدف جلسة التركيز"><button class="primary-btn" id="deepFocusToggle" type="button">ابدأ وضع الإنجاز العميق</button><button class="secondary-btn" id="deepFocusExit" type="button" hidden>إنهاء الوضع العميق</button></section>`);
  }
  injectFeatures();

  function showPage(id){
    $$('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+id));
    $$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.page===id));
    document.body.classList.remove('deep-focus-mode');
    const toggle=$('#deepFocusToggle'),exit=$('#deepFocusExit');if(toggle)toggle.hidden=false;if(exit)exit.hidden=true;
    window.scrollTo({top:0,behavior:'smooth'});renderPage(id);
  }
  // Capture the profile and new-page actions before older delegated navigation handlers.
  document.addEventListener('click',e=>{
    const target=e.target.closest('[data-page]');if(!target)return;
    const id=target.dataset.page;if(id==='profile'||pageIds.includes(id)){e.preventDefault();e.stopImmediatePropagation();showPage(id);}
  },true);
  // Keyboard activation for the profile tile remains supported.
  $('.sidebar .profile')?.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();showPage('profile');}});
  document.addEventListener('click',e=>{
    const go=e.target.closest('[data-go]');if(go&&go.dataset.go==='plus'){setTimeout(()=>window.renderWorld?.(),60);}
  });

  const defaults=[
    {id:'rest15',name:'استراحة 15 دقيقة',cost:25,icon:'☕',description:'خد استراحة قصيرة بعيد عن المهام.'},
    {id:'hobby',name:'وقت لهوايتك',cost:45,icon:'🎨',description:'خصص وقتًا لشيء بتحبه.'},
    {id:'treat',name:'حاجة بتحبها',cost:60,icon:'🍰',description:'كافئ نفسك بحاجة بسيطة ومبهجة.'},
    {id:'freehour',name:'ساعة لنفسك',cost:90,icon:'🌿',description:'ساعة كاملة من غير ضغط أو التزامات.'}
  ];
  function getCatalog(){let c=read('rewardCatalog',null);if(!Array.isArray(c)){c=defaults.map(x=>({...x,default:true}));write('rewardCatalog',c);}return c;}
  function xpBreakdown(){
    const tasks=arr(read('tasks',[])),habits=arr(read('habits',[])),sessions=arr(read('focusSessions',[])),planDone=arr(read('planDone',[])),challenges=arr(read('personalChallenges',[])),ledger=arr(read('challengeRewards',[]));
    const taskXP=tasks.filter(t=>t.done).length*10;
    const habitXP=habits.reduce((n,h)=>n+new Set(arr(h.logs).map(x=>typeof x==='string'?x:x?.date).filter(Boolean).map(x=>String(x).slice(0,10))).size*3,0);
    const sessionXP=new Set(sessions.map((s,i)=>s.id??`legacy-${i}`)).size*5;
    const planXP=new Set(planDone.map(String)).size*2;
    const challengeXP=ledger.reduce((n,c)=>n+Math.max(0,Number(c.xp)||0),0)+challenges.filter(c=>c.rewardClaimed&&!ledger.some(r=>String(r.challengeId)===String(c.id))).reduce((n,c)=>n+Math.max(0,Number(c.rewardXP)||20),0);
    return {tasks:taskXP,habits:habitXP,sessions:sessionXP,plans:planXP,challenges:challengeXP,total:taskXP+habitXP+sessionXP+planXP+challengeXP};
  }
  function spentPoints(){return arr(read('rewardPurchases',[])).reduce((n,x)=>n+Math.max(0,Number(x.cost)||0),0);}
  function availablePoints(){return Math.max(0,xpBreakdown().total-spentPoints());}
  function renderRewards(){
    const xp=xpBreakdown(),spent=spentPoints(),balance=availablePoints();
    $('#shopBalance').textContent=balance;$('#shopLifetime').textContent=xp.total;$('#shopRedeemed').textContent=arr(read('rewardPurchases',[])).length;
    const catalog=getCatalog();
    $('#rewardCatalog').innerHTML=catalog.length?catalog.map(x=>`<article class="reward-card"><div class="reward-icon">${esc(x.icon||'🎁')}</div><div class="reward-info"><b>${esc(x.name)}</b><small>${esc(x.description||'مكافأة شخصية')}</small><strong>${Math.max(1,Number(x.cost)||1)} نقطة</strong></div><div class="reward-actions"><button type="button" data-redeem-reward="${esc(x.id)}" ${balance<Number(x.cost)?'disabled':''}>استبدال</button>${!x.default?`<button type="button" data-delete-reward="${esc(x.id)}" aria-label="حذف المكافأة">حذف</button>`:''}</div></article>`).join(''):'<p class="muted-line">أضف أول مكافأة شخصية ليك.</p>';
    const history=arr(read('rewardPurchases',[])).slice().reverse();$('#rewardHistory').innerHTML=history.length?history.map(x=>`<div class="feature-row"><span>${esc(x.name)}</span><small>${new Date(x.at).toLocaleDateString('ar-EG')}</small><b>-${Number(x.cost)||0} نقطة</b></div>`).join(''):'<p class="muted-line">لسه ما استبدلتش أي مكافأة. أول مكافأة قربت!</p>';
    const total=$('#pointsTotal');if(total)total.textContent=xp.total+' نقطة';
  }
  $('#personalRewardForm')?.addEventListener('submit',e=>{e.preventDefault();const name=$('#personalRewardName').value.trim(),cost=Number($('#personalRewardCost').value);if(!name||!Number.isInteger(cost)||cost<1)return toast('اكتب اسم المكافأة وتكلفة صحيحة.');const c=getCatalog();c.push({id:uid('customreward'),name,cost,icon:'🎁',description:'مكافأتك الخاصة',default:false,createdAt:Date.now()});if(write('rewardCatalog',c)){e.target.reset();$('#personalRewardCost').value=50;renderRewards();toast('اتضافت مكافأتك للمتجر.');}});
  $('#rewardCatalog')?.addEventListener('click',e=>{const redeem=e.target.closest('[data-redeem-reward]'),del=e.target.closest('[data-delete-reward]');if(del){const c=getCatalog().filter(x=>String(x.id)!==del.dataset.deleteReward);write('rewardCatalog',c);renderRewards();return;}if(!redeem)return;const item=getCatalog().find(x=>String(x.id)===redeem.dataset.redeemReward);if(!item)return;const cost=Math.max(1,Number(item.cost)||1);if(availablePoints()<cost)return toast('رصيدك الحالي مش كفاية لاستبدال المكافأة.');if(!confirm(`استبدال «${item.name}» مقابل ${cost} نقطة؟`))return;const purchases=arr(read('rewardPurchases',[]));purchases.push({id:uid('purchase'),rewardId:item.id,name:item.name,cost,at:new Date().toISOString()});if(write('rewardPurchases',purchases)){renderRewards();renderGarden();toast('مبروك! تم تسجيل استبدال المكافأة 🎉');}});

  function weekRange(){const end=today(),d=new Date(end+'T12:00:00');d.setDate(d.getDate()-6);return {start:`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`,end};}
  function weeklyStats(){const {start,end}=weekRange(),tasks=arr(read('tasks',[])),habits=arr(read('habits',[])),sessions=arr(read('focusSessions',[])),rewards=xpBreakdown();const done=tasks.filter(t=>t.done&&String(t.completedDate||'').slice(0,10)>=start&&String(t.completedDate||'').slice(0,10)<=end).length;const focus=sessions.filter(s=>String(s.date||'').slice(0,10)>=start&&String(s.date||'').slice(0,10)<=end).reduce((n,s)=>n+(Number(s.minutes)||0),0);const habitCount=habits.reduce((n,h)=>n+arr(h.logs).filter(x=>{const k=String(typeof x==='string'?x:x?.date||'').slice(0,10);return k>=start&&k<=end;}).length,0);return {start,end,done,focus,habitCount,pending:tasks.filter(t=>!t.done&&!t.archived&&t.date>=start&&t.date<=end).length,rewards};}
  function weekKey(){const d=new Date();d.setDate(d.getDate()-((d.getDay()+6)%7));return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
  function renderWeeklyReview(){const s=weeklyStats(),key=weekKey(),reviews=arr(read('weeklyReviews',[])),old=reviews.find(x=>x.week===key);$('#reviewPeriod').textContent=`من ${s.start} إلى ${s.end}`;$('#reviewStats').innerHTML=[['مهام مكتملة',s.done],['دقائق تركيز',s.focus],['مرات إكمال العادات',s.habitCount],['مهام متبقية',s.pending],['إجمالي نقاط الخبرة',s.rewards.total]].map(x=>`<div><strong>${x[1]}</strong><small>${x[0]}</small></div>`).join('');if(!$('#weeklyReviewForm')?.dataset.dirty){$('#reviewWin').value=old?.win||'';$('#reviewChallenge').value=old?.challenge||'';$('#reviewNext').value=old?.next||'';}$('#reviewSaved').textContent=old?'تم حفظ مراجعة هذا الأسبوع. يمكنك تعديلها في أي وقت.':'لم تحفظ مراجعة هذا الأسبوع بعد.';$('#reviewHistory').innerHTML=reviews.filter(x=>x.week!==key).slice().sort((a,b)=>b.week.localeCompare(a.week)).slice(0,8).map(x=>`<div class="feature-row"><span>أسبوع ${esc(x.week)}</span><small>${esc(x.next||'لا توجد أولوية مسجلة')}</small><b>✓</b></div>`).join('')||'<p class="muted-line">ستظهر مراجعاتك السابقة هنا.</p>';}
  $('#weeklyReviewForm')?.addEventListener('input',e=>{e.currentTarget.dataset.dirty='1';});
  $('#weeklyReviewForm')?.addEventListener('submit',e=>{e.preventDefault();const reviews=arr(read('weeklyReviews',[])),key=weekKey(),record={week:key,win:$('#reviewWin').value.trim(),challenge:$('#reviewChallenge').value.trim(),next:$('#reviewNext').value.trim(),updatedAt:new Date().toISOString()};const i=reviews.findIndex(x=>x.week===key);if(i>=0)reviews[i]=record;else reviews.push(record);if(write('weeklyReviews',reviews)){e.currentTarget.dataset.dirty='';renderWeeklyReview();toast('اتحفظت مراجعتك الأسبوعية.');}});

  const stages=[{min:0,name:'بذرة البداية',icon:'🌱',msg:'كل إنجاز صغير بيسقي حديقتك.'},{min:50,name:'براعم جديدة',icon:'🌿',msg:'حديقتك بدأت تخضر. استمر!'},{min:120,name:'حديقة مزهرة',icon:'🌷',msg:'إنجازاتك بدأت تظهر في كل ركن.'},{min:250,name:'حديقة مزدهرة',icon:'🌳',msg:'أصبحت حديقتك مليانة حياة.'},{min:450,name:'واحة الإنجاز',icon:'🏡',msg:'بنيت مساحة جميلة بالاستمرار.'}];
  function renderGarden(){const xp=xpBreakdown().total,idx=stages.reduce((a,s,i)=>xp>=s.min?i:a,0),stage=stages[idx],next=stages[idx+1],progress=next?Math.min(100,(xp-stage.min)/(next.min-stage.min)*100):100,decor=arr(read('world',{decor:[]}).decor),flowers=Math.min(18,Math.floor(xp/18));$('#gardenStage').textContent=stage.name;$('#gardenPlants').textContent=stage.icon+' '+('🌼'.repeat(Math.min(7,flowers)))+' '+decor.map(x=>({flower:'🌸',star:'⭐',butterfly:'🦋',lantern:'🏮'}[x]||'')).join(' ');$('#gardenMessage').textContent=stage.msg;$('#gardenXP').textContent=xp+' XP';$('#gardenProgress').style.width=progress+'%';$('#gardenMilestones').innerHTML=stages.map((x,i)=>`<div class="garden-milestone ${idx>=i?'unlocked':''}"><span>${idx>=i?x.icon:'🔒'}</span><b>${x.name}</b><small>${x.min} XP</small></div>`).join('');}

  function renderPage(id){if(id==='rewards')renderRewards();if(id==='weekly-review')renderWeeklyReview();if(id==='garden')renderGarden();if(id==='profile'){window.renderInjazProfile?.();}}
  window.refreshInjazEnhancements=()=>{renderRewards();renderWeeklyReview();renderGarden();};
  window.addEventListener('storage',e=>{if(e.key?.startsWith('injaz_'))window.refreshInjazEnhancements();});
  document.addEventListener('click',e=>{if(e.target.closest('.task-check,.habit-check,.habit-delete,.delete-btn,#timerStart,#timerReset,[data-plan-check],[data-challenge-claim],[data-challenge-delete]'))setTimeout(window.refreshInjazEnhancements,90);});
  document.addEventListener('submit',e=>{if(e.target.matches('#taskForm,#habitForm,#challengeForm,#profileForm'))setTimeout(window.refreshInjazEnhancements,100);});

  // Distraction-free timer view. The intent stays local and is not sent anywhere.
  $('#deepFocusToggle')?.addEventListener('click',()=>{document.body.classList.add('deep-focus-mode');$('#deepFocusToggle').hidden=true;$('#deepFocusExit').hidden=false;$('#timerStatus').textContent=$('#deepFocusIntent').value.trim()||'أنت في وضع الإنجاز العميق. خليك مع خطوة واحدة.';});
  $('#deepFocusExit')?.addEventListener('click',()=>{document.body.classList.remove('deep-focus-mode');$('#deepFocusToggle').hidden=false;$('#deepFocusExit').hidden=true;});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&document.body.classList.contains('deep-focus-mode'))$('#deepFocusExit')?.click();});

  // First paint after the previous scripts have injected their existing sections.
  renderRewards();renderWeeklyReview();renderGarden();
})();
