/* INJAZ V4 selected features — offline, local-first */
(() => {
  'use strict';
  const $ = (s, r=document) => r.querySelector(s);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const read = (key, fallback=[]) => { try { return JSON.parse(localStorage.getItem('injaz_'+key)) ?? fallback; } catch { return fallback; } };
  const write = (key, value) => { try { localStorage.setItem('injaz_'+key, JSON.stringify(value)); } catch {} };
  const keyDate = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const today = () => keyDate(new Date());
  const shift = (date, n) => { const d=new Date(date+'T12:00:00'); d.setDate(d.getDate()+n); return keyDate(d); };
  const dateLabel = key => new Date(key+'T12:00:00').toLocaleDateString('ar-EG',{weekday:'short',day:'numeric',month:'short'});
  const getTasks = () => read('tasks', []);
  const getHabits = () => read('habits', []);
  const getSessions = () => read('focusSessions', []);
  let ideas = read('ideaBox', []), challenges = read('personalChallenges', []);
  let searchResults = [];

  function injectUI(){
    const plus = $('#page-plus');
    if (plus && !$('#v4Growth')) {
      const grid = $('.v3-grid', plus);
      const section = document.createElement('section'); section.id='v4Growth'; section.className='v4-grid';
      section.innerHTML = `
        <section class="panel v4-level-panel"><div class="panel-head"><div><h3>مستويات الإنجاز</h3><p>كل خطوة حقيقية تزود خبرتك وتفتح مستوى جديدًا.</p></div><span>🏆</span></div><div class="v4-level-line"><div><strong id="v4LevelName">بذرة البداية</strong><small id="v4XpText">0 XP</small></div><span id="v4LevelIcon">🌱</span></div><div class="progress-track"><i id="v4LevelProgress"></i></div><small id="v4NextLevel" class="muted-line"></small></section>
        <section class="panel"><div class="panel-head"><div><h3>سلسلة الإنجاز 🔥</h3><p>أيام متتالية فيها نشاط حقيقي.</p></div><span>📆</span></div><div class="v4-streak"><strong id="v4Streak">0</strong><span>يوم متواصل</span></div><div id="v4StreakDays" class="v4-streak-days"></div><small id="v4StreakHint" class="muted-line"></small></section>
        <section class="panel"><div class="panel-head"><div><h3>رسالة اليوم</h3><p>كلمة صغيرة لبداية ألطف.</p></div><span>💌</span></div><blockquote id="v4DailyMessage" class="v4-message"></blockquote><small id="v4MessageDate" class="muted-line"></small></section>
        <section class="panel v4-analysis"><div class="panel-head"><div><h3>تحليل أدائك</h3><p>مقارنة حقيقية لآخر سبعة أيام.</p></div><span>📈</span></div><div class="v4-analysis-summary"><div><strong id="v4WeekTasks">0</strong><small>مهام مكتملة</small></div><div><strong id="v4WeekFocus">0</strong><small>دقيقة تركيز</small></div><div><strong id="v4WeekHabits">0</strong><small>عادات مكتملة</small></div></div><div id="v4PerformanceChart" class="v4-chart"></div><p id="v4BestDay" class="muted-line"></p></section>
        <section class="panel v4-challenges"><div class="panel-head"><div><h3>تحدياتي الشخصية</h3><p>اختر هدفًا صغيرًا وتابع تقدمك.</p></div><span>🎯</span></div><form id="v4ChallengeForm" class="v4-form"><input id="v4ChallengeTitle" maxlength="55" placeholder="اسم التحدي" required><select id="v4ChallengeType"><option value="tasks">إنجاز مهام</option><option value="focus">دقائق تركيز</option><option value="habits">إكمال عادات</option></select><input id="v4ChallengeTarget" type="number" min="1" max="1000" value="5" aria-label="الهدف"><button class="primary-btn">إضافة تحدي</button></form><div id="v4ChallengeList" class="feature-list"></div></section>`;
      grid?.append(section);
    }
    const notesPage = $('#page-notes');
    if (notesPage && !$('#v4IdeaBox')) {
      const box = document.createElement('section'); box.id='v4IdeaBox'; box.className='panel v4-ideas';
      box.innerHTML = `<div class="panel-head"><div><h3>صندوق الأفكار 💡</h3><p>احفظ أي فكرة بسرعة وارجع لها وقت ما تحب.</p></div><span>📥</span></div><form id="v4IdeaForm" class="v4-form v4-idea-form"><input id="v4IdeaInput" maxlength="180" placeholder="اكتب الفكرة قبل ما تطير من بالك..." required><button class="primary-btn">حفظ الفكرة</button></form><div id="v4IdeaList" class="feature-list"></div>`;
      notesPage.append(box);
    }
    const search = $('#globalSearch');
    if(search && !$('#v4SearchResults')){
      const panel=document.createElement('div'); panel.id='v4SearchResults'; panel.className='v4-search-results'; panel.hidden=true; search.parentElement.append(panel);
      search.setAttribute('autocomplete','off');
    }
  }

  const levels = [
    {name:'بذرة البداية',icon:'🌱',min:0,max:49},
    {name:'خطوة ثابتة',icon:'🌿',min:50,max:119},
    {name:'صانع الإنجاز',icon:'🪴',min:120,max:249},
    {name:'قمة النشاط',icon:'🌳',min:250,max:449},
    {name:'أسطورة الإنجاز',icon:'🏆',min:450,max:Infinity}
  ];
  const messages = [
    'ابدأ بما تستطيع، فالبداية الصغيرة أفضل من انتظار اللحظة المثالية.',
    'مش لازم تنجز كل شيء اليوم؛ خطوة واحدة بتركيز كفاية.',
    'الاستمرار الهادئ أقوى من الحماس اللي بيختفي بسرعة.',
    'كل دقيقة بتستثمرها في هدفك بتقربك منه.',
    'قارن نفسك بتقدمك أنت، مش بسرعة الآخرين.',
    'لو اليوم مزدحم، اختار أهم مهمة وابدأ بها.',
    'الراحة جزء من الإنجاز؛ خذ وقتك وارجع بهدوء.'
  ];
  function activityDays(){
    const days=new Set();
    getTasks().forEach(t=>{if(t.done&&t.completedDate)days.add(t.completedDate)});
    getHabits().forEach(h=>(h.logs||[]).forEach(d=>days.add(typeof d==='string'?d:d.date)));
    getSessions().forEach(s=>{if(s.date){const d=String(s.date).slice(0,10);days.add(d)}});
    return days;
  }
  function calcStreak(){
    const days=activityDays(), t=today(); let cursor=days.has(t)?t:shift(t,-1), count=0;
    while(days.has(cursor)&&count<500){count++;cursor=shift(cursor,-1)}
    return {count,days};
  }
  function xpTotal(){
    const tasks=getTasks().filter(t=>t.done).length;
    const habits=getHabits().reduce((n,h)=>n+(h.logs||[]).length,0);
    const sessions=getSessions().reduce((n,s)=>n+(Number(s.minutes)>0?1:0),0);
    const plans=new Set(read('planDone',[]).map(String)).size*2; const challengeRewards=read('challengeRewards',[]).reduce((n,c)=>n+Math.max(0,Number(c.xp)||0),0)+read('personalChallenges',[]).filter(c=>c.rewardClaimed&&!read('challengeRewards',[]).some(r=>String(r.challengeId)===String(c.id))).reduce((n,c)=>n+Math.max(0,Number(c.rewardXP)||20),0); return tasks*10+habits*3+sessions*5+plans+challengeRewards;
  }
  function renderLevels(){
    const xp=xpTotal(), level=levels.find(x=>xp>=x.min&&xp<=x.max)||levels[0], idx=levels.indexOf(level), next=levels[idx+1];
    $('#v4LevelName').textContent=level.name; $('#v4LevelIcon').textContent=level.icon; $('#v4XpText').textContent=`${xp} XP`;
    const span=next?next.min-level.min:1, progress=next?Math.min(100,((xp-level.min)/span)*100):100;
    $('#v4LevelProgress').style.width=progress+'%';
    $('#v4NextLevel').textContent=next?`باقي ${Math.max(0,next.min-xp)} نقطة للمستوى التالي: ${next.name}`:'وصلت لأعلى مستوى حاليًا! أحسنت.';
  }
  function renderStreak(){
    const {count,days}=calcStreak(); $('#v4Streak').textContent=count;
    const todayActive=days.has(today()); $('#v4StreakHint').textContent=todayActive?'سجلت نشاطك اليوم، حافظ على السلسلة!':count?'أنجز شيئًا بسيطًا اليوم لتحافظ على استمرارك.':'ابدأ اليوم بأول إنجاز لتكوين سلسلتك.';
    const cells=[]; for(let i=6;i>=0;i--){const d=shift(today(),-i);cells.push(`<div class="${days.has(d)?'active':''}"><i>${days.has(d)?'✓':'·'}</i><small>${new Date(d+'T12:00:00').toLocaleDateString('ar-EG',{weekday:'short'})}</small></div>`)}
    $('#v4StreakDays').innerHTML=cells.join('');
  }
  function renderMessage(){const d=new Date(), idx=Math.floor(new Date(today()+'T12:00:00').getTime()/86400000)%messages.length;$('#v4DailyMessage').textContent=messages[(idx+messages.length)%messages.length];$('#v4MessageDate').textContent=d.toLocaleDateString('ar-EG',{weekday:'long',day:'numeric',month:'long'});}
  function renderAnalysis(){
    const ts=getTasks(), hs=getHabits(), ss=getSessions(), rows=[];
    for(let i=6;i>=0;i--){const k=shift(today(),-i);const done=ts.filter(t=>t.done&&t.completedDate===k).length;const focus=ss.filter(s=>String(s.date||'').slice(0,10)===k).reduce((n,s)=>n+(Number(s.minutes)||0),0);const habits=hs.reduce((n,h)=>n+(h.logs||[]).filter(x=>(typeof x==='string'?x:x.date)===k).length,0);rows.push({k,done,focus,habits});}
    $('#v4WeekTasks').textContent=rows.reduce((n,x)=>n+x.done,0);$('#v4WeekFocus').textContent=rows.reduce((n,x)=>n+x.focus,0);$('#v4WeekHabits').textContent=rows.reduce((n,x)=>n+x.habits,0);
    const max=Math.max(1,...rows.map(x=>x.done+x.focus/25+x.habits));$('#v4PerformanceChart').innerHTML=rows.map(x=>{const score=x.done+x.focus/25+x.habits;return `<div class="v4-chart-col"><b>${x.done}</b><i style="height:${Math.max(4,score/max*100)}%" title="${x.done} مهام، ${x.focus} دقيقة، ${x.habits} عادات"></i><small>${new Date(x.k+'T12:00:00').toLocaleDateString('ar-EG',{weekday:'short'})}</small></div>`}).join('');
    const best=rows.reduce((a,b)=>b.done+b.focus/25+b.habits>a.done+a.focus/25+a.habits?b:a,rows[0]);$('#v4BestDay').textContent=`أكثر أيامك نشاطًا: ${dateLabel(best.k)} — ${best.done} مهام و${best.focus} دقيقة تركيز.`;
  }
  function challengeProgress(c){
    const since=c.start||today(), ts=getTasks(), hs=getHabits(), ss=getSessions();
    if(c.type==='tasks')return ts.filter(t=>t.done&&t.completedDate>=since).length;
    if(c.type==='focus')return ss.filter(s=>String(s.date||'').slice(0,10)>=since).reduce((n,s)=>n+(Number(s.minutes)||0),0);
    return hs.reduce((n,h)=>n+(h.logs||[]).filter(x=>(typeof x==='string'?x:x.date)>=since).length,0);
  }
  function renderChallenges(){
    const root=$('#v4ChallengeList'); if(!root)return;
    root.innerHTML=challenges.length?challenges.map(c=>{const val=challengeProgress(c),pct=Math.min(100,val/Math.max(1,c.target)*100),done=val>=c.target;return `<div class="v4-challenge-row"><div class="v4-challenge-top"><b>${esc(c.title)}</b><small>${val} / ${c.target} ${c.type==='tasks'?'مهمة':c.type==='focus'?'دقيقة':'عادة'}</small></div><div class="progress-track"><i style="width:${pct}%"></i></div><div class="v4-challenge-bottom"><small>${done?'🎉 اكتمل التحدي!':'مستمر — خطوة كمان تقربك'}</small><button type="button" data-v4-challenge-delete="${esc(c.id)}" aria-label="حذف التحدي">حذف</button></div></div>`}).join(''):'<p class="muted-line">لسه مفيش تحديات. اختار هدفًا بسيطًا وابدأ 🌟</p>';
  }
  function renderIdeas(){const root=$('#v4IdeaList');if(!root)return;root.innerHTML=ideas.length?ideas.slice().sort((a,b)=>b.created-a.created).map(i=>`<div class="v4-idea-row"><span>${esc(i.text)}</span><small>${new Date(i.created).toLocaleDateString('ar-EG')}</small><button type="button" data-v4-idea-delete="${esc(i.id)}" aria-label="حذف الفكرة">×</button></div>`).join(''):'<p class="muted-line">صندوقك لسه فاضي. أول فكرة ممكن تكون بداية حاجة جميلة.</p>';}
  function render(){injectUI();if(!$('#v4Growth'))return;try{if(typeof renderRewards==='function')renderRewards()}catch{}renderLevels();renderStreak();renderMessage();renderAnalysis();renderChallenges();renderIdeas();}

  injectUI();
  $('#v4ChallengeForm')?.addEventListener('submit',e=>{e.preventDefault();const title=$('#v4ChallengeTitle').value.trim(),target=Number($('#v4ChallengeTarget').value);if(!title||!Number.isInteger(target)||target<1){window.toast?.('اكتب اسم التحدي وحدد هدفًا صحيحًا');return}challenges.push({id:String(Date.now()),title,type:$('#v4ChallengeType').value,target,start:today()});write('personalChallenges',challenges);e.target.reset();$('#v4ChallengeTarget').value=5;renderChallenges();window.toast?.('تمت إضافة تحديك بنجاح 🎯');});
  $('#v4IdeaForm')?.addEventListener('submit',e=>{e.preventDefault();const text=$('#v4IdeaInput').value.trim();if(!text)return;ideas.push({id:String(Date.now()),text,created:Date.now()});write('ideaBox',ideas);$('#v4IdeaInput').value='';renderIdeas();window.toast?.('اتحفظت الفكرة في صندوقك 💡');});
  document.addEventListener('click',e=>{
    const delIdea=e.target.closest('[data-v4-idea-delete]');if(delIdea){ideas=ideas.filter(x=>x.id!==delIdea.dataset.v4IdeaDelete);write('ideaBox',ideas);renderIdeas();}
    const delChallenge=e.target.closest('[data-v4-challenge-delete]');if(delChallenge){challenges=challenges.filter(x=>x.id!==delChallenge.dataset.v4ChallengeDelete);write('personalChallenges',challenges);renderChallenges();}
  });
  function searchAll(q){
    const term=q.trim().toLocaleLowerCase('ar');if(!term)return [];
    const out=[];const add=(type,title,sub,page,hay)=>{if(String(hay||'').toLocaleLowerCase('ar').includes(term))out.push({type,title,sub,page})};
    getTasks().forEach(x=>add('مهمة',x.name,x.done?'مكتملة':'متبقية','tasks',`${x.name} ${x.cat} ${x.date||''} ${x.completedDate||''}`));
    read('notes',[]).forEach(x=>add('ملاحظة',x.title,x.body,'notes',`${x.title} ${x.body}`));
    getHabits().forEach(x=>add('عادة',x.name||x.title,'عادة يومية','habits',`${x.name||x.title} ${x.frequency||''}`));
    read('ideaBox', []).forEach(x=>add('فكرة',x.title||x.text,x.category||'صندوق الأفكار','ideas',`${x.title||x.text} ${x.description||''} ${x.text||''}`));
    read('personalChallenges', []).forEach(x=>add('تحدي',x.title,'تحدياتك الشخصية','challenges',x.title));
    read('plans',[]).forEach(x=>add('جدول',x.text,x.time,'plus',x.text));
    read('reminders',[]).forEach(x=>add('تذكير',x.text,x.time,'plus',x.text));
    return out.slice(0,30);
  }
  const search=$('#globalSearch'), results=$('#v4SearchResults');
  if(search&&results){
    search.addEventListener('input',()=>{searchResults=searchAll(search.value);if(!search.value.trim()){results.hidden=true;results.innerHTML='';return}results.hidden=false;results.innerHTML=searchResults.length?searchResults.map((r,i)=>`<button type="button" class="v4-search-item" data-v4-search-index="${i}"><span>${esc(r.title)}</span><small>${esc(r.type)} · ${esc(r.sub)}</small></button>`).join(''):'<p class="muted-line">لا توجد نتائج مطابقة.</p>';});
    results.addEventListener('click',e=>{const b=e.target.closest('[data-v4-search-index]');if(!b)return;const item=searchResults[Number(b.dataset.v4SearchIndex)];if(item){if(typeof window.navigate==='function')window.navigate(item.page);else document.querySelector(`[data-page="${item.page}"]`)?.click();results.hidden=true;search.blur();}});
    document.addEventListener('click',e=>{if(!e.target.closest('.global-search'))results.hidden=true;});
  }
  // Refresh after existing app actions and timer/habit updates without polling.
  let scheduled=false;const queue=()=>{if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;render()})};
  document.addEventListener('click',e=>{if(e.target.closest('.task-check,.habit-check,.delete-btn,.habit-delete,.mode,#timerStart,#timerReset'))setTimeout(queue,30);});
  document.addEventListener('submit',e=>{if(e.target.matches('#taskForm,#habitForm,#saveNote'))setTimeout(queue,40);});
  const watched=['#taskList','#habitList','#focusChart','#totalFocus','#totalDone','#notesList'];
  const observer=new MutationObserver(queue);watched.forEach(sel=>{const el=$(sel);if(el)observer.observe(el,{childList:true,subtree:true,characterData:true});});
  window.renderInjazV4=render;
  injectUI();render();
})();
