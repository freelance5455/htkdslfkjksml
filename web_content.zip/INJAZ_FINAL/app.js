/* INJAZ V3.1 — offline-first, single source of truth */
'use strict';
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const DB = 'injaz_';
const defaults = {focus:25, short:5, long:15};
const store = {
  get(key, fallback) { try { const v=localStorage.getItem(DB+key); return v===null?fallback:JSON.parse(v); } catch(e) { console.warn('Storage read:',key,e); return fallback; } },
  set(key, value) { try { localStorage.setItem(DB+key, JSON.stringify(value)); return true; } catch(e) { toast('تعذر حفظ البيانات على الجهاز.'); return false; } }
};
let tasks=store.get('tasks',[]), notes=store.get('notes',[]), habits=store.get('habits',[]),
    focusSessions=store.get('focusSessions',[]), plans=store.get('plans',[]), reminders=store.get('reminders',[]),
    planDone=store.get('planDone',store.get('completedPlan',[])), planDoneAt=store.get('planDoneAt',{}), moodHistory=store.get('moodHistory',{}), settings={...defaults,...store.get('settings',{})};
// Migrate V3.0 single-day values without discarding the user's existing data.
const legacyMood=store.get('mood',''); if(legacyMood&&!moodHistory[todayKey()]){moodHistory[todayKey()]=legacyMood;save('moodHistory',moodHistory);}
let filter='all', calDate=new Date(), selectedDate=keyOf(new Date()), calendarView='month', currentMode='focus', duration=settings.focus*60, remaining=duration,
    running=false, timerHandle=null, audioCtx=null, audioSource=null, audioGain=null, reminderHandle=null,
    focusSessionId=null, focusElapsedSeconds=0, focusSegmentStartedAt=0, focusSessionDate='';
function keyOf(d){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
function todayKey(){return keyOf(new Date());}
function dateLabel(k){return new Date(k+'T12:00:00').toLocaleDateString('ar-EG',{weekday:'long',day:'numeric',month:'long'});}
function escapeHTML(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function toast(message){const el=$('#toast');if(!el)return;el.textContent=message;el.classList.add('show');clearTimeout(toast._t);toast._t=setTimeout(()=>el.classList.remove('show'),2400);}
function save(key,value){store.set(key,value);}
function habitLogDates(h){return [...new Set((Array.isArray(h?.logs)?h.logs:[]).map(x=>typeof x==='string'?x:x?.date).filter(Boolean).map(x=>String(x).slice(0,10)))];}
function persistTasks(){save('tasks',tasks);refreshAll();}
function refreshAll(){renderTasks();renderCalendar();renderHabits();renderStats();renderPlan();renderRewards();renderWeek();renderWeekly();renderReminders();}

// Theme: apply before paint where possible; every component inherits the body variables.
function applyTheme(mode){const dark=mode==='dark';document.body.classList.toggle('dark',dark);document.documentElement.style.colorScheme=dark?'dark':'light';const b=$('#themeBtn');if(b){b.textContent=dark?'☀️':'🌙';b.title=dark?'تفعيل الوضع الفاتح':'تفعيل الوضع الليلي';b.setAttribute('aria-label',b.title);}try{localStorage.setItem('injaz_theme',dark?'dark':'light');}catch{} }
applyTheme(localStorage.getItem('injaz_theme')||'light');
$('#themeBtn')?.addEventListener('click',()=>applyTheme(document.body.classList.contains('dark')?'light':'dark'));

// Header and navigation.
const now=new Date(); if($('#today'))$('#today').textContent=now.toLocaleDateString('ar-EG',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
if($('#dateChip'))$('#dateChip').textContent=now.toLocaleDateString('ar-EG',{day:'numeric',month:'short'});
if($('#greeting'))$('#greeting').textContent=(now.getHours()<12?'صباح الخير!':now.getHours()<18?'أهلاً بيك، يومك جميل!':'مساء الخير!')+' ✨';
function navigate(page){$$('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+page));$$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.page===page));if(page==='calendar')renderCalendar();if(page==='stats')renderStats();if(page==='habits')renderHabits();window.scrollTo({top:0,behavior:'smooth'});}
$$('[data-page]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.page)));
$$('[data-go]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.go)));
const personalSpace=$('.sidebar .profile');if(personalSpace){personalSpace.style.cursor='pointer';personalSpace.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();personalSpace.click();}});}

// Tasks — one delegated event path, unique completion rewards, recurring occurrence generation.
function taskHTML(t){const subs=Array.isArray(t.subtasks)?t.subtasks:[];return `<div class="task-row ${t.done?'done':''} ${t.archived?'task-archived':''}" data-id="${t.id}"><button class="task-check" aria-label="${t.done?'إلغاء الإكمال':'إكمال المهمة'}">${t.done?'✓':''}</button><span class="task-name">${escapeHTML(t.name)}${t.date?`<small class="task-date">${dateLabel(t.date)}</small>`:''}${subs.length?`<small class="task-sub-count">${subs.filter(x=>x.done).length}/${subs.length} مهام فرعية</small>`:''}</span><span class="task-cat">${escapeHTML(t.cat||'عام')} · ${t.priority==='high'?'عالية':t.priority==='low'?'منخفضة':'متوسطة'}</span><button class="task-sub-add" aria-label="إضافة مهمة فرعية" title="مهمة فرعية">＋</button><button class="task-archive" aria-label="أرشفة المهمة" title="${t.archived?'إلغاء الأرشفة':'أرشفة'}">${t.archived?'↶':'▣'}</button><button class="task-edit" aria-label="تعديل المهمة" title="تعديل">✎</button><button class="delete-btn" aria-label="حذف المهمة">×</button>${subs.length?`<details class="task-subtasks"><summary>عرض المهام الفرعية (${subs.length})</summary>${subs.map((x,i)=>`<label><input type="checkbox" data-subtask-toggle="${i}" ${x.done?'checked':''}> ${escapeHTML(x.name)}</label>`).join('')}</details>`:''}</div>`;}
function renderTasks(){const visible=tasks.filter(t=>filter==='archived'?!!t.archived:!t.archived&&(filter==='all'||(filter==='active'&&!t.done)||(filter==='done'&&t.done))).sort((a,b)=>({high:0,medium:1,low:2}[a.priority||'medium']-({high:0,medium:1,low:2}[b.priority||'medium'])));const list=$('#taskList'),home=$('#homeTasks');if(list)list.innerHTML=visible.length?visible.map(taskHTML).join(''):'<div class="empty-state">مفيش مهام هنا حاليًا 🌱</div>';if(home){const pending=tasks.filter(t=>!t.done&&!t.archived).slice(0,4);home.innerHTML=pending.length?pending.map(taskHTML).join(''):'لسه مفيش مهام. أضف أول مهمة ليك ✨';}if($('#doneCount'))$('#doneCount').textContent=tasks.filter(t=>t.done).length;if($('#activeCount'))$('#activeCount').textContent=tasks.filter(t=>!t.done).length;if($('#taskSummary'))$('#taskSummary').textContent=`${tasks.length} مهمة`;}
function addTask(){const name=$('#taskInput')?.value.trim();if(!name)return;const repeat=$('#taskRepeat')?.value||'none';tasks.unshift({id:Date.now()+Math.floor(Math.random()*10000),name,cat:$('#taskCategory')?.value||'عام',date:$('#taskDate')?.value||(repeat!=='none'?todayKey():''),done:false,repeat,priority:$('#taskPriority')?.value||'medium',subtasks:[],archived:false,createdAt:todayKey()});$('#taskInput').value='';$('#taskDate').value='';persistTasks();toast('اتضافت المهمة بنجاح ✨');}
$('#taskForm')?.addEventListener('submit',e=>{e.preventDefault();addTask();});
$$('[data-filter]').forEach(b=>b.addEventListener('click',()=>{filter=b.dataset.filter;$$('[data-filter]').forEach(x=>x.classList.toggle('active',x===b));renderTasks();}));
document.addEventListener('click',e=>{const row=e.target.closest('.task-row');if(!row)return;const id=Number(row.dataset.id),t=tasks.find(x=>Number(x.id)===id);if(!t)return;
 if(e.target.closest('.task-check')){if(!t.done){t.done=true;t.completedDate=todayKey();toast('مهمة مكتملة! +10 نقاط 🌟');if(t.repeat&&t.repeat!=='none'&&t.date){const d=new Date(t.date+'T12:00:00');d.setDate(d.getDate()+(t.repeat==='daily'?1:7));const next=keyOf(d);if(!tasks.some(x=>x.name===t.name&&x.date===next&&x.repeat===t.repeat&&!x.archived))tasks.unshift({id:Date.now()+Math.floor(Math.random()*1000),name:t.name,cat:t.cat,date:next,done:false,repeat:t.repeat,priority:t.priority||'medium',subtasks:[],archived:false,createdAt:todayKey()});}}else{t.done=false;delete t.completedDate;}persistTasks();}
 else if(e.target.closest('.task-sub-add')){const name=prompt('اسم المهمة الفرعية:');if(name===null||!name.trim())return;t.subtasks=Array.isArray(t.subtasks)?t.subtasks:[];t.subtasks.push({id:Date.now()+Math.floor(Math.random()*1000),name:name.trim(),done:false});persistTasks();}
 else if(e.target.closest('[data-subtask-toggle]')){const i=Number(e.target.closest('[data-subtask-toggle]').dataset.subtaskToggle);if(t.subtasks?.[i])t.subtasks[i].done=!!e.target.checked;persistTasks();}
 else if(e.target.closest('.task-archive')){t.archived=!t.archived;persistTasks();toast(t.archived?'تمت أرشفة المهمة':'تمت استعادة المهمة من الأرشيف');}
 else if(e.target.closest('.delete-btn')){if(!confirm('حذف المهمة نهائيًا؟'))return;tasks=tasks.filter(x=>Number(x.id)!==id);persistTasks();toast('تم حذف المهمة');}
 else if(e.target.closest('.task-edit')){const name=prompt('تعديل اسم المهمة:',t.name);if(name===null)return;if(!name.trim()){toast('اسم المهمة لا يمكن أن يكون فارغًا');return;}const date=prompt('موعد المهمة YYYY-MM-DD (اتركه فارغًا لإزالة الموعد):',t.date||'');if(date===null)return;if(date&&!/^\d{4}-\d{2}-\d{2}$/.test(date)){toast('صيغة التاريخ غير صحيحة');return;}const priority=prompt('الأولوية: high / medium / low',t.priority||'medium');if(priority===null)return;if(!['high','medium','low'].includes(priority)){toast('الأولوية غير صحيحة');return;}t.name=name.trim();t.date=date;t.priority=priority;persistTasks();toast('تم تعديل المهمة');}
});

// Notes.
function renderNotes(){const root=$('#notesList');if(!root)return;root.innerHTML=notes.length?notes.map(n=>`<article class="note-card"><button data-del-note="${n.id}" aria-label="حذف">×</button><h4>${escapeHTML(n.title||'ملاحظة بدون عنوان')}${n.pinned?' <span class="pin">★</span>':''}</h4><p>${escapeHTML(n.body)}</p><div class="note-actions"><small>عام</small><button data-pin-note="${n.id}">${n.pinned?'إلغاء التثبيت':'تثبيت'}</button><button data-edit-note="${n.id}">تعديل</button></div></article>`).join(''):'لسه مفيش ملاحظات محفوظة.';}
$('#saveNote')?.addEventListener('click',()=>{const title=$('#noteTitle').value.trim(),body=$('#noteBody').value.trim();if(!title&&!body){toast('اكتب ملاحظة الأول');return;}const edit=$('#saveNote').dataset.edit;if(edit){const n=notes.find(x=>String(x.id)===edit);if(n){n.title=title;n.body=body;}delete $('#saveNote').dataset.edit;$('#saveNote').textContent='حفظ الملاحظة';}else notes.unshift({id:Date.now(),title,body,pinned:false});save('notes',notes);$('#noteTitle').value='';$('#noteBody').value='';renderNotes();toast('اتحفظت ملاحظتك 💜');});
$('#notesList')?.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const id=b.dataset.delNote||b.dataset.pinNote||b.dataset.editNote;if(!id)return;const n=notes.find(x=>String(x.id)===id);if(b.dataset.delNote){notes=notes.filter(x=>String(x.id)!==id);save('notes',notes);renderNotes();}else if(b.dataset.pinNote){n.pinned=!n.pinned;save('notes',notes);renderNotes();}else{ $('#noteTitle').value=n.title||'';$('#noteBody').value=n.body||'';$('#saveNote').dataset.edit=id;$('#saveNote').textContent='حفظ التعديل';window.scrollTo({top:0,behavior:'smooth'});}});

// Calendar — daily, weekly and monthly views share the same selected date.
function renderCalendar(){const grid=$('#calendarGrid');if(!grid)return;const labels=['الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت','الأحد'];let html='';if(calendarView==='month'){const y=calDate.getFullYear(),m=calDate.getMonth(),first=new Date(y,m,1),offset=(first.getDay()+6)%7,days=new Date(y,m+1,0).getDate();$('#calendarMonth').textContent=first.toLocaleDateString('ar-EG',{month:'long',year:'numeric'});html=labels.map(x=>`<div class="weekday">${x}</div>`).join('');for(let i=0;i<offset;i++)html+='<div class="calendar-day blank"></div>';for(let day=1;day<=days;day++){const k=`${y}-${String(m+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`,has=tasks.some(t=>t.date===k&&!t.archived),isToday=k===todayKey();html+=`<button class="calendar-day ${k===selectedDate?'selected':''} ${isToday?'today':''} ${has?'has-task':''}" data-date="${k}">${day}${has?'<i></i>':''}</button>`;}}else{const selected=new Date(selectedDate+'T12:00:00'),start=new Date(selected);if(calendarView==='week')start.setDate(start.getDate()-((start.getDay()+6)%7));const count=calendarView==='day'?1:7;$('#calendarMonth').textContent=calendarView==='day'?dateLabel(selectedDate):`${dateLabel(keyOf(start))} — ${dateLabel(shiftDate(keyOf(start),6))}`;if(calendarView==='week')html=labels.map(x=>`<div class="weekday">${x}</div>`).join('');for(let i=0;i<count;i++){const d=new Date(start);d.setDate(start.getDate()+i);const k=keyOf(d),has=tasks.some(t=>t.date===k&&!t.archived);html+=`<button class="calendar-day ${k===selectedDate?'selected':''} ${k===todayKey()?'today':''} ${has?'has-task':''}" data-date="${k}">${calendarView==='day'?d.toLocaleDateString('ar-EG',{weekday:'long',day:'numeric',month:'short'}):d.getDate()}${has?'<i></i>':''}</button>`;}}grid.innerHTML=html;$$('#calendarGrid [data-date]').forEach(b=>b.addEventListener('click',()=>{selectedDate=b.dataset.date;calDate=new Date(selectedDate+'T12:00:00');renderCalendar();}));$$('[data-cal-view]').forEach(b=>b.classList.toggle('active',b.dataset.calView===calendarView));$('#selectedDateTitle').textContent='مهام '+dateLabel(selectedDate);const dayTasks=tasks.filter(t=>t.date===selectedDate&&!t.archived);$('#calendarTasks').innerHTML=dayTasks.length?dayTasks.map(taskHTML).join(''):'<div class="empty-state">لا توجد مهام في هذا اليوم.</div>';}
function shiftDate(k,n){const d=new Date(k+'T12:00:00');d.setDate(d.getDate()+n);return keyOf(d);}
$$('[data-cal-view]').forEach(b=>b.addEventListener('click',()=>{calendarView=b.dataset.calView;renderCalendar();}));
$('#prevMonth')?.addEventListener('click',()=>{if(calendarView==='month'){calDate=new Date(calDate.getFullYear(),calDate.getMonth()-1,1);selectedDate=keyOf(new Date(calDate.getFullYear(),calDate.getMonth(),Math.min(Number(selectedDate.slice(-2)),new Date(calDate.getFullYear(),calDate.getMonth()+1,0).getDate())));}else{selectedDate=shiftDate(selectedDate,calendarView==='day'?-1:-7);calDate=new Date(selectedDate+'T12:00:00');}renderCalendar();});$('#nextMonth')?.addEventListener('click',()=>{if(calendarView==='month'){calDate=new Date(calDate.getFullYear(),calDate.getMonth()+1,1);selectedDate=keyOf(new Date(calDate.getFullYear(),calDate.getMonth(),Math.min(Number(selectedDate.slice(-2)),new Date(calDate.getFullYear(),calDate.getMonth()+1,0).getDate())));}else{selectedDate=shiftDate(selectedDate,calendarView==='day'?1:7);calDate=new Date(selectedDate+'T12:00:00');}renderCalendar();});

// Habits — preserves the legacy logs array while adding safe scheduling and pause metadata.
function renderHabits(){const root=$('#habitList');if(!root)return;const k=todayKey();$('#habitDate').textContent='اليوم: '+dateLabel(k);let completed=0;root.innerHTML=habits.length?habits.map(h=>{h.logs=Array.isArray(h.logs)?h.logs:[];const done=h.logs.some(x=>(typeof x==='string'?x:x?.date)===k),paused=!!h.paused,weekly=Number(h.weeklyTarget)||7;if(done&&!paused)completed++;const monthPrefix=k.slice(0,7),monthCount=h.logs.filter(x=>String(typeof x==='string'?x:x?.date||'').startsWith(monthPrefix)).length,weekStart=(()=>{const d=new Date(k+'T12:00:00');d.setDate(d.getDate()-((d.getDay()+6)%7));return keyOf(d)})(),weekCount=h.logs.filter(x=>{const d=String(typeof x==='string'?x:x?.date||'');return d>=weekStart&&d<=k}).length;return `<div class="habit-row ${paused?'habit-paused':''}" data-habit="${h.id}"><button class="habit-check ${done?'checked':''}" aria-label="تبديل إكمال العادة" ${paused?'disabled':''}>${done?'✓':''}</button><span class="habit-main">${escapeHTML(h.name||h.title||'عادة')}<small>${paused?'متوقفة مؤقتًا':(h.frequency==='weekly'?'أسبوعية':'يومية')} · ${weekCount}/${Number(h.weeklyTarget)||5} هذا الأسبوع · ${monthCount}/${Number(h.monthlyTarget)||20} هذا الشهر</small></span><small>${paused?'متوقفة':done?'اكتملت اليوم':'مستمرة'}</small><button class="habit-edit" aria-label="تعديل العادة" title="تعديل">✎</button><button class="habit-pause" aria-label="إيقاف أو استئناف العادة" title="${paused?'استئناف':'إيقاف مؤقت'}">${paused?'▶':'Ⅱ'}</button><button class="delete-btn habit-delete" aria-label="حذف العادة">×</button></div>`;}).join(''):'<div class="empty-state">ابدأ بإضافة أول عادة 🌱</div>';if($('#todayHabits'))$('#todayHabits').textContent=completed;}
$('#habitForm')?.addEventListener('submit',e=>{e.preventDefault();const name=$('#habitInput').value.trim();if(!name)return;habits.push({id:Date.now()+Math.floor(Math.random()*10000),name,logs:[],frequency:$('#habitFrequency')?.value||'daily',weeklyTarget:Number($('#habitWeeklyTarget')?.value)||5,monthlyTarget:Number($('#habitMonthlyTarget')?.value)||20,paused:false,createdAt:todayKey()});save('habits',habits);$('#habitInput').value='';renderHabits();renderStats();renderRewards();toast('اتضافت العادة 🌱');});
$('#habitList')?.addEventListener('click',e=>{const row=e.target.closest('.habit-row');if(!row)return;const id=Number(row.dataset.habit),h=habits.find(x=>Number(x.id)===id);if(!h)return;if(e.target.closest('.habit-delete')){if(!confirm('حذف العادة وسجلها؟'))return;habits=habits.filter(x=>Number(x.id)!==id);}else if(e.target.closest('.habit-pause')){h.paused=!h.paused;}else if(e.target.closest('.habit-edit')){const name=prompt('تعديل اسم العادة:',h.name);if(name===null)return;if(!name.trim())return toast('اسم العادة مطلوب');h.name=name.trim();const target=prompt('الهدف الشهري (عدد مرات الإكمال):',String(h.monthlyTarget||20));if(target!==null&&Number.isInteger(Number(target))&&Number(target)>0)h.monthlyTarget=Number(target);}else if(e.target.closest('.habit-check')){if(h.paused)return toast('هذه العادة متوقفة مؤقتًا.');h.logs=h.logs||[];const k=todayKey(),idx=h.logs.findIndex(x=>(typeof x==='string'?x:x?.date)===k);if(idx>=0)h.logs.splice(idx,1);else h.logs.push(k);}else return;save('habits',habits);renderHabits();renderStats();renderRewards();});

// Focus timer: elapsed wall-clock time is persisted minute-by-minute, including paused/partial sessions.
function fmt(sec){return `${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`;}
function drawTimer(){if($('#bigTimer'))$('#bigTimer').textContent=fmt(remaining);if($('.timer-ring span'))$('.timer-ring span').textContent=fmt(remaining);if($('#timerStart'))$('#timerStart').textContent=running?'إيقاف مؤقت':'ابدأ';}
let timerEnd=0;
function currentFocusElapsed(){return focusElapsedSeconds+(running&&currentMode==='focus'?Math.max(0,Math.floor((Date.now()-focusSegmentStartedAt)/1000)):0);}
function persistFocusProgress(){
 if(currentMode!=='focus')return 0;
 const elapsed=currentFocusElapsed(),minutes=Math.floor(elapsed/60);
 if(minutes<=0)return 0;
 if(!focusSessionId)focusSessionId=`focus_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
 if(!focusSessionDate)focusSessionDate=todayKey();
 let session=focusSessions.find(x=>String(x.id)===String(focusSessionId));
 if(!session){session={id:focusSessionId,date:focusSessionDate,minutes:0,elapsedSeconds:0,partial:true};focusSessions.push(session);}
 if(minutes>Number(session.minutes||0)){
   session.minutes=Math.max(Number(session.minutes)||0,minutes);session.elapsedSeconds=Math.max(Number(session.elapsedSeconds)||0,elapsed);session.updatedAt=Date.now();
   save('focusSessions',focusSessions);renderStats();renderRewards();renderWeekly();
   if(typeof window.renderInjazV4==='function')window.renderInjazV4();
   if(typeof window.refreshInjazEnhancements==='function')window.refreshInjazEnhancements();
 }
 return minutes;
}
function stopTimer(){
 if(running&&currentMode==='focus')focusElapsedSeconds+=Math.max(0,Math.floor((Date.now()-focusSegmentStartedAt)/1000));
 running=false;clearInterval(timerHandle);timerHandle=null;
 if(currentMode==='focus')persistFocusProgress();
 drawTimer();
}
function tickTimer(){if(!running)return;remaining=Math.max(0,Math.ceil((timerEnd-Date.now())/1000));drawTimer();if(currentMode==='focus')persistFocusProgress();if(remaining<=0)completeTimer();}
function completeTimer(){
 stopTimer();
 if(currentMode==='focus'){
   // Completion updates the same session record; it never creates a duplicate XP event.
   const expected=Math.max(1,Math.floor((duration+59)/60));
   if(!focusSessionId){focusSessionId=`focus_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;focusSessionDate=todayKey();}
   let session=focusSessions.find(x=>String(x.id)===String(focusSessionId));
   if(!session){session={id:focusSessionId,date:focusSessionDate||todayKey(),minutes:0};focusSessions.push(session);}
   session.minutes=Math.max(Number(session.minutes)||0,expected);session.elapsedSeconds=Math.max(Number(session.elapsedSeconds)||0,duration);session.completed=true;session.partial=false;session.updatedAt=Date.now();save('focusSessions',focusSessions);
   focusSessionId=null;focusElapsedSeconds=0;focusSegmentStartedAt=0;focusSessionDate='';
   toast('أحسنت! خلصت جلسة تركيز 🎉');sendNotice('إنجاز','انتهت جلسة التركيز. أحسنت!');
 }else{toast('خلصت الاستراحة، وقت ما تكون جاهز');sendNotice('إنجاز','انتهت الاستراحة.');}
 $('#timerStatus').textContent='اكتملت الجلسة بنجاح!';renderStats();renderRewards();renderWeekly();window.refreshInjazEnhancements?.();
}
$('#timerStart')?.addEventListener('click',()=>{
 if(running){tickTimer();if(running){stopTimer();$('#timerStatus').textContent='تم إيقاف المؤقت مؤقتًا';}return;}
 if(remaining<=0){remaining=duration;drawTimer();}
 if(currentMode==='focus'&&!focusSessionId){focusSessionId=`focus_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;focusSessionDate=todayKey();focusElapsedSeconds=0;}
 running=true;focusSegmentStartedAt=Date.now();timerEnd=Date.now()+remaining*1000;$('#timerStatus').textContent=currentMode==='focus'?'أنت في وضع التركيز...':'وقت استراحة لطيف';tickTimer();if(running)timerHandle=setInterval(tickTimer,250);
});
function resetTimer(){stopTimer();if(currentMode==='focus'){focusSessionId=null;focusElapsedSeconds=0;focusSegmentStartedAt=0;focusSessionDate='';}remaining=duration;drawTimer();}
$('#timerReset')?.addEventListener('click',resetTimer);
$$('.mode').forEach(b=>b.addEventListener('click',()=>{resetTimer();currentMode=b.dataset.mode;$$('.mode').forEach(x=>x.classList.toggle('active',x===b));duration=(settings[currentMode]||25)*60;remaining=duration;drawTimer();$('#timerStatus').textContent=currentMode==='focus'?'جلسة تركيز جديدة':'وقت استراحة لطيف';}));
function updateTimerLabels(){for(const [k,id] of [['focus','focusLabel'],['short','shortLabel'],['long','longLabel']])if($('#'+id))$('#'+id).textContent=settings[k];}
function loadSettings(){if(running)stopTimer();if(focusSessionId){persistFocusProgress();focusSessionId=null;focusElapsedSeconds=0;focusSegmentStartedAt=0;focusSessionDate='';}for(const [k,id] of [['focus','settingFocus'],['short','settingShort'],['long','settingLong']])if($('#'+id))$('#'+id).value=settings[k];updateTimerLabels();duration=settings[currentMode]*60;remaining=duration;drawTimer();}
$('#saveSettings')?.addEventListener('click',()=>{const next={focus:+$('#settingFocus').value,short:+$('#settingShort').value,long:+$('#settingLong').value};if(!next.focus||!next.short||!next.long||next.focus>180||next.short>60||next.long>90){toast('راجع مدد الوقت المدخلة');return;}settings=next;save('settings',settings);loadSettings();toast('تم حفظ إعدادات المؤقت');});

// Real reward totals derived from unique saved records; no duplicate click counters.
function rewardPoints(){const sessions=new Set(focusSessions.map((s,i)=>s.id??`legacy-${i}`));return tasks.filter(t=>t.done).length*10+habits.reduce((n,h)=>n+habitLogDates(h).length*3,0)+sessions.size*5+new Set(planDone.map(String)).size*2+store.get('challengeRewards',[]).reduce((n,c)=>n+Math.max(0,Number(c.xp)||0),0)+store.get('personalChallenges',[]).filter(c=>c.rewardClaimed&&!store.get('challengeRewards',[]).some(r=>String(r.challengeId)===String(c.id))).reduce((n,c)=>n+Math.max(0,Number(c.rewardXP)||20),0);}
function renderRewards(){const points=rewardPoints();if($('#pointsTotal'))$('#pointsTotal').textContent=points+' نقطة';const badges=[['🌱 بداية جميلة',points>=10],['⭐ ملتزم',points>=50],['🏆 بطل الإنجاز',points>=150],['🔥 صاحب الهمة',points>=300]];if($('#badges'))$('#badges').innerHTML=badges.map(([name,ok])=>`<span class="${ok?'earned-badge':'locked-badge'}">${ok?'✓ ':'🔒 '}${name}</span>`).join('');const stage=points>=300?'🌳':points>=150?'🌿':points>=50?'🪴':'🌱';if($('#plantStage'))$('#plantStage').textContent=stage;if($('#plantMessage'))$('#plantMessage').textContent=points>=300?'نبتتك أصبحت شجرة إنجاز!':points>=150?'نبتتك كبرت بفضل استمرارك!':points>=50?'نبتتك بدأت تكبر، كمّل!':'كل إنجاز صغير بيسقي نبتتك.';if($('#plantProgress'))$('#plantProgress').style.width=(points>=300?100:(points%50)/50*100)+'%';}

// Daily plan.
function renderPlan(){const root=$('#smartPlan');if(!root)return;const list=plans.slice().sort((a,b)=>a.time.localeCompare(b.time));root.innerHTML=list.length?list.map(p=>`<div class="feature-row" data-plan-row="${p.id}"><input type="checkbox" data-plan-check="${p.id}" ${planDone.includes(p.id)?'checked':''}><span>${escapeHTML(p.text)}</span><small>${p.time}</small><button data-plan-edit="${p.id}" title="تعديل">✎</button><button data-plan-del="${p.id}" title="حذف">×</button></div>`).join(''):'<p class="muted-line">أضف أول خطوة لجدولك اليوم.</p>';}
$('#addPlan')?.addEventListener('click',()=>{const time=$('#planTime').value,text=$('#planText').value.trim();if(!time||!text){toast('اكتب الوقت ووصف الخطوة');return;}plans.push({id:Date.now(),time,text});save('plans',plans);$('#planText').value='';renderPlan();toast('تمت إضافة النشاط');});
$('#smartPlan')?.addEventListener('change',e=>{const id=Number(e.target.dataset.planCheck);if(!id)return;if(e.target.checked){if(!planDone.includes(id))planDone.push(id);planDoneAt[String(id)]=todayKey();}else{planDone=planDone.filter(x=>x!==id);delete planDoneAt[String(id)];}save('planDone',planDone);save('planDoneAt',planDoneAt);renderRewards();});
$('#smartPlan')?.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const id=Number(b.dataset.planDel||b.dataset.planEdit),p=plans.find(x=>Number(x.id)===id);if(!p)return;if(b.dataset.planDel){plans=plans.filter(x=>Number(x.id)!==id);planDone=planDone.filter(x=>x!==id);delete planDoneAt[String(id)];save('plans',plans);save('planDone',planDone);save('planDoneAt',planDoneAt);renderPlan();renderRewards();}else{const text=prompt('تعديل النشاط:',p.text);if(text===null)return;if(text.trim())p.text=text.trim();const time=prompt('تعديل الوقت (HH:MM):',p.time);if(time&&/^([01]\d|2[0-3]):[0-5]\d$/.test(time))p.time=time;save('plans',plans);renderPlan();}});

// Week and actual rolling 7-day report.
function renderWeek(){const root=$('#weekOverview');if(!root)return;let out='';for(let i=0;i<7;i++){const d=new Date();d.setDate(d.getDate()+i);const k=keyOf(d),count=tasks.filter(t=>t.date===k&&!t.archived).length;out+=`<div class="week-day"><small>${d.toLocaleDateString('ar-EG',{weekday:'short'})}</small><b>${d.getDate()}</b><i style="opacity:${count?1:0}"></i><small>${count} مهمة</small></div>`;}root.innerHTML=out;}
function inLastSeven(k){const key=String(typeof k==='string'?k:k?.date||'').slice(0,10);const start=new Date();start.setHours(12,0,0,0);start.setDate(start.getDate()-6);return key>=keyOf(start)&&key<=todayKey();}
function renderWeekly(){const root=$('#weeklyReport');if(!root)return;const done=tasks.filter(t=>t.done&&t.completedDate&&inLastSeven(t.completedDate)).length,pending=tasks.filter(t=>!t.done&&!t.archived&&t.date&&inLastSeven(t.date)).length,focus=focusSessions.filter(s=>inLastSeven(s.date)).reduce((n,s)=>n+(Number(s.minutes)||0),0),habitCount=habits.reduce((n,h)=>n+habitLogDates(h).filter(inLastSeven).length,0),points=tasks.filter(t=>t.done&&inLastSeven(t.completedDate)).length*10+habitCount*3+new Set(focusSessions.filter(s=>inLastSeven(s.date)).map((s,i)=>s.id??`legacy-${i}`)).size*5+Object.entries(planDoneAt).filter(([id,k])=>planDone.includes(Number(id))&&inLastSeven(k)).length*2+store.get('challengeRewards',[]).filter(x=>inLastSeven(String(x.at||'').slice(0,10))).reduce((n,x)=>n+(Number(x.xp)||0),0);const daily=[];for(let i=6;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);const k=keyOf(d);daily.push({label:d.toLocaleDateString('ar-EG',{weekday:'short'}),done:tasks.filter(t=>t.done&&t.completedDate===k).length});}const peak=Math.max(1,...daily.map(x=>x.done));root.innerHTML=`<div><strong>${done}</strong><small>مهام مكتملة</small></div><div><strong>${pending}</strong><small>مهام متبقية</small></div><div><strong>${focus}</strong><small>دقيقة تركيز</small></div><div><strong>${habitCount}</strong><small>عادات مكتملة</small></div><div><strong>${points}</strong><small>نقاط مكتسبة</small></div><div class="weekly-chart-wrap"><b>إنجاز المهام يوميًا</b><div class="weekly-chart">${daily.map(x=>`<div><i style="height:${Math.max(4,x.done/peak*100)}%"></i><small>${x.label}</small><em>${x.done}</em></div>`).join('')}</div></div>`;}
function focusMinutesFor(k){return focusSessions.filter(s=>String(s.date||'').slice(0,10)===k).reduce((n,s)=>n+(Number(s.minutes)||0),0);}
function renderStats(){if(!$('#totalDone'))return;const done=tasks.filter(t=>t.done).length,total=focusSessions.reduce((n,s)=>n+(Number(s.minutes)||0),0);$('#totalDone').textContent=done;$('#totalFocus').innerHTML=total+' <em>د</em>';$('#focusTime').innerHTML=focusMinutesFor(todayKey())+' <em>د</em>';$('#todayHabits').textContent=habits.filter(h=>habitLogDates(h).includes(todayKey())).length;let days=[];for(let i=6;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);const k=keyOf(d);days.push({label:d.toLocaleDateString('ar-EG',{weekday:'short'}),value:focusMinutesFor(k)});}const max=Math.max(30,...days.map(x=>x.value));$('#focusChart').innerHTML=days.map(d=>`<div class="chart-col"><strong>${d.value}</strong><div class="bar-track"><i style="height:${Math.max(3,d.value/max*100)}%"></i></div><small>${d.label}</small></div>`).join('');let streak=0;for(let i=0;i<30;i++){const d=new Date();d.setDate(d.getDate()-i);const k=keyOf(d);if(tasks.some(t=>t.done&&t.completedDate===k)||focusMinutesFor(k)>0||habits.some(h=>habitLogDates(h).includes(k)))streak++;else if(i>0)break;}$('#streakText').textContent=streak?`سجلت نشاطًا لمدة ${streak} ${streak===1?'يوم':'أيام'} متتالية. كمل!`:'كل يوم تبدأ فيه هو مكسب جديد.';}

// Reminders. Browser notifications require permission and a secure installed origin; in-page checks run while open.
function sendNotice(title,body){const log=store.get('notificationLog',[]);log.push({id:Date.now()+Math.floor(Math.random()*1000),title:String(title||'إنجاز'),text:String(body||''),at:Date.now()});store.set('notificationLog',log.slice(-200));if('Notification'in window&&Notification.permission==='granted'){try{new Notification(title,{body,icon:'assets/icon-192.png'});}catch(e){console.warn('Notification unavailable',e);}}}
$('#enableNotifications')?.addEventListener('click',async()=>{if(!('Notification'in window)){toast('المتصفح لا يدعم الإشعارات');return;}try{const p=await Notification.requestPermission();$('#notificationState').textContent='حالة الإشعارات: '+(p==='granted'?'مفعّلة':p==='denied'?'مرفوضة':'لم يتم التفعيل');toast(p==='granted'?'تم تفعيل الإشعارات':'لم يتم منح إذن الإشعارات');}catch{toast('تعذر طلب إذن الإشعارات');}});
function renderReminders(){const root=$('#reminderList');if(!root)return;root.innerHTML=reminders.length?reminders.slice().sort((a,b)=>a.time.localeCompare(b.time)).map(r=>`<div class="feature-row"><span>${escapeHTML(r.text)}</span><small>${r.time}</small><button data-rem-edit="${r.id}" title="تعديل">✎</button><button data-rem-del="${r.id}" title="حذف">×</button></div>`).join(''):'<p class="muted-line">لا توجد تذكيرات محفوظة.</p>';}
$('#addReminder')?.addEventListener('click',()=>{const time=$('#reminderTime').value,text=$('#reminderText').value.trim();if(!time||!text){toast('حدد الوقت واكتب التذكير');return;}reminders.push({id:Date.now(),time,text,last:''});save('reminders',reminders);$('#reminderText').value='';renderReminders();toast('تم حفظ التذكير');});
$('#reminderList')?.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const id=Number(b.dataset.remDel||b.dataset.remEdit),r=reminders.find(x=>Number(x.id)===id);if(!r)return;if(b.dataset.remDel)reminders=reminders.filter(x=>Number(x.id)!==id);else{const text=prompt('تعديل نص التذكير:',r.text);if(text===null)return;const time=prompt('تعديل الوقت (HH:MM):',r.time);if(text.trim())r.text=text.trim();if(time&&/^([01]\d|2[0-3]):[0-5]\d$/.test(time))r.time=time;}save('reminders',reminders);renderReminders();});
function checkReminders(){const k=todayKey(),time=new Date().toTimeString().slice(0,5);let changed=false;reminders.forEach(r=>{if(r.time<=time&&r.last!==k){sendNotice('تذكير من إنجاز',r.text);r.last=k;changed=true;if(store.get('notifyInPage',true))toast('تذكير: '+r.text);}});if(changed)save('reminders',reminders);}
if(reminderHandle)clearInterval(reminderHandle);reminderHandle=setInterval(checkReminders,15000);

// Mood saved per date, so the previous days remain available.
function renderMood(){const k=todayKey(),m=moodHistory[k]||'';$('#moodOptions')?.querySelectorAll('button').forEach(b=>b.classList.toggle('active',b.dataset.mood===m));if($('#moodSaved'))$('#moodSaved').textContent=m?'حالتك المسجلة اليوم: '+m:'لم تسجل حالتك اليوم بعد.';}
$('#moodOptions')?.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{moodHistory[todayKey()]=b.dataset.mood;save('moodHistory',moodHistory);renderMood();toast('تم حفظ حالتك اليوم 💜');}));

// Offline ambient audio engine. Each scene has its own spectrum, movement and event pattern.
// All sounds are synthesized locally with Web Audio API; they are not field recordings.
let ambientNodes=[], ambientTimers=[], activeAmbient='', ambientStartToken=0, noiseBufferCache=new WeakMap();
const ambientLibrary=[
 ['rain','مطر هادئ','رذاذ مطر ناعم ومنتظم.','🌧️'],
 ['heavy-rain','مطر غزير','طبقات مطر كثيفة وقطرات متتابعة.','🌧️'],
 ['window-rain','مطر على نافذة','قطرات منفصلة بنقرات خفيفة على الزجاج.','🪟'],
 ['forest','غابة وطيور','هواء بين الأشجار ونداءات طيور اصطناعية.','🌲'],
 ['morning-birds','طيور الصباح','زقزقات متباعدة فوق هواء صباحي خفيف.','🐦'],
 ['ocean','أمواج البحر','موج عريض يرتفع وينحسر ببطء.','🌊'],
 ['night-ocean','بحر هادئ ليلًا','أمواج عميقة وبطيئة وخافتة.','🌙'],
 ['stream','جدول ماء جارٍ','تدفق مائي رفيع مع رذاذ متقطع.','💧'],
 ['waterfall','شلال طبيعي','اندفاع ماء واسع وكثيف.','🏞️'],
 ['wind-trees','رياح بين الأشجار','هبّات هواء عميقة ومتدرجة.','🍃'],
 ['leaves','أوراق مع النسيم','حفيف أوراق خفيف ومتقطع.','🌿'],
 ['fireplace','مدفأة وحطب','دفء منخفض وفرقعات حطب اصطناعية.','🔥'],
 ['night','أجواء الليل','خلفية ليلية عميقة وهادئة.','🌌'],
 ['crickets','صراصير الليل','نبضات حشرية إيقاعية عالية التردد.','🦗'],
 ['cafe','مقهى هادئ','همهمة داخلية مكتومة بلا كلام مفهوم.','☕'],
 ['white','ضوضاء بيضاء','طيف ضوضاء متوازن.','〰️'],
 ['brown','ضوضاء بنية','ضوضاء منخفضة ودافئة.','〰️'],
 ['distant-thunder','مطر ورعد بعيد','مطر مستمر مع دمدمة رعد منخفضة متباعدة.','⛈️']
];
function ensureVolumeControl(){
 const host=$('.sound-controls');if(!host)return;
 if(!host.dataset.audioBound){host.dataset.audioBound='1';host.addEventListener('click',e=>{const b=e.target.closest('[data-sound]');if(!b)return;b.dataset.sound==='stop'?stopAmbient():startAmbient(b.dataset.sound);});}
 if(!$('#soundVolume')){const wrap=document.createElement('label');wrap.className='sound-volume';wrap.innerHTML='<span>مستوى الصوت</span><input id="soundVolume" type="range" min="0" max="100" value="35">';host.after(wrap);$('#soundVolume').addEventListener('input',e=>{if(audioGain&&audioCtx)audioGain.gain.setTargetAtTime((Number(e.target.value)/100)*.65,audioCtx.currentTime,.06);});}
 host.innerHTML=ambientLibrary.map(x=>`<button type="button" data-sound="${x[0]}" title="${x[2]}">${x[3]} ${x[1]}</button>`).join('')+'<button type="button" data-sound="stop">⏹ إيقاف</button>';
 host.classList.add('sound-library-grid');
}
function trackNode(node){ambientNodes.push(node);return node;}
function trackTransient(source,nodes){nodes.forEach(trackNode);source.onended=()=>{nodes.forEach(n=>{try{n.disconnect();}catch{}});ambientNodes=ambientNodes.filter(n=>!nodes.includes(n));};return source;}
function getNoiseBuffer(ctx,color){
 let cache=noiseBufferCache.get(ctx);if(!cache){cache={};noiseBufferCache.set(ctx,cache);}if(cache[color])return cache[color];
 const length=ctx.sampleRate*3,buffer=ctx.createBuffer(1,length,ctx.sampleRate),data=buffer.getChannelData(0);let b0=0,b1=0,b2=0,b3=0,b4=0,b5=0,brown=0;
 for(let i=0;i<length;i++){const w=Math.random()*2-1;let v=w;
  if(color==='pink'){b0=.99886*b0+w*.0555179;b1=.99332*b1+w*.0750759;b2=.96900*b2+w*.1538520;b3=.86650*b3+w*.3104856;b4=.55*b4+w*.5329522;b5=-.7616*b5-w*.0168980;v=(b0+b1+b2+b3+b4+b5+w*.5362)*.11;}
  else if(color==='brown'){brown=(brown+.02*w)/1.02;v=brown*3.2;}
  data[i]=Math.max(-1,Math.min(1,v));
 }
 cache[color]=buffer;return buffer;
}
function noiseLayer({color='pink',hp=80,lp=2400,gain=.05,mod=0,depth=0,q=.7}={}){
 const src=trackNode(audioCtx.createBufferSource());src.buffer=getNoiseBuffer(audioCtx,color);src.loop=true;
 let chain=src;
 if(hp>0){const f=trackNode(audioCtx.createBiquadFilter());f.type='highpass';f.frequency.value=hp;f.Q.value=.55;chain.connect(f);chain=f;}
 if(lp>0){const f=trackNode(audioCtx.createBiquadFilter());f.type='lowpass';f.frequency.value=lp;f.Q.value=q;chain.connect(f);chain=f;}
 const g=trackNode(audioCtx.createGain());g.gain.value=gain;chain.connect(g).connect(audioGain);src.start();
 if(mod>0){const lfo=trackNode(audioCtx.createOscillator()),lg=trackNode(audioCtx.createGain());lfo.frequency.value=mod;lg.gain.value=gain*depth;lfo.connect(lg).connect(g.gain);lfo.start();}
 return g;
}
function scheduleRandom(fn,min,max){let id;const tick=()=>{const i=ambientTimers.indexOf(id);if(i>=0)ambientTimers.splice(i,1);if(!audioCtx)return;fn();id=setTimeout(tick,min+Math.random()*(max-min));ambientTimers.push(id);};id=setTimeout(tick,min+Math.random()*(max-min));ambientTimers.push(id);}
function noiseBurst({hp=700,lp=5000,gain=.025,duration=.08,color='white'}={}){
 if(!audioCtx||!audioGain)return;const t=audioCtx.currentTime,src=audioCtx.createBufferSource();src.buffer=getNoiseBuffer(audioCtx,color);
 const h=audioCtx.createBiquadFilter();h.type='highpass';h.frequency.value=hp;const l=audioCtx.createBiquadFilter();l.type='lowpass';l.frequency.value=lp;
 const g=audioCtx.createGain();g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(Math.max(.0002,gain),t+.012);g.gain.exponentialRampToValueAtTime(.0001,t+duration);
 src.connect(h).connect(l).connect(g).connect(audioGain);trackTransient(src,[src,h,l,g]);src.start(t,Math.random()*1.5,duration+.02);src.stop(t+duration+.03);
}
function addBirdCall(){
 if(!audioCtx||!audioGain)return;const t=audioCtx.currentTime,base=1150+Math.random()*950,count=2+Math.floor(Math.random()*3);
 for(let i=0;i<count;i++){const at=t+i*(.09+Math.random()*.07),o=audioCtx.createOscillator(),g=audioCtx.createGain(),f=audioCtx.createBiquadFilter();o.type='sine';o.frequency.setValueAtTime(base+Math.random()*260,at);o.frequency.exponentialRampToValueAtTime(base*.62,at+.12);f.type='lowpass';f.frequency.value=3300;g.gain.setValueAtTime(.0001,at);g.gain.linearRampToValueAtTime(.012+Math.random()*.009,at+.025);g.gain.exponentialRampToValueAtTime(.0001,at+.15);o.connect(f).connect(g).connect(audioGain);trackTransient(o,[o,g,f]);o.start(at);o.stop(at+.17);}
}
function addCricketChirp(){
 if(!audioCtx||!audioGain)return;const t=audioCtx.currentTime,o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type='sine';o.frequency.value=3800+Math.random()*900;
 const pulses=3+Math.floor(Math.random()*4);g.gain.setValueAtTime(.0001,t);
 for(let i=0;i<pulses;i++){const at=t+i*.055;g.gain.setValueAtTime(.0001,at);g.gain.linearRampToValueAtTime(.0035,at+.009);g.gain.setValueAtTime(.0001,at+.034);}
 o.connect(g).connect(audioGain);trackTransient(o,[o,g]);o.start(t);o.stop(t+pulses*.055+.04);
}
function addWaterDrop(){
 if(!audioCtx||!audioGain)return;const t=audioCtx.currentTime,o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type='sine';o.frequency.setValueAtTime(1450+Math.random()*850,t);o.frequency.exponentialRampToValueAtTime(420+Math.random()*220,t+.16);g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(.012+Math.random()*.008,t+.012);g.gain.exponentialRampToValueAtTime(.0001,t+.2);o.connect(g).connect(audioGain);trackTransient(o,[o,g]);o.start(t);o.stop(t+.21);
}
function addCafeClink(){
 if(!audioCtx||!audioGain)return;const t=audioCtx.currentTime,frequencies=[1320,1980,2640];frequencies.forEach((hz,i)=>{const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type='sine';o.frequency.value=hz*(.98+Math.random()*.04);g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(.006/(i+1),t+.006);g.gain.exponentialRampToValueAtTime(.0001,t+.28+i*.08);o.connect(g).connect(audioGain);trackTransient(o,[o,g]);o.start(t);o.stop(t+.32+i*.08);});
}
function addCrackle(){
 if(!audioCtx||!audioGain)return;const t=audioCtx.currentTime,o=audioCtx.createOscillator(),g=audioCtx.createGain(),f=audioCtx.createBiquadFilter();o.type='triangle';o.frequency.setValueAtTime(900+Math.random()*1700,t);o.frequency.exponentialRampToValueAtTime(180+Math.random()*250,t+.045);f.type='lowpass';f.frequency.value=2400;g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(.012,t+.004);g.gain.exponentialRampToValueAtTime(.0001,t+.065);o.connect(f).connect(g).connect(audioGain);trackTransient(o,[o,f,g]);o.start(t);o.stop(t+.07);
}
function addThunder(){
 if(!audioCtx||!audioGain)return;const t=audioCtx.currentTime,o=audioCtx.createOscillator(),f=audioCtx.createBiquadFilter(),g=audioCtx.createGain();o.type='triangle';o.frequency.setValueAtTime(58,t);o.frequency.exponentialRampToValueAtTime(27,t+3.8);f.type='lowpass';f.frequency.value=155;g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(.045,t+.65);g.gain.setValueAtTime(.032,t+1.1);g.gain.exponentialRampToValueAtTime(.0001,t+4.8);o.connect(f).connect(g).connect(audioGain);trackTransient(o,[o,f,g]);o.start(t);o.stop(t+4.9);noiseBurst({hp:25,lp:180,gain:.025,duration:2.8,color:'brown'});
}
async function startAmbient(kind){
 stopAmbient(false);if(kind==='stop')return;const spec=ambientLibrary.find(x=>x[0]===kind);if(!spec)return;const token=++ambientStartToken;
 try{
  const AC=window.AudioContext||window.webkitAudioContext;if(!AC)throw Error('AudioContext unsupported');const ctx=new AC();audioCtx=ctx;await ctx.resume();if(token!==ambientStartToken||audioCtx!==ctx){try{ctx.close();}catch{}return;}audioGain=ctx.createGain();audioGain.gain.value=(Number($('#soundVolume')?.value??35)/100)*.65;audioGain.connect(ctx.destination);
  switch(kind){
   case 'rain': noiseLayer({color:'pink',hp:160,lp:2500,gain:.105,mod:.12,depth:.13});scheduleRandom(()=>noiseBurst({hp:1200,lp:5200,gain:.018+Math.random()*.012,duration:.045}),260,650);scheduleRandom(addWaterDrop,900,2200);break;
   case 'heavy-rain': noiseLayer({color:'white',hp:90,lp:5200,gain:.105,mod:.18,depth:.12});noiseLayer({color:'pink',hp:180,lp:1800,gain:.085,mod:.11,depth:.2});scheduleRandom(()=>noiseBurst({hp:650,lp:4300,gain:.025+Math.random()*.025,duration:.07}),100,280);break;
   case 'window-rain': noiseLayer({color:'pink',hp:260,lp:1900,gain:.07,mod:.08,depth:.12});noiseLayer({color:'white',hp:1800,lp:6200,gain:.012});scheduleRandom(()=>noiseBurst({hp:900,lp:3600,gain:.018+Math.random()*.02,duration:.025+Math.random()*.035}),380,1050);scheduleRandom(addWaterDrop,1400,3100);break;
   case 'forest': noiseLayer({color:'brown',hp:55,lp:780,gain:.065,mod:.055,depth:.5});noiseLayer({color:'pink',hp:500,lp:2600,gain:.018,mod:.09,depth:.2});scheduleRandom(addBirdCall,2100,5100);break;
   case 'morning-birds': noiseLayer({color:'pink',hp:420,lp:3600,gain:.012,mod:.04,depth:.1});scheduleRandom(addBirdCall,700,1850);break;
   case 'ocean': noiseLayer({color:'brown',hp:35,lp:620,gain:.105,mod:.065,depth:.62});noiseLayer({color:'white',hp:100,lp:1450,gain:.035,mod:.065,depth:.55});break;
   case 'night-ocean': noiseLayer({color:'brown',hp:25,lp:390,gain:.095,mod:.026,depth:.68});noiseLayer({color:'pink',hp:70,lp:850,gain:.012,mod:.035,depth:.35});break;
   case 'stream': noiseLayer({color:'pink',hp:360,lp:3400,gain:.07,mod:.22,depth:.12});noiseLayer({color:'white',hp:1450,lp:6200,gain:.014,mod:.15,depth:.18});scheduleRandom(()=>noiseBurst({hp:1700,lp:6500,gain:.012,duration:.07}),420,1150);scheduleRandom(addWaterDrop,600,1450);break;
   case 'waterfall': noiseLayer({color:'white',hp:100,lp:5100,gain:.105,mod:.14,depth:.14});noiseLayer({color:'pink',hp:180,lp:1900,gain:.075,mod:.1,depth:.12});noiseLayer({color:'white',hp:1900,lp:6800,gain:.012});break;
   case 'wind-trees': noiseLayer({color:'brown',hp:35,lp:850,gain:.095,mod:.035,depth:.72});noiseLayer({color:'pink',hp:170,lp:1500,gain:.018,mod:.05,depth:.35});break;
   case 'leaves': noiseLayer({color:'pink',hp:850,lp:5700,gain:.045,mod:.13,depth:.2});noiseLayer({color:'brown',hp:100,lp:650,gain:.018,mod:.07,depth:.25});scheduleRandom(()=>noiseBurst({hp:1000,lp:6000,gain:.014,duration:.18,color:'pink'}),850,2200);break;
   case 'fireplace': noiseLayer({color:'brown',hp:35,lp:520,gain:.075,mod:.045,depth:.2});noiseLayer({color:'pink',hp:180,lp:1350,gain:.018});scheduleRandom(addCrackle,420,1450);break;
   case 'night': noiseLayer({color:'brown',hp:25,lp:420,gain:.022,mod:.018,depth:.25});noiseLayer({color:'pink',hp:500,lp:1500,gain:.004});scheduleRandom(addCricketChirp,4200,8500);break;
   case 'crickets': noiseLayer({color:'pink',hp:1800,lp:5600,gain:.004});scheduleRandom(addCricketChirp,850,1750);break;
   case 'cafe': noiseLayer({color:'pink',hp:160,lp:1250,gain:.045,mod:.075,depth:.12});noiseLayer({color:'pink',hp:280,lp:780,gain:.018,mod:.11,depth:.18});noiseLayer({color:'white',hp:900,lp:2300,gain:.006,mod:.06,depth:.15});scheduleRandom(()=>noiseBurst({hp:300,lp:1100,gain:.006,duration:.35,color:'pink'}),1800,4200);scheduleRandom(addCafeClink,6500,13000);break;
   case 'white': noiseLayer({color:'white',hp:25,lp:10500,gain:.115});break;
   case 'brown': noiseLayer({color:'brown',hp:20,lp:780,gain:.13});break;
   case 'distant-thunder': noiseLayer({color:'pink',hp:120,lp:2400,gain:.085,mod:.1,depth:.16});noiseLayer({color:'white',hp:500,lp:3800,gain:.018});scheduleRandom(addThunder,9000,17000);scheduleRandom(()=>noiseBurst({hp:1100,lp:5000,gain:.018,duration:.05}),350,850);break;
  }
  activeAmbient=kind;$$('[data-sound]').forEach(b=>b.classList.toggle('active',b.dataset.sound===kind));$('#soundStatus').textContent=`يعمل الآن: ${spec[1]} — ${spec[2]} مؤثر مُولّد محليًا.`;
 }catch(e){console.warn('Ambient audio:',e);if(token===ambientStartToken){stopAmbient(false);if($('#soundStatus'))$('#soundStatus').textContent='تعذر تشغيل الصوت. المس زر التشغيل مرة أخرى أو تحقق من دعم الصوت في المتصفح.';}}
}
function stopAmbient(update=true){
 ambientStartToken++;ambientTimers.forEach(id=>{clearTimeout(id);clearInterval(id);});ambientTimers=[];
 if(audioGain&&audioCtx){try{audioGain.gain.cancelScheduledValues(audioCtx.currentTime);audioGain.gain.setTargetAtTime(0,audioCtx.currentTime,.025);}catch{}}
 ambientNodes.forEach(n=>{try{n.stop?.();}catch{}try{n.disconnect?.();}catch{}});ambientNodes=[];
 const oldCtx=audioCtx;audioCtx=null;audioSource=null;audioGain=null;activeAmbient='';if(oldCtx){try{oldCtx.close();}catch{}}
 $$('[data-sound]').forEach(b=>b.classList.remove('active'));if(update&&$('#soundStatus'))$('#soundStatus').textContent='تم إيقاف مكتبة الأصوات.';
}

// Search displays real results, not just a count.
function ensureSearchResults(){if($('#searchResults'))return;const box=document.createElement('section');box.id='searchResults';box.className='panel search-results';box.hidden=true;$('.topbar')?.after(box);}
ensureSearchResults();
// Extended all-data search is provided by injaz-v4.js.


// First render and PWA cache update.
function boot(){renderNotes();loadSettings();renderMood();ensureVolumeControl();refreshAll();if('serviceWorker'in navigator&&location.protocol!=='file:'){navigator.serviceWorker.register('./sw.js').catch(e=>console.warn('SW registration:',e));}}
boot();
window.addEventListener('beforeunload',()=>{stopAmbient(false);stopTimer();});
