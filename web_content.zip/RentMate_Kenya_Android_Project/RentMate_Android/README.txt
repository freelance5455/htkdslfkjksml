RentMate Kenya - Android project (online version)

This app opens the live website:
https://anthonykithongo23-collab.github.io/rentmate/
Login and data are handled by Firebase (project rentmate-tony) inside the website.
Because the app loads the live site, updating the website updates the app.
The app needs an internet connection.

Package name: com.rentmate.kenya
Needs: INTERNET permission (already in AndroidManifest.xml)

Build with Android Studio or a zip-to-APK tool that builds Gradle projects.
A backup copy of the page is in app/src/main/assets/index.html (not used by the app).
