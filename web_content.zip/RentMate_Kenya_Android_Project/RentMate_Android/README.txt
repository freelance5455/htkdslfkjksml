RentMate Kenya - Android project (version 2.1)

The page inside app/src/main/assets/index.html is the NEW public + agent version:
- visitors see houses and send enquiries (WhatsApp 254725906432)
- agent logs in (bottom of the page, "Agent login") to manage houses
MainActivity also opens the live site https://anthonykithongo23-collab.github.io/rentmate/
Package: com.rentmate.kenya   versionCode 3
