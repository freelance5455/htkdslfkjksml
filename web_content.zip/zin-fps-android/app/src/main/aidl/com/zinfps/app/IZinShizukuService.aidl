package com.zinfps.app;

/** Limited, read-only diagnostic interface exposed by the Shizuku UserService. */
interface IZinShizukuService {
    String runDiagnostic(String diagnosticId);
    void destroy() = 16777114;
}
