package com.zinfps.app

import android.content.Context
import android.os.SystemClock
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Runs only fixed, read-only Android diagnostics in Shizuku's UserService process.
 * No arbitrary shell text or user-provided arguments are accepted.
 */
class ZinShizukuUserService : IZinShizukuService.Stub() {
    constructor() : super()
    @Suppress("UNUSED_PARAMETER")
    constructor(context: Context) : super()

    private data class SafeCommand(val argv: Array<String>, val description: String)

    private val allowedCommands = mapOf(
        "ANDROID_SDK" to SafeCommand(arrayOf("getprop", "ro.build.version.sdk"), "Android SDK level"),
        "ANDROID_RELEASE" to SafeCommand(arrayOf("getprop", "ro.build.version.release"), "Android release"),
        "DISPLAY_SIZE" to SafeCommand(arrayOf("wm", "size"), "Display size"),
        "DISPLAY_DENSITY" to SafeCommand(arrayOf("wm", "density"), "Display density"),
        "BATTERY_DIAGNOSTIC" to SafeCommand(arrayOf("dumpsys", "battery"), "Battery diagnostic")
    )

    private val io = Executors.newCachedThreadPool()

    override fun runDiagnostic(diagnosticId: String): String {
        val safe = allowedCommands[diagnosticId]
            ?: return resultJson(diagnosticId, "Rejected", "", "Diagnostic ID is not allowed", -1, false)

        var process: Process? = null
        val start = SystemClock.elapsedRealtime()
        return try {
            // Array argv, no shell interpreter, and only pre-approved read-only commands.
            process = Runtime.getRuntime().exec(safe.argv)
            val running = process
            val stdout = io.submit<String> { readBounded(running.inputStream) }
            val stderr = io.submit<String> { readBounded(running.errorStream) }

            val finished = running.waitFor(5, TimeUnit.SECONDS)
            if (!finished) {
                running.destroy()
                resultJson(diagnosticId, safe.description, stdout.get(1, TimeUnit.SECONDS), "Timed out after 5 seconds", -2, false)
            } else {
                val out = stdout.get(1, TimeUnit.SECONDS)
                val err = stderr.get(1, TimeUnit.SECONDS)
                val code = running.exitValue()
                resultJson(diagnosticId, safe.description, out, err, code, code == 0,
                    SystemClock.elapsedRealtime() - start)
            }
        } catch (e: Exception) {
            process?.destroy()
            resultJson(diagnosticId, safe.description, "", e.javaClass.simpleName + ": " + (e.message ?: "command failed"), -1, false,
                SystemClock.elapsedRealtime() - start)
        }
    }

    private fun readBounded(stream: java.io.InputStream): String {
        val output = StringBuilder()
        BufferedReader(InputStreamReader(stream)).use { reader ->
            while (output.length < MAX_OUTPUT_CHARS) {
                val line = reader.readLine() ?: break
                if (output.isNotEmpty()) output.append('\n')
                val remaining = MAX_OUTPUT_CHARS - output.length
                output.append(line.take(remaining))
            }
        }
        if (output.length >= MAX_OUTPUT_CHARS) output.append("\n[truncated]")
        return output.toString()
    }

    private fun resultJson(
        id: String,
        description: String,
        stdout: String,
        stderr: String,
        exitCode: Int,
        success: Boolean,
        durationMs: Long = 0
    ) = JSONObject()
        .put("id", id)
        .put("description", description)
        .put("stdout", stdout)
        .put("stderr", stderr)
        .put("exitCode", exitCode)
        .put("success", success)
        .put("durationMs", durationMs)
        .toString()

    override fun destroy() {
        io.shutdownNow()
        System.exit(0)
    }

    private companion object {
        const val MAX_OUTPUT_CHARS = 16_384
    }
}
