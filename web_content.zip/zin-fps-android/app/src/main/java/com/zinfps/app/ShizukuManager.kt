package com.zinfps.app

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Owns the official Shizuku connection/permission lifecycle and exposes only
 * an allowlisted, read-only diagnostics interface through the app UserService.
 */
class ShizukuManager(
    context: Context,
    private val listener: Listener? = null
) {
    enum class ConnectionState { DISCONNECTED, RUNNING_NOT_AUTHORIZED, CONNECTED }

    data class CommandResult(
        val diagnosticId: String,
        val description: String,
        val stdout: String,
        val stderr: String,
        val exitCode: Int,
        val success: Boolean,
        val durationMs: Long
    )

    interface Listener {
        fun onConnectionStateChanged(state: ConnectionState)
        fun onPermissionResult(granted: Boolean) {}
    }

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val closed = AtomicBoolean(false)
    @Volatile private var remote: IZinShizukuService? = null
    @Volatile private var bound = false

    private val args by lazy {
        Shizuku.UserServiceArgs(
            ComponentName(appContext, ZinShizukuUserService::class.java)
        )
            .daemon(false)
            .processNameSuffix("zin_fps_shizuku")
            .debuggable(false)
            .version(BuildConfig.VERSION_CODE)
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            remote = service?.let { IZinShizukuService.Stub.asInterface(it) }
            bound = remote != null
            notifyState()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            remote = null
            bound = false
            notifyState()
        }
    }

    private val binderReceived = Shizuku.OnBinderReceivedListener { notifyState() }
    private val binderDead = Shizuku.OnBinderDeadListener {
        remote = null
        bound = false
        notifyState()
    }
    private val permissionResult = Shizuku.OnRequestPermissionResultListener { code, result ->
        if (code == PERMISSION_REQUEST_CODE) {
            val granted = result == PackageManager.PERMISSION_GRANTED
            if (granted) bindAuthorizedService()
            listener?.let { callback -> mainHandler.post { callback.onPermissionResult(granted) } }
            notifyState()
        }
    }

    init {
        Shizuku.addBinderReceivedListener(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permissionResult)
        notifyState()
    }

    /** True only while the Shizuku binder is alive. */
    fun isServiceRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (_: Throwable) {
        false
    }

    /** True only if Shizuku reports that this exact app has been authorized. */
    fun hasPermission(): Boolean = try {
        isServiceRunning() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) {
        false
    }

    fun connectionState(): ConnectionState = when {
        !isServiceRunning() -> ConnectionState.DISCONNECTED
        !hasPermission() -> ConnectionState.RUNNING_NOT_AUTHORIZED
        else -> ConnectionState.CONNECTED
    }

    /** Requests the official Shizuku permission prompt; does not fake success. */
    fun requestPermission(): Result<Unit> = runCatching {
        check(isServiceRunning()) { "Shizuku service is not running" }
        check(!Shizuku.isPreV11()) { "Shizuku API v11 or newer is required" }
        if (hasPermission()) {
            bindAuthorizedService()
        } else {
            Shizuku.requestPermission(PERMISSION_REQUEST_CODE)
        }
        notifyState()
    }

    /** Bind the app-owned UserService only after the user has granted permission. */
    fun bindAuthorizedService(): Result<Unit> = runCatching {
        check(isServiceRunning()) { "Shizuku service is not running" }
        check(hasPermission()) { "ZIN FPS has not been authorized in Shizuku" }
        if (!bound) {
            Shizuku.bindUserService(args, serviceConnection)
            bound = true
        }
        notifyState()
    }

    /**
     * Execute one of these fixed, read-only diagnostic IDs:
     * ANDROID_SDK, ANDROID_RELEASE, DISPLAY_SIZE, DISPLAY_DENSITY, BATTERY_DIAGNOSTIC.
     * There is intentionally no API for arbitrary shell strings.
     */
    fun runDiagnostic(diagnosticId: String, callback: (Result<CommandResult>) -> Unit) {
        worker.execute {
            val result = runCatching {
                check(hasPermission()) { "Shizuku is disconnected or permission is missing" }
                val service = remote ?: run {
                    bindAuthorizedService().getOrThrow()
                    null
                }
                val activeService = service ?: waitForServiceConnection()
                val json = activeService.runDiagnostic(diagnosticId)
                val parsed = org.json.JSONObject(json)
                CommandResult(
                    diagnosticId = parsed.optString("id", diagnosticId),
                    description = parsed.optString("description"),
                    stdout = parsed.optString("stdout"),
                    stderr = parsed.optString("stderr"),
                    exitCode = parsed.optInt("exitCode", -1),
                    success = parsed.optBoolean("success", false),
                    durationMs = parsed.optLong("durationMs", 0)
                )
            }
            mainHandler.post { callback(result) }
        }
    }

    private fun waitForServiceConnection(): IZinShizukuService {
        val deadline = System.currentTimeMillis() + SERVICE_CONNECT_TIMEOUT_MS
        while (System.currentTimeMillis() < deadline) {
            remote?.let { return it }
            Thread.sleep(50)
        }
        error("Shizuku UserService connection timed out")
    }

    private fun notifyState() {
        val state = connectionState()
        listener?.let { callback -> mainHandler.post { callback.onConnectionStateChanged(state) } }
    }

    fun close() {
        if (!closed.compareAndSet(false, true)) return
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permissionResult)
        if (bound) {
            runCatching { Shizuku.unbindUserService(args, serviceConnection, true) }
        }
        remote = null
        bound = false
        worker.shutdownNow()
    }

    private companion object {
        const val PERMISSION_REQUEST_CODE = 7102
        const val SERVICE_CONNECT_TIMEOUT_MS = 5_000L
    }
}
