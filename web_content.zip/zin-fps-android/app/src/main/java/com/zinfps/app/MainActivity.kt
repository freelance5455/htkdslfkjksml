package com.zinfps.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var connectButton: Button
    private var currentTab = "JOGOS"
    private var selectedProfile = "EQUILIBRADO"
    private lateinit var shizukuManager: ShizukuManager

    private val profiles = listOf("EXTREMO", "EQUILIBRADO", "BATERIA", "PERSONALIZADO")
    private val tabs = listOf("JOGOS", "BOOST", "GPU", "CPU", "ÁUDIO", "REDE")
    private val knownGamePackages = setOf(
        "com.dts.freefireth", "com.dts.freefiremax", "com.netease.newspike",
        "com.tencent.ig", "com.activision.callofduty.shooter", "com.roblox.client",
        "com.mojang.minecraftpe", "com.supercell.brawlstars"
    )


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        content = findViewById(R.id.mainContent)
        selectedProfile = getPreferences(MODE_PRIVATE).getString("profile", "EQUILIBRADO") ?: "EQUILIBRADO"
        shizukuManager = ShizukuManager(this, object : ShizukuManager.Listener {
            override fun onConnectionStateChanged(state: ShizukuManager.ConnectionState) {
                updateShizukuStatus(state)
            }
            override fun onPermissionResult(granted: Boolean) {
                toast(if (granted) "Permissão Shizuku concedida" else "Permissão Shizuku recusada")
            }
        })
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) updateShizukuStatus()
    }

    override fun onDestroy() {
        if (::shizukuManager.isInitialized) shizukuManager.close()
        super.onDestroy()
    }

    private fun render() {
        content.removeAllViews()
        content.addView(header())
        content.addView(sectionTitle("CONEXÃO SHIZUKU"), lpTop(20))
        val connection = panel()
        statusText = text("DESCONECTADO", 13, Color.rgb(255, 112, 126), true).apply { gravity = Gravity.CENTER_VERTICAL }
        connection.addView(statusText, LinearLayout.LayoutParams(0, dp(42), 1f))
        connectButton = button("CONECTAR SHIZUKU") { connectShizuku() }
        connection.addView(connectButton, LinearLayout.LayoutParams(dp(190), dp(44)))
        content.addView(connection, lpTop(7))
        content.addView(text("Conectado = serviço Shizuku ativo e autorização deste app concedida.", 11, mutedColor()), lpTop(7))

        content.addView(sectionTitle("PERFIL DE JOGO"), lpTop(20))
        val profilesScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val profileRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        profiles.forEach { name ->
            val item = button(name) {
                selectedProfile = name
                getPreferences(MODE_PRIVATE).edit().putString("profile", name).apply()
                render()
            }.apply {
                textSize = 10f
                background = rounded(if (name == selectedProfile) redColor() else panelColor(), 12, if (name == selectedProfile) redColor() else lineColor())
                setTextColor(if (name == selectedProfile) Color.WHITE else mutedColor())
            }
            profileRow.addView(item, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(7) })
        }
        profilesScroll.addView(profileRow)
        content.addView(profilesScroll, lpTop(8))
        content.addView(text("Perfil salvo nesta tela; não altera sozinho CPU/GPU ou o jogo.", 10, mutedColor()), lpTop(6))

        content.addView(sectionTitle("FUNÇÕES AVANÇADAS"), lpTop(20))
        val tabsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val tabsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabs.forEach { tab ->
            val tabButton = button(tab) { currentTab = tab; render() }.apply {
                textSize = 11f
                background = rounded(if (currentTab == tab) redColor() else panelColor(), 10, if (currentTab == tab) redColor() else lineColor())
                setTextColor(if (currentTab == tab) Color.WHITE else mutedColor())
            }
            tabsRow.addView(tabButton, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(42)).apply { marginEnd = dp(7) })
        }
        tabsScroll.addView(tabsRow)
        content.addView(tabsScroll, lpTop(8))
        content.addView(sectionTitle(currentTab), lpTop(16))
        renderTabBody()
    }

    private fun header(): View {
        val box = panel().apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(31, 12, 17), 22, Color.rgb(88, 31, 43))
            setPadding(dp(17), dp(19), dp(17), dp(18))
        }
        box.addView(text("ZIN FPS", 28, Color.WHITE, true))
        box.addView(text("GAME CONTROL CENTER", 10, Color.rgb(255, 111, 128), true), lpTop(5))
        return box
    }

    private fun renderTabBody() {
        when (currentTab) {
            "JOGOS" -> renderGames()
            "BOOST" -> {
                infoCard("AÇÕES REAIS DO ANDROID", "Estes atalhos abrem as configurações do sistema. O app não muda configurações silenciosamente.")
                actionCard("Bateria", "Abrir configurações de bateria", Settings.ACTION_BATTERY_SAVER_SETTINGS)
                actionCard("Aplicativos", "Gerenciar apps e uso em segundo plano", Settings.ACTION_APPLICATION_SETTINGS)
                actionCard("Modo de jogo", "Se disponível, abrir configurações do fabricante", Settings.ACTION_SETTINGS)
                diagnosticCard("DIAGNÓSTICOS SOMENTE LEITURA", listOf(
                    "ANDROID_SDK" to "Versão SDK Android",
                    "ANDROID_RELEASE" to "Versão Android",
                    "DISPLAY_SIZE" to "Tamanho da tela",
                    "DISPLAY_DENSITY" to "Densidade da tela",
                    "BATTERY_DIAGNOSTIC" to "Diagnóstico da bateria"
                ))
            }
            "GPU" -> {
                infoCard("GPU E GRÁFICOS", "O Android não oferece a este app um controle universal de clock, FPS ou renderização da GPU. Não há botões falsos de otimização.")
                actionCard("Tela", "Abrir configurações de tela e taxa de atualização", Settings.ACTION_DISPLAY_SETTINGS)
            }
            "CPU" -> {
                val cores = Runtime.getRuntime().availableProcessors()
                infoCard("CPU DO DISPOSITIVO", "Núcleos lógicos disponíveis para o app: $cores\nO app não força clock nem muda limites térmicos.")
                actionCard("Bateria", "Veja o modo de energia do Android", Settings.ACTION_BATTERY_SAVER_SETTINGS)
                diagnosticCard("CONSULTA VIA SHIZUKU", listOf("ANDROID_SDK" to "Ler nível do Android"))
            }
            "ÁUDIO" -> {
                infoCard("ÁUDIO", "O app não aplica equalização nem modifica o áudio do jogo. Use as configurações de som do aparelho ou do próprio jogo.")
                actionCard("Som", "Abrir configurações de áudio", Settings.ACTION_SOUND_SETTINGS)
            }
            "REDE" -> {
                infoCard("REDE", "O Android não permite que este app priorize pacotes do jogo ou prometa reduzir ping. Você pode abrir as configurações da conexão.")
                actionCard("Wi-Fi e rede", "Abrir configurações de Wi-Fi", Settings.ACTION_WIFI_SETTINGS)
            }
        }
    }

    private fun renderGames() {
        val games = installedGames()
        if (games.isEmpty()) {
            infoCard("NENHUM JOGO DETECTADO", "Não encontrei jogos reconhecidos instalados. A lista considera apps marcados como jogo pelo Android e jogos conhecidos.")
            return
        }
        games.forEach { app ->
            val row = panel().apply { gravity = Gravity.CENTER_VERTICAL }
            val icon = ImageView(this).apply { setImageDrawable(app.loadIcon(packageManager)) }
            row.addView(icon, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(11) })
            val label = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            label.addView(text(packageManager.getApplicationLabel(app).toString(), 14, textColor(), true))
            label.addView(text("Instalado · toque para abrir", 10, mutedColor()), lpTop(4))
            row.addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(button("ABRIR") { launchApp(app.packageName) }, LinearLayout.LayoutParams(dp(75), dp(38)))
            row.setOnClickListener { launchApp(app.packageName) }
            content.addView(row, lpTop(8))
        }
    }

    private fun installedGames(): List<ApplicationInfo> {
        val apps = try {
            if (Build.VERSION.SDK_INT >= 33) {
                packageManager.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                packageManager.getInstalledApplications(0)
            }
        } catch (_: Exception) { return emptyList() }
        return apps.filter { app ->
            app.packageName != packageName && packageManager.getLaunchIntentForPackage(app.packageName) != null &&
                ((Build.VERSION.SDK_INT >= 26 && app.category == ApplicationInfo.CATEGORY_GAME) || knownGamePackages.contains(app.packageName))
        }.sortedBy { packageManager.getApplicationLabel(it).toString().lowercase() }
    }

    private fun launchApp(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent == null) toast("Não foi possível abrir esse jogo") else startActivity(intent)
    }

    private fun actionCard(title: String, subtitle: String, action: String) {
        val item = panel().apply { orientation = LinearLayout.VERTICAL }
        item.addView(text(title, 14, textColor(), true))
        item.addView(text(subtitle, 11, mutedColor()), lpTop(5))
        item.addView(button("ABRIR CONFIGURAÇÕES") {
            try { startActivity(Intent(action)) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }, lpTop(10))
        content.addView(item, lpTop(8))
    }

    private fun diagnosticCard(title: String, diagnostics: List<Pair<String, String>>) {
        val card = panel().apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.START }
        card.addView(text(title, 12, Color.rgb(255, 112, 126), true))
        card.addView(text("Comandos fixos e somente leitura. Exigem Shizuku conectado e autorizado.", 10, mutedColor()), lpTop(5))
        diagnostics.forEach { (id, label) ->
            card.addView(button(label) {
                if (shizukuManager.connectionState() != ShizukuManager.ConnectionState.CONNECTED) {
                    toast("Conecte e autorize o Shizuku primeiro")
                } else {
                    shizukuManager.runDiagnostic(id) { result ->
                        result.fold(
                            onSuccess = { r ->
                                val details = buildString {
                                    append("Comando: ").append(r.description).append("\n")
                                    append("Resultado: ").append(if (r.success) "sucesso" else "falhou").append("\n")
                                    append("Código: ").append(r.exitCode).append(" · ").append(r.durationMs).append(" ms\n\n")
                                    if (r.stdout.isNotBlank()) append(r.stdout)
                                    if (r.stderr.isNotBlank()) append("\n\nErro:\n").append(r.stderr)
                                }
                                AlertDialog.Builder(this)
                                    .setTitle(label)
                                    .setMessage(details)
                                    .setPositiveButton("OK", null)
                                    .show()
                            },
                            onFailure = { error -> toast(error.message ?: "Falha no diagnóstico") }
                        )
                    }
                }
            }, lpTop(7))
        }
        content.addView(card, lpTop(9))
    }

    private fun infoCard(title: String, body: String) {
        val item = panel().apply { orientation = LinearLayout.VERTICAL }
        item.addView(text(title, 13, Color.rgb(255, 112, 126), true))
        item.addView(text(body, 12, mutedColor()), lpTop(7))
        content.addView(item, lpTop(8))
    }

    private fun connectShizuku() {
        shizukuManager.requestPermission()
            .onFailure { error -> toast(error.message ?: "Não foi possível conectar ao Shizuku") }
        updateShizukuStatus()
    }

    private fun updateShizukuStatus() {
        if (!::statusText.isInitialized || !::shizukuManager.isInitialized) return
        updateShizukuStatus(shizukuManager.connectionState())
    }

    private fun updateShizukuStatus(state: ShizukuManager.ConnectionState) {
        if (!::statusText.isInitialized) return
        runOnUiThread {
            when (state) {
                ShizukuManager.ConnectionState.CONNECTED -> {
                    statusText.text = "CONECTADO · AUTORIZADO"
                    statusText.setTextColor(Color.rgb(53, 220, 143))
                    connectButton.text = "SHIZUKU CONECTADO"
                }
                ShizukuManager.ConnectionState.RUNNING_NOT_AUTHORIZED -> {
                    statusText.text = "SERVIÇO ATIVO · SEM AUTORIZAÇÃO"
                    statusText.setTextColor(Color.rgb(255, 185, 74))
                    connectButton.text = "CONECTAR SHIZUKU"
                }
                ShizukuManager.ConnectionState.DISCONNECTED -> {
                    statusText.text = "DESCONECTADO"
                    statusText.setTextColor(Color.rgb(255, 112, 126))
                    connectButton.text = "CONECTAR SHIZUKU"
                }
            }
        }
    }

    private fun sectionTitle(value: String) = text(value, 11, Color.rgb(255, 101, 120), true)
    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun panel() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(13), dp(12), dp(13), dp(12))
        background = rounded(panelColor(), 15, lineColor())
    }
    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 11f; isAllCaps = false; setTextColor(Color.WHITE)
        background = rounded(redColor(), 11, redColor()); setOnClickListener { action() }
    }
    private fun rounded(color: Int, radius: Int, stroke: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), stroke)
    }
    private fun lpTop(margin: Int) = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(margin) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun redColor() = Color.rgb(207, 35, 61)
    private fun panelColor() = Color.rgb(23, 21, 24)
    private fun lineColor() = Color.rgb(66, 39, 46)
    private fun textColor() = Color.rgb(245, 241, 242)
    private fun mutedColor() = Color.rgb(170, 159, 162)
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
