package com.zinfps.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView

    private val knownGames = mapOf(
        "com.dts.freefireth" to "Free Fire",
        "com.dts.freefiremax" to "Free Fire MAX",
        "com.netease.newspike" to "Blood Strike",
        "com.tencent.ig" to "PUBG MOBILE",
        "com.activision.callofduty.shooter" to "Call of Duty: Mobile",
        "com.roblox.client" to "Roblox",
        "com.mojang.minecraftpe" to "Minecraft",
        "com.supercell.brawlstars" to "Brawl Stars"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                refreshGamesInPage()
            }
        }
        webView.addJavascriptInterface(GamesBridge(this), "AndroidGames")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun installedGames(): JSONArray {
        val result = JSONArray()
        val apps = if (android.os.Build.VERSION.SDK_INT >= 33) {
            packageManager.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            packageManager.getInstalledApplications(0)
        }
        apps.forEach { appInfo ->
            val launchIntent = packageManager.getLaunchIntentForPackage(appInfo.packageName)
            val isGame = (android.os.Build.VERSION.SDK_INT >= 26 && appInfo.category == android.content.pm.ApplicationInfo.CATEGORY_GAME) || knownGames.containsKey(appInfo.packageName)
            if (launchIntent != null && isGame) {
                val name = packageManager.getApplicationLabel(appInfo).toString().ifBlank { knownGames[appInfo.packageName] ?: appInfo.packageName }
                result.put(JSONObject().put("packageName", appInfo.packageName).put("name", name))
            }
        }
        return result
    }

    private fun selectableApps(): JSONArray {
        val result = JSONArray()
        val apps = if (android.os.Build.VERSION.SDK_INT >= 33) {
            packageManager.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            packageManager.getInstalledApplications(0)
        }
        apps.filter { it.packageName != packageName && packageManager.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { packageManager.getApplicationLabel(it).toString().lowercase() }
            .forEach { info -> result.put(JSONObject().put("packageName", info.packageName).put("name", packageManager.getApplicationLabel(info).toString())) }
        return result
    }

    private fun refreshGamesInPage() {
        if (!::webView.isInitialized) return
        val json = installedGames().toString()
        webView.post { webView.evaluateJavascript("renderDetectedGames($json)", null) }
    }

    inner class GamesBridge(private val context: Context) {
        @JavascriptInterface
        fun listGames(): String = installedGames().toString()


        @JavascriptInterface
        fun showGamePicker() {
            runOnUiThread {
                val games = selectableApps()
                if (games.length() == 0) {
                    android.app.AlertDialog.Builder(this@MainActivity)
                        .setTitle("Nenhum aplicativo selecionável encontrado")
                        .setMessage("Não há aplicativos com ícone de abertura disponíveis.")
                        .setPositiveButton("OK", null)
                        .show()
                    return@runOnUiThread
                }
                val labels = Array(games.length()) { index -> games.getJSONObject(index).getString("name") }
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("Selecione um jogo ou aplicativo")
                    .setItems(labels) { _, which ->
                        val selected = games.getJSONObject(which)
                        val json = selected.toString()
                        webView.evaluateJavascript("window.onGamePicked && window.onGamePicked(${JSONObject.quote(json)})", null)
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }

        @JavascriptInterface
        fun launchPackage(packageName: String): Boolean {
            if (packageManager.getLaunchIntentForPackage(packageName) == null) return false
            val launch = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
            return try {
                context.startActivity(launch)
                true
            } catch (_: Exception) {
                false
            }
        }
    }
}
