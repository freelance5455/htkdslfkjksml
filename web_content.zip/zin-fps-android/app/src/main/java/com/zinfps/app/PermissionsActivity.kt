package com.zinfps.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.content.pm.PackageManager
import android.widget.Button
import android.widget.Toast
import rikka.shizuku.Shizuku

class PermissionsActivity : Activity() {
    companion object {
        private const val SHIZUKU_PERM = 7102
        private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    }
    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_PERM) {
            val granted = grantResult == PackageManager.PERMISSION_GRANTED
            Toast.makeText(this, if (granted) "Permissão Shizuku concedida" else "Permissão Shizuku não concedida", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_permissions)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        findViewById<Button>(R.id.btnShizuku).setOnClickListener { requestShizuku() }
        findViewById<Button>(R.id.btnApps).setOnClickListener {
            // QUERY_ALL_PACKAGES is declared in the manifest; Android does not show a runtime dialog for it.
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    private fun requestShizuku() {
        try {
            when {
                // Shizuku isn't running: explain and try to open it directly.
                !Shizuku.pingBinder() -> {
                    Toast.makeText(
                        this,
                        "⚠️ Abra o Shizuku primeiro e inicie o serviço. Depois volte aqui.",
                        Toast.LENGTH_LONG
                    ).show()
                    try {
                        val launchIntent = packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
                        if (launchIntent != null) {
                            startActivity(launchIntent)
                        } else {
                            AlertDialog.Builder(this)
                                .setTitle("Shizuku não encontrado")
                                .setMessage("Instale o Shizuku, inicie o serviço e volte para autorizar o ZIN FPS.")
                                .setPositiveButton("Abrir página oficial") { _, _ ->
                                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")))
                                }
                                .setNegativeButton("Agora não", null)
                                .show()
                        }
                    } catch (_: Exception) {
                        Toast.makeText(this, "Não foi possível abrir o Shizuku", Toast.LENGTH_SHORT).show()
                    }
                }

                // The user has already authorized this app.
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> {
                    Toast.makeText(this, "✅ Shizuku já está autorizado!", Toast.LENGTH_SHORT).show()
                }

                // Ask Shizuku to show its own permission prompt.
                else -> {
                    if (Shizuku.isPreV11()) {
                        Toast.makeText(this, "❌ Atualize o Shizuku para a versão 11 ou superior!", Toast.LENGTH_LONG).show()
                    } else {
                        Shizuku.requestPermission(SHIZUKU_PERM)
                        Toast.makeText(this, "⌛ Autorize o ZIN FPS na tela do Shizuku.", Toast.LENGTH_LONG).show()
                    }
                }
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Não foi possível comunicar com o Shizuku", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }
}
