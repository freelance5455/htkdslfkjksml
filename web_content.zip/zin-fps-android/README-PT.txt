ZIN FPS — projeto Android

O app mostra somente os jogos compatíveis que realmente estão instalados e abre o jogo ao tocar no cartão. A lista usa consultas restritas de pacotes no Android; não pede acesso amplo a todos os apps nem uma permissão de runtime.

Jogos verificados: Free Fire, Free Fire MAX, Blood Strike, PUBG MOBILE, Call of Duty: Mobile, Roblox, Minecraft e Brawl Stars.

Para compilar, abra esta pasta no Android Studio atualizado e compile o módulo :app. Este ambiente não inclui ferramentas de compilação Android, então não foi gerado um APK aqui.

A imagem fornecida do Madara aparece no cabeçalho. O botão ADICIONAR abre uma lista nativa dos jogos compatíveis encontrados no aparelho; tocar num item seleciona o jogo sem digitação.

Tela inicial de permissões incluída em app/src/main/res/layout/activity_permissions.xml. A permissão QUERY_ALL_PACKAGES é declarada no manifesto (não há diálogo runtime do Android para ela). A lista usa essa visibilidade para exibir jogos conhecidos e para permitir escolher apps com launcher.

Shizuku usa API oficial dev.rikka.shizuku:api/provider 13.1.4. Instale e inicie Shizuku; o botão solicita a autorização pelo próprio Shizuku. A autorização é opcional. O projeto não implementa operações de otimização de sistema privilegiadas ainda.

Observação de distribuição: QUERY_ALL_PACKAGES é uma permissão de visibilidade ampla e pode exigir justificativa/aprovação se o app for publicado no Google Play. Para distribuição fora da Play, a visibilidade ampla fica habilitada conforme o pedido.

A arte do Madara está aplicada exclusivamente ao ícone do app na tela inicial do Android (ícones legacy e adaptive). Ela foi removida da interface interna do aplicativo.
