ZIN FPS 2.0 — aplicativo Android nativo (Kotlin)

Interface inteiramente nativa. O projeto contém a integração oficial Shizuku API/Provider 13.1.4, botão CONECTAR SHIZUKU, solicitação real de autorização, monitoramento do binder e estado CONECTADO somente quando o serviço responde e a permissão foi concedida.

Perfis EXTREMO, EQUILIBRADO, BATERIA e PERSONALIZADO são preferências locais de interface; não afirmam modificar o desempenho do Android. Abas: JOGOS, BOOST, GPU, CPU, ÁUDIO e REDE. A tela JOGOS detecta apps categorizados como jogos e alguns jogos conhecidos; tocar em ABRIR inicia o app. BOOST/ÁUDIO/REDE incluem atalhos às configurações Android. GPU/CPU declaram claramente as limitações e não exibem controles que não sejam executados.

Dependências Shizuku:
- dev.rikka.shizuku:api:13.1.4
- dev.rikka.shizuku:provider:13.1.4
- Repositórios Maven Central, Google e Gradle Plugin Portal

Para abrir: importe a pasta raiz zin-fps-android no Android Studio, sincronize Gradle e execute o módulo app. Use um dispositivo com Shizuku iniciado. A autorização precisa ser concedida no prompt oficial do Shizuku. O binder/consentimento são estados distintos: o app exibe CONECTADO apenas com ambos.

Limites reais: Shizuku é uma ponte de privilégios; esta versão pede e acompanha autorização, mas não executa mudanças privilegiadas de CPU/GPU, não aumenta FPS nem altera as configurações do jogo. A tela só marca como conectado o que verificou. Recursos de GPU/CPU continuam informativos até que uma operação específica segura, compatível e validada seja implementada.

QUERY_ALL_PACKAGES habilita a detecção de apps/jogos instalados. Para publicar na Google Play, essa permissão ampla pode exigir aprovação e justificativa segundo a política de visibilidade de pacotes.

ShizukuManager.kt executa apenas diagnósticos de leitura através do UserService AIDL IZinShizukuService: versão/API do Android, tamanho/densidade da tela e diagnóstico de bateria. IDs fora da allowlist são rejeitados; não aceita comandos de shell arbitrários. A execução usa timeout de 5 s, saída limitada a 16 KiB e retorna stdout, stderr, exitCode, success e duração.
