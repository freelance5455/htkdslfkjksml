package com.example.menu

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding(64, 64, 64, 64)
        }
        status = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER }
        root.addView(status)
        root.addView(button("Permitir notificações") { askNotifications() })
        root.addView(button("Permitir sobrepor a outros apps") { askOverlay() })
        root.addView(button("Abrir menu por cima") { openMenu() })
        setContentView(root)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { onClick() }
    }

    private fun hasNotif() = Build.VERSION.SDK_INT < 33 ||
        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun hasOverlay() = Settings.canDrawOverlays(this)

    private fun refresh() {
        status.text = "Notificações: " + (if (hasNotif()) "concedida" else "pendente") +
            "\nSobrepor: " + (if (hasOverlay()) "concedida" else "pendente") + "\n\n"
    }

    private fun askNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && !hasNotif())
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    private fun askOverlay() {
        if (!hasOverlay())
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun openMenu() {
        if (!hasOverlay()) { askOverlay(); return }
        startService(Intent(this, OverlayService::class.java))
        moveTaskToBack(true)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r); refresh()
    }
}
