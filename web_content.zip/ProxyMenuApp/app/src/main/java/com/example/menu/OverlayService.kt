package com.example.menu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.TextView

class OverlayService : Service() {

    private var view: View? = null
    private lateinit var wm: WindowManager

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (view == null) show()
        notify("Tenha um ótimo dia!")   // troque a frase aqui
        return START_NOT_STICKY
    }

    private fun show() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        val box = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            setBackgroundColor(Color.BLACK)
            loadUrl("file:///android_asset/index.html")
        }
        box.addView(web, FrameLayout.LayoutParams(-1, -1))

        val close = TextView(this).apply {
            text = "✕"; textSize = 20f; setTextColor(Color.WHITE); setPadding(32, 16, 32, 16)
            setOnClickListener { stopSelf() }
        }
        box.addView(close, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))

        val lp = WindowManager.LayoutParams(
            (dm.widthPixels * 0.92).toInt(), (dm.heightPixels * 0.78).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        wm.addView(box, lp)
        view = box
    }

    private fun notify(text: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("msg", "Mensagens", NotificationManager.IMPORTANCE_DEFAULT))
        nm.notify(1, Notification.Builder(this, "msg")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Proxy Menu").setContentText(text).build())
    }

    override fun onDestroy() {
        view?.let { wm.removeView(it) }
        view = null
        super.onDestroy()
    }
}
