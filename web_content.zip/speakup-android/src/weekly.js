/* SpeakUp Academy — النطق + الحصيلة الأسبوعية + تقرير المعلم
   - محاولة النطق الناجحة تُحتسب عند بلوغ النطق الصحيح (>= 80% في البطاقات، >= 70% في الاختبار)
   - أول نطق ناجح للكلمة يضعها ضمن الكلمات المحفوظة
   - الأسبوع يبدأ السبت وينتهي الجمعة، والحد الأدنى 50 كلمة
   - التقرير يُرسل إلى المعلم عبر واتساب أو SMS (يفتح التطبيق والرسالة جاهزة)   */
(function () {
  'use strict';
  var WEEKLY_MIN = 50;
  var DEFAULT_TEACHER = '01095514405';
  var LOG = 'speakup_week_log', STATS = 'speakup_pron_stats', PREF = 'speakup_report_prefs';
  var DAY_NAMES = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];

  function jget(k, d) { try { var r = localStorage.getItem(k); return r ? JSON.parse(r) : d; } catch (e) { return d; } }
  function jset(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function $(id) { return document.getElementById(id); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function key(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function weekStart(d) { var x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() - ((x.getDay() + 1) % 7)); return x; }
  function weekDays(d) { var s = weekStart(d), a = []; for (var i = 0; i < 7; i++) { var x = new Date(s); x.setDate(s.getDate() + i); a.push(x); } return a; }
  function fmt(d) { return d.toLocaleDateString('ar-EG', { day: 'numeric', month: 'long' }); }
  function toast(m, t) { if (typeof window.showToast === 'function') window.showToast(m, t || 'info'); }
  function wordOf(id) { try { return dictionaryData.find(function (w) { return w.id === id; }); } catch (e) { return null; } }
  function esc(t) { return String(t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ---- السجل ---- */
  function logDay(k) { var l = jget(LOG, {}); l[k] = l[k] || { learned: [], pron: 0 }; return [l, l[k]]; }
  function addLearned(id) { var r = logDay(key(new Date())); if (r[1].learned.indexOf(id) < 0) r[1].learned.push(id); jset(LOG, r[0]); }
  function removeLearned(id) {
    var l = jget(LOG, {}), days = weekDays(new Date()).map(key);
    days.forEach(function (k) { if (l[k]) l[k].learned = l[k].learned.filter(function (x) { return x !== id; }); });
    jset(LOG, l);
  }
  function weekSummary(ref) {
    var l = jget(LOG, {}), days = weekDays(ref || new Date()), seen = {}, perDay = [], pron = 0, ids = [];
    days.forEach(function (d) {
      var e = l[key(d)] || { learned: [], pron: 0 }, c = 0;
      e.learned.forEach(function (id) { if (!seen[id]) { seen[id] = 1; ids.push(id); c++; } });
      pron += e.pron || 0; perDay.push({ d: d, learned: c, pron: e.pron || 0 });
    });
    return { days: days, perDay: perDay, learned: ids.length, ids: ids, pron: pron };
  }
  window.__weekSummary = weekSummary;
  window.__buildReport = function () { return buildMessage(); };
  window.__intl = function (n) { return intl(n); };

  /* ---- تسجيل محاولة النطق ---- */
  window.__recordPron = function (word, score, pass) {
    var w = null;
    try { w = dictionaryData.find(function (x) { return String(x.word).toLowerCase() === String(word).toLowerCase(); }); } catch (e) {}
    var stats = jget(STATS, {}), id = w ? w.id : word, st = stats[id] || { a: 0, s: 0 };
    st.a++;
    var ok = score >= (pass || 80);
    if (ok) {
      st.s++;
      var r = logDay(key(new Date())); r[1].pron = (r[1].pron || 0) + 1; jset(LOG, r[0]);
      if (w && typeof learnedWords !== 'undefined' && learnedWords.indexOf(w.id) < 0 && typeof window.toggleLearned === 'function') window.toggleLearned(w.id);
      setTimeout(function () {
        var s = weekSummary();
        toast('✅ محاولة نطق ناجحة! حفظت ' + s.learned + ' من ' + WEEKLY_MIN + ' كلمة هذا الأسبوع', 'success');
      }, 1300);
    }
    stats[id] = st; jset(STATS, stats);
    return { ok: ok, attempts: st.a, successes: st.s };
  };

  /* ---- النص + الإرسال ---- */
  function prefs() { return Object.assign({ teacher: DEFAULT_TEACHER, student: '' }, jget(PREF, {})); }
  function intl(num) { var d = String(num).replace(/\D/g, ''); if (d.indexOf('00') === 0) d = d.slice(2); else if (d.charAt(0) === '0') d = '20' + d.slice(1); return d; }
  function buildMessage() {
    var s = weekSummary(), p = prefs(), ok = s.learned >= WEEKLY_MIN;
    var words = s.ids.slice(0, 25).map(function (id) { var w = wordOf(id); return w ? w.word : ''; }).filter(Boolean).join('، ');
    var lines = ['📊 تقرير الأسبوع — SpeakUp Academy'];
    if (p.student) lines.push('👤 الطالب: ' + p.student);
    lines.push('🗓️ الفترة: ' + fmt(s.days[0]) + ' إلى ' + fmt(s.days[6]));
    lines.push('✅ الكلمات المحفوظة: ' + s.learned + ' (الحد الأدنى ' + WEEKLY_MIN + ')');
    lines.push('🎤 محاولات النطق الناجحة: ' + s.pron);
    lines.push(ok ? '🏆 الحالة: حقق الحد الأدنى الأسبوعي' : '⚠️ الحالة: متبقٍ ' + (WEEKLY_MIN - s.learned) + ' كلمة للوصول للحد الأدنى');
    if (words) lines.push('📝 الكلمات: ' + words + (s.ids.length > 25 ? ' ...' : ''));
    return lines.join('\n');
  }
  function savePrefs() { var p = { teacher: ($('rpTeacher') && $('rpTeacher').value.trim()) || DEFAULT_TEACHER, student: ($('rpStudent') && $('rpStudent').value.trim()) || '' }; jset(PREF, p); return p; }
  function openUrl(u) { window.location.href = u; }
  window.sendReportWhatsApp = function () { var p = savePrefs(); openUrl('https://wa.me/' + intl(p.teacher) + '?text=' + encodeURIComponent(buildMessage())); };
  window.sendReportSms = function () { var p = savePrefs(); openUrl('sms:+' + intl(p.teacher) + '?body=' + encodeURIComponent(buildMessage())); };
  window.copyReport = function () {
    var m = buildMessage();
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(m).then(function () { toast('تم نسخ التقرير 📋', 'success'); }, function () { toast('تعذّر النسخ'); });
    else toast('تعذّر النسخ');
  };

  /* ---- واجهة التقرير ---- */
  function render() {
    var s = weekSummary(), p = prefs(), pct = Math.min(100, Math.round(s.learned / WEEKLY_MIN * 100)), ok = s.learned >= WEEKLY_MIN;
    var max = Math.max(1, Math.max.apply(null, s.perDay.map(function (x) { return x.learned; })));
    var today = key(new Date());
    var bars = s.perDay.map(function (x, i) {
      return '<div class="wk-col' + (key(x.d) === today ? ' today' : '') + '"><span class="wk-n">' + x.learned + '</span><div class="wk-bar"><i style="height:' + Math.round(x.learned / max * 100) + '%"></i></div><span class="wk-d">' + DAY_NAMES[i] + '</span></div>';
    }).join('');
    $('reportBody').innerHTML =
      '<div class="wk-range">' + fmt(s.days[0]) + ' — ' + fmt(s.days[6]) + '</div>' +
      '<div class="wk-hero ' + (ok ? 'ok' : '') + '"><div class="wk-big">' + s.learned + '<small>/ ' + WEEKLY_MIN + '</small></div>' +
      '<div class="wk-sub">' + (ok ? '🏆 حققت الحد الأدنى الأسبوعي' : 'متبقٍ ' + (WEEKLY_MIN - s.learned) + ' كلمة للوصول للحد الأدنى') + '</div>' +
      '<div class="wk-track"><i style="width:' + pct + '%"></i></div></div>' +
      '<div class="wk-stats"><div><b>' + s.learned + '</b><span>كلمة محفوظة</span></div><div><b>' + s.pron + '</b><span>نطق ناجح</span></div></div>' +
      '<div class="wk-chart">' + bars + '</div>' +
      '<label class="wk-field"><span>اسم الطالب (يظهر في التقرير)</span><input id="rpStudent" type="text" placeholder="اختياري" value="' + esc(p.student) + '"></label>' +
      '<label class="wk-field"><span>رقم المعلم</span><input id="rpTeacher" type="tel" inputmode="tel" dir="ltr" value="' + esc(p.teacher) + '"></label>' +
      '<div class="sheet-actions">' +
      '<button class="btn-action" style="background:#25D366;color:#fff;" onclick="sendReportWhatsApp()"><i class="fa-brands fa-whatsapp"></i> إرسال عبر واتساب</button>' +
      '<button class="btn-action" style="background:var(--secondary);color:#fff;" onclick="sendReportSms()"><i class="fa-solid fa-message"></i> إرسال SMS</button>' +
      '<button class="btn-action" style="background:#e5eaf3;color:var(--primary-dark);" onclick="copyReport()"><i class="fa-solid fa-copy"></i> نسخ</button></div>' +
      '<p class="sheet-hint">يفتح التطبيق المختار والتقرير جاهز؛ اضغط «إرسال» ليصل للمعلم.</p>';
  }
  window.openWeeklyReport = function () {
    render(); $('reportOverlay').classList.add('open');
    document.querySelectorAll('.bn-item').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-mode') === 'report'); });
  };
  window.closeWeeklyReport = function () {
    savePrefs(); $('reportOverlay').classList.remove('open');
    var m = 'dict'; try { m = currentMode; } catch (e) {}
    document.querySelectorAll('.bn-item').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-mode') === m); });
  };

  /* ---- ربط الدوال الأصلية ---- */
  window.addEventListener('load', function () {
    var origToggle = window.toggleLearned;
    if (typeof origToggle === 'function') {
      window.toggleLearned = function (id) {
        var was = false; try { was = learnedWords.indexOf(id) > -1; } catch (e) {}
        origToggle(id);
        var now = false; try { now = learnedWords.indexOf(id) > -1; } catch (e) {}
        if (now && !was) { addLearned(id); setTimeout(function () { toast('📈 هذا الأسبوع: ' + weekSummary().learned + ' / ' + WEEKLY_MIN + ' كلمة', 'info'); }, 1600); }
        if (!now && was) removeLearned(id);
      };
    }
    var origStart = window.startPronunciationCheck, wordByIdx = {};
    if (typeof origStart === 'function') window.startPronunciationCheck = function (index, word) { wordByIdx[index] = word; return origStart(index, word); };
    var origRender = window.renderPronunciationResult;
    if (typeof origRender === 'function') {
      window.renderPronunciationResult = function (index, score, transcript) {
        origRender(index, score, transcript);
        var word = wordByIdx[index]; if (!word) return;
        var r = window.__recordPron(word, score, 80), box = $('pronResult_' + index);
        if (box) box.insertAdjacentHTML('beforeend', '<div class="pron-attempts ' + (r.ok ? 'ok' : '') + '">' + (r.ok ? '✅ محاولة ناجحة' : '❌ لم يصل للنطق الصحيح بعد') + ' — ناجحة: ' + r.successes + ' من ' + r.attempts + ' محاولة</div>');
      };
    }
    // نقر زر السجل من إشعار الأحد/الجمعة
    window.addEventListener('speakup:openreport', window.openWeeklyReport);
  });
})();
