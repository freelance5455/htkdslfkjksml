/* SpeakUp Academy — طبقة التكامل مع أندرويد (Capacitor)
   - جسر النطق (TextToSpeech) وجسر التعرف على الصوت (SpeechRecognition)
   - الإشعارات اليومية: حفظ + مراجعة + رسالتان تشجيعيتان
   - التنقل السفلي، زر الرجوع، شريط الحالة                                   */
(function () {
  'use strict';
  var C = window.Capacitor;
  var isNative = !!(C && typeof C.isNativePlatform === 'function' && C.isNativePlatform());
  if (isNative) document.documentElement.classList.add('is-native');

  function plugin(name) {
    try { return isNative ? C.registerPlugin(name) : null; } catch (e) { console.warn('plugin', name, e); return null; }
  }
  var LN = plugin('LocalNotifications');
  var TTS = plugin('TextToSpeech');
  var SR = plugin('SpeechRecognition');
  var AppPlugin = plugin('App');
  var StatusBar = plugin('StatusBar');
  var Splash = plugin('SplashScreen');

  /* ---------- 1) النطق: يملأ الجسر الذي ينتظره التطبيق (window.AndroidTTS) ---------- */
  if (TTS) {
    window.AndroidTTS = {
      speak: function (text, lang) {
        TTS.speak({ text: String(text), lang: lang || 'en-US', rate: 0.85, pitch: 1.0, volume: 1.0, category: 'ambient' })
          .catch(function (e) { console.warn('TTS error', e); });
      }
    };
  }

  /* ---------- 2) التعرف على الصوت (تقييم النطق) ---------- */
  if (SR) {
    var NativeSpeechRecognition = function () {
      this.lang = 'en-US'; this.interimResults = false; this.maxAlternatives = 1;
      this.onresult = null; this.onerror = null; this.onend = null;
    };
    NativeSpeechRecognition.prototype._err = function (code) {
      if (typeof this.onerror === 'function') this.onerror({ error: code });
    };
    NativeSpeechRecognition.prototype.start = function () {
      var self = this;
      (async function () {
        try {
          var av = await SR.available();
          if (!av || !av.available) { self._err('service-not-allowed'); return; }
          var perm = await SR.checkPermissions();
          if (perm.speechRecognition !== 'granted') perm = await SR.requestPermissions();
          if (perm.speechRecognition !== 'granted') { self._err('not-allowed'); return; }
          var res = await SR.start({ language: self.lang || 'en-US', maxResults: 1, partialResults: false, popup: false });
          var t = res && res.matches && res.matches[0];
          if (t) { if (typeof self.onresult === 'function') self.onresult({ results: [[{ transcript: t, confidence: 1 }]] }); }
          else self._err('no-speech');
        } catch (e) {
          var msg = String((e && e.message) || e || '').toLowerCase();
          self._err(msg.indexOf('permission') > -1 ? 'not-allowed' : (msg.indexOf('match') > -1 || msg.indexOf('speech') > -1 || msg.indexOf('timeout') > -1 ? 'no-speech' : 'error'));
        } finally {
          if (typeof self.onend === 'function') self.onend();
        }
      })();
    };
    NativeSpeechRecognition.prototype.stop = NativeSpeechRecognition.prototype.abort = function () { try { SR.stop().catch(function () {}); } catch (e) {} };
    window.SpeechRecognition = NativeSpeechRecognition;
  }

  /* ---------- 3) الإشعارات ---------- */
  var KEY = 'speakup_notif_settings';
  var DEFAULTS = { enabled: true, memorize: '09:00', cheer1: '13:00', review: '18:00', cheer2: '21:00' };
  var DAYS_AHEAD = 28;   // نافذة متجددة: تُعاد جدولتها عند كل فتح للتطبيق

  var MEMORIZE = [
    ['📖 حان وقت حفظ كلماتك', 'هدفك 10 كلمات اليوم لتتجاوز 50 كلمة هذا الأسبوع. ابدأ الآن!'],
    ['✨ كلمات اليوم جاهزة', 'خصّص دقائق قليلة لحفظ كلمات جديدة وقوِّ رصيدك اللغوي.'],
    ['☀️ ابدأ يومك بالإنجليزية', 'كلمة بعد كلمة تبني لغتك. افتح التطبيق واحفظ كلمات اليوم.'],
    ['🎯 هدفك اليوم: 10 كلمات', 'أنت قادر على إنجازه بسهولة. هيا نبدأ!'],
    ['🚀 خطوة جديدة اليوم', 'حفظ كلمات اليوم يقرّبك من الطلاقة. افتح التطبيق الآن.'],
    ['🌟 وقت التعلّم', 'خمس دقائق من التركيز تكفي لحفظ كلمات جديدة.'],
    ['📚 لا تؤجّل كلمات اليوم', 'ابدأ الآن وستشعر بالفخر بإنجازك قبل نهاية اليوم.']
  ];
  var REVIEW = [
    ['🔁 وقت المراجعة', 'راجع كلمات اليوم الآن؛ المراجعة هي سرّ التثبيت.'],
    ['🧠 هل ثبتت الكلمات؟', 'جرّب اختبارًا سريعًا وتأكّد من حفظك.'],
    ['⏳ مراجعة سريعة', 'دقيقتان من المراجعة تضاعفان ما تتذكّره.'],
    ['✅ ثبّت ما حفظته', 'افتح الاختبارات وراجع كلماتك قبل أن تنساها.'],
    ['💡 راجع وتفوّق', 'تكرار الكلمات هو الطريق لإتقانها. هيا نراجع!'],
    ['🎓 مراجعة المساء', 'اختبر نفسك الآن وتحقّق من تقدّمك.'],
    ['🔔 موعد المراجعة اليومية', 'كلماتك تنتظرك لمراجعة سريعة ثم ترتاح.']
  ];
  var CHEER = [
    ['🌟 أنت تتقدّم كل يوم', 'كل كلمة جديدة خطوة نحو الطلاقة. استمر!'],
    ['💪 أحسنت الاستمرار', 'الاستمرارية أهم من السرعة، وأنت على الطريق الصحيح.'],
    ['🏆 فخورون بمجهودك', 'تعلّم لغة جديدة إنجاز كبير. واصل بثقة!'],
    ['🌱 كل يوم تنمو', 'ما تتعلّمه اليوم سيخدمك طوال حياتك.'],
    ['🔥 حافظ على حماسك', 'لا تتوقف الآن، أنت أقرب للهدف مما تظن.'],
    ['😊 رائع ما تفعله', 'خطوة صغيرة كل يوم تصنع فرقًا كبيرًا.'],
    ['🚀 نحو إتقان الإنجليزية', 'أنت تبني مستقبلك كلمة بعد كلمة.'],
    ['🎉 تعلّمك يستحق الاحتفال', 'تذكّر كم كلمة صارت لديك الآن. ما أروعك!'],
    ['🧩 الصبر مفتاح الإتقان', 'لا تقلق من الخطأ، فهو جزء من التعلّم.'],
    ['⭐ أنت أفضل من الأمس', 'تقدّم صغير اليوم أفضل من لا شيء. استمر!'],
    ['🎯 ركّز على هدفك', 'الإنجليزية تفتح لك أبوابًا كثيرة. لا تتوقف.'],
    ['🌈 يوم جميل للتعلّم', 'افتح التطبيق وأضف كلمة جديدة إلى رصيدك.'],
    ['👏 تستحق التقدير', 'مثابرتك ملهمة. كمّل وسترى النتيجة قريبًا.'],
    ['💎 كل كلمة كنز', 'اجمع كلمات اليوم وزد ثروتك اللغوية.']
  ];

  function loadSettings() {
    try { var raw = localStorage.getItem(KEY); return Object.assign({}, DEFAULTS, raw ? JSON.parse(raw) : {}); }
    catch (e) { return Object.assign({}, DEFAULTS); }
  }
  function storeSettings(s) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) {} }
  function hm(str) { var p = String(str || '').split(':'); return [Math.min(23, Math.max(0, +p[0] || 0)), Math.min(59, Math.max(0, +p[1] || 0))]; }

  async function ensurePermission(askIfNeeded) {
    if (!LN) return false;
    try {
      var p = await LN.checkPermissions();
      if (p.display === 'granted') return true;
      if (!askIfNeeded || p.display === 'denied') return false;
      p = await LN.requestPermissions();
      return p.display === 'granted';
    } catch (e) { return false; }
  }

  async function createChannels() {
    try {
      await LN.createChannel({ id: 'reminders', name: 'تذكيرات الحفظ والمراجعة', description: 'تذكير يومي بموعد الحفظ والمراجعة', importance: 4, visibility: 1, vibration: true, lights: true, lightColor: '#10b981' });
      await LN.createChannel({ id: 'cheers', name: 'رسائل التشجيع', description: 'رسائل تحفيزية للطالب', importance: 3, visibility: 1, vibration: true });
    } catch (e) { console.warn('channels', e); }
  }

  var scheduling = false;
  async function rescheduleNotifications(force) {
    if (!LN || scheduling) return;
    scheduling = true;
    try {
      var s = loadSettings();
      var today = new Date();
      var dayKey = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
      var goalDone = false;
      try { goalDone = (typeof getDailyProgress === 'function') && getDailyProgress().count >= 10; } catch (e) {}
      var sig = JSON.stringify(s) + '|' + dayKey + '|' + goalDone;
      if (!force && localStorage.getItem('speakup_notif_sig') === sig) return;

      var pending = await LN.getPending();
      if (pending.notifications && pending.notifications.length) {
        await LN.cancel({ notifications: pending.notifications.map(function (n) { return { id: n.id }; }) });
      }
      if (!s.enabled) { localStorage.setItem('speakup_notif_sig', sig); return; }
      if (!(await ensurePermission(false))) return;
      await createChannels();

      var slots = [
        { n: 1, time: s.memorize, pool: MEMORIZE, type: 'memorize', channel: 'reminders' },
        { n: 2, time: s.cheer1, pool: CHEER, type: 'cheer', channel: 'cheers', off: 0 },
        { n: 3, time: s.review, pool: REVIEW, type: 'review', channel: 'reminders' },
        { n: 4, time: s.cheer2, pool: CHEER, type: 'cheer', channel: 'cheers', off: 1 }
      ];
      var epochDay = Math.floor(new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime() / 86400000);
      var list = [], now = Date.now();
      for (var d = 0; d < DAYS_AHEAD; d++) {
        for (var i = 0; i < slots.length; i++) {
          var sl = slots[i], t = hm(sl.time);
          var at = new Date(today.getFullYear(), today.getMonth(), today.getDate() + d, t[0], t[1], 0, 0);
          if (at.getTime() < now + 20000) continue;
          if (d === 0 && sl.type === 'memorize' && goalDone) continue;
          var idx = sl.type === 'cheer' ? ((epochDay + d) * 2 + sl.off) : (epochDay + d);
          var msg = sl.pool[idx % sl.pool.length];
          list.push({
            id: 1000 + d * 10 + sl.n, title: msg[0], body: msg[1],
            schedule: { at: at, allowWhileIdle: true }, channelId: sl.channel,
            smallIcon: 'ic_stat_notify', iconColor: '#0E264B', extra: { type: sl.type }
          });
        }
      }
      for (var w = 0; w < 4; w++) {
        var fri = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 20, 0, 0, 0);
        fri.setDate(fri.getDate() + ((5 - fri.getDay() + 7) % 7) + w * 7);
        if (fri.getTime() < now + 20000) continue;
        list.push({ id: 5000 + w, title: '📊 موعد تقرير الأسبوع', body: 'أرسل تقريرك الأسبوعي للمعلم الآن (الحد الأدنى 50 كلمة).',
          schedule: { at: fri, allowWhileIdle: true }, channelId: 'reminders', smallIcon: 'ic_stat_notify', iconColor: '#0E264B', extra: { type: 'report' } });
      }
      if (list.length) await LN.schedule({ notifications: list });
      localStorage.setItem('speakup_notif_sig', sig);
    } catch (e) { console.warn('schedule error', e); }
    finally { scheduling = false; }
  }

  async function testNotificationNow() {
    if (!isNative || !LN) { toast('الإشعارات تعمل داخل تطبيق أندرويد فقط'); return; }
    if (!(await ensurePermission(true))) { toast('فعّل إذن الإشعارات من إعدادات الجهاز أولاً'); return; }
    await createChannels();
    var m = CHEER[Math.floor(Math.random() * CHEER.length)];
    try {
      await LN.schedule({ notifications: [{ id: 999, title: m[0], body: m[1], channelId: 'cheers', smallIcon: 'ic_stat_notify', iconColor: '#0E264B',
        schedule: { at: new Date(Date.now() + 3000), allowWhileIdle: true }, extra: { type: 'cheer' } }] });
      toast('سيصلك إشعار تجريبي خلال ثوانٍ ✅');
    } catch (e) { toast('تعذّر إرسال الإشعار التجريبي'); }
  }

  /* ---------- 4) واجهة إعدادات التذكير ---------- */
  function $(id) { return document.getElementById(id); }
  function curMode() { try { return currentMode; } catch (e) { return 'dict'; } }  // let عام في السكربت الرئيسي
  function toast(msg) { if (typeof window.showToast === 'function') window.showToast(msg, 'info'); }

  function syncRowsState() { var on = $('notifMaster').checked; $('notifRows').classList.toggle('disabled', !on); }

  async function openReminderSettings() {
    var s = loadSettings();
    $('notifMaster').checked = !!s.enabled;
    $('timeMemorize').value = s.memorize; $('timeCheer1').value = s.cheer1;
    $('timeReview').value = s.review; $('timeCheer2').value = s.cheer2;
    syncRowsState();
    var note = $('sheetNote'); note.classList.remove('show');
    if (!isNative) { note.textContent = 'الإشعارات المجدولة تعمل داخل تطبيق أندرويد (APK) فقط. يمكنك حفظ المواعيد هنا وستُفعَّل عند التثبيت.'; note.classList.add('show'); }
    else if (LN) {
      try { var p = await LN.checkPermissions(); if (p.display === 'denied') { note.textContent = 'إذن الإشعارات مغلق. افتح إعدادات الجهاز ← التطبيقات ← SpeakUp Academy ← الإشعارات وفعّلها.'; note.classList.add('show'); } } catch (e) {}
    }
    $('settingsOverlay').classList.add('open');
    setActiveNav('settings');
  }
  function closeReminderSettings() {
    $('settingsOverlay').classList.remove('open');
    setActiveNav(curMode());
  }
  async function saveReminderSettings() {
    var s = {
      enabled: $('notifMaster').checked, memorize: $('timeMemorize').value || DEFAULTS.memorize,
      cheer1: $('timeCheer1').value || DEFAULTS.cheer1, review: $('timeReview').value || DEFAULTS.review,
      cheer2: $('timeCheer2').value || DEFAULTS.cheer2
    };
    storeSettings(s);
    if (isNative && s.enabled) {
      var ok = await ensurePermission(true);
      if (!ok) { toast('لم يُمنح إذن الإشعارات. فعّله من إعدادات الجهاز'); return; }
    }
    await rescheduleNotifications(true);
    closeReminderSettings();
    toast(s.enabled ? '✅ تم حفظ التذكيرات وجدولتها' : 'تم إيقاف التذكيرات');
  }

  window.openReminderSettings = openReminderSettings;
  window.closeReminderSettings = closeReminderSettings;
  window.saveReminderSettings = saveReminderSettings;
  window.testNotificationNow = testNotificationNow;

  /* ---------- 5) شريط التنقل وزر الرجوع ---------- */
  function setActiveNav(mode) {
    document.querySelectorAll('.bn-item').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-mode') === mode); });
  }

  window.addEventListener('load', function () {
    var master = $('notifMaster'); if (master) master.addEventListener('change', syncRowsState);

    // مزامنة الشريط السفلي مع التبويبات الأصلية
    if (typeof window.switchMode === 'function') {
      var orig = window.switchMode;
      window.switchMode = function (m) { try { orig(m); } finally { setActiveNav(m); window.scrollTo({ top: 0 }); } };
    }

    if (!isNative) return;
    if (StatusBar) { StatusBar.setBackgroundColor({ color: '#05132A' }).catch(function () {}); StatusBar.setStyle({ style: 'DARK' }).catch(function () {}); }
    if (Splash) setTimeout(function () { Splash.hide().catch(function () {}); }, 300);

    // الجدولة عند الفتح (تطلب الإذن مرة واحدة في أندرويد 13+)
    (async function () {
      var s = loadSettings();
      if (s.enabled) { await ensurePermission(true); await rescheduleNotifications(false); }
    })();

    if (LN) LN.addListener('localNotificationActionPerformed', function (e) {
      var type = e && e.notification && e.notification.extra && e.notification.extra.type;
      if (type === 'report' && window.openWeeklyReport) return window.openWeeklyReport();
      if (typeof window.switchMode === 'function') window.switchMode(type === 'review' ? 'quiz' : 'dict');
    });

    if (AppPlugin) {
      AppPlugin.addListener('resume', function () { rescheduleNotifications(false); });
      AppPlugin.addListener('backButton', function () {
        var rep = $('reportOverlay'); if (rep && rep.classList.contains('open')) return window.closeWeeklyReport();
        var sheet = $('settingsOverlay'), exam = $('examModalOverlay'), daily = $('dailyReminderOverlay');
        if (sheet && sheet.classList.contains('open')) return closeReminderSettings();
        if (exam && exam.classList.contains('open') && typeof window.closeWordExam === 'function') return window.closeWordExam();
        if (daily && daily.classList.contains('open') && typeof window.closeDailyReminder === 'function') return window.closeDailyReminder(false);
        if (curMode() !== 'dict' && typeof window.switchMode === 'function') return window.switchMode('dict');
        AppPlugin.minimizeApp().catch(function () {});
      });
    }
  });
})();
