// يجمع ملفات الواجهة في مجلد www (بما فيها الخطوط والأيقونات محلياً) ليعمل التطبيق بدون إنترنت.
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const www = path.join(root, 'www');
const nm = (...p) => path.join(root, 'node_modules', ...p);

fs.rmSync(www, { recursive: true, force: true });
fs.mkdirSync(path.join(www, 'vendor', 'fonts'), { recursive: true });

for (const f of ['index.html', 'native.js', 'native.css', 'weekly.js']) {
  fs.copyFileSync(path.join(root, 'src', f), path.join(www, f));
}

// Font Awesome (css + webfonts)
const faDst = path.join(www, 'vendor', 'fontawesome');
fs.mkdirSync(path.join(faDst, 'css'), { recursive: true });
fs.mkdirSync(path.join(faDst, 'webfonts'), { recursive: true });
fs.copyFileSync(nm('@fortawesome', 'fontawesome-free', 'css', 'all.min.css'), path.join(faDst, 'css', 'all.min.css'));
for (const f of fs.readdirSync(nm('@fortawesome', 'fontawesome-free', 'webfonts'))) {
  if (f.endsWith('.woff2')) fs.copyFileSync(nm('@fortawesome', 'fontawesome-free', 'webfonts', f), path.join(faDst, 'webfonts', f));
}

// Cairo (عربي + لاتيني)
const weights = [400, 600, 700, 800];
let css = '';
for (const w of weights) {
  for (const [subset, range] of [
    ['arabic', 'U+0600-06FF,U+0750-077F,U+0870-088E,U+0890-0891,U+0897-08E1,U+08E3-08FF,U+200C-200E,U+2010-2011,U+204F,U+2E41,U+FB50-FDFF,U+FE70-FE74,U+FE76-FEFC'],
    ['latin', 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD'],
  ]) {
    const file = `cairo-${subset}-${w}-normal.woff2`;
    fs.copyFileSync(nm('@fontsource', 'cairo', 'files', file), path.join(www, 'vendor', 'fonts', file));
    css += `@font-face{font-family:'Cairo';font-style:normal;font-display:swap;font-weight:${w};src:url(${file}) format('woff2');unicode-range:${range};}\n`;
  }
}
fs.writeFileSync(path.join(www, 'vendor', 'fonts', 'cairo.css'), css);

// Font Awesome 6 ينتظر ../webfonts/ نسبةً لملف css، وهذا ما وفّرناه.
console.log('www ready:', fs.readdirSync(www).join(', '));
