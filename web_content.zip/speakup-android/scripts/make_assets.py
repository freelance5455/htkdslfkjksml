"""يولّد أيقونة التطبيق (قديمة + Adaptive + Monochrome)، أيقونة الإشعار، وشاشة البداية بكل الكثافات."""
import os
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops

RES = os.path.join(os.path.dirname(__file__), '..', 'android', 'app', 'src', 'main', 'res')
OUT = os.path.join(os.path.dirname(__file__), '..', 'resources')
os.makedirs(OUT, exist_ok=True)
S = 1024  # لوحة العمل

NAVY_D, NAVY, BLUE = (5, 19, 42), (14, 38, 75), (28, 79, 138)
GREEN, GREEN_L, GOLD = (16, 185, 129), (52, 211, 153), (245, 158, 11)

def lerp(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

def gradient_bg(size):
    """تدرّج قطري كحلي ← أزرق مع إضاءة خفيفة."""
    im = Image.new('RGB', (size, size))
    px = im.load()
    for y in range(size):
        for x in range(size):
            t = (x * 0.35 + y * 0.65) / size
            c = lerp(NAVY_D, NAVY, min(1, t * 1.6)) if t < .62 else lerp(NAVY, BLUE, (t - .62) / .38)
            px[x, y] = c
    glow = Image.new('L', (size, size), 0)
    ImageDraw.Draw(glow).ellipse((size * .05, size * .02, size * .75, size * .62), fill=70)
    glow = glow.filter(ImageFilter.GaussianBlur(size * .12))
    im.paste(Image.new('RGB', (size, size), (60, 120, 200)), (0, 0), glow)
    return im

def masks():
    """يرسم فقاعة الكلام والسهم كأقنعة (4x للنعومة) على لوحة 1024."""
    k = 3
    W = S * k
    bubble = Image.new('L', (W, W), 0)
    d = ImageDraw.Draw(bubble)
    x0, y0, x1, y1 = 232 * k, 262 * k, 792 * k, 662 * k
    d.rounded_rectangle((x0, y0, x1, y1), radius=120 * k, fill=255)
    d.polygon([(340 * k, 640 * k), (470 * k, 640 * k), (318 * k, 790 * k)], fill=255)   # ذيل الفقاعة
    arrow = Image.new('L', (W, W), 0)
    a = ImageDraw.Draw(arrow)
    cx = 512 * k
    pts = [(cx, 345 * k), (cx + 118 * k, 470 * k), (cx + 46 * k, 470 * k), (cx + 46 * k, 585 * k),
           (cx - 46 * k, 585 * k), (cx - 46 * k, 470 * k), (cx - 118 * k, 470 * k)]
    a.polygon(pts, fill=255)
    a.line(pts + [pts[0]], fill=255, width=26 * k, joint='curve')                         # زوايا مستديرة
    for p in pts: a.ellipse((p[0] - 13 * k, p[1] - 13 * k, p[0] + 13 * k, p[1] + 13 * k), fill=255)
    return bubble.resize((S, S), Image.LANCZOS), arrow.resize((S, S), Image.LANCZOS)

BUBBLE, ARROW = masks()

def foreground():
    """طبقة أمامية شفافة: فقاعة بيضاء + سهم أخضر + نقطة ذهبية."""
    im = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    shadow = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    sh = Image.new('L', (S, S), 0); sh.paste(BUBBLE, (0, 14)); sh = sh.filter(ImageFilter.GaussianBlur(16))
    shadow.paste(Image.new('RGBA', (S, S), (0, 10, 30, 110)), (0, 0), sh)
    im = Image.alpha_composite(im, shadow)
    im.paste(Image.new('RGBA', (S, S), (255, 255, 255, 255)), (0, 0), BUBBLE)
    grad = Image.new('RGBA', (S, S))
    gp = grad.load()
    for y in range(S):
        c = lerp(GREEN_L, GREEN, min(1, max(0, (y - 340) / 250)))
        for x in range(S): gp[x, y] = c + (255,)
    im.paste(grad, (0, 0), ARROW)
    d = ImageDraw.Draw(im)
    d.ellipse((716, 214, 836, 334), fill=(255, 255, 255, 255))
    d.ellipse((730, 228, 822, 320), fill=GOLD + (255,))
    return im

def silhouette():
    """قناع أبيض (فقاعة بسهم مفرّغ) للأيقونة الأحادية وأيقونة الإشعار."""
    alpha = ImageChops.subtract(BUBBLE, ARROW)
    im = Image.new('RGBA', (S, S), (255, 255, 255, 0))
    im.putalpha(alpha)
    return im

def crop_to_content(im, pad=0.08):
    bbox = im.getchannel('A').getbbox()
    c = im.crop(bbox)
    side = int(max(c.size) * (1 + pad * 2))
    out = Image.new('RGBA', (side, side), (0, 0, 0, 0))
    out.paste(c, ((side - c.width) // 2, (side - c.height) // 2))
    return out

def legacy_icon(size, round_=False):
    bg = gradient_bg(1024).convert('RGBA')
    fg = foreground().resize((1024, 1024), Image.LANCZOS)
    # الفقاعة تمتد خارج المنطقة الآمنة قليلاً في الأيقونة القديمة فنكبّرها
    full = Image.alpha_composite(bg, fg)
    full = full.crop((60, 60, 964, 964)).resize((1024, 1024), Image.LANCZOS)
    mask = Image.new('L', (1024, 1024), 0)
    md = ImageDraw.Draw(mask)
    if round_: md.ellipse((0, 0, 1023, 1023), fill=255)
    else: md.rounded_rectangle((0, 0, 1023, 1023), radius=230, fill=255)
    full.putalpha(mask)
    return full.resize((size, size), Image.LANCZOS)

# --- 1) أيقونات الإطلاق ---
dens = {'mdpi': 1, 'hdpi': 1.5, 'xhdpi': 2, 'xxhdpi': 3, 'xxxhdpi': 4}
fg_full, mono_full = foreground(), silhouette()
for name, m in dens.items():
    d = os.path.join(RES, f'mipmap-{name}')
    legacy_icon(int(48 * m)).save(os.path.join(d, 'ic_launcher.png'))
    legacy_icon(int(48 * m), True).save(os.path.join(d, 'ic_launcher_round.png'))
    fg_full.resize((int(108 * m), int(108 * m)), Image.LANCZOS).save(os.path.join(d, 'ic_launcher_foreground.png'))
    mono_full.resize((int(108 * m), int(108 * m)), Image.LANCZOS).save(os.path.join(d, 'ic_launcher_monochrome.png'))

# --- 2) أيقونة الإشعار (أبيض على شفاف) ---
notif = crop_to_content(silhouette(), 0.06)
for name, m in dens.items():
    d = os.path.join(RES, f'drawable-{name}'); os.makedirs(d, exist_ok=True)
    notif.resize((int(24 * m), int(24 * m)), Image.LANCZOS).save(os.path.join(d, 'ic_stat_notify.png'))

# --- 3) شاشة البداية ---
def splash(w, h):
    bg = gradient_bg(max(w, h)).crop((0, 0, w, h)).convert('RGBA')
    icon_side = int(min(w, h) * (0.34 if h > w else 0.30))
    ic = legacy_icon(icon_side * 2)
    ic = ic.resize((icon_side, icon_side), Image.LANCZOS)
    cx, cy = w // 2, int(h * 0.44)
    sh = Image.new('L', (w, h), 0)
    ImageDraw.Draw(sh).rounded_rectangle((cx - icon_side // 2, cy - icon_side // 2 + 10, cx + icon_side // 2, cy + icon_side // 2 + 10), radius=icon_side // 4, fill=120)
    sh = sh.filter(ImageFilter.GaussianBlur(icon_side * .08))
    bg.paste(Image.new('RGBA', (w, h), (0, 0, 0, 255)), (0, 0), sh)
    bg.paste(ic, (cx - icon_side // 2, cy - icon_side // 2), ic)
    try:
        f1 = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', max(18, icon_side // 6))
        f2 = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', max(12, icon_side // 11))
        d = ImageDraw.Draw(bg)
        ty = cy + icon_side // 2 + icon_side // 5
        d.text((cx, ty), 'SpeakUp', font=f1, fill=(255, 255, 255, 255), anchor='mm')
        d.text((cx, ty + icon_side // 4), 'A C A D E M Y', font=f2, fill=(160, 190, 230, 255), anchor='mm')
    except Exception as e:
        print('font skipped', e)
    return bg.convert('RGB')

for root, _, files in os.walk(RES):
    if 'splash.png' in files:
        p = os.path.join(root, 'splash.png')
        w, h = Image.open(p).size
        splash(w, h).save(p)

# --- 4) ملفات للمتجر / المعاينة ---
legacy_icon(1024).save(os.path.join(OUT, 'icon-1024.png'))
legacy_icon(512).save(os.path.join(OUT, 'icon-512.png'))
splash(1080, 1920).resize((540, 960)).save(os.path.join(OUT, 'splash-preview.png'))
print('assets done')
