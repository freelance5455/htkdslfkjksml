# Nexus Graph — mobile OSINT investigation tool

Open `index.html` in a browser (Chrome/Safari). No build step.

## Investigation pipeline

INPUT → NORMALIZE → SOURCE CONNECTORS → DEDUPE → ENTITIES → RELATIONSHIPS → EVIDENCE → GRAPH

### Sources (`sources/`)

Modular connectors: IP (geo, RDAP, PTR), DNS, RDAP domain, URL parse, phone normalize, email parse, username/GitHub, Wikipedia person, Demo.

### Engine (`engine/`)

- `investigation.js` — main pipeline
- `dedupe.js` — canonical IDs
- `cache.js` — 6h local cache
- `rateLimit.js` — per-analysis + sliding window limits
- `apiKeys.js` — keys in localStorage only

### Lookup

1. Tap 🔍 Lookup
2. Enter IP / domain / email / phone / username / name
3. Depth 1–3, optional Demo mode
4. Analyze → auto-add or Review checklist

### Expand

Long-press node → **Expand** re-analyzes that entity.

### Data Sources

Settings → enable/disable connectors, API keys (stored only in browser).

### Demo

Enable **Demo** and query `example.test` or `203.0.113.10` (RFC documentation ranges).

### Existing features

Projects, graph, edges, Timeline, Intelligence layouts, Advanced Search (`type:email status:confirmed`), Evidence, import/export, localStorage.
