/**
 * Nexus Graph v3 — double-tap add, photos, LOD, curved edges, drawer, fixed PNG
 */
(function () {
  'use strict';

  const STORAGE_KEY = 'nexus_graph_v3';
  const RECENT_KEY = 'nexus_graph_recent_v3';
  const SETTINGS_KEY = 'nexus_graph_settings_v3';
  const MAX_PHOTO_SIZE = 720; // max edge for stored photos (balance quality/size)
  const LOD_THRESHOLD = 0.4;

  const NODE_TYPES = {
    person:       { label: 'Человек',     svg: '<circle cx="12" cy="7.5" r="3.8"/><path d="M5.5 20.5v-1.2c0-3.2 2.9-5.8 6.5-5.8s6.5 2.6 6.5 5.8v1.2"/>' },
    username:     { label: 'Username',    svg: '<circle cx="12" cy="8" r="3.5"/><path d="M5 20v-1c0-3.1 3.1-5.5 7-5.5s7 2.4 7 5.5v1"/><path d="M17 6.5h3M18.5 5v3"/>' },
    email:        { label: 'Email',       svg: '<rect x="3" y="6" width="18" height="13" rx="1"/><path d="M3 7.2l9 6.3 9-6.3"/>' },
    phone:        { label: 'Телефон',     svg: '<path d="M7.2 3.5h3.2l1 4.2-2.4 1.5c.9 1.9 2.4 3.4 4.3 4.3l1.5-2.4 4.2 1v3.1c0 1.1-.9 2-2 2C8.6 17.2 3.5 12.1 3.5 5.5c0-1.1.9-2 2-2h1.7z"/>' },
    domain:       { label: 'Домен',       svg: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17"/><ellipse cx="12" cy="12" rx="3.5" ry="8.5"/>' },
    ip:           { label: 'IP',          svg: '<rect x="3.5" y="4.5" width="17" height="15" rx="1.5"/><path d="M7 9h10M7 12.5h8M7 16h5"/>' },
    url:          { label: 'URL',         svg: '<path d="M9.5 14.5a3.2 3.2 0 0 0 4.5 0l1.8-1.8a3.2 3.2 0 1 0-4.5-4.5l-.9.9"/><path d="M14.5 9.5a3.2 3.2 0 0 0-4.5 0L8.2 11.3a3.2 3.2 0 1 0 4.5 4.5l.9-.9"/>' },
    organization: { label: 'Организация', svg: '<path d="M4 21V9.5L12 4l8 5.5V21"/><path d="M9 21v-5.5h6V21"/><path d="M9 11.5h.01M12 11.5h.01M15 11.5h.01"/>' },
    social:       { label: 'Соц. сеть',   svg: '<path d="M4.5 5.5h15a1.5 1.5 0 0 1 1.5 1.5v8a1.5 1.5 0 0 1-1.5 1.5H10l-3.5 3v-3H4.5A1.5 1.5 0 0 1 3 15V7a1.5 1.5 0 0 1 1.5-1.5z"/>' },
    location:     { label: 'Локация',     svg: '<path d="M12 21s-6.5-5-6.5-10.5a6.5 6.5 0 1 1 13 0C18.5 16 12 21 12 21z"/><circle cx="12" cy="10.5" r="2.3"/>' },
    document:     { label: 'Документ',    svg: '<path d="M7 3h8l4 4v13H7z"/><path d="M15 3v4h4"/><path d="M9.5 12h5M9.5 15.5h5"/>' },
    photo:        { label: 'Фото',        svg: '<rect x="3" y="5.5" width="18" height="13.5" rx="1"/><circle cx="9" cy="11" r="2"/><path d="M3 16l4.5-3.5 2.5 2 3-2.5 5 4"/>' },
    image:        { label: 'Image',       svg: '<rect x="3" y="5.5" width="18" height="13.5" rx="1"/><circle cx="9" cy="11" r="2"/><path d="M3 16l4.5-3.5 2.5 2 3-2.5 5 4"/>' },
    file:         { label: 'File',        svg: '<path d="M6.5 3h8l4 4v14h-12z"/><path d="M14.5 3v4h4"/>' },
    server:       { label: 'Сервер',      svg: '<rect x="4" y="3.5" width="16" height="5" rx="1"/><rect x="4" y="10" width="16" height="5" rx="1"/><rect x="4" y="16.5" width="16" height="4" rx="1"/><circle cx="7" cy="6" r="0.8"/><circle cx="7" cy="12.5" r="0.8"/>' },
    dns:          { label: 'DNS',         svg: '<circle cx="12" cy="12" r="8.5"/><path d="M12 3.5v17M3.5 12h17"/>' },
    folder:       { label: 'Папка',       svg: '<path d="M3.5 8h5.5l1.5 1.5H20.5v9.5H3.5z"/><path d="M3.5 8V6h5l1.2 2"/>' },
    database:     { label: 'БД',          svg: '<ellipse cx="12" cy="6.5" rx="7.5" ry="2.8"/><path d="M4.5 6.5v5.5c0 1.5 3.4 2.8 7.5 2.8s7.5-1.3 7.5-2.8V6.5"/><path d="M4.5 12v5.5c0 1.5 3.4 2.8 7.5 2.8s7.5-1.3 7.5-2.8V12"/>' },
    hash:         { label: 'Hash',        svg: '<path d="M9.5 4.5v15M14.5 4.5v15M5 9.5h14M5 14.5h14"/>' },
    asn:          { label: 'ASN',         svg: '<path d="M4.5 19.5V8.5L12 4l7.5 4.5v11"/><path d="M8.5 19.5v-5h7v5"/>' },
    netblock:     { label: 'Netblock',    svg: '<rect x="3.5" y="5" width="17" height="14" rx="1"/><path d="M3.5 10h17M9 5v14M15 5v14"/>' },
    mx:           { label: 'MX',          svg: '<path d="M3.5 7h17v11h-17z"/><path d="M3.5 7l8.5 6 8.5-6"/>' },
    ns:           { label: 'NS',          svg: '<circle cx="12" cy="12" r="8"/><path d="M12 4v16M6 9h12M6 15h12"/>' },
    website:      { label: 'Website',     svg: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17"/><path d="M12 3.5c2.2 2.5 3.5 5.2 3.5 8.5s-1.3 6-3.5 8.5c-2.2-2.5-3.5-5.2-3.5-8.5s1.3-6 3.5-8.5z"/>' },
    port:         { label: 'Port',        svg: '<rect x="5.5" y="3.5" width="13" height="17" rx="1.5"/><path d="M9 8.5h6M9 12h6M9 15.5h4"/>' },
    service:      { label: 'Сервис',      svg: '<circle cx="12" cy="12" r="2.8"/><path d="M12 3.5v2.5M12 18v2.5M3.5 12h2.5M18 12h2.5M6.2 6.2l1.8 1.8M16 16l1.8 1.8M6.2 17.8l1.8-1.8M16 8l1.8-1.8"/>' },
    malware:      { label: 'Malware',     svg: '<path d="M12 3.5l8.5 15.5h-17z"/><path d="M12 10v4M12 16.5h.01"/>' },
    vulnerability:{ label: 'Уязвимость',  svg: '<path d="M12 3.5l8.5 15.5h-17z"/><path d="M12 10v4M12 16.5h.01"/>' },
    certificate:  { label: 'Сертификат',  svg: '<rect x="4.5" y="3.5" width="15" height="12" rx="1"/><path d="M9.5 19.5l2.5-2 2.5 2v-4"/><path d="M8 8h8M8 11h5"/>' },
    ssl:          { label: 'SSL',         svg: '<rect x="5.5" y="10.5" width="13" height="9.5" rx="1"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/>' },
    mac:          { label: 'MAC',         svg: '<rect x="3.5" y="6.5" width="17" height="11" rx="1.5"/><path d="M7 11h.01M10.5 11h.01M14 11h.01"/>' },
    device:       { label: 'Устройство',  svg: '<rect x="6" y="3.5" width="12" height="15" rx="1.5"/><path d="M10 18.5h4"/>' },
    laptop:       { label: 'Ноутбук',     svg: '<rect x="3.5" y="5.5" width="17" height="10" rx="1"/><path d="M2 17.5h20"/>' },
    router:       { label: 'Роутер',      svg: '<rect x="3.5" y="11" width="17" height="7" rx="1"/><path d="M7 11V8M12 11V6.5M17 11V8"/><circle cx="8" cy="14.5" r="0.9"/><circle cx="12" cy="14.5" r="0.9"/>' },
    camera:       { label: 'Камера',      svg: '<path d="M3.5 8.5h3.5l1.5-2h7l1.5 2h3.5v10h-17z"/><circle cx="12" cy="13" r="3.2"/>' },
    vehicle:      { label: 'Транспорт',   svg: '<path d="M4 15h16l-1.2-4.5H5.2z"/><path d="M5.5 15v2.5h2.5v-1.5h8v1.5H18.5V15"/><circle cx="7.5" cy="17" r="1.3"/><circle cx="16.5" cy="17" r="1.3"/>' },
    company:      { label: 'Компания',    svg: '<path d="M4 21V9L12 4l8 5v12"/><path d="M9 21v-6h6v6"/>' },
    bank:         { label: 'Банк',        svg: '<path d="M3.5 9.5l8.5-5 8.5 5"/><path d="M5.5 9.5v8h13v-8"/><path d="M3.5 18.5h17"/>' },
    passport:     { label: 'Паспорт',     svg: '<rect x="5" y="3.5" width="14" height="17" rx="1"/><circle cx="12" cy="10" r="2.8"/><path d="M8.5 16.5h7"/>' },
    idcard:       { label: 'ID',          svg: '<rect x="2.5" y="6.5" width="19" height="11" rx="1.5"/><circle cx="8" cy="12" r="2.3"/><path d="M12.5 10h6M12.5 14h4.5"/>' },
    address:      { label: 'Адрес',       svg: '<path d="M4.5 20.5V9.5L12 4.5l7.5 5v11"/><path d="M10 20.5v-5.5h4v5.5"/>' },
    alias:        { label: 'Alias',       svg: '<circle cx="8.5" cy="9" r="2.8"/><circle cx="15.5" cy="9" r="2.8"/><path d="M3 19c0-2.8 2.5-5 5.5-5s5.5 2.2 5.5 5M10 19c0-2.8 2.5-5 5.5-5s5.5 2.2 5.5 5"/>' },
    group:        { label: 'Группа',      svg: '<circle cx="9" cy="8.5" r="2.8"/><circle cx="15.5" cy="9" r="2.3"/><path d="M3.5 19c0-3 2.9-5.2 6.5-5.2S16.5 16 16.5 19"/><path d="M14 19c0-2 1.6-3.6 4-3.6 1.3 0 2.4.4 3.1 1.1"/>' },
    forum:        { label: 'Форум',       svg: '<path d="M5 5h14a1.5 1.5 0 0 1 1.5 1.5v7.5a1.5 1.5 0 0 1-1.5 1.5H10l-3.5 2.8v-2.8H5A1.5 1.5 0 0 1 3.5 14V6.5A1.5 1.5 0 0 1 5 5z"/>' },
    tweet:        { label: 'Tweet',       svg: '<path d="M4 18c6 0 10-4.5 11-9 1 .5 1.8.7 2.8.8-.9-.6-1.6-1.5-1.9-2.6.9.5 1.8.9 2.8 1C17.8 6.5 16.4 5 14.5 5c-1.8 0-3.2 1.5-3.2 3.3 0 .3 0 .5.1.8C8.2 8.8 5.5 7.2 3.7 4.7c-.3.5-.4 1.1-.4 1.7 0 1.1.6 2.1 1.4 2.7-.5 0-1-.2-1.5-.4 0 1.6 1.1 2.9 2.6 3.2-.3.1-.6.1-.9.1-.2 0-.4 0-.6-.1.4 1.3 1.6 2.2 3 2.3C6.5 16 4.8 16.7 3 16.7c-.3 0-.7 0-1-.1C3.7 17.5 5.8 18 8 18"/>' },
    hashtag:      { label: 'Hashtag',     svg: '<path d="M9 4.5l-2 15M17 4.5l-2 15M4.5 9.5h15M4 14.5h15"/>' },
    password:     { label: 'Пароль',      svg: '<rect x="4.5" y="10.5" width="15" height="10" rx="1.5"/><path d="M8.5 10.5V7.5a3.5 3.5 0 0 1 7 0v3"/><circle cx="12" cy="15.5" r="1.3"/>' },
    key:          { label: 'Ключ',        svg: '<circle cx="8.5" cy="14" r="4.5"/><path d="M12.5 12.5 20 5M17.5 4.5l2.5 2.5"/>' },
    token:        { label: 'Token',       svg: '<circle cx="12" cy="12" r="8.5"/><path d="M8.5 12h7M12 8.5v7"/>' },
    api:          { label: 'API',         svg: '<path d="M5 7.5h3.5v9H5zM10.5 7.5H14l2.5 4.5-2.5 4.5h-3.5"/><path d="M17.5 7.5H19v9h-1.5"/>' },
    cloud:        { label: 'Cloud',       svg: '<path d="M7 17.5h10.5a3.5 3.5 0 0 0 .2-7 5 5 0 0 0-9.5-1.5A3.2 3.2 0 0 0 7 17.5z"/>' },
    vpn:          { label: 'VPN',         svg: '<path d="M12 3.5l7.5 3.5v5c0 4.5-3.2 7.8-7.5 9.2C7.7 19.8 4.5 16.5 4.5 12v-5z"/>' },
    proxy:        { label: 'Proxy',       svg: '<circle cx="6.5" cy="12" r="2.8"/><circle cx="17.5" cy="12" r="2.8"/><path d="M9.3 12h5.4"/>' },
    emailserver:  { label: 'Mail server', svg: '<path d="M3.5 6.5h17v12h-17z"/><path d="M3.5 6.5l8.5 6 8.5-6"/>' },
    whois:        { label: 'WHOIS',       svg: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-3.2-3.2"/><path d="M8.5 11h5M11 8.5v5"/>' },
    geolocation:  { label: 'Geo',         svg: '<path d="M12 21s-6.5-5-6.5-10.5a6.5 6.5 0 1 1 13 0C18.5 16 12 21 12 21z"/><circle cx="12" cy="10.5" r="2.3"/>' },
    geo_estimate: { label: 'Geo estimate',svg: '<path d="M12 21s-6.5-5-6.5-10.5a6.5 6.5 0 1 1 13 0C18.5 16 12 21 12 21z"/><circle cx="12" cy="10.5" r="2.3"/><path d="M17.5 4.5h3v3"/>' },
    network:      { label: 'Network',     svg: '<circle cx="6.5" cy="7" r="2.5"/><circle cx="17.5" cy="7" r="2.5"/><circle cx="12" cy="17" r="2.5"/><path d="M8.5 8.5 10.8 15M15.5 8.5 13.2 15M9 7h6"/>' },
    wifi:         { label: 'Wi‑Fi',       svg: '<path d="M4.5 12.5a9 9 0 0 1 15 0"/><path d="M7.5 15.5a5 5 0 0 1 9 0"/><circle cx="12" cy="18.5" r="1.3"/>' },
    app:          { label: 'Приложение',  svg: '<rect x="4.5" y="4.5" width="15" height="15" rx="2"/><rect x="8.5" y="8.5" width="7" height="7" rx="0.8"/>' },
    account:      { label: 'Аккаунт',     svg: '<circle cx="12" cy="8" r="3.5"/><path d="M5 20v-1c0-3.1 3.1-5.5 7-5.5s7 2.4 7 5.5v1"/>' },
    crypto:       { label: 'Крипто',      svg: '<circle cx="12" cy="12" r="8.5"/><path d="M9.5 8h4.5a2.3 2.3 0 0 1 0 4.6H9.5m0-4.6v9m0-4.4h4.5a2.3 2.3 0 0 1 0 4.6H9.5"/>' },
    bitcoin:      { label: 'Bitcoin',     svg: '<circle cx="12" cy="12" r="8.5"/><path d="M9.5 8h4.5a2.3 2.3 0 0 1 0 4.6H9.5m0-4.6v9m0-4.4h4.5a2.3 2.3 0 0 1 0 4.6H9.5"/>' },
    timestamp:    { label: 'Время',       svg: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5v5l3 1.8"/>' },
    event:        { label: 'Событие',     svg: '<rect x="3.5" y="5.5" width="17" height="15" rx="1"/><path d="M3.5 10h17M8.5 3.5v4M15.5 3.5v4"/>' },
    threat:       { label: 'Угроза',      svg: '<path d="M12 3l9 16.5H3z"/><path d="M12 10v4M12 16.5h.01"/>' },
    ioc:          { label: 'IOC',         svg: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5v5M12 15.5h.01"/>' },
    report:       { label: 'Отчёт',       svg: '<path d="M6.5 3h9l4 4v14h-13z"/><path d="M15.5 3v4h4"/><path d="M9.5 12h6M9.5 15.5h4"/>' },
    video:        { label: 'Video',       svg: '<rect x="2.5" y="6.5" width="14" height="11" rx="1"/><path d="M16.5 10l5-2.5v9l-5-2.5z"/>' },
    audio:        { label: 'Audio',       svg: '<path d="M4.5 10v4h3.5l4.5 3.5v-11L8 10z"/><path d="M16 9.5a3.5 3.5 0 0 1 0 5"/>' },
    archive:      { label: 'Архив',       svg: '<path d="M4 6.5h16v2.5H4z"/><path d="M5 9h14v11H5z"/><path d="M10.5 13.5h3"/>' },
    script:       { label: 'Script',      svg: '<path d="M8 4h9l3 3v13H8z"/><path d="M17 4v3h3"/><path d="M11 12l-1.5 1.5L11 15M14 12l1.5 1.5L14 15"/>' },
    process:      { label: 'Process',     svg: '<rect x="4.5" y="4.5" width="15" height="15" rx="1.5"/><path d="M8 9.5h8M8 12.5h8M8 15.5h5"/>' },
    registry:     { label: 'Registry',    svg: '<path d="M6.5 3.5h8l3.5 3.5v13.5h-11.5z"/><path d="M14.5 3.5v3.5h3.5"/><path d="M9.5 12h5M9.5 15.5h3.5"/>' },
    cookie:       { label: 'Cookie',      svg: '<circle cx="12" cy="12" r="8.5"/><circle cx="9" cy="10" r="0.9"/><circle cx="14" cy="9.5" r="0.9"/><circle cx="11" cy="14" r="0.9"/><circle cx="15" cy="14.5" r="0.9"/>' },
    session:      { label: 'Session',     svg: '<rect x="3.5" y="6.5" width="17" height="11" rx="1.5"/><path d="M7.5 12h9"/>' },
    role:         { label: 'Role',        svg: '<circle cx="12" cy="8" r="3.5"/><path d="M5 20v-1c0-3.1 3.1-5.5 7-5.5s7 2.4 7 5.5v1"/>' },
    permission:   { label: 'Permission',  svg: '<path d="M12 3l7.5 2.8v5.2c0 4.5-3.2 7.8-7.5 9.2C7.7 18.8 4.5 15.5 4.5 11V5.8z"/><path d="M9 12l2 2 4-4"/>' },
    text:         { label: 'Текст',       svg: '<path d="M5 6.5h14M12 6.5v11M8 17.5h8"/>' },
    other:        { label: 'Другое',      svg: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="2.5"/>' }
  };



  const MALTEGO_COLORS = {
    person: '#E8913A', username: '#7B68A6', email: '#D4A017', phone: '#5B9E4D',
    domain: '#3A7BD5', ip: '#5B8C5A', url: '#4A90A4', organization: '#C44B4B',
    social: '#C75B9B', location: '#D97706', document: '#6B7280', photo: '#B45309',
    server: '#4B5563', dns: '#2563EB', file: '#0D9488', folder: '#CA8A04',
    database: '#7C3AED', hash: '#64748B', crypto: '#F59E0B', bitcoin: '#F7931A',
    asn: '#059669', netblock: '#0F766E', mx: '#DB2777', ns: '#4F46E5',
    website: '#0284C7', port: '#475569', service: '#EA580C', malware: '#DC2626',
    vulnerability: '#B91C1C', certificate: '#16A34A', ssl: '#15803D', mac: '#6D28D9',
    device: '#334155', laptop: '#1E40AF', router: '#0369A1', camera: '#9F1239',
    vehicle: '#A16207', company: '#9F1239', bank: '#1D4ED8', passport: '#1E3A8A',
    idcard: '#312E81', address: '#B45309', alias: '#7E22CE', group: '#6B21A8',
    forum: '#BE185D', tweet: '#1D9BF0', hashtag: '#0369A1', password: '#991B1B',
    key: '#A16207', token: '#0F766E', api: '#5B21B6', cloud: '#38BDF8',
    vpn: '#065F46', proxy: '#57534E', emailserver: '#B45309', whois: '#1E40AF',
    geolocation: '#C2410C', geo_estimate: '#B45309', timestamp: '#4B5563', event: '#7C2D12', threat: '#7F1D1D',
    ioc: '#991B1B', report: '#334155', image: '#9A3412', video: '#7E22CE',
    audio: '#6D28D9', archive: '#854D0E', script: '#166534', process: '#1E3A8A',
    registry: '#3F3F46', cookie: '#A16207', session: '#0E7490', account: '#E8913A',
    role: '#CA8A04', permission: '#15803D', text: '#374151', other: '#6B7280'
  };

  const DEFAULT_SETTINGS = {
    nodeSize: 48,
    edgeLabels: true,
    theme: 'light',
    iconStyle: 'colored', // icon | colored | gray | text
    edgeStyle: 'straight',  // smooth | sharp | straight
    edgeColor: '#777777',
    pngLogo: true,
    bgWatermark: false
  };

  let projects = [], currentProject = null, currentProjectId = null;
  let selectedNodeId = null, selectedEdgeId = null;
  let hiddenTypes = new Set();
  let pathHighlight = { nodes: new Set(), edges: new Set() };
  let history = [], historyIndex = -1;
  let settings = { ...DEFAULT_SETTINGS };
  let view = { x: 0, y: 0, scale: 1 };
  let viewMode = 'graph'; // 'graph' | 'dots'
  let renderScheduled = false;

  let isPanning = false, isDraggingNode = false, isLinking = false, isDraggingEdgeCtrl = false, dragEdgeCtrlId = null;
  let linkFromId = null, dragNodeId = null;
  let lastPointer = { x: 0, y: 0 };
  let pointers = new Map();
  let lastPinchDist = 0;
  let longPressTimer = null, longPressTriggered = false;
  let editingNodeId = null, pendingPhotoData = null, pendingPhotoRatio = 1;
  let tempEdgeEl = null;
  let pendingAddPos = null; // {x,y} in graph coords for double-tap add
  let lastTap = { time: 0, x: 0, y: 0 };
  let ignoreModalClickUntil = 0;

  const $ = s => document.querySelector(s);
  const $$ = s => document.querySelectorAll(s);
  const homeScreen = $('#home-screen');
  const invScreen = $('#investigation-screen');
  const graphSvg = $('#graph-svg');
  const edgesLayer = $('#edges-layer');
  const nodesLayer = $('#nodes-layer');
  const graphContainer = $('#graph-container');
  const graphEmpty = $('#graph-empty');

  function uid() { return 'id_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
  function now() { return new Date().toISOString(); }
  function formatDate(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleDateString('ru-RU', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  }
  function toast(msg, ms = 2000) {
    const el = $('#toast');
    el.textContent = msg;
    el.classList.remove('hidden');
    requestAnimationFrame(() => el.classList.add('show'));
    setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.classList.add('hidden'), 200); }, ms);
  }
  function deepClone(o) { return JSON.parse(JSON.stringify(o)); }
  function escapeHtml(s) {
    if (!s) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function truncate(s, n) { return !s ? '' : (s.length > n ? s.slice(0, n - 1) + '…' : s); }

  // Storage
  function loadProjects() { try { projects = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); } catch { projects = []; } }
  let _saveTimer = null;
  function saveProjects() {
    clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => {
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(projects)); } catch (e) {
        console.warn('save failed', e);
        toast('Не удалось сохранить (мало места?)');
      }
    }, 280);
  }
  function saveProjectsNow() {
    clearTimeout(_saveTimer);
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(projects)); } catch (e) {
      console.warn('save failed', e);
    }
  }
  function loadSettings() {
    try { const r = localStorage.getItem(SETTINGS_KEY); if (r) settings = { ...DEFAULT_SETTINGS, ...JSON.parse(r) }; } catch {}
  }
  function saveSettings() { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); }

  function applyTheme() {
    document.documentElement.classList.toggle('theme-dark', settings.theme === 'dark');
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.content = settings.theme === 'dark' ? '#121212' : '#f5f5f5';
    applyBgWatermark();
  }
  function applyBgWatermark() {
    const el = document.getElementById('graph-watermark');
    if (!el) return;
    el.classList.toggle('hidden', !settings.bgWatermark);
  }
  function getRecent() { try { return JSON.parse(localStorage.getItem(RECENT_KEY) || '[]'); } catch { return []; } }
  function addRecent(id) {
    let r = getRecent().filter(x => x !== id); r.unshift(id);
    localStorage.setItem(RECENT_KEY, JSON.stringify(r.slice(0, 5)));
  }

  function createProject(name, desc) {
    const p = { id: uid(), name: name || 'Без названия', description: desc || '', notes: '',
      createdAt: now(), updatedAt: now(), nodes: [], edges: [], timeline: [], view: { x: 0, y: 0, scale: 1 } };
    projects.unshift(p); saveProjects(); return p;
  }
  function deleteProject(id) {
    projects = projects.filter(p => p.id !== id); saveProjects();
    localStorage.setItem(RECENT_KEY, JSON.stringify(getRecent().filter(r => r !== id)));
  }
  function getProject(id) { return projects.find(p => p.id === id); }
  function touchProject() { if (!currentProject) return; currentProject.updatedAt = now(); saveProjects(); }

  // History
  function pushHistory() {
    if (!currentProject) return;
    const snap = { nodes: deepClone(currentProject.nodes), edges: deepClone(currentProject.edges) };
    history = history.slice(0, historyIndex + 1);
    history.push(snap);
    if (history.length > 40) history.shift(); else historyIndex++;
    updateUndoRedo();
  }
  function undo() { if (historyIndex <= 0) return; historyIndex--; applyHistory(); }
  function redo() { if (historyIndex >= history.length - 1) return; historyIndex++; applyHistory(); }
  function applyHistory() {
    if (!currentProject || !history[historyIndex]) return;
    const s = history[historyIndex];
    currentProject.nodes = deepClone(s.nodes);
    currentProject.edges = deepClone(s.edges);
    selectedNodeId = null; selectedEdgeId = null;
    closeNodeSheet(); closeEdgeSheet();
    renderGraph(); updateLists(); touchProject(); updateUndoRedo();
  }
  function updateUndoRedo() {
    $('#btn-undo').disabled = historyIndex <= 0;
    $('#btn-redo').disabled = historyIndex >= history.length - 1;
  }
  function resetHistory() {
    history = []; historyIndex = -1;
    if (currentProject) pushHistory();
    updateUndoRedo();
  }

  // Home
  function plural(n) {
    if (n % 10 === 1 && n % 100 !== 11) return '';
    if (n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20)) return 'а';
    return 'ов';
  }
  function pluralEdges(n) {
    if (n % 10 === 1 && n % 100 !== 11) return 'ь';
    if (n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20)) return 'и';
    return 'ей';
  }

  function renderHome(filter = '') {
    const list = $('#investigations-list');
    const q = filter.toLowerCase().trim();
    let filtered = q ? projects.filter(p => p.name.toLowerCase().includes(q) || (p.description || '').toLowerCase().includes(q)) : projects;
    if (!filtered.length) {
      list.innerHTML = `<div class="empty-state"><p>${q ? 'Ничего не найдено' : 'Нет расследований'}</p>${!q ? '<button class="btn-primary btn-sm" id="empty-new-btn">+ Создать</button>' : ''}</div>`;
      const b = $('#empty-new-btn'); if (b) b.onclick = () => openModal('modal-new-investigation');
    } else {
      list.innerHTML = filtered.map(p => {
        const nc = (p.nodes || []).length, ec = (p.edges || []).length;
        return `<div class="inv-card" data-id="${p.id}"><h3>${escapeHtml(p.name)}</h3>
          ${p.description ? `<div class="desc">${escapeHtml(p.description)}</div>` : ''}
          <div class="meta"><span>${formatDate(p.updatedAt)}</span></div>
          <div class="stats-row"><span class="stat-chip">${nc} объект${plural(nc)}</span>
          <span class="stat-chip">${ec} связ${pluralEdges(ec)}</span></div></div>`;
      }).join('');
      list.querySelectorAll('.inv-card').forEach(c => { c.onclick = () => openProject(c.dataset.id); });
    }
    const rs = $('#recent-section'), rl = $('#recent-list');
    const recentIds = getRecent();
    if (recentIds.length && !q) {
      const rp = recentIds.map(id => getProject(id)).filter(Boolean);
      if (rp.length) {
        rs.classList.remove('hidden');
        rl.innerHTML = rp.map(p => `<div class="inv-card" data-id="${p.id}"><h3>${escapeHtml(p.name)}</h3><div class="meta"><span>${formatDate(p.updatedAt)}</span></div></div>`).join('');
        rl.querySelectorAll('.inv-card').forEach(c => { c.onclick = () => openProject(c.dataset.id); });
      } else { rs.classList.add('hidden'); rl.innerHTML = ''; }
    } else { rs.classList.add('hidden'); rl.innerHTML = ''; }
  }

  function openProject(id) {
    const p = getProject(id); if (!p) return;
    currentProjectId = id; currentProject = p;
    if (!p.nodes) p.nodes = []; if (!p.edges) p.edges = []; if (!p.view) p.view = { x: 0, y: 0, scale: 1 };
    view = { ...p.view };
    selectedNodeId = null; selectedEdgeId = null; isLinking = false;
    addRecent(id); resetHistory();
    showScreen('investigation');
    $('#project-title').textContent = p.name;
    renderGraph(); updateLists(); closeDrawer(); closeAllPanels(); closeNodeSheet(); closeEdgeSheet();
    try {
      if (window.NexusBackground) {
        NexusBackground.resetSession();
        NexusBackground.start(id);
        // low-priority scan of existing graph
        setTimeout(() => {
          if (currentProject && NexusBackground) {
            NexusBackground.enqueueGraph(currentProject.nodes, { source: 'open-project' });
          }
        }, 600);
      }
    } catch (_) {}
  }

  function closeProject() {
    if (currentProject) { currentProject.view = { ...view }; touchProject(); }
    currentProjectId = null; currentProject = null; history = []; historyIndex = -1;
    showScreen('home'); renderHome();
  }
  function showScreen(name) {
    homeScreen.classList.toggle('active', name === 'home');
    invScreen.classList.toggle('active', name === 'investigation');
  }

  // ===== GRAPH RENDER =====
  function nodeRadius(n) {
    if (n.type === 'photo' || n.type === 'image') {
      const w = n.size || 140;
      const h = photoHeight(n, w);
      return Math.max(w, h) / 2;
    }
    return (n.size || settings.nodeSize) / 2;
  }

  function photoHeight(n, w) {
    const ratio = (n.photoRatio && n.photoRatio > 0) ? n.photoRatio : 1;
    return w / ratio;
  }

  function photoSize(n) {
    const w = n.size || 120;
    return { w, h: photoHeight(n, w) };
  }

  function isPhotoNode(n) {
    return !!(n && n.photoData && (n.type === 'photo' || n.type === 'image'));
  }

  function isTextNode(n) {
    return !!(n && n.type === 'text');
  }

  /** Size of a free-text node (full text visible, no icon). */
  function textNodeSize(n) {
    const raw = (n.label || n.value || 'Текст').trim() || 'Текст';
    const maxW = 280;
    const charW = 7.0;
    const padX = 16;
    const padY = 12;
    const lineH = 16;
    // wrap by approximate character width
    const maxChars = Math.max(12, Math.floor((maxW - padX * 2) / charW));
    const lines = [];
    let rest = raw;
    while (rest.length > 0) {
      if (rest.length <= maxChars) { lines.push(rest); break; }
      let cut = rest.lastIndexOf(' ', maxChars);
      if (cut < maxChars * 0.4) cut = maxChars;
      lines.push(rest.slice(0, cut).trimEnd());
      rest = rest.slice(cut).trimStart();
      if (lines.length >= 12) { lines[lines.length - 1] += '…'; break; }
    }
    if (!lines.length) lines.push('Текст');
    const longest = lines.reduce((m, s) => Math.max(m, s.length), 0);
    const w = Math.max(72, Math.min(maxW, longest * charW + padX * 2));
    const h = Math.max(28, lines.length * lineH + padY);
    return { w, h, lines };
  }

  /** Half-width / half-height of a node for edge attachment. */
  function nodeHalfSize(n) {
    if (!n) return { hw: 20, hh: 20, shape: 'circle' };
    if (isPhotoNode(n) || n.type === 'photo' || n.type === 'image') {
      const s = photoSize(n);
      return { hw: s.w / 2, hh: s.h / 2, shape: 'rect' };
    }
    if (isTextNode(n)) {
      const s = textNodeSize(n);
      return { hw: s.w / 2, hh: s.h / 2, shape: 'rect' };
    }
    if ((settings.iconStyle || 'colored') === 'text') {
      const mainText = n.label || n.value || '—';
      const tw = Math.max(48, Math.min(320, mainText.length * 7.2 + 28));
      return { hw: tw / 2, hh: 16, shape: 'rect' };
    }
    const r = nodeRadius(n);
    return { hw: r, hh: r, shape: 'circle' };
  }

  /** Point on node border in direction of (tx, ty) from center. */
  function borderPointToward(node, tx, ty, extraPad) {
    const pad = extraPad || 0;
    let dx = tx - node.x, dy = ty - node.y;
    let len = Math.sqrt(dx * dx + dy * dy);
    if (len < 1e-6) { dx = 0; dy = -1; len = 1; }
    const ux = dx / len, uy = dy / len;
    const sz = nodeHalfSize(node);
    if (sz.shape === 'circle') {
      const r = Math.max(sz.hw, sz.hh) + pad;
      return { x: node.x + ux * r, y: node.y + uy * r, ux: ux, uy: uy };
    }
    // rectangle ray-AABB
    const ax = Math.abs(ux) < 1e-9 ? 1e9 : (sz.hw + pad) / Math.abs(ux);
    const ay = Math.abs(uy) < 1e-9 ? 1e9 : (sz.hh + pad) / Math.abs(uy);
    const t = Math.min(ax, ay);
    return { x: node.x + ux * t, y: node.y + uy * t, ux: ux, uy: uy };
  }

  function getEdgeControl(from, to, e) {
    if (e && e.cx != null && e.cy != null && isFinite(e.cx) && isFinite(e.cy)) {
      return { x: e.cx, y: e.cy };
    }
    const c = (e && e.curve) || 0;
    const mx = (from.x + to.x) / 2, my = (from.y + to.y) / 2;
    const dx = to.x - from.x, dy = to.y - from.y;
    const len = Math.sqrt(dx * dx + dy * dy) || 1;
    return { x: mx + (-dy / len) * c, y: my + (dx / len) * c };
  }

  /**
   * Path + arrow share ONE final direction so the head never detaches from the line.
   */
  function buildEdgeDraw(from, to, e) {
    const style = (viewMode === 'dots') ? 'straight' : (settings.edgeStyle || 'straight');
    const ARROW = 8;

    const start = borderPointToward(from, to.x, to.y, 0);
    let pathD;
    let tipX, tipY, ux, uy;

    if (style === 'sharp') {
      const ctrl = getEdgeControl(from, to, e);
      const midX = ctrl.x;
      // Decide last segment axis from mid → target center
      const preferH = Math.abs(to.x - midX) >= Math.abs(to.y - start.y);
      if (preferH) {
        // horizontal into target
        ux = to.x >= midX ? 1 : -1; uy = 0;
        tipX = to.x - ux * nodeHalfSize(to).hw;
        tipY = to.y;
        const endX = tipX - ux * ARROW;
        const endY = tipY;
        pathD = 'M ' + start.x + ' ' + start.y +
                ' L ' + midX + ' ' + start.y +
                ' L ' + midX + ' ' + endY +
                ' L ' + endX + ' ' + endY;
      } else {
        // vertical into target
        ux = 0; uy = to.y >= start.y ? 1 : -1;
        // refine uy from mid bend
        const midY = (start.y + to.y) / 2;
        ux = 0; uy = to.y >= midY ? 1 : -1;
        tipX = to.x;
        tipY = to.y - uy * nodeHalfSize(to).hh;
        const endX = tipX;
        const endY = tipY - uy * ARROW;
        pathD = 'M ' + start.x + ' ' + start.y +
                ' L ' + midX + ' ' + start.y +
                ' L ' + midX + ' ' + endY +
                ' L ' + endX + ' ' + endY;
      }
    } else if (style === 'smooth') {
      const ctrl = getEdgeControl(from, to, e);
      // Tip on target facing control point (curve approach)
      const tip = borderPointToward(to, ctrl.x, ctrl.y, 0);
      tipX = tip.x; tipY = tip.y;
      let tx = tipX - ctrl.x, ty = tipY - ctrl.y;
      let tl = Math.sqrt(tx * tx + ty * ty);
      if (tl < 1) {
        tx = to.x - from.x; ty = to.y - from.y;
        tl = Math.sqrt(tx * tx + ty * ty) || 1;
      }
      ux = tx / tl; uy = ty / tl;
      const endX = tipX - ux * ARROW;
      const endY = tipY - uy * ARROW;
      pathD = 'M ' + start.x + ' ' + start.y +
              ' Q ' + ctrl.x + ' ' + ctrl.y + ' ' + endX + ' ' + endY;
    } else {
      // straight: tip faces source, direction = line direction
      const tip = borderPointToward(to, from.x, from.y, 0);
      tipX = tip.x; tipY = tip.y;
      let dx = tipX - start.x, dy = tipY - start.y;
      let len = Math.sqrt(dx * dx + dy * dy);
      if (len < 1) {
        dx = to.x - from.x; dy = to.y - from.y;
        len = Math.sqrt(dx * dx + dy * dy) || 1;
      }
      ux = dx / len; uy = dy / len;
      const endX = tipX - ux * ARROW;
      const endY = tipY - uy * ARROW;
      pathD = 'M ' + start.x + ' ' + start.y + ' L ' + endX + ' ' + endY;
    }

    // Arrow base MUST equal path endpoint (tip - ux*ARROW)
    const bx = tipX - ux * ARROW;
    const by = tipY - uy * ARROW;
    const px = -uy, py = ux;
    const wing = ARROW * 0.4;
    const points = [
      tipX, tipY,
      bx + px * wing, by + py * wing,
      bx - px * wing, by - py * wing
    ].join(' ');

    return { pathD: pathD, arrowPoints: points, tip: { x: tipX, y: tipY }, ux: ux, uy: uy };
  }

  function edgePath(from, to, eOrCurve, fromR, toR) {
    const e = (typeof eOrCurve === 'object' && eOrCurve) ? eOrCurve : { curve: eOrCurve || 0 };
    return buildEdgeDraw(from, to, e).pathD;
  }

  function edgeEndpointsNodes(from, to, arrowPad) {
    const d = buildEdgeDraw(from, to, {});
    return { x1: 0, y1: 0, x2: d.tip.x, y2: d.tip.y, ux: d.ux, uy: d.uy, len: 1 };
  }

  function edgeEndpoints(from, to, fromR, toR, arrowPad) {
    return edgeEndpointsNodes(from, to, arrowPad);
  }

  function edgeMidpoint(from, to, curve, fromR, toR) {
    const ctrl = getEdgeControl(from, to, { curve: curve || 0 });
    return { x: ctrl.x, y: ctrl.y };
  }

  function appendArrowHead(g, from, to, e, color) {
    const d = buildEdgeDraw(from, to, e || {});
    const poly = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
    poly.setAttribute('points', d.arrowPoints);
    poly.setAttribute('fill', color || '#555');
    poly.setAttribute('stroke', 'none');
    poly.setAttribute('pointer-events', 'none');
    g.appendChild(poly);
  }

  function edgeAttachRadius(n) {
    if (isPhotoNode(n)) {
      const { w, h } = photoSize(n);
      return Math.sqrt((w / 2) * (w / 2) + (h / 2) * (h / 2)) * 0.85;
    }
    if ((settings.iconStyle || 'colored') === 'text') {
      const mainText = n.label || n.value || '—';
      const tw = Math.max(48, mainText.length * 7.2 + 28);
      const th = 32;
      return Math.sqrt((tw / 2) * (tw / 2) + (th / 2) * (th / 2)) * 0.9;
    }
    return nodeRadius(n);
  }

  let edgeRefreshTimer = null;
  function scheduleEdgeRefresh() {
    if (edgeRefreshTimer) return;
    edgeRefreshTimer = requestAnimationFrame(() => {
      edgeRefreshTimer = null;
      refreshEdgesOnly();
    });
  }

  function renderGraph() {
    if (!currentProject) return;
    const nodes = currentProject.nodes;
    const edges = currentProject.edges;
    graphEmpty.classList.toggle('hidden', nodes.length > 0);
    const showLabels = view.scale >= LOD_THRESHOLD && viewMode === 'graph';
    const dots = viewMode === 'dots';
    graphContainer.classList.toggle('view-dots', dots);

    // --- Edges ---
    edgesLayer.innerHTML = '';
    edges.forEach(e => {
      const from = nodes.find(n => n.id === e.from);
      const to = nodes.find(n => n.id === e.to);
      if (!from || !to) return;
      if (hiddenTypes.has(from.type) || hiddenTypes.has(to.type)) return;

      const fromR = dots ? 6 : edgeAttachRadius(from);
      const toR = dots ? 6 : edgeAttachRadius(to);
      const pathD = edgePath(from, to, e, fromR, toR);

      const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      g.dataset.edgeId = e.id;

      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('class', 'edge-path' + (selectedEdgeId === e.id ? ' selected' : '') + (pathHighlight.edges.has(e.id) ? ' path-hl' : ''));
      path.setAttribute('d', pathD);
      path.setAttribute('stroke', selectedEdgeId === e.id ? (settings.theme === 'dark' ? '#fff' : '#1a1a1a') : (dots ? '#888' : (settings.edgeColor || '#777')));
      path.setAttribute('stroke-width', dots ? 0.8 : (e.width || 1.0));
      path.setAttribute('marker-end', 'none');
      path.setAttribute('stroke-linecap', 'round');
      path.setAttribute('fill', 'none');
      g.appendChild(path);
      const edgeCol = selectedEdgeId === e.id
        ? (settings.theme === 'dark' ? '#fff' : '#1a1a1a')
        : (settings.edgeColor || (settings.theme === 'dark' ? '#888' : '#666'));
      appendArrowHead(g, from, to, e, edgeCol);

      const hit = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      hit.setAttribute('d', pathD);
      hit.setAttribute('stroke', 'transparent');
      hit.setAttribute('stroke-width', '16');
      hit.setAttribute('fill', 'none');
      hit.style.cursor = 'pointer';
      hit.addEventListener('click', ev => { ev.stopPropagation(); selectEdge(e.id); });
      g.appendChild(hit);

      if (settings.edgeLabels && e.type && showLabels && !dots) {
        const mid = getEdgeControl(from, to, e);
        const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('class', 'edge-label');
        text.setAttribute('x', mid.x);
        text.setAttribute('y', mid.y - 6);
        text.textContent = e.type;
        g.appendChild(text);
      }
      // Free bend handle when edge selected
      if (selectedEdgeId === e.id && !dots && (settings.edgeStyle || 'smooth') !== 'straight') {
        const ctrl = getEdgeControl(from, to, e);
        const hc = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        hc.setAttribute('class', 'edge-ctrl');
        hc.setAttribute('cx', ctrl.x);
        hc.setAttribute('cy', ctrl.y);
        hc.setAttribute('r', 8);
        hc.dataset.edgeCtrl = e.id;
        g.appendChild(hc);
      }
      edgesLayer.appendChild(g);
    });

    if (tempEdgeEl && tempEdgeEl.parentNode) tempEdgeEl.parentNode.removeChild(tempEdgeEl);
    tempEdgeEl = null;

    // --- Nodes ---
    nodesLayer.innerHTML = '';
    nodes.forEach(n => {
      if (hiddenTypes.has(n.type)) return;
      const typeInfo = NODE_TYPES[n.type] || NODE_TYPES.other;
      const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      g.setAttribute('class', 'node-group' + (selectedNodeId === n.id ? ' selected' : '') + (n._highlighted ? ' highlighted' : '') + (pathHighlight.nodes.has(n.id) ? ' path-hl' : ''));
      g.dataset.nodeId = n.id;
      g.setAttribute('transform', `translate(${n.x},${n.y})`);

      // DOTS mode — points, straight links, labels when zoomed in
      if (dots) {
        const isDark = settings.theme === 'dark';
        const c = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        c.setAttribute('class', 'node-circle');
        c.setAttribute('r', selectedNodeId === n.id ? 8 : 5.5);
        c.setAttribute('fill', selectedNodeId === n.id ? (isDark ? '#fff' : '#1a1a1a') : (isDark ? '#ccc' : '#333'));
        c.setAttribute('stroke', 'none');
        g.appendChild(c);
        // labels when zoomed in enough
        if (view.scale >= LOD_THRESHOLD) {
          const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
          label.setAttribute('class', 'node-label');
          label.setAttribute('y', 16);
          label.setAttribute('fill', isDark ? '#e8e8e8' : '#1a1a1a');
          label.textContent = truncate(n.label || n.value || '—', 40);
          g.appendChild(label);
        }
        nodesLayer.appendChild(g);
        return;
      }

      // PHOTO node — free rectangle like gallery
      if (isPhotoNode(n)) {
        const { w, h } = photoSize(n);
        if (view.scale < LOD_THRESHOLD) {
          // LOD: small placeholder rect
          const ph = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
          ph.setAttribute('x', -8); ph.setAttribute('y', -8);
          ph.setAttribute('width', 16); ph.setAttribute('height', 16);
          ph.setAttribute('fill', '#ccc');
          ph.setAttribute('stroke', '#999');
          ph.setAttribute('stroke-width', '1');
          ph.setAttribute('rx', '2');
          g.appendChild(ph);
        } else {
          const img = document.createElementNS('http://www.w3.org/2000/svg', 'image');
          img.setAttribute('href', n.photoData);
          img.setAttribute('x', -w / 2);
          img.setAttribute('y', -h / 2);
          img.setAttribute('width', w);
          img.setAttribute('height', h);
          img.setAttribute('preserveAspectRatio', 'xMidYMid meet');
          img.setAttribute('pointer-events', 'none');
          g.appendChild(img);
          // subtle border only when selected
          if (selectedNodeId === n.id) {
            const border = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            border.setAttribute('class', 'photo-rect');
            border.setAttribute('x', -w / 2 - 1);
            border.setAttribute('y', -h / 2 - 1);
            border.setAttribute('width', w + 2);
            border.setAttribute('height', h + 2);
            border.setAttribute('fill', 'none');
            border.setAttribute('stroke', '#1a1a1a');
            border.setAttribute('stroke-width', '2');
            g.appendChild(border);
          }
          if (showLabels) {
            const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            label.setAttribute('class', 'node-label');
            label.setAttribute('y', h / 2 + 14);
            label.textContent = truncate(n.label || 'Фото', 40);
            g.appendChild(label);
          }
        }
        // handles
        if (selectedNodeId === n.id && view.scale >= LOD_THRESHOLD) {
          const { w, h } = photoSize(n);
          const hr = Math.max(w, h) / 2;
          [[0, -hr - 2], [hr + 2, 0], [0, hr + 2], [-hr - 2, 0]].forEach((pos, i) => {
            const handle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            handle.setAttribute('class', 'handle');
            handle.setAttribute('cx', pos[0]); handle.setAttribute('cy', pos[1]);
            handle.setAttribute('r', 7);
            handle.dataset.handle = i; handle.dataset.nodeId = n.id;
            g.appendChild(handle);
          });
        }
        nodesLayer.appendChild(g);
        return;
      }

      // TEXT node — plain box, full text, no icon
      if (isTextNode(n)) {
        const isDark = settings.theme === 'dark';
        const { w, h, lines } = textNodeSize(n);
        if (view.scale < LOD_THRESHOLD) {
          const ph = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
          ph.setAttribute('x', -10); ph.setAttribute('y', -6);
          ph.setAttribute('width', 20); ph.setAttribute('height', 12);
          ph.setAttribute('fill', isDark ? '#333' : '#e5e5e5');
          ph.setAttribute('stroke', isDark ? '#666' : '#999');
          ph.setAttribute('stroke-width', '1');
          ph.setAttribute('rx', '2');
          g.appendChild(ph);
        } else {
          const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
          rect.setAttribute('class', 'node-circle text-node-rect');
          rect.setAttribute('x', -w / 2); rect.setAttribute('y', -h / 2);
          rect.setAttribute('width', w); rect.setAttribute('height', h);
          rect.setAttribute('rx', 4);
          rect.setAttribute('fill', isDark ? '#1a1a1a' : '#fffef7');
          rect.setAttribute('stroke', selectedNodeId === n.id ? (isDark ? '#fff' : '#1a1a1a') : (isDark ? '#666' : '#444'));
          rect.setAttribute('stroke-width', selectedNodeId === n.id ? 2 : 1.25);
          g.appendChild(rect);
          const lineH = 16;
          const startY = -((lines.length - 1) * lineH) / 2;
          lines.forEach((line, i) => {
            const t = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            t.setAttribute('text-anchor', 'middle');
            t.setAttribute('dominant-baseline', 'central');
            t.setAttribute('y', startY + i * lineH);
            t.setAttribute('font-size', '12');
            t.setAttribute('font-weight', '500');
            t.setAttribute('fill', isDark ? '#e8e8e8' : '#1a1a1a');
            t.setAttribute('pointer-events', 'none');
            t.textContent = line;
            g.appendChild(t);
          });
        }
        if (selectedNodeId === n.id && view.scale >= LOD_THRESHOLD) {
          const hr = Math.max(w, h) / 2 + 4;
          [[0, -hr], [hr, 0], [0, hr], [-hr, 0]].forEach((pos, i) => {
            const handle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            handle.setAttribute('class', 'handle');
            handle.setAttribute('cx', pos[0]); handle.setAttribute('cy', pos[1]);
            handle.setAttribute('r', 6);
            handle.dataset.handle = i; handle.dataset.nodeId = n.id;
            g.appendChild(handle);
          });
        }
        nodesLayer.appendChild(g);
        return;
      }

      // Regular node — icon / badge / gray / text
      const r = nodeRadius(n);
      const iconStyle = settings.iconStyle || 'icon';
      const fillColor = MALTEGO_COLORS[n.type] || MALTEGO_COLORS.other;
      const isDark = settings.theme === 'dark';

      if (iconStyle === 'text') {
        const mainText = n.label || n.value || typeInfo.label || '—';
        const subText = (n.value && n.label && n.value !== n.label) ? n.value : '';
        const charW = 7.2;
        const padX = 14;
        const tw = Math.max(48, Math.min(320, mainText.length * charW + padX * 2));
        const th = subText ? 40 : 28;
        const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        rect.setAttribute('class', 'node-circle');
        rect.setAttribute('x', -tw / 2); rect.setAttribute('y', -th / 2);
        rect.setAttribute('width', tw); rect.setAttribute('height', th);
        rect.setAttribute('rx', 2);
        rect.setAttribute('fill', isDark ? '#1e1e1e' : '#ffffff');
        rect.setAttribute('stroke', selectedNodeId === n.id ? (isDark ? '#fff' : '#1a1a1a') : (isDark ? '#555' : '#333'));
        rect.setAttribute('stroke-width', selectedNodeId === n.id ? 2 : 1.25);
        g.appendChild(rect);
        const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        label.setAttribute('text-anchor', 'middle');
        label.setAttribute('dominant-baseline', 'central');
        label.setAttribute('y', subText ? -6 : 0);
        label.setAttribute('font-size', '11');
        label.setAttribute('font-weight', '600');
        label.setAttribute('fill', isDark ? '#e8e8e8' : '#1a1a1a');
        label.setAttribute('pointer-events', 'none');
        label.textContent = mainText.length > 44 ? mainText.slice(0, 43) + '…' : mainText;
        g.appendChild(label);
        if (subText) {
          const sub = document.createElementNS('http://www.w3.org/2000/svg', 'text');
          sub.setAttribute('text-anchor', 'middle');
          sub.setAttribute('dominant-baseline', 'central');
          sub.setAttribute('y', 10);
          sub.setAttribute('font-size', '9');
          sub.setAttribute('fill', isDark ? '#888' : '#666');
          sub.setAttribute('pointer-events', 'none');
          sub.textContent = subText.length > 48 ? subText.slice(0, 47) + '…' : subText;
          g.appendChild(sub);
        }
        if (selectedNodeId === n.id) {
          const hr = Math.max(tw, th) / 2 + 4;
          [[0, -hr], [hr, 0], [0, hr], [-hr, 0]].forEach((pos, i) => {
            const h = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            h.setAttribute('class', 'handle');
            h.setAttribute('cx', pos[0]); h.setAttribute('cy', pos[1]);
            h.setAttribute('r', 6);
            h.dataset.handle = i; h.dataset.nodeId = n.id;
            g.appendChild(h);
          });
        }
        nodesLayer.appendChild(g);
        return;
      }

      // Vector SVG icons — Maltego colors
      // icon = logo only (no circle), fully colored
      // colored = colored circle badge + white glyph
      // gray = gray badge + gray glyph
      if (iconStyle !== 'icon') {
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('class', 'node-circle');
        circle.setAttribute('r', r);
        if (iconStyle === 'gray') {
          circle.setAttribute('fill', isDark ? '#2a2a2a' : '#f0f0f0');
          circle.setAttribute('stroke', isDark ? '#666' : '#999');
        } else {
          // Maltego classic: solid type-colored disc
          circle.setAttribute('fill', fillColor);
          circle.setAttribute('stroke', selectedNodeId === n.id ? (isDark ? '#fff' : '#1a1a1a') : 'rgba(0,0,0,0.22)');
        }
        circle.setAttribute('stroke-width', selectedNodeId === n.id ? 2.5 : 1.5);
        g.appendChild(circle);
      }

      // Glyph size: larger when no circle so logo is the entity
      const iconSize = iconStyle === 'icon' ? r * 1.45 : r * 0.95;
      const ig = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      ig.setAttribute('transform', 'translate(' + (-iconSize / 2) + ',' + (-iconSize / 2) + ') scale(' + (iconSize / 24) + ')');
      ig.setAttribute('pointer-events', 'none');
      ig.setAttribute('stroke-linecap', 'round');
      ig.setAttribute('stroke-linejoin', 'round');

      let iconStroke, iconFill, sw;
      if (iconStyle === 'icon') {
        // Strict geometric logo — Maltego-like, no circle, type color
        ig.setAttribute('fill', 'none');
        ig.setAttribute('stroke', fillColor);
        ig.setAttribute('stroke-width', '1.75');
        ig.setAttribute('stroke-opacity', '1');
        ig.setAttribute('stroke-linecap', 'round');
        ig.setAttribute('stroke-linejoin', 'round');
      } else if (iconStyle === 'gray') {
        iconStroke = isDark ? '#ccc' : '#444';
        ig.setAttribute('fill', 'none');
        ig.setAttribute('stroke', iconStroke);
        ig.setAttribute('stroke-width', '1.8');
      } else {
        // white glyph on colored circle
        ig.setAttribute('fill', 'none');
        ig.setAttribute('stroke', '#ffffff');
        ig.setAttribute('stroke-width', '1.7');
      }

      const svgInner = (typeInfo && typeInfo.svg) || (NODE_TYPES.other && NODE_TYPES.other.svg) ||
        '<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="8" fill="none"/>';
      ig.innerHTML = svgInner;
      g.appendChild(ig);

      // Selection: thin ring only (even for icon-only mode)
      if (selectedNodeId === n.id) {
        const ring = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        ring.setAttribute('r', (iconStyle === 'icon' ? iconSize / 2 : r) + 4);
        ring.setAttribute('fill', 'none');
        ring.setAttribute('stroke', isDark ? '#fff' : '#1a1a1a');
        ring.setAttribute('stroke-width', '2');
        ring.setAttribute('stroke-dasharray', iconStyle === 'icon' ? '3 2' : '');
        ring.setAttribute('pointer-events', 'none');
        g.appendChild(ring);
      }

      if (showLabels) {
        const labelY = (iconStyle === 'icon' ? iconSize / 2 : r) + 13;
        const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        label.setAttribute('class', 'node-label');
        label.setAttribute('y', labelY);
        label.textContent = truncate(n.label || n.value || '—', 42);
        g.appendChild(label);
        if (n.value && n.label && n.value !== n.label) {
          const sub = document.createElementNS('http://www.w3.org/2000/svg', 'text');
          sub.setAttribute('class', 'node-sublabel');
          sub.setAttribute('y', labelY + 11);
          sub.textContent = truncate(n.value, 42);
          g.appendChild(sub);
        }
      }

      if (selectedNodeId === n.id) {
        const hr = iconStyle === 'icon' ? iconSize / 2 : r;
        [[0, -hr - 2], [hr + 2, 0], [0, hr + 2], [-hr - 2, 0]].forEach((pos, i) => {
          const h = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
          h.setAttribute('class', 'handle');
          h.setAttribute('cx', pos[0]); h.setAttribute('cy', pos[1]);
          h.setAttribute('r', 7);
          h.dataset.handle = i; h.dataset.nodeId = n.id;
          g.appendChild(h);
        });
      }
      nodesLayer.appendChild(g);
    });

    applyViewTransform();
    updateMinimap();
  }

  function refreshEdgesOnly() {
    if (!currentProject) return;
    const nodes = currentProject.nodes;
    const edges = currentProject.edges;
    const dots = viewMode === 'dots';
    edgesLayer.innerHTML = '';
    edges.forEach(e => {
      const from = nodes.find(n => n.id === e.from);
      const to = nodes.find(n => n.id === e.to);
      if (!from || !to) return;
      if (hiddenTypes.has(from.type) || hiddenTypes.has(to.type)) return;
      const fromR = dots ? 6 : edgeAttachRadius(from);
      const toR = dots ? 6 : edgeAttachRadius(to);
      const pathD = edgePath(from, to, e, fromR, toR);
      const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('class', 'edge-path' + (selectedEdgeId === e.id ? ' selected' : '') + (pathHighlight.edges.has(e.id) ? ' path-hl' : ''));
      path.setAttribute('d', pathD);
      path.setAttribute('stroke', selectedEdgeId === e.id ? (settings.theme === 'dark' ? '#fff' : '#1a1a1a') : (dots ? '#888' : (settings.edgeColor || '#777')));
      path.setAttribute('stroke-width', dots ? 0.8 : (e.width || 1.0));
      path.setAttribute('marker-end', 'none');
      path.setAttribute('fill', 'none');
      g.appendChild(path);
      const edgeCol = selectedEdgeId === e.id
        ? (settings.theme === 'dark' ? '#fff' : '#1a1a1a')
        : (settings.edgeColor || (settings.theme === 'dark' ? '#888' : '#666'));
      appendArrowHead(g, from, to, e, edgeCol);
      edgesLayer.appendChild(g);
    });
    applyViewTransform();
  }

  function setViewMode(mode) {
    if (viewMode === mode) return;
    const prev = viewMode;
    viewMode = mode;
    $$('#mode-toggle button').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));

    if (mode === 'dots' && currentProject && currentProject.nodes.length) {
      // Radial expand from center: points fly out into a circle
      animateDotsExpand();
    } else if (prev === 'dots' && mode === 'graph') {
      restoreGraphPositions();
      nodesLayer.style.opacity = '0';
      edgesLayer.style.opacity = '0';
      setTimeout(() => {
        renderGraph();
        requestAnimationFrame(() => {
          nodesLayer.style.opacity = '1';
          edgesLayer.style.opacity = '1';
        });
      }, 120);
    } else {
      renderGraph();
    }
  }

  function animateDotsExpand() {
    if (!currentProject) return;
    const nodes = currentProject.nodes;
    if (!nodes.length) { renderGraph(); return; }

    // Save original positions if not already
    nodes.forEach(n => {
      if (n._graphX === undefined) { n._graphX = n.x; n._graphY = n.y; }
    });

    // Center of mass
    let cx = 0, cy = 0;
    nodes.forEach(n => { cx += n._graphX; cy += n._graphY; });
    cx /= nodes.length; cy /= nodes.length;

    // Target positions on a circle
    const R = Math.max(120, 40 + nodes.length * 18);
    const targets = nodes.map((n, i) => {
      const a = (i / nodes.length) * Math.PI * 2 - Math.PI / 2;
      return { x: cx + Math.cos(a) * R, y: cy + Math.sin(a) * R };
    });

    // Start all at center
    nodes.forEach(n => { n.x = cx; n.y = cy; });
    renderGraph();

    const duration = 650;
    const t0 = performance.now();

    function frame(now) {
      const t = Math.min(1, (now - t0) / duration);
      // ease-out cubic
      const e = 1 - Math.pow(1 - t, 3);
      nodes.forEach((n, i) => {
        n.x = cx + (targets[i].x - cx) * e;
        n.y = cy + (targets[i].y - cy) * e;
      });
      renderGraph();
      if (t < 1) requestAnimationFrame(frame);
      else {
        // store dots positions, keep _graphX for return
        nodes.forEach((n, i) => { n.x = targets[i].x; n.y = targets[i].y; });
        renderGraph();
      }
    }
    requestAnimationFrame(frame);
  }

  function restoreGraphPositions() {
    if (!currentProject) return;
    currentProject.nodes.forEach(n => {
      if (n._graphX !== undefined) { n.x = n._graphX; n.y = n._graphY; }
    });
  }


  let _viewRaf = null;
  function applyViewTransform() {
    if (_viewRaf) return;
    _viewRaf = requestAnimationFrame(() => {
      _viewRaf = null;
      const t = 'translate(' + view.x + ',' + view.y + ') scale(' + view.scale + ')';
      edgesLayer.setAttribute('transform', t);
      nodesLayer.setAttribute('transform', t);
    });
  }
  function applyViewTransformNow() {
    if (_viewRaf) { cancelAnimationFrame(_viewRaf); _viewRaf = null; }
    const t = 'translate(' + view.x + ',' + view.y + ') scale(' + view.scale + ')';
    edgesLayer.setAttribute('transform', t);
    nodesLayer.setAttribute('transform', t);
  }

  function selectNode(id) {
    selectedNodeId = id; selectedEdgeId = null;
    closeEdgeSheet();
    closeNodeSheet();
    renderGraph();
  }
  function selectEdge(id) {
    selectedEdgeId = id; selectedNodeId = null;
    closeNodeSheet();
    renderGraph();
    openEdgeSheet(id);
  }

  // ===== POINTERS =====
  function setupGraphInteractions() {
    const el = graphContainer;
    el.addEventListener('pointerdown', onPointerDown);
    el.addEventListener('pointermove', onPointerMove);
    el.addEventListener('pointerup', onPointerUp);
    el.addEventListener('pointercancel', onPointerUp);
    el.addEventListener('wheel', onWheel, { passive: false });
    el.addEventListener('contextmenu', e => e.preventDefault());
  }

  function getSvgPoint(cx, cy) {
    const rect = graphSvg.getBoundingClientRect();
    return { x: (cx - rect.left - view.x) / view.scale, y: (cy - rect.top - view.y) / view.scale };
  }

  function hitTestNode(cx, cy) {
    const pt = getSvgPoint(cx, cy);
    if (!currentProject) return null;
    for (let i = currentProject.nodes.length - 1; i >= 0; i--) {
      const n = currentProject.nodes[i];
      if (viewMode === 'dots') {
        const dx = n.x - pt.x, dy = n.y - pt.y;
        if (dx * dx + dy * dy <= 14 * 14) return n.id;
        continue;
      }
      if (isPhotoNode(n) || n.type === 'photo' || n.type === 'image') {
        const { w, h } = photoSize(n);
        if (Math.abs(pt.x - n.x) <= w / 2 + 6 && Math.abs(pt.y - n.y) <= h / 2 + 6) return n.id;
        continue;
      }
      if (isTextNode(n)) {
        const { w, h } = textNodeSize(n);
        if (Math.abs(pt.x - n.x) <= w / 2 + 6 && Math.abs(pt.y - n.y) <= h / 2 + 6) return n.id;
        continue;
      }
      if ((settings.iconStyle || 'colored') === 'text' && viewMode === 'graph') {
        const mainText = n.label || n.value || '—';
        const tw = Math.max(48, Math.min(320, mainText.length * 7.2 + 28));
        const th = 36;
        if (Math.abs(pt.x - n.x) <= tw / 2 + 4 && Math.abs(pt.y - n.y) <= th / 2 + 4) return n.id;
        continue;
      }
      const r = nodeRadius(n) + 6;
      const dx = n.x - pt.x, dy = n.y - pt.y;
      if (dx * dx + dy * dy <= r * r) return n.id;
    }
    return null;
  }


  function hitTestEdgeCtrl(cx, cy) {
    if (!selectedEdgeId || !currentProject || viewMode === 'dots') return null;
    const e = currentProject.edges.find(x => x.id === selectedEdgeId);
    if (!e) return null;
    const from = currentProject.nodes.find(n => n.id === e.from);
    const to = currentProject.nodes.find(n => n.id === e.to);
    if (!from || !to) return null;
    const ctrl = getEdgeControl(from, to, e);
    const pt = getSvgPoint(cx, cy);
    const dx = ctrl.x - pt.x, dy = ctrl.y - pt.y;
    if (dx * dx + dy * dy <= 16 * 16) return e.id;
    return null;
  }

  function hitTestHandle(cx, cy) {
    if (!selectedNodeId || !currentProject || viewMode === 'dots') return null;
    const node = currentProject.nodes.find(n => n.id === selectedNodeId);
    if (!node) return null;
    const pt = getSvgPoint(cx, cy);
    let hx, hy;
    if (isPhotoNode(node) || node.type === 'photo' || node.type === 'image') {
      const { w, h } = photoSize(node);
      hx = w / 2 + 2; hy = h / 2 + 2;
    } else if (isTextNode(node)) {
      const { w, h } = textNodeSize(node);
      hx = w / 2 + 4; hy = h / 2 + 4;
    } else if ((settings.iconStyle || 'colored') === 'text') {
      const mainText = node.label || node.value || '—';
      const tw = Math.max(48, Math.min(320, mainText.length * 7.2 + 28));
      const th = 28;
      hx = tw / 2 + 4; hy = th / 2 + 4;
    } else {
      const r = nodeRadius(node);
      hx = r + 2; hy = r + 2;
    }
    const handles = [
      [node.x, node.y - hy],
      [node.x + hx, node.y],
      [node.x, node.y + hy],
      [node.x - hx, node.y]
    ];
    for (const h of handles) {
      const dx = h[0] - pt.x, dy = h[1] - pt.y;
      if (dx * dx + dy * dy <= 16 * 16) return selectedNodeId;
    }
    return null;
  }

  function onPointerDown(e) {
    if (e.button === 2) return;
    graphContainer.setPointerCapture(e.pointerId);
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (pointers.size === 1) {
      lastPointer = { x: e.clientX, y: e.clientY };
      longPressTriggered = false;

      const edgeCtrl = hitTestEdgeCtrl(e.clientX, e.clientY);
      if (edgeCtrl) {
        isDraggingEdgeCtrl = true; dragEdgeCtrlId = edgeCtrl;
        isPanning = false; isDraggingNode = false; isLinking = false;
        clearTimeout(longPressTimer);
        return;
      }

      const handleNode = hitTestHandle(e.clientX, e.clientY);
      if (handleNode) {
        isLinking = true; linkFromId = handleNode;
        isDraggingNode = false; dragNodeId = null; isPanning = false;
        clearTimeout(longPressTimer);
        createTempEdge(handleNode, e.clientX, e.clientY);
        return;
      }

      const nodeId = hitTestNode(e.clientX, e.clientY);
      if (nodeId) {
        dragNodeId = nodeId; isDraggingNode = false; isLinking = false;
        longPressTimer = setTimeout(() => {
          longPressTriggered = true; isDraggingNode = false; dragNodeId = null;
          selectedNodeId = nodeId; selectedEdgeId = null;
          renderGraph();
          openNodeSheet(nodeId);
        }, 450);
      } else {
        isPanning = true; isLinking = false;
        // double-tap detection for add — no UI flash
        const t = Date.now();
        const dx = e.clientX - lastTap.x, dy = e.clientY - lastTap.y;
        if (t - lastTap.time < 320 && dx * dx + dy * dy < 1200) {
          isPanning = false;
          const pt = getSvgPoint(e.clientX, e.clientY);
          pendingAddPos = { x: pt.x, y: pt.y };
          lastTap = { time: 0, x: 0, y: 0 };
          // Block accidental type selection from the same double-tap gesture
          ignoreModalClickUntil = Date.now() + 350;
          setTimeout(() => openTypePicker(), 40);
        } else {
          lastTap = { time: t, x: e.clientX, y: e.clientY };
          if (selectedNodeId || selectedEdgeId) {
            selectedNodeId = null; selectedEdgeId = null;
            closeNodeSheet(); closeEdgeSheet(); hideContextMenu();
            renderGraph();
          }
        }
      }
    } else if (pointers.size === 2) {
      clearTimeout(longPressTimer);
      isPanning = false; isDraggingNode = false; isLinking = false;
      dragNodeId = null; removeTempEdge();
      const pts = Array.from(pointers.values());
      lastPinchDist = dist(pts[0], pts[1]);
    }
  }

  function onPointerMove(e) {
    if (!pointers.has(e.pointerId)) return;
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (pointers.size === 2) {
      const pts = Array.from(pointers.values());
      const d = dist(pts[0], pts[1]);
      if (lastPinchDist > 0) {
        const rect = graphSvg.getBoundingClientRect();
        const cx = (pts[0].x + pts[1].x) / 2 - rect.left;
        const cy = (pts[0].y + pts[1].y) / 2 - rect.top;
        const factor = d / lastPinchDist;
        const newScale = Math.min(3, Math.max(0.15, view.scale * factor));
        view.x = cx - (cx - view.x) * (newScale / view.scale);
        view.y = cy - (cy - view.y) * (newScale / view.scale);
        view.scale = newScale;
        applyViewTransform();
        // re-render for LOD if crossed threshold
        updateLodClass();
      }
      lastPinchDist = d;
      return;
    }
    if (pointers.size !== 1) return;

    const dx = e.clientX - lastPointer.x;
    const dy = e.clientY - lastPointer.y;

    if (isDraggingEdgeCtrl && dragEdgeCtrlId) {
      const edge = currentProject.edges.find(x => x.id === dragEdgeCtrlId);
      if (edge) {
        const pt = getSvgPoint(e.clientX, e.clientY);
        edge.cx = pt.x;
        edge.cy = pt.y;
        scheduleEdgeRefresh();
      }
    } else if (isLinking && linkFromId) {
      updateTempEdge(e.clientX, e.clientY);
    } else if (dragNodeId) {
      if (Math.abs(dx) + Math.abs(dy) > 5) { clearTimeout(longPressTimer); isDraggingNode = true; }
      if (isDraggingNode) {
        const node = currentProject.nodes.find(n => n.id === dragNodeId);
        if (node) {
          node.x += dx / view.scale;
          node.y += dy / view.scale;
          // lightweight: only move the node group + refresh edges (no full rebuild of all nodes)
          const el = nodesLayer.querySelector(`[data-node-id="${dragNodeId}"]`);
          if (el) el.setAttribute('transform', `translate(${node.x},${node.y})`);
          scheduleEdgeRefresh();
        }
      }
    } else if (isPanning) {
      view.x += dx; view.y += dy; applyViewTransform();
    }
    lastPointer = { x: e.clientX, y: e.clientY };
  }

  function onPointerUp(e) {
    clearTimeout(longPressTimer);
    pointers.delete(e.pointerId);
    if (pointers.size < 2) lastPinchDist = 0;

    if (pointers.size === 0) {
      if (isDraggingEdgeCtrl) {
        pushHistory(); touchProject();
        isDraggingEdgeCtrl = false; dragEdgeCtrlId = null;
        renderGraph();
      } else if (isLinking && linkFromId) {
        const targetId = hitTestNode(e.clientX, e.clientY);
        if (targetId && targetId !== linkFromId) addEdge(linkFromId, targetId, 'связан с', '');
        removeTempEdge(); isLinking = false; linkFromId = null;
      } else if (dragNodeId && !isDraggingNode && !longPressTriggered) {
        selectNode(dragNodeId);
      } else if (isDraggingNode) {
        pushHistory(); touchProject();
        renderGraph(); // full sync after lightweight drag
      }
      isPanning = false; isDraggingNode = false; dragNodeId = null;
      isLinking = false; linkFromId = null;
    }
  }

  function onWheel(e) {
    e.preventDefault();
    const rect = graphSvg.getBoundingClientRect();
    const cx = e.clientX - rect.left, cy = e.clientY - rect.top;
    const factor = e.deltaY > 0 ? 0.92 : 1.08;
    const newScale = Math.min(3, Math.max(0.15, view.scale * factor));
    view.x = cx - (cx - view.x) * (newScale / view.scale);
    view.y = cy - (cy - view.y) * (newScale / view.scale);
    view.scale = newScale;
    applyViewTransform();
    updateLodClass();
  }

  let lodTimer = null;
  function updateLodClass() {
    const low = view.scale < LOD_THRESHOLD;
    graphContainer.classList.toggle('lod-low', low);
    // full rebuild only after zoom settles (photos need real LOD swap)
    clearTimeout(lodTimer);
    lodTimer = setTimeout(() => {
      if (!currentProject) return;
      const needsPhotoLod = currentProject.nodes.some(n => (n.type === 'photo' || n.type === 'image') && n.photoData);
      if (needsPhotoLod) renderGraph();
    }, 200);
  }

  function dist(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }

  function createTempEdge(fromId, cx, cy) {
    removeTempEdge();
    const from = currentProject.nodes.find(n => n.id === fromId); if (!from) return;
    const pt = getSvgPoint(cx, cy);
    tempEdgeEl = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    tempEdgeEl.setAttribute('class', 'temp-edge');
    tempEdgeEl.setAttribute('x1', from.x); tempEdgeEl.setAttribute('y1', from.y);
    tempEdgeEl.setAttribute('x2', pt.x); tempEdgeEl.setAttribute('y2', pt.y);
    edgesLayer.appendChild(tempEdgeEl);
  }
  function updateTempEdge(cx, cy) {
    if (!tempEdgeEl || !linkFromId) return;
    const from = currentProject.nodes.find(n => n.id === linkFromId); if (!from) return;
    const pt = getSvgPoint(cx, cy);
    tempEdgeEl.setAttribute('x1', from.x); tempEdgeEl.setAttribute('y1', from.y);
    tempEdgeEl.setAttribute('x2', pt.x); tempEdgeEl.setAttribute('y2', pt.y);
  }
  function removeTempEdge() {
    if (tempEdgeEl && tempEdgeEl.parentNode) tempEdgeEl.parentNode.removeChild(tempEdgeEl);
    tempEdgeEl = null;
  }

  // Sheets

  function getOpenTargets(n) {
    if (!n) return [];
    const targets = [];
    const seen = new Set();
    const add = (label, url) => {
      if (!url || seen.has(url)) return;
      seen.add(url);
      targets.push({ label, url });
    };
    const val = (n.value || n.label || '').trim();
    const type = n.type || '';

    // Direct URL
    if (/^https?:\/\//i.test(val)) add('Открыть ссылку', val);
    if (type === 'url' && val && !/^https?:\/\//i.test(val)) add('Открыть', 'https://' + val.replace(/^\/\//, ''));

    // Domain / website
    if ((type === 'domain' || type === 'website' || type === 'ns' || type === 'mx') && val && !/\s/.test(val)) {
      const host = val.replace(/^https?:\/\//i, '').split('/')[0];
      add('Открыть сайт', 'https://' + host);
      add('WHOIS (rdap.org)', 'https://rdap.org/domain/' + encodeURIComponent(host));
    }

    // Email
    if (type === 'email' || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) {
      add('Написать email', 'mailto:' + val);
      const domain = val.includes('@') ? val.split('@')[1] : '';
      if (domain) add('Домен почты', 'https://' + domain);
    }

    // Phone
    if (type === 'phone' || /^\+?[\d\s\-()]{8,}$/.test(val.replace(/\s/g, ''))) {
      const tel = val.replace(/[^\d+]/g, '');
      add('Позвонить', 'tel:' + tel);
    }

    // Coordinates / geolocation
    const coordMatch = val.match(/(-?\d{1,3}(?:\.\d+)?)\s*[,;\s]\s*(-?\d{1,3}(?:\.\d+)?)/);
    if (type === 'geolocation' || type === 'location' || (coordMatch && type !== 'phone')) {
      if (coordMatch) {
        const lat = coordMatch[1], lon = coordMatch[2];
        // sanity: lat -90..90 lon -180..180
        if (Math.abs(parseFloat(lat)) <= 90 && Math.abs(parseFloat(lon)) <= 180) {
          add('Google Maps', 'https://www.google.com/maps?q=' + encodeURIComponent(lat + ',' + lon));
          add('OpenStreetMap', 'https://www.openstreetmap.org/?mlat=' + lat + '&mlon=' + lon + '#map=12/' + lat + '/' + lon);
        }
      } else if (type === 'location' && val) {
        add('Google Maps', 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(val));
      }
    }

    // Username / social — platform profiles
    if (type === 'username' || type === 'social' || type === 'account') {
      const u = val.replace(/^@/, '');
      if (u) {
        add('Telegram', 'https://t.me/' + encodeURIComponent(u));
        add('GitHub', 'https://github.com/' + encodeURIComponent(u));
        add('X / Twitter', 'https://x.com/' + encodeURIComponent(u));
        add('Instagram', 'https://instagram.com/' + encodeURIComponent(u));
        add('VK', 'https://vk.com/' + encodeURIComponent(u));
        add('Reddit', 'https://reddit.com/user/' + encodeURIComponent(u));
      }
    }

    // IP
    if (type === 'ip' && val) {
      add('ipapi.co', 'https://ipapi.co/' + encodeURIComponent(val) + '/');
      add('RDAP', 'https://rdap.org/ip/' + encodeURIComponent(val));
    }

    // Evidence URLs
    (n.evidence || []).forEach(ev => {
      if (ev.url && /^https?:\/\//i.test(ev.url)) {
        add(ev.source ? ('Источник: ' + ev.source) : 'Evidence', ev.url);
      }
    });

    // Hash — search
    if (type === 'hash' && val) {
      add('Google', 'https://www.google.com/search?q=' + encodeURIComponent(val));
    }

    // Person — search
    if (type === 'person' && val) {
      add('Google', 'https://www.google.com/search?q=' + encodeURIComponent(val));
      add('Wikipedia', 'https://en.wikipedia.org/wiki/Special:Search?search=' + encodeURIComponent(val));
    }

    return targets;
  }

  function openExternal(url) {
    if (!url) return;
    try {
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (e) {
      location.href = url;
    }
  }

  function showOpenTargetsForNode(nodeId) {
    const n = currentProject && currentProject.nodes.find(x => x.id === nodeId);
    const targets = getOpenTargets(n);
    if (!targets.length) { toast('Некуда перейти'); return; }
    if (targets.length === 1) {
      openExternal(targets[0].url);
      return;
    }
    const box = $('#open-targets');
    if (!box) {
      openExternal(targets[0].url);
      return;
    }
    box.classList.remove('hidden');
    box.innerHTML = targets.map((t, i) =>
      `<button type="button" class="open-target-btn" data-url="${t.url.replace(/"/g, '&quot;')}">${escapeHtml(t.label)}</button>`
    ).join('');
    box.querySelectorAll('.open-target-btn').forEach(btn => {
      btn.onclick = () => openExternal(btn.dataset.url);
    });
  }

  function openNodeSheet(id) {
    const n = currentProject.nodes.find(x => x.id === id); if (!n) return;
    const t = NODE_TYPES[n.type] || NODE_TYPES.other;
    $('#sheet-type-badge').textContent = t.label;
    $('#sheet-title').textContent = n.label || n.value || '—';
    $('#sheet-value').textContent = n.value || '—';
    $('#sheet-description').textContent = n.description || '—';
    $('#sheet-source').textContent = n.source || '—';
    $('#sheet-date').textContent = formatDate(n.createdAt);
    $('#sheet-notes').textContent = n.notes || '—';
    const tagsEl = $('#sheet-tags');
    if (tagsEl) tagsEl.textContent = (n.tags && n.tags.length) ? n.tags.join(', ') : '—';
    const evBox = $('#sheet-evidence');
    if (evBox) {
      const list = n.evidence || [];
      const sc = n.sourceCount || new Set(list.map(e => e.source)).size;
      if (!list.length) evBox.innerHTML = '—';
      else {
        evBox.innerHTML = `<p class="ev-meta">Sources confirming: <strong>${sc}</strong>` +
          (n.lastCheckedAt ? ` · last check ${escapeHtml(String(n.lastCheckedAt).replace('T', ' ').slice(0, 19))}` : '') +
          (n.recheckStatus ? ` · <strong>${escapeHtml(n.recheckStatus)}</strong>` : '') +
          `</p>` +
          list.map(ev => {
          const st = ev.status || 'unknown';
          const stLabel = st === 'confirmed' ? 'Confirmed' : st === 'possible' ? 'Possible' : st === 'unverified' ? 'Needs review' : 'Unknown';
          const why = ev.why || ev.finding || '';
          return `<div class="evidence-card">
            <span class="ev-status ${st}">${stLabel}</span>
            <div><strong>${escapeHtml(ev.source || '')}</strong></div>
            <div>${escapeHtml(ev.finding || '')}</div>
            ${why ? `<div class="ev-why"><em>Why was this added?</em> ${escapeHtml(why)}</div>` : ''}
            ${n.confidence ? `<div class="ev-why"><em>Confidence:</em> ${escapeHtml(n.confidence)}${n.confidenceReason ? ' — ' + escapeHtml(n.confidenceReason) : ''}</div>` : ''}
            ${ev.url ? `<div style="word-break:break-all;opacity:.8"><a href="${escapeHtml(ev.url)}" target="_blank" rel="noopener">${escapeHtml(ev.url)}</a></div>` : ''}
            <div class="ev-time">${ev.foundAt ? new Date(ev.foundAt).toLocaleString() : ''}</div>
          </div>`;
        }).join('');
      }
    }
    $('#sheet-node-size').value = n.size || settings.nodeSize;

    const pp = $('#sheet-photo-preview');
    // IP geo estimate disclaimer + metadata
    if (n.type === 'geo_estimate' || (n.metadata && n.metadata.kind === 'ip_geolocation_estimate')) {
      const m = n.metadata || {};
      const lines = [
        '<strong>📍 IP GEOLOCATION ESTIMATE</strong>',
        'Not a verified physical location of any person.',
        m.provider ? ('Source: ' + m.provider) : '',
        m.confidence ? ('Confidence: ' + m.confidence) : '',
        'Accuracy: ' + (m.accuracy || 'unknown'),
        m.country ? ('Country: ' + m.country) : '',
        m.region ? ('Region: ' + m.region) : '',
        m.city ? ('City: ' + m.city) : '',
        (m.lat != null && m.lon != null) ? ('Coords: ' + m.lat + ', ' + m.lon) : '',
        m.conflict ? '<em>Conflicting estimates across providers</em>' : '',
        m.timestamp ? ('Checked: ' + m.timestamp) : ''
      ].filter(Boolean);
      const disc = document.createElement('div');
      disc.className = 'geo-disclaimer';
      disc.style.cssText = 'margin:8px 0;padding:8px 10px;background:rgba(180,83,9,.12);border:1px solid rgba(180,83,9,.35);border-radius:8px;font-size:12px;line-height:1.4;';
      disc.innerHTML = lines.join('<br>');
      const evBox = $('#sheet-evidence') || $('#sheet-meta');
      if (evBox && evBox.parentNode) evBox.parentNode.insertBefore(disc, evBox);
      else if ($('#sheet-title')) $('#sheet-title').after(disc);
      // Always add evidence note
      n.evidence = n.evidence || [];
      if (!n.evidence.some(e => /does not establish/i.test(e.finding || e.why || ''))) {
        n.evidence.unshift({
          source: m.provider || 'geo-db',
          url: m.sourceUrl || '',
          foundAt: m.timestamp || now(),
          finding: 'IP geolocation is an estimate based on the provider\'s IP database and does not establish the user\'s physical location.',
          status: 'needs_review',
          why: 'Database range mapping only'
        });
      }
    }

    if (n.type === 'photo' && n.photoData) {
      pp.classList.remove('hidden');
      pp.innerHTML = `<img src="${n.photoData}" alt="photo">`;
    } else {
      pp.classList.add('hidden');
      pp.innerHTML = '';
    }
    // Open / Перейти
    const targets = getOpenTargets(n);
    const btnOpen = $('#btn-open-node');
    const boxOpen = $('#open-targets');
    if (boxOpen) { boxOpen.classList.add('hidden'); boxOpen.innerHTML = ''; }
    if (btnOpen) {
      if (targets.length) {
        btnOpen.classList.remove('hidden');
        btnOpen.dataset.count = String(targets.length);
      } else {
        btnOpen.classList.add('hidden');
      }
    }
    const btnImg = document.getElementById('btn-image-intel');
    if (btnImg) {
      if ((n.type === 'photo' || n.type === 'image') && n.photoData) btnImg.classList.remove('hidden');
      else btnImg.classList.add('hidden');
    }

    $('#node-sheet').classList.add('open');
  }
  function closeNodeSheet() {
    $('#node-sheet').classList.remove('open');
    const boxOpen = $('#open-targets');
    if (boxOpen) { boxOpen.classList.add('hidden'); boxOpen.innerHTML = ''; }
  }

  function openEdgeSheet(id) {
    const e = currentProject.edges.find(x => x.id === id); if (!e) return;
    $('#edge-type-edit').value = e.type || 'связан с';
    $('#edge-width').value = e.width || 1.0;
    $('#edge-curve').value = e.curve || 0;
    $('#edge-desc-edit').value = e.description || '';
    $('#edge-sheet').classList.add('open');
  }
  function closeEdgeSheet() { $('#edge-sheet').classList.remove('open'); }

  function showContextMenu(x, y, nodeId) {
    selectedNodeId = nodeId; renderGraph();
    const menu = $('#context-menu');
    menu.classList.remove('hidden');
    menu.style.left = Math.min(x, window.innerWidth - 180) + 'px';
    menu.style.top = Math.min(y, window.innerHeight - 160) + 'px';
    menu.dataset.nodeId = nodeId;
  }
  function hideContextMenu() { $('#context-menu').classList.add('hidden'); }

  // Node CRUD
  function addNode(data) {
    if (!currentProject) return;
    let x, y;
    if (pendingAddPos) {
      x = pendingAddPos.x; y = pendingAddPos.y;
      pendingAddPos = null;
    } else if (data.x != null && data.y != null) {
      x = data.x; y = data.y;
    } else {
      const rect = graphSvg.getBoundingClientRect();
      x = (rect.width / 2 - view.x) / view.scale + (Math.random() - 0.5) * 40;
      y = (rect.height / 2 - view.y) / view.scale + (Math.random() - 0.5) * 40;
    }
    const node = {
      id: uid(), type: data.type || 'other', label: data.label || '', value: data.value || '',
      description: data.description || '', source: data.source || '', notes: data.notes || '',
      tags: Array.isArray(data.tags) ? data.tags : (data.tags ? String(data.tags).split(',').map(s=>s.trim()).filter(Boolean) : []),
      photoData: data.photoData || null,
      photoRatio: data.photoRatio || 1,
      size: data.size || ((data.type === 'photo' || data.type === 'image' || data.photoData) ? 160 : settings.nodeSize),
      evidence: data.evidence || [],
      metadata: data.metadata || null,
      confidence: data.confidence || null,
      createdAt: now(), x, y
    };
    if (!data.skipHistory) pushHistory();
    currentProject.nodes.push(node);
    addTimelineEvent({
      type: 'node',
      message: 'Найден / добавлен: ' + (node.label || node.value || node.type),
      nodeId: node.id
    });
    touchProject(); renderGraph(); updateLists(); updateMinimap();
    if (!data.silent) {
      selectNode(node.id);
      toast('Объект добавлен');
    }
    // Background analysis queue (non-blocking)
    try {
      if (window.NexusBackground && !data.skipBackground) {
        NexusBackground.enqueueEntity(node, {
          priority: data.silent ? 'NORMAL' : 'HIGH',
          source: data.source || 'user',
          isRoot: !data.silent
        });
      }
    } catch (_) {}
    return node;
  }

  function ensureTimeline() {
    if (!currentProject) return;
    if (!currentProject.timeline) currentProject.timeline = [];
  }

  function addTimelineEvent(ev) {
    if (!currentProject) return;
    ensureTimeline();
    currentProject.timeline.unshift({
      id: uid(),
      time: now(),
      type: ev.type || 'info',
      message: ev.message || '',
      nodeId: ev.nodeId || null,
      edgeId: ev.edgeId || null
    });
    // keep last 200
    if (currentProject.timeline.length > 200) currentProject.timeline.length = 200;
  }

  function makeEvidence(source, url, finding, status, why) {
    return {
      source: source || 'unknown',
      url: url || '',
      foundAt: now(),
      finding: finding || '',
      status: status || 'unverified',
      why: why || finding || ''
    };
  }


  function updateNode(id, data) {
    const n = currentProject.nodes.find(x => x.id === id); if (!n) return;
    pushHistory();
    Object.assign(n, {
      type: data.type, label: data.label, value: data.value,
      description: data.description, source: data.source, notes: data.notes
    });
    if (data.photoData !== undefined) n.photoData = data.photoData;
    if (data.photoRatio !== undefined) n.photoRatio = data.photoRatio;
    touchProject(); renderGraph(); updateLists();
    if (selectedNodeId === id) openNodeSheet(id);
    toast('Сохранено');
  }

  function deleteNode(id) {
    pushHistory();
    currentProject.nodes = currentProject.nodes.filter(n => n.id !== id);
    currentProject.edges = currentProject.edges.filter(e => e.from !== id && e.to !== id);
    // cleanup clip paths
    const clip = document.getElementById('clip_' + id);
    if (clip) clip.remove();
    if (selectedNodeId === id) { selectedNodeId = null; closeNodeSheet(); }
    touchProject(); renderGraph(); updateLists();
    toast('Удалено');
  }

  function addEdge(fromId, toId, type, description) {
    if (!currentProject || fromId === toId) return;
    if (currentProject.edges.some(e => (e.from === fromId && e.to === toId) || (e.from === toId && e.to === fromId))) {
      toast('Связь уже есть'); return;
    }
    pushHistory();
    const edge = {
      id: uid(), from: fromId, to: toId, type: type || 'связан с',
      description: description || '', width: 1.5, curve: 0, createdAt: now(),
      evidence: []
    };
    currentProject.edges.push(edge);
    addTimelineEvent({
      type: 'edge',
      message: 'Обнаружена связь: ' + (type || 'связан с'),
      nodeId: toId,
      edgeId: edge.id
    });
    touchProject(); renderGraph(); updateLists(); updateMinimap();
    toast('Связь создана');
  }

  function updateEdge(id, data) {
    const e = currentProject.edges.find(x => x.id === id); if (!e) return;
    pushHistory();
    Object.assign(e, data);
    touchProject(); renderGraph();
    toast('Связь обновлена');
  }

  function deleteEdge(id) {
    pushHistory();
    currentProject.edges = currentProject.edges.filter(e => e.id !== id);
    selectedEdgeId = null; closeEdgeSheet();
    touchProject(); renderGraph(); updateLists();
    toast('Связь удалена');
  }

  // Lists
  function updateLists() {
    if (!currentProject) return;
    const nodes = currentProject.nodes, edges = currentProject.edges;
    $('#objects-count').textContent = nodes.length;
    $('#links-count').textContent = edges.length;

    const objList = $('#objects-list');
    if (!nodes.length) objList.innerHTML = '<div class="empty-state"><p>Нет объектов</p></div>';
    else {
      objList.innerHTML = nodes.map(n => {
        const t = NODE_TYPES[n.type] || NODE_TYPES.other;
        return `<div class="list-item" data-id="${n.id}">
          <div class="type-dot" style="background:${MALTEGO_COLORS[n.type] || '#333'}"></div>
          <div class="info"><strong>${escapeHtml(n.label || n.value || '—')}</strong>
          <span>${t.label}</span></div></div>`;
      }).join('');
      objList.querySelectorAll('.list-item').forEach(item => {
        item.onclick = () => {
          selectNode(item.dataset.id);
          centerOnNode(item.dataset.id);
          openNodeSheet(item.dataset.id);
          closeAllPanels();
        };
      });
    }

    const linkList = $('#links-list');
    if (!edges.length) linkList.innerHTML = '<div class="empty-state"><p>Нет связей</p></div>';
    else {
      linkList.innerHTML = edges.map(e => {
        const from = nodes.find(n => n.id === e.from);
        const to = nodes.find(n => n.id === e.to);
        return `<div class="list-item" data-id="${e.id}">
          <div class="info"><strong>${escapeHtml((from && (from.label || from.value)) || '?')} → ${escapeHtml((to && (to.label || to.value)) || '?')}</strong>
          <span>${escapeHtml(e.type)}</span></div>
          <button class="icon-btn-sm del-edge" data-id="${e.id}">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#b00020" stroke-width="2"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
          </button></div>`;
      }).join('');
      linkList.querySelectorAll('.del-edge').forEach(btn => {
        btn.onclick = ev => { ev.stopPropagation(); deleteEdge(btn.dataset.id); };
      });
      linkList.querySelectorAll('.list-item').forEach(item => {
        item.onclick = () => { selectEdge(item.dataset.id); closeAllPanels(); };
      });
    }
  }

  function centerOnNode(id) {
    const n = currentProject.nodes.find(x => x.id === id); if (!n) return;
    const rect = graphSvg.getBoundingClientRect();
    view.x = rect.width / 2 - n.x * view.scale;
    view.y = rect.height / 2 - n.y * view.scale;
    applyViewTransform();
  }

  // Drawer & panels
  function openDrawer() {
    $('#drawer').classList.add('open');
    $('#drawer-overlay').classList.remove('hidden');
  }
  function closeDrawer() {
    $('#drawer').classList.remove('open');
    $('#drawer-overlay').classList.add('hidden');
  }
  function openPanel(name) {
    closeAllPanels();
    const p = $(`#panel-${name}`);
    if (p) p.classList.add('open');
  }
  function closeAllPanels() {
    $$('.side-panel').forEach(p => p.classList.remove('open'));
    closeNodeSheet(); closeEdgeSheet(); hideContextMenu();
  }

  // Modals
  function openModal(id) {
    $('#modal-overlay').classList.remove('hidden');
    $$('.modal').forEach(m => m.classList.add('hidden'));
    const m = $(`#${id}`); if (m) m.classList.remove('hidden');
  }
  function closeModal() {
    $('#modal-overlay').classList.add('hidden');
    $$('.modal').forEach(m => m.classList.add('hidden'));
  }


  function detectType(text) {
    const t = (text || '').trim();
    if (!t) return 'other';
    if (/^(\d{1,3}\.){3}\d{1,3}$/.test(t)) return 'ip';
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(t)) return 'email';
    if (/^https?:\/\//i.test(t) || /^www\./i.test(t)) return 'url';
    if (/^(\+?\d[\d\-\s]{7,})$/.test(t)) return 'phone';
    if (/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(t) && !t.includes(' ')) return 'domain';
    if (/^@[\w.]+$/.test(t)) return 'username';
    if (/^[0-9a-f]{32}$/i.test(t) || /^[0-9a-f]{40}$/i.test(t) || /^[0-9a-f]{64}$/i.test(t)) return 'hash';
    return 'person';
  }

  function pickPhotoAndCreate(type) {
    type = type || 'photo';
    const input = document.getElementById('photo-file-input');
    if (!input) { toast('Нет доступа к галерее'); return; }
    input.value = '';
    const onPick = async (e) => {
      input.removeEventListener('change', onPick);
      const file = e.target.files && e.target.files[0];
      if (!file) { toast('Файл не выбран'); return; }
      try {
        toast('Обработка фото…');
        const result = await compressImage(file);
        if (!result || !result.dataUrl) throw new Error('empty image');
        const name = (file.name || 'Фото').replace(/\.[^.]+$/, '').slice(0, 40) || 'Фото';
        const node = addNode({
          type: 'photo',
          label: name,
          value: name,
          description: '',
          source: 'gallery',
          notes: '',
          photoData: result.dataUrl,
          photoRatio: result.ratio || 1,
          size: 160
        });
        if (node && selectedNodeId !== node.id) {
          selectedNodeId = node.id;
        }
        renderGraph();
        updateLists();
        toast('Фото на графе');
      } catch (err) {
        console.error(err);
        toast('Не удалось загрузить: ' + (err.message || 'ошибка'));
      }
    };
    input.addEventListener('change', onPick, { once: true });
    // Must stay in same user-gesture stack (mobile)
    input.click();
  }

  function photoInputModalHandler(e) {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    compressImage(file).then(result => {
      pendingPhotoData = result.dataUrl;
      pendingPhotoRatio = result.ratio;
      const st = document.getElementById('photo-status');
      const th = document.getElementById('photo-thumb');
      if (st) st.textContent = 'Фото загружено';
      if (th) {
        th.classList.remove('hidden');
        th.innerHTML = '<img src="' + pendingPhotoData + '">';
      }
    }).catch(() => toast('Ошибка фото'));
  }

  function openQuickAdd(clientX, clientY) {
    const qa = $('#quick-add');
    const input = $('#quick-add-input');
    const rect = graphContainer.getBoundingClientRect();
    let left = clientX - rect.left;
    let top = clientY - rect.top;
    left = Math.max(20, Math.min(left, rect.width - 20));
    top = Math.max(40, Math.min(top, rect.height - 20));
    qa.style.left = left + 'px';
    qa.style.top = top + 'px';
    qa.classList.remove('hidden');
    input.value = '';
    setTimeout(() => { input.focus(); input.click(); }, 40);
  }

  function closeQuickAdd() {
    $('#quick-add').classList.add('hidden');
    $('#quick-add-input').blur();
  }

  function submitQuickAdd() {
    const val = ($('#quick-add-input').value || '').trim();
    closeQuickAdd();
    if (!val) { pendingAddPos = null; return; }
    const type = detectType(val);
    addNode({
      type,
      label: val,
      value: val,
      description: '',
      source: 'manual',
      notes: '',
      photoData: null
    });
  }


  // ========== ENHANCED LOOKUP ENGINE ==========
  async function fetchJSON(url, opts = {}) {
    const ctrl = AbortSignal.timeout(opts.timeout || 10000);
    const r = await fetch(url, { ...opts, signal: ctrl });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  }
  async function fetchText(url, opts = {}) {
    const ctrl = AbortSignal.timeout(opts.timeout || 10000);
    const r = await fetch(url, { ...opts, signal: ctrl });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.text();
  }
  async function settleAll(tasks) {
    const results = await Promise.allSettled(tasks);
    return results.map(r => r.status === 'fulfilled' ? r.value : { __err: r.reason?.message || String(r.reason) });
  }

  async function lookupNode(nodeId) {
    const n = currentProject.nodes.find(x => x.id === nodeId);
    if (!n) return;
    const val = (n.value || n.label || '').trim();
    if (!val) { toast('Нет значения для lookup'); return; }

    openTerminal('lookup · ' + val);
    termLog('$ nexus lookup "' + val + '"');
    termLog('type: ' + ((NODE_TYPES[n.type] || {}).label || n.type));
    termLog('time: ' + new Date().toISOString());
    termLog('—'.repeat(40));
    termLog('');

    try {
      if (n.type === 'ip' || /^(\d{1,3}\.){3}\d{1,3}$/.test(val) || /^[0-9a-f:]+$/i.test(val) && val.includes(':')) {
        await lookupIP(val, n);
      } else if (n.type === 'phone' || /^[+]?[\d\s\-()]{8,}$/.test(val.replace(/\s/g, ''))) {
        await lookupPhone(val, n);
      } else if (n.type === 'person' || n.type === 'alias' || n.type === 'account' ||
                 (n.type === 'other' && /[A-Za-zА-Яа-яЁё]{2,}\s+[A-Za-zА-Яа-яЁё]{2,}/.test(val))) {
        await lookupPerson(val, n);
      } else if (n.type === 'domain' || n.type === 'url' || n.type === 'website' ||
                 /^[a-z0-9.-]+\.[a-z]{2,}$/i.test(val.replace(/^https?:\/\//, '').split('/')[0])) {
        const host = val.replace(/^https?:\/\//i, '').split('/')[0].split(':')[0];
        await lookupDomain(host, n);
      } else if (n.type === 'email' || val.includes('@')) {
        await lookupEmail(val, n);
      } else if (n.type === 'username' || n.type === 'social' || /^@/.test(val)) {
        await lookupUsername(val, n);
      } else if (n.type === 'hash' || /^[0-9a-f]{32}$/i.test(val) || /^[0-9a-f]{40}$/i.test(val) || /^[0-9a-f]{64}$/i.test(val)) {
        await lookupHash(val, n);
      } else {
        termLog('[*] Auto-detect → person search');
        termLog('');
        await lookupPerson(val, n);
      }
    } catch (err) {
      termLog('');
      termLog('FATAL: ' + (err.message || err));
    }
  }

  async function lookupEmail(email, sourceNode) {
    const [local, domain] = email.split('@');
    termLog('[*] Email analysis');
    termLog('local:  ' + local);
    termLog('domain: ' + domain);
    termLog('');
    const suggestions = [];
    if (domain) {
      await lookupDomain(domain, sourceNode, true);
    }
    termLog('');
    termLog('[*] Local-part as name…');
    const nameGuess = local.replace(/[._+\d]/g, ' ').replace(/\s+/g, ' ').trim();
    if (nameGuess.length >= 3) {
      suggestions.push({ type: 'person', label: nameGuess, value: nameGuess, link: 'имеет email' });
      await lookupPerson(nameGuess, sourceNode, true);
    }
    suggestions.push({ type: 'username', label: local, value: local, link: 'имеет аккаунт' });
    termLog('');
    renderTerminalSuggestions(sourceNode, suggestions);
  }

  async function lookupHash(hash, sourceNode) {
    termLog('[*] Hash analysis');
    const h = hash.toLowerCase();
    let algo = 'unknown';
    if (h.length === 32) algo = 'MD5';
    else if (h.length === 40) algo = 'SHA-1';
    else if (h.length === 64) algo = 'SHA-256';
    termLog('algorithm: ' + algo);
    termLog('length:    ' + h.length);
    termLog('');
    termLog('[*] Open sources (links to check):');
    const links = [
      { type: 'url', label: 'VirusTotal', value: 'https://www.virustotal.com/gui/search/' + h, link: 'проверяется в' },
      { type: 'url', label: 'Hybrid Analysis', value: 'https://www.hybrid-analysis.com/search?query=' + h, link: 'проверяется в' },
      { type: 'url', label: 'MalwareBazaar', value: 'https://bazaar.abuse.ch/browse.php?search=sha256%3A' + h, link: 'проверяется в' }
    ];
    links.forEach(l => termLog('  ' + l.label + ': ' + l.value));
    termLog('');
    renderTerminalSuggestions(sourceNode, links);
  }

  async function lookupPhone(raw, sourceNode) {
    const phone = raw.replace(/[^\d+]/g, '');
    termLog('[*] Phone DEEP analysis');
    termLog('input:  ' + raw);
    termLog('digits: ' + phone);
    termLog('');

    const suggestions = [];
    const prefixes = [
      { p: '+7', c: 'Russia / Kazakhstan', iso: 'RU/KZ' },
      { p: '8', c: 'Russia (domestic)', iso: 'RU' },
      { p: '+380', c: 'Ukraine', iso: 'UA' },
      { p: '+375', c: 'Belarus', iso: 'BY' },
      { p: '+1', c: 'USA / Canada', iso: 'US/CA' },
      { p: '+44', c: 'United Kingdom', iso: 'GB' },
      { p: '+49', c: 'Germany', iso: 'DE' },
      { p: '+33', c: 'France', iso: 'FR' },
      { p: '+90', c: 'Turkey', iso: 'TR' },
      { p: '+86', c: 'China', iso: 'CN' },
      { p: '+91', c: 'India', iso: 'IN' },
      { p: '+48', c: 'Poland', iso: 'PL' },
      { p: '+371', c: 'Latvia', iso: 'LV' },
      { p: '+372', c: 'Estonia', iso: 'EE' },
      { p: '+370', c: 'Lithuania', iso: 'LT' },
      { p: '+994', c: 'Azerbaijan', iso: 'AZ' },
      { p: '+995', c: 'Georgia', iso: 'GE' },
      { p: '+374', c: 'Armenia', iso: 'AM' },
      { p: '+998', c: 'Uzbekistan', iso: 'UZ' },
      { p: '+996', c: 'Kyrgyzstan', iso: 'KG' },
      { p: '+992', c: 'Tajikistan', iso: 'TJ' },
      { p: '+993', c: 'Turkmenistan', iso: 'TM' },
      { p: '+373', c: 'Moldova', iso: 'MD' },
      { p: '+40', c: 'Romania', iso: 'RO' },
      { p: '+359', c: 'Bulgaria', iso: 'BG' },
      { p: '+420', c: 'Czechia', iso: 'CZ' },
      { p: '+36', c: 'Hungary', iso: 'HU' },
      { p: '+39', c: 'Italy', iso: 'IT' },
      { p: '+34', c: 'Spain', iso: 'ES' },
      { p: '+46', c: 'Sweden', iso: 'SE' },
      { p: '+47', c: 'Norway', iso: 'NO' },
      { p: '+358', c: 'Finland', iso: 'FI' },
      { p: '+81', c: 'Japan', iso: 'JP' },
      { p: '+82', c: 'South Korea', iso: 'KR' },
      { p: '+61', c: 'Australia', iso: 'AU' },
      { p: '+55', c: 'Brazil', iso: 'BR' },
      { p: '+52', c: 'Mexico', iso: 'MX' },
      { p: '+971', c: 'UAE', iso: 'AE' },
      { p: '+972', c: 'Israel', iso: 'IL' },
      { p: '+90', c: 'Turkey', iso: 'TR' }
    ];
    let country = null;
    for (const x of prefixes.sort((a, b) => b.p.length - a.p.length)) {
      if (phone.startsWith(x.p) || phone.startsWith(x.p.replace('+', ''))) { country = x; break; }
    }
    if (country) {
      termLog('Country: ' + country.c + ' (' + country.iso + ')');
      suggestions.push({ type: 'location', label: country.c, value: country.iso, link: 'country_code' });
    } else termLog('Country: unknown prefix');
    termLog('Length:  ' + phone.replace('+', '').length + ' digits');
    termLog('');

    // RU DEF codes expanded
    if (phone.replace('+', '').startsWith('7') || phone.startsWith('8')) {
      const n10 = phone.replace(/\D/g, '').replace(/^8/, '7');
      const code = n10.slice(1, 4);
      termLog('DEF / area code: ' + code);
      const ops = {
        '900':'Tele2/Beeline', '901':'Beeline', '902':'Beeline/MegaFon', '903':'Beeline',
        '904':'Beeline/Tele2', '905':'Beeline', '906':'Beeline', '908':'MegaFon', '909':'MegaFon',
        '910':'MegaFon', '911':'MegaFon', '912':'MegaFon', '913':'MegaFon', '914':'MegaFon',
        '915':'MegaFon', '916':'MegaFon', '917':'MegaFon', '918':'MegaFon', '919':'MegaFon',
        '920':'MegaFon', '921':'MegaFon', '922':'MegaFon', '923':'MegaFon', '924':'MegaFon',
        '925':'MegaFon', '926':'MegaFon', '927':'MegaFon', '928':'MegaFon', '929':'MegaFon',
        '930':'MegaFon', '931':'MegaFon', '932':'MegaFon', '933':'MegaFon', '934':'MegaFon',
        '936':'MegaFon', '937':'MegaFon', '938':'MegaFon', '939':'MegaFon',
        '950':'Tele2', '951':'Tele2', '952':'Tele2', '953':'Tele2', '954':'Tele2',
        '955':'Tele2', '956':'Tele2', '958':'Tele2', '960':'Tele2', '961':'Tele2',
        '962':'Tele2', '963':'Tele2', '964':'Tele2', '965':'Tele2', '966':'Tele2',
        '967':'Tele2', '968':'Tele2', '969':'Tele2',
        '980':'MTS', '981':'MTS', '982':'MTS', '983':'MTS', '984':'MTS', '985':'MTS',
        '986':'MTS', '987':'MTS', '988':'MTS', '989':'MTS',
        '991':'MTS', '992':'MTS', '993':'MTS', '994':'MTS', '995':'MTS', '996':'MTS', '997':'MTS', '999':'MTS',
        '495':'Moscow landline', '499':'Moscow landline', '812':'SPb landline',
        '383':'Novosibirsk', '343':'Yekaterinburg', '383':'Novosibirsk'
      };
      if (ops[code]) {
        termLog('Likely operator / region: ' + ops[code]);
        suggestions.push({ type: 'organization', label: ops[code].split('/')[0], value: ops[code], link: 'использует' });
      } else termLog('Operator: unknown for DEF ' + code);
      termLog('');
    }

    termLog('[*] Online sources…');
    const e164 = phone.startsWith('+') ? phone : ('+' + phone.replace(/^8/, '7'));
    const results = await settleAll([
      fetchJSON('https://api.duckduckgo.com/?q=' + encodeURIComponent(phone + ' phone number') + '&format=json&no_redirect=1&no_html=1')
        .then(d => ({ src: 'ddg', d })),
      fetchJSON('https://api.duckduckgo.com/?q=' + encodeURIComponent(e164) + '&format=json&no_redirect=1&no_html=1')
        .then(d => ({ src: 'ddg-e164', d })),
      // htmlweb.ru free phone info (RU-oriented)
      fetchJSON('https://htmlweb.ru/json/service/phone/?tel=' + encodeURIComponent(phone.replace(/\D/g, '')) + '&json')
        .then(d => ({ src: 'htmlweb', d }))
        .catch(e => ({ src: 'htmlweb', __err: e.message }))
    ]);

    results.forEach(src => {
      if (!src) return;
      if (src.__err) { termLog('[!] ' + (src.src || '') + ': ' + src.__err); return; }
      if (src.src && src.src.startsWith('ddg')) {
        const d = src.d || {};
        termLog('[' + src.src + ']');
        if (d.AbstractText) termLog('  ' + d.AbstractText.slice(0, 280));
        (d.RelatedTopics || []).slice(0, 5).forEach(t => {
          if (t.Text) termLog('  · ' + t.Text.slice(0, 120));
        });
        if (!d.AbstractText && !(d.RelatedTopics || []).length) termLog('  (no instant answers)');
      }
      if (src.src === 'htmlweb' && src.d && !src.d.__err) {
        const d = src.d;
        termLog('[htmlweb.ru]');
        Object.keys(d).forEach(k => {
          if (typeof d[k] === 'string' || typeof d[k] === 'number') {
            termLog('  ' + k + ': ' + d[k]);
            if (/oper|operator|оператор/i.test(k) && d[k])
              suggestions.push({ type: 'organization', label: String(d[k]), value: String(d[k]), link: 'использует' });
            if (/region|region|область|город|city/i.test(k) && d[k])
              suggestions.push({ type: 'location', label: String(d[k]), value: String(d[k]), link: 'mentioned_at' });
          }
        });
      }
    });

    termLog('');
    termLog('[*] Formats:');
    termLog('  E.164:    ' + e164);
    termLog('  national: ' + phone.replace(/^\+?7/, '8').replace(/^\+/, ''));
    termLog('  digits:   ' + phone.replace(/\D/g, ''));
    termLog('');
    termLog('[+] Suggestions:');
    renderTerminalSuggestions(sourceNode, suggestions);
  }

  async function lookupPerson(name, sourceNode, quiet) {
    const q = name.trim().replace(/\s+/g, ' ');
    if (!quiet) {
      termLog('[*] Person / FIO DEEP search: "' + q + '"');
      termLog('    sources: Wikipedia×2 · Wikidata · DDG · GitHub · OpenLibrary');
      termLog('');
    }
    const suggestions = [];
    const seen = new Set();
    const addSug = (s) => {
      const k = s.type + '|' + (s.value || s.label);
      if (seen.has(k)) return;
      seen.add(k);
      suggestions.push(s);
    };
    const parts = q.split(' ').filter(Boolean);
    if (parts.length >= 2) {
      termLog('tokens: ' + parts.map((p, i) => '[' + i + '] ' + p).join('  '));
      termLog('');
    }

    termLog('[*] Parallel wave 1…');
    const wave1 = await settleAll([
      fetchJSON('https://ru.wikipedia.org/w/api.php?action=opensearch&search=' + encodeURIComponent(q) + '&limit=8&namespace=0&format=json&origin=*')
        .then(d => ({ src: 'wiki-ru', d })),
      fetchJSON('https://en.wikipedia.org/w/api.php?action=opensearch&search=' + encodeURIComponent(q) + '&limit=8&namespace=0&format=json&origin=*')
        .then(d => ({ src: 'wiki-en', d })),
      fetchJSON('https://www.wikidata.org/w/api.php?action=wbsearchentities&search=' + encodeURIComponent(q) + '&language=ru&uselang=ru&limit=10&format=json&origin=*')
        .then(d => ({ src: 'wikidata', d })),
      fetchJSON('https://www.wikidata.org/w/api.php?action=wbsearchentities&search=' + encodeURIComponent(q) + '&language=en&uselang=en&limit=8&format=json&origin=*')
        .then(d => ({ src: 'wikidata-en', d })),
      fetchJSON('https://api.duckduckgo.com/?q=' + encodeURIComponent(q) + '&format=json&no_redirect=1&no_html=1')
        .then(d => ({ src: 'ddg', d })),
      fetchJSON('https://api.duckduckgo.com/?q=' + encodeURIComponent('"' + q + '"') + '&format=json&no_redirect=1&no_html=1')
        .then(d => ({ src: 'ddg-exact', d })),
      fetchJSON('https://api.github.com/search/users?q=' + encodeURIComponent(q) + '&per_page=5')
        .then(d => ({ src: 'github', d })),
      fetchJSON('https://openlibrary.org/search/authors.json?q=' + encodeURIComponent(q) + '&limit=5')
        .then(d => ({ src: 'openlibrary', d }))
    ]);

    const wikiTitles = [];
    wave1.forEach(src => {
      if (!src || src.__err) {
        if (src && src.__err) termLog('[!] source error: ' + src.__err);
        return;
      }
      if (src.src && src.src.startsWith('wiki') && Array.isArray(src.d)) {
        const titles = src.d[1] || [];
        const descs = src.d[2] || [];
        const links = src.d[3] || [];
        termLog('[' + src.src + '] ' + titles.length + ' hits');
        titles.forEach((t, i) => {
          termLog('  · ' + t + (descs[i] ? ' — ' + descs[i].slice(0, 80) : ''));
          if (links[i]) {
            termLog('    ' + links[i]);
            addSug({ type: 'url', label: t, value: links[i], link: 'упоминается в' });
            wikiTitles.push({ title: t, lang: src.src.includes('ru') ? 'ru' : 'en' });
          }
        });
      } else if (src.src && src.src.startsWith('wikidata')) {
        const list = (src.d && src.d.search) || [];
        termLog('[' + src.src + '] ' + list.length + ' entities');
        list.forEach(item => {
          termLog('  · ' + (item.label || '') + ' [' + item.id + ']' + (item.description ? ' — ' + item.description : ''));
          addSug({ type: 'document', label: (item.label || item.id) + ' [WD]', value: 'https://www.wikidata.org/wiki/' + item.id, link: 'упоминается в' });
        });
      } else if (src.src && src.src.startsWith('ddg')) {
        const d = src.d || {};
        termLog('[' + src.src + ']');
        if (d.Heading) termLog('  heading: ' + d.Heading);
        if (d.AbstractText) {
          termLog('  abstract: ' + d.AbstractText.slice(0, 350));
          if (d.AbstractURL) addSug({ type: 'url', label: d.Heading || 'DDG', value: d.AbstractURL, link: 'упоминается в' });
        }
        if (d.Infobox && d.Infobox.content) {
          d.Infobox.content.slice(0, 15).forEach(row => {
            if (!row.label || !row.value) return;
            const v = typeof row.value === 'string' ? row.value : (row.value.label || '');
            if (!v) return;
            termLog('  ' + row.label + ': ' + String(v).slice(0, 90));
            const lb = row.label.toLowerCase();
            if (/born|родил|birth|date of birth/i.test(lb))
              addSug({ type: 'timestamp', label: String(v).slice(0, 40), value: String(v), link: 'связан с' });
            if (/occupation|професси|job|known for/i.test(lb))
              addSug({ type: 'role', label: String(v).slice(0, 50), value: String(v), link: 'связан с' });
            if (/country|страна|nationality|граждан|residence/i.test(lb))
              addSug({ type: 'location', label: String(v).slice(0, 50), value: String(v), link: 'mentioned_at' });
            if (/website|сайт|official/i.test(lb) && /^https?:/i.test(String(v)))
              addSug({ type: 'url', label: String(v).slice(0, 40), value: String(v), link: 'имеет сайт' });
          });
        }
        (d.RelatedTopics || []).slice(0, 8).forEach(t => {
          const text = t.Text || '';
          if (text) termLog('  · ' + text.slice(0, 140));
          if (t.FirstURL) addSug({ type: 'url', label: text.slice(0, 40), value: t.FirstURL, link: 'упоминается в' });
        });
      } else if (src.src === 'github') {
        const items = (src.d && src.d.items) || [];
        termLog('[github] ' + items.length + ' users');
        items.forEach(u => {
          termLog('  · @' + u.login + (u.html_url ? ' — ' + u.html_url : ''));
          addSug({ type: 'username', label: u.login, value: u.login, link: 'имеет аккаунт' });
          if (u.html_url) addSug({ type: 'url', label: 'github/' + u.login, value: u.html_url, link: 'имеет аккаунт' });
        });
      } else if (src.src === 'openlibrary') {
        const docs = (src.d && src.d.docs) || [];
        termLog('[openlibrary] ' + docs.length + ' authors');
        docs.forEach(a => {
          const nm = a.name || '';
          termLog('  · ' + nm + (a.top_work ? ' — ' + a.top_work : ''));
          if (nm) addSug({ type: 'person', label: nm, value: nm, link: 'связан с' });
          if (a.key) addSug({ type: 'url', label: nm || a.key, value: 'https://openlibrary.org' + a.key, link: 'упоминается в' });
        });
      }
    });
    termLog('');

    // Wave 2: Wikipedia summaries for top titles + Wikidata entity detail
    termLog('[*] Parallel wave 2 (details)…');
    const detailTasks = [];
    wikiTitles.slice(0, 4).forEach(({ title, lang }) => {
      detailTasks.push(
        fetchJSON('https://' + lang + '.wikipedia.org/api/rest_v1/page/summary/' + encodeURIComponent(title.replace(/ /g, '_')))
          .then(d => ({ src: 'summary-' + lang, d }))
          .catch(e => ({ __err: e.message }))
      );
    });
    const wdIds = [];
    wave1.forEach(src => {
      if (src && src.src && src.src.startsWith('wikidata') && src.d && src.d.search) {
        src.d.search.slice(0, 3).forEach(item => { if (item.id) wdIds.push(item.id); });
      }
    });
    [...new Set(wdIds)].slice(0, 4).forEach(id => {
      detailTasks.push(
        fetchJSON('https://www.wikidata.org/w/api.php?action=wbgetentities&ids=' + id +
          '&props=labels|descriptions|claims&languages=ru|en&format=json&origin=*')
          .then(d => ({ src: 'entity', id, d }))
          .catch(e => ({ __err: e.message }))
      );
    });
    // GitHub user profiles for top logins
    wave1.forEach(src => {
      if (src && src.src === 'github' && src.d && src.d.items) {
        src.d.items.slice(0, 2).forEach(u => {
          detailTasks.push(
            fetchJSON('https://api.github.com/users/' + encodeURIComponent(u.login))
              .then(d => ({ src: 'gh-user', d }))
              .catch(e => ({ __err: e.message }))
          );
        });
      }
    });

    const wave2 = await settleAll(detailTasks);
    wave2.forEach(src => {
      if (!src || src.__err) return;
      if (src.src && src.src.startsWith('summary') && src.d) {
        const d = src.d;
        termLog('[wiki summary] ' + (d.title || ''));
        if (d.description) termLog('  ' + d.description);
        if (d.extract) termLog('  ' + d.extract.slice(0, 320));
        if (d.content_urls && d.content_urls.desktop) {
          addSug({ type: 'url', label: d.title, value: d.content_urls.desktop.page, link: 'упоминается в' });
        }
        if (d.coordinates) {
          const c = d.coordinates.lat + ', ' + d.coordinates.lon;
          termLog('  coords: ' + c);
          addSug({ type: 'geolocation', label: c, value: c, link: 'coordinates' });
        }
        if (d.thumbnail && d.thumbnail.source) {
          termLog('  photo: ' + d.thumbnail.source);
        }
      }
      if (src.src === 'entity' && src.d && src.d.entities) {
        const ent = src.d.entities[src.id];
        if (!ent) return;
        const label = (ent.labels && (ent.labels.ru || ent.labels.en) || {}).value || src.id;
        termLog('[wikidata ' + src.id + '] ' + label);
        const claims = ent.claims || {};
        const interesting = {
          P569: 'birth', P570: 'death', P19: 'birthplace', P27: 'citizenship',
          P106: 'occupation', P856: 'website', P2002: 'twitter', P3185: 'vk',
          P2397: 'youtube', P2013: 'facebook', P2003: 'instagram', P1581: 'blog',
          P968: 'email', P21: 'sex', P734: 'surname', P735: 'given name'
        };
        Object.keys(interesting).forEach(pid => {
          const arr = claims[pid];
          if (!arr || !arr[0]) return;
          const dv = arr[0].mainsnak && arr[0].mainsnak.datavalue;
          if (!dv) return;
          let text = '';
          if (dv.type === 'time') text = (dv.value.time || '').replace(/^\+/, '').slice(0, 10);
          else if (dv.type === 'string') text = dv.value;
          else if (dv.type === 'wikibase-entityid') text = dv.value.id;
          else if (dv.type === 'monolingualtext') text = dv.value.text;
          if (!text) return;
          termLog('  ' + interesting[pid] + ': ' + text);
          if (pid === 'P569' || pid === 'P570')
            addSug({ type: 'timestamp', label: text, value: text, link: 'связан с' });
          if (pid === 'P856')
            addSug({ type: 'url', label: text, value: text, link: 'имеет сайт' });
          if (pid === 'P2002')
            addSug({ type: 'username', label: '@' + text, value: text, link: 'имеет аккаунт' });
          if (pid === 'P3185')
            addSug({ type: 'url', label: 'vk.com/' + text, value: 'https://vk.com/' + text, link: 'имеет аккаунт' });
          if (pid === 'P2003')
            addSug({ type: 'url', label: 'instagram/' + text, value: 'https://instagram.com/' + text, link: 'имеет аккаунт' });
          if (pid === 'P2013')
            addSug({ type: 'url', label: 'facebook/' + text, value: 'https://facebook.com/' + text, link: 'имеет аккаунт' });
          if (pid === 'P106')
            addSug({ type: 'role', label: text, value: text, link: 'связан с' });
          if (pid === 'P968')
            addSug({ type: 'email', label: text, value: text, link: 'связан с' });
        });
      }
      if (src.src === 'gh-user' && src.d) {
        const u = src.d;
        termLog('[github profile] @' + u.login);
        if (u.name) termLog('  name: ' + u.name);
        if (u.bio) termLog('  bio: ' + u.bio);
        if (u.company) {
          termLog('  company: ' + u.company);
          addSug({ type: 'organization', label: u.company.replace(/^@/, ''), value: u.company.replace(/^@/, ''), link: 'связан с' });
        }
        if (u.location) {
          termLog('  location: ' + u.location);
          addSug({ type: 'location', label: u.location, value: u.location, link: 'profile_location' });
        }
        if (u.blog) {
          const blog = u.blog.startsWith('http') ? u.blog : 'https://' + u.blog;
          termLog('  blog: ' + blog);
          addSug({ type: 'url', label: blog, value: blog, link: 'имеет сайт' });
        }
        if (u.email) addSug({ type: 'email', label: u.email, value: u.email, link: 'связан с' });
        if (u.twitter_username)
          addSug({ type: 'username', label: '@' + u.twitter_username, value: u.twitter_username, link: 'имеет аккаунт' });
      }
    });

    // Handle variants
    if (parts.length) {
      termLog('');
      termLog('[*] Probable handles & emails:');
      const variants = [
        parts.join('.').toLowerCase(),
        parts.join('_').toLowerCase(),
        parts.join('').toLowerCase(),
        parts[0].toLowerCase() + (parts[1] ? parts[1][0].toLowerCase() : ''),
        (parts[0][0] + (parts[1] || '')).toLowerCase(),
        parts.map(p => p[0]).join('').toLowerCase()
      ].map(s => s.replace(/[^a-zа-яё0-9._]/gi, '')).filter((v, i, a) => v && a.indexOf(v) === i);
      variants.forEach(v => {
        termLog('  ' + v);
        addSug({ type: 'username', label: v, value: v, link: 'имеет аккаунт' });
      });
      if (parts.length >= 2) {
        const emailGuess = parts[0].toLowerCase().replace(/[^a-zа-яё]/gi, '') + '.' +
          parts[parts.length - 1].toLowerCase().replace(/[^a-zа-яё]/gi, '') + '@…';
        termLog('  email pattern: ' + emailGuess);
      }
    }

    termLog('');
    termLog('[+] ' + suggestions.length + ' related node suggestions');
    renderTerminalSuggestions(sourceNode, suggestions);
  }

  async function lookupUsername(raw, sourceNode) {
    const u = raw.replace(/^@/, '').trim();
    termLog('[*] Username OSINT: @' + u);
    termLog('');
    const platforms = [
      { name: 'Telegram', url: 'https://t.me/' + u },
      { name: 'GitHub', url: 'https://github.com/' + u },
      { name: 'X/Twitter', url: 'https://x.com/' + u },
      { name: 'Instagram', url: 'https://instagram.com/' + u },
      { name: 'VK', url: 'https://vk.com/' + u },
      { name: 'Reddit', url: 'https://reddit.com/user/' + u },
      { name: 'YouTube', url: 'https://youtube.com/@' + u },
      { name: 'TikTok', url: 'https://tiktok.com/@' + u },
      { name: 'LinkedIn', url: 'https://linkedin.com/in/' + u },
      { name: 'Habr', url: 'https://habr.com/users/' + u }
    ];
    const suggestions = platforms.map(p => ({
      type: 'url', label: p.name + '/' + u, value: p.url, link: 'имеет аккаунт'
    }));
    platforms.forEach(p => termLog('  ? ' + p.name.padEnd(12) + p.url));
    termLog('');

    // HEAD-like existence probe via no-cors is useless; use DDG
    termLog('[*] Web mentions…');
    try {
      const queries = [u, '@' + u, u + ' site:github.com', u + ' telegram'];
      for (const q of queries) {
        try {
          const data = await fetchJSON('https://api.duckduckgo.com/?q=' + encodeURIComponent(q) + '&format=json&no_redirect=1&no_html=1');
          if (data.AbstractText) termLog('  [' + q + '] ' + data.AbstractText.slice(0, 160));
          (data.RelatedTopics || []).slice(0, 2).forEach(t => {
            if (t.Text) termLog('   · ' + t.Text.slice(0, 100));
          });
        } catch {}
      }
    } catch (e) {
      termLog('[!] ' + e.message);
    }
    termLog('');
    renderTerminalSuggestions(sourceNode, suggestions);
  }

  function openTerminal(title) {
    $('#terminal-title').textContent = title || 'lookup';
    $('#terminal-body').textContent = '';
    $('#terminal-actions').innerHTML = '';
    $('#terminal-panel').classList.remove('hidden');
  }
  function closeTerminal() {
    $('#terminal-panel').classList.add('hidden');
  }

  function setupTerminalDrag() {
    const panel = $('#terminal-panel');
    const handle = $('#terminal-drag');
    const resize = $('#terminal-resize');
    if (!panel || !handle) return;

    let dragging = false, resizing = false;
    let sx, sy, sl, st, sw, sh;

    function onMove(e) {
      const cx = e.touches ? e.touches[0].clientX : e.clientX;
      const cy = e.touches ? e.touches[0].clientY : e.clientY;
      const parent = graphContainer.getBoundingClientRect();
      if (dragging) {
        let nl = sl + (cx - sx);
        let nt = st + (cy - sy);
        nl = Math.max(0, Math.min(nl, parent.width - panel.offsetWidth));
        nt = Math.max(0, Math.min(nt, parent.height - 40));
        panel.style.left = nl + 'px';
        panel.style.top = nt + 'px';
        panel.style.bottom = 'auto';
        panel.style.right = 'auto';
      }
      if (resizing) {
        const nw = Math.max(220, sw + (cx - sx));
        const nh = Math.max(140, sh + (cy - sy));
        panel.style.width = Math.min(nw, parent.width - 8) + 'px';
        panel.style.height = Math.min(nh, parent.height - 8) + 'px';
      }
    }
    function onUp() {
      dragging = false; resizing = false;
      document.removeEventListener('pointermove', onMove);
      document.removeEventListener('pointerup', onUp);
      document.removeEventListener('touchmove', onMove);
      document.removeEventListener('touchend', onUp);
    }

    handle.addEventListener('pointerdown', e => {
      if (e.target.closest('#btn-close-terminal')) return;
      e.preventDefault();
      dragging = true;
      sx = e.clientX; sy = e.clientY;
      const rect = panel.getBoundingClientRect();
      const parent = graphContainer.getBoundingClientRect();
      sl = rect.left - parent.left;
      st = rect.top - parent.top;
      document.addEventListener('pointermove', onMove);
      document.addEventListener('pointerup', onUp);
    });

    if (resize) {
      resize.addEventListener('pointerdown', e => {
        e.preventDefault();
        e.stopPropagation();
        resizing = true;
        sx = e.clientX; sy = e.clientY;
        sw = panel.offsetWidth; sh = panel.offsetHeight;
        document.addEventListener('pointermove', onMove);
        document.addEventListener('pointerup', onUp);
      });
    }
  }

  function termLog(line) {
    const el = $('#terminal-body');
    el.textContent += line + '\n';
    el.scrollTop = el.scrollHeight;
  }

  async function lookupIP(ip, sourceNode) {
    termLog('[*] IP deep lookup: ' + ip);
    termLog('');
    const suggestions = [];
    const GEO_DISCLAIMER = 'IP geolocation is an estimate based on the provider IP database and does NOT establish the user physical location.';

    termLog('[*] Parallel geo / ASN sources (estimates only)…');
    const [ipapi, ipwho, rdns] = await settleAll([
      fetchJSON('https://ipapi.co/' + encodeURIComponent(ip) + '/json/').catch(e => ({ error: e.message })),
      fetchJSON('https://ipwho.is/' + encodeURIComponent(ip)).catch(e => ({ error: e.message })),
      fetchJSON('https://cloudflare-dns.com/resolve?name=' + encodeURIComponent(ip.split('.').reverse().join('.') + '.in-addr.arpa') + '&type=PTR', {
        headers: { Accept: 'application/dns-json' }
      }).catch(e => ({ error: e.message }))
    ]);

    let info = { ip, org: null, asn: null };
    const geoEstimates = [];

    function pushGeoFrom(provider, d, srcUrl) {
      if (!d || d.error || d.__err || d.success === false) return;
      const city = d.city || '';
      const region = d.region || d.region_name || '';
      const country = d.country_name || d.country || '';
      const place = [city, region, country].filter(Boolean).join(', ');
      if (!place) return;
      const lat = d.latitude ?? d.lat;
      const lon = d.longitude ?? d.lon;
      geoEstimates.push({
        provider: provider,
        place: place,
        city: city || null,
        region: region || null,
        country: country || null,
        lat: lat != null ? lat : null,
        lon: lon != null ? lon : null,
        accuracy: 'unknown',
        confidence: city ? 'medium' : 'low',
        sourceUrl: srcUrl,
        timestamp: new Date().toISOString()
      });
      if (!info.org) info.org = d.org || d.connection?.org || d.isp || null;
      if (!info.asn) info.asn = d.asn || d.connection?.asn || null;
    }

    pushGeoFrom('ipapi.co', ipapi, 'https://ipapi.co/' + ip + '/');
    pushGeoFrom('ipwho.is', ipwho, 'https://ipwho.is/' + ip);

    termLog('IP: ' + ip);
    termLog(GEO_DISCLAIMER);
    termLog('');
    if (!geoEstimates.length) {
      termLog('[!] No geolocation estimates from providers');
    } else {
      const cities = geoEstimates.map(g => (g.city || '').toLowerCase()).filter(Boolean);
      const conflict = new Set(cities).size > 1;
      if (conflict) termLog('[!] CONFLICTING geolocation estimates:');
      else termLog('[*] Geolocation estimates (not verified location):');
      geoEstimates.forEach(g => {
        termLog('  · ' + g.provider + ' → ' + g.place);
        termLog('    confidence: ' + g.confidence + ' · accuracy: ' + g.accuracy);
        if (g.lat != null) termLog('    coords: ' + g.lat + ', ' + g.lon);
        suggestions.push({
          type: 'geo_estimate',
          label: (conflict ? '📍 CONFLICTING · ' : '📍 GEO ESTIMATE · ') + g.place,
          value: g.place,
          link: 'geo_estimate',
          metadata: Object.assign({ kind: 'ip_geolocation_estimate', disclaimer: GEO_DISCLAIMER, conflict: conflict }, g)
        });
      });
    }
    termLog('Org/ISP:  ' + (info.org || '—'));
    termLog('ASN:      ' + (info.asn || '—'));
    termLog('');

    // PTR
    try {
      const answers = (rdns && rdns.Answer) || [];
      if (answers.length) {
        termLog('[*] Reverse DNS (PTR):');
        answers.forEach(a => {
          termLog('  ' + a.data);
          suggestions.push({ type: 'domain', label: a.data.replace(/\.$/, ''), value: a.data.replace(/\.$/, ''), link: 'указывает на' });
        });
      } else termLog('[*] PTR: none');
    } catch {
      termLog('[*] PTR: n/a');
    }
    termLog('');

    // Latency
    termLog('[*] HTTP latency probe…');
    try {
      const t0 = performance.now();
      await fetch('https://ipapi.co/' + encodeURIComponent(ip) + '/country/', { signal: AbortSignal.timeout(5000) });
      termLog('RTT ≈ ' + Math.round(performance.now() - t0) + ' ms (HTTP, not ICMP)');
    } catch {
      termLog('Probe: blocked / timeout');
    }
    termLog('');

    // RDAP network if possible
    try {
      termLog('[*] RDAP network…');
      const rdap = await fetchJSON('https://rdap.org/ip/' + encodeURIComponent(ip), { timeout: 8000 });
      if (rdap.name) termLog('net name: ' + rdap.name);
      if (rdap.handle) termLog('handle:   ' + rdap.handle);
      if (rdap.country) termLog('country:  ' + rdap.country);
      (rdap.remarks || []).slice(0, 2).forEach(r => {
        if (r.description) termLog('note:     ' + r.description.join(' ').slice(0, 120));
      });
      termLog('');
    } catch (e) {
      termLog('[!] RDAP: ' + (e.message || 'n/a'));
      termLog('');
    }

    if (info.org) suggestions.push({ type: 'organization', label: info.org, value: info.org, link: 'принадлежит' });
    if (info.asn) suggestions.push({ type: 'asn', label: String(info.asn), value: String(info.asn), link: 'связан с' });
    // Geo estimates are pushed per-source above — never as verified location


    termLog('[+] Related nodes:');
    renderTerminalSuggestions(sourceNode, suggestions);
  }

  async function lookupDomain(domain, sourceNode, quiet) {
    if (!quiet) {
      termLog('[*] Domain deep lookup: ' + domain);
      termLog('');
    }
    const suggestions = [];

    termLog('[*] DNS (A / AAAA / MX / NS / TXT / CNAME) parallel…');
    const types = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME', 'SOA'];
    const dnsTasks = types.map(t =>
      fetchJSON('https://cloudflare-dns.com/resolve?name=' + encodeURIComponent(domain) + '&type=' + t, {
        headers: { Accept: 'application/dns-json' }
      }).then(d => ({ t, d })).catch(e => ({ t, err: e.message }))
    );
    // Google DNS backup for A
    dnsTasks.push(
      fetchJSON('https://dns.google/resolve?name=' + encodeURIComponent(domain) + '&type=A')
        .then(d => ({ t: 'A-google', d })).catch(e => ({ t: 'A-google', err: e.message }))
    );

    const dnsResults = await settleAll(dnsTasks);
    dnsResults.forEach(res => {
      if (!res || res.__err) return;
      if (res.err) {
        termLog('  ' + res.t + ': fail');
        return;
      }
      const answers = (res.d && res.d.Answer) || [];
      if (!answers.length && res.t !== 'SOA') return;
      termLog('  ─ ' + res.t + ' ─');
      answers.forEach(a => {
        termLog('    ' + a.data + (a.TTL ? '  TTL=' + a.TTL : ''));
        const data = a.data;
        if (/^(\d{1,3}\.){3}\d{1,3}$/.test(data)) {
          suggestions.push({ type: 'ip', label: data, value: data, link: 'указывает на' });
        } else if (res.t === 'MX' || res.t.includes('MX')) {
          const host = data.split(' ').pop().replace(/\.$/, '');
          if (host) suggestions.push({ type: 'mx', label: host, value: host, link: 'использует' });
        } else if (res.t === 'NS' || res.t.includes('NS')) {
          suggestions.push({ type: 'ns', label: data.replace(/\.$/, ''), value: data.replace(/\.$/, ''), link: 'связан с' });
        } else if (res.t === 'CNAME') {
          suggestions.push({ type: 'domain', label: data.replace(/\.$/, ''), value: data.replace(/\.$/, ''), link: 'указывает на' });
        }
      });
    });
    termLog('');

    // RDAP domain
    try {
      termLog('[*] RDAP / WHOIS-like…');
      const rdap = await fetchJSON('https://rdap.org/domain/' + encodeURIComponent(domain), { timeout: 10000 });
      if (rdap.ldhName) termLog('name:     ' + rdap.ldhName);
      if (rdap.handle) termLog('handle:   ' + rdap.handle);
      (rdap.status || []).forEach(s => termLog('status:   ' + s));
      (rdap.nameservers || []).forEach(ns => {
        const n = ns.ldhName || ns;
        termLog('NS:       ' + n);
        suggestions.push({ type: 'ns', label: String(n), value: String(n), link: 'связан с' });
      });
      (rdap.entities || []).slice(0, 6).forEach(ent => {
        const roles = (ent.roles || []).join(',');
        const vcard = ent.vcardArray && ent.vcardArray[1];
        let fn = '', email = '', org = '';
        if (Array.isArray(vcard)) {
          vcard.forEach(row => {
            if (row[0] === 'fn') fn = row[3];
            if (row[0] === 'email') email = row[3];
            if (row[0] === 'org') org = row[3];
          });
        }
        if (fn || org || email) {
          termLog('entity[' + roles + ']: ' + [fn, org, email].filter(Boolean).join(' | '));
          if (email) suggestions.push({ type: 'email', label: email, value: email, link: 'связан с' });
          if (org) suggestions.push({ type: 'organization', label: org, value: org, link: 'принадлежит' });
          if (fn) suggestions.push({ type: 'person', label: fn, value: fn, link: 'связан с' });
        }
      });
      (rdap.events || []).forEach(ev => {
        termLog('event:    ' + ev.eventAction + ' @ ' + (ev.eventDate || '').slice(0, 19));
        if (ev.eventAction === 'registration')
          suggestions.push({ type: 'timestamp', label: 'reg ' + (ev.eventDate || '').slice(0, 10), value: ev.eventDate, link: 'связан с' });
      });
      termLog('');
    } catch (e) {
      termLog('[!] RDAP: ' + (e.message || 'n/a'));
      termLog('');
    }

    // Certificate transparency via crt.sh (may CORS-fail in browser)
    try {
      termLog('[*] Certificate transparency (crt.sh)…');
      const certs = await fetchJSON('https://crt.sh/?q=' + encodeURIComponent(domain) + '&output=json', { timeout: 12000 });
      if (Array.isArray(certs) && certs.length) {
        const names = new Set();
        certs.slice(0, 40).forEach(c => {
          String(c.name_value || '').split('\n').forEach(n => {
            n = n.trim().replace(/^\*\./, '');
            if (n && n.includes('.')) names.add(n);
          });
        });
        termLog('  unique names: ' + names.size);
        [...names].slice(0, 15).forEach(n => {
          termLog('  ' + n);
          if (n !== domain) suggestions.push({ type: 'domain', label: n, value: n, link: 'связан с' });
        });
      } else termLog('  (none or blocked)');
      termLog('');
    } catch (e) {
      termLog('[!] crt.sh: ' + e.message + ' (CORS may block)');
      termLog('');
    }

    if (!quiet) {
      
    // Wayback availability
    try {
      termLog('[*] Wayback Machine…');
      const wb = await fetchJSON('https://archive.org/wayback/available?url=' + encodeURIComponent(domain), { timeout: 8000 });
      const snap = wb.archived_snapshots && wb.archived_snapshots.closest;
      if (snap && snap.available) {
        termLog('  snapshot: ' + snap.url);
        termLog('  timestamp: ' + snap.timestamp);
        suggestions.push({ type: 'url', label: 'wayback ' + domain, value: snap.url, link: 'упоминается в' });
      } else termLog('  (no snapshot)');
      termLog('');
    } catch (e) {
      termLog('[!] wayback: ' + e.message);
      termLog('');
    }

termLog('[+] Related nodes:');
      renderTerminalSuggestions(sourceNode, suggestions);
    }
  }

  function renderTerminalSuggestions(sourceNode, suggestions) {
    const box = $('#terminal-actions');
    box.innerHTML = '';
    const seen = new Set();
    let count = 0;
    suggestions.forEach(s => {
      if (!s || !s.value) return;
      const key = s.type + '|' + String(s.value).toLowerCase();
      if (seen.has(key)) return;
      seen.add(key);
      count++;
      const btn = document.createElement('button');
      btn.textContent = '+ ' + String(s.label || s.value).slice(0, 28);
      btn.title = s.type + ': ' + s.value;
      btn.onclick = () => {
        const x = sourceNode.x + 80 + Math.random() * 60;
        const y = sourceNode.y + (Math.random() - 0.5) * 100;
        pendingAddPos = { x, y };
        const node = addNode({
          type: s.type,
          label: s.label || s.value,
          value: s.value,
          description: 'auto from lookup',
          source: 'lookup',
          notes: ''
        });
        if (node) addEdge(sourceNode.id, node.id, s.link || 'связан с', 'lookup');
        toast('Узел добавлен');
      };
      box.appendChild(btn);
    });
    if (!count) {
      const span = document.createElement('span');
      span.style.cssText = 'color:#666;font-size:0.7rem;padding:6px';
      span.textContent = 'Нет предложений';
      box.appendChild(span);
    } else {
      termLog('suggestions: ' + count);
    }
  }

  function openTypePicker() {
    // Always ignore picks for a short window after open (anti mis-tap)
    if (Date.now() > ignoreModalClickUntil) {
      ignoreModalClickUntil = Date.now() + 320;
    }
    const grid = $('#type-grid');
    grid.innerHTML = Object.entries(NODE_TYPES).map(([key, info]) => {
      const col = MALTEGO_COLORS[key] || '#6B7280';
      // Type menu always uses Maltego coloring (colored disc + white glyph)
      return `<button class="type-btn" data-type="${key}" disabled>
        <div class="type-icon" style="background:${col} !important;border-color:${col} !important;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${info.svg}</svg>
        </div>
        ${info.label}
      </button>`;
    }).join('');
    // Enable buttons only after delay so the opening gesture cannot select a type
    const enableAt = ignoreModalClickUntil;
    setTimeout(() => {
      grid.querySelectorAll('.type-btn').forEach(btn => { btn.disabled = false; });
    }, Math.max(0, enableAt - Date.now()));
    grid.querySelectorAll('.type-btn').forEach(btn => {
      btn.onclick = (ev) => {
        if (Date.now() < ignoreModalClickUntil || btn.disabled) {
          ev.preventDefault();
          ev.stopPropagation();
          return;
        }
        const type = btn.dataset.type;
        closeModal();
        if (type === 'photo' || type === 'image') {
          pickPhotoAndCreate(type);
        } else {
          // quick place: one field via quick-add, or full modal for complex
          openNodeModal(null, type);
        }
      };
    });
    openModal('modal-type-picker');
  }

  function openNodeModal(nodeId, presetType) {
    editingNodeId = nodeId;
    pendingPhotoData = null; pendingPhotoRatio = 1;
    // fill type select with all types
    const sel = $('#node-type');
    const cur = sel.value;
    sel.innerHTML = Object.entries(NODE_TYPES).map(([k, v]) =>
      `<option value="${k}">${v.label}</option>`
    ).join('');
    $('#modal-node-title').textContent = nodeId ? 'Редактировать' : 'Добавить объект';
    $('#photo-status').textContent = '';
    $('#photo-thumb').classList.add('hidden');
    $('#photo-thumb').innerHTML = '';

    if (nodeId) {
      const n = currentProject.nodes.find(x => x.id === nodeId); if (!n) return;
      $('#node-type').value = n.type;
      $('#node-label').value = n.label || '';
      $('#node-value').value = n.value || '';
      const textBody = $('#node-text-body');
      if (textBody) textBody.value = (n.type === 'text' ? (n.label || n.value || '') : '') || '';
      $('#node-description').value = n.description || '';
      $('#node-source').value = n.source || '';
      $('#node-notes').value = n.notes || '';
      if ($('#node-tags')) $('#node-tags').value = (n.tags || []).join(', ');
      if (n.photoData) {
        pendingPhotoData = n.photoData;
        pendingPhotoRatio = n.photoRatio || 1;
        $('#photo-status').textContent = 'Фото загружено';
        $('#photo-thumb').classList.remove('hidden');
        $('#photo-thumb').innerHTML = `<img src="${n.photoData}">`;
      }
    } else {
      $('#node-type').value = presetType || 'person';
      $('#node-label').value = '';
      $('#node-value').value = '';
      const textBody = $('#node-text-body');
      if (textBody) textBody.value = '';
      $('#node-description').value = '';
      $('#node-source').value = '';
      $('#node-notes').value = '';
      if ($('#node-tags')) $('#node-tags').value = '';
    }
    togglePhotoGroup();
    openModal('modal-node');
  }

  function togglePhotoGroup() {
    const t = $('#node-type').value;
    const isPhoto = t === 'photo' || t === 'image';
    const isText = t === 'text';
    $('#photo-upload-group').style.display = isPhoto ? 'block' : 'none';
    const labelGroup = $('#node-label-group');
    const valueGroup = $('#node-value-group');
    const textGroup = $('#node-text-group');
    if (textGroup) textGroup.classList.toggle('hidden', !isText);
    if (labelGroup) labelGroup.style.display = isText ? 'none' : 'block';
    if (valueGroup) valueGroup.style.display = isText ? 'none' : 'block';
    if (isText) {
      const body = $('#node-text-body');
      if (body && !body.value) {
        body.value = ($('#node-label').value || $('#node-value').value || '').trim();
      }
    }
  }

  function compressImage(file) {
    return new Promise((resolve, reject) => {
      if (!file) return reject(new Error('no file'));
      const reader = new FileReader();
      reader.onload = ev => {
        const dataUrl = ev.target.result;
        const img = new Image();
        img.onload = () => {
          try {
            let w = img.naturalWidth || img.width;
            let h = img.naturalHeight || img.height;
            if (!w || !h) return reject(new Error('bad dimensions'));
            if (w > MAX_PHOTO_SIZE || h > MAX_PHOTO_SIZE) {
              if (w > h) { h = Math.round(h * MAX_PHOTO_SIZE / w); w = MAX_PHOTO_SIZE; }
              else { w = Math.round(w * MAX_PHOTO_SIZE / h); h = MAX_PHOTO_SIZE; }
            }
            const canvas = document.createElement('canvas');
            canvas.width = w;
            canvas.height = h;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, w, h);
            let out;
            try {
              out = canvas.toDataURL('image/jpeg', 0.82);
            } catch (e) {
              // fallback: use original data URL if canvas tainted/fails
              out = dataUrl;
              w = img.naturalWidth || img.width;
              h = img.naturalHeight || img.height;
            }
            if (!out || out.length < 32) return reject(new Error('encode failed'));
            resolve({ dataUrl: out, ratio: w / Math.max(h, 1) });
          } catch (err) {
            reject(err);
          }
        };
        img.onerror = () => reject(new Error('decode failed'));
        img.src = dataUrl;
      };
      reader.onerror = () => reject(new Error('read failed'));
      reader.readAsDataURL(file);
    });
  }

  function confirmAction(title, msg, onOk) {
    $('#confirm-title').textContent = title;
    $('#confirm-message').textContent = msg;
    openModal('modal-confirm');
    $('#btn-confirm-ok').onclick = () => { closeModal(); onOk(); };
  }

  function parseAdvancedQuery(raw) {
    // Supports: type:email status:confirmed source:example.com free text
    // Also: has:evidence, label:foo, value:bar
    const filters = { type: null, status: null, source: null, label: null, value: null, has: null, text: [] };
    const tokens = (raw || '').trim().split(/\s+/).filter(Boolean);
    tokens.forEach(tok => {
      const m = tok.match(/^(type|status|source|label|value|has):(.+)$/i);
      if (m) {
        const key = m[1].toLowerCase();
        const val = m[2].toLowerCase();
        if (key === 'type') filters.type = val;
        else if (key === 'status') filters.status = val;
        else if (key === 'source') filters.source = val;
        else if (key === 'label') filters.label = val;
        else if (key === 'value') filters.value = val;
        else if (key === 'has') filters.has = val;
      } else {
        filters.text.push(tok.toLowerCase());
      }
    });
    return filters;
  }

  function nodeMatchesFilters(n, f) {
    if (f.type) {
      const tLabel = ((NODE_TYPES[n.type] || {}).label || '').toLowerCase();
      if (n.type.toLowerCase() !== f.type && tLabel !== f.type && !n.type.toLowerCase().includes(f.type) && !tLabel.includes(f.type))
        return false;
    }
    if (f.status) {
      const list = n.evidence || [];
      const ok = list.some(ev => (ev.status || '').toLowerCase() === f.status ||
        (f.status === 'confirmed' && (ev.status || '') === 'confirmed') ||
        (f.status === 'unverified' && (ev.status || '') === 'unverified') ||
        (f.status === 'unknown' && (ev.status || '') === 'unknown'));
      // also allow russian aliases
      const aliases = {
        'подтверждено': 'confirmed', 'confirmed': 'confirmed',
        'проверка': 'unverified', 'unverified': 'unverified',
        'неизвестно': 'unknown', 'unknown': 'unknown'
      };
      const want = aliases[f.status] || f.status;
      const ok2 = list.some(ev => (ev.status || '') === want);
      if (!ok && !ok2) return false;
      if (!list.length && f.status) return false;
    }
    if (f.source) {
      const sources = [
        n.source || '',
        ...(n.evidence || []).map(e => (e.source || '') + ' ' + (e.url || ''))
      ].join(' ').toLowerCase();
      if (!sources.includes(f.source)) return false;
    }
    if (f.label && !(n.label || '').toLowerCase().includes(f.label)) return false;
    if (f.value && !(n.value || '').toLowerCase().includes(f.value)) return false;
    if (f.has === 'evidence' && !(n.evidence && n.evidence.length)) return false;
    if (f.has === 'photo' && !(n.photoData)) return false;
    if (f.text.length) {
      const hay = [n.label, n.value, n.type, n.description, n.source, n.notes, (NODE_TYPES[n.type] || {}).label]
        .concat((n.evidence || []).map(e => [e.source, e.finding, e.url].join(' ')))
        .join(' ').toLowerCase();
      if (!f.text.every(t => hay.includes(t))) return false;
    }
    return true;
  }

  function searchGraph(query) {
    if (!currentProject) return;
    const q = (query || '').trim();
    if (!q) {
      currentProject.nodes.forEach(n => { n._highlighted = false; });
      renderGraph();
      return;
    }
    const filters = parseAdvancedQuery(q);
    currentProject.nodes.forEach(n => {
      n._highlighted = nodeMatchesFilters(n, filters);
    });
    renderGraph();
    const found = currentProject.nodes.filter(n => n._highlighted).length;
    toast(found ? ('Найдено: ' + found) : 'Ничего не найдено');
  }


  function showStats() {
    if (!currentProject) return;
    const nodes = currentProject.nodes, edges = currentProject.edges;
    const typeCounts = {};
    nodes.forEach(n => { typeCounts[n.type] = (typeCounts[n.type] || 0) + 1; });
    const degree = {};
    edges.forEach(e => { degree[e.from] = (degree[e.from] || 0) + 1; degree[e.to] = (degree[e.to] || 0) + 1; });
    const sorted = Object.entries(degree).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([id, deg]) => {
      const n = nodes.find(x => x.id === id);
      return { name: (n && (n.label || n.value)) || '?', deg };
    });
    let html = `
      <div class="stat-card"><div class="num">${nodes.length}</div><div class="lbl">Объектов</div></div>
      <div class="stat-card"><div class="num">${edges.length}</div><div class="lbl">Связей</div></div>
      <div class="stat-card"><div class="num">${Object.keys(typeCounts).length}</div><div class="lbl">Типов</div></div>
      <div class="stat-card"><div class="num">${nodes.length ? (edges.length * 2 / nodes.length).toFixed(1) : 0}</div><div class="lbl">Ср. связей</div></div>`;
    if (Object.keys(typeCounts).length) {
      html += `<div class="stat-list"><h4>По типам</h4>`;
      Object.entries(typeCounts).sort((a, b) => b[1] - a[1]).forEach(([t, c]) => {
        html += `<div class="stat-list-item"><span>${(NODE_TYPES[t] || NODE_TYPES.other).label}</span><span>${c}</span></div>`;
      });
      html += `</div>`;
    }
    if (sorted.length) {
      html += `<div class="stat-list"><h4>Наиболее связанные</h4>`;
      sorted.forEach(s => { html += `<div class="stat-list-item"><span>${escapeHtml(s.name)}</span><span>${s.deg}</span></div>`; });
      html += `</div>`;
    }
    $('#stats-content').innerHTML = html;
    openModal('modal-stats');
  }

  // Export — fixed PNG
  function getGraphBBox() {
    const nodes = currentProject.nodes;
    if (!nodes.length) return { minX: 0, minY: 0, width: 400, height: 300 };
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    nodes.forEach(n => {
      const r = nodeRadius(n) + 36;
      minX = Math.min(minX, n.x - r); minY = Math.min(minY, n.y - r);
      maxX = Math.max(maxX, n.x + r); maxY = Math.max(maxY, n.y + r);
    });
    return { minX, minY, width: Math.max(200, maxX - minX), height: Math.max(200, maxY - minY) };
  }

  function buildExportSvg() {
    const nodes = currentProject.nodes;
    const edges = currentProject.edges;
    const bbox = getGraphBBox();
    const pad = 50;
    const w = bbox.width + pad * 2;
    const h = bbox.height + pad * 2;
    const ox = bbox.minX - pad;
    const oy = bbox.minY - pad;

    let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="${ox} ${oy} ${w} ${h}">`;
    svg += `<rect x="${ox}" y="${oy}" width="${w}" height="${h}" fill="${settings.theme === 'dark' ? '#121212' : '#f4f4f4'}"/>`;
    svg += `<defs><marker id="exp-arrow" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto" markerUnits="userSpaceOnUse">
      <polygon points="0 0, 8 3, 0 6" fill="#555"/></marker></defs>`;

    // Edges first
    edges.forEach(e => {
      const from = nodes.find(n => n.id === e.from);
      const to = nodes.find(n => n.id === e.to);
      if (!from || !to) return;
      if (hiddenTypes.has(from.type) || hiddenTypes.has(to.type)) return;
      const fr = nodeRadius(from), tr = nodeRadius(to);
      const d = edgePath(from, to, e, fr, tr);
      svg += `<path d="${d}" stroke="${settings.edgeColor || '#777'}" stroke-width="${e.width || 1.0}" fill="none" marker-end="url(#exp-arrow)"/>`;
      if (settings.edgeLabels && e.type) {
        const mid = edgeMidpoint(from, to, e.curve || 0, fr, tr);
        svg += `<text x="${mid.x}" y="${mid.y - 6}" text-anchor="middle" fill="#666" font-size="10" font-family="sans-serif">${escapeHtml(e.type)}</text>`;
      }
    });

    // Nodes
    nodes.forEach(n => {
      const t = NODE_TYPES[n.type] || NODE_TYPES.other;
      const r = nodeRadius(n);
      const col = MALTEGO_COLORS[n.type] || '#6B7280';
      const istyle = settings.iconStyle || 'colored';
      if (istyle === 'text') {
        const tw = Math.max(r * 2.2, 56), th = Math.max(r * 1.4, 36);
        svg += `<rect x="${n.x - tw/2}" y="${n.y - th/2}" width="${tw}" height="${th}" rx="6" fill="#fff" stroke="#333" stroke-width="1.5"/>`;
        svg += `<text x="${n.x}" y="${n.y}" text-anchor="middle" dominant-baseline="central" font-size="11" font-weight="600" font-family="sans-serif" fill="#1a1a1a">${escapeHtml(truncate(n.label || n.value || '', 12))}</text>`;
      } else {
        const fill = istyle === 'colored' ? col : '#e8e8e8';
        svg += `<circle cx="${n.x}" cy="${n.y}" r="${r}" fill="${fill}" stroke="rgba(0,0,0,0.2)" stroke-width="1.5"/>`;
        svg += `<g transform="translate(${n.x - r*0.55},${n.y - r*0.55}) scale(${(r*0.95)/24})" fill="none" stroke="${istyle === 'colored' ? '#fff' : '#1a1a1a'}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${t.svg || ''}</g>`;
      }
      // IP geo estimate disclaimer + metadata
    if (n.type === 'geo_estimate' || (n.metadata && n.metadata.kind === 'ip_geolocation_estimate')) {
      const m = n.metadata || {};
      const lines = [
        '<strong>📍 IP GEOLOCATION ESTIMATE</strong>',
        'Not a verified physical location of any person.',
        m.provider ? ('Source: ' + m.provider) : '',
        m.confidence ? ('Confidence: ' + m.confidence) : '',
        'Accuracy: ' + (m.accuracy || 'unknown'),
        m.country ? ('Country: ' + m.country) : '',
        m.region ? ('Region: ' + m.region) : '',
        m.city ? ('City: ' + m.city) : '',
        (m.lat != null && m.lon != null) ? ('Coords: ' + m.lat + ', ' + m.lon) : '',
        m.conflict ? '<em>Conflicting estimates across providers</em>' : '',
        m.timestamp ? ('Checked: ' + m.timestamp) : ''
      ].filter(Boolean);
      const disc = document.createElement('div');
      disc.className = 'geo-disclaimer';
      disc.style.cssText = 'margin:8px 0;padding:8px 10px;background:rgba(180,83,9,.12);border:1px solid rgba(180,83,9,.35);border-radius:8px;font-size:12px;line-height:1.4;';
      disc.innerHTML = lines.join('<br>');
      const evBox = $('#sheet-evidence') || $('#sheet-meta');
      if (evBox && evBox.parentNode) evBox.parentNode.insertBefore(disc, evBox);
      else if ($('#sheet-title')) $('#sheet-title').after(disc);
      // Always add evidence note
      n.evidence = n.evidence || [];
      if (!n.evidence.some(e => /does not establish/i.test(e.finding || e.why || ''))) {
        n.evidence.unshift({
          source: m.provider || 'geo-db',
          url: m.sourceUrl || '',
          foundAt: m.timestamp || now(),
          finding: 'IP geolocation is an estimate based on the provider\'s IP database and does not establish the user\'s physical location.',
          status: 'needs_review',
          why: 'Database range mapping only'
        });
      }
    }

    if (n.type === 'photo' && n.photoData) {
        const pw = n.size || 140;
        const ph = pw / (n.photoRatio || 1);
        svg += `<image href="${n.photoData}" x="${n.x - pw / 2}" y="${n.y - ph / 2}" width="${pw}" height="${ph}" preserveAspectRatio="xMidYMid meet"/>`;
        svg += `<text x="${n.x}" y="${n.y + ph / 2 + 14}" text-anchor="middle" fill="#1a1a1a" font-size="12" font-weight="600" font-family="sans-serif">${escapeHtml(truncate(n.label || 'Фото', 18))}</text>`;
      }
      if ((settings.iconStyle || 'colored') !== 'text') {
        const label = truncate(n.label || n.value || '—', 18);
        svg += `<text x="${n.x}" y="${n.y + r + 14}" text-anchor="middle" fill="#1a1a1a" font-size="12" font-weight="600" font-family="sans-serif">${escapeHtml(label)}</text>`;
      }
    });

    svg += '</svg>';
    return { svg, w, h };
  }

  
  function exportMarkdown() {
    if (!currentProject) { toast('Нет проекта'); return; }
    const p = currentProject;
    const lines = [];
    lines.push('# ' + (p.name || 'Investigation'));
    lines.push('');
    lines.push('Exported: ' + new Date().toISOString());
    lines.push('Nodes: ' + (p.nodes || []).length + ' · Edges: ' + (p.edges || []).length);
    lines.push('');
    if (p.description) { lines.push('## Description'); lines.push(p.description); lines.push(''); }
    if (p.notes) { lines.push('## Project notes'); lines.push(p.notes); lines.push(''); }
    lines.push('## Entities');
    lines.push('');
    (p.nodes || []).forEach(n => {
      lines.push('### [' + (n.type || 'other') + '] ' + (n.label || n.value || n.id));
      if (n.value && n.value !== n.label) lines.push('- Value: `' + n.value + '`');
      if (n.confidence) lines.push('- Confidence: ' + n.confidence);
      if (n.tags && n.tags.length) lines.push('- Tags: ' + n.tags.join(', '));
      if (n.notes) lines.push('- Notes: ' + n.notes);
      if (n.source) lines.push('- Source: ' + n.source);
      const ev = n.evidence || [];
      if (ev.length) {
        lines.push('- Evidence:');
        ev.slice(0, 8).forEach(e => {
          lines.push('  - ' + (e.source || '') + (e.finding ? ': ' + e.finding : '') + (e.url ? ' — ' + e.url : ''));
        });
      }
      lines.push('');
    });
    lines.push('## Relationships');
    lines.push('');
    const byId = {};
    (p.nodes || []).forEach(n => { byId[n.id] = n; });
    (p.edges || []).forEach(e => {
      const a = byId[e.from], b = byId[e.to];
      const al = a ? (a.label || a.value) : e.from;
      const bl = b ? (b.label || b.value) : e.to;
      lines.push('- ' + al + ' → ' + (e.type || 'related') + ' → ' + bl);
    });
    lines.push('');
    const blob = new Blob([lines.join('\n')], { type: 'text/markdown;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = (p.name || 'investigation').replace(/[^\w\-]+/g, '_') + '.md';
    a.click();
    URL.revokeObjectURL(a.href);
    toast('Markdown export');
  }

  function exportJSON() {
    if (!currentProject) return;
    currentProject.view = { ...view };
    const data = deepClone(currentProject);
    data.nodes.forEach(n => delete n._highlighted);
    downloadBlob(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }), sanitizeFilename(currentProject.name) + '.json');
    toast('JSON экспортирован');
  }

  function importJSON(file) {
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const data = JSON.parse(e.target.result);
        if (!data.nodes || !Array.isArray(data.nodes)) throw new Error('Неверный формат');
        const p = {
          id: uid(), name: data.name || 'Импорт', description: data.description || '', notes: data.notes || '',
      tags: Array.isArray(data.tags) ? data.tags : (data.tags ? String(data.tags).split(',').map(s=>s.trim()).filter(Boolean) : []),
          createdAt: data.createdAt || now(), updatedAt: now(),
          nodes: data.nodes.map(n => ({
            id: n.id || uid(), type: n.type || 'other', label: n.label || '', value: n.value || '',
            description: n.description || '', source: n.source || '', notes: n.notes || '',
            photoData: n.photoData || null, photoRatio: n.photoRatio || 1, size: n.size || settings.nodeSize,
            createdAt: n.createdAt || now(), x: n.x || 0, y: n.y || 0
          })),
          edges: (data.edges || []).map(e => ({
            id: e.id || uid(), from: e.from, to: e.to, type: e.type || 'связан с',
            description: e.description || '', width: e.width || 1.5, curve: e.curve || 0, createdAt: e.createdAt || now()
          })),
          view: data.view || { x: 0, y: 0, scale: 1 }
        };
        projects.unshift(p); saveProjects(); openProject(p.id); toast('Импортировано');
      } catch (err) { toast('Ошибка: ' + err.message); }
    };
    reader.readAsText(file);
  }

  function exportPNG() {
    if (!currentProject || !currentProject.nodes.length) { toast('Нет данных'); return; }
    const { svg, w, h } = buildExportSvg();
    const url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml;charset=utf-8' }));
    const img = new Image();
    img.onload = () => {
      const scale = 2;
      const canvas = document.createElement('canvas');
      canvas.width = w * scale; canvas.height = h * scale;
      const ctx = canvas.getContext('2d');
      const bg = settings.theme === 'dark' ? '#121212' : '#f4f4f4';
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.scale(scale, scale);
      ctx.drawImage(img, 0, 0);
      // Semi-transparent Nexus Graph logo watermark on top
      if (settings.pngLogo !== false) {
        ctx.save();
        ctx.globalAlpha = 0.12;
        const logoSize = Math.min(w, h) * 0.28;
        const lx = w / 2;
        const ly = h / 2;
        ctx.strokeStyle = settings.theme === 'dark' ? '#ffffff' : '#1a1a1a';
        ctx.fillStyle = settings.theme === 'dark' ? '#ffffff' : '#1a1a1a';
        ctx.lineWidth = logoSize * 0.03;
        // outer circle
        ctx.beginPath();
        ctx.arc(lx, ly, logoSize * 0.42, 0, Math.PI * 2);
        ctx.stroke();
        // three nodes + links (graph logo)
        const nodes = [
          [lx - logoSize * 0.18, ly - logoSize * 0.12],
          [lx + logoSize * 0.18, ly - logoSize * 0.12],
          [lx, ly + logoSize * 0.2]
        ];
        ctx.lineWidth = logoSize * 0.025;
        ctx.beginPath();
        ctx.moveTo(nodes[0][0], nodes[0][1]);
        ctx.lineTo(nodes[2][0], nodes[2][1]);
        ctx.lineTo(nodes[1][0], nodes[1][1]);
        ctx.lineTo(nodes[0][0], nodes[0][1]);
        ctx.stroke();
        nodes.forEach(([nx, ny]) => {
          ctx.beginPath();
          ctx.arc(nx, ny, logoSize * 0.07, 0, Math.PI * 2);
          ctx.fill();
        });
        ctx.globalAlpha = 0.18;
        ctx.font = `600 ${logoSize * 0.14}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillText('Nexus Graph', lx, ly + logoSize * 0.48);
        ctx.restore();
      }
      canvas.toBlob(blob => {
        downloadBlob(blob, sanitizeFilename(currentProject.name) + '.png');
        toast('PNG готов');
        URL.revokeObjectURL(url);
      }, 'image/png');
    };
    img.onerror = () => { toast('Ошибка PNG'); URL.revokeObjectURL(url); };
    img.src = url;
  }

  function exportSVG() {
    if (!currentProject || !currentProject.nodes.length) { toast('Нет данных'); return; }
    const { svg } = buildExportSvg();
    downloadBlob(new Blob(['<?xml version="1.0" encoding="UTF-8"?>\n' + svg], { type: 'image/svg+xml' }), sanitizeFilename(currentProject.name) + '.svg');
    toast('SVG готов');
  }

  function downloadBlob(blob, filename) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = filename; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 800);
  }
  function sanitizeFilename(name) {
    return (name || 'project').replace(/[^\wа-яА-ЯёЁ\- ]+/g, '').trim().slice(0, 40) || 'project';
  }

  // Demo
  function createDemoIfNeeded() {
    if (projects.length > 0) return;
    const p = createProject('Демо: Сеть Альфа', 'Вымышленное демо-расследование');
    p.notes = 'Демо с вымышленными данными.';
    const defs = [
      { type: 'person', label: 'Алексей Волков', value: 'Aleksey Volkov', description: 'Основной субъект', source: 'OSINT', x: 200, y: 160 },
      { type: 'username', label: 'alpha_wolf92', value: 'alpha_wolf92', description: 'Ник', source: 'Форум', x: 380, y: 90 },
      { type: 'social', label: 'Telegram', value: '@alpha_wolf92', description: 'Аккаунт', source: 'Поиск', x: 520, y: 70 },
      { type: 'email', label: 'Email', value: 'a.volkov@nexus-mail.test', description: 'Адрес', source: 'WHOIS', x: 100, y: 300 },
      { type: 'domain', label: 'nexus-ops.test', value: 'nexus-ops.test', description: 'Домен', source: 'DNS', x: 280, y: 360 },
      { type: 'ip', label: 'IP', value: '203.0.113.42', description: 'TEST-NET', source: 'A-запись', x: 420, y: 400 },
      { type: 'organization', label: 'ООО «Северная Звезда»', value: 'Severnaya Zvezda LLC', description: 'Юрлицо', source: 'Реестр', x: 60, y: 100 }
    ];
    const idMap = {};
    defs.forEach(d => {
      const node = { id: uid(), type: d.type, label: d.label, value: d.value, description: d.description, source: d.source, notes: '', photoData: null, size: 56, createdAt: now(), x: d.x, y: d.y };
      idMap[d.label] = node.id; p.nodes.push(node);
    });
    [
      ['Алексей Волков', 'alpha_wolf92', 'имеет аккаунт', 20],
      ['alpha_wolf92', 'Telegram', 'использует', -15],
      ['Алексей Волков', 'Email', 'использует', 30],
      ['Email', 'nexus-ops.test', 'связан с', 0],
      ['nexus-ops.test', 'IP', 'указывает на', 10],
      ['Алексей Волков', 'ООО «Северная Звезда»', 'принадлежит', -25]
    ].forEach(([f, t, type, curve]) => {
      p.edges.push({ id: uid(), from: idMap[f], to: idMap[t], type, description: '', width: 1.0, curve, createdAt: now() });
    });
    p.view = { x: 10, y: 30, scale: 0.9 };
    saveProjects();
  }

  // Events

  // ========== Timeline / Intelligence / Lookup Center ==========
  function updateMinimap() {
    const canvas = document.getElementById('minimap-canvas');
    const box = document.getElementById('minimap');
    if (!canvas || !box || box.classList.contains('hidden') || !currentProject) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = settings.theme === 'dark' ? '#1a1a1a' : '#f0f0f0';
    ctx.fillRect(0, 0, w, h);
    const nodes = currentProject.nodes.filter(n => !hiddenTypes.has(n.type));
    if (!nodes.length) return;
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    nodes.forEach(n => {
      minX = Math.min(minX, n.x); minY = Math.min(minY, n.y);
      maxX = Math.max(maxX, n.x); maxY = Math.max(maxY, n.y);
    });
    const pad = 20;
    const bw = Math.max(1, maxX - minX), bh = Math.max(1, maxY - minY);
    const scale = Math.min((w - pad * 2) / bw, (h - pad * 2) / bh);
    const map = (x, y) => [
      pad + (x - minX) * scale + (w - pad * 2 - bw * scale) / 2,
      pad + (y - minY) * scale + (h - pad * 2 - bh * scale) / 2
    ];
    ctx.strokeStyle = '#888';
    ctx.lineWidth = 1;
    currentProject.edges.forEach(e => {
      const a = nodes.find(n => n.id === e.from);
      const b = nodes.find(n => n.id === e.to);
      if (!a || !b) return;
      const [x1, y1] = map(a.x, a.y);
      const [x2, y2] = map(b.x, b.y);
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    });
    nodes.forEach(n => {
      const [x, y] = map(n.x, n.y);
      ctx.fillStyle = MALTEGO_COLORS[n.type] || '#666';
      ctx.beginPath(); ctx.arc(x, y, 3, 0, Math.PI * 2); ctx.fill();
    });
  }

  function openTimelinePanel() {
    closeAllPanels();
    renderTimeline();
    $('#panel-timeline').classList.add('open');
  }

  function renderTimeline() {
    ensureTimeline();
    const box = $('#timeline-list');
    if (!box) return;
    const events = (currentProject && currentProject.timeline) || [];
    if (!events.length) {
      box.innerHTML = '<p class="empty-hint">Пока нет событий</p>';
      return;
    }
    box.innerHTML = events.map(ev => {
      const t = ev.time ? new Date(ev.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '';
      const d = ev.time ? new Date(ev.time).toLocaleDateString() : '';
      return `<div class="timeline-item" data-node="${ev.nodeId || ''}" data-edge="${ev.edgeId || ''}">
        <div class="timeline-time">${d} ${t}</div>
        <div class="timeline-msg">${escapeHtml(ev.message || '')}</div>
      </div>`;
    }).join('');
    box.querySelectorAll('.timeline-item').forEach(el => {
      el.onclick = () => {
        const nid = el.dataset.node;
        if (nid) {
          const n = currentProject.nodes.find(x => x.id === nid);
          if (n) {
            selectedNodeId = nid;
            view.x = graphContainer.clientWidth / 2 - n.x * view.scale;
            view.y = graphContainer.clientHeight / 2 - n.y * view.scale;
            applyViewTransform();
            renderGraph();
            openNodeSheet(nid);
          }
        }
      };
    });
  }

  function openIntelPanel() {
    closeAllPanels();
    // fill path selects
    const nodes = (currentProject && currentProject.nodes) || [];
    const opts = nodes.map(n => `<option value="${n.id}">${escapeHtml((n.label || n.value || n.type).slice(0, 40))}</option>`).join('');
    const pf = $('#path-from'), pt = $('#path-to');
    if (pf) pf.innerHTML = opts;
    if (pt) pt.innerHTML = opts;
    // type filters
    const box = $('#intel-type-filters');
    if (box) {
      const types = [...new Set(nodes.map(n => n.type))];
      box.innerHTML = types.map(t => {
        const label = (NODE_TYPES[t] || {}).label || t;
        const checked = hiddenTypes.has(t) ? '' : 'checked';
        return `<label><input type="checkbox" data-type="${t}" ${checked}> ${label}</label>`;
      }).join('');
      box.querySelectorAll('input').forEach(inp => {
        inp.onchange = () => {
          if (inp.checked) hiddenTypes.delete(inp.dataset.type);
          else hiddenTypes.add(inp.dataset.type);
          renderGraph();
        };
      });
    }
    const mm = $('#intel-minimap');
    if (mm) {
      mm.checked = !$('#minimap').classList.contains('hidden');
      mm.onchange = () => {
        $('#minimap').classList.toggle('hidden', !mm.checked);
        updateMinimap();
      };
    }
    $('#panel-intel').classList.add('open');
  }

  function getNodeDegreeMap() {
    const degree = {};
    (currentProject.nodes || []).forEach(n => { degree[n.id] = 0; });
    (currentProject.edges || []).forEach(e => {
      if (degree[e.from] != null) degree[e.from]++;
      if (degree[e.to] != null) degree[e.to]++;
    });
    return degree;
  }

  function connectedComponents() {
    const nodes = currentProject.nodes;
    const adj = {};
    nodes.forEach(n => { adj[n.id] = []; });
    currentProject.edges.forEach(e => {
      if (adj[e.from]) adj[e.from].push(e.to);
      if (adj[e.to]) adj[e.to].push(e.from);
    });
    const seen = new Set();
    const comps = [];
    nodes.forEach(n => {
      if (seen.has(n.id)) return;
      const stack = [n.id];
      const comp = [];
      seen.add(n.id);
      while (stack.length) {
        const id = stack.pop();
        comp.push(id);
        (adj[id] || []).forEach(nb => {
          if (!seen.has(nb)) { seen.add(nb); stack.push(nb); }
        });
      }
      comps.push(comp);
    });
    return comps;
  }

  function runForceLayout(opts) {
    opts = opts || {};
    const nodes = currentProject.nodes;
    const edges = currentProject.edges;
    const repulsion = opts.repulsion || 8000;
    const springLen = opts.springLen || 160;
    const springK = opts.springK || 0.08;
    const iters = opts.iters || 80;
    for (let iter = 0; iter < iters; iter++) {
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          let dx = nodes[j].x - nodes[i].x;
          let dy = nodes[j].y - nodes[i].y;
          let dist = Math.sqrt(dx * dx + dy * dy) || 1;
          const force = repulsion / (dist * dist);
          dx = dx / dist * force; dy = dy / dist * force;
          nodes[i].x -= dx; nodes[i].y -= dy;
          nodes[j].x += dx; nodes[j].y += dy;
        }
      }
      edges.forEach(e => {
        const a = nodes.find(n => n.id === e.from);
        const b = nodes.find(n => n.id === e.to);
        if (!a || !b) return;
        let dx = b.x - a.x, dy = b.y - a.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const force = (dist - springLen) * springK;
        dx = dx / dist * force; dy = dy / dist * force;
        a.x += dx; a.y += dy; b.x -= dx; b.y -= dy;
      });
    }
  }

  function applyLayout(name) {
    if (!currentProject || !currentProject.nodes.length) { toast('Нет узлов'); return; }
    pushHistory();
    const nodes = currentProject.nodes;
    const degree = getNodeDegreeMap();
    const cx = nodes.reduce((s, n) => s + n.x, 0) / nodes.length;
    const cy = nodes.reduce((s, n) => s + n.y, 0) / nodes.length;

    if (name === 'force') runForceLayout({ repulsion: 8000, springLen: 160, springK: 0.08, iters: 90 });
    else if (name === 'force-tight') runForceLayout({ repulsion: 4000, springLen: 100, springK: 0.12, iters: 90 });
    else if (name === 'force-spread') runForceLayout({ repulsion: 16000, springLen: 220, springK: 0.05, iters: 100 });
    else if (name === 'circle') {
      const R = 80 + nodes.length * 12;
      nodes.forEach((n, i) => {
        const a = (i / nodes.length) * Math.PI * 2 - Math.PI / 2;
        n.x = cx + Math.cos(a) * R;
        n.y = cy + Math.sin(a) * R;
      });
    } else if (name === 'circle-type') {
      groupByTypes(true);
    } else if (name === 'spiral') {
      nodes.forEach((n, i) => {
        const a = i * 0.55;
        const r = 30 + i * 14;
        n.x = cx + Math.cos(a) * r;
        n.y = cy + Math.sin(a) * r;
      });
    } else if (name === 'grid') {
      const cols = Math.ceil(Math.sqrt(nodes.length));
      const gap = 120;
      nodes.forEach((n, i) => {
        n.x = cx + (i % cols - cols / 2) * gap;
        n.y = cy + (Math.floor(i / cols) - cols / 2) * gap;
      });
    } else if (name === 'grid-type') {
      const groups = {};
      nodes.forEach(n => { (groups[n.type] = groups[n.type] || []).push(n); });
      const types = Object.keys(groups);
      types.forEach((t, ti) => {
        const list = groups[t];
        const cols = Math.ceil(Math.sqrt(list.length));
        list.forEach((n, i) => {
          n.x = cx + (ti - types.length / 2) * 280 + (i % cols) * 90;
          n.y = cy + Math.floor(i / cols) * 90;
        });
      });
    } else if (name === 'hierarchy' || name === 'hierarchy-lr') {
      // BFS layers from highest degree node
      const start = nodes.slice().sort((a, b) => degree[b.id] - degree[a.id])[0];
      const adj = {};
      nodes.forEach(n => { adj[n.id] = []; });
      currentProject.edges.forEach(e => {
        adj[e.from].push(e.to); adj[e.to].push(e.from);
      });
      const level = { [start.id]: 0 };
      const q = [start.id];
      while (q.length) {
        const id = q.shift();
        (adj[id] || []).forEach(nb => {
          if (level[nb] === undefined) { level[nb] = level[id] + 1; q.push(nb); }
        });
      }
      nodes.forEach(n => { if (level[n.id] === undefined) level[n.id] = 0; });
      const byLevel = {};
      nodes.forEach(n => {
        const L = level[n.id];
        (byLevel[L] = byLevel[L] || []).push(n);
      });
      Object.keys(byLevel).forEach(L => {
        const list = byLevel[L];
        list.forEach((n, i) => {
          if (name === 'hierarchy-lr') {
            n.x = cx + Number(L) * 160;
            n.y = cy + (i - list.length / 2) * 100;
          } else {
            n.x = cx + (i - list.length / 2) * 110;
            n.y = cy + Number(L) * 130;
          }
        });
      });
    } else if (name === 'radial' || name === 'radial-degree') {
      const sorted = nodes.slice().sort((a, b) => name === 'radial-degree' ? (degree[b.id] - degree[a.id]) : 0);
      const hub = sorted[0];
      hub.x = cx; hub.y = cy;
      const rest = sorted.slice(1);
      rest.forEach((n, i) => {
        const a = (i / rest.length) * Math.PI * 2;
        const r = 120 + (degree[n.id] || 0) * 8;
        n.x = cx + Math.cos(a) * r;
        n.y = cy + Math.sin(a) * r;
      });
    } else if (name === 'cluster') {
      const comps = connectedComponents();
      const R = 200 + comps.length * 40;
      comps.forEach((comp, ci) => {
        const a = (ci / comps.length) * Math.PI * 2;
        const gx = cx + Math.cos(a) * R;
        const gy = cy + Math.sin(a) * R;
        comp.forEach((id, i) => {
          const n = nodes.find(x => x.id === id);
          if (!n) return;
          const aa = (i / comp.length) * Math.PI * 2;
          const r = 30 + comp.length * 6;
          n.x = gx + Math.cos(aa) * r;
          n.y = gy + Math.sin(aa) * r;
        });
      });
    } else if (name === 'bipartite') {
      // split by median degree
      const sorted = nodes.slice().sort((a, b) => degree[a.id] - degree[b.id]);
      const mid = Math.floor(sorted.length / 2);
      sorted.forEach((n, i) => {
        if (i < mid) {
          n.x = cx - 180;
          n.y = cy + (i - mid / 2) * 90;
        } else {
          n.x = cx + 180;
          n.y = cy + (i - mid - (sorted.length - mid) / 2) * 90;
        }
      });
    } else if (name === 'arc') {
      nodes.forEach((n, i) => {
        const t = i / Math.max(1, nodes.length - 1);
        const a = Math.PI + t * Math.PI;
        n.x = cx + Math.cos(a) * 220;
        n.y = cy + Math.sin(a) * 120;
      });
    } else if (name === 'square') {
      const per = Math.ceil(nodes.length / 4) || 1;
      nodes.forEach((n, i) => {
        const side = Math.floor(i / per) % 4;
        const t = (i % per) / per;
        const S = 200;
        if (side === 0) { n.x = cx - S + t * 2 * S; n.y = cy - S; }
        else if (side === 1) { n.x = cx + S; n.y = cy - S + t * 2 * S; }
        else if (side === 2) { n.x = cx + S - t * 2 * S; n.y = cy + S; }
        else { n.x = cx - S; n.y = cy + S - t * 2 * S; }
      });
    } else if (name === 'hex') {
      nodes.forEach((n, i) => {
        const a = (i / nodes.length) * Math.PI * 2;
        // approximate hex by clamping radius
        const R = 200;
        const hx = Math.cos(a), hy = Math.sin(a);
        const k = 1 / Math.max(Math.abs(hx), Math.abs(Math.cos(a - Math.PI / 6)));
        n.x = cx + hx * R * 0.85;
        n.y = cy + hy * R * 0.85;
      });
    } else if (name === 'tree') {
      // simple rooted tree layout from max-degree
      const start = nodes.slice().sort((a, b) => degree[b.id] - degree[a.id])[0];
      const adj = {};
      nodes.forEach(n => { adj[n.id] = []; });
      currentProject.edges.forEach(e => {
        adj[e.from].push(e.to); adj[e.to].push(e.from);
      });
      const parent = { [start.id]: null };
      const order = [start.id];
      const q = [start.id];
      while (q.length) {
        const id = q.shift();
        (adj[id] || []).forEach(nb => {
          if (parent[nb] === undefined) { parent[nb] = id; q.push(nb); order.push(nb); }
        });
      }
      nodes.forEach(n => { if (parent[n.id] === undefined) parent[n.id] = null; });
      const children = {};
      Object.keys(parent).forEach(id => {
        const p = parent[id];
        if (p) { (children[p] = children[p] || []).push(id); }
      });
      const leafGap = 100;
      function place(id, depth, x0) {
        const ch = children[id] || [];
        const n = nodes.find(x => x.id === id);
        if (!ch.length) {
          if (n) { n.x = x0; n.y = cy + depth * 120; }
          return x0 + leafGap;
        }
        let x = x0;
        ch.forEach(c => { x = place(c, depth + 1, x); });
        if (n) {
          n.x = (x0 + x - leafGap) / 2;
          n.y = cy + depth * 120;
        }
        return x;
      }
      place(start.id, 0, cx - (nodes.length * leafGap) / 4);
    } else if (name === 'concentric') {
      const sorted = nodes.slice().sort((a, b) => degree[b.id] - degree[a.id]);
      const rings = [[], [], [], []];
      sorted.forEach((n, i) => rings[Math.min(3, Math.floor(i / Math.max(1, Math.ceil(sorted.length / 4))))].push(n));
      rings.forEach((ring, ri) => {
        const R = 60 + ri * 90;
        ring.forEach((n, i) => {
          const a = (i / Math.max(1, ring.length)) * Math.PI * 2;
          n.x = cx + Math.cos(a) * R;
          n.y = cy + Math.sin(a) * R;
        });
      });
    } else if (name === 'degree-sort') {
      const sorted = nodes.slice().sort((a, b) => degree[b.id] - degree[a.id]);
      sorted.forEach((n, i) => {
        n.x = cx + (i - sorted.length / 2) * 100;
        n.y = cy + (degree[n.id] || 0) * -15;
      });
    } else if (name === 'timeline-x') {
      const sorted = nodes.slice().sort((a, b) => (a.createdAt || '').localeCompare(b.createdAt || ''));
      sorted.forEach((n, i) => {
        n.x = cx + (i - sorted.length / 2) * 110;
        n.y = cy + (i % 2 === 0 ? -40 : 40);
      });
    } else if (name === 'alphabet') {
      const sorted = nodes.slice().sort((a, b) => (a.label || a.value || '').localeCompare(b.label || b.value || '', 'ru'));
      const cols = Math.ceil(Math.sqrt(sorted.length));
      sorted.forEach((n, i) => {
        n.x = cx + (i % cols - cols / 2) * 120;
        n.y = cy + (Math.floor(i / cols) - cols / 2) * 100;
      });
    } else if (name === 'random') {
      nodes.forEach(n => {
        n.x = cx + (Math.random() - 0.5) * 500;
        n.y = cy + (Math.random() - 0.5) * 500;
      });
    } else if (name === 'center-hub') {
      const hub = nodes.slice().sort((a, b) => degree[b.id] - degree[a.id])[0];
      hub.x = cx; hub.y = cy;
      nodes.filter(n => n.id !== hub.id).forEach((n, i, arr) => {
        const a = (i / arr.length) * Math.PI * 2;
        n.x = cx + Math.cos(a) * 200;
        n.y = cy + Math.sin(a) * 200;
      });
    } else if (name === 'layers-type') {
      const groups = {};
      nodes.forEach(n => { (groups[n.type] = groups[n.type] || []).push(n); });
      const types = Object.keys(groups);
      types.forEach((t, ti) => {
        groups[t].forEach((n, i) => {
          n.x = cx + (i - groups[t].length / 2) * 100;
          n.y = cy + (ti - types.length / 2) * 140;
        });
      });
    } else {
      runForceLayout({});
    }

    touchProject();
    renderGraph();
    toast('Раскладка: ' + name);
  }

  function autoLayoutGraph() {
    applyLayout('force');
  }

  function groupByTypes(silent) {
    if (!currentProject || !currentProject.nodes.length) return;
    if (!silent) pushHistory();
    const groups = {};
    currentProject.nodes.forEach(n => {
      if (!groups[n.type]) groups[n.type] = [];
      groups[n.type].push(n);
    });
    const types = Object.keys(groups);
    const cx = currentProject.nodes.reduce((s, n) => s + n.x, 0) / currentProject.nodes.length;
    const cy = currentProject.nodes.reduce((s, n) => s + n.y, 0) / currentProject.nodes.length;
    const R = 180 + types.length * 30;
    types.forEach((t, ti) => {
      const angle = (ti / types.length) * Math.PI * 2;
      const gx = cx + Math.cos(angle) * R;
      const gy = cy + Math.sin(angle) * R;
      const list = groups[t];
      list.forEach((n, i) => {
        const a = (i / Math.max(1, list.length)) * Math.PI * 2;
        const r = 40 + list.length * 4;
        n.x = gx + Math.cos(a) * r;
        n.y = gy + Math.sin(a) * r;
      });
    });
    touchProject(); renderGraph();
    if (!silent) toast('Сгруппировано по типам');
  }

  function findPath(fromId, toId) {
    if (!currentProject || fromId === toId) return null;
    const adj = {};
    currentProject.nodes.forEach(n => { adj[n.id] = []; });
    currentProject.edges.forEach(e => {
      if (adj[e.from]) adj[e.from].push({ id: e.to, edgeId: e.id });
      if (adj[e.to]) adj[e.to].push({ id: e.from, edgeId: e.id });
    });
    const queue = [fromId];
    const prev = { [fromId]: null };
    const prevEdge = {};
    while (queue.length) {
      const cur = queue.shift();
      if (cur === toId) break;
      (adj[cur] || []).forEach(({ id, edgeId }) => {
        if (prev[id] !== undefined) return;
        prev[id] = cur;
        prevEdge[id] = edgeId;
        queue.push(id);
      });
    }
    if (prev[toId] === undefined) return null;
    const nodes = [];
    const edges = [];
    let c = toId;
    while (c) {
      nodes.push(c);
      if (prevEdge[c]) edges.push(prevEdge[c]);
      c = prev[c];
    }
    return { nodes: nodes.reverse(), edges: edges.reverse() };
  }

  function highlightPath(fromId, toId) {
    const enabled = document.getElementById('path-hl-enabled');
    if (enabled && !enabled.checked) {
      toast('Подсветка пути выключена');
      return;
    }
    const path = findPath(fromId, toId);
    pathHighlight.nodes = new Set();
    pathHighlight.edges = new Set();
    if (!path) {
      toast('Путь не найден');
      renderGraph();
      return;
    }
    path.nodes.forEach(id => pathHighlight.nodes.add(id));
    path.edges.forEach(id => pathHighlight.edges.add(id));
    renderGraph();
    toast('Путь: ' + path.nodes.length + ' узлов');
  }

  function clearPathHighlight() {
    pathHighlight.nodes = new Set();
    pathHighlight.edges = new Set();
    renderGraph();
  }


  // ========== Investigation Engine integration ==========
  let analysisAbort = { aborted: false };
  let pendingReviewPayload = null;

  function findNodeByCanonical(type, value) {
    if (!currentProject) return null;
    const key = (window.NexusDedupe && NexusDedupe.canonical(type, value)) || (type + '::' + String(value).toLowerCase());
    return currentProject.nodes.find(n => {
      const nk = (window.NexusDedupe && NexusDedupe.canonical(n.type, n.value || n.label)) || (n.type + '::' + String(n.value || n.label).toLowerCase());
      return nk === key;
    }) || null;
  }

  function upsertEntityFromResult(ent, parentNode, relationLabel, angle, dist) {
    if (!ent || !(ent.value || ent.label)) return null;
    const v = String(ent.value || ent.label || '');
    if (/failed|error|timeout|unavailable|not found|no-mx|mx-error|github-404|github-error/i.test(v)) return null;
    if (parentNode) {
      const pv = String(parentNode.value || parentNode.label || '').toLowerCase();
      if (v.toLowerCase() === pv) return null; // never re-add same entity as child
    }
    const existing = findNodeByCanonical(ent.type, ent.value);
    if (existing) {
      // merge evidence
      existing.evidence = existing.evidence || [];
      (ent.evidence || []).forEach(ev => {
        const dup = existing.evidence.some(e => e.source === ev.source && e.finding === ev.finding);
        if (!dup) existing.evidence.push({
          source: ev.source, url: ev.url, finding: ev.finding, status: ev.status,
          foundAt: ev.foundAt || now(), why: ev.why || ev.finding || ''
        });
      });
      existing.sourceCount = new Set((existing.evidence || []).map(e => e.source)).size;
      existing.why = (existing.evidence || []).map(e => e.why || e.finding).filter(Boolean).slice(0, 3).join(' | ');
      if (ent.confidence) existing.confidence = ent.confidence;
      if (ent.confidenceReason) existing.confidenceReason = ent.confidenceReason;
      if (window.NexusConfidence) {
        const c = NexusConfidence.scoreEntity(existing.evidence);
        existing.confidence = c.level;
        existing.confidenceReason = c.reason;
      }
      existing.updatedAt = now();
      existing.lastCheckedAt = now();
      if (parentNode && parentNode.id !== existing.id) {
        if (!currentProject.edges.some(e =>
          (e.from === parentNode.id && e.to === existing.id) ||
          (e.from === existing.id && e.to === parentNode.id))) {
          currentProject.edges.push({
            id: uid(), from: parentNode.id, to: existing.id,
            type: relationLabel || 'связан с', description: 'analysis',
            width: 1.5, curve: 0, createdAt: now(),
            evidence: ent.evidence || []
          });
          addTimelineEvent({ type: 'edge', message: 'Связь: ' + (relationLabel || ''), nodeId: existing.id });
        }
      }
      return existing;
    }
    pendingAddPos = {
      x: parentNode.x + Math.cos(angle) * dist,
      y: parentNode.y + Math.sin(angle) * dist
    };
    const node = addNode({
      type: ent.type,
      label: ent.label || ent.value,
      value: ent.value,
      source: (ent.evidence && ent.evidence[0] && ent.evidence[0].source) || 'analysis',
      description: '',
      evidence: (ent.evidence || []).map(ev => makeEvidence(
        ev.source, ev.url, ev.finding,
        ev.status === 'confirmed' ? 'confirmed' : ev.status === 'possible' ? 'possible' : ev.status === 'unverified' ? 'unverified' : 'unknown',
        ev.why || ev.finding
      )),
      sourceCount: ent.sourceCount || (ent.evidence ? new Set(ent.evidence.map(e => e.source)).size : 1),
      why: ent.why || '',
      confidence: ent.confidence || '',
      confidenceReason: ent.confidenceReason || '',
      metadata: ent.metadata || null,
      lastCheckedAt: now(),
      silent: true,
      skipHistory: true
    });
    if (node && parentNode) {
      // IP geo must never become "person is at location"
      let edgeType = relationLabel || 'связан с';
      if (ent.type === 'geo_estimate' || (ent.metadata && ent.metadata.kind === 'ip_geolocation_estimate')) {
        edgeType = 'geo estimate';
      }
      if (edgeType === 'находится в' && parentNode.type === 'ip') {
        edgeType = 'geo estimate';
      }
      if (!currentProject.edges.some(e =>
        (e.from === parentNode.id && e.to === node.id) ||
        (e.from === node.id && e.to === parentNode.id))) {
        currentProject.edges.push({
          id: uid(), from: parentNode.id, to: node.id,
          type: edgeType, description: 'analysis',
          width: 1.5, curve: 0, createdAt: now(),
          evidence: ent.evidence || []
        });
        addTimelineEvent({ type: 'edge', message: 'Связь: ' + (relationLabel || ''), nodeId: node.id });
      }
    }
    return node;
  }

  function applyAnalysisToGraph(analysis, selectedOnly) {
    if (!currentProject || !analysis) return;
    pushHistory();
    const rootData = analysis.root;
    let root = findNodeByCanonical(rootData.type, rootData.value);
    if (!root) {
      root = addNode({
        type: rootData.type,
        label: rootData.label || rootData.value,
        value: rootData.value,
        source: 'Lookup',
        evidence: [makeEvidence('Lookup', '', 'Query root', 'confirmed')],
        silent: true,
        skipHistory: true
      });
    }

    const ents = analysis.entities || [];
    const filtered = selectedOnly
      ? ents.filter((_, i) => selectedOnly.has(i))
      : ents;

    // limit initial fan-out to avoid clutter (max 20 visible; rest still created if selected)
    const maxShow = 24;
    filtered.slice(0, maxShow).forEach((ent, i) => {
      const angle = (i / Math.max(filtered.length, 1)) * Math.PI * 2 - Math.PI / 2;
      const dist = 130 + (i % 4) * 28;
      const rel = (analysis.relationships && analysis.relationships[i] && analysis.relationships[i].type) || 'связан с';
      // find matching relationship
      const relRow = (analysis.relationships || []).find(r => r.targetValue === ent.value && r.targetType === ent.type);
      upsertEntityFromResult(ent, root, (relRow && relRow.type) || rel, angle, dist);
    });

    touchProject();
    renderGraph();
    updateLists();
    selectNode(root.id);
    addTimelineEvent({
      type: 'lookup',
      message: 'Анализ: ' + rootData.value + ' → ' + filtered.length + ' сущностей',
      nodeId: root.id
    });
    if (analysis.overflowCount) termLog('… +' + analysis.overflowCount + ' additional results not auto-added (anti-spam)');
    toast('Добавлено: ' + filtered.length + (analysis.overflowCount ? ' (+' + analysis.overflowCount + ' hidden)' : ''));
  }

  function showReviewModal(analysis) {
    pendingReviewPayload = analysis;
    const sum = $('#review-summary');
    const list = $('#review-list');
    if (sum) {
      sum.textContent = 'Найдено: ' + (analysis.entities || []).length + ' сущностей · ' +
        (analysis.relationships || []).length + ' связей · источников: ' +
        (analysis.sourceReport || []).filter(s => s.ok).length;
    }
    if (list) {
      list.innerHTML = (analysis.entities || []).map((e, i) => {
        const st = (e.evidence && e.evidence[0] && e.evidence[0].status) || 'unknown';
        return `<div class="review-item">
          <input type="checkbox" data-idx="${i}" checked id="rev-${i}">
          <label for="rev-${i}">
            <div class="rtype">${escapeHtml(e.type)} · ${st}</div>
            <div>${escapeHtml(e.label || e.value)}</div>
          </label>
        </div>`;
      }).join('') || '<p>Нет результатов</p>';
    }
    openModal('modal-review-results');
  }

  function lcProgressLine(html) {
    const el = $('#lc-progress');
    if (!el) return;
    el.classList.remove('hidden');
    el.innerHTML += html + '<br>';
    el.scrollTop = el.scrollHeight;
  }

  async function runLookupCenter(opts) {
    opts = opts || {};
    const query = (opts.query || ($('#lc-query') && $('#lc-query').value) || '').trim();
    if (!query) { toast('Введите запрос'); return; }
    if (!currentProject) { toast('Нет расследования'); return; }

    let type = opts.type || ($('#lc-type') && $('#lc-type').value) || 'auto';
    if (type === 'auto' && window.NexusDedupe) type = NexusDedupe.detectType(query);
    const depth = parseInt(($('#lc-depth') && $('#lc-depth').value) || opts.depth || 1, 10);
    const autoAdd = opts.autoAdd != null ? opts.autoAdd : ($('#lc-auto-nodes') && $('#lc-auto-nodes').checked);
    const demoMode = opts.demoMode != null ? opts.demoMode : ($('#lc-demo') && $('#lc-demo').checked);

    if (!window.NexusEngine) {
      toast('Движок не загружен');
      return;
    }

    analysisAbort = { aborted: false };
    const prog = $('#lc-progress');
    if (prog) { prog.innerHTML = ''; prog.classList.remove('hidden'); }
    const btnCancel = $('#btn-lc-cancel');
    if (btnCancel) btnCancel.classList.remove('hidden');

    lcProgressLine('<span class="run">→</span> type: ' + type + ' · depth: ' + depth + (demoMode ? ' · DEMO' : ''));

    try {
      const analysis = await NexusEngine.analyze(query, {
        type: type === 'auto' ? undefined : type,
        depth,
        demoMode,
        forceRefresh: !!opts.forceRefresh,
        abortCtrl: analysisAbort,
        onProgress(p) {
          if (p.state === 'running') lcProgressLine('<span class="run">⟳</span> ' + (p.source || '') + (p.message ? ' — ' + p.message : ''));
          else if (p.state === 'done') lcProgressLine('<span class="ok">✓</span> ' + (p.source || '') + (p.count != null ? ' (' + p.count + ')' : ''));
          else if (p.state === 'error') lcProgressLine('<span class="err">✕</span> ' + (p.source || '') + ': ' + (p.error || 'unavailable'));
          else if (p.state === 'skip') lcProgressLine('○ ' + (p.source || '') + ' skip');
        }
      });

      lcProgressLine('<span class="ok">✓</span> complete · entities ' + (analysis.entities || []).length);
      if (analysis.fromCache) lcProgressLine('· from cache');

      if (btnCancel) btnCancel.classList.add('hidden');

      if (autoAdd) {
        closeModal();
        applyAnalysisToGraph(analysis, null);
      } else {
        closeModal();
        showReviewModal(analysis);
      }
    } catch (e) {
      lcProgressLine('<span class="err">✕</span> ' + e.message);
      toast('Ошибка анализа');
      if (btnCancel) btnCancel.classList.add('hidden');
    }
  }


  async function analyzePhotoNode(nodeId) {
    const n = currentProject && currentProject.nodes.find(x => x.id === nodeId);
    if (!n || !n.photoData) { toast('Нет изображения'); return; }
    if (!window.NexusMediaIntel) { toast('Media engine не загружен'); return; }
    openTerminal('Image intelligence');
    termLog('$ analyze-image');
    try {
      const res = await NexusMediaIntel.analyzeImageDataUrl(n.photoData);
      termLog('MIME / size / hashes / EXIF…');
      pushHistory();
      (res.results || []).forEach((ent, i) => {
        const angle = (i / Math.max(res.results.length, 1)) * Math.PI * 2;
        upsertEntityFromResult({
          type: ent.type,
          value: ent.value,
          label: ent.label,
          evidence: [{
            source: ent.sourceUrl ? 'media-local' : 'media-local',
            url: ent.sourceUrl || '',
            finding: ent.finding,
            status: ent.status === 'confirmed' ? 'confirmed' : ent.status === 'possible' ? 'possible' : 'unknown',
            foundAt: now()
          }]
        }, n, (window.NexusEngine && NexusEngine.REL_LABELS[ent.relation]) || ent.relation || 'связан с', angle, 110 + (i % 3) * 20);
      });
      // store hashes on node properties
      if (res.meta) {
        n.properties = Object.assign({}, n.properties || {}, {
          mime: res.meta.mime,
          byteSize: res.meta.size,
          sha256: res.meta.sha256,
          md5: res.meta.md5,
          ahash: res.meta.ahash,
          width: res.meta.width,
          height: res.meta.height,
          exif: res.meta.exif
        });
        if (res.meta.sha256 && !n.value) n.value = res.meta.sha256.slice(0, 16) + '…';
      }
      touchProject();
      renderGraph();
      updateLists();
      termLog('[+] Image intelligence done · ' + (res.results || []).length + ' entities');
      toast('Image intel: ' + (res.results || []).length);
      addTimelineEvent({ type: 'lookup', message: 'Image intel: ' + (n.label || 'photo'), nodeId: n.id });
    } catch (e) {
      termLog('ERROR: ' + e.message);
      toast(e.message);
    }
  }

  async function recheckNode(nodeId) {
    const n = currentProject && currentProject.nodes.find(x => x.id === nodeId);
    if (!n || !window.NexusEngine) return;
    const q = n.value || n.label;
    if (!q) { toast('Нет значения'); return; }
    openTerminal('Recheck · ' + q);
    termLog('$ recheck --force');
    // snapshot children linked from this node
    const childIds = new Set();
    (currentProject.edges || []).forEach(e => {
      if (e.from === n.id) childIds.add(e.to);
      if (e.to === n.id) childIds.add(e.from);
    });
    const prevEntities = currentProject.nodes.filter(x => childIds.has(x.id)).map(x => ({
      type: x.type, value: x.value || x.label, sourceCount: x.sourceCount, evidence: x.evidence
    }));
    try {
      const analysis = await NexusEngine.analyze(q, {
        type: n.type, depth: 1, forceRefresh: true,
        photoData: n.photoData, dataUrl: n.photoData,
        onProgress(p) {
          if (p.state === 'done') termLog('  ✓ ' + p.source + (p.health ? ' [' + p.health + ']' : '') + (p.count != null ? ' (' + p.count + ')' : ''));
          if (p.state === 'error') termLog('  ✕ ' + p.source + ' [Failed]: ' + (p.error || ''));
        }
      });
      if (analysis.sourceHealth) {
        Object.entries(analysis.sourceHealth).forEach(([k, v]) => termLog('  health ' + k + ': ' + v.state));
      }
      const diff = NexusEngine.recheckDiff(prevEntities, analysis.entities || []);
      termLog('NEW: ' + diff.NEW.length + ' · CHANGED: ' + diff.CHANGED.length + ' · REMOVED: ' + diff.REMOVED.length + ' · SAME: ' + diff.SAME.length);
      diff.NEW.forEach(e => termLog('  + NEW ' + e.type + ' ' + e.value));
      diff.CHANGED.forEach(e => termLog('  ~ CHANGED ' + e.type + ' ' + e.value));
      diff.REMOVED.forEach(e => termLog('  - REMOVED ' + e.type + ' ' + e.value));
      // apply only NEW/CHANGED to graph; mark REMOVED on existing nodes
      pushHistory();
      n.lastCheckedAt = now();
      const ents = (analysis.entities || []);
      ents.forEach((ent, i) => {
        const angle = (i / Math.max(ents.length, 1)) * Math.PI * 2;
        const node = upsertEntityFromResult(ent, n, ent.relation || 'связан с', angle, 120);
        if (node) {
          const k = (window.NexusDedupe && NexusDedupe.canonical(ent.type, ent.value)) || '';
          const isNew = diff.NEW.some(x => ((NexusDedupe && NexusDedupe.canonical(x.type, x.value)) || '') === k);
          const isCh = diff.CHANGED.some(x => ((NexusDedupe && NexusDedupe.canonical(x.type, x.value)) || '') === k);
          node.recheckStatus = isNew ? 'NEW' : isCh ? 'CHANGED' : 'SAME';
        }
      });
      // mark removed children
      diff.REMOVED.forEach(e => {
        const node = findNodeByCanonical(e.type, e.value);
        if (node) node.recheckStatus = 'REMOVED';
      });
      touchProject(); renderGraph(); updateLists();
      toast('Recheck: +' + diff.NEW.length + ' ~' + diff.CHANGED.length + ' -' + diff.REMOVED.length);
      addTimelineEvent({ type: 'lookup', message: 'Recheck: ' + q, nodeId: n.id });
    } catch (e) {
      termLog('ERROR: ' + e.message);
      toast(e.message);
    }
  }

  
  async function smartExpand(nodeId) {
    const n = currentProject && currentProject.nodes.find(x => x.id === nodeId);
    if (!n || !window.NexusEngine) return;
    // Prefer type-specific full transform if available
    if (window.NexusTransforms) {
      const list = NexusTransforms.forType(n.type) || [];
      const full = list.find(t => t.id === 'full') || list[0];
      if (full && typeof runTransformOnNode === 'function') {
        return runTransformOnNode(n, full);
      }
      if (full) {
        // fall through to expand with depth 2 for infrastructure types
      }
    }
    const depth = ['domain', 'website', 'ip', 'email', 'url'].includes(n.type) ? 2 : 1;
    return expandNode(nodeId, depth);
  }

  async function expandNode(nodeId, depthOverride) {
    const n = currentProject && currentProject.nodes.find(x => x.id === nodeId);
    if (!n) return;
    let q = n.value || n.label;
    let expandType = n.type;
    if (!q) { toast('Нет значения'); return; }
    // certificate node stores ct:domain — expand as domain
    if (expandType === 'certificate' && String(q).startsWith('ct:')) {
      q = String(q).slice(3);
      expandType = 'domain';
    }
    if (!window.NexusEngine) { toast('Движок не загружен'); return; }

    const depth = Math.min(3, Math.max(1, parseInt(
      depthOverride || ($('#sheet-expand-depth') && $('#sheet-expand-depth').value) || 1, 10
    )));
    const maxNodes = depth === 1 ? 20 : depth === 2 ? 40 : 60;
    const maxRequests = depth === 1 ? 12 : depth === 2 ? 20 : 25;

    closeNodeSheet();
    openTerminal('Expand · ' + (n.label || q) + ' · depth ' + depth);
    termLog('$ expand "' + q + '" --depth ' + depth + ' --limit ' + maxNodes);
    termLog('Relationships only from sources (no invented links)');
    termLog('—'.repeat(36));

    analysisAbort = { aborted: false };
    const queue = [{ type: expandType, value: q, nodeId: n.id, level: 0 }];
    const seen = new Set();
    const keyOf = (t, v) => (window.NexusDedupe && NexusDedupe.canonical(t, v)) || (t + '::' + v);
    seen.add(keyOf(expandType, q));
    let created = 0;

    while (queue.length && !analysisAbort.aborted && created < maxNodes) {
      const item = queue.shift();
      if (item.level >= depth) continue;

      termLog('');
      termLog('[depth ' + (item.level + 1) + '] ' + item.type + ' · ' + item.value);

      let analysis;
      try {
        const nodeObj = currentProject.nodes.find(x => x.id === item.nodeId);
        analysis = await NexusEngine.analyze(item.value, {
          type: item.type,
          depth: 1,
          forceRefresh: item.level === 0,
          maxRequests: maxRequests,
          abortCtrl: analysisAbort,
          photoData: nodeObj && nodeObj.photoData,
          dataUrl: nodeObj && nodeObj.photoData,
          onProgress(p) {
            if (p.state === 'done') termLog('  ✓ ' + p.source + (p.count != null ? ' (' + p.count + ')' : ''));
            if (p.state === 'error') termLog('  ✕ ' + p.source + ': ' + (p.error || ''));
          }
        });
      } catch (e) {
        termLog('  ERROR: ' + e.message);
        continue;
      }

      const parent = currentProject.nodes.find(x => x.id === item.nodeId);
      if (!parent) continue;

      // Log what sources actually returned
      (analysis.sourceReport || []).forEach(s => {
        termLog('  ' + (s.ok ? '✓' : '✕') + ' ' + s.source +
          (s.count != null ? ' (' + s.count + ')' : '') +
          (s.error ? ' — ' + s.error : ''));
      });
      if (analysis.fromCache) termLog('  (from cache)');
      if (!(analysis.entities || []).length) {
        termLog('  No graphable entities. Errors stay in logs only.');
      }

      const ents = analysis.entities || [];
      ents.forEach((ent, i) => {
        if (created >= maxNodes) return;
        // Ensure evidence exists for confirmed results
        if (!ent.evidence || !ent.evidence.length) {
          if (ent.status === 'confirmed' || (ent.confidence && ent.confidence !== 'UNKNOWN')) {
            ent.evidence = [{
              source: ent.sourceName || ent.source || 'analysis',
              url: ent.sourceUrl || '',
              finding: ent.finding || ent.label || ent.value,
              status: ent.status || 'confirmed',
              foundAt: new Date().toISOString()
            }];
          } else {
            return;
          }
        }
        // Skip pure invented possibles for expand? keep possibles but they have source evidence
        const k = keyOf(ent.type, ent.value);
        const angle = (i / Math.max(ents.length, 1)) * Math.PI * 2;
        const dist = 120 + item.level * 40 + (i % 3) * 20;
        const relRow = (analysis.relationships || []).find(r => r.targetValue === ent.value && r.targetType === ent.type);
        const before = currentProject.nodes.length;
        const node = upsertEntityFromResult(ent, parent, (relRow && relRow.type) || 'связан с', angle, dist);
        if (currentProject.nodes.length > before) created++;

        // enqueue for next depth — only technical expandable types
        const expandTypes = ['ip', 'domain', 'email', 'url', 'website', 'mx', 'ns', 'certificate', 'asn', 'photo', 'image', 'file', 'hash', 'network', 'organization'];
        if (node && item.level + 1 < depth && expandTypes.includes(ent.type) && !seen.has(k)) {
          seen.add(k);
          queue.push({ type: ent.type, value: ent.value, nodeId: node.id, level: item.level + 1 });
        } else {
          seen.add(k);
        }
      });

      touchProject();
      renderGraph();
    }

    updateLists();
    termLog('');
    termLog('[+] Expand done. New nodes this run: ' + created);
    termLog('Tip: depth 2 expands IP/domain children (RDAP, DNS, CT).');
    addTimelineEvent({
      type: 'lookup',
      message: 'Expand depth ' + depth + ': ' + (n.label || q),
      nodeId: n.id
    });
    toast('Expand готов (depth ' + depth + ')');
    selectNode(n.id);
  }


  function renderDataSourcesSettings() {
    const box = document.getElementById('setting-data-sources');
    if (!box || !window.NexusSources) return;
    const list = NexusSources.list();
    box.innerHTML = list.map(c => {
      const en = !window.NexusApiKeys || NexusApiKeys.isEnabled(c.name);
      const key = window.NexusApiKeys ? NexusApiKeys.get(c.name) : '';
      return `<div class="ds-row" data-src="${c.name}">
        <div>
          <div class="ds-name">${c.name}</div>
          <div class="ds-meta">${(c.supportedTypes || []).join(', ')}${c.requiresApiKey ? ' · API key' : ' · no key'}</div>
        </div>
        <label class="switch-row"><input type="checkbox" class="ds-enable" ${en ? 'checked' : ''}> on</label>
        ${c.requiresApiKey ? `<input type="password" class="ds-key" placeholder="API key" value="${key.replace(/"/g, '&quot;')}">` : ''}
      </div>`;
    }).join('') || '<p class="hint-text">Нет коннекторов</p>';
  }

  function saveDataSourcesSettings() {
    if (!window.NexusApiKeys) return;
    $$('#setting-data-sources .ds-row').forEach(row => {
      const name = row.dataset.src;
      const en = row.querySelector('.ds-enable');
      const key = row.querySelector('.ds-key');
      if (en) NexusApiKeys.setEnabled(name, en.checked);
      if (key) NexusApiKeys.set(name, key.value.trim());
    });
  }


  function openTransformsSheet(nodeId) {
    const n = currentProject && currentProject.nodes.find(x => x.id === nodeId);
    if (!n || !window.NexusTransforms) { toast('Transforms недоступны'); return; }
    selectedNodeId = nodeId;
    const list = $('#transforms-list');
    const transforms = NexusTransforms.forType(n.type);
    const byId = {};
    transforms.forEach(t => { byId[t.id] = t; });
    const groups = {};
    transforms.forEach(t => {
      (groups[t.group] = groups[t.group] || []).push(t);
    });
    let html = '<p class="tf-target"><strong>' + escapeHtml((NODE_TYPES[n.type]||{}).label || n.type) + '</strong> · ' +
      escapeHtml(n.label || n.value || '') + '</p>';
    html += '<button type="button" class="btn-primary tf-run-all" id="btn-tf-run-all" style="width:100%;margin-bottom:10px">Run all safe transforms</button>';
    Object.keys(groups).forEach(g => {
      html += '<div class="tf-group"><div class="tf-group-title">' + escapeHtml(g) + '</div>';
      groups[g].forEach(t => {
        html += '<button type="button" class="tf-btn" data-tf="' + t.id + '">' + escapeHtml(t.label) + '</button>';
      });
      html += '</div>';
    });
    list.innerHTML = html;
    list.querySelectorAll('.tf-btn').forEach(btn => {
      btn.onclick = () => {
        const full = byId[btn.dataset.tf];
        if (!full) return;
        // Pass full transform incl. connectors for focused real queries
        runTransformFromUI(nodeId, Object.assign({}, full, { type: n.type, label: full.label }));
      };
    });
    const runAll = document.getElementById('btn-tf-run-all');
    if (runAll) {
      runAll.onclick = async () => {
        const prog = $('#transforms-progress');
        if (prog) { prog.classList.remove('hidden'); prog.innerHTML = 'Running all…<br>'; }
        try {
          const analysis = await NexusTransforms.runAll(n, {
            onProgress(p) {
              if (!prog) return;
              if (p.state === 'running') prog.innerHTML += '⟳ ' + (p.source || '') + '<br>';
              if (p.state === 'done') prog.innerHTML += '✓ ' + (p.source || '') + '<br>';
              if (p.state === 'failed' || p.state === 'error') prog.innerHTML += '✕ ' + (p.source || '') + '<br>';
              if (p.state === 'skipped') prog.innerHTML += '⊘ ' + (p.source || '') + ': ' + (p.message || 'skipped') + '<br>';
            }
          });
          closeTransformsSheet();
          const count = (analysis.entities || []).length;
          if (!count) {
            toast('No confirmed entities');
            openTerminal('Transforms · all');
            (analysis.sourceReport || []).forEach(s => termLog((s.ok ? '✓ ' : '✕ ') + s.source + (s.error ? ': ' + s.error : '')));
            return;
          }
          showReviewModal(analysis);
          addTimelineEvent({ type: 'lookup', message: 'Transforms all → ' + count, nodeId: n.id });
        } catch (e) {
          toast(e.message || 'Transform failed');
        }
      };
    }
    $('#transforms-progress').classList.add('hidden');
    $('#transforms-progress').innerHTML = '';
    closeNodeSheet();
    $('#sheet-transforms').classList.add('open');
  }

  function closeTransformsSheet() {
    const el = $('#sheet-transforms');
    if (el) el.classList.remove('open');
  }

  async function runTransformFromUI(nodeId, transform) {
    const n = currentProject && currentProject.nodes.find(x => x.id === nodeId);
    if (!n) return;
    const prog = $('#transforms-progress');
    if (prog) { prog.classList.remove('hidden'); prog.innerHTML = 'Running: ' + escapeHtml(transform.label) + '<br>'; }
    analysisAbort = { aborted: false };
    try {
      const analysis = await NexusTransforms.run(transform, n, {
        forceRefresh: false,
        abortCtrl: analysisAbort,
        onProgress(p) {
          if (!prog) return;
          if (p.state === 'running') prog.innerHTML += '<span class="run">⟳</span> ' + p.source + '<br>';
          if (p.state === 'done') prog.innerHTML += '<span class="ok">✓</span> ' + p.source + (p.count != null ? ' (' + p.count + ')' : '') + '<br>';
          if (p.state === 'error' || p.state === 'failed') prog.innerHTML += '<span class="err">✕</span> ' + p.source + ': ' + (p.error || p.message || '') + '<br>';
          if (p.state === 'skipped') prog.innerHTML += '<span class="err">⊘</span> ' + p.source + ': ' + (p.message || 'skipped') + '<br>';
        }
      });
      closeTransformsSheet();
      const count = (analysis.entities || []).length;
      if (!count) {
        toast('No confirmed entities found');
        openTerminal('Transform · ' + transform.label);
        termLog('Sources checked. No confirmed entities.');
        (analysis.sourceReport || []).forEach(s => termLog((s.ok ? '✓ ' : '✕ ') + s.source + (s.error ? ': ' + s.error : '')));
        return;
      }
      // Review by default for transforms (quality over quantity)
      if ($('#lc-auto-nodes') && $('#lc-auto-nodes').checked && count <= 8) {
        applyAnalysisToGraph(analysis, null);
      } else {
        showReviewModal(analysis);
      }
      addTimelineEvent({ type: 'lookup', message: 'Transform: ' + transform.label + ' → ' + count, nodeId: n.id });
    } catch (e) {
      if (prog) prog.innerHTML += '<span class="err">✕</span> ' + e.message;
      toast(e.message);
    }
  }

  function togglePinNode(id) {
    const n = currentProject && currentProject.nodes.find(x => x.id === id);
    if (!n) return;
    pushHistory();
    n.pinned = !n.pinned;
    if (n.pinned) n.tags = Array.from(new Set([...(n.tags || []), 'pinned']));
    else n.tags = (n.tags || []).filter(t => t !== 'pinned');
    touchProject(); renderGraph();
    toast(n.pinned ? 'Pinned' : 'Unpinned');
  }

  function hideNodeTypeOrNode(id) {
    const n = currentProject && currentProject.nodes.find(x => x.id === id);
    if (!n) return;
    pushHistory();
    n.hidden = true;
    touchProject(); renderGraph();
    toast('Hidden (unhide via Objects list)');
  }


  // ===== BACKGROUND ANALYSIS → GRAPH (safe enrichment) =====
  window.NexusBackgroundOnResult = async function (task, analysis) {
    if (!currentProject || !analysis) return;
    const parent = task.entityId
      ? currentProject.nodes.find(n => n.id === task.entityId)
      : findNodeByCanonical(task.type, task.value);
    if (!parent) return;

    const ents = (analysis.entities || []).slice(0, window.NexusBackground ? NexusBackground.MAX_ENTITIES_PER_RUN : 8);
    let added = 0;
    ents.forEach((ent, i) => {
      if (!ent || !(ent.value || ent.label)) return;
      // claims / findings
      if (window.NexusCorrelation) {
        const claim = NexusCorrelation.claimFromEntity(parent, ent);
        if (claim) {
          NexusBackground.addClaim(claim);
          if (!claim.blocked) {
            NexusBackground.addFinding({
              status: claim.status,
              statement: claim.statement,
              score: claim.score,
              why: claim.why,
              entityIds: [parent.id],
              targetType: claim.targetType,
              targetValue: claim.targetValue,
              relation: claim.relation,
              evidence: claim.evidence,
              sources: claim.sources
            });
          }
        }
        if (claim && claim.blocked) return; // no graph edge for identity leaps
      }

      // Only graphable entities (engine already filters; double-check)
      if (window.NexusEngine && NexusEngine.isGraphableEntity && !NexusEngine.isGraphableEntity(ent)) return;

      const angle = (i / Math.max(ents.length, 1)) * Math.PI * 2 - Math.PI / 2;
      const dist = 120 + (i % 3) * 24;
      const rel = (ent.relation && window.NexusEngine && NexusEngine.REL_LABELS[ent.relation])
        || ent.relation || 'связан с';
      // Force geo relation label for estimates
      let edgeLabel = rel;
      if (ent.type === 'geo_estimate') edgeLabel = 'geo estimate';

      const before = currentProject.nodes.length;
      const node = upsertEntityFromResult(ent, parent, edgeLabel, angle, dist);
      if (node && currentProject.nodes.length > before) {
        added++;
        // queue further analysis with depth limit
        if (task.depth < (NexusBackground.MAX_DEPTH || 2)) {
          NexusBackground.enqueueEntity(node, {
            depth: (task.depth || 0) + 1,
            priority: 'LOW',
            source: 'bg-expand'
          });
        }
      }
    });

    // Canonical intersection detection (duplicates → merge evidence only)
    if (window.NexusCorrelation) {
      const pairs = NexusCorrelation.findCanonicalIntersections(currentProject.nodes);
      pairs.forEach(p => {
        if (p.nodes.length < 2) return;
        NexusBackground.addFinding({
          status: 'NEEDS_REVIEW',
          statement: 'Duplicate canonical entities: ' + p.key,
          why: 'Several nodes share the same canonical id — consider merging manually. Not auto-merged to avoid data loss.',
          entityIds: p.nodes.map(n => n.id),
          score: 50
        });
      });
    }

    if (added > 0) {
      touchProject();
      // lightweight: don't full re-render if user is dragging — still ok on mobile batch
      renderGraph();
      updateLists();
      addTimelineEvent({
        type: 'bg',
        message: 'Background: +' + added + ' from ' + (parent.label || parent.value),
        nodeId: parent.id
      });
    }
  };

  function updateBgUi(snap) {
    if (!snap) return;
    const st = snap.stats || {};
    const chip = document.getElementById('analysis-status');
    const counts = document.getElementById('analysis-counts');
    if (chip) {
      chip.classList.toggle('running', (st.running || 0) > 0 || (st.queued || 0) > 0);
      chip.classList.toggle('idle', !(st.running || st.queued));
    }
    if (counts) {
      counts.textContent = (st.running || 0) + '/' + (st.queued || 0);
    }
    const statsEl = document.getElementById('bg-stats');
    if (statsEl) {
      statsEl.textContent = 'Queued ' + (st.queued || 0) +
        ' · Running ' + (st.running || 0) +
        ' · Done ' + (st.completed || 0) +
        ' · ✓ ' + (st.verified || 0) +
        ' · ⚠ ' + (st.needsReview || 0) +
        ' · ⚡ ' + (st.conflicts || 0);
    }
    const list = document.getElementById('bg-findings-list');
    if (list) {
      const findings = snap.findings || [];
      if (!findings.length) {
        list.innerHTML = '<p class="muted">Нет findings — движок работает в фоне</p>';
      } else {
        list.innerHTML = findings.slice(0, 30).map(f => {
          const stLabel = f.status || 'UNVERIFIED';
          return '<div class="bg-finding" data-fid="' + (f.id || '') + '">' +
            '<span class="st ' + stLabel + '">' + stLabel + (f.score != null ? ' · ' + f.score + '/100' : '') + '</span>' +
            '<div>' + escapeHtml(f.statement || '') + '</div>' +
            (f.why ? '<div class="why">' + escapeHtml(f.why) + '</div>' : '') +
            '<div class="bf-actions">' +
              (f.entityIds && f.entityIds[0] ? '<button type="button" data-act="view" data-nid="' + f.entityIds[0] + '">View in graph</button>' : '') +
              '<button type="button" data-act="why" data-fid="' + (f.id || '') + '">Why connected?</button>' +
            '</div></div>';
        }).join('');
      }
    }
  }

  function setupBackgroundUi() {
    if (!window.NexusBackground) return;
    NexusBackground.onUpdate(updateBgUi);
    updateBgUi(NexusBackground.getSnapshot());
    const en = document.getElementById('bg-enabled');
    if (en) {
      en.checked = true;
      en.onchange = () => NexusBackground.setEnabled(en.checked);
    }
    const scan = document.getElementById('btn-bg-scan');
    if (scan) scan.onclick = () => {
      if (!currentProject) return;
      NexusBackground.enqueueGraph(currentProject.nodes, { source: 'manual-scan' });
      toast('Graph queued for background analysis');
      openSidePanel('panel-intel');
    };
    const clr = document.getElementById('btn-bg-clear');
    if (clr) clr.onclick = () => { NexusBackground.clearFindings(); toast('Findings cleared'); };
    const chip = document.getElementById('analysis-status');
    if (chip) chip.onclick = () => openSidePanel('panel-intel');
    const list = document.getElementById('bg-findings-list');
    if (list) {
      list.onclick = (e) => {
        const btn = e.target.closest('button[data-act]');
        if (!btn) return;
        const act = btn.dataset.act;
        if (act === 'view' && btn.dataset.nid) {
          selectNode(btn.dataset.nid);
          const n = currentProject && currentProject.nodes.find(x => x.id === btn.dataset.nid);
          if (n) { view.x = -n.x * view.scale + graphSvg.clientWidth / 2; view.y = -n.y * view.scale + graphSvg.clientHeight / 2; applyViewTransform(); }
        }
        if (act === 'why') {
          const snap = NexusBackground.getSnapshot();
          const f = (snap.findings || []).find(x => x.id === btn.dataset.fid);
          if (!f) return;
          const lines = [
            f.statement,
            '',
            'Status: ' + (f.status || ''),
            'Score: ' + (f.score != null ? f.score + '/100' : '—'),
            'Sources: ' + (f.sources != null ? f.sources : '—'),
            '',
            'Why: ' + (f.why || '—'),
            '',
            'Evidence:'
          ];
          (f.evidence || []).forEach(ev => {
            lines.push(' · [' + (ev.source || '') + '] ' + (ev.finding || '') + (ev.url ? ' <' + ev.url + '>' : ''));
          });
          alert(lines.join('\n'));
        }
      };
    }
  }

  function openSidePanel(id) {
    document.querySelectorAll('.side-panel').forEach(p => p.classList.remove('open'));
    const p = document.getElementById(id);
    if (p) p.classList.add('open');
  }

    function bindEvents() {
    $('#btn-new-investigation').onclick = () => { $('#new-inv-name').value = ''; $('#new-inv-desc').value = ''; openModal('modal-new-investigation'); };
    $('#btn-create-investigation').onclick = () => {
      const p = createProject($('#new-inv-name').value.trim() || 'Без названия', $('#new-inv-desc').value.trim());
      closeModal(); openProject(p.id); toast('Создано');
    };
    $('#home-search-input').oninput = e => renderHome(e.target.value);

    $('#btn-back').onclick = closeProject;
    $('#btn-undo').onclick = undo;
    $('#btn-redo').onclick = redo;
    $('#btn-menu-drawer').onclick = openDrawer;

    // View mode toggle
    $$('#mode-toggle button').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        setViewMode(btn.dataset.mode);
      };
    });
    $('#btn-close-drawer').onclick = closeDrawer;
    $('#drawer-overlay').onclick = closeDrawer;

    $('#btn-search-toggle').onclick = () => {
      const ov = $('#search-overlay');
      ov.classList.toggle('hidden');
      if (!ov.classList.contains('hidden')) $('#graph-search-input').focus();
      else { searchGraph(''); if (currentProject) { currentProject.nodes.forEach(n => n._highlighted = false); renderGraph(); } }
    };
    $('#btn-close-search').onclick = () => {
      $('#search-overlay').classList.add('hidden'); $('#graph-search-input').value = '';
      searchGraph(''); if (currentProject) { currentProject.nodes.forEach(n => n._highlighted = false); renderGraph(); }
    };
    $('#graph-search-input').oninput = e => searchGraph(e.target.value);

    // Drawer actions
    $$('.drawer-item').forEach(btn => {
      btn.onclick = () => {
        const action = btn.dataset.action;
        closeDrawer();
        if (action === 'objects') { updateLists(); openPanel('objects'); }
        else if (action === 'links') { updateLists(); openPanel('links'); }
        else if (action === 'notes') { $('#project-notes').value = currentProject.notes || ''; openModal('modal-notes'); }
        else if (action === 'stats') showStats();
        else if (action === 'export-json') exportJSON();
        else if (action === 'import-json') $('#import-file').click();
        else if (action === 'export-md') exportMarkdown();
        else if (action === 'export-png') exportPNG();
        else if (action === 'export-svg') exportSVG();
        else if (action === 'settings') {
          renderDataSourcesSettings();
          $('#setting-node-size').value = settings.nodeSize;
          $('#setting-edge-labels').checked = settings.edgeLabels;
          $('#setting-theme').value = settings.theme || 'light';
          $('#setting-icon-style').value = settings.iconStyle || 'icon';
          $('#setting-edge-style').value = settings.edgeStyle || 'smooth';
          $('#setting-edge-color').value = settings.edgeColor || '#777777';
          $('#setting-png-logo').checked = settings.pngLogo !== false;
          const bgw = document.getElementById('setting-bg-watermark');
          if (bgw) bgw.checked = !!settings.bgWatermark;
          openModal('modal-settings');
        } else if (action === 'delete-project') {
          confirmAction('Удалить расследование?', 'Нельзя отменить.', () => { deleteProject(currentProjectId); closeProject(); toast('Удалено'); });
        }
      };
    });

    $$('.close-panel').forEach(btn => { btn.onclick = closeAllPanels; });

    $$('.close-sheet').forEach(btn => {
      btn.onclick = () => { closeNodeSheet(); selectedNodeId = null; renderGraph(); };
    });
    $$('.close-edge-sheet').forEach(btn => {
      btn.onclick = () => { closeEdgeSheet(); selectedEdgeId = null; renderGraph(); };
    });

    $('#btn-edit-node').onclick = () => { if (selectedNodeId) openNodeModal(selectedNodeId); };
    $('#btn-lookup-node').onclick = () => { if (selectedNodeId) lookupNode(selectedNodeId); };
    const btnOpenNode = document.getElementById('btn-open-node');
    if (btnOpenNode) btnOpenNode.onclick = () => {
      if (!selectedNodeId) return;
      showOpenTargetsForNode(selectedNodeId);
    };


    const blc = document.getElementById('btn-lookup-center');
    if (blc) blc.onclick = () => { openModal('modal-lookup-center'); setTimeout(() => $('#lc-query')?.focus(), 100); };
    const btnLcRun = document.getElementById('btn-lc-run');
    if (btnLcRun) btnLcRun.onclick = () => runLookupCenter();
    const btnLcCancel = document.getElementById('btn-lc-cancel');
    if (btnLcCancel) btnLcCancel.onclick = () => { analysisAbort.aborted = true; toast('Остановка…'); };
    const btnRevAdd = document.getElementById('btn-review-add');
    if (btnRevAdd) btnRevAdd.onclick = () => {
      if (!pendingReviewPayload) return;
      const selected = new Set();
      $$('#review-list input[type=checkbox]').forEach(cb => {
        if (cb.checked) selected.add(parseInt(cb.dataset.idx, 10));
      });
      closeModal();
      applyAnalysisToGraph(pendingReviewPayload, selected);
      pendingReviewPayload = null;
    };
    const btnRevCancel = document.getElementById('btn-review-cancel');
    if (btnRevCancel) btnRevCancel.onclick = () => { pendingReviewPayload = null; closeModal(); };
    const btnExpand = document.getElementById('btn-expand-node');
    if (btnExpand) btnExpand.onclick = () => { if (selectedNodeId) expandNode(selectedNodeId); };

    const btnTf = document.getElementById('btn-transforms-node');
    if (btnTf) btnTf.onclick = () => { if (selectedNodeId) openTransformsSheet(selectedNodeId); };
    const btnCloseTf = document.getElementById('btn-close-transforms');
    if (btnCloseTf) btnCloseTf.onclick = closeTransformsSheet;
    const btnArrange = document.getElementById('btn-auto-arrange');
    if (btnArrange) btnArrange.onclick = () => { applyLayout('force'); toast('Auto arrange'); };

    // Inject Recheck control once (no layout redesign)
    (function ensureRecheckBtn() {
      const actions = document.querySelector('#node-sheet .sheet-actions');
      if (!actions || document.getElementById('btn-recheck-node')) return;
      const b = document.createElement('button');
      b.id = 'btn-recheck-node';
      b.className = 'btn-secondary';
      b.textContent = 'Recheck / Refresh';
      b.onclick = () => { if (selectedNodeId) recheckNode(selectedNodeId); };
      actions.appendChild(b);
    })();


    const btnTl = document.getElementById('btn-timeline');
    if (btnTl) btnTl.onclick = openTimelinePanel;
    const btnIntel = document.getElementById('btn-intel');
    if (btnIntel) btnIntel.onclick = openIntelPanel;
    const btnLayout = document.getElementById('btn-auto-layout');
    const btnApplyLayout = document.getElementById('btn-apply-layout');
    if (btnApplyLayout) btnApplyLayout.onclick = () => {
      const v = document.getElementById('layout-select')?.value || 'force';
      applyLayout(v);
    };
    const pathEn = document.getElementById('path-hl-enabled');
    if (pathEn) pathEn.onchange = () => {
      if (!pathEn.checked) clearPathHighlight();
    };

    const btnGroup = document.getElementById('btn-group-types');
    if (btnGroup) btnGroup.onclick = groupByTypes;
    const btnClearPath = document.getElementById('btn-clear-path');
    if (btnClearPath) btnClearPath.onclick = clearPathHighlight;
    const btnFindPath = document.getElementById('btn-find-path');
    if (btnFindPath) btnFindPath.onclick = () => {
      const a = $('#path-from')?.value;
      const b = $('#path-to')?.value;
      if (a && b) highlightPath(a, b);
    };

    $('#btn-close-terminal').onclick = closeTerminal;

    const qinput = $('#quick-add-input');
    if (qinput) {
      qinput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); submitQuickAdd(); }
        if (e.key === 'Escape') { closeQuickAdd(); pendingAddPos = null; }
      });
      // blur closes only if empty
      qinput.addEventListener('blur', () => {
        setTimeout(() => {
          if (document.activeElement !== qinput) {
            const v = (qinput.value || '').trim();
            if (!v) closeQuickAdd();
          }
        }, 200);
      });
    }

    $('#btn-delete-node').onclick = () => {
      if (!selectedNodeId) return;
      confirmAction('Удалить объект?', 'Связи будут удалены.', () => deleteNode(selectedNodeId));
    };
    $('#btn-copy-value').onclick = () => {
      const val = $('#sheet-value').textContent;
      if (val && val !== '—') navigator.clipboard.writeText(val).then(() => toast('Скопировано')).catch(() => {});
    };
    $('#sheet-node-size').oninput = e => {
      if (!selectedNodeId) return;
      const n = currentProject.nodes.find(x => x.id === selectedNodeId);
      if (n) { n.size = parseInt(e.target.value, 10); renderGraph(); }
    };
    $('#sheet-node-size').onchange = () => { if (selectedNodeId) { pushHistory(); touchProject(); } };

    $('#btn-save-edge').onclick = () => {
      if (!selectedEdgeId) return;
      updateEdge(selectedEdgeId, {
        type: $('#edge-type-edit').value,
        width: parseFloat($('#edge-width').value),
        curve: parseFloat($('#edge-curve').value),
        description: $('#edge-desc-edit').value.trim()
      });
      // live update while on sheet
      renderGraph();
    };
    // live preview of edge params
    ['edge-width', 'edge-curve'].forEach(id => {
      $(`#${id}`).oninput = () => {
        if (!selectedEdgeId) return;
        const e = currentProject.edges.find(x => x.id === selectedEdgeId);
        if (!e) return;
        e.width = parseFloat($('#edge-width').value);
        e.curve = parseFloat($('#edge-curve').value);
        // slider overrides free control point
        delete e.cx; delete e.cy;
        renderGraph();
      };
    });
    $('#btn-delete-edge').onclick = () => {
      if (!selectedEdgeId) return;
      confirmAction('Удалить связь?', '', () => deleteEdge(selectedEdgeId));
    };

    $('#context-menu').querySelectorAll('button').forEach(btn => {
      btn.onclick = () => {
        const nodeId = $('#context-menu').dataset.nodeId;
        const action = btn.dataset.action;
        hideContextMenu();
        if (action === 'transforms') { selectNode(nodeId); openTransformsSheet(nodeId); }
        else if (action === 'expand') { selectNode(nodeId); (typeof smartExpand === 'function' ? smartExpand(nodeId) : expandNode(nodeId)); }
        else if (action === 'details') { selectNode(nodeId); openNodeSheet(nodeId); }
        else if (action === 'open') {
          selectNode(nodeId);
          openNodeSheet(nodeId);
          showOpenTargetsForNode(nodeId);
        }
        else if (action === 'pin') togglePinNode(nodeId);
        else if (action === 'hide') hideNodeTypeOrNode(nodeId);
        else if (action === 'copy') {
          const n = currentProject.nodes.find(x => x.id === nodeId);
          if (n) { navigator.clipboard.writeText(n.value || n.label || '').then(() => toast('Copied')).catch(() => toast(n.value || n.label || '')); }
        }
        else if (action === 'edit') openNodeModal(nodeId);
        else if (action === 'center') { selectNode(nodeId); centerOnNode(nodeId); }
        else if (action === 'delete') confirmAction('Удалить?', 'Связи будут удалены.', () => deleteNode(nodeId));
      };
    });
    document.addEventListener('pointerdown', e => {
      if (!$('#context-menu').contains(e.target) && !$('#context-menu').classList.contains('hidden')) hideContextMenu();
    });

    $$('.modal-cancel').forEach(btn => { btn.onclick = () => { closeModal(); pendingAddPos = null; }; });
    $('#modal-overlay').addEventListener('click', e => { if (e.target === $('#modal-overlay')) { closeModal(); pendingAddPos = null; } });

    $('#node-type').onchange = togglePhotoGroup;
    $('#btn-pick-photo').onclick = () => $('#photo-file-input').click();
    $('#photo-file-input').onchange = async e => {
      const file = e.target.files[0];
      if (!file) return;
      try {
        const result = await compressImage(file);
        pendingPhotoData = result.dataUrl;
        pendingPhotoRatio = result.ratio;
        $('#photo-status').textContent = 'Фото загружено';
        $('#photo-thumb').classList.remove('hidden');
        $('#photo-thumb').innerHTML = `<img src="${pendingPhotoData}">`;
      } catch { toast('Ошибка загрузки фото'); }
      e.target.value = '';
    };

    $('#btn-save-node').onclick = () => {
      const type = $('#node-type').value;
      let label = $('#node-label').value.trim();
      let value = $('#node-value').value.trim();
      if (type === 'text') {
        const body = ($('#node-text-body') && $('#node-text-body').value || '').trim();
        if (!body) { toast('Напишите текст'); return; }
        label = body;
        value = body;
      }
      const data = {
        type,
        label,
        value,
        description: $('#node-description').value.trim(),
        source: $('#node-source').value.trim(),
        notes: $('#node-notes').value,
        tags: ($('#node-tags') && $('#node-tags').value || '').split(',').map(s => s.trim()).filter(Boolean),
        photoData: pendingPhotoData,
        photoRatio: pendingPhotoRatio || 1
      };
      if (!data.label && !data.value && data.type !== 'photo') { toast('Укажите название или значение'); return; }
      if (data.type === 'photo' && !data.label) data.label = 'Фото';
      if (editingNodeId) updateNode(editingNodeId, data);
      else addNode(data);
      closeModal();
      pendingPhotoData = null;
    };

    $('#btn-save-notes').onclick = () => {
      currentProject.notes = $('#project-notes').value; touchProject(); closeModal(); toast('Сохранено');
    };
    $('#btn-save-settings').onclick = () => {
      settings.nodeSize = parseInt($('#setting-node-size').value, 10);
      settings.edgeLabels = $('#setting-edge-labels').checked;
      settings.theme = $('#setting-theme').value;
      settings.iconStyle = $('#setting-icon-style').value;
      settings.edgeStyle = $('#setting-edge-style').value;
      settings.edgeColor = $('#setting-edge-color').value;
      settings.pngLogo = $('#setting-png-logo').checked;
      saveDataSourcesSettings();
      const bgw = document.getElementById('setting-bg-watermark');
      settings.bgWatermark = bgw ? bgw.checked : false;
      applyBgWatermark();
      saveSettings();
      applyTheme();
      renderGraph();
      closeModal();
      toast('Применено');
    };
    $('#import-file').onchange = e => { const f = e.target.files[0]; if (f) importJSON(f); e.target.value = ''; };

    document.addEventListener('keydown', e => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return;
      if ((e.ctrlKey || e.metaKey) && e.key === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); }
      if ((e.ctrlKey || e.metaKey) && e.key === 'y') { e.preventDefault(); redo(); }
      if (e.key === 'Escape') {
        closeModal(); closeNodeSheet(); closeEdgeSheet(); hideContextMenu();
        closeAllPanels(); closeDrawer(); removeTempEdge(); isLinking = false; pendingAddPos = null; closeQuickAdd(); closeTerminal();
      }
    });
  }

  function init() {
    loadSettings(); applyTheme(); loadProjects(); createDemoIfNeeded();
    bindEvents(); setupGraphInteractions(); setupBackgroundUi(); setupTerminalDrag();
    renderHome(); showScreen('home');
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
