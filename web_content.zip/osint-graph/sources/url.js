(function () {
  const S = window.NexusSources;
  if (!S) return;

  S.register({
    name: 'url-intelligence',
    supportedTypes: ['url'],
    requiresApiKey: false,
    sourceUrl: 'URL parse + DNS',
    async analyze(value) {
      const results = [];
      const logs = [];
      let raw = String(value || '').trim();
      if (!/^https?:\/\//i.test(raw)) raw = 'https://' + raw;
      let u;
      try { u = new URL(raw); } catch (e) {
        return { ok: false, error: 'Invalid URL', results: [], logs: [{ status: 'error', detail: e.message }] };
      }
      const host = u.hostname.replace(/^www\./, '');
      const canonical = u.origin + u.pathname.replace(/\/$/, '') + (u.search || '');

      results.push({
        type: 'domain', value: host, label: host,
        relation: 'hosted_on', status: 'confirmed',
        finding: 'Host extracted from URL', sourceUrl: raw, confidence: 'HIGH'
      });
      if (u.protocol) {
        results.push({
          type: 'document', value: u.protocol.replace(':', ''), label: 'Protocol: ' + u.protocol.replace(':', ''),
          relation: 'uses_protocol', status: 'confirmed',
          finding: 'URL protocol', sourceUrl: raw, confidence: 'HIGH'
        });
      }
      if (u.port) {
        results.push({
          type: 'document', value: 'port:' + u.port, label: 'Port ' + u.port,
          relation: 'uses_port', status: 'confirmed',
          finding: 'Explicit port', sourceUrl: raw, confidence: 'HIGH'
        });
      }
      if (u.pathname && u.pathname !== '/') {
        results.push({
          type: 'document', value: u.pathname, label: 'Path ' + u.pathname.slice(0, 40),
          relation: 'path', status: 'confirmed',
          finding: 'URL path', sourceUrl: raw, confidence: 'HIGH'
        });
      }

      // DNS A/AAAA
      try {
        if (window.NexusRateLimit && NexusRateLimit.canRequest()) NexusRateLimit.consume();
        const r = await fetch('https://cloudflare-dns.com/resolve?name=' + encodeURIComponent(host) + '&type=A', {
          headers: { Accept: 'application/dns-json' }, signal: AbortSignal.timeout(8000)
        });
        if (r.ok) {
          const j = await r.json();
          (j.Answer || []).forEach(a => {
            if (a.data) results.push({
              type: 'ip', value: a.data, label: a.data,
              relation: 'resolves_to', status: 'confirmed',
              finding: host + ' A → ' + a.data, sourceUrl: 'https://cloudflare-dns.com', confidence: 'HIGH'
            });
          });
        }
      } catch (e) {
        logs.push({ check: 'A', status: 'error', detail: e.message });
      }

      return {
        ok: true,
        meta: { url: raw, canonical: canonical, host: host },
        results: results,
        logs: logs,
        source: 'url-intelligence'
      };
    },
    normalizeResult(r) { return r; }
  });
})();
