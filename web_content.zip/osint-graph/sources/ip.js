(function () {
  const S = window.NexusSources;
  if (!S) return;

  async function fetchJSON(url, timeout) {
    if (window.NexusRateLimit && !NexusRateLimit.canRequest()) throw new Error('Rate limit');
    if (window.NexusRateLimit) NexusRateLimit.consume();
    const r = await fetch(url, {
      signal: AbortSignal.timeout(timeout || 10000),
      headers: { Accept: 'application/json' }
    });
    if (r.status === 429) throw new Error('HTTP 429 rate limited');
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  }

  function ipVersion(ip) {
    if (window.NexusDedupe) {
      if (NexusDedupe.isIPv6 && NexusDedupe.isIPv6(ip)) return 'IPv6';
      if (NexusDedupe.isIPv4 && NexusDedupe.isIPv4(ip)) return 'IPv4';
    }
    return String(ip).includes(':') ? 'IPv6' : 'IPv4';
  }

  function makeGeoEstimate(provider, src, data) {
    const country = data.country || '';
    const region = data.region || '';
    const city = data.city || '';
    if (!country && !region && !city) return null;
    const parts = [city, region, country].filter(Boolean);
    const label = '📍 GEO ESTIMATE · ' + parts.join(', ');
    return {
      type: 'geo_estimate',
      value: parts.join(', '),
      label: label,
      relation: 'geo_estimate',
      status: 'needs_review',
      confidence: 'MEDIUM',
      finding: 'IP geolocation estimate from ' + provider +
        '. Database approximation — NOT verified physical location of a person.',
      sourceUrl: src,
      metadata: {
        kind: 'ip_geolocation_estimate',
        provider: provider,
        country: country || null,
        region: region || null,
        city: city || null,
        lat: data.lat != null ? data.lat : null,
        lon: data.lon != null ? data.lon : null,
        accuracy: data.accuracy || 'unknown',
        disclaimer: 'IP geolocation is an estimate based on the provider database, not proof of user location.'
      }
    };
  }

  // ── IP version + multi-source geo / ASN / org ──
  S.register({
    name: 'ip-geo',
    supportedTypes: ['ip'],
    requiresApiKey: false,
    sourceUrl: 'ipwho.is / geojs / ipapi.co',
    async analyze(value) {
      const ip = (window.NexusDedupe && NexusDedupe.normalizeIP(value)) || String(value).trim();
      const results = [];
      const logs = [];
      results.push({
        type: 'document', value: ipVersion(ip), label: ipVersion(ip),
        relation: 'ip_version', status: 'confirmed',
        finding: 'Address family: ' + ipVersion(ip), sourceUrl: ''
      });

      const estimates = [];
      let gotOrg = false, gotAsn = false;

      // 1) ipwho.is (CORS *)
      try {
        const d = await fetchJSON('https://ipwho.is/' + encodeURIComponent(ip));
        if (d && d.success !== false) {
          logs.push({ check: 'ipwho.is', status: 'ok' });
          const org = (d.connection && (d.connection.org || d.connection.isp)) || d.isp || d.org || '';
          const asn = (d.connection && d.connection.asn) || d.asn || '';
          const src = 'https://ipwho.is/' + ip;
          if (org) {
            results.push({ type: 'organization', value: org, label: org, relation: 'hosted_by', status: 'confirmed', finding: 'ISP/Org (ipwho.is): ' + org, sourceUrl: src });
            gotOrg = true;
          }
          if (asn) {
            const asnVal = String(asn).startsWith('AS') ? String(asn) : 'AS' + asn;
            results.push({ type: 'asn', value: asnVal, label: asnVal, relation: 'announced_by', status: 'confirmed', finding: 'ASN (ipwho.is): ' + asnVal, sourceUrl: src });
            gotAsn = true;
          }
          const est = makeGeoEstimate('ipwho.is', src, {
            city: d.city || '', region: d.region || '', country: d.country || '',
            lat: d.latitude, lon: d.longitude, accuracy: 'unknown'
          });
          if (est) estimates.push(est);
        } else {
          logs.push({ check: 'ipwho.is', status: 'error', detail: (d && d.message) || 'failed' });
        }
      } catch (e) {
        logs.push({ check: 'ipwho.is', status: 'error', detail: e.message });
      }

      // 2) geojs.io fallback
      try {
        const d = await fetchJSON('https://get.geojs.io/v1/ip/geo/' + encodeURIComponent(ip) + '.json');
        if (d && (d.country || d.city)) {
          logs.push({ check: 'geojs', status: 'ok' });
          const src = 'https://get.geojs.io/v1/ip/geo/' + ip + '.json';
          if (d.organization && !gotOrg) {
            results.push({ type: 'organization', value: d.organization, label: d.organization, relation: 'hosted_by', status: 'confirmed', finding: 'Org (geojs): ' + d.organization, sourceUrl: src });
            gotOrg = true;
          }
          if (d.asn && !gotAsn) {
            const asnVal = String(d.asn).startsWith('AS') ? String(d.asn) : 'AS' + d.asn;
            results.push({ type: 'asn', value: asnVal, label: asnVal, relation: 'announced_by', status: 'confirmed', finding: 'ASN (geojs): ' + asnVal, sourceUrl: src });
            gotAsn = true;
          }
          const est = makeGeoEstimate('geojs.io', src, {
            city: d.city || '', region: d.region || '', country: d.country || '',
            lat: d.latitude, lon: d.longitude, accuracy: 'unknown'
          });
          if (est) estimates.push(est);
        }
      } catch (e) {
        logs.push({ check: 'geojs', status: 'error', detail: e.message });
      }

      // 3) ipapi.co (often rate-limited — try last)
      try {
        const d = await fetchJSON('https://ipapi.co/' + encodeURIComponent(ip) + '/json/');
        if (d && !d.error) {
          logs.push({ check: 'ipapi.co', status: 'ok' });
          const src = 'https://ipapi.co/' + ip + '/';
          if (d.org && !gotOrg) {
            results.push({ type: 'organization', value: d.org, label: d.org, relation: 'hosted_by', status: 'confirmed', finding: 'ISP/Org (ipapi.co): ' + d.org, sourceUrl: src });
            gotOrg = true;
          }
          if (d.asn && !gotAsn) {
            const asnVal = String(d.asn).startsWith('AS') ? String(d.asn) : 'AS' + d.asn;
            results.push({ type: 'asn', value: asnVal, label: asnVal, relation: 'announced_by', status: 'confirmed', finding: 'ASN (ipapi.co): ' + asnVal, sourceUrl: src });
            gotAsn = true;
          }
          const est = makeGeoEstimate('ipapi.co', src, {
            city: d.city || '', region: d.region || '', country: d.country_name || d.country || '',
            lat: d.latitude, lon: d.longitude, accuracy: 'unknown'
          });
          if (est) estimates.push(est);
        } else {
          logs.push({ check: 'ipapi.co', status: 'error', detail: (d && d.reason) || 'error' });
        }
      } catch (e) {
        logs.push({ check: 'ipapi.co', status: 'error', detail: e.message });
      }

      // Conflict handling for geo
      if (estimates.length === 1) {
        results.push(estimates[0]);
      } else if (estimates.length > 1) {
        const cities = [...new Set(estimates.map(e => e.metadata && e.metadata.city).filter(Boolean))];
        const countries = [...new Set(estimates.map(e => e.metadata && e.metadata.country).filter(Boolean))];
        if (cities.length > 1 || countries.length > 1) {
          results.push({
            type: 'document',
            value: 'geo-conflict:' + ip,
            label: 'Conflicting geolocation estimates',
            relation: 'geo_estimate',
            status: 'needs_review',
            confidence: 'LOW',
            finding: 'Providers disagree: ' + estimates.map(e => (e.metadata && e.metadata.provider) + '=' + e.value).join(' | '),
            sourceUrl: '',
            metadata: { kind: 'ip_geolocation_conflict', estimates: estimates.map(e => e.metadata) }
          });
          estimates.forEach(e => results.push(e));
        } else {
          results.push(estimates[0]);
          // extra providers as evidence-only documents
          estimates.slice(1).forEach(e => {
            results.push({
              type: 'document',
              value: 'geo-src:' + (e.metadata && e.metadata.provider),
              label: 'Geo source: ' + (e.metadata && e.metadata.provider),
              relation: 'geo_estimate',
              status: 'confirmed',
              finding: e.finding,
              sourceUrl: e.sourceUrl
            });
          });
        }
      }

      const ok = results.length > 1 || gotOrg || gotAsn || estimates.length > 0;
      return { ok: ok || results.length > 0, results: results, logs: logs, source: 'ip-geo' };
    },
    normalizeResult(r) { return r; }
  });

  // ── RDAP: try rdap.org then RIPE/ARIN/APNIC ──
  S.register({
    name: 'ip-rdap',
    supportedTypes: ['ip'],
    requiresApiKey: false,
    sourceUrl: 'rdap.org / RIPE / ARIN',
    async analyze(value) {
      const ip = (window.NexusDedupe && NexusDedupe.normalizeIP(value)) || String(value).trim();
      const results = [];
      const logs = [];
      const endpoints = [
        'https://rdap.org/ip/' + encodeURIComponent(ip),
        'https://rdap.db.ripe.net/ip/' + encodeURIComponent(ip),
        'https://rdap.arin.net/registry/ip/' + encodeURIComponent(ip),
        'https://rdap.apnic.net/ip/' + encodeURIComponent(ip)
      ];

      let data = null, src = '';
      for (const url of endpoints) {
        try {
          if (window.NexusRateLimit && !NexusRateLimit.canRequest()) break;
          if (window.NexusRateLimit) NexusRateLimit.consume();
          const r = await fetch(url, { signal: AbortSignal.timeout(10000), headers: { Accept: 'application/rdap+json, application/json' } });
          if (!r.ok) {
            logs.push({ check: url, status: 'error', detail: 'HTTP ' + r.status });
            continue;
          }
          data = await r.json();
          src = url;
          logs.push({ check: url, status: 'ok' });
          break;
        } catch (e) {
          logs.push({ check: url, status: 'error', detail: e.message });
        }
      }

      if (!data) {
        return { ok: false, error: 'RDAP unavailable for this IP', results: [], logs: logs, source: 'ip-rdap' };
      }

      if (data.name) {
        results.push({ type: 'network', value: data.name, label: data.name, relation: 'netblock', status: 'confirmed', finding: 'RDAP network: ' + data.name, sourceUrl: src });
      }
      if (data.handle) {
        results.push({ type: 'document', value: String(data.handle), label: String(data.handle), relation: 'netblock', status: 'confirmed', finding: 'RDAP handle: ' + data.handle, sourceUrl: src });
      }
      if (data.startAddress && data.endAddress) {
        results.push({
          type: 'network',
          value: data.startAddress + ' - ' + data.endAddress,
          label: data.startAddress + ' – ' + data.endAddress,
          relation: 'netblock',
          status: 'confirmed',
          finding: 'RDAP range',
          sourceUrl: src
        });
      }
      if (data.country) {
        results.push({
          type: 'geo_estimate',
          value: data.country,
          label: '📍 GEO ESTIMATE · ' + data.country + ' (RDAP registry)',
          relation: 'geo_estimate',
          status: 'needs_review',
          confidence: 'LOW',
          finding: 'RDAP registry country for the IP block: ' + data.country + '. Allocation country, not verified user location.',
          sourceUrl: src,
          metadata: { kind: 'ip_geolocation_estimate', provider: 'rdap', country: data.country, accuracy: 'country-level registry' }
        });
      }
      (data.entities || []).forEach(ent => {
        let fn = '', org = '', email = '';
        const vcard = ent.vcardArray && ent.vcardArray[1];
        if (Array.isArray(vcard)) {
          vcard.forEach(row => {
            if (!Array.isArray(row)) return;
            if (row[0] === 'fn') fn = row[3];
            if (row[0] === 'org') org = row[3];
            if (row[0] === 'email') email = row[3];
          });
        }
        if (org) {
          results.push({ type: 'organization', value: org, label: org, relation: 'registered_to', status: 'confirmed', finding: 'RDAP org: ' + org, sourceUrl: src });
        }
        if (fn && fn !== org) {
          results.push({ type: 'organization', value: fn, label: fn, relation: 'registered_to', status: 'confirmed', finding: 'RDAP entity: ' + fn, sourceUrl: src });
        }
        if (email) {
          results.push({ type: 'email', value: email, label: email, relation: 'related_to', status: 'confirmed', finding: 'RDAP contact email', sourceUrl: src });
        }
      });

      return { ok: results.length > 0, results: results, logs: logs, source: 'ip-rdap' };
    },
    normalizeResult(r) { return r; }
  });

  // ── PTR via Cloudflare + Google DoH ──
  S.register({
    name: 'ip-ptr',
    supportedTypes: ['ip'],
    requiresApiKey: false,
    sourceUrl: 'Cloudflare / Google DoH',
    async analyze(value) {
      const ip = (window.NexusDedupe && NexusDedupe.normalizeIP(value)) || String(value).trim();
      const results = [];
      const logs = [];
      const parts = ip.split('.');
      if (parts.length !== 4) {
        return { ok: true, results: [], logs: [{ status: 'skip', detail: 'IPv6 PTR not implemented' }], source: 'ip-ptr' };
      }
      const ptr = parts.slice().reverse().join('.') + '.in-addr.arpa';
      const resolvers = [
        'https://cloudflare-dns.com/resolve?name=' + encodeURIComponent(ptr) + '&type=PTR',
        'https://dns.google/resolve?name=' + encodeURIComponent(ptr) + '&type=PTR'
      ];
      for (const url of resolvers) {
        try {
          if (window.NexusRateLimit && !NexusRateLimit.canRequest()) break;
          if (window.NexusRateLimit) NexusRateLimit.consume();
          const r = await fetch(url, {
            headers: { Accept: 'application/dns-json' },
            signal: AbortSignal.timeout(8000)
          });
          if (!r.ok) throw new Error('HTTP ' + r.status);
          const data = await r.json();
          const answers = data.Answer || [];
          answers.forEach(a => {
            const host = String(a.data || '').replace(/\.$/, '');
            if (host && !results.some(x => x.value === host)) {
              results.push({
                type: 'domain', value: host, label: host,
                relation: 'ptr_record', status: 'confirmed',
                finding: 'Reverse DNS PTR: ' + host, sourceUrl: url.split('?')[0]
              });
            }
          });
          logs.push({ check: url.split('?')[0], status: answers.length ? 'ok' : 'empty' });
          if (results.length) break;
        } catch (e) {
          logs.push({ check: url.split('?')[0], status: 'error', detail: e.message });
        }
      }
      return { ok: true, results: results, logs: logs, source: 'ip-ptr' };
    },
    normalizeResult(r) { return r; }
  });

  S.register({
    name: 'ip-ripe-stat',
    supportedTypes: ['ip'],
    requiresApiKey: false,
    sourceUrl: 'https://stat.ripe.net',
    async analyze(value) {
      const ip = (window.NexusDedupe && NexusDedupe.normalizeIP(value)) || String(value).trim();
      const results = [];
      const logs = [];
      try {
        if (window.NexusRateLimit && !NexusRateLimit.canRequest()) throw new Error('Rate limit');
        if (window.NexusRateLimit) NexusRateLimit.consume();
        const url = 'https://stat.ripe.net/data/prefix-overview/data.json?resource=' + encodeURIComponent(ip);
        const r = await fetch(url, { signal: AbortSignal.timeout(10000) });
        if (!r.ok) throw new Error('HTTP ' + r.status);
        const j = await r.json();
        const d = j.data || {};
        logs.push({ check: 'ripe-stat', status: 'ok' });
        const src = url;
        if (d.resource) {
          results.push({
            type: 'network', value: String(d.resource), label: String(d.resource),
            relation: 'netblock', status: 'confirmed',
            finding: 'RIPE Stat prefix: ' + d.resource, sourceUrl: src, confidence: 'HIGH'
          });
        }
        (d.asns || []).forEach(a => {
          const asn = a.asn != null ? 'AS' + a.asn : null;
          const holder = a.holder || '';
          if (asn) {
            results.push({
              type: 'asn', value: asn, label: asn,
              relation: 'announced_by', status: 'confirmed',
              finding: 'ASN from RIPE Stat: ' + asn + (holder ? ' (' + holder + ')' : ''),
              sourceUrl: src, confidence: 'HIGH'
            });
          }
          if (holder) {
            results.push({
              type: 'organization', value: holder, label: holder,
              relation: 'announced_by', status: 'confirmed',
              finding: 'ASN holder (RIPE Stat): ' + holder, sourceUrl: src, confidence: 'HIGH'
            });
          }
        });
        return { ok: results.length > 0, results: results, logs: logs, source: 'ip-ripe-stat' };
      } catch (e) {
        logs.push({ check: 'ripe-stat', status: 'error', detail: e.message });
        return { ok: false, error: e.message, results: [], logs: logs, source: 'ip-ripe-stat' };
      }
    },
    normalizeResult(r) { return r; }
  });
})();
