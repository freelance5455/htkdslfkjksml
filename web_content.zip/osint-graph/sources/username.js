(function () {
  const S = window.NexusSources;
  if (!S) return;

  // Public profile URL templates — only CONFIRMED presence goes to graph
  const SITES = [
    { id: 'github', host: 'github.com', url: u => 'https://github.com/' + u,
      ok: (s, t, h) => s === 200 && !/Not Found|404/i.test(t) && (/repositories|followers|joined/i.test(t) || /og:title/i.test(t)) },
    { id: 'gitlab', host: 'gitlab.com', url: u => 'https://gitlab.com/' + u,
      ok: (s, t) => s === 200 && !/Page Not Found|404/i.test(t) },
    { id: 'bitbucket', host: 'bitbucket.org', url: u => 'https://bitbucket.org/' + u + '/',
      ok: (s, t) => s === 200 && !/Page not found|Repository not found/i.test(t) },
    { id: 'codeberg', host: 'codeberg.org', url: u => 'https://codeberg.org/' + u,
      ok: (s, t) => s === 200 && !/Page Not Found|404/i.test(t) },
    { id: 'reddit', host: 'reddit.com', url: u => 'https://www.reddit.com/user/' + u + '.json',
      ok: (s, t) => s === 200 && /"kind"\s*:\s*"t2"|total_karma/i.test(t) },
    { id: 'hackernews', host: 'news.ycombinator.com', url: u => 'https://hacker-news.firebaseio.com/v0/user/' + u + '.json',
      ok: (s, t) => s === 200 && t && t !== 'null' && /"created"/i.test(t) },
    { id: 'stackoverflow', host: 'stackoverflow.com', url: u => 'https://api.stackexchange.com/2.3/users?order=desc&sort=reputation&inname=' + encodeURIComponent(u) + '&site=stackoverflow',
      ok: (s, t) => {
        if (s !== 200) return false;
        try { const j = JSON.parse(t); return j.items && j.items.length > 0 && j.items.some(i => (i.display_name || '').toLowerCase() === u.toLowerCase()); } catch { return false; }
      } },
    { id: 'npm', host: 'npmjs.com', url: u => 'https://registry.npmjs.org/-/user/org.couchdb.user:' + u,
      ok: (s, t) => s === 200 && /"name"/i.test(t) },
    { id: 'pypi', host: 'pypi.org', url: u => 'https://pypi.org/user/' + u + '/',
      ok: (s, t) => s === 200 && !/Not Found|404/i.test(t) && /packages|profile/i.test(t) },
    { id: 'dockerhub', host: 'hub.docker.com', url: u => 'https://hub.docker.com/v2/users/' + u + '/',
      ok: (s, t) => s === 200 && /"username"|uuid/i.test(t) },
    { id: 'keybase', host: 'keybase.io', url: u => 'https://keybase.io/_/api/1.0/user/lookup.json?username=' + encodeURIComponent(u),
      ok: (s, t) => s === 200 && /"them"|username/i.test(t) && !/"error"/i.test(t) },
    { id: 'devto', host: 'dev.to', url: u => 'https://dev.to/' + u,
      ok: (s, t) => s === 200 && !/Not Found|404/i.test(t) },
    { id: 'medium', host: 'medium.com', url: u => 'https://medium.com/@' + u,
      ok: (s, t) => s === 200 && !/404|not found/i.test(t) },
    { id: 'kaggle', host: 'kaggle.com', url: u => 'https://www.kaggle.com/' + u,
      ok: (s, t) => s === 200 && !/404|Page Not Found/i.test(t) },
    { id: 'huggingface', host: 'huggingface.co', url: u => 'https://huggingface.co/' + u,
      ok: (s, t) => s === 200 && !/404|not found/i.test(t) },
    { id: 'replit', host: 'replit.com', url: u => 'https://replit.com/@' + u,
      ok: (s, t) => s === 200 && !/404|not found/i.test(t) },
    { id: 'aboutme', host: 'about.me', url: u => 'https://about.me/' + u,
      ok: (s, t) => s === 200 && !/404|not found/i.test(t) },
    { id: 'gravatar', host: 'gravatar.com', url: u => 'https://en.gravatar.com/' + u + '.json',
      ok: (s, t) => s === 200 && /entry|displayName|preferredUsername/i.test(t) },
    { id: 'twitch', host: 'twitch.tv', url: u => 'https://www.twitch.tv/' + u,
      ok: (s, t) => s === 200 && !/404|Sorry/i.test(t) },
    { id: 'steam', host: 'steamcommunity.com', url: u => 'https://steamcommunity.com/id/' + u,
      ok: (s, t) => s === 200 && !/The specified profile could not be found|404/i.test(t) }
  ];

  async function probe(site, user) {
    const url = site.url(user);
    try {
      if (window.NexusRateLimit && !NexusRateLimit.canRequest()) {
        return { status: 'rate_limited', url: url };
      }
      if (window.NexusRateLimit) NexusRateLimit.consume();
      const r = await fetch(url, {
        signal: AbortSignal.timeout(9000),
        redirect: 'follow',
        headers: { Accept: 'text/html, application/json, */*' }
      });
      if (r.status === 404 || r.status === 410) return { status: 'not_found', url: url, http: r.status };
      if (r.status === 429) return { status: 'rate_limited', url: url, http: 429 };
      if (r.status === 401 || r.status === 403) return { status: 'blocked', url: url, http: r.status };
      const text = await r.text();
      const title = (text.match(/<title[^>]*>([^<]+)/i) || [])[1] || '';
      if (site.ok(r.status, text, title)) {
        return { status: 'confirmed', url: url.replace(/\.json$/, ''), http: r.status };
      }
      if (r.status === 200) return { status: 'unknown', url: url, detail: '200 but not confirmed' };
      return { status: 'not_found', url: url, http: r.status };
    } catch (e) {
      return { status: 'unknown', url: url, error: e.message || 'fetch failed' };
    }
  }

  S.register({
    name: 'username-intelligence',
    supportedTypes: ['username', 'social', 'account'],
    requiresApiKey: false,
    sourceUrl: 'public profile endpoints',
    async analyze(value) {
      const results = [];
      const logs = [];
      let user = (window.NexusDedupe && NexusDedupe.normalizeUsername(value)) || String(value || '').replace(/^@/, '').trim();
      if (!user || user.length < 2) {
        return { ok: false, error: 'Invalid username', results: [], logs: [{ status: 'error', detail: 'invalid' }] };
      }
      try {
        if (/^https?:\/\//i.test(user)) {
          const u = new URL(user);
          user = u.pathname.split('/').filter(Boolean).pop() || user;
        }
      } catch (_) {}
      user = user.replace(/^@/, '').split('/')[0];

      // Parallel batches of 4 to stay responsive
      let confirmed = 0;
      for (let i = 0; i < SITES.length; i += 4) {
        const batch = SITES.slice(i, i + 4);
        const outcomes = await Promise.all(batch.map(site => probe(site, user)));
        outcomes.forEach((p, j) => {
          const site = batch[j];
          logs.push({ check: site.id, status: p.status, url: p.url, detail: p.error || p.detail || '' });
          if (p.status === 'confirmed') {
            confirmed++;
            results.push({
              type: 'url', value: p.url, label: site.id + '/' + user,
              relation: 'has_account', status: 'confirmed',
              finding: 'Public profile CONFIRMED on ' + site.host,
              sourceUrl: p.url, confidence: 'HIGH',
              metadata: { site: site.id, username: user, verified: true }
            });
            results.push({
              type: 'social', value: site.id + ':' + user, label: site.id,
              relation: 'has_account', status: 'confirmed',
              finding: 'Platform: ' + site.id, sourceUrl: p.url, confidence: 'HIGH'
            });
          }
        });
      }

      logs.push({ check: 'summary', status: confirmed ? 'ok' : 'none', detail: confirmed + ' confirmed / ' + SITES.length + ' checked' });
      return {
        ok: true,
        meta: { username: user, confirmedProfiles: confirmed, checked: SITES.length },
        results: results, logs: logs, source: 'username-intelligence'
      };
    },
    normalizeResult(r) { return r; }
  });
})();
