(function () {
  const S = window.NexusSources;
  if (!S) return;

  // ── Country calling codes (public numbering knowledge) ──
  const CC = [
    { code: '380', iso: 'UA', country: 'Ukraine', nationalLen: [9] },
    { code: '375', iso: 'BY', country: 'Belarus', nationalLen: [9] },
    { code: '7', iso: 'RU/KZ', country: 'Russia / Kazakhstan', nationalLen: [10] },
    { code: '1', iso: 'US/CA', country: 'USA / Canada', nationalLen: [10] },
    { code: '44', iso: 'GB', country: 'United Kingdom', nationalLen: [10] },
    { code: '49', iso: 'DE', country: 'Germany', nationalLen: [10, 11] },
    { code: '33', iso: 'FR', country: 'France', nationalLen: [9] },
    { code: '48', iso: 'PL', country: 'Poland', nationalLen: [9] },
    { code: '371', iso: 'LV', country: 'Latvia', nationalLen: [8] },
    { code: '372', iso: 'EE', country: 'Estonia', nationalLen: [7, 8] },
    { code: '370', iso: 'LT', country: 'Lithuania', nationalLen: [8] },
    { code: '90', iso: 'TR', country: 'Turkey', nationalLen: [10] },
    { code: '994', iso: 'AZ', country: 'Azerbaijan', nationalLen: [9] },
    { code: '995', iso: 'GE', country: 'Georgia', nationalLen: [9] },
    { code: '374', iso: 'AM', country: 'Armenia', nationalLen: [8] },
    { code: '998', iso: 'UZ', country: 'Uzbekistan', nationalLen: [9] },
    { code: '996', iso: 'KG', country: 'Kyrgyzstan', nationalLen: [9] },
    { code: '86', iso: 'CN', country: 'China', nationalLen: [11] },
    { code: '91', iso: 'IN', country: 'India', nationalLen: [10] },
    { code: '81', iso: 'JP', country: 'Japan', nationalLen: [10] },
    { code: '61', iso: 'AU', country: 'Australia', nationalLen: [9] },
    { code: '55', iso: 'BR', country: 'Brazil', nationalLen: [10, 11] },
    { code: '39', iso: 'IT', country: 'Italy', nationalLen: [9, 10] },
    { code: '34', iso: 'ES', country: 'Spain', nationalLen: [9] },
    { code: '972', iso: 'IL', country: 'Israel', nationalLen: [8, 9] },
    { code: '971', iso: 'AE', country: 'UAE', nationalLen: [9] },
    { code: '420', iso: 'CZ', country: 'Czechia', nationalLen: [9] },
    { code: '421', iso: 'SK', country: 'Slovakia', nationalLen: [9] },
    { code: '40', iso: 'RO', country: 'Romania', nationalLen: [9] },
    { code: '36', iso: 'HU', country: 'Hungary', nationalLen: [8, 9] },
    { code: '43', iso: 'AT', country: 'Austria', nationalLen: [10, 11] },
    { code: '41', iso: 'CH', country: 'Switzerland', nationalLen: [9] },
    { code: '46', iso: 'SE', country: 'Sweden', nationalLen: [9] },
    { code: '47', iso: 'NO', country: 'Norway', nationalLen: [8] },
    { code: '45', iso: 'DK', country: 'Denmark', nationalLen: [8] },
    { code: '358', iso: 'FI', country: 'Finland', nationalLen: [9, 10] },
    { code: '31', iso: 'NL', country: 'Netherlands', nationalLen: [9] },
    { code: '32', iso: 'BE', country: 'Belgium', nationalLen: [8, 9] },
    { code: '351', iso: 'PT', country: 'Portugal', nationalLen: [9] },
    { code: '30', iso: 'GR', country: 'Greece', nationalLen: [10] },
    { code: '353', iso: 'IE', country: 'Ireland', nationalLen: [9] },
    { code: '64', iso: 'NZ', country: 'New Zealand', nationalLen: [8, 9] },
    { code: '82', iso: 'KR', country: 'South Korea', nationalLen: [9, 10] },
    { code: '65', iso: 'SG', country: 'Singapore', nationalLen: [8] },
    { code: '60', iso: 'MY', country: 'Malaysia', nationalLen: [9, 10] },
    { code: '66', iso: 'TH', country: 'Thailand', nationalLen: [9] },
    { code: '62', iso: 'ID', country: 'Indonesia', nationalLen: [9, 11] },
    { code: '63', iso: 'PH', country: 'Philippines', nationalLen: [10] },
    { code: '52', iso: 'MX', country: 'Mexico', nationalLen: [10] },
    { code: '54', iso: 'AR', country: 'Argentina', nationalLen: [10] },
    { code: '57', iso: 'CO', country: 'Colombia', nationalLen: [10] },
    { code: '56', iso: 'CL', country: 'Chile', nationalLen: [9] },
    { code: '27', iso: 'ZA', country: 'South Africa', nationalLen: [9] },
    { code: '20', iso: 'EG', country: 'Egypt', nationalLen: [10] },
    { code: '234', iso: 'NG', country: 'Nigeria', nationalLen: [10] },
    { code: '254', iso: 'KE', country: 'Kenya', nationalLen: [9] },
    { code: '966', iso: 'SA', country: 'Saudi Arabia', nationalLen: [9] },
    { code: '98', iso: 'IR', country: 'Iran', nationalLen: [10] },
    { code: '92', iso: 'PK', country: 'Pakistan', nationalLen: [10] },
    { code: '880', iso: 'BD', country: 'Bangladesh', nationalLen: [10] },
    { code: '84', iso: 'VN', country: 'Vietnam', nationalLen: [9, 10] }
  ].sort((a, b) => b.code.length - a.code.length);

  // UA mobile prefixes (public numbering) — operator estimate only
  const UA_MOBILE = {
    '39': 'Kyivstar', '50': 'Vodafone UA', '63': 'lifecell', '66': 'lifecell',
    '67': 'Kyivstar', '68': 'Kyivstar', '73': 'lifecell', '91': 'TriMob',
    '92': 'PEOPLEnet', '93': 'lifecell', '94': 'Intertelecom', '95': 'Vodafone UA',
    '96': 'Kyivstar', '97': 'Kyivstar', '98': 'Kyivstar', '99': 'Vodafone UA'
  };
  // UA landline area codes (sample public)
  const UA_LAND = {
    '44': 'Kyiv', '32': 'Lviv', '56': 'Dnipro', '57': 'Kharkiv', '48': 'Odesa',
    '62': 'Donetsk', '52': 'Kropyvnytskyi', '61': 'Zaporizhzhia', '342': 'Ivano-Frankivsk'
  };
  // RU mobile DEF (public operator ranges — estimate)
  const RU_DEF = {
    '900': 'Tele2', '901': 'Beeline', '902': 'Beeline/MegaFon', '903': 'Beeline',
    '904': 'Beeline/Tele2', '905': 'Beeline', '906': 'Beeline', '908': 'MegaFon',
    '909': 'MegaFon', '910': 'MegaFon', '911': 'MegaFon', '912': 'MegaFon', '913': 'MegaFon',
    '914': 'MegaFon', '915': 'MegaFon', '916': 'MegaFon', '917': 'MegaFon', '918': 'MegaFon',
    '919': 'MegaFon', '920': 'MegaFon', '921': 'MegaFon', '922': 'MegaFon', '923': 'MegaFon',
    '924': 'MegaFon', '925': 'MegaFon', '926': 'MegaFon', '927': 'MegaFon', '928': 'MegaFon',
    '929': 'MegaFon', '930': 'MegaFon', '931': 'MegaFon', '950': 'Tele2', '951': 'Tele2',
    '952': 'Tele2', '953': 'Tele2', '960': 'Tele2', '961': 'Tele2', '962': 'Tele2',
    '963': 'Tele2', '964': 'Tele2', '965': 'Tele2', '966': 'Tele2', '967': 'Tele2',
    '968': 'Tele2', '980': 'MTS', '981': 'MTS', '982': 'MTS', '983': 'MTS', '984': 'MTS',
    '985': 'MTS', '986': 'MTS', '987': 'MTS', '988': 'MTS', '989': 'MTS',
    '495': 'Moscow landline', '499': 'Moscow landline', '812': 'SPb landline'
  };
  // PL mobile
  const PL_MOBILE = {
    '50': 'Orange/T-Mobile/Plus', '51': 'Orange/Plus', '53': 'Orange/Play',
    '57': 'Play', '60': 'Orange/Plus', '66': 'T-Mobile/Play', '69': 'Orange/Play',
    '72': 'Play', '73': 'Play', '78': 'Play', '79': 'Play', '88': 'Orange/Play'
  };

  function digitsOnly(s) { return String(s || '').replace(/\D/g, ''); }

  function normalizeE164(raw) {
    let d = digitsOnly(raw);
    if (!d) return null;
    // strip leading 00 international prefix
    if (d.startsWith('00')) d = d.slice(2);
    // UA national 0XXXXXXXXX → 380…
    if (d.length === 10 && d[0] === '0') d = '38' + d;
    if (d.length === 9 && !d.startsWith('380')) {
      // bare UA national without 0
      d = '380' + d;
    }
    // RU national 8XXXXXXXXXX → 7…
    if (d.length === 11 && d[0] === '8') d = '7' + d.slice(1);
    return d ? '+' + d : null;
  }

  function matchCountry(e164) {
    const d = digitsOnly(e164);
    for (const c of CC) {
      if (d.startsWith(c.code)) {
        const national = d.slice(c.code.length);
        return { ...c, national, e164: '+' + d };
      }
    }
    return { code: '', iso: '??', country: 'Unknown', national: d, e164: '+' + d };
  }

  function numberTypeAndCarrier(cc, national) {
    let type = 'unknown', carrier = null, region = null;
    if (cc.iso === 'UA' || cc.code === '380') {
      const p2 = national.slice(0, 2);
      const p3 = national.slice(0, 3);
      if (UA_MOBILE[p2]) { type = 'mobile'; carrier = UA_MOBILE[p2]; }
      else if (UA_LAND[p3]) { type = 'landline'; region = UA_LAND[p3]; }
      else if (UA_LAND[p2]) { type = 'landline'; region = UA_LAND[p2]; }
      else if (/^(39|50|6[3-8]|73|9[1-9])/.test(national)) type = 'mobile';
      else type = 'unknown';
    } else if (cc.code === '7') {
      const def = national.slice(0, 3);
      if (RU_DEF[def]) {
        carrier = RU_DEF[def];
        type = /landline/i.test(carrier) ? 'landline' : 'mobile';
        if (def === '495' || def === '499') region = 'Moscow';
        if (def === '812') region = 'Saint Petersburg';
      }
    } else if (cc.code === '48') {
      const p2 = national.slice(0, 2);
      if (PL_MOBILE[p2]) { type = 'mobile'; carrier = PL_MOBILE[p2]; }
    } else if (cc.code === '1') {
      type = 'unknown'; // NANP — type not reliably derivable without LERG
    } else if (cc.code === '44') {
      if (national.startsWith('7')) { type = 'mobile'; carrier = 'UK mobile'; }
      else type = 'landline';
    }
    return { type, carrier, region };
  }

  function formatVariants(e164, cc) {
    const d = digitsOnly(e164);
    const nat = cc.national;
    const out = new Set([e164, d, '+' + d]);
    if (cc.code === '380' && nat.length === 9) {
      out.add('0' + nat);
      out.add('+380' + nat);
      out.add('380' + nat);
      out.add('+38 0' + nat.slice(0, 2) + ' ' + nat.slice(2, 5) + ' ' + nat.slice(5, 7) + ' ' + nat.slice(7));
    }
    if (cc.code === '7' && nat.length === 10) {
      out.add('8' + nat);
      out.add('+7' + nat);
    }
    return [...out];
  }

  /** Extract entities that co-occur with the phone digits on a public page text */
  function extractContextFromText(text, pageUrl, phoneVariants) {
    const results = [];
    if (!text || text.length < 20) return results;
    const lower = text.toLowerCase();
    // Confirm phone presence
    const present = phoneVariants.some(v => {
      const bare = digitsOnly(v);
      return bare.length >= 8 && (text.includes(v) || text.includes(bare) || lower.includes(bare));
    });
    if (!present) return results;

    results.push({
      type: 'url', value: pageUrl, label: pageUrl.replace(/^https?:\/\//, '').slice(0, 48),
      relation: 'mentioned_on', status: 'confirmed',
      finding: 'Phone number appears on public page', sourceUrl: pageUrl,
      confidence: 'HIGH'
    });

    // Emails on same page
    const emails = text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g) || [];
    [...new Set(emails)].slice(0, 5).forEach(em => {
      results.push({
        type: 'email', value: em.toLowerCase(), label: em.toLowerCase(),
        relation: 'associated_with', status: 'confirmed',
        finding: 'Email co-occurs with phone on ' + pageUrl, sourceUrl: pageUrl,
        confidence: 'MEDIUM'
      });
    });

    // URLs / domains
    const urls = text.match(/https?:\/\/[^\s"'<>]+/g) || [];
    [...new Set(urls)].slice(0, 6).forEach(u => {
      try {
        const host = new URL(u).hostname.replace(/^www\./, '');
        results.push({
          type: 'domain', value: host, label: host,
          relation: 'associated_with', status: 'confirmed',
          finding: 'Domain linked from page where phone appears', sourceUrl: pageUrl,
          confidence: 'MEDIUM'
        });
      } catch (_) {}
    });

    // @usernames
    const users = text.match(/@[a-zA-Z0-9_]{3,30}/g) || [];
    [...new Set(users)].slice(0, 5).forEach(u => {
      results.push({
        type: 'username', value: u.replace(/^@/, ''), label: u,
        relation: 'associated_with', status: 'possible',
        finding: 'Username co-occurs on page with phone (not identity proof alone)', sourceUrl: pageUrl,
        confidence: 'LOW'
      });
    });

    return results;
  }

  async function tryFetchPublicPage(url, variants) {
    try {
      if (window.NexusRateLimit && !NexusRateLimit.canRequest()) return { status: 'rate_limited' };
      if (window.NexusRateLimit) NexusRateLimit.consume();
      const r = await fetch(url, {
        signal: AbortSignal.timeout(8000),
        redirect: 'follow',
        headers: { 'Accept': 'text/html,application/xhtml+xml' }
      });
      if (r.status === 404) return { status: 'not_found' };
      if (!r.ok) return { status: 'unknown', http: r.status };
      const ct = (r.headers.get('content-type') || '');
      if (!/text|json|html|xml/i.test(ct) && ct) return { status: 'unknown', detail: 'non-text' };
      const text = await r.text();
      const extracted = extractContextFromText(text, url, variants);
      if (!extracted.length) return { status: 'not_found', detail: 'phone not on page' };
      return { status: 'confirmed', results: extracted };
    } catch (e) {
      // CORS or network — cannot verify from pure browser
      return { status: 'unknown', error: e.message || 'fetch failed' };
    }
  }

  // Candidate public URL patterns to probe (no API key). Most will be CORS-blocked in browser —
  // only CONFIRMED results become nodes. Failures stay in logs.
  function candidatePages(e164, cc, variants) {
    const d = digitsOnly(e164);
    const urls = [];
    // tel: is not fetchable; use known public path patterns sparingly
    // Wikipedia doesn't host phone indexes; skip inventing directories
    // Only try pages user might have if we had a proxy — here we skip fake hits
    return urls;
  }


  // ── Social by phone: ONLY verified existing profiles ──
  // Viber / WhatsApp / Telegram / VK do NOT provide public phone→account APIs for browsers.
  // We never invent profile URLs. We only add a node if:
  //   1) a candidate profile URL was found on a public page mentioning the phone, OR
  //   2) a public presence probe confirms the profile URL exists (HTTP + signals).
  const SOCIAL_HOSTS = {
    'vk.com': 'vk', 'm.vk.com': 'vk',
    'facebook.com': 'facebook', 'm.facebook.com': 'facebook',
    'instagram.com': 'instagram',
    't.me': 'telegram', 'telegram.me': 'telegram',
    'ok.ru': 'odnoklassniki', 'www.ok.ru': 'odnoklassniki',
    'linkedin.com': 'linkedin',
    'twitter.com': 'twitter', 'x.com': 'twitter',
    'youtube.com': 'youtube',
    'tiktok.com': 'tiktok'
  };

  function isSocialProfileUrl(url) {
    try {
      const u = new URL(url);
      const host = u.hostname.replace(/^www\./, '').toLowerCase();
      const platform = SOCIAL_HOSTS[host] || SOCIAL_HOSTS[u.hostname.toLowerCase()];
      if (!platform) return null;
      // skip pure homepage
      if (u.pathname === '/' || u.pathname === '') return null;
      // skip login/share paths
      if (/\/(login|share|search|feed|im|settings)/i.test(u.pathname)) return null;
      return platform;
    } catch (_) { return null; }
  }

  async function verifyProfileExists(profileUrl) {
    // Prefer presence engine when available
    if (window.NexusPresence && NexusPresence.checkUrl) {
      try {
        const p = await NexusPresence.checkUrl(profileUrl);
        if (p && p.status === 'CONFIRMED') {
          return { exists: true, method: 'presence', detail: p };
        }
        if (p && (p.status === 'NOT_FOUND' || p.status === 'BLOCKED')) {
          return { exists: false, method: 'presence', detail: p };
        }
      } catch (_) {}
    }
    // Lightweight HEAD/GET probe
    try {
      if (window.NexusRateLimit && !NexusRateLimit.canRequest()) {
        return { exists: null, method: 'skip', detail: 'rate limit' };
      }
      if (window.NexusRateLimit) NexusRateLimit.consume();
      const r = await fetch(profileUrl, {
        method: 'GET',
        signal: AbortSignal.timeout(8000),
        redirect: 'follow',
        headers: { Accept: 'text/html' }
      });
      if (r.status === 404 || r.status === 410) return { exists: false, method: 'http', detail: r.status };
      if (r.status >= 200 && r.status < 400) {
        const text = await r.text();
        const low = text.slice(0, 8000).toLowerCase();
        // Fake/empty profile signals
        if (/page not found|не найдена|does not exist|user not found|account deleted|profile unavailable|this page isn.?t available/i.test(low)) {
          return { exists: false, method: 'content', detail: 'not-found-text' };
        }
        // Viber/WhatsApp deep links often don't return real profile HTML in browser — treat as unverifiable
        if (/viber:\/\/|api\.whatsapp\.com|wa\.me/i.test(profileUrl) && text.length < 500) {
          return { exists: null, method: 'unverifiable', detail: 'messenger deep-link' };
        }
        return { exists: true, method: 'http', detail: r.status };
      }
      return { exists: null, method: 'http', detail: r.status };
    } catch (e) {
      // CORS → cannot confirm from browser
      return { exists: null, method: 'cors_or_network', detail: e.message || 'fetch failed' };
    }
  }

  async function discoverAndVerifySocial(phoneVariants, results, logs) {
    // Explicit statement in logs
    logs.push({
      check: 'social-by-phone',
      status: 'info',
      detail: 'Viber/WhatsApp/Telegram/VK have no public phone→profile API in browser. Only confirmed existing profiles will be added.'
    });

    // 1) DuckDuckGo Instant Answer API (public, CORS-friendly) — discovery only
    const queryVariants = phoneVariants.slice(0, 4);
    for (const q of queryVariants) {
      try {
        if (window.NexusRateLimit && !NexusRateLimit.canRequest()) break;
        if (window.NexusRateLimit) NexusRateLimit.consume();
        const ddg = await fetch(
          'https://api.duckduckgo.com/?q=' + encodeURIComponent('"' + q + '"') + '&format=json&no_redirect=1&no_html=1',
          { signal: AbortSignal.timeout(8000) }
        );
        if (!ddg.ok) {
          logs.push({ check: 'ddg', status: 'error', detail: 'HTTP ' + ddg.status });
          continue;
        }
        const data = await ddg.json();
        const topics = [].concat(data.RelatedTopics || [], data.Results || []);
        const flat = [];
        topics.forEach(t => {
          if (t.FirstURL) flat.push(t);
          (t.Topics || []).forEach(x => flat.push(x));
        });
        if (data.AbstractURL) flat.push({ FirstURL: data.AbstractURL, Text: data.AbstractText || data.Heading });
        logs.push({ check: 'ddg', status: 'ok', detail: flat.length + ' topics for ' + q });

        for (const t of flat.slice(0, 12)) {
          const url = t.FirstURL || t.url;
          if (!url) continue;
          const platform = isSocialProfileUrl(url);
          if (!platform) {
            // non-social page that mentions phone — optional document if abstract present
            if (t.Text && /phone|тел|mobile|whatsapp|viber|vk\.com/i.test(t.Text + ' ' + url)) {
              results.push({
                type: 'url', value: url, label: url.replace(/^https?:\/\//, '').slice(0, 48),
                relation: 'mentioned_in', status: 'possible',
                finding: 'Public search hit related to phone query (verify on page)',
                sourceUrl: url, confidence: 'LOW'
              });
            }
            continue;
          }
          // Verify profile really exists before graphing
          const ver = await verifyProfileExists(url);
          logs.push({
            check: 'profile-verify',
            url: url,
            platform: platform,
            status: ver.exists === true ? 'confirmed' : ver.exists === false ? 'not_found' : 'unknown',
            detail: (ver.method || '') + ' ' + (ver.detail || '')
          });
          if (ver.exists === true) {
            results.push({
              type: 'url',
              value: url,
              label: platform + ': ' + url.replace(/^https?:\/\//, '').slice(0, 40),
              relation: 'has_account',
              status: 'confirmed',
              finding: 'Public ' + platform + ' profile URL discovered near phone mention AND presence confirmed. Not proof that phone owner = profile owner without more evidence.',
              sourceUrl: url,
              confidence: 'MEDIUM',
              metadata: { platform: platform, phoneLink: 'discovered', verified: true }
            });
            results.push({
              type: 'social',
              value: platform + ':' + url,
              label: platform,
              relation: 'has_account',
              status: 'confirmed',
              finding: 'Platform: ' + platform + ' (verified URL)',
              sourceUrl: url,
              confidence: 'MEDIUM'
            });
          }
          // not_found → do not add
          // unknown (CORS) → do not add as confirmed
        }
      } catch (e) {
        logs.push({ check: 'ddg', status: 'error', detail: e.message });
      }
    }

    // 2) Never invent messenger deep links as "found accounts"
    //    wa.me / viber:// / t.me/+phone are NOT proof of account existence from browser.
    logs.push({
      check: 'messengers',
      status: 'unavailable',
      detail: 'wa.me / viber:// / VK phonebook are not verifiable public presence checks from a web page without official API + user consent.'
    });

    // Document for the user in graph (so Expand is not "empty" without explanation)
    results.push({
      type: 'document',
      value: 'phone-social-policy',
      label: 'Social-by-phone policy',
      relation: 'note',
      status: 'confirmed',
      finding: 'Viber, WhatsApp, Telegram, VK do not expose public phone→account lookup. Only profiles that were found publicly AND verified existing are added. Unverified deep-links are never added.',
      sourceUrl: '',
      confidence: 'HIGH'
    });
  }

  S.register({
    name: 'phone-intelligence',
    supportedTypes: ['phone'],
    requiresApiKey: false,
    sourceUrl: 'public numbering plans + optional page verification',
    async analyze(value) {
      const results = [];
      const logs = [];
      const raw = String(value || '').trim();
      const e164 = normalizeE164(raw) || (window.NexusDedupe && NexusDedupe.normalizePhone(raw));
      if (!e164 || digitsOnly(e164).length < 8) {
        return { ok: false, error: 'Invalid phone', results: [], logs: [{ status: 'error', detail: 'invalid number' }] };
      }

      const cc = matchCountry(e164);
      const intel = numberTypeAndCarrier(cc, cc.national);
      const variants = formatVariants(e164, cc);

      logs.push({ check: 'normalize', status: 'ok', detail: e164 + ' variants=' + variants.length });

      // ── Numbering intelligence (always, offline, public) ──
      results.push({
        type: 'document',
        value: 'E.164 ' + e164,
        label: 'E.164: ' + e164,
        relation: 'normalized_as',
        status: 'confirmed',
        finding: 'Canonical E.164 form. Aliases: ' + variants.slice(0, 6).join(', '),
        sourceUrl: '',
        confidence: 'HIGH',
        metadata: { kind: 'phone_normalization', e164: e164, variants: variants }
      });

      results.push({
        type: 'geo_estimate',
        value: cc.country,
        label: '📍 GEO ESTIMATE · ' + cc.country + (cc.iso ? ' (' + cc.iso + ')' : ''),
        relation: 'geo_estimate',
        status: 'needs_review',
        finding: 'Country derived from calling code +' + cc.code + ' (numbering plan). NOT verified physical location of a person.',
        sourceUrl: '',
        confidence: 'MEDIUM',
        metadata: {
          kind: 'phone_geolocation_estimate',
          provider: 'numbering-plan',
          country: cc.country,
          countryCode: cc.code,
          iso: cc.iso,
          region: intel.region || null,
          city: null,
          accuracy: 'country-level only',
          disclaimer: 'Calling-code country is an allocation estimate, not proof of the user location.'
        }
      });

      if (intel.region) {
        results.push({
          type: 'geo_estimate',
          value: intel.region + ', ' + cc.country,
          label: '📍 GEO ESTIMATE · ' + intel.region,
          relation: 'geo_estimate',
          status: 'needs_review',
          finding: 'Region inferred from public area/DEF code. Estimate only — not verified presence.',
          sourceUrl: '',
          confidence: 'LOW',
          metadata: {
            kind: 'phone_geolocation_estimate',
            provider: 'numbering-plan',
            country: cc.country,
            region: intel.region,
            city: null,
            accuracy: 'unknown',
            disclaimer: 'Area-code region is a network allocation estimate, not a verified address.'
          }
        });
      }

      results.push({
        type: 'document',
        value: 'type:' + intel.type,
        label: 'Type: ' + intel.type,
        relation: 'number_type',
        status: 'confirmed',
        finding: 'Number type estimate from public numbering ranges: ' + intel.type,
        sourceUrl: '',
        confidence: intel.type === 'unknown' ? 'LOW' : 'MEDIUM'
      });

      if (intel.carrier) {
        results.push({
          type: 'organization',
          value: intel.carrier,
          label: intel.carrier,
          relation: 'carrier_estimate',
          status: 'needs_review',
          finding: 'Operator/carrier estimate from public DEF/prefix tables. May be outdated after number portability (MNP).',
          sourceUrl: '',
          confidence: 'LOW',
          metadata: { kind: 'carrier_estimate', note: 'MNP may change actual operator' }
        });
      }

      // ── Public presence probes (only CONFIRMED pages become graph nodes) ──
      const pages = candidatePages(e164, cc, variants);
      let confirmedMentions = 0;
      for (const url of pages) {
        const probe = await tryFetchPublicPage(url, variants);
        logs.push({ check: 'presence', url: url, status: probe.status, detail: probe.error || probe.detail || '' });
        if (probe.status === 'confirmed' && probe.results) {
          confirmedMentions++;
          probe.results.forEach(r => results.push(r));
        }
        // not_found / unknown / error → log only
      }
      logs.push({ check: 'public_mentions', status: confirmedMentions ? 'ok' : 'none', detail: confirmedMentions + ' confirmed' });
      // Social profiles: discovery + existence verification only
      await discoverAndVerifySocial(variants, results, logs);


      return {
        ok: true,
        meta: {
          e164: e164,
          country: cc.country,
          iso: cc.iso,
          type: intel.type,
          carrier: intel.carrier,
          region: intel.region,
          variants: variants,
          confirmedMentions: confirmedMentions
        },
        results: results,
        logs: logs,
        source: 'phone-intelligence'
      };
    },
    normalizeResult(r) { return r; }
  });
})();
