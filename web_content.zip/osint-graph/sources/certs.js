/**
 * Certificate Transparency — crt.sh (public)
 */
(function () {
  const S = window.NexusSources;
  if (!S) return;

  S.register({
    name: 'ct-certs',
    supportedTypes: ['domain', 'website'],
    requiresApiKey: false,
    sourceUrl: 'https://crt.sh',
    async analyze(value) {
      let domain = (window.NexusDedupe && NexusDedupe.normalizeDomain(value)) || String(value || '');
      try {
        if (/^https?:\/\//i.test(domain)) domain = new URL(domain).hostname;
      } catch (_) {}
      domain = domain.replace(/^\*\./, '').toLowerCase();
      const results = [];
      const logs = [];

      try {
        if (window.NexusRateLimit && !NexusRateLimit.canRequest()) throw new Error('Rate limit');
        if (window.NexusRateLimit) NexusRateLimit.consume();
        const url = 'https://crt.sh/?q=' + encodeURIComponent('%.' + domain) + '&output=json';
        const r = await fetch(url, { signal: AbortSignal.timeout(15000) });
        if (!r.ok) throw new Error('HTTP ' + r.status);
        const data = await r.json();
        if (!Array.isArray(data)) throw new Error('Unexpected CT response');

        const names = new Set();
        const issuers = new Set();
        data.slice(0, 120).forEach(row => {
          if (row.issuer_name) issuers.add(String(row.issuer_name).slice(0, 80));
          const raw = (row.name_value || row.common_name || '').toString();
          raw.split(/\n/).forEach(n => {
            n = n.trim().toLowerCase().replace(/^\*\./, '');
            if (!n || !n.includes('.')) return;
            if (n === domain || n.endsWith('.' + domain)) names.add(n);
          });
        });

        logs.push({ check: 'crt.sh', status: 'ok', detail: data.length + ' rows, ' + names.size + ' hostnames' });

        if (data.length) {
          results.push({
            type: 'certificate',
            value: 'ct:' + domain,
            label: 'CT · ' + domain,
            relation: 'has_certificate',
            status: 'confirmed',
            finding: 'Certificate Transparency: ' + data.length + ' public entries for ' + domain,
            sourceUrl: 'https://crt.sh/?q=' + encodeURIComponent(domain),
            confidence: 'HIGH'
          });
        }

        [...issuers].slice(0, 3).forEach(iss => {
          results.push({
            type: 'organization',
            value: iss,
            label: iss.slice(0, 40),
            relation: 'issued_by',
            status: 'confirmed',
            finding: 'Certificate issuer (CT): ' + iss,
            sourceUrl: 'https://crt.sh/?q=' + encodeURIComponent(domain),
            confidence: 'MEDIUM'
          });
        });

        [...names].slice(0, 35).forEach(name => {
          if (name === domain) return;
          results.push({
            type: 'domain',
            value: name,
            label: name,
            relation: 'subdomain_of',
            status: 'confirmed',
            finding: 'Hostname seen in public certificate for ' + domain,
            sourceUrl: 'https://crt.sh/?q=' + encodeURIComponent(name),
            confidence: 'HIGH'
          });
        });

        return { ok: true, results: results, logs: logs, source: 'ct-certs', meta: { rows: data.length, hosts: names.size } };
      } catch (e) {
        logs.push({ check: 'crt.sh', status: 'error', detail: e.message });
        // CORS/block — not a graph node
        return { ok: false, error: e.message, results: [], logs: logs, source: 'ct-certs' };
      }
    },
    normalizeResult(r) { return r; }
  });
})();
