(function () {
  const S = window.NexusSources;
  if (!S) return;

  const RESOLVERS = [
    'https://cloudflare-dns.com/resolve',
    'https://dns.google/resolve'
  ];

  async function resolve(name, type) {
    let lastErr;
    for (const base of RESOLVERS) {
      try {
        if (window.NexusRateLimit && !NexusRateLimit.canRequest()) throw new Error('Rate limit');
        if (window.NexusRateLimit) NexusRateLimit.consume();
        const r = await fetch(base + '?name=' + encodeURIComponent(name) + '&type=' + type, {
          headers: { Accept: 'application/dns-json' },
          signal: AbortSignal.timeout(8000)
        });
        if (r.status === 429) throw new Error('HTTP 429');
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return await r.json();
      } catch (e) {
        lastErr = e;
      }
    }
    throw lastErr || new Error('DNS failed');
  }

  S.register({
    name: 'dns',
    supportedTypes: ['domain', 'url', 'website', 'mx', 'ns'],
    requiresApiKey: false,
    sourceUrl: 'Cloudflare / Google DoH',
    async analyze(value) {
      let host = (window.NexusDedupe && NexusDedupe.normalizeDomain(value)) || String(value || '');
      try {
        if (/^https?:\/\//i.test(host)) host = new URL(host).hostname;
      } catch (_) {}
      host = host.replace(/\.$/, '').toLowerCase();
      const results = [];
      const logs = [];
      const seen = new Set();

      const push = (item) => {
        const k = item.type + '::' + String(item.value).toLowerCase();
        if (seen.has(k)) return;
        seen.add(k);
        results.push(item);
      };

      for (const t of ['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME', 'SOA']) {
        try {
          const data = await resolve(host, t);
          const answers = data.Answer || [];
          logs.push({ check: 'DNS ' + t, status: answers.length ? 'ok' : 'empty', detail: answers.length + ' records' });
          answers.forEach(a => {
            let v = String(a.data || '').replace(/\.$/, '');
            if (t === 'MX') v = v.split(/\s+/).pop();
            if (t === 'SOA') {
              const parts = v.split(/\s+/);
              if (parts[0]) {
                push({
                  type: 'ns', value: parts[0].replace(/\.$/, ''), label: parts[0].replace(/\.$/, ''),
                  relation: 'soa_mname', status: 'confirmed',
                  finding: 'SOA primary NS: ' + parts[0], sourceUrl: 'https://cloudflare-dns.com', confidence: 'HIGH'
                });
              }
              return;
            }
            if (t === 'A' || t === 'AAAA') {
              push({
                type: 'ip', value: v, label: v, relation: 'resolves_to', status: 'confirmed',
                finding: t + ' record → ' + v, sourceUrl: 'https://cloudflare-dns.com', confidence: 'HIGH'
              });
            } else if (t === 'MX') {
              push({
                type: 'mx', value: v, label: v, relation: 'mail_to', status: 'confirmed',
                finding: 'MX ' + v, sourceUrl: 'https://cloudflare-dns.com', confidence: 'HIGH'
              });
              // MX host often resolves further — mark as domain too for expand
              push({
                type: 'domain', value: v, label: v, relation: 'mail_host', status: 'confirmed',
                finding: 'Mail host domain from MX', sourceUrl: 'https://cloudflare-dns.com', confidence: 'HIGH'
              });
            } else if (t === 'NS') {
              push({
                type: 'ns', value: v, label: v, relation: 'nameserver', status: 'confirmed',
                finding: 'NS ' + v, sourceUrl: 'https://cloudflare-dns.com', confidence: 'HIGH'
              });
              push({
                type: 'domain', value: v, label: v, relation: 'nameserver_host', status: 'confirmed',
                finding: 'Nameserver hostname', sourceUrl: 'https://cloudflare-dns.com', confidence: 'MEDIUM'
              });
            } else if (t === 'CNAME') {
              push({
                type: 'domain', value: v, label: v, relation: 'cname', status: 'confirmed',
                finding: 'CNAME → ' + v, sourceUrl: 'https://cloudflare-dns.com', confidence: 'HIGH'
              });
            } else if (t === 'TXT') {
              const low = v.toLowerCase();
              if (low.includes('v=spf1')) {
                push({
                  type: 'document', value: 'spf:' + host, label: 'SPF',
                  relation: 'has_spf', status: 'confirmed',
                  finding: 'SPF: ' + v.slice(0, 120), sourceUrl: 'https://cloudflare-dns.com', confidence: 'HIGH'
                });
                // extract include: domains from SPF
                const includes = v.match(/include:([a-z0-9._-]+)/gi) || [];
                includes.slice(0, 6).forEach(inc => {
                  const d = inc.split(':')[1];
                  if (d) push({
                    type: 'domain', value: d, label: d, relation: 'spf_include', status: 'confirmed',
                    finding: 'SPF include:' + d, sourceUrl: 'https://cloudflare-dns.com', confidence: 'MEDIUM'
                  });
                });
              } else if (low.includes('v=dmarc1') || low.includes('dmarc')) {
                push({
                  type: 'document', value: 'dmarc:' + host, label: 'DMARC',
                  relation: 'has_dmarc', status: 'confirmed',
                  finding: 'DMARC-related TXT: ' + v.slice(0, 100), sourceUrl: 'https://cloudflare-dns.com', confidence: 'HIGH'
                });
              } else if (low.includes('verification') || low.includes('google-site') || low.includes('ms=') || low.includes('apple-domain')) {
                push({
                  type: 'document', value: 'txt-verify:' + v.slice(0, 40), label: 'Domain verification TXT',
                  relation: 'related_to', status: 'confirmed',
                  finding: 'Verification TXT (provider ownership signal): ' + v.slice(0, 80),
                  sourceUrl: 'https://cloudflare-dns.com', confidence: 'MEDIUM'
                });
              }
            }
          });
        } catch (e) {
          logs.push({ check: 'DNS ' + t, status: 'error', detail: e.message });
        }
      }

      // DMARC explicit query
      try {
        const data = await resolve('_dmarc.' + host, 'TXT');
        (data.Answer || []).forEach(a => {
          const v = String(a.data || '');
          if (/v=dmarc1/i.test(v)) {
            push({
              type: 'document', value: 'dmarc-record:' + host, label: 'DMARC policy',
              relation: 'has_dmarc', status: 'confirmed',
              finding: 'DMARC: ' + v.slice(0, 120), sourceUrl: 'https://cloudflare-dns.com', confidence: 'HIGH'
            });
          }
        });
      } catch (_) {}

      return {
        ok: results.length > 0,
        results: results,
        logs: logs,
        source: 'dns',
        meta: { host: host, count: results.length }
      };
    },
    normalizeResult(r) { return r; }
  });
})();
