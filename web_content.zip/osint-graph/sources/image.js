(function () {
  const S = window.NexusSources;
  if (!S) return;

  S.register({
    name: 'image-local',
    supportedTypes: ['photo', 'image'],
    requiresApiKey: false,
    sourceUrl: 'local browser analysis',
    async analyze(value, ctx) {
      // value may be ignored; ctx.photoData or ctx.dataUrl required
      const dataUrl = (ctx && (ctx.photoData || ctx.dataUrl)) || null;
      if (!dataUrl || !window.NexusMediaIntel) {
        return {
          ok: false,
          error: 'No image data on node — add photo first, then Expand',
          results: [],
          source: 'image-local'
        };
      }
      try {
        const res = await NexusMediaIntel.analyzeImageDataUrl(dataUrl);
        return res;
      } catch (e) {
        return { ok: false, error: e.message, results: [], source: 'image-local' };
      }
    },
    normalizeResult(r) { return r; }
  });

  S.register({
    name: 'file-local',
    supportedTypes: ['document', 'file'],
    requiresApiKey: false,
    sourceUrl: 'local browser analysis',
    async analyze(value, ctx) {
      if (ctx && ctx.fileBytes && window.NexusMediaIntel) {
        try {
          return await NexusMediaIntel.analyzeFileBytes(ctx.fileBytes, ctx.mime, ctx.fileName);
        } catch (e) {
          return { ok: false, error: e.message, results: [], source: 'file-local' };
        }
      }
      // if value looks like a hash — only link to VT
      const v = String(value || '').trim();
      if (/^[0-9a-f]{32}$/i.test(v) || /^[0-9a-f]{64}$/i.test(v)) {
        return {
          ok: true,
          results: [{
            type: 'url',
            value: 'https://www.virustotal.com/gui/search/' + v.toLowerCase(),
            label: 'VirusTotal',
            relation: 'related_to',
            status: 'unknown',
            finding: 'Hash search only (no file content)',
            sourceUrl: 'https://www.virustotal.com/gui/search/' + v.toLowerCase()
          }],
          source: 'file-local'
        };
      }
      return {
        ok: false,
        error: 'Attach file or provide hash',
        results: [],
        source: 'file-local'
      };
    },
    normalizeResult(r) { return r; }
  });
})();
