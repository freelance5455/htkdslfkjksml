/** Source connector registry — window.NexusSources */
(function (global) {
  const connectors = [];
  const NexusSources = {
    register(connector) {
      if (!connector || !connector.name || typeof connector.analyze !== 'function') {
        console.warn('Invalid connector', connector);
        return;
      }
      const i = connectors.findIndex(c => c.name === connector.name);
      if (i >= 0) connectors[i] = connector;
      else connectors.push(connector);
    },
    list() { return connectors.slice(); },
    forType(type) {
      return connectors.filter(c => {
        if (c.enabled === false) return false;
        const types = c.supportedTypes || [];
        return types.includes(type) || types.includes('*');
      });
    },
    get(name) { return connectors.find(c => c.name === name); }
  };
  global.NexusSources = NexusSources;
})(typeof window !== 'undefined' ? window : globalThis);
