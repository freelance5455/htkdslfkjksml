(function () {
  const S = window.NexusSources;
  if (!S) return;

  async function dns(name, type) {
    if (window.NexusRateLimit && !NexusRateLimit.canRequest()) throw new Error('Rate limit');
    if (window.NexusRateLimit) NexusRateLimit.consume();
    const r = await fetch('https://cloudflare-dns.com/resolve?name=' + encodeURIComponent(name) + '&type=' + type, {
      headers: { Accept: 'application/dns-json' },
      signal: AbortSignal.timeout(8000)
    });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  }

  function parseSpf(txt) {
    if (!/^v=spf1/i.test(txt)) return null;
    return txt;
  }
  function parseDmarc(txt) {
    if (!/^v=DMARC1/i.test(txt)) return null;
    return txt;
  }

  S.register({
    name: 'email-intelligence',
    supportedTypes: ['email'],
    requiresApiKey: false,
    sourceUrl: 'local normalize + Cloudflare DNS',
    async analyze(value) {
      const results = [];
      const logs = [];
      const email = (window.NexusDedupe && NexusDedupe.normalizeEmail(value)) || String(value).trim().toLowerCase();
      if (!email.includes('@')) {
        return { ok: false, error: 'Invalid email', results: [], logs: [{ status: 'error', detail: 'invalid' }] };
      }
      const [local, domain] = email.split('@');
      if (!domain || !local) {
        return { ok: false, error: 'Invalid email', results: [], logs: [{ status: 'error', detail: 'invalid' }] };
      }

      results.push({
        type: 'domain', value: domain, label: domain,
        relation: 'email_domain', status: 'confirmed',
        finding: 'Domain extracted from email local@domain', sourceUrl: '',
        confidence: 'HIGH'
      });

      // Local-part as username candidate only when meaningful
      if (local.length >= 3 && !/^(info|admin|support|noreply|no-reply|mail|contact|hello|office|sales)$/i.test(local)) {
        results.push({
          type: 'username', value: local, label: local,
          relation: 'local_part', status: 'possible',
          finding: 'Local-part as username candidate — not identity proof', sourceUrl: '',
          confidence: 'LOW'
        });
      }

      // MX
      try {
        const mx = await dns(domain, 'MX');
        const mxs = (mx.Answer || []).map(a => {
          const parts = String(a.data || '').split(' ');
          return { pref: parts[0], host: (parts[1] || parts[0] || '').replace(/\.$/, '') };
        }).filter(x => x.host);
        if (!mxs.length) logs.push({ check: 'MX', status: 'not_found', detail: 'No MX' });
        else {
          mxs.forEach(m => {
            results.push({
              type: 'mx', value: m.host, label: m.host + (m.pref ? ' (pref ' + m.pref + ')' : ''),
              relation: 'mail_to', status: 'confirmed',
              finding: 'MX ' + m.host, sourceUrl: 'https://cloudflare-dns.com',
              confidence: 'HIGH'
            });
          });
          logs.push({ check: 'MX', status: 'ok', detail: mxs.length + ' hosts' });
        }
      } catch (e) {
        logs.push({ check: 'MX', status: 'error', detail: e.message });
      }

      // A / AAAA on domain
      for (const t of ['A', 'AAAA']) {
        try {
          const ans = await dns(domain, t);
          (ans.Answer || []).forEach(a => {
            const ip = a.data;
            if (!ip) return;
            results.push({
              type: 'ip', value: ip, label: ip,
              relation: 'resolves_to', status: 'confirmed',
              finding: domain + ' ' + t + ' → ' + ip, sourceUrl: 'https://cloudflare-dns.com',
              confidence: 'HIGH'
            });
          });
        } catch (e) {
          logs.push({ check: t, status: 'error', detail: e.message });
        }
      }

      // TXT → SPF
      try {
        const txt = await dns(domain, 'TXT');
        (txt.Answer || []).forEach(a => {
          const raw = String(a.data || '').replace(/^"|"$/g, '').replace(/" "/g, '');
          const spf = parseSpf(raw);
          if (spf) {
            results.push({
              type: 'document', value: 'SPF:' + domain, label: 'SPF ' + domain,
              relation: 'has_record', status: 'confirmed',
              finding: spf.slice(0, 200), sourceUrl: 'https://cloudflare-dns.com',
              confidence: 'HIGH'
            });
          }
        });
      } catch (e) {
        logs.push({ check: 'TXT/SPF', status: 'error', detail: e.message });
      }

      // DMARC
      try {
        const dmarc = await dns('_dmarc.' + domain, 'TXT');
        (dmarc.Answer || []).forEach(a => {
          const raw = String(a.data || '').replace(/^"|"$/g, '').replace(/" "/g, '');
          const dm = parseDmarc(raw);
          if (dm) {
            results.push({
              type: 'document', value: 'DMARC:' + domain, label: 'DMARC ' + domain,
              relation: 'has_record', status: 'confirmed',
              finding: dm.slice(0, 200), sourceUrl: 'https://cloudflare-dns.com',
              confidence: 'HIGH'
            });
          }
        });
      } catch (e) {
        logs.push({ check: 'DMARC', status: 'error', detail: e.message });
      }

      // NS
      try {
        const ns = await dns(domain, 'NS');
        (ns.Answer || []).forEach(a => {
          const host = String(a.data || '').replace(/\.$/, '');
          if (host) results.push({
            type: 'ns', value: host, label: host,
            relation: 'nameserver', status: 'confirmed',
            finding: 'NS ' + host, sourceUrl: 'https://cloudflare-dns.com',
            confidence: 'HIGH'
          });
        });
      } catch (e) {
        logs.push({ check: 'NS', status: 'error', detail: e.message });
      }

      // Gravatar public profile (MD5 of lowercased email) — only if profile JSON exists
      try {
        function md5(str) {
          function cmn(q, a, b, x, s, t) {
            a = (a + q + x + t) | 0; return (((a << s) | (a >>> (32 - s))) + b) | 0;
          }
          function ff(a, b, c, d, x, s, t) { return cmn((b & c) | (~b & d), a, b, x, s, t); }
          function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & ~d), a, b, x, s, t); }
          function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
          function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | ~d), a, b, x, s, t); }
          function md5blk(s) {
            var blks = [], i; for (i = 0; i < 64; i += 4)
              blks[i >> 2] = s.charCodeAt(i) + (s.charCodeAt(i+1)<<8) + (s.charCodeAt(i+2)<<16) + (s.charCodeAt(i+3)<<24);
            return blks;
          }
          function rhex(n) {
            var j, s = ''; for (j = 0; j < 4; j++) s += ('0' + ((n >> (j*8)) & 255).toString(16)).slice(-2);
            return s;
          }
          var x = [1732584193, -271733879, -1732584194, 271733878];
          var i, n = str.length;
          for (i = 64; i <= str.length; i += 64) {
            (function(k) {
              var a = x[0], b = x[1], c = x[2], d = x[3];
              a = ff(a,b,c,d,k[0],7,-680876936); d = ff(d,a,b,c,k[1],12,-389564586);
              c = ff(c,d,a,b,k[2],17,606105819); b = ff(b,c,d,a,k[3],22,-1044525330);
              a = ff(a,b,c,d,k[4],7,-176418897); d = ff(d,a,b,c,k[5],12,1200080426);
              c = ff(c,d,a,b,k[6],17,-1473231341); b = ff(b,c,d,a,k[7],22,-45705983);
              a = ff(a,b,c,d,k[8],7,1770035416); d = ff(d,a,b,c,k[9],12,-1958414417);
              c = ff(c,d,a,b,k[10],17,-42063); b = ff(b,c,d,a,k[11],22,-1990404162);
              a = ff(a,b,c,d,k[12],7,1804603682); d = ff(d,a,b,c,k[13],12,-40341101);
              c = ff(c,d,a,b,k[14],17,-1502002290); b = ff(b,c,d,a,k[15],22,1236535329);
              a = gg(a,b,c,d,k[1],5,-165796510); d = gg(d,a,b,c,k[6],9,-1069501632);
              c = gg(c,d,a,b,k[11],14,643717713); b = gg(b,c,d,a,k[0],20,-373897302);
              a = gg(a,b,c,d,k[5],5,-701558691); d = gg(d,a,b,c,k[10],9,38016083);
              c = gg(c,d,a,b,k[15],14,-660478335); b = gg(b,c,d,a,k[4],20,-405537848);
              a = gg(a,b,c,d,k[9],5,568446438); d = gg(d,a,b,c,k[14],9,-1019803690);
              c = gg(c,d,a,b,k[3],14,-187363961); b = gg(b,c,d,a,k[8],20,1163531501);
              a = gg(a,b,c,d,k[13],5,-1444681467); d = gg(d,a,b,c,k[2],9,-51403784);
              c = gg(c,d,a,b,k[7],14,1735328473); b = gg(b,c,d,a,k[12],20,-1926607734);
              a = hh(a,b,c,d,k[5],4,-378558); d = hh(d,a,b,c,k[8],11,-2022574463);
              c = hh(c,d,a,b,k[11],16,1839030562); b = hh(b,c,d,a,k[14],23,-35309556);
              a = hh(a,b,c,d,k[1],4,-1530992060); d = hh(d,a,b,c,k[4],11,1272893353);
              c = hh(c,d,a,b,k[7],16,-155497632); b = hh(b,c,d,a,k[10],23,-1094730640);
              a = hh(a,b,c,d,k[13],4,681279174); d = hh(d,a,b,c,k[0],11,-358537222);
              c = hh(c,d,a,b,k[3],16,-722521979); b = hh(b,c,d,a,k[6],23,76029189);
              a = hh(a,b,c,d,k[9],4,-640364487); d = hh(d,a,b,c,k[12],11,-421815835);
              c = hh(c,d,a,b,k[15],16,530742520); b = hh(b,c,d,a,k[2],23,-995338651);
              a = ii(a,b,c,d,k[0],6,-198630844); d = ii(d,a,b,c,k[7],10,1126891415);
              c = ii(c,d,a,b,k[14],15,-1416354905); b = ii(b,c,d,a,k[5],21,-57434055);
              a = ii(a,b,c,d,k[12],6,1700485571); d = ii(d,a,b,c,k[3],10,-1894986606);
              c = ii(c,d,a,b,k[10],15,-1051523); b = ii(b,c,d,a,k[1],21,-2054922799);
              a = ii(a,b,c,d,k[8],6,1873313359); d = ii(d,a,b,c,k[15],10,-30611744);
              c = ii(c,d,a,b,k[6],15,-1560198380); b = ii(b,c,d,a,k[13],21,1309151649);
              a = ii(a,b,c,d,k[4],6,-145523070); d = ii(d,a,b,c,k[11],10,-1120210379);
              c = ii(c,d,a,b,k[2],15,718787259); b = ii(b,c,d,a,k[9],21,-343485551);
              x[0] = (x[0] + a) | 0; x[1] = (x[1] + b) | 0; x[2] = (x[2] + c) | 0; x[3] = (x[3] + d) | 0;
            })(md5blk(str.substring(i - 64, i)));
          }
          str = str.substring(i - 64);
          var tail = new Array(16).fill(0);
          for (i = 0; i < str.length; i++) tail[i >> 2] |= str.charCodeAt(i) << ((i % 4) << 3);
          tail[i >> 2] |= 0x80 << ((i % 4) << 3);
          if (i > 55) {
            (function(k) {
              var a = x[0], b = x[1], c = x[2], d = x[3];
              a = ff(a,b,c,d,k[0],7,-680876936); d = ff(d,a,b,c,k[1],12,-389564586);
              c = ff(c,d,a,b,k[2],17,606105819); b = ff(b,c,d,a,k[3],22,-1044525330);
              a = ff(a,b,c,d,k[4],7,-176418897); d = ff(d,a,b,c,k[5],12,1200080426);
              c = ff(c,d,a,b,k[6],17,-1473231341); b = ff(b,c,d,a,k[7],22,-45705983);
              a = ff(a,b,c,d,k[8],7,1770035416); d = ff(d,a,b,c,k[9],12,-1958414417);
              c = ff(c,d,a,b,k[10],17,-42063); b = ff(b,c,d,a,k[11],22,-1990404162);
              a = ff(a,b,c,d,k[12],7,1804603682); d = ff(d,a,b,c,k[13],12,-40341101);
              c = ff(c,d,a,b,k[14],17,-1502002290); b = ff(b,c,d,a,k[15],22,1236535329);
              a = gg(a,b,c,d,k[1],5,-165796510); d = gg(d,a,b,c,k[6],9,-1069501632);
              c = gg(c,d,a,b,k[11],14,643717713); b = gg(b,c,d,a,k[0],20,-373897302);
              a = gg(a,b,c,d,k[5],5,-701558691); d = gg(d,a,b,c,k[10],9,38016083);
              c = gg(c,d,a,b,k[15],14,-660478335); b = gg(b,c,d,a,k[4],20,-405537848);
              a = gg(a,b,c,d,k[9],5,568446438); d = gg(d,a,b,c,k[14],9,-1019803690);
              c = gg(c,d,a,b,k[3],14,-187363961); b = gg(b,c,d,a,k[8],20,1163531501);
              a = gg(a,b,c,d,k[13],5,-1444681467); d = gg(d,a,b,c,k[2],9,-51403784);
              c = gg(c,d,a,b,k[7],14,1735328473); b = gg(b,c,d,a,k[12],20,-1926607734);
              a = hh(a,b,c,d,k[5],4,-378558); d = hh(d,a,b,c,k[8],11,-2022574463);
              c = hh(c,d,a,b,k[11],16,1839030562); b = hh(b,c,d,a,k[14],23,-35309556);
              a = hh(a,b,c,d,k[1],4,-1530992060); d = hh(d,a,b,c,k[4],11,1272893353);
              c = hh(c,d,a,b,k[7],16,-155497632); b = hh(b,c,d,a,k[10],23,-1094730640);
              a = hh(a,b,c,d,k[13],4,681279174); d = hh(d,a,b,c,k[0],11,-358537222);
              c = hh(c,d,a,b,k[3],16,-722521979); b = hh(b,c,d,a,k[6],23,76029189);
              a = hh(a,b,c,d,k[9],4,-640364487); d = hh(d,a,b,c,k[12],11,-421815835);
              c = hh(c,d,a,b,k[15],16,530742520); b = hh(b,c,d,a,k[2],23,-995338651);
              a = ii(a,b,c,d,k[0],6,-198630844); d = ii(d,a,b,c,k[7],10,1126891415);
              c = ii(c,d,a,b,k[14],15,-1416354905); b = ii(b,c,d,a,k[5],21,-57434055);
              a = ii(a,b,c,d,k[12],6,1700485571); d = ii(d,a,b,c,k[3],10,-1894986606);
              c = ii(c,d,a,b,k[10],15,-1051523); b = ii(b,c,d,a,k[1],21,-2054922799);
              a = ii(a,b,c,d,k[8],6,1873313359); d = ii(d,a,b,c,k[15],10,-30611744);
              c = ii(c,d,a,b,k[6],15,-1560198380); b = ii(b,c,d,a,k[13],21,1309151649);
              a = ii(a,b,c,d,k[4],6,-145523070); d = ii(d,a,b,c,k[11],10,-1120210379);
              c = ii(c,d,a,b,k[2],15,718787259); b = ii(b,c,d,a,k[9],21,-343485551);
              x[0] = (x[0] + a) | 0; x[1] = (x[1] + b) | 0; x[2] = (x[2] + c) | 0; x[3] = (x[3] + d) | 0;
            })(tail);
            tail = new Array(16).fill(0);
          }
          tail[14] = n * 8;
          (function(k) {
            var a = x[0], b = x[1], c = x[2], d = x[3];
            a = ff(a,b,c,d,k[0],7,-680876936); d = ff(d,a,b,c,k[1],12,-389564586);
            c = ff(c,d,a,b,k[2],17,606105819); b = ff(b,c,d,a,k[3],22,-1044525330);
            a = ff(a,b,c,d,k[4],7,-176418897); d = ff(d,a,b,c,k[5],12,1200080426);
            c = ff(c,d,a,b,k[6],17,-1473231341); b = ff(b,c,d,a,k[7],22,-45705983);
            a = ff(a,b,c,d,k[8],7,1770035416); d = ff(d,a,b,c,k[9],12,-1958414417);
            c = ff(c,d,a,b,k[10],17,-42063); b = ff(b,c,d,a,k[11],22,-1990404162);
            a = ff(a,b,c,d,k[12],7,1804603682); d = ff(d,a,b,c,k[13],12,-40341101);
            c = ff(c,d,a,b,k[14],17,-1502002290); b = ff(b,c,d,a,k[15],22,1236535329);
            a = gg(a,b,c,d,k[1],5,-165796510); d = gg(d,a,b,c,k[6],9,-1069501632);
            c = gg(c,d,a,b,k[11],14,643717713); b = gg(b,c,d,a,k[0],20,-373897302);
            a = gg(a,b,c,d,k[5],5,-701558691); d = gg(d,a,b,c,k[10],9,38016083);
            c = gg(c,d,a,b,k[15],14,-660478335); b = gg(b,c,d,a,k[4],20,-405537848);
            a = gg(a,b,c,d,k[9],5,568446438); d = gg(d,a,b,c,k[14],9,-1019803690);
            c = gg(c,d,a,b,k[3],14,-187363961); b = gg(b,c,d,a,k[8],20,1163531501);
            a = gg(a,b,c,d,k[13],5,-1444681467); d = gg(d,a,b,c,k[2],9,-51403784);
            c = gg(c,d,a,b,k[7],14,1735328473); b = gg(b,c,d,a,k[12],20,-1926607734);
            a = hh(a,b,c,d,k[5],4,-378558); d = hh(d,a,b,c,k[8],11,-2022574463);
            c = hh(c,d,a,b,k[11],16,1839030562); b = hh(b,c,d,a,k[14],23,-35309556);
            a = hh(a,b,c,d,k[1],4,-1530992060); d = hh(d,a,b,c,k[4],11,1272893353);
            c = hh(c,d,a,b,k[7],16,-155497632); b = hh(b,c,d,a,k[10],23,-1094730640);
            a = hh(a,b,c,d,k[13],4,681279174); d = hh(d,a,b,c,k[0],11,-358537222);
            c = hh(c,d,a,b,k[3],16,-722521979); b = hh(b,c,d,a,k[6],23,76029189);
            a = hh(a,b,c,d,k[9],4,-640364487); d = hh(d,a,b,c,k[12],11,-421815835);
            c = hh(c,d,a,b,k[15],16,530742520); b = hh(b,c,d,a,k[2],23,-995338651);
            a = ii(a,b,c,d,k[0],6,-198630844); d = ii(d,a,b,c,k[7],10,1126891415);
            c = ii(c,d,a,b,k[14],15,-1416354905); b = ii(b,c,d,a,k[5],21,-57434055);
            a = ii(a,b,c,d,k[12],6,1700485571); d = ii(d,a,b,c,k[3],10,-1894986606);
            c = ii(c,d,a,b,k[10],15,-1051523); b = ii(b,c,d,a,k[1],21,-2054922799);
            a = ii(a,b,c,d,k[8],6,1873313359); d = ii(d,a,b,c,k[15],10,-30611744);
            c = ii(c,d,a,b,k[6],15,-1560198380); b = ii(b,c,d,a,k[13],21,1309151649);
            a = ii(a,b,c,d,k[4],6,-145523070); d = ii(d,a,b,c,k[11],10,-1120210379);
            c = ii(c,d,a,b,k[2],15,718787259); b = ii(b,c,d,a,k[9],21,-343485551);
            x[0] = (x[0] + a) | 0; x[1] = (x[1] + b) | 0; x[2] = (x[2] + c) | 0; x[3] = (x[3] + d) | 0;
          })(tail);
          return rhex(x[0]) + rhex(x[1]) + rhex(x[2]) + rhex(x[3]);
        }

        const hash = md5(email.trim().toLowerCase());
        if (window.NexusRateLimit && NexusRateLimit.canRequest()) {
          NexusRateLimit.consume();
          const gUrl = 'https://en.gravatar.com/' + hash + '.json';
          const gr = await fetch(gUrl, { signal: AbortSignal.timeout(8000) });
          if (gr.status === 404) {
            logs.push({ check: 'gravatar', status: 'not_found' });
          } else if (gr.ok) {
            const gj = await gr.json();
            const entry = (gj.entry && gj.entry[0]) || null;
            if (entry) {
              const profileUrl = entry.profileUrl || ('https://gravatar.com/' + (entry.preferredUsername || hash));
              results.push({
                type: 'url', value: profileUrl, label: 'Gravatar',
                relation: 'has_account', status: 'confirmed',
                finding: 'Public Gravatar profile exists for this email', sourceUrl: profileUrl, confidence: 'HIGH'
              });
              if (entry.preferredUsername) {
                results.push({
                  type: 'username', value: entry.preferredUsername, label: entry.preferredUsername,
                  relation: 'has_account', status: 'confirmed',
                  finding: 'Gravatar preferredUsername', sourceUrl: profileUrl, confidence: 'MEDIUM'
                });
              }
              if (entry.displayName) {
                results.push({
                  type: 'person', value: entry.displayName, label: entry.displayName,
                  relation: 'possible_name', status: 'possible',
                  finding: 'Gravatar displayName — not sole identity proof', sourceUrl: profileUrl, confidence: 'LOW'
                });
              }
              logs.push({ check: 'gravatar', status: 'ok' });
            } else {
              logs.push({ check: 'gravatar', status: 'not_found' });
            }
          } else {
            logs.push({ check: 'gravatar', status: 'error', detail: 'HTTP ' + gr.status });
          }
        }
      } catch (e) {
        logs.push({ check: 'gravatar', status: 'error', detail: e.message || 'failed' });
      }

      return {
        ok: true,
        meta: { email: email, domain: domain, local: local },
        results: results,
        logs: logs,
        source: 'email-intelligence'
      };
    },
    normalizeResult(r) { return r; }
  });
})();
