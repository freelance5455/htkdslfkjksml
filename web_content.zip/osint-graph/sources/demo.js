(function () {
  /* Demo connector disabled — never injects synthetic OSINT data */
  const S = window.NexusSources;
  if (!S) return;
  S.register({
    name: 'demo',
    supportedTypes: [],
    requiresApiKey: false,
    sourceUrl: '',
    enabled: false,
    async analyze() {
      return { ok: true, results: [], source: 'demo', skipped: true };
    },
    normalizeResult(r) { return r; }
  });
})();
