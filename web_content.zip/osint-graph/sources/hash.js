(function () {
  const S = window.NexusSources;
  if (!S) return;

  function detectHashType(h) {
    const s = String(h || '').replace(/\s/g, '').toLowerCase();
    if (/^[0-9a-f]{32}$/.test(s)) return 'MD5';
    if (/^[0-9a-f]{40}$/.test(s)) return 'SHA-1';
    if (/^[0-9a-f]{64}$/.test(s)) return 'SHA-256';
    if (/^[0-9a-f]{128}$/.test(s)) return 'SHA-512';
    return null;
  }

  S.register({
    name: 'hash-intelligence',
    supportedTypes: ['hash'],
    requiresApiKey: false,
    sourceUrl: 'local format detection (no private intel DBs)',
    async analyze(value) {
      const results = [];
      const logs = [];
      const raw = String(value || '').trim();
      const norm = (window.NexusDedupe && NexusDedupe.normalizeHash(raw)) || raw.toLowerCase().replace(/\s/g, '');
      const kind = detectHashType(norm);
      if (!kind) {
        return { ok: false, error: 'Unrecognized hash format', results: [], logs: [{ status: 'error', detail: 'invalid hash' }] };
      }
      results.push({
        type: 'document',
        value: 'hash-type:' + kind,
        label: 'Hash type: ' + kind,
        relation: 'normalized_as',
        status: 'confirmed',
        finding: 'Detected ' + kind + ' (' + norm.length + ' hex chars). No public reputation API configured without key.',
        sourceUrl: '',
        confidence: 'HIGH'
      });
      logs.push({ check: 'format', status: 'ok', detail: kind });
      // Without API key we do NOT invent VirusTotal / malware hits
      logs.push({ check: 'reputation', status: 'skipped', detail: 'API KEY REQUIRED for external reputation sources' });
      return { ok: true, meta: { hash: norm, type: kind }, results: results, logs: logs, source: 'hash-intelligence' };
    },
    normalizeResult(r) { return r; }
  });
})();
