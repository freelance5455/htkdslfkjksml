(function () {
  const S = window.NexusSources;
  if (!S) return;

  async function fetchRdap(url) {
    if (window.NexusRateLimit && !NexusRateLimit.canRequest()) throw new Error('Rate limit');
    if (window.NexusRateLimit) NexusRateLimit.consume();
    const r = await fetch(url, {
      signal: AbortSignal.timeout(12000),
      headers: { Accept: 'application/rdap+json, application/json' }
    });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  }

  function extractEntities(data, src, results) {
    (data.entities || []).forEach(ent => {
      let fn = '', org = '', email = '';
      const vcard = ent.vcardArray && ent.vcardArray[1];
      if (Array.isArray(vcard)) {
        vcard.forEach(row => {
          if (!Array.isArray(row)) return;
          if (row[0] === 'fn') fn = row[3];
          if (row[0] === 'org') org = row[3];
          if (row[0] === 'email') email = row[3];
        });
      }
      const roles = (ent.roles || []).join(',');
      if (org) {
        results.push({
          type: 'organization', value: org, label: org,
          relation: roles.includes('registrar') ? 'registrar' : 'registered_to',
          status: 'confirmed', finding: 'RDAP org (' + (roles || 'entity') + '): ' + org,
          sourceUrl: src, confidence: 'HIGH'
        });
      }
      if (fn && fn !== org) {
        results.push({
          type: 'organization', value: fn, label: fn,
          relation: 'registered_to', status: 'confirmed',
          finding: 'RDAP entity: ' + fn + (roles ? ' [' + roles + ']' : ''),
          sourceUrl: src, confidence: 'MEDIUM'
        });
      }
      if (email) {
        results.push({
          type: 'email', value: email, label: email,
          relation: 'related_to', status: 'confirmed',
          finding: 'RDAP public contact email', sourceUrl: src, confidence: 'HIGH'
        });
      }
    });
    (data.nameservers || []).forEach(ns => {
      const name = (ns.ldhName || ns.unicodeName || '').replace(/\.$/, '').toLowerCase();
      if (name) {
        results.push({
          type: 'ns', value: name, label: name, relation: 'nameserver', status: 'confirmed',
          finding: 'RDAP nameserver: ' + name, sourceUrl: src, confidence: 'HIGH'
        });
        results.push({
          type: 'domain', value: name, label: name, relation: 'nameserver_host', status: 'confirmed',
          finding: 'NS host from RDAP', sourceUrl: src, confidence: 'MEDIUM'
        });
      }
    });
    if (data.events) {
      data.events.forEach(ev => {
        if (ev.eventAction && ev.eventDate) {
          results.push({
            type: 'document',
            value: 'rdap-' + ev.eventAction + ':' + String(ev.eventDate).slice(0, 10),
            label: ev.eventAction + ' ' + String(ev.eventDate).slice(0, 10),
            relation: 'related_to', status: 'confirmed',
            finding: 'RDAP event: ' + ev.eventAction + ' @ ' + ev.eventDate,
            sourceUrl: src, confidence: 'HIGH'
          });
        }
      });
    }
  }

  S.register({
    name: 'rdap-domain',
    supportedTypes: ['domain', 'website'],
    requiresApiKey: false,
    sourceUrl: 'https://rdap.org',
    async analyze(value) {
      let domain = (window.NexusDedupe && NexusDedupe.normalizeDomain(value)) || String(value || '');
      try {
        if (/^https?:\/\//i.test(domain)) domain = new URL(domain).hostname;
      } catch (_) {}
      domain = domain.toLowerCase().replace(/\.$/, '');
      const results = [];
      const logs = [];
      const endpoints = [
        'https://rdap.org/domain/' + encodeURIComponent(domain),
        'https://rdap.verisign.com/com/v1/domain/' + encodeURIComponent(domain),
        'https://rdap.verisign.com/net/v1/domain/' + encodeURIComponent(domain)
      ];
      let data = null, src = '';
      for (const url of endpoints) {
        try {
          data = await fetchRdap(url);
          src = url;
          logs.push({ check: url, status: 'ok' });
          break;
        } catch (e) {
          logs.push({ check: url, status: 'error', detail: e.message });
        }
      }
      if (!data) {
        return { ok: false, error: 'RDAP unavailable', results: [], logs: logs, source: 'rdap-domain' };
      }
      if (data.ldhName || data.unicodeName) {
        results.push({
          type: 'document',
          value: 'rdap-domain:' + (data.ldhName || domain),
          label: 'RDAP: ' + (data.ldhName || domain),
          relation: 'registered_as', status: 'confirmed',
          finding: 'Domain present in RDAP registry', sourceUrl: src, confidence: 'HIGH'
        });
      }
      extractEntities(data, src, results);
      return { ok: results.length > 0, results: results, logs: logs, source: 'rdap-domain' };
    },
    normalizeResult(r) { return r; }
  });
})();
