(function () {
  const S = window.NexusSources;
  if (!S) return;

  async function fetchJSON(url, timeout) {
    if (window.NexusRateLimit && !NexusRateLimit.canRequest()) throw new Error('Rate limit');
    if (window.NexusRateLimit) NexusRateLimit.consume();
    const r = await fetch(url, {
      signal: AbortSignal.timeout(timeout || 12000),
      headers: { Accept: 'application/json' }
    });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  }

  function pushUnique(results, item) {
    if (!item || !item.value) return;
    const key = (item.type + '::' + String(item.value).toLowerCase());
    if (results._keys.has(key)) return;
    results._keys.add(key);
    results.push(item);
  }

  // Wikidata search + entity claims (public figures / open data only)
  async function searchWikidata(name, results, logs) {
    try {
      const searchUrl = 'https://www.wikidata.org/w/api.php?action=wbsearchentities&search=' +
        encodeURIComponent(name) + '&language=en&uselang=en&limit=8&format=json&origin=*';
      const search = await fetchJSON(searchUrl);
      const hits = search.search || [];
      logs.push({ check: 'wikidata-search', status: 'ok', detail: hits.length + ' hits' });
      if (!hits.length) {
        // try Russian label search
        const searchRu = await fetchJSON(
          'https://www.wikidata.org/w/api.php?action=wbsearchentities&search=' +
          encodeURIComponent(name) + '&language=ru&uselang=ru&limit=8&format=json&origin=*'
        );
        hits.push.apply(hits, searchRu.search || []);
        logs.push({ check: 'wikidata-search-ru', status: 'ok', detail: (searchRu.search || []).length + ' hits' });
      }
      if (!hits.length) return;

      const ids = hits.slice(0, 6).map(h => h.id).join('|');
      const entUrl = 'https://www.wikidata.org/w/api.php?action=wbgetentities&ids=' + ids +
        '&props=labels|descriptions|claims|sitelinks&languages=en|ru|uk&format=json&origin=*';
      const ents = await fetchJSON(entUrl);
      const entities = ents.entities || {};

      Object.keys(entities).forEach(qid => {
        const e = entities[qid];
        if (!e || e.missing) return;
        const label = (e.labels && (e.labels.en || e.labels.ru || e.labels.uk) || {}).value || qid;
        const desc = (e.descriptions && (e.descriptions.en || e.descriptions.ru || e.descriptions.uk) || {}).value || '';
        const wdUrl = 'https://www.wikidata.org/wiki/' + qid;

        pushUnique(results, {
          type: 'url', value: wdUrl, label: 'Wikidata: ' + label,
          relation: 'mentioned_in', status: 'confirmed',
          finding: (desc ? desc + ' · ' : '') + 'Wikidata entity ' + qid + ' matches public name search (same name ≠ unique identity)',
          sourceUrl: wdUrl, confidence: 'HIGH'
        });

        // sitelinks → Wikipedia pages
        const site = e.sitelinks || {};
        ['enwiki', 'ruwiki', 'ukwiki', 'dewiki', 'frwiki'].forEach(wiki => {
          if (!site[wiki]) return;
          const title = site[wiki].title;
          const lang = wiki.replace('wiki', '');
          const wikiUrl = 'https://' + lang + '.wikipedia.org/wiki/' + encodeURIComponent(title.replace(/ /g, '_'));
          pushUnique(results, {
            type: 'url', value: wikiUrl, label: 'Wikipedia: ' + title,
            relation: 'mentioned_in', status: 'confirmed',
            finding: 'Wikipedia article linked from Wikidata ' + qid,
            sourceUrl: wikiUrl, confidence: 'HIGH'
          });
        });

        // P856 official website
        const claims = e.claims || {};
        (claims.P856 || []).slice(0, 3).forEach(c => {
          const url = c.mainsnak && c.mainsnak.datavalue && c.mainsnak.datavalue.value;
          if (!url) return;
          try {
            const host = new URL(url).hostname.replace(/^www\./, '');
            pushUnique(results, {
              type: 'url', value: url, label: url.replace(/^https?:\/\//, '').slice(0, 40),
              relation: 'has_website', status: 'confirmed',
              finding: 'Official website (Wikidata P856)', sourceUrl: wdUrl, confidence: 'HIGH'
            });
            pushUnique(results, {
              type: 'domain', value: host, label: host,
              relation: 'associated_with', status: 'confirmed',
              finding: 'Domain from Wikidata official website', sourceUrl: wdUrl, confidence: 'HIGH'
            });
          } catch (_) {}
        });

        // P2002 Twitter username, P2037 Instagram, P2397 YouTube, P2949 Wikidata etc.
        const socialMap = {
          P2002: 'twitter', P2003: 'instagram', P2397: 'youtube',
          P2013: 'facebook', P7085: 'tiktok', P5797: 'twitch',
          P2037: 'github', P6634: 'linkedin', P2005: 'instagram'
        };
        Object.keys(socialMap).forEach(prop => {
          (claims[prop] || []).slice(0, 2).forEach(c => {
            const u = c.mainsnak && c.mainsnak.datavalue && c.mainsnak.datavalue.value;
            if (!u) return;
            pushUnique(results, {
              type: 'username', value: String(u).replace(/^@/, ''), label: '@' + String(u).replace(/^@/, ''),
              relation: 'has_account', status: 'confirmed',
              finding: socialMap[prop] + ' handle from Wikidata ' + prop + ' (public claim)',
              sourceUrl: wdUrl, confidence: 'HIGH',
              metadata: { platform: socialMap[prop], wikidata: qid }
            });
          });
        });

        // P569 birth year only as document (public figure data)
        const birth = claims.P569 && claims.P569[0];
        if (birth && birth.mainsnak && birth.mainsnak.datavalue) {
          const t = birth.mainsnak.datavalue.value && birth.mainsnak.datavalue.value.time;
          if (t) {
            const year = String(t).replace(/^\+/, '').slice(0, 4);
            pushUnique(results, {
              type: 'document', value: 'birth-year:' + year, label: 'Birth year (public): ' + year,
              relation: 'related_to', status: 'confirmed',
              finding: 'Public birth date year from Wikidata (not private data)', sourceUrl: wdUrl, confidence: 'MEDIUM'
            });
          }
        }

        // P106 occupation → document
        (claims.P106 || []).slice(0, 4).forEach(c => {
          const id = c.mainsnak && c.mainsnak.datavalue && c.mainsnak.datavalue.value && c.mainsnak.datavalue.value.id;
          if (id) {
            pushUnique(results, {
              type: 'document', value: 'occupation:' + id, label: 'Occupation claim ' + id,
              relation: 'related_to', status: 'needs_review',
              finding: 'Wikidata occupation claim ' + id + ' — resolve label separately', sourceUrl: wdUrl, confidence: 'MEDIUM'
            });
          }
        });
      });
    } catch (e) {
      logs.push({ check: 'wikidata', status: 'error', detail: e.message });
    }
  }

  async function searchWikipedia(name, results, logs) {
    const langs = ['en', 'ru', 'uk'];
    for (const lang of langs) {
      try {
        const url = 'https://' + lang + '.wikipedia.org/w/api.php?action=opensearch&search=' +
          encodeURIComponent(name) + '&limit=5&namespace=0&format=json&origin=*';
        const data = await fetchJSON(url);
        // opensearch: [query, titles[], descriptions[], urls[]]
        const titles = data[1] || [];
        const descs = data[2] || [];
        const urls = data[3] || [];
        logs.push({ check: 'wikipedia-' + lang, status: 'ok', detail: titles.length + ' hits' });
        titles.forEach((title, i) => {
          const pageUrl = urls[i] || ('https://' + lang + '.wikipedia.org/wiki/' + encodeURIComponent(title.replace(/ /g, '_')));
          pushUnique(results, {
            type: 'url', value: pageUrl, label: 'Wikipedia (' + lang + '): ' + title,
            relation: 'mentioned_in', status: 'confirmed',
            finding: (descs[i] || 'Wikipedia open search') + ' — public encyclopedia page; same name may match multiple people',
            sourceUrl: pageUrl, confidence: 'HIGH'
          });
        });
        // summary for top hit
        if (titles[0]) {
          try {
            const sum = await fetchJSON(
              'https://' + lang + '.wikipedia.org/api/rest_v1/page/summary/' + encodeURIComponent(titles[0].replace(/ /g, '_'))
            );
            if (sum && sum.extract) {
              pushUnique(results, {
                type: 'document',
                value: 'wiki-summary:' + lang + ':' + titles[0],
                label: 'Summary: ' + titles[0].slice(0, 40),
                relation: 'mentioned_in',
                status: 'confirmed',
                finding: String(sum.extract).slice(0, 280),
                sourceUrl: sum.content_urls && sum.content_urls.desktop && sum.content_urls.desktop.page || urls[0],
                confidence: 'MEDIUM'
              });
            }
            if (sum && sum.coordinates) {
              pushUnique(results, {
                type: 'geo_estimate',
                value: sum.coordinates.lat + ',' + sum.coordinates.lon,
                label: '📍 Place coords (article)',
                relation: 'related_to',
                status: 'needs_review',
                finding: 'Coordinates from Wikipedia article (place/topic — not proof of person location)',
                sourceUrl: sum.content_urls && sum.content_urls.desktop && sum.content_urls.desktop.page,
                confidence: 'LOW',
                metadata: { kind: 'article_coordinates', lat: sum.coordinates.lat, lon: sum.coordinates.lon }
              });
            }
          } catch (e) {
            logs.push({ check: 'wiki-summary-' + lang, status: 'error', detail: e.message });
          }
        }
      } catch (e) {
        logs.push({ check: 'wikipedia-' + lang, status: 'error', detail: e.message });
      }
    }
  }

  async function searchOpenLibrary(name, results, logs) {
    try {
      const data = await fetchJSON(
        'https://openlibrary.org/search/authors.json?q=' + encodeURIComponent(name) + '&limit=5'
      );
      const docs = data.docs || [];
      logs.push({ check: 'openlibrary', status: 'ok', detail: docs.length + ' authors' });
      const q = name.toLowerCase();
      docs.filter(d => {
        const n = (d.name || '').toLowerCase();
        return n === q || n.startsWith(q) || q.startsWith(n);
      }).slice(0, 4).forEach(d => {
        const key = d.key || '';
        const url = key ? 'https://openlibrary.org' + (key.startsWith('/') ? key : '/' + key) : '';
        if (url) {
          pushUnique(results, {
            type: 'url', value: url, label: 'OpenLibrary: ' + (d.name || name),
            relation: 'mentioned_in', status: 'confirmed',
            finding: 'Author record in Open Library' + (d.work_count ? ' · works: ' + d.work_count : ''),
            sourceUrl: url, confidence: 'MEDIUM'
          });
        }
      });
    } catch (e) {
      logs.push({ check: 'openlibrary', status: 'error', detail: e.message });
    }
  }

  async function searchMusicBrainz(name, results, logs) {
    try {
      const data = await fetchJSON(
        'https://musicbrainz.org/ws/2/artist?query=' + encodeURIComponent('"' + name + '"') + '&fmt=json&limit=8',
        12000
      );
      const artists = (data.artists || []).filter(a => {
        // Only keep strong matches — avoid "Иван Иванов" noise
        const score = a.score != null ? Number(a.score) : 0;
        const n = (a.name || '').toLowerCase();
        const q = name.toLowerCase();
        return score >= 90 || n === q || n.indexOf(q) === 0;
      });
      logs.push({ check: 'musicbrainz', status: 'ok', detail: artists.length + ' strong matches' });
      artists.slice(0, 3).forEach(a => {
        const url = 'https://musicbrainz.org/artist/' + a.id;
        pushUnique(results, {
          type: 'url', value: url, label: 'MusicBrainz: ' + (a.name || name),
          relation: 'mentioned_in', status: 'confirmed',
          finding: (a.type || 'Artist') + (a.country ? ' · ' + a.country : '') + ' · score ' + (a.score || '?'),
          sourceUrl: url, confidence: 'MEDIUM'
        });
      });
    } catch (e) {
      logs.push({ check: 'musicbrainz', status: 'error', detail: e.message });
    }
  }

  async function searchGithubUsers(name, results, logs) {
    try {
      // GitHub search API allows unauthenticated limited requests
      const data = await fetchJSON(
        'https://api.github.com/search/users?q=' + encodeURIComponent(name) + '+in:fullname&per_page=5'
      );
      const items = data.items || [];
      logs.push({ check: 'github-users', status: 'ok', detail: items.length + ' users' });
      items.forEach(u => {
        pushUnique(results, {
          type: 'username', value: u.login, label: '@' + u.login,
          relation: 'possible_profile', status: 'possible',
          finding: 'GitHub user search match for name (not identity proof)',
          sourceUrl: u.html_url, confidence: 'LOW'
        });
        pushUnique(results, {
          type: 'url', value: u.html_url, label: 'GitHub: ' + u.login,
          relation: 'possible_profile', status: 'possible',
          finding: 'GitHub profile from name search — verify manually',
          sourceUrl: u.html_url, confidence: 'LOW'
        });
      });
    } catch (e) {
      logs.push({ check: 'github-users', status: 'error', detail: e.message });
    }
  }

  S.register({
    name: 'person-intelligence',
    supportedTypes: ['person', 'alias'],
    requiresApiKey: false,
    sourceUrl: 'Wikidata / Wikipedia / OpenLibrary / MusicBrainz / GitHub',
    async analyze(value) {
      const results = [];
      results._keys = new Set();
      const logs = [];
      const name = (window.NexusDedupe && NexusDedupe.normalizePerson(value)) || String(value || '').trim();
      if (!name || name.length < 2) {
        return { ok: false, error: 'Invalid name', results: [], logs: [{ status: 'error', detail: 'invalid' }] };
      }
      const parts = name.split(/\s+/).filter(Boolean);

      results.push({
        type: 'document',
        value: 'name-query:' + name.toLowerCase(),
        label: 'Query: ' + name,
        relation: 'normalized_as',
        status: 'confirmed',
        finding: 'Person-name search. Same name does NOT mean same person — corroborate with org/date/context.',
        sourceUrl: '',
        confidence: 'HIGH'
      });

      await searchWikidata(name, results, logs);
      await searchWikipedia(name, results, logs);
      await searchOpenLibrary(name, results, logs);
      await searchMusicBrainz(name, results, logs);
      await searchGithubUsers(name, results, logs);

      delete results._keys;
      const graphable = results.length;
      logs.push({ check: 'summary', status: graphable ? 'ok' : 'none', detail: graphable + ' candidates' });

      return {
        ok: true,
        meta: { name: name, tokens: parts, resultCount: graphable },
        results: results,
        logs: logs,
        source: 'person-intelligence'
      };
    },
    normalizeResult(r) { return r; }
  });

  // Keep lightweight normalize alias for transforms that call person-normalize
  S.register({
    name: 'person-normalize',
    supportedTypes: ['person', 'alias'],
    requiresApiKey: false,
    sourceUrl: 'local + person-intelligence',
    async analyze(value, ctx) {
      // Delegate to full intelligence
      const full = S.get('person-intelligence');
      if (full) return full.analyze(value, ctx);
      return { ok: true, results: [], source: 'person-normalize' };
    },
    normalizeResult(r) { return r; }
  });
})();
