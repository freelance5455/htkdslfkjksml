/**
 * Nexus Investigation Engine
 * INPUT → NORMALIZE → CLASSIFY → CONNECTORS (parallel) → VALIDATION →
 * CORRELATION → DEDUPE → ENTITIES → RELATIONSHIPS → EVIDENCE → CONFIDENCE → GRAPH
 */
(function (global) {
  const REL_LABELS = {
    resolves_to: 'указывает на', hosted_by: 'размещён у', in_asn: 'в ASN',
    located_in: 'находится в',
    geo_estimate: 'geo estimate',
    announced_by: 'announced by',
    ptr_record: 'PTR',
    ip_version: 'IP version',
    netblock: 'netblock', registered_to: 'зарегистрирован на', nameserver: 'NS',
    mail_to: 'почта', cname: 'CNAME', has_txt: 'TXT', email_domain: 'домен почты',
    local_part: 'local-part', possible_profile: 'возможный профиль', has_account: 'имеет аккаунт',
    has_website: 'сайт', works_at: 'связан с', mentioned_in: 'упоминается в', related_to: 'связан с',
    registered_at: 'дата', ptr_to: 'PTR', in_network: 'сеть', hosted_on: 'на домене',
    uses_protocol: 'протокол', uses_port: 'порт', path: 'путь', carrier: 'оператор',
    carrier_estimate: 'carrier estimate',
    number_type: 'number type',
    normalized_as: 'normalized as',
    mentioned_on: 'mentioned on',
    associated_with: 'associated with',
    profile_on: 'profile on',
    has_record: 'DNS record',
    registrant_email: 'email регистратора',
    has_certificate: 'сертификат', subdomain_of: 'поддомен', has_spf: 'SPF', has_dmarc: 'DMARC',
    has_txt_record: 'TXT', service_account: 'сервис'
  };

  function mapStatus(s) {
    if (s === 'confirmed') return 'confirmed';
    if (s === 'possible') return 'possible';
    if (s === 'needs_review' || s === 'unverified') return 'unverified';
    return 'unknown';
  }

  const sourceHealth = {};
  function setHealth(name, state, detail) {
    sourceHealth[name] = { state, detail: detail || '', at: new Date().toISOString() };
  }

  function isFalsePositive(item) {
    if (!item) return true;
    const url = String(item.sourceUrl || item.value || '').toLowerCase();
    const finding = String(item.finding || '').toLowerCase();
    const label = String(item.label || '').toLowerCase();
    if (/\b404\b|not found|does not exist|no such user|account suspended|page not found/.test(finding + ' ' + label)) return true;
    if (item.status !== 'confirmed' && item.relation === 'possible_profile') return true;
    if (!String(item.value || '').trim()) return true;
    if (/^(error|failed|timeout|null|undefined|n\/a)$/i.test(String(item.value).trim())) return true;
    if (/example\.com|localhost|127\.0\.0\.1|about:blank/.test(url)) return true;
    if (item.presence && item.presence !== 'CONFIRMED') return true;
    return false;
  }

  function whyAdded(item, relation) {
    const parts = [];
    parts.push('Source: ' + (item.sourceName || item.source || 'unknown'));
    if (item.finding) parts.push(item.finding);
    if (relation) parts.push('Link: ' + (REL_LABELS[relation] || relation));
    if (item.status) parts.push('Status: ' + item.status);
    if (item.confidence) parts.push('Confidence: ' + item.confidence);
    if (item.sourceUrl) parts.push('URL: ' + item.sourceUrl);
    return parts.join(' · ');
  }

  const ERROR_VALUE_RE = /^(no-mx|mx-error|github-404|github-error|img-error|exif-error|ocr-unavailable|no-exif|dns-error|a-error|nxdomain)$/i;
  const ERROR_LABEL_RE = /(failed|error|timeout|unavailable|not found|no mx|check failed|source unavailable|rate limit)/i;

  function isGraphableEntity(item) {
    if (!item) return false;
    const st = (item.status || '').toLowerCase();
    const v = String(item.value || item.label || '');
    if (!v || v.length < 1) return false;
    // Never graph errors / empty / not-found states
    if (/^(failed|error|timeout|unavailable|not found|n\/a|null|undefined)$/i.test(v.trim())) return false;
    if (/failed|timeout|api error|mx-error|dns failed|http 4\d\d|http 5\d\d/i.test(v) && item.type !== 'document') return false;
    if (st === 'not_found' || st === 'error' || st === 'blocked' || st === 'rate_limited') return false;
    // Geo estimates allowed as needs_review
    if (item.type === 'geo_estimate' || (item.metadata && item.metadata.kind && /geolocation_estimate/.test(item.metadata.kind))) {
      return st !== 'error';
    }
    // Confirmed always OK
    if (st === 'confirmed') return true;
    // needs_review / possible only for infrastructure-ish types
    if (st === 'needs_review' || st === 'possible' || st === 'unverified') {
      return ['organization', 'asn', 'network', 'document', 'carrier', 'geo_estimate', 'email', 'domain', 'url', 'username', 'social'].includes(item.type);
    }
    if (st === 'unknown' || !st) return false;
    return st === 'confirmed';
  }

  function dedupeResults(list, root) {
    const map = new Map();
    list.forEach(item => {
      if (!isGraphableEntity(item, root)) return;
      const type = item.type || 'other';
      const value = item.value || item.label || '';
      const key = (global.NexusDedupe && NexusDedupe.canonical(type, value)) || (type + '::' + value);
      if (!map.has(key)) {
        map.set(key, {
          type, value, label: item.label || value,
          relation: item.relation || 'related_to',
          evidence: [], sourceCount: 0, why: '', confidence: 'UNKNOWN'
        });
      }
      const row = map.get(key);
      const srcName = item.sourceName || item.source || 'unknown';
      const finding = item.finding || item.label || value;
      if (!row.evidence.some(e => e.source === srcName && e.finding === finding)) {
        row.evidence.push({
          source: srcName, url: item.sourceUrl || '', finding,
          status: mapStatus(item.status), foundAt: new Date().toISOString(),
          why: whyAdded(item, item.relation), confidence: item.confidence || null
        });
      }
      row.sourceCount = new Set(row.evidence.map(e => e.source)).size;
      row.why = row.evidence.map(e => e.why || e.finding).filter(Boolean).slice(0, 3).join(' | ');
      if (global.NexusConfidence) {
        const c = NexusConfidence.scoreEntity(row.evidence);
        row.confidence = c.level;
        row.confidenceReason = c.reason;
        row.confidenceScore = c.score;
      }
    });
    return [...map.values()];
  }

  /** Parallel independent connectors */
  async function runConnectors(type, value, ctx, onProgress) {
    const sources = (global.NexusSources && NexusSources.forType(type)) || [];
    const enabled = sources.filter(c => {
      if (global.NexusApiKeys && !NexusApiKeys.isEnabled(c.name)) return false;
      if (c.requiresApiKey && global.NexusApiKeys && !NexusApiKeys.get(c.name)) return false;
      // skip demo unless ctx.demoMode
      if (c.name === 'demo' && !ctx.demoMode) return false;
      return true;
    });

    const tasks = enabled.map(async (c) => {
      if (ctx.aborted) return null;
      if (onProgress) onProgress({ source: c.name, state: 'running' });
      try {
        const res = await c.analyze(value, ctx);
        if (res && res.skipped) {
          if (onProgress) onProgress({ source: c.name, state: 'skip' });
          return null;
        }
        if (res && res.ok === false) {
          setHealth(c.name, 'Failed', res.error || 'Source unavailable');
          if (onProgress) onProgress({ source: c.name, state: 'error', error: res.error || 'Source unavailable', health: 'Failed' });
          return { source: c.name, ok: false, error: res.error || 'Source unavailable', results: [], logs: res.logs || [] };
        }
        const cnt = (res.results || []).length;
        const health = cnt > 0 ? 'Working' : 'Limited';
        setHealth(c.name, health, cnt + ' results');
        if (onProgress) onProgress({ source: c.name, state: 'done', count: cnt, health });
        return { source: c.name, ok: true, results: res.results || [], meta: res.meta, errors: res.errors, logs: res.logs || [] };
      } catch (e) {
        setHealth(c.name, 'Failed', e.message);
        if (onProgress) onProgress({ source: c.name, state: 'error', error: e.message, health: 'Failed' });
        return { source: c.name, ok: false, error: e.message, results: [], logs: [] };
      }
    });

    const settled = await Promise.all(tasks);
    return settled.filter(Boolean);
  }

  const MAX_AUTO_ENTITIES = 60;

  async function analyze(input, options) {
    options = options || {};
    const demoMode = false; // never use synthetic demo data
    const depth = Math.min(3, Math.max(0, options.depth != null ? options.depth : 1));
    const onProgress = options.onProgress || function () {};
    const abortCtrl = options.abortCtrl || { aborted: false };

    if (global.NexusRateLimit) NexusRateLimit.resetAnalysisBudget(options.maxRequests || 30);

    let type = options.type || (global.NexusDedupe && NexusDedupe.detectType(input)) || 'other';
    let value = input;
    if (global.NexusDedupe) {
      if (type === 'ip') value = NexusDedupe.normalizeIP(input);
      else if (type === 'email') value = NexusDedupe.normalizeEmail(input);
      else if (type === 'domain') value = NexusDedupe.normalizeDomain(input);
      else if (type === 'url') value = NexusDedupe.normalizeURL(input);
      else if (type === 'phone') value = NexusDedupe.normalizePhone(input);
      else if (type === 'username') value = NexusDedupe.normalizeUsername(input);
      else if (type === 'hash') value = NexusDedupe.normalizeHash(input);
    }

    const cacheKey = (global.NexusDedupe && NexusDedupe.canonical(type, value)) || (type + '::' + value);
    if (!options.forceRefresh && global.NexusCache) {
      const cached = NexusCache.get(cacheKey);
      if (cached) {
        onProgress({ source: 'cache', state: 'done', message: 'From cache', health: 'Working' });
        return Object.assign({}, cached, { fromCache: true });
      }
    }

    onProgress({ source: 'pipeline', state: 'running', message: 'normalize+classify' });
    const ctx = {
      demoMode, depth,
      photoData: options.photoData, dataUrl: options.dataUrl,
      fileBytes: options.fileBytes, mime: options.mime, fileName: options.fileName,
      get aborted() { return abortCtrl.aborted; }
    };

    const allRaw = [];
    const reports = await runConnectors(type, value, ctx, onProgress);
    reports.forEach(rep => {
      (rep.results || []).forEach(r => allRaw.push(Object.assign({}, r, { sourceName: rep.source })));
    });

    const rootRef = { type, value };
    let entities = dedupeResults(allRaw, rootRef);

    // Depth 2+: expand limited technical children
    if (depth >= 2 && !abortCtrl.aborted) {
      const expandTypes = new Set(['ip', 'domain', 'email', 'mx', 'ns', 'url', 'website']);
      const toExpand = entities.filter(e => expandTypes.has(e.type)).slice(0, depth === 3 ? 8 : 5);
      for (const ent of toExpand) {
        if (abortCtrl.aborted) break;
        onProgress({ source: 'depth-' + ent.type, state: 'running', message: ent.value });
        const sub = await runConnectors(ent.type, ent.value, ctx, onProgress);
        sub.forEach(rep => {
          (rep.results || []).forEach(r => allRaw.push(Object.assign({}, r, { sourceName: rep.source })));
        });
      }
      entities = dedupeResults(allRaw, rootRef);
    }

    // Anti-spam: cap auto entities, rest in overflow
    let overflow = [];
    if (entities.length > MAX_AUTO_ENTITIES) {
      // prefer higher confidence first
      const rank = { CONFIRMED: 4, HIGH: 3, MEDIUM: 2, LOW: 1, UNKNOWN: 0, CONFLICT: 0 };
      entities.sort((a, b) => (rank[b.confidence] || 0) - (rank[a.confidence] || 0) || (b.sourceCount || 0) - (a.sourceCount || 0));
      overflow = entities.slice(MAX_AUTO_ENTITIES);
      entities = entities.slice(0, MAX_AUTO_ENTITIES);
    }

    const root = { type, value, label: value, canonical: cacheKey };
    const relationships = entities.map(e => ({
      targetType: e.type, targetValue: e.value, targetLabel: e.label,
      type: REL_LABELS[e.relation] || e.relation || 'связан с',
      relationKey: e.relation, evidence: e.evidence,
      confidence: e.confidence, confidenceReason: e.confidenceReason
    }));

    const result = {
      root, entities, relationships, overflow,
      overflowCount: overflow.length,
      sourceReport: reports.map(r => ({
        source: r.source, ok: r.ok, error: r.error,
        count: (r.results || []).length, logs: r.logs || []
      })),
      errors: reports.filter(r => !r.ok).map(r => r.source + ': ' + (r.error || 'unavailable')),
      logs: reports.flatMap(r => (r.logs || []).map(l => Object.assign({ source: r.source }, l))),
      sourceHealth: Object.assign({}, sourceHealth),
      analyzedAt: new Date().toISOString()
    };

    if (global.NexusCache) NexusCache.set(cacheKey, result);
    onProgress({ source: 'pipeline', state: 'done', message: 'graph ready', count: entities.length });
    return result;
  }

  function recheckDiff(prevEntities, nextEntities) {
    const keyOf = (e) => (global.NexusDedupe && NexusDedupe.canonical(e.type, e.value)) || (e.type + '::' + e.value);
    const prevMap = new Map((prevEntities || []).map(e => [keyOf(e), e]));
    const nextMap = new Map((nextEntities || []).map(e => [keyOf(e), e]));
    const out = { NEW: [], CHANGED: [], REMOVED: [], SAME: [] };
    nextMap.forEach((e, k) => {
      if (!prevMap.has(k)) out.NEW.push(e);
      else {
        const p = prevMap.get(k);
        const changed = (p.sourceCount || 0) !== (e.sourceCount || 0) ||
          (p.confidence || '') !== (e.confidence || '');
        if (changed) out.CHANGED.push(e); else out.SAME.push(e);
      }
    });
    prevMap.forEach((e, k) => { if (!nextMap.has(k)) out.REMOVED.push(e); });
    return out;
  }

  global.NexusEngine = {
    analyze, REL_LABELS, mapStatus, isFalsePositive, isGraphableEntity,
    dedupeResults, recheckDiff, getSourceHealth() { return Object.assign({}, sourceHealth); }
  };
})(typeof window !== 'undefined' ? window : globalThis);
