(function (global) {
  function expandIPv6(ip) {
    // minimal normalize: lowercase, strip zone
    return String(ip || '').toLowerCase().split('%')[0].trim();
  }

  function normalizeIP(v) {
    let s = String(v || '').trim().toLowerCase();
    // strip CIDR e.g. 8.8.8.8/32 → 8.8.8.8
    if (s.includes('/')) s = s.split('/')[0].trim();
    // strip brackets [::1]
    s = s.replace(/^\[|\]$/g, '');
    if (s.includes(':')) return expandIPv6(s);
    // IPv4: trim leading zeros in octets carefully - keep simple
    const parts = s.split('.');
    if (parts.length === 4 && parts.every(p => /^\d+$/.test(p) && +p >= 0 && +p <= 255)) {
      return parts.map(p => String(parseInt(p, 10))).join('.');
    }
    return s;
  }

  function isIPv4(v) {
    return /^(\d{1,3}\.){3}\d{1,3}$/.test(normalizeIP(v));
  }
  function isIPv6(v) {
    const s = normalizeIP(v);
    return s.includes(':') && !s.includes('.');
  }

  function normalizeEmail(v) {
    return String(v || '').trim().toLowerCase();
  }
  function normalizeDomain(v) {
    return String(v || '').trim().toLowerCase()
      .replace(/\.$/, '')
      .replace(/^https?:\/\//, '')
      .split('/')[0].split(':')[0];
  }
  function normalizeURL(v) {
    try {
      const u = new URL(v.startsWith('http') ? v : 'https://' + v);
      return (u.origin + u.pathname.replace(/\/$/, '') + (u.search || '')).toLowerCase();
    } catch {
      return String(v || '').trim().toLowerCase();
    }
  }
  function normalizePhone(value) {
    let d = String(value || '').replace(/\D/g, '');
    if (!d) return '';
    if (d.startsWith('00')) d = d.slice(2);
    // UA: 0XXXXXXXXX or 9-digit national → 380…
    if (d.length === 10 && d[0] === '0') d = '38' + d;
    if (d.length === 9 && d[0] !== '0') d = '380' + d;
    // RU: 8XXXXXXXXXX → 7…
    if (d.length === 11 && d[0] === '8') d = '7' + d.slice(1);
    return d ? '+' + d : '';
  }
  function normalizeUsername(v) {
    return String(v || '').trim().replace(/^@/, '').toLowerCase();
  }
  function normalizeHash(v) {
    return String(v || '').trim().toLowerCase();
  }
  function normalizePerson(v) {
    return String(v || '').trim().toLowerCase().replace(/\s+/g, ' ');
  }
  function normalizeASN(v) {
    let s = String(v || '').trim().toUpperCase().replace(/\s+/g, '');
    if (/^\d+$/.test(s)) s = 'AS' + s;
    if (!s.startsWith('AS') && /^AS\d+/i.test(String(v))) s = String(v).toUpperCase();
    return s;
  }

  /** Entity Resolver: same real-world object → one canonical key */
  function canonical(type, value) {
    const t = (type || 'other').toLowerCase();
    let val = value;
    if (t === 'ip' || t === 'netblock') {
      // netblock 1.2.3.0/24 stays as network; /32 collapses to ip
      const raw = String(value || '').trim().toLowerCase();
      if (raw.includes('/')) {
        const [ip, bits] = raw.split('/');
        const b = parseInt(bits, 10);
        if ((isIPv4(ip) && b === 32) || (isIPv6(ip) && b === 128)) {
          return 'ip::' + normalizeIP(ip);
        }
        return 'netblock::' + normalizeIP(ip) + '/' + b;
      }
      return 'ip::' + normalizeIP(value);
    }
    if (t === 'email') val = normalizeEmail(value);
    else if (t === 'domain' || t === 'ns' || t === 'mx' || t === 'website') val = normalizeDomain(value);
    else if (t === 'url') val = normalizeURL(value);
    else if (t === 'phone') val = normalizePhone(value);
    else if (t === 'username' || t === 'social' || t === 'account') val = normalizeUsername(value);
    else if (t === 'hash') val = normalizeHash(value);
    else if (t === 'person' || t === 'alias') val = normalizePerson(value);
    else if (t === 'asn') val = normalizeASN(value);
    else val = String(value || '').trim().toLowerCase();

    // username and social share identity
    const typeKey = (t === 'social' || t === 'account') ? 'username' : (t === 'website' ? 'domain' : t);
    return typeKey + '::' + val;
  }

  /** Resolve aliases: if hostname result points to IP, graph merge uses IP canonical */
  function resolveAliasKeys(type, value, meta) {
    const keys = [canonical(type, value)];
    if (meta && meta.resolvesToIp) keys.push(canonical('ip', meta.resolvesToIp));
    return keys;
  }

  function detectType(text) {
    const t = String(text || '').trim();
    if (!t) return 'other';
    if (/^(\d{1,3}\.){3}\d{1,3}(\/\d{1,2})?$/.test(t)) return t.includes('/') ? 'netblock' : 'ip';
    if (/^[0-9a-f:]+$/i.test(t) && t.includes(':')) return 'ip';
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(t)) return 'email';
    if (/^https?:\/\//i.test(t)) return 'url';
    if (/^(\+?\d[\d\-\s()]{7,})$/.test(t.replace(/\s/g, ''))) return 'phone';
    if (/^[0-9a-f]{32}$/i.test(t) || /^[0-9a-f]{40}$/i.test(t) || /^[0-9a-f]{64}$/i.test(t)) return 'hash';
    if (/^as\d+$/i.test(t)) return 'asn';
    if (/^@[\w.]+$/.test(t)) return 'username';
    if (/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(t) && !t.includes(' ')) return 'domain';
    if (/^[a-z0-9._-]{3,}$/i.test(t) && !t.includes(' ') && !t.includes('.')) return 'username';
    if (/[A-Za-zА-Яа-яЁё]{2,}\s+[A-Za-zА-Яа-яЁё]{2,}/.test(t)) return 'person';
    return 'person';
  }

  global.NexusDedupe = {
    normalizeIP, normalizeEmail, normalizeDomain, normalizeURL,
    normalizePhone, normalizeUsername, normalizeHash, normalizePerson, normalizeASN,
    isIPv4, isIPv6, canonical, resolveAliasKeys, detectType
  };
})(typeof window !== 'undefined' ? window : globalThis);
