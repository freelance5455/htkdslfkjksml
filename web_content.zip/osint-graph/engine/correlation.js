/**
 * Correlation + Claim verification helpers for background analysis.
 * No identity leaps: phone/IP/username never auto-merge into PERSON.
 */
(function (global) {
  function scoreEvidence(evidenceList) {
    const list = evidenceList || [];
    const sources = new Set(list.map(e => e.source).filter(Boolean));
    let score = 0;
    score += Math.min(40, sources.size * 15);
    const confirmed = list.filter(e => e.status === 'confirmed').length;
    score += Math.min(30, confirmed * 10);
    const hasUrl = list.some(e => e.url);
    if (hasUrl) score += 10;
    const conflict = list.some(e => e.status === 'conflict');
    if (conflict) score = Math.min(score, 35);
    // freshness
    const now = Date.now();
    const fresh = list.some(e => e.foundAt && (now - new Date(e.foundAt).getTime()) < 3600000);
    if (fresh) score += 10;
    score = Math.max(0, Math.min(100, score));
    let status = 'UNVERIFIED';
    if (conflict) status = 'CONFLICT';
    else if (sources.size >= 2 && confirmed >= 2) status = 'VERIFIED';
    else if (sources.size >= 2 && confirmed >= 1) status = 'CORROBORATED';
    else if (confirmed >= 1) status = 'POSSIBLE';
    else if (list.length) status = 'NEEDS_REVIEW';
    return { score: score, status: status, sources: sources.size, agreement: confirmed };
  }

  function isIdentityLeap(rel, fromType, toType) {
    const ft = (fromType || '').toLowerCase();
    const tt = (toType || '').toLowerCase();
    // Never auto-claim person identity from technical identifiers
    if (tt === 'person' || ft === 'person') {
      if (['ip', 'phone', 'username', 'email', 'hash', 'asn'].includes(ft) ||
          ['ip', 'phone', 'username', 'email', 'hash', 'asn'].includes(tt)) {
        return true;
      }
    }
    return false;
  }

  function claimFromEntity(parent, ent) {
    if (!parent || !ent) return null;
    if (isIdentityLeap(ent.relation, parent.type, ent.type)) {
      return {
        statement: parent.type + ' → ' + ent.type + ' (identity not auto-claimed)',
        status: 'NEEDS_REVIEW',
        note: 'Matching technical identifiers do not prove personal identity.',
        blocked: true
      };
    }
    const evidence = ent.evidence || [{
      source: ent.sourceName || ent.source || 'analysis',
      url: ent.sourceUrl || '',
      finding: ent.finding || ent.label || ent.value,
      status: ent.status === 'confirmed' ? 'confirmed' : 'unverified',
      foundAt: new Date().toISOString()
    }];
    const scored = scoreEvidence(evidence);
    return {
      statement: (parent.label || parent.value) + ' —[' + (ent.relation || 'related') + ']→ ' + (ent.label || ent.value),
      entityIds: [parent.id].filter(Boolean),
      targetType: ent.type,
      targetValue: ent.value,
      relation: ent.relation,
      status: scored.status,
      score: scored.score,
      evidence: evidence,
      sources: scored.sources,
      agreement: scored.agreement,
      why: ent.finding || ent.why || 'Derived from public source analysis',
      blocked: false
    };
  }

  function findCanonicalIntersections(nodes) {
    // Returns pairs of nodes that share canonical value (true duplicates)
    if (!global.NexusDedupe || !nodes) return [];
    const map = new Map();
    const pairs = [];
    nodes.forEach(n => {
      const k = NexusDedupe.canonical(n.type, n.value || n.label);
      if (!map.has(k)) map.set(k, []);
      map.get(k).push(n);
    });
    map.forEach((arr, k) => {
      if (arr.length > 1) pairs.push({ key: k, nodes: arr });
    });
    return pairs;
  }

  global.NexusCorrelation = {
    scoreEvidence, isIdentityLeap, claimFromEntity, findCanonicalIntersections
  };
})(typeof window !== 'undefined' ? window : globalThis);
