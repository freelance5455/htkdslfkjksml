/**
 * Continuous Background Analysis Engine
 * Non-blocking queue; uses existing NexusEngine / sources.
 * NEVER invents data. FAILED/NOT_FOUND stay out of the graph.
 */
(function (global) {
  const PRIORITY = { CRITICAL: 0, HIGH: 1, NORMAL: 2, LOW: 3 };
  const MAX_CONCURRENT = 1;          // keep UI smooth on mobile
  const MAX_QUEUE = 80;
  const MAX_DEPTH = 2;
  const MAX_ENTITIES_PER_RUN = 8;
  const MAX_TASKS_PER_ENTITY = 3;
  const TICK_MS = 900;
  const RECHECK_TTL_MS = 15 * 60 * 1000;

  const state = {
    enabled: true,
    running: 0,
    queue: [],
    tasksById: {},
    analyzedKeys: {},      // canonical → last completed ts
    entityTaskCount: {},   // entityId → count this session
    findings: [],          // Finding objects
    claims: [],
    stats: { queued: 0, running: 0, completed: 0, failed: 0, skipped: 0, rateLimited: 0, verified: 0, needsReview: 0, conflicts: 0 },
    listeners: [],
    timer: null,
    projectId: null
  };

  function emit() {
    state.stats.queued = state.queue.filter(t => t.status === 'QUEUED' || t.status === 'RETRY').length;
    state.stats.running = state.running;
    state.listeners.forEach(fn => { try { fn(getSnapshot()); } catch (_) {} });
  }

  function getSnapshot() {
    return {
      enabled: state.enabled,
      stats: Object.assign({}, state.stats),
      queue: state.queue.slice(0, 40).map(summarizeTask),
      findings: state.findings.slice(0, 50),
      claims: state.claims.slice(0, 50)
    };
  }

  function summarizeTask(t) {
    return {
      id: t.id, status: t.status, priority: t.priority,
      entityId: t.entityId, type: t.type, value: t.value,
      depth: t.depth, createdAt: t.createdAt, error: t.error || null
    };
  }

  function uid() {
    return 't_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
  }

  function canonical(type, value) {
    if (global.NexusDedupe) return NexusDedupe.canonical(type, value);
    return type + '::' + String(value || '').toLowerCase().trim();
  }

  function enqueue(task) {
    if (!state.enabled || !task) return null;
    const type = task.type || 'other';
    const value = String(task.value || '').trim();
    if (!value) return null;
    const key = canonical(type, value) + '::d' + (task.depth || 0);
    // skip if recently completed
    const last = state.analyzedKeys[key];
    if (last && Date.now() - last < RECHECK_TTL_MS && !task.force) {
      return null;
    }
    // dedupe queue
    if (state.queue.some(t => t.key === key && (t.status === 'QUEUED' || t.status === 'RUNNING' || t.status === 'RETRY'))) {
      return null;
    }
    if (task.entityId) {
      const c = state.entityTaskCount[task.entityId] || 0;
      if (c >= MAX_TASKS_PER_ENTITY && !task.force) return null;
    }
    if (state.queue.length >= MAX_QUEUE) {
      // drop lowest priority
      state.queue.sort((a, b) => PRIORITY[a.priority] - PRIORITY[b.priority]);
      while (state.queue.length >= MAX_QUEUE) {
        const drop = state.queue.pop();
        if (drop) drop.status = 'SKIPPED';
        state.stats.skipped++;
      }
    }
    const t = {
      id: uid(),
      key: key,
      status: 'QUEUED',
      priority: task.priority || 'NORMAL',
      type: type,
      value: value,
      entityId: task.entityId || null,
      depth: task.depth || 0,
      transformId: task.transformId || 'auto-analyze',
      source: task.source || 'background',
      createdAt: new Date().toISOString(),
      startedAt: null,
      completedAt: null,
      retryCount: 0,
      force: !!task.force
    };
    state.queue.push(t);
    state.tasksById[t.id] = t;
    if (t.entityId) state.entityTaskCount[t.entityId] = (state.entityTaskCount[t.entityId] || 0) + 1;
    sortQueue();
    emit();
    return t;
  }

  function sortQueue() {
    state.queue.sort((a, b) => {
      const pa = PRIORITY[a.priority] != null ? PRIORITY[a.priority] : 2;
      const pb = PRIORITY[b.priority] != null ? PRIORITY[b.priority] : 2;
      if (pa !== pb) return pa - pb;
      return (a.createdAt || '').localeCompare(b.createdAt || '');
    });
  }

  function enqueueEntity(node, opts) {
    opts = opts || {};
    if (!node || !node.type || !(node.value || node.label)) return;
    const type = node.type;
    // skip pure document noise unless forced
    if (type === 'document' && !opts.force) return;
    if (type === 'photo' || type === 'image') return;
    const priority = opts.priority || (opts.isRoot ? 'HIGH' : 'NORMAL');
    enqueue({
      type: type,
      value: node.value || node.label,
      entityId: node.id,
      depth: opts.depth || 0,
      priority: priority,
      source: opts.source || 'graph-watch',
      force: opts.force
    });
  }

  function enqueueGraph(nodes, opts) {
    opts = opts || {};
    (nodes || []).forEach((n, i) => {
      enqueueEntity(n, {
        depth: 0,
        priority: i < 5 ? 'HIGH' : 'NORMAL',
        source: opts.source || 'graph-scan'
      });
    });
  }

  async function runTask(task) {
    task.status = 'RUNNING';
    task.startedAt = new Date().toISOString();
    state.running++;
    emit();

    try {
      if (global.NexusRateLimit && !NexusRateLimit.canRequest()) {
        task.status = 'RATE_LIMITED';
        task.retryCount++;
        state.stats.rateLimited++;
        if (task.retryCount < 3) {
          task.status = 'RETRY';
          // re-queue later
          setTimeout(() => {
            if (task.status === 'RETRY') {
              task.status = 'QUEUED';
              sortQueue();
              emit();
            }
          }, 5000 + task.retryCount * 2000);
        } else {
          task.status = 'FAILED';
          task.error = 'rate limited';
          state.stats.failed++;
        }
        return;
      }

      if (!global.NexusEngine || typeof NexusEngine.analyze !== 'function') {
        task.status = 'SKIPPED';
        task.error = 'engine unavailable';
        state.stats.skipped++;
        return;
      }

      const analysis = await NexusEngine.analyze(task.value, {
        type: task.type,
        depth: 0, // single hop per task; further depth via queue
        onProgress: function () {}
      });

      task.status = 'COMPLETED';
      task.completedAt = new Date().toISOString();
      state.stats.completed++;
      state.analyzedKeys[task.key] = Date.now();

      // Feed results into correlation + optional graph enrichment
      if (analysis && typeof global.NexusBackgroundOnResult === 'function') {
        await global.NexusBackgroundOnResult(task, analysis);
      }
    } catch (e) {
      task.status = 'FAILED';
      task.error = (e && e.message) || String(e);
      task.completedAt = new Date().toISOString();
      state.stats.failed++;
    } finally {
      state.running = Math.max(0, state.running - 1);
      // remove completed from active queue list view
      state.queue = state.queue.filter(t =>
        t.status === 'QUEUED' || t.status === 'RUNNING' || t.status === 'RETRY' || t.status === 'RATE_LIMITED'
      );
      emit();
    }
  }

  function tick() {
    if (!state.enabled) return;
    while (state.running < MAX_CONCURRENT) {
      const next = state.queue.find(t => t.status === 'QUEUED');
      if (!next) break;
      // fire and forget — does not block UI
      runTask(next);
    }
  }

  function start(projectId) {
    state.projectId = projectId || null;
    if (state.timer) return;
    state.timer = setInterval(tick, TICK_MS);
    tick();
    emit();
  }

  function stop() {
    if (state.timer) {
      clearInterval(state.timer);
      state.timer = null;
    }
    emit();
  }

  function setEnabled(v) {
    state.enabled = !!v;
    if (state.enabled) start(state.projectId);
    emit();
  }

  function resetSession() {
    state.queue = [];
    state.tasksById = {};
    state.entityTaskCount = {};
    // keep analyzedKeys / findings across soft resets optional
    emit();
  }

  function clearFindings() {
    state.findings = [];
    state.claims = [];
    state.stats.verified = 0;
    state.stats.needsReview = 0;
    state.stats.conflicts = 0;
    emit();
  }

  function addFinding(f) {
    if (!f) return;
    const id = f.id || uid();
    // dedupe findings by statement+entities
    const sig = (f.statement || '') + '|' + (f.entityIds || []).join(',');
    if (state.findings.some(x => (x.statement || '') + '|' + (x.entityIds || []).join(',') === sig)) {
      return;
    }
    const finding = Object.assign({ id: id, createdAt: new Date().toISOString() }, f);
    state.findings.unshift(finding);
    if (state.findings.length > 100) state.findings.length = 100;
    if (finding.status === 'VERIFIED' || finding.status === 'DIRECTLY_VERIFIED') state.stats.verified++;
    else if (finding.status === 'CONFLICT') state.stats.conflicts++;
    else if (finding.status === 'NEEDS_REVIEW' || finding.status === 'POSSIBLE') state.stats.needsReview++;
    emit();
    return finding;
  }

  function addClaim(c) {
    if (!c) return;
    const claim = Object.assign({ id: uid(), createdAt: new Date().toISOString() }, c);
    state.claims.unshift(claim);
    if (state.claims.length > 150) state.claims.length = 150;
    return claim;
  }

  function onUpdate(fn) {
    state.listeners.push(fn);
    return () => {
      state.listeners = state.listeners.filter(x => x !== fn);
    };
  }

  global.NexusBackground = {
    start, stop, setEnabled, resetSession, clearFindings,
    enqueue, enqueueEntity, enqueueGraph,
    addFinding, addClaim, onUpdate, getSnapshot,
    PRIORITY, MAX_DEPTH, MAX_ENTITIES_PER_RUN
  };
})(typeof window !== 'undefined' ? window : globalThis);
