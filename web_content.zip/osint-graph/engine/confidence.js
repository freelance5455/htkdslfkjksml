/**
 * Confidence Engine — evidence-based scoring
 * Levels: CONFIRMED | HIGH | MEDIUM | LOW | UNKNOWN | CONFLICT
 */
(function (global) {
  function scoreEntity(evidenceList) {
    const list = evidenceList || [];
    if (!list.length) return { level: 'UNKNOWN', reason: 'No evidence', score: 0 };

    const sources = new Set(list.map(e => (e.source || '').toLowerCase()).filter(Boolean));
    const statuses = list.map(e => (e.status || '').toLowerCase());
    const hasConfirmed = statuses.some(s => s === 'confirmed');
    const hasConflict = statuses.includes('confirmed') && statuses.some(s => s === 'not_found' || s === 'failed');

    if (hasConflict) {
      return { level: 'CONFLICT', reason: 'Contradictory source statuses', score: 0.3 };
    }

    let score = 0;
    list.forEach(e => {
      if (e.status === 'confirmed') score += 0.45;
      else if (e.status === 'possible' || e.status === 'unverified') score += 0.15;
      if (e.url) score += 0.05;
    });
    score += Math.min(0.35, (sources.size - 1) * 0.15);
    score = Math.min(1, score);

    let level = 'UNKNOWN';
    let reason = '';
    if (hasConfirmed && sources.size >= 2) {
      level = 'CONFIRMED';
      reason = sources.size + ' independent sources with confirmed evidence';
    } else if (hasConfirmed) {
      level = 'HIGH';
      reason = 'Direct public confirmation from ' + [...sources][0];
    } else if (sources.size >= 2 && score >= 0.4) {
      level = 'MEDIUM';
      reason = 'Multiple weak sources (' + sources.size + ')';
    } else if (score >= 0.25) {
      level = 'LOW';
      reason = 'Single weak source';
    } else {
      level = 'UNKNOWN';
      reason = 'Insufficient evidence';
    }
    return { level, reason, score: Math.round(score * 100) / 100, sourceCount: sources.size };
  }

  function scoreRelation(evidenceList) {
    return scoreEntity(evidenceList);
  }

  global.NexusConfidence = { scoreEntity, scoreRelation };
})(typeof window !== 'undefined' ? window : globalThis);
