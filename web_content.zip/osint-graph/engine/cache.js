(function (global) {
  const KEY = 'nexus_lookup_cache_v1';
  const TTL = 1000 * 60 * 60 * 6; // 6h

  function load() {
    try { return JSON.parse(localStorage.getItem(KEY) || '{}'); } catch { return {}; }
  }
  function save(obj) {
    try { localStorage.setItem(KEY, JSON.stringify(obj)); } catch {}
  }

  global.NexusCache = {
    get(canonical) {
      const all = load();
      const row = all[canonical];
      if (!row) return null;
      if (Date.now() - (row.ts || 0) > TTL) {
        delete all[canonical];
        save(all);
        return null;
      }
      return row.data;
    },
    set(canonical, data) {
      const all = load();
      all[canonical] = { ts: Date.now(), data };
      // cap size
      const keys = Object.keys(all);
      if (keys.length > 200) {
        keys.sort((a, b) => (all[a].ts || 0) - (all[b].ts || 0));
        keys.slice(0, keys.length - 150).forEach(k => delete all[k]);
      }
      save(all);
    },
    clear() { localStorage.removeItem(KEY); }
  };
})(typeof window !== 'undefined' ? window : globalThis);
