/**
 * Client-side Image / File intelligence (no backend).
 * SHA-256 via SubtleCrypto, basic JPEG EXIF, aHash, dimensions/MIME.
 */
(function (global) {
  function dataUrlToBytes(dataUrl) {
    const m = String(dataUrl).match(/^data:([^;]+);base64,(.+)$/);
    if (!m) return null;
    const bin = atob(m[2]);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return { mime: m[1], bytes };
  }

  function bufferToHex(buf) {
    return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
  }

  async function sha256(bytes) {
    const hash = await crypto.subtle.digest('SHA-256', bytes);
    return bufferToHex(hash);
  }

  // Minimal MD5 for file intelligence (public domain style compact impl)
  function md5(bytes) {
    function cmn(q, a, b, x, s, t) {
      a = (a + q + x + t) | 0;
      return (((a << s) | (a >>> (32 - s))) + b) | 0;
    }
    function ff(a, b, c, d, x, s, t) { return cmn((b & c) | (~b & d), a, b, x, s, t); }
    function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & ~d), a, b, x, s, t); }
    function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
    function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | ~d), a, b, x, s, t); }

    const len = bytes.length;
    const nBlocks = ((len + 8) >>> 6) + 1;
    const bl = new Array(nBlocks * 16).fill(0);
    for (let i = 0; i < len; i++) bl[i >> 2] |= bytes[i] << ((i % 4) * 8);
    bl[len >> 2] |= 0x80 << ((len % 4) * 8);
    bl[nBlocks * 16 - 2] = len * 8;

    let a0 = 1732584193, b0 = -271733879, c0 = -1732584194, d0 = 271733878;
    for (let i = 0; i < bl.length; i += 16) {
      let a = a0, b = b0, c = c0, d = d0;
      a = ff(a, b, c, d, bl[i], 7, -680876936); d = ff(d, a, b, c, bl[i+1], 12, -389564586);
      c = ff(c, d, a, b, bl[i+2], 17, 606105819); b = ff(b, c, d, a, bl[i+3], 22, -1044525330);
      a = ff(a, b, c, d, bl[i+4], 7, -176418897); d = ff(d, a, b, c, bl[i+5], 12, 1200080426);
      c = ff(c, d, a, b, bl[i+6], 17, -1473231341); b = ff(b, c, d, a, bl[i+7], 22, -45705983);
      a = ff(a, b, c, d, bl[i+8], 7, 1770035416); d = ff(d, a, b, c, bl[i+9], 12, -1958414417);
      c = ff(c, d, a, b, bl[i+10], 17, -42063); b = ff(b, c, d, a, bl[i+11], 22, -1990404162);
      a = ff(a, b, c, d, bl[i+12], 7, 1804603682); d = ff(d, a, b, c, bl[i+13], 12, -40341101);
      c = ff(c, d, a, b, bl[i+14], 17, -1502002290); b = ff(b, c, d, a, bl[i+15], 22, 1236535329);
      a = gg(a, b, c, d, bl[i+1], 5, -165796510); d = gg(d, a, b, c, bl[i+6], 9, -1069501632);
      c = gg(c, d, a, b, bl[i+11], 14, 643717713); b = gg(b, c, d, a, bl[i], 20, -373897302);
      a = gg(a, b, c, d, bl[i+5], 5, -701558691); d = gg(d, a, b, c, bl[i+10], 9, 38016083);
      c = gg(c, d, a, b, bl[i+15], 14, -660478335); b = gg(b, c, d, a, bl[i+4], 20, -405537848);
      a = gg(a, b, c, d, bl[i+9], 5, 568446438); d = gg(d, a, b, c, bl[i+14], 9, -1019803690);
      c = gg(c, d, a, b, bl[i+3], 14, -187363961); b = gg(b, c, d, a, bl[i+8], 20, 1163531501);
      a = gg(a, b, c, d, bl[i+13], 5, -1444681467); d = gg(d, a, b, c, bl[i+2], 9, -51403784);
      c = gg(c, d, a, b, bl[i+7], 14, 1735328473); b = gg(b, c, d, a, bl[i+12], 20, -1926607734);
      a = hh(a, b, c, d, bl[i+5], 4, -378558); d = hh(d, a, b, c, bl[i+8], 11, -2022574463);
      c = hh(c, d, a, b, bl[i+11], 16, 1839030562); b = hh(b, c, d, a, bl[i+14], 23, -35309556);
      a = hh(a, b, c, d, bl[i+1], 4, -1530992060); d = hh(d, a, b, c, bl[i+4], 11, 1272893353);
      c = hh(c, d, a, b, bl[i+7], 16, -155497632); b = hh(b, c, d, a, bl[i+10], 23, -1094730640);
      a = hh(a, b, c, d, bl[i+13], 4, 681279174); d = hh(d, a, b, c, bl[i], 11, -358537222);
      c = hh(c, d, a, b, bl[i+3], 16, -722521979); b = hh(b, c, d, a, bl[i+6], 23, 76029189);
      a = hh(a, b, c, d, bl[i+9], 4, -640364487); d = hh(d, a, b, c, bl[i+12], 11, -421815835);
      c = hh(c, d, a, b, bl[i+15], 16, 530742520); b = hh(b, c, d, a, bl[i+2], 23, -995338651);
      a = ii(a, b, c, d, bl[i], 6, -198630844); d = ii(d, a, b, c, bl[i+7], 10, 1126891415);
      c = ii(c, d, a, b, bl[i+14], 15, -1416354905); b = ii(b, c, d, a, bl[i+5], 21, -57434055);
      a = ii(a, b, c, d, bl[i+12], 6, 1700485571); d = ii(d, a, b, c, bl[i+3], 10, -1894986606);
      c = ii(c, d, a, b, bl[i+10], 15, -1051523); b = ii(b, c, d, a, bl[i+1], 21, -2054922799);
      a = ii(a, b, c, d, bl[i+8], 6, 1873313359); d = ii(d, a, b, c, bl[i+15], 10, -30611744);
      c = ii(c, d, a, b, bl[i+6], 15, -1560198380); b = ii(b, c, d, a, bl[i+13], 21, 1309151649);
      a = ii(a, b, c, d, bl[i+4], 6, -145523070); d = ii(d, a, b, c, bl[i+11], 10, -1120210379);
      c = ii(c, d, a, b, bl[i+2], 15, 718787259); b = ii(b, c, d, a, bl[i+9], 21, -343485551);
      a0 = (a0 + a) | 0; b0 = (b0 + b) | 0; c0 = (c0 + c) | 0; d0 = (d0 + d) | 0;
    }
    function toHex(n) {
      let s = '';
      for (let i = 0; i < 4; i++) s += ((n >> (i * 8)) & 0xff).toString(16).padStart(2, '0');
      return s;
    }
    return toHex(a0) + toHex(b0) + toHex(c0) + toHex(d0);
  }

  /** Basic JPEG EXIF via APP1 / TIFF IFD0 (GPS + orientation + make/model/datetime) */
  function parseJPEGExif(bytes) {
    const out = {};
    if (bytes[0] !== 0xFF || bytes[1] !== 0xD8) return out;
    let offset = 2;
    while (offset < bytes.length - 4) {
      if (bytes[offset] !== 0xFF) break;
      const marker = bytes[offset + 1];
      const size = (bytes[offset + 2] << 8) | bytes[offset + 3];
      if (marker === 0xE1) {
        // EXIF
        const start = offset + 4;
        if (bytes[start] === 0x45 && bytes[start + 1] === 0x78) { // Exif
          const tiff = start + 6;
          const le = bytes[tiff] === 0x49;
          const u16 = (o) => le ? (bytes[o] | (bytes[o + 1] << 8)) : ((bytes[o] << 8) | bytes[o + 1]);
          const u32 = (o) => le
            ? (bytes[o] | (bytes[o + 1] << 8) | (bytes[o + 2] << 16) | (bytes[o + 3] << 24))
            : ((bytes[o] << 24) | (bytes[o + 1] << 16) | (bytes[o + 2] << 8) | bytes[o + 3]);
          const ifd0 = tiff + u32(tiff + 4);
          const entries = u16(ifd0);
          for (let i = 0; i < entries; i++) {
            const e = ifd0 + 2 + i * 12;
            const tag = u16(e);
            const type = u16(e + 2);
            const count = u32(e + 4);
            const valOff = e + 8;
            const valueOffset = (type === 2 && count > 4) ? tiff + u32(valOff) : valOff;
            if (tag === 0x010F || tag === 0x0110) { // Make / Model
              let s = '';
              for (let j = 0; j < Math.min(count - 1, 64); j++) {
                const c = bytes[valueOffset + j];
                if (!c) break;
                s += String.fromCharCode(c);
              }
              if (tag === 0x010F) out.make = s;
              else out.model = s;
            }
            if (tag === 0x0132) { // DateTime
              let s = '';
              for (let j = 0; j < Math.min(count - 1, 32); j++) {
                const c = bytes[valueOffset + j];
                if (!c) break;
                s += String.fromCharCode(c);
              }
              out.dateTime = s;
            }
            if (tag === 0x0112) out.orientation = u16(valOff);
            if (tag === 0x8825) { // GPS IFD pointer
              const gpsIfd = tiff + u32(valOff);
              try {
                const ge = u16(gpsIfd);
                let latRef = 'N', lonRef = 'E', lat, lon;
                for (let g = 0; g < ge; g++) {
                  const ge2 = gpsIfd + 2 + g * 12;
                  const gtag = u16(ge2);
                  if (gtag === 1) latRef = String.fromCharCode(bytes[ge2 + 8]);
                  if (gtag === 3) lonRef = String.fromCharCode(bytes[ge2 + 8]);
                  if (gtag === 2 || gtag === 4) {
                    const off = tiff + u32(ge2 + 8);
                    const num = (i, o) => u32(o + i * 8) / (u32(o + i * 8 + 4) || 1);
                    const deg = num(0, off) + num(1, off) / 60 + num(2, off) / 3600;
                    if (gtag === 2) lat = deg;
                    else lon = deg;
                  }
                }
                if (lat != null && lon != null) {
                  if (latRef === 'S') lat = -lat;
                  if (lonRef === 'W') lon = -lon;
                  out.gps = { lat, lon };
                }
              } catch (_) {}
            }
          }
        }
        break;
      }
      if (marker === 0xDA) break; // SOS
      offset += 2 + size;
    }
    return out;
  }

  function loadImage(dataUrl) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = dataUrl;
    });
  }

  /** Average hash 8x8 → 64-bit hex */
  async function averageHash(dataUrl) {
    const img = await loadImage(dataUrl);
    const c = document.createElement('canvas');
    c.width = 8; c.height = 8;
    const ctx = c.getContext('2d');
    ctx.drawImage(img, 0, 0, 8, 8);
    const data = ctx.getImageData(0, 0, 8, 8).data;
    const grays = [];
    for (let i = 0; i < 64; i++) {
      const o = i * 4;
      grays.push((data[o] + data[o + 1] + data[o + 2]) / 3);
    }
    const avg = grays.reduce((a, b) => a + b, 0) / 64;
    let bits = '';
    grays.forEach(g => { bits += g >= avg ? '1' : '0'; });
    let hex = '';
    for (let i = 0; i < 64; i += 4) {
      hex += parseInt(bits.slice(i, i + 4), 2).toString(16);
    }
    return hex;
  }

  async function analyzeImageDataUrl(dataUrl) {
    const parsed = dataUrlToBytes(dataUrl);
    if (!parsed) throw new Error('Invalid data URL');
    const { mime, bytes } = parsed;
    const results = [];
    const meta = { mime, size: bytes.length };

    results.push({
      type: 'document', value: mime, label: 'MIME ' + mime,
      relation: 'file_mime', status: 'confirmed',
      finding: 'MIME type: ' + mime, sourceUrl: ''
    });
    results.push({
      type: 'document', value: String(bytes.length), label: formatSize(bytes.length),
      relation: 'file_size', status: 'confirmed',
      finding: 'Size: ' + formatSize(bytes.length) + ' (' + bytes.length + ' bytes)', sourceUrl: ''
    });

    const sha = await sha256(bytes);
    meta.sha256 = sha;
    results.push({
      type: 'hash', value: sha, label: 'SHA-256',
      relation: 'file_hash', status: 'confirmed',
      finding: 'SHA-256: ' + sha, sourceUrl: ''
    });
    results.push({
      type: 'url',
      value: 'https://www.virustotal.com/gui/search/' + sha,
      label: 'VirusTotal (hash)',
      relation: 'related_to', status: 'unknown',
      finding: 'Public hash lookup (no file uploaded by Nexus)', sourceUrl: 'https://www.virustotal.com/gui/search/' + sha
    });

    const md = md5(bytes);
    meta.md5 = md;
    results.push({
      type: 'hash', value: md, label: 'MD5',
      relation: 'file_hash', status: 'confirmed',
      finding: 'MD5: ' + md, sourceUrl: ''
    });

    try {
      const img = await loadImage(dataUrl);
      meta.width = img.naturalWidth;
      meta.height = img.naturalHeight;
      results.push({
        type: 'document', value: img.naturalWidth + 'x' + img.naturalHeight,
        label: img.naturalWidth + '×' + img.naturalHeight,
        relation: 'dimensions', status: 'confirmed',
        finding: 'Dimensions: ' + img.naturalWidth + '×' + img.naturalHeight, sourceUrl: ''
      });
      const ah = await averageHash(dataUrl);
      meta.ahash = ah;
      results.push({
        type: 'hash', value: ah, label: 'aHash',
        relation: 'perceptual_hash', status: 'confirmed',
        finding: 'Perceptual aHash: ' + ah, sourceUrl: ''
      });
    } catch (e) {
      results.push({ type: 'document', value: 'img-error', label: 'Image decode failed', relation: 'related_to', status: 'unknown', finding: e.message, sourceUrl: '' });
    }

    // EXIF
    try {
      const exif = parseJPEGExif(bytes);
      meta.exif = exif;
      if (exif.make || exif.model) {
        results.push({
          type: 'document', value: [exif.make, exif.model].filter(Boolean).join(' '),
          label: [exif.make, exif.model].filter(Boolean).join(' '),
          relation: 'device', status: 'confirmed',
          finding: 'EXIF camera: ' + [exif.make, exif.model].filter(Boolean).join(' '), sourceUrl: ''
        });
      }
      if (exif.dateTime) {
        results.push({
          type: 'timestamp', value: exif.dateTime, label: exif.dateTime,
          relation: 'captured_at', status: 'confirmed',
          finding: 'EXIF DateTime: ' + exif.dateTime, sourceUrl: ''
        });
      }
      if (exif.gps) {
        const g = exif.gps.lat + ',' + exif.gps.lon;
        results.push({
          type: 'geolocation', value: g, label: g,
          relation: 'located_in', status: 'confirmed',
          finding: 'EXIF GPS: ' + g, sourceUrl: 'https://www.google.com/maps?q=' + encodeURIComponent(g)
        });
      }
      if (!exif.make && !exif.dateTime && !exif.gps) {
        results.push({
          type: 'document', value: 'no-exif', label: 'No EXIF',
          relation: 'related_to', status: 'confirmed',
          finding: 'No public EXIF tags found (or stripped)', sourceUrl: ''
        });
      }
    } catch (e) {
      results.push({ type: 'document', value: 'exif-error', label: 'EXIF parse error', relation: 'related_to', status: 'unknown', finding: e.message, sourceUrl: '' });
    }

    // OCR not available without external model — honest note
    results.push({
      type: 'document', value: 'ocr-unavailable', label: 'OCR n/a',
      relation: 'related_to', status: 'unknown',
      finding: 'OCR requires optional OCR engine (not bundled). Text not extracted.', sourceUrl: ''
    });

    // Reverse image search — user opens manually (no upload from us)
    results.push({
      type: 'url', value: 'https://www.google.com/searchbyimage',
      label: 'Google reverse image',
      relation: 'related_to', status: 'unknown',
      finding: 'Open reverse image search manually (browser cannot upload file silently)', sourceUrl: 'https://www.google.com/searchbyimage'
    });

    return { ok: true, results, meta, source: 'media-local' };
  }

  async function analyzeFileBytes(bytes, mime, name) {
    const results = [];
    mime = mime || 'application/octet-stream';
    results.push({ type: 'document', value: mime, label: 'MIME ' + mime, relation: 'file_mime', status: 'confirmed', finding: 'MIME: ' + mime, sourceUrl: '' });
    results.push({ type: 'document', value: String(bytes.length), label: formatSize(bytes.length), relation: 'file_size', status: 'confirmed', finding: 'Size: ' + formatSize(bytes.length), sourceUrl: '' });
    if (name) results.push({ type: 'document', value: name, label: name, relation: 'file_name', status: 'confirmed', finding: 'Filename: ' + name, sourceUrl: '' });
    const sha = await sha256(bytes);
    results.push({ type: 'hash', value: sha, label: 'SHA-256', relation: 'file_hash', status: 'confirmed', finding: 'SHA-256: ' + sha, sourceUrl: '' });
    results.push({ type: 'hash', value: md5(bytes), label: 'MD5', relation: 'file_hash', status: 'confirmed', finding: 'MD5: ' + md5(bytes), sourceUrl: '' });
    results.push({
      type: 'url', value: 'https://www.virustotal.com/gui/search/' + sha,
      label: 'VirusTotal', relation: 'related_to', status: 'unknown',
      finding: 'Public hash search', sourceUrl: 'https://www.virustotal.com/gui/search/' + sha
    });
    return { ok: true, results, meta: { mime, size: bytes.length, sha256: sha, name }, source: 'file-local' };
  }

  function formatSize(n) {
    if (n < 1024) return n + ' B';
    if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
    return (n / (1024 * 1024)).toFixed(2) + ' MB';
  }

  global.NexusMediaIntel = {
    analyzeImageDataUrl,
    analyzeFileBytes,
    dataUrlToBytes,
    sha256,
    md5,
    parseJPEGExif,
    averageHash
  };
})(typeof window !== 'undefined' ? window : globalThis);
