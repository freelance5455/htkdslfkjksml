/**
 * Presence Engine — public profile/account existence checks.
 * Status: CONFIRMED | NOT_FOUND | BLOCKED | RATE_LIMITED | UNKNOWN | ERROR
 * Only CONFIRMED is graph-eligible.
 */
(function (global) {
  const NOT_FOUND_PATTERNS = [
    /user not found/i, /page not found/i, /doesn't exist/i, /does not exist/i,
    /no such user/i, /account suspended/i, /couldn't find/i, /could not find/i,
    /404/i, /not found/i, /nobody by that name/i, /this account doesn/i,
    /user does not exist/i, /profile not found/i, /sorry, this page/i
  ];

  function classifyHttp(status, bodyText, title) {
    if (status === 404 || status === 410) return 'NOT_FOUND';
    if (status === 429) return 'RATE_LIMITED';
    if (status === 401 || status === 403) return 'BLOCKED';
    if (status >= 500) return 'ERROR';
    if (status >= 200 && status < 400) {
      const text = (bodyText || '') + ' ' + (title || '');
      if (NOT_FOUND_PATTERNS.some(re => re.test(text))) return 'NOT_FOUND';
      return 'CONFIRMED';
    }
    return 'UNKNOWN';
  }

  async function fetchProbe(url, opts) {
    opts = opts || {};
    try {
      if (global.NexusRateLimit && !NexusRateLimit.canRequest()) {
        return { status: 'RATE_LIMITED', http: 0, error: 'rate_limit' };
      }
      if (global.NexusRateLimit) NexusRateLimit.consume();
      const r = await fetch(url, {
        method: opts.method || 'GET',
        redirect: 'follow',
        signal: AbortSignal.timeout(opts.timeout || 8000),
        headers: opts.headers || { Accept: 'text/html,application/json' }
      });
      let text = '';
      let title = '';
      try {
        const ct = r.headers.get('content-type') || '';
        if (ct.includes('json')) {
          text = await r.text();
        } else {
          text = (await r.text()).slice(0, 8000);
          const m = text.match(/<title[^>]*>([^<]+)<\/title>/i);
          title = m ? m[1].trim() : '';
        }
      } catch (_) {}
      const fingerprint = simpleHash(text.slice(0, 2000));
      const presence = classifyHttp(r.status, text, title);
      return {
        status: presence,
        http: r.status,
        finalUrl: r.url,
        title,
        fingerprint,
        redirected: r.url && url && r.url.split('?')[0] !== url.split('?')[0]
      };
    } catch (e) {
      if (e.name === 'TimeoutError') return { status: 'ERROR', error: 'timeout' };
      // CORS often throws — cannot verify from browser
      return { status: 'UNKNOWN', error: e.message || 'cors_or_network' };
    }
  }

  function simpleHash(s) {
    let h = 0;
    for (let i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
    return String(h);
  }

  /**
   * Anti false-positive: compare real candidate vs random nonexistent handle.
   * If responses look identical → NOT_FOUND (site is a stub).
   */
  async function validateProfile(urlBuilder, username) {
    const realUrl = urlBuilder(username);
    const fakeUser = 'zzqx9nonexistent' + Math.floor(Math.random() * 1e6);
    const fakeUrl = urlBuilder(fakeUser);

    const real = await fetchProbe(realUrl);
    if (real.status !== 'CONFIRMED') return { status: real.status, probe: real, url: realUrl };

    // Control check when possible (same-origin JSON APIs work; HTML may CORS)
    const fake = await fetchProbe(fakeUrl);
    if (fake.status === 'CONFIRMED' && real.fingerprint && fake.fingerprint && real.fingerprint === fake.fingerprint) {
      return {
        status: 'NOT_FOUND',
        probe: real,
        url: realUrl,
        reason: 'identical_response_to_nonexistent_user'
      };
    }
    if (fake.status === 'CONFIRMED' && real.title && fake.title && real.title === fake.title &&
        /not found|sign up|login|join/i.test(real.title)) {
      return { status: 'NOT_FOUND', probe: real, url: realUrl, reason: 'generic_title_for_all_users' };
    }
    return { status: 'CONFIRMED', probe: real, url: realUrl };
  }

  global.NexusPresence = {
    classifyHttp,
    fetchProbe,
    validateProfile,
    NOT_FOUND_PATTERNS
  };
})(typeof window !== 'undefined' ? window : globalThis);
