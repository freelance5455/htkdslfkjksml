/**
 * Maltego-style Transform Engine + Source Router
 * ENTITY → transforms → NexusSourceRegistry.route → connectors → evidence → graph
 * No fake results. API-key sources skip gracefully.
 */
(function (global) {
  const CATALOG = {
    domain: [
      { id: 'domain_to_ip', group: 'DNS', label: 'DNS → IP (A/AAAA)', depth: 1, connectors: ['dns'] },
      { id: 'domain_to_mx', group: 'DNS', label: 'DNS → MX', depth: 1, connectors: ['dns'] },
      { id: 'domain_to_ns', group: 'DNS', label: 'DNS → NS', depth: 1, connectors: ['dns'] },
      { id: 'domain_to_txt', group: 'DNS', label: 'DNS → TXT/SPF', depth: 1, connectors: ['dns'] },
      { id: 'domain_to_rdap', group: 'Registry', label: 'RDAP registration', depth: 1, connectors: ['rdap-domain'] },
      { id: 'domain_to_certs', group: 'TLS', label: 'Certificate Transparency', depth: 1, connectors: ['ct-certs'] },
      { id: 'domain_to_subdomains', group: 'TLS', label: 'Subdomains via CT', depth: 1, connectors: ['ct-certs'] },
      { id: 'full', group: 'Analysis', label: 'Full domain intelligence', depth: 1, connectors: ['dns', 'rdap-domain', 'ct-certs'] },
      { id: 'expand2', group: 'Analysis', label: 'Expand depth 2', depth: 2, connectors: [] }
    ],
    website: [
      { id: 'domain_to_ip', group: 'DNS', label: 'DNS → IP', depth: 1, connectors: ['dns'] },
      { id: 'domain_to_certs', group: 'TLS', label: 'Certificates', depth: 1, connectors: ['ct-certs'] }
    ],
    email: [
      { id: 'email_to_domain', group: 'Infrastructure', label: 'Domain + MX + SPF + DMARC', depth: 1, connectors: ['email-intelligence'] },
      { id: 'email_to_mx', group: 'Infrastructure', label: 'MX records', depth: 1, connectors: ['email-intelligence'] },
      { id: 'full', group: 'Analysis', label: 'Full email intelligence', depth: 1, connectors: [] },
      { id: 'expand2', group: 'Analysis', label: 'Expand depth 2', depth: 2, connectors: [] }
    ],
    ip: [
      { id: 'ip_to_geo_estimate', group: 'Network', label: 'Geo ESTIMATE / ASN / Org', depth: 1, connectors: ['ip-geo'] },
      { id: 'ip_to_rdap', group: 'Network', label: 'RDAP network', depth: 1, connectors: ['ip-rdap'] },
      { id: 'ip_to_asn', group: 'Network', label: 'ASN context', depth: 1, connectors: ['ip-geo', 'ip-rdap'] },
      { id: 'ip_to_ptr', group: 'DNS', label: 'Reverse DNS (PTR)', depth: 1, connectors: ['ip-ptr'] },
      { id: 'full', group: 'Analysis', label: 'Full IP intelligence', depth: 1, connectors: ['ip-geo', 'ip-rdap', 'ip-ptr', 'ip-ripe-stat'] },
      { id: 'expand2', group: 'Analysis', label: 'Expand depth 2', depth: 2, connectors: [] }
    ],
    username: [
      { id: 'username_to_profile', group: 'Presence', label: 'Verify public profiles', depth: 1, connectors: ['username-intelligence'] },
      { id: 'username_verify', group: 'Presence', label: 'Profile verification', depth: 1, connectors: ['username-intelligence'] },
      { id: 'full', group: 'Analysis', label: 'Full username check', depth: 1, connectors: [] }
    ],
    social: [
      { id: 'username_to_profile', group: 'Presence', label: 'Verify public profiles', depth: 1, connectors: ['username-intelligence'] }
    ],
    account: [
      { id: 'username_to_profile', group: 'Presence', label: 'Verify public profiles', depth: 1, connectors: ['username-intelligence'] }
    ],
    phone: [
      { id: 'phone_normalize', group: 'Numbering', label: 'Normalize / type / carrier estimate', depth: 1, connectors: ['phone-intelligence'] },
      { id: 'phone_to_carrier_estimate', group: 'Numbering', label: 'Carrier / range estimate', depth: 1, connectors: ['phone-intelligence'] },
      { id: 'phone_to_public_mentions', group: 'Presence', label: 'Public mentions (verified only)', depth: 1, connectors: ['phone-intelligence'] },
      { id: 'full', group: 'Analysis', label: 'Full phone intelligence', depth: 1, connectors: [] }
    ],
    url: [
      { id: 'url_to_domain', group: 'Parse', label: 'Host / domain / DNS', depth: 1, connectors: ['url-intelligence'] },
      { id: 'full', group: 'Analysis', label: 'Full URL intelligence', depth: 1, connectors: [] },
      { id: 'expand2', group: 'Analysis', label: 'Expand depth 2', depth: 2, connectors: [] }
    ],
    person: [
      { id: 'person_to_public_pages', group: 'Public records', label: 'Wikidata / Wikipedia / Open data', depth: 1, connectors: ['person-intelligence'] },
      { id: 'full', group: 'Analysis', label: 'Full person intelligence', depth: 1, connectors: [] }
    ],
    organization: [
      { id: 'org_to_domains', group: 'Analysis', label: 'Organization intelligence', depth: 1, connectors: [] }
    ],
    hash: [
      { id: 'hash_to_reputation', group: 'Reputation', label: 'Hash type / format', depth: 1, connectors: ['hash-intelligence'] }
    ],
    asn: [
      { id: 'ip_to_asn', group: 'Network', label: 'ASN context', depth: 1, connectors: [] }
    ],
    certificate: [
      { id: 'domain_to_certs', group: 'TLS', label: 'Certificate context', depth: 1, connectors: [] }
    ],
    geo_estimate: [
      { id: 'info', group: 'Analysis', label: 'Estimate metadata only', depth: 0, connectors: [] }
    ]
  };

  function forType(type) {
    const t = (type || 'other').toLowerCase();
    const list = (CATALOG[t] || [{ id: 'full', group: 'Analysis', label: 'Analyze entity', depth: 1, connectors: [] }]).slice();
    if (global.NexusSourceRegistry) {
      list.forEach(tr => {
        const routed = NexusSourceRegistry.route(tr.id, t, { diverse: true, limit: 50 });
        tr.sourceCount = routed.length;
        tr.browserSources = routed.filter(s => s.browserRunnable).length;
        tr.keySources = routed.filter(s => s.requiresApiKey).length;
      });
    }
    return list;
  }

  function getSourcesForTransform(transformId, entityType, opts) {
    if (global.NexusSourceRegistry) {
      return NexusSourceRegistry.route(transformId, entityType, opts || { diverse: true });
    }
    return [];
  }

  async function run(transform, node, options) {
    options = options || {};
    const onProgress = options.onProgress || function () {};
    const type = (transform && transform.type) || (node && node.type) || 'other';
    const value = (node && (node.value || node.label)) || '';
    if (!value) {
      return { root: { type: type, value: '' }, entities: [], relationships: [], sourceReport: [], errors: ['Empty value'], logs: [] };
    }

    if (transform && transform.depth === 0) {
      return {
        root: { type: type, value: value, label: value },
        entities: [], relationships: [],
        sourceReport: [{ source: 'local', ok: true, count: 0 }],
        errors: [], logs: [{ status: 'ok', detail: 'metadata only' }],
        analyzedAt: new Date().toISOString()
      };
    }

    const connectors = (transform && transform.connectors) || [];
    const depth = (transform && transform.depth) || 1;

    // Report routed registry sources (informational — does not invent data)
    if (global.NexusSourceRegistry && transform && transform.id) {
      const routed = NexusSourceRegistry.route(transform.id, type, { diverse: true, limit: 20 });
      onProgress({
        source: 'router',
        state: 'done',
        message: 'Routed ' + routed.length + ' registry sources (' +
          routed.filter(s => s.browserRunnable).length + ' browser-runnable, ' +
          routed.filter(s => s.requiresApiKey).length + ' need API key)'
      });
    }

    if (connectors.length && global.NexusSources) {
      onProgress({ source: 'transform', state: 'running', message: transform.label || transform.id });
      const allRaw = [];
      const reports = [];
      for (const name of connectors) {
        const c = NexusSources.get(name);
        if (!c) {
          reports.push({ source: name, ok: false, error: 'Connector not loaded', count: 0 });
          onProgress({ source: name, state: 'failed', message: 'not loaded' });
          continue;
        }
        if (c.requiresApiKey && global.NexusApiKeys && !NexusApiKeys.get(name)) {
          reports.push({ source: name, ok: false, error: 'API KEY REQUIRED', count: 0, skipped: true });
          onProgress({ source: name, state: 'skipped', message: 'API key required' });
          continue;
        }
        if (global.NexusApiKeys && !NexusApiKeys.isEnabled(name)) {
          reports.push({ source: name, ok: false, error: 'Disabled', count: 0, skipped: true });
          continue;
        }
        try {
          onProgress({ source: name, state: 'running', message: 'querying…' });
          const rep = await c.analyze(value, {
            depth: depth,
            demoMode: false,
            photoData: node && node.photoData,
            dataUrl: node && node.photoData
          });
          const results = (rep && rep.results) || [];
          results.forEach(r => { r.sourceName = rep.source || name; });
          allRaw.push.apply(allRaw, results);
          reports.push({
            source: rep.source || name,
            ok: !!(rep && rep.ok !== false),
            error: rep && rep.error,
            count: results.length,
            logs: (rep && rep.logs) || []
          });
          onProgress({
            source: name,
            state: rep && rep.ok === false ? 'failed' : 'done',
            message: results.length + ' results',
            count: results.length
          });
        } catch (e) {
          reports.push({ source: name, ok: false, error: e.message || String(e), count: 0 });
          onProgress({ source: name, state: 'failed', message: e.message || 'error' });
        }
      }

      let entities = allRaw;
      if (global.NexusEngine && typeof NexusEngine.dedupeResults === 'function') {
        entities = NexusEngine.dedupeResults(allRaw, { type: type, value: value });
      } else if (global.NexusEngine) {
        return NexusEngine.analyze(value, {
          type: type, depth: depth, forceRefresh: options.forceRefresh,
          onProgress: onProgress, demoMode: false
        });
      }

      if (global.NexusEngine && NexusEngine.isGraphableEntity) {
        entities = entities.filter(e => NexusEngine.isGraphableEntity(e));
      }

      const relationships = entities.map(e => ({
        targetType: e.type,
        targetValue: e.value,
        targetLabel: e.label,
        type: (global.NexusEngine && NexusEngine.REL_LABELS && NexusEngine.REL_LABELS[e.relation]) || e.relation || 'связан с',
        relationKey: e.relation,
        evidence: e.evidence,
        confidence: e.confidence
      }));

      return {
        root: { type: type, value: value, label: (node && node.label) || value },
        entities: entities,
        relationships: relationships,
        sourceReport: reports,
        errors: reports.filter(r => !r.ok && !r.skipped).map(r => r.source + ': ' + (r.error || 'failed')),
        logs: reports.flatMap(r => (r.logs || []).map(l => Object.assign({ source: r.source }, l))),
        analyzedAt: new Date().toISOString()
      };
    }

    if (!global.NexusEngine) {
      return {
        root: { type: type, value: value },
        entities: [], relationships: [],
        sourceReport: [], errors: ['Investigation engine not loaded'], logs: []
      };
    }
    return NexusEngine.analyze(value, {
      type: type,
      depth: depth,
      forceRefresh: options.forceRefresh,
      onProgress: onProgress,
      demoMode: false,
      photoData: node && node.photoData,
      dataUrl: node && node.photoData
    });
  }

  async function runAll(node, options) {
    options = options || {};
    const list = forType(node && node.type).filter(t => t.depth > 0 && t.id !== 'expand2');
    const merged = { entities: [], relationships: [], sourceReport: [], errors: [], logs: [] };
    for (const t of list) {
      if (options.abortCtrl && options.abortCtrl.aborted) break;
      const part = await run(Object.assign({}, t, { type: node.type }), node, options);
      (part.entities || []).forEach(e => merged.entities.push(e));
      (part.relationships || []).forEach(r => merged.relationships.push(r));
      (part.sourceReport || []).forEach(r => merged.sourceReport.push(r));
      (part.errors || []).forEach(e => merged.errors.push(e));
      (part.logs || []).forEach(l => merged.logs.push(l));
    }
    if (global.NexusEngine && NexusEngine.dedupeResults) {
      merged.entities = NexusEngine.dedupeResults(merged.entities, {
        type: node.type, value: node.value || node.label
      });
    }
    merged.root = { type: node.type, value: node.value || node.label, label: node.label };
    merged.analyzedAt = new Date().toISOString();
    return merged;
  }

  global.NexusTransforms = { forType, run, runAll, getSourcesForTransform, CATALOG };
})(typeof window !== 'undefined' ? window : globalThis);
