/** API key store — localStorage only, never embedded in HTML */
(function (global) {
  const KEY = 'nexus_api_keys_v1';
  const ENABLED = 'nexus_sources_enabled_v1';

  function loadKeys() {
    try { return JSON.parse(localStorage.getItem(KEY) || '{}'); } catch { return {}; }
  }
  function saveKeys(obj) {
    localStorage.setItem(KEY, JSON.stringify(obj || {}));
  }
  function loadEnabled() {
    try { return JSON.parse(localStorage.getItem(ENABLED) || '{}'); } catch { return {}; }
  }
  function saveEnabled(obj) {
    localStorage.setItem(ENABLED, JSON.stringify(obj || {}));
  }

  global.NexusApiKeys = {
    get(sourceName) {
      const k = loadKeys();
      return k[sourceName] || '';
    },
    set(sourceName, key) {
      const k = loadKeys();
      if (key) k[sourceName] = key;
      else delete k[sourceName];
      saveKeys(k);
    },
    isEnabled(sourceName) {
      const e = loadEnabled();
      if (e[sourceName] === false) return false;
      return true;
    },
    setEnabled(sourceName, on) {
      const e = loadEnabled();
      e[sourceName] = !!on;
      saveEnabled(e);
    },
    allKeys() { return loadKeys(); },
    allEnabled() { return loadEnabled(); }
  };
})(typeof window !== 'undefined' ? window : globalThis);
