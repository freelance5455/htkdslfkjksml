(function (global) {
  let requestCount = 0;
  let windowStart = Date.now();
  const WINDOW_MS = 60000;
  const MAX_PER_WINDOW = 80;
  const MAX_PER_ANALYSIS = 50;

  let analysisBudget = MAX_PER_ANALYSIS;

  global.NexusRateLimit = {
    resetAnalysisBudget(max) {
      analysisBudget = max != null ? max : MAX_PER_ANALYSIS;
    },
    canRequest() {
      const now = Date.now();
      if (now - windowStart > WINDOW_MS) {
        windowStart = now;
        requestCount = 0;
      }
      return requestCount < MAX_PER_WINDOW && analysisBudget > 0;
    },
    consume() {
      requestCount++;
      analysisBudget--;
    },
    remaining() {
      return { window: Math.max(0, MAX_PER_WINDOW - requestCount), analysis: analysisBudget };
    }
  };
})(typeof window !== 'undefined' ? window : globalThis);
