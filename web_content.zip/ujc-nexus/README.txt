UJC NEXUS - Linux + simple English tools OS (PWA)
DESIGNED BY UJC THE UNKNOWN JOINT COMMUNITY

Chalane ke liye: folder ko netlify.com/drop par daalein, link phone/PC ke browser mein kholein,
phir "Add to Home screen / Install app". APK ke liye link pwabuilder.com mein paste karein.

Shuru karein: type  tools   |   open website   |   hint
