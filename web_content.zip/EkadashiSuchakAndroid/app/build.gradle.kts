plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "in.rajke.facts.ekadashisuchak"
    compileSdk = 35
    defaultConfig {
        applicationId = "in.rajke.facts.ekadashisuchak"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
