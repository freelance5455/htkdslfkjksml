एकादशी सूचक Android App — Source Project

यह Android Studio project है, तैयार APK नहीं। इस वातावरण में Android SDK/Gradle build tools उपलब्ध न होने के कारण यहाँ APK compile नहीं हो पाया।

APK बनाने के लिए:
1. ZIP को extract करें।
2. Android Studio वाले computer पर EkadashiSuchakAndroid folder खोलें।
3. Gradle sync पूरा होने दें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK आमतौर पर app/build/outputs/apk/debug/app-debug.apk में मिलेगा।

App आपकी HTML file को फोन के अंदर WebView में खोलता है। तारीखें HTML में दी गई सूची के अनुसार हैं; पंचांग की तारीखें अपने स्थानीय पंडित/विश्वसनीय पंचांग से मिलाकर देखें।
