# معمارية التحديثات عن بُعد والربط الذكي المستقبلي (Remote Configuration & AI Update Architecture)

## 1. الفصل المعماري (Separation of Concerns)
تم تصميم تطبيق **"الحجة رتيل"** بفصل صارم بين 5 طبقات مستقلة:
1. **كود التطبيق (`APP CODE`)**: محرك العرض، قاعدة البيانات المحلية SQLite (`DatabaseHelper.java`)، مولد تقارير PDF (`PdfReportGenerator.java`)، وجسر المشاركة الأصلي (`AndroidBridge.java`).
2. **البيانات التجارية (`DATA`)**: سجلات الموديلات، الأوردرات اليومية، حركات المخزن، حركات القماش والموردين (`أخدت` / `اديت`)، البلاك ليست، وسجلات الأقسام المخصصة.
3. **التهيئة البنيوية (`CONFIGURATION`)**: تعريفات الأقسام (`sections` & `customSections`)، الحقول المخصصة (`sectionCustomFields`)، حالات الأوردر (`orderStatuses`)، أنواع الحركة (`transactionTypes`)، وكروت الملخص اليومي (`dashboardCards`).
4. **التخصيص البصري والنصي (`CUSTOMIZATION`)**: اسم التطبيق، العنوان الفرعي، صورة الشاشة الرئيسية، الشعار، الألوان، حجم الخط، وأسماء جميع الأزرار والعناوين.
5. **طبقة تحديث الإعدادات عن بُعد (`REMOTE UPDATE CONFIGURATION`)**: تستقبل ملف JSON معياري محدّد الإصدار (`configVersion`) من نقطة اتصال قابلة للتخصيص (`remoteEndpoint`) وتتحقق من سلامته أمنياً قبل تطبيقه.

## 2. الأمان والحماية (`SECURITY`)
- لا يسمح النظام أبداً بتنفيذ أي كود برمجي خارجي (`No Arbitrary Remote Code Execution`).
- تقوم طبقة التحقق (`RemoteConfigUpdater.java` و `validateSafeRemoteConfig`) برفض أي حزمة تحتوي على وسوم `<script>` أو `javascript:` أو `eval(`.
- يقتصر التحديث عن بُعد على تعديل أو إضافة الأقسام، الحقول، المسميات، الحالات، والألوان المدعومة رسمياً.

## 3. نموذج JSON القياسي للتحديث الذكي (Configuration Update Schema)
عندما يطلب المستخدم مستقبلاً مثلاً: *"أضف قسماً للمصاريف"*، يقوم خادم التحديث بإصدار حزمة JSON التالية ليقرأها التطبيق ويطبقها فوراً بدون الحاجة لإعادة بناء ملف APK:

```json
{
  "configVersion": "1.1.0",
  "addCustomSection": {
    "name": "قسم المصاريف",
    "icon": "💸",
    "fields": [
      { "name": "بند المصروف", "type": "text" },
      { "name": "المبلغ", "type": "currency" },
      { "name": "التاريخ", "type": "date" },
      { "name": "ملاحظات", "type": "notes" }
    ]
  }
}
```
