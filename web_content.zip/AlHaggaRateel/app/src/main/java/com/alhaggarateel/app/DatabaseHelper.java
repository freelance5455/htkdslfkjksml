package com.alhaggarateel.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Local Offline-First SQLite Database Helper for "الحجة رتيل".
 * Stores both the full structured state and relational tables for Models,
 * Orders, Stock Movements, Fabric Movements, Blacklist, and Custom Sections.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "al_hagga_rateel.db";
    private static final int DB_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS app_state_store (" +
                "id INTEGER PRIMARY KEY CHECK (id = 1), " +
                "state_json TEXT NOT NULL, " +
                "updated_at TEXT)");

        db.execSQL("CREATE TABLE IF NOT EXISTS models_table (" +
                "id TEXT PRIMARY KEY, " +
                "name TEXT NOT NULL, " +
                "initial_stock REAL DEFAULT 0, " +
                "notes TEXT, " +
                "created_at TEXT, " +
                "custom_json TEXT)");

        db.execSQL("CREATE TABLE IF NOT EXISTS orders_table (" +
                "id TEXT PRIMARY KEY, " +
                "order_number TEXT, " +
                "date TEXT, " +
                "customer_name TEXT, " +
                "phone TEXT, " +
                "model_id TEXT, " +
                "model_name TEXT, " +
                "quantity REAL DEFAULT 0, " +
                "order_value REAL DEFAULT 0, " +
                "returned_qty REAL DEFAULT 0, " +
                "status TEXT, " +
                "notes TEXT, " +
                "custom_json TEXT)");

        db.execSQL("CREATE TABLE IF NOT EXISTS stock_transactions_table (" +
                "id TEXT PRIMARY KEY, " +
                "model_id TEXT, " +
                "model_name TEXT, " +
                "type TEXT, " +
                "quantity REAL DEFAULT 0, " +
                "date TEXT, " +
                "notes TEXT)");

        db.execSQL("CREATE TABLE IF NOT EXISTS fabric_transactions_table (" +
                "id TEXT PRIMARY KEY, " +
                "date TEXT, " +
                "person_name TEXT, " +
                "type TEXT, " +
                "quantity REAL DEFAULT 0, " +
                "model_id TEXT, " +
                "model_name TEXT, " +
                "affects_inventory INTEGER DEFAULT 0, " +
                "notes TEXT, " +
                "custom_json TEXT)");

        db.execSQL("CREATE TABLE IF NOT EXISTS blacklist_table (" +
                "id TEXT PRIMARY KEY, " +
                "customer_name TEXT, " +
                "phone TEXT, " +
                "reason TEXT, " +
                "orders_count INTEGER DEFAULT 0, " +
                "returns_count INTEGER DEFAULT 0, " +
                "date_added TEXT, " +
                "notes TEXT, " +
                "custom_json TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }

    public synchronized void saveFullState(String stateJson) {
        if (stateJson == null || stateJson.isEmpty()) return;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues cv = new ContentValues();
            cv.put("id", 1);
            cv.put("state_json", EnglishNumeralUtil.toEnglishDigits(stateJson));
            cv.put("updated_at", String.valueOf(System.currentTimeMillis()));
            db.insertWithOnConflict("app_state_store", null, cv, SQLiteDatabase.CONFLICT_REPLACE);

            // Mirror relational tables for SQL querying & inspection
            JSONObject root = new JSONObject(stateJson);
            JSONObject data = root.optJSONObject("data");
            if (data != null) {
                syncModels(db, data.optJSONArray("models"));
                syncOrders(db, data.optJSONArray("orders"));
                syncStockTx(db, data.optJSONArray("stockTransactions"));
                syncFabricTx(db, data.optJSONArray("fabricTransactions"));
                syncBlacklist(db, data.optJSONArray("blacklist"));
            }
            db.setTransactionSuccessful();
        } catch (Exception ignored) {
        } finally {
            db.endTransaction();
        }
    }

    private void syncModels(SQLiteDatabase db, JSONArray arr) {
        db.delete("models_table", null, null);
        if (arr == null) return;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            ContentValues cv = new ContentValues();
            cv.put("id", o.optString("id"));
            cv.put("name", o.optString("name"));
            cv.put("initial_stock", o.optDouble("initialStock", 0));
            cv.put("notes", o.optString("notes"));
            cv.put("created_at", o.optString("createdAt"));
            JSONObject custom = o.optJSONObject("customData");
            cv.put("custom_json", custom != null ? custom.toString() : "{}");
            db.insertWithOnConflict("models_table", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
        }
    }

    private void syncOrders(SQLiteDatabase db, JSONArray arr) {
        db.delete("orders_table", null, null);
        if (arr == null) return;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            ContentValues cv = new ContentValues();
            cv.put("id", o.optString("id"));
            cv.put("order_number", o.optString("orderNumber"));
            cv.put("date", o.optString("date"));
            cv.put("customer_name", o.optString("customerName"));
            cv.put("phone", o.optString("phone"));
            cv.put("model_id", o.optString("modelId"));
            cv.put("model_name", o.optString("modelName"));
            cv.put("quantity", o.optDouble("quantity", 0));
            cv.put("order_value", o.optDouble("orderValue", 0));
            cv.put("returned_qty", o.optDouble("returnedQty", 0));
            cv.put("status", o.optString("status"));
            cv.put("notes", o.optString("notes"));
            JSONObject custom = o.optJSONObject("customData");
            cv.put("custom_json", custom != null ? custom.toString() : "{}");
            db.insertWithOnConflict("orders_table", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
        }
    }

    private void syncStockTx(SQLiteDatabase db, JSONArray arr) {
        db.delete("stock_transactions_table", null, null);
        if (arr == null) return;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            ContentValues cv = new ContentValues();
            cv.put("id", o.optString("id"));
            cv.put("model_id", o.optString("modelId"));
            cv.put("model_name", o.optString("modelName"));
            cv.put("type", o.optString("type"));
            cv.put("quantity", o.optDouble("quantity", 0));
            cv.put("date", o.optString("date"));
            cv.put("notes", o.optString("notes"));
            db.insertWithOnConflict("stock_transactions_table", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
        }
    }

    private void syncFabricTx(SQLiteDatabase db, JSONArray arr) {
        db.delete("fabric_transactions_table", null, null);
        if (arr == null) return;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            ContentValues cv = new ContentValues();
            cv.put("id", o.optString("id"));
            cv.put("date", o.optString("date"));
            cv.put("person_name", o.optString("personName"));
            cv.put("type", o.optString("type"));
            cv.put("quantity", o.optDouble("quantity", 0));
            cv.put("model_id", o.optString("modelId"));
            cv.put("model_name", o.optString("modelName"));
            cv.put("affects_inventory", o.optBoolean("affectsInventory", false) ? 1 : 0);
            cv.put("notes", o.optString("notes"));
            JSONObject custom = o.optJSONObject("customData");
            cv.put("custom_json", custom != null ? custom.toString() : "{}");
            db.insertWithOnConflict("fabric_transactions_table", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
        }
    }

    private void syncBlacklist(SQLiteDatabase db, JSONArray arr) {
        db.delete("blacklist_table", null, null);
        if (arr == null) return;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            ContentValues cv = new ContentValues();
            cv.put("id", o.optString("id"));
            cv.put("customer_name", o.optString("customerName"));
            cv.put("phone", o.optString("phone"));
            cv.put("reason", o.optString("reason"));
            cv.put("orders_count", o.optInt("ordersCount", 0));
            cv.put("returns_count", o.optInt("returnsCount", 0));
            cv.put("date_added", o.optString("dateAdded"));
            cv.put("notes", o.optString("notes"));
            JSONObject custom = o.optJSONObject("customData");
            cv.put("custom_json", custom != null ? custom.toString() : "{}");
            db.insertWithOnConflict("blacklist_table", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
        }
    }

    public synchronized String loadFullState() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery("SELECT state_json FROM app_state_store WHERE id = 1", null);
            if (cursor != null && cursor.moveToFirst()) {
                return EnglishNumeralUtil.toEnglishDigits(cursor.getString(0));
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return "";
    }
}
