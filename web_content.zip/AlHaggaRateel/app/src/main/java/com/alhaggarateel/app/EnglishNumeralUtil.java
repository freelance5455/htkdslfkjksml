package com.alhaggarateel.app;

/**
 * Enforces English numerals (0 1 2 3 4 5 6 7 8 9) across all strings, reports, PDFs, and database records.
 */
public final class EnglishNumeralUtil {

    private EnglishNumeralUtil() {}

    public static String toEnglishDigits(String input) {
        if (input == null || input.isEmpty()) return "";
        StringBuilder sb = new StringBuilder(input.length());
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c >= '٠' && c <= '٩') {
                sb.append((char) ('0' + (c - '٠')));
            } else if (c >= '۰' && c <= '۹') {
                sb.append((char) ('0' + (c - '۰')));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
