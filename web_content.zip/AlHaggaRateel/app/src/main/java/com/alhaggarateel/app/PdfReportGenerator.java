package com.alhaggarateel.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Generates clean Arabic RTL PDF reports locally using Android's native PdfDocument API.
 */
public class PdfReportGenerator {

    public static File createReportPdf(Context context, String reportTitle, String reportBody) throws IOException {
        String cleanTitle = EnglishNumeralUtil.toEnglishDigits(reportTitle != null ? reportTitle : "تقرير الحجة رتيل");
        String cleanBody = EnglishNumeralUtil.toEnglishDigits(reportBody != null ? reportBody : "");

        PdfDocument pdfDocument = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
        PdfDocument.Page page = pdfDocument.startPage(pageInfo);
        Canvas canvas = page.getCanvas();

        Paint bgPaint = new Paint();
        bgPaint.setColor(Color.parseColor("#FAF7F2"));
        canvas.drawRect(0, 0, 595, 842, bgPaint);

        Paint headerPaint = new Paint();
        headerPaint.setColor(Color.parseColor("#6D28D9"));
        canvas.drawRect(24, 24, 571, 115, headerPaint);

        Paint titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        titlePaint.setColor(Color.WHITE);
        titlePaint.setTextSize(24f);
        titlePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        titlePaint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("الحجة رتيل — دفتر المخزن والأوردرات", 297f, 62f, titlePaint);

        Paint subPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        subPaint.setColor(Color.parseColor("#FDE68A"));
        subPaint.setTextSize(15f);
        subPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        subPaint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText(cleanTitle, 297f, 95f, subPaint);

        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.parseColor("#1F2937"));
        textPaint.setTextSize(14f);
        textPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        textPaint.setTextAlign(Paint.Align.RIGHT);

        String[] lines = cleanBody.split("\n");
        float y = 155f;
        for (String line : lines) {
            if (y > 790f) {
                pdfDocument.finishPage(page);
                pageInfo = new PdfDocument.PageInfo.Builder(595, 842, pdfDocument.getPages().size() + 1).create();
                page = pdfDocument.startPage(pageInfo);
                canvas = page.getCanvas();
                canvas.drawRect(0, 0, 595, 842, bgPaint);
                y = 50f;
            }
            canvas.drawText(EnglishNumeralUtil.toEnglishDigits(line), 555f, y, textPaint);
            y += 26f;
        }

        pdfDocument.finishPage(page);

        File exportDir = new File(context.getCacheDir(), "shared_exports");
        if (!exportDir.exists()) {
            exportDir.mkdirs();
        }
        File outFile = new File(exportDir, "AlHagga_Rateel_Report.pdf");
        try (FileOutputStream fos = new FileOutputStream(outFile)) {
            pdfDocument.writeTo(fos);
        } finally {
            pdfDocument.close();
        }
        return outFile;
    }
}
