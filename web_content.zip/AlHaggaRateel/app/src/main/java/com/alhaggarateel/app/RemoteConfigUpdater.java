package com.alhaggarateel.app;

import org.json.JSONObject;

/**
 * Security & Schema Validator for Remote Configuration Updates.
 * Ensures remote configuration updates NEVER execute arbitrary code and only modify
 * safe configuration properties (labels, sections, fields, statuses, transaction types, UI settings).
 */
public class RemoteConfigUpdater {

    private static final String[] FORBIDDEN_TOKENS = new String[]{
            "<script", "javascript:", "onerror=", "onload=", "eval(", "Function("
    };

    public static boolean isSafeConfigurationPayload(String rawJson) {
        if (rawJson == null || rawJson.trim().isEmpty()) {
            return false;
        }
        String lower = rawJson.toLowerCase();
        for (String token : FORBIDDEN_TOKENS) {
            if (lower.contains(token.toLowerCase())) {
                return false;
            }
        }
        try {
            JSONObject obj = new JSONObject(rawJson);
            return obj.has("configVersion") || obj.has("customization") || obj.has("addCustomSection") || obj.has("labels");
        } catch (Exception e) {
            return false;
        }
    }
}
