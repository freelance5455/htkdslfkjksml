package com.alhaggarateel.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Native Android Bridge exposing SQLite persistence, Native Share Sheet (WhatsApp, Telegram,
 * Messenger, Email, Drive, Facebook, etc.), PDF generation, and Image summary sharing.
 */
public class AndroidBridge {

    private final Context context;
    private final DatabaseHelper dbHelper;

    public AndroidBridge(Context context, DatabaseHelper dbHelper) {
        this.context = context;
        this.dbHelper = dbHelper;
    }

    @JavascriptInterface
    public String loadAppState() {
        return dbHelper.loadFullState();
    }

    @JavascriptInterface
    public void saveAppState(String stateJson) {
        dbHelper.saveFullState(EnglishNumeralUtil.toEnglishDigits(stateJson));
    }

    @JavascriptInterface
    public void shareToWhatsApp(String text) {
        String cleanText = EnglishNumeralUtil.toEnglishDigits(text);
        Intent waIntent = new Intent(Intent.ACTION_SEND);
        waIntent.setType("text/plain");
        waIntent.putExtra(Intent.EXTRA_TEXT, cleanText);
        waIntent.setPackage("com.whatsapp");
        waIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        PackageManager pm = context.getPackageManager();
        if (waIntent.resolveActivity(pm) != null) {
            context.startActivity(waIntent);
        } else {
            // Fallback to normal Android share chooser if WhatsApp is not installed
            shareTextNative(cleanText);
        }
    }

    @JavascriptInterface
    public void shareTextNative(String text) {
        String cleanText = EnglishNumeralUtil.toEnglishDigits(text);
        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.setType("text/plain");
        sendIntent.putExtra(Intent.EXTRA_SUBJECT, "الحجة رتيل — ملخص وتقرير");
        sendIntent.putExtra(Intent.EXTRA_TEXT, cleanText);

        Intent chooser = Intent.createChooser(sendIntent, "مشاركة التقرير عبر...");
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(chooser);
    }

    @JavascriptInterface
    public void shareBase64Image(String dataUrl, String caption) {
        try {
            String base64Part = dataUrl.contains(",") ? dataUrl.substring(dataUrl.indexOf(",") + 1) : dataUrl;
            byte[] decoded = Base64.decode(base64Part, Base64.DEFAULT);

            File exportDir = new File(context.getCacheDir(), "shared_exports");
            if (!exportDir.exists()) exportDir.mkdirs();
            File imgFile = new File(exportDir, "AlHagga_Rateel_Summary.png");
            try (FileOutputStream fos = new FileOutputStream(imgFile)) {
                fos.write(decoded);
            }

            Uri uri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", imgFile);
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("image/png");
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
            if (caption != null && !caption.isEmpty()) {
                shareIntent.putExtra(Intent.EXTRA_TEXT, EnglishNumeralUtil.toEnglishDigits(caption));
            }
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);

            Intent chooser = Intent.createChooser(shareIntent, "مشاركة صورة الملخص...");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(chooser);
        } catch (Exception e) {
            shareTextNative(caption);
        }
    }

    @JavascriptInterface
    public void generateAndSharePdf(String reportTitle, String reportBody) {
        try {
            File pdfFile = PdfReportGenerator.createReportPdf(context, reportTitle, reportBody);
            Uri uri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", pdfFile);

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("application/pdf");
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, EnglishNumeralUtil.toEnglishDigits(reportTitle));
            shareIntent.putExtra(Intent.EXTRA_TEXT, EnglishNumeralUtil.toEnglishDigits(reportBody));
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);

            Intent chooser = Intent.createChooser(shareIntent, "مشاركة ملف PDF عبر...");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(chooser);
        } catch (Exception e) {
            shareTextNative(reportBody);
        }
    }

    @JavascriptInterface
    public void exportBackupJson(String filename, String jsonContent) {
        try {
            File exportDir = new File(context.getCacheDir(), "shared_exports");
            if (!exportDir.exists()) exportDir.mkdirs();
            File backupFile = new File(exportDir, filename != null ? filename : "AlHagga_Rateel_Backup.json");
            try (FileOutputStream fos = new FileOutputStream(backupFile)) {
                fos.write(EnglishNumeralUtil.toEnglishDigits(jsonContent).getBytes(StandardCharsets.UTF_8));
            }

            Uri uri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", backupFile);
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("application/json");
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);

            Intent chooser = Intent.createChooser(shareIntent, "حفظ أو مشاركة النسخة الاحتياطية...");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(chooser);
        } catch (Exception ignored) {
        }
    }
}
