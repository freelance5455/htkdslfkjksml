-keepclassmembers class com.alhaggarateel.app.AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
-keep class com.alhaggarateel.app.** { *; }
