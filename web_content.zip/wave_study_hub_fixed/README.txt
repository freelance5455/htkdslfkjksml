WAVE STUDY HUB — FREE NO-SIGN-IN STARTER

This ZIP is a self-contained website prototype with sample lessons and practice questions for Mathematics, Physics, Chemistry, Biology, English Reading, English Grammar, and SAT Preparation.

IMPORTANT:
- This is NOT an APK file and it is NOT a finished full Grade 12 curriculum.
- It does not require sign-in, a license, a paid service, or a server to open as a local HTML page.
- The lesson and quiz content is stored in index.html. It can work offline when opened locally in a browser.

ANDROID PHONE STEPS:
1. Download this ZIP to your phone.
2. Open the phone's Files / My Files app and find the ZIP in Downloads.
3. Tap the ZIP and choose Extract (or Extract here). Keep index.html and the folder together.
4. Open the extracted folder and tap index.html. Choose Chrome or another browser if asked.
5. Test a subject, read its lesson, and tap Practise questions.

If you want an APK:
- A separate HTML-to-APK builder or Android build environment must package index.html into an APK.
- The License/payment screen belongs to the builder service, not this ZIP. Do not pay or enter payment details just to test the HTML file.
- In a builder, choose an option like Local HTML / Import website / Load index.html and enable offline/local content if available. If the builder locks APK export behind payment, stop and use the local browser version until we identify a genuinely free alternative.

This starter includes short examples only. Add and verify more lessons against the Ethiopian curriculum before relying on it as a complete entrance-exam course.
