# Self Declaration Android App

## Features
- Mobile form for bride/groom and parent details
- Live application preview
- A4 PDF generation
- Share PDF to WhatsApp
- Print / Save PDF
- Works offline after installation

## Build
Open this folder in Android Studio and let Gradle sync.
Then choose:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

Minimum Android version: Android 6.0 (API 23)
Target SDK: 35
