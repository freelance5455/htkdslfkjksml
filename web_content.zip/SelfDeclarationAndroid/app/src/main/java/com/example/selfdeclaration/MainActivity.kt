package com.example.selfdeclaration

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.print.*
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.setBackgroundColor(Color.WHITE)
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidApp")
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun printApplication(html: String) {
            runOnUiThread { openPrintDialog(html) }
        }

        @JavascriptInterface
        fun generatePdf(html: String, shareToWhatsApp: Boolean) {
            runOnUiThread { createPdf(html, shareToWhatsApp) }
        }

        @JavascriptInterface
        fun toast(message: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show() }
        }
    }

    private fun openPrintDialog(html: String) {
        val printView = WebView(this)
        printView.settings.javaScriptEnabled = false
        printView.setBackgroundColor(Color.WHITE)
        printView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                val manager = getSystemService(PRINT_SERVICE) as PrintManager
                val adapter = printView.createPrintDocumentAdapter("Self-Declaration")
                val attrs = PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build()
                manager.print("Self-Declaration", adapter, attrs)
            }
        }
        printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
    }

    private fun createPdf(html: String, shareToWhatsApp: Boolean) {
        val pdfView = WebView(this)
        pdfView.settings.javaScriptEnabled = false
        pdfView.setBackgroundColor(Color.WHITE)
        val file = File(cacheDir, "Self-Declaration-${System.currentTimeMillis()}.pdf")

        pdfView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                Handler(Looper.getMainLooper()).postDelayed({
                    val adapter = pdfView.createPrintDocumentAdapter("Self-Declaration")
                    val attrs = PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .setResolution(PrintAttributes.Resolution("pdf", "pdf", 300, 300))
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                        .build()
                    adapter.onLayout(null, attrs, null, object : PrintDocumentAdapter.LayoutResultCallback() {
                        override fun onLayoutFinished(info: PrintDocumentInfo?, changed: Boolean) {
                            try {
                                val pfd = ParcelFileDescriptor.open(
                                    file,
                                    ParcelFileDescriptor.MODE_CREATE or
                                        ParcelFileDescriptor.MODE_READ_WRITE or
                                        ParcelFileDescriptor.MODE_TRUNCATE
                                )
                                adapter.onWrite(arrayOf(PageRange.ALL_PAGES), pfd, CancellationSignal(),
                                    object : PrintDocumentAdapter.WriteResultCallback() {
                                        override fun onWriteFinished(pages: Array<PageRange>) {
                                            pfd.close()
                                            pdfView.destroy()
                                            sharePdf(file, shareToWhatsApp)
                                        }
                                        override fun onWriteFailed(error: CharSequence?) {
                                            pfd.close(); pdfView.destroy()
                                            Toast.makeText(this@MainActivity, "PDF creation failed", Toast.LENGTH_LONG).show()
                                        }
                                    })
                            } catch (e: Exception) {
                                pdfView.destroy()
                                Toast.makeText(this@MainActivity, "PDF error: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                        override fun onLayoutFailed(error: CharSequence?) {
                            pdfView.destroy()
                            Toast.makeText(this@MainActivity, "PDF layout failed", Toast.LENGTH_LONG).show()
                        }
                    }, Bundle())
                }, 350)
            }
        }
        pdfView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
    }

    private fun sharePdf(file: File, whatsappOnly: Boolean) {
        val uri: Uri = FileProvider.getUriForFile(this, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (whatsappOnly) setPackage("com.whatsapp")
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            val fallback = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(fallback, "Share PDF"))
        }
    }
}
