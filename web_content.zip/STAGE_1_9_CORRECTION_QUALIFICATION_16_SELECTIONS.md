# CGD V117 — Socle 1.9 : correction des qualifications AGD

## Règle validée par l'utilisateur

Pour la Coupe Intergalactique des galaxies (AGD), les 24 sélections sont réparties en six groupes de quatre. À la fin des trois journées :

- les deux premiers de chaque groupe sont qualifiés (12 sélections) ;
- les quatre meilleurs troisièmes sont repêchés ;
- le tableau final commence avec 16 sélections en huitièmes de finale.

Le classement comparatif des troisièmes utilise les points, la différence de buts, les buts marqués, la puissance sportive puis l'identifiant en dernier recours.

## Nombre de rencontres

36 matchs de groupes + 8 huitièmes + 4 quarts + 2 demi-finales + 1 finale = **51 matchs**.

## Changements

- Suppression des barrages et des exemptions directes en quarts de finale.
- Conservation de la périodicité triennale, des 24 sélections, des six groupes et du calendrier AGD.
- Mise à jour du moteur, des contrôles, de l'interface, des tests et de la documentation.
- Les autres compétitions, notamment l'Intergalactique des Clubs (8 groupes, 16 qualifiés), ne sont pas modifiées.
