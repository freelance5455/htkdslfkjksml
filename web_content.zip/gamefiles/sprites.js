// Базовая система спрайтов (билборды)

class SpriteManager {
    constructor(scene) {
        this.scene = scene;
        this.sprites = [];
        this.textures = {};
        this.textureSizes = {};
        this.spriteTypes = {};
        this.loaded = false;
    }
    
    registerType(id, config) {
        this.spriteTypes[id] = {
            texture: config.texture,
            variants: config.variants || [],
            width: config.width || 1,
            height: config.height || 1,
            offsetY: config.offsetY || 0.5,
            pixelScale: config.pixelScale || 0.01,
            keepAspect: config.keepAspect !== undefined ? config.keepAspect : true,
            xSprite: config.xSprite || false,
            fixedAngle: config.fixedAngle || false,
            collision: config.collision || false,
            collisionWidth: config.collisionWidth || config.width || 1,
            collisionHeight: config.collisionHeight || config.height || 1,
            isDoor: config.isDoor || false,
            extraSprites: config.extraSprites || [],
            animated: config.animated || false,
            frameCount: config.frameCount || 1,
            frameDuration: config.frameDuration || 1.0,
            data: config.data || {}
        };
    }
    
    loadTextures(callback) {
        const loader = new THREE.TextureLoader();
        const texturePaths = [];
        
        for (let id in this.spriteTypes) {
            const type = this.spriteTypes[id];
            if (type.texture) {
                texturePaths.push({ key: id, path: type.texture });
            }
            if (type.variants && type.variants.length > 0) {
                for (let i = 0; i < type.variants.length; i++) {
                    const variantFile = type.variants[i];
                    const variantKey = id + '_' + (i + 1);
                    texturePaths.push({ key: variantKey, path: variantFile });
                }
            }
            if (type.extraSprites) {
                for (let extra of type.extraSprites) {
                    if (extra.texture) {
                        const extraKey = id + '_extra_' + type.extraSprites.indexOf(extra);
                        texturePaths.push({ key: extraKey, path: extra.texture });
                    }
                }
            }
        }
        
        let loadedCount = 0;
        const total = texturePaths.length;
        
        if (total === 0) {
            this.loaded = true;
            if (callback) callback();
            return;
        }
        
        for (let item of texturePaths) {
            const path = 'gamefiles/' + item.path;
            loader.load(
                path,
                (texture) => {
                    texture.wrapS = THREE.RepeatWrapping;
                    texture.wrapT = THREE.RepeatWrapping;
                    texture.repeat.set(1, 1);
                    texture.magFilter = THREE.NearestFilter;
                    texture.minFilter = THREE.NearestFilter;
                    texture.needsUpdate = true;
                    
                    this.textures[item.key] = texture;
                    
                    const img = texture.image;
                    if (img) {
                        this.textureSizes[item.key] = {
                            width: img.width,
                            height: img.height
                        };
                    }
                    
                    loadedCount++;
                    if (loadedCount === total) {
                        this.loaded = true;
                        if (callback) callback();
                    }
                },
                undefined,
                (error) => {
                    console.warn('Не удалось загрузить текстуру:', path, error);
                    loadedCount++;
                    if (loadedCount === total) {
                        this.loaded = true;
                        if (callback) callback();
                    }
                }
            );
        }
    }
    
    createSprite(col, row, typeId, extraData, textureId) {
        const type = this.spriteTypes[typeId];
        if (!type) {
            console.warn('Неизвестный тип спрайта:', typeId);
            return null;
        }
        
        let textureKey = typeId;
        if (textureId && type.variants && type.variants.length > 0) {
            const variantKey = typeId + '_' + textureId;
            if (this.textures[variantKey]) {
                textureKey = variantKey;
            } else {
                console.warn(`Вариант ${textureId} для типа ${typeId} не найден, используем основной`);
            }
        }
        
        const baseTexture = this.textures[textureKey];
        if (!baseTexture) {
            console.warn('Текстура не загружена для спрайта:', textureKey);
            return null;
        }
        
        if (type.isDoor) {
            return null;
        }
        
        const x = col + 0.5;
        const z = row + 0.5;
        
        let width = type.width;
        let height = type.height;
        
        if (type.keepAspect && this.textureSizes[textureKey]) {
            const texW = this.textureSizes[textureKey].width;
            const texH = this.textureSizes[textureKey].height;
            const scale = type.pixelScale || 0.01;
            let frameWidth = texW;
            if (type.animated && type.frameCount > 1) {
                frameWidth = texW / type.frameCount;
            }
            width = frameWidth * scale;
            height = texH * scale;
        }
        
        const y = type.offsetY !== undefined ? type.offsetY : height / 2;
        
        let texture = baseTexture;
        let isAnimated = type.animated && type.frameCount > 1;
        if (isAnimated) {
            texture = baseTexture.clone();
            texture.repeat.x = 1 / type.frameCount;
            texture.offset.x = 0;
            texture.needsUpdate = true;
        }
        
        const mainSprite = this.createSingleSprite(x, y, z, width, height, texture, type, true);
        mainSprite.userData.fixedAngle = type.fixedAngle || false;
        mainSprite.userData.animated = isAnimated;
        if (isAnimated) {
            mainSprite.userData.frameCount = type.frameCount;
            mainSprite.userData.frameDuration = type.frameDuration;
            mainSprite.userData.currentFrame = 0;
            mainSprite.userData.timer = 0;
            mainSprite.userData.texture = texture;
        }
        
        const allSprites = [mainSprite];
        
        if (type.xSprite) {
            const mesh2 = this.createSingleSprite(x, y, z, width, height, texture, type, false);
            mesh2.rotation.y = Math.PI / 2;
            mesh2.position.z += 0.001;
            mesh2.userData.fixedAngle = type.fixedAngle || false;
            mesh2.userData.animated = isAnimated;
            if (isAnimated) {
                mesh2.userData.frameCount = type.frameCount;
                mesh2.userData.frameDuration = type.frameDuration;
                mesh2.userData.currentFrame = 0;
                mesh2.userData.timer = 0;
                mesh2.userData.texture = texture;
            }
            allSprites.push(mesh2);
        }
        
        if (type.extraSprites && type.extraSprites.length > 0) {
            for (let i = 0; i < type.extraSprites.length; i++) {
                const extraConfig = type.extraSprites[i];
                const extraKey = `${typeId}_extra_${i}`;
                const extraTex = this.textures[extraKey];
                if (!extraTex) continue;
                
                let extraWidth = extraConfig.width;
                let extraHeight = extraConfig.height;
                if (extraConfig.keepAspect && this.textureSizes[extraKey]) {
                    const texW = this.textureSizes[extraKey].width;
                    const texH = this.textureSizes[extraKey].height;
                    const scale = extraConfig.pixelScale || 0.01;
                    extraWidth = texW * scale;
                    extraHeight = texH * scale;
                }
                const extraY = extraConfig.offsetY || extraHeight / 2;
                
                const extraMesh1 = this.createSingleSprite(x, extraY, z, extraWidth, extraHeight, extraTex, extraConfig, true);
                extraMesh1.userData.fixedAngle = extraConfig.fixedAngle || false;
                extraMesh1.userData.isExtraSprite = true;
                allSprites.push(extraMesh1);
                
                if (extraConfig.xSprite) {
                    const extraMesh2 = this.createSingleSprite(x, extraY, z, extraWidth, extraHeight, extraTex, extraConfig, false);
                    extraMesh2.rotation.y = Math.PI / 2;
                    extraMesh2.position.z += 0.002;
                    extraMesh2.userData.fixedAngle = extraConfig.fixedAngle || false;
                    extraMesh2.userData.isExtraSprite = true;
                    allSprites.push(extraMesh2);
                }
            }
        }
        
        mainSprite.userData.spriteGroup = allSprites;
        mainSprite.userData.isSpriteGroup = true;
        
        return mainSprite;
    }
    
    createSingleSprite(x, y, z, width, height, texture, type, isMain) {
        const geometry = new THREE.PlaneGeometry(width, height);
        const material = new THREE.MeshBasicMaterial({
            map: texture,
            transparent: true,
            side: THREE.DoubleSide,
            depthWrite: true,
            depthTest: true,
            alphaTest: 0.5
        });
        
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.set(x, y, z);
        
        mesh.userData = {
            typeId: type,
            isSprite: true,
            visualWidth: width,
            visualHeight: height,
            isMain: isMain
        };
        
        this.scene.add(mesh);
        this.sprites.push(mesh);
        
        return mesh;
    }
    
    update(player, delta) {
        const playerPos = player.getEyePosition();
        
        for (let sprite of this.sprites) {
            this.updateSpriteAnimation(sprite, delta);
            
            if (sprite.userData.isDoor) continue;
            
            if (sprite.userData.isSpriteGroup) {
                const group = sprite.userData.spriteGroup;
                if (group && group.length > 0) {
                    const fixedAngle = sprite.userData.fixedAngle || false;
                    
                    if (fixedAngle) {
                        // Не поворачиваем
                    } else {
                        for (let member of group) {
                            const dx = member.position.x - playerPos.x;
                            const dz = member.position.z - playerPos.z;
                            const angle = Math.atan2(dx, dz);
                            const index = group.indexOf(member);
                            member.rotation.y = angle + (index % 2 === 1 ? Math.PI / 2 : 0);
                        }
                    }
                }
            } else {
                if (!sprite.userData.fixedAngle) {
                    const dx = sprite.position.x - playerPos.x;
                    const dz = sprite.position.z - playerPos.z;
                    const angle = Math.atan2(dx, dz);
                    sprite.rotation.y = angle;
                }
            }
        }
    }
    
    updateSpriteAnimation(sprite, delta) {
        if (!sprite.userData.animated) return;
        
        sprite.userData.timer += delta;
        const duration = sprite.userData.frameDuration;
        if (sprite.userData.timer >= duration) {
            sprite.userData.timer -= duration;
            sprite.userData.currentFrame = (sprite.userData.currentFrame + 1) % sprite.userData.frameCount;
            if (sprite.userData.texture) {
                sprite.userData.texture.offset.x = sprite.userData.currentFrame / sprite.userData.frameCount;
                sprite.userData.texture.needsUpdate = true;
            }
        }
    }
    
    checkCollision(aabb) {
        return false;
    }
    
    getSpriteAt(col, row) {
        return null;
    }
    
    getSprites() {
        return this.sprites;
    }
    
    clear() {
        for (let sprite of this.sprites) {
            this.scene.remove(sprite);
            if (sprite.geometry) sprite.geometry.dispose();
            if (sprite.material) {
                if (sprite.material.map) {
                    sprite.material.map.dispose();
                }
                sprite.material.dispose();
            }
        }
        this.sprites = [];
    }
}