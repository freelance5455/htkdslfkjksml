// Управление для ПК (WASD + мышь)

class ControlsPC {
    constructor(player, renderer) {
        this.player = player;
        this.renderer = renderer;
        this.keys = {};
        this.isLocked = false;
        this.mouseMovement = 0;
        this.mouseSensitivity = 0.002;
        this.game = null;
        
        this.setupKeyboard();
        this.setupMouse();
        this.setupPointerLock();
    }
    
    setupKeyboard() {
        document.addEventListener('keydown', (e) => {
            const key = e.key.toLowerCase();
            this.keys[key] = true;
            
            // Блокируем прокрутку для WASD, F и Tab
            if (['w','a','s','d','ц','ф','ы','в', 'f', 'а', 'tab'].includes(key) || key === 'tab') {
                e.preventDefault();
            }
            
            // Нажатие F (русская 'а' тоже)
            if ((key === 'f' || key === 'а') && this.game) {
                this.game.interact();
            }
        });
        
        document.addEventListener('keyup', (e) => {
            const key = e.key.toLowerCase();
            this.keys[key] = false;
        });
    }
    
    setupMouse() {
        document.addEventListener('mousemove', (e) => {
            if (this.isLocked) {
                this.mouseMovement += e.movementX;
            }
        });
    }
    
    setupPointerLock() {
        this.renderer.domElement.addEventListener('click', () => {
            if (!this.isLocked && !this.game?.menu?.isActive) {
                this.renderer.domElement.requestPointerLock();
            }
        });
        
        document.addEventListener('pointerlockchange', () => {
            this.isLocked = document.pointerLockElement === this.renderer.domElement;
            if (!this.isLocked) {
                this.mouseMovement = 0;
            }
        });
        
        // ESC только сбрасывает движение мыши
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.mouseMovement = 0;
            }
        });
    }
    
    update(delta) {
        if (!this.isLocked) return;
        if (this.game && this.game.paused) return;
        
        const speed = this.player.moveSpeed;
        let moveX = 0;
        let moveZ = 0;
        
        if (this.keys['w'] || this.keys['ц']) moveZ += speed;
        if (this.keys['s'] || this.keys['ы']) moveZ -= speed;
        if (this.keys['a'] || this.keys['ф']) moveX += speed;
        if (this.keys['d'] || this.keys['в']) moveX -= speed;
        
        if (moveZ !== 0) {
            this.player.moveForward(delta, moveZ);
        }
        if (moveX !== 0) {
            this.player.moveStrafe(delta, moveX);
        }
        
        if (this.mouseMovement !== 0) {
            this.player.rotate(-this.mouseMovement * this.mouseSensitivity);
            this.mouseMovement = 0;
        }
    }
}