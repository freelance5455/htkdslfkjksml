// Взаимодействие с объектами (двери и др.)

class ObjectInteract {
    constructor(objectManager, animationManager, interfaceManager) {
        this.objectManager = objectManager;
        this.animationManager = animationManager;
        this.interfaceManager = interfaceManager;
        this.raycaster = new THREE.Raycaster();
        this.currentDoor = null;
        this.interactDistance = 2.0;
        this.soundManager = null;
        this.openingDoors = [];
        this.openDuration = 1.5;
        this.lastDoor = null;
    }

    update(player, camera) {
        const direction = new THREE.Vector3(0, 0, -1);
        direction.applyQuaternion(camera.quaternion);
        
        const origin = camera.position.clone();
        this.raycaster.set(origin, direction);
        
        const doorMeshes = [];
        const doorMap = new Map();
        for (let door of this.objectManager.doors) {
            if (!door.userData.isOpen && !this.isDoorOpening(door)) {
                doorMeshes.push(door.userData.mesh);
                doorMap.set(door.userData.mesh, door);
            }
        }
        
        const allMeshes = [];
        this.objectManager.scene.children.forEach(child => {
            if (child.isMesh && child.geometry && child.material) {
                if (!doorMap.has(child)) {
                    allMeshes.push(child);
                }
            }
        });
        
        const allMeshesForRaycast = [...allMeshes, ...doorMeshes];
        const intersects = this.raycaster.intersectObjects(allMeshesForRaycast);
        
        let doorFound = false;
        
        if (intersects.length > 0) {
            const hit = intersects[0];
            if (doorMap.has(hit.object) && hit.distance <= this.interactDistance) {
                if (hit.object === intersects[0].object) {
                    this.currentDoor = doorMap.get(hit.object);
                    doorFound = true;
                }
            }
        }
        
        if (!doorFound) {
            this.currentDoor = null;
        }
        
        this.updateActionIcon();
    }
    
    updateActionIcon() {
        const hasDoor = this.currentDoor !== null && !this.currentDoor.userData.isOpen;
        const currentDoorId = hasDoor ? this.currentDoor.userData.col + '_' + this.currentDoor.userData.row : null;
        
        if (this.lastDoor !== currentDoorId) {
            this.lastDoor = currentDoorId;
            
            if (hasDoor) {
                this.interfaceManager.showActionIcon(0);
            } else {
                this.interfaceManager.hideActionIcon();
            }
        }
    }

    isDoorOpening(doorGroup) {
        return this.openingDoors.includes(doorGroup);
    }

    interact() {
        if (this.currentDoor) {
            this.openDoor(this.currentDoor);
        }
    }

    openDoor(doorGroup) {
        if (!doorGroup) return;
        if (doorGroup.userData.isOpen) return;
        if (this.isDoorOpening(doorGroup)) {
            console.log('⏳ Дверь уже открывается, подожди...');
            return;
        }
        
        console.log('🚪 Открываем дверь с анимацией...');
        
        this.openingDoors.push(doorGroup);
        
        // Определяем звук в зависимости от типа двери
        const typeId = doorGroup.userData.typeId || 5;
        let soundKey = 'door_open_wood'; // по умолчанию деревянная
        if (typeId === 16) {
            soundKey = 'door_open_metal';
        }
        
        if (this.soundManager) {
            this.soundManager.playGroupSound(soundKey);
        }
        
        this.interfaceManager.hideActionIcon();
        this.lastDoor = null;
        
        const startAngle = doorGroup.rotation.y;
        const targetAngle = startAngle + Math.PI / 2;
        
        this.animationManager.addDoorAnimation(
            doorGroup,
            targetAngle,
            this.openDuration,
            () => {
                doorGroup.userData.isOpen = true;
                const index = this.openingDoors.indexOf(doorGroup);
                if (index !== -1) {
                    this.openingDoors.splice(index, 1);
                }
                console.log('✅ Дверь открыта (проходима)');
            }
        );
    }
}