// Парсинг данных карты

class MapData {
    constructor(levelData) {
        this.level = levelData;
        this.width = levelData.width || levelData.floor[0].length;
        this.height = levelData.height || levelData.floor.length;
        this.wallHeight = 1.5;
    }
    
    getCellValue(layer, row, col) {
        if (!this.isValidCell(col, row)) return { value: 0, textureId: null };
        const val = layer[row][col];
        return Utils.parseValue(val);
    }
    
    isValidCell(col, row) {
        return col >= 0 && col < this.width && row >= 0 && row < this.height;
    }
    
    getFloorData(row, col) {
        if (!this.isValidCell(col, row)) return { floor: { value: 0, textureId: null }, ceiling: null };
        const val = this.level.floor[row][col];
        return Utils.parseFloorWithCeiling(val);
    }
    
    hasFloor(col, row) {
        const data = this.getFloorData(row, col);
        return data.floor.value === 1;
    }
    
    getFloorTexture(col, row) {
        const data = this.getFloorData(row, col);
        return data.floor.textureId;
    }
    
    hasCeiling(col, row) {
        const data = this.getFloorData(row, col);
        return data.ceiling !== null;
    }
    
    getCeilingData(col, row) {
        const data = this.getFloorData(row, col);
        return data.ceiling;
    }
    
    isWall(col, row) {
        if (!this.isValidCell(col, row)) return true;
        const parsed = this.getCellValue(this.level.objects, row, col);
        return parsed.value === 1;
    }
    
    getWallTexture(col, row) {
        if (!this.isValidCell(col, row)) return null;
        const parsed = this.getCellValue(this.level.objects, row, col);
        return parsed.textureId;
    }
}