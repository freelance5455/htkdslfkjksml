// Система анимаций

class AnimationManager {
    constructor() {
        this.animations = [];
    }

    addDoorAnimation(doorGroup, targetAngle, duration, onComplete) {
        const startAngle = doorGroup.rotation.y;
        
        const anim = {
            type: 'door',
            group: doorGroup,
            startAngle: startAngle,
            targetAngle: targetAngle,
            duration: duration,
            elapsed: 0,
            onComplete: onComplete || null,
            completed: false
        };
        this.animations.push(anim);
    }

    update(delta) {
        for (let i = this.animations.length - 1; i >= 0; i--) {
            const anim = this.animations[i];
            if (anim.completed) {
                this.animations.splice(i, 1);
                continue;
            }
            
            anim.elapsed += delta;
            let progress = Math.min(anim.elapsed / anim.duration, 1);
            progress = progress < 0.5 ? 2 * progress * progress : 1 - Math.pow(-2 * progress + 2, 2) / 2;
            
            const currentAngle = anim.startAngle + (anim.targetAngle - anim.startAngle) * progress;
            anim.group.rotation.y = currentAngle;
            
            if (progress >= 1) {
                anim.completed = true;
                if (anim.onComplete) anim.onComplete();
                this.animations.splice(i, 1);
            }
        }
    }

    clear() {
        this.animations = [];
    }
}