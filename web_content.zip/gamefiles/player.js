// Игрок

class Player {
    constructor(spawnPos) {
        this.position = {
            x: spawnPos.x,
            y: 0.5,
            z: spawnPos.z
        };
        this.rotation = 0;
        
        this.width = 0.6;
        this.height = 1.0;
        this.eyeHeight = 0.8;
        
        this.moveSpeed = 3.0;
        this.rotSpeed = 0.03;
    }
    
    getAABB() {
        return {
            x: this.position.x,
            y: this.position.y,
            z: this.position.z,
            w: this.width,
            h: this.height,
            d: this.width
        };
    }
    
    getEyePosition() {
        return {
            x: this.position.x,
            y: this.eyeHeight,
            z: this.position.z
        };
    }
    
    moveForward(delta, amount) {
        const rad = this.rotation;
        // Исправлено: -sin для forward (в трех.js Z это вперед/назад)
        const dx = -Math.sin(rad) * amount * delta;
        const dz = -Math.cos(rad) * amount * delta;
        this.position.x += dx;
        this.position.z += dz;
    }
    
    moveStrafe(delta, amount) {
        const rad = this.rotation + Math.PI / 2;
        const dx = -Math.sin(rad) * amount * delta;
        const dz = -Math.cos(rad) * amount * delta;
        this.position.x += dx;
        this.position.z += dz;
    }
    
    rotate(amount) {
        this.rotation = Utils.normalizeAngle(this.rotation + amount);
    }
    
    setPosition(x, z) {
        this.position.x = x;
        this.position.z = z;
    }
}