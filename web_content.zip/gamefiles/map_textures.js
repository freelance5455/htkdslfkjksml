// Управление текстурами карты

class MapTextures {
    constructor() {
        this.textures = {};
        this.textureSizes = {};
        this.texturesLoaded = false;
        
        this.textureList = {
            1: 'kirpichi.png',
            2: 'plitka.png',
            3: 'dern.png',
            4: 'doski.png',
            5: 'starie_doski.png',
            6: 'blindazhi.png',
            7: 'beton.png',
            8: 'graviy.png'      // Новая текстура гравия
        };
    }
    
    loadTextures(callback) {
        const loader = new THREE.TextureLoader();
        let loadedCount = 0;
        const totalTextures = Object.keys(this.textureList).length;
        
        if (totalTextures === 0) {
            this.texturesLoaded = true;
            if (callback) callback();
            return;
        }
        
        for (let id in this.textureList) {
            const path = 'gamefiles/' + this.textureList[id];
            loader.load(
                path,
                (texture) => {
                    texture.wrapS = THREE.RepeatWrapping;
                    texture.wrapT = THREE.RepeatWrapping;
                    texture.repeat.set(1, 1);
                    texture.magFilter = THREE.NearestFilter;
                    texture.minFilter = THREE.NearestFilter;
                    texture.needsUpdate = true;
                    
                    this.textures[id] = texture;
                    
                    const img = texture.image;
                    if (img) {
                        this.textureSizes[id] = {
                            width: img.width,
                            height: img.height
                        };
                    }
                    
                    loadedCount++;
                    if (loadedCount === totalTextures) {
                        this.texturesLoaded = true;
                        if (callback) callback();
                    }
                },
                undefined,
                (error) => {
                    console.warn('Не удалось загрузить текстуру:', path, error);
                    loadedCount++;
                    if (loadedCount === totalTextures) {
                        this.texturesLoaded = true;
                        if (callback) callback();
                    }
                }
            );
        }
    }
    
    getTexture(id) {
        return this.textures[id] || null;
    }
}