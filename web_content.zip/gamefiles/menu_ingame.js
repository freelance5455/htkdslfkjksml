// Меню паузы

class InGameMenu {
    constructor(game) {
        this.game = game;
        this.isActive = false;
        this.isSettings = false;
        this.lastToggleTime = 0;
        this.toggleCooldown = 300;
        this.isDragging = false;
        this.lastVolume = 1.0;
        this.hintsEnabled = true;
        this.lastSliderValue = -1;
        
        this.createMenu();
        
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Tab') {
                e.preventDefault();
                const now = Date.now();
                if (now - this.lastToggleTime < this.toggleCooldown) return;
                this.lastToggleTime = now;
                this.toggle();
            }
        });
        
        // Мышь
        document.addEventListener('mousemove', (e) => {
            if (this.isDragging && this.slider) {
                this.updateSliderFromMouse(e);
            }
        });
        
        document.addEventListener('mouseup', () => {
            if (this.isDragging) {
                this.isDragging = false;
            }
        });
        
        // Touch (мобильные)
        document.addEventListener('touchmove', (e) => {
            if (this.isDragging && this.slider) {
                e.preventDefault();
                const touch = e.touches[0];
                if (touch) {
                    this.updateSliderFromTouch(touch);
                }
            }
        }, { passive: false });
        
        document.addEventListener('touchend', () => {
            if (this.isDragging) {
                this.isDragging = false;
            }
        });
        
        document.addEventListener('touchcancel', () => {
            if (this.isDragging) {
                this.isDragging = false;
            }
        });
    }
    
    playClickSound() {
        if (this.game && this.game.sounds) {
            this.game.sounds.playGroupSound('menu_click');
        }
    }
    
    createMenu() {
        this.container = document.createElement('div');
        this.container.id = 'pause-menu';
        this.container.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.95);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 100;
            flex-direction: column;
        `;
        
        // ===== МЕНЮ =====
        this.mainMenu = document.createElement('div');
        this.mainMenu.style.cssText = `
            display: flex;
            flex-direction: column;
            align-items: center;
        `;
        
        const title = document.createElement('div');
        title.textContent = 'ПАУЗА';
        title.style.cssText = `
            color: #fff;
            font-family: Arial, sans-serif;
            font-size: 48px;
            font-weight: bold;
            margin-bottom: 40px;
            letter-spacing: 4px;
        `;
        this.mainMenu.appendChild(title);
        
        const menuButtons = [
            { id: 'resume', text: 'Продолжить' },
            { id: 'settings', text: 'Настройки' },
            { id: 'quit', text: 'Покинуть игру' }
        ];
        
        this.buttons = {};
        let maxWidth = 0;
        const tempButtons = [];
        
        for (let btn of menuButtons) {
            const button = document.createElement('button');
            button.textContent = btn.text;
            button.style.cssText = `
                background: #444444;
                border: 2px solid #9E9E9E;
                color: #ffffff;
                font-family: Arial, sans-serif;
                font-size: 20px;
                padding: 12px 40px;
                margin: 8px 0;
                cursor: pointer;
                transition: background 0.2s;
                text-align: center;
                user-select: none;
                white-space: nowrap;
                display: block;
            `;
            document.body.appendChild(button);
            const rect = button.getBoundingClientRect();
            maxWidth = Math.max(maxWidth, rect.width);
            document.body.removeChild(button);
            tempButtons.push({ element: button, id: btn.id, text: btn.text });
        }
        
        maxWidth += 40;
        
        for (let item of tempButtons) {
            const button = item.element;
            button.style.width = maxWidth + 'px';
            button.id = 'btn-' + item.id;
            
            button.addEventListener('mouseenter', () => {
                button.style.background = '#555555';
            });
            button.addEventListener('mouseleave', () => {
                button.style.background = '#444444';
            });
            
            button.addEventListener('click', () => {
                this.playClickSound();
                this.handleButtonClick(item.id);
            });
            
            this.mainMenu.appendChild(button);
            this.buttons[item.id] = button;
        }
        
        this.container.appendChild(this.mainMenu);
        
        // ===== МЕНЮ НАСТРОЕК =====
        this.settingsMenu = document.createElement('div');
        this.settingsMenu.style.cssText = `
            display: none;
            flex-direction: column;
            align-items: center;
        `;
        
        const settingsTitle = document.createElement('div');
        settingsTitle.textContent = 'НАСТРОЙКИ';
        settingsTitle.style.cssText = `
            color: #fff;
            font-family: Arial, sans-serif;
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 30px;
            letter-spacing: 3px;
        `;
        this.settingsMenu.appendChild(settingsTitle);
        
        const settingsButtons = [
            { id: 'hints', text: 'Расш. подсказки: ВКЛ' },
            { id: 'mob_controls', text: 'Моб. управление' },
            { id: 'back', text: 'Назад' }
        ];
        
        let settingsMaxWidth = 0;
        const settingsTempButtons = [];
        
        for (let btn of settingsButtons) {
            const button = document.createElement('button');
            button.textContent = btn.text;
            button.style.cssText = `
                background: #444444;
                border: 2px solid #9E9E9E;
                color: #ffffff;
                font-family: Arial, sans-serif;
                font-size: 16px;
                padding: 10px 40px;
                margin: 6px 0;
                cursor: pointer;
                transition: background 0.2s;
                text-align: center;
                user-select: none;
                white-space: nowrap;
                display: block;
            `;
            document.body.appendChild(button);
            const rect = button.getBoundingClientRect();
            settingsMaxWidth = Math.max(settingsMaxWidth, rect.width);
            document.body.removeChild(button);
            settingsTempButtons.push({ element: button, id: btn.id, text: btn.text });
        }
        
        settingsMaxWidth += 40;
        
        // ---- Строка звука ----
        const soundWrapper = document.createElement('div');
        soundWrapper.style.cssText = `
            width: ${settingsMaxWidth}px;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            padding: 4px 0;
            margin: 6px 0;
            box-sizing: border-box;
        `;
        
        this.soundToggleBtn = document.createElement('button');
        this.soundToggleBtn.style.cssText = `
            width: 48px;
            height: 48px;
            background: #444444;
            border: 2px solid #9E9E9E;
            cursor: pointer;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            transition: background 0.2s;
        `;
        this.soundToggleBtn.addEventListener('mouseenter', () => {
            this.soundToggleBtn.style.background = '#555555';
        });
        this.soundToggleBtn.addEventListener('mouseleave', () => {
            this.soundToggleBtn.style.background = '#444444';
        });
        this.soundToggleBtn.addEventListener('click', () => {
            this.playClickSound();
            this.toggleSound();
        });
        
        this.soundIcon = document.createElement('img');
        this.soundIcon.style.cssText = `
            width: 32px;
            height: 32px;
            image-rendering: pixelated;
            pointer-events: none;
        `;
        this.soundToggleBtn.appendChild(this.soundIcon);
        soundWrapper.appendChild(this.soundToggleBtn);
        
        this.sliderContainer = document.createElement('div');
        this.sliderContainer.style.cssText = `
            flex: 1;
            height: 48px;
            background: #1E1E1E;
            border: 2px solid #565656;
            position: relative;
            cursor: pointer;
            box-sizing: border-box;
            margin-left: 0;
            touch-action: none;
        `;
        
        this.sliderHandle = document.createElement('div');
        this.sliderHandle.style.cssText = `
            position: absolute;
            top: 0;
            left: 2px;
            width: 10px;
            height: 100%;
            background: #1C16C6;
            border: 1px solid #2A1680;
            pointer-events: none;
            box-sizing: border-box;
            transition: left 0.1s;
        `;
        this.sliderContainer.appendChild(this.sliderHandle);
        
        // События для ползунка (мышь + touch)
        this.sliderContainer.addEventListener('mousedown', (e) => {
            this.isDragging = true;
            this.lastSliderValue = -1;
            this.updateSliderFromMouse(e);
        });
        
        this.sliderContainer.addEventListener('touchstart', (e) => {
            e.preventDefault();
            this.isDragging = true;
            this.lastSliderValue = -1;
            const touch = e.touches[0];
            if (touch) {
                this.updateSliderFromTouch(touch);
            }
        }, { passive: false });
        
        soundWrapper.appendChild(this.sliderContainer);
        this.settingsMenu.appendChild(soundWrapper);
        
        // ---- Кнопки настроек ----
        this.hintsToggleBtn = settingsTempButtons[0].element;
        this.hintsToggleBtn.style.width = settingsMaxWidth + 'px';
        this.hintsToggleBtn.id = 'btn-hints';
        this.hintsToggleBtn.addEventListener('mouseenter', () => {
            if (this.hintsEnabled) {
                this.hintsToggleBtn.style.background = '#555555';
            }
        });
        this.hintsToggleBtn.addEventListener('mouseleave', () => {
            if (this.hintsEnabled) {
                this.hintsToggleBtn.style.background = '#444444';
            } else {
                this.hintsToggleBtn.style.background = '#1E1E1E';
            }
        });
        this.hintsToggleBtn.addEventListener('click', () => {
            this.playClickSound();
            this.toggleHints();
        });
        this.settingsMenu.appendChild(this.hintsToggleBtn);
        
        this.mobControlsBtn = settingsTempButtons[1].element;
        this.mobControlsBtn.style.width = settingsMaxWidth + 'px';
        this.mobControlsBtn.id = 'btn-mob-controls';
        this.mobControlsBtn.addEventListener('mouseenter', () => {
            this.mobControlsBtn.style.background = '#555555';
        });
        this.mobControlsBtn.addEventListener('mouseleave', () => {
            this.mobControlsBtn.style.background = '#444444';
        });
        this.mobControlsBtn.addEventListener('click', () => {
            this.playClickSound();
            console.log('Моб. управление (пока без функционала)');
        });
        this.settingsMenu.appendChild(this.mobControlsBtn);
        
        const backButton = settingsTempButtons[2].element;
        backButton.style.width = settingsMaxWidth + 'px';
        backButton.id = 'btn-back';
        backButton.addEventListener('mouseenter', () => {
            backButton.style.background = '#555555';
        });
        backButton.addEventListener('mouseleave', () => {
            backButton.style.background = '#444444';
        });
        backButton.addEventListener('click', () => {
            this.playClickSound();
            this.showMainMenu();
        });
        this.settingsMenu.appendChild(backButton);
        
        this.slider = this.sliderContainer;
        this.sliderHandleEl = this.sliderHandle;
        
        this.container.appendChild(this.settingsMenu);
        document.body.appendChild(this.container);
    }
    
    updateSliderFromMouse(e) {
        const rect = this.slider.getBoundingClientRect();
        const x = e.clientX - rect.left;
        this.updateSliderValue(x, rect.width);
    }
    
    updateSliderFromTouch(touch) {
        const rect = this.slider.getBoundingClientRect();
        const x = touch.clientX - rect.left;
        this.updateSliderValue(x, rect.width);
    }
    
    updateSliderValue(x, width) {
        let percent = x / width;
        percent = Math.max(0, Math.min(1, percent));
        
        const step = 0.05;
        const newValue = Math.round(percent / step) * step;
        
        if (Math.abs(newValue - this.lastSliderValue) > 0.001) {
            this.lastSliderValue = newValue;
            this.playClickSound();
        }
        
        this.setVolume(newValue);
        this.updateSoundState(newValue);
    }
    
    setVolume(value) {
        if (this.game && this.game.sounds) {
            this.game.sounds.setVolume(value);
        }
        this.updateSliderUI(value);
    }
    
    updateSliderUI(value) {
        const percent = Math.max(0, Math.min(1, value));
        const handleWidth = 10;
        const padding = 2;
        const maxLeft = this.sliderContainer.clientWidth - handleWidth - padding * 2;
        const left = padding + percent * maxLeft;
        this.sliderHandleEl.style.left = left + 'px';
    }
    
    updateSoundState(volume) {
        if (this.game && this.game.sounds) {
            const isMuted = volume === 0;
            this.game.sounds.setEnabled(!isMuted);
            this.updateSoundIcon(!isMuted);
        }
    }
    
    toggleSound() {
        if (this.game && this.game.sounds) {
            const sounds = this.game.sounds;
            const currentVolume = sounds.getVolume();
            const isEnabled = sounds.isEnabled();
            
            if (isEnabled) {
                this.lastVolume = currentVolume;
                sounds.setVolume(0);
                sounds.setEnabled(false);
                this.updateSliderUI(0);
                this.updateSoundIcon(false);
            } else {
                const vol = this.lastVolume > 0 ? this.lastVolume : 1.0;
                sounds.setVolume(vol);
                sounds.setEnabled(true);
                this.updateSliderUI(vol);
                this.updateSoundIcon(true);
            }
        }
    }
    
    updateSoundIcon(enabled) {
        const iconName = enabled ? 'zvuk_on.png' : 'zvuk_off.png';
        this.soundIcon.src = 'gamefiles/ikonki/' + iconName;
    }
    
    toggleHints() {
        this.hintsEnabled = !this.hintsEnabled;
        this.updateHintsButton();
        console.log('Расш. подсказки:', this.hintsEnabled ? 'ВКЛ' : 'ВЫКЛ');
    }
    
    updateHintsButton() {
        const text = this.hintsEnabled ? 'Расш. подсказки: ВКЛ' : 'Расш. подсказки: ВЫКЛ';
        this.hintsToggleBtn.textContent = text;
        
        if (this.hintsEnabled) {
            this.hintsToggleBtn.style.background = '#444444';
            this.hintsToggleBtn.style.border = '2px solid #9E9E9E';
            this.hintsToggleBtn.style.color = '#ffffff';
        } else {
            this.hintsToggleBtn.style.background = '#1E1E1E';
            this.hintsToggleBtn.style.border = '2px solid #565656';
            this.hintsToggleBtn.style.color = '#888888';
        }
    }
    
    updateSettingsUI() {
        if (this.game && this.game.sounds) {
            const sounds = this.game.sounds;
            const volume = sounds.getVolume();
            const enabled = sounds.isEnabled();
            
            this.updateSliderUI(volume);
            this.updateSoundIcon(enabled);
            
            if (!enabled && volume > 0) {
                this.lastVolume = volume;
            }
        }
        this.updateHintsButton();
        this.lastSliderValue = this.game?.sounds?.getVolume() || 0;
    }
    
    showMainMenu() {
        this.isSettings = false;
        this.mainMenu.style.display = 'flex';
        this.settingsMenu.style.display = 'none';
    }
    
    showSettings() {
        this.isSettings = true;
        this.mainMenu.style.display = 'none';
        this.settingsMenu.style.display = 'flex';
        this.updateSettingsUI();
    }
    
    handleButtonClick(id) {
        switch(id) {
            case 'resume':
                this.close();
                break;
            case 'settings':
                this.showSettings();
                break;
            case 'quit':
                console.log('Выход из игры (пока без функционала)');
                break;
        }
    }
    
    toggle() {
        if (this.isActive) {
            this.close();
        } else {
            this.open();
        }
    }
    
    open() {
        this.isActive = true;
        this.isSettings = false;
        this.mainMenu.style.display = 'flex';
        this.settingsMenu.style.display = 'none';
        this.container.style.display = 'flex';
        
        if (this.game) {
            this.game.pause(true);
        }
        
        if (document.pointerLockElement) {
            document.exitPointerLock();
        }
    }
    
    close() {
        this.isActive = false;
        this.isSettings = false;
        this.container.style.display = 'none';
        
        if (this.game) {
            this.game.pause(false);
        }
        
        if (this.game && this.game.renderer) {
            this.game.renderer.domElement.requestPointerLock();
        }
    }
}