// Система звуков

class SoundManager {
    constructor() {
        this.sounds = {};
        this.soundGroups = {};
        this.loaded = false;
        this.loading = false;
        this.totalSounds = 0;
        this.loadedSounds = 0;
        this.enabled = true;
        this.masterVolume = 1.0;
        
        this.soundConfigs = {
            'footstep_grass': {
                files: [
                    'shag_trava_0.mp3',
                    'shag_trava_1.mp3',
                    'shag_trava_2.mp3',
                    'shag_trava_3.mp3'
                ],
                path: 'gamefiles/zvuki/',
                group: 'footsteps',
                random: true,
                gap: 0.3
            },
            'footstep_stone': {
                files: [
                    'shag_kamen_0.mp3',
                    'shag_kamen_1.mp3',
                    'shag_kamen_2.mp3',
                    'shag_kamen_3.mp3',
                    'shag_kamen_4.mp3',
                    'shag_kamen_5.mp3'
                ],
                path: 'gamefiles/zvuki/',
                group: 'footsteps',
                random: true,
                gap: 0.3
            },
            'footstep_gravel': {
                files: [
                    'shag_graviy_0.mp3',
                    'shag_graviy_1.mp3',
                    'shag_graviy_2.mp3',
                    'shag_graviy_3.mp3',
                    'shag_graviy_4.mp3',
                    'shag_graviy_5.mp3'
                ],
                path: 'gamefiles/zvuki/',
                group: 'footsteps',
                random: true,
                gap: 0.3
            },
            'footstep_wood': {
                files: [
                    'shag_doski_0.mp3',
                    'shag_doski_1.mp3',
                    'shag_doski_2.mp3',
                    'shag_doski_3.mp3',
                    'shag_doski_4.mp3'
                ],
                path: 'gamefiles/zvuki/',
                group: 'footsteps',
                random: true,
                gap: 0.3
            },
            'footstep_old_wood': {
                files: [
                    'shag_doski_0.mp3',
                    'shag_doski_1.mp3',
                    'shag_doski_2.mp3',
                    'shag_doski_3.mp3',
                    'shag_doski_4.mp3'
                ],
                path: 'gamefiles/zvuki/',
                group: 'footsteps',
                random: true,
                gap: 0.3
            },
            'door_open_wood': {
                files: [
                    'dver_skrip_1.mp3'
                ],
                path: 'gamefiles/zvuki/',
                group: 'door',
                random: false,
                gap: 0
            },
            'door_open_metal': {
                files: [
                    'dver_met_skrip.mp3'
                ],
                path: 'gamefiles/zvuki/',
                group: 'door',
                random: false,
                gap: 0
            },
            'menu_click': {
                files: [
                    'vibor.mp3'
                ],
                path: 'gamefiles/zvuki/',
                group: 'menu',
                random: false,
                gap: 0.1
            }
        };
        
        this.groupStates = {
            footsteps: {
                lastPlayTime: 0,
                lastIndex: -1
            },
            door: {
                lastPlayTime: 0,
                lastIndex: -1
            },
            menu: {
                lastPlayTime: 0,
                lastIndex: -1
            }
        };
    }
    
    loadSounds(callback) {
        if (this.loaded) {
            if (callback) callback();
            return;
        }
        
        if (this.loading) {
            const checkLoaded = () => {
                if (this.loaded) {
                    if (callback) callback();
                } else {
                    setTimeout(checkLoaded, 100);
                }
            };
            checkLoaded();
            return;
        }
        
        this.loading = true;
        this.loadedSounds = 0;
        
        const soundsToLoad = [];
        for (let key in this.soundConfigs) {
            const config = this.soundConfigs[key];
            if (config.files) {
                for (let file of config.files) {
                    soundsToLoad.push({
                        key: key,
                        file: file,
                        path: config.path || 'gamefiles/zvuki/'
                    });
                }
            }
        }
        
        this.totalSounds = soundsToLoad.length;
        
        if (this.totalSounds === 0) {
            this.loaded = true;
            this.loading = false;
            if (callback) callback();
            return;
        }
        
        for (let item of soundsToLoad) {
            const url = item.path + item.file;
            const audio = new Audio();
            const soundKey = item.key + '_' + item.file.replace(/\.[^/.]+$/, '');
            
            audio.addEventListener('canplaythrough', () => {
                this.sounds[soundKey] = audio;
                this.loadedSounds++;
                
                if (this.loadedSounds >= this.totalSounds) {
                    this.loaded = true;
                    this.loading = false;
                    console.log('Все звуки загружены!');
                    if (callback) callback();
                }
            });
            
            audio.addEventListener('error', (e) => {
                console.warn('Не удалось загрузить звук:', url, e);
                this.loadedSounds++;
                
                if (this.loadedSounds >= this.totalSounds) {
                    this.loaded = true;
                    this.loading = false;
                    console.log('Звуки загружены с ошибками');
                    if (callback) callback();
                }
            });
            
            audio.src = url;
            audio.load();
            
            if (!this.soundGroups[item.key]) {
                this.soundGroups[item.key] = [];
            }
            this.soundGroups[item.key].push({
                key: soundKey,
                file: item.file
            });
        }
    }
    
    playGroupSound(groupKey) {
        if (!this.enabled || !this.loaded) return;
        
        const group = this.soundGroups[groupKey];
        if (!group || group.length === 0) return;
        
        const config = this.soundConfigs[groupKey];
        if (!config) return;
        
        const now = Date.now();
        const state = this.groupStates[config.group];
        if (state) {
            if (now - state.lastPlayTime < (config.gap || 0) * 1000) {
                return;
            }
        }
        
        let index;
        if (config.random) {
            do {
                index = Math.floor(Math.random() * group.length);
            } while (index === state?.lastIndex && group.length > 1);
        } else {
            index = (state?.lastIndex + 1) % group.length;
        }
        
        const soundData = group[index];
        const audio = this.sounds[soundData.key];
        
        if (!audio) return;
        
        const clone = audio.cloneNode();
        clone.volume = this.masterVolume;
        clone.play().catch(e => {});
        
        if (state) {
            state.lastPlayTime = now;
            state.lastIndex = index;
        }
    }
    
    playSound(soundKey) {
        if (!this.enabled || !this.loaded) return;
        
        const audio = this.sounds[soundKey];
        if (!audio) return;
        
        const clone = audio.cloneNode();
        clone.volume = this.masterVolume;
        clone.play().catch(e => {});
    }
    
    toggleEnabled() {
        this.enabled = !this.enabled;
        return this.enabled;
    }
    
    setEnabled(enabled) {
        this.enabled = enabled;
    }
    
    setVolume(volume) {
        this.masterVolume = Math.max(0, Math.min(1, volume));
        return this.masterVolume;
    }
    
    getVolume() {
        return this.masterVolume;
    }
    
    isEnabled() {
        return this.enabled;
    }
    
    isLoaded() {
        return this.loaded;
    }
}