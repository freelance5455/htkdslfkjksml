// Основной игровой цикл

class Game {
    constructor() {
        this.clock = new THREE.Clock();
        this.fpsCounter = 0;
        this.fpsTimer = 0;
        this.currentFPS = 0;
        this.ready = false;
        this.isMoving = false;
        this.footstepTimer = 0;
        this.footstepInterval = 0.4;
        this.paused = false;
        
        this.renderer = new Renderer();
        this.map = new MapManager(LevelTest);
        this.objects = new ObjectManager(this.renderer.scene, this.map);
        this.advancedObjects = new AdvancedObjectManager(this.renderer.scene, this.map);
        this.sounds = new SoundManager();
        this.animations = new AnimationManager();
        this.interface = new InterfaceManager();
        this.objectInteract = new ObjectInteract(this.objects, this.animations, this.interface);
        this.objectInteract.soundManager = this.sounds;
        this.menu = new InGameMenu(this);
        
        let texturesLoaded = 0;
        let soundsLoaded = false;
        let iconsLoaded = false;
        let advancedTexturesLoaded = false;
        const totalTextures = 2;
        
        const checkReady = () => {
            if (texturesLoaded === totalTextures && soundsLoaded && iconsLoaded && advancedTexturesLoaded) {
                this.initGame();
            }
        };
        
        const onTextureLoaded = () => {
            texturesLoaded++;
            checkReady();
        };
        
        const onSoundsLoaded = () => {
            soundsLoaded = true;
            checkReady();
        };
        
        const onIconsLoaded = () => {
            iconsLoaded = true;
            checkReady();
        };
        
        const onAdvancedTexturesLoaded = () => {
            advancedTexturesLoaded = true;
            checkReady();
        };
        
        this.map.loadTextures(onTextureLoaded);
        this.objects.loadTextures(onTextureLoaded);
        this.sounds.loadSounds(onSoundsLoaded);
        this.interface.loadActionIcons(onIconsLoaded);
        this.advancedObjects.loadTextures(onAdvancedTexturesLoaded);
        
        this.lastTime = performance.now();
        this.gameLoop = this.gameLoop.bind(this);
        requestAnimationFrame(this.gameLoop);
        
        this.updateDebug();
    }
    
    pause(state) {
        this.paused = state;
        if (state) {
            console.log('⏸ Игра на паузе');
        } else {
            console.log('▶ Игра продолжена');
            this.lastTime = performance.now();
        }
    }
    
    initGame() {
        this.player = new Player(LevelTest.spawn);
        
        this.controlsPC = new ControlsPC(this.player, this.renderer);
        this.controlsPC.game = this;
        
        this.controlsMob = new ControlsMob(this.player, this.renderer);
        this.controlsMob.game = this;
        
        this.buildLevel();
        this.objects.buildAll();
        this.advancedObjects.buildAll();
        this.resolveCollisions();
        this.ready = true;
        
        console.log('Игра загружена!');
        this.updateDebug();
    }
    
    buildLevel() {
        const width = this.map.width;
        const height = this.map.height;
        const mapObj = this.map;
        
        for (let row = 0; row < height; row++) {
            for (let col = 0; col < width; col++) {
                if (mapObj.hasFloor(col, row)) {
                    const mesh = mapObj.createFloorMesh(col, row);
                    this.renderer.scene.add(mesh);
                }
                
                if (mapObj.hasCeiling(col, row)) {
                    const mesh = mapObj.createCeilingMesh(col, row);
                    if (mesh) {
                        this.renderer.scene.add(mesh);
                    }
                }
            }
        }
        
        for (let row = 0; row < height; row++) {
            for (let col = 0; col < width; col++) {
                if (mapObj.isWall(col, row)) {
                    const mesh = mapObj.createWallMesh(col, row);
                    this.renderer.scene.add(mesh);
                }
            }
        }
    }
    
    interact() {
        if (!this.ready || !this.player || this.paused) return;
        this.objectInteract.interact();
    }
    
    resolveCollisions() {
        if (!this.player || this.paused) return;
        
        const playerAABB = this.player.getAABB();
        const halfW = playerAABB.w / 2;
        const halfD = playerAABB.d / 2;
        
        // Границы по X
        if (playerAABB.x - halfW < 0) {
            this.player.position.x = halfW;
        }
        if (playerAABB.x + halfW > this.map.width) {
            this.player.position.x = this.map.width - halfW;
        }
        // Границы по Z
        if (playerAABB.z - halfD < 0) {
            this.player.position.z = halfD;
        }
        if (playerAABB.z + halfD > this.map.height) {
            this.player.position.z = this.map.height - halfD;
        }
        
        const testPos = {
            x: this.player.position.x,
            y: playerAABB.y,
            z: this.player.position.z,
            w: playerAABB.w,
            h: playerAABB.h,
            d: playerAABB.d
        };
        
        if (this.map.checkCollision(testPos) || this.objects.checkCollision(testPos)) {
            const step = 0.01;
            let found = false;
            
            for (let i = 0; i < 10; i++) {
                testPos.x = this.player.position.x - (i + 1) * step;
                if (!this.map.checkCollision(testPos) && !this.objects.checkCollision(testPos)) {
                    this.player.position.x = testPos.x;
                    found = true;
                    break;
                }
                testPos.x = this.player.position.x + (i + 1) * step;
                if (!this.map.checkCollision(testPos) && !this.objects.checkCollision(testPos)) {
                    this.player.position.x = testPos.x;
                    found = true;
                    break;
                }
            }
        }
        
        const testPosZ = {
            x: this.player.position.x,
            y: playerAABB.y,
            z: this.player.position.z,
            w: playerAABB.w,
            h: playerAABB.h,
            d: playerAABB.d
        };
        
        if (this.map.checkCollision(testPosZ) || this.objects.checkCollision(testPosZ)) {
            const step = 0.01;
            let found = false;
            
            for (let i = 0; i < 10; i++) {
                testPosZ.z = this.player.position.z - (i + 1) * step;
                if (!this.map.checkCollision(testPosZ) && !this.objects.checkCollision(testPosZ)) {
                    this.player.position.z = testPosZ.z;
                    found = true;
                    break;
                }
                testPosZ.z = this.player.position.z + (i + 1) * step;
                if (!this.map.checkCollision(testPosZ) && !this.objects.checkCollision(testPosZ)) {
                    this.player.position.z = testPosZ.z;
                    found = true;
                    break;
                }
            }
        }
        
        // Проверка порталов
        this.checkPortals();
    }
    
    checkPortals() {
        if (!this.player || !this.ready) return;
        
        const playerAABB = this.player.getAABB();
        const portals = this.objects.portals || [];
        
        for (let portal of portals) {
            const col = portal.userData.col;
            const row = portal.userData.row;
            const portalAABB = {
                x: col + 0.5,
                y: 1.0,
                z: row + 0.5,
                w: 1.0,
                h: 2.0,
                d: 1.0
            };
            
            if (Utils.aabbIntersect(playerAABB, portalAABB)) {
                const targetX = portal.userData.targetX;
                const targetZ = portal.userData.targetZ;
                console.log(`Портал телепортирует игрока в (${targetX}, ${targetZ})`);
                this.player.position.x = targetX;
                this.player.position.z = targetZ;
                break;
            }
        }
    }
    
    getSurfaceType() {
        if (!this.ready || !this.player || this.paused) return null;
        
        const col = Math.floor(this.player.position.x);
        const row = Math.floor(this.player.position.z);
        
        if (!this.map.hasFloor(col, row)) return null;
        
        const textureId = this.map.getFloorTexture(col, row);
        
        if (textureId === 2) {
            return 'stone';
        } else if (textureId === 3) {
            return 'grass';
        } else if (textureId === 4) {
            return 'wood';
        } else if (textureId === 5) {
            return 'old_wood';
        } else if (textureId === 8) {
            return 'gravel';
        }
        
        return 'grass';
    }
    
    isPlayerMoving() {
        if (!this.ready || !this.player || this.paused) return false;
        
        const keys = this.controlsPC.keys || {};
        const isPCMoving = keys['w'] || keys['ц'] || keys['s'] || keys['ы'] || 
                          keys['a'] || keys['ф'] || keys['d'] || keys['в'];
        
        const isMobMoving = this.controlsMob && 
                           this.controlsMob.joystick && 
                           this.controlsMob.joystick.active &&
                           (Math.abs(this.controlsMob.joystick.dx) > 0.1 || 
                            Math.abs(this.controlsMob.joystick.dy) > 0.1);
        
        return isPCMoving || isMobMoving;
    }
    
    gameLoop() {
        const now = performance.now();
        const delta = Math.min((now - this.lastTime) / 1000, 0.05);
        this.lastTime = now;
        
        if (this.ready && this.player && !this.paused) {
            const prevX = this.player.position.x;
            const prevZ = this.player.position.z;
            
            this.controlsPC.update(delta);
            this.controlsMob.update(delta);
            
            this.resolveCollisions();
            
            const aabb = this.player.getAABB();
            if (this.map.checkCollision(aabb) || this.objects.checkCollision(aabb)) {
                this.player.position.x = prevX;
                this.player.position.z = prevZ;
            }
            
            const moving = this.isPlayerMoving();
            if (moving) {
                this.footstepTimer += delta;
                if (this.footstepTimer >= this.footstepInterval) {
                    const surface = this.getSurfaceType();
                    if (surface === 'stone') {
                        this.sounds.playGroupSound('footstep_stone');
                    } else if (surface === 'gravel') {
                        this.sounds.playGroupSound('footstep_gravel');
                    } else if (surface === 'wood') {
                        this.sounds.playGroupSound('footstep_wood');
                    } else if (surface === 'old_wood') {
                        this.sounds.playGroupSound('footstep_old_wood');
                    } else {
                        this.sounds.playGroupSound('footstep_grass');
                    }
                    this.footstepTimer = 0;
                }
            } else {
                this.footstepTimer = 0;
            }
            
            this.objects.update(this.player, delta);
            this.renderer.update(this.player);
            this.objectInteract.update(this.player, this.renderer.camera);
            this.animations.update(delta);
        }
        
        this.renderer.render();
        
        this.fpsCounter++;
        this.fpsTimer += delta;
        if (this.fpsTimer >= 0.5) {
            this.currentFPS = Math.round(this.fpsCounter / this.fpsTimer);
            this.fpsCounter = 0;
            this.fpsTimer = 0;
            this.updateDebug();
        }
        
        requestAnimationFrame(this.gameLoop);
    }
    
    updateDebug() {
        if (!this.player) {
            document.getElementById('debug').textContent = 'BlueM InDev | Загрузка...';
            return;
        }
        
        const pos = this.player.position;
        const fps = this.currentFPS;
        
        let rotDeg = Utils.radToDeg(this.player.rotation);
        rotDeg = ((rotDeg % 360) + 360) % 360;
        
        document.getElementById('debug').textContent = 
            `BlueM InDev | ${fps}FPS | (${pos.x.toFixed(2)}, ${pos.z.toFixed(2)}) | ${rotDeg.toFixed(1)}°`;
    }
}

window.addEventListener('load', () => {
    const game = new Game();
    window.game = game;
});