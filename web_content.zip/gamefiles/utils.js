// Вспомогательные функции (только чистая логика)

const Utils = {
    pointInAABB: function(px, py, pz, box) {
        return px >= box.x - box.w/2 && px <= box.x + box.w/2 &&
               py >= box.y - box.h/2 && py <= box.y + box.h/2 &&
               pz >= box.z - box.d/2 && pz <= box.z + box.d/2;
    },
    
    aabbIntersect: function(a, b) {
        return Math.abs(a.x - b.x) < (a.w/2 + b.w/2) &&
               Math.abs(a.y - b.y) < (a.h/2 + b.h/2) &&
               Math.abs(a.z - b.z) < (a.d/2 + b.d/2);
    },
    
    cellToWorld: function(col, row) {
        return { x: col + 0.5, z: row + 0.5 };
    },
    
    worldToCell: function(x, z) {
        return { col: Math.floor(x), row: Math.floor(z) };
    },
    
    isValidCell: function(col, row, size) {
        return col >= 0 && col < size && row >= 0 && row < size;
    },
    
    radToDeg: function(rad) {
        return rad * 180 / Math.PI;
    },
    
    normalizeAngle: function(angle) {
        while (angle > Math.PI) angle -= Math.PI * 2;
        while (angle < -Math.PI) angle += Math.PI * 2;
        return angle;
    },
    
    parseValue: function(val) {
        if (typeof val === 'number') {
            return { value: val, textureId: null };
        }
        if (typeof val === 'string') {
            const match = val.match(/^(\d+)\((\d+)\)$/);
            if (match) {
                return { value: parseInt(match[1]), textureId: parseInt(match[2]) };
            }
            const num = parseInt(val);
            if (!isNaN(num)) {
                return { value: num, textureId: null };
            }
        }
        return { value: 0, textureId: null };
    },
    
    parseFloorWithCeiling: function(val) {
        if (typeof val !== 'string') {
            return { floor: this.parseValue(val), ceiling: null };
        }
        
        const parts = val.split(',');
        if (parts.length === 1) {
            return { floor: this.parseValue(parts[0]), ceiling: null };
        }
        
        const ceilingStr = parts[1].trim();
        const ceilingMatch = ceilingStr.match(/^(\d+)\(([\d.]+)\)$/);
        let ceiling = null;
        
        if (ceilingMatch) {
            ceiling = {
                textureId: parseInt(ceilingMatch[1]),
                height: parseFloat(ceilingMatch[2])
            };
        } else {
            const num = parseInt(ceilingStr);
            if (!isNaN(num)) {
                ceiling = {
                    textureId: num,
                    height: 3.0
                };
            }
        }
        
        return {
            floor: this.parseValue(parts[0]),
            ceiling: ceiling
        };
    }
};