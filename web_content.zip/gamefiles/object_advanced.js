// Расширенные объекты (выделение, подсветка и т.д.)

class AdvancedObjectManager {
    constructor(scene, mapManager) {
        this.scene = scene;
        this.map = mapManager;
        this.objects = [];
        this.textures = {};
        this.loaded = false;
        
        // Список текстур выделения (ID 8)
        this.textureList = {
            1: 'videlenie_zel.png',
            2: 'videlenie_zhel.png',
            3: 'videlenie_kras.png'
        };
    }
    
    // Загрузка текстур выделения
    loadTextures(callback) {
        const loader = new THREE.TextureLoader();
        let loadedCount = 0;
        const totalTextures = Object.keys(this.textureList).length;
        
        if (totalTextures === 0) {
            this.loaded = true;
            if (callback) callback();
            return;
        }
        
        for (let id in this.textureList) {
            const path = 'gamefiles/' + this.textureList[id];
            loader.load(
                path,
                (texture) => {
                    texture.wrapS = THREE.RepeatWrapping;
                    texture.wrapT = THREE.RepeatWrapping;
                    texture.repeat.set(1, 1);
                    texture.magFilter = THREE.NearestFilter;
                    texture.minFilter = THREE.NearestFilter;
                    texture.needsUpdate = true;
                    
                    this.textures[id] = texture;
                    loadedCount++;
                    if (loadedCount === totalTextures) {
                        this.loaded = true;
                        if (callback) callback();
                    }
                },
                undefined,
                (error) => {
                    console.warn('Не удалось загрузить текстуру выделения:', path, error);
                    loadedCount++;
                    if (loadedCount === totalTextures) {
                        this.loaded = true;
                        if (callback) callback();
                    }
                }
            );
        }
    }
    
    // Создание шестиугольной призмы
    createHexagonPrismMesh(col, row, textureId, height = 0.3) {
        const texture = this.textures[textureId];
        if (!texture) {
            console.warn('Текстура выделения не загружена для ID:', textureId);
            return null;
        }
        
        const x = col + 0.5;
        const z = row + 0.5;
        
        const radius = 0.5;
        const segments = 6;
        const halfHeight = height / 2;
        
        const group = new THREE.Group();
        group.position.set(x, halfHeight, z);
        
        for (let i = 0; i < segments; i++) {
            const next = (i + 1) % segments;
            const angle1 = (i / segments) * Math.PI * 2 - Math.PI / 6;
            const angle2 = (next / segments) * Math.PI * 2 - Math.PI / 6;
            
            const x1 = Math.cos(angle1) * radius;
            const z1 = Math.sin(angle1) * radius;
            const x2 = Math.cos(angle2) * radius;
            const z2 = Math.sin(angle2) * radius;
            
            const v1 = { x: x1, y: -halfHeight, z: z1 };
            const v2 = { x: x2, y: -halfHeight, z: z2 };
            const v3 = { x: x2, y: halfHeight, z: z2 };
            const v4 = { x: x1, y: halfHeight, z: z1 };
            
            const geometry = new THREE.BufferGeometry();
            const vertices = [
                v1.x, v1.y, v1.z,
                v2.x, v2.y, v2.z,
                v3.x, v3.y, v3.z,
                v1.x, v1.y, v1.z,
                v3.x, v3.y, v3.z,
                v4.x, v4.y, v4.z
            ];
            
            const uvs = [
                0, 0,
                1, 0,
                1, 1,
                0, 0,
                1, 1,
                0, 1
            ];
            
            geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
            geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
            geometry.computeVertexNormals();
            
            const material = new THREE.MeshBasicMaterial({
                map: texture,
                transparent: true,
                side: THREE.DoubleSide,
                depthWrite: true,
                depthTest: true
            });
            
            const mesh = new THREE.Mesh(geometry, material);
            group.add(mesh);
        }
        
        group.userData = {
            isHighlight: true,
            col: col,
            row: row,
            textureId: textureId,
            type: 'highlight',
            height: height
        };
        
        this.scene.add(group);
        this.objects.push(group);
        
        return group;
    }
    
    // Получить данные о выделении в клетке
    getHighlightData(col, row) {
        if (!this.map || !this.map.data) return null;
        if (!this.map.data.isValidCell(col, row)) return null;
        if (!this.map.level || !this.map.level.objects) return null;
        
        const val = this.map.level.objects[row][col];
        const parsed = Utils.parseValue(val);
        if (parsed.value === 8) {
            let textureId = 1;
            if (parsed.textureId !== null) {
                textureId = parsed.textureId;
                if (textureId < 1 || textureId > 3) textureId = 1;
            }
            return {
                value: parsed.value,
                textureId: textureId
            };
        }
        return null;
    }
    
    // Построить все выделения на карте
    buildAll() {
        const width = this.map.width;
        const height = this.map.height;
        let created = 0;
        
        for (let row = 0; row < height; row++) {
            for (let col = 0; col < width; col++) {
                const data = this.getHighlightData(col, row);
                if (data) {
                    this.createHexagonPrismMesh(col, row, data.textureId, 0.3);
                    created++;
                }
            }
        }
        
        console.log(`Создано выделений: ${created}`);
        return created;
    }
    
    // Очистка
    clear() {
        for (let obj of this.objects) {
            this.scene.remove(obj);
            if (obj.children) {
                for (let child of obj.children) {
                    if (child.geometry) child.geometry.dispose();
                    if (child.material) child.material.dispose();
                }
            }
            if (obj.geometry) obj.geometry.dispose();
            if (obj.material) obj.material.dispose();
        }
        this.objects = [];
    }
}