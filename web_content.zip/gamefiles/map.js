// Основной класс карты (построение мешей и коллизии)

class MapManager {
    constructor(levelData) {
        this.level = levelData;
        this.data = new MapData(levelData);
        this.wallHeight = this.data.wallHeight;
        this.cellSize = 1;
        
        // Прокси для удобства
        this.width = this.data.width;
        this.height = this.data.height;
    }
    
    // Прокси-методы для текстур
    loadTextures(callback) {
        this.textures = new MapTextures();
        this.textures.loadTextures(callback);
    }
    
    getTexture(id) {
        return this.textures ? this.textures.getTexture(id) : null;
    }
    
    get texturesLoaded() {
        return this.textures ? this.textures.texturesLoaded : false;
    }
    
    // Прокси-методы для данных
    getCellValue(layer, row, col) {
        return this.data.getCellValue(layer, row, col);
    }
    
    getFloorData(row, col) {
        return this.data.getFloorData(row, col);
    }
    
    hasFloor(col, row) {
        return this.data.hasFloor(col, row);
    }
    
    getFloorTexture(col, row) {
        return this.data.getFloorTexture(col, row);
    }
    
    hasCeiling(col, row) {
        return this.data.hasCeiling(col, row);
    }
    
    getCeilingData(col, row) {
        return this.data.getCeilingData(col, row);
    }
    
    isWall(col, row) {
        return this.data.isWall(col, row);
    }
    
    getWallTexture(col, row) {
        return this.data.getWallTexture(col, row);
    }
    
    // Коллизии
    checkCollision(aabb) {
        const halfW = aabb.w / 2;
        const halfD = aabb.d / 2;
        
        const corners = [
            { x: aabb.x - halfW, z: aabb.z - halfD },
            { x: aabb.x + halfW, z: aabb.z - halfD },
            { x: aabb.x - halfW, z: aabb.z + halfD },
            { x: aabb.x + halfW, z: aabb.z + halfD }
        ];
        
        for (let corner of corners) {
            const col = Math.floor(corner.x);
            const row = Math.floor(corner.z);
            if (this.isWall(col, row)) {
                return true;
            }
        }
        
        const centerCol = Math.floor(aabb.x);
        const centerRow = Math.floor(aabb.z);
        if (this.isWall(centerCol, centerRow)) {
            return true;
        }
        
        return false;
    }
    
    checkBoundaries(aabb) {
        const halfW = aabb.w / 2;
        const halfD = aabb.d / 2;
        let corrected = false;
        
        if (aabb.x - halfW < 0) {
            aabb.x = halfW;
            corrected = true;
        }
        if (aabb.x + halfW > this.width) {
            aabb.x = this.width - halfW;
            corrected = true;
        }
        if (aabb.z - halfD < 0) {
            aabb.z = halfD;
            corrected = true;
        }
        if (aabb.z + halfD > this.height) {
            aabb.z = this.height - halfD;
            corrected = true;
        }
        
        return corrected;
    }
    
    // Построение мешей
    createWallMesh(col, row) {
        const x = col + 0.5;
        const z = row + 0.5;
        const y = this.wallHeight / 2;
        const hw = 0.5;
        const hh = this.wallHeight / 2;
        const hd = 0.5;
        
        const textureId = this.getWallTexture(col, row);
        const texture = textureId ? this.getTexture(textureId) : null;
        
        const geometry = new THREE.BufferGeometry();
        const vertices = [];
        const normals = [];
        const uvs = [];
        
        function addFace(v1, v2, v3, v4, normal, faceType) {
            const n = [normal.x, normal.y, normal.z];
            
            vertices.push(v1.x, v1.y, v1.z);
            vertices.push(v2.x, v2.y, v2.z);
            vertices.push(v3.x, v3.y, v3.z);
            
            vertices.push(v1.x, v1.y, v1.z);
            vertices.push(v3.x, v3.y, v3.z);
            vertices.push(v4.x, v4.y, v4.z);
            
            for (let i = 0; i < 6; i++) {
                normals.push(n[0], n[1], n[2]);
            }
            
            let u1, v1_uv, u2, v2_uv, u3, v3_uv, u4, v4_uv;
            
            switch(faceType) {
                case 'front':
                    u1 = 0; v1_uv = 0;
                    u2 = 1; v2_uv = 0;
                    u3 = 1; v3_uv = 1;
                    u4 = 0; v4_uv = 1;
                    break;
                case 'back':
                    u1 = 0; v1_uv = 0;
                    u2 = 1; v2_uv = 0;
                    u3 = 1; v3_uv = 1;
                    u4 = 0; v4_uv = 1;
                    break;
                case 'left':
                    u1 = 0; v1_uv = 0;
                    u2 = 1; v2_uv = 0;
                    u3 = 1; v3_uv = 1;
                    u4 = 0; v4_uv = 1;
                    break;
                case 'right':
                    u1 = 0; v1_uv = 0;
                    u2 = 1; v2_uv = 0;
                    u3 = 1; v3_uv = 1;
                    u4 = 0; v4_uv = 1;
                    break;
                default:
                    u1 = 0; v1_uv = 0;
                    u2 = 1; v2_uv = 0;
                    u3 = 1; v3_uv = 1;
                    u4 = 0; v4_uv = 1;
            }
            
            uvs.push(u1, v1_uv);
            uvs.push(u2, v2_uv);
            uvs.push(u3, v3_uv);
            uvs.push(u1, v1_uv);
            uvs.push(u3, v3_uv);
            uvs.push(u4, v4_uv);
        }
        
        // Передняя стена (z+) - Южная
        addFace(
            {x: -hw, y: -hh, z: hd},
            {x:  hw, y: -hh, z: hd},
            {x:  hw, y:  hh, z: hd},
            {x: -hw, y:  hh, z: hd},
            {x: 0, y: 0, z: 1},
            'front'
        );
        
        // Задняя стена (z-) - Северная
        addFace(
            {x:  hw, y: -hh, z: -hd},
            {x: -hw, y: -hh, z: -hd},
            {x: -hw, y:  hh, z: -hd},
            {x:  hw, y:  hh, z: -hd},
            {x: 0, y: 0, z: -1},
            'back'
        );
        
        // Левая стена (x-) - Западная
        addFace(
            {x: -hw, y: -hh, z:  hd},
            {x: -hw, y: -hh, z: -hd},
            {x: -hw, y:  hh, z: -hd},
            {x: -hw, y:  hh, z:  hd},
            {x: -1, y: 0, z: 0},
            'left'
        );
        
        // Правая стена (x+) - Восточная
        addFace(
            {x: hw, y: -hh, z: -hd},
            {x: hw, y: -hh, z:  hd},
            {x: hw, y:  hh, z:  hd},
            {x: hw, y:  hh, z: -hd},
            {x: 1, y: 0, z: 0},
            'right'
        );
        
        geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
        geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
        geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
        
        let material;
        if (texture) {
            material = new THREE.MeshBasicMaterial({
                map: texture,
                side: THREE.DoubleSide
            });
        } else {
            material = new THREE.MeshBasicMaterial({
                color: 0xcc4444,
                side: THREE.DoubleSide
            });
        }
        
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.set(x, y, z);
        
        return mesh;
    }
    
    createFloorMesh(col, row) {
        const x = col + 0.5;
        const z = row + 0.5;
        
        const textureId = this.getFloorTexture(col, row);
        const texture = textureId ? this.getTexture(textureId) : null;
        
        const geometry = new THREE.PlaneGeometry(1, 1);
        let material;
        if (texture) {
            material = new THREE.MeshBasicMaterial({
                map: texture,
                side: THREE.DoubleSide
            });
        } else {
            material = new THREE.MeshBasicMaterial({
                color: 0x888888,
                side: THREE.DoubleSide
            });
        }
        
        const mesh = new THREE.Mesh(geometry, material);
        mesh.rotation.x = -Math.PI / 2;
        mesh.position.set(x, 0, z);
        return mesh;
    }
    
    createCeilingMesh(col, row) {
        const x = col + 0.5;
        const z = row + 0.5;
        
        const ceilingData = this.getCeilingData(col, row);
        if (!ceilingData) return null;
        
        const texture = this.getTexture(ceilingData.textureId);
        const height = ceilingData.height;
        
        const geometry = new THREE.PlaneGeometry(1, 1);
        let material;
        if (texture) {
            material = new THREE.MeshBasicMaterial({
                map: texture,
                side: THREE.DoubleSide
            });
        } else {
            material = new THREE.MeshBasicMaterial({
                color: 0x888888,
                side: THREE.DoubleSide
            });
        }
        
        const mesh = new THREE.Mesh(geometry, material);
        mesh.rotation.x = Math.PI / 2;
        mesh.position.set(x, height, z);
        return mesh;
    }
}