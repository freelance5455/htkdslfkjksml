// Система объектов (наследуется от SpriteManager)

class ObjectManager extends SpriteManager {
    constructor(scene, mapManager) {
        super(scene);
        this.map = mapManager;
        this.doors = [];
        this.portals = [];
        this.fences = [];
        
        this.registerType(2, {
            texture: 'vzrivnaya_bochka.png',
            width: 0.48,
            height: 0.96,
            offsetY: 0.48,
            pixelScale: 0.015,
            keepAspect: true,
            xSprite: false,
            collision: true,
            collisionWidth: 0.6,
            collisionHeight: 0.8,
            data: {
                name: 'Взрывная бочка',
                health: 100,
                explosive: true
            }
        });
        
        this.registerType(3, {
            texture: 'osina_stvol.png',
            width: 1.0,
            height: 3.0,
            offsetY: 1.5,
            pixelScale: 0.03125,
            keepAspect: true,
            xSprite: true,
            fixedAngle: true,
            collision: true,
            collisionWidth: 0.4,
            collisionHeight: 2.0,
            data: {
                name: 'Осина ствол',
                type: 'tree',
                health: 50
            }
        });
        
        this.registerType(4, {
            texture: 'osina_derevo.png',
            width: 1.0,
            height: 3.0,
            offsetY: 1.5,
            pixelScale: 0.03125,
            keepAspect: true,
            xSprite: true,
            fixedAngle: true,
            collision: true,
            collisionWidth: 0.4,
            collisionHeight: 2.0,
            extraSprites: [
                {
                    texture: 'osina_listva.png',
                    width: 1.0,
                    height: 3.0,
                    offsetY: 4.5,
                    pixelScale: 0.09375,
                    keepAspect: true,
                    xSprite: true,
                    fixedAngle: true,
                    data: {
                        name: 'Листва осины',
                        type: 'leaves'
                    }
                }
            ],
            data: {
                name: 'Осина с листвой',
                type: 'tree',
                health: 50
            }
        });
        
        this.registerType(11, {
            texture: 'iva_stvol.png',
            width: 1.0,
            height: 2.0,
            offsetY: 1.0,
            pixelScale: 0.03125,
            keepAspect: true,
            xSprite: true,
            fixedAngle: true,
            collision: true,
            collisionWidth: 0.4,
            collisionHeight: 2.0,
            data: {
                name: 'Ствол ивы',
                type: 'tree',
                health: 50
            }
        });
        
        this.registerType(10, {
            texture: 'iva_derevo.png',
            width: 1.0,
            height: 3.0,
            offsetY: 1.5,
            pixelScale: 0.03125,
            keepAspect: true,
            xSprite: true,
            fixedAngle: true,
            collision: true,
            collisionWidth: 0.4,
            collisionHeight: 2.0,
            extraSprites: [
                {
                    texture: 'iva_listva.png',
                    width: 1.0,
                    height: 3.0,
                    offsetY: 3.6,
                    pixelScale: 0.09375,
                    keepAspect: true,
                    xSprite: true,
                    fixedAngle: true,
                    data: {
                        name: 'Листва ивы',
                        type: 'leaves'
                    }
                }
            ],
            data: {
                name: 'Ива с листвой',
                type: 'tree',
                health: 50
            }
        });
        
        this.registerType(12, {
            texture: 'kandelyabr_napolniy.png',
            width: 0.5,
            height: 2.0,
            offsetY: 1.0,
            pixelScale: 0.03125,
            keepAspect: true,
            xSprite: true,
            fixedAngle: true,
            collision: true,
            collisionWidth: 0.4,
            collisionHeight: 2.0,
            animated: true,
            frameCount: 3,
            frameDuration: 0.75,
            data: {
                name: 'Напольный канделябр',
                type: 'candelabra',
                health: 30
            }
        });
        
        this.registerType(6, {
            texture: 'trava_niz_0.png',
            width: 1.0,
            height: 0.25,
            offsetY: 0.125,
            pixelScale: 0.03125,
            keepAspect: true,
            xSprite: true,
            fixedAngle: true,
            collision: false,
            data: {
                name: 'Трава низкая',
                type: 'grass_low',
                health: 10
            }
        });
        
        this.registerType(7, {
            texture: 'trava_sred_0.png',
            width: 1.0,
            height: 0.5,
            offsetY: 0.25,
            pixelScale: 0.03125,
            keepAspect: true,
            xSprite: true,
            fixedAngle: true,
            collision: false,
            data: {
                name: 'Трава средняя',
                type: 'grass_medium',
                health: 15
            }
        });
        
        this.registerType(9, {
            texture: 'trava_vis_0.png',
            variants: [
                'trava_vis_0.png',
                'trava_vis_1.png'
            ],
            width: 1.0,
            height: 1.0,
            offsetY: 0.5,
            pixelScale: 0.03125,
            keepAspect: true,
            xSprite: true,
            fixedAngle: true,
            collision: false,
            data: {
                name: 'Трава высокая',
                type: 'grass_high',
                health: 20
            }
        });
        
        // Дверь деревянная (ID 5)
        this.registerType(5, {
            texture: 'dver_derevo.png',
            width: 1.0,
            height: 1.5,
            offsetY: 0.75,
            pixelScale: 0.03125,
            keepAspect: true,
            xSprite: false,
            fixedAngle: true,
            collision: false,
            collisionWidth: 0.1,
            collisionHeight: 1.5,
            isDoor: true,
            data: {
                name: 'Дверь деревянная',
                type: 'door',
                doorTypeId: 5,
                isOpen: false
            }
        });
        
        // Дверь решётка (ID 16)
        this.registerType(16, {
            texture: 'dver_reshetka.png',
            width: 1.0,
            height: 1.5,
            offsetY: 0.75,
            pixelScale: 0.03125,
            keepAspect: true,
            xSprite: false,
            fixedAngle: true,
            collision: false,
            collisionWidth: 0.1,
            collisionHeight: 1.5,
            isDoor: true,
            data: {
                name: 'Дверь решётка',
                type: 'door',
                doorTypeId: 16,
                isOpen: false
            }
        });
        
        this.registerType(13, {
            texture: 'portal.png',
            width: 1.0,
            height: 1.0,
            offsetY: 0.5,
            pixelScale: 0.03125,
            keepAspect: true,
            xSprite: false,
            fixedAngle: false,
            collision: false,
            isPortal: true,
            data: {
                name: 'Портал',
                type: 'portal'
            }
        });
        
        this.registerType(14, {
            texture: 'ryaska.png',
            width: 1.0,
            height: 1.0,
            offsetY: 0.05,
            pixelScale: 0.03125,
            keepAspect: true,
            xSprite: false,
            fixedAngle: true,
            collision: false,
            isGround: true,
            data: {
                name: 'Ряска',
                type: 'duckweed'
            }
        });
        
        this.registerType(15, {
            texture: 'zabor_0.png',
            width: 1.0,
            height: 1.0,
            offsetY: 0.5,
            pixelScale: 0.03125,
            keepAspect: true,
            xSprite: false,
            fixedAngle: true,
            collision: false,
            isFence: true,
            data: {
                name: 'Забор',
                type: 'fence'
            }
        });
    }
    
    createSprite(col, row, typeId, extraData, textureId) {
        const type = this.spriteTypes[typeId];
        if (!type) {
            console.warn('Неизвестный тип спрайта:', typeId);
            return null;
        }
        
        // Двери (ID 5 и 16)
        if (typeId === 5 || typeId === 16) {
            const texture = this.textures[typeId];
            if (!texture) {
                console.warn('Текстура не загружена для спрайта:', typeId);
                return null;
            }
            return this.createDoor(col, row, texture, type, extraData);
        }
        
        if (typeId === 13) {
            return this.createPortal(col, row, type, extraData);
        }
        
        if (typeId === 14) {
            return this.createGroundSprite(col, row, typeId, textureId);
        }
        
        if (typeId === 15) {
            return this.createFence(col, row, type, extraData);
        }
        
        return super.createSprite(col, row, typeId, extraData, textureId);
    }
    
    createDoor(col, row, texture, type, extraData) {
        const doorData = extraData || {};
        const facing = doorData.facing || 'north';
        
        const x = col + 0.5;
        const z = row + 0.5;
        
        const typeId = type.data?.doorTypeId || 5;
        
        let width = type.width;
        let height = type.height;
        
        let texId = typeId;
        let texW, texH;
        if (this.textureSizes[5]) {
            texW = this.textureSizes[5].width;
            texH = this.textureSizes[5].height;
        }
        if (this.textureSizes[16]) {
            texW = this.textureSizes[16].width;
            texH = this.textureSizes[16].height;
        }
        const scale = type.pixelScale || 0.03125;
        if (texW) width = texW * scale;
        if (texH) height = texH * scale;
        
        const y = type.offsetY || height / 2;
        
        let axisX, axisZ, offsetX, offsetZ, groupAngle, meshAngle;
        
        switch(facing) {
            case 'north':
                axisX = 0;
                axisZ = 0.5;
                offsetX = 0.5;
                offsetZ = 0;
                groupAngle = 0;
                meshAngle = 0;
                break;
            case 'south':
                axisX = 1;
                axisZ = 0.5;
                offsetX = -0.5;
                offsetZ = 0;
                groupAngle = 0;
                meshAngle = Math.PI;
                break;
            case 'east':
                axisX = 0.5;
                axisZ = 0;
                offsetX = 0;
                offsetZ = 0.5;
                groupAngle = 0;
                meshAngle = -Math.PI / 2;
                break;
            case 'west':
                axisX = 0.5;
                axisZ = 1;
                offsetX = 0;
                offsetZ = -0.5;
                groupAngle = 0;
                meshAngle = Math.PI / 2;
                break;
            default:
                axisX = 0;
                axisZ = 0.5;
                offsetX = 0.5;
                offsetZ = 0;
                groupAngle = 0;
                meshAngle = 0;
        }
        
        const group = new THREE.Group();
        group.position.set(col + axisX, y, row + axisZ);
        group.rotation.y = 0;
        
        const geometry = new THREE.PlaneGeometry(width, height);
        const material = new THREE.MeshBasicMaterial({
            map: texture,
            transparent: true,
            side: THREE.DoubleSide,
            depthWrite: true,
            depthTest: true,
            alphaTest: 0.5
        });
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.set(offsetX, 0, offsetZ);
        mesh.rotation.y = meshAngle;
        group.add(mesh);
        
        this.scene.add(group);
        this.sprites.push(group);
        
        let hitWidth, hitDepth;
        if (facing === 'north' || facing === 'south') {
            hitWidth = 1.0;
            hitDepth = 0.1;
        } else {
            hitWidth = 0.1;
            hitDepth = 1.0;
        }
        
        group.userData = {
            isDoor: true,
            isOpen: false,
            facing: facing,
            col: col,
            row: row,
            fixedAngle: true,
            typeId: typeId,
            hitX: x,
            hitZ: z,
            hitWidth: hitWidth,
            hitDepth: hitDepth,
            hitHeight: height,
            mesh: mesh,
            startAngle: 0,
            meshStartAngle: meshAngle,
            axisX: axisX,
            axisZ: axisZ,
            offsetX: offsetX,
            offsetZ: offsetZ
        };
        
        this.doors.push(group);
        
        console.log(`✅ Дверь (ID ${typeId}) в (${col},${row}) смотрит на ${facing}, ось (${(col+axisX).toFixed(2)}, ${(row+axisZ).toFixed(2)})`);
        
        return group;
    }
    
    createFence(col, row, type, extraData) {
        const textureKey = 15;
        const texture = this.textures[textureKey];
        if (!texture) {
            console.warn('Текстура забора не загружена');
            return null;
        }
        
        const facing = extraData?.facing || 'north';
        
        const x = col + 0.5;
        const z = row + 0.5;
        const y = type.offsetY || 0.5;
        const width = type.width || 1.0;
        const height = type.height || 1.0;
        
        let angle = 0;
        if (facing === 'east' || facing === 'west') {
            angle = Math.PI / 2;
        }
        
        const geometry = new THREE.PlaneGeometry(width, height);
        const material = new THREE.MeshBasicMaterial({
            map: texture,
            transparent: true,
            side: THREE.DoubleSide,
            depthWrite: true,
            depthTest: true,
            alphaTest: 0.5
        });
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.set(x, y, z);
        mesh.rotation.y = angle;
        mesh.userData = {
            isFence: true,
            col: col,
            row: row,
            facing: facing,
            fixedAngle: true,
            typeId: 15,
            hitX: x,
            hitZ: z,
            hitWidth: (facing === 'north' || facing === 'south') ? 1.0 : 0.1,
            hitDepth: (facing === 'north' || facing === 'south') ? 0.1 : 1.0,
            hitHeight: height
        };
        this.scene.add(mesh);
        this.sprites.push(mesh);
        this.fences.push(mesh);
        return mesh;
    }
    
    createGroundSprite(col, row, typeId, textureId) {
        let textureKey = typeId;
        if (textureId && this.spriteTypes[typeId]?.variants?.length > 0) {
            const variantKey = typeId + '_' + textureId;
            if (this.textures[variantKey]) {
                textureKey = variantKey;
            }
        }
        
        const texture = this.textures[textureKey];
        if (!texture) {
            console.warn(`Текстура не загружена для спрайта: ${typeId}`);
            return null;
        }
        
        const type = this.spriteTypes[typeId];
        const x = col + 0.5;
        const z = row + 0.5;
        const y = type.offsetY || 0.05;
        
        let width = type.width || 1.0;
        let height = type.height || 1.0;
        
        if (type.keepAspect && this.textureSizes[textureKey]) {
            const texW = this.textureSizes[textureKey].width;
            const texH = this.textureSizes[textureKey].height;
            const scale = type.pixelScale || 0.01;
            width = texW * scale;
            height = texH * scale;
        }
        
        const geometry = new THREE.PlaneGeometry(width, height);
        const material = new THREE.MeshBasicMaterial({
            map: texture,
            transparent: true,
            side: THREE.DoubleSide,
            depthWrite: true,
            depthTest: true,
            alphaTest: 0.5
        });
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.set(x, y, z);
        mesh.rotation.x = -Math.PI / 2;
        mesh.userData = {
            isGround: true,
            col: col,
            row: row,
            typeId: typeId,
            fixedAngle: true
        };
        this.scene.add(mesh);
        this.sprites.push(mesh);
        return mesh;
    }
    
    createPortal(col, row, type, extraData) {
        console.log(`createPortal вызван для (${col},${row})`);
        
        const x = col + 0.5;
        const z = row + 0.5;
        const y = type.offsetY || 0.5;
        const width = 1.0;
        const height = 1.0;
        
        const targetX = extraData?.targetX || col + 0.5;
        const targetZ = extraData?.targetZ || row + 0.5;
        
        const portalData = {
            userData: {
                isPortal: true,
                col: col,
                row: row,
                targetX: targetX,
                targetZ: targetZ,
                fixedAngle: false,
                typeId: 13,
                mesh: null
            },
            position: { x: x, z: z }
        };
        
        const texture = this.textures[13];
        if (texture) {
            const geometry = new THREE.PlaneGeometry(width, height);
            const material = new THREE.MeshBasicMaterial({
                map: texture,
                transparent: true,
                side: THREE.DoubleSide,
                depthWrite: true,
                depthTest: true,
                alphaTest: 0.5
            });
            const mesh = new THREE.Mesh(geometry, material);
            mesh.position.set(x, y, z);
            mesh.userData = {
                isPortal: true,
                col: col,
                row: row,
                targetX: targetX,
                targetZ: targetZ,
                fixedAngle: false,
                typeId: 13
            };
            this.scene.add(mesh);
            this.sprites.push(mesh);
            portalData.userData.mesh = mesh;
            portalData.mesh = mesh;
        } else {
            console.warn(`Текстура портала не загружена, портал в (${col},${row}) будет невидимым, но будет работать`);
        }
        
        this.portals.push(portalData);
        
        console.log(`Портал создан в (${col},${row}) -> (${targetX}, ${targetZ})`);
        return portalData;
    }
    
    checkCollision(aabb) {
        const halfW = aabb.w / 2;
        const halfD = aabb.d / 2;
        
        const corners = [
            { x: aabb.x - halfW, z: aabb.z - halfD },
            { x: aabb.x + halfW, z: aabb.z - halfD },
            { x: aabb.x - halfW, z: aabb.z + halfD },
            { x: aabb.x + halfW, z: aabb.z + halfD }
        ];
        
        for (let corner of corners) {
            const col = Math.floor(corner.x);
            const row = Math.floor(corner.z);
            
            for (let door of this.doors) {
                if (door.userData.col === col && door.userData.row === row) {
                    if (door.userData.isOpen) continue;
                    
                    const doorAABB = {
                        x: door.userData.hitX,
                        y: door.userData.hitHeight / 2,
                        z: door.userData.hitZ,
                        w: door.userData.hitWidth,
                        h: door.userData.hitHeight,
                        d: door.userData.hitDepth
                    };
                    
                    if (Utils.aabbIntersect(aabb, doorAABB)) {
                        return true;
                    }
                    continue;
                }
            }
            
            for (let fence of this.fences) {
                if (fence.userData.col === col && fence.userData.row === row) {
                    const fenceAABB = {
                        x: fence.userData.hitX,
                        y: fence.userData.hitHeight / 2,
                        z: fence.userData.hitZ,
                        w: fence.userData.hitWidth,
                        h: fence.userData.hitHeight,
                        d: fence.userData.hitDepth
                    };
                    if (Utils.aabbIntersect(aabb, fenceAABB)) {
                        return true;
                    }
                    continue;
                }
            }
            
            const spriteData = this.getSpriteAt(col, row);
            if (spriteData) {
                const type = this.spriteTypes[spriteData.typeId];
                if (type && type.collision && !type.isDoor && !type.isPortal && !type.isGround && !type.isFence) {
                    const spriteAABB = {
                        x: col + 0.5,
                        y: type.collisionHeight / 2,
                        z: row + 0.5,
                        w: type.collisionWidth,
                        h: type.collisionHeight,
                        d: type.collisionWidth
                    };
                    if (Utils.aabbIntersect(aabb, spriteAABB)) {
                        return true;
                    }
                }
            }
        }
        
        const centerCol = Math.floor(aabb.x);
        const centerRow = Math.floor(aabb.z);
        
        for (let door of this.doors) {
            if (door.userData.col === centerCol && door.userData.row === centerRow) {
                if (door.userData.isOpen) continue;
                
                const doorAABB = {
                    x: door.userData.hitX,
                    y: door.userData.hitHeight / 2,
                    z: door.userData.hitZ,
                    w: door.userData.hitWidth,
                    h: door.userData.hitHeight,
                    d: door.userData.hitDepth
                };
                
                if (Utils.aabbIntersect(aabb, doorAABB)) {
                    return true;
                }
                continue;
            }
        }
        
        for (let fence of this.fences) {
            if (fence.userData.col === centerCol && fence.userData.row === centerRow) {
                const fenceAABB = {
                    x: fence.userData.hitX,
                    y: fence.userData.hitHeight / 2,
                    z: fence.userData.hitZ,
                    w: fence.userData.hitWidth,
                    h: fence.userData.hitHeight,
                    d: fence.userData.hitDepth
                };
                if (Utils.aabbIntersect(aabb, fenceAABB)) {
                    return true;
                }
                continue;
            }
        }
        
        const spriteData = this.getSpriteAt(centerCol, centerRow);
        if (spriteData) {
            const type = this.spriteTypes[spriteData.typeId];
            if (type && type.collision && !type.isDoor && !type.isPortal && !type.isGround && !type.isFence) {
                const spriteAABB = {
                    x: centerCol + 0.5,
                    y: type.collisionHeight / 2,
                    z: centerRow + 0.5,
                    w: type.collisionWidth,
                    h: type.collisionHeight,
                    d: type.collisionWidth
                };
                if (Utils.aabbIntersect(aabb, spriteAABB)) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    getSpriteAt(col, row) {
        if (!this.map || !this.map.data) return null;
        if (!this.map.data.isValidCell(col, row)) return null;
        if (!this.map.level || !this.map.level.objects) return null;
        
        const val = this.map.level.objects[row][col];
        const parsed = Utils.parseValue(val);
        if (parsed.value > 1) {
            return {
                typeId: parsed.value,
                textureId: parsed.textureId,
                value: parsed.value
            };
        }
        return null;
    }
    
    buildAll() {
        const width = this.map.width;
        const height = this.map.height;
        let created = 0;
        
        console.log('buildAll: начинаем обход карты');
        
        for (let row = 0; row < height; row++) {
            for (let col = 0; col < width; col++) {
                const val = this.map.level.objects[row][col];
                const parsed = Utils.parseValue(val);
                
                if (parsed.value === 8) continue;
                
                if (parsed.value > 1) {
                    let extraData = null;
                    let textureId = parsed.textureId || null;
                    
                    // Двери (ID 5 и 16)
                    if ((parsed.value === 5 || parsed.value === 16) && typeof val === 'string') {
                        const doorMatch = val.match(/^(\d+)\(l:([nsew])\)$/);
                        if (doorMatch) {
                            const facingMap = { 'n': 'north', 's': 'south', 'e': 'east', 'w': 'west' };
                            extraData = { facing: facingMap[doorMatch[2]] || 'north' };
                        } else {
                            extraData = { facing: 'north' };
                        }
                    }
                    
                    if (parsed.value === 13) {
                        console.log(`buildAll: найден портал в (${col},${row}), val: ${val}`);
                        if (typeof val === 'string') {
                            const portalMatch = val.match(/^13\(x:([\d.]+),z:([\d.]+)\)$/);
                            if (portalMatch) {
                                extraData = {
                                    targetX: parseFloat(portalMatch[1]),
                                    targetZ: parseFloat(portalMatch[2])
                                };
                            } else {
                                console.warn(`Некорректный формат портала в (${col},${row}): ${val}, ожидается 13(x:число,z:число)`);
                                extraData = { targetX: col + 0.5, targetZ: row + 0.5 };
                            }
                        } else if (typeof val === 'number') {
                            console.log(`Портал в (${col},${row}) без координат, ставим текущие`);
                            extraData = { targetX: col + 0.5, targetZ: row + 0.5 };
                        } else {
                            console.warn(`Портал в (${col},${row}) имеет непонятный формат: ${val}`);
                            extraData = { targetX: col + 0.5, targetZ: row + 0.5 };
                        }
                    }
                    
                    if (parsed.value === 15 && typeof val === 'string') {
                        const fenceMatch = val.match(/^15\(l:([nsew])\)$/);
                        if (fenceMatch) {
                            const facingMap = { 'n': 'north', 's': 'south', 'e': 'east', 'w': 'west' };
                            extraData = { facing: facingMap[fenceMatch[1]] || 'north' };
                        } else {
                            extraData = { facing: 'north' };
                        }
                    }
                    
                    this.createSprite(col, row, parsed.value, extraData, textureId);
                    created++;
                }
            }
        }
        
        console.log(`Создано объектов: ${created}, дверей: ${this.doors.length}, порталов: ${this.portals.length}, заборов: ${this.fences.length}`);
        return created;
    }
    
    clear() {
        super.clear();
        this.doors = [];
        this.portals = [];
        this.fences = [];
    }
}