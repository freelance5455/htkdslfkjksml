// Рендеринг

class Renderer {
    constructor() {
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x0a0a2e);
        
        this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 100);
        
        this.renderer = new THREE.WebGLRenderer({ 
            antialias: true 
        });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        document.body.appendChild(this.renderer.domElement);
        
        window.addEventListener('resize', () => this.resize());
    }
    
    update(player) {
        const eye = player.getEyePosition();
        this.camera.position.set(eye.x, eye.y, eye.z);
        this.camera.rotation.order = 'YXZ';
        this.camera.rotation.y = player.rotation;
        this.camera.rotation.x = 0;
    }
    
    render() {
        this.renderer.render(this.scene, this.camera);
    }
    
    resize() {
        const width = window.innerWidth;
        const height = window.innerHeight;
        this.camera.aspect = width / height;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(width, height);
    }
    
    get domElement() {
        return this.renderer.domElement;
    }
}