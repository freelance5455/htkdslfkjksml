// Управление интерфейсом (прицел, иконки действий)

class InterfaceManager {
    constructor() {
        this.actionIcons = null;
        this.actionIconsLoaded = false;
        this.iconSize = 16;
        this.crosshairElement = document.getElementById('crosshair');
        this.originalCrosshairHTML = null;
        this.currentIconIndex = -1;
        
        // Создаем прицел
        this.createCrosshair();
        
        // Загружаем иконки
        this.loadActionIcons();
    }
    
    createCrosshair() {
        if (!this.crosshairElement) return;
        
        // Создаем структуру прицела
        const left = document.createElement('div');
        left.id = 'crosshair-left';
        left.className = 'crosshair-part';
        
        const right = document.createElement('div');
        right.id = 'crosshair-right';
        right.className = 'crosshair-part';
        
        const bottom = document.createElement('div');
        bottom.id = 'crosshair-bottom';
        bottom.className = 'crosshair-part';
        
        const dot = document.createElement('div');
        dot.id = 'crosshair-dot';
        
        this.crosshairElement.appendChild(left);
        this.crosshairElement.appendChild(right);
        this.crosshairElement.appendChild(bottom);
        this.crosshairElement.appendChild(dot);
        
        // Сохраняем оригинальный HTML
        this.originalCrosshairHTML = this.crosshairElement.innerHTML;
    }
    
    // Загрузка иконок действий
    loadActionIcons(callback) {
        if (this.actionIconsLoaded) {
            if (callback) callback();
            return;
        }
        
        const img = new Image();
        img.onload = () => {
            this.actionIcons = img;
            this.actionIconsLoaded = true;
            console.log('Иконки действий загружены');
            if (callback) callback();
        };
        img.onerror = () => {
            console.warn('Не удалось загрузить иконки действий');
            this.actionIcons = null;
            this.actionIconsLoaded = true;
            if (callback) callback();
        };
        img.src = 'gamefiles/ikonki/ikonki_deystva.png';
    }
    
    // Получить иконку по индексу (0 - первая иконка)
    getActionIcon(index) {
        if (!this.actionIconsLoaded || !this.actionIcons) return null;
        
        const canvas = document.createElement('canvas');
        canvas.width = this.iconSize;
        canvas.height = this.iconSize;
        const ctx = canvas.getContext('2d');
        ctx.imageSmoothingEnabled = false;
        
        const sx = index * this.iconSize;
        const sy = 0;
        
        ctx.drawImage(
            this.actionIcons,
            sx, sy, this.iconSize, this.iconSize,
            0, 0, this.iconSize, this.iconSize
        );
        
        return canvas;
    }
    
    // Создать DOM элемент для иконки действия
    createActionIconElement(index, size) {
        const canvas = this.getActionIcon(index);
        if (!canvas) return null;
        
        const img = document.createElement('img');
        img.src = canvas.toDataURL('image/png');
        img.style.cssText = `
            width: ${size || 32}px;
            height: ${size || 32}px;
            image-rendering: pixelated;
            display: block;
            pointer-events: none;
        `;
        return img;
    }
    
    // Заменить прицел на иконку действия
    showActionIcon(index) {
        if (!this.crosshairElement) return;
        
        // Сохраняем оригинальный прицел, если еще не сохранен
        if (this.originalCrosshairHTML === null) {
            this.originalCrosshairHTML = this.crosshairElement.innerHTML;
        }
        
        // Если уже показана эта иконка - не пересоздаем
        if (this.currentIconIndex === index) return;
        
        // Создаем иконку
        const icon = this.createActionIconElement(index, 32);
        if (!icon) return;
        
        // Очищаем и вставляем иконку
        this.crosshairElement.innerHTML = '';
        this.crosshairElement.style.width = '32px';
        this.crosshairElement.style.height = '32px';
        this.crosshairElement.style.transform = 'translate(-50%, -50%)';
        this.crosshairElement.appendChild(icon);
        
        this.currentIconIndex = index;
    }
    
    // Восстановить прицел
    hideActionIcon() {
        if (!this.crosshairElement) return;
        
        if (this.originalCrosshairHTML !== null) {
            this.crosshairElement.innerHTML = this.originalCrosshairHTML;
            this.crosshairElement.style.width = '30px';
            this.crosshairElement.style.height = '30px';
            this.crosshairElement.style.transform = 'translate(-50%, -50%)';
        }
        
        this.currentIconIndex = -1;
    }
    
    // Проверить, показана ли иконка
    isActionIconShown() {
        return this.currentIconIndex >= 0;
    }
    
    // Получить текущий индекс иконки
    getCurrentIconIndex() {
        return this.currentIconIndex;
    }
}