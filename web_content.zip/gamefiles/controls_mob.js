// Управление для мобильных устройств
// Левая половина - движение (плавающий джойстик)
// Правая половина - поворот

class ControlsMob {
    constructor(player, renderer) {
        this.player = player;
        this.renderer = renderer;
        this.game = null;
        
        // Состояние джойстика
        this.joystick = {
            active: false,
            startX: 0,
            startY: 0,
            currentX: 0,
            currentY: 0,
            dx: 0,
            dy: 0,
            radius: 0,
            touchId: null
        };
        
        // Состояние поворота
        this.touchRotate = {
            active: false,
            startX: 0,
            lastX: 0,
            deltaX: 0,
            touchId: null
        };
        
        // Настройки
        this.maxRadius = 50;
        this.rotateSensitivity = 0.005;
        this.moveSpeed = 3.0;
        
        // Определяем устройство
        this.isMobile = this.detectMobile();
        
        if (this.isMobile) {
            this.setupTouchEvents();
            this.createMenuButton();
            this.createInteractButton();
            console.log('Мобильное управление активировано');
        } else {
            console.log('Мобильное управление неактивно (не мобильное устройство)');
        }
    }
    
    detectMobile() {
        return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ||
               window.innerWidth < 768;
    }
    
    createMenuButton() {
        this.menuBtn = document.createElement('div');
        this.menuBtn.id = 'mob-menu-btn';
        this.menuBtn.style.cssText = `
            position: fixed;
            top: 15px;
            left: 15px;
            width: 40px;
            height: 40px;
            z-index: 15;
            cursor: pointer;
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            touch-action: none;
            -webkit-tap-highlight-color: transparent;
            user-select: none;
        `;
        
        const lines = document.createElement('div');
        lines.style.cssText = `
            display: flex;
            flex-direction: column;
            gap: 4px;
            pointer-events: none;
        `;
        
        for (let i = 0; i < 3; i++) {
            const line = document.createElement('div');
            line.style.cssText = `
                width: 20px;
                height: 2px;
                background: rgba(255, 255, 255, 0.8);
                border-radius: 1px;
                pointer-events: none;
            `;
            lines.appendChild(line);
        }
        
        this.menuBtn.appendChild(lines);
        
        this.menuBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (this.game && this.game.menu) {
                this.game.menu.toggle();
            }
        });
        
        document.body.appendChild(this.menuBtn);
    }
    
    createInteractButton() {
        this.interactBtn = document.createElement('div');
        this.interactBtn.id = 'mob-interact-btn';
        this.interactBtn.style.cssText = `
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            z-index: 15;
            cursor: pointer;
            background: rgba(0, 0, 0, 0.5);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            touch-action: none;
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            border: 2px solid rgba(255, 255, 255, 0.3);
        `;
        
        // Иконка взаимодействия из спрайта (позиция 32, 16, размер 16x16)
        this.interactIcon = document.createElement('img');
        this.interactIcon.style.cssText = `
            width: 32px;
            height: 32px;
            image-rendering: pixelated;
            pointer-events: none;
        `;
        this.updateInteractIcon();
        this.interactBtn.appendChild(this.interactIcon);
        
        // Добавляем эффект нажатия
        this.interactBtn.addEventListener('touchstart', (e) => {
            e.preventDefault();
            this.interactBtn.style.transform = 'scale(0.85)';
            this.interactBtn.style.background = 'rgba(255, 255, 255, 0.2)';
        });
        
        this.interactBtn.addEventListener('touchend', (e) => {
            e.preventDefault();
            this.interactBtn.style.transform = 'scale(1)';
            this.interactBtn.style.background = 'rgba(0, 0, 0, 0.5)';
            this.onInteract();
        });
        
        this.interactBtn.addEventListener('touchcancel', (e) => {
            this.interactBtn.style.transform = 'scale(1)';
            this.interactBtn.style.background = 'rgba(0, 0, 0, 0.5)';
        });
        
        // Для мыши (тестирование на ПК)
        this.interactBtn.addEventListener('mousedown', () => {
            this.interactBtn.style.transform = 'scale(0.85)';
            this.interactBtn.style.background = 'rgba(255, 255, 255, 0.2)';
        });
        
        this.interactBtn.addEventListener('mouseup', () => {
            this.interactBtn.style.transform = 'scale(1)';
            this.interactBtn.style.background = 'rgba(0, 0, 0, 0.5)';
            this.onInteract();
        });
        
        this.interactBtn.addEventListener('mouseleave', () => {
            this.interactBtn.style.transform = 'scale(1)';
            this.interactBtn.style.background = 'rgba(0, 0, 0, 0.5)';
        });
        
        document.body.appendChild(this.interactBtn);
    }
    
    updateInteractIcon() {
        // Загружаем спрайт и вырезаем иконку на позиции 32, 16 (размер 16x16)
        const img = new Image();
        img.onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = 32;
            canvas.height = 32;
            const ctx = canvas.getContext('2d');
            // Растягиваем иконку 16x16 до 32x32 для четкости
            ctx.imageSmoothingEnabled = false;
            ctx.drawImage(img, 32, 16, 16, 16, 0, 0, 32, 32);
            this.interactIcon.src = canvas.toDataURL('image/png');
        };
        img.onerror = () => {
            // Если не загрузилось, используем текст
            this.interactIcon.style.display = 'none';
            this.interactBtn.textContent = 'F';
            this.interactBtn.style.color = '#fff';
            this.interactBtn.style.fontSize = '24px';
            this.interactBtn.style.fontWeight = 'bold';
        };
        img.src = 'gamefiles/ikonki/ikonki_deystva.png';
    }
    
    onInteract() {
        if (this.game) {
            this.game.interact();
        }
    }
    
    setupTouchEvents() {
        const canvas = this.renderer.domElement;
        
        canvas.addEventListener('touchstart', (e) => {
            e.preventDefault();
            const touches = e.touches;
            
            for (let i = 0; i < touches.length; i++) {
                const touch = touches[i];
                const rect = canvas.getBoundingClientRect();
                const x = touch.clientX - rect.left;
                const y = touch.clientY - rect.top;
                const halfWidth = rect.width / 2;
                
                if (x < halfWidth) {
                    if (!this.joystick.active) {
                        this.joystick.active = true;
                        this.joystick.touchId = touch.identifier;
                        this.joystick.startX = x;
                        this.joystick.startY = y;
                        this.joystick.currentX = x;
                        this.joystick.currentY = y;
                        this.joystick.dx = 0;
                        this.joystick.dy = 0;
                        this.joystick.radius = 0;
                    }
                }
                else {
                    if (!this.touchRotate.active) {
                        this.touchRotate.active = true;
                        this.touchRotate.touchId = touch.identifier;
                        this.touchRotate.startX = x;
                        this.touchRotate.lastX = x;
                        this.touchRotate.deltaX = 0;
                    }
                }
            }
        }, { passive: false });
        
        canvas.addEventListener('touchmove', (e) => {
            e.preventDefault();
            const touches = e.touches;
            
            for (let i = 0; i < touches.length; i++) {
                const touch = touches[i];
                const rect = canvas.getBoundingClientRect();
                const x = touch.clientX - rect.left;
                const y = touch.clientY - rect.top;
                const halfWidth = rect.width / 2;
                
                if (touch.identifier === this.joystick.touchId && this.joystick.active) {
                    this.joystick.currentX = x;
                    this.joystick.currentY = y;
                    
                    let dx = x - this.joystick.startX;
                    let dy = y - this.joystick.startY;
                    const radius = Math.sqrt(dx * dx + dy * dy);
                    
                    if (radius > this.maxRadius) {
                        const scale = this.maxRadius / radius;
                        dx *= scale;
                        dy *= scale;
                    }
                    
                    this.joystick.dx = dx / this.maxRadius;
                    this.joystick.dy = dy / this.maxRadius;
                    this.joystick.radius = Math.min(radius, this.maxRadius);
                }
                
                if (touch.identifier === this.touchRotate.touchId && this.touchRotate.active) {
                    const deltaX = x - this.touchRotate.lastX;
                    this.touchRotate.deltaX += deltaX;
                    this.touchRotate.lastX = x;
                }
            }
        }, { passive: false });
        
        canvas.addEventListener('touchend', (e) => {
            e.preventDefault();
            
            for (let i = 0; i < e.changedTouches.length; i++) {
                const touch = e.changedTouches[i];
                
                if (touch.identifier === this.joystick.touchId) {
                    this.joystick.active = false;
                    this.joystick.touchId = null;
                    this.joystick.dx = 0;
                    this.joystick.dy = 0;
                    this.joystick.radius = 0;
                }
                
                if (touch.identifier === this.touchRotate.touchId) {
                    this.touchRotate.active = false;
                    this.touchRotate.touchId = null;
                    this.touchRotate.deltaX = 0;
                }
            }
            
            if (e.touches.length > 0) {
                const remainingTouches = e.touches;
                let hasJoystickTouch = false;
                let hasRotateTouch = false;
                
                for (let i = 0; i < remainingTouches.length; i++) {
                    const touch = remainingTouches[i];
                    const rect = canvas.getBoundingClientRect();
                    const x = touch.clientX - rect.left;
                    const halfWidth = rect.width / 2;
                    
                    if (x < halfWidth) {
                        hasJoystickTouch = true;
                    } else {
                        hasRotateTouch = true;
                    }
                }
                
                if (!hasJoystickTouch) {
                    this.joystick.active = false;
                    this.joystick.touchId = null;
                    this.joystick.dx = 0;
                    this.joystick.dy = 0;
                    this.joystick.radius = 0;
                }
                
                if (!hasRotateTouch) {
                    this.touchRotate.active = false;
                    this.touchRotate.touchId = null;
                    this.touchRotate.deltaX = 0;
                }
            }
        }, { passive: false });
        
        canvas.addEventListener('touchcancel', (e) => {
            e.preventDefault();
            
            this.joystick.active = false;
            this.joystick.touchId = null;
            this.joystick.dx = 0;
            this.joystick.dy = 0;
            this.joystick.radius = 0;
            
            this.touchRotate.active = false;
            this.touchRotate.touchId = null;
            this.touchRotate.deltaX = 0;
        }, { passive: false });
    }
    
    update(delta) {
        if (!this.isMobile) return;
        
        if (this.joystick.active) {
            const dx = this.joystick.dx;
            const dy = this.joystick.dy;
            
            if (Math.abs(dy) > 0.1) {
                const speed = -dy * this.moveSpeed;
                this.player.moveForward(delta, speed);
            }
            
            if (Math.abs(dx) > 0.1) {
                const speed = -dx * this.moveSpeed;
                this.player.moveStrafe(delta, speed);
            }
        }
        
        if (this.touchRotate.active && Math.abs(this.touchRotate.deltaX) > 0.5) {
            const rotation = -this.touchRotate.deltaX * this.rotateSensitivity;
            this.player.rotate(rotation);
            this.touchRotate.deltaX = 0;
        }
    }
}