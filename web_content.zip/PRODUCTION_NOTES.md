# Phone-only architecture notes

The old VPS/MT5 bridge has been removed from the active Android project.

The Android app now performs strategy/risk calculations locally. Broker execution is intentionally handed to the official Exness/MT5 mobile application.

Do not add a broker master password to the APK.

If Exness provides a documented, authorized mobile trading API suitable for this account type, a future version could add an API client. Until that is verified, the project should not claim direct automatic broker execution.
