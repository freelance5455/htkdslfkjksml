# Production connection plan

The Android UI intentionally contains no live-trading implementation.

Recommended architecture:

Android APK
    |
    | HTTPS + authenticated requests
    v
Secure trading backend
    |
    | broker-supported API / bridge
    v
Exness / MT5

The backend should implement:
- account authentication
- XAUUSD market data
- EMA20/EMA50
- RSI14
- momentum
- volatility and spread filters
- risk-based volume calculation using broker symbol specifications
- daily loss guard
- max trades/day
- SL/TP
- order_check/order submission where supported
- position reconciliation
- idempotency
- audit logs
- encrypted secrets
- emergency stop

Never hard-code the user's MT5 password into the APK.
