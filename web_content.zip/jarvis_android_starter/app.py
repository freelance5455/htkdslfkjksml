import os
from flask import Flask, request, jsonify, send_from_directory
from google import genai
from google.genai import types

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder="static")
API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

SYSTEM_INSTRUCTION = """
Sen JARVIS'sin: Türkçe konuşan, açık, dikkatli ve yetenekli kişisel yapay zekâ asistanı.
Kullanıcıya Türkçe cevap ver. Bilmediğin bilgiyi uydurma; güncel bilgi gerekiyorsa
kaynak gerektiğini belirt. Kullanıcının özel verilerini gereksiz yere isteme.
Gerçek dünyada sonuç doğuracak işlemleri (mesaj gönderme, arama yapma, dosya silme,
satın alma, hesap ayarı değiştirme vb.) kendiliğinden yaptığını iddia etme.
Bu sürümde telefon üzerinde doğrudan işlem yapma yetkin yoktur. Böyle bir istek
gelirse yapılabilecek güvenli adımları açıkla ve kullanıcı onayı/Android entegrasyonu
gerektiğini belirt. API anahtarı, parola veya gizli bilgileri yanıtta gösterme.
Kısa ama yeterli cevap ver. Futbol tahminlerinde olasılıkları kesinlik gibi sunma.
"""

@app.get("/")
def home():
    return send_from_directory("static", "index.html")

@app.get("/manifest.json")
def manifest():
    return send_from_directory("static", "manifest.json")

@app.get("/sw.js")
def service_worker():
    return send_from_directory("static", "sw.js")

@app.get("/api/health")
def health():
    return jsonify({
        "ok": True,
        "assistant": "JARVIS",
        "ai_configured": bool(API_KEY),
        "model": MODEL if API_KEY else None
    })

@app.post("/api/chat")
def chat():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip()
    history = data.get("history", [])
    if not message:
        return jsonify({"ok": False, "error": "Mesaj boş olamaz."}), 400
    if len(message) > 12000:
        return jsonify({"ok": False, "error": "Mesaj çok uzun (en fazla 12.000 karakter)."}), 413

    if not API_KEY:
        return jsonify({
            "ok": True,
            "mode": "offline",
            "reply": "JARVIS temel modda çalışıyor. Yapay zekâ motorunu etkinleştirmek için Render ortam değişkenlerine GEMINI_API_KEY eklemelisin. API anahtarı eklenene kadar gelişmiş sohbet kullanılamaz."
        })

    try:
        client = genai.Client(api_key=API_KEY)
        contents = []
        # Son 12 mesajla bağlamı sınırla; istemciden gelen rol değerlerini doğrula.
        for item in history[-12:]:
            role = item.get("role")
            text = str(item.get("text", ""))[:5000]
            if role in ("user", "model") and text:
                contents.append(types.Content(
                    role=role,
                    parts=[types.Part.from_text(text=text)]
                ))
        contents.append(types.Content(
            role="user",
            parts=[types.Part.from_text(text=message)]
        ))
        response = client.models.generate_content(
            model=MODEL,
            contents=contents,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_INSTRUCTION,
                temperature=0.6,
                max_output_tokens=1200
            )
        )
        answer = (response.text or "").strip()
        if not answer:
            answer = "Şu anda yanıt oluşturamadım. Biraz sonra tekrar dener misin?"
        return jsonify({"ok": True, "mode": "ai", "reply": answer})
    except Exception as exc:
        # Anahtar veya sağlayıcı ayrıntılarını istemciye döndürme.
        app.logger.exception("Gemini request failed")
        return jsonify({
            "ok": False,
            "error": "Yapay zekâ servisine ulaşılamadı. API anahtarını, model adını ve kullanım limitini kontrol et."
        }), 502

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")))
