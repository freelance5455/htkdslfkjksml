X17 Ultra Camera - Web Target
===============================
Ini adalah versi web/PWA-style yang bisa dibuka langsung tanpa Android Studio.

Cara pakai:
1. Ekstrak ZIP.
2. Buka index.html di browser yang mendukung getUserMedia.
3. Izinkan kamera dan mikrofon.
4. Foto memakai tombol shutter.
5. Video memakai mode Video lalu shutter.
6. Tombol zoom memakai digital crop browser.

Batasan:
- Ini BUKAN kamera native Android.
- Browser tidak dapat menjamin akses ke ISP, RAW, 50MP, Camera2, 10-bit, HDR10+, Dolby Vision, atau stabilisasi proprietary Xiaomi.
- Tombol HDR adalah kontrol UI; versi web tidak boleh mengklaim hasil Dolby Vision.
- Untuk kualitas maksimal di Xiaomi 17T Pro, diperlukan aplikasi Android native yang memakai Camera2/MediaCodec dan API vendor.

Versi: 1.0 Web Target
