GOLDENCAREER — PROTOTYPE ANDROID

Fonctionnalités incluses :
- Jeu solo hors ligne
- Profil joueur de départ (16 ans, GEN 58)
- Choix de contrat entre Lille, PSG et Dortmund
- Simulation automatique des matchs et des saisons
- Événements de carrière avec décisions A/B : coach, agent, sponsor, sélection, prêt
- Les décisions modifient la note, la réputation ou la valeur marchande
- Statistiques et historique de carrière
- Sauvegarde locale sur l'appareil

Le dossier app/src/main/assets/index.html contient le jeu.
Pour tester sans compiler : ouvrez index.html dans un navigateur Android.
Pour générer l'APK : ouvrez ce projet dans Android Studio, laissez Gradle synchroniser, puis Build > Build Bundle(s) / APK(s) > Build APK(s).

Compatibilité prévue : Android 9 (API 28) et versions ultérieures.
Le projet est un prototype ; Android Studio/SDK est nécessaire pour produire le fichier APK.
