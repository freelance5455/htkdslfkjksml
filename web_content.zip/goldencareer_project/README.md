# GoldenCareer Android Project


## Version 3 — Mercato, prêts et Ballon d'Or
Cette version ajoute :
- Six championnats européens simulés : Ligue 1, Premier League, LaLiga, Bundesliga, Serie A et Eredivisie.
- Mercato avec génération d'offres, changement de club et négociation d'un nouveau salaire.
- Négociation de prolongation de contrat.
- Prêts temporaires avec retour au club d'origine à la fin de la saison.
- Course au Ballon d'Or basée sur la note générale, les buts, les passes décisives, la réputation et les trophées.
- Sauvegarde locale hors ligne, avec compatibilité de migration des anciennes sauvegardes.

Les clubs, transferts, calendriers et résultats sont simulés dans le jeu. Ce prototype n'est pas relié aux bases de données officielles ni à des résultats réels.
