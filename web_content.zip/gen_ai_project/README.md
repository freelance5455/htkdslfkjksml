# Gen AI — bezpečný startovací projekt

## Co obsahuje
- `public/`: responzivní HTML rozhraní, PWA manifest, ikona a offline shell.
- `server/server.mjs`: malý Node.js backend, který drží tajný klíč mimo prohlížeč.
- `server/.env.example`: vzor proměnných prostředí; skutečné klíče do HTML nepatří.

## Důležité limity
Toto je startovací projekt, nikoli hotová produkční služba. Chat bude odpovídat až po nastavení kompatibilního AI endpointu. Podpora obrázků a generování kompletních aplikací vyžaduje další endpointy/nástroje. Bezplatné kvóty poskytovatelů se mění; žádný trvale bezplatný výkon nelze zaručit.

## Lokální spuštění frontendu
Z kořenové složky projektu spusť jednoduchý statický server, například:
`python -m http.server 8080 --directory public`
Otevři `http://localhost:8080`.

## Backend
Vyžaduje Node.js 20 nebo novější.
1. Zkopíruj `server/.env.example` do `server/.env` a doplň údaje od poskytovatele, kterému důvěřuješ.
2. Proměnné prostředí nastav v terminálu nebo ve svém hostingovém prostředí; samotný soubor `.env` není automaticky načítán tímto minimalistickým serverem.
3. Nastav `AI_MODEL_URL` na oficiální OpenAI-kompatibilní Chat Completions endpoint a `AI_MODEL_NAME` na model dostupný u daného poskytovatele.
4. Spusť server s proměnnými prostředí nastavenými v shellu:
   `node server/server.mjs`
5. Ve webovém rozhraní nastav backend URL na `http://localhost:8787/api/chat` (pro lokální test). Frontend a backend běžící na jiných portech mají odlišný origin; nastav `ALLOWED_ORIGIN` na adresu frontendu.
6. Pro veřejné nasazení použij HTTPS, autentizaci, rate limiting, monitoring nákladů, ochranu proti prompt injection a zásady mazání dat. Přidej správné CORS nastavení. Nezpřístupňuj backend anonymně na internetu.

## Android
PWA lze otevřít v Android Chrome a přes nabídku prohlížeče zvolit „Přidat na plochu“ / „Instalovat aplikaci“. Pro instalaci jako PWA je obvykle nutné HTTPS nebo localhost. Pro publikování na Google Play bude potřeba další krok (např. Trusted Web Activity / Android wrapper) a splnění požadavků Google Play.

## Bezpečnostní poznámka
- Nepoužívej neznámé proxy služby.
- Neposílej citlivé údaje do AI.
- Serverový kód je demonstrace; před veřejným nasazením doplň autentizaci, limity požadavků, správu tajných klíčů a testy.
- Aktualizace aplikace mají být verzované, testované a ručně schválené. Automatické sebe-upravování produkčního kódu není bezpečný výchozí režim.
