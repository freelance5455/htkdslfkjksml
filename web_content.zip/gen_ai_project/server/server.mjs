// Gen AI backend starter — Node.js 20+, no framework required.
// Keeps the provider API key on the server. Configure a trusted provider yourself.
import http from "node:http";

const PORT = Number(process.env.PORT || 8787);
const API_KEY = process.env.AI_API_KEY || "";
const MODEL_URL = process.env.AI_MODEL_URL || ""; // Trusted provider endpoint only
const MODEL_NAME = process.env.AI_MODEL_NAME || "";
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || "http://localhost:8080";

const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin || "";
  res.setHeader("Vary", "Origin");
  if (origin === ALLOWED_ORIGIN) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  }
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("Cache-Control", "no-store");

  if (req.method === "OPTIONS") { res.writeHead(204); return res.end(); }
  if (req.url !== "/api/chat" || req.method !== "POST") {
    res.writeHead(404, {"Content-Type":"application/json"}); return res.end(JSON.stringify({error:"Not found"}));
  }
  if (origin && origin !== ALLOWED_ORIGIN) {
    res.writeHead(403, {"Content-Type":"application/json"}); return res.end(JSON.stringify({error:"Origin not allowed"}));
  }
  if (!API_KEY || !MODEL_URL || !MODEL_NAME) {
    res.writeHead(503, {"Content-Type":"application/json"}); return res.end(JSON.stringify({error:"Backend needs AI_API_KEY, AI_MODEL_URL and AI_MODEL_NAME configuration."}));
  }

  let raw = "";
  for await (const chunk of req) {
    raw += chunk;
    if (raw.length > 200_000) {
      res.writeHead(413, {"Content-Type":"application/json"}); return res.end(JSON.stringify({error:"Request too large"}));
    }
  }
  let body;
  try { body = JSON.parse(raw || "{}"); } catch {
    res.writeHead(400, {"Content-Type":"application/json"}); return res.end(JSON.stringify({error:"Invalid JSON"}));
  }
  if (typeof body.message !== "string" || !body.message.trim() || body.message.length > 12000) {
    res.writeHead(400, {"Content-Type":"application/json"}); return res.end(JSON.stringify({error:"Message must be 1–12000 characters."}));
  }

  try {
    // Adapter assumes an OpenAI-compatible Chat Completions API.
    // Check your provider's current API format before using it.
    const upstream = await fetch(MODEL_URL, {
      method: "POST",
      headers: { "Content-Type":"application/json", "Authorization":`Bearer ${API_KEY}` },
      body: JSON.stringify({
        model: MODEL_NAME,
        messages: [
          { role:"system", content:"You are Gen AI, a helpful assistant. Never claim you have executed code unless you actually have." },
          { role:"user", content: body.message }
        ],
        temperature: 0.6
      }),
      signal: AbortSignal.timeout(45000)
    });
    if (!upstream.ok) {
      res.writeHead(502, {"Content-Type":"application/json"});
      return res.end(JSON.stringify({error:"AI provider request failed", status:upstream.status}));
    }
    const data = await upstream.json();
    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== "string") throw new Error("Unexpected provider response");
    res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
    res.end(JSON.stringify({reply}));
  } catch (err) {
    res.writeHead(502, {"Content-Type":"application/json"});
    res.end(JSON.stringify({error:"Could not reach AI provider"}));
  }
});
server.listen(PORT, () => console.log(`Gen AI backend listening on http://localhost:${PORT}`));
