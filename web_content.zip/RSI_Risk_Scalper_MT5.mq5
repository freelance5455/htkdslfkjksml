//+------------------------------------------------------------------+
//| RSI Scalper Risk-Controlled EA - MT5                             |
//| Based on the supplied RSI scalping template                      |
//| Educational/testing software. No profit guarantee.               |
//+------------------------------------------------------------------+
#property strict
#property version   "1.00"

#include <Trade/Trade.mqh>
CTrade trade;

input double LotSize              = 0.01;
input double LotIncrement         = 0.01;
input double MaxLotSize           = 0.50;
input int    RSIPeriod            = 14;
input double BuyLevel             = 30.0;
input double SellLevel            = 70.0;
input int    StopLossPoints       = 100;
input int    TakeProfitPoints     = 150;
input int    MaxOpenTrades        = 1;
input int    MaxTradesPerMinute   = 30;
input int    CooldownSeconds      = 1;
input int    MaxSpreadPoints      = 30;
input double MaxDailyLossPct      = 3.0;
input double MaxDrawdownPct       = 10.0;
input int    MaxConsecutiveLosses = 3;
input bool   ResetLotAfterLoss    = true;
input bool   StopOnRiskLimit      = true;
input int    DeviationPoints      = 10;
input int    MagicNumber          = 26091701;
input bool   UseAsyncOrders       = false; // safer default=false; async can reduce waiting

int rsiHandle = INVALID_HANDLE;
double nextLot = 0.01;
double dayStartBalance = 0.0;
bool tradingEnabled = true;
int consecutiveLosses = 0;
datetime lastTradeTime = 0;
datetime minuteBucket = 0;
int tradesThisMinute = 0;
ulong lastProcessedDeal = 0;

//--- normalize lot to symbol constraints
double NormalizeLot(double lots)
{
   double minLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double step   = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   double cap    = MathMin(maxLot, MaxLotSize);

   lots = MathMax(minLot, MathMin(lots, cap));
   if(step > 0)
      lots = MathFloor(lots / step + 1e-9) * step;

   int digits = 2;
   if(step > 0.001) digits = 2;
   else if(step > 0.0001) digits = 3;
   else digits = 4;
   return NormalizeDouble(lots, digits);
}

int CountOpenTrades()
{
   int count = 0;
   for(int i=PositionsTotal()-1; i>=0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket==0) continue;
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      if((int)PositionGetInteger(POSITION_MAGIC)!=MagicNumber) continue;
      count++;
   }
   return count;
}

double TodayClosedProfit()
{
   double p=0.0;
   datetime start=StringToTime(TimeToString(TimeCurrent(),TIME_DATE));
   if(!HistorySelect(start, TimeCurrent())) return 0.0;

   int deals=HistoryDealsTotal();
   for(int i=0;i<deals;i++)
   {
      ulong d=HistoryDealGetTicket(i);
      if(d==0) continue;
      if(HistoryDealGetString(d,DEAL_SYMBOL)!=_Symbol) continue;
      if((int)HistoryDealGetInteger(d,DEAL_MAGIC)!=MagicNumber) continue;
      long entry=HistoryDealGetInteger(d,DEAL_ENTRY);
      if(entry!=DEAL_ENTRY_OUT && entry!=DEAL_ENTRY_OUT_BY) continue;
      p += HistoryDealGetDouble(d,DEAL_PROFIT)
         + HistoryDealGetDouble(d,DEAL_SWAP)
         + HistoryDealGetDouble(d,DEAL_COMMISSION);
   }
   return p;
}

double CurrentDrawdownPct()
{
   double bal=AccountInfoDouble(ACCOUNT_BALANCE);
   double eq =AccountInfoDouble(ACCOUNT_EQUITY);
   if(bal<=0) return 0.0;
   return MathMax(0.0,(bal-eq)/bal*100.0);
}

void ProcessClosedDeals()
{
   datetime start=0;
   if(!HistorySelect(start,TimeCurrent())) return;

   int deals=HistoryDealsTotal();
   ulong newest=lastProcessedDeal;
   double net=0.0;
   bool found=false;

   for(int i=deals-1;i>=0;i--)
   {
      ulong d=HistoryDealGetTicket(i);
      if(d==0 || d<=lastProcessedDeal) continue;
      if(HistoryDealGetString(d,DEAL_SYMBOL)!=_Symbol) continue;
      if((int)HistoryDealGetInteger(d,DEAL_MAGIC)!=MagicNumber) continue;

      long entry=HistoryDealGetInteger(d,DEAL_ENTRY);
      if(entry!=DEAL_ENTRY_OUT && entry!=DEAL_ENTRY_OUT_BY) continue;

      if(d>newest)
      {
         newest=d;
         net=HistoryDealGetDouble(d,DEAL_PROFIT)
            +HistoryDealGetDouble(d,DEAL_SWAP)
            +HistoryDealGetDouble(d,DEAL_COMMISSION);
         found=true;
      }
   }

   if(!found) return;
   lastProcessedDeal=newest;

   if(net>0.0)
   {
      consecutiveLosses=0;
      nextLot=NormalizeLot(nextLot+LotIncrement);
   }
   else if(net<0.0)
   {
      consecutiveLosses++;
      if(ResetLotAfterLoss) nextLot=NormalizeLot(LotSize);
   }

   if(consecutiveLosses>=MaxConsecutiveLosses && StopOnRiskLimit)
      tradingEnabled=false;
}

bool RiskOK()
{
   if(!tradingEnabled) return false;

   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   double point=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   if(point<=0) return false;

   double spread=(ask-bid)/point;
   if(spread>MaxSpreadPoints) return false;

   double daily=TodayClosedProfit();
   if(dayStartBalance>0 && daily<0)
   {
      double lossPct=(-daily/dayStartBalance)*100.0;
      if(lossPct>=MaxDailyLossPct)
      {
         tradingEnabled=false;
         return false;
      }
   }

   if(CurrentDrawdownPct()>=MaxDrawdownPct)
   {
      tradingEnabled=false;
      return false;
   }

   if(CountOpenTrades()>=MaxOpenTrades) return false;

   datetime now=TimeCurrent();
   if(now-minuteBucket>=60)
   {
      minuteBucket=now;
      tradesThisMinute=0;
   }
   if(tradesThisMinute>=MaxTradesPerMinute) return false;
   if(now-lastTradeTime<CooldownSeconds) return false;

   nextLot=NormalizeLot(nextLot);

   double margin=0.0;
   if(!OrderCalcMargin(ORDER_TYPE_BUY,_Symbol,nextLot,ask,margin)) return false;
   if(AccountInfoDouble(ACCOUNT_FREEMARGIN)<=margin) return false;

   return true;
}

bool OpenBuy()
{
   if(!RiskOK()) return false;

   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double point=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   double sl=(StopLossPoints>0 ? ask-StopLossPoints*point : 0);
   double tp=(TakeProfitPoints>0 ? ask+TakeProfitPoints*point : 0);
   int digits=(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS);

   sl=NormalizeDouble(sl,digits);
   tp=NormalizeDouble(tp,digits);

   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(DeviationPoints);
   trade.SetAsyncMode(UseAsyncOrders);

   bool ok=trade.Buy(NormalizeLot(nextLot),_Symbol,0.0,sl,tp,"RSI-RISK");
   if(!ok)
   {
      Print("Buy failed. Retcode=",trade.ResultRetcode()," ",trade.ResultRetcodeDescription());
      return false;
   }
   lastTradeTime=TimeCurrent();
   tradesThisMinute++;
   return true;
}

bool OpenSell()
{
   if(!RiskOK()) return false;

   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
   double point=SymbolInfoDouble(_Symbol,SYMBOL_POINT);
   double sl=(StopLossPoints>0 ? bid+StopLossPoints*point : 0);
   double tp=(TakeProfitPoints>0 ? bid-TakeProfitPoints*point : 0);
   int digits=(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS);

   sl=NormalizeDouble(sl,digits);
   tp=NormalizeDouble(tp,digits);

   trade.SetExpertMagicNumber(MagicNumber);
   trade.SetDeviationInPoints(DeviationPoints);
   trade.SetAsyncMode(UseAsyncOrders);

   bool ok=trade.Sell(NormalizeLot(nextLot),_Symbol,0.0,sl,tp,"RSI-RISK");
   if(!ok)
   {
      Print("Sell failed. Retcode=",trade.ResultRetcode()," ",trade.ResultRetcodeDescription());
      return false;
   }
   lastTradeTime=TimeCurrent();
   tradesThisMinute++;
   return true;
}

int OnInit()
{
   rsiHandle=iRSI(_Symbol,PERIOD_CURRENT,RSIPeriod,PRICE_CLOSE);
   if(rsiHandle==INVALID_HANDLE)
   {
      Print("Failed to create RSI handle.");
      return INIT_FAILED;
   }

   dayStartBalance=AccountInfoDouble(ACCOUNT_BALANCE);
   nextLot=NormalizeLot(LotSize);
   minuteBucket=TimeCurrent();
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   if(rsiHandle!=INVALID_HANDLE)
      IndicatorRelease(rsiHandle);
}

void OnTick()
{
   ProcessClosedDeals();

   if(!tradingEnabled) return;
   if(CountOpenTrades()>=MaxOpenTrades) return;
   if(!RiskOK()) return;

   double rsiBuffer[1];
   if(CopyBuffer(rsiHandle,0,0,1,rsiBuffer)!=1) return;
   double rsi=rsiBuffer[0];

   if(rsi<=BuyLevel)
   {
      OpenBuy();
      return;
   }

   if(rsi>=SellLevel)
   {
      OpenSell();
      return;
   }
}
