/* ============================================================
   PENGGILAS — DETERMINATION RULE DEFINITIONS
   Declarative links only. No BaZi formula is implemented here.
   Each definition points to existing Core B/C evidence/status.
   ============================================================ */
(function (global) {
  "use strict";

  const D = {
    DAY_MASTER_STRENGTH: {
      contextKey: "dayMasterStrength", claimId: "DAY_MASTER_STRENGTH",
      title: "Day-Master Strength (旺衰) — evidence reconciliation",
      conditionDescription: "Classical Day-Master Strength (旺衰) evidence: Month Command, root quality, support/counter evidence, and source-based qualitative synthesis.",
      conditionChecks: [
        { name: "B1 strength evidence present", path: "B1.strength.result", test: "present" },
        { name: "B1 root evidence present", path: "B1.root.result", test: "present" },
        { name: "B1 resolution status reported", path: "B1._strengthResolutionStatus", test: "reported" },
        { name: "B1 Classical synthesis basis present", path: "B1.determination.evidence", test: "present" },
        { name: "B1 Zi Ping adjudication present", path: "B1._classicalAdjudication", test: "present" },
        { name: "B1 determination status closed or explicitly unresolved", path: "B1._strengthResolutionStatus", test: "reported" }
      ],
      closureChecks: [
        { name: "B1 qualitative closure gate is explicit", condition: { path: "B1._strengthClosureGate.status", equals: "CLOSED" } },
        { name: "B1 resolution status is FINAL", condition: { path: "B1._strengthResolutionStatus", equals: "FINAL" } }
      ],
      evidence: [
        { id: "DAY_MASTER_STRENGTH_EVIDENCE_01", section: "B1", field: "strength", path: "B1.strength.result" },
        { id: "DAY_MASTER_STRENGTH_EVIDENCE_02", section: "B1", field: "root", path: "B1.root.result" },
        { id: "DAY_MASTER_STRENGTH_EVIDENCE_03", section: "B1", field: "resolutionStatus", path: "B1._strengthResolutionStatus" }
      ],
      statusPath: "B1._strengthResolutionStatus",
      outcomePath: "B1.strength.result",
      inputs: ["A7", "A8", "A11", "B1", "B2"],
      challenges: [
        { when: { path: "B1._classicalCounterSignals", gt: 0 }, text: "Core B1 reports counter-evidence against an unqualified strength conclusion." }
      ],
      blockingCondition: "Final Day-Master Strength (旺衰) remains open when the configured Zi Ping qualitative hierarchy cannot reconcile Month Command, root, supporting evidence and counter-evidence into one direction.",
      auditDetail: "B1 executes the configured Zi Ping qualitative hierarchy; it does not invent a numeric score or threshold.",
      crossCheckVerified: null
    },

    CHART_PATTERN: {
      contextKey: "chartPattern", claimId: "CHART_PATTERN",
      title: "Chart Pattern / Ge Ju (格局) — evidence reconciliation",
      conditionDescription: "Existing Core B3 pattern candidate, formation, breaking, and determination state.",
      conditionChecks: [
        { name: "B3 candidate evidence present", path: "B3.candidate.result", test: "present" },
        { name: "B3 formation evidence present", path: "B3.formation.result", test: "present" },
        { name: "B3 determination status reported", path: "B3._determinationStatus", test: "reported" }
      ],
      evidence: [
        { id: "CHART_PATTERN_EVIDENCE_01", section: "B3", field: "candidate", path: "B3.candidate.result" },
        { id: "CHART_PATTERN_EVIDENCE_02", section: "B3", field: "formation", path: "B3.formation.result" },
        { id: "CHART_PATTERN_EVIDENCE_03", section: "B3", field: "determinationStatus", path: "B3._determinationStatus" }
      ],
      statusPath: "B3._determinationStatus",
      outcomePath: "B3.final.result",
      inputs: ["B2", "B3", "B7", "B9"],
      challenges: [
        { when: { path: "B3._specialPatternStatus", equals: "SCREENED" }, text: "A special-pattern screen exists; full Formation / Breaking / Rescue (成格/败格/救应) closure remains owned by the applicable rule set." }
      ],
      blockingCondition: "Core B3 remains provisional unless its own authoritative rule status closes the pattern.",
      auditDetail: "B3 remains authoritative for Ge Ju mechanics; determination only reconciles its reported state.",
      crossCheckVerified: null
    },

    TRANSFORMATION_FOLLOWING: {
      contextKey: "transformationFollowing", claimId: "TRANSFORMATION_FOLLOWING",
      title: "Transformation / Hua and Following / Cong (化格 / 从格) — evidence reconciliation",
      conditionDescription: "Existing Core B8 Hua screen and Core B3 special-structure state.",
      conditionChecks: [
        { name: "B8 status evidence present", path: "B8.status.result", test: "present" },
        { name: "B8 condition evidence present", path: "B8.condition.result", test: "present" },
        { name: "B8 transformation status reported", path: "B8.status.result", test: "reported" }
      ],
      evidence: [
        { id: "TRANSFORMATION_FOLLOWING_EVIDENCE_01", section: "B8", field: "status", path: "B8.status.result" },
        { id: "TRANSFORMATION_FOLLOWING_EVIDENCE_02", section: "B8", field: "condition", path: "B8.condition.result" },
        { id: "TRANSFORMATION_FOLLOWING_EVIDENCE_03", section: "B3", field: "specialPatternStatus", path: "B3._specialPatternStatus" }
      ],
      statusPath: "B8.status.result",
      outcomePath: "B8.status.result",
      inputs: ["B1", "B3", "B8", "A12_6", "A12_7"],
      challenges: [
        { when: { path: "B8.status.result", matches: "BLOCKED|UNCONFIRMED|He only" }, text: "Core B8 does not confirm a Hua transformation." }
      ],
      blockingCondition: "Core B8 exposes a screen, not an authoritative closed Hua/Cong determination.",
      auditDetail: "He detection remains separate from Hua; determination does not add a He→Hua formula or chart-specific precedent.",
      crossCheckVerified: null
    },

    USEFUL_ELEMENT: {
      contextKey: "usefulElement", claimId: "USEFUL_ELEMENT",
      title: "Yong Shen / Useful God (用神) — multi-method evidence reconciliation",
      conditionDescription: "Existing Core B13 method candidates, Yong Shen result, and determination state.",
      conditionChecks: [
        { name: "B13 method candidates present", path: "B13.methodCandidates.result", test: "present" },
        { name: "B13 Yong Shen result present", path: "B13.yongShen.result", test: "present" },
        { name: "B13 determination status reported", path: "B13._determinationStatus", test: "reported" },
        { name: "B13 reconciliation status reported", path: "B13.reconciliation.status", test: "reported" },
        { name: "B13 open method gate exposed", path: "B13.reconciliation.openMethodCandidates", test: "present" }
      ],
      evidence: [
        { id: "USEFUL_ELEMENT_EVIDENCE_01", section: "B13", field: "methodCandidates", path: "B13.methodCandidates.result" },
        { id: "USEFUL_ELEMENT_EVIDENCE_02", section: "B13", field: "yongShen", path: "B13.yongShen.result" },
        { id: "USEFUL_ELEMENT_EVIDENCE_03", section: "B13", field: "determinationStatus", path: "B13._determinationStatus" }
      ],
      statusPath: "B13._determinationStatus",
      outcomePath: "B13.yongShen.result",
      inputs: ["B1", "B3", "B13"],
      challenges: [
        { when: { path: "B13._methodConflict", equals: true }, text: "Core B13 reports conflicting method candidates; no silent winner is selected." },
        { when: { path: "B13.reconciliation.status", matches: "OPEN|PARTIAL_AGREEMENT|MULTI_METHOD" }, text: "One or more Yong-Shen methods remain open or non-identical; no unique Useful God (用神) is selected." }
      ],
      blockingCondition: "Core B13 does not expose a unique authoritative Yong Shen closure.",
      auditDetail: "B13 remains authoritative for multi-method Yong Shen candidates; determination does not select a new winner.",
      crossCheckVerified: null
    }
  };

  global.PENGGILAS_DETERMINATION_RULES = {
    version: "2.3-CLOSURE-GATED",
    order: ["DAY_MASTER_STRENGTH", "CHART_PATTERN", "TRANSFORMATION_FOLLOWING", "USEFUL_ELEMENT"],
    rules: D
  };
})(window);
