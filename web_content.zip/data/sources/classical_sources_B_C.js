/* PENGGILAS — Classical Source Registry for B/C
 * Source pool: dominant/common Zi Ping classical corpus.
 * This file records provenance and role only; it does not calculate.
 */
(function (global) {
  "use strict";
  global.PENGGILAS_BC_SOURCES = {
    version: "BC-SOURCES-1.4-CHINA-CROSSCHECK",
    policy: "Prefer cross-source common core; preserve source-specific variants; never silently blend conflicts.",
    sources: [
      { id:"ZPZQ", title:"Mastery of Zi Ping (子平真诠)", english:"Mastery of Zi Ping", pinyin:"Zi Ping Zhen Quan", hanzi:"子平真诠", role:"Month Command, Ge Ju, Yong Shen, Cheng/Bai/Jiu Ying, Yang Ren, Jian Lu/Yue Jie", authority:"CORE", url:"https://tool.shixingji.club/library/zipingzhenquan" },
      { id:"DTT", title:"Subtle Secrets of the Heavenly Marrow (滴天髓)", english:"Subtle Secrets of the Heavenly Marrow", pinyin:"Di Tian Sui", hanzi:"滴天髓", role:"Wang/Shuai, Qi flow, body/use, special structures, Hua and transformation principles", authority:"CORE", url:"https://zh.wikisource.org/zh-hans/%E6%BB%B4%E5%A4%A9%E9%AB%93" },
      { id:"QTBJ", title:"Exhaustive Analysis of Seasonal Balance (穷通宝鉴)", english:"Exhaustive Analysis of Seasonal Balance", pinyin:"Qiong Tong Bao Jian", hanzi:"穷通宝鉴", role:"Seasonal Climate Regulation / Tiao Hou; month × Day-Master source-locked seasonal rules", authority:"CORE-SPECIALIZED", closureRole:"PRIMARY_CLIMATE", url:"https://zh.wikisource.org/zh/%E7%A9%B7%E9%80%9A%E5%AE%9D%E9%91%91" },
      { id:"SMTH", title:"Complete Compendium of Three Fates (三命通会)", english:"Complete Compendium of Three Fates", pinyin:"San Ming Tong Hui", hanzi:"三命通会", role:"Cross-check, broader classical cases, natal/temporal先天后天 framework, variant tables; structural Following cross-check", authority:"CORE-CROSSCHECK", closureRole:"FOLLOWING_CROSSCHECK", url:"https://zh.wikisource.org/zh-hans/%E4%B8%89%E5%91%BD%E9%80%9A%E6%9C%83_%28%E5%9B%9B%E5%BA%AB%E5%85%A8%E6%9B%B8%E6%9C%AC%29/%E5%8D%B710" },
      { id:"YHZP", title:"Essentials of Zi Ping (渊海子平)", english:"Essentials of Zi Ping", pinyin:"Yuan Hai Zi Ping", hanzi:"渊海子平", role:"Foundational Zi Ping Ten-God and structural principles; Following/abandon-life cross-check", authority:"FOUNDATION-CROSSCHECK", closureRole:"FOLLOWING_CROSSCHECK", url:"https://zh.wikisource.org/zh-hans/%E6%B7%B5%E6%B5%B7%E5%AD%90%E5%B9%B3" }
    ],
    equivalenceClaims: [
      { claimId:"B3_MONTH_EXPOSURE", sources:["ZPZQ","DTT"], support:"DIRECT", note:"Pattern identity is tied to Month Command and exposed Month-Qi / Ten-God evidence." },
      { claimId:"B3_FORMATION_BREAK_RESCUE", sources:["ZPZQ"], support:"DIRECT", note:"Formation, breaking, and rescue are distinct classical adjudication stages." },
      { claimId:"B3_ZHENG_GUAN_FORMATION", sources:["ZPZQ"], support:"DIRECT", note:"Direct Officer formation: Officer with Wealth/Resource support and no unresolved destructive relation." },
      { claimId:"B3_WEALTH_FORMATION", sources:["ZPZQ"], support:"DIRECT", note:"Wealth formation has multiple source paths: Wealth generating Officer; Wealth with Food/Output plus strong Body/Companion; or Wealth with properly positioned Resource." },
      { claimId:"B3_RESOURCE_FORMATION", sources:["ZPZQ"], support:"DIRECT", note:"Resource formation has multiple source paths including Killing + Resource, Officer + Resource, and strong Body/Resource with Food/Output." },
      { claimId:"B3_EATING_GOD_FORMATION", sources:["ZPZQ"], support:"DIRECT", note:"Eating God formation: Eating God generates Wealth, or Eating God meets Killing without Wealth and with exposed Resource; Wealth + Killing contamination is a break condition." },
      { claimId:"B3_HURTING_OFFICER_FORMATION", sources:["ZPZQ"], support:"DIRECT", note:"Hurting Officer formation has multiple source paths including Wealth, rooted Resource, weak Body with Killing + Resource, and Killing without Wealth." },
      { claimId:"B3_SEVEN_KILLINGS_FORMATION", sources:["ZPZQ"], support:"DIRECT", note:"Seven Killings formation requires strong Body with controlled Killing; Wealth feeding Killing without control is a break condition." },

      { claimId:"B3_JIAN_LU_YUE_JIE", sources:["ZPZQ","YHZP"], support:"DIRECT", note:"Jian Lu / Month Rob uses alternative exposed routes such as Officer, Wealth+Output, or Killing+control depending on source formulation." },
      { claimId:"B3_YANG_REN", sources:["ZPZQ"], support:"DIRECT", note:"Yang Ren uses Officer/Killing, Wealth/Resource and explicit injury/rescue conditions." },
      { claimId:"B1_STRENGTH", sources:["DTT"], support:"DIRECT", note:"Strength is not reducible to a single seasonal score; extreme following is distinct from ordinary strength assessment." },
      { claimId:"B13_CLIMATE", sources:["QTBJ"], support:"SPECIALIZED", note:"Climate is source-locked to seasonal Day-Master requirements; no generic formula is claimed." },
      { claimId:"B8_HUA_ROOT_SUPPORT", sources:["ZPZQ","DTT"], support:"DIRECT", note:"He (合) and Hua (化) are distinct; the selected Hua profile requires seasonal transformation support plus independent natal target-element root/support before confirmation." },
      { claimId:"B13_FOLLOWING", sources:["DTT","YHZP","SMTH"], support:"CROSS_CHECKED", note:"Following requires extreme structure and explicit contrary-force/root checks; source traditions are retained rather than blended." },
      { claimId:"C_TEMPORAL", sources:["SMTH","ZPZQ"], support:"FRAMEWORK", note:"Temporal layer is treated as activation/change/disruption of an established natal structure; exact change closure remains source-dependent." }
    ],
    closureAuthorities: {
      climate: { primary:"QTBJ", crossCheck:["ZPZQ","DTT","SMTH"] },
      following: { primary:"DTT", crossCheck:["YHZP","SMTH","QTBJ"] }
    },
    normalization: {
      coreRule: "A rule enters CORE when its functional principle is consistent across the selected corpus or is a clearly scoped specialized rule.",
      sourceSpecific: "A rule remains SOURCE_SPECIFIC when it is useful but belongs to one source tradition or specialized seasonal table.",
      variant: "A materially different tradition is retained as VARIANT.",
      conflict: "A direct conflict is retained as CONFLICT and requires an explicit school/profile choice.",
      ruleStatusDependent: "A rule remains RULE_STATUS_DEPENDENT when required conditions or source-specific precedence are not yet determinable."
    }
  };
})(window);
