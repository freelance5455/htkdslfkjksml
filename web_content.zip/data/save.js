/* =========================
   存档系统
   存档结构：已解锁角色、金币、首次通关记录
   实际进度保存在浏览器 localStorage；此文件定义默认存档。
========================= */
const SAVE_KEY = 'laoshudazhan_ch_save_v1';
const DEFAULT_SAVE = {
  unlockedCharacters: ['jerry','shirley','tuffy','demon','swordsman'],
  coins: 0,
  clearedLevels: []
};

function loadSave(){
  try{
    const raw=localStorage.getItem(SAVE_KEY);
    const parsed=raw?JSON.parse(raw):null;
    const save={
      unlockedCharacters:[...DEFAULT_SAVE.unlockedCharacters],
      coins:0,
      clearedLevels:[],
      ...(parsed&&typeof parsed==='object'?parsed:{})
    };
    save.unlockedCharacters=Array.isArray(save.unlockedCharacters)?save.unlockedCharacters:[...DEFAULT_SAVE.unlockedCharacters];
    save.clearedLevels=Array.isArray(save.clearedLevels)?save.clearedLevels:[];
    save.coins=Number.isFinite(Number(save.coins))?Math.max(0,Number(save.coins)):0;
    return save;
  }catch(e){
    return {...DEFAULT_SAVE,unlockedCharacters:[...DEFAULT_SAVE.unlockedCharacters],clearedLevels:[]};
  }
}
let playerSave=loadSave();

function persistSave(){
  try{localStorage.setItem(SAVE_KEY,JSON.stringify(playerSave));}catch(e){}
  updateCoinDisplay();
  if(typeof renderLevelCoins==='function')renderLevelCoins();
}
function updateCoinDisplay(){
  const count=String(playerSave.coins||0);
  const el=document.getElementById('menuCoins');
  if(el)el.textContent=count;
  const shopEl=document.getElementById('shopCoins');
  if(shopEl)shopEl.textContent=count;
}
function awardFirstClear(level){
  const n=Number(level);
  if(n<1||n>4||playerSave.clearedLevels.includes(n))return false;
  playerSave.clearedLevels.push(n);
  playerSave.coins=(Number(playerSave.coins)||0)+1;
  persistSave();
  return true;
}
function isCharacterUnlocked(id){
  return playerSave.unlockedCharacters.includes(id);
}
document.addEventListener('DOMContentLoaded',()=>{updateCoinDisplay();if(typeof renderLevelCoins==='function')renderLevelCoins();});
