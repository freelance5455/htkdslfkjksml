/* ============================================================
   PENGGILAS — CLASSICAL RULE EXECUTION / TRACE LAYER
   Purpose: expose the configured B/C rule application and evidence chain
   without masquerading as the adjudication authority. Adjudication remains
   explicit in Core B/C or the Determination layer according to ownership.

   IMPORTANT:
   - This layer does NOT invent a new Classical formula.
   - It does NOT block downstream calculation.
   - It records which configured rule/profile was consumed and the
     execution state actually supported by the current evaluator.
   - Classical resolution remains source/profile dependent.
   ============================================================ */
(function (global) {
  "use strict";

  const RULES = global.PENGGILAS_BC_RULES || null;
  if (!RULES) throw new Error("[ClassicalRuleEvaluator] PENGGILAS_BC_RULES is not loaded.");

  const MAP = {
    B1: ["B1"], B2: ["B2"], B3: ["B3", "B3_YR", "B3_CONG", "B3_HUA"],
    B4: ["B4"], B5: ["B5"], B6: ["B6_B7"], B7: ["B6_B7"], B8: ["B8"],
    B9: ["B9"], B10: ["B10"], B11: ["B11"], B12: ["B12"], B13: ["B13"],
    B14: ["B14"], B15: ["B15"], B16: ["B16"], B17: ["B17"],
    C1: ["C1", "C1_TOUQING"], C2: ["C2", "C2_HUA"], C3: ["C3"],
    C4: ["C4_CHENG", "C4_BIAN"], C5: ["C5"], C6: ["C6"], C7: ["C7"]
  };

  function rule(key) { return RULES.B[key] || RULES.C[key] || null; }
  function profile(id) {
    return RULES.geJuProfiles[id] || RULES.specialStructureProfiles[id] || null;
  }

  function stateFor(section, output) {
    if (!output) return "NOT_EXECUTED";
    if (section === "B3") return output._determinationStatus === "RESOLVED" ? "RESOLVED" : "SCREENED/CANDIDATE";
    if (section === "B13") return output._determinationStatus === "RESOLVED" ? "RESOLVED" : (output._determinationStatus || "REPORTED");
    if (section === "B6" || section === "B7") return "CLASSIFIED";
    if (section === "B8") return "SCREENED";
    if (section === "B11") return "SCOPED";
    if (section === "B17") return "VERIFICATION-REPORTED";
    if (section === "C4") return "TEMPORAL-SCREENED";
    if (section === "C6") return "TEMPORAL-DETERMINATION-REPORTED";
    if (section === "C7") return "VERIFICATION-REPORTED";
    return "EXECUTED";
  }

  function valueText(value) {
    if (value == null) return "";
    if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return String(value);
    try { return JSON.stringify(value); } catch (e) { return String(value); }
  }

  // This is deliberately a trace of the existing Core B/C result, not a new
  // Classical formula. It answers: what rule was configured, what condition
  // does the registry require, what evidence did the current section actually
  // report, what result did that section report, and what remains challenged?
  function actualEvidence(output) {
    if (!output || typeof output !== "object") return [];
    const rows = [];
    Object.keys(output).forEach(function (field) {
      if (field.charAt(0) === "_") return;
      const value = output[field];
      if (!value || typeof value !== "object" || Array.isArray(value)) return;
      if (Object.prototype.hasOwnProperty.call(value, "result") || Object.prototype.hasOwnProperty.call(value, "evidence")) {
        rows.push({
          field: field,
          result: valueText(value.result),
          evidence: valueText(value.evidence),
          status: valueText(value.status || "AVAILABLE")
        });
      }
    });
    return rows;
  }

  function reportedResult(output) {
    if (!output || typeof output !== "object") return null;
    const preferred = ["determination", "final", "overall", "result"];
    for (let i = 0; i < preferred.length; i++) {
      const value = output[preferred[i]];
      if (value && typeof value === "object" && value.result != null) return valueText(value.result);
      if (value != null && typeof value !== "object") return valueText(value);
    }
    return null;
  }

  function challengesFromOutput(output) {
    if (!output || typeof output !== "object") return [];
    const challenges = [];
    const status = output._determinationStatus || output._strengthResolutionStatus || output._specialPatternStatus;
    if (status && !["RESOLVED", "FINAL", "EXECUTED", "CLASSIFIED", "SCREENED", "CALCULATED"].includes(String(status))) {
      challenges.push("Current section status: " + String(status));
    }
    Object.keys(output).forEach(function (field) {
      const value = output[field];
      if (!value || typeof value !== "object" || Array.isArray(value)) return;
      const result = value.result == null ? "" : String(value.result);
      if (/NOT DETERMINED|UNRESOLVED|PROVISIONAL|CONFLICT|INCOMPLETE|NOT YET RESOLVED|REQUIRES RULE/i.test(result)) {
        challenges.push(field + ": " + result);
      }
    });
    return Array.from(new Set(challenges));
  }

  function traceSection(section, output, sectionOutputs) {
    const ids = MAP[section] || [];
    const effectiveOutput = output || (section === "B13" && sectionOutputs && sectionOutputs.B13_2 ? sectionOutputs.B13_2 : output);
    return ids.map(function (key) {
      const r = rule(key);
      const executionStatus = r ? stateFor(section, effectiveOutput) : "RULE-MISSING";
      return {
        ruleKey: key,
        ruleId: r && r.id ? r.id : "MISSING",
        english: r && r.english ? r.english : key,
        hanzi: r && r.hanzi ? r.hanzi : "",
        type: r && r.type ? r.type : "UNKNOWN",
        sources: r && r.sources ? r.sources.slice() : [],
        executionStatus: executionStatus,
        condition: r && r.condition ? r.condition : null,
        stage: {
          evidence: "CAPTURED",
          ruleApplication: r ? "CONFIGURED_RULE_CONNECTED" : "RULE_MISSING",
          adjudication: effectiveOutput && (effectiveOutput._determinationStatus || effectiveOutput._strengthResolutionStatus) ? "SECTION_RESULT_REPORTED" : "NOT_REPORTED",
          determination: effectiveOutput ? "SECTION_RESULT_AVAILABLE" : "NOT_AVAILABLE"
        },
        evidenceChain: {
          rule: r && r.rule ? r.rule : null,
          condition: r && r.condition ? r.condition : null,
          actualEvidence: actualEvidence(effectiveOutput),
          ruleResult: reportedResult(effectiveOutput),
          challenge: challengesFromOutput(effectiveOutput),
          basis: "Existing Core B/C result trace; no new determination formula is introduced."
        }
      };
    });
  }

  function evaluate(master, sectionOutputs) {
    const trace = {};
    Object.keys(MAP).forEach(function (section) {
      trace[section] = traceSection(section, sectionOutputs[section], sectionOutputs);
    });
    const all = Object.keys(trace).reduce(function (a, k) { return a.concat(trace[k]); }, []);
    const globalRuleSpace = global.PENGGILAS_CLASSICAL_RULE_SPACE || null;
    return {
      registryVersion: RULES.version,
      policy: RULES.policy,
      globalRuleSpace: globalRuleSpace ? {
        version: globalRuleSpace.version,
        terminology: globalRuleSpace.terminology,
        entries: globalRuleSpace.entries.length,
        gaps: globalRuleSpace.audit.filter(function (x) { return x.status === "GAP"; }).length,
        policy: globalRuleSpace.policy
      } : { status: "RULE_SPACE_REGISTRY_NOT_LOADED" },
      sectionCoverage: trace,
      totals: {
        mapped: all.length,
        missingRuleDefinitions: all.filter(function (x) { return x.executionStatus === "RULE-MISSING"; }).length,
        executedOrReported: all.filter(function (x) { return x.executionStatus !== "RULE-MISSING" && x.executionStatus !== "NOT_EXECUTED"; }).length
      }
    };
  }

  global.PENGGILAS_CLASSICAL_RULE_EVALUATOR = {
    version: "1.0",
    map: MAP,
    evaluate: evaluate,
    rule: rule,
    profile: profile
  };
})(window);
