/* ============================================================
   PENGGILAS — CLASSICAL RULE LAYER
   Scope: Sections B (Profile & Structure) and C (Temporal Dynamics) ONLY
   Language: English + Pinyin + Hanzi

   IMPORTANT:
   - Declarative rule registry only; no narrative/personality interpretation.
   - Day-Master interpretation belongs to a separate interpretation layer.
   - Rules are normalized from multiple classical sources. Source variants
     are retained instead of silently blended.
   - A rule may be CORE, VARIANT, SCREEN, or RULE_STATUS_DEPENDENT.
   ============================================================ */
(function (global) {
  "use strict";

  const SOURCES = {
    ZPZQ: {
      id: "ZPZQ",
      title: "Mastery of Zi Ping (子平真诠)",
      role: "Core Zi Ping framework: Month Command, Yong Shen, Ge Ju, Cheng/Bai/Jiu Ying, Yang Ren, Jian Lu/Yue Jie",
      url: "https://luckclub.cn/bazi/002/010/"
    },
    ZPZQ_BH: {
      id: "ZPZQ-BH",
      title: "Mastery of Zi Ping — Useful God Changes (子平真诠·论用神变化)",
      role: "Pattern/Yong-Shen changes through exposure and combinations",
      url: "https://luckclub.cn/bazi/002/012/"
    },
    ZPZQ_YR: {
      id: "ZPZQ-YANGREN",
      title: "Mastery of Zi Ping — Yang Ren (子平真诠·论阳刃)",
      role: "Yang Ren structural screen",
      url: "https://shuyuan.zhiming.life/read/%E5%AD%90%E5%B9%B3%E7%9C%9F%E8%AF%A0/43"
    },
    DTT: {
      id: "DTT",
      title: "Subtle Secrets of the Heavenly Marrow (滴天髓)",
      role: "Strength, balance, pattern truth/falsehood, body-use relationships, extreme-following conditions",
      url: "https://zh.wikisource.org/zh-hans/%E6%BB%B4%E5%A4%A9%E9%AB%93"
    },
    DTT_BAI: {
      id: "DTT-GEJU",
      title: "Subtle Secrets of the Heavenly Marrow — Pattern Theory (滴天髓·格局论)",
      role: "Month-branch pattern basis, exposure/透干 and true-pattern conditions",
      url: "https://zh.wikisource.org/zh-hans/%E6%BB%B4%E5%A4%A9%E9%AB%93/06"
    },
    DTT_WANG: {
      id: "DTT-WANG",
      title: "Subtle Secrets of the Heavenly Marrow — Strength and Weakness (滴天髓·衰旺)",
      role: "Month Command is important but not the sole determinant; extreme Following Structures (从格) are distinct from ordinary strength/weakness",
      url: "https://zh.wikisource.org/zh-hans/%E6%BB%B4%E5%A4%A9%E9%AB%93/12"
    },
    QTBJ: {
      id: "QTBJ",
      title: "Exhaustive Analysis of Seasonal Balance (穷通宝鉴)",
      role: "Seasonal climate regulation and month × Day-Master rules where source-locked",
      url: "https://zh.wikisource.org/zh-hans/%E7%A9%B7%E9%80%9A%E5%AE%9D%E9%91%91"
    },
    ZPZQ_RY: {
      id: "ZPZQ-REN-YUAN",
      title: "Mastery of Zi Ping — Ren Yuan Seasonal Allocation (子平真诠·人元司令分野)",
      role: "Day-precise seasonal Qi as supporting evidence",
      url: "https://www.anhappy.com/share/books/others/books/%E5%9B%BD%E5%AD%A6/%E5%AD%90%E5%B9%B3%E7%9C%9F%E8%AF%A0%E8%AF%84%E6%B3%A8.pdf"
    },
    ZMTH_RY: {
      id: "SMTH-REN-YUAN-VARIANT",
      title: "Complete Compendium of Three Fates — Ren Yuan Seasonal Allocation (三命通会·论人元司事)",
      role: "Alternative Ren-Yuan allocation tradition; retained as a variant, not blended with ZPZQ table",
      url: "https://zh.wikisource.org/"
    }
  };

  const POLICY = {
    precedence: [
      "Month Command (月令)",
      "Pattern Identity (格局识别)",
      "Stem Exposure, Root Qi, and Favorable/Unfavorable Evidence (透干、根气、Favorable / Unfavorable Factors (喜忌)证据)",
      "Combination / Transformation Conditions (Combination / Transformation (合化)条件)",
      "Formation / Breaking / Rescue Evaluation (成败救应)",
      "Useful-God Method Reconciliation (Useful God (用神)法门协调)",
      "Temporal Activation (岁运引动)"
    ],
    statusModel: ["DETECTED", "CLASSIFIED", "EVALUATED", "RESOLVED"],
    resolutionPolicy: "A downstream result cannot be RESOLVED when an upstream required rule is only DETECTED, CLASSIFIED, or unresolved.",
    variantPolicy: "Conflicting source traditions are retained as named variants; the engine does not silently average or blend them.",
    interpretationBoundary: "No Day-Master personality, life-story, career, relationship, health, or other narrative interpretation is contained in this rule layer."
  };

  /* ----------------------------------------------------------
     B — PROFILE & STRUCTURE / GE JU
     ---------------------------------------------------------- */
  const B = {
    B1: {
      id: "BC-B1-001",
      english: "Day-Master Strength Evidence",
      pinyin: "Ri Zhu Wang Shuai",
      hanzi: "日主Day-Master Strength (旺衰)",
      type: "CORE_SCREEN",
      sources: ["ZPZQ", "DTT_WANG"],
      rule: "Use Day Master (日主) as the subject; establish Month Command (月令) first; then examine the whole four pillars for Root Quality (根气), Supporting Qi, Draining / Controlling Qi, and Gain / Loss Interactions. Adjudicate qualitatively only when the evidence points in one direction. Do not convert the Classical evidence into a universal numeric strength score or threshold.",
      logic: [
        "1. Day Master (日主) is the subject of strength assessment.",
        "2. Month Command (月令) is the primary seasonal coordinate / Governing Outline (提纲).",
        "3. Examine Root Quality (根气) and supporting evidence from the remaining stems and branches.",
        "4. Examine draining, wealth, officer/control and other counter-evidence across the whole chart.",
        "5. If the primary seasonal, root and supporting/counter evidence converge, adjudicate Strong / Weak qualitatively; if materially mixed, keep the determination unresolved.",
        "6. No universal numeric weight, score or threshold is introduced unless a source-specific school profile explicitly supplies one."
      ],
      counterEvidencePolicy: {
        presenceIsBlocking: false,
        rule: "Raw Output / Wealth / Officer presence is whole-chart draining/controlling evidence, not automatically material counter-evidence. It becomes blocking only when an explicit source/profile condition identifies a material counter-force."
      },
      precedence: "Day Master first; Month Command (月令) is primary; root and whole-chart gain/loss evidence modify the judgment.",
      condition: "Final Classical Day-Master Strength (旺衰) is allowed only when the configured Zi Ping qualitative hierarchy produces one coherent direction and no unresolved special-structure exclusion blocks the conclusion.",
      excludes: ["Project A8 seasonal multipliers as Classical law", "Automatic Strong/Weak from raw element counts"]
    },
    B2: {
      id: "BC-B2-001",
      english: "Month Command Hierarchy",
      pinyin: "Yue Ling",
      hanzi: "月令",
      type: "CORE",
      sources: ["ZPZQ", "DTT_BAI", "ZPZQ_RY"],
      rule: "Identify the month branch and its Main Qi first; Middle/Residual Qi and day-precise Ren Yuan are supporting evidence and do not replace the Month Command identity.",
      condition: "Ren Yuan variant must remain source-labelled. ZPZQ and San Ming Tong Hui allocation tables must not be silently blended.",
      evidence: ["Month Branch (月支)", "Main Qi (本气)", "Middle Qi (中气)", "Residual Qi (余气)", "day-precise Ren Yuan allocation when configured"],
      logic: ["1. Identify Month Command.", "2. Identify Main Qi before secondary hidden stems.", "3. Apply only the selected Ren Yuan source profile.", "4. Keep alternate allocation traditions as explicit variants."]
    },
    B3: {
      id: "BC-B3-001",
      english: "Pattern Identification and Formation",
      pinyin: "Ge Ju",
      hanzi: "格局",
      type: "CORE_RULE_STATUS",
      sources: ["ZPZQ", "DTT_BAI"],
      rule: "Identify the pattern from Month Command (月令) and its Ten-God structure. A true pattern candidate is tied to the Month-Qi framework; Stem Exposure / 透干 is primary evidence for whether the Month-Qi spirit is structurally expressed. Root, combinations, clashes and other competing factors are then checked before formation is accepted.",
      logic: [
        "1. Establish Month Command (月令) and its Main Qi (本气).",
        "2. Map the Main Qi to the Day Master's Ten-God relationship.",
        "3. Check Stem Exposure / 透干 for the relevant Month-Qi spirit; a hidden Month-Qi candidate alone is not sufficient for a closed pattern.",
        "4. Check root/supporting evidence and natal combinations, clashes, harms, breaks and other competing structures that may alter pattern integrity.",
        "5. Determine formation only when the source conditions for the selected pattern are satisfied.",
        "6. Determine breaking and rescue separately; do not infer Formation / Breaking / Rescue (成格/败格/救应) merely from candidate identification.",
        "7. If formation, breaking or rescue remains unresolved, keep the Ge Ju determination provisional/unresolved rather than inventing a final pattern."
      ],
      stages: ["candidate", "formation", "breaking", "rescue", "final"],
      condition: "A Month-Qi label, hidden-stem candidate, or single Stem Exposure finding alone cannot become a final Ge Ju determination; the applicable source conditions and pattern-integrity checks must close first.",
      evidence: ["Month Command", "Month Main Qi", "Ten-God relation", "Stem Exposure / 透干", "root/support evidence", "He/Chong/Xing/Hai/Po evidence", "special-pattern screens"],
      closure: "Formation, breaking and rescue must each be explicitly evaluated; unresolved stages remain open."
    },
    B3_YR: {
      id: "BC-B3-YR-001",
      english: "Yang Blade Pattern Screen",
      pinyin: "Yang Ren Ge",
      hanzi: "Yang Blade (阳刃)格",
      type: "SPECIAL_PATTERN_SCREEN",
      sources: ["ZPZQ_YR"],
      rule: "For the selected Zi Ping profile, screen the relevant Yang Day Master + Yang Ren month configuration, then evaluate exposed Officer/Seven Killings (透官煞), exposed Wealth/Resource (露Wealth / Resource (财印)), Hurting Officer (伤官) as a base-forming exclusion, and source-described rescue when Output Stars (伤食) is present.",
      evidence: ["Day Master polarity", "Yang Ren month relation", "exposed Officer/Seven Killings", "exposed Wealth/Resource", "Hurting Officer exposure", "Eating/Hurting Officer rescue evidence", "Clash/Combination/Break/Harm"],
      logic: ["1. Confirm the Yang Day Master + Yang Ren configuration.", "2. Require exposed Officer / Killing (官/煞) and exposed Wealth / Resource (财印) for the base formation screen.", "3. Treat exposed Hurting Officer (伤官) as a base-forming exclusion rather than an automatic global failure.", "4. Evaluate source-described rescue/control before closure.", "5. Keep Formation / Breaking / Rescue (成格/败格/救应) unresolved when the applicable rescue profile is not closed."]
    },
    B3_CONG: {
      id: "BC-B3-CONG-001",
      english: "Following Structure Screen",
      pinyin: "Cong Ge",
      hanzi: "从格",
      type: "SPECIAL_PATTERN_RULE_STATUS",
      sources: ["DTT_WANG", "DTT"],
      rule: "Extreme strength/weakness is screened separately from ordinary Day-Master Strength (旺衰). The configured profile recognizes 从旺 where 比劫 is overwhelmingly dominant, 印 provides life/support and 官杀 does not restrain; 从强 requires 印比重、日主当令 and absence of 财官. Other following forms remain separate and are not inferred from raw element counts.",
      condition: "Do not confirm 从格 from one dominant element, one month condition, or one missing element alone; contrary force must be explicitly audited.",
      evidence: ["effective Day-Master root", "Resource/Companion force", "Wealth/Officer/Output force", "material contrary force", "special-pattern exclusions"],
      closure: "Following requires structural dominance plus effective absence/ineffectiveness of contrary force under the selected source profile. The source-supported 从势 screen is distinct and requires all three 财官食伤 sides to be active with no Resource/Companion rescue."
    },
    B3_HUA: {
      id: "BC-B3-HUA-001",
      english: "Transformation Pattern Screen",
      pinyin: "Hua Ge",
      hanzi: "化格",
      type: "SPECIAL_PATTERN_RULE_STATUS",
      sources: ["DTT", "ZPZQ_BH"],
      rule: "A stem combination is first a He/合 relation. Hua/化 requires configured seasonal support, target-element continuity, and obstruction/competition checks. Pattern-level 化格 is a stricter determination than ordinary He-Hua screening.",
      condition: "No universal school variant is assumed; final 化格 remains rule-status dependent until the selected profile is satisfied and competition/independent-Hua evidence is explicitly closed."
    },
    B4: {
      id: "BC-B4-001",
      english: "Ten-God Relation to Month Command",
      pinyin: "Shi Shen Yu Yue Ling",
      hanzi: "十神与月令",
      type: "CORE_DATA_RELATION",
      sources: ["ZPZQ", "DTT_BAI"],
      rule: "Relation to Yue Ling must be derived from the actual Month Command Main Qi Ten-God mapping, never from a downstream Ge Ju candidate."
    },
    B5: {
      id: "BC-B5-001",
      english: "Root Quality",
      pinyin: "Gen Qi",
      hanzi: "根气",
      type: "CORE_QUALITATIVE",
      sources: ["ZPZQ", "DTT_WANG"],
      rule: "Classify root quality qualitatively: Main Qi root has higher evidentiary priority than Middle/Residual root; do not invent a numeric root bonus.",
      evidence: ["Day-Master root in branches", "Main Qi root", "Middle/Residual root", "root exposure/support", "root disruption by relevant interactions"],
      logic: ["1. Locate effective root.", "2. Prioritize Main Qi over secondary hidden-stem support.", "3. Check whether interactions preserve or damage the root.", "4. Report quality without a fabricated numeric bonus."]
    },
    B6_B7: {
      id: "BC-B6B7-001",
      english: "Stem and Branch Interaction Classification",
      pinyin: "Tian Gan / Di Zhi Guan Xi",
      hanzi: "天干 / 地支关系",
      type: "CORE_CLASSIFICATION_RULE_STATUS",
      sources: ["ZPZQ", "DTT"],
      rule: "Detect and classify He, Chong, Xing, Hai, Po, San He, San Hui, Ban He and related structures. Structural effect requires a separate evaluation layer; simultaneous relations are not silently collapsed into a universal ranking.",
      condition: "Detected/classified interaction is not equivalent to resolved structural effect.",
      evidence: ["stem pairs", "branch pairs/groups", "He", "Chong", "Xing", "Hai", "Po", "San He/San Hui/Ban He", "interaction overlap"],
      logic: ["1. Detect relation.", "2. Classify relation type.", "3. Preserve simultaneous relations.", "4. Evaluate structural effect only through the applicable source rule."]
    },
    B8: {
      id: "BC-B8-001",
      english: "Stem Combination Transformation",
      pinyin: "He Hua",
      hanzi: "Combination / Transformation (合化)",
      type: "CORE_SCREEN_RULE_STATUS",
      sources: ["ZPZQ_BH", "DTT"],
      rule: "Separate He detection from Hua confirmation. Check season/month target support, preserve stem position, review configured sitting-branch obstruction, keep competition/independent-Hua closure source-dependent, and apply the selected school profile.",
      evidence: ["He pair", "season/month target support", "stem position", "sitting branch", "obstruction", "competition / independent-Hua closure", "selected school profile"],
      logic: ["He detected → Hua candidate → seasonal target support → positional review → obstruction/competition challenge → Hua confirmation only when all configured gates close."]
    },
    B9: {
      id: "BC-B9-001",
      english: "Structural Configuration Packaging",
      pinyin: "Ge Ju Jie Gou",
      hanzi: "格局结构",
      type: "DERIVED_ONLY",
      sources: ["BC-B3-001", "BC-B6B7-001", "BC-B8-001"],
      rule: "B9 consumes B3/B6/B7/B8 evidence and packages it. It must not independently re-evaluate Ge Ju."
    },
    B10: {
      id: "BC-B10-001",
      english: "Five Element Structural Roles",
      pinyin: "Wu Xing Jie Gou",
      hanzi: "五行结构",
      type: "CORE_DERIVED",
      sources: ["DTT", "ZPZQ"],
      rule: "Report each element as support, drain, control or structural role from the configured generation/control relations; structural presence is not itself a favorable/unfavorable verdict."
    },
    B11: {
      id: "BC-B11-001",
      english: "Qi Flow Evidence",
      pinyin: "Qi Liu",
      hanzi: "气流",
      type: "SCOPED",
      sources: ["DTT"],
      rule: "Report generation/draining/control channels only where the configured evidence exists. Element-presence continuity is not by itself a complete receiver/blockage determination.",
      evidence: ["source element", "generated element", "drained element", "controlled element", "receiver presence", "blocking/separation evidence", "mediator evidence"],
      logic: ["1. Identify source and target roles.", "2. Identify obstruction or separation.", "3. Test whether a mediator connects the sides.", "4. Keep mere element coexistence separate from confirmed Qi passage."]
    },
    B12: {
      id: "BC-B12-001",
      english: "Structural Balance Evidence",
      pinyin: "Wu Xing Ping Heng",
      hanzi: "五行平衡",
      type: "EVIDENCE_ONLY",
      sources: ["DTT_WANG", "DTT"],
      rule: "Separate structural presence/absence from Classical excess/deficiency. A calculated highest element is not automatically 太过; absence is not automatically absolute deficiency."
    },
    B13: {
      id: "BC-B13-001",
      english: "Yong-Shen Method Reconciliation",
      pinyin: "Yong Shen",
      hanzi: "Useful God (用神)",
      type: "MULTI_METHOD_RULE_STATUS",
      sources: ["ZPZQ", "DTT", "QTBJ"],
      methods: [
        { id: "FU_YI", english: "Support-Suppress", hanzi: "扶抑", source: "ZPZQ" },
        { id: "BING_YAO", english: "Disease-Medicine", hanzi: "病药", source: "ZPZQ" },
        { id: "TIAO_HOU", english: "Climate Regulation", hanzi: "调候", source: "QTBJ" },
        { id: "ZHUAN_WANG", english: "Follow the Dominant Qi", hanzi: "专旺", source: "ZPZQ/DTT" },
        { id: "TONG_GUAN", english: "Communication / Bridging", hanzi: "通关", source: "ZPZQ" }
      ],
      rule: "Generate method-specific candidates first. Disease-Medicine / 病药 must identify a concrete structural disease and its treating element; Communication/Bridging / 通关 requires an opposed relation plus an effective intervening path; Follow the Dominant Qi / 专旺 must satisfy a source-specific extreme-structure screen. Reconcile only after Ge Ju, seasonal condition, structural conflict and special-pattern rule conditions are evaluated.",
      condition: "Conflicting or still-open method candidates remain explicitly conditional; no silent winner is selected. A unique Useful God (用神) is closed only when no unresolved method gate can materially change the candidate set under the configured source profile."
    },
    B14: {
      id: "BC-B14-001",
      english: "Structural Dependency",
      pinyin: "Jie Gou Yi Lai",
      hanzi: "结构依赖",
      type: "DERIVED_DEPENDENCY",
      sources: ["B13", "B9", "B12"],
      rule: "Identify primary/secondary dependencies from already-established structural evidence; do not create an independent Ge Ju or Yong Shen determination."
    },
    B15: {
      id: "BC-B15-001",
      english: "Structural Priority",
      pinyin: "Jie Gou You Xian",
      hanzi: "结构优先",
      type: "PROJECT_SYNTHESIS",
      sources: ["B2", "B5", "B13", "B3"],
      rule: "Package project structural priorities transparently; priority order is a project synthesis and is not presented as a universal Classical ranking."
    },
    B16: {
      id: "BC-B16-001",
      english: "Structural Synthesis",
      pinyin: "Jie Gou Zong He",
      hanzi: "结构综合",
      type: "DERIVED_SYNTHESIS",
      sources: ["B1", "B3", "B9", "B13", "B14", "B15"],
      rule: "Synthesize upstream findings without upgrading unresolved evidence into a final Classical determination."
    },
    B14_B16: {
      id: "BC-B14B16-001",
      english: "Structural Dependency and Synthesis",
      pinyin: "Jie Gou Yi Lai / Zong He",
      hanzi: "结构依赖 / 综合",
      type: "DERIVED_ONLY",
      sources: ["B1", "B3", "B8", "B13"],
      rule: "Downstream synthesis consumes authoritative upstream results. Unresolved upstream rule conditions propagate as PROVISIONAL/RULE_STATUS_DEPENDENT; downstream sections must not upgrade them."
    },
    B17: {
      id: "BC-B17-001",
      english: "Classical Structural Verification",
      pinyin: "Jie Gou Yan Zheng",
      hanzi: "结构验证",
      type: "PROVENANCE",
      sources: ["All configured sources"],
      rule: "Verification records whether the configured rule chain was satisfied. Internal calculation or engine cross-check is not independent external verification."
    }
  };


  B.B13.evidence = [
    "Month Command (月令)",
    "Day-Master strength evidence / 日主Day-Master Strength (旺衰)",
    "Ge Ju / 格局 status",
    "Structural conflict / 合冲刑害破",
    "Method-specific candidate evidence: 扶抑 / 病药 / 调候 / 通关 / 专旺",
    "Cross-method conflict/open-gate state"
  ];
  B.B13.logic = [
    "1. Evaluate each configured method independently.",
    "2. Preserve candidate identity as element/stem/function rather than display text.",
    "3. Treat open method gates as reconciliation blockers when they can materially change Useful God (用神).",
    "4. Close only when one coherent candidate remains under the selected source profile.",
    "5. Never upgrade internal source-profile checking into independent external verification."
  ];

  /* ----------------------------------------------------------
     C — TEMPORAL DYNAMICS
     ---------------------------------------------------------- */
  const C = {
    C1: {
      id: "BC-C1-001",
      english: "Temporal Stem/Branch and Ten-God Dynamics",
      pinyin: "Sui Yun Gan Zhi Dong Tai",
      hanzi: "岁运干支动态",
      type: "CORE",
      sources: ["ZPZQ", "DTT"],
      rule: "Map active Da Yun/Liu Nian stems and branches against the natal chart, including Ten-God relation, root activation and interaction candidates.",
      evidence: ["Da Yun/Liu Nian stem", "Da Yun/Liu Nian branch", "natal Ten-God relation", "root activation", "natal-temporal interactions"],
      logic: ["1. Establish natal baseline.", "2. Map temporal stem/branch to natal structure.", "3. classify interaction and activation.", "4. Pass only established evidence downstream."]
    },
    C1_TOUQING: {
      id: "BC-C1-TQ-001",
      english: "Temporal Exposure / Manifestation Screen",
      pinyin: "Tou Qing",
      hanzi: "透清",
      type: "SCREEN_RULE_STATUS",
      sources: ["ZPZQ_BH", "DTT_BAI"],
      rule: "A temporal stem matching a natal structural factor is evidence of manifestation/reinforcement, not automatic pattern formation or final usefulness.",
      evidence: ["temporal stem", "matching natal factor", "natal pattern status", "temporal root/support", "competing temporal factors"],
      logic: ["Match → exposure evidence → reinforcement assessment → no automatic pattern closure."]
    },
    C2: {
      id: "BC-C2-001",
      english: "Temporal Combination and Conflict",
      pinyin: "Sui Yun He Chong Xing Hai Po",
      hanzi: "岁运合冲刑害破",
      type: "CORE_CLASSIFICATION_RULE_STATUS",
      sources: ["ZPZQ", "DTT"],
      rule: "Detect temporal He/Chong/Xing/Hai/Po and three-assembly relations; classify first, then evaluate structural effect. Natal Hua status is not overwritten by a temporal He candidate.",
      evidence: ["temporal relation", "natal relation", "affected natal structure", "formation/disruption evidence", "overlapping interactions"],
      logic: ["1. Detect.", "2. Classify.", "3. Determine affected structure.", "4. Evaluate effect without overwriting natal status."]
    },
    C2_HUA: {
      id: "BC-C2-HUA-001",
      english: "Temporal Transformation Screen",
      pinyin: "Sui Yun Hua",
      hanzi: "岁运化",
      type: "RULE_STATUS_DEPENDENT",
      sources: ["ZPZQ_BH", "DTT"],
      rule: "Temporal He may activate or reinforce a transformation candidate, but temporal Hua requires the same transformation prerequisites plus temporal support and obstruction checks.",
      evidence: ["temporal He", "natal Hua candidate", "seasonal support", "target-element support", "temporal support", "obstruction/competition"],
      logic: ["Temporal He → review Hua prerequisites → temporal support → obstruction challenge → confirmation only when gates close."]
    },
    C3: {
      id: "BC-C3-001",
      english: "Temporal Qi and Structural Response",
      pinyin: "Qi Yu Jie Gou Fan Ying",
      hanzi: "气与结构反应",
      type: "CORE_RULE_STATUS",
      sources: ["ZPZQ", "DTT"],
      rule: "Translate temporal interactions into support, drain, control, root activation and dependency responses only from established natal structure. Presence alone does not equal weighted temporal strength.",
      evidence: ["natal structural role", "temporal support", "temporal drain", "temporal control", "root activation", "dependency response"],
      logic: ["Natal baseline → temporal relation → structural response → challenge → downstream status."]
    },
    C4_CHENG: {
      id: "BC-C4-CHENG-001",
      english: "Temporal Pattern Formation",
      pinyin: "Sui Yun Cheng Ge",
      hanzi: "岁运成格",
      type: "RULE_STATUS_DEPENDENT",
      sources: ["ZPZQ", "DTT_BAI", "ZPZQ_BH"],
      rule: "A temporal stem/branch may complete or reinforce a natal pattern only when the natal candidate already has the required structure and the temporal factor supplies a missing formation condition. Ten-God matching alone is insufficient.",
      evidence: ["natal pattern candidate", "natal formation prerequisites", "temporal missing condition", "temporal support", "conflict/obstruction"],
      logic: ["Existing candidate → identify missing condition → temporal factor supplies it → formation re-evaluation → closure only if source conditions close."]
    },
    C4_BIAN: {
      id: "BC-C4-BIAN-001",
      english: "Temporal Pattern Change",
      pinyin: "Sui Yun Bian Ge",
      hanzi: "岁运变格",
      type: "RULE_STATUS_DEPENDENT",
      sources: ["DTT", "ZPZQ_BH"],
      rule: "A clash/disruption is evidence of structural pressure, not automatic 变格. A change determination requires identification of the prior structure, the disrupting/transforming factor, and the resulting stable structure.",
      evidence: ["prior natal structure", "disrupting factor", "transformation factor", "post-change structure", "stability/continuity evidence"],
      logic: ["Prior structure → disruption/change factor → resulting structure → stability check → Bian Ge only when the new structure is demonstrably established."]
    },
    C5: {
      id: "BC-C5-001",
      english: "Temporal Balance Shift",
      pinyin: "Sui Yun Ping Heng Bian Hua",
      hanzi: "岁运平衡变化",
      type: "EVIDENCE_RULE_STATUS",
      sources: ["DTT_WANG", "DTT", "ZPZQ"],
      rule: "Report temporal support/obstruction and balance shifts relative to the established natal structure. Do not present temporal element counts as a universal weighted Day-Master Strength (旺衰) ranking.",
      evidence: ["natal strength basis", "temporal stem/branch", "temporal root activation", "support/drain/control relation", "interaction with natal structure", "obstruction/rescue evidence"],
      logic: ["1. Start from natal structure.", "2. Apply temporal interaction.", "3. Identify support, drain, control or disruption.", "4. Report shift without creating a second universal strength formula."]
    },
    C6: {
      id: "BC-C6-001",
      english: "Temporal Determination Status",
      pinyin: "Sui Yun Ding Xing",
      hanzi: "岁运定性",
      type: "FINAL_RULE_STATUS",
      sources: ["All upstream B/C rules"],
      rule: "Favorable/unfavorable, Cheng Ge and Bian Ge determinations require upstream natal rule conditions to be resolved. Otherwise return NOT DETERMINED / PROVISIONAL. No deterministic life prediction is emitted by the engine."
    },
    C7: {
      id: "BC-C7-001",
      english: "Temporal Evidence and Provenance",
      pinyin: "Sui Yun Zheng Ju",
      hanzi: "岁运证据",
      type: "PROVENANCE",
      sources: ["All configured sources"],
      rule: "Record evidence, finding and source/basis for C1–C6. Provenance status must distinguish calculated, source-screened, project-rule and independently verified states."
    }
  };



  /* ----------------------------------------------------------
     CLASSICAL CORE NORMALIZATION — SOURCE-LOCKED PROFILES
     These profiles are declarative inputs for B/C evaluators.
     They do not perform interpretation and do not override A.
     ---------------------------------------------------------- */
  const GEJU_PROFILES = {
    ZhengGuan: {
      english: "Direct Officer Pattern",
      pinyin: "Zheng Guan Ge",
      hanzi: "正官格",
      source: "ZPZQ",
      formation: ["Month Command is Direct Officer", "supporting Wealth or Resource evidence", "no unresolved destructive conflict"],
      breaking: ["Officer damaged by Hurting Officer", "unresolved Clash/Punishment/Break/Harm affecting the pattern", "conflicting structure without rescue"],
      rescue: ["Resource protects Officer", "Combination resolves the destructive factor", "configured rescue factor restores pattern function"]
    },
    ZhengCai: {
      english: "Direct Wealth Pattern", pinyin: "Zheng Cai Ge", hanzi: "正财格", source: "ZPZQ",
      formation: ["Month Command is Wealth", "one source formation path closes: Wealth generates Officer; or Wealth meets Food/Output with strong Day Master and Companion; or Wealth carries Resource with non-conflicting position"],
      breaking: ["Companion pressure materially overwhelms Wealth", "Wealth is contaminated by Seven Killings / destructive relation", "unresolved structural conflict"],
      rescue: ["Food/Output transforms Companion pressure", "Officer route restrains Companion pressure", "position/spacing prevents Wealth-Resource conflict"]
    },
    PianCai: {
      english: "Indirect Wealth Pattern", pinyin: "Pian Cai Ge", hanzi: "偏财格", source: "ZPZQ",
      formation: ["Month Command is Indirect Wealth", "productive/supporting route exists", "Day-Master relation is evaluated"],
      breaking: ["excessive Companion pressure", "destructive control or unresolved structural conflict"],
      rescue: ["Eating God transforms Companion pressure", "Officer route restrains Companion pressure", "configured rescue restores Wealth function"]
    },
    ZhengYin: {
      english: "Direct Resource Pattern", pinyin: "Zheng Yin Ge", hanzi: "正印格", source: "ZPZQ",
      formation: ["Month Command is Resource", "one source formation path closes: light Resource meets Seven Killings; Officer + Resource; strong Body + Resource with Food/Output; or source-specific Wealth relation with position/root conditions"],
      breaking: ["Resource damaged by Wealth", "excessive Resource with destructive consequence", "unresolved structural conflict"],
      rescue: ["Companion/combination protects Resource", "configured Output/Control relation restores structure"]
    },
    PianYin: {
      english: "Indirect Resource Pattern", pinyin: "Pian Yin Ge", hanzi: "偏印格", source: "ZPZQ",
      formation: ["Month Command is Indirect Resource", "Resource function is structurally usable"],
      breaking: ["destructive Wealth pressure", "unresolved conflict"],
      rescue: ["configured Output/Wealth relation restores usable structure"]
    },
    ShiShen: {
      english: "Eating God Pattern", pinyin: "Shi Shen Ge", hanzi: "食神格", source: "ZPZQ",
      formation: ["Month Command is Eating God", "one source formation path closes: Eating God generates Wealth; or Eating God meets Killing with no Wealth and exposed Resource"],
      breaking: ["Indirect Resource / Resource damages Eating God", "Eating God generates Wealth while Seven Killings contaminates the structure", "unresolved conflict"],
      rescue: ["Eating God turns toward Wealth", "Eating God follows Killing with exposed Resource", "combination removes destructive factor"]
    },
    ShangGuan: {
      english: "Hurting Officer Pattern", pinyin: "Shang Guan Ge", hanzi: "Hurting Officer (伤官)格", source: "ZPZQ",
      formation: ["Month Command is Hurting Officer", "one source formation path closes: Hurting Officer generates Wealth; or strong Hurting Officer with rooted Resource; or weak Day Master with Killing + Resource; or Hurting Officer with Killing and no Wealth"],
      breaking: ["source-specific Officer conflict without rescue", "Hurting Officer generates Wealth while Killing contaminates the route", "Resource-protection path used with insufficient Hurting Officer strength", "unresolved conflict"],
      rescue: ["Resource protects the structure", "Wealth receives Hurting Officer output", "configured combination resolves the Officer conflict"]
    },
    QiSha: {
      english: "Seven Killings Pattern", pinyin: "Qi Sha Ge", hanzi: "七杀格", source: "ZPZQ",
      formation: ["Month Command is Seven Killings", "Day Master/structure can use the Killing through configured control/support"],
      breaking: ["Seven Killings meets Wealth without adequate control", "unresolved excessive Killing pressure", "conflict without rescue"],
      rescue: ["Eating God controls Seven Killings", "Resource transforms/protects Killing structure where source conditions apply", "configured combination resolves conflict"]
    },
    YangRen: {
      english: "Yang Blade Pattern", pinyin: "Yang Ren Ge", hanzi: "Yang Blade (阳刃)格", source: "ZPZQ_YR",
      formation: ["Yang Day Master + Yang Blade Month configuration", "Officer/Seven Killings control evidence", "supporting Wealth/Resource evidence where required by source profile", "no unresolved destructive factor"],
      breaking: ["absence of required control structure", "unresolved structural conflict"],
      rescue: ["configured Officer/Seven Killings + supporting protection", "source-specific rescue conditions"]
    },
    JianLuYueJie: {
      english: "Establishing Prosperity / Month Rob Pattern", pinyin: "Jian Lu Yue Jie Ge", hanzi: "建禄月劫格", source: "ZPZQ",
      formation: ["Month Command is Jian Lu or Yue Jie", "one source formation path closes: Officer with Wealth/Resource; or Wealth with Food/Output; or Killing with control"],
      breaking: ["no usable source route", "unresolved conflict or competing Officer/Killing structure"],
      rescue: ["source-specific combination/control removes the damaging factor"]
    }
  };

  const SPECIAL_STRUCTURE_PROFILES = {
    CongQiang: {
      english: "Follow-Strength Pattern", pinyin: "Cong Qiang", hanzi: "从强",
      source: "DTT",
      required: ["very strong Resource + Companion side", "additional Companion Stars are present beyond the Day Master's own stem", "Day Master participates in the dominant force", "no material Wealth/Officer counter-force"],
      condition: "A single dominant element or the Day Master's own stem cannot establish the Companion side; explicit additional Companion evidence is required, and explicit Day-Master Month Command support (日主当令) is required by the selected source profile."
    },
    CongWang: {
      english: "Follow-Dominant Pattern", pinyin: "Cong Wang", hanzi: "从旺",
      source: "DTT",
      required: ["extreme Companion/Resource dominance", "additional Companion Stars are present beyond the Day Master's own stem", "no material controlling opposition"],
      condition: "Requires additional Companion evidence beyond the Day Master's own stem, extreme-structure evidence, and school-profile confirmation."
    },
    CongShi: {
      english: "Follow-the-Trend Pattern", pinyin: "Cong Shi", hanzi: "从势",
      source: "DTT",
      required: ["Day Master lacks root", "Wealth/Officer/Output forces are jointly active/strong", "no effective Resource/Companion rescue", "the trend/dominant force group is identified"],
      condition: "从势 requires all three 财官食伤 sides to be active with no effective Resource/Companion rescue; materially balanced forces remain open unless the selected source profile explicitly resolves the trend."
    }
  };

  const HUA_CORE = {
    english: "Stem Combination Transformation Core", pinyin: "Tian Gan He Hua", hanzi: "天干合化",
    source: ["ZPZQ_BH", "DTT"],
    stages: ["He detected / 合", "Hua candidate / 化候选", "Hua evaluated / 化评估", "Hua confirmed / 化成"],
    conditions: ["season/month target support", "stem position closed", "adequate transformation context", "no configured obstruction", "competition / independent-Hua closure established", "selected school profile satisfied"],
    prohibition: "He alone must never be rendered as confirmed Hua."
  };



  /* ----------------------------------------------------------
     CLASSICAL CLOSURE PROFILES — SOURCE-LOCKED, FAIL-CLOSED
     These are declarative gates distilled from the selected China-source
     corpus. They do not calculate a chart and do not replace Core B/C.
     ---------------------------------------------------------- */
  const CLASSICAL_CLOSURE_PROFILES = {
    climate: {
      id: "CS-B13-CLIMATE",
      title: "Climate Regulation Closure (调候闭合)",
      primaryAuthority: "QTBJ",
      crossChecks: ["ZPZQ", "DTT", "SMTH"],
      required: [
        "SEASON_RESOLVED",
        "DAY_MASTER_RESOLVED",
        "SOURCE_RULE_MATCHED",
        "PRIMARY_REGULATOR_IDENTIFIED",
        "REGULATOR_PRESENCE_VERIFIED",
        "REGULATOR_EFFECTIVENESS_VERIFIED",
        "INTERFERENCE_SCREEN_CLOSED"
      ],
      disqualifiers: [
        "SOURCE_INTERFERENCE",
        "EXCESS_PRIMARY_UNRESOLVED",
        "REGULATOR_BLOCKED",
        "CONTRADICTORY_SEASONAL_RULE",
        "UNRESOLVED_EXCEPTION"
      ],
      rule: "Climate closes only when the applicable seasonal source entry is matched, the required regulator is present and effective, and no source-defined obstruction, excess, contradiction, or unresolved exception remains.",
      outcomes: ["CLOSED", "OPEN", "CONFLICT", "PROVISIONAL"]
    },
    following: {
      id: "CS-B13-FOLLOWING",
      title: "Following Structure Closure (从格闭合)",
      primaryAuthority: "DTT",
      crossChecks: ["YHZP", "SMTH", "QTBJ"],
      required: [
        "FOLLOWING_SUBTYPE_IDENTIFIED",
        "DOMINANT_FORCE_VERIFIED",
        "DM_ROOT_SUPPORT_AUDITED",
        "CONTRARY_FORCE_AUDITED",
        "BREAK_CONDITIONS_AUDITED",
        "TRUE_FOLLOWING_CONDITIONS_SATISFIED"
      ],
      disqualifiers: [
        "EFFECTIVE_RESOURCE_COMPANION",
        "EFFECTIVE_WEALTH_OFFICER",
        "MATERIAL_BALANCE",
        "DM_ROOT_PRESENT",
        "DM_MEANINGFUL_SUPPORT",
        "FOLLOWING_STRUCTURE_BROKEN",
        "UNRESOLVED_SUBTYPE"
      ],
      rule: "Following closes only when the specific subtype is identified, the dominant force is structurally verified, Day-Master root/support and contrary forces are audited, and no classical breaking condition remains.",
      outcomes: ["CLOSED", "REJECTED", "OPEN", "CONFLICT", "PROVISIONAL"]
    }
  };

  const CLIMATE_RULE_SCHEMA = {
    title: "Climate Regulation Rule Record (调候规则记录)",
    fields: [
      "dayMaster", "month", "seasonalPhase", "primaryRegulator",
      "secondaryRegulator", "substituteRegulator", "requiredConditions",
      "blockingConditions", "excessConditions", "effectivenessConditions",
      "failureConditions", "exceptionConditions", "source"
    ],
    statusVocabulary: ["PRIMARY", "SECONDARY", "SUBSTITUTE", "NEGATIVE", "EXCEPTION"]
  };

  const FOLLOWING_RULE_SCHEMA = {
    title: "Following Structure Rule Record (从格规则记录)",
    fields: [
      "followingType", "dmRootRequirement", "dmSupportRequirement",
      "dominantTarget", "targetStrength", "competingStructure",
      "breakConditions", "trueFollowingConditions", "falseFollowingConditions",
      "source"
    ],
    statusVocabulary: ["PRIMARY", "SECONDARY", "NEGATIVE", "EXCEPTION"]
  };

  const YONGSHEN_RECONCILIATION = {
    english: "Yong-Shen Multi-Method Reconciliation", pinyin: "Yong Shen Duo Fa", hanzi: "Useful God (用神)多法",
    sources: ["ZPZQ", "DTT", "QTBJ"],
    order: ["identify Month Command (月令)", "identify Ge Ju / 格局", "evaluate strength and structural conflict", "generate method-specific candidates", "compare candidate function and contradictions", "apply configured source/school precedence", "resolve only when one coherent determination remains"],
    methods: ["扶抑", "病药", "调候", "专旺", "通关"],
    rule: "Multiple valid method candidates may coexist. The engine must preserve the method provenance and must not select a winner merely because one method was calculated first."
  };

  const TEMPORAL_CORE = {
    english: "Natal-to-Temporal Structural Activation", pinyin: "Xian Tian Hou Tian", hanzi: "先天后天",
    source: "SMTH",
    rule: "Natal chart establishes the initial structure; Da Yun/Liu Nian are 后天 factors that can supplement, drain, restrain, activate, complete or disrupt an established structure. Temporal presence alone does not prove a new final pattern.",
    sequence: ["natal structure", "temporal interaction", "activation/support or disruption", "formation/change evaluation", "temporal determination"],
    condition: "Do not infer final temporal Cheng Ge/Bian Ge from a single temporal stem/branch or a raw element count."
  };

  const CONFLICTS = [
    {
      id: "BC-CONFLICT-REN-YUAN",
      subject: "Ren Yuan allocation / 人元司令分野",
      variants: ["ZPZQ-REN-YUAN-001", "SMTH-REN-YUAN-VARIANT"],
      resolution: "Configured source profile; do not blend tables."
    },
    {
      id: "BC-CONFLICT-HUA",
      subject: "Hua / 化 school variants",
      variants: ["Selected source-screen", "Other school profiles"],
      resolution: "Keep school profile explicit; no universal silent precedence."
    },
    {
      id: "BC-CONFLICT-WANGSHUAI",
      subject: "Day-Master Strength (旺衰) methodology",
      variants: ["Evidence-first qualitative screen", "School-specific quantitative systems"],
      resolution: "PENGGILAS Core uses evidence-first screen; numeric project metric remains separate."
    },
    {
      id: "BC-CONFLICT-YONGSHEN",
      subject: "Useful God (用神) method reconciliation / Useful God (用神)协调",
      variants: ["扶抑", "病药", "调候", "专旺", "通关"],
      resolution: "Preserve method candidates and require explicit reconciliation; no silent winner."
    }
  ];

  /* Global Rule + Evidence + Logic contract.
   Every B/C entry is required to expose these three semantic layers.
   Missing source-specific closure is represented explicitly rather than inferred. */
  const RULE_EVIDENCE_LOGIC_CONTRACT = {
    required: ["rule", "evidence", "logic"],
    closure: "A rule may close only when its declared evidence and source-specific conditions are satisfied.",
    challenge: "Counter-evidence must remain visible when it materially conflicts with the rule conclusion.",
    sourcePolicy: "Source-specific conditions are never replaced by project metrics or inferred thresholds."
  };

  Object.keys(B).forEach(function (k) {
    if (!Array.isArray(B[k].evidence)) B[k].evidence = ["Declared source rule evidence"];
    if (!Array.isArray(B[k].logic)) B[k].logic = ["Evaluate the declared rule against its evidence; do not infer an unconfigured threshold."];
  });
  Object.keys(C).forEach(function (k) {
    if (!Array.isArray(C[k].evidence)) C[k].evidence = ["Declared source rule evidence"];
    if (!Array.isArray(C[k].logic)) C[k].logic = ["Evaluate the declared rule against its evidence; do not infer an unconfigured threshold."];
  });

  /* ----------------------------------------------------------
     EXECUTION CONTRACT
     The registry is itself the authoritative B/C rule contract.
     No second interpreter owns aliases, matrix projection, or rule meaning.
     Core B/C consume these methods before executing their section nodes.
     ---------------------------------------------------------- */
  const SECTION_KEYS = {
    B: ["B1","B2","B3","B4","B5","B6","B7","B8","B9","B10","B11","B12","B13","B14","B15","B16","B17"],
    C: ["C1","C2","C3","C4","C5","C6","C7"]
  };

  // Runtime context contract: the registry declares what the section executor
  // is allowed to consume. It does not calculate or adjudicate those values.
  const SECTION_CONTEXT = {
    B: ["A7","A8","A10_4","A11","A12_5","A12_6","A12_7","A12_9"],
    C: ["A14_2","B1","B3","B12","B13_2","_determinationContract"]
  };

  function hasPath(root, path) {
    const parts = path.split(".");
    let cursor = root;
    for (let i = 0; i < parts.length; i++) {
      if (cursor == null || !Object.prototype.hasOwnProperty.call(cursor, parts[i])) return false;
      cursor = cursor[parts[i]];
    }
    return cursor !== undefined && cursor !== null;
  }

  const RULE_ALIASES = {
    B6: ["B6_B7"],
    B7: ["B6_B7"],
    C4: ["C4_CHENG", "C4_BIAN"]
  };

  function resolve(key) {
    if (B[key]) return B[key];
    if (C[key]) return C[key];
    const aliases = RULE_ALIASES[key] || [];
    for (let i = 0; i < aliases.length; i++) {
      if (B[aliases[i]]) return B[aliases[i]];
      if (C[aliases[i]]) return C[aliases[i]];
    }
    return null;
  }

  function prepare(section, master) {
    const keys = SECTION_KEYS[section];
    if (!keys) throw new Error("[ClassicalRules] Unknown section: " + section);
    if (!master || typeof master !== "object") {
      throw new Error("[ClassicalRules] MasterResult is required before preparing " + section);
    }
    const missing = keys.filter(function (key) { return !resolve(key); });
    if (missing.length) {
      throw new Error("[ClassicalRules] Missing authoritative rule definition(s) for " + section + ": " + missing.join(", "));
    }
    const malformed = keys.filter(function (key) {
      const rule = resolve(key);
      return !rule || typeof rule.rule !== "string" || !Array.isArray(rule.logic) || !Array.isArray(rule.evidence);
    });
    if (malformed.length) {
      throw new Error("[ClassicalRules] Incomplete rule contract(s) for " + section + ": " + malformed.join(", "));
    }
    const requiredContext = SECTION_CONTEXT[section] || [];
    const missingContext = requiredContext.filter(function (path) { return !hasPath(master, path); });
    if (missingContext.length) {
      throw new Error("[ClassicalRules] Required runtime context missing for " + section + ": " + missingContext.join(", "));
    }
    return {
      section: section,
      registryVersion: "BC-RULES-2.5",
      sourceContext: master.A1 ? "MASTER_RESULT_A_FOUNDATION" : "MASTER_RESULT",
      authoritativeRuleKeys: keys.slice(),
      requiredContext: requiredContext.slice(),
      status: "READY"
    };
  }

  function requireRule(plan, key) {
    if (!plan || plan.status !== "READY" || plan.authoritativeRuleKeys.indexOf(key) === -1) {
      throw new Error("[ClassicalRules] Rule contract not ready for " + key);
    }
    const rule = resolve(key);
    if (!rule) throw new Error("[ClassicalRules] Authoritative rule missing for " + key);
    return rule;
  }

  global.PENGGILAS_BC_RULES = {
    version: "BC-RULES-2.5",
    language: "English + Pinyin + Hanzi",
    scope: ["B1-B17", "C1-C7"],
    interpretationBoundary: POLICY.interpretationBoundary,
    policy: POLICY,
    sources: SOURCES,
    B: B,
    C: C,
    conflicts: CONFLICTS,
    geJuProfiles: GEJU_PROFILES,
    specialStructureProfiles: SPECIAL_STRUCTURE_PROFILES,
    huaCore: HUA_CORE,
    yongShenReconciliation: YONGSHEN_RECONCILIATION,
    classicalClosureProfiles: CLASSICAL_CLOSURE_PROFILES,
    climateRuleSchema: CLIMATE_RULE_SCHEMA,
    followingRuleSchema: FOLLOWING_RULE_SCHEMA,
    temporalCore: TEMPORAL_CORE,
    ruleEvidenceLogicContract: RULE_EVIDENCE_LOGIC_CONTRACT,
    sectionKeys: SECTION_KEYS,
    aliases: RULE_ALIASES,
    resolve: resolve,
    prepare: prepare,
    requireRule: requireRule,
    get: function (id) {
      const all = Object.keys(B).concat(Object.keys(C));
      for (let i = 0; i < all.length; i++) {
        const k = all[i];
        if ((B[k] && B[k].id === id) || (C[k] && C[k].id === id)) return B[k] || C[k];
      }
      return null;
    }
  };
})(window);
