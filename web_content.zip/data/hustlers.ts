import { AvailableHustler, UserTier } from '../types';

export const NEARBY_HUSTLERS: AvailableHustler[] = [
  {
    id: 'hustler-1',
    name: 'Sipho Dlamini',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    skill: 'Master Electrician & Solar Tech',
    category: 'Electrical',
    rating: 4.9,
    reviewsCount: 48,
    hourlyRate: 280,
    location: [-26.1042, 28.0545], // ~0.5 km
    distanceKm: 0.5,
    isVerified: true,
    tier: UserTier.PREMIUM,
    bio: 'Certified wireman with 8+ years experience in domestic wiring, solar inverters, and emergency DB board faults in Sandton & surrounds.',
    isOnline: true,
    completedJobs: 54,
    phone: '+27 82 459 1102'
  },
  {
    id: 'hustler-2',
    name: 'Thabo Ndlovu',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    skill: 'Appliance Repair & Diagnostics',
    category: 'Appliances',
    rating: 4.8,
    reviewsCount: 36,
    hourlyRate: 220,
    location: [-26.1150, 28.0610], // ~1.0 km
    distanceKm: 1.0,
    isVerified: true,
    tier: UserTier.ELITE,
    bio: 'Specialist in washing machines, refrigeration, and ovens. Same-day diagnostics with genuine parts and guarantee.',
    isOnline: true,
    completedJobs: 39,
    phone: '+27 73 980 4421'
  },
  {
    id: 'hustler-3',
    name: 'Lerato Khumalo',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    skill: 'Interior Painter & Drywall Pro',
    category: 'Painting',
    rating: 5.0,
    reviewsCount: 62,
    hourlyRate: 195,
    location: [-26.0910, 28.0430], // ~2.3 km
    distanceKm: 2.3,
    isVerified: true,
    tier: UserTier.PREMIUM,
    bio: 'Precision interior finishing, waterproof coatings, cornices and drywall patching. Clean, fast, and detail-obsessed.',
    isOnline: true,
    completedJobs: 68,
    phone: '+27 84 312 8847'
  },
  {
    id: 'hustler-4',
    name: 'Bongani Sithole',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    skill: 'Carpentry & Furniture Assembly',
    category: 'Handyman',
    rating: 4.7,
    reviewsCount: 29,
    hourlyRate: 180,
    location: [-26.1380, 28.0350], // ~4.1 km
    distanceKm: 4.1,
    isVerified: true,
    tier: UserTier.ELITE,
    bio: 'Flat-pack furniture assembly (IKEA, Decofurn), door locks, hinges, custom shelving and general household woodwork.',
    isOnline: true,
    completedJobs: 33,
    phone: '+27 71 503 6679'
  },
  {
    id: 'hustler-5',
    name: 'Nandi Mokoena',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    skill: 'Deep Cleaning & Move-in Sanitizing',
    category: 'Cleaning',
    rating: 4.9,
    reviewsCount: 51,
    hourlyRate: 165,
    location: [-26.0420, 28.0180], // ~8.2 km
    distanceKm: 8.2,
    isVerified: true,
    tier: UserTier.PREMIUM,
    bio: 'Professional residential cleaning, carpet shampooing, post-renovation cleanup, and move-in/move-out readiness.',
    isOnline: true,
    completedJobs: 57,
    phone: '+27 83 729 0184'
  },
  {
    id: 'hustler-6',
    name: 'Kagiso Moloi',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    skill: 'Licensed Master Plumber',
    category: 'Plumbing',
    rating: 4.9,
    reviewsCount: 44,
    hourlyRate: 260,
    location: [-25.9960, 28.1220], // ~14.0 km (Midrand)
    distanceKm: 14.0,
    isVerified: true,
    tier: UserTier.ELITE,
    bio: 'PIRB registered plumber specializing in high-pressure geysers, leak detection, drain unblocking, and renovations.',
    isOnline: true,
    completedJobs: 46,
    phone: '+27 76 812 9034'
  },
  {
    id: 'hustler-7',
    name: 'Zanele Buthelezi',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    skill: 'Landscaping & Tree Felling',
    category: 'Gardening',
    rating: 4.8,
    reviewsCount: 38,
    hourlyRate: 170,
    location: [-25.8650, 28.1820], // ~29.0 km (Centurion)
    distanceKm: 29.0,
    isVerified: true,
    tier: UserTier.PREMIUM,
    bio: 'Irrigation systems, garden design, grass roll installation, hedge trimming and safe tree felling with full insurance.',
    isOnline: true,
    completedJobs: 52,
    phone: '+27 81 445 7821'
  }
];
