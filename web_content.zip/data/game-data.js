'use strict';

/* =========================
   角色数据
========================= */

const characterData={
  jerry:{
    id:'jerry',
    name:'杰瑞',
    icon:'🐭',
    max:100,
    desc:'大铁锤25伤害；团队防护'
  },
  tuffy:{
    id:'tuffy',
    name:'泰菲',
    icon:'🐁',
    max:70,
    desc:'火箭筒全体20伤害；奶酪蛋糕恢复自身HP'
  },
  shirley:{
    id:'shirley',
    name:'雪梨',
    icon:'🎀',
    max:100,
    desc:'拳击20伤害；爱心花束全队治疗'
  },
  swordsman:{
    id:'swordsman',
    name:'剑客杰瑞',
    icon:'🗡️',
    max:120,
    desc:'剑舞30伤害；格挡并反击40伤害'
  },
  demon:{
    id:'demon',
    name:'恶魔杰瑞',
    icon:'👿',
    max:100,
    desc:'三叉戟25伤害；诅咒符纸吸引攻击'
  }
};

let selectedTeam=[];
let selectedLevel=1;
let s=null;
let enemyTimer=null;
let audioCtx=null;
let battleToken=0;
let resultTimer=null;

const $=id=>document.getElementById(id);
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
