/* ============================================================
   PENGGILAS — GLOBAL CLASSICAL RULE-SPACE COVERAGE
   V48: external-source-derived declarative coverage contract.

   Purpose:
   - enumerate rule families before chart-specific adjudication;
   - distinguish evidence coverage from closure coverage;
   - make counter-evidence and rescue paths first-class;
   - prevent UNRESOLVED from hiding a missing engine branch.

   No numeric strength formula or silent school precedence is introduced.
   Titles use International English (Chinese) terminology.
   ============================================================ */
(function (global) {
  "use strict";

  const RULE_SPACE = [
    {
      id: "CS-B1-STRENGTH",
      section: "B1",
      title: "Day-Master Strength (旺衰)",
      sources: ["ZPZQ", "DTT_WANG"],
      evidence: ["Month Command", "Root Quality", "supporting Qi", "draining/controlling Qi", "whole-chart gain/loss"],
      counterEvidence: ["contrary seasonal evidence", "material opposing root/support", "special-structure exclusion"],
      closure: ["qualitative convergence", "counter-evidence adjudicated", "special-pattern exclusion checked"],
      outcomes: ["STRONG", "WEAK", "MIXED", "UNRESOLVED"],
      gapPolicy: "UNRESOLVED only if the configured qualitative hierarchy cannot adjudicate the evidence state; missing branch is ENGINE_RULE_GAP."
    },
    {
      id: "CS-B2-MONTH-COMMAND",
      section: "B2",
      title: "Month Command (月令)",
      sources: ["ZPZQ", "ZPZQ_RY", "ZMTH_RY"],
      evidence: ["month branch", "Main Qi", "Middle Qi", "Residual Qi", "selected Ren Yuan profile"],
      counterEvidence: ["alternate Ren Yuan tradition"],
      closure: ["source profile selected", "Main Qi identified", "variant preserved"],
      outcomes: ["CLOSED", "VARIANT", "CONFLICT"]
    },
    {
      id: "CS-B3-PATTERN-FAMILY",
      section: "B3",
      title: "Formation, Breaking, and Rescue (成败救应)",
      sources: ["ZPZQ"],
      evidence: ["Month Command", "Ten-God pattern", "Stem Exposure", "root/support", "structural interactions"],
      counterEvidence: ["damaging Ten-God", "Clash / Break / Harm", "conflicting exposed structure", "pattern contamination"],
      closure: ["formation evaluated", "breaking evaluated", "rescue evaluated", "net state adjudicated"],
      outcomes: ["FORMED", "BROKEN", "RESCUED", "PARTIALLY_RESCUED", "UNRESOLVED", "CONFLICT"]
    },
    {
      id: "CS-B3-GEJU-OFFICER",
      section: "B3",
      title: "Direct Officer Pattern (正官格)",
      sources: ["ZPZQ", "YHZP"],
      evidence: ["Officer Month Command", "supporting Wealth/Resource", "Day-Master support"],
      counterEvidence: ["Hurting Officer", "Clash / Break / Harm", "Seven Killings mixing", "excessive Officer"],
      rescue: ["Resource protection", "combination removing contamination", "structural resolution"],
      closure: ["formation", "breaking", "rescue", "final pattern state"]
    },
    {
      id: "CS-B3-GEJU-WEALTH",
      section: "B3",
      title: "Wealth Pattern (财格)",
      sources: ["ZPZQ", "YHZP"],
      evidence: ["Wealth Month Command", "Food/Output support", "Day-Master capacity"],
      counterEvidence: ["Companion pressure", "Seven Killings contamination", "weak Day Master", "destructive relation"],
      rescue: ["Food/Output transforms Companion pressure", "Officer route controls Companion", "source-specific combination"],
      closure: ["formation", "breaking", "rescue", "final pattern state"]
    },
    {
      id: "CS-B3-GEJU-RESOURCE",
      section: "B3",
      title: "Resource Pattern (印格)",
      sources: ["ZPZQ", "YHZP"],
      evidence: ["Resource Month Command", "Officer/Resource support", "usable Resource"],
      counterEvidence: ["Wealth damaging Resource", "excessive Resource", "destructive Output/Control"],
      rescue: ["Companion protection", "combination preserving Resource", "configured structural route"],
      closure: ["formation", "breaking", "rescue", "final pattern state"]
    },
    {
      id: "CS-B3-GEJU-EATING-GOD",
      section: "B3",
      title: "Eating God Pattern (食神格)",
      sources: ["ZPZQ", "YHZP"],
      evidence: ["Eating God Month Command", "Wealth route", "configured Killing route"],
      counterEvidence: ["Indirect Resource / Resource damaging Eating God", "destructive exposure", "structural clash"],
      rescue: ["Eating God → Wealth", "Eating God controls Killing", "combination removing damage"],
      closure: ["formation", "breaking", "rescue", "final pattern state"]
    },
    {
      id: "CS-B3-GEJU-HURTING-OFFICER",
      section: "B3",
      title: "Hurting Officer Pattern (伤官格)",
      sources: ["ZPZQ", "YHZP"],
      evidence: ["Hurting Officer Month Command", "Wealth route", "Resource route", "Day-Master condition"],
      counterEvidence: ["destructive Officer relation", "conflicting Wealth/Killing", "damaged Resource"],
      rescue: ["Resource protects structure", "Wealth receives Output", "combination resolves Officer conflict"],
      closure: ["formation", "breaking", "rescue", "final pattern state"]
    },
    {
      id: "CS-B3-GEJU-SEVEN-KILLINGS",
      section: "B3",
      title: "Seven Killings Pattern (七杀格)",
      sources: ["ZPZQ", "YHZP"],
      evidence: ["Seven Killings", "Day-Master capacity", "control/support"],
      counterEvidence: ["Wealth feeding Killing", "weak Day Master", "uncontrolled Killing", "excessive control"],
      rescue: ["Eating God control", "Resource route", "combination / removal of contamination"],
      closure: ["formation", "breaking", "rescue", "final pattern state"]
    },
    {
      id: "CS-B3-GEJU-YANG-REN",
      section: "B3",
      title: "Yang Ren Pattern (阳刃格)",
      sources: ["ZPZQ_YR"],
      evidence: ["Yang Day Master", "Yang Ren Month", "exposed Officer/Killing", "Wealth/Resource"],
      counterEvidence: ["Hurting Officer", "absence of required control", "structural clash"],
      rescue: ["Resource Protection (印护)", "Officer/Killing control", "source-specific rescue"],
      closure: ["formation", "breaking", "rescue", "final pattern state"]
    },
    {
      id: "CS-B3-GEJU-JIAN-LU",
      section: "B3",
      title: "Establishing Prosperity / Month Rob Pattern (建禄月劫格)",
      sources: ["ZPZQ"],
      evidence: ["Jian Lu / Month Rob", "Officer route", "Wealth + Output route", "Killing + control route"],
      counterEvidence: ["absence of usable Wealth/Officer", "damaging Killing/Resource arrangement"],
      rescue: ["remove damaging factor by combination/control", "source-specific Wealth/Officer route"],
      closure: ["formation", "breaking", "rescue", "final pattern state"]
    },
    {
      id: "CS-B3-MIXED-GEJU",
      section: "B3",
      title: "Mixed Pattern / Pattern Contamination (杂格 / 混杂)",
      sources: ["ZPZQ", "YHZP"],
      evidence: ["multiple candidate patterns", "relative strength", "exposure", "position", "support"],
      counterEvidence: ["competing pattern with stronger Month-Command claim", "destructive interaction"],
      closure: ["rank candidates using source-defined structure", "preserve unresolved conflict when no source closure exists"],
      outcomes: ["SINGLE_PATTERN", "MULTI_METHOD", "CONFLICT", "UNRESOLVED"]
    },
    {
      id: "CS-B3-MISCELLANEOUS-QI",
      section: "B3",
      title: "Miscellaneous-Qi Pattern (杂气格)",
      sources: ["ZPZQ", "YHZP"],
      evidence: ["Chen/Xu/Chou/Wei Month", "exposed hidden stem", "Branch Combination", "source profile"],
      counterEvidence: ["multiple unclosed hidden Qi candidates", "conflicting exposed and combined routes"],
      rescue: ["source-specific exposure / Branch Combination resolution"],
      closure: ["exposure route adjudicated", "combination route adjudicated", "affinity / non-affinity evaluated"],
      outcomes: ["ROUTE_SELECTED", "OPEN", "CONFLICT", "UNRESOLVED"]
    },
    {
      id: "CS-B8-HUA",
      section: "B8",
      title: "Stem Combination Transformation (天干合化)",
      sources: ["ZPZQ_BH", "DTT"],
      evidence: ["He pair", "seasonal support", "target-element continuity", "position", "obstruction", "competition"],
      counterEvidence: ["insufficient seasonal support", "obstruction", "competing transformation", "school conflict"],
      closure: ["He detected", "Hua candidate", "Hua conditions", "competition closed", "school profile closed"],
      outcomes: ["HE_ONLY", "HUA_CANDIDATE", "HUA_CONFIRMED", "UNCONFIRMED", "CONFLICT"]
    },
    {
      id: "CS-B11-TONG-GUAN",
      section: "B11",
      title: "Communication / Bridging (通关)",
      sources: ["DTT", "ZPZQ"],
      evidence: ["opposed forces", "mediating element", "effective path", "support of mediator"],
      counterEvidence: ["mediator absent", "mediator present but ineffective", "broken path", "competing obstruction"],
      closure: ["opposition identified", "mediator identified", "effective passage proven", "counter-force adjudicated"],
      outcomes: ["NO_OPPOSITION", "PASSAGE_CANDIDATE", "BRIDGING_EFFECTIVE", "UNRESOLVED"]
    },
    {
      id: "CS-B13-MULTI-METHOD",
      section: "B13",
      title: "Useful God Multi-Method Framework (用神多法)",
      sources: ["ZPZQ", "DTT", "QTBJ"],
      evidence: ["Support-Suppress", "Disease-Medicine", "Climate Regulation", "Follow the Dominant Qi", "Communication / Bridging"],
      counterEvidence: ["method disagreement", "candidate function conflict", "special-pattern override", "insufficient method closure"],
      closure: ["method-specific candidates generated", "candidate identities normalized", "conflicts classified", "configured source profile reconciled"],
      outcomes: ["AGREEMENT", "PARTIAL_AGREEMENT", "CONFLICT", "MULTI_METHOD", "OPEN"]
    },
    {
      id: "CS-B13-DISEASE-MEDICINE",
      section: "B13",
      title: "Disease-Medicine (病药)",
      sources: ["ZPZQ", "YHZP"],
      evidence: ["concrete structural disease", "treating element", "effectiveness of treatment"],
      counterEvidence: ["no concrete disease", "medicine worsens another decisive structure", "treatment ineffective"],
      closure: ["disease identified", "medicine identified", "treatment direction adjudicated"],
      outcomes: ["CANDIDATE", "EFFECTIVE", "INEFFECTIVE", "OPEN"]
    },
    {
      id: "CS-B13-CLIMATE",
      section: "B13",
      title: "Climate Regulation (调候)",
      sources: ["QTBJ"],
      evidence: ["Month/season", "Day-Master element", "source-specific seasonal requirement", "primary/assisting factors"],
      counterEvidence: ["source-listed interference", "excess of primary factor", "combination altering efficacy"],
      closure: ["season-specific source entry matched", "primary regulator identified", "regulator presence verified", "regulator effectiveness verified", "interference screen closed", "no source-defined disqualifier"],
      outcomes: ["CANDIDATE", "CLOSED", "OPEN", "CONFLICT", "PROVISIONAL"],
      authority: { primary:"QTBJ", crossCheck:["ZPZQ","DTT","SMTH"] },
      closurePolicy: "No CLOSED state without all required closure signals; source interference, unresolved excess, blocked regulator, contradiction, or unresolved exception blocks closure."
    },
    {
      id: "CS-B13-FOLLOWING",
      section: "B13",
      title: "Following Structures (从格)",
      sources: ["DTT"],
      evidence: ["extreme dominant side", "root/support", "absence or ineffectiveness of contrary force"],
      counterEvidence: ["effective Resource/Companion rescue", "effective Wealth/Officer opposition for Follow-Strength/Dominant", "materially balanced forces"],
      closure: ["specific following subtype identified", "dominant force verified", "Day-Master root/support audited", "contrary force audited", "break conditions audited", "true-following conditions satisfied", "no disqualifying support/balance/break condition"],
      outcomes: ["CANDIDATE", "CONFIRMED", "REJECTED", "UNRESOLVED", "CONFLICT", "PROVISIONAL"],
      authority: { primary:"DTT", crossCheck:["YHZP","SMTH","QTBJ"] },
      closurePolicy: "No CONFIRMED state without subtype, dominance, root/support audit, contrary-force audit and break-condition audit; any disqualifier blocks closure."
    },
    {
      id: "CS-C-TEMPORAL",
      section: "C1-C7",
      title: "Natal-to-Temporal Structural Activation (先天后天)",
      sources: ["SMTH", "ZPZQ"],
      evidence: ["natal structure", "Da Yun", "Liu Nian", "activation/support/disruption", "temporal interaction"],
      counterEvidence: ["temporal factor conflicts with natal structure", "activation without formation conditions", "disruption without replacement structure"],
      closure: ["natal baseline fixed", "temporal interaction evaluated", "formation/change conditions evaluated", "temporal conclusion classified"],
      outcomes: ["NO_ACTIVATION", "ACTIVATED", "FORMED", "CHANGED", "DISRUPTED", "UNRESOLVED"]
    },
    {
      id: "CS-B3-USEFUL-GOD-CHANGE", section: "B3", title: "Useful God Change and Transformation (用神变化)",
      sources: ["ZPZQ"], evidence: ["base Useful God", "combination", "transformation", "new functional role"],
      counterEvidence: ["transformation damages original structure", "transformation does not close", "competing transformed role"],
      rescue: ["transformation improves pattern", "combination removes damaging factor"], closure: ["base state", "changed state", "net effect"],
      outcomes: ["UNCHANGED", "CHANGED_POSITIVE", "CHANGED_NEGATIVE", "CONFLICT", "UNRESOLVED"]
    },
    {
      id: "CS-B3-PURITY-MIXTURE", section: "B3", title: "Useful God Purity and Mixture (用神纯杂)",
      sources: ["ZPZQ"], evidence: ["useful structure", "supporting relations", "clean route"],
      counterEvidence: ["mixed useful factors", "competing routes", "contamination"],
      rescue: ["combination clears contamination", "support restores purity"], closure: ["pure", "mixed", "cleared mixture"],
      outcomes: ["PURE", "MIXED", "RESCUED", "CONFLICT", "UNRESOLVED"]
    },
    {
      id: "CS-B3-FORMATION-HIGH-LOW", section: "B3", title: "Formation Quality and High-Low Grade (格局高低)",
      sources: ["ZPZQ"], evidence: ["formation state", "affinity", "force", "position", "sequence", "distance"],
      counterEvidence: ["inaffinity", "weak force", "poor position", "mixed structure"],
      rescue: ["supporting alignment", "removal of contamination"], closure: ["affinity/force adjudicated", "quality state"],
      outcomes: ["HIGHER_QUALITY", "LOWER_QUALITY", "MIXED_QUALITY", "UNRESOLVED"]
    },
    {
      id: "CS-B3-ASSISTANT-GOD", section: "B3", title: "Assistant God (相神)",
      sources: ["ZPZQ"], evidence: ["Useful God", "supporting factor", "pattern dependency"],
      counterEvidence: ["Assistant God damaged", "assistant conflicts with Useful God", "no assistant requirement"],
      rescue: ["assistant protects Useful God", "assistant resolves pattern damage"], closure: ["identified", "damaged", "not required"],
      outcomes: ["IDENTIFIED", "DAMAGED", "NOT_REQUIRED", "CONFLICT", "UNRESOLVED"]
    },
    {
      id: "CS-B3-AUSPICIOUS-BREAK", section: "B3", title: "Auspicious God Breaking Pattern (四吉神破格)",
      sources: ["ZPZQ"], evidence: ["Auspicious God", "formation dependence", "breaking action"],
      counterEvidence: ["no material breaking action", "rescue route", "factor not decisive"],
      rescue: ["source-defined rescue", "combination/control removes damage"], closure: ["break effect established", "rescue adjudicated"],
      outcomes: ["NOT_BREAKING", "BROKEN", "RESCUED", "CONFLICT", "UNRESOLVED"]
    },
    {
      id: "CS-B3-MALEFIC-FORM", section: "B3", title: "Malefic God Forming Pattern (四凶神成格)",
      sources: ["ZPZQ"], evidence: ["Malefic God", "pattern role", "control/functional conversion"],
      counterEvidence: ["uncontrolled harmful role", "destructive contamination", "no functional route"],
      rescue: ["control converts harmful role", "support creates usable route"], closure: ["functional role", "conversion", "net pattern"],
      outcomes: ["FORMED", "NOT_FORMED", "RESCUED", "CONFLICT", "UNRESOLVED"]
    },
    {
      id: "CS-B6B7-SEQUENCE", section: "B6-B7", title: "Birth-Control Sequence and Priority (生克先后)",
      sources: ["ZPZQ"], evidence: ["productive relation", "controlling relation", "order", "position"],
      counterEvidence: ["competing relation", "blocked relation", "later relation reverses effect"],
      rescue: ["intermediate factor changes sequence", "combination alters effective order"], closure: ["sequence adjudicated", "priority adjudicated"],
      outcomes: ["SUPPORTIVE", "HARMFUL", "RESOLVED_BY_SEQUENCE", "CONFLICT", "UNRESOLVED"]
    },
    {
      id: "CS-B3-OUTER-PATTERNS", section: "B3", title: "Outer and Special Patterns (外格)",
      sources: ["ZPZQ"], evidence: ["special configuration", "ordinary-pattern exclusion", "source-defined requirements"],
      counterEvidence: ["ordinary pattern dominates", "required condition absent", "contaminating factor"],
      rescue: ["source-defined special-pattern rescue only"], closure: ["special pattern eligibility", "exclusion test"],
      outcomes: ["CANDIDATE", "CONFIRMED", "REJECTED", "CONFLICT", "UNRESOLVED"]
    },
    {
      id: "CS-C-DAYUN-FORMATION-CHANGE", section: "C", title: "Temporal Formation and Pattern Change (行运成格变格)",
      sources: ["ZPZQ"], evidence: ["natal pattern", "Da Yun", "activation", "formation change"],
      counterEvidence: ["temporal disruption", "insufficient activation", "competing temporal route"],
      rescue: ["temporal support restores/changes formation"], closure: ["formation", "change", "disruption", "no change"],
      outcomes: ["UNCHANGED", "FORMED", "CHANGED", "DISRUPTED", "CONFLICT", "UNRESOLVED"]
    },


    
    
    
    
    
    
    
    
    

  ];

  // V49: every rule family must declare its adjudication state space explicitly.
  // These are source-profile states, not invented outcomes or numeric formulas.
  const UNIVERSAL_CLOSURE_STATES = [
    "NOT_APPLICABLE", "CANDIDATE", "CONFIRMED", "REJECTED",
    "BROKEN", "RESCUED", "PARTIALLY_RESCUED", "CONFLICT",
    "MULTI_METHOD", "UNRESOLVED"
  ];

  const COVERAGE_AXES = [
    "EVIDENCE_COVERAGE",
    "RULE_COVERAGE",
    "ADJUDICATION_COVERAGE",
    "COUNTER_EVIDENCE_COVERAGE",
    "RESCUE_COVERAGE",
    "CLOSURE_COVERAGE",
    "DEPENDENCY_COVERAGE",
    "OUTPUT_COVERAGE"
  ];

  function normalizeCoverageEntry(entry) {
    if (!entry.adjudicationBranches) entry.adjudicationBranches = [];
    if (!entry.stateDimensions) entry.stateDimensions = [];
    if (!entry.outcomes || !entry.outcomes.length) {
      // Pattern families inherit only the states explicitly supported by their
      // formation/breaking/rescue contract; this is a coverage contract, not a
      // determination shortcut.
      if (entry.id.indexOf("CS-B3-GEJU-") === 0 || entry.id === "CS-B3-MISCELLANEOUS-QI") {
        entry.outcomes = ["FORMED", "BROKEN", "RESCUED", "PARTIALLY_RESCUED", "UNRESOLVED", "CONFLICT"];
      }
    }
    return entry;
  }

  RULE_SPACE.forEach(function(entry) {
    normalizeCoverageEntry(entry);
    entry.stateDimensions = entry.stateDimensions.length ? entry.stateDimensions : [
      "PRIMARY_CONDITION", "COUNTER_EVIDENCE", "RESCUE_OR_BREAK", "COMPETING_ROUTE", "SOURCE_CLOSURE"
    ];
    entry.adjudicationBranches = entry.adjudicationBranches.length ? entry.adjudicationBranches : [
      "PRIMARY_CONDITION_EVALUATION", "COUNTER_EVIDENCE_EVALUATION", "RESCUE_BREAK_EVALUATION", "CLOSURE_CLASSIFICATION"
    ];
    entry.coveragePolicy = {
      evidence: "REQUIRED",
      counterEvidence: "REQUIRED",
      rescue: (entry.rescue && entry.rescue.length) ? "SOURCE_DEFINED" : "NOT_DECLARED_BY_CURRENT_SOURCE_PROFILE",
      closure: "REQUIRED",
      noSilentFallback: true
    };
  });

  const REQUIRED_ADJUDICATION_AXES = [
    "EVIDENCE_COVERAGE", "RULE_COVERAGE", "ADJUDICATION_COVERAGE",
    "COUNTER_EVIDENCE_COVERAGE", "RESCUE_COVERAGE", "CLOSURE_COVERAGE",
    "DEPENDENCY_COVERAGE", "OUTPUT_COVERAGE"
  ];

  function auditEntry(entry) {
    const missing = [];
    if (!entry.evidence || !entry.evidence.length) missing.push("EVIDENCE_COVERAGE");
    if (!entry.closure || !entry.closure.length) missing.push("CLOSURE_COVERAGE");
    if (!entry.counterEvidence || !entry.counterEvidence.length) missing.push("COUNTER_EVIDENCE_COVERAGE");
    if (!entry.stateDimensions || entry.stateDimensions.length < 3) missing.push("STATE_SPACE_COVERAGE");
    if (!entry.adjudicationBranches || entry.adjudicationBranches.length < 3) missing.push("ADJUDICATION_COVERAGE");
    if (!entry.outcomes || !entry.outcomes.length) missing.push("OUTCOME_COVERAGE");
    return { id: entry.id, section: entry.section, title: entry.title, missingAxes: missing, status: missing.length ? "GAP" : "DECLARATIVE_COVERAGE" };
  }

  function adjudicationAudit() {
    const rows = RULE_SPACE.map(function (e) {
      const missing = [];
      if (!e.evidence || !e.evidence.length) missing.push("EVIDENCE_COVERAGE");
      if (!e.counterEvidence || !e.counterEvidence.length) missing.push("COUNTER_EVIDENCE_COVERAGE");
      if (!e.closure || !e.closure.length) missing.push("CLOSURE_COVERAGE");
      if (!e.stateDimensions || e.stateDimensions.length < 3) missing.push("STATE_SPACE_COVERAGE");
      if (!e.adjudicationBranches || e.adjudicationBranches.length < 3) missing.push("ADJUDICATION_COVERAGE");
      if (!e.outcomes || !e.outcomes.length) missing.push("OUTCOME_COVERAGE");
      return { id: e.id, title: e.title, missing: missing, pass: missing.length === 0 };
    });
    return {
      version: "V82",
      ruleFamilies: rows.length,
      passed: rows.filter(function(r){ return r.pass; }).length,
      failed: rows.filter(function(r){ return !r.pass; }).length,
      rows: rows,
      requiredAxes: REQUIRED_ADJUDICATION_AXES.slice()
    };
  }

  function propertyChecks() {
    const ids = RULE_SPACE.map(function(e){ return e.id; });
    const uniqueIds = new Set(ids);
    const duplicateIds = ids.filter(function(id, i, a){ return a.indexOf(id) !== i; });
    const missingSection = RULE_SPACE.filter(function(e){ return !e.section; }).map(function(e){ return e.id; });
    const missingTitle = RULE_SPACE.filter(function(e){ return !e.title || !/\([^)]*\)/.test(e.title); }).map(function(e){ return e.id; });
    const unresolvedPolicyViolations = RULE_SPACE.filter(function(e){ return !e.coveragePolicy || e.coveragePolicy.noSilentFallback !== true; }).map(function(e){ return e.id; });
    return {
      duplicateIds: Array.from(new Set(duplicateIds)),
      missingSection: missingSection,
      missingEnglishChineseTitle: missingTitle,
      silentFallbackPolicyViolations: unresolvedPolicyViolations,
      uniqueRuleFamilyCount: uniqueIds.size,
      expectedRuleFamilyCount: 29,
      pass: duplicateIds.length === 0 && uniqueIds.size === 29 && missingSection.length === 0 && missingTitle.length === 0 && unresolvedPolicyViolations.length === 0
    };
  }

  global.PENGGILAS_CLASSICAL_RULE_SPACE = {
    version: "V82",
    terminology: "International English (Chinese)",
    axes: COVERAGE_AXES,
    requiredAdjudicationAxes: REQUIRED_ADJUDICATION_AXES,
    entries: RULE_SPACE,
    audit: RULE_SPACE.map(auditEntry),
    adjudicationAudit: adjudicationAudit,
    propertyChecks: propertyChecks,
    policy: {
      unresolvedMeaning: "UNRESOLVED is legitimate only after the applicable evidence/rule/adjudication space is declared and no valid closure branch is satisfied.",
      engineGapMeaning: "ENGINE_RULE_GAP means the evidence state is valid but no declared adjudication branch exists.",
      noSilentFormula: true,
      noSilentSchoolBlend: true,
      noNumericStrengthThresholdWithoutSource: true
    }
  };
})(window);
