# Univers Galactique — Données Effectifs & Managers

Données extraites et structurées à partir des notes PDF :
- `note_1113_080924259.pdf` → Managers & Sélectionneurs
- `note_1113_080838457.pdf` → Effectifs / Damistes

## Structure du package

```
galactique_data/
├── json/
│   ├── managers.json
│   ├── damistes_premiere_generation.json
│   ├── clubs_c_d.json
│   ├── galaxies_et_representants.json
│   └── schema_overview.json
├── csv/
│   ├── selectionneurs.csv
│   ├── managers_clubs.csv
│   ├── damistes_clubs.csv
│   └── galaxies.csv
└── markdown/
    └── README.md
```

## Entités principales

| Entité                        | Quantité | Identifiants          |
|-------------------------------|----------|-----------------------|
| Galaxies / Sélections         | 24       | GAL-001 → GAL-024     |
| Clubs                         | 60       | (par division)        |
| Managers de clubs             | 60       | MGR-C001 → MGR-C060   |
| Sélectionneurs                | 24       | MGR-S001 → MGR-S024   |
| Damistes (1ère génération)    | 72       | (H + F par club)      |
| Damistes total cible          | 120      | DAM-0001 → DAM-0120   |
| Représentants galactiques     | 48       | 2 par galaxie (H+F)   |

## Divisions

- **Super League** : 12 clubs
- **Ligue A** : 12 clubs
- **Ligue B** : 12 clubs
- **Ligue C** : 12 clubs (proposés)
- **Ligue D** : 12 clubs (proposés)

## Règles importantes pour la génération de code

1. Chaque club a **2 damistes** (1 homme + 1 femme) en première génération.
2. Un damiste a une **origine galactique** distincte de l’appartenance de son club.
3. Contrat club et appartenance sélection sont **deux données séparées**.
4. Les managers de clubs et les sélectionneurs ont des **contrats indépendants**.
5. Les représentants galactiques (48) peuvent signer dans les clubs.
6. Identifiants uniques obligatoires pour les damistes.

## Tables recommandées (BDD)

- `galaxy_origins` — origine galactique du damiste
- `selection_rosters` — représentants des sélections
- `selection_memberships` — convocations / historique

## Utilisation pour générateur de code

Tous les fichiers JSON et CSV sont prêts à être importés directement dans un générateur (seed data, fixtures, mocks, etc.).
Les noms sont cohérents entre les fichiers.
