/* ============================================================
   PENGGILAS — CLASSICAL EXECUTION EVIDENCE SIGNATURE
   V70: runtime evidence -> declared state-matrix branch binding with field-provenance normalization.

   This adapter is READ-ONLY. It consumes existing Core B/C evidence and
   determination output; it does not calculate BaZi or invent a formula.
   An unmatched but valid observed state is explicitly ENGINE_RULE_GAP.
   ============================================================ */
(function (global) {
  "use strict";

  const MATRIX = global.PENGGILAS_GLOBAL_CLASSICAL_STATE_MATRIX;
  if (!MATRIX) throw new Error("[ClassicalExecutionSignature] State matrix is not loaded.");
  const NORMALIZER = global.PENGGILAS_CLASSICAL_RUNTIME_EVIDENCE_NORMALIZER || null;

  const SECTION_MAP = {
    "CS-B1-STRENGTH":["B1"], "CS-B2-MONTH-COMMAND":["B2"],
    "CS-B3-PATTERN-FAMILY":["B3"], "CS-B3-GEJU-OFFICER":["B3"],
    "CS-B3-GEJU-WEALTH":["B3"], "CS-B3-GEJU-RESOURCE":["B3"],
    "CS-B3-GEJU-EATING-GOD":["B3"], "CS-B3-GEJU-HURTING-OFFICER":["B3"],
    "CS-B3-GEJU-SEVEN-KILLINGS":["B3"], "CS-B3-GEJU-YANG-REN":["B3"],
    "CS-B3-GEJU-JIAN-LU":["B3"], "CS-B3-MIXED-GEJU":["B3"],
    "CS-B3-MISCELLANEOUS-QI":["B3"], "CS-B8-HUA":["B8"],
    "CS-B11-TONG-GUAN":["B11"], "CS-B13-MULTI-METHOD":["B13"],
    "CS-B13-DISEASE-MEDICINE":["B13"], "CS-B13-CLIMATE":["B13"],
    "CS-B13-FOLLOWING":["B13"], "CS-C-TEMPORAL":["C4","C6"],
    "CS-B3-USEFUL-GOD-CHANGE":["B13"], "CS-B3-PURITY-MIXTURE":["B13"],
    "CS-B3-FORMATION-HIGH-LOW":["B3","B9"], "CS-B3-ASSISTANT-GOD":["B13"],
    "CS-B3-AUSPICIOUS-BREAK":["B3","B9"], "CS-B3-MALEFIC-FORM":["B3"],
    "CS-B6B7-SEQUENCE":["B6","B7"], "CS-B3-OUTER-PATTERNS":["B3","B9"],
    "CS-C-DAYUN-FORMATION-CHANGE":["C4","C6"]
  };

  function snake(value) {
    return String(value == null ? "" : value)
      .replace(/([a-z])([A-Z])/g,"$1_$2").toUpperCase()
      .replace(/[^A-Z0-9]+/g,"_").replace(/^_+|_+$/g,"");
  }

  function collectStrings(value, out, path) {
    out = out || [];
    path = path || "";
    if (value == null) return out;
    if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
      out.push({ path:path, value:String(value), token:snake(value) });
      return out;
    }
    if (Array.isArray(value)) { value.forEach(function(v,i){ collectStrings(v,out,path+"["+i+"]"); }); return out; }
    if (typeof value === "object") Object.keys(value).forEach(function(k){ if(k.charAt(0)!=="_") collectStrings(value[k],out,path?(path+"."+k):k); });
    return out;
  }

  function outputFor(master, section) {
    if (!master) return null;
    if (section === "B13") return { B13:master.B13_1, B13_2:master.B13_2 };
    return master[section] || null;
  }

  function traceFor(master, section) {
    const t = master && master._ruleTrace && master._ruleTrace[section];
    return Array.isArray(t) ? t : [];
  }

  function bind(entry, master) {
    const sections = SECTION_MAP[entry.id] || [];
    const observations = [];
    sections.forEach(function(section){
      const output = outputFor(master,section);
      if (NORMALIZER) {
        const normalized = NORMALIZER.normalize(master, entry.id) || [];
        normalized.forEach(function(token){
          observations.push({ path:section+"._normalizedEvidence", value:token, token:snake(token), provenance:"FIELD_NORMALIZER", class:"BRANCH" });
        });
        const atomic = NORMALIZER.evidence ? (NORMALIZER.evidence(master, entry.id) || []) : [];
        atomic.forEach(function(token){
          observations.push({ path:section+"._atomicEvidence", value:token, token:snake(token), provenance:"FIELD_NORMALIZER", class:"EVIDENCE" });
        });
      }
      // Only explicit signatureEvidence and normalized field-provenance tokens
      // are admissible execution evidence. Descriptive prose from Core output
      // and rule traces is deliberately excluded: otherwise words such as
      // OPEN/CONFLICT/RESOLVED can be mistaken for adjudicated outcomes.
      function signatureAllowed(familyId, token) {
        const t = String(token || "");
        if (familyId === "CS-B13-CLIMATE") return /^CLIMATE_/.test(t);
        if (familyId === "CS-B13-FOLLOWING") return /^FOLLOWING_/.test(t);
        return true;
      }
      function addExplicitSignatureEvidence(container, pathPrefix) {
        if (!container || typeof container !== "object") return;
        const se = container.signatureEvidence;
        if (Array.isArray(se)) se.forEach(function(token){
          if (!signatureAllowed(entry.id, token)) return;
          observations.push({ path:pathPrefix+".signatureEvidence", value:String(token), token:snake(token), provenance:"EXPLICIT_SIGNATURE_EVIDENCE", class:"BRANCH" });
        });
        else if (typeof se === "string" && signatureAllowed(entry.id, se)) observations.push({ path:pathPrefix+".signatureEvidence", value:se, token:snake(se), provenance:"EXPLICIT_SIGNATURE_EVIDENCE", class:"BRANCH" });
      }
      addExplicitSignatureEvidence(output, section);
      if (section === "B13" && output && output.B13) addExplicitSignatureEvidence(output.B13, section+".B13");
      if (section === "B13" && output && output.B13_2) addExplicitSignatureEvidence(output.B13_2, section+".B13_2");
    });

    const declaredBranches = (entry.branches || []).map(function(b){
      return { signature:String(b[0]), outcome:String(b[1]) };
    });
    const branchObservations = observations.filter(function(obs){ return obs.class !== "EVIDENCE"; });
    const atomicEvidence = observations.filter(function(obs){ return obs.class === "EVIDENCE"; });
    const matched = [];
    branchObservations.forEach(function(obs){
      declaredBranches.forEach(function(branch){
        if (obs.token === snake(branch.signature)) {
          matched.push({ outcome:branch.outcome, signature:branch.signature, matchType:"SIGNATURE", sourcePath:obs.path, observed:obs.value });
        } else if (obs.token === snake(branch.outcome)) {
          matched.push({ outcome:branch.outcome, signature:branch.signature, matchType:"OUTCOME", sourcePath:obs.path, observed:obs.value });
        }
      });
    });
    const unique = [];
    matched.forEach(function(m){
      if(!unique.some(function(x){return x.outcome===m.outcome;})) unique.push(m);
    });

    let status = observations.length === 0 ? "NO_OBSERVED_EVIDENCE" : (branchObservations.length === 0 ? "EVIDENCE_OBSERVED_NO_CLOSURE" : "ENGINE_RULE_GAP");
    let branch = null;
    if (unique.length === 1) {
      branch = (entry.branches || []).find(function(b){ return String(b[1]) === unique[0].outcome; }) || null;
      status = branch ? "BOUND" : "ENGINE_RULE_GAP";
    } else if (unique.length > 1) {
      status = "CONFLICT";
    }

    const closureState = (function(){
      if (unique.length > 1) return "CONFLICT";
      if (!branch) return null;
      if (entry.id === "CS-B13-CLIMATE" || entry.id === "CS-B13-FOLLOWING") {
        const sig = String(branch[0] || "");
        if (/_CLOSURE_COMPLETE$/.test(sig)) return "CLOSED";
        if (/_CLOSURE_BLOCKED$/.test(sig)) return "OPEN";
        return null;
      }
      return null;
    })();

    return {
      ruleFamily: entry.id,
      title: entry.title,
      sections: sections.slice(),
      observedEvidenceCount: observations.length,
      atomicEvidenceCount: atomicEvidence.length,
      atomicEvidence: atomicEvidence.map(function(x){ return {token:x.value, provenance:x.provenance, sourcePath:x.path}; }),
      branchEvidenceCount: branchObservations.length,
      matchedOutcomes: unique,
      matchTypes: Array.from(new Set(matched.map(function(m){ return m.matchType; }))),
      selectedBranch: branch ? { signature:branch[0], outcome:branch[1] } : null,
      closureState: closureState,
      status: status,
      policy: status === "NO_OBSERVED_EVIDENCE"
        ? "No evidence was supplied for this rule family in the current execution payload; this is not an ENGINE_RULE_GAP."
        : (status === "EVIDENCE_OBSERVED_NO_CLOSURE"
          ? "Atomic field-provenance evidence was observed, but the current Core did not assert a complete branch-ready adjudication signature; this is not an ENGINE_RULE_GAP."
          : (status === "ENGINE_RULE_GAP"
          ? "Valid/current evidence was observed, but no declared state-matrix outcome branch matched exactly; no outcome is inferred."
          : (status === "CONFLICT" ? "More than one declared outcome is directly observed; no precedence is invented." : "Existing Core evidence directly binds to a declared matrix outcome; no new BaZi calculation is performed.")))
    };
  }

  function bindAll(master) {
    const rows = MATRIX.entries.map(function(entry){ return bind(entry, master); });
    return {
      version:"V70",
      mode:"EXECUTION_LEVEL_EVIDENCE_SIGNATURE",
      ruleFamilies:rows.length,
      bound:rows.filter(function(r){return r.status==="BOUND";}).length,
      engineRuleGaps:rows.filter(function(r){return r.status==="ENGINE_RULE_GAP";}).length,
      noObservedEvidence:rows.filter(function(r){return r.status==="NO_OBSERVED_EVIDENCE";}).length,
      conflicts:rows.filter(function(r){return r.status==="CONFLICT";}).length,
      rows:rows,
      rule:"This layer validates runtime evidence against the declared state matrix; it never upgrades UNRESOLVED, MULTI_METHOD, CONFLICT, PROVISIONAL, or CANDIDATE states."
    };
  }

  global.PENGGILAS_CLASSICAL_EXECUTION_SIGNATURE = { version:"V70", sectionMap:SECTION_MAP, bindAll:bindAll };
})(window);
