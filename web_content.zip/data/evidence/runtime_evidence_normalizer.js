/* ============================================================
   PENGGILAS — RUNTIME EVIDENCE NORMALIZATION
   V70: field-provenance normalization for actual Core B/C output.

   READ-ONLY. This layer does not calculate BaZi, select school precedence,
   or convert descriptive prose into an adjudicated outcome.

   Two evidence classes are kept separate:
   - EVIDENCE: atomic source/evidence dimensions observed at runtime.
   - BRANCH: complete branch-ready signature explicitly closed by existing Core.
   ============================================================ */
(function (global) {
  "use strict";

  const CLOSURE_CONTRACT = global.PENGGILAS_CLASSICAL_CLOSURE_SIGNAL_CONTRACT || null;

  function present(x, key) { return !!x && x[key] != null && x[key] !== ""; }
  function starts(x, text) { return String(x || "").indexOf(text) === 0; }

  function b1(master) {
    const b1 = master && master.B1;
    if (!b1) return [];
    const out = [];
    const strong = b1._strengthClass === "STRONG";
    const weak = b1._strengthClass === "WEAK";
    const unresolved = b1._strengthClass === "UNRESOLVED";
    const month = /YES/i.test(String(b1.yueLing && b1.yueLing.result || ""));
    const root = String(b1.rootPresence || "") === "Yes";
    const support = starts(b1.resource && b1.resource.result, "Present") || starts(b1.companion && b1.companion.result, "Present");
    const counter = starts(b1.output && b1.output.result, "Present") || starts(b1.wealth && b1.wealth.result, "Present") || starts(b1.officer && b1.officer.result, "Present");
    if (strong && month && root && support) out.push("CONVERGENT_SUPPORT");
    if (weak && !month && !root && counter && !support) out.push("CONVERGENT_DRAIN_CONTROL");
    if (unresolved && support && counter) out.push("MIXED_SUPPORT_AND_COUNTER");
    if (unresolved && !support && !counter) out.push("NO_DECISIVE_EVIDENCE");
    return out;
  }

  function b2(master) {
    const b2 = master && master.B2;
    if (!b2) return [];
    if (present(b2.monthCommand, "result") && present(b2.mainQi, "result")) return ["PROFILE_SELECTED"];
    return [];
  }

  function b3GeJuBranch(master, familyId) {
    const evidence = b3Evidence(master, familyId);
    if (!evidence.length) return [];
    const has = x => evidence.indexOf(x) !== -1;
    const anyClean = (paths, counters) => {
      const counterHit = counters.some(has);
      if (counterHit) return [];
      return paths.some(path => path.every(has)) ? ["FORMATION_CLEAN"] : [];
    };
    switch (familyId) {
      case "CS-B3-GEJU-OFFICER":
        return anyClean([
          ["OFFICER_MONTH","WEALTH_SUPPORT","RESOURCE_SUPPORT","DAY_MASTER_CAPACITY"]
        ], ["HURTING_OFFICER","SEVEN_KILLINGS_MIX"]);
      case "CS-B3-GEJU-WEALTH": {
        // The declared Wealth Pattern (财格) profile has three distinct
        // formation routes. Do not apply the strongest route's Day-Master
        // requirement as a global veto to the other source routes.
        const has = x => evidence.indexOf(x) !== -1;
        const killing = has("KILLING_CONTAMINATION");
        const companionPressure = has("COMPANION_PRESSURE_UNRESOLVED");
        const weakDayMaster = has("WEAK_DAY_MASTER");
        const officerRoute = has("WEALTH_MONTH") && has("WEALTH_OFFICER_ROUTE") && !killing && !companionPressure;
        const outputRoute = has("WEALTH_MONTH") && has("OUTPUT_SUPPORT") && has("STRONG_COMPANION_ROUTE") && !killing && !weakDayMaster;
        const resourceRoute = has("WEALTH_MONTH") && has("RESOURCE_POSITIONAL_ROUTE") && !killing && !companionPressure;
        return (officerRoute || outputRoute || resourceRoute) ? ["FORMATION_CLEAN"] : [];
      }
      case "CS-B3-GEJU-RESOURCE":
        return anyClean([
          ["RESOURCE_MONTH","KILLING_RESOURCE_ROUTE"],
          ["RESOURCE_MONTH","OFFICER_RESOURCE_SUPPORT"],
          ["RESOURCE_MONTH","STRONG_RESOURCE_OUTPUT_ROUTE"]
        ], ["WEALTH_DAMAGE_UNRESOLVED","RESOURCE_OVERLOAD_UNRESOLVED"]);
      case "CS-B3-GEJU-EATING-GOD":
        return anyClean([
          ["EATING_GOD_MONTH","WEALTH_ROUTE","NO_KILLING_CONTAMINATION"],
          ["EATING_GOD_MONTH","KILLING_RESOURCE_ROUTE","NO_WEALTH_ROUTE"]
        ], ["INDIRECT_RESOURCE_DAMAGE","KILLING_CONTAMINATION"]);
      case "CS-B3-GEJU-HURTING-OFFICER":
        return anyClean([
          ["HURTING_OFFICER_MONTH","WEALTH_ROUTE","NO_KILLING_CONTAMINATION"],
          ["HURTING_OFFICER_MONTH","RESOURCE_ROUTE","STRONG_HURTING_ROUTE","NO_KILLING_CONTAMINATION"],
          ["HURTING_OFFICER_MONTH","WEAK_HURTING_KILLING_RESOURCE_ROUTE","NO_WEALTH_ROUTE"],
          ["HURTING_OFFICER_MONTH","KILLING_ROUTE","NO_WEALTH_ROUTE"]
        ], ["OFFICER_CONFLICT","WEALTH_KILLING_CONFLICT"]);
      case "CS-B3-GEJU-SEVEN-KILLINGS":
        return anyClean([
          ["KILLINGS","DAY_MASTER_CAPACITY","CONTROL_SUPPORT"]
        ], ["WEALTH_FEEDING_KILLING","WEAK_DAY_MASTER"]);
      case "CS-B3-GEJU-JIAN-LU":
        return anyClean([
          ["JIAN_LU_MONTH_ROB","OFFICER_WITH_WEALTH_OR_RESOURCE"],
          ["JIAN_LU_MONTH_ROB","WEALTH_WITH_OUTPUT"],
          ["JIAN_LU_MONTH_ROB","KILLING_WITH_CONTROL"]
        ], ["UNRESOLVED_USABLE_ROUTE"])
          .map(function(){ return "OFFICER_WITH_SUPPORT"; });
      default: return [];
    }
  }

  function b3Branches(master) {
    const b3 = master && master.B3;
    if (!b3) return [];
    const yr = b3._yangRen;
    if (yr && yr.isYangRen) {
      if (starts(yr.formation, "SOURCE-BASED BASE FORMATION PASSED")) return ["FORMATION_NO_BREAK"];
      if (yr.rescueStatus === "CANDIDATE_PATHS_IDENTIFIED") return ["BREAK_WITH_RESCUE"];
    }
    return [];
  }

  function miscellaneousQiEvidence(master) {
    const b3 = master && master.B3;
    const m = b3 && b3._miscQi;
    if (!m || !m.applicable) return [];
    const out = [];
    const add = x => { if (x && out.indexOf(x) === -1) out.push(x); };
    add("MIXED_QI_MONTH");
    if (m.exposedRoutes && m.exposedRoutes.length) add("EXPOSED_HIDDEN_STEM");
    if (m.assemblyRoutes && m.assemblyRoutes.length) add("BRANCH_COMBINATION");
    if (m.hiddenQi && m.hiddenQi.length > 1) add("MULTIPLE_HIDDEN_QI");
    if (String(m.affinity || "").indexOf("YOU_QING") === 0) add("AFFINITY");
    if (m.routes && m.routes.length > 1 && String(m.affinity || "").indexOf("RECONCILIATION") !== -1) add("EXPOSURE_COMBINATION_CONFLICT");
    return out;
  }

  function miscellaneousQiBranchEvidence(master) {
    const b3 = master && master.B3;
    const m = b3 && b3._miscQi;
    if (!m || !m.applicable) return [];
    if (m.status && String(m.status).indexOf("ADVERSE") !== -1) return ["ADVERSE_ROUTE_INTERACTION"];
    if (m.routes && m.routes.length === 1 && m.exposedRoutes && m.exposedRoutes.length === 1 && (!m.assemblyRoutes || !m.assemblyRoutes.length)) return ["EXPOSURE_ROUTE_SELECTED"];
    if (m.routes && m.routes.length === 1 && m.assemblyRoutes && m.assemblyRoutes.length === 1 && (!m.exposedRoutes || !m.exposedRoutes.length)) return ["COMBINATION_ROUTE_SELECTED"];
    if (String(m.affinity || "").indexOf("YOU_QING") === 0) return ["AFFINITY_RECONCILED_ROUTE"];
    return [];
  }

  function b3Evidence(master, familyId) {
    const b3 = master && master.B3;
    const b4 = master && master.B4;
    const a10 = master && master.A10_4;
    if (!b3 || !b4) return [];
    const pe = b3._patternEvidence || {};
    const monthGod = pe.monthGodCode || b4._monthCommandGodCode;
    const visible = new Set(pe.visibleTenGodCodes || []);
    const out = [];
    const add = x => { if (x && out.indexOf(x) === -1) out.push(x); };
    const presentGod = key => !!(a10 && a10[key] && a10[key].status === "PRESENT");
    const dmCapacity = master.B1 && master.B1._strengthClass && master.B1._strengthClass !== "UNRESOLVED";

    switch (familyId) {
      case "CS-B3-GEJU-OFFICER":
        if (monthGod !== "ZhengGuan") break;
        add("OFFICER_MONTH");
        if (presentGod("pianCai") || presentGod("zhengCai")) add("WEALTH_SUPPORT");
        if (presentGod("pianYin") || presentGod("zhengYin")) add("RESOURCE_SUPPORT");
        // Day-Master capacity is an observed structural condition, not a synonym
        // for a closed B1 Strong/Weak adjudication. Root/support evidence already
        // exposed by Core is sufficient for this source-path dimension.
        if (dmCapacity || (master.B1 && master.B1.rootPresence === "Yes")) add("DAY_MASTER_CAPACITY");
        if (visible.has("ShangGuan")) add("HURTING_OFFICER");
        if (visible.has("QiSha")) add("SEVEN_KILLINGS_MIX");
        break;
      case "CS-B3-GEJU-WEALTH":
        if (monthGod !== "ZhengCai" && monthGod !== "PianCai") break;
        add("WEALTH_MONTH");
        if (visible.has("ZhengGuan") || visible.has("QiSha")) add("WEALTH_OFFICER_ROUTE");
        if (presentGod("shiShen") || presentGod("shangGuan")) add("OUTPUT_SUPPORT");
        if ((visible.has("BiJian") || visible.has("JieCai")) && master.B1 && master.B1._strengthClass === "STRONG") add("STRONG_COMPANION_ROUTE");
        if (presentGod("zhengYin") || presentGod("pianYin")) add("RESOURCE_POSITIONAL_ROUTE");
        if ((visible.has("BiJian") || visible.has("JieCai")) && !(master.B1 && master.B1._strengthClass === "STRONG")) add("COMPANION_PRESSURE_UNRESOLVED");
        if (visible.has("QiSha")) add("KILLING_CONTAMINATION");
        if (master.B1 && master.B1._strengthClass === "WEAK") add("WEAK_DAY_MASTER");
        break;
      case "CS-B3-GEJU-RESOURCE":
        if (monthGod !== "ZhengYin" && monthGod !== "PianYin") break;
        add("RESOURCE_MONTH");
        if (presentGod("pianYin") || presentGod("zhengYin")) add("USABLE_RESOURCE");
        if (visible.has("ZhengGuan") || visible.has("QiSha")) add("OFFICER_RESOURCE_SUPPORT");
        if (visible.has("QiSha")) add("KILLING_RESOURCE_ROUTE");
        if (presentGod("shiShen") || presentGod("shangGuan")) add("STRONG_RESOURCE_OUTPUT_ROUTE");
        break;
      case "CS-B3-GEJU-EATING-GOD":
        if (monthGod !== "ShiShen") break;
        add("EATING_GOD_MONTH");
        if (presentGod("pianCai") || presentGod("zhengCai")) add("WEALTH_ROUTE");
        else add("NO_WEALTH_ROUTE");
        if (visible.has("QiSha")) add("KILLING_ROUTE");
        if (presentGod("pianYin")) add("INDIRECT_RESOURCE_DAMAGE");
        if (visible.has("QiSha") && (presentGod("pianYin") || presentGod("zhengYin"))) add("KILLING_RESOURCE_ROUTE");
        if (!visible.has("QiSha")) add("NO_KILLING_CONTAMINATION");
        if (visible.has("QiSha") && (presentGod("pianCai") || presentGod("zhengCai"))) add("KILLING_CONTAMINATION");
        break;
      case "CS-B3-GEJU-HURTING-OFFICER":
        if (monthGod !== "ShangGuan") break;
        add("HURTING_OFFICER_MONTH");
        const hoWealth = presentGod("pianCai") || presentGod("zhengCai");
        const hoResource = presentGod("pianYin") || presentGod("zhengYin");
        if (hoWealth) add("WEALTH_ROUTE"); else add("NO_WEALTH_ROUTE");
        if (hoResource) add("RESOURCE_ROUTE");
        if (dmCapacity) add("DAY_MASTER_CONDITION");
        if (master.B1 && master.B1._strengthClass === "STRONG") add("STRONG_HURTING_ROUTE");
        if (master.B1 && master.B1._strengthClass === "WEAK" && visible.has("QiSha") && hoResource) add("WEAK_HURTING_KILLING_RESOURCE_ROUTE");
        if (visible.has("QiSha")) add("KILLING_ROUTE");
        if (visible.has("ZhengGuan")) add("OFFICER_CONFLICT");
        if (visible.has("QiSha") && hoWealth) add("WEALTH_KILLING_CONFLICT");
        if (!visible.has("QiSha")) add("NO_KILLING_CONTAMINATION");
        break;
      case "CS-B3-GEJU-SEVEN-KILLINGS":
        if (monthGod !== "QiSha") break;
        add("KILLINGS");
        if (dmCapacity || (master.B1 && master.B1.rootPresence === "Yes")) add("DAY_MASTER_CAPACITY");
        if (visible.has("ShiShen") || visible.has("ShangGuan") || presentGod("pianYin") || presentGod("zhengYin")) add("CONTROL_SUPPORT");
        if (presentGod("pianCai") || presentGod("zhengCai")) add("WEALTH_FEEDING_KILLING");
        if (master.B1 && master.B1._strengthClass === "WEAK") add("WEAK_DAY_MASTER");
        break;
      case "CS-B3-GEJU-YANG-REN":
        if (!pe.isYangRen) break;
        add("YANG_DAY_MASTER");
        if (pe.isYangRen) add("YANG_REN_MONTH");
        if (b3._yangRen && b3._yangRen.exposedOfficer) add("EXPOSED_OFFICER_KILLING");
        if (b3._yangRen && (b3._yangRen.exposedWealth || b3._yangRen.exposedResource)) add("WEALTH_RESOURCE");
        if (b3._yangRen && b3._yangRen.exposedHurtingOfficer) add("EXPOSED_HURTING_OFFICER");
        break;
      case "CS-B3-GEJU-JIAN-LU":
        if (monthGod !== "BiJian" && monthGod !== "JieCai") break;
        add("JIAN_LU_MONTH_ROB");
        const jlOfficer = presentGod("zhengGuan");
        const jlWealth = presentGod("pianCai") || presentGod("zhengCai");
        const jlResource = presentGod("pianYin") || presentGod("zhengYin");
        const jlOutput = presentGod("shiShen") || presentGod("shangGuan");
        const jlKilling = visible.has("QiSha");
        if (jlOfficer && (jlWealth || jlResource)) add("OFFICER_WITH_WEALTH_OR_RESOURCE");
        if (jlWealth && jlOutput) add("WEALTH_WITH_OUTPUT");
        if (jlKilling && (visible.has("ShiShen") || visible.has("ShangGuan") || jlOutput)) add("KILLING_WITH_CONTROL");
        if (!jlOfficer && !jlWealth && !jlResource && !jlKilling) add("UNRESOLVED_USABLE_ROUTE");
        break;
      default: break;
    }
    return out;
  }



  function usefulGodChangeEvidence(master) {
    const b3=master&&master.B3, b13=master&&master.B13_2;
    if(!b3||!b13) return [];
    const out=[]; const add=x=>{if(out.indexOf(x)<0)out.push(x)};
    const pe=b3._patternEvidence||{};
    if(pe.monthGodCode) add("BASE_USEFUL_GOD");
    const hasRoutes=(b3._miscQi&&b3._miscQi.routes&&b3._miscQi.routes.length)||0;
    if(hasRoutes>0 || (b3._yangRen&&b3._yangRen.isYangRen)) add("TRANSFORMATION_STRUCTURE");
    const visible=pe.visibleTenGodCodes||[];
    if(visible.length) add("EXPOSURE_CHANGE_FACTOR");
    if(b13.yongShen && /CONFLICT|MULTI_METHOD|OPEN|CANDIDATE/i.test(String(b13.yongShen.status))) add("CHANGED_STATE_NOT_CLOSED");
    return out;
  }
  function usefulGodChangeBranch(master){
    const b3=master&&master.B3, b13=master&&master.B13_2; if(!b3||!b13)return[];
    const misc=b3._miscQi||{};
    if(misc.status && /MULTI_ROUTE/.test(misc.status)) return ["TRANSFORMATION_OPEN"];
    return [];
  }

  function purityMixtureEvidence(master){
    const b3=master&&master.B3,b13=master&&master.B13_2;if(!b3||!b13)return[];
    const out=[];const add=x=>{if(out.indexOf(x)<0)out.push(x)};
    if(b3._patternEvidence&&b3._patternEvidence.monthGodCode)add("USEFUL_STRUCTURE");
    const misc=b3._miscQi||{};
    if((misc.routes||[]).length>1)add("MIXTURE");
    if((misc.routes||[]).length===1)add("CLEAN_ROUTE");
    if(b13.yongShen && /CONFLICT|MULTI_METHOD|OPEN/i.test(String(b13.yongShen.status)))add("COMPETING_ROUTE");
    return out;
  }
  function purityMixtureBranch(master){
    const b3=master&&master.B3;if(!b3)return[];
    const misc=b3._miscQi||{};
    // Multiple live routes are directly observable as a mixture/competition
    // signal. A single route is NOT sufficient to assert Classical purity:
    // purity requires source-complete exclusion of contamination and closure.
    if((misc.routes||[]).length>1)return ["COMPETING_ROUTES"];
    return [];
  }

  function bridge(master, key) {
    return master && master.B3 && master.B3._evidentiaryBridge
      ? (master.B3._evidentiaryBridge[key] || null) : null;
  }
  function formationQualityEvidence(master){
    const b=bridge(master,"formationQuality"); if(!b)return[]; const out=[]; const add=x=>{if(out.indexOf(x)<0)out.push(x)};
    if(b.formation)add("FORMATION_STATE");
    if(b.affinity && /YOU_QING/i.test(String(b.affinity)))add("AFFINITY");
    if(b.affinity && /WU_QING/i.test(String(b.affinity)))add("INAFFINITY");
    if((b.force||[]).length)add("FORCE");
    if(b.position && (b.position.touGan || b.position.rootPresence))add("POSITION");
    if(b.sequence && b.sequence.routeCount)add("SEQUENCE");
    (b.counterEvidence||[]).forEach(add);
    return out;
  }
  function formationQualityBranch(master){
    const b=bridge(master,"formationQuality"); if(!b || b.closureStatus!=="CLOSED") return ["INSUFFICIENT_QUALITY_EVIDENCE"];
    if((b.counterEvidence||[]).indexOf("MIXTURE")>=0)return ["MIXED_QUALITY_FACTORS"];
    if((b.counterEvidence||[]).indexOf("INAFFINITY")>=0 || (b.counterEvidence||[]).indexOf("WEAK_FORCE")>=0)return ["INAFFINITY_OR_WEAK_FORCE"];
    return ["AFFINITY_AND_FORCE_SUPPORT"];
  }

  function assistantGodEvidence(master){
    const b=bridge(master,"assistantGod"); if(!b)return[]; const out=[]; const add=x=>{if(out.indexOf(x)<0)out.push(x)};
    if(b.usefulGod)add("USEFUL_GOD");
    if((b.supportingFactors||[]).length)add("SUPPORTING_FACTOR");
    if((b.functionalDependencyCandidates||[]).length)add("PATTERN_DEPENDENCY");
    if((b.patternReliance||[]).length)add("PATTERN_RELIANCE");
    (b.counterEvidence||[]).forEach(add); return out;
  }
  function assistantGodBranch(master){
    const b=bridge(master,"assistantGod"); if(!b || b.closureStatus!=="CLOSED")return[];
    if((b.counterEvidence||[]).indexOf("ASSISTANT_DAMAGED")>=0)return ["ASSISTANT_DAMAGED"];
    if((b.counterEvidence||[]).indexOf("ASSISTANT_CONFLICT")>=0)return ["ASSISTANT_CONFLICT"];
    if(!(b.functionalDependencyCandidates||[]).length)return ["NO_ASSISTANT_REQUIRED"];
    return ["ASSISTANT_SUPPORTS_PATTERN"];
  }

  function auspiciousBreakEvidence(master){
    const b=bridge(master,"auspiciousBreak"); if(!b)return[]; const out=[]; const add=x=>{if(out.indexOf(x)<0)out.push(x)};
    if((b.auspiciousFactors||[]).length)add("AUSPICIOUS_GOD");
    if((b.breakingFactors||[]).length)add("BREAKING_ACTION");
    if((master.B3&&master.B3._patternEvidence&&master.B3._patternEvidence.monthGodCode))add("FORMATION_DEPENDENCE");
    if((b.materialBreakingAction||[]).length)add("MATERIAL_BREAKING_ACTION");
    if((b.rescueRoutes||[]).length)add("RESCUE_ROUTE");
    if((b.rescuePersistence||[]).length)add("RESCUE_OR_PERSISTENCE");
    return out;
  }
  function auspiciousBreakBranch(master){
    const b=bridge(master,"auspiciousBreak"); if(!b || b.closureStatus!=="CLOSED")return ["NO_CLOSURE"];
    if((b.rescuePersistence||[]).length && (b.materialBreakingAction||[]).length)return ["BREAKING_WITH_RESCUE"];
    if((b.materialBreakingAction||[]).length)return ["MATERIAL_BREAKING_EFFECT"];
    return ["NO_BREAKING_EFFECT"];
  }

  function maleficFormEvidence(master){
    const b=bridge(master,"maleficForm"); if(!b)return[]; const out=[]; const add=x=>{if(out.indexOf(x)<0)out.push(x)};
    if((b.maleficFactors||[]).length)add("MALEFIC_GOD");
    if((b.patternRole||[]).length)add("PATTERN_ROLE");
    if((b.functionalRoutes||[]).length)add("FUNCTIONAL_ROUTE");
    if((b.controlOrConversion||[]).length)add("CONTROL_OR_CONVERSION");
    if(b.netEffect)add("NET_EFFECT"); return out;
  }
  function maleficFormBranch(master){
    const b=bridge(master,"maleficForm"); if(!b || b.closureStatus!=="CLOSED")return ["NO_CLOSURE"];
    if((b.functionalRoutes||[]).length && (b.controlOrConversion||[]).length && b.netEffect)return ["FUNCTIONAL_MALEFIC_ROLE"];
    return ["NO_FUNCTIONAL_ROUTE"];
  }

  function outerPatternsEvidence(master){
    const b=bridge(master,"outerPatterns"); if(!b)return[]; const out=[]; const add=x=>{if(out.indexOf(x)<0)out.push(x)};
    if(b.specialConfiguration)add("SPECIAL_CONFIGURATION");
    if(b.ordinaryPatternExclusion)add("ORDINARY_PATTERN_EXCLUSION");
    if((b.sourceRequirements||[]).length)add("SOURCE_REQUIREMENTS");
    if(b.ordinaryPattern && !b.ordinaryPatternExclusion)add("ORDINARY_PATTERN_PRESENT");
    return out;
  }
  function outerPatternsBranch(master){
    const b=bridge(master,"outerPatterns"); if(!b || b.closureStatus!=="CLOSED") {
      if(b && b.ordinaryPattern && !b.specialConfiguration)return ["ORDINARY_PATTERN_OR_MISSING_REQUIREMENT"];
      return ["SPECIAL_RULE_OPEN"];
    }
    if(b.ordinaryPatternExclusion === "CONTRARY_FORCE_EXCLUDED_BY_SCREEN")return ["SPECIAL_PATTERN_CANDIDATE"];
    if(b.ordinaryPattern)return ["ORDINARY_PATTERN_OR_MISSING_REQUIREMENT"];
    return ["SPECIAL_RULE_OPEN"];
  }


  /* ============================================================
     B6/B7 — RELATION EVIDENCE
     Read-only bridge. Existing Core exposes detected relations, but does
     not expose a complete production/control order+position adjudication.
     Therefore these functions emit atomic evidence only; no branch closure
     is invented.
     ============================================================ */
  function b6b7Evidence(master){
    const b6=master&&master.B6, b7=master&&master.B7;
    if(!b6&&!b7)return [];
    const out=[]; const add=x=>{if(x&&out.indexOf(x)<0)out.push(x)};
    const stem=(b6&&Array.isArray(b6._interactions))?b6._interactions:[];
    const branch=(b7&&Array.isArray(b7._interactions))?b7._interactions:[];
    if(stem.length) add("STEM_RELATION_DETECTED");
    if(branch.length) add("BRANCH_RELATION_DETECTED");
    if(b7&&b7._interactionClasses){
      if((b7._interactionClasses.combinations||[]).length)add("COMBINATION_RELATION");
      if((b7._interactionClasses.conflicts||[]).length)add("CONFLICT_RELATION");
      if((b7._interactionClasses.secondary||[]).length)add("SECONDARY_RELATION");
    }
    if(!stem.length&&!branch.length)add("NO_RELATION_DETECTED");
    return out;
  }

  function b6b7Branch(master){
    // Core B6/B7 currently exposes detected relations, but no complete
    // production/control order + position adjudication. When relation
    // evidence is present without an explicit sequence resolution, bind the
    // declared OPEN branch only. Do not infer SUPPORTIVE/HARMFUL/CONFLICT.
    const evidence=b6b7Evidence(master);
    if(!evidence.length || evidence.indexOf("NO_RELATION_DETECTED")>=0) return [];
    return ["SEQUENCE_OPEN"];
  }

  /* ============================================================
     B8 — HUA EVIDENCE
     B8.status is derived from the selected source profile in A12.7. We only
     expose its machine-readable status categories; no independent He -> Hua
     calculation is performed here.
     ============================================================ */
  function b8Evidence(master){
    const b8=master&&master.B8;
    if(!b8)return [];
    const out=[]; const add=x=>{if(x&&out.indexOf(x)<0)out.push(x)};
    const status=String(b8.status&&b8.status.result||"");
    const condition=String(b8.condition&&b8.condition.result||"");
    const candidate=String(b8.candidate&&b8.candidate.result||"");
    if(candidate && candidate!=="None") add("HE_PAIR_PRESENT");
    if(/He only/i.test(status)) add("HE_WITHOUT_HUA_CLOSURE");
    if(/confirmed under selected source profile/i.test(status)) add("HUA_CONFIRMED");
    if(/candidate \/ unconfirmed/i.test(status)) add("HUA_CANDIDATE");
    if(/blocked/i.test(status)) add("HUA_BLOCKED");
    if(/position unresolved/i.test(status)) add("HUA_POSITION_UNRESOLVED");
    if(/competition unresolved/i.test(status)) add("HUA_COMPETITION_UNRESOLVED");
    if(/no independent natal target-element root\/support/i.test(condition)) add("HUA_TARGET_ROOT_SUPPORT_MISSING");
    if(/source-screened \/ unconfirmed/i.test(status)) add("HUA_SCREENED_UNCONFIRMED");
    if(condition) add("HUA_CONDITION_REPORTED");
    return out;
  }

  function b8Branch(master){
    const b8=master&&master.B8;
    if(!b8)return [];
    const status=String(b8.status&&b8.status.result||"");
    if(/confirmed under selected source profile/i.test(status)) return ["HUA_CONFIRMED"];
    if(/He only/i.test(status)) return ["HE_WITHOUT_HUA_CLOSURE"];
    // Candidate/screened/blocked/position/competition states remain open in
    // the current Core output; no CONFIRMED branch is inferred.
    return [];
  }

  /* ============================================================
     B11 — TONG GUAN
     The Core exposes mediatorChecks and passageStatus explicitly. This is
     sufficient for the declared candidate branch, but not for a stronger
     Classical closure beyond what Core already reports.
     ============================================================ */
  function b11Evidence(master){
    const b11=master&&master.B11;
    if(!b11)return [];
    const out=[]; const add=x=>{if(x&&out.indexOf(x)<0)out.push(x)};
    const checks=Array.isArray(b11._mediatorChecks)?b11._mediatorChecks:[];
    if(!checks.length){
      add("NO_OPPOSED_RELATION");
      return out;
    }
    add("OPPOSED_FORCES");
    if(checks.some(x=>x.mediator&&x.mediator!=="NONE CONFIGURED"))add("MEDIATOR_IDENTIFIED");
    if(checks.some(x=>x.mediatorPresent))add("MEDIATOR_PRESENT");
    if(checks.some(x=>x.mediator && !x.mediatorPresent))add("MEDIATOR_ABSENT");
    if(checks.some(x=>x.mediatorPresent&&x.mediator))add("PASSAGE_CANDIDATE");
    return out;
  }

  function b11Branch(master){
    const b11=master&&master.B11;
    if(!b11)return [];
    const checks=Array.isArray(b11._mediatorChecks)?b11._mediatorChecks:[];
    if(!checks.length)return ["NO_OPPOSITION"];
    if(checks.some(x=>x.mediatorPresent&&x.mediator))return ["MEDIATOR_PRESENT_NO_EFFECTIVENESS"];
    if(checks.some(x=>x.mediator && !x.mediatorPresent))return ["BROKEN_OR_UNSUPPORTED"];
    return [];
  }

  /* ============================================================
     C1–C7 — TEMPORAL EVIDENCE
     These functions consume only fields explicitly emitted by Core C.
     They do not recalculate temporal relations.
     ============================================================ */
  function cTemporalEvidence(master){
    const c1=master&&master.C1,c2=master&&master.C2,c3=master&&master.C3,c4=master&&master.C4,c5=master&&master.C5,c6=master&&master.C6,c7=master&&master.C7;
    const out=[]; const add=x=>{if(x&&out.indexOf(x)<0)out.push(x)};
    if(!c1&&!c2&&!c3&&!c4&&!c5&&!c6&&!c7)return [];
    if(c1){ add("DA_YUN_INPUT_EXECUTED"); if(c1.touQing)add("TOU_QING_SCREEN_REPORTED"); }
    if(c2){ if(Array.isArray(c2._clashHits)&&c2._clashHits.length)add("TEMPORAL_CLASH"); else add("TEMPORAL_INTERACTION_SCAN"); }
    if(c3){ if(c3.evidence&&c3.evidence.temporalElements) add("TEMPORAL_ELEMENT_COMPOSITION"); if(c3.evidence&&c3.evidence.natalInteractions) add("NATAL_INTERACTION_DEPENDENCY"); }
    if(c4&&c4.evidence){
      if(c4.evidence.temporalFormationEvidence)add("TEMPORAL_FORMATION_SUPPORT");
      if(c4.evidence.temporalDisruptionEvidence)add("TEMPORAL_PATTERN_DISRUPTION");
      if(c4.evidence.natalPatternResolved)add("NATAL_PATTERN_RESOLVED");
    }
    if(c5&&c5.evidence){
      if(c5.evidence.temporalElements) add("TEMPORAL_BALANCE_EVIDENCE");
      if(c5.evidence.determinationStatus)add("USEFUL_GOD_STATUS_CONSUMED");
    }
    if(c6&&c6.evidence){
      if(c6.evidence.determinationStatus)add("TEMPORAL_DETERMINATION_STATUS");
      if(c6.evidence.adjudication)add("DETERMINATION_CONTRACT_CONSUMED");
    }
    if(c7){ add("TEMPORAL_VERIFICATION_ROWS"); }
    return out;
  }

  function cTemporalBranch(master){
    const c4=master&&master.C4;
    const ev=c4&&c4.evidence;
    if(!ev)return [];
    // A Month-Command clash is only pressure evidence until the source-required
    // resulting structure and stability/continuity are exposed. Core C itself
    // labels this as a Bian Ge candidate, so do not promote it to a closed branch.
    if(ev.temporalDisruptionEvidence)return [];
    // Reinforcement becomes an activation branch only when the natal structure
    // is already resolved. A raw Ten-God match is never sufficient by itself.
    if(ev.temporalFormationEvidence && ev.natalPatternResolved)return ["TEMPORAL_SUPPORTS_NATAL"];
    if(ev.temporalReinforcementOnly && ev.natalPatternResolved)return ["TEMPORAL_SUPPORTS_NATAL"];
    return [];
  }

  function cDayunFormationEvidence(master){
    const c4=master&&master.C4;
    const ev=c4&&c4.evidence;
    if(!ev)return [];
    const out=[]; const add=x=>{if(x&&out.indexOf(x)<0)out.push(x)};
    if(ev.natalPatternResolved)add("NATAL_PATTERN");
    if(ev.temporalFormationEvidence)add("TEMPORAL_FORMATION_SUPPORT");
    if(ev.temporalDisruptionEvidence)add("TEMPORAL_DISRUPTION");
    if(!ev.temporalFormationEvidence&&!ev.temporalDisruptionEvidence)add("NO_EFFECTIVE_CHANGE");
    return out;
  }

  function cDayunFormationBranch(master){
    const c4=master&&master.C4;
    const ev=c4&&c4.evidence;
    if(!ev)return [];
    // Disruption without a demonstrated resulting stable structure remains open.
    if(ev.temporalDisruptionEvidence)return [];
    // A reinforcement of an already-resolved natal pattern is supplemental, not
    // a new formation/change. No Cheng Ge branch is inferred from Ten-God matching.
    if(ev.temporalFormationEvidence && ev.natalPatternResolved)return ["NO_EFFECTIVE_CHANGE"];
    if(ev.temporalReinforcementOnly && ev.natalPatternResolved)return ["NO_EFFECTIVE_CHANGE"];
    if(ev.temporalFormationEvidence && !ev.natalPatternResolved)return [];
    return ["NO_EFFECTIVE_CHANGE"];
  }

  /* ============================================================
     B13 — USEFUL GOD METHOD EVIDENCE
     These adapters expose structured method outputs already produced by Core B.
     They do not diagnose, select a medicine, close a Climate rule, or confirm a
     Following pattern. Branch binding is allowed only where Core exposes an
     explicit state that corresponds to a declared matrix branch.
     ============================================================ */
  function b13MethodCandidate(master, id) {
    const b13 = master && master.B13_2;
    const container = b13 && b13.methodCandidates;
    const list = Array.isArray(container) ? container : (container && Array.isArray(container.result) ? container.result : []);
    return list.find(function (m) { return m && m.id === id; }) || null;
  }

  function b13DiseaseMedicineEvidence(master) {
    const m = b13MethodCandidate(master, "BC-YONG-BINGYAO-001");
    if (!m) return [];
    const out = []; const add = x => { if (out.indexOf(x) < 0) out.push(x); };
    const ev = m.evidence || {};
    if (Array.isArray(ev.signals) && ev.signals.length) add("DISEASE_SCREEN_IDENTIFIED");
    if (ev.diagnosisStatus === "SOURCE_PROFILE_NOT_CLOSED") add("DIAGNOSIS_NOT_CLOSED");
    if (ev.medicineSelectionStatus === "NOT_DETERMINED") add("MEDICINE_NOT_DETERMINED");
    if (m.status === "OPEN" && Array.isArray(ev.signals) && ev.signals.length === 0) add("NO_CONCRETE_DISEASE");
    return out;
  }

  function b13DiseaseMedicineBranch(master) {
    const m = b13MethodCandidate(master, "BC-YONG-BINGYAO-001");
    if (!m) return [];
    const ev = m.evidence || {};
    // Core explicitly exposes an OPEN state with no disease signal and no
    // medicine selection. This matches the matrix OPEN branch; it is not a
    // disease diagnosis and must never be promoted to EFFECTIVE.
    if (m.status === "OPEN" && Array.isArray(ev.signals) && ev.signals.length === 0 &&
        ev.diagnosisStatus === "SOURCE_PROFILE_NOT_CLOSED" &&
        ev.medicineSelectionStatus === "NOT_DETERMINED") {
      return ["NO_CONCRETE_DISEASE"];
    }
    return [];
  }

  function b13ClimateEvidence(master) {
    const m = b13MethodCandidate(master, "BC-YONG-TIAOHOU-001");
    const qtbj = b13MethodCandidate(master, "Qiong Tong Bao Jian (穷通宝鉴) May Bing Fire rule");
    if (!m && !qtbj) return [];
    const out = []; const add = x => { if (out.indexOf(x) < 0) out.push(x); };
    const a7 = master && master.A7;
    if (a7 && a7.monthBranch) { add("SEASON"); add("SEASON_RESOLVED"); }
    if (master && master.B1 && master.B1.dayMasterElement) { add("DAY_MASTER"); add("DAY_MASTER_RESOLVED"); }
    if (m && m.status && m.status !== "NOT_TRIGGERED") add("SEASONAL_REQUIREMENT");
    if (qtbj) {
      add("SOURCE_ENTRY_MATCHED"); add("SOURCE_RULE_MATCHED");
      if (qtbj.candidate && qtbj.candidate.stem) { add("PRIMARY_FACTOR"); add("PRIMARY_REGULATOR_IDENTIFIED"); }
      if (qtbj.result) add("SOURCE_RULE_EVIDENCE");
      const ev = qtbj.evidence || {};
      if (ev.regulatorPresent === true) add("REGULATOR_PRESENCE_VERIFIED");
      if (ev.regulatorEffective === true) add("REGULATOR_EFFECTIVENESS_VERIFIED");
      if (ev.interferenceClosed === true) add("INTERFERENCE_SCREEN_CLOSED");
      if (ev.interference === true) add("SOURCE_INTERFERENCE");
      if (ev.excessPrimary === true) add("EXCESS_PRIMARY_UNRESOLVED");
    }
    return out;
  }

  function b13ClimateBranch(master) {
    const signals = b13ClimateEvidence(master);
    if (!signals.length) return [];
    if (CLOSURE_CONTRACT) {
      const gate = CLOSURE_CONTRACT.evaluate("CS-B13-CLIMATE", signals);
      if (gate.status === "CLOSURE_SIGNAL_COMPLETE") return ["CLIMATE_CLOSURE_COMPLETE"];
      if (gate.status === "CLOSURE_BLOCKED") return ["CLIMATE_CLOSURE_BLOCKED"];
    }
    if (signals.indexOf("SOURCE_ENTRY_MATCHED") >= 0) return ["SOURCE_ENTRY_MATCHED"];
    return [];
  }

  function b13FollowingEvidence(master) {
    const m = b13MethodCandidate(master, "BC-YONG-ZHUANWANG-001");
    if (!m) return [];
    const ev = m.evidence || {};
    const out = []; const add = x => { if (out.indexOf(x) < 0) out.push(x); };
    if (ev.mode) { add("EXTREME_PATTERN_SCREEN"); add("FOLLOWING_SUBTYPE_IDENTIFIED"); }
    if (ev.dmPresent) add("DOMINANT_SIDE");
    if (ev.companionPresent === true) add("COMPANION_PRESENT");
    if (ev.companionDominant) { add("COMPANION_DOMINANCE"); add("DOMINANT_FORCE_VERIFIED"); }
    if (ev.mode === "FOLLOW-THE-TREND / 从势" && ev.followingSideCount === 3) add("DOMINANT_FORCE_VERIFIED");
    if (typeof ev.dmRootPresent === "boolean" || typeof ev.dmMeaningfulSupport === "boolean") add("DM_ROOT_SUPPORT_AUDITED");
    if (ev.resourcePresent === true) add("ROOT_SUPPORT");
    if (ev.dmRootPresent === true) add("DM_ROOT_PRESENT");
    if (ev.dmMeaningfulSupport === true) add("DM_MEANINGFUL_SUPPORT");
    if (ev.wealthPresent || ev.officerPresent || ev.outputPresent) { add("CONTRARY_FORCE_PRESENT"); add("CONTRARY_FORCE_AUDITED"); }
    if ((ev.mode === "FOLLOW THE DOMINANT QI / 从旺" || ev.mode === "FOLLOW-STRENGTH / 从强") && ev.effectiveWealthOfficer === false) add("CONTRARY_FORCE_AUDITED");
    if (ev.mode && ev.breakConditionsAudited === true &&
        ((ev.mode === "FOLLOW THE DOMINANT QI / 从旺" || ev.mode === "FOLLOW-STRENGTH / 从强")
          ? (ev.dmMeaningfulSupport === true && ev.effectiveWealthOfficer === false)
          : (ev.dmRootPresent === false && ev.dmMeaningfulSupport === false))) {
      add("TRUE_FOLLOWING_CONDITIONS_SATISFIED");
    }
    if (ev.breakConditionsAudited === true) add("BREAK_CONDITIONS_AUDITED");
    if (ev.effectiveResourceCompanion === true) add("EFFECTIVE_RESOURCE_COMPANION");
    if (ev.effectiveWealthOfficer === true) add("EFFECTIVE_WEALTH_OFFICER");
    if (ev.mode === "FOLLOW THE DOMINANT QI / 从旺") add("FOLLOWING_DOMINANT_QI");
    if (ev.mode === "FOLLOW-STRENGTH / 从强") add("FOLLOWING_STRENGTH");
    if (ev.mode === "FOLLOW-THE-TREND / 从势") { add("FOLLOWING_TREND"); add("FOLLOWING_DOMINANT_FORCE_GROUP"); }
    if (ev.followingSideCount >= 2) add("FOLLOWING_MULTI_SIDE_STRUCTURE");
    if (ev.followingSideCount === 3) add("FOLLOWING_ALL_THREE_SIDES");
    if (ev.materialBalance === true) add("MATERIAL_BALANCE");
    if (ev.dmRootPresent === true) add("DM_ROOT_PRESENT");
    if (ev.dmMeaningfulSupport === true) add("DM_MEANINGFUL_SUPPORT");
    if (ev.followingBroken === true) add("FOLLOWING_STRUCTURE_BROKEN");
    if (m.status === "OPEN") add("FOLLOWING_SCREEN_OPEN");
    return out;
  }

  function b13MultiMethodBranch(master){
    const b13=master&&master.B13_2, r=b13&&b13.reconciliation; if(!r)return[];
    if(r.status==="AGREEMENT")return ["ALL_ACTIVE_METHODS_AGREE"];
    if(r.status==="PARTIAL_AGREEMENT")return ["SAME_ELEMENT_DIFFERENT_IDENTITY"];
    if(r.status==="CONFLICT")return ["DIFFERENT_ELEMENT_OR_FUNCTION"];
    if(r.status==="MULTI_METHOD")return ["MULTIPLE_VALID_UNRESOLVED_METHODS"];
    return ["METHOD_SPACE_OPEN"];
  }

  function normalize(master, familyId) {
    if (familyId === "CS-B1-STRENGTH") return b1(master);
    if (familyId === "CS-B2-MONTH-COMMAND") return b2(master);
    if (familyId === "CS-B3-PATTERN-FAMILY") return b3Branches(master);
    if (/^CS-B3-GEJU-(OFFICER|WEALTH|RESOURCE|EATING-GOD|HURTING-OFFICER|SEVEN-KILLINGS|JIAN-LU)$/.test(familyId)) return b3GeJuBranch(master, familyId);
    if (familyId === "CS-B3-MIXED-GEJU") {
      const mixed = master && master.B3 && master.B3._classicalFamilies && master.B3._classicalFamilies["CS-B3-MIXED-PATTERN"];
      if (mixed && mixed.closure === "REQUIRES_CLASSICAL_RECONCILIATION") return ["NO_SOURCE_RANKING"];
    }
    if (familyId === "CS-B3-MISCELLANEOUS-QI") return miscellaneousQiBranchEvidence(master);
    if (familyId === "CS-B3-USEFUL-GOD-CHANGE") return usefulGodChangeBranch(master);
    if (familyId === "CS-B3-PURITY-MIXTURE") return purityMixtureBranch(master);
    if (familyId === "CS-B3-FORMATION-HIGH-LOW") return formationQualityBranch(master);
    if (familyId === "CS-B3-ASSISTANT-GOD") return assistantGodBranch(master);
    if (familyId === "CS-B3-AUSPICIOUS-BREAK") return auspiciousBreakBranch(master);
    if (familyId === "CS-B3-MALEFIC-FORM") return maleficFormBranch(master);
    if (familyId === "CS-B3-OUTER-PATTERNS") return outerPatternsBranch(master);
    if (familyId === "CS-B13-MULTI-METHOD") return b13MultiMethodBranch(master);
    if (familyId === "CS-B13-DISEASE-MEDICINE") return b13DiseaseMedicineBranch(master);
    if (familyId === "CS-B13-CLIMATE") return b13ClimateBranch(master);
    if (familyId === "CS-B13-FOLLOWING") {
      const signals = b13FollowingEvidence(master);
      if (!signals.length) return [];
      if (CLOSURE_CONTRACT) {
        const gate = CLOSURE_CONTRACT.evaluate("CS-B13-FOLLOWING", signals);
        if (gate.status === "CLOSURE_SIGNAL_COMPLETE") return ["FOLLOWING_CLOSURE_COMPLETE"];
        if (gate.status === "CLOSURE_BLOCKED") return ["FOLLOWING_CLOSURE_BLOCKED"];
      }
      return [];
    }
    if (familyId === "CS-B6B7-SEQUENCE") return b6b7Branch(master);
    if (familyId === "CS-B8-HUA") return b8Branch(master);
    if (familyId === "CS-B11-TONG-GUAN") return b11Branch(master);
    if (familyId === "CS-C-TEMPORAL") return cTemporalBranch(master);
    if (familyId === "CS-C-DAYUN-FORMATION-CHANGE") return cDayunFormationBranch(master);
    if (familyId === "CS-B3-GEJU-YANG-REN") return b3Branches(master).map(function(x){
      return x === "FORMATION_NO_BREAK" ? "FORMATION_WITH_CONTROL_AND_SUPPORT" :
             x === "BREAK_WITH_RESCUE" ? "RESOURCE_PROTECTION_OR_CONTROL_RESCUE" : x;
    });
    return [];
  }

  function evidence(master, familyId) {
    if (familyId === "CS-B3-MISCELLANEOUS-QI") return miscellaneousQiEvidence(master);
    if (familyId === "CS-B3-USEFUL-GOD-CHANGE") return usefulGodChangeEvidence(master);
    if (familyId === "CS-B3-PURITY-MIXTURE") return purityMixtureEvidence(master);
    if (familyId === "CS-B3-FORMATION-HIGH-LOW") return formationQualityEvidence(master);
    if (familyId === "CS-B3-ASSISTANT-GOD") return assistantGodEvidence(master);
    if (familyId === "CS-B3-AUSPICIOUS-BREAK") return auspiciousBreakEvidence(master);
    if (familyId === "CS-B3-MALEFIC-FORM") return maleficFormEvidence(master);
    if (familyId === "CS-B3-OUTER-PATTERNS") return outerPatternsEvidence(master);
    if (familyId === "CS-B6B7-SEQUENCE") return b6b7Evidence(master);
    if (familyId === "CS-B8-HUA") return b8Evidence(master);
    if (familyId === "CS-B11-TONG-GUAN") return b11Evidence(master);
    if (familyId === "CS-C-TEMPORAL") return cTemporalEvidence(master);
    if (familyId === "CS-C-DAYUN-FORMATION-CHANGE") return cDayunFormationEvidence(master);
    if (familyId === "CS-B13-DISEASE-MEDICINE") return b13DiseaseMedicineEvidence(master);
    if (familyId === "CS-B13-CLIMATE") return b13ClimateEvidence(master);
    if (familyId === "CS-B13-FOLLOWING") return b13FollowingEvidence(master);
    if (familyId === "CS-B13-MULTI-METHOD") {
      const b13=master&&master.B13_2, r=b13&&b13.reconciliation; if(!r)return [];
      const out=[]; const add=x=>{if(out.indexOf(x)<0)out.push(x)};
      const methodContainer=b13.methodCandidates; const methodList=Array.isArray(methodContainer) ? methodContainer : (methodContainer && Array.isArray(methodContainer.result) ? methodContainer.result : []); const methods=methodList.map(function(m){return m.method;});
      if(methods.some(function(m){return /Support-Suppress|Disease-Medicine|Climate Regulation|Following|Communication/i.test(m);})) {
        methods.forEach(function(m){
          if(/Support-Suppress/i.test(m))add("SUPPORT_SUPPRESS");
          if(/Disease-Medicine/i.test(m))add("DISEASE_MEDICINE");
          if(/Climate Regulation/i.test(m))add("CLIMATE");
          if(/Following/i.test(m))add("FOLLOWING");
          if(/Communication/i.test(m))add("BRIDGING");
        });
      }
      if(r.conflict)add("METHOD_DISAGREEMENT");
      if(r.partialAgreement)add("CANDIDATE_FUNCTION_CONFLICT");
      if(r.status==="AGREEMENT")add("AGREEMENT");
      else if(r.status==="PARTIAL_AGREEMENT")add("PARTIAL_AGREEMENT");
      else if(r.status==="CONFLICT")add("CONFLICT");
      else if(r.status==="MULTI_METHOD")add("MULTI_METHOD");
      else add("OPEN");
      return out;
    }
    return b3Evidence(master, familyId);
  }

  const RUNTIME_FAMILIES = [
    "CS-B1-STRENGTH", "CS-B2-MONTH-COMMAND", "CS-B3-PATTERN-FAMILY",
    "CS-B3-GEJU-OFFICER", "CS-B3-GEJU-WEALTH", "CS-B3-GEJU-RESOURCE",
    "CS-B3-GEJU-EATING-GOD", "CS-B3-GEJU-HURTING-OFFICER",
    "CS-B3-GEJU-SEVEN-KILLINGS", "CS-B3-GEJU-YANG-REN", "CS-B3-GEJU-JIAN-LU",
    "CS-B3-MIXED-GEJU", "CS-B3-MISCELLANEOUS-QI", "CS-B8-HUA",
    "CS-B11-TONG-GUAN", "CS-B13-MULTI-METHOD", "CS-B13-DISEASE-MEDICINE",
    "CS-B13-CLIMATE", "CS-B13-FOLLOWING", "CS-C-TEMPORAL",
    "CS-B3-USEFUL-GOD-CHANGE", "CS-B3-PURITY-MIXTURE",
    "CS-B3-FORMATION-HIGH-LOW", "CS-B3-ASSISTANT-GOD",
    "CS-B3-AUSPICIOUS-BREAK", "CS-B3-MALEFIC-FORM", "CS-B6B7-SEQUENCE",
    "CS-B3-OUTER-PATTERNS", "CS-C-DAYUN-FORMATION-CHANGE"
  ];

  global.PENGGILAS_CLASSICAL_RUNTIME_EVIDENCE_NORMALIZER = {
    version: "V83", normalize: normalize, evidence: evidence,
    runtimeFamilies: RUNTIME_FAMILIES,
    rule: "Only field-provenance evidence is normalized; descriptive text is never treated as an adjudicated outcome. Atomic evidence and branch-ready closure evidence remain distinct."
  };
})(window);
