/* ============================================================
   PENGGILAS — CLASSICAL CLOSURE SIGNAL CONTRACT V82
   Read-only contract: this file defines what Core MUST explicitly expose
   before a family may claim a final Classical state. It does not calculate
   BaZi and does not infer closure from descriptive text.
   ============================================================ */
(function (global) {
  "use strict";
  const CONTRACTS = {
    "CS-B3-USEFUL-GOD-CHANGE": ["BASE_USEFUL_GOD", "FUNCTIONAL_CHANGE", "COUNTER_EVIDENCE", "CLOSURE"],
    "CS-B3-PURITY-MIXTURE": ["USEFUL_STRUCTURE", "CONTAMINATION_OR_COMPETITION", "CLEARING_OR_PERSISTENCE", "CLOSURE"],
    "CS-B3-FORMATION-HIGH-LOW": ["FORMATION_STATE", "AFFINITY", "FORCE", "POSITION_OR_SEQUENCE", "CLOSURE"],
    "CS-B3-ASSISTANT-GOD": ["USEFUL_GOD", "FUNCTIONAL_DEPENDENCY", "PATTERN_RELIANCE", "CLOSURE"],
    "CS-B3-AUSPICIOUS-BREAK": ["AUSPICIOUS_GOD", "FORMATION_DEPENDENCE", "MATERIAL_BREAKING_ACTION", "RESCUE_OR_PERSISTENCE", "CLOSURE"],
    "CS-B3-AUSPICIOUS-BREAK-NOT-BREAKING": ["AUSPICIOUS_GOD", "FORMATION_DEPENDENCE", "RESCUE_OR_PERSISTENCE", "CLOSURE"],
    "CS-B3-MALEFIC-FORM": ["MALEFIC_GOD", "PATTERN_ROLE", "CONTROL_OR_CONVERSION", "NET_EFFECT", "CLOSURE"],
    "CS-B3-OUTER-PATTERNS": ["SPECIAL_CONFIGURATION", "ORDINARY_PATTERN_EXCLUSION", "SOURCE_REQUIREMENTS", "CLOSURE"],
    "CS-B13-CLIMATE": ["SEASON_RESOLVED", "DAY_MASTER_RESOLVED", "SOURCE_RULE_MATCHED", "PRIMARY_REGULATOR_IDENTIFIED", "REGULATOR_PRESENCE_VERIFIED", "REGULATOR_EFFECTIVENESS_VERIFIED", "INTERFERENCE_SCREEN_CLOSED"],
    "CS-B13-FOLLOWING": ["FOLLOWING_SUBTYPE_IDENTIFIED", "DOMINANT_FORCE_VERIFIED", "DM_ROOT_SUPPORT_AUDITED", "CONTRARY_FORCE_AUDITED", "BREAK_CONDITIONS_AUDITED", "TRUE_FOLLOWING_CONDITIONS_SATISFIED"]
  };

  const DISQUALIFIERS = {
    "CS-B13-CLIMATE": ["SOURCE_INTERFERENCE", "EXCESS_PRIMARY_UNRESOLVED", "REGULATOR_BLOCKED", "CONTRADICTORY_SEASONAL_RULE", "UNRESOLVED_EXCEPTION"],
    "CS-B13-FOLLOWING": ["MATERIAL_BALANCE", "FOLLOWING_STRUCTURE_BROKEN", "UNRESOLVED_SUBTYPE"]
  };

  function evaluate(familyId, signals) {
    const required = CONTRACTS[familyId] || [];
    const present = new Set(Array.isArray(signals) ? signals : []);
    const missing = required.filter(x => !present.has(x));
    const followingSubtype = present.has("FOLLOWING_DOMINANT_QI") ? "DOMINANT"
      : (present.has("FOLLOWING_STRENGTH") ? "STRENGTH"
      : (present.has("FOLLOWING_TREND") ? "TREND" : null));
    let disqualifiers;
    if (familyId === "CS-B13-FOLLOWING") {
      // Resource/Companion and root/support are constitutive evidence for
      // Follow-Dominant / Follow-Strength. They are disqualifying only for
      // Follow-the-Trend. Wealth/Officer is the contrary-force screen for the
      // two dominant-side subtypes. Unsupported subtype identities never close.
      if (followingSubtype === "DOMINANT" || followingSubtype === "STRENGTH") {
        disqualifiers = ["MATERIAL_BALANCE", "FOLLOWING_STRUCTURE_BROKEN", "UNRESOLVED_SUBTYPE", "EFFECTIVE_WEALTH_OFFICER"];
      } else if (followingSubtype === "TREND") {
        disqualifiers = ["MATERIAL_BALANCE", "FOLLOWING_STRUCTURE_BROKEN", "UNRESOLVED_SUBTYPE", "EFFECTIVE_RESOURCE_COMPANION", "DM_ROOT_PRESENT", "DM_MEANINGFUL_SUPPORT"];
      } else {
        disqualifiers = DISQUALIFIERS[familyId] || [];
      }
    } else {
      disqualifiers = DISQUALIFIERS[familyId] || [];
    }
    const triggered = disqualifiers.filter(x => present.has(x));
    const complete = missing.length === 0 && triggered.length === 0;
    return {
      familyId, required, disqualifiers, present: Array.from(present), missing, triggered,
      status: complete ? "CLOSURE_SIGNAL_COMPLETE" : (triggered.length ? "CLOSURE_BLOCKED" : "EVIDENCE_OBSERVED_NO_CLOSURE"),
      rule: "Explicit source-locked closure gates only; no inferred Classical formula."
    };
  }

  global.PENGGILAS_CLASSICAL_CLOSURE_SIGNAL_CONTRACT = {
    version: "V83",
    contracts: CONTRACTS,
    evaluate: evaluate,
    isComplete: function (familyId, signals) {
      const result = evaluate(familyId, signals);
      return result.missing.length === 0 && result.triggered.length === 0;
    },
    disqualifiers: DISQUALIFIERS
  };
})(window);
