# DATA — Rules, Evidence, Sources & Classical State Support

## 1. Fungsi
Folder `data/` menyimpan **data pendukung dan kontrak rule/evidence** yang digunakan Core untuk melakukan determination dan menjaga provenance.

`data/` bukan orchestrator dan bukan presentation layer.

## 2. Struktur

```text
data/
├── determination-rules.js
├── global_classical_state_matrix.js
├── classical_rule_coverage.js
├── rules/
│   ├── classical_rule_evaluator.js
│   └── classical_rules_B_C.js
├── evidence/
│   ├── closure_signal_contract.js
│   ├── runtime_evidence_normalizer.js
│   └── execution_signature.js
└── sources/
    └── classical_sources_B_C.js
```

## 3. Dokumentasi dan peta support

README ini adalah entry point untuk seluruh `data/`. Tidak ada `.md` kontrak khusus di bawah `data/`; detail fungsi dijelaskan di sini dan mengikuti struktur file production aktual.

Peta dependency:

```text
data/
├── root support       → rule coverage / determination / state matrix
├── rules/              → rule definitions + evaluator
├── evidence/           → runtime evidence contracts / normalization / signatures
└── sources/            → Classical source/basis metadata
        ↓
Core B / Determination / Core C
        ↓
window.masterResult
```

Dokumen kontrak yang mengatur batas lebih tinggi berada di `../PRODUCTION_ARCHITECTURE.md` dan `../core/MASTER_RESULT_ARCHITECTURE.md`.

## 4. Fungsi tiap bagian

| Bagian | Fungsi |
|---|---|
| `determination-rules.js` | Rule/profile yang dikonsumsi determination/engine sesuai implementasi production. |
| `global_classical_state_matrix.js` | State matrix Classical yang menjadi referensi status/closure. |
| `classical_rule_coverage.js` | Coverage/metadata rule support. |
| `rules/` | Declarative B/C rules plus the Rule Registry consumed before Core B/C execution; evaluator remains post-execution trace. |
| `evidence/` | Kontrak, normalizer, dan signature untuk execution evidence/closure evidence. |
| `sources/` | Source/basis metadata yang terkait rule B/C. |

## 5. Siapa yang memanggil

`index.html` memuat file `data/*` sebelum Core yang menggunakannya.

Secara arsitektural:

```text
Data support
    ↓
Core B / Determination / Core C
    ↓
MasterResult
```

`data/` tidak memanggil `app.js` untuk menjalankan pipeline.

## 6. Output

Data layer menyediakan object/function/metadata yang dibaca oleh engine Core, misalnya:

- rule definitions;
- state matrix;
- evidence contracts;
- normalized runtime evidence;
- execution signatures;
- source metadata.

Hasil akhirnya tetap dipublikasikan melalui Core ke `MasterResult`, bukan sebagai result authority kedua di `data/`.

## 7. Batas kewenangan

### Boleh
- menyimpan rule definitions dan support data;
- mendefinisikan evidence/state contracts;
- menyediakan evaluator/helper yang memang menjadi dependency production;
- menyimpan source/provenance metadata.

### Tidak boleh
- menjadi orchestrator pipeline;
- merender UI;
- membuat competing `MasterResult`;
- melakukan silent override terhadap hasil Core;
- mengubah rule hanya karena output template/UI tidak cocok.

## 8. Prinsip penting

Data layer adalah **support layer**, bukan tempat untuk menyisipkan patch presentation.

Jika output salah:

```text
Engine/rule issue     → perbaiki engine/core/data pada boundary yang benar
Mapper issue          → perbaiki json-mapper/template contract
Human UI issue        → perbaiki presentation layer
Chart UI issue        → perbaiki ui/chart
```
