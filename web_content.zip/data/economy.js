// Every completed match earns coins; performance determines the payout.
export function calculateMatchCoins(home, away, stats, mode = 'ranked') {
    const diff = home - away;
    const base = diff > 0 ? 1100 : diff === 0 ? 650 : 300;
    const gross = base + Math.max(-3, Math.min(5, diff)) * 320 + stats.shots * 65 - stats.shotsAgainst * 22 + Math.round((stats.possession - 50) * 5) + Math.min(320, stats.passes * 8);
    return Math.round(Math.max(200, Math.min(5500, mode === 'friendly' ? gross * .8 : gross)));
}
