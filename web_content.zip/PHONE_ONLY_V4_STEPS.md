# GameHub V4 — phone-only setup

## Part A — Build the APK on your phone
1. Create a GitHub account in your phone browser.
2. Create a new repository called `GameHub`.
3. Upload ALL files/folders from this ZIP into the repository root.
4. Open the **Actions** tab.
5. Choose **Build GameHub APK**.
6. Tap **Run workflow**.
7. Wait for the build to finish.
8. Open the completed workflow run and find **Artifacts**.
9. Download `GameHub-debug-apk`.
10. Extract it and install `app-debug.apk` on your phone.

## Part B — Make the website public
1. In GitHub open Settings → Pages.
2. Choose Deploy from branch → `main` → `/ (root)`.
3. Save. GitHub will provide your public Pages address.
4. The site can be opened on any phone/browser.

## Part C — Real online backend
Use Supabase:
1. Create a Supabase project.
2. Create a `games` table with fields: id, name, genre, version, description, cover_url, download_url, created_at, published.
3. Enable Auth for your admin account.
4. Create Storage buckets for game covers/files.
5. Add Row Level Security so public users can read published games, while only your admin can insert/update/delete.
6. Put ONLY the Supabase project URL and public anon key in `app/src/main/assets/config.js`.
7. Never put a service_role/private key in the APK or website.

V4 currently includes a safe demo UI and backend configuration placeholders. A fully live upload implementation requires the actual Supabase project URL/key and database/storage rules; those are account-specific and should be configured by you.

## Publishing
Test the APK before Play Store submission. Google Play also requires developer-account setup, app signing, store listing information, and compliance with its current policies. Only distribute games you own or are authorized to redistribute.
