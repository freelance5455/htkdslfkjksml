# Security Notes

- Do not commit `firebase/config.js` if it contains environment-specific configuration you do not want distributed.
- Never expose Firebase Admin SDK credentials, service-account JSON, private keys, or server secrets in this frontend package.
- Firebase Web API keys are not a substitute for Firestore security rules.
- Test authentication, authorization, custom claims, and tenant isolation before production use.
- Keep backups of business data and test restore procedures.
- Review all third-party dependencies and external CDN availability before a commercial deployment.
