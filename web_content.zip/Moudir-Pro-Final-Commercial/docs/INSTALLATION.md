# Moudir Pro — Installation Guide

## 1. Browser demo
Open `index.html` in a modern browser. Demo data is stored locally in the browser.

## 2. Local web server
For PWA/service-worker behavior, serve the folder over HTTP/HTTPS instead of opening the HTML file directly.

Example:
```bash
npm install
npm start
```

## 3. Firebase (optional)
1. Create a Firebase project.
2. Enable Email/Password Authentication.
3. Create Firestore Database.
4. Copy `firebase/config.example.js` to `firebase/config.js`.
5. Enter the Web App configuration.
6. Review and test `firebase/firestore.rules`.
7. Configure trusted `storeId` claims using a secure server-side process.

Never put Firebase Admin SDK credentials or service-account JSON in the frontend.

## 4. Android
See `android/BUILD-ANDROID.md`. A signed APK/AAB requires your Android build environment and signing key.
