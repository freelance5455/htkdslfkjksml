# Moudir Pro — Production checklist
Implemented in this package:
- Responsive Arabic RTL interface
- Dashboard, products, sales, purchases, customers, suppliers, expenses, reports, users, settings
- Local persistent demo data
- CSV export for sales
- Printable invoice window
- PWA manifest/service worker
- Firebase SDK bridge and configuration template
- Firestore security-rule template using a storeId claim
- Capacitor configuration for Android packaging
- README and commercial documentation

Requires your external setup:
- Create a Firebase project
- Enable Email/Password Authentication
- Create Firestore
- Create custom claims / trusted storeId assignment
- Put your Firebase web config in firebase/config.js
- Review and test security rules before production
- Build/sign APK or AAB with your own Android keystore
- Test on real devices and publish only after QA
