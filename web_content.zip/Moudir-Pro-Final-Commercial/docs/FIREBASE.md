# Firebase
- أنشئ مشروع Firebase.
- فعّل Authentication (Email/Password).
- أنشئ Firestore.
- انسخ config.example.js إلى config.js وضع إعدادات مشروعك.
- طبّق firestore.rules بعد مراجعتها.
- اربط التطبيق بطبقة بيانات Firestore.
ملاحظة: لا تشارك مفاتيح Admin SDK أو service-account JSON مع العملاء أو داخل الواجهة.
