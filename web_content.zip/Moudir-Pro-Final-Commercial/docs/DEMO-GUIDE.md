# Demo Guide

The package includes sample data so a buyer can immediately explore the interface.

Suggested demo flow:
1. Open Dashboard.
2. Add a product and set stock.
3. Create a sale and print its invoice.
4. Add a purchase and observe stock changes.
5. Add a customer, supplier, and expense.
6. Open Reports and export sales as CSV.
7. Open Settings to review store name and currency.

Demo data is local to the browser and is not a live production database.
