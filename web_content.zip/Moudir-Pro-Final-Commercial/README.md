# Moudir Pro 3.1 — Commercial Store Management Source Code

Moudir Pro is a mobile-first Arabic RTL store-management application designed as a customizable commercial source package for small businesses and developers.

## Highlights
- Dashboard with sales, profit, expenses, customers, suppliers, and low-stock indicators
- Product and inventory management
- Quick sales and stock deduction
- Purchases and stock replenishment
- Customers and suppliers
- Expense tracking
- Printable invoices
- CSV export
- Responsive Arabic RTL interface
- PWA manifest and service worker
- Firebase integration bridge and Firestore rules template
- Capacitor-ready Android configuration
- Commercial documentation and licensing template
- Local demo mode with sample data

## Quick demo
Open `index.html` in a modern browser. The demo uses browser LocalStorage and does not require Firebase credentials.

For PWA/service-worker behavior, use a local HTTP server (`npm install` then `npm start`).

## Firebase
Firebase is an optional integration layer in this package. It is not a pre-created live backend.

1. Copy `firebase/config.example.js` to `firebase/config.js`.
2. Add your Firebase Web App configuration.
3. Enable Email/Password Authentication.
4. Create Firestore.
5. Review and test `firebase/firestore.rules`.
6. Configure trusted `storeId` claims through a secure server-side process.

Never include Firebase Admin SDK credentials or service-account JSON in the frontend package.

## Android
See `android/BUILD-ANDROID.md`. A signed APK/AAB requires an Android build environment and your own signing identity.

## Documentation
- `docs/INSTALLATION.md` — setup guide
- `docs/DEMO-GUIDE.md` — buyer demo walkthrough
- `docs/FIREBASE.md` — Firebase setup
- `docs/SECURITY.md` — security notes
- `docs/PRODUCTION-CHECKLIST.md` — deployment checklist
- `docs/SALES_READINESS.md` — commercial delivery notes
- `SELLER-PACK.txt` — listing information
- `LICENSE.txt` — commercial license template
- `CHANGELOG.md` — release history

## Important commercial disclosure
This is a source-code commercial package. It does not include a live Firebase project, production cloud environment, signed APK/AAB, Google Play publication, hosting, or paid third-party services unless explicitly stated in a sales agreement.
