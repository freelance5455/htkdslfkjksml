# Moudir Pro — Android Build Guide

## Requirements
- Node.js LTS
- Android Studio
- Android SDK and a configured emulator/device
- Your own Android signing key for release builds

## First setup
```bash
npm install
npm run android:init
npm run android:sync
npm run android
```

If the Android project already exists, skip `android:init` and use:
```bash
npm install
npm run android:sync
npm run android
```

## Release build
Open the generated Android project in Android Studio and create a signed APK/AAB using your own application ID and signing key.

A signed APK/AAB is intentionally not included in this source package.
