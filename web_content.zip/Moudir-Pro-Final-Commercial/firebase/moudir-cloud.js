/*
 Moudir Pro Firebase bridge
 - Demo mode works with LocalStorage.
 - Production mode activates when firebase/config.js exists and Firebase SDKs are loaded.
 - Data model: stores/{storeId}/{collection}/{docId}
*/
window.MoudirCloud = (() => {
  let enabled = false, db = null, auth = null;
  async function init() {
    try {
      if (!window.firebase || !window.MOUDIR_FIREBASE_CONFIG ||
          window.MOUDIR_FIREBASE_CONFIG.apiKey === "YOUR_API_KEY") return false;
      if (!firebase.apps.length) firebase.initializeApp(window.MOUDIR_FIREBASE_CONFIG);
      auth = firebase.auth();
      db = firebase.firestore();
      enabled = true;
      return true;
    } catch (e) { console.warn("Firebase init:", e); return false; }
  }
  function isEnabled(){ return enabled; }
  async function login(email,password){ if(!enabled) throw Error("Firebase غير مفعّل"); return auth.signInWithEmailAndPassword(email,password); }
  async function register(email,password){ if(!enabled) throw Error("Firebase غير مفعّل"); return auth.createUserWithEmailAndPassword(email,password); }
  async function logout(){ if(auth) return auth.signOut(); }
  async function push(storeId, collection, id, data){
    if(!enabled) return false;
    await db.collection("stores").doc(storeId).collection(collection).doc(String(id)).set(data,{merge:true});
    return true;
  }
  async function remove(storeId, collection, id){
    if(!enabled) return false;
    await db.collection("stores").doc(storeId).collection(collection).doc(String(id)).delete();
    return true;
  }
  async function pull(storeId, collection){
    if(!enabled) return [];
    const snap = await db.collection("stores").doc(storeId).collection(collection).get();
    return snap.docs.map(d=>({id:d.id,...d.data()}));
  }
  return {init,isEnabled,login,register,logout,push,remove,pull};
})();
