# Changelog

## 3.1.0 Commercial Edition
- Added branded PWA icons and favicon.
- Added commercial license template.
- Added installation, demo, and security documentation.
- Added clearer distinction between demo/local mode and optional Firebase integration.
- Added seller-facing packaging guidance.
- Improved package metadata for Android/PWA distribution.
- Added local JSON backup/restore and demo-data reset controls.
- Added basic PWA branding metadata.
