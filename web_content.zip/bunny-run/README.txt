Bunny Run

Open index.html in any browser (works offline; progress saves in the browser).
For Android: host the folder or wrap it with an app packager.
