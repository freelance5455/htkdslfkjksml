# AI Money Agent — Android Bridge Diagnostic Fix 0.2.3-native-bridge

## Why the installed screen may still show OFFLINE
The screenshot's `Failed to fetch` message is the browser-fetch failure, not a native Android HTTP error. In the Android app, the diagnostic now explicitly reports `ANDROID BRIDGE MISSING` when the APK does not include the updated `NativeApi` bridge. This commonly means an older APK was installed or the web folder was packaged instead of the Android project.

## Correct install/build path
1. Extract this ZIP.
2. Open the **android** folder in Android Studio (not `web`).
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Uninstall the older AI Money Agent app from the phone, then install the new APK.
6. Open Settings in the app and read the diagnostic status. It should say `ANDROID BRIDGE READY` before market requests can work through native Android.

## What this patch changes
- Adds an explicit Android bridge diagnostic at startup.
- Prevents packaged `file://` app builds from silently falling back to browser `fetch` when NativeApi is missing.
- Surfaces native request, timeout, HTTP and JSON errors on screen.
- Adds WebChromeClient for better WebView diagnostics.
- Keeps all Android/Web JS copies synchronized.

## Verification limits
JavaScript syntax and ZIP integrity are checked. This environment has no Android SDK/Gradle and cannot certify a live Bitstamp connection or build an APK. Do not treat the project as a verified APK until it is built from the `android/` folder and the on-device diagnostic says `ANDROID BRIDGE READY` followed by `API: OK`.

Data source: official public Bitstamp API only. Demo signals only; no live trading.


Build identity: versionCode 4, versionName 0.2.3-native-bridge. If the installed app still reports Browser fetch blocked, the installed APK is not this build. Remove the old app, rebuild this exact android/ project, and install the resulting APK.

## Review correction
The previous archive had a version identity mismatch: Gradle named the app 0.2.2 while NativeApi.version() returned 0.2.1. This archive aligns the native bridge and Gradle identity at 0.2.3 (versionCode 4).
