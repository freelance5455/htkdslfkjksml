# Underground Racer 3D – Android project

Natív Android (Kotlin) alkalmazás, amely a helyi `app/src/main/assets/index.html` fájlt WebView-ban futtatja. A játék 3D jelenetét Three.js/WebGL rendereli.

## Megjegyzés az internetkapcsolatról
Az `index.html` a Three.js 0.160.0 könyvtárat CDN-ről tölti be (`cdn.jsdelivr.net`). Emiatt a játék első indításakor internetkapcsolat szükséges. A játék és az összes saját 3D pályaelem az index.html-ben van; a Three.js könyvtár nincs offline beágyazva.

## Android Studio
1. Nyisd meg ezt a mappát Android Studio-ban.
2. Várd meg a Gradle sync végét.
3. Válassz telefont vagy emulátort.
4. Run, vagy Build > Build APK(s).

## Böngészős kipróbálás
Az `app/src/main/assets/index.html` fájlt helyi webszerverről vagy internetkapcsolattal rendelkező statikus tárhelyről nyisd meg. Egyes böngészők a `file://` ES modul importot korlátozzák, ezért a helyi webszerver ajánlott.

## Irányítás
- Bal / jobb gomb: sávváltás
- Nitro: nyomva tartva gyorsítás
- Forgalom: kerüld ki az autókat
- Ütközéskor új verseny indítható

## Prototípus státusz
Ez egy teljes 3D-s, WebGL-alapú játszható prototípus generált 3D geometriával, nem kész kereskedelmi játék. Nincsenek még licencelt autómodellek, valódi várostérkép, kampány, mentés vagy hangcsomag.
