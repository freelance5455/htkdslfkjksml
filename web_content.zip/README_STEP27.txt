STEP27 – Haushaltszentrale / Wow-Effekt

- Haushaltsstatus auf der Startseite
- Intelligente Prioritäten: MHD, Mindestbestand, Einkauf
- „Zuerst verbrauchen“ direkt auf dem Dashboard
- Direkte Aktionen aus den Prioritäten
- Bestehende Einkaufs-, Vorrats-, Vorsorge- und Kompassfunktionen unverändert
- Keine Supabase-Migration erforderlich
