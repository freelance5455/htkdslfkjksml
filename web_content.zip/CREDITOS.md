# Créditos
Monsters: Pixel Fantasy Monsters Pack by Laphkal (https://laphkal.itch.io/)
Licencia en assets/monsters/LICENSE-Laphkal.txt: uso gratuito y comercial permitido, edición permitida, crédito obligatorio.
No se permite revender ni redistribuir el pack como recurso suelto: aquí solo se incluyen las 12 hojas de sprites como parte del juego.

Efectos de magia: SpritePilot Magic & Projectiles Pack (CC0, https://spritepilot.com). Licencia en assets/fx/.
Héroes (mago y caballero) y jefe minotauro: RPG Pixel Art Sampler (Free) v4.1 de RetroLabStudioCo (https://furkan90x.itch.io/rpg-pixel-art-sampler-free). Crédito apreciado; no se permite revender ni redistribuir como pack suelto. Licencia en assets/heroes/ y assets/boss/.

Fondos de la ronda 6: generados por código (Canvas), sin recursos externos.

Orcos (Saqueador, Capitan, Acechador): Top-Down Orc Game Character Pixel Art, CraftPix.net (licencia gratuita, ver https://craftpix.net/file-licenses/ y assets/orcs/LICENSE-CraftPix.txt).

Ronda 11: Tiny RPG Character Asset Pack 01 (Soldier & Orc) y Tiny RPG Character Asset Pack 02 (Demon A & Blood Monster A), versiones gratuitas: sprites del Soldado, Orco de asedio, Bestia sangrienta, Demonio, la flecha y los jefes Bestia sangrienta / Demonio abisal (assets/orcs/).
Efectos: Effect and FX Pixel (All, Free): anillos de impacto, chispas y polvo (assets/fx/fx_*.png).
Los ZIP de estos packs no incluían archivo de licencia: revisa las condiciones en la página de origen de cada pack antes de publicar o vender el juego, y añade el nombre del autor aquí.

Ronda 13: efectos nuevos (fx_gale, fx_breath, fx_geyser, fx_splash, fx_spike, fx_rock, fx_crit, fx_halo) tomados de Effect and FX Pixel (All, Free). Orbes orb_*.png: recolores propios de energy-orb.png (SpritePilot, CC0).

Ronda 15: Free Pixel Art Tiny Hero Sprites (Pink, Owlet y Dude Monster), CraftPix.net (https://craftpix.net/file-licenses/). Licencia en assets/heroes/LICENSE-CraftPix-TinyHero.txt. Usados como sprites jugables de Ceniciento, Vórtice y Arco roto.

Ronda 17: efectos del Grimorio arcano (fx_void, fx_skull, fx_rays, fx_lotus, fx_galaxy, fx_hex, fx_ringfrag, fx_nova, fx_star, fx_pulse, fx_zig, fx_beam, fx_sun) tomados de Effect and FX Pixel (All, Free), sin archivo de licencia en el ZIP: revisa sus condiciones antes de publicar.

Ronda 17: sprites de Brea viva, Prisma, Hueco y Singular creados para este proyecto con tools/gen_heroes.py (arte original generado por código, sin recursos de terceros).
Dragón Abisal (assets/monsters/abyss_dragon.png): sprites recortados y reescalados a hoja 4x4 de 64 px a partir de la hoja de referencia "Dragón – Hoja de Sprites" aportada por el usuario.
