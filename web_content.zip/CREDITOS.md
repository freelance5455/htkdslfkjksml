# Créditos e licenças (reaproveitamento)
Código do jogo (index.html, game.js): original, escrito para este projeto.
Itens abaixo vêm dos arquivos que você enviou. **As licenças originais não foram confirmadas** — antes de publicar ou vender, confirme com a fonte de cada pacote.

| Uso no jogo | Origem |
|---|---|
| Nilo (pássaro), inimigos, tilesets Floresta/Caverna/Templo, fundos, tocha, mola, porta, estalactite, sons e músicas | projeto Kiwi Story (Construct 3) |
| Canhão, bola de canhão e pedra rolante | projeto Kiwi Story (Construct 3) |
| Mara, Marcos (placas), Guardião de Turbina e projéteis | projeto Demonoire (Construct 3) |
| Pipa | partícula do Demonoire ampliada 2x |
| Poderes temporários (ícones), espinhos, abismo/névoa, fragmentos de luz, corações, notas musicais da ponte, farol, silhueta do Curador, interface | desenhados em código (originais) |
| Textos/falas | 03_Narrativa/falas.json (escritas para este projeto) |
