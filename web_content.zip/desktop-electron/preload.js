const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('blaze', {
  chooseAndLaunch: () => ipcRenderer.invoke('blaze:choose-and-launch'),
  openOfficialDownload: () => ipcRenderer.invoke('blaze:official-download'),
  openModrinth: () => ipcRenderer.invoke('blaze:open-modrinth')
});
