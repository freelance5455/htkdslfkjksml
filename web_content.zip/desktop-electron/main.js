const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const { spawn } = require('node:child_process');
const path = require('node:path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1440, height: 920, minWidth: 360, minHeight: 640,
    backgroundColor: '#020817',
    title: 'BLAZE CLIENT',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.loadFile('renderer.html');
}
app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('blaze:choose-and-launch', async () => {
  const result = await dialog.showOpenDialog({
    title: 'Select your installed Minecraft Launcher',
    properties: ['openFile'],
    filters: process.platform === 'win32'
      ? [{ name: 'Windows applications', extensions: ['exe'] }]
      : [{ name: 'Applications', extensions: ['app', 'sh', 'desktop', '*'] }]
  });
  if (result.canceled || !result.filePaths[0]) return { ok: false, message: 'Launch cancelled.' };
  const executable = result.filePaths[0];
  try {
    const child = spawn(executable, [], { detached: true, stdio: 'ignore' });
    child.unref();
    return { ok: true, message: 'Minecraft Launcher opened. Sign in and press Play inside that official launcher.' };
  } catch (e) {
    return { ok: false, message: 'Could not open that file. Select the installed Minecraft Launcher executable.' };
  }
});
ipcMain.handle('blaze:official-download', async () => {
  await shell.openExternal('https://www.minecraft.net/download');
  return { ok: true, message: 'Opened the official Minecraft download page.' };
});
ipcMain.handle('blaze:open-modrinth', async () => {
  await shell.openExternal('https://modrinth.com/mods');
  return { ok: true, message: 'Opened Modrinth in your browser. Check version and loader compatibility.' };
});
