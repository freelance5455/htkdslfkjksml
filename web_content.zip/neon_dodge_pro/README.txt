NEON DODGE - UPGRADED GAME
Includes: selectable skins, coin collection, shop, high score, missions, sound toggle, pause/restart, mobile touch controls, increasing difficulty.
To package as APK: upload this ZIP to your HTML-to-APK service and preview first. Then create/build the app and download the APK.
All progress is saved locally in the browser/app storage. Uninstalling or clearing app data may erase it.
