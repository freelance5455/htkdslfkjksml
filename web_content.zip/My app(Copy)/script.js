function checkAccount() {
    // READ INSIDE so it gets fresh data
    const existingAccounts = JSON.parse(localStorage.getItem('hiace_users')) || [];
    
    const inputVal = document.getElementById("userEmail").value.trim().toLowerCase();
    const pass = document.getElementById("password").value.trim();
    const message = document.getElementById("message");

    const foundUser = existingAccounts.find(u => u.email === inputVal && u.password === pass);

    if (foundUser) {
        localStorage.setItem('registered email', foundUser.email);
        localStorage.setItem('use', 'okay');
        alert("Login successful....");
        window.location.href = "wallet.html";
    } else {
        const emailExists = existingAccounts.find(u => u.email === inputVal);
        if (emailExists) {
            message.textContent = "Wrong password, not identified";
            message.style.color = "red";
            alert("Wrong password");
        } else {
            message.textContent = "No account found with this email.";
            message.style.color = "red";
        }
    }
}

function show(){
localStorage.clear();
  let proceed= confirm("Are you sure you want to clear storage");
  if(proceed){
    alert("Cleared Successful");
  }

  else{
    alert("Cancelled");
  }
}