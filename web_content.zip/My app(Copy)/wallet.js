function withdrawal() {
  const message = document.querySelector("span");
  if(message){
    message.innerHTML = "Note : Only palmpay and Opay is available for withdrawal";
    message.style.color = "red";
  }
}

let countdown = 60;
let timeLeft = countdown;
let timerInterval = null;
let miningActive = true;
let cooldown = 240;
let cooldownTimeLeft = cooldown;
let cooldownInterval = null;
let isOnCooldown = false;

// BALANCE SAVE
let hiaceBalance = parseFloat(localStorage.getItem("hiace_balance")) || 23000;
let _isHidden = false;
let _savedBalance = "";

function formatNaira(num){
  return num.toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
}

function updateWalletDisplay(){
  const w = document.getElementById("wallet");
  if(w &&!_isHidden){
    w.innerText = formatNaira(hiaceBalance);
    _savedBalance = w.innerText;
  }
}

(function () {
  const style = document.createElement("style");
  style.innerHTML = `
    @keyframes floatUp {
      0% { transform: translate(-50%, 0) scale(1); opacity: 1; }
      100% { transform: translate(-50%, -130px) scale(1.3); opacity: 0; }
    }
    @keyframes vibrateMine {
      0%{ transform: scale(1) translateX(0) }
      25%{ transform: scale(1.12) translateX(-4px) }
      50%{ transform: scale(1.12) translateX(4px) }
      75%{ transform: scale(1.12) translateX(-4px) }
      100%{ transform: scale(1) translateX(0) }
    }
  .plus-one {
      position: absolute;
      left: 50%;
      top: 20%;
      font-weight: 900;
      font-size: 1.3rem;
      color: #FFC60A;
      pointer-events: none;
      animation: floatUp 0.9s ease-out forwards;
      z-index: 50;
    }
  .vibrate-active {
      animation: vibrateMine 0.18s ease-in-out 1!important;
    }
  .mine-card{position:relative;overflow:hidden}
  `;
  document.head.appendChild(style);
})();

function startTimer() {
  if (timerInterval || isOnCooldown) return;
  let timerPath = document.getElementById("countdownTimer");
  if (!timerPath) return;
  timeLeft = countdown;
  miningActive = true;
  let endTime = Date.now() + countdown * 1000;
  localStorage.setItem("hiace_mine_end", endTime);
  localStorage.removeItem("hiace_cooldown_end");
  timerPath.innerHTML = "Mining ends in <b>" + timeLeft + "s</b>";
  timerInterval = setInterval(function () {
    let remaining = Math.ceil((endTime - Date.now()) / 1000);
    timeLeft = remaining > 0? remaining : 0;
    timerPath.innerHTML = "Mining ends in <b>" + timeLeft + "s</b>";
    if (timeLeft <= 0) {
      clearInterval(timerInterval);
      timerInterval = null;
      miningActive = false;
      localStorage.removeItem("hiace_mine_end");
      startCooldown();
    }
  }, 1000);
}

function startCooldown() {
  let timerPath = document.getElementById("countdownTimer");
  let coin = document.getElementById("image");
  let tap = document.getElementById("tap");
  isOnCooldown = true;
  let endTime = Date.now() + cooldown * 1000;
  localStorage.setItem("hiace_cooldown_end", endTime);
  if (coin) coin.style.opacity = "0.5";
  if (tap) tap.style.opacity = "0.5";
  function updateCooldown() {
    let remaining = Math.ceil((endTime - Date.now()) / 1000);
    cooldownTimeLeft = remaining > 0? remaining : 0;
    let m = Math.floor(cooldownTimeLeft / 60);
    let s = cooldownTimeLeft % 60;
    let mm = m < 10? "0"+m : m;
    let ss = s < 10? "0"+s : s;
    timerPath.innerHTML = "Come back in <b>" + mm + ":" + ss + "</b> to mine";
    if (cooldownTimeLeft <= 0) {
      clearInterval(cooldownInterval);
      cooldownInterval = null;
      isOnCooldown = false;
      miningActive = true;
      localStorage.removeItem("hiace_cooldown_end");
      timerPath.innerHTML = "Ready to Mine - Tap to start";
      if (coin) coin.style.opacity = "1";
      if (tap) tap.style.opacity = "1";
    }
  }
  updateCooldown();
  cooldownInterval = setInterval(updateCooldown, 1000);
}

function checkStorage() {
  let mineEnd = localStorage.getItem("hiace_mine_end");
  let coolEnd = localStorage.getItem("hiace_cooldown_end");
  let now = Date.now();
  if (coolEnd) {
    let left = Math.ceil((parseInt(coolEnd) - now) / 1000);
    if (left > 0) {
      isOnCooldown = true;
      miningActive = false;
      let timerPath = document.getElementById("countdownTimer");
      let coin = document.getElementById("image");
      let tap = document.getElementById("tap");
      if (coin) coin.style.opacity = "0.5";
      if (tap) tap.style.opacity = "0.5";
      function resumeCool() {
        let end = localStorage.getItem("hiace_cooldown_end");
        let remaining = Math.ceil((parseInt(end) - Date.now()) / 1000);
        cooldownTimeLeft = remaining > 0? remaining : 0;
        let m = Math.floor(cooldownTimeLeft / 60);
        let s = cooldownTimeLeft % 60;
        let mm = m < 10? "0"+m : m;
        let ss = s < 10? "0"+s : s;
        if (timerPath) timerPath.innerHTML = "Come back in <b>" + mm + ":" + ss + "</b> to mine";
        if (cooldownTimeLeft <= 0) {
          clearInterval(cooldownInterval);
          cooldownInterval = null;
          isOnCooldown = false;
          miningActive = true;
          localStorage.removeItem("hiace_cooldown_end");
          if (timerPath) timerPath.innerHTML = "Ready to Mine - Tap to start";
          if (coin) coin.style.opacity = "1";
          if (tap) tap.style.opacity = "1";
        }
      }
      resumeCool();
      cooldownInterval = setInterval(resumeCool, 1000);
    } else {
      localStorage.removeItem("hiace_cooldown_end");
    }
  }
  if (mineEnd) {
    let left = Math.ceil((parseInt(mineEnd) - now) / 1000);
    if (left > 0) {
      timeLeft = left;
      miningActive = true;
      let timerPath = document.getElementById("countdownTimer");
      timerInterval = setInterval(function () {
        let end = localStorage.getItem("hiace_mine_end");
        let remaining = Math.ceil((parseInt(end) - Date.now()) / 1000);
        timeLeft = remaining > 0? remaining : 0;
        if (timerPath) timerPath.innerHTML = "Mining ends in <b>" + timeLeft + "s</b>";
        if (timeLeft <= 0) {
          clearInterval(timerInterval);
          timerInterval = null;
          miningActive = false;
          localStorage.removeItem("hiace_mine_end");
          startCooldown();
        }
      }, 1000);
      if (timerPath) timerPath.innerHTML = "Mining ends in <b>" + timeLeft + "s</b>";
    } else {
      localStorage.removeItem("hiace_mine_end");
      startCooldown();
    }
  }
  updateWalletDisplay();
}

function openUp(e) {
  const ump = document.querySelector("#indi");
  if (isOnCooldown) {
    ump.innerHTML = "Mining on cooldown - come back in 4 mins";
    ump.style.color = "#FFC60A";
    return;
  }
  if (!miningActive &&!timerInterval) {
    ump.innerHTML = "Restarting mining...";
    ump.style.color = "#FFC60A";
    startTimer();
    return;
  }
  if (!timerInterval) {
    startTimer();
  }
  if (!miningActive) {
    return;
  }
  ump.innerHTML = "Account not activated, Activate to Mine";
  ump.style.color = "red";
  // ADD BALANCE
  hiaceBalance += 1;
  localStorage.setItem("hiace_balance", hiaceBalance);
  updateWalletDisplay();

  const coin = document.getElementById("image");
  const card = document.querySelector(".mine-card");
  if (navigator.vibrate) navigator.vibrate(70);
  if (coin) {
    coin.classList.remove("vibrate-active");
    void coin.offsetWidth;
    coin.classList.add("vibrate-active");
    setTimeout(function () { coin.classList.remove("vibrate-active"); }, 220);
  }
  if (card) {
    const plus = document.createElement("div");
    plus.className = "plus-one";
    plus.textContent = "+1";
    const rect = card.getBoundingClientRect();
    let x = rect.width / 2;
    if (e) {
      const cx = e.touches? e.touches[0].clientX : e.clientX;
      x = cx - rect.left;
    }
    plus.style.left = x + "px";
    card.appendChild(plus);
    setTimeout(function () { plus.remove(); }, 900);
  }
}

function toggleShowBal() {
  const w = document.getElementById("wallet");
  const eye = document.getElementById("ppp");
  if(!w) return;
  if (_isHidden === false) {
    _savedBalance = w.innerText;
    w.innerText = "****.**";
    eye.innerText = "🙈";
    _isHidden = true;
  } else {
    w.innerText = _savedBalance || formatNaira(hiaceBalance);
    eye.innerText = "👁️";
    _isHidden = false;
  }
}

document.addEventListener("DOMContentLoaded", function () {
  const coin = document.getElementById("image");
  if (coin) {
    coin.addEventListener("touchstart", openUp, { passive: true });
  }
  checkStorage();
  updateWalletDisplay();
});

