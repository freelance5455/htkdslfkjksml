let fresh = parseFloat(localStorage.getItem('fresh')) || 0;
let doneTasks = JSON.parse(localStorage.getItem('doneTasks') || "[]");

document.getElementById('taskBalance').innerText = "$" + fresh.toFixed(2);

doneTasks.forEach(id=>{
  let card = document.getElementById(id);
  if(card){
    card.classList.add('done');
    card.querySelector('.task-btn').innerText = "Done";
    card.querySelector('.task-btn').disabled = true;
  }
});

function doTask(id, reward){
  if(doneTasks.includes(id)){
    alert("You don do this task already");
    return;
  }

  // special for task2 invite - generate link
  if(id === 'task2'){
    let username = localStorage.getItem('username') || "miner";
    let link = "https://hiace.app/ref/" + username.toLowerCase().replace(/\s/g,'');
    navigator.clipboard.writeText(link);
    alert("Referral link copied: " + link);
  }

  if(id === 'task4'){
    window.open("https://t.me/", "_blank");
  }

  fresh += reward;
  doneTasks.push(id);

  localStorage.setItem('fresh', fresh);
  localStorage.setItem('doneTasks', JSON.stringify(doneTasks));

  document.getElementById('taskBalance').innerText = "$" + fresh.toFixed(2);
  
  let card = document.getElementById(id);
  card.classList.add('done');
  card.querySelector('.task-btn').innerText = "Done";
  card.querySelector('.task-btn').disabled = true;

  alert("+" + reward + " HiAce added to wallet!");
}

// reset daily task every 24hrs
let lastClaim = localStorage.getItem('lastDaily');
let now = Date.now();
if(lastClaim && now - lastClaim > 86400000){
  // remove task1 from done so user can claim again
  doneTasks = doneTasks.filter(t=>t!=='task1');
  localStorage.setItem('doneTasks', JSON.stringify(doneTasks));
}