alert("Please wait while we verify");

