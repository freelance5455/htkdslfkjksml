let fresh = parseFloat(localStorage.getItem('fresh')) || 0;
let username = localStorage.getItem('username') || "HiAce Miner";

document.getElementById('pBalance').innerText = "$" + fresh.toFixed(2);
document.getElementById('pMined').innerText = fresh + " HiAce";
document.getElementById('username').innerText = username;
document.getElementById('userId').innerText = "ID: #" + Math.floor(1000 + fresh);
document.getElementById('userEmail').innerText = username.toLowerCase().replace(/\s/g,'') + "@hiace.com";

function editName(){
  let newName = prompt("Enter new username:", username);
  if(newName){
    localStorage.setItem('username', newName);
    document.getElementById('username').innerText = newName;
    location.reload();
  }
}

function copyRef(){
  let link = "https://hiace.app/ref/" + username.replace(/\s/g,'').toLowerCase() + Math.floor(Math.random()*1000);
  navigator.clipboard.writeText(link);
  alert("Referral copied: " + link);
}

function resetData(){
  if(confirm("You wan reset all your mining?")){
    localStorage.setItem('fresh', 0);
    alert("Reset done");
    location.href = "wallet.html";
  }
}

function logout(){
  alert("Logged out (demo)");
  window.location="index.html";
}