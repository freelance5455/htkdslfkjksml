const form = document.querySelector('form');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const confirm = document.getElementById('confirm');

form.addEventListener('submit', function(event) {
  event.preventDefault();
  const email = emailInput.value.trim().toLowerCase();
  const userPassword = passwordInput.value.trim();
  const confirmed = confirm.value.trim();

  if (confirmed != userPassword) {
    alert("password doesnt match");
    return;
  }

  let users = JSON.parse(localStorage.getItem('hiace_users')) || [];
  if (users.find(u => u.email === email)) {
    alert("Email already registered on HiAce");
    return;
  }

  users.push({ email: email, password: userPassword });
  localStorage.setItem('hiace_users', JSON.stringify(users));
  localStorage.setItem('registered email', email);
  localStorage.setItem('use', 'okay');
  
  alert('Signup successful! Redirecting...');
  window.location.href = 'wallet.html';
  
});
