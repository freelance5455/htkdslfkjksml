MY EXPENSE TRACKER - Android WebView project

এই project-এ HTML app-টি app/src/main/assets/index.html-এর ভিতরে আছে।
WebViewAssetLoader ব্যবহার করে appassets.androidplatform.net/assets/index.html থেকে load করা হয়েছে।
এটি Android-এর recommended local-content approach; file://android_assets ব্যবহার করা হয়নি।

Build: Android Studio-তে project open করে Gradle Sync শেষ হলে Build > Build APK(s)।
APK: app/build/outputs/apk/debug/app-debug.apk

Mobile-only: AIDE বা Android-compatible IDE-তে project import করে build করা যেতে পারে; SDK/Gradle download লাগতে পারে।
