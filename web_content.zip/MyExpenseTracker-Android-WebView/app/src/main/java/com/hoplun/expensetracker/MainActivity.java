package com.hoplun.expensetracker;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

public class MainActivity extends AppCompatActivity {
 private WebView webView;
 private static class LocalClient extends WebViewClientCompat {
  private final WebViewAssetLoader loader;
  LocalClient(WebViewAssetLoader l){loader=l;}
  @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){return loader.shouldInterceptRequest(r.getUrl());}
  @Override @SuppressWarnings("deprecation") public WebResourceResponse shouldInterceptRequest(WebView v,String u){return loader.shouldInterceptRequest(Uri.parse(u));}
 }
 @Override @SuppressLint("SetJavaScriptEnabled") protected void onCreate(Bundle b){super.onCreate(b); webView=new WebView(this); setContentView(webView);
  WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(false); s.setAllowContentAccess(false);
  WebViewAssetLoader loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
  webView.setWebViewClient(new LocalClient(loader)); webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
 }
 @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
