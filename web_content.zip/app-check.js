
const API_OVERRIDE = '';
const API = (API_OVERRIDE || (location.protocol.startsWith('http') ? location.origin : 'http://127.0.0.1:3000')).replace(/\/$/, '');
let token = localStorage.getItem('cp_token') || '';
let currentUser = localStorage.getItem('cp_user') || '';
let isRegister = false, currentPlay = null, authBusy = false;
let movieGenre = null, seriesGenre = null, genres = [];
let tMovie, tSeries;

function toast(msg, ms) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), ms || 2500);
}
function togglePwd(id, btn) {
  const i = document.getElementById(id);
  if (i.type === 'password') { i.type = 'text'; btn.textContent = 'مخفی'; }
  else { i.type = 'password'; btn.textContent = 'نمایش'; }
}

async function api(path, opts) {
  opts = opts || {};
  const headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
  if (token) headers['Authorization'] = 'Bearer ' + token;
  let res;
  try {
    res = await fetch(API + path, Object.assign({}, opts, { headers }));
  } catch (e) {
    throw new Error('اتصال به سرور قطع است.\nآدرس: ' + API + '\nابتدا server.py را اجرا کنید.');
  }
  const text = await res.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch (e) { data = { error: text || 'پاسخ نامعتبر' }; }
  if (!res.ok) throw new Error(data.error || data.message || ('خطا ' + res.status));
  return data;
}

function showScreen(name) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('screen-' + name).classList.add('active');
  if (name === 'main') loadHome();
  if (name === 'subscription') loadSubscription();
  if (name === 'profile') loadProfile();
}

function switchTab(tab) {
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.add('hidden'));
  const target = document.getElementById('tab-' + tab);
  if (!target) return;
  target.classList.remove('hidden');
  document.querySelectorAll('.bottom-nav button').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  const titles = { home: 'CINEMA GOLD', movies: 'فیلم‌ها', series: 'سریال‌ها', favorites: 'علاقه‌مندی‌ها', more: 'بیشتر' };
  document.getElementById('mainTitle').textContent = titles[tab] || 'CINEMA GOLD';
  if (tab === 'movies') loadMovies();
  if (tab === 'series') loadSeries();
  if (tab === 'favorites') renderFavorites();
  if (tab === 'more') document.getElementById('moreGreeting').textContent = 'سلام ' + (currentUser || 'کاربر عزیز');
}

function toggleAuthMode() {
  isRegister = !isRegister;
  document.getElementById('authHint').textContent = isRegister ? 'ثبت‌نام رایگان' : 'ورود به حساب کاربری';
  document.getElementById('authBtn').textContent = isRegister ? 'ثبت‌نام' : 'ورود';
  document.getElementById('confirmBox').classList.toggle('hidden', !isRegister);
  document.getElementById('authMsg').innerHTML = '';
}

async function doAuth() {
  if (authBusy) return;
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  const password2 = document.getElementById('password2').value;
  const msg = document.getElementById('authMsg');
  const btn = document.getElementById('authBtn');
  msg.innerHTML = '';
  if (username.length < 3) { msg.innerHTML = '<div class="msg err">نام کاربری حداقل ۳ کاراکتر</div>'; return; }
  if (password.length < 10) { msg.innerHTML = '<div class="msg err">رمز عبور حداقل ۱۰ کاراکتر</div>'; return; }
  if (isRegister && password !== password2) { msg.innerHTML = '<div class="msg err">تکرار رمز مطابقت ندارد</div>'; return; }
  authBusy = true; btn.disabled = true;
  btn.textContent = isRegister ? 'در حال ثبت‌نام...' : 'در حال ورود...';
  try {
    const data = await api(isRegister ? '/api/auth/register' : '/api/auth/login', {
      method: 'POST', body: JSON.stringify({ username, password })
    });
    if (!data.token) throw new Error('توکن دریافت نشد');
    token = data.token;
    currentUser = (data.user && data.user.username) || username;
    localStorage.setItem('cp_token', token);
    localStorage.setItem('cp_user', currentUser);
    msg.innerHTML = '<div class="msg ok">' + (data.message || 'ورود موفق') + '</div>';
    toast(isRegister ? 'ثبت‌نام موفق — حساب رایگان فعال شد' : 'خوش آمدید ' + currentUser);
    setTimeout(() => { showScreen('main'); switchTab('home'); }, 400);
  } catch (e) {
    msg.innerHTML = '<div class="msg err">' + e.message + '</div>';
  } finally {
    authBusy = false; btn.disabled = false;
    btn.textContent = isRegister ? 'ثبت‌نام' : 'ورود';
  }
}

async function logout() {
  try { if (token) await api('/api/auth/logout', {method:'POST'}); } catch (_) {}
  token = '';
  localStorage.removeItem('cp_token');
  localStorage.removeItem('cp_user');
  showScreen('login');
}

function esc(s) { const d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }
function formatViews(v) {
  v = v || 0;
  if (v >= 1e6) return (v/1e6).toFixed(1) + 'M';
  if (v >= 1e3) return (v/1e3).toFixed(1) + 'K';
  return String(v);
}

function getRecent() {
  try { return JSON.parse(localStorage.getItem('cp_recent') || '[]'); } catch { return []; }
}
function addRecent(item) {
  let list = getRecent().filter(x => !(x.type === item.type && x.id === item.id));
  list.unshift(item);
  list = list.slice(0, 12);
  localStorage.setItem('cp_recent', JSON.stringify(list));
}
function clearRecent() {
  localStorage.removeItem('cp_recent');
  renderRecent();
  toast('تاریخچه پاک شد');
}
function renderRecent() {
  const list = getRecent();
  const box = document.getElementById('recentBox');
  const el = document.getElementById('recentList');
  if (!list.length) { box.classList.add('hidden'); return; }
  box.classList.remove('hidden');
  el.innerHTML = list.map(i => {
    const open = i.type === 'series' ? 'openSeries' : 'openMovie';
    const ph = i.poster
      ? `<img src="${esc(i.poster)}" alt="" onerror="this.outerHTML='<div class=poster-ph>${esc((i.title||'?')[0])}</div>'"/>`
      : `<div class="poster-ph">${esc((i.title||'?')[0])}</div>`;
    return `<div class="recent-item" onclick="${open}(${i.id})">${ph}<div class="t">${esc(i.title)}</div></div>`;
  }).join('');
}

function cardHTML(item, type) {
  const poster = item.poster_url
    ? `<img class="poster" src="${esc(item.poster_url)}" alt="" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"/><div class="poster-ph" style="display:none">${esc((item.title||'?')[0])}</div>`
    : `<div class="poster-ph">${esc((item.title||'?')[0])}</div>`;
  const badge = type === 'series' ? 'سریال' : (item.genre || '');
  const fav = isFavorite(type, item.id);
  return `<div class="item" onclick="open${type==='series'?'Series':'Movie'}(${item.id})">
    ${badge ? `<span class="badge">${esc(badge)}</span>` : ''}
    <button class="favorite-btn ${fav?'active':''}" aria-label="علاقه‌مندی" onclick="event.stopPropagation();toggleFavorite('${type}',${item.id})">${fav?'♥':'♡'}</button>
    ${poster}
    <div class="meta"><div class="title">${esc(item.title)}</div>
    <div class="sub"><span class="star">★</span> ${item.rating_avg||0} • ${formatViews(item.view_count)} بازدید</div></div></div>`;
}

function favoritesKey() { return 'cg_favorites_' + (currentUser || 'guest'); }
function getFavorites() { try { return JSON.parse(localStorage.getItem(favoritesKey()) || '[]'); } catch { return []; } }
function isFavorite(type,id) { return getFavorites().some(x => x.type === type && Number(x.id) === Number(id)); }
async function toggleFavorite(type,id) {
  const list = getFavorites();
  const idx = list.findIndex(x => x.type === type && Number(x.id) === Number(id));
  if (idx >= 0) { list.splice(idx,1); localStorage.setItem(favoritesKey(),JSON.stringify(list)); toast('از علاقه‌مندی‌ها حذف شد'); }
  else {
    try {
      const item = await api(type === 'series' ? '/api/series/' + id : '/api/movies/' + id);
      list.unshift({type,id:Number(id),item});
      localStorage.setItem(favoritesKey(),JSON.stringify(list)); toast('به علاقه‌مندی‌ها اضافه شد');
    } catch(e) { toast('ذخیره انجام نشد: ' + e.message); return; }
  }
  renderFavorites();
  if (document.getElementById('tab-home') && !document.getElementById('tab-home').classList.contains('hidden')) loadHome();
  if (document.getElementById('tab-movies') && !document.getElementById('tab-movies').classList.contains('hidden')) loadMovies();
  if (document.getElementById('tab-series') && !document.getElementById('tab-series').classList.contains('hidden')) loadSeries();
}
function renderFavorites() {
  const el = document.getElementById('favoritesGrid'); if (!el) return;
  const items = getFavorites();
  el.innerHTML = items.length ? items.map(x => cardHTML(x.item,x.type)).join('') : '<div class="empty" style="grid-column:1/-1">هنوز فیلم یا سریالی به علاقه‌مندی‌ها اضافه نکرده‌اید. روی قلب پوسترها بزنید.</div>';
}

function timeLabel(seconds) {
  const n = Math.max(0, Math.floor(Number(seconds) || 0));
  const h = Math.floor(n / 3600), m = Math.floor((n % 3600) / 60);
  return h ? `${h} ساعت و ${m} دقیقه` : `${m} دقیقه`;
}
async function loadContinueWatching() {
  const box = document.getElementById('continueBox');
  const el = document.getElementById('continueList');
  try {
    const items = await api('/api/me/watch-progress');
    if (!items.length) { box.classList.add('hidden'); return; }
    box.classList.remove('hidden');
    el.innerHTML = items.map(item => {
      const pct = item.duration > 0 ? Math.max(0, Math.min(100, item.position_seconds / item.duration * 100)) : 0;
      const poster = item.poster_url ? `<img src="${esc(item.poster_url)}" alt="" loading="lazy" onerror="this.outerHTML='<div class=poster-ph>${esc((item.title||'?')[0])}</div>'">` : `<div class="poster-ph">${esc((item.title||'?')[0])}</div>`;
      return `<div class="continue-card" onclick="resumeContent('${item.type}',${item.id})">${poster}<div class="continue-info"><strong>${esc(item.title)}</strong><small>${item.type==='episode' ? esc(item.series_title||'سریال')+' • ' : ''}ادامه از ${timeLabel(item.position_seconds)}</small><div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div></div><button class="continue-remove" title="حذف از تاریخچه" onclick="event.stopPropagation();removeWatchItem('${item.type}',${item.id})">×</button></div>`;
    }).join('');
  } catch (e) { box.classList.add('hidden'); }
}
async function resumeContent(type, id) {
  if (type === 'movie') return playMovie(id);
  try { openPlayer(await api('/api/series/episodes/'+id+'/play')); }
  catch (e) { toast(e.message); if (String(e.message).includes('اشتراک')) showScreen('subscription'); }
}
async function removeWatchItem(type, id) {
  try { await api('/api/me/watch-progress', {method:'POST', body:JSON.stringify({action:'remove', type, id})}); await loadContinueWatching(); toast('از ادامه تماشا حذف شد'); }
  catch (e) { toast(e.message); }
}
async function clearWatchHistory() {
  if (!confirm('تمام موارد بخش ادامه تماشا پاک شود؟')) return;
  try { await api('/api/me/watch-progress', {method:'POST', body:JSON.stringify({action:'clear'})}); await loadContinueWatching(); toast('تاریخچه پاک شد'); }
  catch (e) { toast(e.message); }
}
function applyPublicAppearance(settings) {
  if (!settings) return;
  const colors = settings.colors || {};
  const root = document.documentElement;
  const map = {bg:'--bg',card:'--card',primary:'--primary',text:'--text',muted:'--muted',border:'--border'};
  Object.entries(map).forEach(([key, variable]) => { if (typeof colors[key] === 'string' && /^#[0-9a-f]{6}$/i.test(colors[key])) root.style.setProperty(variable, colors[key]); });
  if (colors.card) root.style.setProperty('--card2', colors.card);
  if (colors.bg && colors.card) document.body.style.background = `linear-gradient(145deg,${colors.bg},${colors.card} 58%,${colors.bg})`;
  const themeMeta = document.querySelector('meta[name="theme-color"]');
  if (themeMeta && colors.bg) themeMeta.setAttribute('content', colors.bg);
}

let homeHeroTimer = null;
function renderHomeHeroSlides(urls) {
  const host=document.getElementById('heroSlides'), dots=document.getElementById('heroDots'), hero=document.getElementById('homeHero');
  const prev=document.getElementById('heroPrev'), next=document.getElementById('heroNext'), pause=document.getElementById('heroPause');
  if(!host||!dots||!hero) return;
  if(homeHeroTimer){clearInterval(homeHeroTimer);homeHeroTimer=null;}
  const list=(Array.isArray(urls)?urls:[]).filter(u=>typeof u==='string'&&u.trim()).slice(0,5);
  host.innerHTML=''; dots.innerHTML='';
  if(!list.length){hero.classList.remove('has-poster');[prev,next,pause].forEach(b=>{if(b)b.hidden=true;});return;}
  hero.classList.add('has-poster');
  let index=0, paused=false;
  const controls=[prev,next,pause]; controls.forEach(b=>{if(b)b.hidden=list.length<2;});
  function showSlide(nextIndex){
    const slides=host.children, indicators=dots.children;
    if(!slides.length)return;
    index=(nextIndex+slides.length)%slides.length;
    Array.from(slides).forEach((el,i)=>el.classList.toggle('active',i===index));
    Array.from(indicators).forEach((el,i)=>{el.classList.toggle('active',i===index);el.setAttribute('aria-current',i===index?'true':'false');});
  }
  list.forEach((url,i)=>{
    const slide=document.createElement('div');slide.className='hero-slide'+(i===0?' active':'');
    slide.style.backgroundImage=`linear-gradient(90deg,rgba(8,11,22,.92) 0%,rgba(8,11,22,.66) 48%,rgba(8,11,22,.22) 100%),url("${url.replace(/"/g,'%22')}")`;
    host.appendChild(slide);
    const dot=document.createElement('button');dot.type='button';dot.className='hero-dot'+(i===0?' active':'');dot.setAttribute('aria-label',`نمایش پوستر ${i+1}`);dot.setAttribute('aria-current',i===0?'true':'false');dot.addEventListener('click',()=>{showSlide(i);restartTimer();});dots.appendChild(dot);
  });
  function stopTimer(){if(homeHeroTimer){clearInterval(homeHeroTimer);homeHeroTimer=null;}}
  function startTimer(){stopTimer();if(list.length>1&&!paused&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches)homeHeroTimer=setInterval(()=>showSlide(index+1),6000);}
  function restartTimer(){startTimer();}
  if(prev)prev.onclick=()=>{showSlide(index-1);restartTimer();};
  if(next)next.onclick=()=>{showSlide(index+1);restartTimer();};
  if(pause){pause.textContent='Ⅱ';pause.setAttribute('aria-label','توقف نمایش خودکار');pause.onclick=()=>{paused=!paused;pause.textContent=paused?'▶':'Ⅱ';pause.setAttribute('aria-label',paused?'ادامه نمایش خودکار':'توقف نمایش خودکار');if(paused)stopTimer();else startTimer();};}
  let touchStartX=null;
  hero.ontouchstart=e=>{touchStartX=e.changedTouches&&e.changedTouches[0]?e.changedTouches[0].clientX:null;};
  hero.ontouchend=e=>{if(touchStartX===null||!e.changedTouches||!e.changedTouches[0])return;const dx=e.changedTouches[0].clientX-touchStartX;touchStartX=null;if(Math.abs(dx)>45){showSlide(index+(dx>0?-1:1));restartTimer();}};
  hero.onmouseenter=()=>stopTimer(); hero.onmouseleave=()=>{if(!paused)startTimer();};
  showSlide(0);startTimer();
}

async function loadHome() {
  renderRecent();
  loadContinueWatching();
  try {
    const [ps, pm, st, settings] = await Promise.all([
      api('/api/series/popular'),
      api('/api/movies/popular'),
      api('/api/subscription/me').catch(() => null),
      api('/api/app-settings').catch(() => null)
    ]);
    applyPublicAppearance(settings);
    const featured = (pm && pm.length ? pm[0] : (ps && ps.length ? ps[0] : null));
    const hero = document.getElementById('homeHero');
    const heroTitle = document.getElementById('heroTitle');
    const heroDesc = document.getElementById('heroDescription');
    const heroButton = document.getElementById('heroButton');
    const customHeroPoster = settings && settings.hero_poster_url;
    const customSlides = settings && Array.isArray(settings.hero_slides) ? settings.hero_slides.filter(Boolean).slice(0,5) : [];
    const slideList = customSlides.length ? customSlides : (customHeroPoster ? [customHeroPoster] : []);
    if (slideList.length) {
      renderHomeHeroSlides(slideList);
      heroTitle.textContent = settings.hero_title || 'دنیای فیلم و سریال، در یک قاب';
      heroDesc.textContent = settings.hero_description || 'جدیدترین فیلم‌ها و سریال‌ها را با تجربه‌ای سینمایی دنبال کنید.';
      heroButton.textContent = settings.hero_button || 'ورود به فیلم‌ها';
      heroButton.onclick = () => switchTab('movies');
    } else if (featured) {
      renderHomeHeroSlides(featured.poster_url ? [featured.poster_url] : []);
      heroTitle.textContent = featured.title || 'پیشنهاد ویژه';
      heroDesc.textContent = featured.description || 'برای مشاهده جزئیات و تماشای این عنوان وارد شوید.';
      heroButton.textContent = 'مشاهده و تماشا';
      heroButton.onclick = () => (featured === (pm && pm[0]) ? openMovie(featured.id) : openSeries(featured.id));
    } else {
      renderHomeHeroSlides([]);
      heroTitle.textContent = (settings && settings.hero_title) || 'دنیای فیلم و سریال، در یک قاب';
      heroDesc.textContent = (settings && settings.hero_description) || 'جدیدترین فیلم‌ها و سریال‌ها را با تجربه‌ای سینمایی دنبال کنید.';
      heroButton.textContent = (settings && settings.hero_button) || 'مشاهده فیلم‌ها'; heroButton.onclick = () => switchTab('movies');
    }
    document.getElementById('popularSeries').innerHTML = ps.length ? ps.map(s => cardHTML(s,'series')).join('') : '<div class="empty">سریالی نیست</div>';
    document.getElementById('popularMovies').innerHTML = pm.length ? pm.map(m => cardHTML(m,'movie')).join('') : '<div class="empty">فیلمی نیست</div>';
    const banner = document.getElementById('subBanner');
    banner.className = 'banner';
    if (!st) {
      document.getElementById('subTitle').textContent = 'وضعیت اشتراک';
      document.getElementById('subSub').textContent = 'برای جزئیات لمس کنید';
    } else if (st.hasAccess && st.type === 'admin') {
      banner.classList.add('ok');
      document.getElementById('subTitle').textContent = 'دسترسی مدیر';
      document.getElementById('subSub').textContent = 'نامحدود';
    } else if (st.hasAccess && st.type === 'free') {
      banner.classList.add('ok');
      document.getElementById('subTitle').textContent = 'تماشای رایگان فعال است';
      document.getElementById('subSub').textContent = 'در این نسخه دسترسی رایگان فعال است';
    }
    else if (st.hasAccess && st.type === 'free_trial') {
      banner.classList.add('trial');
      document.getElementById('subTitle').textContent = 'دوره رایگان فعال';
      document.getElementById('subSub').textContent = 'تا ' + (st.endsAt||'').slice(0,10);
    } else if (st.hasAccess) {
      banner.classList.add('ok');
      document.getElementById('subTitle').textContent = 'اشتراک فعال';
      document.getElementById('subSub').textContent = (st.type||'') + ' تا ' + (st.endsAt||'').slice(0,10);
    } else {
      banner.classList.add('warn');
      document.getElementById('subTitle').textContent = 'اشتراک ندارید';
      document.getElementById('subSub').textContent = 'برای تماشا اشتراک تهیه کنید';
    }
  } catch (e) {
    document.getElementById('popularMovies').innerHTML = '<div class="msg err">' + e.message + '</div>';
  }
}

async function ensureGenres() {
  if (genres.length) return;
  try { genres = await api('/api/genres'); } catch { genres = []; }
}
function renderChips(elId, selected, onSelect) {
  const el = document.getElementById(elId);
  el.innerHTML = `<button class="chip ${!selected?'active':''}" data-g="">همه</button>` +
    genres.map(g => `<button class="chip ${selected===g?'active':''}" data-g="${esc(g)}">${esc(g)}</button>`).join('');
  el.querySelectorAll('.chip').forEach(c => c.onclick = () => onSelect(c.dataset.g || null));
}

async function loadMovies() {
  await ensureGenres();
  renderChips('movieChips', movieGenre, g => { movieGenre = g; loadMovies(); });
  const q = document.getElementById('movieQ').value.trim();
  let url = '/api/movies?';
  if (q) url += 'q=' + encodeURIComponent(q) + '&';
  if (movieGenre) url += 'genre=' + encodeURIComponent(movieGenre);
  try {
    const list = await api(url);
    document.getElementById('moviesGrid').innerHTML = list.length ? list.map(m => cardHTML(m,'movie')).join('') : '<div class="empty">موردی یافت نشد</div>';
  } catch (e) {
    document.getElementById('moviesGrid').innerHTML = '<div class="msg err">' + e.message + '</div>';
  }
}
async function loadSeries() {
  await ensureGenres();
  renderChips('seriesChips', seriesGenre, g => { seriesGenre = g; loadSeries(); });
  const q = document.getElementById('seriesQ').value.trim();
  let url = '/api/series?';
  if (q) url += 'q=' + encodeURIComponent(q) + '&';
  if (seriesGenre) url += 'genre=' + encodeURIComponent(seriesGenre);
  try {
    const list = await api(url);
    document.getElementById('seriesGrid').innerHTML = list.length ? list.map(s => cardHTML(s,'series')).join('') : '<div class="empty">موردی یافت نشد</div>';
  } catch (e) {
    document.getElementById('seriesGrid').innerHTML = '<div class="msg err">' + e.message + '</div>';
  }
}
function debounceMovies(){ clearTimeout(tMovie); tMovie=setTimeout(loadMovies,350); }
function debounceSeries(){ clearTimeout(tSeries); tSeries=setTimeout(loadSeries,350); }

async function openMovie(id) {
  showScreen('movie');
  const el = document.getElementById('movieDetail');
  el.innerHTML = '<div class="loading">بارگذاری...</div>';
  try {
    const m = await api('/api/movies/' + id);
    addRecent({ type:'movie', id:m.id, title:m.title, poster:m.poster_url });
    let comments = [];
    try { comments = await api('/api/comments/movie/' + id); } catch {}
    el.innerHTML = `
      <div class="detail-hero">
        <div class="thumb">${m.poster_url?`<img src="${esc(m.poster_url)}" style="width:100%;display:block" onerror="this.parentNode.innerHTML='<div class=poster-ph>${esc((m.title||'')[0])}</div>'"/>`:`<div class="poster-ph">${esc((m.title||'')[0])}</div>`}</div>
        <div>
          <h2 style="font-size:1.2rem;margin-bottom:8px">${esc(m.title)}</h2>
          <div class="sub"><span class="star">★</span> ${m.rating_avg} (${m.rating_count||0} رأی)</div>
          <div class="sub" style="color:var(--muted);margin-top:4px">${formatViews(m.view_count)} بازدید</div>
          <div class="sub" style="color:var(--muted);margin-top:4px">${m.year||''} • ${esc(m.genre||'')}</div>
        </div>
      </div>
      <p style="color:var(--muted);line-height:1.7;margin-bottom:12px">${esc(m.description||'')}</p>
      <div class="actions">
        <button class="btn" onclick="playMovie(${m.id})">▶ پخش</button>
        <button class="btn secondary" onclick="downloadItem('movie',${m.id},'${esc(m.title)}')">⬇ دانلود</button>
        <button class="btn outline" onclick="reportContent('movie',${m.id})">گزارش مشکل</button>
      </div>
      <div class="rating-row">
        <span>امتیاز شما</span>
        <input type="range" id="rateVal" min="1" max="10" value="8" oninput="document.getElementById('rateLabel').textContent=this.value"/>
        <span id="rateLabel">8</span>
        <button class="btn sm" onclick="rateItem('movie',${m.id})">ثبت</button>
      </div>
      <h3 style="margin:16px 0 8px">نظرات (${comments.length})</h3>
      <div>${comments.map(c=>`<div class="comment"><div class="who">${esc(c.username)}</div><div>${esc(c.body)}</div><div class="when">${esc((c.created_at||'').slice(0,16))}</div></div>`).join('')||'<div class="empty">نظری نیست</div>'}</div>
      <textarea id="commentBody" rows="2" placeholder="نظر شما..." style="margin-top:8px"></textarea>
      <button class="btn" onclick="postComment('movie',${m.id})">ارسال نظر</button>`;
  } catch (e) { el.innerHTML = '<div class="msg err">'+e.message+'</div>'; }
}

async function openSeries(id) {
  showScreen('series');
  const el = document.getElementById('seriesDetail');
  el.innerHTML = '<div class="loading">بارگذاری...</div>';
  try {
    const s = await api('/api/series/' + id);
    addRecent({ type:'series', id:s.id, title:s.title, poster:s.poster_url });
    let comments = [];
    try { comments = await api('/api/comments/series/' + id); } catch {}
    const seasonsHtml = (s.seasons||[]).map(season => `
      <div class="season">
        <strong>${esc(season.title||('فصل '+season.season_number))}</strong>
        ${(season.episodes||[]).map(ep=>`
          <div class="ep">
            <span>قسمت ${ep.episode_number}: ${esc(ep.title||'')}</span>
            <span>
              <button class="btn sm" onclick="playEpisode(${ep.id})">پخش</button>
              <button class="btn sm secondary" onclick="downloadItem('episode',${ep.id},'${esc(ep.title||'')}')">دانلود</button>
            </span>
          </div>`).join('')||'<div class="empty">قسمتی نیست</div>'}
      </div>`).join('')||'<div class="empty">فصلی ثبت نشده</div>';
    el.innerHTML = `
      <div class="detail-hero">
        <div class="thumb">${s.poster_url?`<img src="${esc(s.poster_url)}" style="width:100%;display:block"/>`:`<div class="poster-ph">${esc((s.title||'')[0])}</div>`}</div>
        <div>
          <h2 style="font-size:1.2rem;margin-bottom:8px">${esc(s.title)}</h2>
          <div class="sub"><span class="star">★</span> ${s.rating_avg} • ${formatViews(s.view_count)} بازدید</div>
          <div class="sub" style="color:var(--muted);margin-top:4px">${s.year||''} • ${esc(s.genre||'')}</div>
        </div>
      </div>
      <p style="color:var(--muted);line-height:1.7;margin-bottom:12px">${esc(s.description||'')}</p>
      ${seasonsHtml}
      <div class="actions"><button class="btn outline" onclick="reportContent('series',${s.id})">گزارش مشکل این سریال</button></div>
      <h3 style="margin:16px 0 8px">نظرات (${comments.length})</h3>
      <div>${comments.map(c=>`<div class="comment"><div class="who">${esc(c.username)}</div><div>${esc(c.body)}</div></div>`).join('')||'<div class="empty">نظری نیست</div>'}</div>
      <textarea id="commentBodyS" rows="2" placeholder="نظر شما..." style="margin-top:8px"></textarea>
      <button class="btn" onclick="postComment('series',${s.id},true)">ارسال نظر</button>`;
  } catch (e) { el.innerHTML = '<div class="msg err">'+e.message+'</div>'; }
}

async function playMovie(id) {
  try { openPlayer(await api('/api/movies/'+id+'/play')); }
  catch(e){ toast(e.message); if(String(e.message).includes('اشتراک')) showScreen('subscription'); }
}
async function playEpisode(id) {
  try { openPlayer(await api('/api/series/episodes/'+id+'/play')); }
  catch(e){ toast(e.message); if(String(e.message).includes('اشتراک')) showScreen('subscription'); }
}
let lastProgressWrite = 0;
function mediaHref(path) { return path ? (path.startsWith('http') ? path : API + path) : ''; }
function saveWatchProgress(force) {
  const v = document.getElementById('videoEl');
  if (!currentPlay || !token || !Number.isFinite(v.currentTime)) return;
  const now = Date.now();
  if (!force && now - lastProgressWrite < 10000) return;
  lastProgressWrite = now;
  api('/api/me/watch-progress', {method:'POST', body:JSON.stringify({type:currentPlay.type, id:currentPlay.id, position_seconds:Math.floor(v.currentTime)})}).catch(()=>{});
}
function renderPlayerOptions(p) {
  const el = document.getElementById('playerOptions');
  const v = document.getElementById('videoEl');
  el.innerHTML = '';
  const addSelect = (label, items, onChange) => {
    if (!items || !items.length) return;
    const wrap = document.createElement('label'); wrap.style.cssText='display:flex;align-items:center;gap:6px;color:var(--muted);font-size:.85rem';
    const span = document.createElement('span'); span.textContent=label;
    const select = document.createElement('select'); select.style.cssText='max-width:150px;padding:7px;border-radius:8px;background:var(--card);color:var(--text);border:1px solid var(--border)';
    items.forEach((item,i)=>{const o=document.createElement('option');o.value=String(i);o.textContent=item.label||item.name||item.quality||(`${label} ${i+1}`);select.appendChild(o)});
    select.addEventListener('change',()=>onChange(items[Number(select.value)])); wrap.append(span,select); el.appendChild(wrap);
  };
  addSelect('کیفیت', p.quality_options, item=>{
    if (!item.url) return toast('لینک این کیفیت ثبت نشده است');
    const t=v.currentTime; v.src=mediaHref(item.url); v.load(); v.addEventListener('loadedmetadata',()=>{v.currentTime=t;v.play().catch(()=>{})},{once:true});
  });
  addSelect('صدا', p.audio_tracks, item=>{
    if (!item.url) return toast('لینک این ترک صوتی ثبت نشده است');
    const t=v.currentTime; v.src=mediaHref(item.url); v.load(); v.addEventListener('loadedmetadata',()=>{v.currentTime=t;v.play().catch(()=>{})},{once:true});
  });
  addSelect('زیرنویس', [{label:'بدون زیرنویس',url:''}, ...(p.subtitle_tracks||[])], item=>{
    [...v.querySelectorAll('track')].forEach(t=>t.remove());
    if (item.url) { const t=document.createElement('track'); t.kind='subtitles'; t.label=item.label||'زیرنویس'; t.srclang=item.language||'fa'; t.src=mediaHref(item.url); t.default=true; v.appendChild(t); }
  });
}
function openPlayer(p) {
  currentPlay = p;
  document.getElementById('playerTitle').textContent = p.title || '';
  const v = document.getElementById('videoEl');
  v.pause();
  while (v.firstChild) v.removeChild(v.firstChild);
  v.src = mediaHref(p.video_url || '');
  renderPlayerOptions(p);
  v.load();
  showScreen('player');
  const resume = Math.max(0, Number(p.resume_position)||0);
  if (resume > 5) {
    v.addEventListener('loadedmetadata',()=>{ if (resume < (v.duration||Infinity)-5) v.currentTime=resume; },{once:true});
    toast('ادامه از دقیقه ' + Math.floor(resume/60));
  }
  v.play().catch(()=>{});
}
function closePlayer() {
  const v = document.getElementById('videoEl');
  saveWatchProgress(true);
  v.pause(); v.removeAttribute('src'); v.load();
  document.getElementById('playerOptions').innerHTML='';
  currentPlay=null;
  showScreen('main');
  loadContinueWatching();
}
const progressVideo = document.getElementById('videoEl');
progressVideo.addEventListener('timeupdate',()=>saveWatchProgress(false));
progressVideo.addEventListener('pause',()=>saveWatchProgress(true));
progressVideo.addEventListener('ended',()=>{ if(currentPlay) api('/api/me/watch-progress',{method:'POST',body:JSON.stringify({action:'remove',type:currentPlay.type,id:currentPlay.id})}).then(loadContinueWatching).catch(()=>{}); });
document.addEventListener('visibilitychange',()=>{ if(document.visibilityState==='hidden') saveWatchProgress(true); });
window.addEventListener('pagehide',()=>saveWatchProgress(true));
async function downloadItem(type, id, title) {
  try {
    const res = await api('/api/downloads/request', { method:'POST', body: JSON.stringify({ type, id }) });
    if (res.video_url) {
      window.open(res.video_url, '_blank');
      if (res.subtitle_url) window.open(res.subtitle_url, '_blank');
      toast(res.message || 'دانلود شروع شد');
    }
  } catch(e){ toast(e.message); if(String(e.message).includes('اشتراک')) showScreen('subscription'); }
}
function downloadCurrent() {
  if (!currentPlay || !currentPlay.video_url) return;
  window.open(mediaHref(currentPlay.video_url), '_blank');
  toast('لینک دانلود باز شد');
}
async function reportContent(type, id) {
  const category = prompt('نوع مشکل: broken_link / video / audio / subtitle / quality / other', 'video');
  if (!category) return;
  const description = prompt('توضیح کوتاه مشکل (اختیاری):', '') || '';
  try {
    await api('/api/reports', {method:'POST', body:JSON.stringify({content_type:type, content_id:id, category, description})});
    toast('گزارش شما ثبت شد. ممنون از اطلاع‌رسانی.');
  } catch(e) { toast(e.message); }
}
async function rateItem(type, id) {
  const score = parseInt(document.getElementById('rateVal').value, 10);
  try { await api('/api/ratings/'+type+'/'+id, { method:'POST', body: JSON.stringify({ score }) }); toast('امتیاز ثبت شد'); openMovie(id); }
  catch(e){ toast(e.message); }
}
async function postComment(type, id, isSeries) {
  const body = document.getElementById(isSeries ? 'commentBodyS' : 'commentBody').value.trim();
  if (!body) { toast('متن نظر خالی است'); return; }
  try {
    await api('/api/comments/'+type+'/'+id, { method:'POST', body: JSON.stringify({ body }) });
    toast('نظر ثبت شد');
    if (isSeries) openSeries(id); else openMovie(id);
  } catch(e){ toast(e.message); }
}
async function loadSubscription() {
  const box = document.getElementById('subStatusBox');
  const list = document.getElementById('plansList');
  try {
    const st = await api('/api/subscription/me');
    let text = 'اشتراک غیرفعال';
    box.className = 'banner warn';
    if (st.hasAccess && st.type === 'admin') { text = 'دسترسی مدیر — نامحدود'; box.className='banner ok'; }
    else if (st.hasAccess && st.type === 'free') { text = 'تماشای رایگان فعال است'; box.className='banner ok'; }
    else if (st.hasAccess && st.type === 'free_trial') { text = 'دوره رایگان تا '+(st.endsAt||'').slice(0,10); box.className='banner trial'; }
    else if (st.hasAccess) { text = 'فعال ('+st.type+') تا '+(st.endsAt||'').slice(0,10); box.className='banner ok'; }
    box.innerHTML = '<div><strong>'+text+'</strong></div>';
    const plans = await api('/api/subscription/plans');
    if (!plans.length) { list.innerHTML = '<div class="empty">در نسخه فعلی، تماشای فیلم‌ها رایگان است. اشتراک GOLD در به‌روزرسانی آینده فعال خواهد شد.</div>'; return; }
    list.innerHTML = plans.map(p => `
      <div class="plan">
        <strong>${esc(p.name)}</strong>
        <div style="color:var(--muted)">${p.duration_days} روز</div>
        <div class="price">${Number(p.price).toLocaleString('fa-IR')} تومان</div>
        <button class="btn" onclick="buyPlan(${p.id})">خرید آزمایشی</button>
      </div>`).join('');
  } catch(e){ list.innerHTML = '<div class="msg err">'+e.message+'</div>'; }
}
async function buyPlan(planId) {
  try {
    const pay = await api('/api/subscription/pay', { method:'POST', body: JSON.stringify({ plan_id: planId }) });
    await api('/api/subscription/verify-mock?authority=' + encodeURIComponent(pay.authority));
    toast('پرداخت موفق — اشتراک فعال شد');
    loadSubscription();
  } catch(e){ toast(e.message); }
}
async function loadSupportTickets() {
  const el = document.getElementById('supportTickets');
  const thread = document.getElementById('supportThread');
  thread.innerHTML = '';
  try {
    const items = await api('/api/me/support/tickets');
    if (!items.length) { el.innerHTML = '<div class="empty">هنوز درخواستی ثبت نکرده‌اید.</div>'; return; }
    el.innerHTML = items.map(t => `<div class="comment"><div class="who">${esc(t.subject)}</div><div class="when">وضعیت: ${esc(t.status)} · ${esc((t.created_at||'').slice(0,16))}</div><button class="btn sm secondary" onclick="openSupportTicket(${t.id})">مشاهده گفتگو</button></div>`).join('');
  } catch(e) { el.innerHTML = '<div class="msg err">'+esc(e.message)+'</div>'; }
}
async function submitSupportTicket() {
  const subject = document.getElementById('supportSubject').value.trim();
  const category = document.getElementById('supportCategory').value;
  const message = document.getElementById('supportMessage').value.trim();
  try {
    await api('/api/me/support/tickets', {method:'POST', body:JSON.stringify({subject,category,message})});
    document.getElementById('supportSubject').value='';
    document.getElementById('supportMessage').value='';
    toast('درخواست شما ثبت شد'); loadSupportTickets();
  } catch(e) { toast(e.message); }
}
async function openSupportTicket(id) {
  const el = document.getElementById('supportThread');
  try {
    const data = await api('/api/me/support/tickets/'+id);
    el.innerHTML = `<div class="profile-card"><h3>${esc(data.ticket.subject)}</h3>${data.messages.map(m=>`<div class="comment"><strong>${m.sender_role==='admin'?'پشتیبانی':'شما'}</strong><div>${esc(m.message)}</div><div class="when">${esc((m.created_at||'').slice(0,16))}</div></div>`).join('')}<textarea id="supportReply" rows="3" maxlength="3000" placeholder="پاسخ شما..."></textarea><button class="btn" onclick="replySupportTicket(${id})">ارسال پیام</button></div>`;
  } catch(e) { el.innerHTML = '<div class="msg err">'+esc(e.message)+'</div>'; }
}
async function replySupportTicket(id) {
  const message = document.getElementById('supportReply').value.trim();
  try { await api('/api/me/support/tickets/'+id+'/messages',{method:'POST',body:JSON.stringify({message})}); toast('پیام ارسال شد'); openSupportTicket(id); }
  catch(e) { toast(e.message); }
}

async function loadProfile() {
  const el = document.getElementById('profileBox');
  try {
    const st = await api('/api/subscription/me');
    el.innerHTML = `
      <div style="font-size:1.1rem;font-weight:800;margin-bottom:8px">${esc(currentUser || 'کاربر')}</div>
      <div style="color:var(--muted);margin-bottom:6px">وضعیت: ${st.hasAccess ? 'فعال' : 'غیرفعال'}</div>
      <div style="color:var(--muted)">نوع: ${esc(st.type || '—')}</div>
      <div style="color:var(--muted);margin-top:4px">انقضا: ${esc((st.endsAt||'—').toString().slice(0,10))}</div>`;
  } catch(e){ el.innerHTML = '<div class="msg err">'+e.message+'</div>'; }
}

document.getElementById('password').addEventListener('keydown', e => { if (e.key==='Enter') doAuth(); });
document.getElementById('username').addEventListener('keydown', e => { if (e.key==='Enter') document.getElementById('password').focus(); });
const savedUser = localStorage.getItem('cp_user');
if (savedUser) document.getElementById('username').value = savedUser;

if (token) {
  api('/api/subscription/me').then(() => { showScreen('main'); switchTab('home'); })
    .catch(() => { token=''; localStorage.removeItem('cp_token'); showScreen('login'); });
} else {
  showScreen('login');
}
