MyBusiness Pro — Offline Business Manager
1) Open index.html in Chrome.
2) Data is saved locally on the device.
3) Use Settings > Backup & Restore regularly.
4) For a real Android APK, this HTML app can be wrapped in an Android WebView project.
