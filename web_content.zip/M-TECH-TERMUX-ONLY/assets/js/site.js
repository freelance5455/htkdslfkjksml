document.addEventListener("DOMContentLoaded",()=>{
const menu=document.querySelector("#menuBtn"),nav=document.querySelector("#nav");
if(menu&&nav)menu.onclick=()=>nav.classList.toggle("open");
const search=document.querySelector("#catalogSearch"),catalog=document.querySelector("#catalog"),meta=document.querySelector("#catalogMeta"),more=document.querySelector("#loadMore");
if(!catalog)return;
const file=location.pathname.split("/").pop();
const key=file==="tools.html"?"tools":file==="libraries.html"?"libraries":"repos";
const data=(window.MTECH_DATA&&window.MTECH_DATA[key])||[];
let count=24,query="";
const render=()=>{
 let rows=data.filter(x=>JSON.stringify(x).toLowerCase().includes(query.toLowerCase()));
 const show=rows.slice(0,count);
 meta.innerHTML=`<strong>${rows.length}</strong> نتيجة · يعرض ${show.length} الآن`;
 catalog.innerHTML=show.map(x=>{
  const name=x.name||"",desc=x.description||x.desc||"",cat=x.category||x.language||"مرجع",url=x.url||"#";
  const type=x.type?`<span class="type">${x.type}</span>`:"";
  const warning=file==="tools.html"&&x.type==="مرجع تعليمي"?`<div class="warn">مدخل تعليمي وليس اسم حزمة مؤكدة.</div>`:"";
  return `<article class="catalog-card"><small>${cat}</small><h3>${name}</h3><p>${desc}</p>${type}${warning}<div><a href="${url}" target="_blank" rel="noopener">المصدر / البحث ↗</a></div></article>`;
 }).join("");
 more.style.display=show.length<rows.length?"inline-flex":"none";
};
if(search)search.oninput=e=>{query=e.target.value;count=24;render();};
more.onclick=()=>{count+=24;render();};
render();
});