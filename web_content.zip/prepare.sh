#!/bin/bash
# Baixa o three.js para dentro do app (funciona offline) e troca o link do CDN
set -e
curl -fsSL -o www/three.min.js https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
sed -i 's#https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js#three.min.js#' www/index.html
grep -q 'src="three.min.js"' www/index.html && echo "OK: three.js local"
