'use strict';
// KORA X v1.2.0 — server-side API gateway. Secrets stay in .env and never reach the browser.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { URL } = require('node:url');
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const scrypt = promisify(crypto.scrypt);
const ROOT = __dirname;

function loadDotEnv() {
  const file = path.join(ROOT, '.env');
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const s = line.trim(); if (!s || s.startsWith('#')) continue;
    const i = s.indexOf('='); if (i < 1) continue;
    const k = s.slice(0, i).trim(); let v = s.slice(i + 1).trim();
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (process.env[k] === undefined) process.env[k] = v;
  }
}
loadDotEnv();

const PORT = Number(process.env.PORT || 3000);
const FOOTBALL_KEY = process.env.API_FOOTBALL_KEY || '';
const NEWS_KEY = process.env.NEWSDATA_API_KEY || '';
const CORS_ORIGIN = process.env.CORS_ORIGIN || 'same-origin';
const CACHE = new Map();
const footballMinute = [];
const ipBuckets = new Map();
const commentFile = path.join(ROOT, 'data', 'comments.json');
const userFile = path.join(ROOT, 'data', 'users.json');
const contestFile = path.join(ROOT, 'data', 'contest.json');
const sessions = new Map();
const sessionCookie = 'kora_x_session';
let footballDaily = { day: new Date().toISOString().slice(0, 10), count: 0 };
const SOURCE_STATE = { footballConnected:false, newsConnected:false, footballLastSuccess:null, newsLastSuccess:null, footballLastError:null, newsLastError:null };

function cacheGet(key) { const x = CACHE.get(key); if (!x || x.exp < Date.now()) { CACHE.delete(key); return null; } return x.value; }
function cacheSet(key, value, ms) { CACHE.set(key, { value, exp: Date.now() + ms }); }
function ttl(endpoint, q) {
  if (endpoint === 'fixtures' && q.live === 'all') return 60_000;
  if (endpoint === 'fixtures' && q.ids) return 90_000;
  if (endpoint === 'fixtures' && q.id) return 90_000;
  if (endpoint === 'fixtures') return 3 * 60_000;
  if (endpoint.startsWith('fixtures/')) return 2 * 60_000;
  if (endpoint === 'injuries') return 4 * 60 * 60_000;
  if (endpoint === 'leagues' || endpoint === 'teams' || endpoint.startsWith('players/') || endpoint === 'coachs') return 12 * 60 * 60_000;
  return 30 * 60_000;
}
function qsOf(q) { const p = new URLSearchParams(); for (const [k,v] of Object.entries(q || {})) if (v !== undefined && v !== null && String(v).trim() !== '') p.set(k, String(v).trim()); return p.toString(); }
function httpError(status, message) { const e = new Error(message); e.status = status; return e; }
function dayStamp() { return new Date().toISOString().slice(0, 10); }
async function takeFootballSlot() {
  const now = Date.now();
  if (footballDaily.day !== dayStamp()) footballDaily = { day: dayStamp(), count: 0 };
  while (footballMinute.length && now - footballMinute[0] >= 60_000) footballMinute.shift();
  // A conservative ceiling below the advertised free quota protects room for user-initiated actions.
  const configuredLimit = Number(process.env.FOOTBALL_DAILY_LIMIT || 92);
  const providerRemaining = Number(process.env.FOOTBALL_PROVIDER_REMAINING);
  if (footballDaily.count >= configuredLimit || (Number.isFinite(providerRemaining) && providerRemaining <= 2)) throw httpError(429, 'اقتربت حصة مصدر المباريات اليومية من النفاد. سيتم إيقاف الطلبات مؤقتًا لحماية الخدمة.');
  if (footballMinute.length >= 8) throw httpError(429, 'طلبات المباريات كثيرة في هذه اللحظة. انتظر قليلًا ثم أعد المحاولة.');
  footballMinute.push(now); footballDaily.count++;
}
async function footballGet(endpoint, params = {}) {
  if (!FOOTBALL_KEY) throw httpError(503, 'مصدر بيانات المباريات غير مضبوط على الخادم.');
  const query = qsOf(params); const key = `football:${endpoint}?${query}`;
  const cached = cacheGet(key); if (cached) return cached;
  await takeFootballSlot();
  const url = `https://v3.football.api-sports.io/${endpoint}${query ? `?${query}` : ''}`;
  let response; try { response = await fetch(url, { headers: { 'x-apisports-key': FOOTBALL_KEY, Accept: 'application/json' }, signal: AbortSignal.timeout(20_000) }); } catch (err) { SOURCE_STATE.footballConnected=false; SOURCE_STATE.footballLastError=err?.cause?.code || err?.message || 'network'; throw httpError(502, 'تعذر الوصول إلى مزود بيانات المباريات من الخادم. تحقق من اتصال الاستضافة بالإنترنت ثم أعد المحاولة.'); }
  const body = await response.json().catch(() => null);
  if (!response.ok) throw httpError(response.status, body?.errors ? JSON.stringify(body.errors) : `تعذر جلب بيانات المباريات (${response.status}).`);
  if (!body || !Array.isArray(body.response)) throw httpError(502, 'استجابة مصدر المباريات غير مكتملة.');
  if (body.errors && Object.keys(body.errors).length) { SOURCE_STATE.footballConnected=false; SOURCE_STATE.footballLastError=JSON.stringify(body.errors); throw httpError(502, JSON.stringify(body.errors)); }
  SOURCE_STATE.footballConnected=true; SOURCE_STATE.footballLastSuccess=new Date().toISOString(); SOURCE_STATE.footballLastError=null;
  const providerRemaining = Number(response.headers.get('x-ratelimit-requests-remaining'));
  if (Number.isFinite(providerRemaining) && providerRemaining >= 0) { process.env.FOOTBALL_PROVIDER_REMAINING = String(providerRemaining); }
  cacheSet(key, body, ttl(endpoint, params)); return body;
}
async function newsGet(params = {}) {
  if (!NEWS_KEY) throw httpError(503, 'مصدر الأخبار غير مضبوط على الخادم.');
  const p = new URLSearchParams({ apikey: NEWS_KEY, language: 'ar', category: 'sports', size: '10', removeduplicate: '1', ...params });
  const key = `news:${p.toString().replace(NEWS_KEY, 'hidden')}`; const cached = cacheGet(key); if (cached) return cached;
  let response; try { response = await fetch(`https://newsdata.io/api/1/latest?${p}`, { signal: AbortSignal.timeout(20_000) }); } catch (err) { SOURCE_STATE.newsConnected=false; SOURCE_STATE.newsLastError=err?.cause?.code || err?.message || 'network'; throw httpError(502, 'تعذر الوصول إلى مزود الأخبار من الخادم. تحقق من اتصال الاستضافة بالإنترنت ثم أعد المحاولة.'); }
  const body = await response.json().catch(() => null);
  if (!response.ok || body?.status === 'error') { SOURCE_STATE.newsConnected=false; SOURCE_STATE.newsLastError=body?.results?.message || body?.message || `HTTP ${response.status}`; throw httpError(response.status || 502, SOURCE_STATE.newsLastError || 'تعذر جلب الأخبار من المصدر.'); }
  SOURCE_STATE.newsConnected=true; SOURCE_STATE.newsLastSuccess=new Date().toISOString(); SOURCE_STATE.newsLastError=null;
  const seen = new Set();
  const results = (Array.isArray(body?.results) ? body.results : []).filter(a => {
    if (!a || a.duplicate === true || !a.title || !a.link) return false;
    const id = String(a.article_id || a.link || a.title).toLowerCase();
    if (seen.has(id)) return false; seen.add(id); return true;
  }).map(a => ({
    id: a.article_id || a.link, title: a.title, description: a.description || '', content: a.content || '',
    image: a.image_url || '', source: a.source_name || a.source_id || 'مصدر إخباري', sourceIcon: a.source_icon || '',
    sourceUrl: a.source_url || '', date: a.pubDate || '', url: a.link, language: a.language || 'ar',
    category: Array.isArray(a.category) ? a.category : [], country: Array.isArray(a.country) ? a.country : [],
    video: a.video_url || '', duplicate: false
  }));
  const normalized = { status: body?.status || 'success', totalResults: results.length, nextPage: body?.nextPage || null, results };
  cacheSet(key, normalized, 45 * 60_000); return normalized;
}
function safeCommentFile() {
  try { fs.mkdirSync(path.dirname(commentFile), { recursive: true }); if (!fs.existsSync(commentFile)) fs.writeFileSync(commentFile, '{}'); return JSON.parse(fs.readFileSync(commentFile, 'utf8') || '{}'); }
  catch { return {}; }
}
function writeComments(data) { fs.mkdirSync(path.dirname(commentFile), { recursive: true }); fs.writeFileSync(commentFile, JSON.stringify(data, null, 2), 'utf8'); }
function rateLimit(req, key, max, windowMs) {
  const ip = req.socket.remoteAddress || 'unknown'; const id = `${key}:${ip}`; const now = Date.now();
  const items = (ipBuckets.get(id) || []).filter(t => now - t < windowMs);
  if (items.length >= max) throw httpError(429, 'تجاوزت حد الطلبات المسموح. حاول بعد قليل.');
  items.push(now); ipBuckets.set(id, items);
}
async function readJson(req, max = 8192) {
  let raw = ''; for await (const chunk of req) { raw += chunk; if (raw.length > max) throw httpError(413, 'حجم الطلب أكبر من المسموح.'); }
  try { return JSON.parse(raw || '{}'); } catch { throw httpError(400, 'صيغة البيانات غير صحيحة.'); }
}
function send(res, status, body) { const data = JSON.stringify(body); res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(data); }
function intParam(q, key, fallback) { const n = Number(q.get(key)); return Number.isInteger(n) && n > 0 ? n : fallback; }


function readDb(file, fallback) {
  try { fs.mkdirSync(path.dirname(file), { recursive:true }); if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(fallback, null, 2)); return JSON.parse(fs.readFileSync(file,'utf8') || JSON.stringify(fallback)); }
  catch { return structuredClone(fallback); }
}
function writeDb(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive:true });
  const tmp = file + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(value, null, 2), { mode:0o600 }); fs.renameSync(tmp,file);
}
function cookieValue(req, name) {
  const raw = String(req.headers.cookie || '');
  for (const part of raw.split(';')) { const i=part.indexOf('='); if(i<0) continue; if(part.slice(0,i).trim()===name) return decodeURIComponent(part.slice(i+1).trim()); }
  return '';
}
function currentUser(req) {
  const token=cookieValue(req,sessionCookie), session=sessions.get(token);
  if(!session || session.expires<Date.now()){ if(token)sessions.delete(token); return null; }
  const db=readDb(userFile,{users:[]}); const user=db.users.find(x=>x.id===session.userId);
  return user ? {id:user.id,email:user.email,displayName:user.displayName,createdAt:user.createdAt} : null;
}
function setSession(req,res,userId) {
  const token=crypto.randomBytes(32).toString('base64url');
  sessions.set(token,{userId,expires:Date.now()+14*24*60*60*1000});
  const secure=Boolean(req.socket.encrypted || req.headers['x-forwarded-proto']==='https');
  res.setHeader('Set-Cookie',`${sessionCookie}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=1209600${secure?'; Secure':''}`);
}
function clearSession(req,res) {
  const token=cookieValue(req,sessionCookie); if(token)sessions.delete(token);
  const secure=Boolean(req.socket.encrypted || req.headers['x-forwarded-proto']==='https');
  res.setHeader('Set-Cookie',`${sessionCookie}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure?'; Secure':''}`);
}
function scoreContestPrediction(pred, homeGoals, awayGoals) {
  const actualOutcome=homeGoals===awayGoals?'draw':homeGoals>awayGoals?'home':'away';
  const exact=homeGoals===pred.homeGoals && awayGoals===pred.awayGoals;
  const outcomePoints=exact?10:(pred.outcome===actualOutcome?3:0);
  const actualTotal=homeGoals+awayGoals;
  const totalGoalsPoints=(pred.totalGoals==='over' && actualTotal>2.5)||(pred.totalGoals==='under' && actualTotal<2.5)?4:0;
  const bothTeams=homeGoals>0 && awayGoals>0;
  const bothScorePoints=(pred.bothScore==='yes' && bothTeams)||(pred.bothScore==='no' && !bothTeams)?3:0;
  return {points:outcomePoints+totalGoalsPoints+bothScorePoints, breakdown:{exactOrResult:outcomePoints,totalGoals:totalGoalsPoints,bothScore:bothScorePoints}};
}
async function settleContestRows() {
  const db=readDb(contestFile,{predictions:[]});
  const pending=(db.predictions||[]).filter(x=>x.state==='pending' && Date.parse(x.kickoff||'')<Date.now());
  if(!pending.length || !FOOTBALL_KEY) return db;
  const cairoToday=new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Cairo'}).format(new Date());
  const dates=[...new Set(pending.map(x=>String(x.kickoff||'').slice(0,10)).filter(Boolean))].filter(d=>d<=cairoToday).sort().slice(-3);
  for(const date of dates){
    try{
      const fixtures=await footballGet('fixtures',{date,timezone:'Africa/Cairo'});
      const byId=new Map((fixtures.response||[]).map(f=>[String(f.fixture?.id),f]));
      for(const p of pending.filter(x=>String(x.kickoff||'').slice(0,10)===date)){
        const f=byId.get(String(p.fixtureId)); const st=f?.fixture?.status?.short;
        if(!f || !['FT','AET','PEN'].includes(st)) continue;
        const hg=Number(f.goals?.home), ag=Number(f.goals?.away); if(!Number.isFinite(hg)||!Number.isFinite(ag))continue;
        const result=scoreContestPrediction(p,hg,ag); p.state='settled';p.actualHomeGoals=hg;p.actualAwayGoals=ag;p.points=result.points;p.breakdown=result.breakdown;p.settledAt=new Date().toISOString();
      }
    }catch(err){ SOURCE_STATE.footballLastError=err.message; }
  }
  writeDb(contestFile,db); return db;
}
function contestLeaderboard(db) {
  const acc=new Map();
  for(const p of db.predictions||[]){let u=acc.get(p.userId);if(!u){u={userId:p.userId,name:p.displayName,points:0,settled:0,predictions:0};acc.set(p.userId,u);}u.predictions++;if(p.state==='settled'){u.points+=Number(p.points||0);u.settled++;}}
  return [...acc.values()].sort((a,b)=>b.points-a.points||b.settled-a.settled||a.name.localeCompare(b.name)).map((x,i)=>({...x,rank:i+1}));
}

async function handleApi(req, url, res) {
  const p = url.pathname, q = url.searchParams;
  if (p === '/api/auth/me' && req.method === 'GET') return send(res,200,{user:currentUser(req)});
  if (p === '/api/auth/register' && req.method === 'POST') {
    rateLimit(req,'auth-register',8,60*60_000); const body=await readJson(req);
    const displayName=String(body.displayName||'').trim().slice(0,32), email=String(body.email||'').trim().toLowerCase(), password=String(body.password||'');
    if(displayName.length<2)throw httpError(400,'اكتب اسمًا من حرفين على الأقل.');
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw httpError(400,'أدخل بريدًا إلكترونيًا صحيحًا.');
    if(password.length<8 || password.length>128)throw httpError(400,'كلمة المرور يجب أن تكون 8 أحرف على الأقل.');
    const db=readDb(userFile,{users:[]}); if(db.users.some(x=>x.email===email))throw httpError(409,'هذا البريد مسجل بالفعل. سجّل الدخول بدلًا من إنشاء حساب جديد.');
    const salt=crypto.randomBytes(16).toString('hex'); const hash=(await scrypt(password,salt,64)).toString('hex');
    const user={id:crypto.randomUUID(),email,displayName,salt,hash,createdAt:new Date().toISOString()}; db.users.push(user); writeDb(userFile,db); setSession(req,res,user.id);
    return send(res,201,{user:{id:user.id,email:user.email,displayName:user.displayName,createdAt:user.createdAt}});
  }
  if (p === '/api/auth/login' && req.method === 'POST') {
    rateLimit(req,'auth-login',12,15*60_000); const body=await readJson(req); const email=String(body.email||'').trim().toLowerCase(), password=String(body.password||'');
    const db=readDb(userFile,{users:[]}); const user=db.users.find(x=>x.email===email);
    if(!user || !user.salt || !user.hash)throw httpError(401,'البريد أو كلمة المرور غير صحيحة.');
    const hash=await scrypt(password,user.salt,64); const expected=Buffer.from(user.hash,'hex');
    if(expected.length!==hash.length || !crypto.timingSafeEqual(expected,hash))throw httpError(401,'البريد أو كلمة المرور غير صحيحة.');
    setSession(req,res,user.id); return send(res,200,{user:{id:user.id,email:user.email,displayName:user.displayName,createdAt:user.createdAt}});
  }
  if (p === '/api/auth/logout' && req.method === 'POST') { clearSession(req,res); return send(res,200,{ok:true}); }
  if (p === '/api/contest/my' && req.method === 'GET') {
    const user=currentUser(req); if(!user)throw httpError(401,'سجّل الدخول أولًا للانضمام إلى المسابقة.');
    const db=await settleContestRows(); const rows=(db.predictions||[]).filter(x=>x.userId===user.id).sort((a,b)=>Date.parse(b.createdAt)-Date.parse(a.createdAt));
    return send(res,200,{predictions:rows,points:rows.filter(x=>x.state==='settled').reduce((s,x)=>s+Number(x.points||0),0),user});
  }
  if (p === '/api/contest/leaderboard' && req.method === 'GET') {
    const db=await settleContestRows(); return send(res,200,{leaderboard:contestLeaderboard(db).slice(0,50),prizes:[{rank:1,months:3},{rank:2,months:2},{rank:3,months:1}]});
  }
  if (p === '/api/contest/predictions' && req.method === 'POST') {
    rateLimit(req,'contest-prediction',40,60*60_000); const user=currentUser(req); if(!user)throw httpError(401,'سجّل الدخول أولًا للانضمام إلى المسابقة.');
    const body=await readJson(req); const fixtureId=String(body.fixtureId||'');
    const hg=Number(body.homeGoals), ag=Number(body.awayGoals), totalGoals=String(body.totalGoals||''), bothScore=String(body.bothScore||'');
    if(!/^\d{1,12}$/.test(fixtureId) || !Number.isInteger(hg)||!Number.isInteger(ag)||hg<0||ag<0||hg>20||ag>20)throw httpError(400,'بيانات التوقع غير صحيحة.');
    if(!['over','under'].includes(totalGoals)||!['yes','no'].includes(bothScore))throw httpError(400,'أكمل كل اختيارات التوقع.');
    const fixtureBody=await footballGet('fixtures',{id:fixtureId,timezone:'Africa/Cairo'}); const f=fixtureBody.response?.[0];
    if(!f?.fixture?.id)throw httpError(404,'لم نعثر على المباراة في مصدر النتائج.');
    if(!['NS','TBD','PST'].includes(f.fixture.status?.short))throw httpError(409,'انتهى وقت تسجيل التوقع لهذه المباراة.');
    const kickoff=f.fixture.date; if(Date.parse(kickoff)<=Date.now())throw httpError(409,'بدأت المباراة؛ لا يمكن تسجيل توقع جديد.');
    const outcome=hg===ag?'draw':hg>ag?'home':'away';
    const db=readDb(contestFile,{predictions:[]}); const existing=db.predictions.find(x=>x.userId===user.id&&String(x.fixtureId)===fixtureId);
    const record={id:existing?.id||crypto.randomUUID(),userId:user.id,displayName:user.displayName,fixtureId,kickoff,fixtureLabel:`${f.teams?.home?.name||'الفريق الأول'} × ${f.teams?.away?.name||'الفريق الثاني'}`,homeTeam:f.teams?.home?.name||'',awayTeam:f.teams?.away?.name||'',league:f.league?.name||'',homeGoals:hg,awayGoals:ag,outcome,totalGoals,bothScore,state:'pending',points:0,createdAt:existing?.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()};
    if(existing)Object.assign(existing,record);else db.predictions.push(record);writeDb(contestFile,db);
    return send(res,201,{prediction:record,message:'تم تسجيل توقعك في المسابقة.'});
  }
  if (req.method === 'GET' && p === '/api/health') return send(res, 200, { ok: true, footballConfigured: Boolean(FOOTBALL_KEY), newsConfigured: Boolean(NEWS_KEY), sources: SOURCE_STATE, now: new Date().toISOString() });
  if (req.method === 'GET' && p === '/api/fixtures') {
    const params = { timezone: 'Africa/Cairo' };
    if (q.get('live') === 'all') params.live = 'all';
    else if (q.has('last') || q.has('next') || q.has('from') || q.has('to')) { /* range/history query */ }
    else params.date = q.get('date') || new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Cairo' }).format(new Date());
    for (const k of ['league','season','team','status','last','next','from','to','round','venue']) if (q.has(k)) params[k] = q.get(k);
    return send(res, 200, await footballGet('fixtures', params));
  }
  if (req.method === 'GET' && p === '/api/leagues') return send(res, 200, await footballGet('leagues', { search:q.get('search'), country:q.get('country'), season:q.get('season') || new Date().getFullYear(), current:q.get('current') || 'true', id:q.get('id') }));
  if (req.method === 'GET' && p === '/api/standings') { if (!q.get('league') || !q.get('season')) throw httpError(400, 'حدد البطولة والموسم.'); return send(res, 200, await footballGet('standings', { league:q.get('league'), season:q.get('season'), team:q.get('team') })); }
  if (req.method === 'GET' && p === '/api/teams') {
    const params = {}; for (const k of ['search','id','country','league','season','code','venue']) if (q.has(k)) params[k] = q.get(k);
    if (!Object.keys(params).length) throw httpError(400, 'أدخل اسم الفريق للبحث.'); return send(res, 200, await footballGet('teams', params));
  }
  if (req.method === 'GET' && p === '/api/teams/seasons') { if (!q.get('team')) throw httpError(400, 'حدد الفريق.'); return send(res, 200, await footballGet('teams/seasons', { team:q.get('team') })); }
  if (req.method === 'GET' && p === '/api/squad') { if (!q.get('team')) throw httpError(400, 'حدد الفريق.'); return send(res, 200, await footballGet('players/squads', { team:q.get('team') })); }
  if (req.method === 'GET' && p === '/api/team-stats') { for (const k of ['team','league','season']) if (!q.get(k)) throw httpError(400, 'بيانات إحصائيات الفريق غير مكتملة.'); return send(res, 200, await footballGet('teams/statistics', { team:q.get('team'), league:q.get('league'), season:q.get('season') })); }
  if (req.method === 'GET' && p === '/api/coaches') { if (!q.get('team') && !q.get('search')) throw httpError(400, 'حدد الفريق أو اسم المدرب.'); return send(res, 200, await footballGet('coachs', { team:q.get('team'), search:q.get('search'), id:q.get('id') })); }
  if (req.method === 'GET' && p === '/api/players') {
    const params = {}; for (const k of ['search','id','team','league','season','page']) if (q.has(k)) params[k] = q.get(k);
    if (!params.search && !params.id && !params.team) throw httpError(400, 'أدخل اسم اللاعب أو الفريق.');
    if (params.search && params.search.length < 4) throw httpError(400, 'اكتب أربعة أحرف على الأقل للبحث عن اللاعب.');
    params.season = params.season || new Date().getFullYear(); return send(res, 200, await footballGet('players', params));
  }
  if (req.method === 'GET' && p === '/api/player-teams') { if (!q.get('player')) throw httpError(400, 'حدد اللاعب.'); return send(res, 200, await footballGet('players/teams', { player:q.get('player') })); }
  if (req.method === 'GET' && p === '/api/topscorers') { if (!q.get('league') || !q.get('season')) throw httpError(400, 'حدد البطولة والموسم.'); return send(res, 200, await footballGet('players/topscorers', { league:q.get('league'), season:q.get('season') })); }
  if (req.method === 'GET' && p === '/api/topassists') { if (!q.get('league') || !q.get('season')) throw httpError(400, 'حدد البطولة والموسم.'); return send(res, 200, await footballGet('players/topassists', { league:q.get('league'), season:q.get('season') })); }
  if (req.method === 'GET' && p === '/api/topcards') { if (!q.get('league') || !q.get('season')) throw httpError(400, 'حدد البطولة والموسم.'); return send(res, 200, await footballGet('players/topyellowcards', { league:q.get('league'), season:q.get('season') })); }
  if (req.method === 'GET' && p === '/api/transfers') { if (!q.get('team') && !q.get('player')) throw httpError(400, 'حدد الفريق أو اللاعب.'); return send(res, 200, await footballGet('transfers', { team:q.get('team'), player:q.get('player') })); }
  if (req.method === 'GET' && p === '/api/injuries') { const params={}; for (const k of ['league','season','team','player','fixture','date','ids']) if(q.has(k)) params[k]=q.get(k); if(!Object.keys(params).length) throw httpError(400,'حدد نطاق الإصابات.'); return send(res,200,await footballGet('injuries',params)); }
  if (req.method === 'GET' && p === '/api/predictions') { if (!q.get('fixture')) throw httpError(400,'حدد المباراة.'); return send(res,200,await footballGet('predictions',{fixture:q.get('fixture')})); }
  if (req.method === 'GET' && p === '/api/h2h') { if (!q.get('teams')) throw httpError(400,'حدد الفريقين.'); return send(res,200,await footballGet('fixtures/headtohead',{h2h:q.get('teams'),last:q.get('last')||10,timezone:'Africa/Cairo'})); }
  if (req.method === 'GET' && p === '/api/rounds') { if (!q.get('league') || !q.get('season')) throw httpError(400,'حدد البطولة والموسم.'); return send(res,200,await footballGet('fixtures/rounds',{league:q.get('league'),season:q.get('season'),current:q.get('current')||'true',dates:'true'})); }
  if (req.method === 'GET' && p === '/api/trophies') { if (!q.get('player') && !q.get('coach')) throw httpError(400,'حدد اللاعب أو المدرب.'); return send(res,200,await footballGet('trophies',{player:q.get('player'),coach:q.get('coach')})); }
  if (req.method === 'GET' && p === '/api/sidelined') { if (!q.get('player') && !q.get('coach')) throw httpError(400,'حدد اللاعب أو المدرب.'); return send(res,200,await footballGet('sidelined',{player:q.get('player'),coach:q.get('coach')})); }
  const fixtureMatch = p.match(/^\/api\/fixture\/(\d+)$/);
  if (req.method === 'GET' && fixtureMatch) {
    const id = fixtureMatch[1];
    // Prefer the combined fixtures ids response to minimize API calls.
    const combined = await footballGet('fixtures', { ids:id, timezone:'Africa/Cairo' });
    const row = combined.response?.[0] || {};
    if (row.events || row.lineups || row.statistics || row.players) return send(res,200,{ details:[row], events:row.events||[], lineups:row.lineups||[], statistics:row.statistics||[], players:row.players||[] });
    const [details,events,lineups,statistics,players] = await Promise.all([
      footballGet('fixtures',{id,timezone:'Africa/Cairo'}), footballGet('fixtures/events',{fixture:id}),
      footballGet('fixtures/lineups',{fixture:id}), footballGet('fixtures/statistics',{fixture:id}), footballGet('fixtures/players',{fixture:id})
    ]);
    return send(res,200,{details:details.response,events:events.response,lineups:lineups.response,statistics:statistics.response,players:players.response});
  }
  if (req.method === 'GET' && p === '/api/news') {
    const scope=q.get('scope')||'all'; const next=q.get('page'); const params={};
    if (next) params.page=next;
    if (scope==='egypt') { params.country='eg'; params.q='كرة القدم OR الأهلي OR الزمالك OR منتخب مصر'; }
    else if (scope==='arab') {
      // Free/basic plans allow up to five countries per request; split Arab coverage cleanly.
      const [gulf,maghreb] = await Promise.all([
        newsGet({ country:'sa,eg,ae,qa,ma', q:'كرة القدم OR الدوري OR المنتخب', ...(next?{page:next}:{}) }),
        newsGet({ country:'dz,tn,iq,jo,kw', q:'كرة القدم OR الدوري OR المنتخب', ...(next?{page:next}:{}) })
      ]);
      const seen = new Set(); const merged = [...(gulf.results||[]),...(maghreb.results||[])].filter(a=>{const k=String(a.id||a.url||a.title).toLowerCase();if(seen.has(k))return false;seen.add(k);return true;}).sort((a,b)=>Date.parse(b.date||0)-Date.parse(a.date||0));
      return send(res,200,{status:'success',totalResults:merged.length,nextPage:gulf.nextPage||maghreb.nextPage||null,results:merged});
    }
    else if (scope==='transfers') params.q='انتقالات OR انتقال OR صفقة OR إعارة OR تجديد عقد OR transfer';
    else if (scope==='leagues') params.q='الدوريات OR الدوري OR ترتيب الدوري OR جدول الدوري OR league';
    else if (scope==='competitions') params.q='بطولة OR كأس OR دوري أبطال أوروبا OR كأس العالم OR tournament';
    else if (scope==='clubs') params.q='نادي OR أندية OR ريال مدريد OR برشلونة OR الأهلي OR الزمالك OR ليفربول';
    else if (scope==='national') params.q='منتخب OR المنتخبات OR تصفيات OR كأس أمم إفريقيا';
    else if (scope==='league') { const name=(q.get('name')||'').trim().slice(0,80); if (!name) throw httpError(400,'حدد اسم الدوري.'); params.q=`${name} OR كرة القدم ${name}`; }
    else if (scope==='club') { const name=(q.get('name')||'').trim().slice(0,80); if (!name) throw httpError(400,'حدد اسم النادي أو البطولة.'); params.q=`${name} OR كرة القدم ${name}`; }
    else if (scope==='world') params.q='كرة القدم OR دوري أبطال أوروبا OR ريال مدريد OR برشلونة OR كأس العالم';
    else params.q='كرة القدم OR الدوري OR انتقالات OR دوري أبطال أوروبا OR منتخب';
    return send(res,200,await newsGet(params));
  }
  const commentsMatch=p.match(/^\/api\/articles\/([A-Za-z0-9_:%.-]+)\/comments$/);
  if (commentsMatch && req.method==='GET') { const id=decodeURIComponent(commentsMatch[1]); const db=safeCommentFile(); return send(res,200,{comments:Array.isArray(db[id])?db[id]:[]}); }
  if (commentsMatch && req.method==='POST') {
    rateLimit(req,'comments',4,60_000); const id=decodeURIComponent(commentsMatch[1]); const body=await readJson(req);
    const name=String(body.name||'مشجع KORA X').trim().slice(0,28); const text=String(body.text||'').trim();
    if(!text || text.length>500) throw httpError(400,'اكتب تعليقًا من حرف واحد إلى 500 حرف.');
    const db=safeCommentFile(); const rows=Array.isArray(db[id])?db[id]:[];
    const comment={id:require('node:crypto').randomUUID(),name,text,createdAt:new Date().toISOString()}; rows.push(comment); db[id]=rows.slice(-200); writeComments(db);
    return send(res,201,{comment});
  }
  return send(res,404,{error:'المسار غير موجود.'});
}

const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.webmanifest':'application/manifest+json','.png':'image/png','.ico':'image/x-icon'};
const STATIC=new Set(['/','/index.html','/manifest.webmanifest','/icon.svg','/icon-192.png','/icon-512.png','/sw.js']);
function serveStatic(url,res){const p=url.pathname==='/'?'/index.html':url.pathname;if(!STATIC.has(p))return send(res,404,{error:'الملف غير موجود.'});const file=path.join(ROOT,p==='/'?'index.html':p.slice(1));fs.readFile(file,(err,data)=>{if(err)return send(res,404,{error:'الملف غير موجود.'});res.writeHead(200,{'Content-Type':MIME[path.extname(file)]||'application/octet-stream','Cache-Control':p==='/index.html'?'no-cache':'public, max-age=3600','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin'});res.end(data);});}
const server=http.createServer(async(req,res)=>{
  if(CORS_ORIGIN!=='same-origin'){res.setHeader('Access-Control-Allow-Origin',CORS_ORIGIN);res.setHeader('Vary','Origin');}
  res.setHeader('X-Frame-Options','DENY'); res.setHeader('X-Content-Type-Options','nosniff');
  if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type,Accept'});return res.end();}
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  try{if(url.pathname.startsWith('/api/'))return await handleApi(req,url,res);if(req.method!=='GET')return send(res,405,{error:'الطريقة غير مدعومة.'});serveStatic(url,res);}
  catch(e){send(res,Number(e.status)||500,{error:e.message||'حدث خطأ غير متوقع.'});}
});
server.listen(PORT,()=>{console.log(`KORA X v1.4.0 listening on port ${PORT}`);console.log(`Football source: ${FOOTBALL_KEY?'configured':'missing'} | News source: ${NEWS_KEY?'configured':'missing'}`);});
