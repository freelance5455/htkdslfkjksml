Monee v1.1.33 — AndroidX Seamless Splash

- Uses AndroidX core-splashscreen for the mandatory Android launch frame.
- Mandatory system frame: mint background only; no standalone app logo.
- System splash exits immediately after the Activity can draw.
- Full-screen Cute Soft B remains the visible branded splash.
- Inner Monee UI, fonts, data and finance logic are unchanged.
