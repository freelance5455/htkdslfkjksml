Monee v1.1.34
- System splash icon replaced with a real transparent 288x288 PNG.
- Stronger mint launch background to visually merge into Cute Soft splash.
- System splash exit remains immediate with zero icon animation.
- Inner Monee UI/data logic unchanged.
