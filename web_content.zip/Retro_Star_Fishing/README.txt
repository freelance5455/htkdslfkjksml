RETRO STAR FISHING — PROTOTIPE GAME 2D

Cara main di Android:
1. Ekstrak Retro_Star_Fishing.zip.
2. Buka index.html dengan Chrome/browser.
3. Tekan LEMPAR PANCING untuk menangkap ikan.
4. Jual ikan untuk mendapatkan koin.
5. Beli rod yang lebih bagus untuk menaikkan peluang ikan langka.
6. Kunjungi 3 pulau yang berbeda.

Fitur:
- Visual pixel-art canvas
- 3 pulau
- 7 tingkat kelangkaan: Common, Uncommon, Rare, Epic, Legendary, Mythic, Secret
- 5 rod dengan bonus luck
- Koleksi ikan, jual ikan, koin
- Penyimpanan progress pada browser melalui localStorage
- Tampilan responsif untuk layar HP

Catatan:
Ini prototipe HTML5 mandiri. Progress tersimpan pada browser/perangkat yang sama.
