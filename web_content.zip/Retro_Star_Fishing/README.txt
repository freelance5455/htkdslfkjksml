RETRO STAR FISHING 2D — UPDATE

Cara main di Android:
1. Ekstrak ZIP ini jika diperlukan.
2. Buka index.html dengan browser (Chrome disarankan).
3. Game berjalan offline setelah file terbuka.
4. Progress disimpan di penyimpanan browser perangkat yang sama.
5. Gunakan menu browser > Tambahkan ke layar utama untuk akses cepat.

Fitur update:
- Favorite ikan; ikan Favorite tidak ikut terjual.
- AFK otomatis setiap 7 detik selama halaman tetap terbuka.
- 9 pulau dan fitur kapal/berlayar.
- 7 rod toko: Starter, Gold, Streampink, Artes, Manvis, Arcsoul, Dark & Light.
- ArkFaultes Rod dan Azrealic Rod hanya bisa dibuka lewat misi.
- 500 nama-varian ikan: 59 Common, 78 Uncommon, 123 Rare, 87 Epic, 75 Legendary, 36 Mythic, 34 Secret, 6 Forgotten, 2 Event.
- Gacha, Potion Luck/EXP, Random Event, Fish Limited Hunt.
- Level/EXP, achievement dan hadiah.

Catatan: Ini prototipe web 2D offline, bukan APK Android native. AFK membutuhkan halaman tetap terbuka. Simpanan browser dapat hilang jika data browser dihapus.
