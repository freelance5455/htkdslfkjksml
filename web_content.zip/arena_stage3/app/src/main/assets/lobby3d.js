/* Arena Stars – 3D-Lobby: Welten (Hintergründe), 3D-Requisiten, Partikel, Kamera, Figur-Anzeige */
(function(){
'use strict';
const A=window.A3D,G=A.geo,P=A.part;
const PI=Math.PI;
const SL=G.sphereL,CL=G.cylL,KL=G.coneL,BX=G.box;
const E={emissive:true,outline:false};
function rnd(seed){let s=seed>>>0||1;return()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296}}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}

/* ---------- 3D-Requisiten ---------- */
const PROPS={
 pine:(c1,c2)=>[P(CL,'#6b4a2b',[0,.4,0],[.12,.8,.12]),P(KL,c1,[0,1.1,0],[.7,.9,.7]),P(KL,c1,[0,1.6,0],[.55,.8,.55]),P(KL,c2||c1,[0,2.05,0],[.38,.7,.38])],
 tree:(c1)=>[P(CL,'#6b4a2b',[0,.55,0],[.16,1.1,.16]),P(SL,c1,[0,1.35,0],[.8,.68,.8]),P(SL,c1,[.4,1.05,.15],[.46,.4,.46])],
 rock:(c)=>[P(SL,c,[0,.3,0],[.7,.45,.55]),P(SL,c,[.55,.15,.2],[.35,.25,.3])],
 crystal:(c)=>[P(KL,c,[0,.5,0],[.34,1.0,.34],null,E),P(KL,c,[0,-.3,0],[.34,.6,.34],[PI,0,0],E),P(KL,c,[.4,.3,.1],[.2,.6,.2],[0,0,-.5],E)],
 cactus:()=>[P(CL,'#3f9a4f',[0,.8,0],[.22,1.6,.22]),P(CL,'#3f9a4f',[-.35,.9,0],[.14,.5,.14],[0,0,.0]),P(CL,'#3f9a4f',[-.35,.55,0],[.14,.5,.14],[PI/2,0,PI/2]),P(CL,'#3f9a4f',[.33,1.15,0],[.13,.5,.13]),P(SL,'#ff8ad8',[0,1.65,0],[.1,.08,.1])],
 mesa:(c1,c2)=>[P(CL,c1,[0,.6,0],[1.1,1.2,.9]),P(CL,c2,[0,1.3,0],[1.0,.3,.82]),P(CL,c1,[0,1.55,0],[.9,.25,.75])],
 building:(c,w,h)=>{const p=[P(BX,c,[0,h/2,0],[w,h,w])];const r=rnd(Math.floor(w*100+h*10));for(let i=0;i<7;i++)p.push(P(BX,r()<.6?'#ffe08a':'#6a7aa8',[(r()-.5)*w*.7,.4+r()*(h-.6),w/2+.01],[.14,.18,.02],null,r()<.6?E:{outline:false}));return p},
 planet:(c,r2)=>[P(SL,c,[0,0,0],[1,1,1]),P(CL,r2,[0,0,0],[1.9,.03,1.9],[.35,0,.2],{outline:false})],
 island:(c)=>[P(KL,'#6b5a4a',[0,-.6,0],[1.0,1.3,1.0],[PI,0,0]),P(CL,c,[0,.05,0],[1.0,.2,1.0]),P(SL,'#3f8a4a',[.1,.55,0],[.35,.4,.35]),P(CL,'#6b4a2b',[.1,.3,0],[.06,.4,.06])],
 mushroom:(c)=>[P(CL,'#f3e6d0',[0,.35,0],[.15,.7,.15]),P(SL,c,[0,.8,0],[.55,.3,.55]),P(SL,'#ffffff',[.2,1.0,.1],[.08,.05,.08],null,E)],
 lantern:(c)=>[P(CL,'#4a4a58',[0,.7,0],[.05,1.4,.05]),P(SL,c,[0,1.5,0],[.17,.17,.17],null,E)],
 cloud:(c)=>[P(SL,c,[0,0,0],[.7,.4,.5],null,{outline:false}),P(SL,c,[-.6,-.1,0],[.5,.3,.4],null,{outline:false}),P(SL,c,[.65,-.08,0],[.55,.32,.4],null,{outline:false})],
 spire:(c)=>[P(KL,c,[0,1.4,0],[.45,2.8,.45]),P(KL,c,[.55,.9,.1],[.3,1.8,.3]),P(KL,c,[-.5,.7,0],[.25,1.4,.25])],
 lava:()=>[P(SL,'#2a1a1a',[0,.35,0],[.85,.5,.7]),P(SL,'#ff6a1e',[0,.5,.32],[.45,.12,.3],null,E),P(SL,'#ffb02e',[.3,.4,.25],[.14,.08,.1],null,E)],
 iceberg:()=>[P(KL,'#cfeeff',[0,1.1,0],[.95,2.2,.8]),P(KL,'#e9f8ff',[.7,.6,.2],[.5,1.2,.45],[0,0,-.2]),P(KL,'#9fd8ff',[-.6,.5,.1],[.4,1.0,.4],[0,0,.25])],
 station:()=>{const p=[];for(let i=0;i<14;i++){const a=i/14*PI*2;p.push(P(BX,i%2?'#8fa0c8':'#b9c6e8',[Math.cos(a)*1.8,Math.sin(a)*1.8,0],[.5,.34,.4],[0,0,a]))}p.push(P(SL,'#65f0ff',[0,0,0],[.35,.35,.35],null,E));return p}
};

/* ---------- Welten ---------- */
const THEMES=[
 {name:'Himmelsinseln',sky:['#4d3fb0','#ff6f91','#ffc27a'],sun:{x:.7,r:.1,c:'#fff1b8'},layers:[{c:'#8a5ac8',a:.05,f:3,s:1},{c:'#c9689a',a:.04,f:5,s:4}],stars:0,cloud:'#ffe6f0',ground:'#e9a070',podium:'#fff2e0',ring:'#ffd24a',shadow:'#a8643e',fog:[255,194,140],part:{k:'dust',c:'#fff1b8',n:26},
  props:[['island',-6,-9,1.3,2.0,'#79c06e'],['island',6.5,-11,1.6,2.8,'#79c06e'],['island',-2.5,-16,1,4.0,'#79c06e'],['tree',-5,-5,1.1,0,'#4caf50'],['tree',5.5,-5.5,1.2,0,'#6cc060'],['cloud',-3,-12,1.2,3.3],['cloud',3,-13,1.5,3.9]]},
 {name:'Eisgipfel',sky:['#6fa8ff','#bfe5ff','#eaf8ff'],sun:{x:.25,r:.06,c:'#ffffff'},layers:[{c:'#dff1ff',a:.16,f:3,s:2},{c:'#b9dcf5',a:.1,f:5,s:7}],stars:0,cloud:'#ffffff',ground:'#eaf6ff',podium:'#cfeeff',ring:'#65f0ff',shadow:'#9ec5e0',fog:[220,240,255],part:{k:'snow',c:'#ffffff',n:46},
  props:[['pine',-5.5,-5,1.3,0,'#e8f6ff','#ffffff'],['pine',5,-6,1.5,0,'#cfeeff','#ffffff'],['iceberg',-8,-10,1.4],['iceberg',8,-12,1.7],['crystal',-3.6,-3,1,0,'#8fe3ff'],['crystal',4,-3.2,.8,0,'#9fd8ff'],['pine',-2,-11,1.8,0,'#dff1ff','#ffffff']]},
 {name:'Vulkan-Arena',sky:['#240a18','#7a1d1d','#ff7a2a'],sun:{x:.5,r:.09,c:'#ffb02e'},layers:[{c:'#2a1018',a:.2,f:2,s:3},{c:'#3a1618',a:.1,f:6,s:9}],stars:0,cloud:'#5a2a2a',ground:'#3a2220',podium:'#4a3030',ring:'#ff7a2a',shadow:'#1a0e0e',fog:[255,110,50],part:{k:'ember',c:'#ffb02e',n:50},
  props:[['lava',-4.5,-3.8,1.2],['lava',5,-4.5,1.4],['rock',-7,-7,1.6,0,'#4a2a2a'],['rock',7.5,-8,1.8,0,'#4a2a2a'],['crystal',-2.8,-8,1.5,0,'#ff7a2a'],['crystal',3.5,-9,1.8,0,'#ffb02e'],['spire',9,-14,2,0,'#2a1418']]},
 {name:'Sturmwolken',sky:['#14102a','#3b3560','#7a6ab0'],sun:null,layers:[{c:'#2a2548',a:.1,f:3,s:5},{c:'#3b3560',a:.07,f:6,s:2}],stars:30,cloud:'#4a4470',ground:'#3b3555',podium:'#4a4470',ring:'#ffe14d',shadow:'#1c1830',fog:[110,100,170],part:{k:'spark',c:'#ffe14d',n:30},lightning:true,
  props:[['spire',-6,-8,1.7,0,'#2a2548'],['spire',6.5,-9,2,0,'#2a2548'],['crystal',-4,-4,1.2,0,'#ffe14d'],['crystal',4.2,-4.5,1,0,'#ffe14d'],['rock',-2,-12,2.4,2.6,'#4a4470'],['rock',3,-14,2.8,3.4,'#4a4470']]},
 {name:'Dschungel',sky:['#1f7a62','#5fc98a','#d9f5a0'],sun:{x:.3,r:.07,c:'#fffbd0'},layers:[{c:'#2f8f58',a:.1,f:3,s:2},{c:'#237a47',a:.07,f:5,s:6}],stars:0,cloud:'#e9ffe0',ground:'#3f8a4a',podium:'#6a4a2a',ring:'#7dff9b',shadow:'#24582c',fog:[170,230,150],part:{k:'leaf',c:'#7ddb5a',n:30},
  props:[['tree',-5,-4.5,1.5,0,'#2f9a4a'],['tree',5.5,-5,1.7,0,'#3fae58'],['tree',-8,-9,2,0,'#2a8a46'],['tree',8.5,-10,2.2,0,'#2a8a46'],['mushroom',-3.4,-3,1.2,0,'#e84a5a'],['mushroom',3.6,-3.4,1,0,'#ff8ad8'],['lantern',-6.5,-3,1,0,'#c8ff7a']]},
 {name:'Wüstenschlucht',sky:['#ff9a3d','#ffd98a','#fff1c9'],sun:{x:.68,r:.13,c:'#fff7d0'},layers:[{c:'#e08a4a',a:.12,f:2.5,s:1},{c:'#c8703a',a:.08,f:4,s:5}],stars:0,cloud:'#fff6df',ground:'#e0b070',podium:'#c9985a',ring:'#ffd24a',shadow:'#a8783e',fog:[255,225,170],part:{k:'dust',c:'#fff1c9',n:34},
  props:[['mesa',-7,-9,2.2,0,'#d9803f','#c4672e'],['mesa',8,-11,2.6,0,'#d9803f','#c4672e'],['cactus',-4.5,-4,1.3],['cactus',5,-4.5,1.1],['rock',-2.5,-3.2,.7,0,'#b88a56'],['rock',3,-3.4,.8,0,'#b88a56']]},
 {name:'Nachtstadt',sky:['#070b26','#1a2a5e','#3b4f8f'],sun:{x:.78,r:.07,c:'#f4f1ff',moon:true},layers:[{c:'#141c3e',a:.04,f:6,s:3}],stars:80,city:true,cloud:'#2a3a78',ground:'#26304f',podium:'#34406a',ring:'#a98bff',shadow:'#141a30',fog:[40,60,110],part:{k:'firefly',c:'#ffe08a',n:26},
  props:[['building','#1e2850',1.6,3.4,-7.5,-8],['building','#243060',1.4,4.6,8,-9.5],['building','#1a2244',1.8,2.6,-3.5,-12],['lantern',-4.2,-3,1.1,0,'#ffe08a'],['lantern',4.6,-3.4,1.1,0,'#ffe08a'],['rock',3,-14,2,0,'#2a3560']]},
 {name:'Weltraum-Station',sky:['#03040f','#120a3a','#2a1a6a'],sun:null,layers:[],stars:160,cloud:'#2a2a6a',ground:'#1a1f3f',podium:'#2a3060',ring:'#65f0ff',shadow:'#0a0d22',fog:[30,25,90],part:{k:'star',c:'#ffffff',n:40},planet:true,
  props:[['planet',-7,-14,3.2,3.5,'#5a7aff','#b9c6ff'],['planet',9,-18,1.6,5.5,'#ff7ab0','#ffd0e6'],['station',5.5,-10,1.1,3.2],['crystal',-4,-3.4,1.1,0,'#65f0ff'],['crystal',4.4,-3.8,.9,0,'#d99bff']]}
];
A.THEMES=THEMES;
/* Welt je Kämpfer */
const THEME_OF=[7,5,3,2,1,3,4,5,4,6,2,7,0,1,6,0,3,2,7];
A.themeFor=i=>THEME_OF[i%THEME_OF.length];

function buildPropObj(def,th,fogCol){
 const [kind]=def;let parts,x,z,s,y;
 if(kind==='building'){const [,col,w,h,px,pz]=def;parts=PROPS.building(col,w,h);x=px;z=pz;s=1;y=0}
 else{const [k,px,pz,sc,py,a,b]=def;x=px;z=pz;s=sc;y=py||0;
  if(k==='pine')parts=PROPS.pine(a,b);else if(k==='tree')parts=PROPS.tree(a);else if(k==='rock')parts=PROPS.rock(a);
  else if(k==='crystal')parts=PROPS.crystal(a);else if(k==='mesa')parts=PROPS.mesa(a,b);else if(k==='planet')parts=PROPS.planet(a,b);
  else if(k==='island')parts=PROPS.island(a);else if(k==='mushroom')parts=PROPS.mushroom(a);else if(k==='lantern')parts=PROPS.lantern(a);
  else if(k==='spire')parts=PROPS.spire(a||'#2a2548');else if(k==='cloud')parts=PROPS.cloud(th.cloud);else parts=(PROPS[k]||PROPS.rock)(a);
 }
 const d=Math.hypot(x,z+6);
 const o=A.obj(parts,{pos:[x,y,z],scale:s,outline:false,layer:1});
 o.fog=clamp((d-6)/26,0,.65);o.fogCol=fogCol;
 o.baseY=y;o.baseX=x;o.kind=def[0];o.ph=(x*7.3+z*3.1)%6.28;
 o.update=(t)=>{
  if(o.kind==='island'||o.kind==='cloud'||o.kind==='planet'||o.kind==='station'){o.pos[1]=o.baseY+Math.sin(t*.7+o.ph)*.18}
  if(o.kind==='planet'||o.kind==='station'||o.kind==='island')o.yaw=t*.12+o.ph;
  if(o.kind==='station')o.rz=t*.2;
 };
 return o;
}
function podiumObj(th){
 const parts=[P(CL,th.podium,[0,-.12,0],[1.25,.24,1.25]),P(CL,th.ring,[0,.005,0],[1.17,.03,1.17],null,E),P(CL,th.podium,[0,.012,0],[1.08,.02,1.08],null,{outline:false}),P(CL,th.shadow,[0,.02,0],[.7,.01,.45],null,{outline:false})];
 const o=A.obj(parts,{layer:0,outline:false});o.pos=[0,0,0];return o;
}

/* ---------- Hintergrund (vorgerendert) ---------- */
function drawBackdrop(g,W,H,th,hz,vx){
 const sky=g.createLinearGradient(0,0,0,hz+H*.05);sky.addColorStop(0,th.sky[0]);sky.addColorStop(.6,th.sky[1]);sky.addColorStop(1,th.sky[2]);
 g.fillStyle=sky;g.fillRect(0,0,W,H);
 const r=rnd(77+THEMES.indexOf(th)*13);
 for(let i=0;i<th.stars;i++){g.globalAlpha=.4+r()*.6;g.fillStyle='#ffffff';const s=r()<.1?2:1;g.fillRect(r()*W,r()*hz*.95,s,s)}
 g.globalAlpha=1;
 if(th.sun){const sx=W*th.sun.x,sy=hz*(th.sun.moon?.35:.62),sr=H*th.sun.r;
  const gl=g.createRadialGradient(sx,sy,sr*.3,sx,sy,sr*4);gl.addColorStop(0,th.sun.c+'88');gl.addColorStop(1,th.sun.c+'00');g.fillStyle=gl;g.fillRect(sx-sr*4,sy-sr*4,sr*8,sr*8);
  g.fillStyle=th.sun.c;g.beginPath();g.arc(sx,sy,sr,0,PI*2);g.fill();
  if(th.sun.moon){g.fillStyle='rgba(40,50,100,.25)';for(const [dx,dy,rr] of [[-.3,-.2,.2],[.2,.15,.15],[.1,-.35,.1]]){g.beginPath();g.arc(sx+dx*sr,sy+dy*sr,rr*sr,0,PI*2);g.fill()}}
 }
 if(th.planet){const px=W*.78,py=hz*.55,pr=H*.16;const pg=g.createRadialGradient(px-pr*.4,py-pr*.4,pr*.2,px,py,pr);pg.addColorStop(0,'#ffb3e6');pg.addColorStop(1,'#6a3aa8');g.fillStyle=pg;g.beginPath();g.arc(px,py,pr,0,PI*2);g.fill();
  g.strokeStyle='rgba(255,220,255,.5)';g.lineWidth=4;g.beginPath();g.ellipse(px,py,pr*1.7,pr*.35,-.3,0,PI*2);g.stroke()}
 th.layers.forEach((L,li)=>{
  g.fillStyle=L.c;g.beginPath();g.moveTo(0,H);
  for(let x=0;x<=W;x+=6){const y=hz-H*(L.a*(.6+.4*Math.sin(x/W*PI*L.f+L.s)+.3*Math.sin(x/W*PI*L.f*2.7+L.s*2.1))+.012*li);g.lineTo(x,y)}
  g.lineTo(W,H);g.closePath();g.fill();
 });
 if(th.city){
  let x=-10;const base=hz;
  while(x<W){const w=24+r()*46,h=H*(.06+r()*.2);g.fillStyle=r()<.5?'#0e1432':'#121a40';g.fillRect(x,base-h,w,h+4);
   for(let wy=base-h+6;wy<base-4;wy+=9)for(let wx=x+4;wx<x+w-5;wx+=8){if(r()<.34){g.fillStyle=r()<.7?'#ffe08a':'#8fd0ff';g.fillRect(wx,wy,3,4)}}
   x+=w+r()*6}
 }
 // Boden
 const fg='rgb('+th.fog.join(',')+')';
 const gg=g.createLinearGradient(0,hz,0,H);gg.addColorStop(0,fg);gg.addColorStop(.18,th.ground);gg.addColorStop(1,th.shadow);
 g.fillStyle=gg;g.fillRect(0,hz,W,H-hz);
 g.strokeStyle='rgba(255,255,255,.07)';g.lineWidth=1.5;
 for(let i=-14;i<=14;i++){g.beginPath();g.moveTo(vx,hz);g.lineTo(vx+i*W*.16,H);g.stroke()}
 for(let k=1;k<7;k++){const y=hz+(H-hz)*Math.pow(k/7,1.8);g.beginPath();g.moveTo(0,y);g.lineTo(W,y);g.stroke()}
 const hg=g.createLinearGradient(0,hz-H*.04,0,hz+H*.06);hg.addColorStop(0,'rgba('+th.fog.join(',')+',0)');hg.addColorStop(.5,'rgba('+th.fog.join(',')+',.55)');hg.addColorStop(1,'rgba('+th.fog.join(',')+',0)');
 g.fillStyle=hg;g.fillRect(0,hz-H*.04,W,H*.1);
}

/* ---------- Controller ---------- */
const L=A.Lobby={
 canvas:null,ctx:null,W:800,H:400,dpr:1,scene:null,theme:0,themeOverride:null,model:null,modelIdx:-1,
 yaw:-.4,yawVel:0,dragging:false,idleT:0,pose:0,spawn:1,t:0,running:false,last:0,q:2,ema:16,bg:null,bgKey:'',
 clouds:[],parts:[],flash:0,flashT:3,bolt:null,sway:0,
 init(canvas){
  this.canvas=canvas;this.ctx=canvas.getContext('2d');this.scene=new A.Scene();
  this.scene.outCol='#0b1018';
  this.initClouds();
 },
 initClouds(){const r=rnd(5);this.clouds=[];for(let i=0;i<7;i++)this.clouds.push({x:r(),y:.08+r()*.32,s:.6+r()*1.1,v:.004+r()*.01})},
 resize(W,H,dpr){
  this.W=W;this.H=H;this.dpr=Math.min(dpr||1,1.5);
  this.canvas.width=Math.round(W*this.dpr);this.canvas.height=Math.round(H*this.dpr);
  this.canvas.style.width=W+'px';this.canvas.style.height=H+'px';
  const cam=this.scene.cam;cam.focal=H*1.22;cam.cx=W*.45;cam.cy=H*.45;this.hz=cam.cy-cam.focal*.0886;
  this.bgKey='';
 },
 setTheme(idx){
  this.theme=((idx%THEMES.length)+THEMES.length)%THEMES.length;const th=THEMES[this.theme];
  const fc=th.fog;
  const objs=[];
  objs.push(podiumObj(th));
  th.props.forEach(d=>objs.push(buildPropObj(d,th,fc)));
  this.propObjs=objs;this.bgKey='';
  this.rebuildScene();
  this.parts=[];const pr=rnd(31+this.theme);
  for(let i=0;i<th.part.n;i++)this.parts.push({x:pr(),y:pr(),v:.02+pr()*.05,s:1+pr()*2.4,ph:pr()*6.28});
 },
 rebuildScene(){
  const arr=this.propObjs.slice();
  if(this.model)arr.push(this.model);
  this.scene.objs=arr;
 },
 setBrawler(i,instant){
  if(i===this.modelIdx&&this.model)return;
  this.modelIdx=i;
  const m=A.buildModel(i);
  this.model=m;m.layer=1;m.outline=true;A.setLod(m,this.q>=2);
  if(this.themeOverride===null||this.themeOverride===undefined)this.setTheme(A.themeFor(i));else this.rebuildScene();
  this.spawn=instant?1:0;this.yaw=-.4;this.rebuildScene();
 },
 cycleTheme(){
  const cur=this.theme;this.themeOverride=(cur+1)%THEMES.length;this.setTheme(this.themeOverride);return THEMES[this.theme].name;
 },
 resetTheme(){this.themeOverride=null;if(this.modelIdx>=0)this.setTheme(A.themeFor(this.modelIdx))},
 poseNow(){this.pose=1},
 drag(dx){this.yaw+=dx*.012;this.idleT=this.t},
 start(){if(this.running)return;this.running=true;this.last=performance.now();requestAnimationFrame(n=>this.loop(n))},
 stop(){this.running=false},
 loop(now){
  if(!this.running)return;
  if(now-this.last<24){requestAnimationFrame(n=>this.loop(n));return}
  const dt=Math.min(.05,(now-this.last)/1000);this.last=now;
  this.ema=this.ema*.92+dt*1000*.08;
  if(this.ema>34&&this.q>0){this.q--;this.ema=16;if(this.model)A.setLod(this.model,this.q>=2)}
  this.frame(dt);
  requestAnimationFrame(n=>this.loop(n));
 },
 frame(dt){
  if(!this.model){return}
  this.t+=dt;const t=this.t,W=this.W,H=this.H,ctx=this.ctx,th=THEMES[this.theme];
  // Figur: Einblendung, Drehung, Pose
  if(this.spawn<1)this.spawn=Math.min(1,this.spawn+dt*1.8);
  const sp=this.spawn,back=1+2.2*Math.pow(sp-1,3)+1.2*Math.pow(sp-1,2);
  this.model.scale=Math.max(.01,back)*1.0;
  if(t-this.idleT>2.2)this.yaw+=(Math.sin(t*.6)*.35-.4-this.yaw)*Math.min(1,dt*1.5);
  this.model.yaw=this.yaw+(this.spawn<1?(1-sp)*6:0);
  if(this.pose>0)this.pose=Math.max(0,this.pose-dt*1.2);
  const ps=this.pose>0?Math.sin((1-this.pose)*PI*.5+.0001):0;
  this.model.update&&this.model.update(t,this.pose>0?Math.min(1,this.pose*1.6):0);
  for(const o of this.propObjs)o.update&&o.update(t);
  // Kamera
  const cam=this.scene.cam;cam.pos[0]=Math.sin(t*.32)*.45;cam.tgt[0]=0;
  this.scene.outlineOn=this.q>=1;this.scene.stroke=this.q>=1;
  // Zeichnen
  ctx.setTransform(this.dpr,0,0,this.dpr,0,0);
  const key=this.theme+':'+W+'x'+H;
  if(this.bgKey!==key){
   this.bg=document.createElement('canvas');this.bg.width=Math.round(W*1.1);this.bg.height=Math.round(H*1.0);
   drawBackdrop(this.bg.getContext('2d'),this.bg.width,this.bg.height,th,this.hz,W*.42+W*.05);this.bgKey=key;
  }
  const par=(cam.pos[0])*-14;
  ctx.drawImage(this.bg,-W*.05+par,0,W*1.1,H);
  this.drawClouds(ctx,W,H,th,t,dt);
  if(th.lightning)this.drawLightning(ctx,W,H,dt);
  this.drawParticles(ctx,W,H,th,t,dt,false);
  this.scene.render(ctx,W,H);
  this.drawParticles(ctx,W,H,th,t,dt,true);
  const v=ctx.createRadialGradient(W*.42,H*.5,H*.5,W*.5,H*.5,W*.75);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(0,0,0,.4)');ctx.fillStyle=v;ctx.fillRect(0,0,W,H);
 },
 drawClouds(ctx,W,H,th,t,dt){
  if(th.stars>100)return;
  ctx.fillStyle=th.cloud;ctx.globalAlpha=th.lightning?.65:.55;
  for(const c of this.clouds){c.x+=c.v*dt;if(c.x>1.2)c.x=-.2;const x=c.x*W,y=c.y*H,s=c.s*H*.08;
   ctx.beginPath();ctx.ellipse(x,y,s*1.6,s*.55,0,0,PI*2);ctx.ellipse(x-s,y+s*.1,s,s*.4,0,0,PI*2);ctx.ellipse(x+s*1.05,y+s*.12,s*1.1,s*.42,0,0,PI*2);ctx.fill()}
  ctx.globalAlpha=1;
 },
 drawLightning(ctx,W,H,dt){
  this.flashT-=dt;
  if(this.flashT<=0){this.flashT=2.5+Math.random()*4;this.flash=1;const x0=W*(.2+Math.random()*.6);this.bolt=[[x0,0]];let x=x0,y=0;while(y<H*.48){x+=(Math.random()-.5)*50;y+=H*.05+Math.random()*H*.04;this.bolt.push([x,y])}}
  if(this.flash>0){
   if(this.bolt){ctx.strokeStyle='rgba(255,250,200,'+this.flash+')';ctx.lineWidth=3;ctx.beginPath();this.bolt.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.stroke()}
   ctx.fillStyle='rgba(255,255,255,'+(this.flash*.18)+')';ctx.fillRect(0,0,W,H);this.flash=Math.max(0,this.flash-dt*3);
  }
 },
 drawParticles(ctx,W,H,th,t,dt,front){
  const k=th.part.k,n=Math.round(this.parts.length*(this.q>=2?1:this.q===1?.6:.3));
  for(let i=0;i<n;i++){
   const p=this.parts[i];if((i%3===0)!==front)continue;
   let x=p.x*W,y=p.y*H;
   if(k==='snow'){p.y+=p.v*dt*1.4;p.x+=Math.sin(t+p.ph)*.0006;}
   else if(k==='ember'||k==='spark'){p.y-=p.v*dt*1.6;p.x+=Math.sin(t*2+p.ph)*.0008;if(k==='spark'&&Math.random()<.01){p.x=Math.random();p.y=Math.random()}}
   else if(k==='leaf'){p.y+=p.v*dt;p.x+=Math.sin(t*1.5+p.ph)*.0012}
   else if(k==='dust'){p.x+=p.v*dt*1.5;p.y+=Math.sin(t+p.ph)*.0004}
   else if(k==='firefly'){p.x+=Math.sin(t*.7+p.ph)*.0007;p.y+=Math.cos(t*.9+p.ph)*.0006}
   else {p.x+=0;}
   if(p.y>1.05)p.y=-.05;if(p.y<-.05)p.y=1.05;if(p.x>1.05)p.x=-.05;if(p.x<-.05)p.x=1.05;
   x=p.x*W;y=p.y*H;
   ctx.fillStyle=th.part.c;
   if(k==='star'||k==='firefly'||k==='spark'||k==='ember'){ctx.globalAlpha=.35+.65*Math.abs(Math.sin(t*2+p.ph))}else ctx.globalAlpha=.8;
   if(k==='leaf'){ctx.save();ctx.translate(x,y);ctx.rotate(t+p.ph);ctx.fillRect(-p.s*1.6,-p.s*.6,p.s*3.2,p.s*1.2);ctx.restore()}
   else{const s=p.s*(front?1.6:1)*(H/400);ctx.beginPath();ctx.arc(x,y,Math.max(.8,s),0,PI*2);ctx.fill()}
  }
  ctx.globalAlpha=1;
 }
};
})();
