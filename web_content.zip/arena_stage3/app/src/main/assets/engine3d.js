/* Arena Stars – eigene kleine 3D-Engine (Software-Renderer auf Canvas 2D, keine Fremdbibliothek) */
(function(){
'use strict';
const A=window.A3D=window.A3D||{};
const G=A.geo={};

/* ---------- Geometrie (Einheitskörper, flach schattiert) ---------- */
function mk(tris){
 const P=new Float32Array(tris.length*9),N=new Float32Array(tris.length*3);
 for(let i=0;i<tris.length;i++){const t=tris[i];P.set(t[0],i*9);P.set(t[1],i*9+3);P.set(t[2],i*9+6);N.set(t[3],i*3)}
 return {P,N,n:tris.length};
}
function nrm(x,y,z){const l=Math.hypot(x,y,z)||1;return[x/l,y/l,z/l]}
function boxGeo(){
 const t=[],ax=[[1,0,0],[0,1,0],[0,0,1]];
 for(let a=0;a<3;a++)for(const s of[-1,1]){
  const n=ax[a].map(v=>v*s),u=ax[(a+1)%3],v=ax[(a+2)%3];
  const c=(su,sv)=>[0,1,2].map(k=>n[k]*.5+u[k]*.5*su+v[k]*.5*sv);
  const p=[c(-1,-1),c(1,-1),c(1,1),c(-1,1)];
  t.push([p[0],p[1],p[2],n],[p[0],p[2],p[3],n]);
 }
 return mk(t);
}
function sphereGeo(seg,rings,phiMax,cap){
 const t=[];
 const pt=(i,j)=>{const ph=i/rings*phiMax,th=j/seg*Math.PI*2;return[Math.sin(ph)*Math.cos(th),Math.cos(ph),Math.sin(ph)*Math.sin(th)]};
 for(let i=0;i<rings;i++)for(let j=0;j<seg;j++){
  const a=pt(i,j),b=pt(i,j+1),c=pt(i+1,j+1),d=pt(i+1,j);
  if(i>0){const n=nrm(a[0]+b[0]+c[0],a[1]+b[1]+c[1],a[2]+b[2]+c[2]);t.push([a,b,c,n])}
  if(i<rings-1||phiMax<Math.PI-.01){const n=nrm(a[0]+c[0]+d[0],a[1]+c[1]+d[1],a[2]+c[2]+d[2]);t.push([a,c,d,n])}
 }
 if(cap){for(let j=0;j<seg;j++){t.push([[0,Math.cos(phiMax),0],pt(rings,j+1),pt(rings,j),[0,-1,0]])}}
 return mk(t);
}
function cylGeo(seg,rTop,rBot){
 const t=[];const ys=.5,yb=-.5;
 for(let j=0;j<seg;j++){
  const a0=j/seg*Math.PI*2,a1=(j+1)/seg*Math.PI*2,am=(a0+a1)/2;
  const p0=[Math.cos(a0)*rBot,yb,Math.sin(a0)*rBot],p1=[Math.cos(a1)*rBot,yb,Math.sin(a1)*rBot];
  const p2=[Math.cos(a1)*rTop,ys,Math.sin(a1)*rTop],p3=[Math.cos(a0)*rTop,ys,Math.sin(a0)*rTop];
  const slope=(rBot-rTop);
  const n=nrm(Math.cos(am),slope,Math.sin(am));
  if(rBot>0)t.push([p0,p1,p2,n]);
  if(rTop>0)t.push([p0,p2,p3,n]);
  if(rBot===0)t.push([p0,p2,p3,n]);
  if(rTop>0)t.push([[0,ys,0],p2,p3,[0,1,0]]);
  if(rBot>0)t.push([[0,yb,0],p1,p0,[0,-1,0]]);
 }
 return mk(t);
}
G.box=boxGeo();
/* hohe Auflösung (Figuren) + mittlere Stufe (LOD für schwächere Geräte) + niedrig (Requisiten) */
G.sphere=sphereGeo(32,22,Math.PI,false);G.sphereM=sphereGeo(10,7,Math.PI,false);
G.sphereL=sphereGeo(7,5,Math.PI,false);
G.dome=sphereGeo(32,11,Math.PI/2,true);G.domeM=sphereGeo(10,4,Math.PI/2,true);
G.cyl=cylGeo(32,1,1);G.cylM=cylGeo(10,1,1);
G.cylL=cylGeo(7,1,1);
G.cone=cylGeo(32,0,1);G.coneM=cylGeo(10,0,1);
G.coneL=cylGeo(7,0,1);
G.frustum=cylGeo(10,.6,1);
A.lodMap=new Map([[G.sphere,G.sphereM],[G.dome,G.domeM],[G.cyl,G.cylM],[G.cone,G.coneM]]);

A.rgb=function(hex){const n=parseInt(hex.slice(1,7),16);return[(n>>16)&255,(n>>8)&255,n&255]};
/* Teil: Geometrie g, Farbe, Position, Skalierung, Rotation (R = Rz*Ry*Rx), Optionen */
A.part=function(g,col,pos,sc,rot,o){
 const p={g,col:A.rgb(col),pos:pos||[0,0,0],sc:sc||[1,1,1],rot:rot||[0,0,0],outline:true,emissive:false,cs:null};
 if(o)Object.assign(p,o);
 p.base={pos:p.pos.slice(),rot:p.rot.slice(),sc:p.sc.slice()};
 p.gHi=p.g;p.gLo=A.lodMap.get(p.g)||p.g;p.gTiny=A.lodTiny.get(p.g)||p.gLo;
 return p;
};
A.lodTiny=new Map([[G.sphere,G.sphereL],[G.dome,G.domeM],[G.cyl,G.cylL],[G.cone,G.coneL]]);
A.setLodLevel=function(obj,n){for(const p of obj.parts)p.g=n>=2?p.gHi:n===1?p.gLo:p.gTiny};
A.setLod=function(obj,hi){for(const p of obj.parts)p.g=hi?p.gHi:p.gLo};
A.obj=function(parts,o){return Object.assign({parts,pos:[0,0,0],yaw:0,rx:0,rz:0,scale:1,outline:true,layer:1,fog:0,fogCol:[0,0,0],update:null,visible:true},o||{})};

/* ---------- Mathe ---------- */
function eul(rx,ry,rz){
 const cx=Math.cos(rx),sx=Math.sin(rx),cy=Math.cos(ry),sy=Math.sin(ry),cz=Math.cos(rz),sz=Math.sin(rz);
 const r00=cy,r01=sy*sx,r02=sy*cx,r10=0,r11=cx,r12=-sx,r20=-sy,r21=cy*sx,r22=cy*cx;
 return [cz*r00-sz*r10,cz*r01-sz*r11,cz*r02-sz*r12, sz*r00+cz*r10,sz*r01+cz*r11,sz*r02+cz*r12, r20,r21,r22];
}
function mul3(a,b){
 const r=new Array(9);
 for(let i=0;i<3;i++)for(let j=0;j<3;j++)r[i*3+j]=a[i*3]*b[j]+a[i*3+1]*b[3+j]+a[i*3+2]*b[6+j];
 return r;
}
function norm3(v){const l=Math.hypot(v[0],v[1],v[2])||1;return[v[0]/l,v[1]/l,v[2]/l]}
function cross(a,b){return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]}
const LEVELS=[.46,.6,.74,.88,1.0];

function colorFor(part,idx,obj){
 if(!part.cs||part.csObj!==obj.fog+':'+obj.fogCol.join(',')){part.cs=[];part.csObj=obj.fog+':'+obj.fogCol.join(',')}
 let s=part.cs[idx];
 if(s)return s;
 const lvl=idx>=5?LEVELS[idx-5]+.14:LEVELS[idx];
 const k=part.emissive?1.12:lvl;
 const f=obj.fog,fc=obj.fogCol,c=part.col;
 const r=Math.min(255,Math.round((c[0]*k)*(1-f)+fc[0]*f)),g=Math.min(255,Math.round((c[1]*k)*(1-f)+fc[1]*f)),b=Math.min(255,Math.round((c[2]*k)*(1-f)+fc[2]*f));
 s=part.cs[idx]='rgb('+r+','+g+','+b+')';
 return s;
}

/* ---------- Szene ---------- */
A.Scene=function(){
 this.objs=[];
 this.light=norm3([-.45,.85,.6]);
 this.cam={pos:[0,1.6,6.2],tgt:[0,1.05,0],focal:600,cx:0,cy:0};
 this.outlineOn=true;this.ow=.05;this.outCol='#0e131c';this.stroke=true;
 this.pool=[];
};
A.Scene.prototype.render=function(ctx,W,H){
 const cam=this.cam,P=cam.pos;
 const f=norm3([cam.tgt[0]-P[0],cam.tgt[1]-P[1],cam.tgt[2]-P[2]]),r=norm3(cross(f,[0,1,0])),u=cross(r,f);
 const foc=cam.focal,cx=cam.cx,cy=cam.cy,L=this.light;
 const objs=this.objs.filter(o=>o.visible);
 for(const o of objs){const dx=o.pos[0]-P[0],dy=o.pos[1]-P[1],dz=o.pos[2]-P[2];o._d=dx*f[0]+dy*f[1]+dz*f[2]}
 objs.sort((a,b)=>a.layer-b.layer||b._d-a._d);
 const pool=this.pool;let np=0;
 const outCol=this.outCol,ow=this.ow,doOut=this.outlineOn,stroke=this.stroke;
 ctx.lineJoin='round';ctx.lineWidth=1;
 for(const obj of objs){
  const Ro=eul(obj.rx||0,obj.yaw||0,obj.rz||0),s=obj.scale;
  np=0;
  const outList=[];
  for(const part of obj.parts){
   if(part.hidden)continue;
   const Rp=eul(part.rot[0],part.rot[1],part.rot[2]),T1=mul3(Ro,Rp),sc=part.sc;
   const M=[T1[0]*sc[0]*s,T1[1]*sc[1]*s,T1[2]*sc[2]*s,T1[3]*sc[0]*s,T1[4]*sc[1]*s,T1[5]*sc[2]*s,T1[6]*sc[0]*s,T1[7]*sc[1]*s,T1[8]*sc[2]*s];
   const Nm=[T1[0]/sc[0],T1[1]/sc[1],T1[2]/sc[2],T1[3]/sc[0],T1[4]/sc[1],T1[5]/sc[2],T1[6]/sc[0],T1[7]/sc[1],T1[8]/sc[2]];
   const pp=part.pos;
   const tx=Ro[0]*pp[0]*s+Ro[1]*pp[1]*s+Ro[2]*pp[2]*s+obj.pos[0],ty=Ro[3]*pp[0]*s+Ro[4]*pp[1]*s+Ro[5]*pp[2]*s+obj.pos[1],tz=Ro[6]*pp[0]*s+Ro[7]*pp[1]*s+Ro[8]*pp[2]*s+obj.pos[2];
   const g=part.g,gP=g.P,gN=g.N,n=g.n;
   const outK=(doOut&&obj.outline&&part.outline)?1+this.ow/Math.max(.1,(sc[0]+sc[1]+sc[2])/3*s):0;
   for(let k=0;k<n;k++){
    const i9=k*9,i3=k*3;
    const nx0=gN[i3],ny0=gN[i3+1],nz0=gN[i3+2];
    let nx=Nm[0]*nx0+Nm[1]*ny0+Nm[2]*nz0,ny=Nm[3]*nx0+Nm[4]*ny0+Nm[5]*nz0,nz=Nm[6]*nx0+Nm[7]*ny0+Nm[8]*nz0;
    const nl=Math.hypot(nx,ny,nz)||1;nx/=nl;ny/=nl;nz/=nl;
    // Weltpunkte
    let ax=gP[i9],ay=gP[i9+1],az=gP[i9+2],bx=gP[i9+3],by=gP[i9+4],bz=gP[i9+5],cx2=gP[i9+6],cy2=gP[i9+7],cz2=gP[i9+8];
    const w0x=M[0]*ax+M[1]*ay+M[2]*az+tx,w0y=M[3]*ax+M[4]*ay+M[5]*az+ty,w0z=M[6]*ax+M[7]*ay+M[8]*az+tz;
    const w1x=M[0]*bx+M[1]*by+M[2]*bz+tx,w1y=M[3]*bx+M[4]*by+M[5]*bz+ty,w1z=M[6]*bx+M[7]*by+M[8]*bz+tz;
    const w2x=M[0]*cx2+M[1]*cy2+M[2]*cz2+tx,w2y=M[3]*cx2+M[4]*cy2+M[5]*cz2+ty,w2z=M[6]*cx2+M[7]*cy2+M[8]*cz2+tz;
    const mx=(w0x+w1x+w2x)/3-P[0],my=(w0y+w1y+w2y)/3-P[1],mz=(w0z+w1z+w2z)/3-P[2];
    const facing=nx*mx+ny*my+nz*mz;
    if(facing>=0&&!part.double)continue;
    // Ansicht
    const d0x=w0x-P[0],d0y=w0y-P[1],d0z=w0z-P[2],d1x=w1x-P[0],d1y=w1y-P[1],d1z=w1z-P[2],d2x=w2x-P[0],d2y=w2y-P[1],d2z=w2z-P[2];
    const z0=d0x*f[0]+d0y*f[1]+d0z*f[2],z1=d1x*f[0]+d1y*f[1]+d1z*f[2],z2=d2x*f[0]+d2y*f[1]+d2z*f[2];
    if(z0<.15||z1<.15||z2<.15)continue;
    const x0=cx+foc*(d0x*r[0]+d0y*r[1]+d0z*r[2])/z0,y0=cy-foc*(d0x*u[0]+d0y*u[1]+d0z*u[2])/z0;
    const x1=cx+foc*(d1x*r[0]+d1y*r[1]+d1z*r[2])/z1,y1=cy-foc*(d1x*u[0]+d1y*u[1]+d1z*u[2])/z1;
    const x2=cx+foc*(d2x*r[0]+d2y*r[1]+d2z*r[2])/z2,y2=cy-foc*(d2x*u[0]+d2y*u[1]+d2z*u[2])/z2;
    if((x0<-80&&x1<-80&&x2<-80)||(x0>W+80&&x1>W+80&&x2>W+80)||(y0<-80&&y1<-80&&y2<-80)||(y0>H+80&&y1>H+80&&y2>H+80))continue;
    // Beleuchtung (Toon)
    const ndl=nx*L[0]+ny*L[1]+nz*L[2];
    let idx=ndl>.72?4:ndl>.4?3:ndl>.08?2:ndl>-.3?1:0;
    const dl=Math.hypot(mx,my,mz)||1;
    if(1+facing/dl<.32&&idx<4)idx+=5; // Randlicht
    let it=pool[np];if(!it){it=pool[np]={z:0,x0:0,y0:0,x1:0,y1:0,x2:0,y2:0,p:null,c:0};}
    np++;
    it.z=(z0+z1+z2)/3;it.x0=x0;it.y0=y0;it.x1=x1;it.y1=y1;it.x2=x2;it.y2=y2;it.p=part;it.c=idx;
    if(outK){
     const e=outK;
     const o0x=tx+(w0x-tx)*e,o0y=ty+(w0y-ty)*e,o0z=tz+(w0z-tz)*e,o1x=tx+(w1x-tx)*e,o1y=ty+(w1y-ty)*e,o1z=tz+(w1z-tz)*e,o2x=tx+(w2x-tx)*e,o2y=ty+(w2y-ty)*e,o2z=tz+(w2z-tz)*e;
     const e0x=o0x-P[0],e0y=o0y-P[1],e0z=o0z-P[2],e1x=o1x-P[0],e1y=o1y-P[1],e1z=o1z-P[2],e2x=o2x-P[0],e2y=o2y-P[1],e2z=o2z-P[2];
     const q0=e0x*f[0]+e0y*f[1]+e0z*f[2],q1=e1x*f[0]+e1y*f[1]+e1z*f[2],q2=e2x*f[0]+e2y*f[1]+e2z*f[2];
     if(q0>.15&&q1>.15&&q2>.15)outList.push(cx+foc*(e0x*r[0]+e0y*r[1]+e0z*r[2])/q0,cy-foc*(e0x*u[0]+e0y*u[1]+e0z*u[2])/q0,cx+foc*(e1x*r[0]+e1y*r[1]+e1z*r[2])/q1,cy-foc*(e1x*u[0]+e1y*u[1]+e1z*u[2])/q1,cx+foc*(e2x*r[0]+e2y*r[1]+e2z*r[2])/q2,cy-foc*(e2x*u[0]+e2y*u[1]+e2z*u[2])/q2);
    }
   }
  }
  // Umriss zuerst
  if(outList.length){
   ctx.fillStyle=obj.outCol||outCol;ctx.strokeStyle=obj.outCol||outCol;ctx.lineWidth=1.2;ctx.beginPath();
   for(let i=0;i<outList.length;i+=6){ctx.moveTo(outList[i],outList[i+1]);ctx.lineTo(outList[i+2],outList[i+3]);ctx.lineTo(outList[i+4],outList[i+5]);ctx.closePath()}
   ctx.fill();ctx.stroke();ctx.lineWidth=1;
  }
  // Flächen: weit -> nah
  const list=pool.slice(0,np);
  if(obj.layer>0)list.sort((a,b)=>b.z-a.z);
  for(let i=0;i<list.length;i++){
   const it=list[i],col=colorFor(it.p,it.c,obj);
   ctx.fillStyle=col;
   ctx.beginPath();ctx.moveTo(it.x0,it.y0);ctx.lineTo(it.x1,it.y1);ctx.lineTo(it.x2,it.y2);ctx.closePath();ctx.fill();
   if(stroke){ctx.strokeStyle=col;ctx.stroke()}
  }
 }
};

/* ---------- Sprites für das Spiel (Figur als Bild aus dem 3D-Modell) ---------- */
const spriteCache={};
A.sprite=function(i,size,yaw,lo){
 const key=i+':'+size+(lo?'L':'');
 if(spriteCache[key])return spriteCache[key];
 if(!A.buildModel)return null;
 const c=document.createElement('canvas');c.width=c.height=size;const g=c.getContext('2d');
 const sc=new A.Scene();const m=A.buildModel(i);
 m.yaw=yaw===undefined?.65:yaw;m.update&&m.update(.3,0);
 sc.objs.push(m);sc.cam={pos:[0,1.8,6.4],tgt:[0,1.05,0],focal:size*1.95,cx:size/2,cy:size*.53};
 sc.ow=.055;A.setLod(m,!lo);
 sc.render(g,size,size);
 spriteCache[key]=c;
 return c;
};
})();
