/* Arena Stars – 19 eigene 3D-Kämpfermodelle (aus Grundkörpern zusammengesetzt) */
(function(){
'use strict';
const A=window.A3D,G=A.geo,P=A.part;
const S=G.sphere,B=G.box,C=G.cyl,K=G.cone,D=G.dome;
const PI=Math.PI;
const E={emissive:true,outline:false};

/* Chibi-Grundfigur mit schwingenden Armen */
function chibi(o){
 const parts=[];const add=p=>(parts.push(p),p);
 const bw=o.bw||1,hs=o.hs||1;
 const m={parts,add,o,bw,hs,arms:[],t:0};
 if(!o.noLegs){
  m.legs=[];
  for(const sx of[-1,1]){
   const lp=add(P(C,o.pants,[sx*.22*bw,.34,0],[.17,.5,.17]));
   const ls=add(P(S,o.shoes,[sx*.22*bw,.1,.09],[.2,.12,.29]));
   m.legs.push({lp,ls,sx});
  }
 }
 add(P(S,o.body,[0,.86,0],[.44*bw,.5,.38*Math.max(1,bw*.85)]));
 m.head=add(P(S,o.headCol||o.skin,[0,1.55,0],[.56*hs,.52*hs,.52*hs]));
 if(!o.noEyes){
  for(const sx of[-1,1]){
   add(P(S,'#ffffff',[sx*.2*hs,1.58,.43*hs],[.14,.17,.09],null,{outline:false}));
   add(P(S,o.eyeCol||'#161a24',[sx*.2*hs,1.57,.5*hs],[.075,.105,.05],null,{outline:false}));
  }
 }
 for(const sx of[-1,1]){
  const a=add(P(C,o.armCol||o.body,[0,0,0],[.13,.55,.13])),h=add(P(S,o.handCol||o.skin,[0,0,0],[.16,.16,.16]));
  m.arms.push({a,h,sh:[sx*(.5*bw+.06),1.12,0],len:.55,ax:0,az:.28*sx,side:sx});
 }
 return m;
}
function limb(l){
 const cax=Math.cos(l.ax),d=[cax*Math.sin(l.az),-cax*Math.cos(l.az),-Math.sin(l.ax)];
 l.a.pos=[l.sh[0]+d[0]*l.len/2,l.sh[1]+d[1]*l.len/2,l.sh[2]+d[2]*l.len/2];
 l.a.rot=[l.ax,0,l.az];
 l.h.pos=[l.sh[0]+d[0]*l.len,l.sh[1]+d[1]*l.len,l.sh[2]+d[2]*l.len];
}
function finish(m,extra){
 const obj=A.obj(m.parts);
 obj.update=(t,pose,walk,wph,atk)=>{
  walk=walk||0;wph=wph||0;atk=atk||0;pose=pose||0;
  const s=Math.sin(t*2.2),ws=Math.sin(wph);
  obj.pos[1]=s*.025*(1-walk)+Math.abs(ws)*.09*walk+Math.sin(Math.min(1,pose)*PI)*.45*(pose>0?1:0);
  if(m.legs)for(let i=0;i<2;i++){const lg=m.legs[i],sw=Math.sin(wph+(i?PI:0))*walk;
   lg.lp.rot[0]=-sw*.6;lg.ls.pos[2]=lg.ls.base.pos[2]+sw*.2;lg.ls.pos[1]=lg.ls.base.pos[1]+Math.max(0,-Math.cos(wph+(i?PI:0)))*.07*walk}
  const L=m.arms[0],R=m.arms[1];
  if(L){L.ax=s*.12*(1-walk)+ws*.7*walk-.1*pose;L.az=-.28-pose*.3;limb(L)}
  if(R){R.ax=-s*.12*(1-walk)-ws*.7*walk-pose*2.3-atk*1.6;R.az=.28+pose*.1;limb(R)}
  if(extra)extra(t,pose,m,obj);
 };
 obj.update(0,0);
 return obj;
}
function ring(n,f){for(let i=0;i<n;i++)f(i/n*PI*2,i)}

const builders=[];

/* 0 Nova – Raumfahrer mit Raketenrucksack */
builders[0]=()=>{
 const m=chibi({skin:'#e8f4ff',headCol:'#f4f9ff',body:'#42c8ff',pants:'#2b86b8',shoes:'#e8f4ff',handCol:'#e8f4ff',noEyes:true});
 m.add(P(S,'#1b3dbf',[0,1.55,.3],[.42,.34,.27]));
 for(const sx of[-1,1])m.add(P(S,'#9ff3ff',[sx*.13,1.55,.54],[.06,.09,.04],null,E));
 m.add(P(S,'#bfefff',[-.2,1.7,.47],[.1,.05,.03],[0,0,.5],E));
 const pack=m.add(P(C,'#d33a3a',[0,1.0,-.42],[.2,.55,.2]));
 const flame=m.add(P(K,'#ff9d2e',[0,.58,-.42],[.15,.36,.15],[PI,0,0],E));
 m.add(P(C,'#cfd8e0',[.2,2.1,0],[.035,.3,.035]));
 m.add(P(S,'#ff4d4d',[.2,2.27,0],[.075,.075,.075],null,E));
 m.add(P(S,'#fffb9e',[0,.95,.4],[.1,.1,.05],null,E));
 return finish(m,(t)=>{flame.sc=[.15,.3+Math.sin(t*20)*.08,.15]});
};
/* 1 Brutus – schwerer Ritter mit Schild */
builders[1]=()=>{
 const m=chibi({skin:'#f2c9a0',body:'#ffb347',pants:'#7a5a3a',shoes:'#4a3a2a',bw:1.3,armCol:'#9aa7b3',handCol:'#7b8794'});
 m.add(P(D,'#9aa7b3',[0,1.6,0],[.62,.5,.58]));
 m.add(P(B,'#7b8794',[0,1.5,.52],[.08,.32,.06]));
 m.add(P(K,'#d63a3a',[0,2.2,-.02],[.16,.5,.16]));
 for(const sx of[-1,1])m.add(P(S,'#aab5c0',[sx*.68,1.3,0],[.26,.2,.26]));
 m.add(P(C,'#6b4a2b',[0,.62,0],[.54,.1,.46]));
 m.add(P(C,'#c0392b',[-.82,.95,.32],[.52,.09,.52],[PI/2,0,0]));
 m.add(P(B,'#ffd24a',[-.82,.95,.38],[.34,.09,.05],null,E));m.add(P(B,'#ffd24a',[-.82,.95,.38],[.09,.34,.05],null,E));
 return finish(m);
};
/* 2 Zip – flinker Blitzläufer */
builders[2]=()=>{
 const m=chibi({skin:'#ffe0c2',body:'#ce8aff',pants:'#6a3fb5',shoes:'#ffffff',bw:.85});
 m.add(P(B,'#ffe14d',[-.12,2.12,0],[.12,.3,.1],[0,0,.5],E));
 m.add(P(B,'#ffe14d',[.1,2.32,0],[.12,.3,.1],[0,0,-.5],E));
 m.add(P(B,'#ffe14d',[-.02,2.5,0],[.1,.24,.1],[0,0,.5],E));
 for(const sx of[-1,1]){m.add(P(C,'#26262e',[sx*.2,1.78,.36],[.14,.08,.14],[PI/2,0,0]));m.add(P(S,'#65f0ff',[sx*.2,1.78,.42],[.09,.09,.05],null,E))}
 m.add(P(B,'#f5f5ff',[-.34,.22,-.05],[.05,.3,.2],[0,0,.6]));m.add(P(B,'#f5f5ff',[.34,.22,-.05],[.05,.3,.2],[0,0,-.6]));
 const sc=m.add(P(B,'#a367e8',[0,1.1,-.4],[.34,.12,.7],[.4,0,0]));
 return finish(m,(t)=>{sc.rot=[.4+Math.sin(t*6)*.15,0,0]});
};
/* 3 Pyra – Flammenhaar */
builders[3]=()=>{
 const m=chibi({skin:'#ffd1b0',body:'#ff6868',pants:'#4a1a1a',shoes:'#2a1010',handCol:'#ff9a3a'});
 const fl=[m.add(P(K,'#ff8a1e',[0,2.3,0],[.3,.75,.3],null,E)),m.add(P(K,'#ffb02e',[-.3,2.12,0],[.22,.5,.22],[0,0,.55],E)),m.add(P(K,'#ffb02e',[.3,2.12,0],[.22,.5,.22],[0,0,-.55],E)),m.add(P(K,'#ff6a1e',[0,2.12,-.3],[.22,.5,.22],[-.55,0,0],E))];
 for(const sx of[-1,1])m.add(P(S,'#3a2222',[sx*.62,1.3,0],[.22,.18,.22]));
 m.add(P(S,'#ffb02e',[0,.95,.38],[.12,.12,.06],null,E));
 return finish(m,(t)=>{fl.forEach((f,i)=>{f.sc=[f.base.sc[0],f.base.sc[1]*(1+Math.sin(t*9+i*1.7)*.18),f.base.sc[2]]})});
};
/* 4 Frosta – Eisprinzessin */
builders[4]=()=>{
 const m=chibi({skin:'#e8f6ff',body:'#bfe9ff',pants:'#5b86b8',shoes:'#e8f6ff',handCol:'#e8f6ff'});
 ring(5,(a)=>m.add(P(K,'#9fe3ff',[Math.cos(a)*.34,2.1,Math.sin(a)*.34],[.1,.4,.1],[Math.sin(a)*.4,0,-Math.cos(a)*.4],E)));
 m.add(P(C,'#ffffff',[0,1.17,0],[.42,.12,.36]));m.add(P(B,'#ffffff',[.12,.85,-.3],[.18,.6,.08],[.2,0,.1]));
 for(const sx of[-1,1])m.add(P(K,'#8fe3ff',[sx*.64,1.38,0],[.12,.42,.12],[0,0,-sx*.7],E));
 m.add(P(S,'#ffffff',[.0,1.95,.3],[.07,.07,.07],null,E));
 return finish(m);
};
/* 5 Voltia – Wolken-Magierin */
builders[5]=()=>{
 const m=chibi({skin:'#ffe3c4',body:'#ffe14d',pants:'#3a3a52',shoes:'#2a2a3a',handCol:'#ffe3c4'});
 m.add(P(S,'#6b6f8c',[0,2.04,0],[.52,.18,.46]));
 const cl=[m.add(P(S,'#e4e7f2',[0,2.28,0],[.42,.3,.38])),m.add(P(S,'#d4d8e8',[-.32,2.18,0],[.28,.22,.26])),m.add(P(S,'#d4d8e8',[.32,2.18,0],[.28,.22,.26]))];
 const bolt=m.add(P(K,'#ffe14d',[0,1.9,.26],[.08,.2,.08],[PI,0,0],E));
 m.add(P(C,'#9aa0b8',[0,1.1,-.42],[.04,.7,.04]));
 const orb=m.add(P(S,'#ffe14d',[0,1.5,-.42],[.1,.1,.1],null,E));
 return finish(m,(t)=>{cl.forEach((c,i)=>{c.pos=[c.base.pos[0],c.base.pos[1]+Math.sin(t*2+i)*.03,c.base.pos[2]]});bolt.hidden=Math.sin(t*9)<-.2;orb.sc=[.1+Math.sin(t*10)*.03,.1+Math.sin(t*10)*.03,.1+Math.sin(t*10)*.03]});
};
/* 6 Toxa – verrückter Chemiker */
builders[6]=()=>{
 const m=chibi({skin:'#cfe8a8',body:'#f1f5f0',pants:'#4a5a3a',shoes:'#2a3220',bw:1.1,handCol:'#7ddb5a',armCol:'#f1f5f0'});
 ring(6,(a,i)=>m.add(P(K,'#7ddb5a',[Math.cos(a)*.3,2.08+((i%2)?.05:0),Math.sin(a)*.3],[.1,.4,.1],[Math.sin(a)*.4,0,-Math.cos(a)*.4])));
 m.add(P(C,'#d9a63a',[0,1.78,.36],[.4,.06,.2],[PI/2-.5,0,0]));
 for(const sx of[-1,1])m.add(P(S,'#7dffa0',[sx*.17,1.74,.42],[.11,.11,.06],null,E));
 m.add(P(S,'#9fe9a0',[0,1.05,-.52],[.38,.38,.38],null,{emissive:true}));
 m.add(P(C,'#bbbbbb',[0,1.5,-.52],[.12,.2,.12]));
 const b=[m.add(P(S,'#d6ffd0',[0,0,0],[.06,.06,.06],null,E)),m.add(P(S,'#d6ffd0',[0,0,0],[.05,.05,.05],null,E)),m.add(P(S,'#d6ffd0',[0,0,0],[.04,.04,.04],null,E))];
 return finish(m,(t)=>{b.forEach((p,i)=>{const k=((t*.5+i*.33)%1);p.pos=[(i-1)*.12,.9+k*.6,-.52+Math.sin(t*3+i)*.1]})});
};
/* 7 Kaktor – lebender Kaktus im Topf */
builders[7]=()=>{
 const m=chibi({skin:'#4caf50',body:'#4caf50',pants:'#4caf50',shoes:'#4caf50',noLegs:true,bw:1.15,armCol:'#4caf50',handCol:'#5fc562',eyeCol:'#101010'});
 m.add(P(C,'#c46b3a',[0,.3,0],[.5,.6,.5]));m.add(P(C,'#d98050',[0,.62,0],[.58,.12,.56]));
 ring(12,(a,i)=>{const y=.8+(i%3)*.32,r=.4;m.add(P(K,'#f4f4d0',[Math.cos(a)*r*1.0,y,Math.sin(a)*r*.9],[.04,.15,.04],[Math.sin(a)*1.2,0,-Math.cos(a)*1.2]))});
 ring(5,(a)=>m.add(P(S,'#ff8ad8',[Math.cos(a)*.17,2.12,Math.sin(a)*.17],[.11,.08,.11])));
 m.add(P(S,'#ffe14d',[0,2.14,0],[.09,.07,.09],null,E));
 return finish(m);
};
/* 8 Lumi – Heilerin mit Herz */
builders[8]=()=>{
 const m=chibi({skin:'#ffe3d0',body:'#ff8ad8',pants:'#ffd6f3',shoes:'#ffffff',noLegs:true,handCol:'#ffe3d0'});
 m.add(P(K,'#ffb3e6',[0,.62,0],[.62,.95,.58]));
 for(const sx of[-1,1]){m.add(P(S,'#ffd6f3',[sx*.5,1.8,-.02],[.14,.14,.14]));m.add(P(S,'#ffe9f7',[sx*.45,1.2,-.4],[.05,.4,.2],[0,0,sx*.5]))}
 m.add(P(B,'#ffffff',[0,2.06,.02],[.5,.16,.32]));
 m.add(P(B,'#ff3d6e',[0,2.07,.2],[.2,.07,.02],null,E));m.add(P(B,'#ff3d6e',[0,2.07,.2],[.07,.2,.02],null,E));
 const h=[m.add(P(S,'#ff4d8d',[-.12,0,0],[.17,.17,.17],null,E)),m.add(P(S,'#ff4d8d',[.12,0,0],[.17,.17,.17],null,E)),m.add(P(K,'#ff4d8d',[0,0,0],[.3,.32,.17],[PI,0,0],E))];
 return finish(m,(t)=>{const y=1.9+Math.sin(t*2.4)*.07,x=.85;h[0].pos=[x-.12,y+.12,.3];h[1].pos=[x+.12,y+.12,.3];h[2].pos=[x,y-.04,.3]});
};
/* 9 Schemen – Ninja */
builders[9]=()=>{
 const m=chibi({skin:'#2d2d3d',body:'#5a5a72',pants:'#2d2d3d',shoes:'#1c1c28',bw:.85,handCol:'#2d2d3d',noEyes:true,armCol:'#4a4a62'});
 m.add(P(B,'#ffe0c2',[0,1.57,.45],[.4,.1,.12]));
 for(const sx of[-1,1])m.add(P(B,'#ffffff',[sx*.14,1.575,.51],[.12,.05,.04],[0,0,-sx*.2],{outline:false}));
 m.add(P(C,'#e03a4a',[0,1.72,0],[.57,.09,.53]));
 const t1=m.add(P(B,'#e03a4a',[-.08,1.72,-.62],[.07,.05,.5],[.2,0,0])),t2=m.add(P(B,'#e03a4a',[.08,1.7,-.6],[.07,.05,.4],[.3,0,0]));
 m.add(P(B,'#cfd8e0',[-.1,1.15,-.4],[.05,1.1,.04],[0,0,.55]));m.add(P(B,'#222222',[.22,.65,-.4],[.07,.22,.06],[0,0,.55]));
 m.add(P(B,'#e03a4a',[0,1.18,.0],[.7,.08,.5]));
 return finish(m,(t)=>{t1.rot=[.2+Math.sin(t*5)*.25,Math.sin(t*3)*.2,0];t2.rot=[.3+Math.sin(t*5+1)*.25,-Math.sin(t*3)*.2,0]});
};
/* 10 Bombo – Sprengmeister */
builders[10]=()=>{
 const m=chibi({skin:'#f0c090',body:'#ff9f43',pants:'#40342a',shoes:'#231a12',bw:1.35,handCol:'#40342a',armCol:'#ff9f43'});
 m.add(P(D,'#2b2b33',[0,1.62,0],[.6,.5,.56]));
 m.add(P(C,'#8b6b3a',[0,2.2,0],[.05,.3,.05],[.3,0,0]));
 const sp=m.add(P(S,'#ffe14d',[0,2.38,.08],[.1,.1,.1],null,E));
 for(const sx of[-1,1])m.add(P(B,'#2b1a10',[sx*.2,1.72,.48],[.2,.05,.04],[0,0,-sx*.4],{outline:false}));
 ring(6,(a)=>{const x=Math.cos(a)*.62,z=Math.sin(a)*.5;m.add(P(S,'#26262e',[x,.66,z],[.13,.13,.13]));m.add(P(S,'#ff4d4d',[x,.8,z],[.05,.05,.05],null,E))});
 return finish(m,(t)=>{sp.sc=[.08+Math.abs(Math.sin(t*14))*.07,.08+Math.abs(Math.sin(t*14))*.07,.08+Math.abs(Math.sin(t*14))*.07]});
};
/* 11 Gravo – Schwerkraft-Magier */
builders[11]=()=>{
 const m=chibi({skin:'#e8e0ff',body:'#7a6cff',pants:'#5a4de0',shoes:'#2e2680',noLegs:true,handCol:'#e8e0ff',armCol:'#6a5cf0'});
 m.add(P(K,'#5a4de0',[0,.55,0],[.66,1.0,.6]));
 m.add(P(D,'#4a3fc0',[0,1.62,-.06],[.62,.52,.6]));m.add(P(K,'#4a3fc0',[0,2.12,-.3],[.3,.5,.3],[-.8,0,0]));
 for(const sx of[-1,1])m.add(P(S,'#e8f6ff',[sx*.2,1.58,.44],[.1,.12,.07],null,E));
 m.add(P(C,'#c9b27a',[.9,1.0,.15],[.05,1.9,.05]));
 const orb=m.add(P(S,'#a98bff',[.9,2.02,.15],[.15,.15,.15],null,E));
 const os=[0,1,2].map(i=>m.add(P(S,i%2?'#65f0ff':'#d99bff',[0,0,0],[.1,.1,.1],null,E)));
 return finish(m,(t)=>{os.forEach((o,i)=>{const a=t*1.8+i*2.09;o.pos=[Math.cos(a)*.85,1.2+Math.sin(a*1.3)*.25,Math.sin(a)*.6]});orb.sc=[.15+Math.sin(t*4)*.02,.15+Math.sin(t*4)*.02,.15+Math.sin(t*4)*.02]});
};
/* 12 Falke – Scharfschütze mit Flügeln */
builders[12]=()=>{
 const m=chibi({skin:'#e8d9a8',body:'#c9b27a',pants:'#8a7440',shoes:'#ff9f1c',handCol:'#e8d9a8',armCol:'#c9b27a'});
 m.add(P(K,'#ff9f1c',[0,1.47,.64],[.17,.42,.17],[PI/2,0,0]));
 ring(3,(a,i)=>m.add(P(K,'#8a5a2a',[(i-1)*.14,2.08,-.05],[.07,.4,.07],[-.5,0,(i-1)*.3])));
 m.add(P(S,'#fff7df',[0,.9,.18],[.3,.42,.22]));
 const wl=m.add(P(B,'#b89a5a',[-.78,1.15,-.3],[.1,.95,.45],[0,.4,.35])),wr=m.add(P(B,'#b89a5a',[.78,1.15,-.3],[.1,.95,.45],[0,-.4,-.35]));
 m.add(P(B,'#9a7c40',[0,.55,-.4],[.28,.5,.06],[.2,0,0]));
 m.add(P(C,'#26262e',[.24,1.6,.42],[.07,.34,.07],[PI/2,0,0]));m.add(P(S,'#65f0ff',[.24,1.6,.6],[.06,.06,.04],null,E));
 return finish(m,(t)=>{const f=Math.sin(t*3)*.12;wl.rot=[0,.4,.35+f];wr.rot=[0,-.4,-.35-f]});
};
/* 13 Aegis – Paladin mit Turmschild */
builders[13]=()=>{
 const m=chibi({skin:'#f2cfae',body:'#5aa9ff',pants:'#2d6ad6',shoes:'#dfe8f2',bw:1.25,armCol:'#dfe8f2',handCol:'#dfe8f2'});
 m.add(P(D,'#dfe8f2',[0,1.6,0],[.62,.52,.58]));m.add(P(B,'#1c2430',[0,1.55,.52],[.46,.08,.06]));
 m.add(P(B,'#ffd24a',[0,2.15,-.05],[.08,.36,.42]));
 for(const sx of[-1,1])m.add(P(S,'#dfe8f2',[sx*.66,1.3,0],[.26,.2,.26]));
 const cape=m.add(P(B,'#2d6ad6',[0,.95,-.4],[.8,1.1,.07]));
 m.add(P(B,'#dfe8f2',[-.78,.95,.36],[.7,1.0,.1]));m.add(P(B,'#ffd24a',[-.78,.98,.43],[.28,.4,.04],null,E));
 return finish(m,(t)=>{cape.rot=[Math.sin(t*2)*.05,0,0]});
};
/* 14 Vlad – Vampir */
builders[14]=()=>{
 const m=chibi({skin:'#f3e6ee',body:'#c2315a',pants:'#2b1020',shoes:'#150810',handCol:'#f3e6ee',armCol:'#2b1020',eyeCol:'#d6192e'});
 m.add(P(D,'#1c1018',[0,1.66,-.05],[.58,.42,.55]));
 m.add(P(B,'#2b1020',[0,1.3,-.34],[.86,.6,.08],[-.2,0,0]));m.add(P(B,'#2b1020',[-.4,1.35,-.1],[.08,.55,.5],[0,0,.15]));m.add(P(B,'#2b1020',[.4,1.35,-.1],[.08,.55,.5],[0,0,-.15]));
 for(const sx of[-1,1])m.add(P(K,'#ffffff',[sx*.09,1.33,.47],[.045,.11,.045],[PI,0,0]));
 m.add(P(S,'#ff2e63',[0,1.12,.38],[.1,.07,.05]));
 const wl=m.add(P(B,'#4a1630',[-.8,1.1,-.35],[.08,.8,.55],[0,.5,.5])),wr=m.add(P(B,'#4a1630',[.8,1.1,-.35],[.08,.8,.55],[0,-.5,-.5]));
 return finish(m,(t)=>{const f=Math.sin(t*3.2)*.14;wl.rot=[0,.5,.5+f];wr.rot=[0,-.5,-.5-f]});
};
/* 15 Rascal – Fuchs */
builders[15]=()=>{
 const m=chibi({skin:'#ff9248',body:'#ff9248',pants:'#8a4a22',shoes:'#2a1a10',handCol:'#2a1a10',armCol:'#ff9248',eyeCol:'#101010',hs:1.05});
 m.add(P(S,'#fff2e0',[0,.9,.2],[.32,.42,.24]));
 for(const sx of[-1,1]){m.add(P(K,'#ff9248',[sx*.32,2.2,-.02],[.2,.55,.14],[0,0,-sx*.2]));m.add(P(K,'#ffb3c8',[sx*.32,2.17,.05],[.1,.34,.08],[0,0,-sx*.2],E));m.add(P(S,'#fff2e0',[sx*.3,1.4,.36],[.22,.16,.2]))}
 m.add(P(S,'#2a1a10',[0,1.5,.56],[.1,.08,.08]));
 const tail=[0,1,2].map(i=>m.add(P(S,i===2?'#ffffff':'#ff9248',[0,0,0],[.2-i*.02,.2-i*.02,.3],null)));
 return finish(m,(t)=>{tail.forEach((p,i)=>{const a=Math.sin(t*2.4-i*.6)*.3;p.pos=[Math.sin(a)*.3*(i+1)*.6+.05,.62+i*.28,-.4-i*.16]})});
};
/* 16 Thora – Kriegerin mit Hammer */
builders[16]=()=>{
 const m=chibi({skin:'#f4cfae',body:'#9fb7c9',pants:'#4a5a6a',shoes:'#2a323a',bw:1.2,armCol:'#7c93a6',handCol:'#f4cfae'});
 m.add(P(D,'#cfd8e0',[0,1.65,0],[.6,.4,.56]));
 for(const sx of[-1,1]){m.add(P(B,'#ffffff',[sx*.62,1.88,0],[.05,.36,.2],[0,0,sx*.7]));for(let i=0;i<4;i++)m.add(P(S,'#e0b04a',[sx*.5,1.45-i*.2,-.12],[.09,.09,.09]))}
 m.add(P(C,'#e0b04a',[0,.64,0],[.5,.1,.42]));
 const h=m.add(P(C,'#6b4a2b',[.8,1.0,.3],[.07,1.35,.07],[.0,0,.15]));
 const hd=m.add(P(B,'#7c8794',[.93,1.72,.3],[.55,.36,.36],[0,0,.15]));
 return finish(m,(t,pose)=>{const r=m.arms[1];r.ax=-.9-pose*1.2;r.az=.55;limb(r);const a=-.15+Math.sin(t*2)*.03;h.pos=[r.h.pos[0],r.h.pos[1]+.2,r.h.pos[2]];h.rot=[0,0,-a];hd.pos=[r.h.pos[0]+.12,r.h.pos[1]+.88,r.h.pos[2]];hd.rot=[0,0,-a]});
};
/* 17 Draco – kleiner Drache */
builders[17]=()=>{
 const m=chibi({skin:'#ff5c3a',body:'#ff5c3a',pants:'#c23a1e',shoes:'#ffd9a0',handCol:'#ff5c3a',armCol:'#ff5c3a',eyeCol:'#ffe14d',hs:1.05});
 m.add(P(S,'#ffd9a0',[0,.88,.2],[.33,.44,.25]));
 m.add(P(S,'#ff7a55',[0,1.45,.5],[.3,.22,.3]));
 for(const sx of[-1,1]){m.add(P(S,'#2a1010',[sx*.1,1.5,.78],[.04,.04,.04],null,{outline:false}));m.add(P(K,'#ffe9b0',[sx*.32,2.08,-.05],[.1,.42,.1],[0,0,-sx*.3]))}
 for(let i=0;i<4;i++)m.add(P(K,'#ffb02e',[0,1.6-i*.28,-.42-(i>1?.02:0)],[.08,.2,.08],[-1.1,0,0]));
 const wl=m.add(P(B,'#a3341c',[-.72,1.25,-.3],[.06,.7,.5],[0,.5,.5])),wr=m.add(P(B,'#a3341c',[.72,1.25,-.3],[.06,.7,.5],[0,-.5,-.5]));
 const tl=[0,1,2,3].map(i=>m.add(P(i===3?K:S,i===3?'#ffb02e':'#ff5c3a',[0,0,0],i===3?[.12,.3,.12]:[.17-i*.03,.17-i*.03,.26],i===3?[PI/2,0,0]:null)));
 return finish(m,(t)=>{const f=Math.sin(t*3)*.12;wl.rot=[0,.5,.5+f];wr.rot=[0,-.5,-.5-f];tl.forEach((p,i)=>{p.pos=[Math.sin(t*2-i*.7)*.12*(i+1)*.5,.5+i*.07,-.4-i*.2]})});
};
/* 18 Robi – Roboter mit Zahnrad */
builders[18]=()=>{
 const m=chibi({skin:'#dde7ea',body:'#6fd3c0',pants:'#4a8f84',shoes:'#9aa7ab',noEyes:true,armCol:'#9aa7ab',handCol:'#dde7ea'});
 m.head.g=B;m.head.gHi=B;m.head.gLo=B;m.head.sc=[.78,.6,.6];m.head.base.sc=[.78,.6,.6];
 for(const sx of[-1,1])m.add(P(B,'#65f0ff',[sx*.2,1.58,.31],[.18,.16,.05],null,E));
 m.add(P(B,'#26323a',[0,1.35,.31],[.34,.06,.05],null,{outline:false}));
 m.add(P(C,'#cfd8e0',[0,2.0,0],[.04,.28,.04]));m.add(P(S,'#ff4d4d',[0,2.18,0],[.08,.08,.08],null,E));
 m.add(P(B,'#3a4a50',[0,.95,.39],[.34,.28,.04]));m.add(P(B,'#7dff9b',[0,.98,.42],[.2,.08,.02],null,E));
 const gear=m.add(P(C,'#f4c542',[0,1.02,-.44],[.32,.12,.32],[PI/2,0,0]));
 const teeth=[];ring(8,()=>teeth.push(m.add(P(B,'#f4c542',[0,0,-.44],[.1,.1,.12]))));
 return finish(m,(t)=>{gear.rot=[PI/2,0,t*1.5];teeth.forEach((p,i)=>{const a=t*1.5+i/8*PI*2;p.pos=[Math.cos(a)*.36,1.02+Math.sin(a)*.36,-.44];p.rot=[0,0,a]})});
};

A.MODEL_COUNT=builders.length;
A.buildModel=function(i){
 const b=builders[i%builders.length];
 const o=b();o.id=i;return o;
};
})();
