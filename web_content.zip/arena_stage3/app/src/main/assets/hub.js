/* Arena Stars – Raum-Logik (wird vom Node-Server UND vom Handy im lokalen Modus ohne Server benutzt) */
(function (root, factory) { if (typeof module === 'object' && module.exports) module.exports = factory(); else root.ArenaHub = factory(); })(typeof self !== 'undefined' ? self : this, function () {
  const MODES = {
    ndu: { name: 'Duell 1v1', max: 2, per: 1, teams: true },
    ntm: { name: 'Team-Knockout 3v3', max: 6, per: 3, teams: true },
    nco: { name: 'Koop 3 gegen Bots', max: 3, per: 3, teams: false }
  };
  function create() {
    const clients = new Map(), rooms = new Map(); let nextId = 1;
    function code() { const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ'; let s; do { s = ''; for (let i = 0; i < 4; i++) s += A[Math.floor(Math.random() * A.length)]; } while (rooms.has(s)); return s; }
    const send = (c, o) => { try { c.send(o); } catch (e) {} };
    function pub(r) {
      return { code: r.code, mode: r.mode, friendly: r.friendly, adm: !!r.adm, pool: r.pool, quick: r.quick, phase: r.phase, host: r.host, lan: !!r.lan,
        members: r.members.map(id => { const m = clients.get(id); return { id, name: m.name, admin: m.admin, team: m.team, brawler: m.brawler, pl: m.pl }; }) };
    }
    function bcast(r, obj, except) { for (const id of r.members) if (id !== except) { const m = clients.get(id); if (m) send(m, obj); } }
    function sync(r) { bcast(r, { t: 'room', room: pub(r) }); }
    function teamFor(r, c) {
      const M = MODES[r.mode]; if (!M.teams) return 'A';
      const cnt = { A: 0, B: 0 }; for (const id of r.members) if (id !== c.id) cnt[clients.get(id).team]++;
      return cnt.A <= cnt.B ? 'A' : 'B';
    }
    function canJoin(c, r) {
      if (!r) return 'Raum nicht gefunden';
      if (r.pool === 'admin' && !c.admin) return 'Dieser Raum ist nur für Admin-Accounts';
      if (r.phase !== 'lobby') return 'Die Runde läuft bereits';
      if (r.members.length >= MODES[r.mode].max) return 'Raum ist voll';
      return null;
    }
    function addTo(r, c) { c.room = r.code; c.team = teamFor(r, c); r.members.push(c.id); sync(r); armQuick(r); }
    function newRoom(c, mode, friendly, open, quick, lan) {
      const r = { code: code(), mode, friendly: !!friendly, pool: (c.admin && !open) ? 'admin' : 'normal', quick: !!quick, lan: !!lan, phase: 'lobby', host: c.id, members: [], timer: null };
      rooms.set(r.code, r); addTo(r, c); return r;
    }
    function leave(c) {
      const r = rooms.get(c.room); c.room = null; if (!r) return;
      r.members = r.members.filter(i => i !== c.id);
      if (!r.members.length) { clearTimeout(r.timer); rooms.delete(r.code); return; }
      if (r.host === c.id) r.host = r.members[0];
      if (r.phase === 'play') bcast(r, { t: 'left', id: c.id });
      else r.members.forEach(id => { const m = clients.get(id); if (!MODES[r.mode].teams) m.team = 'A'; });
      sync(r); if (r.phase !== 'play') armQuick(r);
    }
    function startRoom(r) {
      if (r.phase !== 'lobby') return; clearTimeout(r.timer); r.timer = null; r.phase = 'play';
      bcast(r, { t: 'start', room: pub(r), seed: Math.floor(Math.random() * 1e9) });
    }
    function armQuick(r) {
      if (!r.quick || r.phase !== 'lobby') return;
      clearTimeout(r.timer); r.timer = null;
      const M = MODES[r.mode], n = r.members.length;
      if (n >= M.max) { r.timer = setTimeout(() => startRoom(r), 3000); return; }
      if (n >= 2) r.timer = setTimeout(() => { if (rooms.get(r.code) === r && r.members.length >= 2) startRoom(r); }, 12000);
    }
    function connect(sendFn) { const c = { id: 'p' + (nextId++), send: sendFn, name: 'Spieler', admin: false, room: null, team: 'A', brawler: 0, pl: 1, last: Date.now() }; clients.set(c.id, c); return c; }
    function disconnect(c) { if (!clients.has(c.id)) return; clients.delete(c.id); leave(c); }
    function onMsg(c, m) {
      c.last = Date.now();
      switch (m.t) {
        case 'hello': c.name = String(m.name || 'Spieler').slice(0, 14); c.admin = !!m.admin; c.brawler = m.brawler | 0; c.pl = m.pl | 0 || 1; send(c, { t: 'hello', id: c.id }); break;
        case 'ping': send(c, { t: 'pong' }); break;
        case 'create': { if (c.room) leave(c); const mode = MODES[m.mode] ? m.mode : 'ntm'; newRoom(c, mode, m.friendly, m.open, false, m.lan); break; }
        case 'quick': {
          if (c.room) leave(c); const mode = MODES[m.mode] ? m.mode : 'ntm', pool = c.admin ? 'admin' : 'normal';
          let r = [...rooms.values()].find(x => x.quick && x.mode === mode && x.pool === pool && x.phase === 'lobby' && x.members.length < MODES[x.mode].max);
          if (r) addTo(r, c); else newRoom(c, mode, false, false, true);
          break;
        }
        case 'join': {
          const r = rooms.get(String(m.code || '').toUpperCase()), e = canJoin(c, r);
          if (e) { send(c, { t: 'err', msg: e }); break; }
          if (c.room) leave(c); addTo(r, c); break;
        }
        case 'list': {
          const out = [...rooms.values()].filter(r => !r.quick && !r.friendly && !r.lan && r.phase === 'lobby' && (r.pool === 'normal' || c.admin)).map(r => ({ code: r.code, mode: r.mode, n: r.members.length, max: MODES[r.mode].max, pool: r.pool, host: clients.get(r.host).name }));
          send(c, { t: 'list', rooms: out }); break;
        }
        case 'me': c.brawler = m.brawler | 0; c.pl = m.pl | 0 || 1; { const r = rooms.get(c.room); if (r) sync(r); } break;
        case 'team': {
          const r = rooms.get(c.room); if (!r || r.phase !== 'lobby' || !MODES[r.mode].teams) break;
          const t = m.team === 'B' ? 'B' : 'A'; let n = 0; for (const id of r.members) if (id !== c.id && clients.get(id).team === t) n++;
          if (n < MODES[r.mode].per) { c.team = t; sync(r); } else send(c, { t: 'err', msg: 'Team ist voll' });
          break;
        }
        case 'mode': {
          const r = rooms.get(c.room); if (!r || r.host !== c.id || r.phase !== 'lobby' || !MODES[m.mode]) break;
          if (r.members.length > MODES[m.mode].max) { send(c, { t: 'err', msg: 'Zu viele Spieler für diesen Modus' }); break; }
          r.mode = m.mode; const per = { A: 0, B: 0 };
          r.members.forEach(id => { const x = clients.get(id); if (!MODES[r.mode].teams) x.team = 'A'; else { if (per[x.team] >= MODES[r.mode].per) x.team = x.team === 'A' ? 'B' : 'A'; per[x.team]++; } });
          sync(r); break;
        }
        case 'opts': { const r = rooms.get(c.room); if (!r || r.host !== c.id || r.phase !== 'lobby') break; if (!r.quick) { r.friendly = !!m.friendly; if (c.admin) r.pool = m.open ? 'normal' : 'admin'; r.adm = !!(c.admin && r.friendly && m.adm); } sync(r); break; }
        case 'start': {
          const r = rooms.get(c.room); if (!r || r.host !== c.id || r.phase !== 'lobby') break;
          const M = MODES[r.mode], A = r.members.filter(i => clients.get(i).team === 'A').length, B = r.members.length - A;
          if (!r.friendly && M.teams && (A === 0 || B === 0)) { send(c, { t: 'err', msg: 'Für Wertungsspiele brauchen beide Teams Spieler' }); break; }
          if (!r.friendly && !M.teams && r.members.length < 2) { send(c, { t: 'err', msg: 'Mindestens 2 Spieler nötig (oder Testspiel nutzen)' }); break; }
          startRoom(r); break;
        }
        case 'rel': {
          const r = rooms.get(c.room); if (!r || r.phase !== 'play') break;
          const msg = { t: 'rel', from: c.id, d: m.d };
          if (m.to) { const o = clients.get(m.to); if (o && o.room === c.room) send(o, msg); } else bcast(r, msg, c.id);
          break;
        }
        case 'endrm': { const r = rooms.get(c.room); if (!r || r.host !== c.id || r.phase !== 'play') break; r.phase = 'lobby'; r.quick = false; sync(r); bcast(r, { t: 'backroom' }); break; }
        case 'leave': leave(c); send(c, { t: 'left_room' }); break;
      }
    }
    return { connect, disconnect, onMsg, clients, rooms, MODES };
  }
  return { create, MODES };
});
