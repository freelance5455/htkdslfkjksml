/* Arena Stars – 3D-Kampfarena (gekippte Kamera wie bei Brawl-Stars-artigen Spielen), nutzt die eigene 3D-Engine */
(function(){
'use strict';
const A=window.A3D,G=A.geo,P=A.part,B=G.box,C=G.cyl,K=G.cone,SL=G.sphereL;
const U=40,CH=1.4;                       // 1 Welteinheit = 40 Spielpixel
const PI=Math.PI;
const TH={
 solo:{bg:'#1d3f2b',a:'#63c458',b:'#58b84f',gasA:'#8f55b8',gasB:'#7f49a8',wall:'#9aa3ad',top:'#c5ccd6',crate:'#c58a45',bush:'#2f9a4a',bush2:'#4fc468',fence:'#a8743f',fenceTop:'#dba865',tuft:'#2f7d3c',flower:['#ffe45c','#ff8ab5','#ffffff']},
 duo:{bg:'#1d4a38',a:'#78cb6f',b:'#6cc064',gasA:'#8f55b8',gasB:'#7f49a8',wall:'#b4a58f',top:'#dccfb8',crate:'#c58a45',bush:'#2e9a58',bush2:'#52c978',fence:'#9b6a3a',fenceTop:'#d9a05a',tuft:'#3a8a45',flower:['#ff6f91','#ffd24a','#9be8ff']},
 gems:{bg:'#1a1236',a:'#7b64bd',b:'#6f59b2',gasA:'#8f55b8',gasB:'#7f49a8',wall:'#5a4a8a',top:'#9a88d6',crate:'#7a5aa8',bush:'#3f8f8a',bush2:'#5fc0b4',fence:'#4a3a7a',fenceTop:'#8d7cc4',tuft:'#5a479a',flower:['#c77dff','#65f0ff','#ffffff']},
 duel:{bg:'#4a3416',a:'#e3bb78',b:'#d6ac68',gasA:'#8f55b8',gasB:'#7f49a8',wall:'#b07a4c',top:'#d9a672',crate:'#a8683a',bush:'#6a9a3a',bush2:'#8cc050',fence:'#8a5a30',fenceTop:'#c98f52',tuft:'#b58a4a',flower:['#fff1b8','#ff9a4a','#ffffff']},
 heist:{bg:'#11161e',a:'#7e8a9a',b:'#727e8e',gasA:'#8f55b8',gasB:'#7f49a8',wall:'#4a5a70',top:'#8fa3bd',crate:'#c58a45',bush:'#3a7a5a',bush2:'#52a67c',fence:'#3a4658',fenceTop:'#7a8aa0',tuft:'#5a6678',flower:['#ffd24a','#65f0ff','#ffffff']},
 horde:{bg:'#0f1a14',a:'#4f7a52',b:'#47704a',gasA:'#8f55b8',gasB:'#7f49a8',wall:'#6f7f70',top:'#9fb09f',crate:'#8a5a38',bush:'#2a6a3a',bush2:'#3f8f50',fence:'#5a4a38',fenceTop:'#8a7254',tuft:'#2f5a38',flower:['#d8e8c0','#9bd68a','#ffffff']},
 bounty:{bg:'#3a2410',a:'#d9a864',b:'#cc9b58',gasA:'#8f55b8',gasB:'#7f49a8',wall:'#a8683a',top:'#d99a62',crate:'#9a5a30',bush:'#6a8a3a',bush2:'#8cb04e',fence:'#7a4a28',fenceTop:'#b8783e',tuft:'#a9783c',flower:['#ff8a4a','#fff1b8','#ffffff']},
 boss:{bg:'#120b12',a:'#4d3d48',b:'#43343e',gasA:'#8f55b8',gasB:'#7f49a8',wall:'#2e2833',top:'#60546c',crate:'#6a3a3a',bush:'#3a5a3a',bush2:'#4f7a50',fence:'#2a2230',fenceTop:'#7a4a5a',tuft:'#2a1f2a',flower:['#ff5a3a','#ffb02e','#ff8a4a']}
};
const sc=new A.Scene();sc.ow=.05;sc.outCol='#0b1018';sc.light=[-.45,.85,.6];
const R={sc,th:TH.solo,mode:'solo',world:{w:1800,h:1200},W:800,H:400,camX:0,camY:0,statics:[],fence:[],decor:[],q:1,ema:16,tt:0,lastT:0,
 gemObj:null,turretObjs:new Map(),vis:[],obsVis:[],shk:[0,0]};
let f=[0,0,-1],r=[1,0,0],u=[0,1,0],Pp=[0,0,0],FOC=600,CX=0,CY=0;
function norm(v){const l=Math.hypot(v[0],v[1],v[2])||1;return[v[0]/l,v[1]/l,v[2]/l]}
function cross(a,b){return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]}
function prep(){
 const c=sc.cam;Pp=c.pos;f=norm([c.tgt[0]-Pp[0],c.tgt[1]-Pp[1],c.tgt[2]-Pp[2]]);r=norm(cross(f,[0,1,0]));u=cross(r,f);FOC=c.focal;CX=c.cx;CY=c.cy;
}
/* Welt (Spielpixel) + Höhe (Einheiten) -> Bildschirm: [sx,sy,Pixel pro Einheit] */
function proj(x,y,h){
 const dx=x/U-Pp[0],dy=(h||0)-Pp[1],dz=y/U-Pp[2];
 const z=dx*f[0]+dy*f[1]+dz*f[2];if(z<.3)return null;
 return[CX+FOC*(dx*r[0]+dy*r[1]+dz*r[2])/z,CY-FOC*(dx*u[0]+dy*u[1]+dz*u[2])/z,FOC/z];
}
R.project=proj;A.Arena=R;
function hash(i,j){let h=(i*374761393+j*668265263)^0x5bd1e995;h=(h^(h>>>13))*1274126177;return((h^(h>>>16))>>>0)/4294967295}

/* ---------- Aufbau ---------- */
function box(col,x,y,z,w,h,d,o){return P(B,col,[x,y,z],[w,h,d],null,o)}
function buildObstacle(o,th,mode){
 const ww=o.w/U,hh=o.h/U,parts=[];
 if(o.type==='wall'){
  parts.push(box(th.wall,0,.5,0,ww,1.0,hh));
  parts.push(box(th.top,0,1.07,0,ww*.94,.16,hh*.94));
  if(mode==='gems'){parts.push(P(K,'#d6a8ff',[0,1.45,0],[.38,.7,.38],null,{emissive:true,outline:false}))}
  else if(mode==='boss'){parts.push(P(K,'#ff5a3a',[0,1.4,0],[.26,.6,.26],null,{emissive:true,outline:false}))}
  else parts.push(box(th.wall,.0,1.25,0,ww*.4,.2,hh*.4));
 }else if(o.type==='crate'){
  parts.push(box(th.crate,0,.55,0,ww*.92,1.1,hh*.92));
  parts.push(box('#e0a860',0,1.13,0,ww*.98,.09,hh*.98));
  for(const sx of[-1,1])for(const sz of[-1,1])parts.push(box('#6a3f1c',sx*ww*.44,.55,sz*hh*.44,.12,1.12,.12));
 }else if(o.type==='pillar'){
  parts.push(P(C,th.wall,[0,1.1,0],[ww*.46,2.2,ww*.46]));
  parts.push(P(C,th.top,[0,2.25,0],[ww*.55,.22,ww*.55]));
  parts.push(P(K,'#ff5a3a',[0,2.75,0],[.3,.8,.3],null,{emissive:true,outline:false}));
 }else if(o.type==='bush'){
  const sp=[[-.5,.42,-.35,.62],[.5,.4,-.2,.58],[0,.55,.5,.64]];
  sp.forEach((s,i)=>parts.push(P(SL,i%2?th.bush2:th.bush,[s[0]*ww*.5,s[1],s[2]*hh*.5],[s[3]*.95,s[3]*.85,s[3]*.95],null,{outline:true})));
 }
 const ob=A.obj(parts,{pos:[o.x/U,0,o.y/U]});ob.layer=1;ob.outline=o.type!=='bush'||true;
 ob.cx=o.x;ob.cy=o.y;return ob;
}
function buildFence(world,th){
 const out=[],T=5;
 const seg=(x0,z0,x1,z1)=>{ // Strecke in Einheiten, in Stücken zu 5
  const len=Math.hypot(x1-x0,z1-z0),n=Math.max(1,Math.round(len/T));
  for(let i=0;i<n;i++){
   const a=i/n,b=(i+1)/n,xa=x0+(x1-x0)*a,za=z0+(z1-z0)*a,xb=x0+(x1-x0)*b,zb=z0+(z1-z0)*b,mx=(xa+xb)/2,mz=(za+zb)/2;
   const horiz=Math.abs(z1-z0)<.01,parts=[];
   const L=len/n;
   parts.push(box(th.fence,0,.55,0,horiz?L:.28,.2,horiz?.28:L));
   parts.push(box(th.fence,0,.95,0,horiz?L:.22,.16,horiz?.22:L));
   for(const s of[-.5,0,.5]){parts.push(box(th.fenceTop,horiz?s*L:0,.62,horiz?0:s*L,.36,1.3,.36))}
   const ob=A.obj(parts,{pos:[mx,0,mz]});ob.layer=1;ob.cx=mx*U;ob.cy=mz*U;out.push(ob);
  }
 };
 const w=world.w/U,h=world.h/U,m=-.3;
 seg(m,m,w-m,m);seg(m,h-m,w-m,h-m);seg(m,m,m,h-m);seg(w-m,m,w-m,h-m);
 return out;
}
function buildMine(world,th){
 const parts=[P(C,'#4a3a7a',[0,.18,0],[1.9,.36,1.9]),P(C,'#6a58a8',[0,.42,0],[1.5,.2,1.5])];
 const cs=[[0,0,1.9,.55],[-.7,.3,1.3,.38],[.7,-.2,1.5,.4],[.1,.75,1.1,.32],[-.3,-.7,1.2,.34]];
 cs.forEach((c,i)=>parts.push(P(K,i%2?'#d6a8ff':'#8ef0ff',[c[0],.5+c[2]*.5,c[1]],[c[3],c[2],c[3]],[(i-2)*.07,0,(i-2)*.08],{emissive:true,outline:false})));
 const ob=A.obj(parts,{pos:[world.w/2/U,0,world.h/2/U]});ob.layer=1;ob.cx=world.w/2;ob.cy=world.h/2;return ob;
}
function buildSafe(){
 const parts=[box('#6c7a8c',0,1.05,0,2.5,2.1,2.3),box('#8c9bb0',0,1.05,1.16,2.1,1.7,.1),box('#4e5a6a',0,2.15,0,2.6,.18,2.4)];
 parts.push(P(C,'#ffd24a',[0,1.15,1.25],[.55,.1,.55],[PI/2,0,0],{emissive:true,outline:false}));
 parts.push(box('#ffd24a',0,1.15,1.32,.1,.5,.06,{emissive:true,outline:false}));
 for(let i=0;i<3;i++)parts.push(box('#ffd24a',(i-1)*.7,2.38,0,.6,.22,.4,{emissive:true}));
 const o=A.obj(parts);o.layer=1;return o;
}
function gemObj(){
 const parts=[P(K,'#c77dff',[0,.34,0],[.34,.34,.34],null,{emissive:true,outline:false}),P(K,'#9a4dff',[0,.1,0],[.34,.34,.34],[PI,0,0],{emissive:true,outline:false})];
 const o=A.obj(parts);o.layer=1;o.outline=false;return o;
}
R.setup=function(mode,world,obstacles,extra){
 R.mode=mode;R.world=world;R.th=TH[mode]||TH.solo;
 R.statics=obstacles.map(o=>{const ob=buildObstacle(o,R.th,mode);o._o3=ob;return ob});
 R.fence=buildFence(world,R.th);
 R.decor=mode==='gems'?[buildMine(world,R.th)]:[];
 R.turretObjs.clear();R.safeObjs=[];
 R.gemObj=R.gemObj||gemObj();
 R.camX=world.w/2;R.camY=world.h/2;R.camInit=false;
};
R.resize=function(W,H){R.W=W;R.H=H;const c=sc.cam;c.focal=Math.min(W*.78,H*1.9);c.cx=W/2;c.cy=H*.5};
R.resize(800,400);
R.focus=function(x,y){R.camX=x;R.camY=y;R.camInit=true};

/* ---------- Figuren ---------- */
function charObj(e,idx){
 if(!e.o3||e.o3idx!==idx){e.o3=A.buildModel(idx);e.o3idx=idx;e.o3.layer=1;e.o3.outline=true;e._ph=0;e._w=0;e._t=Math.random()*5;e._lx=e.x;e._ly=e.y;e._yaw=0;e._face=e.angle||0}
 return e.o3;
}
function angDiff(a,b){let d=b-a;while(d>PI)d-=PI*2;while(d<-PI)d+=PI*2;return d}
function animChar(e,idx,dt,scale,isPlayer,lod,outline){
 const o=charObj(e,idx);
 const mv=Math.hypot(e.x-e._lx,e.y-e._ly)/Math.max(.001,dt);
 const moveAng=Math.atan2(e.y-e._ly,e.x-e._lx);e._lx=e.x;e._ly=e.y;
 const want=Math.min(1,mv/160);e._w+=(want-e._w)*Math.min(1,dt*9);
 e._ph+=dt*(5+8*e._w);e._t+=dt;
 if(e.atkT>0)e.atkT-=dt;
 if(e.aimT>0)e.aimT-=dt;
 let target=e._face;
 if(e.atkT>0||e.aimT>0||!isPlayer&&e.angle!==undefined)target=e.angle||0;
 else if(mv>20)target=moveAng;
 e._face+=angDiff(e._face,target)*Math.min(1,dt*14);
 const dead=e.alive===false;
 if(dead)e.deadT=(e.deadT||0)+dt;
 const k=dead?Math.max(0,1-e.deadT/.45):1;
 A.setLodLevel(o,lod);o.outline=outline;
 o.update(e._t,0,e._w,e._ph,Math.max(0,(e.atkT||0))/.28);
 o.scale=scale*(.15+.85*k);
 o.yaw=PI/2-e._face+(dead?e.deadT*9:0);
 o.pos[0]=e.x/U;o.pos[2]=e.y/U;o.pos[1]+=dead?e.deadT*2:0;
 o.visible=true;
 return o;
}
function ringPts(cx,cy,rad,n){const pts=[];for(let i=0;i<n;i++){const a=i/n*PI*2,p=proj(cx+Math.cos(a)*rad,cy+Math.sin(a)*rad,.02);pts.push(p)}return pts}
function strokeRing(ctx,cx,cy,rad,col,lw,alpha,n){
 const pts=ringPts(cx,cy,rad,n||36);if(pts.some(p=>!p))return;
 ctx.globalAlpha=alpha;ctx.strokeStyle=col;ctx.lineWidth=lw;ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.closePath();ctx.stroke();ctx.globalAlpha=1;
}
function shadow(ctx,x,y,rad,a){
 const c=proj(x,y,0),e=proj(x+rad,y,0);if(!c||!e)return;const rx=Math.abs(e[0]-c[0]),ry=rx*.62;
 ctx.fillStyle='rgba(0,0,0,'+a+')';ctx.beginPath();ctx.ellipse(c[0],c[1],rx,ry,0,0,PI*2);ctx.fill();
}

/* ---------- Boden ---------- */
function drawFloor(ctx,S){
 const th=R.th,w=R.world.w/U,h=R.world.h/U,T=2;
 const tx=R.camX/U,tz=R.camY/U;
 const i0=Math.max(0,Math.floor((tx-18)/T)),i1=Math.min(Math.ceil(w/T),Math.ceil((tx+18)/T));
 const j0=Math.max(0,Math.floor((tz-14)/T)),j1=Math.min(Math.ceil(h/T),Math.ceil((tz+9)/T));
 const nx=i1-i0+1,nz=j1-j0+1;if(nx<2||nz<2)return;
 const pts=new Array(nx*nz);
 for(let j=0;j<nz;j++)for(let i=0;i<nx;i++){
  const X=Math.min(w,(i0+i)*T),Z=Math.min(h,(j0+j)*T);
  pts[j*nx+i]=proj(X*U,Z*U,0);
 }
 const gas=S.gas;
 for(let j=0;j<nz-1;j++)for(let i=0;i<nx-1;i++){
  const p0=pts[j*nx+i],p1=pts[j*nx+i+1],p2=pts[(j+1)*nx+i+1],p3=pts[(j+1)*nx+i];
  if(!p0||!p1||!p2||!p3)continue;
  const gi=i0+i,gj=j0+j;
  let col=((gi+gj)&1)?th.a:th.b;
  if(gas){const cx=(gi+.5)*T*U,cy=(gj+.5)*T*U;if(Math.hypot(cx-gas.x,cy-gas.y)>gas.r)col=((gi+gj)&1)?th.gasA:th.gasB}
  ctx.fillStyle=col;ctx.beginPath();ctx.moveTo(p0[0],p0[1]);ctx.lineTo(p1[0],p1[1]);ctx.lineTo(p2[0],p2[1]);ctx.lineTo(p3[0],p3[1]);ctx.closePath();ctx.fill();
 }
 // Details (Grasbüschel/Blumen) – deterministisch pro Kachel
 if(R.q>=1){
  ctx.lineWidth=1.6;ctx.strokeStyle=th.tuft;ctx.beginPath();
  const fl=[];
  for(let j=j0;j<j1;j++)for(let i=i0;i<i1;i++){
   for(let k=0;k<2;k++){
    const hx=hash(i*3+k,j*7+1),hz=hash(i*5+k,j*3+9),X=(i+hx)*T*U,Z=(j+hz)*T*U;
    const p=proj(X,Z,0);if(!p)continue;const s=p[2]*.2;
    if(k===0&&hx>.55){fl.push(p[0],p[1],s,Math.floor(hz*3))}else{ctx.moveTo(p[0]-s,p[1]);ctx.lineTo(p[0]-s*.2,p[1]-s*1.3);ctx.moveTo(p[0]+s,p[1]);ctx.lineTo(p[0]+s*.2,p[1]-s*1.3);ctx.moveTo(p[0],p[1]);ctx.lineTo(p[0],p[1]-s*1.6)}
   }
  }
  ctx.stroke();
  for(let i=0;i<fl.length;i+=4){ctx.fillStyle=th.flower[fl[i+3]%3];ctx.beginPath();ctx.arc(fl[i],fl[i+1]-fl[i+2],Math.max(1.5,fl[i+2]*.55),0,PI*2);ctx.fill()}
 }
}

/* ---------- Haupt-Render ---------- */
R.render=function(ctx,S,dt){
 const now=performance.now();
 R.ema=R.ema*.92+Math.min(100,(R.lastT?now-R.lastT:16))*.08;R.lastT=now;
 R.qT=(R.qT||0)+dt;
 if(R.qT>1){R.qT=0;if(R.ema>31&&R.q>0)R.q--;else if(R.ema<19&&R.q<2)R.q++}
 const q=R.q,W=R.W,H=R.H,world=R.world,P0=S.player;
 // Kamera
 const halfX=Math.min(world.w/2,(W/2)/sc.cam.focal*17.6*U*1.05),halfY=Math.min(world.h/2,8.2*U);
 let tx=P0?P0.x:world.w/2,ty=P0?P0.y+10:world.h/2;
 tx=Math.max(halfX-60,Math.min(world.w-halfX+60,tx));ty=Math.max(halfY-30,Math.min(world.h-halfY+90,ty));
 if(world.w/2<halfX)tx=world.w/2;
 if(!R.camInit){R.camX=tx;R.camY=ty;R.camInit=true}
 const kk=Math.min(1,dt*6.5);R.camX+=(tx-R.camX)*kk;R.camY+=(ty-R.camY)*kk;
 const shx=S.shake?(Math.random()-.5)*S.shake*.9:0,shy=S.shake?(Math.random()-.5)*S.shake*.9:0;
 const cam=sc.cam;
 cam.tgt=[R.camX/U+shx/U,.6,R.camY/U+shy/U];
 cam.pos=[cam.tgt[0],cam.tgt[1]+13.6,cam.tgt[2]+11.2];
 prep();
 ctx.fillStyle=R.th.bg;ctx.fillRect(0,0,W,H);
 drawFloor(ctx,S);
 // Bodenmarkierungen
 if(S.gas){strokeRing(ctx,S.gas.x,S.gas.y,S.gas.r,'#e9b6ff',4,.85,72);strokeRing(ctx,S.gas.x,S.gas.y,S.gas.r-6,'#b46ae0',2,.6,72)}
 if(P0&&S.showRange&&P0.range){strokeRing(ctx,P0.x,P0.y,P0.range,'#ffffff',2,.22,56)}
 if(S.target&&P0){const a=proj(P0.x,P0.y,.05),b=proj(S.target.x,S.target.y,.05);if(a&&b){ctx.strokeStyle='rgba(255,90,70,.7)';ctx.lineWidth=3;ctx.setLineDash([8,6]);ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();ctx.setLineDash([])}}
 // Kristalle / Schatten / Ringe
 const gemsList=S.pickups||[];
 for(const g of gemsList)shadow(ctx,g.x,g.y,10,.28);
 for(const t of S.turrets||[])shadow(ctx,t.x,t.y,18,.3);
 const view=(x,y)=>Math.abs(x-R.camX)<19*U&&y-R.camY>-15*U&&y-R.camY<10*U;
 // Objekte zusammenstellen
 const objs=[];
 for(const o of R.statics)if(view(o.cx,o.cy))objs.push(o);
 for(const o of R.fence)if(view(o.cx,o.cy))objs.push(o);
 for(const o of R.decor)objs.push(o);
 // Figuren
 const ents=[];
 const lodB=q>=2?1:0,outB=q>=1;
 for(const sf of S.safes||[]){if(sf.hp<=0)continue;if(!sf._o3)sf._o3=buildSafe();sf._o3.pos=[sf.x/U,0,sf.y/U];if(view(sf.x,sf.y))objs.push(sf._o3);sf._ring='#ff4b4b';sf.sc3=1.0;ents.push(sf)}
 if(P0&&P0.alive!==false){const o=animChar(P0,S.selected,dt,P0.sc3||CH,true,q>=1?1:0,true);objs.push(o);ents.push(P0);P0._ring='#ffd24a'}
 if(S.ally&&S.ally.alive){const e=S.ally;const o=animChar(e,e.model,dt,CH,false,lodB,outB);objs.push(o);ents.push(e);e._ring='#58b8ff'}
 for(const b of S.bots){
  if(b.alive===false&&(b.deadT||0)>.45)continue;
  if(b.hidden&&b.alive!==false)continue;
  if(!view(b.x,b.y)&&b.alive!==false){continue}
  const o=animChar(b,b.model,dt,b.sc3||CH,false,Math.hypot(b.x-R.camX,b.y-R.camY)<10*U?lodB:0,outB&&(b.boss||Math.hypot(b.x-R.camX,b.y-R.camY)<12*U));
  objs.push(o);if(b.alive!==false){ents.push(b);b._ring=b.friend?'#58b8ff':'#ff4b4b'}
 }
 for(const t of S.turrets||[]){
  let o=R.turretObjs.get(t);
  if(!o){o=A.obj([P(C,'#4a5568',[0,.2,0],[.55,.4,.55]),P(C,'#7be0d0',[0,.55,0],[.38,.3,.38]),P(B,'#2f3a4a',[0,.6,.5],[.2,.2,1.0])],{});o.layer=1;R.turretObjs.set(t,o);o.parts[2].pos=[0,.6,.5]}
  o.pos=[t.x/U,0,t.y/U];o.yaw=PI/2-(t.angle||0);objs.push(o);
 }
 const go=R.gemObj;
 for(const g of gemsList){
  if(!view(g.x,g.y))continue;
  const c=Object.assign({},go);c.parts=go.parts;c.pos=[g.x/U,.45+Math.sin((S.clock||0)*3+g.x)*.1,g.y/U];c.yaw=(S.clock||0)*2+g.y;c.scale=1;c.layer=1;c.outline=false;c.visible=true;c.fog=0;c.fogCol=[0,0,0];objs.push(c);
 }
 for(const e of ents){
  const rad=(e.r||20)*1.25;
  shadow(ctx,e.x,e.y,rad*1.1,.32);
  strokeRing(ctx,e.x,e.y,rad,e._ring,e===P0?4:3,.9,24);
 }
 if(P0&&S.hyper>0){strokeRing(ctx,P0.x,P0.y,P0.r+14+Math.sin(S.clock*14)*3,'#ffe66b',5,.75,28)}
 // 3D zeichnen
 sc.objs=objs;sc.outlineOn=q>=1;sc.stroke=q>=2;
 sc.render(ctx,W,H);
 // Geschosse
 for(const s of S.shots){
  const p=proj(s.x,s.y,.95);if(!p)continue;const g=proj(s.x,s.y,0);const k=p[2]/U;
  if(g){ctx.fillStyle='rgba(0,0,0,.25)';ctx.beginPath();ctx.ellipse(g[0],g[1],s.r*k*.9,s.r*k*.5,0,0,PI*2);ctx.fill()}
  const t=proj(s.x-s.vx*.04,s.y-s.vy*.04,.95);
  if(t){ctx.strokeStyle=s.color;ctx.globalAlpha=.45;ctx.lineWidth=Math.max(2,s.r*1.5*k);ctx.lineCap='round';ctx.beginPath();ctx.moveTo(t[0],t[1]);ctx.lineTo(p[0],p[1]);ctx.stroke();ctx.globalAlpha=1}
  ctx.globalAlpha=.35;ctx.fillStyle=s.color;ctx.beginPath();ctx.arc(p[0],p[1],s.r*1.7*k,0,PI*2);ctx.fill();ctx.globalAlpha=1;
  ctx.fillStyle=s.color;ctx.beginPath();ctx.arc(p[0],p[1],s.r*k,0,PI*2);ctx.fill();ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(p[0]-s.r*k*.25,p[1]-s.r*k*.25,s.r*k*.45,0,PI*2);ctx.fill();
 }
 for(const p of S.particles){const q2=proj(p.x,p.y,.7);if(!q2)continue;ctx.globalAlpha=Math.max(0,Math.min(1,p.life/.3));ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(q2[0],q2[1]-(.5-p.life)*8,(p.r||3)*q2[2]/U*1.1,0,PI*2);ctx.fill()}
 ctx.globalAlpha=1;
 // Schild
 if(P0&&P0.inv>0){const c=proj(P0.x,P0.y,1),e=proj(P0.x+P0.r+16,P0.y,1);if(c&&e){ctx.strokeStyle='rgba(120,200,255,.95)';ctx.fillStyle='rgba(120,200,255,.2)';ctx.lineWidth=4;ctx.beginPath();ctx.arc(c[0],c[1],Math.abs(e[0]-c[0])*1.5,0,PI*2);ctx.fill();ctx.stroke()}}
 // Lebensbalken
 const bar=(e,frac,h,boss)=>{
  const p=proj(e.x,e.y,h);if(!p)return;const w=Math.max(34,Math.min(92,p[2]*(boss?3.2:1.7))),bx=p[0]-w/2,by=p[1];
  ctx.fillStyle='rgba(10,16,28,.82)';ctx.beginPath();ctx.roundRect(bx-2,by-2,w+4,10,5);ctx.fill();
  ctx.fillStyle=e._ring==='#ff4b4b'?(frac>.5?'#ff6b5a':'#ff9a3d'):(frac>.5?'#4be07b':frac>.25?'#ffb53d':'#ff5252');
  ctx.beginPath();ctx.roundRect(bx,by,Math.max(0,w*Math.max(0,Math.min(1,frac))),6,3);ctx.fill();
 };
 for(const e of ents){bar(e,e.hp/e.maxHp,2.15*(e.sc3||CH)+.45,e.boss);if(e.name){const p=proj(e.x,e.y,2.15*(e.sc3||CH)+.45);if(p){ctx.font='bold 12px system-ui';ctx.textAlign='center';ctx.textBaseline='bottom';ctx.lineWidth=3;ctx.strokeStyle='rgba(0,0,0,.8)';ctx.strokeText(e.name,p[0],p[1]-4);ctx.fillStyle=e.friend?'#9fd8ff':'#ffb0a0';ctx.fillText(e.name,p[0],p[1]-4)}}}
 // Status-Symbole
 ctx.font='13px system-ui';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#fff';
 for(const b of S.bots){if(!b.alive||b.hidden)continue;const st=[];if(b.slow>0)st.push('❄️');if(b.poison>0)st.push('☠️');if(b.burn>0)st.push('🔥');if(b.stun>0)st.push('💫');if(st.length){const p=proj(b.x,b.y,2.15*(b.sc3||CH)+1.1);if(p)ctx.fillText(st.join(''),p[0],p[1])}}
 // Texte
 ctx.font='bold 16px system-ui,sans-serif';ctx.lineWidth=4;ctx.lineJoin='round';
 for(const t of S.texts){const p=proj(t.x,t.y,3.4);if(!p)continue;ctx.globalAlpha=Math.max(0,Math.min(1,t.life/.4));ctx.strokeStyle='rgba(0,0,0,.75)';ctx.strokeText(t.t,p[0],p[1]);ctx.fillStyle=t.col;ctx.fillText(t.t,p[0],p[1])}
 ctx.globalAlpha=1;
 // Pfeile zu Gegnern außerhalb des Bildes
 for(const b of S.bots){
  if(!b.alive||b.hidden||b.friend)continue;const p=proj(b.x,b.y,1);if(!p)continue;
  if(p[0]>14&&p[0]<W-14&&p[1]>14&&p[1]<H-14)continue;
  const cx=W/2,cy=H/2,dx=p[0]-cx,dy=p[1]-cy,sx=(W/2-22)/Math.max(1,Math.abs(dx)),sy=(H/2-22)/Math.max(1,Math.abs(dy)),k=Math.min(sx,sy),ax=cx+dx*k,ay=cy+dy*k,an=Math.atan2(dy,dx);
  ctx.save();ctx.translate(ax,ay);ctx.rotate(an);ctx.fillStyle='rgba(255,70,60,.9)';ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(11,0);ctx.lineTo(-7,-8);ctx.lineTo(-7,8);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();
 }
 // Vignette
 const v=ctx.createRadialGradient(W/2,H/2,Math.min(W,H)*.5,W/2,H/2,Math.max(W,H)*.8);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(0,0,0,.35)');ctx.fillStyle=v;ctx.fillRect(0,0,W,H);
};
})();
