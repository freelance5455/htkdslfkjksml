'use strict';
/* Arena Stars – Mehrspieler-Server (ohne Abhängigkeiten, nur Node.js >= 16)
   Start:  node server.js [Port]      (Standard-Port 8787)
   Er verwaltet Räume, Teams und leitet Spielnachrichten zwischen den Spielern weiter. */
const http = require('http'), crypto = require('crypto');
const PORT = +(process.argv[2] || process.env.PORT || 8787);

/* ---------- minimaler WebSocket (RFC 6455) ---------- */
function frame(op, data) {
  const p = Buffer.isBuffer(data) ? data : Buffer.from(data);
  let h;
  if (p.length < 126) h = Buffer.from([0x80 | op, p.length]);
  else if (p.length < 65536) { h = Buffer.alloc(4); h[0] = 0x80 | op; h[1] = 126; h.writeUInt16BE(p.length, 2); }
  else { h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 127; h.writeBigUInt64BE(BigInt(p.length), 2); }
  return Buffer.concat([h, p]);
}

const server = http.createServer((req, res) => { res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' }); res.end('Arena Stars Server läuft. Spieler: ' + clients.size + ', Räume: ' + rooms.size + '\n'); });
server.on('upgrade', (req, sock) => {
  const key = req.headers['sec-websocket-key'];
  if (!key) { sock.destroy(); return; }
  const acc = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + acc + '\r\n\r\n');
  sock.setNoDelay(true);
  const c = hub.connect(o => { if (!sock.destroyed) sock.write(frame(1, JSON.stringify(o))); });
  c.sock = sock; c.buf = Buffer.alloc(0); c.frag = [];
  sock.on('data', d => { c.buf = Buffer.concat([c.buf, d]); if (c.buf.length > 4e6) { sock.destroy(); return; } parse(c); });
  const gone = () => hub.disconnect(c);
  sock.on('close', gone); sock.on('error', gone); sock.on('end', gone);
});
function parse(c) {
  for (;;) {
    const b = c.buf; if (b.length < 2) return;
    const fin = !!(b[0] & 0x80), op = b[0] & 15, masked = !!(b[1] & 0x80); let len = b[1] & 127, off = 2;
    if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
    else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
    if (len > 2e6) { c.sock.destroy(); return; }
    const need = off + (masked ? 4 : 0) + len; if (b.length < need) return;
    let payload = Buffer.from(b.subarray(off + (masked ? 4 : 0), need));
    if (masked) { const m = b.subarray(off, off + 4); for (let i = 0; i < payload.length; i++) payload[i] ^= m[i & 3]; }
    c.buf = b.subarray(need);
    if (op === 8) { try { c.sock.write(frame(8, Buffer.alloc(0))); } catch (e) {} c.sock.end(); return; }
    if (op === 9) { try { c.sock.write(frame(10, payload)); } catch (e) {} continue; }
    if (op === 10) continue;
    if (op === 0 || op === 1) {
      if (op === 1) c.frag = [payload]; else c.frag.push(payload);
      if (fin) { const txt = Buffer.concat(c.frag).toString('utf8'); c.frag = []; let m; try { m = JSON.parse(txt); } catch (e) { continue; } try { hub.onMsg(c, m); } catch (e) { console.error('Fehler', e); } }
    }
  }
}

/* ---------- Räume (Logik in hub.js, wird auch im lokalen Modus ohne Server benutzt) ---------- */
const hub = require('./hub.js').create();
const clients = hub.clients, rooms = hub.rooms;
setInterval(() => { for (const c of clients.values()) if (Date.now() - c.last > 70000) { try { c.sock.destroy(); } catch (e) {} } }, 15000);
server.listen(PORT, () => console.log('Arena Stars Server auf Port ' + PORT));
module.exports = server;
