# Arena Stars – Android-Projekt (erweiterter Prototyp)

Offline-Arena-Spiel im Querformat mit Touch-Steuerung, vier eigenen Brawlern, Trophäen, KI-Bots und neuen Fähigkeitssystemen.

## Neue Inhalte
- Spielmodi: Bot-Brawl, Kristallrausch und Duell
- **Trick-Module**: einmalige Spezialfähigkeit pro Kampf (Gadget-artig)
- **Talentsterne**: passive Verbesserungen
- **Maximalmodus**: temporärer Kraftschub im Stil einer Hyperladung
- **Mod-Chips**: zusätzliche Verstärkung mit eigenem Namen
- Trophäen und Siege werden lokal gespeichert
- Gegner skalieren mit deiner Trophäenzahl

Die Namen und Effekte sind eigene Inhalte und keine originalen Brawl-Stars-Dateien.

## APK bauen
1. Installiere Android Studio auf einem Computer.
2. Entpacke das ZIP und öffne `ArenaStars_Android` in Android Studio.
3. Warte, bis Gradle synchronisiert ist.
4. Wähle **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Die APK wird unter `app/build/outputs/apk/debug/app-debug.apk` erstellt.
6. Übertrage die APK auf dein Android-Handy und installiere sie.

Hinweis: Das ZIP enthält den Quellcode und das Android-Projekt, keine bereits kompilierte APK.

## Offline-Story-Modus
- Fünf freischaltbare Story-Missionen mit unterschiedlichen Zielen und Bosskämpfen.
- Story-Fortschritt wird lokal auf dem Gerät gespeichert; die Kampagne benötigt kein Internet.

## App-Icon
- Arena-Stars-Launcher-Icon ist in die Android-Ressourcen eingebunden (inklusive adaptivem Icon für neuere Android-Versionen).

## Online-Trophäenpfad (Oberfläche)
- Separater Online-Trophäenpfad mit fünf Belohnungsstufen und Fortschrittsanzeige ist als UI-Vorschau ergänzt.
- WICHTIG: Der echte Online-Multiplayer/Server ist in diesem Projekt noch nicht eingerichtet. Daher werden noch keine Online-Matches gespielt und keine Online-Trophäen serverseitig vergeben oder synchronisiert. Offline-Spiel und Story funktionieren lokal.



## Neue Brawler (7 zusätzlich, insgesamt 11)
- ❄️ **Frosta** – Treffer verlangsamen; Trick: Eiszone (Gegner im Umkreis 4 s verlangsamt)
- ⛈️ **Voltia** – Kettenblitz springt auf nahen Gegner; Trick: Blitzschlag auf die 2 nächsten Gegner
- 🧪 **Toxa** – Treffer vergiften (Schaden über Zeit); Trick: Giftwolke
- 🌵 **Kaktor** – Streuschuss mit 3 Dornen; Trick: Stachelring (12 Dornen rundum)
- 💚 **Lumi** – heilt sich bei Treffern; Trick: Heilfeld (+45 Leben)
- 🥷 **Schemen** – 25 % kritische Treffer; Trick: Schattenschritt (teleportiert zum nächsten Gegner)
- 💣 **Bombo** – Explosionsschaden um das Ziel; Trick: Minenfeld (5 Sprengpunkte)

Außerdem behoben: Spielstart-Fehler (fehlendes HUD-Element) und Fehler im Ergebnisbildschirm; Trick-Effekte, die Gegner auf 0 Leben bringen, töten diese jetzt zuverlässig.

## Fehlerbehebungen (Gesamtprüfung)
- Menü per Touch scrollbar (vorher blockiert, Start-Knopf auf kleinen Displays unerreichbar)
- Spielstart-Absturz (fehlendes HUD-Element) und Absturz beim zweiten Ergebnisbildschirm behoben
- Doppelte, widersprüchliche Spielmodus-Auswahl zusammengeführt (Bot-Brawl, Duo, Kristallrausch, Duell, Bosskampf); Duell ist jetzt ein echtes 1-gegen-1
- Kristallrausch endet jetzt bei 10 Kristallen (Anzeige im HUD)
- Trick-Modul wird in jedem neuen Kampf wieder freigeschaltet
- Maximalmodus-Boni addieren sich nicht mehr dauerhaft, sondern laufen nach 3,5 s aus
- Notfall-Sprint (Taktikmodul) kann in der nächsten Runde kein Tempo mehr abziehen
- Niederlage gibt keine Trophäen mehr
- Spielmodus und Ausrüstung werden gespeichert
- Angriff-Knopf: gedrückt halten feuert dauerhaft
- Ältere Android-WebViews ohne roundRect werden unterstützt
- Joystick-Knopf mittig, MAX-Knopf leuchtet wenn bereit
- Android: Spiel pausiert im Hintergrund, kein Neustart bei Konfigurationsänderung, explizite Java/Kotlin-17-Einstellungen

## Update: Querformat, Steuerung, 8 neue Brawler, neue Grafik
- Querformat (beide Richtungen) in der App fest eingestellt; im Browser erscheint im Hochformat ein Drehhinweis und das Spiel pausiert.
- Bewegungsstick links, Knöpfe rechts: ANGRIFF (groß, gedrückt halten = Dauerfeuer), MAX links daneben, TRICK darüber. Die Größen passen sich dem Display an.
- Menü zweispaltig (Modi/Ausrüstung/Story links, Brawler rechts mit Detailanzeige), Kampf-starten-Leiste immer sichtbar.
- Neue Brawler (insgesamt 19):
  - 🌀 Gravo – zieht Gegner heran; Trick: Schwarzes Loch (zieht alle heran, betäubt)
  - 🦅 Falke – durchschlagender Fernschuss; Trick: Volltreffer auf den fernsten Gegner
  - 🔰 Aegis – 30 % weniger Schaden; Trick: Schutzkuppel (3 s unverwundbar)
  - 🧛 Vlad – Lebensraub bei Treffern; Trick: Blutrausch (4 s doppelte Feuerrate)
  - 🦊 Rascal – weicht 22 % der Treffer aus; Trick: Rauchwolke (betäubt Gegner)
  - 🔨 Thora – Rückstoß-Treffer; Trick: Erdbeben (Schaden, Rückstoß, Betäubung)
  - 🐉 Draco – entzündet Gegner; Trick: Feuerodem (Feuerkegel)
  - 🤖 Robi – Trick: stellt einen Geschützturm auf, der 7 s lang schießt
- Grafik: vorgerenderter Arena-Hintergrund (Gras, Blumen, Zaun), schattierte Figuren mit Emoji-Gesichtern, Schusspuren, Partikel, Schadenszahlen, K.O.-Effekte, Statussymbole (❄️ ☠️ 🔥 💫), Bildschirmwackeln, Vignette, MAX-Knopf mit Ladering, "LOS!"-Einblendung, Arena passt sich der Bildschirmbreite an.

- Querformat wird ab dem Start erzwungen (Manifest `sensorLandscape` + Activity); im Browser zusätzlich Vollbild und Orientierungssperre sowie Drehhinweis im Hochformat.

## Sofortiges Querformat (auch ohne Gerätedrehung)
- Steht das Gerät hochkant (oder ignoriert ein Wrapper/Browser die Orientierungs-Einstellung), dreht das Spiel seine gesamte Oberfläche selbst um 90° und startet sofort im Querformat. Gerät dazu einfach gegen den Uhrzeigersinn kippen.
- Stick, Knöpfe und Menü-Wischen sind dabei korrekt mitgedreht. Wird das Gerät wirklich quer gehalten, schaltet sich die Software-Drehung automatisch ab.
- Android-App: zusätzlich `sensorLandscape` im Manifest; für Web-Wrapper liegt `assets/manifest.webmanifest` mit `orientation: landscape` bei.

## Update: 3D-Lobby & 3D-Modelle
- Das Hauptmenü ist jetzt eine **3D-Lobby**: die gewählte Figur steht auf einem Podest vor einer von 8 Hintergrundwelten (Himmelsinseln, Eisgipfel, Vulkan-Arena, Sturmwolken, Dschungel, Wüstenschlucht, Nachtstadt, Weltraum-Station) mit Parallax, Wolken, Partikeln und 3D-Requisiten.
- Figur ziehen = drehen, antippen = Pose, Knopf „Welt“ wechselt den Hintergrund. Unten die Kämpfer-Leiste, links die Menüknöpfe (Kämpfer, Modus, Ausrüstung, Story, Online, Hilfe), rechts der große SPIELEN-Knopf.
- **19 eigene 3D-Modelle** (je ein Kämpfer, mit Zubehör und Animation), erzeugt von einer eigenen kleinen Engine ohne Fremdbibliotheken: `assets/engine3d.js`, `models3d.js`, `lobby3d.js`. Hohe Auflösung (bis ~24 Segmente pro Rundung); auf schwächeren Geräten schaltet die Lobby automatisch auf geringere Detailstufen.
- Im Kampf wird der Spieler als Bild aus seinem 3D-Modell gezeichnet.
- Alle Figuren und Welten sind Eigenentwürfe (keine Brawl-Stars-Assets).

## Update: 3D-Arenen, animierte Kämpfer, schwerere Bots
- **Alles in 3D:** Die Kampfarena wird jetzt mit der eigenen 3D-Engine gezeichnet (`assets/arena3d.js`): gekippte Kamera von schräg oben wie bei Brawl-Stars-artigen Spielen, die dem Spieler folgt. 3D-Mauern, Kisten, Säulen, Büsche, Zaun, Kristallmine; je Modus ein eigenes Thema (Wiese, Blumenwiese, Kristallhöhle, Wüste, Vulkan-Boss-Arena).
- **Größere Arenen:** 1800×1300 (Bot-Brawl, Duo), 1600×1100 (Kristalljagd), 1300×900 (Duell), 1400×1000 (Boss) – statt eines Bildschirms. Gegner außerhalb des Bildes werden mit roten Pfeilen angezeigt. Mauern/Kisten/Säulen sind fest (Bewegung + Schüsse blockiert), Büsche verstecken Gegner.
- **Animierte 3D-Modelle im Spiel:** Spieler, Partner und alle Bots sind die 3D-Kämpfer mit Lauf-, Schwing- und Angriffsanimation, drehen sich in Blickrichtung und kippen beim K.O. um. Qualität passt sich automatisch an die Geräteleistung an.
- **Modi:** Bot-Brawl/Duo mit schrumpfender Giftwolke (Showdown-Prinzip); Duo mit KI-Partner; Kristalljagd mit Mine in der Mitte (Kristalle einsammeln, 10 halten, 7 s durchhalten – Treffer verliert Kristalle); Duell in kleiner Arena; Boss mit Ringschüssen und Anstürmen.
- **Schwerere KI:** Bots haben Rollen (Rusher, Scharfschütze, Tank, Allrounder), zielen mit Vorhalt, weichen Schüssen aus, umkreisen dich, umgehen Hindernisse und stecken nicht fest, ziehen sich bei wenig Leben zurück und setzen eine Spezialattacke ein. Sie meiden die Giftwolke und verlieren dich im Busch.

## Update: Bot-Stärke einstellbar
Lobby → Modus → **Bot-Stärke**: Leicht (70 % Leben, 60 % Schaden, langsamer, halbe Trophäen), Normal, Schwer (130 %/125 %, schneller, 1,25× Trophäen), Extrem (170 %/155 %, sehr schnell, 1,5× Trophäen). Die Wahl wird gespeichert und im Modus-Chip der Lobby angezeigt.

## Update: Selbstheilung
Wer länger als 3 Sekunden weder angreift noch Schaden bekommt (auch nicht durch die Giftwolke), heilt sich automatisch um 10 % seines Lebens pro Sekunde. Jeder Angriff oder Treffer unterbricht die Heilung.

## Neu in Version 6
- **Kämpfer-Freischaltsystem**: Seltenheiten (Selten → Legendär) mit Münzkosten, Start mit 120 Münzen; Münzen/Edelsteine gibt es als Kampfbelohnung.
- **Trophäen wie Brawl Stars**: Trophäen pro Kämpfer, Ränge, Trophäenpfad mit Belohnungen, Gewinn/Verlust je nach Rang.
- **Neues Menü**: obere Leiste (Trophäen/Münzen/Edelsteine, Pfad-Fortschritt) und Seitenleiste mit 8 Buttons.
- **24 Kämpfer**, **8 Modi** (neu: Raub, Horde, Kopfgeld), größere Karten, kleinere Objekte.
- **Hochauflösende 3D-Modelle** (32 Segmente, adaptive Qualität).
- **App-Icon** (Stern mit Blitz) in `res/mipmap-*`.

## Kämpfer-Upgrades (Version 7)
- Jeder Kämpfer hat **Stufe 1–11** (+5 % Leben und Schaden pro Stufe, Stufe 11 = +50 %).
- **Kraftpunkte (⚡)** gibt es nach jedem Kampf (Sieg 8–12, Niederlage 3–5) oder für 40 🪙 als Paket (+10). Upgrade kostet Kraftpunkte + Münzen (Kämpfer-Seite → „STUFE x“).
- Auf Stufe 11 werden Kraftpunkte in Münzen umgewandelt.
- Admin: Aktionen für Stufe 11 (einzeln/alle), +500 Kraftpunkte, Stufen zurücksetzen.

## Zielen & Stufen-Fähigkeiten (Version 8)
- **Zielen:** Am ANGRIFF-, MAX- und TRICK-Knopf: *Tippen* = Auto-Ziel, *Halten* (Angriff) = Dauerfeuer, *Ziehen* = selbst zielen mit Zielvorschau, *Loslassen* = Schuss/Einsatz. Richtungs-Tricks (z. B. Dash, Flammenkegel, Teleport, Volltreffer, Geschütz) nutzen die Zielrichtung.
- **Freischaltungen per Stufe:** 4 = MAX lädt 25 % schneller · 5 = Taktikmodul · 6 = +10 % Reichweite · 7 = Trick · 8 = Zweite Chance (1× pro Kampf) · 9 = Sternkraft · 10 = Boost-Chip · 11 = Nova-Ausbruch. Gesperrte Ausrüstung ist in „Ausrüstung“ ausgegraut.
- Admin-Version: alle Kämpfer starten auf Stufe 11.

## Online-Spiel & Testspiel (Version 9)
**Server** (liegt im Ordner `server/`, keine Abhängigkeiten, nur Node.js ≥ 16):
`node server/server.js [Port]` (Standard 8787). Er muss auf einem PC/Server laufen, den alle Spieler erreichen.
In der App: Lobby → **Online** → Server-Adresse eintragen (Android-Emulator: `ws://10.0.2.2:8787`, Handy im selben WLAN: `ws://<PC-IP>:8787`, im Internet: Port freigeben bzw. auf einem Server hosten) → **Verbinden**.

**Modi:** 🌐 Duell 1v1 · 🌐 Team-Knockout 3v3 (bis 3 pro Team, auch 2v2/1v1) · 🌐 Koop (bis 3 Spieler gemeinsam gegen Bots).
**Räume:** Schnelle Runde (automatische Suche), Raum mit Code erstellen/beitreten, Raumliste, Team wechseln, Host startet.
**Admin/Normal:** Admin-Accounts finden in der Schnellen Runde nur andere Admins (Cheats aktiv). Admins können aber auch Räume mit normalen Spielern betreten (und „offen für normale Accounts“ erstellen) – dort sind die Admin-Optionen automatisch AUS. Normale Accounts kommen nicht in Admin-Räume.
**Wertung:** Online-Trophäen (Sieg +8, Niederlage −4), Münzen und Kraftpunkte – außer im Testspiel.
**🧪 Testspiel** (Knopf neben SPIELEN): wie das Freundschaftsspiel in Brawl Stars – Raum mit Team-Features, leere Gegnerplätze füllen Bots, auch allein spielbar (ohne Server), mit „Freunde einladen“ wird es ein Online-Raum. **Keine Trophäen, Münzen oder Kraftpunkte.** Im Testspiel sind auch alle Offline-Modi wählbar.
**Technik:** Jeder Spieler berechnet seine eigene Figur, Treffer meldet der Angreifer, Bots laufen beim Host (Koop). Der Server leitet nur Nachrichten weiter.

## Lokal ohne Server (Version 10)
Lobby → **Online** → **📡 Lokal ohne Server** (gleiches WLAN oder Handy-Hotspot, kein PC-Server nötig).
- **Host:** Modus/Testspiel wählen → „📡 Lokal hosten“ → pro Mitspieler „➕ Einladung erstellen“ → Code kopieren und schicken (Messenger o. Ä.).
- **Mitspieler:** „📡 Lokal beitreten“ → Code einfügen → „Antwort erstellen“ → Antwort-Code zurück an den Host schicken.
- **Host:** Antwort-Code einfügen → „Verbinden“. Danach Teams, Modus, Start wie im Online-Raum (Duell, Team 3v3, Koop, Testspiel).
- Der Host-Handy ersetzt den Server (die Raum-Logik `hub.js` ist dieselbe wie im Server). Admin-Regeln gelten auch lokal (Admin-Raum nur für Admins; offene Räume ohne Cheats).
- Technik: WebRTC-Datenkanal. Hinweis: Manche Netzwerke (Gäste-WLAN, Client-Isolation) blockieren direkte Verbindungen – dann Handy-Hotspot oder den Server (`server/server.js`) nutzen.

## Admin-Funktionen im Testspiel (Version 11)
In Online-/Lokal-Räumen sind die Admin-Funktionen sonst aus (Fairness). Ein Admin-Host kann bei einem **Testspiel-Raum** den Haken „🛠 Admin-Funktionen im Testspiel erlauben“ setzen – dann sind sie für alle Admin-Accounts im Raum aktiv (Anzeige „🛠 Admin-Funktionen AN“). In Wertungsrunden bleiben sie immer aus bzw. nur in reinen Admin-Lobbys aktiv.

## Admin-Funktionen im Testspiel (Version 11)
In normalen (offenen) Räumen sind die Admin-Funktionen aus. Ein **Admin-Host** kann im **Testspiel** (Raum-Option „Testspiel“) den Haken **„🛠 Admin-Funktionen im Testspiel“** setzen – gilt für Server-Räume und lokale Räume. Alle im Raum sehen die Anzeige „Admin-Funktionen AN“. Nur Admin-Accounts erhalten dann die Cheats; normale Accounts bleiben unverändert. In Wertungsrunden wird der Haken ignoriert. Außerdem: stabilerer Verbindungsaufbau im lokalen Modus (Hello-Wiederholung) und schnellere Code-Erstellung.
