# Arena Stars – Android-Projekt (erweiterter Prototyp)

Offline-Arena-Spiel im Querformat mit Touch-Steuerung, vier eigenen Brawlern, Trophäen, KI-Bots und neuen Fähigkeitssystemen.

## Neue Inhalte
- Spielmodi: Bot-Brawl, Kristallrausch und Duell
- **Trick-Module**: einmalige Spezialfähigkeit pro Kampf (Gadget-artig)
- **Talentsterne**: passive Verbesserungen
- **Maximalmodus**: temporärer Kraftschub im Stil einer Hyperladung
- **Mod-Chips**: zusätzliche Verstärkung mit eigenem Namen
- Trophäen und Siege werden lokal gespeichert
- Gegner skalieren mit deiner Trophäenzahl

Die Namen und Effekte sind eigene Inhalte und keine originalen Brawl-Stars-Dateien.

## APK bauen
1. Installiere Android Studio auf einem Computer.
2. Entpacke das ZIP und öffne `ArenaStars_Android` in Android Studio.
3. Warte, bis Gradle synchronisiert ist.
4. Wähle **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Die APK wird unter `app/build/outputs/apk/debug/app-debug.apk` erstellt.
6. Übertrage die APK auf dein Android-Handy und installiere sie.

Hinweis: Das ZIP enthält den Quellcode und das Android-Projekt, keine bereits kompilierte APK.

## Offline-Story-Modus
- Fünf freischaltbare Story-Missionen mit unterschiedlichen Zielen und Bosskämpfen.
- Story-Fortschritt wird lokal auf dem Gerät gespeichert; die Kampagne benötigt kein Internet.

## App-Icon
- Arena-Stars-Launcher-Icon ist in die Android-Ressourcen eingebunden (inklusive adaptivem Icon für neuere Android-Versionen).

## Online-Trophäenpfad (Oberfläche)
- Separater Online-Trophäenpfad mit fünf Belohnungsstufen und Fortschrittsanzeige ist als UI-Vorschau ergänzt.
- WICHTIG: Der echte Online-Multiplayer/Server ist in diesem Projekt noch nicht eingerichtet. Daher werden noch keine Online-Matches gespielt und keine Online-Trophäen serverseitig vergeben oder synchronisiert. Offline-Spiel und Story funktionieren lokal.



## Neue Brawler (7 zusätzlich, insgesamt 11)
- ❄️ **Frosta** – Treffer verlangsamen; Trick: Eiszone (Gegner im Umkreis 4 s verlangsamt)
- ⛈️ **Voltia** – Kettenblitz springt auf nahen Gegner; Trick: Blitzschlag auf die 2 nächsten Gegner
- 🧪 **Toxa** – Treffer vergiften (Schaden über Zeit); Trick: Giftwolke
- 🌵 **Kaktor** – Streuschuss mit 3 Dornen; Trick: Stachelring (12 Dornen rundum)
- 💚 **Lumi** – heilt sich bei Treffern; Trick: Heilfeld (+45 Leben)
- 🥷 **Schemen** – 25 % kritische Treffer; Trick: Schattenschritt (teleportiert zum nächsten Gegner)
- 💣 **Bombo** – Explosionsschaden um das Ziel; Trick: Minenfeld (5 Sprengpunkte)

Außerdem behoben: Spielstart-Fehler (fehlendes HUD-Element) und Fehler im Ergebnisbildschirm; Trick-Effekte, die Gegner auf 0 Leben bringen, töten diese jetzt zuverlässig.

## Fehlerbehebungen (Gesamtprüfung)
- Menü per Touch scrollbar (vorher blockiert, Start-Knopf auf kleinen Displays unerreichbar)
- Spielstart-Absturz (fehlendes HUD-Element) und Absturz beim zweiten Ergebnisbildschirm behoben
- Doppelte, widersprüchliche Spielmodus-Auswahl zusammengeführt (Bot-Brawl, Duo, Kristallrausch, Duell, Bosskampf); Duell ist jetzt ein echtes 1-gegen-1
- Kristallrausch endet jetzt bei 10 Kristallen (Anzeige im HUD)
- Trick-Modul wird in jedem neuen Kampf wieder freigeschaltet
- Maximalmodus-Boni addieren sich nicht mehr dauerhaft, sondern laufen nach 3,5 s aus
- Notfall-Sprint (Taktikmodul) kann in der nächsten Runde kein Tempo mehr abziehen
- Niederlage gibt keine Trophäen mehr
- Spielmodus und Ausrüstung werden gespeichert
- Angriff-Knopf: gedrückt halten feuert dauerhaft
- Ältere Android-WebViews ohne roundRect werden unterstützt
- Joystick-Knopf mittig, MAX-Knopf leuchtet wenn bereit
- Android: Spiel pausiert im Hintergrund, kein Neustart bei Konfigurationsänderung, explizite Java/Kotlin-17-Einstellungen

## Update: Querformat, Steuerung, 8 neue Brawler, neue Grafik
- Querformat (beide Richtungen) in der App fest eingestellt; im Browser erscheint im Hochformat ein Drehhinweis und das Spiel pausiert.
- Bewegungsstick links, Knöpfe rechts: ANGRIFF (groß, gedrückt halten = Dauerfeuer), MAX links daneben, TRICK darüber. Die Größen passen sich dem Display an.
- Menü zweispaltig (Modi/Ausrüstung/Story links, Brawler rechts mit Detailanzeige), Kampf-starten-Leiste immer sichtbar.
- Neue Brawler (insgesamt 19):
  - 🌀 Gravo – zieht Gegner heran; Trick: Schwarzes Loch (zieht alle heran, betäubt)
  - 🦅 Falke – durchschlagender Fernschuss; Trick: Volltreffer auf den fernsten Gegner
  - 🔰 Aegis – 30 % weniger Schaden; Trick: Schutzkuppel (3 s unverwundbar)
  - 🧛 Vlad – Lebensraub bei Treffern; Trick: Blutrausch (4 s doppelte Feuerrate)
  - 🦊 Rascal – weicht 22 % der Treffer aus; Trick: Rauchwolke (betäubt Gegner)
  - 🔨 Thora – Rückstoß-Treffer; Trick: Erdbeben (Schaden, Rückstoß, Betäubung)
  - 🐉 Draco – entzündet Gegner; Trick: Feuerodem (Feuerkegel)
  - 🤖 Robi – Trick: stellt einen Geschützturm auf, der 7 s lang schießt
- Grafik: vorgerenderter Arena-Hintergrund (Gras, Blumen, Zaun), schattierte Figuren mit Emoji-Gesichtern, Schusspuren, Partikel, Schadenszahlen, K.O.-Effekte, Statussymbole (❄️ ☠️ 🔥 💫), Bildschirmwackeln, Vignette, MAX-Knopf mit Ladering, "LOS!"-Einblendung, Arena passt sich der Bildschirmbreite an.
