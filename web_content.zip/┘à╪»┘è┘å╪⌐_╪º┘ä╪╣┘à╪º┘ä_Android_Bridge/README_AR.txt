جسر Android لتطبيق وحدة مدينة العمال
====================================

هذا المشروع يحتوي على:
1) نسخة HTML الحالية داخل app/src/main/assets/index.html.
2) MainActivity.kt لتعريف جسر JavaScript باسم Android.
3) Android.syncContacts() لمزامنة جهات اتصال الهاتف.
4) Android.openWhatsApp(phone,message) لفتح واتساب مباشرة مع الرسالة.
5) Android.openCamera(front/back) لفتح الكاميرا.
6) Android.shareText(text) للمشاركة.
7) صلاحية READ_CONTACTS وCAMERA.

الدوال التي يتوقعها ملف HTML موجودة فعلياً في MainActivity.kt.

ملاحظة البناء:
يتطلب البناء Android SDK وJDK 17 وGradle/Android Gradle Plugin متوافق.
لم يتم ادعاء إنشاء APK في هذه الحزمة؛ هذه حزمة مشروع Android المصدرية الجاهزة للبناء.


إصلاح إضافي - HTTP_RESPONSE_CODE_FAILURE
----------------------------------------
تم تعديل MainActivity.kt ليقرأ index.html من داخل مجلد assets
ويحمّله باستخدام loadDataWithBaseURL بدلاً من الاعتماد على تحميل
صفحة ويب أو مسار ملف خارجي. هذا يمنع خطأ:
HTTP_RESPONSE_CODE_FAILURE
الذي يظهر عندما يحاول WebView الوصول إلى ملف HTML غير موجود أو
مسار عربي/مشفّر خارج APK.
