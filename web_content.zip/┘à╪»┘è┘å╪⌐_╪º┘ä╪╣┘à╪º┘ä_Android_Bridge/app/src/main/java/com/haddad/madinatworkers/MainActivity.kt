package com.haddad.madinatworkers

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val contactsPermissionRequest = 4101
    private val cameraPermissionRequest = 4102
    private var pendingCameraFacing = "back"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = false

        // تحميل الصفحة من داخل APK مباشرة، بدون HTTP أو اسم ملف عربي/مشفّر.
        // هذا يمنع ظهور HTTP_RESPONSE_CODE_FAILURE عند بعض إصدارات WebView.
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                // الروابط الخارجية تفتح خارج الصفحة، بينما الصفحة الداخلية تبقى داخل WebView.
                if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    } catch (_: Exception) {
                    }
                    return true
                }
                return false
            }
        }
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "Android")

        // لا نستخدم loadUrl لملف خارجي. نقرأ index.html من assets ونحمّله
        // مباشرة بقاعدة file داخل APK، وبالتالي لا يعتمد على الإنترنت.
        try {
            val html = assets.open("index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
            webView.loadDataWithBaseURL(
                "file:///android_asset/",
                html,
                "text/html",
                "UTF-8",
                null
            )
        } catch (e: Exception) {
            webView.loadData(
                "<html><body style='font-family:sans-serif;direction:rtl;padding:24px'>" +
                    "<h2>تعذر فتح واجهة التطبيق</h2>" +
                    "<p>ملف index.html غير موجود داخل APK.</p>" +
                    "</body></html>",
                "text/html",
                "UTF-8"
            )
        }

        setContentView(webView)
    }

    private fun jsCall(functionName: String, arg: String = "") {
        runOnUiThread {
            val script = if (arg.isEmpty()) {
                "window.$functionName && window.$functionName();"
            } else {
                "window.$functionName && window.$functionName($arg);"
            }
            webView.evaluateJavascript(script, null)
        }
    }

    private fun jsonString(value: String): String = JSONObject.quote(value)

    private fun normalizeEgyptianWhatsAppNumber(input: String): String {
        var n = input.trim().replace(Regex("[^0-9]"), "")
        if (n.startsWith("00")) n = n.removePrefix("00")
        if (n.startsWith("0") && n.length >= 10) n = "20" + n.substring(1)
        return n
    }

    private fun openWhatsApp(phone: String, message: String) {
        val number = normalizeEgyptianWhatsAppNumber(phone)
        if (number.isBlank()) {
            Toast.makeText(this, "رقم الهاتف غير صالح", Toast.LENGTH_SHORT).show()
            return
        }
        val url = "https://wa.me/$number?text=" + Uri.encode(message)
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        try {
            intent.setPackage("com.whatsapp")
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            intent.setPackage(null)
            try {
                startActivity(intent)
            } catch (_: Exception) {
                Toast.makeText(this, "واتساب غير مثبت على الهاتف", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startContactsSync() {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            jsCall("onContactsSyncStarted")
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), contactsPermissionRequest)
            return
        }
        readContacts()
    }

    @SuppressLint("Range")
    private fun readContacts() {
        try {
            val result = JSONArray()
            val seen = HashSet<String>()
            val cursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
            )

            cursor?.use { c ->
                val nameIndex = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val phoneIndex = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (c.moveToNext()) {
                    val name = if (nameIndex >= 0) c.getString(nameIndex) ?: "بدون اسم" else "بدون اسم"
                    val phone = if (phoneIndex >= 0) c.getString(phoneIndex) ?: "" else ""
                    val key = "$name|$phone"
                    if (phone.isNotBlank() && seen.add(key)) {
                        result.put(JSONObject().apply {
                            put("name", name)
                            put("phone", phone)
                        })
                    }
                }
            }

            jsCall("onContactsFromAndroid", result.toString())
            jsCall("onContactsSyncDone", result.length().toString())
        } catch (e: SecurityException) {
            jsCall("onContactsSyncError", jsonString("لم يتم السماح بقراءة جهات الاتصال."))
        } catch (e: Exception) {
            jsCall("onContactsSyncError", jsonString("تعذر مزامنة جهات الاتصال: ${e.message ?: "خطأ غير معروف"}"))
        }
    }

    private fun openCamera(facing: String) {
        pendingCameraFacing = facing
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            jsCall("onCameraPermissionRequested")
            requestPermissions(arrayOf(Manifest.permission.CAMERA), cameraPermissionRequest)
            return
        }
        launchCamera()
    }

    private fun launchCamera() {
        try {
            val intent = Intent("android.media.action.IMAGE_CAPTURE")
            val cameraFacing = if (pendingCameraFacing == "front") 1 else 0
            intent.putExtra("android.intent.extras.CAMERA_FACING", cameraFacing)
            intent.putExtra("android.intent.extra.USE_FRONT_CAMERA", pendingCameraFacing == "front")
            startActivityForResult(intent, 4201)
            jsCall("onCameraOpened", jsonString(pendingCameraFacing))
        } catch (_: Exception) {
            jsCall("onCameraError", jsonString("تعذر فتح الكاميرا."))
        }
    }

    private fun shareText(text: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(intent, "مشاركة بيانات وحدة مدينة العمال"))
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun isNativeAndroid(): Boolean = true

        @JavascriptInterface
        fun syncContacts() = runOnUiThread { startContactsSync() }

        @JavascriptInterface
        fun openWhatsApp(phone: String, message: String) = runOnUiThread { openWhatsApp(phone, message) }

        @JavascriptInterface
        fun openCamera(facing: String) = runOnUiThread { openCamera(facing) }

        @JavascriptInterface
        fun shareText(text: String) = runOnUiThread { shareText(text) }

        @JavascriptInterface
        fun openAppSettings() {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            contactsPermissionRequest -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    readContacts()
                } else {
                    jsCall("onContactsPermissionDenied")
                }
            }
            cameraPermissionRequest -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    launchCamera()
                } else {
                    jsCall("onCameraPermissionDenied")
                }
            }
        }
    }
}
