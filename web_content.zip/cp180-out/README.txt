Contractor Pro V18.0.0 — Smart Construction Development

Master preserved: V17.5.0 was not modified.
New module: AI Drawing → Smart Estimate (secure-server analysis connection point).
This is a development/QA build, not a production release.
