// Çakma Surfers oda sunucusu (Node.js)
// Kurulum:   npm install ws
// Çalıştır:  node cakma-surfers-sunucu.js          (varsayılan port 8787, PORT=... ile değişir)
// Oyunda:    Online Oda ekranındaki "Sunucu adresi" kutusuna  wss://SUNUCU-ADRESIN  yaz.
// Not: oyun https üzerinden açılıyorsa wss:// (şifreli) adres gerekir; düz ws:// sadece yerel denemelerde çalışır.
'use strict';
const WebSocket = require('ws');
const PORT = +process.env.PORT || 8787;
const MAX_ROOM = Infinity, MAX_ROOMS = 5000;   // odadaki kişi sayısı sınırsız
const httpSrv = require('http').createServer((q, r) => { r.writeHead(200, {'Content-Type':'text/plain; charset=utf-8'}); r.end('Cakma Surfers sunucusu calisiyor'); });
const wss = new WebSocket.Server({ server: httpSrv, maxPayload: 120000 });
httpSrv.listen(PORT);
const rooms = new Map();   // kod -> Set(ws)
let seq = 0;

// ---- küfür filtresi (istemcideki ile aynı mantık; sunucu da süzer) ----
const SUB = ['orospu', 'yarrak', 'siktir', 'pezevenk', 'gavat', 'kahpe', 'amcik', 'amina', 'anani', 'fuck', 'shit', 'bitch', 'asshole', 'sikik', 'sikeyim', 'sikerim', 'ibne', 'dalyarak', 'yavsak', 'serefsiz', 'pust'];
const WORD = ['sik', 'sikim', 'sike', 'amk', 'aq', 'amq', 'got', 'gotu', 'gotunu',  'oc', 'yarak', 'mk', 'sg', 'siktim'];
const MAP = { 'ı': 'i', 'İ': 'i', 'ş': 's', 'Ş': 's', 'ğ': 'g', 'Ğ': 'g', 'ü': 'u', 'Ü': 'u', 'ö': 'o', 'Ö': 'o', 'ç': 'c', 'Ç': 'c', '0': 'o', '1': 'i', '3': 'e', '4': 'a', '5': 's', '7': 't', '@': 'a', '$': 's' };
const norm = t => [...t].map(ch => MAP[ch] || ch.toLowerCase()).join('');
const pat = w => w.split('').map(c => c + '+').join('[^a-z0-9]{0,2}');
const RES = SUB.map(w => new RegExp(pat(w), 'g')).concat(WORD.map(w => new RegExp('(^|[^a-z0-9])(' + pat(w) + ')(?=$|[^a-z0-9])', 'g')));
function cenz(t) {
  const chars = [...String(t)], n = norm(chars.join('')), mask = new Array(chars.length).fill(false);
  for (const re of RES) {
    re.lastIndex = 0; let m;
    while ((m = re.exec(n))) {
      const pre = m[1] !== undefined ? m[1].length : 0, st = m.index + pre, len = m[0].length - pre;
      for (let i = st; i < st + len && i < mask.length; i++) mask[i] = true;
      if (m[0].length === 0) re.lastIndex++;
    }
  }
  return chars.map((c, i) => mask[i] ? '*' : c).join('');
}
const clean = (s, n) => cenz(String(s == null ? '' : s).replace(/[<>\u0000-\u001f]/g, '').trim()).slice(0, n);

function broadcast(code) {
  const set = rooms.get(code); if (!set) return;
  const list = [...set].map(c => ({ id: c.id, n: c.n, d: c.d, x: c.x, s: c.s, c: c.c, b: c.b, h: c.h, g: c.g }));
  const msg = JSON.stringify({ t: 'peers', list });
  for (const c of set) if (c.readyState === 1) c.send(msg);
}
function leave(ws) {
  if (!ws.room) return;
  const set = rooms.get(ws.room);
  if (set) { set.delete(ws); if (!set.size) rooms.delete(ws.room); else broadcast(ws.room); }
  ws.room = null;
}

wss.on('connection', ws => {
  ws.id = 'p' + (++seq); ws.n = 'Misafir'; ws.d = 0; ws.x = 0; ws.s = ''; ws.c = ''; ws.b = ''; ws.h = ''; ws.g = 0; ws.room = null; ws.lastMsg = 0; ws.alive = true;
  ws.send(JSON.stringify({ t: 'hi', id: ws.id }));
  ws.on('pong', () => { ws.alive = true; });
  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    if (!m || typeof m.t !== 'string') return;
    if (m.t === 'join') {
      const code = String(m.room || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
      if (code.length < 3) return;
      leave(ws);
      let set = rooms.get(code);
      if (!set) { if (rooms.size >= MAX_ROOMS) { ws.send(JSON.stringify({ t: 'err', text: 'Sunucu dolu' })); return; } set = new Set(); rooms.set(code, set); }
      if (set.size >= MAX_ROOM) { ws.send(JSON.stringify({ t: 'err', text: 'Oda dolu' })); return; }
      ws.n = clean(m.n, 16) || 'Misafir'; ws.room = code; set.add(ws); broadcast(code);
    } else if (m.t === 'p' && ws.room) {
      ws.n = clean(m.n, 16) || ws.n;
      const d = +m.d; ws.d = Number.isFinite(d) ? Math.max(0, Math.min(10000000, Math.floor(d))) : 0;
      const x = +m.x; ws.x = Number.isFinite(x) ? Math.max(-10, Math.min(10, x)) : 0;
      ws.s = String(m.s || '').slice(0, 20).replace(/[^a-z0-9]/gi, '');
      ws.c = /^#[0-9a-fA-F]{6}$/.test(String(m.c || '')) ? String(m.c) : '';
      ws.b = clean(m.b, 4); ws.h = /^(cap|phones|top|crown)$/.test(String(m.h || '')) ? String(m.h) : '';
      ws.g = (m.g === 1 || m.g === 2) ? m.g : 0;
      const now = Date.now();
      if (!ws.lastB || now - ws.lastB > 250) { ws.lastB = now; broadcast(ws.room); }
    } else if (m.t === 'v' && ws.room) {
      if (typeof m.a !== 'string' || m.a.length > 45000 || !/^[A-Za-z0-9+\/=]+$/.test(m.a)) return;
      const now = Date.now(); if (now - (ws.vWin || 0) > 10000) { ws.vWin = now; ws.vBytes = 0; }
      ws.vBytes += m.a.length; if (ws.vBytes > 1500000) return;   // 10 sn'de ~1 MB ses: uzun konuşmalara yeter, kötüye kullanımı keser
      const tot = Math.max(1, Math.min(80, m.tot | 0)), k = Math.max(0, Math.min(tot - 1, m.k | 0));
      const out = JSON.stringify({ t: 'v', n: ws.n, a: m.a, mt: String(m.mt || 'audio/webm').slice(0, 40), i: String(m.i || '').slice(0, 20), id: String(m.id || '').slice(0, 12), k, tot, bl: /^[0-9.,;]{1,300}$/.test(String(m.bl || '')) ? String(m.bl) : '' });
      for (const c of rooms.get(ws.room) || []) if (c !== ws && c.readyState === 1) c.send(out);
    } else if (m.t === 'e' && ws.room) {
      if (typeof m.k !== 'string' || !/^[a-z0-9]{1,12}$/.test(m.k)) return;
      let js; try { js = JSON.stringify(m.d === undefined ? {} : m.d); } catch (e) { return; }
      if (js.length > 4000) return;
      const now = Date.now(); if (now - (ws.eWin || 0) > 10000) { ws.eWin = now; ws.eN = 0; }
      if (++ws.eN > 120) return;   // 10 sn'de en çok 120 olay
      const out = JSON.stringify({ t: 'e', k: m.k, d: JSON.parse(js), i: String(m.i || '').slice(0, 20), n: ws.n });
      for (const c of rooms.get(ws.room) || []) if (c !== ws && c.readyState === 1) c.send(out);
    } else if (m.t === 'm' && ws.room) {
      const now = Date.now(); if (now - ws.lastMsg < 1000) return; ws.lastMsg = now;
      const text = clean(m.text, 80); if (!text) return;
      const out = JSON.stringify({ t: 'm', n: ws.n, text });
      for (const c of rooms.get(ws.room) || []) if (c.readyState === 1) c.send(out);
    }
  });
  ws.on('close', () => leave(ws));
  ws.on('error', () => { try { ws.terminate(); } catch (e) { } });
});
// bağlantısı kopanları temizle
setInterval(() => { wss.clients.forEach(ws => { if (!ws.alive) { ws.terminate(); return; } ws.alive = false; try { ws.ping(); } catch (e) { } }); }, 30000);
console.log('Çakma Surfers oda sunucusu ' + PORT + ' portunda çalışıyor');
