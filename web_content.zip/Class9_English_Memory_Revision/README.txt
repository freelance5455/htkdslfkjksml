CLASS 9 ENGLISH MEMORY REVISION GAME
Included:
- The Little Girl
- Reach for the Top: Santosh Yadav
- Reach for the Top: Maria Sharapova
- A Legend of the Northland

MODES:
- MCQ + correct answer shown immediately (no Check Answer button)
- Fill in the Blanks + answer shown immediately
- Memory Cards
- All Revision Notes
- All Questions & Answers

ANDROID / ACODE:
1. Extract the ZIP.
2. Open the folder in Acode.
3. Open index.html and use Preview / browser.
Works offline. No API, internet, account, or backend required.

This is a study revision set; check your textbook for any chapter-specific details your teacher emphasised.
