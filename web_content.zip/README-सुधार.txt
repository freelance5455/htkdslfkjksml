नास्तिक दर्शन — Android WebView के लिए सुधारी गई वेब सामग्री

समस्या:
APK की app_settings.json में localEntry = index.html है, इसलिए ऐप assets/web/index.html खोजता है।
पुराने APK में index.html assets/web/नास्तिक-दर्शन-अलग-पृष्ठ/index.html के अंदर था।

सुधार:
इस पैकेज में index.html सीधे रूट में है। सभी संबंधित HTML, images और अध्याय फाइलें अपने सापेक्ष पथ पर रखी गई हैं।

Android ऐप में:
इस पैकेज की सामग्री को ऐप के assets/web/ फोल्डर में सीधे रखें।
अंतिम संरचना:
assets/web/index.html
assets/web/कवर.html
assets/web/विषय-सूची.html
assets/web/images/cover.jpg
assets/web/अध्याय/अध्याय-001.html ... अध्याय-108.html

ध्यान दें:
यह वेब-सामग्री पैकेज है, इंस्टॉल करने योग्य APK नहीं। अंतिम APK को मूल Android प्रोजेक्ट या ऐप-बिल्डर से पुनः बनाकर हस्ताक्षरित करना होगा।
