# Carreira de Craque v1.62.75 — Uniformes Ligue 1 2026/27

- Adicionado catálogo visual próprio de camisas da Ligue 1 para os 18 clubes.
- Camisas titular, visitante e terceiro quando aplicável, com cores, padrões e fornecedores associados à temporada 2026/27.
- Desenhos vetoriais integrados ao sistema de prévia de camisa; não dependem de imagens remotas para aparecer.
- Preservados nome e número do atleta, seleção de uniforme e demais sistemas existentes.
- Os desenhos são recriações visuais simplificadas inspiradas nas referências públicas da temporada; patrocinadores, patches e microdetalhes não são reproduzidos como cópias oficiais.
