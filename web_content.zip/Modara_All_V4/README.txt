MODARA ALL V4 - Browser Prototype

Open index.html in a modern browser. It includes a first-open password gate (password: 19920805).
Data is saved locally in the browser/device. Export Backup regularly.
This is an HTML prototype, not a signed Android APK. Client-side password is basic access control and is not strong security.

Included sections:
- Water & Electricity
- Petty Cash
- Certificate Register
- Security Officer Attendance
- Asset Register (changes/pending status)
- Asset Hand Over
- New Asset Received (separate from Asset Register)
- Staff OT
