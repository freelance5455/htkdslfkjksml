import { chromium } from 'playwright'

const APP = 'http://localhost:5173'
const browser = await chromium.launch({
  executablePath: '/root/.cache/ms-playwright/chromium-1243/chrome-linux/chrome',
  args: ['--no-sandbox', '--disable-dev-shm-usage'],
})

const errors = []
const page = await browser.newPage({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 2 })
page.on('console', (m) => { if (m.type() === 'error') errors.push(`[console] ${m.text()}`) })
page.on('pageerror', (e) => errors.push(`[pageerror] ${e.message}`))
page.on('requestfailed', (r) => errors.push(`[reqfail] ${r.url()} :: ${r.failure()?.errorText}`))

await page.goto(APP, { waitUntil: 'networkidle' })
await page.waitForTimeout(900)

console.log('TITLE:', await page.title())
console.log('ROBOT parts:', await page.locator('.robot svg path, .robot svg rect, .robot svg circle, .robot svg ellipse').count())
console.log('MODES:', await page.locator('.mode-item').count())
console.log('STATUS:', (await page.locator('.hero-status').textContent()).trim())
await page.screenshot({ path: 'shots/astra-home.png' })

// --- configure mock provider first ---
await page.evaluate(() => {
  localStorage.setItem('astra.settings', JSON.stringify({
    provider: 'custom', baseUrl: 'http://localhost:8899/v1', apiKey: 'test-key', model: 'default', search: true,
  }))
})
await page.reload({ waitUntil: 'networkidle' })
await page.waitForTimeout(800)

// --- TUTOR mode ---
await page.click('.mode-item:nth-child(2)')
await page.waitForTimeout(400)
console.log('MODE:', (await page.locator('.hero-text h1').textContent()).trim())
await page.fill('.composer textarea', 'Explain photosynthesis for class 9')
await page.click('.send-btn')
await page.waitForTimeout(1200)
console.log('MOOD while thinking:', (await page.locator('.robot').getAttribute('class')).split(' ').pop())
await page.waitForTimeout(4000)

const bot1 = await page.locator('.msg-bot .bubble').first().innerText()
console.log('TUTOR DETECTED:', bot1.includes('TUTOR') ? 'YES ✓' : 'NO ✗')
console.log('SEARCH INJECTED:', /sources injected: `([1-9])/.exec(bot1)?.[1] ?? '0')
console.log('MD headings:', await page.locator('.md h2, .md h3, .md h4').count())
console.log('MD li:', await page.locator('.md li').count(), '| pre:', await page.locator('.md pre code').count(), '| quote:', await page.locator('.md blockquote').count(), '| link:', await page.locator('.md a').count())
console.log('SOURCE LABEL:', (await page.locator('.sources-toggle').textContent()).trim())
await page.screenshot({ path: 'shots/astra-chat.png' })

// --- mode persists across reload ---
await page.reload({ waitUntil: 'networkidle' })
await page.waitForTimeout(900)
console.log('MODE AFTER RELOAD:', (await page.locator('.hero-text h1').textContent()).trim())

// --- BUSINESS mode ---
await page.click('.mode-item:nth-child(3)')
await page.waitForTimeout(300)
await page.fill('.composer textarea', 'My clothing shop is losing customers')
await page.click('.send-btn')
await page.waitForTimeout(4500)
const bot2 = await page.locator('.msg-bot .bubble').last().innerText()
console.log('BUSINESS DETECTED:', bot2.includes('BUSINESS') ? 'YES ✓' : 'NO ✗')

// --- suggestions / empty state on a new chat ---
await page.click('.new-chat')
await page.waitForTimeout(500)
console.log('NEW CHAT suggestions:', await page.locator('.suggest').count())

// --- settings ---
await page.click('.side-settings')
await page.waitForTimeout(500)
await page.screenshot({ path: 'shots/astra-settings.png' })
console.log('SETTINGS open:', await page.locator('.settings-panel').count())

// --- history persists ---
await page.click('.modal-foot .btn.primary')
await page.reload({ waitUntil: 'networkidle' })
await page.waitForTimeout(900)
console.log('HISTORY:', await page.locator('.conv-item').count(), 'conversations,', await page.locator('.msg').count(), 'messages')

// --- mobile ---
const m = await browser.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 })
m.on('pageerror', (e) => errors.push(`[mobile] ${e.message}`))
await m.goto(APP, { waitUntil: 'networkidle' })
await m.waitForTimeout(900)
await m.screenshot({ path: 'shots/astra-mobile.png' })
console.log('MOBILE menu visible:', await m.locator('.menu-btn').isVisible())
await m.click('.menu-btn')
await m.waitForTimeout(500)
await m.screenshot({ path: 'shots/astra-mobile-menu.png' })

await browser.close()
console.log('ERRORS:', errors.length ? errors : 'none')
