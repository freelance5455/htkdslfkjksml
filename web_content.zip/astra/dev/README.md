# Dev tools (optional)

These let you exercise the whole chat pipeline **without spending money on API calls**.

```bash
# terminal 1 — fake OpenAI-compatible endpoint on :8899
node dev/dev-mock-llm.mjs

# terminal 2 — app on :5173, API on :8787
npm run dev:full

# terminal 3 — headless browser test
npm i -D playwright && node dev/e2e.mjs
```

The mock replies with markdown that reports which **mode** prompt it received and how many
**web sources** were injected, so the test asserts that mode switching and live search
actually reach the LLM.
