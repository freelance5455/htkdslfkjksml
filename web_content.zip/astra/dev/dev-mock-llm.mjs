// TEMPORARY dev stub — an OpenAI-compatible endpoint used to verify the full
// chat pipeline locally without a real provider key. Not part of the app.
import http from 'node:http'

const server = http.createServer((req, res) => {
  let body = ''
  req.on('data', (c) => (body += c))
  req.on('end', () => {
    if (!req.url.includes('/chat/completions')) {
      res.writeHead(404).end('{}')
      return
    }
    let payload = {}
    try {
      payload = JSON.parse(body)
    } catch {}

    const sys = (payload.messages || []).find((m) => m.role === 'system')?.content || ''
    const user = (payload.messages || []).filter((m) => m.role === 'user').pop()?.content || ''

    const mode =
      sys.includes('patient and encouraging tutor')
        ? 'TUTOR'
        : sys.includes('pragmatic business advisor')
          ? 'BUSINESS'
          : 'GENERAL'
    const hasSearch = sys.includes('LIVE WEB RESULTS')
    const sources = (sys.match(/Source: https?:\/\/[^\s]+/g) || []).length

    const reply = `## ${mode} reply

You said: **${user.slice(0, 60)}**

Mode detected: \`${mode}\`
Live sources injected: \`${sources}\`
Search context present: \`${hasSearch}\`

### Here's how I'd approach it

1. First, break the problem into parts.
2. Then work through each one carefully.
3. Finally, check the result makes sense.

Some *italic* text and \`inline code\`.

\`\`\`js
const answer = 42
console.log(answer)
\`\`\`

> A short note to finish.

[Wikipedia link](https://en.wikipedia.org/wiki/Photosynthesis)`

    res.writeHead(200, { 'content-type': 'application/json' })
    res.end(
      JSON.stringify({
        id: 'mock-1',
        object: 'chat.completion',
        choices: [{ index: 0, message: { role: 'assistant', content: reply }, finish_reason: 'stop' }],
        usage: { prompt_tokens: 10, completion_tokens: 10, total_tokens: 20 },
      })
    )
  })
})

server.listen(8899, () => console.log('mock llm on :8899'))
