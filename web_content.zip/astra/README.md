# Astra — AI Assistant

An AI assistant built for two real jobs:

- 🎓 **Homework Tutor** — step-by-step teaching, hints before answers, Indian
  syllabus/₹ context, and a "check your understanding" question at the end.
- 💼 **Business Advisor** — frames the actual problem, gives 2–3 options with
  trade-offs, then a concrete action plan with numbers and risks.
- 🌐 **General** — everything else.

It has a **robot avatar** that reacts (blinks, thinks, talks), **live web search**
with clickable sources, **voice input** and **read-aloud**, and a chat history that
saves in your browser.

---

## Quick start

```bash
npm install
```

### Option A — full mode (recommended)

```bash
cp server/.env.example server/.env    # paste your API key into LLM_API_KEY
npm run dev:full                      # web on :5173, API on :8787
```

### Option B — browser only

```bash
npm install
npm run dev
```

Open the app, hit **⚙️ Settings**, paste an API key, and go. Everything except
web search works (search needs the local server). OpenRouter and Anthropic work
directly from the browser; OpenAI/Groq/Google need the server because their APIs
block browser calls.

### Production

```bash
npm run build     # static frontend → dist/
npm start         # express serves dist/ + /api on :8787
```

---

## Getting an API key (all have free tiers)

| Provider | Where | Notes |
|---|---|---|
| **OpenRouter** | openrouter.ai/keys | ⭐ easiest — many free models, works in-browser |
| **Groq** | console.groq.com/keys | very fast, generous free tier |
| **Google AI Studio** | aistudio.google.com/apikey | Gemini free tier |
| DeepSeek | platform.deepseek.com | very cheap |
| OpenAI | platform.openai.com/api-keys | paid |
| Anthropic | console.anthropic.com | paid |
| **Ollama** | run `ollama serve` | no key, fully offline — pick "Ollama" provider |

---

## How the key is handled

- Paste it in **Settings** → stored in your browser's `localStorage` only, sent
  directly to the provider you chose.
- If the local server has `LLM_API_KEY` set, the key stays on your machine and
  the browser never handles it.

## Web search

Free by default: **Wikipedia + DuckDuckGo** (no key, no signup). For better
results add `TAVILY_API_KEY` or `BRAVE_API_KEY` to `server/.env`.

Search only runs when the toggle in Settings is on, and the sources appear
under the answer so you can check them.

## Project structure

```
src/
  App.jsx                 # shell, chat flow, history, robot moods
  styles.css              # design tokens + all styling
  lib/
    api.js                # server + browser chat paths, settings, history
    modes.js              # the three assistant modes and starter prompts
    markdown.js           # safe markdown renderer (escape-first)
    providersBrowser.js   # provider registry for browser calls
  components/
    Robot.jsx             # animated SVG robot avatar
    Message.jsx           # bubbles, markdown, source list
    Composer.jsx          # input, voice, send
    Settings.jsx          # provider / key / toggles
server/
  index.js                # express API + static hosting + mode prompts
  providers.js            # provider registry + LLM dispatch
  search.js               # web search (Wikipedia, DuckDuckGo, Tavily, Brave)
  .env.example
```

## Modes in detail

**Tutor** — never dumps the final answer. Names the concept, shows every step,
uses relatable Indian examples, gives a hint when the student is stuck, and ends
with a check-your-understanding question.

**Business** — reframes the problem first, offers options with trade-offs, then
gives a this-week action plan, estimates with stated assumptions, and the risks
worth testing cheaply first.

## Notes

- Chat history and settings live in `localStorage` (`astra.history`, `astra.settings`).
- The robot is pure SVG/CSS — no image files, no extra weight.
- The markdown renderer escapes HTML before formatting, so model output can't inject scripts.

## AURA Command Centre additions

- **Hey AURA wake word:** browser speech recognition toggle in the top bar. Requires microphone permission and a browser that supports Web Speech recognition (Chrome/Edge recommended). It listens while the page is open.
- **Local long-term memory:** add user-approved notes in Hub → Long-term memory. Notes remain in this browser's local storage and are included in relevant assistant prompts.
- **Tasks and reminders:** create tasks/reminders in Hub → Tasks & reminders. Browser notifications require permission; Astra must remain open for reminders to fire.
- **Offline AI:** select Ollama in Settings, install Ollama separately, start it with `ollama serve`, and pull a model such as `ollama pull llama3.2`. The local OpenAI-compatible endpoint is `http://localhost:11434/v1`; no API key is needed. Offline operation depends on the model being downloaded first.

These additions are local-device features. They do not provide cloud account login/sync or smart-home device control. Use a trusted HTTPS deployment and a proper authenticated backend before exposing private data over a network.
