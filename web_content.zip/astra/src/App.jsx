import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import Robot from './components/Robot.jsx'
import Message from './components/Message.jsx'
import Composer from './components/Composer.jsx'
import Settings from './components/Settings.jsx'
import AssistantHub from './components/AssistantHub.jsx'
import { MODES, getMode } from './lib/modes.js'
import {
  DEFAULT_SETTINGS,
  detectServer,
  loadSettings,
  saveSettings,
  loadHistory,
  saveHistory,
  sendChat,
} from './lib/api.js'
import { stripMarkdown } from './lib/markdown.js'

const uid = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`

export default function App() {
  const [settings, setSettings] = useState(() => loadSettings())
  const [mode, setMode] = useState(() => {
    try {
      return localStorage.getItem('astra.mode') || 'general'
    } catch {
      return 'general'
    }
  })
  const [conversations, setConversations] = useState(() => loadHistory())
  const [activeId, setActiveId] = useState(null)
  const [busy, setBusy] = useState(false)
  const [mood, setMood] = useState('idle')
  const [speaking, setSpeaking] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [showHub, setShowHub] = useState(false)
  const [memory, setMemory] = useState(() => { try { return localStorage.getItem('astra.memory') || '' } catch { return '' } })
  const [wakeListening, setWakeListening] = useState(false)
  const [wakeSupported, setWakeSupported] = useState(false)
  const [server, setServer] = useState(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const scrollRef = useRef(null)
  const recognitionRef = useRef(null)
  const modeInfo = getMode(mode)
  const [robotSize, setRobotSize] = useState(132)

  /* responsive robot size */
  useEffect(() => {
    const onResize = () => setRobotSize(window.innerWidth < 520 ? 92 : window.innerWidth < 900 ? 112 : 132)
    onResize()
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  /* Some hosts inject a floating widget at the bottom of the page. Detect it and
     lift the composer clear so the send button is never covered. */
  useEffect(() => {
    const check = () => {
      const el = document.getElementById('minimax-floating-ball') || document.querySelector('[id*="floating-ball"]')
      document.documentElement.classList.toggle('has-floating-widget', Boolean(el))
    }
    check()
    const t = setInterval(check, 1500)
    return () => clearInterval(t)
  }, [])

  /* ---------------- boot ---------------- */
  useEffect(() => {
    detectServer().then(setServer)
    const stored = loadSettings()
    setSettings(stored)
  }, [])

  useEffect(() => {
    saveSettings(settings)
  }, [settings])

  useEffect(() => {
    saveHistory(conversations)
  }, [conversations])

  useEffect(() => {
    document.documentElement.style.setProperty('--mode-accent', modeInfo.accent)
  }, [modeInfo])

  useEffect(() => {
    try {
      localStorage.setItem('astra.mode', mode)
    } catch {
      /* storage blocked */
    }
  }, [mode])

  /* Browser wake-word listener: requires microphone permission and a supported browser. */
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    setWakeSupported(Boolean(SpeechRecognition))
    if (!wakeListening || !SpeechRecognition) return
    const recognition = new SpeechRecognition()
    recognition.lang = 'en-IN'
    recognition.continuous = true
    recognition.interimResults = false
    recognition.onresult = (event) => {
      const phrase = event.results[event.results.length - 1][0].transcript.trim()
      if (/\bhey\s+aura\b/i.test(phrase)) {
        const command = phrase.replace(/.*?\bhey\s+aura\b/i, '').trim()
        if (command) send(command)
        else send('Hello AURA, I am listening.')
      }
    }
    recognition.onerror = () => setWakeListening(false)
    recognition.onend = () => { if (wakeListening) { try { recognition.start() } catch {} } }
    recognitionRef.current = recognition
    try { recognition.start() } catch { setWakeListening(false) }
    return () => { recognition.onend = null; recognition.stop(); recognitionRef.current = null }
  }, [wakeListening])

  const active = useMemo(
    () => conversations.find((c) => c.id === activeId) || null,
    [conversations, activeId]
  )

  const messages = active?.messages || []

  // open most recent conversation on first load
  useEffect(() => {
    if (!activeId && conversations.length) setActiveId(conversations[0].id)
  }, [conversations, activeId])

  /* ---------------- scroll ---------------- */
  useEffect(() => {
    const el = scrollRef.current
    if (el) el.scrollTop = el.scrollHeight
  }, [messages.length, busy])

  /* ---------------- speech ---------------- */
  const stopSpeech = useCallback(() => {
    if (window.speechSynthesis) window.speechSynthesis.cancel()
    setSpeaking(false)
  }, [])

  const speak = useCallback(
    (text) => {
      if (!settings.voice || !window.speechSynthesis) return
      const clean = stripMarkdown(text).slice(0, 3000)
      if (!clean) return
      window.speechSynthesis.cancel()
      const u = new SpeechSynthesisUtterance(clean)
      u.lang = 'en-IN'
      u.rate = 1
      u.onend = () => setSpeaking(false)
      u.onerror = () => setSpeaking(false)
      window.speechSynthesis.speak(u)
      setSpeaking(true)
    },
    [settings.voice]
  )

  const toggleSpeak = useCallback(() => {
    if (speaking) {
      stopSpeech()
      return
    }
    const last = [...messages].reverse().find((m) => m.role === 'assistant' && !m.error)
    if (last) speak(last.content)
  }, [speaking, messages, speak, stopSpeech])

  /* ---------------- chat ---------------- */
  async function send(text) {
    stopSpeech()

    let convId = activeId
    if (!convId) {
      convId = uid()
      setActiveId(convId)
    }

    const userMsg = { id: uid(), role: 'user', content: text, createdAt: Date.now() }
    const pendingMsg = { id: uid(), role: 'assistant', content: '', pending: true, createdAt: Date.now() }

    const title = text.trim().slice(0, 42) + (text.trim().length > 42 ? '…' : '')

    setConversations((prev) => {
      const idx = prev.findIndex((c) => c.id === convId)
      const base = idx >= 0 ? prev[idx] : { id: convId, title, mode, createdAt: Date.now(), messages: [] }
      const next = {
        ...base,
        title: base.messages?.length ? base.title : title,
        mode,
        messages: [...(base.messages || []), userMsg, pendingMsg],
      }
      const rest = prev.filter((c) => c.id !== convId)
      return [next, ...rest]
    })

    setBusy(true)
    setMood('thinking')

    try {
      const history = messages.map((m) => ({ role: m.role, content: m.content }))
      const res = await sendChat({
        settings,
        mode,
        messages: [...(memory.trim() ? [{ role: 'system', content: `User-approved local memory (use only when relevant):\n${memory.slice(0, 5000)}` }] : []), ...history, { role: 'user', content: text }],
        search: settings.search,
      })

      setConversations((prev) =>
        prev.map((c) =>
          c.id === convId
            ? {
                ...c,
                messages: (c.messages || []).map((m) =>
                  m.id === pendingMsg.id
                    ? { ...m, pending: false, content: res.reply, sources: res.sources || [] }
                    : m
                ),
              }
            : c
        )
      )
      setMood('happy')
      setTimeout(() => setMood((m) => (m === 'happy' ? 'idle' : m)), 2200)
      if (settings.voice) setTimeout(() => speak(res.reply), 250)
    } catch (err) {
      setConversations((prev) =>
        prev.map((c) =>
          c.id === convId
            ? {
                ...c,
                messages: (c.messages || []).map((m) =>
                  m.id === pendingMsg.id
                    ? { ...m, pending: false, error: true, content: err.message }
                    : m
                ),
              }
            : c
        )
      )
      setMood('sad')
      setTimeout(() => setMood((m) => (m === 'sad' ? 'idle' : m)), 3000)
    } finally {
      setBusy(false)
    }
  }

  function newChat() {
    stopSpeech()
    setActiveId(null)
    setConversations((prev) => [{ id: uid(), title: 'New chat', mode, createdAt: Date.now(), messages: [] }, ...prev.filter(c=>c.messages.length)])
    setMood('idle')
  }

  function clearHistory() {
    setConversations([])
    setActiveId(null)
    setShowSettings(false)
    setMood('idle')
  }

  function copy(text) {
    navigator.clipboard?.writeText(text)
  }

  function deleteConversation(id) {
    setConversations((prev) => prev.filter((c) => c.id !== id))
    if (activeId === id) setActiveId(null)
  }

  /* ---------------- render ---------------- */
  return (
    <div className="app">
      {/* ---------- sidebar ---------- */}
      <aside className={`sidebar${sidebarOpen ? ' open' : ''}`}>
        <div className="side-brand">
          <span className="brand-mark">✦</span>
          <div>
            <strong>Astra</strong>
            <span>AI Assistant</span>
          </div>
          <button className="icon-btn side-close" onClick={() => setSidebarOpen(false)} aria-label="Close menu">✕</button>
        </div>

        <button className="new-chat" onClick={newChat}>
          <span>＋</span> New chat
        </button>

        <div className="side-section-label">Mode</div>
        <div className="mode-list">
          {MODES.map((m) => (
            <button
              key={m.id}
              className={`mode-item${mode === m.id ? ' active' : ''}`}
              style={mode === m.id ? { borderColor: m.accent } : undefined}
              onClick={() => {
                setMode(m.id)
                setSidebarOpen(false)
              }}
            >
              <span className="mode-emoji">{m.emoji}</span>
              <span className="mode-text">
                <strong>{m.label}</strong>
                <em>{m.tagline}</em>
              </span>
            </button>
          ))}
        </div>

        <div className="side-section-label">Recent</div>
        <div className="conv-list">
          {conversations.filter((c) => c.messages?.length).length === 0 && (
            <p className="no-convs">No chats yet</p>
          )}
          {conversations
            .filter((c) => c.messages?.length)
            .map((c) => (
              <div
                key={c.id}
                className={`conv-item${c.id === activeId ? ' active' : ''}`}
                onClick={() => {
                  setActiveId(c.id)
                  setSidebarOpen(false)
                }}
              >
                <span>{c.title}</span>
                <button
                  className="conv-del"
                  onClick={(e) => {
                    e.stopPropagation()
                    deleteConversation(c.id)
                  }}
                  aria-label="Delete chat"
                >
                  🗑️
                </button>
              </div>
            ))}
        </div>

        <button className="side-settings" onClick={() => setShowSettings(true)}>
          ⚙️ Settings
        </button>
      </aside>

      {sidebarOpen && <div className="sidebar-scrim" onClick={() => setSidebarOpen(false)} />}

      {/* ---------- main ---------- */}
      <main className="main">
        <header className="topbar">
          <button className="icon-btn menu-btn" onClick={() => setSidebarOpen(true)} aria-label="Menu">☰</button>
          <div className="mode-tabs">
            {MODES.map((m) => (
              <button
                key={m.id}
                className={`mode-tab${mode === m.id ? ' active' : ''}`}
                style={mode === m.id ? { borderColor: m.accent, color: m.accent } : undefined}
                onClick={() => setMode(m.id)}
              >
                <span>{m.emoji}</span>
                <span className="tab-label">{m.label}</span>
              </button>
            ))}
          </div>
          <div className="top-actions"><button className={`icon-btn wake-btn${wakeListening ? ' listening' : ''}`} disabled={!wakeSupported} onClick={() => setWakeListening(v => !v)} title={wakeSupported ? 'Toggle Hey AURA wake word' : 'Voice recognition is not supported in this browser'}>{wakeListening ? '🎙️' : '🎤'}<span>{wakeListening ? 'Listening' : 'Hey AURA'}</span></button><button className="icon-btn hub-btn" onClick={() => setShowHub(true)} aria-label="Command centre">✦<span>Hub</span></button><button className="icon-btn" onClick={() => setShowSettings(true)} aria-label="Settings">⚙️</button></div>
        </header>

        <div className="chat-wrap">
          <div className="hero">
            <Robot mood={mood} size={robotSize} speaking={speaking} />
            <div className="hero-text">
              <h1>{modeInfo.emoji} {modeInfo.label}</h1>
              <p>{modeInfo.tagline}</p>
              <div className="hero-status">
                <span className={`dot ${server?.available ? 'on' : 'off'}`} />
                {server?.available ? 'online · web search ready' : 'browser mode · add a key in settings'}
              </div>
            </div>
          </div>

          <div className="scroll" ref={scrollRef}>
            {messages.length === 0 ? (
              <div className="suggestions">
                <p className="suggest-title">Try asking</p>
                {modeInfo.prompts.map((p) => (
                  <button key={p} className="suggest" onClick={() => send(p)}>
                    <span className="suggest-icon">{modeInfo.emoji}</span>
                    {p}
                  </button>
                ))}
              </div>
            ) : (
              messages.map((m) => <Message key={m.id} msg={m} onCopy={copy} />)
            )}
          </div>
        </div>

        <Composer
          onSend={send}
          busy={busy}
          mode={mode}
          onSpeak={toggleSpeak}
          speaking={speaking}
        />
      </main>

      {showHub && <AssistantHub onClose={() => setShowHub(false)} onRemember={setMemory} />}

      {showSettings && (
        <Settings
          settings={settings}
          onChange={setSettings}
          onClose={() => setShowSettings(false)}
          server={server}
          onClearHistory={clearHistory}
        />
      )}
    </div>
  )
}
