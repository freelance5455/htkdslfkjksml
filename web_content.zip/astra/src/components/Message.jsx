import { useMemo, useState } from 'react'
import { renderMarkdown } from '../lib/markdown'

function Sources({ sources }) {
  const [open, setOpen] = useState(false)
  if (!sources?.length) return null
  return (
    <div className="sources">
      <button className="sources-toggle" onClick={() => setOpen((o) => !o)}>
        🌐 {sources.length} web {sources.length === 1 ? 'source' : 'sources'}
        <span className="caret">{open ? '▲' : '▼'}</span>
      </button>
      {open && (
        <ol className="sources-list">
          {sources.map((s, i) => (
            <li key={s.url + i}>
              <a href={s.url} target="_blank" rel="noopener noreferrer">
                {s.title}
              </a>
              <span className="source-host">{s.source}</span>
              {s.snippet && <p>{s.snippet}</p>}
            </li>
          ))}
        </ol>
      )}
    </div>
  )
}

export default function Message({ msg, onCopy }) {
  const html = useMemo(() => (msg.role === 'assistant' ? renderMarkdown(msg.content) : ''), [msg])

  if (msg.role === 'user') {
    return (
      <div className="msg msg-user">
        <div className="bubble">{msg.content}</div>
      </div>
    )
  }

  if (msg.pending) {
    return (
      <div className="msg msg-bot">
        <div className="bubble typing">
          <span />
          <span />
          <span />
        </div>
      </div>
    )
  }

  return (
    <div className="msg msg-bot">
      <div className="bubble">
        {msg.error ? (
          <div className="msg-error">
            <strong>⚠️ Something went wrong</strong>
            <p>{msg.content}</p>
          </div>
        ) : (
          <div className="md" dangerouslySetInnerHTML={{ __html: html }} />
        )}
        <Sources sources={msg.sources} />
        {!msg.error && onCopy && (
          <button className="copy-btn" onClick={() => onCopy(msg.content)} title="Copy answer">
            ⧉ Copy
          </button>
        )}
      </div>
    </div>
  )
}
