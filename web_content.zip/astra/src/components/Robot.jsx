import { useEffect, useRef } from 'react'

/**
 * Astra's robot avatar. Pure SVG + CSS — no image assets.
 * mood: 'idle' | 'thinking' | 'talking' | 'happy' | 'sad' | 'error'
 */
export default function Robot({ mood = 'idle', size = 120, speaking = false }) {
  const eyeL = useRef(null)
  const eyeR = useRef(null)
  const mouth = useRef(null)
  const antenna = useRef(null)

  // Random blink every 3-6s
  useEffect(() => {
    let t
    const schedule = () => {
      t = setTimeout(() => {
        blink()
        schedule()
      }, 3000 + Math.random() * 3000)
    }
    const blink = () => {
      ;[eyeL, eyeR].forEach((r) => {
        if (!r.current) return
        r.current.style.transform = 'scaleY(0.08)'
        setTimeout(() => {
          if (r.current) r.current.style.transform = 'scaleY(1)'
        }, 130)
      })
    }
    schedule()
    return () => clearTimeout(t)
  }, [])

  // Mouth movement while "talking"
  useEffect(() => {
    if (!speaking || !mouth.current) return
    let frame
    const start = Date.now()
    const tick = () => {
      const el = mouth.current
      if (!el) return
      const t = (Date.now() - start) / 1000
      const h = 4 + Math.abs(Math.sin(t * 9)) * 9
      el.setAttribute('ry', String(h))
      frame = requestAnimationFrame(tick)
    }
    frame = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(frame)
  }, [speaking])

  const eyeY = mood === 'sad' ? 4 : 0
  const mouthRy = mood === 'happy' ? 9 : mood === 'sad' ? 5 : mood === 'thinking' ? 2 : 7

  return (
    <div className={`robot robot-${mood}`} style={{ width: size, height: size }}>
      <svg viewBox="0 0 200 200" width={size} height={size} role="img" aria-label="Astra robot avatar">
        <defs>
          <linearGradient id="rBody" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="var(--robot-1)" />
            <stop offset="100%" stopColor="var(--robot-2)" />
          </linearGradient>
          <linearGradient id="rScreen" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--robot-screen-1)" />
            <stop offset="100%" stopColor="var(--robot-screen-2)" />
          </linearGradient>
          <radialGradient id="rGlow" cx="50%" cy="50%">
            <stop offset="0%" stopColor="var(--robot-glow)" stopOpacity="0.55" />
            <stop offset="100%" stopColor="var(--robot-glow)" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* ambient glow */}
        <circle cx="100" cy="96" r="92" fill="url(#rGlow)" className="robot-glow" />

        {/* antenna */}
        <g ref={antenna} className="robot-antenna">
          <line x1="100" y1="34" x2="100" y2="18" stroke="var(--robot-metal)" strokeWidth="4" strokeLinecap="round" />
          <circle cx="100" cy="14" r="7" fill="var(--robot-accent)" className="robot-antenna-ball" />
        </g>

        {/* head */}
        <rect x="46" y="32" width="108" height="86" rx="28" fill="url(#rBody)" />
        <rect x="46" y="32" width="108" height="86" rx="28" fill="none" stroke="var(--robot-metal)" strokeWidth="3" />

        {/* ears */}
        <rect x="34" y="62" width="14" height="26" rx="7" fill="var(--robot-metal)" />
        <rect x="152" y="62" width="14" height="26" rx="7" fill="var(--robot-metal)" />

        {/* face screen */}
        <rect x="60" y="48" width="80" height="52" rx="20" fill="url(#rScreen)" />

        {/* eyes */}
        <g ref={eyeL} className="robot-eye" style={{ transformOrigin: '81px 70px' }}>
          <ellipse cx="81" cy={70 + eyeY} rx="8.5" ry="10" fill="var(--robot-eye)" />
        </g>
        <g ref={eyeR} className="robot-eye" style={{ transformOrigin: '119px 70px' }}>
          <ellipse cx="119" cy={70 + eyeY} rx="8.5" ry="10" fill="var(--robot-eye)" />
        </g>

        {/* blush */}
        {mood === 'happy' && (
          <>
            <circle cx="68" cy="86" r="6" fill="var(--robot-blush)" opacity="0.75" />
            <circle cx="132" cy="86" r="6" fill="var(--robot-blush)" opacity="0.75" />
          </>
        )}

        {/* mouth */}
        <ellipse
          ref={mouth}
          cx="100"
          cy="90"
          rx="11"
          ry={mouthRy}
          fill="var(--robot-mouth)"
          className="robot-mouth"
        />

        {/* neck */}
        <rect x="90" y="116" width="20" height="14" fill="var(--robot-metal)" />

        {/* body */}
        <rect x="62" y="128" width="76" height="52" rx="20" fill="url(#rBody)" />
        <rect x="62" y="128" width="76" height="52" rx="20" fill="none" stroke="var(--robot-metal)" strokeWidth="3" />
        <circle cx="100" cy="150" r="11" fill="var(--robot-screen-1)" />
        <circle cx="100" cy="150" r="11" fill="none" stroke="var(--robot-metal)" strokeWidth="2.5" />
        <circle cx="100" cy="150" r="4" fill="var(--robot-accent)" className="robot-core" />

        {/* arms */}
        <g className="robot-arm robot-arm-l">
          <rect x="40" y="134" width="16" height="44" rx="8" fill="var(--robot-metal)" />
        </g>
        <g className="robot-arm robot-arm-r">
          <rect x="144" y="134" width="16" height="44" rx="8" fill="var(--robot-metal)" />
        </g>
      </svg>

      {mood === 'thinking' && (
        <div className="robot-think">
          <span />
          <span />
          <span />
        </div>
      )}
    </div>
  )
}
