import { useState } from 'react'
import { providerList } from '../lib/providersBrowser.js'

const PROVIDERS = providerList()

export default function Settings({ settings, onChange, onClose, server, onClearHistory }) {
  const [showKey, setShowKey] = useState(false)
  const provider = PROVIDERS.find((p) => p.id === settings.provider) || PROVIDERS[0]

  const set = (k, v) => onChange({ ...settings, [k]: v })

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal settings-panel" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <h2>⚙️ Settings</h2>
          <button className="icon-btn" onClick={onClose} aria-label="Close">✕</button>
        </div>

        <div className="modal-body">
          <div className="status-strip">
            <span className={`dot ${server?.available ? 'on' : 'off'}`} />
            <div>
              <strong>{server?.available ? 'Server connected' : 'No local server'}</strong>
              <p>
                {server?.available
                  ? `Search engine: ${server.searchEngine || 'free sources'}${server.serverKeyConfigured ? ' · server has its own API key' : ''}`
                  : 'Running browser-only. Paste a key below — for best results also run `npm run dev:full` locally.'}
              </p>
            </div>
          </div>

          <label className="field">
            <span>AI provider</span>
            <select value={settings.provider} onChange={(e) => {
              const p = PROVIDERS.find((x) => x.id === e.target.value)
              set('provider', e.target.value)
              if (p) set('model', p.models[0].id)
            }}>
              {PROVIDERS.map((p) => (
                <option key={p.id} value={p.id}>{p.label}</option>
              ))}
            </select>
          </label>

          <p className="hint">{provider.hint}</p>

          <label className="field">
            <span>Model</span>
            <select value={settings.model} onChange={(e) => set('model', e.target.value)}>
              {provider.models.map((m) => (
                <option key={m.id} value={m.id}>{m.label}</option>
              ))}
            </select>
          </label>

          <label className="field">
            <span>API key</span>
            <div className="key-row">
              <input
                type={showKey ? 'text' : 'password'}
                value={settings.apiKey}
                onChange={(e) => set('apiKey', e.target.value)}
                placeholder="sk-..."
                autoComplete="off"
                spellCheck={false}
              />
              <button className="icon-btn" onClick={() => setShowKey((s) => !s)} aria-label="Toggle visibility">
                {showKey ? '🙈' : '👁️'}
              </button>
            </div>
          </label>

          {settings.provider === 'ollama' && (
            <div className="privacy-note">Offline setup: install Ollama, run <code>ollama serve</code>, then download a model with <code>ollama pull llama3.2</code>. No API key is required. Keep the model running on this laptop.</div>
          )}

          {settings.provider === 'custom' && (
            <label className="field">
              <span>Base URL</span>
              <input
                type="text"
                value={settings.baseUrl}
                onChange={(e) => set('baseUrl', e.target.value)}
                placeholder="http://localhost:11434/v1"
                spellCheck={false}
              />
            </label>
          )}

          <label className="switch">
            <input
              type="checkbox"
              checked={settings.search}
              onChange={(e) => set('search', e.target.checked)}
            />
            <span className="switch-ui" />
            <div>
              <strong>Search the web</strong>
              <p>Pulls live sources before answering. Needs the local server.</p>
            </div>
          </label>

          <label className="switch">
            <input
              type="checkbox"
              checked={settings.voice}
              onChange={(e) => set('voice', e.target.checked)}
            />
            <span className="switch-ui" />
            <div>
              <strong>Read answers aloud</strong>
              <p>Uses your browser's built-in voice. Works offline.</p>
            </div>
          </label>

          <div className="privacy-note">
            🔒 Your API key is stored only in this browser (localStorage) and sent straight to the AI
            provider you pick. If a local server is running with its own LLM_API_KEY, the key stays on
            your machine instead.
          </div>

          <button className="btn danger full" onClick={onClearHistory}>
            Clear chat history
          </button>
        </div>

        <div className="modal-foot">
          <button className="btn primary" onClick={onClose}>Done</button>
        </div>
      </div>
    </div>
  )
}
