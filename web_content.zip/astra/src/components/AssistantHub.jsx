import { useEffect, useMemo, useState } from 'react'

const read = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback } catch { return fallback } }
const write = (key, value) => { try { localStorage.setItem(key, JSON.stringify(value)) } catch {} }

export default function AssistantHub({ onClose, onRemember }) {
  const [tab, setTab] = useState('tasks')
  const [tasks, setTasks] = useState(() => read('astra.tasks', []))
  const [memory, setMemory] = useState(() => read('astra.memory', ''))
  const [title, setTitle] = useState('')
  const [due, setDue] = useState('')
  const [kind, setKind] = useState('task')
  const [permission, setPermission] = useState(typeof Notification === 'undefined' ? 'unsupported' : Notification.permission)

  useEffect(() => { write('astra.tasks', tasks) }, [tasks])
  useEffect(() => { write('astra.memory', memory); onRemember(memory) }, [memory, onRemember])
  useEffect(() => {
    if (typeof Notification === 'undefined') return
    const timer = window.setInterval(() => {
      const now = Date.now()
      setTasks(current => current.map(item => {
        if (!item.done && !item.notified && item.due && new Date(item.due).getTime() <= now) {
          if (Notification.permission === 'granted') new Notification(item.kind === 'reminder' ? 'AURA reminder' : 'AURA task', { body: item.title })
          return { ...item, notified: true }
        }
        return item
      }))
    }, 15000)
    return () => clearInterval(timer)
  }, [])

  const upcoming = useMemo(() => [...tasks].filter(t => !t.done).sort((a,b) => (a.due || '9999').localeCompare(b.due || '9999')), [tasks])
  function addItem(e) {
    e.preventDefault()
    if (!title.trim()) return
    setTasks(old => [{ id: crypto.randomUUID(), title: title.trim(), due, kind, done: false, notified: false }, ...old])
    setTitle(''); setDue('')
  }
  async function enableNotifications() {
    if (typeof Notification !== 'undefined') setPermission(await Notification.requestPermission())
  }

  return <div className="modal-backdrop" onClick={onClose}>
    <section className="modal hub-panel" onClick={e => e.stopPropagation()}>
      <div className="modal-head"><div><h2>✦ AURA Command Centre</h2><p className="hub-sub">Your private, on-this-device assistant space</p></div><button className="icon-btn" onClick={onClose}>✕</button></div>
      <div className="hub-tabs">
        <button className={tab==='tasks'?'active':''} onClick={()=>setTab('tasks')}>Tasks & reminders</button>
        <button className={tab==='memory'?'active':''} onClick={()=>setTab('memory')}>Long-term memory</button>
      </div>
      {tab === 'tasks' ? <div className="modal-body">
        <form className="hub-form" onSubmit={addItem}>
          <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="What should AURA remind you?" required />
          <div className="hub-form-row"><select value={kind} onChange={e=>setKind(e.target.value)}><option value="task">Task</option><option value="reminder">Reminder</option></select><input type="datetime-local" value={due} onChange={e=>setDue(e.target.value)} /><button className="btn primary" type="submit">Add</button></div>
        </form>
        <div className="hub-notice"><span>Notifications: {permission}</span><button className="btn" onClick={enableNotifications}>Enable notifications</button></div>
        <div className="hub-list">{upcoming.length ? upcoming.map(item=><div className="hub-item" key={item.id}><input aria-label="Mark complete" type="checkbox" checked={item.done} onChange={e=>setTasks(old=>old.map(t=>t.id===item.id?{...t,done:e.target.checked}:t))}/><div><strong>{item.title}</strong><small>{item.kind} {item.due ? `· ${new Date(item.due).toLocaleString()}` : '· No due time'}</small></div><button className="hub-delete" onClick={()=>setTasks(old=>old.filter(t=>t.id!==item.id))}>Delete</button></div>) : <p className="hub-empty">No pending tasks. Add your first reminder above.</p>}</div>
        <p className="hint">Reminders notify you while Astra is running in a supported browser. They are stored locally and are not cloud-synced.</p>
      </div> : <div className="modal-body"><label className="field"><span>Things AURA should remember</span><textarea rows="8" value={memory} onChange={e=>setMemory(e.target.value)} placeholder="Example: I prefer concise answers. My current project is..." /></label><p className="hint">Saved only in this browser on this laptop. Add information you are comfortable storing here; do not enter passwords or banking details.</p></div>}
      <div className="modal-foot"><button className="btn primary" onClick={onClose}>Done</button></div>
    </section>
  </div>
}
