import { useEffect, useRef, useState } from 'react'

export default function Composer({ onSend, busy, mode, onSpeak, speaking }) {
  const [text, setText] = useState('')
  const [listening, setListening] = useState(false)
  const recRef = useRef(null)
  const areaRef = useRef(null)

  useEffect(() => {
    const el = areaRef.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = `${Math.min(el.scrollHeight, 180)}px`
  }, [text])

  function submit(e) {
    e?.preventDefault()
    const t = text.trim()
    if (!t || busy) return
    onSend(t)
    setText('')
  }

  function onKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      submit()
    }
  }

  function toggleMic() {
    if (listening) {
      recRef.current?.stop()
      setListening(false)
      return
    }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition
    if (!SR) {
      alert('Voice input is not supported in this browser. Try Chrome or Edge.')
      return
    }
    const rec = new SR()
    rec.lang = 'en-IN'
    rec.interimResults = true
    rec.continuous = false
    rec.onresult = (e) => {
      let final = ''
      let interim = ''
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const t = e.results[i][0].transcript
        if (e.results[i].isFinal) final += t
        else interim += t
      }
      if (final) setText((prev) => (prev ? `${prev} ${final}` : final))
      else if (interim) setText((prev) => (prev ? `${prev} ${interim}` : interim))
    }
    rec.onend = () => setListening(false)
    rec.onerror = () => setListening(false)
    recRef.current = rec
    rec.start()
    setListening(true)
  }

  return (
    <form className="composer" onSubmit={submit}>
      <div className="composer-box">
        <textarea
          ref={areaRef}
          rows={1}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder={
            mode === 'tutor'
              ? 'Ask your homework question… (Enter to send, Shift+Enter for a new line)'
              : mode === 'business'
                ? 'Describe your business problem…'
                : 'Ask Astra anything…'
          }
          aria-label="Message"
        />
        <div className="composer-tools">
          <button
            type="button"
            className={`tool-btn mic${listening ? ' live' : ''}`}
            onClick={toggleMic}
            title={listening ? 'Stop listening' : 'Speak your question'}
            aria-label="Voice input"
          >
            {listening ? '⏹' : '🎙️'}
          </button>
          <button
            type="button"
            className={`tool-btn${speaking ? ' live' : ''}`}
            onClick={onSpeak}
            title={speaking ? 'Stop reading' : 'Read this answer aloud'}
            aria-label="Read aloud"
          >
            {speaking ? '🔇' : '🔊'}
          </button>
          <button type="submit" className="send-btn" disabled={!text.trim() || busy} aria-label="Send">
            {busy ? <span className="spinner" /> : '➤'}
          </button>
        </div>
      </div>
    </form>
  )
}
