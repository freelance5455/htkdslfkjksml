// LLM provider registry + chat dispatch.
// Supports OpenAI-compatible APIs (OpenAI, OpenRouter, Groq, DeepSeek, Together,
// Google Gemini's compat endpoint, MiniMax) plus native Anthropic.

export const PROVIDERS = {
  openrouter: {
    label: 'OpenRouter',
    baseUrl: 'https://openrouter.ai/api/v1',
    style: 'openai',
    models: [
      { id: 'google/gemini-2.0-flash-exp:free', label: 'Gemini 2.0 Flash (free)' },
      { id: 'meta-llama/llama-3.3-70b-instruct:free', label: 'Llama 3.3 70B (free)' },
      { id: 'openai/gpt-4o-mini', label: 'GPT-4o mini' },
    ],
    hint: 'Free models available. Get a key at openrouter.ai/keys',
    free: true,
  },
  openai: {
    label: 'OpenAI',
    baseUrl: 'https://api.openai.com/v1',
    style: 'openai',
    models: [
      { id: 'gpt-4o-mini', label: 'GPT-4o mini' },
      { id: 'gpt-4o', label: 'GPT-4o' },
      { id: 'gpt-4.1-mini', label: 'GPT-4.1 mini' },
    ],
    hint: 'Get a key at platform.openai.com/api-keys',
    free: false,
  },
  groq: {
    label: 'Groq',
    baseUrl: 'https://api.groq.com/openai/v1',
    style: 'openai',
    models: [
      { id: 'llama-3.3-70b-versatile', label: 'Llama 3.3 70B' },
      { id: 'llama-3.1-8b-instant', label: 'Llama 3.1 8B (fast)' },
    ],
    hint: 'Generous free tier. Get a key at console.groq.com/keys',
    free: true,
  },
  deepseek: {
    label: 'DeepSeek',
    baseUrl: 'https://api.deepseek.com/v1',
    style: 'openai',
    models: [
      { id: 'deepseek-chat', label: 'DeepSeek Chat' },
      { id: 'deepseek-reasoner', label: 'DeepSeek Reasoner' },
    ],
    hint: 'Very cheap. Get a key at platform.deepseek.com',
    free: false,
  },
  google: {
    label: 'Google Gemini',
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai',
    style: 'openai',
    models: [
      { id: 'gemini-2.0-flash', label: 'Gemini 2.0 Flash' },
      { id: 'gemini-1.5-flash', label: 'Gemini 1.5 Flash' },
    ],
    hint: 'Free tier available. Get a key at aistudio.google.com/apikey',
    free: true,
  },
  minimax: {
    label: 'MiniMax',
    baseUrl: 'https://api.minimax.io/v1',
    style: 'openai',
    models: [
      { id: 'MiniMax-Text-01', label: 'MiniMax Text 01' },
      { id: 'abab6.5s-chat', label: 'abab 6.5s Chat' },
    ],
    hint: 'Get a key at platform.minimax.io',
    free: false,
  },
  anthropic: {
    label: 'Anthropic',
    baseUrl: 'https://api.anthropic.com/v1',
    style: 'anthropic',
    models: [
      { id: 'claude-sonnet-4-20250514', label: 'Claude Sonnet 4' },
      { id: 'claude-3-5-haiku-latest', label: 'Claude Haiku 3.5' },
    ],
    hint: 'Get a key at console.anthropic.com',
    free: false,
  },
  ollama: {
    label: 'Ollama (local, free forever)',
    baseUrl: 'http://localhost:11434/v1',
    style: 'openai',
    models: [
      { id: 'llama3.2', label: 'llama3.2' },
      { id: 'qwen2.5', label: 'qwen2.5' },
      { id: 'mistral', label: 'mistral' },
    ],
    hint: 'Run `ollama serve` locally — no API key needed, fully offline',
    free: true,
  },
  custom: {
    label: 'Custom (OpenAI-compatible URL)',
    baseUrl: '',
    style: 'openai',
    models: [{ id: 'default', label: 'Default model' }],
    hint: 'Any OpenAI-compatible endpoint — set the Base URL in Settings',
    free: true,
  },
}

export function listProviders() {
  return Object.entries(PROVIDERS).map(([id, p]) => ({
    id,
    label: p.label,
    style: p.style,
    models: p.models,
    hint: p.hint,
    free: p.free,
  }))
}

/**
 * Calls the LLM and returns the assistant's text.
 * messages: [{ role: 'user'|'assistant'|'system', content: string }]
 */
export async function chat({ providerId, apiKey, model, messages, temperature = 0.7, maxTokens = 1600, baseUrl: baseUrlOverride }) {
  const provider = PROVIDERS[providerId] || PROVIDERS.openrouter
  const baseUrl = (baseUrlOverride || provider.baseUrl || '').replace(/\/$/, '')
  if (!apiKey && providerId !== 'ollama') throw new Error('No API key provided')
  if (!baseUrl) throw new Error('No base URL configured for this provider')

  const timeout = AbortSignal.timeout(120000)

  if (provider.style === 'anthropic') {
    const system = messages.filter((m) => m.role === 'system').map((m) => m.content).join('\n\n')
    const convo = messages
      .filter((m) => m.role !== 'system')
      .map((m) => ({ role: m.role, content: m.content }))

    const res = await fetch(`${baseUrl}/messages`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: model || provider.models[0].id,
        max_tokens: maxTokens,
        temperature,
        system: system || undefined,
        messages: convo,
      }),
      signal: timeout,
    })

    if (!res.ok) throw new Error(`Provider error ${res.status}: ${(await res.text()).slice(0, 400)}`)
    const data = await res.json()
    return (data.content || []).map((c) => c.text || '').join('\n').trim()
  }

  // OpenAI-compatible
  const res = await fetch(`${baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      ...(apiKey ? { authorization: `Bearer ${apiKey}` } : {}),
      ...(providerId === 'openrouter'
        ? {
            'HTTP-Referer': 'https://astra-assistant.local',
            'X-Title': 'Astra AI Assistant',
          }
        : {}),
    },
    body: JSON.stringify({
      model: model || provider.models[0].id,
      messages,
      temperature,
      max_tokens: maxTokens,
      stream: false,
    }),
    signal: timeout,
  })

  if (!res.ok) throw new Error(`Provider error ${res.status}: ${(await res.text()).slice(0, 400)}`)
  const data = await res.json()
  const text = data?.choices?.[0]?.message?.content
  if (!text) throw new Error('Provider returned an empty response')
  return String(text).trim()
}
