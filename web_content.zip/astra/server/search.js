// Live web search. Uses key-free sources by default (Wikipedia + DuckDuckGo),
// and upgrades to a higher-quality engine when TAVILY_API_KEY / BRAVE_API_KEY is set.
//
// NOTE: Wikipedia rejects Node's global fetch (undici) with a 403, so this module
// uses the node:https module directly for the key-free sources.

import http from 'node:http'
import https from 'node:https'
import { URL } from 'node:url'

const UA = 'Astra-AI-Assistant/1.0 (https://github.com/astra-assistant; personal study & business helper)'

/** Minimal HTTP(S) request helper built on node:https — works where fetch is blocked. */
function request(rawUrl, { headers = {}, timeout = 15000, method = 'GET', body = null } = {}) {
  return new Promise((resolve, reject) => {
    let u
    try {
      u = new URL(rawUrl)
    } catch (e) {
      reject(new Error(`Invalid URL: ${rawUrl}`))
      return
    }
    const lib = u.protocol === 'http:' ? http : https
    const payload = body ? Buffer.from(body) : null
    const finalHeaders = {
      'user-agent': UA,
      accept: 'application/json, text/html;q=0.8',
      ...(payload ? { 'content-type': 'application/json', 'content-length': payload.length } : {}),
      ...headers,
    }

    const req = lib.request(
      u,
      { method, headers: finalHeaders, timeout },
      (res) => {
        const status = res.statusCode || 0
        const loc = res.headers.location
        if (status >= 300 && status < 400 && loc) {
          res.resume()
          resolve(request(new URL(loc, rawUrl).toString(), { headers, timeout, method, body }))
          return
        }
        let data = ''
        res.setEncoding('utf8')
        res.on('data', (c) => {
          data += c
        })
        res.on('end', () => resolve({ status, body: data, headers: res.headers }))
      }
    )

    req.on('timeout', () => req.destroy(new Error('Request timed out')))
    req.on('error', reject)
    if (payload) req.write(payload)
    req.end()
  })
}

async function getJSON(url, opts = {}) {
  const r = await request(url, opts)
  if (r.status < 200 || r.status >= 300) throw new Error(`HTTP ${r.status}`)
  return JSON.parse(r.body)
}

function stripHtml(s = '') {
  return s
    .replace(/<[^>]*>/g, '')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ')
    .trim()
}

/* ------------------------------------------------------------------
   Free sources
   ------------------------------------------------------------------ */
async function searchWikipedia(query, limit = 5) {
  const url = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(
    query
  )}&srlimit=${limit}&format=json`
  const data = await getJSON(url)
  const hits = data?.query?.search || []
  return hits.map((h) => ({
    title: h.title,
    url: `https://en.wikipedia.org/wiki/${encodeURIComponent(h.title.replace(/ /g, '_'))}`,
    snippet: stripHtml(h.snippet),
    source: 'Wikipedia',
  }))
}

async function searchDuckDuckGo(query, limit = 5) {
  const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`
  const data = await getJSON(url)
  const out = []

  if (data.Answer && data.AnswerType && data.AnswerType !== 'Nothing') {
    out.push({
      title: `${data.Heading || query} — quick answer`,
      url: data.AbstractURL || `https://duckduckgo.com/?q=${encodeURIComponent(query)}`,
      snippet: stripHtml(data.Answer),
      source: 'DuckDuckGo',
    })
  }
  if (data.AbstractText) {
    out.push({
      title: data.Heading || query,
      url: data.AbstractURL,
      snippet: stripHtml(data.AbstractText),
      source: data.AbstractSource || 'DuckDuckGo',
    })
  }
  for (const t of (data.RelatedTopics || []).slice(0, limit)) {
    if (t.Text && t.FirstURL) {
      out.push({
        title: (t.Text || '').split(' - ')[0].slice(0, 120),
        url: t.FirstURL,
        snippet: stripHtml(t.Text),
        source: 'DuckDuckGo',
      })
    }
  }
  return out
}

/* ------------------------------------------------------------------
   Key-based sources (better quality)
   ------------------------------------------------------------------ */
async function searchTavily(query, limit = 5) {
  const body = JSON.stringify({
    api_key: process.env.TAVILY_API_KEY,
    query,
    max_results: limit,
    search_depth: 'basic',
    include_answer: true,
  })
  const r = await request('https://api.tavily.com/search', { method: 'POST', body, timeout: 20000 })
  if (r.status < 200 || r.status >= 300) throw new Error(`Tavily HTTP ${r.status}`)
  const data = JSON.parse(r.body)
  const out = (data.results || []).map((r2) => ({
    title: r2.title,
    url: r2.url,
    snippet: stripHtml(r2.content || '').slice(0, 400),
    source: new URL(r2.url).hostname.replace(/^www\./, ''),
  }))
  if (data.answer) {
    out.unshift({
      title: 'Search summary',
      url: `https://tavily.com/search?q=${encodeURIComponent(query)}`,
      snippet: data.answer,
      source: 'Tavily',
    })
  }
  return out
}

async function searchBrave(query, limit = 5) {
  const url = `https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=${limit}`
  const r = await request(url, {
    headers: { 'x-subscription-token': process.env.BRAVE_API_KEY, accept: 'application/json' },
    timeout: 20000,
  })
  if (r.status < 200 || r.status >= 300) throw new Error(`Brave HTTP ${r.status}`)
  const data = JSON.parse(r.body)
  return (data.web?.results || []).map((r2) => ({
    title: r2.title,
    url: r2.url,
    snippet: stripHtml(r2.description || '').slice(0, 400),
    source: new URL(r2.url).hostname.replace(/^www\./, ''),
  }))
}

/**
 * Runs a web search and returns normalised results.
 * Falls back gracefully when one source fails.
 */
export async function webSearch(query, limit = 5) {
  const q = String(query || '').trim()
  if (!q) return { results: [], engine: 'none' }

  if (process.env.TAVILY_API_KEY) {
    try {
      return { results: await searchTavily(q, limit), engine: 'Tavily' }
    } catch {
      /* fall through to free sources */
    }
  }
  if (process.env.BRAVE_API_KEY) {
    try {
      return { results: await searchBrave(q, limit), engine: 'Brave' }
    } catch {
      /* fall through */
    }
  }

  const settled = await Promise.allSettled([searchWikipedia(q, limit), searchDuckDuckGo(q, limit)])
  const results = []
  const errors = []
  for (const s of settled) {
    if (s.status === 'fulfilled') results.push(...s.value)
    else errors.push(s.reason?.message || String(s.reason))
  }

  const seen = new Set()
  const unique = results.filter((r) => {
    if (!r.url || seen.has(r.url)) return false
    seen.add(r.url)
    return true
  })

  return {
    results: unique.slice(0, limit + 3),
    engine: 'Wikipedia + DuckDuckGo',
    ...(unique.length === 0 && errors.length ? { error: errors.join('; ') } : {}),
  }
}

/** Builds the context block injected into the LLM prompt. */
export function formatSources(results) {
  if (!results?.length) return ''
  return results
    .map((r, i) => `[${i + 1}] ${r.title}\n${r.snippet}\nSource: ${r.url}`)
    .join('\n\n')
}
