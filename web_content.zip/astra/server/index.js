import express from 'express'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import fs from 'node:fs'
import { chat, listProviders, PROVIDERS } from './providers.js'
import { webSearch, formatSources } from './search.js'

const __dirname = dirname(fileURLToPath(import.meta.url))
const ROOT = join(__dirname, '..')
const PORT = process.env.PORT || 8787

const app = express()
app.use(express.json({ limit: '2mb' }))

/* ---------------------------------------------------------------
   Mode system prompts
   --------------------------------------------------------------- */
export const MODES = {
  general: {
    id: 'general',
    label: 'General',
    emoji: '🌐',
    tagline: 'Ask anything',
    system: `You are Astra, a warm, sharp and genuinely useful AI assistant.
Answer directly and well. Use clear structure with headings and bullet points when it helps.
Use markdown. When you give code, put it in fenced code blocks with the language tag.
Be concrete and actionable. If a question is ambiguous, state the assumption you are making and answer anyway.
Never invent facts, statistics, citations or URLs. If you are unsure, say so plainly.`,
  },
  tutor: {
    id: 'tutor',
    label: 'Homework Tutor',
    emoji: '🎓',
    tagline: 'Learn it, don\'t just copy it',
    system: `You are Astra, a patient and encouraging tutor helping a student with homework and school/college subjects.

HOW YOU TEACH:
- Never just hand over the final answer. Guide the student to it.
- Work through the problem in clear numbered steps, showing the reasoning at each step.
- Name the concept or formula being used and say WHY it applies here.
- Use a concrete, relatable example (Indian context where natural: rupees, cricket, class 10 board exams, JEE/NEET style questions, CBSE/ICSE syllabus).
- If the student seems stuck, give a hint and let them try the next step.
- After the main solution, add a short "Check your understanding" — one quick question to test if it clicked.
- If the student shares a specific formula, theorem or textbook wording, work with exactly that.
- For maths: show every step, never skip algebra. Box the final answer.
- Keep language simple and friendly. Use markdown with headings, steps and bullet points.
- If a question is ambiguous (missing data, unclear which part), ask ONE targeted clarifying question first, and also offer what you can already answer.
- Use Indian numbering and rupee notation where money is involved (₹1,20,000).
- Never fabricate textbook page numbers, marks, or syllabus specifics you're unsure of.`,
  },
  business: {
    id: 'business',
    label: 'Business Advisor',
    emoji: '💼',
    tagline: 'Practical, numbers-first advice',
    system: `You are Astra, a pragmatic business advisor helping a small business owner or founder solve real problems.

HOW YOU ADVIS:
- Start by framing the actual problem in one or two sentences, because most business problems are really a different problem.
- Then give options — usually 2 to 3 realistic paths — each with the trade-offs and what it costs (money, time, effort, risk).
- Finish with a concrete action plan: what to do first, this week, with steps small enough to actually start.
- Bring numbers into it. Use a simple estimate or range where figures are needed, and clearly label your assumptions.
- Cover risk: what could go wrong, and how to test cheaply before committing.
- For Indian small-business context, use ₹ and lakh/crore notation, and think about things like GST, cash flow, customer acquisition cost, and margins.
- If the user is a student or a beginner in business, explain the jargon as you use it.
- Use markdown with headings and bullet points. Use tables when comparing options.
- If key numbers are missing (revenue, budget, team size, customer count), ask for them — but still give a useful framework immediately so they are not stuck.
- Be honest. If an idea is weak, say so plainly and explain why.`,
  },
}

/* ---------------------------------------------------------------
   API routes
   --------------------------------------------------------------- */
app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    providers: listProviders(),
    serverKeyConfigured: Boolean(process.env.LLM_API_KEY),
    searchEngine: process.env.TAVILY_API_KEY
      ? 'Tavily'
      : process.env.BRAVE_API_KEY
        ? 'Brave'
        : 'Wikipedia + DuckDuckGo',
  })
})

app.get('/api/modes', (_req, res) => res.json({ modes: Object.values(MODES) }))

app.post('/api/search', async (req, res) => {
  try {
    const { query, limit = 5 } = req.body || {}
    const out = await webSearch(query, Math.min(Number(limit) || 5, 8))
    res.json(out)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

app.post('/api/chat', async (req, res) => {
  try {
    const { mode = 'general', messages = [], apiKey, provider = 'openrouter', model, baseUrl, search = false } =
      req.body || {}

    const key = apiKey || process.env.LLM_API_KEY
    if (!key && provider !== 'ollama') {
      return res.status(400).json({
        error: 'NO_API_KEY',
        message:
          'No API key found. Add LLM_API_KEY to server/.env, or paste a key in the app Settings.',
      })
    }

    const modeConfig = MODES[mode] || MODES.general
    const systemParts = [modeConfig.system]

    // Pull in live web results when search is on.
    let sources = []
    let searchEngine = null
    if (search) {
      const lastUser = [...messages].reverse().find((m) => m.role === 'user')
      if (lastUser?.content) {
        try {
          const out = await webSearch(lastUser.content, 5)
          sources = out.results
          searchEngine = out.engine
          if (sources.length) {
            systemParts.push(
              `LIVE WEB RESULTS for "${lastUser.content}":\n${formatSources(sources)}\n\nUse these facts where relevant, cite them as [1], [2] etc. If they conflict with what you know, trust the live results and say so. If they do not answer the question, rely on your own knowledge.`
            )
          } else {
            systemParts.push(
              `A web search for "${lastUser.content}" returned no usable results. Answer from your own knowledge and say if the question needs current information.`
            )
          }
        } catch (e) {
          systemParts.push(`Web search failed (${e.message}). Answer from your own knowledge.`)
        }
      }
    }

    const payload = [{ role: 'system', content: systemParts.join('\n\n') }, ...messages]

    const text = await chat({
      providerId: provider,
      apiKey: key || '',
      model,
      baseUrl,
      messages: payload,
    })

    res.json({ reply: text, sources, searchEngine })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

/* ---------------------------------------------------------------
   Static frontend (production)
   --------------------------------------------------------------- */
const dist = join(ROOT, 'dist')
if (fs.existsSync(dist)) {
  app.use(express.static(dist))
  app.get(/^(?!\/api\/).*/, (_req, res) => res.sendFile(join(dist, 'index.html')))
}

app.listen(PORT, () => {
  console.log(`\n  Astra AI Assistant API → http://localhost:${PORT}`)
  console.log(`  Server key: ${process.env.LLM_API_KEY ? 'configured ✓' : 'not set (use app Settings)'}`)
  console.log(`  Search:     ${process.env.TAVILY_API_KEY ? 'Tavily' : process.env.BRAVE_API_KEY ? 'Brave' : 'Wikipedia + DuckDuckGo (free)'}\n`)
})
