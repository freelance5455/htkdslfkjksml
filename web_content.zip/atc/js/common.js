// ===== الإعدادات: غيّر رابط الخادم هنا فقط =====
var API="https://atc-api-production-6c18.up.railway.app";
var WA="96181844579";
// المسار الأساسي للموقع (ينتهي بـ /) ليعمل على أي استضافة
var BASE=location.origin+location.pathname.replace(/index\.html$/,"").replace(/(admin|driver)\/$/,"");
function $(i){return document.getElementById(i)}
function ld(k,d){try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}}
function sv(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
function E(s){return String(s==null?"":s).replace(/[&<>"']/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
async function api(p,m,b,h){var r=await fetch(API+p,{method:m||"GET",headers:Object.assign({"content-type":"application/json"},h||{}),body:b?JSON.stringify(b):undefined});var j=await r.json().catch(function(){return{}});if(!r.ok)throw j;return j}
function wa(ph,t){var n=String(ph||"").replace(/\D/g,"");if(n.indexOf("00")==0)n=n.slice(2);else if(n.charAt(0)=="0")n="961"+n.slice(1);return"https://wa.me/"+n+"?text="+encodeURIComponent(t)}
var ST=["جديد","مؤكد","مُسند","في الطريق","مكتمل","ملغي"];
