# Dexter Pad 0.5.0

0.5 adds light/dark/system appearance, Arabic/English UI (custom tab/button names are preserved), three accent palettes, reduced-motion support including OS preference, focus mode, searchable decks, balanced responsive grids, reorder by drag or keyboard-accessible arrows, independent tab copying across profiles, 10-second undo for button deletion, acknowledgement feedback and session activity, dock locking, optional stream-toggle confirmation, and a quick-start guide. All preferences remain under the settings gear and are included in backup. Android now uses the existing branded Dexter Pad PNG launcher icon.

Validation for 0.5: bilingual visible-text audit across settings, the button editor and all six color panels; appearance persistence and OS theme switching; reduced-motion behavior; search/empty states; reorder save/cancel/drag; cross-profile copy; undo; dock lock; real acknowledgement/error UI with a simulated receiver; stream confirmation; responsive layouts; and the previous keyboard, haptics, wheel delivery and double-tap regression suite. No Android hardware or live Premiere verification was added. PC receiver 0.4 and Premiere extension 0.3 are included unchanged.


Open this folder (containing settings.gradle) in Android Studio. Gradle Wrapper 8.11.1 is included and verified against the official SHA-256. Requires AGP 8.9.1, Android SDK 35 and JDK 17 or a compatible bundled Gradle JDK. First sync needs Internet access.

Build → Generate Signed App Bundle / APK → APK creates a signed build. Keep the keystore for future updates. Existing installs require the same application ID/signing certificate and a higher versionCode. This project uses com.dexter.pad, versionCode 5. Do not uninstall an existing app before backing up settings.

This is source, not a built APK. Android SDK/JDK 17 are unavailable here. Native landscape, haptic feedback and document export paths require Android-device verification. ZIP size is different from APK size.

Features: landscape activity; three independent profiles (Premiere, After Effects, Streamer); draggable profile dock; adjustable button/icon sizes plus individual icon overrides; keyboard chord picker, holds and images; legacy-tab migration; native JSON export/import; optional throttled slider haptics. All settings are under one gear: General, Buttons & Profiles, Connection and Backup.

Streamer volume uses Windows media keys while dragging. Play/pause, stop, previous/next and speaker mute work globally. OBS recording/streaming, scene selection and input mute use authenticated OBS WebSocket 5 through the PC receiver. Match scene/input names in the button editor. Normal editing shortcuts require the respective app in front; the system target is explicitly available for custom global shortcuts.

Color limitations: local preview is approximate and is not Premiere's live frame. Dexter Pad Color 0.3.0 is unchanged; it handles supported numeric controls and Reset All. Wheels/curves still use calibrated Windows pointer input, not a direct UXP wheel setter. This update keeps the mouse pressed across live updates and releases on completion, focus loss, timeout and profile switching. Calibration requires the same visible Lumetri panel and must be repeated after layout changes. Simulated pointer tests passed, but the user's wheel issue has not been verified resolved in a real Premiere session.

Validation: Chrome tests for migration, settings, sizes, dock position, backup round-trip, haptics on/off, key picker/images/holds, six color panels, double-tap resets and live wheel coalescing. EXE compiled. Fake keyboard tests verified routing/media/bounds/release. Real .NET transport passed an authenticated local OBS protocol simulator; receiver-to-extension and transaction tests used a mocked Premiere API. No actual broadcast, recording, Premiere project edit or phone hardware test was performed.

References:
https://developer.android.com/studio
https://developer.android.com/build/build-for-release
https://developer.android.com/build/releases/agp-8-9-0-release-notes
https://github.com/obsproject/obs-websocket/blob/master/docs/generated/protocol.md
