# Dexter Pad protocol v1 (0.4 extensions)

Commands now carry a top-level `profile`: `premiere`, `aftereffects`, or `streamer`. Omitted profiles retain Premiere behavior for older phones. `profile.switch` releases held keys and any active pointer gesture. `shortcut` and `shortcut.down` include `payload.target`, either `profile` (foreground app guard) or explicit `system` (global/current-window input). `shortcut.up` releases by holdId even after focus changes.

Global commands: `audio.mute`, `audio.up`, `audio.down`, `media.play`, `media.stop`, `media.next`, `media.previous`. `audio.step` accepts an integer `payload.steps` from -10 to 10 excluding zero; each step is one Windows volume key press. It is relative, not an absolute volume percentage. The phone does not pretend to know current OS volume.

OBS commands: `obs.record`, `obs.stream`, `obs.scene` with `payload.argument` set to the exact scene name, and `obs.mute` with the exact audio input name. PC authenticates locally with OBS WebSocket 5. No shell commands or arbitrary OBS request types are accepted from the phone. There is no automatic retry of toggles.

Live wheel packets carry `drag:{id,axis,final}`. The phone allows one outstanding wheel command and coalesces newer positions while waiting for acknowledgements. PC holds the pointer across consecutive packets in a gesture and releases on final, profile switch, non-wheel input, focus loss, disconnect or idle timeout. Pointer acknowledgement confirms injection, not Premiere's actual resulting color value. Wheels still require manual calibration.

LocalStorage remains `dexter-pad-v1` for migration. Each tab has a profile. JSON backup version 2 contains all tabs, selected profile, optional haptics boolean and normalized dock position. It does not export pairing/OBS credentials.

Transport: a WebSocket endpoint configured by the user, e.g. `ws://192.168.1.10:8765`. Dexter Pad PC receives keyboard shortcuts and holds. Unsupported Lumetri operations receive a negative acknowledgement with a reason. Do not expose the receiver to the public Internet. Production needs TLS and authenticated pairing.

Client sends:
```json
{"protocol":"dexter-pad","version":1,"type":"pair","payload":{"token":"USER_CODE","client":"Dexter Pad Android"}}
```
Server accepts only after validating the token:
```json
{"protocol":"dexter-pad","version":1,"type":"paired","payload":{"accepted":true}}
```
Commands carry monotonic per-session `id`, `timestamp` in Unix milliseconds, and `tabId`:
```json
{"protocol":"dexter-pad","version":1,"id":1,"type":"shortcut","tabId":"edit","timestamp":1794490000000,"payload":{"keys":"Ctrl+K","label":"Add edit"}}
```
`shortcut.keys` is a plus-delimited chord such as `V`, `Space`, `Shift+Delete`, or `Ctrl+Shift+K`. Receiver must validate a key allowlist and active target application before producing inputs; never execute a shell command from a key string.

Color message payloads:
```json
{"control":"shadows","x":0.25,"y":-0.1,"luma":12}
```
`type: color`; `control`: `shadows`, `midtones`, or `highlights`. X right-positive; Y down-positive. Unit disk coordinates; luminance is -100..100. Drag updates are throttled to approximately 25 Hz plus a final value. Values are absolute, not deltas. The desktop adapter must define their mapping to Premiere/Lumetri and support the installed Premiere version.

Saturation uses `type: color`, payload `{"control":"saturation","value":100}`, range 0..200. `type: color.reset` resets all three wheels and saturation for the current tab.

For each applied command the server returns:
```json
{"protocol":"dexter-pad","version":1,"type":"ack","id":1,"payload":{"ok":true}}
```
Use `ok:false` if not applied. The client reports timeout after three seconds; it never retries input commands, avoiding duplicate key presses. Desktop should reject messages before pairing, validate ranges and sizes, deduplicate IDs within the connection, and release all held keys on errors or disconnection. There is no offline command queue and no automatic reconnect.

## Extended Color Studio controls

New controls use the existing version 1 envelope and tabId. lumetri.set carries section (English panel name), path and value. Sliders send absolute numeric values on release. Curves send ordered normalized [x,y] knots under the named curve. Key selections carry H in degrees and S/L in percent with four ascending falloff/range edges. H may cross zero. LUT imports send the parsed 3D table, with larger tables resampled to a 9-point grid for preview and transfer. The original three primary wheels retain their existing color messages. Saturation in Basic Correction now uses its section-scoped message.

White balance sampling reports lumetri.sample with normalized coordinates, RGB and source local-frame; do not interpret this as a Premiere timeline frame. Apply Match sends lumetri.action with action applyMatch and faceDetection preference. The desktop adapter must obtain the actual current/reference frames and invoke the host grading operations before acknowledging success. Local preview matching estimates per-channel gains.
### Held shortcuts

Tap buttons still emit one `shortcut` event. A hold button emits `shortcut.down` on contact and `shortcut.up` on release or cancellation. Both carry the original tabId and identical payload fields `holdId`, `buttonId`, `keys` and `label`. Each message has its own command id. A client never replays a hold after reconnecting.

A desktop receiver implementing hold tracks holdId per paired connection. Press the chord once on down and release in reverse order on up. Reference-count shared keys across active holds, ignore duplicate downs and unknown ups, and release all owned inputs on disconnect or focus loss. Unsupported hold operations should return a negative acknowledgement.
