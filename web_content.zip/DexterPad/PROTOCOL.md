# Dexter Pad protocol v1 (proposed)

Transport: a WebSocket endpoint configured by the user, e.g. `ws://192.168.1.10:8765`. Desktop server is intentionally outside this phase. Do not expose the receiver to the public Internet. Production needs TLS and authenticated pairing.

Client sends:
```json
{"protocol":"dexter-pad","version":1,"type":"pair","payload":{"token":"USER_CODE","client":"Dexter Pad Android"}}
```
Server accepts only after validating the token:
```json
{"protocol":"dexter-pad","version":1,"type":"paired","payload":{"accepted":true}}
```
Commands carry monotonic per-session `id`, `timestamp` in Unix milliseconds, and `tabId`:
```json
{"protocol":"dexter-pad","version":1,"id":1,"type":"shortcut","tabId":"edit","timestamp":1794490000000,"payload":{"keys":"Ctrl+K","label":"Add edit"}}
```
`shortcut.keys` is a plus-delimited chord such as `V`, `Space`, `Shift+Delete`, or `Ctrl+Shift+K`. Receiver must validate a key allowlist and active target application before producing inputs; never execute a shell command from a key string.

Color message payloads:
```json
{"control":"shadows","x":0.25,"y":-0.1,"luma":12}
```
`type: color`; `control`: `shadows`, `midtones`, or `highlights`. X right-positive; Y down-positive. Unit disk coordinates; luminance is -100..100. Drag updates are throttled to approximately 25 Hz plus a final value. Values are absolute, not deltas. The desktop adapter must define their mapping to Premiere/Lumetri and support the installed Premiere version.

Saturation uses `type: color`, payload `{"control":"saturation","value":100}`, range 0..200. `type: color.reset` resets all three wheels and saturation for the current tab.

For each applied command the server returns:
```json
{"protocol":"dexter-pad","version":1,"type":"ack","id":1,"payload":{"ok":true}}
```
Use `ok:false` if not applied. The client reports timeout after three seconds; it never retries input commands, avoiding duplicate key presses. Desktop should reject messages before pairing, validate ranges and sizes, deduplicate IDs within the connection, and release all held keys on errors or disconnection. There is no offline command queue and no automatic reconnect.

## Extended Color Studio controls

New controls use the existing version 1 envelope and tabId. lumetri.set carries section (English panel name), path and value. Sliders send absolute numeric values on release. Curves send ordered normalized [x,y] knots under the named curve. Key selections carry H in degrees and S/L in percent with four ascending falloff/range edges. H may cross zero. LUT imports send the parsed 3D table, with larger tables resampled to a 9-point grid for preview and transfer. The original three primary wheels retain their existing color messages. Saturation in Basic Correction now uses its section-scoped message.

White balance sampling reports lumetri.sample with normalized coordinates, RGB and source local-frame; do not interpret this as a Premiere timeline frame. Apply Match sends lumetri.action with action applyMatch and faceDetection preference. The desktop adapter must obtain the actual current/reference frames and invoke the host grading operations before acknowledging success. Local preview matching estimates per-channel gains.
### Held shortcuts

Tap buttons still emit one `shortcut` event. A hold button emits `shortcut.down` on contact and `shortcut.up` on release or cancellation. Both carry the original tabId and identical payload fields `holdId`, `buttonId`, `keys` and `label`. Each message has its own command id. A client never replays a hold after reconnecting.

A desktop receiver implementing hold tracks holdId per paired connection. Press the chord once on down and release in reverse order on up. Reference-count shared keys across active holds, ignore duplicate downs and unknown ups, and release all owned inputs on disconnect or focus loss. Unsupported hold operations should return a negative acknowledgement.
