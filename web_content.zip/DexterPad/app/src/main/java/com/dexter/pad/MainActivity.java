package com.dexter.pad;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private String exportData;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        web = new WebView(this);
        web.setBackgroundColor(0xff0b1014);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface public void tick() {
                runOnUiThread(() -> {
                    if (web != null && !isFinishing())
                        web.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK);
                });
            }
            @android.webkit.JavascriptInterface public void exportSettings(String data) {
                if (data == null || data.length() > 8000000) return;
                try { new org.json.JSONObject(data).getJSONArray("tabs"); }
                catch (org.json.JSONException error) { return; }
                runOnUiThread(() -> {
                    if (exportData != null || isFinishing()) return;
                    exportData = data;
                    Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    create.addCategory(Intent.CATEGORY_OPENABLE);
                    create.setType("application/json");
                    create.putExtra(Intent.EXTRA_TITLE, "DexterPad-Settings.json");
                    try { startActivityForResult(create, 11); }
                    catch (Exception error) { exportData = null; }
                });
            }
        }, "DexterAndroid");
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try { startActivityForResult(params.createIntent(), 10); }
                catch (Exception error) { fileCallback.onReceiveValue(null); fileCallback = null; }
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return !url.startsWith("file:///android_asset/"); }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() { web.evaluateJavascript("window.closePanel && window.closePanel()", null); }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == 10 && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            fileCallback = null;
        }
        if (request == 11) {
            final String backup = exportData; exportData = null;
            if (result == RESULT_OK && data != null && data.getData() != null && backup != null) {
                final Uri target = data.getData();
                new Thread(() -> {
                    boolean english = false;
                    try {
                        org.json.JSONObject preferences = new org.json.JSONObject(backup).optJSONObject("ui");
                        english = preferences != null && "en".equals(preferences.optString("language"));
                    } catch (org.json.JSONException ignored) { }
                    String message;
                    try (java.io.OutputStream stream = getContentResolver().openOutputStream(target, "wt")) {
                        if (stream == null) throw new java.io.IOException();
                        stream.write(backup.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                        message = english ? "Settings saved" : "تم حفظ الإعدادات";
                    } catch (Exception error) { message = english ? "Could not save file" : "تعذر حفظ الملف"; }
                    final String notice = message;
                    runOnUiThread(() -> android.widget.Toast.makeText(MainActivity.this, notice, android.widget.Toast.LENGTH_SHORT).show());
                }).start();
            }
        }
    }
    @Override protected void onPause() {
        web.evaluateJavascript("if(typeof ButtonDeck !== 'undefined') ButtonDeck.releaseAll()", null);
        super.onPause();
    }
    @Override protected void onDestroy() { web.destroy(); super.onDestroy(); }
}
