'use strict';
const Grade = (() => {
  const clamp = (x, a=0, b=1) => Math.max(a, Math.min(b,x));
  const mix = (a,b,t) => a + (b-a)*t;
  const hueWrap = h => (h%1+1)%1;
  const wheel = () => ({x:0,y:0,luma:0});
  const groups = ['shadows','midtones','highlights'];
  const channels = ['Master','Red','Green','Blue','Hue vs Sat','Hue vs Hue','Hue vs Luma','Luma vs Sat','Sat vs Sat'];
  const neutralCurve = name => channels.indexOf(name)<4 ? [[0,0],[1,1]] : [[0,.5],[1,.5]];
  function fresh(tab) {
    return {
      section:'Basic Correction',
      basic:{lut:'None',temperature:0,tint:0,exposure:0,contrast:0,highlights:0,shadows:0,whites:0,blacks:0,saturation:tab.saturation ?? 100},
      creative:{look:'None',intensity:100,fadedFilm:0,sharpen:0,vibrance:0,saturation:100,shadowTint:wheel(),highlightTint:wheel(),tintBalance:0},
      curves:Object.fromEntries(channels.map(k=>[k,neutralCurve(k)])),
      match:{comparison:false,face:true,gain:[1,1,1]},
      hsl:{h:[0,0,360,360],s:[0,0,100,100],l:[0,0,100,100],extras:[],mask:'Off',invert:false,denoise:0,blur:0,mode:'Single',master:wheel(),shadows:wheel(),midtones:wheel(),highlights:wheel(),temperature:0,tint:0,contrast:0,sharpen:0,saturation:100},
      vignette:{amount:0,midpoint:50,roundness:0,feather:50},luts:{}
    };
  }
  function hsl([r,g,b]) {
    const hi=Math.max(r,g,b),lo=Math.min(r,g,b),d=hi-lo,l=(hi+lo)/2;
    if(!d) return [0,0,l];
    const h=hi===r?(g-b)/d:hi===g?(b-r)/d+2:(r-g)/d+4;
    return [hueWrap(h/6),d/(1-Math.abs(2*l-1)),l];
  }
  function rgb([h,s,l]) {
    const a=s*Math.min(l,1-l);
    return [0,8,4].map(n=>{const k=(n+12*h)%12;return l-a*Math.max(-1,Math.min(k-3,9-k,1));});
  }
  function curve(points,x) {
    const i=points.findIndex(p=>p[0]>=x);
    if(i<=0)return i===0?points[0][1]:points[points.length-1][1];
    const [a,b]=[points[i-1],points[i]];
    return mix(a[1],b[1],(x-a[0])/(b[0]-a[0]));
  }
  function trapezoid(x,[a,b,c,d]){
    if(x<b)return clamp((x-a)/(b-a||1));
    if(x>c)return clamp((d-x)/(d-c||1));
    return 1;
  }
  function membership([h,s,l],key) {
    function hueRange(range){return Math.max(...[-360,0,360].map(offset=>trapezoid(h*360+offset,range)));}
    let m=hueRange(key.h)*trapezoid(s*100,key.s)*trapezoid(l*100,key.l);
    for(const p of key.extras){
      const v=hueRange(p.h)*trapezoid(s*100,p.s)*trapezoid(l*100,p.l);
      m=p.add?Math.max(m,v):Math.min(m,1-v);
    }
    return key.invert?1-m:m;
  }
  function sampleKey(pixel){
    const [h,s,l]=hsl(pixel);
    const around=(x,r,f,max)=>[-r-f,-r,r,r+f].map(n=>clamp(x+n,0,max));
    return {h:[-24,-12,12,24].map(n=>h*360+n),s:around(s*100,18,10,100),l:around(l*100,18,10,100)};
  }
  function lutValue(lut,pixel){
    const {size,data}=lut;
    const pos=pixel.map((v,i)=>clamp((v-lut.min[i])/(lut.max[i]-lut.min[i]))*(size-1));
    const lo=pos.map(Math.floor),hi=lo.map(v=>Math.min(v+1,size-1)),f=pos.map((v,i)=>v-lo[i]);
    const out=[0,0,0];
    for(let i=0;i<8;i++){
      const idx=[0,1,2].map(j=>i&(1<<j)?hi[j]:lo[j]);
      const w=f.reduce((a,v,j)=>a*(i&(1<<j)?v:1-v),1);
      const start=3*(idx[0]+size*(idx[1]+size*idx[2]));
      for(let j=0;j<3;j++)out[j]+=data[start+j]*w;
    }
    return out;
  }
  function parseCube(text) {
    let size=0,min=[0,0,0],max=[1,1,1],data=[];
    for(const line of text.split(/\r?\n/)){
      const bits=line.split('#')[0].trim().split(/\s+/);
      if(!bits[0]||bits[0]==='TITLE')continue;
      const [tag,...rest]=bits,n=rest.map(Number);
      if(tag==='LUT_3D_SIZE')size=n[0];
      else if(tag==='DOMAIN_MIN')min=n;
      else if(tag==='DOMAIN_MAX')max=n;
      else if(bits.length===3&&bits.every(v=>Number.isFinite(Number(v))))data.push(...bits.map(Number));
      else throw Error('الملف لازم يكون 3D .cube');
    }
    if(!Number.isInteger(size)||size<2||size>65||data.length!==3*size**3||min.length!==3||max.length!==3||min.some((v,i)=>!Number.isFinite(v)||!Number.isFinite(max[i])||v>=max[i]))throw Error('بيانات LUT غير صالحة');
    const full={size,min,max,data};
    if(size<=9)return full;
    const small=[];
    for(let b=0;b<9;b++)for(let g=0;g<9;g++)for(let r=0;r<9;r++)small.push(...lutValue(full,[r/8,g/8,b/8]).map(x=>Math.round(x*10000)/10000));
    return {size:9,min:[0,0,0],max:[1,1,1],data:small};
  }
  function applyLook(name,p,luts){
    if(luts[name])return lutValue(luts[name],p);
    if(name==='Amber')return [p[0]*1.09+.018,p[1]*1.015,p[2]*.90];
    if(name==='Cool')return [p[0]*.91,p[1]*1.02,p[2]*1.1];
    if(name==='Mono'){const l=luma(p);return [l,l,l];}
    return p;
  }
  const luma=([r,g,b])=>r*.2126+g*.7152+b*.0722;
  function wheelDelta(w){
    const amount=Math.hypot(w.x,w.y);
    const tint=rgb([hueWrap(Math.atan2(w.x,-w.y)/(2*Math.PI)),1,.5]);
    return tint.map(v=>(v-.5)*amount*.55+w.luma/200);
  }
  function spatial(data,w,h,amount){
    if(!amount)return Array.from(data);
    const out=new Float32Array(data.length),rad=Math.max(1,Math.ceil(amount/25));
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      let sum=0,n=0;
      for(let dy=-rad;dy<=rad;dy++)for(let dx=-rad;dx<=rad;dx++){sum+=data[clamp(y+dy,0,h-1)*w+clamp(x+dx,0,w-1)];n++;}
      out[y*w+x]=mix(data[y*w+x],sum/n,Math.min(amount/20,1));
    }
    return out;
  }
  function process(frame,tab,showMask,sampleStage){
    const st=tab.studio,a=st.basic,c=st.creative,k=st.hsl,v=st.vignette;
    const w=frame.width,h=frame.height,src=frame.data;
    const out=new Uint8ClampedArray(src.length), pixels=[], mask=[];
    const tables=channels.map(name=>Array.from({length:256},(_,i)=>curve(st.curves[name],i/255)));
    const lookup=(i,x)=>tables[i][Math.round(clamp(x)*255)];
    const offsets=groups.map(key=>wheelDelta(tab.wheels[key])), secondary=(k.mode==='Single'?[k.master]:groups.map(n=>k[n])).map(wheelDelta);
    const shadow=wheelDelta(c.shadowTint),high=wheelDelta(c.highlightTint);
    for(let i=0;i<src.length;i+=4){
      let p=applyLook(a.lut,[src[i]/255,src[i+1]/255,src[i+2]/255],st.luts);
      let l=clamp(luma(p)),warm=a.temperature/500,mag=a.tint/600;
      const lift=(a.shadows*(1-l)**2+a.highlights*l*l+a.whites*l**5+a.blacks*(1-l)**5)/250;
      p=p.map((x,j)=>clamp(((x*2**a.exposure+lift+[warm+mag,-mag,-warm+mag][j])-.5)*(1+a.contrast/100)+.5));
      l=luma(p);p=p.map(x=>mix(l,x,a.saturation/100));
      const look=applyLook(c.look,p,st.luts);
      p=p.map((x,j)=>mix(x,look[j],c.intensity/100));l=clamp(luma(p));
      p=p.map((x,j)=>clamp(mix(l,x,c.saturation/100*(1+c.vibrance/100*(1-(Math.max(...p)-Math.min(...p)))))+c.fadedFilm/400*(1-2*l)+mix(shadow[j],high[j],clamp(l+c.tintBalance/200))));
      p=p.map((x,j)=>lookup(j+1,lookup(0,x)));
      if(sampleStage==='curves') {for(let j=0;j<3;j++)out[i+j]=255*p[j];out[i+3]=255;continue;}
      const t=hsl(p);
      const saturation=t[1]*(2*lookup(4,t[0]))*(2*lookup(7,t[2]))*(2*lookup(8,t[1]));
      p=rgb([hueWrap(t[0]+lookup(5,t[0])-.5),clamp(saturation),clamp(t[2]+lookup(6,t[0])-.5)]);
      l=clamp(luma(p));const weights=[(1-l)**2,2*l*(1-l),l*l];
      p=p.map((x,j)=>clamp((x+weights.reduce((sum,wt,n)=>sum+wt*offsets[n][j],0))*st.match.gain[j]));
      if(sampleStage==='key') {for(let j=0;j<3;j++)out[i+j]=255*p[j];out[i+3]=255;continue;}
      pixels.push(p);mask.push(membership(hsl(p),k));
    }
    const smooth=spatial(mask,w,h,k.denoise), m=spatial(smooth,w,h,k.blur);
    for(let i=0;i<pixels.length;i++){
      const p=pixels[i],l=luma(p),alpha=m[i],x=i%w,y=Math.floor(i/w);
      const detail=p.map((ch,j)=>ch-(pixels[y*w+Math.max(0,x-1)][j]+pixels[y*w+Math.min(w-1,x+1)][j]+pixels[Math.max(0,y-1)*w+x][j]+pixels[Math.min(h-1,y+1)*w+x][j])/4);
      const weights=k.mode==='Single'?[1]:[(1-l)**2,2*l*(1-l),l*l];
      const xx=(x+.5)/w*2-1,yy=(y+.5)/h*2-1;
      const radius=Math.hypot(xx*(1-v.roundness/350),yy);
      const edge=clamp((radius-v.midpoint/110)/(v.feather/75+.02));
      for(let j=0;j<3;j++){
        const tint=[k.temperature/500+k.tint/600,-k.tint/600,-k.temperature/500+k.tint/600][j];
        const corrected=(mix(l,p[j],k.saturation/100)-.5)*(1+k.contrast/100)+.5+tint+secondary.reduce((sum,d,n)=>sum+d[j]*weights[n],0)+detail[j]*k.sharpen/18;
        let value=mix(p[j],corrected,alpha)+v.amount/5*edge+detail[j]*c.sharpen/18;
        if(showMask && k.mask!=='Off')value=k.mask==='White/Black'?alpha:mix(k.mask==='Color/Gray'?.45:0,p[j],alpha);
        out[4*i+j]=clamp(value)*255;
      }
      out[4*i+3]=255;
    }
    return out;
  }
  return {fresh,wheel,groups,channels,neutralCurve,curve,hsl,rgb,luma,clamp,sampleKey,parseCube,process};
})();

