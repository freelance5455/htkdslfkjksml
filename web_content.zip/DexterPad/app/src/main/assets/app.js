'use strict';
const $=s=>document.querySelector(s), uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const defaults=()=>({tabs:[{id:'edit',name:'Editing',type:'buttons',buttons:[['Selection tool','V','↖','#6ce9cb'],['Razor tool','C','✂','#62bded'],['Play / Pause','Space','▷','#bc9af7'],['Add edit','Ctrl+K','⌁','#efbc73'],['Ripple delete','Shift+Delete','⌫','#f28b9e'],['Undo','Ctrl+Z','↶','#6ce9cb']].map((a,i)=>({id:'b'+i,name:a[0],shortcut:a[1],icon:a[2],color:a[3]}))},{id:'color',name:'Color Studio',type:'color',wheels:{shadows:{x:0,y:0,luma:0},midtones:{x:0,y:0,luma:0},highlights:{x:0,y:0,luma:0}},saturation:100,sensitivity:1}],active:'edit',host:'',token:'',haptics:true});
let state;try{state=JSON.parse(localStorage.getItem('dexter-pad-v1'));if(!state||!Array.isArray(state.tabs)||!state.tabs.length)throw Error();}catch{state=defaults();}
Profiles.migrate(state);
let editing=false,socket=null,connected=false,seq=0,toastTimer,attempt=0,pending=new Map();
const wheelUpdates=new Map();
let wheelFlight=null;
const confirmations=new Map();
function afterAck(message,onSuccess){
  if(!connected){onSuccess();return;}
  confirmations.set(message.id,onSuccess);
  setTimeout(()=>confirmations.delete(message.id),3100);
}
function queueWheel(tabId,section,key,type,payload){
  if(!connected)return;
  const control=JSON.stringify([tabId,section,key,payload.drag.axis]);
  wheelUpdates.set(control,{tabId,type,payload});
  flushWheel();
}
function flushWheel(){
  if(!connected || wheelFlight || !wheelUpdates.size || socket?.readyState!==1)return;
  const [key,update]=wheelUpdates.entries().next().value;
  wheelUpdates.delete(key);
  const message={protocol:'dexter-pad',version:1,id:++seq,timestamp:Date.now(),profile:state.profile,...update};
  socket.send(JSON.stringify(message));
  pending.set(message.id,Date.now());
  Experience.track(message,true);
  wheelFlight=message.id;
}
function clearWheelQueue(){wheelUpdates.clear();wheelFlight=null;}
function save(){try{localStorage.setItem('dexter-pad-v1',JSON.stringify(state));}catch{toast('تعذر الحفظ: مساحة التخزين غير متاحة');}}
function toast(message){$('#toast').textContent=message;$('#toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('visible'),2200);}
function visibleTabs(){return state.tabs.filter(t=>t.profile===state.profile);}
function current(){return visibleTabs().find(t=>t.id===state.active)||visibleTabs()[0];}
let lastHaptic=-Infinity;
function haptic(){
  if(!state.haptics||document.hidden)return;
  const now=performance.now();if(now-lastHaptic<45)return;lastHaptic=now;
  try{if(window.DexterAndroid?.tick)window.DexterAndroid.tick();else navigator.vibrate?.(8);}catch{}
}
const sliderTicks=new WeakMap();
document.addEventListener('input',event=>{
  const input=event.target;
  if(!(input instanceof HTMLInputElement)||input.type!=='range')return;
  if(sliderTicks.get(input)===input.value)return;
  sliderTicks.set(input,input.value);haptic();
});
function emit(type,payload,tabId=current().id){haptic();const message={protocol:'dexter-pad',version:1,id:++seq,type,tabId,profile:state.profile,timestamp:Date.now(),payload};if(connected&&socket?.readyState===1){socket.send(JSON.stringify(message));pending.set(message.id,Date.now());$('#status').textContent='تم الإرسال • في انتظار تأكيد الكمبيوتر';}else{$('#status').textContent='معاينة محلية • '+type+' • لم يُرسل إلى الكمبيوتر';}Experience.track(message,connected&&socket?.readyState===1);return message;}
function button(text,click,cls){let el=document.createElement('button');el.type='button';el.textContent=text;el.onclick=click;if(cls)el.className=cls;return el;}
function render(){ButtonDeck.releaseAll();let tab=current();state.active=tab.id;$('#tabs').replaceChildren();visibleTabs().forEach(t=>$('#tabs').append(button((t.type==='color'?'◉  ':'▦  ')+t.name,()=>{state.active=t.id;editing=false;save();render();},t.id===tab.id?'active':'')));$('#pageTitle').textContent=tab.name;$('#eyebrow').textContent=tab.type==='color'?'LUMETRI / COLOR CONTROL':'PREMIERE PRO / CONTROL DECK';$('#edit').hidden=!editing||tab.type!=='buttons';$('#renameTab').hidden=true;$('#edit').textContent=editing?'إنهاء التخصيص':'تخصيص الأزرار';$('#content').replaceChildren();Profiles.paint();if(tab.type==='buttons'){if(state.profile==='streamer')Profiles.streamControls();ButtonDeck.renderGrid(tab);}else renderColor(tab);Experience.paint(tab); }
const wheelNames={shadows:'Shadows · الظلال',midtones:'Midtones · الدرجات الوسطى',highlights:'Highlights · الإضاءات'};
function renderColor(tab){ ColorStudio.open(tab); }
function modal(title,html,onSave){ButtonDeck.releaseAll();$('#modalTitle').textContent=title;$('#fields').innerHTML=html;$('#error').textContent='';$('#submit').hidden=false;$('#submit').textContent='حفظ';$('#form').onsubmit=e=>{e.preventDefault();try{onSave();}catch(err){$('#error').textContent=err.message;}};$('#modal').showModal();}
window.closePanel=()=>{document.getElementById('modal').close();editing=false;render();};$('#close').onclick=closePanel;
function field(id){return $('#'+id).value.trim();}function required(id){const v=field(id);if(!v)throw Error('اكتب قيمة لكل الحقول المطلوبة');return v;}
function addTab(){modal('إضافة تابة','<label>اسم التابة<input id="name" maxlength="30" required></label><label>النوع<select id="type"><option value="buttons">أزرار اختصارات</option><option value="color">عجلات تلوين Premiere</option></select></label>',()=>{const type=field('type'),tab={id:uid(),name:required('name'),type,profile:state.profile};if(type==='buttons')tab.buttons=state.profile==='premiere'?defaults().tabs[0].buttons.map(b=>({...b,id:uid()})):[];else Object.assign(tab,{wheels:defaults().tabs[1].wheels,saturation:100,sensitivity:1});state.tabs.push(tab);state.active=tab.id;save();closePanel();});}
$('#edit').onclick=()=>{editing=!editing;render();};$('#renameTab').onclick=()=>{modal('إعدادات التابة','<label>الاسم<input id="name" maxlength="30" required></label><button type="button" id="deleteTab" class="danger">حذف التابة</button>',()=>{current().name=required('name');save();closePanel();});$('#name').value=current().name;$('#deleteTab').disabled=visibleTabs().length===1;$('#deleteTab').onclick=()=>{if(!confirm(I18n.t('حذف التابة بكل إعداداتها؟')))return;state.tabs=state.tabs.filter(t=>t.id!==current().id);state.active=visibleTabs()[0].id;save();closePanel();};};
function setConnection(value){ButtonDeck.releaseAll();connected=value;Experience.session(value?'online':'offline');$('#connection').textContent=value?'● متصل بالكمبيوتر':'● Offline / تجريبي';$('#connection').classList.toggle('live',value);if(!value){clearWheelQueue();pending.clear();$('#status').textContent='غير متصل • الأوامر لا تصل إلى الكمبيوتر';}}
function connect(host,token){
  let endpoint=host.trim();
  if(!endpoint.includes('://')) endpoint='ws://'+endpoint;
  let parsed;
  try{parsed=new URL(endpoint);}catch{throw Error('اكتب عنوان الكمبيوتر الظاهر في Dexter Pad PC');}
  if(!['ws:','wss:'].includes(parsed.protocol)||parsed.username||parsed.password||parsed.pathname!=='/'||parsed.search||parsed.hash)
    throw Error('انسخ عنوان الاتصال من برنامج الكمبيوتر');
  const bareAddress=!host.includes('://')&&!parsed.port;
  if(bareAddress)parsed.port='8765';
  if(!token)throw Error('اكتب كود الاقتران');
  const id=++attempt;
  if(socket)socket.close();
  setConnection(false);
  Experience.session('connecting');
  const ws=socket=new WebSocket(parsed.href);
  let opened=false,paired=false,failure='';
  const unreachable='تعذّر الوصول إلى '+parsed.host+' • تأكد من بدء الاستقبال على شبكة Wi-Fi الصحيحة.';
  const timeout=setTimeout(()=>{
    if(id!==attempt||paired)return;
    failure=opened?'وصلنا للكمبيوتر، لكن تأكيد الاقتران اتأخر. راجع حالة المستقبل.':unreachable;
    ws.close();
  },8000);
  ws.onopen=()=>{
    if(id!==attempt)return;
    opened=true;
    ws.send(JSON.stringify({protocol:'dexter-pad',version:1,type:'pair',payload:{token,client:'Dexter Pad Android'}}));
  };
  ws.onmessage=e=>{
    if(id!==attempt)return;
    let m;try{m=JSON.parse(e.data);}catch{return;}
    if(m.protocol!=='dexter-pad'||m.version!==1)return;
    if(m.type==='paired'){
      clearTimeout(timeout);
      if(m.payload?.accepted===true){paired=true;setConnection(true);toast('تم الاقتران');}
      else{failure='وصلنا للكمبيوتر، لكن كود الاقتران غير صحيح. اكتب الكود الحالي.';ws.close();}
    }
    if(m.type==='ack'&&pending.delete(m.id)){
      Experience.ack(m.id,m.payload?.ok===true,m.payload?.reason);
      const done=confirmations.get(m.id);
      confirmations.delete(m.id);
      if(done && m.payload?.ok===true)done();
      $('#status').textContent=m.payload?.ok===true?'الكمبيوتر أكد استلام الأمر':String(m.payload?.reason||'الكمبيوتر رفض الأمر').slice(0,140);
      if(wheelFlight===m.id){wheelFlight=null;flushWheel();}
    }
  };
  ws.onerror=()=>{if(!failure)failure=opened?'الاتصال بالكمبيوتر انقطع':unreachable;};
  ws.onclose=()=>{
    clearTimeout(timeout);if(id!==attempt)return;
    setConnection(false);
    const message=failure||(paired?'الاتصال بالكمبيوتر انقطع':opened?'الكمبيوتر قفل الاتصال قبل إتمام الاقتران':unreachable);
    $('#status').textContent=message;toast(message);
  };
}

$('#connection').onclick=()=>SettingsPanel.open('connection');
$('#settings').onclick=()=>SettingsPanel.open();
function validateTabs(tabs){if(!Array.isArray(tabs)||!tabs.length||tabs.length>50)throw Error();const ids=new Set();for(const t of tabs){if(t.profile && !['premiere','aftereffects','streamer'].includes(t.profile))throw Error();if(typeof t.id!=='string'||ids.has(t.id)||typeof t.name!=='string'||t.name.length>30)throw Error();ids.add(t.id);if(t.type==='buttons'){if(!Array.isArray(t.buttons)||t.buttons.length>100)throw Error();for(const b of t.buttons){if(b.iconSize!==undefined&&(!Number.isFinite(b.iconSize)||b.iconSize<16||b.iconSize>100))throw Error();if(b.argument!==undefined&&(typeof b.argument!=='string'||b.argument.length>120))throw Error();if(b.action && !Profiles.actions[b.action])throw Error();if(b.target && !['profile','system'].includes(b.target))throw Error();if(b.image && !ButtonDeck.safeImage(b.image))throw Error();if(b.mode && !['tap','hold'].includes(b.mode))throw Error();if(!['id','name','shortcut','icon','color'].every(k=>typeof b[k]==='string')||!/^#[0-9a-f]{6}$/i.test(b.color))throw Error();}}else if(t.type==='color'){if(!t.wheels||![t.saturation,t.sensitivity].every(Number.isFinite)||t.saturation<0||t.saturation>200||t.sensitivity<=0||t.sensitivity>1)throw Error();for(const k of Object.keys(wheelNames)){const v=t.wheels[k];if(!v||![v.x,v.y,v.luma].every(Number.isFinite)||Math.hypot(v.x,v.y)>1.001||Math.abs(v.luma)>100)throw Error();}}else throw Error();}}
for(const [id,type]of[['padMode','buttons'],['colorMode','color']])$('#'+id).onclick=()=>{const t=visibleTabs().find(t=>t.type===type);if(t){state.active=t.id;editing=false;save();render();}else addTab();};
setInterval(()=>{const now=Date.now();for(const [id,time]of pending)if(now-time>3000){pending.delete(id);Experience.ack(id,false,'انتهت مهلة انتظار التأكيد');if(id===wheelFlight){socket?.close();clearWheelQueue();}$('#status').textContent='لم يؤكد الكمبيوتر تنفيذ الأمر';}},1000);
Profiles.mount();
Experience.mount();
render();
I18n.mount();

