'use strict';
const Experience=(()=>{
  let lastPage='',undoAction=null,undoTimer,latency=null;
  const receipts=new Map(),history=[];
  function node(tag,cls,text){const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;}
  function migrate(){if(!state.ui||typeof state.ui!=='object'||Array.isArray(state.ui))state.ui={};}
  function applyPreferences(){
    migrate();document.body.dataset.motion=state.ui.reduceMotion?'reduced':'auto';
    document.body.dataset.palette=['graphite','midnight','teal'].includes(state.ui.palette)?state.ui.palette:'graphite';
    document.body.classList.toggle('focus-mode',!!state.ui.focus);document.body.dataset.profile=state.profile;
    const mode=state.ui.theme||'dark';document.body.dataset.theme=mode==='system'?(matchMedia('(prefers-color-scheme: light)').matches?'light':'dark'):mode==='light'?'light':'dark';
    document.body.dataset.dockLocked=String(!!state.ui.lockDock);
    I18n.apply();
  }
  function mount(){
    applyPreferences();
    const label=node('span','session-pill','LOCAL PREVIEW');label.id='sessionPill';label.setAttribute('role','status');$('.section-head>div:first-child').prepend(label);
    const search=node('div','deck-search');search.id='deckSearch';
    const icon=node('span','search-icon','⌕'),input=node('input');input.type='search';input.id='shortcutSearch';input.placeholder='ابحث عن اختصار…';input.setAttribute('aria-label','البحث في اختصارات التابة');input.autocomplete='off';
    const count=node('output');count.id='searchCount';count.setAttribute('aria-live','polite');search.append(icon,input,count);$('.section-head>div:last-child').prepend(search);
    input.oninput=filter;
    const connectionInfo=node('span','connection-detail');connectionInfo.id='connectionDetail';connectionInfo.setAttribute('aria-live','off');$('footer').append(connectionInfo);
    const undo=node('div','undo-bar');undo.id='undoBar';undo.hidden=true;undo.setAttribute('role','status');undo.append(node('span'));
    const undoBtn=button('تراجع',()=>{const run=undoAction;undoAction=null;undo.hidden=true;clearTimeout(undoTimer);if(run)run();});undo.append(undoBtn);document.body.append(undo);
    document.addEventListener('pointerdown',e=>{
      const b=e.target.closest('button');if(!b||b.disabled)return;
      b.classList.add('press-feedback');
      setTimeout(()=>b.classList.remove('press-feedback'),160);
    },{passive:true});
    session('offline');
    matchMedia('(prefers-color-scheme: light)').addEventListener('change',()=>{if(state.ui.theme==='system')applyPreferences();});
    addEventListener('resize',()=>requestAnimationFrame(layout));
  }
  function paint(tab){
    applyPreferences();
    const page=state.profile+':'+tab.id+':'+editing;
    if(page!==lastPage){$('#shortcutSearch').value='';$('#content').classList.remove('page-enter');void $('#content').offsetWidth;$('#content').classList.add('page-enter');lastPage=page;}
    $('#deckSearch').hidden=tab.type!=='buttons'||editing;
    document.body.classList.toggle('is-customizing',editing);
    let hint=$('#editingHint');if(hint)hint.remove();
    if(editing){hint=node('div','editing-hint','وضع التخصيص · اختر زرًا لتعديله، أو أضف زرًا جديدًا.');hint.id='editingHint';$('#content').prepend(hint);}
    filter();
    layout();
    document.querySelectorAll('#tabs button').forEach(b=>b.setAttribute('aria-current',b.classList.contains('active')?'page':'false'));
  }
  function layout(){
    const grid=$('#content .grid');if(!grid||!grid.children.length)return;
    const size=Number(current().buttonSize)||110,count=grid.children.length;
    const maximum=Math.max(1,Math.min(6,Math.floor((grid.clientWidth+12)/(size*1.65+12))));
    const columns=Math.ceil(count/Math.ceil(count/maximum));
    grid.style.gridTemplateColumns='repeat('+columns+', minmax(0,1fr))';
  }
  function filter(){
    const input=$('#shortcutSearch');if(!input)return;
    const query=input.value.trim().toLocaleLowerCase(),pads=[...document.querySelectorAll('.deck-pad')];let count=0;
    if(query)ButtonDeck.releaseAll();
    for(const pad of pads){const match=!query||pad.textContent.toLocaleLowerCase().includes(query);pad.hidden=!match;if(match)count++;}
    $('#searchCount').textContent=pads.length?count+'/'+pads.length:'';
    let empty=$('#emptyDeck');if(empty)empty.remove();
    if(current().type==='buttons'&&!editing&&!count){
      empty=node('div','empty-deck');empty.id='emptyDeck';
      empty.append(node('div','empty-mark','◇'),node('h3','',query?'مفيش اختصار بالاسم ده':'مساحتك جاهزة'),node('p','',query?'جرّب اسم الزر أو مفاتيح الاختصار.':'أضف أول اختصار من إعدادات الأزرار.'));
      empty.append(button(query?'مسح البحث':'إضافة اختصار',()=>{if(query){input.value='';filter();input.focus();}else SettingsPanel.open('layout');}));$('#content').append(empty);
    }
  }
  function session(mode){
    document.body.dataset.connection=mode;
    const pill=$('#sessionPill');if(!pill)return;
    pill.textContent=mode==='online'?'CONNECTED':mode==='connecting'?'CONNECTING':'LOCAL PREVIEW';
    if(mode!=='online')latency=null;
    $('#connectionDetail').textContent=mode==='online'?'في انتظار أول أمر':mode==='connecting'?'جارٍ الاقتران…':'معاينة فقط · اتصل من ⚙';
    if(mode==='offline'){for(const [id]of receipts)ack(id,false,'انقطع الاتصال قبل التأكيد');}
  }
  function track(message,live){
    if(message.type==='profile.switch'||message.type==='shortcut.up')return;
    const p=message.payload||{},group=p.drag?.id;
    let row=group?history.find(r=>r.group===group):null;
    const label=p.label||Profiles.actions[message.type]?.label||p.path||p.control||message.type;
    if(!row){row={label:String(label),group,profile:message.profile,time:new Date().toLocaleTimeString('ar-EG',{hour:'2-digit',minute:'2-digit',second:'2-digit'}),result:live?'قيد الإرسال':'معاينة محلية',ok:null};history.unshift(row);if(history.length>40)history.pop();}
    row.result=live?'قيد الإرسال':'معاينة محلية';row.ok=null;
    if(live)receipts.set(message.id,{row,at:performance.now(),buttonId:p.buttonId,tabId:message.tabId});
    if(p.buttonId)feedback(p.buttonId,message.tabId,live?'pending':'preview');
  }
  function feedback(id,tabId,kind){
    if(current().id!==tabId)return;
    const pad=[...document.querySelectorAll('[data-button-id]')].find(el=>el.dataset.buttonId===id);if(!pad)return;
    pad.dataset.receipt=kind;pad.setAttribute('aria-description',kind==='ok'?'الكمبيوتر أكد استلام الأمر':kind==='error'?'لم يتم تأكيد الأمر':kind==='preview'?'معاينة محلية':'في انتظار التأكيد');
    if(kind!=='pending')setTimeout(()=>{if(pad.dataset.receipt===kind)delete pad.dataset.receipt;},850);
  }
  function ack(id,ok,reason){
    const item=receipts.get(id);if(!item)return;receipts.delete(id);
    item.row.ok=ok;item.row.result=ok?'أكد الكمبيوتر الاستلام':String(reason||'لم يصل تأكيد');
    if(ok){latency=Math.round(performance.now()-item.at);$('#connectionDetail').textContent='آخر تأكيد '+latency+' ms';}
    if(item.buttonId)feedback(item.buttonId,item.tabId,ok?'ok':'error');
  }
  function recordList(parent){
    const list=node('div','command-history');parent.append(list);
    if(!history.length){list.append(node('p','hint','بعد استخدام الأزرار هتظهر هنا آخر الأوامر وحالة استلامها.'));return;}
    for(const r of history){const row=node('div','command-row');row.dataset.ok=String(r.ok);row.append(node('time','',r.time),node('strong','',r.label),node('span','',r.result));list.append(row);}
  }
  function undo(label,fn){undoAction=fn;const bar=$('#undoBar');bar.firstElementChild.textContent=label;bar.hidden=false;clearTimeout(undoTimer);undoTimer=setTimeout(()=>{undoAction=null;bar.hidden=true;},10000);}
  function reorder(){
    const tab=current();let order=tab.buttons.slice();
    modal('ترتيب الأزرار','<p class="hint">اسحب المقبض ⠿، أو استخدم الأسهم. الترتيب لا يتغير إلا بعد الحفظ.</p><div id="reorderList"></div>',()=>{tab.buttons=order;save();closePanel();});
    const list=$('#reorderList');
    function move(id,delta){const from=order.findIndex(b=>b.id===id),to=Math.max(0,Math.min(order.length-1,from+delta));order.splice(to,0,order.splice(from,1)[0]);draw();}
    function draw(){list.replaceChildren();order.forEach((b,i)=>{
      const row=node('div','reorder-row');row.dataset.id=b.id;
      const grip=button('⠿',()=>{},'reorder-grip');grip.setAttribute('aria-label','اسحب '+b.name);
      const name=node('span','',b.name),up=button('↑',()=>move(b.id,-1)),down=button('↓',()=>move(b.id,1));
      up.setAttribute('aria-label','رفع '+b.name);down.setAttribute('aria-label','خفض '+b.name);up.disabled=i===0;down.disabled=i===order.length-1;row.append(grip,name,up,down);list.append(row);
      let destination=null,active=false;
      grip.onpointerdown=e=>{if(e.button!==0)return;active=true;destination=b.id;grip.setPointerCapture(e.pointerId);row.classList.add('dragging');};
      grip.onpointermove=e=>{if(!active)return;for(const other of list.children){const r=other.getBoundingClientRect();const hit=e.clientY>=r.top&&e.clientY<=r.bottom;other.classList.toggle('drop-target',hit);if(hit)destination=other.dataset.id;}};
      grip.onpointerup=()=>{if(!active)return;active=false;const from=order.findIndex(x=>x.id===b.id),to=order.findIndex(x=>x.id===destination);if(to>=0)order.splice(to,0,order.splice(from,1)[0]);draw();};
      grip.onpointercancel=grip.onlostpointercapture=()=>{if(active){active=false;draw();}};
    });}draw();
  }
  function duplicate(){
    const original=current();
    modal('نسخ التابة','<label>اسم النسخة<input id="copyName" maxlength="30" required></label><label>البروفايل<select id="copyProfile"><option value="premiere">Premiere Pro</option><option value="aftereffects">After Effects</option><option value="streamer">Streamer</option></select></label><p class="hint">النسخة مستقلة. راجع الاختصارات عند نقلها لبرنامج مختلف.</p>',()=>{
      const clone=JSON.parse(JSON.stringify(original));clone.id=uid();clone.name=required('copyName');clone.profile=field('copyProfile');if(clone.buttons)for(const b of clone.buttons)b.id=uid();
      if(state.tabs.length>=50)throw Error(I18n.t('وصلت للحد الأقصى: 50 تابة'));
      state.tabs.push(clone);ButtonDeck.releaseAll();clearWheelQueue();state.profile=clone.profile;state.active=clone.id;save();closePanel();toast('تم إنشاء نسخة مستقلة');
    });$('#copyName').value=(original.name+' copy').slice(0,30);$('#copyProfile').value=original.profile;if(original.type==='color')$('#copyProfile').disabled=true;
  }
  function guide(){
    modal('جاهز لأول جلسة؟','<div class="guide-brand"><div class="avatar" aria-hidden="true"></div><div><strong>DEXTER PAD</strong><small>LEVEL UP. YOUR WORKFLOW.</small></div></div><div class="quick-guide"><div><b>01</b><h3>اختار مساحة شغلك</h3><p>Pr لبريمير، Ae لأفتر إفكتس، والدائرة للستريمر. اسحب ⠿ لتغيير مكانهم.</p></div><div><b>02</b><h3>وصّل الكمبيوتر</h3><p>شغّل Dexter Pad PC على نفس الشبكة، ثم أدخل العنوان والكود من الإعدادات ← الاتصال.</p></div><div><b>03</b><h3>خلّيها على مقاسك</h3><p>من الأزرار والبروفايلات غيّر الحجم والصور، رتّب الأزرار، وانسخ التابات. احفظ نسخة احتياطية قبل تغيير جهازك.</p></div></div>',closePanel);$('#submit').textContent='جاهز';
  }
  return {mount,paint,layout,applyPreferences,session,track,ack,recordList,undo,reorder,duplicate,guide};
})();
