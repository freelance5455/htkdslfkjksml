'use strict';
const SettingsPanel=(()=>{
  function open(page='general'){
    modal('إعدادات Dexter Pad',`
      <nav class="settings-tabs" aria-label="أقسام الإعدادات">
        <button type="button" data-settings="general">عام</button>
        <button type="button" data-settings="layout">الأزرار والبروفايلات</button>
        <button type="button" data-settings="connection">الاتصال</button>
        <button type="button" data-settings="backup">نسخ احتياطي</button><button type="button" data-settings="activity">سجل الأوامر</button>
      </nav>
      <section data-pane="general"><div class="settings-intro"><span>MAKE IT YOURS</span><h3>مساحة شغلك، بطريقتك.</h3><p>تغييراتك بتتحفظ تلقائيًا على الجهاز.</p></div><div class="preference-grid"><label>وضع الشاشة<select id="themeMode"><option value="dark">داكن</option><option value="light">فاتح</option><option value="system">حسب نظام الجهاز</option></select></label><label>اللغة<select id="language"><option value="ar">العربية</option><option value="en">English</option></select></label><label>قفل مكان شريط البروفايلات<select id="lockDock"><option value="false">قابل للتحريك</option><option value="true">ثابت</option></select></label><label>تأكيد أوامر البث<select id="confirmStream"><option value="true">قبل تبديل حالة البث</option><option value="false">تنفيذ مباشر</option></select></label><label>مظهر الواجهة<select id="palette"><option value="graphite">Graphite · فحمي</option><option value="midnight">Midnight · أزرق داكن</option><option value="teal">Deep teal · بترولي</option></select></label><label>الحركات والانتقالات<select id="reduceMotion"><option value="false">حركات هادئة</option><option value="true">تقليل الحركة</option></select></label><label>وضع التركيز<select id="focusMode"><option value="false">التفاصيل كاملة</option><option value="true">إخفاء تفاصيل الاختصارات</option></select></label></div>
        <label>اهتزاز اللمس والسلايدرات<select id="haptics"><option value="true">تشغيل</option><option value="false">إيقاف</option></select></label>
        <p class="hint">اهتزاز خفيف أثناء تحريك السلايدرات. اختياري، ويراعي إعدادات الاهتزاز في أندرويد.</p>
        <button type="button" id="fullscreenSetting">الوضع الأفقي / ملء الشاشة</button>
        <button type="button" id="quickGuide">دليل البداية السريع</button><button type="button" id="resetDock">إرجاع أيقونات البروفايلات للجانب</button>
        <p class="hint">نسخة Android تفتح بالعرض تلقائيًا. اسحب مقبض ⠿ لتحريك شريط البروفايلات لأي مكان.</p>
      </section>
      <section data-pane="layout" hidden>
        <label>البروفايل<select id="settingsProfile"><option value="premiere">Premiere Pro</option><option value="aftereffects">After Effects</option><option value="streamer">Streamer</option></select></label>
        <label>التابة<select id="settingsTab"></select></label>
        <div id="appearanceSettings"></div>
        <div class="settings-actions"><button type="button" id="customizeDeck">تخصيص الأزرار والصور والاختصارات</button><button type="button" id="manageTab">اسم التابة / حذفها</button><button type="button" id="newTab">إضافة تابة</button><button type="button" id="reorderDeck">ترتيب الأزرار</button><button type="button" id="duplicateTab">نسخ التابة</button></div>
        <p class="hint">الأحجام خاصة بالتابة المختارة. لتغيير حجم أيقونة زر واحد: تخصيص الأزرار ← اختر الزر ← حجم خاص للأيقونة.</p>
      </section>
      <section data-pane="connection" hidden>
        <p class="hint">شغّل Dexter Pad PC على الكمبيوتر، واختار نفس شبكة Wi-Fi المتصل بها الموبايل.</p>
        <label>عنوان الكمبيوتر<input id="host" placeholder="ws://192.168.1.10:8765" dir="ltr"></label>
        <label>كود الاقتران الثابت<input id="token" type="password" inputmode="numeric" maxlength="2" autocomplete="off"></label>
        <div class="settings-actions"><button type="button" class="accent" id="connectNow">اتصال</button><button type="button" id="disconnect">قطع الاتصال</button></div>
        <details><summary>إعداد OBS والتلوين</summary><p class="hint">OBS: فعّل Tools → WebSocket Server Settings، ثم اكتب المنفذ والباسورد في إعداد اتصال OBS داخل Dexter Pad PC. عدّل اسم الميكروفون والمشاهد من تخصيص الزر.<br>Premiere: وصّل إضافة Dexter Pad Color للأدوات الرقمية. العجلات والمنحنيات تحتاج معايرة من برنامج الكمبيوتر وإبقاء لوحة Lumetri ظاهرة؛ إضاءة العجلة على الهاتف وحدها ليست تأكيدًا للتغيير في Premiere.</p></details>
      </section>
      <section data-pane="activity" hidden><p class="hint">آخر 40 أمر في الجلسة. التأكيد يعني أن الكمبيوتر استلم الأمر؛ ليس قراءة لحالة التسجيل أو اللون داخل البرنامج.</p><div id="activityList"></div></section><section data-pane="backup" hidden>
        <p class="hint">ملف واحد للتابات والأزرار والصور والأحجام في البروفايلات الثلاثة، مع إعداد الاهتزاز ومكان شريط البروفايلات.</p>
        <button type="button" id="export">تصدير الإعدادات</button>
        <label>استيراد الإعدادات<input id="import" type="file" accept="application/json,.json"></label>
        <p class="hint">الاستيراد يستبدل الإعدادات الحالية بعد تأكيدك. كلمات مرور الاتصال لا تدخل في النسخة الاحتياطية.</p>
      </section>`,()=>{save();closePanel();});
    $('#submit').textContent='تم';
    Experience.applyPreferences();Experience.recordList($('#activityList'));
    $('#themeMode').value=state.ui.theme||'dark';$('#language').value=state.ui.language||'ar';$('#lockDock').value=String(!!state.ui.lockDock);$('#confirmStream').value=String(state.ui.confirmStream!==false);
    for(const [id,key]of [['themeMode','theme'],['language','language'],['lockDock','lockDock'],['confirmStream','confirmStream']])$('#'+id).onchange=()=>{state.ui[key]=['themeMode','language'].includes(id)?field(id):field(id)==='true';save();Experience.applyPreferences();};
    $('#palette').value=state.ui.palette||'graphite';$('#reduceMotion').value=String(!!state.ui.reduceMotion);$('#focusMode').value=String(!!state.ui.focus);
    for(const [id,key]of [['palette','palette'],['reduceMotion','reduceMotion'],['focusMode','focus']])$('#'+id).onchange=()=>{state.ui[key]=id==='palette'?field(id):field(id)==='true';save();Experience.applyPreferences();};
    $('#quickGuide').onclick=()=>{$('#modal').close();Experience.guide();};
    $('#reorderDeck').hidden=current().type!=='buttons';$('#reorderDeck').onclick=()=>{$('#modal').close();Experience.reorder();};
    $('#duplicateTab').onclick=()=>{$('#modal').close();Experience.duplicate();};
    function select(id){for(const el of document.querySelectorAll('[data-pane]'))el.hidden=el.dataset.pane!==id;for(const el of document.querySelectorAll('[data-settings]'))el.classList.toggle('active',el.dataset.settings===id);}
    for(const b of document.querySelectorAll('[data-settings]'))b.onclick=()=>select(b.dataset.settings);select(page);
    $('#haptics').value=String(state.haptics);$('#haptics').onchange=()=>{state.haptics=field('haptics')==='true';save();};
    $('#fullscreenSetting').onclick=async()=>{try{await document.documentElement.requestFullscreen();await screen.orientation.lock('landscape');}catch{toast('لف الجهاز بالعرض؛ نسخة Android تثبت الاتجاه تلقائيًا');}};
    $('#resetDock').onclick=()=>{state.dock={x:0,y:.45};save();render();toast('تم إرجاع شريط البروفايلات');};
    $('#settingsProfile').value=state.profile;
    $('#settingsProfile').onchange=()=>{const profile=field('settingsProfile');Profiles.switchTo(profile);$('#modal').close();open('layout');};
    for(const t of visibleTabs()){const option=document.createElement('option');option.value=t.id;option.textContent=t.name;$('#settingsTab').append(option);}$('#settingsTab').value=current().id;
    $('#settingsTab').onchange=()=>{state.active=field('settingsTab');save();render();$('#modal').close();open('layout');};
    const tab=current();$('#customizeDeck').hidden=tab.type!=='buttons';
    if(tab.type==='buttons')Profiles.sizeControls(tab,$('#appearanceSettings'));
    $('#customizeDeck').onclick=()=>{$('#modal').close();editing=true;render();toast('اختار الزر اللي عايز تخصصه');};
    $('#manageTab').onclick=()=>{$('#modal').close();$('#renameTab').click();};
    $('#newTab').onclick=()=>{$('#modal').close();addTab();};
    $('#host').value=state.host||'';
    $('#connectNow').onclick=()=>{try{const host=required('host'),token=required('token');if(!/^\d{2}$/.test(token))throw Error('الكود رقمين من برنامج الكمبيوتر');connect(host,token);state.host=host;save();$('#modal').close();toast('جارٍ الاتصال…');}catch(e){$('#error').textContent=e.message;}};
    $('#disconnect').onclick=()=>{attempt++;socket?.close();setConnection(false);toast('تم قطع الاتصال');};
    $('#export').onclick=()=>{
      const text=JSON.stringify({version:2,tabs:state.tabs,profile:state.profile,haptics:state.haptics,dock:state.dock,ui:state.ui},null,2);
      if(window.DexterAndroid?.exportSettings){window.DexterAndroid.exportSettings(text);return;}
      const a=document.createElement('a'),url=URL.createObjectURL(new Blob([text],{type:'application/json'}));a.href=url;a.download='DexterPad-Settings.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
    };
    $('#import').onchange=async e=>{try{
      const f=e.target.files[0];if(!f)return;if(f.size>8000000)throw Error();const data=JSON.parse(await f.text());validateTabs(data.tabs);
      if(!confirm(I18n.t('استبدال إعدادات البروفايلات والتابات الحالية بالنسخة المختارة؟')))return;
      const next={...state,tabs:data.tabs};if(['premiere','aftereffects','streamer'].includes(data.profile))next.profile=data.profile;
      if(typeof data.haptics==='boolean')next.haptics=data.haptics;
      if(data.dock && Number.isFinite(data.dock.x)&&Number.isFinite(data.dock.y))next.dock={x:Math.max(0,Math.min(1,data.dock.x)),y:Math.max(0,Math.min(1,data.dock.y))};
      if(data.ui&&typeof data.ui==='object')next.ui={palette:['graphite','midnight','teal'].includes(data.ui.palette)?data.ui.palette:'graphite',reduceMotion:data.ui.reduceMotion===true,focus:data.ui.focus===true,theme:['dark','light','system'].includes(data.ui.theme)?data.ui.theme:'dark',language:data.ui.language==='en'?'en':'ar',lockDock:data.ui.lockDock===true,confirmStream:data.ui.confirmStream!==false};
      Profiles.migrate(next);next.active=next.tabs.find(t=>t.profile===next.profile).id;
      localStorage.setItem('dexter-pad-v1',JSON.stringify(next));ButtonDeck.releaseAll();clearWheelQueue();state=next;closePanel();toast('تم استيراد الإعدادات');
    }catch{$('#error').textContent='تعذر الاستيراد: الملف غير صالح أو مساحة التخزين غير كافية';}};
  }
  return {open};
})();
