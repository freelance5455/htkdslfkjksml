'use strict';
const Profiles=(()=>{
  let streamCleanup=()=>{};
  const names={premiere:['Pr','Premiere Pro','#aa91ff'],aftereffects:['Ae','After Effects','#899cff'],streamer:['◉','Streamer','#6ce9cb']};
  const actions={
    'obs.record':{label:'OBS · تسجيل / إيقاف'},'obs.stream':{label:'OBS · بث / إيقاف'},
    'obs.scene':{label:'OBS · تغيير المشهد',argument:true},'obs.mute':{label:'OBS · كتم مصدر الصوت',argument:true},
    'media.play':{label:'موسيقى · تشغيل / إيقاف مؤقت'},'media.stop':{label:'إيقاف الميديا'},
    'media.next':{label:'المقطع التالي'},'media.previous':{label:'المقطع السابق'},
    'audio.mute':{label:'كتم صوت الكمبيوتر'},'audio.up':{label:'رفع الصوت'},'audio.down':{label:'خفض الصوت'}
  };
  function deck(profile,name,rows){return {id:uid(),profile,name,type:'buttons',buttons:rows.map(([name,shortcut,icon,action,argument])=>({id:uid(),name,systemLabel:name,shortcut,icon,action:action||'',argument:argument||'',color:names[profile][2],mode:'tap'}))};}
  function migrate(s){
    if(!names[s.profile])s.profile='premiere';
    for(const t of s.tabs)if(!names[t.profile])t.profile='premiere';
    if(!s.tabs.some(t=>t.profile==='premiere'))s.tabs.push(...defaults().tabs.map(t=>({...t,id:uid(),profile:'premiere'})));
    if(!s.tabs.some(t=>t.profile==='aftereffects'))s.tabs.push(deck('aftereffects','Animation',[
      ['Selection','V','↖'],['Position','P','↔'],['Scale','S','⤢'],['Rotation','R','↻'],['Preview','Space','▷'],['Undo','Ctrl+Z','↶'],['Split layer','Ctrl+Shift+D','✂'],['Keyframes','U','◇']
    ]));
    if(!s.tabs.some(t=>t.profile==='streamer'))s.tabs.push(deck('streamer','Live & Media',[
      ['تسجيل OBS','','●','obs.record'],['بث OBS','','◉','obs.stream'],['كتم الميكروفون','','♩','obs.mute','Mic/Aux'],
      ['تشغيل / إيقاف','','▷','media.play'],['المقطع التالي','','»','media.next'],['كتم الجهاز','','♪','audio.mute']
    ]));
    s.profileTabs ||= {};s.version=2;
  }
  function switchTo(id){
    if(id===state.profile)return;
    ButtonDeck.releaseAll();emit('profile.switch',{profile:id});clearWheelQueue();
    state.profileTabs[state.profile]=current().id;state.profile=id;state.active=state.profileTabs[id];editing=false;save();render();
  }
  function place(){
    const dock=$('#profileDock');if(!dock)return;
    const pos=state.dock||{x:0,y:.45},w=Math.max(0,innerWidth-dock.offsetWidth-8),h=Math.max(0,innerHeight-dock.offsetHeight-8);
    dock.style.left=(4+Math.min(1,Math.max(0,pos.x))*w)+'px';dock.style.top=(4+Math.min(1,Math.max(0,pos.y))*h)+'px';
  }
  function mount(){
    const dock=document.createElement('div');dock.id='profileDock';dock.setAttribute('aria-label','البروفايلات');
    const grip=button('⠿',()=>{},'dock-grip');grip.title='اسحب لنقل البروفايلات';grip.setAttribute('aria-label',grip.title);dock.append(grip);
    for(const [id,[icon,label,color]] of Object.entries(names)){const b=button(icon,()=>switchTo(id));b.dataset.profile=id;b.title=label;b.setAttribute('aria-label',label);b.style.setProperty('--profile-color',color);dock.append(b);}
    document.body.append(dock);let drag;
    grip.onpointerdown=e=>{if(state.ui?.lockDock)return;e.preventDefault();const r=dock.getBoundingClientRect();drag={x:e.clientX-r.x,y:e.clientY-r.y};grip.setPointerCapture(e.pointerId);};
    grip.onpointermove=e=>{if(!drag)return;state.dock={x:(e.clientX-drag.x-4)/Math.max(1,innerWidth-dock.offsetWidth-8),y:(e.clientY-drag.y-4)/Math.max(1,innerHeight-dock.offsetHeight-8)};place();};
    grip.onpointerup=grip.onpointercancel=grip.onlostpointercapture=()=>{if(drag){drag=null;save();}};
    grip.onkeydown=e=>{if(state.ui?.lockDock)return;const v={ArrowLeft:[-.05,0],ArrowRight:[.05,0],ArrowUp:[0,-.05],ArrowDown:[0,.05]}[e.key];if(v){e.preventDefault();const p=state.dock||{x:0,y:.45};state.dock={x:Math.max(0,Math.min(1,p.x+v[0])),y:Math.max(0,Math.min(1,p.y+v[1]))};place();save();}};
    addEventListener('resize',place);place();
    const rotate=document.createElement('div');rotate.id='rotateHint';rotate.innerHTML='<span>↻ لف الموبايل بالعرض لمساحة تحكم أكبر</span>';
    rotate.append(button('ملء الشاشة',async()=>{try{await document.documentElement.requestFullscreen();await screen.orientation.lock('landscape');}catch{toast('لف الجهاز بالعرض؛ نسخة Android الأصلية تثبّت الاتجاه تلقائيًا');}}));document.body.append(rotate);
  }
  function paint(){
    streamCleanup();streamCleanup=()=>{};
    const [icon,label,color]=names[state.profile];
    for(const b of document.querySelectorAll('[data-profile]'))b.setAttribute('aria-pressed',String(b.dataset.profile===state.profile));
    const mark=$('.header-actions .premiere');mark.textContent=icon;mark.nextElementSibling.textContent=label;
    $('#eyebrow').textContent=current().type==='color'?'LUMETRI / PREMIERE PRO':label.toUpperCase()+' / CONTROL DECK';
    document.documentElement.style.setProperty('--mint',color);$('#colorMode').hidden=state.profile!=='premiere';
    $('#content').style.setProperty('--buttonSize',Math.max(70,Math.min(240,Number(current().buttonSize)||110))+'px');
    $('#content').style.setProperty('--iconSize',Math.max(16,Math.min(100,Number(current().iconSize)||32))+'px');
    place();
  }
  function sizeControls(tab,parent){
    const bar=document.createElement('div');bar.className='size-controls';
    for(const [key,title,min,max,value] of [['buttonSize','حجم الأزرار',70,240,110],['iconSize','حجم الأيقونات',16,100,32]]){
      const label=document.createElement('label');label.textContent=title;const output=document.createElement('output'),input=document.createElement('input');
      Object.assign(input,{type:'range',min,max,step:1,value:Math.max(min,Math.min(max,Number(tab[key])||value))});input.id=key;input.setAttribute('aria-label',title);
      const update=()=>{output.value=input.value;tab[key]=+input.value;$('#content').style.setProperty('--'+key,input.value+'px');Experience.layout();};
      input.oninput=update;input.onchange=save;update();label.append(input,output);bar.append(label);
    }
    parent.append(bar);
  }
  function fire(b){
    if(b.action==='obs.stream'&&state.ui?.confirmStream!==false&&!confirm(I18n.t('تبديل حالة بث OBS؟ راجع حالة البث على الكمبيوتر قبل المتابعة.')))return false;
    if(b.action){emit(b.action,{buttonId:b.id,label:b.name,argument:b.argument||''});}else emit('shortcut',{buttonId:b.id,keys:b.shortcut,label:b.name,target:b.target||'profile'});
    return true;
  }
  function streamControls(){
    const card=document.createElement('div');card.className='stream-controls';
    const dial=button('♫',null,'volume-dial');dial.id='volumeDial';dial.setAttribute('aria-label','بكرة صوت الكمبيوتر');dial.title='لف لرفع أو خفض الصوت';
    const desc=document.createElement('div');desc.innerHTML='<strong>MASTER VOLUME</strong><small>لف البكرة • يمين أعلى / شمال أقل</small>';
    const keys=document.createElement('div');keys.append(button('−',()=>emit('audio.down',{})),button('Mute',()=>emit('audio.mute',{})),button('+',()=>emit('audio.up',{})));
    card.append(dial,desc,keys);$('#content').append(card);
    let last=null,carry=0,angle=0,queued=0,timer;
    function flush(){clearTimeout(timer);timer=null;const steps=Math.max(-10,Math.min(10,queued));queued-=steps;if(steps)emit('audio.step',{steps});if(queued)timer=setTimeout(flush,40);}
    function polar(e){const r=dial.getBoundingClientRect();return Math.atan2(e.clientY-r.y-r.height/2,e.clientX-r.x-r.width/2);}
    dial.onpointerdown=e=>{if(!e.isPrimary||e.button!==0)return;dial.setPointerCapture(e.pointerId);last=polar(e);carry=0;};
    dial.onpointermove=e=>{if(last===null)return;let next=polar(e),diff=next-last;if(diff>Math.PI)diff-=Math.PI*2;if(diff<-Math.PI)diff+=Math.PI*2;last=next;carry+=diff;angle+=diff;dial.style.setProperty('--angle',angle+'rad');let steps=Math.trunc(carry/(Math.PI/36));if(steps){carry-=steps*Math.PI/36;queued+=steps;if(!timer)timer=setTimeout(flush,40);}};
    dial.onpointerup=dial.onpointercancel=dial.onlostpointercapture=()=>{last=null;if(queued)flush();};
    dial.onkeydown=e=>{if(['ArrowUp','ArrowRight','ArrowDown','ArrowLeft'].includes(e.key)){e.preventDefault();emit('audio.step',{steps:['ArrowUp','ArrowRight'].includes(e.key)?1:-1});}};
    const cancel=()=>{clearTimeout(timer);queued=0;last=null;};
    const hidden=()=>{if(document.hidden)cancel();};
    addEventListener('blur',cancel);document.addEventListener('visibilitychange',hidden);
    streamCleanup=()=>{cancel();removeEventListener('blur',cancel);document.removeEventListener('visibilitychange',hidden);};
  }
  return {migrate,mount,paint,sizeControls,streamControls,fire,actions,switchTo};
})();
