'use strict';

const ButtonDeck = (() => {
  const holds = new Map();
  const layouts = {
    'الكيبورد': [
      ['Esc','1','2','3','4','5','6','7','8','9','0','-','=','Backspace'],
      ['Tab','Q','W','E','R','T','Y','U','I','O','P','[',']','\\'],
      ['CapsLock','A','S','D','F','G','H','J','K','L',';',"'","Enter"],
      ['Shift','Z','X','C','V','B','N','M',',','.','/','`'],
      ['Ctrl','Win','Alt','Space','Left','Down','Up','Right']
    ],
    'مفاتيح إضافية': [
      ['F1','F2','F3','F4','F5','F6','F7','F8','F9','F10','F11','F12'],
      ['Insert','Home','PageUp','Delete','End','PageDown','PrintScreen','ScrollLock','Pause'],
      ['NumLock','NumpadDivide','NumpadMultiply','NumpadSubtract','NumpadAdd','NumpadDecimal'],
      ['Numpad0','Numpad1','Numpad2','Numpad3','Numpad4','Numpad5','Numpad6','Numpad7','Numpad8','Numpad9','NumpadEnter'],
      ['Ctrl','Shift','Win','Alt']
    ]
  };
  const aliases={Left:'←',Down:'↓',Up:'↑',Right:'→',Backspace:'⌫',CapsLock:'Caps',PrintScreen:'PrtSc',NumpadDivide:'Num /',NumpadMultiply:'Num ×',NumpadSubtract:'Num −',NumpadAdd:'Num +',NumpadDecimal:'Num .',NumpadEnter:'Num ↵'};
  const modifiers=['Ctrl','Shift','Alt','Win'];

  function node(tag,parent,text,cls) {
    const el=document.createElement(tag);
    if(text!==undefined)el.textContent=text;
    if(cls)el.className=cls;
    parent.append(el);
    return el;
  }

  function control(parent,text,fn){
    const b=node('button',parent,text);
    b.type='button';
    b.onclick=fn;
    return b;
  }

  function finish(input){
    const hold=holds.get(input);
    if(!hold)return;
    holds.delete(input);
    if(![...holds.values()].some(h=>h.pad===hold.pad)){
      hold.pad.classList.remove('held');
      hold.pad.setAttribute('aria-pressed','false');
    }
    if(hold.connection && connected && socket===hold.connection && socket.readyState===1){
      emit('shortcut.up',hold.payload,hold.tabId);
    }else if(!connected){
      $('#status').textContent='معاينة محلية • تم رفع '+hold.payload.keys;
    }
  }

  function releaseAll(){
    for(const input of [...holds.keys()])finish(input);
  }

  function attachHold(pad,b,tab){
    function start(input){
      if(holds.has(input))return;
      const payload={holdId:uid(),buttonId:b.id,keys:b.shortcut,label:b.name};
      holds.set(input,{pad,tabId:tab.id,payload,connection:connected?socket:null});
      pad.classList.add('held');pad.setAttribute('aria-pressed','true');
      emit('shortcut.down',payload,tab.id);
      if(!connected)$('#status').textContent='ضغط مستمر • '+b.shortcut+' • معاينة محلية';
    }
    pad.setAttribute('aria-pressed','false');
    pad.onpointerdown=e=>{
      if(e.button!==0)return;
      pad.setPointerCapture(e.pointerId);
      start(e.pointerId);
    };
    pad.onpointerup=pad.onpointercancel=pad.onlostpointercapture=e=>finish(e.pointerId);
    pad.oncontextmenu=e=>e.preventDefault();
    pad.onkeydown=e=>{
      if(e.key!==' '&&e.key!=='Enter')return;
      e.preventDefault();if(!e.repeat)start('keyboard:'+e.key);
    };
    pad.onkeyup=e=>{if(e.key===' '||e.key==='Enter'){e.preventDefault();finish('keyboard:'+e.key);}};
    pad.onblur=()=>{for(const key of ['keyboard: ','keyboard:Enter'])if(holds.get(key)?.pad===pad)finish(key);};
  }
  window.addEventListener('blur',releaseAll);
  window.addEventListener('pagehide',releaseAll);
  document.addEventListener('visibilitychange',()=>{if(document.hidden)releaseAll();});

  const safeImage=value=>typeof value==='string' && value.length<=200000 && /^data:image\/(?:png|jpeg|webp);base64,[a-z0-9+/]+=*$/i.test(value);

  function renderGrid(tab){
    const grid=node('div',$('#content'),undefined,'grid'+(editing?' editing':''));
    for(const b of tab.buttons){
      const pad=node('button',grid,undefined,'pad deck-pad');
      pad.style.setProperty('--key',b.color);
      if(safeImage(b.image)){
        const img=node('img',pad,undefined,'pad-picture');img.src=b.image;img.alt='';img.draggable=false;
      }else node('span',pad,b.icon,'icon');
      node('span',pad,b.name,'label');node('kbd',pad,b.shortcut);
      if(b.mode==='hold')node('span',pad,'هولد','hold-label');
      if(editing)pad.onclick=()=>edit(b);
      else if(b.mode==='hold')attachHold(pad,b,tab);
      else pad.onclick=()=>{emit('shortcut',{keys:b.shortcut,label:b.name});toast(b.name+(connected?' • أُرسل':' • معاينة'));};
    }
    if(editing)control(grid,'+ إضافة زر',()=>edit(null)).className='pad';
  }

  async function thumbnail(file){
    const url=URL.createObjectURL(file);
    try{
      const img=new Image();img.src=url;await img.decode();
      const scale=Math.min(1,192/Math.max(img.naturalWidth,img.naturalHeight));
      const c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.naturalWidth*scale));c.height=Math.max(1,Math.round(img.naturalHeight*scale));
      c.getContext('2d').drawImage(img,0,0,c.width,c.height);
      const encoded=c.toDataURL('image/webp',.82);
      if(!safeImage(encoded))throw Error();
      return encoded;
    }finally{URL.revokeObjectURL(url);}
  }

  function edit(b){
    const tab=current();
    let selected=(b?.shortcut||'').split('+').filter(Boolean);
    let replacing=true, image=b?.image||'', imageJob=0;
    let layout=Object.keys(layouts)[0];
    modal(b?'تخصيص الزر':'إضافة زر',`
      <div class="chord-header"><output id="chord" dir="ltr" aria-live="polite"></output><button type="button" id="clearChord">مسح الاختصار</button></div>
      <p class="key-hint">اختار أول مفتاح للاختصار الجديد، وبعده أي مفاتيح عايز تضيفها. دوس على المفتاح المحدد تاني لإزالته.</p>
      <div id="keyPages"></div><div id="keyBoard" dir="ltr"></div>
      <div class="pad-options"><label>اسم الزر<input id="name" required maxlength="35"></label>
      <label>طريقة الضغط<select id="pressMode"><option value="tap">ضغطة واحدة</option><option value="hold">ضغط مستمر لحد ما ترفع صباعك</option></select></label>
      <label>الرمز<input id="icon" maxlength="4"></label><label>لون الزر<input type="color" id="color"></label></div>
      <div class="image-setting"><img id="picturePreview" alt="معاينة صورة الزر" hidden>
      <label>صورة الزر<input type="file" id="padFile" accept="image/*"></label><button type="button" id="removePicture">إزالة الصورة</button></div>
    `,()=>{
      if(!selected.length)throw Error('اختار مفتاح واحد على الأقل');
      const value={id:b?.id||uid(),name:required('name'),shortcut:selected.join('+'),icon:field('icon')||'◇',color:field('color'),mode:field('pressMode'),image};
      if(value.shortcut.length>80)throw Error('الاختصار أطول من المسموح');
      const previous=tab.buttons;
      tab.buttons=b?previous.map(item=>item===b?value:item):[...previous,value];
      try{localStorage.setItem('dexter-pad-v1',JSON.stringify(state));}
      catch{tab.buttons=previous;throw Error('مساحة الحفظ ممتلئة. جرّب إزالة صورة من الأزرار.');}
      $('#modal').close();render();
    });
    const fields=$('#fields'),dialog=$('#modal');
    $('#name').value=b?.name||'';$('#icon').value=b?.icon||'◇';
    $('#color').value=b?.color||'#6ce9cb';$('#pressMode').value=b?.mode==='hold'?'hold':'tap';
    function showKeys(){
      $('#chord').textContent=selected.join(' + ')||'اختار مفتاح';
      $('#keyPages').replaceChildren();
      for(const page of Object.keys(layouts)){
        const btn=control($('#keyPages'),page,()=>{layout=page;showKeys();});
        btn.setAttribute('aria-pressed',String(layout===page));
      }
      $('#keyBoard').replaceChildren();
      for(const keys of layouts[layout]){
        const row=node('div',$('#keyBoard'),undefined,'key-row');
        for(const key of keys){
          const btn=control(row,aliases[key]||key.replace(/^Numpad/,'Num '),()=>{
            if(replacing){selected=[];replacing=false;}
            if(selected.includes(key))selected=selected.filter(v=>v!==key);
            else selected.push(key);
            selected=[...modifiers.filter(v=>selected.includes(v)),...selected.filter(v=>!modifiers.includes(v))];
            showKeys();$('#keyBoard').querySelector('[data-key="'+CSS.escape(key)+'"]')?.focus({preventScroll:true});
          });
          btn.dataset.key=key;btn.setAttribute('aria-label',key);btn.setAttribute('aria-pressed',String(selected.includes(key)));
        }
      }
    }
    $('#clearChord').onclick=()=>{selected=[];replacing=false;showKeys();};showKeys();
    function showImage(){
      const img=$('#picturePreview');img.hidden=!image;
      if(image)img.src=image;else img.removeAttribute('src');
      $('#removePicture').hidden=!image;
    }
    showImage();
    const fileInput=$('#padFile'),submit=$('#submit');
    submit.disabled=false;
    fileInput.onchange=async()=>{
      const file=fileInput.files[0];if(!file)return;
      const job=++imageJob;submit.disabled=true;
      try{const result=await thumbnail(file);if(job===imageJob && fileInput.isConnected){image=result;showImage();$('#error').textContent='';}}
      catch{if(job===imageJob && fileInput.isConnected)$('#error').textContent='تعذّر فتح الصورة. جرّب صورة PNG أو JPG.';}
      finally{if(job===imageJob && fileInput.isConnected){submit.disabled=false;fileInput.value='';}}
    };
    $('#removePicture').onclick=()=>{imageJob++;image='';submit.disabled=false;showImage();};
    if(b)control(fields,'حذف الزر',()=>{tab.buttons=tab.buttons.filter(item=>item!==b);save();dialog.close();render();}).className='danger';
    dialog.addEventListener('close',()=>{imageJob++;submit.disabled=false;},{once:true});
    dialog.scrollTop=0;
  }
  return {renderGrid,releaseAll,safeImage};
})();
