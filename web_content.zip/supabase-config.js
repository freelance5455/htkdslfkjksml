/* إعدادات Supabase العامة فقط.
   ضع عنوان مشروعك ومفتاح anon/publishable هنا بعد إنشاء المشروع.
   لا تضع service_role key أو أي مفتاح سري داخل التطبيق مطلقًا. */
window.GZ_SUPABASE_CONFIG = {
  url: "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE",
  anonKey: "PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE",
  ownerEmail: "PUT_THE_OWNER_EMAIL_HERE"
};
