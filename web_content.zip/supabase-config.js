// Add your Supabase Project URL and anon/public key here. Never put a service_role key here.
window.ANIMEMIND_SUPABASE_CONFIG = {
  url: 'https://YOUR_PROJECT.supabase.co',
  anonKey: 'YOUR_SUPABASE_ANON_PUBLIC_KEY'
};
