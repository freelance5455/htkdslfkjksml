window.MUEEN_SUPABASE_CONFIG = { url: "", anonKey: "" };
