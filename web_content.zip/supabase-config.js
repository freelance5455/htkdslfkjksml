// Supabase Dashboard > Project Settings > API
// Use only the Project URL and anon/public key.
// NEVER put the service_role key in this file.
export const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL";
export const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY";
