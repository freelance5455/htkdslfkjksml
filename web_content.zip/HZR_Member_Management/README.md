# HZR Member Management — Android project prototype

**Important:** This folder is an Android Studio project scaffold and a working WebView-based app prototype. It is **not a compiled APK**. The current environment does not have Android SDK/build tools, so an installable APK could not be built or tested here.

## Features implemented in the prototype
- Current Member: add/edit and advanced search
- Old Member: transfer with removal date, reason, removed-by details; restore option
- Member ID format `HZ-YY-SSSSS-T`, with D/G/S/B type codes, structure checks, and serial uniqueness within each year
- Member ID Registry: assigned IDs and available serial preview
- Birthday Blaster on home screen: current members with birthdays in next 30 days, birth date, next birthday date, days remaining
- Profile details, Call and SMS links
- JSON backup export/import
- Local storage on the device/browser; no cloud sync

## Build the APK
1. Install Android Studio and its Android SDK (API 35).
2. Open this folder as an Android Studio project.
3. Allow Gradle sync to finish.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. For distribution, create a signed APK via **Build > Generate Signed Bundle / APK**.

## Limitations / production checklist
- The app uses local browser/WebView storage only. It does not sync across devices and has no multi-user authentication.
- Local storage is not encrypted; use test data until a secure database, access control, encryption, and backup policy are implemented.
- Review privacy and permissions before entering real member data.
- Test ID allocation and birthday calculations on target Android devices before official use.


## V2.0 prototype update (2026-10-27)
- Added first-run local Admin setup and login screen.
- Added Settings → Password Update with separate approval-password check and new-password confirmation. The approval value is stored as a SHA-256 hash in client code, but client-side checks are extractable and are **not secure for production**. Replace with server-side authorization before real deployment. A pure-JavaScript SHA-256 fallback is included for local-file WebView contexts.
- Added Instructions page describing the prototype features and limitations.
- Added Settings and Instructions shortcuts on the dashboard.
- Added a native Android SHA-256 bridge for local-file WebView contexts where `crypto.subtle` is unavailable. (The standalone JavaScript fallback has not been certified for all browsers; Android uses the native bridge.)
- Fixed Member ID validation to allow only D/G/S/B suffixes.
- Fixed serial allocation and duplicate checks to reset per year, while preventing duplicate serials within the same year across membership types.
- Updated ID Registry serial-only lookup to check the current year and use a full ID for older records.
- This remains a WebView/HTML prototype (Android versionName 2.0). Cloud sync, finance, receipts, QR verification, multi-admin security and a compiled APK are not included. The browser workflow was not fully automated in this environment; JavaScript syntax and SHA-256 fallback were checked, but Android device testing is still required.


## Additional second-pass review (2026-10-27)
- Fixed member editing so the membership type cannot be changed to a value that conflicts with the permanent Member ID suffix.
- Hardened JSON backup import: rejects malformed records, invalid IDs/status/type, ID/type mismatches, duplicate IDs and duplicate year/serial assignments before replacing existing records.
- Delayed revoking the backup download URL to reduce the chance of interrupting downloads on mobile browsers.
- Added Android handling for `tel:` and `sms:` links to open the phone dialer or messaging app rather than leaving those URLs inside the WebView.
- Added a back-button flow to close an open modal or return to Home before exiting.
- Disabled Android app auto-backup to avoid copying locally stored credentials/member records into device backup.
- Increased Android versionCode to 3.
- Verified JavaScript syntax, SHA-256 configured approval hash with Python's SHA-256, HTML asset parity, and ZIP integrity. Android/Gradle compilation and real-device testing remain unperformed.


## Third-pass review (2026-10-27)
- Added guarded JSON loading for local member and metadata storage so malformed saved JSON does not immediately crash app startup. Unreadable raw JSON is preserved under a recovery key when storage permits, and the dashboard displays a warning.
- Normalized imported member serial values from the validated Member ID, preventing missing or stale `serial` fields in an otherwise valid backup from affecting sorting.
- Re-copied the updated HTML into the Android WebView asset and verified both copies match exactly.
- Rechecked JavaScript syntax and the pure-JavaScript SHA-256 fallback against known test vectors. This is still static testing only; no Android build/device run was possible in this environment.


## Offline Sync (no cloud)

Settings includes **Export Sync Package** and **Import & Merge Sync Package**. This creates a JSON package that can be transferred between Admin devices using Bluetooth, Quick Share, USB, or another file-transfer method. Import merges records by Member ID: new IDs are added, records with a newer `updatedAt` timestamp replace older copies, and equal-time or serial collisions are retained locally and reported. To carry changes both ways, exchange a fresh package back to the originating device. This is manual file-based synchronization, not live sync. Export a full backup first. If multiple admins edit the same record concurrently, manually review conflicts; do not treat the merge as a cloud-grade conflict-resolution system.


## Fourth-pass review (2026-10-27)
- Added Android WebView's native document picker so JSON backup/sync import can select files through Android's file picker.
- Added a native Android save dialog for JSON exports, because browser Blob downloads are unreliable in a file-based WebView.
- Allowed content-URI access for the document picker.
- Added 10 MB file-size limits and a 20,000-record limit for offline sync imports to reduce accidental oversized imports.
- Normalized imported Member IDs to uppercase before merge validation.
- Compared records using stable key ordering so the same record is not falsely reported as a conflict just because JSON property order differs.
- Rechecked JavaScript syntax, SHA-256 fallback test vectors, HTML/asset parity and ZIP integrity. Android compilation and device testing are still pending because Android SDK/build tools are unavailable in this environment.


## Offline Sync review update (2026-10-27)
- Native Android JSON export now reports success only after the destination file has been written, and reports cancellation/failure instead of claiming export succeeded immediately.
- Browser-based export reports that a download was requested and reminds the user to check Downloads.
- Synced the updated main HTML to the Android WebView asset.
- Still requires an Android SDK build and real-device testing; no compiled APK is included.
