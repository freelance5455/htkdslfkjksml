# HZR Member Management — Android project prototype

**Important:** This folder is an Android Studio project scaffold and a working WebView-based app prototype. It is **not a compiled APK**. The current environment does not have Android SDK/build tools, so an installable APK could not be built or tested here.

## Features implemented in the prototype
- Current Member: add/edit and advanced search
- Old Member: transfer with removal date, reason, removed-by details; restore option
- Member ID format `HZ-YY-SSSSS-T`, with D/G/S/B type codes, structure checks, and duplicate/serial checks
- Member ID Registry: assigned IDs and available serial preview
- Birthday Blaster on home screen: current members with birthdays in next 30 days, birth date, next birthday date, days remaining
- Profile details, Call and SMS links
- JSON backup export/import
- Local storage on the device/browser; no cloud sync

## Build the APK
1. Install Android Studio and its Android SDK (API 35).
2. Open this folder as an Android Studio project.
3. Allow Gradle sync to finish.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. For distribution, create a signed APK via **Build > Generate Signed Bundle / APK**.

## Limitations / production checklist
- The app uses local browser/WebView storage only. It does not sync across devices and has no multi-user authentication.
- Local storage is not encrypted; use test data until a secure database, access control, encryption, and backup policy are implemented.
- Review privacy and permissions before entering real member data.
- Test ID allocation and birthday calculations on target Android devices before official use.
