# HZR Member Management — Version 3.8 Android project prototype

**Important:** This folder is an Android Studio project scaffold and a working WebView-based app prototype. It is **not a compiled APK**. The current environment does not have Android SDK/build tools, so an installable APK could not be built or tested here.

## Features implemented in the prototype
- Current Member: add/edit and advanced search
- Old Member: transfer with removal date, reason, removed-by details; restore option
- Member ID format `HZ-YY-SSSSS-T`, with D/G/S/B type codes, structure checks, and serial uniqueness within each year
- Member ID Registry: assigned IDs and available serial preview
- Birthday Blaster on home screen: current members with birthdays in next 30 days, birth date, next birthday date, days remaining
- Profile details, Call and SMS links
- JSON backup export/import
- Local storage on the device/browser; no cloud sync

## Build the APK
1. Install Android Studio and its Android SDK (API 35).
2. Open this folder as an Android Studio project.
3. Allow Gradle sync to finish.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. For distribution, create a signed APK via **Build > Generate Signed Bundle / APK**.

## Limitations / production checklist
- The app uses local browser/WebView storage only. It does not sync across devices and has no multi-user authentication.
- Local storage is not encrypted; use test data until a secure database, access control, encryption, and backup policy are implemented.
- Review privacy and permissions before entering real member data.
- Test ID allocation and birthday calculations on target Android devices before official use.


## V2.0 prototype update (2026-10-27)
- Added first-run local Admin setup and login screen.
- Added Settings → Password Update with separate approval-password check and new-password confirmation. The approval value is stored as a SHA-256 hash in client code, but client-side checks are extractable and are **not secure for production**. Replace with server-side authorization before real deployment. A pure-JavaScript SHA-256 fallback is included for local-file WebView contexts.
- Added Instructions page describing the prototype features and limitations.
- Added Settings and Instructions shortcuts on the dashboard.
- Added a native Android SHA-256 bridge for local-file WebView contexts where `crypto.subtle` is unavailable. (The standalone JavaScript fallback has not been certified for all browsers; Android uses the native bridge.)
- Fixed Member ID validation to allow only D/G/S/B suffixes.
- Fixed serial allocation and duplicate checks to reset per year, while preventing duplicate serials within the same year across membership types.
- Updated ID Registry serial-only lookup to check the current year and use a full ID for older records.
- This remains a WebView/HTML prototype (Android versionName 2.0). Cloud sync, finance, receipts, QR verification, multi-admin security and a compiled APK are not included. The browser workflow was not fully automated in this environment; JavaScript syntax and SHA-256 fallback were checked, but Android device testing is still required.


## Additional second-pass review (2026-10-27)
- Fixed member editing so the membership type cannot be changed to a value that conflicts with the permanent Member ID suffix.
- Hardened JSON backup import: rejects malformed records, invalid IDs/status/type, ID/type mismatches, duplicate IDs and duplicate year/serial assignments before replacing existing records.
- Delayed revoking the backup download URL to reduce the chance of interrupting downloads on mobile browsers.
- Added Android handling for `tel:` and `sms:` links to open the phone dialer or messaging app rather than leaving those URLs inside the WebView.
- Added a back-button flow to close an open modal or return to Home before exiting.
- Disabled Android app auto-backup to avoid copying locally stored credentials/member records into device backup.
- Increased Android versionCode to 3.
- Verified JavaScript syntax, SHA-256 configured approval hash with Python's SHA-256, HTML asset parity, and ZIP integrity. Android/Gradle compilation and real-device testing remain unperformed.


## Third-pass review (2026-10-27)
- Added guarded JSON loading for local member and metadata storage so malformed saved JSON does not immediately crash app startup. Unreadable raw JSON is preserved under a recovery key when storage permits, and the dashboard displays a warning.
- Normalized imported member serial values from the validated Member ID, preventing missing or stale `serial` fields in an otherwise valid backup from affecting sorting.
- Re-copied the updated HTML into the Android WebView asset and verified both copies match exactly.
- Rechecked JavaScript syntax and the pure-JavaScript SHA-256 fallback against known test vectors. This is still static testing only; no Android build/device run was possible in this environment.


## Offline Sync (no cloud)

Settings includes **Export Sync Package** and **Import & Merge Sync Package**. This creates a JSON package that can be transferred between Admin devices using Bluetooth, Quick Share, USB, or another file-transfer method. Import merges records by Member ID: new IDs are added, records with a newer `updatedAt` timestamp replace older copies, and equal-time or serial collisions are retained locally and reported. To carry changes both ways, exchange a fresh package back to the originating device. This is manual file-based synchronization, not live sync. Export a full backup first. If multiple admins edit the same record concurrently, manually review conflicts; do not treat the merge as a cloud-grade conflict-resolution system.


## Fourth-pass review (2026-10-27)
- Added Android WebView's native document picker so JSON backup/sync import can select files through Android's file picker.
- Added a native Android save dialog for JSON exports, because browser Blob downloads are unreliable in a file-based WebView.
- Allowed content-URI access for the document picker.
- Added 10 MB file-size limits and a 20,000-record limit for offline sync imports to reduce accidental oversized imports.
- Normalized imported Member IDs to uppercase before merge validation.
- Compared records using stable key ordering so the same record is not falsely reported as a conflict just because JSON property order differs.
- Rechecked JavaScript syntax, SHA-256 fallback test vectors, HTML/asset parity and ZIP integrity. Android compilation and device testing are still pending because Android SDK/build tools are unavailable in this environment.


## Offline Sync review update (2026-10-27)
- Native Android JSON export now reports success only after the destination file has been written, and reports cancellation/failure instead of claiming export succeeded immediately.
- Browser-based export reports that a download was requested and reminds the user to check Downloads.
- Synced the updated main HTML to the Android WebView asset.
- Still requires an Android SDK build and real-device testing; no compiled APK is included.


## Review 8 — Statistics & Analytics
- Added a separate Statistics & Analytics dashboard section accessible from Home.
- Added circular charts for member status, membership type, and gender.
- Added bar charts for department counts, join-year trend, and record completeness.
- All charts recalculate from locally saved member records; no cloud connection is used.
- Updated the Android WebView asset to match the root `index.html`.
- Validation: JavaScript syntax and ZIP integrity checked; Android APK build/device testing unavailable in this environment.

## Review 11 — Final static audit (2026-10-27)
- Corrected date-only defaults, month totals, and date-based export filenames to use the device's local calendar rather than UTC, avoiding date/month shifts in time zones such as Bangladesh (UTC+6).
- Changed member-wise Subscription chart aggregation to use Member ID as the key, so different members with the same name are not combined.
- Preserved two-decimal amounts in Subscription charts instead of rounding every chart value to whole taka.
- Made the “Members Who Paid” metric ignore blank member IDs.
- Clarified that the Bengali language option translates the Settings screen but some other screens remain in English.
- Copied the final HTML to the Android WebView asset and verified exact parity.
- Static checks: JavaScript syntax, SHA-256 fallback known vectors, and ZIP integrity. No Android SDK/Gradle build or real-device test was available, so this is not a guarantee that every runtime feature works on-device.


## Review 12 — Configurable Birthday Window (2026-10-27)
- Added a Settings → Birthday Blaster option to show birthdays for the next 1 month, 2 months, 3 months, or 1 year.
- Saved the selected window in local app preferences; the Dashboard count, Dashboard birthday list, Birthday Blaster page, and Statistics birthday metric use the same selection.
- Uses calendar-month/year boundaries rather than a fixed 30-day approximation, including month-end handling.
- Added Bengali translations for the setting and all four options.
- Copied the updated HTML into the Android WebView asset and checked exact parity.
- Static validation only; no Android APK build or real-device testing was available.


## Version 3.0 update (2026-10-27)
- Bumped Android versionName to 3.0 and versionCode to 4.
- Added Subscription → Member Lifetime Transaction History. Search by the exact Member ID to view that member's saved collection records from newest to oldest, with lifetime total and transaction count.
- Sorting uses payment date descending, then available update/creation metadata as a tie-breaker for same-day records.
- Search is local and includes only collection records saved/imported on this device; it does not fetch remote data and Subscription records are not yet merged by Offline Sync.
- Updated both the standalone HTML and Android WebView asset with the same source.
- Validation: JavaScript syntax, HTML asset equality, and ZIP integrity checked. Android APK build and physical-device testing were not available in this environment.


## Version 3.1 audit update
- Added member profile fields for Current Work / Role and Achievements, including view/edit persistence and completeness metrics.
- Expanded Subscription charts with payment-method circular chart and yearly collection bar chart.
- Stabilized newest-first transaction ordering when multiple records share a date.
- Offline Sync package v2 includes Subscription collections and merges by collection ID using update timestamps. Legacy v1 member-only packages remain importable.
- Added Bengali labels for additional common screens; not every sentence/field in the app is fully translated.
- APK build and physical Android-device testing remain outstanding.


## Version 3.2 audit fixes

- Subscription charts now show BDT currency values in circular-chart totals/legends and bar-chart values, rather than unlabeled raw numbers.
- Added strict calendar-date validation for collection entry and collection import/sync.
- Collection imports reject invalid or duplicate collection IDs instead of silently overwriting duplicate IDs in the incoming file.
- Full backup import now rejects invalid Subscription records rather than silently dropping malformed collection entries.
- Existing locally stored Subscription data is checked at startup; invalid/duplicate rows are copied to a local recovery key where storage permits, and only valid rows are loaded.
- Changing theme, text size, compact cards or birthday range re-applies the selected language after rerendering Settings.
- Android app version updated to 3.2 (versionCode 6).

Validation performed: JavaScript syntax check, helper-level date/record validation tests, matching web and Android HTML assets, and ZIP integrity test. The Android APK was not built and real-device behavior remains unverified because this environment does not have a configured Android SDK/Gradle build setup.


## Version 3.3 audit fixes (2026-10-27)
- Made Full Backup import transactional: all member IDs, serial uniqueness, and Subscription records are validated before replacing any in-memory or stored data.
- Normalized imported member IDs to uppercase before validation, avoiding false rejection of otherwise valid lowercase IDs while still enforcing unique IDs/serials.
- A full backup that predates Subscription support now replaces Subscription records with an empty list rather than accidentally retaining unrelated collections from the current device.
- If member/meta storage succeeds but Subscription storage fails, the import rolls back the member and metadata changes instead of leaving a partial replacement.
- Updated the Settings/Instructions version labels and Android versionName to 3.3 (versionCode 7).
- Static/helper checks only; no Android APK build or physical-device test was performed.


## Version 3.4 audit fixes (2026-10-27)
- Fixed leap-day birthdays: members born on 29 February are consistently shown on 28 February in non-leap years instead of rolling to 1 March.
- Birthday calculations now reject malformed stored birth dates before creating a calendar date.
- Monthly collection chart now always displays the current month plus the preceding 11 calendar months, including zero-collection months; it no longer shows 12 non-empty months that may span a misleading time range.
- Updated app labels and Android version metadata to 3.4 (versionCode 8).
- Main HTML and Android WebView asset are kept byte-identical.


## Version 3.5 audit fixes (2026-10-27)
- Added strict optional calendar-date validation for imported member records (date of birth, join date, and removal date) in both full-backup replacement and offline-sync merge. Blank optional dates remain allowed for legacy records. Invalid dates such as 2026-02-30 are rejected before any import changes are applied.
- Updated app instructions/version labels and Android metadata to 3.5 (versionCode 9).
- Synchronized the browser HTML and Android WebView asset.
- Static checks only; this does not claim a built APK or physical-device end-to-end testing.


Version 3.7 logo update: the home/header area now displays both supplied HZR Member Info (blue) and HZR emblem (black/gold) logos. Both image assets are included in the web root and Android WebView assets.


## Version 3.7 header update
- Reworked the app header to place the original blue HZR Member Info logo on the left and the black/gold HZR logo on the right, with the existing HYPER ZONE REPUBLIC / MEMBER MANAGEMENT SYSTEM title centered between them.
- Cropped excess blank canvas around the artwork while preserving the full logo marks; header images use object-fit: contain and no clipping container.
- Updated header to a blue/white theme and bumped Android versionName to 3.7, versionCode to 11.
- Main HTML and Android WebView HTML/assets are synchronized.


## Version 3.8 audit fixes (2026-10-27)
- Cropped excessive near-white margins from both supplied logo assets so the blue logo is less likely to appear visually cut off at small sizes.
- Kept both logos on the outer sides of the centered home header text and tightened responsive sizing.
- Updated stale in-app About/Instructions labels from Version 3.6 to Version 3.8.
- Synced Android WebView assets with the root HTML and logo assets.
- Android versionName 3.8; versionCode 12.
- Static checks only; no APK build or physical-device test performed.


## Version 4.0 — Membership Expansion & Hyper Statistics
- Expanded member records with personal, educational, skills, guardian, declaration, application and official-use fields from the latest HZR membership application form.
- Existing local storage remains device-local; this is not cloud sync or production-grade access control.
- Version Name: 4.0; Version Code: 13.


## Version 4.1 — Application Approval & Reports
- Added Application Approval Center. New registrations are saved as Pending and remain outside Current Members until approved. Admin approval records the approving name/date; rejection requires a reason and records the Admin name.
- Provisional Member ID is allocated when an application is submitted and retained after approval.
- Reports and approval data remain local to this device; no cloud backend or automatic sync is added.

## Version 4.2 — Statistics Dashboard Redesign
- Reworked Statistics & Analytics into a responsive, dashboard-style analytics screen inspired by the supplied references.
- Added current-vs-old membership donut, department comparison bars, application and fee-status summaries, plus profile and membership breakdown charts.
- All visualizations use locally stored records; no sample or fabricated statistics are inserted.
- Android version: 4.2 (versionCode 15).


- New member forms prefill the next available ID using HZ-YY-SSSSS-T; year and serial are generated automatically, while admins select D/G/S/B.
- Admins can edit the complete ID manually, subject to format, uniqueness and membership-type validation.
- Version code 16.

## V4.3 update — Eanat module removal
- Removed the Eanat dashboard module, collection forms, records, reports, member payment status, and all Eanat-related analytics.
- Backup and offline sync now contain member records and metadata only; older packages with an optional Eanat payload remain import-compatible, but that payload is ignored.


## V4.3 Member Menu Style Update (2026-11-05)

- Added Settings → Member Menu selection for Classic and Bookshelf Style.
- Saved selected style in the existing local preferences store; default is Classic.
- Kept the existing Classic member list path and its search/profile/edit actions.
- Added bookshelf presentation for Current/New and Old member categories using existing records and IDs.
- Added instant partial search across Member ID, Name and Digital Name, plus Member Type and Department filters and clear controls.
- Books are sorted by existing serial/ID, grouped into two-tier shelf units, styled with HZR blue framing and gold accents, and open the corresponding existing member profile.
- Kept both HTML entry copies synchronized (root index.html and Android assets index.html). No APK was built.


## V5.0 Member Menu and Navigation Update (AI deferred)

- Application Version Name: 5.0; Version Code: 17.
- Expanded Settings → Member Menu selection to eight presentations: Classic, Bookshelf, Classic Bookshelf, Modern Grid, Compact List, Index Card, File Cabinet, and Modern Bookshelf.
- Kept the Classic renderer and the pre-existing Bookshelf renderer as their own paths; new presentations use the same existing member records and profile-opening action.
- Added searchable, responsive grid/list/index-card/file-cabinet views and HZR-blue bookshelf views. Classic Bookshelf displays member IDs vertically in top-to-bottom reading direction; the original Bookshelf spine presentation is unchanged.
- Added page navigation history and page-level Back controls; Android System Back now uses the page history and closes an open profile/modal first.
- AI / Ask AI work is intentionally deferred per user direction.
- Database schema and local member record storage were not intentionally changed.
- Validation performed: JavaScript syntax check (`node --check`) passed. A full Android Gradle build/APK and device install test were not possible in this environment because Gradle and Android SDK/platform tools are not installed.


## Version 5.5 — Birthday Blaster, Bookshelf & Hyper Digital Statistics (2026-11-10)

- Android `versionName` updated to `5.5`; `versionCode` set to `51` as requested.
- Birthday Blaster now includes seven selectable layouts: Classic Birthday, 3D Celebration, Royal Gold, Hyper Digital (default), Minimal White, Memory Gallery, and Magazine Style.
- Birthday layout and animation preferences are stored locally. Birthday animation is enabled by default and can be disabled.
- All birthday layouts use the same existing Current Member records and birthday calculations; no separate birthday data is created.
- Corrected Bookshelf geometry so each bookshelf is rendered as two distinct five-book shelf rows with a visible shelf divider, and additional books flow into subsequent bookshelf units.
- Refined the Statistics & Analytics visual theme with Hyper Digital blue dashboard styling while retaining database-driven charts and existing calculations.
- Root `index.html`, Android WebView asset `app/src/main/assets/index.html`, and requested `app/zip/index.html` are synchronized.
- Static validation required before release: JavaScript syntax, HTML asset parity, settings persistence logic, birthday layout selection, bookshelf layout structure, and ZIP integrity.
- Android APK compilation and physical-device testing must be completed in an Android SDK environment; this source package is not itself a compiled APK.
