package com.hzr.members;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class MainActivity extends Activity {
    private static final int REQUEST_IMPORT_FILE = 4101;
    private static final int REQUEST_EXPORT_FILE = 4102;
    private WebView web;
    private ValueCallback<Uri[]> pendingFileCallback;
    private String pendingExportContent;
    private String pendingExportName = "HZR-backup.json";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleExternalUrl(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleExternalUrl(Uri.parse(url));
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback, FileChooserParams params) {
                if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
                pendingFileCallback = filePathCallback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "text/plain", "application/octet-stream"});
                try { startActivityForResult(intent, REQUEST_IMPORT_FILE); return true; }
                catch (Exception e) { pendingFileCallback = null; filePathCallback.onReceiveValue(null); Toast.makeText(MainActivity.this, "Unable to open file picker.", Toast.LENGTH_SHORT).show(); return false; }
            }
        });
        web.addJavascriptInterface(new NativeSecurity(), "HZRNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    public final class NativeSecurity {
        @JavascriptInterface public String sha256(String value) {
            try {
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                byte[] bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
                StringBuilder out = new StringBuilder(bytes.length * 2);
                for (byte b : bytes) out.append(String.format("%02x", b & 0xff));
                return out.toString();
            } catch (Exception e) { throw new IllegalStateException("SHA-256 unavailable", e); }
        }
        @JavascriptInterface public void saveJson(String filename, String content) {
            runOnUiThread(() -> {
                pendingExportName = filename == null || filename.trim().isEmpty() ? "HZR-export.json" : filename.replaceAll("[^A-Za-z0-9._-]", "_");
                pendingExportContent = content == null ? "{}" : content;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, pendingExportName);
                try { startActivityForResult(intent, REQUEST_EXPORT_FILE); }
                catch (Exception e) { pendingExportContent = null; notifySaveResult(false, "Unable to open save dialog."); Toast.makeText(MainActivity.this, "Unable to open save dialog.", Toast.LENGTH_SHORT).show(); }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMPORT_FILE) {
            if (pendingFileCallback != null) {
                Uri[] result = resultCode == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null;
                pendingFileCallback.onReceiveValue(result);
                pendingFileCallback = null;
            }
            return;
        }
        if (requestCode == REQUEST_EXPORT_FILE) {
            boolean saved = false;
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingExportContent != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IllegalStateException("Cannot open destination");
                    out.write(pendingExportContent.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                    saved = true;
                    Toast.makeText(this, "JSON file saved.", Toast.LENGTH_SHORT).show();
                } catch (Exception e) { Toast.makeText(this, "Could not save JSON file.", Toast.LENGTH_LONG).show(); }
            }
            notifySaveResult(saved, saved ? "JSON file saved. You can now share it with the other Admin." : (resultCode == RESULT_CANCELED ? "Save cancelled. No file was exported." : "Could not save JSON file. Please try again."));
            pendingExportContent = null;
        }
    }

    private void notifySaveResult(boolean success, String message) {
        if (web == null) return;
        String escaped = message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
        web.evaluateJavascript("if(window.hzrNativeSaveResult){window.hzrNativeSaveResult(" + success + ", '" + escaped + "')}", null);
    }

    private boolean handleExternalUrl(Uri uri) {
        String scheme = uri.getScheme();
        if (scheme == null || scheme.equals("file") || scheme.equals("about") || scheme.equals("content")) return false;
        if (scheme.equals("tel") || scheme.equals("sms") || scheme.equals("smsto")) {
            try {
                Intent intent = scheme.equals("tel") ? new Intent(Intent.ACTION_DIAL, uri) : new Intent(Intent.ACTION_SENDTO, uri);
                startActivity(intent);
            } catch (Exception e) { Toast.makeText(this, "No compatible phone or messaging app was found.", Toast.LENGTH_SHORT).show(); }
            return true;
        }
        return true;
    }

    @Override public void onBackPressed() {
        if (web != null) {
            web.evaluateJavascript("if(document.querySelector('#modalroot')?.innerHTML){document.querySelector('#modalroot').innerHTML='';'closed'}else if(typeof page!=='undefined'&&page!=='home'){navigate('home');'home'}else{'exit'}", value -> {
                if ("\"exit\"".equals(value)) MainActivity.super.onBackPressed();
            });
        } else super.onBackPressed();
    }
}
