# JOM BACA! — prototaip Android portrait

Buka `index.html` dalam Chrome Android. Untuk pengalaman skrin penuh, hoskan folder ini melalui HTTPS dan gunakan **Add to Home screen**; manifest membolehkan mod standalone. ZIP ini ialah game web luar talian selepas fail disimpan setempat, bukan APK.

Aliran: profil/nama panggilan → umur → peta → level 10 aktiviti → keputusan → papan juara. Setiap sesi memilih dua daripada setiap lima jenis aktiviti. Progres dan papan juara disimpan pada peranti melalui localStorage; tiada pelayan atau akaun. Profil berlainan mempunyai jumlah markah sendiri. Soalan dipisahkan dalam `data.js` (90 aktiviti terjana daripada set data). Untuk menambah soalan, gunakan `add({...})` dengan `age`, `module` (0–7), `type`, `prompt`, `question`, `options`/`pairs`, `answer`, `image`, `audio`, `points`.

Audio perkataan menggunakan SpeechSynthesis `ms-MY` apabila suara tersebut tersedia pada peranti; jika tiada, sistem mungkin guna sebutan lalai. Kesan bunyi ringkas dijana menggunakan Web Audio. Rakaman suara BM boleh menggantikan `speak()` kemudian.

Aktiviti disusun sebagai latihan perkembangan membaca prasekolah. Ini demo yang diinspirasikan oleh kemahiran awal membaca; pemetaan tepat kepada kod Standard Pembelajaran Kurikulum Prasekolah 2026 perlu disemak pendidik sebelum digunakan sebagai bahan rasmi. Rujukan: https://bpk.moe.gov.my/menu-docman/483-dokumen-kurikulum-prasekolah-2026/file
