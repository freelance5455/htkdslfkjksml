/* Content lives here: add entries without changing game.js. Each card has age, module, type, prompt, options, answer, image, audio and points. */
const WORLDS=[['Kenali Huruf','🔤'],['Bunyi Huruf','🎵'],['Vokal','🌈'],['Suku Kata','🧩'],['Bina Perkataan','🏗️'],['Jom Membaca','📖'],['Ayat Mudah','💬'],['Cabaran Membaca','🏆']];
const WORDS=[
 {word:'IBU',parts:['I','BU'],icon:'👩',age:4},{word:'AYAH',parts:['A','YAH'],icon:'👨',age:4},{word:'MATA',parts:['MA','TA'],icon:'👀',age:4},{word:'KAKI',parts:['KA','KI'],icon:'🦶',age:4},{word:'BUKU',parts:['BU','KU'],icon:'📚',age:5},{word:'BOLA',parts:['BO','LA'],icon:'⚽',age:5},{word:'BAJU',parts:['BA','JU'],icon:'👕',age:5},{word:'SUSU',parts:['SU','SU'],icon:'🥛',age:5},{word:'NASI',parts:['NA','SI'],icon:'🍚',age:5},{word:'IKAN',parts:['I','KAN'],icon:'🐟',age:5},{word:'KUCING',parts:['KU','CING'],icon:'🐈',age:6},{word:'AYAM',parts:['A','YAM'],icon:'🐓',age:6},{word:'RUMAH',parts:['RU','MAH'],icon:'🏠',age:6},{word:'MEJA',parts:['ME','JA'],icon:'🪑',age:6},{word:'KERUSI',parts:['KE','RU','SI'],icon:'🪑',age:6}
];
const LETTERS=[['A','a','🍎','epal'],['B','b','⚽','bola'],['C','c','🏆','cawan'],['D','d','🎲','dadu'],['E','e','🦅','elang'],['I','i','🐟','ikan'],['K','k','🐈','kucing'],['M','m','👀','mata'],['O','o','🍊','oren'],['U','u','🐍','ular']];
const SENTENCES=[{text:'ALI MAKAN NASI.',ask:'Apakah yang Ali makan?',answer:'NASI',options:['NASI','BUKU','BOLA'],icon:'🍚'},{text:'IBU BACA BUKU.',ask:'Apakah yang ibu baca?',answer:'BUKU',options:['BUKU','BAJU','IKAN'],icon:'📚'},{text:'KUCING TIDUR DI RUMAH.',ask:'Siapakah yang tidur?',answer:'KUCING',options:['KUCING','AYAM','ALI'],icon:'🐈'},{text:'AYAH BELI BAJU.',ask:'Apakah yang ayah beli?',answer:'BAJU',options:['BAJU','BOLA','NASI'],icon:'👕'},{text:'BOLA ADA DI BAWAH MEJA.',ask:'Di manakah bola?',answer:'BAWAH MEJA',options:['BAWAH MEJA','ATAS RUMAH','DALAM BUKU'],icon:'⚽'}];
const bank=[];let serial=0;function add(q){bank.push({id:'Q'+(++serial),points:10,...q})}
for(const [i,l] of LETTERS.entries()){
 add({age:4,module:i%3,type:'objective',prompt:'Cari huruf '+l[0],question:'Yang manakah huruf '+l[0]+'?',options:[l[0],...LETTERS.filter(x=>x[0]!==l[0]).slice((i+2)%5,(i+2)%5+2).map(x=>x[0])],answer:l[0],image:l[2],audio:l[0]});
 add({age:4,module:i%3,type:'cards',prompt:'Pilih huruf kecil bagi '+l[0],question:l[0]+' → ?',options:[l[1],...LETTERS.filter(x=>x[0]!==l[0]).slice((i+3)%5,(i+3)%5+2).map(x=>x[1])],answer:l[1],image:l[2],audio:l[0]});
}
for(const [i,w] of WORDS.entries()){
 const peers=WORDS.filter(x=>x.word!==w.word && x.age<=Math.max(w.age,5));
 const other=[peers[(i+2)%peers.length].word,peers[(i+5)%peers.length].word];
 add({age:w.age,module:w.age===4?2:w.age===5?4:5,type:'cards',prompt:'Pilih perkataan yang sepadan dengan gambar',question:w.icon,options:[w.word,...other],answer:w.word,image:w.icon,audio:w.word});
 add({age:w.age,module:w.age===4?3:w.age===5?4:5,type:'drag',prompt:'Seret suku kata pertama ke ruang kosong',question:w.icon+'  '+ '___ + '+w.parts.slice(1).join(' + '),options:[w.parts[0],...['BO','KU','LA','MA','SI','TA','BA'].filter(x=>x!==w.parts[0]).slice(i%3,i%3+2)],answer:w.parts[0],image:w.icon,audio:w.word});
 add({age:w.age,module:w.age===4?3:w.age===5?4:5,type:'order',prompt:'Susun suku kata menjadi perkataan',question:w.icon+'  '+w.word,options:w.parts,answer:w.parts.join('|'),image:w.icon,audio:w.word});
}
for(const [i,w] of WORDS.entries()){
 const peers=WORDS.filter(x=>x.word!==w.word&&x.age<=Math.max(4,w.age));
 const items=[w,...peers.slice(i%Math.max(1,peers.length-2),i%Math.max(1,peers.length-2)+2)];
 if(items.length===3)add({age:w.age,module:w.age===4?2:w.age===5?5:6,type:'match',prompt:'Padankan gambar dengan perkataan',question:'Cari pasangan yang betul',pairs:items.map(x=>({icon:x.icon,word:x.word})),answer:items.map(x=>x.word).join('|'),image:w.icon,audio:w.word});
}
for(const [i,s] of SENTENCES.entries()){
 add({age:6,module:6,type:'objective',prompt:'Baca ayat dan jawab soalan',question:s.text+'|'+s.ask,options:s.options,answer:s.answer,image:s.icon,audio:s.text});
 add({age:6,module:7,type:'cards',prompt:'Dengar dan pilih jawapan',question:s.text+'|'+s.ask,options:s.options,answer:s.answer,image:s.icon,audio:s.text});
}
