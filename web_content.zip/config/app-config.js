// Réglages non sensibles. Ne mettez JAMAIS de clé API ici (ce fichier est public dans l'APK).
// AI_ENDPOINT : URL https de votre proxy (voir backend/ai-worker.js). Laisser vide pour désactiver l'assistant intégré.
window.APP_CONFIG = { AI_ENDPOINT: "" };
