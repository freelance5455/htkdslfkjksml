/* Interações globais e utilitários do Love Bank */
(() => {
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  window.LoveBank = window.LoveBank || {};
  window.LoveBank.toast = (message) => {
    let region = $("#toast-region");
    if (!region) { region = document.createElement("div"); region.id="toast-region"; region.className="toast-region"; region.setAttribute("role","status"); document.body.append(region); }
    const toast=document.createElement("div"); toast.className="toast"; toast.textContent=message; region.append(toast);
    window.setTimeout(()=>toast.remove(),3500);
  };
  $$("[data-toast]").forEach(btn=>btn.addEventListener("click",()=>window.LoveBank.toast(btn.dataset.toast)));
  $$("[data-go]").forEach(btn=>btn.addEventListener("click",()=>location.href=btn.dataset.go));
  $$("[data-logout]").forEach(btn=>btn.addEventListener("click",()=>{sessionStorage.removeItem("loveBankDemoUser");location.href="index.html";}));
  $$("[data-toggle-password]").forEach(btn=>btn.addEventListener("click",()=>{
    const input=$("#"+btn.dataset.togglePassword); if(!input)return;
    const show=input.type==="password";input.type=show?"text":"password";btn.setAttribute("aria-label",show?"Ocultar senha":"Mostrar senha");
  }));
  const menu=$(".sidebar");
  $$("[data-menu-toggle]").forEach(btn=>btn.addEventListener("click",()=>menu?.classList.toggle("open")));
  document.addEventListener("click",e=>{if(menu?.classList.contains("open")&&!menu.contains(e.target)&&!e.target.closest("[data-menu-toggle]"))menu.classList.remove("open");});
  const page=$(".page-content")?.dataset.page;
  if(page){const link=$(`[data-nav="${page}"]`);link?.classList.add("active");}
  const globalSearch=$("#global-search");
  globalSearch?.addEventListener("keydown",e=>{if(e.key==="Enter"&&globalSearch.value.trim()){sessionStorage.setItem("loveBankSearch",globalSearch.value.trim());location.href="extrato.html";}});
  if($("#transaction-search")&&sessionStorage.getItem("loveBankSearch")){$("#transaction-search").value=sessionStorage.getItem("loveBankSearch");sessionStorage.removeItem("loveBankSearch");$("#transaction-search").dispatchEvent(new Event("input"));}
  $("#forgot-password")?.addEventListener("click",e=>{e.preventDefault();window.LoveBank.toast("Na demonstração, crie uma nova conta ou use o acesso local. Recuperação real exige backend seguro.");});
  $("#google-demo")?.addEventListener("click",()=>window.LoveBank.toast("O login Google precisa de integração OAuth real. Nenhuma autenticação foi realizada."));
  $("#terms-link")?.addEventListener("click",e=>{e.preventDefault();window.LoveBank.toast("Demonstração: termos ilustrativos. Consulte um profissional antes de publicar um serviço real.");});
  $("#toggle-balance")?.addEventListener("click",()=>{const balance=$("[data-balance]");if(!balance)return;const hidden=balance.dataset.hidden==="true";balance.textContent=hidden?"R$ 8.450,90":"R$ ••••••";balance.dataset.hidden=String(!hidden);$("#toggle-balance").setAttribute("aria-label",hidden?"Ocultar saldo":"Revelar saldo");});
  $("#chart-period")?.addEventListener("change",e=>{if(e.target.value==="12")window.LoveBank.toast("Visão anual ilustrativa selecionada.");else window.LoveBank.toast("Exibindo os últimos 6 meses.");});
  $("#theme-toggle")?.addEventListener("change",e=>{document.body.classList.toggle("dark-mode",e.target.checked);try{localStorage.setItem("loveBankTheme",e.target.checked?"dark":"light");}catch{}});
  try{if(localStorage.getItem("loveBankTheme")==="dark"&&$("#theme-toggle")){$("#theme-toggle").checked=true;document.body.classList.add("dark-mode");}}catch{}
  $("#notifications-toggle")?.addEventListener("change",e=>window.LoveBank.toast(e.target.checked?"Notificações demonstrativas ativadas.":"Notificações demonstrativas desativadas."));
  $("#avatar-upload")?.addEventListener("change",e=>{const file=e.target.files?.[0];if(!file)return;if(!file.type.startsWith("image/")){window.LoveBank.toast("Selecione um arquivo de imagem.");return;}if(file.size>2*1024*1024){window.LoveBank.toast("A imagem deve ter até 2 MB.");return;}const reader=new FileReader();reader.onload=()=>{$("#profile-avatar").style.backgroundImage=`url(${reader.result})`;$("#profile-avatar").style.backgroundSize="cover";$("#profile-avatar").textContent="";window.LoveBank.toast("Foto aplicada nesta sessão.");};reader.readAsDataURL(file);});
  $("#profile-form")?.addEventListener("submit",e=>{e.preventDefault();const name=$("#profile-name-input").value.trim(),email=$("#profile-email-input").value.trim();if(!name||!email.includes("@")){setMessage($("#profile-message"),"Confira seu nome e e-mail.",true);return;}$("#profile-name").textContent=name;$("#profile-email").textContent=email;setMessage($("#profile-message"),"Perfil atualizado nesta demonstração.");});
  $("#goal-form")?.addEventListener("submit",e=>{e.preventDefault();const name=$("#goal-name").value.trim(),target=Number($("#goal-target").value),saved=Number($("#goal-saved").value);if(!name||target<=0||saved<0){window.LoveBank.toast("Confira os dados da sua meta.");return;}const pct=Math.min(100,Math.round(saved/target*100));$("#goal-result").textContent=`${name} · ${pct}% concluída · faltam ${money(Math.max(0,target-saved))}`;window.LoveBank.toast("Meta atualizada na demonstração.");});
  function setMessage(el,msg,error=false){if(!el)return;el.textContent=msg;el.classList.toggle("error",error);}
  function money(n){return n.toLocaleString("pt-BR",{style:"currency",currency:"BRL"});}
})();