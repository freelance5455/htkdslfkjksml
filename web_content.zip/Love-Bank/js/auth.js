/* Fluxos de autenticação APENAS demonstrativos. Não usar em produção. */
(() => {
  const $=s=>document.querySelector(s);
  const say=(el,msg,error=false)=>{if(!el)return;el.textContent=msg;el.classList.toggle("error",error);};
  const getUsers=()=>{try{return JSON.parse(localStorage.getItem("loveBankDemoUsers")||"[]");}catch{return[];}};
  const saveUsers=users=>localStorage.setItem("loveBankDemoUsers",JSON.stringify(users));
  $("#signup-form")?.addEventListener("submit",e=>{
    e.preventDefault();
    const name=$("#full-name").value.trim(),email=$("#signup-email").value.trim().toLowerCase(),birth=$("#birth-date").value,password=$("#signup-password").value,confirm=$("#confirm-password").value;
    const msg=$("#signup-message");
    if(name.length<2||!email.includes("@")||!birth){say(msg,"Preencha os campos obrigatórios corretamente.",true);return;}
    if(password.length<8){say(msg,"A senha demonstrativa deve ter pelo menos 8 caracteres.",true);return;}
    if(password!==confirm){say(msg,"As senhas não são iguais. Tente novamente.",true);return;}
    if(!$("#accept-terms").checked){say(msg,"Você precisa aceitar os termos ilustrativos.",true);return;}
    const users=getUsers();if(users.some(u=>u.email===email)){say(msg,"Este e-mail já foi cadastrado nesta demonstração.",true);return;}
    /* Aviso: armazenamento local e senha simples servem só para protótipo, nunca produção. */
    users.push({name,email,birth,password});saveUsers(users);
    sessionStorage.setItem("loveBankDemoUser",JSON.stringify({name,email}));
    say(msg,"Conta demonstrativa criada! Abrindo seu painel…");setTimeout(()=>location.href="dashboard.html",700);
  });
  $("#login-form")?.addEventListener("submit",e=>{
    e.preventDefault();const email=$("#login-email").value.trim().toLowerCase(),password=$("#login-password").value,msg=$("#login-message");
    if(!email.includes("@")||!password){say(msg,"Informe um e-mail válido e sua senha.",true);return;}
    const user=getUsers().find(u=>u.email===email&&u.password===password);
    if(user){sessionStorage.setItem("loveBankDemoUser",JSON.stringify({name:user.name,email:user.email}));say(msg,"Acesso demonstrativo autorizado. Abrindo painel…");setTimeout(()=>location.href="dashboard.html",600);}
    else say(msg,"Não encontramos essa conta demonstrativa. Crie uma conta primeiro.",true);
  });
})();