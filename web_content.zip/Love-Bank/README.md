# Love Bank — demonstração visual

Projeto front-end em HTML5, CSS3 e JavaScript, com telas de entrada, login, cadastro, painel, Pix demonstrativo, extrato, cartões e perfil.

## Executar
1. Extraia a pasta `Love-Bank`.
2. Abra `index.html` no navegador. Para melhor compatibilidade, use um servidor local simples (por exemplo, a extensão Live Server no VS Code).
3. Clique em **Começar agora** para cadastrar uma conta demonstrativa, ou em **Já tenho uma conta** para entrar.
4. Use apenas dados fictícios. Os dados de conta da demonstração ficam no armazenamento local do navegador.

## Arquivos
- `index.html`: tela de entrada e identidade visual.
- `login.html`, `cadastro.html`: formulários demonstrativos.
- `dashboard.html`: resumo financeiro.
- `pix.html`: fluxo de revisão e comprovante demonstrativo.
- `extrato.html`: filtros e exportação CSV.
- `cartoes.html`: cartão inteiramente fictício.
- `perfil.html`: preferências, tema e metas.
- `css/style.css`: estilos, responsividade e animações.
- `js/script.js`: interações gerais.
- `js/auth.js`: fluxos locais de login/cadastro.
- `js/financeiro.js`: dados e interações financeiras.

## Limites importantes
Este projeto **não é um banco real**. Não envia Pix, não faz transferências, não cria cartões válidos e não se conecta ao Google. Login/cadastro usam armazenamento local apenas para demonstrar o fluxo; não é seguro para produção. Não coloque senhas reais, CPF, dados bancários ou segredos no projeto.

Para um produto real, será necessário backend HTTPS, autenticação segura (hash de senha com algoritmo apropriado, sessões/tokens protegidos), banco de dados com controle de acesso, monitoramento, antifraude, proteção de dados e integração com instituição/provedor autorizado. Operações Pix e serviços financeiros exigem avaliação jurídica e regulatória no Brasil.
