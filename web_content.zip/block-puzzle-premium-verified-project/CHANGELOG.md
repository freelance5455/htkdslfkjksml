# Changelog — Premium Block Puzzle

## Premium upgrade (this build)

### Preserved
- Original board size (8×8), shape set, scoring formula, combo rules
- Pointer-event drag system with touch lift offset
- Themes, block styles, synth audio, vibration, effects toggles
- Save/resume session, Continue-once, best score
- Line-clear beams, particles, placement preview (static)

### Fixed / hardened
- Placement preview cells remain static (no CSS animation/filter/transform on drag previews) for Android WebView stability
- Undo stack and hint never mutate board on invalid paths
- Save format versioned (v2) with graceful fallback

### Added
1. **Undo** — up to 3 move history; restores board, hand, score, combo
2. **Hint** — searches legal placements; highlights cells + tray piece; truthful “no moves” message
3. **Daily Challenge** — local-date target score; progress & completion persisted
4. **Achievements** — 9 tracked achievements unlocked from real events
5. **Local records** — personal score history list (offline only)
6. Home navigation updated (Daily, Achieve, Theme, Settings, Help)
7. In-game Undo + Hint buttons in HUD

### Not included / requires backend
- Online multiplayer leaderboard, accounts, cross-device sync
