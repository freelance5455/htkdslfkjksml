# Block Puzzle — Premium Edition

Single-file offline HTML5 block puzzle game, upgraded for smooth mobile drag-and-drop, premium visuals, and additional features.

## Files

- `index.html` — complete game (HTML + CSS + JS)
- `assets/app-icon-512.png` — 512×512 app icon for APK builders
- `original-source-backup.html` — untouched prior source
- `CHANGELOG.md` — what changed
- `TEST_REPORT.md` — tests performed and limitations

## How to run

1. Open `index.html` in a modern mobile or desktop browser, **or**
2. Load it into your HTML-to-APK builder and set `assets/app-icon-512.png` as the app icon.

Core gameplay works fully offline. No network requests are required.

## Features

**Preserved from original**
- 8×8 board, classic shapes, tray of 3 pieces
- Drag / drop with touch lift offset and placement preview
- Row & column clears, combo scoring, perfect-board bonus
- Themes (Classic, Aurora, Neon, Forest, Ocean)
- Block styles (Glossy, Flat, Neon)
- Sound (Web Audio piano synth), vibration, effects toggles
- Save / resume, Continue-once on game over
- Best score persistence

**Added / improved**
- **Undo** — reverse the last placement (up to 3 steps). Restores board, hand, score, combo.
- **Hint** — highlights one legal placement for an available piece (does not auto-place).
- **Daily Challenge** — date-based target score; progress and completion saved locally per day.
- **Achievements** — tracked from real gameplay events, with unlock notifications.
- **Local records** — offline score history (clearly labeled; no fake online ranks).
- Premium line-clear beams and controlled particles (existing, retained).
- Static placement previews during drag (no pulse flicker).

## Online leaderboard

Not connected. The game is offline-first. A future backend would need:

- `POST /scores` — submit `{score, date, mode, clientId}` (server must validate)
- `GET /leaderboard?limit=50` — return ranked list

Never put API secrets in client code. See TEST_REPORT.md for details.

## Build notes

- Single HTML entry point; keep the `assets` folder next to it for the favicon/icon reference.
- Uses Pointer Events + touch-action controls suitable for Android WebView.
- localStorage keys: `bp_best`, `bp_settings`, `bp_save`, `bp_daily`, `bp_achieve`, `bp_history`.
