'use strict';
const ColorStudio = (() => {
  const sections=['Basic Correction','Creative','Curves','Color Wheels & Match','HSL Secondary','Vignette'];
  const subtitles=['التصحيح الأساسي','اللوك والشكل الفني','المنحنيات','العجلات ومطابقة الشوتات','عزل لون وتعديله','أطراف الصورة'];
  const sessions=new WeakMap();
  let previousTap=null;
  document.addEventListener('pointerdown',e=>{
    if(!previousTap?.target.contains(e.target))previousTap=null;
  },true);
  function doubleTapReset(target,reset){
    let down=null;
    target.style.touchAction=target.matches('.tint-wheel,.curve-graph')?'none':'manipulation';
    target.addEventListener('pointerdown',e=>{
      down=e.isPrimary && e.button===0 ? {id:e.pointerId,x:e.clientX,y:e.clientY,time:e.timeStamp}:null;
      if(!down)previousTap=null;
    });
    const cancel=()=>{down=null;previousTap=null;};
    target.addEventListener('pointercancel',cancel);
    target.addEventListener('pointermove',e=>{
      if(down && Math.hypot(e.clientX-down.x,e.clientY-down.y)>10)cancel();
    });
    target.addEventListener('pointerup',e=>{
      if(!down || e.pointerId!==down.id || e.timeStamp-down.time>300 ||
         Math.hypot(e.clientX-down.x,e.clientY-down.y)>10){cancel();return;}
      down=null;
      if(previousTap?.target===target && previousTap.type===e.pointerType &&
         e.timeStamp-previousTap.time<360 && Math.hypot(e.clientX-previousTap.x,e.clientY-previousTap.y)<24){
        previousTap=null;reset();
      }else previousTap={target,type:e.pointerType,x:e.clientX,y:e.clientY,time:e.timeStamp};
    });
  }
  function el(tag,parent,text,cls){
    const node=document.createElement(tag);
    if(text!==undefined)node.textContent=text;
    if(cls)node.className=cls;
    if(parent)parent.append(node);
    return node;
  }
  function action(parent,label,fn){const b=el('button',parent,label);b.type='button';b.onclick=fn;return b;}
  function makeFrame(reference){
    const c=document.createElement('canvas');c.width=160;c.height=90;
    const ctx=c.getContext('2d'),sky=ctx.createLinearGradient(0,0,0,90);
    sky.addColorStop(0,reference?'#8e6e93':'#3b6b92');sky.addColorStop(.66,reference?'#ffc895':'#dfd6ae');sky.addColorStop(1,'#727c73');
    ctx.fillStyle=sky;ctx.fillRect(0,0,160,90);
    ctx.fillStyle=reference?'#ffe6be':'#f5e8c4';ctx.beginPath();ctx.arc(112,29,10,0,2*Math.PI);ctx.fill();
    for(let j=0;j<3;j++){
      ctx.fillStyle=(reference?['#a58691','#856269','#4f424c']:['#83979d','#567b80','#294b52'])[j];
      ctx.beginPath();ctx.moveTo(0,90);
      for(let x=0;x<=160;x++)ctx.lineTo(x,47+j*12+9*Math.sin(x/22+j)+5*Math.cos(x/9+j));
      ctx.lineTo(160,90);ctx.fill();
    }
    ['#242526','#888888','#efefef','#d06955','#d8b457','#50896e','#507aac'].forEach((s,i)=>{ctx.fillStyle=s;ctx.fillRect(7+i*8,80,8,4);});
    return ctx.getImageData(0,0,160,90);
  }
  function picker(parent,title,accept,callback){
    const label=el('label',parent,undefined,'pick-file');el('span',label,title);
    const input=el('input',label);input.type='file';input.accept=accept;
    input.onchange=async()=>{try{if(input.files[0])await callback(input.files[0]);}catch(e){toast(e.message||'تعذّر فتح الملف');}input.value='';};
  }
  async function imageFrame(file){
    const url=URL.createObjectURL(file);
    try{const img=new Image();img.src=url;await img.decode();const c=document.createElement('canvas');
      c.width=160;c.height=Math.max(1,Math.min(160,Math.round(160*img.height/img.width)));
      const ctx=c.getContext('2d');ctx.drawImage(img,0,0,c.width,c.height);return ctx.getImageData(0,0,c.width,c.height);
    }finally{URL.revokeObjectURL(url);}
  }
  const means=f=>{const m=[0,0,0];for(let i=0;i<f.data.length;i+=4)for(let j=0;j<3;j++)m[j]+=f.data[i+j]/255;return m.map(x=>x/(f.width*f.height));};
  function open(tab){
    const st=tab.studio ||= Grade.fresh(tab);
    const neutral=Grade.fresh({});
    const sliderDefaults=new Map(['basic','creative','hsl','vignette'].map(key=>[st[key],neutral[key]]));
    for(const key of ['h','s','l'])sliderDefaults.set(st.hsl[key],neutral.hsl[key]);
    if(!sessions.has(tab))sessions.set(tab,{frame:makeFrame(false),reference:makeFrame(true),curve:'Master',selected:-1});
    const session=sessions.get(tab), section=st.section;
    const root=el('div',$('#content'),undefined,'studio');
    const tabs=el('div',root,undefined,'studio-tabs');
    for(const name of sections){const b=action(tabs,name,()=>{st.section=name;save();render();});b.classList.toggle('chosen',section===name);}
    const layout=el('div',root,undefined,'studio-layout');
    const tool=el('section',layout,undefined,'studio-tools'), monitor=el('aside',layout,undefined,'studio-monitor');
    el('h2',tool,subtitles[sections.indexOf(section)]);
    el('h3',monitor,'معاينة محلية');
    const screens=el('div',monitor,undefined,'screens');
    const still=el('canvas',screens);still.setAttribute('aria-label','فريم التجربة الحالي');
    if(section===sections[3]&&st.match.comparison){
      const ref=el('canvas',screens);ref.width=session.reference.width;ref.height=session.reference.height;ref.getContext('2d').putImageData(session.reference,0,0);
      el('small',monitor,'الشوت الحالي ثم الفريم المرجعي');
    }
    const prompt=el('p',monitor,'اضبط اللون على فريم التجربة أو اختار صورة من جهازك.','studio-hint');
    picker(monitor,'اختيار فريم','image/*',async file=>{session.frame=await imageFrame(file);draw();});
    let raf=0, pick=null;
    function draw(){
      if(!root.isConnected)return;
      const f=session.frame;still.width=f.width;still.height=f.height;
      const ctx=still.getContext('2d');const img=ctx.createImageData(f.width,f.height);
      img.data.set(Grade.process(f,tab,section===sections[4]));ctx.putImageData(img,0,0);
    }
    function preview(){if(!raf)raf=requestAnimationFrame(()=>{raf=0;draw();});}
    function commit(path,value){save();emit('lumetri.set',{section,path,value});preview();}
    function rerender(){save();render();}
    function eyedrop(parent,label,fn){
      action(parent,label,()=>{pick=fn;prompt.textContent='اضغط على اللون المطلوب في فريم المعاينة';still.classList.add('sampling');still.scrollIntoView({block:'nearest'});});
    }
    still.onclick=e=>{
      if(!pick)return;
      const r=still.getBoundingClientRect(),f=session.frame;
      const x=Grade.clamp(Math.floor((e.clientX-r.left)/r.width*f.width),0,f.width-1),y=Grade.clamp(Math.floor((e.clientY-r.top)/r.height*f.height),0,f.height-1);
      const stage=section===sections[4]?'key':section===sections[2]?'curves':null;
      const source=stage?Grade.process(f,tab,false,stage):f.data;
      const rgb=[0,1,2].map(j=>source[(y*f.width+x)*4+j]/255);
      const fn=pick;pick=null;fn(rgb,{x:x/f.width,y:y/f.height});rerender();
    };
    function group(title){const g=el('fieldset',tool);el('legend',g,title);return g;}
    function slider(parent,obj,key,title,min=-100,max=100,step=1){
      const label=el('label',parent,undefined,'studio-slider');el('span',label,title);
      const val=el('output',label,String(obj[key]));const input=el('input',label);
      Object.assign(input,{type:'range',min,max,step,value:obj[key]});input.setAttribute('aria-label',title);
      input.oninput=()=>{obj[key]=+input.value;val.textContent=input.value;preview();};
      input.onchange=()=>commit(key,obj[key]);
      doubleTapReset(label,()=>{
        input.value=sliderDefaults.get(obj)?.[key]??0;
        input.oninput();input.onchange();
      });
      return input;
    }
    function select(parent,title,options,value,onChange){
      const label=el('label',parent,title,'studio-select'),s=el('select',label);
      options.forEach(v=>s.add(new Option(v,v)));s.value=value;s.onchange=()=>onChange(s.value);return s;
    }
    function toggle(parent,obj,key,title){
      const label=el('label',parent,undefined,'studio-toggle'),i=el('input',label);i.type='checkbox';i.checked=obj[key];
      el('span',label,title);i.onchange=()=>{obj[key]=i.checked;commit(key,i.checked);rerender();};
    }
    function chooseLut(g,obj,key){
      const names=['None',...(key==='look'?['Amber','Cool','Mono']:[]),...Object.keys(st.luts)];
      const choose=name=>{obj[key]=name;commit(key,name);rerender();};
      select(g,key==='look'?'Look':'Input LUT',names,obj[key],choose);
      if(key==='look'){const bar=el('div',g,undefined,'studio-row');
        action(bar,'‹ السابق',()=>choose(names[(names.indexOf(obj[key])+names.length-1)%names.length]));
        action(bar,'التالي ›',()=>choose(names[(names.indexOf(obj[key])+1)%names.length]));}
      picker(g,'تحميل ملف .cube','.cube',async file=>{
        if(file.size>16e6)throw Error('أقصى حجم للملف 16 MB');
        const lut=Grade.parseCube(await file.text()),name='LUT · '+file.name;
        st.luts[name]=lut;commit('lut.import',{name,lut});choose(name);
      });
    }
    function tintWheel(g,obj,key,title,withLuma,main=false){
      const card=el('div',g,undefined,'tint-card'),v=obj[key];
      el('h4',card,title);const dial=el('div',card,undefined,'tint-wheel'),puck=el('i',dial);
      dial.tabIndex=0;dial.setAttribute('aria-label',title);dial.setAttribute('role','group');
      const position=()=>{puck.style.left=(50+v.x*50)+'%';puck.style.top=(50+v.y*50)+'%';};
      let gesture='';
      const sendWheel=(axis,final)=>{
        const drag={id:gesture||uid(),axis,final};
        const payload=main?{control:key,...v,drag}:{section,path:key,value:{...v},drag};
        if(connected)queueWheel(tab.id,section,key,main?'color':'lumetri.set',payload);
        if(final){gesture='';save();preview();}
      };
      const finish=()=>sendWheel('tint',true);
      const move=e=>{const r=dial.getBoundingClientRect();let x=(e.clientX-r.left)/r.width*2-1,y=(e.clientY-r.top)/r.height*2-1;
        if(dial._drag){const start=dial._drag;x=start.x+(e.clientX-start.px)*2/r.width*tab.sensitivity;y=start.y+(e.clientY-start.py)*2/r.height*tab.sensitivity;}
        const d=Math.max(1,Math.hypot(x,y));v.x=x/d;v.y=y/d;position();preview();};
      dial.onpointerdown=e=>{if(!e.isPrimary)return;gesture=uid();dial.setPointerCapture(e.pointerId);if(tab.sensitivity===1)move(e);dial._drag={x:v.x,y:v.y,px:e.clientX,py:e.clientY};};
      dial.onpointermove=e=>{
        if(!dial.hasPointerCapture(e.pointerId))return;
        move(e);
        sendWheel('tint',false);
      };
      dial.onpointerup=e=>{if(!dial.hasPointerCapture(e.pointerId))return;move(e);dial._drag=null;finish();};dial.onpointercancel=()=>{if(dial._drag){dial._drag=null;finish();}};
      dial.onkeydown=e=>{const d={ArrowLeft:[-.02,0],ArrowRight:[.02,0],ArrowUp:[0,-.02],ArrowDown:[0,.02]}[e.key];if(!d)return;e.preventDefault();
        const x=v.x+d[0],y=v.y+d[1],n=Math.max(1,Math.hypot(x,y));v.x=x/n;v.y=y/n;position();finish();};
      position();if(withLuma){
        const i=slider(card,v,'luma','Luminance'),update=i.oninput;
        i.oninput=()=>{update();if(!gesture)gesture=uid();sendWheel('luma',false);};
        i.onchange=()=>sendWheel('luma',true);
      }
      const center=()=>{v.x=v.y=0;position();finish();};
      doubleTapReset(dial,center);
      action(card,'توسيط',center);
    }
    function reset(key){action(tool,'Reset · استعادة إعدادات القسم',()=>{st[key]=Grade.fresh({})[key];commit('reset',st[key]);rerender();});}
    function basic(){
      const a=st.basic;
      chooseLut(group('Input LUT'),a,'lut');
      const wb=group('White Balance');
      eyedrop(wb,'قطّارة توازن الأبيض',(p,point)=>{const [r,g,b]=p;a.temperature=Grade.clamp(Math.round((b-r)*250),-100,100);a.tint=Grade.clamp(Math.round((g-(r+b)/2)*300),-100,100);emit('lumetri.sample',{section,tool:'whiteBalance',point,rgb:p,source:'local-frame'});commit('whiteBalance',{temperature:a.temperature,tint:a.tint});});
      slider(wb,a,'temperature','Temperature');slider(wb,a,'tint','Tint');
      const g=group('Tone');slider(g,a,'exposure','Exposure',-5,5,.05);
      for(const key of ['Contrast','Highlights','Shadows','Whites','Blacks'])slider(g,a,key.toLowerCase(),key);
      slider(g,a,'saturation','Saturation',0,200);
      action(g,'Auto · تصحيح تلقائي',()=>{
        const f=session.frame,levels=[];
        for(let i=0;i<f.data.length;i+=4)levels.push(Grade.luma([f.data[i],f.data[i+1],f.data[i+2]])/255);
        levels.sort((x,y)=>x-y);
        const percentile=q=>levels[Math.floor((levels.length-1)*q)];
        const dark=percentile(.05),mid=percentile(.5),light=percentile(.95);
        a.exposure=Grade.clamp(Math.round(Math.log2(.45/Math.max(.01,mid))*20)/20,-5,5);
        a.contrast=Grade.clamp(Math.round((.8-(light-dark))*40),-25,25);
        a.blacks=Grade.clamp(Math.round((.04-dark)*100),-30,30);
        a.whites=Grade.clamp(Math.round((.96-light)*100),-30,30);
        commit('auto',{exposure:a.exposure,contrast:a.contrast,blacks:a.blacks,whites:a.whites});rerender();
      });
      reset('basic');
    }
    function creative(){
      const c=st.creative,g=group('Look Preview');chooseLut(g,c,'look');slider(g,c,'intensity','Intensity',0,200);
      const style=group('Adjustments');slider(style,c,'fadedFilm','Faded Film',0,100);slider(style,c,'sharpen','Sharpen',0,100);
      slider(style,c,'vibrance','Vibrance');slider(style,c,'saturation','Saturation',0,200);
      const t=group('Tint');tintWheel(t,c,'shadowTint','Shadow Tint',false);tintWheel(t,c,'highlightTint','Highlight Tint',false);slider(t,c,'tintBalance','Tint Balance');reset('creative');
    }
    function curves(){
      const g=group('RGB / Hue Saturation Curves'),name=session.curve,pts=st.curves[name];
      select(g,'المنحنى',Grade.channels,name,value=>{session.curve=value;session.selected=-1;render();});
      const graph=el('canvas',g,undefined,'curve-graph');graph.width=620;graph.height=240;
      const ctx=graph.getContext('2d');
      function paint(){
        const w=graph.width,h=graph.height;ctx.clearRect(0,0,w,h);
        ctx.strokeStyle='#31444d';ctx.lineWidth=1;
        for(let i=0;i<=8;i++){ctx.beginPath();ctx.moveTo(w*i/8,0);ctx.lineTo(w*i/8,h);ctx.moveTo(0,h*i/8);ctx.lineTo(w,h*i/8);ctx.stroke();}
        ctx.lineWidth=3;ctx.strokeStyle=({Red:'#ff6868',Green:'#76ebad',Blue:'#7db8ff',Master:'#edf2f3'})[name]||'#65e0cf';
        ctx.beginPath();pts.forEach(([x,y],i)=>ctx[i?'lineTo':'moveTo'](x*w,(1-y)*h));ctx.stroke();
        pts.forEach(([x,y],i)=>{ctx.fillStyle=i===session.selected?'#ffda83':'#e9f4f5';ctx.beginPath();ctx.arc(x*w,(1-y)*h,6,0,7);ctx.fill();});
      }
      const coords=e=>{const r=graph.getBoundingClientRect();return [Grade.clamp((e.clientX-r.left)/r.width),Grade.clamp(1-(e.clientY-r.top)/r.height)];};
      graph.onpointerdown=e=>{const [x,y]=coords(e);let idx=pts.findIndex(p=>Math.abs(p[0]-x)<.035&&Math.abs(p[1]-y)<.1);
        if(idx<0){idx=pts.findIndex(p=>Math.abs(p[0]-x)<.01);if(idx<0){idx=pts.findIndex(p=>p[0]>x);pts.splice(idx,0,[x,y]);}}
        session.selected=idx;graph.setPointerCapture(e.pointerId);paint();preview();};
      graph.onpointermove=e=>{if(!graph.hasPointerCapture(e.pointerId))return;const [x,y]=coords(e),i=session.selected;
        pts[i]=[i===0?0:i===pts.length-1?1:Grade.clamp(x,pts[i-1][0]+.001,pts[i+1][0]-.001),y];paint();preview();};
      graph.onpointerup=graph.onpointercancel=()=>commit(name,pts);
      el('p',g,'المس لإضافة نقطة واسحبها للتعديل.','studio-hint');paint();
      action(g,'حذف النقطة',()=>{const i=session.selected;if(i<=0||i>=pts.length-1)return toast('اختار نقطة داخلية');pts.splice(i,1);session.selected=-1;commit(name,pts);paint();});
      const resetCurve=()=>{pts.splice(0,pts.length,...Grade.neutralCurve(name));session.selected=-1;commit(name,pts);paint();};
      doubleTapReset(graph,resetCurve);
      action(g,'إعادة ضبط المنحنى',resetCurve);
      if(Grade.channels.indexOf(name)>3)eyedrop(g,'قطّارة نطاق اللون',p=>{
        const [h,s,l]=Grade.hsl(p),x=name==='Luma vs Sat'?l:name==='Sat vs Sat'?s:h;
        const added=[x-.07,x,x+.07].map(v=>Grade.clamp(v)).filter(v=>pts.every(([old])=>Math.abs(old-v)>.002)).map(v=>[v,Grade.curve(pts,v)]);
        pts.push(...added);pts.sort((a,b)=>a[0]-b[0]);commit(name,pts);
      });
    }
    function wheels(){
      const g=group('Color Wheels');g.classList.add('wheel-group');
      for(const n of Grade.groups)tintWheel(g,tab.wheels,n,n[0].toUpperCase()+n.slice(1),true,true);
      select(tool,'حساسية السحب',['1','0.5','0.25'],String(tab.sensitivity),v=>{tab.sensitivity=Number(v);save();});
      const m=group('Shot Match');toggle(m,st.match,'comparison','Comparison View');toggle(m,st.match,'face','Face Detection · عند الربط بـ Premiere');
      picker(m,'اختيار فريم مرجعي','image/*',async file=>{session.reference=await imageFrame(file);st.match.comparison=true;rerender();});
      action(m,'Apply Match',()=>{const a=means(session.frame),b=means(session.reference);st.match.gain=b.map((v,i)=>Grade.clamp(v/Math.max(.02,a[i]),.25,4));
        emit('lumetri.action',{section,action:'applyMatch',faceDetection:st.match.face});save();preview();toast('تم تقريب متوسطات اللون في المعاينة المحلية');});
      action(m,'Reset',()=>{for(const key of Grade.groups)tab.wheels[key]=Grade.wheel();st.match=Grade.fresh({}).match;emit('color.reset',{});commit('resetMatch',st.match);rerender();});
    }
    function secondary(){
      const k=st.hsl,g=group('Key');
      for(const [op,title] of [['set','Set Color'],['add','+ Add'],['remove','− Remove']])eyedrop(g,title,p=>{const range=Grade.sampleKey(p);
        if(op==='set'){Object.assign(k,range);k.extras=[];}else k.extras.push({...range,add:op==='add'});commit('key',{h:k.h,s:k.s,l:k.l,extras:k.extras});});
      select(g,'Color Presets',['Custom','Red','Yellow','Green','Cyan','Blue','Magenta'],'Custom',v=>{const index=['Red','Yellow','Green','Cyan','Blue','Magenta'].indexOf(v);if(index<0)return;k.h=[-35,-20,20,35].map(n=>n+index*60);k.s=[10,20,100,100];k.l=[0,5,95,100];k.extras=[];commit('key',{h:k.h,s:k.s,l:k.l,extras:[]});rerender();});
      for(const [key,name] of [['h','Hue'],['s','Saturation'],['l','Lightness']]){
        const details=el('details',g);const summary=el('summary',details,name+' · Range / Falloff');
        const r=k[key],inputs=[];
        ['بداية التدرّج','بداية التحديد','نهاية التحديد','نهاية التدرّج'].forEach((label,i)=>{
          const field=slider(details,r,i,label,key==='h'?-180:0,key==='h'?540:100);
          inputs.push(field);field.oninput=()=>{r[i]=Grade.clamp(+field.value,i?r[i-1]:Number(field.min),i<3?r[i+1]:Number(field.max));field.value=r[i];field.previousSibling.textContent=r[i];preview();};
          field.onchange=()=>commit(key,r);
        });
      }
      select(g,'عرض الماسك',['Off','Color/Gray','Color/Black','White/Black'],k.mask,v=>{k.mask=v;commit('mask',v);});toggle(g,k,'invert','Invert');
      const refine=group('Refine');slider(refine,k,'denoise','Denoise',0,100);slider(refine,k,'blur','Blur',0,100);
      const correction=group('Correction');select(correction,'عجلات التصحيح',['Single','Three'],k.mode,v=>{k.mode=v;commit('mode',v);rerender();});
      for(const n of k.mode==='Single'?['master']:Grade.groups)tintWheel(correction,k,n,n,true);
      for(const key of ['Temperature','Tint','Contrast','Sharpen','Saturation'])slider(correction,k,key.toLowerCase(),key,['Sharpen','Saturation'].includes(key)?0:-100,key==='Saturation'?200:100);
      reset('hsl');
    }
    function vignette(){
      const g=group('Vignette'),v=st.vignette;
      slider(g,v,'amount','Amount',-3,3,.1);slider(g,v,'midpoint','Midpoint',0,100);
      slider(g,v,'roundness','Roundness');slider(g,v,'feather','Feather',0,100);reset('vignette');
    }
    [basic,creative,curves,wheels,secondary,vignette][Math.max(0,sections.indexOf(section))]();draw();
  }
  return {open};
})();

