CONDOR FIELD MANAGER — PROJET ANDROID

Ce dossier contient le projet Android Studio qui enveloppe la version HTML de
Condor Field Manager dans une application Android WebView.

POUR GENERER LE FICHIER APK :
1. Installer Android Studio sur un ordinateur.
2. Décompresser le dossier CondorFieldManager_Android.
3. Dans Android Studio : File > Open, puis choisir ce dossier.
4. Attendre la synchronisation Gradle et l'installation des composants Android
   demandés (Android SDK 35 / Gradle).
5. Choisir Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio affichera un lien vers l'APK généré.
7. Copier l'APK sur le téléphone Android et l'installer. Autoriser si demandé
   l'installation depuis cette source.

NOTES :
- Nom de l'application : Condor Field Manager
- Identifiant : com.condor.fieldmanager
- Android minimum : 6.0 (API 23)
- Les données du site sont stockées dans le stockage local du WebView sur
  l'appareil. Désinstaller l'application peut supprimer ces données.
- Les cartes Leaflet nécessitent une connexion Internet pour charger les
  bibliothèques et les fonds de carte.
- La permission de localisation est prévue pour les fonctions qui l'utilisent.
- Ceci est le projet source Android prêt à être compilé dans Android Studio,
  pas encore un APK compilé/signé.
