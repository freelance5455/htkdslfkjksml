DZ Legends - مشروع Android تجريبي

هذا مشروع Android Studio يغلّف نسخة HTML الحالية داخل تطبيق WebView أفقي. ليس ملف APK جاهزًا.

طريقة بناء APK:
1) فك الضغط عن DZ_Legends_Android_Project.zip.
2) افتح المجلد DZ_Legends_Android في Android Studio.
3) وافق على تنزيل Gradle/Android SDK إذا طُلب منك.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد APK غالبًا داخل app/build/outputs/apk/debug/app-debug.apk.

التحديثات: عند تعديل اللعبة، استبدل app/src/main/assets/index.html بالنسخة الجديدة ثم أعد بناء APK. للتحديث فوق نسخة مثبتة، حافظ على applicationId نفسه ووقّع الإصدارات بمفتاح التوقيع نفسه.

ملاحظة: هذه نسخة تجريبية محلية، ولا تحتوي على خوادم أو لعب أونلاين حقيقي.
