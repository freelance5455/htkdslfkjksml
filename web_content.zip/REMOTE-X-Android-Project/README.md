# REMOTE-X Android project (UI prototype)

This is an Android Studio project for a local controller-interface prototype.

## Included
- Dark neon-green REMOTE-X interface
- Indian mobile-number entry screen
- Four-digit OTP UI screen (demonstration only)
- Multilingual custom message editor (500-character limit)
- Local terminal preview with speed selector and Stop control

## Not included
- No SMS is sent and no phone number is verified.
- No backend, SMS provider, remote browser session, or live command channel is configured.
- It does not control, lock, trap, shut down, or modify another device.
- The target phone would need to open a session and explicitly authorize any browser-based simulation.

## Build
1. Open this folder in Android Studio.
2. Install Android SDK Platform 35 and a compatible Android Gradle Plugin toolchain.
3. Let Gradle sync.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be created under `app/build/outputs/apk/debug/`.

This environment did not contain the Android SDK, so no APK has been compiled here.
