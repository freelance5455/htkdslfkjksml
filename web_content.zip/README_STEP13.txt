Unser Vorrat – STEP 13 Produktdetails

Neu:
- Marke und Packungsgröße im Artikel-Editor
- Produktkarten zeigen Marke/Packungsgröße kompakt
- EAN-Produktdaten übernehmen Marke und Packungsgröße
- Produktkatalog speichert Packungsgröße als quantity
- Suche berücksichtigt Marke und Packungsgröße

WICHTIG: Einmal migration_artikeldetails.sql im Supabase SQL Editor ausführen, bevor neue Marke/Packungsgröße gespeichert werden.
