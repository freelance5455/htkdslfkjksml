PERSONAL COMMAND CENTER - Offline Tracker

1. Download index.html to your Android phone.
2. Open it using your browser (Chrome recommended). If it opens in a preview/file viewer, choose Open with Chrome.
3. Tracker data is stored locally in the browser on that device.
4. Use Export backup regularly to save a JSON backup. Import backup restores it.

Features:
- Bank, Gold, Silver savings balances
- Savings deposits and expense log
- Goal progress and daily target setting
- Daily habit/training checklist
- XP/levels and achievements
- Motivational quotes
- Backup export/import

Note: This is a local web app prototype, not a signed APK. It does not connect to bank or savings apps.
