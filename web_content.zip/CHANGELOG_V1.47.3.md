# Carreira de Craque v1.47.3 — Ajustes de camisas

- Palmeiras: camisa titular verde lisa, sem grafismos diagonais adicionais.
- São Paulo: camisa com faixa horizontal vermelha em cima, branca no meio e preta embaixo, no estilo solicitado para o Santa Cruz.
- Flamengo: listras horizontais rubro-negras mais grossas na camisa titular, tanto na prévia do uniforme quanto na arte da camisa do jogador.
- Cache do PWA atualizado para carregar a nova versão.
