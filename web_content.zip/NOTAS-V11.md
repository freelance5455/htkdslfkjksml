# Notas v11 — Mundo Estável

## Correção principal
A cena tinha um plano global de chão de 10.000 × 10.000 unidades ao mesmo tempo que os tiles de terreno eram desenhados em y=0,004. Essas superfícies quase coplanares podiam causar z-fighting e oscilação de cores no WebView. O plano global foi removido; o terreno é renderizado pelos tiles dos setores carregados.

## Estabilidade visual
- Iluminação fixa e neutra; removida a variação abrupta de intensidade a cada ciclo de atualização de clima.
- Sombras WebGL em tempo real desativadas para Android, evitando artefatos de shadow-map e reduzindo custo.
- Tons de bioma aproximados para reduzir contraste duro entre tiles e overlays climáticos atenuados.
- Cache do Service Worker renovado na v11.

## Construções/colisões
- Casas ampliadas e visualmente mais detalhadas, com footprint sólido guardado na entidade.
- Resolver `canWalkTo`/`moveWithCollision` impede jogador, NPCs, monstros e companheiros de atravessarem fachadas/árvores em seus movimentos comuns, permitindo deslizar pela parede.
- Assentamentos de setores geram de 2 a 4 casas em vez de uma casa isolada com tanta frequência.

## Modelos
- NPCs recebem escala de corpo determinística derivada do nome, posição, raça e papel (crianças menores; anões/ferais/orcs com proporções distintas).
- Ombreiras/equipamento assimétricos evitam a aparência de cópia exata.
- Monstros têm escalas e proporções definidas por arquétipo; coelhos e cervos variam de tamanho.
