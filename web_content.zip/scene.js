window.sceneData = {
	"objects": [
		{
			"behavior": "none",
			"color": "0x85ae3f",
			"name": "Sphere_0",
			"position": [
				-1.46936249732971,
				1.5,
				0.446288734674454
			],
			"rotation": [
				0.0,
				0.0,
				0.0
			],
			"scale": [
				1.0,
				1.0,
				1.0
			],
			"shape": "sphere"
		},
		{
			"behavior": "none",
			"color": "0xb286e6",
			"name": "Sphere_1",
			"position": [
				-0.731353938579559,
				1.5,
				-0.639249622821808
			],
			"rotation": [
				0.0,
				0.0,
				0.0
			],
			"scale": [
				1.0,
				1.0,
				1.0
			],
			"shape": "sphere"
		},
		{
			"behavior": "none",
			"color": "0xc24152",
			"name": "Cylinder_2",
			"position": [
				1.38813042640686,
				1.5,
				-1.33737993240356
			],
			"rotation": [
				0.0,
				0.0,
				0.0
			],
			"scale": [
				1.0,
				1.0,
				1.0
			],
			"shape": "cylinder"
		},
		{
			"behavior": "none",
			"color": "0xd5d344",
			"name": "Cylinder_3",
			"position": [
				1.39841198921204,
				1.5,
				1.96054589748383
			],
			"rotation": [
				0.0,
				0.0,
				0.0
			],
			"scale": [
				1.0,
				1.0,
				1.0
			],
			"shape": "cylinder"
		},
		{
			"behavior": "none",
			"color": "0x46daf1",
			"name": "Cube_4",
			"position": [
				-5.74919605255127,
				-4.5,
				2.09233260154724
			],
			"rotation": [
				0.0,
				0.0,
				0.0
			],
			"scale": [
				9.99999523162842,
				9.99999523162842,
				9.99999523162842
			],
			"shape": "cube"
		}
	]
};