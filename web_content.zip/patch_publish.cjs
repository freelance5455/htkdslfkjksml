const fs = require('fs');
let code = fs.readFileSync('src/components/OwnerUpdateView.tsx', 'utf8');

const targetPublishModal = `{/* Publish Modal */}
      {showPublishModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-purple-500/40 rounded-3xl p-6 max-w-md w-full shadow-2xl relative text-left animate-fadeIn">
            <button onClick={() => setShowPublishModal(false)} className="absolute top-4 right-4 text-slate-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
            <div className="space-y-4">
              <div className="flex items-center space-x-3 border-b border-slate-700 pb-4">
                <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center text-purple-400 border border-purple-500/30">
                  <Globe className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-purple-100">Publish Application</h3>
                  <p className="text-[10px] text-slate-400">Deploy to global app stores or custom domain.</p>
                </div>
              </div>
              
              <div className="space-y-4 pt-2">
                <div>
                  <label className="text-xs font-bold text-slate-300 mb-1.5 block">Select App Store</label>
                  <select className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-sm text-white focus:border-purple-500 outline-none">
                    <option>Google Play Store</option>
                    <option>PalmStore</option>
                    <option>Apple App Store</option>
                    <option>Amazon Appstore</option>
                    <option>Samsung Galaxy Store</option>
                  </select>
                </div>

                <div className="text-center text-xs text-slate-500 font-bold uppercase tracking-wider">— OR —</div>

                <div>
                  <label className="text-xs font-bold text-slate-300 mb-1.5 block">Preferred Website URL</label>
                  <input type="text" placeholder="e.g. juhnkrixmusika.com" className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-sm text-white focus:border-purple-500 outline-none placeholder-slate-600" />
                </div>

                <button onClick={() => { setShowPublishModal(false); showToast('App is being published successfully to the selected destination!'); }} className="w-full p-3.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-sm font-bold flex items-center justify-center space-x-2 mt-4 transition-all">
                  <Globe className="w-5 h-5" />
                  <span>Publish App Now</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}`;

const replacePublishModal = `{/* Publish Modal (Full Page) */}
      {showPublishModal && (
        <div className="fixed inset-0 z-[200] flex flex-col bg-slate-950 animate-fadeIn overflow-y-auto">
          <div className="w-full bg-slate-900 border-b border-amber-500/20 p-6 flex justify-between items-center sticky top-0 z-10 shadow-2xl">
            <div className="flex items-center space-x-3 text-amber-100">
              <Globe className="w-8 h-8 text-purple-400" />
              <h2 className="text-2xl font-bold font-serif">Global Publishing Terminal</h2>
            </div>
            <button onClick={() => setShowPublishModal(false)} className="px-5 py-2.5 rounded-full bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center space-x-2 border border-slate-600 transition-all shadow-xl">
              <X className="w-4 h-4" />
              <span>Close Terminal</span>
            </button>
          </div>
          
          <div className="flex-1 max-w-5xl w-full mx-auto p-6 md:p-12 space-y-8 relative">
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="text-center space-y-4 mb-12 relative z-10">
              <h3 className="text-3xl md:text-5xl font-extrabold text-amber-100 tracking-tight">Select Publishing Destination</h3>
              <p className="text-slate-400 text-sm md:text-base max-w-2xl mx-auto">Deploy JUHNKRIX MUSIKA to the world. Choose an automated publishing pipeline below to distribute your application to believers globally.</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
              <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-amber-500/30 rounded-3xl p-8 space-y-6 shadow-2xl hover:scale-105 transition-all group">
                <div className="w-16 h-16 bg-blue-500/20 rounded-2xl flex items-center justify-center text-blue-400 border border-blue-500/30 group-hover:bg-blue-500 group-hover:text-white transition-all">
                  <MonitorSmartphone className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-white mb-2">Google Play Store</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">Automatically generate a signed Android App Bundle (.AAB), run verification checks, and deploy to your Google Play Developer Console.</p>
                </div>
                <button onClick={() => { setShowPublishModal(false); showToast('Connecting to Google Play Console API...'); window.open("https://play.google.com/console", "_blank"); }} className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-bold flex items-center justify-center space-x-2 transition-all">
                  <span>Google PLAY STORE publishing links</span>
                </button>
              </div>
              
              <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-amber-500/30 rounded-3xl p-8 space-y-6 shadow-2xl hover:scale-105 transition-all group">
                <div className="w-16 h-16 bg-emerald-500/20 rounded-2xl flex items-center justify-center text-emerald-400 border border-emerald-500/30 group-hover:bg-emerald-500 group-hover:text-white transition-all">
                  <Globe className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-white mb-2">Palmstore / Third-Party</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">Compile a standalone universal APK optimized for Palmstore, Aptoide, and direct device side-loading across global regions.</p>
                </div>
                <button onClick={() => { setShowPublishModal(false); showToast('Connecting to Palmstore Portal...'); window.open("https://af.palmstore.com", "_blank"); }} className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-sm font-bold flex items-center justify-center space-x-2 transition-all">
                  <span>PALMSTORE publishing links</span>
                </button>
              </div>
              
              <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-amber-500/30 rounded-3xl p-8 space-y-6 shadow-2xl hover:scale-105 transition-all group">
                <div className="w-16 h-16 bg-purple-500/20 rounded-2xl flex items-center justify-center text-purple-400 border border-purple-500/30 group-hover:bg-purple-500 group-hover:text-white transition-all">
                  <Code className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-white mb-2">Custom Website URL</h4>
                  <p className="text-xs text-slate-400 leading-relaxed mb-4">Deploy the Progressive Web App (PWA) directly to a domain of your choice. Enter the URL below to configure DNS routing.</p>
                  <input type="text" placeholder="https://your-domain.com" className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500" />
                </div>
                <button onClick={() => { setShowPublishModal(false); showToast('Deploying static PWA build to target server...'); }} className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-sm font-bold flex items-center justify-center space-x-2 transition-all">
                  <span>PUBLISH TO ANY WEBSITE URL OF YOUR CHOICE links</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}`;

if (code.includes(targetPublishModal)) {
  code = code.replace(targetPublishModal, replacePublishModal);
  console.log("Patched publish modal");
} else {
  console.log("Publish modal not found");
}

fs.writeFileSync('src/components/OwnerUpdateView.tsx', code);
