@echo off
curl -L -o www\three.min.js https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
echo OK
