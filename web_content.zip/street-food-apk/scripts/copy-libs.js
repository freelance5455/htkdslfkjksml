// Copia three.js y PeerJS a www/lib para que el juego funcione sin internet
const fs=require('fs'),path=require('path');
const copy=(from,to)=>{try{fs.mkdirSync(path.dirname(to),{recursive:true});fs.copyFileSync(from,to);console.log('✔',to)}catch(e){console.error('✘ No se pudo copiar',from,'→ ejecuta primero: npm install');process.exitCode=1}};
copy('node_modules/three/build/three.min.js','www/lib/three.min.js');
copy('node_modules/peerjs/dist/peerjs.min.js','www/lib/peerjs.min.js');

// Fuentes locales (Bungee, Baloo 2, Caveat) para que se vean igual sin internet
try{
  const specs=[['bungee','Bungee',[400]],['baloo-2','Baloo 2',[500,600,800]],['caveat','Caveat',[600]]];
  let css='';fs.mkdirSync('www/fonts',{recursive:true});
  for(const [pkg,fam,ws] of specs){const dir=`node_modules/@fontsource/${pkg}/files`;if(!fs.existsSync(dir))continue;
    for(const w of ws){const f=`${pkg}-latin-${w}-normal.woff2`;
      if(fs.existsSync(path.join(dir,f))){fs.copyFileSync(path.join(dir,f),path.join('www/fonts',f));css+=`@font-face{font-family:'${fam}';font-style:normal;font-weight:${w};font-display:swap;src:url(${f}) format('woff2')}\n`}}}
  fs.writeFileSync('www/fonts/fonts.css',css);console.log('✔ www/fonts/fonts.css');
}catch(e){console.warn('Fuentes locales omitidas:',e.message)}
