// Ajusta el proyecto Android generado: pantalla horizontal, pantalla completa e inmersivo
const fs=require('fs'),path=require('path');
const cfg=JSON.parse(fs.readFileSync('capacitor.config.json','utf8')),root='android/app/src/main';
if(!fs.existsSync(root)){console.error('Primero ejecuta: npx cap add android');process.exit(1)}
const mp=path.join(root,'AndroidManifest.xml');let m=fs.readFileSync(mp,'utf8');
// Localiza la <activity> principal (la que contiene .MainActivity; si no, la primera) y fuerza horizontal en ELLA
const tags=[...m.matchAll(/<activity\b[^>]*>/g)];
const tag=(tags.find(t=>/\.MainActivity|MainActivity/.test(t[0]))||tags[0]);
if(!tag){console.error('✘ No se encontró <activity> en AndroidManifest.xml');process.exit(1)}
let nt=tag[0];
if(/android:screenOrientation\s*=\s*"[^"]*"/.test(nt))nt=nt.replace(/android:screenOrientation\s*=\s*"[^"]*"/g,'android:screenOrientation="sensorLandscape"');
else nt=nt.replace(/^<activity/,'<activity\n            android:screenOrientation="sensorLandscape"');
if(!/android:hardwareAccelerated=/.test(nt))nt=nt.replace(/^<activity/,'<activity\n            android:hardwareAccelerated="true"');
m=m.slice(0,tag.index)+nt+m.slice(tag.index+tag[0].length);fs.writeFileSync(mp,m);
// Comprobación: si no quedó horizontal, la compilación falla en vez de producir un APK vertical
const chk=fs.readFileSync(mp,'utf8');
if(!/<activity\b[^>]*android:screenOrientation="sensorLandscape"/.test(chk)){console.error('✘ AndroidManifest: la orientación horizontal NO se aplicó');process.exit(1)}
console.log('✔ AndroidManifest: pantalla horizontal (sensorLandscape) en la actividad principal');
const sp=path.join(root,'res/values/styles.xml');
if(fs.existsSync(sp)){let s=fs.readFileSync(sp,'utf8');if(!s.includes('windowFullscreen')){s=s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/,'$1\n        <item name="android:windowFullscreen">true</item>\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>');fs.writeFileSync(sp,s);console.log('✔ styles.xml: pantalla completa')}}
const dir=path.join(root,'java',...cfg.appId.split('.'));fs.mkdirSync(dir,{recursive:true});
fs.writeFileSync(path.join(dir,'MainActivity.java'),`package ${cfg.appId};

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
  }

  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) {
      getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }
  }
}
`);console.log('✔ MainActivity: modo inmersivo');
