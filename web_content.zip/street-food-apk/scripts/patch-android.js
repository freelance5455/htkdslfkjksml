// Ajusta el proyecto Android generado: pantalla horizontal, pantalla completa e inmersivo
const fs=require('fs'),path=require('path');
const cfg=JSON.parse(fs.readFileSync('capacitor.config.json','utf8')),root='android/app/src/main';
if(!fs.existsSync(root)){console.error('Primero ejecuta: npx cap add android');process.exit(1)}
const mp=path.join(root,'AndroidManifest.xml');let m=fs.readFileSync(mp,'utf8');
if(!m.includes('screenOrientation')){m=m.replace('<activity','<activity\n            android:screenOrientation="sensorLandscape"\n            android:hardwareAccelerated="true"');fs.writeFileSync(mp,m);console.log('✔ AndroidManifest: pantalla horizontal')}
const sp=path.join(root,'res/values/styles.xml');
if(fs.existsSync(sp)){let s=fs.readFileSync(sp,'utf8');if(!s.includes('windowFullscreen')){s=s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/,'$1\n        <item name="android:windowFullscreen">true</item>\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>');fs.writeFileSync(sp,s);console.log('✔ styles.xml: pantalla completa')}}
const dir=path.join(root,'java',...cfg.appId.split('.'));fs.mkdirSync(dir,{recursive:true});
fs.writeFileSync(path.join(dir,'MainActivity.java'),`package ${cfg.appId};

import android.view.View;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) {
      getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }
  }
}
`);console.log('✔ MainActivity: modo inmersivo');
