# Ficha para Google Play (borrador para revisar)

**Nombre (máx. 30):** Street Food 3D
**Descripción corta (máx. 80):** Cocina, sirve y conduce tu food truck por la ciudad en 3D.

**Descripción larga:**
Monta tu puesto de comida callejera y conviértete en el mejor cocinero de la ciudad.
- Toma pedidos, corta, pela, cocina en la parrilla y fríe a mano.
- Contrata empleados que cortan, cocinan y fríen por ti.
- Conduce tu camión por la ciudad: universidad, centro financiero, estadio, playa y parque. Cada lugar cambia cuántos clientes llegan y cuánto pagan.
- Juega en cooperativo en línea con tus amigos.
- Crea tu cuenta o entra como invitado.

**Categoría sugerida:** Juegos → Simulación
**Etiquetas:** simulador, cocina, food truck, 3D, cooperativo
**Clasificación de contenido:** responde el cuestionario de Play Console; el juego no tiene violencia gráfica, compras ni anuncios (revisa tu versión final).

## Plantilla de política de privacidad (adáptala y publícala en una web)
*Street Food 3D* guarda tu partida y tu cuenta únicamente en tu dispositivo. No recopilamos datos personales ni mostramos anuncios.
El modo cooperativo en línea usa conexiones directas entre jugadores (WebRTC) y un servidor de señalización de PeerJS: para conectar, tu dirección IP puede ser visible para los otros jugadores de la sala y para ese servidor. No guardamos esa información.
Si borras los datos de la app o la desinstalas, tu partida se elimina.
Contacto: *(tu correo)*
