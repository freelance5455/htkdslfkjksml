// Ajustes para la app Android (Capacitor) y la versión instalada
(()=>{
const C=window.Capacitor,native=!!(C&&C.isNativePlatform&&C.isNativePlatform()),P=(C&&C.Plugins)||{};
// pantalla siempre encendida mientras juegas
const wl=async()=>{try{if(navigator.wakeLock)await navigator.wakeLock.request('screen')}catch(e){}};wl();document.addEventListener('visibilitychange',()=>{if(!document.hidden)wl()});
// horizontal cuando el navegador lo permita
const lockLand=()=>{try{if(screen.orientation&&screen.orientation.lock)screen.orientation.lock('landscape').catch(()=>{})}catch(e){}};
lockLand();['fullscreenchange','webkitfullscreenchange'].forEach(ev=>document.addEventListener(ev,lockLand));document.addEventListener('pointerdown',lockLand,{once:true});
if(!native)return;
if(P.SplashScreen)setTimeout(()=>P.SplashScreen.hide(),900);
if(P.StatusBar&&P.StatusBar.hide)P.StatusBar.hide().catch(()=>{});
// botón "atrás" de Android: pausa en el juego, sale desde el menú
if(P.App)P.App.addListener('backButton',()=>{
 try{if(state==='service'&&typeof pause==='function'){pause();return}if(state==='menu')P.App.exitApp()}catch(e){}});
// al salir de la app a segundo plano, pausa para no perder pedidos
document.addEventListener('visibilitychange',()=>{try{if(document.hidden&&state==='service'&&typeof pause==='function')pause()}catch(e){}});
})();
