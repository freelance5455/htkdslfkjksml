// Ajustes para la app Android (Capacitor) y la versión instalada
(()=>{
const C=window.Capacitor,native=!!(C&&C.isNativePlatform&&C.isNativePlatform()),P=(C&&C.Plugins)||{};
// pantalla siempre encendida mientras juegas
const wl=async()=>{try{if(navigator.wakeLock)await navigator.wakeLock.request('screen')}catch(e){}};wl();document.addEventListener('visibilitychange',()=>{if(!document.hidden)wl()});
// ===== HORIZONTAL FORZADO =====
// A) Intenta bloquear la orientación (Android/Chrome). B) Si el teléfono sigue en vertical, dibuja el juego girado 90° para que SE VEA horizontal.
const dW=Object.getOwnPropertyDescriptor(window,'innerWidth'),dH=Object.getOwnPropertyDescriptor(window,'innerHeight');
const gw=dW&&dW.get,gh=dH&&dH.get;
const RW=()=>gw?gw.call(window):document.documentElement.clientWidth; // ancho real de la pantalla
const RH=()=>gh?gh.call(window):document.documentElement.clientHeight; // alto real
const touchy=matchMedia('(pointer:coarse)').matches;
let rot=false,sc=1,LW=0,LH=0;const MINW=844; // ancho virtual mínimo: igual que un horizontal real
// el juego lee innerWidth/innerHeight: si está girado, ve los valores intercambiados
try{Object.defineProperty(window,'innerWidth',{configurable:true,get:()=>rot?LW:RW()});Object.defineProperty(window,'innerHeight',{configurable:true,get:()=>rot?LH:RH()})}catch(e){}
// los toques también se convierten a las coordenadas del juego girado
const patch=(proto,xn,yn)=>{try{const dx=Object.getOwnPropertyDescriptor(proto,xn),dy=Object.getOwnPropertyDescriptor(proto,yn);if(!dx||!dy||!dx.get||!dy.get)return;
 Object.defineProperty(proto,xn,{configurable:true,enumerable:true,get(){return rot?dy.get.call(this)/sc:dx.get.call(this)}});
 Object.defineProperty(proto,yn,{configurable:true,enumerable:true,get(){return rot?(RW()-dx.get.call(this))/sc:dy.get.call(this)}})}catch(e){}};
patch(MouseEvent.prototype,'clientX','clientY');if(window.Touch)patch(Touch.prototype,'clientX','clientY');
const gbr=Element.prototype.getBoundingClientRect;
Element.prototype.getBoundingClientRect=function(){const r=gbr.call(this);if(!rot)return r;return new DOMRect(r.top/sc,(RW()-r.right)/sc,(r.bottom-r.top)/sc,(r.right-r.left)/sc)};
const st=document.createElement('style');
st.textContent='html{-webkit-text-size-adjust:100%;text-size-adjust:100%}html.sfrot{overflow:hidden}html.sfrot body{position:fixed!important;top:0;left:0;margin:0;width:var(--lw)!important;height:var(--lh)!important;transform-origin:0 0;transform:translateX(var(--rw)) rotate(90deg) scale(var(--sc));overflow:hidden;-webkit-text-size-adjust:100%;text-size-adjust:100%}';
document.head.appendChild(st);
const root=document.documentElement;
function apply(){
 const w=RW(),h=RH(),want=touchy&&h>w;let changed=false;
 if(want){
  const s=Math.min(1,h/MINW),lw=h/s,lh=w/s; // pantalla útil = h × w; se dibuja a lw × lh y se escala
  changed=rot&&(Math.abs(lw-LW)>.5||Math.abs(lh-LH)>.5);
  sc=s;LW=lw;LH=lh;
  root.style.setProperty('--rw',w+'px');root.style.setProperty('--lw',lw+'px');root.style.setProperty('--lh',lh+'px');root.style.setProperty('--sc',s);
  root.style.setProperty('--vw',(lw/100)+'px');root.style.setProperty('--vh',(lh/100)+'px');
 }
 if(want===rot){if(changed){try{window.dispatchEvent(new Event('resize'))}catch(e){}}return}
 rot=want;root.classList.toggle('sfrot',rot);
 if(!rot){sc=1;['--rw','--lw','--lh','--sc','--vw','--vh'].forEach(k=>root.style.removeProperty(k))}
 try{window.dispatchEvent(new Event('resize'))}catch(e){}
}
const isLandReal=()=>RW()>=RH();
const lockLand=()=>{try{if(screen.orientation&&screen.orientation.lock)return screen.orientation.lock('landscape')}catch(e){}return Promise.reject()};
const goFull=()=>{try{if(document.fullscreenElement||document.webkitFullscreenElement)return;const e=root,r=e.requestFullscreen||e.webkitRequestFullscreen;if(r){const p=r.call(e);(p&&p.then?p:Promise.resolve()).then(()=>lockLand().catch(()=>{})).catch(()=>{})}}catch(x){}};
lockLand().catch(()=>{});
['fullscreenchange','webkitfullscreenchange'].forEach(ev=>document.addEventListener(ev,()=>{lockLand().catch(()=>{});apply()}));
['load','resize','orientationchange'].forEach(ev=>addEventListener(ev,()=>{if(!isLandReal())lockLand().catch(()=>{});apply()}));
document.addEventListener('visibilitychange',()=>{if(!document.hidden){lockLand().catch(()=>{});apply()}});
// en el primer toque (el navegador lo exige) intenta pantalla completa + bloqueo horizontal; si no se puede, queda el giro por software
if(!native)document.addEventListener('pointerup',()=>{if(!isLandReal())goFull()},{passive:true});
apply();
if(!native)return;
if(P.SplashScreen)setTimeout(()=>P.SplashScreen.hide(),900);
if(P.StatusBar&&P.StatusBar.hide)P.StatusBar.hide().catch(()=>{});
// botón "atrás" de Android: pausa en el juego, sale desde el menú
if(P.App)P.App.addListener('backButton',()=>{
 try{if(state==='service'&&typeof pause==='function'){pause();return}if(state==='menu')P.App.exitApp()}catch(e){}});
// al salir de la app a segundo plano, pausa para no perder pedidos
document.addEventListener('visibilitychange',()=>{try{if(document.hidden&&state==='service'&&typeof pause==='function')pause()}catch(e){}});
})();
