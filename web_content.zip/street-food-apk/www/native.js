// Ajustes para la app Android (Capacitor) y la versión instalada
(()=>{
const C=window.Capacitor,native=!!(C&&C.isNativePlatform&&C.isNativePlatform()),P=(C&&C.Plugins)||{};
// pantalla siempre encendida mientras juegas
const wl=async()=>{try{if(navigator.wakeLock)await navigator.wakeLock.request('screen')}catch(e){}};wl();document.addEventListener('visibilitychange',()=>{if(!document.hidden)wl()});
// ===== HORIZONTAL FORZADO =====
const isLand=()=>innerWidth>=innerHeight;
const lockLand=()=>{try{if(screen.orientation&&screen.orientation.lock)return screen.orientation.lock('landscape').catch(()=>{})}catch(e){}return Promise.reject()};
const goFull=()=>{try{const e=document.documentElement,r=e.requestFullscreen||e.webkitRequestFullscreen;if(r){const p=r.call(e);return(p&&p.then?p:Promise.resolve()).then(lockLand).catch(()=>{})}}catch(x){}return Promise.resolve()};
// 1) bloqueo directo; se reintenta al cargar, al cambiar tamaño/orientación y al volver a la app
lockLand();
['fullscreenchange','webkitfullscreenchange'].forEach(ev=>document.addEventListener(ev,lockLand));
['load','resize','orientationchange'].forEach(ev=>addEventListener(ev,()=>{lockLand();aviso()}));
document.addEventListener('visibilitychange',()=>{if(!document.hidden){lockLand();aviso()}});
// 2) en el primer toque (el navegador lo exige) pasa a pantalla completa y bloquea horizontal
document.addEventListener('pointerdown',()=>{if(!native){lockLand().catch(goFull)}},{once:false,passive:true});
// 3) respaldo (iPhone/Safari y navegadores que no permiten bloquear): aviso a pantalla completa mientras esté vertical
const ov=document.createElement('div');ov.id='rot-ov';
ov.style.cssText='position:fixed;inset:0;z-index:2147483647;display:none;flex-direction:column;align-items:center;justify-content:center;gap:18px;background:#1a1030;color:#fff;font:700 20px/1.3 sans-serif;text-align:center;padding:24px;touch-action:none';
ov.innerHTML='<div style="font-size:72px;animation:rotk 1.6s ease-in-out infinite">📱</div><div>Gira tu teléfono<br>para jugar en horizontal</div><style>@keyframes rotk{0%,20%{transform:rotate(0)}60%,100%{transform:rotate(-90deg)}}</style>';
const addOv=()=>{if(!ov.parentNode)document.body.appendChild(ov)};
function aviso(){addOv();const v=!isLand();ov.style.display=v?'flex':'none';
 // pausa el juego mientras está vertical
 try{if(v&&typeof state!=='undefined'&&state==='service'&&typeof pause==='function')pause()}catch(e){}}
if(document.body)aviso();else addEventListener('DOMContentLoaded',aviso);
setInterval(aviso,800);
if(!native)return;
if(P.SplashScreen)setTimeout(()=>P.SplashScreen.hide(),900);
if(P.StatusBar&&P.StatusBar.hide)P.StatusBar.hide().catch(()=>{});
// botón "atrás" de Android: pausa en el juego, sale desde el menú
if(P.App)P.App.addListener('backButton',()=>{
 try{if(state==='service'&&typeof pause==='function'){pause();return}if(state==='menu')P.App.exitApp()}catch(e){}});
// al salir de la app a segundo plano, pausa para no perder pedidos
document.addEventListener('visibilitychange',()=>{try{if(document.hidden&&state==='service'&&typeof pause==='function')pause()}catch(e){}});
})();
