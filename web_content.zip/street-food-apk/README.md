# 🍔 Street Food 3D → app Android (APK)

Todo lo necesario para convertir el juego en una app instalable.

## Qué hay en esta carpeta
| Carpeta / archivo | Para qué sirve |
|---|---|
| `www/` | El juego: `index.html`, manifiesto, service worker (offline), iconos y `native.js` (botón atrás, pantalla encendida) |
| `assets/` | Logo (icono, primer plano y fondo adaptativos) y pantallas de carga. De aquí salen los iconos de Android |
| `capacitor.config.json` | Nombre de la app (`Street Food 3D`) e id (`com.streetfood.game`). **Cambia el id si publicas en Play Store** |
| `scripts/` | Copia las librerías para jugar sin internet y ajusta Android (horizontal, pantalla completa) |
| `store/` | Gráfico de cabecera 1024×500, textos de la ficha y plantilla de política de privacidad |
| `netlify.toml` | Para subir `www/` a Netlify |

## Camino A · Rápido (necesita internet para generar, no instalar nada pesado)
1. Sube la carpeta `www` a Netlify (arrastrar y soltar).
2. Entra en **pwabuilder.com**, pega la dirección de tu juego y elige **Android** para descargar el paquete.
   (Es un servicio externo: sus pantallas pueden cambiar.)
3. Instala el APK que te da en el móvil.

## Camino B · APK que funciona sin internet (Capacitor)
**Necesitas:** Node 18 o superior, Android Studio y JDK 17.
```bash
npm install
npm run setup      # añade Android, copia librerías, genera iconos y pantalla de carga
npm run open       # abre Android Studio
```
En Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
O por consola: `cd android && ./gradlew assembleDebug` (en Windows `gradlew.bat assembleDebug`).
El archivo queda en `android/app/build/outputs/apk/debug/app-debug.apk`.

Para instalarlo: pásalo al móvil y ábrelo (activa «instalar apps desconocidas»), o con el móvil conectado: `adb install app-debug.apk`.

Cuando cambies el juego (`www/index.html`): `npm run sync` y vuelve a compilar.

## APK firmado para Google Play
1. Crea tu llave (guárdala bien, sin ella no podrás actualizar la app):
   `keytool -genkey -v -keystore street-food.keystore -alias streetfood -keyalg RSA -keysize 2048 -validity 10000`
2. En Android Studio: **Build → Generate Signed Bundle / APK** → elige **Android App Bundle (AAB)**; Play Store pide AAB.
3. Sube `versionCode` (y `versionName`) en `android/app/build.gradle` en cada actualización.
4. Rellena la ficha con `store/listing.md` y sube `store/feature-graphic-1024x500.png`.

## Camino C · APK independiente solo con el móvil (GitHub lo compila gratis)
El APK lleva el juego, las librerías 3D y las letras **dentro**, sin depender de ninguna página.
1. Crea una cuenta gratis en github.com y un repositorio nuevo (puede ser privado).
2. **Add file → Upload files** y sube `street-food-apk.zip` (el zip entero, sin descomprimir).
3. **Add file → Create new file**. En el nombre escribe `.github/workflows/apk.yml` y pega el contenido del archivo `apk.yml`. Pulsa **Commit changes**.
4. Pestaña **Actions** → **Compilar APK** → **Run workflow**. Tarda unos minutos.
5. Al terminar, entra en esa ejecución, baja hasta **Artifacts** y descarga `street-food-apk`. Dentro está `app-debug.apk`.
6. Instálalo (permite «instalar apps desconocidas»).

Es un APK de **prueba** (firmado con llave de depuración): sirve para instalar y jugar. Para Google Play hay que firmarlo como se explica arriba.
Si Actions falla, copia el texto del paso en rojo y mándamelo para arreglarlo.

## Importante saber
- **Cooperativo en línea:** necesita internet (usa PeerJS). Lo demás funciona sin conexión.
- **Cuentas y partidas** se guardan en el móvil, no en la nube: si desinstalas la app o borras sus datos, se pierden.
- La app se abre en **horizontal** y a **pantalla completa**; el botón «atrás» pausa el juego.
- Los scripts y el paquete **no se han podido probar compilando un APK real** (aquí no hay Android SDK). Si algún paso falla, dime el mensaje exacto y lo arreglo.
