Anna Class 10 — Starter Web App

Files:
- index.html: main screens
- style.css: design
- script.js: sample subjects, quiz and demo admin panel

How to run on Android:
1. Extract AnnaClass10.zip into a folder.
2. Open the folder in Acode.
3. Open index.html and use Preview/Run.
4. The Admin demo password is anna123.

Important:
- This is a local prototype. Questions are stored only in the same browser's localStorage.
- Demo Admin password is NOT secure authentication.
- Do not publish this as a production app with private data.
- Firebase Authentication, database rules, and server-side admin authorization still need to be configured before a public release.
- Sample quiz questions are examples only; verify curriculum/content before teaching use.
