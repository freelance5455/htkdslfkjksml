const SUBJECTS = [
  {id:"science",name:"Science",hi:"विज्ञान",icon:"🔬",tint:"#e7efff",books:[{id:"physics",name:"Physics",hi:"भौतिकी"},{id:"chemistry",name:"Chemistry",hi:"रसायन विज्ञान"},{id:"biology",name:"Biology",hi:"जीव विज्ञान"}]},
  {id:"english",name:"English",hi:"अंग्रेज़ी",icon:"📘",tint:"#e8f6ef",books:[{id:"english-book",name:"English Book",hi:"पाठ और अभ्यास"}]},
  {id:"hindi",name:"Hindi",hi:"हिंदी",icon:"📕",tint:"#fff0e6",books:[{id:"hindi-book",name:"Hindi Book",hi:"पाठ और अभ्यास"}]},
  {id:"math",name:"Mathematics",hi:"गणित",icon:"📐",tint:"#f1eaff",books:[{id:"math-book",name:"Mathematics Book",hi:"गणित के अध्याय"}]},
  {id:"sst",name:"SST",hi:"सामाजिक विज्ञान",icon:"🌍",tint:"#e4f5f6",books:[{id:"history",name:"History",hi:"इतिहास"},{id:"geography",name:"Geography",hi:"भूगोल"},{id:"civics",name:"Political Science",hi:"राजनीति विज्ञान"},{id:"economics",name:"Economics",hi:"अर्थशास्त्र"}]},
  {id:"sanskrit",name:"Sanskrit",hi:"संस्कृत",icon:"📜",tint:"#fff5d9",books:[{id:"sanskrit-book",name:"Sanskrit Book",hi:"पाठ और अभ्यास"}]}
];

// Demo questions only. Replace these with verified Bihar Board syllabus questions in Admin.
const starterQuestions = [
 {id:"demo1",subject:"science",book:"physics",chapter:"chapter1",chapterName:"Chapter 1: प्रकाश",question:"प्रकाश के परावर्तन में आपतन कोण किसके बराबर होता है?",options:["परावर्तन कोण","अपवर्तन कोण","90°","0°"],correct:0},
 {id:"demo2",subject:"science",book:"physics",chapter:"chapter1",chapterName:"Chapter 1: प्रकाश",question:"समतल दर्पण में बना प्रतिबिंब कैसा होता है?",options:["वास्तविक और उल्टा","आभासी और सीधा","वास्तविक और सीधा","हमेशा बड़ा"],correct:1},
 {id:"demo3",subject:"science",book:"chemistry",chapter:"chapter1",chapterName:"Chapter 1: रासायनिक अभिक्रियाएँ",question:"रासायनिक अभिक्रिया में नए पदार्थ बनने की प्रक्रिया को क्या कहते हैं?",options:["वाष्पीकरण","गलन","रासायनिक परिवर्तन","संघनन"],correct:2}
];
const STORAGE_KEY = "annaClass10QuestionsV1";
let questions = loadQuestions();
let currentSubject = null, currentBook = null, currentChapter = null;
let quizQuestions = [], quizIndex = 0, score = 0, answered = false;

const $ = id => document.getElementById(id);
function loadQuestions(){
  try { const saved = localStorage.getItem(STORAGE_KEY); return saved ? JSON.parse(saved) : starterQuestions.slice(); }
  catch(e) { return starterQuestions.slice(); }
}
function saveQuestions(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(questions)); }
function subjectById(id){ return SUBJECTS.find(s=>s.id===id); }
function bookById(subject,id){ return subject?.books.find(b=>b.id===id); }
function escapeHtml(value){ return String(value).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }

function showView(id){
  ["homeView","contentView","quizView"].forEach(view=>$(view).classList.toggle("hidden",view!==id));
}
function renderSubjects(){
  $("subjects").innerHTML = SUBJECTS.map(s=>`
    <button class="subject-card" data-subject="${s.id}" style="--tint:${s.tint}">
      <span class="subject-icon">${s.icon}</span><strong>${s.name}</strong><small>${s.hi}</small>
    </button>`).join("");
  document.querySelectorAll("[data-subject]").forEach(btn=>btn.addEventListener("click",()=>openSubject(btn.dataset.subject)));
}
function openSubject(id){
  currentSubject = subjectById(id); currentBook=null; currentChapter=null;
  if(!currentSubject) return;
  $("contentHeading").innerHTML=`<h2>${currentSubject.icon} ${currentSubject.name}</h2><p>${currentSubject.hi} · अपनी किताब या सेक्शन चुनें</p>`;
  $("contentList").innerHTML=currentSubject.books.map(b=>`
    <button class="list-card" data-book="${b.id}">
      <span class="list-icon">📚</span><span class="list-info"><strong>${b.name}</strong><small>${b.hi}</small></span><span class="chevron">›</span>
    </button>`).join("");
  document.querySelectorAll("[data-book]").forEach(btn=>btn.addEventListener("click",()=>openBook(btn.dataset.book)));
  showView("contentView"); window.scrollTo(0,0);
}
function chaptersFor(subjectId,bookId){
  const found = [...new Map(questions.filter(q=>q.subject===subjectId&&q.book===bookId).map(q=>[q.chapter, {id:q.chapter,name:q.chapterName||q.chapter}])).values()];
  // Keep a sample chapter visible for every book; Admin can add more.
  if(!found.length) return [{id:"chapter1",name:"Chapter 1"}];
  return found;
}
function openBook(bookId){
  currentBook=bookById(currentSubject,bookId); if(!currentBook)return;
  const chapters=chaptersFor(currentSubject.id,bookId);
  $("contentHeading").innerHTML=`<h2>📖 ${currentBook.name}</h2><p>${currentSubject.name} · चैप्टर चुनें</p>`;
  $("contentList").innerHTML=chapters.map(ch=>{
    const count=questions.filter(q=>q.subject===currentSubject.id&&q.book===bookId&&q.chapter===ch.id).length;
    return `<button class="list-card" data-chapter="${escapeHtml(ch.id)}"><span class="list-icon">📝</span><span class="list-info"><strong>${escapeHtml(ch.name)}</strong><small>${count} अभ्यास प्रश्न</small></span><span class="chevron">›</span></button>`;
  }).join("");
  document.querySelectorAll("[data-chapter]").forEach(btn=>btn.addEventListener("click",()=>openQuiz(btn.dataset.chapter)));
  window.scrollTo(0,0);
}
function openQuiz(chapterId){
  currentChapter=chapterId;
  quizQuestions=questions.filter(q=>q.subject===currentSubject.id&&q.book===currentBook.id&&q.chapter===chapterId);
  if(!quizQuestions.length){
    $("contentList").innerHTML=`<div class="empty-state">इस चैप्टर में अभी प्रश्न नहीं हैं। Admin Panel से प्रश्न जोड़ें।<br><br><button class="primary" id="addFromEmpty">Admin Panel खोलें</button></div>`;
    $("addFromEmpty").addEventListener("click",()=>openAdmin());
    return;
  }
  quizIndex=0;score=0;answered=false;showView("quizView");renderQuestion();window.scrollTo(0,0);
}
function renderQuestion(){
  const q=quizQuestions[quizIndex]; answered=false;
  $("quizLabel").textContent=`${currentSubject.name} · ${currentBook.name}`;
  $("quizProgress").textContent=`प्रश्न ${quizIndex+1} / ${quizQuestions.length}`;
  $("progressFill").style.width=`${(quizIndex/quizQuestions.length)*100}%`;
  $("questionNumber").textContent=`प्रश्न ${quizIndex+1}`;
  $("questionText").textContent=q.question;
  $("answerFeedback").textContent="";$("answerFeedback").className="feedback";
  $("nextQuestion").disabled=true;
  $("nextQuestion").textContent=quizIndex===quizQuestions.length-1?"रिजल्ट देखें":"अगला प्रश्न →";
  $("answerOptions").innerHTML=q.options.map((o,i)=>`<button class="option" data-option="${i}"><span class="letter">${"ABCD"[i]}</span><span>${escapeHtml(o)}</span></button>`).join("");
  document.querySelectorAll("[data-option]").forEach(btn=>btn.addEventListener("click",()=>chooseAnswer(Number(btn.dataset.option))));
}
function chooseAnswer(index){
  if(answered)return;answered=true;const q=quizQuestions[quizIndex];const buttons=[...document.querySelectorAll("[data-option]")];
  buttons.forEach((btn,i)=>{btn.disabled=true;if(i===q.correct)btn.classList.add("correct");else if(i===index)btn.classList.add("wrong");});
  if(index===q.correct){score++;$("answerFeedback").textContent="सही जवाब! 🎉";$("answerFeedback").classList.add("good");}
  else{$("answerFeedback").textContent=`गलत जवाब। सही उत्तर: ${q.options[q.correct]}`;$("answerFeedback").classList.add("bad");}
  $("nextQuestion").disabled=false;
}
$("nextQuestion").addEventListener("click",()=>{
  if(!answered)return;
  if(quizIndex<quizQuestions.length-1){quizIndex++;renderQuestion();return;}
  $("progressFill").style.width="100%";
  $("questionNumber").textContent="Quiz पूरा हुआ!";
  $("questionText").textContent=`आपका स्कोर ${score} / ${quizQuestions.length}`;
  $("answerOptions").innerHTML=`<p class="empty-state">${score===quizQuestions.length?"शानदार! सभी उत्तर सही हैं।":"अभ्यास करते रहें, आप बेहतर करेंगे।"}</p>`;
  $("answerFeedback").textContent=`प्रतिशत: ${Math.round(score/quizQuestions.length*100)}%`;
  $("answerFeedback").className="feedback good";
  $("nextQuestion").textContent="विषय पर वापस जाएँ";
  $("nextQuestion").onclick=()=>{ $("nextQuestion").onclick=null; $("nextQuestion").addEventListener("click",()=>{}, {once:true}); openSubject(currentSubject.id); };
});
$("backHome").addEventListener("click",()=>{showView("homeView");window.scrollTo(0,0);});
$("backContent").addEventListener("click",()=>openBook(currentBook.id));

// Admin demo panel. This is NOT secure authentication; use Firebase Auth + server-enforced rules before deployment.
function openAdmin(){$("adminModal").classList.remove("hidden");$("adminLogin").classList.remove("hidden");$("adminDashboard").classList.add("hidden");$("loginError").textContent="";$("adminPassword").value="";}
$("adminOpen").addEventListener("click",openAdmin);
$("adminClose").addEventListener("click",()=>$("adminModal").classList.add("hidden"));
$("adminModal").addEventListener("click",e=>{if(e.target===$("adminModal"))$("adminModal").classList.add("hidden");});
$("adminLoginButton").addEventListener("click",()=>{
  if($("adminPassword").value==="anna123"){$("adminLogin").classList.add("hidden");$("adminDashboard").classList.remove("hidden");renderAdmin();}
  else $("loginError").textContent="पासवर्ड सही नहीं है।";
});
$("adminPassword").addEventListener("keydown",e=>{if(e.key==="Enter")$("adminLoginButton").click();});
$("adminLogout").addEventListener("click",()=>{$("adminDashboard").classList.add("hidden");$("adminLogin").classList.remove("hidden");});
function fillAdminSubjects(){$("adminSubject").innerHTML=SUBJECTS.map(s=>`<option value="${s.id}">${s.name}</option>`).join("");}
function renderAdmin(){
  $("adminQuestions").innerHTML=questions.map((q,i)=>`<div class="admin-question"><strong>${escapeHtml(q.question)}</strong><small>${escapeHtml(subjectById(q.subject)?.name||q.subject)} · ${escapeHtml(q.book)} · ${escapeHtml(q.chapterName||q.chapter)}</small><button class="delete-button" data-delete="${i}">प्रश्न हटाएँ</button></div>`).join("")||'<p class="muted">अभी कोई प्रश्न नहीं है।</p>';
  document.querySelectorAll("[data-delete]").forEach(btn=>btn.addEventListener("click",()=>{if(confirm("क्या यह प्रश्न हटाना है?")){questions.splice(Number(btn.dataset.delete),1);saveQuestions();renderAdmin();}}));
}
$("questionForm").addEventListener("submit",e=>{
  e.preventDefault();
  const subjectId=$("adminSubject").value,bookName=$("adminBook").value.trim(),chapterName=$("adminChapter").value.trim();
  const subject=subjectById(subjectId);
  let book=subject.books.find(b=>b.name.toLowerCase()===bookName.toLowerCase());
  if(!book){book={id:bookName.toLowerCase().replace(/[^a-z0-9]+/g,"-")||"custom-book",name:bookName,hi:bookName};if(!subject.books.some(b=>b.id===book.id))subject.books.push(book);}
  const chapterId=chapterName.toLowerCase().replace(/[^a-z0-9]+/g,"-")||"custom-chapter";
  const options=[0,1,2,3].map(i=>$("opt"+i).value.trim());
  questions.push({id:"q"+Date.now(),subject:subjectId,book:book.id,chapter:chapterId,chapterName,question:$("adminQuestion").value.trim(),options,correct:Number($("adminCorrect").value)});
  saveQuestions();e.target.reset();renderAdmin();renderSubjects();alert("प्रश्न इस ब्राउज़र में सेव हो गया।");
});
$("exportData").addEventListener("click",()=>{
  const blob=new Blob([JSON.stringify(questions,null,2)],{type:"application/json"});
  const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="anna-class-10-questions.json";a.click();URL.revokeObjectURL(url);
});
fillAdminSubjects();renderSubjects();
