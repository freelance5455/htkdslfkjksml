# V60 — Excel Android in-app Downloads picker fallback

Version 2.26 / versionCode 30.

The Android Excel importer no longer relies exclusively on DocumentsUI appearing. The Choose File action first opens an in-app Downloads list populated through MediaStore. Users can select a supported `.xlsx`, `.csv`, or `.txt` file directly. An “Other files” action retains the Android document picker fallback.
