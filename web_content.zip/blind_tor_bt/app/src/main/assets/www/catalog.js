const CATALOG = [
  {
    "id": "item-01",
    "name": "Белые кеды",
    "category": "Обувь",
    "image": "assets/item_01.jpg"
  },
  {
    "id": "item-02",
    "name": "New Balance",
    "category": "Обувь",
    "image": "assets/item_02.jpg"
  },
  {
    "id": "item-03",
    "name": "Красные спортивные кроссовки",
    "category": "Обувь",
    "image": "assets/item_03.jpg"
  },
  {
    "id": "item-04",
    "name": "Чёрно-белые кроссовки",
    "category": "Обувь",
    "image": "assets/item_04.jpg"
  },
  {
    "id": "item-05",
    "name": "Красные туфли",
    "category": "Обувь",
    "image": "assets/item_05.jpg"
  },
  {
    "id": "item-06",
    "name": "Чёрные классические туфли",
    "category": "Обувь",
    "image": "assets/item_06.jpg"
  },
  {
    "id": "item-07",
    "name": "Чёрные сабо",
    "category": "Обувь",
    "image": "assets/item_07.jpg"
  },
  {
    "id": "item-08",
    "name": "Чёрные сандалии",
    "category": "Обувь",
    "image": "assets/item_08.jpg"
  },
  {
    "id": "item-09",
    "name": "Чёрные кеды",
    "category": "Обувь",
    "image": "assets/item_09.jpg"
  },
  {
    "id": "item-10",
    "name": "Белые кроссовки",
    "category": "Обувь",
    "image": "assets/item_10.jpg"
  },
  {
    "id": "item-11",
    "name": "Яркие легинсы",
    "category": "Штаны",
    "image": "assets/item_11.jpg"
  },
  {
    "id": "item-12",
    "name": "Графитовые широкие штаны",
    "category": "Штаны",
    "image": "assets/item_12.jpg"
  },
  {
    "id": "item-13",
    "name": "Камуфляжные брюки",
    "category": "Штаны",
    "image": "assets/item_13.jpg"
  },
  {
    "id": "item-14",
    "name": "Чёрные джинсы",
    "category": "Штаны",
    "image": "assets/item_14.jpg"
  },
  {
    "id": "item-15",
    "name": "Синие джинсы",
    "category": "Штаны",
    "image": "assets/item_15.jpg"
  },
  {
    "id": "item-16",
    "name": "Чёрные расклёшенные джинсы",
    "category": "Штаны",
    "image": "assets/item_16.jpg"
  },
  {
    "id": "item-17",
    "name": "Чёрные карго",
    "category": "Штаны",
    "image": "assets/item_17.jpg"
  },
  {
    "id": "item-18",
    "name": "Спортивные штаны",
    "category": "Штаны",
    "image": "assets/item_18.jpg"
  },
  {
    "id": "item-19",
    "name": "Рваные серые джинсы",
    "category": "Штаны",
    "image": "assets/item_19.jpg"
  },
  {
    "id": "item-20",
    "name": "Светлые широкие штаны",
    "category": "Штаны",
    "image": "assets/item_20.jpg"
  },
  {
    "id": "item-21",
    "name": "Жёлтая футболка",
    "category": "Футболка",
    "image": "assets/item_21.jpg"
  },
  {
    "id": "item-22",
    "name": "Чёрная футболка с белой окантовкой",
    "category": "Футболка",
    "image": "assets/item_22.jpg"
  },
  {
    "id": "item-23",
    "name": "Коричневая полосатая футболка",
    "category": "Футболка",
    "image": "assets/item_23.jpg"
  },
  {
    "id": "item-24",
    "name": "Белая полосатая футболка",
    "category": "Футболка",
    "image": "assets/item_24.jpg"
  },
  {
    "id": "item-25",
    "name": "NASA футболка",
    "category": "Футболка",
    "image": "assets/item_25.jpg"
  },
  {
    "id": "item-26",
    "name": "Nirvana футболка",
    "category": "Футболка",
    "image": "assets/item_26.jpg"
  },
  {
    "id": "item-27",
    "name": "Графическая футболка",
    "category": "Футболка",
    "image": "assets/item_27.jpg"
  },
  {
    "id": "item-28",
    "name": "Six Seven футболка",
    "category": "Футболка",
    "image": "assets/item_28.jpg"
  },
  {
    "id": "item-29",
    "name": "Белая базовая футболка",
    "category": "Футболка",
    "image": "assets/item_29.jpg"
  },
  {
    "id": "item-30",
    "name": "Levi’s серая кофта",
    "category": "Кофта",
    "image": "assets/item_30.jpg"
  },
  {
    "id": "item-31",
    "name": "Синяя кофта",
    "category": "Кофта",
    "image": "assets/item_31.jpg"
  },
  {
    "id": "item-32",
    "name": "Чёрно-белая кофта",
    "category": "Кофта",
    "image": "assets/item_32.jpg"
  },
  {
    "id": "item-33",
    "name": "Серая кофта с принтом",
    "category": "Кофта",
    "image": "assets/item_33.jpg"
  },
  {
    "id": "item-34",
    "name": "Меховая кофта",
    "category": "Кофта",
    "image": "assets/item_34.jpg"
  },
  {
    "id": "item-35",
    "name": "Чёрная худи",
    "category": "Кофта",
    "image": "assets/item_35.jpg"
  },
  {
    "id": "item-36",
    "name": "Худи с лицом",
    "category": "Кофта",
    "image": "assets/item_36.jpg"
  },
  {
    "id": "item-37",
    "name": "Худи с лицом",
    "category": "Кофта",
    "image": "assets/item_37.jpg"
  },
  {
    "id": "item-38",
    "name": "Синяя камуфляжная худи",
    "category": "Кофта",
    "image": "assets/item_38.jpg"
  },
  {
    "id": "item-39",
    "name": "Зелёная камуфляжная худи",
    "category": "Кофта",
    "image": "assets/item_39.jpg"
  },
  {
    "id": "item-40",
    "name": "Чёрная bucket hat",
    "category": "Головной убор",
    "image": "assets/item_40.jpg"
  },
  {
    "id": "item-41",
    "name": "Цветная кепка с пропеллером",
    "category": "Головной убор",
    "image": "assets/item_41.jpg"
  },
  {
    "id": "item-42",
    "name": "Ушанка",
    "category": "Головной убор",
    "image": "assets/item_42.jpg"
  },
  {
    "id": "item-43",
    "name": "Чёрная бини",
    "category": "Головной убор",
    "image": "assets/item_43.jpg"
  },
  {
    "id": "item-44",
    "name": "Supreme бини",
    "category": "Головной убор",
    "image": "assets/item_44.jpg"
  },
  {
    "id": "item-45",
    "name": "Gucci tiger кепка",
    "category": "Головной убор",
    "image": "assets/item_45.jpg"
  },
  {
    "id": "item-46",
    "name": "Чёрная кепка",
    "category": "Головной убор",
    "image": "assets/item_46.jpg"
  },
  {
    "id": "item-47",
    "name": "Красно-чёрная кепка",
    "category": "Головной убор",
    "image": "assets/item_47.jpg"
  },
  {
    "id": "item-48",
    "name": "Чёрная кепка с принтом",
    "category": "Головной убор",
    "image": "assets/item_48.jpg"
  },
  {
    "id": "item-49",
    "name": "Белые солнцезащитные очки",
    "category": "Аксессуары",
    "image": "assets/item_49.jpg"
  },
  {
    "id": "item-50",
    "name": "Звезда-брелок",
    "category": "Аксессуары",
    "image": "assets/item_50.jpg"
  },
  {
    "id": "item-51",
    "name": "Цепь",
    "category": "Аксессуары",
    "image": "assets/item_51.jpg"
  },
  {
    "id": "item-52",
    "name": "Цепочка на пояс",
    "category": "Аксессуары",
    "image": "assets/item_52.jpg"
  },
  {
    "id": "item-53",
    "name": "Бандана с цепью",
    "category": "Аксессуары",
    "image": "assets/item_53.jpg"
  },
  {
    "id": "item-54",
    "name": "Часы",
    "category": "Аксессуары",
    "image": "assets/item_54.jpg"
  },
  {
    "id": "item-55",
    "name": "Чёрные очки",
    "category": "Аксессуары",
    "image": "assets/item_55.jpg"
  },
  {
    "id": "item-56",
    "name": "Проводные наушники",
    "category": "Аксессуары",
    "image": "assets/item_56.jpg"
  },
  {
    "id": "item-57",
    "name": "iPod",
    "category": "Аксессуары",
    "image": "assets/item_57.jpg"
  },
  {
    "id": "item-58",
    "name": "Аксессуар №10",
    "category": "Аксессуары",
    "image": "assets/item_58.jpg"
  },
  {
    "id": "item-59",
    "name": "Футболка №10",
    "category": "Футболка",
    "image": "assets/item_missing_1.jpg"
  },
  {
    "id": "item-60",
    "name": "Головной убор №10",
    "category": "Головной убор",
    "image": "assets/item_missing_2.jpg"
  }
];
