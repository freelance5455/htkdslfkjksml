package com.blindtor.bluetooth;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.UUID;

public class BtBridge {
  private static final UUID UUID_BT=UUID.fromString("8f0d8f36-8a35-4f4a-9f8e-1e3f6c7a6a11");
  private final Activity a; private final WebView w; private final BluetoothAdapter adapter;
  private BluetoothServerSocket server; private BluetoothSocket socket; private Thread io; private BroadcastReceiver receiver;
  BtBridge(Activity a,WebView w){this.a=a;this.w=w; BluetoothManager bm=(BluetoothManager)a.getSystemService(Context.BLUETOOTH_SERVICE); adapter=bm.getAdapter();}
  @JavascriptInterface public void startHost(){ if(!permissions())return; try{ Intent in=new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE); in.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION,300); a.startActivity(in); }catch(Exception ignored){} new Thread(()->{try{server=adapter.listenUsingRfcommWithServiceRecord("BlindTor",UUID_BT); emit("{\"type\":\"host_ready\"}"); socket=server.accept(); server.close(); connected(); readLoop();}catch(Exception e){error(e.getMessage());}}).start();}
  @JavascriptInterface public void startDiscovery(){ if(!permissions())return; a.runOnUiThread(()->{ if(adapter.isDiscovering())adapter.cancelDiscovery(); receiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){if(BluetoothDevice.ACTION_FOUND.equals(i.getAction())){BluetoothDevice d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE); try{JSONObject o=new JSONObject();o.put("name",d.getName());o.put("address",d.getAddress());List<JSONObject> list=new ArrayList<>();list.add(o);JSONObject e=new JSONObject();e.put("type","devices");e.put("devices",new JSONArray(list));emit(e.toString());}catch(Exception x){}}}}; a.registerReceiver(receiver,new IntentFilter(BluetoothDevice.ACTION_FOUND)); adapter.startDiscovery();});}
  @JavascriptInterface public void connect(String addr){if(!permissions())return;new Thread(()->{try{BluetoothDevice d=adapter.getRemoteDevice(addr); if(adapter.isDiscovering())adapter.cancelDiscovery(); socket=d.createRfcommSocketToServiceRecord(UUID_BT); socket.connect(); connected(); readLoop();}catch(Exception e){error(e.getMessage());}}).start();}
  @JavascriptInterface public void send(String msg){new Thread(()->{try{if(socket!=null&&socket.isConnected()){OutputStream o=socket.getOutputStream();o.write((msg+"\n").getBytes("UTF-8"));o.flush();}}catch(Exception e){error(e.getMessage());}}).start();}
  private boolean permissions(){if(Build.VERSION.SDK_INT>=31){String[] p={Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_ADVERTISE};ArrayList<String> q=new ArrayList<>();for(String x:p)if(a.checkSelfPermission(x)!=PackageManager.PERMISSION_GRANTED)q.add(x);if(!q.isEmpty()){a.requestPermissions(q.toArray(new String[0]),77);return false;}}if(adapter==null||!adapter.isEnabled()){error("Включи Bluetooth на телефоне.");return false;}return true;}
  private void connected(){emit("{\"type\":\"connected\"}"); a.runOnUiThread(()->w.evaluateJavascript("window.onBluetoothConnected&&window.onBluetoothConnected()",null));}
  private void readLoop(){io=new Thread(()->{try{BufferedReader r=new BufferedReader(new InputStreamReader(socket.getInputStream(),"UTF-8"));String line;while((line=r.readLine())!=null){String safe=JSONObject.quote(line);emit("{\"type\":\"message\",\"data\":"+safe+"}");a.runOnUiThread(()->w.evaluateJavascript("window.__btIncoming&&window.__btIncoming("+safe+")",null));}}catch(Exception e){error("Соединение завершено.");}});io.start();}
  private void emit(String json){a.runOnUiThread(()->w.evaluateJavascript("window.dispatchEvent(new CustomEvent('BlindTorBTEvent',{detail:"+json+"}))",null));}
  private void error(String m){try{JSONObject o=new JSONObject();o.put("type","error");o.put("message",m==null?"Ошибка Bluetooth":m);emit(o.toString());}catch(Exception ignored){}}
  private boolean ok(){return socket!=null&&socket.isConnected();}
  public void close(){try{if(receiver!=null)a.unregisterReceiver(receiver);}catch(Exception ignored){}try{if(socket!=null)socket.close();}catch(Exception ignored){}try{if(server!=null)server.close();}catch(Exception ignored){}}
}