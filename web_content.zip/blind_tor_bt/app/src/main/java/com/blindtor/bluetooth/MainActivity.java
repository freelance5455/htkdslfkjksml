package com.blindtor.bluetooth;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    WebView web; BtBridge bt;
    @Override public void onCreate(Bundle b){ super.onCreate(b); web=new WebView(this); web.setWebViewClient(new WebViewClient()); WebSettings ws=web.getSettings(); ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setAllowFileAccess(true); ws.setUseWideViewPort(false); ws.setLoadWithOverviewMode(false); bt=new BtBridge(this,web); web.addJavascriptInterface(bt,"BlindTorBT"); setContentView(web); web.loadUrl("file:///android_asset/www/index.html"); }
    @Override protected void onDestroy(){ if(bt!=null) bt.close(); super.onDestroy(); }
}