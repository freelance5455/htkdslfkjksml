const CACHE="kahkashan-shell-v1";
const SHELL=["./","./index.html","./styles.css","./app.js","./config.js","./manifest.webmanifest","./assets/icon.svg"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL))));
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener("fetch",e=>{
  const u=new URL(e.request.url);
  if(e.request.method!=="GET" || u.origin!==location.origin) return;
  // HTML and app shell are network-first so published updates reach phones.
  if(e.request.mode==="navigate" || /\.(html|js|css|webmanifest)$/.test(u.pathname)){
    e.respondWith(fetch(e.request).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return r;}).catch(()=>caches.match(e.request).then(r=>r||caches.match("./index.html"))));
  } else {
    e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request)));
  }
});