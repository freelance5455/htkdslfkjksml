const CACHE_NAME='restzeit-shell-v3';
const SHELL=[
  new URL('./index.html',self.registration.scope).href,
  new URL('./manifest.json',self.registration.scope).href,
  new URL('./restzeit12-app-icon.png',self.registration.scope).href,
  new URL('./restzeit12-app-icon-192.png',self.registration.scope).href
];
self.addEventListener('install',event=>{event.waitUntil((async()=>{const cache=await caches.open(CACHE_NAME);await cache.addAll(SHELL);await self.skipWaiting()})())});
self.addEventListener('activate',event=>{event.waitUntil((async()=>{const keys=await caches.keys();await Promise.all(keys.filter(key=>key.startsWith('restzeit-shell-')&&key!==CACHE_NAME).map(key=>caches.delete(key)));await self.clients.claim()})())});
self.addEventListener('fetch',event=>{const req=event.request;if(req.method!=='GET')return;const url=new URL(req.url);if(url.origin!==self.location.origin||url.pathname.includes('/api/'))return;if(req.mode==='navigate'){event.respondWith((async()=>{try{const response=await fetch(req);if(response.ok){const cache=await caches.open(CACHE_NAME);cache.put(SHELL[0],response.clone())}return response}catch{return (await caches.match(req))||(await caches.match(SHELL[0]))||Response.error()}})());return}if(SHELL.includes(url.href)){event.respondWith((async()=>{const cached=await caches.match(req);if(cached)return cached;try{return await fetch(req)}catch{return Response.error()}})())}});
