/* JOSTECH — SERVICE WORKER COMPLET (TOUS LES 33 MANUELS & COURS) */
const CACHE_NAME = "jostech-cache-v1.3";

const ASSETS = [
  "./", "./index.html", "./manifest.json", "./logo-jostech.jpg",
  "./style.css", "./style-extra.css", "./style-ui.css",
  "./courses.js", "./course-1.js", "./course-2.js", "./course-3.js",
  "./course-4.js", "./course-5.js", "./course-6.js", "./course-7.js",
  "./course-8.js", "./course-9.js", "./course-10.js",
  "./book-ig-1.js", "./book-ig-2.js", "./book-ig-3.js", "./book-ig-4.js",
  "./book-prog-1.js", "./book-prog-2.js", "./book-prog-3.js", "./book-prog-4.js",
  "./book-web-1.js", "./book-web-2.js", "./book-web-3.js", "./book-web-4.js",
  "./book-sec-1.js", "./book-sec-2.js", "./book-sec-3.js",
  "./book-ia-1.js", "./book-ia-2.js", "./book-ia-3.js",
  "./book-res-1.js", "./book-res-2.js", "./book-res-3.js",
  "./book-bdd-1.js", "./book-bdd-2.js", "./book-bdd-3.js",
  "./book-rob-1.js", "./book-rob-2.js", "./book-rob-3.js",
  "./book-gl-1.js", "./book-gl-2.js", "./book-gl-3.js",
  "./book-eng-1.js", "./book-eng-2.js", "./book-eng-3.js",
  "./quizzes.js", "./quiz-engine.js",
  "./views-auth.js", "./auth-admin.js",
  "./lab-sql.js", "./lab.js",
  "./ai-data.js", "./offline-badges.js", "./assistant.js",
  "./app-reader.js", "./app-lesson.js", "./app.js"
];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE_NAME).then(c => Promise.all(ASSETS.map(u => c.add(u).catch(() => {})))));
  self.skipWaiting();
});
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener("fetch", e => {
  if (e.request.method !== "GET" || !e.request.url.startsWith(self.location.origin)) return;
  e.respondWith(
    caches.match(e.request, { ignoreSearch: true }).then(c => c || fetch(e.request).then(r => {
      if (r && r.status === 200) { const cl = r.clone(); caches.open(CACHE_NAME).then(ca => ca.put(e.request, cl)); }
      return r;
    }).catch(() => caches.match("./index.html")))
  );
});