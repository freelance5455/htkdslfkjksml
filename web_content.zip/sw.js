const CACHE="abby-pwa-v1-2";
const FILES=["./","./index.html","./style.css","./app.js","./manifest.json","./assets/icon-192.png","./assets/icon-512.png","./assets/abby-portrait.jpg"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES))));
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener("fetch",e=>{if(e.request.method!=="GET")return;e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request)));});
