var CACHE_NAME = 'recipe-app-v1';
var assetsToCache = [
    'index.html',
    'styles.css',
    'app.js',
    'manifest.json'
];

// Service Worker Install Event - Caches app shell elements locally
self.addEventListener(
    'install', function(event) {
        event.waitUntil(
            caches.open(CACHE_NAME).then(function(cache) {
                return cache.addAll(assetsToCache);
            }).then(function() {
                return self.skipWaiting();
            }) );
    });

// Service Worker Activate Event - Automatically claims clients to prevent boot lags
self.addEventListener('activate', function(event) {
    event.waitUntil(self.clients.claim());
});

// Service Worker Fetch Event - Safely routes local requests while skipping cloud databases
self.addEventListener('fetch', function(event) {

    // Only handle local structural app files, bypass external web links like JSONBin to avoid errors
    if (event.request.url.startsWith(self.location.origin)) {
        event.respondWith(
            caches.match(event.request).then(function(response) {
                return response || fetch(event.request);
    })
);
}
});



