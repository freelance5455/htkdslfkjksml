/**
 * Panchal Business Manager - Offline Service Worker (v3)
 * Caches all ERP modules and core shell assets for offline usage.
 */
const CACHE_NAME = "pbm-shell-v10";
const SHELL_ASSETS = [
  "./erp.html",
  "./manifest.json",
  "./css/styles.css",
  "./vendor/html2canvas.min.js",
  "./vendor/jspdf.umd.min.js",
  "./js/db.js",
  "./js/templates.js",
  "./js/print_share.js",
  "./js/security.js",
  "./js/parties.js",
  "./js/inventory.js",
  "./js/billing.js",
  "./js/accounting.js",
  "./js/projects.js",
  "./js/payroll.js",
  "./js/zoho_suite.js",
  "./js/app.js"
];

self.addEventListener("install", function (event) {
  event.waitUntil(
    caches.open(CACHE_NAME).then(function (cache) {
      return cache.addAll(SHELL_ASSETS);
    })
  );
  self.skipWaiting();
});

self.addEventListener("activate", function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(
        keys.map(function (key) {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
          return null;
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener("fetch", function (event) {
  if (event.request.method !== "GET") {
    return;
  }

  event.respondWith(
    caches.match(event.request).then(function (cachedResponse) {
      if (cachedResponse) {
        return cachedResponse;
      }
      return fetch(event.request)
        .then(function (networkResponse) {
          if (
            networkResponse &&
            networkResponse.status === 200 &&
            networkResponse.type === "basic"
          ) {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then(function (cache) {
              cache.put(event.request, responseClone);
            });
          }
          return networkResponse;
        })
        .catch(function () {
          if (event.request.mode === "navigate") {
            return caches.match("./erp.html");
          }
          return new Response("Offline", { status: 503, statusText: "Offline" });
        });
    })
  );
});
