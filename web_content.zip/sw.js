// Salva os arquivos do aplicativo para abertura offline depois da instalação.
const CACHE='acai-alcantaras-local-v3';
const ASSETS=['./','./index.html','./style.css','./app.js','./icon.svg','./icon-192.png','./icon-512.png','./logo-padrao.jpg','./manifest.webmanifest'];
self.addEventListener('install', event=>{
 event.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
 event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('acai-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET'||new URL(event.request.url).origin!==self.location.origin)return;
 event.respondWith(
  caches.match(event.request).then(cached=>{
   const network=fetch(event.request).then(res=>{
    if(res.ok && new URL(event.request.url).pathname.match(/(?:\/|\.(?:js|css|html|png|svg|webmanifest))$/)){
     const copy=res.clone();caches.open(CACHE).then(c=>c.put(event.request,copy));
    }return res;
   }).catch(()=>cached || (event.request.mode==='navigate'?caches.match('./index.html'):undefined));
   return cached || network;
  })
 );
});
