// Service Worker v2 — Portais · Vínculo Quântico
// Cache-first: funciona OFFLINE. Não ativa nova versão sozinho — avisa o usuário.
const CACHE = "sonar-v4";
const ASSETS = ["./", "./index.html", "./manifest.json", "./icon-192.png", "./icon-512.png"];

self.addEventListener("install", e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => {
      // Primeira instalação (sem SW ativo): ativa imediatamente para offline já no primeiro uso.
      // Atualização: NÃO ativa sozinho — espera o usuário tocar em "Nova versão disponível" (SKIP_WAITING).
      if (!self.registration || !self.registration.active) { return self.skipWaiting(); }
    })
  );
});

self.addEventListener("message", e => {
  if (e.data && e.data.type === "SKIP_WAITING") { self.skipWaiting(); }
});

self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", e => {
  if (e.request.method !== "GET") return;
  e.respondWith(
    caches.match(e.request).then(cached => {
      const network = fetch(e.request).then(res => {
        if (res && res.status === 200 && res.type === "basic") {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put(e.request, copy));
        }
        return res;
      }).catch(() => cached);
      return cached || network;
    })
  );
});
