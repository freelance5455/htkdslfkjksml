self.addEventListener('install', e => {
  e.waitUntil(caches.open('toancube').then(c => c.addAll(['index.html','style.css','game.js','manifest.json'])));
});
self.addEventListener('fetch', e => {
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});