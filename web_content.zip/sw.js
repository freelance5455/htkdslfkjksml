const CACHE = 'orbit-v2';
const CORE_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './icon-maskable-512.png'
];
const FONT_ASSETS = [
  'fredoka-500','fredoka-600','fredoka-700',
  'nunito-400','nunito-600','nunito-700','nunito-800',
  'poppins-500','poppins-600','poppins-700',
  'space-grotesk-500','space-grotesk-600','space-grotesk-700',
  'quicksand-600','quicksand-700',
  'vazirmatn-500','vazirmatn-700'
].map(n => './fonts/' + n + '.woff2');

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(async c => {
    await c.addAll(CORE_ASSETS); // these must exist — fail loudly if not
    // fonts are optional until fonts/README.txt has been followed — cache
    // each one separately so a missing file doesn't break the whole install
    await Promise.all(FONT_ASSETS.map(url => c.add(url).catch(() => {})));
  }));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
  );
  self.clients.claim();
});

// Cache-first for app shell, falling back to network, so Orbit works with no signal.
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    caches.match(e.request).then(cached => {
      const fetchPromise = fetch(e.request).then(res => {
        if (res && res.status === 200) {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put(e.request, copy));
        }
        return res;
      }).catch(() => cached);
      return cached || fetchPromise;
    })
  );
});
