// Caches the whole app so it opens offline. To ship an update, change V (e.g. bills-v2).
const V = 'bills-v1';
const FILES = ['./', './index.html', './sw.js'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(V).then(c => c.addAll(FILES)));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET') return;
  e.respondWith(
    caches.match(r, { ignoreSearch: true }).then(hit =>
      hit ||
      fetch(r).then(res => {
        if (res.ok && new URL(r.url).origin === location.origin) {
          const copy = res.clone();
          caches.open(V).then(c => c.put(r, copy));
        }
        return res;
      }).catch(() => caches.match('./index.html'))
    )
  );
});
