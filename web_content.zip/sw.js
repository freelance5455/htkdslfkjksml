const CACHE="calisten-2.0-v1";
const ASSETS=[
"./","./index.html","./manifest.json",
"./css/variables.css","./css/reset.css","./css/base.css","./css/components.css",
"./css/navigation.css","./css/dashboard.css","./css/workout.css","./css/exercises.css",
"./css/progress.css","./css/app.css",
"./js/app.js","./js/state.js","./js/storage.js","./js/database.js","./js/data.js",
"./js/exercises.js","./js/workouts.js","./js/workout-player.js","./js/timer.js",
"./js/progression.js","./js/skills.js","./js/planner.js","./js/history.js",
"./js/analytics.js","./js/recovery.js","./js/gamification.js","./js/settings.js",
"./js/onboarding.js","./js/ui.js","./js/utils.js",
"./assets/icons/icon-192.svg","./assets/icons/icon-512.svg"
];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener("activate",e=>e.waitUntil(self.clients.claim()));
self.addEventListener("fetch",e=>{
  if(e.request.method!=="GET") return;
  e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request).then(r=>{
    if(r.ok){const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));}
    return r;
  }).catch(()=>caches.match("./index.html"))));
});