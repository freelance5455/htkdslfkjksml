const VERSION='v5';
const CACHE_NAME='seated-enterprise-pos-'+VERSION;
const SHELL=['./','./index.html','./offline.html','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png','./icons/maskable-192.png','./icons/maskable-512.png'];

self.addEventListener('install',e=>{
  e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(SHELL)));
});

self.addEventListener('activate',e=>{
  e.waitUntil(
    caches.keys()
      .then(keys=>Promise.all(keys.filter(k=>k.startsWith('seated-enterprise-pos-')&&k!==CACHE_NAME).map(k=>caches.delete(k))))
      .then(()=>self.clients.claim())
  );
});

// The page can ask a waiting worker to take over (update banner "Reload" button)
self.addEventListener('message',e=>{if(e.data==='SKIP_WAITING')self.skipWaiting();});

self.addEventListener('fetch',e=>{
  const req=e.request;
  if(req.method!=='GET')return;
  const url=new URL(req.url);
  if(url.origin!==location.origin)return;

  // Pages: network first (so updates arrive), fall back to cache, then offline page
  if(req.mode==='navigate'){
    e.respondWith(
      fetch(req).then(res=>{
        if(res.ok){const copy=res.clone();caches.open(CACHE_NAME).then(c=>c.put('./index.html',copy));}
        return res;
      }).catch(()=>caches.match('./index.html').then(r=>r||caches.match('./offline.html')))
    );
    return;
  }

  // Static assets: cache first, refresh in background
  e.respondWith(
    caches.match(req).then(cached=>{
      const net=fetch(req).then(res=>{
        if(res.ok){const copy=res.clone();caches.open(CACHE_NAME).then(c=>c.put(req,copy));}
        return res;
      }).catch(()=>cached);
      return cached||net;
    })
  );
});
