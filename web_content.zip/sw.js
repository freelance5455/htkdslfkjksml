const C='imposed-v26',F=['./','index.html','styles.css','manifest.webmanifest','img/logo-64.png','img/logo-128.png','img/logo-192.png','img/logo-512.png','js/i18n.js','js/core.js','js/boot.js','js/data.js','js/audio.js','js/extras.js','js/views.js','js/release.js','js/profiles.js','js/discography.js','js/captcha.js','js/events.js'];
self.addEventListener('install',e=>{self.skipWaiting();e.waitUntil(caches.open(C).then(c=>c.addAll(F)))});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim())));
/* Network first, so a new deploy shows up immediately. The cache is only the offline fallback. config.js is never cached. */
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==location.origin||u.pathname.endsWith('config.js'))return;
e.respondWith(fetch(e.request).then(r=>{if(r.ok){const copy=r.clone();caches.open(C).then(c=>c.put(e.request,copy))}return r}).catch(()=>caches.match(e.request)))});
