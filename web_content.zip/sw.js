// Service Worker for system notifications + badge support
self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) {
          client.focus();
          client.postMessage({ type: 'NOTIFICATION_CLICK', data: event.notification.data || {} });
          return;
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow('./index.html');
      }
    })
  );
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SHOW_NOTIFICATION') {
    const { title, body, id, icon } = event.data;
    event.waitUntil(
      self.registration.showNotification(title || 'Notification', {
        body: body || '',
        icon: icon || './sukuna-logo.png',
        badge: './sukuna-logo.png',
        tag: 'admin-notif-' + (id || Date.now()),
        renotify: true,
        requireInteraction: false,
        data: { id: id, url: './index.html' }
      })
    );
  }
});
