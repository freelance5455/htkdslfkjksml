const API = 'https://tmatches.staionp01.workers.dev';
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => {});
async function sha(s) { const d = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)); return [...new Uint8Array(d)].map(b => b.toString(16).padStart(2, '0')).join(''); }
self.addEventListener('push', e => e.waitUntil((async () => {
  let shown = 0;
  try {
    const sub = await self.registration.pushManager.getSubscription();
    if (sub) {
      const r = await fetch(API + '/api/push/latest?h=' + await sha(sub.endpoint), { cache: 'no-store' });
      const j = await r.json();
      for (const a of j.alerts || []) {
        await self.registration.showNotification(a.title, { body: a.body, icon: 'icon-192.png', badge: 'icon-192.png', tag: 'm' + a.id, dir: 'rtl', lang: 'ar', vibrate: [200, 100, 200] });
        shown++;
      }
    }
  } catch (err) {}
  if (!shown) await self.registration.showNotification('T-Matches', { body: 'بدأت مباراة تتابعها ⚽', icon: 'icon-192.png', tag: 'generic' });
})()));
self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(clients.matchAll({ type: 'window', includeUncontrolled: true }).then(l => l.length ? l[0].focus() : clients.openWindow('./')));
});
