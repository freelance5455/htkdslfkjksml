// Service Worker für Tagklar - sorgt für Offline-Nutzung und macht die App auf
// iOS/Android/Desktop "installierbar" (Add to Home Screen). Sendet KEINE Push-
// Benachrichtigungen im Hintergrund - siehe Erklärung im Chat, warum das mit reinem
// clientseitigem Code (ohne eigenen Push-Server) auf iOS nicht zuverlässig möglich ist.

const CACHE_NAME = 'tagklar-v3';
const NETWORK_TIMEOUT_MS = 1500;
const APP_SHELL = [
  './',
  './index.html',
  './styles.css',
  './main.js',
  './ui.js',
  './storage.js',
  './recurrence.js',
  './notifications.js',
  './i18n.js',
  './backup.js',
  './ics.js',
  './crypto.js',
  './cloud-backup.js',
  './manifest.webmanifest',
  './icons/icon-72.png',
  './icons/icon-96.png',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/apple-touch-icon.png',
  './icons/favicon-16.png',
  './icons/favicon-32.png',
  './icons/favicon-512.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => Promise.all(
      APP_SHELL.map((url) => cache.add(url).catch(() => {})),
      // .catch() pro Datei: fehlt z.B. cloud-backup.js bewusst (optionales Feature),
      // soll das die Installation des restlichen Caches nicht verhindern.
    )).then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(
      keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)),
    )).then(() => self.clients.claim()),
  );
});

// Network-first mit kurzem Timeout: Solange eine Antwort vom Server innerhalb von
// NETWORK_TIMEOUT_MS ankommt, gewinnt sie - man bekommt also (fast) immer die aktuelle
// Version. Braucht das Netzwerk länger (schlechte Verbindung) oder ist gar keins da,
// wird sofort auf die zwischengespeicherte Version zurückgefallen, statt unbegrenzt zu
// warten. Die Netzwerk-Antwort aktualisiert den Cache in jedem Fall im Hintergrund
// weiter, sobald sie eintrifft - auch wenn der Timeout schon gewonnen hat.
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const networkPromise = fetch(event.request).then((response) => {
      if (response && response.ok) cache.put(event.request, response.clone());
      return response;
    }).catch(() => null);

    const timeoutPromise = new Promise((resolve) => { setTimeout(() => resolve(null), NETWORK_TIMEOUT_MS); });

    const fast = await Promise.race([networkPromise, timeoutPromise]);
    if (fast) return fast;

    const cached = await cache.match(event.request);
    if (cached) return cached;

    // Kein Cache vorhanden (z.B. allererster Aufruf) - dann doch auf die eventuell
    // langsame Netzwerkantwort warten, lieber spät als gar keine Antwort.
    const late = await networkPromise;
    return late || Response.error();
  })());
});
