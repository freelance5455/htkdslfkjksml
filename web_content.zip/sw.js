/* Service worker do SUPREM CAMPEONATO: rede primeiro, cache como reserva (abre mesmo sem internet) */
const C = 'suprem-v1';
const FILES = ['./', './index.html', './manifest.json', './icon-192.png', './icon-512.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(C).then(c => c.addAll(FILES))); self.skipWaiting(); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== C).map(x => caches.delete(x)))));
  self.clients.claim();
});
self.addEventListener('fetch', e => {
  const u = e.request.url;
  // só guarda arquivos do próprio site, do Tailwind e das fontes (nunca chamadas ao Supabase)
  if (e.request.method !== 'GET' || !(u.startsWith(self.location.origin) || /tailwindcss|fonts\.(googleapis|gstatic)/.test(u))) return;
  e.respondWith(fetch(e.request).then(r => { const cp = r.clone(); caches.open(C).then(c => c.put(e.request, cp)); return r; }).catch(() => caches.match(e.request)));
});
