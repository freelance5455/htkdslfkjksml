'use strict';
const CACHE_NAME = 'mnd-hub-shell-v14';
const APP_SHELL = ['/', '/manifest.webmanifest', '/assets/mnd-icon-192.png', '/assets/mnd-icon-512.png', '/assets/mnd-splash-logo.png', '/assets/apple-touch-icon.png'];
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await Promise.all(APP_SHELL.map(async url => { try { const response = await fetch(url, {cache:'reload'}); if (response.ok) await cache.put(url, response); } catch (_) {} }));
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith('mnd-hub-shell-') && key !== CACHE_NAME).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET' || new URL(event.request.url).origin !== self.location.origin) return;
  event.respondWith((async () => {
    try {
      const response = await fetch(event.request);
      if (response && response.ok && response.type === 'basic') {
        const cache = await caches.open(CACHE_NAME);
        cache.put(event.request, response.clone()).catch(() => {});
      }
      return response;
    } catch (_) {
      const cached = await caches.match(event.request);
      if (cached) return cached;
      if (event.request.mode === 'navigate') return (await caches.match('/')) || Response.error();
      return Response.error();
    }
  })());
});
self.addEventListener('push', event => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch (_) { data = {body: event.data ? event.data.text() : ''}; }
  const isCall = data.type === 'call';
  const options = {body:data.body || 'New update available.', icon:'/assets/mnd-icon-192.png', badge:'/assets/mnd-icon-192.png', vibrate:isCall?[500,1000,500,1000,500]:[200,100,200], requireInteraction:isCall, data:{url:data.url || '/'}, actions:isCall?[{action:'answer',title:'Open'},{action:'decline',title:'Dismiss'}]:[]};
  event.waitUntil(self.registration.showNotification(data.title || 'MND Hub', options));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  if (event.action === 'decline') return;
  const target = new URL((event.notification.data && event.notification.data.url) || '/', self.location.origin).href;
  event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(list => {
    for (const client of list) if (client.url === target && 'focus' in client) return client.focus();
    return self.clients.openWindow ? self.clients.openWindow(target) : undefined;
  }));
});
