/* PCM TRACKER service worker.
 * Caches every app resource on first online visit so the app opens offline.
 * Study data lives in localStorage on the device, so updating this file never resets progress.
 * Bump CACHE_VERSION whenever app files change so clients pick up the new version.
 */
var CACHE_VERSION = 'v1';
var CACHE = 'pcm-tracker-' + CACHE_VERSION;
var ASSETS = [
  './',
  './index.html',
  './styles.css',
  './data.js',
  './app.js',
  './manifest.json',
  './offline.html',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png',
  './icons/apple-touch-icon.png'
];

self.addEventListener('install', function (event) {
  event.waitUntil(
    caches.open(CACHE).then(function (c) { return c.addAll(ASSETS); }).then(function () {
      return self.skipWaiting();
    })
  );
});

self.addEventListener('activate', function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.filter(function (k) { return k.indexOf('pcm-tracker-') === 0 && k !== CACHE; })
        .map(function (k) { return caches.delete(k); }));
    }).then(function () { return self.clients.claim(); })
  );
});

self.addEventListener('message', function (event) {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', function (event) {
  var req = event.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  var isNav = req.mode === 'navigate';
  event.respondWith(
    caches.match(isNav ? './index.html' : req, { ignoreSearch: true }).then(function (cached) {
      var network = fetch(req).then(function (res) {
        if (res && res.status === 200 && res.type === 'basic') {
          var copy = res.clone();
          caches.open(CACHE).then(function (c) { c.put(isNav ? './index.html' : req, copy); });
        }
        return res;
      }).catch(function () { return null; });

      if (cached) { network.catch(function () {}); return cached; }
      return network.then(function (res) {
        if (res) return res;
        if (isNav) return caches.match('./offline.html');
        return new Response('Offline', { status: 503, statusText: 'Offline' });
      });
    })
  );
});
