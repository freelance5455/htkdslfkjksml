var CACHE = 'm1li-v18';
var SHELL = ['./', 'index.html', 'shop.js', 'm1li-views.js', 'products.json', 'config.js', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'icon-maskable-512.png', 'design.css', 'home.css', 'apps-extra.js', 'cover.png'];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(CACHE).then(function (c) { return Promise.all(SHELL.map(function (u) { return c.add(u).catch(function () {}); })); }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (keys) {
    return Promise.all(keys.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});
self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return;
  if (url.hostname === 'accounts.google.com' || url.hostname === 'www.googleapis.com') return;   // Google Sign-In: لا تخزين
  if (url.pathname.indexOf('/api/') !== -1) return;   // طلبات السيرفر (عدّادات/توكنات) لا تُخزَّن أبداً
  var sameOrigin = url.origin === location.origin;
  // network-first: المنتجات والصفحة تتحدث دائماً عند وجود إنترنت
  if (sameOrigin) {
    e.respondWith(fetch(req).then(function (res) {
      if (res && res.ok) { var copy = res.clone(); caches.open(CACHE).then(function (c) { c.put(req, copy); }).catch(function () {}); }
      return res;
    }).catch(function () { return caches.match(req).then(function (m) { return m || caches.match('index.html'); }); }));
  } else {
    // CDN (Tailwind / FontAwesome / Fonts): cache-first
    e.respondWith(caches.match(req).then(function (m) {
      return m || fetch(req).then(function (res) {
        if (res && (res.ok || res.type === 'opaque')) { var copy = res.clone(); caches.open(CACHE).then(function (c) { c.put(req, copy); }).catch(function () {}); }
        return res;
      });
    }));
  }
});
