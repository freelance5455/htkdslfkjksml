const C="masarif-v1",FILES=["./","index.html","manifest.json","icon-192.png","icon-512.png"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting()))});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==C).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener("fetch",e=>{if(e.request.method!=="GET")return;
 e.respondWith(caches.match(e.request,{ignoreSearch:true}).then(r=>r||fetch(e.request).then(n=>{const cp=n.clone();caches.open(C).then(c=>c.put(e.request,cp));return n}).catch(()=>e.request.mode==="navigate"?caches.match("index.html"):Response.error())))});
function readS(){return new Promise(res=>{const r=indexedDB.open("masarif",1);r.onupgradeneeded=()=>r.result.createObjectStore("k");r.onerror=()=>res(null);
 r.onsuccess=()=>{try{const g=r.result.transaction("k").objectStore("k").get("S");g.onsuccess=()=>res(g.result);g.onerror=()=>res(null)}catch(x){res(null)}}})}
async function check(){const S=await readS();if(!S||!S.exp)return;const d=new Date(),p=n=>String(n).padStart(2,"0"),m=d.getFullYear()+"-"+p(d.getMonth()+1),t=m+"-"+p(d.getDate());
 if(S.lastNotif===t)return;const sp=f=>S.exp.filter(e=>e.d.slice(0,7)===m&&f(e)).reduce((a,e)=>a+e.a,0),B=S.budgets||{};
 const o=Object.keys(B).filter(k=>sp(e=>e.t===k)>B[k]),T=S.total||0,ov=T>0&&sp(()=>true)>T;if(!o.length&&!ov)return;
 await self.registration.showNotification("مصاريفي — تنبيه",{body:(ov?"تجاوزت الحد الإجمالي للمصاريف. ":"")+(o.length?"تجاوزت الحد في: "+o.join("، "):""),icon:"icon-192.png",tag:"over",lang:"ar",dir:"rtl"})}
self.addEventListener("periodicsync",e=>{if(e.tag==="daily-check")e.waitUntil(check())});
self.addEventListener("notificationclick",e=>{e.notification.close();e.waitUntil(self.clients.matchAll({type:"window"}).then(cs=>cs.length?cs[0].focus():self.clients.openWindow("./")))});
