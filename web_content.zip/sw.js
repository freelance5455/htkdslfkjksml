const CACHE = 'mkfonts-v22';
const ASSETS = [
  './', './index.html', './manifest.json', './purno-guide.ttf',
  './ui-fonts/MiSansBengali-Thin.woff', './ui-fonts/MiSansBengali-ExtraLight.woff', './ui-fonts/MiSansBengali-Light.woff', './ui-fonts/MiSansBengali-Normal.woff', './ui-fonts/MiSansBengali-Regular.woff', './ui-fonts/MiSansBengali-Medium.woff', './ui-fonts/MiSansBengali-DemiBold.woff', './ui-fonts/MiSansBengali-SemiBold.woff', './ui-fonts/MiSansBengali-Bold.woff', './ui-fonts/MiSansBengali-Heavy.woff',
  './logo.png', './icon-192.png', './icon-512.png', './maskable-192.png', './maskable-512.png', './apple-touch-icon.png', './favicon-32.png'
];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  const isDoc = req.mode === 'navigate' || url.pathname.endsWith('/') || url.pathname.endsWith('.html');
  const store = res => { if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); } return res; };
  if (isDoc) {
    // পেজ: আগে নেটওয়ার্ক (নতুন সংস্করণ সাথে সাথে আসে), না পেলে বা ধীর হলে সংরক্ষিত কপি
    const net = fetch(req).then(store);
    e.respondWith(
      Promise.race([net, new Promise((_, rej) => setTimeout(rej, 4000))])
        .catch(() => caches.match(req).then(h => h || caches.match('./index.html')))
    );
    return;
  }
  e.respondWith(caches.match(req).then(hit => hit || fetch(req).then(store)));
});
