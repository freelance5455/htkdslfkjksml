// Offline cache für die Browser/PWA-Version. Die native Android-App enthält die Dateien direkt im APK-Paket.
const V = 'chefkalk-app-v2';
const DATEIEN = ['./', 'index.html', 'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-180.png', 'icons/icon-maskable-512.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(V).then(c => c.addAll(DATEIEN)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== V).map(x => caches.delete(x)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);
  if (url.origin !== location.origin) return;
  e.respondWith(caches.open(V).then(async c => {
    const hit = await c.match(e.request, { ignoreSearch: true });
    const netz = fetch(e.request).then(r => { if (r && r.ok) c.put(e.request.mode === 'navigate' ? 'index.html' : e.request, r.clone()); return r; }).catch(() => null);
    return hit || (await netz) || (e.request.mode === 'navigate' ? c.match('index.html') : Response.error());
  }));
});
