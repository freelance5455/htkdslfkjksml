const CACHE="kali-academy-v1";
const FILES=["./","./index.html","./manifest.json","./assets/mohammad_khaled.jpg","./assets/ahmed_avatar.png"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES))));
self.addEventListener("fetch",e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
