const V='ams-v3';
const F=['./','index.html','css/style.css','css/polish.css','js/main.js','js/extras.js','js/polish.js','manifest.webmanifest','icon-192.png','icon-512.png'];
const APP=new Set(F.map(x=>new URL(x,self.location.href).href));
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(F)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x.startsWith('ams-')&&x!==V).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const r=e.request;
  if(r.method!=='GET'||new URL(r.url).origin!==self.location.origin||!APP.has(r.url))return;
  e.respondWith(fetch(r).then(res=>{
    if(res.ok&&res.type==='basic')caches.open(V).then(c=>c.put(r,res.clone())).catch(()=>{});
    return res;
  }).catch(async()=>await caches.match(r)||Response.error()));
});
