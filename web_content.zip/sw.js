/* Errata service worker: precaches the whole app so it works offline.
   The version and file list below are filled in by scripts/build.mjs. */
const VERSION = 'd6543bfac9';
const CACHE = `errata-${VERSION}`;
const PRECACHE = [
  "./",
  "./assets/app-37749dafc2.css",
  "./assets/app-4EVU3VXG.js",
  "./assets/fonts/KaTeX_AMS-Regular.woff2",
  "./assets/fonts/KaTeX_Caligraphic-Bold.woff2",
  "./assets/fonts/KaTeX_Caligraphic-Regular.woff2",
  "./assets/fonts/KaTeX_Fraktur-Bold.woff2",
  "./assets/fonts/KaTeX_Fraktur-Regular.woff2",
  "./assets/fonts/KaTeX_Main-Bold.woff2",
  "./assets/fonts/KaTeX_Main-BoldItalic.woff2",
  "./assets/fonts/KaTeX_Main-Italic.woff2",
  "./assets/fonts/KaTeX_Main-Regular.woff2",
  "./assets/fonts/KaTeX_Math-BoldItalic.woff2",
  "./assets/fonts/KaTeX_Math-Italic.woff2",
  "./assets/fonts/KaTeX_SansSerif-Bold.woff2",
  "./assets/fonts/KaTeX_SansSerif-Italic.woff2",
  "./assets/fonts/KaTeX_SansSerif-Regular.woff2",
  "./assets/fonts/KaTeX_Script-Regular.woff2",
  "./assets/fonts/KaTeX_Size1-Regular.woff2",
  "./assets/fonts/KaTeX_Size2-Regular.woff2",
  "./assets/fonts/KaTeX_Size3-Regular.woff2",
  "./assets/fonts/KaTeX_Size4-Regular.woff2",
  "./assets/fonts/KaTeX_Typewriter-Regular.woff2",
  "./assets/katex-c9eac1c75c.css",
  "./icons/apple-touch-icon.png",
  "./icons/favicon-32.png",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon-maskable-512.png",
  "./index.html",
  "./manifest.webmanifest"
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(PRECACHE.map((u) => new Request(u, { cache: 'reload' })))),
  );
  /* No skipWaiting here: a new version waits until the student chooses to update,
     so a test in progress is never disturbed. */
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith('errata-') && k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  if (req.mode === 'navigate') {
    event.respondWith(
      caches.match('./index.html').then((hit) => hit || fetch(req)),
    );
    return;
  }
  event.respondWith(
    caches.match(req).then(
      (hit) =>
        hit ||
        fetch(req).then((res) => {
          if (res.ok) {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
          }
          return res;
        }),
    ),
  );
});
