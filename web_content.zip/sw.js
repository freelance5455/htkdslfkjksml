const CACHE = 'dojo-zero-anime-v16';
const CORE = ['./', './index.html', './manifest.webmanifest', './icon-192.png', './icon-512.png', './portraits/fighter-1.svg', './portraits/fighter-2.svg', './portraits/fighter-3.svg', './portraits/fighter-4.svg', './portraits/fighter-5.svg', './portraits/fighter-6.svg', './portraits/fighter-7.svg', './portraits/fighter-8.svg', './portraits/fighter-9.svg'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  event.respondWith(caches.match(req).then(cached => {
    if (cached) return cached;
    return fetch(req).then(response => {
      if (response && response.ok) caches.open(CACHE).then(cache => cache.put(req, response.clone()));
      return response;
    }).catch(() => caches.match('./index.html'));
  }));
});
