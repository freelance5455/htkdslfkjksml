/* SONIQ MUSIC - Service Worker
   يخزّن ملفات الواجهة فقط. لا يخزّن الصوت ولا نتائج الـ API ولا الطلبات الخارجية. */

const CACHE_VERSION = 'v1';                 // غيّر الرقم (v2, v3...) عند كل تحديث للتطبيق
const CACHE_NAME = 'soniq-shell-' + CACHE_VERSION;

const APP_SHELL = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys
          .filter((k) => k.startsWith('soniq-shell-') && k !== CACHE_NAME)
          .map((k) => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);

  // الطلبات الخارجية (واجهات API، البث، الصور من مصادر أخرى) تمرّ مباشرة بلا تخزين
  if (url.origin !== self.location.origin) return;

  // طلبات الصوت/الفيديو (تستخدم Range) تمرّ مباشرة
  if (req.headers.has('range') || /\.(mp3|m4a|aac|ogg|wav|flac|mp4|webm)$/i.test(url.pathname)) return;

  // فتح التطبيق: الشبكة أولاً (للحصول على آخر نسخة)، ثم النسخة المخزّنة عند انقطاع الإنترنت
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((c) => c.put('./index.html', copy));
          return res;
        })
        .catch(() => caches.match('./index.html').then((r) => r || caches.match('./')))
    );
    return;
  }

  // باقي ملفات التطبيق: المخزّن أولاً مع تحديثه بالخلفية
  event.respondWith(
    caches.match(req).then((cached) => {
      const network = fetch(req)
        .then((res) => {
          if (res && res.status === 200) {
            const copy = res.clone();
            caches.open(CACHE_NAME).then((c) => c.put(req, copy));
          }
          return res;
        })
        .catch(() => cached);
      return cached || network;
    })
  );
});
