/* UrbaAlerte — service worker : coque d'application hors ligne + cache des tuiles consultées */
const V='urbaalerte-v1',TILES='urbaalerte-tiles-v1';
const SHELL=['./','index.html','manifest.webmanifest','css/fonts.css','css/app.css','js/config.js','js/util.js','js/db.js','js/geo.js','js/api.js','js/risk.js','js/map.js','js/demo.js','js/app.js','js/screens.js','js/report.js',
'assets/fonts/inter-400.woff','assets/fonts/inter-500.woff','assets/fonts/inter-600.woff','assets/fonts/display-700.woff','assets/fonts/display-800.woff','assets/fonts/mono-400.woff',
'assets/icons/icon-192.png','assets/icons/icon-512.png','assets/icons/icon-96.png','assets/anim/splash-radar.svg','assets/anim/pulse-alert.svg','assets/anim/onb-signaler.svg','assets/anim/onb-localiser.svg','assets/anim/onb-alerte.svg',
'assets/illustrations/collines-aube.jpg','assets/illustrations/vallee-lukaya.jpg','assets/illustrations/quartier-colline.jpg','assets/illustrations/erosion-ravin.jpg','assets/illustrations/reseau-alerte.jpg'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>Promise.all(SHELL.map(u=>c.add(u).catch(()=>{})))).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V&&x!==TILES).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET')return;const u=new URL(r.url);
 if(/tile\.openstreetmap|tiles?\./.test(u.host)){e.respondWith(caches.open(TILES).then(async c=>{const hit=await c.match(r);const net=fetch(r).then(x=>{if(x.ok||x.type==='opaque'){c.put(r,x.clone());c.keys().then(k=>{if(k.length>400)c.delete(k[0])})}return x}).catch(()=>hit);return hit||net}));return}
 if(u.origin!==location.origin)return;
 e.respondWith(caches.match(r,{ignoreSearch:true}).then(h=>h||fetch(r).then(x=>{if(x.ok){const cp=x.clone();caches.open(V).then(c=>c.put(r,cp))}return x}).catch(()=>caches.match('index.html'))))});
self.addEventListener('notificationclick',e=>{e.notification.close();e.waitUntil(self.clients.matchAll({type:'window'}).then(l=>l.length?l[0].focus():self.clients.openWindow('./index.html')))});
