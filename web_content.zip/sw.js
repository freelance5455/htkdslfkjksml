const CACHE='sdh-offline-v10';
const CORE=['./','./index.html','./manifest.webmanifest','./icon.svg','./sw.js'];

self.addEventListener('install',event=>{
  event.waitUntil((async()=>{
    const cache=await caches.open(CACHE);
    for(const url of CORE){
      try{await cache.add(new Request(url,{cache:'reload'}));}catch(e){}
    }
    await self.skipWaiting();
  })());
});

self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    const keys=await caches.keys();
    await Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET') return;
  const req=event.request;
  event.respondWith((async()=>{
    const cached=await caches.match(req);
    if(cached) return cached;
    try{
      const response=await fetch(req);
      if(response && response.ok && new URL(req.url).origin===self.location.origin){
        const cache=await caches.open(CACHE);
        cache.put(req,response.clone()).catch(()=>{});
      }
      return response;
    }catch(e){
      if(req.mode==='navigate' || req.destination==='document'){
        return (await caches.match('./index.html')) || (await caches.match('./')) || new Response('Offline',{status:503});
      }
      return (await caches.match(req)) || (await caches.match('./index.html')) || new Response('',{status:503});
    }
  })());
});
