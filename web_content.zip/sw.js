const CACHE = 'app-v1';
const FILES = [
  './'i.html',
  './2.jpg',
  './'3.html',
   './'3.png',
    './'4.html',
    './'4.png',
     './'5.html',
     './'6.html',
     './'6.png',
      './'7.html',
      './'7.jpg',
       './'8.html',
        './'A.html',
        './'A.jpg',
         './'B.html',
         './'B.jpg',
          './'B1.html',
          './'B1.jpg',
           './'index.html',
           './'c.jpg',
           './'c.mp4',
           
  './manifest.json'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)));
  self.skipWaiting();
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(res => res || fetch(e.request))
  );
});