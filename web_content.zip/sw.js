const CACHE_V5_HOLD = 'korbball-v5-hold-mic-1';
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE_V5_HOLD).then(c => c.addAll(['./', './index.html', './manifest.json'])));
});
self.addEventListener('fetch', e => {
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});
