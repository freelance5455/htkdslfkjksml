/* Gali Rush service worker: caches the game so it opens offline. Bump VERSION after every update. */
const VERSION='gali-rush-v3';
const SHELL=['./','index.html','manifest.webmanifest','icons/icon-192.png','icons/icon-512.png','icons/maskable-512.png','icons/apple-touch-icon.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(VERSION).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==VERSION).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const r=e.request;if(r.method!=='GET')return;
  const u=new URL(r.url);
  if(u.origin===location.origin){
    e.respondWith(caches.match(r,{ignoreSearch:true}).then(hit=>hit||fetch(r).then(res=>{
      if(res.ok){const cp=res.clone();caches.open(VERSION).then(c=>c.put(r,cp))}return res
    }).catch(()=>r.mode==='navigate'?caches.match('index.html'):Response.error())));
    return;
  }
  if(/fonts\.(googleapis|gstatic)\.com$/.test(u.hostname)){
    e.respondWith(caches.open(VERSION).then(c=>c.match(r).then(hit=>{
      const net=fetch(r).then(res=>{c.put(r,res.clone());return res}).catch(()=>hit||Response.error());
      return hit||net;
    })));
  }
});
