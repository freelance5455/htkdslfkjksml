/* Offline cache for local assets (stale-while-revalidate). Bump VERSION on release. */
const VERSION='kartino-v7';
const ASSETS=['./','index.html','css/images.css','css/style.css','css/desktop.css','css/perf-mobile.css','css/mobile.css','js/effects.js','js/fallback.js','vendor/jquery.min.js','js/app.js','js/desktop.js','js/mobile.js',
 'images/cl.webp','images/cr.webp','images/login.webp','images/lounge.webp','images/table.webp','images/icon.svg','images/kartino-logo.png','images/payment-card.png','manifest.webmanifest'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(VERSION).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==VERSION).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
 const u=new URL(e.request.url);
 if(e.request.method!=='GET'||u.origin!==location.origin||u.pathname.startsWith('/api/'))return;
 e.respondWith(caches.open(VERSION).then(c=>c.match(e.request).then(hit=>{
  const net=fetch(e.request).then(r=>{if(r.ok)c.put(e.request,r.clone());return r}).catch(()=>hit);
  return hit||net;
 })));
});
