const CACHE_NAME = 'pikalango-v1';
const ASSETS = [
  'index.html',
  'manifest.json',
  'pikachu_happy.jpg',
  'pikachu_celebrate.jpg',
  'pikachu_jump.jpg',
  'pikachu_sad.jpg',
  'pikachu_wave.jpg',
  'pikachu_surprised.jpg',
  'audio/hola_como_estas.mp3',
  'audio/buenos_dias.mp3',
  'audio/cafe_por_favor.mp3',
  'audio/dialogo_cafe.mp3',
  'audio/donde_estacion.mp3',
  'audio/presentacion.mp3',
  'audio/cuanto_cuesta.mp3',
  'audio/reservar_mesa.mp3',
  'audio/dialogo_dia.mp3'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))
  );
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(res => res || fetch(e.request))
  );
});