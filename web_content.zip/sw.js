/* Donghua Core 4K service worker
   শুধু নিজের সাইটের ফাইল ক্যাশ করে। ভিডিও, Firebase, Google Sheets, YouTube কখনো ক্যাশ/আটকানো হয় না।
   অ্যাপ আপডেট দিলে নিচের VERSION সংখ্যা বাড়ান। */
/* OneSignal পুশ নোটিফিকেশন (নেট না থাকলেও সার্ভিস ওয়ার্কার যেন না ভাঙে) */
try { importScripts("https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.sw.js"); } catch (e) {}

const VERSION = "v1-10";
const CACHE = "dc-" + VERSION;
const SHELL = ["/", "/manifest.json", "/icons/icon-192-v2.png", "/icons/icon-512-v2.png", "/icons/apple-touch-icon-v2.png"];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL).catch(() => {})).then(() => self.skipWaiting()));
});

self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith("dc-") && k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== "GET" || u.origin !== location.origin) return;       /* অন্য সার্ভার ছুঁইনা */
  if (r.headers.has("range")) return;                                    /* ভিডিও রেঞ্জ রিকোয়েস্ট ছুঁইনা */
  if (u.pathname === "/sw.js") return;

  /* পেজ: আগে নেটওয়ার্ক (সবসময় নতুন), না পেলে ক্যাশ */
  if (r.mode === "navigate") {
    e.respondWith(
      fetch(r).then(res => {
        if (res.ok) { const c = res.clone(); caches.open(CACHE).then(x => x.put("/", c)); }
        return res;
      }).catch(() => caches.match("/").then(m => m || new Response("Offline / অফলাইন", { status: 503, headers: { "Content-Type": "text/plain; charset=utf-8" } })))
    );
    return;
  }

  /* আইকন ও স্ট্যাটিক ফাইল: ক্যাশ আগে, পেছনে আপডেট */
  e.respondWith(
    caches.match(r).then(m => {
      const net = fetch(r).then(res => {
        if (res.ok) { const c = res.clone(); caches.open(CACHE).then(x => x.put(r, c)); }
        return res;
      }).catch(() => m);
      return m || net;
    })
  );
});
