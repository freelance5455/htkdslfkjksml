// Incrementa o cache quando o shell muda para que instalações PWA não
// continuem a servir uma versão anterior dos arquivos móveis.
const SHELL_CACHE = 'myfanalist-shell-v55';
const COVER_CACHE = 'myfanalist-covers-v1';
// Estes ficheiros são indispensáveis para abrir e usar o app offline.
// Se qualquer um falhar, a instalação do service worker falha em vez de
// deixar o app instalado sem conseguir iniciar.
const REQUIRED_SHELL_FILES = [
  './', './index.html', './styles-mobile.css', './app-mobile.js', './manifest.json',
  './vendor/html2canvas.min.js', './vendor/jspdf.umd.min.js'
];
// Os recursos visuais são opcionais para o arranque, mas também ficam
// disponíveis offline quando existem no pacote.
const SHELL_FILES = [
  './', './index.html', './styles-mobile.css', './app-mobile.js', './manifest.json',
  './favicon.ico', './icons/icon-192.png', './icons/icon-512.png', './icons/icon-maskable-512.png', './icons/apple-touch-icon.png', './icons/default-avatar.svg',
  './icons/avatar-cat.svg', './icons/avatar-flower.svg', './icons/avatar-fox.svg',
  './icons/avatar-rabbit.svg', './icons/avatar-star.svg',
  // As imagens de fundo (app + teclado) entram no pré-cache do shell para
  // ficarem prontas já na instalação, em vez de só serem buscadas (e
  // demorarem a aparecer) na primeira vez que a tela ou o teclado abrem.
  './app-bg.jpg', './anime-bg.jpg'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(SHELL_CACHE)
      .then(async cache => {
        await Promise.all(REQUIRED_SHELL_FILES.map(url => cache.add(url)));
        await Promise.all(SHELL_FILES
          .filter(url => !REQUIRED_SHELL_FILES.includes(url))
          .map(url => cache.add(url).catch(() => null)));
      })
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys
        .filter(key => (key.startsWith('acervo-shell-') || key.startsWith('myfanalist-shell-')) && key !== SHELL_CACHE)
        .map(key => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const req = event.request;

  if(req.destination === 'image'){
    event.respondWith(
      caches.match(req).then(cached => {
        if(cached) return cached;
        return fetch(req).then(res => {
          if(res && (res.ok || res.type === 'opaque')){
            const clone = res.clone();
            caches.open(COVER_CACHE).then(cache => cache.put(req, clone)).catch(() => {});
          }
          return res;
        }).catch(() => new Response('', {
          status: 504,
          statusText: 'Imagem indisponível offline'
        }));
      })
    );
    return;
  }

  const url = new URL(req.url);
  if(url.origin === location.origin && req.method === 'GET'){
    // BUGFIX (abertura lenta pelo atalho instalado / às vezes trava no
    // navegador): a estratégia era "rede primeiro" — TODA abertura do app
    // esperava uma resposta de rede completa antes de mostrar qualquer
    // coisa, mesmo já havendo uma cópia boa em cache. Numa rede lenta ou
    // instável isso trava a abertura por vários segundos (ou indefinidamente,
    // já que uma rede lenta não conta como falha e por isso nunca cai no
    // fallback do cache). Agora é "cache primeiro": responde na hora com o
    // que já está em cache (abertura instantânea) e atualiza o cache em
    // segundo plano para a próxima vez — só usa a rede se não houver nada
    // em cache ainda.
    event.respondWith(
      caches.match(req).then(cached => {
        const networkUpdate = fetch(req).then(res => {
          if(res && res.ok){
            const clone = res.clone();
            caches.open(SHELL_CACHE).then(cache => cache.put(req, clone)).catch(() => {});
          }
          return res;
        }).catch(() => null);
        if(cached) return cached;
        return networkUpdate.then(res => res || caches.match('./index.html'));
      })
    );
  }
});
