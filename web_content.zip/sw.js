// Caches the app shell so repeat opens are fast, but it is network-first:
// it always tries the real network first and only falls back to a saved
// copy when the network truly fails, so you never get stuck on an old
// broken version. It never caches Firebase requests, so your data is
// always fetched live, never served stale from this cache.
const CACHE = 'inexa-shell-v2';
const SHELL = ['./', './index.html', './manifest.json', './icons/icon-192.png', './icons/icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(async c => {
      // Cache each file one at a time so one missing file doesn't block the rest.
      await Promise.all(SHELL.map(url => c.add(url).catch(() => {})));
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
  );
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  const url = e.request.url;
  if (e.request.method !== 'GET' || url.includes('googleapis.com') || url.includes('firebaseio.com') || url.includes('gstatic.com/firebasejs')) return;
  e.respondWith((async () => {
    try {
      const net = await fetch(e.request);
      if (net && net.ok) {
        const c = await caches.open(CACHE);
        c.put(e.request, net.clone());
      }
      return net;
    } catch (err) {
      // Network failed (e.g. a weak signal): fall back to a saved copy if we have one.
      const cached = await caches.match(e.request);
      if (cached) return cached;
      // No saved copy either: answer with something, never leave it unanswered.
      return new Response(
        'You appear to be offline and this page was not saved yet. Please reconnect and reload.',
        { status: 503, statusText: 'Offline', headers: { 'Content-Type': 'text/plain' } }
      );
    }
  })());
});
