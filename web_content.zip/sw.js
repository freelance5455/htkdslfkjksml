const CACHE='blackwood-v1';
const ASSETS=['./','./index.html','./manifest.webmanifest','./assets/study.jpg','./assets/eleanor.jpg','./assets/brandy.jpg','./assets/fireplace.jpg','./assets/inventory.jpg','./assets/suspects.jpg','./assets/notebook.jpg','./assets/accusation.jpg','./assets/icon-192.png','./assets/icon-512.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener('fetch',e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
