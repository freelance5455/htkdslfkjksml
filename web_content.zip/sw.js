const CACHE="cpr-metronome-smooth-v2";
const FILES=["./","./index.html","./manifest.webmanifest","./icons/cpr.svg"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES))));
self.addEventListener("activate",e=>e.waitUntil(self.clients.claim()));
self.addEventListener("fetch",e=>{
 if(e.request.method!=="GET")return;
 e.respondWith(caches.match(e.request).then(c=>c||fetch(e.request).then(r=>{
  const copy=r.clone(); caches.open(CACHE).then(cache=>cache.put(e.request,copy)); return r;
 })));
});
