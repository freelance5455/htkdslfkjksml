const C='blindados-v1',F=['./','index.html','css/style.css','js/01-mundo.js','js/02-construcoes.js','js/03-veiculos-base.js','js/04-veiculos-novos.js','js/05-veiculos-outros.js','js/06-fisica-ia.js','js/07-danos-progressao.js','js/08-controles-loop.js','js/09-extras.js','manifest.json','icon-192.png','icon-512.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(F)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
/* guarda tambem three.js e a fonte na primeira visita, para abrir sem internet depois */
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(n=>{if(n&&(n.ok||n.type==='opaque')){const c=n.clone();caches.open(C).then(x=>x.put(e.request,c))}return n}).catch(()=>r)))});
