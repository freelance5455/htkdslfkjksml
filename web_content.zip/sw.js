const CACHE='unser-vorrat-v1';
const APP_SHELL=[
  './','./index.html','./manifest.json','./icon-192.png','./icon-512.png','./app-icon.png','./bat.png','./bat.svg',
  './assets/header-art.png','./assets/add-frame.png','./assets/stat-red.png','./assets/urgent-deco.png','./assets/nav-vorrat.png','./assets/nav-einkauf.png','./assets/urgent-frame.png','./assets/nav-rezepte.png','./assets/stat-purple.png','./assets/stat-orange.png','./assets/stat-article.png','./assets/add-deco.png'
];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(APP_SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const r=e.request;
  if(r.method!=='GET') return;
  const u=new URL(r.url);
  if(u.origin!==location.origin) return;
  e.respondWith(caches.match(r).then(cached=>cached||fetch(r).then(resp=>{const copy=resp.clone(); caches.open(CACHE).then(c=>c.put(r,copy)).catch(()=>{}); return resp}).catch(()=>caches.match('./index.html'))));
});
