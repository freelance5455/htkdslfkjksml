// Service Worker — permite o Chrome instalar como PWA
self.addEventListener('install', function(e) {
  self.skipWaiting();
});
self.addEventListener('activate', function(e) {
  e.waitUntil(self.clients.claim());
});
self.addEventListener('fetch', function(e) {
  // manipulador vazio: necessário para o Chrome reconhecer como instalável
});