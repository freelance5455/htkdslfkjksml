const C='youme-v2',A=['./','index.html','style.css','app.js','config.js','manifest.json','icon-192.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(A))));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||!e.request.url.startsWith(self.location.origin))return;
e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)))});
