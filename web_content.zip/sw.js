const CACHE='easuko-v4.0-learning-ai-1';
const ASSETS=['./','./index.html','./style.css','./script.js?v=4.0','./manifest.json','./ai/theme-brain.js?v=4.0','./ai/judge-brain.js?v=4.0','./ai/game-brain.js?v=4.0','./ai/memory-brain.js?v=4.0','./sw.js','./ai/engine.js?v=4.0','./ai/model.json?v=2','./ai/concepts.json?v=4','./assets/judge-girl.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(u.origin!==self.location.origin||e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request).then(res=>{const copy=res.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return res}).catch(()=>caches.match('./index.html'))))});
