/* Dhonnobad Foundation lightweight offline shell. Dynamic/private Firebase data is never cached. */
const CACHE_NAME = 'dhonnobad-shell-v2';
const CACHE_PREFIX = 'dhonnobad-shell-';
const APP_SHELL = ['./', './index.html', './style.css', './script.js', './manifest.json', './logo.png', './dhonnobad-ai-round-button.png'];
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key.startsWith(CACHE_PREFIX) && key !== CACHE_NAME).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET' || new URL(request.url).origin !== self.location.origin) return;
  event.respondWith(fetch(request).then((response) => {
    if (response && response.ok && request.destination !== 'document' && !request.url.includes('firebase')) {
      const copy = response.clone(); caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
    }
    return response;
  }).catch(() => caches.match(request).then((cached) => cached || (request.mode === 'navigate' ? caches.match('./index.html') : undefined))));
});
