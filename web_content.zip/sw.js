const C="mbattle-free-v7";
const ASSETS=["./free.html","./manifest.json","./icon-192.png","./icon-512.png","./index.html"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()))});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==C).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener("fetch",e=>{
 e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(res=>{
  if(e.request.method==="GET"&&res.status===200){const copy=res.clone();caches.open(C).then(c=>c.put(e.request,copy))}
  return res;
 }).catch(()=>caches.match("./free.html"))))
});
