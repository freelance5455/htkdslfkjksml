const CACHE="offline-reels-v9";
const ROOT=self.registration.scope;
const APP=[ROOT,ROOT+"index.html",ROOT+"manifest.webmanifest",ROOT+"icons/icon-192.png",ROOT+"icons/icon-512.png"];
self.addEventListener("install",e=>e.waitUntil((async()=>{
  const c=await caches.open(CACHE);
  await Promise.all(APP.map(u=>c.add(u).catch(()=>{})));
  await self.skipWaiting();
})()));
self.addEventListener("activate",e=>e.waitUntil((async()=>{
  for(const k of await caches.keys()) if(k!==CACHE) await caches.delete(k);
  await self.clients.claim();
})()));
self.addEventListener("fetch",e=>{
  const r=e.request;
  if(r.method!=="GET"||new URL(r.url).origin!==location.origin)return;
  e.respondWith((async()=>{
    const cache=await caches.open(CACHE);
    let hit=await cache.match(r,{ignoreSearch:true});
    if(!hit&&r.mode==="navigate")hit=await cache.match(ROOT+"index.html");
    const net=fetch(r).then(res=>{if(res&&res.ok)cache.put(r,res.clone()).catch(()=>{});return res}).catch(()=>null);
    if(hit){e.waitUntil(net);return hit}
    return (await net)||new Response("Offline",{status:503});
  })());
});
