// Service worker for the standalone "Waves & Wish" PWA build.
// Strategy: cache-first for everything the game needs, so once the app has been
// opened a single time it launches and plays with no network at all.
//   - same-origin files (index.html, character.js, icons) are precached on install
//   - cross-origin art (the hero banners/splashes and the voice-line clips,
//     all hosted on uploads.dev) is cached lazily the first time it is
//     requested, then served from cache. So the hero voices become available
//     offline the first time each line is played (and the music the first time
//     each track is heard).
// Bump CACHE to invalidate old copies after a rebuild.
const CACHE = "waves-and-wish-v9";
const CORE = [
  "./",
  "./index.html",
  "./character.js",
  "./audio.js",
  "./manifest.json",
  "./manifest.webmanifest",
  "./icon-192.png",
  "./icon-512.png",
  "./icon-maskable-512.png",
  "./apple-touch-icon.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE)
      .then((cache) => cache.addAll(CORE))
      .then(() => self.skipWaiting())
      .catch(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.protocol !== "http:" && url.protocol !== "https:") return;
  if (url.origin === self.location.origin) {
    // same-origin: cache-first, falling back to the shell so the app still boots offline
    event.respondWith(
      caches.match(req, { ignoreSearch: true }).then((hit) => {
        if (hit) return hit;
        return fetch(req).then((res) => {
          if (res && res.ok) caches.open(CACHE).then((c) => c.put(req, res.clone()));
          return res;
        }).catch(() => caches.match("./index.html"));
      })
    );
    return;
  }
  // cross-origin art: cache-first, refreshed in the background
  event.respondWith(
    caches.match(req).then((hit) => {
      const network = fetch(req).then((res) => {
        if (res && (res.ok || res.type === "opaque")) caches.open(CACHE).then((c) => c.put(req, res.clone()));
        return res;
      }).catch(() => hit);
      return hit || network;
    })
  );
});
