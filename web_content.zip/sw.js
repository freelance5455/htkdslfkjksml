// Service worker: guarda los archivos de la app para poder abrirla sin conexión
const CACHE = 'video-color-v9';
const ARCHIVOS = [
    './',
    './index.html',
    './style.css',
    './script.js',
    './manifest.json',
    './icon-192.png',
    './icon-512.png',
    './icon-maskable-512.png'
];

self.addEventListener('install', (evento) => {
    evento.waitUntil(
        caches.open(CACHE).then((cache) => cache.addAll(ARCHIVOS))
    );
    self.skipWaiting();
});

self.addEventListener('activate', (evento) => {
    evento.waitUntil(
        caches.keys().then((claves) =>
            Promise.all(claves.filter((c) => c !== CACHE).map((c) => caches.delete(c)))
        )
    );
    self.clients.claim();
});

// Red primero (así siempre ves la última versión); sin conexión usa lo guardado
self.addEventListener('fetch', (evento) => {
    const peticion = evento.request;
    if (peticion.method !== 'GET' || !peticion.url.startsWith(self.location.origin)) {
        return;
    }
    evento.respondWith(
        fetch(peticion)
            .then((respuesta) => {
                const copia = respuesta.clone();
                caches.open(CACHE).then((cache) => cache.put(peticion, copia));
                return respuesta;
            })
            .catch(() => caches.match(peticion))
    );
});
