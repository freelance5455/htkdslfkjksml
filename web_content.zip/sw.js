const CACHE='tpgai-v1.5.1';
const ASSETS=['./','./index.html','./manifest.webmanifest','./icon.svg'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('tpgai-')&&key!==CACHE).map(key=>caches.delete(key))))));
self.addEventListener('fetch',event=>{
  const request=event.request;
  if(request.method!=='GET') return;
  const url=new URL(request.url);
  // Never intercept/cache live API requests or cross-origin requests.
  if(url.origin!==self.location.origin || url.pathname.startsWith('/.netlify/functions/')) return;
  if(request.cache==='no-store') return;
  event.respondWith(caches.match(request).then(cached=>cached||fetch(request).then(response=>{
    if(response.ok && response.type==='basic' && !response.headers.get('Cache-Control')?.includes('no-store')) {
      const copy=response.clone(); caches.open(CACHE).then(cache=>cache.put(request,copy));
    }
    return response;
  }).catch(()=>caches.match('./index.html'))));
});
