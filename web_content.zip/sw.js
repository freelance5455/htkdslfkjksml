const V='noor-v7',SHELL=['./','index.html','manifest.webmanifest','icon-192.png','icon-512.png','hero.jpg','v6.css','theme.css','apple-touch-icon.png','favicon.png','js/ui.js','js/core.js','js/audio.js','js/library.js','js/stats.js','js/learn.js','js/hifzai.js','js/surahs.js','js/remind.js','js/extras.js'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>Promise.all(SHELL.map(u=>c.add(u).catch(()=>{})))).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V&&x!=='jq-audio').map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const r=e.request,u=new URL(r.url);
  if(r.method!=='GET'||r.headers.has('range'))return;
  if(u.origin===location.origin){
    e.respondWith(fetch(r).then(x=>{if(x.ok){const c=x.clone();caches.open(V).then(h=>h.put(r,c))}return x}).catch(()=>caches.match(r).then(m=>m||caches.match('index.html'))));
    return;
  }
  if(/alquran\.cloud|aladhan\.com|fonts\.(googleapis|gstatic)\.com|^(www\.)?mp3quran\.net$/.test(u.host)){
    e.respondWith(caches.match(r).then(m=>{const f=fetch(r).then(x=>{if(x.ok){const c=x.clone();caches.open(V).then(h=>h.put(r,c))}return x}).catch(()=>m);return m&&/alquran\.cloud\/v1\/(quran|surah)\//.test(r.url)?m:f}));
  }
});
self.addEventListener('notificationclick',e=>{e.notification.close();const h=(e.notification.data&&e.notification.data.hash)||'';
  e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>{if(cs.length){cs[0].focus();cs[0].postMessage({hash:h});return}return self.clients.openWindow('./'+h)}))});
