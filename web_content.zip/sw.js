const CACHE = 'noor-shell-v12';
const DATA_CACHE = 'noor-quran-data-v2';
const SHELL = ['./','./index.html','./styles.css','./app.js','./manifest.webmanifest','./icon.svg','./assets/audio/adhan.mp3'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil((async()=>{const keys=await caches.keys();await Promise.all(keys.filter(k=>k.startsWith('noor-shell-')&&k!==CACHE).map(k=>caches.delete(k)));await self.clients.claim();})()));
self.addEventListener('fetch',event=>{
  const req=event.request;if(req.method!=='GET')return;
  const url=new URL(req.url);
  if(url.origin===self.location.origin){
    event.respondWith((async()=>{
      const cache=await caches.open(CACHE);
      try{const fresh=await fetch(req,{cache:'no-store'});if(fresh.ok)cache.put(req,fresh.clone());return fresh;}
      catch(error){const cached=await cache.match(req);if(cached)return cached;throw error;}
    })());
    return;
  }
  if(url.hostname==='api.alquran.cloud'||url.hostname==='api.aladhan.com'||url.hostname==='quranenc.com'){
    event.respondWith(fetch(req).then(res=>{if(res.ok){const copy=res.clone();caches.open(DATA_CACHE).then(async c=>{await c.put(req,copy);const keys=await c.keys();if(keys.length>45)await c.delete(keys[0]);});}return res;}).catch(()=>caches.match(req).then(cached=>cached||Promise.reject(new Error('Offline')))));
  }
});
