const CACHE="bubble-clicker-v2";
const ASSETS=["./","./index.html","./style.css","./app.js","./manifest.json","./icon.svg","./assets/background.png","./assets/top.png","./assets/achievements.png","./assets/shop.png","./assets/settings.png"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener("activate",e=>e.waitUntil(self.clients.claim()));
self.addEventListener("fetch",e=>{
  if(e.request.method!=="GET") return;
  e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request).then(r=>{
    const copy=r.clone(); caches.open(CACHE).then(c=>c.put(e.request,copy)); return r;
  }).catch(()=>cached)));
});
