// GestCom service worker : coque de l'app en cache, données toujours en ligne (Supabase)
const CACHE = 'gestcom-v1';
const SHELL = ['/', '/index.html', '/manifest.json', '/icon-192.png', '/icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  const url = new URL(req.url);
  // Jamais de cache pour les données (Supabase, API) ni pour les requêtes non-GET
  if (req.method !== 'GET' || url.origin !== self.location.origin) return;
  // Pages : réseau d'abord (toujours la dernière version), cache si hors ligne
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req).then(r => {
        const copy = r.clone(); caches.open(CACHE).then(c => c.put('/index.html', copy)); return r;
      }).catch(() => caches.match('/index.html'))
    );
    return;
  }
  // Fichiers statiques : cache d'abord, mise à jour en arrière-plan
  e.respondWith(
    caches.match(req).then(hit => {
      const net = fetch(req).then(r => {
        if (r.ok) { const copy = r.clone(); caches.open(CACHE).then(c => c.put(req, copy)); }
        return r;
      }).catch(() => hit);
      return hit || net;
    })
  );
});
