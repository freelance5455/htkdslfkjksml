const CACHE="nayeem-shell-v3";
const ASSETS=["./","./index.html","./style.css","./app.js","./firebase-config.js","./network.js"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener("fetch",e=>e.respondWith(caches.match(e.request).then(x=>x||fetch(e.request))));
