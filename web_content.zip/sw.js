/**
 * sw.js — hand-rolled service worker (no build tool, no CDN dependency).
 * Strategy: cache-first for the app shell, since this app has no server
 * and no remote data — everything it needs to run lives in this cache.
 */

const CACHE_VERSION = 'life-guide-v11';

const SHELL_ASSETS = [
  "./",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon-maskable-512.png",
  "./index.html",
  "./manifest.webmanifest",
  "./src/components/charts/canvasChart.js",
  "./src/components/icons.js",
  "./src/components/layout/celebrate.js",
  "./src/components/layout/greeting.js",
  "./src/components/layout/navBar.js",
  "./src/components/layout/quickAdd.js",
  "./src/components/modal.js",
  "./src/components/prayerCard.js",
  "./src/components/ui.js",
  "./src/core/intelligence/suggestionEngine.js",
  "./src/core/motivation/coach.js",
  "./src/core/motivation/quotes.js",
  "./src/core/native/bridge.js",
  "./src/core/notifications/reminderService.js",
  "./src/core/notifications/toast.js",
  "./src/core/prayer/prayerService.js",
  "./src/core/profile/prefsService.js",
  "./src/core/profile/profileService.js",
  "./src/core/router.js",
  "./src/core/scoring/scoreEngine.js",
  "./src/core/security/pinLock.js",
  "./src/core/stats/statsService.js",
  "./src/core/storage/backupService.js",
  "./src/core/storage/db.js",
  "./src/core/storage/storageService.js",
  "./src/core/tasks/taskEngine.js",
  "./src/core/utils/dateUtils.js",
  "./src/core/utils/eventBus.js",
  "./src/core/xp/achievements.js",
  "./src/core/xp/xpEngine.js",
  "./src/main.js",
  "./src/modules/body/fitness/fitnessService.js",
  "./src/modules/body/nutrition/nutritionService.js",
  "./src/modules/body/skin/skinService.js",
  "./src/modules/body/skin/skinTrackerService.js",
  "./src/modules/body/weight/weightService.js",
  "./src/modules/body/weight/weightUI.js",
  "./src/modules/dashboard/dashPrefs.js",
  "./src/modules/dashboard/quickActions.js",
  "./src/modules/discipline/habits/habitForm.js",
  "./src/modules/discipline/habits/habitsService.js",
  "./src/modules/discipline/routines/routinesService.js",
  "./src/modules/discipline/weeklyReview/weeklyReviewService.js",
  "./src/modules/mastery/masteryService.js",
  "./src/modules/mastery/masteryUI.js",
  "./src/modules/mind/anki/ankiService.js",
  "./src/modules/mind/flashcards/flashcardService.js",
  "./src/modules/mind/notes/notesService.js",
  "./src/modules/mind/pastQuestions/pastQuestionsService.js",
  "./src/modules/mind/pomodoro/pomodoroService.js",
  "./src/modules/mind/pomodoro/pomodoroUI.js",
  "./src/modules/mind/study/studyService.js",
  "./src/modules/mind/subjects/subjectsService.js",
  "./src/modules/mind/subjects/subjectsUI.js",
  "./src/modules/presence/confidence/confidenceService.js",
  "./src/modules/presence/grooming/groomingService.js",
  "./src/pages/AboutPage.js",
  "./src/pages/BodyPage.js",
  "./src/pages/Dashboard.js",
  "./src/pages/DisciplinePage.js",
  "./src/pages/MindPage.js",
  "./src/pages/PresencePage.js",
  "./src/pages/ProgressPage.js",
  "./src/pages/Settings.js",
  "./src/pages/settingsPanels.js",
  "./src/styles/globals.css",
  "./src/styles/tokens.css"
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) => cache.addAll(SHELL_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((key) => key !== CACHE_VERSION)
          .map((key) => caches.delete(key))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;

      return fetch(event.request)
        .then((response) => {
          const clone = response.clone();
          caches.open(CACHE_VERSION).then((cache) => cache.put(event.request, clone));
          return response;
        })
        .catch(() => caches.match('./index.html'));
    })
  );
});

// Listen for a manual "skip waiting" trigger from the update toast.
self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});
