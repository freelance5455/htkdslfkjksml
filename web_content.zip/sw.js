'use strict';
const CACHE='class-planner-pwa-v3';
const ASSETS=['/','/app.js','/icons.js','/manifest.json','/icon.svg','/icons/icon-192.png','/icons/icon-512.png'];

self.addEventListener('install',event=>{
  event.waitUntil((async()=>{
    const cache=await caches.open(CACHE);
    await Promise.all(ASSETS.map(async path=>{
      try { await cache.add(path); } catch (error) { /* Keep installation resilient if one optional asset is absent. */ }
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    const names=await caches.keys();
    await Promise.all(names.filter(name=>(name.startsWith('class-planner-')||name==='cp-v2')&&name!==CACHE).map(name=>caches.delete(name)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch',event=>{
  const request=event.request;
  if(request.method!=='GET') return;
  const url=new URL(request.url);
  if(url.origin!==self.location.origin||url.pathname.startsWith('/api/')||url.pathname.startsWith('/__')) return;

  if(request.mode==='navigate'){
    event.respondWith((async()=>{
      try {
        const response=await fetch(request);
        if(response.ok&&!response.redirected){const cache=await caches.open(CACHE);cache.put('/',response.clone()).catch(()=>{});}
        return response;
      } catch(error) {
        return (await caches.match(request))||(await caches.match('/'))||new Response('ഓഫ്‌ലൈൻ ആണ്. ഈ പേജ് മുമ്പ് തുറന്നിട്ടില്ലെങ്കിൽ ഇന്റർനെറ്റ് ലഭിക്കുമ്പോൾ വീണ്ടും ശ്രമിക്കുക.',{status:503,headers:{'Content-Type':'text/plain; charset=utf-8'}});
      }
    })());
    return;
  }

  event.respondWith((async()=>{
    const cached=await caches.match(request);
    if(cached)return cached;
    try {
      const response=await fetch(request);
      if(response.ok&&!response.redirected){const cache=await caches.open(CACHE);cache.put(request,response.clone()).catch(()=>{});}
      return response;
    } catch(error) {
      return new Response('',{status:504,statusText:'Offline'});
    }
  })());
});
