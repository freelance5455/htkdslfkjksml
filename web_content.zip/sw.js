/* Offline cache: app shell, cache-first with background refresh. Cross-origin requests are never touched. */
const VERSION = 'europath-2.1.0';
const SHELL = ['./', 'index.html', 'css/app.css', 'js/config.js', 'js/data.js', 'js/countries.js', 'js/i18n.js', 'js/i18n2.js', 'js/i18n3.js', 'js/store.js', 'js/art.js', 'js/wx.js', 'js/places.js', 'js/legal.js', 'js/app.js', 'manifest.webmanifest', 'icons/icon.svg', 'icons/icon-192.png', 'icons/icon-512.png', 'privacy.html', 'terms.html'];
self.addEventListener('install', e => { e.waitUntil(caches.open(VERSION).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== VERSION).map(x => caches.delete(x)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin) return;
  e.respondWith(caches.match(e.request).then(hit => {
    const net = fetch(e.request).then(r => { if (r.ok) caches.open(VERSION).then(c => c.put(e.request, r.clone())); return r; }).catch(() => hit);
    return hit || net;
  }));
});
