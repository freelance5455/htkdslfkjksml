var C='halaqa-v6';
self.addEventListener('install',function(e){e.waitUntil(caches.open(C).then(function(c){return Promise.all(['/','/manifest.json','/icon-192.png','/icon-512.png'].map(function(u){return c.add(u).catch(function(){})}))}));self.skipWaiting()});
self.addEventListener('activate',function(e){e.waitUntil(self.clients.claim())});
self.addEventListener('fetch',function(e){e.respondWith(fetch(e.request).then(function(r){var k=r.clone();if(e.request.method=='GET'&&r.ok)caches.open(C).then(function(c){c.put(e.request,k)});return r}).catch(function(){return caches.match(e.request).then(function(m){return m||caches.match('/')})}))});
