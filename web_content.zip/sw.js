var C='memrise-v6',A=['./','index.html','css/style.css','js/app.js','manifest.webmanifest','fonts/ah-400.woff2','fonts/ah-700.woff2','icon-192.png','icon-512.png'];
self.addEventListener('install',function(e){e.waitUntil(caches.open(C).then(function(c){return c.addAll(A);}).then(function(){return self.skipWaiting();}));});
self.addEventListener('activate',function(e){e.waitUntil(caches.keys().then(function(k){return Promise.all(k.filter(function(x){return x!==C;}).map(function(x){return caches.delete(x);}));}).then(function(){return self.clients.claim();}));});
self.addEventListener('fetch',function(e){if(e.request.method==='GET')e.respondWith(caches.match(e.request).then(function(r){return r||fetch(e.request);}));});
