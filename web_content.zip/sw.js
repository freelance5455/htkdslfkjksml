/* ============================================================================
   AURA PLAYER — sw.js (Service Worker)
   Caché "offline-first" del propio app shell de la aplicación.

   Estrategia:
   - Instalación: precarga el app shell (HTML, CSS, JS, iconos y librerías
     locales). Con esto la app abre sin internet después de la primera visita.
   - Fetch (mismo origen, GET):
       * cache-first con revalidación en segundo plano (stale-while-revalidate)
       * si no está en caché: red → guardar en caché
       * si no hay red: respaldo a index.html (modo offline)
   - Los archivos de MÚSICA no pasan por aquí: se leen con File API / blobs,
     que el Service Worker no intercepta.

   Nota: en file:// (APK empaquetado) el SW no existe; app.js lo detecta y
   la aplicación funciona igualmente sin caché.
   ============================================================================ */

'use strict';

const CACHE = 'aura-player-v1.0.0';

const APP_SHELL = [
  './',
  './index.html',
  './styles.css',
  './app.js',
  './manifest.webmanifest',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './vendor/jsmediatags.min.js',
  './vendor/color-thief.umd.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    await Promise.allSettled(
      APP_SHELL.map((url) => cache.add(new Request(url, { cache: 'reload' })))
    );
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(
      names.filter((n) => n !== CACHE).map((n) => caches.delete(n))
    );
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;   // el CDN va directo a red

  event.respondWith((async () => {
    const cache = await caches.open(CACHE);

    const cached = await cache.match(req, { ignoreSearch: true });
    if (cached) {
      // Revalidar en segundo plano para la próxima visita
      event.waitUntil(cache.add(req).catch(() => {}));
      return cached;
    }

    try {
      const fresh = await fetch(req);
      if (fresh && fresh.ok) cache.put(req, fresh.clone());
      return fresh;
    } catch (err) {
      const shell = await cache.match('./index.html');
      if (shell) return shell;
      throw err;
    }
  })());
});
