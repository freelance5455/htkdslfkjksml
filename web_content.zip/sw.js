/* Focus Everyday — service worker: offline-first, never touches localStorage (your data stays safe). */
const CACHE='fe-pwa-v1';
const CORE=["./", "index.html", "manifest.webmanifest", "icons/logo.png", "icons/icon-192.png", "icons/icon-512.png", "icons/icon-maskable-512.png", "icons/apple-touch-icon.png", "fonts/bebas-neue-latin-400-normal.woff2", "fonts/cairo-arabic-400-normal.woff2", "fonts/cairo-arabic-700-normal.woff2", "fonts/cairo-arabic-900-normal.woff2", "fonts/cairo-latin-400-normal.woff2", "fonts/cairo-latin-700-normal.woff2", "fonts/cairo-latin-900-normal.woff2", "fonts/fonts.css", "fonts/oswald-latin-400-normal.woff2", "fonts/oswald-latin-600-normal.woff2", "fonts/oswald-latin-700-normal.woff2"];
self.addEventListener('install',e=>{
  e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',e=>{
  e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
// Cache first (instant + offline), refresh the cached copy in the background when online.
self.addEventListener('fetch',e=>{
  const req=e.request;
  if(req.method!=='GET')return;
  const url=new URL(req.url);
  if(url.origin!==self.location.origin)return;          // API calls etc. go straight to the network
  e.respondWith((async()=>{
    const cache=await caches.open(CACHE);
    const hit=await cache.match(req,{ignoreSearch:true});
    const refresh=fetch(req).then(res=>{if(res&&res.ok)cache.put(req,res.clone());return res;}).catch(()=>null);
    if(hit){e.waitUntil(refresh);return hit;}
    const res=await refresh;
    if(res)return res;
    if(req.mode==='navigate'){const fb=await cache.match('index.html');if(fb)return fb;}
    return new Response('',{status:504,statusText:'Offline'});
  })());
});
