/* Service worker — 100% offline: pré-cache de todos os arquivos locais, nenhuma chamada de rede externa */
const VERSION = '4.0.0'; // única definição da versão do cache
const CACHE = 'protracker-' + VERSION;
const CORE = [
  './', './index.html', './app.css',
  './util.js', './i18n.js', './catalog.js', './game.js', './store.js', './ui.js', './share.js', './views1.js', './views2.js', './main.js',
  './manifest.webmanifest',
  './icons/icon-192.png', './icons/icon-512.png', './icons/maskable-512.png', './icons/apple-touch-icon.png'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())
  );
});
self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // nunca toca a rede externa
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const cached = await cache.match(req, { ignoreSearch: true });
    if (cached) return cached;
    try {
      const res = await fetch(req);
      if (res && res.ok && res.status === 200) cache.put(req, res.clone()); // nunca guarda 206 / erros
      return res;
    } catch (e) {
      if (req.mode === 'navigate') { const fb = await cache.match('./index.html'); if (fb) return fb; }
      return Response.error();
    }
  })());
});
