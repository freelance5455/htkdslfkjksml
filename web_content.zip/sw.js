// Sube la versión (V) cuando cambies archivos para forzar la limpieza de cachés viejas.
const V = "kazuya-v10";
const FILES = ["./", "index.html", "manifest.webmanifest", "icon.svg", "icon-180.png", "icon-192.png", "icon-512.png", "icon-maskable-512.png", "logo.png", "ryu.webp", "tora.webp"];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(V).then(c => c.addAll(FILES)));
  self.skipWaiting();
});

self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== V).map(k => caches.delete(k))))
  );
  self.clients.claim();
});

// Stale-while-revalidate: responde al instante desde caché y actualiza en segundo plano,
// así los cambios aparecen en la siguiente apertura sin quedarse pegado a una versión vieja.
self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET" || new URL(req.url).origin !== location.origin) return;
  e.respondWith(
    caches.open(V).then(async cache => {
      const cached = await cache.match(req, { ignoreSearch: true });
      const network = fetch(req)
        .then(res => { if (res.ok) cache.put(req, res.clone()); return res; })
        .catch(() => null);
      if (cached) { e.waitUntil(network); return cached; }
      const res = await network;
      return res || (req.mode === "navigate" ? cache.match("index.html") : Response.error());
    })
  );
});

// Al tocar un aviso, enfoca la app (o la abre).
self.addEventListener("notificationclick", e => {
  e.notification.close();
  e.waitUntil(
    clients.matchAll({ type: "window", includeUncontrolled: true }).then(list => {
      const w = list.find(c => "focus" in c);
      return w ? w.focus() : clients.openWindow("./index.html");
    })
  );
});
