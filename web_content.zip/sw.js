const CACHE="bff-pro-v1";
const CORE=["./","./index.html","./home.html","./chat.html","./friends.html","./profile.html","./map.html","./login.html","./signup.html","./theme.css","./ui-pro.css","./theme.js","./app.js","./calls.js","./home.js","./chat.js","./friends.js","./profile.js","./map.js","./auth.js","./login.js","./signup.js","./manifest.webmanifest","./icons/app-icon.svg"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener("fetch",e=>{if(e.request.method!=="GET")return;e.respondWith(fetch(e.request).then(r=>{if(r.ok){const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));}return r;}).catch(()=>caches.match(e.request).then(r=>r||caches.match("./index.html"))));});
