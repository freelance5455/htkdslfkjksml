// Learnly service worker — cache-first, fully offline after first load.
// Bump CACHE_NAME when JS changes so clients don't keep a broken white-screen build.
const CACHE_NAME = "learnly-v12-ps-papers-quiz";

const CORE_ASSETS = [
  "./", "./index.html", "./manifest.json",
  "./css/style.css",
  "./icons/icon-192.png", "./icons/icon-512.png",
  "./content/curriculum_all_grades.json",
  "./content/tips_and_tricks.json",
  "./js/app.js", "./js/db.js", "./js/theme.js",
  "./js/engines/gradeManager.js", "./js/engines/foundationEngine.js",
  "./js/engines/questionEngine.js", "./js/engines/unifiedEngine.js",
  "./js/engines/fetEngine.js",
  "./js/engines/answerCheck.js", "./js/engines/adaptive.js",
  "./js/engines/mastery.js", "./js/engines/economyEngine.js",
  "./js/engines/gamificationEngine.js", "./js/engines/paperEngine.js",
  "./js/engines/dataEngine.js",
  "./js/engines/probabilityEngine.js", "./js/engines/contentLoader.js",
  "./js/engines/timerEngine.js", "./js/engines/theoremEngine.js",
  "./js/ui/render.js", "./js/ui/geometryLabCanvas.js", "./js/ui/widgets.js",
  "./js/ui/imageBuilder.js",
  "./js/screens/login.js", "./js/screens/home.js", "./js/screens/learn.js",
  "./js/screens/practice.js", "./js/screens/papers.js", "./js/screens/profile.js",
  "./js/screens/settings.js", "./js/screens/labs.js",
  "./js/screens/gamification.js", "./js/screens/science.js",
  "./js/screens/parent.js", "./js/screens/teach.js", "./js/screens/structured.js",
  "./js/screens/challenges.js", "./js/screens/lessons.js",
  "./content/grade11/past_papers/paper_templates.json",
  "./content/grade11/past_papers/equations_bank.json"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      // Prefer soft caching so one missing file doesn't abort install
      await Promise.all(
        CORE_ASSETS.map((url) => cache.add(url).catch(() => {}))
      );
      return self.skipWaiting();
    })
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;
      return fetch(req).then((res) => {
        const copy = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(req, copy)).catch(() => {});
        return res;
      }).catch(() => cached);
    })
  );
});
