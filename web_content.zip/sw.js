const CACHE_NAME='bayt-al-hikmah-v2';
const CORE=['./','./index.html','./manifest.webmanifest','./share-target.html','./icon-192.png','./icon-512.png'];
const DB_NAME='BaytAlHikmahDB', DB_VERSION=2;
function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB_NAME,DB_VERSION);r.onupgradeneeded=()=>{const d=r.result;if(!d.objectStoreNames.contains('books')){const s=d.createObjectStore('books',{keyPath:'id'});s.createIndex('title','title',{unique:false});s.createIndex('category','category',{unique:false})}if(!d.objectStoreNames.contains('incomingShares'))d.createObjectStore('incomingShares',{keyPath:'id'});};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE_NAME).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const u=new URL(event.request.url);
 if(event.request.method==='POST' && u.pathname.endsWith('/share-target.html')){
  event.respondWith((async()=>{try{const form=await event.request.formData();const files=form.getAll('files').filter(f=>f && typeof f.name==='string' && f.name);const db=await openDB();await new Promise((resolve,reject)=>{const tx=db.transaction('incomingShares','readwrite');const store=tx.objectStore('incomingShares');files.forEach((file,i)=>store.put({id:'shared_'+Date.now()+'_'+i+'_'+Math.random().toString(36).slice(2),file,title:form.get('title')||''}));tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error)});db.close();return Response.redirect(new URL('./index.html?shared=1',self.registration.scope),303)}catch(err){return new Response('বইটি গ্রহণ করা যায়নি। অ্যাপটি আবার খুলে চেষ্টা করুন।',{status:500,headers:{'Content-Type':'text/plain;charset=utf-8'}})}})());return;
 }
 if(event.request.method!=='GET')return;
 event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request).then(response=>{if(response&&response.ok&&u.origin===self.location.origin){const copy=response.clone();caches.open(CACHE_NAME).then(c=>c.put(event.request,copy))}return response}).catch(()=>caches.match('./index.html'))));
});
