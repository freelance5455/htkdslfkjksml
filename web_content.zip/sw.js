// Learnly Grade 10 — offline-first service worker (browser PWA).
// Soft install: never block APK / WebView asset loads.
const CACHE_NAME = "learnly-g10-ml-v9-learning-cards-measurement";

const CORE_ASSETS = [
  "./",
  "./index.html",
  "./manifest.json",
  "./sw.js",
  "./css/style.css",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./content/curriculum_all_grades.json",
  "./content/tips_and_tricks.json",
  "./content/subject_topics.json",
  "./content/subjects_by_grade.json",
  "./js/app.js",
  "./js/db.js",
  "./js/theme.js"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) =>
      Promise.all(
        CORE_ASSETS.map((url) => cache.add(url).catch(() => {}))
      )
    ).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.hostname === "appassets.androidplatform.net") return;

  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;
      return fetch(req).then((res) => {
        if (res && res.ok && url.origin === self.location.origin) {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, copy)).catch(() => {});
        }
        return res;
      }).catch(() => {
        if (req.mode === "navigate") {
          return caches.match("./index.html").then((r) => r || Response.error());
        }
        return Response.error();
      });
    })
  );
});
