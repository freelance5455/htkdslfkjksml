const CACHE_APP = "vorlesezauber-app-v5";
const CACHE_MODELS = "vorlesezauber-models-v5";

const APP_FILES = [
  "./",
  "./index.html",
  "./styles.css",
  "./app.js",
  "./piper-adapter.js",
  "./vendor/piper-tts-web.bundle.js",
  "./manifest.webmanifest",
  "./icon-192.png",
  "./icon-512.png",
  "./apple-touch-icon.png",
];

self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(CACHE_APP)
      .then((c) => c.addAll(APP_FILES))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => k !== CACHE_APP && k !== CACHE_MODELS)
          .map((k) => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

function isModelRequest(url) {
  return (
    url.pathname.startsWith("/piper-model/") ||
    url.hostname.includes("huggingface.co") ||
    url.hostname.includes("corsproxy.io") ||
    url.hostname.includes("allorigins.win")
  );
}

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);

  // App shell: cache-first
  if (url.origin === self.location.origin && !isModelRequest(url)) {
    e.respondWith(
      caches.match(req).then((cached) => {
        if (cached) return cached;
        return fetch(req).then((res) => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(CACHE_APP).then((c) => c.put(req, clone));
          }
          return res;
        }).catch(() => caches.match("./index.html"));
      })
    );
    return;
  }

  // Models / ONNX: cache-first, network fill
  if (isModelRequest(url)) {
    e.respondWith(
      caches.open(CACHE_MODELS).then(async (cache) => {
        const cached = await cache.match(req);
        if (cached) return cached;
        try {
          const res = await fetch(req);
          if (res.ok) {
            cache.put(req, res.clone());
          }
          return res;
        } catch (err) {
          // offline + no cache → fail
          return new Response("Modell offline nicht verfügbar", { status: 503 });
        }
      })
    );
  }
});
