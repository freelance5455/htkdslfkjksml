const CACHE_V5_V3 = 'korbball-v5-v3-cache';
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE_V5_V3).then(c => c.addAll(['./', './index.html', './manifest.json'])));
});
self.addEventListener('fetch', e => {
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});
