const CACHE_NAME = 'brc-sidoarjo-v252';
const urlsToCache = [
  './',
  './index.html',
  './manifest.json',
  './logo.png'
];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(urlsToCache)));
});
self.addEventListener('fetch', event => {
  event.respondWith(caches.match(event.request).then(r => r || fetch(event.request)));
});