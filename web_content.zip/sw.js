// Archivo de compatibilidad. La aplicacion no depende del service worker.
