/* آسمان · service worker
   - صفحه و فایل‌های خود برنامه: اول شبکه (برای به‌روزرسانی سریع)، اگر نبود کش
   - آیکون و فونت: کش با به‌روزرسانی در پس‌زمینه
   - API های هواشناسی دست‌نخورده می‌مانند (برنامه خودش کش دارد) */
const V = 'asman-v6.4';
const SHELL = ['./', './index.html', './manifest.webmanifest', './icon-192.png', './icon-512.png', './icon-maskable-512.png', './apple-touch-icon.png'];
const OPTIONAL = ['./Vazirmatn.woff2', './Vazirmatn.ttf'];

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(V);
    await Promise.allSettled([...SHELL, ...OPTIONAL].map(u => c.add(new Request(u, { cache: 'reload' }))));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== V && k.startsWith('asman-')) await caches.delete(k);
    await self.clients.claim();
  })());
});

const timeout = (p, ms) => Promise.race([p, new Promise((_, r) => setTimeout(() => r(new Error('timeout')), ms))]);

self.addEventListener('fetch', e => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin) return;
  const isPage = req.mode === 'navigate' || /\/(index\.html)?$/.test(url.pathname) || url.pathname.endsWith('/manifest.webmanifest');
  if (isPage) {
    e.respondWith((async () => {
      const c = await caches.open(V);
      try {
        const r = await timeout(fetch(req), 4000);
        if (r && r.ok) c.put(req.mode === 'navigate' ? './index.html' : req, r.clone());
        return r;
      } catch (_) {
        return (await c.match(req, { ignoreSearch: true })) || (await c.match('./index.html')) || (await c.match('./')) || Response.error();
      }
    })());
    return;
  }
  e.respondWith((async () => {
    const c = await caches.open(V), hit = await c.match(req);
    const net = fetch(req).then(r => { if (r && r.ok) c.put(req, r.clone()); return r }).catch(() => null);
    return hit || (await net) || Response.error();
  })());
});
