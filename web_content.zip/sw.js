/* Orbit PKL Studio - service worker
   Ubah VERSI setiap kali index.html diperbarui agar pengguna menerima versi baru. */
const VERSI='orbit-pkl-v1';
const FONT=VERSI+'-font';
const INTI=['./','index.html','manifest.webmanifest','icons/icon-192.png','icons/icon-512.png','icons/icon-maskable-512.png','icons/apple-touch-icon.png','icons/favicon-32.png'];
self.addEventListener('install',e=>{
  e.waitUntil(caches.open(VERSI).then(c=>c.addAll(INTI)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',e=>{
  e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k.startsWith('orbit-pkl')&&k!==VERSI&&k!==FONT).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',e=>{
  const r=e.request;if(r.method!=='GET')return;
  const u=new URL(r.url);
  /* halaman utama: langsung dari cache agar terbuka seketika, juga saat offline */
  if(r.mode==='navigate'){e.respondWith(caches.match('index.html').then(c=>c||fetch(r)));return}
  /* berkas milik aplikasi: cache dulu, lalu jaringan */
  if(u.origin===location.origin){
    e.respondWith(caches.match(r).then(c=>c||fetch(r).then(x=>{if(x&&x.ok){const k=x.clone();caches.open(VERSI).then(ca=>ca.put(r,k))}return x})));
    return;
  }
  /* font Google: tampilkan yang tersimpan, perbarui diam-diam */
  if(/(^|\.)(googleapis|gstatic)\.com$/.test(u.hostname)){
    e.respondWith(caches.open(FONT).then(ca=>ca.match(r).then(c=>{
      const f=fetch(r).then(x=>{if(x&&(x.ok||x.type==='opaque'))ca.put(r,x.clone());return x}).catch(()=>c);
      return c||f;
    })));
  }
});
