const CACHE='study-panda-shell-v1';
const SHELL=['./index.html','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png','./icons/apple-touch-icon.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>Promise.allSettled(SHELL.map(u=>c.add(new Request(u,{cache:'reload'}))))).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('study-panda-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
 const req=e.request;if(req.method!=='GET')return;
 let u;try{u=new URL(req.url)}catch(_){return}
 if(u.pathname.includes('/api/')||u.pathname.includes('/auth/')||u.searchParams.has('token')||u.searchParams.has('access_token'))return;
 const same=u.origin===self.location.origin;
 const app=same&&(req.mode==='navigate'||u.pathname.endsWith('/index.html')||u.pathname.endsWith('/manifest.webmanifest')||u.pathname.includes('/icons/'));
 const asset=['script','style','image','font'].includes(req.destination);if(!app&&!asset)return;
 if(req.mode==='navigate'||u.pathname.endsWith('/index.html')){
  e.respondWith(fetch(req).then(r=>{if(r.ok){const copy=r.clone();caches.open(CACHE).then(c=>c.put(req,copy))}return r}).catch(()=>caches.match('./index.html')));return;
 }
 e.respondWith(caches.match(req).then(hit=>{const net=fetch(req).then(r=>{if(r.ok&&(same||r.type==='cors')){const copy=r.clone();caches.open(CACHE).then(c=>c.put(req,copy))}return r}).catch(()=>hit);return hit||net}));
});
