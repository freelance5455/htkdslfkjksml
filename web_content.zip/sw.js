/* Service worker: makes the app load offline and keeps it up to date. */
const CACHE = "inventory-v8";
const FILES = ["./", "index.html", "core.js", "barcodes.js", "reports.js", "pdf.js", "app.js", "manifest.json",
  "icon-192.png", "icon-512.png", "icon-maskable-192.png", "icon-maskable-512.png"];

self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(CACHE)
      .then((c) => Promise.all(FILES.map((f) => c.add(f).catch(() => null)))) // one missing file must not break install
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())
  );
});

self.addEventListener("message", (e) => { if (e.data === "SKIP_WAITING") self.skipWaiting(); });

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET" || !req.url.startsWith("http")) return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // never touch other sites

  // App page loads: try the network first (fresh app), fall back to the saved copy when offline.
  // Only the app page itself is saved under index.html; other pages (such as check.html) are left alone.
  if (req.mode === "navigate") {
    const isApp = url.pathname.endsWith("/") || url.pathname.endsWith("/index.html");
    e.respondWith(
      fetch(req)
        .then((res) => { if (isApp && res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put("index.html", copy)); } return res; })
        .catch(() => (isApp ? caches.match("index.html").then((r) => r || caches.match("./")) : caches.match(req)))
    );
    return;
  }

  // Everything else: show the saved copy instantly and refresh it in the background.
  e.respondWith(
    caches.match(req).then((cached) => {
      const fresh = fetch(req).then((res) => {
        if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); }
        return res;
      }).catch(() => cached);
      return cached || fresh;
    })
  );
});
