/* POS offline cache — ដាក់ឯកសារនេះក្នុង folder តែមួយជាមួយ index.html */
const CACHE = 'pos-offline-v12';
self.addEventListener('install', e => { self.skipWaiting(); e.waitUntil(caches.open(CACHE).then(c => c.add('./')).catch(() => {})); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
function timeout(ms) { return new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms)); }
async function networkFirst(req) {
  const cache = await caches.open(CACHE);
  try {
    const res = await Promise.race([fetch(req), timeout(4000)]);
    if (res && res.ok) cache.put(req, res.clone());
    return res;
  } catch (e) {
    return (await cache.match(req, { ignoreSearch: true })) || (await cache.match('./')) || Response.error();
  }
}
async function staleWhileRevalidate(req) {
  const cache = await caches.open(CACHE);
  const cached = await cache.match(req);
  const net = fetch(req).then(res => { if (res && (res.ok || res.type === 'opaque')) cache.put(req, res.clone()); return res; }).catch(() => cached);
  return cached || net;
}
self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET') return;
  const u = new URL(r.url);
  if (u.hostname.endsWith('.supabase.co') && u.pathname.indexOf('/storage/v1/object/public/') < 0) return; // API ទិន្នន័យ មិន cache
  if (/^\/(rest|auth)\//.test(u.pathname) || (/^\/storage\//.test(u.pathname) && u.pathname.indexOf('/storage/v1/object/public/') < 0)) return; // Cloudflare API ទិន្នន័យ មិន cache
  if (r.mode === 'navigate') { e.respondWith(networkFirst(r)); return; }
  e.respondWith(staleWhileRevalidate(r));
});
