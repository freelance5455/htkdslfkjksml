const C="sp-v2",F=["./","index.html","style.css","core.js","app.js","manifest.json","icon-192.png","icon-512.png","icon-maskable-512.png","fonts/NotoSansBengali-Regular.woff","fonts/NotoSansBengali-Bold.woff"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(F)));self.skipWaiting()});
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>clients.claim())));
self.addEventListener("fetch",e=>{
 if(e.request.method!=="GET")return;
 const u=new URL(e.request.url);
 if(u.origin!==location.origin){
  if(u.hostname.indexOf("jsdelivr")<0&&u.hostname.indexOf("projectnaptha")<0)return;
  e.respondWith(caches.open("sp-cdn").then(c=>c.match(e.request).then(r=>r||fetch(e.request).then(n=>{if(n&&n.ok)c.put(e.request,n.clone());return n}))));return;
 }
 e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).catch(()=>caches.match("index.html"))))});
