// J.A.R.V.I.S BR 2.4 — APP. Guarda o app no aparelho para abrir até sem internet (para PENSAR ele precisa dela).
// Só é usado quando o app está num site (https); dentro do APK/arquivo o próprio APK já guarda tudo.
const CACHE = "jarvis-app-v24";
const CASCA = ["./", "./index.html", "./core.js", "./motor.js", "./missoes.js", "./jarvis.js", "./tela.css", "./arcade.html", "./holograma.html",
  "./armadura.html", "./ar.html", "./grafo.html", "./missoes.html", "./monitor.html", "./player.html", "./manifest.webmanifest", "./icone.svg", "./icone-192.png", "./icone-512.png"];
self.addEventListener("install", e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(CASCA)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  const u = new URL(e.request.url);
  if (e.request.method !== "GET" || u.origin !== location.origin) return;
  e.respondWith(fetch(e.request).then(r => { const c = r.clone(); caches.open(CACHE).then(k => k.put(e.request, c)); return r; })
    .catch(() => caches.match(e.request).then(r => r || caches.match("./index.html"))));
});
