const C='mr-khorasani-v2.6.5-android-no-qr';
const F=['./','./index.html','./app.js','./supabase-config.js','./supabase-client.js','./guest-runtime.js','./manifest.webmanifest','./brand-mr.png','./icon-192.png','./icon-512.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(F)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||new URL(e.request.url).origin!==self.location.origin)return;e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(x=>{const cp=x.clone();caches.open(C).then(c=>c.put(e.request,cp)).catch(()=>{});return x}).catch(()=>caches.match('./index.html'))))});
