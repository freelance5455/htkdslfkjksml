/* Pas de mise en cache des fiches privées. Ce worker reçoit uniquement les notifications. */
const SETTINGS='midok-push-settings-v1';
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('message',e=>{if(e.data?.type==='midok-push-enabled')e.waitUntil((async()=>{const c=await caches.open(SETTINGS);await c.put(new Request(new URL('push-preference',self.registration.scope)),new Response(JSON.stringify({enabled:e.data.enabled===true})))})())});
self.addEventListener('push',e=>e.waitUntil((async()=>{
 const c=await caches.open(SETTINGS),r=await c.match(new Request(new URL('push-preference',self.registration.scope)));
 if(!r||!(await r.json()).enabled)return;
 let data;try{data=e.data.json()}catch{return}
 if(typeof data.title!=='string'||typeof data.body!=='string')return;
 await self.registration.showNotification(data.title.slice(0,120),{body:data.body.slice(0,2000),tag:String(data.id||'midok'),renotify:false,icon:'icon.svg',data:{url:self.registration.scope}});
})()));
self.addEventListener('notificationclick',e=>{e.notification.close();e.waitUntil((async()=>{const windows=await self.clients.matchAll({type:'window',includeUncontrolled:true});if(windows.length)return windows[0].focus();return self.clients.openWindow(self.registration.scope)})())});
