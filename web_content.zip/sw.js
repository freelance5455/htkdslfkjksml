const CACHE = "unknown-x-offline-v27.0";
const FILES = [
  "./",
  "./index.html",
  "./manifest.json",
  "./css/style.css",
  "./css/v17.css",
  "./css/v18.css",
  "./css/v19.css",
  "./css/v20.css",
  "./css/v21.css",
  "./css/v22.css",
  "./css/v23.css",
  "./css/v24.css",
  "./css/v25.css",
  "./css/v26.css",
  "./css/v27.css",
  "./js/data.js",
  "./js/app.js",
  "./js/v17.js",
  "./js/v17b.js",
  "./js/v17c.js",
  "./js/v18.js",
  "./js/v19.js",
  "./js/v20.js",
  "./js/v21.js",
  "./js/v22.js",
  "./js/v23.js",
  "./js/v24.js",
  "./js/v25.js",
  "./js/v26.js",
  "./js/v27.js",
  "./assets/unknown-x-mark.svg",
  "./assets/orion-city.svg"
];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE)
      .then(cache => cache.addAll(FILES))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    const stale = keys.filter(key => key.startsWith("unknown-x-") && key !== CACHE);
    await Promise.all(stale.map(key => caches.delete(key)));
    await self.clients.claim();
    if (stale.length) {
      const clients = await self.clients.matchAll({ type: "window" });
      await Promise.all(clients.map(client => client.navigate(client.url).catch(() => {})));
    }
  })());
});

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;

  event.respondWith((async () => {
    try {
      const response = await fetch(request);
      if (response && response.ok && new URL(request.url).origin === self.location.origin) {
        const copy = response.clone();
        caches.open(CACHE).then(cache => cache.put(request, copy)).catch(() => {});
      }
      return response;
    } catch (error) {
      const cached = await caches.match(request);
      if (cached) return cached;
      if (request.mode === "navigate") {
        return (await caches.match("./index.html")) || (await caches.match("./")) || Response.error();
      }
      return Response.error();
    }
  })());
});
