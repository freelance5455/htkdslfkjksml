const V='truk-jambi-v1',B='https://cdn.jsdelivr.net/npm/three@0.128.0/';
const LOCAL=['./','index.html','manifest.webmanifest','icons/icon-192.png','icons/icon-512.png'];
const LIBS=['lib/three.min.js','lib/GLTFLoader.js','lib/BufferGeometryUtils.js'];
const CDN=[B+'build/three.min.js',B+'examples/js/loaders/GLTFLoader.js',B+'examples/js/utils/BufferGeometryUtils.js'];
self.addEventListener('install',e=>{e.waitUntil((async()=>{const c=await caches.open(V);await c.addAll(LOCAL);
for(const u of LIBS){try{const r=await fetch(u);if(r.ok)await c.put(u,r)}catch(_){}}
for(const u of CDN){try{const r=await fetch(u,{mode:'cors'});if(r.ok)await c.put(u,r)}catch(_){}}
self.skipWaiting()})())});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request,{ignoreSearch:true}).then(h=>h||fetch(e.request).then(r=>{if(r.ok){const cp=r.clone();caches.open(V).then(c=>c.put(e.request,cp))}return r}).catch(()=>e.request.mode==='navigate'?caches.match('index.html'):Response.error())))});
