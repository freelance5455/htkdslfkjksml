// v5 Android 9: service worker intentionally disabled to avoid stale WebView cache.
