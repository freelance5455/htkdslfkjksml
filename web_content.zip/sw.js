/* Offline cache. Three.js is cached from the CDN on the first successful online launch. */
const CACHE = 'ultimate-drive-v1';
const CORE = ['./', './index.html', './manifest.webmanifest'];
const THREE_URL = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    await cache.addAll(CORE);
    try {
      const response = await fetch(THREE_URL, {mode:'no-cors', cache:'reload'});
      await cache.put(THREE_URL, response);
    } catch (_) { /* online first launch is required if CDN is not already cached */ }
    self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) if (key !== CACHE) await caches.delete(key);
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin === self.location.origin || req.url === THREE_URL) {
    event.respondWith((async () => {
      const cached = await caches.match(req, {ignoreSearch:true});
      if (cached) return cached;
      try {
        const fresh = await fetch(req);
        const cache = await caches.open(CACHE);
        cache.put(req, fresh.clone()).catch(()=>{});
        return fresh;
      } catch (_) {
        return (await caches.match('./index.html')) || Response.error();
      }
    })());
  }
});
