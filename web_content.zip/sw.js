/* سرویس‌ورکر آفلاین. با هر تغییر فایل‌ها، VERSION را بالا ببر تا کش قدیمی پاک شود. */
const VERSION = '2.3.6';
const CACHE = 'study-v2-' + VERSION;
const ASSETS = [
  './',
  'index.html',
  'manifest.json',
  'icon-192.png',
  'icon-512.png',
  'css/app.css',
  'fonts/Vazirmatn-Variable.woff2',
  'js/00-util.js',
  'js/01-data.js',
  'js/02-grade8.js',
  'js/03-store.js',
  'js/04-backup.js',
  'js/05-study.js',
  'js/06-plan.js',
  'js/07-exam.js',
  'js/08-gamify.js',
  'js/09-ui-core.js',
  'js/09b-charts.js',
  'js/10-views-common.js',
  'js/11-view-today.js',
  'js/11b-remind.js',
  'js/12-view-plan.js',
  'js/13-view-subj.js',
  'js/14-view-exam.js',
  'js/15-view-timer.js',
  'js/15b-view-settings.js',
  'js/16-view-stat.js',
  'js/20-ai-proxy.js',
  'js/20b-providers.js',
  'js/21-ai-knowledge.js',
  'js/22-ai-tools.js',
  'js/23-ai-chat.js',
  'js/23b-ai-profiles.js',
  'js/24-ai-photos.js',
  'js/25-ai-md.js',
  'js/99-app.js'
];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(CACHE).then(function (c) { return c.addAll(ASSETS); }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (keys) {
    return Promise.all(keys.filter(function (k) { return k.indexOf('study-v') === 0 && k !== CACHE; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});
self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);
  // پراکسی هوش مصنوعی و هر دامنه‌ی دیگر: مستقیم از شبکه، هرگز از کش
  if (url.origin !== self.location.origin) return;
  e.respondWith(caches.match(req, { ignoreSearch: true }).then(function (hit) {
    if (hit) return hit;
    return fetch(req).then(function (res) {
      if (res && res.ok) { var copy = res.clone(); caches.open(CACHE).then(function (c) { c.put(req, copy); }); }
      return res;
    });
  }).catch(function () { return caches.match('index.html'); }));
});
