const CACHE='white-room-v2';
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(['./','./index.html','./manifest.json','./assets/hinata.jpg','./assets/luffy_run.jpg','./assets/luffy_sky.jpg','./assets/jinwoo.jpg','./assets/portrait.jpg','./assets/bluelock.jpg']))));
self.addEventListener('fetch',e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).catch(()=>caches.match('./index.html')))));
