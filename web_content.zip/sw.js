// Service Worker بسيط جداً عشان التطبيق يتقبل كـ PWA
const CACHE_NAME = 'warranty-app-v1';

self.addEventListener('install', (event) => {
  console.log('Service Worker: Installed');
});

self.addEventListener('activate', (event) => {
  console.log('Service Worker: Activated');
});

self.addEventListener('fetch', (event) => {
  // بنسيب المتصفح يتصرف بشكل طبيعي
  event.respondWith(fetch(event.request));
});