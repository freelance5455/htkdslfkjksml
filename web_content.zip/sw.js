/* blure v0.7.5 - network-first online, cache fallback offline */
const VERSION='blure-offline-v0932-editorfix';
const REQUIRED=['./ide.html','./blure-runtime.js?v=075','./execution-modes.js?v=075'];
const OPTIONAL=['./landing.html','./docs.html','./index.html','./offline.html','./blure-offline.html','./theme.css?v=076','./theme.js?v=070','./navigation.css?v=072','./navigation.js?v=072','./visual-polish.css?v=079','./visual-polish.js?v=079','./manifest.webmanifest','./icon-192.png','./icon-512.png','./icon-maskable-512.png','./icon.svg','./blure-080.css?v=080','./blure-rounded.css?v=080r1','./blure-workspace.css?v=080r1'];
const path=p=>new URL(p,self.registration.scope).href;
const baseKey=u=>{const v=new URL(u);v.search='';return v.href};
async function getFresh(url){
 const r=await fetch(new Request(url,{cache:'no-store',credentials:'same-origin'}));
 if(!r.ok||r.redirected||r.type==='opaque')throw Error('Invalid response for '+url+' ('+r.status+')');
 const type=(r.headers.get('content-type')||'').toLowerCase();
 const name=new URL(url).pathname;
 if(/\.html$/.test(name)&&!type.includes('text/html'))throw Error('HTML MIME mismatch: '+url);
 if(/\.js$/.test(name)&&!/javascript|ecmascript/.test(type))throw Error('JS MIME mismatch: '+url);
 if(name.endsWith('/blure-runtime.js')&&!(await r.clone().text()).includes('createSession'))throw Error('Invalid runtime response');
 return r;
}
async function store(c,p){const url=path(p);const r=await getFresh(url);await c.put(url,r.clone());await c.put(baseKey(url),r.clone());return r}
async function populate(){const c=await caches.open(VERSION);for(const p of REQUIRED)await store(c,p);await Promise.allSettled(OPTIONAL.map(p=>store(c,p)));return c}
self.addEventListener('install',e=>e.waitUntil((async()=>{await populate();await self.skipWaiting()})()));
self.addEventListener('activate',e=>e.waitUntil((async()=>{
 const c=await caches.open(VERSION);
 if(await c.match(path(REQUIRED[0]))&&await c.match(path(REQUIRED[1]))){
  const keys=await caches.keys();await Promise.all(keys.filter(k=>k.startsWith('blure-')&&k!==VERSION).map(k=>caches.delete(k)));
 }
 await self.clients.claim();
})()));
self.addEventListener('message',e=>{
 if(e.data?.type==='BLURE_VERIFY')e.waitUntil((async()=>{
  let ready=false,error='';try{
   let c=await caches.open(VERSION);
   ready=!!((await c.match(path(REQUIRED[0])))&&(await c.match(path(REQUIRED[1]))));
   if(!ready&&e.data.retry){c=await populate();ready=!!((await c.match(path(REQUIRED[0])))&&(await c.match(path(REQUIRED[1])))&&(await c.match(path(REQUIRED[2]))))}
  }catch(ex){error=String(ex.message||ex)}
  e.ports?.[0]?.postMessage({ready,error,version:VERSION});
 })());
});
async function onlineFirst(req,fallback){
 const c=await caches.open(VERSION);
 try{
  const r=await getFresh(req.url);
  await c.put(req.url,r.clone());
  await c.put(baseKey(req.url),r.clone());
  return r;
 }catch(_){
  const cached=await c.match(req)||await c.match(baseKey(req.url))||(fallback?await c.match(path(fallback)):null);
  if(cached)return cached;
  return new Response('blure: connect once to cache this page',{status:503,headers:{'Content-Type':'text/plain'}});
 }
}
self.addEventListener('fetch',e=>{
 const req=e.request;if(req.method!=='GET')return;
 const u=new URL(req.url),scope=self.registration.scope;
 if(u.origin!==self.location.origin||!u.href.startsWith(scope))return;
 const name=u.pathname.split('/').pop();
 if(req.mode==='navigate'){
  if(name==='php-playground.php'||name==='download.php')return;
  if(name===''||name==='index.php'){
   e.respondWith(onlineFirst(req,'./landing.html'));return;
  }
  if(name==='index.html'){e.respondWith(onlineFirst(req,'./ide.html'));return}
  if(['ide.html','offline.html','blure-offline.html','docs.html','landing.html'].includes(name)){
   e.respondWith(onlineFirst(req,name==='offline.html'||name==='blure-offline.html'?'./ide.html':'./'+name));return;
  }
  return;
 }
 if(['blure-runtime.js','execution-modes.js','blure-ui.js','theme.css','theme.js','navigation.css','navigation.js','visual-polish.css','visual-polish.js','manifest.webmanifest','icon.svg','icon-192.png','icon-512.png','icon-maskable-512.png'].includes(name)){
  e.respondWith(onlineFirst(req));
 }
});
