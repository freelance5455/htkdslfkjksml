const CACHE = 'forma-pwa-v10-1';
const ROOT = new URL('./', self.location.href);
const ASSETS = ['index.html','install.js','manifest.webmanifest','icons/icon-192.png','icons/icon-512.png','icons/maskable-512.png'];
const urls = ASSETS.map(path => new URL(path, ROOT).href);
// Never cache redirected sign-in pages or third-party requests.
const safe = response => response.ok && !response.redirected && response.type === 'basic';
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    for (const url of urls) {
      const response = await fetch(new Request(url, {cache: 'reload', credentials: 'same-origin'}));
      if (!safe(response)) throw new Error('App assets unavailable');
      await cache.put(url, response);
    }
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) if (key.startsWith('forma-pwa-') && key !== CACHE) await caches.delete(key);
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== ROOT.origin) return;
  const home = request.mode === 'navigate' && (url.pathname === ROOT.pathname || url.pathname === new URL('index.html', ROOT).pathname);
  if (home) {
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        if (safe(response)) {
          const cache = await caches.open(CACHE);
          await cache.put(new URL('index.html', ROOT).href, response.clone());
        }
        return response;
      } catch {
        return await caches.match(new URL('index.html', ROOT).href) || new Response('Please connect to the internet to open Forma.', {status: 503, headers: {'Content-Type':'text/plain; charset=utf-8'}});
      }
    })());
  } else if (urls.includes(url.href)) {
    event.respondWith(caches.match(request).then(cached => cached || fetch(request)));
  }
});
