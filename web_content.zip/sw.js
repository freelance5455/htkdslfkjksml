/* سراج - Service Worker: offline-first app shell */
const CACHE_NAME = "siraj-v3";
const APP_SHELL = [
  "./",
  "index.html",
  "manifest.webmanifest",
  "icons/icon-192.png",
  "icons/icon-512.png",
  "icons/icon-maskable-512.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys.filter((key) => key.startsWith("siraj-") && key !== CACHE_NAME)
          .map((key) => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  // Navigation: show the cached app immediately when offline; refresh cache when online.
  if (request.mode === "navigate") {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match("index.html") || await cache.match("./");
      try {
        const fresh = await fetch(request);
        if (fresh && fresh.ok) await cache.put("index.html", fresh.clone());
        return fresh;
      } catch (_) {
        return cached || new Response("افتح سراج مرة واحدة مع الاتصال بالإنترنت لتجهيزه للعمل دون اتصال.", {
          status: 503, headers: { "Content-Type": "text/plain; charset=utf-8" }
        });
      }
    })());
    return;
  }

  // Static same-origin files: cache-first, with background refresh when online.
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request);
    const network = fetch(request).then((response) => {
      if (response && response.ok && response.type === "basic") cache.put(request, response.clone());
      return response;
    }).catch(() => null);
    return cached || await network || new Response("غير متاح دون اتصال.", {
      status: 503, headers: { "Content-Type": "text/plain; charset=utf-8" }
    });
  })());
});
