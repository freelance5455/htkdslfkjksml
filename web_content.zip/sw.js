const CACHE_V5 = 'korbball-v5-archiv-full-cache';
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE_V5).then(c => c.addAll(['./', './index.html', './manifest.json', './icon.svg'])));
});
self.addEventListener('fetch', e => {
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});
