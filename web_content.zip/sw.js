/**
 * MedsReminder Service Worker
 * Offline Cache + Phone's Default Push Notifications for Medicine Doses & Stock Refills
 */

const CACHE_NAME = "meds-reminder-cache-v1.01";
const ASSETS = [
  "./",
  "./index.html",
  "./manifest.json",
  "./styles.css",
  "./script.js",
  "./icon-192.png",
  "./icon-512.png"
];

let backgroundDosesList = [];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE_NAME).then(c => c.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener("activate", (e) => {
  e.waitUntil(clients.claim());
});

self.addEventListener("fetch", (e) => {
  e.respondWith(
    caches.match(e.request).then(res => res || fetch(e.request).catch(() => caches.match("./index.html")))
  );
});

// Schedule doses via Notification Triggers API (Chromium/Android)
function scheduleBackgroundDoses(doses) {
  if (Array.isArray(doses)) {
    backgroundDosesList = doses;
  }

  if (typeof Notification !== 'undefined' && 'showTrigger' in Notification.prototype && typeof TimestampTrigger !== 'undefined') {
    backgroundDosesList.forEach((dose) => {
      const now = Date.now();
      if (dose.timestamp && dose.timestamp > now) {
        try {
          self.registration.showNotification(dose.title, {
            body: dose.body,
            icon: 'icon-192.png',
            badge: 'icon-192.png',
            vibrate: [200, 100, 200, 100, 300],
            tag: dose.tag,
            renotify: true,
            requireInteraction: true,
            silent: false, // Plays phone default notification ringtone
            showTrigger: new TimestampTrigger(dose.timestamp),
            data: {
              medId: dose.medId,
              doseIndex: dose.doseIndex,
              dateStr: dose.dateStr,
              url: './index.html'
            }
          }).catch(err => console.warn('Trigger error:', err));
        } catch (e) {
          console.warn('TimestampTrigger error:', e);
        }
      }
    });
  }
}

// Background dose check loop for active service worker
function checkAndFireDueDoses() {
  const now = Date.now();
  if (!backgroundDosesList || backgroundDosesList.length === 0) return;

  backgroundDosesList.forEach((dose) => {
    if (dose.timestamp && Math.abs(now - dose.timestamp) <= 75000 && !dose.fired) {
      dose.fired = true;
      self.registration.showNotification(dose.title, {
        body: dose.body,
        icon: 'icon-192.png',
        badge: 'icon-192.png',
        vibrate: [200, 100, 200, 100, 300],
        tag: dose.tag,
        renotify: true,
        requireInteraction: true,
        silent: false, // Plays phone default notification sound
        data: {
          medId: dose.medId,
          doseIndex: dose.doseIndex,
          dateStr: dose.dateStr,
          url: './index.html'
        }
      }).catch(e => console.warn(e));
    }
  });
}

// Periodic Background Sync event (Android background wakeup)
self.addEventListener("periodicsync", (event) => {
  if (event.tag === "check-medicine-doses") {
    event.waitUntil(checkAndFireDueDoses());
  }
});

// Messages from app client
self.addEventListener("message", (event) => {
  if (event.data) {
    if (event.data.type === "SYNC_SCHEDULE") {
      scheduleBackgroundDoses(event.data.doses);
    } else if (event.data.type === "CHECK_NOW") {
      checkAndFireDueDoses();
    }
  }
});

// Active background check interval
setInterval(checkAndFireDueDoses, 15000);

// Notification click handling
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const doseData = event.notification.data || {};

  event.waitUntil(
    clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url && "focus" in client) {
          if (doseData.medId) {
            client.postMessage({ type: 'FOCUS_MED', medId: doseData.medId });
          }
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow("./index.html");
      }
    })
  );
});
