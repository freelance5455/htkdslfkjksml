/* Highland Reach service worker: makes the game installable and playable offline.
   App files: cache-first (refreshed in the background). three.js and real-elevation tiles
   are cached the first time they are downloaded, so visited parts of Ethiopia load offline. */
const VER = 'hr-v7';
const SHELL = ['./', 'index.html', 'style.css', 'config.js', 'game.js', 'controls.js', 'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-maskable-512.png'];
const TILE = 'hr-tiles-v1', TILE_MAX = 1500;

self.addEventListener('install', e => { e.waitUntil(caches.open(VER).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VER && k !== TILE && k !== 'hr-lib-v1').map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

async function trim(cache, max) { const ks = await cache.keys(); for (let i = 0; i < ks.length - max; i++) await cache.delete(ks[i]); }

self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET') return;
  if (u.hostname === 's3.amazonaws.com' && u.pathname.includes('elevation-tiles-prod')) {          // elevation tiles
    e.respondWith(caches.open(TILE).then(async c => {
      const hit = await c.match(r); if (hit) return hit;
      try { const res = await fetch(r); if (res && (res.ok || res.type === 'opaque')) { c.put(r, res.clone()); trim(c, TILE_MAX); } return res; }
      catch (err) { return hit || Response.error(); }
    }));
  } else if (u.hostname === 'cdnjs.cloudflare.com') {                                            // three.js
    e.respondWith(caches.open('hr-lib-v1').then(async c => {
      const hit = await c.match(r); if (hit) return hit;
      const res = await fetch(r); if (res && (res.ok || res.type === 'opaque')) c.put(r, res.clone()); return res;
    }));
  } else if (u.origin === location.origin) {                                                      // app files
    e.respondWith(caches.open(VER).then(async c => {
      const hit = await c.match(r, { ignoreSearch: true });
      const net = fetch(r).then(res => { if (res && res.ok) c.put(r, res.clone()); return res; }).catch(() => null);
      return hit || (await net) || (r.mode === 'navigate' ? c.match('index.html') : Response.error());
    }));
  }
});
