const C='gsmad-v2';
self.addEventListener('install',e=>{self.skipWaiting();e.waitUntil(caches.open(C).then(c=>c.addAll(['./','./index.html','./manifest.webmanifest']).catch(()=>0)))});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!=C).map(x=>caches.delete(x)))).then(()=>clients.claim())));
self.addEventListener('fetch',e=>{const q=e.request;if(q.method!='GET')return;
e.respondWith(fetch(q).then(r=>{if(r&&(r.ok||r.type=='opaque')){const c=r.clone();caches.open(C).then(x=>x.put(q,c)).catch(()=>0)}return r}).catch(()=>caches.match(q).then(r=>r||(q.mode=='navigate'?caches.match('./index.html'):Response.error()))))});
