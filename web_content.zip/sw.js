// Minimal offline cache for the PWA route (PWABuilder / Add to Home Screen).
const CACHE = 'sika-v1';
const ASSETS = [
  './', './index.html', './support.js',
  './vendor/react.production.min.js', './vendor/react-dom.production.min.js',
  './manifest.webmanifest',
  './icons/icon-192.png', './icons/icon-512.png', './icons/icon-512-maskable.png'
];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(()=>self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(self.clients.claim()); });
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request).then(hit => hit || fetch(e.request).catch(()=>caches.match('./index.html'))));
});
