var C="labour-tracker-v30";
var SDK=["https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js","https://www.gstatic.com/firebasejs/10.12.2/firebase-auth-compat.js","https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore-compat.js","https://www.gstatic.com/firebasejs/10.12.2/firebase-app-check-compat.js"];
self.addEventListener("install",function(e){e.waitUntil(caches.open(C).then(function(c){
  var sdk=SDK.map(function(u){return c.add(new Request(u,{mode:"no-cors"})).catch(function(){})});
  return Promise.all([c.addAll(["./","index.html","manifest.json","icon-192.png","icon-512.png","apple-touch-icon.png","icon-maskable-192.png","icon-maskable-512.png"])].concat(sdk))}).then(function(){return self.skipWaiting()}))});
self.addEventListener("activate",function(e){e.waitUntil(caches.keys().then(function(ks){return Promise.all(ks.filter(function(k){return k!==C}).map(function(k){return caches.delete(k)}))}).then(function(){return self.clients.claim()}))});
// Fast start: show the saved copy at once, refresh it in the background for next time.
self.addEventListener("fetch",function(e){
  if(e.request.method!=="GET")return;
  var u=new URL(e.request.url);
  if(u.origin!==location.origin&&u.hostname!=="www.gstatic.com")return;
  if(u.pathname.indexOf("/api/")===0)return;
  e.respondWith(caches.match(e.request,{ignoreSearch:true}).then(function(hit){
    if(hit&&u.hostname==="www.gstatic.com")return hit;
    var net=fetch(e.request).then(function(r){if(r&&(r.ok||r.type==="opaque")){var cp=r.clone();caches.open(C).then(function(c){c.put(e.request,cp)})}return r}).catch(function(){return hit});
    return hit||net}))});
