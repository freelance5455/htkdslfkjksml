var CACHE="pymad-v1";
self.addEventListener("install",function(e){self.skipWaiting()});
self.addEventListener("activate",function(e){e.waitUntil(self.clients.claim())});
self.addEventListener("fetch",function(e){
  var req=e.request;if(req.method!=="GET")return;
  var url=new URL(req.url);if(url.origin!==self.location.origin)return;
  e.respondWith(fetch(req).then(function(resp){
    if(resp&&resp.ok){var copy=resp.clone();caches.open(CACHE).then(function(c){c.put(req,copy)})}
    return resp;
  }).catch(function(){return caches.match(req).then(function(hit){return hit||caches.match(self.registration.scope)})}));
});
