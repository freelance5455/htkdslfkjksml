const CACHE = "petit-francais-v3";
const SHELL = ["./", "index.html", "manifest.webmanifest", "icon.svg",
  "assets/icons/icon-192.png", "assets/icons/icon-512.png", "assets/icons/icon-maskable-512.png",
  "assets/images/cat-happy.svg", "assets/images/cat-sad.svg", "assets/images/cat-sleep.svg", "assets/images/bunny.svg", "assets/images/bear.svg",
  "assets/sounds/right.wav", "assets/sounds/wrong.wav", "assets/sounds/level.wav", "assets/sounds/done.wav"];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys()
    .then(keys => Promise.all(keys.filter(k => k !== CACHE && k !== "pf-state").map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

// Audio-Dateien werden mit Range-Anfragen geladen (Safari): aus dem Cache als 206 beantworten.
async function ranged(req, res) {
  const m = /bytes=(\d+)-(\d*)/.exec(req.headers.get("range") || "");
  if (!m || !res) return res;
  const buf = await res.arrayBuffer(), s = +m[1], e = m[2] ? +m[2] : buf.byteLength - 1;
  return new Response(buf.slice(s, e + 1), { status: 206, headers: {
    "Content-Type": res.headers.get("Content-Type") || "audio/wav",
    "Content-Range": `bytes ${s}-${e}/${buf.byteLength}`, "Content-Length": e - s + 1 } });
}

self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  e.respondWith((async () => {
    const cached = await caches.match(req, { ignoreSearch: true });
    // Stale-while-revalidate: sofort aus dem Cache, im Hintergrund aktualisieren
    const net = fetch(req).then(res => {
      if (res && res.ok && res.status === 200) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); }
      return res;
    }).catch(() => null);
    if (cached) { net.catch(() => {}); return ranged(req, cached); }
    const res = await net;
    if (res) return res;
    return (await caches.match("index.html")) || Response.error();
  })());
});

// ---- Erinnerungen (experimentell, nur Chrome/Android mit installierter App) ----
// Der Browser entscheidet, ob und wann "periodicsync" ausgelöst wird – es gibt keine Uhrzeit-Garantie.
self.addEventListener("periodicsync", e => { if (e.tag === "pf-daily") e.waitUntil(remind()); });
async function remind() {
  const c = await caches.open("pf-state"), r = await c.match("state.json");
  if (!r) return;
  const s = await r.json();
  if (!s.on) return;
  const n = new Date(), [h, m] = (s.time || "18:00").split(":").map(Number);
  if (n.getHours() * 60 + n.getMinutes() < h * 60 + m) return;
  const td = n.getFullYear() + "-" + String(n.getMonth() + 1).padStart(2, "0") + "-" + String(n.getDate()).padStart(2, "0");
  if (s.date === td && s.met) return;
  const nr = await c.match("notified.json");
  if (nr && (await nr.text()) === td) return;
  await c.put("notified.json", new Response(td));
  await self.registration.showNotification("Petit Français", {
    body: s.date === td && s.left ? `Heute noch ${s.left} Min lernen!` : "Zeit für deine Französisch-Runde!",
    icon: "assets/icons/icon-192.png", tag: "pf-daily" });
}
self.addEventListener("notificationclick", e => {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: "window" }).then(cl => cl.length ? cl[0].focus() : self.clients.openWindow("./")));
});
