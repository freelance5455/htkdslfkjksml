/* عامل خدمة: تخزين مؤقت للتطبيق ليعمل دون إنترنت. الإصدار e090ef5a6a يتغير مع كل بناء فيُحدَّث التخزين تلقائياً. بيانات الطلاب لا تمر هنا أبداً (تبقى في المتصفح). */
const CACHE = 'exam-dept-e090ef5a6a';
const SHELL = ['./', 'index.html', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png'];
self.addEventListener('install', e=>{ e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting())); });
self.addEventListener('activate', e=>{ e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k.startsWith('exam-dept-') && k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())); });
self.addEventListener('fetch', e=>{
  const u = new URL(e.request.url);
  if(e.request.method !== 'GET' || u.origin !== location.origin) return;     // لا نعترض الطلبات الخارجية
  e.respondWith(caches.match(e.request, { ignoreSearch:true }).then(hit=> hit || fetch(e.request).then(r=>{ if(r.ok){ const c = r.clone(); caches.open(CACHE).then(x=>x.put(e.request, c)); } return r; }).catch(()=> caches.match('index.html'))));
});
