// Digital Printable service worker: fast cached start, background refresh. Backend calls are never cached.
const CACHE = "dp-v5";
const CORE = ["./", "./pro.js", "./manifest.webmanifest", "./icons/icon-192.png", "./icons/icon-512.png"];
self.addEventListener("install", (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(CORE)).then(() => self.skipWaiting())); });
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((k) => Promise.all(k.filter((x) => x !== CACHE).map((x) => caches.delete(x)))).then(() => self.clients.claim()));
});
// Browsers refuse to show a response that went through a redirect, so never store or serve one for a page load.
async function clean(res) {
  if (!res || !res.redirected) return res;
  return new Response(await res.blob(), { status: res.status, statusText: res.statusText, headers: res.headers });
}
self.addEventListener("fetch", (e) => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== "GET" || url.hostname.endsWith("supabase.co") || req.headers.has("range")) return;
  if (req.mode === "navigate") {
    if (url.pathname.endsWith("/index.html")) { e.respondWith(Response.redirect(url.pathname.replace(/index\.html$/, "") + url.search, 302)); return; }
    e.respondWith(caches.open(CACHE).then(async (cache) => {
      const hit = await cache.match("./");
      const net = fetch("./").then(clean).then((res) => { if (res && res.ok) cache.put("./", res.clone()); return res; }).catch(() => hit);
      return hit || net;
    }));
    return;
  }
  e.respondWith(caches.open(CACHE).then((cache) => cache.match(req).then((hit) => {
    const net = fetch(req).then((res) => { if (res && (res.status === 200 || res.type === "opaque")) cache.put(req, res.clone()); return res; }).catch(() => hit);
    return hit || net;
  })));
});
