// Service Worker básico para permitir instalación PWA y funcionamiento offline
const CACHE_NAME = 'metallic-feast-v2';
const ASSETS = [
  './',
  './index.html',
  './style.css',
  './data.js',
  './data_expansion.js',
  './game.js',
  './manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    // cache:'reload' evita guardar copias viejas que el navegador tenga en su caché HTTP
    caches.open(CACHE_NAME).then((cache) =>
      cache.addAll(ASSETS.map((url) => new Request(url, { cache: 'reload' })))
    )
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Red primero (así siempre ves la última versión del juego) y caché como respaldo sin conexión
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    fetch(event.request)
      .then((res) => {
        if (res && res.ok && new URL(event.request.url).origin === self.location.origin) {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        }
        return res;
      })
      .catch(() => caches.match(event.request))
  );
});
