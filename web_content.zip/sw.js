/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "b559ff6ff5bf739f727df432fbd4de3a"
  }, {
    "url": "pwa-512x512.png",
    "revision": "b2cd706e1b006086a2bdfa0eea876601"
  }, {
    "url": "pwa-192x192.png",
    "revision": "dfbc3c9ac0dc71ecd7bb94aa43a55330"
  }, {
    "url": "index.html",
    "revision": "8f247fd343bc5170de1d71ffab8ca5ba"
  }, {
    "url": "icon.svg",
    "revision": "7b342af6238cb234984a53f2cbc19edc"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "0e364ee3308ff68ca0926456ba7bc402"
  }, {
    "url": "src/assets/images/hero_elevator_engineering_1795091428913.jpg",
    "revision": "d21d2ae21276eb5eafb780f6ebd1b5e0"
  }, {
    "url": "src/assets/images/hamyar_service_logo_1795098046625.jpg",
    "revision": "f1345c42e6ea64190d3ea2b047e14593"
  }, {
    "url": "assets/workbox-window.prod.es5-Dxeuga9-.js",
    "revision": null
  }, {
    "url": "assets/index-Cvd-jVKx.css",
    "revision": null
  }, {
    "url": "assets/index-Cm2sRzfq.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "0e364ee3308ff68ca0926456ba7bc402"
  }, {
    "url": "icon.svg",
    "revision": "7b342af6238cb234984a53f2cbc19edc"
  }, {
    "url": "pwa-192x192.png",
    "revision": "dfbc3c9ac0dc71ecd7bb94aa43a55330"
  }, {
    "url": "pwa-512x512.png",
    "revision": "b2cd706e1b006086a2bdfa0eea876601"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "b559ff6ff5bf739f727df432fbd4de3a"
  }, {
    "url": "manifest.webmanifest",
    "revision": "99d63b4907520f3001b17007c97f00db"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("/index.html"), {
    denylist: [/^\/downloads\//, /^\/api\//]
  }));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
