/* غيّر رقم الإصدار عند كل تحديث للملفات */
const V='ayman-cashflow-v4';
const SHELL=['./','index.html','manifest.webmanifest','css/style.css','js/storage.js','js/pwa.js','js/app.js','js/drive-backup.js','js/cloud.js','icons/icon-192.png','icons/icon-512.png'];
const XLSX_CDN='https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js',XLSX_LOCAL='lib/xlsx.full.min.js';
self.addEventListener('install',e=>{e.waitUntil((async()=>{const c=await caches.open(V);await c.addAll(SHELL);
 await Promise.allSettled([c.add(XLSX_LOCAL),fetch(XLSX_CDN,{mode:'no-cors'}).then(r=>c.put(XLSX_CDN,r))]);self.skipWaiting()})())});
self.addEventListener('activate',e=>{e.waitUntil((async()=>{for(const k of await caches.keys())if(k!==V)await caches.delete(k);await self.clients.claim()})())});
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET')return;const u=new URL(r.url);
 if(r.url===XLSX_CDN||u.pathname.endsWith('/'+XLSX_LOCAL)){e.respondWith(caches.match(r).then(h=>h||fetch(r).then(n=>{const c=n.clone();caches.open(V).then(x=>x.put(r,c));return n})));return}
 if(u.origin!==location.origin)return;
 /* شبكة أولاً (لتصل التحديثات) ثم الكاش عند انقطاع الإنترنت */
 e.respondWith(Promise.race([fetch(r).then(n=>{if(n.ok){const c=n.clone();caches.open(V).then(x=>x.put(r,c))}return n}),new Promise((_,j)=>setTimeout(j,5000))]).catch(()=>caches.match(r,{ignoreSearch:true}).then(h=>h||(r.mode==='navigate'?caches.match('index.html'):Response.error()))))});
