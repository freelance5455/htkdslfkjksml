// Offa V18 intentionally does not cache application files in a service worker.
self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => self.clients.claim());
