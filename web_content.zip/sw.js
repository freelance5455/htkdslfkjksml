const VERSION = 'goalos-shell-v3';
const SHELL = `${VERSION}-shell`;
const ASSETS = `${VERSION}-assets`;
const APP_SHELL = ['./index.html', './manifest.json', './favicon.svg'];

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    try {
      const shell = await caches.open(SHELL);
      await shell.addAll(APP_SHELL);
      const response = await shell.match('./index.html');
      if (response) {
        const html = await response.clone().text();
        const paths = [...html.matchAll(/(?:src|href)=["']([^"']+)["']/g)]
          .map(match => match[1])
          .filter(path => !path.startsWith('data:') && !path.startsWith('http'));
        const assets = await caches.open(ASSETS);
        await Promise.all(
          paths.map(path =>
            fetch(new URL(path, self.registration.scope).href)
              .then(res => (res.ok ? assets.put(path, res) : null))
              .catch(() => null)
          )
        );
      }
    } catch {
      // If pre-caching fails for any reason, the app still works online;
      // it just won't have an offline app shell cached yet.
    }
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith('goalos-') && key !== SHELL && key !== ASSETS).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});
self.addEventListener('message', event => {
  if (event.data === 'CHECK_FOR_UPDATES') self.registration.update().catch(() => {});
});
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET' || new URL(request.url).origin !== self.location.origin) return;
  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        if (response.ok) {
          const cache = await caches.open(SHELL);
          await cache.put('./index.html', response.clone());
        }
        return response;
      } catch {
        const cache = await caches.open(SHELL);
        return (await cache.match('./index.html')) || Response.error();
      }
    })());
    return;
  }
  event.respondWith((async () => {
    const cache = await caches.open(ASSETS);
    const cached = await cache.match(request);
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response.ok && (response.type === 'basic' || response.type === 'cors')) await cache.put(request, response.clone());
      return response;
    } catch {
      return cached || Response.error();
    }
  })());
});
