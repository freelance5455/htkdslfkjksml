const CACHE = 'stockly-twin-v2';
const ASSETS = ['./', './index.html', './app.js', './manifest.json'];
self.addEventListener('install', e => e.waitUntil(
  caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting())
));
self.addEventListener('activate', e => e.waitUntil(
  caches.keys().then(k => Promise.all(k.filter(x => x !== CACHE).map(x => caches.delete(x))))
    .then(() => self.clients.claim())
));
self.addEventListener('fetch', e => e.respondWith(
  caches.match(e.request).then(r => r || fetch(e.request).then(x => {
    const y = x.clone();
    caches.open(CACHE).then(c => c.put(e.request, y));
    return x;
  }).catch(() => caches.match('./index.html')))
));
