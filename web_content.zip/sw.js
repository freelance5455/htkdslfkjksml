const CACHE = 'vortex-v3';
const SHELL = ['./', './index.html', './config.js', './verified.js', './manifest.webmanifest', './vortex.svg', './logo.png',
  './icons/icon-192.png', './icons/icon-512.png'];
const SERVER = (self.VORTEX_SERVER_URL || '').replace(/\/$/, '');

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((k) => Promise.all(k.filter((x) => x !== CACHE).map((x) => caches.delete(x))))
    .then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  // API / загрузки / сокеты — никогда не кэшируем
  if (/^\/(api|uploads|socket\.io)\b/.test(url.pathname)) return;
  e.respondWith(
    caches.match(req).then((hit) => hit || fetch(req).then((res) => {
      if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); }
      return res;
    }).catch(() => req.mode === 'navigate' ? caches.match('./index.html') : Response.error()))
  );
});
