/* Polyglot Education — minimal service worker.
 * Maqsad: ilovani o‘rnatish mumkin bo‘lishi va internet uzilganda qobiq (shell) ochilishi.
 * Supabase (boshqa domen) so‘rovlari va barcha POST/PUT so‘rovlari HECH QACHON keshlanmaydi —
 * shuning uchun ma’lumotlar (to‘lov, Coin, baho) eskirib qolmaydi. */
const VERSION = 'hero-v1'
const SHELL = VERSION + '-shell'
const ASSETS = VERSION + '-assets'

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(SHELL).then((c) => c.add('/')).catch(() => {}))
  self.skipWaiting()
})

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  )
})

self.addEventListener('fetch', (e) => {
  const req = e.request
  if (req.method !== 'GET') return
  const url = new URL(req.url)
  if (url.origin !== self.location.origin) return // Supabase, Google Fonts — brauzer o‘zi hal qiladi

  // Sahifa ochilishi: avval tarmoq (yangi versiya), uzilsa — keshdagi qobiq
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req)
        .then((res) => { const copy = res.clone(); caches.open(SHELL).then((c) => c.put('/', copy)); return res })
        .catch(() => caches.match('/'))
    )
    return
  }

  // Hash'li statik fayllar (/assets/*, ikonkalar, shriftlar): avval kesh
  if (url.pathname.startsWith('/assets/') || url.pathname.startsWith('/icons/') || url.pathname.startsWith('/fonts/') || url.pathname === '/logo.svg') {
    e.respondWith(
      caches.match(req).then((hit) => hit || fetch(req).then((res) => {
        if (res.ok) { const copy = res.clone(); caches.open(ASSETS).then((c) => c.put(req, copy)) }
        return res
      }))
    )
  }
})
