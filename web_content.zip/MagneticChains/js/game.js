(function () {
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');

    let viewWidth = 1000;
    let viewHeight = 600;
    let scaleRatio = 1;

    function resizeCanvas() {
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        const isPortrait = window.innerWidth < window.innerHeight;

        // Завдяки віртуальному розвороту в CSS ширина полотна завжди відповідає більшій стороні екрана
        const w = isPortrait ? Math.max(window.innerWidth, window.innerHeight) : window.innerWidth;
        const h = isPortrait ? Math.min(window.innerWidth, window.innerHeight) : window.innerHeight;

        canvas.width = w * dpr;
        canvas.height = h * dpr;

        const baseAspect = 16 / 9;
        const currentAspect = w / h;
        if (currentAspect > baseAspect) {
            viewHeight = 600;
            viewWidth = 600 * currentAspect;
        } else {
            viewWidth = 1060;
            viewHeight = 1060 / currentAspect;
        }
        scaleRatio = (w * dpr) / viewWidth;
    }
    window.addEventListener('resize', resizeCanvas);
    window.addEventListener('orientationchange', () => {
        setTimeout(resizeCanvas, 150);
    });
    document.addEventListener('fullscreenchange', resizeCanvas);
    document.addEventListener('webkitfullscreenchange', resizeCanvas);
    resizeCanvas();

    function autoLockLandscape() {
        try {
            const docEl = document.documentElement;
            const requestFS = docEl.requestFullscreen || docEl.webkitRequestFullscreen || docEl.mozRequestFullScreen || docEl.msRequestFullscreen;
            const isFS = document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement;

            if (!isFS && requestFS) {
                const p = requestFS.call(docEl);
                if (p && p.then) {
                    p.then(() => {
                        if (screen.orientation && screen.orientation.lock) {
                            screen.orientation.lock('landscape').catch(() => { });
                        }
                    }).catch(() => { });
                }
            } else if (screen.orientation && screen.orientation.lock) {
                screen.orientation.lock('landscape').catch(() => { });
            }
        } catch (e) { }
    }

    const CEILING_Y = 125;
    const FLOOR_Y = 475;
    const PLAYER_RADIUS = 20;

    const STATE = {
        MENU: 'MENU',
        PLAYING: 'PLAYING',
        PAUSED: 'PAUSED',
        GAMEOVER: 'GAMEOVER',
        VICTORY: 'VICTORY'
    };

    let currentGameState = STATE.MENU;
    let activeGameMode = 'ENDLESS';
    let currentAdventureWorld = 1;
    let currentAdventureLevel = 1;

    let gameSpeed = 8.5;
    let distanceTravelled = 0;
    let currentScore = 0;
    let levelLength = 42000;

    let floatingTexts = [];
    let screenShake = 0;

    let endlessBiomeTimer = 0;
    const BIOME_STABLE_DURATION = 55;
    const BIOME_TRANSITION_DURATION = 7.0;
    const BIOME_TOTAL_CYCLE = BIOME_STABLE_DURATION + BIOME_TRANSITION_DURATION;

    let isBiomeTransitioning = false;
    let biomeTransitionProgress = 0;
    let fromBiomeTheme = window.WorldRegistry.getTheme(1);
    let toBiomeTheme = window.WorldRegistry.getTheme(2);

    let activeBiome = window.WorldRegistry.getTheme(1);
    let currentBiomeIndex = 0;
    let cameraX = 0;
    let obstacles = [];

    const STORAGE_KEY = "dual_gravity_chains_36_skins_master_v1";

    let gameData = {
        unlockedWorld: 30,
        levelsCompletedPerWorld: Array(30).fill(100),
        endlessHighScore: 2500,
        nearMisses: 42,
        totalFlips: 350,
        equippedSkinId: "base_robot"
    };

    function loadGameData() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (raw) {
                const parsed = JSON.parse(raw);
                gameData = { ...gameData, ...parsed };
            }
        } catch (e) { }
        gameData.unlockedWorld = 30;
        gameData.levelsCompletedPerWorld = Array(30).fill(100);
        if (!window.ALL_SKINS_LIST.some(s => s.id === gameData.equippedSkinId)) {
            gameData.equippedSkinId = "base_robot";
        }
    }

    function saveGameData() {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(gameData));
        } catch (e) { }
        updateStatsUI();
        updateShowcaseSkin();
    }

    loadGameData();

    const player = new window.PlayerManager(CEILING_Y, FLOOR_Y, PLAYER_RADIUS);

    function addFloatingText(text, x, y, color = '#facc15') {
        floatingTexts.push({
            text, x, y, color,
            alpha: 1.0,
            vy: -0.7,
            timer: 0,
            maxLife: 85 // 1.4 секунди життя на екрані
        });
    }

    function startEndlessGame() {
        autoLockLandscape();
        activeGameMode = 'ENDLESS';
        currentBiomeIndex = 0;
        activeBiome = window.WorldRegistry.getTheme(1);
        fromBiomeTheme = activeBiome;
        toBiomeTheme = window.WorldRegistry.getTheme(2);

        isBiomeTransitioning = false;
        biomeTransitionProgress = 0;
        endlessBiomeTimer = 0;

        gameSpeed = 8.5;
        endlessNextSpawnX = 700;
        obstacles = [];
        floatingTexts = [];
        screenShake = 0;

        player.reset();
        cameraX = 0;
        distanceTravelled = 0;
        currentScore = 0;

        currentGameState = STATE.PLAYING;
        hideAllOverlays();
        window.sound.startMusic(gameSpeed);
    }

    function startAdventureLevel(world, level) {
        autoLockLandscape();
        activeGameMode = 'ADVENTURE';
        currentAdventureWorld = world;
        currentAdventureLevel = level;

        activeBiome = window.WorldRegistry.getTheme(world);
        isBiomeTransitioning = false;
        biomeTransitionProgress = 0;

        gameSpeed = 8.5 + (world - 1) * 0.08 + (level - 1) * 0.02;

        const generated = window.WorldRegistry.generateLevel(world, level, CEILING_Y, FLOOR_Y, gameSpeed);
        obstacles = generated.obstacles;
        levelLength = generated.levelLength;
        floatingTexts = [];
        screenShake = 0;

        player.reset();
        cameraX = 0;
        distanceTravelled = 0;
        currentScore = 0;

        currentGameState = STATE.PLAYING;
        hideAllOverlays();
        window.sound.startMusic(gameSpeed);
    }

    let endlessNextSpawnX = 700;
    function updateEndlessSpawning() {
        const minSafeReactionDistance = gameSpeed * 15 + 45;
        while (endlessNextSpawnX < player.x + viewWidth + 600) {
            const rng = Math.random;
            const patternIdx = Math.floor(rng() * window.OBSTACLE_PATTERNS.length);
            const pattern = window.OBSTACLE_PATTERNS[patternIdx](endlessNextSpawnX, 1, rng, CEILING_Y, FLOOR_Y);

            pattern.objs.forEach(obj => obstacles.push(obj));
            endlessNextSpawnX += Math.max(pattern.advance, minSafeReactionDistance);
        }
        obstacles = obstacles.filter(o => (o.type === 'RAIL_GAP' ? o.x + o.width : o.x) > player.x - 350);
    }

    function circleIntersectsSpike(cx, cy, r, ob) {
        const tipX = ob.x;
        const tipY = ob.onCeil ? ob.y + ob.h : ob.y - ob.h;
        const bLeftX = ob.x - ob.w / 2;
        const bRightX = ob.x + ob.w / 2;

        const dx = cx - tipX;
        const dy = cy - tipY;
        if (Math.sqrt(dx * dx + dy * dy) < r * 0.75) return true;

        if (cx > bLeftX && cx < bRightX) {
            if (ob.onCeil && cy - r < tipY) return true;
            if (!ob.onCeil && cy + r > tipY) return true;
        }
        return false;
    }

    function triggerNearMiss() {
        player.nearMissTimer = 25;
        gameData.nearMisses++;
        currentScore += 100;
        screenShake = 4;
        window.sound.playNearMiss();

        const toast = document.getElementById('nearMissToast');
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 600);

        const curSkin = window.SkinRegistry.get(gameData.equippedSkinId);
        for (let i = 0; i < 10; i++) {
            player.particles.push({
                x: player.x + (Math.random() - 0.5) * 20,
                y: player.y + (Math.random() - 0.5) * 20,
                vx: (Math.random() - 0.5) * 6,
                vy: (Math.random() - 0.5) * 6,
                size: 4,
                color: curSkin.trailCol || '#00f0ff',
                alpha: 1,
                life: 22
            });
        }
    }

    function triggerDeath() {
        currentGameState = STATE.GAMEOVER;
        screenShake = 10;
        window.sound.stopMusic();
        window.sound.playCrash();

        const curSkin = window.SkinRegistry.get(gameData.equippedSkinId);
        for (let i = 0; i < 40; i++) {
            const ang = Math.random() * Math.PI * 2;
            const spd = Math.random() * 8 + 2;
            player.particles.push({
                x: player.x,
                y: player.y,
                vx: Math.cos(ang) * spd,
                vy: Math.sin(ang) * spd,
                size: Math.random() * 6 + 3,
                color: [curSkin.trailCol, activeBiome.railFloor, '#f43f5e', '#ffffff'][Math.floor(Math.random() * 4)],
                alpha: 1,
                life: 40
            });
        }

        saveGameData();

        let scoreMsg = "";
        if (activeGameMode === 'ENDLESS') {
            const distM = Math.floor(distanceTravelled / 10);
            if (distM > gameData.endlessHighScore) {
                gameData.endlessHighScore = distM;
                saveGameData();
            }
            scoreMsg = `Дистанція: ${distM} м • Рахунок: ${currentScore}`;
        } else {
            const pct = Math.min(100, Math.floor((player.x / levelLength) * 100));
            scoreMsg = `Світ ${currentAdventureWorld} • Рівень ${currentAdventureLevel} • Пройдено: ${pct}%`;
        }

        document.getElementById('gameOverScoreText').textContent = scoreMsg;
        document.getElementById('gameOverOverlay').classList.remove('hidden');
    }

    function triggerVictory() {
        currentGameState = STATE.VICTORY;
        screenShake = 0;
        window.sound.stopMusic();
        window.sound.playVictory();

        document.getElementById('victorySubtitle').textContent = `Світ ${currentAdventureWorld} • Рівень ${currentAdventureLevel} завершено!`;
        document.getElementById('victoryOverlay').classList.remove('hidden');
    }

    function checkHazards() {
        if (player.y < -40 || player.y > viewHeight + 40) {
            triggerDeath();
            return;
        }

        for (let ob of obstacles) {
            if (ob.x > player.x + 90 || ob.x < player.x - 90) continue;

            if (ob.type === 'FLUX_ORB' && !ob.collected) {
                const d = Math.hypot(player.x - ob.x, player.y - ob.y);
                if (d < PLAYER_RADIUS + ob.radius + 12) {
                    ob.collected = true;
                    player.combo++;
                    const points = ob.value * Math.min(5, Math.floor(player.combo / 3) + 1);
                    currentScore += points;
                    window.sound.playCollectOrb(player.combo);

                    const comboText = player.combo > 2 ? `+${points} [x${Math.min(5, Math.floor(player.combo / 3) + 1)}]` : `+${points}`;
                    addFloatingText(comboText, ob.x, ob.y - 15, '#38bdf8');

                    for (let p = 0; p < 8; p++) {
                        player.particles.push({
                            x: ob.x, y: ob.y,
                            vx: (Math.random() - 0.5) * 6,
                            vy: (Math.random() - 0.5) * 6,
                            size: 3.5, color: '#38bdf8',
                            alpha: 1, life: 18
                        });
                    }
                }
            }

            if (ob.type === 'BOOST_RING' && !ob.passed) {
                const d = Math.hypot(player.x - ob.x, player.y - ob.y);
                if (d < PLAYER_RADIUS + ob.radius + 8) {
                    ob.passed = true;
                    player.triggerBoost(window.sound);
                    currentScore += 300;
                    screenShake = 6;
                    addFloatingText("SPEED BOOST!", ob.x, ob.y - 25, '#facc15');
                }
            }

            if (ob.type === 'FINISH_GATE') {
                if (player.x >= ob.x) {
                    triggerVictory();
                    return;
                }
            }

            if (player.boostTimer > 0) continue;

            const distToObstacle = Math.abs(player.x - ob.x);
            if (distToObstacle < PLAYER_RADIUS + 32 && player.nearMissTimer === 0) {
                let isClose = false;
                if (ob.type === 'SPIKE') {
                    const tipY = ob.onCeil ? ob.y + ob.h : ob.y - ob.h;
                    if (Math.abs(player.y - tipY) < PLAYER_RADIUS + 24) isClose = true;
                } else if (ob.type === 'SAW') {
                    const d = Math.hypot(player.x - ob.x, player.y - ob.y);
                    if (d < PLAYER_RADIUS + ob.radius + 22) isClose = true;
                }
                if (isClose) triggerNearMiss();
            }

            if (ob.type === 'SPIKE') {
                if (circleIntersectsSpike(player.x, player.y, PLAYER_RADIUS, ob)) {
                    triggerDeath();
                    return;
                }
            } else if (ob.type === 'SAW') {
                const d = Math.hypot(player.x - ob.x, player.y - ob.y);
                if (d < PLAYER_RADIUS + ob.radius * 0.78) {
                    triggerDeath();
                    return;
                }
            } else if (ob.type === 'LASER') {
                if (player.x + PLAYER_RADIUS * 0.7 > ob.x - ob.width / 2 &&
                    player.x - PLAYER_RADIUS * 0.7 < ob.x + ob.width / 2) {
                    if (player.y >= ob.y1 && player.y <= ob.y2) {
                        triggerDeath();
                        return;
                    }
                }
            }
        }
    }

    function updateGame(deltaScale, deltaSec) {
        if (currentGameState !== STATE.PLAYING) return;

        const stepDist = player.updatePhysics(deltaScale, gameSpeed, window.sound, obstacles);
        distanceTravelled += stepDist;
        currentScore += Math.floor(gameSpeed * 0.4 * deltaScale);
        cameraX = player.x - 200;

        checkHazards();

        for (let i = floatingTexts.length - 1; i >= 0; i--) {
            const ft = floatingTexts[i];
            ft.y += ft.vy;
            ft.timer++;
            if (ft.timer > 55) {
                ft.alpha = Math.max(0, 1 - (ft.timer - 55) / 30);
            }
            if (ft.timer >= ft.maxLife) floatingTexts.splice(i, 1);
        }

        const distM = Math.floor(distanceTravelled / 10);
        document.getElementById('hudDistance').textContent = `${distM}m`;
        document.getElementById('hudScore').textContent = `${currentScore}${player.combo > 1 ? ` (x${Math.min(5, Math.floor(player.combo / 3) + 1)})` : ''}`;

        if (activeGameMode === 'ENDLESS') {
            updateEndlessSpawning();
            endlessBiomeTimer += deltaSec;

            const themes = window.WORLD_THEMES || [];
            const nextIdx = (currentBiomeIndex + 1) % themes.length;

            if (endlessBiomeTimer < BIOME_STABLE_DURATION) {
                isBiomeTransitioning = false;
                biomeTransitionProgress = 0;
                fromBiomeTheme = themes[currentBiomeIndex];
                toBiomeTheme = themes[nextIdx];
                activeBiome = fromBiomeTheme;
            } else if (endlessBiomeTimer < BIOME_TOTAL_CYCLE) {
                isBiomeTransitioning = true;
                const elapsed = endlessBiomeTimer - BIOME_STABLE_DURATION;
                biomeTransitionProgress = Math.min(1.0, elapsed / BIOME_TRANSITION_DURATION);
                fromBiomeTheme = themes[currentBiomeIndex];
                toBiomeTheme = themes[nextIdx];
            } else {
                endlessBiomeTimer = 0;
                currentBiomeIndex = nextIdx;
                activeBiome = themes[currentBiomeIndex];
                fromBiomeTheme = activeBiome;
                toBiomeTheme = themes[(currentBiomeIndex + 1) % themes.length];
                isBiomeTransitioning = false;
                biomeTransitionProgress = 0;
            }

            gameSpeed = Math.min(15.5, 8.5 + (distM / 300) * 0.28);
        } else {
            isBiomeTransitioning = false;
            biomeTransitionProgress = 0;
        }
    }

    function renderObstacles(time) {
        ctx.save();
        ctx.translate(-cameraX, 0);

        for (let ob of obstacles) {
            if (ob.x < cameraX - 100 || ob.x > cameraX + viewWidth + 100) continue;

            if (ob.type === 'FLUX_ORB') {
                if (ob.collected) continue;
                ctx.save();
                const pulse = 1.0 + Math.sin(time * 0.008 + ob.x) * 0.18;
                ctx.translate(ob.x, ob.y);
                ctx.scale(pulse, pulse);

                ctx.shadowColor = '#00f0ff';
                ctx.shadowBlur = 12;
                ctx.fillStyle = '#00f0ff';
                ctx.beginPath();
                ctx.arc(0, 0, ob.radius, 0, Math.PI * 2);
                ctx.fill();

                ctx.fillStyle = '#ffffff';
                ctx.beginPath();
                ctx.arc(0, 0, ob.radius * 0.45, 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();
            } else if (ob.type === 'BOOST_RING') {
                ctx.save();
                ctx.translate(ob.x, ob.y);
                ctx.shadowColor = '#facc15';
                ctx.shadowBlur = 16;

                ctx.lineWidth = 5;
                ctx.strokeStyle = ob.passed ? '#475569' : '#facc15';
                ctx.beginPath();
                ctx.ellipse(0, 0, ob.radius * 0.45, ob.radius, 0, 0, Math.PI * 2);
                ctx.stroke();

                ctx.lineWidth = 2.5;
                ctx.strokeStyle = '#ffffff';
                ctx.beginPath();
                ctx.ellipse(0, 0, ob.radius * 0.25, ob.radius * 0.75, 0, 0, Math.PI * 2);
                ctx.stroke();
                ctx.restore();
            } else if (ob.type === 'SPIKE') {
                ctx.save();
                const isCeil = ob.onCeil;
                const tipY = isCeil ? ob.y + ob.h : ob.y - ob.h;
                const bLeftX = ob.x - ob.w / 2;
                const bRightX = ob.x + ob.w / 2;

                ctx.fillStyle = '#1e293b';
                ctx.lineWidth = 2;
                ctx.strokeStyle = '#0f172a';
                const basePlateY = isCeil ? ob.y : ob.y - 6;
                ctx.beginPath();
                ctx.roundRect(bLeftX - 3, basePlateY, ob.w + 6, 6, 2);
                ctx.fill();
                ctx.stroke();

                ctx.fillStyle = '#fb7185';
                ctx.beginPath();
                ctx.moveTo(bLeftX, ob.y); ctx.lineTo(ob.x, tipY); ctx.lineTo(ob.x, ob.y);
                ctx.closePath(); ctx.fill();

                ctx.fillStyle = '#be185d';
                ctx.beginPath();
                ctx.moveTo(ob.x, ob.y); ctx.lineTo(ob.x, tipY); ctx.lineTo(bRightX, ob.y);
                ctx.closePath(); ctx.fill();

                ctx.lineWidth = 3.5;
                ctx.strokeStyle = '#2e1065';
                ctx.beginPath();
                ctx.moveTo(bLeftX, ob.y); ctx.lineTo(ob.x, tipY); ctx.lineTo(bRightX, ob.y);
                ctx.closePath(); ctx.stroke();
                ctx.restore();
            } else if (ob.type === 'SAW') {
                ctx.save();
                ctx.translate(ob.x, ob.y);
                ctx.rotate(time * (ob.rotSpeed || 0.006));

                ctx.shadowColor = '#d946ef';
                ctx.shadowBlur = 18;

                ctx.beginPath();
                const teeth = 10;
                for (let i = 0; i < teeth * 2; i++) {
                    const ang = (i * Math.PI) / teeth;
                    const r = i % 2 === 0 ? ob.radius : ob.radius * 0.68;
                    const sx = Math.cos(ang) * r;
                    const sy = Math.sin(ang) * r;
                    if (i === 0) ctx.moveTo(sx, sy);
                    else ctx.lineTo(sx, sy);
                }
                ctx.closePath();
                ctx.fillStyle = '#a855f7';
                ctx.fill();
                ctx.lineWidth = 3.5;
                ctx.strokeStyle = '#581c87';
                ctx.stroke();

                ctx.beginPath();
                ctx.arc(0, 0, ob.radius * 0.45, 0, Math.PI * 2);
                ctx.fillStyle = '#fdf4ff';
                ctx.fill();
                ctx.lineWidth = 3;
                ctx.strokeStyle = '#a855f7';
                ctx.stroke();

                ctx.beginPath();
                ctx.arc(0, 0, ob.radius * 0.2, 0, Math.PI * 2);
                ctx.fillStyle = '#6b21a8';
                ctx.fill();
                ctx.restore();
            } else if (ob.type === 'LASER') {
                ctx.save();
                const pulse = (Math.sin(time * 0.015) + 1) * 0.5;
                ctx.shadowColor = '#00f0ff';
                ctx.shadowBlur = 15;

                ctx.fillStyle = `rgba(0, 240, 255, ${0.45 + pulse * 0.35})`;
                ctx.fillRect(ob.x - ob.width / 2, ob.y1, ob.width, ob.y2 - ob.y1);
                ctx.fillStyle = '#ffffff';
                ctx.fillRect(ob.x - 2, ob.y1, 4, ob.y2 - ob.y1);

                ctx.fillStyle = '#ea580c';
                ctx.fillRect(ob.x - 14, ob.y1 - 6, 28, 8);
                ctx.fillRect(ob.x - 14, ob.y2 - 2, 28, 8);
                ctx.restore();
            } else if (ob.type === 'FINISH_GATE') {
                ctx.save();
                ctx.shadowColor = '#00f0ff';
                ctx.shadowBlur = 25;

                ctx.strokeStyle = '#00f0ff';
                ctx.lineWidth = 7;
                ctx.beginPath();
                ctx.moveTo(ob.x, ob.y); ctx.lineTo(ob.x, ob.y + ob.h);
                ctx.stroke();

                ctx.fillStyle = activeBiome.railFloor;
                ctx.beginPath();
                ctx.arc(ob.x, (ob.y + ob.h) / 2, 36, 0, Math.PI * 2);
                ctx.fill();
                ctx.lineWidth = 4;
                ctx.strokeStyle = '#ffffff';
                ctx.stroke();

                ctx.fillStyle = '#ffffff';
                ctx.font = "bold 22px 'Chakra Petch', sans-serif";
                ctx.textAlign = "center";
                ctx.textBaseline = "middle";
                ctx.fillText("GOAL", ob.x, (ob.y + ob.h) / 2);
                ctx.restore();
            }
        }

        for (let ft of floatingTexts) {
            ctx.save();
            ctx.globalAlpha = Math.max(0, ft.alpha);
            ctx.translate(ft.x, ft.y);

            ctx.font = "900 22px 'Chakra Petch', sans-serif";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";

            ctx.lineWidth = 4.5;
            ctx.strokeStyle = '#050212';
            ctx.strokeText(ft.text, 0, 0);

            ctx.shadowColor = ft.color;
            ctx.shadowBlur = 10;
            ctx.fillStyle = ft.color;
            ctx.fillText(ft.text, 0, 0);
            ctx.restore();
        }

        ctx.restore();
    }

    let lastTimestamp = performance.now();

    function mainLoop(time) {
        const dt = Math.min(time - lastTimestamp, 50);
        lastTimestamp = time;
        const deltaScale = dt / (1000 / 60);
        const deltaSec = dt / 1000;

        ctx.setTransform(scaleRatio, 0, 0, scaleRatio, 0, 0);
        ctx.clearRect(0, 0, viewWidth, viewHeight);

        if (screenShake > 0.05) {
            const rx = (Math.random() - 0.5) * screenShake;
            const ry = (Math.random() - 0.5) * screenShake;
            ctx.translate(rx, ry);
            screenShake *= 0.88;
        } else {
            screenShake = 0;
        }

        if (currentGameState === STATE.PLAYING) {
            updateGame(deltaScale, deltaSec);
        }

        const effectiveCamX = (currentGameState === STATE.MENU) ? 0 : cameraX;

        const transitionData = {
            isTransitioning: isBiomeTransitioning,
            progress: biomeTransitionProgress,
            fromBiome: fromBiomeTheme,
            toBiome: toBiomeTheme
        };

        if (window.renderBackground) {
            window.renderBackground(ctx, activeBiome, time, effectiveCamX, viewWidth, viewHeight, CEILING_Y, FLOOR_Y, transitionData);
        }
        if (window.renderTracks) {
            window.renderTracks(ctx, activeBiome, effectiveCamX, viewWidth, viewHeight, CEILING_Y, FLOOR_Y, transitionData, obstacles);
        }

        if (currentGameState === STATE.PLAYING || currentGameState === STATE.PAUSED || currentGameState === STATE.GAMEOVER || currentGameState === STATE.VICTORY) {
            renderObstacles(time);
            if (currentGameState !== STATE.GAMEOVER) {
                player.render(ctx, cameraX, time, gameData.equippedSkinId);
            }
            player.renderParticles(ctx, cameraX);
        }

        if (currentGameState === STATE.MENU) {
            renderMenuShowcase(time);
        }

        requestAnimationFrame(mainLoop);
    }

    const menuCanvas = document.getElementById('menuPlayerCanvas');
    const menuCtx = menuCanvas.getContext('2d');

    function renderMenuShowcase(time) {
        menuCtx.clearRect(0, 0, menuCanvas.width, menuCanvas.height);

        const cx = menuCanvas.width / 2;
        const cy = menuCanvas.height / 2 + 10;

        menuCtx.save();
        menuCtx.translate(cx, cy + 54);
        menuCtx.scale(1, 0.35);

        menuCtx.shadowColor = '#00f0ff';
        menuCtx.shadowBlur = 18;
        menuCtx.lineWidth = 6;
        menuCtx.strokeStyle = '#00f0ff';
        menuCtx.beginPath();
        menuCtx.arc(0, 0, 48, 0, Math.PI * 2);
        menuCtx.stroke();

        menuCtx.lineWidth = 3;
        menuCtx.strokeStyle = '#ffffff';
        menuCtx.beginPath();
        menuCtx.arc(0, 0, 32, 0, Math.PI * 2);
        menuCtx.stroke();
        menuCtx.restore();

        const showcaseLevitate = Math.sin(time * 0.003) * 6;
        const showcaseBreath = 1.0 + Math.sin(time * 0.004) * 0.04;
        const currentSkin = window.SkinRegistry.get(gameData.equippedSkinId);

        if (window.drawUnifiedSkin) {
            window.drawUnifiedSkin(menuCtx, cx, cy + showcaseLevitate, 34, currentSkin, {
                scaleX: showcaseBreath,
                scaleY: 2.0 - showcaseBreath,
                gravityDir: 1,
                rotation: 0,
                nearMiss: false,
                isBlinking: false,
                time: time
            });
        }
    }

    function updateShowcaseSkin() {
        const currentSkin = window.SkinRegistry.get(gameData.equippedSkinId);
        document.getElementById('menuSkinName').textContent = currentSkin.name;
    }

    function hideAllOverlays() {
        document.querySelectorAll('.overlay').forEach(el => el.classList.add('hidden'));
    }

    function restartCurrentSession() {
        screenShake = 0;
        if (activeGameMode === 'ENDLESS') startEndlessGame();
        else startAdventureLevel(currentAdventureWorld, currentAdventureLevel);
    }

    function returnToMainMenu() {
        screenShake = 0;
        window.sound.stopMusic();
        currentGameState = STATE.MENU;
        hideAllOverlays();
        document.getElementById('menuOverlay').classList.remove('hidden');
        updateStatsUI();
        updateShowcaseSkin();
    }

    function updateStatsUI() {
        document.getElementById('menuBestDistance').textContent = `${gameData.endlessHighScore} м`;
        document.getElementById('menuWorldsCleared').textContent = `30 / 30 (ВІДКРИТО)`;

        document.getElementById('statEndlessDist').textContent = `${gameData.endlessHighScore} м`;
        document.getElementById('statTotalLevels').textContent = `3000 / 3000 (100%)`;
        document.getElementById('statNearMisses').textContent = gameData.nearMisses;
        document.getElementById('statTotalFlips').textContent = gameData.totalFlips;
    }

    function renderWorldsList() {
        const container = document.getElementById('worldsList');
        container.innerHTML = '';

        for (let i = 1; i <= 30; i++) {
            const theme = window.WorldRegistry.getTheme(i);

            const card = document.createElement('div');
            card.className = 'world-card';
            card.innerHTML = `
                <div style="font-weight: 900; font-size: 1.3rem; color: #ffffff; text-align: center; margin-top: 6px;">СВІТ ${i}</div>
                <div style="font-size: 0.85rem; font-weight: 700; color: #94a3b8; text-align: center;">${theme.name}</div>
                
                <div style="background: rgba(245, 158, 11, 0.2); color: #fbbf24; padding: 4px 10px; border-radius: 12px; font-size: 0.75rem; font-weight: 800; border: 1px solid #f59e0b;">
                    СКІН: ${theme.skinName}
                </div>

                <div style="width: 100%; text-align: center; font-weight: 800; font-size: 0.82rem; color: #10b981;">
                    100 РІВНІВ (ПО 1.5+ ХВ)
                </div>
            `;

            card.addEventListener('click', () => {
                window.sound.playClick();
                openLevelsGrid(i);
            });
            container.appendChild(card);
        }
    }

    function openLevelsGrid(worldNum) {
        currentAdventureWorld = worldNum;
        const overlay = document.getElementById('levelsGridOverlay');
        const theme = window.WorldRegistry.getTheme(worldNum);
        document.getElementById('gridWorldTitle').textContent = `СВІТ ${worldNum}: ${theme.name.toUpperCase()}`;

        const cellsContainer = document.getElementById('levelGridCells');
        cellsContainer.innerHTML = '';

        for (let lvl = 1; lvl <= 100; lvl++) {
            const cell = document.createElement('div');
            cell.className = 'level-cell';
            cell.textContent = lvl;

            cell.addEventListener('click', () => {
                window.sound.playClick();
                startAdventureLevel(worldNum, lvl);
            });
            cellsContainer.appendChild(cell);
        }

        hideAllOverlays();
        overlay.classList.remove('hidden');
    }

    function renderSkins(tabType = 'classic') {
        const container = document.getElementById('skinsGrid');
        container.innerHTML = '';

        const filteredSkins = window.SkinRegistry.getByGroup(tabType);

        filteredSkins.forEach(skin => {
            const isEquipped = (gameData.equippedSkinId === skin.id);

            const item = document.createElement('div');
            item.className = `skin-item ${isEquipped ? 'selected' : ''}`;

            const miniCanvas = document.createElement('canvas');
            miniCanvas.className = 'skin-mini-canvas';
            miniCanvas.width = 80;
            miniCanvas.height = 80;
            const mCtx = miniCanvas.getContext('2d');

            if (window.drawUnifiedSkin) {
                window.drawUnifiedSkin(mCtx, 40, 42, 20, skin, {
                    scaleX: 1, scaleY: 1, gravityDir: 1, rotation: 0, nearMiss: false, isBlinking: false, time: 250
                });
            }

            item.appendChild(miniCanvas);

            const nameDiv = document.createElement('div');
            nameDiv.style.fontWeight = '800';
            nameDiv.style.fontSize = '0.78rem';
            nameDiv.style.textAlign = 'center';
            nameDiv.style.color = '#ffffff';
            nameDiv.textContent = skin.name;
            item.appendChild(nameDiv);

            const statusDiv = document.createElement('div');
            statusDiv.style.fontSize = '0.72rem';
            statusDiv.style.fontWeight = '800';
            statusDiv.style.color = isEquipped ? '#10b981' : '#38bdf8';
            statusDiv.textContent = isEquipped ? 'АКТИВНИЙ' : 'ОБРАТИ';
            item.appendChild(statusDiv);

            item.addEventListener('click', () => {
                window.sound.playClick();
                gameData.equippedSkinId = skin.id;
                saveGameData();
                renderSkins(tabType);
            });
            container.appendChild(item);
        });
    }

    function togglePause() {
        if (currentGameState === STATE.PLAYING) {
            currentGameState = STATE.PAUSED;
            window.sound.stopMusic();
            hideAllOverlays();
            document.getElementById('pauseOverlay').classList.remove('hidden');
        } else if (currentGameState === STATE.PAUSED) {
            currentGameState = STATE.PLAYING;
            hideAllOverlays();
            window.sound.startMusic(gameSpeed);
        }
    }

    window.addEventListener('keydown', (e) => {
        if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
            e.preventDefault();
            autoLockLandscape();
            if (currentGameState === STATE.PLAYING) {
                const curSkin = window.SkinRegistry.get(gameData.equippedSkinId);
                player.flipGravity(window.sound, curSkin, activeBiome);
                gameData.totalFlips++;
            } else if (currentGameState === STATE.GAMEOVER) {
                restartCurrentSession();
            }
        }
        if (e.code === 'Escape' || e.code === 'KeyP') {
            togglePause();
        }
    });

    canvas.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        autoLockLandscape();
        if (currentGameState === STATE.PLAYING) {
            const curSkin = window.SkinRegistry.get(gameData.equippedSkinId);
            player.flipGravity(window.sound, curSkin, activeBiome);
            gameData.totalFlips++;
        }
    });

    document.getElementById('playEndlessBtn').addEventListener('click', () => {
        window.sound.playClick();
        startEndlessGame();
    });

    document.getElementById('openAdventureBtn').addEventListener('click', () => {
        window.sound.playClick();
        renderWorldsList();
        hideAllOverlays();
        document.getElementById('adventureOverlay').classList.remove('hidden');
    });

    document.getElementById('closeAdventureBtn').addEventListener('click', () => {
        window.sound.playClick();
        returnToMainMenu();
    });

    document.getElementById('closeLevelsGridBtn').addEventListener('click', () => {
        window.sound.playClick();
        renderWorldsList();
        hideAllOverlays();
        document.getElementById('adventureOverlay').classList.remove('hidden');
    });

    document.getElementById('openSkinsBtn').addEventListener('click', () => {
        window.sound.playClick();
        renderSkins('classic');
        hideAllOverlays();
        document.getElementById('skinsOverlay').classList.remove('hidden');
    });

    document.getElementById('menuToSkinsBtn').addEventListener('click', () => {
        window.sound.playClick();
        renderSkins('classic');
        hideAllOverlays();
        document.getElementById('skinsOverlay').classList.remove('hidden');
    });

    document.getElementById('closeSkinsBtn').addEventListener('click', () => {
        window.sound.playClick();
        returnToMainMenu();
    });

    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            window.sound.playClick();
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            renderSkins(btn.dataset.tab);
        });
    });

    document.getElementById('openAwardsBtn').addEventListener('click', () => {
        window.sound.playClick();
        updateStatsUI();
        hideAllOverlays();
        document.getElementById('awardsOverlay').classList.remove('hidden');
    });

    document.getElementById('closeAwardsBtn').addEventListener('click', () => {
        window.sound.playClick();
        returnToMainMenu();
    });

    document.getElementById('openSettingsBtn').addEventListener('click', () => {
        window.sound.playClick();
        hideAllOverlays();
        document.getElementById('settingsOverlay').classList.remove('hidden');
    });

    document.getElementById('closeSettingsBtn').addEventListener('click', () => {
        window.sound.playClick();
        returnToMainMenu();
    });

    document.getElementById('toggleSoundSettingBtn').addEventListener('click', () => {
        const isEnabled = window.sound.toggle();
        document.getElementById('toggleSoundSettingBtn').textContent = isEnabled ? 'УВІМК' : 'ВИМК';
        document.getElementById('soundToggleBtn').textContent = isEnabled ? 'SND' : 'MUT';
    });

    document.getElementById('soundToggleBtn').addEventListener('click', () => {
        const isEnabled = window.sound.toggle();
        document.getElementById('soundToggleBtn').textContent = isEnabled ? 'SND' : 'MUT';
        document.getElementById('toggleSoundSettingBtn').textContent = isEnabled ? 'УВІМК' : 'ВИМК';
    });

    document.getElementById('resetDataBtn').addEventListener('click', () => {
        if (confirm("Скинути збереження?")) {
            localStorage.removeItem(STORAGE_KEY);
            location.reload();
        }
    });

    document.getElementById('pauseBtn').addEventListener('click', togglePause);
    document.getElementById('resumeGameBtn').addEventListener('click', togglePause);

    document.getElementById('retryFromPauseBtn').addEventListener('click', () => {
        window.sound.playClick();
        restartCurrentSession();
    });

    document.getElementById('toMenuFromPauseBtn').addEventListener('click', () => {
        window.sound.playClick();
        returnToMainMenu();
    });

    document.getElementById('retryGameBtn').addEventListener('click', () => {
        window.sound.playClick();
        restartCurrentSession();
    });

    document.getElementById('toMenuFromDeathBtn').addEventListener('click', () => {
        window.sound.playClick();
        returnToMainMenu();
    });

    document.getElementById('nextLevelBtn').addEventListener('click', () => {
        window.sound.playClick();
        startAdventureLevel(currentAdventureWorld, Math.min(100, currentAdventureLevel + 1));
    });

    document.getElementById('replayLevelBtn').addEventListener('click', () => {
        window.sound.playClick();
        startAdventureLevel(currentAdventureWorld, currentAdventureLevel);
    });

    document.getElementById('toAdventureFromWinBtn').addEventListener('click', () => {
        window.sound.playClick();
        openLevelsGrid(currentAdventureWorld);
    });

    window.onload = () => {
        returnToMainMenu();
        requestAnimationFrame(mainLoop);
    };
})();