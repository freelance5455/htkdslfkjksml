const ALL_SKINS_LIST = [
    { id: "base_robot", name: "Робот Магніт", group: "classic", renderType: "robot", color: "#ffffff", accentColor: "#ff7a00", earColor: "#0284c7", eyeColor: "#00f0ff", accessory: "antenna", trailCol: "#00f0ff" },
    { id: "base_cyan", name: "Неоновий Бабл", group: "classic", renderType: "robot", color: "#06b6d4", accentColor: "#22d3ee", earColor: "#0284c7", eyeColor: "#ffffff", accessory: "visor", trailCol: "#22d3ee" },
    { id: "base_pink", name: "Рожева Жуйка", group: "classic", renderType: "robot", color: "#ec4899", accentColor: "#f472b6", earColor: "#be185d", eyeColor: "#ffffff", accessory: "wings", trailCol: "#f472b6" },
    { id: "base_yellow", name: "Лимонний Джем", group: "classic", renderType: "robot", color: "#eab308", accentColor: "#fde047", earColor: "#ca8a04", eyeColor: "#ffffff", accessory: "smile", trailCol: "#fde047" },
    { id: "base_green", name: "М'ятний Слайм", group: "classic", renderType: "robot", color: "#22c55e", accentColor: "#86efac", earColor: "#15803d", eyeColor: "#ffffff", accessory: "leaf", trailCol: "#86efac" },
    { id: "top_1_sovereign", name: "Гравітаційний Бог", group: "classic", renderType: "robot", color: "#fbbf24", accentColor: "#f59e0b", earColor: "#d97706", eyeColor: "#ffffff", accessory: "crown", trailCol: "#f59e0b" }
];

for (let i = 1; i <= 30; i++) {
    const wTheme = (window.WorldRegistry && window.WorldRegistry.getTheme(i)) || { skinName: "Герой", trailCol: "#00f0ff" };
    ALL_SKINS_LIST.push({
        id: `world_${i}`,
        name: `${i}. ${wTheme.skinName}`,
        group: (i <= 15) ? "worlds_1_15" : "worlds_16_30",
        renderType: "concept_world",
        skinNum: i,
        trailCol: wTheme.trailCol || "#00f0ff"
    });
}

function drawCuteEye(cCtx, ex, ey, rad, isBlinking, irisColor = '#0f172a') {
    cCtx.save();
    if (isBlinking) {
        cCtx.strokeStyle = '#0f172a';
        cCtx.lineWidth = 2.5;
        cCtx.beginPath();
        cCtx.arc(ex, ey, rad, 0.2, Math.PI - 0.2);
        cCtx.stroke();
    } else {
        cCtx.fillStyle = '#ffffff';
        cCtx.beginPath();
        cCtx.ellipse(ex, ey, rad, rad * 1.2, 0, 0, Math.PI * 2);
        cCtx.fill();
        cCtx.lineWidth = 1.5;
        cCtx.strokeStyle = '#0f172a';
        cCtx.stroke();

        cCtx.fillStyle = irisColor;
        cCtx.beginPath();
        cCtx.arc(ex + rad * 0.15, ey, rad * 0.65, 0, Math.PI * 2);
        cCtx.fill();

        cCtx.fillStyle = '#ffffff';
        cCtx.beginPath();
        cCtx.arc(ex, ey - rad * 0.35, rad * 0.3, 0, Math.PI * 2);
        cCtx.arc(ex + rad * 0.35, ey + rad * 0.2, rad * 0.16, 0, Math.PI * 2);
        cCtx.fill();
    }
    cCtx.restore();
}

function drawClassicRobotSkin(cCtx, rad, skin, animOptions) {
    cCtx.fillStyle = skin.earColor || '#0284c7';
    cCtx.beginPath();
    cCtx.roundRect(-rad * 1.15, -rad * 0.35, rad * 0.4, rad * 0.7, 4);
    cCtx.fill();
    cCtx.lineWidth = 2.5;
    cCtx.strokeStyle = '#0f172a';
    cCtx.stroke();

    cCtx.beginPath();
    cCtx.arc(0, 0, rad, 0, Math.PI * 2);
    cCtx.fillStyle = skin.color || '#ffffff';
    cCtx.fill();
    cCtx.lineWidth = 3.5;
    cCtx.strokeStyle = '#0f172a';
    cCtx.stroke();

    cCtx.save();
    cCtx.beginPath();
    cCtx.arc(0, 0, rad - 1.5, 0, Math.PI * 2);
    cCtx.clip();

    cCtx.fillStyle = skin.accentColor || '#ff7a00';
    cCtx.beginPath();
    cCtx.arc(rad * 0.1, rad * 0.75, rad * 0.95, 0, Math.PI * 2);
    cCtx.fill();

    cCtx.fillStyle = skin.earColor || '#0284c7';
    cCtx.beginPath();
    cCtx.arc(rad * 0.2, rad * 0.9, rad * 0.6, 0, Math.PI * 2);
    cCtx.fill();
    cCtx.restore();

    cCtx.fillStyle = '#0f172a';
    cCtx.beginPath();
    cCtx.roundRect(-rad * 0.2, -rad * 0.55, rad * 1.05, rad * 0.9, 10);
    cCtx.fill();
    cCtx.lineWidth = 2.5;
    cCtx.strokeStyle = '#334155';
    cCtx.stroke();

    if (animOptions.nearMiss) {
        cCtx.fillStyle = skin.eyeColor || '#00f0ff';
        cCtx.beginPath();
        cCtx.arc(rad * 0.15, -rad * 0.1, 4.5, 0, Math.PI * 2);
        cCtx.arc(rad * 0.6, -rad * 0.1, 4.5, 0, Math.PI * 2);
        cCtx.fill();
    } else if (animOptions.isBlinking) {
        cCtx.strokeStyle = skin.eyeColor || '#00f0ff';
        cCtx.lineWidth = 2.5;
        cCtx.beginPath();
        cCtx.moveTo(rad * 0.05, -rad * 0.1);
        cCtx.lineTo(rad * 0.25, -rad * 0.1);
        cCtx.moveTo(rad * 0.5, -rad * 0.1);
        cCtx.lineTo(rad * 0.7, -rad * 0.1);
        cCtx.stroke();
    } else {
        cCtx.fillStyle = skin.eyeColor || '#00f0ff';
        cCtx.beginPath();
        cCtx.ellipse(rad * 0.15, -rad * 0.1, 3.2, 5, 0, 0, Math.PI * 2);
        cCtx.ellipse(rad * 0.6, -rad * 0.1, 3.2, 5, 0, 0, Math.PI * 2);
        cCtx.fill();
    }

    cCtx.beginPath();
    cCtx.arc(-rad * 0.35, -rad * 0.45, rad * 0.25, 0, Math.PI * 2);
    cCtx.fillStyle = 'rgba(255, 255, 255, 0.65)';
    cCtx.fill();

    const acc = skin.accessory;
    if (acc === 'crown') {
        cCtx.fillStyle = '#fbbf24';
        cCtx.strokeStyle = '#b45309';
        cCtx.lineWidth = 2;
        cCtx.beginPath();
        cCtx.moveTo(-10, -rad);
        cCtx.lineTo(-6, -rad - 10);
        cCtx.lineTo(0, -rad - 4);
        cCtx.lineTo(6, -rad - 10);
        cCtx.lineTo(10, -rad);
        cCtx.closePath();
        cCtx.fill();
        cCtx.stroke();
    } else if (acc === 'wings') {
        cCtx.fillStyle = '#fbcfe8';
        cCtx.strokeStyle = '#db2777';
        cCtx.lineWidth = 1.8;
        cCtx.beginPath();
        cCtx.arc(-rad * 0.8, -rad * 0.2, 8, 0, Math.PI * 2);
        cCtx.fill();
        cCtx.stroke();
    } else if (acc === 'leaf') {
        cCtx.fillStyle = '#22c55e';
        cCtx.strokeStyle = '#15803d';
        cCtx.lineWidth = 1.8;
        cCtx.beginPath();
        cCtx.ellipse(0, -rad - 6, 4, 8, Math.PI * 0.2, 0, Math.PI * 2);
        cCtx.fill();
        cCtx.stroke();
    } else if (acc === 'visor') {
        cCtx.strokeStyle = '#00f0ff';
        cCtx.lineWidth = 2;
        cCtx.beginPath();
        cCtx.moveTo(-rad * 0.25, -rad * 0.55);
        cCtx.lineTo(rad * 0.85, -rad * 0.55);
        cCtx.stroke();
    }
}

function draw30VectorBall(cCtx, rad, skinId, animOptions = {}) {
    const isBlink = animOptions.isBlinking || false;
    const time = animOptions.time || 0;
    const id = skinId || 1;

    const wingFlap = Math.sin(time * 0.015);
    const fastFlap = Math.sin(time * 0.035);
    const pulse = 0.5 + 0.5 * Math.sin(time * 0.008);

    switch (id) {
        case 1: {
            cCtx.strokeStyle = '#64748b'; cCtx.lineWidth = 3;
            cCtx.beginPath(); cCtx.moveTo(-rad * 0.45, -rad * 0.6); cCtx.lineTo(-rad * 0.7, -rad * 1.05); cCtx.stroke();
            cCtx.beginPath(); cCtx.moveTo(rad * 0.45, -rad * 0.6); cCtx.lineTo(rad * 0.7, -rad * 1.05); cCtx.stroke();
            cCtx.fillStyle = '#00f0ff';
            cCtx.shadowColor = '#00f0ff'; cCtx.shadowBlur = 6 + pulse * 8;
            cCtx.beginPath(); cCtx.arc(-rad * 0.7, -rad * 1.05, 4, 0, Math.PI * 2); cCtx.arc(rad * 0.7, -rad * 1.05, 4, 0, Math.PI * 2); cCtx.fill();
            cCtx.shadowBlur = 0;

            const rGrad = cCtx.createRadialGradient(-4, -6, 2, 0, 0, rad);
            rGrad.addColorStop(0, '#e2e8f0'); rGrad.addColorStop(0.7, '#94a3b8'); rGrad.addColorStop(1, '#475569');
            cCtx.fillStyle = rGrad;
            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
            cCtx.strokeStyle = '#1e293b'; cCtx.lineWidth = 3; cCtx.stroke();

            cCtx.fillStyle = '#0f172a';
            cCtx.beginPath(); cCtx.roundRect(-rad * 0.65, -rad * 0.45, rad * 1.3, rad * 0.7, 8); cCtx.fill();
            cCtx.fillStyle = '#00f0ff'; cCtx.shadowColor = '#00f0ff'; cCtx.shadowBlur = 8 + pulse * 10;
            cCtx.beginPath(); cCtx.arc(0, -rad * 0.1, rad * 0.25, 0, Math.PI * 2); cCtx.fill();
            cCtx.shadowBlur = 0;

            cCtx.fillStyle = '#c084fc';
            cCtx.beginPath(); cCtx.arc(-rad * 0.95, rad * 0.2, 5.5, 0, Math.PI * 2); cCtx.arc(rad * 0.95, rad * 0.2, 5.5, 0, Math.PI * 2); cCtx.fill();
            break;
        }

        case 2: {
            cCtx.strokeStyle = '#451a03'; cCtx.lineWidth = 4;
            cCtx.beginPath(); cCtx.moveTo(0, -rad * 0.8); cCtx.quadraticCurveTo(4, -rad * 1.3, 10, -rad * 1.25); cCtx.stroke();
            cCtx.fillStyle = '#78350f';
            cCtx.beginPath(); cCtx.ellipse(0, -rad * 0.35, rad * 1.05, rad * 0.55, 0, 0, Math.PI * 2); cCtx.fill();
            cCtx.strokeStyle = '#451a03'; cCtx.lineWidth = 2.5; cCtx.stroke();

            cCtx.fillStyle = '#d97706';
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.9, -rad * 0.2);
            cCtx.bezierCurveTo(-rad * 0.95, rad * 0.8, -rad * 0.2, rad * 1.15, 0, rad * 1.18);
            cCtx.bezierCurveTo(rad * 0.2, rad * 1.15, rad * 0.95, rad * 0.8, rad * 0.9, -rad * 0.2);
            cCtx.closePath(); cCtx.fill(); cCtx.stroke();

            drawCuteEye(cCtx, -rad * 0.35, rad * 0.2, rad * 0.2, isBlink, '#451a03');
            drawCuteEye(cCtx, rad * 0.35, rad * 0.2, rad * 0.2, isBlink, '#451a03');
            cCtx.fillStyle = '#fb7185';
            cCtx.beginPath(); cCtx.arc(-rad * 0.6, rad * 0.45, 4, 0, Math.PI * 2); cCtx.arc(rad * 0.6, rad * 0.45, 4, 0, Math.PI * 2); cCtx.fill();

            cCtx.fillStyle = '#22c55e';
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.7, rad * 0.8); cCtx.lineTo(-rad * 0.3, rad * 1.2); cCtx.lineTo(0, rad * 0.9);
            cCtx.lineTo(rad * 0.3, rad * 1.2); cCtx.lineTo(rad * 0.7, rad * 0.8); cCtx.stroke(); cCtx.fill();
            break;
        }

        case 3: {
            cCtx.fillStyle = '#f97316';
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.5, -rad * 0.8); cCtx.lineTo(-rad * 0.2, -rad * 1.2);
            cCtx.lineTo(0, -rad * 0.9); cCtx.lineTo(rad * 0.2, -rad * 1.25);
            cCtx.lineTo(rad * 0.5, -rad * 0.8); cCtx.closePath(); cCtx.fill();

            cCtx.fillStyle = '#292524';
            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
            cCtx.strokeStyle = '#f97316'; cCtx.lineWidth = 3; cCtx.stroke();

            cCtx.strokeStyle = '#ea580c'; cCtx.lineWidth = 3.5;
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.7, -rad * 0.2); cCtx.lineTo(-rad * 0.1, 0); cCtx.lineTo(-rad * 0.4, rad * 0.7);
            cCtx.moveTo(0, 0); cCtx.lineTo(rad * 0.6, -rad * 0.3);
            cCtx.moveTo(rad * 0.1, rad * 0.2); cCtx.lineTo(rad * 0.5, rad * 0.6);
            cCtx.stroke();

            cCtx.fillStyle = '#ffedd5'; cCtx.shadowColor = '#f97316'; cCtx.shadowBlur = 6 + pulse * 10;
            cCtx.beginPath(); cCtx.arc(-rad * 0.3, -rad * 0.2, 4, 0, Math.PI * 2); cCtx.arc(rad * 0.3, -rad * 0.2, 4, 0, Math.PI * 2); cCtx.fill();
            cCtx.shadowBlur = 0;
            break;
        }

        case 4: {
            cCtx.fillStyle = '#7e22ce';
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.9, -rad * 0.4); cCtx.lineTo(-rad * 1.25, -rad * 0.9); cCtx.lineTo(-rad * 0.5, -rad * 0.8);
            cCtx.moveTo(rad * 0.9, -rad * 0.4); cCtx.lineTo(rad * 1.25, -rad * 0.9); cCtx.lineTo(rad * 0.5, -rad * 0.8);
            cCtx.fill();

            cCtx.fillStyle = '#c084fc';
            cCtx.beginPath();
            for (let a = 0; a < 6; a++) {
                const ang = a * Math.PI / 3;
                const x = Math.cos(ang) * rad;
                const y = Math.sin(ang) * rad;
                if (a === 0) cCtx.moveTo(x, y); else cCtx.lineTo(x, y);
            }
            cCtx.closePath(); cCtx.fill();
            cCtx.strokeStyle = '#581c87'; cCtx.lineWidth = 3; cCtx.stroke();

            cCtx.fillStyle = '#f3e8ff';
            cCtx.beginPath();
            cCtx.moveTo(0, -rad * 0.7); cCtx.lineTo(rad * 0.45, 0); cCtx.lineTo(0, rad * 0.7); cCtx.lineTo(-rad * 0.45, 0);
            cCtx.closePath(); cCtx.fill();
            break;
        }

        case 5: {
            cCtx.fillStyle = '#bae6fd';
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.7, -rad * 0.5); cCtx.lineTo(-rad * 0.5, -rad * 1.2);
            cCtx.lineTo(-rad * 0.1, -rad * 0.7); cCtx.lineTo(rad * 0.2, -rad * 1.3);
            cCtx.lineTo(rad * 0.6, -rad * 0.6); cCtx.closePath(); cCtx.fill();
            cCtx.strokeStyle = '#0284c7'; cCtx.lineWidth = 2; cCtx.stroke();

            cCtx.fillStyle = '#7dd3fc';
            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
            cCtx.stroke();

            cCtx.fillStyle = '#0284c7';
            cCtx.beginPath(); cCtx.roundRect(-rad * 0.65, -rad * 0.25, rad * 1.3, rad * 0.5, 6); cCtx.fill();
            cCtx.fillStyle = '#38bdf8'; cCtx.shadowColor = '#00f0ff'; cCtx.shadowBlur = 8 + pulse * 6;
            cCtx.fillRect(-rad * 0.5, -rad * 0.15, rad * 1.0, rad * 0.3);
            cCtx.shadowBlur = 0;
            break;
        }

        case 6: {
            cCtx.fillStyle = '#facc15'; cCtx.strokeStyle = '#854d0e'; cCtx.lineWidth = 2;
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.6, -rad * 0.7); cCtx.lineTo(-rad * 0.7, -rad * 1.15); cCtx.lineTo(-rad * 0.2, -rad * 0.85);
            cCtx.lineTo(0, -rad * 1.25); cCtx.lineTo(rad * 0.2, -rad * 0.85); cCtx.lineTo(rad * 0.7, -rad * 1.15); cCtx.lineTo(rad * 0.6, -rad * 0.7);
            cCtx.closePath(); cCtx.fill(); cCtx.stroke();

            cCtx.fillStyle = '#eab308';
            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
            cCtx.stroke();

            cCtx.strokeStyle = '#facc15'; cCtx.lineWidth = 3.5;
            cCtx.beginPath(); cCtx.arc(-rad * 0.95, -rad * 0.1, rad * 0.35, 0, Math.PI * 2); cCtx.stroke();
            cCtx.beginPath(); cCtx.arc(rad * 0.95, -rad * 0.1, rad * 0.35, 0, Math.PI * 2); cCtx.stroke();

            drawCuteEye(cCtx, -rad * 0.3, -rad * 0.1, rad * 0.18, isBlink, '#713f12');
            drawCuteEye(cCtx, rad * 0.3, -rad * 0.1, rad * 0.18, isBlink, '#713f12');
            break;
        }

        case 7: {
            const angleOffset = wingFlap * 0.25;
            cCtx.save();
            cCtx.translate(-rad * 0.8, -rad * 0.2); cCtx.rotate(-0.3 - angleOffset);
            cCtx.fillStyle = '#fdf2f8'; cCtx.strokeStyle = '#f472b6'; cCtx.lineWidth = 2;
            cCtx.beginPath(); cCtx.ellipse(0, 0, rad * 0.5, rad * 0.25, 0, 0, Math.PI * 2); cCtx.fill(); cCtx.stroke();
            cCtx.restore();

            cCtx.save();
            cCtx.translate(rad * 0.8, -rad * 0.2); cCtx.rotate(0.3 + angleOffset);
            cCtx.fillStyle = '#fdf2f8'; cCtx.strokeStyle = '#f472b6'; cCtx.lineWidth = 2;
            cCtx.beginPath(); cCtx.ellipse(0, 0, rad * 0.5, rad * 0.25, 0, 0, Math.PI * 2); cCtx.fill(); cCtx.stroke();
            cCtx.restore();

            cCtx.fillStyle = '#be185d';
            cCtx.beginPath(); cCtx.arc(0, -rad * 1.05, 7, 0, Math.PI * 2); cCtx.fill();

            cCtx.fillStyle = '#f59e0b';
            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();

            cCtx.fillStyle = '#f43f5e';
            cCtx.beginPath(); cCtx.arc(0, 0, rad * 0.9, 0, Math.PI * 2); cCtx.fill();

            cCtx.fillStyle = '#0c051f';
            cCtx.beginPath(); cCtx.arc(0, 0, rad * 0.35, 0, Math.PI * 2); cCtx.fill();

            cCtx.strokeStyle = '#fde047'; cCtx.lineWidth = 3; cCtx.lineCap = 'round';
            cCtx.beginPath(); cCtx.moveTo(-rad * 0.5, -rad * 0.4); cCtx.lineTo(-rad * 0.3, -rad * 0.5); cCtx.stroke();
            cCtx.strokeStyle = '#38bdf8';
            cCtx.beginPath(); cCtx.moveTo(rad * 0.3, -rad * 0.5); cCtx.lineTo(rad * 0.5, -rad * 0.3); cCtx.stroke();
            break;
        }

        case 8: {
            cCtx.fillStyle = '#fde047';
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.4, -rad * 0.6); cCtx.lineTo(-rad * 0.8, -rad * 1.3); cCtx.lineTo(-rad * 0.4, -rad * 0.9); cCtx.lineTo(-rad * 0.6, -rad * 0.6);
            cCtx.moveTo(rad * 0.4, -rad * 0.6); cCtx.lineTo(rad * 0.8, -rad * 1.3); cCtx.lineTo(rad * 0.4, -rad * 0.9); cCtx.lineTo(rad * 0.6, -rad * 0.6);
            cCtx.fill();

            cCtx.fillStyle = '#0284c7';
            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
            cCtx.strokeStyle = '#38bdf8'; cCtx.lineWidth = 3; cCtx.stroke();

            cCtx.fillStyle = '#fef08a'; cCtx.shadowColor = '#facc15'; cCtx.shadowBlur = 8 + pulse * 12;
            cCtx.beginPath();
            cCtx.moveTo(0, -rad * 0.5); cCtx.lineTo(-rad * 0.25, 0); cCtx.lineTo(0, 0); cCtx.lineTo(-rad * 0.15, rad * 0.55);
            cCtx.lineTo(rad * 0.25, -rad * 0.1); cCtx.lineTo(0, -rad * 0.1); cCtx.closePath(); cCtx.fill();
            cCtx.shadowBlur = 0;
            break;
        }

        case 9: {
            cCtx.fillStyle = '#5eead4';
            cCtx.beginPath();
            cCtx.moveTo(0, -rad * 0.8);
            cCtx.quadraticCurveTo(-rad * 1.4, -rad * 0.3, -rad * 1.3, rad * 0.3);
            cCtx.quadraticCurveTo(-rad * 0.6, rad * 0.6, 0, rad * 1.05);
            cCtx.quadraticCurveTo(rad * 0.6, rad * 0.6, rad * 1.3, rad * 0.3);
            cCtx.quadraticCurveTo(rad * 1.4, -rad * 0.3, 0, -rad * 0.8);
            cCtx.fill();
            cCtx.strokeStyle = '#0f766e'; cCtx.lineWidth = 3; cCtx.stroke();

            cCtx.fillStyle = '#0f172a';
            cCtx.beginPath(); cCtx.ellipse(0, -rad * 0.15, rad * 0.55, rad * 0.22, 0, 0, Math.PI * 2); cCtx.fill();
            cCtx.fillStyle = '#a855f7'; cCtx.shadowColor = '#a855f7'; cCtx.shadowBlur = 6;
            cCtx.beginPath(); cCtx.ellipse(0, -rad * 0.15, rad * 0.4, rad * 0.1, 0, 0, Math.PI * 2); cCtx.fill();
            cCtx.shadowBlur = 0;
            break;
        }

        case 10: {
            const gearAngle = time * 0.002;
            cCtx.save();
            cCtx.rotate(gearAngle);
            cCtx.fillStyle = '#d97706';
            cCtx.beginPath();
            for (let i = 0; i < 16; i++) {
                const a = (i * Math.PI) / 8;
                const r = i % 2 === 0 ? rad * 1.15 : rad * 0.9;
                const x = Math.cos(a) * r, y = Math.sin(a) * r;
                if (i === 0) cCtx.moveTo(x, y); else cCtx.lineTo(x, y);
            }
            cCtx.closePath(); cCtx.fill();
            cCtx.strokeStyle = '#78350f'; cCtx.lineWidth = 3; cCtx.stroke();
            cCtx.restore();

            cCtx.fillStyle = '#fef3c7';
            cCtx.beginPath(); cCtx.arc(0, 0, rad * 0.65, 0, Math.PI * 2); cCtx.fill();
            cCtx.strokeStyle = '#92400e'; cCtx.lineWidth = 2; cCtx.stroke();

            const secondAngle = time * 0.006;
            const minuteAngle = time * 0.001;
            cCtx.strokeStyle = '#451a03'; cCtx.lineWidth = 2.5; cCtx.lineCap = 'round';
            cCtx.beginPath();
            cCtx.moveTo(0, 0); cCtx.lineTo(Math.cos(minuteAngle - Math.PI / 2) * rad * 0.35, Math.sin(minuteAngle - Math.PI / 2) * rad * 0.35);
            cCtx.moveTo(0, 0); cCtx.lineTo(Math.cos(secondAngle - Math.PI / 2) * rad * 0.48, Math.sin(secondAngle - Math.PI / 2) * rad * 0.48);
            cCtx.stroke();
            break;
        }

        case 11: {
            cCtx.fillStyle = '#84cc16';
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.7, -rad * 0.3);
            cCtx.quadraticCurveTo(-rad * 0.9, -rad * 0.9, -rad * 0.4, -rad * 0.8);
            cCtx.quadraticCurveTo(0, -rad * 1.1, rad * 0.4, -rad * 0.8);
            cCtx.quadraticCurveTo(rad * 0.9, -rad * 0.9, rad * 0.7, -rad * 0.3);
            cCtx.quadraticCurveTo(rad * 1.1, rad * 0.7, 0, rad * 1.05);
            cCtx.quadraticCurveTo(-rad * 1.1, rad * 0.7, -rad * 0.7, -rad * 0.3);
            cCtx.fill();
            cCtx.strokeStyle = '#4d7c0f'; cCtx.lineWidth = 3; cCtx.stroke();

            cCtx.fillStyle = '#bef264';
            cCtx.beginPath(); cCtx.arc(-rad * 0.3, -rad * 0.1, 4.5, 0, Math.PI * 2); cCtx.arc(rad * 0.3, -rad * 0.1, 4.5, 0, Math.PI * 2); cCtx.arc(0, rad * 0.25, 4, 0, Math.PI * 2); cCtx.fill();
            cCtx.fillStyle = '#14532d';
            cCtx.beginPath(); cCtx.arc(-rad * 0.3, -rad * 0.1, 2, 0, Math.PI * 2); cCtx.arc(rad * 0.3, -rad * 0.1, 2, 0, Math.PI * 2); cCtx.arc(0, rad * 0.25, 1.8, 0, Math.PI * 2); cCtx.fill();
            break;
        }

        case 12: {
            cCtx.fillStyle = '#f59e0b';
            cCtx.save();
            const rayPulse = 1.0 + Math.sin(time * 0.008) * 0.12;
            for (let i = 0; i < 12; i++) {
                cCtx.rotate(Math.PI / 6);
                cCtx.beginPath();
                cCtx.moveTo(-4, -rad * 0.9); cCtx.lineTo(0, -rad * 1.35 * rayPulse); cCtx.lineTo(4, -rad * 0.9);
                cCtx.fill();
            }
            cCtx.restore();

            cCtx.fillStyle = '#fbbf24';
            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
            cCtx.strokeStyle = '#d97706'; cCtx.lineWidth = 3; cCtx.stroke();

            cCtx.fillStyle = '#451a03';
            cCtx.beginPath(); cCtx.ellipse(-rad * 0.3, 0, 3, 7, 0.15, 0, Math.PI * 2); cCtx.ellipse(rad * 0.3, 0, 3, 7, -0.15, 0, Math.PI * 2); cCtx.fill();
            break;
        }

        case 13: {
            cCtx.fillStyle = '#6366f1';
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.8, -rad * 0.4); cCtx.quadraticCurveTo(0, -rad * 1.2, rad * 0.8, -rad * 0.4);
            cCtx.lineTo(rad * 0.7, -rad * 0.1); cCtx.lineTo(-rad * 0.7, -rad * 0.1); cCtx.closePath(); cCtx.fill();
            cCtx.strokeStyle = '#312e81'; cCtx.lineWidth = 2.5; cCtx.stroke();

            cCtx.fillStyle = '#38bdf8';
            cCtx.beginPath(); cCtx.moveTo(-rad * 0.2, -rad * 0.8); cCtx.lineTo(0, -rad * 1.2); cCtx.lineTo(rad * 0.2, -rad * 0.8); cCtx.fill();

            cCtx.fillStyle = '#ec4899';
            cCtx.beginPath(); cCtx.arc(0, 0, rad * 0.85, 0, Math.PI * 2); cCtx.fill();
            cCtx.fillStyle = '#00f0ff'; cCtx.shadowColor = '#00f0ff'; cCtx.shadowBlur = 8 + pulse * 6;
            cCtx.fillRect(-rad * 0.5, -rad * 0.2, rad * 1.0, rad * 0.3);
            cCtx.shadowBlur = 0;
            break;
        }

        case 14: {
            cCtx.strokeStyle = '#ec4899'; cCtx.lineWidth = 2.5;
            cCtx.beginPath(); cCtx.arc(-rad * 0.4, -rad * 0.9, 8, Math.PI, 0); cCtx.stroke();
            cCtx.beginPath(); cCtx.arc(rad * 0.4, -rad * 0.9, 8, Math.PI, 0); cCtx.stroke();

            cCtx.fillStyle = '#cbd5e1';
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.7, -rad * 0.3);
            cCtx.quadraticCurveTo(-rad * 0.9, -rad * 0.9, 0, -rad * 1.0);
            cCtx.quadraticCurveTo(rad * 0.9, -rad * 0.9, rad * 0.7, -rad * 0.3);
            cCtx.quadraticCurveTo(rad * 0.6, rad * 0.9, 0, rad * 1.05);
            cCtx.quadraticCurveTo(-rad * 0.6, rad * 0.9, -rad * 0.7, -rad * 0.3);
            cCtx.fill();
            cCtx.strokeStyle = '#475569'; cCtx.lineWidth = 3; cCtx.stroke();

            cCtx.fillStyle = '#0f172a';
            cCtx.beginPath(); cCtx.ellipse(-rad * 0.35, -rad * 0.1, rad * 0.22, rad * 0.38, -0.3, 0, Math.PI * 2); cCtx.fill();
            cCtx.beginPath(); cCtx.ellipse(rad * 0.35, -rad * 0.1, rad * 0.22, rad * 0.38, 0.3, 0, Math.PI * 2); cCtx.fill();
            cCtx.fillStyle = '#ffffff';
            cCtx.beginPath(); cCtx.arc(-rad * 0.35, -rad * 0.22, 3, 0, Math.PI * 2); cCtx.arc(rad * 0.35, -rad * 0.22, 3, 0, Math.PI * 2); cCtx.fill();
            break;
        }

        case 15: {
            const flutter = fastFlap * 0.35;
            cCtx.save();
            cCtx.translate(-rad * 0.5, -rad * 0.7); cCtx.rotate(-0.4 - flutter);
            cCtx.fillStyle = 'rgba(254, 249, 195, 0.85)'; cCtx.strokeStyle = '#ca8a04'; cCtx.lineWidth = 2;
            cCtx.beginPath(); cCtx.ellipse(0, 0, rad * 0.55, rad * 0.26, 0, 0, Math.PI * 2); cCtx.fill(); cCtx.stroke();
            cCtx.restore();

            cCtx.save();
            cCtx.translate(rad * 0.5, -rad * 0.7); cCtx.rotate(0.4 + flutter);
            cCtx.fillStyle = 'rgba(254, 249, 195, 0.85)'; cCtx.strokeStyle = '#ca8a04'; cCtx.lineWidth = 2;
            cCtx.beginPath(); cCtx.ellipse(0, 0, rad * 0.55, rad * 0.26, 0, 0, Math.PI * 2); cCtx.fill(); cCtx.stroke();
            cCtx.restore();

            cCtx.fillStyle = '#facc15';
            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
            cCtx.strokeStyle = '#451a03'; cCtx.lineWidth = 3; cCtx.stroke();

            cCtx.fillStyle = '#451a03';
            cCtx.fillRect(-rad * 0.9, -rad * 0.35, rad * 1.8, rad * 0.25);
            cCtx.fillRect(-rad * 0.9, rad * 0.15, rad * 1.8, rad * 0.25);

            cCtx.strokeStyle = '#713f12'; cCtx.lineWidth = 3;
            cCtx.beginPath(); cCtx.moveTo(-rad * 0.3, -rad * 0.7); cCtx.lineTo(-rad * 0.5, -rad * 1.2); cCtx.stroke();
            cCtx.beginPath(); cCtx.moveTo(rad * 0.3, -rad * 0.7); cCtx.lineTo(rad * 0.5, -rad * 1.2); cCtx.stroke();
            cCtx.fillStyle = '#a16207';
            cCtx.beginPath(); cCtx.arc(-rad * 0.5, -rad * 1.2, 4, 0, Math.PI * 2); cCtx.arc(rad * 0.5, -rad * 1.2, 4, 0, Math.PI * 2); cCtx.fill();
            break;
        }

        case 16: {
            const haloFloat = Math.sin(time * 0.005) * 3;
            cCtx.strokeStyle = '#fde047'; cCtx.lineWidth = 3.5;
            cCtx.shadowColor = '#facc15'; cCtx.shadowBlur = 8 + pulse * 6;
            cCtx.beginPath(); cCtx.ellipse(0, -rad * 1.15 + haloFloat, rad * 0.65, rad * 0.2, 0, 0, Math.PI * 2); cCtx.stroke();
            cCtx.shadowBlur = 0;

            const cloudWing = Math.sin(time * 0.01) * 0.15;
            cCtx.save();
            cCtx.translate(-rad * 0.8, 0); cCtx.rotate(-cloudWing);
            cCtx.fillStyle = '#ffffff'; cCtx.strokeStyle = '#38bdf8'; cCtx.lineWidth = 2;
            cCtx.beginPath(); cCtx.ellipse(0, 0, rad * 0.45, rad * 0.25, 0, 0, Math.PI * 2); cCtx.fill(); cCtx.stroke();
            cCtx.restore();

            cCtx.save();
            cCtx.translate(rad * 0.8, 0); cCtx.rotate(cloudWing);
            cCtx.fillStyle = '#ffffff'; cCtx.strokeStyle = '#38bdf8'; cCtx.lineWidth = 2;
            cCtx.beginPath(); cCtx.ellipse(0, 0, rad * 0.45, rad * 0.25, 0, 0, Math.PI * 2); cCtx.fill(); cCtx.stroke();
            cCtx.restore();

            cCtx.fillStyle = '#f0f9ff';
            cCtx.beginPath();
            cCtx.arc(-rad * 0.5, 0, rad * 0.55, 0, Math.PI * 2);
            cCtx.arc(rad * 0.5, 0, rad * 0.55, 0, Math.PI * 2);
            cCtx.arc(0, -rad * 0.4, rad * 0.65, 0, Math.PI * 2);
            cCtx.arc(0, rad * 0.4, rad * 0.65, 0, Math.PI * 2);
            cCtx.fill();
            cCtx.strokeStyle = '#38bdf8'; cCtx.lineWidth = 3; cCtx.stroke();

            drawCuteEye(cCtx, -rad * 0.28, 0, rad * 0.16, isBlink, '#0284c7');
            drawCuteEye(cCtx, rad * 0.28, 0, rad * 0.16, isBlink, '#0284c7');
            break;
        }

        case 17: {
            cCtx.fillStyle = '#0e7490';
            cCtx.fillRect(-3, -rad * 1.25, 6, rad * 0.4);
            cCtx.fillStyle = '#f43f5e';
            cCtx.fillRect(-5, -rad * 1.45, 10, 8);

            cCtx.fillStyle = '#155e75';
            cCtx.beginPath(); cCtx.roundRect(-rad * 0.9, -rad * 0.85, rad * 1.8, rad * 1.7, 8); cCtx.fill();
            cCtx.strokeStyle = '#082f49'; cCtx.lineWidth = 3.5; cCtx.stroke();

            cCtx.fillStyle = '#082f49';
            cCtx.beginPath(); cCtx.roundRect(-rad * 0.7, -rad * 0.65, rad * 1.4, rad * 1.3, 4); cCtx.fill();
            cCtx.fillStyle = '#22d3ee';
            cCtx.fillRect(-rad * 0.45, -rad * 0.2, 7, 10);
            cCtx.fillRect(rad * 0.25, -rad * 0.2, 7, 10);
            break;
        }

        case 18: {
            cCtx.fillStyle = '#1e1b4b';
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.7, -rad * 0.4); cCtx.lineTo(-rad * 0.95, -rad * 1.1); cCtx.lineTo(-rad * 0.3, -rad * 0.8);
            cCtx.lineTo(0, -rad * 0.9);
            cCtx.lineTo(rad * 0.3, -rad * 0.8); cCtx.lineTo(rad * 0.95, -rad * 1.1); cCtx.lineTo(rad * 0.7, -rad * 0.4);
            cCtx.closePath(); cCtx.fill();

            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
            cCtx.strokeStyle = '#312e81'; cCtx.lineWidth = 3; cCtx.stroke();

            cCtx.fillStyle = '#4338ca';
            cCtx.fillRect(-rad * 0.85, -rad * 0.25, rad * 1.7, rad * 0.5);

            cCtx.fillStyle = '#ffffff';
            cCtx.beginPath(); cCtx.ellipse(-rad * 0.35, -rad * 0.05, 6, 2.5, -0.15, 0, Math.PI * 2); cCtx.ellipse(rad * 0.35, -rad * 0.05, 6, 2.5, 0.15, 0, Math.PI * 2); cCtx.fill();
            break;
        }

        case 19: {
            cCtx.fillStyle = '#e9d5ff';
            cCtx.beginPath();
            cCtx.arc(0, -rad * 0.4, rad * 0.95, 0, Math.PI * 2);
            cCtx.fill();
            cCtx.fillStyle = '#0c051f';
            cCtx.beginPath();
            cCtx.arc(rad * 0.25, -rad * 0.5, rad * 0.85, 0, Math.PI * 2);
            cCtx.fill();

            cCtx.fillStyle = '#d8b4fe';
            cCtx.beginPath(); cCtx.arc(0, 0, rad * 0.85, 0, Math.PI * 2); cCtx.fill();
            cCtx.strokeStyle = '#7e22ce'; cCtx.lineWidth = 2.5; cCtx.stroke();

            const shardFloat = Math.sin(time * 0.005) * 4;
            cCtx.fillStyle = '#c084fc';
            cCtx.fillRect(-rad * 1.25 - 3, -3 + shardFloat, 6, 6);
            cCtx.fillRect(rad * 1.25 - 3, -3 - shardFloat, 6, 6);
            break;
        }

        case 20: {
            cCtx.fillStyle = '#10b981';
            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
            cCtx.strokeStyle = '#047857'; cCtx.lineWidth = 3; cCtx.stroke();

            cCtx.fillStyle = '#022c22';
            cCtx.beginPath(); cCtx.roundRect(-rad * 0.75, -rad * 0.45, rad * 1.5, rad * 0.85, 6); cCtx.fill();
            cCtx.strokeStyle = '#6ee7b7'; cCtx.lineWidth = 2; cCtx.stroke();

            cCtx.strokeStyle = '#34d399'; cCtx.lineWidth = 1.5;
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.55, -rad * 0.15); cCtx.lineTo(rad * 0.45, -rad * 0.15);
            cCtx.moveTo(-rad * 0.4, rad * 0.1); cCtx.lineTo(rad * 0.3, rad * 0.1);
            cCtx.stroke();
            break;
        }

        case 21: {
            const dFlap = Math.sin(time * 0.012) * 0.28;
            cCtx.save();
            cCtx.translate(-rad * 0.8, -rad * 0.3); cCtx.rotate(-0.3 - dFlap);
            cCtx.fillStyle = '#ea580c'; cCtx.strokeStyle = '#7f1d1d'; cCtx.lineWidth = 2.5;
            cCtx.beginPath();
            cCtx.moveTo(0, 0); cCtx.lineTo(-rad * 0.9, -rad * 0.5); cCtx.lineTo(-rad * 0.5, rad * 0.4); cCtx.closePath(); cCtx.fill(); cCtx.stroke();
            cCtx.restore();

            cCtx.save();
            cCtx.translate(rad * 0.8, -rad * 0.3); cCtx.rotate(0.3 + dFlap);
            cCtx.fillStyle = '#ea580c'; cCtx.strokeStyle = '#7f1d1d'; cCtx.lineWidth = 2.5;
            cCtx.beginPath();
            cCtx.moveTo(0, 0); cCtx.lineTo(rad * 0.9, -rad * 0.5); cCtx.lineTo(rad * 0.5, rad * 0.4); cCtx.closePath(); cCtx.fill(); cCtx.stroke();
            cCtx.restore();

            cCtx.strokeStyle = '#7f1d1d'; cCtx.lineWidth = 4; cCtx.lineCap = 'round';
            cCtx.beginPath(); cCtx.moveTo(-rad * 0.4, -rad * 0.6); cCtx.lineTo(-rad * 0.7, -rad * 1.2); cCtx.stroke();
            cCtx.beginPath(); cCtx.moveTo(rad * 0.4, -rad * 0.6); cCtx.lineTo(rad * 0.7, -rad * 1.2); cCtx.stroke();

            cCtx.fillStyle = '#ef4444';
            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
            cCtx.stroke();

            cCtx.fillStyle = '#facc15';
            cCtx.beginPath(); cCtx.ellipse(-rad * 0.35, -rad * 0.1, 4, 7, 0.2, 0, Math.PI * 2); cCtx.ellipse(rad * 0.35, -rad * 0.1, 4, 7, -0.2, 0, Math.PI * 2); cCtx.fill();
            break;
        }

        case 22: {
            cCtx.fillStyle = '#1e293b';
            cCtx.beginPath();
            cCtx.moveTo(-rad * 1.2, -rad * 0.3); cCtx.quadraticCurveTo(0, -rad * 1.3, rad * 1.2, -rad * 0.3);
            cCtx.quadraticCurveTo(0, -rad * 0.5, -rad * 1.2, -rad * 0.3); cCtx.fill();
            cCtx.strokeStyle = '#d97706'; cCtx.lineWidth = 2.5; cCtx.stroke();
            cCtx.fillStyle = '#f59e0b';
            cCtx.beginPath(); cCtx.arc(0, -rad * 0.7, 4, 0, Math.PI * 2); cCtx.fill();

            cCtx.fillStyle = '#94a3b8';
            cCtx.beginPath(); cCtx.arc(0, 0, rad * 0.9, 0, Math.PI * 2); cCtx.fill();
            cCtx.strokeStyle = '#334155'; cCtx.lineWidth = 3; cCtx.stroke();

            cCtx.fillStyle = '#ef4444'; cCtx.shadowColor = '#ef4444'; cCtx.shadowBlur = 6 + pulse * 8;
            cCtx.beginPath(); cCtx.arc(-rad * 0.3, 0, 5, 0, Math.PI * 2); cCtx.fill();
            cCtx.shadowBlur = 0;
            cCtx.fillStyle = '#0f172a';
            cCtx.beginPath(); cCtx.arc(rad * 0.3, 0, 6, 0, Math.PI * 2); cCtx.fill();
            break;
        }

        case 23: {
            cCtx.fillStyle = '#facc15'; cCtx.strokeStyle = '#ca8a04'; cCtx.lineWidth = 1.5;
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.4, -rad * 0.7); cCtx.lineTo(-rad * 0.5, -rad * 1.1); cCtx.lineTo(-rad * 0.2, -rad * 0.8);
            cCtx.lineTo(0, -rad * 1.15); cCtx.lineTo(rad * 0.2, -rad * 0.8); cCtx.lineTo(rad * 0.5, -rad * 1.1); cCtx.lineTo(rad * 0.4, -rad * 0.7);
            cCtx.closePath(); cCtx.fill(); cCtx.stroke();

            const dGrad = cCtx.createLinearGradient(-rad, -rad, rad, rad);
            dGrad.addColorStop(0, '#38bdf8'); dGrad.addColorStop(0.5, '#ec4899'); dGrad.addColorStop(1, '#a855f7');
            cCtx.fillStyle = dGrad;
            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
            cCtx.strokeStyle = '#ffffff'; cCtx.lineWidth = 2.5; cCtx.stroke();

            cCtx.strokeStyle = 'rgba(255, 255, 255, 0.4)'; cCtx.lineWidth = 1.5;
            for (let g = -rad * 0.6; g <= rad * 0.6; g += 8) {
                cCtx.beginPath(); cCtx.moveTo(-rad * 0.8, g); cCtx.lineTo(rad * 0.8, g); cCtx.stroke();
                cCtx.beginPath(); cCtx.moveTo(g, -rad * 0.8); cCtx.lineTo(g, rad * 0.8); cCtx.stroke();
            }
            break;
        }

        case 24: {
            cCtx.fillStyle = '#e0f2fe';
            cCtx.beginPath(); cCtx.moveTo(0, -rad * 1.3); cCtx.lineTo(rad * 0.5, -rad * 0.8); cCtx.lineTo(0, -rad * 0.6); cCtx.lineTo(-rad * 0.5, -rad * 0.8); cCtx.closePath(); cCtx.fill();
            cCtx.strokeStyle = '#0284c7'; cCtx.lineWidth = 2; cCtx.stroke();

            cCtx.fillStyle = '#7dd3fc';
            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
            cCtx.stroke();

            cCtx.fillStyle = '#0c4a6e';
            cCtx.beginPath(); cCtx.roundRect(-rad * 0.6, -rad * 0.15, rad * 1.2, rad * 0.35, 4); cCtx.fill();
            cCtx.strokeStyle = '#bae6fd'; cCtx.lineWidth = 2; cCtx.stroke();
            break;
        }

        case 25: {
            cCtx.strokeStyle = '#65a30d'; cCtx.lineWidth = 5; cCtx.lineCap = 'round';
            cCtx.beginPath(); cCtx.moveTo(-rad * 0.7, -rad * 0.8); cCtx.lineTo(-rad * 0.4, rad * 0.9); cCtx.stroke();

            cCtx.fillStyle = '#18181b';
            cCtx.beginPath(); cCtx.arc(-rad * 0.7, -rad * 0.7, 7, 0, Math.PI * 2); cCtx.arc(rad * 0.7, -rad * 0.7, 7, 0, Math.PI * 2); cCtx.fill();

            cCtx.fillStyle = '#f8fafc';
            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
            cCtx.strokeStyle = '#27272a'; cCtx.lineWidth = 3; cCtx.stroke();

            cCtx.fillStyle = '#18181b';
            cCtx.beginPath(); cCtx.ellipse(-rad * 0.35, -rad * 0.1, 7, 5, -0.2, 0, Math.PI * 2); cCtx.ellipse(rad * 0.35, -rad * 0.1, 7, 5, 0.2, 0, Math.PI * 2); cCtx.fill();
            cCtx.fillStyle = '#ffffff';
            cCtx.beginPath(); cCtx.arc(-rad * 0.35, -rad * 0.1, 2, 0, Math.PI * 2); cCtx.arc(rad * 0.35, -rad * 0.1, 2, 0, Math.PI * 2); cCtx.fill();
            break;
        }

        case 26: {
            cCtx.fillStyle = '#1e1b4b';
            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
            cCtx.strokeStyle = '#7e22ce'; cCtx.lineWidth = 3; cCtx.stroke();

            cCtx.fillStyle = '#00f0ff'; cCtx.shadowColor = '#00f0ff'; cCtx.shadowBlur = 8 + pulse * 10;
            cCtx.beginPath(); cCtx.ellipse(0, -rad * 0.1, rad * 0.75, rad * 0.28, 0, 0, Math.PI * 2); cCtx.fill();
            cCtx.shadowBlur = 0;

            cCtx.strokeStyle = '#c084fc'; cCtx.lineWidth = 4;
            cCtx.beginPath(); cCtx.arc(-rad * 0.95, rad * 0.4, 6, 0, Math.PI * 2); cCtx.arc(rad * 0.95, rad * 0.4, 6, 0, Math.PI * 2); cCtx.stroke();
            break;
        }

        case 27: {
            const runeAngle = time * 0.003;
            cCtx.save();
            cCtx.rotate(runeAngle);
            cCtx.strokeStyle = '#e879f9'; cCtx.lineWidth = 2; cCtx.setLineDash([4, 4]);
            cCtx.beginPath(); cCtx.arc(0, 0, rad * 1.35, 0, Math.PI * 2); cCtx.stroke();
            cCtx.setLineDash([]);
            cCtx.restore();

            cCtx.fillStyle = '#6b21a8';
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.8, -rad * 0.3); cCtx.quadraticCurveTo(0, -rad * 1.3, rad * 0.8, -rad * 0.3);
            cCtx.lineTo(rad * 0.7, rad * 0.7); cCtx.lineTo(-rad * 0.7, rad * 0.7); cCtx.closePath(); cCtx.fill();
            cCtx.strokeStyle = '#3b0764'; cCtx.lineWidth = 3; cCtx.stroke();

            cCtx.fillStyle = '#f472b6'; cCtx.shadowColor = '#f472b6'; cCtx.shadowBlur = 8 + pulse * 8;
            cCtx.beginPath(); cCtx.ellipse(-rad * 0.3, 0, 4, 6, 0, 0, Math.PI * 2); cCtx.ellipse(rad * 0.3, 0, 4, 6, 0, 0, Math.PI * 2); cCtx.fill();
            cCtx.shadowBlur = 0;
            break;
        }

        case 28: {
            cCtx.lineWidth = 3;
            cCtx.strokeStyle = '#f43f5e'; cCtx.beginPath(); cCtx.arc(0, 0, rad * 1.35, 0, Math.PI * 2); cCtx.stroke();
            cCtx.strokeStyle = '#eab308'; cCtx.beginPath(); cCtx.arc(0, 0, rad * 1.2, 0, Math.PI * 2); cCtx.stroke();
            cCtx.strokeStyle = '#38bdf8'; cCtx.beginPath(); cCtx.arc(0, 0, rad * 1.05, 0, Math.PI * 2); cCtx.stroke();

            cCtx.fillStyle = '#ffffff';
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.4, -rad * 0.7); cCtx.lineTo(-rad * 0.5, -rad * 1.15); cCtx.lineTo(0, -rad * 1.35); cCtx.lineTo(rad * 0.5, -rad * 1.15); cCtx.lineTo(rad * 0.4, -rad * 0.7);
            cCtx.closePath(); cCtx.fill();

            cCtx.fillStyle = '#ffffff'; cCtx.shadowColor = '#ffffff'; cCtx.shadowBlur = 8 + pulse * 8;
            cCtx.beginPath(); cCtx.arc(-rad * 0.3, 0, 4, 0, Math.PI * 2); cCtx.arc(rad * 0.3, 0, 4, 0, Math.PI * 2); cCtx.fill();
            cCtx.shadowBlur = 0;
            break;
        }

        case 29: {
            cCtx.fillStyle = '#818cf8';
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.4, -rad * 0.6); cCtx.quadraticCurveTo(-rad * 1.1, -rad * 1.2, -rad * 0.5, -rad * 1.35);
            cCtx.quadraticCurveTo(-rad * 0.3, -rad * 0.8, -rad * 0.2, -rad * 0.6);
            cCtx.moveTo(rad * 0.4, -rad * 0.6); cCtx.quadraticCurveTo(rad * 1.1, -rad * 1.2, rad * 0.5, -rad * 1.35);
            cCtx.quadraticCurveTo(rad * 0.3, -rad * 0.8, rad * 0.2, -rad * 0.6);
            cCtx.fill();

            cCtx.fillStyle = '#0b0f19';
            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
            cCtx.strokeStyle = '#6366f1'; cCtx.lineWidth = 3; cCtx.stroke();

            const starAngle = time * 0.004;
            cCtx.save();
            cCtx.rotate(starAngle);
            cCtx.fillStyle = '#ffffff'; cCtx.shadowColor = '#a78bfa'; cCtx.shadowBlur = 10 + pulse * 12;
            cCtx.beginPath();
            for (let s = 0; s < 8; s++) {
                const sAng = s * Math.PI / 4;
                const sR = s % 2 === 0 ? rad * 0.55 : rad * 0.22;
                const sx = Math.cos(sAng) * sR, sy = Math.sin(sAng) * sR;
                if (s === 0) cCtx.moveTo(sx, sy); else cCtx.lineTo(sx, sy);
            }
            cCtx.closePath(); cCtx.fill();
            cCtx.restore();
            cCtx.shadowBlur = 0;
            break;
        }

        case 30: {
            cCtx.fillStyle = '#f59e0b'; cCtx.strokeStyle = '#b45309'; cCtx.lineWidth = 2.5;
            cCtx.beginPath();
            cCtx.moveTo(-rad * 0.7, -rad * 0.6); cCtx.lineTo(-rad * 0.8, -rad * 1.35); cCtx.lineTo(-rad * 0.3, -rad * 0.9);
            cCtx.lineTo(0, -rad * 1.45); cCtx.lineTo(rad * 0.3, -rad * 0.9); cCtx.lineTo(rad * 0.8, -rad * 1.35); cCtx.lineTo(rad * 0.7, -rad * 0.6);
            cCtx.closePath(); cCtx.fill(); cCtx.stroke();
            cCtx.fillStyle = '#38bdf8'; cCtx.beginPath(); cCtx.arc(0, -rad * 1.25, 4, 0, Math.PI * 2); cCtx.fill();

            cCtx.fillStyle = '#f97316';
            cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
            cCtx.strokeStyle = '#9a3412'; cCtx.lineWidth = 3; cCtx.stroke();

            cCtx.fillStyle = '#00f0ff'; cCtx.shadowColor = '#00f0ff'; cCtx.shadowBlur = 10 + pulse * 14;
            cCtx.beginPath(); cCtx.ellipse(-rad * 0.35, -rad * 0.1, 5, 2.5, 0, 0, Math.PI * 2); cCtx.ellipse(rad * 0.35, -rad * 0.1, 5, 2.5, 0, 0, Math.PI * 2); cCtx.fill();
            cCtx.shadowBlur = 0;

            cCtx.strokeStyle = '#ea580c'; cCtx.lineWidth = 4;
            cCtx.beginPath(); cCtx.arc(0, rad * 0.5, rad * 0.7, 0.2, Math.PI - 0.2); cCtx.stroke();
            break;
        }
    }
}

function drawUnifiedSkin(cCtx, cx, cy, rad, skinDef, animOptions = {}) {
    const skin = skinDef || ALL_SKINS_LIST[0];
    cCtx.save();
    cCtx.translate(cx, cy);

    const scaleX = animOptions.scaleX || 1;
    const scaleY = animOptions.scaleY || 1;
    const gDir = animOptions.gravityDir || 1;
    const rot = animOptions.rotation || 0;

    cCtx.scale(scaleX, scaleY * gDir);
    cCtx.rotate(rot);

    try {
        if (skin.renderType === 'robot') {
            drawClassicRobotSkin(cCtx, rad, skin, animOptions);
        } else {
            draw30VectorBall(cCtx, rad, skin.skinNum || 1, animOptions);
        }
    } catch (e) {
        cCtx.fillStyle = '#00f0ff';
        cCtx.beginPath(); cCtx.arc(0, 0, rad, 0, Math.PI * 2); cCtx.fill();
    }

    cCtx.restore();
}

class SkinRegistry {
    static get(skinId) {
        const found = ALL_SKINS_LIST.find(s => s.id === skinId);
        return found || ALL_SKINS_LIST[0];
    }
    static getAll() {
        return ALL_SKINS_LIST;
    }
    static getByGroup(group) {
        return ALL_SKINS_LIST.filter(s => s.group === group);
    }
    static draw(cCtx, cx, cy, rad, skinDef, animOptions) {
        drawUnifiedSkin(cCtx, cx, cy, rad, skinDef, animOptions);
    }
}

window.ALL_SKINS_LIST = ALL_SKINS_LIST;
window.drawUnifiedSkin = drawUnifiedSkin;
window.SkinRegistry = SkinRegistry;