/**
 * js/backgrounds.js - Процедурні паралакс-фони світів 1–30
 * Плавне перетікання біомів (No Hard Cut Lines) та стохастична система хаотичних частинок
 */

// =========================================================================
// УТИЛІТИ КОЛЬОРУ ТА ПЛАВНОЇ ІНТЕРПОЛЯЦІЇ (COLOR LERP)
// =========================================================================
function hexToRgb(hex) {
    if (!hex) return { r: 0, g: 0, b: 0 };
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    const num = parseInt(hex, 16);
    return { r: (num >> 16) & 255, g: (num >> 8) & 255, b: num & 255 };
}

function rgbToHex(r, g, b) {
    return '#' + [r, g, b].map(x => {
        const h = Math.max(0, Math.min(255, Math.round(x))).toString(16);
        return h.length === 1 ? '0' + h : h;
    }).join('');
}

function parseColorString(str) {
    if (!str) return { r: 0, g: 0, b: 0, a: 1 };
    str = str.trim();
    if (str.startsWith('#')) {
        const rgb = hexToRgb(str);
        return { r: rgb.r, g: rgb.g, b: rgb.b, a: 1 };
    }
    const match = str.match(/rgba?\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([\d.]+))?\s*\)/);
    if (match) {
        return {
            r: parseInt(match[1]),
            g: parseInt(match[2]),
            b: parseInt(match[3]),
            a: match[4] !== undefined ? parseFloat(match[4]) : 1
        };
    }
    return { r: 0, g: 0, b: 0, a: 1 };
}

function lerpAnyColor(c1, c2, t) {
    const p1 = parseColorString(c1);
    const p2 = parseColorString(c2);
    const r = Math.round(p1.r + (p2.r - p1.r) * t);
    const g = Math.round(p1.g + (p2.g - p1.g) * t);
    const b = Math.round(p1.b + (p2.b - p1.b) * t);
    const a = +(p1.a + (p2.a - p1.a) * t).toFixed(3);
    if (p1.a < 1 || p2.a < 1 || (c1 && c1.startsWith('rgba')) || (c2 && c2.startsWith('rgba'))) {
        return `rgba(${r}, ${g}, ${b}, ${a})`;
    }
    return rgbToHex(r, g, b);
}

function interpolateTheme(t1, t2, progress) {
    if (!t1) return t2;
    if (!t2) return t1;
    const s = progress * progress * (3 - 2 * progress); // smoothstep
    return {
        id: progress < 0.5 ? t1.id : t2.id,
        name: progress < 0.5 ? t1.name : t2.name,
        skyTop: lerpAnyColor(t1.skyTop, t2.skyTop, s),
        skyMid: lerpAnyColor(t1.skyMid, t2.skyMid, s),
        skyBot: lerpAnyColor(t1.skyBot, t2.skyBot, s),
        railFloor: lerpAnyColor(t1.railFloor, t2.railFloor, s),
        railFloorDark: lerpAnyColor(t1.railFloorDark, t2.railFloorDark, s),
        railCeil: lerpAnyColor(t1.railCeil, t2.railCeil, s),
        railCeilDark: lerpAnyColor(t1.railCeilDark, t2.railCeilDark, s),
        chainCol: lerpAnyColor(t1.chainCol, t2.chainCol, s),
        gearCol: lerpAnyColor(t1.gearCol, t2.gearCol, s),
        planetCol: lerpAnyColor(t1.planetCol, t2.planetCol, s),
        skinName: progress < 0.5 ? t1.skinName : t2.skinName,
        trailCol: lerpAnyColor(t1.trailCol, t2.trailCol, s)
    };
}

// =========================================================================
// СТОХАСТИЧНИЙ ХАОТИЧНИЙ СИМУЛЯТОР ЧАСТИНОК (БЕЗ ЖОДНОГО ПАТЕРНУ)
// =========================================================================
class ChaoticBiomeParticleSystem {
    constructor(count = 42) {
        this.count = count;
        this.particles = [];
        this.lastX = 0;
        this.init();
    }

    init() {
        this.particles = [];
        for (let i = 0; i < this.count; i++) {
            this.particles.push(this.createParticle(true));
        }
    }

    createParticle(randomX = false, viewWidth = 1000, CEILING_Y = 125, FLOOR_Y = 475) {
        return {
            x: randomX ? Math.random() * (viewWidth + 200) - 100 : viewWidth + Math.random() * 80,
            y: CEILING_Y + 10 + Math.random() * (FLOOR_Y - CEILING_Y - 20),
            vx: -0.3 - Math.random() * 0.7,
            vy: (Math.random() - 0.5) * 0.4,
            size: 1.2 + Math.random() * 2.8,
            baseAlpha: 0.35 + Math.random() * 0.55,
            pulseSpeed: 0.002 + Math.random() * 0.005,
            phase: Math.random() * Math.PI * 2,
            noiseSeed: Math.random() * 1000,
            swayAmpX: 0.4 + Math.random() * 0.8,
            swayAmpY: 0.5 + Math.random() * 1.1,
            parallax: 0.2 + Math.random() * 0.45,
            colorHueShift: Math.random()
        };
    }

    getBiomePalette(bId) {
        switch (bId) {
            case 2: // Кібер-гай: світлячки (смарагд, лайм, м'ята, золото)
                return ['#34d399', '#10b981', '#6ee7b7', '#a7f3d0', '#fef08a'];
            case 3: // Магма: гарячий попіл, іскри (вогняний білий, жовтий, помаранч, рубін)
                return ['#fff7ed', '#fef08a', '#f97316', '#ef4444', '#b91c1c'];
            case 4: // Кришталь: алмазний пил, аметистові мерехтіння
                return ['#e879f9', '#c084fc', '#ffffff', '#67e8f9', '#fdf4ff'];
            case 5: // Крига: сніжинки, морозні інійні крихти
                return ['#ffffff', '#e0f2fe', '#bae6fd', '#7dd3fc', '#38bdf8'];
            default: // Неон: кібернетичні квантові крапки
                return ['#00f0ff', '#38bdf8', '#c084fc', '#facc15', '#ffffff'];
        }
    }

    updateAndDraw(ctx, activeBiome, transitionData, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y) {
        const deltaCamX = renderCamX - this.lastX;
        this.lastX = renderCamX;

        const curBiomeId = activeBiome.id || 1;
        const curPalette = this.getBiomePalette(curBiomeId);

        let nextPalette = null;
        let transProgress = 0;
        if (transitionData && transitionData.isTransitioning && transitionData.toBiome) {
            nextPalette = this.getBiomePalette(transitionData.toBiome.id || 1);
            transProgress = transitionData.progress;
        }

        ctx.save();
        for (let i = 0; i < this.particles.length; i++) {
            const p = this.particles[i];

            // Турбулентний шумовий вектор
            const noise = Math.sin(time * 0.0018 + p.noiseSeed) * Math.cos(time * 0.0012 + p.noiseSeed * 1.7);
            const noise2 = Math.sin(time * 0.0022 + p.noiseSeed * 2.1);

            // Поведінка залежно від біому
            if (curBiomeId === 3) {
                // Магма: конвекційні потоки тягнуть іскри вгору
                p.vy = -0.8 - Math.abs(noise) * 1.2;
                p.x += (p.vx + noise * p.swayAmpX * 1.4) - deltaCamX * p.parallax;
                p.y += p.vy;
            } else if (curBiomeId === 5) {
                // Крига: пориви вітру хуртовини тягнуть вліво і вниз
                p.x += (p.vx * 1.8 - 0.9 + noise * 0.4) - deltaCamX * p.parallax;
                p.y += (0.6 + Math.abs(noise2) * 0.8);
            } else if (curBiomeId === 4) {
                // Кришталь: антигравітаційне повільне зависання
                p.x += (p.vx * 0.4 + noise * 0.3) - deltaCamX * p.parallax;
                p.y += (noise2 * 0.4);
            } else {
                // Кібер-гай та інші: плавне плавання світлячків
                p.x += (p.vx + noise * p.swayAmpX) - deltaCamX * p.parallax;
                p.y += (p.vy + noise2 * p.swayAmpY);
            }

            // Перевірка меж та безшовний респавн
            if (p.x < -60) {
                p.x = viewWidth + 40 + Math.random() * 80;
                p.y = CEILING_Y + 15 + Math.random() * (FLOOR_Y - CEILING_Y - 30);
                p.noiseSeed = Math.random() * 1000;
            } else if (p.x > viewWidth + 120) {
                p.x = -30;
                p.y = CEILING_Y + 15 + Math.random() * (FLOOR_Y - CEILING_Y - 30);
            }

            if (p.y < CEILING_Y - 10) {
                p.y = FLOOR_Y - 10 - Math.random() * 30;
                p.x = Math.random() * viewWidth;
            } else if (p.y > FLOOR_Y + 10) {
                p.y = CEILING_Y + 10 + Math.random() * 30;
                p.x = Math.random() * viewWidth;
            }

            // Розрахунок кольору частинки з плавним перетіканням
            const cIdx = Math.floor(p.colorHueShift * curPalette.length);
            let particleColor = curPalette[cIdx % curPalette.length];

            if (nextPalette && transProgress > 0) {
                const nextColor = nextPalette[cIdx % nextPalette.length];
                particleColor = lerpAnyColor(particleColor, nextColor, transProgress);
            }

            // Індивідуальне мерехтіння
            const pulse = (Math.sin(time * p.pulseSpeed + p.phase) + 1) * 0.5;
            const finalAlpha = p.baseAlpha * (0.45 + 0.55 * pulse);

            // Малювання хаотичної точки
            ctx.fillStyle = particleColor;
            ctx.globalAlpha = Math.max(0, Math.min(1, finalAlpha));

            if (curBiomeId === 2 || curBiomeId === 4) {
                ctx.shadowColor = particleColor;
                ctx.shadowBlur = 6 * pulse;
            }

            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
            ctx.shadowBlur = 0;
        }
        ctx.restore();
    }
}

const backgroundParticleSystem = new ChaoticBiomeParticleSystem(48);

// =========================================================================
// УНІКАЛЬНІ СПОРУДИ ДЛЯ КОЖНОГО ОКРЕМОГО СВІТУ (БЕЗ ДУБЛЮВАННЯ)
// =========================================================================
function drawCyberBioVine(ctx, p0, p1, p2, vineColor, nodeColor, time) {
    ctx.save();
    ctx.strokeStyle = vineColor;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(p0.x, p0.y);
    ctx.quadraticCurveTo(p1.x, p1.y, p2.x, p2.y);
    ctx.stroke();

    for (let t = 0.2; t <= 0.85; t += 0.2) {
        const inv = 1 - t;
        const nx = inv * inv * p0.x + 2 * inv * t * p1.x + t * t * p2.x;
        const ny = inv * inv * p0.y + 2 * inv * t * p1.y + t * t * p2.y;
        const pulse = 0.6 + Math.sin(time * 0.006 + t * 10) * 0.4;
        ctx.fillStyle = nodeColor;
        ctx.shadowColor = nodeColor;
        ctx.shadowBlur = 6 * pulse;
        ctx.beginPath();
        ctx.arc(nx, ny, 3.5 * pulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
    }
    ctx.restore();
}

function renderWorld2Scenery(ctx, activeBiome, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y) {
    // Шар 1: Місяць (0.02x)
    const deepCamX = renderCamX * 0.02;
    const moonX = ((680 - deepCamX) % (viewWidth + 500) + (viewWidth + 500)) % (viewWidth + 500) - 200;
    ctx.save();
    ctx.translate(moonX, 130);
    const mGlow = ctx.createRadialGradient(0, 0, 20, 0, 0, 120);
    mGlow.addColorStop(0, 'rgba(52, 211, 153, 0.45)');
    mGlow.addColorStop(0.6, 'rgba(16, 185, 129, 0.12)');
    mGlow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = mGlow;
    ctx.beginPath(); ctx.arc(0, 0, 120, 0, Math.PI * 2); ctx.fill();

    ctx.fillStyle = '#022c22';
    ctx.beginPath(); ctx.arc(0, 0, 52, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#34d399'; ctx.lineWidth = 2.5; ctx.stroke();

    ctx.strokeStyle = 'rgba(52, 211, 153, 0.3)'; ctx.lineWidth = 1.2;
    for (let l = -35; l <= 35; l += 14) {
        ctx.beginPath(); ctx.moveTo(-35, l); ctx.lineTo(35, l); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(l, -35); ctx.lineTo(l, 35); ctx.stroke();
    }
    ctx.save();
    ctx.rotate(-0.35);
    ctx.strokeStyle = 'rgba(52, 211, 153, 0.5)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.ellipse(0, 0, 88, 22, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.restore();
    ctx.restore();

    // Шар 2: Далекий полог лісу (0.05x)
    const farX = renderCamX * 0.05;
    for (let f = -150; f < viewWidth + 300; f += 220) {
        const screenFarX = ((f - farX) % (viewWidth + 400) + (viewWidth + 400)) % (viewWidth + 400) - 150;
        ctx.fillStyle = 'rgba(2, 44, 34, 0.5)';
        ctx.beginPath();
        ctx.arc(screenFarX, FLOOR_Y - 140, 75, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = 'rgba(52, 211, 153, 0.15)'; ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(screenFarX, FLOOR_Y); ctx.lineTo(screenFarX, FLOOR_Y - 140);
        ctx.stroke();
    }

    // Шар 3: Варіативні великі сектори (0.15x, крок 780px)
    const midX = renderCamX * 0.15;
    const sectorWidth = 780;
    const sStart = Math.floor((midX - 350) / sectorWidth) * sectorWidth;
    const sEnd = Math.floor((midX + viewWidth + 350) / sectorWidth) * sectorWidth;

    for (let sx = sStart; sx <= sEnd; sx += sectorWidth) {
        const screenX = sx - midX;
        const sectorIndex = Math.abs(Math.floor(sx / sectorWidth)) % 3;

        if (sectorIndex === 0) {
            ctx.save();
            ctx.translate(screenX + 180, 0);
            ctx.fillStyle = '#03251d';
            ctx.strokeStyle = '#059669'; ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(-45, CEILING_Y - 20);
            ctx.bezierCurveTo(-15, 230, -35, 340, -60, FLOOR_Y + 18);
            ctx.lineTo(60, FLOOR_Y + 18);
            ctx.bezierCurveTo(35, 340, 15, 230, 45, CEILING_Y - 20);
            ctx.closePath();
            ctx.fill(); ctx.stroke();

            const p1 = 0.5 + Math.sin(time * 0.005 + sx) * 0.5;
            ctx.strokeStyle = `rgba(52, 211, 153, ${0.4 + p1 * 0.5})`;
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(-15, CEILING_Y); ctx.quadraticCurveTo(0, 300, -25, FLOOR_Y);
            ctx.moveTo(15, CEILING_Y); ctx.quadraticCurveTo(0, 300, 25, FLOOR_Y);
            ctx.stroke();

            ctx.fillStyle = 'rgba(6, 78, 59, 0.7)';
            ctx.beginPath();
            ctx.arc(-70, 220, 50, 0, Math.PI * 2);
            ctx.arc(70, 250, 55, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#10b981'; ctx.lineWidth = 2; ctx.stroke();

            drawCyberBioVine(ctx, { x: -160, y: CEILING_Y + 20 }, { x: -70, y: 220 }, { x: -45, y: 260 }, '#059669', '#34d399', time);
            ctx.restore();
        } else if (sectorIndex === 1) {
            ctx.save();
            ctx.translate(screenX + 170, FLOOR_Y);
            const mushrooms = [
                { x: -70, h: 180, r: 52, col: '#10b981', glow: '#34d399' },
                { x: 30, h: 125, r: 40, col: '#059669', glow: '#6ee7b7' },
                { x: 100, h: 80, r: 30, col: '#047857', glow: '#a7f3d0' }
            ];
            mushrooms.forEach(m => {
                ctx.strokeStyle = '#022c22'; ctx.lineWidth = 14; ctx.lineCap = 'round';
                ctx.beginPath();
                ctx.moveTo(m.x, 0); ctx.quadraticCurveTo(m.x - 8, -m.h * 0.5, m.x, -m.h);
                ctx.stroke();
                ctx.strokeStyle = m.col; ctx.lineWidth = 3; ctx.stroke();

                ctx.fillStyle = m.col;
                ctx.shadowColor = m.glow; ctx.shadowBlur = 14;
                ctx.beginPath();
                ctx.ellipse(m.x, -m.h, m.r, m.r * 0.55, 0, Math.PI, 0);
                ctx.closePath();
                ctx.fill();
                ctx.shadowBlur = 0;
                ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.8; ctx.stroke();
            });
            drawCyberBioVine(ctx, { x: -140, y: -60 }, { x: -40, y: -190 }, { x: 80, y: -130 }, '#047857', '#34d399', time);
            ctx.restore();
        } else {
            ctx.save();
            ctx.translate(screenX + 160, FLOOR_Y);
            ctx.fillStyle = '#02231c';
            ctx.strokeStyle = '#10b981'; ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.moveTo(-60, 0); ctx.lineTo(-25, -200); ctx.lineTo(25, -200); ctx.lineTo(60, 0);
            ctx.closePath();
            ctx.fill(); ctx.stroke();

            const lev = Math.sin(time * 0.004) * 8;
            ctx.fillStyle = '#34d399';
            ctx.shadowColor = '#34d399'; ctx.shadowBlur = 16;
            ctx.beginPath();
            ctx.moveTo(0, -250 + lev); ctx.lineTo(16, -225 + lev); ctx.lineTo(0, -205 + lev); ctx.lineTo(-16, -225 + lev);
            ctx.closePath(); ctx.fill();
            ctx.shadowBlur = 0;

            for (let r = 0; r < 4; r++) {
                const lit = Math.sin(time * 0.003 + r * 1.5 + sx) > 0;
                ctx.fillStyle = lit ? '#6ee7b7' : 'rgba(52, 211, 153, 0.15)';
                ctx.fillRect(-15, -170 + r * 40, 30, 8);
            }
            drawCyberBioVine(ctx, { x: -120, y: -20 }, { x: -40, y: -180 }, { x: 25, y: -200 }, '#059669', '#6ee7b7', time);
            ctx.restore();
        }
    }
}

function renderWorld3Scenery(ctx, activeBiome, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y) {
    const deepCamX = renderCamX * 0.02;
    const sunX = ((640 - deepCamX) % (viewWidth + 500) + (viewWidth + 500)) % (viewWidth + 500) - 200;
    ctx.save();
    ctx.translate(sunX, 130);
    const sGrad = ctx.createRadialGradient(0, 0, 25, 0, 0, 140);
    sGrad.addColorStop(0, '#ff3b00');
    sGrad.addColorStop(0.5, 'rgba(239, 68, 68, 0.45)');
    sGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = sGrad;
    ctx.beginPath(); ctx.arc(0, 0, 140, 0, Math.PI * 2); ctx.fill();

    ctx.fillStyle = '#1c0205';
    ctx.beginPath(); ctx.arc(0, 0, 60, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#f97316'; ctx.lineWidth = 3; ctx.stroke();

    ctx.strokeStyle = '#ef4444'; ctx.lineWidth = 2.5;
    for (let a = 0; a < 6; a++) {
        const ang = a * (Math.PI / 3) + time * 0.001;
        ctx.beginPath();
        ctx.moveTo(Math.cos(ang) * 60, Math.sin(ang) * 60);
        ctx.lineTo(Math.cos(ang) * 85, Math.sin(ang) * 85);
        ctx.stroke();
    }
    ctx.restore();

    const farX = renderCamX * 0.05;
    for (let f = -180; f < viewWidth + 300; f += 240) {
        const sx = ((f - farX) % (viewWidth + 400) + (viewWidth + 400)) % (viewWidth + 400) - 150;
        ctx.fillStyle = '#2d060a';
        ctx.beginPath();
        ctx.moveTo(sx - 120, FLOOR_Y); ctx.lineTo(sx, FLOOR_Y - 170); ctx.lineTo(sx + 120, FLOOR_Y);
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = 'rgba(249, 115, 22, 0.35)'; ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(sx, FLOOR_Y - 170); ctx.lineTo(sx - 20, FLOOR_Y - 70); ctx.lineTo(sx, FLOOR_Y);
        ctx.stroke();
    }

    const midX = renderCamX * 0.15;
    const sectorWidth = 780;
    const sStart = Math.floor((midX - 350) / sectorWidth) * sectorWidth;
    const sEnd = Math.floor((midX + viewWidth + 350) / sectorWidth) * sectorWidth;

    for (let sx = sStart; sx <= sEnd; sx += sectorWidth) {
        const screenX = sx - midX;
        const sectorIndex = Math.abs(Math.floor(sx / sectorWidth)) % 3;

        if (sectorIndex === 0) {
            ctx.save();
            ctx.translate(screenX + 180, FLOOR_Y);
            ctx.fillStyle = '#1c0407';
            ctx.beginPath();
            ctx.moveTo(-160, 0); ctx.lineTo(-45, -185); ctx.lineTo(45, -185); ctx.lineTo(140, 0);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = '#7f1d1d'; ctx.lineWidth = 3; ctx.stroke();

            ctx.fillStyle = '#ff7a00';
            ctx.beginPath(); ctx.ellipse(0, -185, 45, 14, 0, 0, Math.PI * 2); ctx.fill();

            ctx.strokeStyle = '#ef4444'; ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.moveTo(-10, -180); ctx.lineTo(-30, -100); ctx.lineTo(-12, -40); ctx.lineTo(-25, 0);
            ctx.moveTo(12, -180); ctx.lineTo(35, -90); ctx.lineTo(20, -30); ctx.lineTo(38, 0);
            ctx.stroke();

            const erupt = Math.sin(time * 0.008 + sx) > 0.15;
            if (erupt) {
                ctx.fillStyle = '#fef08a';
                ctx.shadowColor = '#ea580c'; ctx.shadowBlur = 18;
                ctx.beginPath();
                ctx.moveTo(-16, -185); ctx.lineTo(0, -255 - Math.sin(time * 0.015) * 25); ctx.lineTo(16, -185);
                ctx.closePath(); ctx.fill();
                ctx.shadowBlur = 0;
            }
            ctx.restore();
        } else if (sectorIndex === 1) {
            ctx.save();
            ctx.translate(screenX + 160, FLOOR_Y);
            ctx.fillStyle = '#180306';
            ctx.strokeStyle = '#991b1b'; ctx.lineWidth = 2.5;

            const pillars = [
                { x: -90, w: 45, h: 90 }, { x: -45, w: 50, h: 195 },
                { x: 5, w: 45, h: 140 }, { x: 50, w: 50, h: 80 }
            ];
            pillars.forEach(p => {
                ctx.fillRect(p.x, -p.h, p.w, p.h);
                ctx.strokeRect(p.x, -p.h, p.w, p.h);
                ctx.fillStyle = '#ff7a00';
                ctx.fillRect(p.x, -p.h - 4, p.w, 6);
                ctx.fillStyle = '#180306';
            });
            ctx.restore();
        } else {
            ctx.save();
            ctx.translate(screenX + 150, FLOOR_Y);
            ctx.fillStyle = '#220509';
            ctx.strokeStyle = '#7f1d1d'; ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(-110, 0); ctx.bezierCurveTo(-110, -220, 110, -220, 110, 0);
            ctx.lineTo(70, 0); ctx.bezierCurveTo(70, -150, -70, -150, -70, 0);
            ctx.closePath(); ctx.fill(); ctx.stroke();

            ctx.fillStyle = '#f97316';
            ctx.beginPath();
            ctx.moveTo(-20, -150); ctx.lineTo(-10, -115); ctx.lineTo(0, -150);
            ctx.moveTo(10, -150); ctx.lineTo(20, -125); ctx.lineTo(30, -150);
            ctx.fill();
            ctx.restore();
        }
    }
}

function renderWorld4Scenery(ctx, activeBiome, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y) {
    const deepCamX = renderCamX * 0.02;
    const geodeX = ((630 - deepCamX) % (viewWidth + 500) + (viewWidth + 500)) % (viewWidth + 500) - 200;
    ctx.save();
    ctx.translate(geodeX, 140);
    const cGrad = ctx.createRadialGradient(0, 0, 30, 0, 0, 140);
    cGrad.addColorStop(0, 'rgba(232, 121, 249, 0.5)');
    cGrad.addColorStop(0.6, 'rgba(192, 132, 252, 0.15)');
    cGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = cGrad;
    ctx.beginPath(); ctx.arc(0, 0, 140, 0, Math.PI * 2); ctx.fill();

    ctx.fillStyle = '#3b0764';
    ctx.strokeStyle = '#e879f9'; ctx.lineWidth = 2.5;
    ctx.beginPath();
    for (let a = 0; a < 8; a++) {
        const ang = a * (Math.PI / 4);
        const r = a % 2 === 0 ? 58 : 44;
        const cx = Math.cos(ang) * r, cy = Math.sin(ang) * r;
        if (a === 0) ctx.moveTo(cx, cy); else ctx.lineTo(cx, cy);
    }
    ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.restore();

    const farX = renderCamX * 0.05;
    ctx.save();
    ctx.rotate(-0.2);
    for (let r = -200; r < viewWidth + 400; r += 260) {
        const rayX = ((r - farX) % (viewWidth + 400) + (viewWidth + 400)) % (viewWidth + 400) - 150;
        const rGrad = ctx.createLinearGradient(rayX, 0, rayX + 60, 600);
        rGrad.addColorStop(0, 'rgba(232, 121, 249, 0.14)');
        rGrad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = rGrad;
        ctx.fillRect(rayX, 0, 70, 900);
    }
    ctx.restore();

    const midX = renderCamX * 0.15;
    const sectorWidth = 780;
    const sStart = Math.floor((midX - 350) / sectorWidth) * sectorWidth;
    const sEnd = Math.floor((midX + viewWidth + 350) / sectorWidth) * sectorWidth;

    for (let sx = sStart; sx <= sEnd; sx += sectorWidth) {
        const screenX = sx - midX;
        const sectorIndex = Math.abs(Math.floor(sx / sectorWidth)) % 3;

        if (sectorIndex === 0) {
            ctx.save();
            ctx.translate(screenX + 175, 0);
            ctx.fillStyle = '#581c87';
            ctx.beginPath();
            ctx.moveTo(-38, CEILING_Y - 14); ctx.lineTo(-8, CEILING_Y + 115); ctx.lineTo(8, CEILING_Y + 135); ctx.lineTo(32, CEILING_Y - 14);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = '#c084fc'; ctx.lineWidth = 2.5; ctx.stroke();

            ctx.fillStyle = '#3b0764';
            ctx.beginPath();
            ctx.moveTo(15, FLOOR_Y + 18); ctx.lineTo(60, FLOOR_Y - 130); ctx.lineTo(95, FLOOR_Y + 18);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = '#a855f7'; ctx.lineWidth = 2.5; ctx.stroke();
            ctx.restore();
        } else if (sectorIndex === 1) {
            ctx.save();
            ctx.translate(screenX + 160, 240);
            const shards = [
                { x: -60, y: -40, s: 28, r: 0.2 }, { x: 30, y: 15, s: 38, r: -0.3 }, { x: 85, y: -50, s: 22, r: 0.4 }
            ];
            shards.forEach(sh => {
                const bob = Math.sin(time * 0.004 + sh.x) * 10;
                ctx.save();
                ctx.translate(sh.x, sh.y + bob);
                ctx.rotate(sh.r);
                ctx.fillStyle = '#7e22ce';
                ctx.shadowColor = '#e879f9'; ctx.shadowBlur = 14;
                ctx.beginPath();
                ctx.moveTo(0, -sh.s); ctx.lineTo(sh.s * 0.6, 0); ctx.lineTo(0, sh.s); ctx.lineTo(-sh.s * 0.6, 0);
                ctx.closePath(); ctx.fill();
                ctx.shadowBlur = 0;
                ctx.strokeStyle = '#f5d0fe'; ctx.lineWidth = 2; ctx.stroke();
                ctx.restore();
            });
            ctx.restore();
        } else {
            ctx.save();
            ctx.translate(screenX + 160, 0);
            for (let c = -50; c <= 50; c += 35) {
                const sLen = 70 + Math.abs(c);
                ctx.fillStyle = '#4c1d95';
                ctx.beginPath();
                ctx.moveTo(c - 14, CEILING_Y - 14); ctx.lineTo(c, CEILING_Y + sLen); ctx.lineTo(c + 14, CEILING_Y - 14);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = '#c084fc'; ctx.lineWidth = 2; ctx.stroke();
            }
            ctx.restore();
        }
    }
}

function renderWorld5Scenery(ctx, activeBiome, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y) {
    ctx.save();
    for (let a = 0; a < 3; a++) {
        ctx.beginPath();
        const aAlpha = 0.18 + Math.sin(time * 0.003 + a) * 0.08;
        ctx.fillStyle = a === 0 ? `rgba(56, 189, 248, ${aAlpha})` : `rgba(52, 211, 153, ${aAlpha})`;
        ctx.moveTo(0, 50 + a * 35);
        for (let x = 0; x <= viewWidth; x += 60) {
            const waveY = 60 + a * 35 + Math.sin(x * 0.006 + time * 0.002 + a * 1.5) * 32;
            ctx.lineTo(x, waveY);
        }
        ctx.lineTo(viewWidth, 0); ctx.lineTo(0, 0); ctx.closePath(); ctx.fill();
    }
    ctx.restore();

    const deepCamX = renderCamX * 0.02;
    const iceMoonX = ((660 - deepCamX) % (viewWidth + 500) + (viewWidth + 500)) % (viewWidth + 500) - 200;
    ctx.save();
    ctx.translate(iceMoonX, 125);
    const halo = ctx.createRadialGradient(0, 0, 15, 0, 0, 95);
    halo.addColorStop(0, 'rgba(224, 242, 254, 0.45)');
    halo.addColorStop(0.6, 'rgba(56, 189, 248, 0.12)');
    halo.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = halo;
    ctx.beginPath(); ctx.arc(0, 0, 95, 0, Math.PI * 2); ctx.fill();

    ctx.fillStyle = '#072f4a';
    ctx.beginPath(); ctx.arc(0, 0, 46, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#7dd3fc'; ctx.lineWidth = 2.5; ctx.stroke();
    ctx.restore();

    const midX = renderCamX * 0.15;
    const sectorWidth = 780;
    const sStart = Math.floor((midX - 350) / sectorWidth) * sectorWidth;
    const sEnd = Math.floor((midX + viewWidth + 350) / sectorWidth) * sectorWidth;

    for (let sx = sStart; sx <= sEnd; sx += sectorWidth) {
        const screenX = sx - midX;
        const sectorIndex = Math.abs(Math.floor(sx / sectorWidth)) % 3;

        if (sectorIndex === 0) {
            ctx.save();
            ctx.translate(screenX + 180, FLOOR_Y);
            ctx.fillStyle = '#072f4a';
            ctx.beginPath();
            ctx.moveTo(-110, 0); ctx.lineTo(-15, -185); ctx.lineTo(-15, 0);
            ctx.closePath(); ctx.fill();

            ctx.fillStyle = '#0284c7';
            ctx.beginPath();
            ctx.moveTo(0, -185); ctx.lineTo(95, 0); ctx.lineTo(0, 0);
            ctx.closePath(); ctx.fill();

            ctx.strokeStyle = '#7dd3fc'; ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(-110, 0); ctx.lineTo(-15, -185); ctx.lineTo(0, 0); ctx.lineTo(0, -185); ctx.lineTo(95, 0);
            ctx.stroke();
            ctx.restore();
        } else if (sectorIndex === 1) {
            ctx.save();
            ctx.translate(screenX + 160, 0);
            ctx.fillStyle = '#0c4a6e';
            ctx.strokeStyle = '#38bdf8'; ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(-100, CEILING_Y - 14);
            ctx.bezierCurveTo(-40, CEILING_Y + 110, 40, CEILING_Y + 110, 100, CEILING_Y - 14);
            ctx.stroke();

            const icicles = [-70, -45, -20, 0, 20, 45, 70];
            icicles.forEach((ix, idx) => {
                const len = 35 + (idx % 3) * 25;
                ctx.fillStyle = '#e0f2fe';
                ctx.beginPath();
                ctx.moveTo(ix - 6, CEILING_Y + 30); ctx.lineTo(ix, CEILING_Y + 30 + len); ctx.lineTo(ix + 6, CEILING_Y + 30);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = '#7dd3fc'; ctx.lineWidth = 1.5; ctx.stroke();
            });
            ctx.restore();
        } else {
            ctx.save();
            ctx.translate(screenX + 160, FLOOR_Y);
            ctx.fillStyle = '#072f4a';
            ctx.strokeStyle = '#38bdf8'; ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.moveTo(-35, 0); ctx.lineTo(-20, -190); ctx.lineTo(20, -190); ctx.lineTo(35, 0);
            ctx.closePath(); ctx.fill(); ctx.stroke();

            ctx.fillStyle = '#e0f2fe';
            ctx.beginPath();
            ctx.moveTo(-24, -190); ctx.lineTo(0, -215); ctx.lineTo(24, -190);
            ctx.closePath(); ctx.fill();
            ctx.restore();
        }
    }
}

function renderWorld1Scenery(ctx, activeBiome, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y) {
    const deepCamX = renderCamX * 0.02;
    const planetScreenX = ((650 - deepCamX) % (viewWidth + 500) + (viewWidth + 500)) % (viewWidth + 500) - 200;

    ctx.save();
    ctx.translate(planetScreenX, 130);
    const haloGrad = ctx.createRadialGradient(0, 0, 30, 0, 0, 110);
    haloGrad.addColorStop(0, activeBiome.planetCol);
    haloGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = haloGrad;
    ctx.globalAlpha = 0.35;
    ctx.beginPath(); ctx.arc(0, 0, 110, 0, Math.PI * 2); ctx.fill();

    ctx.globalAlpha = 0.85;
    ctx.fillStyle = activeBiome.skyMid;
    ctx.beginPath(); ctx.arc(0, 0, 55, 0, Math.PI * 2); ctx.fill();
    ctx.lineWidth = 2; ctx.strokeStyle = activeBiome.planetCol; ctx.stroke();

    ctx.save();
    ctx.rotate(0.35);
    ctx.lineWidth = 4; ctx.strokeStyle = activeBiome.planetCol;
    ctx.beginPath(); ctx.ellipse(0, 0, 95, 20, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.restore();
    ctx.restore();

    const farX = renderCamX * 0.05;
    const ringInterval = 720;
    const rStart = Math.floor((farX - 200) / ringInterval) * ringInterval;
    for (let rx = rStart; rx < farX + viewWidth + 300; rx += ringInterval) {
        const sx = rx - farX;
        ctx.lineWidth = 4;
        ctx.strokeStyle = activeBiome.chainCol;
        ctx.beginPath(); ctx.arc(sx, 300, 160, 0, Math.PI * 2); ctx.stroke();
    }
}

function renderBiomeScenery(ctx, theme, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y) {
    const id = theme.id || 1;
    if (id === 2) renderWorld2Scenery(ctx, theme, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);
    else if (id === 3) renderWorld3Scenery(ctx, theme, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);
    else if (id === 4) renderWorld4Scenery(ctx, theme, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);
    else if (id === 5) renderWorld5Scenery(ctx, theme, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);
    else renderWorld1Scenery(ctx, theme, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);
}

// =========================================================================
// ГОЛОВНИЙ РЕНДЕРЕР ФОНУ З ПЛАВНИМ ПЕРЕТІКАННЯМ СВІТІВ
// =========================================================================
function renderBackground(ctx, activeBiome, time, renderCamX, viewWidth, viewHeight, CEILING_Y, FLOOR_Y, transitionData) {
    ctx.save();

    const isTrans = transitionData && transitionData.isTransitioning && transitionData.toBiome;
    const effectiveTheme = isTrans
        ? interpolateTheme(transitionData.fromBiome, transitionData.toBiome, transitionData.progress)
        : activeBiome;

    // 1. Плавний базовий вертикальний градієнт неба
    const bgGrad = ctx.createLinearGradient(0, 0, viewWidth, viewHeight);
    bgGrad.addColorStop(0, effectiveTheme.skyTop || "#12052b");
    bgGrad.addColorStop(0.5, effectiveTheme.skyMid || "#250954");
    bgGrad.addColorStop(1, effectiveTheme.skyBot || "#082a3d");
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, viewWidth, viewHeight);

    // 2. Якщо йде перехід: насувається м'який світловий фронт справа наліво (БЕЗ ЛІНІЙ!)
    if (isTrans) {
        const p = transitionData.progress;
        // Хвиля завширшки 650px пливе через екран
        const waveCenter = viewWidth * (1.3 - p * 1.6);
        const waveGrad = ctx.createLinearGradient(waveCenter - 320, 0, waveCenter + 320, 0);
        waveGrad.addColorStop(0, 'rgba(0,0,0,0)');
        waveGrad.addColorStop(0.5, lerpAnyColor(transitionData.toBiome.skyMid, '#ffffff', 0.15));
        waveGrad.addColorStop(1, 'rgba(0,0,0,0)');

        ctx.save();
        ctx.globalAlpha = 0.35 * Math.sin(p * Math.PI);
        ctx.fillStyle = waveGrad;
        ctx.fillRect(0, 0, viewWidth, viewHeight);
        ctx.restore();
    }

    // 3. Відмальовка споруд світів із плавним альфа-розчиненням
    if (isTrans) {
        const p = transitionData.progress;
        const smoothP = p * p * (3 - 2 * p);

        // Попередній світ згасає
        ctx.save();
        ctx.globalAlpha = Math.max(0, 1 - smoothP);
        renderBiomeScenery(ctx, transitionData.fromBiome, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);
        ctx.restore();

        // Новий світ проявляється
        ctx.save();
        ctx.globalAlpha = Math.min(1, smoothP);
        renderBiomeScenery(ctx, transitionData.toBiome, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);
        ctx.restore();
    } else {
        renderBiomeScenery(ctx, activeBiome, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);
    }

    // 4. Стохастичні хаотичні мікрочастинки (не мають циклу, перетікають у кольорах)
    backgroundParticleSystem.updateAndDraw(ctx, effectiveTheme, transitionData, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);

    ctx.restore();
}

function renderTracks(ctx, activeBiome, renderCamX, viewWidth, viewHeight, CEILING_Y, FLOOR_Y, transitionData) {
    ctx.save();

    const isTrans = transitionData && transitionData.isTransitioning && transitionData.toBiome;
    const effectiveTheme = isTrans
        ? interpolateTheme(transitionData.fromBiome, transitionData.toBiome, transitionData.progress)
        : activeBiome;

    const ceilGrad = ctx.createLinearGradient(0, CEILING_Y - 16, 0, CEILING_Y);
    ceilGrad.addColorStop(0, effectiveTheme.railCeilDark);
    ceilGrad.addColorStop(1, effectiveTheme.railCeil);

    ctx.fillStyle = '#061325';
    ctx.fillRect(0, 0, viewWidth, CEILING_Y - 14);

    ctx.fillStyle = ceilGrad;
    ctx.fillRect(0, CEILING_Y - 14, viewWidth, 14);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, CEILING_Y - 4, viewWidth, 4);

    const floorGrad = ctx.createLinearGradient(0, FLOOR_Y, 0, FLOOR_Y + 18);
    floorGrad.addColorStop(0, effectiveTheme.railFloor);
    floorGrad.addColorStop(1, effectiveTheme.railFloorDark);

    ctx.fillStyle = floorGrad;
    ctx.fillRect(0, FLOOR_Y, viewWidth, 18);
    ctx.lineWidth = 3;
    ctx.strokeStyle = effectiveTheme.railFloorDark;
    ctx.strokeRect(0, FLOOR_Y, viewWidth, 18);

    ctx.save();
    ctx.fillStyle = '#fef08a';
    const dashSpacing = 36;
    const dashOff = (renderCamX * 0.8) % dashSpacing;
    for (let dx = -dashOff; dx < viewWidth; dx += dashSpacing) {
        ctx.beginPath();
        ctx.roundRect(dx, FLOOR_Y + 5, 20, 7, 3);
        ctx.fill();
    }
    ctx.restore();

    ctx.fillStyle = '#110c28';
    ctx.fillRect(0, FLOOR_Y + 18, viewWidth, viewHeight - (FLOOR_Y + 18));
    ctx.restore();
}

window.renderBackground = renderBackground;
window.renderTracks = renderTracks;