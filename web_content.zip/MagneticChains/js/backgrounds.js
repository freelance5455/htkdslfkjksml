/**
 * js/backgrounds.js - Процедурні паралакс-фони світів 1–30
 * Повна деталізація кожного біому (ланцюги, шестерні, виверження, кристали, айсберги)
 * М'який морфінг біомів та налаштовані динамічні магнітні кільця Світу 1
 */

// =========================================================================
// 1. УТИЛІТИ КОЛЬОРУ ТА ПЛАВНОЇ ІНТЕРПОЛЯЦІЇ
// =========================================================================
function hexToRgb(hex) {
    if (!hex) return { r: 0, g: 0, b: 0 };
    hex = hex.replace('#', '');
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    const num = parseInt(hex, 16);
    return { r: (num >> 16) & 255, g: (num >> 8) & 255, b: num & 255 };
}

function rgbToHex(r, g, b) {
    return '#' + [r, g, b].map(x => {
        const h = Math.max(0, Math.min(255, Math.round(x))).toString(16);
        return h.length === 1 ? '0' + h : h;
    }).join('');
}

function parseColorString(str) {
    if (!str) return { r: 0, g: 0, b: 0, a: 1 };
    str = str.trim();
    if (str.startsWith('#')) {
        const rgb = hexToRgb(str);
        return { r: rgb.r, g: rgb.g, b: rgb.b, a: 1 };
    }
    const match = str.match(/rgba?\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([\d.]+))?\s*\)/);
    if (match) {
        return {
            r: parseInt(match[1]),
            g: parseInt(match[2]),
            b: parseInt(match[3]),
            a: match[4] !== undefined ? parseFloat(match[4]) : 1
        };
    }
    return { r: 0, g: 0, b: 0, a: 1 };
}

function lerpAnyColor(c1, c2, t) {
    const p1 = parseColorString(c1);
    const p2 = parseColorString(c2);
    const r = Math.round(p1.r + (p2.r - p1.r) * t);
    const g = Math.round(p1.g + (p2.g - p1.g) * t);
    const b = Math.round(p1.b + (p2.b - p1.b) * t);
    const a = +(p1.a + (p2.a - p1.a) * t).toFixed(3);
    if (p1.a < 1 || p2.a < 1 || (c1 && c1.startsWith('rgba')) || (c2 && c2.startsWith('rgba'))) {
        return `rgba(${r}, ${g}, ${b}, ${a})`;
    }
    return rgbToHex(r, g, b);
}

function interpolateTheme(t1, t2, progress) {
    if (!t1) return t2;
    if (!t2) return t1;
    const s = progress * progress * (3 - 2 * progress);
    return {
        id: progress < 0.5 ? t1.id : t2.id,
        name: progress < 0.5 ? t1.name : t2.name,
        skyTop: lerpAnyColor(t1.skyTop, t2.skyTop, s),
        skyMid: lerpAnyColor(t1.skyMid, t2.skyMid, s),
        skyBot: lerpAnyColor(t1.skyBot, t2.skyBot, s),
        railFloor: lerpAnyColor(t1.railFloor, t2.railFloor, s),
        railFloorDark: lerpAnyColor(t1.railFloorDark, t2.railFloorDark, s),
        railCeil: lerpAnyColor(t1.railCeil, t2.railCeil, s),
        railCeilDark: lerpAnyColor(t1.railCeilDark, t2.railCeilDark, s),
        chainCol: lerpAnyColor(t1.chainCol, t2.chainCol, s),
        gearCol: lerpAnyColor(t1.gearCol, t2.gearCol, s),
        planetCol: lerpAnyColor(t1.planetCol, t2.planetCol, s),
        skinName: progress < 0.5 ? t1.skinName : t2.skinName,
        trailCol: lerpAnyColor(t1.trailCol, t2.trailCol, s)
    };
}

// =========================================================================
// 2. ДЕТАЛІЗОВАНІ ЕЛЕМЕНТИ (ЛАНЦЮГИ, ШЕСТЕРНІ, ЛІАНИ)
// =========================================================================
function drawWorld1Chain(ctx, p0, p1, p2, strokeColor) {
    const steps = 14;
    let prevPt = p0;
    for (let i = 1; i <= steps; i++) {
        const t = i / steps;
        const inv = 1 - t;
        const curX = inv * inv * p0.x + 2 * inv * t * p1.x + t * t * p2.x;
        const curY = inv * inv * p0.y + 2 * inv * t * p1.y + t * t * p2.y;

        if (i % 2 === 0) {
            const ang = Math.atan2(curY - prevPt.y, curX - prevPt.x);
            ctx.save();
            ctx.translate(curX, curY);
            ctx.rotate(ang);
            ctx.strokeStyle = strokeColor || "rgba(0, 240, 255, 0.45)";
            ctx.lineWidth = 2.4;
            ctx.beginPath();
            ctx.ellipse(0, 0, 8.5, 4.2, 0, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
        }
        prevPt = { x: curX, y: curY };
    }
}

function drawWorld1Gear(ctx, rOuter, rInner, teeth, fillColor, strokeColor, skyTop) {
    ctx.beginPath();
    for (let i = 0; i < teeth * 2; i++) {
        const ang = (i * Math.PI) / teeth;
        const r = i % 2 === 0 ? rOuter : rInner;
        const gx = Math.cos(ang) * r;
        const gy = Math.sin(ang) * r;
        if (i === 0) ctx.moveTo(gx, gy); else ctx.lineTo(gx, gy);
    }
    ctx.closePath();
    ctx.fillStyle = fillColor;
    ctx.fill();
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = strokeColor;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(0, 0, rInner * 0.45, 0, Math.PI * 2);
    ctx.fillStyle = skyTop || '#12052b';
    ctx.fill();
    ctx.stroke();
}

function drawCyberBioVine(ctx, p0, p1, p2, vineColor, nodeColor, time) {
    ctx.save();
    ctx.strokeStyle = vineColor;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(p0.x, p0.y);
    ctx.quadraticCurveTo(p1.x, p1.y, p2.x, p2.y);
    ctx.stroke();

    for (let t = 0.2; t <= 0.85; t += 0.2) {
        const inv = 1 - t;
        const nx = inv * inv * p0.x + 2 * inv * t * p1.x + t * t * p2.x;
        const ny = inv * inv * p0.y + 2 * inv * t * p1.y + t * t * p2.y;
        const pulse = 0.6 + Math.sin(time * 0.006 + t * 10) * 0.4;
        ctx.fillStyle = nodeColor;
        ctx.shadowColor = nodeColor;
        ctx.shadowBlur = 6 * pulse;
        ctx.beginPath();
        ctx.arc(nx, ny, 3.5 * pulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
    }
    ctx.restore();
}

// =========================================================================
// 3. УНІКАЛЬНІ АТМОСФЕРНІ СИСТЕМИ
// =========================================================================
class World1Atmosphere {
    constructor() {
        this.glyphs = Array.from({ length: 9 }, () => ({
            x: Math.random() * 1200,
            y: 140 + Math.random() * 320,
            speed: 0.35 + Math.random() * 0.45,
            type: Math.random() > 0.5 ? '+' : '◇',
            phase: Math.random() * Math.PI * 2
        }));
    }

    render(ctx, theme, time, deltaCamX, viewWidth, viewHeight, alpha = 1) {
        ctx.save();
        const scanY = ((time * 0.035) % (viewHeight + 80)) - 40;
        const sGrad = ctx.createLinearGradient(0, scanY - 20, 0, scanY + 20);
        sGrad.addColorStop(0, 'rgba(0, 240, 255, 0)');
        sGrad.addColorStop(0.5, 'rgba(0, 240, 255, 0.09)');
        sGrad.addColorStop(1, 'rgba(0, 240, 255, 0)');
        ctx.fillStyle = sGrad;
        ctx.fillRect(0, scanY - 20, viewWidth, 40);

        ctx.font = '11px monospace';
        ctx.fillStyle = theme.planetCol || '#00f0ff';
        this.glyphs.forEach(g => {
            g.x -= (g.speed + deltaCamX * 0.2);
            if (g.x < -30) g.x = viewWidth + 30;
            if (g.x > viewWidth + 40) g.x = -20;

            const flicker = 0.25 + Math.sin(time * 0.003 + g.phase) * 0.2;
            ctx.globalAlpha = Math.max(0, flicker * alpha);
            ctx.fillText(g.type, g.x, g.y + Math.sin(time * 0.002 + g.phase) * 6);
        });
        ctx.restore();
    }
}

class World2Atmosphere {
    constructor() {
        this.spores = Array.from({ length: 14 }, () => ({
            x: Math.random() * 1200,
            y: 160 + Math.random() * 300,
            vx: -0.3 - Math.random() * 0.4,
            size: 2.5 + Math.random() * 2.5,
            rot: Math.random() * Math.PI * 2,
            rotSpd: (Math.random() - 0.5) * 0.02,
            phase: Math.random() * 100
        }));
    }

    render(ctx, theme, time, deltaCamX, viewWidth, viewHeight, FLOOR_Y, alpha = 1) {
        ctx.save();
        const fogH = 80;
        const fogGrad = ctx.createLinearGradient(0, FLOOR_Y - fogH, 0, FLOOR_Y);
        fogGrad.addColorStop(0, 'rgba(52, 211, 153, 0)');
        fogGrad.addColorStop(1, 'rgba(16, 185, 129, 0.15)');
        ctx.fillStyle = fogGrad;
        ctx.beginPath();
        ctx.moveTo(0, FLOOR_Y);
        for (let x = 0; x <= viewWidth; x += 60) {
            const wave = Math.sin(x * 0.008 + time * 0.0015) * 10;
            ctx.lineTo(x, FLOOR_Y - fogH * 0.6 + wave);
        }
        ctx.lineTo(viewWidth, FLOOR_Y);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#34d399';
        this.spores.forEach(s => {
            s.x += s.vx - deltaCamX * 0.25;
            s.y += Math.sin(time * 0.002 + s.phase) * 0.4;
            s.rot += s.rotSpd;
            if (s.x < -30) s.x = viewWidth + 30;
            if (s.x > viewWidth + 40) s.x = -20;

            ctx.save();
            ctx.translate(s.x, s.y);
            ctx.rotate(s.rot);
            const pAlpha = (0.35 + Math.sin(time * 0.003 + s.phase) * 0.25) * alpha;
            ctx.globalAlpha = Math.max(0, pAlpha);
            ctx.beginPath();
            ctx.ellipse(0, 0, s.size * 1.5, s.size * 0.7, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        });
        ctx.restore();
    }
}

class World3Atmosphere {
    constructor() {
        this.cinders = Array.from({ length: 18 }, () => ({
            x: Math.random() * 1200,
            y: 480 - Math.random() * 320,
            speedY: 0.8 + Math.random() * 1.2,
            size: 1.5 + Math.random() * 2,
            amp: 10 + Math.random() * 15,
            phase: Math.random() * Math.PI * 2
        }));
    }

    render(ctx, theme, time, deltaCamX, viewWidth, CEILING_Y, FLOOR_Y, alpha = 1) {
        ctx.save();
        for (let i = 0; i < 3; i++) {
            const hx = ((i * 380 - deltaCamX * 0.15 + time * 0.03) % (viewWidth + 240)) - 100;
            const hGrad = ctx.createLinearGradient(hx, 0, hx + 120, 0);
            hGrad.addColorStop(0, 'rgba(249, 115, 22, 0)');
            hGrad.addColorStop(0.5, 'rgba(239, 68, 68, 0.08)');
            hGrad.addColorStop(1, 'rgba(249, 115, 22, 0)');
            ctx.fillStyle = hGrad;
            ctx.beginPath();
            ctx.moveTo(hx, FLOOR_Y);
            for (let y = FLOOR_Y; y >= CEILING_Y; y -= 40) {
                const shift = Math.sin(y * 0.02 + time * 0.004 + i) * 12;
                ctx.lineTo(hx + shift, y);
            }
            ctx.lineTo(hx + 120, CEILING_Y);
            ctx.lineTo(hx + 120, FLOOR_Y);
            ctx.closePath();
            ctx.fill();
        }

        this.cinders.forEach(c => {
            c.y -= c.speedY;
            c.x += Math.sin(time * 0.003 + c.phase) * 0.7 - deltaCamX * 0.25;
            if (c.y < CEILING_Y) {
                c.y = FLOOR_Y;
                c.x = Math.random() * viewWidth;
            }
            if (c.x < -20) c.x = viewWidth + 20;
            if (c.x > viewWidth + 20) c.x = -10;

            ctx.fillStyle = c.size > 2.2 ? '#fef08a' : (c.size > 1.8 ? '#f97316' : '#ef4444');
            ctx.globalAlpha = (0.4 + Math.sin(time * 0.005 + c.phase) * 0.3) * alpha;
            ctx.beginPath();
            ctx.arc(c.x, c.y, c.size, 0, Math.PI * 2);
            ctx.fill();
        });
        ctx.restore();
    }
}

class World4Atmosphere {
    constructor() {
        this.flares = Array.from({ length: 8 }, () => ({
            x: 50 + Math.random() * 1100,
            y: 160 + Math.random() * 280,
            period: 0.002 + Math.random() * 0.003,
            phase: Math.random() * Math.PI * 2,
            size: 12 + Math.random() * 14
        }));
    }

    render(ctx, theme, time, deltaCamX, viewWidth, viewHeight, alpha = 1) {
        ctx.save();
        for (let c = 0; c < 2; c++) {
            const cx = ((c * 560 + time * 0.02) % (viewWidth + 300)) - 150;
            const cGrad = ctx.createRadialGradient(cx, 300, 20, cx, 300, 160);
            cGrad.addColorStop(0, 'rgba(232, 121, 249, 0.08)');
            cGrad.addColorStop(0.5, 'rgba(192, 132, 252, 0.03)');
            cGrad.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = cGrad;
            ctx.beginPath();
            ctx.ellipse(cx, 300, 180, 80, 0.2, 0, Math.PI * 2);
            ctx.fill();
        }

        this.flares.forEach(f => {
            f.x -= deltaCamX * 0.15;
            if (f.x < -40) f.x = viewWidth + 40;
            if (f.x > viewWidth + 40) f.x = -30;

            const glow = Math.max(0, Math.sin(time * f.period + f.phase));
            if (glow > 0.05) {
                ctx.save();
                ctx.translate(f.x, f.y);
                ctx.globalAlpha = glow * 0.65 * alpha;
                ctx.strokeStyle = '#ffffff';
                ctx.lineWidth = 1.6;

                const len = f.size * glow;
                ctx.beginPath();
                ctx.moveTo(-len, 0); ctx.lineTo(len, 0);
                ctx.moveTo(0, -len); ctx.lineTo(0, len);
                ctx.stroke();

                ctx.fillStyle = '#e879f9';
                ctx.beginPath();
                ctx.arc(0, 0, 2.5, 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();
            }
        });
        ctx.restore();
    }
}

class World5Atmosphere {
    constructor() {
        this.flakes = Array.from({ length: 16 }, () => ({
            x: Math.random() * 1200,
            y: 120 + Math.random() * 340,
            speedX: 2.0 + Math.random() * 1.6,
            speedY: 0.35 + Math.random() * 0.5,
            size: 1.8 + Math.random() * 1.8,
            angle: Math.random() * Math.PI
        }));
    }

    render(ctx, theme, time, deltaCamX, viewWidth, viewHeight, alpha = 1) {
        ctx.save();
        for (let g = 0; g < 3; g++) {
            const gx = ((g * 420 - time * 0.08) % (viewWidth + 400)) - 100;
            const gy = 180 + g * 80;
            const wGrad = ctx.createLinearGradient(gx, gy, gx + 220, gy + 30);
            wGrad.addColorStop(0, 'rgba(224, 242, 254, 0)');
            wGrad.addColorStop(0.5, 'rgba(125, 211, 252, 0.08)');
            wGrad.addColorStop(1, 'rgba(224, 242, 254, 0)');
            ctx.fillStyle = wGrad;
            ctx.fillRect(gx, gy, 240, 16);
        }

        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.2;
        this.flakes.forEach(f => {
            f.x -= (f.speedX + deltaCamX * 0.3);
            f.y += f.speedY;
            f.angle += 0.012;
            if (f.x < -30) {
                f.x = viewWidth + 30;
                f.y = 120 + Math.random() * 340;
            }
            if (f.x > viewWidth + 40) f.x = -20;

            ctx.save();
            ctx.translate(f.x, f.y);
            ctx.rotate(f.angle);
            ctx.globalAlpha = 0.5 * alpha;
            ctx.beginPath();
            ctx.moveTo(-f.size, 0); ctx.lineTo(f.size, 0);
            ctx.moveTo(0, -f.size); ctx.lineTo(0, f.size);
            ctx.stroke();
            ctx.restore();
        });
        ctx.restore();
    }
}

const atmosphericEngines = {
    world1: new World1Atmosphere(),
    world2: new World2Atmosphere(),
    world3: new World3Atmosphere(),
    world4: new World4Atmosphere(),
    world5: new World5Atmosphere(),
    lastCamX: null
};

function renderAtmosphereForWorld(ctx, theme, time, deltaCamX, viewWidth, viewHeight, CEILING_Y, FLOOR_Y, alpha = 1) {
    const id = theme.id || 1;
    if (id === 2) atmosphericEngines.world2.render(ctx, theme, time, deltaCamX, viewWidth, viewHeight, FLOOR_Y, alpha);
    else if (id === 3) atmosphericEngines.world3.render(ctx, theme, time, deltaCamX, viewWidth, CEILING_Y, FLOOR_Y, alpha);
    else if (id === 4) atmosphericEngines.world4.render(ctx, theme, time, deltaCamX, viewWidth, viewHeight, alpha);
    else if (id === 5) atmosphericEngines.world5.render(ctx, theme, time, deltaCamX, viewWidth, viewHeight, alpha);
    else atmosphericEngines.world1.render(ctx, theme, time, deltaCamX, viewWidth, viewHeight, alpha);
}

// =========================================================================
// 4. ДЕКОРАЦІЇ СВІТІВ (НАЛАШТОВАНІ ДЕЛІКАТНІ КІЛЬЦЯ СВІТУ 1)
// =========================================================================
function renderWorld1Scenery(ctx, activeBiome, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y) {
    // Шар 1: Неонова планета з кільцем (0.02x)
    const deepCamX = renderCamX * 0.02;
    const planetScreenX = ((650 - deepCamX) % (viewWidth + 500) + (viewWidth + 500)) % (viewWidth + 500) - 200;

    ctx.save();
    ctx.translate(planetScreenX, 130);
    const haloGrad = ctx.createRadialGradient(0, 0, 30, 0, 0, 110);
    haloGrad.addColorStop(0, activeBiome.planetCol || '#00f0ff');
    haloGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = haloGrad;
    ctx.globalAlpha = 0.35;
    ctx.beginPath(); ctx.arc(0, 0, 110, 0, Math.PI * 2); ctx.fill();

    ctx.globalAlpha = 0.85;
    ctx.fillStyle = activeBiome.skyMid || '#250954';
    ctx.beginPath(); ctx.arc(0, 0, 55, 0, Math.PI * 2); ctx.fill();
    ctx.lineWidth = 2; ctx.strokeStyle = activeBiome.planetCol || '#00f0ff'; ctx.stroke();

    ctx.save();
    ctx.rotate(0.35);
    ctx.lineWidth = 4; ctx.strokeStyle = activeBiome.planetCol || '#00f0ff';
    ctx.beginPath(); ctx.ellipse(0, 0, 95, 20, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.restore();
    ctx.restore();

    // Шар 2: Фоновий магнітний пояс із делікатними технологічними кільцями (0.05x)
    const farX = renderCamX * 0.05;
    const ringInterval = 720;
    const rStart = Math.floor((farX - 200) / ringInterval) * ringInterval;
    for (let rx = rStart; rx < farX + viewWidth + 300; rx += ringInterval) {
        const sx = rx - farX;
        ctx.save();
        ctx.translate(sx, 300);

        // Повільне обертання та делікатний напівпрозорий вигляд (без статичної різкості та ілюзії викривлення)
        const rotTime = time * 0.0003;
        const pulse = 0.16 + Math.sin(time * 0.002 + rx) * 0.05;

        // Зовнішній тонкий ореол (R = 175)
        ctx.save();
        ctx.rotate(rotTime);
        ctx.lineWidth = 4;
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
        ctx.beginPath(); ctx.arc(0, 0, 175, 0, Math.PI * 2); ctx.stroke();
        ctx.restore();

        // Основне технологічне магнітне кільце з пунктиром (R = 125, не торкається підлоги/стелі)
        ctx.save();
        ctx.rotate(rotTime);
        ctx.lineWidth = 2.5;
        ctx.strokeStyle = activeBiome.planetCol || '#00f0ff';
        ctx.globalAlpha = pulse;
        ctx.setLineDash([24, 14]);
        ctx.beginPath(); ctx.arc(0, 0, 125, 0, Math.PI * 2); ctx.stroke();
        ctx.restore();

        // Внутрішнє зустрічне легке кільце (R = 85)
        ctx.save();
        ctx.rotate(-rotTime * 1.5);
        ctx.lineWidth = 1.8;
        ctx.strokeStyle = activeBiome.chainCol || 'rgba(0, 240, 255, 0.35)';
        ctx.globalAlpha = pulse * 0.8;
        ctx.setLineDash([10, 14]);
        ctx.beginPath(); ctx.arc(0, 0, 85, 0, Math.PI * 2); ctx.stroke();
        ctx.restore();

        ctx.restore();
    }

    // Шар 3: Варіативні сектори з підвісними блоками, ланцюгами та шестернями (0.15x)
    const midX = renderCamX * 0.15;
    const sectorWidth = 650;
    const sStart = Math.floor((midX - 350) / sectorWidth) * sectorWidth;
    const sEnd = Math.floor((midX + viewWidth + 350) / sectorWidth) * sectorWidth;

    for (let sx = sStart; sx <= sEnd; sx += sectorWidth) {
        const screenX = sx - midX;
        const sectorIndex = Math.abs(Math.floor(sx / sectorWidth)) % 3;

        if (sectorIndex === 0) {
            ctx.save();
            ctx.translate(screenX + 180, 240);
            ctx.fillStyle = 'rgba(20, 10, 45, 0.75)';
            ctx.beginPath(); ctx.roundRect(-14, -40, 28, 90, 6); ctx.fill();
            ctx.lineWidth = 2; ctx.strokeStyle = activeBiome.chainCol || '#00f0ff'; ctx.stroke();

            const pulse = 0.75 + Math.sin(time * 0.005) * 0.25;
            ctx.fillStyle = activeBiome.planetCol || '#00f0ff';
            ctx.globalAlpha = pulse;
            ctx.beginPath(); ctx.arc(0, -40, 14, 0, Math.PI * 2); ctx.fill();
            ctx.globalAlpha = 1.0;

            drawWorld1Chain(ctx, { x: -140, y: -90 }, { x: -60, y: -30 }, { x: 0, y: -40 }, activeBiome.chainCol);
            ctx.restore();
        } else if (sectorIndex === 1) {
            ctx.save();
            ctx.translate(screenX + 120, 220);
            ctx.rotate(time * 0.0009 + sx);
            drawWorld1Gear(ctx, 68, 50, 8, activeBiome.gearCol || '#3b82f6', 'rgba(0,0,0,0.5)', activeBiome.skyTop);
            ctx.restore();

            ctx.save();
            ctx.translate(screenX + 225, 275);
            ctx.rotate(-time * 0.0014 + sx);
            drawWorld1Gear(ctx, 46, 32, 6, activeBiome.gearCol || '#3b82f6', 'rgba(0,0,0,0.5)', activeBiome.skyTop);
            ctx.restore();

            drawWorld1Chain(ctx, { x: screenX + 30, y: 170 }, { x: screenX + 180, y: 235 }, { x: screenX + 340, y: 175 }, activeBiome.chainCol);
        } else {
            ctx.save();
            ctx.translate(screenX + 140, 200);
            ctx.fillStyle = 'rgba(15, 8, 38, 0.85)';
            ctx.fillRect(-40, 0, 80, 140);
            ctx.lineWidth = 2; ctx.strokeStyle = activeBiome.chainCol || '#00f0ff';
            ctx.strokeRect(-40, 0, 80, 140);

            for (let r = 0; r < 4; r++) {
                for (let c = 0; c < 2; c++) {
                    const lit = (Math.sin(time * 0.003 + r * 2 + c) > 0);
                    ctx.fillStyle = lit ? (activeBiome.planetCol || '#00f0ff') : 'rgba(255,255,255,0.08)';
                    ctx.fillRect(-26 + c * 32, 16 + r * 28, 20, 14);
                }
            }
            drawWorld1Chain(ctx, { x: -120, y: -20 }, { x: -60, y: 20 }, { x: -40, y: 0 }, activeBiome.chainCol);
            ctx.restore();
        }
    }
}

function renderWorld2Scenery(ctx, activeBiome, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y) {
    const deepCamX = renderCamX * 0.02;
    const moonX = ((680 - deepCamX) % (viewWidth + 500) + (viewWidth + 500)) % (viewWidth + 500) - 200;
    ctx.save();
    ctx.translate(moonX, 130);
    const mGlow = ctx.createRadialGradient(0, 0, 20, 0, 0, 120);
    mGlow.addColorStop(0, 'rgba(52, 211, 153, 0.45)');
    mGlow.addColorStop(0.6, 'rgba(16, 185, 129, 0.12)');
    mGlow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = mGlow;
    ctx.beginPath(); ctx.arc(0, 0, 120, 0, Math.PI * 2); ctx.fill();

    ctx.fillStyle = '#022c22';
    ctx.beginPath(); ctx.arc(0, 0, 52, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#34d399'; ctx.lineWidth = 2.5; ctx.stroke();

    ctx.strokeStyle = 'rgba(52, 211, 153, 0.3)'; ctx.lineWidth = 1.2;
    for (let l = -35; l <= 35; l += 14) {
        ctx.beginPath(); ctx.moveTo(-35, l); ctx.lineTo(35, l); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(l, -35); ctx.lineTo(l, 35); ctx.stroke();
    }

    ctx.save();
    ctx.rotate(-0.35);
    ctx.strokeStyle = 'rgba(52, 211, 153, 0.5)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.ellipse(0, 0, 88, 22, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.restore();
    ctx.restore();

    const farX = renderCamX * 0.05;
    for (let f = -150; f < viewWidth + 300; f += 220) {
        const screenFarX = ((f - farX) % (viewWidth + 400) + (viewWidth + 400)) % (viewWidth + 400) - 150;
        ctx.fillStyle = 'rgba(2, 44, 34, 0.5)';
        ctx.beginPath();
        ctx.arc(screenFarX, FLOOR_Y - 140, 75, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = 'rgba(52, 211, 153, 0.15)'; ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(screenFarX, FLOOR_Y); ctx.lineTo(screenFarX, FLOOR_Y - 140);
        ctx.stroke();
    }

    const midX = renderCamX * 0.15;
    const sectorWidth = 780;
    const sStart = Math.floor((midX - 350) / sectorWidth) * sectorWidth;
    const sEnd = Math.floor((midX + viewWidth + 350) / sectorWidth) * sectorWidth;

    for (let sx = sStart; sx <= sEnd; sx += sectorWidth) {
        const screenX = sx - midX;
        const sectorIndex = Math.abs(Math.floor(sx / sectorWidth)) % 3;

        if (sectorIndex === 0) {
            ctx.save();
            ctx.translate(screenX + 180, 0);
            ctx.fillStyle = '#03251d';
            ctx.strokeStyle = '#059669'; ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(-45, CEILING_Y - 20);
            ctx.bezierCurveTo(-15, 230, -35, 340, -60, FLOOR_Y + 18);
            ctx.lineTo(60, FLOOR_Y + 18);
            ctx.bezierCurveTo(35, 340, 15, 230, 45, CEILING_Y - 20);
            ctx.closePath();
            ctx.fill(); ctx.stroke();

            const p1 = 0.5 + Math.sin(time * 0.005 + sx) * 0.5;
            ctx.strokeStyle = `rgba(52, 211, 153, ${0.4 + p1 * 0.5})`;
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(-15, CEILING_Y); ctx.quadraticCurveTo(0, 300, -25, FLOOR_Y);
            ctx.moveTo(15, CEILING_Y); ctx.quadraticCurveTo(0, 300, 25, FLOOR_Y);
            ctx.stroke();

            ctx.fillStyle = 'rgba(6, 78, 59, 0.7)';
            ctx.beginPath();
            ctx.arc(-70, 220, 50, 0, Math.PI * 2);
            ctx.arc(70, 250, 55, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#10b981'; ctx.lineWidth = 2; ctx.stroke();

            drawCyberBioVine(ctx, { x: -160, y: CEILING_Y + 20 }, { x: -70, y: 220 }, { x: -45, y: 260 }, '#059669', '#34d399', time);
            ctx.restore();
        } else if (sectorIndex === 1) {
            ctx.save();
            ctx.translate(screenX + 170, FLOOR_Y);
            const mushrooms = [
                { x: -70, h: 180, r: 52, col: '#10b981', glow: '#34d399' },
                { x: 30, h: 125, r: 40, col: '#059669', glow: '#6ee7b7' },
                { x: 100, h: 80, r: 30, col: '#047857', glow: '#a7f3d0' }
            ];
            mushrooms.forEach(m => {
                ctx.strokeStyle = '#022c22'; ctx.lineWidth = 14; ctx.lineCap = 'round';
                ctx.beginPath();
                ctx.moveTo(m.x, 0); ctx.quadraticCurveTo(m.x - 8, -m.h * 0.5, m.x, -m.h);
                ctx.stroke();
                ctx.strokeStyle = m.col; ctx.lineWidth = 3; ctx.stroke();

                ctx.fillStyle = m.col;
                ctx.shadowColor = m.glow; ctx.shadowBlur = 14;
                ctx.beginPath();
                ctx.ellipse(m.x, -m.h, m.r, m.r * 0.55, 0, Math.PI, 0);
                ctx.closePath();
                ctx.fill();
                ctx.shadowBlur = 0;
                ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.8; ctx.stroke();

                ctx.fillStyle = '#ffffff';
                ctx.beginPath();
                ctx.arc(m.x - m.r * 0.4, -m.h - m.r * 0.2, 3, 0, Math.PI * 2);
                ctx.arc(m.x + m.r * 0.3, -m.h - m.r * 0.25, 4, 0, Math.PI * 2);
                ctx.fill();
            });
            drawCyberBioVine(ctx, { x: -140, y: -60 }, { x: -40, y: -190 }, { x: 80, y: -130 }, '#047857', '#34d399', time);
            ctx.restore();
        } else {
            ctx.save();
            ctx.translate(screenX + 160, FLOOR_Y);
            ctx.fillStyle = '#02231c';
            ctx.strokeStyle = '#10b981'; ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.moveTo(-60, 0); ctx.lineTo(-25, -200); ctx.lineTo(25, -200); ctx.lineTo(60, 0);
            ctx.closePath();
            ctx.fill(); ctx.stroke();

            const lev = Math.sin(time * 0.004) * 8;
            ctx.fillStyle = '#34d399';
            ctx.shadowColor = '#34d399'; ctx.shadowBlur = 16;
            ctx.beginPath();
            ctx.moveTo(0, -250 + lev); ctx.lineTo(16, -225 + lev); ctx.lineTo(0, -205 + lev); ctx.lineTo(-16, -225 + lev);
            ctx.closePath(); ctx.fill();
            ctx.shadowBlur = 0;

            for (let r = 0; r < 4; r++) {
                const lit = Math.sin(time * 0.003 + r * 1.5 + sx) > 0;
                ctx.fillStyle = lit ? '#6ee7b7' : 'rgba(52, 211, 153, 0.15)';
                ctx.fillRect(-15, -170 + r * 40, 30, 8);
            }
            drawCyberBioVine(ctx, { x: -120, y: -20 }, { x: -40, y: -180 }, { x: 25, y: -200 }, '#059669', '#6ee7b7', time);
            ctx.restore();
        }
    }
}

function renderWorld3Scenery(ctx, activeBiome, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y) {
    const deepCamX = renderCamX * 0.02;
    const sunX = ((640 - deepCamX) % (viewWidth + 500) + (viewWidth + 500)) % (viewWidth + 500) - 200;
    ctx.save();
    ctx.translate(sunX, 130);
    const sGrad = ctx.createRadialGradient(0, 0, 25, 0, 0, 140);
    sGrad.addColorStop(0, '#ff3b00');
    sGrad.addColorStop(0.5, 'rgba(239, 68, 68, 0.45)');
    sGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = sGrad;
    ctx.beginPath(); ctx.arc(0, 0, 140, 0, Math.PI * 2); ctx.fill();

    ctx.fillStyle = '#1c0205';
    ctx.beginPath(); ctx.arc(0, 0, 60, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#f97316'; ctx.lineWidth = 3; ctx.stroke();

    ctx.strokeStyle = '#ef4444'; ctx.lineWidth = 2.5;
    for (let a = 0; a < 6; a++) {
        const ang = a * (Math.PI / 3) + time * 0.001;
        ctx.beginPath();
        ctx.moveTo(Math.cos(ang) * 60, Math.sin(ang) * 60);
        ctx.lineTo(Math.cos(ang) * 85, Math.sin(ang) * 85);
        ctx.stroke();
    }
    ctx.restore();

    const farX = renderCamX * 0.05;
    for (let f = -180; f < viewWidth + 300; f += 240) {
        const sx = ((f - farX) % (viewWidth + 400) + (viewWidth + 400)) % (viewWidth + 400) - 150;
        ctx.fillStyle = '#2d060a';
        ctx.beginPath();
        ctx.moveTo(sx - 120, FLOOR_Y);
        ctx.lineTo(sx, FLOOR_Y - 170);
        ctx.lineTo(sx + 120, FLOOR_Y);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = 'rgba(249, 115, 22, 0.35)'; ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(sx, FLOOR_Y - 170); ctx.lineTo(sx - 20, FLOOR_Y - 70); ctx.lineTo(sx, FLOOR_Y);
        ctx.stroke();
    }

    const midX = renderCamX * 0.15;
    const sectorWidth = 780;
    const sStart = Math.floor((midX - 350) / sectorWidth) * sectorWidth;
    const sEnd = Math.floor((midX + viewWidth + 350) / sectorWidth) * sectorWidth;

    for (let sx = sStart; sx <= sEnd; sx += sectorWidth) {
        const screenX = sx - midX;
        const sectorIndex = Math.abs(Math.floor(sx / sectorWidth)) % 3;

        if (sectorIndex === 0) {
            ctx.save();
            ctx.translate(screenX + 180, FLOOR_Y);
            ctx.fillStyle = '#1c0407';
            ctx.beginPath();
            ctx.moveTo(-160, 0); ctx.lineTo(-45, -185); ctx.lineTo(45, -185); ctx.lineTo(140, 0);
            ctx.closePath();
            ctx.fill();
            ctx.strokeStyle = '#7f1d1d'; ctx.lineWidth = 3; ctx.stroke();

            ctx.fillStyle = '#ff7a00';
            ctx.beginPath(); ctx.ellipse(0, -185, 45, 14, 0, 0, Math.PI * 2); ctx.fill();

            ctx.strokeStyle = '#ef4444'; ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.moveTo(-10, -180); ctx.lineTo(-30, -100); ctx.lineTo(-12, -40); ctx.lineTo(-25, 0);
            ctx.moveTo(12, -180); ctx.lineTo(35, -90); ctx.lineTo(20, -30); ctx.lineTo(38, 0);
            ctx.stroke();

            const erupt = Math.sin(time * 0.008 + sx) > 0.15;
            if (erupt) {
                ctx.fillStyle = '#fef08a';
                ctx.shadowColor = '#ea580c'; ctx.shadowBlur = 18;
                ctx.beginPath();
                ctx.moveTo(-16, -185);
                ctx.lineTo(0, -255 - Math.sin(time * 0.015) * 25);
                ctx.lineTo(16, -185);
                ctx.closePath(); ctx.fill();
                ctx.shadowBlur = 0;
            }
            ctx.restore();
        } else if (sectorIndex === 1) {
            ctx.save();
            ctx.translate(screenX + 160, FLOOR_Y);
            ctx.fillStyle = '#180306';
            ctx.strokeStyle = '#991b1b'; ctx.lineWidth = 2.5;

            const pillars = [
                { x: -90, w: 45, h: 90 }, { x: -45, w: 50, h: 195 },
                { x: 5, w: 45, h: 140 }, { x: 50, w: 50, h: 80 }
            ];
            pillars.forEach(p => {
                ctx.fillRect(p.x, -p.h, p.w, p.h);
                ctx.strokeRect(p.x, -p.h, p.w, p.h);

                ctx.fillStyle = '#ff7a00';
                ctx.fillRect(p.x, -p.h - 4, p.w, 6);
                ctx.fillStyle = '#180306';

                ctx.strokeStyle = '#ef4444'; ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.moveTo(p.x + p.w * 0.5, -p.h);
                ctx.lineTo(p.x + p.w * 0.3, -p.h * 0.5);
                ctx.lineTo(p.x + p.w * 0.7, 0);
                ctx.stroke();
                ctx.strokeStyle = '#991b1b'; ctx.lineWidth = 2.5;
            });
            ctx.restore();
        } else {
            ctx.save();
            ctx.translate(screenX + 150, FLOOR_Y);
            ctx.fillStyle = '#220509';
            ctx.strokeStyle = '#7f1d1d'; ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(-110, 0); ctx.bezierCurveTo(-110, -220, 110, -220, 110, 0);
            ctx.lineTo(70, 0); ctx.bezierCurveTo(70, -150, -70, -150, -70, 0);
            ctx.closePath();
            ctx.fill(); ctx.stroke();

            ctx.fillStyle = '#f97316';
            ctx.beginPath();
            ctx.moveTo(-20, -150); ctx.lineTo(-10, -115); ctx.lineTo(0, -150);
            ctx.moveTo(10, -150); ctx.lineTo(20, -125); ctx.lineTo(30, -150);
            ctx.fill();

            ctx.fillStyle = '#ff7a00';
            ctx.fillRect(-70, -10, 140, 10);
            ctx.restore();
        }
    }
}

function renderWorld4Scenery(ctx, activeBiome, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y) {
    const deepCamX = renderCamX * 0.02;
    const geodeX = ((630 - deepCamX) % (viewWidth + 500) + (viewWidth + 500)) % (viewWidth + 500) - 200;
    ctx.save();
    ctx.translate(geodeX, 140);
    const cGrad = ctx.createRadialGradient(0, 0, 30, 0, 0, 140);
    cGrad.addColorStop(0, 'rgba(232, 121, 249, 0.5)');
    cGrad.addColorStop(0.6, 'rgba(192, 132, 252, 0.15)');
    cGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = cGrad;
    ctx.beginPath(); ctx.arc(0, 0, 140, 0, Math.PI * 2); ctx.fill();

    ctx.fillStyle = '#3b0764';
    ctx.strokeStyle = '#e879f9'; ctx.lineWidth = 2.5;
    ctx.beginPath();
    for (let a = 0; a < 8; a++) {
        const ang = a * (Math.PI / 4);
        const r = a % 2 === 0 ? 58 : 44;
        const cx = Math.cos(ang) * r, cy = Math.sin(ang) * r;
        if (a === 0) ctx.moveTo(cx, cy); else ctx.lineTo(cx, cy);
    }
    ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.restore();

    const farX = renderCamX * 0.05;
    ctx.save();
    ctx.rotate(-0.2);
    for (let r = -200; r < viewWidth + 400; r += 260) {
        const rayX = ((r - farX) % (viewWidth + 400) + (viewWidth + 400)) % (viewWidth + 400) - 150;
        const rGrad = ctx.createLinearGradient(rayX, 0, rayX + 60, FLOOR_Y);
        rGrad.addColorStop(0, 'rgba(232, 121, 249, 0.14)');
        rGrad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = rGrad;
        ctx.fillRect(rayX, 0, 70, FLOOR_Y * 1.5);
    }
    ctx.restore();

    const midX = renderCamX * 0.15;
    const sectorWidth = 780;
    const sStart = Math.floor((midX - 350) / sectorWidth) * sectorWidth;
    const sEnd = Math.floor((midX + viewWidth + 350) / sectorWidth) * sectorWidth;

    for (let sx = sStart; sx <= sEnd; sx += sectorWidth) {
        const screenX = sx - midX;
        const sectorIndex = Math.abs(Math.floor(sx / sectorWidth)) % 3;

        if (sectorIndex === 0) {
            ctx.save();
            ctx.translate(screenX + 175, 0);

            ctx.fillStyle = '#581c87';
            ctx.beginPath();
            ctx.moveTo(-38, CEILING_Y - 14); ctx.lineTo(-8, CEILING_Y + 115); ctx.lineTo(8, CEILING_Y + 135); ctx.lineTo(32, CEILING_Y - 14);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = '#c084fc'; ctx.lineWidth = 2.5; ctx.stroke();

            ctx.fillStyle = '#e879f9';
            ctx.beginPath();
            ctx.moveTo(-8, CEILING_Y + 115); ctx.lineTo(0, CEILING_Y - 14); ctx.lineTo(8, CEILING_Y + 135);
            ctx.closePath(); ctx.fill();

            ctx.fillStyle = '#3b0764';
            ctx.beginPath();
            ctx.moveTo(15, FLOOR_Y + 18); ctx.lineTo(60, FLOOR_Y - 130); ctx.lineTo(95, FLOOR_Y + 18);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = '#a855f7'; ctx.lineWidth = 2.5; ctx.stroke();

            ctx.fillStyle = '#f3e8ff';
            ctx.beginPath();
            ctx.moveTo(50, FLOOR_Y + 18); ctx.lineTo(60, FLOOR_Y - 130); ctx.lineTo(75, FLOOR_Y + 18);
            ctx.closePath(); ctx.fill();
            ctx.restore();
        } else if (sectorIndex === 1) {
            ctx.save();
            ctx.translate(screenX + 160, 240);
            const shards = [
                { x: -60, y: -40, s: 28, r: 0.2 }, { x: 30, y: 15, s: 38, r: -0.3 }, { x: 85, y: -50, s: 22, r: 0.4 }
            ];
            shards.forEach(sh => {
                const bob = Math.sin(time * 0.004 + sh.x) * 10;
                ctx.save();
                ctx.translate(sh.x, sh.y + bob);
                ctx.rotate(sh.r);
                ctx.fillStyle = '#7e22ce';
                ctx.shadowColor = '#e879f9'; ctx.shadowBlur = 14;
                ctx.beginPath();
                ctx.moveTo(0, -sh.s); ctx.lineTo(sh.s * 0.6, 0); ctx.lineTo(0, sh.s); ctx.lineTo(-sh.s * 0.6, 0);
                ctx.closePath(); ctx.fill();
                ctx.shadowBlur = 0;
                ctx.strokeStyle = '#f5d0fe'; ctx.lineWidth = 2; ctx.stroke();
                ctx.restore();
            });

            ctx.strokeStyle = 'rgba(232, 121, 249, 0.6)'; ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(-60, -40); ctx.lineTo(30, 15); ctx.lineTo(85, -50);
            ctx.stroke();
            ctx.restore();
        } else {
            ctx.save();
            ctx.translate(screenX + 160, 0);
            for (let c = -50; c <= 50; c += 35) {
                const sLen = 70 + Math.abs(c);
                ctx.fillStyle = '#4c1d95';
                ctx.beginPath();
                ctx.moveTo(c - 14, CEILING_Y - 14); ctx.lineTo(c, CEILING_Y + sLen); ctx.lineTo(c + 14, CEILING_Y - 14);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = '#c084fc'; ctx.lineWidth = 2; ctx.stroke();
            }
            for (let c = -40; c <= 40; c += 40) {
                ctx.fillStyle = '#2e1065';
                ctx.beginPath();
                ctx.moveTo(c - 16, FLOOR_Y + 18); ctx.lineTo(c, FLOOR_Y - 90); ctx.lineTo(c + 16, FLOOR_Y + 18);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = '#e879f9'; ctx.lineWidth = 2; ctx.stroke();
            }
            ctx.restore();
        }
    }
}

function renderWorld5Scenery(ctx, activeBiome, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y) {
    ctx.save();
    for (let a = 0; a < 3; a++) {
        ctx.beginPath();
        const aAlpha = 0.18 + Math.sin(time * 0.003 + a) * 0.08;
        ctx.fillStyle = a === 0 ? `rgba(56, 189, 248, ${aAlpha})` : `rgba(52, 211, 153, ${aAlpha})`;
        ctx.moveTo(0, 50 + a * 35);
        for (let x = 0; x <= viewWidth; x += 60) {
            const waveY = 60 + a * 35 + Math.sin(x * 0.006 + time * 0.002 + a * 1.5) * 32;
            ctx.lineTo(x, waveY);
        }
        ctx.lineTo(viewWidth, 0); ctx.lineTo(0, 0);
        ctx.closePath(); ctx.fill();
    }
    ctx.restore();

    const deepCamX = renderCamX * 0.02;
    const iceMoonX = ((660 - deepCamX) % (viewWidth + 500) + (viewWidth + 500)) % (viewWidth + 500) - 200;
    ctx.save();
    ctx.translate(iceMoonX, 125);
    const halo = ctx.createRadialGradient(0, 0, 15, 0, 0, 95);
    halo.addColorStop(0, 'rgba(224, 242, 254, 0.45)');
    halo.addColorStop(0.6, 'rgba(56, 189, 248, 0.12)');
    halo.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = halo;
    ctx.beginPath(); ctx.arc(0, 0, 95, 0, Math.PI * 2); ctx.fill();

    ctx.fillStyle = '#072f4a';
    ctx.beginPath(); ctx.arc(0, 0, 46, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#7dd3fc'; ctx.lineWidth = 2.5; ctx.stroke();
    ctx.restore();

    const farX = renderCamX * 0.05;
    for (let f = -160; f < viewWidth + 300; f += 220) {
        const sx = ((f - farX) % (viewWidth + 400) + (viewWidth + 400)) % (viewWidth + 400) - 150;
        ctx.fillStyle = '#052238';
        ctx.beginPath();
        ctx.moveTo(sx - 90, FLOOR_Y); ctx.lineTo(sx, FLOOR_Y - 150); ctx.lineTo(sx + 90, FLOOR_Y);
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = 'rgba(125, 211, 252, 0.3)'; ctx.lineWidth = 2; ctx.stroke();
    }

    const midX = renderCamX * 0.15;
    const sectorWidth = 780;
    const sStart = Math.floor((midX - 350) / sectorWidth) * sectorWidth;
    const sEnd = Math.floor((midX + viewWidth + 350) / sectorWidth) * sectorWidth;

    for (let sx = sStart; sx <= sEnd; sx += sectorWidth) {
        const screenX = sx - midX;
        const sectorIndex = Math.abs(Math.floor(sx / sectorWidth)) % 3;

        if (sectorIndex === 0) {
            ctx.save();
            ctx.translate(screenX + 180, FLOOR_Y);
            ctx.fillStyle = '#072f4a';
            ctx.beginPath();
            ctx.moveTo(-110, 0); ctx.lineTo(-15, -185); ctx.lineTo(-15, 0);
            ctx.closePath(); ctx.fill();

            ctx.fillStyle = '#0284c7';
            ctx.beginPath();
            ctx.moveTo(0, -185); ctx.lineTo(95, 0); ctx.lineTo(0, 0);
            ctx.closePath(); ctx.fill();

            ctx.strokeStyle = '#7dd3fc'; ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(-110, 0); ctx.lineTo(-15, -185); ctx.lineTo(0, 0); ctx.lineTo(0, -185); ctx.lineTo(95, 0);
            ctx.stroke();

            ctx.strokeStyle = '#e0f2fe'; ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(-8, -185); ctx.lineTo(-8, 0);
            ctx.stroke();
            ctx.restore();
        } else if (sectorIndex === 1) {
            ctx.save();
            ctx.translate(screenX + 160, 0);
            ctx.fillStyle = '#0c4a6e';
            ctx.strokeStyle = '#38bdf8'; ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(-100, CEILING_Y - 14);
            ctx.bezierCurveTo(-40, CEILING_Y + 110, 40, CEILING_Y + 110, 100, CEILING_Y - 14);
            ctx.stroke();

            const icicles = [-70, -45, -20, 0, 20, 45, 70];
            icicles.forEach((ix, idx) => {
                const len = 35 + (idx % 3) * 25;
                ctx.fillStyle = '#e0f2fe';
                ctx.beginPath();
                ctx.moveTo(ix - 6, CEILING_Y + 30); ctx.lineTo(ix, CEILING_Y + 30 + len); ctx.lineTo(ix + 6, CEILING_Y + 30);
                ctx.closePath(); ctx.fill();
                ctx.strokeStyle = '#7dd3fc'; ctx.lineWidth = 1.5; ctx.stroke();
            });
            ctx.restore();
        } else {
            ctx.save();
            ctx.translate(screenX + 160, FLOOR_Y);
            ctx.fillStyle = '#072f4a';
            ctx.strokeStyle = '#38bdf8'; ctx.lineWidth = 2.5;
            ctx.beginPath();
            ctx.moveTo(-35, 0); ctx.lineTo(-20, -190); ctx.lineTo(20, -190); ctx.lineTo(35, 0);
            ctx.closePath(); ctx.fill(); ctx.stroke();

            ctx.fillStyle = '#e0f2fe';
            ctx.beginPath();
            ctx.moveTo(-24, -190); ctx.lineTo(0, -215); ctx.lineTo(24, -190);
            ctx.closePath(); ctx.fill();

            for (let r = 0; r < 4; r++) {
                const lit = Math.sin(time * 0.003 + r * 1.8 + sx) > 0;
                ctx.fillStyle = lit ? '#7dd3fc' : 'rgba(125, 211, 252, 0.15)';
                ctx.fillRect(-12, -160 + r * 35, 24, 7);
            }
            ctx.restore();
        }
    }
}

function renderBiomeScenery(ctx, theme, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y) {
    const id = theme.id || 1;
    if (id === 2) renderWorld2Scenery(ctx, theme, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);
    else if (id === 3) renderWorld3Scenery(ctx, theme, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);
    else if (id === 4) renderWorld4Scenery(ctx, theme, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);
    else if (id === 5) renderWorld5Scenery(ctx, theme, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);
    else renderWorld1Scenery(ctx, theme, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);
}

// =========================================================================
// 5. ГОЛОВНІ РЕНДЕРЕРИ (ФОН І РЕЙКИ З РОЗРИВАМИ)
// =========================================================================
function renderBackground(ctx, activeBiome, time, renderCamX, viewWidth, viewHeight, CEILING_Y, FLOOR_Y, transitionData) {
    ctx.save();

    const rawDelta = atmosphericEngines.lastCamX !== null ? (renderCamX - atmosphericEngines.lastCamX) : 0;
    const deltaCamX = Math.max(-35, Math.min(35, rawDelta));
    atmosphericEngines.lastCamX = renderCamX;

    const isTrans = transitionData && transitionData.isTransitioning && transitionData.toBiome;
    const effectiveTheme = isTrans
        ? interpolateTheme(transitionData.fromBiome, transitionData.toBiome, transitionData.progress)
        : activeBiome;

    // 1. Градієнт неба
    const bgGrad = ctx.createLinearGradient(0, 0, viewWidth, viewHeight);
    bgGrad.addColorStop(0, effectiveTheme.skyTop || "#12052b");
    bgGrad.addColorStop(0.5, effectiveTheme.skyMid || "#250954");
    bgGrad.addColorStop(1, effectiveTheme.skyBot || "#082a3d");
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, viewWidth, viewHeight);

    // 2. М'яка хвиля світла
    if (isTrans) {
        const p = transitionData.progress;
        const waveCenter = viewWidth * (1.3 - p * 1.6);
        const waveGrad = ctx.createLinearGradient(waveCenter - 320, 0, waveCenter + 320, 0);
        waveGrad.addColorStop(0, 'rgba(0,0,0,0)');
        waveGrad.addColorStop(0.5, lerpAnyColor(transitionData.toBiome.skyMid, '#ffffff', 0.12));
        waveGrad.addColorStop(1, 'rgba(0,0,0,0)');

        ctx.save();
        ctx.globalAlpha = 0.3 * Math.sin(p * Math.PI);
        ctx.fillStyle = waveGrad;
        ctx.fillRect(0, 0, viewWidth, viewHeight);
        ctx.restore();
    }

    // 3. Декорації
    if (isTrans) {
        const p = transitionData.progress;
        const smoothP = p * p * (3 - 2 * p);

        ctx.save();
        ctx.globalAlpha = Math.max(0, 1 - smoothP);
        renderBiomeScenery(ctx, transitionData.fromBiome, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);
        ctx.restore();

        ctx.save();
        ctx.globalAlpha = Math.min(1, smoothP);
        renderBiomeScenery(ctx, transitionData.toBiome, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);
        ctx.restore();

        renderAtmosphereForWorld(ctx, transitionData.fromBiome, time, deltaCamX, viewWidth, viewHeight, CEILING_Y, FLOOR_Y, 1 - p);
        renderAtmosphereForWorld(ctx, transitionData.toBiome, time, deltaCamX, viewWidth, viewHeight, CEILING_Y, FLOOR_Y, p);
    } else {
        renderBiomeScenery(ctx, activeBiome, time, renderCamX, viewWidth, CEILING_Y, FLOOR_Y);
        renderAtmosphereForWorld(ctx, activeBiome, time, deltaCamX, viewWidth, viewHeight, CEILING_Y, FLOOR_Y, 1.0);
    }

    ctx.restore();
}

function getSolidRailSegments(startX, endX, gaps) {
    let segments = [{ x1: startX, x2: endX }];
    for (const g of gaps) {
        const gx1 = g.x;
        const gx2 = g.x + g.width;
        const next = [];
        for (const seg of segments) {
            if (gx2 <= seg.x1 || gx1 >= seg.x2) {
                next.push(seg);
            } else {
                if (gx1 > seg.x1) next.push({ x1: seg.x1, x2: gx1 });
                if (gx2 < seg.x2) next.push({ x1: gx2, x2: seg.x2 });
            }
        }
        segments = next;
    }
    return segments;
}

function renderTracks(ctx, activeBiome, renderCamX, viewWidth, viewHeight, CEILING_Y, FLOOR_Y, transitionData, obstacles = []) {
    ctx.save();

    const isTrans = transitionData && transitionData.isTransitioning && transitionData.toBiome;
    const effectiveTheme = isTrans
        ? interpolateTheme(transitionData.fromBiome, transitionData.toBiome, transitionData.progress)
        : activeBiome;

    const visibleX1 = renderCamX - 40;
    const visibleX2 = renderCamX + viewWidth + 40;

    const ceilGaps = (obstacles || []).filter(o => o.type === 'RAIL_GAP' && o.rail === 'CEIL');
    const floorGaps = (obstacles || []).filter(o => o.type === 'RAIL_GAP' && o.rail === 'FLOOR');

    const ceilSegments = getSolidRailSegments(visibleX1, visibleX2, ceilGaps);
    const floorSegments = getSolidRailSegments(visibleX1, visibleX2, floorGaps);

    ctx.translate(-renderCamX, 0);

    // 1. СЕГМЕНТИ СТЕЛІ
    for (let seg of ceilSegments) {
        const w = seg.x2 - seg.x1;
        if (w <= 0) continue;

        ctx.fillStyle = '#061325';
        ctx.fillRect(seg.x1, 0, w, CEILING_Y - 14);

        const ceilGrad = ctx.createLinearGradient(0, CEILING_Y - 16, 0, CEILING_Y);
        ceilGrad.addColorStop(0, effectiveTheme.railCeilDark);
        ceilGrad.addColorStop(1, effectiveTheme.railCeil);
        ctx.fillStyle = ceilGrad;
        ctx.fillRect(seg.x1, CEILING_Y - 14, w, 14);

        ctx.fillStyle = '#ffffff';
        ctx.fillRect(seg.x1, CEILING_Y - 4, w, 4);
    }

    for (let g of ceilGaps) {
        if (g.x + g.width >= visibleX1 && g.x <= visibleX2) {
            ctx.fillStyle = '#ef4444';
            ctx.fillRect(g.x - 6, CEILING_Y - 14, 6, 14);
            ctx.fillRect(g.x + g.width, CEILING_Y - 14, 6, 14);
        }
    }

    // 2. СЕГМЕНТИ ПІДЛОГИ
    for (let seg of floorSegments) {
        const w = seg.x2 - seg.x1;
        if (w <= 0) continue;

        const floorGrad = ctx.createLinearGradient(0, FLOOR_Y, 0, FLOOR_Y + 18);
        floorGrad.addColorStop(0, effectiveTheme.railFloor);
        floorGrad.addColorStop(1, effectiveTheme.railFloorDark);

        ctx.fillStyle = floorGrad;
        ctx.fillRect(seg.x1, FLOOR_Y, w, 18);
        ctx.lineWidth = 3;
        ctx.strokeStyle = effectiveTheme.railFloorDark;
        ctx.strokeRect(seg.x1, FLOOR_Y, w, 18);

        ctx.fillStyle = '#fef08a';
        const dashSpacing = 36;
        const startDash = Math.floor(seg.x1 / dashSpacing) * dashSpacing;
        for (let dx = startDash; dx < seg.x2 - 16; dx += dashSpacing) {
            if (dx >= seg.x1) {
                ctx.beginPath();
                ctx.roundRect(dx, FLOOR_Y + 5, 20, 7, 3);
                ctx.fill();
            }
        }

        ctx.fillStyle = '#110c28';
        ctx.fillRect(seg.x1, FLOOR_Y + 18, w, viewHeight - (FLOOR_Y + 18));
    }

    for (let g of floorGaps) {
        if (g.x + g.width >= visibleX1 && g.x <= visibleX2) {
            ctx.fillStyle = '#ef4444';
            ctx.fillRect(g.x - 6, FLOOR_Y, 6, 18);
            ctx.fillRect(g.x + g.width, FLOOR_Y, 6, 18);
        }
    }

    ctx.restore();
}

window.renderBackground = renderBackground;
window.renderTracks = renderTracks;