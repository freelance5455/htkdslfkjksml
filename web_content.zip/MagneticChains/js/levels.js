const WORLD_THEMES = [
    { id: 1, name: "Магнітний Неон", skyTop: "#12052b", skyMid: "#250954", skyBot: "#082a3d", railFloor: "#ff7a00", railFloorDark: "#c2410c", railCeil: "#00f0ff", railCeilDark: "#0284c7", chainCol: "rgba(0, 240, 255, 0.45)", gearCol: "rgba(168, 85, 247, 0.35)", planetCol: "#00f0ff", skinName: "Магнітний Бот", trailCol: "#00f0ff" },
    { id: 2, name: "Смарагдовий Кібер-Гай", skyTop: "#031e17", skyMid: "#063d2f", skyBot: "#02241d", railFloor: "#10b981", railFloorDark: "#047857", railCeil: "#34d399", railCeilDark: "#059669", chainCol: "rgba(52, 211, 153, 0.45)", gearCol: "rgba(16, 185, 129, 0.35)", planetCol: "#34d399", skinName: "Лісовий Жолудь", trailCol: "#22c55e" },
    { id: 3, name: "Вулканічна Магма", skyTop: "#230408", skyMid: "#450a0a", skyBot: "#1c0407", railFloor: "#f97316", railFloorDark: "#c2410c", railCeil: "#ef4444", railCeilDark: "#b91c1c", chainCol: "rgba(249, 115, 22, 0.45)", gearCol: "rgba(239, 68, 68, 0.35)", planetCol: "#ff4400", skinName: "Магматичний Голем", trailCol: "#f97316" },
    { id: 4, name: "Кришталева Печера", skyTop: "#18062e", skyMid: "#3b0764", skyBot: "#1f0436", railFloor: "#c084fc", railFloorDark: "#7e22ce", railCeil: "#e879f9", railCeilDark: "#a21caf", chainCol: "rgba(232, 121, 249, 0.45)", gearCol: "rgba(192, 132, 252, 0.35)", planetCol: "#e879f9", skinName: "Аметистовий Кристал", trailCol: "#c084fc" },
    { id: 5, name: "Крижана Безодня", skyTop: "#031525", skyMid: "#072f4a", skyBot: "#041c2c", railFloor: "#38bdf8", railFloorDark: "#0284c7", railCeil: "#e0f2fe", railCeilDark: "#7dd3fc", chainCol: "rgba(125, 211, 252, 0.45)", gearCol: "rgba(56, 189, 248, 0.35)", planetCol: "#7dd3fc", skinName: "Крижаний Шторм", trailCol: "#38bdf8" },
    { id: 6, name: "Золотий Олімп", skyTop: "#211502", skyMid: "#452e04", skyBot: "#1a1202", railFloor: "#eab308", railFloorDark: "#a16207", railCeil: "#facc15", railCeilDark: "#ca8a04", chainCol: "rgba(250, 204, 21, 0.45)", gearCol: "rgba(234, 179, 8, 0.35)", planetCol: "#facc15", skinName: "Золотий Кубок", trailCol: "#facc15" },
    { id: 7, name: "Полуничний Зефір", skyTop: "#2c051a", skyMid: "#50072b", skyBot: "#200313", railFloor: "#f43f5e", railFloorDark: "#be123c", railCeil: "#fb7185", railCeilDark: "#e11d48", chainCol: "rgba(251, 113, 133, 0.45)", gearCol: "rgba(244, 63, 94, 0.35)", planetCol: "#fb7185", skinName: "Ягідний Пончик", trailCol: "#f43f5e" },
    { id: 8, name: "Грозовий Перевал", skyTop: "#0f172a", skyMid: "#1e293b", skyBot: "#090d16", railFloor: "#64748b", railFloorDark: "#334155", railCeil: "#38bdf8", railCeilDark: "#0284c7", chainCol: "rgba(56, 189, 248, 0.45)", gearCol: "rgba(100, 116, 139, 0.35)", planetCol: "#38bdf8", skinName: "Блискавка Зевса", trailCol: "#fde047" },
    { id: 9, name: "Кораловий Риф", skyTop: "#04202c", skyMid: "#063c4f", skyBot: "#021721", railFloor: "#14b8a6", railFloorDark: "#0f766e", railCeil: "#06b6d4", railCeilDark: "#0891b2", chainCol: "rgba(20, 184, 166, 0.45)", gearCol: "rgba(6, 182, 212, 0.35)", planetCol: "#2dd4bf", skinName: "Морський Скат", trailCol: "#2dd4bf" },
    { id: 10, name: "Годинниковий Завод", skyTop: "#24150b", skyMid: "#452410", skyBot: "#1c0d05", railFloor: "#d97706", railFloorDark: "#92400e", railCeil: "#f59e0b", railCeilDark: "#b45309", chainCol: "rgba(245, 158, 11, 0.45)", gearCol: "rgba(217, 119, 6, 0.35)", planetCol: "#fbbf24", skinName: "Мідна Шестерня", trailCol: "#d97706" },
    { id: 11, name: "Токсична Пустка", skyTop: "#121a05", skyMid: "#243507", skyBot: "#0d1403", railFloor: "#84cc16", railFloorDark: "#4d7c0f", railCeil: "#a3e635", railCeilDark: "#65a30d", chainCol: "rgba(163, 230, 53, 0.45)", gearCol: "rgba(132, 204, 22, 0.35)", planetCol: "#a3e635", skinName: "Токсичний Слайм", trailCol: "#84cc16" },
    { id: 12, name: "Сонячний Спалах", skyTop: "#2a0d02", skyMid: "#521b04", skyBot: "#210901", railFloor: "#ea580c", railFloorDark: "#9a3412", railCeil: "#f97316", railCeilDark: "#c2410c", chainCol: "rgba(249, 115, 22, 0.45)", gearCol: "rgba(234, 88, 12, 0.35)", planetCol: "#fdba74", skinName: "Сонячний Промінь", trailCol: "#fbbf24" },
    { id: 13, name: "Сакура в Неоні", skyTop: "#200926", skyMid: "#3f104d", skyBot: "#16051b", railFloor: "#ec4899", railFloorDark: "#9d174d", railCeil: "#f472b6", railCeilDark: "#be185d", chainCol: "rgba(244, 114, 182, 0.45)", gearCol: "rgba(236, 72, 153, 0.35)", planetCol: "#f472b6", skinName: "Кібер-Самурай", trailCol: "#ec4899" },
    { id: 14, name: "НЛО Галактика", skyTop: "#080727", skyMid: "#13104f", skyBot: "#040316", railFloor: "#6366f1", railFloorDark: "#3730a3", railCeil: "#818cf8", railCeilDark: "#4f46e5", chainCol: "rgba(129, 140, 248, 0.45)", gearCol: "rgba(99, 102, 241, 0.35)", planetCol: "#a5b4fc", skinName: "Прибулець Зорг", trailCol: "#a5b4fc" },
    { id: 15, name: "Медові Дюни", skyTop: "#241c06", skyMid: "#453409", skyBot: "#1a1303", railFloor: "#ca8a04", railFloorDark: "#854d0e", railCeil: "#eab308", railCeilDark: "#a16207", chainCol: "rgba(234, 179, 8, 0.45)", gearCol: "rgba(202, 138, 4, 0.35)", planetCol: "#fde047", skinName: "Медова Бджілка", trailCol: "#fde047" },
    { id: 16, name: "Хмарне Королівство", skyTop: "#0c1a30", skyMid: "#19355e", skyBot: "#081222", railFloor: "#60a5fa", railFloorDark: "#1d4ed8", railCeil: "#93c5fd", railCeilDark: "#2563eb", chainCol: "rgba(147, 197, 253, 0.45)", gearCol: "rgba(96, 165, 250, 0.35)", planetCol: "#bfdbfe", skinName: "Хмарний Серафим", trailCol: "#ffffff" },
    { id: 17, name: "Ретро 8-Bit", skyTop: "#1e0424", skyMid: "#3b0847", skyBot: "#140219", railFloor: "#d946ef", railFloorDark: "#86198f", railCeil: "#06b6d4", railCeilDark: "#0891b2", chainCol: "rgba(217, 70, 239, 0.45)", gearCol: "rgba(6, 182, 212, 0.35)", planetCol: "#f0abfc", skinName: "Піксельний Герой", trailCol: "#22d3ee" },
    { id: 18, name: "Тіньовий Додзьо", skyTop: "#0a0c10", skyMid: "#151922", skyBot: "#06070a", railFloor: "#475569", railFloorDark: "#1e293b", railCeil: "#f43f5e", railCeilDark: "#be123c", chainCol: "rgba(244, 63, 94, 0.45)", gearCol: "rgba(71, 85, 105, 0.35)", planetCol: "#e2e8f0", skinName: "Нічний Шинобі", trailCol: "#64748b" },
    { id: 19, name: "Лавандовий Світанок", skyTop: "#1c0d29", skyMid: "#351a4e", skyBot: "#13081c", railFloor: "#a855f7", railFloorDark: "#6b21a8", railCeil: "#c084fc", railCeilDark: "#7e22ce", chainCol: "rgba(192, 132, 252, 0.45)", gearCol: "rgba(168, 85, 247, 0.35)", planetCol: "#d8b4fe", skinName: "Місячний Мрійник", trailCol: "#d8b4fe" },
    { id: 20, name: "Кібер-М'ята", skyTop: "#031c19", skyMid: "#073a34", skyBot: "#021513", railFloor: "#059669", railFloorDark: "#065f46", railCeil: "#10b981", railCeilDark: "#047857", chainCol: "rgba(16, 185, 129, 0.45)", gearCol: "rgba(5, 150, 105, 0.35)", planetCol: "#6ee7b7", skinName: "М'ятний Хакер", trailCol: "#10b981" },
    { id: 21, name: "Драконяче Лігво", skyTop: "#25030e", skyMid: "#4b081e", skyBot: "#1b0209", railFloor: "#e11d48", railFloorDark: "#881337", railCeil: "#f43f5e", railCeilDark: "#9f1239", chainCol: "rgba(244, 63, 94, 0.45)", gearCol: "rgba(225, 29, 72, 0.35)", planetCol: "#fda4af", skinName: "Червоний Дракон", trailCol: "#ef4444" },
    { id: 22, name: "Піратська Бухта", skyTop: "#081726", skyMid: "#102c49", skyBot: "#040d16", railFloor: "#0284c7", railFloorDark: "#075985", railCeil: "#f59e0b", railCeilDark: "#b45309", chainCol: "rgba(2, 132, 199, 0.45)", gearCol: "rgba(245, 158, 11, 0.35)", planetCol: "#38bdf8", skinName: "Капітан Флінт", trailCol: "#0284c7" },
    { id: 23, name: "Диско 80-х", skyTop: "#22052c", skyMid: "#460959", skyBot: "#18021f", railFloor: "#ec4899", railFloorDark: "#9d174d", railCeil: "#a855f7", railCeilDark: "#6b21a8", chainCol: "rgba(236, 72, 153, 0.45)", gearCol: "rgba(168, 85, 247, 0.35)", planetCol: "#f472b6", skinName: "Диско-Сфера", trailCol: "#f472b6" },
    { id: 24, name: "Алмазний Пік", skyTop: "#031e2b", skyMid: "#08374e", skyBot: "#02141d", railFloor: "#06b6d4", railFloorDark: "#0e7490", railCeil: "#67e8f9", railCeilDark: "#0891b2", chainCol: "rgba(103, 232, 249, 0.45)", gearCol: "rgba(6, 182, 212, 0.35)", planetCol: "#a5f3fc", skinName: "Діамантовий Страж", trailCol: "#67e8f9" },
    { id: 25, name: "Бамбуковий Гай", skyTop: "#0b1c0a", skyMid: "#193617", skyBot: "#071406", railFloor: "#65a30d", railFloorDark: "#3f6212", railCeil: "#84cc16", railCeilDark: "#4d7c0f", chainCol: "rgba(132, 204, 22, 0.45)", gearCol: "rgba(101, 163, 13, 0.35)", planetCol: "#bef264", skinName: "Майстер Панда", trailCol: "#bef264" },
    { id: 26, name: "Нічний Мегаполіс", skyTop: "#0d0a21", skyMid: "#1a1443", skyBot: "#080616", railFloor: "#3b82f6", railFloorDark: "#1d4ed8", railCeil: "#f43f5e", railCeilDark: "#be123c", chainCol: "rgba(59, 130, 246, 0.45)", gearCol: "rgba(244, 63, 94, 0.35)", planetCol: "#60a5fa", skinName: "Кібер-Гонщик", trailCol: "#a855f7" },
    { id: 27, name: "Чарівна Академія", skyTop: "#170624", skyMid: "#2f0c4a", skyBot: "#0e0317", railFloor: "#7e22ce", railFloorDark: "#581c87", railCeil: "#d946ef", railCeilDark: "#a21caf", chainCol: "rgba(217, 70, 239, 0.45)", gearCol: "rgba(126, 34, 206, 0.35)", planetCol: "#e879f9", skinName: "Верховний Маг", trailCol: "#d946ef" },
    { id: 28, name: "Лабіринт Дзеркал", skyTop: "#131326", skyMid: "#252549", skyBot: "#0d0d1b", railFloor: "#94a3b8", railFloorDark: "#475569", railCeil: "#cbd5e1", railCeilDark: "#64748b", chainCol: "rgba(203, 213, 225, 0.45)", gearCol: "rgba(148, 163, 184, 0.35)", planetCol: "#f8fafc", skinName: "Призматичний Фантом", trailCol: "#ffffff" },
    { id: 29, name: "Сутінкова Безодня", skyTop: "#0a0217", skyMid: "#170533", skyBot: "#05010c", railFloor: "#4c1d95", railFloorDark: "#2e1065", railCeil: "#00f0ff", railCeilDark: "#0284c7", chainCol: "rgba(0, 240, 255, 0.45)", gearCol: "rgba(76, 29, 149, 0.35)", planetCol: "#a78bfa", skinName: "Астральний Мандрівник", trailCol: "#818cf8" },
    { id: 30, name: "Вічна Гармонія", skyTop: "#080c24", skyMid: "#121b4a", skyBot: "#040715", railFloor: "#f59e0b", railFloorDark: "#b45309", railCeil: "#10b981", railCeilDark: "#047857", chainCol: "rgba(245, 158, 11, 0.5)", gearCol: "rgba(16, 185, 129, 0.4)", planetCol: "#fde047", skinName: "Абсолютний Владика", trailCol: "#f59e0b" }
];

/**
 * Бібліотека насичених ритмічних патернів
 */
const OBSTACLE_PATTERNS = [
    // 0. ТІЛЬКИ ПІДЛОГА (NO CEILING): Обрив стелі! На підлозі шип, треба стрибнути у повітря й знову натиснути для падіння
    (x, dir, rng, CEILING_Y, FLOOR_Y) => ({
        objs: [
            { type: 'RAIL_GAP', x: x + 20, width: 440, rail: 'CEIL' },
            { type: 'SPIKE', x: x + 220, y: FLOOR_Y, onCeil: false, w: 46, h: 48 },
            { type: 'FLUX_ORB', x: x + 120, y: FLOOR_Y - 70, radius: 10, value: 100, collected: false },
            { type: 'FLUX_ORB', x: x + 180, y: (FLOOR_Y + CEILING_Y) / 2 - 20, radius: 11, value: 150, collected: false },
            { type: 'FLUX_ORB', x: x + 260, y: (FLOOR_Y + CEILING_Y) / 2 - 20, radius: 11, value: 150, collected: false },
            { type: 'FLUX_ORB', x: x + 320, y: FLOOR_Y - 70, radius: 10, value: 100, collected: false }
        ],
        advance: 490
    }),

    // 1. ТІЛЬКИ СТЕЛЯ (NO FLOOR): Підлоги немає! На стелі шип, треба пірнути вниз і в повітрі натиснути вдруге для повернення
    (x, dir, rng, CEILING_Y, FLOOR_Y) => ({
        objs: [
            { type: 'RAIL_GAP', x: x + 20, width: 440, rail: 'FLOOR' },
            { type: 'SPIKE', x: x + 220, y: CEILING_Y, onCeil: true, w: 46, h: 48 },
            { type: 'FLUX_ORB', x: x + 120, y: CEILING_Y + 70, radius: 10, value: 100, collected: false },
            { type: 'FLUX_ORB', x: x + 180, y: (FLOOR_Y + CEILING_Y) / 2 + 20, radius: 11, value: 150, collected: false },
            { type: 'FLUX_ORB', x: x + 260, y: (FLOOR_Y + CEILING_Y) / 2 + 20, radius: 11, value: 150, collected: false },
            { type: 'FLUX_ORB', x: x + 320, y: CEILING_Y + 70, radius: 10, value: 100, collected: false }
        ],
        advance: 490
    }),

    // 2. Ритмічний Слалом (Шип підлоги + дуга з 3 сфер + Шип стелі)
    (x, dir, rng, CEILING_Y, FLOOR_Y) => ({
        objs: [
            { type: 'SPIKE', x: x + 30, y: FLOOR_Y, onCeil: false, w: 44, h: 48 },
            { type: 'FLUX_ORB', x: x + 90, y: FLOOR_Y - 65, radius: 10, value: 100, collected: false },
            { type: 'FLUX_ORB', x: x + 140, y: (FLOOR_Y + CEILING_Y) / 2, radius: 10, value: 150, collected: false },
            { type: 'FLUX_ORB', x: x + 190, y: CEILING_Y + 65, radius: 10, value: 200, collected: false },
            { type: 'SPIKE', x: x + 250, y: CEILING_Y, onCeil: true, w: 44, h: 48 }
        ],
        advance: 320
    }),

    // 3. Хвиля Енергії (5 сфер по синусоїді, що стимулюють бездоганний фліп)
    (x, dir, rng, CEILING_Y, FLOOR_Y) => {
        const objs = [];
        for (let i = 0; i < 5; i++) {
            const ox = x + i * 48;
            const progress = i / 4;
            const oy = CEILING_Y + 55 + Math.sin(progress * Math.PI) * (FLOOR_Y - CEILING_Y - 110);
            objs.push({ type: 'FLUX_ORB', x: ox, y: oy, radius: 10, value: 100 + i * 25, collected: false });
        }
        return { objs, advance: 280 };
    },

    // 4. Гравітаційне Буст-Кільце над пилкою (Проліт крізь кільце дає щит та швидкість)
    (x, dir, rng, CEILING_Y, FLOOR_Y) => ({
        objs: [
            { type: 'BOOST_RING', x: x + 60, y: (FLOOR_Y + CEILING_Y) / 2, radius: 32, passed: false },
            { type: 'SAW', x: x + 160, y: (FLOOR_Y + CEILING_Y) / 2, radius: 36, rotSpeed: 0.08 },
            { type: 'FLUX_ORB', x: x + 240, y: (FLOOR_Y + CEILING_Y) / 2, radius: 12, value: 250, collected: false }
        ],
        advance: 340
    }),

    // 5. Пульсуючий Лазер під біт + сфери обходу
    (x, dir, rng, CEILING_Y, FLOOR_Y) => {
        const topHole = rng() > 0.5;
        return {
            objs: [
                {
                    type: 'LASER',
                    x: x + 90,
                    y1: topHole ? CEILING_Y + 130 : CEILING_Y,
                    y2: topHole ? FLOOR_Y : FLOOR_Y - 130,
                    width: 14
                },
                { type: 'FLUX_ORB', x: x + 90, y: topHole ? CEILING_Y + 55 : FLOOR_Y - 55, radius: 11, value: 150, collected: false },
                { type: 'FLUX_ORB', x: x + 160, y: topHole ? CEILING_Y + 55 : FLOOR_Y - 55, radius: 10, value: 100, collected: false }
            ],
            advance: 280
        };
    },

    // 6. Подвійний Стрибковий Каскад (Подвійний шип підлоги та бонусні сфери вгорі)
    (x, dir, rng, CEILING_Y, FLOOR_Y) => ({
        objs: [
            { type: 'SPIKE', x: x + 35, y: FLOOR_Y, onCeil: false, w: 44, h: 48 },
            { type: 'SPIKE', x: x + 85, y: FLOOR_Y, onCeil: false, w: 44, h: 48 },
            { type: 'FLUX_ORB', x: x + 150, y: CEILING_Y + 50, radius: 10, value: 150, collected: false },
            { type: 'FLUX_ORB', x: x + 200, y: CEILING_Y + 50, radius: 10, value: 150, collected: false }
        ],
        advance: 290
    })
];

class WorldRegistry {
    static getTheme(worldId) {
        if (!Array.isArray(WORLD_THEMES) || WORLD_THEMES.length === 0) {
            return { id: 1, name: "Магнітний Неон", skyTop: "#12052b", skyMid: "#250954", skyBot: "#082a3d", railFloor: "#ff7a00", railFloorDark: "#c2410c", railCeil: "#00f0ff", railCeilDark: "#0284c7", chainCol: "rgba(0, 240, 255, 0.45)", gearCol: "rgba(168, 85, 247, 0.35)", planetCol: "#00f0ff", skinName: "Магнітний Бот", trailCol: "#00f0ff" };
        }
        const found = WORLD_THEMES.find(t => t.id === worldId);
        return found || WORLD_THEMES[0];
    }

    static createSeededRNG(seed) {
        let s = Math.floor(seed) >>> 0;
        return function () {
            s |= 0;
            s = (s + 0x6D2B79F5) | 0;
            let t = Math.imul(s ^ (s >>> 15), 1 | s);
            t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
    }

    static generateLevel(worldIndex, levelIndex, CEILING_Y, FLOOR_Y, gameSpeed) {
        const obstacles = [];
        const seed = worldIndex * 1000 + levelIndex;
        const rng = this.createSeededRNG(seed);
        const targetSeconds = 85 + levelIndex * 0.3;
        const levelLength = Math.round(targetSeconds * 60 * gameSpeed);

        let cursorX = 650;
        const minReactionDist = gameSpeed * 15 + 45;

        while (cursorX < levelLength - 500) {
            const patternIdx = Math.floor(rng() * OBSTACLE_PATTERNS.length);
            const pattern = OBSTACLE_PATTERNS[patternIdx](cursorX, 1, rng, CEILING_Y, FLOOR_Y);
            pattern.objs.forEach(obj => obstacles.push(obj));
            cursorX += Math.max(pattern.advance, minReactionDist);
        }

        obstacles.push({
            type: 'FINISH_GATE',
            x: levelLength,
            y: CEILING_Y,
            h: FLOOR_Y - CEILING_Y
        });

        return { obstacles, levelLength };
    }
}

window.WORLD_THEMES = WORLD_THEMES;
window.OBSTACLE_PATTERNS = OBSTACLE_PATTERNS;
window.WorldRegistry = WorldRegistry;