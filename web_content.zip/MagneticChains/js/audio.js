class CuteSoundEngine {
    constructor() {
        this.ctx = null;
        this.enabled = true;
        this.bpm = 138;
        this.beatDuration = 60 / this.bpm;
        this.isPlaying = false;

        // Планувальник Web Audio API
        this.lookahead = 0.035;
        this.scheduleAheadTime = 0.12;
        this.nextNoteTime = 0;
        this.currentStep = 0;
        this.musicTimer = null;

        // Пентатонічний лад для збирання сфер (A-Minor Pentatonic)
        this.scale = [220, 261.63, 293.66, 329.63, 392.00, 440, 523.25, 587.33, 659.25, 783.99, 880];
        this.bassNotes = [110, 110, 130.81, 146.83, 110, 110, 164.81, 146.83];
    }

    init() {
        if (!this.ctx) {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (AudioCtx) this.ctx = new AudioCtx();
        }
        if (this.ctx && this.ctx.state === 'suspended') {
            this.ctx.resume();
        }
    }

    playKick(time) {
        if (!this.enabled || !this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.frequency.setValueAtTime(145, time);
        osc.frequency.exponentialRampToValueAtTime(32, time + 0.08);
        gain.gain.setValueAtTime(0.35, time);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 0.11);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(time);
        osc.stop(time + 0.12);
    }

    playSnare(time) {
        if (!this.enabled || !this.ctx) return;
        const bufferSize = Math.floor(this.ctx.sampleRate * 0.07);
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;

        const noise = this.ctx.createBufferSource();
        noise.buffer = buffer;
        const filter = this.ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = 1800;

        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(0.18, time);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 0.07);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        noise.start(time);
        noise.stop(time + 0.07);
    }

    playHat(time, open = false) {
        if (!this.enabled || !this.ctx) return;
        const osc = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(9000, time);
        filter.type = 'highpass';
        filter.frequency.value = 7500;

        const dur = open ? 0.06 : 0.025;
        gain.gain.setValueAtTime(0.08, time);
        gain.gain.exponentialRampToValueAtTime(0.001, time + dur);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(time);
        osc.stop(time + dur + 0.01);
    }

    playBassNote(time, freq) {
        if (!this.enabled || !this.ctx) return;
        const osc = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, time);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(900, time);
        filter.frequency.exponentialRampToValueAtTime(200, time + 0.12);

        gain.gain.setValueAtTime(0.16, time);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 0.12);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(time);
        osc.stop(time + 0.13);
    }

    scheduler() {
        if (!this.enabled || !this.isPlaying || !this.ctx) return;
        const sixteenth = this.beatDuration / 4;

        while (this.nextNoteTime < this.ctx.currentTime + this.scheduleAheadTime) {
            const step = this.currentStep;
            const time = this.nextNoteTime;
            const beatInBar = Math.floor(step / 4) % 4;
            const stepInBeat = step % 4;

            // Kick на 1 та 3 долю
            if ((beatInBar === 0 || beatInBar === 2) && stepInBeat === 0) {
                this.playKick(time);
            }
            // Snare на 2 та 4 долю
            if ((beatInBar === 1 || beatInBar === 3) && stepInBeat === 0) {
                this.playSnare(time);
            }
            // Хай-хет на слабкі 16-ті
            if (stepInBeat === 2) {
                this.playHat(time, false);
            } else if (step % 8 === 4) {
                this.playHat(time, true);
            }

            // Ритмічний басовий пасаж
            if (step % 2 === 0) {
                const noteIdx = Math.floor(step / 2) % this.bassNotes.length;
                this.playBassNote(time, this.bassNotes[noteIdx]);
            }

            this.nextNoteTime += sixteenth;
            this.currentStep = (this.currentStep + 1) % 64;
        }
    }

    startMusic(speed = 8.5) {
        if (!this.enabled) return;
        this.init();
        if (this.isPlaying) return;

        this.bpm = Math.min(165, 126 + (speed - 7.5) * 4);
        this.beatDuration = 60 / this.bpm;
        this.isPlaying = true;
        this.nextNoteTime = this.ctx.currentTime + 0.05;
        this.currentStep = 0;

        this.musicTimer = setInterval(() => this.scheduler(), this.lookahead * 1000);
    }

    stopMusic() {
        this.isPlaying = false;
        if (this.musicTimer) {
            clearInterval(this.musicTimer);
            this.musicTimer = null;
        }
    }

    playFlip(dir) {
        if (!this.enabled) return;
        this.init();
        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'triangle';
            const fStart = dir > 0 ? 240 : 480;
            const fEnd = dir > 0 ? 480 : 240;
            osc.frequency.setValueAtTime(fStart, now);
            osc.frequency.exponentialRampToValueAtTime(fEnd, now + 0.09);
            gain.gain.setValueAtTime(0.2, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.1);
        } catch (e) { }
    }

    playCollectOrb(combo = 0) {
        if (!this.enabled) return;
        this.init();
        try {
            const now = this.ctx.currentTime;
            const noteIdx = Math.min(this.scale.length - 1, combo % this.scale.length);
            const freq = this.scale[noteIdx];

            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, now);
            osc.frequency.exponentialRampToValueAtTime(freq * 1.04, now + 0.11);

            gain.gain.setValueAtTime(0.18, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);

            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.12);
        } catch (e) { }
    }

    playBoostRing() {
        if (!this.enabled) return;
        this.init();
        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(320, now);
            osc.frequency.exponentialRampToValueAtTime(880, now + 0.18);

            gain.gain.setValueAtTime(0.22, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.21);
        } catch (e) { }
    }

    playLand() {
        if (!this.enabled) return;
        this.init();
        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(120, now);
            osc.frequency.exponentialRampToValueAtTime(35, now + 0.06);
            gain.gain.setValueAtTime(0.15, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);
            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.07);
        } catch (e) { }
    }

    playNearMiss() {
        if (!this.enabled) return;
        this.init();
        try {
            const now = this.ctx.currentTime;
            [880, 1320, 1760].forEach((freq, idx) => {
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(freq, now + idx * 0.03);
                gain.gain.setValueAtTime(0.1, now + idx * 0.03);
                gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.03 + 0.1);
                osc.connect(gain);
                gain.connect(this.ctx.destination);
                osc.start(now + idx * 0.03);
                osc.stop(now + idx * 0.03 + 0.11);
            });
        } catch (e) { }
    }

    playCrash() {
        if (!this.enabled) return;
        this.init();
        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(260, now);
            osc.frequency.exponentialRampToValueAtTime(30, now + 0.26);
            gain.gain.setValueAtTime(0.28, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.26);
            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.27);
        } catch (e) { }
    }

    playClick() {
        if (!this.enabled) return;
        this.init();
        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(600, now);
            osc.frequency.exponentialRampToValueAtTime(300, now + 0.04);
            gain.gain.setValueAtTime(0.08, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.05);
        } catch (e) { }
    }

    playVictory() {
        if (!this.enabled) return;
        this.init();
        try {
            const notes = [523.25, 659.25, 783.99, 1046.50];
            notes.forEach((freq, idx) => {
                const now = this.ctx.currentTime + idx * 0.08;
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'triangle';
                osc.frequency.setValueAtTime(freq, now);
                gain.gain.setValueAtTime(0.14, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
                osc.connect(gain);
                gain.connect(this.ctx.destination);
                osc.start(now);
                osc.stop(now + 0.26);
            });
        } catch (e) { }
    }

    toggle() {
        this.enabled = !this.enabled;
        if (!this.enabled) this.stopMusic();
        return this.enabled;
    }
}

window.sound = new CuteSoundEngine();