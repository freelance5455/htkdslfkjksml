class PlayerManager {
    constructor(ceilingY = 125, floorY = 475, radius = 20) {
        this.CEILING_Y = ceilingY;
        this.FLOOR_Y = floorY;
        this.PLAYER_RADIUS = radius;

        this.GRAVITY_VAL = 1.45;
        this.FLIP_FORCE = 10.5;

        this.x = 200;
        this.y = this.FLOOR_Y - this.PLAYER_RADIUS;
        this.vy = 0;
        this.gravityDir = 1;
        this.rotationAngle = 0;
        this.isGrounded = true;
        this.scaleX = 1;
        this.scaleY = 1;
        this.blinkTimer = 0;
        this.isBlinking = false;
        this.nearMissTimer = 0;

        this.boostTimer = 0;
        this.combo = 0;

        this.trail = [];
        this.particles = [];
    }

    reset() {
        this.x = 200;
        this.y = this.FLOOR_Y - this.PLAYER_RADIUS;
        this.vy = 0;
        this.gravityDir = 1;
        this.rotationAngle = 0;
        this.isGrounded = true;
        this.scaleX = 1;
        this.scaleY = 1;
        this.blinkTimer = 0;
        this.isBlinking = false;
        this.nearMissTimer = 0;
        this.boostTimer = 0;
        this.combo = 0;
        this.trail = [];
        this.particles = [];
    }

    flipGravity(soundEngine, currentSkin, activeBiome) {
        this.gravityDir = -this.gravityDir;
        this.vy = this.gravityDir * this.FLIP_FORCE;
        this.isGrounded = false;

        if (soundEngine) soundEngine.playFlip(this.gravityDir);

        this.scaleX = 0.65;
        this.scaleY = 1.45;

        const particleCol = (currentSkin && currentSkin.trailCol) || (this.gravityDir > 0 ? activeBiome.railFloor : activeBiome.railCeil);
        for (let i = 0; i < 14; i++) {
            this.particles.push({
                x: this.x,
                y: this.y,
                vx: (Math.random() - 0.5) * 7,
                vy: (Math.random() - 0.5) * 7,
                size: Math.random() * 4 + 2,
                color: particleCol,
                alpha: 1,
                life: 20
            });
        }
    }

    triggerBoost(soundEngine) {
        this.boostTimer = 35;
        if (soundEngine) soundEngine.playBoostRing();

        for (let i = 0; i < 18; i++) {
            this.particles.push({
                x: this.x,
                y: this.y,
                vx: (Math.random() - 0.2) * 11,
                vy: (Math.random() - 0.5) * 8,
                size: Math.random() * 5 + 3,
                color: '#facc15',
                alpha: 1,
                life: 24
            });
        }
    }

    updatePhysics(deltaScale, gameSpeed, soundEngine, obstacles = []) {
        const stepDist = (gameSpeed + (this.boostTimer > 0 ? 3.0 : 0)) * deltaScale;
        this.x += stepDist;

        this.rotationAngle += (stepDist / this.PLAYER_RADIUS) * this.gravityDir * 0.26;

        this.vy += this.GRAVITY_VAL * this.gravityDir * deltaScale;
        this.y += this.vy * deltaScale;

        if (!this.isGrounded) {
            const targetScaleY = 1.0 + Math.min(0.4, Math.abs(this.vy) * 0.04);
            const targetScaleX = 1.0 / targetScaleY;
            this.scaleY += (targetScaleY - this.scaleY) * 0.25;
            this.scaleX += (targetScaleX - this.scaleX) * 0.25;
        }

        // Перевірка наявності рейок у точці X гравця (чи немає розриву)
        const ceilGaps = obstacles.filter(o => o.type === 'RAIL_GAP' && o.rail === 'CEIL');
        const floorGaps = obstacles.filter(o => o.type === 'RAIL_GAP' && o.rail === 'FLOOR');

        const hasCeil = !ceilGaps.some(g => this.x >= g.x && this.x <= g.x + g.width);
        const hasFloor = !floorGaps.some(g => this.x >= g.x && this.x <= g.x + g.width);

        // Посадка на підлогу (лише якщо є рейка підлоги)
        if (this.gravityDir > 0 && hasFloor && this.y >= this.FLOOR_Y - this.PLAYER_RADIUS) {
            if (!this.isGrounded) {
                this.scaleX = 1.4;
                this.scaleY = 0.65;
                if (soundEngine) soundEngine.playLand();
            }
            this.y = this.FLOOR_Y - this.PLAYER_RADIUS;
            this.vy = 0;
            this.isGrounded = true;
        }
        // Посадка на стелю (лише якщо є рейка стелі)
        else if (this.gravityDir < 0 && hasCeil && this.y <= this.CEILING_Y + this.PLAYER_RADIUS) {
            if (!this.isGrounded) {
                this.scaleX = 1.4;
                this.scaleY = 0.65;
                if (soundEngine) soundEngine.playLand();
            }
            this.y = this.CEILING_Y + this.PLAYER_RADIUS;
            this.vy = 0;
            this.isGrounded = true;
        } else {
            this.isGrounded = false;
        }

        this.scaleX += (1 - this.scaleX) * 0.18;
        this.scaleY += (1 - this.scaleY) * 0.18;

        this.blinkTimer++;
        if (this.blinkTimer > 180) {
            this.isBlinking = true;
            if (this.blinkTimer > 192) {
                this.isBlinking = false;
                this.blinkTimer = 0;
            }
        }

        if (this.nearMissTimer > 0) this.nearMissTimer--;
        if (this.boostTimer > 0) this.boostTimer--;

        this.trail.unshift({ x: this.x, y: this.y, isBoost: this.boostTimer > 0 });
        if (this.trail.length > 9) this.trail.pop();

        return stepDist;
    }

    render(ctx, cameraX, time, equippedSkinId) {
        ctx.save();
        ctx.translate(-cameraX, 0);

        const currentSkin = (window.SkinRegistry && window.SkinRegistry.get(equippedSkinId)) || window.ALL_SKINS_LIST[0];
        const skinTrailColor = this.boostTimer > 0 ? '#fde047' : (currentSkin.trailCol || '#00f0ff');

        for (let i = 0; i < this.trail.length; i++) {
            const pt = this.trail[i];
            const alpha = (1 - i / this.trail.length) * 0.55;
            const r = this.PLAYER_RADIUS * (1 - i / this.trail.length * 0.45);
            ctx.save();
            ctx.globalAlpha = alpha;
            ctx.fillStyle = pt.isBoost ? '#facc15' : skinTrailColor;
            ctx.shadowColor = ctx.fillStyle;
            ctx.shadowBlur = 10;
            ctx.beginPath();
            ctx.arc(pt.x, pt.y, r, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }

        if (this.boostTimer > 0) {
            ctx.save();
            ctx.strokeStyle = '#facc15';
            ctx.lineWidth = 3;
            ctx.shadowColor = '#facc15';
            ctx.shadowBlur = 15;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.PLAYER_RADIUS + 6, 0, Math.PI * 2);
            ctx.stroke();
            ctx.restore();
        }

        if (window.drawUnifiedSkin) {
            window.drawUnifiedSkin(ctx, this.x, this.y, this.PLAYER_RADIUS, currentSkin, {
                scaleX: this.scaleX,
                scaleY: this.scaleY,
                gravityDir: this.gravityDir,
                rotation: this.rotationAngle,
                nearMiss: this.nearMissTimer > 0,
                isBlinking: this.isBlinking,
                time: time
            });
        }

        ctx.restore();
    }

    renderParticles(ctx, cameraX) {
        ctx.save();
        ctx.translate(-cameraX, 0);
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            p.x += p.vx;
            p.y += p.vy;
            p.alpha -= 1 / p.life;

            if (p.alpha <= 0) {
                this.particles.splice(i, 1);
                continue;
            }

            ctx.fillStyle = p.color;
            ctx.globalAlpha = p.alpha;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.restore();
    }
}

window.PlayerManager = PlayerManager;