class PlayerManager {
    constructor(ceilingY = 125, floorY = 475, radius = 20) {
        this.CEILING_Y = ceilingY;
        this.FLOOR_Y = floorY;
        this.PLAYER_RADIUS = radius;
        this.GRAVITY_VAL = 1.35;
        this.FLIP_FORCE = 9.8;

        this.x = 200;
        this.y = this.FLOOR_Y - this.PLAYER_RADIUS;
        this.vy = 0;
        this.gravityDir = 1;
        this.rotationAngle = 0;
        this.isGrounded = true;
        this.scaleX = 1;
        this.scaleY = 1;
        this.blinkTimer = 0;
        this.isBlinking = false;
        this.nearMissTimer = 0;
        this.trail = [];
        this.particles = [];
    }

    reset() {
        this.x = 200;
        this.y = this.FLOOR_Y - this.PLAYER_RADIUS;
        this.vy = 0;
        this.gravityDir = 1;
        this.rotationAngle = 0;
        this.isGrounded = true;
        this.scaleX = 1;
        this.scaleY = 1;
        this.blinkTimer = 0;
        this.isBlinking = false;
        this.nearMissTimer = 0;
        this.trail = [];
        this.particles = [];
    }

    flipGravity(soundEngine, currentSkin, activeBiome) {
        this.gravityDir = -this.gravityDir;
        this.vy = this.gravityDir * this.FLIP_FORCE;
        this.isGrounded = false;

        if (soundEngine) soundEngine.playFlip(this.gravityDir);

        this.scaleX = 0.7;
        this.scaleY = 1.4;

        const particleCol = (currentSkin && currentSkin.trailCol) || (this.gravityDir > 0 ? activeBiome.railFloor : activeBiome.railCeil);
        for (let i = 0; i < 14; i++) {
            this.particles.push({
                x: this.x,
                y: this.y,
                vx: (Math.random() - 0.5) * 6,
                vy: (Math.random() - 0.5) * 6,
                size: Math.random() * 4 + 2,
                color: particleCol,
                alpha: 1,
                life: 22
            });
        }
    }

    updatePhysics(deltaScale, gameSpeed, soundEngine) {
        const stepDist = gameSpeed * deltaScale;
        this.x += stepDist;

        this.rotationAngle += (stepDist / this.PLAYER_RADIUS) * this.gravityDir * 0.23;

        this.vy += this.GRAVITY_VAL * this.gravityDir * deltaScale;
        this.y += this.vy * deltaScale;

        if (!this.isGrounded) {
            const targetScaleY = 1.0 + Math.min(0.35, Math.abs(this.vy) * 0.035);
            const targetScaleX = 1.0 / targetScaleY;
            this.scaleY += (targetScaleY - this.scaleY) * 0.25;
            this.scaleX += (targetScaleX - this.scaleX) * 0.25;
        }

        if (this.gravityDir > 0 && this.y >= this.FLOOR_Y - this.PLAYER_RADIUS) {
            if (!this.isGrounded) {
                this.scaleX = 1.4;
                this.scaleY = 0.65;
                if (soundEngine) soundEngine.playLand();
            }
            this.y = this.FLOOR_Y - this.PLAYER_RADIUS;
            this.vy = 0;
            this.isGrounded = true;
        } else if (this.gravityDir < 0 && this.y <= this.CEILING_Y + this.PLAYER_RADIUS) {
            if (!this.isGrounded) {
                this.scaleX = 1.4;
                this.scaleY = 0.65;
                if (soundEngine) soundEngine.playLand();
            }
            this.y = this.CEILING_Y + this.PLAYER_RADIUS;
            this.vy = 0;
            this.isGrounded = true;
        } else {
            this.isGrounded = false;
        }

        this.scaleX += (1 - this.scaleX) * 0.18;
        this.scaleY += (1 - this.scaleY) * 0.18;

        this.blinkTimer++;
        if (this.blinkTimer > 180) {
            this.isBlinking = true;
            if (this.blinkTimer > 192) {
                this.isBlinking = false;
                this.blinkTimer = 0;
            }
        }

        if (this.nearMissTimer > 0) this.nearMissTimer--;

        this.trail.unshift({ x: this.x, y: this.y });
        if (this.trail.length > 8) this.trail.pop();

        return stepDist;
    }

    render(ctx, cameraX, time, equippedSkinId) {
        ctx.save();
        ctx.translate(-cameraX, 0);

        const currentSkin = (window.SkinRegistry && window.SkinRegistry.get(equippedSkinId)) || window.ALL_SKINS_LIST[0];
        const skinTrailColor = currentSkin.trailCol || '#00f0ff';

        for (let i = 0; i < this.trail.length; i++) {
            const pt = this.trail[i];
            const alpha = (1 - i / this.trail.length) * 0.45;
            const r = this.PLAYER_RADIUS * (1 - i / this.trail.length * 0.45);
            ctx.save();
            ctx.globalAlpha = alpha;
            ctx.fillStyle = skinTrailColor;
            ctx.shadowColor = skinTrailColor;
            ctx.shadowBlur = 8;
            ctx.beginPath();
            ctx.arc(pt.x, pt.y, r, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }

        if (window.drawUnifiedSkin) {
            window.drawUnifiedSkin(ctx, this.x, this.y, this.PLAYER_RADIUS, currentSkin, {
                scaleX: this.scaleX,
                scaleY: this.scaleY,
                gravityDir: this.gravityDir,
                rotation: this.rotationAngle,
                nearMiss: this.nearMissTimer > 0,
                isBlinking: this.isBlinking,
                time: time
            });
        }

        ctx.restore();
    }

    renderParticles(ctx, cameraX) {
        ctx.save();
        ctx.translate(-cameraX, 0);
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            p.x += p.vx;
            p.y += p.vy;
            p.alpha -= 1 / p.life;

            if (p.alpha <= 0) {
                this.particles.splice(i, 1);
                continue;
            }

            ctx.fillStyle = p.color;
            ctx.globalAlpha = p.alpha;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.restore();
    }
}

window.PlayerManager = PlayerManager;