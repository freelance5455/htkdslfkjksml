# Adrees Personal Cloud

A mobile-first private personal cloud starter built with Node.js, Express, SQLite, sessions and local file storage.

## Run locally
1. Install Node.js 18+.
2. Extract this ZIP.
3. Open a terminal in the project folder.
4. Run `npm install`
5. Run `npm start`
6. Open `http://localhost:3000`

## Initial login
Username: `03069271818`
Initial password: `08520852`

On first login, change the password to a strong password of at least 8 characters.

## Features
- Login/session authentication with bcrypt password hashing
- Upload multiple photos, videos, documents, audio and other files
- Search and category filters
- Image/video preview and download
- Favorites and trash/restore/permanent delete
- Notes
- Personal information storage
- Dashboard statistics
- Mobile-first responsive UI and PWA manifest

## Internet deployment
Use a normal Node.js server/VPS or another host with persistent disk. Do not rely on ephemeral serverless storage for the SQLite database and uploads. Put HTTPS in front of the app, set a long random `SESSION_SECRET`, and configure environment variables from `.env.example`.

Back up `data/cloud.db` and `data/uploads/` regularly.
