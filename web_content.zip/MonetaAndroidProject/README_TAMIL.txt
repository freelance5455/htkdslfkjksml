MONETA FINANCE - Android project

இந்த ZIP-ல் Moneta Finance HTML app-ஐ Android WebView app ஆக மாற்றும் Android Studio project உள்ளது.
இது நேரடியாக APK அல்ல; இந்த சூழலில் Android SDK/Gradle build tools இல்லாததால் compiled APK உருவாக்க முடியவில்லை.

APK உருவாக்க:
1. Android Studio-ஐ கணினியில் install செய்யவும்.
2. இந்த ZIP-ஐ extract செய்யவும்.
3. Android Studio > Open > MonetaAndroidProject folder-ஐ தேர்வு செய்யவும்.
4. Gradle sync முடிந்ததும் Build > Build Bundle(s) / APK(s) > Build APK(s) தேர்வு செய்யவும்.
5. APK பொதுவாக app/build/outputs/apk/debug/app-debug.apk என்ற இடத்தில் உருவாகும்.

குறிப்பு:
- உங்கள் transactions சாதனத்தின் app/browser local storage-ல் சேமிக்கப்படும்.
- App data clear அல்லது uninstall செய்தால் data நீங்கலாம்; JSON backup/export பயன்படுத்தவும்.
