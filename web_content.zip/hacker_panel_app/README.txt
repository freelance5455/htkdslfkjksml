HACKER PANEL APP — QUICK START

1. Extract hacker_panel_app.zip.
2. Keep index.html and music.mp3 in the same folder.
3. Open index.html in Chrome (Android or computer).
4. Enter key: D28LA1EN03NS50PS
5. Tap LOGIN. The supplied clip's audio should play and the blue “Panel lega 😂” message appears.

Note: This is a stylish demo/access screen, not real security. The key is visible in the page source, so don't use it to protect private data. Browser audio may require device volume enabled.
