# Dashboard and sidebar rebuild — 2.6.0

## Changes
- Reorganized authenticated navigation into Dashboard, Creative Workspaces, AI Creation, Your Library, Account, and Administration groups.
- Renamed the voice destination to Voice Cloning Studio and the video destination to Video Edit Studio.
- Corrected current-page states and retained the existing responsive drawer/collapse behavior.
- Replaced the obsolete green navigation accent with the current black/red Anonymoux palette.
- Rebuilt dashboard quick-create shortcuts to point only to actual workspaces; removed generic duplicate New Project and Upload Reference cards.
- Added distinct Voice Cloning Studio and AI Agent Studio shortcuts.

## Preserved
- Existing user authentication and role checks.
- Sidebar sign-out form and CSRF token.
- Wallet balance, notification center, theme toggle, and recent access tracking.
- Existing Projects, Assets, History, Tools & Tutorials, and Settings destinations.
