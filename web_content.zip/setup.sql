-- Run this once in Supabase → SQL Editor → New query → Run

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text, email text,
  currency text not null default 'INR',
  created_at timestamptz not null default now()
);

create table public.incomes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  amount numeric(14,2) not null check (amount > 0),
  type text not null check (type in ('Salary','Freelance','Business','Gift','Investment','Other')),
  description text default '',
  date date not null,
  recurring boolean not null default false,
  recurring_type text check (recurring_type in ('weekly','monthly','yearly')),
  created_at timestamptz not null default now(),
  check (recurring or recurring_type is null)
);

create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  amount numeric(14,2) not null check (amount > 0),
  category text not null check (category in ('Food','Groceries','Transport','Shopping','Bills','Electricity','Internet','Education','Health','Entertainment','Travel','Subscriptions','Rent','EMI','Personal','Other')),
  description text default '',
  payment_method text not null default 'UPI' check (payment_method in ('Cash','UPI','Debit Card','Credit Card','Bank Transfer','Other')),
  date date not null,
  recurring boolean not null default false,
  recurring_type text check (recurring_type in ('daily','weekly','monthly','yearly')),
  created_at timestamptz not null default now(),
  check (recurring or recurring_type is null)
);

create table public.budgets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  category text not null,
  amount numeric(14,2) not null check (amount > 0),
  month text not null check (month ~ '^\d{4}-\d{2}$'),
  created_at timestamptz not null default now(),
  unique (user_id, category, month)
);

create table public.savings_goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null,
  target_amount numeric(14,2) not null check (target_amount > 0),
  saved_amount numeric(14,2) not null default 0 check (saved_amount >= 0),
  target_date date,
  created_at timestamptz not null default now()
);

-- Row Level Security: every user can only touch their own rows
alter table public.profiles enable row level security;
create policy "own profile read"   on public.profiles for select to authenticated using (auth.uid() = id);
create policy "own profile insert" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "own profile update" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

do $$ declare t text; begin
  foreach t in array array['incomes','expenses','budgets','savings_goals'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('create policy "own rows" on public.%I for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id)', t);
    execute format('create index on public.%I (user_id)', t);
  end loop;
end $$;

-- Auto-create a profile when someone signs up
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, name, email)
  values (new.id, coalesce(new.raw_user_meta_data->>'name',''), new.email)
  on conflict (id) do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();
