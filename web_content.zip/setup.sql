-- ANÓNIMO: tabla para mensajes recibidos por enlace.
-- No borra ni modifica profiles ni messages existentes.
create table if not exists public.anonymous_messages (
 id uuid primary key default gen_random_uuid(),
 recipient_id uuid not null references auth.users(id) on delete cascade,
 content text not null check (char_length(trim(content)) between 1 and 1000),
 created_at timestamptz not null default now()
);
create index if not exists anonymous_messages_recipient_created_idx
 on public.anonymous_messages(recipient_id,created_at desc);
alter table public.profiles enable row level security;
alter table public.anonymous_messages enable row level security;
do $$
begin
 if not exists(select 1 from pg_policies where schemaname='public' and tablename='profiles' and policyname='profiles_public_link_lookup') then
  create policy profiles_public_link_lookup on public.profiles for select to anon,authenticated using (true);
 end if;
 if not exists(select 1 from pg_policies where schemaname='public' and tablename='profiles' and policyname='profiles_insert_own') then
  create policy profiles_insert_own on public.profiles for insert to authenticated with check (auth.uid()=id);
 end if;
 if not exists(select 1 from pg_policies where schemaname='public' and tablename='profiles' and policyname='profiles_update_own') then
  create policy profiles_update_own on public.profiles for update to authenticated using (auth.uid()=id) with check (auth.uid()=id);
 end if;
 if not exists(select 1 from pg_policies where schemaname='public' and tablename='anonymous_messages' and policyname='anonymous_messages_public_insert') then
  create policy anonymous_messages_public_insert on public.anonymous_messages for insert to anon,authenticated with check (char_length(trim(content)) between 1 and 1000 and exists(select 1 from public.profiles p where p.id=recipient_id));
 end if;
 if not exists(select 1 from pg_policies where schemaname='public' and tablename='anonymous_messages' and policyname='anonymous_messages_recipient_read') then
  create policy anonymous_messages_recipient_read on public.anonymous_messages for select to authenticated using (auth.uid()=recipient_id);
 end if;
end $$;
grant select on public.profiles to anon,authenticated;
grant insert,update on public.profiles to authenticated;
grant insert on public.anonymous_messages to anon,authenticated;
grant select on public.anonymous_messages to authenticated;
