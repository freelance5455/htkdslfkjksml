# BranchLedger Android APK project

This project wraps the supplied `branchmate.html` as an Android WebView app named **BranchLedger**.

## Build APK in Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync and install Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
5. Copy the APK to your Android phone and install it (allow installation from the source used to open the APK if Android asks).

The HTML uses HTTPS CDN resources for fonts and jsPDF, so the app requests Internet permission. The core page is bundled locally and opens without a web server.
