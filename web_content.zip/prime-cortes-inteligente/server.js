const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.YOUTUBE_API_KEY;
const ARCHIVE_ENABLED = process.env.INTERNET_ARCHIVE_ENABLED !== "false";

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function isoDurationToSeconds(iso) {
  const m = String(iso || "").match(/^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/);
  if (!m) return null;
  return Number(m[1] || 0) * 3600 + Number(m[2] || 0) * 60 + Number(m[3] || 0);
}
function normalize(s) {
  return String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}
function relevantTitle(title, description, query) {
  const q = normalize(query), t = normalize(title), d = normalize(description);
  const words = q.split(" ").filter(w => w.length > 1);
  if (!words.length) return false;
  if (t.includes(q)) return true;
  const hits = words.filter(w => t.includes(w)).length;
  const descHits = words.filter(w => d.includes(w)).length;
  return hits >= Math.max(1, Math.ceil(words.length * 0.7)) ||
    (hits >= 1 && descHits >= Math.max(1, Math.ceil(words.length * 0.7)));
}
async function fetchJson(url, label) {
  const response = await fetch(url, { headers: { "User-Agent": "PrimeCortesInteligente/1.1 (metadata search)" } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(`${label}: HTTP ${response.status}`);
  return data;
}
async function youtube(endpoint, params) {
  const url = new URL(`https://www.googleapis.com/youtube/v3/${endpoint}`);
  Object.entries({ ...params, key: API_KEY }).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== "") url.searchParams.set(k, String(v));
  });
  const data = await fetchJson(url, "YouTube API");
  if (data.error) throw new Error(data.error.message || "Erro da YouTube API");
  return data;
}
async function searchYouTube(query, target, tolerance, sort) {
  if (!API_KEY) return { provider: "YouTube", status: "needs_key", results: [], message: "Configure YOUTUBE_API_KEY para ativar esta fonte." };
  const phrases = [`${query} edit`, `${query} scene edit`, `${query} shorts`, `${query} fan edit`, `${query} scene`, `${query} corte`, `${query} clip`];
  const ids = new Set();
  let quotaCalls = 0;
  for (const phrase of phrases) {
    const data = await youtube("search", {
      part: "snippet", type: "video", q: phrase, maxResults: 25,
      order: sort === "recent" ? "date" : (sort === "views" ? "viewCount" : "relevance"),
      safeSearch: "moderate"
    });
    quotaCalls++;
    for (const item of data.items || []) if (item.id?.videoId) ids.add(item.id.videoId);
  }
  const idList = [...ids];
  const videoData = [];
  for (let i = 0; i < idList.length; i += 50) {
    const data = await youtube("videos", {
      part: "snippet,contentDetails,statistics,status", id: idList.slice(i, i + 50).join(",")
    });
    videoData.push(...(data.items || []));
  }
  const min = Math.max(0, target - tolerance), max = target + tolerance;
  const results = videoData.map(v => {
    const seconds = isoDurationToSeconds(v.contentDetails?.duration);
    const title = v.snippet?.title || "", description = v.snippet?.description || "";
    const isRelevant = relevantTitle(title, description, query);
    const editSignals = /edit|shorts|short|scene|corte|fan.?made|amv|clip|compila/i.test(title);
    const durationMatch = seconds !== null && seconds >= min && seconds <= max;
    const views = v.statistics?.viewCount ? Number(v.statistics.viewCount) : null;
    let score = (normalize(title).includes(normalize(query)) ? 5 : 0) + (isRelevant ? 3 : 0) + (editSignals ? 2 : 0) + (durationMatch ? 4 : 0);
    return {
      id: `youtube:${v.id}`, source: "YouTube", sourceId: v.id, title,
      channel: v.snippet?.channelTitle || "Canal desconhecido",
      thumbnail: v.snippet?.thumbnails?.high?.url || v.snippet?.thumbnails?.medium?.url || v.snippet?.thumbnails?.default?.url || "",
      durationSeconds: seconds, views, publishedAt: v.snippet?.publishedAt || null,
      description: description.slice(0, 400), url: `https://www.youtube.com/watch?v=${v.id}`,
      embedUrl: `https://www.youtube-nocookie.com/embed/${v.id}`, score, isRelevant, durationMatch
    };
  }).filter(v => v.durationSeconds > 0 && v.isRelevant && v.durationMatch);
  return { provider: "YouTube", status: "ok", results, message: `${quotaCalls} buscas de metadados executadas.` };
}
async function searchArchive(query, target, tolerance) {
  if (!ARCHIVE_ENABLED) return { provider: "Internet Archive", status: "disabled", results: [], message: "Fonte desativada na configuração." };
  // Internet Archive is a public metadata catalog, not a dedicated catalog of modern fan edits.
  // Only return records whose title/description are relevant and whose metadata includes a matching duration.
  const url = new URL("https://archive.org/advancedsearch.php");
  url.searchParams.set("q", `(${query.replace(/[+\-&|!(){}\\[\]^"~*?:/]/g, " ")} ) AND mediatype:(movies)`);
  url.searchParams.set("fl[]", "identifier,title,description,creator,date,runtime,year");
  url.searchParams.set("rows", "100");
  url.searchParams.set("page", "1");
  url.searchParams.set("output", "json");
  const data = await fetchJson(url, "Internet Archive");
  const docs = data?.response?.docs || [];
  const min = Math.max(0, target - tolerance), max = target + tolerance;
  const results = docs.map(d => {
    let seconds = null;
    const raw = d.runtime;
    if (typeof raw === "number") seconds = raw > 1000 ? Math.round(raw / 1000) : Math.round(raw);
    else if (raw) {
      const s = String(Array.isArray(raw) ? raw[0] : raw).trim();
      if (/^\d+:\d{2}(:\d{2})?$/.test(s)) {
        const p = s.split(":").map(Number);
        seconds = p.length === 3 ? p[0]*3600+p[1]*60+p[2] : p[0]*60+p[1];
      } else if (/^\d+(\.\d+)?$/.test(s)) seconds = Math.round(Number(s));
    }
    const title = Array.isArray(d.title) ? d.title[0] : (d.title || d.identifier || "Vídeo do Internet Archive");
    const description = Array.isArray(d.description) ? d.description.join(" ") : (d.description || "");
    const identifier = d.identifier;
    const isRelevant = relevantTitle(title, description, query);
    const durationMatch = seconds !== null && seconds >= min && seconds <= max;
    return {
      id: `archive:${identifier}`, source: "Internet Archive", sourceId: identifier, title,
      channel: Array.isArray(d.creator) ? d.creator.join(", ") : (d.creator || "Internet Archive"),
      thumbnail: `https://archive.org/services/img/${encodeURIComponent(identifier)}`,
      durationSeconds: seconds, views: null, publishedAt: d.date || d.year || null,
      description: String(description).slice(0, 400),
      url: `https://archive.org/details/${encodeURIComponent(identifier)}`,
      embedUrl: `https://archive.org/embed/${encodeURIComponent(identifier)}`,
      score: isRelevant ? 2 : 0, isRelevant, durationMatch
    };
  }).filter(v => v.isRelevant && v.durationMatch && v.durationSeconds > 0);
  return { provider: "Internet Archive", status: "ok", results, message: "Catálogo público de metadados consultado; nem sempre contém cortes editados recentes." };
}
app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    app: "PRIME CORTES INTELIGENTE",
    providers: [
      { id: "youtube", name: "YouTube", configured: Boolean(API_KEY), status: API_KEY ? "ready" : "needs_key", detail: API_KEY ? "Chave configurada" : "Precisa de chave da API oficial" },
      { id: "archive", name: "Internet Archive", configured: ARCHIVE_ENABLED, status: ARCHIVE_ENABLED ? "ready" : "disabled", detail: ARCHIVE_ENABLED ? "Pesquisa pública de metadados; catálogo limitado para cortes" : "Desativado" },
      { id: "tiktok", name: "TikTok", configured: false, status: "restricted", detail: "Integração não ativada: a API de pesquisa tem acesso restrito a pesquisadores aprovados" }
    ]
  });
});
app.get("/api/search", async (req, res) => {
  const query = String(req.query.q || "").trim();
  const target = Number(req.query.seconds || 40);
  const tolerance = Number(req.query.tolerance ?? 10);
  const sort = String(req.query.sort || "relevance");
  if (query.length < 2) return res.status(400).json({ error: "Digite o nome de um filme ou série." });
  if (!Number.isFinite(target) || target < 1 || target > 7200) return res.status(400).json({ error: "Duração inválida." });
  if (!Number.isFinite(tolerance) || tolerance < 0 || tolerance > 600) return res.status(400).json({ error: "Tolerância inválida." });
  const settled = await Promise.allSettled([
    searchYouTube(query, target, tolerance, sort),
    searchArchive(query, target, tolerance)
  ]);
  const providers = settled.map((item, i) => {
    const name = i === 0 ? "YouTube" : "Internet Archive";
    if (item.status === "fulfilled") return item.value;
    return { provider: name, status: "error", results: [], message: item.reason?.message || "Falha ao consultar a fonte." };
  });
  const results = providers.flatMap(p => p.results || []);
  const unique = [...new Map(results.map(v => [v.id, v])).values()];
  unique.sort((a, b) => {
    if (sort === "views") return (b.views || 0) - (a.views || 0);
    if (sort === "recent") return new Date(b.publishedAt || 0) - new Date(a.publishedAt || 0);
    if (sort === "duration") return Math.abs(a.durationSeconds - target) - Math.abs(b.durationSeconds - target);
    return (b.score || 0) - (a.score || 0);
  });
  const active = providers.filter(p => p.status === "ok").length;
  res.json({
    query, targetSeconds: target, toleranceSeconds: tolerance, results: unique.slice(0, 80),
    providers: providers.map(p => ({ provider: p.provider, status: p.status, count: (p.results || []).length, message: p.message })),
    note: "O sistema consulta fontes independentes e só mostra resultados com duração encontrada nos metadados dentro da tolerância. A relação com a obra depende dos metadados publicados; confirme antes de usar.",
    summary: `${active} fonte(s) consultada(s).`
  });
});
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`PRIME CORTES INTELIGENTE em http://localhost:${PORT}`));
