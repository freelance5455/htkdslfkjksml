const $ = id => document.getElementById(id);
let lastQuery = "", lastSeconds = 40, lastTolerance = 10, currentResults = [];
const LIB_KEY = "primeCortesLibraryV2";
const fmtDuration = s => {
  if (s == null) return "Duração não informada";
  if (s < 60) return `${s}s`;
  return `${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;
};
const fmtViews = n => n == null ? "Visualizações indisponíveis" : `${Number(n).toLocaleString("pt-BR")} visualizações`;
const fmtDate = d => d ? new Date(d).toLocaleDateString("pt-BR") : "Data indisponível";
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function libraryGet(){try{return JSON.parse(localStorage.getItem(LIB_KEY)||"[]")}catch{return []}}
function librarySet(items){localStorage.setItem(LIB_KEY,JSON.stringify(items));renderLibrary()}
function isSaved(id){return libraryGet().some(v=>v.id===id)}
function cardHTML(v){
  const saved = isSaved(v.id);
  return `<article class="video-card">
    <div class="thumb-wrap"><img class="thumb" loading="lazy" src="${esc(v.thumbnail)}" alt="" onerror="this.style.opacity='.2'"><span class="duration">${fmtDuration(v.durationSeconds)}</span></div>
    <div class="card-content"><div class="source-label">${esc(v.source || "Fonte")}</div><div class="video-title">${esc(v.title)}</div><div class="channel">${esc(v.channel)}</div>
    <div class="meta"><span>${esc(fmtViews(v.views))}</span><span>${esc(fmtDate(v.publishedAt))}</span></div>
    <div class="actions"><button class="watch" data-action="watch" data-id="${esc(v.id)}">Assistir</button><button data-action="save" data-id="${esc(v.id)}">${saved?"Salvo ✓":"♡ Salvar"}</button><button data-action="share" data-id="${esc(v.id)}">↗</button></div>
    </div></article>`;
}
function renderLibrary(){
  const items=libraryGet();
  $("library").innerHTML=items.map(cardHTML).join("");
  $("libraryEmpty").classList.toggle("hidden",items.length>0);
}
function showMessage(text){$("message").textContent=text;$("message").classList.remove("hidden")}
function clearMessage(){$("message").textContent="";$("message").classList.add("hidden")}
function setProvider(id, status, detail){
  const el = $(id); if (!el) return;
  el.textContent = detail;
  const chip = el.closest(".provider-chip");
  chip.classList.remove("provider-ready","provider-error","provider-warn");
  chip.classList.add(status === "ready" ? "provider-ready" : status === "error" ? "provider-error" : "provider-warn");
}
async function loadHealth(){
  try {
    const r = await fetch("/api/health"); const d = await r.json();
    for (const p of d.providers || []) {
      if (p.id === "youtube") setProvider("youtubeStatus", p.status === "ready" ? "ready" : "warn", p.detail);
      if (p.id === "archive") setProvider("archiveStatus", p.status === "ready" ? "ready" : "warn", p.detail);
      if (p.id === "tiktok") setProvider("tiktokStatus", "warn", p.detail);
    }
  } catch {
    setProvider("youtubeStatus","error","Servidor indisponível");
    setProvider("archiveStatus","error","Servidor indisponível");
  }
}
function renderProviderResults(providers){
  if (!providers?.length) return;
  const text = providers.map(p => `${p.provider}: ${p.count} resultado(s)`).join(" · ");
  $("status").textContent += ` Fontes: ${text}.`;
}
async function search(){
  const query=$("query").value.trim();
  const seconds=$("seconds").value==="custom"?Number($("customSeconds").value):Number($("seconds").value);
  const tolerance=Number($("tolerance").value);
  if(query.length<2){showMessage("Digite o nome de um filme ou série.");return}
  if(!Number.isFinite(seconds)||seconds<1){showMessage("Informe uma duração válida.");return}
  lastQuery=query;lastSeconds=seconds;lastTolerance=tolerance;currentResults=[];
  $("results").innerHTML=""; $("moreButton").classList.add("hidden");
  $("searchButton").disabled=true;
  $("status").textContent="Pesquisando nas fontes conectadas e conferindo a duração...";
  clearMessage();
  try{
    const params=new URLSearchParams({q:lastQuery,seconds:lastSeconds,tolerance:lastTolerance,sort:$("sort").value});
    const response=await fetch(`/api/search?${params.toString()}`);
    const data=await response.json();
    if(!response.ok)throw new Error(data.error||"Não foi possível pesquisar.");
    currentResults=data.results||[];
    $("results").innerHTML=currentResults.map(cardHTML).join("");
    $("resultsTitle").textContent=`Cortes: ${lastQuery}`;
    $("status").textContent=`${currentResults.length} resultado(s) entre ${Math.max(0,lastSeconds-lastTolerance)} e ${lastSeconds+lastTolerance} segundos. `;
    renderProviderResults(data.providers);
    if(!currentResults.length)showMessage("Nenhum resultado confirmado com duração conhecida nessa faixa. Isso não significa que o corte não exista. Tente outro título, uma tolerância maior ou aguarde a conexão de novas fontes.");
    else if(data.note)showMessage(data.note);
    for (const p of data.providers || []) {
      if (p.provider === "YouTube") setProvider("youtubeStatus", p.status === "ok" ? "ready" : p.status === "error" ? "error" : "warn", `${p.count} resultado(s) · ${p.message}`);
      if (p.provider === "Internet Archive") setProvider("archiveStatus", p.status === "ok" ? "ready" : p.status === "error" ? "error" : "warn", `${p.count} resultado(s) · ${p.message}`);
    }
  }catch(err){showMessage(`${err.message} Confira a configuração do servidor no README.`);$("status").textContent="A pesquisa não foi concluída."}
  finally{$("searchButton").disabled=false}
}
$("searchForm").addEventListener("submit",e=>{e.preventDefault();search()});
$("seconds").addEventListener("change",()=> $("customWrap").classList.toggle("hidden",$("seconds").value!=="custom"));
$("sort").addEventListener("change",()=>{if(lastQuery)search()});
document.querySelectorAll(".example").forEach(b=>b.addEventListener("click",()=>{$("query").value=b.dataset.q;search()}));
document.body.addEventListener("click",async e=>{
 const b=e.target.closest("[data-action]");if(!b)return;
 const v=[...currentResults,...libraryGet()].find(x=>x.id===b.dataset.id);if(!v)return;
 if(b.dataset.action==="watch"){
   $("playerTitle").textContent=v.title;$("openYoutube").href=v.url;
   $("playerFrame").innerHTML=`<iframe src="${esc(v.embedUrl)}?autoplay=1" title="${esc(v.title)}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`;
   $("playerModal").classList.remove("hidden");
 }else if(b.dataset.action==="save"){
   const items=libraryGet();
   if(items.some(x=>x.id===v.id))librarySet(items.filter(x=>x.id!==v.id));else librarySet([v,...items]);
   $("results").innerHTML=currentResults.map(cardHTML).join("");
 }else if(b.dataset.action==="share"){
   try{if(navigator.share)await navigator.share({title:v.title,url:v.url});else if(navigator.clipboard){await navigator.clipboard.writeText(v.url);showMessage("Link copiado para compartilhar.")}else window.open(v.url,"_blank","noopener")}catch{}
 }
});
$("closePlayer").addEventListener("click",()=>{$("playerModal").classList.add("hidden");$("playerFrame").innerHTML=""});
$("playerModal").addEventListener("click",e=>{if(e.target===$("playerModal")){$("playerModal").classList.add("hidden");$("playerFrame").innerHTML=""}});
$("clearLibrary").addEventListener("click",()=>{if(confirm("Deseja remover todos os vídeos salvos?"))librarySet([])});
$("homeNav").addEventListener("click",()=>window.scrollTo({top:0,behavior:"smooth"}));
$("searchNav").addEventListener("click",()=>{$("query").focus()});
renderLibrary(); loadHealth();
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));
