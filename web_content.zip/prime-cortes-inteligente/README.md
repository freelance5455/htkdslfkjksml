# PRIME CORTES INTELIGENTE — edição multifonte

Aplicativo web instalável (PWA) para pesquisar cortes/vídeos por título e duração, consultar fontes separadas, filtrar pela duração informada nos metadados, assistir pela própria plataforma, compartilhar links e salvar uma biblioteca local.

## O que esta versão inclui

- **YouTube Data API v3** como fonte principal, com busca por termos relacionados a edits/cenas/clipes e verificação da duração real retornada pela API.
- **Internet Archive** como segunda fonte opcional de catálogo público. Só são mostrados resultados quando o catálogo fornece duração que se encaixa na faixa escolhida. O acervo não é especializado em edits recentes, então pode retornar poucos ou nenhum resultado.
- **Painel de status por fonte** no aplicativo, para mostrar se está configurada, consultada ou indisponível.
- Filtro de duração, tolerância, ordenação, remoção de duplicados, player incorporado, abertura na fonte original, compartilhamento e biblioteca local.
- Interface responsiva com tema escuro e base PWA instalável.

## Limites importantes — sem promessas falsas

Não existe uma API universal que pesquise automaticamente dentro de todos os aplicativos. Cada serviço precisa ter uma API oficial, acesso permitido ou catálogo público. Esta versão já implementa duas fontes independentes; as outras devem ser adicionadas como adaptadores próprios.

**TikTok:** não está conectado nesta versão. A API de pesquisa do TikTok tem acesso restrito a pesquisadores qualificados/aprovados e não é uma integração que se possa prometer para qualquer conta comercial.

O app não baixa vídeos protegidos nem contorna controles de plataformas. Ele apresenta links e players disponibilizados pelas próprias fontes. A duração e os metadados ajudam a filtrar, mas não garantem que todo vídeo seja exatamente a cena desejada; confira antes de publicar.

## Requisito

Node.js 18 ou superior.

## Configuração da API do YouTube

1. Abra https://console.cloud.google.com/
2. Crie/seleciona um projeto.
3. Ative **YouTube Data API v3**.
4. Crie uma chave de API e restrinja seu uso de acordo com a hospedagem.
5. Configure a variável de ambiente `YOUTUBE_API_KEY` no servidor. Nunca coloque a chave no frontend ou publique em repositório.

A busca do YouTube consome cota da API. A aplicação consulta várias frases para ampliar os resultados, portanto monitore a cota e evite executar pesquisas repetidas sem necessidade.

## Rodar localmente

```bash
npm install
```

Linux/macOS:
```bash
export YOUTUBE_API_KEY="SUA_CHAVE"
npm start
```

Windows PowerShell:
```powershell
$env:YOUTUBE_API_KEY="SUA_CHAVE"
npm start
```

Opcional: desativar Internet Archive:
```powershell
$env:INTERNET_ARCHIVE_ENABLED="false"
npm start
```

Abra http://localhost:3000.

## Hospedar e instalar no Android

Hospede em um serviço que execute Node.js e configure `YOUTUBE_API_KEY` como segredo/variável de ambiente. Use HTTPS. Depois, abra a URL no Chrome do Android e escolha **Instalar app** ou **Adicionar à tela inicial**, quando disponível.

## O que falta para produção

- Configurar uma chave real da YouTube Data API.
- Testar buscas reais com `Sobrenatural`, `The Flash` e `Titanic` em diferentes durações.
- Adicionar outros provedores somente quando houver API/acesso permitido e metadados de duração utilizáveis.
- Se houver muitos usuários, adicionar cache, limites por usuário, monitoramento de cota e testes automatizados.

**Transparência:** o pacote é o código-fonte do aplicativo, não uma hospedagem online já ativada. Sem chave configurada e servidor publicado, a busca real do YouTube não estará ativa. O acesso ao Internet Archive é tentado pelo backend quando a aplicação está rodando e o servidor tem internet.
