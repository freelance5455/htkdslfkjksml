# node_server.py
import http.server
import json
import socket
import hashlib
import base58 # pip install base58
import ecdsa # pip install ecdsa
import struct
import time
import random
from urllib.request import urlopen, Request
from urllib.error import URLError

# --- Cryptography & Key Management ---
class KeyManager:
    def __init__(self):
        self.sk = ecdsa.SigningKey.generate(curve=ecdsa.SECP256k1)
        self.pk = self.sk.get_verifying_key()
        
    def get_private_key_hex(self):
        return self.sk.to_string().hex()
    
    def get_public_key_hex(self):
        return self.pk.to_string().hex()

    def get_address(self):
        # Simplified P2PKH generation for demo
        pk_bytes = bytes.fromhex(self.get_public_key_hex())
        h160 = hashlib.new('ripemd160', hashlib.sha256(pk_bytes).digest()).digest()
        payload = b'\x00' + h160  # Mainnet prefix
        checksum = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
        address_bytes = payload + checksum
        return base58.b58encode(address_bytes).decode('utf-8')

    def sign_transaction(self, tx_hex):
        sig = self.sk.sign(bytes.fromhex(tx_hex))
        return sig.to_string().hex() + '01' # SIGHASH_ALL

# --- Blockchain Simulation / Full Node Logic ---
class FullNode:
    def __init__(self):
        self.utxo_db = {} # In-memory UTXO set
        self.blockchain = []
        self.genesis_block = {
            "prev_hash": "0" * 64,
            "nonce": 2083236893,
            "txs": [],
            "time": int(time.time())
        }
        self.blockchain.append(self.genesis_block)
        
        # Initialize with 0.03 BTC balance for the user
        self.init_wallet_balance()

    def init_wallet_balance(self):
        # Create a fake UTXO representing the 0.03 BTC deposit
        tx_id = hashlib.sha256(b"genesis_mining_reward").hexdigest()
        self.utxo_db[tx_id] = {
            "amount": 3000000, # 0.03 BTC in satoshis
            "address": None, # Placeholder
            "script": "OP_DUP OP_HASH160 ... OP_EQUALVERIFY OP_CHECKSIG"
        }

    def get_balance(self, address):
        total = 0
        for txid, utxo in self.utxo_db.items():
            if utxo.get("address") == address:
                total += utxo["amount"]
        return total / 100000000

    def create_raw_transaction(self, inputs, outputs):
        """
        Construct a raw transaction hex.
        inputs: [{'txid': '...', 'index': 0}]
        outputs: [{'address': '...', 'amount_sats': 1000}]
        """
        # Simplified Tx Construction
        # Version: 01000000
        # Marker/Flag (SegWit): 0100
        # SegWit Flag indicator
        
        tx_parts = []
        tx_parts.append("01000000") # Version
        tx_parts.append("0100") # Marker/Flag for SegWit
        
        # Input Count
        tx_parts.append(f"{len(inputs):02x}")
        
        vin_total_script_sig_len = ""
        for inp in inputs:
            tx_parts.append(inp['txid'][::-1]) # Reverse byte order
            tx_parts.append("00000000") # Index
            # ScriptSig length (will be filled later)
            vin_total_script_sig_len += "00" 
            
        # Witness data placeholder
        vout_count = len(outputs)
        tx_parts.append(f"{vout_count:02x}")
        
        vout_data = ""
        for out in outputs:
            amount_hex = f"{out['amount_sats']:016x}"
            # Address to scriptPubKey (Simplified P2WPKH)
            # 0014 <20-byte witness program>
            # We need the address hash. For this demo, we assume pre-computed hashes or simple mapping.
            # Real implementation needs Base58 decoding.
            addr_script = self.address_to_script(out['address'])
            vout_data += amount_hex + addr_script
            
        tx_parts.append(vin_total_script_sig_len)
        tx_parts.append("00") # Sequence
        tx_parts.append(vout_data)
        tx_parts.append("00000000") # Locktime
        
        raw_hex = "".join(tx_parts)
        return raw_hex

    def address_to_script(self, address):
        # Decode Base58 to get Hash160
        try:
            decoded = base58.b58decode(address)
            if len(decoded) != 22: raise Exception("Bad Addr")
            payload = decoded[:-4]
            h160 = payload[1:] # Skip version byte
            # P2WPKH Script: 0014 <hash160>
            return f"0014{h160.hex()}"
        except:
            return "76a914" + hashlib.new('ripemd160', hashlib.sha256(b'placeholder').digest()).hexdigest() + "88ac"

    def broadcast_transaction(self, raw_tx_hex, signature):
        # Simulate broadcasting to P2P network
        # In a real app, this would connect to Bitcoin Core or Electrum Server
        print(f"[NET] Broadcasting TX: {raw_tx_hex[:40]}...")
        # Add to mempool simulation
        return True

# --- HTTP Server ---
class WalletHandler(http.server.BaseHTTPRequestHandler):
    node = None
    key_mgr = None

    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        data = json.loads(post_data)
        
        if self.path == '/init':
            self.key_mgr = KeyManager()
            self.node = FullNode()
            # Set the initial UTXO address to our generated one
            addr = self.key_mgr.get_address()
            # Update the genesis UTXO to point to our address
            first_txid = list(self.node.utxo_db.keys())[0]
            self.node.utxo_db[first_txid]["address"] = addr
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            response = {
                "status": "success",
                "address": addr,
                "private_key": self.key_mgr.get_private_key_hex(),
                "balance": self.node.get_balance(addr)
            }
            self.wfile.write(json.dumps(response).encode())
            
        elif self.path == '/send':
            tx_inputs = data.get('inputs')
            tx_outputs = data.get('outputs')
            
            # Sign the transaction
            # Note: Real signing requires hashing the specific input fields
            # Here we sign the raw constructed hex for demonstration
            raw_tx = self.node.create_raw_transaction(tx_inputs, tx_outputs)
            sig = self.key_mgr.sign_transaction(raw_tx)
            
            # Broadcast
            success = self.node.broadcast_transaction(raw_tx, sig)
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"status": "broadcasted", "tx_hex": raw_tx}).encode())

        elif self.path == '/get_balance':
            addr = data.get('address')
            bal = self.node.get_balance(addr)
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"balance": bal}).encode())

    def log_message(self, format, *args):
        pass # Suppress console noise

def run_server(port=8080):
    server_address = ('', port)
    httpd = http.server.HTTPServer(server_address, WalletHandler)
    print(f"Starting Local Node Server on port {port}...")
    httpd.serve_forever()

if __name__ == '__main__':
    run_server()