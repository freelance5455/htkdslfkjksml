// Barrier shape library for the fluid dynamics simulation.
// Each entry: { name: string, group: string, locations: [x0,y0, x1,y1, ...] }
// The first 11 shapes are the original hand-placed presets; the rest are
// generated programmatically below with small rasterization helpers, and the
// simulation auto-fits any shape to the current grid size when placed.

var barrierList = (function () {

        // ---------- rasterization helpers (all return flat [x,y,x,y,...] arrays) ----------

        // Remove duplicate points from a flat coordinate list.
        function dedupe(pts) {
                var seen = {}, out = [];
                for (var i = 0; i < pts.length; i += 2) {
                        var key = pts[i] + ',' + pts[i + 1];
                        if (!seen[key]) { seen[key] = 1; out.push(pts[i], pts[i + 1]); }
                }
                return out;
        }

        // Straight line between two points (DDA).
        function line(x0, y0, x1, y1) {
                var pts = [];
                var dx = x1 - x0, dy = y1 - y0;
                var steps = Math.max(Math.abs(dx), Math.abs(dy), 1);
                for (var i = 0; i <= steps; i++) {
                        pts.push(Math.round(x0 + dx * i / steps), Math.round(y0 + dy * i / steps));
                }
                return pts;
        }

        // Axis-aligned rectangle, filled or outline only.
        function rect(x0, y0, x1, y1, filled) {
                if (filled) {
                        var pts = [];
                        for (var y = y0; y <= y1; y++)
                                for (var x = x0; x <= x1; x++) pts.push(x, y);
                        return pts;
                }
                return [].concat(line(x0, y0, x1, y0), line(x1, y0, x1, y1),
                                 line(x1, y1, x0, y1), line(x0, y1, x0, y0));
        }

        // Ellipse (or circle when rx == ry), filled or hollow with given wall thickness.
        function ellipse(cx, cy, rx, ry, filled, thickness) {
                var pts = [];
                var t = thickness || 2;
                var irx = rx - t, iry = ry - t;
                for (var y = Math.ceil(cy - ry); y <= Math.floor(cy + ry); y++) {
                        for (var x = Math.ceil(cx - rx); x <= Math.floor(cx + rx); x++) {
                                var nx = (x - cx) / rx, ny = (y - cy) / ry;
                                if (nx * nx + ny * ny > 1) continue;
                                if (!filled) {
                                        var mx = irx > 0 ? (x - cx) / irx : 0;
                                        var my = iry > 0 ? (y - cy) / iry : 0;
                                        if (mx * mx + my * my < 1) continue;
                                }
                                pts.push(x, y);
                        }
                }
                return pts;
        }

        function circle(cx, cy, r, filled, thickness) {
                return ellipse(cx, cy, r, r, filled, thickness);
        }

        // Filled polygon from a vertex list [[x,y], ...]; edges are stroked too so the
        // outline is always complete.
        function polygon(verts) {
                var pts = [];
                var minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
                var i, j;
                for (i = 0; i < verts.length; i++) {
                        minX = Math.min(minX, verts[i][0]); maxX = Math.max(maxX, verts[i][0]);
                        minY = Math.min(minY, verts[i][1]); maxY = Math.max(maxY, verts[i][1]);
                }
                for (var y = Math.floor(minY); y <= Math.ceil(maxY); y++) {
                        for (var x = Math.floor(minX); x <= Math.ceil(maxX); x++) {
                                var inside = false;
                                for (i = 0, j = verts.length - 1; i < verts.length; j = i++) {
                                        var xi = verts[i][0], yi = verts[i][1];
                                        var xj = verts[j][0], yj = verts[j][1];
                                        if (((yi > y) != (yj > y)) &&
                                            (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) inside = !inside;
                                }
                                if (inside) pts.push(x, y);
                        }
                }
                for (i = 0; i < verts.length; i++) {
                        var a = verts[i], b = verts[(i + 1) % verts.length];
                        pts = pts.concat(line(a[0], a[1], b[0], b[1]));
                }
                return pts;
        }

        function union() {
                var pts = [];
                for (var a = 0; a < arguments.length; a++) pts = pts.concat(arguments[a]);
                return pts;
        }

        function subtract(a, b) {
                var kill = {};
                for (var i = 0; i < b.length; i += 2) kill[b[i] + ',' + b[i + 1]] = 1;
                var out = [];
                for (i = 0; i < a.length; i += 2) {
                        if (!kill[a[i] + ',' + a[i + 1]]) out.push(a[i], a[i + 1]);
                }
                return out;
        }

        // Star vertices: n spikes, alternating outer/inner radius.
        function starVerts(cx, cy, rO, rI, n) {
                var verts = [];
                for (var k = 0; k < 2 * n; k++) {
                        var ang = -Math.PI / 2 + k * Math.PI / n;
                        var r = (k % 2 === 0) ? rO : rI;
                        verts.push([Math.round(cx + r * Math.cos(ang)), Math.round(cy + r * Math.sin(ang))]);
                }
                return verts;
        }

        // Rotate a vertex list counterclockwise by the given angle (degrees).
        function rotateVerts(verts, deg) {
                var rad = deg * Math.PI / 180;
                var c = Math.cos(rad), s = Math.sin(rad);
                var out = [];
                for (var i = 0; i < verts.length; i++) {
                        out.push([verts[i][0] * c - verts[i][1] * s,
                                  verts[i][0] * s + verts[i][1] * c]);
                }
                return out;
        }

        // Streamline "teardrop" body, built by scanning half-widths: rounded blunt
        // nose upstream, maximum width at the nose fraction, long tapering tail.
        // L = total length, R = maximum half-width, nf = nose fraction, p = tail power.
        function teardrop(L, R, nf, p) {
                var x0 = -L / 2, xn = x0 + nf * L;
                var verts = [], i, x;
                for (x = x0; x <= xn; x += 1) {
                        var f = (xn - x) / (nf * L);
                        verts.push([x, R * Math.sqrt(Math.max(0, 1 - f * f))]);
                }
                for (x = xn + 1; x <= L / 2; x += 1) {
                        verts.push([x, R * Math.pow(Math.max(0, 1 - (x - xn) / (L / 2 - xn)), p)]);
                }
                var lower = [];
                for (i = verts.length - 1; i >= 0; i--) lower.push([verts[i][0], -verts[i][1]]);
                return verts.concat(lower);
        }

        // Bullet: round ogive nose, straight shank, boat-tailed base.
        function bullet(L, R, noseLen, tailLen, tailR) {
                var x0 = -L / 2, xn = x0 + noseLen, xt = L / 2 - tailLen;
                var verts = [], i, x;
                for (x = x0; x <= xn; x += 1) {
                        var f = Math.max(0, (xn - x) / noseLen);
                        verts.push([x, R * Math.sqrt(Math.max(0, 1 - f * f))]);
                }
                for (x = xn + 1; x <= xt; x += 1) verts.push([x, R]);
                for (x = xt + 1; x <= L / 2; x += 1) {
                        var f2 = (x - xt) / tailLen;
                        verts.push([x, R + (tailR - R) * f2 * f2]);
                }
                var lower = [];
                for (i = verts.length - 1; i >= 0; i--) lower.push([verts[i][0], -verts[i][1]]);
                return verts.concat(lower);
        }

        // NACA-style airfoil outline: chord c, thickness ratio t, optional camber
        // (m = max camber fraction, p = its position). Leading edge is upstream (left).
        function nacaFoil(c, t, m, p) {
                var verts = [];
                function yt(xh) {
                        return 5 * t * c * (0.2969 * Math.sqrt(xh) - 0.1260 * xh
                                - 0.3516 * xh * xh + 0.2843 * xh * xh * xh - 0.1015 * xh * xh * xh * xh);
                }
                function yc(xh) {
                        if (!m) return 0;
                        if (xh < p) return m / (p * p) * (2 * p * xh - xh * xh);
                        return m / ((1 - p) * (1 - p)) * ((1 - 2 * p) + 2 * p * xh - xh * xh);
                }
                var steps = Math.max(24, Math.round(c));
                var i;
                for (i = 0; i <= steps; i++) {
                        var xh = i / steps;
                        verts.push([-c / 2 + xh * c, yc(xh) + yt(xh)]);
                }
                for (i = steps - 1; i > 0; i--) {
                        var xh2 = i / steps;
                        verts.push([-c / 2 + xh2 * c, yc(xh2) - yt(xh2)]);
                }
                return verts;
        }

        var shapes = [];
        function add(name, group, pts) {
                shapes.push({ name: name, group: group, locations: dedupe(pts) });
        }

        // ---------- original presets (kept verbatim) ----------

        shapes.push({ name: "Short line", group: "Plates & lines", locations: [
                12,15, 12,16, 12,17, 12,18, 12,19, 12,20, 12,21, 12,22, 12,23] });

        shapes.push({ name: "Long line", group: "Plates & lines", locations: [
                13,11, 13,12, 13,13, 13,14, 13,15, 13,16, 13,17, 13,18, 13,19, 13,20,
                13,21, 13,22, 13,23, 13,24, 13,25, 13,26, 13,27, 13,28] });

        shapes.push({ name: "Diagonal", group: "Plates & lines", locations: [
                30,14, 29,15, 30,15, 28,16, 29,16, 27,17, 28,17, 26,18, 27,18, 25,19,
                26,19, 24,20, 25,20, 23,21, 24,21, 22,22, 23,22, 21,23, 22,23, 20,24,
                21,24, 19,25, 20,25, 18,26, 19,26, 17,27, 18,27, 16,28, 17,28, 15,29,
                16,29, 14,30, 15,30, 13,31, 14,31] });

        shapes.push({ name: "Shallow diagonal", group: "Plates & lines", locations: [
                47,18, 48,18, 49,18, 50,18, 44,19, 45,19, 46,19, 47,19, 41,20, 42,20,
                43,20, 44,20, 38,21, 39,21, 40,21, 41,21, 35,22, 36,22, 37,22, 38,22,
                32,23, 33,23, 34,23, 35,23, 29,24, 30,24, 31,24, 32,24, 26,25, 27,25,
                28,25, 29,25, 23,26, 24,26, 25,26, 26,26, 20,27, 21,27, 22,27, 23,27,
                17,28, 18,28, 19,28, 20,28] });

        shapes.push({ name: "Line with spoiler", group: "Plates & lines", locations: [
                16,20, 16,21, 16,22, 16,23, 16,24, 17,24, 18,24, 19,24, 20,24, 21,24,
                22,24, 23,24, 24,24, 25,24, 26,24, 27,24, 28,24, 29,24, 30,24, 31,24,
                32,24, 33,24, 34,24, 35,24, 36,24, 37,24, 38,24, 39,24, 40,24, 41,24,
                42,24, 43,24, 44,24, 45,24, 46,24, 47,24, 48,24, 49,24, 50,24, 16,25,
                16,26, 16,27, 16,28] });

        // ---------- generated presets ----------

        // Perforated plate: vertical wall with regular gaps (bluff-body grid / flow straightener).
        var perf = [];
        for (var k = 0; k < 4; k++) perf = perf.concat(line(0, k * 12 - 21, 0, k * 12 - 14));
        add("Perforated plate", "Plates & lines", perf);

        // Wall with a center gap (channel / nozzle test).
        add("Wall with gap", "Plates & lines",
            union(line(0, -24, 0, -6), line(0, 6, 0, 24)));

        add("Square", "Bluff bodies", rect(-7, -7, 7, 7, true));

        add("Triangle", "Bluff bodies", polygon([[-14, 12], [14, 12], [0, -12]]));

        add("Diamond", "Bluff bodies", polygon([[0, -15], [11, 0], [0, 15], [-11, 0]]));

        add("Ellipse", "Bluff bodies", ellipse(0, 0, 17, 9, true));

        add("Hexagon", "Bluff bodies",
            polygon([[13, 0], [7, 11], [-7, 11], [-13, 0], [-7, -11], [7, -11]]));

        add("Cross", "Bluff bodies",
            union(rect(-4, -16, 4, 16, true), rect(-16, -4, 16, 4, true)));

        add("Star", "Bluff bodies", polygon(starVerts(0, 0, 16, 7, 5)));

        // Ring (annulus): flow through and around the hole.
        add("Ring", "Bluff bodies",
            subtract(circle(0, 0, 14, true), circle(0, 0, 9, true)));

        // Cylinder with a downstream splitter plate (classic vortex-suppression study).
        add("Cylinder + splitter", "Composite",
            union(circle(0, 0, 11, true), line(11, 0, 36, 0)));

        // Two cylinders in tandem (front-back along the flow).
        add("Tandem circles", "Composite",
            union(circle(-11, 0, 9, true), circle(11, 0, 9, true)));

        // Two cylinders side by side (across the flow).
        add("Side-by-side circles", "Composite",
            union(circle(0, -11, 9, true), circle(0, 11, 9, true)));

        add("Hollow square", "Composite",
            subtract(rect(-8, -8, 8, 8, true), rect(-5, -5, 5, 5, true)));

        // 3x3 array of small blocks.
        var gridPts = [];
        for (var gi = -1; gi <= 1; gi++)
                for (var gj = -1; gj <= 1; gj++)
                        gridPts = gridPts.concat(rect(gi * 10 - 2, gj * 10 - 2, gi * 10 + 2, gj * 10 + 2, true));
        add("Grid of blocks", "Composite", gridPts);

        // Vehicles and aerodynamic bodies are drawn NOSE-UPSTREAM: the default wind
        // blows rightward, so a stationary body faces the oncoming flow like a
        // wind-tunnel model (nose pointing left, tail trailing downstream).

        // Airplane silhouette (top view, nose pointing left into the wind).
        var plane = union(
                ellipse(0, 0, 30, 3, true),                                 // fuselage
                polygon([[-6, -1], [10, -15], [14, -14], [2, 0]]),          // left wing (swept back)
                polygon([[-6, 1], [10, 15], [14, 14], [2, 0]]),             // right wing
                polygon([[20, -1], [28, -9], [31, -8], [24, 0]]),           // left tailplane
                polygon([[20, 1], [28, 9], [31, 8], [24, 0]]));             // right tailplane
        add("Airplane", "Vehicles", plane);

        // Car silhouette (side view, nose pointing left into the wind, wheels down).
        var car = union(
                polygon([[-26, -6], [-26, -1], [-20, 2], [-12, 2], [-9, 7],
                         [6, 7], [10, 2], [20, 2], [26, -1], [26, -6]]),
                circle(-15, -6, 4, true),
                circle(15, -6, 4, true));
        add("Car", "Vehicles", car);

        // Big arrow pointing upwind (left).
        add("Arrow", "Vehicles",
            polygon([[20, -5], [-4, -5], [-4, -12], [-20, 0], [-4, 12], [-4, 5], [20, 5]]));

        // ---------- aerodynamic presets ----------

        // Classic minimum-drag streamline body.
        add("Teardrop", "Aerodynamic", polygon(teardrop(52, 10, 0.35, 1.6)));

        // Bullet: ogive nose, straight shank, boat-tailed base.
        add("Bullet", "Aerodynamic", polygon(bullet(44, 7, 16, 9, 4)));

        // Rocket: nose cone, body, nozzle and two swept tail fins.
        add("Rocket", "Aerodynamic", union(
                polygon([[-26, 0], [-8, -6], [-8, 6]]),                     // nose cone (left)
                rect(-8, -6, 18, 6, true),                                  // body
                polygon([[18, -3], [23, -5], [23, 5], [18, 3]]),            // nozzle
                polygon([[10, -5], [24, -14], [24, -5]]),                   // fin
                polygon([[10, 5], [24, 14], [24, 5]])));                    // fin

        // Symmetric NACA-style wing section.
        add("NACA airfoil", "Aerodynamic", polygon(nacaFoil(44, 0.18)));

        // Cambered wing section (lifts upward in the default flow).
        add("Cambered wing", "Aerodynamic", polygon(nacaFoil(44, 0.15, 0.06, 0.4)));

        // Symmetric wing held at 10 degrees angle of attack.
        add("Airfoil 10 deg AoA", "Aerodynamic", polygon(rotateVerts(nacaFoil(44, 0.15), -10)));

        // Sailplane (top view): slender fuselage, long straight wing, tail stabilizer.
        add("Glider", "Aerodynamic", union(
                ellipse(0, 0, 22, 2, true),
                rect(-10, -16, -7, 16, true),
                rect(14, -6, 17, 6, true)));

        // Paper dart (top view).
        add("Paper dart", "Aerodynamic", polygon([[-22, 0], [14, -13], [8, 0], [14, 13]]));

        // Submarine (side view): hull, conning tower, stern fin.
        add("Submarine", "Aerodynamic", union(
                ellipse(0, 0, 24, 6, true),
                polygon([[-6, 5], [8, 5], [5, 12], [-2, 12]]),
                polygon([[17, 3], [27, 9], [27, 3]])));

        // Cone: pointed minimum-resistance body.
        add("Cone", "Aerodynamic", polygon([[-20, 0], [16, -11], [16, 11]]));

        // ---------- remaining original presets ----------

        shapes.push({ name: "Small circle", group: "Bluff bodies", locations: [
                14,11, 15,11, 16,11, 17,11, 18,11, 13,12, 14,12, 18,12, 19,12, 12,13,
                13,13, 19,13, 20,13, 12,14, 20,14, 12,15, 20,15, 12,16, 20,16, 12,17,
                13,17, 19,17, 20,17, 13,18, 14,18, 18,18, 19,18, 14,19, 15,19, 16,19,
                17,19, 18,19] });

        shapes.push({ name: "Large circle", group: "Bluff bodies", locations: [
                19,11, 20,11, 21,11, 22,11, 23,11, 24,11, 17,12, 18,12, 19,12, 24,12,
                25,12, 26,12, 16,13, 17,13, 26,13, 27,13, 15,14, 16,14, 27,14, 28,14,
                14,15, 15,15, 28,15, 29,15, 14,16, 29,16, 13,17, 14,17, 29,17, 30,17,
                13,18, 30,18, 13,19, 30,19, 13,20, 30,20, 13,21, 30,21, 13,22, 14,22,
                29,22, 30,22, 14,23, 29,23, 14,24, 15,24, 28,24, 29,24, 15,25, 16,25,
                27,25, 28,25, 16,26, 17,26, 26,26, 27,26, 17,27, 18,27, 19,27, 24,27,
                25,27, 26,27, 19,28, 20,28, 21,28, 22,28, 23,28, 24,28] });

        shapes.push({ name: "Circle with spoiler", group: "Composite", locations: [
                29,36, 30,36, 31,36, 32,36, 33,36, 28,37, 29,37, 33,37, 34,37, 27,38,
                28,38, 34,38, 35,38, 27,39, 35,39, 27,40, 35,40, 36,40, 37,40, 38,40,
                39,40, 40,40, 41,40, 42,40, 43,40, 44,40, 45,40, 46,40, 47,40, 48,40,
                49,40, 50,40, 51,40, 52,40, 53,40, 54,40, 55,40, 56,40, 57,40, 58,40,
                59,40, 60,40, 61,40, 62,40, 63,40, 64,40, 65,40, 66,40, 67,40, 68,40,
                69,40, 27,41, 35,41, 27,42, 28,42, 34,42, 35,42, 28,43, 29,43, 33,43,
                34,43, 29,44, 30,44, 31,44, 32,44, 33,44] });

        shapes.push({ name: "Right angle", group: "Bluff bodies", locations: [
                27,36, 28,36, 29,36, 30,36, 31,36, 32,36, 33,36, 34,36, 35,36, 36,36,
                37,36, 38,36, 39,36, 40,36, 41,36, 42,36, 43,36, 44,36, 45,36, 46,36,
                47,36, 48,36, 49,36, 50,36, 51,36, 52,36, 53,36, 54,36, 55,36, 56,36,
                57,36, 58,36, 59,36, 60,36, 61,36, 62,36, 63,36, 64,36, 65,36, 66,36,
                67,36, 68,36, 69,36, 70,36, 71,36, 72,36, 73,36, 74,36, 75,36, 76,36,
                77,36, 78,36, 79,36, 27,37, 27,38, 27,39, 27,40, 27,41, 27,42, 27,43,
                27,44] });

        shapes.push({ name: "Wedge", group: "Bluff bodies", locations: [
                27,36, 28,36, 29,36, 30,36, 31,36, 32,36, 33,36, 34,36, 35,36, 36,36,
                37,36, 38,36, 39,36, 40,36, 41,36, 42,36, 43,36, 44,36, 45,36, 46,36,
                47,36, 48,36, 49,36, 50,36, 51,36, 52,36, 53,36, 54,36, 55,36, 56,36,
                57,36, 58,36, 59,36, 60,36, 61,36, 62,36, 63,36, 64,36, 65,36, 66,36,
                67,36, 68,36, 69,36, 70,36, 71,36, 72,36, 73,36, 74,36, 75,36, 76,36,
                77,36, 78,36, 79,36, 27,37, 67,37, 68,37, 69,37, 70,37, 71,37, 72,37,
                73,37, 27,38, 61,38, 62,38, 63,38, 64,38, 65,38, 66,38, 67,38, 27,39,
                55,39, 56,39, 57,39, 58,39, 59,39, 60,39, 61,39, 27,40, 49,40, 50,40,
                51,40, 52,40, 53,40, 54,40, 55,40, 27,41, 43,41, 44,41, 45,41, 46,41,
                47,41, 48,41, 49,41, 27,42, 37,42, 38,42, 39,42, 40,42, 41,42, 42,42,
                43,42, 27,43, 31,43, 32,43, 33,43, 34,43, 35,43, 36,43, 37,43, 27,44,
                28,44, 29,44, 30,44, 31,44] });

        shapes.push({ name: "Airfoil", group: "Aerodynamic", locations: [
                17,16, 18,16, 19,16, 20,16, 21,16, 22,16, 23,16, 24,16, 25,16, 26,16,
                27,16, 28,16, 29,16, 30,16, 31,16, 32,16, 33,16, 34,16, 35,16, 36,16,
                37,16, 38,16, 39,16, 40,16, 41,16, 42,16, 43,16, 44,16, 45,16, 46,16,
                47,16, 48,16, 49,16, 50,16, 51,16, 52,16, 53,16, 54,16, 55,16, 56,16,
                57,16, 58,16, 59,16, 60,16, 61,16, 62,16, 63,16, 64,16, 65,16, 66,16,
                67,16, 68,16, 14,17, 15,17, 16,17, 17,17, 56,17, 57,17, 58,17, 59,17,
                60,17, 61,17, 62,17, 13,18, 14,18, 50,18, 51,18, 52,18, 53,18, 54,18,
                55,18, 56,18, 13,19, 44,19, 45,19, 46,19, 47,19, 48,19, 49,19, 50,19,
                13,20, 38,20, 39,20, 40,20, 41,20, 42,20, 43,20, 44,20, 13,21, 14,21,
                32,21, 33,21, 34,21, 35,21, 36,21, 37,21, 38,21, 14,22, 15,22, 26,22,
                27,22, 28,22, 29,22, 30,22, 31,22, 32,22, 15,23, 16,23, 17,23, 18,23,
                21,23, 22,23, 23,23, 24,23, 25,23, 26,23, 18,24, 19,24, 20,24, 21,24] });

        return shapes;
})();
