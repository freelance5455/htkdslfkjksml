# MÁQUINA MILITAR — entrega 2026-10-06

Esta entrega foi reconstruída a partir do PROMPT MASTER 3.2 e da matriz integral de 49 registos encontrada nos ficheiros.

## Conteúdo
- `index.html`: interface completa/offline, com dados embutidos.
- `manifest.json` e `sw.js`: modo PWA quando servido por HTTP/HTTPS.
- `data.json`: matriz operacional completa (49 registos; 348 alarmes; 88 notificações; 57 eventos).
- `app/`: projecto Android nativo preparado para usar `AlarmManager.setExactAndAllowWhileIdle`, `BroadcastReceiver`, reconstrução em BOOT/TIME_SET/TIMEZONE_CHANGED, canal de notificações, vibração e alerta em ecrã bloqueado quando o sistema permitir.

## Integridade
O artefacto não declara que uma PWA ou um navegador consegue garantir alarmes Android em background. A interface só chama agendamento nativo quando a ponte Android `AndroidMM` existe.

## Limitação da entrega aqui
O ambiente desta conversa não possui Android SDK/Gradle instalado e não permitiu baixar essas ferramentas; por isso não há um APK compilado anexado. O código Android é fonte real, mas não foi falsamente declarado “APK testado no Morepe M830”.
