# تحقق الحديث

هذا المشروع يحول الفكرة إلى تطبيق Android بسيط يفتح صفحة الأحاديث في الدرر السنية داخل WebView.

## بناء APK
افتح المجلد في Android Studio ثم اختر:
Build > Build APK(s)

يتطلب Android SDK وGradle عبر Android Studio.

## نسخة الويب
الملف `web/index.html` يمكن رفعه على استضافة ويب أو فتحه مباشرة.
