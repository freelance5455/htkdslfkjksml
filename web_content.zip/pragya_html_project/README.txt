PRAGYA PRODUCTION - HOPPER-WISE HTML APP

Files:
- index.html: offline-capable single-page app

How to try:
1. Extract this ZIP.
2. Open index.html in a browser to test.
3. For APK conversion, upload the extracted HTML/project to an HTML-to-APK service that supports index.html (service rules vary).

Includes the hopper names/configuration supplied by Harshit for Moong Mogar and Moong Dal plants, daily records saved in localStorage, truck dispatch, history, CSV export, and JSON backup/restore.

IMPORTANT:
- Browser/localStorage data is stored on the device/browser profile. It may not automatically carry over to a newly installed APK or another browser. Export JSON backups regularly.
- Auto carry-forward is a basic opening-value carry-forward from the previous saved date. Verify stock figures before relying on them for production accounting.
- This is a prototype. Check balances and records against your physical register before using for business-critical stock.
