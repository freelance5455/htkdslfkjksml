//HFDefault += "&config | value: .txt file

//HFDefault += "&bgcolor=808080" | value: hexadecimal color

//HFDefault += "&cubecolor=000000" | value: hexadecimal color

//HFDefault += "&butbgcolor=bgcolor" | value: hexadecimal color

//HFDefault += "&slidercolor=000000 or ffffff depending on bgcolor" | value: hexadecimal color

//HFDefault += "&troughcolor=darker shade of bgcolor" | value: hexadecimal color

//HFDefault += "&clickprogress=1" | value: 0 or 1

//HFDefault += "&snap=0" | value: 0 or 1

//HFDefault += "&buttonbar=1 | value: 0 - 2

//HFDefault += "&buttonheight | value: 9 - 25

//HFDefault += "&repeat | value: 0 or 1

//HFDefault += "&edit | value: 0 or 1

//HFDefault += "&speed | value: natural number

//HFDefault += "&doublespeed | value: natural number

//HFDefault += "&position | value: R, U, F, L, D and/or B string

//HFDefault += "&scale | value: natural number

//HFDefault += "&align | value: 0 - 99

//HFDefault += "&hint | value: natural number

//HFDefault += "&hinthoriz | value: decimal number greater than 0

//HFDefault += "&hintvert | value: decimal number greater than 0

//HFDefault += "&hintborder | value: 0 or 1

//HFDefault += "&perspective | value: natural number

//HFDefault += "&borderwidth | value: 0 - 20

//HFDefault += "&move | value: string from move character set or random

//HFDefault += "&movetext | value: 0 - 6 (for 3x3x3 only, other cube sizes: 0, 1, 5 or 6)

//HFDefault += "&movetextspace | value: 0 or 1

//HFDefault += "&yz | value: 0 or 1

//HFDefault += "&sign | value: 0 or 1

//HFDefault += "&wca | value: 0 or 1

//HFDefault += "&initmove | value: string from move character set, random or #

//HFDefault += "&initrevmove | value: string from move character set, random or #

//HFDefault += "&demo | value: string from move character set, random or #

//HFDefault += "&metric | value: 0 - 3

//HFDefault += "&counter | value: 0 or 1

//HFDefault += "&fonttype | value: 0 or 1

//HFDefault += "&textsize | value: 5 - 40

//HFDefault += "&facelets | value: string of color codes

//HFDefault += "&colorscheme | value: 6 color codes

//HFDefault += "&colors | value: hexadecimal color string

//HFDefault += "&pos | value: string of Lars Petrus' color codes

//HFDefault += "&supercube | value: 0 or 1

//HFDefault += "&superfacelets | value: 0 - 3 string

//HFDefault += "&scw | value: 0 - 2

//HFDefault += "&gabbacolors | value: 0 or 1

//HFDefault += "&scramble | value: 0 - 2

//HFDefault += "&randmoves | value: natural numbervar movetype = "Generator";
var HFDefault = "id=cube"
//HFDefault += "&align=1"               //default: 1                  value: 0 - 99         
//HFDefault += "&bgcolor=808080";       //default: 808080             value: hexadecimal color
//HFDefault += "&borderwidth=10";       //default: 10 (or 6)*         value: 0 - 20
//HFDefault += "&butbgcolor=";          //default: bgcolor value      value: hexadecimal color
HFDefault += "&butbgcolor=c0c0c0";
//HFDefault += "&buttonbar=";
HFDefault += "&buttonbar=1";
//HFDefault += "&buttonheight=13";
HFDefault += "&buttonheight=25";
HFDefault += "&clickprogress=1";
//HFDefault += "&color0=FF8040";
//HFDefault += "&color1=FF0000";
//HFDefault += "&color2=00FF00";
//HFDefault += "&color3=0000FF";
//HFDefault += "&color4=999999";
//HFDefault += "&color5=AAAA44";
//HFDefault += "&color6=BB7744";
//HFDefault += "&color7=994444";
//HFDefault += "&color8=447744";
//HFDefault += "&color9=004477";
////HFDefault += "&colorscheme=wyorgb";
HFDefault += "&colorscheme=ywbgor";
//HFDefault += "&counter=1";
//HFDefault += "&cubecolor=000000";
//HFDefault += "&demo=";
//HFDefault += "&doublespeed=0";
////HFDefault += "&edit=1";
HFDefault += "&edit=0";
//HFDefault += "&facelets=";
//HFDefault += "&fonttype=1";
//HFDefault += "&gabbacolors=0";
//HFDefault += "&hint=0";
//HFDefault += "&hintborder=0";
//HFDefault += "&hinthoriz=3.7";
//HFDefault += "&hintvert=3.7";
//HFDefault += "&initmove=";
//HFDefault += "&initrevmove=";
//HFDefault += "&markers=";
//HFDefault += "&metric=0";
//HFDefault += "&move=";
////HFDefault += "&movetext=0";
HFDefault += "&movetext=5";
//HFDefault += "&movetextspace=1";
//HFDefault += "&perspective=2";
//HFDefault += "&position=lluu";
//HFDefault += "&randmoves=0";
HFDefault += "&repeat=0";
////HFDefault += "&repeat=1";
//HFDefault += "&scale=0";
//HFDefault += "&scramble=0";
//HFDefault += "&scw=0";
////HFDefault += "&sign=0;
HFDefault += "&sign=1";
////HFDefault += "&slidercolor=";
HFDefault += "&slidercolor=ff0000";
////HFDefault += "&snap=0";
HFDefault += "&snap=1";
////HFDefault += "&speed=10";
//HFDefault += "&speed=12";
//HFDefault += "&supercube=0";
//HFDefault += "&superfacelets=";
//HFDefault += "&textsize=12";
////HFDefault += "&troughcolor=";
HFDefault += "&troughcolor=ffff00";
//HFDefault += "&wca=0";
////HFDefault += "&yz=0";
HFDefault += "&yz=1";
