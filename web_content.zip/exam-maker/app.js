'use strict';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6);
const shuf=a=>{a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[a[i],a[j]]=[a[j],a[i]]}return a};
const dg=s=>s.replace(/[٠-٩]/g,d=>d.charCodeAt(0)-1632).replace(/[۰-۹]/g,d=>d.charCodeAt(0)-1776);
const nz=s=>dg(String(s)).replace(/[\u064B-\u0652ـ]/g,'').replace(/[إأآ]/g,'ا').replace(/\s+/g,' ').trim().toLowerCase();
const db=new Promise((r,j)=>{const q=indexedDB.open('exammaker',1);q.onupgradeneeded=()=>q.result.createObjectStore('kv');q.onsuccess=()=>r(q.result);q.onerror=j});
const tx=async(m,f)=>{const d=await db;return new Promise(r=>{const t=d.transaction('kv',m),o=f(t.objectStore('kv'));t.oncomplete=()=>r(o.result)})};
const kv={get:k=>tx('readonly',s=>s.get(k)),set:(k,v)=>tx('readwrite',s=>s.put(v,k)),clear:()=>tx('readwrite',s=>s.clear())};
let S={exams:[],atts:[],ses:null},Q=[],pages=[],low=new Set(),cur=null,tmr;
const save=()=>Promise.all([kv.set('exams',S.exams),kv.set('atts',S.atts),kv.set('ses',S.ses)]);
const TN={mcq:'اختيار من متعدد',tf:'صح وخطأ',blank:'إكمال',short:'إجابة قصيرة',essay:'مقالي'};
const av=(x,v)=>v==null||v===''?'':(x.t==='mcq'||x.t==='tf')?(x.o[v]??''):v;
function show(id){$$('.v').forEach(v=>v.hidden=v.id!==id);scrollTo(0,0);if(id==='home')home();if(id==='scan')eng()}
function home(){
 const a=S.atts,avg=a.length?Math.round(a.reduce((x,y)=>x+y.pct,0)/a.length):0;
 $('#stats').innerHTML=a.length?`<p>اختبارات منجزة: <b>${a.length}</b> — المتوسط: <b>${avg}%</b></p><div class="spark">${a.slice(-8).map(x=>`<u style="height:${Math.max(4,x.pct)}%" title="${x.pct}%"></u>`).join('')}</div>`:'<p class="mut">ستظهر إحصاءاتك بعد أول اختبار.</p>';
 $('#exl').innerHTML=S.exams.length?S.exams.slice().reverse().map(e=>`<div class="it"><span>${esc(e.title)}<small>${e.qs.length} سؤال</small></span><button data-st="${e.id}">ابدأ</button><button data-pe="${e.id}">طباعة</button><button data-dx="${e.id}" class="dng">حذف</button></div>`).join(''):'<p class="mut">لا توجد اختبارات بعد. ابدأ بمسح ورقة امتحان.</p>';
 $('#atl').innerHTML=a.length?a.slice(-5).reverse().map(x=>`<div class="it"><span>${esc(x.title)}<small>${x.pct}% — ${new Date(x.date).toLocaleDateString('ar')}</small></span><button data-vw="${x.id}">عرض</button></div>`).join(''):'<p class="mut">لا توجد نتائج بعد.</p>';
 $('#resume').innerHTML=S.ses?'<div class="card"><b>لديك اختبار غير مكتمل</b><div class="row"><button class="pri" id="b-res">متابعة الاختبار</button></div></div>':'';
}
/* ---- محرك القراءة (OCR) ---- */
const V=new URL('vendor/',location.href).href,CD='https://cdn.jsdelivr.net/npm/';
const FILES=[['tesseract.min.js',CD+'tesseract.js@5.1.1/dist/tesseract.min.js'],['worker.min.js',CD+'tesseract.js@5.1.1/dist/worker.min.js'],['core/tesseract-core-simd-lstm.wasm.js',CD+'tesseract.js-core@5.1.1/tesseract-core-simd-lstm.wasm.js'],['core/tesseract-core-lstm.wasm.js',CD+'tesseract.js-core@5.1.1/tesseract-core-lstm.wasm.js'],['lang/ara.traineddata.gz','https://tessdata.projectnaptha.com/4.0.0/ara.traineddata.gz'],['lang/eng.traineddata.gz','https://tessdata.projectnaptha.com/4.0.0/eng.traineddata.gz']];
async function engineReady(){try{const r=await fetch(V+'tesseract.min.js');return r.ok&&/javascript/.test(r.headers.get('content-type')||'')}catch{return false}}
async function eng(){$('#eng').innerHTML=await engineReady()?'<span class="chip ok">محرك القراءة جاهز (يعمل دون إنترنت)</span>':'<button id="b-setup">تجهيز محرك القراءة (مرة واحدة)</button>'}
async function setup(){
 if(!navigator.onLine)return alert('يلزم اتصال بالإنترنت لتجهيز المحرك لأول مرة.');
 if(!confirm('سيُنزَّل محرك القراءة (نحو 25 ميغابايت) مرة واحدة ثم يعمل دون إنترنت. متابعة؟'))return;
 const c=await caches.open('em-v1');let n=0;
 for(const[p,u]of FILES){$('#ocrst').textContent=`تنزيل المحرك ${++n}/${FILES.length}…`;const core=p.startsWith('core/');
  try{const r=await fetch(u);if(!r.ok)throw 0;await c.put(V+p,r)}catch{if(!core){$('#ocrst').textContent='تعذّر التنزيل. تحقق من الاتصال وأعد المحاولة.';return}}}
 $('#ocrst').textContent='اكتمل تجهيز المحرك.';eng()}
function prep(img){const c=document.createElement('canvas'),s=Math.min(1,2400/Math.max(img.width,img.height));c.width=img.width*s;c.height=img.height*s;const x=c.getContext('2d');x.drawImage(img,0,0,c.width,c.height);
 const d=x.getImageData(0,0,c.width,c.height),p=d.data,h=new Array(256).fill(0),n=p.length/4;
 for(let i=0;i<p.length;i+=4){const g=p[i]*.3+p[i+1]*.59+p[i+2]*.11|0;p[i]=g;h[g]++}
 let a=0,lo=0,hi=255;while(lo<255&&(a+=h[lo])<n*.02)lo++;a=0;while(hi>0&&(a+=h[hi])<n*.02)hi--;
 const k=255/Math.max(1,hi-lo);for(let i=0;i<p.length;i+=4){p[i]=p[i+1]=p[i+2]=Math.max(0,Math.min(255,(p[i]-lo)*k))}x.putImageData(d,0,0);return c}
const drawPages=()=>{$('#pg').innerHTML=pages.map((p,i)=>`<figure><img src="${p.url}" alt="صفحة ${i+1}"><button data-rp="${i}" class="dng" aria-label="حذف الصفحة">×</button></figure>`).join('')};
function addFiles(fs){[...fs].forEach(f=>{if(!/^image\//.test(f.type))return;const img=new Image(),o={img,url:URL.createObjectURL(f)};img.src=o.url;pages.push(o);img.onload=drawPages});drawPages();show('scan')}
async function ocr(){
 if(!pages.length)return alert('أضف صورة أولًا.');
 if(!await engineReady())return alert('جهّز محرك القراءة أولًا، أو الصق النص يدويًا.');
 if(!window.Tesseract)await new Promise((r,j)=>{const s=document.createElement('script');s.src=V+'tesseract.min.js';s.onload=r;s.onerror=j;document.head.append(s)});
 let cp=0;const out=[];low=new Set();$('#b-ocr').disabled=true;
 try{const w=await Tesseract.createWorker('ara+eng',1,{workerPath:V+'worker.min.js',corePath:V+'core',langPath:V+'lang',logger:m=>{if(m.status==='recognizing text')$('#ocrst').textContent=`الصفحة ${cp}/${pages.length} — ${m.progress*100|0}%`}});
  for(const p of pages){cp++;$('#ocrst').textContent=`تجهيز الصفحة ${cp}…`;const{data}=await w.recognize(prep(p.img));
   const L=data.lines?.length?data.lines:data.text.split('\n').map(text=>({text,confidence:100}));
   L.forEach(l=>{const t=dg(l.text).trim();if(t&&l.confidence<60)low.add(t)});out.push(L.map(l=>l.text.trim()).filter(Boolean).join('\n'))}
  await w.terminate();$('#txt').value=out.join('\n');$('#ocrst').textContent='تمت القراءة. راجع النص ثم استخرج الأسئلة.';
  $('#lowl').innerHTML=low.size?`<p class="warn">أسطر غير مؤكدة (راجعها في النص):</p>${[...low].slice(0,8).map(t=>`<p class="mut">${esc(t)}</p>`).join('')}`:''}
 catch(e){$('#ocrst').textContent='تعذّرت القراءة. تأكد من تجهيز المحرك أو الصق النص يدويًا.'}
 $('#b-ocr').disabled=false}
/* ---- استخراج الأسئلة ---- */
const LET={'أ':0,'ا':0,'ب':1,'ج':2,'د':3,'ه':4,'هـ':4,a:0,b:1,c:2,d:3,e:4};
const OPT=/^[\(\[]?\s*(هـ|[أابجده]|[A-Ea-e])\s*[\)\]\.\-:،]\s*(.+)/,QRE=/^(?:س\s*)?(\d{1,3})\s*[\)\.\-:،]\s*(.+)/,MK=/[✓✔☑√]/;
function parse(raw){
 const L=dg(raw).split('\n').map(s=>s.trim()).filter(Boolean);
 const k=L.findIndex(l=>l.length<45&&/(الإجابات|الاجابات|مفتاح|answer\s*key|answers)/i.test(l));
 const body=k<0?L:L.slice(0,k),key=k<0?'':L.slice(k+1).join(' '),qs=[];let c=null;
 for(const l of body){
  const o=c&&l.match(OPT);
  if(o){let t=o[2];const m=MK.test(t);t=t.replace(MK,'').trim();c.o.push(t);if(m){c.a=c.o.length-1;c.c='mark'}if(low.has(l))c.low=1;continue}
  const q=l.match(QRE);
  if(q||(/[؟?]\s*$/.test(l)&&(!c||c.o.length))){c={id:uid(),n:q?+q[1]:qs.length+1,q:q?q[2]:l,o:[],a:null,c:null,t:'short'};qs.push(c);if(low.has(l))c.low=1;continue}
  if(c){if(c.o.length)c.o[c.o.length-1]+=' '+l;else c.q+=' '+l;if(low.has(l))c.low=1}}
 qs.forEach(q=>{if(q.o.length>=2)q.t='mcq';else{q.o=[];q.a=null;q.c=null;q.t=/(\(\s*\)|_{3,}|\.{4,}|…)/.test(q.q)?'blank':/(صح|خطأ|صواب|true|false)/i.test(q.q)?'tf':/(اشرح|علل|ناقش|اكتب|وضح|explain|discuss|describe)/i.test(q.q)?'essay':'short';if(q.t==='tf')q.o=['صح','خطأ']}});
 const km={};for(const m of key.matchAll(/(\d{1,3})\s*[\)\.\-:–]?\s*(هـ|[أابجده]|[A-Ea-e]|صح|خطأ|خطا|true|false)(?![\p{L}])/giu))km[+m[1]]??=m[2];
 qs.forEach(q=>{const v=km[q.n];if(v==null||q.a!=null)return;const s=v.toLowerCase();let i=-1;
  if(q.t==='tf')i=/^(صح|true)/.test(s)?0:/^(خطأ|خطا|false)/.test(s)?1:-1;else if(q.t==='mcq'&&s in LET)i=LET[s];
  if(i>=0&&i<q.o.length){q.a=i;q.c='key'}});
 return qs}
function rev(){
 $('#ql').innerHTML=Q.map((q,i)=>{const mc=q.t==='mcq'||q.t==='tf',has=q.a!=null&&q.a!=='';
  return `<div class="card${q.low?' lw':''}" data-i="${i}"><div class="row"><b>${i+1}</b><select data-f="t" aria-label="نوع السؤال">${Object.entries(TN).map(([k,v])=>`<option value="${k}"${q.t===k?' selected':''}>${v}</option>`).join('')}</select><button data-dq="${i}" class="dng">حذف</button></div>${q.low?'<p class="warn">قراءة غير مؤكدة — راجع النص</p>':''}<textarea data-f="q" rows="2">${esc(q.q)}</textarea>${mc?q.o.map((o,j)=>`<label class="op"><input type="radio" name="r${i}" data-ra="${j}"${q.a===j?' checked':''}><input data-f="o" data-j="${j}" value="${esc(o)}"${q.t==='tf'?' readonly':''}></label>`).join('')+(q.t==='mcq'?`<button data-ao="${i}">+ خيار</button>`:''):`<input data-f="a" placeholder="الإجابة الصحيحة (اختياري)" value="${esc(q.a??'')}">`}<p class="mut">${!has?'الإجابة الصحيحة غير محددة — لن يُحتسب هذا السؤال في الدرجة':q.c==='key'?'مقترحة من مفتاح الإجابات — تحتاج تأكيدك':q.c==='mark'?'مقترحة من علامة بجوار الخيار — تحتاج تأكيدك':'حدّدتها أنت'}</p></div>`}).join('');
 $('#s-n').value=Q.length}
function gen(){
 const sug=Q.filter(q=>q.c==='key'||q.c==='mark');
 if(sug.length){if(confirm(`${sug.length} إجابة مقترحة لم تُؤكَّد بعد.\nموافق = اعتمادها، إلغاء = حذفها لتحدد الإجابات بنفسك.`))sug.forEach(q=>q.c='user');else{sug.forEach(q=>{q.a=null;q.c=null});return rev()}}
 let qs=Q.filter(q=>q.q.trim()).map(q=>({...q,o:[...q.o]}));
 if(!qs.length)return alert('لا توجد أسئلة.');
 if($('#s-sq').checked)qs=shuf(qs);
 qs=qs.slice(0,Math.max(1,+$('#s-n').value||qs.length));
 if($('#s-so').checked)qs.forEach(q=>{if(q.t==='mcq'&&q.a!=null){const p=shuf(q.o.map((_,i)=>i));q.o=p.map(i=>q.o[i]);q.a=p.indexOf(q.a)}});
 const e={id:uid(),title:$('#s-t').value.trim()||'اختبار '+new Date().toLocaleDateString('ar'),date:Date.now(),dur:+$('#s-d').value||0,m:+$('#s-m').value||1,qs};
 S.exams.push(e);start(e)}
/* ---- الاختبار ---- */
function start(e){S.ses={e,ans:{},fl:{},i:0,t0:Date.now(),end:e.dur?Date.now()+e.dur*6e4:0};save();ex()}
function ex(){show('ex');draw();clearInterval(tmr);tick();tmr=setInterval(tick,1000)}
function tick(){const s=S.ses;if(!s)return;const r=s.end?s.end-Date.now():Date.now()-s.t0,t=Math.max(0,r)/1000|0;
 $('#tm').textContent=`${String(t/60|0).padStart(2,'0')}:${String(t%60).padStart(2,'0')}`;
 if(s.end&&r<=0){clearInterval(tmr);alert('انتهى الوقت. سيتم تسليم إجاباتك الآن.');submit(true)}}
const done=(s,i)=>s.ans[i]!=null&&s.ans[i]!=='';
function nv(){const s=S.ses,e=s.e;$('#pgl').textContent=`السؤال ${s.i+1} من ${e.qs.length}`;
 $('#pb').style.width=e.qs.filter((_,i)=>done(s,i)).length/e.qs.length*100+'%';
 $('#b-flag').textContent=s.fl[s.i]?'إلغاء التعليم':'تعليم للمراجعة';
 $('#nav').innerHTML=e.qs.map((_,i)=>`<button data-gq="${i}" class="${i===s.i?'cur ':''}${done(s,i)?'done ':''}${s.fl[i]?'fl':''}">${i+1}</button>`).join('')}
function draw(){const s=S.ses,q=s.e.qs[s.i],a=s.ans[s.i];
 $('#qb').innerHTML=`<div class="card"><p class="qt">${esc(q.q)}</p>${q.t==='mcq'||q.t==='tf'?q.o.map((o,j)=>`<button class="ch${a===j?' on':''}" data-pk="${j}">${esc(o)}</button>`).join(''):q.t==='essay'?`<textarea data-tx rows="6">${esc(a||'')}</textarea>`:`<input data-tx value="${esc(a||'')}" placeholder="اكتب إجابتك">`}</div>`;nv()}
function submit(auto){const s=S.ses,e=s.e,un=e.qs.filter((_,i)=>!done(s,i)).length;
 if(!auto&&!confirm(un?`لديك ${un} سؤال بلا إجابة. تسليم الاختبار؟`:'تسليم الاختبار؟'))return;
 clearInterval(tmr);let sc=0,tot=0,ok=0,bad=0,ng=0,na=0;
 const items=e.qs.map((q,i)=>{const u=s.ans[i],has=done(s,i),ka=q.a!=null&&String(q.a).trim()!=='';let g=null;
  if(q.t!=='essay'&&ka)g=!has?false:(q.t==='mcq'||q.t==='tf')?u===q.a:nz(u)===nz(q.a);
  if(g===null)ng++;else{tot+=e.m;if(g){ok++;sc+=e.m}else if(has)bad++;else na++}
  return{q:q.q,o:q.o,t:q.t,a:q.a,u,g}});
 const r={id:uid(),exId:e.id,title:e.title,date:Date.now(),sc,tot,pct:tot?Math.round(sc/tot*100):0,ok,bad,un:na,ng,time:(Date.now()-s.t0)/1000|0,items};
 S.atts.push(r);S.ses=null;save();res(r)}
function res(r){cur=r;show('res');const n=Math.max(1,r.ok+r.bad+r.un),d=r.ok/n*100,b=d+r.bad/n*100;
 $('#rs').innerHTML=`<div class="card sc"><div class="dn" style="background:conic-gradient(var(--ok) 0 ${d}%,var(--bad) ${d}% ${b}%,var(--mut) ${b}% 100%)"><b>${r.pct}%</b></div><p>${r.sc} من ${r.tot} درجة</p><p>صحيحة ${r.ok} — خاطئة ${r.bad} — بلا إجابة ${r.un}${r.ng?` — غير مصحَّحة ${r.ng}`:''}</p><p class="mut">الوقت: ${r.time/60|0} د ${r.time%60} ث</p></div>`+
 r.items.map((x,i)=>`<div class="card ${x.g===true?'g':x.g===false?'b':''}"><p><b>${i+1}.</b> ${esc(x.q)}</p><p>إجابتك: ${esc(av(x,x.u))||'—'}</p><p>الصحيحة: ${x.a==null||x.a===''?'غير محددة':esc(av(x,x.a))}</p></div>`).join('')}
/* ---- تصدير وطباعة ---- */
function dl(name,txt){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([txt],{type:'application/json'}));a.download=name;a.click()}
function pr(e,key){const L='أبجده';$('#pr').innerHTML=`<h1>${esc(e.title)}</h1>`+(key?'<h2>مفتاح الإجابات</h2><ol>'+e.qs.map(q=>`<li>${q.a==null||q.a===''?'غير محددة':esc(av(q,q.a))}</li>`).join('')+'</ol>':`<p>المدة: ${e.dur?e.dur+' دقيقة':'مفتوحة'} — الدرجة لكل سؤال: ${e.m}</p><ol>`+e.qs.map(q=>`<li>${esc(q.q)}${q.o.length?'<ul style="list-style:none">'+q.o.map((o,j)=>`<li>${L[j]}) ${esc(o)}</li>`).join('')+'</ul>':'<div class="ln"></div>'}</li>`).join('')+'</ol>');print()}
const okQ=q=>q&&typeof q.q==='string'&&q.q.length<3000&&Object.hasOwn(TN,q.t)&&Array.isArray(q.o)&&q.o.every(o=>typeof o==='string');
async function imp(f){if(!f||f.size>5e6)return alert('الملف كبير أو غير صالح.');
 try{const d=JSON.parse(await f.text());if(!Array.isArray(d.exams))throw 0;
  const ex=d.exams.filter(e=>e&&typeof e.title==='string'&&Array.isArray(e.qs)&&e.qs.length&&e.qs.every(okQ)&&!S.exams.some(x=>x.id===e.id)).map(e=>({id:String(e.id||uid()),title:e.title,date:+e.date||Date.now(),dur:+e.dur||0,m:+e.m||1,qs:e.qs}));
  S.exams.push(...ex);await save();home();alert(`تم استيراد ${ex.length} اختبار.`)}catch{alert('ملف JSON غير صالح.')}}
/* ---- الأحداث ---- */
document.addEventListener('click',e=>{const t=e.target.closest('button');if(!t)return;const d=t.dataset,id=t.id,E=k=>S.exams.find(x=>x.id===k),i=+(d.dq??d.ao??d.rp??d.gq??d.pk);
 if(d.go)show(d.go);
 else if(id==='b-scan'){pages=[];drawPages();$('#f-cam').click()}
 else if(id==='b-add')$('#f-cam').click();
 else if(id==='b-gal'){pages=[];drawPages();$('#f-gal').click()}
 else if(id==='b-txt'){pages=[];drawPages();$('#txt').value='';$('#lowl').innerHTML='';low=new Set();show('scan')}
 else if(id==='b-ocr')ocr();else if(id==='b-setup')setup();
 else if(id==='b-parse'){Q=parse($('#txt').value);if(Q.length){rev();show('rev')}else alert('لم أجد أسئلة. تأكد أن الأسئلة مرقمة (1- 2-) وأن الخيارات تبدأ بـ أ) ب) ج) أو A) B) C).')}
 else if(id==='b-addq'){Q.push({id:uid(),n:Q.length+1,q:'',o:['','','',''],a:null,c:null,t:'mcq'});rev()}
 else if(d.dq!==undefined){Q.splice(i,1);rev()}else if(d.ao!==undefined){Q[i].o.push('');rev()}
 else if(id==='b-gen')gen();
 else if(d.rp!==undefined){pages.splice(i,1);drawPages()}
 else if(d.pk!==undefined){S.ses.ans[S.ses.i]=i;save();draw()}
 else if(d.gq!==undefined){S.ses.i=i;draw()}
 else if(id==='b-prev'&&S.ses.i>0){S.ses.i--;draw()}else if(id==='b-next'&&S.ses.i<S.ses.e.qs.length-1){S.ses.i++;draw()}
 else if(id==='b-flag'){S.ses.fl[S.ses.i]=!S.ses.fl[S.ses.i];save();nv()}
 else if(id==='b-sub')submit();else if(id==='b-res')ex();
 else if(id==='b-re'){const x=E(cur.exId);x?start(x):alert('الاختبار الأصلي محذوف.')}
 else if(id==='b-pa'){const x=E(cur.exId);x?pr(x,true):alert('الاختبار الأصلي محذوف.')}
 else if(d.st)start(E(d.st));else if(d.pe)pr(E(d.pe),false);
 else if(d.dx){if(confirm('حذف هذا الاختبار نهائيًا؟')){S.exams=S.exams.filter(x=>x.id!==d.dx);save();home()}}
 else if(d.vw)res(S.atts.find(x=>x.id===d.vw));
 else if(id==='b-exp')dl('exam-maker.json',JSON.stringify({v:1,exams:S.exams,atts:S.atts}));
 else if(id==='b-imp')$('#f-imp').click();
 else if(id==='b-del'){if(confirm('سيُحذف كل شيء (الاختبارات والنتائج) من هذا الجهاز نهائيًا. متابعة؟')){kv.clear().then(()=>{S={exams:[],atts:[],ses:null};home()})}}
 else if(id==='th'){const m=document.documentElement.dataset.theme==='light'?'dark':'light';document.documentElement.dataset.theme=m;try{localStorage.theme=m}catch{}}});
$('#ql').addEventListener('input',e=>{const t=e.target,c=t.closest('[data-i]'),f=t.dataset.f;if(!c||!f)return;const q=Q[c.dataset.i];
 if(f==='o')q.o[+t.dataset.j]=t.value;else if(f==='a'){q.a=t.value;q.c='user'}
 else if(f==='t'){q.t=t.value;if(q.t==='tf'){q.o=['صح','خطأ'];q.a=null;q.c=null}else if(q.t==='mcq'){if(q.o.length<2)q.o=['','','',''];if(typeof q.a==='string')q.a=null}else{q.o=[];q.a=null;q.c=null}rev()}
 else q[f]=t.value});
$('#ql').addEventListener('change',e=>{const r=e.target.closest('[data-ra]');if(!r)return;const q=Q[r.closest('[data-i]').dataset.i];q.a=+r.dataset.ra;q.c='user';rev()});
$('#qb').addEventListener('input',e=>{if(!e.target.matches('[data-tx]'))return;const s=S.ses;if(e.target.value.trim())s.ans[s.i]=e.target.value;else delete s.ans[s.i];save();nv()});
$('#f-cam').onchange=e=>{addFiles(e.target.files);e.target.value=''};$('#f-gal').onchange=e=>{addFiles(e.target.files);e.target.value=''};
$('#f-imp').onchange=e=>{imp(e.target.files[0]);e.target.value=''};
const net=()=>{$('#net').textContent=navigator.onLine?'متصل':'بلا اتصال';$('#net').className='chip'+(navigator.onLine?' ok':'')};
addEventListener('online',net);addEventListener('offline',net);
(async()=>{try{if(localStorage.theme)document.documentElement.dataset.theme=localStorage.theme}catch{}
 S.exams=await kv.get('exams')||[];S.atts=await kv.get('atts')||[];S.ses=await kv.get('ses')||null;net();
 if('serviceWorker'in navigator)navigator.serviceWorker.register('sw.js');show('home')})();
