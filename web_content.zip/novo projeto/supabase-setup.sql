-- Duck Delivery Supabase setup.
-- Execute in Supabase Dashboard > SQL Editor to install or update the schema.
-- Configure Authentication > URL Configuration with the deployed HTTPS site URL
-- and allow the local development URL used by VS Code Live Server.
-- The two administrator email addresses are allowlisted below. Existing accounts
-- receive the admin claim when this script runs; new allowlisted accounts receive
-- it automatically when created. Existing administrators must sign out and back
-- in after this script runs so their session receives the updated claim.

create extension if not exists pgcrypto;

create table if not exists public.admin_access_slots (
    slot smallint primary key check (slot in (1, 2)),
    email text not null unique
);
insert into public.admin_access_slots (slot, email)
values
    (1, 'ericksanttos81@gmail.com'),
    (2, 'oklajunior26@gmail.com')
on conflict (slot) do update set email = excluded.email;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
    select coalesce(
        exists (
            select 1
            from auth.users account
            where account.id = auth.uid()
              and (
                  account.raw_app_meta_data ->> 'role' = 'admin'
                  or exists (
                      select 1
                      from public.admin_access_slots allowed
                      where lower(account.email) = allowed.email
                  )
              )
        ),
        false
    );
$$;

create table if not exists public.profiles (
    id uuid primary key references auth.users(id) on delete cascade,
    full_name text not null,
    phone text not null default '',
    email text not null,
    role text not null check (role in ('client', 'courier')),
    account_status text not null default 'active' check (account_status in ('active', 'blocked')),
    block_reason text,
    created_at timestamptz not null default now()
);
alter table public.profiles add column if not exists account_status text not null default 'active';
alter table public.profiles add column if not exists block_reason text;
alter table public.profiles drop constraint if exists profiles_account_status_check;
alter table public.profiles add constraint profiles_account_status_check check (account_status in ('active', 'blocked'));

create or replace function public.is_active_user()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
    select exists (
        select 1 from public.profiles
        where id = auth.uid() and account_status = 'active'
    );
$$;

create table if not exists public.courier_profiles (
    user_id uuid primary key references public.profiles(id) on delete cascade,
    vehicle_type text not null check (vehicle_type in ('motorcycle', 'bicycle')),
    plate text,
    vehicle_info text not null default '',
    pix_type text,
    pix_key text,
    approval_status text not null default 'pending'
        check (approval_status in ('pending', 'approved', 'rejected', 'suspended')),
    rejection_reason text,
    document_paths text[] not null default '{}',
    is_online boolean not null default false,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    constraint motorcycle_plate_required check (
        vehicle_type <> 'motorcycle' or (plate is not null and length(trim(plate)) > 0)
    ),
    constraint courier_profiles_pix_key_check check (
        (pix_type is null and pix_key is null)
        or (
            pix_type is not null
            and
            pix_type in ('cpf', 'email', 'phone', 'random')
            and pix_key is not null
            and length(trim(pix_key)) > 0
        )
    ),
    constraint rejected_reason_required check (
        approval_status <> 'rejected' or length(trim(coalesce(rejection_reason, ''))) > 0
    )
);
alter table public.courier_profiles add column if not exists pix_type text;
alter table public.courier_profiles add column if not exists pix_key text;
alter table public.courier_profiles drop constraint if exists courier_profiles_pix_key_check;
alter table public.courier_profiles add constraint courier_profiles_pix_key_check check (
    (pix_type is null and pix_key is null)
    or (
        pix_type is not null
        and pix_type in ('cpf', 'email', 'phone', 'random')
        and pix_key is not null
        and length(trim(pix_key)) > 0
    )
);
alter table public.courier_profiles drop constraint if exists courier_profiles_approval_status_check;
alter table public.courier_profiles add constraint courier_profiles_approval_status_check
    check (approval_status in ('pending', 'approved', 'rejected', 'suspended'));

create table if not exists public.platform_settings (
    id boolean primary key default true check (id),
    minimum_fee numeric(10, 2) not null default 8 check (minimum_fee >= 0),
    motorcycle_per_km numeric(10, 2) not null default 2.5 check (motorcycle_per_km >= 0),
    bicycle_per_km numeric(10, 2) not null default 1.8 check (bicycle_per_km >= 0),
    additional_fee numeric(10, 2) not null default 0 check (additional_fee >= 0),
    platform_fee_percent numeric(5, 2) not null default 15
        check (platform_fee_percent between 0 and 100),
    commission_enabled boolean not null default true,
    allow_cancel_after_acceptance boolean not null default false,
    updated_at timestamptz not null default now()
);
alter table public.platform_settings add column if not exists additional_fee numeric(10, 2) not null default 0;
alter table public.platform_settings add column if not exists commission_enabled boolean not null default true;
alter table public.platform_settings add column if not exists allow_cancel_after_acceptance boolean not null default false;
alter table public.platform_settings drop constraint if exists platform_settings_additional_fee_check;
alter table public.platform_settings add constraint platform_settings_additional_fee_check check (additional_fee >= 0);

insert into public.platform_settings (id) values (true) on conflict (id) do nothing;

create table if not exists public.delivery_orders (
    id uuid primary key default gen_random_uuid(),
    client_id uuid not null references public.profiles(id),
    courier_id uuid references public.profiles(id),
    pickup_address text not null,
    dropoff_address text not null,
    description text not null,
    notes text not null default '',
    vehicle_type text not null check (vehicle_type in ('motorcycle', 'bicycle')),
    distance_km numeric(8, 2) not null check (distance_km > 0 and distance_km <= 100),
    pickup_latitude double precision,
    pickup_longitude double precision,
    dropoff_latitude double precision,
    dropoff_longitude double precision,
    total_amount numeric(10, 2) not null default 0,
    courier_amount numeric(10, 2) not null default 0,
    status text not null default 'pending'
        check (status in ('pending', 'accepted', 'pickup_started', 'collected', 'in_transit', 'delivered', 'cancelled')),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    delivered_at timestamptz
);

create table if not exists public.courier_order_responses (
    order_id uuid not null references public.delivery_orders(id) on delete cascade,
    courier_id uuid not null references public.profiles(id) on delete cascade,
    response text not null check (response in ('accepted', 'rejected')),
    created_at timestamptz not null default now(),
    primary key (order_id, courier_id)
);

create table if not exists public.courier_earnings (
    id uuid primary key default gen_random_uuid(),
    order_id uuid not null unique references public.delivery_orders(id),
    courier_id uuid not null references public.profiles(id),
    amount numeric(10, 2) not null check (amount >= 0),
    status text not null default 'pending' check (status in ('pending', 'paid')),
    created_at timestamptz not null default now(),
    paid_at timestamptz
);

create table if not exists public.courier_ratings (
    id uuid primary key default gen_random_uuid(),
    order_id uuid not null unique references public.delivery_orders(id),
    client_id uuid not null references public.profiles(id),
    courier_id uuid not null references public.profiles(id),
    stars smallint not null check (stars between 1 and 5),
    comment text not null default '',
    created_at timestamptz not null default now()
);

create table if not exists public.admin_activity_log (
    id uuid primary key default gen_random_uuid(),
    admin_id uuid not null references auth.users(id),
    action text not null,
    target_type text not null,
    target_id text,
    details jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now()
);
create index if not exists admin_activity_log_created_idx on public.admin_activity_log (created_at desc);

create or replace function public.log_admin_activity(p_action text, p_target_type text, p_target_id text, p_details jsonb default '{}'::jsonb)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
    if not public.is_admin() or auth.uid() is null then
        raise exception 'Apenas administradores autenticados podem registrar atividades.';
    end if;
    insert into public.admin_activity_log (admin_id, action, target_type, target_id, details)
    values (auth.uid(), left(p_action, 100), left(p_target_type, 100), left(p_target_id, 200), coalesce(p_details, '{}'::jsonb));
end;
$$;

create or replace function public.audit_platform_settings_update()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
    if auth.uid() is not null and public.is_admin() then
        insert into public.admin_activity_log (admin_id, action, target_type, target_id, details)
        values (
            auth.uid(),
            'settings_updated',
            'platform_settings',
            'true',
            jsonb_build_object(
                'minimum_fee', new.minimum_fee,
                'motorcycle_per_km', new.motorcycle_per_km,
                'bicycle_per_km', new.bicycle_per_km,
                'additional_fee', new.additional_fee,
                'commission_enabled', new.commission_enabled,
                'platform_fee_percent', new.platform_fee_percent,
                'allow_cancel_after_acceptance', new.allow_cancel_after_acceptance
            )
        );
    end if;
    new.updated_at := now();
    return new;
end;
$$;
drop trigger if exists audit_platform_settings_after_update on public.platform_settings;
create trigger audit_platform_settings_after_update
    before update on public.platform_settings
    for each row execute procedure public.audit_platform_settings_update();

create index if not exists delivery_orders_available_idx
    on public.delivery_orders (status, created_at desc);
create index if not exists delivery_orders_courier_idx
    on public.delivery_orders (courier_id, status, created_at desc);
create index if not exists delivery_orders_client_idx
    on public.delivery_orders (client_id, created_at desc);
create index if not exists courier_earnings_courier_idx
    on public.courier_earnings (courier_id, status);
create index if not exists courier_ratings_courier_idx
    on public.courier_ratings (courier_id);

create or replace function public.grant_admin_role_for_allowlisted_email()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
    if exists (
        select 1
        from public.admin_access_slots allowed
        where allowed.email = lower(new.email)
    ) then
        new.raw_app_meta_data := coalesce(new.raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb;
    end if;
    return new;
end;
$$;

drop trigger if exists assign_allowlisted_admin_role on auth.users;
create trigger assign_allowlisted_admin_role
    before insert on auth.users
    for each row execute procedure public.grant_admin_role_for_allowlisted_email();

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
    requested_role text := new.raw_user_meta_data ->> 'role';
begin
    if requested_role is null or requested_role not in ('client', 'courier') then
        requested_role := 'client';
    end if;

    insert into public.profiles (id, full_name, phone, email, role)
    values (
        new.id,
        coalesce(nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''), 'Usuário'),
        coalesce(new.raw_user_meta_data ->> 'phone', ''),
        new.email,
        requested_role
    );

    if requested_role = 'courier' then
        insert into public.courier_profiles (user_id, vehicle_type, plate, vehicle_info, pix_type, pix_key)
        values (
            new.id,
            case when new.raw_user_meta_data ->> 'vehicle_type' = 'bicycle' then 'bicycle' else 'motorcycle' end,
            nullif(upper(trim(new.raw_user_meta_data ->> 'plate')), ''),
            coalesce(new.raw_user_meta_data ->> 'vehicle_info', ''),
            nullif(new.raw_user_meta_data ->> 'pix_type', ''),
            nullif(trim(new.raw_user_meta_data ->> 'pix_key'), '')
        );
    end if;

    return new;
end;
$$;

create or replace function public.review_courier_profile(p_user_id uuid, p_decision text, p_reason text default null)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
    if not public.is_admin() then
        raise exception 'Apenas administradores podem revisar cadastros.';
    end if;
    if p_decision not in ('approved', 'rejected', 'suspended') then
        raise exception 'Decisão de análise inválida.';
    end if;
    if p_decision in ('rejected', 'suspended') and length(trim(coalesce(p_reason, ''))) = 0 then
        raise exception 'Informe o motivo da recusa ou suspensão.';
    end if;
    update public.courier_profiles
    set approval_status = p_decision,
        rejection_reason = case when p_decision in ('rejected', 'suspended') then trim(p_reason) else null end,
        is_online = false,
        updated_at = now()
    where user_id = p_user_id
      and (p_decision <> 'approved' or cardinality(document_paths) > 0);
    if not found then
        raise exception 'Cadastro não encontrado ou sem documentos enviados.';
    end if;
    perform public.log_admin_activity(
        'courier_' || p_decision,
        'courier',
        p_user_id::text,
        jsonb_build_object('reason', case when p_decision in ('rejected', 'suspended') then trim(p_reason) else null end)
    );
end;
$$;

create or replace function public.admin_set_account_blocked(p_user_id uuid, p_blocked boolean, p_reason text default null)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
    if not public.is_admin() then
        raise exception 'Apenas administradores podem bloquear contas.';
    end if;
    if p_user_id = auth.uid() then
        raise exception 'Não é permitido bloquear a própria conta.';
    end if;
    if p_blocked and length(trim(coalesce(p_reason, ''))) = 0 then
        raise exception 'Informe o motivo do bloqueio.';
    end if;
    update public.profiles
    set account_status = case when p_blocked then 'blocked' else 'active' end,
        block_reason = case when p_blocked then left(trim(p_reason), 500) else null end
    where id = p_user_id
      and not exists (
          select 1 from auth.users target_user
          where target_user.id = p_user_id
            and target_user.raw_app_meta_data ->> 'role' = 'admin'
      );
    if not found then
        raise exception 'Conta não encontrada ou não pode ser bloqueada por esta operação.';
    end if;
    update public.courier_profiles
    set is_online = false, updated_at = now()
    where user_id = p_user_id and p_blocked;
    perform public.log_admin_activity(
        case when p_blocked then 'account_blocked' else 'account_unblocked' end,
        'profile',
        p_user_id::text,
        jsonb_build_object('reason', case when p_blocked then left(trim(p_reason), 500) else null end)
    );
end;
$$;

create or replace function public.admin_dashboard_summary()
returns table (
    total_orders bigint,
    active_orders bigint,
    completed_orders bigint,
    cancelled_orders bigint,
    gross_revenue numeric,
    platform_commission numeric,
    pending_payouts numeric,
    completed_payouts numeric,
    total_clients bigint,
    total_couriers bigint,
    online_couriers bigint
)
language plpgsql
security definer
set search_path = ''
as $$
begin
    if not public.is_admin() then
        raise exception 'Apenas administradores podem consultar os relatórios.';
    end if;
    return query
    select
        (select count(*) from public.delivery_orders),
        (select count(*) from public.delivery_orders where status in ('accepted', 'pickup_started', 'collected', 'in_transit')),
        (select count(*) from public.delivery_orders where status = 'delivered'),
        (select count(*) from public.delivery_orders where status = 'cancelled'),
        coalesce((select sum(total_amount) from public.delivery_orders where status = 'delivered'), 0),
        coalesce((select sum(total_amount - courier_amount) from public.delivery_orders where status = 'delivered'), 0),
        coalesce((select sum(amount) from public.courier_earnings where status = 'pending'), 0),
        coalesce((select sum(amount) from public.courier_earnings where status = 'paid'), 0),
        (select count(*) from public.profiles where role = 'client'),
        (select count(*) from public.courier_profiles),
        (select count(*) from public.courier_profiles where is_online and approval_status = 'approved');
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
    after insert on auth.users
    for each row execute procedure public.handle_new_user();

create or replace function public.prepare_delivery_order()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
    settings public.platform_settings%rowtype;
begin
    select * into settings from public.platform_settings where id = true;
    new.total_amount := settings.minimum_fee + new.distance_km *
        case new.vehicle_type
            when 'motorcycle' then settings.motorcycle_per_km
            else settings.bicycle_per_km
        end + settings.additional_fee;
    new.courier_amount := case
        when settings.commission_enabled then round(new.total_amount * (1 - settings.platform_fee_percent / 100), 2)
        else new.total_amount
    end;
    new.status := 'pending';
    new.courier_id := null;
    return new;
end;
$$;

drop trigger if exists prepare_delivery_order_before_insert on public.delivery_orders;
create trigger prepare_delivery_order_before_insert
    before insert on public.delivery_orders
    for each row execute procedure public.prepare_delivery_order();

create or replace function public.record_courier_earning()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
    if new.status = 'delivered' and old.status <> 'delivered' then
        insert into public.courier_earnings (order_id, courier_id, amount)
        values (new.id, new.courier_id, new.courier_amount)
        on conflict (order_id) do nothing;
        new.delivered_at := now();
    end if;
    return new;
end;
$$;

drop trigger if exists record_courier_earning_after_delivery on public.delivery_orders;
create trigger record_courier_earning_after_delivery
    before update of status on public.delivery_orders
    for each row execute procedure public.record_courier_earning();

create or replace function public.accept_delivery(p_order_id uuid)
returns public.delivery_orders
language plpgsql
security definer
set search_path = ''
as $$
declare
    order_row public.delivery_orders%rowtype;
    courier_row public.courier_profiles%rowtype;
begin
    if public.is_admin() then
        raise exception 'Administradores não podem aceitar entregas como entregadores.';
    end if;
    if not public.is_active_user() then
        raise exception 'Conta bloqueada ou inativa.';
    end if;
    select * into courier_row
    from public.courier_profiles
    where user_id = auth.uid()
      and approval_status = 'approved'
      and is_online
    for update;
    if not found then
        raise exception 'Seu cadastro precisa estar aprovado e você precisa estar online.';
    end if;

    if exists (
        select 1 from public.delivery_orders
        where courier_id = auth.uid()
          and status in ('accepted', 'pickup_started', 'collected', 'in_transit')
    ) then
        raise exception 'Finalize a entrega atual antes de aceitar outra.';
    end if;

    select * into order_row
    from public.delivery_orders
    where id = p_order_id and status = 'pending'
    for update;

    if not found then
        raise exception 'Este pedido não está mais disponível.';
    end if;
    if order_row.vehicle_type <> courier_row.vehicle_type then
        raise exception 'Este pedido exige outro tipo de veículo.';
    end if;

    update public.delivery_orders
    set courier_id = auth.uid(), status = 'accepted', updated_at = now()
    where id = p_order_id
    returning * into order_row;

    insert into public.courier_order_responses (order_id, courier_id, response)
    values (p_order_id, auth.uid(), 'accepted')
    on conflict (order_id, courier_id) do update set response = 'accepted', created_at = now();

    return order_row;
end;
$$;

create or replace function public.respond_to_delivery(p_order_id uuid, p_response text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
    if public.is_admin() then
        raise exception 'Administradores não podem responder a pedidos como entregadores.';
    end if;
    if not public.is_active_user() then
        raise exception 'Conta bloqueada ou inativa.';
    end if;
    if p_response <> 'rejected' then
        raise exception 'Resposta inválida.';
    end if;
    if not exists (
        select 1 from public.courier_profiles
        where user_id = auth.uid() and approval_status = 'approved'
    ) then
        raise exception 'Somente entregadores aprovados podem responder a pedidos.';
    end if;
    if not exists (
        select 1 from public.delivery_orders
        where id = p_order_id and status = 'pending'
    ) then
        raise exception 'Este pedido não está mais disponível.';
    end if;

    insert into public.courier_order_responses (order_id, courier_id, response)
    values (p_order_id, auth.uid(), 'rejected')
    on conflict (order_id, courier_id) do update set response = 'rejected', created_at = now();
end;
$$;

create or replace function public.advance_delivery(p_order_id uuid, p_next_status text)
returns public.delivery_orders
language plpgsql
security definer
set search_path = ''
as $$
declare
    order_row public.delivery_orders%rowtype;
    expected_status text;
begin
    if public.is_admin() then
        raise exception 'Administradores não podem avançar entregas como entregadores.';
    end if;
    if not public.is_active_user() then
        raise exception 'Conta bloqueada ou inativa.';
    end if;
    expected_status := case p_next_status
        when 'pickup_started' then 'accepted'
        when 'collected' then 'pickup_started'
        when 'in_transit' then 'collected'
        when 'delivered' then 'in_transit'
        else null
    end;
    if expected_status is null then
        raise exception 'Etapa de entrega inválida.';
    end if;

    update public.delivery_orders
    set status = p_next_status, updated_at = now()
    where id = p_order_id
      and courier_id = auth.uid()
      and status = expected_status
    returning * into order_row;

    if not found then
        raise exception 'A entrega não está atribuída a você ou a etapa anterior não foi concluída.';
    end if;
    return order_row;
end;
$$;

create or replace function public.cancel_delivery(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
    if public.is_admin() then
        raise exception 'Administradores não podem cancelar pedidos como clientes.';
    end if;
    if not public.is_active_user() then
        raise exception 'Conta bloqueada ou inativa.';
    end if;
    update public.delivery_orders
    set status = 'cancelled', updated_at = now()
    where id = p_order_id
      and client_id = auth.uid()
      and not public.is_admin()
      and (
          status = 'pending'
          or (
              status in ('accepted', 'pickup_started')
              and exists (
                  select 1 from public.platform_settings
                  where id = true and allow_cancel_after_acceptance
              )
          )
      );
    if not found then
        raise exception 'Não foi possível cancelar este pedido.';
    end if;
end;
$$;

create or replace function public.set_courier_online(p_online boolean)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
    if public.is_admin() then
        raise exception 'Administradores não podem alterar disponibilidade de entregador.';
    end if;
    if not public.is_active_user() then
        raise exception 'Conta bloqueada ou inativa.';
    end if;
    update public.courier_profiles
    set is_online = p_online, updated_at = now()
    where user_id = auth.uid() and approval_status = 'approved';
    if not found then
        raise exception 'Somente entregadores aprovados podem ficar online.';
    end if;
end;
$$;

create or replace function public.submit_courier_documents(p_paths text[])
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
    if public.is_admin() then
        raise exception 'Administradores não podem enviar cadastro de entregador.';
    end if;
    if not public.is_active_user() then
        raise exception 'Conta bloqueada ou inativa.';
    end if;
    if cardinality(p_paths) < 1 or cardinality(p_paths) > 5 then
        raise exception 'Envie entre 1 e 5 documentos.';
    end if;
    if exists (
        select 1
        from unnest(p_paths) as submitted(path)
        where split_part(submitted.path, '/', 1) <> auth.uid()::text
           or not exists (
                select 1 from storage.objects object
                where object.bucket_id = 'courier-documents'
                  and object.name = submitted.path
           )
    ) then
        raise exception 'Um ou mais documentos enviados não foram encontrados.';
    end if;
    update public.courier_profiles
    set document_paths = p_paths,
        approval_status = 'pending',
        rejection_reason = null,
        is_online = false,
        updated_at = now()
    where user_id = auth.uid();
    if not found then
        raise exception 'Cadastro de entregador não encontrado.';
    end if;
end;
$$;

create or replace function public.mark_courier_earning_paid(p_earning_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
    if not public.is_admin() then
        raise exception 'Apenas administradores podem confirmar pagamentos.';
    end if;
    update public.courier_earnings
    set status = 'paid', paid_at = now()
    where id = p_earning_id and status = 'pending';
    if not found then
        raise exception 'Ganho pendente não encontrado.';
    end if;
    perform public.log_admin_activity('courier_payout_paid', 'courier_earning', p_earning_id::text);
end;
$$;

alter table public.profiles enable row level security;
alter table public.courier_profiles enable row level security;
alter table public.platform_settings enable row level security;
alter table public.delivery_orders enable row level security;
alter table public.courier_order_responses enable row level security;
alter table public.courier_earnings enable row level security;
alter table public.courier_ratings enable row level security;
alter table public.admin_activity_log enable row level security;
alter table public.admin_access_slots enable row level security;

revoke all on public.profiles, public.courier_profiles, public.platform_settings,
    public.delivery_orders, public.courier_order_responses, public.courier_earnings,
    public.courier_ratings, public.admin_activity_log, public.admin_access_slots from anon, authenticated;
grant select on public.profiles to authenticated;
grant update (full_name, phone) on public.profiles to authenticated;
grant select on public.courier_profiles to authenticated;
grant update (vehicle_type, plate, vehicle_info) on public.courier_profiles to authenticated;
grant select on public.platform_settings to anon, authenticated;
grant update (minimum_fee, motorcycle_per_km, bicycle_per_km, additional_fee, platform_fee_percent, commission_enabled, allow_cancel_after_acceptance)
    on public.platform_settings to authenticated;
grant select on public.delivery_orders to authenticated;
grant insert (client_id, pickup_address, dropoff_address, description, notes, vehicle_type, distance_km)
    on public.delivery_orders to authenticated;
grant insert (pickup_latitude, pickup_longitude, dropoff_latitude, dropoff_longitude)
    on public.delivery_orders to authenticated;
grant select, insert on public.courier_order_responses to authenticated;
grant select on public.courier_earnings to authenticated;
grant select, insert on public.courier_ratings to authenticated;
grant select on public.admin_activity_log to authenticated;
grant usage on schema public to authenticated;

drop policy if exists "profiles read own or admin" on public.profiles;
create policy "profiles read own or admin" on public.profiles
    for select to authenticated using (id = auth.uid() or public.is_admin());
drop policy if exists "profiles update own or admin" on public.profiles;
create policy "profiles update own or admin" on public.profiles
    for update to authenticated using ((id = auth.uid() and public.is_active_user()) or public.is_admin())
    with check ((id = auth.uid() and public.is_active_user()) or public.is_admin());

drop policy if exists "courier profile read own or admin" on public.courier_profiles;
create policy "courier profile read own or admin" on public.courier_profiles
    for select to authenticated using ((user_id = auth.uid() and public.is_active_user()) or public.is_admin());
drop policy if exists "courier profile update own or admin" on public.courier_profiles;
create policy "courier profile update own or admin" on public.courier_profiles
    for update to authenticated using ((user_id = auth.uid() and public.is_active_user()) or public.is_admin())
    with check (
        (user_id = auth.uid() and public.is_active_user() and approval_status in ('pending', 'rejected') and is_online = false)
        or public.is_admin()
    );

drop policy if exists "settings read authenticated" on public.platform_settings;
create policy "settings read authenticated" on public.platform_settings
    for select to authenticated using (true);
drop policy if exists "settings read public" on public.platform_settings;
create policy "settings read public" on public.platform_settings
    for select to anon using (true);
drop policy if exists "settings admin update" on public.platform_settings;
create policy "settings admin update" on public.platform_settings
    for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "orders visible to involved users" on public.delivery_orders;
create policy "orders visible to involved users" on public.delivery_orders
    for select to authenticated using (
        public.is_active_user() and (
        client_id = auth.uid()
        or courier_id = auth.uid()
        or public.is_admin()
        or (
            status = 'pending'
            and exists (
                select 1 from public.courier_profiles cp
                where cp.user_id = auth.uid()
                  and cp.approval_status = 'approved'
                  and cp.is_online
            ))
        )
    );
drop policy if exists "clients create own orders" on public.delivery_orders;
create policy "clients create own orders" on public.delivery_orders
    for insert to authenticated with check (
        client_id = auth.uid()
        and public.is_active_user()
        and not public.is_admin()
        and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'client')
    );

drop policy if exists "courier read own responses" on public.courier_order_responses;
create policy "courier read own responses" on public.courier_order_responses
    for select to authenticated using ((courier_id = auth.uid() and public.is_active_user()) or public.is_admin());
drop policy if exists "courier insert own rejection" on public.courier_order_responses;
create policy "courier insert own rejection" on public.courier_order_responses
    for insert to authenticated with check (
        courier_id = auth.uid()
        and public.is_active_user()
        and response = 'rejected'
        and exists (
            select 1 from public.courier_profiles cp
            where cp.user_id = auth.uid() and cp.approval_status = 'approved'
        )
    );

drop policy if exists "courier earnings read own or admin" on public.courier_earnings;
create policy "courier earnings read own or admin" on public.courier_earnings
    for select to authenticated using ((courier_id = auth.uid() and public.is_active_user()) or public.is_admin());

drop policy if exists "ratings read involved users or admin" on public.courier_ratings;
create policy "ratings read involved users or admin" on public.courier_ratings
    for select to authenticated using (
        (public.is_active_user() and (client_id = auth.uid() or courier_id = auth.uid())) or public.is_admin()
    );
drop policy if exists "clients rate completed deliveries" on public.courier_ratings;
create policy "clients rate completed deliveries" on public.courier_ratings
    for insert to authenticated with check (
        client_id = auth.uid()
        and public.is_active_user()
        and not public.is_admin()
        and exists (
            select 1 from public.delivery_orders o
            where o.id = order_id
              and o.client_id = auth.uid()
              and o.courier_id = courier_id
              and o.status = 'delivered'
        )
    );
drop policy if exists "admin activity read only admins" on public.admin_activity_log;
create policy "admin activity read only admins" on public.admin_activity_log
    for select to authenticated using (public.is_admin());

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('courier-documents', 'courier-documents', false, 10485760, array['application/pdf', 'image/jpeg', 'image/png'])
on conflict (id) do update set public = false, file_size_limit = 10485760,
    allowed_mime_types = array['application/pdf', 'image/jpeg', 'image/png'];

drop policy if exists "courier upload own documents" on storage.objects;
create policy "courier upload own documents" on storage.objects
    for insert to authenticated with check (
        bucket_id = 'courier-documents'
        and (storage.foldername(name))[1] = auth.uid()::text
        and public.is_active_user()
        and exists (
            select 1 from public.courier_profiles cp where cp.user_id = auth.uid()
        )
    );
drop policy if exists "courier view own documents or admin" on storage.objects;
create policy "courier view own documents or admin" on storage.objects
    for select to authenticated using (
        bucket_id = 'courier-documents'
        and (((storage.foldername(name))[1] = auth.uid()::text and public.is_active_user()) or public.is_admin())
    );
drop policy if exists "courier delete own documents while pending" on storage.objects;
create policy "courier delete own documents while pending" on storage.objects
    for delete to authenticated using (
        bucket_id = 'courier-documents'
        and (storage.foldername(name))[1] = auth.uid()::text
        and public.is_active_user()
        and exists (
            select 1 from public.courier_profiles cp
            where cp.user_id = auth.uid() and cp.approval_status in ('pending', 'rejected')
        )
    );

grant execute on function public.accept_delivery(uuid) to authenticated;
grant execute on function public.respond_to_delivery(uuid, text) to authenticated;
grant execute on function public.advance_delivery(uuid, text) to authenticated;
grant execute on function public.cancel_delivery(uuid) to authenticated;
grant execute on function public.set_courier_online(boolean) to authenticated;
grant execute on function public.submit_courier_documents(text[]) to authenticated;
grant execute on function public.mark_courier_earning_paid(uuid) to authenticated;
revoke all on function public.admin_set_account_blocked(uuid, boolean, text) from public, anon;
revoke all on function public.admin_dashboard_summary() from public, anon;
grant execute on function public.admin_set_account_blocked(uuid, boolean, text) to authenticated;
grant execute on function public.admin_dashboard_summary() to authenticated;
revoke all on function public.review_courier_profile(uuid, text, text) from public, anon;
grant execute on function public.review_courier_profile(uuid, text, text) to authenticated;
revoke all on function public.accept_delivery(uuid) from public, anon;
revoke all on function public.respond_to_delivery(uuid, text) from public, anon;
revoke all on function public.advance_delivery(uuid, text) from public, anon;
revoke all on function public.cancel_delivery(uuid) from public, anon;
revoke all on function public.set_courier_online(boolean) from public, anon;
revoke all on function public.submit_courier_documents(text[]) from public, anon;
revoke all on function public.mark_courier_earning_paid(uuid) from public, anon;
revoke all on function public.review_courier_profile(uuid, text, text) from public, anon;
revoke all on function public.log_admin_activity(text, text, text, jsonb) from public, anon, authenticated;
revoke all on function public.grant_admin_role_for_allowlisted_email() from public, anon, authenticated;
revoke all on function public.handle_new_user() from public, anon, authenticated;
revoke all on function public.prepare_delivery_order() from public, anon, authenticated;
revoke all on function public.record_courier_earning() from public, anon, authenticated;

-- Only these two allowlisted accounts receive the administrator claim.
update auth.users
set raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) - 'role'
where raw_app_meta_data ->> 'role' = 'admin'
  and coalesce(lower(email), '') not in (
      select email from public.admin_access_slots
  );

update auth.users
set raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb
where lower(email) in (
    select email from public.admin_access_slots
);

-- Live courier coordinates are isolated from delivery order data and can only
-- be written by the courier currently assigned to an active delivery.
create table if not exists public.courier_locations (
    order_id uuid primary key references public.delivery_orders(id) on delete cascade,
    courier_id uuid not null references public.profiles(id) on delete cascade,
    latitude double precision not null check (latitude between -90 and 90),
    longitude double precision not null check (longitude between -180 and 180),
    accuracy_m double precision check (accuracy_m is null or accuracy_m between 0 and 100000),
    heading double precision check (heading is null or heading between 0 and 360),
    speed_mps double precision check (speed_mps is null or speed_mps between 0 and 100),
    updated_at timestamptz not null default now()
);

alter table public.courier_locations enable row level security;
revoke all on public.courier_locations from anon, authenticated;
grant select on public.courier_locations to authenticated;

drop policy if exists "active order participants read courier location" on public.courier_locations;
create policy "active order participants read courier location" on public.courier_locations
    for select to authenticated using (
        public.is_active_user()
        and exists (
            select 1
            from public.delivery_orders o
            where o.id = courier_locations.order_id
              and o.courier_id = courier_locations.courier_id
              and o.status in ('accepted', 'pickup_started', 'collected', 'in_transit')
              and (o.client_id = auth.uid() or o.courier_id = auth.uid() or public.is_admin())
        )
    );

create or replace function public.update_courier_location(
    p_order_id uuid,
    p_latitude double precision,
    p_longitude double precision,
    p_accuracy_m double precision default null,
    p_heading double precision default null,
    p_speed_mps double precision default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
    if auth.uid() is null
       or p_latitude is null or p_latitude not between -90 and 90
       or p_longitude is null or p_longitude not between -180 and 180
       or (p_accuracy_m is not null and p_accuracy_m not between 0 and 100000)
       or (p_heading is not null and p_heading not between 0 and 360)
       or (p_speed_mps is not null and p_speed_mps not between 0 and 100) then
        raise exception 'Coordenadas de localização inválidas.';
    end if;

    if not exists (
        select 1
        from public.delivery_orders o
        join public.profiles p on p.id = o.courier_id
        join public.courier_profiles cp on cp.user_id = o.courier_id
        where o.id = p_order_id
          and o.courier_id = auth.uid()
          and o.status in ('accepted', 'pickup_started', 'collected', 'in_transit')
          and p.role = 'courier'
          and p.account_status = 'active'
          and cp.approval_status = 'approved'
    ) then
        raise exception 'O entregador não está autorizado a atualizar a localização deste pedido.';
    end if;

    insert into public.courier_locations (
        order_id, courier_id, latitude, longitude, accuracy_m, heading, speed_mps, updated_at
    ) values (
        p_order_id, auth.uid(), p_latitude, p_longitude, p_accuracy_m, p_heading, p_speed_mps, now()
    )
    on conflict (order_id) do update set
        courier_id = excluded.courier_id,
        latitude = excluded.latitude,
        longitude = excluded.longitude,
        accuracy_m = excluded.accuracy_m,
        heading = excluded.heading,
        speed_mps = excluded.speed_mps,
        updated_at = now();
end;
$$;

revoke all on function public.update_courier_location(uuid, double precision, double precision, double precision, double precision, double precision)
    from public, anon;
grant execute on function public.update_courier_location(uuid, double precision, double precision, double precision, double precision, double precision)
    to authenticated;

notify pgrst, 'reload schema';

create or replace function public.clear_inactive_courier_location()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
    if new.status not in ('accepted', 'pickup_started', 'collected', 'in_transit') then
        delete from public.courier_locations where order_id = new.id;
    end if;
    return new;
end;
$$;

revoke all on function public.clear_inactive_courier_location() from public, anon, authenticated;
drop trigger if exists clear_inactive_courier_location on public.delivery_orders;
create trigger clear_inactive_courier_location
    after update of status on public.delivery_orders
    for each row execute function public.clear_inactive_courier_location();

do $$
begin
    if not exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
        raise exception 'A publicação supabase_realtime não existe neste projeto Supabase.';
    end if;

    if not exists (
        select 1 from pg_publication_tables
        where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'delivery_orders'
    ) then
        alter publication supabase_realtime add table public.delivery_orders;
    end if;

    if not exists (
        select 1 from pg_publication_tables
        where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'courier_locations'
    ) then
        alter publication supabase_realtime add table public.courier_locations;
    end if;
end;
$$;
