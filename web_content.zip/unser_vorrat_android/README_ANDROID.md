# Unser Vorrat – Android-App

Diese Version verpackt die bestehende Web-App als native Android-WebView-App.
Die bestehende Supabase-Anbindung und das komplette Rezeptsystem bleiben erhalten.

## Projekt
- App-Name: Unser Vorrat
- Application ID: de.unservorrat.app
- Min SDK: 23
- Target/Compile SDK: 35
- Kamera-Berechtigung ist für den vorhandenen Barcode-Scanner vorbereitet.
- App-Icon: Fledermaus im Rot/Blau-Stil.

## Mit Android Studio bauen
1. Android Studio installieren.
2. Dieses Projekt öffnen (Ordner, in dem `settings.gradle` liegt).
3. Gradle-Synchronisierung abwarten.
4. Falls Android Studio SDK 35 anfordert, installieren.
5. `Build > Build Bundle(s) / APK(s) > Build APK(s)` auswählen.
6. Die erzeugte Debug-APK liegt unter:
   `android/app/build/outputs/apk/debug/app-debug.apk`

## Alternativ: GitHub Actions
Die Datei `.github/workflows/build-apk.yml` kann manuell gestartet werden.
Sie baut die APK auf GitHub und stellt sie als Workflow-Artefakt bereit.

## Wichtig
Die App nutzt weiterhin Supabase als gemeinsames Backend. Die Zugangsdaten sind dieselben Publishable/Anon-Daten wie in der bisherigen Web-App. Keine Service-Role-/Secret-Keys verwenden.
