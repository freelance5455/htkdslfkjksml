# Unser Vorrat: no custom ProGuard rules required.
