Unser Vorrat 2.0
Supabase project: https://maztcaldlmjsgftoejku.supabase.co

Enthalten:
- Login/Konto erstellen
- Haushalt erstellen/beitreten
- gemeinsamer Vorrat
- MHD, Kategorien, Lagerorte, Mindestbestand
- Suche und Filter
- Einkaufsliste
- Realtime

Die Datei index.html muss im Root des Netlify-Deployments liegen.
