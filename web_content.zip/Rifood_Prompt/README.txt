RIFOOD PROMPT

File utama aplikasi: index.html

Cara pakai:
1. Ekstrak ZIP ini.
2. Buka index.html di browser untuk menjalankan aplikasi.
3. Untuk upload ke Netlify Drop, upload folder Rifood_Prompt yang sudah diekstrak (atau ZIP jika situs meminta folder/arsip).

Aplikasi ini berupa web app statis, bukan APK Android.
