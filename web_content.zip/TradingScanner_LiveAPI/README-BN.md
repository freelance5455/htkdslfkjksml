# Trading Scanner — Live Market API version

এই project Twelve Data-এর real forex market data ব্যবহার করার জন্য তৈরি।

## গুরুত্বপূর্ণ
- Twelve Data Basic plan বর্তমানে free এবং real-time forex + technical indicators দেয়; তাদের pricing page অনুযায়ী Basic-এ 800 API requests/day আছে। Individual Basic personal/internal/non-commercial use-এর জন্য। Public/commercial data redistribution-এর জন্য আলাদা licensing প্রয়োজন।
- Quotex-এর `OTC` symbols Twelve Data-এর normal forex feed নয়। এই project তাই `EUR/USD`, `GBP/USD`, `USD/JPY`, `AUD/USD`-এর মতো real forex pairs ব্যবহার করে।
- API key Android app-এর মধ্যে রাখা হয়নি। Backend-এর environment variable-এ রাখতে হবে।

## 1) Twelve Data API key
Official site: https://twelvedata.com/
Account খুলে dashboard থেকে API key নিন।

## 2) Backend চালানো
Node.js 18+ লাগবে।

backend folder:
    npm install

তারপর:
    TWELVE_DATA_API_KEY=আপনার_KEY npm start

Windows PowerShell:
    $env:TWELVE_DATA_API_KEY="আপনার_KEY"
    npm start

Backend হবে:
    http://localhost:8080

## 3) Android app
android folder Android Studio-তে Open করুন।
Build > Build APK(s)

App খুলে Backend URL-এ আপনার deployed HTTPS backend দিন।
উদাহরণ:
    https://your-backend.example.com

## 4) Production
Backend-টি HTTPS-এ deploy করুন। API key কখনো Android HTML/JavaScript-এ hard-code করবেন না।

## Signal logic
BUY = EMA9 > EMA21 + RSI14 50-70 + price > EMA9
SELL = EMA9 < EMA21 + RSI14 30-50 + price < EMA9
Otherwise WAIT

এটি educational/rule-based analysis; 100% accurate signal নয় এবং কোনো trade execute করে না।
