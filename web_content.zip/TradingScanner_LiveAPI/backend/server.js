import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

const KEY = process.env.TWELVE_DATA_API_KEY;
const PORT = process.env.PORT || 8080;
const allowed = new Set(["EUR/USD","GBP/USD","USD/JPY","AUD/USD"]);
const intervals = new Set(["1min","5min","15min"]);

function ema(values, period){
  if(values.length < period) return null;
  const k = 2/(period+1);
  let e = values.slice(0,period).reduce((a,b)=>a+b,0)/period;
  for(let i=period;i<values.length;i++) e = values[i]*k + e*(1-k);
  return e;
}
function rsi(values, period=14){
  if(values.length <= period) return null;
  let gain=0, loss=0;
  for(let i=1;i<=period;i++){ const d=values[i]-values[i-1]; if(d>=0) gain+=d; else loss-=d; }
  gain/=period; loss/=period;
  for(let i=period+1;i<values.length;i++){
    const d=values[i]-values[i-1], g=Math.max(d,0), l=Math.max(-d,0);
    gain=(gain*(period-1)+g)/period; loss=(loss*(period-1)+l)/period;
  }
  if(loss===0) return 100;
  return 100-(100/(1+gain/loss));
}

app.get("/health",(req,res)=>res.json({ok:true,service:"Trading Scanner Backend"}));

app.get("/analyze", async (req,res)=>{
  try{
    if(!KEY) return res.status(500).json({error:"Server API key is not configured."});
    const symbol = String(req.query.symbol||"EUR/USD");
    const interval = String(req.query.interval||"1min");
    if(!allowed.has(symbol)) return res.status(400).json({error:"Unsupported symbol."});
    if(!intervals.has(interval)) return res.status(400).json({error:"Unsupported interval."});

    const url = new URL("https://api.twelvedata.com/time_series");
    url.searchParams.set("symbol",symbol);
    url.searchParams.set("interval",interval);
    url.searchParams.set("outputsize","120");
    url.searchParams.set("apikey",KEY);

    const response = await fetch(url);
    const data = await response.json();
    if(!response.ok || data.status==="error" || !data.values)
      return res.status(502).json({error:data.message||"Market data unavailable."});

    const rows = [...data.values].reverse();
    const closes = rows.map(x=>Number(x.close)).filter(Number.isFinite);
    if(closes.length < 30) return res.status(502).json({error:"Not enough market data."});

    const e9=ema(closes,9), e21=ema(closes,21), rv=rsi(closes,14);
    const last=rows[rows.length-1], prev=rows[rows.length-2];
    const candle=Number(last.close)>Number(last.open)?"GREEN":Number(last.close)<Number(last.open)?"RED":"DOJI";

    let signal="WAIT", reason="Indicators are mixed; wait for confirmation.";
    if(e9>e21 && rv>=50 && rv<70 && Number(last.close)>e9){
      signal="BUY"; reason="EMA 9 is above EMA 21, RSI is above 50, and price is above EMA 9.";
    } else if(e9<e21 && rv<50 && rv>30 && Number(last.close)<e9){
      signal="SELL"; reason="EMA 9 is below EMA 21, RSI is below 50, and price is below EMA 9.";
    }

    res.json({
      symbol, interval, price:Number(last.close), datetime:last.datetime,
      rsi:Number(rv.toFixed(2)), ema9:Number(e9.toFixed(6)), ema21:Number(e21.toFixed(6)),
      candle, signal, reason, previous_close:Number(prev.close)
    });
  }catch(e){
    res.status(500).json({error:"Backend error: "+e.message});
  }
});

app.listen(PORT,()=>console.log(`Trading Scanner backend listening on ${PORT}`));
