

const API_ROOT="https://ultratech-iot.com/";
const STATUS_PATH="/isHardwareConnected";
function tokenFromWidget(w){
 if(w?.token)return String(w.token).trim();
 for(const candidate of [w?.url,w?.statusUrl]){
  if(!candidate)continue;
  try{const u=new URL(candidate);if(u.hostname.toLowerCase()==="ultratech-iot.com"){const m=u.pathname.match(/^\/([^/]+)\/(?:get\/V\d+|isHardwareConnected)\/?$/);if(m)return decodeURIComponent(m[1]);}}catch(e){}
 }
 return "";
}
function extractVirtualNumber(w){for(const candidate of [w?.url,w?.valueUrl]){if(!candidate)continue;try{const u=new URL(candidate);const m=u.pathname.match(/\/get\/V(\d+)\/?$/);if(m)return Number(m[1]);}catch(e){}}return 23;}
function valueUrlFor(w){const pin=Math.max(0,Math.min(999,parseInt(w?.virtualNumber??23,10)||0));return API_ROOT+encodeURIComponent(tokenFromWidget(w))+"/get/V"+pin;}
function statusUrlFor(w){return API_ROOT+encodeURIComponent(tokenFromWidget(w))+STATUS_PATH;}
const projectGrid=document.getElementById("projectGrid"), widgetGrid=document.getElementById("widgetGrid");
const projectEditor=document.getElementById("projectEditor"),widgetEditor=document.getElementById("widgetEditor");
const remoteUrlEditor=document.getElementById("remoteUrlEditor");
const projectForm=document.getElementById("projectForm"),widgetForm=document.getElementById("widgetForm");
// Hidden fields belonging to other widget types must never block saving in mobile WebViews.
widgetForm.noValidate=true;
let projects=[],activeProjectId=null,activeTabId=null,refreshTimers={},sortMode=false;
let projectLayoutMode=false;
let projectLayout={columns:2,rowColumns:[],cardHeight:142};
try{const savedProjectLayout=JSON.parse(localStorage.getItem("ultra_project_layout")||"null");if(savedProjectLayout&&typeof savedProjectLayout==="object")projectLayout={columns:Math.max(1,Math.min(6,parseInt(savedProjectLayout.columns,10)||2)),rowColumns:Array.isArray(savedProjectLayout.rowColumns)?savedProjectLayout.rowColumns.slice(0,9).map(v=>Math.max(1,Math.min(6,parseInt(v,10)||2))):[],cardHeight:Math.max(120,Math.min(260,parseInt(savedProjectLayout.cardHeight,10)||142))};}catch(e){}
function saveProjectLayout(){localStorage.setItem("ultra_project_layout",JSON.stringify(projectLayout));}
function projectRowCapacity(row){return Math.max(1,Math.min(6,parseInt(projectLayout.rowColumns[row],10)||projectLayout.columns||2));}
function renderProjectLayoutControls(){const select=document.getElementById("projectDefaultColumns");select.value=String(projectLayout.columns);document.getElementById("projectDefaultColumnsValue").textContent=String(projectLayout.columns);const heightInput=document.getElementById("projectCardHeight");heightInput.value=String(projectLayout.cardHeight);document.getElementById("projectCardHeightValue").textContent=projectLayout.cardHeight+" px";projectGrid.style.setProperty("--project-card-height",projectLayout.cardHeight+"px");document.getElementById("projectRowLayoutControls").innerHTML=Array.from({length:9},(_,row)=>{const value=projectRowCapacity(row);return `<div class="row-layout-item"><label for="projectRowColumns${row}"><span>الصف ${row+1}</span><strong>${value}</strong></label><select id="projectRowColumns${row}" data-project-row-columns="${row}">${[1,2,3,4,5,6].map(n=>`<option value="${n}" ${value===n?"selected":""}>${n===1?"مشروع واحد":n===2?"مشروعان":n+" مشاريع"}</option>`).join("")}</select></div>`;}).join("");}
try{
 const saved=JSON.parse(localStorage.getItem("ultra_projects")||"null");
 if(Array.isArray(saved))projects=saved.map((p,pi)=>{
  const normalizeWidgets=list=>(list||[]).map((w,i)=>({...w,slot:Number.isInteger(Number(w.slot))&&Number(w.slot)>=0?Number(w.slot):i,token:tokenFromWidget(w)}));
  const tabs=Array.isArray(p.tabs)&&p.tabs.length?p.tabs.map((t,ti)=>({...t,id:String(t.id||`tab-${pi}-${ti}`),name:String(t.name||`تبويب ${ti+1}`),widgets:normalizeWidgets(t.widgets),layoutColumns:Math.max(1,Math.min(6,parseInt(t.layoutColumns,10)||parseInt(p.layoutColumns,10)||3)),rowColumns:Array.isArray(t.rowColumns)?t.rowColumns.slice(0,9):[],rowHeights:Array.isArray(t.rowHeights)?t.rowHeights.slice(0,9).map(v=>v===null||v===undefined||v===""?null:Math.max(0,Math.min(400,parseInt(v,10)||0))):[],layoutScale:Math.max(.25,Math.min(1.4,Number(t.layoutScale)||Number(p.layoutScale)||1)),gridLayoutEnabled:true,gridResolution:Number(t.gridResolution)||6})): [{id:`tab-home-${p.id||pi}`,name:"الرئيسية",widgets:normalizeWidgets(p.widgets),layoutColumns:Math.max(1,Math.min(6,parseInt(p.layoutColumns,10)||3)),rowColumns:Array.isArray(p.rowColumns)?p.rowColumns.slice(0,9):[],rowHeights:Array.isArray(p.rowHeights)?p.rowHeights.slice(0,9).map(v=>v===null||v===undefined||v===""?null:Math.max(0,Math.min(400,parseInt(v,10)||0))):[],layoutScale:Math.max(.25,Math.min(1.4,Number(p.layoutScale)||1)),gridLayoutEnabled:true,gridResolution:Number(p.gridResolution)||6}];
  const activeTabId=tabs.some(t=>t.id===p.activeTabId)?p.activeTabId:tabs[0].id;const active=tabs.find(t=>t.id===activeTabId);
  return {...p,tabs,tabsWidget:p.tabsWidget===true||(p.tabsWidget===undefined&&tabs.length>1),activeTabId,widgets:active.widgets,layoutColumns:active.layoutColumns,rowColumns:active.rowColumns,rowHeights:active.rowHeights,layoutScale:active.layoutScale,gridResolution:active.gridResolution};
 });
 else{
  const old=JSON.parse(localStorage.getItem("ultra_widgets")||"null");
  if(Array.isArray(old)&&old.length)projects=[{id:"legacy-project",name:"مشروعي الأول",widgets:old.map((w,i)=>({...w,slot:i,token:tokenFromWidget(w),statusUrl:"",precision:1,interval:5}))}];
 }
}catch(e){projects=[]}
function syncActiveTab(project){if(!project||!Array.isArray(project.tabs))return;const tab=project.tabs.find(t=>String(t.id)===String(project.activeTabId))||project.tabs[0];if(!tab)return;project.activeTabId=tab.id;tab.widgets=project.widgets||[];tab.layoutColumns=project.layoutColumns||3;tab.rowColumns=project.rowColumns||[];tab.rowHeights=project.rowHeights||[];tab.layoutScale=project.layoutScale||1;tab.gridLayoutEnabled=true;tab.gridResolution=project.gridResolution||12;}
function save(){const project=projects.find(x=>String(x.id)===String(activeProjectId));if(project)syncActiveTab(project);localStorage.setItem("ultra_projects",JSON.stringify(projects))}
function activateProjectTab(project,tabId){if(!project)return;syncActiveTab(project);const tab=project.tabs.find(t=>String(t.id)===String(tabId))||project.tabs[0];if(!tab)return;project.activeTabId=tab.id;activeTabId=tab.id;project.widgets=tab.widgets||[];project.layoutColumns=tab.layoutColumns||3;project.rowColumns=tab.rowColumns||[];project.rowHeights=tab.rowHeights||[];project.layoutScale=tab.layoutScale||1;project.gridLayoutEnabled=true;project.gridResolution=tab.gridResolution||6;save();}
function renderProjectTabs(project,showAddButton=false){const nav=document.getElementById("projectTabs");nav.classList.toggle("sort-mode",!!showAddButton);if(!project||!project.tabsWidget){nav.hidden=true;nav.innerHTML="";return;}nav.hidden=false;nav.innerHTML=project.tabs.map(t=>`<span class="project-tab-wrap" data-tab-wrap="${esc(t.id)}"><button type="button" class="project-tab ${t.id===project.activeTabId?"active":""}" data-project-tab="${esc(t.id)}" aria-label="${esc(t.name)} - اسحب لإعادة الترتيب">${esc(t.name)}</button><button type="button" class="tab-delete-btn" data-tab-delete="${esc(t.id)}" aria-label="حذف التبويب ${esc(t.name)}" title="حذف التبويب">×</button></span>`).join("")+(showAddButton?`<button type="button" class="project-tab project-tab-add" id="addProjectTab" aria-label="إضافة تبويب" title="إضافة تبويب">＋</button><button type="button" class="project-tabs-widget-delete" id="deleteTabsWidget" aria-label="حذف ويدجت التبويبات بالكامل" title="حذف ويدجت Tabs بالكامل">×</button>`:"");}
const projectTabsNav=document.getElementById("projectTabs");
projectTabsNav.addEventListener("click",e=>{if(suppressTabClick){e.preventDefault();e.stopPropagation();return;}const del=e.target.closest("[data-tab-delete]");if(del){const project=projects.find(x=>x.id===activeProjectId),tab=project?.tabs.find(t=>t.id===del.dataset.tabDelete);if(!project||!tab)return;if(project.tabs.length===1){showToast("يجب أن يحتوي المشروع على تبويب واحد على الأقل");return;}if(!confirm(`حذف التبويب «${tab.name}» وجميع مؤشراته؟`))return;syncActiveTab(project);const wasActive=project.activeTabId===tab.id;project.tabs=project.tabs.filter(t=>t.id!==tab.id);if(wasActive){const next=project.tabs[0];activateProjectTab(project,next.id);}save();render();showToast("تم حذف التبويب ومؤشراته");return;}if(e.target.closest("#deleteTabsWidget")){const project=projects.find(x=>x.id===activeProjectId);if(!project)return;if(!confirm("هل تريد حذف ويدجت Tabs بالكامل مع جميع التبويبات والمؤشرات الموجودة داخلها؟"))return;project.tabsWidget=false;project.tabs=[{id:"tab-home-"+Date.now(),name:"الرئيسية",widgets:[],layoutColumns:project.layoutColumns||3,rowColumns:[],rowHeights:[],layoutScale:project.layoutScale||1,gridLayoutEnabled:true,gridResolution:6}];project.activeTabId=project.tabs[0].id;project.widgets=[];project.layoutColumns=project.tabs[0].layoutColumns;project.rowColumns=[];project.rowHeights=[];project.layoutScale=project.tabs[0].layoutScale;activeTabId=project.activeTabId;save();sortMode=false;render();showToast("تم حذف ويدجت Tabs بالكامل");return;}const tabBtn=e.target.closest("[data-project-tab]");if(tabBtn){const project=projects.find(x=>x.id===activeProjectId);if(!project)return;const tab=project.tabs.find(t=>t.id===tabBtn.dataset.projectTab);if(!tab)return;activateProjectTab(project,tab.id);sortMode=false;render();return;}if(e.target.closest("#addProjectTab")){const project=projects.find(x=>x.id===activeProjectId);if(!project)return;const name=prompt("اسم التبويب الجديد:",`تبويب ${project.tabs.length+1}`);if(!name||!name.trim())return;syncActiveTab(project);const tab={id:"tab-"+Date.now()+"-"+Math.random().toString(36).slice(2,6),name:name.trim().slice(0,30),widgets:[],layoutColumns:project.layoutColumns||3,rowColumns:[],rowHeights:[],layoutScale:project.layoutScale||1,gridLayoutEnabled:true,gridResolution:6};project.tabs.push(tab);activateProjectTab(project,tab.id);sortMode=false;save();render();}});
let tabDragState=null, suppressTabClick=false;
projectTabsNav.addEventListener("pointerdown",e=>{const b=e.target.closest("[data-project-tab]");if(!b||e.button!==0)return;tabDragState={id:b.dataset.projectTab,startX:e.clientX,startY:e.clientY,dragging:false,overId:b.dataset.projectTab};});
document.addEventListener("pointermove",e=>{if(!tabDragState)return;const dx=e.clientX-tabDragState.startX,dy=e.clientY-tabDragState.startY;if(!tabDragState.dragging&&Math.hypot(dx,dy)<7)return;tabDragState.dragging=true;suppressTabClick=true;projectTabsNav.querySelector(`[data-project-tab="${tabDragState.id}"]`)?.classList.add("tab-dragging");const hit=document.elementFromPoint(e.clientX,e.clientY)?.closest("[data-project-tab]");projectTabsNav.querySelectorAll(".tab-drop-target").forEach(el=>el.classList.remove("tab-drop-target"));if(hit){tabDragState.overId=hit.dataset.projectTab;hit.classList.add("tab-drop-target");}e.preventDefault();},{passive:false});
document.addEventListener("pointerup",()=>{if(!tabDragState)return;const state=tabDragState;tabDragState=null;projectTabsNav.querySelectorAll(".tab-dragging,.tab-drop-target").forEach(el=>el.classList.remove("tab-dragging","tab-drop-target"));if(!state.dragging){setTimeout(()=>{suppressTabClick=false;},0);return;}const project=projects.find(x=>x.id===activeProjectId);if(project&&state.overId&&state.id!==state.overId){const from=project.tabs.findIndex(t=>t.id===state.id),to=project.tabs.findIndex(t=>t.id===state.overId);if(from>=0&&to>=0){const [tab]=project.tabs.splice(from,1);project.tabs.splice(to,0,tab);save();render();showToast("تم نقل التبويب");}}setTimeout(()=>{suppressTabClick=false;},180);});
projectTabsNav.addEventListener("dblclick",e=>{const b=e.target.closest("[data-project-tab]");if(!b)return;const project=projects.find(x=>x.id===activeProjectId),tab=project?.tabs.find(t=>t.id===b.dataset.projectTab);if(!project||!tab)return;const next=prompt("اسم التبويب:",tab.name);if(next===null)return;if(!next.trim())return;tab.name=next.trim().slice(0,30);save();render();});
// Force Arabic-Indic and Persian digits to ASCII in numeric entry fields.
function toLatinDigits(value){return String(value??"").replace(/[٠-٩۰-۹]/g,ch=>{const code=ch.charCodeAt(0);return String(code>=0x06f0?code-0x06f0:code-0x0660);});}
document.addEventListener("input",e=>{const el=e.target;if(!(el instanceof HTMLInputElement)||!el.matches(".numeric-current"))return;const before=el.value,after=toLatinDigits(before);if(before!==after){const start=el.selectionStart;el.value=after;try{el.setSelectionRange(start,start);}catch(_){}}},true);
document.addEventListener("paste",e=>{const el=e.target;if(!(el instanceof HTMLInputElement)||!el.matches(".numeric-current"))return;const pasted=(e.clipboardData||window.clipboardData)?.getData("text");if(!pasted)return;const normalized=toLatinDigits(pasted);if(normalized!==pasted){e.preventDefault();document.execCommand("insertText",false,normalized);}},true);
// قائمة الأدوات الصغيرة في زاوية الشاشة.
const toolsMenu=document.getElementById("toolsMenu"),toolsMenuBtn=document.getElementById("toolsMenuBtn");
function closeToolsMenu(){toolsMenu.hidden=true;toolsMenuBtn.setAttribute("aria-expanded","false")}
function placeToolsMenu(){const r=toolsMenuBtn.getBoundingClientRect(),w=Math.min(300,window.innerWidth-24),left=Math.max(12,Math.min(window.innerWidth-w-12,r.right-w)),h=toolsMenu.offsetHeight;let top=r.bottom+8;if(top+h>window.innerHeight-12)top=Math.max(12,r.top-h-8);toolsMenu.style.width=w+"px";toolsMenu.style.left=left+"px";toolsMenu.style.top=top+"px";toolsMenu.style.right="auto"} toolsMenuBtn.addEventListener("click",e=>{e.stopPropagation();toolsMenu.hidden=!toolsMenu.hidden;if(!toolsMenu.hidden)placeToolsMenu();toolsMenuBtn.setAttribute("aria-expanded",String(!toolsMenu.hidden))});window.addEventListener("resize",()=>{if(!toolsMenu.hidden)placeToolsMenu()});window.addEventListener("scroll",()=>{if(!toolsMenu.hidden)placeToolsMenu()},true);
document.addEventListener("click",e=>{if(!toolsMenu.hidden&&!toolsMenu.contains(e.target)&&e.target!==toolsMenuBtn)closeToolsMenu()});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeToolsMenu()});
// نظام نقل ونسخ احتياطي: مشروع واحد أو جميع المشاريع، مع خيارات استيراد آمنة.
const transferPage=document.getElementById("transferPage"),transferText=document.getElementById("transferText");
const backupChoiceEditor=document.getElementById("backupChoiceEditor");
function closeTransferPage(){transferPage.hidden=true;document.body.style.overflow="";document.querySelector("main").hidden=false;document.getElementById("addBtn").hidden=activeProjectId? !sortMode:false;}
function showTransferPage(mode){
 closeToolsMenu();if(transferPage.parentElement!==document.body)document.body.appendChild(transferPage);document.body.style.overflow="hidden";document.querySelector("main").hidden=true;document.getElementById("addBtn").hidden=true;transferPage.hidden=false;
 const backup=mode==="backup";document.getElementById("transferTitle").textContent=backup?"تصدير نسخة احتياطية":"استيراد نسخة احتياطية";
 document.getElementById("transferHelp").textContent=backup?"انسخ كود JSON أو نزّله كملف، ثم انقله إلى الجهاز الآخر.":"الصق كود JSON هنا. سيُفحص محتوى النسخة قبل تطبيقها، ويمكنك اختيار طريقة الاستيراد.";
 document.getElementById("backupActions").hidden=!backup;document.getElementById("restoreActions").hidden=backup;document.getElementById("importOptions").hidden=true;
 transferText.value="";transferText.readOnly=backup;if(!backup)transferText.focus();
}
function backupPayload(scope,projectId){
 const active=projects.find(p=>String(p.id)===String(activeProjectId));if(active)syncActiveTab(active);
 const meta={app:"AltraTech Dashboard",formatVersion:2,backupType:scope,createdAt:new Date().toISOString(),projectCount:scope==="single"?1:projects.length,widgetCount:scope==="single"?(projects.find(p=>p.id===projectId)?.tabs||[]).reduce((n,t)=>n+(t.widgets||[]).length,0):projects.reduce((n,p)=>n+(p.tabs||[]).reduce((m,t)=>m+(t.widgets||[]).length,0),0)};
 if(scope==="single"){const p=projects.find(x=>x.id===projectId);if(!p)throw new Error("project missing");return {...meta,project:JSON.parse(JSON.stringify(p))};}
 return {...meta,projects:JSON.parse(JSON.stringify(projects))};
}
window.backupProject=id=>{try{const payload=backupPayload("single",id);showTransferPage("backup");transferText.value=JSON.stringify(payload,null,2);document.getElementById("transferHelp").textContent="هذه نسخة احتياطية مستقلة لهذا المشروع فقط، وتشمل إعداداته ومؤشراته وترتيبها وتخطيط الصفوف. انسخ الكود أو نزّله لنقله إلى جهاز آخر.";}catch(err){showToast("تعذر إنشاء النسخة الاحتياطية لهذا المشروع");}};
function openBackupChoice(){closeToolsMenu();const select=document.getElementById("backupProjectSelect");select.innerHTML=projects.map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join("");select.disabled=!projects.length;document.getElementById("backupScope").value="all";document.getElementById("backupProjectField").hidden=true;backupChoiceEditor.showModal();}
document.getElementById("backupBtn").addEventListener("click",openBackupChoice);
document.getElementById("closeBackupChoice").onclick=()=>backupChoiceEditor.close();document.getElementById("cancelBackupChoice").onclick=()=>backupChoiceEditor.close();
document.getElementById("backupScope").addEventListener("change",e=>{document.getElementById("backupProjectField").hidden=e.target.value!=="single";});
document.getElementById("backupChoiceForm").addEventListener("submit",e=>{e.preventDefault();const scope=document.getElementById("backupScope").value,id=document.getElementById("backupProjectSelect").value;if(scope==="single"&&!id){showToast("لا يوجد مشروع لتصديره");return;}try{const payload=backupPayload(scope,id);backupChoiceEditor.close();showTransferPage("backup");transferText.value=JSON.stringify(payload,null,2);document.getElementById("transferHelp").textContent=scope==="single"?"هذه نسخة مستقلة لمشروع واحد، وتشمل إعداداته ومؤشراته وترتيبها وتخطيط الصفوف.":"هذه نسخة شاملة لجميع المشاريع في ملف JSON واحد، وتشمل إعدادات كل مشروع ومؤشراته وترتيبها.";}catch(err){showToast("تعذر إنشاء النسخة الاحتياطية");}});
document.getElementById("pasteRestoreBtn").addEventListener("click",()=>showTransferPage("restore"));
document.getElementById("remoteRestoreBtn").addEventListener("click",()=>{closeToolsMenu();document.getElementById("remoteBackupUrl").value=localStorage.getItem("altra_remote_backup_url")||"";updateRemoteStatus("يتم فحص الرابط تلقائياً عند فتح التطبيق. النسخة الجديدة لن تُطبق إلا بعد موافقتك.");remoteUrlEditor.showModal();});
document.getElementById("closeRemoteUrl").onclick=()=>remoteUrlEditor.close();document.getElementById("cancelRemoteUrl").onclick=()=>remoteUrlEditor.close();
function updateRemoteStatus(message){document.getElementById("remoteStatus").textContent=message}
document.getElementById("remoteUrlForm").addEventListener("submit",e=>{e.preventDefault();const input=document.getElementById("remoteBackupUrl"),url=input.value.trim();if(url){try{const parsed=new URL(url);if(parsed.protocol!=="https:"&&parsed.protocol!=="http:")throw new Error();}catch(err){updateRemoteStatus("الرابط غير صالح. أدخل رابط HTTP أو HTTPS مباشر لملف JSON.");return;}}const previous=localStorage.getItem("altra_remote_backup_url")||"";if(previous!==url)localStorage.removeItem("altra_remote_backup_hash");if(url)localStorage.setItem("altra_remote_backup_url",url);else localStorage.removeItem("altra_remote_backup_url");updateRemoteStatus(url?"تم حفظ الرابط. سيُفحص تلقائياً عند تشغيل التطبيق.":"تم حذف رابط الاستعادة.");showToast(url?"تم حفظ رابط الاستعادة عبر الإنترنت":"تم حذف رابط الاستعادة");});
document.getElementById("checkRemoteNow").addEventListener("click",async()=>{const url=document.getElementById("remoteBackupUrl").value.trim();if(!url){updateRemoteStatus("أدخل الرابط أولاً ثم احفظه.");return;}try{new URL(url)}catch(e){updateRemoteStatus("الرابط غير صالح.");return;}const previous=localStorage.getItem("altra_remote_backup_url")||"";if(previous!==url)localStorage.removeItem("altra_remote_backup_hash");localStorage.setItem("altra_remote_backup_url",url);await checkRemoteBackup(true);});
document.getElementById("transferBack").addEventListener("click",closeTransferPage);
document.getElementById("copyBackup").addEventListener("click",async()=>{try{transferText.focus();transferText.select();transferText.setSelectionRange(0,transferText.value.length);let copied=false;if(navigator.clipboard&&navigator.clipboard.writeText){try{await navigator.clipboard.writeText(transferText.value);copied=true}catch(e){}}if(!copied)copied=document.execCommand("copy");showToast(copied?"تم نسخ كود JSON بنجاح":"حدد النص وانسخه يدوياً");}catch(e){showToast("حدد النص وانسخه يدوياً");}});
document.getElementById("downloadBackup").addEventListener("click",()=>{try{const data=JSON.parse(transferText.value),scope=data.backupType||"all",name=scope==="single"?(data.project?.name||"project"):"all-projects",safe=String(name).replace(/[^\w\u0600-\u06FF-]+/g,"_").slice(0,40)||"backup",blob=new Blob([transferText.value],{type:"application/json;charset=utf-8"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=`AltraTech_${safe}_backup.json`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);showToast("تم تجهيز ملف JSON للتنزيل");}catch(e){showToast("تعذر تجهيز ملف النسخة");}});
document.getElementById("clearRestore").addEventListener("click",()=>{transferText.value="";document.getElementById("importOptions").hidden=true;transferText.focus()});
function validateBackup(raw){if(typeof raw!=="string"||raw.length>5*1024*1024)throw new Error("backup size");const data=JSON.parse(raw);if(!data||typeof data!=="object")throw new Error("invalid backup");let incoming,type;if(data.backupType==="single"||data.project){type="single";incoming=[data.project];}else{type="all";incoming=Array.isArray(data)?data:data.projects;}if(!Array.isArray(incoming)||(type==="single"&&!incoming.length)||incoming.some(p=>!p||typeof p.name!=="string"||!Array.isArray(p.widgets)))throw new Error("invalid backup");if(incoming.length>500||incoming.some(p=>p.widgets.length>5000))throw new Error("backup too large");return {data,type,incoming};}
function showImportPreview(){const raw=transferText.value.trim();if(!raw){document.getElementById("importOptions").hidden=true;return;}try{const {type,incoming}=validateBackup(raw);document.getElementById("importOptions").hidden=false;document.getElementById("importSummary").textContent=`تم التحقق من نسخة ${type==="single"?"مشروع واحد":"جميع المشاريع"}: ${incoming.length} مشروع، و${incoming.reduce((n,p)=>n+p.widgets.length,0)} مؤشر. اختر طريقة الدمج قبل الاستيراد.`;const strategy=document.getElementById("importStrategy");strategy.value=type==="single"?"replace-matching":"merge";strategy.querySelector('option[value="replace-all"]').disabled=false;document.getElementById("applyRestore").disabled=false;}catch(err){document.getElementById("importOptions").hidden=true;document.getElementById("applyRestore").disabled=true;}}
transferText.addEventListener("input",showImportPreview);
function normalizeImportedProjects(incoming){const stamp=Date.now();return incoming.map((p,pi)=>({...p,id:String(p.id||`import-p-${stamp}-${pi}`),name:p.name.trim().slice(0,55),layoutColumns:Math.max(1,Math.min(6,parseInt(p.layoutColumns,10)||3)),rowColumns:Array.isArray(p.rowColumns)?p.rowColumns.slice(0,9).map(v=>Math.max(1,Math.min(6,parseInt(v,10)||3))):[],rowHeights:Array.isArray(p.rowHeights)?p.rowHeights.slice(0,9).map(v=>v===null||v===undefined||v===""?null:Math.max(0,Math.min(400,parseInt(v,10)||0))):[],layoutScale:Math.max(.25,Math.min(1.4,Number(p.layoutScale)||1)),widgets:p.widgets.map((w,wi)=>({...w,id:String(w.id||`import-w-${stamp}-${pi}-${wi}`),slot:Number.isInteger(Number(w.slot))&&Number(w.slot)>=0?Math.min(9999,Number(w.slot)):wi,title:String(w.title||"مؤشر").slice(0,50),type:["button","numericInput","textInput","gauge","donutGauge","donutGaugeAlt","waterRing","temperatureDial","terminal"].includes(w.type)?w.type:"value",token:tokenFromWidget(w),virtualNumber:Math.max(0,Math.min(999,parseInt(w.virtualNumber??23,10)||0)),unit:String(w.unit||""),precision:Math.max(0,Math.min(10,Number(w.precision??1)||0)),valueFontSize:Math.max(12,Math.min(48,Number(w.valueFontSize)||24)),interval:Math.max(2,Math.min(86400,Number(w.interval)||5)),value:w.type==="numericInput"||["gauge","donutGauge","donutGaugeAlt","waterRing","temperatureDial"].includes(w.type)?(Number.isFinite(Number(w.value))?Number(w.value):(Number(w.initialValue)||0)):w.type==="textInput"?String(w.value??w.initialValue??""):"—",connected:null,buttonState:false,updated:w.type==="button"?"جاهز للتحكم":(w.type==="numericInput"||w.type==="textInput")?"جاهز للإدخال":"بانتظار القراءة"})),tabs:Array.isArray(p.tabs)&&p.tabs.length?p.tabs.map((t,ti)=>({...t,id:String(t.id||`import-tab-${stamp}-${pi}-${ti}`),name:String(t.name||`تبويب ${ti+1}`).slice(0,30),rowHeights:Array.isArray(t.rowHeights)?t.rowHeights.slice(0,9).map(v=>v===null||v===undefined||v===""?null:Math.max(0,Math.min(400,parseInt(v,10)||0))):[],widgets:(t.widgets||[]).map((w,wi)=>({...w,id:String(w.id||`import-tab-w-${stamp}-${pi}-${ti}-${wi}`),slot:Number.isInteger(Number(w.slot))&&Number(w.slot)>=0?Math.min(9999,Number(w.slot)):wi,token:tokenFromWidget(w),value:w.type==="numericInput"||["gauge","donutGauge","donutGaugeAlt","waterRing","temperatureDial"].includes(w.type)?(Number.isFinite(Number(w.value))?Number(w.value):(Number(w.initialValue)||0)):w.type==="textInput"?String(w.value??w.initialValue??""):"—",connected:null}))})): [{id:`import-home-${stamp}-${pi}`,name:"الرئيسية",widgets:p.widgets.map(w=>({...w})),layoutColumns:Math.max(1,Math.min(6,parseInt(p.layoutColumns,10)||3)),rowColumns:p.rowColumns||[],rowHeights:p.rowHeights||[],layoutScale:p.layoutScale||1}],activeTabId:p.activeTabId||null}));}
function restoreFromText(raw,options={}){const {incoming,type}=validateBackup(raw),clean=normalizeImportedProjects(incoming),strategy=options.confirmed?"replace-all":document.getElementById("importStrategy").value;let next=projects.map(p=>p);if(strategy==="replace-all"){if(!options.confirmed&&!confirm(`سيتم حذف ${projects.length} مشروعاً حالياً واستبدالها بـ ${clean.length} مشروع من النسخة. هل تريد المتابعة؟`))return false;next=clean;}else if(strategy==="replace-matching"){for(const item of clean){const idx=next.findIndex(p=>String(p.id)===String(item.id));if(idx>=0)next[idx]=item;else next.push(item);}}else{for(const item of clean){let id=item.id;if(next.some(p=>String(p.id)===String(id))){id=`${id}-import-${Date.now()}-${Math.random().toString(36).slice(2,7)}`;item.id=id;}next.push(item);}}
 if(!options.confirmed&&!confirm(`تأكيد استيراد ${clean.length} مشروع (${clean.reduce((n,p)=>n+p.widgets.length,0)} مؤشر) باستخدام خيار «${strategy==="merge"?"إضافة دون حذف":strategy==="replace-matching"?"استبدال المطابق":"استبدال الكل"}»؟`))return false;stopTimers();activeProjectId=null;projects=next;save();history.replaceState({view:"projects"},"",location.pathname+location.search);closeTransferPage();render();showToast(type==="single"?"تم استيراد المشروع بنجاح":"تم استيراد المشاريع بنجاح");return true;}
// استعادة مستقلة من بطاقة المشروع: لا تمس أي مشروع آخر، وتستهدف البطاقة التي ضغط المستخدم عليها.
const projectRestoreEditor=document.getElementById("projectRestoreEditor");
let projectRestoreTargetId=null;
window.openProjectRestore=function(projectId){
 const target=projects.find(p=>String(p.id)===String(projectId));if(!target){showToast("تعذر العثور على المشروع");return;}
 projectRestoreTargetId=String(projectId);
 document.getElementById("projectRestoreTitle").textContent="استعادة نسخة: "+target.name;
 document.getElementById("projectRestoreText").value="";
 document.getElementById("projectRestoreStatus").textContent="الصق نسخة JSON التي أنشأتها لهذا المشروع فقط.";
 document.getElementById("applyProjectRestore").disabled=true;
 projectRestoreEditor.showModal();
};
function validateProjectRestorePreview(){
 const raw=document.getElementById("projectRestoreText").value.trim(),btn=document.getElementById("applyProjectRestore"),status=document.getElementById("projectRestoreStatus");
 btn.disabled=true;if(!raw){status.textContent="الصق كود النسخة الاحتياطية JSON.";return;}
 try{const parsed=validateBackup(raw);if(parsed.type!=="single"||parsed.incoming.length!==1)throw new Error("single project required");
  const target=projects.find(p=>String(p.id)===String(projectRestoreTargetId));if(!target)throw new Error("target missing");
  status.textContent=`نسخة صالحة لمشروع «${parsed.incoming[0].name}» وتحتوي على ${parsed.incoming[0].widgets.length} مؤشر. سيتم استبدال مشروع «${target.name}» فقط.`;btn.disabled=false;
 }catch(e){status.textContent="الكود غير صالح أو أنه نسخة لجميع المشاريع. استخدم نسخة مشروع واحد تم إنشاؤها من خيار النسخ الاحتياطي.";}
}
document.getElementById("projectRestoreText").addEventListener("input",validateProjectRestorePreview);
document.getElementById("closeProjectRestore").onclick=()=>projectRestoreEditor.close();
document.getElementById("cancelProjectRestore").onclick=()=>projectRestoreEditor.close();
document.getElementById("projectRestoreForm").addEventListener("submit",e=>{
 e.preventDefault();const raw=document.getElementById("projectRestoreText").value.trim();
 try{
  const parsed=validateBackup(raw);if(parsed.type!=="single"||parsed.incoming.length!==1)throw new Error("single project required");
  const index=projects.findIndex(p=>String(p.id)===String(projectRestoreTargetId));if(index<0)throw new Error("target missing");
  const target=projects[index],restored=normalizeImportedProjects(parsed.incoming)[0];
  if(!confirm(`سيتم استبدال بيانات مشروع «${target.name}» بالنسخة «${restored.name}»، مع بقاء جميع المشاريع الأخرى دون تغيير. هل تريد المتابعة؟`))return;
  restored.id=target.id;projects[index]=restored;stopTimers();save();projectRestoreEditor.close();projectRestoreTargetId=null;render();showToast("تمت استعادة نسخة المشروع بنجاح");
 }catch(err){showToast("تعذرت الاستعادة: تأكد من صحة كود نسخة المشروع");}
});

document.getElementById("applyRestore").addEventListener("click",()=>{const raw=transferText.value.trim();if(!raw){showToast("الصق كود JSON أولاً");return;}try{restoreFromText(raw)}catch(err){showToast("تعذر الاستيراد: النسخة غير صالحة أو تالفة");}});
// فحص ملف النسخة الاحتياطية المستضاف على الإنترنت عند كل تشغيل للتطبيق.
function backupFingerprint(raw){let hash=2166136261;for(let i=0;i<raw.length;i++){hash^=raw.charCodeAt(i);hash=Math.imul(hash,16777619)}return (hash>>>0).toString(16)}
// Decode remote JSON by its actual byte encoding. JSON exchanged over the web
// should be UTF-8; some hosts incorrectly label UTF-8 files as Latin-1/ASCII.
async function decodeRemoteJsonResponse(response){
 const buffer=await response.arrayBuffer();
 const bytes=new Uint8Array(buffer);
 if(bytes.length>=3&&bytes[0]===0xEF&&bytes[1]===0xBB&&bytes[2]===0xBF){
  return new TextDecoder("utf-8").decode(bytes.subarray(3)).replace(/^\uFEFF/,"");
 }
 if(bytes.length>=2&&bytes[0]===0xFF&&bytes[1]===0xFE)return new TextDecoder("utf-16le").decode(bytes.subarray(2)).replace(/^\uFEFF/,"");
 if(bytes.length>=2&&bytes[0]===0xFE&&bytes[1]===0xFF)return new TextDecoder("utf-16be").decode(bytes.subarray(2)).replace(/^\uFEFF/,"");
 // Prefer strict UTF-8 regardless of a possibly incorrect server charset header.
 try{return new TextDecoder("utf-8",{fatal:true}).decode(bytes).replace(/^\uFEFF/,"");}catch(e){}
 const contentType=response.headers.get("content-type")||"";
 const match=contentType.match(/charset\s*=\s*["']?([^;\s"']+)/i);
 const declared=(match?.[1]||"").toLowerCase();
 const candidates=[];
 if(declared&&declared!=="utf-8"&&declared!=="utf8")candidates.push(declared);
 // Common legacy encodings used by older Arabic-hosted JSON files.
 candidates.push("windows-1256","windows-1252");
 for(const encoding of candidates){try{return new TextDecoder(encoding).decode(bytes).replace(/^\uFEFF/,"");}catch(e){}}
 throw new Error("unsupported JSON encoding");
}
async function checkRemoteBackup(manual=false){
 const url=localStorage.getItem("altra_remote_backup_url");if(!url){if(manual)updateRemoteStatus("لم يتم حفظ رابط للاستعادة بعد.");return;}
 if(manual)updateRemoteStatus("جارٍ الاتصال بالرابط وفحص محتواه...");
 try{
  const response=await fetch(url,{cache:"no-store",headers:{"Accept":"application/json,text/plain,*/*"}});
  if(!response.ok)throw new Error("HTTP "+response.status);
  const raw=await decodeRemoteJsonResponse(response);if(!raw||raw.length>5*1024*1024)throw new Error("invalid size");
  const parsed=JSON.parse(raw),incoming=Array.isArray(parsed)?parsed:parsed?.projects;
  if(!Array.isArray(incoming)||incoming.some(p=>!p||typeof p.name!=="string"||!Array.isArray(p.widgets)))throw new Error("invalid backup");
  const fingerprint=backupFingerprint(raw),last=localStorage.getItem("altra_remote_backup_hash");
  if(fingerprint===last){if(manual)updateRemoteStatus("الرابط يعمل، ولا توجد نسخة جديدة. آخر نسخة مفحوصة مطابقة.");return;}
  const approved=confirm("تم العثور على نسخة احتياطية جديدة عبر الإنترنت تحتوي على "+incoming.length+" مشروع. هل تريد استعادتها واستبدال المشاريع الحالية؟");
  if(approved){const done=restoreFromText(raw,{confirmed:true});if(done){localStorage.setItem("altra_remote_backup_hash",fingerprint);if(manual)updateRemoteStatus("تمت استعادة النسخة الجديدة بنجاح.");}}
  else{localStorage.setItem("altra_remote_backup_hash",fingerprint);if(manual)updateRemoteStatus("تم تجاهل النسخة الحالية. سيُعاد الفحص عند التشغيل، ولن يظهر التنبيه مجدداً إلا إذا تغير محتوى الملف.");}
 }catch(err){if(manual)updateRemoteStatus("تعذر فحص الرابط. تأكد من صحته ومن أن الخادم يسمح بالوصول من التطبيق (CORS) وأن الملف JSON صالح.");else console.warn("Remote backup check failed:",err);}
}

// الاستيراد اليدوي متاح عبر لصق كود JSON فقط.

function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function showToast(msg){const t=document.getElementById("toast");t.textContent=msg;t.style.display="block";setTimeout(()=>t.style.display="none",3000)}
function stopTimers(){Object.values(refreshTimers).forEach(clearTimeout);refreshTimers={}}
function widgetStatusColor(w){return w.connected===true?"#22c55e":"#ef4444";}
function terminalPayloadText(data){
 if(data===null||data===undefined)return null;
 const itemText=item=>{
  if(item===null||item===undefined)return "";
  if(typeof item==="string")return item;
  if(typeof item==="number"||typeof item==="boolean")return String(item);
  if(typeof item==="object"){
   for(const key of ["text","message","value","data","content","line"])if(key in item&&item[key]!==null&&item[key]!==undefined)return itemText(item[key]);
   return JSON.stringify(item);
  }
  return String(item);
 };
 // Terminal endpoints may return an array of fragments, not a single value.
 // Join without adding separators because the server already supplies CR/LF fragments.
 if(Array.isArray(data))return data.map(itemText).join("");
 if(typeof data==="object"){
  for(const key of ["messages","logs","lines","history","data","result","value"])if(key in data){const value=data[key];if(Array.isArray(value))return value.map(itemText).join("");if(typeof value==="string")return value;}
  return itemText(data);
 }
 return String(data);
}
function terminalLinesHtml(w){
 const remote=String(w.terminalText??"");
 const sent=(Array.isArray(w.terminalLines)?w.terminalLines:[]).filter(line=>line&&line.kind==="sent").slice(-100);
 if(!remote&&!sent.length)return '<div class="terminal-empty">Terminal ready</div>';
 return `<div class="terminal-output">${esc(remote)}</div>`+sent.map(line=>`<div class="terminal-line sent">${esc(line.text??"")}</div>`).join("");
}
function refreshTerminalScreen(w){const screen=document.querySelector(`[data-terminal-screen="${CSS.escape(w.id)}"]`);if(!screen)return;const nextHtml=terminalLinesHtml(w);if(screen.innerHTML!==nextHtml){const wasAtBottom=screen.scrollHeight-screen.scrollTop-screen.clientHeight<24;screen.innerHTML=nextHtml;if(wasAtBottom)screen.scrollTop=screen.scrollHeight;}}
function appendTerminalLine(w,text,kind="received"){w.terminalLines=Array.isArray(w.terminalLines)?w.terminalLines:[];w.terminalLines.push({text:String(text),kind,at:Date.now()});if(w.terminalLines.length>100)w.terminalLines=w.terminalLines.slice(-100);refreshTerminalScreen(w);save();}

function gridGeometryForLegacySlot(p,slot){
 let row=0,start=0,capacity=3;
 for(;row<1000;row++){capacity=Math.max(1,Math.min(6,parseInt(p.rowColumns?.[row],10)||Math.max(1,Math.min(6,parseInt(p.layoutColumns,10)||3))));if(slot<start+capacity)break;start+=capacity;}
 const col=Math.max(0,slot-start),x=Math.floor(col*12/capacity),next=Math.floor((col+1)*12/capacity);
 return {x,y:row*4,w:Math.max(1,next-x),h:4};
}
function gridRectOverlaps(a,b){return a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;}
function gridPlacementFree(widgets,id,x,y,w,h){const candidate={x,y,w,h};return !(widgets||[]).some(item=>item.id!==id&&Number.isFinite(Number(item.gridX))&&gridRectOverlaps(candidate,{x:Number(item.gridX)||0,y:Number(item.gridY)||0,w:Math.max(1,Number(item.gridW)||4),h:Math.max(1,Number(item.gridH)||4)}));}
function findNearestGridPlacement(widgets,id,x,y,w,h){
 // Search outward from the requested cell. Work is bounded by occupied area,
 // and the first ring containing a free cell is always the nearest candidate.
 const items=(widgets||[]).filter(item=>item.id!==id&&Number.isFinite(Number(item.gridX))&&Number.isFinite(Number(item.gridY)));
 const maxY=Math.min(4000,Math.max(y+160,...items.map(item=>(Number(item.gridY)||0)+Math.max(1,Number(item.gridH)||4)+h+8)));
 const maxRadius=Math.max(12,Math.min(500,Math.max(maxY-y,12)+12));
 for(let radius=0;radius<=maxRadius;radius++){
  let best=null,bestScore=Infinity;
  const y0=Math.max(0,y-radius),y1=Math.min(maxY,y+radius);
  for(let yy=y0;yy<=y1;yy++){
   const dy=Math.abs(yy-y);if(dy>radius)continue;
   const rem=radius-dy;
   const candidates=rem===0?[x]:[x-rem,x+rem];
   for(const rawX of candidates){const xx=Math.max(0,Math.min(12-w,rawX));
    if(!gridPlacementFree(widgets,id,xx,yy,w,h))continue;
    const score=Math.abs(xx-x)+Math.abs(yy-y)*1.15;
    if(score<bestScore){best={x:xx,y:yy,width:w,height:h};bestScore=score;}
   }
  }
  if(best)return best;
 }
 return null;
}
function ensureGridGeometry(p,widgets){
 const resolution=Math.max(1,Number(p.gridResolution)||6);
 (widgets||[]).forEach((w,i)=>{if(Number.isFinite(Number(w.gridX))&&Number.isFinite(Number(w.gridY))&&Number(w.gridW)>0&&Number(w.gridH)>0){if(resolution!==12){w.gridX=Math.round(Number(w.gridX)*2);w.gridY=Math.round(Number(w.gridY)*2);w.gridW=Math.max(1,Math.round(Number(w.gridW)*2));w.gridH=Math.max(1,Math.round(Number(w.gridH)*2));}}else{const slot=Number.isInteger(Number(w.slot))&&Number(w.slot)>=0?Number(w.slot):i;const g=gridGeometryForLegacySlot(p,slot);w.gridX=g.x;w.gridY=g.y;w.gridW=g.w;w.gridH=g.h;}
  // Keep stored geometry within the actual 12-column canvas and supported row range.
  w.gridW=Math.max(1,Math.min(12,Math.round(Number(w.gridW)||4)));
  w.gridH=Math.max(1,Math.min(40,Math.round(Number(w.gridH)||4)));
  w.gridX=Math.max(0,Math.min(12-w.gridW,Math.round(Number(w.gridX)||0)));
  w.gridY=Math.max(0,Math.round(Number(w.gridY)||0));
  // Terminal width is user-controlled and may span all 12 grid columns.
 });
 p.gridResolution=12;
}
function assignGridGeometry(item,widgets){
 const width=item.type==="terminal"?6:4,height=item.type==="terminal"?6:4;
 for(let y=0;y<4000;y++)for(let x=0;x<=12-width;x++)if(gridPlacementFree(widgets,item.id,x,y,width,height)){item.gridX=x;item.gridY=y;item.gridW=width;item.gridH=height;return;}
 item.gridX=0;item.gridY=4000;item.gridW=width;item.gridH=height;
}
function preserveGridGeometry(item,old,p){
 if(old&&Number.isFinite(Number(old.gridX))){item.gridX=old.gridX;item.gridY=old.gridY;item.gridW=old.gridW;item.gridH=old.gridH;}
 else if(p.gridLayoutEnabled)assignGridGeometry(item,p.widgets.filter(w=>!old||w.id!==old.id));
}
function gaugeColorFor(w,pct){if(w.gaugeColorMode!=="multi")return /^#[0-9a-f]{6}$/i.test(w.gaugeColor||"")?w.gaugeColor:"#35d0ba";const low=w.gaugeLowColor||"#22c55e",mid=w.gaugeMidColor||"#f59e0b",high=w.gaugeHighColor||"#ef4444";const hex=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16));const a=pct<.5?hex(low):hex(mid),b=pct<.5?hex(mid):hex(high),t=pct<.5?pct*2:(pct-.5)*2;return "#"+a.map((v,i)=>Math.round(v+(b[i]-v)*t).toString(16).padStart(2,"0")).join("");}
function gridWidgetMarkup(w){
 const id=esc(w.id),title=esc(w.title),slot=Number(w.slot)||0,x=Math.max(0,Math.min(11,Number(w.gridX)||0)),y=Math.max(0,Number(w.gridY)||0),gw=Math.max(1,Math.min(12-x,Number(w.gridW)||4)),gh=Math.max(1,Math.min(40,Number(w.gridH)||4)),position=`grid-column:${x+1}/span ${gw};grid-row:${y+1}/span ${gh};`,size=`${gw}×${gh}`;
 const common=`data-widget-id="${id}" data-slot="${slot}" data-grid-size="${size}" style="${position}"`;
 const handles=`<button class="drag-handle" type="button" aria-label="اسحب لتحريك ${title}" title="اسحب لتحريك المؤشر">✥</button><button class="grid-resize-left" type="button" aria-label="تغيير الحافة اليسرى" title="اسحب الحافة اليسرى"></button><button class="grid-resize-right" type="button" aria-label="تغيير الحافة اليمنى" title="اسحب الحافة اليمنى"></button><button class="grid-resize-top" type="button" aria-label="تغيير الحافة العلوية" title="اسحب الحافة العلوية"></button><button class="grid-resize-bottom" type="button" aria-label="تغيير الحافة السفلية" title="اسحب الحافة السفلية"></button><button class="grid-resize-handle" type="button" aria-label="تغيير العرض والارتفاع" title="اسحب لتغيير العرض والارتفاع">⤡</button>`;
 const actions=`<div class="actions"><button class="iconbtn edit-widget-btn" type="button" title="تعديل" data-edit-widget="${id}">✎</button><button class="iconbtn delete-widget-btn" type="button" title="حذف" onclick="deleteWidget('${id}')">×</button></div>`;
 if(w.type==="button"){
  const on=!!w.buttonState;return `<article class="card widget-card control-widget" ${common}><div class="card-top"><div class="card-title">${title}</div>${handles}</div><button type="button" class="control-toggle" data-control-id="${id}" style="background:${esc(on?w.onColor||"#25c28a":w.offColor||"#596579")};font-size:${Math.max(10,Math.min(48,Number(on?w.onFontSize:w.offFontSize)||35))}px">${esc(on?w.onLabel||"ON":w.offLabel||"OFF")}</button><div class="card-foot"><span class="updated">${esc(w.updated||"جاهز للتحكم")}</span>${actions}</div></article>`;
 }
 if(w.type==="numericInput"){
  const min=Number.isFinite(Number(w.minValue))?Number(w.minValue):0,max=Number.isFinite(Number(w.maxValue))?Number(w.maxValue):100,precision=Math.max(0,Math.min(6,Number(w.precision)||0)),value=Number.isFinite(Number(w.value))?Number(w.value):(Number(w.initialValue)||0);
  return `<article class="card widget-card numeric-input-widget" ${common}><div class="card-top"><div class="card-title">${title}</div>${handles}${actions}</div><div class="numeric-input-controls"><button type="button" class="numeric-step-btn" data-numeric-step="-1" data-numeric-id="${id}" aria-label="إنقاص القيمة">−</button><input class="numeric-current" type="text" lang="en" inputmode="decimal" autocomplete="off" spellcheck="false" value="${Number(value).toFixed(precision)}" data-numeric-value="${id}" aria-label="القيمة الرقمية"><button type="button" class="numeric-step-btn" data-numeric-step="1" data-numeric-id="${id}" aria-label="زيادة القيمة">+</button></div><div class="grid-card-spacer"></div></article>`;
 }
 if(w.type==="textInput"){
  const maxLength=Math.max(1,Math.min(512,Number(w.maxLength)||120)),textValue=String(w.value??w.initialValue??"");return `<article class="card widget-card text-input-widget" ${common}><div class="card-top"><div class="card-title">${title}</div>${handles}${actions}</div><input class="text-input-field" type="text" maxlength="${maxLength}" value="${esc(textValue)}" placeholder="${esc(w.placeholder||"")}" data-text-input="${id}" aria-label="${title}" autocomplete="off" autocapitalize="sentences" spellcheck="false"><div class="grid-card-spacer"></div></article>`;
 }
 if(["gauge","donutGauge","donutGaugeAlt","waterRing","temperatureDial"].includes(w.type)){
  const min=Number.isFinite(Number(w.minValue))?Number(w.minValue):0,max=Number.isFinite(Number(w.maxValue))&&Number(w.maxValue)>min?Number(w.maxValue):100,value=Number.isFinite(Number(w.value))?Number(w.value):min,pct=Math.max(0,Math.min(1,(value-min)/(max-min))),circ=2*Math.PI*43,dash=(circ*.75),offset=dash*(1-pct),precision=Math.max(0,Math.min(3,Number(w.precision)||0)),color=gaugeColorFor(w,pct);
  if(w.type==="waterRing"){
   const liquidY=(100-pct*100).toFixed(2),percent=Math.round(pct*100);
   return `<article class="card widget-card gauge-widget water-ring-widget" ${common} style="--gauge-color:#35cfff;--water-font:${Math.max(16,Math.min(38,Number(w.gaugeFontSize)||24))}px;--grid-scale:${Math.max(.35,Math.min(2.5,Math.min(gw/4,gh/4))).toFixed(2)}"><div class="gauge-tools">${actions}</div>${handles}<div class="gauge-face"><svg class="water-ring-svg" viewBox="0 0 100 100" role="img" aria-label="Water level ${percent}%"><defs><clipPath id="waterClip-${id}"><circle cx="50" cy="50" r="42"/></clipPath><linearGradient id="waterLiquidGradient-${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#70edff"/><stop offset=".42" stop-color="#18b9f2"/><stop offset="1" stop-color="#0755b8"/></linearGradient><linearGradient id="waterDropGradient-${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset=".45" stop-color="#7ceaff"/><stop offset="1" stop-color="#1596e8"/></linearGradient></defs><circle class="water-ring-outer-glow" cx="50" cy="50" r="46"/><circle class="water-ring-glass" cx="50" cy="50" r="43"/><g clip-path="url(#waterClip-${id})"><circle class="water-ring-inner" cx="50" cy="50" r="42"/><rect class="water-ring-liquid" id="water-fill-${id}" x="8" y="${liquidY}" width="84" height="84" fill="url(#waterLiquidGradient-${id})"/><path class="water-ring-wave-back" id="water-wave-back-${id}" d="M5 ${liquidY} Q25 ${Number(liquidY)-3} 45 ${liquidY} T85 ${liquidY} T125 ${liquidY} V100 H5Z"/><path class="water-ring-wave" id="water-wave-${id}" d="M5 ${liquidY} Q25 ${Number(liquidY)-4} 45 ${liquidY} T85 ${liquidY} T125 ${liquidY} V100 H5Z"/><circle class="water-ring-bubble" cx="35" cy="76" r="1.3"/><circle class="water-ring-bubble" cx="68" cy="83" r="1" style="animation-delay:1.1s"/><circle class="water-ring-bubble" cx="56" cy="69" r=".8" style="animation-delay:2s"/></g><path class="water-ring-droplet" d="M50 27 C45 34 39 40 39 47 A11 11 0 0 0 61 47 C61 40 55 34 50 27Z"/><path d="M45 46 Q46 40 50 36" fill="none" stroke="#fff" stroke-width="1.5" stroke-linecap="round" opacity=".8"/></svg><div class="water-ring-percent" id="water-percent-${id}">${percent}%</div></div></article>`;
  }
  if(w.type==="temperatureDial"){
   const tempState=pct<.28?"باردة":pct<.68?"معتدلة":"مرتفعة";
   return `<article class="card widget-card gauge-widget temperature-dial-widget" ${common} style="--grid-scale:${Math.max(.35,Math.min(2.5,Math.min(gw/4,gh/4))).toFixed(2)};--gauge-size:${Math.max(12,Math.min(46,Number(w.gaugeFontSize)||24))}px;--thermal-pct:${(pct*100).toFixed(2)}%;--thermal-value-scale:${Math.min(1,6.4/Math.max(1,value.toFixed(precision).length)).toFixed(2)}"><div class="gauge-tools">${actions}</div>${handles}<div class="gauge-face thermal-prism-face"><div class="thermal-main"><div class="thermal-reading-panel"><div class="thermal-reading-line"><span class="gauge-reading" id="gauge-val-${id}">${esc(value.toFixed(precision))}</span><span class="gauge-unit">${esc(w.unit||"°C")}</span></div><div class="thermal-state" id="thermal-state-${id}">${tempState}</div></div><div class="thermal-scale"><div class="thermal-spectrum-bar"><span class="thermal-spectrum-marker" id="thermal-marker-${id}"></span></div><div class="thermal-footer"><span>${esc(String(max))}</span><span><b>${esc(String(min))}</b></span></div></div></div></div></article>`;
  }
  const donut=w.type==="donutGauge"||w.type==="donutGaugeAlt",variantClass=w.type==="donutGauge"?" donut-gauge-widget":w.type==="donutGaugeAlt"?" donut-gauge-widget donut-gauge-glow-widget":"";const arcPct=donut?pct*100:pct*75;return `<article class="card widget-card gauge-widget${variantClass}" ${common} style="--donut-progress:${arcPct.toFixed(2)};--gauge-color:${color};--gauge-size:${Math.max(12,Math.min(46,Number(w.gaugeFontSize)||24))}px;--grid-scale:${Math.max(.35,Math.min(2.5,Math.min(gw/4,gh/4))).toFixed(2)};--gauge-title-size:${Math.max(7,Math.min(13,(Math.max(40,gw-16)/(Math.max(1,title.length)*.62))))}px"><div class="gauge-tools">${actions}</div>${handles}<div class="gauge-face"><svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Gauge ${title}"><circle class="gauge-track" cx="50" cy="50" r="45" pathLength="100" stroke-dasharray="${donut?"100 0":"75 25"}" transform="rotate(${donut?"-90":"135"} 50 50)"/><circle class="gauge-progress" cx="50" cy="50" r="45" pathLength="100" stroke-dasharray="${arcPct.toFixed(2)} 100" transform="rotate(${donut?"-90":"135"} 50 50)"/></svg><div class="gauge-value-wrap"><div class="gauge-title">${title}</div><div class="gauge-reading-row"><div class="gauge-reading" id="gauge-val-${id}">${esc(value.toFixed(precision))}</div><div class="gauge-unit" style="--gauge-size:${Math.max(12,Math.min(46,Number(w.gaugeFontSize)||24))}px">${esc(w.unit||"")}</div></div></div></div></article>`;
 }
 if(w.type==="terminal"){
  const lines=Array.isArray(w.terminalLines)?w.terminalLines:[];return `<article class="card widget-card terminal-widget" ${common}><div class="card-top"><div class="card-title">${title}</div>${handles}${actions}</div><div class="terminal-screen" data-terminal-screen="${id}" role="log" aria-live="polite">${terminalLinesHtml(lines)}</div><div class="terminal-compose"><input class="terminal-command" type="text" data-terminal-input="${id}" placeholder="اكتب أمراً..." autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="أمر Terminal"><button class="terminal-send" type="button" data-terminal-send="${id}" aria-label="إرسال">➤</button></div></article>`;
 }
 return `<article class="card widget-card value-widget-card" data-widget-id="${id}" data-slot="${slot}" data-grid-size="${size}" style="--c:${widgetStatusColor(w)};--value-size:${Math.max(12,Math.min(48,Number(w.valueFontSize)||24))}px;--grid-scale:${Math.max(.35,Math.min(2.5,Math.min(gw/4,gh/4))).toFixed(2)};${position}"><div class="card-top"><div class="card-title">${title}</div>${handles}${w.ledIndicatorEnabled?`<span class="dot value-led-dot" id="led-${id}" style="--led-c:${w.ledState===true?"#22c55e":w.ledState===false?"#ef4444":"#64748b"}"></span>`:""}${actions}</div><div class="value-line"><div class="value" id="val-${id}">${esc(w.value??"—")}</div><div class="unit">${esc(w.unit||"آخر قراءة")}</div></div><div class="grid-card-spacer"></div></article>`;
}
function renderGridLayout(p,ws){
 ensureGridGeometry(p,ws);save();const ordered=[...ws].sort((a,b)=>(Number(a.gridY)||0)-(Number(b.gridY)||0)||(Number(a.gridX)||0)-(Number(b.gridX)||0));widgetGrid.innerHTML=ordered.map(gridWidgetMarkup).join("");
 widgetGrid.querySelectorAll(".widget-card").forEach(card=>{
  const base=Number.parseFloat(card.style.getPropertyValue("--grid-scale"))||1;
  card.dataset.baseGridScale=String(base);
  card.style.setProperty("--grid-scale",String(base*(Number(p.layoutScale)||1)));
 });
}

function render(){
 stopTimers();
 const back=document.getElementById("backBtn"),add=document.getElementById("addBtn"),title=document.getElementById("sectionTitle"),sectionHead=document.getElementById("sectionHead"),sortBtn=document.getElementById("sortModeBtn"),layoutControls=document.getElementById("layoutControls");
 if(!activeProjectId){
  projectGrid.hidden=false;widgetGrid.hidden=true;document.getElementById("projectTabs").hidden=true;back.hidden=true;sortBtn.hidden=true;document.getElementById("projectLayoutBtn").hidden=false;toolsMenuBtn.hidden=false;add.hidden=false;sortMode=false;projectLayoutMode=false;document.getElementById("projectLayoutBtn").textContent="▦";document.getElementById("projectLayoutBtn").title="تنسيق المشاريع";document.getElementById("projectLayoutBtn").setAttribute("aria-label","تنسيق المشاريع");projectGrid.classList.remove("project-actions-visible");widgetGrid.classList.remove("sort-mode");layoutControls.classList.remove("visible");document.getElementById("projectLayoutControls").classList.remove("visible");sectionHead.hidden=false;title.textContent="المشاريع";add.setAttribute("aria-label","إضافة مشروع");add.title="إضافة مشروع";renderProjectLayoutControls();
  if(!projects.length){projectGrid.innerHTML='<div class="empty">لا توجد مشاريع حتى الآن.<br>اضغط زر + لإنشاء مشروعك الأول.</div>';}else{let rows=[],offset=0,row=0;while(offset<projects.length){const capacity=projectRowCapacity(row);const cards=projects.slice(offset,offset+capacity).map(p=>`<article class="card project-card" data-project-id="${esc(p.id)}" style="--c:#35d0ba" onclick="openProject('${esc(p.id)}')"><div><div class="card-top"><div class="card-title">${esc(p.name)}</div><button class="project-drag-handle" type="button" aria-label="اسحب لترتيب المشروع" title="اسحب لإعادة ترتيب المشروع">⠿</button><span class="dot"></span></div><div class="project-icon">▦</div></div><div class="project-meta"><div class="actions"><button class="iconbtn project-backup-btn" title="إنشاء نسخة احتياطية لهذا المشروع" aria-label="إنشاء نسخة احتياطية لهذا المشروع" onclick="event.stopPropagation();backupProject('${esc(p.id)}')">⇩</button><button class="iconbtn project-restore-btn" title="استعادة نسخة هذا المشروع" aria-label="استعادة نسخة هذا المشروع" onclick="event.stopPropagation();openProjectRestore('${esc(p.id)}')">↻</button><button class="iconbtn" title="تعديل الاسم" aria-label="تعديل اسم المشروع" onclick="event.stopPropagation();editProject('${esc(p.id)}')">✎</button><button class="iconbtn" title="حذف المشروع" aria-label="حذف المشروع" onclick="event.stopPropagation();deleteProject('${esc(p.id)}')">×</button></div></div></article>`);rows.push(`<div class="project-row" style="--project-columns:${capacity}">${cards.join("")}</div>`);offset+=capacity;row++;}projectGrid.innerHTML=rows.join("");}
 }else{
  const p=projects.find(x=>x.id===activeProjectId);if(!p){activeProjectId=null;render();return}
  projectGrid.hidden=true;widgetGrid.hidden=false;renderProjectTabs(p,sortMode);document.getElementById("projectLayoutBtn").hidden=true;back.hidden=false;sortBtn.hidden=false;toolsMenuBtn.hidden=true;closeToolsMenu();add.hidden=!sortMode;sortBtn.innerHTML=sortMode?'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20Z"/><path d="m7.5 12.5 3 3 6-7"/></svg>':'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 4v16m0 0-4-4m4 4 4-4M16 20V4m0 0-4 4m4-4 4 4"/></svg>';sortBtn.setAttribute("aria-label",sortMode?"إنهاء الترتيب":"ترتيب المؤشرات");sortBtn.title=sortMode?"إنهاء الترتيب":"ترتيب المؤشرات";widgetGrid.classList.toggle("sort-mode",sortMode);layoutControls.classList.toggle("visible",sortMode);const layoutScale=Math.max(.25,Math.min(1.4,Number(p.layoutScale)||1));widgetGrid.style.setProperty("--layout-scale",layoutScale);document.getElementById("layoutScale").value=String(Math.round(layoutScale*100));document.getElementById("layoutScaleValue").textContent=Math.round(layoutScale*100)+"%";sectionHead.hidden=false;title.textContent=p.name;add.setAttribute("aria-label","إضافة مؤشر");add.title="إضافة مؤشر";
  const ws=p.widgets||[];
  p.gridLayoutEnabled=true;widgetGrid.classList.add("grid-layout");layoutControls.classList.toggle("visible",sortMode);
  if(!ws.length){widgetGrid.innerHTML='<div class="empty">لا توجد مؤشرات في هذا المشروع بعد.<br>فعّل وضع ترتيب المؤشرات ثم اضغط زر + لإضافة أول مؤشر.</div>';}else{renderGridLayout(p,ws);}
  // لا يتم إرسال أي طلبات للشبكة إلا بعد فتح المشروع؛ نوزّع البداية قليلاً لتجنب دفعة طلبات متزامنة.
  // تتم مزامنة الأزرار وحقول الإدخال مع الخادم كل 5 ثوانٍ.
  ws.forEach((w,index)=>scheduleWidget(w,index*150,activeProjectId));
 }
}
// إعدادات تخطيط مستقلة لكل مشروع: عدد المؤشرات في كل صف وحجم البطاقات.
const layoutScaleInput=document.getElementById("layoutScale");
function activeLayoutProject(){return projects.find(x=>x.id===activeProjectId)}
function applyLayoutScalePreview(scale){
 scale=Math.max(.25,Math.min(1.4,Number(scale)||1));
 widgetGrid.style.setProperty("--layout-scale",String(scale));
 widgetGrid.querySelectorAll(".widget-card").forEach(card=>{
  const base=Number(card.dataset.baseGridScale)||1;
  card.style.setProperty("--grid-scale",String(Math.max(.2,Math.min(3,base*scale))));
 });
 document.getElementById("layoutScaleValue").textContent=Math.round(scale*100)+"%";
}
layoutScaleInput.addEventListener("input",()=>{const p=activeLayoutProject();if(!sortMode||!p)return;const scale=Math.max(.25,Math.min(1.4,Number(layoutScaleInput.value)/100));p.layoutScale=scale;applyLayoutScalePreview(scale)});
layoutScaleInput.addEventListener("change",()=>{const p=activeLayoutProject();if(!sortMode||!p)return;p.layoutScale=Math.max(.25,Math.min(1.4,Number(layoutScaleInput.value)/100));applyLayoutScalePreview(p.layoutScale);save()});
// فتح إعدادات المؤشرات عبر تفويض أحداث اللمس؛ pointerup أكثر ثباتاً في Android WebView.
function openWidgetEditorFromButton(e){
 const edit=e.target?.closest?.("[data-edit-widget]");
 if(!edit||!widgetGrid.contains(edit))return false;
 e.preventDefault();e.stopPropagation();e.stopImmediatePropagation?.();
 const id=edit.dataset.editWidget;
 if(id&&typeof window.editWidget==="function"){window.editWidget(id);return true;}
 return false;
}
widgetGrid.addEventListener("pointerup",e=>{if(e.pointerType==="mouse"&&e.button!==0)return;openWidgetEditorFromButton(e);},true);
// دعم لوحة المفاتيح/قارئات الشاشة دون فتح النافذة مرتين بعد اللمس.
widgetGrid.addEventListener("click",e=>{if(e.detail===0)openWidgetEditorFromButton(e);},true);

// وضع ترتيب المؤشرات: السحب من مقبض ⠿، مع أزرار بديلة لتحريك المؤشر.
document.getElementById("sortModeBtn").addEventListener("click",()=>{sortMode=!sortMode;render();showToast(sortMode?"اسحب المؤشرات من مقبض ⠿ لتغيير ترتيبها":"تم حفظ ترتيب المؤشرات")});

let gridPointerState=null,gridPreviewFrame=0;
function gridMetrics(){
 const rect=widgetGrid.getBoundingClientRect(),style=getComputedStyle(widgetGrid);
 const tracks=style.gridTemplateColumns.match(/(?:\d+(?:\.\d+)?px)/g)||[];
 const gapX=parseFloat(style.columnGap)||4,gapY=parseFloat(style.rowGap)||4;
 const cellW=tracks.length?parseFloat(tracks[0]):(rect.width-gapX*11)/12;
 const raw=style.gridAutoRows||"32px",matches=[...raw.matchAll(/([\d.]+)px/g)];
 const cellH=matches.length?parseFloat(matches[matches.length-1][1]):(innerWidth<=430?30:32);
 return {rect,stepX:cellW+gapX,stepY:cellH+gapY};
}
function clearGridPreview(state){
 if(!state)return;
 state.card.classList.remove("grid-dragging","grid-resizing","grid-drop-invalid");
 state.card.style.transform="";state.card.style.gridColumn=state.originalColumn;state.card.style.gridRow=state.originalRow;
 delete state.card.dataset.gridPreview;
}
function applyGridPreview(state,x,y,width,height){
 state.current={x,y,width,height};
 state.card.style.gridColumn=`${x+1}/span ${width}`;
 state.card.style.gridRow=`${y+1}/span ${height}`;
 state.card.dataset.gridSize=`${width}×${height}`;
}
function updateGridPointer(e){
 const state=gridPointerState;if(!state||state.pointerId!==e.pointerId)return;
 const metrics=gridMetrics(),dx=e.clientX-state.startX,dy=e.clientY-state.startY;
 let x=state.baseX,y=state.baseY,width=state.baseW,height=state.baseH;
 if(state.mode==="drag"){
  x=Math.max(0,Math.min(12-width,Math.round((e.clientX-metrics.rect.left-state.grabX)/metrics.stepX)));
  y=Math.max(0,Math.round((e.clientY-metrics.rect.top-state.grabY)/metrics.stepY));
 }else{
  const minH=2,ddx=Math.round(dx/metrics.stepX),ddy=Math.round(dy/metrics.stepY);
  if(state.mode==="resize-left"){const delta=Math.max(-state.baseX,Math.min(state.baseW-1,ddx));x=state.baseX+delta;width=state.baseW-delta;}
  else if(state.mode==="resize-right")width=Math.max(1,Math.min(12-state.baseX,state.baseW+ddx));
  else if(state.mode==="resize-top"){const delta=Math.max(-state.baseY,Math.min(state.baseH-minH,ddy));y=state.baseY+delta;height=state.baseH-delta;}
  else if(state.mode==="resize-bottom")height=Math.max(minH,Math.min(40,state.baseH+ddy));
  else {if(state.mode!=="resize-y")width=Math.max(1,Math.min(12-state.baseX,state.baseW+ddx));if(state.mode!=="resize-x")height=Math.max(minH,Math.min(40,state.baseH+ddy));}
 }
 const project=projects.find(item=>item.id===activeProjectId);if(!project)return;
 const free=gridPlacementFree(project.widgets,state.id,x,y,width,height);
 state.card.classList.toggle("grid-drop-invalid",!free);
 if(state.mode==="drag"){
  state.current={x,y,width,height};
  state.card.style.transform=`translate3d(${dx}px,${dy}px,0)`;
 }else applyGridPreview(state,x,y,width,height);
}
widgetGrid.addEventListener("pointerdown",e=>{
 const project=projects.find(item=>item.id===activeProjectId);
 if(!sortMode||!project||gridPointerState)return;
 const card=e.target.closest(".widget-card");if(!card||!widgetGrid.contains(card))return;
 const resize=e.target.closest(".grid-resize-handle"),resizeX=e.target.closest(".grid-resize-x"),resizeY=e.target.closest(".grid-resize-y"),edgeLeft=e.target.closest(".grid-resize-left"),edgeRight=e.target.closest(".grid-resize-right"),edgeTop=e.target.closest(".grid-resize-top"),edgeBottom=e.target.closest(".grid-resize-bottom");
 const handle=e.target.closest(".drag-handle");
 const interactive=e.target.closest("button,input,select,textarea,a,[contenteditable],.terminal-screen,.terminal-compose");
 const mode=resize?"resize":resizeX?"resize-x":resizeY?"resize-y":edgeLeft?"resize-left":edgeRight?"resize-right":edgeTop?"resize-top":edgeBottom?"resize-bottom":handle?"drag":null;
 // Keep ordinary widget surfaces available for native vertical page scrolling.
 // Move only from the dedicated center grip; edge zones resize the full card.
 if(!mode||interactive&&!resize&&!resizeX&&!resizeY&&!edgeLeft&&!edgeRight&&!edgeTop&&!edgeBottom&&!handle)return;
 if(e.pointerType==="mouse"&&e.button!==0)return;
 const item=project.widgets.find(w=>String(w.id)===String(card.dataset.widgetId));if(!item)return;
 const rect=card.getBoundingClientRect();
 gridPointerState={mode,id:item.id,pointerId:e.pointerId,card,startX:e.clientX,startY:e.clientY,
  grabX:e.clientX-rect.left,grabY:e.clientY-rect.top,
  baseX:Number(item.gridX)||0,baseY:Number(item.gridY)||0,baseW:Math.max(1,Number(item.gridW)||4),baseH:Math.max(1,Number(item.gridH)||4),
  current:{x:Number(item.gridX)||0,y:Number(item.gridY)||0,width:Math.max(1,Number(item.gridW)||4),height:Math.max(1,Number(item.gridH)||4)},
  originalColumn:card.style.gridColumn,originalRow:card.style.gridRow};
 card.classList.add(mode==="drag"?"grid-dragging":"grid-resizing");
 try{widgetGrid.setPointerCapture(e.pointerId)}catch(_){gridPointerState=null;return;}
 e.preventDefault();e.stopPropagation();
},true);
let pendingGridPointerEvent=null;
widgetGrid.addEventListener("pointermove",e=>{
 if(!gridPointerState||gridPointerState.pointerId!==e.pointerId)return;
 e.preventDefault();pendingGridPointerEvent={pointerId:e.pointerId,clientX:e.clientX,clientY:e.clientY,pointerType:e.pointerType};
 if(!gridPreviewFrame)gridPreviewFrame=requestAnimationFrame(()=>{gridPreviewFrame=0;const latest=pendingGridPointerEvent;pendingGridPointerEvent=null;if(latest&&gridPointerState&&gridPointerState.pointerId===latest.pointerId)updateGridPointer(latest);});
},true);
function finishGridPointer(e,cancelled=false){
 const state=gridPointerState;if(!state||state.pointerId!==e.pointerId)return;
 if(gridPreviewFrame){cancelAnimationFrame(gridPreviewFrame);gridPreviewFrame=0;}
 if(!cancelled)updateGridPointer(e);
 pendingGridPointerEvent=null;gridPointerState=null;
 const project=projects.find(item=>item.id===activeProjectId),widget=project?.widgets.find(item=>String(item.id)===String(state.id));
 clearGridPreview(state);
 try{if(widgetGrid.hasPointerCapture(e.pointerId))widgetGrid.releasePointerCapture(e.pointerId)}catch(_){}
 if(cancelled||!project||!widget){render();return;}
 let next=state.current;
 if(!gridPlacementFree(project.widgets,widget.id,next.x,next.y,next.width,next.height)&&state.mode==="drag")
  next=findNearestGridPlacement(project.widgets,widget.id,next.x,next.y,next.width,next.height);
 if(!next||!gridPlacementFree(project.widgets,widget.id,next.x,next.y,next.width,next.height)){
  render();showToast("لا توجد مساحة مناسبة هنا. جرّب مكاناً آخر.");return;
 }
 widget.gridX=next.x;widget.gridY=next.y;widget.gridW=next.width;widget.gridH=next.height;
 save();render();
}
widgetGrid.addEventListener("pointerup",e=>finishGridPointer(e,false),true);
widgetGrid.addEventListener("pointercancel",e=>finishGridPointer(e,true),true);
widgetGrid.addEventListener("lostpointercapture",e=>{
 if(gridPointerState&&gridPointerState.pointerId===e.pointerId)finishGridPointer(e,true);
},true);

// v96: activate resize rails only after a stationary long-press (Blynk-like).
let resizeHold=null;
const RESIZE_HOLD_MS=650, RESIZE_HOLD_MOVE=11;
function clearResizeHold(){
 if(!resizeHold)return;
 clearTimeout(resizeHold.timer);
 resizeHold.card?.classList.remove("resize-pressing");
 resizeHold=null;
}
widgetGrid.addEventListener("pointerdown",e=>{
 if(!sortMode||e.button!==undefined&&e.button!==0||e.target.closest(".drag-handle,.grid-resize-handle,.grid-resize-x,.grid-resize-y,.grid-resize-left,.grid-resize-right,.grid-resize-top,.grid-resize-bottom,button,input,select,textarea,a,[contenteditable],.terminal-screen,.terminal-compose"))return;
 const card=e.target.closest(".widget-card");
 if(!card||!widgetGrid.contains(card)||gridPointerState)return;
 clearResizeHold();
 const hold={card,pointerId:e.pointerId,x:e.clientX,y:e.clientY,timer:0};
 hold.timer=setTimeout(()=>{
  if(resizeHold!==hold||!sortMode)return;
  card.classList.add("resize-active");
  card.classList.remove("resize-pressing");
  resizeHold=null;
  if(typeof showToast==="function")showToast("وضع التحجيم: اسحب أحد مقابض الحواف لتغيير الحجم");
 },RESIZE_HOLD_MS);
 resizeHold=hold;card.classList.add("resize-pressing");
});
widgetGrid.addEventListener("pointermove",e=>{
 if(!resizeHold||resizeHold.pointerId!==e.pointerId)return;
 if(Math.hypot(e.clientX-resizeHold.x,e.clientY-resizeHold.y)>RESIZE_HOLD_MOVE)clearResizeHold();
},true);
["pointerup","pointercancel","lostpointercapture"].forEach(type=>widgetGrid.addEventListener(type,e=>{
 if(resizeHold&&resizeHold.pointerId===e.pointerId)clearResizeHold();
},true));

// ترتيب المشاريع بالسحب من مقبض ⠿ أو بأزرار النقل، مع حفظ الترتيب تلقائياً.
let projectDragState=null;

projectGrid.addEventListener("pointerdown",e=>{if(!projectLayoutMode)return;const handle=e.target.closest(".project-drag-handle");if(!handle)return;const card=handle.closest(".project-card");if(!card)return;projectDragState={id:card.dataset.projectId,pointerId:e.pointerId,card};card.classList.add("project-dragging");try{handle.setPointerCapture(e.pointerId)}catch(err){}e.preventDefault();});
projectGrid.addEventListener("pointermove",e=>{if(!projectDragState||projectDragState.pointerId!==e.pointerId)return;const target=document.elementFromPoint(e.clientX,e.clientY)?.closest(".project-card");projectGrid.querySelectorAll(".project-drop-target").forEach(el=>el.classList.remove("project-drop-target"));if(target&&target!==projectDragState.card)target.classList.add("project-drop-target");});
function finishProjectDrag(e){if(!projectDragState||projectDragState.pointerId!==e.pointerId)return;const fromId=projectDragState.id,target=document.elementFromPoint(e.clientX,e.clientY)?.closest(".project-card");projectDragState.card.classList.remove("project-dragging");projectGrid.querySelectorAll(".project-drop-target").forEach(el=>el.classList.remove("project-drop-target"));projectDragState=null;if(!target||target.dataset.projectId===fromId)return;const from=projects.findIndex(p=>String(p.id)===String(fromId)),to=projects.findIndex(p=>String(p.id)===String(target.dataset.projectId));if(from<0||to<0||from===to)return;const [item]=projects.splice(from,1);projects.splice(to,0,item);save();render();projectLayoutMode=true;projectLayoutControls.classList.add("visible");projectGrid.classList.add("project-actions-visible");projectLayoutBtn.textContent="✓";projectLayoutBtn.title="إنهاء تنسيق الصفوف";projectLayoutBtn.setAttribute("aria-label","إنهاء تنسيق الصفوف");}
projectGrid.addEventListener("pointerup",finishProjectDrag);projectGrid.addEventListener("pointercancel",e=>{if(projectDragState){projectDragState.card.classList.remove("project-dragging");projectGrid.querySelectorAll(".project-drop-target").forEach(el=>el.classList.remove("project-drop-target"));projectDragState=null;}});
// الضغط المطوّل خمس ثوانٍ على بطاقة المشروع يفتح إعدادات تعديل المشروع.
let projectHoldTimer=null,projectHoldCard=null,projectHoldTriggered=false;
projectGrid.addEventListener("pointerdown",e=>{const card=e.target.closest(".project-card");if(!card||e.target.closest("button"))return;clearTimeout(projectHoldTimer);projectHoldCard=card;projectHoldTriggered=false;card.classList.add("long-pressing");projectHoldTimer=setTimeout(()=>{projectHoldTriggered=true;card.classList.remove("long-pressing");editProject(card.dataset.projectId);},5000);});
projectGrid.addEventListener("pointermove",e=>{if(!projectHoldTimer||!projectHoldCard)return;if(Math.abs(e.movementX||0)>12||Math.abs(e.movementY||0)>12){clearTimeout(projectHoldTimer);projectHoldTimer=null;projectHoldCard=null;}});
function cancelProjectHold(){clearTimeout(projectHoldTimer);projectHoldTimer=null;if(projectHoldCard)projectHoldCard.classList.remove("long-pressing");projectHoldCard=null;}
projectGrid.addEventListener("pointerup",cancelProjectHold);projectGrid.addEventListener("pointercancel",cancelProjectHold);
projectGrid.addEventListener("contextmenu",e=>{if(e.target.closest(".project-card"))e.preventDefault();});
projectGrid.addEventListener("click",e=>{if(projectHoldTriggered){e.preventDefault();e.stopPropagation();projectHoldTriggered=false;}},true);
// إعداد عدد المشاريع في كل صف، بنفس أسلوب تخطيط المؤشرات.
const projectLayoutBtn=document.getElementById("projectLayoutBtn"),projectLayoutControls=document.getElementById("projectLayoutControls");
projectLayoutBtn.addEventListener("click",()=>{projectLayoutMode=!projectLayoutMode;projectLayoutControls.classList.toggle("visible",projectLayoutMode);projectGrid.classList.toggle("project-actions-visible",projectLayoutMode);projectLayoutBtn.textContent=projectLayoutMode?"✓":"▦";projectLayoutBtn.title=projectLayoutMode?"إنهاء تنسيق الصفوف":"تنسيق الصفوف";projectLayoutBtn.setAttribute("aria-label",projectLayoutBtn.title);});
document.getElementById("projectCardHeight").addEventListener("input",e=>{const height=Math.max(120,Math.min(260,parseInt(e.target.value,10)||142));projectLayout.cardHeight=height;projectGrid.style.setProperty("--project-card-height",height+"px");document.getElementById("projectCardHeightValue").textContent=height+" px";saveProjectLayout();});
document.getElementById("projectDefaultColumns").addEventListener("change",e=>{projectLayout.columns=Math.max(1,Math.min(6,parseInt(e.target.value,10)||2));saveProjectLayout();render();projectLayoutMode=true;projectLayoutControls.classList.add("visible");projectGrid.classList.add("project-actions-visible");projectLayoutBtn.textContent="✓";projectLayoutBtn.title="إنهاء تنسيق الصفوف";projectLayoutBtn.setAttribute("aria-label",projectLayoutBtn.title);});
document.getElementById("projectRowLayoutControls").addEventListener("change",e=>{const select=e.target.closest("[data-project-row-columns]");if(!select)return;const row=Math.max(0,parseInt(select.dataset.projectRowColumns,10)||0);projectLayout.rowColumns[row]=Math.max(1,Math.min(6,parseInt(select.value,10)||2));saveProjectLayout();render();projectLayoutMode=true;projectLayoutControls.classList.add("visible");projectGrid.classList.add("project-actions-visible");projectLayoutBtn.textContent="✓";projectLayoutBtn.title="إنهاء تنسيق الصفوف";projectLayoutBtn.setAttribute("aria-label",projectLayoutBtn.title);});
window.openProject=id=>{
 const project=projects.find(x=>x.id===id);if(!project)return;
 activeProjectId=id;sortMode=false;activateProjectTab(project,project.activeTabId);
 history.pushState({view:"project",projectId:id},"", "#project-"+encodeURIComponent(id));
 render();
};
window.editProject=id=>{const p=projects.find(x=>x.id===id);if(!p)return;document.getElementById("projectId").value=id;document.getElementById("projectName").value=p.name;document.getElementById("projectModalTitle").textContent="تعديل المشروع";projectEditor.showModal()};
window.deleteProject=id=>{const p=projects.find(x=>x.id===id);if(!p)return;if(confirm(`هل تريد حذف المشروع «${p.name}» وجميع مؤشراته؟`)){projects=projects.filter(x=>x.id!==id);save();render()}};
function openNewProject(){projectForm.reset();document.getElementById("projectId").value="";document.getElementById("projectModalTitle").textContent="إضافة مشروع جديد";projectEditor.showModal()}
document.getElementById("backBtn").onclick=()=>{
 if(activeProjectId){history.back();}
 else{activeProjectId=null;render();}
};
// دعم زر الرجوع في المتصفح وأجهزة أندرويد للعودة إلى قائمة المشاريع.
if(!history.state)history.replaceState({view:"projects"},"",location.pathname+location.search);
window.addEventListener("popstate",event=>{
 activeProjectId=event.state?.view==="project"?event.state.projectId:null;sortMode=false;
 render();
});
// دعم زر الرجوع في WebView/Android أيضاً، بما في ذلك أغلفة Cordova إن وجدت.
window.addEventListener("hashchange",()=>{
 const match=location.hash.match(/^#project-(.+)$/);
 if(!match&&activeProjectId){activeProjectId=null;sortMode=false;render();}
});
document.addEventListener("backbutton",event=>{
 if(activeProjectId){event?.preventDefault?.();history.back();}
},false);

const widgetTypeChooser=document.getElementById("widgetTypeChooser");
document.getElementById("addBtn").onclick=()=>activeProjectId?widgetTypeChooser.showModal():openNewProject();
document.getElementById("closeTypeChooser").onclick=()=>widgetTypeChooser.close();
document.getElementById("chooseValue").onclick=()=>{widgetTypeChooser.close();openNewWidget("value")};
document.getElementById("chooseGauge").onclick=()=>{widgetTypeChooser.close();openNewWidget("gauge")};
document.getElementById("chooseDonutGauge").onclick=()=>{widgetTypeChooser.close();openNewWidget("donutGauge")};
document.getElementById("chooseDonutGaugeAlt").onclick=()=>{widgetTypeChooser.close();openNewWidget("donutGaugeAlt")};
document.getElementById("chooseWaterRing").onclick=()=>{widgetTypeChooser.close();openNewWidget("waterRing")};
document.getElementById("chooseTemperatureDial").onclick=()=>{widgetTypeChooser.close();openNewWidget("temperatureDial")};
document.getElementById("gaugeColorMode").addEventListener("change",e=>{document.getElementById("gaugeMultiColors").hidden=e.target.value!=="multi"});
document.getElementById("chooseButton").onclick=()=>{widgetTypeChooser.close();openNewWidget("button")};
document.getElementById("chooseNumericInput").onclick=()=>{widgetTypeChooser.close();openNewWidget("numericInput")};
document.getElementById("chooseTextInput").onclick=()=>{widgetTypeChooser.close();openNewWidget("textInput")};
document.getElementById("chooseTerminal").onclick=()=>{widgetTypeChooser.close();openNewWidget("terminal")};
document.getElementById("chooseTabs").onclick=()=>{widgetTypeChooser.close();const p=projects.find(x=>x.id===activeProjectId);if(!p)return;p.tabsWidget=true;save();render();showToast("تمت إضافة ويدجت التبويبات إلى المشروع")};
document.getElementById("closeProject").onclick=()=>projectEditor.close();
document.getElementById("cancelProject").onclick=()=>projectEditor.close();
projectForm.addEventListener("submit",e=>{e.preventDefault();const id=document.getElementById("projectId").value,name=document.getElementById("projectName").value.trim();if(id){const p=projects.find(x=>x.id===id);if(p)p.name=name}else {const id="p"+Date.now(),tab={id:"tab-home-"+Date.now(),name:"الرئيسية",widgets:[],layoutColumns:3,rowColumns:[],rowHeights:[],layoutScale:1,gridLayoutEnabled:true};projects.push({id,name,widgets:[],tabs:[tab],tabsWidget:false,activeTabId:tab.id,layoutColumns:3,rowColumns:[],rowHeights:[],layoutScale:1});}save();projectEditor.close();render()});
function setWidgetEditorType(type){
 const isButton=type==="button",isNumeric=type==="numericInput",isText=type==="textInput",isTerminal=type==="terminal",isGauge=["gauge","donutGauge","donutGaugeAlt","waterRing","temperatureDial"].includes(type),isValue=type==="value";
 document.getElementById("widgetType").value=type;
 document.getElementById("valueFields").hidden=!isValue;
 document.getElementById("gaugeFields").hidden=!isGauge;
 document.getElementById("buttonFields").hidden=!isButton;
 document.getElementById("numericInputFields").hidden=!isNumeric;
 document.getElementById("textInputFields").hidden=!isText;
 document.getElementById("widgetModalTitle").textContent=isButton?"إضافة زر تحكم":isNumeric?"إضافة Numeric Input":isText?"إضافة Text Input":isTerminal?"إضافة Terminal":isGauge?(type==="gauge"?"إضافة Gauge":type==="donutGauge"?"إضافة Donut Gauge":type==="donutGaugeAlt"?"إضافة Donut Gauge Glow":"إضافة Water Ring"):"إضافة مؤشر Value";
 // Only the shared identity fields are required for every widget type.
 document.getElementById("title").required=true;
 document.getElementById("token").required=true;
 document.getElementById("virtualNumber").required=true;
 document.getElementById("unit").required=false;
 document.getElementById("precision").required=isValue;
 document.getElementById("valueFontSize").required=isValue;
 document.getElementById("interval").required=isValue;
 syncValueLedControls();
}
function syncValueLedControls(){
 const enabled=document.getElementById("valueLedEnabled").checked;
 const pinInput=document.getElementById("valueLedPin");
 pinInput.disabled=!enabled;
 pinInput.required=enabled;
}
document.getElementById("valueLedEnabled").addEventListener("change",syncValueLedControls);
function widgetRowCapacity(p,row){return Math.max(1,Math.min(6,parseInt(p.rowColumns?.[row],10)||Math.max(1,Math.min(6,parseInt(p.layoutColumns,10)||3))));}
function widgetRowStart(p,row){let start=0;for(let r=0;r<row;r++)start+=widgetRowCapacity(p,r);return start;}
function widgetRowForSlot(p,slot){let start=0;for(let row=0;row<9;row++){const cap=widgetRowCapacity(p,row);if(slot>=start&&slot<start+cap)return row;start+=cap;}return 8;}
function openNewWidget(type="value"){widgetForm.reset();document.getElementById("widgetId").value="";document.getElementById("precision").value="1";document.getElementById("valueFontSize").value="24";document.getElementById("interval").value="5";document.getElementById("virtualNumber").value=type==="button"?"42":"23";document.getElementById("token").value=type==="button"?"qGSaSjlvIwyaExysk2X5HWGPrnGCmBs9":"";document.getElementById("onLabel").value="ON";document.getElementById("offLabel").value="OFF";document.getElementById("buttonMode").value="switch";document.getElementById("onColor").value="#25c28a";document.getElementById("offColor").value="#596579";document.getElementById("onFontSize").value="35";document.getElementById("offFontSize").value="35";document.getElementById("numericMin").value="0";document.getElementById("numericMax").value="100";document.getElementById("numericStep").value="1";document.getElementById("numericPrecision").value="0";document.getElementById("numericInitial").value="0";document.getElementById("textInputPlaceholder").value="";document.getElementById("textInputMaxLength").value="120";document.getElementById("textInputInitial").value="";document.getElementById("gaugeMin").value=type==="temperatureDial"?"-20":"0";document.getElementById("gaugeMax").value=type==="temperatureDial"?"60":"100";document.getElementById("gaugeUnit").value=type==="temperatureDial"?"°C":"";document.getElementById("gaugePrecision").value="1";document.getElementById("gaugeColor").value="#35d0ba";document.getElementById("gaugeFontSize").value="24";document.getElementById("gaugeColorMode").value="single";document.getElementById("gaugeLowColor").value="#22c55e";document.getElementById("gaugeMidColor").value="#f59e0b";document.getElementById("gaugeHighColor").value="#ef4444";document.getElementById("gaugeMultiColors").hidden=true;document.getElementById("gaugeInterval").value="5";document.getElementById("valueLedEnabled").checked=false;document.getElementById("valueLedPin").value="0";setWidgetEditorType(type);widgetEditor.showModal()}
window.editWidget=id=>{const w=(projects.find(p=>p.id===activeProjectId)?.widgets||[]).find(x=>x.id===id);if(!w)return;widgetForm.reset();document.getElementById("widgetId").value=w.id;document.getElementById("title").value=w.title;document.getElementById("token").value=tokenFromWidget(w);document.getElementById("virtualNumber").value=String(w.virtualNumber??extractVirtualNumber(w)??23);const type=w.type==="button"?"button":w.type==="numericInput"?"numericInput":w.type==="textInput"?"textInput":w.type==="terminal"?"terminal":["gauge","donutGauge","donutGaugeAlt","waterRing","temperatureDial"].includes(w.type)?w.type:"value";setWidgetEditorType(type);if(type==="button"){document.getElementById("onLabel").value=w.onLabel||"ON";document.getElementById("offLabel").value=w.offLabel||"OFF";document.getElementById("buttonMode").value=w.buttonMode||"switch";document.getElementById("onColor").value=w.onColor||"#25c28a";document.getElementById("offColor").value=w.offColor||"#596579";document.getElementById("onFontSize").value=String(w.onFontSize||35);document.getElementById("offFontSize").value=String(w.offFontSize||35);}else if(type==="numericInput"){document.getElementById("numericMin").value=String(w.minValue??0);document.getElementById("numericMax").value=String(w.maxValue??100);document.getElementById("numericStep").value=String(w.step??1);document.getElementById("numericPrecision").value=String(w.precision??0);document.getElementById("numericInitial").value=String(Number.isFinite(Number(w.value))?w.value:(w.initialValue??0));}else if(type==="textInput"){document.getElementById("textInputPlaceholder").value=w.placeholder||"";document.getElementById("textInputMaxLength").value=String(w.maxLength||120);document.getElementById("textInputInitial").value=String(w.value??w.initialValue??"");}else if(["gauge","donutGauge","donutGaugeAlt","waterRing","temperatureDial"].includes(type)){document.getElementById("gaugeMin").value=String(w.minValue??0);document.getElementById("gaugeMax").value=String(w.maxValue??100);document.getElementById("gaugeUnit").value=w.unit||"";document.getElementById("gaugePrecision").value=String(w.precision??1);document.getElementById("gaugeColor").value=w.gaugeColor||"#35d0ba";document.getElementById("gaugeFontSize").value=String(w.gaugeFontSize??20);document.getElementById("gaugeColorMode").value=w.gaugeColorMode||"single";document.getElementById("gaugeLowColor").value=w.gaugeLowColor||"#22c55e";document.getElementById("gaugeMidColor").value=w.gaugeMidColor||"#f59e0b";document.getElementById("gaugeHighColor").value=w.gaugeHighColor||"#ef4444";document.getElementById("gaugeMultiColors").hidden=document.getElementById("gaugeColorMode").value!=="multi";document.getElementById("gaugeInterval").value=String(w.interval??5);}else if(type==="value"){document.getElementById("unit").value=w.unit||"";document.getElementById("precision").value=String(w.precision??1);document.getElementById("valueFontSize").value=String(w.valueFontSize??35);document.getElementById("interval").value=String(w.interval??5);document.getElementById("valueLedEnabled").checked=!!w.ledIndicatorEnabled;document.getElementById("valueLedPin").value=String(w.ledVirtualNumber??0);}document.getElementById("widgetModalTitle").textContent=type==="button"?"تعديل زر التحكم":type==="numericInput"?"تعديل Numeric Input":type==="textInput"?"تعديل Text Input":type==="terminal"?"تعديل Terminal":type==="gauge"?"تعديل Gauge":type==="donutGauge"?"تعديل Donut Gauge":type==="donutGaugeAlt"?"تعديل Donut Gauge Glow":type==="waterRing"?"تعديل Water Ring":type==="temperatureDial"?"تعديل Temperature Dial":"تعديل مؤشر Value";widgetEditor.showModal()};
window.deleteWidget=id=>{const p=projects.find(x=>x.id===activeProjectId);if(!p||!confirm("هل تريد حذف هذا المؤشر؟"))return;clearTimeout(refreshTimers[id]);delete refreshTimers[id];p.widgets=p.widgets.filter(w=>w.id!==id);save();render()};
document.getElementById("closeWidget").onclick=()=>widgetEditor.close();
document.getElementById("cancelWidget").onclick=()=>widgetEditor.close();
widgetForm.addEventListener("submit",e=>{
 e.preventDefault();const p=projects.find(x=>x.id===activeProjectId);if(!p)return;
 const id=document.getElementById("widgetId").value,old=(p.widgets||[]).find(w=>w.id===id);
 const type=document.getElementById("widgetType").value;
 const titleValue=document.getElementById("title").value.trim();if(!titleValue){showToast("أدخل اسم المؤشر أولاً");document.getElementById("title").focus();return;}
 const token=document.getElementById("token").value.trim();if(!token){showToast("أدخل التوكين أولاً");document.getElementById("token").focus();return;}
 const virtualRaw=document.getElementById("virtualNumber").value.trim();if(!/^\d{1,3}$/.test(virtualRaw)){showToast("أدخل رقم فيرجوال صحيحاً من 0 إلى 999");return;}const virtualNumber=Number(virtualRaw);
 const usedSlots=new Set(p.widgets.filter(w=>!old||w.id!==old.id).map(w=>Number(w.slot)||0));const oldSlot=old&&Number.isInteger(Number(old.slot))?Number(old.slot):-1;let targetSlot=oldSlot>=0?oldSlot:0;if(!old){while(usedSlots.has(targetSlot))targetSlot++;}
 if(["gauge","donutGauge","donutGaugeAlt","waterRing","temperatureDial"].includes(type)){
  const minValue=Number(document.getElementById("gaugeMin").value),maxValue=Number(document.getElementById("gaugeMax").value),gaugeFontSize=Math.max(12,Math.min(46,Number(document.getElementById("gaugeFontSize").value)||24)),gaugeColorMode=document.getElementById("gaugeColorMode").value,precision=Math.max(0,Math.min(3,Number(document.getElementById("gaugePrecision").value)||0)),interval=Math.max(2,Math.min(86400,Number(document.getElementById("gaugeInterval").value)||5));
  if(!Number.isFinite(minValue)||!Number.isFinite(maxValue)||maxValue<=minValue){showToast("يجب أن تكون قيمة Max أكبر من Min");return;}
  const remote=old&&Number.isFinite(Number(old.value))?Number(old.value):minValue,item={id:id||("gauge"+Date.now()),type,slot:targetSlot,title:titleValue,token,virtualNumber,minValue,maxValue,precision,unit:document.getElementById("gaugeUnit").value.trim(),gaugeColor:document.getElementById("gaugeColor").value,gaugeFontSize,gaugeColorMode,gaugeLowColor:document.getElementById("gaugeLowColor").value,gaugeMidColor:document.getElementById("gaugeMidColor").value,gaugeHighColor:document.getElementById("gaugeHighColor").value,interval,value:Math.max(minValue,Math.min(maxValue,remote)),connected:old?.connected??null,updated:old?.updated??"بانتظار القراءة"};
  preserveGridGeometry(item,old,p);if(old){p.widgets=p.widgets.map(w=>w.id===id?item:w);clearTimeout(refreshTimers[id]);delete refreshTimers[id]}else p.widgets.push(item);save();widgetEditor.close();render();return;
 }
 if(type==="terminal"){const item={id:id||("term"+Date.now()),type:"terminal",slot:targetSlot,title:titleValue,token,virtualNumber,terminalLines:Array.isArray(old?.terminalLines)?old.terminalLines:[],lastRemoteValue:old?.lastRemoteValue??null,connected:old?.connected??null,updated:old?.updated??"Terminal ready"};preserveGridGeometry(item,old,p);if(old){p.widgets=p.widgets.map(w=>w.id===id?item:w);clearTimeout(refreshTimers[id]);delete refreshTimers[id]}else p.widgets.push(item);save();widgetEditor.close();render();return;}
 if(type==="textInput"){const maxLength=Math.max(1,Math.min(512,parseInt(document.getElementById("textInputMaxLength").value,10)||120)),placeholder=document.getElementById("textInputPlaceholder").value.slice(0,80),initialValue=document.getElementById("textInputInitial").value.slice(0,maxLength),current=String(old?.value??initialValue).slice(0,maxLength);const item={id:id||("ti"+Date.now()),type:"textInput",slot:targetSlot,title:titleValue,token,virtualNumber,placeholder,maxLength,initialValue,value:current,updated:old?.updated??"جاهز للإدخال"};preserveGridGeometry(item,old,p);if(old){p.widgets=p.widgets.map(w=>w.id===id?item:w);clearTimeout(refreshTimers[id]);delete refreshTimers[id]}else p.widgets.push(item);save();widgetEditor.close();render();return;}
 if(type==="numericInput"){const readDecimal=id=>{const raw=String(document.getElementById(id).value??"").trim().replace(/\s/g,"").replace(",",".");return raw===""?NaN:Number(raw);};const minValue=readDecimal("numericMin"),maxValue=readDecimal("numericMax"),step=readDecimal("numericStep"),precision=Math.max(0,Math.min(6,Number(document.getElementById("numericPrecision").value)||0));let initialValue=readDecimal("numericInitial");if(!Number.isFinite(minValue)||!Number.isFinite(maxValue)||maxValue<minValue||!Number.isFinite(step)||step<=0||!Number.isFinite(initialValue)){showToast("تحقق من الحد الأدنى والأعلى ومقدار التغيير والقيمة الابتدائية");return;}initialValue=Number(Math.min(maxValue,Math.max(minValue,initialValue)).toFixed(precision));const current=old&&Number.isFinite(Number(old.value))?Number(old.value):initialValue;const item={id:id||("ni"+Date.now()),type:"numericInput",slot:targetSlot,title:titleValue,token,virtualNumber,minValue,maxValue,step,precision,initialValue,value:Number(Math.min(maxValue,Math.max(minValue,current)).toFixed(precision)),unit:"",interval:10,updated:old?.updated??"جاهز للإدخال"};preserveGridGeometry(item,old,p);if(old){p.widgets=p.widgets.map(w=>w.id===id?item:w);clearTimeout(refreshTimers[id]);delete refreshTimers[id]}else p.widgets.push(item);save();widgetEditor.close();render();return;}
 if(type==="button"){const item={id:id||("b"+Date.now()),type:"button",slot:targetSlot,title:titleValue,token,virtualNumber,onLabel:document.getElementById("onLabel").value.trim()||"ON",offLabel:document.getElementById("offLabel").value.trim()||"OFF",buttonMode:document.getElementById("buttonMode").value,onColor:document.getElementById("onColor").value,offColor:document.getElementById("offColor").value,onFontSize:Math.max(10,Math.min(48,Number(document.getElementById("onFontSize").value)||35)),offFontSize:Math.max(10,Math.min(48,Number(document.getElementById("offFontSize").value)||35)),buttonState:old?.buttonState??false,updated:old?.updated??"جاهز للتحكم"};preserveGridGeometry(item,old,p);if(old){p.widgets=p.widgets.map(w=>w.id===id?item:w);clearTimeout(refreshTimers[id]);delete refreshTimers[id]}else p.widgets.push(item);save();widgetEditor.close();render();return;}
 const ledEnabled=document.getElementById("valueLedEnabled").checked;
 const ledPinRaw=document.getElementById("valueLedPin").value.trim();
 if(ledEnabled&&(!/^\d{1,3}$/.test(ledPinRaw)||Number(ledPinRaw)>999)){showToast("أدخل رقم Virtual Pin صحيحاً لمؤشر LED من 0 إلى 999");document.getElementById("valueLedPin").focus();return;}
 const interval=Math.max(2,Math.min(86400,Number(document.getElementById("interval").value)||5));
 const valueFontSize=Math.max(12,Math.min(48,Number(document.getElementById("valueFontSize").value)||24));const item={id:id||("w"+Date.now()),type:"value",slot:targetSlot,title:titleValue,token,virtualNumber,unit:document.getElementById("unit").value.trim(),precision:Math.max(0,Math.min(10,Number(document.getElementById("precision").value)||0)),valueFontSize,interval,value:old?.value??"—",connected:old?.connected??null,ledIndicatorEnabled:ledEnabled,ledVirtualNumber:ledEnabled?Number(ledPinRaw):0,ledState:ledEnabled&&old?.ledIndicatorEnabled&&Number(old?.ledVirtualNumber)===Number(ledPinRaw)?(old?.ledState??null):null,updated:old?.updated??"بانتظار القراءة"};
 preserveGridGeometry(item,old,p);if(old){p.widgets=p.widgets.map(w=>w.id===id?item:w);clearTimeout(refreshTimers[id]);delete refreshTimers[id]}else p.widgets.push(item);
 save();widgetEditor.close();render();
});
let activePushId=null,activePushButton=null;
async function sendNumericInputValue(w,value){const pin=Math.max(0,Math.min(999,parseInt(w.virtualNumber??23,10)||0)),url=API_ROOT+encodeURIComponent(tokenFromWidget(w))+"/update/V"+pin+"?value="+encodeURIComponent(String(value));try{await fetch(url,{method:"GET",mode:"no-cors",cache:"no-store",keepalive:true});}catch(err){showToast("تعذر إرسال القيمة؛ تحقق من الاتصال");}save();}
function commitNumericInput(w,raw){let value=Number(raw);if(!Number.isFinite(value)){showToast("أدخل قيمة رقمية صحيحة");const restore=document.querySelector(`[data-numeric-value="${CSS.escape(w.id)}"]`);if(restore)restore.value=Number.isFinite(Number(w.value))?Number(w.value).toFixed(Math.max(0,Math.min(6,Number(w.precision)||0))):Number(w.initialValue||0).toFixed(Math.max(0,Math.min(6,Number(w.precision)||0)));return false;}const min=Number.isFinite(Number(w.minValue))?Number(w.minValue):0,max=Number.isFinite(Number(w.maxValue))?Number(w.maxValue):100,precision=Math.max(0,Math.min(6,Number(w.precision)||0));value=Math.min(max,Math.max(min,value));value=Number(value.toFixed(precision));w.value=value;save();const input=document.querySelector(`[data-numeric-value="${CSS.escape(w.id)}"]`);if(input)input.value=value.toFixed(precision);sendNumericInputValue(w,value);return true;}
widgetGrid.addEventListener("click",e=>{const btn=e.target.closest("[data-numeric-step]");if(!btn)return;const id=btn.dataset.numericId,w=(projects.find(p=>p.id===activeProjectId)?.widgets||[]).find(x=>x.id===id);if(!w||w.type!=="numericInput")return;const current=Number.isFinite(Number(w.value))?Number(w.value):Number(w.initialValue)||0,step=Number(w.step)||1;commitNumericInput(w,current+Number(btn.dataset.numericStep)*step);});
widgetGrid.addEventListener("change",e=>{const input=e.target.closest("[data-numeric-value]");if(!input)return;const w=(projects.find(p=>p.id===activeProjectId)?.widgets||[]).find(x=>x.id===input.dataset.numericValue);if(!w||w.type!=="numericInput")return;commitNumericInput(w,input.value);});
widgetGrid.addEventListener("keydown",e=>{const input=e.target.closest("[data-numeric-value]");if(!input||e.key!=="Enter")return;e.preventDefault();input.blur();});
async function sendTextInputValue(w,value){const pin=Math.max(0,Math.min(999,parseInt(w.virtualNumber??23,10)||0)),url=API_ROOT+encodeURIComponent(tokenFromWidget(w))+"/update/V"+pin+"?value="+encodeURIComponent(String(value));try{await fetch(url,{method:"GET",mode:"no-cors",cache:"no-store",keepalive:true});showToast("تم إرسال النص");}catch(err){showToast("تعذر إرسال النص؛ تحقق من الاتصال");}}
widgetGrid.addEventListener("keydown",e=>{const input=e.target.closest("[data-text-input]");if(!input||e.key!=="Enter")return;e.preventDefault();const w=(projects.find(p=>p.id===activeProjectId)?.widgets||[]).find(x=>x.id===input.dataset.textInput);if(!w||w.type!=="textInput")return;const value=String(input.value||"").slice(0,Math.max(1,Math.min(512,Number(w.maxLength)||120)));w.value=value;save();sendTextInputValue(w,value);input.blur();});
widgetGrid.addEventListener("change",e=>{const input=e.target.closest("[data-text-input]");if(!input)return;const w=(projects.find(p=>p.id===activeProjectId)?.widgets||[]).find(x=>x.id===input.dataset.textInput);if(!w||w.type!=="textInput")return;w.value=String(input.value||"").slice(0,Math.max(1,Math.min(512,Number(w.maxLength)||120)));save();});

async function sendTerminalCommand(w,raw){const command=String(raw??"");if(!command.trim())return;appendTerminalLine(w,command,"sent");const pin=Math.max(0,Math.min(999,parseInt(w.virtualNumber??23,10)||0)),url=API_ROOT+encodeURIComponent(tokenFromWidget(w))+"/update/V"+pin+"?value="+encodeURIComponent(command);try{await fetch(url,{method:"GET",mode:"no-cors",cache:"no-store",keepalive:true});}catch(err){appendTerminalLine(w,"تعذر إرسال الأمر؛ تحقق من الاتصال","received");}}
widgetGrid.addEventListener("click",e=>{const send=e.target.closest("[data-terminal-send]");if(send){const id=send.dataset.terminalSend,w=(projects.find(p=>p.id===activeProjectId)?.widgets||[]).find(x=>x.id===id);const input=widgetGrid.querySelector(`[data-terminal-input="${CSS.escape(id)}"]`);if(w&&input){const value=input.value;input.value="";sendTerminalCommand(w,value);}return;}});
widgetGrid.addEventListener("keydown",e=>{const input=e.target.closest("[data-terminal-input]");if(!input||e.key!=="Enter")return;e.preventDefault();const id=input.dataset.terminalInput,w=(projects.find(p=>p.id===activeProjectId)?.widgets||[]).find(x=>x.id===id);if(!w)return;const value=input.value;input.value="";sendTerminalCommand(w,value);});
// تعامل مع زر Button في مرحلة الالتقاط لمنع أي سلوك افتراضي للمتصفح
// أو مستمع أعلى الشجرة من تحويل الضغط إلى تنقل/إعادة تحميل للصفحة.
widgetGrid.addEventListener("submit",e=>{e.preventDefault();e.stopPropagation();},true);
widgetGrid.addEventListener("click",async e=>{
 const btn=e.target.closest("[data-control-id]");if(!btn)return;
 e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();
 const id=btn.dataset.controlId,w=(projects.find(p=>p.id===activeProjectId)?.widgets||[]).find(x=>x.id===id);
 if(!w||w.type!=="button"||w.buttonMode==="push")return;
 const on=!w.buttonState;w.buttonState=on;save();updateCard(w);
 const url=API_ROOT+encodeURIComponent(tokenFromWidget(w))+"/update/V"+w.virtualNumber+"?value="+(on?"1":"0");
 try{await fetch(url,{method:"GET",mode:"no-cors",cache:"no-store",keepalive:true})}catch(err){showToast("تعذر إرسال الأمر؛ تحقق من الاتصال");}
},{capture:true});
widgetGrid.addEventListener("pointerdown",e=>{const btn=e.target.closest("[data-control-id]");if(!btn||e.button!==0)return;const w=(projects.find(p=>p.id===activeProjectId)?.widgets||[]).find(x=>x.id===btn.dataset.controlId);if(!w||w.buttonMode!=="push"||activePushId)return;e.preventDefault();e.stopPropagation();activePushId=w.id;activePushButton=btn;btn.textContent=w.onLabel||"ON";btn.style.background=w.onColor||"#25c28a";btn.style.fontSize=Math.max(10,Math.min(48,Number(w.onFontSize)||35))+"px";btn.setAttribute("aria-pressed","true");const url=API_ROOT+encodeURIComponent(tokenFromWidget(w))+"/update/V"+w.virtualNumber+"?value=1";fetch(url,{method:"GET",mode:"no-cors",cache:"no-store",keepalive:true}).catch(()=>showToast("تعذر إرسال أمر ON"));});
function finishPush(){if(!activePushId)return;const id=activePushId,btn=activePushButton;activePushId=null;activePushButton=null;const w=(projects.find(p=>p.id===activeProjectId)?.widgets||[]).find(x=>x.id===id);if(btn&&w){btn.textContent=w.offLabel||"OFF";btn.style.background=w.offColor||"#596579";btn.style.fontSize=Math.max(10,Math.min(48,Number(w.offFontSize)||35))+"px";btn.setAttribute("aria-pressed","false");}if(!w)return;const url=API_ROOT+encodeURIComponent(tokenFromWidget(w))+"/update/V"+w.virtualNumber+"?value=0";fetch(url,{method:"GET",mode:"no-cors",cache:"no-store",keepalive:true}).catch(()=>showToast("تعذر إرسال أمر OFF"));}
widgetGrid.addEventListener("pointerup",finishPush);widgetGrid.addEventListener("pointercancel",finishPush);window.addEventListener("pointerup",finishPush);window.addEventListener("blur",finishPush);
function extractValue(data){
 if(Array.isArray(data))return data.length?data[0]:"—";
 if(data&&typeof data==="object"){for(const k of ["value","data","result","V23","v","reading"])if(k in data){const v=data[k];if(Array.isArray(v))return v[0]??"—";if(v&&typeof v==="object")continue;return v??"—"}}
 return data===null||data===undefined?"—":data;
}
function formatValue(value,precision){
 if(typeof value==="number"&&Number.isFinite(value))return value.toFixed(Math.max(0,Math.min(10,precision)));
 if(typeof value==="string"&&value.trim()!==""&&Number.isFinite(Number(value))){return Number(value).toFixed(Math.max(0,Math.min(10,precision)))}
 return String(value);
}
function parseConnection(data){
 if(typeof data==="boolean")return data;
 if(typeof data==="string"){const s=data.trim().toLowerCase();if(["true","1","online","connected","متصل"].includes(s))return true;if(["false","0","offline","disconnected","غير متصل"].includes(s))return false;try{return parseConnection(JSON.parse(s))}catch(e){return null}}
 if(data&&typeof data==="object"){for(const k of ["connected","online","status","isOnline","is_connected","device_status"])if(k in data){const v=data[k];if(typeof v==="boolean")return v;if(typeof v==="string"||typeof v==="number")return parseConnection(String(v))}}
 return null;
}
async function fetchJson(url){const r=await fetch(url,{cache:"no-store"});if(!r.ok)throw new Error("HTTP "+r.status);return r.json()}
function updateCard(w){
 const el=document.getElementById("val-"+w.id),upd=document.getElementById("upd-"+w.id),conn=document.getElementById("conn-"+w.id),card=document.querySelector(`[data-widget-id="${CSS.escape(w.id)}"]`);
 if(el){el.textContent=w.value??"—";el.style.fontSize=Math.max(12,Math.min(48,Number(w.valueFontSize)||24))+"px";}
 const numericInput=document.querySelector(`[data-numeric-value="${CSS.escape(w.id)}"]`);
 if(numericInput&&document.activeElement!==numericInput&&Number.isFinite(Number(w.value)))numericInput.value=Number(w.value).toFixed(Math.max(0,Math.min(6,Number(w.precision)||0)));
 const textInput=document.querySelector(`[data-text-input="${CSS.escape(w.id)}"]`);
 if(textInput&&document.activeElement!==textInput&&String(textInput.value)!==String(w.value??""))textInput.value=String(w.value??"").slice(0,Math.max(1,Math.min(512,Number(w.maxLength)||120)));
 if(w.type==="terminal")refreshTerminalScreen(w);
 if(["gauge","donutGauge","donutGaugeAlt","waterRing","temperatureDial"].includes(w.type)){
  const min=Number(w.minValue??0),max=Number(w.maxValue??100),v=Number(w.value),pct=Number.isFinite(v)&&max>min?Math.max(0,Math.min(1,(v-min)/(max-min))):0;
  if(w.type==="waterRing"){
   const y=(100-pct*100).toFixed(2),fill=document.getElementById("water-fill-"+w.id),wave=document.getElementById("water-wave-"+w.id),waveBack=document.getElementById("water-wave-back-"+w.id),label=document.getElementById("water-percent-"+w.id);
   if(fill)fill.setAttribute("y",y);if(wave)wave.setAttribute("d",`M5 ${y} Q25 ${Number(y)-4} 45 ${y} T85 ${y} T125 ${y} V100 H5Z`);if(waveBack)waveBack.setAttribute("d",`M5 ${y} Q25 ${Number(y)-3} 45 ${y} T85 ${y} T125 ${y} V100 H5Z`);if(label)label.textContent=Math.round(pct*100)+"%";
  }else if(w.type==="temperatureDial"){
   const reading=document.getElementById("gauge-val-"+w.id),state=document.getElementById("thermal-state-"+w.id),marker=document.getElementById("thermal-marker-"+w.id),safePct=Math.max(0,Math.min(1,pct)),card=document.querySelector(`[data-widget-id="${CSS.escape(w.id)}"]`);
   const shownTemp=(Number.isFinite(Number(w.value))?Number(w.value):min).toFixed(Math.max(0,Math.min(3,Number(w.precision)||0)));
   if(reading)reading.textContent=shownTemp;
   if(card)card.style.setProperty("--thermal-value-scale",Math.min(1,6.4/Math.max(1,shownTemp.length)).toFixed(2));
   if(state)state.textContent=safePct<.28?"باردة":safePct<.68?"معتدلة":"مرتفعة";
   if(marker)marker.style.top=(100-safePct*100).toFixed(2)+"%";if(card)card.style.setProperty("--thermal-pct",(safePct*100).toFixed(2)+"%");
  }else{
  const reading=document.getElementById("gauge-val-"+w.id),progress=document.querySelector(`[data-widget-id="${CSS.escape(w.id)}"] .gauge-progress`);
  if(reading)reading.textContent=(Number.isFinite(Number(w.value))?Number(w.value):Number(w.minValue??0)).toFixed(Math.max(0,Math.min(3,Number(w.precision)||0)));
  if(progress){const min=Number(w.minValue??0),max=Number(w.maxValue??100),v=Number(w.value),pct=Number.isFinite(v)&&max>min?Math.max(0,Math.min(1,(v-min)/(max-min))):0;const donut=w.type==="donutGauge"||w.type==="donutGaugeAlt";progress.setAttribute("stroke-dasharray",`${(pct*(donut?100:75)).toFixed(2)} 100`);progress.style.stroke=gaugeColorFor(w,pct);const card=document.querySelector(`[data-widget-id="${CSS.escape(w.id)}"]`);if(card){if(donut)card.style.setProperty("--donut-progress",`${(pct*100).toFixed(2)}`);card.style.setProperty("--gauge-size",`${Math.max(12,Math.min(46,Number(w.gaugeFontSize)||24))}px`);const unit=card.querySelector(".gauge-unit");if(unit)unit.style.fontSize=`clamp(12px,calc(var(--gauge-size,30px)*var(--grid-scale,1)),46px)`;}}  }
 }
 const control=document.querySelector(`[data-control-id="${CSS.escape(w.id)}"]`);
 if(control&&w.type==="button"&&!(w.buttonMode==="push"&&activePushId===w.id)){
  const on=!!w.buttonState;control.textContent=on?(w.onLabel||"ON"):(w.offLabel||"OFF");
  control.style.background=on?(w.onColor||"#25c28a"):(w.offColor||"#596579");
  control.style.fontSize=Math.max(10,Math.min(48,Number(on?w.onFontSize:w.offFontSize)||35))+"px";
  control.setAttribute("aria-pressed",String(on));
 }
 if(upd)upd.textContent=w.updated||"";
 if(card)card.style.setProperty("--c",widgetStatusColor(w));const ledDot=document.getElementById("led-"+w.id);if(ledDot){ledDot.style.setProperty("--led-c",w.ledState===true?"#22c55e":w.ledState===false?"#ef4444":"#64748b");ledDot.title=w.ledState===true?"LED ON":w.ledState===false?"LED OFF":"LED status unknown";}
 if(conn){conn.className="connection "+(w.connected===true?"online":"offline");conn.textContent=w.connected===true?"متصل":w.connected===false?"غير متصل":"الحالة غير معروفة";}
}
function extractRemoteControlValue(data){
 const raw=extractValue(data);
 return raw;
}
function parseRemoteButtonState(data){
 const raw=extractRemoteControlValue(data);
 if(typeof raw==="boolean")return raw;
 const normalized=String(raw??"").trim().toLowerCase();
 if(["1","true","on","high","yes"].includes(normalized))return true;
 if(["0","false","off","low","no"].includes(normalized))return false;
 return null;
}
function parseValueLedState(data){
 const raw=extractRemoteControlValue(data);
 const numeric=typeof raw==="number"?raw:(String(raw??"").trim()===""?NaN:Number(String(raw).trim()));
 if(numeric===255)return true;
 if(numeric===0)return false;
 return null;
}
async function refreshOne(w){
 try{
  const data=await fetchJson(valueUrlFor(w)),remote=extractRemoteControlValue(data);
  if(w.type==="button"){
   const state=parseRemoteButtonState(data);
   if(state!==null)w.buttonState=state;
  }else if(w.type==="numericInput"){
   const numeric=Number(remote);
   if(remote!==null&&remote!==undefined&&remote!==""&&Number.isFinite(numeric))w.value=numeric;
  }else if(w.type==="textInput"){
   if(remote!==null&&remote!==undefined)w.value=String(remote).slice(0,Math.max(1,Math.min(512,Number(w.maxLength)||120)));
  }else if(w.type==="terminal"){
   const fullTerminalText=terminalPayloadText(data);
   if(fullTerminalText!==null){w.terminalText=fullTerminalText;w.lastRemoteValue=fullTerminalText;}
  }else if(["gauge","donutGauge","donutGaugeAlt","waterRing","temperatureDial"].includes(w.type)){
   const numeric=Number(remote);if(remote!==null&&remote!==undefined&&remote!==""&&Number.isFinite(numeric))w.value=Math.max(Number(w.minValue??0),Math.min(Number(w.maxValue??100),numeric));
  }else{
   w.value=formatValue(remote,Number(w.precision??1));
   if(w.ledIndicatorEnabled){try{const ledPin=Math.max(0,Math.min(999,parseInt(w.ledVirtualNumber??0,10)||0));const ledData=await fetchJson(API_ROOT+encodeURIComponent(tokenFromWidget(w))+"/get/V"+ledPin);w.ledState=parseValueLedState(ledData);}catch(e){w.ledState=null;}}else{w.ledState=null;}
  }
  w.readError=false;
 }catch(e){
  w.readError=true;
  // احتفظ بآخر قراءة سليمة عند فشل طلب مؤقت؛ لا تستبدل قيمة Gauge/Temperature برسالة خطأ فتومض الواجهة.
  // تبقى القراءة السابقة ظاهرة إلى أن تصل قراءة صحيحة جديدة.
 }
 if(tokenFromWidget(w)&&! ["terminal","numericInput","textInput"].includes(w.type)){
  try{w.connected=parseConnection(await fetchJson(statusUrlFor(w)))}catch(e){w.connected=false;}
 }
 w.updated=new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit",second:"2-digit"});
 save();updateCard(w);
}
function scheduleWidget(w,delay,projectId=activeProjectId){
 if(document.hidden||!projectId||activeProjectId!==projectId)return;
 refreshTimers[w.id]=setTimeout(async()=>{
  if(activeProjectId!==projectId||document.hidden)return;
  const p=projects.find(x=>x.id===projectId);const current=p?.widgets?.find(x=>x.id===w.id);if(!current)return;
  await refreshOne(current);
  const nextDelay=(current.type==="button"||current.type==="numericInput"||current.type==="textInput"||current.type==="terminal")?5000:Math.max(2,Number(current.interval)||5)*1000;
  if(activeProjectId===projectId)scheduleWidget(current,nextDelay,projectId);
 },delay);
}
document.addEventListener("visibilitychange",()=>{
 if(document.hidden){stopTimers();return;}
 if(!activeProjectId)return;
 const p=projects.find(x=>x.id===activeProjectId);if(!p)return;
 (p.widgets||[]).forEach((w,index)=>{clearTimeout(refreshTimers[w.id]);scheduleWidget(w,index*100,activeProjectId);});
});
// إيقاف أي تحديثات مجدولة فور مغادرة التطبيق أو إخفاء الصفحة.
window.addEventListener("pagehide",stopTimers);
render();
// يبدأ الفحص بعد عرض الواجهة، وفقط عندما تكون الصفحة ظاهرة للمستخدم.
setTimeout(()=>{if(!document.hidden)checkRemoteBackup(false);},900);
// تسجيل Service Worker عند الاستضافة عبر HTTPS فقط؛ لا يتدخل في APK/WebView أو file://.
if(location.protocol==="https:" && "serviceWorker" in navigator){
 window.addEventListener("load",()=>navigator.serviceWorker.register("./service-worker.js").catch(()=>{}));
}

