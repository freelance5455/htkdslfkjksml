/* Ultra Tech PWA shell cache. API requests and live device data are never cached. */
const CACHE_NAME = "ultra-tech-shell-v19-server-first";
const APP_SHELL = [
  "./assets/ultratech-logo.jpg",
  "./qr-vendor.js",
  "./manifest.webmanifest",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon-512-maskable.png",
  "./icons/apple-touch-icon.png"
];

self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith("ultra-tech-shell-") && key !== CACHE_NAME).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  // Never serve an offline dashboard or cached design. Authentication and
  // project state require the server; the browser displays its network error.
  if (request.mode === "navigate" || url.pathname.endsWith("/index.html")) {
    event.respondWith(fetch(request));
    return;
  }

  // Cache only the static app shell. Never cache Blynk/device API responses.
  const path = url.pathname;
  if (/\/(manifest\.webmanifest|service-worker\.js|icons\/[^/]+\.png|assets\/[^/]+\.jpg)$/.test(path)) {
    event.respondWith(caches.match(request).then(cached => cached || fetch(request).then(response => {
      if (response && response.ok) caches.open(CACHE_NAME).then(cache => cache.put(request, response.clone()));
      return response;
    })));
  }
});
