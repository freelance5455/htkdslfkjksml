SALÓN ROSE — PROTOTIPO FUNCIONAL DE AGENDA OFFLINE

Incluye:
- Agenda diaria de citas
- Crear, editar y cancelar citas
- Clientes derivados de las citas registradas
- Servicios personalizables
- Advertencia ante citas a la misma hora
- Exportar e importar copias de seguridad
- Interfaz rosa, blanca y dorada

IMPORTANTE:
Este proyecto es una aplicación web local, NO es todavía un APK compilado.
Para probarlo, abre index.html en un navegador moderno. Los datos se guardan en el almacenamiento local de ese navegador y no se sincronizan entre dispositivos. Si se borran los datos del navegador, podrían perderse; usa la copia de seguridad.

Para crear un APK real hace falta empaquetar este proyecto con Android Studio/Capacitor y compilarlo en un entorno con las herramientas de Android instaladas. La versión actual no ha sido compilada ni verificada como APK.
