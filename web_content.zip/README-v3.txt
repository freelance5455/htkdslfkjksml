Personal OS 3.0.0 (versionCode 3) — upgrade notes
1. Open this project in Android Studio / your builder and build as before (same applicationId + same signing key as your installed 2.0.0, otherwise Android will refuse to update and you could lose data).
2. INSTALL OVER the existing app (do not uninstall). Your data lives in the WebView's IndexedDB and is migrated automatically on first open.
3. BEFORE updating: if you can, keep a screenshot/notes of anything critical (v2.0 had no backup feature). After updating, go to More > Settings > Export file right away.
4. Backups are saved to Downloads/ (Android 10+ needs no permission).
Changed files: app/build.gradle, AndroidManifest.xml, MainActivity.java, assets/index.html
