Futbol 11x11 (oflayn)
1) Zipni oching (extract).
2) index.html faylini brauzerda (Chrome/Safari) oching. Internet kerak emas.
3) Telefonda: faylni "Fayllar"dan Chrome bilan oching yoki "Bosh ekranga qo'shish" qiling.
O'yin avtomatik saqlanadi.
