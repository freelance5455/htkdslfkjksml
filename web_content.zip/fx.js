/* Learnova Creator Studio — motion & interaction layer */
(function(){
"use strict";
const reduce=matchMedia("(prefers-reduced-motion: reduce)").matches;

/* 1. Scroll progress bar */
const bar=document.createElement("div");bar.id="fxProgress";document.body.appendChild(bar);
let tick=false;
function prog(){tick=false;const h=document.documentElement.scrollHeight-innerHeight;bar.style.transform="scaleX("+(h>0?Math.min(1,scrollY/h):0)+")";}
addEventListener("scroll",()=>{if(!tick){tick=true;requestAnimationFrame(prog);}},{passive:true});prog();

/* 2. Ripple on buttons */
document.addEventListener("pointerdown",e=>{
  if(reduce)return;
  const t=e.target.closest(".primary-btn,.secondary-btn,.danger-btn,.ai-btn,.ghost-btn,.icon-btn,.bnav a,.tab");
  if(!t||t.disabled)return;
  const r=t.getBoundingClientRect(),s=Math.max(r.width,r.height)*2.2,d=document.createElement("span");
  d.className="fx-ripple";d.style.width=d.style.height=s+"px";d.style.left=(e.clientX-r.left-s/2)+"px";d.style.top=(e.clientY-r.top-s/2)+"px";
  t.appendChild(d);setTimeout(()=>d.remove(),650);
},{passive:true});

/* 3. Smooth page transitions */
document.addEventListener("click",e=>{
  if(e.defaultPrevented||e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey)return;
  const a=e.target.closest("a[href]");if(!a||a.target||a.hasAttribute("download"))return;
  const h=a.getAttribute("href");if(!h||h[0]==="#"||/^(mailto:|tel:|javascript:)/i.test(h))return;
  let u;try{u=new URL(a.href,location.href);}catch(x){return;}
  if(u.origin!==location.origin&&location.protocol!=="file:")return;
  if(u.pathname===location.pathname&&u.search===location.search)return;
  if(reduce)return;
  e.preventDefault();document.body.classList.add("fx-leave");setTimeout(()=>{location.href=a.href;},170);
});
addEventListener("pageshow",()=>document.body.classList.remove("fx-leave"));

/* 4. Smooth dark/light theme switch */
document.addEventListener("click",e=>{
  if(e.target.closest("#themeBtn")){document.body.classList.add("fx-theming");setTimeout(()=>document.body.classList.remove("fx-theming"),500);}
},true);

/* 5. Count-up numbers for dashboard metrics */
function countUp(el){
  const n=parseInt(el.textContent,10);if(isNaN(n)||n<=0||el._last===n)return;
  el._last=n;if(reduce)return;el._fx=true;
  const t0=performance.now(),dur=Math.min(1100,350+n*40);
  (function step(t){
    const k=Math.min(1,(t-t0)/dur),e=1-Math.pow(1-k,3);
    el.textContent=Math.round(n*e);
    if(k<1)requestAnimationFrame(step);else{el.textContent=n;el._fx=false;}
  })(t0);
}
["totalMetric","productionMetric","scheduledMetric","publishedMetric"].forEach(id=>{
  const el=document.getElementById(id);if(!el)return;
  countUp(el);
  new MutationObserver(()=>{if(!el._fx)countUp(el);}).observe(el,{childList:true,characterData:true,subtree:true});
});

/* 6. Assistant composer: auto-grow, Enter to send (desktop), Shift+Enter = new line */
const ta=document.getElementById("assistantInput");
if(ta){
  const grow=()=>{ta.style.height="auto";ta.style.height=Math.min(ta.scrollHeight,180)+"px";};
  ta.addEventListener("input",grow);
  new MutationObserver(grow).observe(ta,{attributes:true});
  const f=document.getElementById("assistantForm");
  ta.addEventListener("keydown",e=>{
    if(e.key==="Enter"&&!e.shiftKey&&!e.isComposing&&matchMedia("(hover:hover) and (pointer:fine)").matches){e.preventDefault();if(ta.value.trim()&&f.requestSubmit)f.requestSubmit();}
  });
  f&&f.addEventListener("submit",()=>setTimeout(grow,0));
}
})();
