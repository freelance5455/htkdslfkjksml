/* JOSTECH — CHAPITRE COMPLET FORMAT LIVRE : PROG-2-1-1 */
registerLessonDetail(2, 2, "prog-2-1-1", {
  title: "Leçon 1 : Mémoire RAM, Pointeurs et Allocation Dynamique en C",
  duration: "50 min (Manuel universitaire complet)",
  objectives: [
    "Comprendre la cartographie complète de la mémoire d'un processus (Code, Pile, Tas).",
    "Maîtriser les opérateurs & (adresse de) et * (déréférencement) en Langage C.",
    "Distinguer le passage par valeur du passage par adresse dans les fonctions.",
    "Comprendre l'équivalence entre tableaux et arithmétique des pointeurs.",
    "Allouer et libérer proprement la mémoire dynamique avec malloc() et free()."
  ],
  prerequisites: ["Niveau 1 de Programmation et notions de RAM / hexadécimal."],
  sections: [
    {
      type: "theory",
      title: "1. Pourquoi le Langage C est-il le pilier des systèmes ?",
      text: "Créé en 1972 par Dennis Ritchie aux laboratoires Bell pour écrire le système UNIX, le langage C reste aujourd'hui incontournable à l'université. Le noyau Linux, Windows, macOS, les bases de données (MySQL, PostgreSQL) et l'interpréteur Python lui-même sont écrits en C.\n\nContrairement à Python ou JavaScript qui cachent la gestion de la RAM derrière un ramasse-miettes automatique (Garbage Collector), le langage C offre un accès direct aux adresses mémoire physiques : c'est ce qui explique sa vitesse exceptionnelle, mais aussi la rigueur qu'il exige."
    },
    {
      type: "definition",
      term: "Adresse mémoire et Pointeur (* et &)",
      text: "Imaginez la mémoire RAM comme une immense rue où chaque octet est une maison numérotée en hexadécimal (ex: 0x1000, 0x1001, 0x1002...). Lorsque vous déclarez « int age = 22; », le compilateur réserve 4 octets consécutifs (sur architecture 32/64 bits) à une adresse précise, disons 0x7ffc04.\n\nUn pointeur est tout simplement une variable spéciale qui stocke cette adresse (0x7ffc04) au lieu de stocker l'entier 22.\n• L'opérateur unaire & (« adresse de ») : &age vaut 0x7ffc04.\n• Déclaration d'un pointeur : int *p = &age; (p pointe vers l'entier age).\n• L'opérateur * (« contenu pointé par » ou déréférencement) : *p lit ou modifie directement la valeur située à l'adresse contenue dans p (donc *p vaut 22)."
    },
    {
      type: "table",
      title: "2. Cartographie de la mémoire d'un programme C",
      headers: ["Segment RAM", "Contenu stocké", "Gestion & Durée de vie"],
      rows: [
        ["Text / Code", "Instructions binaires du programme compilé.", "Lecture seule, toute la durée d'exécution."],
        ["Data / BSS", "Variables globales et statiques.", "Toute la durée d'exécution."],
        ["Pile (Stack)", "Variables locales et paramètres des fonctions.", "Automatique (LIFO), rapide, taille limitée (~quelques Mo)."],
        ["Tas (Heap)", "Blocs dynamiques demandés par malloc() / calloc().", "Manuelle par le développeur (free), grande capacité."]
      ]
    },
    {
      type: "theory",
      title: "3. Passage par valeur vs Passage par adresse & Arithmétique des pointeurs",
      text: "En C, lorsqu'on appelle f(x), la fonction reçoit uniquement une COPIE de x sur la Pile : modifier ce paramètre dans f() ne change rien à la variable x d'origine. Pour qu'une fonction modifie réellement des variables extérieures (ou renvoie plusieurs résultats), on lui transmet leurs adresses : f(&x).\n\nAutre secret fondamental du C : le nom d'un tableau (tab) est en réalité un pointeur constant vers son tout premier élément (&tab[0]) ! Ainsi, écrire tab[i] est rigoureusement traduit par le compilateur en *(tab + i). Si un int occupe 4 octets et que tab démarre à 0x1000, alors tab + 1 pointe automatiquement à 0x1004, et tab + 2 à 0x1008 !"
    },
    {
      type: "code",
      lang: "Langage C — Pointeurs, Échange et Allocation Dynamique",
      code: [
        "#include <stdio.h>",
        "#include <stdlib.h>",
        "",
        "void echanger(int *a, int *b) {",
        "    int temp = *a;",
        "    *a = *b;",
        "    *b = temp;",
        "}",
        "",
        "int main() {",
        "    int x = 10, y = 20;",
        "    echanger(&x, &y); // Passage par adresse",
        "    printf(\"x=%d, y=%d\\n\", x, y); // Affiche x=20, y=10",
        "",
        "    // Allocation dynamique sur le Tas pour 5 notes :",
        "    int *notes = (int *) malloc(5 * sizeof(int));",
        "    if (notes == NULL) return 1; // Toujours vérifier l'échec !",
        "",
        "    notes[0] = 16; // Équivaut à *notes = 16",
        "    *(notes + 1) = 18;",
        "    printf(\"Note 1 : %d, Note 2 : %d\\n\", notes[0], notes[1]);",
        "",
        "    free(notes);   // Libère le Tas",
        "    notes = NULL;  // Évite un pointeur fou (Dangling pointer)",
        "    return 0;",
        "}"
      ].join("\n")
    },
    {
      type: "warning",
      title: "Les 4 bugs critiques à éviter absolument en Langage C",
      text: "1) Pointeur sauvage non initialisé : écrire « int *p; *p = 5; » écrit à une adresse aléatoire et provoque un crash immédiat (Segmentation Fault).\n2) Déréférencement NULL : toujours vérifier « if (p != NULL) » avant d'utiliser *p après un malloc().\n3) Fuite mémoire (Memory Leak) : allouer avec malloc() sans jamais appeler free() remplit la RAM jusqu'au blocage.\n4) Dangling Pointer (Use-After-Free) : réutiliser un pointeur après avoir fait free(p) — c'est l'une des failles de cybersécurité les plus exploitées !"
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Lecture d'état mémoire",
      question: "On exécute les lignes C suivantes :\nint a = 5, b = 12;\nint *p = &a;\n*p = *p + 3;\np = &b;\n*p = *p * 2;\nQue valent finalement a, b et *p ?",
      solution: "• p pointe sur a (5). « *p = *p + 3 » modifie a : a devient 8.\n• Ensuite « p = &b » déplace le pointeur vers b (12).\n• « *p = *p * 2 » modifie b : b devient 24.\nRésultat final : a = 8, b = 24, *p = 24."
    },
    {
      title: "Exercice 2 — Arithmétique des pointeurs",
      question: "Un tableau « int t[4] = {10, 20, 30, 40}; » commence à l'adresse 0x2000. Sachant que sizeof(int) = 4 octets :\n1) Quelle est l'adresse exacte de t[2] ?\n2) Que vaut *(t + 3) ?",
      solution: "1) t[2] se trouve à 0x2000 + (2 × 4) = 0x2008.\n2) *(t + 3) désigne t[3], donc la valeur 40."
    },
    {
      title: "Exercice 3 — Audit de sécurité mémoire",
      question: "Un développeur écrit une fonction qui alloue un tableau temporaire de 1000 entiers avec malloc(), fait un calcul, puis exécute « return resultat; » sans appeler free(). Quel problème survient si cette fonction est appelée 100 000 fois par un serveur Web ?",
      solution: "Chaque appel consomme 4 000 octets (~4 Ko) sur le Tas sans jamais les rendre. Après 100 000 appels, ~400 Mo de RAM sont perdus (Fuite mémoire / Memory Leak), finissant par faire planter le serveur (Out Of Memory)."
    }
  ],
  summary: "Les pointeurs stockent des adresses RAM (& pour obtenir l'adresse, * pour accéder à la valeur). Ils permettent le passage par adresse, l'accès rapide aux tableaux et la gestion manuelle du Tas (malloc/free), base de toute programmation système sécurisée.",
  references: [
    "Kernighan, B. & Ritchie, D. — Le Langage C (2e éd.), Dunod.",
    "Delannoy, C. — Programmer en langage C, Eyrolles."
  ]
});