BRAIN WORD CHALLENGE — ENHANCED MOBILE WEB GAME

Included:
- index.html, style.css, script.js
- Improved colourful mobile layout
- 100 distinct word entries
- Coins: +10 for a correct answer; hints cost 5 coins
- Automatically saves current level and coins in browser localStorage on the same device/browser

How to use on Android:
1. Extract the ZIP using your phone's Files app.
2. Open the folder in a code editor such as Acode.
3. If replacing your current game, replace all three files (index.html, style.css, script.js).
4. Preview index.html in the editor/browser.
5. Keep the same browser and do not clear site data if you want the saved progress to remain.

Important:
- This ZIP is a mobile-friendly web game, not an installable Android APK.
- To make a real APK, open the project in an Android packaging workflow such as Capacitor/Android Studio and build/sign it. The Play Store needs its own app signing, listing and policy steps.
- The provided 100 word entries include a few words of varying length; the tile layout adapts to word length.
