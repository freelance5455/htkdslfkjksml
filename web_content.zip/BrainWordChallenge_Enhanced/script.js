const wordBank = [
{word:"APPLE",clue:"A fruit that can be red or green",category:"FRUIT"},
{word:"TIGER",clue:"A big wild cat with stripes",category:"ANIMALS"},
{word:"HOUSE",clue:"A place where people live",category:"HOME"},
{word:"BREAD",clue:"Food often made from flour",category:"FOOD"},
{word:"PLANT",clue:"A living thing that grows in soil",category:"NATURE"},
{word:"WATER",clue:"You drink this every day",category:"NATURE"},
{word:"CHAIR",clue:"You sit on this",category:"HOME"},
{word:"MUSIC",clue:"You listen to songs and this",category:"ART"},
{word:"CLOUD",clue:"A white or grey thing in the sky",category:"NATURE"},
{word:"SMILE",clue:"A happy expression on your face",category:"PEOPLE"},
{word:"GRAPE",clue:"A small fruit that grows in bunches",category:"FRUIT"},
{word:"BEACH",clue:"A sandy place beside the sea",category:"NATURE"},
{word:"LIGHT",clue:"It helps you see in the dark",category:"EVERYDAY"},
{word:"TRAIN",clue:"A vehicle that runs on tracks",category:"TRAVEL"},
{word:"BRAIN",clue:"The organ you use to think",category:"BODY"},
{word:"SNAKE",clue:"A long reptile with no legs",category:"ANIMALS"},
{word:"LEMON",clue:"A yellow, sour fruit",category:"FRUIT"},
{word:"PLANE",clue:"A vehicle that flies in the sky",category:"TRAVEL"},
{word:"SHEEP",clue:"An animal that gives wool",category:"ANIMALS"},
{word:"GREEN",clue:"The colour of many leaves",category:"COLOURS"},
{word:"HORSE",clue:"An animal people can ride",category:"ANIMALS"},
{word:"MOUSE",clue:"A small animal or computer device",category:"ANIMALS"},
{word:"RIVER",clue:"A natural stream of flowing water",category:"NATURE"},
{word:"STONE",clue:"A small piece of rock",category:"NATURE"},
{word:"HEART",clue:"It pumps blood around your body",category:"BODY"},
{word:"CLOCK",clue:"It tells you the time",category:"EVERYDAY"},
{word:"SPOON",clue:"You use it to eat soup",category:"KITCHEN"},
{word:"GRASS",clue:"Green plants covering a lawn",category:"NATURE"},
{word:"QUEEN",clue:"A woman who rules a kingdom",category:"PEOPLE"},
{word:"NIGHT",clue:"The dark time after sunset",category:"TIME"},
{word:"BERRY",clue:"A small juicy fruit",category:"FRUIT"},
{word:"CANDY",clue:"A sweet treat",category:"FOOD"},
{word:"PIZZA",clue:"A round baked food with toppings",category:"FOOD"},
{word:"MANGO",clue:"A tropical fruit with a large seed",category:"FRUIT"},
{word:"PEACH",clue:"A soft fruit with fuzzy skin",category:"FRUIT"},
{word:"OLIVE",clue:"A small fruit used to make oil",category:"FOOD"},
{word:"SUGAR",clue:"A sweet ingredient",category:"FOOD"},
{word:"HONEY",clue:"Sweet food made by bees",category:"FOOD"},
{word:"TOMATO",clue:"A red fruit often used as a vegetable",category:"FOOD"},
{word:"CARROT",clue:"An orange vegetable",category:"FOOD"},
{word:"POTATO",clue:"A vegetable often used for fries",category:"FOOD"},
{word:"ONION",clue:"A vegetable that can make you cry",category:"FOOD"},
{word:"CHERRY",clue:"A small red fruit with a pit",category:"FRUIT"},
{word:"ORANGE",clue:"A citrus fruit and a colour",category:"FRUIT"},
{word:"PURPLE",clue:"A colour made from red and blue",category:"COLOURS"},
{word:"YELLOW",clue:"The colour of the sun in drawings",category:"COLOURS"},
{word:"SILVER",clue:"A shiny grey metal",category:"MATERIALS"},
{word:"GOLDEN",clue:"Having the colour of gold",category:"COLOURS"},
{word:"WINTER",clue:"The coldest season in many places",category:"SEASONS"},
{word:"SUMMER",clue:"The hottest season in many places",category:"SEASONS"},
{word:"SPRING",clue:"The season when many flowers bloom",category:"SEASONS"},
{word:"AUTUMN",clue:"The season when many leaves fall",category:"SEASONS"},
{word:"MONDAY",clue:"The day after Sunday",category:"DAYS"},
{word:"FRIDAY",clue:"The day before Saturday",category:"DAYS"},
{word:"SUNDAY",clue:"A day at the end of the usual week",category:"DAYS"},
{word:"MARKET",clue:"A place where people buy and sell",category:"PLACES"},
{word:"SCHOOL",clue:"A place where students learn",category:"PLACES"},
{word:"GARDEN",clue:"A place where flowers and plants grow",category:"PLACES"},
{word:"CASTLE",clue:"A large fortified home of royalty",category:"PLACES"},
{word:"BRIDGE",clue:"A structure built over water or a road",category:"PLACES"},
{word:"TUNNEL",clue:"A passage under or through something",category:"PLACES"},
{word:"WINDOW",clue:"An opening in a wall with glass",category:"HOME"},
{word:"PILLOW",clue:"You rest your head on this in bed",category:"HOME"},
{word:"BLANKET",clue:"A warm cover for a bed",category:"HOME"},
{word:"MIRROR",clue:"You can see your reflection in this",category:"HOME"},
{word:"BOTTLE",clue:"A container for drinks",category:"EVERYDAY"},
{word:"BASKET",clue:"A container used to carry things",category:"EVERYDAY"},
{word:"POCKET",clue:"A small pouch in your clothes",category:"CLOTHING"},
{word:"JACKET",clue:"Outer clothing worn over a shirt",category:"CLOTHING"},
{word:"BUTTON",clue:"A small fastener on clothing",category:"CLOTHING"},
{word:"SHOES",clue:"You wear these on your feet",category:"CLOTHING"},
{word:"SOCKS",clue:"You wear these inside shoes",category:"CLOTHING"},
{word:"CAMERA",clue:"A device used to take photos",category:"TECH"},
{word:"SCREEN",clue:"The display on a phone or computer",category:"TECH"},
{word:"ROBOT",clue:"A machine that can do tasks",category:"TECH"},
{word:"ROCKET",clue:"A vehicle designed for space travel",category:"SPACE"},
{word:"PLANET",clue:"A large world that orbits a star",category:"SPACE"},
{word:"STAR",clue:"A bright ball of gas in space",category:"SPACE"},
{word:"MOON",clue:"Earth's natural satellite",category:"SPACE"},
{word:"EARTH",clue:"The planet where we live",category:"SPACE"},
{word:"OCEAN",clue:"A very large body of salt water",category:"NATURE"},
{word:"ISLAND",clue:"Land surrounded by water",category:"NATURE"},
{word:"FOREST",clue:"A large area covered with trees",category:"NATURE"},
{word:"DESERT",clue:"A very dry area with little rain",category:"NATURE"},
{word:"FLOWER",clue:"The colourful part of many plants",category:"NATURE"},
{word:"PENCIL",clue:"You write or draw with this",category:"SCHOOL"},
{word:"PAPER",clue:"A thin material used for writing",category:"SCHOOL"},
{word:"ERASER",clue:"You use this to remove pencil marks",category:"SCHOOL"},
{word:"RULER",clue:"A tool for measuring straight lines",category:"SCHOOL"},
{word:"POET",clue:"A person who writes poems",category:"PEOPLE"},
{word:"SINGER",clue:"A person who performs songs",category:"PEOPLE"},
{word:"DOCTOR",clue:"A person trained to treat illness",category:"JOBS"},
{word:"FARMER",clue:"A person who grows crops",category:"JOBS"},
{word:"BAKER",clue:"A person who makes bread and cakes",category:"JOBS"},
{word:"DRIVER",clue:"A person who drives a vehicle",category:"JOBS"},
{word:"FRIEND",clue:"A person you know and like",category:"PEOPLE"},
{word:"FAMILY",clue:"Parents, children and relatives",category:"PEOPLE"},
{word:"LAUGH",clue:"The sound you make when something is funny",category:"FEELINGS"},
{word:"HAPPY",clue:"Feeling joy",category:"FEELINGS"},
{word:"BRAVE",clue:"Ready to face danger or difficulty",category:"FEELINGS"},
{word:"QUICK",clue:"Fast; not slow",category:"WORDS"},
{word:"SMART",clue:"Clever and quick to learn",category:"WORDS"},
{word:"PEACE",clue:"A state without fighting or war",category:"WORDS"},
{word:"DREAM",clue:"Images or stories in your sleep",category:"WORDS"}
];
// exactly 100 distinct entries are provided above; normalize to first 100.
const levels = wordBank.slice(0,100);
let currentLevel = 0, coins = 20, selected = [], shuffled = [], solved = false;

const $ = id => document.getElementById(id);
function save() {
  try { localStorage.setItem("bwc_save_v2", JSON.stringify({currentLevel, coins})); } catch(e) {}
}
function loadSave() {
  try {
    const data = JSON.parse(localStorage.getItem("bwc_save_v2") || "null");
    if (data) {
      currentLevel = Math.min(99, Math.max(0, Number(data.currentLevel) || 0));
      coins = Math.max(0, Number(data.coins) || 0);
    }
  } catch(e) {}
}
function shuffleWord(word) {
  let arr = word.split("");
  for (let i=arr.length-1;i>0;i--) { const j=Math.floor(Math.random()*(i+1)); [arr[i],arr[j]]=[arr[j],arr[i]]; }
  if (arr.join("") === word && arr.length > 1) arr.push(arr.shift());
  return arr;
}
function render() {
  const item = levels[currentLevel];
  selected=[]; solved=false; shuffled=shuffleWord(item.word);
  $("level").textContent = `${currentLevel+1}/100`;
  $("coins").textContent = coins;
  $("progress").textContent = `${currentLevel}%`;
  $("completed").textContent = currentLevel;
  $("clue").textContent = item.clue;
  $("category").textContent = item.category;
  $("message").textContent = "Choose the letters to begin!";
  $("nextBtn").classList.add("hidden");
  $("checkBtn").disabled=false; $("hintBtn").disabled=false;
  drawAnswer(); drawLetters(); save();
}
function drawAnswer() {
  $("answer").innerHTML="";
  levels[currentLevel].word.split("").forEach((_,i)=>{
    const slot=document.createElement("button");
    slot.className="slot"+(selected[i]?" filled":"");
    slot.textContent=selected[i]?selected[i].letter:"";
    slot.setAttribute("aria-label", selected[i] ? "Remove letter "+selected[i].letter : "Empty slot");
    slot.onclick=()=>{ if(solved||!selected[i])return; selected.splice(i,1); drawAnswer(); drawLetters(); };
    $("answer").appendChild(slot);
  });
}
function drawLetters() {
  $("letters").innerHTML="";
  shuffled.forEach((letter,index)=>{
    const b=document.createElement("button"); b.className="letter"; b.textContent=letter;
    b.disabled=solved||selected.some(x=>x.index===index);
    b.onclick=()=>{if(solved||selected.length>=levels[currentLevel].word.length)return;selected.push({letter,index});drawAnswer();drawLetters();};
    $("letters").appendChild(b);
  });
}
$("checkBtn").onclick=()=>{
  if(solved)return;
  const answer=selected.map(x=>x.letter).join("");
  if(answer.length!==levels[currentLevel].word.length){$("message").textContent="Select all letters first!";return;}
  if(answer===levels[currentLevel].word){
    solved=true; coins+=10; $("coins").textContent=coins;
    $("message").textContent="🎉 Correct! +10 coins earned!";
    $("checkBtn").disabled=true; $("hintBtn").disabled=true; $("nextBtn").classList.remove("hidden");
    drawLetters(); save();
  } else $("message").textContent="Not quite! Try another order.";
};
$("clearBtn").onclick=()=>{if(solved)return;selected=[];$("message").textContent="Letters cleared. Try again!";drawAnswer();drawLetters();};
$("hintBtn").onclick=()=>{
  if(solved)return;
  if(coins<5){$("message").textContent="You need 5 coins to use a hint.";return;}
  coins-=5; $("coins").textContent=coins;
  const target=levels[currentLevel].word; selected=[];
  target.split("").forEach(ch=>{const idx=shuffled.findIndex((x,i)=>x===ch&&!selected.some(s=>s.index===i));selected.push({letter:ch,index:idx});});
  $("message").textContent="Hint filled the answer. Tap Check!";
  drawAnswer();drawLetters();save();
};
$("nextBtn").onclick=()=>{
  if(currentLevel<99){currentLevel++;render();}
  else {$("message").textContent="🏆 Amazing! You completed all 100 levels!";$("nextBtn").classList.add("hidden");save();}
};
$("resetBtn").onclick=()=>{
  if(confirm("Reset all saved levels and coins?")){currentLevel=0;coins=20;save();render();}
};
loadSave(); render();
