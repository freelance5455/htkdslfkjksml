# Medemer Grand Strategy 2025 – 2050 — Android APK Build Guide

This Android project packages the **complete, 115-page Amharic & Bilingual Consolidated HTML5 edition** (`app/src/main/assets/medemer_grand_strategy.html`) inside a native Kotlin `WebViewAssetLoader` shell so the full strategy works **100% offline** on Android 7.0+ (API 24–35) without requiring network access.

## Prerequisites
- Android Studio Ladybug+ or Android SDK Platform 35 + Build-Tools 35.0.0
- JDK 17 (`JAVA_HOME` configured)

## Build Commands

### 1. Debug APK
```bash
cd android-apk
gradle wrapper --gradle-version 8.10.2   # if gradlew is not yet initialized
./gradlew assembleDebug
```
Output APK: `app/build/outputs/apk/debug/app-debug.apk`

### 2. Signed Release APK / AAB
1. Generate an upload keystore:
   ```bash
   keytool -genkey -v -keystore release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias medemer
   ```
2. Configure `signingConfigs` in `app/build.gradle.kts` (via environment variables—never commit passwords).
3. Run:
   ```bash
   ./gradlew assembleRelease
   ```
   Output APK: `app/build/outputs/apk/release/app-release.apk`
