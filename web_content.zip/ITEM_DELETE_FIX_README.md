# Item Delete Fix

This build fixes item deletion in the Android WebView by replacing browser confirm() dialogs with an in-app confirmation modal.

Active list: Delete moves an item to the Recycle Bin using an UPDATE on public.items.
Recycle Bin: Delete permanently removes the item using DELETE on public.items.

Supabase requirements:
- Admins must have UPDATE permission on public.items for the recycle-bin action.
- Admins must have DELETE permission on public.items for permanent deletion.
The supplied schema already defines both policies for public.is_admin().
