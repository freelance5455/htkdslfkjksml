Gold Precision 75 — مشروع Android لتحويل نسخة HTML إلى APK
الإصدار المضمّن: v7.5 Signal Recovery

مهم: هذا ZIP هو مشروع مصدر Android، وليس ملف APK جاهزًا. يلزم Android Studio وAndroid SDK لبناء APK.

خطوات البناء:
1) فك ضغط الملف على كمبيوتر.
2) افتح Android Studio ثم Open واختر مجلد Gold-Precision-75-Android-Project.
3) وافق على تنزيل Gradle/Android SDK عند الطلب، وانتظر اكتمال Gradle Sync.
4) من Build اختر Build APK(s).
5) غالبًا تجد APK التجريبي في app/build/outputs/apk/debug/app-debug.apk.

ملاحظات:
- التطبيق يفتح واجهة HTML محليًا ويحتاج اتصال إنترنت لجلب بيانات Biquote.
- إشعارات الخلفية المضمونة بعد إغلاق التطبيق غير مضافة هنا؛ تحتاج خدمة Push/خادم أو تطوير Android إضافي. أذونات الإشعارات وحدها لا تجعل الفحص يعمل بالخلفية.
- لا تحذف بيانات المتصفح أو النسخ القديمة قبل التأكد من نقل سجلاتك؛ بيانات HTML القديمة قد لا تنتقل تلقائيًا إلى مساحة التطبيق الجديد.
- لا تعتمد على نتائج الباك تست قبل التأكد من اكتمال بيانات التاريخ المطلوبة.

بناء APK دون كمبيوتر (باستخدام GitHub Actions من الهاتف):
1) أنشئ مستودعًا جديدًا على GitHub وارفع محتويات هذا المجلد إليه (وليس ملف ZIP نفسه).
2) افتح تبويب Actions في المستودع، ثم اختر Build Gold Precision 75 APK واضغط Run workflow.
3) انتظر حتى ينتهي التشغيل بنجاح.
4) افتح تشغيل workflow الناجح، ثم نزّل Artifact باسم Gold-Precision-75-v7.5-debug-apk.
5) فك ضغط الـ Artifact؛ ستجد app-debug.apk. قد يطلب Android السماح بالتثبيت من هذا المصدر.

هذا المسار يبني APK تجريبيًا موقّعًا بمفتاح debug، وليس نسخة متجر Google Play.
