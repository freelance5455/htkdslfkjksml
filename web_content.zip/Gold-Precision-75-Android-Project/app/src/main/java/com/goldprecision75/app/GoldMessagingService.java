package com.goldprecision75.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import androidx.core.app.NotificationCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

/**
 * خدمة استقبال إشعارات FCM مع صوت قوي + اهتزاز + ظهور على شاشة القفل.
 * تعمل حتى بعد إغلاق التطبيق (بشرط إرسال الرسالة من خادم Firebase).
 */
public class GoldMessagingService extends FirebaseMessagingService {

    private static final String CHANNEL_ID = "gold_signals_high";
    private static final String CHANNEL_NAME = "إشعارات إشارات التداول القوية";

    @Override
    public void onMessageReceived(RemoteMessage message) {
        String title = "Gold Precision 75 — إشارة جديدة";
        String body = "تم اكتشاف إشارة تداول حقيقية";

        if (message.getNotification() != null) {
            if (message.getNotification().getTitle() != null) {
                title = message.getNotification().getTitle();
            }
            if (message.getNotification().getBody() != null) {
                body = message.getNotification().getBody();
            }
        } else if (message.getData() != null) {
            if (message.getData().containsKey("title")) {
                title = message.getData().get("title");
            }
            if (message.getData().containsKey("body")) {
                body = message.getData().get("body");
            }
        }

        ensureChannel();
        showStrongNotification(title, body);
    }

    @Override
    public void onNewToken(String token) {
        // بعد نشر الخادم: أرسل الـ token إلى backend ليخزنه ويرسل الإشعارات لاحقاً
        // مثال: sendTokenToServer(token);
    }

    private void showStrongNotification(String title, String body) {
        // صوت إنذار قوي (أقوى من صوت الإشعار العادي)
        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);

        Intent openApp = new Intent(this, MainActivity.class);
        openApp.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }

        PendingIntent contentIntent = PendingIntent.getActivity(this, 75, openApp, flags);
        PendingIntent fullScreenIntent = PendingIntent.getActivity(this, 76, openApp, flags);

        // نمط اهتزاز قوي (زمور)
        long[] vibrationPattern = new long[]{0, 600, 200, 600, 200, 900, 300, 600};

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(getApplicationInfo().icon)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .setFullScreenIntent(fullScreenIntent, true)   // يظهر فوق شاشة القفل
                .setSound(soundUri)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setVibrate(vibrationPattern)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setLights(0xFF00FF00, 1000, 500);

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        int notificationId = (int) (System.currentTimeMillis() & 0x7fffffff);
        nm.notify(notificationId, builder.build());

        // اهتزاز إضافي مباشر (بعض الأجهزة تتجاهل الاهتزاز من الإشعار)
        try {
            Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createWaveform(vibrationPattern, -1));
                } else {
                    vibrator.vibrate(vibrationPattern, -1);
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void ensureChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return;
        }

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm.getNotificationChannel(CHANNEL_ID) != null) {
            return;
        }

        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
        );
        channel.setDescription("تنبيهات فورية مع صوت إنذار واهتزاز قوي عند كل إشارة تداول حقيقية");
        channel.enableVibration(true);
        channel.setVibrationPattern(new long[]{0, 600, 200, 600, 200, 900, 300, 600});
        channel.enableLights(true);
        channel.setLightColor(0xFF00FF00);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        channel.setBypassDnd(true); // محاولة تجاوز وضع عدم الإزعاج إن أمكن

        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        channel.setSound(soundUri, audioAttributes);

        nm.createNotificationChannel(channel);
    }
}
