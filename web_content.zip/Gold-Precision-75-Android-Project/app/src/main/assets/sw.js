const CACHE='gold-precision-75-android-v75';
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(['./index.html','./manifest.json']))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',event=>{ if(event.request.method==='GET' && new URL(event.request.url).origin===self.location.origin){event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request)));}});
