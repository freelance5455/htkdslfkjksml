ARSA AI HTML starter
1. Extract the ZIP.
2. Open index.html in Chrome to preview the app.
3. This is a browser-based starter, not an APK by itself.
4. To package it as an Android APK, wrap the web app with Capacitor (requires Node.js, Android Studio and Android SDK), or use the earlier Expo React Native project.
5. AI Studio is clearly marked demo-only until you connect a secure backend. Do not put private API keys in index.html.
