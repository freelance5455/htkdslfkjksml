STARFALL DEFENSE — 200-LEVEL CAMPAIGN (Music + New Look edition)

HOW TO PLAY
1. Extract this ZIP and open index.html in Chrome (or any modern browser, desktop or Android).
2. Pick a sector. Move with the ◀ ▶ pad (or drag, or arrow keys / A D). Hold FIRE (or Space) to shoot.
3. Tap AUTO FIRE to shoot hands-free.

WHAT'S NEW
- Background music: 4 original synthesized tracks, one per sector (Nebula Drift, Solar Ruins, Frost Nova, Void Emperor).
  Drums, bass, pads, arpeggios and a lead melody; the music gets more intense as you progress through a sector.
- Separate ♫ MUSIC and FX (sound effects) toggles. Your choice is remembered.
- Redesigned touch controller: glass D-pad, glowing FIRE orb with press feedback, AUTO FIRE toggle, vibration on hit.
- New theme: neon HUD with progress bar, sector-coloured menu cards, planets and drifting nebulas, twinkling stars,
  redesigned ship and enemies, level / mission banners.
- Auto-pauses when you switch tabs or apps.
- Fixed: Game Over → Mission Select (and Next Mission) no longer breaks the menu; fixed the "mission complete" text.

NOTES
- All audio is generated in the browser (no downloads, works offline). Browsers only allow sound after a tap/click, so music starts when you enter a sector.
- The revive timer is a demo simulation, not a real ad.
- Progress and best score are stored in the browser's local storage.
