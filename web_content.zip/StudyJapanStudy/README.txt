STUDY JAPAN STUDY — Android project

Project ini membungkus materi belajar bahasa Jepang ke dalam aplikasi Android sederhana berbasis WebView.

Untuk membuat APK:
1. Install Android Studio di komputer/laptop.
2. Ekstrak ZIP ini.
3. Buka folder StudyJapanStudy melalui Android Studio.
4. Tunggu Gradle Sync selesai (internet diperlukan untuk mengunduh komponen build).
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, klik Locate. APK biasanya ada di app/build/outputs/apk/debug/app-debug.apk.
7. Pindahkan APK ke HP Android dan buka untuk memasang. Jika diminta, izinkan pemasangan dari sumber tersebut.

Nama aplikasi: Study Japan Study
Application ID: com.studyjapanstudy.app

Catatan:
- Ini adalah source project Android Studio, bukan file APK yang sudah dikompilasi.
- Fitur belajar dan progres XP disimpan di penyimpanan lokal aplikasi.
- Timer berjalan ketika aplikasi terbuka. Pengingat saat aplikasi ditutup belum diimplementasikan sebagai alarm Android native.
