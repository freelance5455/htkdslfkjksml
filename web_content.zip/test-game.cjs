const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(require('path').join(__dirname,'index.html'),'utf8').split('<script>')[1].split('</script>')[0];
function make(){const elements=new Map();const noop=()=>{};const ctx=new Proxy({}, {get:(t,k)=>t[k]||noop,set:(t,k,v)=>(t[k]=v,true)});function element(id){if(!elements.has(id)){const e={id,style:{},dataset:{},value:'normal',hidden:true,classList:{add:noop,remove:noop,toggle:noop},getContext:()=>ctx,getBoundingClientRect:()=>({width:['aim','move'].includes(id)?90:800,height:['aim','move'].includes(id)?90:600,left:0,top:0}),addEventListener:noop,setPointerCapture:noop,setAttribute:noop,appendChild:noop,querySelector:()=>({style:{}}),insertAdjacentHTML:noop,innerHTML:'',textContent:''};e.parentNode=e;elements.set(id,e)}return elements.get(id)}const sandbox={document:{getElementById:element,createElement:()=>element('dynamic'+Math.random()),querySelectorAll:()=>[],addEventListener:noop},window:{devicePixelRatio:1,addEventListener:noop},matchMedia:()=>({matches:true}),requestAnimationFrame:noop,setTimeout:noop,performance:{now:()=>100},console,Math,JSON};sandbox.window.window=sandbox.window;const context=vm.createContext(sandbox);vm.runInContext(source,context);return {context,run:s=>vm.runInContext(s,context),window:sandbox.window,element}}
const g=make();const run=g.run;
assert(run('solid(500,400)'),'central building collision');assert(!run('solid(130,140)'),'safe spawn');
assert(run('visible({...newPlayer(0,0),x:400,y:440,a:0},{x:450,y:440})'),'enemy in cone');
assert(!run('visible({...newPlayer(0,3),x:400,y:440,a:0},{x:800,y:440})'),'cover occludes enemy');
assert(!run('visible({...newPlayer(0,0),x:400,y:440,a:0},{x:300,y:440})'),'enemy behind player hidden');
run('let testp={...newPlayer(0,0),x:450,y:440};movePlayer(testp,1,0,1)');assert(run('testp.x+R<=485'),'movement cannot pass through building');
run("begin('bot');players[0].x=400;players[0].y=440;players[0].a=0;players[1].x=800;players[1].y=440;shoot(players[0]);for(let i=0;i<60;i++)stepBullets(.016)");assert.equal(run('players[1].hp'),100,'wall stops bullet');
run("players=[newPlayer(0,0),newPlayer(1,0)];players[0].x=400;players[0].y=260;players[0].a=0;players[1].x=650;players[1].y=260;bullets=[];shoot(players[0]);for(let i=0;i<60;i++)stepBullets(.016)");assert.equal(run('players[1].hp'),76,'bullet damages opponent');assert.equal(run('players[0].ammo'),11,'shoot consumes ammo');
run('players[0].ammo=0;players[0].cool=0;shoot(players[0])');assert(run('players[0].reload>0'),'empty magazine reloads');
assert(run('pathTo({x:130,y:140},{x:1070,y:740}).length>0'),'bot has path between spawns');
assert(run('pathTo({x:130,y:140},{x:1070,y:740}).every(p=>!solid(p.x,p.y,R+3))'),'path avoids cover');
run("begin('bot');phase='fight';for(let i=0;i<18000;i++)tick(1/60)");assert(run('round>=3'),'bot simulation advances rounds');assert(run('players.every(p=>!solid(p.x,p.y))'),'bot and player stay outside cover');
// Two separate clients exercise ordered hello/ready/start/input/state messages.
const a=make(),b=make(),messages=[];a.window.AndroidArena={send:s=>messages.push([b,s]),disconnect:()=>{}};b.window.AndroidArena={send:s=>messages.push([a,s]),disconnect:()=>{}};
function drain(){let guard=100;while(messages.length&&guard--){const [target,s]=messages.shift();target.window.onBluetoothMessage(s)}assert(guard>0,'protocol does not loop')}
a.run("mode='bluetooth';role='host';selected=2");b.run("mode='bluetooth';role='guest';selected=3");a.window.onBluetoothStatus('connected','ok');b.window.onBluetoothStatus('connected','ok');drain();
assert.equal(a.run('choice[1]'),3);assert.equal(b.run('choice[0]'),2);
a.element('ready').onclick();drain();assert.equal(a.run('phase'),'menu','host cannot start before guest confirms');
b.element('ready').onclick();drain();assert.equal(a.run('phase'),'prep');assert.equal(b.run('phase'),'prep');assert.equal(b.run('localId()'),1);
b.run('input.x=1;input.a=.3;input.fire=true;tick(.05)');drain();assert.equal(a.run('remoteInput.x'),1);
a.run('sendSnapshot()');drain();assert.equal(b.run('players[1].weapon'),0);
b.window.onBluetoothMessage(JSON.stringify({t:'input',v:{x:100,y:-100,a:.5,fire:1}})); // ignored on guest
a.window.onBluetoothMessage(JSON.stringify({t:'input',v:{x:100,y:-100,a:.5,fire:1}}));assert.equal(a.run('remoteInput.x'),1);assert.equal(a.run('remoteInput.y'),-1);


// Preparation and economy use the same authoritative functions as actual play.
const economy=make(),er=economy.run;
er("begin('bot');input.x=1;input.fire=true;tick(.016,13)");
assert.equal(er('phase'),'prep');assert.equal(er('phaseTime'),7);assert.equal(er('players[0].x'),130);assert.equal(er('bullets.length'),0);
assert.equal(er('money[0]'),1000);assert(!er('buyWeapon(0,2)'),'cannot overspend');
assert(er('buyWeapon(0,1)'));assert.equal(er('money[0]'),100);assert(er('buyWeapon(0,1)'));assert.equal(er('money[0]'),100,'no duplicate charge');
assert(er('buyWeapon(0,0)'));assert.equal(er('money[0]'),1000,'swap refunds current purchase');assert(!er('buyWeapon(0,1,round-1)'),'stale round purchase rejected');
er('tick(.016,7)');assert.equal(er('phase'),'countdown');assert.equal(er('input.fire'),false);assert(!er('buyWeapon(0,1)'),'purchase closes at 20 seconds');
er('tick(.016,3)');assert.equal(er('phase'),'fight');er('finishRound(0)');assert.equal(er('money[0]'),2200);assert.equal(er('scores[0]'),1);er('finishRound(0)');assert.equal(er('money[0]'),2200,'rewards only once');
er('tick(.016,4)');assert.equal(er('phase'),'prep');assert.equal(er('round'),2);assert.equal(er('choice[0]'),0);assert.equal(er('phaseTime'),20);
er('money=[1000,1000];phase="fight";finishRound(-1)');assert.equal(er('money[0]'),1800);assert.equal(er('money[1]'),1800);assert.equal(er('lastWinner'),-1,'draw has no winner bonus');
er('scores=[8,0];phase="fight";finishRound(0);tick(.016,4)');assert.equal(er('scores[0]'),9);assert.equal(er('phase'),'prep','9 victories do not end match');
er('phase="fight";finishRound(0);tick(.016,4)');assert.equal(er('scores[0]'),10);assert.equal(er('phase'),'end','10 victories end match');
// Single joystick moves and turns; aim lock enables backwards movement.
const controls=make();controls.run("begin('bot');phase='fight';input.fire=false");
const event={pointerId:11,clientX:470,clientY:300,preventDefault(){}};
const initialAngle=controls.run('input.a');controls.element('move').onpointerdown(event);assert.equal(controls.run('input.a'),initialAngle);assert.equal(controls.run('input.x'),0);
controls.element('move').onpointermove({...event,clientX:540});assert(controls.run('input.x>0'));assert.equal(controls.run('input.fire'),false);controls.run('updateAim(.016)');assert(controls.run('input.a')<initialAngle);assert(initialAngle-controls.run('input.a')<=2.8*.016);
controls.element('move').onpointerup(event);const angleAfterRelease=controls.run('input.a');controls.run('faceMovement();updateAim(.033)');assert.equal(controls.run('input.a'),angleAfterRelease);assert.equal(controls.run('input.x'),0);
controls.run('input.a=0;toggleAimLock();input.x=-1;input.y=0;faceMovement();updateAim(.033);movePlayer(players[0],input.x,input.y,.016)');assert.equal(controls.run('input.a'),0);assert(controls.run('players[0].x<130'),'locked direction supports walking backwards');controls.run('toggleAimLock();faceMovement();updateAim(.033)');assert(controls.run('input.a')!==0,'unlocked direction follows movement');
controls.element('fire').onpointerdown({...event,pointerId:13});assert.equal(controls.run('input.fire'),true);controls.run('stopFire({pointerId:13})');assert.equal(controls.run('input.fire'),false);
// Guest purchases are charged on host, then echoed back with authoritative balances.
b.run('requestPurchase(1)');drain();assert.equal(a.run('choice[1]'),1);assert.equal(a.run('money[1]'),100);assert.equal(b.run('money[1]'),100);
b.run('requestPurchase(3)');drain();assert.equal(a.run('money[1]'),100);assert.equal(a.run('choice[1]'),1,'insufficient guest purchase denied');
a.window.onBluetoothMessage(JSON.stringify({t:'buy',weapon:0,round:999}));drain();assert.equal(a.run('money[1]'),100,'stale guest purchase denied');
a.run('phase="fight";finishRound(1);sendSnapshot()');drain();assert.equal(b.run('money[1]'),1300);assert.equal(b.run('scores[1]'),1);assert.equal(b.run('roundWinner'),1);
a.run('tick(.016,4);sendSnapshot()');drain();assert.equal(b.run('phase'),'prep');assert.equal(b.run('round'),2);assert.equal(b.run('phaseTime'),20);assert.equal(b.run('choice[1]'),0);
console.log('PASS: visibility, collisions, projectiles, bot navigation and 300-second play; exact 20s preparation; affordable purchases, refunds, income and winner bonus; first-to-10; separate rotation/movement/fire; two-client purchase synchronization and round transitions.');

const items=make(),ir=items.run;ir("begin('bot');money=[10000,10000]");
assert.equal(ir('weapons.length'),12);for(let f=0;f<4;f++)assert.equal(ir(`weapons.filter(w=>w.family===${f}).length`),3);
assert.equal(ir('new Set(weapons.map(w=>w.name)).size'),12);
for(let f=0;f<4;f++)assert.equal(ir(`new Set(weapons.filter(w=>w.family===${f}).map(w=>w.damage)).size`),3,'distinct family stats');
assert(ir('buyGear(0,"helmet",1)'));assert.equal(ir('money[0]'),9700);assert(ir('buyGear(0,"helmet",2)'));assert.equal(ir('money[0]'),9350,'helmet swap refunds previous tier');
assert(ir('buyGear(0,"vest",2)'));assert.equal(ir('money[0]'),8350);assert(ir('buyGear(0,"explosive",1)'));assert(ir('buyGear(0,"flash",1)'));assert.equal(ir('money[0]'),7700);
assert(ir('buyWeapon(0,11)'));assert.equal(ir('money[0]'),4100,'weapon does not refund other slots');
assert(!ir('buyGear(0,"__proto__",1)'));assert(!ir('buyGear(0,"helmet",999)'));assert(!ir('buyGear(0,"flash",2)'));assert(!ir('buyGear(0,"vest",0,round-1)'));
ir('tick(.016,20)');assert.equal(ir('players[0].helmet'),2);assert.equal(ir('players[0].vest'),2);assert.equal(ir('players[0].grenades.explosive'),1,'loadout survives countdown');assert.equal(ir('players[0].weapon'),11);
ir('tick(.016,3)');const reduction=ir('damagePlayer(players[0],80,"bullet")');assert(reduction<80);assert(ir('players[0].helmetArmor<65&&players[0].vestArmor<120'),'armor wears');
ir('players[0].hp=100;players[0].helmetArmor=0;players[0].vestArmor=0');assert.equal(ir('damagePlayer(players[0],80,"bullet")'),80,'exhausted armor no longer absorbs');
ir('players=[newPlayer(0,0),newPlayer(1,0)];players[0].x=400;players[0].y=440;players[1].x=800;players[1].y=440;detonate({x:450,y:440,kind:"explosive"})');assert.equal(ir('players[1].hp'),100,'wall shields explosion');assert(ir('players[0].hp<100'),'self damage is possible');
ir('players=[newPlayer(0,0),newPlayer(1,0)];players[0].x=400;players[0].y=260;players[1].x=600;players[1].y=260;detonate({x:610,y:260,kind:"explosive"})');assert(ir('players[1].hp<30'),'nearby explosion deals meaningful damage');assert.equal(ir('players[0].hp'),100,'blast radius limits damage');
ir('players=[newPlayer(0,0),newPlayer(1,0)];players[0].x=400;players[0].y=440;players[1].x=800;players[1].y=440;detonate({x:750,y:440,kind:"flash"})');assert.equal(ir('players[0].flash'),0,'wall shields flash');assert(ir('players[1].flash>0'),'exposed operator is blinded');
ir('players=[newPlayer(0,0),newPlayer(1,0)];players[0].x=400;players[0].y=260;players[0].a=0;players[1].x=650;players[1].y=260;detonate({x:450,y:260,kind:"flash"})');const fullFlash=ir('players[0].flash');assert(fullFlash>1);assert(!ir('visible(players[0],players[1])'),'flash actually hides enemy');
ir('players[0].flash=0;players[0].helmet=2;players[0].helmetArmor=65;detonate({x:450,y:260,kind:"flash"})');assert(ir('players[0].flash')<fullFlash,'helmet reduces flash duration');
ir('players[0].flash=0;players[0].grenades.explosive=1;players[0].grenadeCool=0;grenades=[];phase="fight"');assert(ir('throwGrenade(players[0],"explosive")'));assert.equal(ir('players[0].grenades.explosive'),0);assert(!ir('throwGrenade(players[0],"explosive")'),'grenade cannot be duplicated');ir('for(let i=0;i<90;i++)stepGrenades(1/60)');assert.equal(ir('grenades.length'),0,'grenade detonates after fuse');
const stable=make();stable.run("begin('bot');phase='fight';input.a=1");const touch={pointerId:40,clientX:25,clientY:75,preventDefault(){}};stable.element('move').onpointerdown(touch);assert.equal(stable.run('input.a'),1);stable.element('move').onpointermove({...touch,clientX:30,clientY:77});stable.run('updateAim(.033)');assert.equal(stable.run('input.a'),1,'dead zone ignores tiny motion');stable.element('move').onpointermove({...touch,clientX:-200,clientY:75});stable.run('updateAim(.033)');assert(Math.abs(stable.run('input.a')-1)<=.093,'large drag still bounded');stable.element('move').onpointerup(touch);const heldAngle=stable.run('input.a');stable.element('move').onpointermove({...touch,clientX:800,clientY:800});stable.run('for(let i=0;i<60;i++)updateAim(.016)');assert.equal(stable.run('input.a'),heldAngle,'release and late move do not rotate');
// Host-validated equipment and grenade packets stay synchronized on both phones.
a.run('phase="prep";phaseTime=20;money[1]=3000;sendSnapshot()');drain();b.run('requestItem("helmet",2)');drain();b.run('requestItem("vest",1)');drain();b.run('requestItem("flash",1)');drain();assert.equal(a.run('money[1]'),1600);assert.equal(b.run('players[1].helmet'),2);assert.equal(b.run('players[1].vest'),1);assert.equal(b.run('players[1].grenades.flash'),1);
a.run('phase="fight";sendSnapshot()');drain();b.run('input.grenade="flash";tick(.05)');drain();assert.equal(a.run('remoteInput.grenade'),'flash');assert.equal(b.run('input.grenade'),null,'guest grenade input sends once');a.run('tick(.016);sendSnapshot()');drain();assert.equal(b.run('players[1].grenades.flash'),0);assert.equal(b.run('grenades.length'),1);
console.log('PASS v3: 12 weapons, independent gear purchases/refunds, armor wear, blast and flash occlusion, blindness and protection, finite grenades, stable dynamic joysticks with bounded rotation, and Bluetooth equipment/throw synchronization.');

const ui=make();ui.run("begin('bot');money=[10000,10000]");for(let category=0;category<6;category++){ui.run(`selectCategory(${category});syncPrepUI()`);assert(ui.element('buyspec').innerHTML.includes('id="purchase"'));assert(!ui.element('buyspec').innerHTML.includes('undefined'));assert(ui.element('buywheel').innerHTML.includes('wheel-option'));}ui.run('for(let i=0;i<12;i++){gunSvg(i);itemData("weapon",i)}');console.log('PASS shop rendering: 6 categories, 12 weapon visuals and complete item detail/purchase panels.');

const grenadeUi=make();grenadeUi.run("begin('bot');money[0]=3000;buyGear(0,'explosive',1);buyGear(0,'flash',1);tick(.016,20);tick(.016,3)");grenadeUi.element('selectflash').onclick();assert.equal(grenadeUi.run('grenadeKind'),'flash');grenadeUi.element('throwgrenade').onclick();assert.equal(grenadeUi.run('input.grenade'),'flash');grenadeUi.run('tick(.016)');assert.equal(grenadeUi.run('players[0].grenades.flash'),0);assert.equal(grenadeUi.run('players[0].grenades.explosive'),1);grenadeUi.element('selectexplosive').onclick();assert.equal(grenadeUi.run('grenadeKind'),'explosive');grenadeUi.run('paused=true;input.grenade=null');grenadeUi.element('throwgrenade').onclick();assert.equal(grenadeUi.run('input.grenade'),null,'paused input cannot throw');
console.log('PASS v0.4: single movement/facing joystick, backwards movement under aim lock, stable release, separate fire/reload/aim and grenade type selection.');
