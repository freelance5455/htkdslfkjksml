-- Madar Halaqat: Multi-teacher migration V23
-- Run once in Supabase SQL Editor before using V23.
create table if not exists public.teacher_profiles (
  id uuid primary key default gen_random_uuid(),
  auth_user_id uuid not null references auth.users(id) on delete cascade,
  teacher_name text not null,
  teacher_code text not null unique,
  created_at timestamptz not null default now()
);

alter table public.circles add column if not exists teacher_profile_id uuid references public.teacher_profiles(id) on delete cascade;
alter table public.daily_reports add column if not exists teacher_profile_id uuid references public.teacher_profiles(id) on delete cascade;
alter table public.daily_reports add column if not exists teacher_name text;
alter table public.daily_reports add column if not exists report_date date;

create index if not exists idx_teacher_profiles_auth on public.teacher_profiles(auth_user_id);
create index if not exists idx_circles_teacher_profile on public.circles(teacher_profile_id);
create index if not exists idx_reports_teacher_profile on public.daily_reports(teacher_profile_id);

-- Keep the existing daily uniqueness, while allowing the app to update an existing report.
-- No existing rows are deleted.

alter table public.teacher_profiles enable row level security;

drop policy if exists "teacher_profiles_select_own" on public.teacher_profiles;
drop policy if exists "teacher_profiles_insert_own" on public.teacher_profiles;
drop policy if exists "teacher_profiles_update_own" on public.teacher_profiles;
create policy "teacher_profiles_select_own" on public.teacher_profiles for select to authenticated using (auth_user_id = auth.uid());
create policy "teacher_profiles_insert_own" on public.teacher_profiles for insert to authenticated with check (auth_user_id = auth.uid());
create policy "teacher_profiles_update_own" on public.teacher_profiles for update to authenticated using (auth_user_id = auth.uid()) with check (auth_user_id = auth.uid());

grant select,insert,update on public.teacher_profiles to authenticated;

-- Allow the manager app to read the teacher identity table.
drop policy if exists "manager_read_teacher_profiles" on public.teacher_profiles;
create policy "manager_read_teacher_profiles" on public.teacher_profiles for select to authenticated using (public.is_manager());

NOTIFY pgrst, 'reload schema';
