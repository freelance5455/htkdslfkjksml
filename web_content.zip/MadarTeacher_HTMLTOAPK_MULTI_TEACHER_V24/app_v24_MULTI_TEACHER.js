const APP_DIAG_VERSION = "HTMLTOAPK_MULTI_TEACHER_V24";
console.log(APP_DIAG_VERSION);
const SURAH_DATA = [["الفاتحة",7],["البقرة",286],["آل عمران",200],["النساء",176],["المائدة",120],["الأنعام",165],["الأعراف",206],["الأنفال",75],["التوبة",129],["يونس",109],["هود",123],["يوسف",111],["الرعد",43],["إبراهيم",52],["الحجر",99],["النحل",128],["الإسراء",111],["الكهف",110],["مريم",98],["طه",135],["الأنبياء",112],["الحج",78],["المؤمنون",118],["النور",64],["الفرقان",77],["الشعراء",227],["النمل",93],["القصص",88],["العنكبوت",69],["الروم",60],["لقمان",34],["السجدة",30],["الأحزاب",73],["سبأ",54],["فاطر",45],["يس",83],["الصافات",182],["ص",88],["الزمر",75],["غافر",85],["فصلت",54],["الشورى",53],["الزخرف",89],["الدخان",59],["الجاثية",37],["الأحقاف",35],["محمد",38],["الفتح",29],["الحجرات",18],["ق",45],["الذاريات",60],["الطور",49],["النجم",62],["القمر",55],["الرحمن",78],["الواقعة",96],["الحديد",29],["المجادلة",22],["الحشر",24],["الممتحنة",13],["الصف",14],["الجمعة",11],["المنافقون",11],["التغابن",18],["الطلاق",12],["التحريم",12],["الملك",30],["القلم",52],["الحاقة",52],["المعارج",44],["نوح",28],["الجن",28],["المزمل",20],["المدثر",56],["القيامة",40],["الإنسان",31],["المرسلات",50],["النبأ",40],["النازعات",46],["عبس",42],["التكوير",29],["الانفطار",19],["المطففين",36],["الانشقاق",25],["البروج",22],["الطارق",17],["الأعلى",19],["الغاشية",26],["الفجر",30],["البلد",20],["الشمس",15],["الليل",21],["الضحى",11],["الشرح",8],["التين",8],["العلق",19],["القدر",5],["البينة",8],["الزلزلة",8],["العاديات",11],["القارعة",11],["التكاثر",8],["العصر",3],["الهمزة",9],["الفيل",5],["قريش",4],["الماعون",7],["الكوثر",3],["الكافرون",6],["النصر",3],["المسد",5],["الإخلاص",4],["الفلق",5],["الناس",6]];
let user=null,circles=[],students=[],activeCircle=null,activeStudent=null,lessonType='new';
let teacherName=localStorage.getItem('madar_teacher_name')||'';
let teacherProfile=null;
function loadTeacherName(){const e=document.getElementById('teacherName');if(e)e.value=teacherName;}
function saveTeacherName(){const e=document.getElementById('teacherName');if(e&&e.value.trim()){teacherName=e.value.trim();localStorage.setItem('madar_teacher_name',teacherName);}}
async function ensureTeacherProfile(){
  let name=(localStorage.getItem('madar_teacher_name')||'').trim();
  if(!name){name=prompt('اكتب اسم المحفظ الذي يستخدم هذا الجهاز:','');if(!name||!name.trim())throw new Error('يجب كتابة اسم المحفظ أولاً.');name=name.trim();localStorage.setItem('madar_teacher_name',name);}
  const existing=await sb.from('teacher_profiles').select('*').eq('auth_user_id',user.id).eq('teacher_name',name).maybeSingle();
  if(existing.error && !/relation .* does not exist|schema cache/i.test(existing.error.message)) throw existing.error;
  if(existing.data){teacherProfile=existing.data;return null}
  const code='T-'+crypto.randomUUID().slice(0,8).toUpperCase();
  const ins=await sb.from('teacher_profiles').insert({auth_user_id:user.id,teacher_name:name,teacher_code:code}).select('*').single();
  if(ins.error) return ins.error;
  teacherProfile=ins.data; return null;
}
function profileRequired(){return teacherProfile?.id||null;}
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const msg=(id,text,ok=false)=>{const e=$(id);if(!e)return;e.textContent=text;e.className=ok?'ok':'err';};
function screen(id){document.querySelectorAll('.screen').forEach(x=>x.classList.add('hidden'));const e=$(id);if(e)e.classList.remove('hidden');window.scrollTo(0,0)}
function empty(t){return `<div class="empty">${esc(t)}</div>`}
function goHome(){screen('home')}
function openCircles(){screen('circles');loadCircles()}
async function openReport(){screen('report'); const d=new Date(); $('reportDate').value=localDateISO(d); await renderAllCircleReports()}
function openCircleView(){if(!activeCircle)return openCircles();screen('circle');loadStudents()}
function openStudentView(){if(!activeStudent)return openCircleView();screen('student');loadHistory()}

async function login(){
  const email=$('email').value.trim(),password=$('password').value;
  if(!email||!password){msg('loginMsg','اكتب البريد الإلكتروني وكلمة المرور.');return}
  const b=$('loginBtn');b.disabled=true;msg('loginMsg','جاري الدخول...');
  try{
    const r=await sb.auth.signInWithPassword({email,password});
    if(r.error){msg('loginMsg',r.error.message);return}
    user=r.data?.user||null;
    if(!user){msg('loginMsg','تعذر الحصول على جلسة الدخول.');return}
    await checkRole();
  }catch(e){console.error(e);msg('loginMsg','تعذر الاتصال بـ Supabase: '+(e?.message||e))}
  finally{b.disabled=false}
}
async function checkRole(){
  const r=await sb.from('profiles').select('role').eq('id',user.id).maybeSingle();
  if(r.error){msg('loginMsg','خطأ في قراءة صلاحية الحساب: '+r.error.message);return}
  if(!r.data||r.data.role!=='teacher'){await sb.auth.signOut();msg('loginMsg','هذا الحساب ليس حساب محفظ.');return}
  const pe=await ensureTeacherProfile();if(pe){msg('loginMsg','تعذر حفظ هوية المحفظ: '+pe.message);return}
  $('login').classList.add('hidden');$('app').classList.remove('hidden');await loadCircles();goHome();loadTeacherName();
}
async function loadCircles(){
  const r=await sb.from('circles').select('*').eq('teacher_id',user.id).eq('teacher_profile_id',profileRequired()).order('created_at',{ascending:true});
  if(r.error){msg('circleMsg',r.error.message);return}
  circles=r.data||[];$('circleCount').textContent=circles.length+' حلقة';
  $('circleList').innerHTML=circles.map(c=>`<button class="cardRow" data-circle-id="${c.id}"><span class="rowIcon">📚</span><span class="rowText"><b>${esc(c.name)}</b><small>فتح الحلقة والطلاب</small></span><span class="arrow">‹</span></button>`).join('')||empty('لا توجد حلقات بعد. أضف أول حلقة.');
  document.querySelectorAll('[data-circle-id]').forEach(b=>b.onclick=()=>chooseCircle(b.dataset.circleId));
}
async function addCircle(){
  const name=$('circleName').value.trim();if(!name){msg('circleMsg','اكتب اسم الحلقة أولاً.');return}
  const b=$('addCircle');b.disabled=true;msg('circleMsg','جاري الإضافة...');
  try{const r=await sb.from('circles').insert({teacher_id:user.id,teacher_profile_id:profileRequired(),name});if(r.error){msg('circleMsg',r.error.message);return}$('circleName').value='';msg('circleMsg','تمت إضافة الحلقة.',true);await loadCircles()}finally{b.disabled=false}
}
async function chooseCircle(id){activeCircle=circles.find(c=>c.id===id)||null;if(!activeCircle)return;$('circleTitle').textContent=activeCircle.name;screen('circle');await loadStudents()}
async function loadStudents(){
  const r=await sb.from('students').select('*').eq('circle_id',activeCircle.id).eq('active',true).order('name');
  if(r.error){$('studentList').innerHTML=empty(r.error.message);return}students=r.data||[];
  $('studentList').innerHTML=students.map(s=>`<button class="cardRow" data-student-id="${s.id}"><span class="avatar">${esc(s.name).slice(0,1)}</span><span class="rowText"><b>${esc(s.name)}</b><small>فتح ملف الطالب</small></span><span class="arrow">‹</span></button>`).join('')||empty('لا يوجد طلاب في هذه الحلقة.');
  document.querySelectorAll('[data-student-id]').forEach(b=>b.onclick=()=>chooseStudent(b.dataset.studentId));
}
async function addStudent(){
  const name=$('studentName').value.trim();if(!name){msg('studentMsg','اكتب اسم الطالب أولاً.');return}
  const b=$('addStudent');b.disabled=true;msg('studentMsg','جاري الإضافة...');
  try{const r=await sb.from('students').insert({circle_id:activeCircle.id,name});if(r.error){msg('studentMsg',r.error.message);return}$('studentName').value='';msg('studentMsg','تمت إضافة الطالب.',true);await loadStudents()}finally{b.disabled=false}
}
function chooseStudent(id){activeStudent=students.find(s=>s.id===id)||null;if(!activeStudent)return;$('studentTitle').textContent=activeStudent.name;screen('student');loadHistory()}
async function loadHistory(){
  const r=await sb.from('recitations').select('*').eq('student_id',activeStudent.id).order('created_at',{ascending:false}).limit(100);
  if(r.error){$('history').innerHTML=empty(r.error.message);return}
  const rows=r.data||[];
  const groups={};
  rows.forEach(x=>{
    const key=x.date||x.recitation_date||(x.created_at?new Date(x.created_at).toISOString().slice(0,10):'');
    if(!groups[key])groups[key]={date:key,new:[],review:[]};
    const type=x.type==='new'?'new':'review';
    const fa=x.from_ayah??x.from_verse??x.start_ayah??x.start_verse??x.ayah_from??x.from??'—';
    const ta=x.to_ayah??x.to_verse??x.end_ayah??x.end_verse??x.ayah_to??x.to??'—';
    const sn=x.surah_number||x.surah||1;
    const name=esc(SURAH_DATA[(Number(sn)||1)-1]?.[0]||'سورة');
    const item=`<div class="history-item"><b>${name}</b><span>الآيات ${esc(fa)}–${esc(ta)}</span></div>`;
    groups[key][type].push(item);
  });
  const dates=Object.keys(groups).sort((a,b)=>String(b).localeCompare(String(a)));
  $('history').innerHTML=dates.map(date=>{
    const g=groups[date];
    const dateLabel=esc(date?new Date(date+'T00:00:00').toLocaleDateString('ar-EG'):'');
    return `<div class="history-pair">
      <div class="history-date">${dateLabel}</div>
      <div class="history-col new-col"><strong>📖 حفظ جديد</strong>${g.new.join('')||'<span class="history-empty">لا يوجد</span>'}</div>
      <div class="history-col review-col"><strong>🔄 مراجعة</strong>${g.review.join('')||'<span class="history-empty">لا يوجد</span>'}</div>
    </div>`;
  }).join('')||empty('لا يوجد سجل لهذا الطالب.');
}
function openLesson(t){lessonType=t;$('lessonTitle').textContent=t==='new'?'حفظ جديد':'مراجعة';$('lessonMsg').textContent='';$('fromAyah').value='';$('toAyah').value='';$('surah').value='0';updateAyahLimit();screen('lesson')}
function updateAyahLimit(){const m=SURAH_DATA[Number($('surah').value)][1];$('fromAyah').max=m;$('toAyah').max=m;$('surahHint').textContent='عدد آيات السورة: '+m}
function serverMissingColumn(msg){
  const m=String(msg||'').match(/(?:Could not find the '([^']+)' column|column ["']([^"']+)["'])/i);
  return m?.[1]||m?.[2]||null;
}
function serverNotNullColumn(msg){
  const m=String(msg||'').match(/null value in column ["']([^"']+)["']/i);
  return m?.[1]||null;
}
function valueForColumn(col,ctx){
  const c=String(col||'').toLowerCase();
  if(c==='circle_id') return ctx.circle_id;
  if(c==='student_id') return ctx.student_id;
  if(c==='teacher_id') return ctx.teacher_id;
  if(c==='type') return ctx.type;
  if(c.includes('surah') && c.includes('number')) return ctx.surah_number;
  if(c==='surah_from') return ctx.surah_number;
  if(c==='surah_to') return ctx.surah_number;
  if(c.includes('from') && (c.includes('ayah')||c.includes('verse'))) return ctx.from_ayah;
  if(c.includes('to') && (c.includes('ayah')||c.includes('verse'))) return ctx.to_ayah;
  if(c==='from_ayah') return ctx.from_ayah;
  if(c==='to_ayah') return ctx.to_ayah;
  if(c==='recitation_date') return ctx.date;
  if(c==='attendance_date') return ctx.date;
  if(c==='report_date') return ctx.date;
  if(c==='date') return ctx.date;
  if(c==='created_at') return ctx.created_at||new Date().toISOString();
  if(c==='updated_at') return new Date().toISOString();
  if(c==='hours') return ctx.hours??0;
  if(c==='notes') return ctx.notes??'';
  if(c==='status') return ctx.status||'present';
  return undefined;
}
async function adaptiveInsert(table, initial, ctx, maxTries=12){
  let payload={...initial};
  for(let attempt=0;attempt<maxTries;attempt++){
    const r=await sb.from(table).insert(payload);
    if(!r.error) return null;
    const msg=String(r.error.message||r.error);
    const missing=serverMissingColumn(msg);
    if(missing && Object.prototype.hasOwnProperty.call(payload,missing)){
      delete payload[missing];
      continue;
    }
    const nn=serverNotNullColumn(msg);
    if(nn && !Object.prototype.hasOwnProperty.call(payload,nn)){
      const v=valueForColumn(nn,ctx);
      if(v!==undefined){payload[nn]=v;continue}
    }
    return new Error('['+APP_DIAG_VERSION+'] '+table+': '+msg);
  }
  return new Error('['+APP_DIAG_VERSION+'] '+table+': تعذر تجهيز البيانات تلقائياً.');
}
async function saveLesson(e){
  if(e){e.preventDefault();e.stopPropagation()}
  try{
    if(!activeCircle || !activeStudent){msg('lessonMsg','اختر الحلقة والطالب أولاً.');return}
    const surahSel=$('surah'),fromEl=$('fromAyah'),toEl=$('toAyah');
    if(!surahSel||!fromEl||!toEl){msg('lessonMsg','خطأ في واجهة الحفظ: عناصر الإدخال غير موجودة.');return}
    const i=Number(surahSel.value||0),from=Number(fromEl.value||0),to=Number(toEl.value||0);
    if(!i||!from||!to){msg('lessonMsg','اختر السورة وأدخل الآيات.');return}
    const max=SURAH_DATA[i]?.[1]||0;
    if(from<1||to<1||from>to||to>max){msg('lessonMsg','رقم الآيات غير صحيح لهذه السورة.');return}
    const today=new Date().toISOString().slice(0,10);
    const ctx={circle_id:activeCircle.id,student_id:activeStudent.id,teacher_id:user?.id,teacher_profile_id:profileRequired(),type:lessonType,surah_number:i,from_ayah:from,to_ayah:to,date:today};
    const broad={circle_id:ctx.circle_id,student_id:ctx.student_id,teacher_id:ctx.teacher_id,teacher_profile_id:ctx.teacher_profile_id,type:ctx.type,surah_number:i,surah_from:i,surah_to:i,from_ayah:from,to_ayah:to,start_ayah:from,end_ayah:to,from_verse:from,to_verse:to,recitation_date:today,date:today};
    const b=$('saveLesson');if(b)b.disabled=true;msg('lessonMsg','جاري الحفظ...');
    const err=await adaptiveInsert('recitations',broad,ctx);
    if(err){console.error(err);msg('lessonMsg','فشل الحفظ: '+err.message);return}
    msg('lessonMsg','تم الحفظ بنجاح.',true);await loadHistory();
  }catch(err){console.error(APP_DIAG_VERSION,err);msg('lessonMsg','خطأ أثناء الحفظ: '+(err?.message||String(err)))}
  finally{const b=$('saveLesson');if(b)b.disabled=false}
}

function localDateISO(d=new Date()){
  const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');
  return `${y}-${m}-${day}`;
}
function draftKey(date){return `madar_report_drafts_${profileRequired()||user?.id||'unknown'}_${date}`}
function getDrafts(date){try{return JSON.parse(localStorage.getItem(draftKey(date))||'[]')||[]}catch{return[]}}
function setDrafts(date,items){localStorage.setItem(draftKey(date),JSON.stringify(items||[]))}
function clearDrafts(date){localStorage.removeItem(draftKey(date))}
function circleById(id){return circles.find(c=>String(c.id)===String(id))||null}
async function renderAllCircleReports(){
  const box=$('allCircleReports');
  if(!circles.length){box.innerHTML=empty('لا توجد حلقات.');return}
  const date=$('reportDate')?.value||localDateISO();
  const sel=$('reportCircle');
  if(sel){sel.innerHTML=circles.map(c=>`<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('')}
  const drafts=getDrafts(date);
  box.innerHTML=drafts.length?drafts.map((d,i)=>{
    const c=circleById(d.circleId);
    const names=(d.studentIds||[]).map(id=>students.find(s=>s.id===id)?.name).filter(Boolean);
    return `<div class="report-card saved-report"><div><h3>✅ ${esc(c?.name||'حلقة')}</h3><small>${esc(d.time||'بدون وقت')} — ${esc(d.savedAt||'')}</small></div><div class="saved-meta"><span>الساعات: ${Number(d.hours||0)}</span><span>الحضور: ${names.length}</span></div><div class="saved-students">${names.length?names.map(esc).join('، '):'لا يوجد حضور مسجل'}</div>${d.notes?`<div class="muted">${esc(d.notes)}</div>`:''}<button type="button" class="danger small-delete" data-draft-index="${i}">حذف الحفظ</button></div>`
  }).join('') : empty('لم تحفظ أي حلقة لهذا اليوم بعد. اختر الحلقة وسجّل بياناتها ثم اضغط «حفظ الحلقة».');
  box.querySelectorAll('.small-delete').forEach(b=>b.onclick=()=>{const arr=getDrafts(date);arr.splice(Number(b.dataset.draftIndex),1);setDrafts(date,arr);renderAllCircleReports();msg('reportMsg','تم حذف الحفظ المحلي.',true)})
  const c=circleById(sel?.value)||circles[0];
  if(sel&&c)sel.value=c.id;
  await loadReportStudents(c?.id);
}
async function loadReportStudents(cid){
  const box=$('reportAttendance'); if(!box)return;
  if(!cid){box.innerHTML=empty('اختر الحلقة.');return}
  const r=await sb.from('students').select('id,name').eq('circle_id',cid).eq('active',true).order('name');
  if(r.error){box.innerHTML=empty(r.error.message);return}
  box.innerHTML=(r.data||[]).map(s=>`<label class="att"><input type="checkbox" class="report-att" value="${esc(s.id)}"><span>${esc(s.name)}</span></label>`).join('')||'<p class="muted">لا يوجد طلاب في هذه الحلقة.</p>';
}
async function saveReportDraft(){
  const date=$('reportDate')?.value||localDateISO(),cid=$('reportCircle')?.value,hours=Number($('reportHours')?.value||0),time=$('reportTime')?.value||'',notes=$('reportNotes')?.value?.trim()||'';
  if(!cid){msg('reportMsg','اختر الحلقة أولاً.');return}
  const studentIds=[...document.querySelectorAll('.report-att:checked')].map(x=>x.value);
  const arr=getDrafts(date);
  arr.push({circleId:cid,hours,studentIds,time,notes,savedAt:new Date().toLocaleTimeString('ar-EG',{hour:'2-digit',minute:'2-digit'})});
  setDrafts(date,arr);
  $('reportHours').value='';$('reportTime').value='';$('reportNotes').value='';
  document.querySelectorAll('.report-att').forEach(x=>x.checked=false);
  await renderAllCircleReports();msg('reportMsg','تم حفظ الحلقة في التطبيق. يمكنك تسجيل الحلقة التالية ثم إرسال الكل مرة واحدة.',true);
}
function mergeDrafts(date){
  const map=new Map();
  for(const d of getDrafts(date)){
    if(!map.has(d.circleId))map.set(d.circleId,{circleId:d.circleId,hours:0,studentIds:new Set(),notes:[],times:[]});
    const x=map.get(d.circleId);x.hours+=Number(d.hours||0);(d.studentIds||[]).forEach(id=>x.studentIds.add(id));if(d.notes)x.notes.push(d.notes);if(d.time)x.times.push(d.time);
  }
  return [...map.values()].map(x=>({...x,studentIds:[...x.studentIds],notes:x.notes.join(' | '),times:x.times.join('، ')}));
}
async function sendReport(e){
  if(e){e.preventDefault();e.stopPropagation()}
  try{
    const date=$('reportDate')?.value||localDateISO(),b=$('sendReport');
    if(!date){msg('reportMsg','اختر التاريخ.');return}
    if(!user){msg('reportMsg','جلسة الدخول انتهت. سجّل الدخول مرة أخرى.');return}
    const merged=mergeDrafts(date);
    if(!merged.length){msg('reportMsg','احفظ حلقة واحدة على الأقل أولاً.');return}
    if(b)b.disabled=true;msg('reportMsg','جاري إرسال الحلقات المحفوظة...');
    for(let n=0;n<merged.length;n++){
      const d=merged[n];
      msg('reportMsg',`جاري إرسال الحلقة ${n+1} من ${merged.length}...`);
      const ae=await saveAttendance(d.circleId,date,d.studentIds);if(ae)throw new Error('الحضور: '+ae.message);
      const note=[d.times?`أوقات الحلقة: ${d.times}`:'',d.notes].filter(Boolean).join('\n');
      const re=await saveOrUpdateReport(d.circleId,date,d.hours,note);if(re)throw new Error('التقرير: '+re.message);
    }
    clearDrafts(date);await renderAllCircleReports();msg('reportMsg','تم إرسال جميع الحلقات المحفوظة للمدير بنجاح.',true)
  }catch(e2){console.error(APP_DIAG_VERSION,e2);msg('reportMsg','لم يتم الإرسال: '+(e2?.message||String(e2)))}
  finally{const b=$('sendReport');if(b)b.disabled=false}
}

function bind(){
  SURAH_DATA.forEach((s,i)=>$('surah').insertAdjacentHTML('beforeend',`<option value="${i}">${i+1} — ${s[0]}</option>`));
  $('surah').onchange=updateAyahLimit;
  $('loginBtn').onclick=login;
  $('logout').onclick=async()=>{await sb.auth.signOut();location.reload()};
  $('addCircle').addEventListener('click',addCircle);$('addStudent').addEventListener('click',addStudent);$('saveLesson').addEventListener('click',saveLesson);$('sendReport').addEventListener('click',sendReport);$('saveReportDraft').addEventListener('click',saveReportDraft);$('reportCircle').addEventListener('change',()=>loadReportStudents($('reportCircle').value));$('reportDate').addEventListener('change',()=>renderAllCircleReports());
}
async function init(){
  bind();
  loadTeacherName();
  try{
    const r=await sb.auth.getSession();
    if(r.error)throw r.error;
    user=r.data?.session?.user||null;
    if(user) await checkRole(); else {$('login').classList.remove('hidden');$('app').classList.add('hidden')}
  }catch(e){console.error(e);msg('loginMsg','تعذر الاتصال بالخادم: '+(e?.message||e))}
}
sb.auth.onAuthStateChange((event,session)=>{if(event==='SIGNED_OUT'){user=null;$('app').classList.add('hidden');$('login').classList.remove('hidden')}});
init();
