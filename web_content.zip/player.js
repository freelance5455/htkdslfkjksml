const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
const MOVE_KEYS = new Set(['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight']);

export function createPlayer(camera,onInteract) {
  const player = { x:0,z:0,yaw:0,pitch:0,moveX:0,moveY:0,keys:new Set(),lookId:null,lastX:0,lastY:0 };
  camera.position.set(0,1.62,3.8);
  const look = document.querySelector('#look-zone'), zone = document.querySelector('#stick-zone'), stick = document.querySelector('#stick');
  look.addEventListener('pointerdown',e=>{
    if (player.lookId !== null) return;
    player.lookId=e.pointerId; player.lastX=e.clientX; player.lastY=e.clientY; look.setPointerCapture(e.pointerId);
  });
  look.addEventListener('pointermove',e=>{
    if (e.pointerId!==player.lookId) return;
    player.yaw-=(e.clientX-player.lastX)*.004;
    player.pitch=clamp(player.pitch-(e.clientY-player.lastY)*.0035,-.75,.68);
    player.lastX=e.clientX; player.lastY=e.clientY;
  });
  const stopLook=e=>{ if(e.pointerId===player.lookId) player.lookId=null; };
  look.addEventListener('pointerup',stopLook); look.addEventListener('pointercancel',stopLook);

  document.addEventListener('keydown',e=>{
    if(e.target instanceof HTMLInputElement||e.target instanceof HTMLTextAreaElement)return;
    if(MOVE_KEYS.has(e.code)) { e.preventDefault(); player.keys.add(e.code); }
    if((e.code==='KeyE'||e.code==='Space')&&!e.repeat) { e.preventDefault(); onInteract(); }
  });
  document.addEventListener('keyup',e=>player.keys.delete(e.code));
  addEventListener('blur',()=>player.keys.clear());

  let stickId=null;
  zone.addEventListener('pointerdown',e=>{ if(stickId!==null)return; stickId=e.pointerId; zone.setPointerCapture(e.pointerId); moveStick(e); });
  zone.addEventListener('pointermove',e=>{ if(e.pointerId===stickId)moveStick(e); });
  const stopStick=e=>{ if(e.pointerId!==stickId)return; stickId=null; player.moveX=player.moveY=0; stick.style.transform=''; };
  zone.addEventListener('pointerup',stopStick); zone.addEventListener('pointercancel',stopStick);
  function moveStick(e){
    const r=zone.getBoundingClientRect(),dx=e.clientX-r.left-r.width/2,dy=e.clientY-r.top-r.height/2;
    const length=Math.min(38,Math.hypot(dx,dy)),angle=Math.atan2(dy,dx),x=Math.cos(angle)*length,y=Math.sin(angle)*length;
    stick.style.transform=`translate(${x}px,${y}px)`; player.moveX=x/38; player.moveY=y/38;
  }
  document.querySelector('#interact').addEventListener('click',onInteract);
  return {
    setPosition(x,z,yaw=player.yaw){player.x=x;player.z=z;player.yaw=yaw;player.pitch=0;},
    get pose(){return {x:player.x,z:player.z,yaw:player.yaw};},
    update(dt){
    const k=player.keys;
    const forward=player.moveY||((k.has('KeyW')||k.has('ArrowUp')?-1:0)+(k.has('KeyS')||k.has('ArrowDown')?1:0));
    const side=player.moveX||((k.has('KeyD')||k.has('ArrowRight')?1:0)+(k.has('KeyA')||k.has('ArrowLeft')?-1:0));
    const length=Math.hypot(side,forward)||1,speed=2.4*dt;
    player.x=clamp(player.x+(side*Math.cos(player.yaw)-forward*Math.sin(player.yaw))/length*speed,-8.7,8.7);
    player.z=clamp(player.z+(side*Math.sin(player.yaw)+forward*Math.cos(player.yaw))/length*speed,-8.4,8.4);
    camera.position.set(player.x,1.62,player.z); camera.rotation.order='YXZ'; camera.rotation.set(player.pitch,player.yaw,0);
  }};
}
