# Keep Tracked — standalone `index.html`

This folder contains **one file**: `index.html` (≈530 KB). It is the complete
Keep Tracked app — setup wizard, PIN lock, home balance, ledger receipts,
heat calendar, bill trackers with month-to-month rollover, insights graphs
and settings — with all JavaScript and CSS inlined.

* No server, no build step, **no internet** — everything is stored on the
  device (`localStorage` key `kt.db.v1`).
* Works opened directly from disk (`file://`), from any static host, from an
  Android `WebView`, or baked into a real APK.
* A different device / fresh install starts completely empty (that is
  intended — use Settings → Backup / Restore to move data).

Regenerate it any time with:

```bash
npm run build                 # produces the compiled Tailwind CSS
node scripts/build-standalone.mjs
```

---

## Option A — real native APK with Capacitor (no Android Studio)

```bash
# 1. one-time tools: JDK 17 + Android SDK command-line tools
#    (sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0")
npm i -D @capacitor/core @capacitor/cli @capacitor/android

# 2. create the Android project using THIS folder as the web assets
npx cap init "Keep Tracked" app.keeptracked.offline --web-dir standalone
npx cap add android
npx cap copy android

# 3. compile the APK with Gradle only
cd android && ./gradlew assembleDebug
#    → android/app/build/outputs/apk/debug/app-debug.apk
```

Because the whole app is inside `index.html`, the APK is fully offline:
Capacitor ships the file inside the package and the WebView loads it from
`https://localhost/` internally — no `server.url` needed.

## Option B — online HTML→APK wrappers (zero tools)

Services such as **WebIntoApp**, **AppsGeyser** or **Median.co** accept a
single HTML file (or a zip containing it). Upload `standalone/index.html`,
set the app name *Keep Tracked*, enable *JavaScript* and *DOM storage /
localStorage*, and download the generated APK.

## Option C — plain Android WebView (if you write your own shell)

```kotlin
webView.settings.javaScriptEnabled = true
webView.settings.domStorageEnabled = true          // required for the ledger
webView.settings.allowFileAccess = true
webView.loadUrl("file:///android_asset/keeptracked/index.html")
```

Copy `index.html` into `app/src/main/assets/keeptracked/`.

---

## Notes

* `domStorageEnabled = true` (or DOM storage toggled on in wrappers) is
  **required** — the ledger lives in `localStorage`.
* Uninstalling the app clears the ledger. Export a backup first
  (Settings → data & backup → Backup).
* Fonts fall back to the system stack when offline; the bundled UI does not
  depend on any network resource.
