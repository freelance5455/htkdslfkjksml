# Gnani AI ChatBox — secure backend starter

## Included
- `public/index.html`: mobile-friendly Gnani AI frontend
- `server.js`: Express backend; the AI key stays server-side
- `.env.example`: environment variable template
- `package.json`: dependencies and start script

## Run locally
1. Install Node.js (LTS).
2. Copy `.env.example` to `.env`.
3. Put your secret API key in `.env` as `OPENAI_API_KEY=...`.
4. In this folder run `npm install`, then `npm start`.
5. Open `http://localhost:3000`.

## Security notes
- Never put an API key in `public/index.html` or ship it inside an APK.
- This starter has basic security headers, request-size limits, and rate limiting.
- Before public launch, add user authentication, per-user quotas, abuse monitoring, HTTPS, and a production hosting environment.
- API usage may incur charges. Set provider spending limits and monitor usage.
- The HTML-to-APK wrapper must call your deployed HTTPS backend; localhost only works on your own development machine.

## Important
This is a backend starter, not a deployed service. You must supply your own API key and deploy the server to a host you control before real AI responses work on a phone.
