import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import dotenv from "dotenv";

dotenv.config();
const app = express();
const port = Number(process.env.PORT || 3000);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "32kb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false }));
app.use(express.static("public"));

const apiKey = process.env.OPENAI_API_KEY;
const client = apiKey ? new OpenAI({ apiKey }) : null;

app.get("/api/health", (_req, res) => res.json({ ok: true, configured: Boolean(client) }));

app.post("/api/chat", async (req, res) => {
  try {
    if (!client) return res.status(503).json({ error: "Server is missing OPENAI_API_KEY. Add it to .env; never put it in browser HTML." });
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "Message is required." });
    if (message.length > 12_000) return res.status(413).json({ error: "Message is too long." });

    const history = Array.isArray(req.body?.history) ? req.body.history.slice(-12) : [];
    const safeHistory = history
      .filter(x => x && ["user", "assistant"].includes(x.role) && typeof x.content === "string")
      .map(x => ({ role: x.role, content: x.content.slice(0, 12_000) }));

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions: "You are Gnani AI, a helpful assistant for clients and everyday users. Be clear, useful, and honest. Do not claim to have performed actions you cannot perform.",
      input: [...safeHistory, { role: "user", content: message }]
    });
    res.json({ reply: response.output_text || "I couldn't produce a text response." });
  } catch (err) {
    console.error("Chat API error:", err?.message || err);
    res.status(500).json({ error: "AI request failed. Check server logs and API billing/access." });
  }
});

app.listen(port, () => console.log(`Gnani AI backend running at http://localhost:${port}`));
