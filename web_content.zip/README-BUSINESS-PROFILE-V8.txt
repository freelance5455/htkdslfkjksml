BOOK UP — BUSINESS PROFILE CATALOGUE UPDATE (V8)

WHAT CHANGED
- The 40 colour palette choices now sit inside a neat, vertically scrollable palette panel.
- The business-profile editor now has three catalogue tabs: Product Gallery, Offers, and Services.
- Product Gallery entries support product name, image upload, description, price, URL/link, Add and Remove.
- Offers use the same fields and Add/Remove workflow, and display in their own Offers section.
- Services support service name and link, with Add/Remove. Public services display as theme-coloured pill links.
- Products and offers display as horizontal sliders with image, title, price and Know more.
- Know more opens a separate themed detail tab with image, description, price, optional link and a Book Now inquiry form. The form includes name, +91 contact number, requirement, date and address; Submit opens WhatsApp with field labels formatted in bold.
- The detail tab includes a close control at the top-right.
- Create profile page and Share it are side-by-side above the live preview panel. The live preview updates as the form is edited and reflects catalogue entries and selected palette.
- The generated profile keeps one medium-sized Share It / Save Contact pair side-by-side above the footer message.
- Existing Book Up modules and project structure are retained.

INSTALLATION — WEB HOSTING
1. Back up the current website.
2. Extract this ZIP and upload/replace the complete www folder contents.
3. Keep profile-stability.js beside index.html.
4. Clear the old site/PWA cache or close and reopen the app, then open Business Profile and save/regenerate the profile.

INSTALLATION — ANDROID / CAPACITOR
1. Replace the project www folder with the included www folder.
2. Run: npm install
3. Run: npm run android:sync
4. Run: npm run android:open
5. Build and sign a fresh APK/AAB in Android Studio.

IMPORTANT
- Existing shared/exported HTML profile files do not update automatically. Generate and share a fresh profile after installing this update.
- WhatsApp enquiry submission opens WhatsApp with a prefilled message; it does not silently send or remotely store the enquiry. The business WhatsApp/contact number must be filled in the profile.
- HTML file sharing depends on whether the receiving app accepts HTML files. If it does not, Share it downloads the file so it can be attached manually.
- Static validation: all inline JavaScript blocks and profile-stability.js pass Node syntax checks; ZIP integrity is checked. A live Android device test and browser interaction test were not completed in this environment.
