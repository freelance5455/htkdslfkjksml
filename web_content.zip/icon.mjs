import { chromium } from 'playwright';
const browser = await chromium.launch({ executablePath: '/home/user/.cache/ms-playwright/chromium_headless_shell-1148/chrome-linux/headless_shell', args: ['--no-sandbox','--disable-gpu'] });
const fs = await import('fs');
const svg = fs.readFileSync('public/icon.svg','utf8');
for (const [name, size] of [['icon-192',192],['icon-512',512],['apple-touch-icon',180]]) {
  const page = await browser.newPage({ viewport: { width: size, height: size }, deviceScaleFactor: 1 });
  await page.setContent(`<html><body style="margin:0;background:transparent;overflow:hidden"><div style="width:${size}px;height:${size}px">${svg.replace('width="512" height="512"', `width="${size}" height="${size}"`)}</div></body></html>`);
  await page.screenshot({ path: `public/${name}.png`, omitBackground: true });
  await page.close();
}
await browser.close();
