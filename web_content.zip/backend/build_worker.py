import asyncio, subprocess, shutil
from pathlib import Path

jobs = {}

async def run_build(job_id, work):
    jobs[job_id]["status"] = "building"
    src = Path(work) / "src"
    try:
        # The Docker image mounts only this temporary project directory.
        cmd = [
            "docker", "run", "--rm",
            "--network=none",
            "--cpus=2", "--memory=4g",
            "-v", f"{src.resolve()}:/workspace/project",
            "zip-to-apk-builder:latest",
        ]
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT
        )
        try:
            out, _ = await asyncio.wait_for(proc.communicate(), timeout=900)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            raise RuntimeError("Build timed out after 15 minutes")

        logs = out.decode(errors="replace")[-30000:]
        jobs[job_id]["logs"] = logs
        if proc.returncode != 0:
            raise RuntimeError("Gradle build failed")

        candidates = list(src.rglob("*.apk"))
        if not candidates:
            raise RuntimeError("Build finished but no APK was found")

        jobs[job_id]["apk"] = str(candidates[0])
        jobs[job_id]["status"] = "completed"
    except Exception as e:
        jobs[job_id]["status"] = "failed"
        jobs[job_id]["logs"] += f"\nERROR: {e}"
    finally:
        # Keep successful source/APK for this MVP; production should use object storage
        # and scheduled cleanup.
        if jobs[job_id]["status"] == "failed":
            shutil.rmtree(work, ignore_errors=True)
