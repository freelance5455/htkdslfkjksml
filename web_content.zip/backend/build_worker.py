import asyncio, shutil
from pathlib import Path
jobs = {}

async def run_build(job_id, work):
    jobs[job_id]["status"] = "building"
    src = Path(work) / "src"
    try:
        cmd = [
            "docker","run","--rm","--network=none",
            "--cpus=2","--memory=4g",
            "-v",f"{src.resolve()}:/workspace/project",
            "zip-to-apk-builder:latest"
        ]
        p = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
        try:
            out,_ = await asyncio.wait_for(p.communicate(), timeout=900)
        except asyncio.TimeoutError:
            p.kill(); await p.communicate()
            raise RuntimeError("Build timeout (15 minutes)")
        jobs[job_id]["logs"] = out.decode(errors="replace")[-30000:]
        if p.returncode != 0: raise RuntimeError("Gradle build failed")
        apks = list(src.rglob("*.apk"))
        if not apks: raise RuntimeError("No APK produced")
        jobs[job_id]["apk"] = str(apks[0])
        jobs[job_id]["status"] = "completed"
    except Exception as e:
        jobs[job_id]["status"] = "failed"
        jobs[job_id]["logs"] += "\nERROR: " + str(e)
        shutil.rmtree(work, ignore_errors=True)
