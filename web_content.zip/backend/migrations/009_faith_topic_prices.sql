-- @foreign_keys_off
-- Faith topics can be priced too: buying a topic unlocks every course-content lesson in it (series or standalone).
-- Rebuilds `transactions` (new item type + column) and `faith_access` (an access row is for a series OR a topic).
-- Every existing row is copied across unchanged; the migration runner verifies foreign keys before committing.

ALTER TABLE faith_topics ADD COLUMN price_kobo INTEGER NOT NULL DEFAULT 0 CHECK (price_kobo >= 0);
ALTER TABLE faith_topics ADD COLUMN access_policy TEXT NOT NULL DEFAULT 'lifetime' CHECK (access_policy IN ('lifetime','days'));
ALTER TABLE faith_topics ADD COLUMN access_days INTEGER;

CREATE TABLE faith_access_new (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  series_id INTEGER REFERENCES faith_series(id) ON DELETE CASCADE,
  topic_id INTEGER REFERENCES faith_topics(id) ON DELETE CASCADE,
  starts_at TEXT NOT NULL,
  expires_at TEXT,
  transaction_id INTEGER UNIQUE REFERENCES transactions(id),
  revoked_at TEXT,
  CHECK ((series_id IS NOT NULL AND topic_id IS NULL) OR (series_id IS NULL AND topic_id IS NOT NULL))
);
INSERT INTO faith_access_new(id,user_id,series_id,starts_at,expires_at,transaction_id,revoked_at)
  SELECT id,user_id,series_id,starts_at,expires_at,transaction_id,revoked_at FROM faith_access;
DROP TABLE faith_access;
ALTER TABLE faith_access_new RENAME TO faith_access;
CREATE INDEX idx_faith_access_user ON faith_access(user_id, series_id);
CREATE INDEX idx_faith_access_topic ON faith_access(user_id, topic_id);

CREATE TABLE transactions_new (
  id INTEGER PRIMARY KEY,
  reference TEXT NOT NULL UNIQUE,
  user_id INTEGER NOT NULL REFERENCES users(id),
  item_type TEXT NOT NULL CHECK (item_type IN ('course','plan','faith','faith_topic')),
  course_id INTEGER REFERENCES courses(id),
  plan_id INTEGER REFERENCES plans(id),
  item_title TEXT NOT NULL,
  division TEXT,
  list_price_kobo INTEGER NOT NULL,
  discount_kobo INTEGER NOT NULL DEFAULT 0,
  amount_kobo INTEGER NOT NULL CHECK (amount_kobo >= 0),
  promo_id INTEGER REFERENCES promos(id),
  method TEXT NOT NULL DEFAULT 'manual_transfer',
  status TEXT NOT NULL DEFAULT 'awaiting_payment' CHECK (status IN
    ('awaiting_payment','pending_verification','info_requested','approved','rejected','cancelled','refunded','failed')),
  provider_ref TEXT,
  info_request TEXT,
  decision_reason TEXT,
  decided_by INTEGER REFERENCES users(id),
  decided_at TEXT,
  submitted_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  faith_series_id INTEGER REFERENCES faith_series(id),
  faith_topic_id INTEGER REFERENCES faith_topics(id),
  CHECK ((item_type='course' AND course_id IS NOT NULL) OR (item_type='plan' AND plan_id IS NOT NULL)
      OR (item_type='faith' AND faith_series_id IS NOT NULL) OR (item_type='faith_topic' AND faith_topic_id IS NOT NULL))
);
INSERT INTO transactions_new(id,reference,user_id,item_type,course_id,plan_id,item_title,division,list_price_kobo,discount_kobo,amount_kobo,promo_id,method,status,
    provider_ref,info_request,decision_reason,decided_by,decided_at,submitted_at,created_at,updated_at,faith_series_id)
  SELECT id,reference,user_id,item_type,course_id,plan_id,item_title,division,list_price_kobo,discount_kobo,amount_kobo,promo_id,method,status,
    provider_ref,info_request,decision_reason,decided_by,decided_at,submitted_at,created_at,updated_at,faith_series_id FROM transactions;
DROP TABLE transactions;
ALTER TABLE transactions_new RENAME TO transactions;
CREATE INDEX idx_tx_status ON transactions(status, created_at);
CREATE INDEX idx_tx_user ON transactions(user_id, created_at);
