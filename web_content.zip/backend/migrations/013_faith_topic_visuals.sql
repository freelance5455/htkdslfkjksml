-- Faith topics can carry an optional icon (a key from the built-in set) or an optional uploaded image.
-- Additive only: two new nullable columns; no existing row or value is changed.
ALTER TABLE faith_topics ADD COLUMN icon TEXT;
ALTER TABLE faith_topics ADD COLUMN image TEXT;
