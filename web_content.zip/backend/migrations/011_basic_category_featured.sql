-- Basic Academic categories: let administrators feature a category on the homepage.
-- Additive only: one new column. Existing Basic categories that are already priced are featured so the homepage keeps
-- showing them (as category cards instead of individual courses); an administrator can untick any of them.
ALTER TABLE categories ADD COLUMN featured INTEGER NOT NULL DEFAULT 0;
UPDATE categories SET featured = 1 WHERE division = 'academic' AND level = 'basic' AND active = 1 AND price_kobo > 0;
