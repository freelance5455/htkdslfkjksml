-- Strict division separation (homepage Income Skills section, course division integrity).
-- Additive and data-safe: no course, price, transaction, entitlement or account is deleted or rebuilt.

-- 1. The homepage section formerly called "Featured Course(s)" is the Income Skills section. Rename any stored title/button that still says "featured".
UPDATE settings SET value = 'Income Skills' WHERE key = 'home.featured_title' AND lower(value) LIKE '%featured%';
UPDATE settings SET value = 'View all Income Skills courses' WHERE key = 'home.featured_button' AND lower(value) LIKE '%featured%';

-- 2. Repair division values ONLY where the intended division can be established reliably: a course that sits in a category whose division
--    is different from its own. The category was chosen explicitly (the course forms never allow a cross-division category), so the
--    course follows its category. Every repair is logged here so it can be reviewed or reversed. Courses with no category, or whose
--    division cannot be proven, are never touched (see: python manage.py audit-divisions).
CREATE TABLE IF NOT EXISTS division_repairs (
  id INTEGER PRIMARY KEY,
  course_id INTEGER NOT NULL,
  old_division TEXT, old_academic_level TEXT, old_subscription_eligible INTEGER, category_id INTEGER,
  new_division TEXT, new_academic_level TEXT,
  reason TEXT,
  repaired_at TEXT NOT NULL DEFAULT (datetime('now'))
);
INSERT INTO division_repairs(course_id, old_division, old_academic_level, old_subscription_eligible, category_id, new_division, new_academic_level, reason)
SELECT c.id, c.division, c.academic_level, c.subscription_eligible, c.category_id, cat.division,
       CASE WHEN cat.division = 'academic' THEN COALESCE(cat.level, 'basic') END,
       'course sat in a category of a different division'
  FROM courses c JOIN categories cat ON cat.id = c.category_id
 WHERE cat.division <> c.division;
UPDATE courses
   SET division = (SELECT division FROM categories WHERE categories.id = courses.category_id),
       academic_level = (SELECT CASE WHEN division = 'academic' THEN COALESCE(level, 'basic') END FROM categories WHERE categories.id = courses.category_id),
       subscription_eligible = CASE WHEN (SELECT division FROM categories WHERE categories.id = courses.category_id) = 'professional' THEN 0 ELSE subscription_eligible END,
       updated_at = datetime('now')
 WHERE category_id IS NOT NULL AND division <> (SELECT division FROM categories WHERE categories.id = courses.category_id);

-- 3. Database-level guard: a course can never be saved into a category of another division.
--    (Only changes to division/category_id are checked, so unrelated updates to old rows are never blocked.)
CREATE TRIGGER IF NOT EXISTS trg_courses_division_insert BEFORE INSERT ON courses
WHEN NEW.category_id IS NOT NULL AND (SELECT division FROM categories WHERE id = NEW.category_id) IS NOT NEW.division
BEGIN SELECT RAISE(ABORT, 'A course must belong to a category of its own division'); END;
CREATE TRIGGER IF NOT EXISTS trg_courses_division_update BEFORE UPDATE OF division, category_id ON courses
WHEN NEW.category_id IS NOT NULL AND (SELECT division FROM categories WHERE id = NEW.category_id) IS NOT NEW.division
BEGIN SELECT RAISE(ABORT, 'A course must belong to a category of its own division'); END;
