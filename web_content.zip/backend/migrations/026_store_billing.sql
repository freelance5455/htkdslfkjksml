-- 026: Google Play Billing / Apple In-App Purchase ledger (ADDITIVE ONLY). Entitlements are still created by the existing payment code
-- (payments._approve -> entitlements), so scopes, expiry, payouts and affiliate rules behave exactly as for website payments.
CREATE TABLE store_purchases (
  id INTEGER PRIMARY KEY,
  platform TEXT NOT NULL CHECK (platform IN ('google_play','app_store')),
  store_txn_id TEXT NOT NULL,              -- Google orderId / Apple transactionId (unique per charge, incl. every renewal)
  original_txn_id TEXT,                    -- Google purchaseToken / Apple originalTransactionId (identifies one subscription across renewals)
  product_id TEXT NOT NULL,
  user_id INTEGER NOT NULL REFERENCES users(id),
  transaction_id INTEGER REFERENCES transactions(id),
  status TEXT NOT NULL DEFAULT 'verified' CHECK (status IN ('verified','refunded','revoked')),
  environment TEXT,                        -- production | sandbox
  purchased_at TEXT, expires_at TEXT,
  store_amount_micros INTEGER, store_currency TEXT,   -- what the store charged (informational: store prices are set in the store consoles)
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (platform, store_txn_id)
);
CREATE INDEX idx_store_purchases_user ON store_purchases(user_id);
CREATE INDEX idx_store_purchases_orig ON store_purchases(platform, original_txn_id);
