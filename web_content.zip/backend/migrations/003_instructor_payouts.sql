-- Tutor earnings ledger + withdrawal requests.
-- One row per approved course sale (kind 'sale'); a refund adds a matching negative 'reversal'.
-- UNIQUE(transaction_id, kind) makes double-crediting impossible.
CREATE TABLE instructor_earnings (
  id INTEGER PRIMARY KEY,
  instructor_id INTEGER NOT NULL REFERENCES users(id),
  transaction_id INTEGER NOT NULL REFERENCES transactions(id),
  course_id INTEGER REFERENCES courses(id),
  kind TEXT NOT NULL CHECK (kind IN ('sale','reversal')),
  gross_kobo INTEGER NOT NULL,           -- what the student paid
  percent REAL NOT NULL,                 -- tutor share % that applied at the time (snapshot)
  amount_kobo INTEGER NOT NULL,          -- tutor's share (negative for reversals)
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (transaction_id, kind)
);
CREATE INDEX idx_earn_instr ON instructor_earnings(instructor_id, created_at);

CREATE TABLE payout_requests (
  id INTEGER PRIMARY KEY,
  instructor_id INTEGER NOT NULL REFERENCES users(id),
  amount_kobo INTEGER NOT NULL CHECK (amount_kobo > 0),
  status TEXT NOT NULL DEFAULT 'requested' CHECK (status IN ('requested','paid','rejected','cancelled')),
  bank_name TEXT NOT NULL,
  account_name TEXT NOT NULL,
  account_number TEXT NOT NULL,
  note TEXT,
  requested_at TEXT NOT NULL DEFAULT (datetime('now')),
  decided_by INTEGER REFERENCES users(id),
  decided_at TEXT,
  reject_reason TEXT,
  receipt_file TEXT,
  receipt_name TEXT,
  receipt_mime TEXT,
  transfer_reference TEXT,
  admin_note TEXT
);
CREATE INDEX idx_payout_status ON payout_requests(status, requested_at);
CREATE INDEX idx_payout_instr ON payout_requests(instructor_id, requested_at);

ALTER TABLE users ADD COLUMN payout_bank TEXT;
ALTER TABLE users ADD COLUMN payout_account_name TEXT;
ALTER TABLE users ADD COLUMN payout_account_number TEXT;

-- Backfill: sales approved before this feature existed are credited at the default 40% (refunded ones never earned).
INSERT INTO instructor_earnings(instructor_id, transaction_id, course_id, kind, gross_kobo, percent, amount_kobo, created_at)
SELECT c.instructor_id, t.id, t.course_id, 'sale', t.amount_kobo, 40, (t.amount_kobo * 40 + 50) / 100, COALESCE(t.decided_at, t.created_at)
FROM transactions t JOIN courses c ON c.id = t.course_id
WHERE t.item_type = 'course' AND t.status = 'approved' AND t.amount_kobo > 0 AND c.instructor_id IS NOT NULL;
