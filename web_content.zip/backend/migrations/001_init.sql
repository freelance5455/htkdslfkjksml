-- Dagba Digital Academy: initial schema (SQLite). All timestamps are UTC 'YYYY-MM-DD HH:MM:SS'.
-- Money is stored as integer kobo (1 NGN = 100 kobo).

CREATE TABLE users (
  id INTEGER PRIMARY KEY,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  phone TEXT,
  role TEXT NOT NULL DEFAULT 'student' CHECK (role IN ('student','instructor','writer','admin')),
  is_owner INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  class_level TEXT,
  bio TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_login_at TEXT
);
-- Granular permissions for staff with role='admin' (the owner implicitly has all).
CREATE TABLE user_permissions (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  permission TEXT NOT NULL,
  PRIMARY KEY (user_id, permission)
);
CREATE TABLE password_resets (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  used_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT);

CREATE TABLE categories (
  id INTEGER PRIMARY KEY,
  division TEXT NOT NULL CHECK (division IN ('academic','income')),
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  position INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE courses (
  id INTEGER PRIMARY KEY,
  division TEXT NOT NULL CHECK (division IN ('academic','income')),
  category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  summary TEXT,
  description TEXT,
  thumbnail TEXT,
  level TEXT,            -- e.g. Junior Secondary / Senior Secondary / Beginner
  class_level TEXT,      -- JSS1..SS3
  subject TEXT,
  term TEXT,
  price_kobo INTEGER NOT NULL DEFAULT 0 CHECK (price_kobo >= 0),
  access_policy TEXT NOT NULL DEFAULT 'lifetime' CHECK (access_policy IN ('lifetime','days')),
  access_days INTEGER,
  subscription_eligible INTEGER NOT NULL DEFAULT 1,
  certificate_enabled INTEGER NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','review','published','archived')),
  featured INTEGER NOT NULL DEFAULT 0,
  instructor_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  seo_title TEXT,
  seo_description TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_courses_listing ON courses(status, division, category_id);
CREATE TABLE modules (
  id INTEGER PRIMARY KEY,
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  position INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE lessons (
  id INTEGER PRIMARY KEY,
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  module_id INTEGER REFERENCES modules(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'text' CHECK (kind IN ('text','video','pdf','embed')),
  body TEXT,
  video_url TEXT,
  resource_file TEXT,
  resource_name TEXT,
  duration_min INTEGER,
  position INTEGER NOT NULL DEFAULT 0,
  free_preview INTEGER NOT NULL DEFAULT 0,
  downloadable INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX idx_lessons_course ON lessons(course_id, position);
CREATE TABLE quizzes (
  id INTEGER PRIMARY KEY,
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  pass_mark INTEGER NOT NULL DEFAULT 50 CHECK (pass_mark BETWEEN 0 AND 100),
  position INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE questions (
  id INTEGER PRIMARY KEY,
  quiz_id INTEGER NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  prompt TEXT NOT NULL,
  options TEXT NOT NULL,           -- one option per line
  correct INTEGER NOT NULL,        -- 1-based option number
  explanation TEXT,
  position INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE quiz_attempts (
  id INTEGER PRIMARY KEY,
  quiz_id INTEGER NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  score_percent INTEGER NOT NULL,
  passed INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_attempts ON quiz_attempts(user_id, quiz_id);
CREATE TABLE assignments (
  id INTEGER PRIMARY KEY,
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  instructions TEXT,
  due_date TEXT,
  max_score INTEGER NOT NULL DEFAULT 100
);
CREATE TABLE submissions (
  id INTEGER PRIMARY KEY,
  assignment_id INTEGER NOT NULL REFERENCES assignments(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body TEXT,
  file TEXT,
  file_name TEXT,
  status TEXT NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted','reviewed')),
  score INTEGER,
  feedback TEXT,
  reviewed_by INTEGER REFERENCES users(id),
  submitted_at TEXT NOT NULL DEFAULT (datetime('now')),
  reviewed_at TEXT,
  UNIQUE (assignment_id, user_id)
);
CREATE TABLE progress (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lesson_id INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  completed_at TEXT,
  position_seconds INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, lesson_id)
);
CREATE INDEX idx_progress_course ON progress(user_id, course_id);
CREATE TABLE announcements (
  id INTEGER PRIMARY KEY,
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  body TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Commerce -------------------------------------------------------------
CREATE TABLE plans (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  division TEXT NOT NULL CHECK (division IN ('academic','income')),
  description TEXT,
  price_kobo INTEGER NOT NULL DEFAULT 0 CHECK (price_kobo >= 0),
  duration_days INTEGER NOT NULL DEFAULT 30 CHECK (duration_days > 0),
  active INTEGER NOT NULL DEFAULT 0,
  position INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE promos (
  id INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE COLLATE NOCASE,
  description TEXT,
  percent_off INTEGER NOT NULL DEFAULT 0 CHECK (percent_off BETWEEN 0 AND 100),
  amount_off_kobo INTEGER NOT NULL DEFAULT 0 CHECK (amount_off_kobo >= 0),
  applies_to TEXT NOT NULL DEFAULT 'all' CHECK (applies_to IN ('all','courses','plans')),
  active INTEGER NOT NULL DEFAULT 1,
  starts_at TEXT,
  expires_at TEXT,
  max_uses INTEGER
);
CREATE TABLE transactions (
  id INTEGER PRIMARY KEY,
  reference TEXT NOT NULL UNIQUE,
  user_id INTEGER NOT NULL REFERENCES users(id),
  item_type TEXT NOT NULL CHECK (item_type IN ('course','plan')),
  course_id INTEGER REFERENCES courses(id),
  plan_id INTEGER REFERENCES plans(id),
  item_title TEXT NOT NULL,
  division TEXT,
  list_price_kobo INTEGER NOT NULL,
  discount_kobo INTEGER NOT NULL DEFAULT 0,
  amount_kobo INTEGER NOT NULL CHECK (amount_kobo >= 0),
  promo_id INTEGER REFERENCES promos(id),
  method TEXT NOT NULL DEFAULT 'manual_transfer',
  status TEXT NOT NULL DEFAULT 'awaiting_payment' CHECK (status IN
    ('awaiting_payment','pending_verification','info_requested','approved','rejected','cancelled','refunded','failed')),
  provider_ref TEXT,
  info_request TEXT,
  decision_reason TEXT,
  decided_by INTEGER REFERENCES users(id),
  decided_at TEXT,
  submitted_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  CHECK ((item_type='course' AND course_id IS NOT NULL) OR (item_type='plan' AND plan_id IS NOT NULL))
);
CREATE INDEX idx_tx_status ON transactions(status, created_at);
CREATE INDEX idx_tx_user ON transactions(user_id, created_at);
CREATE TABLE payment_evidence (
  id INTEGER PRIMARY KEY,
  transaction_id INTEGER NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  file TEXT NOT NULL,
  original_name TEXT,
  mime TEXT NOT NULL,
  size INTEGER NOT NULL,
  transfer_date TEXT,
  sender_name TEXT,
  sender_bank TEXT,
  amount_sent_kobo INTEGER,
  note TEXT,
  submitted_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE payment_notes (
  id INTEGER PRIMARY KEY,
  transaction_id INTEGER NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
  author_id INTEGER NOT NULL REFERENCES users(id),
  note TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
-- One entitlement per approved transaction: the UNIQUE constraint makes duplicate approval impossible.
CREATE TABLE entitlements (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('course','subscription')),
  course_id INTEGER REFERENCES courses(id) ON DELETE CASCADE,
  plan_id INTEGER REFERENCES plans(id) ON DELETE SET NULL,
  division TEXT,
  starts_at TEXT NOT NULL,
  expires_at TEXT,            -- NULL = never expires
  transaction_id INTEGER UNIQUE REFERENCES transactions(id),
  revoked_at TEXT,
  expiry_notified INTEGER NOT NULL DEFAULT 0,
  CHECK ((kind='course' AND course_id IS NOT NULL) OR (kind='subscription' AND division IS NOT NULL))
);
CREATE INDEX idx_ent_user ON entitlements(user_id, kind);

-- Engagement / content ---------------------------------------------------
CREATE TABLE notifications (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL DEFAULT 'info',
  title TEXT NOT NULL,
  body TEXT,
  link TEXT,
  read_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_notif_user ON notifications(user_id, read_at, created_at);
CREATE TABLE certificates (
  id INTEGER PRIMARY KEY,
  cert_id TEXT NOT NULL UNIQUE,
  user_id INTEGER NOT NULL REFERENCES users(id),
  course_id INTEGER NOT NULL REFERENCES courses(id),
  student_name TEXT NOT NULL,
  course_title TEXT NOT NULL,
  issued_at TEXT NOT NULL DEFAULT (datetime('now')),
  revoked_at TEXT,
  revoked_reason TEXT,
  revoked_by INTEGER REFERENCES users(id),
  UNIQUE (user_id, course_id)
);
CREATE TABLE article_categories (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE
);
CREATE TABLE articles (
  id INTEGER PRIMARY KEY,
  category_id INTEGER REFERENCES article_categories(id) ON DELETE SET NULL,
  author_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  excerpt TEXT,
  body TEXT,
  featured_image TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','pending','published','scheduled','archived')),
  publish_at TEXT,
  seo_title TEXT,
  seo_description TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_articles_pub ON articles(status, publish_at);
CREATE TABLE nuggets (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  category TEXT,
  body TEXT,
  image TEXT,
  author_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','pending','published','archived')),
  featured INTEGER NOT NULL DEFAULT 0,
  published_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE testimonials (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  detail TEXT,
  quote TEXT NOT NULL,
  verified INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE faqs (
  id INTEGER PRIMARY KEY,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  position INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE pages (
  id INTEGER PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  body TEXT,
  seo_description TEXT
);
CREATE TABLE newsletter_subscribers (
  id INTEGER PRIMARY KEY,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE contact_messages (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  subject TEXT,
  message TEXT NOT NULL,
  handled INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Platform ---------------------------------------------------------------
CREATE TABLE audit_logs (
  id INTEGER PRIMARY KEY,
  actor_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  actor_label TEXT,
  action TEXT NOT NULL,
  entity TEXT,
  entity_id TEXT,
  detail TEXT,
  ip TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_audit ON audit_logs(entity, entity_id);
CREATE INDEX idx_audit_created ON audit_logs(created_at);
CREATE TABLE rate_events (key TEXT NOT NULL, ts INTEGER NOT NULL);
CREATE INDEX idx_rate ON rate_events(key, ts);
CREATE TABLE webhook_events (
  id INTEGER PRIMARY KEY,
  provider TEXT NOT NULL,
  event_key TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (provider, event_key)
);
