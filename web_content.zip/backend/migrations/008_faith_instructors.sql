-- Faith series can have an instructor (tutor), who earns the same revenue share as a course tutor.
ALTER TABLE faith_series ADD COLUMN instructor_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE instructor_earnings ADD COLUMN faith_series_id INTEGER REFERENCES faith_series(id) ON DELETE SET NULL;
