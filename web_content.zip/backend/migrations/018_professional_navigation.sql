-- Follow-up to 017: the public menus and the default hero slide point at Professional Development's own page.
-- Only stored (edited) menus are touched, and only when they do not already link to /professional; unedited menus use the new built-in defaults.
UPDATE settings SET value = replace(value, 'Income Skills | /income-skills', 'Income Skills | /income-skills' || char(10) || 'Professional Development | /professional')
 WHERE key = 'nav.header' AND value LIKE '%Income Skills | /income-skills%' AND value NOT LIKE '%/professional%';
UPDATE settings SET value = replace(value, 'Courses | /courses', 'Courses | /courses' || char(10) || 'Professional Development | /professional')
 WHERE key = 'nav.footer_explore' AND value LIKE '%Courses | /courses%' AND value NOT LIKE '%/professional%';
UPDATE hero_slides SET cta_url = '/professional' WHERE cta_url = '/academic/professional';
UPDATE hero_slides SET cta2_url = '/professional' WHERE cta2_url = '/academic/professional';
