-- Homepage hero carousel: every slide (text, buttons, image, order, on/off, default) lives in the database and is edited in
-- Admin > Appearance > Homepage hero. Additive only: one new table; no existing table or value is changed.
CREATE TABLE hero_slides (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  label TEXT,                       -- small tag above the headline, e.g. "Academic Learning"
  headline TEXT NOT NULL,
  description TEXT,
  cta_label TEXT, cta_url TEXT,     -- main button
  cta2_label TEXT, cta2_url TEXT,   -- optional second button
  image TEXT,                       -- uploaded picture (file name in the public media folder); variants: <name>-480 / -1200
  image_sizes TEXT,                 -- widths that exist for the image, e.g. "480,800,1200"
  image_alt TEXT,
  art TEXT NOT NULL DEFAULT 'academic',   -- built-in illustration used when there is no picture or it fails to load
  tone TEXT NOT NULL DEFAULT 'purple',    -- colour wash behind the slide: purple | blue | ink
  focus TEXT NOT NULL DEFAULT 'center',   -- which part of the picture stays visible when it is cropped
  active INTEGER NOT NULL DEFAULT 1,
  is_default INTEGER NOT NULL DEFAULT 0,  -- the slide shown first
  position INTEGER NOT NULL DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX idx_hero_slides_order ON hero_slides(active, position);
INSERT INTO hero_slides(label, headline, description, cta_label, cta_url, cta2_label, cta2_url, art, tone, active, is_default, position) VALUES
 ('Academic Learning', 'School subjects, made simple.', 'Clear lessons from secondary school to university, on any phone.', 'Explore academics', '/academic', 'All courses', '/courses', 'academic', 'purple', 1, 1, 1),
 ('Income Skills', 'Skills that pay.', 'Practical, job-ready courses in digital marketing, design, web development and freelancing.', 'Explore income skills', '/income-skills', 'All courses', '/courses', 'income', 'blue', 1, 0, 2),
 ('Faith & Personal Growth', 'Grow in faith. Grow in life.', 'Bible studies, prayer and practical Christian living as video and audio lessons.', 'Explore Faith lessons', '/faith', 'All courses', '/courses', 'faith', 'ink', 1, 0, 3),
 ('Professional Development', 'Advance your career.', 'Prepare for professional exams and certifications. Programmes are launching soon.', 'See what is coming', '/academic/professional', 'All courses', '/courses', 'professional', 'blue', 1, 0, 4);
