-- 025: mobile API foundation (ADDITIVE ONLY: no existing table is altered or dropped).
-- api_sessions: one row per signed-in app install; refresh tokens are stored only as SHA-256 hashes.
CREATE TABLE api_sessions (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  refresh_hash TEXT NOT NULL UNIQUE,
  prev_refresh_hash TEXT,                 -- the previous refresh token: presenting it again means it was stolen/replayed, so the session is revoked
  device_name TEXT, platform TEXT, app_version TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_used_at TEXT,
  expires_at TEXT NOT NULL,
  revoked_at TEXT
);
CREATE INDEX idx_api_sessions_user ON api_sessions(user_id);
-- device_tokens: FCM/APNs push tokens registered by the app (delivery needs Firebase credentials supplied by the owner).
CREATE TABLE device_tokens (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session_id INTEGER REFERENCES api_sessions(id) ON DELETE CASCADE,
  platform TEXT NOT NULL CHECK (platform IN ('android','ios')),
  token TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_seen_at TEXT
);
CREATE INDEX idx_device_tokens_user ON device_tokens(user_id);
-- content_version: bumped by database triggers whenever admin-managed content changes (any route, import or script), so the app knows when to refresh.
CREATE TABLE content_version (id INTEGER PRIMARY KEY CHECK (id = 1), version INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL DEFAULT (datetime('now')));
INSERT INTO content_version(id, version) VALUES (1, 1);

CREATE TRIGGER cv_courses_i AFTER INSERT ON courses BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_courses_u AFTER UPDATE ON courses BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_courses_d AFTER DELETE ON courses BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_modules_i AFTER INSERT ON modules BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_modules_u AFTER UPDATE ON modules BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_modules_d AFTER DELETE ON modules BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_lessons_i AFTER INSERT ON lessons BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_lessons_u AFTER UPDATE ON lessons BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_lessons_d AFTER DELETE ON lessons BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_categories_i AFTER INSERT ON categories BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_categories_u AFTER UPDATE ON categories BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_categories_d AFTER DELETE ON categories BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_plans_i AFTER INSERT ON plans BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_plans_u AFTER UPDATE ON plans BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_plans_d AFTER DELETE ON plans BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_hero_slides_i AFTER INSERT ON hero_slides BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_hero_slides_u AFTER UPDATE ON hero_slides BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_hero_slides_d AFTER DELETE ON hero_slides BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_articles_i AFTER INSERT ON articles BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_articles_u AFTER UPDATE ON articles BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_articles_d AFTER DELETE ON articles BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_article_categories_i AFTER INSERT ON article_categories BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_article_categories_u AFTER UPDATE ON article_categories BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_article_categories_d AFTER DELETE ON article_categories BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_nuggets_i AFTER INSERT ON nuggets BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_nuggets_u AFTER UPDATE ON nuggets BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_nuggets_d AFTER DELETE ON nuggets BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_testimonials_i AFTER INSERT ON testimonials BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_testimonials_u AFTER UPDATE ON testimonials BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_testimonials_d AFTER DELETE ON testimonials BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_faqs_i AFTER INSERT ON faqs BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_faqs_u AFTER UPDATE ON faqs BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_faqs_d AFTER DELETE ON faqs BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_pages_i AFTER INSERT ON pages BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_pages_u AFTER UPDATE ON pages BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_pages_d AFTER DELETE ON pages BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_settings_i AFTER INSERT ON settings BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_settings_u AFTER UPDATE ON settings BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_settings_d AFTER DELETE ON settings BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_learning_paths_i AFTER INSERT ON learning_paths BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_learning_paths_u AFTER UPDATE ON learning_paths BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_learning_paths_d AFTER DELETE ON learning_paths BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_learning_path_courses_i AFTER INSERT ON learning_path_courses BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_learning_path_courses_u AFTER UPDATE ON learning_path_courses BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_learning_path_courses_d AFTER DELETE ON learning_path_courses BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_path_prerequisites_i AFTER INSERT ON path_prerequisites BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_path_prerequisites_u AFTER UPDATE ON path_prerequisites BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_path_prerequisites_d AFTER DELETE ON path_prerequisites BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_faith_topics_i AFTER INSERT ON faith_topics BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_faith_topics_u AFTER UPDATE ON faith_topics BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_faith_topics_d AFTER DELETE ON faith_topics BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_faith_series_i AFTER INSERT ON faith_series BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_faith_series_u AFTER UPDATE ON faith_series BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_faith_series_d AFTER DELETE ON faith_series BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_faith_items_i AFTER INSERT ON faith_items BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_faith_items_u AFTER UPDATE ON faith_items BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_faith_items_d AFTER DELETE ON faith_items BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_quizzes_i AFTER INSERT ON quizzes BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_quizzes_u AFTER UPDATE ON quizzes BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_quizzes_d AFTER DELETE ON quizzes BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_questions_i AFTER INSERT ON questions BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_questions_u AFTER UPDATE ON questions BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_questions_d AFTER DELETE ON questions BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_assignments_i AFTER INSERT ON assignments BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_assignments_u AFTER UPDATE ON assignments BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_assignments_d AFTER DELETE ON assignments BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_announcements_i AFTER INSERT ON announcements BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_announcements_u AFTER UPDATE ON announcements BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_announcements_d AFTER DELETE ON announcements BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_tutor_profiles_i AFTER INSERT ON tutor_profiles BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_tutor_profiles_u AFTER UPDATE ON tutor_profiles BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
CREATE TRIGGER cv_tutor_profiles_d AFTER DELETE ON tutor_profiles BEGIN UPDATE content_version SET version=version+1, updated_at=datetime('now') WHERE id=1; END;
