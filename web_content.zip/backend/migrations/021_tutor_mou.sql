-- Tutor Memorandum of Understanding (MOU) and electronic acceptance. Additive only: no existing table is changed and no existing row is touched.
--
--   mou_documents    the agreement series ("Tutor Memorandum of Understanding"); one row today, room for more.
--   mou_versions     every draft and every published version. A published version is IMMUTABLE (enforced by triggers below): editing the
--                    MOU creates a new draft, and publishing that draft gives it the next version number (1.0, 1.1, 2.0 ...).
--   mou_views        proof that the applicant was shown a given published version before signing (written when the document is rendered to them).
--   mou_acceptances  one signed agreement per person per version. It stores a permanent snapshot of the exact text accepted, a SHA-256
--                    of that snapshot and of the whole record, and is IMMUTABLE and undeletable (triggers). Nothing here is generated
--                    from the editable MOU after the fact.

CREATE TABLE mou_documents (
  id INTEGER PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
INSERT INTO mou_documents(slug, title) VALUES ('tutor-mou', 'Tutor Memorandum of Understanding');

CREATE TABLE mou_versions (
  id INTEGER PRIMARY KEY,
  document_id INTEGER NOT NULL REFERENCES mou_documents(id),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published')),
  title TEXT NOT NULL,
  body_html TEXT NOT NULL DEFAULT '',                     -- sanitised HTML (whitelist) produced by services/mou.py
  change_type TEXT NOT NULL DEFAULT 'minor' CHECK (change_type IN ('minor','major')),   -- decides the next number when published
  change_note TEXT,                                       -- what changed, for the admin history
  based_on_id INTEGER REFERENCES mou_versions(id),
  version_major INTEGER, version_minor INTEGER,
  version_label TEXT,                                     -- '1.0', '1.1', '2.0' - assigned automatically at publication
  content_hash TEXT,                                      -- SHA-256 of title + body at publication
  created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_by INTEGER REFERENCES users(id), updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  published_by INTEGER REFERENCES users(id), published_at TEXT,
  CHECK ((status = 'draft'     AND version_label IS NULL AND published_at IS NULL)
      OR (status = 'published' AND version_label IS NOT NULL AND version_major IS NOT NULL AND version_minor IS NOT NULL AND published_at IS NOT NULL AND content_hash IS NOT NULL))
);
CREATE UNIQUE INDEX uq_mou_version_label ON mou_versions(document_id, version_label) WHERE status = 'published';
CREATE UNIQUE INDEX uq_mou_version_num   ON mou_versions(document_id, version_major, version_minor) WHERE status = 'published';
CREATE UNIQUE INDEX uq_mou_one_draft     ON mou_versions(document_id) WHERE status = 'draft';
CREATE INDEX idx_mou_versions_pub        ON mou_versions(document_id, status, version_major, version_minor);

-- A published version can never be edited or deleted; a draft may be edited, discarded, or promoted to published (once).
CREATE TRIGGER trg_mou_versions_no_update BEFORE UPDATE ON mou_versions
WHEN OLD.status = 'published'
BEGIN SELECT RAISE(ABORT, 'A published MOU version is immutable. Create a new version instead.'); END;
CREATE TRIGGER trg_mou_versions_no_delete BEFORE DELETE ON mou_versions
WHEN OLD.status = 'published'
BEGIN SELECT RAISE(ABORT, 'A published MOU version cannot be deleted.'); END;
CREATE TRIGGER trg_mou_versions_no_unpublish BEFORE UPDATE OF status ON mou_versions
WHEN NEW.status = 'draft' AND OLD.status != 'draft'
BEGIN SELECT RAISE(ABORT, 'A MOU version cannot go back to draft.'); END;

CREATE TABLE mou_views (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  version_id INTEGER NOT NULL REFERENCES mou_versions(id),
  first_viewed_at TEXT NOT NULL DEFAULT (datetime('now')),
  ip_address TEXT,
  UNIQUE (user_id, version_id)
);

CREATE TABLE mou_acceptances (
  id INTEGER PRIMARY KEY,
  reference TEXT NOT NULL UNIQUE,                          -- agreement reference number, e.g. DDA-MOU-2026-7K3QZ9AB (random: not guessable from another)
  user_id INTEGER NOT NULL REFERENCES users(id),           -- no cascade: a signed agreement cannot be removed by deleting an account
  application_id INTEGER REFERENCES tutor_applications(id),
  version_id INTEGER NOT NULL REFERENCES mou_versions(id),
  version_label TEXT NOT NULL,
  document_title TEXT NOT NULL,
  content_html TEXT NOT NULL,                              -- permanent snapshot of the exact text accepted
  content_hash TEXT NOT NULL,                              -- SHA-256 of title + snapshot (must equal mou_versions.content_hash)
  full_name TEXT NOT NULL,                                 -- registered legal name at the time
  email TEXT NOT NULL,                                     -- registered email at the time
  signature TEXT NOT NULL,                                 -- the name the applicant typed as their electronic signature
  agreement_text TEXT NOT NULL,                            -- the checkbox wording they ticked
  confirmation_text TEXT NOT NULL,                         -- the acknowledgement shown beside the signature
  accepted_at TEXT NOT NULL DEFAULT (datetime('now')),     -- UTC
  ip_address TEXT, user_agent TEXT,
  record_hash TEXT NOT NULL,                               -- SHA-256 over every field above: detects later tampering
  UNIQUE (user_id, version_id)                             -- repeated submissions cannot create a second record for the same version
);
CREATE INDEX idx_mou_acc_user    ON mou_acceptances(user_id, accepted_at);
CREATE INDEX idx_mou_acc_version ON mou_acceptances(version_id);
CREATE INDEX idx_mou_acc_app     ON mou_acceptances(application_id);
CREATE INDEX idx_mou_acc_date    ON mou_acceptances(accepted_at);

CREATE TRIGGER trg_mou_acc_no_update BEFORE UPDATE ON mou_acceptances
BEGIN SELECT RAISE(ABORT, 'A signed agreement is immutable.'); END;
CREATE TRIGGER trg_mou_acc_no_delete BEFORE DELETE ON mou_acceptances
BEGIN SELECT RAISE(ABORT, 'A signed agreement cannot be deleted.'); END;
-- The snapshot must be the published text of the version it names, byte for byte (by hash).
CREATE TRIGGER trg_mou_acc_snapshot BEFORE INSERT ON mou_acceptances
WHEN NOT EXISTS (SELECT 1 FROM mou_versions v WHERE v.id = NEW.version_id AND v.status = 'published' AND v.content_hash = NEW.content_hash AND v.version_label = NEW.version_label)
BEGIN SELECT RAISE(ABORT, 'The agreement must reference a published MOU version and its exact content.'); END;
