-- Faith & Spiritual Growth: a native part of the learning ecosystem (same accounts, same admin, same uploads).
-- Purely additive: no existing table is changed except `uploads`, which is rebuilt only to allow audio files
-- (SQLite cannot alter a CHECK constraint). Existing upload rows are copied across unchanged.

CREATE TABLE faith_topics (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  position INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1
);

-- A series is an ordered study (for example "The Gospel of John" or "Learning to Pray").
CREATE TABLE faith_series (
  id INTEGER PRIMARY KEY,
  topic_id INTEGER NOT NULL REFERENCES faith_topics(id) ON DELETE RESTRICT,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  summary TEXT,
  description TEXT,
  cover TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  featured INTEGER NOT NULL DEFAULT 0,
  position INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_faith_series ON faith_series(topic_id, status);

-- A lesson: video, audio, reading or study guide. Any lesson may combine several (e.g. a video plus its audio and a PDF guide);
-- `kind` is the main format and decides what is required to publish.
CREATE TABLE faith_items (
  id INTEGER PRIMARY KEY,
  topic_id INTEGER NOT NULL REFERENCES faith_topics(id) ON DELETE RESTRICT,
  series_id INTEGER REFERENCES faith_series(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  kind TEXT NOT NULL DEFAULT 'reading' CHECK (kind IN ('video','audio','reading','study')),
  summary TEXT,
  body TEXT,
  scripture TEXT,
  speaker TEXT,
  video_url TEXT,
  video_file TEXT,
  video_name TEXT,
  audio_url TEXT,
  audio_file TEXT,
  audio_name TEXT,
  resource_file TEXT,
  resource_name TEXT,
  thumbnail TEXT,
  duration_min INTEGER,
  position INTEGER NOT NULL DEFAULT 0,
  access TEXT NOT NULL DEFAULT 'public' CHECK (access IN ('public','members')),
  downloadable INTEGER NOT NULL DEFAULT 1,
  featured INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived')),
  published_at TEXT,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_faith_items_list ON faith_items(status, topic_id, kind);
CREATE INDEX idx_faith_items_series ON faith_items(series_id, position);

-- Per-learner progress and bookmarks (same idea as `progress`, kept separate so course certificates and reports are untouched).
CREATE TABLE faith_progress (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  item_id INTEGER NOT NULL REFERENCES faith_items(id) ON DELETE CASCADE,
  completed_at TEXT,
  position_seconds INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, item_id)
);
CREATE INDEX idx_faith_progress_user ON faith_progress(user_id, updated_at);
CREATE TABLE faith_saved (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  item_id INTEGER NOT NULL REFERENCES faith_items(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, item_id)
);

INSERT INTO faith_topics(name, slug, description, position) VALUES
 ('Bible Studies', 'bible-studies', 'Walk through Scripture book by book and theme by theme, with clear explanations you can follow.', 0),
 ('Christian Living', 'christian-living', 'Live out your faith in everyday life: at school, at work, with money and in your community.', 1),
 ('Prayer', 'prayer', 'Learn to pray, build a steady habit of prayer, and grow in trusting God.', 2),
 ('Biblical Wisdom', 'biblical-wisdom', 'Timeless wisdom from Proverbs, the Psalms and the teaching of Jesus for the decisions you face.', 3),
 ('Relationships', 'relationships', 'Family, marriage, friendship and community, as Scripture describes them.', 4),
 ('Spiritual Growth', 'spiritual-growth', 'Disciplines, character and maturity that deepen your walk with God.', 5);

-- Allow audio uploads (rebuild of the small `uploads` bookkeeping table; nothing references it).
CREATE TABLE uploads_new (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('video','audio','resource')),
  original_name TEXT,
  size INTEGER NOT NULL,
  next_index INTEGER NOT NULL DEFAULT 0,
  received INTEGER NOT NULL DEFAULT 0,
  stored_name TEXT,
  status TEXT NOT NULL DEFAULT 'partial' CHECK (status IN ('partial','ready')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
INSERT INTO uploads_new(id,user_id,kind,original_name,size,next_index,received,stored_name,status,created_at)
  SELECT id,user_id,kind,original_name,size,next_index,received,stored_name,status,created_at FROM uploads;
DROP TABLE uploads;
ALTER TABLE uploads_new RENAME TO uploads;
CREATE INDEX idx_uploads_stored ON uploads(stored_name);

-- Put the new section in the header menu and footer of EXISTING sites. Only touches a menu the owner has already saved
-- (a fresh install gets it from the built-in default), never removes anything, and never adds it twice.
UPDATE settings SET value = replace(value, 'Pricing | /pricing', 'Faith | /faith' || char(10) || 'Pricing | /pricing')
 WHERE key = 'c.nav.header' AND value NOT LIKE '%| /faith%' AND value LIKE '%Pricing | /pricing%';
UPDATE settings SET value = value || char(10) || 'Faith | /faith'
 WHERE key = 'c.nav.header' AND value NOT LIKE '%| /faith%' AND trim(value) <> '';
UPDATE settings SET value = value || char(10) || 'Faith & Spiritual Growth | /faith'
 WHERE key = 'c.nav.footer_explore' AND value NOT LIKE '%| /faith%' AND trim(value) <> '';
