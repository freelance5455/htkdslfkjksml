-- Academic section restructure: Basic / Advanced / Professional Development.
-- Nothing is deleted or duplicated. Existing academic subjects become Basic subjects; existing academic courses become
-- Basic courses (they were all secondary-school oriented). Courses whose subject cannot be determined reliably are
-- kept, still visible, and flagged (needs_review) so an administrator can reassign them.
ALTER TABLE categories ADD COLUMN level TEXT CHECK (level IN ('basic','advanced','professional'));
ALTER TABLE courses ADD COLUMN academic_level TEXT CHECK (academic_level IN ('basic','advanced','professional'));
ALTER TABLE courses ADD COLUMN needs_review INTEGER NOT NULL DEFAULT 0;
CREATE INDEX idx_courses_level ON courses(division, academic_level, category_id, status);

UPDATE categories SET level = 'basic' WHERE division = 'academic';

-- Advanced (university-level) subjects: structure only, no courses.
INSERT OR IGNORE INTO categories(division, level, name, slug, position) VALUES
 ('academic','advanced','Mathematics','advanced-mathematics',0), ('academic','advanced','Physics','advanced-physics',1),
 ('academic','advanced','Chemistry','advanced-chemistry',2), ('academic','advanced','Biology','advanced-biology',3),
 ('academic','advanced','Economics','advanced-economics',4), ('academic','advanced','Accounting','advanced-accounting',5),
 ('academic','advanced','Computer Science','advanced-computer-science',6), ('academic','advanced','Statistics','advanced-statistics',7),
 ('academic','advanced','Engineering','advanced-engineering',8), ('academic','advanced','Business Administration','advanced-business-administration',9),
 ('academic','advanced','Political Science','advanced-political-science',10), ('academic','advanced','Law','advanced-law',11),
 ('academic','advanced','Other University Subjects','advanced-other-university-subjects',12);

UPDATE courses SET academic_level = 'basic' WHERE division = 'academic';
-- A course with no subject but a subject name typed in the old free-text field: link it when the name matches a Basic subject exactly.
UPDATE courses SET category_id = (SELECT id FROM categories WHERE division='academic' AND level='basic' AND lower(name)=lower(trim(courses.subject)) LIMIT 1)
 WHERE division='academic' AND category_id IS NULL AND subject IS NOT NULL AND trim(subject) <> '';
-- Reliable = sits in one of the standard secondary-school subjects. Everything else is flagged for manual review.
UPDATE courses SET needs_review = 1
 WHERE division='academic' AND (category_id IS NULL OR category_id NOT IN (SELECT id FROM categories WHERE slug LIKE 'academic-%'));

-- The seeded About page described the old class system. Replace only that exact sentence; text the owner has edited is left alone.
UPDATE pages SET body = replace(body,
  'Our academic courses support JSS1 to SS3 learners, including WAEC preparation, while',
  'Our academic courses are organised into Basic (secondary school), Advanced (university level) and, soon, Professional Development programmes, while')
 WHERE slug = 'about';
