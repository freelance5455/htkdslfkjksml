-- Affiliate / influencer programme.
-- An affiliate is a normal user account plus a row here. `percent` NULL = use the site-wide default (Settings > Affiliates).
-- A person who signs up after following an affiliate's link is locked to that affiliate in users.referred_by_affiliate,
-- so every later purchase is credited to them, from any device, even if the person never uses the link again.
CREATE TABLE affiliates (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL UNIQUE REFERENCES users(id),
  slug TEXT NOT NULL UNIQUE COLLATE NOCASE,
  percent REAL CHECK (percent IS NULL OR (percent >= 0 AND percent <= 100)),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','removed')),
  created_by INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  removed_at TEXT
);

ALTER TABLE users ADD COLUMN referred_by_affiliate INTEGER REFERENCES affiliates(id);
ALTER TABLE users ADD COLUMN referred_at TEXT;
CREATE INDEX idx_users_referred ON users(referred_by_affiliate);

-- One row per landing on an affiliate link (de-duplicated per visitor per 30 minutes in code).
CREATE TABLE affiliate_clicks (
  id INTEGER PRIMARY KEY,
  affiliate_id INTEGER NOT NULL REFERENCES affiliates(id),
  visitor TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_aclick ON affiliate_clicks(affiliate_id, created_at);

-- Commission ledger. One 'sale' per approved purchase; a refund adds a matching negative 'reversal'.
-- UNIQUE(transaction_id, kind) makes double-crediting impossible. `percent` is a snapshot of the rate that applied.
CREATE TABLE affiliate_earnings (
  id INTEGER PRIMARY KEY,
  affiliate_id INTEGER NOT NULL REFERENCES affiliates(id),
  transaction_id INTEGER NOT NULL REFERENCES transactions(id),
  buyer_id INTEGER REFERENCES users(id),
  kind TEXT NOT NULL CHECK (kind IN ('sale','reversal')),
  gross_kobo INTEGER NOT NULL,
  percent REAL NOT NULL,
  amount_kobo INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (transaction_id, kind)
);
CREATE INDEX idx_aearn ON affiliate_earnings(affiliate_id, created_at);

CREATE TABLE affiliate_payouts (
  id INTEGER PRIMARY KEY,
  affiliate_id INTEGER NOT NULL REFERENCES affiliates(id),
  amount_kobo INTEGER NOT NULL CHECK (amount_kobo > 0),
  status TEXT NOT NULL DEFAULT 'requested' CHECK (status IN ('requested','paid','rejected','cancelled')),
  bank_name TEXT NOT NULL,
  account_name TEXT NOT NULL,
  account_number TEXT NOT NULL,
  requested_at TEXT NOT NULL DEFAULT (datetime('now')),
  decided_by INTEGER REFERENCES users(id),
  decided_at TEXT,
  reject_reason TEXT,
  receipt_file TEXT,
  receipt_name TEXT,
  receipt_mime TEXT,
  transfer_reference TEXT,
  admin_note TEXT
);
CREATE INDEX idx_apayout ON affiliate_payouts(status, requested_at);
CREATE INDEX idx_apayout_aff ON affiliate_payouts(affiliate_id, requested_at);
