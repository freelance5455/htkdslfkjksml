-- Faith: admins can assign topics to tutors (many-to-many), and tutor lessons go through a review step.
-- Additive only: one new table and three nullable columns. No existing row, status or permission is changed.
CREATE TABLE faith_topic_tutors (
  topic_id INTEGER NOT NULL REFERENCES faith_topics(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  assigned_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  assigned_at TEXT NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (topic_id, user_id)
);
CREATE INDEX idx_faith_topic_tutors_user ON faith_topic_tutors(user_id);
-- A lesson is "awaiting review" while status='draft' AND submitted_at IS NOT NULL (status keeps its existing draft/published/archived values).
ALTER TABLE faith_items ADD COLUMN submitted_at TEXT;
ALTER TABLE faith_items ADD COLUMN review_note TEXT;
ALTER TABLE faith_items ADD COLUMN reviewed_at TEXT;
