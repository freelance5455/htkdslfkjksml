-- Subject-level pricing for all three subject-sold divisions: Academic Basic, Academic Advanced and Professional Development
-- (Income Skills keeps individual course pricing).
--
-- No table is rebuilt and nothing is deleted. The schema from migrations 010-018 already holds everything needed:
--   categories.price_kobo / featured / image / active / access_policy / access_days   (subject price, homepage featuring, cover image, status)
--   entitlements(kind='subject', category_id, division, level)                       (subject purchases)
--   transactions(item_type='subject', subject_id)                                    (subject payments)
-- Existing Basic subject purchases, individual course purchases, subscriptions, prices and transactions are untouched.

-- 1. Fast "does this person own this subject" lookups (used on every course/lesson access check).
CREATE INDEX IF NOT EXISTS idx_ent_subject ON entitlements(user_id, category_id) WHERE kind = 'subject';

-- 2. Make sure every existing subject purchase records its own division and level (older Basic purchases already do; this only fills gaps).
UPDATE entitlements
   SET division = (SELECT division FROM categories WHERE categories.id = entitlements.category_id),
       level    = (SELECT CASE WHEN division = 'professional' THEN 'professional' ELSE COALESCE(level, 'basic') END FROM categories WHERE categories.id = entitlements.category_id)
 WHERE kind = 'subject' AND category_id IS NOT NULL AND (division IS NULL OR level IS NULL);

-- 3. Professional Development subjects (programme areas) can now be shown as homepage subject cards.
--    Existing active ones are featured so the homepage keeps showing Professional Development; an administrator can untick any of them.
UPDATE categories SET featured = 1 WHERE division = 'professional' AND active = 1;
