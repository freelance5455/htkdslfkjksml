-- Interactive learning: scheduled release, lesson/course discussions, learning paths with prerequisites.
-- Additive only: two nullable columns and new tables. No existing row is changed.

-- Scheduled release: UTC 'YYYY-MM-DD HH:MM:SS', NULL = available as soon as the student has access. A lesson opens at the LATER of its own
-- date and its module's date.
ALTER TABLE modules ADD COLUMN release_at TEXT;
ALTER TABLE lessons ADD COLUMN release_at TEXT;
CREATE INDEX idx_lessons_release ON lessons(course_id, release_at);

-- Discussions. lesson_id NULL = the course-wide discussion. parent_id NULL = a question; otherwise a reply to that question (one level deep).
-- A moderator "removes" a post (status='removed', kept with who/when/why for oversight and restore).
CREATE TABLE discussion_posts (
  id INTEGER PRIMARY KEY,
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  lesson_id INTEGER REFERENCES lessons(id) ON DELETE CASCADE,
  parent_id INTEGER REFERENCES discussion_posts(id) ON DELETE CASCADE,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  body TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'visible' CHECK (status IN ('visible','removed')),
  removed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  removed_at TEXT,
  removed_reason TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_posts_scope  ON discussion_posts(course_id, lesson_id, parent_id, created_at);
CREATE INDEX idx_posts_parent ON discussion_posts(parent_id);
CREATE INDEX idx_posts_user   ON discussion_posts(user_id);

-- Learning paths: related courses in a recommended order. Prerequisites belong to a path and only apply while the path is published.
CREATE TABLE learning_paths (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  summary TEXT,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published')),
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE learning_path_courses (
  path_id INTEGER NOT NULL REFERENCES learning_paths(id) ON DELETE CASCADE,
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  position INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (path_id, course_id)
);
CREATE INDEX idx_lpc_course ON learning_path_courses(course_id);
CREATE TABLE path_prerequisites (
  path_id INTEGER NOT NULL REFERENCES learning_paths(id) ON DELETE CASCADE,
  course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  requires_course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  PRIMARY KEY (path_id, course_id, requires_course_id),
  CHECK (course_id <> requires_course_id)
);
CREATE INDEX idx_pp_course ON path_prerequisites(course_id);
