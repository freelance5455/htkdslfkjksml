-- @foreign_keys_off
-- Pricing restructure: Basic subjects are bought (one price unlocks every course under the subject), Basic and Advanced
-- each have an independent subscription, Professional Development has none.
-- Rebuilds `transactions` (new item type 'subject') and `entitlements` (new kind 'subject' + level/category columns).
-- Every existing row is copied unchanged; the runner verifies foreign keys before committing.

ALTER TABLE categories ADD COLUMN price_kobo INTEGER NOT NULL DEFAULT 0 CHECK (price_kobo >= 0);
ALTER TABLE categories ADD COLUMN access_policy TEXT NOT NULL DEFAULT 'lifetime' CHECK (access_policy IN ('lifetime','days'));
ALTER TABLE categories ADD COLUMN access_days INTEGER;
ALTER TABLE plans ADD COLUMN level TEXT CHECK (level IN ('basic','advanced'));

UPDATE plans SET level='basic' WHERE division='academic';
UPDATE plans SET name='Basic Subscription' WHERE division='academic' AND name='Academic Subscription';
INSERT INTO plans(name, division, level, description, price_kobo, duration_days, active, position)
  SELECT 'Advanced Subscription','academic','advanced','Access to every Advanced (university-level) course included in the subscription.',0,30,0,
         COALESCE((SELECT MAX(position) FROM plans),0)+1
  WHERE NOT EXISTS (SELECT 1 FROM plans WHERE level='advanced');

CREATE TABLE entitlements_new (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('course','subscription','subject')),
  course_id INTEGER REFERENCES courses(id) ON DELETE CASCADE,
  plan_id INTEGER REFERENCES plans(id) ON DELETE SET NULL,
  division TEXT,
  starts_at TEXT NOT NULL,
  expires_at TEXT,
  transaction_id INTEGER UNIQUE REFERENCES transactions(id),
  revoked_at TEXT,
  expiry_notified INTEGER NOT NULL DEFAULT 0,
  level TEXT,
  category_id INTEGER REFERENCES categories(id) ON DELETE CASCADE,
  CHECK ((kind='course' AND course_id IS NOT NULL) OR (kind='subscription' AND division IS NOT NULL)
      OR (kind='subject' AND category_id IS NOT NULL))
);
INSERT INTO entitlements_new(id,user_id,kind,course_id,plan_id,division,starts_at,expires_at,transaction_id,revoked_at,expiry_notified,level)
  SELECT id,user_id,kind,course_id,plan_id,division,starts_at,expires_at,transaction_id,revoked_at,expiry_notified,
         CASE WHEN kind='subscription' THEN CASE WHEN division='academic' THEN 'basic' ELSE 'income' END END FROM entitlements;
DROP TABLE entitlements;
ALTER TABLE entitlements_new RENAME TO entitlements;
CREATE INDEX idx_ent_user ON entitlements(user_id, kind);

CREATE TABLE transactions_new (
  id INTEGER PRIMARY KEY,
  reference TEXT NOT NULL UNIQUE,
  user_id INTEGER NOT NULL REFERENCES users(id),
  item_type TEXT NOT NULL CHECK (item_type IN ('course','plan','faith','faith_topic','subject')),
  course_id INTEGER REFERENCES courses(id),
  plan_id INTEGER REFERENCES plans(id),
  item_title TEXT NOT NULL,
  division TEXT,
  list_price_kobo INTEGER NOT NULL,
  discount_kobo INTEGER NOT NULL DEFAULT 0,
  amount_kobo INTEGER NOT NULL CHECK (amount_kobo >= 0),
  promo_id INTEGER REFERENCES promos(id),
  method TEXT NOT NULL DEFAULT 'manual_transfer',
  status TEXT NOT NULL DEFAULT 'awaiting_payment' CHECK (status IN
    ('awaiting_payment','pending_verification','info_requested','approved','rejected','cancelled','refunded','failed')),
  provider_ref TEXT,
  info_request TEXT,
  decision_reason TEXT,
  decided_by INTEGER REFERENCES users(id),
  decided_at TEXT,
  submitted_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  faith_series_id INTEGER REFERENCES faith_series(id),
  faith_topic_id INTEGER REFERENCES faith_topics(id),
  subject_id INTEGER REFERENCES categories(id),
  CHECK ((item_type='course' AND course_id IS NOT NULL) OR (item_type='plan' AND plan_id IS NOT NULL)
      OR (item_type='faith' AND faith_series_id IS NOT NULL) OR (item_type='faith_topic' AND faith_topic_id IS NOT NULL)
      OR (item_type='subject' AND subject_id IS NOT NULL))
);
INSERT INTO transactions_new(id,reference,user_id,item_type,course_id,plan_id,item_title,division,list_price_kobo,discount_kobo,amount_kobo,promo_id,method,status,
    provider_ref,info_request,decision_reason,decided_by,decided_at,submitted_at,created_at,updated_at,faith_series_id,faith_topic_id)
  SELECT id,reference,user_id,item_type,course_id,plan_id,item_title,division,list_price_kobo,discount_kobo,amount_kobo,promo_id,method,status,
    provider_ref,info_request,decision_reason,decided_by,decided_at,submitted_at,created_at,updated_at,faith_series_id,faith_topic_id FROM transactions;
DROP TABLE transactions;
ALTER TABLE transactions_new RENAME TO transactions;
CREATE INDEX idx_tx_status ON transactions(status, created_at);
CREATE INDEX idx_tx_user ON transactions(user_id, created_at);
