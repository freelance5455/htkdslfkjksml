-- Tutor programme: applications, tutor profiles, per-course referral links with attribution, commission source/overrides,
-- and one optional profile picture per user. Additive only: existing users, courses, earnings and payouts are untouched
-- (every existing earning row keeps source 'platform', i.e. exactly the rate it was credited at).

ALTER TABLE users ADD COLUMN avatar TEXT;                         -- file name in the public media folder (square, resized); NULL = show initials

ALTER TABLE courses ADD COLUMN outcomes TEXT;                     -- "What you will learn", one point per line
ALTER TABLE courses ADD COLUMN tutor_affiliate_percent REAL;      -- per-course override of the tutor's share on tutor-referred sales (NULL = use tutor/default)
ALTER TABLE courses ADD COLUMN tutor_platform_percent REAL;       -- per-course override of the tutor's share on academy-generated sales

CREATE TABLE tutor_profiles (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  code TEXT NOT NULL UNIQUE COLLATE NOCASE,                       -- the tutor's referral code used in ?ref=CODE
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended')),
  location TEXT, experience TEXT, qualifications TEXT, website TEXT,
  affiliate_percent REAL CHECK (affiliate_percent IS NULL OR (affiliate_percent >= 0 AND affiliate_percent <= 100)),
  platform_percent REAL CHECK (platform_percent IS NULL OR (platform_percent >= 0 AND platform_percent <= 100)),
  suspended_at TEXT, suspended_by INTEGER REFERENCES users(id), suspended_reason TEXT, suspended_courses TEXT,
  application_id INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE tutor_applications (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  kind TEXT NOT NULL DEFAULT 'tutor' CHECK (kind IN ('tutor','course')),   -- 'tutor' = becoming a tutor; 'course' = a new course from an existing tutor
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','pending','revision','approved','rejected')),
  full_name TEXT, phone TEXT, location TEXT, bio TEXT, experience TEXT, qualifications TEXT, website TEXT,
  category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
  title TEXT, summary TEXT, description TEXT, curriculum TEXT, outcomes TEXT, cover_image TEXT,
  expected_price_kobo INTEGER NOT NULL DEFAULT 0 CHECK (expected_price_kobo >= 0),
  approved_price_kobo INTEGER CHECK (approved_price_kobo IS NULL OR approved_price_kobo >= 0),
  course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
  feedback TEXT,
  reviewed_by INTEGER REFERENCES users(id), reviewed_at TEXT, submitted_at TEXT, approved_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_tapp_status ON tutor_applications(status, submitted_at);
CREATE INDEX idx_tapp_user ON tutor_applications(user_id, status);
CREATE INDEX idx_tapp_course ON tutor_applications(course_id);

-- History of every step and every message between the reviewer and the applicant.
CREATE TABLE tutor_application_events (
  id INTEGER PRIMARY KEY,
  application_id INTEGER NOT NULL REFERENCES tutor_applications(id) ON DELETE CASCADE,
  actor_id INTEGER REFERENCES users(id),
  event TEXT NOT NULL,
  note TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_tevent_app ON tutor_application_events(application_id, id);

-- Landings on a tutor's referral link (analytics only).
CREATE TABLE tutor_clicks (
  id INTEGER PRIMARY KEY,
  tutor_id INTEGER NOT NULL REFERENCES users(id),
  course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
  visitor TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_tclick ON tutor_clicks(tutor_id, created_at);

-- A signed-in person's current referral (last link wins), so the 30-day window follows them across devices and sessions.
CREATE TABLE tutor_referrals (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  tutor_id INTEGER NOT NULL REFERENCES users(id),
  course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
  code TEXT NOT NULL,
  clicked_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);

ALTER TABLE transactions ADD COLUMN tutor_ref_id INTEGER REFERENCES users(id);   -- tutor whose link brought this buyer (snapshotted when the order is created)
ALTER TABLE transactions ADD COLUMN tutor_ref_code TEXT;

ALTER TABLE instructor_earnings ADD COLUMN source TEXT NOT NULL DEFAULT 'platform' CHECK (source IN ('platform','affiliate'));
ALTER TABLE instructor_earnings ADD COLUMN ref_code TEXT;
ALTER TABLE instructor_earnings ADD COLUMN rate_basis TEXT;                      -- which rule set the percent: course | tutor | division | default
CREATE INDEX idx_earn_source ON instructor_earnings(instructor_id, source);

-- Backfill: every existing tutor gets a profile and a referral code; courses already waiting for review join the review queue.
INSERT INTO tutor_profiles(user_id, code) SELECT id, 't' || id || '-' || lower(hex(randomblob(3))) FROM users WHERE role = 'instructor';
INSERT INTO tutor_applications(user_id, kind, status, full_name, title, summary, description, expected_price_kobo, course_id, submitted_at)
SELECT c.instructor_id, 'course', 'pending', u.full_name, c.title, c.summary, c.description, c.price_kobo, c.id, c.updated_at
FROM courses c JOIN users u ON u.id = c.instructor_id WHERE c.status = 'review' AND u.role = 'instructor';
