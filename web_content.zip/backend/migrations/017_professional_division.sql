-- @foreign_keys_off
-- Professional Development becomes its own main division (independent of Academic, like Income Skills):
--   Academic (Basic, Advanced)  |  Income Skills  |  Professional Development
-- SQLite cannot relax a CHECK constraint in place, so `categories` and `courses` are rebuilt with division IN ('academic','income','professional').
-- Every row is copied unchanged first (same ids, so every course, lesson, enrolment, payment, certificate and earning keeps its link);
-- the runner verifies foreign keys before committing. Only afterwards are the former "Academic > Professional" programme areas and courses
-- moved to the new division. Nothing is deleted or duplicated.

CREATE TABLE categories_new (
  id INTEGER PRIMARY KEY,
  division TEXT NOT NULL CHECK (division IN ('academic','income','professional')),
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  position INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1
, level TEXT CHECK (level IN ('basic','advanced','professional')), price_kobo INTEGER NOT NULL DEFAULT 0 CHECK (price_kobo >= 0), access_policy TEXT NOT NULL DEFAULT 'lifetime' CHECK (access_policy IN ('lifetime','days')), access_days INTEGER, featured INTEGER NOT NULL DEFAULT 0, image TEXT);
INSERT INTO categories_new(id, division, name, slug, description, position, active, level, price_kobo, access_policy, access_days, featured, image) SELECT id, division, name, slug, description, position, active, level, price_kobo, access_policy, access_days, featured, image FROM categories;
DROP TABLE categories;
ALTER TABLE categories_new RENAME TO categories;

CREATE TABLE courses_new (
  id INTEGER PRIMARY KEY,
  division TEXT NOT NULL CHECK (division IN ('academic','income','professional')),
  category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  summary TEXT,
  description TEXT,
  thumbnail TEXT,
  level TEXT,            -- e.g. Junior Secondary / Senior Secondary / Beginner
  class_level TEXT,      -- JSS1..SS3
  subject TEXT,
  term TEXT,
  price_kobo INTEGER NOT NULL DEFAULT 0 CHECK (price_kobo >= 0),
  access_policy TEXT NOT NULL DEFAULT 'lifetime' CHECK (access_policy IN ('lifetime','days')),
  access_days INTEGER,
  subscription_eligible INTEGER NOT NULL DEFAULT 1,
  certificate_enabled INTEGER NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','review','published','archived')),
  featured INTEGER NOT NULL DEFAULT 0,
  instructor_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  seo_title TEXT,
  seo_description TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
, academic_level TEXT CHECK (academic_level IN ('basic','advanced','professional')), needs_review INTEGER NOT NULL DEFAULT 0, outcomes TEXT, tutor_affiliate_percent REAL, tutor_platform_percent REAL);
INSERT INTO courses_new(id, division, category_id, title, slug, summary, description, thumbnail, level, class_level, subject, term, price_kobo, access_policy, access_days, subscription_eligible, certificate_enabled, status, featured, instructor_id, seo_title, seo_description, created_at, updated_at, academic_level, needs_review, outcomes, tutor_affiliate_percent, tutor_platform_percent) SELECT id, division, category_id, title, slug, summary, description, thumbnail, level, class_level, subject, term, price_kobo, access_policy, access_days, subscription_eligible, certificate_enabled, status, featured, instructor_id, seo_title, seo_description, created_at, updated_at, academic_level, needs_review, outcomes, tutor_affiliate_percent, tutor_platform_percent FROM courses;
DROP TABLE courses;
ALTER TABLE courses_new RENAME TO courses;
CREATE INDEX idx_courses_listing ON courses(status, division, category_id);
CREATE INDEX idx_courses_level ON courses(division, academic_level, category_id, status);
CREATE INDEX idx_courses_division_status ON courses(division, status, category_id);

-- Former Academic > Professional Development moves out of Academic completely. Professional courses never had a subscription.
UPDATE categories SET division='professional', level=NULL WHERE division='academic' AND level='professional';
UPDATE courses SET division='professional', academic_level=NULL, subscription_eligible=0, needs_review=0 WHERE division='academic' AND academic_level='professional';

-- Advanced subjects may be shown on the homepage (empty subjects are never shown); Basic keeps whatever was already featured.
UPDATE categories SET featured=1 WHERE division='academic' AND level='advanced';

-- The homepage section that was called "Featured Courses" is now the Income Skills section (only an untouched default is renamed).
UPDATE settings SET value='Income Skills' WHERE key='home.featured_title' AND lower(trim(value))='featured courses';
