-- Course learning objectives (shown on the course page and the learner's course home). Additive: one nullable column; "outcomes" already exists.
ALTER TABLE courses ADD COLUMN objectives TEXT;      -- "Course objectives", one point per line
