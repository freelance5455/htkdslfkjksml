-- Direct video upload + chunked upload tracking for the course builder.
ALTER TABLE lessons ADD COLUMN video_file TEXT;
ALTER TABLE lessons ADD COLUMN video_name TEXT;
ALTER TABLE lessons ADD COLUMN video_size INTEGER;
CREATE TABLE uploads (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('video','resource')),
  original_name TEXT,
  size INTEGER NOT NULL,
  next_index INTEGER NOT NULL DEFAULT 0,
  received INTEGER NOT NULL DEFAULT 0,
  stored_name TEXT,
  status TEXT NOT NULL DEFAULT 'partial' CHECK (status IN ('partial','ready')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_uploads_stored ON uploads(stored_name);
