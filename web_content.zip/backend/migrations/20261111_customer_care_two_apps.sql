-- HANIMEX Customer Care shared backend. Already applied to project tysaigoafdsjztsbjuso.
-- Keep roles in hanimex_profiles; clients cannot set or modify their own role/permissions.
alter table public.hanimex_profiles
  add column if not exists username text,
  add column if not exists department_id text default 'support',
  add column if not exists permissions jsonb not null default '{}'::jsonb,
  add column if not exists phone text,
  add column if not exists is_active boolean not null default true,
  add column if not exists must_change_password boolean not null default true;
create unique index if not exists hanimex_profiles_username_ci on public.hanimex_profiles(lower(username)) where username is not null;
update public.hanimex_profiles set department_id='support' where department_id is null;
alter table public.hanimex_support_tickets add column if not exists department_id text not null default 'support';
create table if not exists public.hanimex_care_departments(id text primary key,name text not null,active boolean not null default true,sort_order integer not null default 0);
insert into public.hanimex_care_departments(id,name,sort_order) values ('support','خدمة العملاء',1),('delivery','التوصيل',2),('maintenance','الصيانة',3),('satisfaction','رضا العملاء',4) on conflict(id) do update set name=excluded.name,sort_order=excluded.sort_order;
create or replace function public.hanimex_is_admin() returns boolean language sql stable security definer set search_path='' as $$ select exists(select 1 from public.hanimex_profiles p where p.user_id=(select auth.uid()) and p.role='admin' and p.is_active=true); $$;
create or replace function public.hanimex_is_active_staff() returns boolean language sql stable security definer set search_path='' as $$ select exists(select 1 from public.hanimex_profiles p where p.user_id=(select auth.uid()) and p.is_active=true); $$;
create or replace function public.hanimex_care_has(p_permission text) returns boolean language sql stable security definer set search_path='' as $$ select exists(select 1 from public.hanimex_profiles p where p.user_id=(select auth.uid()) and p.is_active=true and (p.role='admin' or coalesce((p.permissions->>p_permission)::boolean,false))); $$;
revoke all on function public.hanimex_is_admin() from public,anon;
revoke all on function public.hanimex_is_active_staff() from public,anon;
revoke all on function public.hanimex_care_has(text) from public,anon;
grant execute on function public.hanimex_is_admin() to authenticated;
grant execute on function public.hanimex_is_active_staff() to authenticated;
grant execute on function public.hanimex_care_has(text) to authenticated;
alter table public.hanimex_profiles enable row level security;
alter table public.hanimex_customers enable row level security;
alter table public.hanimex_support_tickets enable row level security;
alter table public.hanimex_support_messages enable row level security;
alter table public.hanimex_support_events enable row level security;
alter table public.hanimex_care_departments enable row level security;
drop policy if exists "profile read self or admin" on public.hanimex_profiles;
drop policy if exists "admin manages profiles" on public.hanimex_profiles;
drop policy if exists "staff manage customers" on public.hanimex_customers;
drop policy if exists "staff manage support tickets" on public.hanimex_support_tickets;
drop policy if exists "staff manage support messages" on public.hanimex_support_messages;
drop policy if exists "staff manage support events" on public.hanimex_support_events;
create policy "care profiles self or admin read" on public.hanimex_profiles for select to authenticated using(user_id=(select auth.uid()) or (select public.hanimex_is_admin()));
create policy "care profiles admin full access" on public.hanimex_profiles for all to authenticated using((select public.hanimex_is_admin())) with check((select public.hanimex_is_admin()));
create policy "care departments read active" on public.hanimex_care_departments for select to authenticated using(active=true or (select public.hanimex_is_admin()));
create policy "care departments admin manage" on public.hanimex_care_departments for all to authenticated using((select public.hanimex_is_admin())) with check((select public.hanimex_is_admin()));
create policy "care customers read active staff" on public.hanimex_customers for select to authenticated using((select public.hanimex_is_active_staff()));
create policy "care customers insert active staff" on public.hanimex_customers for insert to authenticated with check((select public.hanimex_is_active_staff()) and (created_by is null or created_by=(select auth.uid())));
create policy "care customers update active staff" on public.hanimex_customers for update to authenticated using((select public.hanimex_is_admin()) or (select public.hanimex_is_active_staff())) with check((select public.hanimex_is_admin()) or (select public.hanimex_is_active_staff()));
create policy "care customers admin delete" on public.hanimex_customers for delete to authenticated using((select public.hanimex_is_admin()));
create policy "care tickets read permission" on public.hanimex_support_tickets for select to authenticated using((select public.hanimex_is_admin()) or ((select public.hanimex_care_has('tickets.read')) and (category<>'delivery' or (select public.hanimex_care_has('delivery.access'))) and (category<>'technical' or (select public.hanimex_care_has('maintenance.access')))));
create policy "care tickets insert permission" on public.hanimex_support_tickets for insert to authenticated with check((select public.hanimex_is_admin()) or ((select public.hanimex_care_has('tickets.create')) and created_by=(select auth.uid()) and (category<>'delivery' or (select public.hanimex_care_has('delivery.access'))) and (category<>'technical' or (select public.hanimex_care_has('maintenance.access')))));
create policy "care tickets update permission" on public.hanimex_support_tickets for update to authenticated using((select public.hanimex_is_admin()) or ((select public.hanimex_care_has('tickets.update')) and (created_by=(select auth.uid()) or assigned_to=(select auth.uid())) and (category<>'delivery' or (select public.hanimex_care_has('delivery.access'))) and (category<>'technical' or (select public.hanimex_care_has('maintenance.access'))))) with check((select public.hanimex_is_admin()) or ((select public.hanimex_care_has('tickets.update')) and (created_by=(select auth.uid()) or assigned_to=(select auth.uid())) and (category<>'delivery' or (select public.hanimex_care_has('delivery.access'))) and (category<>'technical' or (select public.hanimex_care_has('maintenance.access')))));
create policy "care tickets admin delete" on public.hanimex_support_tickets for delete to authenticated using((select public.hanimex_is_admin()));
create policy "care messages read permission" on public.hanimex_support_messages for select to authenticated using((select public.hanimex_care_has('tickets.read')) and exists(select 1 from public.hanimex_support_tickets t where t.id=ticket_id));
create policy "care messages insert permission" on public.hanimex_support_messages for insert to authenticated with check((select public.hanimex_care_has('tickets.read')) and sender_id=(select auth.uid()) and exists(select 1 from public.hanimex_support_tickets t where t.id=ticket_id));
create policy "care messages admin delete" on public.hanimex_support_messages for delete to authenticated using((select public.hanimex_is_admin()));
create policy "care events read permission" on public.hanimex_support_events for select to authenticated using((select public.hanimex_care_has('tickets.read')) and exists(select 1 from public.hanimex_support_tickets t where t.id=ticket_id));
create policy "care events insert permission" on public.hanimex_support_events for insert to authenticated with check((select public.hanimex_care_has('tickets.read')) and actor_id=(select auth.uid()) and exists(select 1 from public.hanimex_support_tickets t where t.id=ticket_id));
grant select,update on public.hanimex_profiles to authenticated;
grant select,insert,update,delete on public.hanimex_care_departments to authenticated;
grant select,insert,update,delete on public.hanimex_customers to authenticated;
grant select,insert,update,delete on public.hanimex_support_tickets to authenticated;
grant select,insert,delete on public.hanimex_support_messages to authenticated;
grant select,insert on public.hanimex_support_events to authenticated;
do $$ begin alter publication supabase_realtime add table public.hanimex_support_tickets; exception when duplicate_object then null; when undefined_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.hanimex_support_messages; exception when duplicate_object then null; when undefined_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.hanimex_support_events; exception when duplicate_object then null; when undefined_object then null; end $$;
