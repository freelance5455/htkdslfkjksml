-- Pre-Launch Mode: early registrations collected while the public site is closed. Additive only; the on/off switch, launch date and all
-- countdown wording live in the existing `settings` table (keys prelaunch.*), so nothing else changes and no row is touched.
CREATE TABLE prelaunch_signups (
  id INTEGER PRIMARY KEY,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,          -- one row per address: repeat sign-ups cannot create duplicates
  name TEXT,
  source TEXT NOT NULL DEFAULT 'email' CHECK (source IN ('email','account')),
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  ip_address TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_prelaunch_signups_created ON prelaunch_signups(created_at);
