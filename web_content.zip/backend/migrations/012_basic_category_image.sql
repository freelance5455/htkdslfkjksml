-- Basic Academic categories can carry one cover image (stored like other public images, served via /media).
-- Additive only: one new nullable column; nothing existing is changed.
ALTER TABLE categories ADD COLUMN image TEXT;
