import os, time
from datetime import datetime, timezone
from typing import Optional
import httpx
from fastapi import FastAPI, HTTPException
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    webull_app_key: str = ""
    webull_app_secret: str = ""
    webull_region: str = "us"
    webull_enabled: bool = False
    idx_enabled: bool = False
    idx_base_url: str = ""
    idx_api_key: str = ""
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

s=Settings()
app=FastAPI(title="MasterFlow Trading Live Gateway", version="1.0-live-ready")

@app.get("/health")
def health():
    return {"ok": True, "service":"masterflow-live-gateway", "time":datetime.now(timezone.utc).isoformat()}

@app.get("/provider-status")
def provider_status():
    return {
      "webull": {"configured": bool(s.webull_app_key and s.webull_app_secret), "enabled": s.webull_enabled},
      "idx": {"configured": bool(s.idx_base_url and s.idx_api_key), "enabled": s.idx_enabled},
      "auto_trading": False,
    }

async def webull_snapshot(symbol: str):
    if not s.webull_enabled:
        raise HTTPException(503, "Webull live data disabled. Enable it only after the OpenAPI market-data subscription is active.")
    if not s.webull_app_key or not s.webull_app_secret:
        raise HTTPException(503, "Webull credentials are not configured on the backend.")
    # SDK/auth details vary by SDK release; keep credentials server-side and use the official SDK/API.
    # This gateway deliberately does not expose credentials to the browser/APK.
    try:
        from webull.core.client import ApiClient
        from webull.data.data_client import DataClient
        from webull.data.common.category import Category
        api = ApiClient(s.webull_app_key, s.webull_app_secret, s.webull_region)
        api.add_endpoint(s.webull_region, "https://api.webull.com")
        client = DataClient(api)
        res = client.market_data.get_snapshot(symbol, Category.US_STOCK.name)
        if res.status_code != 200:
            raise HTTPException(res.status_code, res.text)
        return res.json()
    except ImportError as e:
        raise HTTPException(500, f"Webull SDK unavailable: {e}")

@app.get("/live/quote")
async def live_quote(symbol: str):
    symbol=symbol.strip().upper()
    if not symbol or len(symbol)>20:
        raise HTTPException(400,"Invalid symbol")
    data=await webull_snapshot(symbol)
    return {"source":"WEBULL", "live":True, "received_at":time.time(), "data":data}

@app.get("/analyze")
async def analyze(symbol: str):
    q=await live_quote(symbol)
    d=q["data"][0] if isinstance(q["data"],list) and q["data"] else q["data"]
    price=float(d.get("price",0)) if d.get("price") else None
    return {
      "symbol":symbol.upper(), "source":"WEBULL", "data_status":"LIVE",
      "price":price, "last_trade_time":d.get("last_trade_time"),
      "master_call":"TUNDA", "confidence":0,
      "warning":"Live market data connected; strategy engine remains conservative until candle history/indicators are available.",
      "auto_trading":False
    }

@app.get("/idx/quote")
async def idx_quote(symbol: str):
    if not s.idx_enabled or not s.idx_base_url:
        raise HTTPException(503,"IDX provider is not configured. Connect a licensed IDX market-data provider on the backend.")
    headers={"Authorization":f"Bearer {s.idx_api_key}"} if s.idx_api_key else {}
    async with httpx.AsyncClient(timeout=10) as c:
        r=await c.get(s.idx_base_url.rstrip("/")+"/quote", params={"symbol":symbol.upper()}, headers=headers)
        r.raise_for_status()
        return {"source":"IDX_PROVIDER","live":True,"received_at":time.time(),"data":r.json()}
