import os
import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title="TPH-X Flight Radar System Backend")

# Enable wide cross-origin requests for local Android Webview access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# OpenSky Network public API target
OPENSKY_URL = "https://opensky-network.org/api/states/all"

def classify_aircraft(icao24, callsign):
    """
    Simple classification rule engine leveraging typical regional data telemetry heuristics.
    In real production deployment, this maps against an asset sqlite database lookup file.
    """
    callsign = (callsign or "").strip().upper()
    
    # Simple example pattern matchers for demonstration classification
    if any(prefix in callsign for prefix in ["RCH", "ASY", "CFC", "IAM", "BAF", "KAF"]):
        return "military"
    if any(prefix in callsign for prefix in ["SAM", "GJM", "GOV"]):
        return "government"
    if callsign.startswith("HELO") or callsign.startswith("HCP"):
        return "helicopter"
    if icao24.startswith("a") or len(callsign) <= 5 and callsign != "":
        return "private"
    
    return "civilian"

@app.get("/api/aircraft")
async def get_aircraft_telemetry():
    try:
        # Pull request wrapper from standard live endpoint feed source securely
        async with httpx.AsyncClient(timeout=10.0) as client:
            # Check for authorized user credentials safely loaded from protected environment state
            username = os.getenv("OPENSKY_USERNAME")
            password = os.getenv("OPENSKY_PASSWORD")
            
            auth = (username, password) if username and password else None
            
            # Request subset over Europe/UK regional bounding box for crisp dashboard responsiveness
            params = {
                "lamin": 49.0,
                "lamin": 49.5,
                "lamax": 61.0,
                "lomin": -11.0,
                "lomax": 2.0
            }
            
            response = await client.get(OPENSKY_URL, params=params, auth=auth)
            
            if response.status_code != 200:
                raise HTTPException(status_code=502, detail="Upstream data network error")
                
            data = response.json()
            states = data.get("states") or []
            
            normalized_records = []
            for s in states[:150]: # Cap collection size for sleek client runtime performance
                if not s[5] or not s[6]: # Filter records without coordinates immediately
                    continue
                    
                callsign_str = s[1].strip() if s[1] else ""
                classification = classify_aircraft(s[0], callsign_str)
                
                normalized_records.append({
                    "icao24": s[0],
                    "callsign": callsign_str or None,
                    "latitude": float(s[6]),
                    "longitude": float(s[5]),
                    "altitude_m": float(s[7]) if s[7] is not None else 0.0,
                    "ground_speed_ms": float(s[9]) if s[9] is not None else 0.0,
                    "heading_deg": float(s[10]) if s[10] is not None else 0.0,
                    "vertical_rate_ms": float(s[11]) if s[11] is not None else 0.0,
                    "last_seen": int(s[4]),
                    "source": "OpenSky Network Feed",
                    "classification": classification
                })
                
            return {"aircraft": normalized_records}
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
