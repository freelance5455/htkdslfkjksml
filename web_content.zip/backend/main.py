import os, math
from datetime import datetime, timezone
from typing import Any

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    twelvedata_api_key: str = ""
    twelvedata_base_url: str = "https://api.twelvedata.com"
    # Optional licensed IDX/provider feed can be added later; it is never used as a silent fallback.
    licensed_market_base_url: str = ""
    licensed_market_api_key: str = ""
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


s = Settings()
app = FastAPI(title="MasterFlow Trading Market Gateway", version="7.1-cloud-ready")

# Frontend/APK may call this API from a different origin. No secrets are exposed here.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

MARKETS = {
    "IDX": {"exchange": "XIDX", "name": "Indonesia Stock Exchange", "timing": "EOD"},
    "US": {"exchange": None, "name": "United States", "timing": "REALTIME"},
    "HK": {"exchange": "XHKG", "name": "Hong Kong Stock Exchange", "timing": "PROVIDER"},
    "JP": {"exchange": "XJPX", "name": "Tokyo Stock Exchange", "timing": "PROVIDER"},
    "SG": {"exchange": "XSES", "name": "Singapore Exchange", "timing": "PROVIDER"},
}

STARTER = {
    "IDX": ["BBCA", "BBRI", "BMRI", "TLKM", "ASII", "GOTO", "ICBP", "INDF", "UNTR", "ANTM", "ADRO", "BRPT", "MDKA", "AMRT", "BBNI"],
    "US": ["AAPL", "NVDA", "MSFT", "AMZN", "META", "TSLA", "GOOGL", "AMD", "NFLX", "AVGO", "PLTR", "INTC"],
    "HK": ["0700", "9988", "3690", "1299", "1810"],
    "JP": ["7203", "6758", "9984", "8306", "8035"],
    "SG": ["D05", "O39", "U11", "Z74"],
}


def _clean_symbol(symbol: str, market: str) -> str:
    symbol = symbol.strip().upper()
    if market == "IDX":
        return symbol.replace(".JK", "")
    if market == "HK":
        return symbol.replace(".HK", "")
    if market == "JP":
        return symbol.replace(".T", "")
    if market == "SG":
        return symbol.replace(".SI", "")
    return symbol


def _score(v: float) -> int:
    return int(max(0, min(100, round(v))))


async def td_get(path: str, params: dict[str, Any]) -> dict[str, Any] | None:
    if not s.twelvedata_api_key:
        return None
    p = dict(params)
    p["apikey"] = s.twelvedata_api_key
    url = s.twelvedata_base_url.rstrip("/") + path
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.get(url, params=p)
            if r.status_code != 200:
                return None
            raw = r.json()
            if isinstance(raw, dict) and raw.get("status") == "error":
                return None
            return raw
    except Exception:
        return None


async def td_quote(symbol: str, market: str) -> dict[str, Any] | None:
    cfg = MARKETS[market]
    params = {"symbol": _clean_symbol(symbol, market)}
    if cfg["exchange"]:
        params["exchange"] = cfg["exchange"]
    raw = await td_get("/quote", params)
    if not raw or not raw.get("close"):
        return None
    price = float(raw["close"])
    prev = float(raw.get("previous_close") or price)
    change = float(raw.get("change") or (price - prev))
    pct = float(raw.get("percent_change") or ((change / prev) * 100 if prev else 0))
    return {
        "source": "TWELVE_DATA",
        "provider": "Twelve Data",
        "timing": cfg["timing"],
        "live": cfg["timing"] == "REALTIME",
        "delayed": cfg["timing"] != "REALTIME",
        "symbol": _clean_symbol(symbol, market),
        "price": price,
        "previous_close": prev,
        "change": change,
        "change_pct": pct,
        "volume": raw.get("volume"),
        "timestamp": raw.get("datetime") or raw.get("timestamp"),
        "market_open": raw.get("is_market_open"),
        "warning": "US real-time availability depends on Twelve Data entitlement; IDX is EOD on the Twelve Data exchange catalog." if market in ("US", "IDX") else "Timing depends on the exchange/data entitlement configured in Twelve Data.",
    }


async def td_series(symbol: str, market: str, interval: str = "1day", outputsize: int = 120) -> dict[str, list[Any]] | None:
    cfg = MARKETS[market]
    params = {"symbol": _clean_symbol(symbol, market), "interval": interval, "outputsize": outputsize, "order": "ASC"}
    if cfg["exchange"]:
        params["exchange"] = cfg["exchange"]
    raw = await td_get("/time_series", params)
    values = (raw or {}).get("values")
    if not isinstance(values, list) or not values:
        return None
    def arr(key: str):
        out = []
        for x in values:
            try: out.append(float(x.get(key)) if x.get(key) is not None else None)
            except Exception: out.append(None)
        return out
    return {"datetime": [x.get("datetime") for x in values], "open": arr("open"), "high": arr("high"), "low": arr("low"), "close": arr("close"), "volume": arr("volume")}


async def quote(symbol: str, market: str = "IDX") -> dict[str, Any]:
    market = market.upper()
    if market not in MARKETS:
        raise HTTPException(400, "Unsupported market")
    symbol = _clean_symbol(symbol, market)
    if not symbol:
        raise HTTPException(400, "Invalid symbol")
    q = await td_quote(symbol, market)
    if not q:
        raise HTTPException(503, "Twelve Data tidak mengembalikan data untuk simbol ini atau API key/entitlement belum aktif")
    return q


@app.get("/health")
def health():
    return {"ok": True, "service": "masterflow-trusted-market-gateway", "time": datetime.now(timezone.utc).isoformat(), "auto_trading": False}


@app.get("/health")
async def health():
    return {"ok": True, "provider": "Twelve Data", "auto_trading": False}

@app.get("/provider-status")
def provider_status():
    return {
        "primary": {"provider": "Twelve Data", "configured": bool(s.twelvedata_api_key), "base_url": s.twelvedata_base_url},
        "markets": {k: {"exchange": v["exchange"], "timing": v["timing"], "name": v["name"]} for k, v in MARKETS.items()},
        "fallback": None,
        "demo_data": False,
        "auto_trading": False,
    }


@app.get("/public/quote")
async def public_quote(symbol: str, market: str = "IDX"):
    return await quote(symbol, market)


async def universe(market: str = "IDX"):
    market = market.upper()
    if market not in MARKETS:
        raise HTTPException(400, "Unsupported market")
    cfg = MARKETS[market]
    params = {"exchange": cfg["exchange"]} if cfg["exchange"] else {"country": "United States"}
    raw = await td_get("/stocks", params)
    if isinstance(raw, list):
        syms = []
        for x in raw:
            if isinstance(x, dict) and x.get("symbol"):
                syms.append(str(x["symbol"]).upper())
        if syms:
            return {"market": market, "source": "TWELVE_DATA", "symbols": syms, "complete": True}
    return {"market": market, "source": "TWELVE_DATA_STARTER", "symbols": STARTER[market], "complete": False}


def _ema(vals: list[float], period: int) -> list[float]:
    vals = [float(v) for v in vals if v is not None]
    if not vals: return []
    k = 2 / (period + 1)
    out = [vals[0]]
    for v in vals[1:]: out.append(v * k + out[-1] * (1 - k))
    return out


def _rsi(vals: list[float], period: int = 14) -> float | None:
    vals = [float(v) for v in vals if v is not None]
    if len(vals) < period + 1: return None
    gains, losses = [], []
    for i in range(1, len(vals)):
        d = vals[i] - vals[i - 1]
        gains.append(max(d, 0)); losses.append(max(-d, 0))
    ag = sum(gains[-period:]) / period; al = sum(losses[-period:]) / period
    if al == 0: return 100.0
    return 100 - 100 / (1 + ag / al)


def _macd(vals: list[float]):
    e12, e26 = _ema(vals, 12), _ema(vals, 26)
    if len(e26) < 2: return None
    line = [a - b for a, b in zip(e12[-len(e26):], e26)]
    sig = _ema(line, 9)
    return {"line": line[-1], "signal": sig[-1], "hist": line[-1] - sig[-1]}


def technical(series):
    closes = [x for x in series["close"] if x is not None]
    vols = [x for x in series["volume"] if x is not None]
    if len(closes) < 30: return None
    last = closes[-1]
    sma20 = sum(closes[-20:]) / 20
    sma50 = sum(closes[-50:]) / 50 if len(closes) >= 50 else sma20
    trend = _score(50 + ((last / sma20 - 1) * 350) + ((sma20 / sma50 - 1) * 250))
    momentum_20 = (last / closes[-21] - 1) * 100 if closes[-21] else 0
    mom = _score(50 + momentum_20 * 9)
    if len(vols) >= 20 and sum(vols[-20:]) > 0:
        vr = vols[-1] / (sum(vols[-20:]) / 20)
        volume_score = _score(50 + (vr - 1) * 35)
    else: volume_score = None
    returns = [(closes[i] / closes[i-1] - 1) * 100 for i in range(max(1, len(closes)-20), len(closes)) if closes[i-1]]
    volat = math.sqrt(sum(r*r for r in returns) / len(returns)) if returns else 0
    volatility = _score(100 - min(100, volat * 15))
    rsi = _rsi(closes)
    macd = _macd(closes)
    rsi_score = _score(rsi) if rsi is not None else None
    macd_score = _score(50 + (macd["hist"] / (abs(last) * 0.01)) * 25) if macd and last else None
    parts = [x for x in [trend, mom, volume_score, volatility, rsi_score, macd_score] if x is not None]
    conf = _score(sum(parts) / len(parts)) if parts else 0
    confluence = _score((trend + mom + (volume_score if volume_score is not None else 50) + volatility + (rsi_score if rsi_score is not None else 50) + (macd_score if macd_score is not None else 50)) / 6)
    signal = "BELI" if conf >= 67 else "JUAL" if conf <= 33 else "TUNDA"
    # ATR-like average true range from daily OHLC.
    trs = []
    for i in range(1, len(series["close"])):
        h, l, pc = series["high"][i], series["low"][i], series["close"][i-1]
        if h is not None and l is not None and pc is not None: trs.append(max(h-l, abs(h-pc), abs(l-pc)))
    atr = sum(trs[-14:]) / min(14, len(trs)) if trs else last * 0.02
    entry = round(last, 4)
    sl = round(last - 1.5 * atr, 4) if signal == "BELI" else round(last + 1.5 * atr, 4) if signal == "JUAL" else None
    tp1 = round(last + 2 * atr, 4) if signal == "BELI" else round(last - 2 * atr, 4) if signal == "JUAL" else None
    rr = round(abs((tp1-last)/(last-sl)), 2) if sl and tp1 and last != sl else None
    buy = sell = None
    if len(vols) >= 10 and len(series["high"]) >= 10:
        ub = db = 0.0
        for o,h,l,c,v in zip(series["open"][-20:], series["high"][-20:], series["low"][-20:], series["close"][-20:], series["volume"][-20:]):
            if None in (h,l,c,v) or h == l: continue
            flow = ((c-l)/(h-l)-0.5)*2*float(v)
            if flow >= 0: ub += flow
            else: db += -flow
        total = ub + db
        if total: buy, sell = round(ub/total*100,1), round(db/total*100,1)
    return {"signal": signal, "confidence": conf, "scores": {"trend": trend, "momentum": mom, "volume": volume_score, "volatility": volatility, "confluence": confluence}, "rsi": rsi, "macd": macd, "entry": entry, "sl": sl, "tp1": tp1, "rr": rr, "buy": buy, "sell": sell}


@app.get("/analyze")
async def analyze(symbol: str, market: str = "IDX"):
    market = market.upper()
    q = await quote(symbol, market)
    series = await td_series(symbol, market, "1day", 120)
    if not series:
        raise HTTPException(503, "Twelve Data tidak menyediakan historical OHLC untuk simbol ini")
    tech = technical(series)
    if not tech:
        raise HTTPException(503, "Data historical belum cukup untuk analisis teknikal")
    return {
        "symbol": _clean_symbol(symbol, market), "market": market, "source": q["source"], "provider": q["provider"],
        "data_status": q["timing"], "price": q["price"], "change_pct": q["change_pct"], "signal": tech["signal"],
        "confidence": tech["confidence"], "scores": tech["scores"], "confluence": "KUAT" if tech["confidence"] >= 75 else "SEDANG" if tech["confidence"] >= 55 else "LEMAH",
        "flow": {"scalp": tech["signal"], "macro": tech["signal"], "swing": tech["signal"]}, "entry": tech["entry"], "stop_loss": tech["sl"], "tp1": tech["tp1"], "rr": tech["rr"],
        "ohlc": {k: v[-60:] for k, v in series.items()}, "indicators": {"rsi": tech["rsi"], "macd": tech["macd"]},
        "pressure": {"buy": tech["buy"], "sell": tech["sell"]} if tech["buy"] is not None else None,
        "timestamp": q.get("timestamp"), "market_open": q.get("market_open"), "warning": q.get("warning"),
        "reasons": ["Trend, momentum, volume, volatilitas, RSI, dan MACD dihitung dari OHLCV Twelve Data.", "Harga/interval mengikuti timing dan lisensi exchange pada akun Twelve Data.", "Skor adalah alat bantu analisis, bukan jaminan profit atau rekomendasi investasi."],
        "auto_trading": False,
    }


@app.get("/scan")
async def scan(market: str = "IDX", universe_name: str = "all"):
    u = await universe(market)
    rows = []
    for sym in u["symbols"][:25]:
        try:
            result = await analyze(sym, market)
            rows.append({"symbol": result["symbol"], "score": result["confidence"], "signal": result["signal"], "entry": result["entry"], "flow": result["data_status"]})
        except Exception:
            continue
    rows.sort(key=lambda x: x["score"], reverse=True)
    return {"market": market.upper(), "universe_complete": u["complete"], "results": rows, "source": "TWELVE_DATA_ONLY", "warning": "Scanner hanya memakai data Twelve Data; tidak ada Yahoo/demo fallback.", "auto_trading": False}
