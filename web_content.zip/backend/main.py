from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from pathlib import Path
import asyncio, uuid, zipfile, shutil, tempfile, os
from build_worker import run_build, jobs

app = FastAPI(title="ZIP to APK Builder")
BASE = Path(__file__).resolve().parent.parent
INDEX = BASE / "index.html"

@app.get("/", response_class=HTMLResponse)
async def index():
    return INDEX.read_text(encoding="utf-8")

@app.post("/api/build")
async def create_build(file: UploadFile = File(...)):
    if not file.filename or not file.filename.lower().endswith(".zip"):
        raise HTTPException(400, "Only .zip files are supported")

    job_id = uuid.uuid4().hex
    work = Path(tempfile.mkdtemp(prefix=f"zipapk-{job_id}-"))
    archive = work / "project.zip"

    try:
        with archive.open("wb") as out:
            size = 0
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > 250 * 1024 * 1024:
                    raise HTTPException(413, "ZIP exceeds 250 MB limit")
                out.write(chunk)

        with zipfile.ZipFile(archive) as z:
            for info in z.infolist():
                p = Path(info.filename)
                if p.is_absolute() or ".." in p.parts:
                    raise HTTPException(400, "Unsafe ZIP path")
            z.extractall(work / "src")

        src = work / "src"
        if not any((src / n).exists() for n in ("settings.gradle", "settings.gradle.kts", "build.gradle", "build.gradle.kts")):
            raise HTTPException(400, "ZIP does not look like a Gradle project")

        jobs[job_id] = {"id": job_id, "status": "queued", "logs": "", "apk": None}
        asyncio.create_task(run_build(job_id, work))
        return {"id": job_id, "status": "queued"}
    except HTTPException:
        shutil.rmtree(work, ignore_errors=True)
        raise
    except zipfile.BadZipFile:
        shutil.rmtree(work, ignore_errors=True)
        raise HTTPException(400, "Invalid ZIP archive")
    except Exception as e:
        shutil.rmtree(work, ignore_errors=True)
        raise HTTPException(500, str(e))

@app.get("/api/builds/{job_id}")
async def get_build(job_id: str):
    if job_id not in jobs:
        raise HTTPException(404, "Build not found")
    return jobs[job_id]

@app.get("/api/builds/{job_id}/apk")
async def download_apk(job_id: str):
    job = jobs.get(job_id)
    if not job or job["status"] != "completed" or not job["apk"]:
        raise HTTPException(404, "APK is not ready")
    path = Path(job["apk"])
    if not path.exists():
        raise HTTPException(404, "APK no longer exists")
    return FileResponse(path, media_type="application/vnd.android.package-archive",
                        filename="app-debug.apk")
