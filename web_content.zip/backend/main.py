import os, time
from datetime import datetime, timezone
import httpx
from fastapi import FastAPI, HTTPException
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    goapi_base_url: str = "https://goapi.io/api"
    goapi_api_key: str = ""
    alphavantage_api_key: str = ""
    alphavantage_base_url: str = "https://www.alphavantage.co/query"
    webull_enabled: bool = False
    webull_app_key: str = ""
    webull_app_secret: str = ""
    webull_region: str = "us"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

s=Settings()
app=FastAPI(title="MasterFlow Trading Multi-Market Gateway", version="2.0-public-multi")

US=['AAPL','NVDA','MSFT','AMZN','META','TSLA','GOOGL','AMD','NFLX','AVGO','PLTR','INTC']
HK=['0700.HK','9988.HK','3690.HK','1299.HK','1810.HK']
JP=['7203.T','6758.T','9984.T','8306.T','8035.T']
SG=['D05.SI','O39.SI','U11.SI','Z74.SI']

@app.get('/health')
def health(): return {'ok':True,'service':'masterflow-multi-market-gateway','time':datetime.now(timezone.utc).isoformat(),'auto_trading':False}

@app.get('/provider-status')
def provider_status():
    return {'idx':{'provider':'GOAPI','configured':bool(s.goapi_api_key)},'global':{'provider':'Alpha Vantage','configured':bool(s.alphavantage_api_key)},'fallback':'Yahoo Finance public chart','auto_trading':False}

async def av_quote(symbol):
    if not s.alphavantage_api_key: return None
    async with httpx.AsyncClient(timeout=15) as c:
        r=await c.get(s.alphavantage_base_url,params={'function':'GLOBAL_QUOTE','symbol':symbol,'apikey':s.alphavantage_api_key})
        if r.status_code!=200: return None
        raw=r.json(); q=raw.get('Global Quote') or {}
        if not q or not q.get('05. price'): return None
        price=float(q['05. price']); change=float(q.get('09. change','0') or 0); pct=float(q.get('10. change percent','0').replace('%','') or 0)
        return {'source':'ALPHA_VANTAGE_PUBLIC','live':False,'delayed':True,'symbol':symbol,'price':price,'change':change,'change_pct':pct,'volume':q.get('06. volume'),'timestamp':q.get('07. latest trading day'),'warning':'Alpha Vantage public/free quote is not assumed realtime; commercial/realtime entitlements vary by plan.'}

async def goapi_quote(symbol):
    if not s.goapi_api_key: return None
    headers={'Authorization':f'Bearer {s.goapi_api_key}','X-API-KEY':s.goapi_api_key}
    # GOAPI deployments can expose /stock/idx/prices under different base prefixes; try documented path first.
    for url in [s.goapi_base_url.rstrip('/')+'/stock/idx/prices', s.goapi_base_url.rstrip('/')+'/v1/stock/idx/prices']:
        try:
            async with httpx.AsyncClient(timeout=15) as c:
                r=await c.get(url,params={'symbols':symbol,'symbol':symbol},headers=headers)
                if r.status_code!=200: continue
                raw=r.json(); items=raw if isinstance(raw,list) else raw.get('data') or raw.get('results') or raw.get('items') or []
                if isinstance(items,dict): items=[items]
                q=next((x for x in items if str(x.get('symbol') or x.get('ticker') or '').upper()==symbol), items[0] if items else None)
                if q:
                    price=q.get('price') or q.get('last') or q.get('close')
                    if price is not None:
                        prev=q.get('previous_close') or q.get('prev_close') or price
                        change=float(q.get('change') or (float(price)-float(prev)))
                        pct=float(q.get('change_pct') or q.get('change_percent') or ((change/float(prev))*100 if prev else 0))
                        return {'source':'GOAPI_IDX_DELAYED','live':False,'delayed':True,'symbol':symbol,'price':float(price),'previous_close':float(prev),'change':change,'change_pct':pct,'volume':q.get('volume'),'timestamp':q.get('timestamp') or q.get('date'),'warning':'GOAPI dokumentasi menyebut harga IDX delay sekitar 3–10 menit.'}
        except Exception: pass
    return None

async def yahoo_quote(symbol, market='IDX'):
    if market=='IDX': ysym=symbol.replace('.JK','')+'.JK'
    else: ysym=symbol
    url=f'https://query1.finance.yahoo.com/v8/finance/chart/{ysym}'
    async with httpx.AsyncClient(timeout=12,headers={'User-Agent':'Mozilla/5.0'}) as c:
        r=await c.get(url,params={'range':'1d','interval':'5m','includePrePost':'false'})
        if r.status_code!=200: return None
        raw=r.json(); result=(raw.get('chart',{}).get('result') or [None])[0]
        if not result: return None
        meta=result.get('meta',{}); q=(result.get('indicators',{}).get('quote') or [{}])[0]; ts=result.get('timestamp') or []; closes=q.get('close') or []; vols=q.get('volume') or []
        i=len(closes)-1
        while i>=0 and closes[i] is None: i-=1
        if i<0: return None
        price=float(closes[i]); prev=float(meta.get('previousClose') or price); change=price-prev; pct=change/prev*100 if prev else 0
        return {'source':'YAHOO_PUBLIC_DELAYED','live':False,'delayed':True,'symbol':symbol,'price':price,'previous_close':prev,'change':change,'change_pct':pct,'volume':vols[i] if i<len(vols) else None,'timestamp':ts[i] if i<len(ts) else None,'refresh_seconds':300,'warning':'Fallback public market data; freshness depends on source/venue.'}

async def quote(symbol, market='IDX'):
    symbol=symbol.strip().upper()
    if not symbol: raise HTTPException(400,'Invalid symbol')
    if market=='IDX':
        q=await goapi_quote(symbol)
        if q: return q
        q=await yahoo_quote(symbol,'IDX')
    else:
        q=await av_quote(symbol)
        if not q: q=await yahoo_quote(symbol,market)
    if not q: raise HTTPException(404,'No public market data for symbol')
    return q

@app.get('/public/quote')
async def public_quote(symbol:str, market:str='IDX'):
    return await quote(symbol,market.upper())

@app.get('/universe')
async def universe(market:str='IDX'):
    market=market.upper()
    if market=='US': return {'market':'US','source':'STATIC_STARTER_PLUS_PROVIDER_SEARCH','symbols':US,'complete':False}
    if market=='HK': return {'market':'HK','source':'STATIC_STARTER','symbols':HK,'complete':False}
    if market=='JP': return {'market':'JP','source':'STATIC_STARTER','symbols':JP,'complete':False}
    if market=='SG': return {'market':'SG','source':'STATIC_STARTER','symbols':SG,'complete':False}
    if market=='IDX' and s.goapi_api_key:
        headers={'Authorization':f'Bearer {s.goapi_api_key}','X-API-KEY':s.goapi_api_key}
        try:
            async with httpx.AsyncClient(timeout=15) as c:
                r=await c.get(s.goapi_base_url.rstrip('/')+'/stock/idx/companies',headers=headers)
                if r.status_code==200:
                    raw=r.json(); items=raw if isinstance(raw,list) else raw.get('data') or raw.get('results') or raw.get('items') or []
                    syms=[str(x.get('symbol') or x.get('ticker')).upper() for x in items if isinstance(x,dict) and (x.get('symbol') or x.get('ticker'))]
                    if syms: return {'market':'IDX','source':'GOAPI','symbols':sorted(set(syms)),'complete':True}
        except Exception: pass
    return {'market':market,'source':'STARTER','symbols':US if market=='US' else (HK if market=='HK' else JP if market=='JP' else SG if market=='SG' else ['BBCA','BBRI','BMRI','TLKM','ASII','GOTO','ICBP','INDF','UNTR','ANTM','ADRO','BRPT','MDKA','AMRT','BBNI']),'complete':False}

@app.get('/analyze')
async def analyze(symbol:str,market:str='IDX'):
    q=await quote(symbol,market.upper()); pct=float(q.get('change_pct') or 0)
    if pct>=2: call,conf='BELI',60
    elif pct<=-2: call,conf='JUAL',60
    else: call,conf='TUNDA',50
    return {'symbol':symbol.upper(),'market':market.upper(),'source':q['source'],'data_status':'DELAYED_PUBLIC','price':q['price'],'change_pct':pct,'master_call':call,'signal':call,'confidence':conf,'warning':q.get('warning'),'auto_trading':False}

@app.get('/scan')
async def scan(market:str='IDX',universe_name:str='all'):
    u=await universe(market)
    # To avoid provider-rate explosions, scan a bounded public sample unless a licensed/bulk feed is available.
    symbols=u['symbols'][:30]
    rows=[]
    for sym in symbols:
        try:
            q=await quote(sym,market.upper()); pct=float(q.get('change_pct') or 0); score=min(99,max(40,50+abs(pct)*5)); sig='BELI' if pct>=2 else 'JUAL' if pct<=-2 else 'TUNDA'; rows.append({'symbol':sym,'score':round(score),'signal':sig,'entry':f"{q['price']:,.2f}",'flow':'Public delayed'})
        except Exception: continue
    rows.sort(key=lambda x:x['score'],reverse=True)
    return {'market':market.upper(),'universe_complete':u['complete'],'results':rows,'source':'PUBLIC_MULTI_PROVIDER','warning':'Scanner publik dibatasi agar tidak melampaui rate limits; analisis ini bukan jaminan profit.','auto_trading':False}
