/**
 * FarmTool Circle - Google Apps Script backend starter.
 * Verify RESOURCE_ID and API response fields against the live data.gov.in resource.
 * Store secrets in Script Properties; never put the API key in the Android app.
 */
const RESOURCE_ID = 'REPLACE_WITH_VERIFIED_RESOURCE_ID';

function doGet(e) {
  const params = (e && e.parameter) ? e.parameter : {};
  const state = params.state || '';
  const district = params.district || '';
  const market = params.market || '';
  const commodity = params.commodity || '';
  const limit = Math.min(Number(params.limit || 100), 1000);

  const key = PropertiesService.getScriptProperties().getProperty('DATA_GOV_API_KEY');
  if (!key) return json({ok:false, error:'Backend API key is not configured.'});
  if (RESOURCE_ID.indexOf('REPLACE_') === 0) {
    return json({ok:false, error:'Verify and set RESOURCE_ID in Code.gs first.'});
  }

  // Confirm this endpoint and filter names in the current data.gov.in API documentation.
  const url = 'https://api.data.gov.in/resource/' + encodeURIComponent(RESOURCE_ID) +
    '?api-key=' + encodeURIComponent(key) +
    '&format=json&limit=' + limit;
  const response = UrlFetchApp.fetch(url, {muteHttpExceptions:true});
  const status = response.getResponseCode();
  if (status < 200 || status >= 300) {
    return json({ok:false, error:'Government data service returned HTTP ' + status});
  }

  const payload = JSON.parse(response.getContentText());
  const records = payload.records || [];
  const filtered = records.filter(r =>
    (!state || String(r.state || '').toLowerCase() === state.toLowerCase()) &&
    (!district || String(r.district || '').toLowerCase() === district.toLowerCase()) &&
    (!market || String(r.market || '').toLowerCase() === market.toLowerCase()) &&
    (!commodity || String(r.commodity || '').toLowerCase() === commodity.toLowerCase())
  );

  const rows = filtered.map(r => {
    const minQ = numberOrNull(r.min_price);
    const maxQ = numberOrNull(r.max_price);
    const modalQ = numberOrNull(r.modal_price);
    return {
      state: r.state || '',
      district: r.district || '',
      market: r.market || '',
      commodity: r.commodity || '',
      variety: r.variety || '',
      arrival_date: r.arrival_date || '',
      min_quintal: minQ,
      max_quintal: maxQ,
      modal_quintal: modalQ,
      min_kg: minQ === null ? null : minQ / 100,
      max_kg: maxQ === null ? null : maxQ / 100,
      modal_kg: modalQ === null ? null : modalQ / 100
    };
  });

  return json({ok:true, count:rows.length, records:rows, source:'data.gov.in'});
}

function numberOrNull(v) {
  const n = Number(String(v == null ? '' : v).replace(/,/g, ''));
  return String(v == null ? '' : v).trim() === '' || !isFinite(n) ? null : n;
}
function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * Optional daily trigger: run once manually to create a daily refresh trigger.
 * This verifies connectivity only; the app fetches current records from the API.
 */
function installDailyTrigger() {
  ScriptApp.getProjectTriggers().forEach(t => {
    if (t.getHandlerFunction() === 'dailyCheck') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('dailyCheck').timeBased().everyDays(1).create();
}
function dailyCheck() {
  // Add verified dataset pagination and caching here after confirming API schema.
  PropertiesService.getScriptProperties().setProperty('LAST_CHECKED', new Date().toISOString());
}
