<?php
declare(strict_types=1);
const STORE_FILE=__DIR__.'/../database/data.json';
function storeRead(): array {
 if(!is_dir(dirname(STORE_FILE)))mkdir(dirname(STORE_FILE),0750,true);
 if(!file_exists(STORE_FILE))file_put_contents(STORE_FILE,json_encode(['users'=>[],'messages'=>[]],JSON_PRETTY_PRINT),LOCK_EX);
 $raw=file_get_contents(STORE_FILE);$s=json_decode($raw,true);
 if(!is_array($s))throw new RuntimeException('Banco JSON inválido.');
 $s['users']??=[];$s['messages']??=[];return $s;
}
function storeWrite(array $s): void {
 $fp=fopen(STORE_FILE,'c+');if(!$fp)throw new RuntimeException('Não foi possível abrir o armazenamento.');
 try {if(!flock($fp,LOCK_EX))throw new RuntimeException('Não foi possível bloquear o armazenamento.');ftruncate($fp,0);rewind($fp);fwrite($fp,json_encode($s,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));fflush($fp);flock($fp,LOCK_UN);}finally{fclose($fp);}
}
