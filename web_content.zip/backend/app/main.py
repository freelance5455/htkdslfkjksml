from datetime import datetime, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from typing import Optional
import os, math, json
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import swisseph as swe
from dotenv import load_dotenv

load_dotenv()
app = FastAPI(title="Horary AI API", version="0.2.0",
              description="Deterministic chart facts plus Bulgarian-language explanation.")
# The HTML/WebView frontend calls the API from a separate origin. No credentials are used.
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["GET", "POST", "OPTIONS"], allow_headers=["*"])

SIGNS = ["Овен","Телец","Близнаци","Рак","Лъв","Дева","Везни","Скорпион","Стрелец","Козирог","Водолей","Риби"]
PLANETS = {
    "Sun": (swe.SUN, "Слънце"), "Moon": (swe.MOON, "Луна"),
    "Mercury": (swe.MERCURY, "Меркурий"), "Venus": (swe.VENUS, "Венера"),
    "Mars": (swe.MARS, "Марс"), "Jupiter": (swe.JUPITER, "Юпитер"),
    "Saturn": (swe.SATURN, "Сатурн")
}
RULERS = {0:"Марс",1:"Венера",2:"Меркурий",3:"Луна",4:"Слънце",5:"Меркурий",
          6:"Венера",7:"Марс",8:"Юпитер",9:"Сатурн",10:"Сатурн",11:"Юпитер"}

class HoraryRequest(BaseModel):
    question: str = Field(min_length=5, max_length=1000)
    askedAtLocal: str
    place: str = Field(min_length=2, max_length=200)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    timezone: str = "Europe/Sofia"

class HoraryResponse(BaseModel):
    verdict: str
    confidencePercent: int
    confidenceMeaning: str
    summary: str
    detailedExplanation: str
    supportingFactors: list[str]
    challengingFactors: list[str]
    timing: str
    chartFacts: list[str]
    warnings: list[str]
    disclaimer: str

def norm_angle(x): return x % 360.0
def signed_delta(a,b): return (b-a+180)%360-180
def sign_index(lon): return int(norm_angle(lon)//30)
def fmt_pos(lon):
    lon = norm_angle(lon)
    si = sign_index(lon)
    deg = int(lon % 30)
    mins = int((lon % 1)*60)
    return f"{deg}°{mins:02d}′ {SIGNS[si]}"

def julian_day(local_str, tz_name):
    try:
        naive = datetime.strptime(local_str, "%Y-%m-%d %H:%M")
        tz = ZoneInfo(tz_name)
    except (ValueError, ZoneInfoNotFoundError):
        raise HTTPException(422, "Провери датата, часа и часовата зона. Форматът е YYYY-MM-DD HH:MM.")
    aware = naive.replace(tzinfo=tz)
    utc = aware.astimezone(timezone.utc)
    return swe.julday(utc.year, utc.month, utc.day,
                      utc.hour + utc.minute/60 + utc.second/3600)

def calc_chart(req):
    jd = julian_day(req.askedAtLocal, req.timezone)
    flags = swe.FLG_SWIEPH | swe.FLG_SPEED
    planets = {}
    for key, (body, bg) in PLANETS.items():
        vals, retflag = swe.calc_ut(jd, body, flags)
        planets[key] = {
            "name": bg, "longitude": float(vals[0]), "speed": float(vals[3]),
            "position": fmt_pos(vals[0]), "retrograde": vals[3] < 0,
            "sign": SIGNS[sign_index(vals[0])]
        }
    # Placidus houses as a reproducible baseline. Traditional house systems are a user-selectable future feature.
    try:
        cusps, ascmc = swe.houses_ex(jd, req.latitude, req.longitude, b'P')
    except Exception as e:
        raise HTTPException(422, f"Не успях да изчисля домовете за тези координати: {e}")
    asc, mc = float(ascmc[0]), float(ascmc[1])
    houses = [float(x) for x in cusps]
    # Find house from cusp intervals; handle wraparound.
    def house_of(lon):
        for i in range(12):
            start = houses[i]
            end = houses[(i+1)%12]
            span = (end-start)%360
            dist = (lon-start)%360
            if dist < span or math.isclose(dist, 0, abs_tol=1e-6):
                return i+1
        return None
    for p in planets.values(): p["house"] = house_of(p["longitude"])
    asc_sign = sign_index(asc)
    dsc_sign = sign_index(norm_angle(asc+180))
    lord1 = RULERS[asc_sign]
    lord7 = RULERS[dsc_sign]
    name_to_key = {v[1]:k for k,v in PLANETS.items()}
    aspects = []
    aspect_defs = [(0,"съвпад",8),(60,"секстил",5),(90,"квадрат",6),(120,"тригон",6),(180,"опозиция",8)]
    pitems = list(planets.items())
    for i in range(len(pitems)):
        for j in range(i+1,len(pitems)):
            ka, pa = pitems[i]; kb, pb = pitems[j]
            sep = abs(signed_delta(pa["longitude"],pb["longitude"]))
            nearest = min(aspect_defs, key=lambda x: abs(sep-x[0]))
            orb = abs(sep-nearest[0])
            if orb <= nearest[2]:
                # Applying/separating heuristic from relative longitudinal speed; explicitly label approximate.
                rel_speed = pb["speed"] - pa["speed"]
                delta_now = signed_delta(pa["longitude"], pb["longitude"])
                target = nearest[0]
                # For exactness evaluate relative separation after a small step.
                future_sep = abs(signed_delta(pa["longitude"]+pa["speed"]*0.01,
                                              pb["longitude"]+pb["speed"]*0.01))
                applying = abs(future_sep-target) < orb
                aspects.append({"a":pa["name"],"b":pb["name"],"type":nearest[1],
                                "orb":round(orb,2),"applying":applying})
    moon = planets["Moon"]
    # Provisional VOC check: scan forward until the Moon changes sign and look for
    # exact major aspects to the seven traditional planets. This is still a
    # practical approximation, not a fully validated traditional judgement.
    moon_future = []
    moon_sign = sign_index(moon["longitude"])
    last_sign_step = 0.0
    step_days = 0.05
    max_days = 3.0
    for t in [i * step_days for i in range(1, int(max_days / step_days) + 1)]:
        moon_vals, _ = swe.calc_ut(jd + t, swe.MOON, flags)
        if sign_index(float(moon_vals[0])) != moon_sign:
            last_sign_step = t
            break
    if last_sign_step == 0.0:
        last_sign_step = max_days
    # Sample future separations; record a perfection if distance to an aspect
    # reaches a local minimum close to exactness before sign ingress.
    for key, (body, bg) in PLANETS.items():
        if key == "Moon":
            continue
        for angle, label, orb_allow in aspect_defs:
            previous_error = None
            for i in range(1, int(last_sign_step / step_days) + 1):
                t = i * step_days
                mv, _ = swe.calc_ut(jd + t, swe.MOON, flags)
                pv, _ = swe.calc_ut(jd + t, body, flags)
                sep = abs(signed_delta(float(mv[0]), float(pv[0])))
                err = abs(sep - angle)
                if previous_error is not None and err > previous_error and previous_error < 0.25:
                    moon_future.append((key, label))
                    break
                previous_error = err
    moon_voc = len(moon_future) == 0
    facts = [
        f"Асцендент: {fmt_pos(asc)}; управител на I дом: {lord1}.",
        f"Десцендент: {fmt_pos(norm_angle(asc+180))}; управител на VII дом: {lord7}.",
        f"Луна: {moon['position']}; статус без курс: {'възможно' if moon_voc else 'не е показана без курс'} (предварителна проверка)."
    ]
    for key,p in planets.items():
        retro = ", ретроградна" if p["retrograde"] else ""
        facts.append(f"{p['name']}: {p['position']}, дом {p['house']}{retro}.")
    for a in aspects:
        state = "прилагащ" if a["applying"] else "разделящ/неясен"
        facts.append(f"{a['a']} — {a['type']} — {a['b']}, орбис {a['orb']}° ({state}).")
    warnings = [
        "Използва се Плацидус като базова система за домове; тя не е единствената традиционна опция.",
        "Проверката за Луна без курс използва времево пробване преди смяна на знак; възможни са гранични грешки и резултатът остава предварителен.",
        "За пълно традиционно съждение са нужни допълнителни правила: достойнства, рецепции, превод/събиране на светлина и тематични производни домове."
    ]
    return {"jd":jd,"planets":planets,"asc":asc,"mc":mc,"houses":houses,"aspects":aspects,
            "lord1":lord1,"lord7":lord7,"moon_voc":moon_voc,"facts":facts,"warnings":warnings}

def deterministic_assessment(question, chart):
    # Conservative preliminary indicators; this is not a complete William Lilly judgment.
    lordmap = {"Марс":"Mars","Венера":"Venus","Меркурий":"Mercury","Луна":"Moon",
               "Слънце":"Sun","Юпитер":"Jupiter","Сатурн":"Saturn"}
    p1 = chart["planets"].get(lordmap.get(chart["lord1"],"Mars"))
    p7 = chart["planets"].get(lordmap.get(chart["lord7"],"Venus"))
    relevant = [a for a in chart["aspects"] if {a["a"],a["b"]} == {p1["name"],p7["name"]}]
    applying = any(a["applying"] for a in relevant)
    warnings = list(chart["warnings"])
    support, challenge = [], []
    if applying: support.append("Има индикация за приближаващ основен аспект между управителите на I и VII дом.")
    else: challenge.append("Не е открит ясен прилагащ основен аспект между управителите на I и VII дом в базовата проверка.")
    if chart["moon_voc"]: challenge.append("Предварителната проверка отбелязва Луната като възможно без курс; това може да символизира липса на развитие.")
    else: support.append("Предварителната проверка не маркира Луната като без курс.")
    if len(support) > len(challenge):
        verdict, score = "По-скоро благоприятно", 55
    elif len(challenge) > len(support):
        verdict, score = "По-скоро неблагоприятно", 45
    else:
        verdict, score = "Нееднозначно", 50
    if relevant and not applying:
        warnings.append("Има аспект между основните сигнификатори, но базовата скоростна проверка не го класифицира като прилагащ.")
    return verdict, score, support, challenge, warnings

def ai_explanation(question, facts, verdict, score, support, challenge, warnings):
    api_key = os.getenv("OPENAI_API_KEY")
    model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    if not api_key:
        return (
            "AI обяснението не е включено, защото сървърът няма OPENAI_API_KEY. "
            "По-долу са показани изчислените факти и предварителните правила, а не завършено хорарно съждение."
        )
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        prompt = {
            "question": question, "verdict": verdict, "consistency_score": score,
            "chart_facts": facts, "supporting": support, "challenging": challenge, "warnings": warnings
        }
        response = client.chat.completions.create(
            model=model,
            temperature=0.2,
            messages=[
                {"role":"system","content":(
                    "Ти си обяснител на традиционна западна хорарна астрология на ясен български. "
                    "Използвай САМО подадените факти. Не измисляй позиции, аспекти, рецепции или срокове. "
                    "Обясни с обикновен език какво подкрепя извода и какво му противоречи. "
                    "Изрично кажи, че това е символично тълкуване, не научно доказана прогноза. "
                    "Процентът е съгласуваност на правилата, не вероятност събитието да се случи. "
                    "Ако данните не стигат, кажи го ясно. Структурирай отговора с кратък отговор, подробно обяснение, "
                    "положителни показатели, затрудняващи показатели и ограничения. Не твърди, че знаеш тайните чувства на друг човек."
                )},
                {"role":"user","content":json.dumps(prompt, ensure_ascii=False)}
            ]
        )
        return response.choices[0].message.content or "AI не върна обяснение."
    except Exception:
        return "AI услугата временно не е достъпна. Използвай показаните изчислени факти; не прави заключение само по тях."

@app.get("/health")
def health():
    return {"status":"ok","chart_engine":"pyswisseph","ai_configured":bool(os.getenv("OPENAI_API_KEY"))}

@app.post("/horary", response_model=HoraryResponse)
def horary(req: HoraryRequest):
    try:
        chart = calc_chart(req)
        verdict, score, support, challenge, warnings = deterministic_assessment(req.question, chart)
        explanation = ai_explanation(req.question, chart["facts"], verdict, score, support, challenge, warnings)
        if "не е включено" in explanation or "временно не е достъпна" in explanation:
            warnings.append("Подробното AI тълкуване не е генерирано; не представяй предварителния извод като окончателен.")
        return HoraryResponse(
            verdict=verdict,
            confidencePercent=score,
            confidenceMeaning="Предварителна съгласуваност на индикаторите, а не вероятност събитието да се случи.",
            summary=f"Предварителен резултат: {verdict.lower()}. Това е базова автоматична оценка, не завършено традиционно хорарно съждение.",
            detailedExplanation=explanation,
            supportingFactors=support,
            challengingFactors=challenge,
            timing="Не се посочва срок: настоящата версия няма достатъчно валидирани правила за надеждно времево съждение.",
            chartFacts=chart["facts"],
            warnings=warnings,
            disclaimer="Хорарната астрология е символична практика, а не научно потвърден метод за предсказване. Оценката не е реална вероятност."
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Грешка при изчисляване. Не е генерирано тълкуване, за да не се показват измислени данни. Подробности: {type(e).__name__}")
