from pathlib import Path
import json, os, uuid
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from .voices import public_voices
from .engine import synthesize

ROOT = Path(__file__).resolve().parents[2]
FRONTEND = ROOT / "frontend"
DATA = ROOT / "data"
UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", str(DATA / "reference_audio")))
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
CUSTOM_FILE = DATA / "custom_voices.json"
DATA.mkdir(parents=True, exist_ok=True)
MAX_UPLOAD = int(os.getenv("MAX_UPLOAD_MB", "20")) * 1024 * 1024

app = FastAPI(title=os.getenv("APP_NAME", "VoxForge AI"), version="0.1.0")

def read_custom():
    if not CUSTOM_FILE.exists(): return []
    try: return json.loads(CUSTOM_FILE.read_text(encoding="utf-8"))
    except (ValueError, OSError): return []

def write_custom(rows):
    CUSTOM_FILE.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")

@app.get("/api/health")
def health():
    return {"status": "ok", "model": "not_configured", "note": "Connect a neural engine for synthesis."}

@app.get("/api/voices")
def voices():
    return {"voices": public_voices(), "count": 50}

@app.get("/api/voices/custom")
def custom_voices():
    return {"voices": read_custom()}

class SynthesisRequest(BaseModel):
    text: str = Field(min_length=1, max_length=5000)
    language: str = Field(default="en-US", min_length=2, max_length=20)
    voice_id: str = "ai_assistant"
    rate: float = Field(default=1.0, ge=0.6, le=1.5)
    pitch: float = Field(default=1.0, ge=0.6, le=1.5)
    custom_voice_id: str | None = None
    reference_text: str | None = Field(default=None, max_length=2000)

@app.post("/api/synthesize")
def api_synthesize(req: SynthesisRequest):
    voice = next((v for v in public_voices() if v["id"] == req.voice_id), None)
    if not voice: raise HTTPException(404, "Unknown voice preset")
    reference_path = None
    if req.custom_voice_id:
        row = next((r for r in read_custom() if r["id"] == req.custom_voice_id), None)
        if not row: raise HTTPException(404, "Unknown custom voice")
        reference_path = str(UPLOAD_DIR / row["stored_filename"])
        if not req.reference_text:
            req.reference_text = row.get("reference_text")
    wav = synthesize(req.text, req.language, voice, reference_path, req.rate, req.pitch, req.reference_text)
    out = DATA / f"{uuid.uuid4().hex}.wav"
    out.write_bytes(wav)
    return FileResponse(out, media_type="audio/wav", filename="voxforge-output.wav",
                        background=None)

@app.post("/api/voices/clone")
async def clone_voice(name: str = Form(...), consent: bool = Form(...),
                      audio: UploadFile = File(...)):
    if not consent:
        raise HTTPException(400, "Confirm you own this recording or have explicit permission.")
    if not name.strip() or len(name) > 80: raise HTTPException(400, "Name must be 1–80 characters.")
    content_type = (audio.content_type or "").lower()
    allowed = {"audio/wav", "audio/x-wav", "audio/mpeg", "audio/mp4",
               "audio/ogg", "audio/webm", "audio/flac", "audio/x-flac"}
    if content_type not in allowed:
        raise HTTPException(415, "Use a supported audio file (WAV, MP3, MP4/M4A, OGG, WebM or FLAC).")
    content = await audio.read(MAX_UPLOAD + 1)
    if not content: raise HTTPException(400, "Empty audio file.")
    if len(content) > MAX_UPLOAD: raise HTTPException(413, f"Audio must be under {MAX_UPLOAD // (1024*1024)} MB.")
    suffix = Path(audio.filename or "").suffix.lower()
    if suffix not in {".wav",".mp3",".m4a",".mp4",".ogg",".webm",".flac"}:
        suffix = ".audio"
    file_id = uuid.uuid4().hex
    stored = f"{file_id}{suffix}"
    (UPLOAD_DIR / stored).write_bytes(content)
    rows = read_custom()
    row = {"id": file_id, "name": name.strip(), "stored_filename": stored,
           "original_filename": Path(audio.filename or "reference").name,
           "consent_confirmed": True, "reference_text": reference_text.strip(), "status": "reference_uploaded_model_not_configured"}
    rows.append(row); write_custom(rows)
    return JSONResponse({"voice": {k:v for k,v in row.items() if k != "stored_filename"},
                         "message": "Reference stored privately. This does not create a clone until a compatible model is configured."}, status_code=201)

@app.delete("/api/voices/custom/{voice_id}")
def delete_custom_voice(voice_id: str):
    rows = read_custom()
    row = next((r for r in rows if r["id"] == voice_id), None)
    if not row: raise HTTPException(404, "Custom voice not found")
    path = UPLOAD_DIR / row["stored_filename"]
    if path.exists(): path.unlink()
    write_custom([r for r in rows if r["id"] != voice_id])
    return {"deleted": True}

@app.get("/")
def index():
    return FileResponse(FRONTEND / "index.html")

app.mount("/static", StaticFiles(directory=FRONTEND), name="static")
