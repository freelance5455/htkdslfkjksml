"""Optional Qwen3-TTS adapter.

Install backend/requirements-gpu.txt and set VOXFORGE_ENGINE=qwen3.
VoiceDesign handles generated character styles; Base handles consented reference cloning.
Models are loaded lazily and stay resident in the worker process.
"""
import os
from functools import lru_cache
from io import BytesIO
from pathlib import Path
import soundfile as sf
from fastapi import HTTPException

ENGINE = os.getenv("VOXFORGE_ENGINE", "disabled").lower()
DESIGN_MODEL = os.getenv("QWEN_TTS_DESIGN_MODEL", "Qwen/Qwen3-TTS-12Hz-1.7B-VoiceDesign")
CLONE_MODEL = os.getenv("QWEN_TTS_CLONE_MODEL", "Qwen/Qwen3-TTS-12Hz-1.7B-Base")
DEVICE = os.getenv("QWEN_TTS_DEVICE", "cuda:0")
DTYPE_NAME = os.getenv("QWEN_TTS_DTYPE", "bfloat16")

LANGUAGES = {
    "zh": "Chinese", "zh-cn": "Chinese", "en": "English", "en-us": "English",
    "en-gb": "English", "ja": "Japanese", "ja-jp": "Japanese", "ko": "Korean",
    "ko-kr": "Korean", "de": "German", "de-de": "German", "fr": "French",
    "fr-fr": "French", "ru": "Russian", "ru-ru": "Russian", "pt": "Portuguese",
    "pt-br": "Portuguese", "es": "Spanish", "es-es": "Spanish", "it": "Italian",
    "it-it": "Italian",
}

def _language(code: str) -> str:
    key = code.lower()
    lang = LANGUAGES.get(key) or LANGUAGES.get(key.split("-")[0])
    if not lang:
        raise HTTPException(422, f"Qwen3-TTS does not list support for '{code}'. Supported languages: Chinese, English, Japanese, Korean, German, French, Russian, Portuguese, Spanish and Italian.")
    return lang

@lru_cache(maxsize=2)
def _load(model_id: str):
    try:
        import torch
        from qwen_tts import Qwen3TTSModel
    except ImportError as exc:
        raise HTTPException(503, "Qwen3-TTS is not installed. Install backend/requirements-gpu.txt in a compatible model-worker environment.") from exc
    if DEVICE.startswith("cuda") and not torch.cuda.is_available():
        raise HTTPException(503, "QWEN_TTS_DEVICE requests CUDA, but no CUDA GPU is available. Configure a compatible GPU worker or set QWEN_TTS_DEVICE=cpu for testing.")
    dtype = getattr(torch, DTYPE_NAME, torch.float32)
    try:
        return Qwen3TTSModel.from_pretrained(
            model_id, device_map=DEVICE, dtype=dtype
        )
    except Exception as exc:
        raise HTTPException(503, f"Could not load speech model '{model_id}': {type(exc).__name__}: {exc}") from exc

def synthesize(text: str, language: str, preset: dict, reference_path: str | None = None,
               rate: float = 1.0, pitch: float = 1.0, reference_text: str | None = None) -> bytes:
    if ENGINE != "qwen3":
        raise HTTPException(501, detail="Speech model is not enabled. Set VOXFORGE_ENGINE=qwen3 and install the GPU requirements; see docs/MODEL_ADAPTER.md.")
    lang = _language(language)
    try:
        if reference_path:
            if not reference_text or not reference_text.strip():
                raise HTTPException(422, "Provide the exact transcript of the reference recording in reference_text for voice cloning.")
            model = _load(CLONE_MODEL)
            wavs, sr = model.generate_voice_clone(
                text=text, language=lang, ref_audio=reference_path,
                ref_text=reference_text.strip()
            )
        else:
            model = _load(DESIGN_MODEL)
            style = preset.get("description", "Natural, clear speech")
            instruction = f"{style}. Speaking rate {rate:.1f}x, pitch preference {pitch:.1f}."
            wavs, sr = model.generate_voice_design(
                text=text, language=lang, instruct=instruction
            )
        out = BytesIO()
        sf.write(out, wavs[0], sr, format="WAV")
        return out.getvalue()
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(500, f"Speech generation failed: {type(exc).__name__}: {exc}") from exc
