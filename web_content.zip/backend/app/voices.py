"""Preset descriptors. Presets are styles, not 50 separately trained identities."""
STYLES = [
("Ava","feminine","Warm, friendly narrator","🌸"),("Olivia","feminine","Soft, conversational","🌷"),
("Sophia","feminine","Elegant storyteller","✨"),("Emma","feminine","Bright, upbeat","☀️"),
("Mia","feminine","Youthful, casual","🌼"),("Isabella","feminine","Polished, confident","💎"),
("Amara","feminine","Rich, expressive","🌺"),("Zara","feminine","Modern, energetic","⚡"),
("Luna","feminine","Dreamy, gentle","🌙"),("Nora","feminine","Calm, reassuring","🕊️"),
("Aria","feminine","Musical, expressive","🎵"),("Layla","feminine","Smooth, mellow","🌹"),
("Maya","feminine","Natural, approachable","🍃"),("Ella","feminine","Light, cheerful","🦋"),
("Ivy","feminine","Crisp, professional","🌿"),("James","masculine","Clear, professional","🎙️"),
("Liam","masculine","Warm, approachable","☕"),("Noah","masculine","Calm, thoughtful","🌊"),
("Oliver","masculine","British-style narrator","🎩"),("Leo","masculine","Bold, energetic","🦁"),
("Ethan","masculine","Conversational, relaxed","🏔️"),("Alexander","masculine","Deep, authoritative","👑"),
("Omar","masculine","Rich, measured","🌌"),("Kai","masculine","Modern, light","🌐"),
("Daniel","masculine","Friendly, steady","🎧"),("Adam","masculine","Direct, confident","🧭"),
("Rayan","masculine","Smooth, expressive","🌠"),("Theo","masculine","Gentle, reflective","📚"),
("Gabriel","masculine","Warm, resonant","🔥"),("Miles","masculine","Laid-back, mellow","🎸"),
("Professor","character","Wise academic","🧠"),("Storyteller","character","Animated story voice","📖"),
("Robot","character","Synthetic sci-fi","🤖"),("Space Captain","character","Epic adventure","🚀"),
("Fantasy Mage","character","Mystical narrator","🔮"),("Detective","character","Noir mystery","🕵️"),
("Game Hero","character","Bold, dramatic","🛡️"),("Cheerful Elf","character","Playful fantasy","🧝"),
("Villain","character","Dramatic theatrical","🎭"),("News Anchor","character","Broadcast presenter","📰"),
("Documentary","character","Measured narration","🌍"),("Sports Caster","character","High-energy commentary","🏆"),
("Meditation","character","Slow, soothing","🪷"),("Comedy","character","Expressive, playful","🎪"),
("Vintage Radio","character","Classic radio style","📻"),("Anime Hero","character","Animated adventure","⭐"),
("Fairy","character","Light fantasy style","🧚"),("Giant","character","Grand, resonant","⛰️"),
("Pirate","character","Rugged adventure","🏴‍☠️"),("AI Assistant","character","Precise, helpful","💠"),
]
def public_voices():
    return [{"id": name.lower().replace(" ","_"), "name": name, "category": cat,
             "description": desc, "emoji": emoji}
            for name,cat,desc,emoji in STYLES]
