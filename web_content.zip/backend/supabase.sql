-- À exécuter dans Supabase > SQL Editor. Chat public anonyme (sans comptes).
create table messages (
  id bigint generated always as identity primary key,
  room text not null check (room in ('general','BTC','ETH','SOL')),
  nick text not null check (char_length(nick) between 2 and 20),
  body text not null check (char_length(body) between 1 and 500),
  created_at timestamptz not null default now()
);
create table reports (
  id bigint generated always as identity primary key,
  message_id bigint not null references messages(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table messages enable row level security;
alter table reports enable row level security;
create policy "lecture publique" on messages for select to anon using (true);
create policy "ecriture publique" on messages for insert to anon with check (true);
create policy "signalement public" on reports for insert to anon with check (true);
-- Pas de lecture des signalements ni de suppression côté anon : modérez depuis le tableau de bord Supabase.
-- Limites : sans authentification, le spam est possible. Comptes, DM privés et blocage nécessitent Supabase Auth (étape suivante).
