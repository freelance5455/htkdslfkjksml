// Serveur NOVA (Cloudflare Worker). Les clés sont des "secrets" du Worker : jamais dans le navigateur.
const H=(o)=>({"access-control-allow-origin":o||"*","access-control-allow-headers":"authorization,content-type","access-control-allow-methods":"GET,POST,OPTIONS"});
export default{async fetch(q,env){const u=new URL(q.url),h=H(env.ALLOWED_ORIGIN);const J=(o,s=200)=>new Response(JSON.stringify(o),{status:s,headers:{...h,"content-type":"application/json"}});
if(q.method==="OPTIONS")return new Response(null,{headers:h});
if(!env.APP_TOKEN||q.headers.get("authorization")!=="Bearer "+env.APP_TOKEN)return J({error:"Jeton d'accès invalide."},401);
const need=(k,n)=>{if(!env[k])throw Error(n+" non configuré sur le serveur (secret "+k+" manquant).")};
const post=async(url,key,body)=>{const r=await fetch(url,{method:"POST",headers:{authorization:"Bearer "+key,"content-type":"application/json"},body:JSON.stringify(body)});if(!r.ok)throw Error("Moteur : "+r.status+" "+(await r.text()).slice(0,200));return r};
const rep=async(model,input)=>{const r=await post(`https://api.replicate.com/v1/models/${model}/predictions`,env.REPLICATE_KEY,{input});const j=await r.json();return{id:j.id}};
try{const p=u.pathname;
if(p==="/api/health")return J({moteurs:{cerveau:!!env.CHAT_KEY,images:!!env.IMAGE_KEY,video:!!(env.REPLICATE_KEY&&env.VIDEO_MODEL),musique:!!(env.REPLICATE_KEY&&env.MUSIC_MODEL),voix:!!env.TTS_KEY}});
if(p==="/api/job"){need("REPLICATE_KEY","Replicate");const r=await fetch("https://api.replicate.com/v1/predictions/"+u.searchParams.get("id"),{headers:{authorization:"Bearer "+env.REPLICATE_KEY}});const j=await r.json();return J({status:j.status,output:j.output,error:j.error})}
const b=await q.json();
if(p==="/api/chat"){need("CHAT_KEY","Cerveau IA");const r=await post(env.CHAT_URL||"https://api.openai.com/v1/chat/completions",env.CHAT_KEY,{model:env.CHAT_MODEL,messages:b.messages});return J({text:(await r.json()).choices[0].message.content})}
if(p==="/api/image"){need("IMAGE_KEY","Images");const r=await post(env.IMAGE_URL||"https://api.openai.com/v1/images/generations",env.IMAGE_KEY,{model:env.IMAGE_MODEL,prompt:b.prompt,size:b.size||"1024x1024"});const d=(await r.json()).data[0];return J({url:d.url||"data:image/png;base64,"+d.b64_json})}
if(p==="/api/tts"){need("TTS_KEY","Voix");const r=await post(env.TTS_URL||"https://api.openai.com/v1/audio/speech",env.TTS_KEY,{model:env.TTS_MODEL,voice:env.TTS_VOICE||"alloy",input:b.text});return new Response(r.body,{headers:{...h,"content-type":"audio/mpeg"}})}
if(p==="/api/video"){need("REPLICATE_KEY","Vidéo");need("VIDEO_MODEL","Modèle vidéo");return J(await rep(env.VIDEO_MODEL,{prompt:b.prompt,...(b.image?{image:b.image}:{})}))}
if(p==="/api/music"){need("REPLICATE_KEY","Musique");need("MUSIC_MODEL","Modèle musique");return J(await rep(env.MUSIC_MODEL,{prompt:b.prompt}))}
return J({error:"Route inconnue"},404)}catch(e){return J({error:e.message},502)}}};
