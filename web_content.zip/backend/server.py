import os
from flask import Flask,request,jsonify,send_from_directory
from openai import OpenAI
BASE=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
app=Flask(__name__,static_folder=BASE+'/frontend',static_url_path='')
key=os.getenv('OPENAI_API_KEY'); store=os.getenv('NURSING_VECTOR_STORE_ID')
client=OpenAI(api_key=key) if key else None
SYSTEM='''You are Kedrick AI, a nursing education assistant developed by Kedrick Nkole. Answer nursing questions clearly and safely. Use the connected nursing knowledge base when available. Structure answers with definition, assessment, management, nursing management, complications and education when relevant. Never invent references. For medicines, doses and emergencies, tell users to verify current approved local guidelines and facility protocols.'''
@app.get('/')
def home(): return send_from_directory(BASE+'/frontend','index.html')
@app.post('/api/kedrick-ai')
def ask():
    if not client:return jsonify(error='OPENAI_API_KEY is not configured'),500
    q=(request.get_json(silent=True) or {}).get('question','').strip()
    if not q:return jsonify(error='Question is required'),400
    tools=[{'type':'file_search','vector_store_ids':[store]}] if store else []
    try:
        r=client.responses.create(model=os.getenv('OPENAI_MODEL','gpt-5.6-luna'),instructions=SYSTEM,input=q,tools=tools)
        return jsonify(answer=r.output_text)
    except Exception as e:return jsonify(error=str(e)),500
if __name__=='__main__':app.run(host='0.0.0.0',port=int(os.getenv('PORT','5000')))
