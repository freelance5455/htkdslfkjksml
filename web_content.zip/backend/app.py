
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
from pathlib import Path
import sqlite3, datetime, webbrowser

DB = Path(__file__).with_name("queue.db")
app = FastAPI(title="Instagram Manual Signup Queue")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict this to your hosted frontend in production.
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init():
    c = conn()
    c.execute("""CREATE TABLE IF NOT EXISTS queue (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT NOT NULL UNIQUE,
        username TEXT DEFAULT '',
        display_name TEXT DEFAULT '',
        bio TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'pending',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT NOT NULL,
        action TEXT NOT NULL,
        created_at TEXT NOT NULL
    )""")
    c.commit(); c.close()

init()

def now(): return datetime.datetime.utcnow().isoformat(timespec="seconds") + "Z"

def log(email, action):
    c=conn(); c.execute("INSERT INTO logs(email,action,created_at) VALUES(?,?,?)",(email,action,now())); c.commit(); c.close()

class EmailItem(BaseModel):
    email: EmailStr
    username: str = ""
    display_name: str = ""
    bio: str = ""

class StatusBody(BaseModel):
    status: str

@app.get("/api/queue")
def queue():
    c=conn()
    rows=[dict(r) for r in c.execute("SELECT * FROM queue ORDER BY id").fetchall()]
    c.close()
    return rows

@app.post("/api/queue")
def add_items(items: list[EmailItem]):
    c=conn(); added=0
    for x in items:
        try:
            t=now()
            c.execute("""INSERT INTO queue(email,username,display_name,bio,status,created_at,updated_at)
                         VALUES(?,?,?,?,?,?,?)""",
                      (x.email,x.username,x.display_name,x.bio,"pending",t,t))
            log(x.email,"added_to_queue"); added += 1
        except sqlite3.IntegrityError:
            pass
    c.commit(); c.close()
    return {"added":added}

@app.post("/api/queue/{item_id}/status")
def set_status(item_id:int, body:StatusBody):
    allowed={"pending","verification","completed","failed"}
    if body.status not in allowed: raise HTTPException(400,"Invalid status")
    c=conn()
    row=c.execute("SELECT email FROM queue WHERE id=?",(item_id,)).fetchone()
    if not row: c.close(); raise HTTPException(404,"Not found")
    c.execute("UPDATE queue SET status=?,updated_at=? WHERE id=?",(body.status,now(),item_id))
    c.commit(); c.close(); log(row["email"],body.status)
    return {"ok":True}

@app.post("/api/queue/{item_id}/start")
def start(item_id:int):
    c=conn()
    row=c.execute("SELECT * FROM queue WHERE id=?",(item_id,)).fetchone()
    if not row: c.close(); raise HTTPException(404,"Not found")
    c.execute("UPDATE queue SET status='verification',updated_at=? WHERE id=?",(now(),item_id))
    c.commit(); c.close()
    log(row["email"],"signup_started_manual_verification")
    return {"ok":True,"signup_url":"https://www.instagram.com/accounts/emailsignup/"}

@app.get("/api/logs")
def logs():
    c=conn(); rows=[dict(r) for r in c.execute("SELECT * FROM logs ORDER BY id DESC LIMIT 200").fetchall()]; c.close()
    return rows

@app.get("/api/health")
def health(): return {"ok":True}
