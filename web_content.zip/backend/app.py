"""
LIBYA BUSINESS PRO API - Step 2 foundation
Python standard library only: WSGI + SQLite + PBKDF2 + HMAC sessions.
Run: python backend/app.py
"""
import os, json, sqlite3, hashlib, hmac, secrets, time, base64
from datetime import datetime, timezone
from wsgiref.simple_server import make_server
from urllib.parse import parse_qs

ROOT = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("LBP_DB_PATH", os.path.join(ROOT, "libya_business_pro.sqlite3"))
SECRET = os.environ.get("LBP_SECRET", "CHANGE_THIS_SECRET_BEFORE_PRODUCTION")
TOKEN_TTL = 60 * 60 * 24 * 7

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, email TEXT UNIQUE COLLATE NOCASE, phone TEXT UNIQUE,
 password_hash TEXT NOT NULL, password_salt TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS organizations (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, currency TEXT NOT NULL DEFAULT 'LYD',
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS memberships (
 user_id TEXT NOT NULL REFERENCES users(id), org_id TEXT NOT NULL REFERENCES organizations(id),
 role TEXT NOT NULL CHECK(role IN ('owner','admin','accountant','cashier','viewer')),
 created_at TEXT NOT NULL, PRIMARY KEY(user_id, org_id)
);
CREATE TABLE IF NOT EXISTS branches (
 id TEXT PRIMARY KEY, org_id TEXT NOT NULL REFERENCES organizations(id),
 name TEXT NOT NULL, code TEXT NOT NULL, created_at TEXT NOT NULL,
 UNIQUE(org_id, code)
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
 expires_at INTEGER NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sales (
 id TEXT PRIMARY KEY, org_id TEXT NOT NULL REFERENCES organizations(id),
 branch_id TEXT NOT NULL REFERENCES branches(id), invoice_no TEXT NOT NULL,
 customer TEXT NOT NULL, total_minor INTEGER NOT NULL, currency TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'completed', idempotency_key TEXT NOT NULL,
 created_by TEXT NOT NULL REFERENCES users(id), created_at TEXT NOT NULL,
 UNIQUE(org_id, idempotency_key), UNIQUE(org_id, invoice_no)
);
CREATE TABLE IF NOT EXISTS products (
 id TEXT PRIMARY KEY, org_id TEXT NOT NULL REFERENCES organizations(id),
 branch_id TEXT NOT NULL REFERENCES branches(id), sku TEXT NOT NULL,
 name TEXT NOT NULL, price_minor INTEGER NOT NULL, stock INTEGER NOT NULL DEFAULT 0,
 active INTEGER NOT NULL DEFAULT 1, created_by TEXT NOT NULL REFERENCES users(id),
 created_at TEXT NOT NULL, UNIQUE(org_id, sku)
);
CREATE INDEX IF NOT EXISTS idx_products_org ON products(org_id, active);
CREATE TABLE IF NOT EXISTS audit_log (
 id TEXT PRIMARY KEY, org_id TEXT NOT NULL REFERENCES organizations(id),
 branch_id TEXT, user_id TEXT NOT NULL REFERENCES users(id),
 action TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL,
 details_json TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sync_receipts (
 org_id TEXT NOT NULL REFERENCES organizations(id), idempotency_key TEXT NOT NULL,
 response_json TEXT NOT NULL, created_at TEXT NOT NULL,
 PRIMARY KEY(org_id, idempotency_key)
);
CREATE INDEX IF NOT EXISTS idx_sales_org_date ON sales(org_id, created_at);
CREATE INDEX IF NOT EXISTS idx_audit_org_date ON audit_log(org_id, created_at);
"""

def now():
    return datetime.now(timezone.utc).isoformat()

def db():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c

def init_db():
    with db() as c:
        c.executescript(SCHEMA)

def enc(b):
    return base64.urlsafe_b64encode(b).decode().rstrip("=")

def dec(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))

def pw_hash(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 240000).hex()

def make_token(user_id):
    payload = enc(json.dumps({"sub": user_id, "exp": int(time.time()) + TOKEN_TTL}).encode())
    sig = enc(hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).digest())
    return payload + "." + sig

def token_user(token):
    try:
        payload, sig = token.split(".", 1)
        expected = enc(hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, expected):
            return None
        data = json.loads(dec(payload))
        if data["exp"] < int(time.time()):
            return None
        return data["sub"]
    except Exception:
        return None

def response(start_response, status, data):
    body = json.dumps(data, ensure_ascii=False).encode()
    start_response(status, [("Content-Type","application/json; charset=utf-8"),
                            ("Content-Length",str(len(body))),
                            ("Cache-Control","no-store")])
    return [body]

def read_json(environ):
    try:
        n = int(environ.get("CONTENT_LENGTH") or 0)
        if n > 1_000_000:
            return {}
        return json.loads(environ["wsgi.input"].read(n) or b"{}")
    except Exception:
        return {}

def current_user(environ):
    auth = environ.get("HTTP_AUTHORIZATION", "")
    if not auth.startswith("Bearer "):
        return None
    token = auth[7:]
    uid = token_user(token)
    if not uid:
        return None
    th = hashlib.sha256(token.encode()).hexdigest()
    with db() as c:
        row = c.execute("SELECT user_id FROM sessions WHERE token_hash=? AND expires_at>?",
                        (th, int(time.time()))).fetchone()
    return uid if row else None

def membership(c, uid, org_id):
    return c.execute("""SELECT m.role,o.name,o.currency FROM memberships m
                        JOIN organizations o ON o.id=m.org_id
                        WHERE m.user_id=? AND m.org_id=?""", (uid, org_id)).fetchone()

def audit(c, org_id, branch_id, uid, action, entity_type, entity_id, details):
    c.execute("""INSERT INTO audit_log VALUES(?,?,?,?,?,?,?,?,?)""",
        (secrets.token_hex(16), org_id, branch_id, uid, action, entity_type,
         entity_id, json.dumps(details, ensure_ascii=False), now()))

def app(environ, start_response):
    path = environ.get("PATH_INFO", "/")
    method = environ.get("REQUEST_METHOD", "GET").upper()
    data = read_json(environ) if method in ("POST","PUT","PATCH") else {}
    if path == "/health" and method == "GET":
        return response(start_response, "200 OK", {"ok": True, "service":"LIBYA BUSINESS PRO API", "database":"sqlite"})
    if path == "/auth/register" and method == "POST":
        email = (data.get("email") or "").strip().lower() or None
        phone = (data.get("phone") or "").strip() or None
        password = data.get("password") or ""
        org_name = (data.get("organization_name") or "").strip()
        if (not email and not phone) or len(password) < 10 or not org_name:
            return response(start_response, "400 Bad Request", {"error":"email_or_phone_and_org_required", "message":"أدخل البريد أو الهاتف واسم الشركة وكلمة مرور لا تقل عن 10 أحرف"})
        uid, oid, bid = secrets.token_hex(16), secrets.token_hex(16), secrets.token_hex(16)
        salt = secrets.token_bytes(16)
        try:
            with db() as c:
                c.execute("INSERT INTO users VALUES(?,?,?,?,?,?)",
                    (uid,email,phone,pw_hash(password,salt),salt.hex(),now()))
                c.execute("INSERT INTO organizations VALUES(?,?,?,?)",(oid,org_name,"LYD",now()))
                c.execute("INSERT INTO memberships VALUES(?,?,?,?)",(uid,oid,"owner",now()))
                c.execute("INSERT INTO branches VALUES(?,?,?,?,?)",(bid,oid,"الفرع الرئيسي","MAIN",now()))
                audit(c,oid,bid,uid,"organization.created","organization",oid,{"name":org_name})
        except sqlite3.IntegrityError:
            return response(start_response, "409 Conflict", {"error":"account_exists","message":"البريد أو رقم الهاتف مستخدم بالفعل"})
        return response(start_response, "201 Created", {"user_id":uid,"organization_id":oid,"branch_id":bid,"message":"تم إنشاء الحساب والشركة والفرع. سجّل الدخول."})
    if path == "/auth/login" and method == "POST":
        ident = (data.get("email_or_phone") or "").strip()
        password = data.get("password") or ""
        with db() as c:
            row = c.execute("SELECT * FROM users WHERE email=? COLLATE NOCASE OR phone=?", (ident,ident)).fetchone()
            if not row or not hmac.compare_digest(pw_hash(password,bytes.fromhex(row["password_salt"])),row["password_hash"]):
                return response(start_response, "401 Unauthorized", {"error":"invalid_credentials","message":"بيانات الدخول غير صحيحة"})
            token = make_token(row["id"])
            th = hashlib.sha256(token.encode()).hexdigest()
            c.execute("INSERT INTO sessions VALUES(?,?,?,?)",(th,row["id"],int(time.time())+TOKEN_TTL,now()))
            orgs = c.execute("""SELECT o.id,o.name,o.currency,m.role FROM organizations o
                               JOIN memberships m ON m.org_id=o.id WHERE m.user_id=?""",(row["id"],)).fetchall()
        return response(start_response, "200 OK", {"access_token":token,"token_type":"Bearer","expires_in":TOKEN_TTL,"organizations":[dict(x) for x in orgs]})
    uid = current_user(environ)
    if not uid:
        return response(start_response, "401 Unauthorized", {"error":"authentication_required","message":"سجّل الدخول أولاً"})
    if path == "/auth/logout" and method == "POST":
        token = environ.get("HTTP_AUTHORIZATION","")[7:]
        with db() as c:
            c.execute("DELETE FROM sessions WHERE token_hash=?",(hashlib.sha256(token.encode()).hexdigest(),))
        return response(start_response, "200 OK", {"ok":True})
    if path == "/me" and method == "GET":
        with db() as c:
            user = c.execute("SELECT id,email,phone,created_at FROM users WHERE id=?",(uid,)).fetchone()
            orgs = c.execute("""SELECT o.id,o.name,o.currency,m.role FROM organizations o
                                JOIN memberships m ON m.org_id=o.id WHERE m.user_id=?""",(uid,)).fetchall()
        return response(start_response, "200 OK", {"user":dict(user),"organizations":[dict(x) for x in orgs]})
    if path == "/branches" and method == "GET":
        org_id = environ.get("HTTP_X_ORGANIZATION_ID","")
        with db() as c:
            m = membership(c,uid,org_id)
            if not m: return response(start_response,"403 Forbidden",{"error":"organization_access_denied"})
            rows = c.execute("SELECT id,name,code,created_at FROM branches WHERE org_id=?",(org_id,)).fetchall()
        return response(start_response,"200 OK",{"branches":[dict(x) for x in rows]})
    if path == "/branches" and method == "POST":
        org_id = environ.get("HTTP_X_ORGANIZATION_ID","")
        with db() as c:
            m = membership(c,uid,org_id)
            if not m: return response(start_response,"403 Forbidden",{"error":"organization_access_denied"})
            if m["role"] not in ("owner","admin"): return response(start_response,"403 Forbidden",{"error":"role_not_allowed"})
            name=(data.get("name") or "").strip(); code=(data.get("code") or "").strip().upper()
            if not name or not code: return response(start_response,"400 Bad Request",{"error":"name_and_code_required"})
            bid=secrets.token_hex(16)
            try: c.execute("INSERT INTO branches VALUES(?,?,?,?,?)",(bid,org_id,name,code,now()))
            except sqlite3.IntegrityError: return response(start_response,"409 Conflict",{"error":"branch_code_exists"})
            audit(c,org_id,bid,uid,"branch.created","branch",bid,{"name":name,"code":code})
        return response(start_response,"201 Created",{"id":bid,"name":name,"code":code})
    if path == "/products" and method == "GET":
        org_id=environ.get("HTTP_X_ORGANIZATION_ID","")
        with db() as c:
            m=membership(c,uid,org_id)
            if not m: return response(start_response,"403 Forbidden",{"error":"organization_access_denied"})
            rows=c.execute("""SELECT id,branch_id,sku,name,price_minor,stock,active,created_at
                              FROM products WHERE org_id=? ORDER BY name""",(org_id,)).fetchall()
        return response(start_response,"200 OK",{"products":[dict(x) for x in rows]})
    if path == "/sales" and method == "GET":
        org_id=environ.get("HTTP_X_ORGANIZATION_ID","")
        with db() as c:
            m=membership(c,uid,org_id)
            if not m: return response(start_response,"403 Forbidden",{"error":"organization_access_denied"})
            rows=c.execute("""SELECT id,branch_id,invoice_no,customer,total_minor,currency,status,created_at
                              FROM sales WHERE org_id=? ORDER BY created_at DESC LIMIT 500""",(org_id,)).fetchall()
        return response(start_response,"200 OK",{"sales":[dict(x) for x in rows]})
    if path == "/sync/push" and method == "POST":
        org_id=environ.get("HTTP_X_ORGANIZATION_ID","")
        ops=data.get("operations") or []
        if not isinstance(ops,list) or len(ops)>100: return response(start_response,"400 Bad Request",{"error":"operations_must_be_array_max_100"})
        results=[]
        with db() as c:
            m=membership(c,uid,org_id)
            if not m: return response(start_response,"403 Forbidden",{"error":"organization_access_denied"})
            if m["role"] not in ("owner","admin","accountant","cashier"):
                return response(start_response,"403 Forbidden",{"error":"role_not_allowed"})
            for op in ops:
                key=str(op.get("idempotency_key") or "").strip()
                kind=op.get("type")
                payload=op.get("payload") or {}
                if not key or len(key)>128:
                    results.append({"idempotency_key":key,"ok":False,"error":"valid_idempotency_key_required"}); continue
                previous=c.execute("SELECT response_json FROM sync_receipts WHERE org_id=? AND idempotency_key=?",(org_id,key)).fetchone()
                if previous:
                    results.append(json.loads(previous["response_json"])); continue
                try:
                    branch_id=str(payload.get("branch_id") or "")
                    branch=c.execute("SELECT id FROM branches WHERE id=? AND org_id=?",(branch_id,org_id)).fetchone()
                    if not branch: raise ValueError("branch_not_in_organization")
                    if kind=="sale.create":
                        total=float(payload.get("total",0))
                        if total<0 or total>1_000_000_000: raise ValueError("invalid_total")
                        total_minor=round(total*100)
                        invoice_no=str(payload.get("invoice_no") or ("INV-"+secrets.token_hex(5).upper()))
                        sid=secrets.token_hex(16)
                        c.execute("""INSERT INTO sales(id,org_id,branch_id,invoice_no,customer,total_minor,currency,status,idempotency_key,created_by,created_at)
                                     VALUES(?,?,?,?,?,?,?,'completed',?,?,?)""",
                            (sid,org_id,branch_id,invoice_no,str(payload.get("customer") or "عميل نقدي"),total_minor,"LYD",key,uid,now()))
                        audit(c,org_id,branch_id,uid,"sale.created","sale",sid,{"invoice_no":invoice_no,"total_minor":total_minor,"idempotency_key":key})
                        result={"idempotency_key":key,"ok":True,"sale_id":sid,"invoice_no":invoice_no,"total_minor":total_minor}
                    elif kind=="product.create":
                        sku=str(payload.get("sku") or "").strip().upper()
                        name=str(payload.get("name") or "").strip()
                        price=float(payload.get("price",0))
                        stock=int(payload.get("stock",0))
                        if not sku or not name or price<0 or price>1_000_000_000 or stock<0:
                            raise ValueError("invalid_product_fields")
                        pid=secrets.token_hex(16)
                        price_minor=round(price*100)
                        c.execute("INSERT INTO products VALUES(?,?,?,?,?,?,1,?,?,?)",
                            (pid,org_id,branch_id,sku,name,price_minor,stock,uid,now()))
                        audit(c,org_id,branch_id,uid,"product.created","product",pid,{"sku":sku,"name":name,"stock":stock,"price_minor":price_minor})
                        result={"idempotency_key":key,"ok":True,"product_id":pid,"sku":sku}
                    else:
                        raise ValueError("unsupported_operation")
                except (ValueError,sqlite3.IntegrityError) as e:
                    result={"idempotency_key":key,"ok":False,"error":str(e) or "operation_failed"}
                c.execute("INSERT INTO sync_receipts VALUES(?,?,?,?)",(org_id,key,json.dumps(result,ensure_ascii=False),now()))
                results.append(result)
        return response(start_response,"200 OK",{"results":results})
    return response(start_response,"404 Not Found",{"error":"not_found"})

if __name__ == "__main__":
    init_db()
    port=int(os.environ.get("PORT","8080"))
    print(f"LIBYA BUSINESS PRO API listening on http://127.0.0.1:{port}")
    make_server("0.0.0.0",port,app).serve_forever()
