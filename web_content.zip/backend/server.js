/**
 * Shivania AI - Secure Backend Proxy Server
 * 
 * This server allows running Shivania AI without exposing your GEMINI_API_KEY to the browser.
 * It forwards streaming chat completions directly from Google Gemini API.
 */

const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

const app = express();
const PORT = process.env.PORT || 3000;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const DEFAULT_MODEL = process.env.GEMINI_MODEL || 'gemini-3.8-flash';

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Serve static frontend files from parent directory
app.use(express.static(path.join(__dirname, '../')));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    appName: 'Shivania AI Backend Proxy',
    hasApiKey: !!GEMINI_API_KEY && GEMINI_API_KEY !== 'your_actual_gemini_api_key_here',
    defaultModel: DEFAULT_MODEL,
    timestamp: new Date().toISOString()
  });
});

// Verify API Key endpoint
app.get('/api/verify-key', async (req, res) => {
  const apiKey = req.headers['x-gemini-key'] || GEMINI_API_KEY;
  if (!apiKey || apiKey === 'your_actual_gemini_api_key_here') {
    return res.status(400).json({ error: 'No Gemini API key configured.' });
  }

  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`);
    if (!response.ok) {
      const err = await response.json();
      return res.status(response.status).json({ error: err.error?.message || 'Invalid API key' });
    }
    const data = await response.json();
    const chatModels = (data.models || [])
      .filter(m => m.supportedGenerationMethods && m.supportedGenerationMethods.includes('generateContent'))
      .map(m => m.name.replace('models/', ''));

    return res.json({ success: true, models: chatModels });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to connect to Google Gemini API: ' + err.message });
  }
});

// Chat completion endpoint with SSE streaming
app.post('/api/chat', async (req, res) => {
  const apiKey = req.headers['x-gemini-key'] || GEMINI_API_KEY;

  if (!apiKey || apiKey === 'your_actual_gemini_api_key_here') {
    return res.status(401).json({
      error: 'GEMINI_API_KEY is not configured. Please set it in your .env file or in the app Settings.'
    });
  }

  const { contents, systemInstruction, generationConfig, model = DEFAULT_MODEL, stream = true } = req.body;

  if (!contents || !Array.isArray(contents)) {
    return res.status(400).json({ error: 'Invalid request body: "contents" array is required.' });
  }

  const endpoint = stream ? 'streamGenerateContent' : 'generateContent';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:${endpoint}?key=${apiKey}${stream ? '&alt=sse' : ''}`;

  try {
    const payload = {
      contents,
      generationConfig: {
        temperature: 0.85,
        topP: 0.95,
        maxOutputTokens: 1024,
        ...(generationConfig || {})
      },
      safetySettings: [
        { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_MEDIUM_AND_ABOVE' },
        { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_MEDIUM_AND_ABOVE' },
        { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_MEDIUM_AND_ABOVE' },
        { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_MEDIUM_AND_ABOVE' }
      ]
    };

    if (systemInstruction) {
      payload.systemInstruction = systemInstruction;
    }

    const geminiRes = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!geminiRes.ok) {
      const errorData = await geminiRes.json();
      return res.status(geminiRes.status).json({
        error: errorData.error?.message || 'Google Gemini API returned an error',
        details: errorData
      });
    }

    if (stream) {
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');

      const reader = geminiRes.body.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        res.write(chunk);
      }
      res.end();
    } else {
      const data = await geminiRes.json();
      return res.json(data);
    }
  } catch (error) {
    console.error('Gemini Proxy Error:', error);
    if (!res.headersSent) {
      res.status(500).json({ error: 'Internal server error: ' + error.message });
    } else {
      res.end();
    }
  }
});

app.listen(PORT, () => {
  console.log(`===============================================`);
  console.log(`✨ Shivania AI server running at: http://localhost:${PORT}`);
  console.log(`🔑 Gemini API Key configured: ${!!GEMINI_API_KEY && GEMINI_API_KEY !== 'your_actual_gemini_api_key_here' ? 'YES' : 'NO (Set in .env or Settings)'}`);
  console.log(`🤖 Default Model: ${DEFAULT_MODEL}`);
  console.log(`===============================================`);
});
