const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { Pool } = require('pg');

const app = express();
const port = process.env.PORT || 3000;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const publicDir = path.join(__dirname, '..', 'frontend');
const uploadDir = path.join(__dirname, 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(uploadDir));
app.use(express.static(publicDir));

const storage = multer.diskStorage({
  destination: uploadDir,
  filename: (_, file, cb) => {
    const safe = Date.now() + '-' + file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
    cb(null, safe);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 200 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    cb(null, /^video\/(mp4|webm|quicktime)$/.test(file.mimetype));
  }
});

app.get('/api/health', (_, res) => res.json({ok:true, name:'DZ SHORTS v3000'}));

app.get('/api/videos', async (_, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT * FROM videos ORDER BY created_at DESC'
    );
    res.json(rows);
  } catch (e) {
    res.status(500).json({error:'database_error'});
  }
});

app.post('/api/videos', upload.single('video'), async (req, res) => {
  try {
    const username = (req.body.username || '@dz_user').slice(0,80);
    const caption = req.body.caption || '';
    const videoUrl = req.file ? `/uploads/${req.file.filename}` : null;
    const { rows } = await pool.query(
      'INSERT INTO videos(username,caption,video_url) VALUES($1,$2,$3) RETURNING *',
      [username, caption, videoUrl]
    );
    res.status(201).json(rows[0]);
  } catch (e) {
    res.status(500).json({error:'upload_failed'});
  }
});

app.post('/api/videos/:id/like', async (req,res)=>{
  try {
    const { rows } = await pool.query(
      'UPDATE videos SET likes=likes+1 WHERE id=$1 RETURNING *',[req.params.id]
    );
    res.json(rows[0] || {});
  } catch(e) { res.status(500).json({error:'like_failed'}); }
});

app.post('/api/videos/:id/view', async (req,res)=>{
  try {
    const { rows } = await pool.query(
      'UPDATE videos SET views=views+1 WHERE id=$1 RETURNING views',[req.params.id]
    );
    res.json(rows[0] || {});
  } catch(e) { res.status(500).json({error:'view_failed'}); }
});

app.get('*', (_,res)=>res.sendFile(path.join(publicDir,'index.html')));

app.listen(port, ()=>console.log(`DZ SHORTS v3000 running on ${port}`));
