const express=require("express"), multer=require("multer"), helmet=require("helmet"), cors=require("cors"), rateLimit=require("express-rate-limit");
const fs=require("fs"),path=require("path"),os=require("os"),crypto=require("crypto"),{spawn}=require("child_process"),AdmZip=require("adm-zip");
const app=express(),PORT=process.env.PORT||8787,API_KEY=process.env.NEXUS_API_KEY;
app.use(helmet({crossOriginResourcePolicy:{policy:"cross-origin"}}));
app.use(cors({origin:(process.env.ALLOWED_ORIGIN||"").split(",").filter(Boolean)}));
app.use(express.json({limit:"32kb"}));app.use("/api",rateLimit({windowMs:60_000,max:5}));
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:100*1024*1024,files:1}});
function auth(req,res,next){if(!API_KEY)return res.status(503).send("Defina NEXUS_API_KEY no servidor antes de aceitar builds.");const expected=Buffer.from("Bearer "+API_KEY), supplied=Buffer.from(req.headers.authorization||"");if(supplied.length!==expected.length||!crypto.timingSafeEqual(supplied,expected))return res.status(401).send("Chave de API inválida.");next()}
function validConfig(c){if(!c||typeof c!=="object")throw Error("Configuração ausente.");if(!/^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*){1,}$/.test(c.packageName||""))throw Error("Nome de pacote inválido.");if(!Number.isInteger(+c.versionCode)||+c.versionCode<1)throw Error("versionCode inválido.");if(![23,26,29].includes(+c.minSdk))throw Error("minSdk não permitido.");return c}
function run(command,args,cwd,timeout=240000){return new Promise((resolve,reject)=>{const p=spawn(command,args,{cwd,env:{...process.env,GRADLE_OPTS:"-Dorg.gradle.daemon=false"},stdio:["ignore","pipe","pipe"]});let out="";p.stdout.on("data",d=>{out+=d.toString();if(out.length>30000)out=out.slice(-30000)});p.stderr.on("data",d=>{out+=d.toString();if(out.length>30000)out=out.slice(-30000)});const timer=setTimeout(()=>{p.kill("SIGKILL");reject(Error("Tempo limite excedido. "+out.slice(-3000)))},timeout);p.on("error",e=>{clearTimeout(timer);reject(e)});p.on("close",code=>{clearTimeout(timer);code===0?resolve(out):reject(Error("Gradle falhou (código "+code+"). "+out.slice(-6000)))})})}
app.get("/health",(req,res)=>res.json({ok:true,service:"NEXUS Android Build API"}));
app.post("/api/build",auth,upload.single("project"),async(req,res)=>{let dir;try{
 if(!req.file)return res.status(400).send("Arquivo ZIP do projeto não enviado.");
 const c=validConfig(JSON.parse(req.body.config||"{}"));dir=fs.mkdtempSync(path.join(os.tmpdir(),"nexus-build-"));
 const zip=new AdmZip(req.file.buffer),root=path.join(dir,"app/src/main/assets/www");fs.mkdirSync(root,{recursive:true});
 for(const e of zip.getEntries()){if(e.isDirectory)continue;const name=e.entryName.replace(/\\/g,"/");if(name.startsWith("/")||name.split("/").includes("..")||name.includes("\0"))continue;const dest=path.resolve(root,name);if(!dest.startsWith(root+path.sep))continue;fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,e.getData())}
 if(!fs.existsSync(path.join(root,"index.html")))throw Error("O ZIP precisa conter index.html na raiz do projeto.");
 const tpl=path.join(__dirname,"android-template");fs.cpSync(tpl,dir,{recursive:true});
 const pkg=c.packageName,activityPath=path.join(dir,"app/src/main/java",...pkg.split("."));fs.mkdirSync(activityPath,{recursive:true});
 const activity=path.join(activityPath,"MainActivity.kt");
 const code=`package ${pkg}\n\nimport android.app.Activity\nimport android.os.Bundle\nimport android.webkit.WebView\nimport android.webkit.WebViewClient\nimport android.view.View\n\nclass MainActivity : Activity() {\n override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)\n val web=WebView(this); web.webViewClient=WebViewClient(); web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true\n web.loadUrl(\"file:///android_asset/www/index.html\"); setContentView(web)\n ${c.fullscreen?"window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)":""}\n }\n}\n`;fs.writeFileSync(activity,code);
 const manifest=`<manifest xmlns:android="http://schemas.android.com/apk/res/android"><uses-permission android:name="android.permission.INTERNET" />\n<application android:theme="@android:style/Theme.Material.Light.NoActionBar" android:label="${String(c.appName||"NEXUS App").replace(/[&<>"]/g,"")} " android:usesCleartextTraffic="true"><activity android:name="${pkg}.MainActivity" android:screenOrientation="${c.orientation||"unspecified"}" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>`;
 fs.writeFileSync(path.join(dir,"app/src/main/AndroidManifest.xml"),manifest);
 const gradle=fs.readFileSync(path.join(dir,"app/build.gradle"),"utf8").replace(/applicationId\s+"[^"]+"/,`applicationId "${pkg}"`).replace(/versionCode\s+\d+/,`versionCode ${+c.versionCode}`).replace(/versionName\s+"[^"]+"/,`versionName "${String(c.versionName||"1.0.0").replace(/"/g,"")}"`).replace(/minSdk\s+\d+/,`minSdk ${+c.minSdk}`);
 fs.writeFileSync(path.join(dir,"app/build.gradle"),gradle);
 const output=await run(process.env.GRADLE_BIN||"gradle",["--no-daemon","--stacktrace","assembleDebug"],dir);
 const apk=path.join(dir,"app/build/outputs/apk/debug/app-debug.apk");if(!fs.existsSync(apk))throw Error("Gradle terminou, mas o APK não foi encontrado.");
 res.setHeader("Content-Type","application/vnd.android.package-archive");res.setHeader("Content-Disposition",'attachment; filename="nexus-app-debug.apk"');res.sendFile(apk,err=>{if(err)console.error(err);fs.rmSync(dir,{recursive:true,force:true})});dir=null;
 }catch(e){console.error(e);res.status(500).type("text/plain").send(e.message||"Falha na compilação.");}finally{if(dir)fs.rmSync(dir,{recursive:true,force:true})}
});
app.listen(PORT,()=>console.log(`NEXUS Build API listening on ${PORT}`));
