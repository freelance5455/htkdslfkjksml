import express from "express";
import cors from "cors";
import crypto from "crypto";

const app = express();
const port = Number(process.env.PORT || 3000);
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-6-luna";
const MAX_INPUT_CHARS = Number(process.env.MAX_INPUT_CHARS || 4000);

if (!OPENAI_API_KEY) {
  console.warn("WARNING: OPENAI_API_KEY is not configured. /api/chat will return 503.");
}

app.use(cors({
  origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(",") : true
}));
app.use(express.json({ limit: "128kb" }));

const devices = new Map();
const activity = [];

app.get("/api/health", (_, res) => res.json({
  ok: true,
  service: "Smart API",
  version: "1.4.0",
  aiConfigured: Boolean(OPENAI_API_KEY)
}));

app.post("/api/devices/register", (req, res) => {
  const { deviceId, name, platform = "android" } = req.body || {};
  if (!deviceId) return res.status(400).json({ error: "deviceId required" });
  const d = {
    deviceId,
    name: name || "Android device",
    platform,
    authorized: false,
    updatedAt: new Date().toISOString()
  };
  devices.set(deviceId, d);
  res.json(d);
});

app.get("/api/devices", (_, res) => res.json([...devices.values()]));

function systemInstructions() {
  return `You are Smart, an Android AI assistant.
Help the user clearly and concisely.
You may explain how to perform phone tasks, but do not claim you performed an Android action unless the Android app actually reports that action succeeded.
Never request or expose secret API keys.
For actions that require Android permissions, tell the user when permission is required.
Keep responses suitable for a mobile assistant.`;
}

app.post("/api/chat", async (req, res) => {
  const message = String(req.body?.message || "").trim();
  const sessionId = String(req.body?.sessionId || "").trim() || crypto.randomUUID();
  const deviceId = String(req.body?.deviceId || "").trim() || null;

  if (!message) return res.status(400).json({ error: "message required" });
  if (message.length > MAX_INPUT_CHARS) {
    return res.status(413).json({ error: `message too long; maximum is ${MAX_INPUT_CHARS} characters` });
  }
  if (!OPENAI_API_KEY) {
    return res.status(503).json({ error: "AI backend is not configured. Set OPENAI_API_KEY on the server." });
  }

  try {
    const r = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: OPENAI_MODEL,
        instructions: systemInstructions(),
        input: message,
        max_output_tokens: 700
      })
    });

    const data = await r.json();
    if (!r.ok) {
      console.error("OpenAI error:", JSON.stringify(data));
      return res.status(502).json({ error: "AI provider request failed." });
    }

    const content = String(data.output_text || "").trim();
    const item = {
      id: crypto.randomUUID(),
      sessionId,
      deviceId,
      command: message,
      response: content,
      status: "completed",
      model: OPENAI_MODEL,
      createdAt: new Date().toISOString()
    };
    activity.push(item);
    if (activity.length > 500) activity.shift();

    res.json({
      ok: true,
      sessionId,
      response: content || "I didn't receive a text response from the AI provider."
    });
  } catch (error) {
    console.error(error);
    res.status(502).json({ error: "Unable to reach the AI provider." });
  }
});

app.post("/api/command", (req, res) => {
  const command = String(req.body?.command || "").trim();
  if (!command) return res.status(400).json({ error: "command required" });
  const item = {
    id: crypto.randomUUID(),
    command,
    deviceId: req.body?.deviceId || null,
    status: "received",
    createdAt: new Date().toISOString()
  };
  activity.push(item);
  res.json({ ok: true, message: `Smart received: "${command}"`, commandId: item.id, status: item.status });
});

app.get("/api/activity", (_, res) => res.json(activity.slice(-100).reverse()));

app.post("/api/billing/google-play", (req, res) => {
  const { userId, productId, purchaseToken } = req.body || {};
  if (!userId || !productId || !purchaseToken) {
    return res.status(400).json({ error: "userId, productId and purchaseToken are required" });
  }
  return res.status(202).json({
    status: "pending_verification",
    message: "Purchase received. Configure Google Play Developer API verification before granting Pro access."
  });
});

app.listen(port, () => console.log(`Smart API listening on ${port}`));
