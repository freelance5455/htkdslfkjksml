const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const admin = require('firebase-admin');
const { google } = require('googleapis');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { OAuth2Client } = require('google-auth-library');

const app = express();
app.set('trust proxy', 1); // Caddy/Nginx ke peeche asli IP
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*", methods: ["GET", "POST"] }
});

// ==========================================
// 1. FIREBASE PUSH NOTIFICATION SETUP
// ==========================================
// 'serviceAccountKey.json' Firebase Console se download karke is folder me rakho
try {
  admin.initializeApp({
    credential: admin.credential.cert(require('./serviceAccountKey.json'))
  });
  console.log("Firebase initialized successfully.");
} catch (error) {
  console.warn("Firebase credentials not found. Notifications will run in mock mode.");
}

async function sendPushNotification(targetToken, title, body) {
  const message = { notification: { title, body }, token: targetToken };
  try {
    return await admin.messaging().send(message);
  } catch (err) {
    console.error("Push Error:", err.message);
  }
}

// ==========================================
// 2. DATABASE (JSON file: data/db.json) + GOOGLE LOGIN SESSIONS
// ==========================================
// GOOGLE_CLIENT_ID = Google Cloud Console ka *Web application* OAuth client ID
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || '';
const START_COINS = parseInt(process.env.START_COINS || '0', 10);
const SESSION_DAYS = 30;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const googleClient = new OAuth2Client(GOOGLE_CLIENT_ID);

let db = { users: {}, sessions: {} }; // sessions: sha256(token) -> { userId, exp }
try {
  db = Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE, 'utf8')));
} catch (e) { /* pehli baar: file nahi hai */ }
if (!Object.keys(db.users).length && process.env.SEED_TEST_USERS === 'true') {
  db.users.user_1 = { id: 'user_1', name: 'Host_Nishant', coins: 500, diamonds: 0, fcmToken: '' };
  db.users.user_2 = { id: 'user_2', name: 'User_Guest', coins: 2000, diamonds: 0, fcmToken: '' };
}

let saveTimer = null;
function saveDb() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      const tmp = DB_FILE + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(db));
      fs.renameSync(tmp, DB_FILE);
    } catch (e) { console.error('DB save error:', e.message); }
  }, 300);
}
function flushDb() { clearTimeout(saveTimer); try { fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(DB_FILE, JSON.stringify(db)); } catch (e) {} }
process.on('SIGTERM', () => { flushDb(); process.exit(0); });
process.on('SIGINT', () => { flushDb(); process.exit(0); });

const sha = (t) => crypto.createHash('sha256').update(String(t)).digest('hex');

function createSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  db.sessions[sha(token)] = { userId, exp: Date.now() + SESSION_DAYS * 864e5 };
  saveDb();
  return token;
}
function userFromToken(token) {
  if (!token) return null;
  const s = db.sessions[sha(token)];
  if (!s) return null;
  if (s.exp < Date.now()) { delete db.sessions[sha(token)]; saveDb(); return null; }
  return db.users[s.userId] || null;
}
// purane sessions saaf karo
setInterval(() => {
  let n = 0;
  for (const k of Object.keys(db.sessions)) if (db.sessions[k].exp < Date.now()) { delete db.sessions[k]; n++; }
  if (n) saveDb();
}, 3600e3).unref();

// ---- Public numeric ID (pid): har user ka unique number ----
const OWNER_EMAIL = (process.env.OWNER_EMAIL || 'nishantkumar854204@gmail.com').toLowerCase();
const RESERVED_PIDS = new Set(['600000001','600000002','600000003','600000004','600000005','600000006','600000007','600000008']);
db.nextPid = db.nextPid || 700000001;
const pidTaken = (pid, exceptId) => RESERVED_PIDS.has(pid) || Object.values(db.users).some(x => x.pid === pid && x.id !== exceptId);
function newPid() { let p; do { p = String(db.nextPid++); } while (pidTaken(p)); return p; }
function randomPid() { let p; do { p = String(100000000 + crypto.randomInt(900000000)); } while (pidTaken(p)); return p; }
Object.values(db.users).forEach(u => { if (!u.pid) u.pid = newPid(); }); // purane users ko ID do
const isOwner = (u) => !!u && u.id.startsWith('g_') && String(u.email || '').toLowerCase() === OWNER_EMAIL;
function requireOwner(req, res, next) {
  if (!isOwner(req.user)) return res.status(403).json({ error: 'Sirf Owner (Google login se) kar sakta hai' });
  next();
}
function findUser(q) {
  q = String(q || '').trim().toLowerCase();
  return Object.values(db.users).find(x => x.pid === q || x.id.toLowerCase() === q || String(x.email || '').toLowerCase() === q);
}

const publicUser = (u) => ({ id: u.id, pid: u.pid, name: u.name, email: u.email, picture: u.picture, coins: u.coins, diamonds: u.diamonds });

function bearer(req) {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7) : '';
}
function requireAuth(req, res, next) {
  const u = userFromToken(bearer(req));
  if (!u) return res.status(401).json({ error: 'Login required' });
  req.user = u; req.token = bearer(req);
  next();
}

// ==========================================
// 3. MAIN REST API SERVER
// ==========================================
app.get('/health', (req, res) => res.json({ ok: true }));

// ---- internet ke liye: simple rate limit (IP ke hisaab se) ----
const hits = new Map();
function rateLimit(max, windowMs) {
  return (req, res, next) => {
    const k = req.ip + req.path, now = Date.now();
    const h = (hits.get(k) || []).filter(t => now - t < windowMs);
    if (h.length >= max) return res.status(429).json({ error: 'Bahut zyada requests, thoda ruko' });
    h.push(now); hits.set(k, h); next();
  };
}
setInterval(() => { const n = Date.now(); for (const [k, v] of hits) if (!v.some(t => n - t < 60e3)) hits.delete(k); }, 60e3).unref();

// ---- LiveKit (voice/video): login wale user ko room token do ----
const LK_KEY = process.env.LIVEKIT_API_KEY || '';
const LK_SECRET = process.env.LIVEKIT_API_SECRET || '';
const LK_URL = process.env.LIVEKIT_URL || ''; // public wss://livekit.tumhara-domain.com
const b64u = (o) => Buffer.from(typeof o === 'string' ? o : JSON.stringify(o)).toString('base64url');
function livekitToken(identity, name, room) {
  const now = Math.floor(Date.now() / 1000);
  const head = b64u({ alg: 'HS256', typ: 'JWT' });
  const body = b64u({ iss: LK_KEY, sub: identity, name, nbf: now, exp: now + 6 * 3600,
    video: { room, roomJoin: true, canPublish: true, canSubscribe: true } });
  const sig = crypto.createHmac('sha256', LK_SECRET).update(head + '.' + body).digest('base64url');
  return head + '.' + body + '.' + sig;
}
app.post('/api/livekit/token', requireAuth, rateLimit(30, 60e3), (req, res) => {
  if (!LK_KEY || !LK_SECRET || !LK_URL) return res.status(501).json({ error: 'LiveKit server me set nahi hai' });
  const room = String((req.body && req.body.roomId) || '').slice(0, 64);
  if (!room) return res.status(400).json({ error: 'roomId missing' });
  res.json({ success: true, url: LK_URL, token: livekitToken(req.user.id, req.user.name, room) });
});

// ---- Google Login: app Google se idToken leke yaha bhejta hai ----
app.post('/api/auth/google', rateLimit(20, 60e3), async (req, res) => {
  if (!GOOGLE_CLIENT_ID) return res.status(501).json({ error: 'Server me GOOGLE_CLIENT_ID set nahi hai' });
  const idToken = req.body && req.body.idToken;
  if (!idToken || typeof idToken !== 'string') return res.status(400).json({ error: 'idToken missing' });
  try {
    const ticket = await googleClient.verifyIdToken({ idToken, audience: GOOGLE_CLIENT_ID });
    const p = ticket.getPayload();
    if (!p || !p.sub || !p.email || p.email_verified === false) return res.status(401).json({ error: 'Google email verified nahi hai' });
    const id = 'g_' + p.sub;
    let u = db.users[id];
    if (!u) {
      u = db.users[id] = { id, pid: newPid(), name: '', coins: START_COINS, diamonds: 0, fcmToken: '', createdAt: Date.now() };
    }
    u.email = p.email;
    u.picture = p.picture || '';
    if (!u.name) u.name = (p.name || p.email.split('@')[0]).slice(0, 30);
    const token = createSession(id);
    saveDb();
    res.json({ success: true, token, user: publicUser(u) });
  } catch (err) {
    console.warn('Google verify failed:', err.message);
    res.status(401).json({ error: 'Invalid Google token' });
  }
});

// ---- Email + password login (password scrypt se hash hota hai, plain nahi rakhte) ----
function hashPw(pw, salt) {
  salt = salt || crypto.randomBytes(16).toString('hex');
  return salt + ':' + crypto.scryptSync(pw, salt, 64).toString('hex');
}
function checkPw(pw, stored) {
  const [salt, h] = String(stored || '').split(':');
  if (!salt || !h) return false;
  const a = Buffer.from(h, 'hex'), b = crypto.scryptSync(pw, salt, 64);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const emailUser = (e) => Object.values(db.users).find(x => String(x.email || '').toLowerCase() === e);

app.post('/api/auth/email/register', rateLimit(10, 60e3), (req, res) => {
  const b = req.body || {};
  const email = String(b.email || '').trim().toLowerCase(), pw = String(b.password || ''), name = String(b.name || '').trim().slice(0, 30);
  if (!EMAIL_RE.test(email) || email.length > 100) return res.status(400).json({ error: 'Sahi email daalo' });
  if (pw.length < 6 || pw.length > 100) return res.status(400).json({ error: 'Password kam se kam 6 akshar ka ho' });
  if (!name) return res.status(400).json({ error: 'Naam daalo' });
  if (emailUser(email)) return res.status(409).json({ error: 'Ye email pehle se registered hai, login karo' });
  const id = 'e_' + crypto.randomBytes(8).toString('hex');
  const u = db.users[id] = { id, pid: newPid(), name, email, pw: hashPw(pw), coins: START_COINS, diamonds: 0, fcmToken: '', createdAt: Date.now() };
  res.json({ success: true, token: createSession(id), user: publicUser(u) });
});
app.post('/api/auth/email/login', rateLimit(10, 60e3), (req, res) => {
  const b = req.body || {};
  const u = emailUser(String(b.email || '').trim().toLowerCase());
  if (!u || !u.pw || !checkPw(String(b.password || ''), u.pw)) return res.status(401).json({ error: 'Email ya password galat hai' });
  res.json({ success: true, token: createSession(u.id), user: publicUser(u) });
});

app.get('/api/me', requireAuth, (req, res) => res.json({ success: true, user: publicUser(req.user) }));

app.post('/api/auth/logout', requireAuth, (req, res) => {
  delete db.sessions[sha(req.token)];
  saveDb();
  res.json({ success: true });
});

app.post('/api/me/name', requireAuth, (req, res) => {
  const name = String((req.body && req.body.name) || '').trim().slice(0, 30);
  if (!name) return res.status(400).json({ error: 'Name required' });
  req.user.name = name; saveDb();
  res.json({ success: true, user: publicUser(req.user) });
});

// ---- Owner: unique ID options (Owner Google email se login zaroori) ----
// 1) Custom number set karo   2) Random unique number do
app.post('/api/owner/set-id', requireAuth, requireOwner, (req, res) => {
  const t = findUser(req.body && req.body.target);
  const pid = String((req.body && req.body.newPid) || '').trim();
  if (!t) return res.status(404).json({ error: 'User nahi mila (ID ya email check karo)' });
  if (!/^[1-9]\d{3,11}$/.test(pid)) return res.status(400).json({ error: 'ID 4 se 12 digit ka number ho, 0 se shuru nahi' });
  if (pidTaken(pid, t.id)) return res.status(409).json({ error: 'Ye ID pehle se kisi ke paas hai ya reserved hai' });
  const old = t.pid; t.pid = pid; saveDb();
  res.json({ success: true, old, user: publicUser(t) });
});
app.post('/api/owner/random-id', requireAuth, requireOwner, (req, res) => {
  const t = findUser(req.body && req.body.target);
  if (!t) return res.status(404).json({ error: 'User nahi mila (ID ya email check karo)' });
  const old = t.pid; t.pid = randomPid(); saveDb();
  res.json({ success: true, old, user: publicUser(t) });
});
app.get('/api/owner/check-id/:pid', requireAuth, requireOwner, (req, res) => {
  res.json({ success: true, pid: req.params.pid, available: /^[1-9]\d{3,11}$/.test(req.params.pid) && !pidTaken(req.params.pid) });
});

// ID se user dhundo (search)
app.get('/api/user/pid/:pid', requireAuth, (req, res) => {
  const u = Object.values(db.users).find(x => x.pid === req.params.pid);
  if (!u) return res.status(404).json({ error: 'User not found' });
  res.json({ success: true, data: { id: u.id, pid: u.pid, name: u.name, picture: u.picture } });
});

// public profile (coins/email nahi dikhte)
app.get('/api/user/:id', (req, res) => {
  const u = db.users[req.params.id];
  if (!u) return res.status(404).json({ error: 'User not found' });
  res.json({ success: true, data: { id: u.id, pid: u.pid, name: u.name, picture: u.picture } });
});

// Google In-App Purchase (IAP) Verification Route
app.post('/api/billing/verify-purchase', requireAuth, async (req, res) => {
  const userId = req.user.id;
  const { packageName, productId, purchaseToken } = req.body;

  // SAFETY: mock verification kisi ko bhi free coins deta hai.
  // Isliye default me band hai. Sirf testing ke liye ALLOW_MOCK_PURCHASE=true set karo.
  if (process.env.ALLOW_MOCK_PURCHASE !== 'true') {
    return res.status(501).json({ error: "Purchase verification not configured" });
  }

  try {
    /*
      Production verification logic:
      const auth = new google.auth.GoogleAuth({
        keyFile: './google-play-service-account.json',
        scopes: ['https://www.googleapis.com/auth/androidpublisher']
      });
      const playDeveloper = google.androidpublisher({ version: 'v3', auth });
      const verify = await playDeveloper.purchases.products.get({
        packageName, productId, token: purchaseToken
      });
    */
    if (db.users[userId]) {
      const creditedCoins = 1000; // ProductId ke according dynamically set karein
      db.users[userId].coins += creditedCoins;
      saveDb();
      return res.json({
        success: true,
        message: "Purchase verified successfully (MOCK)",
        newBalance: db.users[userId].coins
      });
    }
    res.status(404).json({ error: "User not found" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==========================================
// 4. REAL-TIME CHAT & RTC SIGNALING SERVER
// ==========================================
// Socket login: app io(url,{auth:{token}}) se session token bhejta hai
io.use((socket, next) => {
  const token = (socket.handshake.auth && socket.handshake.auth.token) || '';
  const u = userFromToken(token);
  if (!u) return next(new Error('unauthorized'));
  socket.data.userId = u.id;
  next();
});

io.on('connection', (socket) => {
  const me = () => db.users[socket.data.userId];
  console.log(`Client connected: ${socket.id} (${socket.data.userId})`);

  socket.on('join_room', ({ roomId }) => {
    if (!roomId) return;
    socket.join(String(roomId));
    socket.to(String(roomId)).emit('user_joined', { userId: socket.data.userId, socketId: socket.id });
  });

  let chatTimes = [];
  socket.on('send_chat', ({ roomId, message }) => {
    const u = me();
    const now = Date.now(); chatTimes = chatTimes.filter(t => now - t < 5000);
    if (chatTimes.length >= 10) return; // 5 sec me max 10 msg
    chatTimes.push(now);
    if (!u || !roomId || !socket.rooms.has(String(roomId))) return;
    io.to(String(roomId)).emit('new_chat', {
      userId: u.id,
      name: u.name,
      picture: u.picture,
      message: String(message).slice(0, 500),
      timestamp: new Date().toISOString()
    });
  });

  // Live Gifting Transaction Logic (sender hamesha login wala user hota hai)
  socket.on('send_gift', ({ roomId, receiverId, giftName, cost }) => {
    const sender = me();
    const senderId = socket.data.userId;
    const receiver = db.users[receiverId];

    // FIX: negative/decimal cost se coins "kamaye" ja sakte the
    if (!Number.isInteger(cost) || cost <= 0 || cost > 1000000) {
      return socket.emit('gift_error', { message: "Invalid gift cost" });
    }
    if (!sender || !receiver || senderId === receiverId) {
      return socket.emit('gift_error', { message: "Invalid sender or receiver" });
    }
    if (sender.coins < cost) {
      return socket.emit('gift_error', { message: "Insufficient coins balance" });
    }

    sender.coins -= cost;
    receiver.diamonds += cost; // Host ko diamonds reward
    saveDb();

    io.to(String(roomId)).emit('gift_broadcast', {
      senderId, receiverId, giftName: String(giftName).slice(0, 50), cost, timestamp: Date.now()
    });
  });

  // WebRTC Signaling
  socket.on('webrtc_offer', ({ targetSocketId, offer }) => {
    socket.to(targetSocketId).emit('webrtc_offer', { senderSocketId: socket.id, offer });
  });
  socket.on('webrtc_answer', ({ targetSocketId, answer }) => {
    socket.to(targetSocketId).emit('webrtc_answer', { senderSocketId: socket.id, answer });
  });
  socket.on('ice_candidate', ({ targetSocketId, candidate }) => {
    socket.to(targetSocketId).emit('ice_candidate', { senderSocketId: socket.id, candidate });
  });

  socket.on('disconnect', () => {
    console.log(`Client disconnected: ${socket.id}`);
  });
});

// ==========================================
// SERVER START
// ==========================================
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`🚀 Live Backend Server running on port ${PORT}`);
  if (!GOOGLE_CLIENT_ID) console.warn('⚠ GOOGLE_CLIENT_ID set nahi hai: Google login kaam nahi karega.');
});
