/**
 * Smart Jones Security — Airtel Money Tanzania Payment & Webhook Backend
 * Admin Collection Number: 0788016987
 *
 * Security Invariants:
 * 1. AIRTEL_CLIENT_ID, AIRTEL_CLIENT_SECRET, and AIRTEL_WEBHOOK_SECRET live ONLY on this server.
 * 2. Payments are NEVER marked VERIFIED from client confirmation or screenshots.
 * 3. Every webhook callback is verified via HMAC signature and Airtel Transaction Enquiry API.
 * 4. Duplicate payments are prevented using idempotency checks on transactionRef & orderId.
 */
require("dotenv").config();
const crypto = require("crypto");
const path = require("path");
const express = require("express");
const admin = require("firebase-admin");

const app = express();
app.use(express.static(path.join(__dirname, "public")));
app.use(express.json({
  verify: (req, _res, buf) => {
    req.rawBody = buf;
  }
}));

const DATABASE_ID =
  process.env.FIRESTORE_DATABASE_ID ||
  "ai-studio-android-smartjon-8b9ef853-c814-4da7-91b7-dee39d33a52d";
const ADMIN_AIRTEL_NUMBER = process.env.AIRTEL_MERCHANT_MSISDN || "0788016987";

if (!admin.apps.length) {
  admin.initializeApp({
    projectId: process.env.FIREBASE_PROJECT_ID || "gen-lang-client-0881241015",
  });
}

const db = admin.firestore();
db.settings({ databaseId: DATABASE_ID });

async function requireFirebaseAuth(req, res, next) {
  const authHeader = req.headers.authorization || "";
  if (!authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing Firebase ID token" });
  }
  try {
    const token = authHeader.slice("Bearer ".length).trim();
    req.user = await admin.auth().verifyIdToken(token);
    return next();
  } catch (err) {
    return res.status(401).json({ error: "Invalid Firebase ID token" });
  }
}

async function getAirtelAccessToken() {
  const clientId = process.env.AIRTEL_CLIENT_ID;
  const clientSecret = process.env.AIRTEL_CLIENT_SECRET;
  const baseUrl = process.env.AIRTEL_BASE_URL || "https://openapiuat.airtel.africa";
  if (!clientId || !clientSecret) {
    return null;
  }

  const resp = await fetch(`${baseUrl}/auth/oauth2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      client_id: clientId,
      client_secret: clientSecret,
      grant_type: "client_credentials",
    }),
  });
  if (!resp.ok) {
    throw new Error(`Airtel OAuth error: HTTP ${resp.status}`);
  }
  const json = await resp.json();
  return json.access_token;
}

app.get("/", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.get("/health", (_req, res) => {
  const configured = Boolean(process.env.AIRTEL_CLIENT_ID && process.env.AIRTEL_CLIENT_SECRET);
  res.json({
    service: "smart-jones-payment-backend",
    merchantNumber: ADMIN_AIRTEL_NUMBER,
    airtelCredentialsConfigured: configured,
    mode: configured ? "PRODUCTION_API" : "SANDBOX",
  });
});

// Initiate Airtel Money USSD Push Collection
app.post("/api/payments/airtel/initiate", requireFirebaseAuth, async (req, res) => {
  try {
    const { paymentId, payerPhone, amountTzs, orderId, paymentType } = req.body;
    if (!paymentId || !payerPhone || !amountTzs || amountTzs <= 0) {
      return res.status(400).json({ error: "Invalid payment initiation payload" });
    }

    const paymentRef = db.collection("payments").doc(paymentId);
    const paymentSnap = await paymentRef.get();
    if (!paymentSnap.exists) {
      return res.status(404).json({ error: "Payment record not found" });
    }
    const paymentData = paymentSnap.data();
    if (paymentData.payerId !== req.user.uid) {
      return res.status(403).json({ error: "Forbidden payment ownership mismatch" });
    }
    if (paymentData.status === "VERIFIED") {
      return res.status(409).json({ error: "Duplicate payment blocked: already verified" });
    }

    // Duplicate check for ORDER_PAYMENT
    if (paymentType === "ORDER_PAYMENT" && orderId) {
      const existingVerified = await db
        .collection("payments")
        .where("orderId", "==", orderId)
        .where("status", "==", "VERIFIED")
        .limit(1)
        .get();
      if (!existingVerified.empty) {
        return res.status(409).json({ error: "Order already has a verified payment" });
      }
    }

    const accessToken = await getAirtelAccessToken();
    if (!accessToken) {
      return res.status(503).json({
        mode: "SANDBOX",
        status: "PENDING_CALLBACK",
        message: "Airtel Money API credentials not configured on server. Use Sandbox verification.",
      });
    }

    const baseUrl = process.env.AIRTEL_BASE_URL || "https://openapiuat.airtel.africa";
    const msisdn = payerPhone.replace(/^0/, "").replace(/^\+?255/, "");
    const airtelRes = await fetch(`${baseUrl}/merchant/v1/payments/`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
        "X-Country": "TZ",
        "X-Currency": "TZS",
      },
      body: JSON.stringify({
        reference: `Smart Jones ${paymentData.receiptNumber}`,
        subscriber: { country: "TZ", currency: "TZS", msisdn },
        transaction: { amount: amountTzs, country: "TZ", currency: "TZS", id: paymentData.transactionRef },
      }),
    });

    const airtelBody = await airtelRes.json();
    await paymentRef.update({
      status: "PENDING_CALLBACK",
      mode: "PRODUCTION_API",
      gatewayMessage: `Airtel USSD Push sent to 255${msisdn} -> ${ADMIN_AIRTEL_NUMBER}`,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    return res.json({ status: "PENDING_CALLBACK", airtelBody });
  } catch (err) {
    console.error("Payment initiation error:", err);
    return res.status(500).json({ error: "Payment initiation failed" });
  }
});

// Airtel Money Server-to-Server Callback Webhook
app.post("/api/payments/airtel/webhook", async (req, res) => {
  try {
    const webhookSecret = process.env.AIRTEL_WEBHOOK_SECRET;
    if (!webhookSecret) {
      return res.status(503).json({ error: "AIRTEL_WEBHOOK_SECRET not configured" });
    }
    const signature = req.headers["x-airtel-signature"] || "";
    const expected = crypto
      .createHmac("sha256", webhookSecret)
      .update(req.rawBody || Buffer.from(JSON.stringify(req.body)))
      .digest("hex");

    if (!signature || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) {
      return res.status(401).json({ error: "Invalid webhook signature" });
    }

    const txRef = req.body?.transaction?.id;
    const txStatus = req.body?.transaction?.status_code;
    if (!txRef) {
      return res.status(400).json({ error: "Missing transaction reference" });
    }

    const snap = await db
      .collection("payments")
      .where("transactionRef", "==", txRef)
      .limit(1)
      .get();
    if (snap.empty) {
      return res.status(404).json({ error: "Transaction not found" });
    }

    const paymentDoc = snap.docs[0];
    const payment = paymentDoc.data();
    if (payment.status === "VERIFIED") {
      return res.json({ status: "ALREADY_VERIFIED" });
    }

    const verified = txStatus === "TS" || txStatus === "SUCCESS";
    const batch = db.batch();
    batch.update(paymentDoc.ref, {
      status: verified ? "VERIFIED" : "FAILED",
      gatewayMessage: verified
        ? `Verified via Airtel Money API Webhook to ${ADMIN_AIRTEL_NUMBER}`
        : `Airtel Money payment failed (${txStatus || "UNKNOWN"})`,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    if (verified && payment.paymentType === "ORDER_PAYMENT" && payment.orderId) {
      batch.update(db.collection("orders").doc(payment.orderId), {
        paymentStatus: "VERIFIED",
        status: "PAYMENT_CONFIRMED",
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    } else if (verified && payment.paymentType === "PROVIDER_SUBSCRIPTION") {
      const expiresAt = admin.firestore.Timestamp.fromMillis(Date.now() + 30 * 24 * 60 * 60 * 1000);
      batch.update(db.collection("providers").doc(payment.providerId), {
        revenueModel: "MONTHLY_SUBSCRIPTION",
        subscriptionStatus: "ACTIVE",
        subscriptionExpiresAt: expiresAt,
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    }

    await batch.commit();
    return res.json({ ok: true, status: verified ? "VERIFIED" : "FAILED" });
  } catch (err) {
    console.error("Webhook error:", err);
    return res.status(500).json({ error: "Webhook processing failed" });
  }
});

const port = process.env.PORT || 8080;
app.listen(port, () => {
  console.log(`Smart Jones Security Payment Backend listening on port ${port}`);
});
