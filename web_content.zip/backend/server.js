import express from "express";
import session from "express-session";

const app = express();
app.use(express.json());

app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, secure: true, sameSite: "lax" }
}));

const PORT = process.env.PORT || 3000;
const APP_ID = process.env.INSTAGRAM_APP_ID;
const APP_SECRET = process.env.INSTAGRAM_APP_SECRET;
const REDIRECT_URI = process.env.REDIRECT_URI;

app.get("/auth/instagram", (req,res)=>{
  const scopes="instagram_business_basic,instagram_business_manage_messages";
  const url="https://www.instagram.com/oauth/authorize"+
    "?client_id="+encodeURIComponent(APP_ID)+
    "&redirect_uri="+encodeURIComponent(REDIRECT_URI)+
    "&response_type=code"+
    "&scope="+encodeURIComponent(scopes);
  res.redirect(url);
});

app.get("/auth/instagram/callback", async (req,res)=>{
  const code=req.query.code;
  if(!code)return res.status(400).send("Authorization code missing.");
  try{
    const r=await fetch("https://api.instagram.com/oauth/access_token",{
      method:"POST",
      headers:{"Content-Type":"application/x-www-form-urlencoded"},
      body:new URLSearchParams({
        client_id:APP_ID,
        client_secret:APP_SECRET,
        grant_type:"authorization_code",
        redirect_uri:REDIRECT_URI,
        code
      })
    });
    const data=await r.json();
    if(!r.ok)return res.status(400).send("Instagram authorization failed.");
    req.session.instagramUserId=data.user_id;
    req.session.instagramAccessToken=data.access_token;
    res.redirect("/connected");
  }catch(e){console.error(e);res.status(500).send("Server error.");}
});

app.get("/connected",(req,res)=>res.send("<h2>Instagram Connected ✓</h2><p>Return to the app.</p>"));

app.get("/api/conversations",async(req,res)=>{
  if(!req.session.instagramAccessToken)return res.status(401).json({error:"Instagram account not connected."});
  res.json({conversations:[]});
});

app.listen(PORT,()=>console.log(`Server running on ${PORT}`));
