import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const db = new Database(path.join(__dirname, "gm_pay.db"));
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_THIS_SECRET_IN_PRODUCTION";
const ACTIVATION_FEE_USD = Number(process.env.ACTIVATION_FEE_USD || 1);

app.use(helmet({contentSecurityPolicy:false}));
app.use(cors());
app.use(express.json());
app.use(rateLimit({windowMs:60000, max:120}));

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 phone TEXT UNIQUE NOT NULL,
 name TEXT NOT NULL,
 password_hash TEXT NOT NULL,
 pin_hash TEXT,
 country TEXT,
 verified INTEGER DEFAULT 0,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS wallets(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 currency TEXT NOT NULL,
 balance REAL DEFAULT 0,
 UNIQUE(user_id,currency)
);
CREATE TABLE IF NOT EXISTS transactions(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 type TEXT NOT NULL,
 amount REAL NOT NULL,
 currency TEXT NOT NULL,
 counterparty TEXT,
 status TEXT NOT NULL,
 reference TEXT UNIQUE NOT NULL,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS merchants(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER UNIQUE NOT NULL,
 business_name TEXT NOT NULL,
 country TEXT,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

const auth = (req,res,next)=>{
 try{
   const h=req.headers.authorization||"";
   if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Authentification requise"});
   req.user=jwt.verify(h.slice(7),JWT_SECRET); next();
 }catch(e){return res.status(401).json({error:"Session invalide"});}
};

const ref=()=>`GMP-${Date.now()}-${Math.random().toString(36).slice(2,8).toUpperCase()}`;

app.get("/api/health",(req,res)=>res.json({ok:true,service:"GM Pay",mode:"sandbox-ready"}));

app.post("/api/register",async(req,res)=>{
 const {phone,name,password,pin,country}=req.body;
 if(!phone||!name||!password||!pin) return res.status(400).json({error:"phone, name, password et pin sont requis"});
 if(String(pin).length!==4) return res.status(400).json({error:"Le PIN doit contenir 4 chiffres"});
 try{
  const hash=await bcrypt.hash(password,12);
  const ph=await bcrypt.hash(String(pin),12);
  const info=db.prepare("INSERT INTO users(phone,name,password_hash,pin_hash,country) VALUES(?,?,?,?,?)").run(phone,name,hash,ph,country||"CD");
  const uid=info.lastInsertRowid;
  const ins=db.prepare("INSERT INTO wallets(user_id,currency,balance) VALUES(?,?,0)");
  ins.run(uid,"USD"); ins.run(uid,"CDF");
  const token=jwt.sign({id:Number(uid),phone},JWT_SECRET,{expiresIn:"7d"});
  res.json({token,user:{id:Number(uid),phone,name,country:country||"CD"},activation_fee_usd:ACTIVATION_FEE_USD});
 }catch(e){res.status(409).json({error:"Numéro déjà utilisé ou données invalides"});}
});

app.post("/api/login",async(req,res)=>{
 const {phone,password}=req.body;
 const u=db.prepare("SELECT * FROM users WHERE phone=?").get(phone);
 if(!u||!(await bcrypt.compare(password,u.password_hash))) return res.status(401).json({error:"Identifiants incorrects"});
 const token=jwt.sign({id:u.id,phone:u.phone},JWT_SECRET,{expiresIn:"7d"});
 res.json({token,user:{id:u.id,phone:u.phone,name:u.name,country:u.country}});
});

app.get("/api/me",auth,(req,res)=>{
 const u=db.prepare("SELECT id,phone,name,country,verified,created_at FROM users WHERE id=?").get(req.user.id);
 const wallets=db.prepare("SELECT currency,balance FROM wallets WHERE user_id=?").all(req.user.id);
 const tx=db.prepare("SELECT type,amount,currency,counterparty,status,reference,created_at FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT 50").all(req.user.id);
 res.json({user:u,wallets,transactions:tx});
});

app.post("/api/transfer",auth,(req,res)=>{
 const {toPhone,amount,currency,pin}=req.body;
 const value=Number(amount);
 if(!toPhone||!value||value<=0||!currency||!pin) return res.status(400).json({error:"Données de transfert invalides"});
 const sender=db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id);
 const receiver=db.prepare("SELECT * FROM users WHERE phone=?").get(toPhone);
 if(!receiver) return res.status(404).json({error:"Destinataire introuvable"});
 if(receiver.id===sender.id) return res.status(400).json({error:"Vous ne pouvez pas vous envoyer de l'argent"});
 const run=db.transaction(async()=>{
   if(!(await bcrypt.compare(String(pin),sender.pin_hash))) throw new Error("PIN incorrect");
   const w=db.prepare("SELECT * FROM wallets WHERE user_id=? AND currency=?").get(sender.id,currency);
   if(!w || w.balance<value) throw new Error("Solde insuffisant");
   const rw=db.prepare("SELECT * FROM wallets WHERE user_id=? AND currency=?").get(receiver.id,currency);
   if(!rw) db.prepare("INSERT INTO wallets(user_id,currency,balance) VALUES(?,?,0)").run(receiver.id,currency);
   db.prepare("UPDATE wallets SET balance=balance-? WHERE user_id=? AND currency=?").run(value,sender.id,currency);
   db.prepare("UPDATE wallets SET balance=balance+? WHERE user_id=? AND currency=?").run(value,receiver.id,currency);
   const r=ref();
   db.prepare("INSERT INTO transactions(user_id,type,amount,currency,counterparty,status,reference) VALUES(?,?,?,?,?,?,?)").run(sender.id,"TRANSFER_OUT",value,currency,toPhone,"COMPLETED",r);
   db.prepare("INSERT INTO transactions(user_id,type,amount,currency,counterparty,status,reference) VALUES(?,?,?,?,?,?,?)").run(receiver.id,"TRANSFER_IN",value,currency,sender.phone,"COMPLETED",r);
   return r;
 });
 try{const r=await run();res.json({success:true,reference:r});}
 catch(e){res.status(400).json({error:e.message});}
});

app.post("/api/demo-credit",auth,(req,res)=>{
 const {amount,currency}=req.body; const v=Number(amount);
 if(!v||v<=0) return res.status(400).json({error:"Montant invalide"});
 // Sandbox only: never represents real money.
 db.prepare("INSERT OR IGNORE INTO wallets(user_id,currency,balance) VALUES(?,?,0)").run(req.user.id,currency);
 db.prepare("UPDATE wallets SET balance=balance+? WHERE user_id=? AND currency=?").run(v,req.user.id,currency);
 const r=ref(); db.prepare("INSERT INTO transactions(user_id,type,amount,currency,status,reference) VALUES(?,?,?,?,?,?)").run(req.user.id,"SANDBOX_CREDIT",v,currency,"SANDBOX",r);
 res.json({success:true,mode:"SANDBOX",reference:r});
});

app.post("/api/merchant",auth,(req,res)=>{
 const {businessName,country}=req.body;
 if(!businessName) return res.status(400).json({error:"Nom de l'entreprise requis"});
 try{
  const r=db.prepare("INSERT INTO merchants(user_id,business_name,country) VALUES(?,?,?)").run(req.user.id,businessName,country||"CD");
  res.json({success:true,merchant_id:Number(r.lastInsertRowid)});
 }catch(e){res.status(409).json({error:"Compte marchand déjà existant"});}
});

app.use(express.static(path.join(__dirname,"../web")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"../web/index.html")));
app.listen(process.env.PORT||3000,()=>console.log("GM Pay running on http://localhost:"+(process.env.PORT||3000)));
