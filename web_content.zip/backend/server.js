import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: null
    }
  }
}));
app.use(express.json({ limit: "40kb" }));
app.use("/api/", rateLimit({
  windowMs: 60 * 1000,
  limit: 20,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Muitas mensagens em pouco tempo. Aguarde um minuto e tente novamente." }
}));

app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey || apiKey === "cole_sua_chave_aqui") {
    return res.status(503).json({
      error: "A API ainda não foi configurada. Crie o arquivo .env e adicione sua chave de API."
    });
  }

  const messages = req.body?.messages;
  if (!Array.isArray(messages) || messages.length === 0 || messages.length > 30) {
    return res.status(400).json({ error: "Envie entre 1 e 30 mensagens." });
  }

  const safeMessages = [];
  for (const message of messages) {
    if (!message || !["user", "assistant"].includes(message.role) ||
        typeof message.content !== "string" || !message.content.trim() ||
        message.content.length > 8000) {
      return res.status(400).json({ error: "Uma das mensagens é inválida." });
    }
    safeMessages.push({ role: message.role, content: message.content.trim() });
  }

  try {
    const upstream = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        messages: [
          {
            role: "system",
            content: "Você é a V1 IA, uma assistente útil, clara, respeitosa e competente. Responda em português por padrão, a menos que a pessoa use outro idioma. Explique passo a passo quando isso ajudar e admita quando não souber."
          },
          ...safeMessages
        ],
        temperature: 0.7
      }),
      signal: AbortSignal.timeout(60000)
    });

    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error("Erro da API do provedor:", upstream.status, data?.error?.code || "sem código");
      if (upstream.status === 401) {
        return res.status(502).json({ error: "A chave de API foi recusada. Confira a chave no arquivo .env." });
      }
      if (upstream.status === 429) {
        return res.status(429).json({ error: "Limite ou crédito da API atingido. Confira o uso e o faturamento da sua conta de API." });
      }
      return res.status(502).json({ error: "O serviço de IA retornou um erro. Tente novamente em instantes." });
    }

    const answer = data?.choices?.[0]?.message?.content;
    if (typeof answer !== "string" || !answer.trim()) {
      return res.status(502).json({ error: "A IA não retornou uma resposta válida." });
    }
    res.json({ answer: answer.trim() });
  } catch (error) {
    console.error("Falha ao contactar a API:", error?.name || "erro");
    res.status(504).json({ error: "Não foi possível contactar a IA agora. Verifique sua conexão e tente novamente." });
  }
});

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`V1 IA rodando em http://localhost:${PORT}`);
  if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === "cole_sua_chave_aqui") {
    console.log("Configure OPENAI_API_KEY no arquivo .env para ativar as respostas da IA.");
  }
});
