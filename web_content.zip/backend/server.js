// MOVA+ API - esqueleto da próxima etapa
const express = require('express');
const app = express();
app.use(express.json());

let trips = [];
app.get('/api/health',(req,res)=>res.json({ok:true,service:'MOVA+'}));
app.get('/api/trips',(req,res)=>res.json(trips));
app.post('/api/trips',(req,res)=>{
  const trip={id:Date.now(),...req.body,status:'PROCURANDO_MOTORISTA',createdAt:new Date().toISOString()};
  trips.push(trip); res.status(201).json(trip);
});
app.patch('/api/trips/:id',(req,res)=>{
  const t=trips.find(x=>x.id==req.params.id);
  if(!t) return res.status(404).json({error:'Viagem não encontrada'});
  Object.assign(t,req.body); res.json(t);
});
app.listen(process.env.PORT||3000,()=>console.log('MOVA+ API online'));
