-- فیلم‌تو: schema و policy های نسخه اولیه
-- این فایل را در Supabase SQL Editor اجرا کنید.

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 100),
  description text not null default '' check (char_length(description) <= 1000),
  display_name text not null default 'کاربر فیلم‌تو',
  storage_path text not null,
  video_url text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.video_likes (
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (video_id,user_id)
);

create table if not exists public.video_comments (
  id uuid primary key default gen_random_uuid(),
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 500),
  created_at timestamptz not null default now()
);

create index if not exists videos_created_at_idx on public.videos(created_at desc);
create index if not exists videos_title_idx on public.videos using gin (to_tsvector('simple', title));

alter table public.videos enable row level security;
alter table public.video_likes enable row level security;
alter table public.video_comments enable row level security;

create policy "Anyone can read videos" on public.videos for select using (true);
create policy "Signed-in users can publish own videos" on public.videos for insert to authenticated with check (auth.uid() = user_id);
create policy "Owners can update own videos" on public.videos for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Owners can delete own videos" on public.videos for delete to authenticated using (auth.uid() = user_id);

create policy "Anyone can read likes" on public.video_likes for select using (true);
create policy "Users can like as themselves" on public.video_likes for insert to authenticated with check (auth.uid() = user_id);
create policy "Users can remove own likes" on public.video_likes for delete to authenticated using (auth.uid() = user_id);

create policy "Anyone can read comments" on public.video_comments for select using (true);
create policy "Users can comment as themselves" on public.video_comments for insert to authenticated with check (auth.uid() = user_id);
create policy "Users can delete own comments" on public.video_comments for delete to authenticated using (auth.uid() = user_id);

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('videos','videos',true,209715200,array['video/mp4','video/webm','video/quicktime','video/x-matroska'])
on conflict (id) do update set public=true,file_size_limit=209715200,allowed_mime_types=excluded.allowed_mime_types;

create policy "Public can read video files" on storage.objects for select using (bucket_id='videos');
create policy "Authenticated users upload to own folder" on storage.objects for insert to authenticated
with check (bucket_id='videos' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "Users can delete own video files" on storage.objects for delete to authenticated
using (bucket_id='videos' and (storage.foldername(name))[1]=auth.uid()::text);
