import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import jwt from '@fastify/jwt';
import websocket from '@fastify/websocket';
import swagger from '@fastify/swagger';
import swaggerUi from '@fastify/swagger-ui';
import { serializerCompiler, validatorCompiler } from 'fastify-type-provider-zod';

import { env } from './config/env.js';
import { authRoutes } from './routes/auth.js';
import { mailboxRoutes } from './routes/mailboxes.js';
import { messageRoutes } from './routes/messages.js';
import { numberRoutes } from './routes/numbers.js';
import { creditRoutes } from './routes/credits.js';
import { webhookRoutes } from './routes/webhooks.js';
import { adminRoutes } from './routes/admin.js';
import { wsHub } from './websocket/hub.js';
import { CreditsService } from './services/credits.service.js';

export async function buildServer() {
  const server = Fastify({
    logger: env.NODE_ENV !== 'test',
    bodyLimit: env.MAX_EMAIL_SIZE_BYTES + 1024 * 1024,
  });

  server.setValidatorCompiler(validatorCompiler);
  server.setSerializerCompiler(serializerCompiler);

  // Security plugins
  await server.register(cors, { origin: true });
  await server.register(helmet, { contentSecurityPolicy: false });

  // Rate limiting (IP/device abuse prevention)
  await server.register(rateLimit, {
    max: 120,
    timeWindow: '1 minute',
  });

  // JWT auth
  await server.register(jwt, {
    secret: env.JWT_SECRET,
  });

  // WebSocket support
  await server.register(websocket);

  // OpenAPI Swagger documentation
  await server.register(swagger, {
    openapi: {
      info: {
        title: 'TempBox API',
        description: 'Disposable Email & Temporary Phone Number API for SMS Verifications',
        version: '1.0.0',
      },
      servers: [{ url: `http://localhost:${env.PORT}` }],
    },
  });

  await server.register(swaggerUi, {
    routePrefix: '/docs',
  });

  // Health check
  server.get('/health', async () => ({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'tempbox-core',
  }));

  // WebSocket endpoint: /ws?token=JWT
  server.register(async function (fastify) {
    fastify.get('/ws', { websocket: true }, (connection, req) => {
      const query = req.query as { token?: string };
      let userId = 'anonymous';

      if (query.token) {
        try {
          const decoded: any = fastify.jwt.verify(query.token);
          userId = decoded.userId;
        } catch {
          connection.socket.send(JSON.stringify({ error: 'Invalid token' }));
        }
      }

      wsHub.registerClient(userId, connection.socket);
      connection.socket.send(JSON.stringify({ event: 'connected', userId }));
    });
  });

  // Register application routes
  await server.register(authRoutes);
  await server.register(mailboxRoutes);
  await server.register(messageRoutes);
  await server.register(numberRoutes);
  await server.register(creditRoutes);
  await server.register(webhookRoutes);
  await server.register(adminRoutes);

  return server;
}

// Background scheduler for auto-refunds and expired cleanup
setInterval(async () => {
  try {
    const refunded = await CreditsService.processAutomaticRefunds();
    if (refunded.length > 0) {
      console.log(`[AutoRefund] Refunded credits for ${refunded.length} unused numbers.`);
    }
  } catch (err: any) {
    console.error('[AutoRefund] Error during refund cycle:', err.message);
  }
}, 60 * 1000); // Check every minute

// Start standalone server if run directly
if (process.env.NODE_ENV !== 'test') {
  const start = async () => {
    try {
      const server = await buildServer();
      await server.listen({ port: env.PORT, host: '0.0.0.0' });
      console.log(`🚀 TempBox backend running at http://0.0.0.0:${env.PORT}`);
      console.log(`📚 OpenAPI Docs available at http://0.0.0.0:${env.PORT}/docs`);
    } catch (err) {
      console.error(err);
      process.exit(1);
    }
  };
  start();
}
