import express from "express";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import cookieParser from "cookie-parser";
import auth from "./auth";
import marketplace from "./marketplace";

const app=express();
app.disable("x-powered-by");
app.use(helmet({contentSecurityPolicy:false}));
app.use(cors({origin:process.env.FRONTEND_ORIGIN?.split(",")??false,credentials:true}));
app.use(express.json({limit:"200kb"}));
app.use(cookieParser());
app.use(rateLimit({windowMs:15*60*1000,max:300,standardHeaders:true,legacyHeaders:false}));
app.get("/api/health",(_,res)=>res.json({ok:true}));
app.use("/api/auth",auth);
app.use("/api",marketplace);
app.use((err:any,_req:any,res:any,_next:any)=>{
 console.error(err);
 res.status(500).json({error:"Internal server error"});
});
const port=Number(process.env.PORT||4000);
app.listen(port,()=>console.log(`Souqi API listening on :${port}`));