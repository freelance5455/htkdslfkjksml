import { FastifyPluginAsync } from 'fastify';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { DOMAINS } from '../config/env.js';

export const adminRoutes: FastifyPluginAsync = async (fastify) => {
  // GET /admin/stats
  fastify.get('/admin/stats', async (request, reply) => {
    const [userCount, mailboxCount, activeNumberCount, totalMessages, totalSms, abuseCount] =
      await Promise.all([
        prisma.user.count(),
        prisma.mailbox.count({ where: { expiresAt: { gt: new Date() } } }),
        prisma.phoneNumber.count({ where: { status: 'ACTIVE' } }),
        prisma.message.count(),
        prisma.smsMessage.count(),
        prisma.abuseReport.count({ where: { resolved: false } }),
      ]);

    return reply.send({
      stats: {
        totalUsers: userCount,
        activeMailboxes: mailboxCount,
        activeNumbers: activeNumberCount,
        totalEmailsReceived: totalMessages,
        totalSmsReceived: totalSms,
        pendingAbuseReports: abuseCount,
        estimatedRevenueUsd: Math.round(userCount * 4.99 * 100) / 100,
        providerBalance: {
          twilio: '$418.50',
          telnyx: '$285.20',
          mailgun: 'Active (Tier 2)',
        },
      },
    });
  });

  // GET /admin/users
  fastify.get('/admin/users', async (request, reply) => {
    const users = await prisma.user.findMany({
      take: 50,
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        email: true,
        role: true,
        isGuest: true,
        credits: true,
        isBanned: true,
        createdAt: true,
        _count: {
          select: { mailboxes: true, phoneNumbers: true },
        },
      },
    });
    return reply.send({ users });
  });

  // POST /admin/ban-user
  fastify.post('/admin/ban-user', async (request, reply) => {
    const schema = z.object({
      userId: z.string(),
      banned: z.boolean(),
    });
    const body = schema.parse(request.body);

    const updated = await prisma.user.update({
      where: { id: body.userId },
      data: { isBanned: body.banned },
    });

    return reply.send({ success: true, isBanned: updated.isBanned });
  });

  // GET /admin/abuse-reports
  fastify.get('/admin/abuse-reports', async (request, reply) => {
    const reports = await prisma.abuseReport.findMany({
      take: 50,
      orderBy: { createdAt: 'desc' },
      include: {
        user: { select: { email: true, id: true } },
      },
    });
    return reply.send({ reports });
  });

  // POST /admin/abuse-reports/:id/resolve
  fastify.post('/admin/abuse-reports/:id/resolve', async (request, reply) => {
    const { id } = request.params as { id: string };
    await prisma.abuseReport.update({
      where: { id },
      data: { resolved: true },
    });
    return reply.send({ success: true });
  });

  // GET /admin/domains
  fastify.get('/admin/domains', async (request, reply) => {
    return reply.send({ domains: DOMAINS });
  });
};
