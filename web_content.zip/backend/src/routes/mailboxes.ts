import { FastifyPluginAsync } from 'fastify';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { DOMAINS } from '../config/env.js';
import { LifetimeTier } from '@prisma/client';

export const mailboxRoutes: FastifyPluginAsync = async (fastify) => {
  // Authentication hook for all mailbox routes
  fastify.addHook('onRequest', async (request, reply) => {
    try {
      await request.jwtVerify();
    } catch (err) {
      reply.status(401).send({ error: 'Unauthorized' });
    }
  });

  // GET /mailboxes
  fastify.get('/mailboxes', async (request, reply) => {
    const userId = (request.user as any).userId;
    const mailboxes = await prisma.mailbox.findMany({
      where: {
        userId,
        expiresAt: { gt: new Date() },
      },
      include: {
        _count: {
          select: {
            messages: { where: { isRead: false } },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return reply.send({
      mailboxes: mailboxes.map((mb) => ({
        id: mb.id,
        address: mb.address,
        username: mb.username,
        domain: mb.domain,
        lifetimeTier: mb.lifetimeTier,
        expiresAt: mb.expiresAt,
        unreadCount: mb._count.messages,
        createdAt: mb.createdAt,
      })),
      availableDomains: DOMAINS,
    });
  });

  // POST /mailboxes
  fastify.post('/mailboxes', async (request, reply) => {
    const userId = (request.user as any).userId;
    const schema = z.object({
      username: z.string().min(3).max(30).optional(),
      domain: z.string().optional(),
      duration: z.enum(['10m', '1h', '24h', '7d']).default('24h'),
    });

    const body = schema.parse(request.body);
    const selectedDomain = body.domain && DOMAINS.includes(body.domain) ? body.domain : DOMAINS[0];

    // Generate random prefix if not supplied
    const username = (body.username || Math.random().toString(36).substring(2, 9)).toLowerCase();
    const fullAddress = `${username}@${selectedDomain}`;

    // Check if address is already taken
    const existing = await prisma.mailbox.findFirst({
      where: {
        address: fullAddress,
        expiresAt: { gt: new Date() },
      },
    });

    if (existing) {
      return reply.status(409).send({ error: 'This email address is already in use' });
    }

    // Determine lifetime
    let expiresAt = new Date();
    let lifetimeTier: LifetimeTier = LifetimeTier.TWENTY_FOUR_HOURS;
    if (body.duration === '10m') {
      expiresAt = new Date(Date.now() + 10 * 60 * 1000);
      lifetimeTier = LifetimeTier.TEN_MINUTES;
    } else if (body.duration === '1h') {
      expiresAt = new Date(Date.now() + 60 * 60 * 1000);
      lifetimeTier = LifetimeTier.ONE_HOUR;
    } else if (body.duration === '7d') {
      expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      lifetimeTier = LifetimeTier.SEVEN_DAYS;
    } else {
      expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
      lifetimeTier = LifetimeTier.TWENTY_FOUR_HOURS;
    }

    const mailbox = await prisma.mailbox.create({
      data: {
        userId,
        address: fullAddress,
        username,
        domain: selectedDomain,
        lifetimeTier,
        expiresAt,
        isCustom: !!body.username,
      },
    });

    return reply.status(201).send(mailbox);
  });

  // POST /mailboxes/:id/extend
  fastify.post('/mailboxes/:id/extend', async (request, reply) => {
    const userId = (request.user as any).userId;
    const { id } = request.params as { id: string };

    const mailbox = await prisma.mailbox.findFirst({
      where: { id, userId },
    });

    if (!mailbox) {
      return reply.status(404).send({ error: 'Mailbox not found' });
    }

    // Extend by 24 hours from current expiration (or from now if expired)
    const baseDate = mailbox.expiresAt > new Date() ? mailbox.expiresAt : new Date();
    const newExpiresAt = new Date(baseDate.getTime() + 24 * 60 * 60 * 1000);

    const updated = await prisma.mailbox.update({
      where: { id },
      data: { expiresAt: newExpiresAt },
    });

    return reply.send({ success: true, expiresAt: updated.expiresAt });
  });

  // DELETE /mailboxes/:id
  fastify.delete('/mailboxes/:id', async (request, reply) => {
    const userId = (request.user as any).userId;
    const { id } = request.params as { id: string };

    const mailbox = await prisma.mailbox.findFirst({
      where: { id, userId },
    });

    if (!mailbox) {
      return reply.status(404).send({ error: 'Mailbox not found' });
    }

    await prisma.mailbox.delete({ where: { id } });
    return reply.send({ success: true });
  });
};
