import { FastifyPluginAsync } from 'fastify';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { decryptText } from '../lib/crypto.js';

export const messageRoutes: FastifyPluginAsync = async (fastify) => {
  fastify.addHook('onRequest', async (request, reply) => {
    try {
      await request.jwtVerify();
    } catch (err) {
      reply.status(401).send({ error: 'Unauthorized' });
    }
  });

  // GET /mailboxes/:id/messages
  fastify.get('/mailboxes/:id/messages', async (request, reply) => {
    const userId = (request.user as any).userId;
    const { id: mailboxId } = request.params as { id: string };

    const mailbox = await prisma.mailbox.findFirst({
      where: { id: mailboxId, userId },
    });
    if (!mailbox) {
      return reply.status(404).send({ error: 'Mailbox not found' });
    }

    const messages = await prisma.message.findMany({
      where: { mailboxId },
      orderBy: { receivedAt: 'desc' },
      select: {
        id: true,
        fromAddress: true,
        fromName: true,
        toAddress: true,
        subject: true,
        textPreview: true,
        extractedOtp: true,
        verificationUrl: true,
        isRead: true,
        isSpam: true,
        sizeBytes: true,
        receivedAt: true,
        attachments: {
          select: { id: true, filename: true, sizeBytes: true, contentType: true },
        },
      },
    });

    return reply.send({ messages });
  });

  // GET /messages/:id
  fastify.get('/messages/:id', async (request, reply) => {
    const userId = (request.user as any).userId;
    const { id } = request.params as { id: string };

    const message = await prisma.message.findFirst({
      where: {
        id,
        mailbox: { userId },
      },
      include: {
        attachments: true,
        mailbox: { select: { address: true } },
      },
    });

    if (!message) {
      return reply.status(404).send({ error: 'Message not found' });
    }

    // Mark as read
    if (!message.isRead) {
      await prisma.message.update({
        where: { id },
        data: { isRead: true },
      });
    }

    // Decrypt AES-256-GCM body at rest
    let decryptedBody = '';
    try {
      decryptedBody = decryptText({
        cipherText: message.encryptedBody,
        iv: message.iv,
        authTag: message.authTag,
      });
    } catch (err) {
      decryptedBody = message.textPreview || 'Error decrypting message content.';
    }

    return reply.send({
      id: message.id,
      mailboxId: message.mailboxId,
      fromAddress: message.fromAddress,
      fromName: message.fromName,
      toAddress: message.toAddress,
      subject: message.subject,
      body: decryptedBody,
      textPreview: message.textPreview,
      extractedOtp: message.extractedOtp,
      verificationUrl: message.verificationUrl,
      isRead: true,
      sizeBytes: message.sizeBytes,
      receivedAt: message.receivedAt,
      attachments: message.attachments,
    });
  });

  // DELETE /messages/:id
  fastify.delete('/messages/:id', async (request, reply) => {
    const userId = (request.user as any).userId;
    const { id } = request.params as { id: string };

    const message = await prisma.message.findFirst({
      where: {
        id,
        mailbox: { userId },
      },
    });

    if (!message) {
      return reply.status(404).send({ error: 'Message not found' });
    }

    await prisma.message.delete({ where: { id } });
    return reply.send({ success: true });
  });

  // POST /messages/:id/report-spam
  fastify.post('/messages/:id/report-spam', async (request, reply) => {
    const userId = (request.user as any).userId;
    const { id } = request.params as { id: string };

    const message = await prisma.message.findFirst({
      where: { id, mailbox: { userId } },
    });
    if (!message) return reply.status(404).send({ error: 'Message not found' });

    await prisma.$transaction([
      prisma.message.update({
        where: { id },
        data: { isSpam: true },
      }),
      prisma.abuseReport.create({
        data: {
          userId,
          itemType: 'MESSAGE',
          itemId: id,
          reason: 'SPAM_REPORT',
          details: `From: ${message.fromAddress}, Subject: ${message.subject}`,
        },
      }),
      prisma.blockedSender.upsert({
        where: { pattern: message.fromAddress.toLowerCase() },
        create: {
          pattern: message.fromAddress.toLowerCase(),
          reason: 'Reported by user as spam',
        },
        update: {},
      }),
    ]);

    return reply.send({ success: true, message: 'Sender marked as spam and blocked' });
  });
};
