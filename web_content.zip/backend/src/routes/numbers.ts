import { FastifyPluginAsync } from 'fastify';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { getSmsProvider } from '../services/sms/index.js';
import { CreditsService } from '../services/credits.service.js';
import { decryptText } from '../lib/crypto.js';
import { NumberStatus } from '@prisma/client';

export const numberRoutes: FastifyPluginAsync = async (fastify) => {
  fastify.addHook('onRequest', async (request, reply) => {
    try {
      await request.jwtVerify();
    } catch (err) {
      reply.status(401).send({ error: 'Unauthorized' });
    }
  });

  // GET /numbers/available?country=
  fastify.get('/numbers/available', async (request, reply) => {
    const query = request.query as { country?: string };
    const country = (query.country || 'US').toUpperCase();

    const provider = getSmsProvider();
    const numbers = await provider.getAvailableNumbers(country);

    return reply.send({
      country,
      provider: provider.name,
      numbers,
    });
  });

  // GET /numbers (user's active numbers)
  fastify.get('/numbers', async (request, reply) => {
    const userId = (request.user as any).userId;

    const numbers = await prisma.phoneNumber.findMany({
      where: {
        userId,
        status: { in: [NumberStatus.ACTIVE, NumberStatus.RENTED, NumberStatus.EXPIRING_SOON] },
      },
      include: {
        _count: {
          select: { smsMessages: true },
        },
      },
      orderBy: { rentedAt: 'desc' },
    });

    return reply.send({
      numbers: numbers.map((n) => ({
        id: n.id,
        number: n.number,
        countryCode: n.countryCode,
        status: n.status,
        rentedAt: n.rentedAt,
        expiresAt: n.expiresAt,
        creditsCost: n.creditsCost,
        smsCount: n._count.smsMessages,
      })),
    });
  });

  // POST /numbers/rent
  fastify.post('/numbers/rent', async (request, reply) => {
    const userId = (request.user as any).userId;
    const schema = z.object({
      number: z.string(),
      countryCode: z.string().default('US'),
      duration: z.enum(['20m', '24h', '7d', '30d']).default('20m'),
    });

    const body = schema.parse(request.body);

    // Calculate credit cost and expiry duration
    let cost = 10;
    let expiresAt = new Date();
    if (body.duration === '20m') {
      cost = 10;
      expiresAt = new Date(Date.now() + 20 * 60 * 1000);
    } else if (body.duration === '24h') {
      cost = 25;
      expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
    } else if (body.duration === '7d') {
      cost = 70;
      expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    } else if (body.duration === '30d') {
      cost = 180;
      expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    }

    const provider = getSmsProvider();
    const rental = await provider.rentNumber(body.number);

    // Create phone number record in DB
    const createdNumber = await prisma.phoneNumber.create({
      data: {
        userId,
        number: body.number,
        countryCode: body.countryCode.toUpperCase(),
        provider: provider.name,
        providerSid: rental.providerSid,
        status: NumberStatus.ACTIVE,
        expiresAt,
        creditsCost: cost,
      },
    });

    // Deduct credits via transaction ledger
    try {
      await CreditsService.deductCreditsForRental(userId, cost, createdNumber.id, body.number);
    } catch (err: any) {
      // Revert if insufficient credits
      await prisma.phoneNumber.delete({ where: { id: createdNumber.id } });
      return reply.status(402).send({ error: err.message });
    }

    return reply.status(201).send(createdNumber);
  });

  // GET /numbers/:id/sms
  fastify.get('/numbers/:id/sms', async (request, reply) => {
    const userId = (request.user as any).userId;
    const { id } = request.params as { id: string };

    const phoneNumber = await prisma.phoneNumber.findFirst({
      where: { id, userId },
    });
    if (!phoneNumber) return reply.status(404).send({ error: 'Number not found' });

    const messages = await prisma.smsMessage.findMany({
      where: { phoneNumberId: id },
      orderBy: { receivedAt: 'desc' },
    });

    const decryptedMessages = messages.map((m) => {
      let bodyText = m.preview;
      try {
        bodyText = decryptText({
          cipherText: m.encryptedText,
          iv: m.iv,
          authTag: m.authTag,
        });
      } catch {}

      return {
        id: m.id,
        fromNumber: m.fromNumber,
        text: bodyText,
        extractedOtp: m.extractedOtp,
        receivedAt: m.receivedAt,
      };
    });

    return reply.send({
      phoneNumber: {
        id: phoneNumber.id,
        number: phoneNumber.number,
        countryCode: phoneNumber.countryCode,
        status: phoneNumber.status,
        expiresAt: phoneNumber.expiresAt,
      },
      messages: decryptedMessages,
    });
  });

  // POST /numbers/:id/renew
  fastify.post('/numbers/:id/renew', async (request, reply) => {
    const userId = (request.user as any).userId;
    const { id } = request.params as { id: string };

    const num = await prisma.phoneNumber.findFirst({
      where: { id, userId },
    });
    if (!num) return reply.status(404).send({ error: 'Number not found' });

    const renewalCost = 15;
    await CreditsService.deductCreditsForRental(userId, renewalCost, num.id, num.number);

    const base = num.expiresAt > new Date() ? num.expiresAt : new Date();
    const newExpiresAt = new Date(base.getTime() + 24 * 60 * 60 * 1000);

    const updated = await prisma.phoneNumber.update({
      where: { id },
      data: { expiresAt: newExpiresAt, status: NumberStatus.ACTIVE },
    });

    return reply.send({ success: true, expiresAt: updated.expiresAt });
  });

  // DELETE /numbers/:id (release)
  fastify.delete('/numbers/:id', async (request, reply) => {
    const userId = (request.user as any).userId;
    const { id } = request.params as { id: string };

    const num = await prisma.phoneNumber.findFirst({
      where: { id, userId },
    });
    if (!num) return reply.status(404).send({ error: 'Number not found' });

    const provider = getSmsProvider();
    if (num.providerSid) {
      await provider.releaseNumber(num.providerSid);
    }

    await prisma.phoneNumber.update({
      where: { id },
      data: { status: NumberStatus.RELEASED },
    });

    return reply.send({ success: true });
  });
};
