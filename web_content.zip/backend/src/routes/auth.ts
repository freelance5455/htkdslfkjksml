import { FastifyPluginAsync } from 'fastify';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import { prisma } from '../lib/prisma.js';
import { env } from '../config/env.js';

export const authRoutes: FastifyPluginAsync = async (fastify) => {
  // POST /auth/guest
  fastify.post('/auth/guest', async (request, reply) => {
    const schema = z.object({
      deviceId: z.string().min(4),
      platform: z.string().optional().default('mobile'),
      fcmToken: z.string().optional(),
    });

    const parsed = schema.parse(request.body);

    let device = await prisma.device.findUnique({
      where: { deviceId: parsed.deviceId },
      include: { user: true },
    });

    let user = device?.user;

    if (!user) {
      user = await prisma.user.create({
        data: {
          isGuest: true,
          credits: env.DEFAULT_CREDITS_GUEST,
          devices: {
            create: {
              deviceId: parsed.deviceId,
              platform: parsed.platform,
              fcmToken: parsed.fcmToken,
            },
          },
        },
      });
    } else if (parsed.fcmToken) {
      await prisma.device.update({
        where: { id: device!.id },
        data: { fcmToken: parsed.fcmToken, lastSeenAt: new Date() },
      });
    }

    const token = fastify.jwt.sign({ userId: user.id, isGuest: true, role: user.role });
    const refreshToken = (fastify as any).jwtRefresh
      ? (fastify as any).jwtRefresh.sign({ userId: user.id })
      : token;

    return reply.send({
      user: {
        id: user.id,
        email: user.email,
        isGuest: user.isGuest,
        role: user.role,
        credits: user.credits,
      },
      accessToken: token,
      refreshToken,
    });
  });

  // POST /auth/register
  fastify.post('/auth/register', async (request, reply) => {
    const schema = z.object({
      email: z.string().email(),
      password: z.string().min(8),
      deviceId: z.string().optional(),
    });

    const body = schema.parse(request.body);
    const existing = await prisma.user.findUnique({ where: { email: body.email } });
    if (existing) {
      return reply.status(409).send({ error: 'Email already registered' });
    }

    const passwordHash = await bcrypt.hash(body.password, 10);
    const user = await prisma.user.create({
      data: {
        email: body.email,
        passwordHash,
        isGuest: false,
        credits: 50,
        devices: body.deviceId
          ? {
              create: {
                deviceId: body.deviceId,
              },
            }
          : undefined,
      },
    });

    const token = fastify.jwt.sign({ userId: user.id, isGuest: false, role: user.role });
    return reply.send({
      user: {
        id: user.id,
        email: user.email,
        isGuest: false,
        role: user.role,
        credits: user.credits,
      },
      accessToken: token,
    });
  });

  // POST /auth/login
  fastify.post('/auth/login', async (request, reply) => {
    const schema = z.object({
      email: z.string().email(),
      password: z.string(),
    });

    const body = schema.parse(request.body);
    const user = await prisma.user.findUnique({ where: { email: body.email } });
    if (!user || !user.passwordHash) {
      return reply.status(401).send({ error: 'Invalid credentials' });
    }

    const isValid = await bcrypt.compare(body.password, user.passwordHash);
    if (!isValid) {
      return reply.status(401).send({ error: 'Invalid credentials' });
    }

    const token = fastify.jwt.sign({ userId: user.id, isGuest: false, role: user.role });
    return reply.send({
      user: {
        id: user.id,
        email: user.email,
        isGuest: false,
        role: user.role,
        credits: user.credits,
      },
      accessToken: token,
    });
  });
};
