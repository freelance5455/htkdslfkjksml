import { FastifyPluginAsync } from 'fastify';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { CreditsService } from '../services/credits.service.js';

export const creditRoutes: FastifyPluginAsync = async (fastify) => {
  fastify.addHook('onRequest', async (request, reply) => {
    try {
      await request.jwtVerify();
    } catch (err) {
      reply.status(401).send({ error: 'Unauthorized' });
    }
  });

  // GET /credits
  fastify.get('/credits', async (request, reply) => {
    const userId = (request.user as any).userId;

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { credits: true, role: true },
    });

    const transactions = await prisma.creditTransaction.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    return reply.send({
      credits: user?.credits || 0,
      isPremium: user?.role === 'PREMIUM',
      transactions,
    });
  });

  // POST /credits/purchase/verify
  fastify.post('/credits/purchase/verify', async (request, reply) => {
    const userId = (request.user as any).userId;
    const schema = z.object({
      receiptToken: z.string().min(1),
      packageId: z.enum(['tier_50', 'tier_150', 'tier_500', 'sub_unlimited']),
      store: z.enum(['apple', 'google', 'revenuecat', 'mock']).default('revenuecat'),
    });

    const body = schema.parse(request.body);

    let creditsToAdd = 50;
    if (body.packageId === 'tier_150') creditsToAdd = 150;
    if (body.packageId === 'tier_500') creditsToAdd = 500;
    if (body.packageId === 'sub_unlimited') {
      creditsToAdd = 1000;
      await prisma.user.update({
        where: { id: userId },
        data: { role: 'PREMIUM' },
      });
    }

    const txId = `rc_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    const newBalance = await CreditsService.addPurchasedCredits(userId, creditsToAdd, txId, body.store);

    return reply.send({
      success: true,
      addedCredits: creditsToAdd,
      newBalance,
      transactionId: txId,
    });
  });
};
