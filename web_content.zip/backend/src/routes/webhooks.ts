import { FastifyPluginAsync } from 'fastify';
import crypto from 'crypto';
import { prisma } from '../lib/prisma.js';
import { InboundEmailService } from '../services/email/inbound.service.js';
import { getSmsProvider } from '../services/sms/index.js';
import { encryptText } from '../lib/crypto.js';
import { extractOtpAndLinks } from '../lib/otp.js';
import { wsHub } from '../websocket/hub.js';
import { env } from '../config/env.js';

export const webhookRoutes: FastifyPluginAsync = async (fastify) => {
  // POST /webhooks/inbound-email (Mailgun / Postmark / Cloudflare)
  fastify.post('/webhooks/inbound-email', async (request, reply) => {
    const body = request.body as any;

    // Optional Mailgun HMAC signature validation
    if (env.MAILGUN_WEBHOOK_SIGNING_KEY && body.signature) {
      const { timestamp, token, signature } = body.signature;
      const expected = crypto
        .createHmac('sha256', env.MAILGUN_WEBHOOK_SIGNING_KEY)
        .update(timestamp + token)
        .digest('hex');

      if (signature !== expected) {
        return reply.status(403).send({ error: 'Invalid webhook signature' });
      }
    }

    // Extract email fields from provider payload (handles standard Mailgun/Postmark/Sendgrid formats)
    const recipient = body.recipient || body['recipient'] || body.to || body.To;
    const sender = body.sender || body.from || body.From || 'unknown@domain.com';
    const subject = body.subject || body.Subject || '(No Subject)';
    const htmlBody = body['body-html'] || body.html || body.HtmlBody || '';
    const textBody = body['body-plain'] || body.text || body.TextBody || '';

    if (!recipient) {
      return reply.status(400).send({ error: 'Recipient address required' });
    }

    const result = await InboundEmailService.processIncomingEmail({
      toAddress: recipient,
      fromAddress: sender,
      fromName: body['from-name'] || sender.split('@')[0],
      subject,
      htmlBody,
      textBody,
    });

    return reply.send({ success: true, ...result });
  });

  // POST /webhooks/sms (Twilio / Telnyx / Vonage)
  fastify.post('/webhooks/sms', async (request, reply) => {
    const provider = getSmsProvider();

    // Verify signature
    const isValid = provider.verifyWebhookSignature(request.headers, JSON.stringify(request.body));
    if (!isValid) {
      return reply.status(403).send({ error: 'Invalid SMS webhook signature' });
    }

    const payload = provider.parseInboundWebhook(request.body);

    // Normalize destination number
    const targetNumber = payload.to.replace(/[^\d+]/g, '');

    // Find rented number in database
    const phoneNumber = await prisma.phoneNumber.findFirst({
      where: {
        number: { contains: targetNumber.slice(-8) }, // Match last 8 digits for formatting tolerance
        status: { not: 'RELEASED' },
      },
      include: { user: true },
    });

    if (!phoneNumber) {
      return reply.status(404).send({ error: 'Rented number not found or released' });
    }

    // Check block-list of disallowed services to reduce abuse (e.g., banking/gov SMS)
    const lowerText = payload.text.toLowerCase();
    const isAbuseKeyword = ['irs.gov', 'gov.uk', 'treasury', 'social security', 'bank of america', 'chase bank'].some(
      (keyword) => lowerText.includes(keyword)
    );

    if (isAbuseKeyword) {
      await prisma.abuseReport.create({
        data: {
          userId: phoneNumber.userId,
          itemType: 'SMS',
          itemId: phoneNumber.id,
          reason: 'PROHIBITED_BANKING_OR_GOV_SMS',
          details: `From: ${payload.from}, Text snippet: ${payload.text.slice(0, 50)}`,
        },
      });
    }

    // Auto-detect OTP codes in SMS
    const otpResult = extractOtpAndLinks(payload.text);

    // Encrypt at rest
    const encrypted = encryptText(payload.text);

    // Store SMS and increment received counter (stops auto-refund)
    const sms = await prisma.smsMessage.create({
      data: {
        phoneNumberId: phoneNumber.id,
        fromNumber: payload.from,
        encryptedText: encrypted.cipherText,
        iv: encrypted.iv,
        authTag: encrypted.authTag,
        preview: payload.text.slice(0, 100),
        extractedOtp: otpResult.code,
      },
    });

    await prisma.phoneNumber.update({
      where: { id: phoneNumber.id },
      data: { receivedSmsQty: { increment: 1 } },
    });

    // Notify user in real time via WebSocket
    wsHub.notifyNewSms(phoneNumber.userId, phoneNumber.id, {
      id: sms.id,
      fromNumber: payload.from,
      text: payload.text,
      extractedOtp: otpResult.code,
      receivedAt: sms.receivedAt,
    });

    return reply.send({ success: true, smsId: sms.id, extractedOtp: otpResult.code });
  });
};
