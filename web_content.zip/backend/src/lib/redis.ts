import Redis from 'ioredis';
import { env } from '../config/env.js';

let redisClient: Redis | null = null;

try {
  redisClient = new Redis(env.REDIS_URL, {
    maxRetriesPerRequest: 1,
    retryStrategy(times) {
      if (times > 3) return null;
      return Math.min(times * 100, 1000);
    },
    lazyConnect: true,
  });

  redisClient.on('error', (err) => {
    // Graceful fallback logging
    console.warn('[Redis] Connection warning (running in degraded memory mode if disconnected):', err.message);
  });
} catch (e) {
  console.warn('[Redis] Initialized with fallback store');
}

// In-memory fallback map for test/offline environments
const fallbackStore = new Map<string, { val: string; expiresAt: number }>();

export const redis = {
  async get(key: string): Promise<string | null> {
    try {
      if (redisClient && redisClient.status === 'ready') {
        return await redisClient.get(key);
      }
    } catch {}
    const entry = fallbackStore.get(key);
    if (!entry) return null;
    if (Date.now() > entry.expiresAt) {
      fallbackStore.delete(key);
      return null;
    }
    return entry.val;
  },

  async set(key: string, val: string, mode?: string, ttlSeconds?: number): Promise<void> {
    try {
      if (redisClient && redisClient.status === 'ready') {
        if (mode === 'EX' && ttlSeconds) {
          await redisClient.set(key, val, 'EX', ttlSeconds);
        } else {
          await redisClient.set(key, val);
        }
        return;
      }
    } catch {}
    const ttl = ttlSeconds ? ttlSeconds * 1000 : 3600 * 1000;
    fallbackStore.set(key, { val, expiresAt: Date.now() + ttl });
  },

  async del(key: string): Promise<void> {
    try {
      if (redisClient && redisClient.status === 'ready') {
        await redisClient.del(key);
      }
    } catch {}
    fallbackStore.delete(key);
  },

  async exists(key: string): Promise<boolean> {
    const val = await this.get(key);
    return val !== null;
  }
};
