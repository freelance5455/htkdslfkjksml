/**
 * Auto-detects OTP verification codes and activation links
 * from incoming emails and SMS bodies.
 */
export interface ExtractedCodeResult {
  code: string | null;
  verificationUrl: string | null;
  confidence: 'high' | 'medium' | 'none';
}

const OTP_PATTERNS = [
  // "Your verification code is 123456"
  /(?:code|otp|pin|token|verification|password|login|confirm|passcode)[:\s\-is]{1,6}([0-9]{4,8})\b/i,
  // "Enter 123456 to verify"
  /(?:enter|use|with)\s+([0-9]{4,8})\s+(?:to\s+(?:verify|login|confirm|authenticate))/i,
  // "G-123456 is your Google verification code"
  /\b([A-Z0-9]{1,3}-[0-9]{4,8})\b/i,
  // Standalone 6-digit code with word boundary
  /\b([0-9]{6})\b/,
  // 4-digit code in explicit verification context
  /(?:security|secret)\s*code[:\s]+([0-9]{4})/i,
];

const URL_PATTERNS = [
  // Links with verify, confirm, activate, token
  /(https?:\/\/[^\s<>"']+(?:verify|confirm|activation|token|auth|validate)[^\s<>"']*)/i,
  // Generic URL
  /(https?:\/\/[^\s<>"']+)/i,
];

export function extractOtpAndLinks(text: string): ExtractedCodeResult {
  if (!text) {
    return { code: null, verificationUrl: null, confidence: 'none' };
  }

  let code: string | null = null;
  let confidence: 'high' | 'medium' | 'none' = 'none';

  for (let i = 0; i < OTP_PATTERNS.length; i++) {
    const match = text.match(OTP_PATTERNS[i]);
    if (match && match[1]) {
      code = match[1].trim();
      confidence = i <= 2 ? 'high' : 'medium';
      break;
    }
  }

  let verificationUrl: string | null = null;
  for (const pattern of URL_PATTERNS) {
    const urlMatch = text.match(pattern);
    if (urlMatch && urlMatch[1]) {
      verificationUrl = urlMatch[1];
      break;
    }
  }

  return { code, verificationUrl, confidence };
}
