import DOMPurify from 'isomorphic-dompurify';

export interface SanitizeResult {
  cleanHtml: string;
  hasTrackers: boolean;
  plainText: string;
}

/**
 * Sanitizes email HTML server-side:
 * - Strips `<script>`, `<iframe>`, `<object>`, `<embed>`, `<form>`
 * - Strips `onclick`, `onload`, and other dangerous javascript handlers
 * - Detects and neutralizes tracking pixels (1x1 gif/png images, email open trackers)
 * - Converts remote image URLs to data-src if remote images are blocked
 */
export function sanitizeEmailHtml(rawHtml: string, allowRemoteImages: boolean = false): SanitizeResult {
  if (!rawHtml) {
    return { cleanHtml: '', hasTrackers: false, plainText: '' };
  }

  let trackerDetected = false;

  // Pre-strip known tracker patterns (1x1 pixels, spy pixels, pixel.gif)
  const trackerPattern = /<img[^>]+(?:width=['"]?[01]['"]?|height=['"]?[01]['"]?|display:\s*none|pixel|tracking|beacon|mailtrack|open\?)[^>]*>/gi;
  if (trackerPattern.test(rawHtml)) {
    trackerDetected = true;
  }

  let sanitized = DOMPurify.sanitize(rawHtml, {
    ALLOWED_TAGS: [
      'a', 'b', 'blockquote', 'br', 'code', 'div', 'em', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
      'hr', 'i', 'img', 'li', 'ol', 'p', 'pre', 'span', 'strong', 'table', 'tbody', 'td',
      'th', 'thead', 'tr', 'ul', 'font', 'center', 'sub', 'sup'
    ],
    ALLOWED_ATTR: ['href', 'title', 'target', 'src', 'alt', 'width', 'height', 'style', 'color', 'align'],
    FORBID_TAGS: ['script', 'iframe', 'frame', 'object', 'embed', 'form', 'input', 'button'],
    FORBID_ATTR: ['onerror', 'onload', 'onclick', 'onmouseover'],
  });

  // If remote images are blocked, rewrite img src to data-src to prevent automatic loading
  if (!allowRemoteImages) {
    sanitized = sanitized.replace(/<img\s+([^>]*?)src=["'](https?:\/\/[^"']+)["']([^>]*?)>/gi, (match, before, src, after) => {
      // Check if it was a 1x1 tracker
      if (match.includes('width="1"') || match.includes('height="1"') || match.includes('width="0"')) {
        return '<!-- tracker removed -->';
      }
      return `<img ${before} data-blocked-src="${src}" src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='80' height='24'><rect width='100%' height='100%' fill='%23334155'/><text x='50%' y='65%' font-family='sans-serif' font-size='10' fill='%2394a3b8' text-anchor='middle'>[Image Blocked]</text></svg>" ${after}>`;
    });
  }

  // Derive plain text
  const plainText = sanitized.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();

  return {
    cleanHtml: sanitized,
    hasTrackers: trackerDetected,
    plainText,
  };
}
