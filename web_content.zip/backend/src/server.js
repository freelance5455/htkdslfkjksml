import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Database from "better-sqlite3";
import { google } from "googleapis";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: "200kb" }));

const PORT = process.env.PORT || 8080;
const JWT_SECRET = process.env.JWT_SECRET || "dev-only-change-me";
const PACKAGE_NAME = process.env.GOOGLE_PLAY_PACKAGE_NAME || "com.mdcatnums.prep";
const db = new Database("mdcat_nums.sqlite");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS progress (
  user_id INTEGER PRIMARY KEY,
  done INTEGER NOT NULL DEFAULT 0,
  right_count INTEGER NOT NULL DEFAULT 0,
  mistakes_json TEXT NOT NULL DEFAULT '[]',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS entitlements (
  user_id INTEGER PRIMARY KEY,
  product_id TEXT,
  active INTEGER NOT NULL DEFAULT 0,
  expiry_time TEXT,
  purchase_token TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS questions (
  id TEXT PRIMARY KEY,
  subject TEXT NOT NULL,
  question TEXT NOT NULL,
  options_json TEXT NOT NULL,
  answer INTEGER NOT NULL,
  explanation TEXT NOT NULL,
  premium INTEGER NOT NULL DEFAULT 0
);
`);

const seed = [
  ["bio-001","Biology","Which organelle is mainly responsible for ATP production?",["Ribosome","Mitochondrion","Golgi apparatus","Lysosome"],1,"Mitochondria generate most cellular ATP through aerobic respiration.",0],
  ["bio-002","Biology","The basic structural and functional unit of life is the:",["Tissue","Organ","Cell","Organ system"],2,"The cell is the fundamental unit of structure and function in living organisms.",0],
  ["chem-001","Chemistry","The pH of a neutral aqueous solution at 25°C is:",["0","5","7","14"],2,"At 25°C, neutral water has pH 7.",0],
  ["chem-002","Chemistry","A catalyst changes the rate of a reaction by changing the:",["Equilibrium constant","Activation energy","Products","Mass"],1,"A catalyst provides an alternative pathway with lower activation energy.",1],
  ["phy-001","Physics","Which particle was discovered by James Chadwick?",["Electron","Proton","Neutron","Positron"],2,"Chadwick demonstrated the existence of the neutron in 1932.",0],
  ["eng-001","English","Choose the correct form: She ___ finished her work.",["have","has","do","did"],1,"With the singular subject 'she', the present perfect uses 'has'.",0]
];

const insert = db.prepare(`
INSERT OR IGNORE INTO questions
(id,subject,question,options_json,answer,explanation,premium)
VALUES(?,?,?,?,?,?,?)
`);
for (const q of seed) insert.run(q[0], q[1], q[2], JSON.stringify(q[3]), q[4], q[5], q[6]);

function auth(req,res,next){
  const h=req.headers.authorization||"";
  const token=h.startsWith("Bearer ")?h.slice(7):"";
  try { req.user=jwt.verify(token,JWT_SECRET); next(); }
  catch { res.status(401).json({ok:false,error:"Authentication required."}); }
}

function issue(user){
  return jwt.sign({id:user.id,email:user.email,name:user.name},JWT_SECRET,{expiresIn:"30d"});
}

app.get("/health",(_req,res)=>res.json({ok:true,service:"MDCAT/NUMS Prep backend",version:"1.1"}));

app.post("/api/auth/register",async(req,res)=>{
  const {name,email,password}=req.body||{};
  if(!name||!email||!password||password.length<8) return res.status(400).json({ok:false,error:"Name, valid email and password of at least 8 characters are required."});
  const normalized=email.trim().toLowerCase();
  try{
    const hash=await bcrypt.hash(password,12);
    const info=db.prepare("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)").run(name.trim(),normalized,hash);
    db.prepare("INSERT INTO progress(user_id) VALUES(?)").run(info.lastInsertRowid);
    const user={id:info.lastInsertRowid,name:name.trim(),email:normalized};
    res.json({ok:true,token:issue(user),user});
  }catch{
    res.status(409).json({ok:false,error:"An account with that email already exists."});
  }
});

app.post("/api/auth/login",async(req,res)=>{
  const {email,password}=req.body||{};
  const user=db.prepare("SELECT * FROM users WHERE email=?").get(String(email||"").trim().toLowerCase());
  if(!user || !(await bcrypt.compare(password||"",user.password_hash))) return res.status(401).json({ok:false,error:"Incorrect email or password."});
  res.json({ok:true,token:issue(user),user:{id:user.id,name:user.name,email:user.email}});
});

app.get("/api/me",auth,(req,res)=>{
  const user=db.prepare("SELECT id,name,email,created_at FROM users WHERE id=?").get(req.user.id);
  const ent=db.prepare("SELECT active,product_id,expiry_time FROM entitlements WHERE user_id=?").get(req.user.id);
  res.json({ok:true,user, premium:!!ent?.active, entitlement:ent||null});
});

app.get("/api/questions",auth,(req,res)=>{
  const premium=!!db.prepare("SELECT active FROM entitlements WHERE user_id=?").get(req.user.id)?.active;
  const rows=db.prepare("SELECT * FROM questions ORDER BY rowid").all();
  const questions=rows.filter(q=>!q.premium || premium).map(q=>({
    id:q.id,subject:q.subject,question:q.question,options:JSON.parse(q.options_json),
    answer:q.answer,explanation:q.explanation,premium:!!q.premium
  }));
  res.json({ok:true,questions});
});

app.get("/api/progress",auth,(req,res)=>{
  const p=db.prepare("SELECT done,right_count,mistakes_json,updated_at FROM progress WHERE user_id=?").get(req.user.id)
    || {done:0,right_count:0,mistakes_json:"[]"};
  res.json({ok:true,done:p.done,right:p.right_count,mistakes:JSON.parse(p.mistakes_json),updatedAt:p.updated_at});
});

app.post("/api/progress",auth,(req,res)=>{
  const done=Math.max(0,Number(req.body.done||0));
  const right=Math.max(0,Number(req.body.right||0));
  const mistakes=Array.isArray(req.body.mistakes)?req.body.mistakes:[];
  db.prepare(`
    INSERT INTO progress(user_id,done,right_count,mistakes_json,updated_at)
    VALUES(?,?,?,?,CURRENT_TIMESTAMP)
    ON CONFLICT(user_id) DO UPDATE SET
      done=excluded.done,right_count=excluded.right_count,
      mistakes_json=excluded.mistakes_json,updated_at=CURRENT_TIMESTAMP
  `).run(req.user.id,done,right,JSON.stringify(mistakes));
  res.json({ok:true});
});

function getAuth(){
  const email=process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
  const rawKey=process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY;
  if(!email||!rawKey) throw new Error("Google Play service account is not configured.");
  return new google.auth.GoogleAuth({
    credentials:{client_email:email,private_key:rawKey.replace(/\\n/g,"\n")},
    scopes:["https://www.googleapis.com/auth/androidpublisher"]
  });
}


async function refreshSubscriptionForUser(userId, purchaseToken) {
  const publisher=google.androidpublisher({version:"v3",auth:getAuth()});
  const result=await publisher.purchases.subscriptionsv2.get({
    packageName:PACKAGE_NAME, token:purchaseToken
  });
  const sub=result.data;
  const item=(sub.lineItems||[])[0];
  const active=["SUBSCRIPTION_STATE_ACTIVE","SUBSCRIPTION_STATE_IN_GRACE_PERIOD"].includes(sub.subscriptionState);
  db.prepare(`
    UPDATE entitlements SET active=?, expiry_time=?, updated_at=CURRENT_TIMESTAMP
    WHERE user_id=? AND purchase_token=?
  `).run(active?1:0,item?.expiryTime||null,userId,purchaseToken);
  return {active,state:sub.subscriptionState||null,expiryTime:item?.expiryTime||null};
}

// Google Play RTDN receiver.
// Configure Google Cloud Pub/Sub to POST push messages to this endpoint.
// Do not expose this endpoint without authenticating the Pub/Sub push in production.
app.post("/api/play/rtdn", async (req,res)=>{
  try{
    const msg=req.body?.message?.data;
    if(!msg) return res.status(400).json({ok:false,error:"Missing Pub/Sub message data."});
    const decoded=JSON.parse(Buffer.from(msg,"base64").toString("utf8"));
    const token=decoded?.subscriptionNotification?.purchaseToken;
    if(!token) return res.json({ok:true,ignored:true});

    const row=db.prepare("SELECT user_id FROM entitlements WHERE purchase_token=?").get(token);
    if(row?.user_id) await refreshSubscriptionForUser(row.user_id,token);
    res.json({ok:true});
  }catch(e){
    console.error(e?.response?.data||e);
    // Return 200 only after a successfully processed/ignored event in production.
    res.status(500).json({ok:false,error:"RTDN processing failed."});
  }
});

app.post("/api/play/verify-subscription",auth,async(req,res)=>{
  try{
    const {purchaseToken,productId}=req.body||{};
    if(!purchaseToken||!productId) return res.status(400).json({ok:false,error:"purchaseToken and productId are required."});
    const publisher=google.androidpublisher({version:"v3",auth:getAuth()});
    const result=await publisher.purchases.subscriptionsv2.get({packageName:PACKAGE_NAME,token:purchaseToken});
    const sub=result.data;
    const item=(sub.lineItems||[]).find(x=>x.productId===productId);
    const active=["SUBSCRIPTION_STATE_ACTIVE","SUBSCRIPTION_STATE_IN_GRACE_PERIOD"].includes(sub.subscriptionState)&&!!item;
    db.prepare(`
      INSERT INTO entitlements(user_id,product_id,active,expiry_time,purchase_token,updated_at)
      VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
      ON CONFLICT(user_id) DO UPDATE SET
        product_id=excluded.product_id,active=excluded.active,
        expiry_time=excluded.expiry_time,purchase_token=excluded.purchase_token,
        updated_at=CURRENT_TIMESTAMP
    `).run(req.user.id,productId,active?1:0,item?.expiryTime||null,purchaseToken);
    res.json({ok:true,active,subscriptionState:sub.subscriptionState||null,productId:item?.productId||null,expiryTime:item?.expiryTime||null});
  }catch(e){
    console.error(e?.response?.data||e);
    res.status(500).json({ok:false,error:"Subscription verification failed."});
  }
});


app.post("/api/admin/questions/import",(req,res)=>{
  const adminToken=process.env.ADMIN_IMPORT_TOKEN;
  if(!adminToken || req.headers["x-admin-token"]!==adminToken)
    return res.status(403).json({ok:false,error:"Forbidden"});
  const questions=Array.isArray(req.body?.questions)?req.body.questions:[];
  const tx=db.transaction(()=>{
    for(const q of questions){
      if(!q.id||!q.subject||!q.question||!Array.isArray(q.options)||typeof q.answer!=="number")
        continue;
      insert.run(q.id,q.subject,q.question,JSON.stringify(q.options),q.answer,String(q.explanation||""),q.premium?1:0);
    }
  });
  tx();
  res.json({ok:true,imported:questions.length});
});

app.listen(PORT,()=>console.log(`Backend listening on http://localhost:${PORT}`));
