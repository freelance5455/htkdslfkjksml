require("dotenv").config();

const express = require("express");
const crypto = require("crypto");
const axios = require("axios");
const { Pool } = require("pg");

const app = express();
const port = Number(process.env.PORT || 3000);
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const GOOGLE_KEYS_URL =
  "https://www.gstatic.com/admob/reward/verifier-keys.json";

const ADMOB_REWARDED_AD_UNIT =
  process.env.ADMOB_REWARDED_AD_UNIT ||
  "ca-app-pub-3940256099942544/5224354917";

let keyCache = null;
let keyCacheExpiresAt = 0;

app.use(express.json());

app.get("/health", async (_req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ ok: true, database: true });
  } catch (error) {
    console.error(error);
    res.status(503).json({ ok: false, database: false });
  }
});

function requireUuid(value, field) {
  if (!value || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)) {
    const error = new Error(`Invalid ${field}`);
    error.status = 400;
    throw error;
  }
  return value;
}

/*
 * DEMO authentication:
 * The Android sample supplies X-User-Id.
 *
 * Production:
 * Replace this with your existing Messenger authentication/JWT/session
 * middleware. Never trust a client-provided user ID as authentication.
 */
function getAuthenticatedUserId(req) {
  return requireUuid(req.header("x-user-id"), "user ID");
}

app.post("/api/bootstrap", async (_req, res) => {
  const userId = crypto.randomUUID();

  await pool.query(
    "INSERT INTO users (id) VALUES ($1)",
    [userId]
  );

  res.json({ userId });
});

/*
 * Creates a one-time nonce that is embedded into AdMob custom_data.
 * The nonce binds the eventual Google SSV callback to the user/session.
 */
app.post("/api/reward/session", async (req, res) => {
  try {
    const userId = getAuthenticatedUserId(req);
    const nonce = crypto.randomUUID();

    await pool.query(
      `INSERT INTO reward_sessions (nonce, user_id, expires_at)
       VALUES ($1, $2, NOW() + INTERVAL '10 minutes')`,
      [nonce, userId]
    );

    res.json({
      nonce,
      adUnitId: ADMOB_REWARDED_AD_UNIT,
      expiresInSeconds: 600
    });
  } catch (error) {
    console.error(error);
    res.status(error.status || 500).json({
      error: error.message || "Internal error"
    });
  }
});

app.get("/api/reward/balance", async (req, res) => {
  try {
    const userId = getAuthenticatedUserId(req);

    const result = await pool.query(
      "SELECT balance FROM users WHERE id = $1",
      [userId]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    res.json({ balance: Number(result.rows[0].balance) });
  } catch (error) {
    console.error(error);
    res.status(error.status || 500).json({
      error: error.message || "Internal error"
    });
  }
});

async function getGooglePublicKeys() {
  const now = Date.now();

  if (keyCache && now < keyCacheExpiresAt) {
    return keyCache;
  }

  const response = await axios.get(GOOGLE_KEYS_URL, {
    timeout: 10000
  });

  if (!response.data || !Array.isArray(response.data.keys)) {
    throw new Error("Invalid Google key response");
  }

  keyCache = response.data.keys;
  // Google recommends periodically refreshing the verification keys.
  keyCacheExpiresAt = now + 23 * 60 * 60 * 1000;

  return keyCache;
}

/*
 * IMPORTANT:
 * Google signs the original callback query string.
 * Do NOT reconstruct it by parsing/sorting/re-serializing parameters.
 *
 * Google documents that signature and key_id are the final two query
 * parameters, in that order. Everything before "signature=" is signed.
 */
function getSignedContentAndSignature(req) {
  const rawQuery = req.originalUrl.split("?")[1] || "";

  const signatureMarker = "signature=";
  const signatureIndex = rawQuery.indexOf(signatureMarker);

  if (signatureIndex < 0) {
    throw new Error("Missing signature");
  }

  if (signatureIndex === 0 || rawQuery[signatureIndex - 1] !== "&") {
    throw new Error("Invalid signature position");
  }

  const signedContent = rawQuery.slice(0, signatureIndex - 1);

  const suffix = rawQuery.slice(signatureIndex);
  const keyMarker = "&key_id=";
  const keyIndex = suffix.indexOf(keyMarker);

  if (keyIndex < 0) {
    throw new Error("Missing key_id");
  }

  const signature = suffix.slice(
    signatureMarker.length,
    keyIndex
  );

  const keyId = suffix.slice(keyIndex + keyMarker.length);

  if (!signature || !keyId || keyId.includes("&")) {
    throw new Error("Malformed signature/key_id");
  }

  return {
    signedContent,
    signature,
    keyId
  };
}

function verifyGoogleSignature(signedContent, signature, keyId, keys) {
  const key = keys.find(
    (item) => String(item.keyId) === String(keyId)
  );

  if (!key) {
    throw new Error("Unknown Google key_id");
  }

  const publicKeyPem =
    key.pem ||
    `-----BEGIN PUBLIC KEY-----\n${key.base64}\n-----END PUBLIC KEY-----`;

  const verifier = crypto.createVerify("SHA256");
  verifier.update(Buffer.from(signedContent, "utf8"));
  verifier.end();

  const signatureBytes = Buffer.from(signature, "base64url");

  return verifier.verify(publicKeyPem, signatureBytes);
}

/*
 * Google calls this endpoint directly.
 * Configure this exact HTTPS URL in the AdMob rewarded ad unit SSV settings.
 */
app.get("/v1/admob/ssv", async (req, res) => {
  const client = await pool.connect();

  try {
    const {
      signedContent,
      signature,
      keyId
    } = getSignedContentAndSignature(req);

    const keys = await getGooglePublicKeys();

    if (!verifyGoogleSignature(
      signedContent,
      signature,
      keyId,
      keys
    )) {
      return res.status(403).send("Invalid signature");
    }

    const {
      ad_network,
      ad_unit,
      reward_amount,
      reward_item,
      timestamp,
      transaction_id,
      user_id,
      custom_data
    } = req.query;

    if (
      !ad_network ||
      !ad_unit ||
      !reward_amount ||
      !reward_item ||
      !timestamp ||
      !transaction_id ||
      !user_id ||
      !custom_data
    ) {
      return res.status(400).send("Missing required SSV parameter");
    }

    if (String(ad_unit) !== ADMOB_REWARDED_AD_UNIT) {
      return res.status(400).send("Unexpected ad unit");
    }

    requireUuid(String(user_id), "user_id");
    requireUuid(String(custom_data), "custom_data");

    const amount = Number.parseInt(String(reward_amount), 10);
    const timestampMs = Number.parseInt(String(timestamp), 10);

    if (!Number.isSafeInteger(amount) || amount <= 0) {
      return res.status(400).send("Invalid reward amount");
    }

    if (!Number.isSafeInteger(timestampMs) || timestampMs <= 0) {
      return res.status(400).send("Invalid timestamp");
    }

    // Reject callbacks that are wildly outside the expected time window.
    // Google timestamps are epoch milliseconds.
    const maxAgeMs = 15 * 60 * 1000;
    if (Math.abs(Date.now() - timestampMs) > maxAgeMs) {
      return res.status(400).send("Stale SSV timestamp");
    }

    await client.query("BEGIN");

    // Lock the transaction row if it exists. This makes duplicate delivery
    // safe even if two Google callbacks arrive concurrently.
    const existing = await client.query(
      `SELECT transaction_id
       FROM reward_transactions
       WHERE transaction_id = $1
       FOR UPDATE`,
      [String(transaction_id)]
    );

    if (existing.rowCount > 0) {
      await client.query("COMMIT");
      return res.status(200).send("OK");
    }

    const session = await client.query(
      `SELECT nonce, user_id, status
       FROM reward_sessions
       WHERE nonce = $1
         AND expires_at > NOW()
       FOR UPDATE`,
      [String(custom_data)]
    );

    if (
      session.rowCount === 0 ||
      session.rows[0].status !== "pending"
    ) {
      await client.query("ROLLBACK");
      return res.status(400).send("Invalid or already used reward session");
    }

    if (String(session.rows[0].user_id) !== String(user_id)) {
      await client.query("ROLLBACK");
      return res.status(403).send("User/session mismatch");
    }

    await client.query(
      `INSERT INTO reward_transactions
       (transaction_id, user_id, nonce, ad_network, ad_unit,
        reward_amount, reward_item, timestamp_ms)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [
        String(transaction_id),
        String(user_id),
        String(custom_data),
        String(ad_network),
        String(ad_unit),
        amount,
        String(reward_item),
        timestampMs
      ]
    );

    await client.query(
      "UPDATE users SET balance = balance + $1 WHERE id = $2",
      [amount, String(user_id)]
    );

    await client.query(
      "UPDATE reward_sessions SET status = 'rewarded' WHERE nonce = $1",
      [String(custom_data)]
    );

    await client.query("COMMIT");

    console.log(
      `Reward granted: user=${user_id} amount=${amount} transaction=${transaction_id}`
    );

    return res.status(200).send("OK");
  } catch (error) {
    try {
      await client.query("ROLLBACK");
    } catch (_) {}

    console.error("SSV error:", error);
    return res.status(500).send("Internal Error");
  } finally {
    client.release();
  }
});

app.use((error, _req, res, _next) => {
  console.error(error);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(port, () => {
  console.log(`Reward SSV backend listening on http://0.0.0.0:${port}`);
});
