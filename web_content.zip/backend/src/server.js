import { config, assertProductionSafety } from './config/index.js';
import { runMigrations } from './database/migrate.js';
import { createApp } from './app.js';
import { logger } from './utils/logger.js';
import { taskManager } from './core/task-manager.js';

// Garante que o banco esteja com o schema mais recente antes de aceitar requisicoes
runMigrations();
// Retoma tarefas queued/processing persistidas antes de aceitar novas requisicoes.
taskManager.recoverPendingTasks();

for (const warning of assertProductionSafety()) {
  logger.warn(warning);
}

const server = createApp();

server.listen(config.port, config.host, () => {
  logger.info(`ADAM KNOWLEDGE backend rodando em http://${config.host}:${config.port}`);
  logger.info('Endpoints disponiveis: ver docs/API.md');
});

process.on('SIGINT', () => {
  logger.info('Encerrando ADAM KNOWLEDGE backend...');
  server.close(() => process.exit(0));
});

export { server };
