/**
 * Roteador HTTP minimalista, escrito sobre o modulo nativo `node:http`.
 * Evita a dependencia de um framework (Express/Fastify) nesta primeira etapa,
 * ja que o ambiente de build nao tinha acesso a rede para `npm install` no
 * momento desta implementacao. Pode ser trocado por Express no futuro sem
 * alterar os handlers, pois a assinatura (req, res, params) e compativel.
 */
import { config } from '../config/index.js';

export class HttpRouter {
  constructor() {
    this.routes = []; // { method, pattern: RegExp, paramNames: string[], handler }
  }

  _register(method, path, handler) {
    const paramNames = [];
    const patternStr = path
      .split('/')
      .map((segment) => {
        if (segment.startsWith(':')) {
          paramNames.push(segment.slice(1));
          return '([^/]+)';
        }
        return segment.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      })
      .join('/');
    const pattern = new RegExp(`^${patternStr}/?$`);
    this.routes.push({ method, pattern, paramNames, handler });
  }

  get(path, handler) { this._register('GET', path, handler); }
  post(path, handler) { this._register('POST', path, handler); }

  async handle(req, res) {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    applyCors(req, res);
    if (req.method === 'OPTIONS') {
      if (!res.getHeader('Access-Control-Allow-Origin')) {
        sendJson(res, 403, { error: 'CORS_ORIGIN_DENIED', message: 'Origem nao autorizada para acessar a API.' });
        return;
      }
      res.writeHead(204);
      res.end();
      return;
    }
    const match = this.routes.find((r) => r.method === req.method && r.pattern.test(url.pathname));

    if (!match) {
      sendJson(res, 404, { error: 'NOT_FOUND', message: `Rota nao encontrada: ${req.method} ${url.pathname}` });
      return;
    }

    const execResult = match.pattern.exec(url.pathname);
    const params = {};
    match.paramNames.forEach((name, i) => { params[name] = decodeURIComponent(execResult[i + 1]); });

    let body = {};
    if (req.method === 'POST') {
      try {
        body = await readJsonBody(req);
      } catch (err) {
        sendJson(res, 400, { error: 'INVALID_JSON', message: `Corpo da requisicao invalido: ${err.message}` });
        return;
      }
    }

    try {
      await match.handler({ req, res, params, query: Object.fromEntries(url.searchParams), body, sendJson: (status, payload) => sendJson(res, status, payload) });
    } catch (err) {
      // Erros de validacao de entrada do usuario (ex: ResourceValidationError)
      // sao erros do CLIENTE (400), nunca erros internos do servidor (500),
      // mesmo quando lancados varias camadas abaixo do handler da rota.
      const isValidationError = err.name && err.name.endsWith('ValidationError');
      const statusCode = err.statusCode || (isValidationError ? 400 : 500);
      const code = err.code || (isValidationError ? 'VALIDATION_ERROR' : 'INTERNAL_ERROR');
      sendJson(res, statusCode, {
        error: code,
        message: err.message || 'Erro interno inesperado.',
      });
    }
  }
}

function applyCors(req, res) {
  const origin = req.headers.origin;
  if (!origin) return;
  const allowed = config.corsAllowedOrigins.includes(origin) || config.corsAllowedOrigins.includes('*');
  if (!allowed) return;
  res.setHeader('Access-Control-Allow-Origin', config.corsAllowedOrigins.includes('*') ? '*' : origin);
  res.setHeader('Vary', 'Origin');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type');
  res.setHeader('Access-Control-Max-Age', '600');
}


export function sendJson(res, status, payload) {
  const body = JSON.stringify(payload, null, 2);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    let size = 0;
    const MAX_SIZE = 2 * 1024 * 1024; // 2MB: limite de requisicao (ver secao 12, limites de requisicao)

    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_SIZE) {
        reject(new Error('Corpo da requisicao excede o limite de 2MB.'));
        req.destroy();
        return;
      }
      data += chunk;
    });
    req.on('end', () => {
      if (!data.trim()) return resolve({});
      try {
        resolve(JSON.parse(data));
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', reject);
  });
}

export class ApiError extends Error {
  constructor(statusCode, code, message) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
  }
}
