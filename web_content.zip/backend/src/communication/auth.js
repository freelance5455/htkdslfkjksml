import { timingSafeEqual } from 'node:crypto';
import { config } from '../config/index.js';

/**
 * Autenticacao simples por token compartilhado (Bearer), adequada para
 * comunicacao entre dois aplicativos Android no mesmo aparelho/rede local.
 * Usa comparacao em tempo constante para evitar vazamento de informacao via
 * timing attack.
 */
export function verifyToken(authorizationHeader) {
  if (!config.addonforgeToken) {
    return { ok: false, reason: 'ADDONFORGE_TOKEN nao esta configurado no servidor.' };
  }
  if (!authorizationHeader || !authorizationHeader.startsWith('Bearer ')) {
    return { ok: false, reason: 'Cabecalho Authorization ausente ou mal formatado. Use "Bearer <token>".' };
  }

  const provided = authorizationHeader.slice('Bearer '.length).trim();
  const expected = config.addonforgeToken;

  const providedBuf = Buffer.from(provided);
  const expectedBuf = Buffer.from(expected);
  if (providedBuf.length !== expectedBuf.length) {
    return { ok: false, reason: 'Token invalido.' };
  }
  const matches = timingSafeEqual(providedBuf, expectedBuf);
  return matches ? { ok: true } : { ok: false, reason: 'Token invalido.' };
}

/** Rastreia o estado de conexao do AddonForge para o System Monitor */
export const addonForgeConnectionTracker = {
  _lastSeenAt: null,
  _connected: false,

  markSeen() {
    this._lastSeenAt = new Date().toISOString();
    this._connected = true;
  },

  markDisconnected() {
    this._connected = false;
  },

  isConnected() {
    // considera desconectado se nao houve contato nos ultimos 5 minutos
    if (!this._connected || !this._lastSeenAt) return false;
    const elapsedMs = Date.now() - new Date(this._lastSeenAt).getTime();
    return elapsedMs < 5 * 60 * 1000;
  },

  lastSeenAt() {
    return this._lastSeenAt;
  },
};
