import { randomUUID } from 'node:crypto';
import { HttpRouter, ApiError } from './http-router.js';
import { verifyToken, addonForgeConnectionTracker } from './auth.js';
import { config } from '../config/index.js';
import { intelligenceOrchestrator } from '../core/intelligence-orchestrator.js';
import { taskManager } from '../core/task-manager.js';
import { resourceLibrary } from '../resources/resource-library.js';
import { systemMonitor } from '../monitor/system-monitor.js';
import { logger } from '../utils/logger.js';
import path from 'node:path';

/**
 * ADAM ADDONFORGE BRIDGE
 *
 * Implementa o contrato de API proposto na especificacao (secao 11):
 *   GET  /api/health
 *   POST /api/connect
 *   POST /api/research
 *   POST /api/resources/search
 *   POST /api/resources/create
 *   GET  /api/tasks/:id
 *   GET  /api/library
 *   GET  /api/library/:id
 *   POST /api/sync
 *
 * Toda rota (exceto /api/health) exige autenticacao via
 * "Authorization: Bearer <ADDONFORGE_TOKEN>".
 */
export function buildAddonForgeRouter() {
  const router = new HttpRouter();

  function requireAuth(req) {
    const auth = verifyToken(req.headers.authorization);
    if (!auth.ok) {
      throw new ApiError(401, 'UNAUTHORIZED', auth.reason);
    }
    addonForgeConnectionTracker.markSeen();
  }

  // GET /api/health - nao exige autenticacao, usado para diagnostico rapido
  router.get('/api/health', async ({ sendJson }) => {
    const status = await systemMonitor.getStatus();
    sendJson(200, status);
  });

  // POST /api/connect - handshake inicial do AddonForge
  router.post('/api/connect', async ({ req, body, sendJson }) => {
    requireAuth(req);
    logger.info('AddonForge conectou-se ao ADAM KNOWLEDGE', { client: body.client_name || 'desconhecido' });
    sendJson(200, {
      connected: true,
      server: 'ADAM KNOWLEDGE',
      version: '0.1.0',
      serverTime: new Date().toISOString(),
    });
  });

  // POST /api/research - solicitacao de pesquisa (fluxo principal da especificacao)
  router.post('/api/research', async ({ req, body, sendJson }) => {
    requireAuth(req);

    const { request_id: requestId, query, category, requirements = {} } = body;
    if (!query || typeof query !== 'string') {
      throw new ApiError(400, 'INVALID_REQUEST', 'O campo "query" e obrigatorio e deve ser uma string.');
    }

    const result = await intelligenceOrchestrator.processRequest(query, {
      requestId: requestId || randomUUID(),
      category,
      ...requirements,
    });

    sendJson(202, {
      request_id: result.requestId,
      status: 'processing',
      intent: result.intent,
      tasks: result.tasks.map((t) => ({ task_id: t.id, type: t.type, status: t.status })),
    });
  });

  // GET /api/tasks/:id (tambem aceitamos consultar pelo request_id, documentado em API.md)
  router.get('/api/tasks/:id', async ({ req, params, sendJson }) => {
    requireAuth(req);
    const byRequest = intelligenceOrchestrator.getRequestStatus(params.id);
    if (byRequest) {
      sendJson(200, byRequest);
      return;
    }
    const task = taskManager.getTask(params.id);
    if (!task) throw new ApiError(404, 'NOT_FOUND', `Nenhuma tarefa ou solicitacao encontrada com id "${params.id}".`);
    sendJson(200, task);
  });

  // POST /api/resources/search
  router.post('/api/resources/search', async ({ req, body, sendJson }) => {
    requireAuth(req);
    const results = resourceLibrary.search(body || {});
    sendJson(200, results);
  });

  // POST /api/resources/create
  router.post('/api/resources/create', async ({ req, body, sendJson }) => {
    requireAuth(req);
    const { file_base64: fileBase64, file_extension: fileExtension, ...rest } = body;
    const fileBuffer = fileBase64 ? Buffer.from(fileBase64, 'base64') : null;

    const resource = await resourceLibrary.addResource({
      type: rest.type,
      category: rest.category,
      name: rest.name,
      description: rest.description,
      origin: rest.origin,
      format: rest.format,
      resolution: rest.resolution,
      licenseInfo: rest.license_info,
      tags: rest.tags || [],
      project: rest.project,
      compatibility: rest.compatibility,
      fileBuffer,
      fileExtension,
    });
    sendJson(201, resource);
  });

  // GET /api/library - lista recursos com filtros via query string
  router.get('/api/library', async ({ req, query, sendJson }) => {
    requireAuth(req);
    const results = resourceLibrary.search({
      type: query.type, category: query.category, project: query.project,
      tag: query.tag, text: query.text,
      limit: query.limit ? Number(query.limit) : undefined,
      offset: query.offset ? Number(query.offset) : undefined,
    });
    sendJson(200, results);
  });

  // GET /api/library/:id/file - baixa os bytes reais do recurso (sempre autenticado)
  router.get('/api/library/:id/file', async ({ req, res, params }) => {
    requireAuth(req);
    const resource = resourceLibrary.getResource(params.id);
    if (!resource) throw new ApiError(404, 'NOT_FOUND', `Recurso \"${params.id}\" nao encontrado.`);
    if (!resource.file_path) throw new ApiError(404, 'FILE_NOT_FOUND', 'Este recurso e apenas uma referencia e nao possui arquivo salvo.');
    let buffer;
    try { buffer = resourceLibrary.readResourceFile(params.id); }
    catch (err) { throw new ApiError(404, 'FILE_NOT_FOUND', err.message); }
    const extension = path.extname(resource.file_path).toLowerCase();
    const contentTypes = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.json': 'application/json', '.geojson': 'application/json', '.ogg': 'audio/ogg', '.wav': 'audio/wav', '.mp3': 'audio/mpeg', '.mcmeta': 'application/json', '.txt': 'text/plain; charset=utf-8' };
    res.writeHead(200, {
      'Content-Type': contentTypes[extension] || 'application/octet-stream',
      'Content-Length': buffer.length,
      'Content-Disposition': `attachment; filename=\"${params.id}${extension.replace(/[^.a-z0-9]/g, '')}\"`,
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': 'private, no-store',
    });
    res.end(buffer);
  });

  // GET /api/library/:id
  router.get('/api/library/:id', async ({ req, params, sendJson }) => {
    requireAuth(req);
    const resource = resourceLibrary.getResource(params.id);
    if (!resource) throw new ApiError(404, 'NOT_FOUND', `Recurso "${params.id}" nao encontrado.`);
    sendJson(200, resource);
  });

  // POST /api/sync - sincronizacao com armazenamento remoto (preparado, nao implementado nesta etapa)
  router.post('/api/sync', async ({ req, sendJson }) => {
    requireAuth(req);
    sendJson(501, {
      synced: false,
      message: 'Sincronizacao com armazenamento remoto esta preparada na arquitetura mas ainda nao '
        + 'implementada nesta primeira etapa (ver docs/STATUS.md).',
    });
  });

  return router;
}
