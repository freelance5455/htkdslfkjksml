import {Router} from "express";
import {z} from "zod";
import {db} from "./db";
import {auth,role,AuthReq} from "./middleware";

const r=Router();
const commission=()=>Number(process.env.PLATFORM_COMMISSION_RATE||"0.10");

r.get("/products",async(req,res)=>{
 const products=await db.product.findMany({where:{status:"PUBLISHED"},include:{seller:{select:{id:true,name:true,social:true}}},orderBy:{createdAt:"desc"}});
 res.json(products);
});

r.post("/products",auth,role("SELLER","ADMIN"),async(req:AuthReq,res)=>{
 const v=z.object({name:z.string().min(2).max(160),description:z.string().max(5000),priceUsd:z.number().positive().max(100000),fileKey:z.string().min(1).max(500),imageUrl:z.string().url().optional()}).parse(req.body);
 const p=await db.product.create({data:{...v,priceUsd:v.priceUsd,sellerId:req.user!.id,status:"PUBLISHED"}});
 res.status(201).json(p);
});

/* الخادم يحسب العمولة من السعر الموجود في قاعدة البيانات، وليس من السعر القادم من المتصفح. */
r.post("/orders",async(req,res)=>{
 const v=z.object({buyerEmail:z.string().email(),productIds:z.array(z.string()).min(1).max(50)}).parse(req.body);
 const products=await db.product.findMany({where:{id:{in:v.productIds},status:"PUBLISHED"}});
 if(products.length!==new Set(v.productIds).size)return res.status(400).json({error:"Some products are unavailable"});
 const subtotal=products.reduce((s,p)=>s+Number(p.priceUsd),0);
 const fee=Math.round(subtotal*commission()*100)/100;
 const net=Math.round((subtotal-fee)*100)/100;
 const order=await db.$transaction(async tx=>{
   const o=await tx.order.create({data:{buyerEmail:v.buyerEmail,subtotalUsd:subtotal,platformFeeUsd:fee,sellerNetUsd:net,items:{create:products.map(p=>({productId:p.id,sellerId:p.sellerId,priceUsd:p.priceUsd}))}}});
   /* لا نضيف الرصيد للبائع هنا؛ يضاف فقط من webhook دفع موثوق بعد نجاح الدفع. */
   return o;
 });
 res.status(201).json({orderId:order.id,subtotalUsd:subtotal,platformFeeUsd:fee,sellerNetUsd:net,status:order.status});
});

r.get("/seller/wallet",auth,role("SELLER","ADMIN"),async(req:AuthReq,res)=>{
 const w=await db.wallet.findUnique({where:{userId:req.user!.id}});
 res.json(w||{availableUsd:0,pendingUsd:0});
});

r.post("/seller/withdrawals",auth,role("SELLER"),async(req:AuthReq,res)=>{
 const v=z.object({amountUsd:z.number().positive(),method:z.string().min(2).max(50),destination:z.string().min(3).max(300)}).parse(req.body);
 const w=await db.wallet.findUnique({where:{userId:req.user!.id}});
 if(!w||Number(w.availableUsd)<v.amountUsd)return res.status(400).json({error:"Insufficient available balance"});
 const result=await db.$transaction(async tx=>{
   await tx.wallet.update({where:{userId:req.user!.id},data:{availableUsd:{decrement:v.amountUsd}}});
   return tx.withdrawal.create({data:{sellerId:req.user!.id,amountUsd:v.amountUsd,method:v.method,destination:v.destination}});
 });
 res.status(201).json(result);
});

/* Webhook الدفع الحقيقي يجب أن يتحقق من توقيع مزود الدفع قبل استدعاء هذا المنطق. */
r.post("/payments/webhook",async(req,res)=>{
 // TODO: تحقق من signature الخاص بمزود الدفع، امنع replay، ثم حدّث Order إلى PAID داخل transaction.
 res.status(501).json({error:"Payment provider adapter not configured"});
});
export default r;