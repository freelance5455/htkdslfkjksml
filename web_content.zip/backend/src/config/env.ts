import { z } from 'zod';
import dotenv from 'dotenv';

dotenv.config();

const envSchema = z.object({
  PORT: z.coerce.number().default(4000),
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  DATABASE_URL: z.string().default('postgresql://postgres:postgres@localhost:5432/tempbox?schema=public'),
  REDIS_URL: z.string().default('redis://localhost:6379'),
  JWT_SECRET: z.string().default('tempbox-ultra-secure-jwt-secret-min-32-chars-long-abc123'),
  JWT_REFRESH_SECRET: z.string().default('tempbox-ultra-secure-refresh-jwt-secret-xyz987'),
  ENCRYPTION_KEY: z.string().default('0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef'),
  SMS_PROVIDER: z.enum(['mock', 'twilio', 'telnyx']).default('mock'),
  TWILIO_ACCOUNT_SID: z.string().optional(),
  TWILIO_AUTH_TOKEN: z.string().optional(),
  TELNYX_API_KEY: z.string().optional(),
  MAILGUN_API_KEY: z.string().optional(),
  MAILGUN_WEBHOOK_SIGNING_KEY: z.string().optional(),
  ALLOWED_DOMAINS: z.string().default('tempbox.io,mailshred.org,dispostash.dev'),
  DEFAULT_CREDITS_GUEST: z.coerce.number().default(30),
  MAX_EMAIL_SIZE_BYTES: z.coerce.number().default(10 * 1024 * 1024), // 10MB
  MAX_ATTACHMENTS_SIZE_BYTES: z.coerce.number().default(5 * 1024 * 1024), // 5MB
});

export const env = envSchema.parse(process.env);
export const DOMAINS = env.ALLOWED_DOMAINS.split(',').map(d => d.trim());
