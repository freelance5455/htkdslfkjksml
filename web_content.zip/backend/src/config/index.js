import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const PROJECT_ROOT = path.resolve(__dirname, '..', '..');

/**
 * Carrega um arquivo .env simples (KEY=VALUE por linha) sem dependencias externas.
 * Nao sobrescreve variaveis ja definidas no ambiente real (process.env tem prioridade).
 */
function loadEnvFile(envPath) {
  if (!fs.existsSync(envPath)) return;
  const content = fs.readFileSync(envPath, 'utf-8');
  for (const rawLine of content.split('\n')) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const eqIndex = line.indexOf('=');
    if (eqIndex === -1) continue;
    const key = line.slice(0, eqIndex).trim();
    let value = line.slice(eqIndex + 1).trim();
    // remove aspas envolventes, se houver
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (process.env[key] === undefined) {
      process.env[key] = value;
    }
  }
}

loadEnvFile(path.join(PROJECT_ROOT, '.env'));

function bool(value, fallback) {
  if (value === undefined || value === '') return fallback;
  return value === 'true' || value === '1';
}

export const config = {
  port: Number(process.env.PORT || 4100),
  host: process.env.HOST || '127.0.0.1',

  addonforgeToken: process.env.ADDONFORGE_TOKEN || '',
  corsAllowedOrigins: (process.env.CORS_ALLOWED_ORIGINS || 'null').split(';').map((v) => v.trim()).filter(Boolean),

  databasePath: path.resolve(PROJECT_ROOT, process.env.DATABASE_PATH || './storage/database/adam.db'),
  resourceStoragePath: path.resolve(PROJECT_ROOT, process.env.RESOURCE_STORAGE_PATH || './storage/resources'),

  ai: {
    provider: process.env.AI_PROVIDER || '',
    apiKey: process.env.AI_API_KEY || '',
    model: process.env.AI_MODEL || '',
    get configured() {
      return Boolean(this.provider && this.apiKey);
    },
  },

  webSearch: {
    provider: process.env.WEB_SEARCH_PROVIDER || '',
    apiKey: process.env.WEB_SEARCH_API_KEY || '',
    get configured() {
      // o provedor duckduckgo_html nao exige chave de API
      if (this.provider === 'duckduckgo_html') return true;
      return Boolean(this.provider && this.apiKey);
    },
  },

  researchTimeoutMs: Number(process.env.RESEARCH_TIMEOUT_MS || 15000),
};

export function assertProductionSafety() {
  const warnings = [];
  if (!config.addonforgeToken || config.addonforgeToken === 'troque-este-token-por-um-segredo-forte') {
    warnings.push('ADDONFORGE_TOKEN nao foi configurado com um valor seguro. A API de comunicacao esta vulneravel.');
  }
  return warnings;
}
