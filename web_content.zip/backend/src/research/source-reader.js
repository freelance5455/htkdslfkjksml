const USER_AGENT = 'Mozilla/5.0 (compatible; AdamKnowledgeBot/0.1; +https://adam-knowledge.local)';

/** Erro especifico para falhas de leitura de fonte, usado para nunca fingir sucesso */
export class SourceReadError extends Error {
  constructor(message, { code = 'SOURCE_READ_ERROR', url, cause } = {}) {
    super(message);
    this.name = 'SourceReadError';
    this.code = code;
    this.url = url;
    this.cause = cause;
  }
}

function extractTitle(html) {
  const match = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  return match ? decodeEntities(match[1]).trim() : null;
}

function decodeEntities(str) {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, ' ');
}

/**
 * Extrai o texto "legivel" de uma pagina HTML, removendo script/style/nav/footer
 * e tags, de forma leve (sem um parser DOM completo).
 *
 * Nota de limitacao honesta: esta e uma extracao baseada em regex, suficiente
 * para a maioria de paginas de artigo/documentacao, mas nao substitui um
 * parser DOM real (ex: um parser HTML dedicado) para paginas com estrutura
 * complexa ou fortemente dependente de JavaScript. Documentado como ponto de
 * evolucao futura.
 */
function extractReadableText(html, { maxLength = 8000 } = {}) {
  let text = html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<nav[\s\S]*?<\/nav>/gi, ' ')
    .replace(/<footer[\s\S]*?<\/footer>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|li|h[1-6])>/gi, '\n')
    .replace(/<[^>]+>/g, ' ');

  text = decodeEntities(text);
  text = text.replace(/[ \t]+/g, ' ').replace(/\n{2,}/g, '\n').split('\n').map((l) => l.trim()).filter(Boolean).join('\n');

  if (text.length > maxLength) {
    text = text.slice(0, maxLength) + '\n[... conteudo truncado ...]';
  }
  return text;
}

export class SourceReader {
  constructor({ timeoutMs = 15000 } = {}) {
    this.timeoutMs = timeoutMs;
  }

  /**
   * Acessa uma URL real e retorna titulo + texto extraido.
   * Nunca retorna dados simulados: em caso de falha, lanca SourceReadError.
   */
  async read(url) {
    let parsedUrl;
    try {
      parsedUrl = new URL(url);
    } catch {
      throw new SourceReadError(`URL invalida: "${url}"`, { code: 'INVALID_URL', url });
    }
    if (!['http:', 'https:'].includes(parsedUrl.protocol)) {
      throw new SourceReadError(`Protocolo nao suportado: "${parsedUrl.protocol}"`, { code: 'UNSUPPORTED_PROTOCOL', url });
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const response = await fetch(parsedUrl, {
        headers: { 'User-Agent': USER_AGENT, Accept: 'text/html,application/xhtml+xml' },
        signal: controller.signal,
      });

      if (!response.ok) {
        throw new SourceReadError(
          `A fonte respondeu com status HTTP ${response.status}.`,
          { code: 'HTTP_ERROR', url }
        );
      }

      const contentType = response.headers.get('content-type') || '';
      if (!contentType.includes('text/html') && !contentType.includes('xml') && contentType !== '') {
        throw new SourceReadError(
          `Tipo de conteudo nao suportado para extracao de texto: "${contentType}".`,
          { code: 'UNSUPPORTED_CONTENT_TYPE', url }
        );
      }

      const html = await response.text();
      return {
        url: parsedUrl.toString(),
        title: extractTitle(html),
        text: extractReadableText(html),
        fetchedAt: new Date().toISOString(),
      };
    } catch (err) {
      if (err instanceof SourceReadError) throw err;
      if (err.name === 'AbortError') {
        throw new SourceReadError(
          `Tempo limite (${this.timeoutMs}ms) excedido ao acessar "${url}".`,
          { code: 'TIMEOUT', url, cause: err }
        );
      }
      throw new SourceReadError(`Falha ao acessar a fonte: ${err.message}`, { code: 'NETWORK_ERROR', url, cause: err });
    } finally {
      clearTimeout(timer);
    }
  }
}

export const sourceReader = new SourceReader();
