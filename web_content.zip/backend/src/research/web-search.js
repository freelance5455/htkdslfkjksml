import { config } from '../config/index.js';
import { researchRepository } from '../database/repositories/research-repository.js';
import { sourceReader } from './source-reader.js';
import { DuckDuckGoProvider } from './search-providers/duckduckgo-provider.js';
import { GenericApiProvider } from './search-providers/generic-api-provider.js';
import { SearchProviderError } from './search-providers/provider-interface.js';
import { logger } from '../utils/logger.js';

const STALE_THRESHOLD_DAYS = 365 * 2; // heuristica simples: paginas sem data detectavel nao sao avaliadas

/** Erro usado quando nao ha provedor de pesquisa configurado (nunca simula resultados) */
export class WebResearchNotConfiguredError extends Error {
  constructor() {
    super('Nenhum provedor de pesquisa web esta configurado. Defina WEB_SEARCH_PROVIDER no .env.');
    this.name = 'WebResearchNotConfiguredError';
    this.code = 'WEB_SEARCH_NOT_CONFIGURED';
  }
}

function buildProvider() {
  if (!config.webSearch.configured) return null;

  switch (config.webSearch.provider) {
    case 'duckduckgo_html':
      return new DuckDuckGoProvider({ timeoutMs: config.researchTimeoutMs });
    case 'generic_api':
      return new GenericApiProvider({
        apiKey: config.webSearch.apiKey,
        timeoutMs: config.researchTimeoutMs,
      });
    default:
      return null;
  }
}

/**
 * ADAM WEB RESEARCH ENGINE
 *
 * Fluxo real (nunca simulado):
 *  1. Recebe a query.
 *  2. Consulta o provedor de pesquisa configuravel.
 *  3. Para cada resultado relevante, tenta ler a pagina de verdade.
 *  4. Registra fontes, links originais e marca falhas de acesso quando ocorrem.
 *  5. Persiste tudo no ADAM KNOWLEDGE DATABASE.
 *
 * Se nenhum provedor estiver configurado, informa isso claramente em vez de
 * inventar resultados (requisito explicito da especificacao).
 */
export class WebResearchEngine {
  constructor({ readTopN = 3 } = {}) {
    this.readTopN = readTopN;
  }

  async research(query, { category = null, requestId = null, readPages = true } = {}) {
    const provider = buildProvider();
    const researchQuery = researchRepository.createQuery({ query, category, requestId });

    if (!provider) {
      researchRepository.updateQueryStatus(researchQuery.id, 'failed', 'Nenhum provedor de pesquisa configurado.');
      throw new WebResearchNotConfiguredError();
    }

    researchRepository.updateQueryStatus(researchQuery.id, 'processing');

    let searchResults;
    try {
      searchResults = await provider.search(query, { limit: 10 });
    } catch (err) {
      const message = err instanceof SearchProviderError ? err.message : `Erro inesperado: ${err.message}`;
      researchRepository.updateQueryStatus(researchQuery.id, 'failed', message);
      logger.error(`Pesquisa web falhou para "${query}"`, err);
      throw err;
    }

    if (searchResults.length === 0) {
      researchRepository.updateQueryStatus(researchQuery.id, 'completed');
      return researchRepository.findQueryById(researchQuery.id);
    }

    const toRead = readPages ? searchResults.slice(0, this.readTopN) : [];
    const readUrls = new Set(toRead.map((r) => r.url));

    for (const result of searchResults) {
      if (readUrls.has(result.url)) {
        try {
          const page = await sourceReader.read(result.url);
          researchRepository.addResult(researchQuery.id, {
            sourceUrl: result.url,
            title: page.title || result.title,
            snippet: result.snippet,
            extractedText: page.text,
          });
        } catch (err) {
          // Fonte inacessivel: registramos isso explicitamente, sem fingir conteudo
          logger.warn(`Nao foi possivel acessar a fonte "${result.url}": ${err.message}`);
          researchRepository.addResult(researchQuery.id, {
            sourceUrl: result.url,
            title: result.title,
            snippet: result.snippet,
            extractedText: `[FONTE INACESSIVEL: ${err.message}]`,
          });
        }
      } else {
        researchRepository.addResult(researchQuery.id, {
          sourceUrl: result.url,
          title: result.title,
          snippet: result.snippet,
          extractedText: null,
        });
      }
    }

    researchRepository.updateQueryStatus(researchQuery.id, 'completed');
    return researchRepository.findQueryById(researchQuery.id);
  }
}

export const webResearchEngine = new WebResearchEngine();
