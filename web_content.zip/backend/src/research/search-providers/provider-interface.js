/**
 * Contrato que todo provedor de pesquisa web deve respeitar.
 * Permite trocar o provedor (DuckDuckGo, Bing, Brave, SerpAPI, etc.)
 * sem alterar o restante do sistema.
 *
 * @typedef {object} SearchResult
 * @property {string} url
 * @property {string} title
 * @property {string} snippet
 *
 * @interface SearchProvider
 * @method {(query: string, options?: object) => Promise<SearchResult[]>} search
 */
export class SearchProviderError extends Error {
  constructor(message, { code = 'SEARCH_PROVIDER_ERROR', cause } = {}) {
    super(message);
    this.name = 'SearchProviderError';
    this.code = code;
    this.cause = cause;
  }
}
