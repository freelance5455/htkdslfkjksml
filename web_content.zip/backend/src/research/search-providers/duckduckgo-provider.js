import { SearchProviderError } from './provider-interface.js';

const ENDPOINT = 'https://html.duckduckgo.com/html/';
const USER_AGENT = 'Mozilla/5.0 (compatible; AdamKnowledgeBot/0.1; +https://adam-knowledge.local)';

function decodeEntities(str) {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/<[^>]+>/g, '')
    .trim();
}

/**
 * Provedor de pesquisa que usa a versao HTML (sem JS) da DuckDuckGo.
 * Nao exige chave de API, mas depende da estrutura publica da pagina,
 * que pode mudar sem aviso. Recomendado apenas para desenvolvimento/testes
 * ou uso leve. Para producao, prefira um provedor com API oficial e contrato
 * estavel (ver generic-api-provider.js).
 */
export class DuckDuckGoProvider {
  constructor({ timeoutMs = 15000 } = {}) {
    this.timeoutMs = timeoutMs;
  }

  async search(query, { limit = 10 } = {}) {
    if (!query || !query.trim()) {
      throw new SearchProviderError('Query de pesquisa vazia.', { code: 'EMPTY_QUERY' });
    }

    const url = `${ENDPOINT}?q=${encodeURIComponent(query)}`;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);

    let html;
    try {
      const response = await fetch(url, {
        headers: { 'User-Agent': USER_AGENT },
        signal: controller.signal,
      });
      if (!response.ok) {
        throw new SearchProviderError(
          `DuckDuckGo respondeu com status ${response.status}.`,
          { code: 'HTTP_ERROR' }
        );
      }
      html = await response.text();
    } catch (err) {
      if (err.name === 'AbortError') {
        throw new SearchProviderError(
          `Tempo limite (${this.timeoutMs}ms) excedido ao pesquisar "${query}".`,
          { code: 'TIMEOUT', cause: err }
        );
      }
      throw new SearchProviderError(
        `Falha ao acessar o provedor de pesquisa: ${err.message}`,
        { code: 'NETWORK_ERROR', cause: err }
      );
    } finally {
      clearTimeout(timer);
    }

    return this._parseResults(html, limit);
  }

  _parseResults(html, limit) {
    const results = [];
    // Estrutura conhecida do html.duckduckgo.com: cada resultado tem um link
    // com classe "result__a" e um snippet com classe "result__snippet".
    const resultBlockRegex = /<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)<\/a>[\s\S]*?(?:<a[^>]*class="result__snippet"[^>]*>(.*?)<\/a>)?/g;

    let match;
    while ((match = resultBlockRegex.exec(html)) !== null && results.length < limit) {
      const rawUrl = match[1];
      const title = decodeEntities(match[2] || '');
      const snippet = decodeEntities(match[3] || '');

      const resolvedUrl = this._resolveRedirectUrl(rawUrl);
      if (!resolvedUrl || !title) continue;

      results.push({ url: resolvedUrl, title, snippet });
    }

    return results;
  }

  /** O DuckDuckGo HTML usa links de redirecionamento (/l/?uddg=<url-encoded>) */
  _resolveRedirectUrl(rawUrl) {
    try {
      if (rawUrl.startsWith('//')) rawUrl = `https:${rawUrl}`;
      const parsed = new URL(rawUrl, 'https://duckduckgo.com');
      const uddg = parsed.searchParams.get('uddg');
      if (uddg) return decodeURIComponent(uddg);
      return parsed.toString();
    } catch {
      return null;
    }
  }
}
