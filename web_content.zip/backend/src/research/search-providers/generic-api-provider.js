import { SearchProviderError } from './provider-interface.js';

/**
 * Provedor de pesquisa baseado em uma API oficial com chave de autenticacao
 * (modelo compativel com Brave Search API, Bing Web Search, SerpAPI, etc).
 * Este e o caminho recomendado para producao: contrato estavel, sem
 * dependencia da estrutura de HTML de terceiros.
 *
 * Configuracao necessaria (.env):
 *   WEB_SEARCH_PROVIDER=generic_api
 *   WEB_SEARCH_API_KEY=<sua-chave>
 *   WEB_SEARCH_API_ENDPOINT=<endpoint-do-provedor>
 *
 * O formato exato de request/response varia por provedor. Esta classe
 * implementa o formato da Brave Search API como exemplo de referencia;
 * ajuste `_buildRequest` e `_parseResponse` para o provedor escolhido.
 */
export class GenericApiProvider {
  constructor({ apiKey, endpoint = 'https://api.search.brave.com/res/v1/web/search', timeoutMs = 15000 }) {
    if (!apiKey) {
      throw new SearchProviderError(
        'GenericApiProvider requer uma WEB_SEARCH_API_KEY configurada.',
        { code: 'MISSING_API_KEY' }
      );
    }
    this.apiKey = apiKey;
    this.endpoint = endpoint;
    this.timeoutMs = timeoutMs;
  }

  async search(query, { limit = 10 } = {}) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const url = new URL(this.endpoint);
      url.searchParams.set('q', query);
      url.searchParams.set('count', String(limit));

      const response = await fetch(url, {
        headers: {
          Accept: 'application/json',
          'X-Subscription-Token': this.apiKey,
        },
        signal: controller.signal,
      });

      if (!response.ok) {
        throw new SearchProviderError(
          `Provedor de pesquisa respondeu com status ${response.status}.`,
          { code: 'HTTP_ERROR' }
        );
      }

      const data = await response.json();
      return this._parseResponse(data, limit);
    } catch (err) {
      if (err instanceof SearchProviderError) throw err;
      if (err.name === 'AbortError') {
        throw new SearchProviderError(
          `Tempo limite (${this.timeoutMs}ms) excedido ao pesquisar "${query}".`,
          { code: 'TIMEOUT', cause: err }
        );
      }
      throw new SearchProviderError(`Falha ao acessar o provedor de pesquisa: ${err.message}`, {
        code: 'NETWORK_ERROR',
        cause: err,
      });
    } finally {
      clearTimeout(timer);
    }
  }

  _parseResponse(data, limit) {
    const items = data?.web?.results || [];
    return items.slice(0, limit).map((item) => ({
      url: item.url,
      title: item.title,
      snippet: item.description || '',
    }));
  }
}
