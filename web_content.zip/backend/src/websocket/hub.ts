import { WebSocket } from 'ws';

export interface WsClient {
  socket: any;
  userId: string;
  mailboxIds: Set<string>;
  phoneNumberIds: Set<string>;
}

class WebSocketHub {
  private clients = new Map<string, Set<WsClient>>();

  public registerClient(userId: string, socket: any): WsClient {
    const client: WsClient = {
      socket,
      userId,
      mailboxIds: new Set(),
      phoneNumberIds: new Set(),
    };

    if (!this.clients.has(userId)) {
      this.clients.set(userId, new Set());
    }
    this.clients.get(userId)!.add(client);

    socket.on('close', () => {
      this.clients.get(userId)?.delete(client);
      if (this.clients.get(userId)?.size === 0) {
        this.clients.delete(userId);
      }
    });

    return client;
  }

  public broadcastToUser(userId: string, event: string, data: any) {
    const userClients = this.clients.get(userId);
    if (!userClients) return;

    const payload = JSON.stringify({ event, data, timestamp: new Date().toISOString() });
    for (const client of userClients) {
      if (client.socket.readyState === 1 /* OPEN */) {
        client.socket.send(payload);
      }
    }
  }

  public notifyNewEmail(userId: string, mailboxId: string, message: any) {
    this.broadcastToUser(userId, 'new_message', { mailboxId, message });
  }

  public notifyNewSms(userId: string, phoneNumberId: string, sms: any) {
    this.broadcastToUser(userId, 'new_sms', { phoneNumberId, sms });
  }
}

export const wsHub = new WebSocketHub();
