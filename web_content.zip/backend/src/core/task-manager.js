import { EventEmitter } from 'node:events';
import { taskRepository } from '../database/repositories/task-repository.js';
import { logger } from '../utils/logger.js';

const DEFAULT_CONCURRENCY = 4;
const DEFAULT_MAX_ATTEMPTS = 2;

/**
 * ADAM TASK ENGINE
 *
 * Fila de tarefas assincrona com:
 * - limite de processamento simultaneo (concorrencia)
 * - estados reais persistidos: queued, processing, completed, failed, cancelled
 * - cancelamento cooperativo
 * - retentativas controladas em caso de falha
 *
 * Nao promete velocidade instantanea: tarefas que dependem de rede
 * (pesquisa web, leitura de paginas) sao genuinamente assincronas.
 */
export class TaskManager extends EventEmitter {
  constructor({ concurrency = DEFAULT_CONCURRENCY, maxAttempts = DEFAULT_MAX_ATTEMPTS } = {}) {
    super();
    this.concurrency = concurrency;
    this.maxAttempts = maxAttempts;
    this.handlers = new Map(); // type -> handler(task) => Promise<result>
    this.active = new Set(); // task ids em processamento
    this.cancelled = new Set(); // task ids com cancelamento solicitado
    this.pendingQueue = []; // fila em memoria com task ids aguardando slot
    this.draining = false;
    this.recoveryPrepared = false;
  }

  /** Registra um handler responsavel por executar tarefas de um certo tipo */
  registerHandler(type, handlerFn) {
    this.handlers.set(type, handlerFn);
    if (this.recoveryPrepared) this.recoverPendingTasks();
  }

  /**
   * Recoloca tarefas interrompidas na fila apos migrations e registro dos handlers.
   * Chamado explicitamente na inicializacao do servidor para nao acessar o banco
   * antes de as migrations serem aplicadas.
   */
  recoverPendingTasks() {
    if (!this.recoveryPrepared) {
      const recovery = taskRepository.recoverInterrupted(this.maxAttempts);
      this.recoveryPrepared = true;
      logger.info('Recuperacao de tarefas apos reinicializacao', recovery);
    }
    const known = new Set(this.pendingQueue);
    const queued = taskRepository.listByStatus('queued', 10000);
    for (const task of queued) {
      if (this.handlers.has(task.type) && !known.has(task.id)) {
        this.pendingQueue.push(task.id);
        known.add(task.id);
      }
    }
    this._drain();
    return { queuedForResume: this.pendingQueue.length };
  }

  /** Cria e enfileira uma nova tarefa. Retorna o registro persistido da tarefa. */
  enqueue({ type, payload = {}, parentRequestId = null }) {
    if (!this.handlers.has(type)) {
      throw new Error(`Nenhum handler registrado para o tipo de tarefa "${type}".`);
    }
    const task = taskRepository.create({ type, payload, parentRequestId });
    this.pendingQueue.push(task.id);
    this.emit('task:queued', task);
    this._drain();
    return task;
  }

  /** Solicita cancelamento cooperativo de uma tarefa (antes ou durante execucao) */
  cancel(taskId) {
    const task = taskRepository.findById(taskId);
    if (!task) return null;
    if (task.status === 'completed' || task.status === 'failed') return task;

    this.cancelled.add(taskId);
    if (!this.active.has(taskId)) {
      // ainda nao comecou: cancela imediatamente
      const updated = taskRepository.updateStatus(taskId, 'cancelled');
      this.pendingQueue = this.pendingQueue.filter((id) => id !== taskId);
      this.emit('task:cancelled', updated);
      return updated;
    }
    // se ja estiver processando, o handler deve checar isCancelled() cooperativamente
    return task;
  }

  isCancelled(taskId) {
    return this.cancelled.has(taskId);
  }

  getTask(taskId) {
    return taskRepository.findById(taskId);
  }

  getTasksByRequest(parentRequestId) {
    return taskRepository.findByParentRequest(parentRequestId);
  }

  getStats() {
    return {
      ...taskRepository.countByStatus(),
      activeNow: this.active.size,
      queuedInMemory: this.pendingQueue.length,
      concurrencyLimit: this.concurrency,
    };
  }

  /** Processa a fila respeitando o limite de concorrencia */
  _drain() {
    if (this.draining) return;
    this.draining = true;
    queueMicrotask(() => this._drainLoop());
  }

  async _drainLoop() {
    while (this.pendingQueue.length > 0 && this.active.size < this.concurrency) {
      const taskId = this.pendingQueue.shift();
      this._runTask(taskId); // intencionalmente nao aguardado (execucao paralela)
    }
    this.draining = false;
  }

  async _runTask(taskId) {
    this.active.add(taskId);
    const task = taskRepository.findById(taskId);

    if (!task || this.cancelled.has(taskId)) {
      this.active.delete(taskId);
      this.cancelled.delete(taskId);
      this._drain();
      return;
    }

    taskRepository.updateStatus(taskId, 'processing');
    taskRepository.incrementAttempts(taskId);
    this.emit('task:processing', { ...task, status: 'processing' });

    const handler = this.handlers.get(task.type);
    try {
      const result = await handler(task, { isCancelled: () => this.isCancelled(taskId) });

      if (this.isCancelled(taskId)) {
        const updated = taskRepository.updateStatus(taskId, 'cancelled');
        this.emit('task:cancelled', updated);
      } else {
        const updated = taskRepository.updateStatus(taskId, 'completed', { result });
        this.emit('task:completed', updated);
      }
    } catch (err) {
      logger.error(`Falha ao processar tarefa ${taskId} (${task.type})`, err);
      const current = taskRepository.findById(taskId);
      if (current.attempts < this.maxAttempts && !this.isCancelled(taskId)) {
        logger.warn(`Reagendando tarefa ${taskId} para nova tentativa (${current.attempts}/${this.maxAttempts})`);
        taskRepository.updateStatus(taskId, 'queued', { error: err.message });
        this.pendingQueue.push(taskId);
      } else {
        const updated = taskRepository.updateStatus(taskId, 'failed', { error: err.message });
        this.emit('task:failed', updated);
      }
    } finally {
      this.active.delete(taskId);
      this.cancelled.delete(taskId);
      this._drain();
    }
  }
}

// Instancia singleton compartilhada pela aplicacao
export const taskManager = new TaskManager();
