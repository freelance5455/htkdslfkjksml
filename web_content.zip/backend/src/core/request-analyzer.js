/**
 * ADAM KNOWLEDGE - Request Analyzer
 *
 * Interpreta uma solicitacao em linguagem natural (ou um pedido estruturado
 * vindo do AddonForge) e decide quais modulos devem ser acionados e em que
 * subtarefas o pedido deve ser dividido.
 *
 * Esta e uma implementacao real baseada em regras e palavras-chave (nao uma
 * IA generativa). Ela funciona de verdade para os casos descritos na
 * especificacao, mas e deliberadamente simples: o ponto de extensao
 * `aiProvider` permite plugar um modelo de linguagem real futuramente para
 * uma interpretacao mais sofisticada, sem mudar o contrato de saida.
 */

const IMAGE_KEYWORDS = ['foto', 'fotografia', 'imagem', 'imagens', 'referência visual', 'referencia visual', 'textura', 'texturas'];
const MATERIAL_ANALYSIS_KEYWORDS = ['padrão', 'padrao', 'padrões', 'padroes', 'cor', 'cores', 'material', 'analis'];
const DOCUMENTATION_KEYWORDS = ['documentação', 'documentacao', 'api', 'bedrock', 'formato', 'especificação técnica', 'especificacao tecnica'];
const RESOURCE_CATEGORY_MAP = {
  textura: 'texture', texturas: 'texture',
  modelo: 'model', modelos: 'model', '3d': 'model',
  animação: 'animation', animacao: 'animation', animações: 'animation', animacoes: 'animation',
  som: 'sound', sons: 'sound', sonoro: 'sound', sonora: 'sound', sonoros: 'sound', sonoras: 'sound',
  áudio: 'sound', audio: 'sound',
  documentação: 'documentation', documentacao: 'documentation',
};

/**
 * Extrai palavras (tokens) do texto, ignorando pontuacao e case.
 * Usamos correspondencia por TOKEN INTEIRO (nao substring) para evitar falsos
 * positivos como a palavra-chave "api" combinando com "capital".
 */
function tokenize(text) {
  return text.toLowerCase().match(/\p{L}+/gu) || [];
}

function containsAny(text, keywords) {
  const tokens = tokenize(text);
  const lower = text.toLowerCase();
  return keywords.some((kw) => (kw.includes(' ') ? lower.includes(kw) : tokens.includes(kw)));
}

function detectResourceCategory(text) {
  const tokens = tokenize(text);
  for (const [word, category] of Object.entries(RESOURCE_CATEGORY_MAP)) {
    if (tokens.includes(word)) return category;
  }
  return null;
}

export class RequestAnalyzer {
  /**
   * @param {string} query - texto em linguagem natural do pedido
   * @param {object} [explicitRequirements] - requisitos ja estruturados (ex: vindos do AddonForge)
   * @returns {{ intent: string, resourceCategory: string|null, subtasks: Array<{type:string, payload:object}> }}
   */
  analyze(query, explicitRequirements = {}) {
    if (!query || typeof query !== 'string' || !query.trim()) {
      throw new Error('O campo "query" e obrigatorio e deve ser uma string nao vazia.');
    }

    const subtasks = [];
    const resourceCategory = detectResourceCategory(query);

    const wantsImages = explicitRequirements.find_images ?? containsAny(query, IMAGE_KEYWORDS);
    const wantsMaterialAnalysis = explicitRequirements.analyze_material ?? containsAny(query, MATERIAL_ANALYSIS_KEYWORDS);
    const wantsDocumentation = explicitRequirements.find_documentation ?? containsAny(query, DOCUMENTATION_KEYWORDS);

    // 1. Pesquisa textual de base é sempre a primeira subtarefa
    subtasks.push({ type: 'research.web_search', payload: { query } });

    // 2. Pesquisa de imagens, se aplicavel
    if (wantsImages) {
      subtasks.push({ type: 'research.image_search', payload: { query, category: resourceCategory } });
    }

    // 3. Analise de material/padroes visuais, se aplicavel (depende dos resultados anteriores)
    if (wantsMaterialAnalysis) {
      subtasks.push({ type: 'research.material_analysis', payload: { query } });
    }

    // 4. Documentacao tecnica, se aplicavel
    if (wantsDocumentation) {
      subtasks.push({ type: 'research.documentation_search', payload: { query } });
    }

    // A organizacao/compilacao final dos resultados (item 7 da especificacao)
    // NAO e enfileirada como uma tarefa paralela: ela e feita pelo proprio
    // IntelligenceOrchestrator em getRequestStatus(), somente depois que todas
    // as subtarefas acima realmente terminarem. Enfileirar como tarefa paralela
    // criaria uma condicao de corrida (compilaria resultados ainda incompletos).

    const intent = resourceCategory ? `create_resource_reference:${resourceCategory}` : 'general_research';

    return { intent, resourceCategory, subtasks };
  }
}

export const requestAnalyzer = new RequestAnalyzer();
