import { randomUUID } from 'node:crypto';
import { config } from '../config/index.js';
import { requestAnalyzer } from './request-analyzer.js';
import { taskManager } from './task-manager.js';
import { webResearchEngine, WebResearchNotConfiguredError } from '../research/web-search.js';
import { resourceLibrary } from '../resources/resource-library.js';
import { logger } from '../utils/logger.js';

/**
 * ADAM KNOWLEDGE CORE
 *
 * Responsabilidades (conforme especificacao, secao 5):
 *  1. Receber solicitacoes.
 *  2. Identificar a intencao do usuario (via RequestAnalyzer).
 *  3. Determinar o tipo de pesquisa necessaria.
 *  4. Escolher os modulos adequados.
 *  5. Distribuir tarefas (via TaskManager).
 *  6. Acompanhar o processamento.
 *  7. Organizar resultados.
 *  8. Verificar a qualidade das informacoes (fontes inacessiveis sao marcadas).
 *  9. Salvar os resultados importantes (ja feito pelos repositories).
 *  10. Entregar respostas estruturadas.
 *
 * A integracao com um provedor real de IA generativa e um ponto de extensao
 * explicito (`callAiProvider`): se nao configurado, o sistema informa a
 * limitacao claramente, como exige a especificacao, em vez de simular.
 */
export class IntelligenceOrchestrator {
  constructor() {
    this._registerHandlers();
  }

  _registerHandlers() {
    taskManager.registerHandler('research.web_search', async (task) => {
      const { query } = task.payload;
      const result = await webResearchEngine.research(query, { requestId: task.parent_request_id });
      return { researchQueryId: result.id, resultsCount: result.results.length };
    });

    taskManager.registerHandler('research.image_search', async (task) => {
      // Reaproveita o mesmo motor de pesquisa, mas documentado como ponto de
      // evolucao: a especificacao (secao 7) preve um ADAM IMAGE RESEARCH
      // dedicado para provedores de busca de imagem especificos. Por ora,
      // registramos a necessidade e devolvemos status honesto.
      return {
        note: 'Pesquisa de imagens dedicada ainda nao implementada nesta etapa. '
          + 'A pesquisa textual ja localiza paginas que podem conter imagens de referencia.',
        category: task.payload.category,
      };
    });

    taskManager.registerHandler('research.material_analysis', async () => {
      return {
        note: 'Analise automatizada de padroes visuais/materiais depende de um motor '
          + 'generativo de visao computacional, previsto para a segunda etapa do projeto.',
      };
    });

    taskManager.registerHandler('research.documentation_search', async (task) => {
      const { query } = task.payload;
      const result = await webResearchEngine.research(`${query} documentação técnica`, {
        requestId: task.parent_request_id,
      });
      return { researchQueryId: result.id, resultsCount: result.results.length };
    });

  }

  /**
   * Processa uma solicitacao completa de pesquisa/conhecimento.
   * @param {string} query
   * @param {object} [requirements] - requisitos explicitos (ex: vindos do AddonForge)
   * @returns {{ requestId: string, intent: string, tasks: Array }}
   */
  async processRequest(query, requirements = {}) {
    const requestId = requirements.requestId || randomUUID();
    const analysis = requestAnalyzer.analyze(query, requirements);

    logger.info('Nova solicitacao recebida pelo ADAM KNOWLEDGE CORE', {
      requestId, intent: analysis.intent, subtaskCount: analysis.subtasks.length,
    });

    const tasks = analysis.subtasks.map((subtask) =>
      taskManager.enqueue({ type: subtask.type, payload: subtask.payload, parentRequestId: requestId })
    );

    return { requestId, intent: analysis.intent, resourceCategory: analysis.resourceCategory, tasks };
  }

  /**
   * Consulta o estado atual de uma solicitacao. So produz o resultado
   * "compilado" (item 7 da especificacao: organizar resultados) depois que
   * TODAS as subtarefas realmente terminaram — nunca compila um resultado
   * parcial como se fosse final.
   */
  getRequestStatus(requestId) {
    const tasks = taskManager.getTasksByRequest(requestId);
    if (tasks.length === 0) return null;

    const allDone = tasks.every((t) => ['completed', 'failed', 'cancelled'].includes(t.status));
    const anyFailed = tasks.some((t) => t.status === 'failed');
    const status = !allDone ? 'processing' : (anyFailed ? 'completed_with_errors' : 'completed');

    const taskSummaries = tasks.map((t) => ({
      id: t.id, type: t.type, status: t.status, result: t.result, error: t.error,
    }));

    return {
      requestId,
      status,
      tasks: taskSummaries,
      compiledResult: allDone ? this._compileResults(taskSummaries) : null,
    };
  }

  /** Organiza os resultados das subtarefas concluidas em uma resposta estruturada unica */
  _compileResults(taskSummaries) {
    const successful = taskSummaries.filter((t) => t.status === 'completed');
    const failed = taskSummaries.filter((t) => t.status === 'failed');
    return {
      summary: `${successful.length} de ${taskSummaries.length} subtarefa(s) concluida(s) com sucesso.`,
      successful: successful.map((t) => ({ type: t.type, result: t.result })),
      failed: failed.map((t) => ({ type: t.type, error: t.error })),
    };
  }

  /**
   * Ponto de extensao para um provedor de IA generativa real.
   * Nunca inventa respostas: se nao configurado, retorna um status explicito.
   */
  async callAiProvider(prompt) {
    if (!config.ai.configured) {
      return {
        available: false,
        message: 'Nenhum provedor de IA esta configurado (AI_PROVIDER/AI_API_KEY ausentes). '
          + 'Configure um provedor real no .env para habilitar este recurso.',
      };
    }
    // Implementacao real de chamada ao provedor configurado seria feita aqui,
    // mantendo a credencial exclusivamente no servidor (nunca no cliente/APK).
    throw new Error(`Integracao com o provedor de IA "${config.ai.provider}" ainda nao implementada nesta etapa.`);
  }
}

export const intelligenceOrchestrator = new IntelligenceOrchestrator();
