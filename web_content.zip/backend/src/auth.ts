import {Router} from "express";
import {z} from "zod";
import argon2 from "argon2";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import {db} from "./db";

const r=Router();
const accessSecret=()=>process.env.JWT_ACCESS_SECRET||"DEV_ONLY_CHANGE_ME";
const refreshSecret=()=>process.env.JWT_REFRESH_SECRET||"DEV_ONLY_CHANGE_ME_2";
const signAccess=(id:string,role:string)=>jwt.sign({sub:id,role},accessSecret(),{expiresIn:"15m"});
const hashToken=(s:string)=>crypto.createHash("sha256").update(s).digest("hex");

r.post("/register",async(req,res)=>{
 const v=z.object({name:z.string().min(2).max(80),email:z.string().email().max(200),password:z.string().min(8).max(128),seller:z.boolean().default(false)}).parse(req.body);
 const email=v.email.toLowerCase();
 if(await db.user.findUnique({where:{email}})) return res.status(409).json({error:"Email already registered"});
 const user=await db.user.create({data:{name:v.name,email,passwordHash:await argon2.hash(v.password),role:v.seller?"SELLER":"USER",wallet:v.seller?{create:{}}:undefined}});
 res.status(201).json({id:user.id,email:user.email,name:user.name,role:user.role});
});

r.post("/login",async(req,res)=>{
 const v=z.object({email:z.string().email(),password:z.string()}).parse(req.body);
 const user=await db.user.findUnique({where:{email:v.email.toLowerCase()}});
 if(!user || !(await argon2.verify(user.passwordHash,v.password))) return res.status(401).json({error:"Invalid credentials"});
 const raw=crypto.randomBytes(48).toString("base64url");
 await db.refreshToken.create({data:{tokenHash:hashToken(raw),userId:user.id,expiresAt:new Date(Date.now()+30*86400000)}});
 res.cookie("refresh_token",raw,{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"strict",maxAge:30*86400000});
 res.json({accessToken:signAccess(user.id,user.role),user:{id:user.id,name:user.name,email:user.email,role:user.role}});
});

r.post("/refresh",async(req,res)=>{
 const raw=req.cookies?.refresh_token;if(!raw)return res.status(401).json({error:"No refresh token"});
 const row=await db.refreshToken.findUnique({where:{tokenHash:hashToken(raw)},include:{user:true}});
 if(!row||row.expiresAt<new Date())return res.status(401).json({error:"Invalid refresh token"});
 res.json({accessToken:signAccess(row.user.id,row.user.role)});
});

r.post("/logout",async(req,res)=>{
 const raw=req.cookies?.refresh_token;if(raw)await db.refreshToken.deleteMany({where:{tokenHash:hashToken(raw)}});
 res.clearCookie("refresh_token");res.json({ok:true});
});
export default r;