const MAX_RECENT_ERRORS = 100;
const recentErrors = [];

function timestamp() {
  return new Date().toISOString();
}

export const logger = {
  info(message, meta = {}) {
    console.log(`[${timestamp()}] [INFO] ${message}`, Object.keys(meta).length ? meta : '');
  },
  warn(message, meta = {}) {
    console.warn(`[${timestamp()}] [WARN] ${message}`, Object.keys(meta).length ? meta : '');
  },
  error(message, error, meta = {}) {
    const entry = {
      timestamp: timestamp(),
      message,
      error: error ? (error.stack || error.message || String(error)) : undefined,
      meta,
    };
    recentErrors.unshift(entry);
    if (recentErrors.length > MAX_RECENT_ERRORS) recentErrors.pop();
    console.error(`[${entry.timestamp}] [ERROR] ${message}`, entry.error || '', Object.keys(meta).length ? meta : '');
  },
  getRecentErrors(limit = 10) {
    return recentErrors.slice(0, limit);
  },
};
