import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { getDatabase } from './db.js';
import { logger } from '../utils/logger.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const MIGRATIONS_DIR = path.join(__dirname, 'migrations');

/**
 * Aplica todas as migrations pendentes, em ordem alfabetica, registrando
 * cada uma na tabela schema_migrations para nunca reaplicar a mesma migration.
 */
export function runMigrations() {
  const db = getDatabase();

  // A propria tabela de controle precisa existir antes de checarmos o que ja rodou
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      applied_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  const files = fs.readdirSync(MIGRATIONS_DIR)
    .filter((f) => f.endsWith('.sql'))
    .sort();

  const already = new Set(
    db.prepare('SELECT name FROM schema_migrations').all().map((r) => r.name)
  );

  const applied = [];
  for (const file of files) {
    if (already.has(file)) continue;
    const sql = fs.readFileSync(path.join(MIGRATIONS_DIR, file), 'utf-8');
    logger.info(`Aplicando migration: ${file}`);
    db.exec(sql);
    db.prepare('INSERT INTO schema_migrations (name) VALUES (?)').run(file);
    applied.push(file);
  }

  if (applied.length === 0) {
    logger.info('Nenhuma migration pendente. Banco ja esta atualizado.');
  } else {
    logger.info(`Migrations aplicadas com sucesso: ${applied.join(', ')}`);
  }

  return applied;
}

// Permite rodar via `npm run migrate`
if (import.meta.url === `file://${process.argv[1]}`) {
  runMigrations();
}
