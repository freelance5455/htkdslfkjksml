-- ADAM KNOWLEDGE DATABASE - migration 001: fundacao do schema

CREATE TABLE IF NOT EXISTS schema_migrations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  applied_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Tarefas do ADAM TASK ENGINE
CREATE TABLE IF NOT EXISTS tasks (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'queued'
    CHECK (status IN ('queued', 'processing', 'completed', 'failed', 'cancelled')),
  payload_json TEXT NOT NULL DEFAULT '{}',
  result_json TEXT,
  error TEXT,
  attempts INTEGER NOT NULL DEFAULT 0,
  parent_request_id TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_parent_request ON tasks(parent_request_id);

-- Pesquisas realizadas pelo ADAM WEB RESEARCH ENGINE
CREATE TABLE IF NOT EXISTS research_queries (
  id TEXT PRIMARY KEY,
  request_id TEXT,
  query TEXT NOT NULL,
  category TEXT,
  status TEXT NOT NULL DEFAULT 'queued'
    CHECK (status IN ('queued', 'processing', 'completed', 'failed', 'cancelled')),
  error TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_research_queries_request ON research_queries(request_id);

-- Resultados individuais de uma pesquisa (fontes, links, texto extraido)
CREATE TABLE IF NOT EXISTS research_results (
  id TEXT PRIMARY KEY,
  query_id TEXT NOT NULL REFERENCES research_queries(id) ON DELETE CASCADE,
  source_url TEXT NOT NULL,
  title TEXT,
  snippet TEXT,
  extracted_text TEXT,
  is_stale INTEGER NOT NULL DEFAULT 0,
  fetched_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_research_results_query ON research_results(query_id);

-- ADAM RESOURCE LIBRARY: texturas, modelos, animacoes, sons, documentacao
CREATE TABLE IF NOT EXISTS resources (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL
    CHECK (type IN ('texture', 'model', 'animation', 'sound', 'documentation')),
  category TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  origin TEXT,
  file_path TEXT,
  format TEXT,
  resolution TEXT,
  license_info TEXT,
  tags_json TEXT NOT NULL DEFAULT '[]',
  project TEXT,
  compatibility TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_resources_type ON resources(type);
CREATE INDEX IF NOT EXISTS idx_resources_category ON resources(category);
CREATE INDEX IF NOT EXISTS idx_resources_project ON resources(project);

-- Solicitacoes recebidas via ADAM ADDONFORGE BRIDGE
CREATE TABLE IF NOT EXISTS addonforge_requests (
  id TEXT PRIMARY KEY,
  request_id TEXT NOT NULL UNIQUE,
  type TEXT NOT NULL,
  category TEXT,
  query TEXT,
  requirements_json TEXT NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'queued'
    CHECK (status IN ('queued', 'processing', 'completed', 'failed', 'cancelled')),
  response_json TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_addonforge_requests_status ON addonforge_requests(status);
