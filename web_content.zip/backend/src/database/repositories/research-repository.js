import { randomUUID } from 'node:crypto';
import { getDatabase } from '../db.js';

export const researchRepository = {
  createQuery({ query, category = null, requestId = null }) {
    const db = getDatabase();
    const id = randomUUID();
    db.prepare(`
      INSERT INTO research_queries (id, request_id, query, category, status)
      VALUES (?, ?, ?, ?, 'queued')
    `).run(id, requestId, query, category);
    return this.findQueryById(id);
  },

  findQueryById(id) {
    const db = getDatabase();
    const row = db.prepare('SELECT * FROM research_queries WHERE id = ?').get(id);
    if (!row) return null;
    const results = this.listResults(id);
    return { ...row, results };
  },

  updateQueryStatus(id, status, error = null) {
    const db = getDatabase();
    db.prepare(`
      UPDATE research_queries SET status = ?, error = ?, updated_at = datetime('now') WHERE id = ?
    `).run(status, error, id);
    return this.findQueryById(id);
  },

  addResult(queryId, { sourceUrl, title = null, snippet = null, extractedText = null, isStale = false }) {
    const db = getDatabase();
    const id = randomUUID();
    db.prepare(`
      INSERT INTO research_results (id, query_id, source_url, title, snippet, extracted_text, is_stale, fetched_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `).run(id, queryId, sourceUrl, title, snippet, extractedText, isStale ? 1 : 0);
    return id;
  },

  listResults(queryId) {
    const db = getDatabase();
    return db.prepare('SELECT * FROM research_results WHERE query_id = ? ORDER BY created_at ASC').all(queryId);
  },

  listRecentQueries(limit = 20) {
    const db = getDatabase();
    return db.prepare('SELECT * FROM research_queries ORDER BY created_at DESC LIMIT ?').all(limit);
  },
};
