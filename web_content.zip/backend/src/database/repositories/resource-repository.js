import { randomUUID } from 'node:crypto';
import { getDatabase } from '../db.js';

const VALID_TYPES = ['texture', 'model', 'animation', 'sound', 'documentation'];

/** Erro de validacao de entrada do usuario (deve virar HTTP 400, nunca 500) */
export class ResourceValidationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'ResourceValidationError';
  }
}

export const resourceRepository = {
  create({
    type, category, name, description = null, origin = null, filePath = null,
    format = null, resolution = null, licenseInfo = null, tags = [], project = null,
    compatibility = null,
  }) {
    if (!VALID_TYPES.includes(type)) {
      throw new ResourceValidationError(`Tipo de recurso invalido: "${type}". Tipos validos: ${VALID_TYPES.join(', ')}`);
    }
    if (!category || !name) {
      throw new ResourceValidationError('Os campos "category" e "name" sao obrigatorios para um recurso.');
    }

    const db = getDatabase();
    const id = randomUUID();
    db.prepare(`
      INSERT INTO resources (
        id, type, category, name, description, origin, file_path, format,
        resolution, license_info, tags_json, project, compatibility
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id, type, category, name, description, origin, filePath, format,
      resolution, licenseInfo, JSON.stringify(tags), project, compatibility
    );
    return this.findById(id);
  },

  findById(id) {
    const db = getDatabase();
    const row = db.prepare('SELECT * FROM resources WHERE id = ?').get(id);
    return row ? deserialize(row) : null;
  },

  search({ type, category, project, tag, text, limit = 50, offset = 0 } = {}) {
    const db = getDatabase();
    const clauses = [];
    const params = [];

    if (type) { clauses.push('type = ?'); params.push(type); }
    if (category) { clauses.push('category = ?'); params.push(category); }
    if (project) { clauses.push('project = ?'); params.push(project); }
    if (tag) { clauses.push('tags_json LIKE ?'); params.push(`%"${tag}"%`); }
    if (text) { clauses.push('(name LIKE ? OR description LIKE ?)'); params.push(`%${text}%`, `%${text}%`); }

    const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
    const rows = db.prepare(`
      SELECT * FROM resources ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?
    `).all(...params, limit, offset);

    const totalRow = db.prepare(`SELECT COUNT(*) as count FROM resources ${where}`).get(...params);

    return { items: rows.map(deserialize), total: totalRow.count };
  },

  update(id, fields) {
    const db = getDatabase();
    const existing = this.findById(id);
    if (!existing) return null;

    const allowed = ['description', 'origin', 'file_path', 'format', 'resolution', 'license_info', 'project', 'compatibility'];
    const sets = [];
    const params = [];
    for (const key of allowed) {
      const camel = key.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
      if (fields[camel] !== undefined) {
        sets.push(`${key} = ?`);
        params.push(fields[camel]);
      }
    }
    if (fields.tags !== undefined) {
      sets.push('tags_json = ?');
      params.push(JSON.stringify(fields.tags));
    }
    if (sets.length === 0) return existing;

    sets.push(`updated_at = datetime('now')`);
    params.push(id);
    db.prepare(`UPDATE resources SET ${sets.join(', ')} WHERE id = ?`).run(...params);
    return this.findById(id);
  },

  delete(id) {
    const db = getDatabase();
    const result = db.prepare('DELETE FROM resources WHERE id = ?').run(id);
    return result.changes > 0;
  },

  countByType() {
    const db = getDatabase();
    const rows = db.prepare('SELECT type, COUNT(*) as count FROM resources GROUP BY type').all();
    const result = { texture: 0, model: 0, animation: 0, sound: 0, documentation: 0 };
    for (const row of rows) result[row.type] = row.count;
    return result;
  },
};

function deserialize(row) {
  return {
    ...row,
    tags: safeParse(row.tags_json, []),
  };
}

function safeParse(json, fallback) {
  try {
    return JSON.parse(json);
  } catch {
    return fallback;
  }
}

export { VALID_TYPES as VALID_RESOURCE_TYPES };
