import { randomUUID } from 'node:crypto';
import { getDatabase } from '../db.js';

export const taskRepository = {
  create({ type, payload = {}, parentRequestId = null }) {
    const db = getDatabase();
    const id = randomUUID();
    db.prepare(`
      INSERT INTO tasks (id, type, status, payload_json, parent_request_id)
      VALUES (?, ?, 'queued', ?, ?)
    `).run(id, type, JSON.stringify(payload), parentRequestId);
    return this.findById(id);
  },

  findById(id) {
    const db = getDatabase();
    const row = db.prepare('SELECT * FROM tasks WHERE id = ?').get(id);
    return row ? deserialize(row) : null;
  },

  findByParentRequest(parentRequestId) {
    const db = getDatabase();
    const rows = db.prepare('SELECT * FROM tasks WHERE parent_request_id = ? ORDER BY created_at ASC')
      .all(parentRequestId);
    return rows.map(deserialize);
  },

  updateStatus(id, status, { result, error } = {}) {
    const db = getDatabase();
    db.prepare(`
      UPDATE tasks
      SET status = ?, result_json = ?, error = ?, updated_at = datetime('now')
      WHERE id = ?
    `).run(status, result !== undefined ? JSON.stringify(result) : null, error || null, id);
    return this.findById(id);
  },

  incrementAttempts(id) {
    const db = getDatabase();
    db.prepare(`UPDATE tasks SET attempts = attempts + 1, updated_at = datetime('now') WHERE id = ?`).run(id);
    return this.findById(id);
  },

  /** Recupera tarefas que ficaram em estado nao terminal apos uma queda. */
  recoverInterrupted(maxAttempts = 2) {
    const db = getDatabase();
    const terminal = db.prepare(`
      UPDATE tasks SET status = 'failed', error = COALESCE(error, 'Limite de tentativas atingido antes da reinicializacao.'), updated_at = datetime('now')
      WHERE status = 'processing' AND attempts >= ?
    `).run(maxAttempts);
    const recovered = db.prepare(`
      UPDATE tasks SET status = 'queued', error = COALESCE(error, 'Retomada apos reinicializacao do ADAM KNOWLEDGE.'), updated_at = datetime('now')
      WHERE status = 'processing' AND attempts < ?
    `).run(maxAttempts);
    return { recovered: recovered.changes, failedAtLimit: terminal.changes };
  },

  listByStatus(status, limit = 50) {
    const db = getDatabase();
    const rows = db.prepare('SELECT * FROM tasks WHERE status = ? ORDER BY created_at ASC LIMIT ?')
      .all(status, limit);
    return rows.map(deserialize);
  },

  countByStatus() {
    const db = getDatabase();
    const rows = db.prepare('SELECT status, COUNT(*) as count FROM tasks GROUP BY status').all();
    const result = { queued: 0, processing: 0, completed: 0, failed: 0, cancelled: 0 };
    for (const row of rows) result[row.status] = row.count;
    return result;
  },
};

function deserialize(row) {
  return {
    ...row,
    payload: safeParse(row.payload_json, {}),
    result: row.result_json ? safeParse(row.result_json, null) : null,
  };
}

function safeParse(json, fallback) {
  try {
    return JSON.parse(json);
  } catch {
    return fallback;
  }
}
