import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { config } from '../config/index.js';
import { logger } from '../utils/logger.js';

let instance = null;

/**
 * Retorna uma conexao singleton com o banco SQLite local.
 * Usa o modulo nativo node:sqlite (experimental no Node 22), evitando
 * dependencia de pacotes externos como better-sqlite3.
 */
export function getDatabase() {
  if (instance) return instance;

  const dir = path.dirname(config.databasePath);
  fs.mkdirSync(dir, { recursive: true });

  instance = new DatabaseSync(config.databasePath);
  instance.exec('PRAGMA journal_mode = WAL;');
  instance.exec('PRAGMA foreign_keys = ON;');
  logger.info('Banco de dados SQLite conectado', { path: config.databasePath });
  return instance;
}

export function closeDatabase() {
  if (instance) {
    instance.close();
    instance = null;
  }
}

/** Verificacao real de saude do banco (usada pelo ADAM SYSTEM MONITOR) */
export function checkDatabaseHealth() {
  try {
    const db = getDatabase();
    const row = db.prepare('SELECT 1 AS ok').get();
    return { ok: row?.ok === 1, detail: 'conexao e consulta de teste bem-sucedidas' };
  } catch (err) {
    logger.error('Falha na verificacao de saude do banco de dados', err);
    return { ok: false, detail: err.message };
  }
}
