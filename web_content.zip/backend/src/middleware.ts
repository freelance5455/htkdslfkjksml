import {Request,Response,NextFunction} from "express";
import jwt from "jsonwebtoken";
export type AuthReq=Request&{user?:{id:string,role:string}};
export function auth(req:AuthReq,res:Response,next:NextFunction){
 const h=req.headers.authorization;
 if(!h?.startsWith("Bearer "))return res.status(401).json({error:"Authentication required"});
 try{req.user=jwt.verify(h.slice(7),process.env.JWT_ACCESS_SECRET||"DEV_ONLY_CHANGE_ME") as any;next()}
 catch{return res.status(401).json({error:"Invalid or expired token"})}
}
export function role(...roles:string[]){return (req:AuthReq,res:Response,next:NextFunction)=>{if(!req.user||!roles.includes(req.user.role))return res.status(403).json({error:"Forbidden"});next()}}