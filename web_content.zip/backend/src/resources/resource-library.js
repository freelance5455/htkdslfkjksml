import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { config } from '../config/index.js';
import { resourceRepository, VALID_RESOURCE_TYPES, ResourceValidationError } from '../database/repositories/resource-repository.js';
import { logger } from '../utils/logger.js';

const TYPE_TO_FOLDER = {
  texture: 'textures',
  model: 'models',
  animation: 'animations',
  sound: 'sounds',
  documentation: 'documentation',
};

/**
 * ADAM RESOURCE LIBRARY
 *
 * Organiza fisicamente os arquivos em storage/resources/<tipo>/<categoria>/
 * e mantem os metadados completos no banco de dados (origem, licenca, tags,
 * compatibilidade, projeto). Evita guardar arquivos grandes diretamente em
 * colunas de banco: aqui o arquivo vive no disco e o banco guarda so o path
 * e os metadados (preparado para, no futuro, trocar o disco local por um
 * armazenamento de objetos remoto sem mudar o contrato).
 */
export class ResourceLibrary {
  constructor({ basePath = config.resourceStoragePath } = {}) {
    this.basePath = path.resolve(basePath);
    this._ensureFolders();
  }

  _ensureFolders() {
    for (const folder of Object.values(TYPE_TO_FOLDER)) {
      fs.mkdirSync(path.join(this.basePath, folder), { recursive: true });
    }
  }

  /**
   * Registra um recurso. Se `fileBuffer` for fornecido, o arquivo e
   * realmente salvo em disco; caso contrario, o recurso e cadastrado como
   * referencia (ex: apenas um link de origem, sem arquivo reutilizavel —
   * util para o caso descrito na especificacao de "imagem usada so como
   * referencia" vs "arquivo reutilizavel").
   */
  async addResource({
    type, category, name, description, origin, format, resolution,
    licenseInfo, tags = [], project, compatibility, fileBuffer = null, fileExtension = null,
  }) {
    if (!VALID_RESOURCE_TYPES.includes(type)) {
      throw new ResourceValidationError(`Tipo de recurso invalido: "${type}".`);
    }

    let filePath = null;
    if (fileBuffer) {
      const folder = path.join(this.basePath, TYPE_TO_FOLDER[type], sanitize(category));
      fs.mkdirSync(folder, { recursive: true });
      const extension = normalizeExtension(fileExtension);
      const fileName = `${randomUUID()}${extension ? `.${extension}` : ''}`;
      const absolutePath = path.join(folder, fileName);
      fs.writeFileSync(absolutePath, fileBuffer);
      filePath = path.relative(this.basePath, absolutePath);
      logger.info('Arquivo de recurso salvo em disco', { filePath });
    }

    return resourceRepository.create({
      type, category, name, description, origin, filePath, format, resolution,
      licenseInfo, tags, project, compatibility,
    });
  }

  getResource(id) {
    return resourceRepository.findById(id);
  }

  /** Retorna o conteudo binario de um recurso salvo em disco, se existir */
  readResourceFile(id) {
    const resource = resourceRepository.findById(id);
    if (!resource) throw new Error(`Recurso "${id}" nao encontrado.`);
    if (!resource.file_path) throw new Error(`Recurso "${id}" nao possui arquivo associado (e apenas uma referencia).`);
    const absolutePath = resolveInsideBase(this.basePath, resource.file_path);
    if (!fs.existsSync(absolutePath) || !fs.statSync(absolutePath).isFile()) {
      throw new Error(`Arquivo esperado nao encontrado em disco: ${absolutePath}`);
    }
    return fs.readFileSync(absolutePath);
  }

  search(filters) {
    return resourceRepository.search(filters);
  }

  update(id, fields) {
    return resourceRepository.update(id, fields);
  }

  delete(id) {
    const resource = resourceRepository.findById(id);
    if (resource?.file_path) {
      const absolutePath = resolveInsideBase(this.basePath, resource.file_path);
      if (fs.existsSync(absolutePath) && fs.statSync(absolutePath).isFile()) fs.unlinkSync(absolutePath);
    }
    return resourceRepository.delete(id);
  }

  getStats() {
    return resourceRepository.countByType();
  }
}

function normalizeExtension(value) {
  if (value == null || value === '') return '';
  const extension = String(value).replace(/^\./, '').toLowerCase();
  if (!/^[a-z0-9]{1,10}$/.test(extension)) {
    throw new ResourceValidationError('Extensao de arquivo invalida. Use apenas letras e numeros (1 a 10 caracteres).');
  }
  return extension;
}

function resolveInsideBase(basePath, relativePath) {
  if (typeof relativePath !== 'string' || path.isAbsolute(relativePath)) {
    throw new ResourceValidationError('Caminho de arquivo de recurso invalido.');
  }
  const resolved = path.resolve(basePath, relativePath);
  const relative = path.relative(basePath, resolved);
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) {
    throw new ResourceValidationError('Caminho de arquivo fora da biblioteca de recursos.');
  }
  return resolved;
}

function sanitize(value) {
  return String(value).toLowerCase().replace(/[^a-z0-9-_]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '') || 'geral';
}

export const resourceLibrary = new ResourceLibrary();
