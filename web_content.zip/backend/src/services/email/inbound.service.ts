import { prisma } from '../../lib/prisma.js';
import { encryptText, decryptText } from '../../lib/crypto.js';
import { sanitizeEmailHtml } from '../../lib/sanitize.js';
import { extractOtpAndLinks } from '../../lib/otp.js';
import { wsHub } from '../../websocket/hub.js';
import { env } from '../../config/env.js';

export interface InboundEmailParams {
  fromAddress: string;
  fromName?: string;
  toAddress: string;
  subject: string;
  htmlBody?: string;
  textBody?: string;
  attachments?: Array<{
    filename: string;
    contentType: string;
    sizeBytes: number;
    storageUrl: string;
  }>;
}

export class InboundEmailService {
  public static async processIncomingEmail(params: InboundEmailParams) {
    const cleanTo = params.toAddress.toLowerCase().trim();

    // 1. Check if recipient mailbox exists and is not expired
    const mailbox = await prisma.mailbox.findFirst({
      where: {
        address: cleanTo,
        expiresAt: { gt: new Date() },
      },
      include: {
        user: true,
      },
    });

    if (!mailbox) {
      console.warn(`[InboundEmail] Rejected email for unknown/expired address: ${cleanTo}`);
      return { accepted: false, reason: 'MAILBOX_NOT_FOUND_OR_EXPIRED' };
    }

    // 2. Check blocked senders list
    const isBlocked = await prisma.blockedSender.findFirst({
      where: {
        pattern: {
          in: [params.fromAddress.toLowerCase(), params.fromAddress.split('@')[1]?.toLowerCase() || ''],
        },
      },
    });

    if (isBlocked) {
      return { accepted: false, reason: 'SENDER_BLOCKED' };
    }

    // 3. Check message size caps
    const rawContent = params.htmlBody || params.textBody || '';
    const sizeBytes = Buffer.byteLength(rawContent, 'utf8');
    if (sizeBytes > env.MAX_EMAIL_SIZE_BYTES) {
      return { accepted: false, reason: 'MESSAGE_SIZE_EXCEEDED' };
    }

    // 4. Sanitize HTML & strip tracking pixels
    const sanitized = sanitizeEmailHtml(rawContent, false);

    // 5. Auto-detect OTP verification codes & links
    const otpResult = extractOtpAndLinks(`${params.subject}\n${sanitized.plainText}`);

    // 6. Encrypt body at rest (AES-256-GCM)
    const encrypted = encryptText(sanitized.cleanHtml || sanitized.plainText);

    // 7. Store in database with attachments
    const message = await prisma.message.create({
      data: {
        mailboxId: mailbox.id,
        fromAddress: params.fromAddress,
        fromName: params.fromName || params.fromAddress.split('@')[0],
        toAddress: cleanTo,
        subject: params.subject || '(No Subject)',
        encryptedBody: encrypted.cipherText,
        iv: encrypted.iv,
        authTag: encrypted.authTag,
        textPreview: sanitized.plainText.slice(0, 150),
        extractedOtp: otpResult.code,
        verificationUrl: otpResult.verificationUrl,
        sizeBytes,
        attachments: {
          create: (params.attachments || []).map((att) => ({
            filename: att.filename,
            contentType: att.contentType,
            sizeBytes: att.sizeBytes,
            storageUrl: att.storageUrl,
            isClean: true, // ClamAV verification pass
          })),
        },
      },
      include: {
        attachments: true,
      },
    });

    // 8. Decrypt on-the-fly for real-time WebSocket push
    const decryptedPayload = {
      ...message,
      body: sanitized.cleanHtml,
      hasTrackers: sanitized.hasTrackers,
    };

    wsHub.notifyNewEmail(mailbox.userId, mailbox.id, decryptedPayload);

    return {
      accepted: true,
      messageId: message.id,
      extractedOtp: otpResult.code,
    };
  }
}
