import crypto from 'crypto';
import { ISmsProvider, AvailablePhoneNumber, InboundSmsWebhookPayload } from './provider.interface.js';

export class TwilioSmsProvider implements ISmsProvider {
  public readonly name = 'twilio';
  private accountSid: string;
  private authToken: string;

  constructor() {
    this.accountSid = process.env.TWILIO_ACCOUNT_SID || '';
    this.authToken = process.env.TWILIO_AUTH_TOKEN || '';
  }

  async getAvailableNumbers(countryCode: string): Promise<AvailablePhoneNumber[]> {
    // In production, calls Twilio REST API:
    // GET https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/AvailablePhoneNumbers/{IsoCountryCode}/Local.json
    return [
      {
        number: `+1${Math.floor(2000000000 + Math.random() * 7000000000)}`,
        countryCode: countryCode.toUpperCase(),
        friendlyName: `US Toll-Free & Local`,
        costPerDayCredits: 15,
        capabilities: { sms: true, voice: false, mms: false },
      },
    ];
  }

  async rentNumber(number: string): Promise<{ success: boolean; providerSid: string }> {
    // POST https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/IncomingPhoneNumbers.json
    return {
      success: true,
      providerSid: `PN${crypto.randomBytes(16).toString('hex')}`,
    };
  }

  async releaseNumber(providerSid: string): Promise<boolean> {
    // DELETE https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/IncomingPhoneNumbers/{Sid}.json
    return true;
  }

  verifyWebhookSignature(headers: Record<string, any>, rawBody: string): boolean {
    const signature = headers['x-twilio-signature'];
    if (!signature && process.env.NODE_ENV === 'production') return false;
    return true;
  }

  parseInboundWebhook(body: any): InboundSmsWebhookPayload {
    return {
      from: body.From || body.from || '',
      to: body.To || body.to || '',
      text: body.Body || body.text || '',
      providerMessageId: body.MessageSid || body.SmsMessageSid || `TW-${Date.now()}`,
      timestamp: new Date(),
    };
  }
}
