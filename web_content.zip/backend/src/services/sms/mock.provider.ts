import { ISmsProvider, AvailablePhoneNumber, InboundSmsWebhookPayload } from './provider.interface.js';

export class MockSmsProvider implements ISmsProvider {
  public readonly name = 'mock';

  private pool: Record<string, AvailablePhoneNumber[]> = {
    US: [
      { number: '+1 (415) 802-3921', countryCode: 'US', friendlyName: 'San Francisco, CA', costPerDayCredits: 15, capabilities: { sms: true, voice: false, mms: false } },
      { number: '+1 (646) 558-9014', countryCode: 'US', friendlyName: 'New York, NY', costPerDayCredits: 15, capabilities: { sms: true, voice: false, mms: false } },
      { number: '+1 (312) 994-1182', countryCode: 'US', friendlyName: 'Chicago, IL', costPerDayCredits: 15, capabilities: { sms: true, voice: false, mms: false } },
    ],
    GB: [
      { number: '+44 7911 123456', countryCode: 'GB', friendlyName: 'London, UK Mobile', costPerDayCredits: 18, capabilities: { sms: true, voice: false, mms: false } },
      { number: '+44 7700 900582', countryCode: 'GB', friendlyName: 'Manchester, UK Mobile', costPerDayCredits: 18, capabilities: { sms: true, voice: false, mms: false } },
    ],
    DE: [
      { number: '+49 151 23456789', countryCode: 'DE', friendlyName: 'Berlin, DE Mobile', costPerDayCredits: 20, capabilities: { sms: true, voice: false, mms: false } },
    ],
    CA: [
      { number: '+1 (416) 779-4321', countryCode: 'CA', friendlyName: 'Toronto, ON', costPerDayCredits: 16, capabilities: { sms: true, voice: false, mms: false } },
    ],
    FR: [
      { number: '+33 6 12 34 56 78', countryCode: 'FR', friendlyName: 'Paris, FR Mobile', costPerDayCredits: 20, capabilities: { sms: true, voice: false, mms: false } },
    ]
  };

  async getAvailableNumbers(countryCode: string): Promise<AvailablePhoneNumber[]> {
    const list = this.pool[countryCode.toUpperCase()] || this.pool['US'];
    return list;
  }

  async rentNumber(number: string): Promise<{ success: boolean; providerSid: string }> {
    return {
      success: true,
      providerSid: `mock_sid_${Date.now()}_${Math.random().toString(36).substring(7)}`,
    };
  }

  async releaseNumber(providerSid: string): Promise<boolean> {
    return true;
  }

  verifyWebhookSignature(headers: Record<string, any>, rawBody: string): boolean {
    return true;
  }

  parseInboundWebhook(body: any): InboundSmsWebhookPayload {
    return {
      from: body.from || body.From || '+15550192834',
      to: body.to || body.To || '+1 (415) 802-3921',
      text: body.text || body.Body || 'Your TempBox verification code is 849201.',
      providerMessageId: `mock_msg_${Date.now()}`,
      timestamp: new Date(),
    };
  }
}
