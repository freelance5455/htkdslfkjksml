import { ISmsProvider } from './provider.interface.js';
import { TwilioSmsProvider } from './twilio.provider.js';
import { TelnyxSmsProvider } from './telnyx.provider.js';
import { MockSmsProvider } from './mock.provider.js';

export function getSmsProvider(): ISmsProvider {
  const providerType = process.env.SMS_PROVIDER || 'mock';
  switch (providerType.toLowerCase()) {
    case 'twilio':
      return new TwilioSmsProvider();
    case 'telnyx':
      return new TelnyxSmsProvider();
    case 'mock':
    default:
      return new MockSmsProvider();
  }
}
