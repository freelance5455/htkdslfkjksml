export interface AvailablePhoneNumber {
  number: string;
  countryCode: string;
  friendlyName: string;
  costPerDayCredits: number;
  capabilities: {
    sms: boolean;
    voice: boolean;
    mms: boolean;
  };
}

export interface InboundSmsWebhookPayload {
  from: string;
  to: string;
  text: string;
  providerMessageId: string;
  timestamp?: Date;
}

export interface ISmsProvider {
  readonly name: string;
  getAvailableNumbers(countryCode: string): Promise<AvailablePhoneNumber[]>;
  rentNumber(number: string): Promise<{ success: boolean; providerSid: string }>;
  releaseNumber(providerSidOrNumber: string): Promise<boolean>;
  verifyWebhookSignature(headers: Record<string, any>, rawBody: string): boolean;
  parseInboundWebhook(body: any): InboundSmsWebhookPayload;
}
