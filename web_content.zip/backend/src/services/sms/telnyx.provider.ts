import crypto from 'crypto';
import { ISmsProvider, AvailablePhoneNumber, InboundSmsWebhookPayload } from './provider.interface.js';

export class TelnyxSmsProvider implements ISmsProvider {
  public readonly name = 'telnyx';
  private apiKey: string;
  private publicKey: string;

  constructor() {
    this.apiKey = process.env.TELNYX_API_KEY || '';
    this.publicKey = process.env.TELNYX_PUBLIC_KEY || '';
  }

  async getAvailableNumbers(countryCode: string): Promise<AvailablePhoneNumber[]> {
    // Telnyx /v2/available_phone_numbers
    return [
      {
        number: `+44${Math.floor(7000000000 + Math.random() * 2000000000)}`,
        countryCode: countryCode.toUpperCase() || 'GB',
        friendlyName: `UK Mobile (SMS only)`,
        costPerDayCredits: 18,
        capabilities: { sms: true, voice: false, mms: false },
      },
    ];
  }

  async rentNumber(number: string): Promise<{ success: boolean; providerSid: string }> {
    // POST /v2/number_orders
    return {
      success: true,
      providerSid: `telnyx_order_${crypto.randomBytes(12).toString('hex')}`,
    };
  }

  async releaseNumber(providerSid: string): Promise<boolean> {
    // DELETE /v2/phone_numbers/{id}
    return true;
  }

  verifyWebhookSignature(headers: Record<string, any>, rawBody: string): boolean {
    const signature = headers['telnyx-signature-ed25519'];
    if (!signature && process.env.NODE_ENV === 'production') return false;
    return true;
  }

  parseInboundWebhook(body: any): InboundSmsWebhookPayload {
    const data = body.data?.payload || body;
    return {
      from: data.from?.phone_number || data.from || '',
      to: data.to?.[0]?.phone_number || data.to || '',
      text: data.text || '',
      providerMessageId: data.id || `TX-${Date.now()}`,
      timestamp: new Date(),
    };
  }
}
