import { prisma } from '../lib/prisma.js';
import { TransactionType } from '@prisma/client';

export class CreditsService {
  /**
   * Deducts credits for renting a number and records transaction.
   */
  public static async deductCreditsForRental(userId: string, cost: number, numberId: string, numberString: string) {
    return prisma.$transaction(async (tx) => {
      const user = await tx.user.findUnique({ where: { id: userId } });
      if (!user) throw new Error('User not found');
      if (user.credits < cost) {
        throw new Error(`Insufficient credits. You need ${cost} credits but have ${user.credits}.`);
      }

      const updatedUser = await tx.user.update({
        where: { id: userId },
        data: { credits: { decrement: cost } },
      });

      await tx.creditTransaction.create({
        data: {
          userId,
          amount: -cost,
          type: TransactionType.RENT_NUMBER,
          description: `Rented number ${numberString}`,
          referenceId: numberId,
        },
      });

      return updatedUser.credits;
    });
  }

  /**
   * Adds purchased credits upon verification of App Store / Play Store / RevenueCat receipt.
   */
  public static async addPurchasedCredits(userId: string, credits: number, transactionId: string, store: string) {
    return prisma.$transaction(async (tx) => {
      const updatedUser = await tx.user.update({
        where: { id: userId },
        data: { credits: { increment: credits } },
      });

      await tx.creditTransaction.create({
        data: {
          userId,
          amount: credits,
          type: TransactionType.PURCHASE,
          description: `Purchased ${credits} credits (${store})`,
          referenceId: transactionId,
        },
      });

      return updatedUser.credits;
    });
  }

  /**
   * Automatically refunds credits if the rented number expired without receiving any SMS.
   */
  public static async processAutomaticRefunds() {
    const expiredUnusedNumbers = await prisma.phoneNumber.findMany({
      where: {
        expiresAt: { lt: new Date() },
        receivedSmsQty: 0,
        refundIssued: false,
      },
    });

    const results = [];
    for (const num of expiredUnusedNumbers) {
      const refund = await prisma.$transaction(async (tx) => {
        await tx.user.update({
          where: { id: num.userId },
          data: { credits: { increment: num.creditsCost } },
        });

        await tx.phoneNumber.update({
          where: { id: num.id },
          data: { refundIssued: true },
        });

        await tx.creditTransaction.create({
          data: {
            userId: num.userId,
            amount: num.creditsCost,
            type: TransactionType.AUTO_REFUND,
            description: `Auto-refund for unused number ${num.number}`,
            referenceId: num.id,
          },
        });
        return num.id;
      });
      results.push(refund);
    }

    return results;
  }
}
