import http from 'node:http';
import { buildAddonForgeRouter } from './communication/addonforge-bridge.js';
import { logger } from './utils/logger.js';

/**
 * Cria o servidor HTTP sem inicia-lo (nao chama .listen()).
 * Separado de server.js para permitir testes de integracao que sobem o
 * servidor em uma porta efemera, com um banco de dados isolado por teste.
 */
export function createApp() {
  const router = buildAddonForgeRouter();

  const server = http.createServer((req, res) => {
    router.handle(req, res).catch((err) => {
      logger.error('Erro nao tratado no servidor HTTP', err);
      if (!res.headersSent) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'INTERNAL_ERROR', message: 'Erro interno inesperado.' }));
      }
    });
  });

  return server;
}
