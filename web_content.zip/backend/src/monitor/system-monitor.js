import fs from 'node:fs';
import { config } from '../config/index.js';
import { checkDatabaseHealth } from '../database/db.js';
import { taskManager } from '../core/task-manager.js';
import { logger } from '../utils/logger.js';

const INTERNET_CHECK_URL = 'https://1.1.1.1'; // endpoint estavel e leve so para checagem de conectividade
const INTERNET_CHECK_TIMEOUT_MS = 4000;

/**
 * ADAM SYSTEM MONITOR
 *
 * Todos os estados vem de verificacoes reais executadas no momento da
 * chamada — nunca de indicadores visuais fixos, conforme exige a
 * especificacao (secao 15).
 */
export class SystemMonitor {
  constructor({ addonForgeConnectionTracker } = {}) {
    this._addonForgeTracker = addonForgeConnectionTracker || { isConnected: () => false, lastSeenAt: () => null };
  }

  async checkInternet() {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), INTERNET_CHECK_TIMEOUT_MS);
    try {
      await fetch(INTERNET_CHECK_URL, { method: 'HEAD', signal: controller.signal });
      return { connected: true };
    } catch (err) {
      return { connected: false, detail: err.name === 'AbortError' ? 'timeout' : err.message };
    } finally {
      clearTimeout(timer);
    }
  }

  checkStorage() {
    try {
      const stat = fs.statfsSync(config.resourceStoragePath);
      const totalBytes = stat.blocks * stat.bsize;
      const freeBytes = stat.bfree * stat.bsize;
      return {
        ok: true,
        totalBytes,
        freeBytes,
        freePercent: totalBytes > 0 ? Number(((freeBytes / totalBytes) * 100).toFixed(1)) : null,
      };
    } catch (err) {
      return { ok: false, detail: err.message };
    }
  }

  async getStatus() {
    const [internet, db] = await Promise.all([
      this.checkInternet(),
      Promise.resolve(checkDatabaseHealth()),
    ]);
    const storage = this.checkStorage();
    const taskStats = taskManager.getStats();
    const recentErrors = logger.getRecentErrors(5);

    return {
      app: 'ADAM KNOWLEDGE',
      timestamp: new Date().toISOString(),
      database: db.ok ? 'OK' : `FALHA (${db.detail})`,
      internet: internet.connected ? 'CONECTADA' : `DESCONECTADA${internet.detail ? ` (${internet.detail})` : ''}`,
      webResearch: config.webSearch.configured ? 'DISPONIVEL' : 'NAO CONFIGURADA',
      imageResearch: 'PARCIAL (reaproveita pesquisa web nesta etapa)',
      artificialIntelligence: config.ai.configured ? 'CONFIGURADA' : 'NAO CONFIGURADA',
      addonForge: this._addonForgeTracker.isConnected() ? 'CONECTADO' : 'DESCONECTADO',
      addonForgeLastSeenAt: this._addonForgeTracker.lastSeenAt(),
      storage: storage.ok
        ? `OK (${storage.freePercent}% livre)`
        : `FALHA (${storage.detail})`,
      tasks: taskStats,
      recentErrors: recentErrors.map((e) => ({ timestamp: e.timestamp, message: e.message })),
    };
  }
}

export const systemMonitor = new SystemMonitor();
