import os, secrets, logging
from flask import Flask, g, request, session, render_template, send_from_directory, abort, Response
from .config import Config
from . import db as dbm, security, util
from .services import settings as S, theme as theme_svc

ROOT = os.path.dirname(os.path.dirname(__file__))

def create_app(test_config=None):
    app = Flask(__name__, instance_path=os.path.join(ROOT, "instance"))
    app.config.from_object(Config)
    if test_config: app.config.update(test_config)
    if not app.config.get("SECRET_KEY"):
        # Persist a generated key for first-run convenience; production should set SECRET_KEY explicitly.
        kf = os.path.join(os.path.dirname(app.config["DATABASE"]), ".secret_key")
        os.makedirs(os.path.dirname(kf), exist_ok=True)
        if not os.path.exists(kf):
            with open(kf, "w") as f: f.write(secrets.token_hex(32))
            os.chmod(kf, 0o600)
        app.config["SECRET_KEY"] = open(kf).read().strip()
    if os.environ.get("AUTO_MIGRATE", "true").lower() not in ("0", "false", "no") and app.config.get("AUTO_MIGRATE", True):
        applied = dbm.migrate(app.config["DATABASE"], os.path.join(ROOT, "migrations"))   # an upgraded app never runs against an out-of-date database
        if applied: logging.getLogger("dagba").warning("Applied database migrations: %s", applied)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    if os.environ.get("TRUST_PROXY", "").lower() in ("1", "true", "yes"):
        from werkzeug.middleware.proxy_fix import ProxyFix  # so rate limiting / audit see the real client IP behind nginx
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
    app.teardown_appcontext(dbm.close_db)

    @app.before_request
    def _before():
        S.clear_cache(); security.load_user()
        from .services import prelaunch as _PL
        blocked = _PL.gate()                       # Pre-Launch Mode: server-side gate in front of every URL (no-op when the mode is off or the launch time has passed)
        if blocked is not None: return blocked
        security.csrf_protect()

    app.after_request(security.security_headers)

    @app.context_processor
    def _ctx():
        unread = pending = pending_po = pending_aff = 0; my_aff = None
        from .services import prelaunch as _PL
        pl_on = _PL.restricting(); pl_lock = pl_on and not _PL.can_bypass(g.get("user"))
        if g.get("user"):
            unread = dbm.val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read_at IS NULL", (g.user["id"],), 0)
            if security.has_perm("payments.manage"):
                pending = dbm.val("SELECT COUNT(*) FROM transactions WHERE status='pending_verification'", default=0)
            if security.has_perm("payouts.manage"):
                pending_po = dbm.val("SELECT COUNT(*) FROM payout_requests WHERE status='requested'", default=0)
            if security.has_perm("affiliates.manage"):
                pending_aff = dbm.val("SELECT COUNT(*) FROM affiliate_payouts WHERE status='requested'", default=0)
            my_aff = dbm.q1("SELECT id, slug, status FROM affiliates WHERE user_id=?", (g.user["id"],))
        return dict(S=S.all_public(), csrf_token=security.csrf_token, has_perm=security.has_perm, user=g.get("user"),
                    unread_count=unread, pending_payments=pending, pending_payouts=pending_po, pending_aff=pending_aff, my_affiliate=my_aff, mode_btn=theme_svc.show_toggle(), mode_default=theme_svc.mode_default(), now_year=__import__('datetime').date.today().year, site_url=app.config["SITE_URL"], PERMISSIONS=security.PERMISSIONS, prelaunch_lock=pl_lock, prelaunch_banner=bool(pl_on and not pl_lock), prelaunch_label=_PL.launch_label() if pl_on else "")

    from .services import content as C
    from .services import avatars as _AV, tutors as _TU
    app.jinja_env.globals["initials"] = _AV.initials; app.jinja_env.globals["TUTOR_LABEL"] = _TU.LABEL
    from .services import icons as _IC
    app.jinja_env.globals["lucide"] = _IC.lucide; app.jinja_env.globals["lucide_ok"] = _IC.valid
    app.jinja_env.globals["ct"] = C.ct; app.jinja_env.globals["cl"] = C.cl; app.jinja_env.globals["safe_url"] = C.safe_url
    from .services import academic as _A
    from .services import faith as _F
    app.jinja_env.globals["FAITH_KINDS"] = _F.KINDS
    from .services import access as _AC
    app.jinja_env.globals["sold_by_subject"] = _AC.sells_by_subject
    app.jinja_env.globals["LEVELS"] = _A.LEVELS; app.jinja_env.globals["subject_slug"] = _A.subject_slug
    def _page_url(n):
        from urllib.parse import urlencode
        a = request.args.to_dict(); a["page"] = n; return request.path + "?" + urlencode(a)
    app.jinja_env.globals["page_url"] = _page_url
    app.jinja_env.globals["csrf_token"] = security.csrf_token
    app.jinja_env.filters["naira"] = util.naira
    from .services import mou as _MOU
    app.jinja_env.filters["mou_html"] = _MOU.safe_markup
    app.jinja_env.filters["rt"] = util.render_text
    app.jinja_env.filters["date"] = lambda s: (s or "")[:10]
    app.jinja_env.filters["dt"] = lambda s: (s or "")[:16]
    app.jinja_env.globals["embed_url"] = util.embed_url; app.jinja_env.globals["div_label"] = util.division_label

    from .blueprints import public, auth, student, pay, staff, staffpay, builder, payouts as payouts_bp, affiliates as affiliates_bp, faith, faith_admin, paths as paths_bp, hero_admin, tutors as tutors_bp, mou as mou_bp, prelaunch as prelaunch_bp, discuss as discuss_bp, learnpaths as learnpaths_bp, api_v1 as api_v1_bp
    for bp in (public.bp, auth.bp, student.bp, pay.bp, staff.bp, staffpay.bp, builder.bp, payouts_bp.bp, affiliates_bp.bp, faith.bp, faith_admin.bp, paths_bp.bp, hero_admin.bp, tutors_bp.bp, mou_bp.bp, prelaunch_bp.bp, discuss_bp.bp, learnpaths_bp.bp, api_v1_bp.bp): app.register_blueprint(bp)

    @app.errorhandler(403)
    def _403(e):
        if request.path.startswith('/api/v1/'): from .services import mobile as _M; return _M.json_error(403, getattr(e, 'description', 'Request failed.'))
        return render_template("error.html", code=403, msg="You do not have permission to view this page."), 403
    @app.errorhandler(404)
    def _404(e):
        if request.path.startswith('/api/v1/'): from .services import mobile as _M; return _M.json_error(404, getattr(e, 'description', 'Request failed.'))
        return render_template("error.html", code=404, msg="We could not find that page."), 404
    @app.errorhandler(400)
    def _400(e):
        if request.path.startswith('/api/v1/'): from .services import mobile as _M; return _M.json_error(400, getattr(e, 'description', 'Request failed.'))
        return render_template("error.html", code=400, msg=getattr(e, "description", "Bad request.")), 400
    @app.errorhandler(413)
    def _413(e):
        if request.path.startswith('/api/v1/'): from .services import mobile as _M; return _M.json_error(413, "The upload is larger than the server allows.")
        if request.headers.get("X-Requested-With") == "fetch":
            from flask import jsonify
            return jsonify(ok=False, errors=["The upload is larger than the server allows. Use a smaller/compressed video."]), 413
        return render_template("error.html", code=413, msg="That file is too large."), 413
    @app.errorhandler(500)
    def _500(e):
        import uuid, traceback
        ref = uuid.uuid4().hex[:8].upper(); orig = getattr(e, "original_exception", None) or e
        text = f"{type(orig).__name__}: {orig}"[:400]
        logging.getLogger("dagba").error("Unhandled error %s on %s %s\n%s", ref, request.method, request.path, "".join(traceback.format_exception(type(orig), orig, orig.__traceback__))[-3000:])
        try:   # also visible to the owner in Admin > Audit log (no server access needed)
            from .services import audit as _audit
            _audit.log("error.500", "error", ref, f"{request.method} {request.path} | {text}")
        except Exception: pass
        hint = "The database is out of date. Run:  python manage.py migrate" if "no such column" in text or "no such table" in text else ""
        staff = bool(g.get("user") and g.user["role"] == "admin")
        from flask import jsonify
        if request.path.startswith("/api/v1/"):
            from .services import mobile as _M; return _M.json_error(500, f"Something went wrong on our side (ref {ref}). Please try again.", "server_error")
        if request.headers.get("X-Requested-With") == "fetch" or request.is_json:
            return jsonify(ok=False, error=f"Something went wrong on our side (ref {ref}). Please try again.", errors=[f"Something went wrong on our side (ref {ref}). Please try again."]), 500
        return render_template("error.html", code=500, msg="Something went wrong on our side. Please try again.", ref=ref, detail=text if staff else "", hint=hint if staff or hint else ""), 500
    return app
