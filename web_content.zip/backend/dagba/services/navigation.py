"""Dashboard navigation: Parent menu -> submenu -> page, built per user from the roles and permissions that already exist.

``build(user)`` returns a tree of nodes::

    link  = dict(kind="link",  label, href, active, badge, icon)
    group = dict(kind="group", label, icon, active, open, badge, children=[link | group, ...])

Nothing here grants access: every item is shown only when the page behind it would be allowed for this user, and every page
still enforces its own permission check. A group with no visible child is dropped; a group with one child collapses to a link.
"""
from flask import g, request, url_for
from ..db import q1, val
from ..security import has_perm
from . import paths as P

# request endpoints that belong to a menu item's page (edit forms, detail pages, ...)
FAMILY = {"staff.crud_form": "staff.crud_list", "staff.crud_delete": "staff.crud_list", "faithadmin.editor": "faithadmin.lessons", "faithadmin.tutor_topics": "faithadmin.tutors", "faithadmin.topic_tutors": "faithadmin.tutors",
          "staff.user_detail": "staff.users", "staff.user_new": "staff.users", "staffpay.payment": "staffpay.payments",
          "payouts.payout": "payouts.payouts", "affiliates.admin_detail": "affiliates.admin_list", "affiliates.admin_new": "affiliates.admin_list",
          "staff.submission": "staff.submissions", "tutors.app_detail": "tutors.apps_list", "tutors.tutor_detail": "tutors.tutors_list", "mou.admin_edit": "mou.admin_index", "prelaunch.signup_delete": "prelaunch.signups", "learnpaths.edit": "learnpaths.manage", "learnpaths.detail": "learnpaths.index", "mou.admin_preview": "mou.admin_index", "mou.admin_version": "mou.admin_index", "mou.admin_agreement": "mou.records", "mou.my_agreement": "mou.my_agreements", "heroadmin.edit": "heroadmin.index", "builder.page": "staff.crud_list", "student.course_home": "student.courses"}
FILTER_KEYS = ("rname", "ctx", "group", "status", "role", "type", "tab", "kind", "path", "division", "level")

def _cur():
    """(endpoint, params) of the current request, with a few pages mapped to the menu item that owns them."""
    ep = request.endpoint or ""; va = dict(request.view_args or {}); args = {k: request.args.get(k, "") for k in FILTER_KEYS if request.args.get(k)}
    cur = {**args, **{k: str(v) for k, v in va.items() if k in FILTER_KEYS}}
    if ep == "builder.page":                                   # the course builder is the editor behind Courses
        cid = va.get("cid"); c = q1("SELECT division, academic_level FROM courses WHERE id=?", (cid,)) if cid else None
        cur = dict(rname="courses", ctx=P.path_of_course(c) if c else (P.valid(request.args.get("ctx")) or ""))
    return FAMILY.get(ep, ep), cur

class _B:
    def __init__(self, user):
        self.u = user; self.ep, self.cur = _cur()

    def link(self, label, endpoint, icon=None, badge=0, ext=None, **params):
        href = ext or url_for(endpoint, **params)
        active = False
        if not ext and endpoint == self.ep:
            active = all(str(self.cur.get(k, "")) == str(v) for k, v in params.items() if k in FILTER_KEYS)
            if active: active = all(k in params for k in self.cur if k in ("status", "role", "type", "tab", "kind", "path") and self.cur[k])  # "All users" is not active on ?role=student
        return dict(kind="link", label=label, href=href, active=active, badge=badge or 0, icon=icon)

    def group(self, label, children, icon=None, badge=0):
        kids = [c for c in children if c]
        if not kids: return None
        act = any(c["active"] for c in kids)
        return dict(kind="group", label=label, icon=icon, active=act, open=act, badge=badge or sum(c["badge"] for c in kids), children=kids)

def flat(tree):
    """Old flat list of (label, href), kept for callers that still expect it."""
    out = []
    for n in tree:
        if n["kind"] == "link": out.append((n["label"], n["href"]))
        else: out += flat(n["children"])
    return out

def build(user):
    if not user: return []
    return _student(user) if user["role"] == "student" else _staff(user)

# ------------------------------------------------------------------------------------------------ staff
def _staff(u):
    from ..blueprints import staff as ST, staffpay as SP
    from . import payouts as PO
    b = _B(u); L = b.link; G = b.group
    admin = u["role"] == "admin"; instr = u["role"] == "instructor"; writer = u["role"] == "writer"
    ok = lambda r: ST._allowed(ST.RES[r])
    grp_ok = lambda grp: has_perm(SP.GROUPS[grp]["perm"])
    n_pay = val("SELECT COUNT(*) FROM transactions WHERE status='pending_verification'", default=0) if has_perm("payments.manage") else 0
    n_po = val("SELECT COUNT(*) FROM payout_requests WHERE status='requested'", default=0) if has_perm("payouts.manage") else 0
    n_aff = val("SELECT COUNT(*) FROM affiliate_payouts WHERE status='requested'", default=0) if has_perm("affiliates.manage") else 0
    n_msg = val("SELECT COUNT(*) FROM contact_messages WHERE handled=0", default=0) if has_perm("settings.manage") else 0
    n_wr = val("SELECT COUNT(*) FROM articles WHERE status='pending'", default=0) + val("SELECT COUNT(*) FROM nuggets WHERE status='pending'", default=0) if has_perm("content.manage") else 0
    n_unread = val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read_at IS NULL", (u["id"],), 0)
    t = [L("Dashboard", "staff.dashboard", "home")]

    # ---- TUTOR PROGRAMME: the tutor's own workspace, and the admin review desk
    if instr:
        n_rev = val("SELECT COUNT(*) FROM tutor_applications WHERE user_id=? AND status='revision'", (u["id"],), 0)
        t.append(G("Teaching", [L("My courses", "builder.catalog"), L("Submit a new course", "builder.page"), L("Submissions & feedback", "tutors.submissions", badge=n_rev),
                                L("Sales & enrolment reports", "tutors.reports"), L("Affiliate links", "tutors.links"), L("My earnings", "payouts.earnings"), L("Tutor profile", "tutors.tutor_profile"), L("Learning paths", "learnpaths.manage"), L("Discussions", "discuss.moderate"), L("My Agreement / Signed MOU", "mou.my_agreements")], "academics"))
    if has_perm("tutors.manage") or has_perm("mou.manage"):
        tm = has_perm("tutors.manage")
        n_apps = val("SELECT COUNT(*) FROM tutor_applications WHERE status='pending'", default=0) if tm else 0
        t.append(G("Tutors", [L("Tutor applications", "tutors.apps_list", badge=n_apps, status="pending") if tm else None, L("New course reviews", "tutors.apps_list", kind="course") if tm else None, L("All applications", "tutors.apps_list") if tm else None,
                              L("Tutors", "tutors.tutors_list") if tm else None, L("Tutor transactions", "tutors.ledger") if tm else None,
                              L("Tutor MOU Management", "mou.admin_index") if has_perm("mou.manage") else None, L("Signed MOU records", "mou.records")], "users", badge=n_apps))

    # ---- FAITH
    manager = has_perm("faith.manage")
    if manager or instr:
        t.append(G("Faith", [
            L("Overview", "faithadmin.overview") if manager else None,
            L("Topics", "staff.crud_list", rname="faith-topics", ctx="faith") if ok("faith-topics") else None,
            L("Courses", "staff.crud_list", rname="faith-series", ctx="faith") if ok("faith-series") else None,
            L("Lessons", "faithadmin.lessons"),
            L("Tutors", "faithadmin.tutors") if manager else None,
            L("Resources", "faithadmin.lessons", kind="study"),
            L("Settings", "staffpay.settings", group="faith") if manager and grp_ok("faith") else None], "faith"))

    # ---- ACADEMICS and INCOME SKILLS (one independent submenu per path)
    if ok("courses") or ok("categories"):
        def path_items(key):
            subj = "Subjects" if key in P.ACADEMIC else ("Programme areas" if key == "professional" else "Categories")
            return [
                L("Overview", "paths.overview", ctx=key),
                L(subj, "staff.crud_list", rname="categories", ctx=key) if ok("categories") else None,
                L("Courses", "staff.crud_list", rname="courses", ctx=key) if ok("courses") else None,
                L("Topics", "staff.crud_list", rname="modules", ctx=key) if ok("modules") else None,
                L("Lessons", "staff.crud_list", rname="lessons", ctx=key) if ok("lessons") else None,
                L("Assignments", "staff.crud_list", rname="assignments", ctx=key) if ok("assignments") else None,
                L("Quizzes", "staff.crud_list", rname="quizzes", ctx=key) if ok("quizzes") else None,
                L("Students / Enrolments", "paths.enrolments", ctx=key),
                L("Resources", "paths.resources", ctx=key),
                L("Course announcements", "staff.crud_list", rname="announcements", ctx=key) if ok("announcements") else None]
        path_group = lambda key: G(P.name(key), path_items(key), "academics")
        t.append(G("Academics", [L("Overview", "builder.academic_structure") if has_perm("courses.manage") else None,
                                 L("Course catalog", "builder.catalog", division="academic"),
                                 *[path_group(k) for k in P.ACADEMIC],
                                 L("Learning paths", "learnpaths.manage") if has_perm("paths.manage") else None, L("Discussions", "discuss.moderate") if has_perm("discussions.manage") else None,
                                 L("Assignments to mark", "staff.submissions")], "academics"))
        t.append(G("Income Skills", [*path_items("income"), L("Course catalog", "builder.catalog", division="income")], "income"))
        t.append(G("Professional Development", [*path_items("professional"), L("Course catalog", "builder.catalog", division="professional")], "academics"))

    # ---- PAYMENTS
    t.append(G("Payments", [
        L("Transactions", "staffpay.payments", badge=0) if has_perm("payments.manage") else None,
        L("Course purchases", "staffpay.payments", type="course") if has_perm("payments.manage") else None,
        L("Subscriptions", "staffpay.payments", type="plan") if has_perm("payments.manage") else None,
        L("Payment verification", "staffpay.payments", badge=n_pay, status="pending_verification") if has_perm("payments.manage") else None,
        L("Payment history", "staffpay.payments", status="approved") if has_perm("payments.manage") else None,
        L("Bank account details", "staffpay.settings", group="bank") if grp_ok("bank") else None,
        L("Payment settings", "staffpay.settings", group="methods") if grp_ok("methods") else None,
        L("Prices & subscriptions", "staff.pricing") if has_perm("pricing.manage") else None,
        L("Subscription plans", "staff.crud_list", rname="plans") if ok("plans") else None,
        L("Discount codes", "staff.crud_list", rname="promos") if ok("promos") else None,
        L("Tutor payout requests", "payouts.payouts", badge=n_po) if has_perm("payouts.manage") else None,
        L("Tutor earnings", "payouts.instructors") if has_perm("payouts.manage") else None,
        L("Payout settings", "staffpay.settings", group="payouts") if grp_ok("payouts") else None], "payments"))
    if PO.is_earner(u) and not instr: t.append(L("My earnings", "payouts.earnings", "earnings"))

    # ---- AFFILIATES
    t.append(G("Affiliates", [
        L("Affiliates", "affiliates.admin_list") if has_perm("affiliates.manage") else None,
        L("Removed affiliates", "affiliates.admin_list", tab="removed") if has_perm("affiliates.manage") else None,
        L("Withdrawal requests", "affiliates.admin_list", badge=n_aff, tab="requests") if has_perm("affiliates.manage") else None,
        L("Affiliate settings", "staffpay.settings", group="affiliates") if grp_ok("affiliates") else None], "affiliates"))

    # ---- USERS
    t.append(G("Users", [
        L("All users", "staff.users"), L("Students", "staff.users", role="student"), L("Instructors / Tutors", "staff.users", role="instructor"),
        L("Writers", "staff.users", role="writer"), L("Administrators", "staff.users", role="admin")] if has_perm("users.manage") else [], "users"))

    # ---- CERTIFICATES
    t.append(G("Certificates", [
        L("Issued certificates", "staff.certs") if has_perm("certificates.manage") else None,
        L("Certificate settings", "staffpay.settings", group="cert") if grp_ok("cert") else None], "certificates"))

    # ---- APPEARANCE
    if has_perm("settings.manage"):
        t.append(G("Appearance", [
            L("Branding & logo", "staffpay.settings", group="brand"), L("Theme colours", "staffpay.theme"), L("Homepage hero", "heroadmin.index"), L("Homepage", "staffpay.settings", group="home"), L("Intro card icons", "staffpay.intro_icons"),
            L("Website text & menus", "staffpay.content_index"), L("Pages", "staff.crud_list", rname="pages") if ok("pages") else None,
            L("Site settings", "staffpay.settings", group="site"), L("SEO", "staffpay.settings", group="seo")], "appearance"))

    # ---- BLOG / CONTENT
    if ok("articles") or ok("nuggets"):
        mine = "My " if writer else "All "
        t.append(G("Blog / Content", [
            L(mine + "articles", "staff.crud_list", rname="articles") if ok("articles") else None,
            L("Writers' submissions", "staff.crud_list", badge=n_wr, rname="articles", status="pending") if ok("articles") and not writer else None,
            L("Drafts", "staff.crud_list", rname="articles", status="draft") if ok("articles") else None,
            L("Published articles", "staff.crud_list", rname="articles", status="published") if ok("articles") else None,
            L("Nuggets", "staff.crud_list", rname="nuggets") if ok("nuggets") else None,
            L("Testimonials", "staff.crud_list", rname="testimonials") if ok("testimonials") else None,
            L("FAQs", "staff.crud_list", rname="faqs") if ok("faqs") else None], "blog"))

    # ---- ANALYTICS, NOTIFICATIONS, SUPPORT, SYSTEM
    if has_perm("reports.view"): t.append(L("Analytics & reports", "staffpay.reports", "analytics"))
    t.append(G("Notifications", [L("My notifications", "student.notifications", badge=n_unread),
                                 L("Announcements", "staff.broadcast") if has_perm("notifications.manage") else None], "bell", badge=n_unread))
    if has_perm("settings.manage"): t.append(L("Support: contact messages", "staff.messages", "support", badge=n_msg))
    if has_perm("prelaunch.manage"): t.append(G("Pre-Launch", [L("Pre-Launch settings", "prelaunch.settings"), L("Early registrations", "prelaunch.signups")], "system"))
    t.append(G("System", [L("Activity log", "staff.audit_view") if has_perm("audit.view") else None,
                          L("Backup & export", "staff.system") if has_perm("system.manage") else None], "system"))

    # ---- personal
    my_aff = q1("SELECT id FROM affiliates WHERE user_id=?", (u["id"],))
    t.append(G("My account", [L("Profile settings", "auth.account"), L("My affiliate link", "affiliates.dashboard") if my_aff else None], "user"))
    return _tidy(t)

def _tidy(items):
    """Drop empty groups and collapse one-child groups to a plain link."""
    out = []
    for n in items:
        if not n: continue
        if n["kind"] == "group":
            n["children"] = _tidy(n["children"])
            if not n["children"]: continue
            if len(n["children"]) == 1 and n["children"][0]["kind"] == "link":
                c = n["children"][0]; c["icon"] = n["icon"] or c["icon"]; n = c
        out.append(n)
    return out

# ------------------------------------------------------------------------------------------------ student
def _student(u):
    b = _B(u); L = b.link; G = b.group
    n_unread = val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read_at IS NULL", (u["id"],), 0)
    my_aff = q1("SELECT id FROM affiliates WHERE user_id=?", (u["id"],))
    t = [L("Dashboard", "student.dashboard", "home"),
         G("My learning", [L("All my courses", "student.courses"),
                           *[L(P.name(k) if k != "income" else "Income Skills", "student.courses", path=k) for k in ("basic", "advanced", "professional", "income")],
                           L("Assessments", "student.assessments"), L("Assignments", "student.assignments"), L("Learning paths", "learnpaths.index"), L("Learning activity", "student.activity"), L("Certificates", "student.certificates")], "academics"),
         G("Faith & Growth", [L("My Faith learning", "faith.my"), L("Browse Faith", "faith.index")], "faith"),
         G("Payments", [L("Payments & subscriptions", "student.payments"), L("Plans & pricing", "public.pricing")], "payments"),
         L("Browse courses", "public.courses", "compass"),
         L("Notifications", "student.notifications", "bell", badge=n_unread)]
    if my_aff: t.append(L("Affiliate", "affiliates.dashboard", "affiliates"))
    app = q1("SELECT status FROM tutor_applications WHERE user_id=? AND kind='tutor' AND status IN ('draft','pending','revision') ORDER BY id DESC LIMIT 1", (u["id"],))
    t.append(L("Teach with us" if not app else "My tutor application", "tutors.apply", "compass", badge=1 if app and app["status"] == "revision" else 0))
    t.append(L("Profile settings", "auth.account", "user"))
    return _tidy(t)
