"""Server-side verification of Google Play and App Store purchases. The app only forwards the store's proof of purchase; this module asks the
store itself whether it is genuine. Without credentials every call raises StoreNotConfigured (the API answers 503): a purchase is NEVER
accepted on the app's word alone.

Needs the optional package `cryptography` (requirements-store.txt) and credentials you create in the store consoles (see docs/STORE_BILLING.md).
STATUS: written against the public Google Play Developer API v3 and App Store Server API docs and unit-tested only with a local fake store.
It has NOT been run against live Google/Apple (no credentials were available): test with licence-tester / sandbox accounts before release."""
import base64, json, os, time, urllib.request, urllib.parse, urllib.error
from datetime import datetime, timezone
from flask import current_app

class StoreNotConfigured(Exception): pass
class StoreRejected(Exception): pass          # the store says the purchase is not valid

def _cfg(k): return current_app.config.get(k) or os.environ.get(k, "")
def _b64u(b): return base64.urlsafe_b64encode(b).rstrip(b"=").decode()
def _b64d(s): return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))
def _http(url, headers=None, data=None, method=None):
    req = urllib.request.Request(url, data=data, headers=headers or {}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=15) as r: return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        if e.code in (400, 404, 410): raise StoreRejected(f"store answered {e.code}")
        raise StoreNotConfigured(f"store API error {e.code}")
    except (urllib.error.URLError, TimeoutError) as e: raise StoreNotConfigured(f"store API unreachable: {e}")
def _iso(ms): return datetime.fromtimestamp(int(ms) / 1000, timezone.utc).strftime("%Y-%m-%d %H:%M:%S") if ms else None

def verify(platform, payload):
    """payload: google_play -> {product_id, purchase_token, kind: 'subscription'|'product'}; app_store -> {transaction_id}.
    Returns {product_id, store_txn_id, original_txn_id, purchased_at, expires_at, environment, amount_micros, currency, state} with state 'active'|'expired'|'refunded'."""
    if platform == "google_play": return _google(payload)
    if platform == "app_store": return _apple(payload)
    raise StoreRejected("unknown platform")

# ---- Google Play ---------------------------------------------------------------------------------------------------------------------
def service_account_token(path, scope):
    """OAuth2 access token for a Google service-account JSON file (used for Play Developer API and Firebase Cloud Messaging)."""
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding
    except ImportError: raise StoreNotConfigured("the 'cryptography' package is not installed")
    sa = json.load(open(path)); now = int(time.time())
    head = _b64u(json.dumps({"alg": "RS256", "typ": "JWT"}).encode())
    claim = _b64u(json.dumps({"iss": sa["client_email"], "scope": scope, "aud": "https://oauth2.googleapis.com/token", "iat": now, "exp": now + 3000}).encode())
    key = serialization.load_pem_private_key(sa["private_key"].encode(), None)
    sig = _b64u(key.sign(f"{head}.{claim}".encode(), padding.PKCS1v15(), hashes.SHA256()))
    r = _http("https://oauth2.googleapis.com/token", {"Content-Type": "application/x-www-form-urlencoded"},
              urllib.parse.urlencode({"grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer", "assertion": f"{head}.{claim}.{sig}"}).encode(), "POST")
    return r["access_token"]

def _google_token():
    path, pkg = _cfg("GOOGLE_PLAY_SERVICE_ACCOUNT_FILE"), _cfg("GOOGLE_PLAY_PACKAGE_NAME")
    if not (path and pkg and os.path.exists(path)): raise StoreNotConfigured("Google Play credentials are not configured")
    return service_account_token(path, "https://www.googleapis.com/auth/androidpublisher"), pkg

def _google(p):
    tok, pkg = _google_token(); h = {"Authorization": f"Bearer {tok}"}; pt = urllib.parse.quote(str(p.get("purchase_token", "")), safe="")
    if not pt: raise StoreRejected("missing purchase token")
    if p.get("kind") == "subscription":
        d = _http(f"https://androidpublisher.googleapis.com/androidpublisher/v3/applications/{pkg}/purchases/subscriptionsv2/tokens/{pt}", h)
        li = (d.get("lineItems") or [{}])[0]; st = d.get("subscriptionState", "")
        exp = li.get("expiryTime", "")[:19].replace("T", " ") or None
        state = "active" if st in ("SUBSCRIPTION_STATE_ACTIVE", "SUBSCRIPTION_STATE_IN_GRACE_PERIOD", "SUBSCRIPTION_STATE_CANCELED") and exp and exp > datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S") else "expired"
        if d.get("canceledStateContext", {}).get("replacementCancellation") or st == "SUBSCRIPTION_STATE_PENDING": state = "expired"
        return dict(product_id=li.get("productId"), store_txn_id=(d.get("latestOrderId") or ""), original_txn_id=str(p["purchase_token"]), purchased_at=d.get("startTime", "")[:19].replace("T", " ") or None,
                    expires_at=exp, environment="sandbox" if d.get("testPurchase") else "production", amount_micros=None, currency=None, state=state)
    d = _http(f"https://androidpublisher.googleapis.com/androidpublisher/v3/applications/{pkg}/purchases/products/{urllib.parse.quote(str(p.get('product_id', '')), safe='')}/tokens/{pt}", h)
    if d.get("purchaseState") != 0: raise StoreRejected("purchase is not completed")             # 0 = purchased (1 cancelled, 2 pending)
    return dict(product_id=p["product_id"], store_txn_id=d.get("orderId") or "", original_txn_id=str(p["purchase_token"]), purchased_at=_iso(d.get("purchaseTimeMillis")), expires_at=None,
                environment="sandbox" if d.get("purchaseType") == 0 else "production", amount_micros=None, currency=None, state="active")

def google_acknowledge(product_kind, product_id, purchase_token):
    """Play refunds purchases that are not acknowledged within 3 days, so the server acknowledges after granting access."""
    try: tok, pkg = _google_token()
    except StoreNotConfigured: return                      # access is already granted; the next restore retries the acknowledgement
    h = {"Authorization": f"Bearer {tok}", "Content-Type": "application/json"}; pt = urllib.parse.quote(purchase_token, safe="")
    base = f"https://androidpublisher.googleapis.com/androidpublisher/v3/applications/{pkg}/purchases"
    url = f"{base}/subscriptions/{urllib.parse.quote(product_id, safe='')}/tokens/{pt}:acknowledge" if product_kind == "subscription" else f"{base}/products/{urllib.parse.quote(product_id, safe='')}/tokens/{pt}:acknowledge"
    try: _http(url, h, b"{}", "POST")
    except (StoreRejected, StoreNotConfigured): pass          # already acknowledged / transient: the next restore retries

# ---- Apple ---------------------------------------------------------------------------------------------------------------------------
def _apple_jwt():
    iss, kid, keyfile, bundle = _cfg("APPLE_IAP_ISSUER_ID"), _cfg("APPLE_IAP_KEY_ID"), _cfg("APPLE_IAP_PRIVATE_KEY_FILE"), _cfg("APPLE_BUNDLE_ID")
    if not (iss and kid and bundle and keyfile and os.path.exists(keyfile)): raise StoreNotConfigured("Apple In-App Purchase credentials are not configured")
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import ec, utils
    except ImportError: raise StoreNotConfigured("the 'cryptography' package is not installed")
    now = int(time.time()); head = _b64u(json.dumps({"alg": "ES256", "kid": kid, "typ": "JWT"}).encode())
    claim = _b64u(json.dumps({"iss": iss, "iat": now, "exp": now + 1200, "aud": "appstoreconnect-v1", "bid": bundle}).encode())
    key = serialization.load_pem_private_key(open(keyfile, "rb").read(), None)
    r, s = utils.decode_dss_signature(key.sign(f"{head}.{claim}".encode(), ec.ECDSA(hashes.SHA256())))
    return f"{head}.{claim}.{_b64u(r.to_bytes(32, 'big') + s.to_bytes(32, 'big'))}", bundle

def decode_apple_jws(jws, root_pem=None):
    """Verify an Apple-signed JWS (ES256, x5c chain) and return its payload. The chain is checked to Apple's root when APPLE_ROOT_CA_FILE is set."""
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import ec, utils
    h, c, s = jws.split("."); header = json.loads(_b64d(h)); chain = [x509.load_der_x509_certificate(base64.b64decode(x)) for x in header["x5c"]]
    sig = _b64d(s); der = utils.encode_dss_signature(int.from_bytes(sig[:32], "big"), int.from_bytes(sig[32:], "big"))
    chain[0].public_key().verify(der, f"{h}.{c}".encode(), ec.ECDSA(hashes.SHA256()))
    for child, parent in zip(chain, chain[1:]): child.verify_directly_issued_by(parent)
    if root_pem: chain[-1].verify_directly_issued_by(x509.load_pem_x509_certificate(root_pem)); assert chain[-1].fingerprint(hashes.SHA256()) == x509.load_pem_x509_certificate(root_pem).fingerprint(hashes.SHA256())
    return json.loads(_b64d(c))

def _apple(p):
    jwt, bundle = _apple_jwt(); tid = urllib.parse.quote(str(p.get("transaction_id", "")), safe="")
    if not tid: raise StoreRejected("missing transaction id")
    root = open(_cfg("APPLE_ROOT_CA_FILE"), "rb").read() if _cfg("APPLE_ROOT_CA_FILE") and os.path.exists(_cfg("APPLE_ROOT_CA_FILE")) else None
    d = None
    for host in ("api.storekit.itunes.apple.com", "api.storekit-sandbox.itunes.apple.com"):        # production first; sandbox for TestFlight/review purchases
        try: d = _http(f"https://{host}/inApps/v1/transactions/{tid}", {"Authorization": f"Bearer {jwt}"}); break
        except StoreRejected: continue
    if d is None: raise StoreRejected("transaction not found")
    t = decode_apple_jws(d["signedTransactionInfo"], root)
    if t.get("bundleId") != bundle: raise StoreRejected("transaction belongs to a different app")
    state = "refunded" if t.get("revocationDate") else ("expired" if t.get("expiresDate") and int(t["expiresDate"]) < time.time() * 1000 else "active")
    return dict(product_id=t.get("productId"), store_txn_id=str(t.get("transactionId")), original_txn_id=str(t.get("originalTransactionId")), purchased_at=_iso(t.get("purchaseDate")), expires_at=_iso(t.get("expiresDate")),
                environment=str(t.get("environment", "")).lower() or None, amount_micros=int(t["price"]) * 1000 if t.get("price") else None, currency=t.get("currency"), state=state)
