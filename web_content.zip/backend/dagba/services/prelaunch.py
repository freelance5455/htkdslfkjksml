"""Pre-Launch Mode: a switchable, date-driven gate in front of the whole site.

restricting() is True when the admin switch (prelaunch.enabled) is ON **and** the launch moment has not arrived. It is evaluated on every
request, so restrictions lift by themselves at the configured date and time, and every admin change applies immediately. No scheduler or
cron job is involved.

While restricting, only these people get through to the real site: administrators (always), and the roles listed in prelaunch.bypass_roles
(default instructors). Everyone else (public visitors, students) gets the countdown page, and every other URL redirects to it (or answers 403
to non-page requests). The gate lives in a Flask before_request hook, so direct URLs are protected on the server, not in the browser.
"""
import re
from datetime import datetime, timedelta, timezone
from flask import g, request, redirect, url_for, render_template, make_response, jsonify
from ..db import q, q1, ex, val
from . import settings as S

DEFAULT_LAUNCH = "2027-01-04T00:00"
DEFAULT_OFFSET = "+01:00"                       # West Africa Time (Lagos); a plain offset needs no tz database on the host
OFFSETS = [("+01:00", "West Africa Time, Lagos (UTC+01:00)"), ("+00:00", "UTC / GMT (UTC+00:00)"), ("+02:00", "Central / South Africa (UTC+02:00)"), ("+03:00", "East Africa Time (UTC+03:00)"),
           ("-05:00", "US Eastern, standard time (UTC-05:00)"), ("-08:00", "US Pacific, standard time (UTC-08:00)"), ("+05:30", "India (UTC+05:30)")]
ROLES = ("admin", "instructor", "writer", "student")
BYPASS_CHOICES = (("instructor", "Instructors"), ("writer", "Writers"))     # administrators always have access: they cannot be locked out
EMAIL = re.compile(r"[^@\s]+@[^@\s]+\.[^@\s]+")

# paths a visitor may always use while restricted (exact match, or prefix when it ends with "/")
ALWAYS = ("/pre-launch", "/prelaunch/subscribe", "/login", "/logout", "/forgot-password", "/reset-password/", "/static/", "/robots.txt", "/favicon.ico",
          "/terms-and-conditions", "/privacy-policy", "/refund-policy", "/delete-account", "/healthz", "/.well-known/", "/webhooks/", "/pay/callback/", "/api/v1/config", "/api/v1/auth/login", "/api/v1/auth/refresh", "/api/v1/auth/logout")
REGISTRATION = ("/register", "/api/v1/auth/register")

def _now(): return datetime.now(timezone.utc)

def _offset(s=None):
    s = s or S.get("prelaunch.utc_offset", DEFAULT_OFFSET)
    m = re.fullmatch(r"([+-])(\d{2}):(\d{2})", s or "")
    if not m: m = re.fullmatch(r"([+-])(\d{2}):(\d{2})", DEFAULT_OFFSET)
    mins = int(m[2]) * 60 + int(m[3]); mins = -mins if m[1] == "-" else mins
    return timezone(timedelta(minutes=mins))

def parse_launch(local, offset=None):
    """'YYYY-MM-DDTHH:MM' in the given UTC offset -> aware UTC datetime, or None when malformed."""
    try: return datetime.strptime((local or "").strip()[:16], "%Y-%m-%dT%H:%M").replace(tzinfo=_offset(offset)).astimezone(timezone.utc)
    except ValueError: return None

def launch_at():
    return parse_launch(S.get("prelaunch.launch_at", DEFAULT_LAUNCH)) or parse_launch(DEFAULT_LAUNCH, DEFAULT_OFFSET)

def enabled(): return S.flag("prelaunch.enabled")
def launched(): return _now() >= launch_at()
def restricting():
    """True while the site is closed to the public: the switch is on and the launch moment is still in the future."""
    return enabled() and not launched()

def bypass_roles():
    return {"admin"} | {r for r in (S.get("prelaunch.bypass_roles", "instructor") or "").split(",") if r in ROLES and r != "student"}

def can_bypass(user): return bool(user and user["role"] in bypass_roles())

def locked_for(user):
    """True when Pre-Launch Mode is closing the site to this visitor (used by templates to hide navigation that would only redirect)."""
    return restricting() and not can_bypass(user)

def launch_label():
    """Human-readable launch moment in the configured time zone, e.g. '4 January 2027, 00:00 (UTC+01:00)'."""
    local = launch_at().astimezone(_offset()); off = S.get("prelaunch.utc_offset", DEFAULT_OFFSET)
    return f"{local.day} {local.strftime('%B %Y, %H:%M')} (UTC{off})"

def is_allowed_path(path):
    if path == "/": return True
    for a in ALWAYS:
        if path == a or (a.endswith("/") and path.startswith(a)): return True
    if path in REGISTRATION and S.flag("prelaunch.register_enabled"): return True
    if path.startswith("/media/"):                                    # only the branding images the countdown page itself uses
        name = path[len("/media/"):]; return bool(name) and name in {S.get("brand.logo", ""), S.get("brand.favicon", ""), S.get("seo.og_image", "")}
    if path == "/theme.css": return True
    return False

def gate():
    """before_request: None to let the request continue, or a response that replaces it."""
    if not restricting(): return None
    if request.method == "OPTIONS" and request.path.startswith("/api/v1/"): return None       # CORS preflight from the app must succeed so the app can show the real reason
    if can_bypass(g.get("user")): return None
    path = request.path
    if path == "/" and request.method in ("GET", "HEAD"): return countdown_response()
    if is_allowed_path(path): return None
    if path.startswith("/api/v1/"):
        from . import mobile; return mobile.json_error(403, "Dagba Digital Academy has not launched yet.", "prelaunch")
    wants_page = request.method in ("GET", "HEAD") and request.headers.get("X-Requested-With") != "fetch" and "application/json" not in request.headers.get("Accept", "")
    if wants_page:
        r = redirect(url_for("public.home")); r.headers["Cache-Control"] = "no-store"; return r
    r = jsonify(ok=False, error="Dagba Digital Academy has not launched yet.", errors=["Dagba Digital Academy has not launched yet."]); r.status_code = 403
    r.headers["Cache-Control"] = "no-store"; return r

def countdown_response(preview=False):
    r = make_response(render_template("public/prelaunch.html", p=page_context(), preview=preview))
    r.headers["Cache-Control"] = "no-store"; r.headers["X-Robots-Tag"] = "noindex" if preview else "noarchive"; return r

def text(key, default=""):
    return S.get("prelaunch." + key, default)

def page_context():
    u = g.get("user"); name = (u["full_name"].split(" ")[0] if u and u["full_name"] else "")
    lt = launch_at()
    return dict(launch_iso=lt.strftime("%Y-%m-%dT%H:%M:%SZ"), now_ms=int(_now().timestamp() * 1000), launch_ms=int(lt.timestamp() * 1000), label=launch_label(),
                show_countdown=S.flag("prelaunch.show_countdown"), signup=S.flag("prelaunch.signup_enabled"), register=S.flag("prelaunch.register_enabled"),
                registered_text=text("registered_text").replace("{name}", name), user=u,
                social=[(k, S.get("social." + k)) for k in ("facebook", "instagram", "youtube", "x") if (S.get("social." + k) or "").startswith("https://")],
                whatsapp=re.sub(r"\D", "", S.get("contact.whatsapp", "") or ""))

# ---------------------------------------------------------------- early registrations
def record_email(email, name="", ip=None):
    """Add an address to the early-registration list. Returns True when it is new; the same address (any letter case) is stored once."""
    email = (email or "").strip().lower()
    if not EMAIL.fullmatch(email) or len(email) > 200: raise ValueError("Enter a valid email address.")
    u = q1("SELECT id FROM users WHERE email=?", (email,)); is_new = not val("SELECT 1 FROM prelaunch_signups WHERE email=?", (email,))
    ex("INSERT OR IGNORE INTO prelaunch_signups(email,name,source,user_id,ip_address) VALUES (?,?,?,?,?)", (email, (name or "").strip()[:120] or None, "account" if u else "email", u["id"] if u else None, ip))
    return is_new

def record_account(uid, email, name):
    """A new account was created while the site is closed: it is also an early registrant (idempotent; upgrades an email-only row)."""
    email = (email or "").strip().lower()
    ex("INSERT OR IGNORE INTO prelaunch_signups(email,name,source,user_id) VALUES (?,?,?,?)", (email, name[:120], "account", uid))
    ex("UPDATE prelaunch_signups SET user_id=?, source='account', name=COALESCE(name, ?) WHERE email=? AND user_id IS NULL", (uid, name[:120], email))

LIST_SQL = """SELECT * FROM (
  SELECT s.id AS sid, s.email, COALESCE(s.name, u.full_name) AS name, CASE WHEN s.user_id IS NULL THEN 'email' ELSE 'account' END AS source, s.created_at, s.user_id
    FROM prelaunch_signups s LEFT JOIN users u ON u.id=s.user_id
  UNION ALL
  SELECT NULL, u.email, u.full_name, 'account', u.created_at, u.id FROM users u WHERE u.role='student' AND lower(u.email) NOT IN (SELECT lower(email) FROM prelaunch_signups)
) """

def _like(s): return "%" + s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"

def list_query(args):
    where, a = ["1=1"], []
    term = (args.get("q") or "").strip()[:100]
    if term: where.append("(email LIKE ? ESCAPE '\\' OR name LIKE ? ESCAPE '\\')"); a += [_like(term)] * 2
    if args.get("source") in ("email", "account"): where.append("source=?"); a.append(args["source"])
    return LIST_SQL + " WHERE " + " AND ".join(where) + " ORDER BY created_at DESC, email", tuple(a)

def counts():
    return dict(emails=val("SELECT COUNT(*) FROM prelaunch_signups WHERE user_id IS NULL", default=0), accounts=val("SELECT COUNT(*) FROM users WHERE role='student'", default=0),
                total=val("SELECT COUNT(*) FROM (" + LIST_SQL + ")", default=0))
