"""Icon registry (a curated subset of Lucide, ISC licence: https://lucide.dev) and the admin-controlled Intro Card icons.

Intro cards live in the existing setting `c.home.what_cards`, one card per line:  Title | Text | /link | Link label | icon
The optional 5th field is the chosen icon's name. Without it the card keeps the automatic icon the site always used (chosen from the
card's title/link), so "restore default icons" simply clears that 5th field. Nothing else about a card changes."""
import json, os
from functools import lru_cache
from markupsafe import Markup
from . import settings as S, content as C

PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static", "icons", "lucide-subset.json")
KEY = "home.what_cards"

@lru_cache(maxsize=1)
def _icons():
    with open(PATH, encoding="utf-8") as fh: return {i["n"]: i for i in json.load(fh)["icons"]}

def catalog(): return list(_icons().values())
def valid(name): return bool(name) and name in _icons()

def lucide(name, cls="ico"):
    """Inline SVG for an icon name ('' when unknown). Same size/stroke conventions as the site's other line icons."""
    i = _icons().get(name or "")
    if not i: return Markup("")
    return Markup(f'<svg class="{cls}" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">{i["s"]}</svg>')

def label(name): return name.replace("-", " ") if name else ""

def _split(line): return [p.strip() for p in line.split("|")]

def intro_cards():
    """The homepage intro cards as dicts (i = position): title, text, link, label and the chosen icon ('' = automatic default)."""
    out = []
    for i, p in enumerate(C.cl(KEY)):
        p = p + [""] * (5 - len(p))
        out.append(dict(i=i, title=p[0], text=p[1], link=p[2], label=p[3], icon=p[4] if valid(p[4]) else ""))
    return out

def _write(icons):
    """Rewrite the stored card list with `icons` (one per card, '' = automatic). Titles, texts, links and labels are untouched."""
    lines = []
    for n, p in enumerate(C.cl(KEY)):
        p = (p + [""] * 4)[:4]
        ic = icons[n] if n < len(icons) else ""
        lines.append(" | ".join(p + ([ic] if ic else [])))
    S.put("c." + KEY, "\n".join(lines))

def save_intro_icons(icons, titles):
    """Persist the chosen icons. Returns an error message or None. `titles` guards against saving over cards edited in the meantime."""
    cards = intro_cards()
    if len(icons) != len(cards) or [c["title"] for c in cards] != list(titles): return "The intro cards changed while you were editing. Reload the page and try again."
    bad = [i for i in icons if i and not valid(i)]
    if bad: return "Unknown icon: " + bad[0]
    _write(icons); return None

def reset_intro_icons():
    _write([""] * len(C.cl(KEY)))
