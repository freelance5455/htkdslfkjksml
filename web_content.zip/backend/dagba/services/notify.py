import smtplib, logging, ssl
from email.message import EmailMessage
from flask import current_app
from ..db import q, ex

log = logging.getLogger("dagba.notify")

def send_email(to, subject, body):
    """Best-effort. Never raises: core workflows must not depend on email delivery."""
    c = current_app.config
    if not (c.get("SMTP_HOST") and c.get("SMTP_FROM")): return False
    try:
        m = EmailMessage(); m["From"] = c["SMTP_FROM"]; m["To"] = to; m["Subject"] = subject; m.set_content(body)
        with smtplib.SMTP(c["SMTP_HOST"], c["SMTP_PORT"], timeout=10) as s:
            s.starttls(context=ssl.create_default_context())
            if c.get("SMTP_USER"): s.login(c["SMTP_USER"], c["SMTP_PASSWORD"])
            s.send_message(m)
        return True
    except Exception as e:  # noqa
        log.warning("email to %s failed: %s", to, e); return False

def notify(user_id, title, body="", link=None, kind="info", email=False):
    try:
        ex("INSERT INTO notifications(user_id, kind, title, body, link) VALUES (?,?,?,?,?)", (user_id, kind, title, body, link))
        try:
            from . import push; push.send_async(user_id, title, body, link, kind)      # phones with the app installed; best-effort, never blocks or fails the notification
        except Exception: pass
        if email:
            u = q("SELECT email FROM users WHERE id=?", (user_id,))
            if u: send_email(u[0]["email"], title, f"{body}\n\n{(current_app.config['SITE_URL'] + link) if link else ''}")
    except Exception as e:  # noqa
        log.error("notification failed: %s", e)

def staff_with(perm):
    """Owner(s) plus admins holding `perm`."""
    return [r["id"] for r in q(
        "SELECT id FROM users WHERE is_active=1 AND role='admin' AND (is_owner=1 OR id IN (SELECT user_id FROM user_permissions WHERE permission=?))", (perm,))]

def notify_staff(perm, title, body="", link=None, kind="info"):
    for uid in staff_with(perm): notify(uid, title, body, link, kind)
