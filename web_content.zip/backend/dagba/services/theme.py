"""Whole-site theme: colours, fonts, corner roundness, layout width, hero style, motion and optional custom CSS.

Everything is stored as ordinary settings and served as /theme.css, which loads AFTER app.css and overrides its :root defaults.
The defaults below are exactly the values the stylesheet shipped with, so nothing changes until an admin saves a change.
Colours that depend on others (text on the dark header, soft tints, borders, glows...) are COMPUTED here, never typed in, so any palette
stays readable: light text on dark colours, dark text on light ones."""
import re, time
from ..db import ex
from . import settings

HEX = re.compile(r"#[0-9a-fA-F]{6}")

# key, label, default, help
COLOURS = [
    ("brand.primary", "Primary colour", "#7236E6", "Buttons, links and highlights."),
    ("brand.dark", "Header, footer & banner colour", "#1b1230", "The bar at the top, the footer and the numbers strip."),
    ("brand.accent", "Accent colour", "#2563eb", "Second colour used in gradients, underlines and focus rings."),
    ("theme.hero_mid", "Home-page banner: middle colour", "#3b1d8f", "The banner blends header colour, this colour and the primary colour."),
    ("theme.bg", "Page background", "#faf9ff", ""),
    ("theme.surface", "Cards, tables & forms", "#ffffff", "The background of boxes that sit on the page."),
    ("theme.text", "Body text", "#1f1b2e", ""),
    ("theme.heading", "Headings", "#1b1230", "Ignored while 'same as header colour' is ticked."),
    ("theme.muted", "Secondary text", "#6b6880", "Captions, hints and small print."),
    ("theme.line", "Borders", "#e6e1f7", "Lines around cards, tables and menus."),
    ("theme.tint", "Soft highlight", "#efe9ff", "Badges, the active menu item and gentle backgrounds."),
]
FONTS = {  # system fonts only: no downloads, works offline and under the site's strict security policy
    "system": ("Modern (device default)", 'system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif'),
    "clean": ("Clean (Helvetica / Arial)", '"Helvetica Neue",Helvetica,Arial,sans-serif'),
    "humanist": ("Friendly (Segoe / Trebuchet)", '"Segoe UI",Candara,"Trebuchet MS",Optima,sans-serif'),
    "rounded": ("Rounded", 'ui-rounded,"SF Pro Rounded",Nunito,"Varela Round",system-ui,sans-serif'),
    "classic": ("Classic serif (Georgia)", 'Georgia,"Times New Roman",Times,serif'),
    "mono": ("Typewriter (monospace)", 'ui-monospace,"SFMono-Regular",Menlo,Consolas,monospace'),
}
RADII = {  # label, (lg, m2, md, sm, xl, btn)
    "square": ("Square corners", (0, 0, 0, 0, 0, 0)),
    "slight": ("Slightly rounded", (6, 5, 4, 3, 8, 4)),
    "default": ("Rounded (default)", (14, 12, 10, 8, 16, 10)),
    "very": ("Very rounded", (22, 19, 16, 12, 26, 16)),
}
WIDTHS = {"narrow": ("Narrow (960 px)", 960), "standard": ("Standard (1120 px)", 1120), "wide": ("Wide (1280 px)", 1280), "full": ("Extra wide (1440 px)", 1440)}
HEROES = {"gradient": "Colour blend (default)", "dark": "Solid header colour", "brand": "Solid primary colour"}
SIZES = (14, 15, 16, 17, 18, 19, 20)

DEFAULTS = {k: d for k, _l, d, _h in COLOURS}
DEFAULTS.update({"theme.heading_same": "1", "theme.font_body": "system", "theme.font_heading": "same", "theme.font_size": "16", "theme.radius": "default", "theme.width": "standard",
                 "theme.pill": "0", "theme.hero": "gradient", "theme.sticky": "1", "theme.motion": "1", "theme.custom_css": "",
                 "theme.mode_button": "1", "theme.mode_default": "light"})
KEYS = list(DEFAULTS)
FLAGS = ("theme.heading_same", "theme.pill", "theme.sticky", "theme.motion", "theme.mode_button")

PRESETS = {
    "Dagba purple (original)": {k: DEFAULTS[k] for k in DEFAULTS if k.startswith(("brand.", "theme.")) and k not in ("theme.custom_css",)},
    "Ocean blue": {"brand.primary": "#0369a1", "brand.dark": "#082f49", "brand.accent": "#0891b2", "theme.hero_mid": "#0c4a6e", "theme.bg": "#f5faff", "theme.surface": "#ffffff", "theme.text": "#1e293b",
                   "theme.muted": "#5b6b7f", "theme.line": "#d6e6f2", "theme.tint": "#e0f2fe", "theme.heading_same": "1"},
    "Emerald": {"brand.primary": "#047857", "brand.dark": "#052e1f", "brand.accent": "#0d9488", "theme.hero_mid": "#065f46", "theme.bg": "#f6fbf8", "theme.surface": "#ffffff", "theme.text": "#1c2b25",
                "theme.muted": "#586b61", "theme.line": "#d5e8de", "theme.tint": "#d1fae5", "theme.heading_same": "1"},
    "Sunset": {"brand.primary": "#c2410c", "brand.dark": "#3b1308", "brand.accent": "#be185d", "theme.hero_mid": "#9a3412", "theme.bg": "#fffaf5", "theme.surface": "#ffffff", "theme.text": "#2b1d14",
               "theme.muted": "#7a5f4e", "theme.line": "#f1dfcf", "theme.tint": "#ffedd5", "theme.heading_same": "1"},
    "Slate & gold": {"brand.primary": "#b45309", "brand.dark": "#111827", "brand.accent": "#0f766e", "theme.hero_mid": "#1f2937", "theme.bg": "#fafaf9", "theme.surface": "#ffffff", "theme.text": "#1c1917",
                     "theme.muted": "#6b625c", "theme.line": "#e7e5e4", "theme.tint": "#fef3c7", "theme.heading_same": "1", "theme.font_heading": "classic"},
    "Midnight (dark mode)": {"brand.primary": "#a78bfa", "brand.dark": "#0a0716", "brand.accent": "#38bdf8", "theme.hero_mid": "#2e1065", "theme.bg": "#0f0b1e", "theme.surface": "#1a1530", "theme.text": "#e8e4f5",
                             "theme.heading": "#ffffff", "theme.heading_same": "0", "theme.muted": "#a9a3c4", "theme.line": "#2e2750", "theme.tint": "#2a2150"},
}

# ------------------------------------------------------------------ colour maths
def _rgb(h): h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
def _hex(c): return "#%02x%02x%02x" % tuple(max(0, min(255, int(round(v)))) for v in c)
def mix(a, b, t):
    """Colour a moved a fraction t of the way towards colour b."""
    x, y = _rgb(a), _rgb(b); return _hex([x[i] + (y[i] - x[i]) * t for i in range(3)])
def lum(h):
    f = lambda v: (v / 255 / 12.92) if v / 255 <= 0.03928 else (((v / 255) + 0.055) / 1.055) ** 2.4
    r, g, b = (f(v) for v in _rgb(h)); return 0.2126 * r + 0.7152 * g + 0.0722 * b
def contrast(a, b):
    la, lb = sorted((lum(a), lum(b)), reverse=True); return (la + 0.05) / (lb + 0.05)
INK = "#050308"
def on_colour(bg):
    """White or near-black, whichever reads better on `bg`."""
    return "#ffffff" if contrast("#ffffff", bg) >= contrast(INK, bg) else INK
def rgba(h, a): r, g, b = _rgb(h); return f"rgba({r},{g},{b},{a:g})".replace(",0.", ",.")

# ------------------------------------------------------------------ reading & validating
def current():
    """Effective theme values: saved settings over defaults. Bad stored values fall back to the default."""
    out = {}
    for k, d in DEFAULTS.items():
        v = settings.get(k, d)
        out[k] = v if _valid(k, v) else d
    return out

def _valid(k, v):
    if k in dict((c[0], 1) for c in COLOURS): return bool(HEX.fullmatch(v or ""))
    if k in FLAGS: return v in ("0", "1")
    if k in ("theme.font_body",): return v in FONTS
    if k == "theme.font_heading": return v == "same" or v in FONTS
    if k == "theme.font_size": return v.isdigit() and int(v) in SIZES
    if k == "theme.radius": return v in RADII
    if k == "theme.width": return v in WIDTHS
    if k == "theme.hero": return v in HEROES
    if k == "theme.mode_default": return v in ("light", "auto")
    if k == "theme.custom_css": return isinstance(v, str) and len(v) <= 20000
    return False

def from_form(form):
    """Parse a submitted form into (values, errors). Unticked checkboxes are 0. Never raises."""
    vals, errs = {}, []
    label = {c[0]: c[1] for c in COLOURS}
    for k, d in DEFAULTS.items():
        if k in FLAGS: vals[k] = "1" if form.get(k) in ("1", "on", "true") else "0"; continue
        raw = (form.get(k) if form.get(k) is not None else d)
        raw = raw.strip() if k != "theme.custom_css" else raw.replace("\r\n", "\n")
        if k in label: raw = raw.lower()
        if not _valid(k, raw):
            errs.append(f"'{label.get(k, k.replace('theme.', '').replace('_', ' ').title())}' is not valid.")
            raw = d
        vals[k] = raw
    css = vals["theme.custom_css"]
    if css.count("{") != css.count("}"): errs.append("Custom CSS has unmatched curly brackets { }. Nothing was saved."); vals["theme.custom_css"] = DEFAULTS["theme.custom_css"]
    return vals, errs

# ------------------------------------------------------------------ computing CSS variables
def variables(v, only_changed=True):
    """CSS custom properties for the values `v`. With only_changed, anything identical to the stylesheet default is left out."""
    c = {k: v[k] for k in DEFAULTS if k in dict((x[0], 1) for x in COLOURS)}
    dark, brand, surf, text, line, tint = c["brand.dark"], c["brand.primary"], c["theme.surface"], c["theme.text"], c["theme.line"], c["theme.tint"]
    heading = dark if v["theme.heading_same"] == "1" else c["theme.heading"]
    mid = c["theme.hero_mid"]
    if v["theme.hero"] == "dark": stops = (dark,)
    elif v["theme.hero"] == "brand": stops = (brand,)
    else: stops = (dark, mid, brand)
    herobg = _hex([sum(_rgb(s)[i] for s in stops) / len(stops) for i in range(3)])
    od, oh = on_colour(dark), on_colour(herobg)
    out = {
        "--brand": brand, "--dark": dark, "--accent": c["brand.accent"], "--hero-mid": mid, "--bg": c["theme.bg"], "--surface": surf, "--text": text, "--heading": heading,
        "--muted": c["theme.muted"], "--line": line, "--tint": tint,
        "--tint-soft": mix(tint, surf, .27), "--tint-faint": mix(tint, surf, .68), "--line-strong": mix(line, text, .11), "--line-soft": mix(line, surf, .45),
        "--on-brand": on_colour(brand), "--on-dark": od, "--on-dark-soft": mix(od, brand, .12), "--on-dark-dim": mix(mix(od, brand, .2), dark, .08), "--on-dark-hi": mix(brand, od, .6),
        "--on-dark-line": rgba(od, .4), "--on-dark-line1": rgba(od, .33), "--on-dark-line2": rgba(od, .13), "--on-hero-line": rgba(oh, .4),
        "--on-dark-hi2": mix(c["brand.accent"], od, .6), "--on-hero-hi2": mix(c["brand.accent"], oh, .6), "--field-text": "#000000" if text == DEFAULTS["theme.text"] else text, "--on-hero": oh, "--on-hero-soft": mix(oh, brand, .16), "--on-hero-hi": mix(brand, oh, .6),
        "--glow": rgba(brand, .18), "--glow2": rgba(brand, .28),
        "--font": FONTS[v["theme.font_body"]][1],
        "--font-h": FONTS[v["theme.font_body"] if v["theme.font_heading"] == "same" else v["theme.font_heading"]][1],
        "--fs": f"{v['theme.font_size']}px", "--wrap": f"{WIDTHS[v['theme.width']][1]}px",
    }
    lg, m2, md, sm, xl, btn = RADII[v["theme.radius"]][1]
    out.update({"--r-lg": f"{lg}px", "--r-m2": f"{m2}px", "--r-md": f"{md}px", "--r-sm": f"{sm}px", "--r-xl": f"{xl}px", "--r-btn": "999px" if v["theme.pill"] == "1" else f"{btn}px"})
    if only_changed:
        base = variables(_defaults_theme(), only_changed=False)
        out = {k: x for k, x in out.items() if x != base[k]}
    return out

def _defaults_theme(): return dict(DEFAULTS)

# ------------------------------------------------------------------ dark mode
def _lighten_until(c, bg, ratio):
    for _ in range(16):
        if contrast(c, bg) >= ratio: break
        c = mix(c, "#ffffff", .08)
    return c

def dark_values(v):
    """The dark-mode version of theme values `v`: near-black surfaces tinted with the primary colour, light text, and primary/accent
    colours lightened just enough to stay readable on dark backgrounds. Everything else (fonts, shape, width...) is unchanged."""
    brand, base = v["brand.primary"], "#0b0a10"
    bg, surf, text = mix(base, brand, .08), mix(base, brand, .16), mix("#ffffff", brand, .06)
    d = dict(v)
    d.update({"theme.bg": bg, "theme.surface": surf, "theme.text": text, "theme.heading": mix("#ffffff", brand, .02), "theme.heading_same": "0", "theme.muted": mix(text, bg, .38),
              "theme.line": mix(bg, brand, .30), "theme.tint": mix(bg, brand, .26), "brand.dark": mix("#050308", brand, .08)})
    d["brand.primary"] = _lighten_until(brand, surf, 4.5)
    d["brand.accent"] = _lighten_until(v["brand.accent"], bg, 3.0)
    d["theme.hero_mid"] = mix(d["brand.dark"], d["brand.primary"], .35)
    return d

def dark_css(v):
    """Rule applied when a visitor switches to dark mode (html[data-mode=dark]). Only values that differ from light mode are emitted."""
    light, dark = variables(v, only_changed=False), variables(dark_values(v), only_changed=False)
    diff = {k: x for k, x in dark.items() if light.get(k) != x}
    return "html[data-mode=dark]{" + ";".join(f"{k}:{x}" for k, x in diff.items()) + ";color-scheme:dark}"

def show_toggle():
    """Whether the header shows the light/dark switch: enabled by the admin AND the site's own theme is light (a dark theme has nothing to switch to)."""
    if not settings.flag("theme.mode_button"): return False
    bg = settings.get("theme.bg", DEFAULTS["theme.bg"])
    return lum(bg if HEX.fullmatch(bg or "") else DEFAULTS["theme.bg"]) > .18

def mode_default():
    d = settings.get("theme.mode_default", "light"); return d if d in ("light", "auto") else "light"

def css():
    """The full /theme.css text for the saved theme."""
    v = current(); parts = []
    vs = variables(v)
    if vs: parts.append(":root{" + ";".join(f"{k}:{x}" for k, x in vs.items()) + "}")
    parts.append(dark_css(v))
    if v["theme.sticky"] != "1": parts.append("header.site{position:static}")
    if v["theme.hero"] == "dark": parts.append(".hero{background:var(--dark);animation:none}")
    elif v["theme.hero"] == "brand": parts.append(".hero{background:var(--brand);animation:none}")
    if v["theme.motion"] != "1":
        parts.append("*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}html{scroll-behavior:auto}.reveal{opacity:1!important;transform:none!important}"
                     ".js .tcar .tcard{opacity:1!important;transform:none!important}.amedia img{opacity:1!important;transform:none!important}.marquee .track{width:auto;flex-wrap:wrap}")
    if v["theme.custom_css"].strip(): parts.append("/* custom */\n" + v["theme.custom_css"])
    return "\n".join(parts) + "\n"

def warnings(v):
    """Readability problems in a palette, in plain words."""
    heading = v["brand.dark"] if v["theme.heading_same"] == "1" else v["theme.heading"]
    checks = [("Body text", v["theme.text"], v["theme.bg"], "the page background"), ("Body text", v["theme.text"], v["theme.surface"], "cards and forms"),
              ("Headings", heading, v["theme.bg"], "the page background"), ("Headings", heading, v["theme.surface"], "cards and forms"),
              ("Secondary text", v["theme.muted"], v["theme.bg"], "the page background"), ("Links and buttons (primary colour)", v["brand.primary"], v["theme.bg"], "the page background"),
              ("Primary colour", v["brand.primary"], v["theme.surface"], "cards and forms")]
    out = []
    for name, fg, bg, where in checks:
        r = contrast(fg, bg)
        if r < 4.5: out.append(f"{name} on {where} is hard to read (contrast {r:.1f}:1; aim for 4.5:1 or more).")
    return out

# ------------------------------------------------------------------ saving
def save(vals):
    """Write every theme setting, remember what changed (for the audit log) and bump the cache-busting revision."""
    changed = []
    for k in KEYS:
        if settings.get(k, DEFAULTS[k]) != vals[k]: changed.append(k)
        settings.put(k, vals[k])
    settings.put("theme.rev", str(int(time.time() * 1000)))
    return changed

def reset():
    for k in KEYS: ex("DELETE FROM settings WHERE key=?", (k,))
    settings.clear_cache()
    settings.put("theme.rev", str(int(time.time() * 1000)))
