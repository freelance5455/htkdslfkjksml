"""Faith & Spiritual Growth: topics, series and lessons (video, audio, reading, study guides) with learner progress.
It lives inside the same accounts, uploads, admin and theme as the rest of the academy; it has its own small set of tables
so course certificates, payments and reports are not affected."""
import os, re
from flask import current_app
from ..db import get_db, q, q1, ex, val
from ..util import now, unique_slug, embed_url
from . import settings, audit, builder as B

KINDS = {"video": "Video", "audio": "Audio", "reading": "Reading", "study": "Study guide"}
ACCESS = {"public": "Free preview: anyone can open it, no account needed", "members": "Course content: needs sign-in, and purchase if the series is paid"}
STATUSES = ("draft", "published", "archived")
# Built-in icons an admin can give a topic (drawn in templates/_icons.html; keep the two lists in step).
TOPIC_ICONS = [("book", "Bible / study"), ("cross", "Cross"), ("prayer", "Prayer"), ("growth", "Growth"), ("heart", "Heart"), ("users", "People"),
               ("wisdom", "Wisdom"), ("home", "Home / family"), ("star", "Star"), ("light", "Light"), ("worship", "Worship"), ("mission", "World / mission")]
AUDIO_MIME = B.AUDIO_EXT

class FaithError(Exception):
    def __init__(self, msg, status=400, **extra): super().__init__(msg); self.status = status; self.extra = extra

def _priv(): return current_app.config["PRIVATE_DIR"]
def _s(v, n): return (v if isinstance(v, str) else "").strip()[:n]
def _i(v):
    try: return int(v)
    except (TypeError, ValueError): return None

# ------------------------------------------------------------------ reading
def topics(with_counts=True, active_only=True):
    rows = q("SELECT * FROM faith_topics" + (" WHERE active=1" if active_only else "") + " ORDER BY position, name")
    out = []
    for t in rows:
        d = dict(t)
        if with_counts:
            d["n"] = val("SELECT COUNT(*) FROM faith_items WHERE topic_id=? AND status='published'", (t["id"],), 0)
            d["series_n"] = val("SELECT COUNT(*) FROM faith_series s WHERE s.topic_id=? AND s.status='published' AND EXISTS (SELECT 1 FROM faith_items i WHERE i.series_id=s.id AND i.status='published')", (t["id"],), 0)
        out.append(d)
    return out

def topic_by_slug(slug): return q1("SELECT * FROM faith_topics WHERE slug=? AND active=1", (slug,))
def has_content(): return bool(val("SELECT 1 FROM faith_items WHERE status='published' LIMIT 1"))

ITEM_SELECT = """SELECT i.*, t.name AS topic, t.slug AS topic_slug, s.title AS series, s.slug AS series_slug, COALESCE(s.price_kobo,0) AS series_price, COALESCE(t.price_kobo,0) AS topic_price
                 FROM faith_items i JOIN faith_topics t ON t.id=i.topic_id LEFT JOIN faith_series s ON s.id=i.series_id"""

def item_by_slug(slug): return q1(ITEM_SELECT + " WHERE i.slug=?", (slug,))
def item_by_id(iid): return q1(ITEM_SELECT + " WHERE i.id=?", (iid,))

def kind_counts():
    c = {r["kind"]: r["n"] for r in q("SELECT kind, COUNT(*) n FROM faith_items WHERE status='published' GROUP BY kind")}
    return {k: c.get(k, 0) for k in KINDS}

def series_progress(uid, series_id):
    total = val("SELECT COUNT(*) FROM faith_items WHERE series_id=? AND status='published'", (series_id,), 0)
    done = val("SELECT COUNT(*) FROM faith_progress p JOIN faith_items i ON i.id=p.item_id WHERE p.user_id=? AND i.series_id=? AND i.status='published' AND p.completed_at IS NOT NULL", (uid, series_id), 0) if uid else 0
    return dict(total=total, done=done, percent=int(done * 100 / total) if total else 0)

def done_ids(uid, item_ids=None):
    if not uid: return set()
    return {r["item_id"] for r in q("SELECT item_id FROM faith_progress WHERE user_id=? AND completed_at IS NOT NULL", (uid,))}

def saved_ids(uid):
    return {r["item_id"] for r in q("SELECT item_id FROM faith_saved WHERE user_id=?", (uid,))} if uid else set()

def continue_items(uid, limit=4):
    """Lessons the learner started but has not finished, most recent first."""
    if not uid: return []
    return q(ITEM_SELECT + """ JOIN faith_progress p ON p.item_id=i.id AND p.user_id=? WHERE i.status='published' AND p.completed_at IS NULL
                              ORDER BY p.updated_at DESC LIMIT ?""", (uid, limit))

def neighbours(item):
    """Previous/next published lesson in the same series (by order, then id)."""
    if not item["series_id"]: return None, None
    rows = q("SELECT id, title, slug, access FROM faith_items WHERE series_id=? AND status='published' ORDER BY position, id", (item["series_id"],))
    ids = [r["id"] for r in rows]
    if item["id"] not in ids: return None, None
    k = ids.index(item["id"])
    return (rows[k - 1] if k else None), (rows[k + 1] if k + 1 < len(rows) else None)

def related(item, limit=3):
    return q(ITEM_SELECT + " WHERE i.status='published' AND i.topic_id=? AND i.id!=? AND COALESCE(i.series_id,0)!=COALESCE(?,-1) ORDER BY i.featured DESC, COALESCE(i.published_at,i.created_at) DESC LIMIT ?",
             (item["topic_id"], item["id"], item["series_id"], limit))

def series_entitled(uid, series_id):
    """True when the learner has an active (paid, not revoked, not expired) purchase of this series."""
    return bool(uid and series_id and val("""SELECT 1 FROM faith_access WHERE user_id=? AND series_id=? AND revoked_at IS NULL
                                              AND (expires_at IS NULL OR expires_at > ?)""", (uid, series_id, now())))

def topic_entitled(uid, topic_id):
    return bool(uid and topic_id and val("""SELECT 1 FROM faith_access WHERE user_id=? AND topic_id=? AND revoked_at IS NULL
                                             AND (expires_at IS NULL OR expires_at > ?)""", (uid, topic_id, now())))

def owned_series_ids(uid):
    if not uid: return set()
    return {r["series_id"] for r in q("SELECT series_id FROM faith_access WHERE user_id=? AND series_id IS NOT NULL AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > ?)", (uid, now()))}

def owned_topic_ids(uid):
    if not uid: return set()
    return {r["topic_id"] for r in q("SELECT topic_id FROM faith_access WHERE user_id=? AND topic_id IS NOT NULL AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > ?)", (uid, now()))}

def purchased_series(uid):
    return q("""SELECT s.*, t.name AS topic, t.slug AS topic_slug, a.expires_at AS access_until,
                (SELECT COUNT(*) FROM faith_items i WHERE i.series_id=s.id AND i.status='published') AS n
                FROM faith_access a JOIN faith_series s ON s.id=a.series_id JOIN faith_topics t ON t.id=s.topic_id
                WHERE a.user_id=? AND a.revoked_at IS NULL AND (a.expires_at IS NULL OR a.expires_at > ?) ORDER BY a.starts_at DESC""", (uid, now())) if uid else []

def purchased_topics(uid):
    return q("""SELECT t.*, a.expires_at AS access_until,
                (SELECT COUNT(*) FROM faith_items i WHERE i.topic_id=t.id AND i.status='published') AS n
                FROM faith_access a JOIN faith_topics t ON t.id=a.topic_id
                WHERE a.user_id=? AND a.revoked_at IS NULL AND (a.expires_at IS NULL OR a.expires_at > ?) ORDER BY a.starts_at DESC""", (uid, now())) if uid else []

def item_state(item, uid, owned=None, manage=False, owned_topics=None):
    """What the visitor can do with a published lesson: 'open' | 'signin' (free but needs an account) | 'buy' (needs a purchase).
    Free previews are always open. A lesson needs a purchase when its series or its topic has a price; owning either unlocks it.
    Faith managers can open everything."""
    if item["access"] == "public" or manage: return "open"
    sp, tp = (item["series_price"] or 0) > 0 and item["series_id"], (item["topic_price"] or 0) > 0
    if sp or tp:
        if not uid: return "buy"
        owned = owned_series_ids(uid) if owned is None else owned
        owned_topics = owned_topic_ids(uid) if owned_topics is None else owned_topics
        return "open" if (sp and item["series_id"] in owned) or (tp and item["topic_id"] in owned_topics) else "buy"
    return "open" if uid else "signin"

def can_view(user, item, manage=False):
    """Drafts and archived lessons are visible to faith managers only; other lessons follow item_state."""
    if item["status"] != "published": return manage
    return item_state(item, user["id"] if user else None, None, manage) == "open"

def stats():
    return dict(
        topics=val("SELECT COUNT(*) FROM faith_topics WHERE active=1", default=0),
        series=val("SELECT COUNT(*) FROM faith_series WHERE status='published'", default=0),
        published=val("SELECT COUNT(*) FROM faith_items WHERE status='published'", default=0),
        drafts=val("SELECT COUNT(*) FROM faith_items WHERE status='draft'", default=0),
        videos=val("SELECT COUNT(*) FROM faith_items WHERE status='published' AND kind='video'", default=0),
        audios=val("SELECT COUNT(*) FROM faith_items WHERE status='published' AND kind='audio'", default=0),
        paid_series=val("SELECT COUNT(*) FROM faith_series WHERE status='published' AND price_kobo>0", default=0),
        paid_topics=val("SELECT COUNT(*) FROM faith_topics WHERE active=1 AND price_kobo>0", default=0),
        unpriced_series=val("SELECT COUNT(*) FROM faith_series WHERE status='published' AND price_kobo=0", default=0),
        students=val("SELECT COUNT(DISTINCT user_id) FROM faith_access WHERE revoked_at IS NULL", default=0),
        revenue=val("SELECT COALESCE(SUM(amount_kobo),0) FROM transactions WHERE item_type IN ('faith','faith_topic') AND status='approved'", default=0),
        learners=val("SELECT COUNT(DISTINCT user_id) FROM faith_progress", default=0),
        completions=val("SELECT COUNT(*) FROM faith_progress WHERE completed_at IS NOT NULL", default=0),
        media_bytes=val("SELECT COALESCE(SUM(size),0) FROM uploads WHERE status='ready' AND kind IN ('video','audio') AND stored_name IN (SELECT video_file FROM faith_items UNION SELECT audio_file FROM faith_items)", default=0))

# ------------------------------------------------------------------ saving (admin)
def load_item(iid):
    r = q1("SELECT * FROM faith_items WHERE id=?", (iid,))
    keys = ("id", "title", "topic_id", "series_id", "kind", "summary", "body", "scripture", "speaker", "video_url", "video_file", "video_name", "audio_url", "audio_file", "audio_name",
            "resource_file", "resource_name", "thumbnail", "duration_min", "position", "access", "downloadable", "featured", "status", "slug")
    d = {k: (r[k] if r[k] is not None else "") for k in keys}
    d["downloadable"] = bool(r["downloadable"]); d["featured"] = bool(r["featured"]); d["id"] = r["id"]
    return d

def blank_item(topic_id="", series_id=""):
    return dict(id=None, title="", topic_id=topic_id, series_id=series_id, kind="video", summary="", body="", scripture="", speaker="", video_url="", video_file="", video_name="", audio_url="",
                audio_file="", audio_name="", resource_file="", resource_name="", thumbnail="", duration_min="", position="", access="members", downloadable=True, featured=False, status="draft", slug="")

def _rm(name):
    if name and not val("SELECT 1 FROM faith_items WHERE video_file=? OR audio_file=? OR resource_file=?", (name,) * 3) \
       and not val("SELECT 1 FROM lessons WHERE video_file=? OR resource_file=?", (name, name)):
        B._rm(os.path.join(_priv(), name)); ex("DELETE FROM uploads WHERE stored_name=?", (name,))

def save_item(user, p):
    errs = []; iid = _i(p.get("id")); row = None
    if iid:
        row = q1("SELECT * FROM faith_items WHERE id=?", (iid,))
        if not row: raise FaithError("Lesson not found.", 404)
    title = _s(p.get("title"), 200)
    if not title: errs.append("Give the lesson a title.")
    topic_id = _i(p.get("topic_id"))
    if not topic_id or not val("SELECT 1 FROM faith_topics WHERE id=?", (topic_id,)): errs.append("Choose a topic."); topic_id = None
    series_id = _i(p.get("series_id")) if p.get("series_id") not in (None, "") else None
    if series_id:
        sr = q1("SELECT * FROM faith_series WHERE id=?", (series_id,))
        if not sr: errs.append("Unknown series."); series_id = None
        elif topic_id and sr["topic_id"] != topic_id: errs.append("That series belongs to a different topic. Choose a series from the same topic, or no series."); series_id = None
    tutor = user["role"] != "admin"                  # tutors work inside their own series and their assigned topics; they cannot publish, archive or feature
    if tutor:
        if row and not tutor_can_edit(user, row): raise FaithError("You can only edit lessons in your own series or in a topic you are assigned to.", 403)
        if row and row["status"] == "draft" and row["submitted_at"]: raise FaithError("This lesson is awaiting review. Withdraw it from review first if you need to change it.", 409)
        if not tutor_can_create(user, topic_id, series_id): errs.append("Choose one of your own series, or a Faith topic you have been assigned to." if not series_id else "Choose one of your own series for this lesson.")
    kind = p.get("kind") if p.get("kind") in KINDS else None
    if not kind: errs.append("Choose the main format: video, audio, reading or study guide.")
    status = p.get("status") if p.get("status") in STATUSES else "draft"
    if tutor: status = row["status"] if row else "draft"
    access = p.get("access") if p.get("access") in ACCESS else "members"
    body = _s(p.get("body"), 50000) or None

    vurl = _s(p.get("video_url"), 500); aurl = _s(p.get("audio_url"), 500)
    vf = _s(p.get("video_file"), 60); af = _s(p.get("audio_file"), 60); rf = _s(p.get("resource_file"), 60)
    if vurl and not (vurl.startswith("https://") and embed_url(vurl)[0]): errs.append("The video link must be a YouTube or Vimeo link, or a direct https link ending in .mp4 or .webm."); vurl = ""
    if aurl and not (aurl.startswith("https://") and re.search(r"\.(mp3|m4a|aac|ogg|oga|opus|wav)(\?.*)?$", aurl, re.I)): errs.append("The audio link must be a direct https link to an MP3, M4A, AAC, OGG or WAV file."); aurl = ""
    vf = B._check_file(vf, "video", user, row["video_file"] if row else None)
    if vf is False: errs.append("The uploaded video is not valid. Upload it again."); vf = None
    af = B._check_file(af, "audio", user, row["audio_file"] if row else None)
    if af is False: errs.append("The uploaded audio is not valid. Upload it again."); af = None
    rf = B._check_file(rf, "resource", user, row["resource_file"] if row else None)
    if rf is False: errs.append("The attached study material is not valid. Upload it again."); rf = None
    if vf: vurl = ""
    if af: aurl = ""

    thumb = _s(p.get("thumbnail"), 60) or None
    if thumb and thumb != (row["thumbnail"] if row else None) and not (re.fullmatch(r"[0-9a-f]{24}\.(webp|jpg|png)", thumb) and os.path.exists(os.path.join(current_app.config["PUBLIC_DIR"], thumb))):
        errs.append("The cover image did not upload correctly. Choose it again, or remove it."); thumb = None
    dur = _i(p.get("duration_min")); dur = dur if dur and 0 < dur < 10000 else None
    pos = _i(p.get("position")); pos = pos if pos is not None and 0 <= pos < 100000 else 0

    if status == "published":
        need = {"video": (vf or vurl, "Add a video (upload a file or paste a YouTube/Vimeo link) before publishing a video lesson."),
                "audio": (af or aurl, "Add an audio file (upload or link) before publishing an audio lesson."),
                "reading": (body, "Write the reading text before publishing a reading lesson."),
                "study": (rf or body, "Attach the study material (or write the guide text) before publishing a study guide.")}.get(kind)
        if need and not need[0]: errs.append(need[1])
    if errs: raise FaithError("Please fix the highlighted problems.", 400, errors=errs)

    c = dict(topic_id=topic_id, series_id=series_id, title=title, kind=kind, summary=_s(p.get("summary"), 400) or None, body=body, scripture=_s(p.get("scripture"), 120) or None, speaker=_s(p.get("speaker"), 120) or None,
             video_url=vurl or None, video_file=vf, video_name=(_s(p.get("video_name"), 150) or None) if vf else None, audio_url=aurl or None, audio_file=af, audio_name=(_s(p.get("audio_name"), 150) or None) if af else None,
             resource_file=rf, resource_name=(_s(p.get("resource_name"), 150) or None) if rf else None, thumbnail=thumb, duration_min=dur, position=pos, access=access,
             downloadable=0 if p.get("downloadable") is False else 1, featured=(row["featured"] if row else 0) if tutor else (1 if p.get("featured") else 0), status=status, updated_at=now())
    if status == "published" and not (row and row["published_at"]): c["published_at"] = now()
    if not tutor and status != "draft" and row and row["submitted_at"]: c["submitted_at"] = None; c["reviewed_at"] = now()     # an admin decision closes the review
    gone = []
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        if row:
            for f in ("video_file", "audio_file", "resource_file"):
                if row[f] and row[f] != c[f]: gone.append(row[f])
            db.execute("UPDATE faith_items SET " + ", ".join(f"{k}=?" for k in c) + " WHERE id=?", tuple(c.values()) + (iid,))
        else:
            c["slug"] = unique_slug("faith_items", title); c["created_by"] = user["id"]
            iid = db.execute("INSERT INTO faith_items(" + ",".join(c) + ") VALUES (" + ",".join("?" * len(c)) + ")", tuple(c.values())).lastrowid
        db.execute("INSERT INTO audit_logs(actor_id,actor_label,action,entity,entity_id,detail) VALUES (?,?,?,?,?,?)",
                   (user["id"], f"{user['full_name']} <{user['email']}>", "faith.save", "faith_items", str(iid), f"{title} [{status}] {kind}"))
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK"); raise
    for f in set(gone): _rm(f)                     # files no lesson uses any more
    if tutor and not row:
        from .notify import notify_staff
        notify_staff("faith.manage", "New Faith lesson from a tutor", f"{user['full_name']}: {title}", f"/staff/faith/lesson/{iid}", "content")
    if not tutor and status == "published" and row and row["submitted_at"]: _tell_approved(row)
    return iid, status

def delete_item(user, row):
    ex("DELETE FROM faith_items WHERE id=?", (row["id"],))
    for f in (row["video_file"], row["audio_file"], row["resource_file"]): _rm(f)
    audit.log("faith.delete", "faith_items", row["id"], row["title"], actor=user)

def _has_content(row):
    return {"video": row["video_file"] or row["video_url"], "audio": row["audio_file"] or row["audio_url"], "reading": row["body"], "study": row["resource_file"] or row["body"]}.get(row["kind"])

def set_status(user, row, status):
    if status not in STATUSES: raise FaithError("Unknown status.")
    if status == "published" and not _has_content(row): raise FaithError("This lesson has no content for its format yet. Open it, add the content, then publish.")
    ex("UPDATE faith_items SET status=?, updated_at=?, published_at=CASE WHEN ?='published' AND published_at IS NULL THEN ? ELSE published_at END, submitted_at=CASE WHEN ?='draft' THEN submitted_at ELSE NULL END, reviewed_at=CASE WHEN ?!='draft' AND submitted_at IS NOT NULL THEN ? ELSE reviewed_at END WHERE id=?",
       (status, now(), status, now(), status, status, now(), row["id"]))
    audit.log("faith.status", "faith_items", row["id"], f"{row['status']} -> {status}", actor=user)
    if status == "published" and row["submitted_at"]: _tell_approved(row)

# ---- tutor topic assignments -----------------------------------------------------------------------
# A topic assignment is an ADDITIONAL permission. It never removes what a tutor already has (their own series, their other sections);
# it adds the right to create lessons in that topic. Everything is enforced here, on the server.
def tutor_topic_ids(uid): return {r["topic_id"] for r in q("SELECT topic_id FROM faith_topic_tutors WHERE user_id=?", (uid,))}

def _own_series(uid, series_id): return bool(series_id and val("SELECT 1 FROM faith_series WHERE id=? AND instructor_id=?", (series_id, uid)))

def tutor_can_create(user, topic_id, series_id):
    """New or moved lesson: in one of the tutor's own series (existing right), or in an assigned topic (a series, if chosen, must be the tutor's own)."""
    if _own_series(user["id"], series_id): return True
    return bool(topic_id and not series_id and topic_id in tutor_topic_ids(user["id"]))

def tutor_can_edit(user, row):
    """Existing right: lessons in the tutor's own series. Added: lessons the tutor created in a topic that is still assigned to them."""
    if _own_series(user["id"], row["series_id"]): return True
    return row["created_by"] == user["id"] and row["topic_id"] in tutor_topic_ids(user["id"])

def tutor_scope_sql(uid):
    """WHERE fragment (with args) limiting a tutor's lesson list to what they may open."""
    return ("(i.series_id IN (SELECT id FROM faith_series WHERE instructor_id=?) OR (i.created_by=? AND i.topic_id IN (SELECT topic_id FROM faith_topic_tutors WHERE user_id=?)))", [uid, uid, uid])

def tutor_topics(uid):
    """Topics a tutor may start lessons in: assigned ones plus the topics of their own series (those need a series, as before)."""
    return q("SELECT * FROM faith_topics WHERE id IN (SELECT topic_id FROM faith_topic_tutors WHERE user_id=?) OR id IN (SELECT topic_id FROM faith_series WHERE instructor_id=?) ORDER BY position, name", (uid, uid))

def tutors_overview():
    """Every active tutor with their assigned topics and lesson counts, for the admin screen."""
    out = []
    for u in q("SELECT id, full_name, email FROM users WHERE role='instructor' AND is_active=1 ORDER BY full_name COLLATE NOCASE"):
        tp = q("SELECT t.id, t.name FROM faith_topic_tutors a JOIN faith_topics t ON t.id=a.topic_id WHERE a.user_id=? ORDER BY t.position, t.name", (u["id"],))
        out.append(dict(u=u, topics=tp, lessons=val("SELECT COUNT(*) FROM faith_items WHERE created_by=?", (u["id"],), 0),
                        pending=val("SELECT COUNT(*) FROM faith_items WHERE created_by=? AND status='draft' AND submitted_at IS NOT NULL", (u["id"],), 0)))
    return out

def topic_tutors(topic_id):
    return q("SELECT u.id, u.full_name, u.email FROM faith_topic_tutors a JOIN users u ON u.id=a.user_id WHERE a.topic_id=? ORDER BY u.full_name COLLATE NOCASE", (topic_id,))

def _apply_assignments(actor, pairs_add, pairs_del):
    """pairs are (topic_id, user_id). Inserts and deletes together, audited; existing lessons are never touched."""
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        for t, u in pairs_add: db.execute("INSERT OR IGNORE INTO faith_topic_tutors(topic_id,user_id,assigned_by) VALUES (?,?,?)", (t, u, actor["id"]))
        for t, u in pairs_del: db.execute("DELETE FROM faith_topic_tutors WHERE topic_id=? AND user_id=?", (t, u))
        for act, pairs in (("faith.assign", pairs_add), ("faith.revoke", pairs_del)):
            for t, u in pairs: db.execute("INSERT INTO audit_logs(actor_id,actor_label,action,entity,entity_id,detail) VALUES (?,?,?,?,?,?)", (actor["id"], f"{actor['full_name']} <{actor['email']}>", act, "faith_topic_tutors", f"{t}:{u}", f"topic {t} tutor {u}"))
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK"); raise

def _tell_assignment(uid, names, gained):
    from .notify import notify
    if names: notify(uid, "Faith topics assigned to you" if gained else "Faith topic access removed", ", ".join(names), "/staff/faith/lessons" if gained else None, "content")

def set_tutor_topics(actor, uid, topic_ids):
    """Make the tutor's assigned topics exactly topic_ids (add what is new, revoke what is no longer ticked)."""
    if not val("SELECT 1 FROM users WHERE id=? AND role='instructor'", (uid,)): raise FaithError("Tutor not found.", 404)
    valid = {r["id"] for r in q("SELECT id FROM faith_topics")}
    want = {t for t in (_i(x) for x in topic_ids) if t in valid}; have = tutor_topic_ids(uid)
    add, rem = sorted(want - have), sorted(have - want)
    _apply_assignments(actor, [(t, uid) for t in add], [(t, uid) for t in rem])
    nm = lambda ids: [r["name"] for r in q("SELECT name FROM faith_topics WHERE id IN (%s)" % ",".join("?" * len(ids)), tuple(ids))] if ids else []
    _tell_assignment(uid, nm(add), True); _tell_assignment(uid, nm(rem), False)
    return add, rem

def set_topic_tutors(actor, topic_id, user_ids):
    """Same, from the topic's side: assign one topic to several tutors at once."""
    if not val("SELECT 1 FROM faith_topics WHERE id=?", (topic_id,)): raise FaithError("Topic not found.", 404)
    valid = {r["id"] for r in q("SELECT id FROM users WHERE role='instructor' AND is_active=1")}
    want = {u for u in (_i(x) for x in user_ids) if u in valid}; have = {r["id"] for r in topic_tutors(topic_id)}
    add, rem = sorted(want - have), sorted(have - want)
    _apply_assignments(actor, [(topic_id, u) for u in add], [(topic_id, u) for u in rem])
    name = val("SELECT name FROM faith_topics WHERE id=?", (topic_id,))
    for u in add: _tell_assignment(u, [name], True)
    for u in rem: _tell_assignment(u, [name], False)
    return add, rem

# ---- review workflow: tutor submits -> admin approves (publishes) or returns it. Nothing is ever published automatically.
def submit_item(user, row):
    if user["role"] == "admin": raise FaithError("Administrators publish directly.", 400)
    if not tutor_can_edit(user, row): raise FaithError("You can only submit lessons in your own series or in a topic you are assigned to.", 403)
    if row["status"] != "draft": raise FaithError("Only draft lessons can be submitted for review.", 400)
    if row["submitted_at"]: raise FaithError("This lesson is already awaiting review.", 400)
    if not _has_content(row): raise FaithError("Add the lesson content for its format (video, audio, reading text or study material) before submitting it.", 400)
    ex("UPDATE faith_items SET submitted_at=?, review_note=NULL, updated_at=? WHERE id=?", (now(), now(), row["id"]))
    audit.log("faith.submit", "faith_items", row["id"], row["title"], actor=user)
    from .notify import notify_staff
    notify_staff("faith.manage", "Faith lesson awaiting review", f"{user['full_name']}: {row['title']}", f"/staff/faith/lesson/{row['id']}", "content")

def withdraw_item(user, row):
    if user["role"] != "admin" and not tutor_can_edit(user, row): raise FaithError("You cannot change this lesson.", 403)
    if not (row["status"] == "draft" and row["submitted_at"]): raise FaithError("This lesson is not awaiting review.", 400)
    ex("UPDATE faith_items SET submitted_at=NULL, updated_at=? WHERE id=?", (now(), row["id"]))
    audit.log("faith.withdraw", "faith_items", row["id"], row["title"], actor=user)

def return_item(user, row, note=""):
    """Admin sends a submitted lesson back to the tutor for changes (it stays a draft)."""
    if not (row["status"] == "draft" and row["submitted_at"]): raise FaithError("This lesson is not awaiting review.", 400)
    ex("UPDATE faith_items SET submitted_at=NULL, review_note=?, reviewed_at=?, updated_at=? WHERE id=?", (_s(note, 500) or None, now(), now(), row["id"]))
    audit.log("faith.return", "faith_items", row["id"], row["title"], actor=user)
    if row["created_by"]:
        from .notify import notify
        notify(row["created_by"], "Faith lesson returned for changes", f"{row['title']}" + (f": {_s(note, 500)}" if _s(note, 500) else ""), f"/staff/faith/lesson/{row['id']}", "content")

def _tell_approved(row):
    if row["created_by"]:
        from .notify import notify
        notify(row["created_by"], "Your Faith lesson was approved", row["title"], f"/staff/faith/lesson/{row['id']}", "content")

def pending_count(): return val("SELECT COUNT(*) FROM faith_items WHERE status='draft' AND submitted_at IS NOT NULL", default=0)


# ---- teachers (instructors): only name and bio are public; never email, phone or money
_LIVE_SERIES = """s.status='published' AND EXISTS (SELECT 1 FROM faith_topics t WHERE t.id=s.topic_id AND t.active=1)
                  AND EXISTS (SELECT 1 FROM faith_items i WHERE i.series_id=s.id AND i.status='published')"""

def teachers():
    """Instructors with at least one live Faith series: id, name, bio and number of series."""
    return q(f"""SELECT u.id, u.full_name, u.bio, COUNT(*) AS n FROM faith_series s JOIN users u ON u.id=s.instructor_id
                 WHERE u.is_active=1 AND {_LIVE_SERIES} GROUP BY u.id ORDER BY n DESC, u.full_name""")

def teacher(uid):
    return q1(f"""SELECT u.id, u.full_name, u.bio, COUNT(*) AS n FROM faith_series s JOIN users u ON u.id=s.instructor_id
                  WHERE u.is_active=1 AND u.id=? AND {_LIVE_SERIES} GROUP BY u.id""", (uid,))

def teacher_series(uid):
    return q(f"""SELECT s.*, t.name AS topic, t.slug AS topic_slug, (SELECT full_name FROM users WHERE id=s.instructor_id) AS tutor, (SELECT COUNT(*) FROM faith_items i WHERE i.series_id=s.id AND i.status='published') AS n
                 FROM faith_series s JOIN faith_topics t ON t.id=s.topic_id WHERE s.instructor_id=? AND {_LIVE_SERIES} ORDER BY s.featured DESC, s.position, s.title""", (uid,))
