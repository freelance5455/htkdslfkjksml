import os, secrets, io
from PIL import Image
from flask import current_app
from . import settings

MAGIC = [(b"\xff\xd8\xff", "jpg", "image/jpeg"), (b"\x89PNG\r\n\x1a\n", "png", "image/png"), (b"%PDF-", "pdf", "application/pdf")]

class UploadError(ValueError): pass

def sniff(head):
    for sig, ext, mime in MAGIC:
        if head.startswith(sig): return ext, mime
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP": return "webp", "image/webp"
    return None, None

def _validate(fs, allowed, max_bytes):
    data = fs.read(max_bytes + 1); fs.seek(0)
    if not data: raise UploadError("The file is empty.")
    if len(data) > max_bytes: raise UploadError(f"File is too large (max {max_bytes // 1024 // 1024} MB).")
    ext, mime = sniff(data[:16])
    if not ext or ext not in allowed: raise UploadError("Unsupported file type.")
    name_ext = (fs.filename or "").rsplit(".", 1)[-1].lower()
    if name_ext == "jpeg": name_ext = "jpg"
    if name_ext != ext: raise UploadError("The file extension does not match the file content.")
    if ext in ("jpg", "png", "webp"):
        try:
            im = Image.open(io.BytesIO(data)); im.verify()
        except Exception: raise UploadError("The image is corrupt or invalid.")
    if ext == "pdf" and b"%%EOF" not in data[-2048:]: raise UploadError("The PDF appears to be corrupt.")
    return data, ext, mime

def save_private(fs, allowed=("jpg", "png", "pdf"), max_bytes=5 * 1024 * 1024):
    """Store outside the web root under a random name. Returns (stored_name, ext, mime, size)."""
    data, ext, mime = _validate(fs, allowed, max_bytes)
    name = secrets.token_hex(16) + "." + ext
    os.makedirs(current_app.config["PRIVATE_DIR"], exist_ok=True)
    with open(os.path.join(current_app.config["PRIVATE_DIR"], name), "wb") as f: f.write(data)
    return name, ext, mime, len(data)

def save_resource(fs, max_bytes=25 * 1024 * 1024):
    """Course resources: PDF/images, or office docs & zips validated by signature."""
    head = fs.read(16); fs.seek(0)
    ext = (fs.filename or "").rsplit(".", 1)[-1].lower()
    if ext in ("docx", "pptx", "xlsx", "zip") and head.startswith(b"PK\x03\x04"):
        data = fs.read(max_bytes + 1); fs.seek(0)
        if len(data) > max_bytes: raise UploadError("File too large.")
        name = secrets.token_hex(16) + "." + ext
        os.makedirs(current_app.config["PRIVATE_DIR"], exist_ok=True)
        open(os.path.join(current_app.config["PRIVATE_DIR"], name), "wb").write(data)
        return name, ext, "application/octet-stream", len(data)
    return save_private(fs, ("jpg", "png", "pdf", "webp"), max_bytes)

def save_public_image(fs, max_bytes=15 * 1024 * 1024):
    """Re-encode with Pillow (strips embedded payloads), fix phone-photo rotation, cap dimensions, serve via /media.
    Large phone photos are accepted and shrunk; damaged/truncated/oversized-pixel images give a clear message instead of an error."""
    data, ext, _ = _validate(fs, ("jpg", "png", "webp"), max_bytes)
    try:
        Image.MAX_IMAGE_PIXELS = 80_000_000
        im = Image.open(io.BytesIO(data)); im.load()                           # raises for truncated/corrupt data
        from PIL import ImageOps
        im = ImageOps.exif_transpose(im)                                      # upright phone photos
        im.thumbnail((1600, 1600))
        if im.mode not in ("RGB", "RGBA"): im = im.convert("RGBA" if "transparency" in im.info or im.mode in ("LA", "PA") else "RGB")
        os.makedirs(current_app.config["PUBLIC_DIR"], exist_ok=True); base = secrets.token_hex(12)
        try:
            name = base + ".webp"; im.save(os.path.join(current_app.config["PUBLIC_DIR"], name), "WEBP", quality=82)
        except Exception:                                                     # Pillow built without WebP: fall back to JPEG/PNG
            if im.mode == "RGBA": name = base + ".png"; im.save(os.path.join(current_app.config["PUBLIC_DIR"], name), "PNG", optimize=True)
            else: name = base + ".jpg"; im.save(os.path.join(current_app.config["PUBLIC_DIR"], name), "JPEG", quality=85)
        return name
    except UploadError: raise
    except Exception:
        raise UploadError("This image could not be processed. It may be damaged or incomplete (for example a photo that did not finish downloading). Please try another copy, or re-save it as JPG or PNG.")

def allowed_receipt_types():
    t = [x.strip().lower().replace("jpeg", "jpg") for x in settings.get("bank.file_types", "jpg,png,pdf").split(",")]
    return tuple(x for x in t if x in ("jpg", "png", "pdf")) or ("jpg", "png", "pdf")

def receipt_max_bytes():
    try: return max(1, min(20, int(float(settings.get("bank.max_mb", "5"))))) * 1024 * 1024
    except ValueError: return 5 * 1024 * 1024

