"""Lesson and course discussions.
 * Who may read/post: students with access to the course (enrolled, free, or covered by a subscription), the course's instructor, and admins.
 * Questions hang under a lesson (lesson_id) or under the course as a whole (lesson_id NULL); replies are one level below a question.
 * Moderation: the course's instructor (their own courses) and admins holding discussions.manage can remove (soft: kept for oversight) and restore.
   Authors can remove their own posts.
 * Notifications (kind 'discussion'): a new question tells the instructor; a reply tells everyone already in that thread and the instructor.
Post bodies are plain text, always escaped when shown."""
import re
from ..db import q, q1, ex, val
from ..util import now
from . import access, audit, release
from .notify import notify

class DiscussionError(Exception): pass
MAX_BODY, MIN_BODY = 3000, 2

def _perm(user):
    from ..security import has_perm
    return bool(user and user["role"] == "admin" and has_perm("discussions.manage", user))

def is_staff_of(user, course):
    """Instructor of this course, or an admin (any admin may take part and read)."""
    return bool(user and (user["role"] == "admin" or (user["role"] == "instructor" and course["instructor_id"] == user["id"])))

def can_view(user, course):
    if not user: return False
    return is_staff_of(user, course) or bool(access.course_access(user["id"], course))

def can_moderate(user, course):
    return bool(user and (_perm(user) or (user["role"] == "instructor" and course["instructor_id"] == user["id"])))

def _label(row):
    """Name shown on a post: instructors and admins in full (with a role badge), students as first name + initial."""
    if not row["author_id"]: return "Former student", None
    n = (row["author_name"] or "Student").strip(); parts = n.split()
    if row["author_role"] in ("instructor", "admin"): return n, "Instructor" if row["author_role"] == "instructor" else "Admin"
    return (parts[0] + (f" {parts[-1][0]}." if len(parts) > 1 else "")), None

def _rows(course_id, lesson_id, parent_ids=None, top=True):
    sql = """SELECT d.*, u.id AS author_id, u.full_name AS author_name, u.role AS author_role FROM discussion_posts d LEFT JOIN users u ON u.id=d.user_id WHERE d.course_id=?"""
    a = [course_id]
    if top: sql += " AND d.parent_id IS NULL" + (" AND d.lesson_id=?" if lesson_id else " AND d.lesson_id IS NULL"); a += [lesson_id] if lesson_id else []
    else: sql += f" AND d.parent_id IN ({','.join('?' * len(parent_ids))})"; a += parent_ids
    return q(sql + (" ORDER BY d.created_at DESC, d.id DESC" if top else " ORDER BY d.created_at, d.id"), tuple(a))

def threads(course, lesson_id, viewer):
    """Questions for a lesson (or the course) with their replies. Removed posts are hidden from everyone but moderators."""
    mod = can_moderate(viewer, course); out = []
    tops = _rows(course["id"], lesson_id)
    if not mod: tops = [t for t in tops if t["status"] == "visible"]
    reps = {}
    if tops:
        for r in _rows(course["id"], lesson_id, [t["id"] for t in tops], top=False):
            if r["status"] == "visible" or mod: reps.setdefault(r["parent_id"], []).append(r)
    def card(r):
        name, badge = _label(r)
        return dict(post=r, name=name, badge=badge, mine=bool(viewer and r["user_id"] == viewer["id"]), removed=r["status"] == "removed", can_delete=bool(viewer and (mod or r["user_id"] == viewer["id"])) and r["status"] == "visible")
    for t in tops: out.append(dict(card(t), replies=[card(r) for r in reps.get(t["id"], [])]))
    return out

def count(course_id, lesson_id=None):
    return val("SELECT COUNT(*) FROM discussion_posts WHERE course_id=? AND status='visible' AND parent_id IS NULL AND " + ("lesson_id=?" if lesson_id else "lesson_id IS NULL"), (course_id, lesson_id) if lesson_id else (course_id,), 0)

def _link(course, post):
    base = f"/learn/{course['slug']}/lesson/{post['lesson_id']}" if post["lesson_id"] else f"/learn/{course['slug']}/discussion"
    return f"{base}#post-{post['id']}"

def post(user, course, body, lesson_id=None, parent_id=None):
    """Create a question or a reply. Raises DiscussionError with a message for the person."""
    from ..security import rate_limited
    if not can_view(user, course): raise DiscussionError("You need access to this course to join its discussion.")
    body = re.sub(r"\n{3,}", "\n\n", (body or "").replace("\r", "").strip())
    if len(body) < MIN_BODY: raise DiscussionError("Write your question or reply first.")
    if len(body) > MAX_BODY: raise DiscussionError(f"Please keep it under {MAX_BODY} characters.")
    lesson = None
    if lesson_id:
        lesson = q1("SELECT * FROM lessons WHERE id=? AND course_id=?", (lesson_id, course["id"]))
        if not lesson: raise DiscussionError("That lesson was not found.")
        if not is_staff_of(user, course) and release.lesson_opens_at(lesson["id"]): raise DiscussionError("That lesson is not open yet.")
    parent = None
    if parent_id:
        parent = q1("SELECT * FROM discussion_posts WHERE id=? AND course_id=?", (parent_id, course["id"]))
        if not parent or parent["parent_id"] or parent["status"] != "visible": raise DiscussionError("You can only reply to an open question.")
        if (parent["lesson_id"] or None) != (lesson["id"] if lesson else None): raise DiscussionError("That question belongs to a different lesson.")
    if rate_limited(f"discuss:{user['id']}", 20, 3600): raise DiscussionError("You are posting very quickly. Please wait a little and try again.")
    pid = ex("INSERT INTO discussion_posts(course_id,lesson_id,parent_id,user_id,body) VALUES (?,?,?,?,?)", (course["id"], lesson["id"] if lesson else None, parent["id"] if parent else None, user["id"], body))
    p = q1("SELECT * FROM discussion_posts WHERE id=?", (pid,)); where = f"{lesson['title']} ({course['title']})" if lesson else course["title"]
    snippet = body[:140] + ("..." if len(body) > 140 else ""); who = user["full_name"].split()[0] if user["full_name"] else "Someone"
    if parent:
        people = {parent["user_id"]} | {r["user_id"] for r in q("SELECT user_id FROM discussion_posts WHERE parent_id=? AND status='visible'", (parent["id"],))}
        if course["instructor_id"]: people.add(course["instructor_id"])
        title = f"New reply in {where}"
    else:
        people = {course["instructor_id"]} if course["instructor_id"] else set(); title = f"New question in {where}"
    for uid in people - {user["id"], None}: notify(uid, title, f"{who}: {snippet}", _link(course, p), "discussion")
    return p

def remove(user, post_id, reason=""):
    """Moderator removal (soft), or an author removing their own post."""
    p = q1("SELECT * FROM discussion_posts WHERE id=?", (post_id,)); c = q1("SELECT * FROM courses WHERE id=?", (p["course_id"],)) if p else None
    if not p or not c: raise DiscussionError("Post not found.")
    mod = can_moderate(user, c)
    if not (mod or p["user_id"] == user["id"]): raise DiscussionError("You cannot remove this post.")
    if p["status"] == "removed": return p
    ex("UPDATE discussion_posts SET status='removed', removed_by=?, removed_at=?, removed_reason=? WHERE id=?", (user["id"], now(), (reason or "").strip()[:200] or ("Deleted by the author" if not mod else None), post_id))
    audit.log("discussion.removed", "discussion_post", post_id, f"course {c['id']} by user {p['user_id']}" + (f": {reason[:80]}" if reason else ""), actor=user)
    if p["user_id"] and p["user_id"] != user["id"]: notify(p["user_id"], "Your discussion post was removed", f"A moderator removed your post in {c['title']}." + (f" Reason: {reason.strip()[:200]}" if reason and reason.strip() else ""), None, "discussion")
    return p

def restore(user, post_id):
    p = q1("SELECT * FROM discussion_posts WHERE id=?", (post_id,)); c = q1("SELECT * FROM courses WHERE id=?", (p["course_id"],)) if p else None
    if not p or not c or not can_moderate(user, c): raise DiscussionError("You cannot restore this post.")
    ex("UPDATE discussion_posts SET status='visible', removed_by=NULL, removed_at=NULL, removed_reason=NULL WHERE id=?", (post_id,))
    audit.log("discussion.restored", "discussion_post", post_id, f"course {c['id']}", actor=user); return p

def moderation_list(user, args, per=30):
    """All discussion posts the person may moderate: an admin sees every course, an instructor only their own."""
    where, a = ["1=1"], []
    if not _perm(user): where.append("c.instructor_id=?"); a.append(user["id"])
    if args.get("course", type=int): where.append("d.course_id=?"); a.append(args.get("course", type=int))
    if args.get("status") in ("visible", "removed"): where.append("d.status=?"); a.append(args["status"])
    term = (args.get("q") or "").strip()[:100]
    if term: where.append("(d.body LIKE ? ESCAPE '\\' OR u.full_name LIKE ? ESCAPE '\\')"); like = "%" + term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"; a += [like, like]
    base = f"""FROM discussion_posts d JOIN courses c ON c.id=d.course_id LEFT JOIN lessons l ON l.id=d.lesson_id LEFT JOIN users u ON u.id=d.user_id WHERE {' AND '.join(where)}"""
    page = max(1, args.get("page", 1, type=int)); total = val(f"SELECT COUNT(*) {base}", tuple(a), 0)
    rows = q(f"SELECT d.*, c.title AS course_title, c.slug AS course_slug, l.title AS lesson_title, u.full_name AS author_name, u.role AS author_role {base} ORDER BY d.created_at DESC, d.id DESC LIMIT ? OFFSET ?", (*a, per, (page - 1) * per))
    return rows, total, page, max(1, -(-total // per))

def moderated_courses(user):
    return q("SELECT id, title FROM courses ORDER BY title") if _perm(user) else q("SELECT id, title FROM courses WHERE instructor_id=? ORDER BY title", (user["id"],))
