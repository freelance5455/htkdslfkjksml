"""Turns a store-verified purchase into website-identical access. Everything after verification goes through payments._approve, so access scope,
expiry stacking, instructor earnings and affiliate commission follow the SAME rules as bank-transfer and gateway payments.
Product ids are derived, never stored: dagba.<kind>.<id> with kind in plan|course|subject|faith|faithtopic (create matching products in the store consoles)."""
import json, re
from ..db import get_db, q, q1, ex, val
from ..util import now
from . import payments as P, audit, store_verify as V

KINDS = {"plan": "plan", "course": "course", "subject": "subject", "faith": "faith", "faithtopic": "faith_topic"}
PID = re.compile(r"^dagba\.(plan|course|subject|faith|faithtopic)\.(\d+)$")

class StoreError(Exception):
    def __init__(self, msg, code="store_error", status=400): super().__init__(msg); self.code = code; self.status = status

_KIND_OF = {v: k for k, v in KINDS.items()}
def product_id(item_type, item_id): return f"dagba.{_KIND_OF[item_type]}.{item_id}"
def parse_product(pid):
    m = PID.match(pid or ""); return (KINDS[m.group(1)], int(m.group(2))) if m else (None, None)

def catalogue():
    """Everything currently sellable, with the product id the store console must contain. Prices shown to learners come from the store, not from here."""
    out = []
    for p in q("SELECT * FROM plans WHERE active=1 AND price_kobo>0 ORDER BY position, id"): out.append(dict(product_id=product_id("plan", p["id"]), type="subscription", title=p["name"], web_price_kobo=p["price_kobo"], duration_days=p["duration_days"]))
    from .access import subject_scope
    for c in q("SELECT * FROM categories WHERE active=1 AND price_kobo>0"):
        if subject_scope(c): out.append(dict(product_id=product_id("subject", c["id"]), type="non_consumable", title=c["name"] + " (full subject)", web_price_kobo=c["price_kobo"]))
    for c in q("SELECT * FROM courses WHERE status='published' AND price_kobo>0 AND division IN ('income','academic','professional')"):
        try: P.price_item("course", c["id"])
        except P.PayError: continue                         # courses sold through a subject are not sold individually
        out.append(dict(product_id=product_id("course", c["id"]), type="non_consumable", title=c["title"], web_price_kobo=c["price_kobo"]))
    for s in q("SELECT * FROM faith_series WHERE status='published' AND price_kobo>0"): out.append(dict(product_id=product_id("faith", s["id"]), type="non_consumable", title=s["title"], web_price_kobo=s["price_kobo"]))
    for t in q("SELECT * FROM faith_topics WHERE active=1 AND price_kobo>0"): out.append(dict(product_id=product_id("faithtopic", t["id"]), type="non_consumable", title=t["name"] + " (all lessons)", web_price_kobo=t["price_kobo"]))
    return out

def fulfil(user, platform, v):
    """v is a dict RETURNED BY store_verify.verify(); never data taken straight from the app. Idempotent per (platform, store transaction)."""
    if v["state"] == "refunded": raise StoreError("This purchase was refunded.", "refunded", 409)
    if v["state"] != "active": raise StoreError("This purchase is no longer active.", "expired", 409)
    item_type, item_id = parse_product(v["product_id"])
    if not item_type: raise StoreError("Unknown product.", "unknown_product")
    if not v.get("store_txn_id"): raise StoreError("The store did not return a transaction id.", "store_error", 502)
    old = q1("SELECT * FROM store_purchases WHERE platform=? AND store_txn_id=?", (platform, v["store_txn_id"]))
    if old:
        if old["user_id"] != user["id"]: raise StoreError("This purchase is already linked to a different account.", "linked_elsewhere", 409)
        return old, False
    other = q1("SELECT user_id FROM store_purchases WHERE platform=? AND original_txn_id=? AND user_id!=? LIMIT 1", (platform, v.get("original_txn_id"), user["id"])) if v.get("original_txn_id") else None
    if other: raise StoreError("This subscription is already linked to a different account.", "linked_elsewhere", 409)
    try: tx = P.create_transaction(user, item_type, item_id)
    except P.PayError as e: raise StoreError(str(e), "not_purchasable", 409)
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        if db.execute("SELECT 1 FROM store_purchases WHERE platform=? AND store_txn_id=?", (platform, v["store_txn_id"])).fetchone(): db.execute("ROLLBACK"); return fulfil(user, platform, v)
        P._approve(db, tx, None, platform)
        db.execute("""INSERT INTO store_purchases(platform,store_txn_id,original_txn_id,product_id,user_id,transaction_id,environment,purchased_at,expires_at,store_amount_micros,store_currency) VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                   (platform, v["store_txn_id"], v.get("original_txn_id"), v["product_id"], user["id"], tx["id"], v.get("environment"), v.get("purchased_at"), v.get("expires_at"), v.get("amount_micros"), v.get("currency")))
        db.execute("INSERT INTO audit_logs(actor_label,action,entity,entity_id,detail) VALUES (?,?,?,?,?)", (platform, "payment.store_approved", "transaction", str(tx["id"]), f"{v['product_id']} {v['store_txn_id']}"))
        db.execute("COMMIT")
    except Exception: db.execute("ROLLBACK"); raise
    P._after_decision(tx["id"], "approve", None)
    return q1("SELECT * FROM store_purchases WHERE platform=? AND store_txn_id=?", (platform, v["store_txn_id"])), True

def revoke(platform, store_txn_id, reason="Refunded by the store"):
    """Store refund/chargeback: same effect as a staff refund (access revoked, instructor/affiliate credit reversed). Returns False if unknown/already revoked."""
    sp = q1("SELECT * FROM store_purchases WHERE platform=? AND store_txn_id=? AND status='verified'", (platform, store_txn_id))
    if not sp or not sp["transaction_id"]: return False
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        cur = db.execute("UPDATE transactions SET status='refunded', decision_reason=?, updated_at=? WHERE id=? AND status='approved'", (reason, now(), sp["transaction_id"]))
        if cur.rowcount == 1:
            db.execute("UPDATE entitlements SET revoked_at=? WHERE transaction_id=?", (now(), sp["transaction_id"])); db.execute("UPDATE faith_access SET revoked_at=? WHERE transaction_id=?", (now(), sp["transaction_id"]))
            P.payouts.record_reversal(db, sp["transaction_id"]); P.affiliates.record_reversal(db, sp["transaction_id"])
        db.execute("UPDATE store_purchases SET status='refunded' WHERE id=?", (sp["id"],))
        db.execute("INSERT INTO audit_logs(actor_label,action,entity,entity_id,detail) VALUES (?,?,?,?,?)", (platform, "payment.store_refund", "transaction", str(sp["transaction_id"]), reason))
        db.execute("COMMIT")
    except Exception: db.execute("ROLLBACK"); raise
    return True
