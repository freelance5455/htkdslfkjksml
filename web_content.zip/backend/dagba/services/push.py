"""Push notifications to the phone apps through Firebase Cloud Messaging (FCM HTTP v1; FCM also delivers to iPhones through APNs once you upload
your APNs key in the Firebase console). Every in-app notification (announcement, payment decision, grade, discussion reply, certificate) that
the website creates is also pushed here, so no other code had to change. Without FIREBASE_SERVICE_ACCOUNT_FILE this is a silent no-op."""
import json, os, threading, logging, urllib.request, urllib.error
from flask import current_app
from ..db import q, ex
from . import store_verify as V

log = logging.getLogger("dagba.push")

def configured():
    c = current_app.config; f = c.get("FIREBASE_SERVICE_ACCOUNT_FILE") or os.environ.get("FIREBASE_SERVICE_ACCOUNT_FILE", "")
    return bool(f and os.path.exists(f)), f

def _post(token, access, project, msg):
    req = urllib.request.Request(f"https://fcm.googleapis.com/v1/projects/{project}/messages:send", data=json.dumps({"message": msg}).encode(),
                                 headers={"Authorization": f"Bearer {access}", "Content-Type": "application/json"}, method="POST")
    try:
        urllib.request.urlopen(req, timeout=10).read(); return "ok"
    except urllib.error.HTTPError as e:
        detail = e.read()
        return "dead" if e.code == 404 or b"UNREGISTERED" in detail else f"error {e.code}"
    except Exception as e: return f"error {e}"

def send(user_id, title, body="", link=None, kind="info"):
    ok, f = configured()
    if not ok: return 0
    toks = q("SELECT id, token, platform FROM device_tokens WHERE user_id=?", (user_id,))
    if not toks: return 0
    try:
        project = json.load(open(f))["project_id"]; access = V.service_account_token(f, "https://www.googleapis.com/auth/firebase.messaging")
    except Exception as e: log.warning("push unavailable: %s", e); return 0
    sent = 0
    for t in toks:
        msg = {"token": t["token"], "notification": {"title": title[:100], "body": (body or "")[:200]}, "data": {"link": link or "", "kind": kind}, "android": {"priority": "HIGH"}}
        r = _post(t["token"], access, project, msg)
        if r == "ok": sent += 1
        elif r == "dead": ex("DELETE FROM device_tokens WHERE id=?", (t["id"],))       # app uninstalled / token rotated
        else: log.warning("push to device %s failed: %s", t["id"], r)
    return sent

def send_async(user_id, title, body="", link=None, kind="info"):
    ok, _ = configured()
    if not ok or current_app.config.get("TESTING"): return
    app = current_app._get_current_object()
    def run():
        with app.app_context():
            try: send(user_id, title, body, link, kind)
            except Exception as e: log.warning("push failed: %s", e)
    threading.Thread(target=run, daemon=True).start()
