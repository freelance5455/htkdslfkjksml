"""Real payment-gateway adapters (server-side only). They are implemented from the providers' public API docs but
have NOT been exercised against live accounts: they remain 'awaiting credentials' until keys are configured.
A provider is only offered to students when it is enabled in the admin dashboard AND has its secret configured."""
import hmac, hashlib, json, urllib.request, urllib.error
from . import settings

class ProviderError(Exception): pass

def _http(method, url, headers, body=None, timeout=20):
    req = urllib.request.Request(url, method=method, headers={**headers, "Content-Type": "application/json", "User-Agent": "DagbaAcademy/1.0"},
                                 data=json.dumps(body).encode() if body is not None else None)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r: return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        raise ProviderError(f"Gateway error {e.code}")
    except Exception as e:  # noqa
        raise ProviderError(f"Gateway unreachable: {e.__class__.__name__}")

class Paystack:
    name = "paystack"; label = "Card / Bank (Paystack)"
    def secret(self): return settings.get("pay.paystack.secret_key", "")
    def configured(self): return bool(self.secret())
    def _h(self): return {"Authorization": "Bearer " + self.secret()}
    def initialize(self, tx, user, callback_url):
        r = _http("POST", "https://api.paystack.co/transaction/initialize", self._h(),
                  {"email": user["email"], "amount": tx["amount_kobo"], "reference": tx["reference"], "callback_url": callback_url, "currency": "NGN"})
        if not r.get("status"): raise ProviderError("Paystack refused to start the payment.")
        return r["data"]["authorization_url"]
    def verify(self, reference):
        r = _http("GET", "https://api.paystack.co/transaction/verify/" + reference, self._h())
        d = r.get("data") or {}
        st = {"success": "success", "failed": "failed", "abandoned": "cancelled"}.get(d.get("status"), "pending")
        return {"status": st if r.get("status") else "pending", "amount_kobo": int(d.get("amount") or 0), "currency": d.get("currency"), "reference": d.get("reference")}
    def verify_webhook(self, headers, raw):
        sig = headers.get("x-paystack-signature", "")
        mac = hmac.new(self.secret().encode(), raw, hashlib.sha512).hexdigest()
        return bool(self.secret()) and hmac.compare_digest(sig, mac)
    def parse_event(self, raw):
        e = json.loads(raw.decode() or "{}")
        d = e.get("data") or {}
        return (d.get("reference") if e.get("event") == "charge.success" else None), f"{e.get('event')}:{d.get('id')}"

class Flutterwave:
    name = "flutterwave"; label = "Card / Bank (Flutterwave)"
    def secret(self): return settings.get("pay.flutterwave.secret_key", "")
    def configured(self): return bool(self.secret() and settings.get("pay.flutterwave.webhook_hash", ""))
    def _h(self): return {"Authorization": "Bearer " + self.secret()}
    def initialize(self, tx, user, callback_url):
        r = _http("POST", "https://api.flutterwave.com/v3/payments", self._h(),
                  {"tx_ref": tx["reference"], "amount": tx["amount_kobo"] / 100, "currency": "NGN", "redirect_url": callback_url,
                   "customer": {"email": user["email"], "name": user["full_name"]}, "customizations": {"title": settings.get("site.name")}})
        if r.get("status") != "success": raise ProviderError("Flutterwave refused to start the payment.")
        return r["data"]["link"]
    def verify(self, reference):
        r = _http("GET", "https://api.flutterwave.com/v3/transactions/verify_by_reference?tx_ref=" + reference, self._h())
        d = r.get("data") or {}
        st = {"successful": "success", "failed": "failed", "cancelled": "cancelled"}.get(d.get("status"), "pending")
        return {"status": st if r.get("status") == "success" else "pending", "amount_kobo": round(float(d.get("amount") or 0) * 100),
                "currency": d.get("currency"), "reference": d.get("tx_ref")}
    def verify_webhook(self, headers, raw):
        h = settings.get("pay.flutterwave.webhook_hash", "")
        return bool(h) and hmac.compare_digest(headers.get("verif-hash", ""), h)
    def parse_event(self, raw):
        e = json.loads(raw.decode() or "{}"); d = e.get("data") or {}
        return d.get("tx_ref"), f"{e.get('event')}:{d.get('id')}"

PROVIDERS = {"paystack": Paystack, "flutterwave": Flutterwave}

def get_provider(name):
    """Return an instance only if enabled by the owner AND configured. Never pretends to be connected."""
    cls = PROVIDERS.get(name)
    if not cls: return None
    p = cls()
    return p if settings.flag(f"pay.{name}.enabled") and p.configured() else None

def active_providers():
    return [p for p in (get_provider(n) for n in PROVIDERS) if p]
