"""Homepage hero carousel: slides and rotation settings live in the database (table hero_slides + 'hero.*' settings).

The public page reads them on every request, so an admin change shows immediately with no code change or redeploy.
Uploaded pictures are re-encoded here into three small WebP sizes (phones load the small one) and always fall back to a built-in
illustration, so a slide never shows a broken image."""
import io, os, secrets
from PIL import Image, ImageOps
from flask import current_app, url_for
from ..db import q, q1, ex, val
from ..util import now
from . import settings as S, uploads

ART = {"academic": "Books and graduation cap", "income": "Laptop with rising earnings", "faith": "Open book under rays of light", "professional": "Briefcase and certificate"}
TONES = {"purple": "Deep purple", "blue": "Royal blue", "ink": "Black and purple"}
FOCUS = {"center": "Centre", "top": "Top (faces, headlines)", "bottom": "Bottom", "left": "Left", "right": "Right"}
WIDTHS = (480, 800, 1200)        # 800 is the main file; 480 and 1200 only exist when the source is wide enough
MAX_SLIDES = 10
LIMITS = dict(label=40, headline=70, description=170, cta_label=28, cta2_label=28, image_alt=140, cta_url=300, cta2_url=300)
INTERVAL_MIN, INTERVAL_MAX = 3, 20

# ------------------------------------------------------------------ settings
def autoplay(): return S.get("hero.autoplay", "1") in ("1", "true", "on", "yes")
def interval():
    try: return max(INTERVAL_MIN, min(INTERVAL_MAX, int(float(S.get("hero.interval", "6")))))
    except (TypeError, ValueError): return 6

def save_settings(form):
    try: n = int(float((form.get("interval") or "").strip()))
    except ValueError: return f"Seconds per slide must be a number between {INTERVAL_MIN} and {INTERVAL_MAX}."
    if not INTERVAL_MIN <= n <= INTERVAL_MAX: return f"Seconds per slide must be between {INTERVAL_MIN} and {INTERVAL_MAX}."
    S.put("hero.autoplay", "1" if form.get("autoplay") else "0"); S.put("hero.interval", str(n)); return None

# ------------------------------------------------------------------ validation
def safe_link(u):
    u = (u or "").strip()
    return bool(u) and ((u.startswith("/") and not u.startswith("//") and "\\" not in u) or u.startswith("https://")) and not any(c in u for c in " \t\r\n<>\"'")

def build(form, row=None):
    """Validate the slide form. Returns (values, errors); image handling is done by the caller."""
    v, errs = {}, []
    g = lambda k: (form.get(k) or "").strip()
    for k, mx in LIMITS.items():
        if k in ("cta_url", "cta2_url"): continue
        v[k] = g(k)
        if len(v[k]) > mx: errs.append(f"{k.replace('_', ' ').capitalize()} is too long (maximum {mx} characters).")
    if not v["headline"]: errs.append("Headline is required.")
    for lab, url, nm in (("cta_label", "cta_url", "Main button"), ("cta2_label", "cta2_url", "Second button")):
        u = g(url); v[url] = u
        if v[lab] and not u: errs.append(f"{nm}: add a link, or clear the label.")
        elif u and not safe_link(u): errs.append(f"{nm} link must start with / (a page on this site) or https://")
        elif u and not v[lab]: errs.append(f"{nm}: add a label for the link, or clear the link.")
        if len(u) > LIMITS[url]: errs.append(f"{nm} link is too long.")
    for k, allowed in (("art", ART), ("tone", TONES), ("focus", FOCUS)):
        v[k] = g(k) or (row[k] if row else next(iter(allowed)))
        if v[k] not in allowed: errs.append(f"Choose a valid {k}.")
    v["active"] = 1 if form.get("active") else 0
    return v, errs

# ------------------------------------------------------------------ images
def _ext_for_webp():
    b = io.BytesIO()
    try: Image.new("RGB", (4, 4)).save(b, "WEBP"); return "webp"
    except Exception: return "jpg"

def save_image(fs, max_bytes=15 * 1024 * 1024):
    """Validate, upright, and write 480/800/1200 px versions. Returns (file name, 'w1,w2,..')."""
    data, ext, _ = uploads._validate(fs, ("jpg", "png", "webp"), max_bytes)
    try:
        Image.MAX_IMAGE_PIXELS = 80_000_000
        im = Image.open(io.BytesIO(data)); im.load(); im = ImageOps.exif_transpose(im)
        if im.mode in ("RGBA", "LA", "P"):                       # flatten transparency on white: photos need no alpha
            im = im.convert("RGBA"); bg = Image.new("RGB", im.size, (255, 255, 255)); bg.paste(im, mask=im.split()[-1]); im = bg
        elif im.mode != "RGB": im = im.convert("RGB")
        im.thumbnail((2400, 3000))
        ext = _ext_for_webp(); token = secrets.token_hex(12); d = current_app.config["PUBLIC_DIR"]; os.makedirs(d, exist_ok=True)
        widths = [w for w in WIDTHS if w <= im.width] or [im.width]
        main = 800 if 800 <= im.width else max(widths)
        for w in sorted(set(widths + [main])):
            r = im if w == im.width else im.resize((w, max(1, round(im.height * w / im.width))), Image.LANCZOS)
            fn = f"{token}.{ext}" if w == main else f"{token}-{w}.{ext}"
            if ext == "webp": r.save(os.path.join(d, fn), "WEBP", quality=70, method=4)
            else: r.save(os.path.join(d, fn), "JPEG", quality=72, optimize=True, progressive=True)
        sizes = sorted(set(widths + [main]))
        return f"{token}.{ext}", ",".join(map(str, sizes))
    except uploads.UploadError: raise
    except Exception:
        raise uploads.UploadError("This image could not be processed. It may be damaged or incomplete. Please try another copy, or re-save it as JPG or PNG.")

def _variant_names(name, sizes):
    base, ext = os.path.splitext(name or "")
    out = [name] if name else []
    for w in (sizes or "").split(","):
        if w.strip().isdigit(): out.append(f"{base}-{int(w)}{ext}")
    return out

def drop_image(name, sizes):
    """Delete a replaced/removed picture and its smaller versions unless another slide still uses it."""
    if not name or val("SELECT 1 FROM hero_slides WHERE image=?", (name,)): return
    d = current_app.config["PUBLIC_DIR"]
    for fn in _variant_names(name, "480,800,1200"):
        try: os.remove(os.path.join(d, os.path.basename(fn)))
        except OSError: pass

def image_urls(row):
    """(src, srcset) for an uploaded picture, or (None, None)."""
    if not row["image"]: return None, None
    base, ext = os.path.splitext(row["image"]); ws = [int(w) for w in (row["image_sizes"] or "").split(",") if w.strip().isdigit()]
    main = url_for("public.media", name=row["image"])
    if len(ws) < 2: return main, None
    d = current_app.config["PUBLIC_DIR"]; parts = []
    for w in ws:
        fn = row["image"] if w == 800 or (w == max(ws) and 800 not in ws) else f"{base}-{w}{ext}"
        if os.path.exists(os.path.join(d, fn)): parts.append(f"{url_for('public.media', name=fn)} {w}w")
    return main, (", ".join(parts) if len(parts) > 1 else None)

# ------------------------------------------------------------------ queries and ordering
def all_slides(): return q("SELECT * FROM hero_slides ORDER BY position, id")

def renumber():
    for i, r in enumerate(all_slides(), 1): ex("UPDATE hero_slides SET position=? WHERE id=?", (i, r["id"]))

def move(sid, direction):
    rows = [r["id"] for r in all_slides()]
    if sid not in rows: return
    i = rows.index(sid); j = i + (-1 if direction == "up" else 1)
    if 0 <= j < len(rows):
        rows[i], rows[j] = rows[j], rows[i]
        for pos, rid in enumerate(rows, 1): ex("UPDATE hero_slides SET position=?, updated_at=? WHERE id=?", (pos, now(), rid))

def set_default(sid):
    ex("UPDATE hero_slides SET is_default=0 WHERE is_default=1"); ex("UPDATE hero_slides SET is_default=1, active=1, updated_at=? WHERE id=?", (now(), sid))

def public():
    """Everything the homepage needs: active slides in order, start index, rotation settings, image URLs."""
    slides = []
    for r in q("SELECT * FROM hero_slides WHERE active=1 ORDER BY position, id"):
        d = dict(r); d["src"], d["srcset"] = image_urls(r); d["art_url"] = url_for("static", filename=f"img/hero/{r['art'] if r['art'] in ART else 'academic'}.svg")
        d["alt"] = r["image_alt"] or ""
        slides.append(d)
    start = next((i for i, s in enumerate(slides) if s["is_default"]), 0)
    return dict(slides=slides, start=start, autoplay=autoplay() and len(slides) > 1, interval=interval())
