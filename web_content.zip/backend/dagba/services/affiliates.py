"""Affiliate / influencer programme.

HOW ATTRIBUTION WORKS
1. Someone opens an affiliate's link (/r/<name>, or any page with ?ref=<name>). A signed first-party cookie remembers the affiliate
   for a year. FIRST LINK WINS: if the browser already carries a valid cookie for an active affiliate, a later link from another
   affiliate does not replace it.
2. The moment that person creates an account, the affiliate is written onto the user row (users.referred_by_affiliate). From then
   on the link no longer matters: the person can log in from any device, type the normal web address, and every purchase they make
   is credited to that affiliate.
3. When a payment is approved the commission is added to the ledger in the same database transaction (exactly once); a refund
   adds a matching negative entry. The rate is snapshotted per sale, so changing the percentage only affects future sales.
Accounts that already existed before someone followed a link are never re-attributed; only new sign-ups are tied to a link."""
import hashlib, re, secrets, datetime as dt
from flask import current_app, request, g, has_request_context
from itsdangerous import URLSafeSerializer, BadSignature
from werkzeug.security import generate_password_hash
from ..db import get_db, q, q1, ex, val
from ..util import now, now_dt, add_days, naira, parse_naira, slugify
from . import settings, uploads, audit
from .notify import notify, notify_staff, send_email

COOKIE = "dda_ref"
COOKIE_DAYS = 365
SLUG_RE = re.compile(r"[a-z0-9][a-z0-9-]{1,28}[a-z0-9]")          # 3 to 30 characters
RESERVED = {"admin", "administrator", "staff", "support", "official", "dagba", "dagba-academy", "academy", "login", "register", "api", "static", "help", "owner", "team", "root", "www"}
EMAIL = re.compile(r"[^@\s]+@[^@\s]+\.[^@\s]+")
BOTS = re.compile(r"bot|crawl|spider|slurp|facebookexternalhit|whatsapp|telegram|preview|curl|wget|python-requests|headless", re.I)

class AffError(Exception): pass

# ------------------------------------------------------------------ settings
def enabled(): return settings.flag("affiliate.enabled")

def default_percent():
    try: return max(0.0, min(100.0, float(settings.get("affiliate.percent", "20"))))
    except ValueError: return 20.0

def rate_for(aff):
    """The percentage that applies to `aff` right now (their own rate if set, otherwise the site-wide default)."""
    return float(aff["percent"]) if aff["percent"] is not None else default_percent()

def min_kobo():
    try: return max(0, int(round(float(settings.get("affiliate.min_naira", "0")) * 100)))
    except ValueError: return 0

def share(amount_kobo, pct): return int(amount_kobo * pct / 100.0 + 0.5)

def parse_percent(text):
    t = (text or "").strip().replace("%", "")
    if not t: return None
    try: p = float(t)
    except ValueError: raise AffError("The percentage must be a number from 0 to 100.")
    if not 0 <= p <= 100: raise AffError("The percentage must be a number from 0 to 100.")
    return p

# ------------------------------------------------------------------ lookups & slugs
def by_slug(slug): return q1("SELECT * FROM affiliates WHERE slug=?", ((slug or "").strip().lower(),))
def get(aid): return q1("SELECT * FROM affiliates WHERE id=?", (aid,))
def for_user(uid): return q1("SELECT * FROM affiliates WHERE user_id=?", (uid,)) if uid else None

def link_for(slug): return f"{current_app.config['SITE_URL']}/r/{slug}"

def check_slug(text, exclude_id=None):
    """Normalise a preferred name into a link name, or explain why it cannot be used."""
    s = slugify(text) if (text or "").strip() else ""
    if not SLUG_RE.fullmatch(s): raise AffError("The link name must be 3 to 30 characters: letters, numbers and hyphens only (for example: chioma or chioma-okafor).")
    if s in RESERVED: raise AffError("That link name is reserved. Please choose another.")
    if val("SELECT 1 FROM affiliates WHERE slug=? AND id IS NOT ?", (s, exclude_id)) or val("SELECT 1 FROM tutor_profiles WHERE code=?", (s,)): raise AffError("That link name is already taken. Please choose another.")
    return s

def _derive(text):
    base = slugify(text)[:26].strip("-") or "partner"
    if len(base) < 3: base += "-dda"
    s, n = base, 2
    while s in RESERVED or val("SELECT 1 FROM affiliates WHERE slug=?", (s,)) or val("SELECT 1 FROM tutor_profiles WHERE code=?", (s,)): s = f"{base}-{n}"; n += 1
    return s

# ------------------------------------------------------------------ attribution cookie
def _signer(): return URLSafeSerializer(current_app.config["SECRET_KEY"], salt="dda-affiliate-ref")

def read_cookie():
    raw = request.cookies.get(COOKIE) if has_request_context() else None
    if not raw: return None
    try:
        d = _signer().loads(raw)
        return d if isinstance(d, dict) and isinstance(d.get("a"), int) and isinstance(d.get("v"), str) else None
    except BadSignature: return None

def cookie_value(aid, visitor): return _signer().dumps({"a": int(aid), "v": visitor})

def landing(slug):
    """Called when a visitor lands on an affiliate link. Records the click and decides whether to (re)write the cookie.
    Returns the cookie value to set, or None to leave the browser's cookie as it is."""
    if not enabled(): return None
    aff = by_slug(slug)
    if not aff or aff["status"] != "active": return None
    me = g.get("user")
    if me: return None                         # already has an account: links only attribute NEW sign-ups
    if BOTS.search(request.headers.get("User-Agent", "")): return None   # link previews / crawlers must not count or set cookies
    cur = read_cookie()
    visitor = cur["v"] if cur else secrets.token_urlsafe(9)
    try:
        from ..security import rate_limited, client_ip
        counted = not rate_limited(f"aref:{client_ip()}", 60, 600)
    except Exception: counted = True
    if counted and not val("SELECT 1 FROM affiliate_clicks WHERE affiliate_id=? AND visitor=? AND created_at>?", (aff["id"], visitor, add_days(now_dt(), -30 / 1440))):
        ex("INSERT INTO affiliate_clicks(affiliate_id, visitor) VALUES (?,?)", (aff["id"], visitor))
    if cur:
        held = get(cur["a"])
        if held and held["status"] == "active" and enabled(): return None    # first link wins
    return cookie_value(aff["id"], visitor)

def attach_referral(user_id, user_name=""):
    """Called right after a new account is created. Ties the new user to the affiliate whose link they followed (if any)."""
    cur = read_cookie()
    if not cur or not enabled(): return None
    aff = get(cur["a"])
    if not aff or aff["status"] != "active" or aff["user_id"] == user_id: return None
    ex("UPDATE users SET referred_by_affiliate=?, referred_at=? WHERE id=? AND referred_by_affiliate IS NULL", (aff["id"], now(), user_id))
    audit.log("affiliate.signup", "affiliate", aff["id"], f"user {user_id}", actor={"id": user_id, "full_name": user_name or "new user", "email": ""})
    notify(aff["user_id"], "New sign-up from your link", f"{mask_name(user_name)} just created an account through your link.", "/affiliate", "affiliate")
    return aff["id"]

def mask_name(full):
    p = (full or "").split()
    if not p: return "A student"
    return p[0] + (" " + p[-1][0] + "." if len(p) > 1 else "")

# ------------------------------------------------------------------ admin: add / edit / remove
def _setup_link(uid):
    token = secrets.token_urlsafe(32)
    ex("INSERT INTO password_resets(user_id, token_hash, expires_at) VALUES (?,?,?)", (uid, hashlib.sha256(token.encode()).hexdigest(), add_days(now_dt(), 7)))
    return f"{current_app.config['SITE_URL']}/reset-password/{token}"

def create(actor, full_name, email, slug_text, percent_text):
    """Make someone an affiliate. If the email already has an account it is linked; otherwise an account is created and the admin
    receives a 7-day password-setup link to pass on. Returns (affiliate_id, setup_link_or_None)."""
    email = (email or "").strip().lower(); full_name = (full_name or "").strip()
    if not EMAIL.fullmatch(email): raise AffError("Enter a valid email address.")
    pct = parse_percent(percent_text)
    u = q1("SELECT * FROM users WHERE email=?", (email,))
    if u:
        if not u["is_active"]: raise AffError("That account is deactivated. Re-activate it under Users first.")
        old = for_user(u["id"])
        if old: raise AffError("That person is already an affiliate" + (" (currently removed: open the Removed tab and restore them)." if old["status"] == "removed" else "."))
        if u["role"] == "admin" and not actor["is_owner"] and u["id"] != actor["id"]: raise AffError("Only the owner can make an administrator an affiliate.")
    elif not full_name or len(full_name) > 120: raise AffError("Enter the person's full name.")
    slug = check_slug(slug_text) if (slug_text or "").strip() else _derive(full_name or u["full_name"])
    link = None
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        if u: uid = u["id"]
        else:
            uid = db.execute("INSERT INTO users(email,password_hash,full_name,role) VALUES (?,?,?,'student')", (email, generate_password_hash(secrets.token_urlsafe(24)), full_name)).lastrowid
        aid = db.execute("INSERT INTO affiliates(user_id,slug,percent,created_by) VALUES (?,?,?,?)", (uid, slug, pct, actor["id"])).lastrowid
        db.execute("COMMIT")
    except Exception as e:
        db.execute("ROLLBACK")
        if "UNIQUE" in str(e): raise AffError("That link name is already taken. Please choose another.")
        raise
    if not u:
        link = _setup_link(uid)
        send_email(email, "Your Dagba Digital Academy affiliate account", f"Hello {full_name},\n\nYou have been added as an affiliate. Set your password here (valid for 7 days):\n{link}\n\nYour personal link: {link_for(slug)}")
    audit.log("affiliate.created", "affiliate", aid, f"{email} /r/{slug} rate={'default' if pct is None else pct}", actor=actor)
    notify(uid, "You are now an affiliate", f"Your personal link is {link_for(slug)}. You earn a commission on every purchase made by people who sign up through it.", "/affiliate", "affiliate")
    return aid, link

def update(actor, aff, slug_text=None, percent_text=None, set_percent=False):
    """Change the link name and/or (admin only) the personal rate. Old links stop working when the name changes."""
    sets, args, notes = [], [], []
    if slug_text is not None and slug_text.strip() and slugify(slug_text) != aff["slug"]:
        s = check_slug(slug_text, aff["id"]); sets.append("slug=?"); args.append(s); notes.append(f"slug {aff['slug']} -> {s}")
    if set_percent:
        p = parse_percent(percent_text)
        if p != aff["percent"]: sets.append("percent=?"); args.append(p); notes.append(f"rate {aff['percent']} -> {p}")
    if not sets: return False
    ex(f"UPDATE affiliates SET {', '.join(sets)} WHERE id=?", tuple(args) + (aff["id"],))
    audit.log("affiliate.updated", "affiliate", aff["id"], "; ".join(notes), actor=actor); return True

def _need(aid):
    a = get(aid)
    if not a: raise AffError("Affiliate not found.")
    return a

def remove(actor, aid):
    a = _need(aid)
    if a["status"] == "removed": return
    ex("UPDATE affiliates SET status='removed', removed_at=? WHERE id=?", (now(), aid))
    audit.log("affiliate.removed", "affiliate", aid, a["slug"], actor=actor)
    notify(a["user_id"], "Affiliate access ended", "Your affiliate link is no longer active. You can still withdraw what you have already earned.", "/affiliate", "affiliate")

def restore(actor, aid):
    a = _need(aid)
    ex("UPDATE affiliates SET status='active', removed_at=NULL WHERE id=?", (aid,))
    audit.log("affiliate.restored", "affiliate", aid, a["slug"], actor=actor)

# ------------------------------------------------------------------ commission ledger (called inside payment transactions)
def record_sale(db, tx):
    """Credit the referring affiliate. Idempotent (UNIQUE(transaction_id, kind)). Called inside the payment-approval transaction."""
    if tx["amount_kobo"] <= 0 or not enabled(): return
    if tx["item_type"] == "plan" and not settings.flag("affiliate.on_plans"): return
    u = db.execute("SELECT referred_by_affiliate FROM users WHERE id=?", (tx["user_id"],)).fetchone()
    if not u or not u["referred_by_affiliate"]: return
    a = db.execute("SELECT * FROM affiliates WHERE id=? AND status='active'", (u["referred_by_affiliate"],)).fetchone()
    if not a or a["user_id"] == tx["user_id"]: return
    p = rate_for(a)
    t = db.execute("SELECT source, percent FROM instructor_earnings WHERE transaction_id=? AND kind='sale'", (tx["id"],)).fetchone()
    if t and t["source"] == "affiliate": return                    # the tutor's own link brought this sale: one commission only, never two
    if t: p = max(0.0, min(p, 100.0 - t["percent"]))               # tutor + influencer can never be paid more than the whole sale
    db.execute("INSERT OR IGNORE INTO affiliate_earnings(affiliate_id,transaction_id,buyer_id,kind,gross_kobo,percent,amount_kobo) VALUES (?,?,?,?,?,?,?)",
               (a["id"], tx["id"], tx["user_id"], "sale", tx["amount_kobo"], p, share(tx["amount_kobo"], p)))

def record_reversal(db, tx_id):
    s = db.execute("SELECT * FROM affiliate_earnings WHERE transaction_id=? AND kind='sale'", (tx_id,)).fetchone()
    if s: db.execute("INSERT OR IGNORE INTO affiliate_earnings(affiliate_id,transaction_id,buyer_id,kind,gross_kobo,percent,amount_kobo) VALUES (?,?,?,?,?,?,?)",
                     (s["affiliate_id"], tx_id, s["buyer_id"], "reversal", s["gross_kobo"], s["percent"], -s["amount_kobo"]))

def notify_sale(tx_id):
    try:
        e = q1("SELECT e.*, a.user_id AS owner, t.item_title, u.full_name FROM affiliate_earnings e JOIN affiliates a ON a.id=e.affiliate_id JOIN transactions t ON t.id=e.transaction_id JOIN users u ON u.id=t.user_id WHERE e.transaction_id=? AND e.kind='sale'", (tx_id,))
        if e: notify(e["owner"], "You earned a commission", f"{mask_name(e['full_name'])} bought {e['item_title']}. You earned {naira(e['amount_kobo'])}.", "/affiliate", "earning")
    except Exception: pass

# ------------------------------------------------------------------ numbers
def summary(aid):
    f = lambda sql, *a: val(sql, a, 0)
    earned = f("SELECT COALESCE(SUM(amount_kobo),0) FROM affiliate_earnings WHERE affiliate_id=?", aid)
    gross = f("SELECT COALESCE(SUM(CASE kind WHEN 'sale' THEN gross_kobo ELSE -gross_kobo END),0) FROM affiliate_earnings WHERE affiliate_id=?", aid)
    paid = f("SELECT COALESCE(SUM(amount_kobo),0) FROM affiliate_payouts WHERE affiliate_id=? AND status='paid'", aid)
    pending = f("SELECT COALESCE(SUM(amount_kobo),0) FROM affiliate_payouts WHERE affiliate_id=? AND status='requested'", aid)
    return dict(earned=earned, gross=gross, paid=paid, pending=pending, available=earned - paid - pending,
                sales=f("SELECT COUNT(*) FROM affiliate_earnings WHERE affiliate_id=? AND kind='sale'", aid),
                buyers=f("SELECT COUNT(DISTINCT buyer_id) FROM affiliate_earnings WHERE affiliate_id=? AND kind='sale'", aid),
                signups=f("SELECT COUNT(*) FROM users WHERE referred_by_affiliate=?", aid),
                clicks=f("SELECT COUNT(*) FROM affiliate_clicks WHERE affiliate_id=?", aid),
                visitors=f("SELECT COUNT(DISTINCT visitor) FROM affiliate_clicks WHERE affiliate_id=?", aid))

def summary_db(db, aid):
    earned = db.execute("SELECT COALESCE(SUM(amount_kobo),0) FROM affiliate_earnings WHERE affiliate_id=?", (aid,)).fetchone()[0]
    used = db.execute("SELECT COALESCE(SUM(amount_kobo),0) FROM affiliate_payouts WHERE affiliate_id=? AND status IN ('requested','paid')", (aid,)).fetchone()[0]
    return dict(earned=earned, available=earned - used)

# ------------------------------------------------------------------ withdrawals
def request_payout(user, aff, amount_text):
    if not settings.flag("affiliate.payout_enabled"): raise AffError("Withdrawal requests are currently switched off. Please contact the academy.")
    u = q1("SELECT * FROM users WHERE id=?", (user["id"],))
    if not (u["payout_bank"] and u["payout_account_name"] and u["payout_account_number"]): raise AffError("Save your bank account details first.")
    try: amount = parse_naira(amount_text)
    except ValueError as e: raise AffError(str(e))
    if amount <= 0: raise AffError("Enter the amount you want to withdraw.")
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        if db.execute("SELECT 1 FROM affiliate_payouts WHERE affiliate_id=? AND status='requested'", (aff["id"],)).fetchone(): raise AffError("You already have a withdrawal request waiting to be paid. Wait for it to be completed or cancel it first.")
        s = summary_db(db, aff["id"])
        if s["available"] <= 0: raise AffError("You can request a withdrawal once you have earned money.")
        if amount > s["available"]: raise AffError(f"You can withdraw at most {naira(s['available'])} right now.")
        if amount < min_kobo(): raise AffError(f"The minimum withdrawal is {naira(min_kobo())}.")
        rid = db.execute("INSERT INTO affiliate_payouts(affiliate_id,amount_kobo,bank_name,account_name,account_number) VALUES (?,?,?,?,?)", (aff["id"], amount, u["payout_bank"], u["payout_account_name"], u["payout_account_number"])).lastrowid
        db.execute("INSERT INTO audit_logs(actor_id,actor_label,action,entity,entity_id,detail) VALUES (?,?,?,?,?,?)", (u["id"], u["email"], "affiliate.payout_requested", "affiliate_payout", str(rid), naira(amount)))
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK"); raise
    notify_staff("affiliates.manage", "New affiliate withdrawal request", f"{u['full_name']} requested {naira(amount)}.", f"/staff/affiliates/{aff['id']}", "payout")
    return rid

def cancel_payout(user, aff, rid):
    cur = get_db().execute("UPDATE affiliate_payouts SET status='cancelled', decided_at=? WHERE id=? AND affiliate_id=? AND status='requested'", (now(), rid, aff["id"]))
    if cur.rowcount != 1: raise AffError("This request can no longer be cancelled.")
    audit.log("affiliate.payout_cancelled", "affiliate_payout", rid, actor=user)

def _can_decide(actor, aff):
    from ..security import has_perm
    if not has_perm("affiliates.manage", actor): raise AffError("You do not have permission to manage affiliates.")
    if aff["user_id"] == actor["id"] and not actor["is_owner"]: raise AffError("You cannot decide your own withdrawal request.")

def mark_paid(actor, rid, fs, reference="", note=""):
    r = q1("SELECT * FROM affiliate_payouts WHERE id=?", (rid,))
    if not r: raise AffError("Request not found.")
    _can_decide(actor, get(r["affiliate_id"]))
    if r["status"] != "requested": raise AffError("This request has already been processed.")
    if not fs or not fs.filename: raise AffError("Upload the transfer receipt before marking this payout as paid.")
    try: stored, _e, mime, _s = uploads.save_private(fs, ("jpg", "png", "pdf"), 8 * 1024 * 1024)
    except uploads.UploadError as e: raise AffError(str(e))
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        cur = db.execute("UPDATE affiliate_payouts SET status='paid', decided_by=?, decided_at=?, receipt_file=?, receipt_name=?, receipt_mime=?, transfer_reference=?, admin_note=? WHERE id=? AND status='requested'",
                         (actor["id"], now(), stored, (fs.filename or "")[:120], mime, (reference or "")[:80], (note or "")[:1000], rid))
        if cur.rowcount != 1: raise AffError("This request has already been processed.")
        db.execute("INSERT INTO audit_logs(actor_id,actor_label,action,entity,entity_id,detail) VALUES (?,?,?,?,?,?)", (actor["id"], f"{actor['full_name']} <{actor['email']}>", "affiliate.payout_paid", "affiliate_payout", str(rid), f"{naira(r['amount_kobo'])} ref {reference}"[:300]))
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK")
        from . import payouts as _p; _p.uploads_cleanup(stored); raise
    notify(get(r["affiliate_id"])["user_id"], "Your withdrawal has been paid", f"{naira(r['amount_kobo'])} was sent to your bank account. The receipt is on your affiliate page.", "/affiliate", "payout", email=True)

def reject_payout(actor, rid, reason):
    r = q1("SELECT * FROM affiliate_payouts WHERE id=?", (rid,))
    if not r: raise AffError("Request not found.")
    a = get(r["affiliate_id"]); _can_decide(actor, a)
    if not (reason or "").strip(): raise AffError("Give the affiliate a reason.")
    cur = get_db().execute("UPDATE affiliate_payouts SET status='rejected', decided_by=?, decided_at=?, reject_reason=? WHERE id=? AND status='requested'", (actor["id"], now(), reason.strip()[:1000], rid))
    if cur.rowcount != 1: raise AffError("This request has already been processed.")
    audit.log("affiliate.payout_rejected", "affiliate_payout", rid, reason[:200], actor=actor)
    notify(a["user_id"], "Your withdrawal was declined", reason.strip()[:300], "/affiliate", "payout", email=True)
