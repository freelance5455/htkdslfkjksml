from ..db import get_db, q, q1, ex, val
from ..util import now, now_dt, add_days, new_reference, parse_ts, naira
from . import settings, uploads, audit
from .notify import notify, notify_staff
from .content import ctf
from . import payouts, affiliates

OPEN = ("awaiting_payment", "pending_verification", "info_requested")

class PayError(Exception): pass

def price_item(item_type, item_id):
    if item_type == "subject":
        from .access import subject_scope
        t = q1("SELECT * FROM categories WHERE id=? AND active=1", (item_id,))
        if not t or subject_scope(t) is None: raise PayError("This subject is not available.")      # Basic, Advanced or Professional Development subjects only
        if t["price_kobo"] <= 0: raise PayError("This subject has no price set yet.")
        return dict(title=t["name"] + " (full subject)", division=t["division"], price=t["price_kobo"], course_id=None, plan_id=None, faith_series_id=None, faith_topic_id=None, subject_id=t["id"])
    if item_type == "course":
        c = q1("SELECT * FROM courses WHERE id=? AND status='published'", (item_id,))
        if not c: raise PayError("This course is not available.")
        from .access import sells_by_subject
        if sells_by_subject(c): raise PayError("This course is sold as part of its subject. Buy the subject to unlock it.")
        if c["price_kobo"] <= 0: raise PayError("This course is free; no payment is needed.")
        return dict(title=c["title"], division=c["division"], price=c["price_kobo"], course_id=c["id"], plan_id=None, faith_series_id=None, faith_topic_id=None)
    if item_type == "faith_topic":
        t = q1("SELECT * FROM faith_topics WHERE id=? AND active=1", (item_id,))
        if not t: raise PayError("This topic is not available.")
        if t["price_kobo"] <= 0: raise PayError("This topic is free; no payment is needed.")
        return dict(title=t["name"] + " (all lessons)", division="faith", price=t["price_kobo"], course_id=None, plan_id=None, faith_series_id=None, faith_topic_id=t["id"])
    if item_type == "faith":
        s = q1("SELECT * FROM faith_series WHERE id=? AND status='published'", (item_id,))
        if not s: raise PayError("This course is not available.")
        if s["price_kobo"] <= 0: raise PayError("This course is free; no payment is needed.")
        return dict(title=s["title"], division="faith", price=s["price_kobo"], course_id=None, plan_id=None, faith_series_id=s["id"], faith_topic_id=None)
    p = q1("SELECT * FROM plans WHERE id=? AND active=1", (item_id,))
    if not p: raise PayError("This plan is not available.")
    if p["price_kobo"] <= 0: raise PayError("This plan has no price set yet.")
    return dict(title=p["name"], division=p["division"], price=p["price_kobo"], course_id=None, plan_id=p["id"], faith_series_id=None, faith_topic_id=None)

def evaluate_promo(code, item_type, price):
    """Server-side promo validation. Returns (promo_row, discount_kobo)."""
    code = (code or "").strip()
    if not code: return None, 0
    p = q1("SELECT * FROM promos WHERE code=? AND active=1", (code,))
    n = now()
    if (not p or (p["starts_at"] and p["starts_at"] > n) or (p["expires_at"] and p["expires_at"] < n)
            or (p["applies_to"] == "courses" and item_type not in ("course", "faith", "faith_topic", "subject")) or (p["applies_to"] == "plans" and item_type != "plan")):
        raise PayError("That promo code is not valid.")
    if p["max_uses"] and val("SELECT COUNT(*) FROM transactions WHERE promo_id=? AND status='approved'", (p["id"],), 0) >= p["max_uses"]:
        raise PayError("That promo code has reached its usage limit.")
    d = price * p["percent_off"] // 100 + p["amount_off_kobo"]
    return p, max(0, min(price, d))

def create_transaction(user, item_type, item_id, promo_code=None):
    it = price_item(item_type, item_id)
    from .access import course_entitled
    if item_type == "course" and course_entitled(user["id"], item_id):
        raise PayError("You already have access to this course.")
    if item_type == "subject":
        from .access import subject_entitled
        if subject_entitled(user["id"], item_id): raise PayError("You already have access to this subject.")
    if item_type == "faith":
        from .faith import series_entitled
        if series_entitled(user["id"], item_id): raise PayError("You already have access to this course.")
    if item_type == "faith_topic":
        from .faith import topic_entitled
        if topic_entitled(user["id"], item_id): raise PayError("You already have access to this topic.")
    col = {"course": "course_id", "faith": "faith_series_id", "faith_topic": "faith_topic_id", "subject": "subject_id"}.get(item_type, "plan_id")
    existing = q1(f"SELECT * FROM transactions WHERE user_id=? AND {col}=? AND item_type=? AND status IN ('awaiting_payment','pending_verification','info_requested')",
                  (user["id"], item_id, item_type))
    if existing: return existing
    promo, disc = evaluate_promo(promo_code, item_type, it["price"])
    amount = it["price"] - disc
    for _ in range(5):
        ref = new_reference()
        try:
            tid = ex("""INSERT INTO transactions(reference,user_id,item_type,course_id,plan_id,faith_series_id,faith_topic_id,subject_id,item_title,division,list_price_kobo,discount_kobo,amount_kobo,promo_id,method)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                     (ref, user["id"], item_type, it["course_id"], it["plan_id"], it["faith_series_id"], it["faith_topic_id"], it.get("subject_id"), it["title"], it["division"], it["price"], disc, amount,
                      promo["id"] if promo else None, "manual_transfer"))
            break
        except Exception as e:  # unique collision on reference: retry
            if "UNIQUE" not in str(e): raise
    else: raise PayError("Could not create a transaction reference. Try again.")
    audit.log("payment.created", "transaction", tid, f"{ref} {it['title']} {naira(amount)}", actor=user)
    if item_type == "course":
        from . import tutors
        tutors.attribute(tid, user, q1("SELECT * FROM courses WHERE id=?", (item_id,)))      # tutor referral inside the attribution window (never blocks a purchase)
    tx = q1("SELECT * FROM transactions WHERE id=?", (tid,))
    if amount == 0:  # 100% promotion: no money involved, server grants directly and records it
        db = get_db(); db.execute("BEGIN IMMEDIATE")
        try: _approve(db, tx, None, "promo"); db.execute("COMMIT")
        except Exception: db.execute("ROLLBACK"); raise
        tx = q1("SELECT * FROM transactions WHERE id=?", (tid,))
    return tx

def get_for_user(ref, user):
    tx = q1("SELECT * FROM transactions WHERE reference=? AND user_id=?", (ref, user["id"]))
    if not tx: raise PayError("Transaction not found.")
    return tx

def submit_evidence(tx, user, f, form):
    if tx["user_id"] != user["id"]: raise PayError("Not your transaction.")
    if tx["method"] != "manual_transfer": raise PayError("This transaction uses a different payment method.")
    if not settings.flag("bank.enabled"): raise PayError("Manual bank transfer is currently unavailable.")
    resub = tx["status"] == "rejected" and settings.flag("bank.allow_resubmit")
    if tx["status"] not in ("awaiting_payment", "info_requested") and not resub:
        raise PayError("Payment evidence cannot be submitted for this transaction in its current state.")
    have_file = bool(f and f.filename)
    if not have_file and settings.flag("bank.receipt_required"): raise PayError("Please upload your payment receipt.")
    if not have_file and not (form.get("note") or "").strip(): raise PayError("Upload a receipt or add transfer details.")
    name = orig = mime = None; size = 0
    if have_file:
        try: name, _ext, mime, size = uploads.save_private(f, uploads.allowed_receipt_types(), uploads.receipt_max_bytes())
        except uploads.UploadError as e: raise PayError(str(e))
    td = (form.get("transfer_date") or "").strip()
    if td and not parse_ts(td): raise PayError("Enter a valid transfer date.")
    sent = None
    if (form.get("amount_sent") or "").strip():
        from ..util import parse_naira
        try: sent = parse_naira(form["amount_sent"])
        except ValueError as e: raise PayError(str(e))
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        cur = db.execute("UPDATE transactions SET status='pending_verification', submitted_at=?, updated_at=?, info_request=NULL, decision_reason=NULL "
                         "WHERE id=? AND status IN ('awaiting_payment','info_requested','rejected')", (now(), now(), tx["id"]))
        if cur.rowcount != 1: raise PayError("This transaction can no longer accept evidence.")
        db.execute("""INSERT INTO payment_evidence(transaction_id,file,original_name,mime,size,transfer_date,sender_name,sender_bank,amount_sent_kobo,note)
                      VALUES (?,?,?,?,?,?,?,?,?,?)""",
                   (tx["id"], name or "", (f.filename or "")[:120] if have_file else None, mime or "none", size, td or None,
                    (form.get("sender_name") or "")[:120], (form.get("sender_bank") or "")[:120], sent, (form.get("note") or "")[:1000]))
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK"); raise
    audit.log("payment.evidence_submitted", "transaction", tx["id"], tx["reference"], actor=user)
    notify_staff("payments.manage", "New payment awaiting verification",
                 f"{user['full_name']} submitted proof for {tx['item_title']} ({naira(tx['amount_kobo'])}) ref {tx['reference']}.",
                 f"/staff/payments/{tx['id']}", "payment")
    notify(user["id"], ctf("notif.submitted_title"), ctf("notif.submitted_body", item=tx["item_title"]),
           f"/pay/{tx['reference']}", "payment")

def cancel(tx, user):
    if tx["user_id"] != user["id"] or tx["status"] not in ("awaiting_payment", "info_requested"):
        raise PayError("This transaction cannot be cancelled.")
    ex("UPDATE transactions SET status='cancelled', updated_at=? WHERE id=?", (now(), tx["id"]))
    audit.log("payment.cancelled", "transaction", tx["id"], tx["reference"], actor=user)

def _grant(db, tx, ts):
    """Create exactly one entitlement for a transaction (UNIQUE(transaction_id) guards duplicates)."""
    start = now_dt()
    if tx["item_type"] == "faith_topic":
        s = db.execute("SELECT access_policy, access_days FROM faith_topics WHERE id=?", (tx["faith_topic_id"],)).fetchone()
        exp = add_days(start, s["access_days"]) if s["access_policy"] == "days" and s["access_days"] else None
        db.execute("INSERT OR IGNORE INTO faith_access(user_id,topic_id,starts_at,expires_at,transaction_id) VALUES (?,?,?,?,?)", (tx["user_id"], tx["faith_topic_id"], ts, exp, tx["id"]))
    elif tx["item_type"] == "faith":
        s = db.execute("SELECT access_policy, access_days FROM faith_series WHERE id=?", (tx["faith_series_id"],)).fetchone()
        exp = add_days(start, s["access_days"]) if s["access_policy"] == "days" and s["access_days"] else None
        db.execute("INSERT OR IGNORE INTO faith_access(user_id,series_id,starts_at,expires_at,transaction_id) VALUES (?,?,?,?,?)", (tx["user_id"], tx["faith_series_id"], ts, exp, tx["id"]))
    elif tx["item_type"] == "subject":
        s = db.execute("SELECT access_policy, access_days, division, level FROM categories WHERE id=?", (tx["subject_id"],)).fetchone()
        exp = add_days(start, s["access_days"]) if s["access_policy"] == "days" and s["access_days"] else None
        scope = "professional" if s["division"] == "professional" else (s["level"] or "basic")       # the subject entitlement records its own division and level; it never touches a subscription
        db.execute("INSERT OR IGNORE INTO entitlements(user_id,kind,category_id,division,level,starts_at,expires_at,transaction_id) VALUES (?,?,?,?,?,?,?,?)",
                   (tx["user_id"], "subject", tx["subject_id"], s["division"], scope, ts, exp, tx["id"]))
    elif tx["item_type"] == "course":
        c = db.execute("SELECT access_policy, access_days FROM courses WHERE id=?", (tx["course_id"],)).fetchone()
        exp = add_days(start, c["access_days"]) if c["access_policy"] == "days" and c["access_days"] else None
        db.execute("INSERT OR IGNORE INTO entitlements(user_id,kind,course_id,division,starts_at,expires_at,transaction_id) VALUES (?,?,?,?,?,?,?)",
                   (tx["user_id"], "course", tx["course_id"], tx["division"], ts, exp, tx["id"]))
    else:
        p = db.execute("SELECT duration_days, division, level FROM plans WHERE id=?", (tx["plan_id"],)).fetchone()
        lvl = ("income" if p["division"] != "academic" else (p["level"] or "basic"))
        cur = db.execute("""SELECT MAX(expires_at) m, SUM(expires_at IS NULL) lifetime FROM entitlements WHERE user_id=? AND kind='subscription'
                            AND COALESCE(level, CASE WHEN division='academic' THEN 'basic' ELSE 'income' END)=?
                            AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at>?)""", (tx["user_id"], lvl, ts)).fetchone()
        base = parse_ts(cur["m"]) if cur and cur["m"] and parse_ts(cur["m"]) > start else start  # renewals stack on remaining time
        db.execute("INSERT OR IGNORE INTO entitlements(user_id,kind,plan_id,division,level,starts_at,expires_at,transaction_id) VALUES (?,?,?,?,?,?,?,?)",
                   (tx["user_id"], "subscription", tx["plan_id"], tx["division"], lvl, ts, add_days(base, p["duration_days"]), tx["id"]))

def _approve(db, tx, actor_id, method):
    ts = now()
    cur = db.execute("""UPDATE transactions SET status='approved', decided_by=?, decided_at=?, updated_at=?, method=? , info_request=NULL
                        WHERE id=? AND status IN ('pending_verification','awaiting_payment')""", (actor_id, ts, ts, method, tx["id"]))
    if cur.rowcount != 1: raise PayError("This payment is not awaiting approval (it may already have been processed).")
    _grant(db, tx, ts)
    payouts.record_sale(db, tx)          # tutor's share is credited in the same transaction as the approval
    affiliates.record_sale(db, tx)       # ...and so is the referring affiliate's commission

def _after_link(tx):
    if tx["item_type"] == "plan": return "/student"
    if tx["item_type"] == "subject":
        t = q1("SELECT name, division, level FROM categories WHERE id=?", (tx["subject_id"],))
        from .academic import subject_slug
        return f"/professional/{subject_slug(t['name'])}" if t["division"] == "professional" else f"/academic/{t['level'] or 'basic'}/{subject_slug(t['name'])}"
    if tx["item_type"] == "faith_topic": return f"/faith/topic/{q1('SELECT slug FROM faith_topics WHERE id=?', (tx['faith_topic_id'],))['slug']}"
    if tx["item_type"] == "faith": return f"/faith/series/{q1('SELECT slug FROM faith_series WHERE id=?', (tx['faith_series_id'],))['slug']}"
    return f"/courses/{q1('SELECT slug FROM courses WHERE id=?', (tx['course_id'],))['slug']}"

def _after_decision(tx_id, kind, actor, reason=""):
    try:
        tx = q1("SELECT * FROM transactions WHERE id=?", (tx_id,))
        link = f"/pay/{tx['reference']}"
        if kind == "approve": payouts.notify_sale(tx_id); affiliates.notify_sale(tx_id)
        if kind == "approve":
            notify(tx["user_id"], ctf("notif.approved_title"), ctf("notif.approved_body", item=tx["item_title"]),
                   _after_link(tx), "payment", email=True)
        elif kind == "reject":
            notify(tx["user_id"], ctf("notif.rejected_title"), ctf("notif.rejected_body", reason=reason), link, "payment", email=True)
        elif kind == "info":
            notify(tx["user_id"], ctf("notif.info_title"), reason, link, "payment", email=True)
    except Exception:
        pass  # notification failure must never undo or block the decision

def decide(tx_id, actor, action, text="", note=""):
    """action: approve | reject | info. Atomic; idempotent against double clicks / double approval."""
    from ..security import has_perm
    if not has_perm("payments.manage", actor): raise PayError("You do not have permission to verify payments.")
    text = (text or "").strip()
    if action in ("reject", "info") and not text: raise PayError("Please provide a reason / the information needed.")
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        tx = db.execute("SELECT * FROM transactions WHERE id=?", (tx_id,)).fetchone()
        if not tx: raise PayError("Transaction not found.")
        if tx["user_id"] == actor["id"]: raise PayError("You cannot decide your own payment.")
        ts = now()
        if action == "approve":
            if tx["status"] != "pending_verification": raise PayError("Only payments pending verification can be approved.")
            _approve(db, tx, actor["id"], tx["method"])
        elif action == "reject":
            if tx["status"] not in ("pending_verification", "info_requested"): raise PayError("This payment cannot be rejected now.")
            db.execute("UPDATE transactions SET status='rejected', decision_reason=?, decided_by=?, decided_at=?, updated_at=? WHERE id=?", (text, actor["id"], ts, ts, tx_id))
        elif action == "info":
            if tx["status"] != "pending_verification": raise PayError("Information can only be requested on pending payments.")
            db.execute("UPDATE transactions SET status='info_requested', info_request=?, updated_at=? WHERE id=?", (text, ts, tx_id))
        else: raise PayError("Unknown action.")
        if note.strip(): db.execute("INSERT INTO payment_notes(transaction_id,author_id,note) VALUES (?,?,?)", (tx_id, actor["id"], note.strip()))
        db.execute("INSERT INTO audit_logs(actor_id,actor_label,action,entity,entity_id,detail) VALUES (?,?,?,?,?,?)",
                   (actor["id"], f"{actor['full_name']} <{actor['email']}>", f"payment.{action}", "transaction", str(tx_id), f"{tx['reference']} {text}"[:500]))
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK"); raise
    _after_decision(tx_id, action, actor, text)

def refund(tx_id, actor, reason):
    from ..security import has_perm
    if not has_perm("payments.refund", actor): raise PayError("You do not have permission to refund payments.")
    if not reason.strip(): raise PayError("A reason is required.")
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        cur = db.execute("UPDATE transactions SET status='refunded', decision_reason=?, updated_at=? WHERE id=? AND status='approved'", (reason, now(), tx_id))
        if cur.rowcount != 1: raise PayError("Only approved payments can be refunded.")
        db.execute("UPDATE entitlements SET revoked_at=? WHERE transaction_id=?", (now(), tx_id))
        db.execute("UPDATE faith_access SET revoked_at=? WHERE transaction_id=?", (now(), tx_id))
        payouts.record_reversal(db, tx_id)
        affiliates.record_reversal(db, tx_id)
        db.execute("INSERT INTO audit_logs(actor_id,actor_label,action,entity,entity_id,detail) VALUES (?,?,?,?,?,?)",
                   (actor["id"], actor["email"], "payment.refund", "transaction", str(tx_id), reason))
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK"); raise

def start_gateway(tx, user, provider, callback_url):
    if tx["user_id"] != user["id"] or tx["status"] != "awaiting_payment": raise PayError("This transaction cannot be paid online.")
    ex("UPDATE transactions SET method=?, updated_at=? WHERE id=?", (provider.name, now(), tx["id"]))
    return provider.initialize(tx, user, callback_url)

def finalize_gateway(reference, provider, verified):
    """Idempotent. `verified` comes from a SERVER-SIDE call to the provider API, never from the browser.
    Returns the final status string."""
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        tx = db.execute("SELECT * FROM transactions WHERE reference=?", (reference,)).fetchone()
        if not tx or tx["method"] != provider: db.execute("ROLLBACK"); return "unknown"
        if tx["status"] in ("approved", "refunded"): db.execute("COMMIT"); return tx["status"]
        if tx["status"] not in ("awaiting_payment", "failed"): db.execute("COMMIT"); return tx["status"]
        st = verified.get("status")
        if st == "success":
            if verified.get("amount_kobo") != tx["amount_kobo"] or (verified.get("currency") or "NGN") != "NGN":
                db.execute("UPDATE transactions SET status='failed', decision_reason='Gateway amount/currency mismatch - needs manual review', updated_at=? WHERE id=?", (now(), tx["id"]))
                db.execute("COMMIT"); notify_staff("payments.manage", "Gateway payment mismatch", f"Ref {reference}: amount mismatch, review manually.", f"/staff/payments/{tx['id']}", "payment")
                return "failed"
            _approve(db, tx, None, provider)
            db.execute("INSERT INTO audit_logs(actor_label,action,entity,entity_id,detail) VALUES (?,?,?,?,?)", (provider, "payment.gateway_approved", "transaction", str(tx["id"]), reference))
            db.execute("COMMIT"); _after_decision(tx["id"], "approve", None); return "approved"
        if st == "failed":
            db.execute("UPDATE transactions SET status='failed', decision_reason='Payment failed at gateway', updated_at=? WHERE id=?", (now(), tx["id"]))
            db.execute("COMMIT"); return "failed"
        db.execute("COMMIT"); return tx["status"]
    except Exception:
        db.execute("ROLLBACK"); raise
