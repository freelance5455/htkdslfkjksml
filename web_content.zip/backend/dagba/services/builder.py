"""One-page course builder: chunked video uploads + atomic save of course, modules, lessons and quiz."""
import os, re, secrets
from flask import current_app
from ..db import get_db, q, q1, ex, val
from ..util import now, unique_slug, parse_naira
from . import settings, audit, uploads as U, release as R

VIDEO_EXT = {"mp4": "video/mp4", "m4v": "video/mp4", "webm": "video/webm"}
AUDIO_EXT = {"mp3": "audio/mpeg", "m4a": "audio/mp4", "aac": "audio/aac", "ogg": "audio/ogg", "oga": "audio/ogg", "opus": "audio/ogg", "wav": "audio/wav"}
CHUNK = 4 * 1024 * 1024
KINDS = ("text", "video", "pdf", "embed")

class BuilderError(Exception):
    def __init__(self, msg, status=400, **extra): super().__init__(msg); self.status = status; self.extra = extra

def video_limit_mb():
    try: return max(10, min(2000, int(float(settings.get("video.max_mb", "500")))))
    except ValueError: return 500

def audio_limit_mb():
    try: return max(5, min(1000, int(float(settings.get("faith.audio_max_mb", "200")))))
    except ValueError: return 200

def _priv(): return current_app.config["PRIVATE_DIR"]
def _tmp(): d = os.path.join(_priv(), "tmp"); os.makedirs(d, exist_ok=True); return d
def _rm(path):
    try: os.remove(path)
    except OSError: pass

# ---------------------------------------------------------------- chunked uploads
def init_upload(user, name, size, kind="video"):
    ext = (name or "").rsplit(".", 1)[-1].lower()
    if kind == "audio":
        if ext not in AUDIO_EXT: raise BuilderError("Only MP3, M4A, AAC, OGG, OPUS or WAV audio files are supported.")
        limit, what = audio_limit_mb(), "Audio file"
    else:
        kind = "video"
        if ext not in VIDEO_EXT: raise BuilderError("Only MP4 or WebM videos are supported.")
        limit, what = video_limit_mb(), "Video"
    if not isinstance(size, int) or size <= 0: raise BuilderError("Empty file.")
    if size > limit * 1024 * 1024: raise BuilderError(f"{what} is too large (limit {limit} MB).")
    for r in q("SELECT id FROM uploads WHERE status='partial' AND created_at < datetime('now','-1 day')"):   # tidy abandoned partials
        _rm(os.path.join(_tmp(), r["id"] + ".part")); ex("DELETE FROM uploads WHERE id=?", (r["id"],))
    for r in q("SELECT id, stored_name FROM uploads WHERE status='ready' AND created_at < datetime('now','-2 day')"):   # uploaded but never attached to a lesson
        if r["stored_name"] and not val("SELECT 1 FROM lessons WHERE video_file=? OR resource_file=?", (r["stored_name"], r["stored_name"])) \
           and not val("SELECT 1 FROM faith_items WHERE video_file=? OR audio_file=? OR resource_file=?", (r["stored_name"],) * 3):
            _rm(os.path.join(_priv(), r["stored_name"])); ex("DELETE FROM uploads WHERE id=?", (r["id"],))
    uid = secrets.token_hex(16)
    ex("INSERT INTO uploads(id,user_id,kind,original_name,size) VALUES (?,?,?,?,?)", (uid, user["id"], kind, name[:150], size))
    open(os.path.join(_tmp(), uid + ".part"), "wb").close()
    return uid

def append_chunk(user, uid, index, data):
    u = q1("SELECT * FROM uploads WHERE id=? AND user_id=? AND status='partial'", (uid, user["id"]))
    if not u: raise BuilderError("Upload not found.", 404)
    if index != u["next_index"]: raise BuilderError("Chunk out of order.", 409, expected=u["next_index"], received=u["received"])
    if not data or len(data) > 2 * CHUNK: raise BuilderError("Invalid chunk size.")
    if u["received"] + len(data) > u["size"]: raise BuilderError("More data than declared.")
    path = os.path.join(_tmp(), uid + ".part")
    with open(path, "ab") as f:
        f.truncate(u["received"]); f.seek(u["received"]); f.write(data)       # heals a half-written retry
    ex("UPDATE uploads SET next_index=next_index+1, received=received+? WHERE id=?", (len(data), uid))
    return u["received"] + len(data)

def finish_upload(user, uid):
    u = q1("SELECT * FROM uploads WHERE id=? AND user_id=? AND status='partial'", (uid, user["id"]))
    if not u: raise BuilderError("Upload not found.", 404)
    path = os.path.join(_tmp(), uid + ".part")
    if u["received"] != u["size"] or not os.path.exists(path) or os.path.getsize(path) != u["size"]:
        raise BuilderError("Upload incomplete. Please retry.", 409, expected=u["next_index"], received=u["received"])
    with open(path, "rb") as f: head = f.read(16)
    ext = u["original_name"].rsplit(".", 1)[-1].lower()
    if u["kind"] == "audio":
        ok = (ext == "mp3" and (head[:3] == b"ID3" or (len(head) > 1 and head[0] == 0xFF and head[1] & 0xE0 == 0xE0))) or (ext == "m4a" and head[4:8] == b"ftyp") \
             or (ext in ("ogg", "oga", "opus") and head[:4] == b"OggS") or (ext == "wav" and head[:4] == b"RIFF" and head[8:12] == b"WAVE") \
             or (ext == "aac" and len(head) > 1 and head[0] == 0xFF and head[1] & 0xF6 == 0xF0)
        if not ok:
            _rm(path); ex("DELETE FROM uploads WHERE id=?", (uid,)); raise BuilderError("That file is not a valid MP3, M4A, AAC, OGG, OPUS or WAV audio file.")
        stored = secrets.token_hex(16) + "." + ("ogg" if ext in ("oga", "opus") else ext)
    else:
        is_mp4, is_webm = head[4:8] == b"ftyp", head[:4] == b"\x1a\x45\xdf\xa3"
        if not ((ext in ("mp4", "m4v") and is_mp4) or (ext == "webm" and is_webm)):
            _rm(path); ex("DELETE FROM uploads WHERE id=?", (uid,)); raise BuilderError("That file is not a valid MP4 or WebM video.")
        stored = secrets.token_hex(16) + (".webm" if is_webm else ".mp4")
    os.replace(path, os.path.join(_priv(), stored))
    ex("UPDATE uploads SET status='ready', stored_name=? WHERE id=?", (stored, uid))
    return stored, u["original_name"]

def register_resource(user, stored, original, size):
    ex("INSERT INTO uploads(id,user_id,kind,original_name,size,status,stored_name) VALUES (?,?,?,?,?,'ready',?)", (secrets.token_hex(16), user["id"], "resource", original[:150], size, stored))

# ---------------------------------------------------------------- load
def _rel(item, old, tag, errs):
    """Scheduled release from the builder: absent key = keep what is stored (older clients never wipe it); '' = release immediately; else a site-time date."""
    if "release_at" not in item: return old
    try: return R.to_utc(item.get("release_at"))
    except ValueError: errs.append(f"{tag}: enter the release date as a valid date and time."); return old

def load_course(cid):
    c = q1("SELECT * FROM courses WHERE id=?", (cid,))
    mods = []
    for m in q("SELECT * FROM modules WHERE course_id=? ORDER BY position, id", (cid,)):
        les = [dict(id=l["id"], title=l["title"], kind=l["kind"], body=l["body"] or "", video_url=l["video_url"] or "", video_file=l["video_file"] or "", video_name=l["video_name"] or "",
                    resource_file=l["resource_file"] or "", resource_name=l["resource_name"] or "", duration_min=l["duration_min"] or "", free_preview=bool(l["free_preview"]), downloadable=bool(l["downloadable"]), release_at=R.to_local(l["release_at"]))
               for l in q("SELECT * FROM lessons WHERE module_id=? AND course_id=? ORDER BY position, id", (m["id"], cid))]
        mods.append(dict(id=m["id"], title=m["title"], release_at=R.to_local(m["release_at"]), lessons=les))
    z = q1("SELECT * FROM quizzes WHERE course_id=? ORDER BY position, id LIMIT 1", (cid,))
    quiz = None
    if z:
        quiz = dict(id=z["id"], title=z["title"], pass_mark=z["pass_mark"], questions=[dict(prompt=x["prompt"], options=x["options"], correct=x["correct"], explanation=x["explanation"] or "")
                    for x in q("SELECT * FROM questions WHERE quiz_id=? ORDER BY position, id", (z["id"],))])
    keys = ("id", "title", "division", "academic_level", "category_id", "summary", "description", "thumbnail", "level", "class_level", "subject", "term", "access_policy", "access_days",
            "subscription_eligible", "certificate_enabled", "featured", "instructor_id", "status", "slug", "objectives", "outcomes")
    d = {k: c[k] for k in keys}; d["objectives"] = d["objectives"] or ""; d["outcomes"] = d["outcomes"] or ""; d["price"] = c["price_kobo"] / 100; d["modules"] = mods; d["quiz"] = quiz
    d["academic_level"] = d["academic_level"] or ("basic" if c["division"] == "academic" else ""); d["needs_review"] = bool(c["needs_review"])
    for k in ("subscription_eligible", "certificate_enabled", "featured"): d[k] = bool(d[k])
    return d

def blank_course():
    return dict(id=None, title="", division="academic", academic_level="basic", needs_review=False, category_id="", summary="", description="", thumbnail="", level="", class_level="", subject="", term="", objectives="", outcomes="", price=0, access_policy="lifetime", access_days="",
                subscription_eligible=True, certificate_enabled=True, featured=False, instructor_id="", status="draft", slug="",
                modules=[dict(id=None, title="Module 1", lessons=[])], quiz=None)

# ---------------------------------------------------------------- save
def _s(v, n): return (v if isinstance(v, str) else "").strip()[:n]
def _i(v):
    try: return int(v)
    except (TypeError, ValueError): return None

def _check_file(name, kind, user, existing):
    if not name: return None
    if existing and name == existing: return name
    if not val("SELECT 1 FROM uploads WHERE stored_name=? AND user_id=? AND kind=? AND status='ready'", (name, user["id"], kind)): return False
    return name

def division_name(d): return {"academic": "Academic", "income": "Income Skills", "professional": "Professional Development"}.get(d, str(d))

def save_course(user, p, action):
    is_admin = user["role"] == "admin"; errs = []
    cid = _i(p.get("id")); row = None
    if cid:
        row = q1("SELECT * FROM courses WHERE id=?", (cid,))
        if not row or (not is_admin and row["instructor_id"] != user["id"]): raise BuilderError("Course not found.", 404)
    title = _s(p.get("title"), 200)
    if not title: errs.append("Course title is required.")
    from . import academic as A     # Academic courses carry a level (Basic/Advanced) and a matching subject; Income Skills and Professional Development are separate divisions
    posted = _s(p.get("division"), 20) or (row["division"] if row else "")      # an edit that does not send a division keeps the stored one
    division, _lv = A.normalize(posted, _s(p.get("academic_level"), 20)); p = dict(p, academic_level=_lv)
    if row and division != row["division"]:
        # A course never changes division by accident. Only an administrator who explicitly ticks "Move to another division" may move it.
        if not (is_admin and p.get("division_change") is True): raise BuilderError("This course belongs to " + division_name(row["division"]) + " and its division cannot be changed while editing. An administrator can use 'Move this course to another division' on the course page.", 400, errors=["Division cannot be changed by editing."])
    if division not in ("academic", "income", "professional"): errs.append("Choose a division (Academic, Income Skills or Professional Development).")
    cat = _i(p.get("category_id")) if p.get("category_id") not in (None, "") else None
    if cat and not val("SELECT 1 FROM categories WHERE id=?", (cat,)): errs.append("Unknown category."); cat = None
    ae, alevel, cat = A.validate(division, _s(p.get("academic_level"), 20), cat, action == "publish"); errs += ae
    thumb = _s(p.get("thumbnail"), 60) or None
    if division == "academic" and alevel == "basic": thumb = row["thumbnail"] if row else None      # Basic courses carry no image of their own; the category does (an existing one is kept as is)
    if thumb and thumb != (row["thumbnail"] if row else None):
        # Only a NEWLY chosen cover needs checking (an existing one is never blocked, even if its file went missing). The uploader
        # produces .webp normally and .jpg/.png on servers whose image library has no WebP support, so all three are valid.
        if not (re.fullmatch(r"[0-9a-f]{24}\.(webp|jpg|png)", thumb) and os.path.exists(os.path.join(current_app.config["PUBLIC_DIR"], thumb))):
            errs.append("The cover image did not upload correctly. Choose it again, or remove it and save without a cover image.")
            thumb = None
    c = dict(title=title, division=division, academic_level=alevel, category_id=cat, summary=_s(p.get("summary"), 400) or None, description=_s(p.get("description"), 20000) or None, thumbnail=thumb,
             level=_s(p.get("level"), 60) or None, class_level=_s(p.get("class_level"), 20) or None, subject=_s(p.get("subject"), 80) or None, term=_s(p.get("term"), 40) or None)
    for k in ("objectives", "outcomes"):                                   # only when sent, so a client that does not know these fields never blanks them
        if k in p: c[k] = "\n".join(_s(x, 300) for x in (p.get(k) or "").splitlines() if x.strip())[:3000] or None
    if is_admin:
        try: c["price_kobo"] = parse_naira(str(p.get("price") or "0"))
        except ValueError as e: errs.append("Price: " + str(e))
        pol = p.get("access_policy"); c["access_policy"] = pol if pol in ("lifetime", "days") else "lifetime"
        days = _i(p.get("access_days")); c["access_days"] = days if c["access_policy"] == "days" else None
        if c["access_policy"] == "days" and (not days or days < 1): errs.append("Enter the number of access days.")
        c["subscription_eligible"] = 1 if (p.get("subscription_eligible") and division != "professional") else 0; c["certificate_enabled"] = 1 if p.get("certificate_enabled") else 0; c["featured"] = 1 if p.get("featured") else 0
        ins = _i(p.get("instructor_id")) if p.get("instructor_id") not in (None, "") else None
        if ins and not val("SELECT 1 FROM users WHERE id=? AND role IN ('instructor','admin') AND is_active=1", (ins,)): errs.append("Unknown instructor."); ins = None
        c["instructor_id"] = ins
    elif not row: c["instructor_id"] = user["id"]
    if division != "academic" or (alevel and cat): c["needs_review"] = 0      # properly classified now: leaves the review queue

    # curriculum
    mods_in = p.get("modules") if isinstance(p.get("modules"), list) else []
    ex_lessons = {r["id"]: r for r in q("SELECT * FROM lessons WHERE course_id=?", (cid,))} if cid else {}
    ex_mods = {r["id"] for r in q("SELECT id FROM modules WHERE course_id=?", (cid,))} if cid else set()
    ex_mod_rel = {r["id"]: r["release_at"] for r in q("SELECT id, release_at FROM modules WHERE course_id=?", (cid,))} if cid else {}
    clean_mods, n_lessons, seen_l, seen_m = [], 0, set(), set()
    for mi, m in enumerate(mods_in[:100]):
        mid = _i(m.get("id"))
        if mid and (mid not in ex_mods or mid in seen_m): errs.append(f"Module {mi+1}: invalid reference."); mid = None
        if mid: seen_m.add(mid)
        mt = _s(m.get("title"), 150)
        if not mt: errs.append(f"Module {mi+1}: give it a title.")
        mrel = _rel(m, ex_mod_rel.get(mid), f"Module {mi+1}", errs)
        les = []
        for li, l in enumerate((m.get("lessons") if isinstance(m.get("lessons"), list) else [])[:300]):
            tag = f"Module {mi+1}, lesson {li+1}"; lid = _i(l.get("id"))
            if lid and (lid not in ex_lessons or lid in seen_l): errs.append(f"{tag}: invalid reference."); lid = None
            if lid: seen_l.add(lid)
            old = ex_lessons.get(lid)
            lt = _s(l.get("title"), 200); kind = l.get("kind") if l.get("kind") in KINDS else "text"
            if not lt: errs.append(f"{tag}: give it a title.")
            vurl = _s(l.get("video_url"), 500); vfile = _s(l.get("video_file"), 60); rfile = _s(l.get("resource_file"), 60)
            if vurl and not vurl.startswith("https://"): errs.append(f"{tag}: video link must start with https://"); vurl = ""
            vf = _check_file(vfile, "video", user, old["video_file"] if old else None) if kind == "video" else None
            if vf is False: errs.append(f"{tag}: the uploaded video is not valid; upload it again."); vf = None
            rf = _check_file(rfile, "resource", user, old["resource_file"] if old else None)
            if rf is False: errs.append(f"{tag}: the attached file is not valid; upload it again."); rf = None
            if kind == "video":
                if not (vf or vurl): errs.append(f"{tag}: upload a video or paste a video link.")
                if vf: vurl = ""
            else: vurl = vurl if kind == "embed" else ""
            if kind == "embed" and not vurl: errs.append(f"{tag}: paste the https link to embed.")
            if kind == "pdf" and not (rf or _s(l.get("body"), 10)): errs.append(f"{tag}: attach a file.")
            dur = _i(l.get("duration_min")); lrel = _rel(l, old["release_at"] if old else None, tag, errs)
            les.append(dict(id=lid, release_at=lrel, title=lt, kind=kind, body=_s(l.get("body"), 50000) or None, video_url=vurl or None, video_file=vf, video_name=(_s(l.get("video_name"), 150) or None) if vf else None,
                            resource_file=rf, resource_name=(_s(l.get("resource_name"), 150) or None) if rf else None, duration_min=dur if dur and dur > 0 else None,
                            free_preview=1 if l.get("free_preview") else 0, downloadable=0 if l.get("downloadable") is False else 1))
            n_lessons += 1
        clean_mods.append(dict(id=mid, title=mt, release_at=mrel, lessons=les))

    # quiz (optional; the builder manages the course's first quiz)
    qz = p.get("quiz") if isinstance(p.get("quiz"), dict) else None; quiz = None
    if qz:
        zid = _i(qz.get("id")); first = q1("SELECT id FROM quizzes WHERE course_id=? ORDER BY position, id LIMIT 1", (cid,)) if cid else None
        if zid and (not first or zid != first["id"]): errs.append("Quiz: invalid reference."); zid = None
        if qz.get("delete"): quiz = dict(id=zid, delete=True)
        else:
            qs = []
            for qi, x in enumerate((qz.get("questions") if isinstance(qz.get("questions"), list) else [])[:200]):
                opts = [o.strip() for o in _s(x.get("options"), 2000).splitlines() if o.strip()]; cor = _i(x.get("correct"))
                if not _s(x.get("prompt"), 1000): errs.append(f"Quiz question {qi+1}: write the question.")
                elif not 2 <= len(opts) <= 6: errs.append(f"Quiz question {qi+1}: give 2 to 6 options, one per line.")
                elif not cor or not 1 <= cor <= len(opts): errs.append(f"Quiz question {qi+1}: the correct option number must be between 1 and {len(opts)}.")
                else: qs.append((_s(x.get("prompt"), 1000), "\n".join(opts), cor, _s(x.get("explanation"), 1000) or None))
            pm = _i(qz.get("pass_mark")); pm = 50 if pm is None else pm
            if not 0 <= pm <= 100: errs.append("Quiz pass mark must be 0-100."); pm = 50
            if qs: quiz = dict(id=zid, title=_s(qz.get("title"), 150) or "Course quiz", pass_mark=pm, questions=qs)

    # status
    status = row["status"] if row else "draft"
    if action == "publish":
        if n_lessons == 0: errs.append("Add at least one lesson before publishing or submitting for review.")
        status = "published" if is_admin else (status if status in ("published", "archived") else "review")
    if errs: raise BuilderError("Please fix the highlighted problems.", 400, errors=errs)
    c["status"] = status; c["updated_at"] = now()

    db = get_db(); db.execute("BEGIN IMMEDIATE"); gone = []
    try:
        if row:
            db.execute("UPDATE courses SET " + ", ".join(f"{k}=?" for k in c) + " WHERE id=?", tuple(c.values()) + (cid,))
        else:
            c["slug"] = unique_slug("courses", title)
            cid = db.execute("INSERT INTO courses(" + ",".join(c) + ") VALUES (" + ",".join("?" * len(c)) + ")", tuple(c.values())).lastrowid
        keep_l = set()
        for mi, m in enumerate(clean_mods):
            if m["id"]: db.execute("UPDATE modules SET title=?, position=?, release_at=? WHERE id=?", (m["title"], mi + 1, m["release_at"], m["id"])); mid = m["id"]
            else: mid = db.execute("INSERT INTO modules(course_id,title,position,release_at) VALUES (?,?,?,?)", (cid, m["title"], mi + 1, m["release_at"])).lastrowid
            for li, l in enumerate(m["lessons"]):
                vals = (mid, l["title"], l["kind"], l["body"], l["video_url"], l["video_file"], l["video_name"], l["resource_file"], l["resource_name"], l["duration_min"], li + 1, l["free_preview"], l["downloadable"], l["release_at"])
                if l["id"]:
                    old = ex_lessons[l["id"]]
                    for f in ("video_file", "resource_file"):
                        if old[f] and old[f] != l[f]: gone.append(old[f])
                    db.execute("UPDATE lessons SET module_id=?,title=?,kind=?,body=?,video_url=?,video_file=?,video_name=?,resource_file=?,resource_name=?,duration_min=?,position=?,free_preview=?,downloadable=?,release_at=? WHERE id=?", vals + (l["id"],)); keep_l.add(l["id"])
                else:
                    keep_l.add(db.execute("INSERT INTO lessons(module_id,title,kind,body,video_url,video_file,video_name,resource_file,resource_name,duration_min,position,free_preview,downloadable,release_at,course_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", vals + (cid,)).lastrowid)
        for lid, old in ex_lessons.items():
            if lid not in keep_l: gone += [f for f in (old["video_file"], old["resource_file"]) if f]; db.execute("DELETE FROM lessons WHERE id=?", (lid,))
        keep_m = {m["id"] for m in clean_mods if m["id"]}
        for mid in ex_mods:
            if mid not in keep_m: db.execute("DELETE FROM modules WHERE id=?", (mid,))
        # remove modules that were newly inserted? (they have no id in clean_mods but are kept implicitly)
        if quiz:
            if quiz.get("delete"):
                if quiz["id"]: db.execute("DELETE FROM quizzes WHERE id=?", (quiz["id"],))
            else:
                zid = quiz["id"]
                if zid: db.execute("UPDATE quizzes SET title=?, pass_mark=? WHERE id=?", (quiz["title"], quiz["pass_mark"], zid)); db.execute("DELETE FROM questions WHERE quiz_id=?", (zid,))
                else: zid = db.execute("INSERT INTO quizzes(course_id,title,pass_mark,position) VALUES (?,?,?,1)", (cid, quiz["title"], quiz["pass_mark"])).lastrowid
                for pos, (pr, op, co, exn) in enumerate(quiz["questions"], 1):
                    db.execute("INSERT INTO questions(quiz_id,course_id,prompt,options,correct,explanation,position) VALUES (?,?,?,?,?,?,?)", (zid, cid, pr, op, co, exn, pos))
        db.execute("INSERT INTO audit_logs(actor_id,actor_label,action,entity,entity_id,detail) VALUES (?,?,?,?,?,?)",
                   (user["id"], f"{user['full_name']} <{user['email']}>", "course.builder_save", "courses", str(cid), f"{title} [{status}] lessons={n_lessons}"))
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK"); raise
    for f in set(gone):                                  # delete files no lesson uses any more
        if not val("SELECT 1 FROM lessons WHERE video_file=? OR resource_file=?", (f, f)):
            _rm(os.path.join(_priv(), f)); ex("DELETE FROM uploads WHERE stored_name=?", (f,))
    return cid, status

def delete_lesson_files(lesson):
    for f in (lesson["video_file"] if "video_file" in lesson.keys() else None, lesson["resource_file"]):
        if f and not val("SELECT 1 FROM lessons WHERE (video_file=? OR resource_file=?) AND id!=?", (f, f, lesson["id"])):
            _rm(os.path.join(_priv(), f)); ex("DELETE FROM uploads WHERE stored_name=?", (f,))
