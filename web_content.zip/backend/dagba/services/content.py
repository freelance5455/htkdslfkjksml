"""Editable website text. Every string here has a default (identical to the original design) and can be overridden
from Admin > Website text & menus. Stored in the settings table under 'c.<key>'. Lists use one item per line, fields split by ' | '."""
from . import settings as S

def F(key, label, default, kind="text", help=""): return dict(key=key, label=label, default=default, kind=kind, help=help)

HEADER_NAV = "Courses | /courses\nAcademic | /academic\nIncome Skills | /income-skills\nProfessional Development | /professional\nFaith | /faith\nPricing | /pricing\nBlog | /blog\nNuggets | /nuggets\nAbout | /about\nContact | /contact"
LIST_HELP = "One item per line. Format: Label | /page-or-https://link  (links must start with / or https://)."

GROUPS = [
 ("menus", "Menus & footer", "Header menu, footer links and footer text. Add your own pages (Admin > Pages) to the menu here.", [
   F("nav.header", "Header menu", HEADER_NAV, "list", LIST_HELP),
   F("nav.footer_explore", "Footer: Explore links", "Courses | /courses\nProfessional Development | /professional\nFaith & Spiritual Growth | /faith\nPricing | /pricing\nFAQ | /faq\nVerify a certificate | /verify\nTestimonials | /testimonials\nBecome a tutor | /become-a-tutor", "list", LIST_HELP),
   F("nav.footer_legal", "Footer: Legal links", "Privacy Policy | /privacy-policy\nTerms and Conditions | /terms-and-conditions\nRefund Policy | /refund-policy", "list", LIST_HELP),
   F("footer.explore_title", "Footer: Explore heading", "Explore"), F("footer.contact_title", "Footer: Contact heading", "Contact"), F("footer.legal_title", "Footer: Legal heading", "Legal"),
   F("footer.extra", "Footer: extra line (optional)", "", "text", "Shown beside the copyright line."),
   F("ui.login", "Button: Log in", "Log in"), F("ui.signup", "Button: Sign up", "Sign up"), F("ui.my_learning", "Button: My learning", "My learning")]),
 ("home", "Homepage text", "Section titles, cards and steps. Hide any section with the checkboxes in Admin > Homepage.", [
   F("home.what_title", "Intro section title", "What is {name}?"), F("home.what_text", "Intro section text", "To simplify complex knowledge, make learning accessible and practical, and equip learners with academic knowledge and real-world skills. We complement school, we do not replace it.", "textarea"),
   F("home.what_cards", "Intro cards", "Academic learning | Secondary school subjects (Basic), university-level courses (Advanced) and professional development programmes, organised by subject. | /academic | Explore academic courses\nIncome skills | Practical, job-ready skills such as digital marketing, design, web development, freelancing and personal finance. | /income-skills | Explore income skills", "list", "One card per line: Title | Text | /link | Link label | icon (optional). Pick icons visually under Appearance > Intro card icons."),
   F("home.adv_title", "Advanced Courses section: title", "Advanced Courses"), F("home.adv_button", "Advanced Courses section: button", "Explore Advanced subjects"),
   F("home.featured_title", "Income Skills section: title", "Income Skills"), F("home.featured_sub", "Income Skills section: subtitle", "Practical, job-ready skills you can start earning from."), F("home.featured_button", "Income Skills section: button", "View all Income Skills courses"),
   F("home.pro_title", "Professional Development section: title", "Professional Development"), F("home.pro_sub", "Professional Development section: subtitle", "Professional examinations and career advancement."), F("home.pro_button", "Professional Development section: button", "View all Professional Development courses"),
   F("home.steps_title", "How it works: title", "How it works"),
   F("home.steps", "How it works: steps", "Create a free account | Sign up in a minute from your phone.\nChoose how to learn | Buy a single course or subscribe to the Academic or Income Skills plan.\nPay by bank transfer | Transfer with your unique reference and upload your receipt. Access is activated once our team confirms your payment.\nLearn and get certified | Watch lessons, take quizzes, track progress and earn a verifiable certificate.", "list", "One step per line: Title | Text"),
   F("home.why_title", "Benefits: title", "Why learn with us"),
   F("home.why", "Benefits cards", "Simplified | Complex ideas explained plainly.\nPractical | Knowledge you can apply in school and in life.\nMobile-friendly | Built to work on ordinary Android phones and modest connections.\nResume anywhere | Your progress is saved to your account on every device.", "list", "One card per line: Title | Text"),
   F("home.plans_title", "Subscription plans title", "Subscription plans"), F("home.plans_button", "Subscribe button", "Subscribe"),
   F("home.testi_title", "Testimonials title", "What learners say"), F("home.nuggets_title", "Nuggets title", "Academy nuggets"), F("home.nuggets_link", "Nuggets link text", "More nuggets \u2192"),
   F("home.articles_title", "Articles title", "Latest articles"), F("home.articles_button", "Articles button", "Read all articles"), F("home.faq_title", "FAQ title", "Frequently asked questions"), F("home.faq_link", "FAQ link text", "All FAQs"),
   F("home.news_title", "Newsletter title", "Stay in the loop"), F("home.news_button", "Newsletter button", "Subscribe"), F("home.rotor_prefix", "Rotating word prefix", "Explore")]),
 ("pages", "Page headings & messages", "Titles, introductions and empty-state messages on the public pages.", [
   F("courses.title_all", "Courses page title", "All courses"), F("courses.title_academic", "Academic page title", "Academic programmes"), F("courses.title_income", "Income Skills page title", "Income skills programmes"), F("courses.empty", "No courses message", "No courses match yet. Check back soon."),
   F("course.outline_title", "Course page: outline heading", "Course outline"), F("course.buy_button", "Course page: buy button", "Buy this course"),
   F("pricing.title", "Pricing: title", "Pricing"), F("pricing.intro", "Pricing: introduction", "Buy subjects (Basic) and courses (Advanced and Professional Development) individually, or subscribe to Basic or Advanced. The Basic, Advanced and Income Skills subscriptions are separate: buy any or all. Professional Development has no subscription. Courses you buy individually are never affected when a subscription ends.", "textarea"),
   F("pricing.subs_title", "Pricing: subscriptions heading", "Subscriptions"), F("pricing.courses_title", "Pricing: courses heading", "Individual courses"), F("pricing.subs_empty", "Pricing: no plans message", "Subscription plans will be announced soon."),
   F("blog.title", "Blog: title", "Blog"), F("blog.empty", "Blog: empty message", "No articles yet."),
   F("nuggets.title", "Nuggets: title", "Academy Nuggets"), F("nuggets.intro", "Nuggets: introduction", "Short, practical lessons you can read in a minute."), F("nuggets.empty", "Nuggets: empty message", "No nuggets published yet."),
   F("testimonials.title", "Testimonials: title", "Testimonials"), F("testimonials.empty", "Testimonials: empty message", "Testimonials from verified learners will appear here."),
   F("faq.title", "FAQ: title", "Frequently asked questions"),
   F("contact.title", "Contact: title", "Contact us"), F("contact.side_title", "Contact: details heading", "Reach us"), F("contact.success", "Contact: success message", "Thank you. Your message has been sent."),
   F("verify.title", "Certificate check: title", "Verify a certificate"),
   F("login.title", "Login: title", "Log in"), F("register.title", "Sign-up: title", "Create your account"), F("forgot.title", "Forgot password: title", "Reset your password"), F("forgot.intro", "Forgot password: introduction", "Enter your email and we will send a reset link."),
   F("checkout.title", "Checkout: title", "Checkout"), F("checkout.note", "Checkout: reassurance note", "You will get a unique reference and bank transfer details. Access is activated after payment is confirmed. We never ask for your banking password, PIN or OTP.", "textarea")]),
 ("academic", "Academic section text", "Headings and descriptions on the Academic pages (Basic, Advanced, Professional Development).", [
   F("academic.intro", "Academic page introduction", "Choose how you want to learn: secondary school subjects, university-level courses, or professional programmes.", "textarea"),
   F("academic.basic_title", "Basic: title", "Basic"), F("academic.basic_sub", "Basic: subtitle", "Secondary School Education"), F("academic.basic_text", "Basic: description", "All the subjects taught in Nigerian secondary schools, from junior to senior level, organised by subject.", "textarea"),
   F("academic.adv_title", "Advanced: title", "Advanced"), F("academic.adv_sub", "Advanced: subtitle", "University-Level Education"), F("academic.adv_text", "Advanced: description", "Deeper, university-level courses for undergraduates and serious learners. A subject like Physics appears here at university depth, separate from the secondary school version.", "textarea"),
   F("academic.pro_title", "Professional Development: title", "Professional Development"), F("academic.pro_sub", "Professional Development: subtitle", "Professional Examinations and Career Advancement"), F("academic.pro_text", "Professional Development: description", "Preparation for professional examinations, certifications and career advancement.", "textarea"),
   F("academic.soon_title", "Coming soon: heading", "Programs Coming Soon"), F("academic.soon_text", "Coming soon: message", "We are preparing programmes for professional examinations and certifications. Check back soon, or leave your email below to hear when they launch.", "textarea"),
   F("academic.explore", "Explore button", "Explore"), F("academic.subjects_title", "Subjects heading", "Choose a subject"), F("academic.subject_soon", "Subject with no courses yet: label", "Coming soon"),
   F("academic.subjects_empty", "No subjects message", "No subjects have been added here yet."), F("academic.courses_empty", "No courses in a subject message", "No courses in this subject yet. Check back soon.")]),
 ("faith", "Faith & Spiritual Growth text", "Headings and messages on the Faith & Spiritual Growth pages and its homepage section. Topics, series and lessons are edited under the Faith menu items.", [
   F("faith.title", "Faith page: title", "Faith & Spiritual Growth"),
   F("faith.intro", "Faith page: introduction", "Grow in your faith alongside your learning. Bible studies, practical Christian living, prayer, biblical wisdom, relationships and spiritual growth, as videos, audio lessons and study materials you can use on any phone.", "textarea"),
   F("faith.teachers_title", "Teachers heading", "Meet our teachers"), F("faith.teacher_about", "Series page: about the teacher", "About your teacher"), F("faith.teacher_courses", "Teacher page: series heading", "Series by this teacher"),
   F("faith.topics_title", "Topics heading", "Choose a topic"), F("faith.latest_title", "Latest lessons heading", "New lessons"), F("faith.series_title", "Featured series heading", "Study series"),
   F("faith.resume_title", "Continue heading (signed-in learners)", "Continue where you left off"),
   F("faith.empty", "No lessons yet message", "Lessons are being prepared. Please check back soon."),
   F("faith.buy_button", "Paid course: buy button", "Enrol in this course"), F("faith.buy_login", "Paid course: button for visitors not signed in", "Log in to enrol"),
   F("faith.buy_note", "Paid course: note beside the price", "Pay once and get every lesson, audio and study guide in this course. Free preview lessons are open to everyone.", "textarea"),
   F("faith.topic_buy_button", "Paid topic: buy button", "Get the whole topic"),
   F("faith.topic_buy_note", "Paid topic: note beside the price", "Pay once and unlock every course lesson in this topic, now and as new ones are added. Free preview lessons are open to everyone.", "textarea"),
   F("faith.locked_title", "Locked lesson: heading", "This lesson is part of a paid course"),
   F("faith.locked_text", "Locked lesson: message ({series} = course name)", "Enrol in {series} to watch, listen and download the study materials. Lessons marked Free preview are open to everyone.", "textarea"),
   F("faith.members_note", "Members-only lesson message", "This lesson is for signed-in members. Log in or create a free account to watch, listen and study.", "textarea"),
   F("faith.home_title", "Homepage section: title", "Faith & Spiritual Growth"), F("faith.home_text", "Homepage section: text", "Bible studies, prayer, biblical wisdom and practical Christian living, as videos, audio lessons and study guides.", "textarea"), F("faith.home_button", "Homepage section: button", "Explore Faith lessons")]),
 ("messages", "Payment page & notifications", "Wording on the student payment page and the notifications students receive. Placeholders: {item} = course/plan name, {reason} = staff reason.", [
   F("pay.bank_title", "Payment page: bank transfer heading", "Pay by bank transfer"), F("pay.confirm_title", "Payment page: confirm heading", "Confirm your payment"),
   F("pay.pending_text", "Payment page: pending message", "We received your proof of payment. Our team will confirm the money in our account and then activate your access. You will be notified. Access is not active until then.", "textarea"),
   F("pay.approved_text", "Payment page: approved message", "Your access is active."),
   F("notif.submitted_title", "Notification: payment submitted (title)", "Payment submitted"), F("notif.submitted_body", "Notification: payment submitted (text)", "We received your proof for {item}. Access is activated after our team confirms the money in our account.", "textarea"),
   F("notif.approved_title", "Notification: payment approved (title)", "Payment approved - access active"), F("notif.approved_body", "Notification: payment approved (text)", "Your payment for {item} was confirmed. Your access is now active.", "textarea"),
   F("notif.rejected_title", "Notification: payment rejected (title)", "Payment not approved"), F("notif.rejected_body", "Notification: payment rejected (text)", "Reason: {reason}", "textarea"),
   F("notif.info_title", "Notification: more information needed (title)", "More information needed for your payment"),
   F("notif.cert_title", "Notification: certificate ready (title)", "Your certificate is ready"), F("notif.cert_body", "Notification: certificate ready (text)", "Congratulations on completing {item}.", "textarea"),
   F("notif.sale_title", "Notification to tutor: new purchase (title)", "New purchase of your course"), F("notif.sale_body", "Notification to tutor: new purchase (text)", "{student} bought {item}. You earned {amount}.", "textarea"),
   F("notif.payout_paid_title", "Notification to tutor: withdrawal paid (title)", "Withdrawal paid"), F("notif.payout_paid_body", "Notification to tutor: withdrawal paid (text)", "{amount} has been paid to your bank account. Open Earnings to see the receipt.", "textarea"),
   F("notif.payout_rejected_title", "Notification to tutor: withdrawal declined (title)", "Withdrawal request declined"), F("notif.payout_rejected_body", "Notification to tutor: withdrawal declined (text)", "Reason: {reason}", "textarea"),
   F("notif.expired_title", "Notification: subscription expired (title)", "Your {item} subscription has expired"), F("notif.expired_body", "Notification: subscription expired (text)", "Renew to regain access to subscription courses. Courses you bought individually are not affected.", "textarea")]),
]
FIELDS = {f["key"]: f for _, _, _, fs in GROUPS for f in fs}

# make defaults visible to the settings layer
for k, f in FIELDS.items(): S.DEFAULTS["c." + k] = f["default"]

def ct(key):
    """Editable text for `key` ({name} is replaced with the academy name)."""
    v = S.get("c." + key, FIELDS[key]["default"] if key in FIELDS else "")
    return (v or "").replace("{name}", S.get("site.name", "")) if v is not None else ""

def ctf(key, **kw):
    """Editable text with {placeholders} filled in (values are plain text; templates escape on output)."""
    v = ct(key)
    for k, val in kw.items(): v = v.replace("{" + k + "}", str(val))
    return v

def cl(key):
    """Editable list: returns a list of lists of stripped fields (split on ' | ')."""
    out = []
    for line in (S.get("c." + key, "") or "").splitlines():
        line = line.strip()
        if line: out.append([p.strip() for p in line.split("|")])
    return out

def safe_url(u):
    return u if u.startswith("/") and not u.startswith("//") or u.startswith("https://") else "#"

def _icon_ok(name):
    from . import icons          # imported late: icons.py itself reads this module
    return icons.valid(name)

def validate(key, value):
    f = FIELDS.get(key[2:]) if key.startswith("c.") else None
    if not f or f["kind"] != "list": return None
    for n, line in enumerate(value.splitlines(), 1):
        if not line.strip(): continue
        parts = [p.strip() for p in line.split("|")]
        if key.startswith("c.nav."):
            if len(parts) != 2 or not parts[0] or not (parts[1].startswith("/") and not parts[1].startswith("//") or parts[1].startswith("https://")):
                return f"{f['label']}, line {n}: use  Label | /page  or  Label | https://link"
        elif not parts[0]: return f"{f['label']}, line {n}: each line needs a title."
        elif key == "c.home.what_cards" and len(parts) >= 5 and parts[4] and not _icon_ok(parts[4]):
            return f"{f['label']}, line {n}: unknown icon '{parts[4]}'. Choose icons under Appearance > Intro card icons, or leave the 5th part empty."
        elif key == "c.home.what_cards" and len(parts) >= 3 and parts[2] and not (parts[2].startswith("/") and not parts[2].startswith("//") or parts[2].startswith("https://")):
            return f"{f['label']}, line {n}: the link must start with / or https://"
    if len(value) > 6000: return f"{f['label']} is too long."
    return None
