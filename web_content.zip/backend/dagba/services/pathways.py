"""Learning paths: related courses in a recommended order, with prerequisites. A path is the unit teachers manage; its prerequisites are enforced
for students only while the path is PUBLISHED (so unpublishing lifts them), on the server, in front of the existing lesson/quiz/assignment/video routes.
A course is 'completed' when every lesson of it is completed (the existing progress records); a prerequisite course with no lessons counts as done.
Enrolment and payment are untouched: a student can still buy a course whose prerequisites are unmet, they just cannot start it until they are met."""
import re
from ..db import get_db, q, q1, ex, val
from ..util import now, slugify
from . import lms, audit

class PathError(Exception): pass

def _staff_all(user):
    from ..security import has_perm
    return bool(user and has_perm("paths.manage", user))

def can_manage(user, path):
    """Admins with paths.manage manage every path; an instructor manages the paths they created."""
    if not user or not path: return False
    return _staff_all(user) or (user["role"] == "instructor" and path["created_by"] == user["id"])

def can_use_course(user, course):
    """Which courses a person may put in a path: any for a path admin, only their own for an instructor."""
    return _staff_all(user) or (user["role"] == "instructor" and course["instructor_id"] == user["id"])

def get(pid): return q1("SELECT * FROM learning_paths WHERE id=?", (pid,))
def by_slug(slug): return q1("SELECT * FROM learning_paths WHERE slug=?", (slug,))

def courses(pid):
    return q("""SELECT c.*, lpc.position FROM learning_path_courses lpc JOIN courses c ON c.id=lpc.course_id WHERE lpc.path_id=? ORDER BY lpc.position, c.id""", (pid,))

def prereq_map(pid):
    """{course_id: [required course ids]} for one path."""
    m = {}
    for r in q("SELECT course_id, requires_course_id FROM path_prerequisites WHERE path_id=?", (pid,)): m.setdefault(r["course_id"], []).append(r["requires_course_id"])
    return m

def _clean(text, n): return re.sub(r"[ \t]+", " ", (text or "").strip())[:n]

def save_path(user, form, pid=None):
    title = _clean(form.get("title"), 150)
    if not title: raise PathError("Give the learning path a title.")
    status = "published" if form.get("status") == "published" else "draft"
    summary = _clean(form.get("summary"), 300) or None; desc = (form.get("description") or "").strip()[:5000] or None
    if pid:
        p = get(pid) or None
        if not p or not can_manage(user, p): raise PathError("Learning path not found.")
        if status == "published" and not val("SELECT COUNT(*) FROM learning_path_courses WHERE path_id=?", (pid,), 0): raise PathError("Add at least one course before publishing the path.")
        ex("UPDATE learning_paths SET title=?, summary=?, description=?, status=?, updated_at=? WHERE id=?", (title, summary, desc, status, now(), pid))
        audit.log("path.updated", "learning_path", pid, f"{title} ({status})", actor=user)
        return pid
    base = slugify(title) or "path"; slug, n = base, 2
    while val("SELECT 1 FROM learning_paths WHERE slug=?", (slug,)): slug = f"{base}-{n}"; n += 1
    pid = ex("INSERT INTO learning_paths(title,slug,summary,description,status,created_by) VALUES (?,?,?,?,'draft',?)", (title, slug, summary, desc, user["id"]))
    audit.log("path.created", "learning_path", pid, title, actor=user); return pid

def delete_path(user, pid):
    p = get(pid)
    if not p or not can_manage(user, p): raise PathError("Learning path not found.")
    ex("DELETE FROM learning_paths WHERE id=?", (pid,)); audit.log("path.deleted", "learning_path", pid, p["title"], actor=user)

def add_course(user, pid, cid):
    p = get(pid); c = q1("SELECT * FROM courses WHERE id=?", (cid,))
    if not p or not can_manage(user, p): raise PathError("Learning path not found.")
    if not c: raise PathError("Choose a course.")
    if not can_use_course(user, c): raise PathError("You can only add your own courses.")
    if val("SELECT 1 FROM learning_path_courses WHERE path_id=? AND course_id=?", (pid, cid)): raise PathError("That course is already in the path.")
    pos = (val("SELECT MAX(position) FROM learning_path_courses WHERE path_id=?", (pid,), 0) or 0) + 1
    ex("INSERT INTO learning_path_courses(path_id,course_id,position) VALUES (?,?,?)", (pid, cid, pos)); ex("UPDATE learning_paths SET updated_at=? WHERE id=?", (now(), pid))
    audit.log("path.course_added", "learning_path", pid, c["title"], actor=user)

def remove_course(user, pid, cid):
    p = get(pid)
    if not p or not can_manage(user, p): raise PathError("Learning path not found.")
    ex("DELETE FROM path_prerequisites WHERE path_id=? AND (course_id=? OR requires_course_id=?)", (pid, cid, cid)); ex("DELETE FROM learning_path_courses WHERE path_id=? AND course_id=?", (pid, cid))
    for i, r in enumerate(q("SELECT course_id FROM learning_path_courses WHERE path_id=? ORDER BY position, course_id", (pid,)), 1): ex("UPDATE learning_path_courses SET position=? WHERE path_id=? AND course_id=?", (i, pid, r["course_id"]))
    if p["status"] == "published" and not val("SELECT COUNT(*) FROM learning_path_courses WHERE path_id=?", (pid,), 0): ex("UPDATE learning_paths SET status='draft' WHERE id=?", (pid,))
    audit.log("path.course_removed", "learning_path", pid, str(cid), actor=user)

def move_course(user, pid, cid, direction):
    p = get(pid)
    if not p or not can_manage(user, p): raise PathError("Learning path not found.")
    ids = [r["course_id"] for r in q("SELECT course_id FROM learning_path_courses WHERE path_id=? ORDER BY position, course_id", (pid,))]
    if cid not in ids: raise PathError("That course is not in the path.")
    i = ids.index(cid); j = i - 1 if direction == "up" else i + 1
    if 0 <= j < len(ids): ids[i], ids[j] = ids[j], ids[i]
    for n, c in enumerate(ids, 1): ex("UPDATE learning_path_courses SET position=? WHERE path_id=? AND course_id=?", (n, pid, c))

def _reaches(pid, start, target, extra=None):
    """True when `target` can be reached from `start` by following 'requires' edges inside the path (cycle test)."""
    graph = prereq_map(pid)
    if extra: graph = {k: list(v) for k, v in graph.items()}; graph[extra[0]] = extra[1]
    seen, stack = set(), [start]
    while stack:
        n = stack.pop()
        if n == target: return True
        if n in seen: continue
        seen.add(n); stack += graph.get(n, [])
    return False

def set_prerequisites(user, pid, cid, requires):
    """Replace the prerequisites of one course in this path. Each must be another course of the same path; no loops."""
    p = get(pid)
    if not p or not can_manage(user, p): raise PathError("Learning path not found.")
    members = {r["course_id"] for r in q("SELECT course_id FROM learning_path_courses WHERE path_id=?", (pid,))}
    if cid not in members: raise PathError("That course is not in the path.")
    req = []
    for r in requires:
        try: r = int(r)
        except (TypeError, ValueError): continue
        if r == cid: raise PathError("A course cannot be its own prerequisite.")
        if r not in members: raise PathError("A prerequisite must be a course in this path.")
        if r not in req: req.append(r)
    for r in req:
        if _reaches(pid, r, cid, extra=(cid, req)): raise PathError("Those prerequisites would make a loop: a course cannot require a course that already requires it.")
    ex("DELETE FROM path_prerequisites WHERE path_id=? AND course_id=?", (pid, cid))
    for r in req: ex("INSERT INTO path_prerequisites(path_id,course_id,requires_course_id) VALUES (?,?,?)", (pid, cid, r))
    audit.log("path.prerequisites_set", "learning_path", pid, f"course {cid} requires {req}", actor=user)

# ------------------------------------------------------------------ what a student sees and what is enforced
def completed(uid, course_id):
    p = lms.course_progress(uid, course_id); return p["percent"] == 100 and p["total"] > 0

def unmet(uid, course_id):
    """Prerequisite courses this student has not completed yet, from every PUBLISHED path that lists the course. [] means no restriction."""
    rows = q("""SELECT DISTINCT r.id, r.title, r.slug, p.title AS path_title, p.slug AS path_slug FROM path_prerequisites pp JOIN learning_paths p ON p.id=pp.path_id AND p.status='published'
                JOIN courses r ON r.id=pp.requires_course_id WHERE pp.course_id=? ORDER BY p.id, r.id""", (course_id,))
    out = []
    for r in rows:
        if lms.course_progress(uid, r["id"])["total"] == 0: continue                  # nothing to complete in it
        if not completed(uid, r["id"]): out.append(r)
    return out

def paths_for_course(course_id):
    return q("""SELECT p.* FROM learning_paths p JOIN learning_path_courses lpc ON lpc.path_id=p.id WHERE lpc.course_id=? AND p.status='published' ORDER BY p.title""", (course_id,))

def requirements(course_id):
    """Published-path prerequisites of a course (for the course page), whoever is looking."""
    return q("""SELECT DISTINCT r.id, r.title, r.slug, p.title AS path_title FROM path_prerequisites pp JOIN learning_paths p ON p.id=pp.path_id AND p.status='published'
                JOIN courses r ON r.id=pp.requires_course_id WHERE pp.course_id=? ORDER BY r.title""", (course_id,))

def progress(uid, path):
    """Ordered steps with state, plus overall progress. States: completed | in_progress | available | locked."""
    steps, tot, done_l = [], 0, 0; pm = prereq_map(path["id"])
    cs = courses(path["id"])
    for c in cs:
        pr = lms.course_progress(uid, c["id"]) if uid else {"total": 0, "done": 0, "percent": 0}
        need = [x for x in unmet(uid, c["id"])] if uid else []
        wanted = [r for r in cs if r["id"] in pm.get(c["id"], [])]
        state = "completed" if pr["total"] and pr["percent"] == 100 else ("locked" if need else ("in_progress" if pr["done"] else "available"))
        steps.append(dict(course=c, progress=pr, state=state, requires=wanted, unmet=need)); tot += pr["total"]; done_l += pr["done"]
    n_done = sum(1 for s in steps if s["state"] == "completed")
    nxt = next((s for s in steps if s["state"] in ("in_progress", "available")), None)
    return dict(steps=steps, courses_total=len(steps), courses_done=n_done, percent=int(done_l * 100 / tot) if tot else 0, next=nxt)

def list_published(): return q("SELECT p.*, (SELECT COUNT(*) FROM learning_path_courses WHERE path_id=p.id) AS n FROM learning_paths p WHERE p.status='published' ORDER BY p.title")

def for_student(uid, course_ids, limit=4):
    """Published paths the student has started (owns a course of), with progress, for the dashboard."""
    if not course_ids: return []
    ph = ",".join("?" * len(course_ids))
    rows = q(f"SELECT DISTINCT p.* FROM learning_paths p JOIN learning_path_courses lpc ON lpc.path_id=p.id WHERE p.status='published' AND lpc.course_id IN ({ph}) ORDER BY p.title", tuple(course_ids))
    return [dict(path=p, prog=progress(uid, p)) for p in rows][:limit]

def managed(user):
    return q("SELECT p.*, (SELECT COUNT(*) FROM learning_path_courses WHERE path_id=p.id) AS n, u.full_name AS owner FROM learning_paths p LEFT JOIN users u ON u.id=p.created_by" +
             ("" if _staff_all(user) else " WHERE p.created_by=?") + " ORDER BY p.updated_at DESC", () if _staff_all(user) else (user["id"],))

def addable_courses(user, pid):
    sql = "SELECT id, title, division FROM courses WHERE id NOT IN (SELECT course_id FROM learning_path_courses WHERE path_id=?)" + ("" if _staff_all(user) else " AND instructor_id=?") + " ORDER BY title"
    return q(sql, (pid,) if _staff_all(user) else (pid, user["id"]))
