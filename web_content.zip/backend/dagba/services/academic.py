"""Course structure:  Academic (Basic, Advanced)  |  Income Skills  |  Professional Development.
Basic, Advanced and Professional Development are sold by SUBJECT (category): one saved price per subject unlocks every course, topic and lesson in it.
Income Skills keeps individual course prices.
Academic splits into two levels, each with its own subjects. Professional Development is an independent main division (courses.division =
'professional') with its own programme areas, exactly like Income Skills. Subscriptions, entitlements and payments work as before."""
from ..db import q, q1, val
from ..util import slugify

PRO = dict(key="professional", name="Professional Development", sub="Professional Examinations and Career Advancement")

class _Levels(dict):
    """The two Academic levels. Looking up 'professional' (a stale value from an old form or import) still gives a label instead of an error,
    but it is not a level: it never appears when iterating and `x in LEVELS` is False."""
    def __missing__(self, key):
        if key == "professional": return PRO
        raise KeyError(key)

LEVELS = _Levels({
    "basic": dict(key="basic", name="Basic", sub="Secondary School Education"),
    "advanced": dict(key="advanced", name="Advanced", sub="University-Level Education"),
})
ALL = {**LEVELS, "professional": PRO}          # every course group, for admin screens and counts
EFFECTIVE = "COALESCE(c.academic_level,'basic')"      # academic courses saved before the restructure count as Basic

def subject_slug(name): return slugify(name)

def _cat_where(level):
    """SQL + args selecting the categories (subjects / programme areas) of a level, or of the Professional Development division."""
    if level == "professional": return "division='professional'", ()
    return "division='academic' AND level=?", (level,)

def normalize(division, level):
    """Older forms still send Professional as an academic level; it is now its own division."""
    if division == "academic" and level == "professional": return "professional", None
    return division, level

def _best_by_subject(level):
    """One category per subject name. If duplicates ever exist (the admin screens refuse them), the one that actually holds published courses wins, so a card and its page always agree."""
    w, a = _cat_where(level); best = {}
    for c in q(f"SELECT * FROM categories WHERE {w} AND active=1 ORDER BY position, name, id", a):
        key = subject_slug(c["name"]); n = val("SELECT COUNT(*) FROM courses WHERE category_id=? AND status='published' AND division=?", (c["id"], c["division"]), 0)
        if key not in best or n > best[key][1]: best[key] = (c, n)
    return best

def subjects(level, only_with_courses=False):
    """Active subjects of a level with their number of published courses (each subject once, in the admin's order)."""
    best = _best_by_subject(level); rows = []
    for key, (c, n) in sorted(best.items(), key=lambda kv: (kv[1][0]["position"], kv[1][0]["name"])):
        if n or not only_with_courses: rows.append(dict(c=c, slug=key, n=n))
    return rows

def find_subject(level, slug):
    r = _best_by_subject(level).get(slug)
    return r[0] if r else None

def uncategorised_count(level):
    if level == "professional": return val("SELECT COUNT(*) FROM courses WHERE division='professional' AND status='published' AND category_id IS NULL", default=0)
    return val(f"SELECT COUNT(*) FROM courses c WHERE c.division='academic' AND c.status='published' AND c.category_id IS NULL AND {EFFECTIVE}=?", (level,), 0)

def level_counts():
    out = {lv: val(f"SELECT COUNT(*) FROM courses c WHERE c.division='academic' AND c.status='published' AND {EFFECTIVE}=?", (lv,), 0) for lv in LEVELS}
    out["professional"] = val("SELECT COUNT(*) FROM courses WHERE division='professional' AND status='published'", default=0)
    return out

def validate(division, level, category_id, publishing):
    """Returns (error_list, clean_level, clean_category_id). Only Academic courses carry a level (Basic or Advanced); Income Skills and
    Professional Development are independent divisions whose categories must belong to that same division."""
    division, level = normalize(division, level)
    if division in ("income", "professional"):
        errs = []
        if category_id:
            c = q1("SELECT * FROM categories WHERE id=?", (category_id,))
            if not c or c["division"] != division:
                errs.append(f"That category does not belong to {'Income Skills' if division == 'income' else 'Professional Development'}. Choose one from the same division.")
                category_id = None
        return errs, None, category_id
    if division != "academic": return ["Choose a division."], None, category_id
    errs = []
    if level not in LEVELS: return ["Choose the academic category: Basic or Advanced."], None, category_id
    if category_id:
        c = q1("SELECT * FROM categories WHERE id=?", (category_id,))
        if not c or c["division"] != "academic" or c["level"] != level:
            errs.append(f"That subject does not belong to the {LEVELS[level]['name']} category. Pick a {LEVELS[level]['name']} subject.")
            category_id = None
    elif publishing:
        errs.append(f"Choose the subject for this {LEVELS[level]['name']} course before publishing.")
    return errs, level, category_id

def label(level): return LEVELS.get(level or "basic", LEVELS["basic"])["name"]


# ---- Basic Academic: categories are what students see and buy (a category = e.g. "English JSS1") ----------------------
def basic_categories(featured_only=False, search=None, limit=None):
    """Active Basic categories with the number of published courses in each (empty categories are not shown to students)."""
    where, args = ["division='academic'", "level='basic'", "active=1"], []
    if featured_only: where.append("featured=1")
    if search: where.append("name LIKE ?"); args.append(f"%{search}%")
    rows = []
    for c in q(f"SELECT * FROM categories WHERE {' AND '.join(where)} ORDER BY position, name", tuple(args)):
        n = val("SELECT COUNT(*) FROM courses WHERE category_id=? AND status='published' AND division='academic'", (c["id"],), 0)
        if n: rows.append(dict(c=c, slug=subject_slug(c["name"]), n=n))
    return rows[:limit] if limit else rows

def category_contents(category_id):
    """Every published course in a subject (Basic, Advanced or Professional Development) with its topics (modules) and lessons, in teaching order."""
    cat = q1("SELECT * FROM categories WHERE id=?", (category_id,))
    if cat is None or cat["division"] not in ("academic", "professional"): return []
    where, args = "category_id=? AND status='published' AND division=?", [category_id, cat["division"]]
    if cat["division"] == "academic": where += " AND COALESCE(academic_level,'basic')=?"; args.append(cat["level"] or "basic")
    out = []
    for c in q(f"SELECT * FROM courses WHERE {where} ORDER BY featured DESC, title", tuple(args)):
        topics, loose = [], []
        mods = {m["id"]: dict(m=m, lessons=[]) for m in q("SELECT * FROM modules WHERE course_id=? ORDER BY position, id", (c["id"],))}
        for l in q("SELECT * FROM lessons WHERE course_id=? ORDER BY position, id", (c["id"],)):
            (mods[l["module_id"]]["lessons"] if l["module_id"] in mods else loose).append(l)
        topics = list(mods.values())
        out.append(dict(c=c, topics=topics, loose=loose, n_lessons=sum(len(t["lessons"]) for t in topics) + len(loose)))
    return out


# ---- Homepage: subject cards (each subject once) for Basic, Advanced and Professional Development; individual courses for Income Skills ----
SUBJECT_LEVELS = ("basic", "advanced", "professional")      # the three divisions that are sold by subject

def subject_url_args(level, slug):
    """(endpoint, kwargs) of a subject's public page."""
    if level == "professional": return "public.professional_subject", dict(subject=slug)
    return "public.academic_subject", dict(level=level, subject=slug)

def home_subjects(level, limit=24):
    """Subjects shown on the homepage: active, marked 'show on homepage', with at least one published course, one card per subject.
    Works for Basic, Advanced and Professional Development; each row carries the saved subject price and cover image (row['c'])."""
    if level not in SUBJECT_LEVELS: return []
    out = []
    for r in subjects(level, only_with_courses=True):
        if r["c"]["featured"]: out.append(r)
    return out[:limit]

def priced_subjects(level):
    """Active subjects of a level that have a saved price (for the public price list)."""
    return [r["c"] for r in subjects(level) if (r["c"]["price_kobo"] or 0) > 0]

def home_income_courses(limit=12):
    """The homepage Income Skills section: published Income Skills courses ONLY (division='income').
    The 'featured' flag only decides the ORDER inside this division; it can never bring a course from another division into the section."""
    return q("""SELECT c.*, cat.name AS category FROM courses c LEFT JOIN categories cat ON cat.id=c.category_id
                WHERE c.division='income' AND c.status='published'
                ORDER BY c.featured DESC, c.created_at DESC, c.id DESC LIMIT ?""", (limit,))


def division_counts():
    """Published courses per group for the admin dashboard: Academic Basic, Academic Advanced, Income Skills, Professional Development."""
    lc = level_counts()
    return [("basic", "Academic: Basic", lc["basic"]), ("advanced", "Academic: Advanced", lc["advanced"]),
            ("income", "Income Skills", val("SELECT COUNT(*) FROM courses WHERE division='income' AND status='published'", default=0)), ("professional", "Professional Development", lc["professional"])]
