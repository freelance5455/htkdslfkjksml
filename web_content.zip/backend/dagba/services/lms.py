import io, secrets
from flask import current_app
from ..db import get_db, q, q1, ex, val
from ..util import now
from . import settings, audit
from .notify import notify

def course_progress(uid, course_id):
    total = val("SELECT COUNT(*) FROM lessons WHERE course_id=?", (course_id,), 0)
    done = val("SELECT COUNT(*) FROM progress p JOIN lessons l ON l.id=p.lesson_id WHERE p.user_id=? AND l.course_id=? AND p.completed_at IS NOT NULL", (uid, course_id), 0)
    return {"total": total, "done": done, "percent": int(done * 100 / total) if total else 0}

def resume_lesson(uid, course_id):
    """Most recently touched incomplete lesson, else first incomplete, else first lesson. Lessons whose scheduled release has not arrived are skipped."""
    t = now()
    r = q1("""SELECT l.* FROM progress p JOIN lessons l ON l.id=p.lesson_id LEFT JOIN modules m ON m.id=l.module_id WHERE p.user_id=? AND l.course_id=? AND p.completed_at IS NULL
              AND (l.release_at IS NULL OR l.release_at<=?) AND (m.release_at IS NULL OR m.release_at<=?) ORDER BY p.updated_at DESC LIMIT 1""", (uid, course_id, t, t))
    if r: return r
    r = q1("""SELECT l.* FROM lessons l LEFT JOIN modules m ON m.id=l.module_id WHERE l.course_id=?
              AND (l.release_at IS NULL OR l.release_at<=?) AND (m.release_at IS NULL OR m.release_at<=?)
              AND l.id NOT IN (SELECT lesson_id FROM progress WHERE user_id=? AND completed_at IS NOT NULL)
              ORDER BY COALESCE(m.position,0), l.position, l.id LIMIT 1""", (course_id, t, t, uid))
    return r or q1("""SELECT l.* FROM lessons l LEFT JOIN modules m ON m.id=l.module_id WHERE l.course_id=? AND (l.release_at IS NULL OR l.release_at<=?) AND (m.release_at IS NULL OR m.release_at<=?)
                      ORDER BY COALESCE(m.position,0), l.position, l.id LIMIT 1""", (course_id, t, t))

def ordered_lessons(course_id):
    return q("""SELECT l.*, m.title AS module_title, m.release_at AS module_release_at FROM lessons l LEFT JOIN modules m ON m.id=l.module_id
                WHERE l.course_id=? ORDER BY COALESCE(m.position,0), m.id, l.position, l.id""", (course_id,))

def quizzes_status(uid, course_id):
    rows = q("""SELECT z.*, (SELECT MAX(score_percent) FROM quiz_attempts a WHERE a.quiz_id=z.id AND a.user_id=?) AS best,
                (SELECT MAX(passed) FROM quiz_attempts a WHERE a.quiz_id=z.id AND a.user_id=?) AS passed
                FROM quizzes z WHERE z.course_id=? ORDER BY z.position, z.id""", (uid, uid, course_id))
    return rows

def eligibility(uid, course):
    reasons = []
    if not course["certificate_enabled"]: return False, ["Certificates are not offered for this course."]
    p = course_progress(uid, course["id"])
    if p["total"] == 0: reasons.append("This course has no lessons yet.")
    elif p["done"] < p["total"]: reasons.append(f"Complete all lessons ({p['done']}/{p['total']} done).")
    if settings.flag("cert.min_quiz_pass"):
        for z in quizzes_status(uid, course["id"]):
            if not z["passed"]: reasons.append(f"Pass the quiz '{z['title']}'.")
    return (not reasons), reasons

def issue_certificate(user, course):
    ok, reasons = eligibility(user["id"], course)
    if not ok: return None, reasons
    existing = q1("SELECT * FROM certificates WHERE user_id=? AND course_id=?", (user["id"], course["id"]))
    if existing: return existing, []
    cid = f"DDA-{now()[:4]}-{secrets.token_hex(4).upper()}"
    ex("INSERT INTO certificates(cert_id,user_id,course_id,student_name,course_title) VALUES (?,?,?,?,?)", (cid, user["id"], course["id"], user["full_name"], course["title"]))
    audit.log("certificate.issued", "certificate", cid, course["title"], actor=user)
    from .content import ctf
    notify(user["id"], ctf("notif.cert_title"), ctf("notif.cert_body", item=course["title"]), "/student/certificates", "certificate")
    return q1("SELECT * FROM certificates WHERE cert_id=?", (cid,)), []

def certificate_pdf(cert):
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.pdfgen import canvas
    from reportlab.lib.colors import HexColor
    from reportlab.graphics.barcode.qr import QrCodeWidget
    from reportlab.graphics.shapes import Drawing
    from reportlab.graphics import renderPDF
    from reportlab.lib.utils import ImageReader
    import os
    W, H = landscape(A4); buf = io.BytesIO(); c = canvas.Canvas(buf, pagesize=(W, H))
    purple = HexColor(settings.get("brand.primary", "#7236E6")); dark = HexColor(settings.get("brand.dark", "#1b1230"))
    c.setFillColor(HexColor("#ffffff")); c.rect(0, 0, W, H, fill=1, stroke=0)
    c.setStrokeColor(purple); c.setLineWidth(8); c.rect(18, 18, W - 36, H - 36)
    c.setLineWidth(1.5); c.setStrokeColor(dark); c.rect(32, 32, W - 64, H - 64)
    logo = os.path.join(current_app.static_folder, "img", "logo.png"); custom = settings.get("brand.logo", "")
    if custom and os.path.exists(os.path.join(current_app.config["PUBLIC_DIR"], custom)): logo = os.path.join(current_app.config["PUBLIC_DIR"], custom)
    if os.path.exists(logo): c.drawImage(ImageReader(logo), W / 2 - 30, H - 120, 60, 60, mask="auto")
    c.setFillColor(dark); c.setFont("Helvetica-Bold", 14); c.drawCentredString(W / 2, H - 140, settings.get("site.name").upper())
    c.setFillColor(purple); c.setFont("Helvetica-Bold", 34); c.drawCentredString(W / 2, H - 195, settings.get("cert.title_text"))
    c.setFillColor(dark); c.setFont("Helvetica", 14); c.drawCentredString(W / 2, H - 235, settings.get("cert.line1"))
    name = cert["student_name"]; fs = 36
    while fs > 18 and c.stringWidth(name, "Helvetica-Bold", fs) > W - 160: fs -= 2
    c.setFont("Helvetica-Bold", fs); c.drawCentredString(W / 2, H - 285, name)
    c.setStrokeColor(purple); c.setLineWidth(1); c.line(W / 2 - 180, H - 295, W / 2 + 180, H - 295)
    c.setFont("Helvetica", 14); c.drawCentredString(W / 2, H - 325, settings.get("cert.line2"))
    t = cert["course_title"]; fs = 24
    while fs > 12 and c.stringWidth(t, "Helvetica-Bold", fs) > W - 160: fs -= 2
    c.setFont("Helvetica-Bold", fs); c.drawCentredString(W / 2, H - 360, t)
    c.setFont("Helvetica", 12); c.drawCentredString(W / 2, H - 395, f"{settings.get('cert.completed')} {cert['issued_at'][:10]}")
    c.setFont("Helvetica-Oblique", 11); c.drawCentredString(W / 2, 110, settings.get("site.tagline"))
    c.setFont("Helvetica", 10); c.drawString(60, 70, f"Certificate ID: {cert['cert_id']}")
    c.drawString(60, 56, "Verify: " + current_app.config["SITE_URL"] + "/verify/" + cert["cert_id"])
    c.drawString(W / 2 - 80, 56, settings.get("cert.signatory"))
    qr = QrCodeWidget(current_app.config["SITE_URL"] + "/verify/" + cert["cert_id"]); b = qr.getBounds()
    d = Drawing(70, 70, transform=[70 / (b[2] - b[0]), 0, 0, 70 / (b[3] - b[1]), 0, 0]); d.add(qr)
    renderPDF.draw(d, c, W - 130, 50)
    c.showPage(); c.save(); return buf.getvalue()
