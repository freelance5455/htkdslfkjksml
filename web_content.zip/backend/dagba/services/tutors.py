"""Tutor programme: applications, review, activation, tutor profiles, referral attribution, commission rates and reports.

ROLES. A tutor is an account with role 'instructor' (the existing role); the word "Tutor" is what people see. Nobody re-registers: an
approved applicant's existing student account is upgraded in place.

APPLICATION WORKFLOW (status): draft -> pending -> approved | rejected | revision -> (edit) -> pending ...
  kind 'tutor'  = a student applying to become a tutor with a first course.
  kind 'course' = an existing tutor submitting a further course. Every new course is reviewed, including courses from existing tutors.
The course materials (modules, lessons, videos, resources) are authored in the normal Course Builder on a draft course that belongs to the
application. Nothing is published until an administrator approves; approval is one database transaction (role, profile, price, publication).

REFERRALS. Every tutor has a code. A visit to any public page with ?ref=<code> (for example /course/<slug>?ref=<code>) stores a signed cookie
for `tutor.attribution_days` (default 30) and, for signed-in visitors, a row in tutor_referrals, so the window survives sessions and devices.
The newest link wins. When a student orders one of THAT tutor's courses inside the window, the order is stamped with the tutor
(transactions.tutor_ref_id). On approval the sale is a 'tutor-generated' (affiliate) sale at the referral rate; every other sale is an
'academy-generated' (platform) sale at the normal rate. A tutor never earns referral commission on their own purchase.

RATES. Course override > tutor override > settings default. Referral default = `payout.tutor_referral_percent` (97), never above
`payout.max_percent` (97). Platform default = the existing per-division tutor share. Each ledger row snapshots the rate, its source and why."""
import re, secrets
import datetime as dt
from flask import current_app, request, g, has_request_context
from itsdangerous import URLSafeSerializer, BadSignature
from ..db import get_db, q, q1, ex, val
from ..util import now, now_dt, add_days, naira, parse_naira, slugify, unique_slug
from . import settings, audit, avatars, uploads
from .notify import notify, notify_staff

COOKIE = "dda_tref"
STATUSES = ("draft", "pending", "revision", "approved", "rejected")
LABEL = {"draft": "Draft", "pending": "Pending review", "revision": "Revision requested", "approved": "Approved", "rejected": "Rejected"}
OPEN = ("draft", "pending", "revision")
EDITABLE = ("draft", "revision")
BOTS = re.compile(r"bot|crawl|spider|slurp|facebookexternalhit|whatsapp|telegram|preview|curl|wget|python-requests|headless", re.I)
LIMITS = dict(full_name=120, phone=30, location=120, bio=2000, experience=3000, qualifications=1000, website=200, title=150, summary=300, description=5000, curriculum=6000, outcomes=2000)

class TutorError(Exception): pass

# ------------------------------------------------------------------ settings
def _pct(key, default):
    try: return max(0.0, min(100.0, float(settings.get(key, str(default)))))
    except (TypeError, ValueError): return float(default)
def max_percent(): return _pct("payout.max_percent", 97)
def referral_percent(): return min(_pct("payout.tutor_referral_percent", 97), max_percent())
def attribution_days():
    try: return max(1, min(365, int(float(settings.get("tutor.attribution_days", "30")))))
    except (TypeError, ValueError): return 30
def hold_days():
    try: return max(0, min(90, int(float(settings.get("payout.hold_days", "0")))))
    except (TypeError, ValueError): return 0
def applications_open(): return settings.flag("tutor.applications_open")
def referrals_on(): return settings.flag("tutor.referrals_on")

def parse_pct(text, allow_blank=True, cap=True):
    t = (text or "").strip().replace("%", "")
    if not t:
        if allow_blank: return None
        raise TutorError("Enter a percentage.")
    try: p = float(t)
    except ValueError: raise TutorError("The percentage must be a number.")
    if not 0 <= p <= 100: raise TutorError("The percentage must be between 0 and 100.")
    if cap and p > max_percent(): raise TutorError(f"The highest tutor share allowed is {max_percent():g}% (Payout settings > Highest tutor share).")
    return p

# ------------------------------------------------------------------ profiles
def profile(uid): return q1("SELECT * FROM tutor_profiles WHERE user_id=?", (uid,)) if uid else None
def by_code(code): return q1("SELECT * FROM tutor_profiles WHERE code=?", ((code or "").strip(),)) if code else None
def is_suspended(uid):
    p = profile(uid); return bool(p and p["status"] == "suspended")

def new_code(name):
    base = (slugify((name or "").split(" ")[0])[:10].strip("-") or "tutor")
    for _ in range(50):
        c = f"{base}-{secrets.token_hex(2)}"
        if not val("SELECT 1 FROM tutor_profiles WHERE code=?", (c,)) and not val("SELECT 1 FROM affiliates WHERE slug=?", (c,)): return c
    return f"{base}-{secrets.token_hex(5)}"

def ensure_profile(uid, app=None):
    """The tutor profile for `uid`, created if missing (existing instructors get one the first time they need it)."""
    p = profile(uid)
    if p: return p
    u = q1("SELECT * FROM users WHERE id=?", (uid,))
    if not u: return None
    ex("INSERT OR IGNORE INTO tutor_profiles(user_id, code, location, experience, qualifications, website, application_id) VALUES (?,?,?,?,?,?,?)",
       (uid, new_code(u["full_name"]), (app or {}).get("location") if app else None, (app or {}).get("experience") if app else None,
        (app or {}).get("qualifications") if app else None, (app or {}).get("website") if app else None, app["id"] if app else None))
    return profile(uid)

def link_for(code, slug=None):
    base = current_app.config["SITE_URL"].rstrip("/")
    return f"{base}/course/{slug}?ref={code}" if slug else f"{base}/?ref={code}"

# ------------------------------------------------------------------ applications
def get(aid): return q1("SELECT * FROM tutor_applications WHERE id=?", (aid,))
def mine(uid, aid):
    a = get(aid); return a if a and a["user_id"] == uid else None

def open_application(uid):
    return q1("SELECT * FROM tutor_applications WHERE user_id=? AND kind='tutor' AND status IN ('draft','pending','revision') ORDER BY id DESC LIMIT 1", (uid,))

def latest_application(uid, kind="tutor"):
    return q1("SELECT * FROM tutor_applications WHERE user_id=? AND kind=? ORDER BY id DESC LIMIT 1", (uid, kind))

def can_apply(user):
    """(ok, message). Only student accounts apply; staff accounts already have access, and an existing tutor submits courses instead."""
    if not user: return False, "Log in or create an account to apply."
    if user["role"] == "instructor": return False, "You are already a tutor. Submit a new course from your dashboard."
    if user["role"] != "student": return False, "Your account already has staff access. Ask the academy owner if you would like to teach as well."
    if not applications_open() and not open_application(user["id"]): return False, "Tutor applications are closed at the moment. Please check back soon."
    return True, ""

def is_applicant(user):
    """A student who has an application they may still edit (this is what lets them use the Course Builder on their own application course)."""
    return bool(user and user["role"] == "student" and q1("SELECT 1 FROM tutor_applications WHERE user_id=? AND kind='tutor' AND status IN ('draft','revision') AND course_id IS NOT NULL", (user["id"],)))

def applicant_course_ok(user, course_id):
    """May this person author this course in the builder as an applicant? Own application course, while it is still editable."""
    return bool(user and user["role"] == "student" and course_id and q1(
        "SELECT 1 FROM tutor_applications WHERE user_id=? AND course_id=? AND kind='tutor' AND status IN ('draft','revision')", (user["id"], course_id)))

def event(aid, actor, name, note=None):
    ex("INSERT INTO tutor_application_events(application_id, actor_id, event, note) VALUES (?,?,?,?)", (aid, actor["id"] if actor else None, name, (note or "")[:2000] or None))

def events(aid):
    return q("SELECT e.*, u.full_name AS actor FROM tutor_application_events e LEFT JOIN users u ON u.id=e.actor_id WHERE e.application_id=? ORDER BY e.id", (aid,))

def start(user):
    ok, msg = can_apply(user)
    if not ok: raise TutorError(msg)
    a = open_application(user["id"])
    if a: return a
    aid = ex("INSERT INTO tutor_applications(user_id, kind, status, full_name, phone, bio) VALUES (?,?,?,?,?,?)", (user["id"], "tutor", "draft", user["full_name"], user["phone"], user["bio"]))
    event(aid, user, "created"); audit.log("tutor.application_started", "tutor_application", aid, "", actor=user)
    return get(aid)

def _s(f, k, n): return (f.get(k) or "").strip()[:n]

def _category(cid):
    return q1("SELECT * FROM categories WHERE id=? AND active=1", (cid,)) if cid else None

def categories():
    return q("SELECT id, name, division, level FROM categories WHERE active=1 ORDER BY division, level, position, name")

def save_application(user, app, form, files=None, submit=False):
    """Save the form (draft or submit). Returns a list of problems; the application is saved only if there are none for a draft, or
    submitted only if there are none at all. Drafts may be incomplete."""
    if app["user_id"] != user["id"] or app["status"] not in EDITABLE: raise TutorError("This application can no longer be edited.")
    f = form; errs = []; v = {k: _s(f, k, n) for k, n in LIMITS.items()}
    price_text = (f.get("expected_price") or "").strip()
    try: price = parse_naira(price_text)
    except ValueError as e: errs.append("Expected price: " + str(e)); price = app["expected_price_kobo"]
    if len(price_text) > 15: errs.append("Expected price is too long."); price = app["expected_price_kobo"]
    cat = _category(int(f["category_id"])) if (f.get("category_id") or "").isdigit() else None
    if (f.get("category_id") or "") and not cat: errs.append("Choose one of the listed teaching categories.")
    if v["website"] and not re.fullmatch(r"https://[^\s<>\"']+", v["website"]): errs.append("Website must start with https://")
    for k, n in LIMITS.items():
        if len((f.get(k) or "").strip()) > n: errs.append(f"{k.replace('_', ' ').capitalize()} is too long (maximum {n} characters).")
    cover = app["cover_image"]; fs = (files or {}).get("cover")
    if fs and fs.filename:
        try: cover = uploads.save_public_image(fs)
        except uploads.UploadError as e: errs.append("Cover image: " + str(e))
    pic = (files or {}).get("avatar")
    if pic and pic.filename:
        try: avatars.save(user["id"], pic, actor=user)
        except uploads.UploadError as e: errs.append("Profile picture: " + str(e))
    if f.get("remove_avatar"): avatars.remove(user["id"], actor=user)
    if submit:
        req = [("full_name", "your full name"), ("phone", "a phone number"), ("bio", "a short biography"), ("experience", "your teaching experience"), ("title", "the course title"),
               ("summary", "a one-line course summary"), ("description", "the course description"), ("curriculum", "the curriculum outline"), ("outcomes", "the learning outcomes")]
        errs += [f"Please add {lbl}." for k, lbl in req if not v[k]]
        if not cat: errs.append("Choose a teaching category.")
        if len(v["bio"]) < 40 and v["bio"]: errs.append("Your biography is too short. Tell students a little about yourself (at least 40 characters).")
        if not price_text: errs.append("Enter the price you expect for the course (use 0 for a free course).")
        if not cover: errs.append("Add a course cover image.")
        cid = app["course_id"]
        if not cid or not val("SELECT COUNT(*) FROM lessons WHERE course_id=?", (cid,), 0): errs.append("Add at least one lesson to your course (video, text or materials) in the Course Builder before submitting.")
    mver = mdone = None
    if submit and app["kind"] == "tutor":                                   # becoming a tutor needs the signed MOU; further courses from existing tutors never do
        from . import mou as _M
        merrs, mver, mdone = _M.check_submission(user, f); errs += merrs
    if errs:
        _persist(app["id"], v, cat, price, cover, user, soft=True)      # keep what they typed so nothing is lost
        return errs
    if not submit:
        _persist(app["id"], v, cat, price, cover, user)
        a = get(app["id"]); _sync_course(a, user)
        return []
    # Submitting: the application, its course sync and the signed agreement are ONE transaction (all committed, or none).
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        _persist(app["id"], v, cat, price, cover, user)
        a = get(app["id"]); _sync_course(a, user)
        if mver is not None:
            from . import mou as _M
            acc = _M.accept(user, get(app["id"]), mver, f)
            event(app["id"], user, "mou_accepted" if mdone is None else "mou_on_file", f"Version {acc['version_label']} - reference {acc['reference']}")
        _submit(a, user)
        db.execute("COMMIT")
    except Exception:
        if db.in_transaction: db.execute("ROLLBACK")
        raise
    return []

def _persist(aid, v, cat, price, cover, user, soft=False):
    ex("""UPDATE tutor_applications SET full_name=?, phone=?, location=?, bio=?, experience=?, qualifications=?, website=?, category_id=?, title=?, summary=?, description=?, curriculum=?,
          outcomes=?, cover_image=?, expected_price_kobo=?, updated_at=? WHERE id=?""",
       (v["full_name"], v["phone"], v["location"], v["bio"], v["experience"], v["qualifications"], v["website"], cat["id"] if cat else None, v["title"], v["summary"], v["description"],
        v["curriculum"], v["outcomes"], cover, price, now(), aid))
    if soft: return
    event(aid, user, "saved")

def _sync_course(app, user):
    """Create/update the draft course that holds this application's lessons. Price here is only the EXPECTED price until approval."""
    cat = _category(app["category_id"])
    if not app["title"] or not cat: return app["course_id"]
    division = cat["division"]; level = (cat["level"] or "basic") if division == "academic" else None
    thumb = app["cover_image"] if not (division == "academic" and level == "basic") else None
    if app["course_id"] and val("SELECT 1 FROM courses WHERE id=?", (app["course_id"],)):
        ex("UPDATE courses SET title=?, summary=?, description=?, outcomes=?, thumbnail=COALESCE(?, thumbnail), division=?, academic_level=?, category_id=?, price_kobo=CASE WHEN status='published' THEN price_kobo ELSE ? END, updated_at=? WHERE id=?",
           (app["title"], app["summary"], app["description"], app["outcomes"], thumb, division, level, cat["id"], app["expected_price_kobo"], now(), app["course_id"]))
        return app["course_id"]
    cid = ex("""INSERT INTO courses(division, academic_level, category_id, title, slug, summary, description, outcomes, thumbnail, price_kobo, status, instructor_id, subscription_eligible, certificate_enabled)
                VALUES (?,?,?,?,?,?,?,?,?,?,'draft',?,?,1)""",
             (division, level, cat["id"], app["title"], unique_slug("courses", app["title"]), app["summary"], app["description"], app["outcomes"], thumb, app["expected_price_kobo"], app["user_id"], 0 if division == "professional" else 1))
    ex("UPDATE tutor_applications SET course_id=? WHERE id=?", (cid, app["id"]))
    return cid

def pull_from_course(app_id):
    """After the builder saved the course, mirror its headline fields back onto the application so the two never disagree."""
    a = get(app_id)
    if not a or not a["course_id"]: return
    c = q1("SELECT * FROM courses WHERE id=?", (a["course_id"],))
    if c: ex("UPDATE tutor_applications SET title=?, summary=?, description=?, cover_image=COALESCE(?, cover_image), category_id=COALESCE(?, category_id), updated_at=? WHERE id=?",
             (c["title"], c["summary"], c["description"], c["thumbnail"], c["category_id"], now(), app_id))

def _submit(app, user):
    ex("UPDATE tutor_applications SET status='pending', submitted_at=?, updated_at=? WHERE id=? AND status IN ('draft','revision')", (now(), now(), app["id"]))
    ex("UPDATE courses SET status='review', updated_at=? WHERE id=? AND status!='published'", (now(), app["course_id"]))
    event(app["id"], user, "resubmitted" if app["status"] == "revision" else "submitted")
    audit.log("tutor.application_submitted", "tutor_application", app["id"], app["title"] or "", actor=user)
    notify_staff("tutors.manage", "New tutor application" if app["kind"] == "tutor" else "Course ready for review", f"{user['full_name']}: {app['title'] or 'Untitled course'}", f"/staff/tutors/applications/{app['id']}", "content")

def withdraw(user, app):
    """Take a pending application back to draft so it can be edited (the reviewer is not left with a moving target otherwise)."""
    cur = get_db().execute("UPDATE tutor_applications SET status='draft', updated_at=? WHERE id=? AND user_id=? AND status='pending'", (now(), app["id"], user["id"]))
    if cur.rowcount != 1: raise TutorError("This application cannot be withdrawn.")
    ex("UPDATE courses SET status='draft' WHERE id=? AND status='review'", (app["course_id"],))
    event(app["id"], user, "withdrawn")

# --- course submissions by existing tutors (the builder reports them here) ---
def course_submitted(course_id, user, notify_staff_too=True):
    """An existing tutor sent a course for review (status 'review'). Make sure it is in the review queue exactly once."""
    c = q1("SELECT * FROM courses WHERE id=?", (course_id,))
    if not c or c["status"] != "review" or not c["instructor_id"]: return None
    a = q1("SELECT * FROM tutor_applications WHERE course_id=? ORDER BY id DESC LIMIT 1", (course_id,))
    if a and a["status"] in ("pending",): return a["id"]
    if a and a["status"] in ("draft", "revision") and not (a["kind"] == "tutor" and not val("SELECT 1 FROM mou_acceptances WHERE user_id=?", (a["user_id"],))):
        ex("UPDATE tutor_applications SET status='pending', submitted_at=?, title=?, summary=?, description=?, updated_at=? WHERE id=?", (now(), c["title"], c["summary"], c["description"], now(), a["id"]))
        event(a["id"], user, "resubmitted")
        aid = a["id"]
    else:                                                                            # none yet, or a finished one: a fresh review round
        aid = ex("""INSERT INTO tutor_applications(user_id, kind, status, full_name, title, summary, description, outcomes, cover_image, category_id, expected_price_kobo, course_id, submitted_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""", (c["instructor_id"], "course", "pending", user["full_name"] if user else None, c["title"], c["summary"], c["description"], c["outcomes"], c["thumbnail"], c["category_id"], c["price_kobo"], course_id, now()))
        event(aid, user, "submitted")
    if notify_staff_too: notify_staff("tutors.manage", "Course ready for review", f"{user['full_name'] if user else 'A tutor'}: {c['title']}", f"/staff/tutors/applications/{aid}", "content")
    return aid

def publish_blocked(course_id):
    """A message when this course may not be published yet because it has not been submitted and approved; None when publishing is fine.
    A course that is waiting for review CAN be published by an administrator: that counts as approving it (see finalize_publish)."""
    a = q1("SELECT status FROM tutor_applications WHERE course_id=? ORDER BY id DESC LIMIT 1", (course_id,))
    if a and a["status"] not in ("approved", "pending"): return f"This course belongs to a tutor application that is {LABEL[a['status']].lower()}, so it has not been submitted for review. Only approved courses can be published."
    return None

def finalize_publish(actor, course_id):
    """An administrator just published a course that was waiting in the review queue: record it as an approval (history, tutor role,
    profile, notification) at the price now on the course. Quietly does nothing when there is nothing pending."""
    a = q1("SELECT id FROM tutor_applications WHERE course_id=? AND status='pending' ORDER BY id DESC LIMIT 1", (course_id,))
    if not a: return False
    c = q1("SELECT price_kobo FROM courses WHERE id=?", (course_id,))
    try: approve(actor, a["id"], str(c["price_kobo"] / 100)); return True
    except TutorError as e:
        current_app.logger.warning("approval on publish skipped: %s", e); return False

# ------------------------------------------------------------------ review
def _check_reviewer(actor, app):
    from ..security import has_perm
    if not has_perm("tutors.manage", actor): raise TutorError("You do not have permission to review tutor applications.")
    if app["user_id"] == actor["id"]: raise TutorError("You cannot review your own application.")

def approve(actor, aid, price_text="", aff_text="", plat_text="", note=""):
    """Approve: upgrade the account, create the profile, set the final price, publish the course. One transaction; safe to click twice."""
    app = get(aid)
    if not app: raise TutorError("Application not found.")
    _check_reviewer(actor, app)
    if app["status"] != "pending": raise TutorError("Only applications that are waiting for review can be approved.")
    try: price = parse_naira(price_text) if (price_text or "").strip() else app["expected_price_kobo"]
    except ValueError as e: raise TutorError("Approved price: " + str(e))
    aff = plat = None
    overrides = bool((aff_text or "").strip() or (plat_text or "").strip())
    if overrides:
        from ..security import has_perm
        if not has_perm("payouts.manage", actor): raise TutorError("Only someone who can manage payouts can set commission overrides.")
        aff, plat = parse_pct(aff_text), parse_pct(plat_text)
    user = q1("SELECT * FROM users WHERE id=?", (app["user_id"],))
    if not user or not user["is_active"]: raise TutorError("The applicant's account is not active.")
    if user["role"] not in ("student", "instructor"): raise TutorError("This person has a staff account. Change their role first if they should teach.")
    if is_suspended(user["id"]): raise TutorError("This tutor is suspended. Lift the suspension before approving more courses.")
    cid = app["course_id"]
    if not cid or not val("SELECT 1 FROM courses WHERE id=?", (cid,)): raise TutorError("This application has no course yet.")
    if not val("SELECT COUNT(*) FROM lessons WHERE course_id=?", (cid,), 0): raise TutorError("The course has no lessons yet. Ask the applicant to add some, or request a revision.")
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        cur = db.execute("UPDATE tutor_applications SET status='approved', approved_price_kobo=?, reviewed_by=?, reviewed_at=?, approved_at=?, feedback=?, updated_at=? WHERE id=? AND status='pending'",
                         (price, actor["id"], now(), now(), (note or "").strip()[:2000] or None, now(), aid))
        if cur.rowcount != 1: raise TutorError("This application was already processed.")
        upgraded = user["role"] == "student"
        if upgraded:
            db.execute("UPDATE users SET role='instructor' WHERE id=?", (user["id"],))
            if app["bio"]: db.execute("UPDATE users SET bio=? WHERE id=?", (app["bio"], user["id"]))
            if app["phone"] and not user["phone"]: db.execute("UPDATE users SET phone=? WHERE id=?", (app["phone"], user["id"]))
        if not db.execute("SELECT 1 FROM tutor_profiles WHERE user_id=?", (user["id"],)).fetchone():
            db.execute("INSERT INTO tutor_profiles(user_id, code, location, experience, qualifications, website, application_id) VALUES (?,?,?,?,?,?,?)",
                       (user["id"], new_code(user["full_name"]), app["location"], app["experience"], app["qualifications"], app["website"], aid))
        sets, args = ["status='published'", "price_kobo=?", "instructor_id=?", "updated_at=?"], [price, user["id"], now()]
        if overrides: sets += ["tutor_affiliate_percent=?", "tutor_platform_percent=?"]; args += [aff, plat]
        db.execute(f"UPDATE courses SET {', '.join(sets)} WHERE id=?", tuple(args) + (cid,))
        db.execute("INSERT INTO tutor_application_events(application_id, actor_id, event, note) VALUES (?,?,?,?)", (aid, actor["id"], "approved", f"Price {naira(price)}" + (f" (asked {naira(app['expected_price_kobo'])})" if price != app["expected_price_kobo"] else "")))
        db.execute("INSERT INTO audit_logs(actor_id,actor_label,action,entity,entity_id,detail) VALUES (?,?,?,?,?,?)", (actor["id"], f"{actor['full_name']} <{actor['email']}>", "tutor.approved", "tutor_application", str(aid), f"user {user['id']} course {cid} price {naira(price)} upgraded={upgraded}"))
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK"); raise
    c = q1("SELECT slug, title FROM courses WHERE id=?", (cid,))
    notify(user["id"], "Your course was approved" if app["kind"] == "course" else "Welcome, tutor! Your application was approved",
           f"'{c['title']}' is now live at {naira(price)}." + (" Your tutor dashboard is ready." if app["kind"] == "tutor" else ""), "/staff/", "info", email=True)
    return app["user_id"]

def request_revision(actor, aid, feedback):
    app = get(aid)
    if not app: raise TutorError("Application not found.")
    _check_reviewer(actor, app)
    if not (feedback or "").strip(): raise TutorError("Tell the applicant what to change.")
    cur = get_db().execute("UPDATE tutor_applications SET status='revision', feedback=?, reviewed_by=?, reviewed_at=?, updated_at=? WHERE id=? AND status='pending'", (feedback.strip()[:2000], actor["id"], now(), now(), aid))
    if cur.rowcount != 1: raise TutorError("Only applications that are waiting for review can be sent back.")
    ex("UPDATE courses SET status='draft' WHERE id=? AND status='review'", (app["course_id"],))
    event(aid, actor, "revision_requested", feedback); audit.log("tutor.revision_requested", "tutor_application", aid, feedback[:200], actor=actor)
    notify(app["user_id"], "Changes requested on your application", feedback.strip()[:300], "/tutor/apply" if app["kind"] == "tutor" else "/staff/tutor/submissions", "info", email=True)

def reject(actor, aid, feedback):
    app = get(aid)
    if not app: raise TutorError("Application not found.")
    _check_reviewer(actor, app)
    if not (feedback or "").strip(): raise TutorError("Give the applicant a reason.")
    cur = get_db().execute("UPDATE tutor_applications SET status='rejected', feedback=?, reviewed_by=?, reviewed_at=?, updated_at=? WHERE id=? AND status IN ('pending','revision')", (feedback.strip()[:2000], actor["id"], now(), now(), aid))
    if cur.rowcount != 1: raise TutorError("This application cannot be rejected in its current state.")
    ex("UPDATE courses SET status='draft' WHERE id=? AND status='review'", (app["course_id"],))
    event(aid, actor, "rejected", feedback); audit.log("tutor.rejected", "tutor_application", aid, feedback[:200], actor=actor)
    notify(app["user_id"], "Update on your application", feedback.strip()[:300], "/tutor/apply" if app["kind"] == "tutor" else "/staff/tutor/submissions", "info", email=True)

def adjust_price(actor, aid, price_text):
    """Reviewer sets the price before deciding (also recorded in the history)."""
    app = get(aid)
    if not app: raise TutorError("Application not found.")
    _check_reviewer(actor, app)
    try: price = parse_naira(price_text)
    except ValueError as e: raise TutorError("Price: " + str(e))
    if app["status"] not in ("pending", "revision"): raise TutorError("The price can only be adjusted while the application is open.")
    ex("UPDATE tutor_applications SET approved_price_kobo=?, updated_at=? WHERE id=?", (price, now(), aid)); ex("UPDATE courses SET price_kobo=? WHERE id=? AND status!='published'", (price, app["course_id"]))
    event(aid, actor, "price_adjusted", f"{naira(price)} (asked {naira(app['expected_price_kobo'])})")

# ------------------------------------------------------------------ suspension
def suspend(actor, uid, reason):
    p = ensure_profile(uid)
    if not p: raise TutorError("Tutor not found.")
    if not (reason or "").strip(): raise TutorError("Give a reason (it is shown to the tutor).")
    if p["status"] == "suspended": raise TutorError("This tutor is already suspended.")
    pub = [r["id"] for r in q("SELECT id FROM courses WHERE instructor_id=? AND status='published'", (uid,))]
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        db.execute("UPDATE tutor_profiles SET status='suspended', suspended_at=?, suspended_by=?, suspended_reason=?, suspended_courses=? WHERE user_id=?", (now(), actor["id"], reason.strip()[:500], ",".join(map(str, pub)), uid))
        for cid in pub: db.execute("UPDATE courses SET status='archived', updated_at=? WHERE id=?", (now(), cid))      # hidden from the catalogue; nothing is deleted
        db.execute("INSERT INTO audit_logs(actor_id,actor_label,action,entity,entity_id,detail) VALUES (?,?,?,?,?,?)", (actor["id"], f"{actor['full_name']} <{actor['email']}>", "tutor.suspended", "user", str(uid), f"{reason[:200]} courses hidden: {len(pub)}"))
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK"); raise
    notify(uid, "Your tutor account has been suspended", reason.strip()[:300], "/staff/", "info", email=True)

def unsuspend(actor, uid):
    p = profile(uid)
    if not p or p["status"] != "suspended": raise TutorError("This tutor is not suspended.")
    ids = [int(x) for x in (p["suspended_courses"] or "").split(",") if x.isdigit()]
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        db.execute("UPDATE tutor_profiles SET status='active', suspended_at=NULL, suspended_by=NULL, suspended_reason=NULL, suspended_courses=NULL WHERE user_id=?", (uid,))
        for cid in ids: db.execute("UPDATE courses SET status='published', updated_at=? WHERE id=? AND instructor_id=? AND status='archived'", (now(), cid, uid))
        db.execute("INSERT INTO audit_logs(actor_id,actor_label,action,entity,entity_id,detail) VALUES (?,?,?,?,?,?)", (actor["id"], f"{actor['full_name']} <{actor['email']}>", "tutor.unsuspended", "user", str(uid), f"courses restored: {len(ids)}"))
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK"); raise
    notify(uid, "Your tutor account is active again", "Your suspension has been lifted and your courses are live again.", "/staff/", "info", email=True)

# ------------------------------------------------------------------ commission rates
def rate(course, tutor_id, source):
    """(percent, basis) for a sale of `course` by `tutor_id`. source: 'affiliate' (tutor-generated) or 'platform' (academy-generated)."""
    from . import payouts
    p = profile(tutor_id)
    col, ccol = ("affiliate_percent", "tutor_affiliate_percent") if source == "affiliate" else ("platform_percent", "tutor_platform_percent")
    if course[ccol] is not None: pct, basis = float(course[ccol]), "course"
    elif p and p[col] is not None: pct, basis = float(p[col]), "tutor"
    elif source == "affiliate": pct, basis = referral_percent(), "default"
    else: pct, basis = payouts.percent(course["division"]), "division"
    if source == "affiliate" or basis != "division": pct = min(pct, max_percent())       # the cap protects the school from a mistyped override; legacy platform rates are untouched
    return pct, basis

# ------------------------------------------------------------------ referral tracking
def _signer(): return URLSafeSerializer(current_app.config["SECRET_KEY"], salt="dda-tutor-ref")

def read_cookie():
    raw = request.cookies.get(COOKIE) if has_request_context() else None
    if not raw: return None
    try: d = _signer().loads(raw)
    except BadSignature: return None
    ok = isinstance(d, dict) and isinstance(d.get("t"), int) and isinstance(d.get("v"), str) and isinstance(d.get("ts"), int)
    return d if ok else None

def _within(ts_epoch):
    return ts_epoch + attribution_days() * 86400 >= int(dt.datetime.now(dt.timezone.utc).timestamp())

def landing(code, course_slug=None):
    """Called for ?ref=<code>. Records the click and returns the cookie value to set (newest link wins), or None."""
    if not referrals_on(): return None
    p = by_code(code)
    if not p or p["status"] != "active": return None
    tu = q1("SELECT id, is_active FROM users WHERE id=?", (p["user_id"],))
    if not tu or not tu["is_active"]: return None
    me = g.get("user")
    if me and me["id"] == p["user_id"]: return None                          # a tutor opening their own link: never attributed
    if BOTS.search(request.headers.get("User-Agent", "")): return None      # link previews and crawlers neither count nor set cookies
    cur = read_cookie(); visitor = cur["v"] if cur else secrets.token_urlsafe(9)
    course = q1("SELECT id FROM courses WHERE slug=?", (course_slug,)) if course_slug else None
    try:
        from ..security import rate_limited, client_ip
        counted = not rate_limited(f"tref:{client_ip()}", 60, 600)
    except Exception: counted = True
    if counted and not val("SELECT 1 FROM tutor_clicks WHERE tutor_id=? AND visitor=? AND created_at>?", (p["user_id"], visitor, add_days(now_dt(), -30 / 1440))):
        ex("INSERT INTO tutor_clicks(tutor_id, course_id, visitor) VALUES (?,?,?)", (p["user_id"], course["id"] if course else None, visitor))
    ts = int(dt.datetime.now(dt.timezone.utc).timestamp())
    if me: _store_referral(me["id"], p, course["id"] if course else None)
    return _signer().dumps({"t": p["user_id"], "c": course["id"] if course else 0, "v": visitor, "ts": ts})

def _store_referral(uid, p, course_id):
    if uid == p["user_id"]: return
    ex("""INSERT INTO tutor_referrals(user_id, tutor_id, course_id, code, clicked_at, expires_at) VALUES (?,?,?,?,?,?)
          ON CONFLICT(user_id) DO UPDATE SET tutor_id=excluded.tutor_id, course_id=excluded.course_id, code=excluded.code, clicked_at=excluded.clicked_at, expires_at=excluded.expires_at""",
       (uid, p["user_id"], course_id, p["code"], now(), add_days(now_dt(), attribution_days())))

def claim_cookie(user):
    """After sign-up / login: copy the browser's referral onto the account so it follows the person to any device."""
    try:
        c = read_cookie()
        if not c or not _within(c["ts"]): return
        p = profile(c["t"])
        if not p or p["status"] != "active" or p["user_id"] == user["id"]: return
        row = q1("SELECT clicked_at FROM tutor_referrals WHERE user_id=?", (user["id"],))
        cookie_at = dt.datetime.fromtimestamp(c["ts"], dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        if row and row["clicked_at"] >= cookie_at: return                       # the account already holds a newer link
        ex("""INSERT INTO tutor_referrals(user_id, tutor_id, course_id, code, clicked_at, expires_at) VALUES (?,?,?,?,?,?)
              ON CONFLICT(user_id) DO UPDATE SET tutor_id=excluded.tutor_id, course_id=excluded.course_id, code=excluded.code, clicked_at=excluded.clicked_at, expires_at=excluded.expires_at""",
           (user["id"], p["user_id"], c["c"] or None, p["code"], cookie_at, add_days(dt.datetime.fromtimestamp(c["ts"], dt.timezone.utc).replace(tzinfo=None), attribution_days())))
    except Exception: current_app.logger.exception("tutor referral claim failed")

def is_self(buyer, tutor):
    """True when the buyer is (or is obviously) the tutor: same account, same phone number or same email address."""
    if not buyer or not tutor: return False
    if buyer["id"] == tutor["id"]: return True
    if (buyer["email"] or "").strip().lower() == (tutor["email"] or "").strip().lower(): return True
    a, b = re.sub(r"\D", "", buyer["phone"] or ""), re.sub(r"\D", "", tutor["phone"] or "")
    return bool(len(a) >= 7 and a[-9:] == b[-9:])

def attribute(tx_id, buyer, course):
    """Stamp a freshly created course order with the tutor whose link brought the buyer (if any, inside the window). Never raises."""
    try:
        if not referrals_on() or not course or not course["instructor_id"]: return None
        tid = course["instructor_id"]; p = profile(tid)
        if not p or p["status"] != "active": return None
        tutor = q1("SELECT * FROM users WHERE id=? AND is_active=1", (tid,))
        if not tutor or is_self(buyer, tutor): return None
        best = None                                                           # newest valid link among cookie and account record
        c = read_cookie()
        if c and c["t"] == tid and _within(c["ts"]): best = c["ts"]
        row = q1("SELECT * FROM tutor_referrals WHERE user_id=? AND tutor_id=? AND expires_at>=?", (buyer["id"], tid, now()))
        if row:
            ts = int(dt.datetime.strptime(row["clicked_at"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=dt.timezone.utc).timestamp()); best = max(best or 0, ts)
        if not best: return None
        ex("UPDATE transactions SET tutor_ref_id=?, tutor_ref_code=? WHERE id=? AND tutor_ref_id IS NULL", (tid, p["code"], tx_id))
        return p["code"]
    except Exception:
        current_app.logger.exception("tutor attribution failed"); return None

def referral_valid_at_sale(db, tx, course):
    """Re-checked when the payment is approved: still the course's tutor, still active, still not the buyer."""
    if not tx["tutor_ref_id"] or tx["tutor_ref_id"] != course["instructor_id"]: return False
    if not referrals_on(): return False
    p = db.execute("SELECT status FROM tutor_profiles WHERE user_id=?", (tx["tutor_ref_id"],)).fetchone()
    if not p or p["status"] != "active": return False
    tutor = db.execute("SELECT * FROM users WHERE id=?", (tx["tutor_ref_id"],)).fetchone(); buyer = db.execute("SELECT * FROM users WHERE id=?", (tx["user_id"],)).fetchone()
    return not is_self(buyer, tutor)

# ------------------------------------------------------------------ numbers for dashboards and admin
def learners(course_id):
    return val("SELECT COUNT(*) FROM (SELECT user_id FROM entitlements WHERE course_id=? AND kind='course' AND revoked_at IS NULL UNION SELECT user_id FROM progress WHERE course_id=?)", (course_id, course_id), 0)

def split(uid=None, since=None, until=None):
    """Money by source for one tutor or everybody (net of refunds): {source: dict(sales, gross, earned)} plus a 'total'."""
    where, args = ["1=1"], []
    if uid: where.append("e.instructor_id=?"); args.append(uid)
    if since: where.append("e.created_at>=?"); args.append(since)
    if until: where.append("e.created_at<?"); args.append(until)
    out = {s: dict(sales=0, gross=0, earned=0) for s in ("affiliate", "platform")}
    for r in q(f"""SELECT e.source, SUM(CASE e.kind WHEN 'sale' THEN 1 ELSE 0 END) sales, SUM(CASE e.kind WHEN 'sale' THEN e.gross_kobo ELSE -e.gross_kobo END) gross, SUM(e.amount_kobo) earned
                   FROM instructor_earnings e WHERE {' AND '.join(where)} GROUP BY e.source""", tuple(args)):
        out[r["source"]] = dict(sales=r["sales"] or 0, gross=r["gross"] or 0, earned=r["earned"] or 0)
    out["total"] = {k: out["affiliate"][k] + out["platform"][k] for k in ("sales", "gross", "earned")}
    return out

def per_course(uid):
    rows = q("""SELECT c.id, c.title, c.slug, c.status, c.price_kobo, c.division,
                  COALESCE(SUM(CASE WHEN e.kind='sale' AND e.source='affiliate' THEN 1 ELSE 0 END),0) aff_sales,
                  COALESCE(SUM(CASE WHEN e.kind='sale' AND e.source='platform' THEN 1 ELSE 0 END),0) plat_sales,
                  COALESCE(SUM(CASE WHEN e.source='affiliate' THEN e.amount_kobo ELSE 0 END),0) aff_earned,
                  COALESCE(SUM(CASE WHEN e.source='platform' THEN e.amount_kobo ELSE 0 END),0) plat_earned
                FROM courses c LEFT JOIN instructor_earnings e ON e.course_id=c.id AND e.instructor_id=c.instructor_id WHERE c.instructor_id=? GROUP BY c.id ORDER BY c.created_at DESC""", (uid,))
    out = []
    for r in rows:
        d = dict(r); d["learners"] = learners(r["id"]); out.append(d)
    return out

def link_stats(uid):
    """Per course: the tutor's link, clicks, unique visitors, referred sales, conversion and referral earnings."""
    p = ensure_profile(uid); out = []
    total_clicks = val("SELECT COUNT(*) FROM tutor_clicks WHERE tutor_id=?", (uid,), 0)
    for c in q("SELECT id, title, slug, status FROM courses WHERE instructor_id=? AND status='published' ORDER BY title", (uid,)):
        clicks = val("SELECT COUNT(*) FROM tutor_clicks WHERE tutor_id=? AND course_id=?", (uid, c["id"]), 0)
        visitors = val("SELECT COUNT(DISTINCT visitor) FROM tutor_clicks WHERE tutor_id=? AND course_id=?", (uid, c["id"]), 0)
        sales = val("SELECT COUNT(*) FROM instructor_earnings WHERE instructor_id=? AND course_id=? AND kind='sale' AND source='affiliate'", (uid, c["id"]), 0)
        earned = val("SELECT COALESCE(SUM(amount_kobo),0) FROM instructor_earnings WHERE instructor_id=? AND course_id=? AND source='affiliate'", (uid, c["id"]), 0)
        out.append(dict(c, link=link_for(p["code"], c["slug"]), clicks=clicks, visitors=visitors, sales=sales, earned=earned, conversion=(round(100.0 * sales / visitors, 1) if visitors else 0.0)))
    tot = dict(clicks=total_clicks, visitors=val("SELECT COUNT(DISTINCT visitor) FROM tutor_clicks WHERE tutor_id=?", (uid,), 0),
               sales=sum(r["sales"] for r in out), earned=val("SELECT COALESCE(SUM(amount_kobo),0) FROM instructor_earnings WHERE instructor_id=? AND source='affiliate'", (uid,), 0))
    tot["conversion"] = round(100.0 * tot["sales"] / tot["visitors"], 1) if tot["visitors"] else 0.0
    return p, out, tot
