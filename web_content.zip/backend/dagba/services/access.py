from ..db import q, q1, val
from ..util import now

SCOPES = ("basic", "advanced", "income")      # independent subscription scopes; Professional Development has none

def course_scope(c):
    """'basic' | 'advanced' | 'professional' | 'income' for a course row."""
    if c["division"] == "professional": return "professional"
    if c["division"] != "academic": return "income"
    return c["academic_level"] or "basic"

def scope_of_plan(p):
    if p["division"] != "academic": return "income"
    return p["level"] or "basic"

def _active_sub_expiry(uid, scope):
    """Latest expiry among active subscriptions in this scope ('9999' = lifetime), or None if none active."""
    if scope not in SCOPES: return None
    r = q1("""SELECT COALESCE(expires_at,'9999-12-31 00:00:00') AS e FROM entitlements
              WHERE user_id=? AND kind='subscription' AND COALESCE(level, CASE WHEN division='academic' THEN 'basic' ELSE 'income' END)=?
              AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at > ?) ORDER BY e DESC LIMIT 1""", (uid, scope, now()))
    return None if r is None else r["e"]

def subscription_status(uid):
    return {s: _active_sub_expiry(uid, s) for s in SCOPES}

def course_entitled(uid, course_id):
    return bool(val("""SELECT 1 FROM entitlements WHERE user_id=? AND kind='course' AND course_id=? AND revoked_at IS NULL
                       AND (expires_at IS NULL OR expires_at > ?)""", (uid, course_id, now())))

def subject_entitled(uid, category_id):
    return bool(category_id) and bool(val("""SELECT 1 FROM entitlements WHERE user_id=? AND kind='subject' AND category_id=? AND revoked_at IS NULL
                       AND (expires_at IS NULL OR expires_at > ?)""", (uid, category_id, now())))

SUBJECT_DIVISIONS = ("academic", "professional")      # Income Skills is never sold by subject: its courses keep individual prices

def subject_scope(cat):
    """'basic' | 'advanced' | 'professional' for a category (subject) row, or None when the category cannot be sold as a subject."""
    if cat is None: return None
    if cat["division"] == "professional": return "professional"
    if cat["division"] == "academic" and cat["level"] in ("basic", "advanced"): return cat["level"]
    return None

def subject_of(course):
    """The priced subject (category row) a course is sold through, or None when it is sold on its own.
    A course is sold by subject when it sits in a subject of its OWN division and level (Basic, Advanced or Professional Development)
    and that subject has a saved price. Income Skills courses are never sold by subject."""
    if course["division"] not in SUBJECT_DIVISIONS or not course["category_id"]: return None
    cat = q1("SELECT * FROM categories WHERE id=?", (course["category_id"],))
    if cat is None or (cat["price_kobo"] or 0) <= 0: return None
    if subject_scope(cat) != course_scope(course): return None          # a subject only sells courses of its own division and level
    return cat

def subject_price(course):
    """Saved price of the subject a course sits in (0 when the course is not in a priced subject)."""
    cat = subject_of(course)
    return (cat["price_kobo"] or 0) if cat else 0

def sells_by_subject(course):
    return subject_of(course) is not None

def course_access(uid, course):
    """Return 'free' | 'purchased' | 'subscription' | None. Each source is evaluated independently, so
    one expiring never affects another (separate entitlements). Basic, Advanced and Professional Development courses sit in
    subjects: buying the subject unlocks every course in it. Courses outside a priced subject (and all Income Skills courses)
    are bought individually. Only Basic/Advanced/Income have subscriptions, and they stay independent of each other."""
    if course["status"] != "published": return None
    cat = subject_of(course)
    if cat is None and course["price_kobo"] == 0: return "free"
    if not uid: return None
    if cat is not None and subject_entitled(uid, cat["id"]): return "purchased"
    if course_entitled(uid, course["id"]): return "purchased"      # an individual purchase (also every purchase made before subject pricing) stays valid
    scope = course_scope(course)
    in_basic_category = scope == "basic" and bool(course["category_id"])      # a Basic subscription unlocks every Basic category, whatever the course's own flag
    if scope != "professional" and (course["subscription_eligible"] or in_basic_category) and _active_sub_expiry(uid, scope): return "subscription"
    return None

def purchased_courses(uid):
    """Every course the person owns: individual purchases plus every published course of each subject they bought (any division)."""
    return q("""SELECT c.*, e.expires_at AS access_until, e.starts_at AS bought_at FROM entitlements e JOIN courses c ON c.id=e.course_id
                WHERE e.user_id=? AND e.kind='course' AND e.revoked_at IS NULL AND (e.expires_at IS NULL OR e.expires_at>?)
                UNION
                SELECT c.*, e.expires_at, e.starts_at FROM entitlements e JOIN categories cat ON cat.id=e.category_id
                  JOIN courses c ON c.category_id=cat.id AND c.division=cat.division AND c.status='published'
                   AND (cat.division='professional' OR COALESCE(c.academic_level,'basic')=cat.level)
                WHERE e.user_id=? AND e.kind='subject' AND e.revoked_at IS NULL AND (e.expires_at IS NULL OR e.expires_at>?)
                ORDER BY bought_at DESC""", (uid, now(), uid, now()))

def purchased_subjects(uid):
    return q("""SELECT cat.*, e.expires_at AS access_until FROM entitlements e JOIN categories cat ON cat.id=e.category_id
                WHERE e.user_id=? AND e.kind='subject' AND e.revoked_at IS NULL AND (e.expires_at IS NULL OR e.expires_at>?)
                ORDER BY e.starts_at DESC""", (uid, now()))

def expire_notifications():
    """Notify users once when a subscription lapses. Does not revoke anything (expiry is evaluated on read)."""
    from .notify import notify
    n = 0
    for r in q("""SELECT e.id, e.user_id, e.division, e.level FROM entitlements e WHERE e.kind='subscription' AND e.revoked_at IS NULL
                  AND e.expires_at IS NOT NULL AND e.expires_at <= ? AND e.expiry_notified=0""", (now(),)):
        from ..db import ex
        ex("UPDATE entitlements SET expiry_notified=1 WHERE id=?", (r["id"],))
        label = {"basic": "Basic", "advanced": "Advanced"}.get(r["level"] or "", "Income Skills" if r["division"] != "academic" else "Basic")
        from .content import ctf
        notify(r["user_id"], ctf("notif.expired_title", item=label), ctf("notif.expired_body"), "/pricing", "subscription")
        n += 1
    return n
