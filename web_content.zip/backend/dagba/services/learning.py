"""Read-only views over the existing learning records for the student dashboard (progress, assignments, quizzes, certificates, courses).
Nothing here writes to the database or changes enrolment, payment or progress logic; it only reads what lms/access already maintain."""
from datetime import date
from flask import url_for
from ..db import q, q1, val
from . import lms, access

def _ph(ids): return ",".join("?" * len(ids))
def today(): return date.today().isoformat()

def overview(uid, courses):
    """Overall progress across every course the student can learn in. `courses` rows carry a `progress` dict (see student.my_courses)."""
    total = sum(c["progress"]["total"] for c in courses); done = sum(c["progress"]["done"] for c in courses)
    full = [c for c in courses if c["progress"]["total"] and c["progress"]["percent"] == 100]
    started = [c for c in courses if 0 < c["progress"]["percent"] < 100 or (c["progress"]["done"] and c["progress"]["percent"] < 100)]
    return dict(courses=len(courses), lessons_total=total, lessons_done=done, percent=int(done * 100 / total) if total else 0,
                completed=len(full), in_progress=len(started), not_started=len(courses) - len(full) - len(started),
                certificates=val("SELECT COUNT(*) FROM certificates WHERE user_id=? AND revoked_at IS NULL", (uid,), 0))

def last_activity(uid):
    """{course_id: most recent time the student touched any lesson of it}"""
    return {r["course_id"]: r["t"] for r in q("SELECT course_id, MAX(updated_at) AS t FROM progress WHERE user_id=? GROUP BY course_id", (uid,))}

def continue_items(uid, courses, limit=4):
    """Per unfinished course: the lesson to resume (last touched unfinished lesson, else the next one) and the saved video position."""
    act = last_activity(uid); out = []
    for c in courses:
        p = c["progress"]
        if not p["total"] or p["percent"] >= 100: continue
        l = lms.resume_lesson(uid, c["id"])
        if not l: continue
        pr = q1("SELECT position_seconds FROM progress WHERE user_id=? AND lesson_id=?", (uid, l["id"]))
        out.append(dict(course=c, lesson=l, position=pr["position_seconds"] if pr else 0, last_at=act.get(c["id"]), started=bool(p["done"] or act.get(c["id"]))))
    out.sort(key=lambda i: i["last_at"] or "", reverse=True)       # most recently studied first; never-started courses last
    return out[:limit]

def recent_courses(uid, courses, limit=3):
    act = last_activity(uid); seen = [c for c in courses if act.get(c["id"])]
    seen.sort(key=lambda c: act[c["id"]], reverse=True)
    return [dict(c, last_at=act[c["id"]]) for c in seen[:limit]]

def recent_lessons(uid, course_ids, limit=6):
    if not course_ids: return []
    return q(f"""SELECT l.id, l.title, l.kind, c.title AS course, c.slug, p.updated_at, p.completed_at, p.position_seconds FROM progress p JOIN lessons l ON l.id=p.lesson_id
                 JOIN courses c ON c.id=p.course_id WHERE p.user_id=? AND p.course_id IN ({_ph(course_ids)}) ORDER BY p.updated_at DESC, l.id DESC LIMIT ?""", (uid, *course_ids, limit))

def completed_modules(uid, course_ids, limit=6):
    if not course_ids: return []
    return q(f"""SELECT m.id, m.title, c.title AS course, c.slug, MAX(p.completed_at) AS at, COUNT(l.id) AS lessons FROM modules m JOIN courses c ON c.id=m.course_id
                 JOIN lessons l ON l.module_id=m.id LEFT JOIN progress p ON p.lesson_id=l.id AND p.user_id=? AND p.completed_at IS NOT NULL
                 WHERE m.course_id IN ({_ph(course_ids)}) GROUP BY m.id HAVING COUNT(l.id)>0 AND COUNT(p.lesson_id)=COUNT(l.id) ORDER BY at DESC LIMIT ?""", (uid, *course_ids, limit))

def pending_assignments(uid, course_ids, limit=6):
    """Assignments of the student's courses that they have not submitted. Overdue ones first, then by due date; undated last."""
    if not course_ids: return []
    t = today()
    rows = q(f"""SELECT a.id, a.title, a.due_date, a.max_score, c.title AS course, c.slug FROM assignments a JOIN courses c ON c.id=a.course_id
                 WHERE a.course_id IN ({_ph(course_ids)}) AND NOT EXISTS (SELECT 1 FROM submissions s WHERE s.assignment_id=a.id AND s.user_id=?)""", (*course_ids, uid))
    out = [dict(r, due=(r["due_date"] or "")[:10], overdue=bool(r["due_date"]) and (r["due_date"] or "")[:10] < t) for r in rows]
    out.sort(key=lambda r: (r["due"] == "", r["due"] or "9999", r["id"]))
    return out[:limit]

def upcoming_assessments(uid, course_ids, limit=6):
    """Dated assignments still to hand in (due today or later) plus quizzes in the student's courses that they have not passed yet."""
    if not course_ids: return []
    t = today(); items = []
    for a in pending_assignments(uid, course_ids, 100):
        if a["due"] and a["due"] >= t: items.append(dict(kind="assignment", title=a["title"], course=a["course"], when=a["due"], link=url_for("student.assignment", slug=a["slug"], aid=a["id"])))
    for z in q(f"""SELECT z.id, z.title, c.title AS course, c.slug FROM quizzes z JOIN courses c ON c.id=z.course_id WHERE z.course_id IN ({_ph(course_ids)})
                   AND EXISTS (SELECT 1 FROM questions x WHERE x.quiz_id=z.id) AND NOT EXISTS (SELECT 1 FROM quiz_attempts a WHERE a.quiz_id=z.id AND a.user_id=? AND a.passed=1) ORDER BY z.course_id, z.position""", (*course_ids, uid)):
        items.append(dict(kind="quiz", title=z["title"], course=z["course"], when=None, link=url_for("student.quiz", slug=z["slug"], qid=z["id"])))
    items.sort(key=lambda i: (i["when"] is None, i["when"] or ""))
    return items[:limit]

def recent_results(uid, limit=5):
    """Latest grades: reviewed assignments and quiz attempts."""
    rows = [dict(kind="assignment", title=r["title"], course=r["course"], at=r["reviewed_at"] or r["submitted_at"], score=f"{r['score']}/{r['max_score']}" if r["score"] is not None else "reviewed", passed=None,
                 link=url_for("student.assignments")) for r in q("""SELECT s.score, s.reviewed_at, s.submitted_at, a.title, a.max_score, c.title AS course FROM submissions s JOIN assignments a ON a.id=s.assignment_id
                 JOIN courses c ON c.id=a.course_id WHERE s.user_id=? AND s.status='reviewed' ORDER BY s.reviewed_at DESC LIMIT ?""", (uid, limit))]
    rows += [dict(kind="quiz", title=r["title"], course=r["course"], at=r["created_at"], score=f"{r['score_percent']}%", passed=bool(r["passed"]), link=url_for("student.assessments"))
             for r in q("""SELECT a.score_percent, a.passed, a.created_at, z.title, c.title AS course FROM quiz_attempts a JOIN quizzes z ON z.id=a.quiz_id JOIN courses c ON c.id=z.course_id
                           WHERE a.user_id=? ORDER BY a.created_at DESC LIMIT ?""", (uid, limit))]
    rows.sort(key=lambda r: r["at"] or "", reverse=True); return rows[:limit]

def history(uid, limit=20):
    """Learning history: lessons completed, quiz attempts, assignments handed in or graded, certificates, newest first."""
    ev = []
    for r in q("SELECT l.title, c.title AS course, c.slug, l.id AS lid, p.completed_at AS at FROM progress p JOIN lessons l ON l.id=p.lesson_id JOIN courses c ON c.id=p.course_id WHERE p.user_id=? AND p.completed_at IS NOT NULL ORDER BY p.completed_at DESC LIMIT ?", (uid, limit)):
        ev.append(dict(kind="lesson", text="Completed lesson", title=r["title"], course=r["course"], at=r["at"], link=url_for("student.lesson", slug=r["slug"], lid=r["lid"])))
    for r in q("SELECT a.score_percent, a.passed, a.created_at AS at, z.title, c.title AS course, c.slug, z.id AS qid FROM quiz_attempts a JOIN quizzes z ON z.id=a.quiz_id JOIN courses c ON c.id=z.course_id WHERE a.user_id=? ORDER BY a.created_at DESC LIMIT ?", (uid, limit)):
        ev.append(dict(kind="quiz", text=f"Quiz: {'passed' if r['passed'] else 'not passed yet'} ({r['score_percent']}%)", title=r["title"], course=r["course"], at=r["at"], link=url_for("student.quiz", slug=r["slug"], qid=r["qid"])))
    for r in q("SELECT s.submitted_at, s.reviewed_at, s.score, s.status, a.title, a.max_score, c.title AS course FROM submissions s JOIN assignments a ON a.id=s.assignment_id JOIN courses c ON c.id=a.course_id WHERE s.user_id=? ORDER BY s.submitted_at DESC LIMIT ?", (uid, limit)):
        ev.append(dict(kind="assignment", text="Assignment submitted", title=r["title"], course=r["course"], at=r["submitted_at"], link=url_for("student.assignments")))
        if r["status"] == "reviewed" and r["reviewed_at"]:
            ev.append(dict(kind="assignment", text="Assignment graded" + (f" ({r['score']}/{r['max_score']})" if r["score"] is not None else ""), title=r["title"], course=r["course"], at=r["reviewed_at"], link=url_for("student.assignments")))
    for r in q("SELECT course_title, issued_at FROM certificates WHERE user_id=? AND revoked_at IS NULL ORDER BY issued_at DESC LIMIT ?", (uid, limit)):
        ev.append(dict(kind="certificate", text="Certificate earned", title=r["course_title"], course=r["course_title"], at=r["issued_at"], link=url_for("student.certificates")))
    ev.sort(key=lambda e: e["at"] or "", reverse=True); return ev[:limit]

def recommendations(uid, courses, limit=4):
    """Courses the student does not have yet, ranked by how closely they match what they study: same subject as a course they are taking or finished (the
    strongest signal), the next level up in a subject they completed, the same division and academic level, their own class level, then featured courses."""
    mine = {c["id"] for c in courses}
    cats = {c["category_id"] for c in courses if c["category_id"]}
    done_cats = {c["category_id"] for c in courses if c["category_id"] and c["progress"]["total"] and c["progress"]["percent"] == 100}
    lvl = lambda c: c["academic_level"] or ("basic" if c["division"] == "academic" else None)      # an Academic course with no stored level is a Basic one
    divs = {c["division"] for c in courses}; levels = {lvl(c) for c in courses if lvl(c)}
    done_basic = {c["category_id"] for c in courses if c["category_id"] and lvl(c) == "basic" and c["progress"]["total"] and c["progress"]["percent"] == 100}
    klass = val("SELECT class_level FROM users WHERE id=?", (uid,)) or ""
    names = {r["id"]: r["name"] for r in q("SELECT id, name FROM categories")}
    cand = q("SELECT c.*, cat.name AS category FROM courses c LEFT JOIN categories cat ON cat.id=c.category_id WHERE c.status='published'" + (f" AND c.id NOT IN ({_ph(mine)})" if mine else "") + " ORDER BY c.featured DESC, c.created_at DESC LIMIT 200", tuple(mine))
    scored = []
    for c in cand:
        s, why = 0, ""
        if c["category_id"] in cats: s += 4; why = f"Because you study {names.get(c['category_id'], 'this subject')}"
        if c["category_id"] in done_basic and lvl(c) == "advanced": s += 3; why = f"Next step after finishing {names.get(c['category_id'], 'Basic')}"
        elif c["category_id"] in done_cats: s += 1
        if c["division"] in divs: s += 2; why = why or "Matches your learning path"
        if lvl(c) and lvl(c) in levels: s += 1
        if klass and c["class_level"] and c["class_level"].lower() == klass.lower(): s += 3; why = why or f"For {klass}"
        if c["featured"]: s += 1; why = why or "Popular with learners"
        if not courses and not why: why = "A good place to start"
        if s or not courses: scored.append((s, c, why))
    scored.sort(key=lambda t: (-t[0], -(t[1]["featured"] or 0), t[1]["title"]))
    out = []
    for s, c, why in scored:
        mode = access.course_access(uid, c)                        # free or already covered by a subscription: say so instead of showing a price
        out.append(dict(course=c, reason=why or "You may also like", included=mode in ("free", "subscription")))
        if len(out) >= limit: break
    return out
