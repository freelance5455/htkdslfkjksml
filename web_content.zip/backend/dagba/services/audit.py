from flask import g, request, has_request_context
from ..db import ex

def log(action, entity=None, entity_id=None, detail=None, actor=None):
    actor = actor or (g.get("user") if has_request_context() else None)
    ip = request.remote_addr if has_request_context() else None
    ex("INSERT INTO audit_logs(actor_id, actor_label, action, entity, entity_id, detail, ip) VALUES (?,?,?,?,?,?,?)",
       (actor["id"] if actor else None, (actor["full_name"] + " <" + actor["email"] + ">") if actor else "system",
        action, entity, str(entity_id) if entity_id is not None else None, detail, ip))
