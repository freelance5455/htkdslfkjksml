"""Tutor Memorandum of Understanding (MOU): drafting, versioning, electronic acceptance and the signed-agreement register.

DOCUMENT MODEL
  mou_versions       Drafts and published versions. There is at most one draft. Publishing turns the draft into the next numbered version
                     (1.0 first; then 1.1, 1.2 ... for a "minor" change or 2.0, 3.0 ... for a "major" one). A published row can never be
                     changed or deleted (database triggers), so editing the MOU always produces a new version.
  mou_acceptances    One signed agreement per person per version, holding a permanent copy of the exact text accepted plus SHA-256 hashes of
                     that copy and of the whole record. Immutable and undeletable (database triggers). Every signed-agreement view and PDF
                     is produced from THIS snapshot, never from the editable MOU.
  mou_views          The applicant was shown version N before signing it (written when the document is rendered to them).

WHEN IS IT REQUIRED
  Only when a student submits a *tutor* application (kind 'tutor') for review. Saving a draft never needs it, and existing tutors who
  submit additional courses (kind 'course') are never asked. The check is made on the server inside the same transaction that submits
  the application (see tutors.save_application), so an application and its acceptance record are committed together or not at all.

A typed name is an electronic signature that records acceptance. It is NOT a verified identity credential and this module never says
that it is, or that it guarantees enforceability.
"""
import re, io, os, json, hashlib, secrets, sqlite3, unicodedata
from html.parser import HTMLParser
from html import escape as _esc
from urllib.parse import urlparse
from markupsafe import Markup
from flask import current_app, request, has_request_context
from ..db import get_db, q, q1, ex, val
from ..util import now
from . import settings, audit

DOC_SLUG = "tutor-mou"
MAX_HTML = 250_000
MIN_TEXT = 200                     # a published agreement must contain at least this much text

class MouError(Exception): pass

# ------------------------------------------------------------------ wording shown to the applicant (also stored with each acceptance)
def academy(): return (settings.get("site.name") or "Dagba Digital Academy").strip() or "Dagba Digital Academy"
def agreement_text():
    return f"I confirm that I have read, understood, and voluntarily agree to the terms and conditions contained in this Memorandum of Understanding between myself and {academy()}."
def confirmation_text():
    return "By entering my name and submitting this application, I acknowledge that my electronic signature represents my acceptance of this Memorandum of Understanding."
DISCLAIMER = ("This is a typed electronic signature recorded by the academy's system when the signatory submitted a tutor application. It records the signatory's "
              "acceptance of this document. It is not a verified identity credential, and this record does not by itself decide whether the document is legally enforceable.")

# ------------------------------------------------------------------ HTML sanitiser (whitelist, stdlib only)
ALLOWED = {"p", "br", "h2", "h3", "h4", "strong", "em", "u", "ul", "ol", "li", "blockquote", "hr", "a"}
ALIAS = {"b": "strong", "i": "em", "h1": "h2", "h5": "h4", "h6": "h4", "div": "p"}
VOID = {"br", "hr"}
INLINE = {"strong", "em", "u", "a", "br"}
PARA = {"p", "h2", "h3", "h4"}
CONTAINER = {"li", "ul", "ol", "blockquote"}
DROP = {"script", "style", "iframe", "object", "embed", "noscript", "template", "svg", "math", "textarea", "title", "head", "select", "option", "button", "form", "input"}

class Node:
    __slots__ = ("tag", "attrs", "kids")
    def __init__(self, tag, attrs=None): self.tag = tag; self.attrs = attrs or {}; self.kids = []

def safe_href(h):
    h = (h or "").strip()
    if not h or len(h) > 500 or re.search(r"[\x00-\x20\"'<>`]", h): return None
    p = urlparse(h)
    if p.scheme in ("http", "https") and p.netloc: return h
    if p.scheme == "mailto" and p.path and "@" in p.path: return h
    return None

class _Parser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = Node("root"); self.stack = [self.root]; self.skip = []
    def _top(self): return self.stack[-1]
    def _add(self, n): self._top().kids.append(n)
    def _close_para(self):
        for i in range(len(self.stack) - 1, 0, -1):
            t = self.stack[i].tag
            if t in CONTAINER: return
            if t in PARA: del self.stack[i:]; return
    def _pop_inline(self):
        while len(self.stack) > 1 and self.stack[-1].tag in INLINE: self.stack.pop()
    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if self.skip:
            if tag not in VOID: self.skip.append(tag)
            return
        if tag in DROP: self.skip.append(tag); return
        t = ALIAS.get(tag, tag)
        if t not in ALLOWED: return
        if t == "br": self._add(Node("br")); return
        if t == "hr": self._close_para(); self._pop_inline(); self._add(Node("hr")); return
        a = {}
        if t == "a":
            href = safe_href(dict(attrs).get("href"))
            if not href: return
            a["href"] = href
        if t in ("p", "h2", "h3", "h4", "ul", "ol", "blockquote"):
            self._close_para(); self._pop_inline()
        if t == "li":
            self._close_para(); self._pop_inline()
            for i in range(len(self.stack) - 1, 0, -1):          # close a sibling <li>, up to the list it belongs to
                if self.stack[i].tag in ("ul", "ol"): del self.stack[i + 1:]; break
            else: t = "p"                                          # <li> outside any list: keep the text as a paragraph
        n = Node(t, a); self._add(n); self.stack.append(n)
    def handle_endtag(self, tag):
        tag = tag.lower()
        if self.skip:
            if tag in self.skip:
                while self.skip and self.skip.pop() != tag: pass
            return
        t = ALIAS.get(tag, tag)
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == t: del self.stack[i:]; return
    def handle_data(self, data):
        if not self.skip and data: self._add(data)

def _has_text(kids):
    for k in kids:
        if isinstance(k, str):
            if k.strip(): return True
        elif k.tag == "br": continue
        elif _has_text(k.kids): return True
    return False

def _group_inline(kids):
    """Wrap runs of inline content in paragraphs (used for the document root, <blockquote> and list items that mix text and blocks)."""
    out, run = [], []
    def flush():
        if run and _has_text(run): p = Node("p"); p.kids = list(run); out.append(p)
        run.clear()
    for k in kids:
        if isinstance(k, str) or k.tag in INLINE: run.append(k)
        else: flush(); out.append(k)
    flush(); return out

def _norm(node):
    kids = []
    for k in node.kids:
        if isinstance(k, str): kids.append(re.sub(r"\s+", " ", k)); continue
        _norm(k)
        if k.tag == "hr" or k.tag == "br": kids.append(k)
        elif k.tag in ("ul", "ol"):
            if k.kids: kids.append(k)
        elif _has_text(k.kids) or any(isinstance(c, Node) and c.tag in ("ul", "ol") for c in k.kids): kids.append(k)
    node.kids = kids
    if node.tag in ("root", "blockquote"): node.kids = _group_inline(node.kids)
    elif node.tag in ("ul", "ol"):
        fixed = []
        for k in node.kids:
            if isinstance(k, Node) and k.tag == "li": fixed.append(k)
            elif isinstance(k, Node) and k.tag in ("ul", "ol") and fixed: fixed[-1].kids.append(k)      # editors emit a nested list beside its parent item
            else:
                if isinstance(k, str) and not k.strip(): continue
                li = Node("li"); li.kids = [k]; fixed.append(li)
        node.kids = fixed
    elif node.tag == "li":
        if any(isinstance(k, Node) and k.tag not in INLINE for k in node.kids): node.kids = _group_inline_keep(node.kids)
    if node.tag in PARA or node.tag == "li":                       # trim the ends of a text block
        while node.kids and isinstance(node.kids[0], str) and not node.kids[0].strip(): node.kids.pop(0)
        while node.kids and isinstance(node.kids[-1], str) and not node.kids[-1].strip(): node.kids.pop()
        if node.kids and isinstance(node.kids[0], str): node.kids[0] = node.kids[0].lstrip()
        if node.kids and isinstance(node.kids[-1], str): node.kids[-1] = node.kids[-1].rstrip()

def _group_inline_keep(kids):
    """A list item that holds paragraphs or nested lists: inline runs become paragraphs, blocks stay as they are."""
    return _group_inline(kids)

def parse(html):
    html = (html or "")[:MAX_HTML * 2]
    p = _Parser()
    try: p.feed(html); p.close()
    except Exception: pass
    _norm(p.root)
    return p.root.kids

def to_html(nodes):
    out = []
    for n in nodes:
        if isinstance(n, str): out.append(_esc(n, quote=False))
        elif n.tag == "br": out.append("<br>")
        elif n.tag == "hr": out.append("<hr>")
        elif n.tag == "a": out.append(f'<a href="{_esc(n.attrs["href"], quote=True)}" rel="noopener noreferrer nofollow" target="_blank">{to_html(n.kids)}</a>')
        else: out.append(f"<{n.tag}>{to_html(n.kids)}</{n.tag}>")
    return "".join(out)

def plain_text(nodes):
    out = []
    for n in nodes:
        if isinstance(n, str): out.append(n)
        elif n.tag in ("br", "hr"): out.append("\n")
        else: out.append(plain_text(n.kids)); out.append("\n" if n.tag in ("p", "li", "h2", "h3", "h4", "blockquote") else "")
    return "".join(out)

def sanitize(html):
    """Return the safe, normalised HTML for `html`. Idempotent: sanitize(sanitize(x)) == sanitize(x)."""
    return to_html(parse(html))

def safe_markup(html): return Markup(sanitize(html))      # Jinja filter `mou_html`: even stored text is re-checked on the way out

def text_length(html): return len(re.sub(r"\s+", " ", plain_text(parse(html))).strip())

# ------------------------------------------------------------------ hashing
def content_hash(title, body_html): return hashlib.sha256(((title or "") + "\n" + (body_html or "")).encode("utf-8")).hexdigest()

_REC_FIELDS = ("reference", "user_id", "application_id", "version_id", "version_label", "document_title", "content_hash", "full_name", "email",
               "signature", "agreement_text", "confirmation_text", "accepted_at")
def record_digest(d):
    blob = json.dumps([d[k] if d[k] is not None else None for k in _REC_FIELDS], ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()

def verify(acc):
    """True when the stored snapshot and record still match the hashes written at signing (and the published version's hash)."""
    try:
        if content_hash(acc["document_title"], acc["content_html"]) != acc["content_hash"]: return False
        if record_digest(acc) != acc["record_hash"]: return False
        v = q1("SELECT content_hash FROM mou_versions WHERE id=?", (acc["version_id"],))
        return bool(v and v["content_hash"] == acc["content_hash"])
    except Exception: return False

# ------------------------------------------------------------------ names
def norm_name(s):
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", s or "")).strip().casefold()

def names_match(typed, registered):
    return bool(norm_name(typed)) and norm_name(typed) == norm_name(registered)

# ------------------------------------------------------------------ versions
def document(): return q1("SELECT * FROM mou_documents WHERE slug=?", (DOC_SLUG,))
def get_version(vid): return q1("SELECT * FROM mou_versions WHERE id=?", (vid,)) if vid else None
def current():
    """The published version applicants must accept (the highest version number), or None."""
    return q1("SELECT * FROM mou_versions WHERE document_id=? AND status='published' ORDER BY version_major DESC, version_minor DESC LIMIT 1", (document()["id"],))
def draft(): return q1("SELECT * FROM mou_versions WHERE document_id=? AND status='draft'", (document()["id"],))

def next_numbers(change_type):
    cur = current()
    if not cur: return 1, 0
    return (cur["version_major"] + 1, 0) if change_type == "major" else (cur["version_major"], cur["version_minor"] + 1)
def next_label(change_type): a, b = next_numbers(change_type); return f"{a}.{b}"

def versions():
    """Every version, newest first, with who/when and how many people signed it."""
    return q("""SELECT v.*, cu.full_name AS created_name, uu.full_name AS updated_name, pu.full_name AS published_name,
                       (SELECT COUNT(*) FROM mou_acceptances a WHERE a.version_id=v.id) AS signed
                FROM mou_versions v LEFT JOIN users cu ON cu.id=v.created_by LEFT JOIN users uu ON uu.id=v.updated_by LEFT JOIN users pu ON pu.id=v.published_by
                WHERE v.document_id=? ORDER BY CASE v.status WHEN 'draft' THEN 0 ELSE 1 END, v.version_major DESC, v.version_minor DESC, v.id DESC""", (document()["id"],))

def _need_manage(actor):
    from ..security import has_perm
    if not actor or not has_perm("mou.manage", actor): raise MouError("You do not have permission to manage the tutor MOU.")

def create_draft(actor):
    """Start editing: a draft copy of the current version (or of the standard template when nothing is published yet). One draft at a time."""
    _need_manage(actor)
    d = draft()
    if d: return d
    cur = current(); doc = document()
    did = ex("INSERT INTO mou_versions(document_id, status, title, body_html, change_type, based_on_id, created_by, updated_by) VALUES (?,?,?,?,?,?,?,?)",
             (doc["id"], "draft", cur["title"] if cur else doc["title"], cur["body_html"] if cur else starter_html(), "minor", cur["id"] if cur else None, actor["id"], actor["id"]))
    audit.log("mou.draft_created", "mou_version", did, f"based on {cur['version_label']}" if cur else "from the standard template", actor=actor)
    return get_version(did)

def _clean_fields(form):
    title = re.sub(r"\s+", " ", (form.get("title") or "")).strip()[:200]
    body = sanitize((form.get("body_html") or "")[:MAX_HTML])
    ct = form.get("change_type") if form.get("change_type") in ("minor", "major") else "minor"
    note = (form.get("change_note") or "").strip()[:500]
    return title, body, ct, note

def save_draft(actor, form):
    _need_manage(actor)
    d = draft()
    if not d: raise MouError("There is no draft to save. Start a new version first.")
    title, body, ct, note = _clean_fields(form)
    if not title: raise MouError("Give the agreement a title.")
    cur = get_db().execute("UPDATE mou_versions SET title=?, body_html=?, change_type=?, change_note=?, updated_by=?, updated_at=? WHERE id=? AND status='draft'",
                           (title, body, ct, note or None, actor["id"], now(), d["id"]))
    if cur.rowcount != 1: raise MouError("The draft was changed by someone else. Reload the page.")
    audit.log("mou.draft_saved", "mou_version", d["id"], f"{len(body)} characters", actor=actor)
    return get_version(d["id"])

def discard_draft(actor):
    _need_manage(actor)
    d = draft()
    if not d: raise MouError("There is no draft to discard.")
    get_db().execute("DELETE FROM mou_versions WHERE id=? AND status='draft'", (d["id"],))
    audit.log("mou.draft_discarded", "mou_version", d["id"], "", actor=actor)

def publish(actor, form=None):
    """Save the submitted draft fields (if any) and publish the draft as the next version. One transaction; the version number is
    assigned here. The published row is immutable from this moment."""
    _need_manage(actor)
    if form is not None: save_draft(actor, form)
    d = draft()
    if not d: raise MouError("There is no draft to publish.")
    title, body = d["title"], sanitize(d["body_html"])
    if not title.strip(): raise MouError("Give the agreement a title before publishing.")
    if text_length(body) < MIN_TEXT: raise MouError(f"The agreement is too short to publish (at least {MIN_TEXT} characters of text).")
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        major, minor = next_numbers(d["change_type"]); label = f"{major}.{minor}"; h = content_hash(title, body); t = now()
        cur = db.execute("""UPDATE mou_versions SET status='published', body_html=?, version_major=?, version_minor=?, version_label=?, content_hash=?, published_by=?, published_at=?, updated_by=?, updated_at=?
                            WHERE id=? AND status='draft'""", (body, major, minor, label, h, actor["id"], t, actor["id"], t, d["id"]))
        if cur.rowcount != 1: raise MouError("This draft was already published.")
        db.execute("INSERT INTO audit_logs(actor_id,actor_label,action,entity,entity_id,detail,ip) VALUES (?,?,?,?,?,?,?)",
                   (actor["id"], f"{actor['full_name']} <{actor['email']}>", "mou.published", "mou_version", str(d["id"]), f"version {label} sha256 {h[:16]}", request.remote_addr if has_request_context() else None))
        db.execute("COMMIT")
    except Exception:
        if db.in_transaction: db.execute("ROLLBACK")
        raise
    return get_version(d["id"])

# ------------------------------------------------------------------ the applicant side
def already_signed(uid, version_id):
    return q1("SELECT * FROM mou_acceptances WHERE user_id=? AND version_id=?", (uid, version_id))

def record_view(user, version):
    """The applicant has been shown this published version. Idempotent; written when the document is rendered to them."""
    if not user or not version or version["status"] != "published": return
    ex("INSERT OR IGNORE INTO mou_views(user_id, version_id, ip_address) VALUES (?,?,?)", (user["id"], version["id"], request.remote_addr if has_request_context() else None))

def was_viewed(uid, version_id): return bool(val("SELECT 1 FROM mou_views WHERE user_id=? AND version_id=?", (uid, version_id)))

def check_submission(user, form):
    """Server-side gate for submitting a tutor application. Returns (errors, version, already) where `already` is the existing acceptance of the
    current version, if this person has one. Nothing is trusted from the browser: the version, the tick and the name are all re-checked."""
    v = current()
    if not v: return ["The tutor agreement (MOU) has not been published yet, so applications cannot be submitted right now. Your draft is saved; please try again soon."], None, None
    done = already_signed(user["id"], v["id"])
    if done: return [], v, done
    errs = []
    try: posted = int(form.get("mou_version_id") or 0)
    except (TypeError, ValueError): posted = 0
    if posted != v["id"]:
        errs.append("Please review the Memorandum of Understanding shown in the application and sign it. It may have been updated since you opened this page.")
    elif not was_viewed(user["id"], v["id"]):
        errs.append("Please open and read the Memorandum of Understanding before signing it.")
    if form.get("mou_agree") != "1": errs.append("Tick the box to confirm that you have read and agree to the Memorandum of Understanding.")
    sig = (form.get("mou_signature") or "").strip()
    if not sig: errs.append("Type your full legal name in the signature box to sign the Memorandum of Understanding.")
    elif len(sig) > 200 or not names_match(sig, user["full_name"]):
        errs.append(f"Your signature must match the full name on your account ({user['full_name']}). If your name is not correct, update it in Profile settings and try again.")
    return errs, v, None

def new_reference():
    for _ in range(20):
        r = "DDA-MOU-" + now()[:4] + "-" + "".join(secrets.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(8))
        if not val("SELECT 1 FROM mou_acceptances WHERE reference=?", (r,)): return r
    raise MouError("Could not allocate an agreement reference. Please try again.")

def accept(user, app, version, form):
    """Write the signed agreement. MUST be called inside the caller's transaction (it does not begin or commit one), so that the
    application and its agreement are committed together. Returns the acceptance row. A repeat for the same person and version returns
    the existing record rather than a duplicate."""
    done = already_signed(user["id"], version["id"])
    if done: return done
    fresh = get_version(version["id"])                       # the stored text is what is signed, never what the browser or an old page held
    if not fresh or fresh["status"] != "published": raise MouError("That version of the agreement is not available.")
    u = q1("SELECT id, full_name, email FROM users WHERE id=?", (user["id"],))
    d = dict(reference=new_reference(), user_id=u["id"], application_id=app["id"] if app else None, version_id=fresh["id"], version_label=fresh["version_label"],
             document_title=fresh["title"], content_html=fresh["body_html"], content_hash=fresh["content_hash"], full_name=u["full_name"], email=u["email"],
             signature=re.sub(r"\s+", " ", (form.get("mou_signature") or "").strip())[:200], agreement_text=agreement_text(), confirmation_text=confirmation_text(), accepted_at=now())
    d["record_hash"] = record_digest(d)
    ua = (request.headers.get("User-Agent", "") if has_request_context() else "")[:300]
    ip = request.remote_addr if has_request_context() else None
    try:
        aid = ex("""INSERT INTO mou_acceptances(reference,user_id,application_id,version_id,version_label,document_title,content_html,content_hash,full_name,email,signature,agreement_text,confirmation_text,accepted_at,ip_address,user_agent,record_hash)
                    VALUES (:reference,:user_id,:application_id,:version_id,:version_label,:document_title,:content_html,:content_hash,:full_name,:email,:signature,:agreement_text,:confirmation_text,:accepted_at,:ip,:ua,:record_hash)""",
                 {**d, "ip": ip, "ua": ua})
    except sqlite3.IntegrityError:
        again = already_signed(user["id"], version["id"])
        if again: return again
        raise
    acc = q1("SELECT * FROM mou_acceptances WHERE id=?", (aid,))
    audit.log("mou.accepted", "mou_acceptance", aid, f"{acc['reference']} version {acc['version_label']} by user {u['id']}", actor=user)
    return acc

# ------------------------------------------------------------------ reading signed agreements
def by_reference(ref):
    return q1("SELECT a.*, u.role AS account_role FROM mou_acceptances a JOIN users u ON u.id=a.user_id WHERE a.reference=?", ((ref or "").strip(),))

def for_user(uid):
    """All of a person's signed agreements, newest first (every version they ever signed stays here)."""
    return q("SELECT a.*, u.role AS account_role FROM mou_acceptances a JOIN users u ON u.id=a.user_id WHERE a.user_id=? ORDER BY a.accepted_at DESC, a.id DESC", (uid,))

def status_of(acc, current_id=None):
    """(label, css) for the signature status column."""
    if not verify(acc): return "Integrity check failed", "red"
    cid = current_id if current_id is not None else (current() or {"id": None})["id"]
    return ("Signed", "green") if acc["version_id"] == cid else ("Signed (earlier version)", "blue")

def for_application(app_id):
    return q1("SELECT * FROM mou_acceptances WHERE application_id=? ORDER BY id DESC LIMIT 1", (app_id,))

def _like(s): return "%" + s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"

def records_query(args):
    where, a = ["1=1"], []
    term = (args.get("q") or "").strip()[:100]
    if term: where.append("(a.full_name LIKE ? ESCAPE '\\' OR a.email LIKE ? ESCAPE '\\' OR a.signature LIKE ? ESCAPE '\\' OR a.reference LIKE ? ESCAPE '\\')"); a += [_like(term)] * 4
    ver = args.get("version", type=int) if hasattr(args, "get") else None
    if ver: where.append("a.version_id=?"); a.append(ver)
    if args.get("from"): where.append("a.accepted_at>=?"); a.append(args["from"][:10])
    if args.get("to"): where.append("a.accepted_at<=?"); a.append(args["to"][:10] + " 23:59:59")
    cur = current(); cid = cur["id"] if cur else -1
    st = args.get("status", "")
    if st == "current": where.append("a.version_id=?"); a.append(cid)
    elif st == "earlier": where.append("a.version_id<>?"); a.append(cid)
    acct = args.get("account", "")
    if acct == "tutor": where.append("u.role='instructor'")
    elif acct == "applicant": where.append("u.role<>'instructor'")
    sql = f"SELECT a.*, u.role AS account_role FROM mou_acceptances a JOIN users u ON u.id=a.user_id WHERE {' AND '.join(where)} ORDER BY a.accepted_at DESC, a.id DESC"
    return sql, tuple(a)

def count_signed(version_id): return val("SELECT COUNT(*) FROM mou_acceptances WHERE version_id=?", (version_id,), 0)

# ------------------------------------------------------------------ may this person see this agreement?
def can_view(user, acc):
    from ..security import has_perm
    if not user or not acc: return False
    if acc["user_id"] == user["id"]: return True
    return has_perm("tutors.manage", user) or has_perm("mou.manage", user)

def can_review_records(user=None):
    from ..security import has_perm
    return has_perm("tutors.manage", user) or has_perm("mou.manage", user)

# ------------------------------------------------------------------ starter text
def starter_html():
    """A plain starting point for the very first draft. The academy's own wording (and legal review) replaces it before publishing."""
    n = academy()
    return (f"<h2>1. Parties and purpose</h2><p>This Memorandum of Understanding (&ldquo;MOU&rdquo;) is made between {n} (&ldquo;the Academy&rdquo;) and the person who signs it (&ldquo;the Tutor&rdquo;). "
            f"It sets out the basis on which the Tutor may publish and teach courses on the Academy&rsquo;s platform.</p>"
            "<h2>2. The Tutor&rsquo;s responsibilities</h2><ol><li>To give accurate information about their identity, qualifications and experience.</li>"
            "<li>To create original course material, or material they have the right to use, and to keep it accurate and up to date.</li>"
            "<li>To treat learners with courtesy and respect and to respond to learner questions within a reasonable time.</li>"
            "<li>Not to share learner personal data outside the platform or use it for any purpose other than teaching the course.</li></ol>"
            f"<h2>3. The Academy&rsquo;s responsibilities</h2><ol><li>To host, market and sell the Tutor&rsquo;s approved courses on the platform.</li>"
            "<li>To review courses before publication and to explain any changes it requires.</li>"
            "<li>To record sales and pay the Tutor&rsquo;s share of revenue in line with the rates and payout rules published in the Tutor dashboard.</li></ol>"
            "<h2>4. Intellectual property</h2><p>The Tutor keeps ownership of their course material and grants the Academy a non-exclusive licence to host, display and sell it on the platform while the course is published.</p>"
            "<h2>5. Suspension and termination</h2><p>Either party may end this MOU by giving written notice. The Academy may suspend a Tutor who breaches this MOU or the platform rules, and will give the reason.</p>"
            "<h2>6. Changes to this MOU</h2><p>The Academy may publish a new version of this MOU. A new version applies to tutors who accept it; each tutor keeps a copy of the version they signed.</p>"
            "<h2>7. Acceptance</h2><p>The Tutor accepts this MOU by ticking the confirmation box and typing their full legal name as an electronic signature when submitting their tutor application.</p>")

# ------------------------------------------------------------------ PDF
_FONTS = {}
def _font_set():
    """Register a Unicode font family once. Prefers DejaVu Serif / Liberation Serif if installed, then the Bitstream Vera that ships inside
    reportlab (so a PDF can always be produced), then the built-in Times. Returns dict(reg, bold, ital, bi, ttf)."""
    if _FONTS: return _FONTS
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    import reportlab
    rl = os.path.join(os.path.dirname(reportlab.__file__), "fonts")
    cands = [("DDASerif", ["/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Italic.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSerif-BoldItalic.ttf"]),
             ("DDASerif", ["/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf", "/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf", "/usr/share/fonts/truetype/liberation/LiberationSerif-Italic.ttf", "/usr/share/fonts/truetype/liberation/LiberationSerif-BoldItalic.ttf"]),
             ("DDAVera", [os.path.join(rl, f) for f in ("Vera.ttf", "VeraBd.ttf", "VeraIt.ttf", "VeraBI.ttf")])]
    for base, paths in cands:
        if all(os.path.exists(p) for p in paths):
            try:
                names = [f"{base}", f"{base}-Bold", f"{base}-Italic", f"{base}-BoldItalic"]
                for nme, p in zip(names, paths): pdfmetrics.registerFont(TTFont(nme, p))
                pdfmetrics.registerFontFamily(base, normal=names[0], bold=names[1], italic=names[2], boldItalic=names[3])
                _FONTS.update(reg=names[0], bold=names[1], ital=names[2], bi=names[3], ttf=True); return _FONTS
            except Exception: continue
    _FONTS.update(reg="Times-Roman", bold="Times-Bold", ital="Times-Italic", bi="Times-BoldItalic", ttf=False)
    return _FONTS

def _supported(ch, f):
    from reportlab.pdfbase import pdfmetrics
    if f["ttf"]:
        face = pdfmetrics.getFont(f["reg"]).face
        return ord(ch) in face.charToGlyph
    try: ch.encode("cp1252"); return True
    except UnicodeEncodeError: return False

def _pdf_text(s, f):
    """Make text safe for the PDF font: keep every character the font can draw, fold accents away when it cannot, otherwise '?'."""
    s = unicodedata.normalize("NFC", s or "").replace("\u00a0", " ")
    out = []
    for ch in s:
        if ch in "\n\t" or _supported(ch, f): out.append(ch); continue
        base = "".join(c for c in unicodedata.normalize("NFKD", ch) if not unicodedata.combining(c))
        out.append(base if base and all(_supported(c, f) for c in base) else "?")
    return "".join(out)

def _logo_path():
    p = os.path.join(current_app.static_folder, "img", "logo.png"); custom = settings.get("brand.logo", "")
    if custom and os.path.exists(os.path.join(current_app.config["PUBLIC_DIR"], custom)): p = os.path.join(current_app.config["PUBLIC_DIR"], custom)
    return p if os.path.exists(p) else None

def build_pdf(title, version_label, body_html, acc=None, status_note=None):
    """The agreement as a formal A4 PDF. With `acc` (a signed agreement row) it is built ONLY from that row's stored snapshot and shows the
    signature and acceptance record; without it, an unsigned review copy of the given text. `status_note` is printed on unsigned copies
    (for example 'Draft - not published')."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.lib.colors import HexColor, white
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT, TA_CENTER
    from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle, KeepTogether, ListFlowable, ListItem, HRFlowable, Image
    from reportlab.pdfgen import canvas as rl_canvas
    from xml.sax.saxutils import escape as xesc
    f = _font_set(); T = lambda s: _pdf_text(s, f)
    brand = HexColor(settings.get("brand.primary", "#7236E6") or "#7236E6"); dark = HexColor(settings.get("brand.dark", "#1b1230") or "#1b1230"); grey = HexColor("#5b5870"); rule = HexColor("#d9d4ee")
    name = academy(); tagline = settings.get("site.tagline", "") or ""
    W, H = A4; LM = RM = 22 * mm; TM = 30 * mm; BM = 24 * mm
    body = ParagraphStyle("body", fontName=f["reg"], fontSize=10.3, leading=15.2, alignment=TA_JUSTIFY, textColor=HexColor("#1f1b2e"), spaceAfter=6)
    h2 = ParagraphStyle("h2", parent=body, fontName=f["bold"], fontSize=12.6, leading=16, alignment=TA_LEFT, textColor=dark, spaceBefore=12, spaceAfter=5, keepWithNext=1)
    h3 = ParagraphStyle("h3", parent=h2, fontSize=11.2, leading=14.5, spaceBefore=8, textColor=brand)
    h4 = ParagraphStyle("h4", parent=h3, fontName=f["bi"], fontSize=10.5, textColor=dark)
    quote = ParagraphStyle("quote", parent=body, leftIndent=14, textColor=grey, fontName=f["ital"], borderPadding=0)
    small = ParagraphStyle("small", parent=body, fontSize=8.6, leading=12, alignment=TA_LEFT, textColor=grey, spaceAfter=3)
    cell = ParagraphStyle("cell", parent=body, fontSize=9.6, leading=13, alignment=TA_LEFT, spaceAfter=0)
    lab = ParagraphStyle("lab", parent=cell, fontName=f["bold"], textColor=grey, fontSize=8.6)
    mono = ParagraphStyle("mono", parent=cell, fontName="Courier", fontSize=7.6, leading=10)
    sigst = ParagraphStyle("sig", parent=cell, fontName=f["bi"], fontSize=19, leading=24, textColor=dark)

    def inline(nodes):
        out = []
        for n in nodes:
            if isinstance(n, str): out.append(xesc(T(n)))
            elif n.tag == "br": out.append("<br/>")
            elif n.tag == "strong": out.append(f"<b>{inline(n.kids)}</b>")
            elif n.tag == "em": out.append(f"<i>{inline(n.kids)}</i>")
            elif n.tag == "u": out.append(f"<u>{inline(n.kids)}</u>")
            elif n.tag == "a": out.append(f'<a href="{xesc(n.attrs["href"], {chr(34): "&quot;"})}" color="#2563eb"><u>{inline(n.kids)}</u></a>')
            else: out.append(inline(n.kids))
        return "".join(out)

    def flows(nodes, depth=0, style=None):
        out, run = [], []
        def flush():
            if run and _has_text(run): out.append(Paragraph(inline(run), style or body))
            run.clear()
        for n in nodes:
            if isinstance(n, str) or n.tag in INLINE: run.append(n); continue
            flush()
            if n.tag == "p": 
                if _has_text(n.kids): out.append(Paragraph(inline(n.kids), style or body))
            elif n.tag in ("h2", "h3", "h4"): out.append(Paragraph(inline(n.kids), {"h2": h2, "h3": h3, "h4": h4}[n.tag]))
            elif n.tag == "hr": out.append(HRFlowable(width="100%", thickness=0.6, color=rule, spaceBefore=4, spaceAfter=8))
            elif n.tag == "blockquote": out += flows(n.kids, depth, quote)
            elif n.tag in ("ul", "ol"):
                items = [ListItem(flows(li.kids, depth + 1, style) or [Spacer(1, 1)], leftIndent=22) for li in n.kids]
                kw = dict(bulletType="bullet", start="\u2022" if f["ttf"] else "-") if n.tag == "ul" else dict(bulletType=["1", "a", "i"][min(depth, 2)], bulletFormat=["%s.", "(%s)", "(%s)"][min(depth, 2)])
                out.append(ListFlowable(items, bulletFontName=f["reg"], bulletFontSize=10.3, bulletOffsetY=0, leftIndent=22, spaceBefore=0, spaceAfter=4, **kw))
        flush(); return out

    class Numbered(rl_canvas.Canvas):
        def __init__(self, *a, **k): super().__init__(*a, **k); self._states = []
        def showPage(self): self._states.append(dict(self.__dict__)); self._startPage()
        def save(self):
            total = len(self._states)
            for st in self._states: self.__dict__.update(st); self._decorate(total); super().showPage()
            super().save()
        def _decorate(self, total):
            self.saveState()
            logo = _logo_path()
            if logo:
                try:
                    from reportlab.lib.utils import ImageReader
                    self.drawImage(ImageReader(logo), LM, H - 21 * mm, 11 * mm, 11 * mm, mask="auto", preserveAspectRatio=True)
                except Exception: pass
            self.setFillColor(dark); self.setFont(f["bold"], 11); self.drawString(LM + 14 * mm, H - 15.5 * mm, T(name))
            self.setFillColor(grey); self.setFont(f["reg"], 8); self.drawString(LM + 14 * mm, H - 19.5 * mm, T(tagline)[:90])
            self.setFont(f["reg"], 8.5); self.drawRightString(W - RM, H - 15.5 * mm, T(title)[:70]); self.drawRightString(W - RM, H - 19.5 * mm, f"Version {version_label}")
            self.setStrokeColor(brand); self.setLineWidth(1.4); self.line(LM, H - 24 * mm, W - RM, H - 24 * mm)
            self.setStrokeColor(rule); self.setLineWidth(0.6); self.line(LM, 16 * mm, W - RM, 16 * mm)
            self.setFillColor(grey); self.setFont(f["reg"], 8)
            self.drawString(LM, 11.5 * mm, T(f"Agreement reference: {acc['reference']}" if acc else (status_note or "Unsigned review copy")))
            self.drawRightString(W - RM, 11.5 * mm, f"Page {self._pageNumber} of {total}")
            self.restoreState()

    buf = io.BytesIO()
    doc = BaseDocTemplate(buf, pagesize=A4, leftMargin=LM, rightMargin=RM, topMargin=TM, bottomMargin=BM, title=T(f"{title} v{version_label}"), author=T(name), subject=T(f"{title} - version {version_label}"),
                          creator=T(name))
    doc.addPageTemplates([PageTemplate(id="p", frames=[Frame(LM, BM, W - LM - RM, H - TM - BM, id="f", leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)])])
    story = []
    ts = ParagraphStyle("title", parent=h2, fontSize=21, leading=26, alignment=TA_LEFT, spaceBefore=2, spaceAfter=4, textColor=dark, keepWithNext=0)
    story.append(Paragraph(xesc(T(title)), ts))
    sub = f"Version {version_label}" + (f" &nbsp;|&nbsp; Agreement reference {xesc(acc['reference'])}" if acc else (f" &nbsp;|&nbsp; {xesc(T(status_note))}" if status_note else " &nbsp;|&nbsp; Unsigned review copy"))
    story.append(Paragraph(sub, ParagraphStyle("sub", parent=small, fontSize=9.5, textColor=brand, fontName=f["bold"], spaceAfter=8)))
    if acc:
        info = Table([[Paragraph("BETWEEN", lab), Paragraph(f"{xesc(T(name))} (the Academy) and <b>{xesc(T(acc['full_name']))}</b> (the Tutor)", cell)],
                      [Paragraph("SIGNED", lab), Paragraph(f"{xesc(acc['accepted_at'][:16])} UTC &nbsp;|&nbsp; electronically, by typed name", cell)]],
                     colWidths=[24 * mm, W - LM - RM - 24 * mm])
        info.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), HexColor("#f6f3ff")), ("BOX", (0, 0), (-1, -1), 0.6, rule), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5), ("LEFTPADDING", (0, 0), (-1, -1), 8)]))
        story += [info, Spacer(1, 8)]
    story += flows(parse(body_html))
    if acc:
        rows = [[Paragraph("Signed by (electronic signature)", lab), Paragraph(xesc(T(acc["signature"])), sigst)],
                [Paragraph("Full legal name (registered)", lab), Paragraph(xesc(T(acc["full_name"])), cell)],
                [Paragraph("Registered email", lab), Paragraph(xesc(T(acc["email"])), cell)],
                [Paragraph("User ID", lab), Paragraph(str(acc["user_id"]), cell)],
                [Paragraph("Date and time signed", lab), Paragraph(f"{xesc(acc['accepted_at'])} UTC", cell)],
                [Paragraph("MOU version accepted", lab), Paragraph(f"{xesc(T(acc['document_title']))}, version {xesc(acc['version_label'])}", cell)],
                [Paragraph("Agreement reference", lab), Paragraph(xesc(acc["reference"]), cell)],
                [Paragraph("Document fingerprint (SHA-256)", lab), Paragraph(acc["content_hash"][:32] + "<br/>" + acc["content_hash"][32:], mono)]]
        t = Table(rows, colWidths=[52 * mm, W - LM - RM - 52 * mm])
        t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.5, rule), ("BACKGROUND", (0, 0), (0, -1), HexColor("#f6f3ff")), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5), ("LEFTPADDING", (0, 0), (-1, -1), 8)]))
        story.append(KeepTogether([HRFlowable(width="100%", thickness=1.4, color=brand, spaceBefore=14, spaceAfter=6),
                                   Paragraph("ELECTRONIC SIGNATURE AND ACCEPTANCE RECORD", ParagraphStyle("sh", parent=h2, fontSize=11.5, spaceBefore=2, keepWithNext=1)), t, Spacer(1, 7),
                                   Paragraph("<b>Agreement confirmed by the signatory:</b> " + xesc(T(acc["agreement_text"])), small),
                                   Paragraph("<b>Acknowledgement:</b> " + xesc(T(acc["confirmation_text"])), small),
                                   Paragraph("<i>" + xesc(T(DISCLAIMER)) + "</i>", small)]))
    else:
        story += [Spacer(1, 10), HRFlowable(width="100%", thickness=0.6, color=rule), Spacer(1, 4),
                  Paragraph(xesc(T("This is an unsigned copy for review. The agreement is accepted only when it is signed electronically in the tutor application.")), small)]
    doc.build(story, canvasmaker=Numbered)
    return buf.getvalue()

def agreement_pdf(acc):
    """The signed agreement, built from its own stored snapshot only."""
    return build_pdf(acc["document_title"], acc["version_label"], acc["content_html"], acc=acc)

def version_pdf(v):
    note = None if v["status"] == "published" else "DRAFT - not published"
    return build_pdf(v["title"], v["version_label"] or "draft", v["body_html"], acc=None, status_note=note)

def pdf_filename(acc=None, v=None):
    if acc: return f"Dagba-Tutor-MOU-v{acc['version_label']}-{acc['reference']}.pdf"
    return f"Dagba-Tutor-MOU-v{(v['version_label'] if v and v['version_label'] else 'draft')}.pdf"
