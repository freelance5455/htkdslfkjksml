"""Tutor revenue share and withdrawals.
Rules: a tutor earns `payout.instructor_percent` (default 40%) of what the student actually paid for an individual course purchase
(after discounts). Subscriptions are not tied to a course, so the school keeps them. Money is credited exactly once when a payment is
approved, reversed if it is refunded, and withdrawals can only be requested from the available balance and are completed only with
an uploaded receipt."""
import math, re
from ..db import get_db, q, q1, ex, val
from ..util import now, now_dt, add_days, naira, parse_naira
from . import settings, uploads, audit
from .notify import notify, notify_staff
from .content import ctf

class PayoutError(Exception): pass

DIVISIONS = ("academic", "income", "professional", "faith")

def percent(division=None):
    """The tutor share (%) for a sale in `division`. Each division may have its own rate (Tutor payout settings); a blank one uses the default."""
    if division in DIVISIONS:
        raw = (settings.get(f"payout.instructor_percent_{division}", "") or "").strip()
        if not raw and division == "professional":          # Professional used to be part of Academic: until it gets its own rate it keeps the Academic one
            raw = (settings.get("payout.instructor_percent_academic", "") or "").strip()
        if raw:
            try: return max(0.0, min(100.0, float(raw)))
            except ValueError: pass
    try: return max(0.0, min(100.0, float(settings.get("payout.instructor_percent", "40"))))
    except ValueError: return 40.0

def rates(): return {d: percent(d) for d in DIVISIONS}

def min_kobo():
    try: return max(0, int(round(float(settings.get("payout.min_naira", "0")) * 100)))
    except ValueError: return 0

def share(amount_kobo, pct): return int(math.floor(amount_kobo * pct / 100.0 + 0.5))

def mask_name(full):
    p = (full or "").split()
    if not p: return "A student"
    return p[0] + (" " + p[-1][0] + "." if len(p) > 1 else "")

def record_sale(db, tx):
    """Called inside the payment-approval transaction. Idempotent (UNIQUE(transaction_id, kind)).
    A sale brought by the tutor's own referral link is 'affiliate' (tutor-generated) at the referral rate; every other sale is 'platform'
    (academy-generated) at the normal rate. The percent, its source and the reason are snapshotted on the ledger row."""
    if tx["item_type"] not in ("course", "faith") or tx["amount_kobo"] <= 0: return
    if tx["item_type"] == "faith":
        c = db.execute("SELECT instructor_id, 'faith' AS division FROM faith_series WHERE id=?", (tx["faith_series_id"],)).fetchone()
        if not c or not c["instructor_id"]: return
        p, source, basis, code = percent(c["division"]), "platform", "division", None
    else:
        c = db.execute("SELECT * FROM courses WHERE id=?", (tx["course_id"],)).fetchone()
        if not c or not c["instructor_id"]: return
        from . import tutors
        source, code = "platform", None
        if tx["tutor_ref_id"] and tutors.referral_valid_at_sale(db, tx, c): source, code = "affiliate", tx["tutor_ref_code"]
        p, basis = tutors.rate(c, c["instructor_id"], source)          # snapshot of the rate for THIS sale at approval time
    db.execute("INSERT OR IGNORE INTO instructor_earnings(instructor_id,transaction_id,course_id,faith_series_id,kind,gross_kobo,percent,amount_kobo,source,ref_code,rate_basis) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
               (c["instructor_id"], tx["id"], tx["course_id"], tx["faith_series_id"], "sale", tx["amount_kobo"], p, share(tx["amount_kobo"], p), source, code, basis))

def record_reversal(db, tx_id):
    """A refunded sale takes the tutor's share back."""
    s = db.execute("SELECT * FROM instructor_earnings WHERE transaction_id=? AND kind='sale'", (tx_id,)).fetchone()
    if s: db.execute("INSERT OR IGNORE INTO instructor_earnings(instructor_id,transaction_id,course_id,faith_series_id,kind,gross_kobo,percent,amount_kobo,source,ref_code,rate_basis) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                     (s["instructor_id"], tx_id, s["course_id"], s["faith_series_id"], "reversal", s["gross_kobo"], s["percent"], -s["amount_kobo"], s["source"], s["ref_code"], s["rate_basis"]))

def notify_sale(tx_id):
    try:
        e = q1("SELECT e.*, COALESCE(c.title, fs.title) AS title, u.full_name FROM instructor_earnings e LEFT JOIN courses c ON c.id=e.course_id LEFT JOIN faith_series fs ON fs.id=e.faith_series_id JOIN transactions t ON t.id=e.transaction_id JOIN users u ON u.id=t.user_id WHERE e.transaction_id=? AND e.kind='sale'", (tx_id,))
        if e: notify(e["instructor_id"], ctf("notif.sale_title"), ctf("notif.sale_body", student=mask_name(e["full_name"]), item=e["title"], amount=naira(e["amount_kobo"])), "/staff/earnings", "earning")
    except Exception: pass

def _cleared(db_q, uid):
    """Earned money that has finished its holding period (`payout.hold_days`, default 0 = available at once). A sale and its refund are netted per transaction."""
    from . import tutors
    days = tutors.hold_days()
    if days <= 0: return None
    cutoff = add_days(now_dt(), -days)
    return db_q("SELECT COALESCE(SUM(net),0) FROM (SELECT SUM(amount_kobo) net, MIN(created_at) first_at FROM instructor_earnings WHERE instructor_id=? GROUP BY transaction_id) WHERE first_at<=?", (uid, cutoff))

def summary(uid):
    earned = val("SELECT COALESCE(SUM(amount_kobo),0) FROM instructor_earnings WHERE instructor_id=?", (uid,), 0)
    gross = val("SELECT COALESCE(SUM(gross_kobo),0) FROM instructor_earnings WHERE instructor_id=? AND kind='sale'", (uid,), 0) - val("SELECT COALESCE(SUM(gross_kobo),0) FROM instructor_earnings WHERE instructor_id=? AND kind='reversal'", (uid,), 0)
    paid = val("SELECT COALESCE(SUM(amount_kobo),0) FROM payout_requests WHERE instructor_id=? AND status='paid'", (uid,), 0)
    pending = val("SELECT COALESCE(SUM(amount_kobo),0) FROM payout_requests WHERE instructor_id=? AND status='requested'", (uid,), 0)
    sales = val("SELECT COUNT(*) FROM instructor_earnings WHERE instructor_id=? AND kind='sale'", (uid,), 0)
    cl = _cleared(lambda sql, a: val(sql, a, 0), uid); cleared = earned if cl is None else cl
    clearing = max(0, earned - cleared)
    return dict(earned=earned, gross=gross, paid=paid, pending=pending, clearing=clearing, pending_total=pending + clearing, available=cleared - paid - pending, sales=sales)

def is_earner(user):
    return bool(user and (user["role"] == "instructor" or val("SELECT 1 FROM instructor_earnings WHERE instructor_id=? LIMIT 1", (user["id"],))))

def save_bank(user, bank, name, number):
    bank, name, number = (bank or "").strip()[:80], (name or "").strip()[:120], re.sub(r"\s+", "", number or "")
    if not bank or not name: raise PayoutError("Enter your bank name and the account name.")
    if not re.fullmatch(r"\d{10}", number): raise PayoutError("Account number must be exactly 10 digits.")
    ex("UPDATE users SET payout_bank=?, payout_account_name=?, payout_account_number=? WHERE id=?", (bank, name, number, user["id"]))
    audit.log("payout.bank_saved", "user", user["id"], f"{bank} ****{number[-4:]}", actor=user)
    return bank, name, number

def request(user, amount_text):
    """Create a withdrawal request. Only possible from money actually earned; one open request at a time."""
    if not settings.flag("payout.enabled"): raise PayoutError("Withdrawal requests are currently switched off. Please contact the academy.")
    from . import tutors
    if tutors.is_suspended(user["id"]): raise PayoutError("Your tutor account is suspended, so withdrawals are paused. Please contact the academy.")
    u = q1("SELECT * FROM users WHERE id=?", (user["id"],))
    if not (u["payout_bank"] and u["payout_account_name"] and u["payout_account_number"]): raise PayoutError("Save your bank account details first.")
    try: amount = parse_naira(amount_text)
    except ValueError as e: raise PayoutError(str(e))
    if amount <= 0: raise PayoutError("Enter the amount you want to withdraw.")
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        if db.execute("SELECT 1 FROM payout_requests WHERE instructor_id=? AND status='requested'", (u["id"],)).fetchone(): raise PayoutError("You already have a withdrawal request waiting to be paid. Wait for it to be completed or cancel it first.")
        s = summary_db(db, u["id"])
        if s["available"] <= 0: raise PayoutError("You can request a withdrawal once you have earned money.")
        if amount > s["available"]: raise PayoutError(f"You can withdraw at most {naira(s['available'])} right now.")
        if amount < min_kobo(): raise PayoutError(f"The minimum withdrawal is {naira(min_kobo())}.")
        rid = db.execute("INSERT INTO payout_requests(instructor_id,amount_kobo,bank_name,account_name,account_number) VALUES (?,?,?,?,?)", (u["id"], amount, u["payout_bank"], u["payout_account_name"], u["payout_account_number"])).lastrowid
        db.execute("INSERT INTO audit_logs(actor_id,actor_label,action,entity,entity_id,detail) VALUES (?,?,?,?,?,?)", (u["id"], u["email"], "payout.requested", "payout", str(rid), naira(amount)))
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK"); raise
    notify_staff("payouts.manage", "New withdrawal request", f"{u['full_name']} requested {naira(amount)}.", f"/staff/payouts/{rid}", "payout")
    return rid

def summary_db(db, uid):
    earned = db.execute("SELECT COALESCE(SUM(amount_kobo),0) FROM instructor_earnings WHERE instructor_id=?", (uid,)).fetchone()[0]
    cl = _cleared(lambda sql, a: db.execute(sql, a).fetchone()[0], uid); cleared = earned if cl is None else cl
    used = db.execute("SELECT COALESCE(SUM(amount_kobo),0) FROM payout_requests WHERE instructor_id=? AND status IN ('requested','paid')", (uid,)).fetchone()[0]
    return dict(earned=earned, available=cleared - used)

def cancel(user, rid):
    cur = get_db().execute("UPDATE payout_requests SET status='cancelled', decided_at=? WHERE id=? AND instructor_id=? AND status='requested'", (now(), rid, user["id"]))
    if cur.rowcount != 1: raise PayoutError("This request can no longer be cancelled.")
    audit.log("payout.cancelled", "payout", rid, actor=user)

def _can_decide(actor, req):
    from ..security import has_perm
    if not has_perm("payouts.manage", actor): raise PayoutError("You do not have permission to manage payouts.")
    if req["instructor_id"] == actor["id"] and not actor["is_owner"]: raise PayoutError("You cannot decide your own withdrawal request.")

def mark_paid(actor, rid, fs, reference="", note=""):
    """Completes a request. A receipt (JPG/PNG/PDF) proving the transfer is mandatory."""
    r = q1("SELECT * FROM payout_requests WHERE id=?", (rid,))
    if not r: raise PayoutError("Request not found.")
    _can_decide(actor, r)
    if r["status"] != "requested": raise PayoutError("This request has already been processed.")
    if not fs or not fs.filename: raise PayoutError("Upload the transfer receipt before marking this payout as paid.")
    try: stored, _e, mime, _s = uploads.save_private(fs, ("jpg", "png", "pdf"), 8 * 1024 * 1024)
    except uploads.UploadError as e: raise PayoutError(str(e))
    db = get_db(); db.execute("BEGIN IMMEDIATE")
    try:
        cur = db.execute("UPDATE payout_requests SET status='paid', decided_by=?, decided_at=?, receipt_file=?, receipt_name=?, receipt_mime=?, transfer_reference=?, admin_note=? WHERE id=? AND status='requested'",
                         (actor["id"], now(), stored, (fs.filename or "")[:120], mime, (reference or "")[:80], (note or "")[:1000], rid))
        if cur.rowcount != 1: raise PayoutError("This request has already been processed.")
        db.execute("INSERT INTO audit_logs(actor_id,actor_label,action,entity,entity_id,detail) VALUES (?,?,?,?,?,?)", (actor["id"], f"{actor['full_name']} <{actor['email']}>", "payout.paid", "payout", str(rid), f"{naira(r['amount_kobo'])} ref {reference}"[:300]))
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK"); uploads_cleanup(stored); raise
    notify(r["instructor_id"], ctf("notif.payout_paid_title"), ctf("notif.payout_paid_body", amount=naira(r["amount_kobo"])), "/staff/earnings", "payout", email=True)

def reject(actor, rid, reason):
    r = q1("SELECT * FROM payout_requests WHERE id=?", (rid,))
    if not r: raise PayoutError("Request not found.")
    _can_decide(actor, r)
    if not (reason or "").strip(): raise PayoutError("Give the tutor a reason.")
    cur = get_db().execute("UPDATE payout_requests SET status='rejected', decided_by=?, decided_at=?, reject_reason=? WHERE id=? AND status='requested'", (actor["id"], now(), reason.strip()[:1000], rid))
    if cur.rowcount != 1: raise PayoutError("This request has already been processed.")
    audit.log("payout.rejected", "payout", rid, reason[:200], actor=actor)
    notify(r["instructor_id"], ctf("notif.payout_rejected_title"), ctf("notif.payout_rejected_body", reason=reason.strip()[:300]), "/staff/earnings", "payout", email=True)

def uploads_cleanup(name):
    import os
    from flask import current_app
    try: os.remove(os.path.join(current_app.config["PRIVATE_DIR"], name))
    except OSError: pass


def by_division(uid=None):
    """Money per division: {division: {gross, earned, sales}} (net of refunds), for one tutor or for everyone. Faith series count as 'faith'."""
    out = {d: dict(gross=0, earned=0, sales=0) for d in DIVISIONS}
    where, args = ("WHERE e.instructor_id=?", (uid,)) if uid else ("", ())
    for r in q(f"""SELECT COALESCE(c.division, 'faith') AS d, SUM(CASE e.kind WHEN 'sale' THEN e.gross_kobo ELSE -e.gross_kobo END) AS gross, SUM(e.amount_kobo) AS earned,
                   SUM(CASE e.kind WHEN 'sale' THEN 1 ELSE 0 END) AS sales FROM instructor_earnings e LEFT JOIN courses c ON c.id=e.course_id {where} GROUP BY COALESCE(c.division, 'faith')""", args):
        if r["d"] in out: out[r["d"]] = dict(gross=r["gross"] or 0, earned=r["earned"] or 0, sales=r["sales"] or 0)
    return out
