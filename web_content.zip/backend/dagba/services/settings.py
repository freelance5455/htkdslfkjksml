import os
from ..db import q, q1, ex

DEFAULTS = {
    "site.name": "Dagba Digital Academy",
    "site.tagline": "Simplifying Knowledge. Building Excellence. Equipping for the Real World.",
    "site.philosophy": "We make knowledge desirable.",
    "site.mission": "To simplify complex knowledge, make learning accessible and practical, and equip learners with academic knowledge and real-world skills.",
    "brand.primary": "#7236E6", "brand.dark": "#1b1230", "brand.accent": "#2563eb",
    "home.hero_title": "Learn what school teaches. Master what the world pays for.",
    "home.hero_text": "Dagba Digital Academy simplifies complex knowledge with clear, practical lessons for secondary school students and for anyone building real-world, income-generating skills.",
    "home.cta_primary": "Browse courses", "home.cta_secondary": "Create free account",
    "home.show_testimonials": "1", "hero.autoplay": "1", "hero.interval": "6",
    "contact.email": "", "contact.phone": "", "contact.whatsapp": "", "contact.address": "Nigeria",
    "social.facebook": "", "social.instagram": "", "social.youtube": "", "social.x": "",
    "seo.description": "Dagba Digital Academy: simplified academic courses from secondary school to university level and practical income skills courses, built for Nigerian learners.",
    "seo.og_image": "",
    "theme.rev": "0", "theme.mode_button": "1", "theme.mode_default": "light", "affiliate.enabled": "1", "affiliate.percent": "20", "affiliate.on_plans": "0", "affiliate.min_naira": "0", "affiliate.payout_enabled": "1", "affiliate.instructions": "Share your link. When someone signs up through it, every course they buy afterwards earns you a commission, even if they come back later using the normal website address. Withdrawals are paid by bank transfer after the academy reviews your request.",
    "video.max_mb": "500", "payout.instructor_percent": "40", "payout.tutor_referral_percent": "97", "payout.max_percent": "97", "payout.hold_days": "0", "tutor.attribution_days": "30", "tutor.applications_open": "1", "tutor.referrals_on": "1", "payout.min_naira": "0", "payout.enabled": "1", "payout.instructions": "Withdrawals are paid by bank transfer after the academy reviews your request. You will be notified here when it is paid, and the transfer receipt will be available to you.", "brand.logo": "", "brand.favicon": "", "cert.title_text": "CERTIFICATE OF COMPLETION", "cert.line1": "This certifies that", "cert.line2": "has successfully completed the course", "cert.completed": "Completed on",
    "home.show_what": "1", "home.show_featured": "1", "home.show_advanced": "1", "home.show_income": "1", "home.show_professional": "1", "home.show_steps": "1", "home.show_why": "1", "home.show_plans": "1", "home.show_nuggets": "1", "home.show_articles": "1", "home.show_faq": "1", "home.show_newsletter": "1", "home.show_marquee": "1", "home.show_numbers": "1", "home.show_faith": "1", "faith.audio_max_mb": "200",
    "cert.signatory": "Director, Dagba Digital Academy", "cert.min_quiz_pass": "1",
    "bank.enabled": "1", "bank.name": "", "bank.account_name": "", "bank.account_number": "",
    "bank.instructions": "Transfer the exact amount shown to the account below using your banking app, then upload your receipt on this page.",
    "bank.reference_instructions": "Put the transaction reference in the transfer narration/remark if your bank app allows it.",
    "bank.support_contact": "", "bank.receipt_required": "1", "bank.file_types": "jpg,jpeg,png,pdf",
    "bank.max_mb": "5", "bank.allow_resubmit": "1",
    "prelaunch.enabled": "0", "prelaunch.launch_at": "2027-01-04T00:00", "prelaunch.utc_offset": "+01:00", "prelaunch.show_countdown": "1", "prelaunch.signup_enabled": "1", "prelaunch.register_enabled": "1", "prelaunch.bypass_roles": "instructor",
    "prelaunch.badge": "Launching 4 January 2027", "prelaunch.title": "We are launching soon", "prelaunch.message": "Dagba Digital Academy is putting the finishing touches on simplified academic courses and practical income skills. Register now to be first through the door on launch day.",
    "prelaunch.countdown_label": "Doors open in", "prelaunch.live_text": "We are live! Taking you in...", "prelaunch.signup_title": "Get early access", "prelaunch.signup_text": "Leave your email and we will tell you the moment we open.", "prelaunch.signup_button": "Notify me",
    "prelaunch.success_text": "You are on the list. We will email you at launch.", "prelaunch.account_text": "Prefer to get set up now? Create your free account today and your learning space will be ready on launch day.", "prelaunch.account_button": "Create my account",
    "prelaunch.registered_text": "Thanks for registering, {name}! Your account is ready. Courses and lessons open to students on launch day.", "prelaunch.social_title": "Follow us for updates", "prelaunch.footer": "Simplifying Knowledge. Building Excellence.",
    "pay.paystack.enabled": "0", "pay.paystack.public_key": "", "pay.paystack.secret_key": "",
    "pay.flutterwave.enabled": "0", "pay.flutterwave.public_key": "", "pay.flutterwave.secret_key": "", "pay.flutterwave.webhook_hash": "",
}
ENV_OVERRIDES = {
    "pay.paystack.secret_key": "PAYSTACK_SECRET_KEY",
    "pay.flutterwave.secret_key": "FLUTTERWAVE_SECRET_KEY",
    "pay.flutterwave.webhook_hash": "FLUTTERWAVE_WEBHOOK_HASH",
}

def _rows():
    from flask import g, has_app_context
    if has_app_context():
        if "_sc" not in g: g._sc = {r["key"]: r["value"] for r in q("SELECT key,value FROM settings")}
        return g._sc
    return {r["key"]: r["value"] for r in q("SELECT key,value FROM settings")}

def clear_cache():
    from flask import g, has_app_context
    if has_app_context(): g.pop("_sc", None)

def get(key, default=None):
    env = ENV_OVERRIDES.get(key)
    if env and os.environ.get(env): return os.environ[env]
    v = _rows().get(key)
    if v is not None: return v
    return DEFAULTS.get(key, default)

def flag(key): return get(key, "0") in ("1", "true", "on", "yes")

def put(key, value):
    ex("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value)); clear_cache()

def all_public():
    d = dict(DEFAULTS); d.update(_rows())
    return {k: v for k, v in d.items() if not k.startswith(("pay.", "bank.account", "c.")) and "secret" not in k}
