"""Mobile API support: token sessions, signed media links and the content version.
Nothing here changes existing website behaviour. Access tokens are short-lived signed values; refresh tokens are random, rotated on
every use and stored only as SHA-256 hashes, so a database leak does not leak usable tokens."""
import hashlib, secrets, datetime as dt
from flask import current_app
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from ..db import q1, ex, val
from ..util import now

ACCESS_TTL = 15 * 60                  # seconds
REFRESH_DAYS = 60
MEDIA_TTL = 60 * 60

def _ser(salt): return URLSafeTimedSerializer(current_app.config["SECRET_KEY"], salt=salt)
def _h(s): return hashlib.sha256(s.encode()).hexdigest()
def _exp(days): return (dt.datetime.now(dt.timezone.utc).replace(tzinfo=None) + dt.timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")

def _tokens(sid, uid, refresh):
    return dict(access_token=_ser("dagba-api-access").dumps({"sid": sid, "uid": uid}), refresh_token=refresh,
                token_type="Bearer", expires_in=ACCESS_TTL)

def create_session(user, device=None):
    d = device or {}; refresh = secrets.token_urlsafe(48)
    sid = ex("INSERT INTO api_sessions(user_id,refresh_hash,device_name,platform,app_version,last_used_at,expires_at) VALUES (?,?,?,?,?,?,?)",
             (user["id"], _h(refresh), str(d.get("device_name", ""))[:80], str(d.get("platform", ""))[:20], str(d.get("app_version", ""))[:20], now(), _exp(REFRESH_DAYS)))
    return _tokens(sid, user["id"], refresh)

def authenticate(token):
    """(user_row, session_id) for a valid access token of a live session and an active user, else (None, None)."""
    try: p = _ser("dagba-api-access").loads(token, max_age=ACCESS_TTL)
    except (BadSignature, SignatureExpired): return None, None
    s = q1("SELECT id, user_id, expires_at, revoked_at FROM api_sessions WHERE id=?", (p.get("sid"),))
    if not s or s["revoked_at"] or s["user_id"] != p.get("uid") or s["expires_at"] < now(): return None, None
    u = q1("SELECT * FROM users WHERE id=?", (s["user_id"],))
    return (u, s["id"]) if u and u["is_active"] else (None, None)

def refresh(refresh_token):
    """Rotate a refresh token. Returns (tokens, None) or (None, reason). Replaying an already-rotated token revokes the whole session."""
    hh = _h(refresh_token or "")
    s = q1("SELECT * FROM api_sessions WHERE refresh_hash=?", (hh,))
    if not s:
        old = q1("SELECT id FROM api_sessions WHERE prev_refresh_hash=?", (hh,))
        if old: ex("UPDATE api_sessions SET revoked_at=? WHERE id=? AND revoked_at IS NULL", (now(), old["id"]))
        return None, "invalid"
    if s["revoked_at"] or s["expires_at"] < now(): return None, "expired"
    u = q1("SELECT * FROM users WHERE id=?", (s["user_id"],))
    if not u or not u["is_active"]: return None, "inactive"
    new = secrets.token_urlsafe(48)
    ex("UPDATE api_sessions SET refresh_hash=?, prev_refresh_hash=?, last_used_at=?, expires_at=? WHERE id=?", (_h(new), hh, now(), _exp(REFRESH_DAYS), s["id"]))
    return _tokens(s["id"], u["id"], new), None

def revoke(sid): ex("UPDATE api_sessions SET revoked_at=? WHERE id=? AND revoked_at IS NULL", (now(), sid)); ex("DELETE FROM device_tokens WHERE session_id=?", (sid,))
def revoke_all(uid): ex("UPDATE api_sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL", (now(), uid)); ex("DELETE FROM device_tokens WHERE user_id=?", (uid,))

# Signed, short-lived, user- and lesson-bound links so a native <video>/<a> (which cannot send an Authorization header) can fetch a file
# the API has already confirmed this learner may open. The file route re-checks nothing it should not trust: it only honours a valid signature.
def sign_media(kind, lesson_id, uid): return _ser("dagba-api-media").dumps({"k": kind, "l": lesson_id, "u": uid})
def verify_media(token, kind, lesson_id):
    try: p = _ser("dagba-api-media").loads(token or "", max_age=MEDIA_TTL)
    except (BadSignature, SignatureExpired): return None
    return p["u"] if p.get("k") == kind and p.get("l") == lesson_id else None

def content_version(): return val("SELECT version FROM content_version WHERE id=1", default=1)

def json_error(status, message, code=None):
    from flask import jsonify
    r = jsonify(ok=False, error=dict(code=code or {400: "bad_request", 401: "unauthorized", 403: "forbidden", 404: "not_found", 413: "too_large", 429: "rate_limited"}.get(status, "error"), message=message))
    r.status_code = status; r.headers["Cache-Control"] = "no-store"; return r
