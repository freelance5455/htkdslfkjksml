"""Scheduled lesson/module release. Dates are stored in UTC and entered/shown in the site time zone (setting site.utc_offset, falling back to the
pre-launch offset, default West Africa Time). A lesson opens at the LATER of its own date and its module's date; staff previewing a course are never
blocked. Enforcement lives in the student routes (lesson page, video, resource, progress) so a direct URL cannot get around it."""
import re
from datetime import datetime, timedelta, timezone
from ..db import q, q1
from ..util import now
from . import settings as S

def _tz():
    off = S.get("site.utc_offset") or S.get("prelaunch.utc_offset") or "+01:00"
    m = re.fullmatch(r"([+-])(\d{2}):(\d{2})", off) or re.fullmatch(r"([+-])(\d{2}):(\d{2})", "+01:00")
    mins = int(m[2]) * 60 + int(m[3]); return timezone(timedelta(minutes=-mins if m[1] == "-" else mins)), off

def to_utc(text):
    """'YYYY-MM-DDTHH:MM' (site time) -> 'YYYY-MM-DD HH:MM:SS' UTC; '' -> None; anything else raises ValueError."""
    text = (text or "").strip()
    if not text: return None
    try: d = datetime.strptime(text.replace(" ", "T")[:16], "%Y-%m-%dT%H:%M")
    except ValueError: raise ValueError("Enter the release date as a valid date and time.")
    return d.replace(tzinfo=_tz()[0]).astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

def to_local(utc):
    """UTC string -> 'YYYY-MM-DDTHH:MM' in site time (for a datetime-local input), '' when unset."""
    if not utc: return ""
    return datetime.strptime(utc[:19], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc).astimezone(_tz()[0]).strftime("%Y-%m-%dT%H:%M")

def fmt(utc):
    """Human text for a UTC release time, in site time: '12 Jan 2027, 09:00'."""
    if not utc: return ""
    d = datetime.strptime(utc[:19], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc).astimezone(_tz()[0])
    return f"{d.day} {d.strftime('%b %Y, %H:%M')}"

def effective(lesson_release, module_release):
    vals = [v for v in (lesson_release, module_release) if v]
    return max(vals) if vals else None

def opens_at(row, at=None):
    """UTC time this lesson row opens if that is still in the future, else None. `row` needs release_at and module_release_at (ordered_lessons gives both)."""
    e = effective(row["release_at"], row["module_release_at"] if "module_release_at" in row.keys() else None)
    return e if e and e > (at or now()) else None

def lesson_opens_at(lesson_id):
    r = q1("SELECT l.release_at, m.release_at AS module_release_at FROM lessons l LEFT JOIN modules m ON m.id=l.module_id WHERE l.id=?", (lesson_id,))
    return opens_at(r) if r else None

# SQL for "this lesson (alias l, module alias m) is open now": use with two copies of now()
OPEN_SQL = "(l.release_at IS NULL OR l.release_at<=?) AND (m.release_at IS NULL OR m.release_at<=?)"

def upcoming(course_ids, limit=5):
    """Scheduled lessons not yet open in these courses, soonest first (for 'coming up' lists)."""
    if not course_ids: return []
    t = now(); ph = ",".join("?" * len(course_ids))
    rows = q(f"""SELECT l.id, l.title, c.title AS course, c.slug, MAX(COALESCE(l.release_at,''), COALESCE(m.release_at,'')) AS opens FROM lessons l LEFT JOIN modules m ON m.id=l.module_id
                 JOIN courses c ON c.id=l.course_id WHERE l.course_id IN ({ph}) AND MAX(COALESCE(l.release_at,''), COALESCE(m.release_at,''))>? ORDER BY opens, l.id LIMIT ?""", (*course_ids, t, limit))
    return [dict(r, when=fmt(r["opens"])) for r in rows]
