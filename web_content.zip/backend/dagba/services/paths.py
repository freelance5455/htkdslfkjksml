"""Learning paths: Faith, Basic, Advanced, Professional and Income Skills are separate content-management contexts.

A context is chosen with ``?ctx=<key>`` on staff list/edit pages (the sidebar always supplies it). Every query for a
context-aware resource is filtered *in SQL* here, so a record from another path can neither be listed, opened, edited,
deleted nor attached to. Nothing in this module changes stored data: the existing ``division`` / ``academic_level`` /
``level`` columns already say which path a record belongs to (academic courses saved before the levels existed count as Basic).
"""

ACADEMIC = ("basic", "advanced")                       # academic levels; Professional Development is its own division (below)
PATHS = {
    "faith":        dict(key="faith", name="Faith", icon="faith"),
    "basic":        dict(key="basic", name="Basic", icon="academics", sub="Secondary School Education"),
    "advanced":     dict(key="advanced", name="Advanced", icon="academics", sub="University-Level Education"),
    "professional": dict(key="professional", name="Professional", icon="academics", sub="Professional Examinations and Career Advancement"),
    "income":       dict(key="income", name="Income Skills", icon="income"),
}

# resource name (staff.RES key) -> how it is tied to a path
COURSE_CHILDREN = {"modules", "lessons", "quizzes", "assignments", "announcements"}      # have course_id
FAITH_RESOURCES = {"faith-topics", "faith-series"}
CONTEXT_RESOURCES = {"categories", "courses", "questions"} | COURSE_CHILDREN | FAITH_RESOURCES

def valid(ctx):
    return ctx if ctx in PATHS else None

def name(ctx):
    return PATHS[ctx]["name"] if ctx in PATHS else ""

def is_academic(ctx): return ctx in ACADEMIC       # Professional Development is NOT academic

def course_clause(ctx, a=""):
    """SQL (and args) selecting the courses of one path. `a` is an optional table alias."""
    p = a + "." if a else ""
    if ctx in ACADEMIC: return f"({p}division='academic' AND COALESCE({p}academic_level,'basic')=?)", (ctx,)
    if ctx in ("income", "professional"): return f"{p}division='{ctx}'", ()
    return "0=1", ()                                   # Faith has no academic/income/professional courses

def category_clause(ctx, a=""):
    p = a + "." if a else ""
    if ctx in ACADEMIC: return f"({p}division='academic' AND {p}level=?)", (ctx,)
    if ctx in ("income", "professional"): return f"{p}division='{ctx}'", ()
    return "0=1", ()

def resource_clause(rname, ctx):
    """(sql, args) restricting a staff resource to a path, or None when the resource is not path-specific or no path is chosen."""
    if not ctx or rname not in CONTEXT_RESOURCES: return None
    if rname in FAITH_RESOURCES: return ("1=1", ()) if ctx == "faith" else ("0=1", ())
    if rname == "categories": return category_clause(ctx)
    if rname == "courses": return course_clause(ctx)
    cs, ca = course_clause(ctx, "c")
    if cs == "0=1": return "0=1", ()                   # Faith has none of these
    if rname == "questions": return f"quiz_id IN (SELECT z.id FROM quizzes z JOIN courses c ON c.id=z.course_id WHERE {cs})", ca
    return f"course_id IN (SELECT c.id FROM courses c WHERE {cs})", ca

def course_in_path(course_id, ctx):
    """True when the course exists and belongs to the path (used to stop cross-path attachments)."""
    from ..db import val
    cs, ca = course_clause(ctx, "c")
    return bool(course_id) and bool(val(f"SELECT 1 FROM courses c WHERE c.id=? AND {cs}", (course_id,) + ca))

def path_of_course(c):
    """The path key of a course row."""
    if c["division"] == "professional": return "professional"
    if c["division"] != "academic": return "income"
    return c["academic_level"] or "basic"
