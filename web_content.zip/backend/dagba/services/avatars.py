"""One optional profile picture per account (students, tutors, writers, admins).
Uploads are validated by file signature + extension (JPG/PNG/WebP), decoded and re-encoded by Pillow (this strips any hidden
payload and EXIF data), turned upright, centre-cropped to a square and stored as a small WebP (JPEG if WebP is unavailable).
No picture = initials on a coloured circle (templates/_avatar.html)."""
import io, os, secrets
from PIL import Image, ImageOps
from flask import current_app
from ..db import q1, ex, val
from . import uploads, audit

SIZE = 256
MAX_BYTES = 5 * 1024 * 1024

def _ext():
    try: Image.new("RGB", (4, 4)).save(io.BytesIO(), "WEBP"); return "webp"
    except Exception: return "jpg"

def save(user_id, fs, actor=None):
    """Replace the user's picture. Returns the stored file name or raises uploads.UploadError with a friendly message."""
    data, ext, _ = uploads._validate(fs, ("jpg", "png", "webp"), MAX_BYTES)
    try:
        Image.MAX_IMAGE_PIXELS = 60_000_000
        im = Image.open(io.BytesIO(data)); im.load(); im = ImageOps.exif_transpose(im)
        if im.mode in ("RGBA", "LA", "P"):
            im = im.convert("RGBA"); bg = Image.new("RGB", im.size, (255, 255, 255)); bg.paste(im, mask=im.split()[-1]); im = bg
        elif im.mode != "RGB": im = im.convert("RGB")
        im = ImageOps.fit(im, (SIZE, SIZE), Image.LANCZOS, centering=(0.5, 0.4))     # square, slightly favouring the top (faces)
        e = _ext(); name = f"av-{secrets.token_hex(10)}.{e}"; d = current_app.config["PUBLIC_DIR"]; os.makedirs(d, exist_ok=True)
        if e == "webp": im.save(os.path.join(d, name), "WEBP", quality=82, method=4)
        else: im.save(os.path.join(d, name), "JPEG", quality=84, optimize=True)
    except uploads.UploadError: raise
    except Exception:
        raise uploads.UploadError("This picture could not be processed. It may be damaged or incomplete. Please try another photo, or save it again as JPG or PNG.")
    old = val("SELECT avatar FROM users WHERE id=?", (user_id,))
    ex("UPDATE users SET avatar=? WHERE id=?", (name, user_id))
    _delete(old)
    audit.log("profile.picture_changed", "user", user_id, "", actor=actor)
    return name

def remove(user_id, actor=None):
    old = val("SELECT avatar FROM users WHERE id=?", (user_id,))
    if not old: return False
    ex("UPDATE users SET avatar=NULL WHERE id=?", (user_id,)); _delete(old)
    audit.log("profile.picture_removed", "user", user_id, "", actor=actor); return True

def _delete(name):
    if not name or not name.startswith("av-") or os.path.basename(name) != name: return
    try: os.remove(os.path.join(current_app.config["PUBLIC_DIR"], name))
    except OSError: pass

def initials(full_name):
    parts = [p for p in (full_name or "").replace("-", " ").split() if p[:1].isalnum()]
    if not parts: return "?"
    return (parts[0][0] + (parts[-1][0] if len(parts) > 1 else "")).upper()
