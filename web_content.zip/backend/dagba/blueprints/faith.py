"""Faith & Spiritual Growth: public pages and learner actions (progress, saved lessons, media streaming)."""
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, jsonify, send_from_directory, current_app
from ..db import q, q1, ex, val
from ..util import now
from ..security import login_required, has_perm
from ..services import faith as F
from .public import paginate, page_no

bp = Blueprint("faith", __name__, url_prefix="/faith")
LIVE = "i.status='published'"

def _manage(): return has_perm("faith.manage")
def _uid(): return g.user["id"] if g.get("user") else None

def _filters(extra=None):
    """Shared search/filter for the lesson lists (published lessons only)."""
    where, args = [LIVE], []
    for k, col in (("kind", "i.kind"),):
        v = request.args.get(k, "")
        if v in F.KINDS: where.append(f"{col}=?"); args.append(v)
    t = request.args.get("topic", "")
    if t: where.append("t.slug=?"); args.append(t)
    s = request.args.get("q", "").strip()[:100]
    if s: where.append("(i.title LIKE ? OR i.summary LIKE ? OR i.scripture LIKE ? OR i.speaker LIKE ?)"); args += [f"%{s}%"] * 4
    for w, a in (extra or []): where.append(w); args.append(a)
    return where, args

def _list(where, args, order="i.featured DESC, COALESCE(i.published_at,i.created_at) DESC"):
    sql = F.ITEM_SELECT + " WHERE " + " AND ".join(where) + " ORDER BY " + order
    return paginate(sql, args, page_no(), 12)

def _ctx(**kw):
    uid = _uid()
    owned = F.owned_series_ids(uid); owned_t = F.owned_topic_ids(uid); manage = _manage()
    return dict(KINDS=F.KINDS, done=F.done_ids(uid), saved=F.saved_ids(uid), owned=owned, owned_topics=owned_t, state=lambda i: F.item_state(i, uid, owned, manage, owned_t), **kw)

@bp.route("", strict_slashes=False)
def index():
    uid = _uid()
    latest = q(F.ITEM_SELECT + " WHERE " + LIVE + " ORDER BY COALESCE(i.published_at,i.created_at) DESC LIMIT 6")
    featured = q("""SELECT s.*, t.name AS topic, t.slug AS topic_slug, (SELECT full_name FROM users WHERE id=s.instructor_id) AS tutor, (SELECT COUNT(*) FROM faith_items i WHERE i.series_id=s.id AND i.status='published') AS n
                    FROM faith_series s JOIN faith_topics t ON t.id=s.topic_id WHERE s.status='published' AND t.active=1
                    AND EXISTS (SELECT 1 FROM faith_items i WHERE i.series_id=s.id AND i.status='published') ORDER BY s.featured DESC, s.position, s.created_at DESC LIMIT 3""")
    return render_template("faith/index.html", topics=F.topics(), latest=latest, featured=featured, counts=F.kind_counts(), has_content=F.has_content(),
                           resume=F.continue_items(uid, 3), teachers=F.teachers(), **_ctx())

@bp.route("/browse")
def browse():
    where, args = _filters(); rows, pg = _list(where, args)
    return render_template("faith/browse.html", items=rows, pg=pg, topics=F.topics(with_counts=False), counts=F.kind_counts(), **_ctx())

@bp.route("/topic/<slug>")
def topic(slug):
    t = F.topic_by_slug(slug) or abort(404)
    where, args = _filters([("i.topic_id=?", t["id"])]); rows, pg = _list(where, args)
    series = q("""SELECT s.*, (SELECT full_name FROM users WHERE id=s.instructor_id) AS tutor, (SELECT COUNT(*) FROM faith_items i WHERE i.series_id=s.id AND i.status='published') AS n FROM faith_series s
                  WHERE s.topic_id=? AND s.status='published' AND EXISTS (SELECT 1 FROM faith_items i WHERE i.series_id=s.id AND i.status='published')
                  ORDER BY s.featured DESC, s.position, s.title""", (t["id"],))
    return render_template("faith/topic.html", t=t, topic_access=_manage() or F.topic_entitled(_uid(), t["id"]), series=series, items=rows, pg=pg, topics=F.topics(with_counts=False), **_ctx())

@bp.route("/teacher/<int:uid>")
def teacher(uid):
    t = F.teacher(uid) or abort(404)
    return render_template("faith/teacher.html", t=t, series=F.teacher_series(uid), **_ctx())

@bp.route("/series/<slug>")
def series(slug):
    s = q1("SELECT s.*, t.name AS topic, t.slug AS topic_slug, u.full_name AS tutor, u.bio AS tutor_bio FROM faith_series s JOIN faith_topics t ON t.id=s.topic_id LEFT JOIN users u ON u.id=s.instructor_id WHERE s.slug=?", (slug,)) or abort(404)
    if s["status"] != "published" and not _manage(): abort(404)
    items = q(F.ITEM_SELECT + " WHERE i.series_id=? AND " + ("1=1" if _manage() else LIVE) + " ORDER BY i.position, i.id", (s["id"],))
    uid = _uid(); first = next((i for i in items if i["status"] == "published"), None)
    d = F.done_ids(uid); nxt = next((i for i in items if i["status"] == "published" and i["id"] not in d), first)
    return render_template("faith/series.html", s=s, items=items, prog=F.series_progress(uid, s["id"]), start=nxt, paid=s["price_kobo"] > 0,
                           topic=q1("SELECT * FROM faith_topics WHERE id=?", (s["topic_id"],)), has_access=_manage() or (s["price_kobo"] <= 0 and not q1("SELECT 1 FROM faith_topics WHERE id=? AND price_kobo>0", (s["topic_id"],))) or F.series_entitled(uid, s["id"]) or F.topic_entitled(uid, s["topic_id"]), **_ctx())

@bp.route("/lesson/<slug>")
def lesson(slug):
    i = F.item_by_slug(slug) or abort(404)
    if i["status"] != "published" and not _manage(): abort(404)         # drafts/archived: faith managers only (a members-only lesson still shows its page, with a sign-in prompt)
    uid = _uid(); lock = F.item_state(i, uid, None, _manage()) if i["status"] == "published" else None; gated = lock if lock != "open" else None   # None | 'signin' | 'buy'
    sr = q1("SELECT s.*, u.full_name AS tutor FROM faith_series s LEFT JOIN users u ON u.id=s.instructor_id WHERE s.id=?", (i["series_id"],)) if i["series_id"] else None
    prog = q1("SELECT * FROM faith_progress WHERE user_id=? AND item_id=?", (uid, i["id"])) if uid and not gated else None
    if uid and i["status"] == "published" and not gated and not prog:
        ex("INSERT OR IGNORE INTO faith_progress(user_id,item_id,updated_at) VALUES (?,?,?)", (uid, i["id"], now()))
    elif prog and i["status"] == "published" and not gated:
        ex("UPDATE faith_progress SET updated_at=? WHERE user_id=? AND item_id=?", (now(), uid, i["id"]))
    prev, nxt = F.neighbours(i)
    from ..util import embed_url
    return render_template("faith/lesson.html", i=i, gated=gated, prog=prog, prev=prev, nxt=nxt, related=F.related(i), embed=embed_url(i["video_url"]) if i["video_url"] else (None, ""),
                           sr=sr, topic=q1("SELECT * FROM faith_topics WHERE id=?", (i["topic_id"],)), is_done=bool(prog and prog["completed_at"]), is_saved=i["id"] in F.saved_ids(uid), preview=i["status"] != "published", **_ctx())

def _visible_item(iid):
    i = F.item_by_id(iid) or abort(404)
    if not F.can_view(g.get("user"), i, _manage()) or i["status"] != "published": abort(403)
    return i

@bp.route("/lesson/<int:iid>/complete", methods=["POST"])
@login_required
def complete(iid):
    i = _visible_item(iid); undo = request.form.get("undo") == "1"
    if undo: ex("UPDATE faith_progress SET completed_at=NULL, updated_at=? WHERE user_id=? AND item_id=?", (now(), g.user["id"], iid))
    else:
        ex("""INSERT INTO faith_progress(user_id,item_id,completed_at,updated_at) VALUES (?,?,?,?)
              ON CONFLICT(user_id,item_id) DO UPDATE SET completed_at=COALESCE(faith_progress.completed_at, excluded.completed_at), updated_at=excluded.updated_at""", (g.user["id"], iid, now(), now()))
    if request.headers.get("X-Requested-With") == "fetch": return jsonify(ok=True, done=not undo)
    if not undo:
        _, nxt = F.neighbours(i)
        if nxt: flash("Well done. On to the next lesson.", "success"); return redirect(url_for("faith.lesson", slug=nxt["slug"]))
        if i["series_id"]: flash("You have finished this series. Well done.", "success"); return redirect(url_for("faith.series", slug=i["series_slug"]))
        flash("Marked as complete.", "success")
    return redirect(url_for("faith.lesson", slug=i["slug"]))

@bp.route("/lesson/<int:iid>/save", methods=["POST"])
@login_required
def save(iid):
    i = F.item_by_id(iid) or abort(404)
    if i["status"] != "published": abort(404)
    if val("SELECT 1 FROM faith_saved WHERE user_id=? AND item_id=?", (g.user["id"], iid)): ex("DELETE FROM faith_saved WHERE user_id=? AND item_id=?", (g.user["id"], iid)); on = False
    else: ex("INSERT OR IGNORE INTO faith_saved(user_id,item_id) VALUES (?,?)", (g.user["id"], iid)); on = True
    if request.headers.get("X-Requested-With") == "fetch": return jsonify(ok=True, saved=on)
    flash("Saved to your list." if on else "Removed from your saved list.", "success")
    return redirect(url_for("faith.lesson", slug=i["slug"]))

@bp.route("/lesson/<int:iid>/progress", methods=["POST"])
@login_required
def position(iid):
    _visible_item(iid)
    pos = max(0, min(request.form.get("position", 0, type=int), 86400))
    ex("""INSERT INTO faith_progress(user_id,item_id,position_seconds,updated_at) VALUES (?,?,?,?)
          ON CONFLICT(user_id,item_id) DO UPDATE SET position_seconds=excluded.position_seconds, updated_at=excluded.updated_at""", (g.user["id"], iid, pos, now()))
    return jsonify(ok=True)

def _media_row(iid):
    i = F.item_by_id(iid) or abort(404)
    if i["status"] != "published":
        if not _manage(): abort(404)
    elif not F.can_view(g.get("user"), i, _manage()): abort(403)
    return i

@bp.route("/media/<int:iid>/<kind>")
def media(iid, kind):
    """Stream an uploaded lesson video or audio file with Range support (seeking and resume)."""
    if kind not in ("video", "audio"): abort(404)
    i = _media_row(iid); name = i["video_file"] if kind == "video" else i["audio_file"]
    if not name: abort(404)
    ext = name.rsplit(".", 1)[-1].lower()
    mime = ("video/webm" if ext == "webm" else "video/mp4") if kind == "video" else F.AUDIO_MIME.get(ext, "audio/mpeg")
    resp = send_from_directory(current_app.config["PRIVATE_DIR"], name, mimetype=mime, conditional=True, max_age=0)
    resp.headers["Cache-Control"] = "private, max-age=3600"; resp.headers["Content-Disposition"] = "inline"
    return resp

@bp.route("/resource/<int:iid>")
def resource(iid):
    i = _media_row(iid)
    if not i["resource_file"] or not (i["downloadable"] or _manage()): abort(404)
    pdf = i["resource_file"].endswith(".pdf")
    return send_from_directory(current_app.config["PRIVATE_DIR"], i["resource_file"], as_attachment=not pdf or request.args.get("dl") == "1", download_name=i["resource_name"] or i["resource_file"])

@bp.route("/my")
@login_required
def my():
    uid = g.user["id"]
    saved = q(F.ITEM_SELECT + " JOIN faith_saved fs ON fs.item_id=i.id AND fs.user_id=? WHERE " + LIVE + " ORDER BY fs.created_at DESC", (uid,))
    finished = q(F.ITEM_SELECT + " JOIN faith_progress p ON p.item_id=i.id AND p.user_id=? WHERE " + LIVE + " AND p.completed_at IS NOT NULL ORDER BY p.completed_at DESC LIMIT 12", (uid,))
    by_topic = []
    for t in F.topics():
        done = val("SELECT COUNT(*) FROM faith_progress p JOIN faith_items i ON i.id=p.item_id WHERE p.user_id=? AND i.topic_id=? AND i.status='published' AND p.completed_at IS NOT NULL", (uid, t["id"]), 0)
        if t["n"]: by_topic.append(dict(t=t, done=done, percent=int(done * 100 / t["n"])))
    return render_template("faith/my.html", mine=F.purchased_series(uid), mine_topics=F.purchased_topics(uid), resume=F.continue_items(uid, 6), saved_items=saved, finished=finished, by_topic=by_topic,
                           total_done=val("SELECT COUNT(*) FROM faith_progress p JOIN faith_items i ON i.id=p.item_id WHERE p.user_id=? AND i.status='published' AND p.completed_at IS NOT NULL", (uid,), 0), **_ctx())
