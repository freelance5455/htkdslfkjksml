"""Admin > Appearance > Homepage hero: add / edit / delete slides, upload or replace pictures, enable or disable, reorder,
choose the first slide and set automatic rotation. Everything is stored in the database (see services/hero.py)."""
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from ..db import q1, ex, val
from ..security import perm_required
from ..util import now
from ..services import hero as H, uploads, audit

bp = Blueprint("heroadmin", __name__, url_prefix="/staff/hero")
PERM = "settings.manage"

def _row(sid): return q1("SELECT * FROM hero_slides WHERE id=?", (sid,)) or abort(404)

@bp.route("/")
@perm_required(PERM)
def index():
    rows = H.all_slides()
    thumbs = {r["id"]: H.image_urls(r)[0] or url_for("static", filename=f"img/hero/{r['art'] if r['art'] in H.ART else 'academic'}.svg") for r in rows}
    return render_template("staff/hero.html", slides=rows, thumbs=thumbs, autoplay=H.autoplay(), interval=H.interval(), H=H, n_active=sum(1 for r in rows if r["active"]))

@bp.route("/settings", methods=["POST"])
@perm_required(PERM)
def settings():
    err = H.save_settings(request.form)
    if err: flash(err, "error")
    else: audit.log("hero.settings", "settings", 0, f"autoplay={'on' if H.autoplay() else 'off'}, {H.interval()}s"); flash("Rotation settings saved.", "success")
    return redirect(url_for("heroadmin.index"))

@bp.route("/new", methods=["GET", "POST"])
@bp.route("/<int:sid>/edit", methods=["GET", "POST"])
@perm_required(PERM)
def edit(sid=None):
    row = _row(sid) if sid else None
    if not row and val("SELECT COUNT(*) FROM hero_slides", default=0) >= H.MAX_SLIDES:
        flash(f"You can have at most {H.MAX_SLIDES} slides. Delete one to add another.", "error"); return redirect(url_for("heroadmin.index"))
    v = dict(row) if row else dict(active=1, art="academic", tone="purple", focus="center")
    if request.method == "POST":
        vals, errs = H.build(request.form, row); new_img = None; new_sizes = None
        fs = request.files.get("image")
        if fs and fs.filename:
            try: new_img, new_sizes = H.save_image(fs)
            except uploads.UploadError as e: errs.append(f"Image: {e}")
        if errs:
            if new_img: H.drop_image(new_img, new_sizes)
            for e in errs: flash(e, "error")
            v.update(vals)
        else:
            old = (row["image"], row["image_sizes"]) if row else (None, None)
            if new_img: vals["image"], vals["image_sizes"] = new_img, new_sizes
            elif row and request.form.get("remove_image"): vals["image"], vals["image_sizes"] = None, None
            vals["updated_at"] = now()
            if row:
                ex("UPDATE hero_slides SET " + ", ".join(f"{k}=?" for k in vals) + " WHERE id=?", tuple(vals.values()) + (sid,)); rid = sid
            else:
                vals["position"] = val("SELECT COALESCE(MAX(position),0)+1 FROM hero_slides", default=1)
                rid = ex("INSERT INTO hero_slides(" + ",".join(vals) + ") VALUES (" + ",".join("?" * len(vals)) + ")", tuple(vals.values()))
            if request.form.get("is_default") and vals["active"]: H.set_default(rid)
            elif row and row["is_default"] and (not request.form.get("is_default") or not vals["active"]):
                ex("UPDATE hero_slides SET is_default=0 WHERE id=?", (rid,))      # a hidden or un-ticked slide cannot stay the first slide
            if old[0] and old[0] != vals.get("image", old[0]): H.drop_image(old[0], old[1])
            audit.log(f"hero.{'update' if row else 'create'}", "hero_slides", rid, vals["headline"][:100])
            flash("Slide saved. It is already live on the homepage." if vals["active"] else "Slide saved. It is hidden until you enable it.", "success")
            return redirect(url_for("heroadmin.index"))
    return render_template("staff/hero_form.html", row=row, v=v, H=H, img=H.image_urls(row)[0] if row else None)

def _act(sid, fn, msg, log):
    row = _row(sid); fn(row); audit.log(log, "hero_slides", sid, row["headline"][:100]); flash(msg, "success"); return redirect(url_for("heroadmin.index"))

@bp.route("/<int:sid>/toggle", methods=["POST"])
@perm_required(PERM)
def toggle(sid):
    row = _row(sid); on = 0 if row["active"] else 1
    ex("UPDATE hero_slides SET active=?, is_default=CASE WHEN ?=0 THEN 0 ELSE is_default END, updated_at=? WHERE id=?", (on, on, now(), sid))
    audit.log("hero.enable" if on else "hero.disable", "hero_slides", sid, row["headline"][:100])
    flash("Slide is now shown on the homepage." if on else "Slide hidden from the homepage.", "success"); return redirect(url_for("heroadmin.index"))

@bp.route("/<int:sid>/default", methods=["POST"])
@perm_required(PERM)
def default(sid): return _act(sid, lambda r: H.set_default(sid), "This slide is now the first one visitors see.", "hero.default")

@bp.route("/<int:sid>/move", methods=["POST"])
@perm_required(PERM)
def move(sid):
    _row(sid); H.move(sid, "up" if request.form.get("dir") == "up" else "down"); audit.log("hero.reorder", "hero_slides", sid, ""); return redirect(url_for("heroadmin.index"))

@bp.route("/<int:sid>/delete", methods=["POST"])
@perm_required(PERM)
def delete(sid):
    row = _row(sid); ex("DELETE FROM hero_slides WHERE id=?", (sid,)); H.drop_image(row["image"], row["image_sizes"]); H.renumber()
    audit.log("hero.delete", "hero_slides", sid, row["headline"][:100]); flash("Slide deleted.", "info"); return redirect(url_for("heroadmin.index"))
