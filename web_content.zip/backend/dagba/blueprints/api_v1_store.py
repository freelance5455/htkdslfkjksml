"""Mobile API v1, part 3: in-app purchases (Google Play Billing / Apple In-App Purchase). The app sends the store's proof of purchase; the server
verifies it with the store, then grants access through the normal payment code. Bank transfer is deliberately NOT offered inside the apps."""
from flask import jsonify, g, current_app
from ..security import rate_limited
from ..services import store_billing as SB, store_verify as V, audit
from .api_v1 import bp, err, auth_required, body, private_json, public_cache
from ..services import mobile

@bp.route("/store/products")
def store_products():
    """Public catalogue of sellable items keyed by the product id that must exist in Play Console / App Store Connect. Prices come from the store SDK."""
    return public_cache(jsonify(ok=True, products=SB.catalogue(), content_version=mobile.content_version()), 30)

def _verify_and_fulfil(platform, payload):
    try: v = V.verify(platform, payload)
    except V.StoreNotConfigured as e:
        current_app.logger.warning("store billing unavailable: %s", e); return err(503, "In-app purchases are not available yet. Please try again later.", "store_unavailable")
    except V.StoreRejected as e: return err(400, "The store could not confirm this purchase.", "store_rejected")
    try: sp, new = SB.fulfil(g.user, platform, v)
    except SB.StoreError as e: return err(e.status, str(e), e.code)
    if new and platform == "google_play":
        V.google_acknowledge("subscription" if payload.get("kind") == "subscription" else "product", v["product_id"], str(payload.get("purchase_token", "")))
    return private_json(product_id=sp["product_id"], granted=bool(new), expires_at=sp["expires_at"])

@bp.route("/store/verify", methods=["POST"])
@auth_required
def store_verify():
    d = body(); platform = d.get("platform")
    if rate_limited(f"storeverify:{g.user['id']}", 30, 3600): return err(429, "Too many attempts. Try again later.")
    if platform == "google_play":
        p = dict(product_id=str(d.get("product_id", "")), purchase_token=str(d.get("purchase_token", "")), kind="subscription" if d.get("kind") == "subscription" else "product")
        if not SB.parse_product(p["product_id"])[0]: return err(400, "Unknown product.", "unknown_product")
    elif platform == "app_store": p = dict(transaction_id=str(d.get("transaction_id", "")))
    else: return err(400, "Unsupported platform.", "validation")
    return _verify_and_fulfil(platform, p)
