"""Mobile API v1 (Capacitor Android/iOS apps). A thin JSON layer over the SAME services, tables and business rules the website uses:
access/entitlements, pricing, notifications and progress are never re-implemented here. Auth is Bearer tokens only (see services/mobile.py)."""
import re, math
from functools import wraps
from flask import Blueprint, request, jsonify, g, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from ..db import q, q1, ex, val
from ..util import now, naira
from ..security import rate_limited, client_ip
from ..services import settings as S, access, audit, mobile, academic
from ..services.notify import notify_staff
from .auth import EMAIL, DUMMY_HASH, check_password_strength

bp = Blueprint("api_v1", __name__, url_prefix="/api/v1")
API_VERSION = 1
MIN_APP_VERSION = "1.0.0"          # raise this to force very old installs to update from the store

# Origins of the Capacitor WebView: Android serves the bundled app from https://localhost, iOS from capacitor://localhost (http://localhost for local dev).
ALLOWED_ORIGINS = {"https://localhost", "capacitor://localhost", "http://localhost", "ionic://localhost"}

@bp.after_request
def cors(resp):
    o = request.headers.get("Origin")
    if o in ALLOWED_ORIGINS:
        resp.headers["Access-Control-Allow-Origin"] = o; resp.headers["Vary"] = "Origin"
        resp.headers["Access-Control-Allow-Headers"] = "Authorization, Content-Type, If-None-Match"; resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PATCH, DELETE, OPTIONS"
        resp.headers["Access-Control-Expose-Headers"] = "ETag"; resp.headers["Access-Control-Max-Age"] = "600"
    return resp

def err(status, message, code=None): return mobile.json_error(status, message, code)

def auth_required(f):
    @wraps(f)
    def w(*a, **k):
        if not g.get("user"): return err(401, "Please sign in again.", "unauthorized")
        return f(*a, **k)
    return w

def body():
    d = request.get_json(silent=True)
    return d if isinstance(d, dict) else {}

def public_cache(resp, seconds=60):
    """Public, non-personal responses: short shared cache + ETag so the app (and Cloudflare) revalidate cheaply on slow networks."""
    resp.headers["Cache-Control"] = f"public, max-age={seconds}"
    resp.add_etag(); return resp.make_conditional(request)

def private_json(**kw):
    r = jsonify(ok=True, **kw); r.headers["Cache-Control"] = "private, no-store"; return r

def media_url(name):
    return f"{current_app.config['SITE_URL']}/media/{name}" if name else None

# ---- serialisers -------------------------------------------------------------------------------------------------------------------
LIVE_UPDATE_KEYS = ("mobile.bundle_version", "mobile.bundle_url", "mobile.bundle_sha256", "mobile.bundle_min_native")     # set by scripts/publish_web_bundle.py, never by hand-editing the apps
PUBLIC_SETTINGS = ("site.name", "site.tagline", "brand.primary", "brand.dark", "brand.accent", "contact.email", "contact.phone", "contact.whatsapp",
                   "mobile.store_url_android", "mobile.store_url_ios", "social.facebook", "social.instagram", "social.youtube", "social.x")       # whitelist: settings also holds payment-gateway secrets and bank details

def course_card(c, uid=None):
    sub = access.subject_of(c)
    d = dict(id=c["id"], slug=c["slug"], title=c["title"], summary=c["summary"], thumbnail=media_url(c["thumbnail"]),
             division=c["division"], level=((c["academic_level"] if c["academic_level"] in academic.LEVELS else "basic") if c["division"] == "academic" else None), scope=access.course_scope(c),
             featured=bool(c["featured"]), duration_min=val("SELECT COALESCE(SUM(duration_min),0) FROM lessons WHERE course_id=?", (c["id"],), 0),
             lessons=val("SELECT COUNT(*) FROM lessons WHERE course_id=?", (c["id"],), 0), instructor=_instructor(c["instructor_id"]),
             price_kobo=c["price_kobo"], price_label=("Free" if (c["price_kobo"] == 0 and not sub) else naira(sub["price_kobo"] if sub else c["price_kobo"])),
             purchase=_purchase_target(c, sub))
    if uid is not None: d["access"] = access.course_access(uid, c)
    return d

def _purchase_target(c, sub):
    """What a learner buys to unlock this course: the subject (Basic/Advanced/Professional) or the course itself (Income Skills etc.)."""
    if sub: return dict(item_type="subject", item_id=sub["id"], price_kobo=sub["price_kobo"], title=sub["name"] + " (full subject)")
    if c["price_kobo"] > 0: return dict(item_type="course", item_id=c["id"], price_kobo=c["price_kobo"], title=c["title"])
    return None

def _instructor(uid):
    if not uid: return None
    u = q1("SELECT id, full_name FROM users WHERE id=?", (uid,))
    return dict(id=u["id"], name=u["full_name"]) if u else None

def _points(text): return [x.strip(" -*\u2022") for x in (text or "").splitlines() if x.strip(" -*\u2022")]

# ---- public ------------------------------------------------------------------------------------------------------------------------
@bp.route("/config")
def config():
    from ..services import prelaunch as PL
    cfg = {k: S.get(k, "") for k in PUBLIC_SETTINGS}
    r = jsonify(ok=True, api_version=API_VERSION, min_app_version=MIN_APP_VERSION, content_version=mobile.content_version(), settings=cfg,
                prelaunch=dict(active=bool(PL.restricting()), label=PL.launch_label() if PL.restricting() else ""),
                live_update=dict(version=S.get("mobile.bundle_version", ""), url=S.get("mobile.bundle_url", ""), sha256=S.get("mobile.bundle_sha256", ""), min_native=S.get("mobile.bundle_min_native", "")),
                academic_levels=[dict(key=k, name=v["name"], sub=v["sub"]) for k, v in academic.LEVELS.items()],      # Basic and Advanced only
                divisions=[dict(key="academic", name="Academic"), dict(key="income", name="Income Skills"), dict(key="professional", name="Professional Development"), dict(key="faith", name="Faith & Spiritual Growth")])
    return public_cache(r, 30)

@bp.route("/bundles/<name>")
def web_bundle(name):
    """Hosts the signed web-layer bundles used for live updates (see docs/UPDATES.md). Only files published by scripts/publish_web_bundle.py are served."""
    import os, re
    from flask import send_from_directory
    if not re.fullmatch(r"dagba-web-[0-9A-Za-z._-]{1,40}\.zip", name): return err(404, "Not found.", "not_found")
    d = os.path.join(current_app.config["PUBLIC_DIR"], "bundles")
    if not os.path.exists(os.path.join(d, name)): return err(404, "Not found.", "not_found")
    return send_from_directory(d, name, mimetype="application/zip", max_age=3600)

@bp.route("/content-version")
def content_version():
    return public_cache(jsonify(ok=True, content_version=mobile.content_version()), 10)

@bp.route("/categories")
def categories():
    rows = q("SELECT id, division, level, name, slug, description, image, featured, price_kobo FROM categories WHERE active=1 ORDER BY division, COALESCE(level,''), position, name")
    out = [dict(id=r["id"], division=r["division"], level=r["level"] if r["division"] == "academic" else None, name=r["name"], slug=r["slug"], description=r["description"],
                image=media_url(r["image"]), featured=bool(r["featured"]), price_kobo=r["price_kobo"],
                courses=val("SELECT COUNT(*) FROM courses WHERE category_id=? AND status='published'", (r["id"],), 0)) for r in rows]
    return public_cache(jsonify(ok=True, categories=[c for c in out if c["courses"]], content_version=mobile.content_version()))

def _list_sql(args):
    where = ["c.status='published'"]; p = []
    div = args.get("division")
    if div in ("academic", "income", "professional"): where.append("c.division=?"); p.append(div)
    lvl = args.get("level")
    if lvl in ("basic", "advanced"): where.append("c.division='academic' AND COALESCE(c.academic_level,'basic')=?"); p.append(lvl)
    if args.get("category_id", type=int): where.append("c.category_id=?"); p.append(args.get("category_id", type=int))
    if args.get("free") in ("1", "true"): where.append("c.price_kobo=0")
    if args.get("featured") in ("1", "true"): where.append("c.featured=1")
    s = (args.get("q") or "").strip()[:80]
    if s:
        like = "%" + s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        where.append("(c.title LIKE ? ESCAPE '\\' OR c.summary LIKE ? ESCAPE '\\')"); p += [like, like]
    return " AND ".join(where), p

SORTS = {"new": "c.id DESC", "popular": "(SELECT COUNT(DISTINCT user_id) FROM progress WHERE course_id=c.id) DESC, c.id DESC", "title": "c.title COLLATE NOCASE",
         "price_low": "c.price_kobo ASC, c.id DESC", "price_high": "c.price_kobo DESC, c.id DESC"}

@bp.route("/courses")
def courses():
    where, p = _list_sql(request.args)
    page = max(1, request.args.get("page", 1, type=int)); per = max(1, min(50, request.args.get("per_page", 20, type=int)))
    total = val(f"SELECT COUNT(*) FROM courses c WHERE {where}", p, 0)
    order = SORTS.get(request.args.get("sort"), "c.featured DESC, c.id DESC")
    rows = q(f"SELECT c.* FROM courses c WHERE {where} ORDER BY {order} LIMIT ? OFFSET ?", p + [per, (page - 1) * per])
    uid = g.user["id"] if g.get("user") else None
    resp = jsonify(ok=True, courses=[course_card(c, uid) for c in rows], page=page, per_page=per, total=total, pages=max(1, math.ceil(total / per)), content_version=mobile.content_version())
    if uid: resp.headers["Cache-Control"] = "private, no-cache"; return resp
    return public_cache(resp)

@bp.route("/courses/<slug>")
def course_detail(slug):
    c = q1("SELECT * FROM courses WHERE slug=?", (slug,))
    uid = g.user["id"] if g.get("user") else None
    is_staff_owner = bool(uid and (g.user["role"] == "admin" or c and c["instructor_id"] == uid))
    if not c or (c["status"] != "published" and not is_staff_owner): return err(404, "This course is not available.", "not_found")
    mode = "preview" if is_staff_owner and c["status"] != "published" else (access.course_access(uid, c) if uid else access.course_access(None, c))
    mods = q("SELECT id, title FROM modules WHERE course_id=? ORDER BY position, id", (c["id"],))
    lessons = q("SELECT id, module_id, title, kind, duration_min, free_preview FROM lessons WHERE course_id=? ORDER BY position, id", (c["id"],))
    curriculum = []
    for m in mods + [dict(id=None, title="Lessons")]:
        ls = [dict(id=l["id"], title=l["title"], kind=l["kind"], duration_min=l["duration_min"], free_preview=bool(l["free_preview"]), locked=not (mode or l["free_preview"]))
              for l in lessons if l["module_id"] == m["id"]]
        if ls: curriculum.append(dict(id=m["id"], title=m["title"], lessons=ls))
    d = course_card(c, uid); d.update(description=c["description"], objectives=_points(c["objectives"]), outcomes=_points(c["outcomes"]), curriculum=curriculum,
        access=mode, access_policy=c["access_policy"], access_days=c["access_days"], certificate=bool(c["certificate_enabled"]),
        subscription=_sub_target(c), updated_at=c["updated_at"])
    resp = jsonify(ok=True, course=d, content_version=mobile.content_version())
    if uid: resp.headers["Cache-Control"] = "private, no-cache"; return resp
    return public_cache(resp)

def _sub_target(c):
    """Which subscription (if any) also unlocks this course. Scopes are independent: basic / advanced / income never unlock each other."""
    scope = access.course_scope(c)
    if scope == "professional" or not (c["subscription_eligible"] or (scope == "basic" and c["category_id"])): return None
    return dict(scope=scope)

# ---- auth --------------------------------------------------------------------------------------------------------------------------
def _device(d): return dict(device_name=d.get("device_name"), platform=d.get("platform"), app_version=d.get("app_version"))

def user_json(u):
    subs = access.subscription_status(u["id"])
    return dict(id=u["id"], email=u["email"], full_name=u["full_name"], phone=u["phone"], role=u["role"], created_at=u["created_at"],
                subscriptions={k: dict(active=v is not None, expires_at=None if (v is None or v.startswith("9999")) else v, lifetime=bool(v and v.startswith("9999"))) for k, v in subs.items()})

@bp.route("/auth/register", methods=["POST"])
def register():
    d = body(); email = str(d.get("email", "")).strip().lower(); name = str(d.get("full_name", "")).strip(); pw = str(d.get("password", ""))
    e = None
    if not name or len(name) > 120: e = "Please enter your full name."
    elif not EMAIL.fullmatch(email): e = "Enter a valid email address."
    else: e = check_password_strength(pw, email, name)
    if not e and rate_limited(f"reg:{client_ip()}", 10, 3600): return err(429, "Too many sign-ups from this network. Try again later.")
    if not e and val("SELECT 1 FROM users WHERE email=?", (email,)): e = "An account with this email already exists. Try signing in."
    if e: return err(400, e, "validation")
    uid = ex("INSERT INTO users(email,password_hash,full_name,phone) VALUES (?,?,?,?)", (email, generate_password_hash(pw), name, str(d.get("phone", "")).strip()[:30]))
    audit.log("user.registered", "user", uid, email + " (app)", actor={"id": uid, "full_name": name, "email": email})
    try:
        from ..services import prelaunch as PL
        if PL.restricting(): PL.record_account(uid, email, name)
    except Exception: pass
    notify_staff("users.manage", "New student registered", f"{name} ({email}) via the app", f"/staff/users/{uid}", "info")
    u = q1("SELECT * FROM users WHERE id=?", (uid,))
    r = jsonify(ok=True, user=user_json(u), **mobile.create_session(u, _device(d))); r.status_code = 201; r.headers["Cache-Control"] = "no-store"; return r

@bp.route("/auth/login", methods=["POST"])
def login():
    d = body(); email = str(d.get("email", "")).strip().lower(); pw = str(d.get("password", ""))
    if rate_limited(f"login:{client_ip()}:{email}", 8, 900) or rate_limited(f"loginip:{client_ip()}", 40, 900):
        return err(429, "Too many login attempts. Please wait 15 minutes and try again.")
    u = q1("SELECT * FROM users WHERE email=?", (email,)); ok = check_password_hash(u["password_hash"] if u else DUMMY_HASH, pw)
    if not (u and ok): return err(401, "Incorrect email or password.", "bad_credentials")
    if not u["is_active"]: return err(403, "This account has been deactivated. Contact support.", "deactivated")
    ex("UPDATE users SET last_login_at=? WHERE id=?", (now(), u["id"])); audit.log("auth.login", "user", u["id"], "app", actor=u)
    r = jsonify(ok=True, user=user_json(u), **mobile.create_session(u, _device(d))); r.headers["Cache-Control"] = "no-store"; return r

@bp.route("/auth/refresh", methods=["POST"])
def refresh():
    if rate_limited(f"refresh:{client_ip()}", 120, 900): return err(429, "Too many requests.")
    t, why = mobile.refresh(str(body().get("refresh_token", "")))
    if not t: return err(401, "Your session has ended. Please sign in again.", "session_ended")
    r = jsonify(ok=True, **t); r.headers["Cache-Control"] = "no-store"; return r

@bp.route("/auth/logout", methods=["POST"])
def logout():
    if g.get("api_session"): mobile.revoke(g.api_session)
    return private_json()

@bp.route("/me")
@auth_required
def me(): return private_json(user=user_json(g.user))

@bp.route("/me", methods=["PATCH"])
@auth_required
def me_update():
    d = body(); name = str(d.get("full_name", g.user["full_name"])).strip(); phone = str(d.get("phone", g.user["phone"] or "")).strip()[:30]
    if not name or len(name) > 120: return err(400, "Please enter your full name.", "validation")
    ex("UPDATE users SET full_name=?, phone=? WHERE id=?", (name, phone, g.user["id"]))
    return private_json(user=user_json(q1("SELECT * FROM users WHERE id=?", (g.user["id"],))))

@bp.route("/me/password", methods=["POST"])
@auth_required
def change_password():
    d = body(); old = str(d.get("current_password", "")); new = str(d.get("new_password", ""))
    if rate_limited(f"pwchg:{g.user['id']}", 8, 900): return err(429, "Too many attempts. Try again later.")
    if not check_password_hash(g.user["password_hash"], old): return err(400, "Your current password is incorrect.", "bad_credentials")
    e = check_password_strength(new, g.user["email"], g.user["full_name"])
    if e: return err(400, e, "validation")
    ex("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new), g.user["id"]))
    keep = g.api_session
    ex("UPDATE api_sessions SET revoked_at=? WHERE user_id=? AND id!=? AND revoked_at IS NULL", (now(), g.user["id"], keep))    # other devices must sign in again
    audit.log("auth.password_changed", "user", g.user["id"], "app", actor=g.user)
    return private_json()

@bp.route("/me", methods=["DELETE"])
@auth_required
def delete_account():
    """In-app account deletion (required by Apple/Google for apps with account creation). Personal data is erased/anonymised; financial,
    payout and certificate-verification records are kept because the business must retain them (this is disclosed in the privacy policy)."""
    u = g.user; d = body()
    if u["role"] != "student" or u["is_owner"]: return err(403, "Staff accounts must be closed by the academy. Contact support.", "staff_account")
    if not check_password_hash(u["password_hash"], str(d.get("password", ""))): return err(400, "Password is incorrect.", "bad_credentials")
    if val("SELECT 1 FROM affiliates WHERE user_id=? AND status='active'", (u["id"],)) or val("SELECT 1 FROM tutor_applications WHERE user_id=? AND status IN ('pending','revision','approved')", (u["id"],)):
        return err(409, "This account has an active affiliate or tutor profile. Contact support to close it.", "active_profile")
    uid = u["id"]
    mobile.revoke_all(uid)
    ex("DELETE FROM notifications WHERE user_id=?", (uid,))
    ex("UPDATE users SET email=?, full_name='Deleted user', phone=NULL, bio=NULL, class_level=NULL, is_active=0, password_hash=? WHERE id=?",
       (f"deleted-{uid}@deleted.invalid", generate_password_hash(__import__("secrets").token_hex(24)), uid))
    audit.log("user.deleted_self", "user", uid, "app", actor={"id": uid, "full_name": "Deleted user", "email": ""})
    return private_json(deleted=True)

@bp.route("/devices", methods=["POST"])
@auth_required
def register_device():
    d = body(); tok = str(d.get("token", "")).strip(); plat = d.get("platform")
    if plat not in ("android", "ios") or not (20 <= len(tok) <= 4096): return err(400, "Invalid device token.", "validation")
    ex("INSERT INTO device_tokens(user_id,session_id,platform,token,last_seen_at) VALUES (?,?,?,?,?) ON CONFLICT(token) DO UPDATE SET user_id=excluded.user_id, session_id=excluded.session_id, last_seen_at=excluded.last_seen_at",
       (g.user["id"], g.api_session, plat, tok, now()))
    return private_json()

from . import api_v1_learn, api_v1_store  # noqa: E402,F401  (registers parts 2-3 of the API on the same blueprint)
