"""Admin side of Faith & Spiritual Growth: overview, lesson list, one-page lesson editor with video/audio/study-material upload.
Topics and series use the same generic list/edit screens as the rest of the admin (see RES in staff.py)."""
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, jsonify
from ..db import q, q1, ex, val
from ..security import has_perm, login_required
from ..util import now
from ..services import faith as F, builder as B, uploads, audit, settings as S

bp = Blueprint("faithadmin", __name__, url_prefix="/staff/faith")
PERM = "faith.manage"

def _tutor(): return bool(g.get("user")) and g.user["role"] == "instructor" and not has_perm(PERM)
def _own_series_ids(): return [r["id"] for r in q("SELECT id FROM faith_series WHERE instructor_id=?", (g.user["id"],))]

def perm_required(perm):
    """Faith managers (admins with faith.manage) see everything; tutors see only the series assigned to them and their lessons."""
    def deco(f):
        from functools import wraps
        @wraps(f)
        @login_required
        def w(*a, **k):
            if not (has_perm(perm) or g.user["role"] == "instructor"): abort(403)
            return f(*a, **k)
        return w
    return deco

def manager_only(f):
    from functools import wraps
    @wraps(f)
    @login_required
    def w(*a, **k):
        if not has_perm(PERM): abort(403)
        return f(*a, **k)
    return w

def _own_item(iid):
    """A tutor may open a lesson only when it sits in one of their series."""
    row = q1("SELECT * FROM faith_items WHERE id=?", (iid,)) or abort(404)
    if _tutor() and not F.tutor_can_edit(g.user, row): abort(403)          # own series (existing right) or a created lesson in a still-assigned topic
    return row

def _json_err(e): return jsonify(ok=False, error=str(e), **getattr(e, "extra", {})), e.status

def api(f):
    """JSON endpoints: an expired session or missing permission gives a clean JSON answer instead of an HTML page."""
    from functools import wraps
    @wraps(f)
    def w(*a, **k):
        if not g.user: return jsonify(ok=False, error="Your session expired. Log in again in another tab, then retry (your upload progress is kept)."), 401
        if not (has_perm(PERM) or g.user["role"] == "instructor"): return jsonify(ok=False, error="You do not have permission to manage this section."), 403
        return f(*a, **k)
    return w

@bp.route("/")
@perm_required(PERM)
def overview():
    if _tutor(): return redirect(url_for("faithadmin.lessons"))
    topics = []
    for t in F.topics(active_only=False):
        t["drafts"] = val("SELECT COUNT(*) FROM faith_items WHERE topic_id=? AND status='draft'", (t["id"],), 0); topics.append(t)
    recent = q(F.ITEM_SELECT + " ORDER BY i.updated_at DESC LIMIT 6")
    from ..services import payouts as PO
    teachers = []
    for u in q("""SELECT u.id, u.full_name, u.email, COUNT(*) AS total, SUM(CASE WHEN s.status='published' THEN 1 ELSE 0 END) AS pub FROM faith_series s JOIN users u ON u.id=s.instructor_id GROUP BY u.id ORDER BY u.full_name"""):
        teachers.append(dict(u=u, faith=PO.by_division(u["id"])["faith"], s=PO.summary(u["id"])))
    return render_template("staff/faith_overview.html", st=F.stats(), pending=F.pending_count(), topics=topics, recent=recent, KINDS=F.KINDS, max_audio=B.audio_limit_mb(), max_video=B.video_limit_mb(),
                           teachers=teachers, unassigned=val("SELECT COUNT(*) FROM faith_series WHERE instructor_id IS NULL", default=0), rate=PO.percent("faith"), default_rate=PO.percent(),
                           payout_on=S.flag("payout.enabled"), can_users=has_perm("users.manage"), can_payouts=has_perm("payouts.manage"))

@bp.route("/lessons")
@perm_required(PERM)
def lessons():
    where, args = ["1=1"], []
    if _tutor(): sc, sa = F.tutor_scope_sql(g.user["id"]); where.append(sc); args += sa
    for k, col in (("topic", "i.topic_id"), ("status", "i.status"), ("kind", "i.kind"), ("series", "i.series_id")):
        v = request.args.get(k, "")
        if k == "status" and v == "pending": where.append("i.status='draft' AND i.submitted_at IS NOT NULL"); continue      # awaiting review
        if v: where.append(f"{col}=?"); args.append(v)
    s = request.args.get("q", "").strip()[:100]
    if s: where.append("(i.title LIKE ? OR i.scripture LIKE ? OR i.speaker LIKE ?)"); args += [f"%{s}%"] * 3
    sql = F.ITEM_SELECT + " WHERE " + " AND ".join(where)
    page = max(1, request.args.get("page", 1, type=int)); per = 20
    total = val(f"SELECT COUNT(*) FROM ({sql})", args, 0)
    rows = q(sql + " ORDER BY i.updated_at DESC LIMIT ? OFFSET ?", tuple(args) + (per, (page - 1) * per))
    return render_template("staff/faith_lessons.html", rows=rows, total=total, page=page, per=per, topics=(F.tutor_topics(g.user["id"]) if _tutor() else F.topics(with_counts=False, active_only=False)), series=q("SELECT id, title FROM faith_series" + (" WHERE instructor_id=?" if _tutor() else "") + " ORDER BY title", (g.user["id"],) if _tutor() else ()),
                           KINDS=F.KINDS, args=request.args, tutor=_tutor(), my_topics=(F.tutor_topics(g.user["id"]) if _tutor() else []), assigned=(F.tutor_topic_ids(g.user["id"]) if _tutor() else set()), pending=F.pending_count())

def _editor_context(item=None):
    if _tutor():
        rows = list(F.tutor_topics(g.user["id"]))
        if item and item.get("topic_id") and item["topic_id"] not in {t["id"] for t in rows}: rows += list(q("SELECT * FROM faith_topics WHERE id=?", (item["topic_id"],)))   # keep a lesson's current topic visible
    else: rows = F.topics(with_counts=False, active_only=False)
    topics = [dict(id=t["id"], name=t["name"]) for t in rows]
    series = [dict(id=s["id"], title=s["title"], topic_id=s["topic_id"]) for s in q("SELECT id, title, topic_id FROM faith_series" + (" WHERE instructor_id=?" if _tutor() else "") + " ORDER BY title", (g.user["id"],) if _tutor() else ())]
    return dict(tutor=_tutor(), assigned=(F.tutor_topic_ids(g.user["id"]) if _tutor() else set()), topics=topics, series=series, KINDS=F.KINDS, ACCESS=F.ACCESS, max_video=B.video_limit_mb(), max_audio=B.audio_limit_mb(), chunk=B.CHUNK)

@bp.route("/lesson/new")
@bp.route("/lesson/<int:iid>")
@perm_required(PERM)
def editor(iid=None):
    if iid:
        _own_item(iid)
        data = F.load_item(iid)
    else: data = F.blank_item(request.args.get("topic", type=int) or "", request.args.get("series", type=int) or "")
    review = q1("SELECT submitted_at, review_note FROM faith_items WHERE id=?", (iid,)) if iid else None
    return render_template("staff/faith_editor.html", data=data, review=review, **_editor_context(data))

@bp.route("/save", methods=["POST"])
@api
def save():
    p = request.get_json(silent=True)
    if not isinstance(p, dict): return jsonify(ok=False, error="Invalid request."), 400
    try: iid, status = F.save_item(g.user, p)
    except F.FaithError as e: return _json_err(e)
    return jsonify(ok=True, id=iid, status=status, redirect=url_for("faithadmin.editor", iid=iid, saved=1))

@bp.route("/lesson/<int:iid>/status", methods=["POST"])
@manager_only
def status(iid):
    row = q1("SELECT * FROM faith_items WHERE id=?", (iid,)) or abort(404)
    try: F.set_status(g.user, row, request.form.get("status", "")); flash(f"'{row['title']}' updated.", "success")
    except F.FaithError as e: flash(str(e), "error")
    return redirect(request.referrer or url_for("faithadmin.lessons"))

@bp.route("/lesson/<int:iid>/delete", methods=["POST"])
@perm_required(PERM)
def delete(iid):
    row = _own_item(iid)
    if _tutor() and (row["status"] != "draft" or row["submitted_at"]): abort(403)        # tutors can delete their own drafts only (withdraw from review first)
    F.delete_item(g.user, row); flash("Lesson deleted.", "info")
    return redirect(url_for("faithadmin.lessons"))

# ---- review workflow (tutor submits, admin approves or returns; nothing publishes automatically) ----
@bp.route("/lesson/<int:iid>/submit", methods=["POST"])
@perm_required(PERM)
def submit(iid):
    row = _own_item(iid)
    try: F.submit_item(g.user, row); flash("Submitted for review. An administrator will approve and publish it, and you will be notified.", "success")
    except F.FaithError as e: flash(str(e), "error")
    return redirect(url_for("faithadmin.editor", iid=iid))

@bp.route("/lesson/<int:iid>/withdraw", methods=["POST"])
@perm_required(PERM)
def withdraw(iid):
    row = _own_item(iid)
    try: F.withdraw_item(g.user, row); flash("Withdrawn from review. You can edit it again.", "info")
    except F.FaithError as e: flash(str(e), "error")
    return redirect(url_for("faithadmin.editor", iid=iid))

@bp.route("/lesson/<int:iid>/return", methods=["POST"])
@manager_only
def return_lesson(iid):
    row = q1("SELECT * FROM faith_items WHERE id=?", (iid,)) or abort(404)
    try: F.return_item(g.user, row, request.form.get("note", "")); flash(f"'{row['title']}' returned to the tutor.", "info")
    except F.FaithError as e: flash(str(e), "error")
    return redirect(request.referrer or url_for("faithadmin.lessons"))

# ---- tutor topic assignments (admins with faith.manage) ----
@bp.route("/tutors")
@manager_only
def tutors():
    topics = F.topics(with_counts=False, active_only=False)
    return render_template("staff/faith_tutors.html", rows=F.tutors_overview(), topics=[dict(t, tutors=F.topic_tutors(t["id"])) for t in topics], can_users=has_perm("users.manage"))

@bp.route("/tutors/<int:uid>", methods=["GET", "POST"])
@manager_only
def tutor_topics(uid):
    u = q1("SELECT id, full_name, email, is_active FROM users WHERE id=? AND role='instructor'", (uid,)) or abort(404)
    if request.method == "POST":
        try: add, rem = F.set_tutor_topics(g.user, uid, request.form.getlist("topic"))
        except F.FaithError as e: flash(str(e), "error")
        else: flash(f"Saved. {len(add)} added, {len(rem)} revoked." if (add or rem) else "No changes.", "success"); return redirect(url_for("faithadmin.tutors"))
    return render_template("staff/faith_tutor.html", u=u, topics=F.topics(with_counts=False, active_only=False), mine=F.tutor_topic_ids(uid),
                           lessons=q("SELECT i.id, i.title, i.status, i.submitted_at, t.name AS topic FROM faith_items i JOIN faith_topics t ON t.id=i.topic_id WHERE i.created_by=? ORDER BY i.updated_at DESC LIMIT 20", (uid,)))

@bp.route("/tutors/topic/<int:tid>", methods=["GET", "POST"])
@manager_only
def topic_tutors(tid):
    t = q1("SELECT * FROM faith_topics WHERE id=?", (tid,)) or abort(404)
    if request.method == "POST":
        try: add, rem = F.set_topic_tutors(g.user, tid, request.form.getlist("tutor"))
        except F.FaithError as e: flash(str(e), "error")
        else: flash(f"Saved. {len(add)} added, {len(rem)} revoked." if (add or rem) else "No changes.", "success"); return redirect(url_for("faithadmin.tutors"))
    return render_template("staff/faith_topic_tutors.html", t=t, tutors=q("SELECT id, full_name, email FROM users WHERE role='instructor' AND is_active=1 ORDER BY full_name COLLATE NOCASE"), mine={r["id"] for r in F.topic_tutors(tid)})

# ---- uploads (same resumable engine as the course builder) --------------------------------------
@bp.route("/upload/init", methods=["POST"])
@api
def upload_init():
    j = request.get_json(silent=True) or {}
    if not isinstance(j, dict): j = {}
    try: uid = B.init_upload(g.user, str(j.get("name") or ""), j.get("size"), "audio" if j.get("kind") == "audio" else "video")
    except B.BuilderError as e: return _json_err(e)
    return jsonify(ok=True, upload_id=uid, chunk=B.CHUNK)

@bp.route("/upload/<uid>/status")
@api
def upload_status(uid):
    r = q1("SELECT * FROM uploads WHERE id=? AND user_id=?", (uid, g.user["id"])) or abort(404)
    return jsonify(ok=True, next_index=r["next_index"], received=r["received"], size=r["size"], status=r["status"])

@bp.route("/upload/<uid>/chunk", methods=["POST"])
@api
def upload_chunk(uid):
    try: got = B.append_chunk(g.user, uid, request.args.get("index", -1, type=int), request.get_data())
    except B.BuilderError as e: return _json_err(e)
    return jsonify(ok=True, received=got)

@bp.route("/upload/<uid>/finish", methods=["POST"])
@api
def upload_finish(uid):
    try: stored, name = B.finish_upload(g.user, uid)
    except B.BuilderError as e: return _json_err(e)
    return jsonify(ok=True, file=stored, name=name, size=val("SELECT size FROM uploads WHERE id=?", (uid,), 0))

@bp.route("/resource", methods=["POST"])
@api
def upload_resource():
    f = request.files.get("file")
    if not f or not f.filename: return jsonify(ok=False, error="Choose a file."), 400
    try: stored, _e, _m, size = uploads.save_resource(f)
    except uploads.UploadError as e: return jsonify(ok=False, error=str(e)), 400
    B.register_resource(g.user, stored, f.filename, size)
    return jsonify(ok=True, file=stored, name=f.filename[:150])

@bp.route("/cover", methods=["POST"])
@api
def upload_cover():
    f = request.files.get("file")
    if not f or not f.filename: return jsonify(ok=False, error="Choose an image."), 400
    try: name = uploads.save_public_image(f)
    except uploads.UploadError as e: return jsonify(ok=False, error=str(e)), 400
    return jsonify(ok=True, file=name, url=url_for("public.media", name=name))
