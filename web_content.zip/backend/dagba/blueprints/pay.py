import logging
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, send_from_directory, current_app, jsonify
from ..db import q, q1, ex, val
from ..security import login_required, has_perm, rate_limited, client_ip
from ..services import payments as P, settings as S, providers, uploads
from ..util import naira

bp = Blueprint("pay", __name__)
log = logging.getLogger("dagba.pay")

def _checkout(item_type, item_id, back):
    try: it = P.price_item(item_type, item_id)
    except P.PayError as e:
        flash(str(e), "error"); return redirect(back)
    code = (request.values.get("promo") or "").strip(); promo = disc = None
    if code:
        try: promo, disc = P.evaluate_promo(code, item_type, it["price"])
        except P.PayError as e: flash(str(e), "error"); code = ""
    if request.method == "POST" and request.form.get("action") == "pay":
        try:
            tx = P.create_transaction(g.user, item_type, item_id, code)
            return redirect(url_for("pay.pay", ref=tx["reference"]))
        except P.PayError as e: flash(str(e), "error")
    return render_template("pay/checkout.html", it=it, code=code, disc=disc or 0, total=it["price"] - (disc or 0), item_type=item_type, item_id=item_id)

@bp.route("/checkout/course/<slug>", methods=["GET", "POST"])
@login_required
def checkout_course(slug):
    c = q1("SELECT id FROM courses WHERE slug=?", (slug,))
    if not c: abort(404)
    full = q1("SELECT * FROM courses WHERE id=?", (c["id"],))
    from ..services.access import sells_by_subject
    if sells_by_subject(full): return redirect(url_for("pay.checkout_subject", sid=full["category_id"]))
    return _checkout("course", c["id"], url_for("public.course", slug=slug))

@bp.route("/checkout/subject/<int:sid>", methods=["GET", "POST"])
@login_required
def checkout_subject(sid):
    """Buy a whole subject (Basic, Advanced or Professional Development). The price is the subject's saved price."""
    from ..services.access import subject_scope
    from ..services.academic import subject_slug, subject_url_args
    t = q1("SELECT * FROM categories WHERE id=?", (sid,))
    scope = subject_scope(t) if t else None
    if not scope: abort(404)
    ep, kw = subject_url_args(scope, subject_slug(t["name"]))
    return _checkout("subject", sid, url_for(ep, **kw))

@bp.route("/checkout/faith/<slug>", methods=["GET", "POST"])
@login_required
def checkout_faith(slug):
    s = q1("SELECT id FROM faith_series WHERE slug=?", (slug,))
    if not s: abort(404)
    return _checkout("faith", s["id"], url_for("faith.series", slug=slug))

@bp.route("/checkout/faith-topic/<slug>", methods=["GET", "POST"])
@login_required
def checkout_faith_topic(slug):
    t = q1("SELECT id FROM faith_topics WHERE slug=?", (slug,))
    if not t: abort(404)
    return _checkout("faith_topic", t["id"], url_for("faith.topic", slug=slug))

@bp.route("/checkout/plan/<int:pid>", methods=["GET", "POST"])
@login_required
def checkout_plan(pid): return _checkout("plan", pid, url_for("public.pricing"))

def _own(ref):
    tx = q1("SELECT * FROM transactions WHERE reference=? AND user_id=?", (ref, g.user["id"]))
    if not tx: abort(404)
    return tx

@bp.route("/pay/<ref>")
@login_required
def pay(ref):
    tx = _own(ref)
    return render_template("pay/pay.html", tx=tx, ev=q("SELECT * FROM payment_evidence WHERE transaction_id=? ORDER BY id DESC", (tx["id"],)),
        bank=dict(name=S.get("bank.name"), account_name=S.get("bank.account_name"), account_number=S.get("bank.account_number"),
                  instructions=S.get("bank.instructions"), ref_instructions=S.get("bank.reference_instructions"), support=S.get("bank.support_contact")),
        manual_on=S.flag("bank.enabled"), bank_ready=bool(S.get("bank.account_number") and S.get("bank.name")),
        receipt_required=S.flag("bank.receipt_required"), types=", ".join(x.upper() for x in uploads.allowed_receipt_types()),
        max_mb=uploads.receipt_max_bytes() // 1024 // 1024, resubmit=S.flag("bank.allow_resubmit"), gateways=providers.active_providers())

@bp.route("/pay/<ref>/evidence", methods=["POST"])
@login_required
def evidence(ref):
    tx = _own(ref)
    if rate_limited(f"evidence:{g.user['id']}", 10, 3600): flash("Too many uploads. Try again later.", "error")
    else:
        try:
            P.submit_evidence(tx, g.user, request.files.get("receipt"), request.form)
            flash("Payment evidence submitted. We will verify it and notify you.", "success")
        except P.PayError as e: flash(str(e), "error")
    return redirect(url_for("pay.pay", ref=ref))

@bp.route("/pay/<ref>/cancel", methods=["POST"])
@login_required
def cancel(ref):
    try: P.cancel(_own(ref), g.user); flash("Transaction cancelled.", "info")
    except P.PayError as e: flash(str(e), "error")
    return redirect(url_for("student.payments"))

@bp.route("/pay/<ref>/gateway/<provider>", methods=["POST"])
@login_required
def gateway(ref, provider):
    tx = _own(ref); p = providers.get_provider(provider)
    if not p: flash("That payment method is not available.", "error"); return redirect(url_for("pay.pay", ref=ref))
    try:
        url = P.start_gateway(tx, g.user, p, f"{current_app.config['SITE_URL']}/pay/callback/{provider}")
        return redirect(url)
    except (P.PayError, providers.ProviderError) as e:
        flash(str(e), "error"); return redirect(url_for("pay.pay", ref=ref))

@bp.route("/pay/callback/<provider>")
def callback(provider):
    p = providers.get_provider(provider)
    ref = request.args.get("reference") or request.args.get("tx_ref") or ""
    if not p or not ref: abort(404)
    if rate_limited(f"cb:{client_ip()}", 30, 600): abort(429)
    try:
        status = P.finalize_gateway(ref, provider, p.verify(ref))  # server-side verification, never trust the query string
    except providers.ProviderError as e:
        log.warning("verify failed %s: %s", ref, e); flash("We could not confirm the payment yet. It will update automatically once confirmed.", "info"); status = None
    flash({"approved": "Payment confirmed. Your access is active!", "failed": "The payment did not go through."}.get(status, "Payment status updated."), "success" if status == "approved" else "info")
    return redirect(url_for("pay.pay", ref=ref) if g.user else url_for("auth.login"))

@bp.route("/webhooks/<provider>", methods=["POST"])
def webhook(provider):
    p = providers.get_provider(provider)
    if not p: abort(404)
    raw = request.get_data()
    if not p.verify_webhook({k.lower(): v for k, v in request.headers.items()}, raw): abort(401)
    try: ref, key = p.parse_event(raw)
    except Exception: abort(400)
    if ref:
        try:
            P.finalize_gateway(ref, provider, p.verify(ref))
            ex("INSERT OR IGNORE INTO webhook_events(provider,event_key) VALUES (?,?)", (provider, key))
        except providers.ProviderError: return jsonify(ok=False), 500  # provider will retry
    return jsonify(ok=True)

@bp.route("/pay/receipt/<int:eid>")
@login_required
def receipt(eid):
    e = q1("SELECT e.*, t.user_id FROM payment_evidence e JOIN transactions t ON t.id=e.transaction_id WHERE e.id=?", (eid,))
    if not e or not e["file"]: abort(404)
    if not (e["user_id"] == g.user["id"] or has_perm("payments.manage")): abort(403)
    resp = send_from_directory(current_app.config["PRIVATE_DIR"], e["file"], mimetype=e["mime"], as_attachment=False)
    resp.headers["Content-Disposition"] = "inline"; resp.headers["Cache-Control"] = "private, no-store"
    resp.headers["Content-Security-Policy"] = "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox"
    return resp
