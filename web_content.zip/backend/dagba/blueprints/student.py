import os
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, jsonify, send_from_directory, current_app, Response
from ..db import q, q1, ex, val
from ..util import now
from ..security import login_required, role_required
from ..services import access, lms, uploads, audit, learning as LRN, faith as F, release as R, pathways as PW, discussions as D
from ..services.notify import notify

bp = Blueprint("student", __name__)

def _can_preview(course):
    u = g.user
    return u["role"] == "admin" or (u["role"] in ("instructor", "student") and course["instructor_id"] == u["id"])     # a student only owns a course while it is their tutor application

def _course_or_404(slug):
    c = q1("SELECT * FROM courses WHERE slug=?", (slug,))
    if not c: abort(404)
    return c

def _points(text):
    """One point per line, bullets stripped (course objectives / expected learning outcomes)."""
    return [x.strip(" -*\u2022") for x in (text or "").splitlines() if x.strip(" -*\u2022")]

def _mode(c):
    if _can_preview(c): return "preview"
    return access.course_access(g.user["id"], c)

def _blocked(c, l=None, mode=None):
    """Server-side restrictions on top of enrolment: a lesson whose scheduled release has not arrived ('release', UTC time) and unmet learning-path
    prerequisites ('prereq', [courses]). Staff previewing their own course are never blocked. None = allowed."""
    if mode == "preview" or _can_preview(c): return None
    if l is not None:
        row = q1("SELECT l.release_at, m.release_at AS module_release_at FROM lessons l LEFT JOIN modules m ON m.id=l.module_id WHERE l.id=?", (l["id"],))
        o = R.opens_at(row) if row else None
        if o: return ("release", o)
    if mode:
        u = PW.unmet(g.user["id"], c["id"])
        if u: return ("prereq", u)
    return None

@bp.route("/student")
@login_required
def dashboard():
    uid = g.user["id"]
    my = my_courses(uid); ids = [c["id"] for c in my]
    return render_template("student/dashboard.html", courses=my[:6], subs=access.subscription_status(uid),
        pending=q("SELECT * FROM transactions WHERE user_id=? AND status IN ('awaiting_payment','pending_verification','info_requested') ORDER BY created_at DESC", (uid,)),
        certs=val("SELECT COUNT(*) FROM certificates WHERE user_id=? AND revoked_at IS NULL", (uid,), 0),
        notes=q("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 5", (uid,)),
        unread=val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read_at IS NULL", (uid,), 0),
        faith_resume=F.continue_items(uid, 2), faith_on=F.has_content(),
        ov=LRN.overview(uid, my), resume=LRN.continue_items(uid, my, 4), recent_courses=LRN.recent_courses(uid, my, 3), recent_lessons=LRN.recent_lessons(uid, ids, 5),
        modules_done=LRN.completed_modules(uid, ids, 4), finished=[c for c in my if c["progress"]["total"] and c["progress"]["percent"] == 100][:4],
        todo=LRN.pending_assignments(uid, ids, 5), upcoming=LRN.upcoming_assessments(uid, ids, 5), results=LRN.recent_results(uid, 4),
        recs=LRN.recommendations(uid, my, 4), history=LRN.history(uid, 6), coming=R.upcoming(ids, 4), my_paths=PW.for_student(uid, ids, 3))

@bp.route("/student/activity")
@login_required
def activity():
    uid = g.user["id"]; my = my_courses(uid); ids = [c["id"] for c in my]
    return render_template("student/activity.html", history=LRN.history(uid, 60), lessons=LRN.recent_lessons(uid, ids, 12), modules=LRN.completed_modules(uid, ids, 20), ov=LRN.overview(uid, my), courses=my)

def my_courses(uid):
    rows = {}
    for c in access.purchased_courses(uid): rows[c["id"]] = c
    for c in q("SELECT DISTINCT c.* FROM progress p JOIN courses c ON c.id=p.course_id WHERE p.user_id=? AND c.status='published'", (uid,)):
        if access.course_access(uid, c): rows.setdefault(c["id"], c)
    out = []
    for c in rows.values():
        d = dict(c); d["progress"] = lms.course_progress(uid, c["id"]); out.append(d)
    return sorted(out, key=lambda c: -c["progress"]["percent"] if c["progress"]["percent"] < 100 else 1)

@bp.route("/student/courses")
@login_required
def courses():
    uid = g.user["id"]; subs = access.subscription_status(uid)
    included = []
    for d, exp in subs.items():
        if not exp: continue
        if d == "income": included += q("SELECT * FROM courses WHERE status='published' AND division='income' AND subscription_eligible=1 AND price_kobo>0 ORDER BY title")
        else: included += [c for c in q("SELECT c.* FROM courses c WHERE c.status='published' AND c.division='academic' AND (c.subscription_eligible=1 OR (? = 'basic' AND c.category_id IS NOT NULL)) AND COALESCE(c.academic_level,'basic')=? ORDER BY c.title", (d, d))
                           if c["price_kobo"] > 0 or access.sells_by_subject(c)]
    mine, subjects = my_courses(uid), access.purchased_subjects(uid)
    path = request.args.get("path", "")
    if path in ("basic", "advanced", "professional", "income"):            # one learning path at a time
        mine = [c for c in mine if access.course_scope(c) == path]; included = [c for c in included if access.course_scope(c) == path]
        subjects = [c for c in subjects if access.subject_scope(c) == path]; subs = {k: v for k, v in subs.items() if k == path}
    return render_template("student/courses.html", courses=mine, included=included, subs=subs, subjects=subjects, path=path)

@bp.route("/student/assessments")
@login_required
def assessments():
    rows = q("""SELECT a.*, z.title AS quiz, c.title AS course, c.slug FROM quiz_attempts a JOIN quizzes z ON z.id=a.quiz_id JOIN courses c ON c.id=z.course_id
                WHERE a.user_id=? ORDER BY a.created_at DESC LIMIT 100""", (g.user["id"],))
    return render_template("student/assessments.html", rows=rows)

@bp.route("/student/assignments")
@login_required
def assignments():
    rows = q("""SELECT s.*, a.title, a.max_score, c.title AS course, c.slug, a.id AS aid FROM submissions s JOIN assignments a ON a.id=s.assignment_id
                JOIN courses c ON c.id=a.course_id WHERE s.user_id=? ORDER BY s.submitted_at DESC""", (g.user["id"],))
    return render_template("student/assignments.html", rows=rows)

@bp.route("/student/certificates")
@login_required
def certificates():
    return render_template("student/certificates.html", certs=q("SELECT * FROM certificates WHERE user_id=? ORDER BY issued_at DESC", (g.user["id"],)))

@bp.route("/student/payments")
@login_required
def payments():
    uid = g.user["id"]
    return render_template("student/payments.html", txs=q("SELECT * FROM transactions WHERE user_id=? ORDER BY created_at DESC", (uid,)),
        subs=q("SELECT e.*, p.name FROM entitlements e LEFT JOIN plans p ON p.id=e.plan_id WHERE e.user_id=? AND e.kind='subscription' ORDER BY e.starts_at DESC", (uid,)),
        status=access.subscription_status(uid), now_str=now())

# Notification groups for the filter chips (kinds already written by the announcement, assignment, quiz and certificate code)
NOTE_FILTERS = {"announcement": ("announcement",), "assignment": ("assignment",), "grade": ("assessment",), "certificate": ("certificate",), "discussion": ("discussion",)}

@bp.route("/notifications", methods=["GET", "POST"])
@login_required
def notifications():
    if request.method == "POST":
        if request.form.get("id"): ex("UPDATE notifications SET read_at=? WHERE id=? AND user_id=? AND read_at IS NULL", (now(), request.form.get("id", type=int), g.user["id"]))
        else: ex("UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL", (now(), g.user["id"]))
        return redirect(url_for("student.notifications"))
    page = max(1, request.args.get("page", 1, type=int)); kind = request.args.get("kind", "")
    kinds = NOTE_FILTERS.get(kind)
    rows = q("SELECT * FROM notifications WHERE user_id=?" + (f" AND kind IN ({','.join('?' * len(kinds))})" if kinds else "") + " ORDER BY created_at DESC, id DESC LIMIT 30 OFFSET ?", (g.user["id"], *(kinds or ()), (page - 1) * 30))
    return render_template("student/notifications.html", rows=rows, page=page, kind=kind if kinds else "", filters=NOTE_FILTERS)

@bp.route("/notifications/<int:nid>/go")
@login_required
def notification_go(nid):
    n = q1("SELECT * FROM notifications WHERE id=? AND user_id=?", (nid, g.user["id"]))
    if not n: abort(404)
    ex("UPDATE notifications SET read_at=COALESCE(read_at,?) WHERE id=?", (now(), nid))
    link = n["link"] or ""
    return redirect(link if link.startswith("/") and not link.startswith("//") else url_for("student.notifications"))

# ---- Learning ----------------------------------------------------------
@bp.route("/learn/<slug>")
@login_required
def course_home(slug):
    c = _course_or_404(slug); mode = _mode(c)
    if not mode:
        flash("You need access to this course first.", "info"); return redirect(url_for("public.course", slug=slug))
    b = _blocked(c, None, mode)
    if b: return render_template("learn/locked.html", c=c, unmet=b[1]), 403
    uid = g.user["id"]; lessons = lms.ordered_lessons(c["id"])
    done = {r["lesson_id"] for r in q("SELECT lesson_id FROM progress WHERE user_id=? AND course_id=? AND completed_at IS NOT NULL", (uid, c["id"]))}
    ok, reasons = lms.eligibility(uid, c)
    opens = {x["id"]: R.fmt(R.opens_at(x)) for x in lessons if R.opens_at(x)} if mode != "preview" else {}
    return render_template("learn/course.html", c=c, lessons=lessons, done=done, mode=mode, progress=lms.course_progress(uid, c["id"]),
        resume=lms.resume_lesson(uid, c["id"]), quizzes=lms.quizzes_status(uid, c["id"]),
        assignments=q("SELECT a.*, (SELECT status FROM submissions s WHERE s.assignment_id=a.id AND s.user_id=?) AS sub_status FROM assignments a WHERE a.course_id=? ORDER BY a.id", (uid, c["id"])),
        announcements=q("SELECT * FROM announcements WHERE course_id=? ORDER BY created_at DESC LIMIT 5", (c["id"],)),
        cert=q1("SELECT * FROM certificates WHERE user_id=? AND course_id=?", (uid, c["id"])), eligible=ok, reasons=reasons,
        objectives=_points(c["objectives"]), outcomes=_points(c["outcomes"]), opens=opens, sched={x["id"]: R.fmt(R.effective(x["release_at"], x["module_release_at"])) for x in lessons if R.effective(x["release_at"], x["module_release_at"])} if mode == "preview" else {},
        paths=PW.paths_for_course(c["id"]), n_disc=D.count(c["id"]))

@bp.route("/learn/<slug>/lesson/<int:lid>")
@login_required
def lesson(slug, lid):
    c = _course_or_404(slug); l = q1("SELECT * FROM lessons WHERE id=? AND course_id=?", (lid, c["id"]))
    if not l: abort(404)
    mode = _mode(c)
    if not mode and not (l["free_preview"] and c["status"] == "published"):
        flash("This lesson is part of a paid course.", "info"); return redirect(url_for("public.course", slug=slug))
    b = _blocked(c, l, mode)
    if b:
        flash(f"This lesson opens on {R.fmt(b[1])}." if b[0] == "release" else "Complete the prerequisite course first.", "info"); return redirect(url_for("student.course_home", slug=slug))
    uid = g.user["id"]; prog = q1("SELECT * FROM progress WHERE user_id=? AND lesson_id=?", (uid, lid))
    if mode and mode != "preview":
        ex("INSERT INTO progress(user_id,lesson_id,course_id,updated_at) VALUES (?,?,?,?) ON CONFLICT(user_id,lesson_id) DO UPDATE SET updated_at=excluded.updated_at", (uid, lid, c["id"], now()))
    lessons = lms.ordered_lessons(c["id"]); ids = [x["id"] for x in lessons]; i = ids.index(lid)
    opens = {x["id"]: R.fmt(R.opens_at(x)) for x in lessons if R.opens_at(x)} if mode != "preview" else {}
    return render_template("learn/lesson.html", c=c, l=l, lessons=lessons, prev=lessons[i - 1] if i else None, nxt=lessons[i + 1] if i + 1 < len(lessons) else None, opens=opens,
        disc=D.threads(c, lid, g.user) if D.can_view(g.user, c) else None, can_post=D.can_view(g.user, c), can_mod=D.can_moderate(g.user, c),
        prog=prog, mode=mode, done={r["lesson_id"] for r in q("SELECT lesson_id FROM progress WHERE user_id=? AND course_id=? AND completed_at IS NOT NULL", (uid, c["id"]))})

def _learner_lesson(lid):
    l = q1("SELECT l.*, c.status cstatus, c.price_kobo, c.subscription_eligible, c.division, c.id cid FROM lessons l JOIN courses c ON c.id=l.course_id WHERE l.id=?", (lid,))
    if not l: abort(404)
    course = q1("SELECT * FROM courses WHERE id=?", (l["course_id"],))
    mode = access.course_access(g.user["id"], course)
    if not mode: abort(403)
    if _blocked(course, l, mode): abort(403)                          # scheduled release / prerequisites are enforced here too
    return l, course

@bp.route("/learn/lesson/<int:lid>/progress", methods=["POST"])
@login_required
def save_position(lid):
    l, c = _learner_lesson(lid)
    pos = max(0, min(request.form.get("position", 0, type=int), 86400))
    ex("INSERT INTO progress(user_id,lesson_id,course_id,position_seconds,updated_at) VALUES (?,?,?,?,?) ON CONFLICT(user_id,lesson_id) DO UPDATE SET position_seconds=excluded.position_seconds, updated_at=excluded.updated_at",
       (g.user["id"], lid, c["id"], pos, now()))
    return jsonify(ok=True)

@bp.route("/learn/lesson/<int:lid>/complete", methods=["POST"])
@login_required
def complete(lid):
    l, c = _learner_lesson(lid)
    ex("INSERT INTO progress(user_id,lesson_id,course_id,completed_at,updated_at) VALUES (?,?,?,?,?) ON CONFLICT(user_id,lesson_id) DO UPDATE SET completed_at=COALESCE(progress.completed_at, excluded.completed_at), updated_at=excluded.updated_at",
       (g.user["id"], lid, c["id"], now(), now()))
    p = lms.course_progress(g.user["id"], c["id"])
    if p["percent"] == 100: flash("You have finished all lessons in this course. Check the course page for your certificate.", "success")
    nxt = q1("SELECT l.id FROM lessons l LEFT JOIN modules m ON m.id=l.module_id WHERE l.course_id=? AND l.id!=? AND l.id NOT IN (SELECT lesson_id FROM progress WHERE user_id=? AND completed_at IS NOT NULL) AND (l.release_at IS NULL OR l.release_at<=?) AND (m.release_at IS NULL OR m.release_at<=?) ORDER BY COALESCE(m.position,0), l.position, l.id LIMIT 1", (c["id"], lid, g.user["id"], now(), now()))
    if request.headers.get("X-Requested-With") == "fetch": return jsonify(ok=True, percent=p["percent"])
    return redirect(url_for("student.lesson", slug=c["slug"], lid=nxt["id"]) if nxt else url_for("student.course_home", slug=c["slug"]))

@bp.route("/learn/resource/<int:lid>")
@login_required
def resource(lid):
    l = q1("SELECT * FROM lessons WHERE id=?", (lid,))
    if not l or not l["resource_file"]: abort(404)
    c = q1("SELECT * FROM courses WHERE id=?", (l["course_id"],))
    if not (_can_preview(c) or (access.course_access(g.user["id"], c) and l["downloadable"]) or (l["free_preview"] and c["status"] == "published" and l["downloadable"])): abort(403)
    if _blocked(c, l, None if _can_preview(c) else access.course_access(g.user["id"], c)): abort(403)
    return send_from_directory(current_app.config["PRIVATE_DIR"], l["resource_file"], as_attachment=l["kind"] != "pdf" or request.args.get("dl") == "1",
                               download_name=l["resource_name"] or l["resource_file"])

@bp.route("/learn/video/<int:lid>")
@login_required
def video(lid):
    """Serve an uploaded lesson video with Range support (seeking/resume) to entitled learners only."""
    l = q1("SELECT * FROM lessons WHERE id=?", (lid,))
    if not l or not l["video_file"]: abort(404)
    c = q1("SELECT * FROM courses WHERE id=?", (l["course_id"],))
    if not (_can_preview(c) or access.course_access(g.user["id"], c) or (l["free_preview"] and c["status"] == "published")): abort(403)
    if _blocked(c, l, None if _can_preview(c) else access.course_access(g.user["id"], c)): abort(403)
    mime = "video/webm" if l["video_file"].endswith(".webm") else "video/mp4"
    resp = send_from_directory(current_app.config["PRIVATE_DIR"], l["video_file"], mimetype=mime, conditional=True, max_age=0)
    resp.headers["Cache-Control"] = "private, max-age=3600"; resp.headers["Content-Disposition"] = "inline"
    return resp

@bp.route("/learn/<slug>/quiz/<int:qid>", methods=["GET", "POST"])
@login_required
def quiz(slug, qid):
    c = _course_or_404(slug); z = q1("SELECT * FROM quizzes WHERE id=? AND course_id=?", (qid, c["id"]))
    if not z: abort(404)
    if not _mode(c) or _blocked(c, None, _mode(c)): abort(403)
    qs = q("SELECT * FROM questions WHERE quiz_id=? ORDER BY position, id", (qid,))
    result = None
    if request.method == "POST" and qs:
        right = 0; review = []
        for item in qs:
            opts = item["options"].splitlines(); pick = request.form.get(f"q{item['id']}", type=int)
            ok = pick == item["correct"]; right += ok
            review.append(dict(q=item, pick=pick, ok=ok, opts=opts))
        pct = round(right * 100 / len(qs)); passed = int(pct >= z["pass_mark"])
        if _mode(c) != "preview":
            ex("INSERT INTO quiz_attempts(quiz_id,user_id,score_percent,passed) VALUES (?,?,?,?)", (qid, g.user["id"], pct, passed))
            notify(g.user["id"], f"Assessment result: {z['title']}", f"You scored {pct}% ({'passed' if passed else 'not passed yet - try again'}).", f"/learn/{slug}", "assessment")
        result = dict(pct=pct, passed=passed, review=review)
    attempts = q("SELECT * FROM quiz_attempts WHERE quiz_id=? AND user_id=? ORDER BY id DESC LIMIT 5", (qid, g.user["id"]))
    return render_template("learn/quiz.html", c=c, z=z, qs=qs, result=result, attempts=attempts)

@bp.route("/learn/<slug>/assignment/<int:aid>", methods=["GET", "POST"])
@login_required
def assignment(slug, aid):
    c = _course_or_404(slug); a = q1("SELECT * FROM assignments WHERE id=? AND course_id=?", (aid, c["id"]))
    if not a: abort(404)
    if not _mode(c) or _blocked(c, None, _mode(c)): abort(403)
    sub = q1("SELECT * FROM submissions WHERE assignment_id=? AND user_id=?", (aid, g.user["id"]))
    if request.method == "POST":
        if sub and sub["status"] == "reviewed": flash("This assignment has already been reviewed.", "error")
        else:
            body = request.form.get("body", "").strip(); f = request.files.get("file"); name = fname = None
            try:
                if f and f.filename: name, _e, _m, _s = uploads.save_private(f, ("jpg", "png", "pdf"), 8 * 1024 * 1024); fname = f.filename[:120]
                if not body and not name and not (sub and sub["file"]): raise uploads.UploadError("Write an answer or attach a file.")
                ex("""INSERT INTO submissions(assignment_id,user_id,body,file,file_name) VALUES (?,?,?,?,?)
                      ON CONFLICT(assignment_id,user_id) DO UPDATE SET body=excluded.body, file=COALESCE(excluded.file,submissions.file), file_name=COALESCE(excluded.file_name,submissions.file_name), submitted_at=?""",
                   (aid, g.user["id"], body[:10000], name, fname, now()))
                if c["instructor_id"]: notify(c["instructor_id"], "New assignment submission", f"{g.user['full_name']} submitted '{a['title']}'.", f"/staff/submissions", "assignment")
                flash("Assignment submitted.", "success")
            except uploads.UploadError as e: flash(str(e), "error")
        return redirect(url_for("student.assignment", slug=slug, aid=aid))
    return render_template("learn/assignment.html", c=c, a=a, sub=sub)

@bp.route("/files/submission/<int:sid>")
@login_required
def submission_file(sid):
    s = q1("SELECT s.*, c.instructor_id FROM submissions s JOIN assignments a ON a.id=s.assignment_id JOIN courses c ON c.id=a.course_id WHERE s.id=?", (sid,))
    if not s or not s["file"]: abort(404)
    if not (s["user_id"] == g.user["id"] or g.user["role"] == "admin" or s["instructor_id"] == g.user["id"]): abort(403)
    return send_from_directory(current_app.config["PRIVATE_DIR"], s["file"], as_attachment=True, download_name=s["file_name"] or s["file"])

@bp.route("/learn/<slug>/certificate", methods=["POST"])
@login_required
def claim_certificate(slug):
    c = _course_or_404(slug)
    if not access.course_access(g.user["id"], c): abort(403)
    cert, reasons = lms.issue_certificate(g.user, c)
    if not cert: flash("Not eligible yet: " + " ".join(reasons), "error")
    else: flash("Your certificate is ready.", "success")
    return redirect(url_for("student.course_home", slug=slug))

@bp.route("/certificates/<cert_id>.pdf")
@login_required
def certificate_pdf(cert_id):
    cert = q1("SELECT * FROM certificates WHERE cert_id=?", (cert_id,))
    if not cert or not (cert["user_id"] == g.user["id"] or g.user["role"] == "admin"): abort(404)
    if cert["revoked_at"]: flash("This certificate has been revoked.", "error"); return redirect(url_for("student.certificates"))
    return Response(lms.certificate_pdf(cert), mimetype="application/pdf", headers={"Content-Disposition": f'inline; filename="{cert_id}.pdf"'})
