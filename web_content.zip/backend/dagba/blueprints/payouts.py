"""Tutor earnings page (instructors) and payout management (admins with payouts.manage)."""
import csv, io
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, Response, send_from_directory, current_app
from ..db import q, q1, ex, val
from ..util import naira
from ..security import login_required, has_perm
from ..services import payouts as P, settings as S, audit

bp = Blueprint("payouts", __name__, url_prefix="/staff")
LABEL = {"requested": "Waiting to be paid", "paid": "Paid", "rejected": "Declined", "cancelled": "Cancelled"}

def _earner():
    if not P.is_earner(g.user): abort(403)
    return g.user

def _need_perm():
    if not has_perm("payouts.manage"): abort(403)

def _csv(name, head, rows):
    safe = lambda v: "'" + v if isinstance(v, str) and v[:1] in "=+-@\t\r" else v
    buf = io.StringIO(); w = csv.writer(buf); w.writerow(head)
    for r in rows: w.writerow([safe(x) for x in r])
    audit.log("export.csv", "export", name)
    return Response(buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename={name}"})

# ------------------------------------------------------------------ tutor side
@bp.route("/earnings")
@login_required
def earnings():
    u = _earner(); page = max(1, request.args.get("page", 1, type=int)); per = 15
    sales = q("""SELECT e.*, COALESCE(c.title, fs.title) AS title, COALESCE(c.division, 'faith') AS division, t.created_at AS paid_at, b.full_name AS buyer FROM instructor_earnings e LEFT JOIN courses c ON c.id=e.course_id LEFT JOIN faith_series fs ON fs.id=e.faith_series_id
                 JOIN transactions t ON t.id=e.transaction_id JOIN users b ON b.id=t.user_id WHERE e.instructor_id=? ORDER BY e.created_at DESC, e.id DESC LIMIT ? OFFSET ?""", (u["id"], per, (page - 1) * per))
    s = P.summary(u["id"]); total = val("SELECT COUNT(*) FROM instructor_earnings WHERE instructor_id=?", (u["id"],), 0)
    me = q1("SELECT * FROM users WHERE id=?", (u["id"],))
    reqs = q("SELECT * FROM payout_requests WHERE instructor_id=? ORDER BY requested_at DESC, id DESC", (u["id"],))
    by_course = q("SELECT COALESCE(c.title, fs.title) AS title, COALESCE(c.division, 'faith') AS division, COUNT(*) n, SUM(e.amount_kobo) amt FROM instructor_earnings e LEFT JOIN courses c ON c.id=e.course_id LEFT JOIN faith_series fs ON fs.id=e.faith_series_id WHERE e.instructor_id=? AND e.kind='sale' GROUP BY COALESCE(e.course_id, -e.faith_series_id) ORDER BY amt DESC", (u["id"],))
    return render_template("staff/earnings.html", s=s, sales=sales, reqs=reqs, me=me, open_req=next((r for r in reqs if r["status"] == "requested"), None), page=page, per=per, total=total, mask=P.mask_name,
                           pct=P.percent(), rates=P.rates(), by_div=P.by_division(u["id"]), min_amt=P.min_kobo(), enabled=S.flag("payout.enabled"), instructions=S.get("payout.instructions"), by_course=by_course, LABEL=LABEL)

@bp.route("/earnings/account", methods=["POST"])
@login_required
def earnings_account():
    u = _earner(); f = request.form
    try: P.save_bank(u, f.get("bank"), f.get("account_name"), f.get("account_number")); flash("Bank details saved.", "success")
    except P.PayoutError as e: flash(str(e), "error")
    return redirect(url_for("payouts.earnings"))

@bp.route("/earnings/request", methods=["POST"])
@login_required
def earnings_request():
    u = _earner(); f = request.form
    try:
        if f.get("bank"):   # bank details are submitted with the request form; save them first
            P.save_bank(u, f.get("bank"), f.get("account_name"), f.get("account_number"))
        P.request(u, f.get("amount", ""))
        flash("Withdrawal requested. The academy has been notified and will pay you by bank transfer.", "success")
    except P.PayoutError as e: flash(str(e), "error")
    return redirect(url_for("payouts.earnings"))

@bp.route("/earnings/<int:rid>/cancel", methods=["POST"])
@login_required
def earnings_cancel(rid):
    u = _earner()
    try: P.cancel(u, rid); flash("Request cancelled. The money is back in your available balance.", "info")
    except P.PayoutError as e: flash(str(e), "error")
    return redirect(url_for("payouts.earnings"))

@bp.route("/earnings/export.csv")
@login_required
def earnings_csv():
    u = _earner()
    rows = q("""SELECT e.*, COALESCE(c.title, fs.title) AS title, t.reference, b.full_name FROM instructor_earnings e LEFT JOIN courses c ON c.id=e.course_id LEFT JOIN faith_series fs ON fs.id=e.faith_series_id JOIN transactions t ON t.id=e.transaction_id JOIN users b ON b.id=t.user_id WHERE e.instructor_id=? ORDER BY e.created_at DESC""", (u["id"],))
    return _csv("my-earnings.csv", ["Date", "Course", "Student", "Type", "Student paid (NGN)", "Your share %", "You earned (NGN)", "Reference"],
                [[r["created_at"], r["title"], P.mask_name(r["full_name"]), r["kind"], r["gross_kobo"] / 100, r["percent"], r["amount_kobo"] / 100, r["reference"]] for r in rows])

@bp.route("/payouts/receipt/<int:rid>")
@login_required
def receipt(rid):
    r = q1("SELECT * FROM payout_requests WHERE id=?", (rid,))
    if not r or not r["receipt_file"]: abort(404)
    if not (r["instructor_id"] == g.user["id"] or has_perm("payouts.manage")): abort(403)
    resp = send_from_directory(current_app.config["PRIVATE_DIR"], r["receipt_file"], mimetype=r["receipt_mime"], as_attachment=False)
    resp.headers["Content-Disposition"] = "inline"; resp.headers["Cache-Control"] = "private, no-store"
    resp.headers["Content-Security-Policy"] = "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox"
    return resp

# ------------------------------------------------------------------ admin side
@bp.route("/payouts")
@login_required
def payouts():
    _need_perm(); st = request.args.get("status", ""); s = request.args.get("q", "").strip(); page = max(1, request.args.get("page", 1, type=int))
    where, a = ["1=1"], []
    if st in LABEL: where.append("r.status=?"); a.append(st)
    if s: where.append("(u.full_name LIKE ? OR u.email LIKE ? OR r.account_number LIKE ?)"); a += [f"%{s}%"] * 3
    sql = f"SELECT r.*, u.full_name, u.email FROM payout_requests r JOIN users u ON u.id=r.instructor_id WHERE {' AND '.join(where)}"
    rows = q(sql + " ORDER BY (r.status='requested') DESC, r.requested_at DESC LIMIT 25 OFFSET ?", tuple(a) + ((page - 1) * 25,))
    counts = {r["status"]: r["n"] for r in q("SELECT status, COUNT(*) n FROM payout_requests GROUP BY status")}
    return render_template("staff/payouts.html", rows=rows, counts=counts, LABEL=LABEL, args=request.args, page=page, total=val(f"SELECT COUNT(*) FROM ({sql})", a, 0),
                           owed=val("SELECT COALESCE(SUM(amount_kobo),0) FROM payout_requests WHERE status='requested'", default=0), paid=val("SELECT COALESCE(SUM(amount_kobo),0) FROM payout_requests WHERE status='paid'", default=0))

@bp.route("/payouts/<int:rid>", methods=["GET", "POST"])
@login_required
def payout(rid):
    _need_perm(); r = q1("SELECT r.*, u.full_name, u.email, u.phone FROM payout_requests r JOIN users u ON u.id=r.instructor_id WHERE r.id=?", (rid,)) or abort(404)
    if request.method == "POST":
        act = request.form.get("action")
        try:
            if not request.form.get("confirm"): raise P.PayoutError("Tick the confirmation box first.")
            if act == "pay": P.mark_paid(g.user, rid, request.files.get("receipt"), request.form.get("reference", ""), request.form.get("note", "")); flash("Marked as paid. The tutor has been notified and can see the receipt.", "success")
            elif act == "reject": P.reject(g.user, rid, request.form.get("reason", "")); flash("Request declined. The money is back in the tutor's available balance.", "info")
            else: abort(400)
        except P.PayoutError as e: flash(str(e), "error")
        return redirect(url_for("payouts.payout", rid=rid))
    return render_template("staff/payout.html", r=r, s=P.summary(r["instructor_id"]), LABEL=LABEL, decider=val("SELECT full_name FROM users WHERE id=?", (r["decided_by"],), None),
        sales=q("SELECT e.*, COALESCE(c.title, fs.title) AS title FROM instructor_earnings e LEFT JOIN courses c ON c.id=e.course_id LEFT JOIN faith_series fs ON fs.id=e.faith_series_id WHERE e.instructor_id=? ORDER BY e.created_at DESC LIMIT 10", (r["instructor_id"],)),
        history=q("SELECT * FROM audit_logs WHERE entity='payout' AND entity_id=? ORDER BY id", (str(rid),)), own=r["instructor_id"] == g.user["id"] and not g.user["is_owner"])

def _earners():
    rows = []
    for u in q("SELECT id, full_name, email FROM users WHERE role='instructor' OR id IN (SELECT instructor_id FROM instructor_earnings) ORDER BY full_name"):
        s = P.summary(u["id"]); rows.append(dict(u=u, s=s, by_div=P.by_division(u["id"])))
    return rows

@bp.route("/payouts/instructors")
@login_required
def instructors():
    _need_perm(); rows = _earners()
    tot = dict(gross=sum(r["s"]["gross"] for r in rows), earned=sum(r["s"]["earned"] for r in rows), paid=sum(r["s"]["paid"] for r in rows), pending=sum(r["s"]["pending"] for r in rows), available=sum(r["s"]["available"] for r in rows))
    tot["school"] = tot["gross"] - tot["earned"]
    return render_template("staff/payout_instructors.html", rows=rows, tot=tot, pct=P.percent(), rates=P.rates(), by_div=P.by_division())

@bp.route("/payouts/instructors/export.csv")
@login_required
def instructors_csv():
    _need_perm()
    return _csv("tutor-earnings.csv", ["Tutor", "Email", "Student payments (NGN)", "Tutor earned (NGN)", "Paid out (NGN)", "Waiting (NGN)", "Available (NGN)", "Sales", "Earned: Academic (NGN)", "Earned: Income Skills (NGN)", "Earned: Faith (NGN)"],
                [[r["u"]["full_name"], r["u"]["email"], r["s"]["gross"] / 100, r["s"]["earned"] / 100, r["s"]["paid"] / 100, r["s"]["pending"] / 100, r["s"]["available"] / 100, r["s"]["sales"]] + [r["by_div"][d]["earned"] / 100 for d in ("academic", "income", "faith")] for r in _earners()])

@bp.route("/payouts/export.csv")
@login_required
def payouts_csv():
    _need_perm()
    rows = q("SELECT r.*, u.full_name, u.email FROM payout_requests r JOIN users u ON u.id=r.instructor_id ORDER BY r.requested_at DESC")
    return _csv("payout-requests.csv", ["ID", "Tutor", "Email", "Amount (NGN)", "Status", "Bank", "Account name", "Account number", "Requested", "Decided", "Transfer reference", "Reason"],
                [[r["id"], r["full_name"], r["email"], r["amount_kobo"] / 100, r["status"], r["bank_name"], r["account_name"], r["account_number"], r["requested_at"], r["decided_at"], r["transfer_reference"], r["reject_reason"]] for r in rows])
