"""Mobile API v1, part 2: home, learning, lessons, media, quizzes, assignments, certificates, notifications, payments history, discussions,
articles, learning paths and Faith. Entitlement, release-schedule and prerequisite rules come from the same functions the website uses
(student._mode / student._blocked / access.*), so a rule changed once changes everywhere."""
import os
from flask import jsonify, request, g, current_app, send_from_directory, Response, abort
from ..db import q, q1, ex, val
from ..util import now, render_text, embed_url, naira
from ..security import login_required
from ..services import settings as S, access, lms, uploads, learning as LRN, pathways as PW, discussions as D, faith as F, release as R, mobile, audit
from ..services.notify import notify
from .api_v1 import bp, err, auth_required, body, public_cache, private_json, media_url, course_card, _points, _instructor
from .student import _mode, _blocked, _can_preview, my_courses
from .public import ARTICLE_LIVE

def _course(slug):
    c = q1("SELECT * FROM courses WHERE slug=?", (slug,))
    if not c or (c["status"] != "published" and not _can_preview(c)): abort(404)
    return c

def _entitled(c):
    """(mode, blocked) for the signed-in user; aborts 403 with a JSON message when the course is locked or not yet open."""
    mode = _mode(c)
    if not mode: abort(403, "You need access to this course first.")
    b = _blocked(c, None, mode)
    if b: abort(403, "Complete the prerequisite course first." if b[0] == "prereq" else f"This opens on {R.fmt(b[1])}.")
    return mode

# ---- home / my learning ------------------------------------------------------------------------------------------------------------
@bp.route("/home")
def home():
    uid = g.user["id"] if g.get("user") else None; flag = S.flag
    def cards(where="", args=(), order="c.featured DESC, c.id DESC", n=8):
        return [course_card(c, uid) for c in q(f"SELECT c.* FROM courses c WHERE c.status='published' {where} ORDER BY {order} LIMIT {n}", args)]
    banners = [dict(id=b["id"], label=b["label"], headline=b["headline"], description=b["description"], image=media_url(b["image"]), tone=b["tone"],
                    cta=dict(label=b["cta_label"], url=b["cta_url"]) if b["cta_label"] else None, cta2=dict(label=b["cta2_label"], url=b["cta2_url"]) if b["cta2_label"] else None)
               for b in q("SELECT * FROM hero_slides WHERE active=1 ORDER BY is_default DESC, position, id")]
    d = dict(banners=banners, featured=cards("AND c.featured=1"),
             popular=cards(order="(SELECT COUNT(DISTINCT user_id) FROM progress WHERE course_id=c.id) DESC, c.id DESC", n=8),
             sections=[dict(key=k, title=t, courses=cards(w)) for k, t, w, show in (
                 ("basic", "Academic: Basic", "AND c.division='academic' AND COALESCE(c.academic_level,'basic')='basic'", flag("home.show_featured")),   # same switch the website uses for its Basic block
                 ("advanced", "Academic: Advanced", "AND c.division='academic' AND c.academic_level='advanced'", flag("home.show_advanced")),
                 ("income", "Income Skills", "AND c.division='income'", flag("home.show_income")),
                 ("professional", "Professional Development", "AND c.division='professional'", flag("home.show_professional"))) if show],
             faith=[dict(slug=t["slug"], name=t["name"], image=media_url(t["image"]) if "image" in t.keys() else None, items=t["n"]) for t in F.topics() if t["n"]][:8] if flag("home.show_faith") else [],
             paths=[dict(slug=p["slug"], title=p["title"], summary=p["summary"], courses=p["n"]) for p in PW.list_published()[:6]],
             articles=_articles(6) if flag("home.show_articles") else [], greeting_name=(g.user["full_name"].split()[0] if uid and g.user["full_name"] else None), content_version=mobile.content_version())
    for s in d["sections"]: s["courses"] = [c for c in s["courses"]]
    if uid:
        my = my_courses(uid); d["continue"] = [dict(course=course_card(i["course"], uid), lesson=dict(id=i["lesson"]["id"], title=i["lesson"]["title"]), position_seconds=i["position"], percent=i["course"]["progress"]["percent"]) for i in LRN.continue_items(uid, my, 4)]
        d["unread_notifications"] = val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read_at IS NULL", (uid,), 0)
    r = jsonify(ok=True, **d); r.headers["Cache-Control"] = "private, no-cache" if uid else "public, max-age=60"
    return r if uid else public_cache(r)

@bp.route("/my/learning")
@auth_required
def my_learning():
    uid = g.user["id"]; my = my_courses(uid); done = []; active = []
    for c in my:
        card = course_card(c, uid); card["progress"] = c["progress"]
        (done if c["progress"]["percent"] >= 100 and c["progress"]["total"] else active).append(card)
    certs = q("SELECT * FROM certificates WHERE user_id=? AND revoked_at IS NULL ORDER BY issued_at DESC", (uid,))
    return private_json(in_progress=active, completed=done, certificates=len(certs), history=[dict(r) for r in LRN.history(uid, 30)],
                        paths=[dict(slug=x["path"]["slug"], title=x["path"]["title"], percent=x["prog"]["percent"], courses_done=x["prog"]["courses_done"], courses_total=x["prog"]["courses_total"]) for x in PW.for_student(uid, [c["id"] for c in my], 12)])

# ---- course learning view / lessons ------------------------------------------------------------------------------------------------
@bp.route("/learn/<slug>")
@auth_required
def learn_course(slug):
    c = _course(slug); mode = _entitled(c); uid = g.user["id"]; lessons = lms.ordered_lessons(c["id"])
    done = {r["lesson_id"] for r in q("SELECT lesson_id FROM progress WHERE user_id=? AND course_id=? AND completed_at IS NOT NULL", (uid, c["id"]))}
    ok, reasons = lms.eligibility(uid, c); resume = lms.resume_lesson(uid, c["id"]); cert = q1("SELECT cert_id FROM certificates WHERE user_id=? AND course_id=? AND revoked_at IS NULL", (uid, c["id"]))
    mods = {}
    for l in lessons:
        o = R.opens_at(l) if mode != "preview" else None
        mods.setdefault((l["module_id"], l["module_title"] or "Lessons"), []).append(dict(id=l["id"], title=l["title"], kind=l["kind"], duration_min=l["duration_min"], done=l["id"] in done, opens_at=R.fmt(o) if o else None))
    return private_json(course=course_card(c, uid), access=mode, progress=lms.course_progress(uid, c["id"]), resume_lesson_id=resume["id"] if resume else None,
        curriculum=[dict(id=k[0], title=k[1], lessons=v) for k, v in mods.items()], objectives=_points(c["objectives"]), outcomes=_points(c["outcomes"]),
        quizzes=[dict(id=z["id"], title=z["title"], pass_mark=z["pass_mark"], best_percent=z["best"], passed=bool(z["passed"])) for z in lms.quizzes_status(uid, c["id"])],
        assignments=[dict(id=a["id"], title=a["title"], due_date=a["due_date"], status=a["sub_status"]) for a in q("SELECT a.*, (SELECT status FROM submissions s WHERE s.assignment_id=a.id AND s.user_id=?) AS sub_status FROM assignments a WHERE a.course_id=? ORDER BY a.id", (uid, c["id"]))],
        announcements=[dict(id=a["id"], title=a["title"], body=a["body"], created_at=a["created_at"]) for a in q("SELECT * FROM announcements WHERE course_id=? ORDER BY created_at DESC LIMIT 5", (c["id"],))],
        certificate=dict(eligible=ok, reasons=reasons, cert_id=cert["cert_id"] if cert else None), discussion_count=D.count(c["id"]))

def _lesson_ctx(lid):
    l = q1("SELECT * FROM lessons WHERE id=?", (lid,)); c = q1("SELECT * FROM courses WHERE id=?", (l["course_id"],)) if l else None
    if not l or not c: abort(404)
    mode = _mode(c)
    if not mode and not (l["free_preview"] and c["status"] == "published"): abort(403, "This lesson is part of a paid course.")
    b = _blocked(c, l, mode)
    if b: abort(403, "Complete the prerequisite course first." if b[0] == "prereq" else f"This lesson opens on {R.fmt(b[1])}.")
    return l, c, mode

@bp.route("/lessons/<int:lid>")
@auth_required
def lesson(lid):
    l, c, mode = _lesson_ctx(lid); uid = g.user["id"]
    prog = q1("SELECT * FROM progress WHERE user_id=? AND lesson_id=?", (uid, lid))
    if mode and mode != "preview":
        ex("INSERT INTO progress(user_id,lesson_id,course_id,updated_at) VALUES (?,?,?,?) ON CONFLICT(user_id,lesson_id) DO UPDATE SET updated_at=excluded.updated_at", (uid, lid, c["id"], now()))
    allv = lms.ordered_lessons(c["id"]); ids = [x["id"] for x in allv]; i = ids.index(lid)
    video = None
    if l["video_file"]: video = dict(type="file", url=f"{current_app.config['SITE_URL']}/api/v1/media/video/{lid}?t={mobile.sign_media('video', lid, uid)}")
    elif l["video_url"]:
        kind, url = embed_url(l["video_url"])
        if kind: video = dict(type=kind, url=url)
    res = None
    if l["resource_file"] and l["downloadable"]: res = dict(name=l["resource_name"] or l["resource_file"], url=f"{current_app.config['SITE_URL']}/api/v1/media/resource/{lid}?t={mobile.sign_media('resource', lid, uid)}")
    return private_json(lesson=dict(id=l["id"], course_slug=c["slug"], title=l["title"], kind=l["kind"], duration_min=l["duration_min"], body_html=str(render_text(l["body"])) if l["body"] else "",
        video=video, resource=res, done=bool(prog and prog["completed_at"]), position_seconds=prog["position_seconds"] if prog else 0,
        prev_id=ids[i - 1] if i else None, next_id=ids[i + 1] if i + 1 < len(ids) else None, progress=lms.course_progress(uid, c["id"]) if mode else None, access=mode))

@bp.route("/lessons/<int:lid>/progress", methods=["POST"])
@auth_required
def save_position(lid):
    l, c, mode = _lesson_ctx(lid)
    if not mode or mode == "preview": return private_json()
    pos = max(0, min(int(body().get("position", 0) or 0), 86400))
    ex("INSERT INTO progress(user_id,lesson_id,course_id,position_seconds,updated_at) VALUES (?,?,?,?,?) ON CONFLICT(user_id,lesson_id) DO UPDATE SET position_seconds=excluded.position_seconds, updated_at=excluded.updated_at", (g.user["id"], lid, c["id"], pos, now()))
    return private_json()

@bp.route("/lessons/<int:lid>/complete", methods=["POST"])
@auth_required
def complete(lid):
    l, c, mode = _lesson_ctx(lid)
    if not mode or mode == "preview": return err(403, "Enrol in this course to track your progress.", "forbidden")
    ex("INSERT INTO progress(user_id,lesson_id,course_id,completed_at,updated_at) VALUES (?,?,?,?,?) ON CONFLICT(user_id,lesson_id) DO UPDATE SET completed_at=COALESCE(progress.completed_at, excluded.completed_at), updated_at=excluded.updated_at", (g.user["id"], lid, c["id"], now(), now()))
    return private_json(progress=lms.course_progress(g.user["id"], c["id"]))

@bp.route("/media/<kind>/<int:lid>")
def media_file(kind, lid):
    """Signed-link file streaming (Range supported) for lesson videos/resources and certificate PDFs. The link was minted only after the access checks above."""
    uid = mobile.verify_media(request.args.get("t"), kind, lid)
    if uid is None: abort(403, "This link has expired. Reopen the lesson.")
    if kind in ("fvideo", "faudio"):                         # Faith lesson files: access is re-checked at stream time (uid 0 = signed-out visitor on a public lesson)
        i = F.item_by_id(lid)
        if not i or i["status"] != "published" or F.item_state(i, uid or None) != "open": abort(403)
        name = i["video_file"] if kind == "fvideo" else i["audio_file"]
        if not name: abort(404)
        ext = name.rsplit(".", 1)[-1].lower()
        mime = ("video/webm" if ext == "webm" else "video/mp4") if kind == "fvideo" else F.AUDIO_MIME.get(ext, "audio/mpeg")
        r = send_from_directory(current_app.config["PRIVATE_DIR"], name, mimetype=mime, conditional=True, max_age=0); r.headers["Cache-Control"] = "private, max-age=3600"; r.headers["Content-Disposition"] = "inline"; return r
    u = q1("SELECT * FROM users WHERE id=? AND is_active=1", (uid,))
    if not u: abort(403)
    if kind == "cert":
        cert = q1("SELECT * FROM certificates WHERE id=? AND user_id=? AND revoked_at IS NULL", (lid, uid))
        if not cert: abort(404)
        return Response(lms.certificate_pdf(cert), mimetype="application/pdf", headers={"Content-Disposition": f'inline; filename="{cert["cert_id"]}.pdf"', "Cache-Control": "private, no-store"})
    l = q1("SELECT * FROM lessons WHERE id=?", (lid,))
    if not l: abort(404)
    if kind == "video" and l["video_file"]:
        mime = "video/webm" if l["video_file"].endswith(".webm") else "video/mp4"
        r = send_from_directory(current_app.config["PRIVATE_DIR"], l["video_file"], mimetype=mime, conditional=True, max_age=0); r.headers["Cache-Control"] = "private, max-age=3600"; r.headers["Content-Disposition"] = "inline"; return r
    if kind == "resource" and l["resource_file"] and l["downloadable"]:
        return send_from_directory(current_app.config["PRIVATE_DIR"], l["resource_file"], as_attachment=l["kind"] != "pdf", download_name=l["resource_name"] or l["resource_file"])
    abort(404)

# ---- quizzes / assignments / certificates -----------------------------------------------------------------------------------------
@bp.route("/quizzes/<int:qid>")
@auth_required
def quiz(qid):
    z = q1("SELECT * FROM quizzes WHERE id=?", (qid,)); c = q1("SELECT * FROM courses WHERE id=?", (z["course_id"],)) if z else None
    if not z or not c: abort(404)
    _entitled(c)
    qs = q("SELECT id, prompt, options FROM questions WHERE quiz_id=? ORDER BY position, id", (qid,))
    att = q("SELECT score_percent, passed, created_at FROM quiz_attempts WHERE quiz_id=? AND user_id=? ORDER BY id DESC LIMIT 5", (qid, g.user["id"]))
    return private_json(quiz=dict(id=z["id"], title=z["title"], pass_mark=z["pass_mark"], course_slug=c["slug"], questions=[dict(id=x["id"], prompt=x["prompt"], options=x["options"].splitlines()) for x in qs]),      # correct answers are never sent before submission
                        attempts=[dict(r) for r in att])

@bp.route("/quizzes/<int:qid>/submit", methods=["POST"])
@auth_required
def quiz_submit(qid):
    z = q1("SELECT * FROM quizzes WHERE id=?", (qid,)); c = q1("SELECT * FROM courses WHERE id=?", (z["course_id"],)) if z else None
    if not z or not c: abort(404)
    mode = _entitled(c); qs = q("SELECT * FROM questions WHERE quiz_id=? ORDER BY position, id", (qid,))
    if not qs: return err(400, "This quiz has no questions yet.", "validation")
    ans = body().get("answers") or {}; right = 0; review = []
    for item in qs:
        try: pick = int(ans.get(str(item["id"])))
        except (TypeError, ValueError): pick = None
        ok = pick == item["correct"]; right += ok
        review.append(dict(question_id=item["id"], pick=pick, correct=item["correct"], is_correct=ok, explanation=item["explanation"]))
    pct = round(right * 100 / len(qs)); passed = int(pct >= z["pass_mark"])
    if mode != "preview":
        ex("INSERT INTO quiz_attempts(quiz_id,user_id,score_percent,passed) VALUES (?,?,?,?)", (qid, g.user["id"], pct, passed))
        notify(g.user["id"], f"Assessment result: {z['title']}", f"You scored {pct}% ({'passed' if passed else 'not passed yet - try again'}).", f"/learn/{c['slug']}", "assessment")
    return private_json(percent=pct, passed=bool(passed), pass_mark=z["pass_mark"], review=review)

@bp.route("/assignments/<int:aid>")
@auth_required
def assignment(aid):
    a = q1("SELECT * FROM assignments WHERE id=?", (aid,)); c = q1("SELECT * FROM courses WHERE id=?", (a["course_id"],)) if a else None
    if not a or not c: abort(404)
    _entitled(c); s = q1("SELECT * FROM submissions WHERE assignment_id=? AND user_id=?", (aid, g.user["id"]))
    return private_json(assignment=dict(id=a["id"], title=a["title"], instructions=a["instructions"], due_date=a["due_date"], max_score=a["max_score"], course_slug=c["slug"]),
                        submission=dict(body=s["body"], file_name=s["file_name"], status=s["status"], score=s["score"], feedback=s["feedback"], submitted_at=s["submitted_at"]) if s else None)

@bp.route("/assignments/<int:aid>/submit", methods=["POST"])
@auth_required
def assignment_submit(aid):
    a = q1("SELECT * FROM assignments WHERE id=?", (aid,)); c = q1("SELECT * FROM courses WHERE id=?", (a["course_id"],)) if a else None
    if not a or not c: abort(404)
    mode = _entitled(c)
    if mode == "preview": return err(403, "Staff previews cannot submit.", "forbidden")
    sub = q1("SELECT * FROM submissions WHERE assignment_id=? AND user_id=?", (aid, g.user["id"]))
    if sub and sub["status"] == "reviewed": return err(409, "This assignment has already been reviewed.", "conflict")
    text = (request.form.get("body") if request.form else (body().get("body") or "")) or ""; text = text.strip(); f = request.files.get("file"); name = fname = None
    try:
        if f and f.filename: name, _e, _m, _s = uploads.save_private(f, ("jpg", "png", "pdf"), 8 * 1024 * 1024); fname = f.filename[:120]       # same validated, re-encoded upload path as the website
        if not text and not name and not (sub and sub["file"]): raise uploads.UploadError("Write an answer or attach a file.")
    except uploads.UploadError as e: return err(400, str(e), "validation")
    ex("""INSERT INTO submissions(assignment_id,user_id,body,file,file_name) VALUES (?,?,?,?,?)
          ON CONFLICT(assignment_id,user_id) DO UPDATE SET body=excluded.body, file=COALESCE(excluded.file,submissions.file), file_name=COALESCE(excluded.file_name,submissions.file_name), submitted_at=?""", (aid, g.user["id"], text[:10000], name, fname, now()))
    if c["instructor_id"]: notify(c["instructor_id"], "New assignment submission", f"{g.user['full_name']} submitted '{a['title']}'.", "/staff/submissions", "assignment")
    return private_json()

@bp.route("/my/assignments")
@auth_required
def my_assignments():
    rows = q("""SELECT s.status, s.score, s.submitted_at, a.id AS aid, a.title, a.max_score, c.title AS course, c.slug FROM submissions s JOIN assignments a ON a.id=s.assignment_id
                JOIN courses c ON c.id=a.course_id WHERE s.user_id=? ORDER BY s.submitted_at DESC""", (g.user["id"],))
    return private_json(assignments=[dict(r) for r in rows])

@bp.route("/my/certificates")
@auth_required
def my_certificates():
    base = current_app.config["SITE_URL"]
    return private_json(certificates=[dict(cert_id=r["cert_id"], course_title=r["course_title"], issued_at=r["issued_at"], verify_url=f"{base}/verify/{r['cert_id']}",
        pdf_url=f"{base}/api/v1/media/cert/{r['id']}?t={mobile.sign_media('cert', r['id'], g.user['id'])}") for r in q("SELECT * FROM certificates WHERE user_id=? AND revoked_at IS NULL ORDER BY issued_at DESC", (g.user["id"],))])

@bp.route("/learn/<slug>/certificate", methods=["POST"])
@auth_required
def claim_certificate(slug):
    c = _course(slug)
    if not access.course_access(g.user["id"], c): return err(403, "You need access to this course first.", "forbidden")
    cert, reasons = lms.issue_certificate(g.user, c)
    if not cert: return err(409, "Not eligible yet: " + " ".join(reasons), "not_eligible")
    return private_json(cert_id=cert["cert_id"])

# ---- notifications / payments history / plans ---------------------------------------------------------------------------------------
@bp.route("/notifications")
@auth_required
def notifications():
    from .student import NOTE_FILTERS
    kinds = NOTE_FILTERS.get(request.args.get("kind", "")); page = max(1, request.args.get("page", 1, type=int))
    rows = q("SELECT * FROM notifications WHERE user_id=?" + (f" AND kind IN ({','.join('?' * len(kinds))})" if kinds else "") + " ORDER BY created_at DESC, id DESC LIMIT 30 OFFSET ?", (g.user["id"], *(kinds or ()), (page - 1) * 30))
    return private_json(notifications=[dict(id=n["id"], kind=n["kind"], title=n["title"], body=n["body"], link=n["link"], read=bool(n["read_at"]), created_at=n["created_at"]) for n in rows],
                        unread=val("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read_at IS NULL", (g.user["id"],), 0), page=page, has_more=len(rows) == 30)

@bp.route("/notifications/read", methods=["POST"])
@auth_required
def notifications_read():
    nid = body().get("id")
    if nid: ex("UPDATE notifications SET read_at=? WHERE id=? AND user_id=? AND read_at IS NULL", (now(), int(nid), g.user["id"]))
    else: ex("UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL", (now(), g.user["id"]))
    return private_json()

@bp.route("/my/payments")
@auth_required
def my_payments():
    uid = g.user["id"]
    return private_json(transactions=[dict(reference=t["reference"], title=t["item_title"], amount_kobo=t["amount_kobo"], amount_label=naira(t["amount_kobo"]), status=t["status"], method=t["method"], created_at=t["created_at"], note=t["info_request"] or t["decision_reason"]) for t in q("SELECT * FROM transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 100", (uid,))],
        subscriptions=[dict(name=e["name"], starts_at=e["starts_at"], expires_at=e["expires_at"], active=e["revoked_at"] is None and (e["expires_at"] is None or e["expires_at"] > now())) for e in q("SELECT e.*, p.name FROM entitlements e LEFT JOIN plans p ON p.id=e.plan_id WHERE e.user_id=? AND e.kind='subscription' ORDER BY e.starts_at DESC", (uid,))],
        status={k: v for k, v in access.subscription_status(uid).items()})

@bp.route("/plans")
def plans():
    rows = q("SELECT * FROM plans WHERE active=1 ORDER BY position, price_kobo")
    return public_cache(jsonify(ok=True, plans=[dict(id=p["id"], name=p["name"], description=p["description"], scope=access.scope_of_plan(p), price_kobo=p["price_kobo"], price_label=naira(p["price_kobo"]), duration_days=p["duration_days"]) for p in rows], content_version=mobile.content_version()))

# ---- discussions -------------------------------------------------------------------------------------------------------------------
@bp.route("/courses/<slug>/discussions")
@auth_required
def discussions(slug):
    c = _course(slug)
    if not D.can_view(g.user, c): return err(403, "You need access to this course to join its discussion.", "forbidden")
    lid = request.args.get("lesson_id", type=int)
    def card(x):
        p = x["post"]; return dict(id=p["id"], body=p["body"] if not x["removed"] else "", name=x["name"], badge=x["badge"], mine=x["mine"], removed=x["removed"], can_delete=bool(x["can_delete"]), created_at=p["created_at"])
    return private_json(threads=[dict(card(t), replies=[card(r) for r in t["replies"]]) for t in D.threads(c, lid, g.user)])

@bp.route("/courses/<slug>/discussions", methods=["POST"])
@auth_required
def discussion_post(slug):
    c = _course(slug); d = body()
    try: p = D.post(g.user, c, d.get("body", ""), d.get("lesson_id"), d.get("parent_id"))
    except D.DiscussionError as e: return err(400, str(e), "validation")
    return private_json(id=p["id"])

# ---- articles / learning paths / faith -----------------------------------------------------------------------------------------------
def _articles(n=20, page=1):
    rows = q(f"SELECT a.*, u.full_name AS author, ac.name AS category FROM articles a LEFT JOIN users u ON u.id=a.author_id LEFT JOIN article_categories ac ON ac.id=a.category_id WHERE {ARTICLE_LIVE} ORDER BY COALESCE(a.publish_at,a.created_at) DESC LIMIT ? OFFSET ?", (now(), n, (page - 1) * n))
    return [dict(slug=a["slug"], title=a["title"], excerpt=a["excerpt"], image=media_url(a["featured_image"]), category=a["category"], author=a["author"], published_at=a["publish_at"] or a["created_at"]) for a in rows]

@bp.route("/articles")
def articles():
    page = max(1, request.args.get("page", 1, type=int)); return public_cache(jsonify(ok=True, articles=_articles(20, page), page=page, content_version=mobile.content_version()))

@bp.route("/articles/<slug>")
def article(slug):
    a = q1(f"SELECT a.*, u.full_name AS author, ac.name AS category FROM articles a LEFT JOIN users u ON u.id=a.author_id LEFT JOIN article_categories ac ON ac.id=a.category_id WHERE a.slug=? AND {ARTICLE_LIVE}", (slug, now()))
    if not a: return err(404, "This article is not available.", "not_found")
    return public_cache(jsonify(ok=True, article=dict(slug=a["slug"], title=a["title"], excerpt=a["excerpt"], image=media_url(a["featured_image"]), category=a["category"], author=a["author"],
        published_at=a["publish_at"] or a["created_at"], body_html=str(render_text(a["body"])), share_url=f"{current_app.config['SITE_URL']}/blog/{a['slug']}")))

@bp.route("/paths")
def paths():
    return public_cache(jsonify(ok=True, paths=[dict(slug=p["slug"], title=p["title"], summary=p["summary"], courses=p["n"]) for p in PW.list_published()], content_version=mobile.content_version()))

@bp.route("/paths/<slug>")
def path(slug):
    p = PW.by_slug(slug)
    if not p or p["status"] != "published": return err(404, "This learning path is not available.", "not_found")
    uid = g.user["id"] if g.get("user") else None; pr = PW.progress(uid, p)
    resp = jsonify(ok=True, path=dict(slug=p["slug"], title=p["title"], summary=p["summary"], description=p["description"], percent=pr["percent"], courses_done=pr["courses_done"], courses_total=pr["courses_total"],
        steps=[dict(course=course_card(s["course"], uid), state=s["state"], percent=s["progress"]["percent"], requires=[r["title"] for r in s["requires"]]) for s in pr["steps"]]))
    if uid: resp.headers["Cache-Control"] = "private, no-cache"; return resp
    return public_cache(resp)

def _faith_item(i, uid, owned_s, owned_t):
    return dict(id=i["id"], slug=i["slug"], title=i["title"], kind=i["kind"], summary=i["summary"], speaker=i["speaker"], scripture=i["scripture"], duration_min=i["duration_min"],
                thumbnail=media_url(i["thumbnail"]), topic=i["topic"], series=i["series"], state=F.item_state(i, uid, owned_s, False, owned_t),
                buy=([dict(product_id=f"dagba.faith.{i['series_id']}", title=i["series"], web_price_kobo=i["series_price"])] if i["series_id"] and (i["series_price"] or 0) > 0 else []) + ([dict(product_id=f"dagba.faithtopic.{i['topic_id']}", title=i["topic"] + " (all lessons)", web_price_kobo=i["topic_price"])] if (i["topic_price"] or 0) > 0 else []))

@bp.route("/faith")
def faith():
    uid = g.user["id"] if g.get("user") else None
    resp = jsonify(ok=True, topics=[dict(slug=t["slug"], name=t["name"], description=t["description"] if "description" in t.keys() else None, items=t["n"], series=t["series_n"], price_kobo=t["price_kobo"] if "price_kobo" in t.keys() else 0) for t in F.topics() if t["n"]], content_version=mobile.content_version())
    return public_cache(resp)

@bp.route("/faith/topics/<slug>")
def faith_topic(slug):
    t = F.topic_by_slug(slug)
    if not t: return err(404, "Topic not found.", "not_found")
    uid = g.user["id"] if g.get("user") else None; os_, ot = (F.owned_series_ids(uid), F.owned_topic_ids(uid)) if uid else (set(), set())
    items = q(F.ITEM_SELECT + " WHERE i.topic_id=? AND i.status='published' ORDER BY i.position, i.id LIMIT 100", (t["id"],))
    r = jsonify(ok=True, topic=dict(slug=t["slug"], name=t["name"]), items=[_faith_item(i, uid, os_, ot) for i in items])
    if uid: r.headers["Cache-Control"] = "private, no-cache"; return r
    return public_cache(r)

@bp.route("/faith/items/<slug>")
def faith_item(slug):
    i = F.item_by_slug(slug); uid = g.user["id"] if g.get("user") else None
    if not i or i["status"] != "published": return err(404, "Not found.", "not_found")
    d = _faith_item(i, uid, None, None)
    if d["state"] == "open":
        d["body_html"] = str(render_text(i["body"])) if i["body"] else ""
        if i["video_url"]: k, u = embed_url(i["video_url"]); d["video"] = dict(type=k, url=u) if k else None
        if i["audio_url"] and i["audio_url"].startswith("https://"): d["audio"] = dict(type="url", url=i["audio_url"])
        base = current_app.config["SITE_URL"]
        if i["video_file"]: d["video"] = dict(type="file", url=f"{base}/api/v1/media/fvideo/{i['id']}?t={mobile.sign_media('fvideo', i['id'], uid or 0)}")
        if i["audio_file"]: d["audio"] = dict(type="file", url=f"{base}/api/v1/media/faudio/{i['id']}?t={mobile.sign_media('faudio', i['id'], uid or 0)}")
    r = jsonify(ok=True, item=d)
    r.headers["Cache-Control"] = "private, no-cache"; return r
