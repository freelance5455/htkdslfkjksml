"""Tutor programme pages.
 public     /become-a-tutor, /tutors/<code>
 applicant  /tutor/apply...                 (a logged-in student; the course materials are authored in the Course Builder)
 tutor      /staff/tutor/submissions|reports|links|profile   (role instructor; sees ONLY their own data)
 admin      /staff/tutors/applications..., /staff/tutors, /staff/tutors/<id>, /staff/tutors/ledger   (permission tutors.manage)
Referral links (?ref=CODE) are captured here for every public page."""
import csv, io
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, Response, current_app
from ..db import q, q1, ex, val
from ..util import naira
from ..security import login_required, perm_required, has_perm
from ..services import tutors as T, payouts as PO, audit, settings as S, mou as M

bp = Blueprint("tutors", __name__)

# ------------------------------------------------------------------ referral capture
@bp.before_app_request
def _ref_param():
    g.pop("new_tref", None)
    code = request.args.get("ref")
    if code and request.method == "GET" and request.endpoint and request.endpoint != "static" and not request.path.startswith(("/r/", "/staff", "/affiliate", "/tutor/")):
        slug = (request.view_args or {}).get("slug") if request.endpoint in ("public.course", "public.course_alias") else None
        v = T.landing(code, slug)
        if v: g.new_tref = v

@bp.after_app_request
def _set_ref_cookie(resp):
    v = g.get("new_tref")
    if v:
        resp.set_cookie(T.COOKIE, v, max_age=T.attribution_days() * 86400, httponly=True, samesite="Lax", secure=bool(current_app.config.get("SESSION_COOKIE_SECURE")))
    return resp

def _csv(name, head, rows):
    safe = lambda v: "'" + v if isinstance(v, str) and v[:1] in "=+-@\t\r" else v
    buf = io.StringIO(); w = csv.writer(buf); w.writerow(head)
    for r in rows: w.writerow([safe(x) for x in r])
    audit.log("export.csv", "export", name)
    return Response(buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename={name}"})

# ------------------------------------------------------------------ public
@bp.route("/become-a-tutor")
def become():
    ok, msg = T.can_apply(g.user) if g.user else (True, "")
    app = T.open_application(g.user["id"]) if g.user and g.user["role"] == "student" else None
    last = T.latest_application(g.user["id"]) if g.user and g.user["role"] == "student" else None
    return render_template("public/become_tutor.html", can=ok, msg=msg, app=app, last=last, ref_pct=T.referral_percent(), days=T.attribution_days(), open_=T.applications_open())

@bp.route("/tutors/<code>")
def public_profile(code):
    p = T.by_code(code)
    u = q1("SELECT * FROM users WHERE id=? AND is_active=1", (p["user_id"],)) if p else None
    if not p or not u or p["status"] != "active": abort(404)
    courses = q("SELECT c.*, cat.name AS category FROM courses c LEFT JOIN categories cat ON cat.id=c.category_id WHERE c.instructor_id=? AND c.status='published' ORDER BY c.created_at DESC", (u["id"],))
    return render_template("public/tutor_profile.html", t=u, p=p, courses=courses, n_learners=sum(T.learners(c["id"]) for c in courses))

# ------------------------------------------------------------------ applicant
def _student():
    u = g.user
    if u["role"] == "instructor": return None
    return u

@bp.route("/tutor/apply")
@login_required
def apply():
    if g.user["role"] == "instructor": return redirect(url_for("tutors.submissions"))
    app = T.open_application(g.user["id"]) or T.latest_application(g.user["id"])
    ok, msg = T.can_apply(g.user)
    cats = T.categories(); course = q1("SELECT * FROM courses WHERE id=?", (app["course_id"],)) if app and app["course_id"] else None
    lessons = q("SELECT l.*, m.title AS module FROM lessons l LEFT JOIN modules m ON m.id=l.module_id WHERE l.course_id=? ORDER BY m.position, l.position", (course["id"],)) if course else []
    mv = M.current(); mdone = M.already_signed(g.user["id"], mv["id"]) if mv else None
    editable = bool(app and app["status"] in T.EDITABLE)
    if mv and editable and not mdone: M.record_view(g.user, mv)           # the applicant is being shown the document: the server remembers it
    mine = M.for_user(g.user["id"]) if app else []
    return render_template("tutor/apply.html", app=app, can=ok, msg=msg, cats=cats, course=course, lessons=lessons, events=T.events(app["id"]) if app else [], editable=editable, T=T,
                           mou_v=mv, mou_done=mdone, mou_mine=mine[0] if mine else None, M=M)

@bp.route("/tutor/apply/start", methods=["POST"])
@login_required
def apply_start():
    try: T.start(g.user)
    except T.TutorError as e: flash(str(e), "error")
    return redirect(url_for("tutors.apply"))

@bp.route("/tutor/apply/save", methods=["POST"])
@login_required
def apply_save():
    app = T.open_application(g.user["id"])
    if not app: abort(404)
    act = request.form.get("action")
    try:
        if act == "withdraw": T.withdraw(g.user, app); flash("Your application is back in draft so you can edit it. Submit it again when you are ready.", "success")
        else:
            errs = T.save_application(g.user, app, request.form, request.files, submit=(act == "submit"))
            if errs:
                for e in errs: flash(e, "error")
            else: flash("Application submitted. We will review it and email you." if act == "submit" else "Draft saved.", "success")
    except T.TutorError as e: flash(str(e), "error")
    return redirect(url_for("tutors.apply"))

# ------------------------------------------------------------------ tutor dashboard (own data only)
def _tutor():
    if g.user["role"] != "instructor": abort(403)
    return g.user, T.ensure_profile(g.user["id"])

@bp.route("/staff/tutor/submissions")
@login_required
def submissions():
    u, p = _tutor()
    rows = q("""SELECT a.*, c.slug, c.status AS course_status FROM tutor_applications a LEFT JOIN courses c ON c.id=a.course_id WHERE a.user_id=? ORDER BY a.id DESC""", (u["id"],))
    drafts = q("SELECT id, title, slug, status FROM courses WHERE instructor_id=? AND status IN ('draft','review') AND id NOT IN (SELECT course_id FROM tutor_applications WHERE course_id IS NOT NULL AND status IN ('pending','revision','approved')) ORDER BY updated_at DESC", (u["id"],))
    return render_template("staff/tutor_submissions.html", rows=rows, drafts=drafts, p=p, T=T)

@bp.route("/staff/tutor/reports")
@login_required
def reports():
    u, p = _tutor(); since, until = request.args.get("from") or None, request.args.get("to") or None
    if until: until = until + " 23:59:59"
    sp = T.split(u["id"], since, until); courses = T.per_course(u["id"])
    recent = q("""SELECT e.*, c.title, b.full_name AS buyer FROM instructor_earnings e LEFT JOIN courses c ON c.id=e.course_id JOIN transactions t ON t.id=e.transaction_id JOIN users b ON b.id=t.user_id
                  WHERE e.instructor_id=? ORDER BY e.id DESC LIMIT 25""", (u["id"],))
    return render_template("staff/tutor_reports.html", sp=sp, courses=courses, recent=recent, s=PO.summary(u["id"]), mask=PO.mask_name, p=p, args=request.args)

@bp.route("/staff/tutor/reports.csv")
@login_required
def reports_csv():
    u, p = _tutor()
    rows = q("""SELECT e.created_at, c.title, e.kind, e.source, e.ref_code, e.gross_kobo, e.percent, e.amount_kobo, t.reference FROM instructor_earnings e LEFT JOIN courses c ON c.id=e.course_id JOIN transactions t ON t.id=e.transaction_id
                WHERE e.instructor_id=? ORDER BY e.id DESC""", (u["id"],))
    return _csv("my-sales.csv", ["Date", "Course", "Type", "Source", "Referral code", "Student paid (NGN)", "My share (%)", "My earnings (NGN)", "Reference"],
                [[r["created_at"], r["title"] or "", r["kind"], "My referral link" if r["source"] == "affiliate" else "Dagba website", r["ref_code"] or "", r["gross_kobo"] / 100, r["percent"], r["amount_kobo"] / 100, r["reference"]] for r in rows])

@bp.route("/staff/tutor/links")
@login_required
def links():
    u, p = _tutor(); p, rows, tot = T.link_stats(u["id"])
    return render_template("staff/tutor_links.html", p=p, rows=rows, tot=tot, home=T.link_for(p["code"]), pct=T.referral_percent(), days=T.attribution_days(), s=T.split(u["id"]), plat=PO.percent())

@bp.route("/staff/tutor/profile", methods=["GET", "POST"])
@login_required
def tutor_profile():
    u, p = _tutor()
    if request.method == "POST":
        f = request.form; web = (f.get("website") or "").strip()[:200]
        if web and not web.startswith("https://"): flash("Website must start with https://", "error")
        else:
            ex("UPDATE tutor_profiles SET location=?, experience=?, qualifications=?, website=? WHERE user_id=?", ((f.get("location") or "")[:120], (f.get("experience") or "")[:3000], (f.get("qualifications") or "")[:1000], web or None, u["id"]))
            ex("UPDATE users SET bio=? WHERE id=?", ((f.get("bio") or "").strip()[:2000], u["id"])); flash("Tutor profile saved.", "success")
        return redirect(url_for("tutors.tutor_profile"))
    return render_template("staff/tutor_profile.html", p=p, me=q1("SELECT * FROM users WHERE id=?", (u["id"],)))

# ------------------------------------------------------------------ admin: applications
def _need_review():
    if not has_perm("tutors.manage"): abort(403)

@bp.route("/staff/tutors/applications")
@login_required
def apps_list():
    _need_review()
    # courses sent for review by any other route (the old course form, imports) join the queue here, so nothing waits unseen
    for r in q("SELECT c.id, c.instructor_id FROM courses c JOIN users u ON u.id=c.instructor_id WHERE c.status='review' AND u.role='instructor' AND NOT EXISTS (SELECT 1 FROM tutor_applications a WHERE a.course_id=c.id AND a.status='pending')"):
        T.course_submitted(r["id"], q1("SELECT * FROM users WHERE id=?", (r["instructor_id"],)))
    st = request.args.get("status", ""); kind = request.args.get("kind", ""); term = (request.args.get("q") or "").strip()
    where, a = ["a.status!='draft'" if not st else "1=1"], []
    if st in T.STATUSES: where.append("a.status=?"); a.append(st)
    if kind in ("tutor", "course"): where.append("a.kind=?"); a.append(kind)
    if term: where.append("(a.title LIKE ? OR a.full_name LIKE ? OR u.email LIKE ?)"); a += [f"%{term}%"] * 3
    rows = q(f"""SELECT a.*, u.email, u.avatar, u.full_name AS uname, u.id AS uid FROM tutor_applications a JOIN users u ON u.id=a.user_id WHERE {' AND '.join(where)}
                 ORDER BY CASE a.status WHEN 'pending' THEN 0 WHEN 'revision' THEN 1 ELSE 2 END, COALESCE(a.submitted_at, a.created_at) DESC LIMIT 200""", tuple(a))
    counts = {r["status"]: r["n"] for r in q("SELECT status, COUNT(*) n FROM tutor_applications GROUP BY status")}
    return render_template("staff/tutor_apps.html", rows=rows, counts=counts, st=st, kind=kind, term=term, T=T)

@bp.route("/staff/tutors/applications/<int:aid>")
@login_required
def app_detail(aid):
    _need_review(); app = T.get(aid) or abort(404)
    user = q1("SELECT * FROM users WHERE id=?", (app["user_id"],)); course = q1("SELECT * FROM courses WHERE id=?", (app["course_id"],)) if app["course_id"] else None
    mods = []
    if course:
        for m in q("SELECT * FROM modules WHERE course_id=? ORDER BY position", (course["id"],)):
            mods.append(dict(m, lessons=q("SELECT * FROM lessons WHERE module_id=? ORDER BY position", (m["id"],))))
        loose = q("SELECT * FROM lessons WHERE course_id=? AND module_id IS NULL ORDER BY position", (course["id"],))
        if loose: mods.append(dict(id=0, title="Lessons", lessons=loose))
    cat = q1("SELECT * FROM categories WHERE id=?", (app["category_id"],)) if app["category_id"] else None
    macc = M.for_application(aid) or (M.for_user(user["id"])[:1] or [None])[0]
    return render_template("staff/tutor_app.html", app=app, u=user, macc=macc, mou_st=M.status_of(macc) if macc else None, mou_ok=M.can_review_records(), course=course, mods=mods, cat=cat, events=T.events(aid), prof=T.profile(user["id"]), can_money=has_perm("payouts.manage"), T=T,
                           block=T.publish_blocked(course["id"]) if course and course["status"] != "published" else None, max_pct=T.max_percent(), ref_pct=T.referral_percent(), n_lessons=sum(len(m["lessons"]) for m in mods))

@bp.route("/staff/tutors/applications/<int:aid>/decide", methods=["POST"])
@login_required
def app_decide(aid):
    _need_review(); f = request.form; act = f.get("action")
    try:
        if act == "approve": uid = T.approve(g.user, aid, f.get("price", ""), f.get("aff_percent", ""), f.get("plat_percent", ""), f.get("feedback", "")); flash("Approved. The account is now a tutor and the course is published.", "success")
        elif act == "revision": T.request_revision(g.user, aid, f.get("feedback", "")); flash("Sent back to the applicant with your feedback.", "success")
        elif act == "reject": T.reject(g.user, aid, f.get("feedback", "")); flash("Application rejected and the applicant has been told why.", "success")
        elif act == "price": T.adjust_price(g.user, aid, f.get("price", "")); flash("Price updated.", "success")
        else: abort(400)
    except T.TutorError as e: flash(str(e), "error")
    return redirect(url_for("tutors.app_detail", aid=aid))

# ------------------------------------------------------------------ admin: tutors
@bp.route("/staff/tutors")
@login_required
def tutors_list():
    _need_review(); term = (request.args.get("q") or "").strip(); st = request.args.get("status", "")
    where, a = ["u.role='instructor'"], []
    if st in ("active", "suspended"): where.append("COALESCE(p.status,'active')=?"); a.append(st)
    if term: where.append("(u.full_name LIKE ? OR u.email LIKE ? OR p.code LIKE ?)"); a += [f"%{term}%"] * 3
    rows = q(f"""SELECT u.id, u.full_name, u.email, u.avatar, u.is_active, p.code, COALESCE(p.status,'active') AS pstatus,
                   (SELECT COUNT(*) FROM courses c WHERE c.instructor_id=u.id AND c.status='published') n_courses,
                   (SELECT COALESCE(SUM(amount_kobo),0) FROM instructor_earnings e WHERE e.instructor_id=u.id) earned,
                   (SELECT COALESCE(SUM(amount_kobo),0) FROM instructor_earnings e WHERE e.instructor_id=u.id AND e.source='affiliate') earned_aff
                 FROM users u LEFT JOIN tutor_profiles p ON p.user_id=u.id WHERE {' AND '.join(where)} ORDER BY u.full_name LIMIT 300""", tuple(a))
    return render_template("staff/tutors.html", rows=rows, term=term, st=st, show_money=has_perm("payouts.manage") or has_perm("reports.view"))

@bp.route("/staff/tutors/<int:uid>", methods=["GET", "POST"])
@login_required
def tutor_detail(uid):
    _need_review(); u = q1("SELECT * FROM users WHERE id=? AND role='instructor'", (uid,)) or abort(404); p = T.ensure_profile(uid)
    if request.method == "POST":
        f = request.form; act = f.get("action")
        try:
            if act == "suspend": T.suspend(g.user, uid, f.get("reason", "")); flash("Tutor suspended. Their courses are hidden and withdrawals are paused.", "success")
            elif act == "unsuspend": T.unsuspend(g.user, uid); flash("Suspension lifted. Their courses are live again.", "success")
            elif act == "rates":
                if not has_perm("payouts.manage"): abort(403)
                aff, plat = T.parse_pct(f.get("affiliate_percent")), T.parse_pct(f.get("platform_percent"))
                ex("UPDATE tutor_profiles SET affiliate_percent=?, platform_percent=? WHERE user_id=?", (aff, plat, uid))
                audit.log("tutor.rates", "user", uid, f"referral={aff} platform={plat}"); flash("This tutor's commission rates were saved. They apply to future sales only.", "success")
            elif act == "course_rates":
                if not has_perm("payouts.manage"): abort(403)
                cid = request.form.get("course_id", type=int); c = q1("SELECT * FROM courses WHERE id=? AND instructor_id=?", (cid, uid)) or abort(404)
                aff, plat = T.parse_pct(f.get("affiliate_percent")), T.parse_pct(f.get("platform_percent"))
                ex("UPDATE courses SET tutor_affiliate_percent=?, tutor_platform_percent=? WHERE id=?", (aff, plat, cid))
                audit.log("course.rates", "courses", cid, f"referral={aff} platform={plat}"); flash(f"Rates saved for '{c['title']}'.", "success")
            else: abort(400)
        except T.TutorError as e: flash(str(e), "error")
        return redirect(url_for("tutors.tutor_detail", uid=uid))
    courses = q("SELECT * FROM courses WHERE instructor_id=? ORDER BY title", (uid,))
    recent = q("""SELECT e.*, c.title, b.full_name AS buyer FROM instructor_earnings e LEFT JOIN courses c ON c.id=e.course_id JOIN transactions t ON t.id=e.transaction_id JOIN users b ON b.id=t.user_id
                  WHERE e.instructor_id=? ORDER BY e.id DESC LIMIT 20""", (uid,))
    cur = M.current(); cid = cur["id"] if cur else -1
    return render_template("staff/tutor_detail.html", agreements=[dict(r=r, st=M.status_of(r, cid)) for r in M.for_user(uid)], u=u, p=p, courses=courses, sp=T.split(uid), s=PO.summary(uid), recent=recent, apps=q("SELECT * FROM tutor_applications WHERE user_id=? ORDER BY id DESC", (uid,)),
                           money=has_perm("payouts.manage"), max_pct=T.max_percent(), ref_pct=T.referral_percent(), plat=PO.rates(), T=T, links=T.link_stats(uid)[1])

def _ledger_query():
    if not (has_perm("tutors.manage") or has_perm("payouts.manage")): abort(403)
    where, a = ["1=1"], []
    src = request.args.get("source", "")
    if src in ("affiliate", "platform"): where.append("e.source=?"); a.append(src)
    if request.args.get("tutor", type=int): where.append("e.instructor_id=?"); a.append(request.args.get("tutor", type=int))
    if request.args.get("from"): where.append("e.created_at>=?"); a.append(request.args["from"])
    if request.args.get("to"): where.append("e.created_at<?"); a.append(request.args["to"] + " 23:59:59")
    return f"""SELECT e.*, c.title, tu.full_name AS tutor, b.full_name AS buyer, t.reference, t.amount_kobo AS paid FROM instructor_earnings e LEFT JOIN courses c ON c.id=e.course_id JOIN users tu ON tu.id=e.instructor_id
               JOIN transactions t ON t.id=e.transaction_id JOIN users b ON b.id=t.user_id WHERE {' AND '.join(where)} ORDER BY e.id DESC""", tuple(a)

@bp.route("/staff/tutors/ledger")
@login_required
def ledger():
    sql, a = _ledger_query(); page = max(1, request.args.get("page", 1, type=int)); per = 30
    total = val(f"SELECT COUNT(*) FROM ({sql})", a, 0); rows = q(sql + " LIMIT ? OFFSET ?", a + (per, (page - 1) * per))
    sp = T.split(request.args.get("tutor", type=int) or None, request.args.get("from") or None, (request.args["to"] + " 23:59:59") if request.args.get("to") else None)
    tutors = q("SELECT id, full_name FROM users WHERE role='instructor' ORDER BY full_name")
    from urllib.parse import urlencode
    qs = urlencode({k: v for k, v in request.args.items() if k != "page" and v})
    return render_template("staff/tutor_ledger.html", rows=rows, page=page, per=per, total=total, sp=sp, tutors=tutors, args=request.args, qs=qs)

@bp.route("/staff/tutors/ledger.csv")
@login_required
def ledger_csv():
    sql, a = _ledger_query()
    return _csv("tutor-transactions.csv", ["Date", "Tutor", "Course", "Student", "Type", "Source", "Referral code", "Student paid (NGN)", "Tutor share (%)", "Rate basis", "Tutor earnings (NGN)", "Payment reference"],
                [[r["created_at"], r["tutor"], r["title"] or "", r["buyer"], r["kind"], "Tutor referral" if r["source"] == "affiliate" else "Dagba website", r["ref_code"] or "", r["gross_kobo"] / 100, r["percent"], r["rate_basis"] or "", r["amount_kobo"] / 100, r["reference"]] for r in q(sql, a)])
