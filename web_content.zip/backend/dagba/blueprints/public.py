import re
from flask import Blueprint, render_template, request, abort, redirect, url_for, flash, send_from_directory, current_app, Response, g, jsonify
from ..db import q, q1, ex, val
from ..util import now
from ..security import client_ip, rate_limited
from ..services import settings as S, access, lms, academic as A, faith as F, hero as HERO, pathways as PW, release as R
from ..services.notify import notify_staff

bp = Blueprint("public", __name__)
PER_PAGE = 12
ARTICLE_LIVE = "(a.status='published' OR (a.status='scheduled' AND a.publish_at<=?))"

def paginate(sql, args, page, per=PER_PAGE):
    total = val(f"SELECT COUNT(*) FROM ({sql})", args, 0)
    rows = q(sql + " LIMIT ? OFFSET ?", tuple(args) + (per, (page - 1) * per))
    return rows, dict(page=page, pages=max(1, -(-total // per)), total=total)

def page_no(): return max(1, request.args.get("page", 1, type=int))

@bp.route("/")
def home():
    subj = q("SELECT DISTINCT cat.name, cat.division, cat.position FROM categories cat JOIN courses c ON c.category_id=cat.id WHERE c.status='published' AND cat.active=1 ORDER BY cat.division, cat.position")
    has_courses = bool(subj)
    if not subj: subj = q("SELECT name, division, position FROM categories WHERE active=1 ORDER BY division, position")
    stats = dict(courses=val("SELECT COUNT(*) FROM courses WHERE status='published'", default=0), lessons=val("SELECT COUNT(*) FROM lessons l JOIN courses c ON c.id=l.course_id WHERE c.status='published'", default=0), subjects=len(set(r["name"] for r in subj)) if has_courses else 0)
    return render_template("public/home.html", home_basic=A.home_subjects("basic"), home_adv=A.home_subjects("advanced"), home_income=A.home_income_courses(), home_pro=A.home_subjects("professional"), hero_data=HERO.public(), ticker=list(dict.fromkeys(r["name"] for r in subj)), stats=stats,
        testimonials=q("SELECT * FROM testimonials WHERE status='published' ORDER BY id DESC LIMIT 6"),
        nuggets=q("SELECT * FROM nuggets WHERE status='published' ORDER BY featured DESC, published_at DESC LIMIT 3"),
        articles=q(f"SELECT a.*, u.full_name AS author, ac.name AS category FROM articles a LEFT JOIN users u ON u.id=a.author_id LEFT JOIN article_categories ac ON ac.id=a.category_id WHERE {ARTICLE_LIVE} ORDER BY COALESCE(a.publish_at,a.created_at) DESC LIMIT 3", (now(),)),
        faqs=q("SELECT * FROM faqs WHERE active=1 ORDER BY position, id LIMIT 6"),
        plans=q("SELECT * FROM plans WHERE active=1 AND price_kobo>0 ORDER BY position"),
        faith_topics=[t for t in F.topics() if t["n"]] if F.has_content() else [])

def _course_list(division=None):
    where, args = ["c.status='published'"], []
    dv = request.args.get("division")
    if division: where.append("c.division=?"); args.append(division)
    elif dv in ("academic", "income", "professional"): where.append("c.division=?"); args.append(dv)
    for k, col in (("category", "c.category_id"), ("subject", "c.subject")):
        v = request.args.get(k)
        if v: where.append(f"{col}=?"); args.append(v)
    lv = request.args.get("level")
    if lv in A.LEVELS: where.append(f"c.division='academic' AND {A.EFFECTIVE}=?"); args.append(lv)
    where.append(f"NOT (c.division='academic' AND {A.EFFECTIVE}='basic' AND c.category_id IS NOT NULL)")      # Basic courses appear under their category
    s = request.args.get("q", "").strip()
    if s: where.append("(c.title LIKE ? OR c.summary LIKE ?)"); args += [f"%{s}%"] * 2
    sql = ("SELECT c.*, cat.name AS category FROM courses c LEFT JOIN categories cat ON cat.id=c.category_id WHERE " + " AND ".join(where) + " ORDER BY c.featured DESC, c.title")
    rows, pg = paginate(sql, args, page_no())
    cats = q("SELECT * FROM categories WHERE active=1 AND (? IS NULL OR division=?) ORDER BY division, level, position, name", (division, division))
    return rows, pg, cats, []

@bp.route("/courses")
def courses(): return _list("all")
@bp.route("/income-skills")
def income(): return _list("income")

@bp.route("/academic")
def academic():
    counts = A.level_counts()
    return render_template("public/academic.html", counts=counts, LV=A.LEVELS)

@bp.route("/professional")
def professional():
    """Professional Development: an independent division (not part of Academic). Sold by subject (programme area): each subject card shows its cover image and saved price; courses are also listed below."""
    page = page_no(); where, args = ["c.division='professional'", "c.status='published'"], []
    area = request.args.get("area", type=int)
    if area: where.append("c.category_id=?"); args.append(area)
    s = request.args.get("q", "").strip()
    if s: where.append("(c.title LIKE ? OR c.summary LIKE ?)"); args += [f"%{s}%"] * 2
    rows, pg = paginate("SELECT c.*, cat.name AS category FROM courses c LEFT JOIN categories cat ON cat.id=c.category_id WHERE " + " AND ".join(where) + " ORDER BY c.featured DESC, c.title", args, page)
    total = val("SELECT COUNT(*) FROM courses WHERE division='professional' AND status='published'", default=0)
    return render_template("public/professional.html", courses=rows, pg=pg, total=total, areas=A.subjects("professional", only_with_courses=True), area=area, LV=A.LEVELS)

@bp.route("/academic/<level>")
def academic_level(level):
    if level == "professional": return redirect(url_for("public.professional", **request.args), 301)      # the old address keeps working
    if level not in A.LEVELS: abort(404)
    return render_template("public/academic_level.html", level=level, info=A.LEVELS[level], subjects=A.subjects(level), other=A.uncategorised_count(level), LV=A.LEVELS)

@bp.route("/academic/<level>/<subject>")
def academic_subject(level, subject):
    if level == "professional": return redirect(url_for("public.professional_subject", subject=subject), 301)
    if level not in A.LEVELS: abort(404)
    return _subject_page(level, subject)

@bp.route("/professional/<subject>")
def professional_subject(subject):
    return _subject_page("professional", subject)

def _subject_page(level, subject):
    """One subject page for Basic, Advanced and Professional Development: its saved price, a buy button, and every course/topic/lesson the subject unlocks."""
    page = page_no()
    if level == "professional": where, args = ["c.division='professional'", "c.status='published'"], []
    else: where, args = ["c.division='academic'", "c.status='published'", f"{A.EFFECTIVE}=?"], [level]
    if subject == "other": cat = None; where.append("c.category_id IS NULL")
    else:
        cat = A.find_subject(level, subject) or abort(404); where.append("c.category_id=?"); args.append(cat["id"])
    s2 = request.args.get("q", "").strip()
    if s2: where.append("(c.title LIKE ? OR c.summary LIKE ?)"); args += [f"%{s2}%"] * 2
    rows, pg = paginate("SELECT c.*, cat.name AS category FROM courses c LEFT JOIN categories cat ON cat.id=c.category_id WHERE " + " AND ".join(where) + " ORDER BY c.featured DESC, c.title", args, page)
    uid = g.user["id"] if g.user else None
    owned = bool(uid and cat and access.subject_entitled(uid, cat["id"]))
    priced = bool(cat and (cat["price_kobo"] or 0) > 0)
    subscribed = bool(uid and cat and level == "basic" and access.subscription_status(uid).get("basic"))      # a Basic subscription unlocks the whole Basic subject
    contents = A.category_contents(cat["id"]) if cat and (priced or level == "basic") else None
    unlocked = {x["c"]["id"] for x in contents if access.course_access(uid, x["c"])} if contents and uid else set()      # per course, so subscriptions stay independent
    plans = q("SELECT * FROM plans WHERE active=1 AND price_kobo>0 AND division='academic' AND level=? ORDER BY position", (level,)) if level in ("basic", "advanced") else []
    return render_template("public/academic_subject.html", level=level, info=A.ALL[level], cat=cat, courses=rows, pg=pg, LV=A.LEVELS, owned=owned, priced=priced, subscribed=subscribed, contents=contents, unlocked=unlocked, plans=plans)

def _list(which):
    div = None if which == "all" else which
    cat_arg = request.args.get("category", type=int)
    if cat_arg and val("SELECT 1 FROM categories WHERE id=? AND division='academic' AND level='basic'", (cat_arg,)):
        return redirect(url_for("public.academic_subject", level="basic", subject=A.subject_slug(val("SELECT name FROM categories WHERE id=?", (cat_arg,)))))
    rows, pg, cats, classes = _course_list(div)
    lv = request.args.get("level"); s = request.args.get("q", "").strip()
    basic_cats = A.basic_categories(search=s or None) if which != "income" and lv in (None, "", "basic") and not request.args.get("category") and not request.args.get("subject") else []
    from ..services.content import ct
    titles = {"all": ct("courses.title_all"), "academic": ct("courses.title_academic"), "income": ct("courses.title_income")}
    return render_template("public/courses.html", courses=rows, pg=pg, basic_cats=basic_cats, cats=cats, classes=classes, which=which, title=titles[which], LV=A.LEVELS)

@bp.route("/courses/<slug>")
def course(slug):
    c = q1("SELECT c.*, cat.name AS category, u.full_name AS instructor FROM courses c LEFT JOIN categories cat ON cat.id=c.category_id LEFT JOIN users u ON u.id=c.instructor_id WHERE c.slug=?", (slug,))
    can_preview = g.user and (g.user["role"] == "admin" or (c and c["instructor_id"] == g.user["id"]))
    if not c or (c["status"] != "published" and not can_preview): abort(404)
    lessons = lms.ordered_lessons(c["id"])
    mode = access.course_access(g.user["id"] if g.user else None, c)
    scope = access.course_scope(c)
    plans = (q("SELECT * FROM plans WHERE active=1 AND price_kobo>0 AND division=? AND COALESCE(level,'')=? ORDER BY position", (c["division"], scope if c["division"] == "academic" else ""))
             if c["subscription_eligible"] and scope != "professional" else [])
    subj = access.subject_of(c)      # the priced subject (Basic, Advanced or Professional Development) that sells this course, if any
    tutor = q1("SELECT u.id, u.full_name, u.avatar, u.bio, p.code, p.location FROM users u JOIN tutor_profiles p ON p.user_id=u.id WHERE u.id=? AND u.is_active=1 AND p.status='active'", (c["instructor_id"],)) if c["instructor_id"] else None
    outcomes = [x.strip(" -*\u2022") for x in (c["outcomes"] or "").splitlines() if x.strip(" -*\u2022")]
    objectives = [x.strip(" -*\u2022") for x in (c["objectives"] or "").splitlines() if x.strip(" -*\u2022")]
    return render_template("public/course.html", c=c, subj=subj, lessons=lessons, mode=mode, plans=plans, LV=A.LEVELS, subject_slug=A.subject_slug, tutor=tutor, outcomes=outcomes, objectives=objectives, paths=PW.paths_for_course(c["id"]), requires=PW.requirements(c["id"]), unmet=PW.unmet(g.user["id"], c["id"]) if (g.user and mode) else [], R=R,
                           progress=lms.course_progress(g.user["id"], c["id"]) if g.user and mode else None)

bp.add_url_rule("/course/<slug>", endpoint="course_alias", view_func=course)      # the shareable form of the link: /course/<slug>?ref=<tutor code>

@bp.route("/pricing")
def pricing():
    courses = q(f"SELECT c.*, {A.EFFECTIVE} AS lvl FROM courses c WHERE c.status='published' AND c.price_kobo>0 ORDER BY c.division, c.title")
    single = [c for c in courses if not access.sells_by_subject(c)]       # courses bought on their own (Income Skills always; others only when their subject has no price)
    return render_template("public/pricing.html", plans=q("SELECT * FROM plans WHERE active=1 ORDER BY division, level, position"),
        subjects=A.priced_subjects("basic"), subjects_adv=A.priced_subjects("advanced"), subjects_pro=A.priced_subjects("professional"),
        adv=[c for c in single if c["division"] == "academic" and c["lvl"] == "advanced"],
        pro=[c for c in single if c["division"] == "professional"],
        income=[c for c in courses if c["division"] == "income"],
        basic_legacy=[c for c in single if c["division"] == "academic" and c["lvl"] == "basic"])

@bp.route("/blog")
def blog():
    where, args = [ARTICLE_LIVE], [now()]
    c = request.args.get("category")
    if c: where.append("a.category_id=(SELECT id FROM article_categories WHERE slug=?)"); args.append(c)
    rows, pg = paginate("SELECT a.*, u.full_name AS author, ac.name AS category FROM articles a LEFT JOIN users u ON u.id=a.author_id LEFT JOIN article_categories ac ON ac.id=a.category_id WHERE "
                        + " AND ".join(where) + " ORDER BY COALESCE(a.publish_at,a.created_at) DESC", args, page_no())
    return render_template("public/blog.html", articles=rows, pg=pg, cats=q("SELECT * FROM article_categories ORDER BY name"))

@bp.route("/blog/<slug>")
def article(slug):
    a = q1(f"SELECT a.*, u.full_name AS author, u.bio AS author_bio, ac.name AS category FROM articles a LEFT JOIN users u ON u.id=a.author_id LEFT JOIN article_categories ac ON ac.id=a.category_id WHERE a.slug=? AND {ARTICLE_LIVE}", (slug, now()))
    if not a: abort(404)
    return render_template("public/article.html", a=a)

@bp.route("/nuggets")
def nuggets():
    rows, pg = paginate("SELECT * FROM nuggets WHERE status='published' ORDER BY featured DESC, published_at DESC", [], page_no())
    return render_template("public/nuggets.html", nuggets=rows, pg=pg)

@bp.route("/nuggets/<slug>")
def nugget(slug):
    n = q1("SELECT * FROM nuggets WHERE slug=? AND status='published'", (slug,))
    if not n: abort(404)
    return render_template("public/nugget.html", n=n)

@bp.route("/testimonials")
def testimonials():
    return render_template("public/testimonials.html", items=q("SELECT * FROM testimonials WHERE status='published' ORDER BY id DESC"))

@bp.route("/faq")
def faq():
    rows = q("SELECT * FROM faqs WHERE active=1 ORDER BY position, id")
    ld = {"@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [{"@type": "Question", "name": f["question"], "acceptedAnswer": {"@type": "Answer", "text": f["answer"]}} for f in rows]}
    return render_template("public/faq.html", faqs=rows, ld=ld)

def _page(slug):
    p = q1("SELECT * FROM pages WHERE slug=?", (slug,))
    if not p: abort(404)
    return render_template("public/page.html", p=p)
@bp.route("/about")
def about(): return _page("about")
@bp.route("/privacy-policy")
def privacy(): return _page("privacy-policy")
@bp.route("/terms-and-conditions")
def terms(): return _page("terms-and-conditions")
@bp.route("/refund-policy")
def refund(): return _page("refund-policy")

@bp.route("/healthz")
def healthz():
    """Uptime/health probe for monitors and deploy scripts: proves the app is up and can read its database. Reveals nothing else."""
    from ..db import val
    try: ok = val("SELECT 1") == 1
    except Exception: ok = False
    r = jsonify(ok=ok); r.status_code = 200 if ok else 503; r.headers["Cache-Control"] = "no-store"; return r

@bp.route("/.well-known/assetlinks.json")
def assetlinks():
    """Android App Links: lets https://dagbadigitalacademy.com/courses/... open in the app. Needs mobile.android_package + mobile.android_sha256 (comma separated) in settings."""
    from ..services import settings as S
    pkg = S.get("mobile.android_package", ""); fps = [x.strip() for x in S.get("mobile.android_sha256", "").split(",") if x.strip()]
    if not (pkg and fps): abort(404)
    return jsonify([{"relation": ["delegate_permission/common.handle_all_urls"], "target": {"namespace": "android_app", "package_name": pkg, "sha256_cert_fingerprints": fps}}])

@bp.route("/.well-known/apple-app-site-association")
def apple_aasa():
    """iOS Universal Links. Needs mobile.apple_app_id = '<TEAMID>.<bundle id>' in settings."""
    from ..services import settings as S
    app_id = S.get("mobile.apple_app_id", "")
    if not app_id: abort(404)
    r = jsonify({"applinks": {"details": [{"appIDs": [app_id], "components": [{"/": "/courses/*"}, {"/": "/blog/*"}, {"/": "/learn/*"}, {"/": "/faith/*"}, {"/": "/paths/*"}]}]}})
    r.headers["Content-Type"] = "application/json"; return r

@bp.route("/delete-account")
def delete_account_info():
    """Public account-deletion page. Google Play requires a web URL where people can learn how to delete their account and data."""
    from ..services import settings as S
    email = S.get("contact.email", "")
    body = ("## Delete your account in the app\n\nOpen the Dagba Digital Academy app, go to Profile, then Privacy and security, then Delete account. Enter your password to confirm. "
            "This signs you out on every device and removes your personal details immediately.\n\n"
            "## Cannot use the app?\n\nSend a deletion request from the email address on your account" + (f" to {email}" if email else " through our Contact page") + ". We will confirm your identity and delete the account.\n\n"
            "## What is deleted and what is kept\n\nDeleted: your name, email address, phone number, profile details, notifications and sign-in sessions. Your account is closed and cannot be recovered.\n\n"
            "Kept: payment, instructor-earnings and refund records (required for accounting and legal purposes); these are no longer linked to your name or email. "
            "Also kept: certificates you earned, exactly as issued (they show the name printed on them) so that employers and others can still verify them. Ask us if you want a certificate revoked. Staff and tutor accounts are closed by the academy on request.")
    return render_template("public/page.html", p=dict(title="Delete your account", body=body, seo_description="How to delete your Dagba Digital Academy account and data."))

CORE_PAGES = ("about", "privacy-policy", "terms-and-conditions", "refund-policy")

@bp.route("/p/<slug>")
def custom_page(slug):
    if slug in CORE_PAGES: return redirect("/" + slug)
    return _page(slug)

@bp.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        f = request.form
        name, email, msg = f.get("name", "").strip(), f.get("email", "").strip(), f.get("message", "").strip()
        if f.get("website"):  # honeypot
            return redirect(url_for("public.contact"))
        if not (name and re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email) and msg):
            flash("Please fill in your name, a valid email and your message.", "error")
        elif rate_limited(f"contact:{client_ip()}", 5, 3600):
            flash("Too many messages. Please try again later.", "error")
        else:
            ex("INSERT INTO contact_messages(name,email,subject,message) VALUES (?,?,?,?)", (name[:120], email[:200], f.get("subject", "")[:200], msg[:5000]))
            notify_staff("settings.manage", "New contact message", f"{name}: {f.get('subject', '')}", "/staff/messages", "info")
            from ..services.content import ct; flash(ct("contact.success"), "success"); return redirect(url_for("public.contact"))
    return render_template("public/contact.html")

@bp.route("/newsletter", methods=["POST"])
def newsletter():
    email = request.form.get("email", "").strip()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email): flash("Enter a valid email address.", "error")
    elif rate_limited(f"news:{client_ip()}", 10, 3600): flash("Too many attempts.", "error")
    else:
        ex("INSERT OR IGNORE INTO newsletter_subscribers(email) VALUES (?)", (email[:200],)); flash("You are subscribed. Thank you!", "success")
    return redirect(request.referrer or url_for("public.home"))

@bp.route("/verify", methods=["GET", "POST"])
def verify_form():
    if request.method == "POST": return redirect(url_for("public.verify", cert_id=request.form.get("cert_id", "").strip().upper()))
    return render_template("public/verify.html", cert=None, searched=False)

@bp.route("/verify/<cert_id>")
def verify(cert_id):
    c = q1("SELECT * FROM certificates WHERE cert_id=?", (cert_id.upper(),))
    return render_template("public/verify.html", cert=c, searched=True, cert_id=cert_id)

@bp.route("/media/<path:name>")
def media(name):
    if not name.lower().endswith((".webp", ".jpg", ".png")): abort(404)
    return send_from_directory(current_app.config["PUBLIC_DIR"], name, max_age=86400)

@bp.route("/theme.css")
def theme():
    from ..services import theme as TH
    age = 31536000 if request.args.get("v") else 300          # the link carries a revision number, so a saved change shows immediately
    return Response(TH.css(), mimetype="text/css", headers={"Cache-Control": f"public, max-age={age}"})

@bp.route("/robots.txt")
def robots():
    return Response("User-agent: *\nDisallow: /student\nDisallow: /staff\nDisallow: /learn\nDisallow: /pay\nDisallow: /checkout\nDisallow: /account\nDisallow: /login\nDisallow: /register\nDisallow: /notifications\nDisallow: /faith/my\n"
                    f"Sitemap: {current_app.config['SITE_URL']}/sitemap.xml\n", mimetype="text/plain")

@bp.route("/sitemap.xml")
def sitemap():
    base = current_app.config["SITE_URL"]
    urls = [base + p for p in ("/", "/courses", "/academic", "/income-skills", "/professional", "/pricing", "/blog", "/nuggets", "/testimonials", "/faq", "/contact", "/about", "/privacy-policy", "/terms-and-conditions", "/refund-policy", "/verify")]
    urls += [f"{base}/courses/{r['slug']}" for r in q("SELECT slug FROM courses WHERE status='published'")]
    urls += [f"{base}/blog/{r['slug']}" for r in q(f"SELECT slug FROM articles a WHERE {ARTICLE_LIVE}", (now(),))]
    urls += [f"{base}/nuggets/{r['slug']}" for r in q("SELECT slug FROM nuggets WHERE status='published'")]
    urls += [f"{base}/p/{r['slug']}" for r in q("SELECT slug FROM pages") if r["slug"] not in CORE_PAGES]
    urls += [f"{base}/academic/{lv}" for lv in A.LEVELS] + [f"{base}/academic/{lv}/{x['slug']}" for lv in ("basic", "advanced") for x in A.subjects(lv, only_with_courses=True)]
    urls += [f"{base}/professional/{x['slug']}" for x in A.subjects("professional", only_with_courses=True)]
    urls += [base + "/faith", base + "/faith/browse"] + [f"{base}/faith/topic/{t['slug']}" for t in F.topics() if t["n"]]
    urls += [f"{base}/faith/series/{r['slug']}" for r in q("SELECT slug FROM faith_series s WHERE s.status='published' AND EXISTS (SELECT 1 FROM faith_items i WHERE i.series_id=s.id AND i.status='published')")]
    urls += [f"{base}/faith/lesson/{r['slug']}" for r in q("SELECT slug FROM faith_items WHERE status='published' AND access='public'")]
    xml = '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + "".join(f"<url><loc>{u}</loc></url>" for u in urls) + "</urlset>"
    return Response(xml, mimetype="application/xml")
