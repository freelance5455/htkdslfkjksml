import re, hashlib, secrets, logging
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, g, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from ..db import q, q1, ex, val
from ..util import now, now_dt, add_days
from ..security import login_required, rate_limited, client_ip
from ..services import audit, affiliates, tutors, avatars, uploads
from ..services.notify import notify_staff, send_email
from ..services.access import expire_notifications

bp = Blueprint("auth", __name__)
EMAIL = re.compile(r"[^@\s]+@[^@\s]+\.[^@\s]+")
DUMMY_HASH = generate_password_hash("not-a-real-password")
CLASSES = ["", "JSS1", "JSS2", "JSS3", "SS1", "SS2", "SS3", "Adult / Professional"]

def check_password_strength(pw, email="", name=""):
    if len(pw) < 8: return "Password must be at least 8 characters."
    if pw.lower() in ("password", "12345678", "123456789", "qwertyui", "password1") or pw.lower() == email.lower(): return "That password is too easy to guess."
    if not (re.search(r"[A-Za-z]", pw) and re.search(r"\d", pw)): return "Use a mix of letters and numbers."
    return None

def safe_next(n):
    return n if n and n.startswith("/") and not n.startswith("//") and "\\" not in n else None

def _login(u):
    _ck = None
    try:
        from ..services import tutors as _T
        _ck = _T.read_cookie()
    except Exception: pass
    session.clear(); session["uid"] = u["id"]; session.permanent = True
    ex("UPDATE users SET last_login_at=? WHERE id=?", (now(), u["id"]))
    if _ck: tutors.claim_cookie(u)                      # keep a tutor referral the visitor followed before logging in (30-day window)
    try: expire_notifications()
    except Exception: pass

def home_for(u): return url_for("staff.dashboard") if u["role"] in ("admin", "instructor", "writer") else url_for("student.dashboard")

@bp.route("/register", methods=["GET", "POST"])
def register():
    if g.user: return redirect(home_for(g.user))
    if request.method == "POST":
        f = request.form; email = f.get("email", "").strip().lower(); name = f.get("full_name", "").strip()
        err = None
        if not name or len(name) > 120: err = "Please enter your full name."
        elif not EMAIL.fullmatch(email): err = "Enter a valid email address."
        elif f.get("password") != f.get("password2"): err = "Passwords do not match."
        else: err = check_password_strength(f.get("password", ""), email, name)
        if not err and rate_limited(f"reg:{client_ip()}", 10, 3600): err = "Too many sign-ups from this network. Try again later."
        if not err and val("SELECT 1 FROM users WHERE email=?", (email,)): err = "An account with this email already exists. Try logging in."
        if err: flash(err, "error")
        else:
            cl = f.get("class_level", "") if f.get("class_level", "") in CLASSES else ""
            uid = ex("INSERT INTO users(email,password_hash,full_name,phone,class_level) VALUES (?,?,?,?,?)",
                     (email, generate_password_hash(f["password"]), name, f.get("phone", "").strip()[:30], cl))
            audit.log("user.registered", "user", uid, email, actor={"id": uid, "full_name": name, "email": email})
            try: affiliates.attach_referral(uid, name)       # lock this new account to the affiliate whose link they followed (never blocks sign-up)
            except Exception: logging.getLogger("dagba").exception("referral attach failed")
            try:
                from ..services import prelaunch as _PL
                if _PL.restricting(): _PL.record_account(uid, email, name)       # an account made before launch is also an early registrant
            except Exception: logging.getLogger("dagba").exception("prelaunch registration record failed")
            notify_staff("users.manage", "New student registered", f"{name} ({email})", f"/staff/users/{uid}", "info")
            _login(q1("SELECT * FROM users WHERE id=?", (uid,)))
            flash("Welcome to Dagba Digital Academy!", "success"); return redirect(safe_next(request.args.get("next") or request.form.get("next")) or url_for("student.dashboard"))
    return render_template("auth/register.html", classes=CLASSES, next=safe_next(request.args.get("next")))

@bp.route("/login", methods=["GET", "POST"])
def login():
    if g.user: return redirect(home_for(g.user))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower(); pw = request.form.get("password", "")
        if rate_limited(f"login:{client_ip()}:{email}", 8, 900) or rate_limited(f"loginip:{client_ip()}", 40, 900):
            flash("Too many login attempts. Please wait 15 minutes and try again.", "error")
        else:
            u = q1("SELECT * FROM users WHERE email=?", (email,))
            ok = check_password_hash(u["password_hash"] if u else DUMMY_HASH, pw)
            if u and ok and u["is_active"]:
                _login(u); audit.log("auth.login", "user", u["id"], actor=u)
                return redirect(safe_next(request.args.get("next")) or home_for(u))
            flash("Incorrect email or password." if not (u and ok) else "This account has been deactivated. Contact support.", "error")
    return render_template("auth/login.html")

@bp.route("/logout", methods=["POST"])
def logout():
    session.clear(); flash("You have been logged out.", "info"); return redirect(url_for("public.home"))

@bp.route("/forgot-password", methods=["GET", "POST"])
def forgot():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        if rate_limited(f"forgot:{client_ip()}", 5, 3600): flash("Too many requests. Try again later.", "error")
        else:
            u = q1("SELECT * FROM users WHERE email=? AND is_active=1", (email,))
            if u:
                link = make_reset_link(u["id"])
                sent = send_email(u["email"], "Reset your Dagba Digital Academy password", f"Use this link within 1 hour to set a new password:\n{link}\n\nIf you did not ask for this, ignore this email.")
                if not sent: logging.getLogger("dagba").warning("Email not configured/failed; reset for user %s can be generated by an administrator.", u["id"])
            flash("If that email has an account, a reset link has been sent. If you do not receive it, contact support and an administrator can help.", "info")
            return redirect(url_for("auth.login"))
    return render_template("auth/forgot.html")

def make_reset_link(uid):
    token = secrets.token_urlsafe(32)
    ex("INSERT INTO password_resets(user_id, token_hash, expires_at) VALUES (?,?,?)", (uid, hashlib.sha256(token.encode()).hexdigest(), add_days(now_dt(), 0.0416667)))
    return f"{current_app.config['SITE_URL']}/reset-password/{token}"

@bp.route("/reset-password/<token>", methods=["GET", "POST"])
def reset(token):
    r = q1("SELECT * FROM password_resets WHERE token_hash=? AND used_at IS NULL AND expires_at>?", (hashlib.sha256(token.encode()).hexdigest(), now()))
    if not r:
        flash("This reset link is invalid or has expired.", "error"); return redirect(url_for("auth.forgot"))
    if request.method == "POST":
        u = q1("SELECT * FROM users WHERE id=?", (r["user_id"],))
        pw = request.form.get("password", "")
        err = "Passwords do not match." if pw != request.form.get("password2") else check_password_strength(pw, u["email"])
        if err: flash(err, "error")
        else:
            ex("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(pw), u["id"]))
            ex("UPDATE password_resets SET used_at=? WHERE user_id=? AND used_at IS NULL", (now(), u["id"]))
            audit.log("auth.password_reset", "user", u["id"], actor=u)
            flash("Password updated. You can now log in.", "success"); return redirect(url_for("auth.login"))
    return render_template("auth/reset.html", token=token)

@bp.route("/account", methods=["GET", "POST"])
@login_required
def account():
    if request.method == "POST":
        f = request.form
        if f.get("action") in ("avatar", "avatar_remove"):
            if rate_limited(f"avatar:{g.user['id']}", 20, 3600): flash("Too many picture changes. Please try again later.", "error")
            elif f["action"] == "avatar_remove": flash("Profile picture removed." if avatars.remove(g.user["id"]) else "You have no profile picture.", "success")
            else:
                try:
                    fs = request.files.get("picture")
                    if not fs or not fs.filename: raise uploads.UploadError("Choose a picture first.")
                    avatars.save(g.user["id"], fs); flash("Profile picture updated.", "success")
                except uploads.UploadError as e: flash(str(e), "error")
        elif f.get("action") == "profile":
            name = f.get("full_name", "").strip()
            if not name: flash("Name is required.", "error")
            else:
                cl = f.get("class_level", "") if f.get("class_level", "") in CLASSES else ""
                ex("UPDATE users SET full_name=?, phone=?, class_level=?, bio=? WHERE id=?", (name[:120], f.get("phone", "")[:30], cl, f.get("bio", "")[:1000], g.user["id"]))
                flash("Profile updated.", "success")
        else:
            if not check_password_hash(g.user["password_hash"], f.get("current", "")): flash("Current password is incorrect.", "error")
            elif f.get("password") != f.get("password2"): flash("New passwords do not match.", "error")
            else:
                err = check_password_strength(f.get("password", ""), g.user["email"])
                if err: flash(err, "error")
                else:
                    ex("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(f["password"]), g.user["id"]))
                    audit.log("auth.password_changed", "user", g.user["id"]); flash("Password changed.", "success")
        return redirect(url_for("auth.account"))
    return render_template("auth/account.html", classes=CLASSES)
