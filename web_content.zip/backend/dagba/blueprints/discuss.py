"""Discussions: the course-wide page, posting/removing (students, instructors, admins) and the moderation list for instructors and admins."""
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort
from ..db import q, q1
from ..security import login_required
from ..services import discussions as D

bp = Blueprint("discuss", __name__)

def _course(slug): return q1("SELECT * FROM courses WHERE slug=?", (slug,)) or abort(404)

def _back(c, lesson_id, anchor=""):
    return redirect((url_for("student.lesson", slug=c["slug"], lid=lesson_id) if lesson_id else url_for("discuss.course_page", slug=c["slug"])) + anchor)

@bp.route("/learn/<slug>/discussion")
@login_required
def course_page(slug):
    c = _course(slug)
    if not D.can_view(g.user, c): flash("You need access to this course to join its discussion.", "info"); return redirect(url_for("public.course", slug=slug))
    return render_template("learn/discussion.html", c=c, disc=D.threads(c, None, g.user), can_post=True, can_mod=D.can_moderate(g.user, c), lesson=None)

@bp.route("/learn/<slug>/discuss", methods=["POST"])
@login_required
def create(slug):
    c = _course(slug); lid = request.form.get("lesson_id", type=int); parent = request.form.get("parent_id", type=int)
    try: p = D.post(g.user, c, request.form.get("body", ""), lid, parent); flash("Reply posted." if parent else "Question posted.", "success"); return _back(c, lid, f"#post-{p['id']}")
    except D.DiscussionError as e: flash(str(e), "error"); return _back(c, lid, "#discussion")

@bp.route("/learn/<slug>/discuss/<int:pid>/delete", methods=["POST"])
@login_required
def delete(slug, pid):
    c = _course(slug); p = q1("SELECT * FROM discussion_posts WHERE id=? AND course_id=?", (pid, c["id"])) or abort(404)
    try: D.remove(g.user, pid, request.form.get("reason", "")); flash("Post removed.", "success")
    except D.DiscussionError as e: flash(str(e), "error")
    return _back(c, p["lesson_id"], "#discussion")

# ------------------------------------------------------------------ moderation (instructor: own courses; admin: everything)
def _moderator():
    if g.user["role"] == "instructor" or D._perm(g.user): return
    abort(403)

@bp.route("/staff/discussions")
@login_required
def moderate():
    _moderator(); rows, total, page, pages = D.moderation_list(g.user, request.args)
    return render_template("staff/discussions.html", rows=rows, total=total, pg=dict(page=page, pages=pages), courses=D.moderated_courses(g.user),
                           f=dict(course=request.args.get("course", type=int) or "", status=request.args.get("status", ""), q=request.args.get("q", "")))

@bp.route("/staff/discussions/<int:pid>/<action>", methods=["POST"])
@login_required
def act(pid, action):
    _moderator()
    if action not in ("remove", "restore"): abort(404)
    try:
        (D.remove(g.user, pid, request.form.get("reason", "")) if action == "remove" else D.restore(g.user, pid)); flash("Post removed." if action == "remove" else "Post restored.", "success")
    except D.DiscussionError as e: flash(str(e), "error")
    return redirect(request.referrer if request.referrer and request.referrer.startswith(request.host_url) else url_for("discuss.moderate"))
