"""Tutor MOU pages.
 admin (permission mou.manage)        /staff/mou, /staff/mou/draft..., /staff/mou/versions/<id>
 admin (tutors.manage or mou.manage)  /staff/mou/records[.csv], /staff/mou/agreements/<reference>[/pdf]
 owner (any logged-in person)         /staff/tutor/agreement[/<reference>[/pdf]]   only their OWN agreements (anything else is a 404)
 applicant                            /tutor/apply/mou[.pdf]                      the current published MOU, for reading and downloading unsigned
Every agreement is addressed by its random reference, checked against the signed-in user on every request, and sent with no-store caching."""
import csv, io
from urllib.parse import urlencode
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, Response
from ..db import q, q1, val
from ..security import login_required, has_perm
from ..services import mou as M, audit

bp = Blueprint("mou", __name__)

def _manage():
    if not has_perm("mou.manage"): abort(403)
def _review():
    if not M.can_review_records(): abort(403)

def _pdf(data, filename):
    return Response(data, mimetype="application/pdf", headers={"Content-Disposition": f'attachment; filename="{filename}"', "Cache-Control": "no-store, private", "X-Content-Type-Options": "nosniff"})

# ------------------------------------------------------------------ admin: Tutor MOU Management
@bp.route("/staff/mou")
@login_required
def admin_index():
    _manage()
    cur = M.current(); d = M.draft(); vs = M.versions()
    return render_template("staff/mou_index.html", cur=cur, draft=d, versions=vs, signed_cur=M.count_signed(cur["id"]) if cur else 0, total_signed=val("SELECT COUNT(*) FROM mou_acceptances", default=0), M=M)

@bp.route("/staff/mou/draft/new", methods=["POST"])
@login_required
def admin_new_draft():
    _manage()
    try: M.create_draft(g.user); flash("A draft is ready. Nothing changes for applicants until you publish it.", "success")
    except M.MouError as e: flash(str(e), "error")
    return redirect(url_for("mou.admin_edit"))

@bp.route("/staff/mou/draft", methods=["GET", "POST"])
@login_required
def admin_edit():
    _manage(); d = M.draft()
    if not d: flash("There is no draft yet. Start a new version first.", "info"); return redirect(url_for("mou.admin_index"))
    if request.method == "POST":
        act = request.form.get("action")
        try:
            if act == "publish":
                v = M.publish(g.user, request.form); flash(f"Published as version {v['version_label']}. New applicants will now sign this version; everyone who signed an earlier version keeps exactly what they signed.", "success")
                return redirect(url_for("mou.admin_index"))
            elif act == "save": M.save_draft(g.user, request.form); flash("Draft saved. Applicants still see the published version.", "success")
            elif act == "preview": M.save_draft(g.user, request.form); return redirect(url_for("mou.admin_preview"))
            else: abort(400)
        except M.MouError as e: flash(str(e), "error")
        return redirect(url_for("mou.admin_edit"))
    return render_template("staff/mou_edit.html", d=d, cur=M.current(), minor=M.next_label("minor"), major=M.next_label("major"), M=M)

@bp.route("/staff/mou/draft/discard", methods=["POST"])
@login_required
def admin_discard():
    _manage()
    try: M.discard_draft(g.user); flash("Draft discarded. The published version is unchanged.", "success")
    except M.MouError as e: flash(str(e), "error")
    return redirect(url_for("mou.admin_index"))

@bp.route("/staff/mou/draft/preview")
@login_required
def admin_preview():
    _manage(); d = M.draft() or abort(404)
    return render_template("staff/mou_view.html", v=d, preview=True, signed=0, M=M)

@bp.route("/staff/mou/versions/<int:vid>")
@login_required
def admin_version(vid):
    v = M.get_version(vid) or abort(404)
    _manage() if v["status"] == "draft" else _review()
    return render_template("staff/mou_view.html", v=v, preview=v["status"] == "draft", signed=M.count_signed(vid), M=M)

@bp.route("/staff/mou/versions/<int:vid>/pdf")
@login_required
def admin_version_pdf(vid):
    v = M.get_version(vid) or abort(404)
    _manage() if v["status"] == "draft" else _review()
    audit.log("mou.version_pdf", "mou_version", vid, v["version_label"] or "draft")
    return _pdf(M.version_pdf(v), M.pdf_filename(v=v))

# ------------------------------------------------------------------ admin: the register of signed agreements
def _filters():
    return dict(q=(request.args.get("q") or "").strip()[:100], version=request.args.get("version", type=int) or "", status=request.args.get("status", ""), frm=request.args.get("from", ""), to=request.args.get("to", ""), account=request.args.get("account", ""))

@bp.route("/staff/mou/records")
@login_required
def records():
    _review(); sql, a = M.records_query(request.args); page = max(1, request.args.get("page", 1, type=int)); per = 30
    total = val(f"SELECT COUNT(*) FROM ({sql})", a, 0); rows = q(sql + " LIMIT ? OFFSET ?", a + (per, (page - 1) * per))
    cur = M.current(); cid = cur["id"] if cur else -1
    items = [dict(r=r, st=M.status_of(r, cid)) for r in rows]
    qs = urlencode({k: v for k, v in request.args.items() if k != "page" and v})
    return render_template("staff/mou_records.html", items=items, total=total, pg=dict(page=page, pages=max(1, -(-total // per))), f=_filters(), versions=q("SELECT id, version_label FROM mou_versions WHERE status='published' ORDER BY version_major DESC, version_minor DESC"), qs=qs, M=M)

@bp.route("/staff/mou/records.csv")
@login_required
def records_csv():
    _review(); sql, a = M.records_query(request.args); cur = M.current(); cid = cur["id"] if cur else -1
    safe = lambda v: "'" + v if isinstance(v, str) and v[:1] in "=+-@\t\r" else v
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["Reference", "Name", "Email", "User ID", "Account type", "MOU version", "Signed (UTC)", "Signature as typed", "Status", "Content SHA-256", "Record SHA-256"])
    for r in q(sql + " LIMIT 20000", a):
        w.writerow([safe(x) for x in [r["reference"], r["full_name"], r["email"], r["user_id"], "Tutor" if r["account_role"] == "instructor" else "Applicant", r["version_label"], r["accepted_at"], r["signature"], M.status_of(r, cid)[0], r["content_hash"], r["record_hash"]]])
    audit.log("mou.register_exported", "export", "mou-register.csv", request.query_string.decode()[:200])
    return Response(buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=signed-mou-register.csv", "Cache-Control": "no-store, private"})

def _admin_agreement(ref):
    _review(); acc = M.by_reference(ref) or abort(404)
    return acc

@bp.route("/staff/mou/agreements/<ref>")
@login_required
def admin_agreement(ref):
    acc = _admin_agreement(ref)
    audit.log("mou.agreement_viewed", "mou_acceptance", acc["id"], f"{acc['reference']} (user {acc['user_id']})")
    return render_template("staff/mou_agreement.html", acc=acc, st=M.status_of(acc), admin=True, M=M, u=q1("SELECT id, full_name, email, role FROM users WHERE id=?", (acc["user_id"],)),
                           pdf=url_for("mou.admin_agreement_pdf", ref=acc["reference"]), back=url_for("mou.records"))

@bp.route("/staff/mou/agreements/<ref>/pdf")
@login_required
def admin_agreement_pdf(ref):
    acc = _admin_agreement(ref)
    audit.log("mou.agreement_downloaded", "mou_acceptance", acc["id"], f"{acc['reference']} (user {acc['user_id']})")
    return _pdf(M.agreement_pdf(acc), M.pdf_filename(acc=acc))

# ------------------------------------------------------------------ the signed-in person's OWN agreements (tutor dashboard: My Agreement / Signed MOU)
def _own(ref):
    acc = M.by_reference(ref)
    if not acc or acc["user_id"] != g.user["id"]: abort(404)        # someone else's agreement looks exactly like one that does not exist
    return acc

@bp.route("/staff/tutor/agreement")
@login_required
def my_agreements():
    rows = M.for_user(g.user["id"]); cur = M.current(); cid = cur["id"] if cur else -1
    if not rows and g.user["role"] not in ("instructor",): abort(403)
    return render_template("staff/my_agreement.html", items=[dict(r=r, st=M.status_of(r, cid)) for r in rows], newer=bool(rows and cur and rows[0]["version_id"] != cur["id"]), cur=cur, M=M)

@bp.route("/staff/tutor/agreement/<ref>")
@login_required
def my_agreement(ref):
    acc = _own(ref)
    return render_template("staff/mou_agreement.html", acc=acc, st=M.status_of(acc), admin=False, M=M, u=g.user, pdf=url_for("mou.my_agreement_pdf", ref=acc["reference"]), back=url_for("mou.my_agreements"))

@bp.route("/staff/tutor/agreement/<ref>/pdf")
@login_required
def my_agreement_pdf(ref):
    acc = _own(ref)
    audit.log("mou.agreement_downloaded", "mou_acceptance", acc["id"], f"{acc['reference']} (own copy)")
    return _pdf(M.agreement_pdf(acc), M.pdf_filename(acc=acc))

# ------------------------------------------------------------------ applicant: read / download the current published MOU
@bp.route("/tutor/apply/mou")
@login_required
def reader():
    v = M.current()
    if v and g.user["role"] == "student": M.record_view(g.user, v)       # being shown the document is what the server checks at submission
    return render_template("tutor/mou_reader.html", v=v, signed=M.already_signed(g.user["id"], v["id"]) if v else None, M=M)

@bp.route("/tutor/apply/mou.pdf")
@login_required
def reader_pdf():
    v = M.current() or abort(404)
    if g.user["role"] == "student": M.record_view(g.user, v)
    return _pdf(M.version_pdf(v), M.pdf_filename(v=v))
