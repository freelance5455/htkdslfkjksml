import os, sqlite3
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, current_app
from werkzeug.security import generate_password_hash
from ..db import q, q1, ex, val
from ..util import now, unique_slug, parse_naira, naira, parse_ts
from ..security import login_required, role_required, perm_required, has_perm, is_staff, PERMISSIONS
from ..services import uploads, audit, settings as S, paths as P, faith as FA
from ..services.notify import notify, notify_staff
from .auth import check_password_strength, make_reset_link

bp = Blueprint("staff", __name__, url_prefix="/staff")

# ---------------------------------------------------------------- option providers
def o_div(u): return [("academic", "Academic"), ("income", "Income Skills"), ("professional", "Professional Development")]
def _cx(): return P.valid(request.args.get("ctx")) if request else None
def o_cats(u):
    cx = _cx(); w, a = P.category_clause(cx) if cx else ("1=1", ())
    return [("", "(none)")] + [(r["id"], (r["name"] if cx else f"{r['division'].title()} - {(r['level'].title() + ' - ') if r['level'] else ''}{r['name']}")) for r in q(f"SELECT * FROM categories WHERE {w} ORDER BY division, level, name", a)]
def o_plan_level(u): return [("", "(Income Skills: none)"), ("basic", "Academic: Basic"), ("advanced", "Academic: Advanced")]
def o_level(u): return [("", "(Income Skills / Professional Development: none)"), ("basic", "Academic: Basic (secondary school)"), ("advanced", "Academic: Advanced (university)")]
def o_instr(u): return [("", "(unassigned)")] + [(r["id"], f"{r['full_name']} ({r['role']})") for r in q("SELECT * FROM users WHERE role IN ('instructor','admin') AND is_active=1 ORDER BY full_name")]
def _cw(u, alias="c"):
    """WHERE parts limiting courses to the active path and (for instructors) to their own courses."""
    parts, a = ["1=1"], ()
    cx = _cx()
    if cx: cs, ca = P.course_clause(cx, alias); parts.append(cs); a += ca
    if u["role"] == "instructor": parts.append(f"{alias}.instructor_id=?"); a += (u["id"],)
    return " AND ".join(parts), a
def o_courses(u):
    w, a = _cw(u)
    return [(r["id"], r["title"]) for r in q(f"SELECT c.id, c.title FROM courses c WHERE {w} ORDER BY c.title", a)]
def o_modules(u):
    w, a = _cw(u)
    return [("", "(none)")] + [(r["id"], f"{r['ct']} / {r['title']}") for r in q(f"SELECT m.id, m.title, c.title ct FROM modules m JOIN courses c ON c.id=m.course_id WHERE {w} ORDER BY c.title, m.position", a)]
def o_quizzes(u):
    w, a = _cw(u)
    return [(r["id"], f"{r['ct']} / {r['title']}") for r in q(f"SELECT z.id, z.title, c.title ct FROM quizzes z JOIN courses c ON c.id=z.course_id WHERE {w} ORDER BY c.title, z.position", a)]
def o_ftopics(u): return [(r["id"], r["name"]) for r in q("SELECT * FROM faith_topics ORDER BY position, name")]
def o_fstatus(u): return [("draft", "Draft")] + ([("published", "Published"), ("archived", "Archived")] if u["role"] == "admin" else [])
def o_acats(u): return [("", "(none)")] + [(r["id"], r["name"]) for r in q("SELECT * FROM article_categories ORDER BY name")]
def o_cstatus(u): return [("draft", "Draft"), ("review", "Ready for review")] + ([("published", "Published"), ("archived", "Archived")] if u["role"] == "admin" else [])
def o_cstatus_w(u): return [("draft", "Draft"), ("pending", "Submit for approval")] + ([("published", "Published"), ("scheduled", "Scheduled"), ("archived", "Archived")] if u["role"] == "admin" else [])
def o_nstatus(u): return [("draft", "Draft"), ("pending", "Submit for approval")] + ([("published", "Published"), ("archived", "Archived")] if u["role"] == "admin" else [])

def F(n, l, t="text", o=None, req=False, h="", admin=False, col=None, rm=False): return dict(n=n, l=l, t=t, o=o, req=req, h=h, admin=admin, col=col or n, rm=rm)

RES = {
 "categories": dict(title="Categories", table="categories", perm="courses.manage", roles=(), slug="name", order="division, position, name",
    fields=[F("division", "Division", "select", o_div, True), F("level", "Academic category", "select", o_level, h="Academic subjects belong to Basic or Advanced. Professional Development and Income Skills have their own division (leave this empty). The same subject name can exist in both Basic and Advanced."),
            F("name", "Name", req=True), F("description", "Description", "textarea"),
            F("price_kobo", "Subject price (NGN)", "price", admin=True, h="Basic, Advanced and Professional Development subjects (e.g. English JSS1). Buying the subject unlocks every published course, topic and lesson in it. Required for an active Basic subject. Income Skills courses are priced individually, so Income Skills categories have no price."),
            F("featured", "Show on the homepage", "check", admin=True, h="Basic, Advanced and Professional Development subjects. The subject appears once in its homepage section with its cover image and price, and only while it is active and has published courses."),
            F("access_policy", "Subject access", "select", [("lifetime", "Lifetime"), ("days", "Limited days")], admin=True), F("access_days", "Access days", "int", admin=True),
            F("image", "Cover image", "image", h="Basic, Advanced and Professional Development subjects. Shown with the subject name and price on the homepage and the subject lists. Courses and topics inside the subject need no images.", rm=True),
            F("position", "Order", "int"), F("active", "Active", "check")],
    cols=["name", "division", "level", "price_kobo", "featured", "active"], search=["name"], defaults=dict(active=1)),
 "courses": dict(title="Courses", table="courses", perm="courses.manage", roles=("instructor",), owner="instructor_id", slug="title", order="created_at DESC",
    fields=[F("title", "Title", req=True), F("division", "Division", "select", o_div, True), F("category_id", "Category", "select", o_cats), F("summary", "Short summary", "textarea"),
            F("description", "Full description", "textarea", h="Supports ## headings, **bold**, - lists."), F("objectives", "Course objectives", "textarea", h="What the course aims to do, one point per line."), F("outcomes", "Expected learning outcomes", "textarea", h="What students will be able to do afterwards, one point per line."), F("thumbnail", "Thumbnail image", "image", h="Not used for Basic Academic courses: their category carries the cover image."),
            F("level", "Level (Income Skills)", h="e.g. Beginner"), F("academic_level", "Academic category", "select", o_level, h="Required for Academic courses; leave empty for Income Skills."), F("subject", "Subject (Income Skills)"), F("term", "Term"),
            F("price_kobo", "Price (NGN)", "price", h="Advanced and Professional Development: the price of this course (unlocks all its topics and lessons). Basic: priced per subject under Categories; this price is only used when the subject has no price. 0 makes the course free.", admin=True),
            F("access_policy", "Access after purchase", "select", [("lifetime", "Lifetime"), ("days", "Limited number of days")], admin=True),
            F("access_days", "Access days", "int", admin=True), F("subscription_eligible", "Included in subscriptions", "check", admin=True),
            F("certificate_enabled", "Offer certificate", "check", admin=True), F("status", "Status", "select", o_cstatus, True), F("featured", "Featured on homepage", "check", admin=True, h="Income Skills and Professional Development courses are all shown in their homepage section; featured ones come first."),
            F("instructor_id", "Instructor", "select", o_instr, admin=True), F("seo_title", "SEO title"), F("seo_description", "SEO description", "textarea")],
    cols=["title", "division", "price_kobo", "status", "instructor_id"], search=["title", "subject"], defaults=dict(subscription_eligible=1, certificate_enabled=1, access_policy="lifetime", status="draft")),
 "modules": dict(title="Modules / Topics", table="modules", perm="courses.manage", roles=("instructor",), owner="course", parent="course_id", order="course_id, position",
    fields=[F("course_id", "Course", "select", o_courses, True), F("title", "Title", req=True), F("position", "Order", "int")], cols=["title", "course_id", "position"], search=["title"], defaults={}),
 "lessons": dict(title="Lessons", table="lessons", perm="courses.manage", roles=("instructor",), owner="course", parent="course_id", order="course_id, position, id",
    fields=[F("course_id", "Course", "select", o_courses, True), F("module_id", "Module / topic", "select", o_modules), F("title", "Title", req=True),
            F("kind", "Type", "select", [("text", "Text lesson"), ("video", "Video (YouTube/Vimeo/mp4 link)"), ("pdf", "PDF / downloadable resource"), ("embed", "Embedded media")], True),
            F("body", "Lesson text", "textarea", h="Supports ## headings, **bold**, - lists, links."), F("video_url", "Video / embed URL", "url", h="https links only."),
            F("resource_file", "Resource file", "file", h="PDF, image, DOCX, PPTX, XLSX or ZIP up to 25MB."),
            F("duration_min", "Duration (minutes)", "int"), F("position", "Order", "int"), F("free_preview", "Free preview", "check"), F("downloadable", "Allow download", "check")],
    cols=["title", "course_id", "kind", "position"], search=["title"], defaults=dict(downloadable=1, kind="text")),
 "quizzes": dict(title="Quizzes", table="quizzes", perm="courses.manage", roles=("instructor",), owner="course", parent="course_id", order="course_id, position",
    fields=[F("course_id", "Course", "select", o_courses, True), F("title", "Title", req=True), F("pass_mark", "Pass mark (%)", "int"), F("position", "Order", "int")],
    cols=["title", "course_id", "pass_mark"], search=["title"], defaults=dict(pass_mark=50)),
 "questions": dict(title="Quiz questions", table="questions", perm="courses.manage", roles=("instructor",), owner="course", parent="quiz_id", order="quiz_id, position, id",
    fields=[F("quiz_id", "Quiz", "select", o_quizzes, True), F("prompt", "Question", "textarea", req=True), F("options", "Options (one per line, 2-6)", "textarea", req=True),
            F("correct", "Correct option number", "int", req=True), F("explanation", "Explanation (shown after submitting)", "textarea"), F("position", "Order", "int")],
    cols=["prompt", "quiz_id", "correct"], search=["prompt"], defaults={}),
 "assignments": dict(title="Assignments", table="assignments", perm="courses.manage", roles=("instructor",), owner="course", parent="course_id", order="course_id, id",
    fields=[F("course_id", "Course", "select", o_courses, True), F("title", "Title", req=True), F("instructions", "Instructions", "textarea"), F("due_date", "Due date", "date"), F("max_score", "Maximum score", "int")],
    cols=["title", "course_id", "due_date"], search=["title"], defaults=dict(max_score=100)),
 "announcements": dict(title="Course announcements", table="announcements", perm="courses.manage", roles=("instructor",), owner="course", parent="course_id", order="created_at DESC",
    fields=[F("course_id", "Course", "select", o_courses, True), F("title", "Title", req=True), F("body", "Message", "textarea")], cols=["title", "course_id", "created_at"], search=["title"], defaults={}),
 "plans": dict(title="Subscription plans", table="plans", perm="pricing.manage", roles=(), order="division, position",
    fields=[F("name", "Plan name", req=True), F("division", "Division", "select", o_div, True), F("level", "Section", "select", o_plan_level, h="Basic and Advanced subscriptions are independent. Professional Development has no subscription."),
            F("description", "Description", "textarea"), F("price_kobo", "Price (NGN)", "price"),
            F("duration_days", "Duration (days)", "int", req=True), F("active", "Active (offered to students)", "check", h="Set a price before activating."), F("position", "Order", "int")],
    cols=["name", "division", "price_kobo", "duration_days", "active"], search=["name"], defaults=dict(duration_days=30)),
 "promos": dict(title="Discounts & promo codes", table="promos", perm="pricing.manage", roles=(), order="id DESC",
    fields=[F("code", "Code", req=True), F("description", "Description"), F("percent_off", "Percent off (0-100)", "int"), F("amount_off_kobo", "Amount off (NGN)", "price"),
            F("applies_to", "Applies to", "select", [("all", "Courses and plans"), ("courses", "Courses only"), ("plans", "Plans only")]), F("active", "Active", "check"),
            F("starts_at", "Starts", "datetime"), F("expires_at", "Expires", "datetime"), F("max_uses", "Max uses", "int")],
    cols=["code", "percent_off", "amount_off_kobo", "applies_to", "active"], search=["code"], defaults=dict(active=1)),
 "faith-topics": dict(title="Faith: Topics", table="faith_topics", perm="faith.manage", roles=(), slug="name", order="position, name",
    fields=[F("name", "Topic name", req=True), F("description", "Short description", "textarea", h="Shown on the Faith page and the topic's card."),
            F("icon", "Topic icon", "icon", o=lambda u: FA.TOPIC_ICONS, h="Optional. Pick a ready-made icon, or upload an image below instead. Choosing one replaces the other."),
            F("image", "Topic image", "image", h="Optional. Shown on the topic's card instead of an icon. A square picture works best.", rm=True),
            F("position", "Order", "int", h="Smaller numbers appear first."),
            F("price_kobo", "Price for the whole topic (NGN)", "price", h="Optional. Buying the topic unlocks every course-content lesson in it, in any series. 0 means the topic itself is not sold (individual series can still be priced)."),
            F("access_policy", "Access after purchase", "select", [("lifetime", "Lifetime"), ("days", "Limited number of days")]), F("access_days", "Access days", "int"),
            F("active", "Active (visible on the website)", "check")],
    cols=["name", "price_kobo", "position", "active"], search=["name"], defaults=dict(active=1, access_policy="lifetime")),
 "faith-series": dict(title="Faith: Series", table="faith_series", perm="faith.manage", roles=("instructor",), owner="instructor_id", slug="title", order="topic_id, position, title",
    fields=[F("topic_id", "Topic", "select", o_ftopics, True), F("title", "Series title", req=True, h="For example: The Gospel of John, or Learning to Pray."), F("summary", "Short summary", "textarea"),
            F("description", "About this series", "textarea", h="Supports ## headings, **bold**, - lists."), F("cover", "Cover image", "image"),
            F("price_kobo", "Price (NGN)", "price", h="The price of the whole course. 0 makes it free to every signed-in learner. Lessons you mark 'Free preview' stay open to everyone."),
            F("access_policy", "Access after purchase", "select", [("lifetime", "Lifetime"), ("days", "Limited number of days")]), F("access_days", "Access days", "int"),
            F("instructor_id", "Instructor (tutor)", "select", o_instr, admin=True, h="The tutor who teaches this course and earns the tutor revenue share on each sale."),
            F("status", "Status", "select", o_fstatus, True), F("featured", "Featured on the Faith page", "check", admin=True), F("position", "Order", "int", admin=True)],
    cols=["title", "topic_id", "price_kobo", "status", "instructor_id"], search=["title", "summary"], defaults=dict(status="draft", access_policy="lifetime")),
 "testimonials": dict(title="Testimonials", table="testimonials", perm="content.manage", roles=(), order="id DESC",
    fields=[F("name", "Name", req=True), F("detail", "Detail (e.g. SS3 student)"), F("quote", "Testimonial", "textarea", req=True), F("verified", "Verified genuine", "check", h="Only publish testimonials you have verified."),
            F("status", "Status", "select", [("draft", "Draft"), ("published", "Published")])],
    cols=["name", "verified", "status"], search=["name", "quote"], defaults={}),
 "faqs": dict(title="FAQs", table="faqs", perm="content.manage", roles=(), order="position, id",
    fields=[F("question", "Question", req=True), F("answer", "Answer", "textarea", req=True), F("position", "Order", "int"), F("active", "Active", "check")], cols=["question", "active"], search=["question"], defaults=dict(active=1)),
 "pages": dict(title="Pages (About, Policies, your own)", table="pages", perm="content.manage", roles=(), order="slug", slug="title",
    fields=[F("title", "Title", req=True), F("body", "Content", "textarea", h="Supports ## headings, **bold**, - lists."), F("seo_description", "SEO description", "textarea")], cols=["slug", "title"], search=["title"], defaults={}),
 "article-categories": dict(title="Blog categories", table="article_categories", perm="content.manage", roles=(), slug="name", order="name",
    fields=[F("name", "Name", req=True)], cols=["name"], search=["name"], defaults={}),
 "articles": dict(title="Blog articles", table="articles", perm="content.manage", roles=("writer",), owner="author_id", slug="title", order="created_at DESC", writer_status=True,
    fields=[F("title", "Title", req=True), F("category_id", "Category", "select", o_acats), F("excerpt", "Excerpt", "textarea"), F("body", "Article body", "textarea", req=True, h="Supports ## headings, **bold**, - lists, links."),
            F("featured_image", "Featured image", "image"), F("status", "Status", "select", o_cstatus_w, True), F("publish_at", "Publish date/time (for scheduling)", "datetime"),
            F("seo_title", "SEO title"), F("seo_description", "SEO description", "textarea")],
    cols=["title", "status", "author_id", "publish_at"], search=["title"], defaults=dict(status="draft")),
 "nuggets": dict(title="Academy nuggets", table="nuggets", perm="content.manage", roles=("writer",), owner="author_id", slug="title", order="created_at DESC", writer_status=True,
    fields=[F("title", "Title", req=True), F("category", "Category", h="e.g. Finance, Business, Productivity"), F("body", "Nugget text", "textarea", req=True), F("image", "Image", "image"),
            F("status", "Status", "select", o_nstatus, True), F("featured", "Featured", "check", admin=True)],
    cols=["title", "category", "status", "author_id"], search=["title", "category"], defaults=dict(status="draft")),
}

# ---------------------------------------------------------------- helpers
def _allowed(res):
    u = g.user
    if u["role"] == "admin": return has_perm(res["perm"])
    return u["role"] in res["roles"]

def _scope(res):
    """Role scope AND learning-path scope, both enforced in SQL."""
    w, a = _role_scope(res)
    pc = P.resource_clause(res.get("_name"), _cx())
    return (f"({w}) AND ({pc[0]})", tuple(a) + tuple(pc[1])) if pc else (w, a)

def _role_scope(res):
    u = g.user
    if u["role"] == "admin": return "1=1", ()
    o = res.get("owner")
    if o == "course": return "course_id IN (SELECT id FROM courses WHERE instructor_id=?)" if res["table"] != "questions" else "quiz_id IN (SELECT z.id FROM quizzes z JOIN courses c ON c.id=z.course_id WHERE c.instructor_id=?)", (u["id"],)
    if o: return f"{o}=?", (u["id"],)
    return "1=0", ()

def _opts(f):
    o = f["o"]
    return o(g.user) if callable(o) else (o or [])

_PATH_FIXED = {"categories": {"division", "level"}, "courses": {"division", "academic_level"}}
def _fields(res):
    hide = _PATH_FIXED.get(res.get("_name"), set()) if _cx() else set()
    return [f for f in res["fields"] if not (f["admin"] and g.user["role"] != "admin") and f["n"] not in hide]

def _display(res, row, name):
    f = next((x for x in res["fields"] if x["n"] == name), None); v = row[name] if name in row.keys() else None
    if f is None: return v if v is not None else ""
    if f["t"] == "price": return naira(v)
    if f["t"] == "check": return "Yes" if v else "No"
    if f["t"] == "select":
        for ov, ol in _opts(f):
            if str(ov) == str(v if v is not None else ""): return ol
    return "" if v is None else str(v)[:90]

def _build(res, form, files, row):
    vals, errs = {}, []
    for f in _fields(res):
        n, t = f["n"], f["t"]
        if t == "file":
            fs = files.get(n)
            if fs and fs.filename:
                try:
                    name, ext, _m, _s = uploads.save_resource(fs); vals[n] = name; vals["resource_name"] = fs.filename[:120]
                except uploads.UploadError as e: errs.append(f"{f['l']}: {e}")
            continue
        if t == "image":
            fs = files.get(n)
            if fs and fs.filename:
                try: vals[n] = uploads.save_public_image(fs)
                except uploads.UploadError as e: errs.append(f"{f['l']}: {e}")
            elif f.get("rm") and form.get("remove_" + n): vals[n] = None
            continue
        if t == "icon":
            if n not in form: continue
            raw = (form.get(n) or "").strip()
            if raw and raw not in {k for k, _ in FA.TOPIC_ICONS}: errs.append("Choose a valid topic icon.")
            else: vals[n] = raw or None
            continue
        raw = (form.get(n) or "").strip()
        if t == "check": vals[n] = 1 if form.get(n) else 0; continue
        if f["req"] and not raw: errs.append(f"{f['l']} is required."); continue
        if t == "select" and n not in form and not f["req"]: continue  # field not submitted: keep existing/default
        if t == "int":
            try: vals[n] = int(raw) if raw else (None if n in ("access_days", "max_uses", "correct") else 0)
            except ValueError: errs.append(f"{f['l']} must be a whole number.")
        elif t == "price":
            try: vals[f["col"]] = parse_naira(raw)
            except ValueError as e: errs.append(f"{f['l']}: {e}")
        elif t == "select":
            allowed = {str(a) for a, _ in _opts(f)}
            if raw not in allowed: errs.append(f"Choose a valid {f['l'].lower()}.")
            else: vals[n] = int(raw) if raw.isdigit() and n.endswith("_id") else (raw or None)
        elif t in ("date", "datetime"):
            if raw and not parse_ts(raw): errs.append(f"{f['l']} is not a valid date.")
            else: vals[n] = raw.replace("T", " ") if raw else None
        elif t == "url":
            if raw and not raw.startswith("https://"): errs.append(f"{f['l']} must start with https://")
            else: vals[n] = raw or None
        else: vals[n] = raw if raw != "" else None
    return vals, errs

def _path_hooks(rname, vals, row, errs):
    cx = _cx()
    if not cx: return
    if rname == "categories":
        if cx == "faith": errs.append("Faith content is organised by topics."); return
        vals["division"], vals["level"] = ("academic", cx) if cx in P.ACADEMIC else (cx, None)      # income / professional are divisions in their own right
    elif rname == "courses":
        if cx == "faith": errs.append("Faith courses are managed under Faith."); return
        vals["division"], vals["academic_level"] = ("academic", cx) if cx in P.ACADEMIC else (cx, None)
    elif rname in P.COURSE_CHILDREN:
        if not P.course_in_path(vals.get("course_id"), cx): errs.append(f"Choose a {P.name(cx)} course. Content cannot be attached across learning paths.")
    elif rname == "questions":
        cid = val("SELECT course_id FROM quizzes WHERE id=?", (vals.get("quiz_id"),))
        if not P.course_in_path(cid, cx): errs.append(f"Choose a {P.name(cx)} quiz.")

def _hooks(rname, res, vals, row, errs):
    u = g.user
    _path_hooks(rname, vals, row, errs)
    if rname == "categories":
        lv = vals.get("level"); div = vals.get("division")
        if div == "academic" and lv not in ("basic", "advanced"): errs.append("Choose Basic or Advanced for an academic subject.")
        if div in ("income", "professional"): vals["level"] = None
        if row and div and row["division"] != div and val("SELECT 1 FROM courses WHERE category_id=?", (row["id"],)): errs.append("This subject already has courses, so its division cannot be changed. Move or remove the courses first.")
        sold = div == "professional" or (div == "academic" and lv in ("basic", "advanced"))        # Basic, Advanced and Professional Development are sold by subject
        if not sold and (vals.get("price_kobo") or 0) > 0: errs.append("Income Skills courses are priced individually. Set the price on each course; Income Skills categories have no subject price.")
        if vals.get("access_policy") == "days" and not vals.get("access_days"): errs.append("Enter the number of access days.")
        if not sold: vals["featured"] = 0; vals.pop("image", None); vals["price_kobo"] = 0         # homepage subject cards and cover images are for the three subject-priced divisions
        elif div == "academic" and lv == "basic" and vals.get("active") and (vals.get("price_kobo") or 0) <= 0: errs.append("Set a price for this Basic subject (students pay for subjects, not individual courses).")
        dup = val("SELECT 1 FROM categories WHERE division=? AND COALESCE(level,'')=COALESCE(?,'') AND lower(name)=lower(?) AND id IS NOT ?", (div, vals.get("level"), vals.get("name"), row["id"] if row else None))
        if dup: errs.append("A subject with that name already exists in this category.")
        if row and (row["level"] or None) != (vals.get("level") or None) and val("SELECT COUNT(*) FROM courses WHERE category_id=?", (row["id"],), 0):
            errs.append("This subject has courses. Move or reassign them first, then change its category.")
    if rname == "courses":
        from ..services import academic as A
        vals["division"], vals["academic_level"] = A.normalize(vals.get("division"), vals.get("academic_level"))
        ae, alv, ac = A.validate(vals.get("division"), vals.get("academic_level"), vals.get("category_id"), vals.get("status") == "published"); errs += ae
        vals["academic_level"] = alv; vals["category_id"] = ac
        if vals.get("division") == "academic" and alv == "basic": vals.pop("thumbnail", None)      # Basic courses carry no image of their own; the category does
        if u["role"] != "admin":
            if row is None: vals["instructor_id"] = u["id"]
        if vals.get("access_policy") == "days" and not vals.get("access_days"): errs.append("Enter the number of access days.")
        if vals.get("division") == "professional": vals["subscription_eligible"] = 0          # Professional Development has no subscription
        vals["updated_at"] = now()
        if u["role"] != "admin" and row is not None and row["status"] in ("published", "archived"): vals["status"] = row["status"]
    if rname in ("lessons", "modules", "quizzes", "assignments", "announcements"):
        if vals.get("module_id") and rname == "lessons":
            if val("SELECT course_id FROM modules WHERE id=?", (vals["module_id"],)) != vals.get("course_id"): errs.append("The module must belong to the selected course.")
        if rname == "announcements" and row is None: vals["created_by"] = u["id"]
    if rname == "questions":
        opts = [o.strip() for o in (vals.get("options") or "").splitlines() if o.strip()]
        if not 2 <= len(opts) <= 6: errs.append("Provide between 2 and 6 options, one per line.")
        elif not vals.get("correct") or not 1 <= vals["correct"] <= len(opts): errs.append("Correct option number is out of range.")
        vals["options"] = "\n".join(opts)
        c = q1("SELECT course_id FROM quizzes WHERE id=?", (vals.get("quiz_id"),))
        if c: vals["course_id"] = c["course_id"]
    if rname == "quizzes" and not 0 <= (vals.get("pass_mark") or 0) <= 100: errs.append("Pass mark must be 0-100.")
    if rname == "promos":
        vals["code"] = (vals.get("code") or "").upper().replace(" ", "")
        if not 0 <= (vals.get("percent_off") or 0) <= 100: errs.append("Percent off must be 0-100.")
        if not vals.get("percent_off") and not vals.get("amount_off_kobo"): errs.append("Set a percent or amount discount.")
    if rname == "plans":
        if vals.get("division") == "income": vals["level"] = None
        elif vals.get("level") not in ("basic", "advanced"): errs.append("Choose Basic or Advanced. Professional Development has no subscription.")
    if rname == "plans" and vals.get("active") and not vals.get("price_kobo"): errs.append("Set a price before activating a plan.")
    if rname == "plans" and (vals.get("duration_days") or 0) < 1: errs.append("Duration must be at least 1 day.")
    if rname in ("articles", "nuggets"):
        st = vals.get("status")
        if row is None: vals["author_id"] = u["id"]
        if u["role"] == "writer" and row is not None and row["status"] in ("published", "scheduled", "archived"): errs.append("Published content can only be changed by an administrator.")
        if rname == "articles":
            if st == "scheduled" and not vals.get("publish_at"): errs.append("Choose a publish date/time for scheduled articles.")
            if st == "published" and not vals.get("publish_at"): vals["publish_at"] = now()
            vals["updated_at"] = now()
        elif st == "published": vals["published_at"] = (row["published_at"] if row and row["published_at"] else now())
    if rname == "faith-series":
        vals["updated_at"] = now()
        if u["role"] != "admin":
            if row is None: vals["instructor_id"] = u["id"]
            vals["status"] = row["status"] if row else "draft"
        if vals.get("access_policy") == "days" and not vals.get("access_days"): errs.append("Enter the number of access days.")
    if rname == "faith-topics" and vals.get("access_policy") == "days" and not vals.get("access_days"): errs.append("Enter the number of access days.")
    if rname == "faith-topics":            # a topic shows an uploaded image OR an icon, never both
        if vals.get("image"): vals["icon"] = None
        elif vals.get("icon") and "image" not in vals: vals["image"] = None
    if rname == "faith-topics" and row is not None and not vals.get("active") and val("SELECT COUNT(*) FROM faith_items WHERE topic_id=? AND status='published'", (row["id"],), 0):
        errs.append("This topic still has published lessons. Move or archive them first, or keep the topic active.")
    if rname == "testimonials" and vals.get("status") == "published" and not vals.get("verified"): errs.append("Only verified testimonials can be published. Tick 'Verified genuine' once confirmed.")

def _get(rname):
    res = RES.get(rname) or abort(404)
    if not _allowed(res): abort(403)
    res = dict(res, _name=rname)
    pc = P.resource_clause(rname, _cx())
    if pc and pc[0] == "0=1": abort(404)               # e.g. Faith topics under Basic, or lessons under Faith
    return res

def _row(res, rid):
    w, a = _scope(res)
    r = q1(f"SELECT * FROM {res['table']} WHERE id=? AND {w}", (rid,) + a)
    if not r: abort(404)
    return r

def nav():
    """Flat list kept for backwards compatibility; the dashboards render the grouped tree from services.navigation."""
    from ..services import navigation as N
    return N.flat(N.build(g.user))

@bp.app_context_processor
def _inject():
    from ..services import navigation as N
    return dict(staff_nav=nav if g.get("user") and is_staff() else (lambda: []), nav_tree=(lambda: N.build(g.user)) if g.get("user") else (lambda: []))

# ---------------------------------------------------------------- dashboard
@bp.route("/")
@role_required("admin", "instructor", "writer")
def dashboard():
    u = g.user; d = {}
    if u["role"] == "admin":
        d = dict(students=val("SELECT COUNT(*) FROM users WHERE role='student'", default=0),
                 active_subs=val("SELECT COUNT(DISTINCT user_id) FROM entitlements WHERE kind='subscription' AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at>?)", (now(),), 0),
                 pending=val("SELECT COUNT(*) FROM transactions WHERE status='pending_verification'", default=0),
                 revenue=val("SELECT COALESCE(SUM(amount_kobo),0) FROM transactions WHERE status='approved'", default=0),
                 courses=val("SELECT COUNT(*) FROM courses WHERE status='published'", default=0),
                 divs=__import__("dagba.services.academic", fromlist=["x"]).division_counts(),
                 review=val("SELECT (SELECT COUNT(*) FROM courses WHERE status='review')+(SELECT COUNT(*) FROM articles WHERE status='pending')+(SELECT COUNT(*) FROM nuggets WHERE status='pending')+(SELECT COUNT(*) FROM faith_items WHERE status='draft' AND submitted_at IS NOT NULL)", default=0),
                 messages=val("SELECT COUNT(*) FROM contact_messages WHERE handled=0", default=0),
                 faith=val("SELECT COUNT(*) FROM faith_items WHERE status='published'", default=0))
    elif u["role"] == "instructor":
        d = dict(courses=q("SELECT c.*, (SELECT COUNT(DISTINCT user_id) FROM progress p WHERE p.course_id=c.id) learners FROM courses c WHERE instructor_id=?", (u["id"],)),
                 earn=__import__("dagba.services.payouts", fromlist=["x"]).summary(u["id"]),
                 to_review=val("SELECT COUNT(*) FROM submissions s JOIN assignments a ON a.id=s.assignment_id JOIN courses c ON c.id=a.course_id WHERE c.instructor_id=? AND s.status='submitted'", (u["id"],), 0))
    else:
        d = dict(items=q("SELECT 'Article' kind, title, status, created_at FROM articles WHERE author_id=? UNION ALL SELECT 'Nugget', title, status, created_at FROM nuggets WHERE author_id=? ORDER BY created_at DESC LIMIT 30", (u["id"], u["id"])))
    return render_template("staff/dashboard.html", d=d)

# ---------------------------------------------------------------- generic CRUD
@bp.route("/r/<rname>")
@login_required
def crud_list(rname):
    res = _get(rname); w, a = _scope(res); where = [w]; args = list(a)
    parent = res.get("parent"); pid = request.args.get(parent, type=int) if parent else None
    if pid: where.append(f"{parent}=?"); args.append(pid)
    s = request.args.get("q", "").strip()
    if s: where.append("(" + " OR ".join(f"{c} LIKE ?" for c in res["search"]) + ")"); args += [f"%{s}%"] * len(res["search"])
    st = request.args.get("status", "").strip()[:20]
    if st and any(f["n"] == "status" for f in res["fields"]): where.append("status=?"); args.append(st)
    keep = {k: v for k, v in (("ctx", _cx()), ("status", st)) if v}
    page = max(1, request.args.get("page", 1, type=int)); sql = f"SELECT * FROM {res['table']} WHERE {' AND '.join(where)}"
    total = val(f"SELECT COUNT(*) FROM ({sql})", args, 0)
    rows = q(sql + f" ORDER BY {res['order']} LIMIT 25 OFFSET ?", tuple(args) + ((page - 1) * 25,))
    def cell(r, c):
        if c == "author_id": return val("SELECT full_name FROM users WHERE id=?", (r["author_id"],), "-")
        if c == "instructor_id": return val("SELECT full_name FROM users WHERE id=?", (r["instructor_id"],), "-")
        if c == "course_id": return val("SELECT title FROM courses WHERE id=?", (r["course_id"],), "-")
        if c == "quiz_id": return val("SELECT title FROM quizzes WHERE id=?", (r["quiz_id"],), "-")
        if c in ("slug", "created_at", "publish_at"): return str(r[c] or "")[:16]
        if c in ("percent_off",): return f"{r[c]}%"
        if c == "amount_off_kobo": return naira(r[c])
        return _display(res, r, c)
    return render_template("staff/crud_list.html", res=res, rname=rname, rows=rows, cell=cell, total=total, page=page, q=s, pid=pid, parent=parent, keep=keep, ctx=_cx(), ctx_name=P.name(_cx()), cq={"ctx": _cx()} if _cx() else {}, nq=({parent: pid} if pid else {}) | ({"ctx": _cx()} if _cx() else {}),
                           labels={f["n"]: f["l"] for f in res["fields"]} | {"slug": "Page", "created_at": "Created", "publish_at": "Publish at", "author_id": "Author", "instructor_id": "Instructor", "course_id": "Course", "quiz_id": "Quiz", "percent_off": "% off", "amount_off_kobo": "Amount off"})

@bp.route("/r/<rname>/new", methods=["GET", "POST"])
@bp.route("/r/<rname>/<int:rid>/edit", methods=["GET", "POST"])
@login_required
def crud_form(rname, rid=None):
    res = _get(rname); row = _row(res, rid) if rid else None
    form_vals = dict(res["defaults"]); 
    if row: form_vals = {k: row[k] for k in row.keys()}
    elif res.get("parent") and request.args.get(res["parent"], type=int): form_vals[res["parent"]] = request.args.get(res["parent"], type=int)
    if rname == "categories" and not row and request.args.get("level") in ("basic", "advanced"): form_vals.update(division="academic", level=request.args["level"], featured=1)
    if rname == "categories" and not row and request.args.get("level") == "professional": form_vals.update(division="professional", level=None, featured=1)
    if rname == "courses" and not row and _cx() in P.ACADEMIC: form_vals.update(division="academic", academic_level=_cx())
    if rname == "courses" and not row and _cx() in ("income", "professional"): form_vals.update(division=_cx())
    if request.method == "POST":
        vals, errs = _build(res, request.form, request.files, row)
        _hooks(rname, res, vals, row, errs)
        # instructors may only attach rows to their own courses
        if g.user["role"] == "instructor" and res.get("owner") == "course":
            cid = vals.get("course_id")
            if cid and not val("SELECT 1 FROM courses WHERE id=? AND instructor_id=?", (cid, g.user["id"])): errs.append("You can only add content to your own courses.")
        if rname == "courses" and row is not None and vals.get("status") == "published" and row["status"] != "published":
            from ..services import tutors as _T
            _m = _T.publish_blocked(row["id"])                          # only an approved tutor course may be published
            if _m: errs.append(_m)
        if errs:
            for e in errs: flash(e, "error")
            form_vals.update({k: request.form.get(k) for k in request.form}); form_vals.update(vals)
        else:
            try:
                if res.get("slug") and not row:
                    base = vals.get(res["slug"]) or "item"
                    if rname == "categories": base = f"{vals.get('level') or vals.get('division')} {base}"
                    vals["slug"] = unique_slug(res["table"], base, rid)
                if row:
                    ex(f"UPDATE {res['table']} SET " + ", ".join(f"{k}=?" for k in vals) + " WHERE id=?", tuple(vals.values()) + (rid,)); new_id = rid
                else:
                    new_id = ex(f"INSERT INTO {res['table']}(" + ",".join(vals) + ") VALUES (" + ",".join("?" * len(vals)) + ")", tuple(vals.values()))
                audit.log(f"{rname}.{'update' if row else 'create'}", res["table"], new_id, str(vals.get("title") or vals.get("name") or vals.get("code") or "")[:100])
                _after_save(rname, new_id, vals, row)
                flash("Saved.", "success")
                nxt = url_for("staff.crud_list", rname=rname, **({"ctx": _cx()} if _cx() else {}), **({res["parent"]: vals[res["parent"]]} if res.get("parent") and vals.get(res["parent"]) else {}))
                return redirect(nxt)
            except sqlite3.IntegrityError as e:
                flash("Could not save: " + ("that value already exists." if "UNIQUE" in str(e) else "invalid reference."), "error")
    return render_template("staff/crud_form.html", res=res, rname=rname, row=row, fields=_fields(res), v=form_vals, opts=_opts, ctx=_cx(), ctx_name=P.name(_cx()), cq={"ctx": _cx()} if _cx() else {})

def _drop_image(name):
    """Delete a replaced/removed public image file unless something else still uses it."""
    if not name or val("SELECT 1 FROM categories WHERE image=? UNION SELECT 1 FROM courses WHERE thumbnail=? UNION SELECT 1 FROM faith_topics WHERE image=?", (name, name, name)): return
    p = os.path.join(current_app.config["PUBLIC_DIR"], os.path.basename(name))
    try: os.remove(p)
    except OSError: pass

def _after_save(rname, rid, vals, row):
    if rname in ("categories", "faith-topics") and row is not None and "image" in vals and row["image"] and row["image"] != vals["image"]:
        _drop_image(row["image"])
    if rname == "announcements" and row is None:
        for r in q("SELECT DISTINCT user_id FROM entitlements WHERE course_id=? AND revoked_at IS NULL UNION SELECT DISTINCT user_id FROM progress WHERE course_id=?", (vals["course_id"], vals["course_id"])):
            notify(r[0], "Course announcement: " + vals["title"], vals.get("body") or "", f"/learn/{val('SELECT slug FROM courses WHERE id=?', (vals['course_id'],))}", "announcement")
    if rname == "faith-series" and g.user["role"] != "admin" and row is not None and (row["price_kobo"] or 0) != (vals.get("price_kobo") or 0):
        notify_staff("faith.manage", "Tutor changed a Faith course price", f"{g.user['full_name']}: {row['title']} ({(row['price_kobo'] or 0)//100} to {(vals.get('price_kobo') or 0)//100} NGN)", f"/staff/r/faith-series/{rid}/edit", "content")
    if rname == "faith-series" and row is None and g.user["role"] != "admin":
        notify_staff("faith.manage", "New Faith course from a tutor", f"{g.user['full_name']}: {vals.get('title', '')}", f"/staff/r/faith-series/{rid}/edit", "content")
    if rname in ("articles", "nuggets"):
        if vals.get("status") == "pending" and (row is None or row["status"] != "pending"):
            notify_staff("content.manage", "Content awaiting approval", vals.get("title", ""), f"/staff/r/{rname}/{rid}/edit", "content")
        if vals.get("status") in ("published", "scheduled") and row and row["author_id"] and row["author_id"] != g.user["id"] and row["status"] not in ("published", "scheduled"):
            notify(row["author_id"], "Your content was approved", vals.get("title", ""), f"/staff/r/{rname}/{rid}/edit", "content")
    if rname == "courses" and vals.get("status") == "review" and (row is None or row["status"] != "review"):
        notify_staff("courses.manage", "Course ready for review", vals.get("title", ""), f"/staff/r/courses/{rid}/edit", "content")
        if g.user["role"] == "instructor":
            from ..services import tutors as _T
            _T.course_submitted(rid, g.user, notify_staff_too=False)   # joins the Tutor applications review queue (reviewers were notified just above)
    if rname == "courses" and vals.get("status") == "published" and g.user["role"] == "admin" and (row is None or row["status"] != "published"):
        __import__("dagba.services.tutors", fromlist=["x"]).finalize_publish(g.user, rid)       # publishing a course that waited for review = approving it

@bp.route("/r/<rname>/<int:rid>/delete", methods=["POST"])
@login_required
def crud_delete(rname, rid):
    res = _get(rname); row = _row(res, rid)
    if res.get("no_delete") or (rname == "pages" and row["slug"] in ("about", "privacy-policy", "terms-and-conditions", "refund-policy")): abort(403)
    if g.user["role"] != "admin" and rname in ("articles", "nuggets", "courses", "faith-series") and row["status"] not in ("draft",): abort(403)
    from ..services import builder as B
    if rname == "categories": ex("UPDATE courses SET needs_review=1 WHERE category_id=? AND division='academic'", (rid,))
    files = [l for l in q("SELECT * FROM lessons WHERE course_id=?", (rid,))] if rname == "courses" else ([row] if rname == "lessons" else [])
    try:
        ex(f"DELETE FROM {res['table']} WHERE id=?", (rid,))
        for l in files: B.delete_lesson_files(l) if rname == "lessons" else [B._rm(os.path.join(B._priv(), f)) for f in (l["video_file"], l["resource_file"]) if f]
        audit.log(f"{rname}.delete", res["table"], rid, str(row["title"] if "title" in row.keys() else ""))
        flash("Deleted.", "info")
    except sqlite3.IntegrityError: flash("This item is in use (for example, it has payments or records attached). Archive it instead.", "error")
    return redirect(request.referrer or url_for("staff.crud_list", rname=rname, **({"ctx": _cx()} if _cx() else {})))

# ---------------------------------------------------------------- users
@bp.route("/users")
@perm_required("users.manage")
def users():
    role = request.args.get("role", ""); s = request.args.get("q", "").strip(); page = max(1, request.args.get("page", 1, type=int))
    where, a = ["1=1"], []
    if role in ("student", "instructor", "writer", "admin"): where.append("role=?"); a.append(role)
    if s: where.append("(full_name LIKE ? OR email LIKE ?)"); a += [f"%{s}%"] * 2
    sql = "SELECT * FROM users WHERE " + " AND ".join(where)
    return render_template("staff/users.html", rows=q(sql + " ORDER BY id DESC LIMIT 30 OFFSET ?", tuple(a) + ((page - 1) * 30,)), total=val(f"SELECT COUNT(*) FROM ({sql})", a, 0), page=page, role=role, q=s)

def _can_touch(target):
    return g.user["is_owner"] or target["role"] != "admin"

@bp.route("/users/new", methods=["GET", "POST"])
@perm_required("users.manage")
def user_new():
    if request.method == "POST":
        f = request.form; email = f.get("email", "").strip().lower(); role = f.get("role")
        err = None
        if role not in ("student", "instructor", "writer", "admin") or (role == "admin" and not g.user["is_owner"]): err = "Choose a valid role (only the owner can create administrators)."
        elif not f.get("full_name", "").strip() or "@" not in email: err = "Name and a valid email are required."
        elif val("SELECT 1 FROM users WHERE email=?", (email,)): err = "That email is already registered."
        else: err = check_password_strength(f.get("password", ""), email)
        if err: flash(err, "error")
        else:
            uid = ex("INSERT INTO users(email,password_hash,full_name,role,phone) VALUES (?,?,?,?,?)", (email, generate_password_hash(f["password"]), f["full_name"].strip(), role, f.get("phone", "")[:30]))
            if role == "instructor": __import__("dagba.services.tutors", fromlist=["x"]).ensure_profile(uid)       # every tutor gets a referral code
            audit.log("user.create", "user", uid, f"{email} as {role}"); flash("User created. Share the temporary password securely and ask them to change it.", "success")
            return redirect(url_for("staff.user_detail", uid=uid))
    return render_template("staff/user_new.html")

@bp.route("/users/<int:uid>", methods=["GET", "POST"])
@perm_required("users.manage")
def user_detail(uid):
    t = q1("SELECT * FROM users WHERE id=?", (uid,)) or abort(404)
    if not _can_touch(t): abort(403)
    if request.method == "POST":
        a = request.form.get("action")
        if a in ("avatar", "avatar_remove"):
            from ..services import avatars as _AV, uploads as _UP
            if a == "avatar_remove": flash("Profile picture removed." if _AV.remove(uid, actor=g.user) else "This user has no profile picture.", "success")
            else:
                try:
                    fs = request.files.get("picture")
                    if not fs or not fs.filename: raise _UP.UploadError("Choose a picture first.")
                    _AV.save(uid, fs, actor=g.user); flash("Profile picture updated.", "success")
                except _UP.UploadError as e: flash(str(e), "error")
        elif t["is_owner"] and a in ("role", "toggle", "perms"): flash("The owner account cannot be changed this way.", "error")
        elif a == "role":
            r = request.form.get("role")
            if r not in ("student", "instructor", "writer", "admin") or (r == "admin" and not g.user["is_owner"]): flash("Not allowed.", "error")
            else:
                ex("UPDATE users SET role=? WHERE id=?", (r, uid)); audit.log("user.role", "user", uid, f"{t['role']} -> {r}"); flash("Role updated.", "success")
                if r == "instructor": __import__("dagba.services.tutors", fromlist=["x"]).ensure_profile(uid)
        elif a == "toggle":
            if uid == g.user["id"]: flash("You cannot deactivate yourself.", "error")
            else: ex("UPDATE users SET is_active=1-is_active WHERE id=?", (uid,)); audit.log("user.toggle_active", "user", uid); flash("Account status changed.", "success")
        elif a == "perms" and g.user["is_owner"] and t["role"] == "admin":
            ex("DELETE FROM user_permissions WHERE user_id=?", (uid,))
            for p in request.form.getlist("perm"):
                if p in PERMISSIONS: ex("INSERT INTO user_permissions(user_id,permission) VALUES (?,?)", (uid, p))
            audit.log("user.permissions", "user", uid, ",".join(request.form.getlist("perm"))); flash("Permissions saved.", "success")
        elif a == "reset" and g.user["is_owner"]:
            link = make_reset_link(uid); audit.log("user.reset_link", "user", uid)
            flash("One-time reset link (valid 1 hour). Send it to the user over a trusted channel: " + link, "info")
        return redirect(url_for("staff.user_detail", uid=uid))
    return render_template("staff/user_detail.html", t=t, perms={r["permission"] for r in q("SELECT permission FROM user_permissions WHERE user_id=?", (uid,))},
        ents=q("SELECT e.*, COALESCE(c.title, cat.name || ' (subject)', CASE e.level WHEN 'basic' THEN 'Basic subscription' WHEN 'advanced' THEN 'Advanced subscription' END) ct FROM entitlements e LEFT JOIN courses c ON c.id=e.course_id LEFT JOIN categories cat ON cat.id=e.category_id WHERE e.user_id=? ORDER BY e.starts_at DESC", (uid,)),
        fents=q("SELECT a.*, COALESCE(s.title, t.name || ' (topic)') ct FROM faith_access a LEFT JOIN faith_series s ON s.id=a.series_id LEFT JOIN faith_topics t ON t.id=a.topic_id WHERE a.user_id=? ORDER BY a.starts_at DESC", (uid,)),
        txs=q("SELECT * FROM transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 20", (uid,)))

# ---------------------------------------------------------------- submissions, learners
def _sub_scope():
    return ("1=1", ()) if g.user["role"] == "admin" else ("c.instructor_id=?", (g.user["id"],))

@bp.route("/submissions")
@login_required
def submissions():
    if not (g.user["role"] == "instructor" or has_perm("courses.manage")): abort(403)
    w, a = _sub_scope()
    rows = q(f"SELECT s.*, u.full_name, a.title, c.title ct FROM submissions s JOIN assignments a ON a.id=s.assignment_id JOIN courses c ON c.id=a.course_id JOIN users u ON u.id=s.user_id WHERE {w} ORDER BY s.status, s.submitted_at DESC LIMIT 100", a)
    return render_template("staff/submissions.html", rows=rows)

@bp.route("/submissions/<int:sid>", methods=["GET", "POST"])
@login_required
def submission(sid):
    if not (g.user["role"] == "instructor" or has_perm("courses.manage")): abort(403)
    w, a = _sub_scope()
    s = q1(f"SELECT s.*, u.full_name, a.title, a.max_score, a.instructions, c.title ct FROM submissions s JOIN assignments a ON a.id=s.assignment_id JOIN courses c ON c.id=a.course_id JOIN users u ON u.id=s.user_id WHERE s.id=? AND {w}", (sid,) + a) or abort(404)
    if request.method == "POST":
        sc = request.form.get("score", type=int)
        if sc is None or not 0 <= sc <= s["max_score"]: flash(f"Score must be between 0 and {s['max_score']}.", "error")
        else:
            ex("UPDATE submissions SET score=?, feedback=?, status='reviewed', reviewed_by=?, reviewed_at=? WHERE id=?", (sc, request.form.get("feedback", "")[:5000], g.user["id"], now(), sid))
            notify(s["user_id"], "Assignment feedback: " + s["title"], f"Score {sc}/{s['max_score']}. " + request.form.get("feedback", "")[:200], "/student/assignments", "assignment")
            audit.log("assignment.review", "submission", sid); flash("Feedback sent.", "success"); return redirect(url_for("staff.submissions"))
    return render_template("staff/submission.html", s=s)

@bp.route("/courses/<int:cid>/learners")
@login_required
def learners(cid):
    c = q1("SELECT * FROM courses WHERE id=?", (cid,)) or abort(404)
    if not (g.user["role"] == "admin" and has_perm("courses.manage") or c["instructor_id"] == g.user["id"]): abort(403)
    from ..services import lms
    rows = []
    for u in q("SELECT DISTINCT u.id, u.full_name, u.email FROM users u WHERE u.id IN (SELECT user_id FROM progress WHERE course_id=? UNION SELECT user_id FROM entitlements WHERE course_id=?)", (cid, cid)):
        rows.append(dict(u=u, p=lms.course_progress(u["id"], cid)))
    return render_template("staff/learners.html", c=c, rows=rows)

# ---------------------------------------------------------------- messages, broadcast, certs, audit, system
@bp.route("/messages", methods=["GET", "POST"])
@perm_required("settings.manage")
def messages():
    if request.method == "POST":
        ex("UPDATE contact_messages SET handled=1-handled WHERE id=?", (request.form.get("id", type=int),)); return redirect(url_for("staff.messages"))
    return render_template("staff/messages.html", rows=q("SELECT * FROM contact_messages ORDER BY handled, id DESC LIMIT 100"),
                           subs=val("SELECT COUNT(*) FROM newsletter_subscribers", default=0), emails=q("SELECT email FROM newsletter_subscribers ORDER BY id DESC LIMIT 500"))

@bp.route("/pricing", methods=["GET", "POST"])
@perm_required("pricing.manage")
def pricing():
    """One screen for every price: Basic, Advanced and Professional Development subjects, Income Skills courses, Basic/Advanced/Income subscription fees."""
    from ..services import academic as A
    if request.method == "POST":
        kind, rid = request.form.get("kind"), request.form.get("id", type=int)
        try: kobo = parse_naira(request.form.get("price", ""))
        except Exception: kobo = None
        if kobo is None or kobo < 0: flash("Enter a valid price.", "error"); return redirect(url_for("staff.pricing"))
        if kind == "subject":
            from ..services.access import subject_scope
            r = q1("SELECT * FROM categories WHERE id=?", (rid,))
            if not r or not subject_scope(r): abort(404)                # Basic, Advanced or Professional Development subjects
            ex("UPDATE categories SET price_kobo=? WHERE id=?", (kobo, rid)); audit.log("price.subject", "category", rid, f"{r['name']} {kobo}")
        elif kind == "course":
            r = q1("SELECT * FROM courses WHERE id=?", (rid,)) or abort(404)
            ex("UPDATE courses SET price_kobo=?, updated_at=? WHERE id=?", (kobo, now(), rid)); audit.log("price.course", "course", rid, f"{r['title']} {kobo}")
        elif kind == "plan":
            r = q1("SELECT * FROM plans WHERE id=?", (rid,)) or abort(404)
            days = request.form.get("days", type=int) or r["duration_days"]
            if days < 1: flash("Duration must be at least 1 day.", "error"); return redirect(url_for("staff.pricing"))
            act = 1 if request.form.get("active") else 0
            if act and kobo <= 0: flash("Set a price before activating a plan.", "error"); return redirect(url_for("staff.pricing"))
            ex("UPDATE plans SET price_kobo=?, duration_days=?, active=? WHERE id=?", (kobo, days, act, rid)); audit.log("price.plan", "plan", rid, f"{r['name']} {kobo}")
        else: abort(400)
        flash("Price saved.", "success"); return redirect(url_for("staff.pricing"))
    courses = q(f"SELECT c.id, c.title, c.price_kobo, c.status, {A.EFFECTIVE} AS lvl, c.division FROM courses c ORDER BY c.title")
    return render_template("staff/pricing.html",
        subjects=q("SELECT * FROM categories WHERE division='academic' AND level='basic' ORDER BY active DESC, position, name"),
        subjects_adv=q("SELECT * FROM categories WHERE division='academic' AND level='advanced' ORDER BY active DESC, position, name"),
        subjects_pro=q("SELECT * FROM categories WHERE division='professional' ORDER BY active DESC, position, name"),
        income=[c for c in courses if c["division"] == "income"],
        adv=[c for c in courses if c["division"] == "academic" and c["lvl"] == "advanced"],
        pro=[c for c in courses if c["division"] == "professional"],
        basic_courses=[c for c in courses if c["division"] == "academic" and c["lvl"] == "basic"],
        plans=q("SELECT * FROM plans ORDER BY division, level, position"))

@bp.route("/broadcast", methods=["GET", "POST"])
@perm_required("notifications.manage")
def broadcast():
    if request.method == "POST":
        aud, title, body = request.form.get("audience"), request.form.get("title", "").strip(), request.form.get("body", "").strip()
        if not title: flash("Title is required.", "error")
        else:
            sqls = {"students": "SELECT id FROM users WHERE role='student' AND is_active=1", "everyone": "SELECT id FROM users WHERE is_active=1",
                    "basic": "SELECT DISTINCT user_id FROM entitlements WHERE kind='subscription' AND COALESCE(level,'basic')='basic' AND division='academic' AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at>?)",
                    "advanced": "SELECT DISTINCT user_id FROM entitlements WHERE kind='subscription' AND level='advanced' AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at>?)",
                    "income": "SELECT DISTINCT user_id FROM entitlements WHERE kind='subscription' AND division='income' AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at>?)"}
            if aud not in sqls: abort(400)
            ids = [r[0] for r in q(sqls[aud], (now(),) if "?" in sqls[aud] else ())]
            for i in ids: notify(i, title, body, None, "announcement")
            audit.log("broadcast", "notification", None, f"{aud}: {title} ({len(ids)} users)"); flash(f"Sent to {len(ids)} users.", "success"); return redirect(url_for("staff.broadcast"))
    return render_template("staff/broadcast.html")

@bp.route("/certificates", methods=["GET", "POST"])
@perm_required("certificates.manage")
def certs():
    if request.method == "POST":
        cid, act, reason = request.form.get("cert_id"), request.form.get("action"), request.form.get("reason", "").strip()
        if act == "revoke":
            if not reason: flash("A reason is required to revoke.", "error")
            else:
                ex("UPDATE certificates SET revoked_at=?, revoked_reason=?, revoked_by=? WHERE cert_id=? AND revoked_at IS NULL", (now(), reason, g.user["id"], cid)); audit.log("certificate.revoke", "certificate", cid, reason); flash("Certificate revoked.", "info")
        elif act == "reinstate":
            ex("UPDATE certificates SET revoked_at=NULL, revoked_reason=NULL WHERE cert_id=?", (cid,)); audit.log("certificate.reinstate", "certificate", cid, reason); flash("Certificate reinstated.", "info")
        return redirect(url_for("staff.certs"))
    s = request.args.get("q", "").strip()
    rows = q("SELECT * FROM certificates WHERE (?='' OR cert_id LIKE ? OR student_name LIKE ? OR course_title LIKE ?) ORDER BY issued_at DESC LIMIT 100", (s, f"%{s}%", f"%{s}%", f"%{s}%"))
    return render_template("staff/certs.html", rows=rows, q=s)

@bp.route("/audit")
@perm_required("audit.view")
def audit_view():
    page = max(1, request.args.get("page", 1, type=int)); s = request.args.get("q", "").strip()
    rows = q("SELECT * FROM audit_logs WHERE (?='' OR action LIKE ? OR detail LIKE ? OR entity_id LIKE ? OR actor_label LIKE ?) ORDER BY id DESC LIMIT 50 OFFSET ?", (s, *([f"%{s}%"] * 4), (page - 1) * 50))
    return render_template("staff/audit.html", rows=rows, page=page, q=s)

@bp.route("/system", methods=["GET", "POST"])
@perm_required("system.manage")
def system():
    if request.method == "POST":
        import os, tempfile, zipfile, sqlite3 as sq
        from flask import send_file
        tmp = tempfile.mktemp(suffix=".db"); src = sq.connect(current_app.config["DATABASE"]); dst = sq.connect(tmp); src.backup(dst); dst.close(); src.close()
        zpath = tempfile.mktemp(suffix=".zip")
        with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as z:
            z.write(tmp, "dagba.db")
            for label, d in (("private", current_app.config["PRIVATE_DIR"]), ("public", current_app.config["PUBLIC_DIR"])):
                if os.path.isdir(d):
                    for fn in os.listdir(d): z.write(os.path.join(d, fn), f"{label}/{fn}")
        os.remove(tmp); audit.log("system.backup", "system", None, "full backup downloaded")
        resp = send_file(zpath, mimetype="application/zip", as_attachment=True, download_name=f"dagba-backup-{now()[:10]}.zip")
        resp.call_on_close(lambda: os.path.exists(zpath) and os.remove(zpath))
        return resp
    return render_template("staff/system.html")
