"""Per-learning-path staff pages (Basic / Advanced / Professional / Income Skills): overview, students & enrolments, resources.
Every query is filtered to the one path in the URL by services.paths, and instructors only ever see their own courses."""
from flask import Blueprint, render_template, request, abort, g
from ..db import q, val
from ..security import login_required, has_perm
from ..services import paths as P

bp = Blueprint("paths", __name__, url_prefix="/staff/path")

def _path(ctx):
    if ctx not in P.PATHS or ctx == "faith": abort(404)
    u = g.user
    if not (has_perm("courses.manage") or u["role"] == "instructor"): abort(403)
    return u

def _scope(ctx, a="c"):
    """Courses of this path (and of this instructor, when the viewer is one)."""
    cs, ca = P.course_clause(ctx, a); w, args = [cs], list(ca)
    if g.user["role"] == "instructor": w.append(f"{a}.instructor_id=?"); args.append(g.user["id"])
    return " AND ".join(w), tuple(args)

@bp.route("/<ctx>")
@login_required
def overview(ctx):
    _path(ctx); w, a = _scope(ctx)
    own = g.user["role"] == "instructor"
    st = dict(
        courses=val(f"SELECT COUNT(*) FROM courses c WHERE {w}", a, 0),
        published=val(f"SELECT COUNT(*) FROM courses c WHERE {w} AND c.status='published'", a, 0),
        drafts=val(f"SELECT COUNT(*) FROM courses c WHERE {w} AND c.status IN ('draft','review')", a, 0),
        topics=val(f"SELECT COUNT(*) FROM modules m JOIN courses c ON c.id=m.course_id WHERE {w}", a, 0),
        lessons=val(f"SELECT COUNT(*) FROM lessons l JOIN courses c ON c.id=l.course_id WHERE {w}", a, 0),
        quizzes=val(f"SELECT COUNT(*) FROM quizzes z JOIN courses c ON c.id=z.course_id WHERE {w}", a, 0),
        assignments=val(f"SELECT COUNT(*) FROM assignments x JOIN courses c ON c.id=x.course_id WHERE {w}", a, 0),
        learners=val(f"SELECT COUNT(*) FROM (SELECT e.user_id FROM entitlements e JOIN courses c ON c.id=e.course_id WHERE e.kind='course' AND e.revoked_at IS NULL AND {w} UNION SELECT p.user_id FROM progress p JOIN courses c ON c.id=p.course_id WHERE {w})", a + a, 0))
    if not own:
        cw, ca = P.category_clause(ctx)
        st["subjects"] = val(f"SELECT COUNT(*) FROM categories WHERE {cw}", ca, 0)
    recent = q(f"SELECT c.id, c.title, c.status, c.updated_at FROM courses c WHERE {w} ORDER BY c.updated_at DESC LIMIT 6", a)
    return render_template("staff/path_overview.html", ctx=ctx, info=P.PATHS[ctx], st=st, recent=recent, own=own)

@bp.route("/<ctx>/enrolments")
@login_required
def enrolments(ctx):
    _path(ctx); w, a = _scope(ctx); s = request.args.get("q", "").strip()[:80]
    like = [f"%{s}%"] * 2 if s else []; flt = " AND (u.full_name LIKE ? OR u.email LIKE ?)" if s else ""
    rows = [dict(r, access="Course purchase" if r["how"] == "course" else "Free / in progress") for r in q(f"""
        SELECT u.id uid, u.full_name, u.email, c.title item, e.starts_at since, e.expires_at until, 'course' how
          FROM entitlements e JOIN users u ON u.id=e.user_id JOIN courses c ON c.id=e.course_id WHERE e.kind='course' AND e.revoked_at IS NULL AND {w}{flt}
        UNION
        SELECT u.id, u.full_name, u.email, c.title, MIN(p.updated_at), NULL, 'progress'
          FROM progress p JOIN users u ON u.id=p.user_id JOIN courses c ON c.id=p.course_id
         WHERE {w}{flt} AND NOT EXISTS (SELECT 1 FROM entitlements e WHERE e.user_id=p.user_id AND e.course_id=p.course_id AND e.kind='course' AND e.revoked_at IS NULL)
         GROUP BY u.id, c.id ORDER BY since DESC LIMIT 300""", a + tuple(like) + a + tuple(like))]
    if ctx in ("basic", "advanced", "professional") and g.user["role"] != "instructor":      # Basic, Advanced and Professional Development are bought per subject
        cw, ca = P.category_clause(ctx, "cat")
        rows += [dict(r, access="Subject purchase") for r in q(f"""SELECT u.id uid, u.full_name, u.email, cat.name item, e.starts_at since, e.expires_at until FROM entitlements e
            JOIN users u ON u.id=e.user_id JOIN categories cat ON cat.id=e.category_id WHERE e.kind='subject' AND e.revoked_at IS NULL AND {cw}{flt} ORDER BY e.starts_at DESC LIMIT 300""", ca + tuple(like))]
    if ctx != "professional" and g.user["role"] != "instructor":                          # Professional has no subscription
        sc = "COALESCE(e.level, CASE WHEN e.division='academic' THEN 'basic' ELSE 'income' END)=?"
        rows += [dict(r, access="Subscription") for r in q(f"""SELECT u.id uid, u.full_name, u.email, COALESCE(p.name,'Subscription') item, e.starts_at since, e.expires_at until FROM entitlements e
            JOIN users u ON u.id=e.user_id LEFT JOIN plans p ON p.id=e.plan_id WHERE e.kind='subscription' AND e.revoked_at IS NULL AND {sc}{flt} ORDER BY e.starts_at DESC LIMIT 300""", (ctx,) + tuple(like))]
    rows.sort(key=lambda r: r["since"] or "", reverse=True)
    return render_template("staff/path_enrolments.html", ctx=ctx, info=P.PATHS[ctx], rows=rows[:300], q=s)

@bp.route("/<ctx>/resources")
@login_required
def resources(ctx):
    _path(ctx); w, a = _scope(ctx); s = request.args.get("q", "").strip()[:80]
    flt, fa = (" AND (l.title LIKE ? OR l.resource_name LIKE ? OR c.title LIKE ?)", [f"%{s}%"] * 3) if s else ("", [])
    rows = q(f"""SELECT l.id, l.title, l.resource_name, l.kind, c.id cid, c.title course, m.title topic FROM lessons l JOIN courses c ON c.id=l.course_id LEFT JOIN modules m ON m.id=l.module_id
                 WHERE {w} AND l.resource_file IS NOT NULL AND l.resource_file!=''{flt} ORDER BY c.title, l.position LIMIT 300""", a + tuple(fa))
    return render_template("staff/path_resources.html", ctx=ctx, info=P.PATHS[ctx], rows=rows, q=s)
