"""One-page Course Builder + admin Course Catalog."""
import csv, io
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, jsonify, Response, current_app
from ..db import q, q1, ex, val
from ..util import now, naira
from ..security import login_required, has_perm
from ..services import paths as P
from ..services import builder as B, uploads, audit, settings as S, academic as A
from ..services.notify import notify_staff

bp = Blueprint("builder", __name__, url_prefix="/staff")

def _author(cid=None):
    """Admins with courses.manage, and instructors, may author courses. A student with an open tutor application may author ONLY that
    application's course (cid is required), and only while the application is still editable."""
    from ..services import tutors as T
    u = g.user
    if u["role"] == "instructor":
        if T.is_suspended(u["id"]): abort(403, "Your tutor account is suspended. Please contact the academy.")
        return u
    if u["role"] == "admin" and has_perm("courses.manage"): return u
    if u["role"] == "student" and cid and T.applicant_course_ok(u, cid): return u
    abort(403)

def _author_up():
    """Upload endpoints: staff as usual; an applicant (student with an editable application course) may upload their own course files."""
    from ..services import tutors as T
    if g.user["role"] == "student" and T.is_applicant(g.user): return g.user
    return _author()

def api(f):
    """JSON endpoints: an expired session returns a clean 401 (the page shows a message) instead of redirecting to an HTML login page."""
    from functools import wraps
    @wraps(f)
    def w(*a, **k):
        if not g.user: return jsonify(ok=False, error="Your session expired. Log in again in another tab, then retry (your upload progress is kept)."), 401
        return f(*a, **k)
    return w

def _json_err(e):
    return jsonify(ok=False, error=str(e), **getattr(e, "extra", {})), e.status

def _cats():
    return [dict(id=r["id"], name=r["name"], division=r["division"], level=r["level"]) for r in q("SELECT * FROM categories WHERE active=1 ORDER BY division, level, position, name")]

@bp.route("/builder")
@bp.route("/builder/<int:cid>")
@login_required
def page(cid=None):
    u = _author(cid); is_admin = u["role"] == "admin"; applicant = u["role"] == "student"
    if cid:
        c = q1("SELECT * FROM courses WHERE id=?", (cid,))
        if not c or (not is_admin and c["instructor_id"] != u["id"]): abort(404)
        data = B.load_course(cid)
    else:
        data = B.blank_course(); cx = P.valid(request.args.get("ctx"))
        if cx in ("income", "professional"): data.update(division=cx, academic_level="")
        elif cx in P.ACADEMIC: data.update(division="academic", academic_level=cx)
    instructors = [dict(id=r["id"], name=r["full_name"]) for r in q("SELECT id, full_name FROM users WHERE role IN ('instructor','admin') AND is_active=1 ORDER BY full_name")] if is_admin else []
    return render_template("staff/builder.html", data=data, cats=_cats(), instructors=instructors, is_admin=is_admin, applicant=applicant, max_mb=B.video_limit_mb(), chunk=B.CHUNK)

# ---- resumable chunked video upload ------------------------------------------------
@bp.route("/builder/upload/init", methods=["POST"])
@api
def upload_init():
    u = _author_up(); j = request.get_json(silent=True) or {}
    try: uid = B.init_upload(u, str(j.get("name") or ""), j.get("size"))
    except B.BuilderError as e: return _json_err(e)
    return jsonify(ok=True, upload_id=uid, chunk=B.CHUNK)

@bp.route("/builder/upload/<uid>/status")
@api
def upload_status(uid):
    u = _author_up(); r = q1("SELECT * FROM uploads WHERE id=? AND user_id=?", (uid, u["id"]))
    if not r: abort(404)
    return jsonify(ok=True, next_index=r["next_index"], received=r["received"], size=r["size"], status=r["status"])

@bp.route("/builder/upload/<uid>/chunk", methods=["POST"])
@api
def upload_chunk(uid):
    u = _author_up()
    try: got = B.append_chunk(u, uid, request.args.get("index", -1, type=int), request.get_data())
    except B.BuilderError as e: return _json_err(e)
    return jsonify(ok=True, received=got)

@bp.route("/builder/upload/<uid>/finish", methods=["POST"])
@api
def upload_finish(uid):
    u = _author_up()
    try: stored, name = B.finish_upload(u, uid)
    except B.BuilderError as e: return _json_err(e)
    size = val("SELECT size FROM uploads WHERE id=?", (uid,), 0)
    return jsonify(ok=True, file=stored, name=name, size=size)

@bp.route("/builder/resource", methods=["POST"])
@api
def upload_resource():
    u = _author_up(); f = request.files.get("file")
    if not f or not f.filename: return jsonify(ok=False, error="Choose a file."), 400
    try: stored, _ext, _mime, size = uploads.save_resource(f)
    except uploads.UploadError as e: return jsonify(ok=False, error=str(e)), 400
    B.register_resource(u, stored, f.filename, size)
    return jsonify(ok=True, file=stored, name=f.filename[:150])

@bp.route("/builder/thumbnail", methods=["POST"])
@api
def upload_thumb():
    _author_up(); f = request.files.get("file")
    if not f or not f.filename: return jsonify(ok=False, error="Choose an image."), 400
    try: name = uploads.save_public_image(f)
    except uploads.UploadError as e: return jsonify(ok=False, error=str(e)), 400
    return jsonify(ok=True, file=name, url=url_for("public.media", name=name))

@bp.route("/builder/save", methods=["POST"])
@api
def save():
    from ..services import tutors as T
    p = request.get_json(silent=True)
    if not isinstance(p, dict): return jsonify(ok=False, error="Invalid request."), 400
    cid_in = B._i(p.get("id")); u = _author(cid_in)
    applicant = u["role"] == "student"
    if applicant:
        if not cid_in: return jsonify(ok=False, error="Start from your tutor application to add a course."), 403
        p["action"] = "draft"                                            # applicants never publish or self-submit here; they submit from the application page
    elif u["role"] == "admin" and p.get("action") == "publish" and cid_in:
        msg = T.publish_blocked(cid_in) if val("SELECT status FROM courses WHERE id=?", (cid_in,)) != "published" else None
        if msg: return jsonify(ok=False, error=msg, errors=[msg]), 400   # only approved courses can be published
    try: cid, status = B.save_course(u, p, "publish" if p.get("action") == "publish" else "draft")
    except B.BuilderError as e: return _json_err(e)
    if applicant:
        a = q1("SELECT id FROM tutor_applications WHERE course_id=? AND user_id=? ORDER BY id DESC LIMIT 1", (cid, u["id"]))
        if a: T.pull_from_course(a["id"])
    elif status == "review":
        if u["role"] == "instructor": T.course_submitted(cid, u)           # joins the Tutor applications queue and tells the reviewers
        else: notify_staff("courses.manage", "Course ready for review", p.get("title", ""), url_for("builder.page", cid=cid), "content")
    elif status == "published" and u["role"] == "admin": T.finalize_publish(u, cid)
    return jsonify(ok=True, id=cid, status=status, redirect=url_for("builder.page", cid=cid, saved=1))

# ---- Catalog -----------------------------------------------------------------------
def _catalog_query():
    u = g.user; where, a = ["1=1"], []
    if u["role"] == "instructor": where.append("c.instructor_id=?"); a.append(u["id"])
    for k, col in (("division", "c.division"), ("status", "c.status"), ("category", "c.category_id"), ("instructor", "c.instructor_id")):
        v = request.args.get(k, "")
        if v and (k != "instructor" or u["role"] == "admin"): where.append(f"{col}=?"); a.append(v)
    cx = P.valid(request.args.get("ctx"))
    if cx and cx != "faith": cs, ca = P.course_clause(cx, "c"); where.append(cs); a += list(ca)
    lv = request.args.get("level", "")
    if lv in A.LEVELS: where.append(f"c.division='academic' AND {A.EFFECTIVE}=?"); a.append(lv)
    if request.args.get("review") == "1": where.append("c.needs_review=1")
    s = request.args.get("q", "").strip()
    if s: where.append("(c.title LIKE ? OR c.subject LIKE ? OR c.summary LIKE ?)"); a += [f"%{s}%"] * 3
    sort = {"new": "c.created_at DESC", "title": "c.title COLLATE NOCASE", "price": "c.price_kobo DESC", "learners": "learners DESC"}.get(request.args.get("sort"), "c.created_at DESC")
    sql = f"""SELECT c.*, cat.name AS category, cat.level AS cat_level, u.full_name AS instructor,
        (SELECT COUNT(*) FROM lessons l WHERE l.course_id=c.id) AS lessons,
        (SELECT COUNT(*) FROM lessons l WHERE l.course_id=c.id AND l.video_file IS NOT NULL AND l.video_file!='') AS videos,
        (SELECT COALESCE(SUM(video_size),0) FROM lessons l WHERE l.course_id=c.id) AS video_bytes,
        (SELECT COUNT(*) FROM quizzes z WHERE z.course_id=c.id) AS quizzes,
        (SELECT COUNT(*) FROM (SELECT user_id FROM entitlements e WHERE e.course_id=c.id AND e.revoked_at IS NULL UNION SELECT user_id FROM progress p WHERE p.course_id=c.id)) AS learners,
        (SELECT COALESCE(SUM(amount_kobo),0) FROM transactions t WHERE t.course_id=c.id AND t.status='approved') AS revenue
        FROM courses c LEFT JOIN categories cat ON cat.id=c.category_id LEFT JOIN users u ON u.id=c.instructor_id WHERE {' AND '.join(where)} ORDER BY {sort}"""
    return sql, a

@bp.route("/catalog")
@login_required
def catalog():
    _author(); sql, a = _catalog_query(); page = max(1, request.args.get("page", 1, type=int)); per = 18
    total = val(f"SELECT COUNT(*) FROM ({sql})", a, 0)
    rows = q(sql + " LIMIT ? OFFSET ?", tuple(a) + (per, (page - 1) * per))
    own = "WHERE instructor_id=%d" % g.user["id"] if g.user["role"] == "instructor" else ""
    stats = q1(f"""SELECT COUNT(*) total, COALESCE(SUM(needs_review),0) review, SUM(status='published') published, SUM(status IN ('draft','review')) drafts, SUM(status='archived') archived,
        (SELECT COUNT(*) FROM lessons WHERE course_id IN (SELECT id FROM courses {own})) lessons,
        (SELECT COUNT(*) FROM lessons WHERE video_file IS NOT NULL AND video_file!='' AND course_id IN (SELECT id FROM courses {own})) videos,
        (SELECT COALESCE(SUM(video_size),0) FROM lessons WHERE course_id IN (SELECT id FROM courses {own})) video_bytes FROM courses {own}""")
    instructors = q("SELECT id, full_name FROM users WHERE role IN ('instructor','admin') ORDER BY full_name") if g.user["role"] == "admin" else []
    return render_template("staff/catalog.html", rows=rows, total=total, page=page, per=per, stats=stats, cats=q("SELECT * FROM categories ORDER BY division, level, name"), instructors=instructors, LV=A.LEVELS,
                           show_money=has_perm("reports.view"), args=request.args)

@bp.route("/catalog/export.csv")
@login_required
def catalog_csv():
    _author(); sql, a = _catalog_query(); rows = q(sql, a); money = has_perm("reports.view")
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["ID", "Title", "Division", "Academic category", "Subject / category", "Needs review", "Status", "Price (NGN)", "Instructor", "Lessons", "Uploaded videos", "Quizzes", "Learners"] + (["Confirmed revenue (NGN)"] if money else []) + ["Created"])
    safe = lambda v: "'" + v if isinstance(v, str) and v[:1] in "=+-@\t\r" else v
    for r in rows:
        w.writerow([safe(x) for x in [r["id"], r["title"], r["division"], (A.label(r["academic_level"]) if r["division"] == "academic" else ""), r["category"] or "", "yes" if r["needs_review"] else "", r["status"], r["price_kobo"] / 100, r["instructor"] or "", r["lessons"], r["videos"], r["quizzes"], r["learners"]]
                   + ([r["revenue"] / 100] if money else []) + [r["created_at"]]])
    audit.log("export.csv", "export", "catalog")
    return Response(buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=course-catalog.csv"})

@bp.route("/catalog/<int:cid>/status", methods=["POST"])
@login_required
def catalog_status(cid):
    if not has_perm("courses.manage"): abort(403)
    c = q1("SELECT * FROM courses WHERE id=?", (cid,)) or abort(404); st = request.form.get("status")
    if st not in ("published", "draft", "archived"): abort(400)
    from ..services import tutors as T
    if st == "published" and c["status"] != "published" and T.publish_blocked(cid): flash(T.publish_blocked(cid), "error")
    elif st == "published" and not val("SELECT COUNT(*) FROM lessons WHERE course_id=?", (cid,), 0):
        flash("Add at least one lesson before publishing.", "error")
    else:
        ex("UPDATE courses SET status=?, updated_at=? WHERE id=?", (st, now(), cid)); audit.log("course.status", "courses", cid, f"{c['status']} -> {st}")
        if st == "published" and c["status"] != "published": T.finalize_publish(g.user, cid)       # publishing a course that waited for review = approving it
        flash(f"'{c['title']}' is now {st}.", "success")
    return redirect(request.referrer or url_for("builder.catalog"))


# ---- Academic structure (admin): subjects per level + review queue ---------------------------------
def _targets():
    """Every place an academic course can live, as 'level:category_id' choices for the review form."""
    out = []
    for lv, info in A.LEVELS.items():
        rows = q("SELECT id, name FROM categories WHERE division='academic' AND level=? AND active=1 ORDER BY position, name", (lv,))
        out.append((info["name"], [(f"{lv}:{r['id']}", r["name"]) for r in rows] + ([(f"{lv}:", "(Professional: no programme area)")] if lv == "professional" else [])))
    return out

@bp.route("/academic")
@login_required
def academic_structure():
    if not has_perm("courses.manage"): abort(403)
    panels = []
    for lv, info in A.ALL.items():                 # Basic, Advanced (Academic) and Professional Development (its own division)
        w, wa = A._cat_where(lv)
        rows = q(f"""SELECT c.*, (SELECT COUNT(*) FROM courses x WHERE x.category_id=c.id AND x.status='published') pub, (SELECT COUNT(*) FROM courses x WHERE x.category_id=c.id) total
                    FROM categories c WHERE {w.replace('division', 'c.division').replace('level', 'c.level')} ORDER BY c.active DESC, c.position, c.name""", wa)
        loose = A.uncategorised_count(lv) if lv == "professional" else val("SELECT COUNT(*) FROM courses WHERE division='academic' AND category_id IS NULL AND COALESCE(academic_level,'basic')=?", (lv,), 0)
        panels.append(dict(key=lv, info=info, rows=rows, loose=loose))
    review = q("""SELECT c.*, cat.name AS category FROM courses c LEFT JOIN categories cat ON cat.id=c.category_id WHERE c.division='academic' AND c.needs_review=1 ORDER BY c.title""")
    return render_template("staff/academic.html", panels=panels, review=review, targets=_targets())

@bp.route("/academic/assign/<int:cid>", methods=["POST"])
@login_required
def academic_assign(cid):
    if not has_perm("courses.manage"): abort(403)
    c = q1("SELECT * FROM courses WHERE id=? AND division='academic'", (cid,)) or abort(404)
    lv, _, cat = (request.form.get("target") or "").partition(":")
    errs, lv2, cat2 = A.validate("academic", lv, int(cat) if cat.isdigit() else None, False)
    if lv2 in ("basic", "advanced") and not cat2 and not errs: errs = ["Choose a subject for this course."]
    if errs: flash(errs[0], "error")
    else:
        ex("UPDATE courses SET academic_level=?, category_id=?, needs_review=0, updated_at=? WHERE id=?", (lv2, cat2, now(), cid))
        audit.log("course.academic_assign", "courses", cid, f"{c['title']} -> {lv2}/{cat2}"); flash(f"'{c['title']}' moved to {A.label(lv2)}.", "success")
    return redirect(request.referrer or url_for("builder.academic_structure"))


@bp.route("/academic/category/<int:cid>", methods=["GET", "POST"])
@login_required
def academic_category(cid):
    """Choose which courses sit under a subject of ANY subject-priced division (Basic, Advanced or Professional Development).
    The subject's price, cover image and homepage featuring are edited with the subject itself."""
    if not has_perm("courses.manage"): abort(403)
    from ..services.access import subject_scope
    cat = q1("SELECT * FROM categories WHERE id=?", (cid,)) or abort(404)
    scope = subject_scope(cat) or abort(404)
    if scope == "professional": base, args = "division='professional'", ()
    else: base, args = "division='academic' AND COALESCE(academic_level,'basic')=?", (scope,)
    if request.method == "POST":
        chosen = {int(x) for x in request.form.getlist("course") if x.isdigit()}
        valid = {r["id"] for r in q(f"SELECT id FROM courses WHERE {base}", args)}
        current = {r["id"] for r in q("SELECT id FROM courses WHERE category_id=?", (cid,))}
        add, drop = (chosen & valid) - current, current - chosen
        for course_id in add:
            if scope == "professional": ex("UPDATE courses SET category_id=?, needs_review=0, updated_at=? WHERE id=?", (cid, now(), course_id))
            else: ex("UPDATE courses SET category_id=?, academic_level=?, needs_review=0, updated_at=? WHERE id=?", (cid, scope, now(), course_id))
        for course_id in drop: ex("UPDATE courses SET category_id=NULL, updated_at=? WHERE id=?", (now(), course_id))
        audit.log("category.courses", "category", cid, f"{cat['name']}: +{len(add)} -{len(drop)}")
        flash(f"{cat['name']} updated: {len(chosen & valid)} course{'s' if len(chosen & valid) != 1 else ''} assigned.", "success")
        return redirect(url_for("builder.academic_category", cid=cid))
    rows = q(f"""SELECT c.id, c.title, c.status, c.category_id, o.name AS other FROM courses c LEFT JOIN categories o ON o.id=c.category_id
                WHERE {base.replace('division', 'c.division').replace('academic_level', 'c.academic_level')} ORDER BY (c.category_id=?) DESC, c.title""", args + (cid,))
    return render_template("staff/academic_category.html", cat=cat, rows=rows, scope=scope, scope_name=A.ALL[scope]["name"])
