"""Learning paths: public/student pages (/learning-paths) and the teacher/admin editor (/staff/learning-paths)."""
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort
from ..db import q, q1
from ..security import login_required
from ..services import pathways as PW

bp = Blueprint("learnpaths", __name__)

@bp.route("/learning-paths")
def index():
    rows = PW.list_published(); uid = g.user["id"] if g.user else None
    return render_template("public/learning_paths.html", paths=[dict(path=p, prog=PW.progress(uid, p) if uid else None) for p in rows])

@bp.route("/learning-paths/<slug>")
def detail(slug):
    p = PW.by_slug(slug) or abort(404)
    if p["status"] != "published" and not (g.user and PW.can_manage(g.user, p)): abort(404)
    return render_template("public/learning_path.html", p=p, prog=PW.progress(g.user["id"] if g.user else None, p), preview=p["status"] != "published")

# ------------------------------------------------------------------ editor
def _teacher():
    if g.user["role"] not in ("instructor", "admin"): abort(403)
    if g.user["role"] == "admin" and not PW._staff_all(g.user): abort(403)

@bp.route("/staff/learning-paths", methods=["GET", "POST"])
@login_required
def manage():
    _teacher()
    if request.method == "POST":
        try: pid = PW.save_path(g.user, request.form); flash("Learning path created. Add courses to it next.", "success"); return redirect(url_for("learnpaths.edit", pid=pid))
        except PW.PathError as e: flash(str(e), "error")
    return render_template("staff/learning_paths.html", paths=PW.managed(g.user))

@bp.route("/staff/learning-paths/<int:pid>", methods=["GET", "POST"])
@login_required
def edit(pid):
    _teacher(); p = PW.get(pid) or abort(404)
    if not PW.can_manage(g.user, p): abort(404)
    if request.method == "POST":
        f = request.form; act = f.get("action"); cid = f.get("course_id", type=int)
        try:
            if act == "save": PW.save_path(g.user, f, pid); flash("Saved.", "success")
            elif act == "add": PW.add_course(g.user, pid, cid); flash("Course added.", "success")
            elif act == "remove": PW.remove_course(g.user, pid, cid); flash("Course removed from the path.", "success")
            elif act in ("up", "down"): PW.move_course(g.user, pid, cid, act)
            elif act == "prereq": PW.set_prerequisites(g.user, pid, cid, f.getlist("requires")); flash("Prerequisites saved.", "success")
            elif act == "delete": PW.delete_path(g.user, pid); flash("Learning path deleted. Courses were not affected.", "success"); return redirect(url_for("learnpaths.manage"))
            else: abort(400)
        except PW.PathError as e: flash(str(e), "error")
        return redirect(url_for("learnpaths.edit", pid=pid))
    cs = PW.courses(pid)
    return render_template("staff/learning_path_edit.html", p=PW.get(pid), cs=cs, pm=PW.prereq_map(pid), addable=PW.addable_courses(g.user, pid))
