"""Pre-Launch Mode pages.
 public   GET /pre-launch (the countdown page; also the admin preview), POST /prelaunch/subscribe (email early registration)
 admin    /staff/prelaunch (settings, permission prelaunch.manage), /staff/prelaunch/signups[.csv] (registrations and collected emails)
The access gate itself is services/prelaunch.gate(), run on every request from the app's before_request hook."""
import csv, io
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, Response
from ..db import q, q1, val, ex
from ..security import login_required, perm_required, has_perm, rate_limited, client_ip
from ..services import prelaunch as P, settings as S, audit

bp = Blueprint("prelaunch", __name__)

TEXT_FIELDS = (("badge", "Badge above the title", 120), ("title", "Headline", 150), ("message", "Supporting message", 900), ("countdown_label", "Countdown caption", 80), ("live_text", "Message shown when the countdown reaches zero", 120),
               ("signup_title", "Email sign-up heading", 100), ("signup_text", "Email sign-up text", 300), ("signup_button", "Email sign-up button", 40), ("success_text", "Message after signing up", 200),
               ("account_text", "Create-account text", 300), ("account_button", "Create-account button", 40), ("registered_text", "Message for students who are already registered ({name} = first name)", 300),
               ("social_title", "Social links heading", 100), ("footer", "Footer line", 160))

@bp.route("/pre-launch")
def page():
    if P.restricting(): return P.countdown_response()
    if g.user and g.user["role"] == "admin": return P.countdown_response(preview=True)       # admins can preview the page at any time
    return redirect(url_for("public.home"))

@bp.route("/prelaunch/subscribe", methods=["POST"])
def subscribe():
    if not P.restricting() or not S.flag("prelaunch.signup_enabled"): return redirect(url_for("public.home"))
    f = request.form
    if f.get("website"): return redirect(url_for("public.home") + "#signup")                  # honeypot: bots fill the hidden field
    if rate_limited(f"prelaunch:{client_ip()}", 12, 3600): flash("Too many attempts. Please try again later.", "error")
    else:
        try:
            P.record_email(f.get("email", ""), f.get("name", ""), client_ip()); flash(P.text("success_text") or "You are on the list.", "success")   # same message for new and repeat addresses
        except ValueError as e: flash(str(e), "error")
    return redirect(url_for("public.home") + "#signup")

def _valid(f):
    errs, out = [], {}
    d, t = (f.get("launch_date") or "").strip(), (f.get("launch_time") or "").strip()
    at = f"{d}T{t}" if d and t else ""
    if not P.parse_launch(at): errs.append("Enter a valid launch date and time.")
    off = f.get("utc_offset", "")
    if off not in {o for o, _ in P.OFFSETS}: errs.append("Choose a time zone from the list.")
    out["prelaunch.launch_at"] = at; out["prelaunch.utc_offset"] = off
    out["prelaunch.enabled"] = "1" if f.get("enabled") else "0"; out["prelaunch.show_countdown"] = "1" if f.get("show_countdown") else "0"
    out["prelaunch.signup_enabled"] = "1" if f.get("signup_enabled") else "0"; out["prelaunch.register_enabled"] = "1" if f.get("register_enabled") else "0"
    allowed = {r for r, _ in P.BYPASS_CHOICES}; out["prelaunch.bypass_roles"] = ",".join(r for r in f.getlist("bypass") if r in allowed)
    for key, label, mx in TEXT_FIELDS:
        v = (f.get(key) or "").strip()
        if len(v) > mx: errs.append(f"{label} is too long (maximum {mx} characters).")
        out["prelaunch." + key] = v
    return errs, out

@bp.route("/staff/prelaunch", methods=["GET", "POST"])
@perm_required("prelaunch.manage")
def settings():
    if request.method == "POST":
        if request.form.get("action") in ("open_now", "close_now"):
            on = request.form["action"] == "close_now"; S.put("prelaunch.enabled", "1" if on else "0")
            audit.log("prelaunch.switched", "setting", "prelaunch.enabled", "ON" if on else "OFF")
            flash("Pre-Launch Mode is ON. Only administrators" + (" and the allowed roles" if P.bypass_roles() - {"admin"} else "") + " can open the site." if on else "Pre-Launch Mode is OFF. The website is open to everyone.", "success")
            return redirect(url_for("prelaunch.settings"))
        errs, new = _valid(request.form)
        if errs:
            for e in errs: flash(e, "error")
        else:
            old = {k: S.get(k) for k in new}; changed = [k for k in new if (old[k] or "") != new[k]]
            for k, v in new.items(): S.put(k, v)
            audit.log("prelaunch.settings_saved", "setting", "prelaunch", ", ".join(k.replace("prelaunch.", "") for k in changed) or "no changes")
            if new["prelaunch.enabled"] == "1" and P.launched(): flash("Saved. Note: the launch time is already in the past, so the site is open to everyone.", "info")
            else: flash("Saved. The change is live now.", "success")
            return redirect(url_for("prelaunch.settings"))
    lt = P.launch_at().astimezone(P._offset())
    return render_template("staff/prelaunch.html", P=P, fields=TEXT_FIELDS, d=lt.strftime("%Y-%m-%d"), t=lt.strftime("%H:%M"), counts=P.counts(), restricting=P.restricting(), launched=P.launched(), bypass=P.bypass_roles(), extra_roles=sorted(P.bypass_roles() - {"admin"}), text=P.text)

@bp.route("/staff/prelaunch/signups")
@perm_required("prelaunch.manage")
def signups():
    sql, a = P.list_query(request.args); page = max(1, request.args.get("page", 1, type=int)); per = 50
    total = val(f"SELECT COUNT(*) FROM ({sql})", a, 0); rows = q(sql + " LIMIT ? OFFSET ?", a + (per, (page - 1) * per))
    return render_template("staff/prelaunch_signups.html", rows=rows, total=total, pg=dict(page=page, pages=max(1, -(-total // per))), counts=P.counts(), f=dict(q=request.args.get("q", ""), source=request.args.get("source", "")))

@bp.route("/staff/prelaunch/signups/<int:sid>/delete", methods=["POST"])
@perm_required("prelaunch.manage")
def signup_delete(sid):
    r = q1("SELECT * FROM prelaunch_signups WHERE id=?", (sid,)) or abort(404)
    if r["user_id"]: flash("This person has an account. Manage them under Users.", "error"); return redirect(url_for("prelaunch.signups"))
    ex("DELETE FROM prelaunch_signups WHERE id=?", (sid,)); audit.log("prelaunch.signup_removed", "prelaunch_signup", sid, r["email"]); flash("Email removed.", "success")
    return redirect(url_for("prelaunch.signups"))

@bp.route("/staff/prelaunch/signups.csv")
@perm_required("prelaunch.manage")
def signups_csv():
    sql, a = P.list_query(request.args); safe = lambda v: "'" + v if isinstance(v, str) and v[:1] in "=+-@\t\r" else v
    buf = io.StringIO(); w = csv.writer(buf); w.writerow(["Email", "Name", "Type", "Registered (UTC)"])
    for r in q(sql + " LIMIT 50000", a): w.writerow([safe(r["email"]), safe(r["name"] or ""), "Account" if r["source"] == "account" else "Email only", r["created_at"]])
    audit.log("prelaunch.exported", "export", "prelaunch-registrations.csv", "")
    return Response(buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=prelaunch-registrations.csv", "Cache-Control": "no-store, private"})
