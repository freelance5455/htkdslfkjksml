"""Affiliate programme: public tracking links (/r/<name>), the affiliate's own dashboard (/affiliate) and admin management (/staff/affiliates)."""
import csv, io
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, Response, send_from_directory, current_app
from ..db import q, q1, ex, val
from ..security import login_required, perm_required, has_perm
from ..services import affiliates as A, payouts as PO, settings as S, audit

bp = Blueprint("affiliates", __name__)
LABEL = {"requested": "Waiting to be paid", "paid": "Paid", "rejected": "Declined", "cancelled": "Cancelled"}

# ------------------------------------------------------------------ tracking links
def _safe_path(p):
    return p if p and p.startswith("/") and not p.startswith("//") and "\\" not in p and not p.startswith(("/staff", "/affiliate")) else None

@bp.route("/r/<slug>")
def go(slug):
    v = A.landing(slug)
    if v: g.new_ref = v
    resp = redirect(_safe_path(request.args.get("to")) or url_for("public.home"))
    resp.headers["Cache-Control"] = "no-store"        # a cached redirect would skip the click count and the cookie
    return resp

@bp.before_app_request
def _ref_param():
    """Any public page can carry ?ref=<name> (handy for linking an affiliate straight to one course)."""
    g.pop("new_ref", None)                               # never let a flag from an earlier request leak into this one
    slug = request.args.get("ref")
    if slug and request.method == "GET" and request.endpoint and request.endpoint != "static" and not request.path.startswith(("/r/", "/staff", "/affiliate")):
        v = A.landing(slug)
        if v: g.new_ref = v

@bp.after_app_request
def _set_ref_cookie(resp):
    v = g.get("new_ref")
    if v:
        resp.set_cookie(A.COOKIE, v, max_age=A.COOKIE_DAYS * 86400, httponly=True, samesite="Lax", secure=bool(current_app.config.get("SESSION_COOKIE_SECURE")))
    return resp

# ------------------------------------------------------------------ the affiliate's own page
def _mine():
    a = A.for_user(g.user["id"])
    if not a: abort(404)
    return a

def _fresh_user(): return q1("SELECT * FROM users WHERE id=?", (g.user["id"],))

@bp.route("/affiliate")
@login_required
def dashboard():
    a = _mine(); page = max(1, request.args.get("page", 1, type=int)); per = 15
    s = A.summary(a["id"])
    earns = q("""SELECT e.*, t.item_title, b.full_name AS buyer FROM affiliate_earnings e JOIN transactions t ON t.id=e.transaction_id JOIN users b ON b.id=e.buyer_id
                 WHERE e.affiliate_id=? ORDER BY e.created_at DESC, e.id DESC LIMIT ? OFFSET ?""", (a["id"], per, (page - 1) * per))
    refs = q("""SELECT u.id, u.full_name, u.referred_at, COUNT(CASE WHEN e.kind='sale' THEN 1 END) AS n, COALESCE(SUM(e.amount_kobo),0) AS amt
                FROM users u LEFT JOIN affiliate_earnings e ON e.buyer_id=u.id AND e.affiliate_id=? WHERE u.referred_by_affiliate=? GROUP BY u.id ORDER BY u.referred_at DESC LIMIT 50""", (a["id"], a["id"]))
    reqs = q("SELECT * FROM affiliate_payouts WHERE affiliate_id=? ORDER BY requested_at DESC, id DESC", (a["id"],))
    return render_template("affiliate/dashboard.html", a=a, s=s, link=A.link_for(a["slug"]), site=current_app.config["SITE_URL"], rate=A.rate_for(a), me=_fresh_user(), earns=earns, refs=refs, reqs=reqs,
        open_req=next((r for r in reqs if r["status"] == "requested"), None), page=page, per=per, total=val("SELECT COUNT(*) FROM affiliate_earnings WHERE affiliate_id=?", (a["id"],), 0),
        mask=A.mask_name, enabled=A.enabled(), payout_on=S.flag("affiliate.payout_enabled"), min_amt=A.min_kobo(), instructions=S.get("affiliate.instructions"), on_plans=S.flag("affiliate.on_plans"), LABEL=LABEL)

@bp.route("/affiliate/link", methods=["POST"])
@login_required
def my_link():
    a = _mine()
    if a["status"] != "active": flash("Your affiliate link is no longer active.", "error")
    else:
        try:
            if A.update(g.user, a, slug_text=request.form.get("slug", "")): flash("Your link name was changed. Your OLD link no longer works, so update it wherever you have shared it.", "success")
            else: flash("No changes.", "info")
        except A.AffError as e: flash(str(e), "error")
    return redirect(url_for("affiliates.dashboard"))

@bp.route("/affiliate/account", methods=["POST"])
@login_required
def my_account():
    _mine(); f = request.form
    try: PO.save_bank(g.user, f.get("bank"), f.get("account_name"), f.get("account_number")); flash("Bank details saved.", "success")
    except PO.PayoutError as e: flash(str(e), "error")
    return redirect(url_for("affiliates.dashboard"))

@bp.route("/affiliate/request", methods=["POST"])
@login_required
def my_request():
    a = _mine(); f = request.form
    try:
        if f.get("bank"): PO.save_bank(g.user, f.get("bank"), f.get("account_name"), f.get("account_number"))
        A.request_payout(g.user, a, f.get("amount", ""))
        flash("Withdrawal requested. The academy has been notified and will pay you by bank transfer.", "success")
    except (A.AffError, PO.PayoutError) as e: flash(str(e), "error")
    return redirect(url_for("affiliates.dashboard"))

@bp.route("/affiliate/<int:rid>/cancel", methods=["POST"])
@login_required
def my_cancel(rid):
    a = _mine()
    try: A.cancel_payout(g.user, a, rid); flash("Request cancelled. The money is back in your available balance.", "info")
    except A.AffError as e: flash(str(e), "error")
    return redirect(url_for("affiliates.dashboard"))

@bp.route("/affiliate/receipt/<int:rid>")
@login_required
def receipt(rid):
    r = q1("SELECT r.*, a.user_id FROM affiliate_payouts r JOIN affiliates a ON a.id=r.affiliate_id WHERE r.id=?", (rid,))
    if not r or not r["receipt_file"]: abort(404)
    if not (r["user_id"] == g.user["id"] or has_perm("affiliates.manage")): abort(403)
    resp = send_from_directory(current_app.config["PRIVATE_DIR"], r["receipt_file"], mimetype=r["receipt_mime"], as_attachment=False)
    resp.headers["Content-Disposition"] = "inline"; resp.headers["Cache-Control"] = "private, no-store"
    resp.headers["Content-Security-Policy"] = "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox"
    return resp

# ------------------------------------------------------------------ admin
def _rows(status):
    out = []
    for a in q("SELECT a.*, u.full_name, u.email FROM affiliates a JOIN users u ON u.id=a.user_id WHERE a.status=? ORDER BY a.created_at DESC, a.id DESC", (status,)):
        out.append(dict(a=a, s=A.summary(a["id"]), rate=A.rate_for(a)))
    return out

@bp.route("/staff/affiliates")
@perm_required("affiliates.manage")
def admin_list():
    tab = request.args.get("tab", "active"); tab = tab if tab in ("active", "removed", "requests") else "active"
    counts = dict(active=val("SELECT COUNT(*) FROM affiliates WHERE status='active'", default=0), removed=val("SELECT COUNT(*) FROM affiliates WHERE status='removed'", default=0),
                  requests=val("SELECT COUNT(*) FROM affiliate_payouts WHERE status='requested'", default=0))
    reqs = q("SELECT r.*, a.slug, u.full_name, u.email FROM affiliate_payouts r JOIN affiliates a ON a.id=r.affiliate_id JOIN users u ON u.id=a.user_id WHERE r.status='requested' ORDER BY r.requested_at") if tab == "requests" else []
    rows = _rows(tab) if tab in ("active", "removed") else []
    tot = dict(gross=sum(r["s"]["gross"] for r in rows), earned=sum(r["s"]["earned"] for r in rows), available=sum(r["s"]["available"] for r in rows), pending=sum(r["s"]["pending"] for r in rows), paid=sum(r["s"]["paid"] for r in rows))
    return render_template("staff/affiliates.html", tab=tab, rows=rows, reqs=reqs, counts=counts, tot=tot, pct=A.default_percent(), enabled=A.enabled(), on_plans=S.flag("affiliate.on_plans"), site=current_app.config["SITE_URL"], args=request.args)

@bp.route("/staff/affiliates/new", methods=["POST"])
@perm_required("affiliates.manage")
def admin_new():
    f = request.form
    try:
        aid, link = A.create(g.user, f.get("full_name"), f.get("email"), f.get("slug"), f.get("percent"))
        a = A.get(aid)
        msg = f"Affiliate added. Their link: {A.link_for(a['slug'])}."
        if link: msg += f" A new account was created. Send them this password-setup link (valid 7 days): {link}"
        flash(msg, "success"); return redirect(url_for("affiliates.admin_detail", aid=aid))
    except A.AffError as e:
        flash(str(e), "error"); return redirect(url_for("affiliates.admin_list"))

@bp.route("/staff/affiliates/default-percent", methods=["POST"])
@perm_required("affiliates.manage")
def admin_default_percent():
    try:
        p = A.parse_percent(request.form.get("percent"))
        if p is None: raise A.AffError("Enter a percentage from 0 to 100.")
        old = A.default_percent(); S.put("affiliate.percent", f"{p:g}")
        audit.log("affiliate.default_percent", "settings", "affiliate.percent", f"{old:g} -> {p:g}")
        flash(f"Default commission is now {p:g}%. It applies to future sales only; affiliates with their own personal rate keep it.", "success")
    except A.AffError as e: flash(str(e), "error")
    return redirect(url_for("affiliates.admin_list"))

@bp.route("/staff/affiliates/<int:aid>", methods=["GET", "POST"])
@perm_required("affiliates.manage")
def admin_detail(aid):
    a = A.get(aid) or abort(404)
    if request.method == "POST":
        f = request.form; act = f.get("action")
        try:
            if act == "update":
                if A.update(g.user, a, slug_text=f.get("slug", ""), percent_text=f.get("percent", ""), set_percent=True): flash("Saved. Changes to the rate apply to future sales only.", "success")
                else: flash("No changes.", "info")
            elif act == "remove":
                if not f.get("confirm"): raise A.AffError("Tick the confirmation box first.")
                A.remove(g.user, aid); flash("Affiliate removed. Their link stopped working and they earn nothing new. What they already earned can still be paid out.", "info")
            elif act == "restore": A.restore(g.user, aid); flash("Affiliate restored.", "success")
            elif act in ("pay", "reject"):
                rid = f.get("rid", type=int)
                if not f.get("confirm"): raise A.AffError("Tick the confirmation box first.")
                if act == "pay": A.mark_paid(g.user, rid, request.files.get("receipt"), f.get("reference", ""), f.get("note", "")); flash("Marked as paid. The affiliate has been notified and can see the receipt.", "success")
                else: A.reject_payout(g.user, rid, f.get("reason", "")); flash("Request declined. The money is back in the affiliate's available balance.", "info")
            else: abort(400)
        except A.AffError as e: flash(str(e), "error")
        return redirect(url_for("affiliates.admin_detail", aid=aid))
    u = q1("SELECT * FROM users WHERE id=?", (a["user_id"],))
    return render_template("staff/affiliate.html", a=a, u=u, s=A.summary(aid), rate=A.rate_for(a), default=A.default_percent(), link=A.link_for(a["slug"]), LABEL=LABEL, mask=A.mask_name,
        refs=q("""SELECT u.id, u.full_name, u.email, u.referred_at, COUNT(CASE WHEN e.kind='sale' THEN 1 END) AS n, COALESCE(SUM(e.amount_kobo),0) AS amt
                  FROM users u LEFT JOIN affiliate_earnings e ON e.buyer_id=u.id AND e.affiliate_id=? WHERE u.referred_by_affiliate=? GROUP BY u.id ORDER BY u.referred_at DESC LIMIT 100""", (aid, aid)),
        earns=q("SELECT e.*, t.item_title, t.reference, b.full_name AS buyer FROM affiliate_earnings e JOIN transactions t ON t.id=e.transaction_id JOIN users b ON b.id=e.buyer_id WHERE e.affiliate_id=? ORDER BY e.created_at DESC, e.id DESC LIMIT 50", (aid,)),
        reqs=q("SELECT * FROM affiliate_payouts WHERE affiliate_id=? ORDER BY (status='requested') DESC, requested_at DESC, id DESC", (aid,)),
        own=a["user_id"] == g.user["id"] and not g.user["is_owner"])

@bp.route("/staff/affiliates/export.csv")
@perm_required("affiliates.manage")
def admin_csv():
    safe = lambda v: "'" + v if isinstance(v, str) and v[:1] in "=+-@\t\r" else v
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["Affiliate", "Email", "Link name", "Status", "Rate %", "Clicks", "Sign-ups", "Buyers", "Purchases", "Students paid (NGN)", "Earned (NGN)", "Paid out (NGN)", "Waiting (NGN)", "Available (NGN)"])
    for st in ("active", "removed"):
        for r in _rows(st):
            a, s = r["a"], r["s"]
            w.writerow([safe(x) for x in [a["full_name"], a["email"], a["slug"], a["status"], r["rate"], s["clicks"], s["signups"], s["buyers"], s["sales"], s["gross"] / 100, s["earned"] / 100, s["paid"] / 100, s["pending"] / 100, s["available"] / 100]])
    audit.log("export.csv", "export", "affiliates.csv")
    return Response(buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=affiliates.csv"})
