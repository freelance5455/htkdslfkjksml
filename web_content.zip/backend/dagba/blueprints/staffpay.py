import csv, io, re
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, abort, Response
from ..db import q, q1, ex, val
from ..util import now, naira, parse_ts
from ..security import perm_required, has_perm
from ..services import payments as P, settings as S, audit, providers, content as C, uploads, theme as TH, icons as IC
from ..services.notify import notify

bp = Blueprint("staffpay", __name__, url_prefix="/staff")
STATUSES = ["pending_verification", "info_requested", "approved", "rejected", "awaiting_payment", "cancelled", "refunded", "failed"]
LABELS = {"pending_verification": "Pending verification", "info_requested": "Info requested", "approved": "Approved", "rejected": "Rejected",
          "awaiting_payment": "Awaiting payment", "cancelled": "Cancelled", "refunded": "Refunded", "failed": "Failed"}

def _filters():
    where, a = ["1=1"], []
    st = request.args.get("status", "")
    if st in STATUSES: where.append("t.status=?"); a.append(st)
    ty = request.args.get("type", "")
    if ty in ("course", "plan"): where.append("t.item_type=?"); a.append(ty)
    m = request.args.get("method", "")
    if m: where.append("t.method=?"); a.append(m)
    s = request.args.get("q", "").strip()
    if s: where.append("(t.reference LIKE ? OR u.full_name LIKE ? OR u.email LIKE ? OR t.item_title LIKE ?)"); a += [f"%{s}%"] * 4
    for k, op in (("from", ">="), ("to", "<=")):
        d = request.args.get(k, "")
        if d and parse_ts(d): where.append(f"substr(t.created_at,1,10){op}?"); a.append(d[:10])
    return " AND ".join(where), a

BASE = "FROM transactions t JOIN users u ON u.id=t.user_id WHERE "

@bp.route("/payments")
@perm_required("payments.manage")
def payments():
    w, a = _filters(); page = max(1, request.args.get("page", 1, type=int))
    rows = q(f"SELECT t.*, u.full_name, u.email {BASE}{w} ORDER BY (t.status='pending_verification') DESC, t.created_at DESC LIMIT 25 OFFSET ?", tuple(a) + ((page - 1) * 25,))
    counts = {r["status"]: r["n"] for r in q("SELECT status, COUNT(*) n FROM transactions GROUP BY status")}
    return render_template("staff/payments.html", rows=rows, total=val(f"SELECT COUNT(*) {BASE}{w}", a, 0), page=page, counts=counts, STATUSES=STATUSES, LABELS=LABELS, args=request.args)

@bp.route("/payments/export.csv")
@perm_required("payments.manage")
def payments_csv():
    w, a = _filters()
    rows = q(f"SELECT t.*, u.full_name, u.email {BASE}{w} ORDER BY t.created_at DESC", a)
    return _csv("payments.csv", ["Reference", "Student", "Email", "Item", "Type", "Division", "List price (NGN)", "Discount (NGN)", "Amount (NGN)", "Method", "Status", "Created", "Submitted", "Decided", "Reason"],
                [[r["reference"], r["full_name"], r["email"], r["item_title"], r["item_type"], r["division"], r["list_price_kobo"] / 100, r["discount_kobo"] / 100, r["amount_kobo"] / 100, r["method"], r["status"], r["created_at"], r["submitted_at"], r["decided_at"], r["decision_reason"]] for r in rows])

def _csv(name, head, rows):
    def safe(v):  # neutralise spreadsheet formula injection
        return "'" + v if isinstance(v, str) and v[:1] in "=+-@\t\r" else v
    buf = io.StringIO(); w = csv.writer(buf); w.writerow(head)
    for r in rows: w.writerow([safe(x) for x in r])
    audit.log("export.csv", "export", name)
    return Response(buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename={name}"})

@bp.route("/payments/<int:tid>", methods=["GET", "POST"])
@perm_required("payments.manage")
def payment(tid):
    t = q1("SELECT t.*, u.full_name, u.email, u.phone FROM transactions t JOIN users u ON u.id=t.user_id WHERE t.id=?", (tid,)) or abort(404)
    if request.method == "POST":
        act = request.form.get("action")
        try:
            if act in ("approve", "reject", "info"):
                if not request.form.get("confirm"): raise P.PayError("Please tick the confirmation box before submitting your decision.")
                if act == "approve" and not request.form.get("verified_funds"): raise P.PayError("Confirm that you have verified the funds in the academy's bank account.")
                P.decide(tid, g.user, act, request.form.get("text", ""), request.form.get("note", ""))
                flash({"approve": "Payment approved and access activated.", "reject": "Payment rejected.", "info": "Information requested from the student."}[act], "success")
            elif act == "note":
                n = request.form.get("note", "").strip()
                if n: ex("INSERT INTO payment_notes(transaction_id,author_id,note) VALUES (?,?,?)", (tid, g.user["id"], n[:2000])); audit.log("payment.note", "transaction", tid)
            elif act == "refund":
                if not request.form.get("confirm"): raise P.PayError("Please confirm the refund.")
                P.refund(tid, g.user, request.form.get("text", "")); flash("Marked as refunded; access revoked.", "info")
        except P.PayError as e: flash(str(e), "error")
        return redirect(url_for("staffpay.payment", tid=tid))
    return render_template("staff/payment.html", t=t, ev=q("SELECT * FROM payment_evidence WHERE transaction_id=? ORDER BY id DESC", (tid,)),
        notes=q("SELECT n.*, u.full_name FROM payment_notes n JOIN users u ON u.id=n.author_id WHERE transaction_id=? ORDER BY n.id", (tid,)),
        history=q("SELECT * FROM audit_logs WHERE entity='transaction' AND entity_id=? ORDER BY id", (str(tid),)),
        prior=q("SELECT * FROM transactions WHERE user_id=? AND id!=? ORDER BY created_at DESC LIMIT 10", (t["user_id"], tid)),
        decider=val("SELECT full_name FROM users WHERE id=?", (t["decided_by"],), None), LABELS=LABELS,
        own=t["user_id"] == g.user["id"])

# ---------------------------------------------------------------- reports
def _range():
    f, t = request.args.get("from", ""), request.args.get("to", "")
    where, a = ["1=1"], []
    if f and parse_ts(f): where.append("substr(created_at,1,10)>=?"); a.append(f[:10])
    if t and parse_ts(t): where.append("substr(created_at,1,10)<=?"); a.append(t[:10])
    return " AND ".join(where), a

def _report():
    w, a = _range()
    # Confirmed revenue = approved only. Pending submissions are reported separately and never summed into revenue.
    return dict(
        confirmed=q1(f"SELECT COALESCE(SUM(amount_kobo),0) amt, COUNT(*) n FROM transactions WHERE status='approved' AND {w}", a),
        pending=q1(f"SELECT COALESCE(SUM(amount_kobo),0) amt, COUNT(*) n FROM transactions WHERE status='pending_verification' AND {w}", a),
        info=val(f"SELECT COUNT(*) FROM transactions WHERE status='info_requested' AND {w}", a, 0),
        rejected=val(f"SELECT COUNT(*) FROM transactions WHERE status='rejected' AND {w}", a, 0),
        refunded=q1(f"SELECT COALESCE(SUM(amount_kobo),0) amt, COUNT(*) n FROM transactions WHERE status='refunded' AND {w}", a),
        by_course=q(f"SELECT item_title, COUNT(*) n, SUM(amount_kobo) amt FROM transactions WHERE status='approved' AND item_type IN ('course','faith','faith_topic') AND {w} GROUP BY item_type, COALESCE(course_id, faith_series_id, faith_topic_id) ORDER BY amt DESC", a),
        by_division=q(f"SELECT division, COUNT(*) n, SUM(amount_kobo) amt FROM transactions WHERE status='approved' AND item_type='plan' AND {w} GROUP BY division", a),
        by_group=q(f"""SELECT CASE WHEN c.division='academic' THEN CASE COALESCE(c.academic_level,'basic') WHEN 'advanced' THEN 'Academic: Advanced' ELSE 'Academic: Basic' END
                                   WHEN c.division='income' THEN 'Income Skills' ELSE 'Professional Development' END AS grp, COUNT(*) n, SUM(t.amount_kobo) amt
                       FROM transactions t JOIN courses c ON c.id=t.course_id WHERE t.status='approved' AND t.item_type='course' AND {w.replace('created_at', 't.created_at')} GROUP BY grp ORDER BY amt DESC""", a),
        by_plan=q(f"SELECT item_title, COUNT(*) n, SUM(amount_kobo) amt FROM transactions WHERE status='approved' AND item_type='plan' AND {w} GROUP BY plan_id ORDER BY amt DESC", a),
        by_method=q(f"SELECT method, COUNT(*) n, SUM(amount_kobo) amt FROM transactions WHERE status='approved' AND {w} GROUP BY method", a),
        awaiting=q(f"SELECT t.id, t.reference, t.item_title, t.amount_kobo, t.submitted_at, u.full_name FROM transactions t JOIN users u ON u.id=t.user_id WHERE t.status='pending_verification' AND {w.replace('created_at','t.created_at')} ORDER BY t.submitted_at", a))

@bp.route("/reports")
@perm_required("reports.view")
def reports(): return render_template("staff/reports.html", r=_report(), args=request.args)

@bp.route("/reports/export.csv")
@perm_required("reports.view")
def reports_csv():
    r = _report(); rows = [["Confirmed revenue (approved only)", "", r["confirmed"]["amt"] / 100, r["confirmed"]["n"]], ["Pending verification (NOT revenue)", "", r["pending"]["amt"] / 100, r["pending"]["n"]]]
    rows += [["Revenue by course", x["item_title"], x["amt"] / 100, x["n"]] for x in r["by_course"]]
    rows += [["Revenue by course division", x["grp"], x["amt"] / 100, x["n"]] for x in r["by_group"]]
    rows += [["Revenue by subscription category", x["division"], x["amt"] / 100, x["n"]] for x in r["by_division"]]
    rows += [["Revenue by payment method", x["method"], x["amt"] / 100, x["n"]] for x in r["by_method"]]
    return _csv("report.csv", ["Section", "Item", "Amount (NGN)", "Count"], rows)

# ---------------------------------------------------------------- settings engine
def T(k, l, t="text", h=""): return dict(k=k, l=l, t=t, h=h)
GROUPS = {
 "bank": dict(title="Bank transfer settings", perm="bank.manage", intro="These details are shown to students on the payment page immediately after you save. Double-check the account number.",
    fields=[T("bank.enabled", "Enable manual bank transfer", "check"), T("bank.name", "Bank name"), T("bank.account_name", "Account name"), T("bank.account_number", "Account number", h="10-digit NUBAN account number"),
            T("bank.instructions", "Payment instructions", "textarea"), T("bank.reference_instructions", "Transfer reference instructions", "textarea"), T("bank.support_contact", "Payment support contact (phone / WhatsApp / email)"),
            T("bank.receipt_required", "Receipt upload is mandatory", "check"), T("bank.file_types", "Accepted file types", h="Comma separated, from: jpg, png, pdf"), T("bank.max_mb", "Maximum file size (MB)", h="1 to 20"),
            T("bank.allow_resubmit", "Allow resubmission after rejection", "check")]),
 "methods": dict(title="Payment methods", perm="bank.manage", gateways=True, intro="Manual bank transfer works with no external account. Online gateways are offered to students only when enabled here AND their secret keys are configured. Keys are never shown to browsers or students; you can alternatively set them as server environment variables.",
    fields=[T("bank.enabled", "Manual bank transfer: enabled", "check"),
            T("pay.paystack.enabled", "Paystack: enabled", "check"), T("pay.paystack.public_key", "Paystack public key"), T("pay.paystack.secret_key", "Paystack secret key", "secret", "Webhook URL to register in Paystack: {site}/webhooks/paystack"),
            T("pay.flutterwave.enabled", "Flutterwave: enabled", "check"), T("pay.flutterwave.public_key", "Flutterwave public key"), T("pay.flutterwave.secret_key", "Flutterwave secret key", "secret"),
            T("pay.flutterwave.webhook_hash", "Flutterwave webhook secret hash", "secret", "Webhook URL: {site}/webhooks/flutterwave (set the same secret hash in Flutterwave)")]),
 "payouts": dict(title="Tutor payout settings", perm="payouts.manage", intro="Tutors earn a percentage of what each student actually pays (after any discount) for an individual course purchase: a LOWER share on sales the academy generates (website, organic marketing, advertising) and a HIGHER share (default 97%) on sales that come through the tutor's own referral link. Subscriptions are not split. A change applies to FUTURE sales only: every sale remembers the percentage that applied when it was approved.",
    fields=[T("payout.instructor_percent", "Tutor share (%)", "text", "Default 40: the tutor keeps 40% and the school 60%. Applies to every division unless you set one below."), T("payout.instructor_percent_academic", "Academic courses: tutor share (%)", "text", "Leave blank to use the default above."), T("payout.instructor_percent_income", "Income Skills courses: tutor share (%)", "text", "Leave blank to use the default above."), T("payout.instructor_percent_professional", "Professional Development courses: tutor share (%)", "text", "Leave blank to keep the Academic rate (Professional Development used to be part of Academic)."), T("payout.instructor_percent_faith", "Faith & Spiritual Growth courses: tutor share (%)", "text", "Leave blank to use the default above. 0 = Faith teachers serve without pay."), T("payout.tutor_referral_percent", "Tutor-generated sales: tutor share (%)", "text", "Sales that came through the tutor's OWN referral link. Default 97. Can be overridden per tutor or per course on the Tutors page."), T("payout.max_percent", "Highest tutor share allowed (%)", "text", "Default 97. No override or default can exceed this. The tutor-generated rate above is also kept at or below it."), T("tutor.attribution_days", "Referral window (days)", "text", "How long a tutor's link keeps credit after someone follows it. Default 30; the browser remembers it across visits."), T("tutor.referrals_on", "Tutor referral links are on", "check"), T("tutor.applications_open", "Accept new tutor applications", "check"), T("payout.hold_days", "Holding period before earnings can be withdrawn (days)", "text", "0 = available immediately. A few days protects against refunds; earnings still holding show as Pending to the tutor."), T("payout.min_naira", "Minimum withdrawal (NGN)", "text", "0 = no minimum."), T("payout.enabled", "Allow tutors to request withdrawals", "check"), T("payout.instructions", "Message shown to tutors on their Earnings page", "textarea")]),
 "affiliates": dict(title="Affiliate programme settings", perm="affiliates.manage", intro="Affiliates earn this percentage of what each referred student actually pays (after any discount). A change applies to FUTURE sales only: every sale remembers the percentage that applied when it was approved. You can also give one affiliate their own personal rate on their page.",
    fields=[T("affiliate.enabled", "Affiliate programme is on (links track visitors and commissions are earned)", "check"), T("affiliate.percent", "Default commission (%)", "text", "0 to 100. Applies to every affiliate who has no personal rate."), T("affiliate.on_plans", "Also pay commission on subscription plans (not only individual courses)", "check"),
            T("affiliate.min_naira", "Minimum withdrawal (NGN)", "text", "0 = no minimum."), T("affiliate.payout_enabled", "Allow affiliates to request withdrawals", "check"), T("affiliate.instructions", "Message shown on the affiliate page", "textarea")]),
 "site": dict(title="Site & contact settings", perm="settings.manage", intro="", fields=[T("site.name", "Academy name"), T("site.tagline", "Tagline"), T("site.philosophy", "Core philosophy"), T("site.mission", "Mission", "textarea"),
            T("contact.email", "Contact email"), T("contact.phone", "Contact phone"), T("contact.whatsapp", "WhatsApp number (digits, with country code)"), T("contact.address", "Address / location"),
            T("video.max_mb", "Maximum lesson video upload size (MB)", h="10 to 2000. Also set the same or higher limit on your web server/proxy (client_max_body_size)."), T("social.facebook", "Facebook URL"), T("social.instagram", "Instagram URL"), T("social.youtube", "YouTube URL"), T("social.x", "X (Twitter) URL")]),
 "home": dict(title="Homepage content", perm="settings.manage", intro="The big banner at the top of the homepage is managed under Appearance > Homepage hero (slides, pictures, buttons, order). The hero text below is only used if every slide is hidden. Which Basic and Advanced subjects appear is set on each subject (tick Show on the homepage); Income Skills and Professional Development show their published courses, featured ones first. Nuggets, articles, testimonials and FAQs are managed in their own sections.",
    fields=[T("home.hero_title", "Hero headline"), T("home.hero_text", "Hero text", "textarea"), T("home.cta_primary", "Primary button text"), T("home.cta_secondary", "Secondary button text"), T("home.show_testimonials", "Show testimonials section", "check"),
            T("home.show_marquee", "Show subject ticker", "check"), T("home.show_numbers", "Show numbers band (only appears when courses exist)", "check"), T("home.show_what", "Show intro section", "check"), T("home.show_featured", "Show Basic subjects section", "check"), T("home.show_advanced", "Show Advanced Courses section (Advanced subjects; only appears when subjects have published courses)", "check"), T("home.show_income", "Show Income Skills section (individual courses)", "check"), T("home.show_professional", "Show Professional Development section (individual courses; only appears once a course is published)", "check"),
            T("home.show_steps", "Show How it works", "check"), T("home.show_why", "Show benefits", "check"), T("home.show_plans", "Show subscription plans", "check"), T("home.show_nuggets", "Show nuggets", "check"),
            T("home.show_articles", "Show latest articles", "check"), T("home.show_faq", "Show FAQs", "check"), T("home.show_newsletter", "Show newsletter box", "check"), T("home.show_faith", "Show Faith & Spiritual Growth section (only appears once lessons are published)", "check")]),
 "faith": dict(title="Faith & Spiritual Growth settings", perm="faith.manage", intro="Topics, series and lessons are managed from the Faith menu items. Headings and wording are under Website text & menus > Faith & Spiritual Growth text.",
    fields=[T("faith.audio_max_mb", "Maximum audio upload size (MB)", h="5 to 1000. Video uploads use the limit in Site settings. Also set the same or higher limit on your web server/proxy (client_max_body_size).")]),
 "brand": dict(title="Branding", perm="settings.manage", intro="Your logo and browser-tab icon. Colours, fonts and layout are on the Theme page (Admin > Theme & colours).",
    fields=[T("brand.logo", "Logo (square image works best)", "image", "JPG/PNG/WebP up to 15 MB. Used in the header and on certificates."), T("brand.favicon", "Browser tab icon (favicon)", "image", "A small square image.")]),
 "seo": dict(title="SEO settings", perm="settings.manage", intro="", fields=[T("seo.description", "Default meta description", "textarea")]),
 "cert": dict(title="Certificate settings", perm="certificates.manage", intro="Certificates are available when a student has completed all lessons. Optionally also require passing all quizzes.",
    fields=[T("cert.min_quiz_pass", "Require passing every course quiz", "check"), T("cert.signatory", "Signatory line on certificate"), T("cert.title_text", "Certificate heading"), T("cert.line1", "Line above the student's name"), T("cert.line2", "Line above the course title"), T("cert.completed", "Completion date label")]),
}

for _gid, _title, _intro, _fields in C.GROUPS:
    GROUPS["c_" + _gid] = dict(title=_title, perm="settings.manage", intro=_intro, content=True,
                               fields=[T("c." + f["key"], f["label"], "textarea" if f["kind"] in ("textarea", "list") else "text", f["help"]) for f in _fields])

def _validate_setting(k, v):
    e = C.validate(k, v)
    if e: return e
    if k == "bank.account_number" and v and not re.fullmatch(r"\d{10}", v): return "Account number must be exactly 10 digits."
    if k == "bank.max_mb" and not (v.replace(".", "", 1).isdigit() and 1 <= float(v) <= 20): return "Maximum file size must be between 1 and 20 MB."
    if k == "bank.file_types":
        t = [x.strip().lower() for x in v.split(",") if x.strip()]
        if not t or any(x not in ("jpg", "jpeg", "png", "pdf") for x in t): return "Accepted file types must be a list from: jpg, png, pdf."
    if k.startswith("brand.") and not re.fullmatch(r"#[0-9a-fA-F]{6}", v): return "Colours must be hex codes like #7236E6."
    if k == "payout.instructor_percent" or (k.startswith("payout.instructor_percent_") and (v or "").strip()):
        try:
            if not 0 <= float(v) <= 100: raise ValueError
        except ValueError: return "Tutor share must be a number from 0 to 100."
    if k in ("payout.tutor_referral_percent", "payout.max_percent", "payout.hold_days", "tutor.attribution_days") and not (v or "").strip(): return None      # blank = use the built-in default
    if k in ("payout.tutor_referral_percent", "payout.max_percent"):
        try:
            if not 0 <= float(v) <= 100: raise ValueError
        except ValueError: return "Percentages must be numbers from 0 to 100."
    if k == "payout.hold_days" and not (v.isdigit() and 0 <= int(v) <= 90): return "Holding period must be a whole number of days from 0 to 90."
    if k == "tutor.attribution_days" and not (v.isdigit() and 1 <= int(v) <= 365): return "Referral window must be a whole number of days from 1 to 365."
    if k == "affiliate.percent":
        try:
            if not 0 <= float(v) <= 100: raise ValueError
        except ValueError: return "Default commission must be a number from 0 to 100."
    if k == "affiliate.min_naira":
        try:
            if float(v or 0) < 0: raise ValueError
        except ValueError: return "Minimum withdrawal must be a positive amount (or 0)."
    if k == "payout.min_naira":
        try:
            if float(v or 0) < 0: raise ValueError
        except ValueError: return "Minimum withdrawal must be a positive amount (or 0)."
    if k == "faith.audio_max_mb" and not (v.isdigit() and 5 <= int(v) <= 1000): return "Audio upload limit must be between 5 and 1000 MB."
    if k == "video.max_mb" and not (v.isdigit() and 10 <= int(v) <= 2000): return "Video upload limit must be between 10 and 2000 MB."
    if k == "contact.whatsapp" and v and not re.fullmatch(r"\d{8,15}", v): return "WhatsApp number must be digits only, with country code."
    return None

@bp.route("/settings/<group>", methods=["GET", "POST"])
def settings(group):
    from ..security import login_required
    if not g.user: return redirect(url_for("auth.login"))
    gr = GROUPS.get(group) or abort(404)
    if not has_perm(gr["perm"]): abort(403)
    if request.method == "POST":
        errs, changes, updates = [], [], {}
        for f in gr["fields"]:
            k = f["k"]
            if f["t"] == "image":
                fs = request.files.get(k)
                if request.form.get("reset_" + k): changes.append(f"{k}: reset to default"); updates[k] = ""
                elif fs and fs.filename:
                    try: updates[k] = uploads.save_public_image(fs); changes.append(f"{k}: new image uploaded")
                    except uploads.UploadError as e: errs.append(f"{f['l']}: {e}")
                continue
            if f["t"] == "check": new = "1" if request.form.get(k) else "0"
            else:
                new = request.form.get(k, "").strip()
                if f["t"] == "secret" and not new: continue  # blank = keep existing
            e = _validate_setting(k, new)
            if e: errs.append(e); continue
            old = S.get(k, "")
            if f["t"] == "secret": changes.append(f"{k}: updated"); updates[k] = new
            elif old != new: changes.append(f"{k}: {old!r} -> {new!r}"); updates[k] = new
        if errs:
            for e in errs: flash(e, "error")
        else:
            for k, v in updates.items(): S.put(k, v)
            if changes: audit.log(f"settings.{group}", "settings", group, "; ".join(changes)[:1500])
            flash("Settings saved." if changes else "No changes.", "success"); return redirect(url_for("staffpay.settings", group=group))
    gw = []
    if gr.get("gateways"):
        for name, cls in providers.PROVIDERS.items():
            p = cls(); on = S.flag(f"pay.{name}.enabled")
            gw.append(dict(name=name, label=p.label, state="Active: offered to students" if (on and p.configured()) else ("Enabled but missing credentials: NOT offered" if on else ("Credentials saved, disabled" if p.configured() else "Awaiting credentials"))))
    cur = {f["k"]: ("" if f["t"] == "secret" else S.get(f["k"], "")) for f in gr["fields"]}
    if gr.get("content"): cur = {k: (v if v is not None else "") for k, v in cur.items()}
    return render_template("staff/settings.html", gr=gr, group=group, cur=cur, gw=gw,
                           secret_set={f["k"]: bool(S.get(f["k"], "")) for f in gr["fields"] if f["t"] == "secret"})


@bp.route("/content")
def content_index():
    if not g.user: return redirect(url_for("auth.login"))
    if not has_perm("settings.manage"): abort(403)
    groups = [(f"c_{gid}", title, intro, len(fs)) for gid, title, intro, fs in C.GROUPS]
    return render_template("staff/content_index.html", groups=groups)


# ------------------------------------------------------------------ homepage intro card icons
@bp.route("/intro-icons", methods=["GET", "POST"])
def intro_icons():
    """Choose the icon of every homepage Intro Card (searchable Lucide picker with live preview). Saved in the settings table, shown on the homepage immediately."""
    if not g.user: return redirect(url_for("auth.login"))
    if not has_perm("settings.manage"): abort(403)
    if request.method == "POST":
        if request.form.get("action") == "reset":
            IC.reset_intro_icons(); audit.log("intro.icons", "settings", "home.what_cards", "restored default icons"); flash("Default intro card icons restored.", "success")
        else:
            n = len(IC.intro_cards()); icons = [request.form.get(f"icon_{i}", "").strip() for i in range(n)]; titles = [request.form.get(f"title_{i}", "") for i in range(n)]
            err = IC.save_intro_icons(icons, titles)
            if err: flash(err, "error")
            else: audit.log("intro.icons", "settings", "home.what_cards", ", ".join(f"{c['title']}={i or 'default'}" for c, i in zip(IC.intro_cards(), icons))[:1500]); flash("Intro card icons saved. They are live on the homepage now.", "success")
        return redirect(url_for("staffpay.intro_icons"))
    return render_template("staff/intro_icons.html", cards=IC.intro_cards(), IC=IC)


# ------------------------------------------------------------------ whole-site theme
def _theme_page(vals=None, errors=None):
    v = vals or TH.current()
    return render_template("staff/theme.html", v=v, colours=TH.COLOURS, fonts=TH.FONTS, radii=TH.RADII, widths=TH.WIDTHS, heroes=TH.HEROES, sizes=TH.SIZES, presets=TH.PRESETS,
                           vars=TH.variables(v, only_changed=False), warns=TH.warnings(v), errors=errors or [])

@bp.route("/theme", methods=["GET", "POST"])
@perm_required("settings.manage")
def theme():
    if request.method == "POST":
        if request.form.get("action") == "reset":
            TH.reset(); audit.log("theme.reset", "settings", "theme", "all theme settings returned to the original look")
            flash("The original theme has been restored.", "success"); return redirect(url_for("staffpay.theme"))
        vals, errs = TH.from_form(request.form)
        if errs:
            for e in errs: flash(e, "error")
            return _theme_page(vals, errs)          # keep what they typed so nothing is lost; nothing was saved
        changed = TH.save(vals)
        audit.log("theme.saved", "settings", "theme", ", ".join(k.replace("theme.", "") for k in changed)[:300] or "no changes")
        flash("Theme saved. Every page now uses it." if changed else "No changes to save.", "success" if changed else "info")
        for w in TH.warnings(vals): flash("Readability warning: " + w, "error")
        return redirect(url_for("staffpay.theme"))
    return _theme_page()

@bp.route("/theme/preview", methods=["POST"])
@perm_required("settings.manage")
def theme_preview():
    """Computes the CSS variables for the unsaved form values so the live preview uses exactly the same maths as the real site. Saves nothing."""
    from flask import jsonify
    vals, errs = TH.from_form(request.form)
    return jsonify(vars=TH.variables(vals, only_changed=False), dark=TH.variables(TH.dark_values(vals), only_changed=False), hero=vals["theme.hero"], warnings=TH.warnings(vals), errors=errs)
