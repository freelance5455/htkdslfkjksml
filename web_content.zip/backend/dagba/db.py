import os, sqlite3
from flask import g, current_app

def connect(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    c = sqlite3.connect(path, timeout=15, isolation_level=None)  # autocommit; explicit BEGIN where needed
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA journal_mode=WAL")
    return c

def get_db():
    if "db" not in g:
        g.db = connect(current_app.config["DATABASE"])
    return g.db

def close_db(_=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def q(sql, args=()):
    return get_db().execute(sql, args).fetchall()

def q1(sql, args=()):
    return get_db().execute(sql, args).fetchone()

def ex(sql, args=()):
    return get_db().execute(sql, args).lastrowid

def val(sql, args=(), default=None):
    r = get_db().execute(sql, args).fetchone()
    return default if r is None or r[0] is None else r[0]

def migrate(path, migrations_dir):
    """Apply pending numbered SQL migrations. A lock file serialises concurrent starters (e.g. several gunicorn workers)."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    lock = open(path + ".migrate.lock", "a")
    try:
        try:
            import fcntl; fcntl.flock(lock, fcntl.LOCK_EX)
        except ImportError: pass                       # Windows dev machines: single process anyway
        return _migrate(path, migrations_dir)
    finally: lock.close()

def _migrate(path, migrations_dir):
    c = connect(path)
    c.execute("CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT DEFAULT (datetime('now')))")
    done = {r[0] for r in c.execute("SELECT name FROM schema_migrations")}
    applied = []
    for f in sorted(os.listdir(migrations_dir)):
        if f.endswith(".sql") and f not in done:
            with open(os.path.join(migrations_dir, f), encoding="utf-8") as fh: sql = fh.read()
            fk_off = sql.lstrip().startswith("-- @foreign_keys_off")     # table rebuilds: SQLite's documented procedure needs FKs off (cannot be switched inside a transaction)
            if not fk_off: c.executescript("BEGIN;\n" + sql + "\nCOMMIT;")
            else:
                before = len(c.execute("PRAGMA foreign_key_check").fetchall())
                c.execute("PRAGMA foreign_keys=OFF")
                try:
                    c.executescript("BEGIN;\n" + sql)
                    if len(c.execute("PRAGMA foreign_key_check").fetchall()) > before: raise RuntimeError(f"Migration {f} would leave broken foreign keys; nothing was changed")
                    c.execute("COMMIT")
                except Exception:
                    if c.in_transaction: c.execute("ROLLBACK")
                    raise
                finally: c.execute("PRAGMA foreign_keys=ON")
            c.execute("INSERT INTO schema_migrations(name) VALUES (?)", (f,))
            applied.append(f)
    c.close()
    return applied
