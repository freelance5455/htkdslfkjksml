(function(){
  var csrf=document.querySelector('meta[name=csrf]');csrf=csrf&&csrf.content;
  function post(path,fields){var d=new FormData();Object.keys(fields||{}).forEach(function(k){d.append(k,fields[k])});d.append('_csrf',csrf);
    return fetch(path,{method:'POST',body:d,credentials:'same-origin',headers:{'X-Requested-With':'fetch'}}).catch(function(){})}
  [].slice.call(document.querySelectorAll('[data-faith]')).forEach(function(m){
    var id=m.getAttribute('data-faith');if(!id)return;
    var auth=m.getAttribute('data-auth')==='1',start=parseInt(m.getAttribute('data-start')||'0',10),last=0;
    m.addEventListener('loadedmetadata',function(){if(start>5&&m.duration&&start<m.duration-5)m.currentTime=start});
    if(!auth||!csrf)return;
    function save(){var t=Math.floor(m.currentTime||0);if(t>0&&Math.abs(t-last)>=1){last=t;post('/faith/lesson/'+id+'/progress',{position:t})}}
    m.addEventListener('timeupdate',function(){var t=Math.floor(m.currentTime);if(Math.abs(t-last)>=10){last=t;post('/faith/lesson/'+id+'/progress',{position:t})}});
    m.addEventListener('pause',save);
    m.addEventListener('ended',function(){post('/faith/lesson/'+id+'/complete',{}).then(function(r){var s=document.getElementById('fstate');if(s)s.textContent='Lesson marked as complete.';if(r&&r.ok&&window.DDA)DDA.toast('Lesson complete. Your progress is saved.')})});
  });
})();
