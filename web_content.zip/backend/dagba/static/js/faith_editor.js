(function(){
'use strict';
var root=document.getElementById('feditor');if(!root)return;
var csrf=document.querySelector('meta[name=csrf]').content,MAX={video:+root.dataset.maxVideo,audio:+root.dataset.maxAudio};
var init=JSON.parse(document.getElementById('initial').textContent),D=init.item,SERIES=init.series;
var $=function(s,r){return(r||document).querySelector(s)},$$=function(s,r){return[].slice.call((r||document).querySelectorAll(s))};
var dirty=false,busy=0,files={video:null,audio:null,res:null},ups={video:null,audio:null},thumb=D.thumbnail||'';
function fmt(b){return b>=1048576?(b/1048576).toFixed(1)+' MB':Math.max(1,Math.round(b/1024))+' KB'}
function sleep(ms){return new Promise(function(r){setTimeout(r,ms)})}
function api(url,o){o=o||{};o.credentials='same-origin';o.headers=Object.assign({'X-CSRF-Token':csrf,'X-Requested-With':'fetch'},o.headers||{});
  return fetch(url,o).then(function(r){return r.json().catch(function(){return{ok:false,error:'Server error ('+r.status+')'}}).then(function(j){j._status=r.status;return j})})}
function postJSON(url,obj){return api(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(obj)})}
function show(list,kind){var b=$('#msgs');b.textContent='';(list||[]).forEach(function(t){var d=document.createElement('div');d.className='flash '+(kind||'error');d.textContent=t;b.appendChild(d)});if(list&&list.length)window.scrollTo({top:0,behavior:'smooth'})}
root.addEventListener('input',function(){dirty=true});root.addEventListener('change',function(){dirty=true});
window.addEventListener('beforeunload',function(e){if(dirty||busy){e.preventDefault();e.returnValue=''}});

// fields
$$('[data-f]').forEach(function(el){var v=D[el.dataset.f];if(v===undefined||v===null)v='';if(el.type==='checkbox')el.checked=!!v;else el.value=v});
if(D.video_file)files.video={file:D.video_file,name:D.video_name};if(D.audio_file)files.audio={file:D.audio_file,name:D.audio_name};if(D.resource_file)files.res={file:D.resource_file,name:D.resource_name};
var topic=$('#f_topic'),series=$('#f_series'),kind=$('#f_kind');
function fillSeries(){var cur=series.value||D.series_id||'';series.textContent='';var o=document.createElement('option');o.value='';o.textContent='(no series)';series.appendChild(o);
  SERIES.filter(function(s){return String(s.topic_id)===String(topic.value)}).forEach(function(s){var x=document.createElement('option');x.value=s.id;x.textContent=s.title;if(String(s.id)===String(cur))x.selected=true;series.appendChild(x)})}
topic.addEventListener('change',function(){D.series_id='';series.value='';fillSeries()});fillSeries();
var HELP={video:'Needs a video file or a YouTube/Vimeo link to publish.',audio:'Needs an audio file or link to publish.',reading:'Needs the written lesson (section 3) to publish.',study:'Needs a study material file or written guide to publish.'};
function kindSync(){$('#kindhelp').textContent=HELP[kind.value]||'';$('#bodylabel').textContent=kind.value==='reading'?'Reading text *':'Lesson notes'}kind.addEventListener('change',kindSync);kindSync();

// cover
var tp=$('#thumbprev'),tm=$('#thumbmsg');function thumbUi(){tp.hidden=!thumb;if(thumb)tp.src='/media/'+thumb;$('#thumbrm').hidden=!thumb}thumbUi();
$('#f_thumb').addEventListener('change',function(){var f=this.files[0];if(!f)return;var fd=new FormData();fd.append('file',f);tm.textContent='Uploading...';busy++;
  api('/staff/faith/cover',{method:'POST',body:fd}).then(function(j){busy--;if(j.ok){thumb=j.file;thumbUi();tm.textContent='Cover image ready.';dirty=true}else tm.textContent=j.error||'Upload failed.'})});
$('#thumbrm').addEventListener('click',function(){thumb='';thumbUi();dirty=true});

// resumable chunked upload for video and audio (4 MB pieces; survives flaky connections)
function slotEl(s){return $('.slot[data-slot='+s+']')}
function ui(s){var el=slotEl(s),st=$('.vstate',el),f=files[s],u=ups[s];st.hidden=!(f||u);if(!(f||u))return;
  $('.vname',el).textContent=f?'Uploaded: '+(f.name||f.file):(u?u.file.name:'');
  $('progress',el).hidden=!u||u.done;$('[data-act=cancel]',el).hidden=!(u&&!u.done&&!u.failed);$('[data-act=retry]',el).hidden=!(u&&u.failed);$('[data-act=remove]',el).hidden=!f||(u&&!u.done)}
function sendChunk(url,blob,onp){return new Promise(function(res,rej){var x=new XMLHttpRequest();x.open('POST',url);x.setRequestHeader('X-CSRF-Token',csrf);x.setRequestHeader('Content-Type','application/octet-stream');
  x.upload.onprogress=function(e){if(e.lengthComputable)onp(e.loaded)};x.onload=function(){var j={};try{j=JSON.parse(x.responseText)}catch(e){}j._status=x.status;res(j)};x.onerror=function(){rej(new Error('network'))};x.ontimeout=x.onerror;x.timeout=180000;x.send(blob)})}
async function run(s){var u=ups[s],el=slotEl(s),base='/staff/faith/upload/';u.failed=false;show([]);ui(s);var t0=Date.now(),b0=0;
  try{
    if(!u.id){var j=await postJSON(base+'init',{name:u.file.name,size:u.file.size,kind:s==='audio'?'audio':'video'});if(!j.ok)throw new Error(j.error||'Could not start upload');u.id=j.upload_id;u.chunk=j.chunk;u.idx=0;u.off=0}
    else{var st=await api(base+u.id+'/status');if(!st.ok)throw new Error('Upload session expired. Choose the file again.');u.idx=st.next_index;u.off=st.received}
    b0=u.off;
    while(u.off<u.file.size){
      if(u.cancel)throw new Error('cancelled');
      var blob=u.file.slice(u.off,u.off+u.chunk),tries=0,r;
      for(;;){
        try{r=await sendChunk(base+u.id+'/chunk?index='+u.idx,blob,function(l){var d=u.off+l;$('progress',el).value=Math.min(99,d*100/u.file.size);var sec=(Date.now()-t0)/1000||1;
          $('.vmeta',el).textContent=fmt(d)+' of '+fmt(u.file.size)+' ('+Math.round(d*100/u.file.size)+'%) at '+fmt((d-b0)/sec)+'/s'});break}
        catch(e){if(++tries>5)throw new Error('Connection lost. Your progress is kept: press Resume upload.');await sleep(1200*tries)}
      }
      if(r.ok){u.off=r.received;u.idx++}else if(r._status===409&&r.expected!==undefined){u.idx=r.expected;u.off=r.received}else throw new Error(r.error||'Upload failed');
    }
    var f=await postJSON(base+u.id+'/finish',{});if(!f.ok)throw new Error(f.error||'Could not finish upload');
    files[s]={file:f.file,name:f.name,size:f.size};u.done=true;$('.vmeta',el).textContent='Done: '+fmt(f.size);$('progress',el).value=100;busy--;ups[s]=null;ui(s);dirty=true;
  }catch(e){busy--;if(e.message==='cancelled'){ups[s]=null;$('.vmeta',el).textContent='';ui(s);return}u.failed=true;ui(s);$('.vmeta',el).textContent=e.message}}
function start(s,file){if(!file)return;var ok=s==='audio'?/\.(mp3|m4a|aac|ogg|oga|opus|wav)$/i:/\.(mp4|m4v|webm)$/i;
  if(!ok.test(file.name)){show([s==='audio'?'Audio must be an MP3, M4A, AAC, OGG, OPUS or WAV file.':'Video must be an MP4 or WebM file. Tip: export your video as MP4 (H.264).']);return}
  if(file.size>MAX[s]*1048576){show(['That file is '+fmt(file.size)+'. The limit is '+MAX[s]+' MB. Compress it, or raise the limit in the settings.']);return}
  show([]);files[s]=null;ups[s]={file:file};busy++;run(s)}
$$('[data-pick]').forEach(function(inp){inp.addEventListener('change',function(){var s=inp.dataset.pick,f=inp.files[0];
  if(s==='res'){if(!f)return;var fd=new FormData();fd.append('file',f);var el=slotEl('res');$('.rname',el).textContent='Uploading...';$('.rstate',el).hidden=false;busy++;
    api('/staff/faith/resource',{method:'POST',body:fd}).then(function(j){busy--;if(j.ok){files.res={file:j.file,name:j.name};resUi();dirty=true}else{files.res=null;resUi();show([j.error||'Upload failed'])}})}
  else start(s,f);inp.value=''})});
function resUi(){var el=slotEl('res'),r=files.res;$('.rstate',el).hidden=!r;if(r)$('.rname',el).textContent='Attached: '+(r.name||r.file)}resUi();ui('video');ui('audio');
root.addEventListener('click',function(e){var b=e.target.closest('[data-act]');if(!b)return;var s=b.closest('.slot').dataset.slot,act=b.dataset.act;
  if(act==='cancel')ups[s].cancel=true;else if(act==='retry'){busy++;run(s)}else if(act==='remove'){files[s]=null;ui(s);dirty=true}else if(act==='rremove'){files.res=null;resUi();dirty=true}});

// save
$('#fsave').addEventListener('click',function(){
  if(busy){show(['A file is still uploading. Wait for it to finish (or cancel it), then save.']);return}
  var p={id:D.id||'',thumbnail:thumb};$$('[data-f]').forEach(function(el){p[el.dataset.f]=el.type==='checkbox'?el.checked:el.value});
  var v=files.video,a=files.audio,r=files.res;p.video_file=v?v.file:'';p.video_name=v?v.name:'';p.audio_file=a?a.file:'';p.audio_name=a?a.name:'';p.resource_file=r?r.file:'';p.resource_name=r?r.name:'';
  var st=$('#savestate');st.textContent='Saving...';this.disabled=true;var btn=this;
  postJSON('/staff/faith/save',p).then(function(j){btn.disabled=false;
    if(j.ok){dirty=false;window.location.href=j.redirect}
    else{st.textContent='';show(j.errors&&j.errors.length?j.errors:[j.error||'Could not save.'])}})});
})();
