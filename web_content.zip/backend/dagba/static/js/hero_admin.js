/* Hero slide form: instant preview of the chosen picture and live character counters. Optional; the form works without it. */
(function(){
  var f=document.querySelector('[data-hero-file]'),pv=document.getElementById('hpv');
  if(f&&pv)f.addEventListener('change',function(){var file=f.files&&f.files[0];if(!file||!/^image\//.test(file.type)||!window.FileReader)return;
    var r=new FileReader();r.onload=function(){pv.src=r.result;pv.alt='New picture (not saved yet)'};r.readAsDataURL(file)});
  [].forEach.call(document.querySelectorAll('[data-count]'),function(el){
    var h=el.parentNode.querySelector('.help'),box=document.createElement('span');box.className='small muted hcount';box.setAttribute('aria-hidden','true');
    function u(){box.textContent=' '+el.value.length+' / '+el.maxLength}el.addEventListener('input',u);u();if(h)h.appendChild(box)});
})();
