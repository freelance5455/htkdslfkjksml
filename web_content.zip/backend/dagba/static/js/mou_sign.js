/* Tutor application: signature hints and a loading state. The server re-checks everything; this only helps the applicant. */
(function(){
'use strict';
var sig=document.getElementById('mou_sig'),agree=document.getElementById('mou_agree');
var form=sig&&sig.form||document.querySelector('form.f[action$="/tutor/apply/save"]');
var state=document.getElementById('mou_state');
function norm(s){try{s=s.normalize('NFKC')}catch(e){}return s.replace(/\s+/g,' ').trim().toLowerCase()}
function say(t,ok){if(!state)return;state.textContent=t;state.className='small '+(ok?'mou-ok':'mou-bad')}
function hint(){
  if(!sig||sig.disabled)return;
  var v=norm(sig.value),want=norm(sig.getAttribute('data-registered')||'');
  if(!v)return say('',true);
  if(v===want)say('Your signature matches the name on your account.',true);
  else say('This does not match the name on your account yet.',false);
}
if(sig){sig.addEventListener('input',hint);hint()}
if(form){
  var busy=false;
  form.addEventListener('submit',function(e){
    var b=e.submitter,action=b&&b.name==='action'?b.value:'';
    if(busy){e.preventDefault();return}
    if(action==='submit'&&sig&&!sig.disabled){
      var miss=[];
      if(agree&&!agree.checked)miss.push('tick the agreement box');
      if(!norm(sig.value))miss.push('type your full legal name as your signature');
      if(miss.length){e.preventDefault();say('Before you submit, please '+miss.join(' and ')+'.',false);(agree&&!agree.checked?agree:sig).focus();return}
    }
    busy=true;
    setTimeout(function(){[].forEach.call(form.querySelectorAll('button[name=action]'),function(x){x.disabled=true;if(x===b)x.textContent=action==='submit'?'Submitting...':'Saving...'})},0);
  });
  window.addEventListener('pageshow',function(ev){if(ev.persisted){busy=false;[].forEach.call(form.querySelectorAll('button[name=action]'),function(x){x.disabled=false})}});
}
})();
