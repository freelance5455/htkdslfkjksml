/* Theme editor: live preview (uses the server's own colour maths) and one-click presets. No inline code, so it works under the strict CSP. */
(function(){
  var f=document.getElementById('themeform'),tp=document.getElementById('tp');if(!f||!tp)return;
  var warn=document.getElementById('twarn'),timer=null,seq=0,pmode='light',last=null;
  function apply(d){
    last=d;var vs=pmode==='dark'?d.dark:d.vars;
    Object.keys(vs).forEach(function(k){tp.style.setProperty(k,vs[k])});
    tp.setAttribute('data-hero',d.hero);
    if(warn){warn.textContent='';(d.warnings||[]).forEach(function(w){var p=document.createElement('p');p.className='small bad-t';p.textContent=w;warn.appendChild(p)})}
    f.querySelectorAll('output[data-for]').forEach(function(o){var i=f.elements[o.getAttribute('data-for')];if(i)o.textContent=i.value})
  }
  function refresh(){
    var n=++seq,fd=new FormData(f);
    fetch(f.getAttribute('data-preview'),{method:'POST',body:fd,credentials:'same-origin',headers:{'X-Requested-With':'fetch'}})
      .then(function(r){return r.json()}).then(function(d){if(n===seq)apply(d)}).catch(function(){});
  }
  function later(){clearTimeout(timer);timer=setTimeout(refresh,120)}
  f.addEventListener('input',later);f.addEventListener('change',later);
  document.querySelectorAll('[data-preset]').forEach(function(b){b.addEventListener('click',function(){
    var p=JSON.parse(b.getAttribute('data-preset'));
    Object.keys(p).forEach(function(k){var el=f.elements[k];if(!el)return;if(el.type==='checkbox')el.checked=p[k]==='1';else el.value=p[k]});
    refresh()})});
  document.querySelectorAll('[data-pmode]').forEach(function(b){b.addEventListener('click',function(){
    pmode=b.getAttribute('data-pmode');
    document.querySelectorAll('[data-pmode]').forEach(function(o){var on=o===b;o.setAttribute('aria-pressed',on?'true':'false');o.className='btn sm'+(on?'':' sec')});
    if(last)apply(last)})});
  refresh();
})();
