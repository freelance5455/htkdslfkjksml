/* Homepage course carousels. Vanilla JS, no dependencies. Every [data-fcar] block is its own independent carousel
   (own position, timer, hover/focus state). The markup is already a swipeable scroll-snap row; this adds seamless
   looping (cloned slides), arrows, dots, auto-slide and keyboard use. */
(function(){
  [].forEach.call(document.querySelectorAll('[data-fcar]'),init);
  function init(root,k){
  var track=root.querySelector('.ftrack'),ctrl=root.querySelector('.tctrl'),dotsBox=root.querySelector('.tdots');
  var real=[].slice.call(track.children),n=real.length;if(!n)return;
  var rm=document.documentElement.classList.contains('rm')||(window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  var DELAY=(parseInt(root.getAttribute('data-delay'),10)||5500)+(k||0)*(root.getAttribute('data-delay')?0:900),looping=false,base=0,step=0,tgt=null,timer=0,touching=false,hover=false,focus=false,inView=true,dots=[],settleT=0,raf=0;

  function perView(){var w=real[0].getBoundingClientRect().width;return w?Math.max(1,Math.round(track.clientWidth/w)):1}
  function clones(){return [].slice.call(track.querySelectorAll('.fclone'))}
  function clear(){clones().forEach(function(c){c.parentNode.removeChild(c)})}
  function mk(el){var c=el.cloneNode(true);c.classList.add('fclone');c.setAttribute('aria-hidden','true');c.setAttribute('inert','');
    [].forEach.call(c.querySelectorAll('a,button'),function(a){a.setAttribute('tabindex','-1')});
    [].forEach.call(c.querySelectorAll('img'),function(i){i.classList.add('loaded')});return c}
  function build(){clear();
    real.forEach(function(el){track.insertBefore(mk(el),real[0])});            // n clones before (same order as the real slides)
    real.forEach(function(el){track.appendChild(mk(el))});                      // n clones after
  }
  function measure(){base=real[0].offsetLeft;step=n>1?real[1].offsetLeft-real[0].offsetLeft:0}
  function pos(i){return base+i*step}
  function cur(){return step?Math.round((track.scrollLeft-base)/step):0}
  function mod(i){return((i%n)+n)%n}

  function paint(){raf=0;var a=mod(cur());dots.forEach(function(d,i){var on=i===a;d.classList.toggle('on',on);if(on)d.setAttribute('aria-current','true');else d.removeAttribute('aria-current')})}
  function goTo(i,smooth){measure();tgt=i;track.scrollTo({left:pos(i),behavior:smooth&&!rm?'smooth':'auto'});if(!smooth||rm)settle()}
  function settle(){                                                          // after a slide lands: hop from a clone to its identical real twin (invisible)
    tgt=null;if(!looping||touching||!step){paint();return}
    var c=cur();if(c<0)track.scrollLeft+=n*step;else if(c>=n)track.scrollLeft-=n*step;paint()
  }
  function onScroll(){if(!raf)raf=requestAnimationFrame(paint);clearTimeout(settleT);settleT=setTimeout(settle,looping?110:0)}
  function move(d){if(!looping)return;var c=tgt!=null?tgt:cur();goTo(c+d,true)}
  function user(d){move(d);restart()}

  function dotsBuild(){dotsBox.innerHTML='';dots=[];for(var i=0;i<n;i++){(function(i){var b=document.createElement('button');b.type='button';b.setAttribute('aria-label','Go to slide '+(i+1)+' of '+n);
    b.addEventListener('click',function(){var c=tgt!=null?tgt:cur();goTo(c+(i-mod(c)),true);restart()});dotsBox.appendChild(b);dots.push(b)})(i)}}

  /* auto-slide: paused on hover (mouse), focus, touch, hidden tab or when scrolled out of view */
  function tick(){if(!hover&&!focus&&!touching&&inView&&!document.hidden)move(1)}
  function start(){stop();if(looping&&!rm)timer=setInterval(tick,DELAY)}
  function stop(){if(timer){clearInterval(timer);timer=0}}
  function restart(){start()}

  function layout(){
    var want=n>perView();
    if(want&&!looping){build();looping=true}else if(!want&&looping){clear();looping=false}
    track.classList.toggle('few',!looping);ctrl.hidden=!looping;
    measure();if(looping)goTo(mod(cur()>=-n&&cur()<2*n?cur():0),false);else track.scrollLeft=0;
    paint();start();
  }

  if(root.classList.contains('introcar')){                                       // one-time entrance: cards rise in, staggered, when the section scrolls into view
    if(rm||!('IntersectionObserver' in window))root.classList.add('seen');
    else{var eo=new IntersectionObserver(function(es){if(es[0].isIntersecting){root.classList.add('seen');eo.disconnect()}},{threshold:.15});eo.observe(root)}
  }
  dotsBuild();
  [].forEach.call(root.querySelectorAll('.tbtn'),function(b){b.addEventListener('click',function(){user(+b.getAttribute('data-dir'))})});
  track.addEventListener('scroll',onScroll,{passive:true});
  track.addEventListener('keydown',function(e){if(e.key==='ArrowRight'){e.preventDefault();user(1)}else if(e.key==='ArrowLeft'){e.preventDefault();user(-1)}});
  track.addEventListener('touchstart',function(){touching=true;tgt=null},{passive:true});
  function release(){touching=false;clearTimeout(settleT);settleT=setTimeout(settle,looping?140:0);restart()}
  track.addEventListener('touchend',release,{passive:true});track.addEventListener('touchcancel',release,{passive:true});
  if(window.matchMedia&&window.matchMedia('(hover:hover)').matches){
    root.addEventListener('mouseenter',function(){hover=true});root.addEventListener('mouseleave',function(){hover=false;restart()});
  }
  root.addEventListener('focusin',function(e){var t=e.target;focus=!!(t.matches&&t.matches(':focus-visible'))});      // keyboard focus pauses; a mouse/touch click does not
  root.addEventListener('focusout',function(e){if(!root.contains(e.relatedTarget)){focus=false;restart()}});
  if('IntersectionObserver' in window)new IntersectionObserver(function(es){inView=es[0].isIntersecting}).observe(root);
  document.addEventListener('visibilitychange',function(){if(!document.hidden)restart()});
  var rt;window.addEventListener('resize',function(){clearTimeout(rt);rt=setTimeout(layout,150)});
  window.addEventListener('load',function(){measure();if(looping)goTo(mod(cur()),false)});     // image sizes can shift positions slightly
  layout();
  }
})();
