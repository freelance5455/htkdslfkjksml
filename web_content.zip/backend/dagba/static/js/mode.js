/* Light / dark switch. Runs in <head> (before the page paints) so there is no flash of the wrong colours.
   The choice is remembered on this device. If the visitor never chose, the admin's "first visit" setting decides (light, or follow the device). */
(function(){
  var K='dda-mode',d=document.documentElement,m=document.querySelector('meta[name=dda-mode-default]'),def=m?m.getAttribute('content'):'light',
      mq=window.matchMedia?window.matchMedia('(prefers-color-scheme: dark)'):null;
  function stored(){try{var v=localStorage.getItem(K);return v==='dark'||v==='light'?v:null}catch(e){return null}}
  function current(){if(def==='off')return'light';return stored()||(def==='auto'&&mq&&mq.matches?'dark':'light')}
  function apply(x){
    d.setAttribute('data-mode',x);
    var b=document.getElementById('modebtn');if(!b)return;var dk=x==='dark';
    b.setAttribute('aria-pressed',dk?'true':'false');b.setAttribute('aria-label',dk?'Switch to light mode':'Switch to dark mode');b.setAttribute('title',dk?'Switch to light mode':'Switch to dark mode');
  }
  apply(current());
  if(def!=='off')d.classList.add('mode-on');
  document.addEventListener('DOMContentLoaded',function(){
    apply(current());
    var b=document.getElementById('modebtn');if(!b)return;
    b.addEventListener('click',function(){var n=d.getAttribute('data-mode')==='dark'?'light':'dark';try{localStorage.setItem(K,n)}catch(e){}apply(n)});
  });
  if(mq&&mq.addEventListener)mq.addEventListener('change',function(){if(!stored())apply(current())});
  window.addEventListener('storage',function(e){if(e.key===K)apply(current())});      /* keep other open tabs in step */
})();
