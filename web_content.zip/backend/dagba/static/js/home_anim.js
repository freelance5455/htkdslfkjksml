/* Homepage motion, layer 2. Pure enhancement: everything here is skipped for "reduce motion" and the page is complete without it. */
(function(){
  var d=document.documentElement;
  if(d.classList.contains('rm')||!document.querySelector('.herogrid,.hx'))return;
  d.classList.add('home-anim');
  var fine=window.matchMedia&&window.matchMedia('(hover:hover) and (pointer:fine)').matches;
  var hero=document.querySelector('.hero');

  // 1. top scroll-progress bar + back-to-top button with a progress ring
  var bar=document.createElement('div');bar.className='homebar';bar.setAttribute('aria-hidden','true');document.body.appendChild(bar);
  var NS='http://www.w3.org/2000/svg',C=2*Math.PI*18;
  var top=document.createElement('button');top.type='button';top.className='totop';top.setAttribute('aria-label','Back to top');
  var svg=document.createElementNS(NS,'svg');svg.setAttribute('viewBox','0 0 44 44');svg.setAttribute('aria-hidden','true');
  var ring=document.createElementNS(NS,'circle');ring.setAttribute('cx','22');ring.setAttribute('cy','22');ring.setAttribute('r','18');ring.setAttribute('class','ring');
  ring.setAttribute('stroke-dasharray',C.toFixed(1));ring.setAttribute('stroke-dashoffset',C.toFixed(1));
  var arrow=document.createElementNS(NS,'path');arrow.setAttribute('d','M22 28V16M16 21l6-6 6 6');arrow.setAttribute('class','arr');
  svg.appendChild(ring);svg.appendChild(arrow);top.appendChild(svg);document.body.appendChild(top);
  top.addEventListener('click',function(){window.scrollTo({top:0,behavior:'smooth'})});

  // 2. scroll cue at the bottom of the hero
  var next=hero&&(hero.nextElementSibling);
  if(hero&&next){
    var cue=document.createElement('button');cue.type='button';cue.className='cue';cue.setAttribute('aria-label','Scroll to the next section');cue.innerHTML='<span></span>';
    cue.addEventListener('click',function(){next.scrollIntoView({behavior:'smooth',block:'start'})});hero.appendChild(cue);
  }

  // 3. one scroll handler (rAF-throttled) drives progress, the back-to-top ring, hero parallax and the cue
  var tick=false,orbs=[].slice.call(document.querySelectorAll('.hero .orb'));
  function onScroll(){
    var y=window.pageYOffset||0,h=Math.max(1,d.scrollHeight-window.innerHeight),k=Math.min(1,y/h);
    bar.style.transform='scaleX('+k+')';ring.setAttribute('stroke-dashoffset',(C*(1-k)).toFixed(1));
    top.classList.toggle('on',y>700&&!d.classList.contains('is-playing'));
    if(hero){var hh=hero.offsetHeight;if(y<hh+200){if(fine)hero.style.setProperty('--py',y+'px');if(cue)cue.classList.toggle('gone',y>80)}}   // parallax only with a mouse
  }
  window.addEventListener('scroll',function(){if(tick)return;tick=true;requestAnimationFrame(function(){onScroll();tick=false})},{passive:true});onScroll();

  // 4. pointer effects (mouse and pen only; touch screens keep the lighter CSS motion)
  if(fine&&hero){
    var chips=hero.querySelector('.chips'),raf=0,px=0,py=0;
    hero.addEventListener('pointermove',function(e){
      var r=hero.getBoundingClientRect();px=(e.clientX-r.left)/r.width-.5;py=(e.clientY-r.top)/r.height-.5;
      if(!raf)raf=requestAnimationFrame(function(){raf=0;hero.style.setProperty('--px',px.toFixed(3));hero.style.setProperty('--pm',py.toFixed(3))});
    },{passive:true});
    hero.addEventListener('pointerleave',function(){hero.style.setProperty('--px','0');hero.style.setProperty('--pm','0')});
    // magnetic primary buttons
    [].slice.call(hero.querySelectorAll('.btn')).forEach(function(b){
      b.addEventListener('pointermove',function(e){var r=b.getBoundingClientRect();b.style.setProperty('--bx',((e.clientX-r.left-r.width/2)*.18).toFixed(1)+'px');b.style.setProperty('--by',((e.clientY-r.top-r.height/2)*.28).toFixed(1)+'px')},{passive:true});
      b.addEventListener('pointerleave',function(){b.style.setProperty('--bx','0px');b.style.setProperty('--by','0px')});
    });
    // cursor-following light inside cards
    document.addEventListener('pointermove',function(e){var c=e.target.closest&&e.target.closest('main .card');if(!c)return;var r=c.getBoundingClientRect();c.style.setProperty('--sx',(e.clientX-r.left)+'px');c.style.setProperty('--sy2',(e.clientY-r.top)+'px')},{passive:true});
  }

  // 5. a second, opposite-direction row in the subject ticker
  var m=document.querySelector('.marquee');
  if(m&&fine&&window.matchMedia('(min-width:700px)').matches){var c2=m.cloneNode(true);c2.classList.add('rev');c2.removeAttribute('role');c2.removeAttribute('aria-label');c2.setAttribute('aria-hidden','true');m.parentNode.insertBefore(c2,m.nextSibling)}

  // 6. section entrances that fire once: numbers band, faith band, steps
  if('IntersectionObserver' in window){
    var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('seen');io.unobserve(e.target)}})},{threshold:.25});
    [].slice.call(document.querySelectorAll('.numbers,.faithband,.testi,.hero')).forEach(function(el){io.observe(el)});
    // pause every endless hero animation while the hero is off-screen
    if(hero)new IntersectionObserver(function(es){hero.classList.toggle('off',!es[0].isIntersecting)}).observe(hero);
  }else{[].slice.call(document.querySelectorAll('.numbers,.faithband,.testi')).forEach(function(el){el.classList.add('seen')})}
  // 7. gentle ripple where a button is clicked
  document.addEventListener('pointerdown',function(e){
    if(d.classList.contains('calm'))return;var b=e.target.closest&&e.target.closest('main .btn,header.site .btn');if(!b||b.disabled)return;
    var r=b.getBoundingClientRect(),s=Math.max(r.width,r.height)*2,sp=document.createElement('span');sp.className='rip';
    sp.style.width=sp.style.height=s+'px';sp.style.left=(e.clientX-r.left-s/2)+'px';sp.style.top=(e.clientY-r.top-s/2)+'px';
    b.appendChild(sp);setTimeout(function(){if(sp.parentNode)sp.parentNode.removeChild(sp)},700);
  },{passive:true});
})();
