(function(){var d=document.documentElement,mm=window.matchMedia;d.classList.add('js');
if(!mm)return;
var rq=mm('(prefers-reduced-motion: reduce)');
if(rq.matches)d.classList.add('rm');
// follow the system setting if the visitor changes it while the page is open
if(rq.addEventListener)rq.addEventListener('change',function(){d.classList.toggle('rm',rq.matches)});
if(!mm('(hover:hover) and (pointer:fine)').matches)d.classList.add('touch');   // phones and tablets: no tilt, no parallax, no cursor effects
if(window.CSSViewTransitionRule)d.classList.add('vt');                          // the browser is doing the page-to-page transition itself
})();
