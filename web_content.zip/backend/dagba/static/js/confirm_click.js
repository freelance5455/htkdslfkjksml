/* Ask before a button with data-confirm-click submits its form (CSP-safe: no inline handlers). */
document.addEventListener('click',function(e){var b=e.target.closest('button[data-confirm-click]');if(b&&!window.confirm(b.getAttribute('data-confirm-click')))e.preventDefault()});
