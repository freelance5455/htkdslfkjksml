(function(){
'use strict';
var root=document.getElementById('builder');if(!root)return;
var csrf=document.querySelector('meta[name=csrf]').content,MAXMB=+root.dataset.maxMb;
var init=JSON.parse(document.getElementById('initial').textContent),C=init.course,CATS=init.cats;
var $=function(s,r){return(r||document).querySelector(s)},$$=function(s,r){return[].slice.call((r||document).querySelectorAll(s))};
var dirty=false,busy=0;
function clone(id){return document.getElementById(id).content.firstElementChild.cloneNode(true)}
function fmt(b){return b>=1048576?(b/1048576).toFixed(1)+' MB':Math.max(1,Math.round(b/1024))+' KB'}
function sleep(ms){return new Promise(function(r){setTimeout(r,ms)})}
function api(url,o){o=o||{};o.credentials='same-origin';o.headers=Object.assign({'X-CSRF-Token':csrf,'X-Requested-With':'fetch'},o.headers||{});
  return fetch(url,o).then(function(r){return r.json().catch(function(){return{ok:false,error:'Server error ('+r.status+')'}}).then(function(j){j._status=r.status;return j})})}
function postJSON(url,obj){return api(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(obj)})}
function show(list,kind){var b=$('#msgs');b.textContent='';(list||[]).forEach(function(t){var d=document.createElement('div');d.className='flash '+(kind||'error');d.textContent=t;b.appendChild(d)});if(list&&list.length)window.scrollTo({top:0,behavior:'smooth'})}
function mark(){dirty=true}
root.addEventListener('input',mark);root.addEventListener('change',mark);
window.addEventListener('beforeunload',function(e){if(dirty||busy){e.preventDefault();e.returnValue=''}});

// ---- course basics
$$('[data-c]').forEach(function(el){var k=el.dataset.c,v=C[k];if(v===undefined||v===null)v='';if(el.type==='checkbox')el.checked=!!v;else el.value=v});
var divSel=$('#c_division'),catSel=$('#c_cat'),lvlSel=$('#c_level');
function isAcademic(){return divSel.value==='academic'}
function isPro(){return divSel.value==='professional'}
function fillCats(){var cur=catSel.value||C.category_id||'',pro=isPro();catSel.textContent='';var o=document.createElement('option');o.value='';
  o.textContent=isAcademic()?'Choose a subject...':(pro?'(No programme area)':'(none)');catSel.appendChild(o);
  CATS.filter(function(c){return c.division===divSel.value&&(!isAcademic()||c.level===lvlSel.value)}).forEach(function(c){var x=document.createElement('option');x.value=c.id;x.textContent=c.name;if(String(c.id)===String(cur))x.selected=true;catSel.appendChild(x)});
  $('#catlabel').textContent=isAcademic()?'Subject *':(pro?'Programme area (optional)':'Category');
  $('#cathelp').textContent=isAcademic()?'The course appears under Academic > '+lvlSel.options[lvlSel.selectedIndex].text.split(':')[0]+' > this subject.':(pro?'Professional Development is its own section. Programme areas are an optional grouping; the course appears under Professional Development once published.':'');
  $('#levelbox').hidden=!isAcademic();var tr=$('#thumbrow');if(tr)tr.hidden=isAcademic()&&lvlSel.value==='basic';var m=$('details.more');if(m)m.hidden=isAcademic()}
var mv=$('#c_divmove');if(C.id){divSel.disabled=true;if(mv)mv.addEventListener('change',function(){divSel.disabled=!mv.checked;if(!mv.checked){divSel.value=C.division;C.category_id=catSel.value;fillCats()}})}
divSel.addEventListener('change',function(){C.category_id='';catSel.value='';fillCats()});
lvlSel.addEventListener('change',function(){C.category_id='';catSel.value='';fillCats()});fillCats();
var pol=$('#c_pol');function polSync(){var b=$('#daysbox');if(b&&pol)b.hidden=pol.value!=='days'}if(pol){pol.addEventListener('change',polSync);polSync()}
var thumb=C.thumbnail||'';var tp=$('#thumbprev');if(thumb){tp.src='/media/'+thumb;tp.hidden=false}
$('#c_thumb').addEventListener('change',function(){var f=this.files[0];if(!f)return;var fd=new FormData();fd.append('file',f);$('#thumbmsg').textContent='Uploading...';busy++;
  api('/staff/builder/thumbnail',{method:'POST',body:fd}).then(function(j){busy--;if(j.ok){thumb=j.file;tp.src=j.url;tp.hidden=false;$('#thumbmsg').textContent='Cover image ready.';mark()}else{$('#thumbmsg').textContent=j.error||'Upload failed.'}})});

// ---- ordering helpers
function move(el,dir){var s=dir<0?el.previousElementSibling:el.nextElementSibling;if(!s)return;if(dir<0)el.parentNode.insertBefore(el,s);else el.parentNode.insertBefore(s,el);renum();mark()}
function renum(){$$('.mod',$('#modules')).forEach(function(m,i){$('.mnum',m).textContent='Module '+(i+1);$$('.lesson',m).forEach(function(l,j){$('.lnum',l).textContent='Lesson '+(i+1)+'.'+(j+1)})});
  $$('.qcard',$('#questions')).forEach(function(q,i){$('.qnum',q).textContent='Question '+(i+1)})}

// ---- modules & lessons
function addModule(m){var el=clone('t-module');el.dataset.id=(m&&m.id)||'';$('[data-f=title]',el).value=(m&&m.title)||'';$('[data-f=release_at]',el).value=(m&&m.release_at)||'';$('#modules').appendChild(el);((m&&m.lessons)||[]).forEach(function(l){addLesson(el,l)});renum();return el}
function setKind(le,k){le.dataset.kind=k;$('.urllabel',le).textContent=k==='embed'?'Link to embed (https)':'Or paste a video link (https)'}
function vui(le){var s=$('.vstate',le),v=le._video,u=le._up;s.hidden=!(v||u);if(!(v||u))return;
  $('.vname',le).textContent=v?'Uploaded: '+(v.name||v.file):(u?u.file.name:'');
  var pr=$('progress',le);pr.hidden=!u||u.done;$('[data-act=vcancel]',le).hidden=!(u&&!u.done&&!u.failed);$('[data-act=vretry]',le).hidden=!(u&&u.failed);$('[data-act=vremove]',le).hidden=!v||(u&&!u.done)}
function rui(le){var r=le._res,s=$('.rstate',le);s.hidden=!r;if(r)$('.rname',le).textContent='Attached: '+(r.name||r.file)}
function addLesson(modEl,l){var el=clone('t-lesson');l=l||{};el.dataset.id=l.id||'';
  $('[data-f=title]',el).value=l.title||'';$('[data-f=body]',el).value=l.body||'';$('[data-f=video_url]',el).value=l.video_url||'';$('[data-f=duration_min]',el).value=l.duration_min||'';
  $('[data-f=release_at]',el).value=l.release_at||'';$('[data-f=free_preview]',el).checked=!!l.free_preview;$('[data-f=downloadable]',el).checked=l.downloadable===undefined?true:!!l.downloadable;
  var k=l.kind||'video';$('[data-f=kind]',el).value=k;setKind(el,k);
  if(l.video_file)el._video={file:l.video_file,name:l.video_name};if(l.resource_file)el._res={file:l.resource_file,name:l.resource_name};
  $('.lessons',modEl).appendChild(el);vui(el);rui(el);renum();return el}

// ---- resumable chunked video upload (4 MB pieces; survives flaky connections)
function sendChunk(url,blob,onp){return new Promise(function(res,rej){var x=new XMLHttpRequest();x.open('POST',url);x.setRequestHeader('X-CSRF-Token',csrf);x.setRequestHeader('Content-Type','application/octet-stream');
  x.upload.onprogress=function(e){if(e.lengthComputable)onp(e.loaded)};x.onload=function(){var j={};try{j=JSON.parse(x.responseText)}catch(e){}j._status=x.status;res(j)};x.onerror=function(){rej(new Error('network'))};x.ontimeout=x.onerror;x.timeout=180000;x.send(blob)})}
async function runUpload(le){var u=le._up;u.failed=false;show([]);vui(le);var t0=Date.now(),base=0;
  try{
    if(!u.id){var j=await postJSON('/staff/builder/upload/init',{name:u.file.name,size:u.file.size});if(!j.ok)throw new Error(j.error||'Could not start upload');u.id=j.upload_id;u.chunk=j.chunk;u.idx=0;u.off=0}
    else{var st=await api('/staff/builder/upload/'+u.id+'/status');if(!st.ok)throw new Error('Upload session expired. Choose the file again.');u.idx=st.next_index;u.off=st.received}
    base=u.off;
    while(u.off<u.file.size){
      if(u.cancel)throw new Error('cancelled');
      var blob=u.file.slice(u.off,u.off+u.chunk),tries=0,r;
      for(;;){
        try{r=await sendChunk('/staff/builder/upload/'+u.id+'/chunk?index='+u.idx,blob,function(l){var done=u.off+l;$('progress',le).value=Math.min(99,done*100/u.file.size);
          var sec=(Date.now()-t0)/1000||1;$('.vmeta',le).textContent=fmt(done)+' of '+fmt(u.file.size)+' ('+Math.round(done*100/u.file.size)+'%) at '+fmt((done-base)/sec)+'/s'});break}
        catch(e){if(++tries>5)throw new Error('Connection lost. Your progress is kept: press Resume upload.');await sleep(1200*tries)}
      }
      if(r.ok){u.off=r.received;u.idx++}
      else if(r._status===409&&r.expected!==undefined){u.idx=r.expected;u.off=r.received}
      else throw new Error(r.error||'Upload failed');
    }
    var f=await postJSON('/staff/builder/upload/'+u.id+'/finish',{});if(!f.ok)throw new Error(f.error||'Could not finish upload');
    le._video={file:f.file,name:f.name,size:f.size};u.done=true;$('.vmeta',le).textContent='Done: '+fmt(f.size);$('progress',le).value=100;busy--;le._up=null;vui(le);mark();
  }catch(e){busy--;if(e.message==='cancelled'){le._up=null;$('.vmeta',le).textContent='';vui(le);return}u.failed=true;vui(le);$('.vmeta',le).textContent=e.message;busy++;busy--}}
function startVideo(le,file){if(!file)return;
  if(!/\.(mp4|m4v|webm)$/i.test(file.name)){show(['Video must be an MP4 or WebM file. Tip: export your video as MP4 (H.264).']);return}
  if(file.size>MAXMB*1048576){show(['That video is '+fmt(file.size)+'. The limit is '+MAXMB+' MB. Compress it (720p H.264 is plenty) or ask the owner to raise the limit in Site settings.']);return}
  show([]);le._video=null;le._up={file:file};busy++;runUpload(le)}

root.addEventListener('click',function(e){var b=e.target.closest('[data-act]');if(!b)return;var act=b.dataset.act,box=b.closest('.lesson')||b.closest('.mod')||b.closest('.qcard');
  if(act==='up'||act==='down')move(box,act==='up'?-1:1);
  else if(act==='del'){if(box.dataset.id&&!confirm('Remove this item? It is deleted when you press Save.'))return;if(box._up&&!box._up.done){box._up.cancel=true}box.remove();renum();mark()}
  else if(act==='addles')addLesson(box);
  else if(act==='vcancel'){box._up.cancel=true}
  else if(act==='vretry'){busy++;runUpload(box)}
  else if(act==='vremove'){box._video=null;vui(box);mark()}
  else if(act==='rremove'){box._res=null;rui(box);mark()}
  else if(act==='addopt')addOpt($('.opts',box),'',false)});
root.addEventListener('change',function(e){var t=e.target,le=t.closest('.lesson');
  if(t.matches('[data-f=kind]')&&le)setKind(le,t.value);
  else if(t.dataset&&t.dataset.act==='pickvideo'){startVideo(le,t.files[0]);t.value=''}
  else if(t.dataset&&t.dataset.act==='pickres'&&t.files[0]){var fd=new FormData();fd.append('file',t.files[0]);$('.rname',le).textContent='Uploading...';$('.rstate',le).hidden=false;busy++;
    api('/staff/builder/resource',{method:'POST',body:fd}).then(function(j){busy--;if(j.ok){le._res={file:j.file,name:j.name};rui(le);mark()}else{rui(le);show([j.error||'Upload failed'])}});t.value=''}});
$('#addmod').addEventListener('click',function(){var m=addModule({title:'Module '+($$('.mod').length+1)});addLesson(m,{kind:'video'});mark()});

// ---- quiz
function addOpt(box,text,correct){var n='o'+Math.random().toString(36).slice(2),row=document.createElement('div');row.className='optrow';
  var r=document.createElement('input');r.type='radio';r.name=box.dataset.g;r.checked=!!correct;r.setAttribute('aria-label','Correct answer');var t=document.createElement('input');t.type='text';t.placeholder='Option';t.value=text||'';t.maxLength=300;row.appendChild(r);row.appendChild(t);box.appendChild(row)}
var qn=0;
function addQuestion(x){var el=clone('t-question'),box=$('.opts',el);box.dataset.g='qc'+(++qn);x=x||{};$('[data-f=prompt]',el).value=x.prompt||'';$('[data-f=explanation]',el).value=x.explanation||'';
  var opts=(x.options||'').split('\n').filter(Boolean);if(!opts.length)opts=['','','',''];opts.forEach(function(o,i){addOpt(box,o,x.correct===i+1)});$('#questions').appendChild(el);renum()}
var qon=$('#quizon');qon.addEventListener('change',function(){$('#quizbox').hidden=!qon.checked;if(qon.checked&&!$$('.qcard').length)addQuestion()});
$('#addq').addEventListener('click',function(){addQuestion();mark()});
if(C.quiz){qon.checked=true;$('#quizbox').hidden=false;$('#q_title').value=C.quiz.title;$('#q_pass').value=C.quiz.pass_mark;C.quiz.questions.forEach(addQuestion)}

// ---- load curriculum
(C.modules&&C.modules.length?C.modules:[{title:'Module 1',lessons:[]}]).forEach(function(m){addModule(m)});
if(!$$('.lesson').length){var f=$('.mod');if(f)addLesson(f,{kind:'video'})}
dirty=false;

// ---- collect & save
function collect(action){var p={action:action,id:C.id||'',thumbnail:thumb};
  $$('[data-c]').forEach(function(el){p[el.dataset.c]=el.type==='checkbox'?el.checked:el.value});
  p.modules=$$('.mod',$('#modules')).map(function(m){return{id:m.dataset.id||null,title:$('[data-f=title]',m).value,release_at:$('[data-f=release_at]',m).value,lessons:$$('.lesson',m).map(function(l){var v=l._video,r=l._res;
    return{id:l.dataset.id||null,title:$('[data-f=title]',l).value,kind:$('[data-f=kind]',l).value,body:$('[data-f=body]',l).value,video_url:$('[data-f=video_url]',l).value,
      video_file:v?v.file:'',video_name:v?v.name:'',resource_file:r?r.file:'',resource_name:r?r.name:'',duration_min:$('[data-f=duration_min]',l).value,
      free_preview:$('[data-f=free_preview]',l).checked,downloadable:$('[data-f=downloadable]',l).checked,release_at:$('[data-f=release_at]',l).value}})}});
  if(qon.checked){p.quiz={id:C.quiz?C.quiz.id:null,title:$('#q_title').value,pass_mark:$('#q_pass').value,questions:$$('.qcard').map(function(q){var rows=$$('.optrow',q),texts=[],cor=0,n=0;
    rows.forEach(function(r){var t=$('input[type=text]',r).value.trim();if(t){n++;texts.push(t);if($('input[type=radio]',r).checked)cor=n}});
    return{prompt:$('[data-f=prompt]',q).value,options:texts.join('\n'),correct:cor,explanation:$('[data-f=explanation]',q).value}})}}
  else if(C.quiz)p.quiz={id:C.quiz.id,delete:true};
  return p}
var saving=false;
$$('[data-save]').forEach(function(b){b.addEventListener('click',function(){
  if(saving)return;if(busy){show(['A video or file is still uploading. Wait for it to finish (or cancel it), then save.']);return}
  if($$('.lesson').some(function(l){return l._up&&!l._up.done})){show(['A video upload was interrupted. Press "Resume upload" on that lesson (your progress is kept), or remove the lesson, then save.']);return}
  saving=true;$('#savestate').textContent='Saving...';$$('[data-save]').forEach(function(x){x.disabled=true});
  postJSON('/staff/builder/save',collect(b.dataset.save)).then(function(j){
    if(j.ok){dirty=false;window.location.href=j.redirect}else{saving=false;$('#savestate').textContent='';$$('[data-save]').forEach(function(x){x.disabled=false});show(j.errors||[j.error||'Could not save.'])}
  }).catch(function(){saving=false;$$('[data-save]').forEach(function(x){x.disabled=false});$('#savestate').textContent='';show(['Network problem. Nothing was lost on this page: try saving again.'])})})});
})();
