/* Dagba motion layer (global). Progressive enhancement only: every page is complete and usable without this file.
   Order matters: functional helpers first (they also run for "reduce motion"), decorative motion last (skipped for "reduce motion"). */
(function(){
  'use strict';
  var d=document.documentElement,rm=d.classList.contains('rm');
  function mq(q){return !!(window.matchMedia&&window.matchMedia(q).matches)}
  var fine=mq('(hover:hover) and (pointer:fine)'),wide=mq('(min-width:700px)');
  var staff=!!document.querySelector('.dash[data-staff]');
  function $$(s,r){return [].slice.call((r||document).querySelectorAll(s))}
  function ease(k){return 1-Math.pow(1-k,3)}
  function countTo(el,n,ms,suffix){var s=null;suffix=suffix||'';el.textContent='0'+suffix;
    (function step(ts){if(!s)s=ts;var k=Math.min(1,(ts-s)/ms);el.textContent=Math.round(n*ease(k))+suffix;if(k<1)requestAnimationFrame(step);else el.textContent=n+suffix})(performance.now())}
  var hasIO='IntersectionObserver' in window;

  /* ---------- header shadow, reading progress ---------- */
  var header=document.querySelector('header.site'),bar=null;
  if(document.querySelector('.prose')){bar=document.createElement('div');bar.className='readbar';bar.setAttribute('aria-hidden','true');document.body.appendChild(bar)}
  function onScroll(){var y=window.pageYOffset||0;if(header)header.classList.toggle('scrolled',y>8);
    if(bar){var h=d.scrollHeight-window.innerHeight;bar.style.transform='scaleX('+(h>0?Math.min(1,y/h):0)+')'}}
  var ticking=false;window.addEventListener('scroll',function(){if(!ticking){ticking=true;requestAnimationFrame(function(){onScroll();ticking=false})}},{passive:true});onScroll();

  /* ---------- toast + "something just happened" messages that survive a page change ---------- */
  var tbox=null,tq=[],playing=false,tt=null;
  function flush(){
    if(playing||!tq.length||(tbox&&tbox.classList.contains('on')))return;
    var t=tq.shift();
    if(!tbox){tbox=document.createElement('div');tbox.className='toast';tbox.setAttribute('role','status');tbox.setAttribute('aria-live','polite');document.body.appendChild(tbox)}
    tbox.className='toast '+t.k;
    setTimeout(function(){tbox.textContent='';var i=document.createElement('span');i.className='tick';i.setAttribute('aria-hidden','true');i.textContent=t.k==='error'?'!':'\u2713';
      var s=document.createElement('span');s.textContent=t.m;tbox.appendChild(i);tbox.appendChild(s);tbox.classList.add('on');
      clearTimeout(tt);tt=setTimeout(function(){tbox.classList.remove('on');setTimeout(flush,350)},3600)},40);
  }
  function toast(m,k){tq.push({m:m,k:k||'success'});flush()}
  function later(m,k){try{sessionStorage.setItem('dda-toast',JSON.stringify({m:m,k:k||'success',t:Date.now()}))}catch(e){}}
  try{var pend=sessionStorage.getItem('dda-toast');
    if(pend){sessionStorage.removeItem('dda-toast');var po=JSON.parse(pend);
      if(po&&po.m&&Date.now()-po.t<15000&&!document.querySelector('main .flash.success'))setTimeout(function(){toast(po.m,po.k)},400)}}catch(e){}
  // never show anything while a video or audio lesson is playing; queued messages appear when it pauses or ends
  function isMedia(t){return t&&(t.tagName==='VIDEO'||t.tagName==='AUDIO')}
  ['play','playing'].forEach(function(ev){document.addEventListener(ev,function(e){if(isMedia(e.target)){playing=true;d.classList.add('is-playing')}},true)});
  ['pause','ended'].forEach(function(ev){document.addEventListener(ev,function(e){if(isMedia(e.target)){playing=false;d.classList.remove('is-playing');setTimeout(flush,600)}},true)});
  if(document.querySelector('.player,.faudio'))d.classList.add('calm');          // lesson pages: no ripples, no back-to-top, no floating extras
  window.DDA={toast:toast,later:later};

  /* ---------- images fade in once loaded ---------- */
  function imgFade(root){$$('.amedia img,img.thumb,img.catimg',root).forEach(function(im){
    if(im.classList.contains('loaded'))return;function ok(){im.classList.add('loaded')}
    if(im.complete&&im.naturalWidth)ok();else{im.addEventListener('load',ok);im.addEventListener('error',ok)}})}
  imgFade();

  /* ---------- progress bars: fill when seen, animate from the last value this tab saw, turn green at 100% ---------- */
  var pio=null;
  function progressBars(root){
    $$('progress[value]',root).forEach(function(p){
      if(p.closest('#builder,.vstate')||p._pg)return;p._pg=1;
      var max=parseFloat(p.getAttribute('max'))||100,t=parseFloat(p.getAttribute('value'))||0,key=p.getAttribute('data-pkey'),prev=null;
      p.classList.toggle('done',max>0&&t>=max);
      if(key){try{var v=sessionStorage.getItem('dda-p:'+key);if(v!==null)prev=parseFloat(v)}catch(e){}try{sessionStorage.setItem('dda-p:'+key,String(t))}catch(e){}}
      if(rm||t<=0||(prev!==null&&Math.abs(prev-t)<.01))return;
      var from=prev!==null&&prev<t?prev:0;p.value=from;p._to=t;p._from=from;
      if(!hasIO){p.value=t;return}
      if(!pio)pio=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;pio.unobserve(e.target);var el=e.target,s=null,a=el._from,b=el._to;
        setTimeout(function(){requestAnimationFrame(function step(ts){if(!s)s=ts;var k=Math.min(1,(ts-s)/(a>0?700:900));el.value=a+(b-a)*ease(k);if(k<1)requestAnimationFrame(step);else el.value=b})},180)})},{threshold:.2});
      pio.observe(p);
    });
  }
  progressBars();

  /* ---------- dashboard statistics: accent bar + count-up when seen (plain integers only, never invents data) ---------- */
  var sio=null;
  function stats(root){
    $$('.stat',root).forEach(function(st){
      if(st._st)return;st._st=1;var b=st.querySelector('b'),txt=b?b.textContent.trim():'',n=/^\d{1,6}$/.test(txt)?parseInt(txt,10):0;
      if(rm||!hasIO){st.classList.add('on');return}
      if(!sio)sio=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;sio.unobserve(e.target);var el=e.target;el.classList.add('on');
        if(el._n>1)countTo(el._b,el._n,800)})},{threshold:.4});
      st._n=n;st._b=b;sio.observe(st);
    });
  }
  stats();

  /* ---------- testimonial carousel: swipe/scroll-snap, buttons, dots. Auto-advance only on wide screens with a mouse, and it stops for good after any interaction ---------- */
  var car=document.querySelector('.tcar');
  if(car){
    var track=car.querySelector('.ttrack'),cards=[].slice.call(track.children),dotsBox=car.querySelector('.tdots'),ctrl=car.querySelector('.tctrl');
    var per=1,pages=1,page=0,timer=null,paused=false,visible=false,dots=[],touched=false;
    function cardLeft(i){return cards[i].getBoundingClientRect().left-track.getBoundingClientRect().left+track.scrollLeft}
    function target(i){var c=cards[i];return per===1?cardLeft(i)-(track.clientWidth-c.offsetWidth)/2:cardLeft(i)-parseFloat(getComputedStyle(track).paddingLeft||0)}
    function go(p){page=(p+pages)%pages;var idx=Math.min(page*per,cards.length-1),maxL=track.scrollWidth-track.clientWidth;
      track.scrollTo({left:Math.max(0,Math.min(maxL,target(idx))),behavior:rm?'auto':'smooth'});mark(page)}
    function mark(p){dots.forEach(function(x,i){x.classList.toggle('on',i===p);x.setAttribute('aria-current',i===p?'true':'false')})}
    function build(){var w=cards[0].getBoundingClientRect().width+16;per=Math.max(1,Math.round(track.clientWidth/w));pages=Math.max(1,Math.ceil(cards.length/per));
      track.classList.toggle('few',cards.length<=per);ctrl.hidden=pages<=1;dotsBox.textContent='';dots=[];
      for(var i=0;i<pages;i++){(function(i){var b=document.createElement('button');b.type='button';b.setAttribute('aria-label','Show testimonials '+(i+1));b.addEventListener('click',function(){hold();go(i)});dotsBox.appendChild(b);dots.push(b)})(i)}
      mark(Math.min(page,pages-1))}
    function hold(){touched=true}
    var st=null;track.addEventListener('scroll',function(){clearTimeout(st);st=setTimeout(function(){
      var tl=track.getBoundingClientRect().left,best=0,bd=1e9;cards.forEach(function(c,i){var dd=Math.abs(c.getBoundingClientRect().left-tl-(per===1?(track.clientWidth-c.offsetWidth)/2:0));if(dd<bd){bd=dd;best=i}});
      var atEnd=track.scrollLeft>=track.scrollWidth-track.clientWidth-4;page=atEnd?pages-1:Math.min(pages-1,Math.round(best/per));mark(page)},80)},{passive:true});
    car.querySelectorAll('.tbtn').forEach(function(b){b.addEventListener('click',function(){hold();go(page+(+b.getAttribute('data-dir')))})});
    ['pointerenter','focusin'].forEach(function(ev){car.addEventListener(ev,function(){paused=true},{passive:true})});
    ['pointerleave','focusout'].forEach(function(ev){car.addEventListener(ev,function(){paused=false},{passive:true})});
    ['touchstart','pointerdown','wheel'].forEach(function(ev){car.addEventListener(ev,hold,{passive:true})});
    track.addEventListener('keydown',function(e){if(e.key==='ArrowRight'){e.preventDefault();hold();go(page+1)}else if(e.key==='ArrowLeft'){e.preventDefault();hold();go(page-1)}});
    if(hasIO){
      var cio=new IntersectionObserver(function(es){es.forEach(function(e){e.target.classList.toggle('on',e.isIntersecting)})},{root:track,threshold:.6});cards.forEach(function(c){cio.observe(c)});
      new IntersectionObserver(function(es){visible=es[0].isIntersecting},{threshold:.35}).observe(car);
    }else{cards.forEach(function(c){c.classList.add('on')});visible=true}
    var rz=null;window.addEventListener('resize',function(){clearTimeout(rz);rz=setTimeout(function(){build();go(page)},150)});
    build();
    var auto=fine&&wide;                // phones and tablets never auto-advance
    if(!rm&&cards.length>1)timer=setInterval(function(){if(!auto||paused||touched||document.hidden||!visible||pages<=1)return;go(page+1)},5600);
  }

  /* ---------- curriculum expansion on public pages: first 6 lessons, the rest on demand ---------- */
  var clpId=0;
  function collapsibles(root){
    if(document.querySelector('.dash'))return;
    $$('ol.lessonlist',root).forEach(function(ol){
      if(ol.getAttribute('data-clp'))return;var li=[].slice.call(ol.children).filter(function(c){return c.tagName==='LI'});if(li.length<=8)return;
      ol.setAttribute('data-clp','1');if(!ol.id)ol.id='lessons-'+(++clpId);var extra=li.slice(6);
      extra.forEach(function(x){x.hidden=true;x.classList.add('more-item')});
      var b=document.createElement('button');b.type='button';b.className='btn sec sm clp-toggle';b.setAttribute('aria-expanded','false');b.setAttribute('aria-controls',ol.id);
      var all='Show all '+li.length+' lessons';b.textContent=all;
      b.addEventListener('click',function(){var open=b.getAttribute('aria-expanded')!=='true';b.setAttribute('aria-expanded',open?'true':'false');b.textContent=open?'Show fewer lessons':all;
        extra.forEach(function(x,i){x.hidden=!open;if(open){x.style.setProperty('--i',Math.min(i,10));x.classList.remove('pop');void x.offsetWidth;x.classList.add('pop')}else x.classList.remove('pop')});
        if(open)setTimeout(function(){extra.forEach(function(x){x.classList.remove('pop')})},900)});
      ol.parentNode.insertBefore(b,ol.nextSibling);
    });
  }
  collapsibles();

  /* ---------- live search / filter: same URLs and same server pages, swapped in place with a soft transition.
     Any problem at all falls back to a normal page load, so filtering can never break. ---------- */
  var statusEl=null;
  function say(t){if(!statusEl){statusEl=document.createElement('div');statusEl.className='skip';statusEl.setAttribute('role','status');statusEl.setAttribute('aria-live','polite');document.body.appendChild(statusEl)}statusEl.textContent=t}
  $$('form[data-live]').forEach(function(form){
    var sels=(form.getAttribute('data-live')||'').split(',').map(function(s){return s.trim()}).filter(Boolean);
    var boxes=sels.map(function(s){return document.querySelector(s)}).filter(Boolean);if(!boxes.length||!window.fetch||!window.URL||!window.DOMParser)return;
    var ctl=null,seq=0,deb=null;
    function urlFor(){var u=new URL(form.getAttribute('action')||location.pathname,location.href);u.search='';new FormData(form).forEach(function(v,k){if(typeof v==='string'&&v!=='')u.searchParams.append(k,v)});return u}
    function load(u,push,scroll){
      var my=++seq;if(ctl&&ctl.abort)ctl.abort();ctl=window.AbortController?new AbortController():null;
      boxes.forEach(function(b){b.classList.add('is-loading');b.setAttribute('aria-busy','true')});
      fetch(u.href,{credentials:'same-origin',headers:{'X-Requested-With':'fetch'},signal:ctl?ctl.signal:undefined}).then(function(r){
        if(!r.ok||(r.headers.get('content-type')||'').indexOf('text/html')<0)throw new Error('bad');return r.text()}).then(function(html){
        if(my!==seq)return;var doc=new DOMParser().parseFromString(html,'text/html');
        sels.forEach(function(s){var nb=doc.querySelector(s),ob=document.querySelector(s);if(!nb||!ob)throw new Error('shape');
          ob.innerHTML=nb.innerHTML;ob.classList.remove('is-loading');ob.removeAttribute('aria-busy');
          if(!rm){ob.classList.remove('swap-in');$$('.card',ob).forEach(function(c,i){c.style.setProperty('--i',Math.min(i,10))});void ob.offsetWidth;ob.classList.add('swap-in')}
          imgFade(ob);collapsibles(ob);stats(ob);progressBars(ob)});
        if(push)history.pushState({live:1},'',u.href);
        var n=$$('.card',boxes[0]).length;say(n?n+(n===1?' result shown.':' results shown.'):'No results.');
        if(scroll){var t=boxes[0].getBoundingClientRect().top+window.pageYOffset-80;window.scrollTo({top:Math.max(0,t),behavior:rm?'auto':'smooth'})}
      }).catch(function(e){if(e&&e.name==='AbortError')return;location.href=u.href});
    }
    form.addEventListener('submit',function(e){e.preventDefault();clearTimeout(deb);load(urlFor(),true,false)});
    form.addEventListener('change',function(e){if(e.target.tagName==='SELECT'){clearTimeout(deb);load(urlFor(),true,false)}});
    form.addEventListener('input',function(e){var t=e.target;if(t.type!=='search')return;clearTimeout(deb);var v=t.value.trim();if(v.length===1)return;deb=setTimeout(function(){load(urlFor(),true,false)},450)});
    boxes[0].addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('.pager a');if(!a||e.metaKey||e.ctrlKey||e.shiftKey||e.button!==0)return;
      var u;try{u=new URL(a.href,location.href)}catch(x){return}if(u.origin!==location.origin)return;e.preventDefault();load(u,true,true)});
    window.addEventListener('popstate',function(){var u=new URL(location.href);
      [].slice.call(form.elements).forEach(function(el){if(el.name&&el.type!=='submit'&&el.type!=='hidden')el.value=u.searchParams.get(el.name)||''});load(u,false,false)});
  });

  /* ---------- forms: validation states, busy buttons, upload notice, lesson-completion feedback ---------- */
  var TEXTY=/^(text|email|password|number|url|tel|date|datetime-local|time)$/;
  function fieldOk(el){return el&&el.form&&el.willValidate&&!el.closest('#builder')&&!el.form.hasAttribute('data-live')&&(el.tagName==='SELECT'||el.tagName==='TEXTAREA'||(el.tagName==='INPUT'&&TEXTY.test(el.type)))}
  document.addEventListener('invalid',function(e){var el=e.target;if(!fieldOk(el))return;el.classList.remove('is-valid');el.classList.add('is-invalid');el.setAttribute('aria-invalid','true');
    var f=el.form;if(!rm&&!f._shook){f._shook=1;el.classList.remove('shake');void el.offsetWidth;el.classList.add('shake');setTimeout(function(){f._shook=0;el.classList.remove('shake')},700)}},true);
  document.addEventListener('input',function(e){var el=e.target;if(el.classList&&el.classList.contains('is-invalid')&&el.validity&&el.validity.valid){el.classList.remove('is-invalid');el.removeAttribute('aria-invalid')}},true);
  document.addEventListener('focusout',function(e){var el=e.target;if(!fieldOk(el)||el.value==='')return;
    if(el.validity.valid){el.classList.remove('is-invalid');el.removeAttribute('aria-invalid');if(el.required||el.type==='email'||el.type==='url')el.classList.add('is-valid')}
    else{el.classList.remove('is-valid');el.classList.add('is-invalid');el.setAttribute('aria-invalid','true')}},true);
  var COMPLETE=/\/(learn|faith)\/lesson\/\d+\/complete$/;
  document.addEventListener('submit',function(e){
    var f=e.target;if(e.defaultPrevented||!f||f.tagName!=='FORM'||(f.method||'get').toLowerCase()!=='post'||f.hasAttribute('data-live')||f.closest('#builder'))return;
    var btn=e.submitter||f.querySelector('button:not([type=button]),input[type=submit]');
    var path='';try{path=new URL(f.action,location.href).pathname}catch(x){}
    if(btn&&btn.classList){
      if(COMPLETE.test(path)&&!f.querySelector('[name=undo]')){later('Lesson complete. Your progress is saved.');btn.classList.add('is-done');if(btn.tagName==='BUTTON')btn.textContent='\u2713 Saved'}
      else{btn.classList.add('is-busy');btn.setAttribute('aria-busy','true')}
    }
    if(f.enctype==='multipart/form-data'&&$$('input[type=file]',f).some(function(i){return i.files&&i.files.length})&&!f.querySelector('.upstate')){
      var u=document.createElement('div');u.className='upstate';u.setAttribute('role','status');u.innerHTML='<span>Uploading. Please keep this page open until it finishes.</span><div class="upbar"><i></i></div>';f.appendChild(u)}
    if(f.hasAttribute('data-confirm')){var row=f.closest('tr,.card');if(row)row.classList.add('removing')}
    setTimeout(function(){if(btn&&btn.classList)btn.classList.remove('is-busy')},60000);
  });
  window.addEventListener('pageshow',function(){d.classList.remove('leaving');$$('.is-busy').forEach(function(b){b.classList.remove('is-busy');b.removeAttribute('aria-busy')});$$('.upstate').forEach(function(u){u.parentNode.removeChild(u)});$$('.removing').forEach(function(r){r.classList.remove('removing')})});

  /* ---------- quiz score ring, certificates (one-time achievement shine) ---------- */
  $$('.qscore').forEach(function(el){var n=el.querySelector('.qnum');if(!rm)requestAnimationFrame(function(){requestAnimationFrame(function(){el.classList.add('go')})});
    if(n&&!rm){var t=parseInt(n.getAttribute('data-pct'),10);if(t>1)countTo(n,t,900,'%')}else el.classList.add('go')});
  $$('[data-cert]').forEach(function(el){var k='dda-cert:'+el.getAttribute('data-cert'),seen=false;try{seen=!!localStorage.getItem(k)}catch(e){}
    if(seen)return;try{localStorage.setItem(k,'1')}catch(e){}
    if(!rm)el.classList.add('cert-new')});

  if(rm)return;                       // everything below is decorative motion: skipped when the user asks for reduced motion

  /* ---------- hero rotating word: pauses when the hero is off-screen ---------- */
  var rot=document.querySelector('.rotor');
  if(rot){var words=[];try{words=JSON.parse(rot.getAttribute('data-words')||'[]')}catch(e){}
    if(words.length>1){var wi=0,heroOn=true;var hh=document.querySelector('.hero');if(hh&&hasIO)new IntersectionObserver(function(es){heroOn=es[0].isIntersecting}).observe(hh);
      setInterval(function(){if(document.hidden||!heroOn)return;rot.classList.add('out');setTimeout(function(){wi=(wi+1)%words.length;rot.textContent=words[wi];rot.classList.remove('out');rot.classList.add('pre');void rot.offsetWidth;rot.classList.remove('pre')},300)},2800)}}

  /* ---------- scroll reveal with short staggers: transform/opacity only; never hides content for long ---------- */
  var rio=null;
  function shown(el){if(!el.classList.contains('reveal')||el.classList.contains('in'))return;if(rio)rio.unobserve(el);el.classList.add('in');
    var dl=parseInt(el.style.getPropertyValue('--d'),10)||0;
    setTimeout(function(){el.classList.remove('reveal','in','quick');el.style.removeProperty('--d')},dl+800)}   // hand control back to hover styles
  function reveal(root){
    if(!hasIO)return;var main=document.querySelector('main');if(!main)return;
    var sel='.card,.stat,.q,details.faq,blockquote,.tcar,section.block>.wrap>h2,.block>h1,.lessonlist,.bank,.tablewrap,.pager,.wrap.narrow>h1,.fformat,.frow';
    var items=$$(sel,root||main).filter(function(el){return !el.closest('.hero')&&!el.closest('.fcar')&&!el.closest('.reveal')&&!el.classList.contains('flash')&&!el.classList.contains('pricepanel')&&!el.closest('.cinfo')&&!el.classList.contains('reveal')});
    var groups=new Map(),step=staff?35:60,cap=staff?5:6;
    items.forEach(function(el){var p=el.parentElement,i=groups.get(p)||0;groups.set(p,i+1);
      el.style.setProperty('--d',Math.min(i,cap)*step+'ms');el.classList.add('reveal');if(staff)el.classList.add('quick')});
    if(!rio)rio=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){rio.unobserve(e.target);shown(e.target)}})},{threshold:.08,rootMargin:'0px 0px -6% 0px'});
    items.forEach(function(el){rio.observe(el)});
    return items;
  }
  var revItems=reveal()||[];
  // safety nets: anything scrolled past, or reached with the keyboard, must never stay hidden
  window.addEventListener('scroll',function(){revItems.forEach(function(el){if(el.classList.contains('reveal')&&!el.classList.contains('in')&&el.getBoundingClientRect().bottom<0){if(rio)rio.unobserve(el);el.classList.remove('reveal');el.style.removeProperty('--d')}})},{passive:true});
  document.addEventListener('focusin',function(e){var el=e.target.closest&&e.target.closest('.reveal');if(el)shown(el)});

  /* ---------- hero spotlight (mouse only) ---------- */
  var hero=document.querySelector('.hero');
  if(hero&&fine)hero.addEventListener('pointermove',function(e){var r=hero.getBoundingClientRect();hero.style.setProperty('--mx',(e.clientX-r.left)+'px');hero.style.setProperty('--my',(e.clientY-r.top)+'px')},{passive:true});

  /* ---------- heading underline sweeps, connected steps, real-number counters ---------- */
  if(hasIO){
    var dio=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;dio.unobserve(e.target);var t=e.target;
      if(t.classList.contains('num')){var n=parseInt(t.getAttribute('data-count'),10)||0;if(n>1)countTo(t,n,1100)}else t.classList.add('drawn')})},{threshold:.35});
    $$('main section.block h2,.steps,.num[data-count]').forEach(function(el){dio.observe(el)});
  }

  /* ---------- subtle 3D tilt: mouse/pen only, never on touch screens or in dashboards ---------- */
  if(fine&&!staff){
    document.addEventListener('pointermove',function(e){if(e.pointerType==='touch')return;var c=e.target.closest&&e.target.closest('.tilt');if(!c)return;var r=c.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;
      c.style.setProperty('--ry',(x*5).toFixed(2)+'deg');c.style.setProperty('--rx',(-y*5).toFixed(2)+'deg')},{passive:true});
    document.addEventListener('pointerout',function(e){var c=e.target.closest&&e.target.closest('.tilt');if(c&&!c.contains(e.relatedTarget)){c.style.setProperty('--rx','0deg');c.style.setProperty('--ry','0deg')}});
  }

  /* ---------- soft page-leave fade for same-site navigation (skipped when the browser does view transitions, on lesson pages,
     for downloads, and it always restores itself so a cancelled or slow navigation can never leave the page faded) ---------- */
  var NOFADE=/\.(pdf|zip|csv|docx?|xlsx?|pptx?|mp4|webm|mp3|png|jpe?g)$/i;
  document.addEventListener('click',function(e){
    if(d.classList.contains('vt')||d.classList.contains('calm'))return;
    var a=e.target.closest&&e.target.closest('a[href]');
    if(!a||e.defaultPrevented||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey||e.button!==0||a.target||a.hasAttribute('download')||a.hasAttribute('data-no-fade'))return;
    var u;try{u=new URL(a.href,location.href)}catch(x){return}
    if(u.origin!==location.origin||(u.pathname===location.pathname&&u.search===location.search)||u.hash&&u.pathname===location.pathname||NOFADE.test(u.pathname)||/[?&]dl=1/.test(u.search)||/^\/(certificates|learn\/resource|learn\/video|pay\/receipt|media|faith\/resource|faith\/media)\b/.test(u.pathname))return;
    d.classList.add('leaving');setTimeout(function(){d.classList.remove('leaving')},2500);
  });
  document.addEventListener('visibilitychange',function(){if(!document.hidden)d.classList.remove('leaving')});
})();
