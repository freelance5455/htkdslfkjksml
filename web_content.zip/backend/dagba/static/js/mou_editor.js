/* Rich-text editor for the Tutor MOU. No external library (the site's CSP allows only its own scripts). Without JavaScript the plain
   textarea stays visible and still works; the server sanitises everything either way. */
(function(){
'use strict';
var wrap=document.getElementById('mou-wrap');if(!wrap)return;
var ta=document.getElementById('mou_body'),surface=document.getElementById('mou-surface'),tools=document.getElementById('mou-tools'),count=document.getElementById('mou-count');
var form=ta.form,dirty=false,submitting=false;
try{document.execCommand('defaultParagraphSeparator',false,'p')}catch(e){}
surface.innerHTML=ta.value;wrap.classList.add('on');
function sync(){ta.value=surface.innerHTML;if(count){var n=(surface.innerText||'').replace(/\s+/g,' ').trim().length;count.textContent=n.toLocaleString()+' characters'}}
sync();
function run(cmd,arg){surface.focus();try{document.execCommand(cmd,false,arg||null)}catch(e){}sync();dirty=true}
function safeUrl(u){u=(u||'').trim();return /^(https?:\/\/[^\s"'<>]+|mailto:[^\s"'<>]+@[^\s"'<>]+)$/i.test(u)?u:''}
var actions={
  h2:function(){run('formatBlock','<h2>')},h3:function(){run('formatBlock','<h3>')},h4:function(){run('formatBlock','<h4>')},p:function(){run('formatBlock','<p>')},
  bold:function(){run('bold')},italic:function(){run('italic')},underline:function(){run('underline')},
  ul:function(){run('insertUnorderedList')},ol:function(){run('insertOrderedList')},indent:function(){run('indent')},outdent:function(){run('outdent')},
  quote:function(){run('formatBlock','<blockquote>')},hr:function(){run('insertHorizontalRule')},
  undo:function(){run('undo')},redo:function(){run('redo')},clear:function(){run('removeFormat');run('formatBlock','<p>')},
  link:function(){var u=safeUrl(window.prompt('Link address (https://... or mailto:...)','https://'));if(u)run('createLink',u);else if(u===''){}},
  unlink:function(){run('unlink')}
};
tools.addEventListener('pointerdown',function(e){if(e.target.closest('button'))e.preventDefault()});   /* keep the text selection while a button is pressed */
tools.addEventListener('click',function(e){var b=e.target.closest('button[data-cmd]');if(b&&actions[b.dataset.cmd])actions[b.dataset.cmd]()});
surface.addEventListener('input',function(){sync();dirty=true});
surface.addEventListener('paste',function(e){var t=(e.clipboardData||window.clipboardData);if(!t)return;e.preventDefault();var txt=t.getData('text/plain');document.execCommand('insertText',false,txt)});
surface.addEventListener('keydown',function(e){if((e.ctrlKey||e.metaKey)&&!e.shiftKey){var k=e.key.toLowerCase();if(k==='b'||k==='i'||k==='u')return}});
form.addEventListener('submit',function(e){
  var b=e.submitter;
  if(b&&b.hasAttribute('data-confirm-click')&&!window.confirm(b.getAttribute('data-confirm-click'))){e.preventDefault();return}
  if(submitting){e.preventDefault();return}
  sync();submitting=true;dirty=false;
  setTimeout(function(){[].forEach.call(form.querySelectorAll('button[name=action]'),function(x){x.disabled=true;if(x===b)x.textContent='Working...'})},0);
});
window.addEventListener('beforeunload',function(e){if(dirty&&!submitting){e.preventDefault();e.returnValue=''}});
window.addEventListener('pageshow',function(ev){if(ev.persisted){submitting=false;[].forEach.call(form.querySelectorAll('button[name=action]'),function(x){x.disabled=false})}});
})();
