/* Homepage hero carousel. Vanilla JS, no dependencies. Progressive enhancement: without it the first slide is shown, complete and usable.
   - the progress bars ARE the timer (a CSS animation ends => next slide), so pausing never loses your place
   - pauses for hover, keyboard focus, touch, hidden tab, off-screen, and when the visitor presses Pause
   - no automatic rotation with "reduce motion" or Data Saver / 2G; slide pictures after the first load only when needed */
(function(){
  'use strict';
  var root=document.querySelector('[data-hx]');if(!root)return;
  var d=document.documentElement,stage=root.querySelector('.hx-stage'),slides=[].slice.call(root.querySelectorAll('.hslide')),n=slides.length;if(!n)return;
  var bars=[].slice.call(root.querySelectorAll('.hx-bar')),pp=root.querySelector('.hx-pp');
  function mq(q){return !!(window.matchMedia&&window.matchMedia(q).matches)}
  var rm=d.classList.contains('rm')||mq('(prefers-reduced-motion: reduce)');
  var conn=navigator.connection||{},lean=!!conn.saveData||/(^|-)2g$/.test(conn.effectiveType||'');
  var ms=Math.max(3,Math.min(20,+root.getAttribute('data-interval')||6))*1000;
  var cur=Math.min(n-1,Math.max(0,+root.getAttribute('data-start')||0));
  var auto=root.getAttribute('data-autoplay')==='1'&&n>1&&!rm&&!lean;
  var userPaused=false,hover=false,focus=false,touch=false,inView=true,hid=!!document.hidden;
  function mod(i){return((i%n)+n)%n}

  /* ---- pictures: later slides load on demand; a failed picture falls back to the built-in artwork ---- */
  function prime(i){var im=slides[mod(i)].querySelector('img[data-src]');if(!im)return;
    var ss=im.getAttribute('data-srcset');if(ss){im.setAttribute('srcset',ss);im.removeAttribute('data-srcset')}
    im.setAttribute('src',im.getAttribute('data-src'));im.removeAttribute('data-src')}
  slides.forEach(function(s){var im=s.querySelector('img');if(!im)return;im.setAttribute('draggable','false');
    function bad(){var fb=im.getAttribute('data-fallback');
      if(fb&&!im.getAttribute('data-tried')){im.setAttribute('data-tried','1');im.removeAttribute('srcset');im.classList.add('art');im.alt='';im.src=fb}else im.classList.add('broken')}
    im.addEventListener('error',bad);
    if(im.complete&&im.naturalWidth===0&&(im.getAttribute('src')||'').indexOf('data:')!==0&&im.getAttribute('src'))bad()});

  /* ---- state ---- */
  function sync(){root.classList.toggle('is-auto',auto);root.classList.toggle('is-paused',userPaused||hover||focus||touch||hid||!inView)}
  function paint(){bars.forEach(function(b,i){var on=i===cur;b.classList.toggle('done',i<cur);
    if(on){b.classList.remove('on');void b.offsetWidth;b.classList.add('on');b.setAttribute('aria-current','true')}else{b.classList.remove('on');b.removeAttribute('aria-current')}})}
  function show(to,dir,user){
    to=mod(to);if(to===cur)return;dir=dir||(to>cur?1:-1);
    var a=slides[cur],b=slides[to];prime(to);prime(to+dir);
    b.classList.add('no-tr');b.classList.remove('is-active');b.classList.toggle('to-left',dir<0);void b.offsetWidth;b.classList.remove('no-tr');
    a.classList.remove('is-active');a.classList.toggle('to-left',dir>0);
    b.classList.remove('to-left');b.classList.add('is-active');
    slides.forEach(function(s){var on=s===b;if(on)s.removeAttribute('aria-hidden');else s.setAttribute('aria-hidden','true');
      [].forEach.call(s.querySelectorAll('a'),function(l){if(on)l.removeAttribute('tabindex');else l.setAttribute('tabindex','-1')})});
    stage.setAttribute('aria-live',user?'polite':'off');cur=to;paint();
  }
  function go(dir){show(cur+dir,dir,true)}

  /* ---- controls ---- */
  bars.forEach(function(b){b.addEventListener('click',function(){var i=+b.getAttribute('data-i');show(i,i>cur?1:-1,true)})});
  var prev=root.querySelector('.hx-prev'),next=root.querySelector('.hx-next');
  if(prev)prev.addEventListener('click',function(){go(-1)});if(next)next.addEventListener('click',function(){go(1)});
  if(pp){if(auto)pp.hidden=false;pp.addEventListener('click',function(){userPaused=!userPaused;pp.classList.toggle('is-off',userPaused);
    pp.setAttribute('aria-label',userPaused?'Resume automatic rotation':'Pause automatic rotation');sync()})}
  root.addEventListener('keydown',function(e){if(e.target.closest&&e.target.closest('input,textarea,select'))return;
    if(e.key==='ArrowRight'){e.preventDefault();go(1)}else if(e.key==='ArrowLeft'){e.preventDefault();go(-1)}});
  root.addEventListener('animationend',function(e){if(e.animationName!=='hxfill'||!auto)return;var p=e.target.parentNode;if(p&&p.classList.contains('on'))show(cur+1,1,false)});

  /* ---- swipe / drag: the slide follows the finger, then snaps or moves on ---- */
  var sx=0,sy=0,dx=0,drag=false,lock=null,pid=null,moved=false;
  function end(commit){if(!drag)return;drag=false;root.classList.remove('dragging');root.style.removeProperty('--dx');root.style.removeProperty('--dp');touch=false;sync();
    if(commit&&Math.abs(dx)>Math.max(40,root.clientWidth*.12))show(cur+(dx<0?1:-1),dx<0?1:-1,true);dx=0}
  root.addEventListener('pointerdown',function(e){if(n<2||(e.pointerType==='mouse'&&e.button!==0)||(e.target.closest&&e.target.closest('.hx-ui')))return;
    sx=e.clientX;sy=e.clientY;dx=0;drag=true;lock=null;moved=false;pid=e.pointerId;touch=e.pointerType!=='mouse';sync();prime(cur+1);prime(cur-1)});
  root.addEventListener('pointermove',function(e){if(!drag||e.pointerId!==pid)return;var x=e.clientX-sx,y=e.clientY-sy;
    if(lock===null&&(Math.abs(x)>8||Math.abs(y)>8)){lock=Math.abs(x)>Math.abs(y)*1.2?'x':'y';if(lock==='x'){root.classList.add('dragging');try{root.setPointerCapture(pid)}catch(_){}}else end(false)}
    if(lock==='x'){dx=x;moved=true;if(!rm){root.style.setProperty('--dx',x+'px');root.style.setProperty('--dp',Math.min(1,Math.abs(x)/Math.max(1,root.clientWidth)).toFixed(3))}}});
  root.addEventListener('pointerup',function(e){if(e.pointerId===pid)end(lock==='x')});
  root.addEventListener('pointercancel',function(e){if(e.pointerId===pid)end(false)});
  root.addEventListener('click',function(e){if(moved){e.preventDefault();e.stopPropagation();moved=false}},true);

  /* ---- pause rules ---- */
  if(mq('(hover:hover)')){root.addEventListener('mouseenter',function(){hover=true;sync();prime(cur+1)});root.addEventListener('mouseleave',function(){hover=false;sync()})}
  root.addEventListener('focusin',function(e){var t=e.target;focus=!!(t.matches&&t.matches(':focus-visible'));sync();prime(cur+1)});
  root.addEventListener('focusout',function(e){if(!root.contains(e.relatedTarget)){focus=false;sync()}});
  document.addEventListener('visibilitychange',function(){hid=document.hidden;sync()});
  if('IntersectionObserver' in window)new IntersectionObserver(function(es){inView=es[0].isIntersecting;sync()},{threshold:.2}).observe(root);

  /* ---- go ---- */
  root.style.setProperty('--hxdur',ms+'ms');paint();sync();
  slides.forEach(function(s,i){if(i!==cur){s.setAttribute('aria-hidden','true');[].forEach.call(s.querySelectorAll('a'),function(l){l.setAttribute('tabindex','-1')})}});
  function warm(){if(!lean)setTimeout(function(){prime(cur+1)},1200)}
  if(document.readyState==='complete')warm();else window.addEventListener('load',warm);
})();
