/* Tutor affiliate page: select a link when it is clicked so it is easy to copy on a phone. */
(function(){[].forEach.call(document.querySelectorAll('.copy input[readonly]'),function(i){i.addEventListener('focus',function(){i.select()});i.addEventListener('click',function(){i.select()})})})();
