/* Admin > Appearance > Intro card icons: searchable Lucide picker with live preview. Vanilla JS, no dependencies.
   The icon list is a static JSON file; the chosen name is stored in a hidden field and saved by the normal form post. */
(function(){
  var root=document.getElementById('iiroot');if(!root)return;
  var panel=document.getElementById('ipicker'),grid=document.getElementById('iigrid'),box=document.getElementById('iisearch'),count=document.getElementById('iicount');
  var icons=[],active=null,shown=0;
  function svg(s){return '<svg class="ico" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'+s+'</svg>'}
  function label(n){return n?n.replace(/-/g,' '):'Default icon'}
  function row(el){return el.closest('.iirow')}
  function hidden(r){return r.querySelector('[data-icon]')}

  function paint(r){                                   // live preview + caption for one card
    var n=hidden(r).value,slot=r.querySelector('.iislot'),def=r.querySelector('.iidef'),found=null;
    for(var i=0;i<icons.length;i++)if(icons[i].n===n){found=icons[i];break}
    if(n&&found)slot.innerHTML='<span class="pico" aria-hidden="true">'+svg(found.s)+'</span>';
    else slot.innerHTML=def?def.innerHTML:'';
    r.querySelector('.iiname').textContent=label(n);
    r.querySelector('[data-default]').hidden=!n;
    mark();
  }
  function mark(){                                     // highlight the picked tile for the card being edited
    if(!active)return;var cur=hidden(active).value;
    [].forEach.call(grid.children,function(b){b.setAttribute('aria-pressed',b.getAttribute('data-n')===cur?'true':'false')});
  }
  function render(){
    var terms=box.value.toLowerCase().split(/\s+/).filter(Boolean);grid.innerHTML='';shown=0;var frag=document.createDocumentFragment();
    icons.forEach(function(ic){
      var hay=ic.n.replace(/-/g,' ')+' '+ic.k;for(var t=0;t<terms.length;t++)if(hay.indexOf(terms[t])<0)return;
      var b=document.createElement('button');b.type='button';b.className='itile';b.setAttribute('data-n',ic.n);b.setAttribute('aria-label',label(ic.n));b.title=label(ic.n);
      b.innerHTML=svg(ic.s)+'<span>'+label(ic.n)+'</span>';frag.appendChild(b);shown++;
    });
    grid.appendChild(frag);
    count.textContent=shown?shown+' icon'+(shown===1?'':'s')+(terms.length?' match':''):'No icons match "'+box.value+'". Try a simpler word such as "book" or "work".';
    mark();
  }
  function open(r){
    active=r;r.parentNode.insertBefore(panel,r.nextSibling);panel.hidden=false;
    [].forEach.call(root.querySelectorAll('[data-pick]'),function(b){b.setAttribute('aria-expanded',row(b)===r?'true':'false')});
    render();box.focus({preventScroll:true});if(panel.scrollIntoView)panel.scrollIntoView({block:'nearest',behavior:'smooth'});
  }
  function close(){
    if(active){var b=active.querySelector('[data-pick]');b.setAttribute('aria-expanded','false');b.focus({preventScroll:true})}
    panel.hidden=true;active=null;
  }
  function choose(n){if(!active)return;hidden(active).value=n;paint(active)}

  root.addEventListener('click',function(e){
    var p=e.target.closest('[data-pick]');if(p){var r=row(p);if(active===r&&!panel.hidden)close();else open(r);return}
    if(e.target.closest('[data-close]')){close();return}
    var d=e.target.closest('[data-default]');if(d){var r2=row(d);hidden(r2).value='';paint(r2);return}
    var t=e.target.closest('.itile');if(t)choose(t.getAttribute('data-n'));
  });
  box.addEventListener('input',render);
  box.addEventListener('keydown',function(e){if(e.key==='Enter')e.preventDefault()});          // Enter in the search box must not submit the form
  root.addEventListener('keydown',function(e){if(e.key==='Escape'&&!panel.hidden){e.preventDefault();close()}});
  fetch(root.getAttribute('data-src'),{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){
    icons=d.icons||[];[].forEach.call(root.querySelectorAll('.iirow'),paint);if(active)render();
  }).catch(function(){count.textContent='The icon library could not be loaded. Reload the page.'});
})();
