(function(){
  var b=document.querySelector('.menu-btn'),n=document.querySelector('nav.main');
  if(b&&n)b.addEventListener('click',function(){var o=n.classList.toggle('open');b.setAttribute('aria-expanded',o)});
  document.querySelectorAll('form[data-confirm]').forEach(function(f){f.addEventListener('submit',function(e){if(!confirm(f.getAttribute('data-confirm')))e.preventDefault()})});
  var csrf=document.querySelector('meta[name=csrf]');csrf=csrf&&csrf.content;
  var v=document.querySelector('video[data-lesson],[data-lesson-id]');
  if(v&&v.tagName==='VIDEO'){
    var id=v.getAttribute('data-lesson'),last=0;
    var start=parseInt(v.getAttribute('data-start')||'0',10);
    v.addEventListener('loadedmetadata',function(){if(start>5&&start<v.duration-5)v.currentTime=start});
    v.addEventListener('timeupdate',function(){var t=Math.floor(v.currentTime);if(t-last>=10){last=t;
      var d=new FormData();d.append('position',t);d.append('_csrf',csrf);fetch('/learn/lesson/'+id+'/progress',{method:'POST',body:d,credentials:'same-origin'}).catch(function(){})}});
  }
  document.querySelectorAll('[data-copy]').forEach(function(c){c.addEventListener('click',function(){var t=c.getAttribute('data-copy'),o=c.textContent;(navigator.clipboard?navigator.clipboard.writeText(t):Promise.reject()).then(function(){c.textContent='Copied';setTimeout(function(){c.textContent=o},2000)}).catch(function(){var i=c.parentNode.querySelector('input');if(i){i.focus();i.select()}})})});
  var sm=document.getElementById('sidemenu');
  if(sm&&window.matchMedia('(min-width:900px)').matches)sm.setAttribute('open','');
})();
