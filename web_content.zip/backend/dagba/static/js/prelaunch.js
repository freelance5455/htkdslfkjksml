/* Live countdown for the pre-launch page. Uses the SERVER's clock (data-now) so a wrong clock on the visitor's phone cannot show the wrong time.
   When it reaches zero the page reloads; the server then opens the site by itself (no admin action needed). */
(function(){
'use strict';
var box=document.querySelector('.pl-count');if(!box)return;
var launch=+box.getAttribute('data-launch'),skew=+box.getAttribute('data-now')-Date.now();
var nums={};[].forEach.call(box.querySelectorAll('.pl-num'),function(n){nums[n.getAttribute('data-u')]=n});
var live=box.querySelector('.pl-live'),done=false,timer;
function pad(n){return n<10?'0'+n:''+n}
function tick(){
  var left=launch-(Date.now()+skew);
  if(left<=0){
    if(!done){done=true;[].forEach.call(Object.keys(nums),function(k){nums[k].textContent='00'});
      if(live){live.textContent=box.getAttribute('data-live')||'';live.hidden=false}
      setTimeout(function(){location.replace('/')},1500)}
    clearInterval(timer);return}
  var s=Math.floor(left/1000);
  nums.d.textContent=Math.floor(s/86400);nums.h.textContent=pad(Math.floor(s%86400/3600));nums.m.textContent=pad(Math.floor(s%3600/60));nums.s.textContent=pad(s%60);
}
tick();timer=setInterval(tick,1000);
document.addEventListener('visibilitychange',function(){if(!document.hidden)tick()});
})();
