import hmac, secrets, time
from functools import wraps
from flask import session, request, g, abort, redirect, url_for, current_app, flash
from .db import q1, q, ex, val

PERMISSIONS = {
    "users.manage": "Manage students, instructors, writers and staff",
    "courses.manage": "Manage all courses, lessons, categories and assessments",
    "pricing.manage": "Manage prices, plans, discounts and promotions",
    "payments.manage": "Verify payments (approve / reject / request information)",
    "payments.refund": "Mark payments as refunded",
    "bank.manage": "Edit bank transfer details and payment methods/gateways",
    "content.manage": "Manage blog, nuggets, testimonials, FAQs and pages",
    "faith.manage": "Manage Faith & Spiritual Growth (topics, series, lessons, videos, audio and study materials)",
    "certificates.manage": "Manage and revoke certificates",
    "tutors.manage": "Review tutor applications and new courses, approve or reject them, manage tutors and suspend them",
    "prelaunch.manage": "Switch Pre-Launch Mode on or off, set the launch date and countdown page, and view early registrations",
    "paths.manage": "Create and manage learning paths and prerequisites across all courses",
    "discussions.manage": "Moderate lesson and course discussions across all courses",
    "mou.manage": "Write, publish and version the Tutor Memorandum of Understanding, and view every signed tutor agreement",
    "payouts.manage": "Review tutor withdrawal requests, pay them and upload receipts",
    "affiliates.manage": "Add / remove affiliates (influencers), set commission rates and pay their withdrawals",
    "reports.view": "View reports and export CSV",
    "settings.manage": "Edit website, branding, SEO and contact settings",
    "notifications.manage": "Send announcements",
    "audit.view": "View the audit log",
    "system.manage": "Download backups and exports",
}

def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_urlsafe(32)
    return session["_csrf"]

CSRF_EXEMPT = {"pay.webhook"}

def csrf_protect():
    if request.path.startswith("/api/v1/"): return       # the mobile API never accepts the cookie session (bearer tokens only), so cookie-based CSRF cannot apply
    if request.method in ("POST", "PUT", "PATCH", "DELETE") and request.endpoint not in CSRF_EXEMPT:
        sent = request.form.get("_csrf") or request.headers.get("X-CSRF-Token") or ""
        if not sent or not hmac.compare_digest(sent.encode("utf-8", "ignore"), session.get("_csrf", "").encode()):
            abort(400, "Security check failed (CSRF). Please go back, refresh the page and try again.")

def load_user():
    g.user = None; g.api_session = None
    if request.path.startswith("/api/v1/"):               # mobile API: Authorization: Bearer <access token> only; cookies are ignored
        h = request.headers.get("Authorization", "")
        if h[:7].lower() == "bearer ":
            from .services import mobile
            u, sid = mobile.authenticate(h[7:].strip())
            if u:
                g.user = u; g.api_session = sid
                g.perms = {r["permission"] for r in q("SELECT permission FROM user_permissions WHERE user_id=?", (u["id"],))}
        return
    uid = session.get("uid")
    if uid:
        u = q1("SELECT * FROM users WHERE id=?", (uid,))
        if u and u["is_active"]:
            g.user = u
            g.perms = {r["permission"] for r in q("SELECT permission FROM user_permissions WHERE user_id=?", (uid,))}
        else:
            session.clear()

def has_perm(perm, user=None):
    u = user or g.get("user")
    if not u or u["role"] != "admin": return False
    if u["is_owner"]: return True
    if user is not None and user is not g.get("user"):
        return bool(val("SELECT 1 FROM user_permissions WHERE user_id=? AND permission=?", (u["id"], perm)))
    return perm in g.get("perms", set())

def is_staff(user=None):
    u = user or g.get("user")
    return bool(u and u["role"] in ("admin", "instructor", "writer"))

def login_required(f):
    @wraps(f)
    def w(*a, **k):
        if not g.user:
            flash("Please log in to continue.", "info")
            return redirect(url_for("auth.login", next=request.full_path.rstrip("?")))
        return f(*a, **k)
    return w

def role_required(*roles):
    def deco(f):
        @wraps(f)
        @login_required
        def w(*a, **k):
            if g.user["role"] not in roles: abort(403)
            return f(*a, **k)
        return w
    return deco

def perm_required(perm):
    def deco(f):
        @wraps(f)
        @login_required
        def w(*a, **k):
            if not has_perm(perm): abort(403)
            return f(*a, **k)
        return w
    return deco

def client_ip():
    return request.remote_addr or "?"

def rate_limited(key, limit, window_s, record=True):
    """True if the caller already exceeded `limit` events in `window_s` seconds. Records the event."""
    if not current_app.config.get("RATE_LIMITS_ENABLED", True): return False
    t = int(time.time())
    q1("DELETE FROM rate_events WHERE ts < ?", (t - 86400,))
    n = val("SELECT COUNT(*) FROM rate_events WHERE key=? AND ts>?", (key, t - window_s), 0)
    if n >= limit: return True
    if record: ex("INSERT INTO rate_events(key, ts) VALUES (?,?)", (key, t))
    return False

def security_headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    resp.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    resp.headers.setdefault("Content-Security-Policy",
        "default-src 'self'; img-src 'self' data:; media-src 'self' https:; "
        "frame-src https://www.youtube-nocookie.com https://player.vimeo.com; "
        "style-src 'self'; script-src 'self'; form-action 'self' https://checkout.paystack.com https://checkout.flutterwave.com; "
        "base-uri 'self'; object-src 'none'; frame-ancestors 'none'")
    if current_app.config.get("SESSION_COOKIE_SECURE"):
        resp.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    if request.endpoint and (request.path.startswith(("/student", "/staff", "/learn", "/pay", "/account", "/login", "/register", "/notifications", "/affiliate", "/r/", "/faith/my", "/tutor/", "/api/"))):
        resp.headers["Cache-Control"] = "no-store"
    return resp
