import re, html, secrets, datetime as dt
from urllib.parse import urlparse, parse_qs
from markupsafe import Markup, escape
from .db import val

def _utc(): return dt.datetime.now(dt.timezone.utc).replace(tzinfo=None)
def now(): return _utc().strftime("%Y-%m-%d %H:%M:%S")
def now_dt(): return _utc().replace(microsecond=0)
def add_days(base, days): return (base + dt.timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
def parse_ts(s):
    if not s: return None
    for f in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M", "%Y-%m-%d"):
        try: return dt.datetime.strptime(s, f)
        except ValueError: pass
    return None

def slugify(s):
    s = re.sub(r"[^a-z0-9]+", "-", (s or "").lower()).strip("-")
    return s or "item"

def unique_slug(table, text, exclude_id=None):
    base = slugify(text)[:80]; slug = base; n = 2
    while val(f"SELECT 1 FROM {table} WHERE slug=? AND id IS NOT ?", (slug, exclude_id)):
        slug = f"{base}-{n}"; n += 1
    return slug

def naira(kobo):
    kobo = int(kobo or 0)
    return "\u20a6{:,.2f}".format(kobo / 100).replace(".00", "")

def parse_naira(s):
    s = (s or "").replace(",", "").replace("\u20a6", "").strip()
    if not s: return 0
    try: k = round(float(s) * 100)
    except ValueError: raise ValueError("Enter a valid amount.")
    if k < 0: raise ValueError("Amount cannot be negative.")
    return k

def new_reference():
    return "DDA-" + "".join(secrets.choice("ABCDEFGHJKLMNPQRSTUVWXYZ23456789") for _ in range(10))

def render_text(s):
    """Safe lightweight formatting: HTML is escaped first; supports ## headings, **bold**, - lists, paragraphs, links."""
    out, in_list = [], False
    for block in re.split(r"\n{2,}", html.unescape(str(s or "")).strip()):
        lines = block.split("\n"); parts = []
        for ln in lines:
            e = str(escape(ln))
            e = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", e)
            e = re.sub(r"(https?://[^\s<]+)", r'<a href="\1" rel="noopener nofollow">\1</a>', e)
            parts.append(e)
        if all(p.lstrip().startswith("- ") for p in parts):
            out.append("<ul>" + "".join(f"<li>{p.lstrip()[2:]}</li>" for p in parts) + "</ul>")
        elif parts[0].startswith("## "):
            out.append(f"<h3>{parts[0][3:]}</h3>")
            if len(parts) > 1: out.append("<p>" + "<br>".join(parts[1:]) + "</p>")
        elif parts[0].startswith("# "):
            out.append(f"<h2>{parts[0][2:]}</h2>")
            if len(parts) > 1: out.append("<p>" + "<br>".join(parts[1:]) + "</p>")
        else:
            out.append("<p>" + "<br>".join(parts) + "</p>")
    return Markup("".join(out))

def embed_url(url):
    """Return ('iframe'|'video'|None, safe_url). Only https and known hosts are embedded."""
    u = (url or "").strip()
    p = urlparse(u)
    if p.scheme != "https": return None, ""
    host = (p.hostname or "").lower()
    if host in ("www.youtube.com", "youtube.com", "m.youtube.com"):
        vid = parse_qs(p.query).get("v", [""])[0]
        if re.fullmatch(r"[\w-]{6,15}", vid): return "iframe", f"https://www.youtube-nocookie.com/embed/{vid}"
    if host == "youtu.be":
        vid = p.path.strip("/")
        if re.fullmatch(r"[\w-]{6,15}", vid): return "iframe", f"https://www.youtube-nocookie.com/embed/{vid}"
    if host in ("vimeo.com", "www.vimeo.com"):
        vid = p.path.strip("/").split("/")[0]
        if vid.isdigit(): return "iframe", f"https://player.vimeo.com/video/{vid}"
    if host == "player.vimeo.com": return "iframe", u
    if re.search(r"\.(mp4|webm|ogg)$", p.path, re.I): return "video", u
    return None, ""


DIVISIONS = {"academic": "Academic", "income": "Income Skills", "professional": "Professional Development", "faith": "Faith & Spiritual Growth"}
def division_label(d): return DIVISIONS.get(d, (d or "").title())
