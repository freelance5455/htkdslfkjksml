"""Clearly-labelled demonstration content for development/QA only. Not loaded in production."""
from werkzeug.security import generate_password_hash
from .db import ex, val, q1
from .seed import seed_structure
from .util import now

def seed_demo():
    seed_structure()
    def user(email, name, role):
        r = q1("SELECT id FROM users WHERE email=?", (email,))
        return r["id"] if r else ex("INSERT INTO users(email,password_hash,full_name,role) VALUES (?,?,?,?)", (email, generate_password_hash("Demo12345"), name, role))
    inst = user("instructor@demo.test", "[DEMO] Instructor", "instructor"); user("writer@demo.test", "[DEMO] Writer", "writer"); user("student@demo.test", "[DEMO] Student", "student")
    cat = lambda slug: val("SELECT id FROM categories WHERE slug=?", (slug,))
    if val("SELECT 1 FROM courses WHERE slug='demo-algebra-basics'"): return
    c1 = ex("INSERT INTO courses(division,academic_level,category_id,title,slug,summary,description,price_kobo,status,instructor_id) VALUES ('academic','basic',?,?,?,?,?,?,'published',?)",
            (cat("academic-mathematics"), "[DEMO] Algebra Basics", "demo-algebra-basics", "Demo course for testing.", "Demonstration content only.", 500000, inst))
    c2 = ex("INSERT INTO courses(division,category_id,title,slug,summary,description,level,price_kobo,status,instructor_id) VALUES ('income',?,?,?,?,?,?,?,'published',?)",
            (cat("income-digital-marketing"), "[DEMO] Digital Marketing Starter", "demo-digital-marketing", "Demo course for testing.", "Demonstration content only.", "Beginner", 1000000, inst))
    c3 = ex("INSERT INTO courses(division,academic_level,category_id,title,slug,summary,level,price_kobo,status,instructor_id) VALUES ('academic','basic',?,?,?,?,?,0,'published',?)", (cat("academic-other-secondary-school-subjects"), "[DEMO] Free Study Skills", "demo-free-study-skills", "A free demo course.", "All", inst))
    for c in (c1, c2, c3):
        m = ex("INSERT INTO modules(course_id,title,position) VALUES (?,?,1)", (c, "Getting started"))
        ex("INSERT INTO lessons(course_id,module_id,title,kind,body,position,free_preview) VALUES (?,?,?,?,?,1,1)", (c, m, "Welcome", "text", "## Welcome\nThis is demonstration content.", ))
        ex("INSERT INTO lessons(course_id,module_id,title,kind,body,position) VALUES (?,?,?,?,?,2)", (c, m, "Lesson two", "text", "More **demo** content."))
        z = ex("INSERT INTO quizzes(course_id,title,pass_mark) VALUES (?,?,50)", (c, "Check your understanding"))
        ex("INSERT INTO questions(quiz_id,course_id,prompt,options,correct,explanation) VALUES (?,?,?,?,?,?)", (z, c, "What is 2 + 2?", "3\n4\n5", 2, "Two plus two is four."))
        ex("INSERT INTO assignments(course_id,title,instructions) VALUES (?,?,?)", (c, "Short reflection", "Write two sentences about what you learned."))
    ex("UPDATE plans SET price_kobo=1500000, active=1 WHERE division='academic' AND level='basic'"); ex("UPDATE plans SET price_kobo=2500000, active=1 WHERE division='academic' AND level='advanced'"); ex("UPDATE plans SET price_kobo=3000000, active=1 WHERE division='income'")
    ex("UPDATE settings SET value=value WHERE 0"); 
    from .services import settings as S
    S.put("bank.name", "[DEMO] Example Bank"); S.put("bank.account_name", "[DEMO] Dagba Digital Academy"); S.put("bank.account_number", "0123456789")
    # Faith & Spiritual Growth: clearly labelled sample lessons (no uploaded media) so the section can be tried out. Delete them from Faith: Lessons.
    def topic(slug): return val("SELECT id FROM faith_topics WHERE slug=?", (slug,))
    fs = ex("INSERT INTO faith_series(topic_id,title,slug,summary,status,featured,price_kobo) VALUES (?,?,?,?,'published',1,500000)", (topic("prayer"), "[DEMO] Learning to Pray", "demo-learning-to-pray", "A short sample series to show how ordered lessons look."))
    for n, (t, k, body, scr) in enumerate((("[DEMO] Why we pray", "reading", "## Why pray?\nSample reading text. Replace with your own lesson.", "Luke 11:1-4"),
                                           ("[DEMO] A daily habit of prayer", "reading", "## Building a habit\nSample reading text.\n\n- Choose a time\n- Choose a place", "Mark 1:35"),
                                           ("[DEMO] Praying the Psalms", "study", "## Study guide\nSample study guide text. Attach a PDF in the lesson editor.", "Psalm 23"))):
        ex("INSERT INTO faith_items(topic_id,series_id,title,slug,kind,summary,body,scripture,position,status,published_at,duration_min,access) VALUES (?,?,?,?,?,?,?,?,?,'published',datetime('now'),?,?)",
           (topic("prayer"), fs, t, "demo-faith-" + str(n + 1), k, "Demonstration content only.", body, scr, n + 1, 5 + n, "public" if n == 0 else "members"))   # first lesson is the free preview, the rest need the (demo) purchase
