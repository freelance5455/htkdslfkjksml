import os

def _load_dotenv():
    """Minimal .env loader (no extra dependency). Real environment variables always win."""
    p = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env")
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            line = line.split("  #")[0].strip() if "  #" in line else line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1); os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))

_load_dotenv()

def _b(name, default=False):
    v = os.environ.get(name)
    return default if v is None else v.lower() in ("1", "true", "yes", "on")

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY") or None
    DATABASE = os.environ.get("DATABASE_PATH", os.path.join(os.path.dirname(os.path.dirname(__file__)), "instance", "dagba.db"))
    PRIVATE_DIR = os.environ.get("PRIVATE_UPLOAD_DIR", os.path.join(os.path.dirname(os.path.dirname(__file__)), "instance", "private"))
    PUBLIC_DIR = os.environ.get("PUBLIC_UPLOAD_DIR", os.path.join(os.path.dirname(os.path.dirname(__file__)), "instance", "public"))
    SITE_URL = os.environ.get("SITE_URL", "http://localhost:5000").rstrip("/")
    SESSION_COOKIE_SECURE = _b("COOKIE_SECURE", False)
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 24 * 14
    MAX_FORM_MEMORY_SIZE = 4 * 1024 * 1024      # long blog posts / lesson text (Flask's default would cap text at 500 KB)
    MAX_CONTENT_LENGTH = int(os.environ.get("MAX_UPLOAD_MB", "25")) * 1024 * 1024
    SMTP_HOST = os.environ.get("SMTP_HOST", "")
    SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
    SMTP_USER = os.environ.get("SMTP_USER", "")
    SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD", "")
    SMTP_FROM = os.environ.get("SMTP_FROM", "")
    RATE_LIMITS_ENABLED = True
    TESTING = False
