"""Structural seed data (categories, legal-page templates, FAQs). Contains NO fake testimonials, courses or statistics."""
from .db import ex, val
from .util import slugify

ACADEMIC = ["Mathematics", "English Language", "Physics", "Chemistry", "Biology", "Economics", "Government", "Literature in English", "Agricultural Science", "Civic Education", "Further Mathematics", "Other Secondary School Subjects"]
ADVANCED = ["Mathematics", "Physics", "Chemistry", "Biology", "Economics", "Accounting", "Computer Science", "Statistics", "Engineering", "Business Administration", "Political Science", "Law", "Other University Subjects"]
INCOME = ["Digital Marketing", "Copywriting", "Graphic Design", "Web Development", "Software Development", "Artificial Intelligence", "Video Editing", "E-commerce", "Freelancing", "Business Development", "Personal Finance", "Trading Education", "Entrepreneurship", "Other Practical Skills"]

PAGES = {
 "about": ("About Dagba Digital Academy", "## Who we are\nDagba Digital Academy simplifies complex knowledge and makes learning accessible and practical.\n\n## Our philosophy\nWe make knowledge desirable.\n\n## Our mission\nTo simplify complex knowledge, make learning accessible and practical, and equip learners with academic knowledge and real-world skills.\n\n## How we fit with school\nWe complement traditional education rather than replacing schools. Our academic courses are organised into Basic (secondary school), Advanced (university level) and, soon, Professional Development programmes, while our income skills courses prepare learners for the real world."),
 "privacy-policy": ("Privacy Policy", "TEMPLATE - have this reviewed by a qualified professional before launch.\n\n## Information we collect\nWe collect the details you give us when you register (name, email, phone, class level), your learning progress, and payment information you submit for verification (such as transfer receipts).\n\n## How we use it\nTo provide courses, verify payments, issue certificates and communicate with you about your account.\n\n## Payment evidence\nReceipts you upload are stored privately and are visible only to authorised academy staff and to you.\n\n## We never ask for banking passwords, PINs, OTPs or card details.\n\n## Your choices\nContact us to correct or delete your account data."),
 "terms-and-conditions": ("Terms and Conditions", "TEMPLATE - have this reviewed by a qualified professional before launch.\n\n## Accounts\nYou are responsible for keeping your login secure and for the accuracy of the information you provide.\n\n## Courses and access\nAccess to a course depends on how it was acquired: an individual purchase follows that course's stated access period; subscriptions give access to eligible courses in their category while active.\n\n## Payments\nPayments by bank transfer are confirmed manually. Access is activated only after our team confirms receipt of funds.\n\n## Acceptable use\nDo not share your account or redistribute course materials."),
 "refund-policy": ("Refund Policy", "TEMPLATE - set your own refund terms and have them reviewed before launch.\n\n## Requests\nContact us with your transaction reference to request a refund.\n\n## Review\nRequests are reviewed individually. Approved refunds end access to the related course or subscription."),
}
FAQS = [("How do I pay for a course?", "Choose a course or plan, select Pay, and follow the bank transfer instructions shown with your unique reference. After paying, upload your receipt. Access is activated once our team confirms your payment."),
        ("How long does payment verification take?", "A team member checks that the money has arrived in our account, then approves your payment. You will receive a notification when it is done."),
        ("Do the Basic, Advanced and Income Skills subscriptions overlap?", "No. They are separate. You can buy any or all of them, and one expiring never affects the other."),
        ("What happens to my course when a subscription ends?", "Courses you bought individually stay yours according to their access period. Only subscription-based access ends."),
        ("Can I use Dagba on my phone?", "Yes. The academy is designed to work well on ordinary Android phones and low-bandwidth connections.")]

def seed_structure():
    for i, n in enumerate(ACADEMIC):
        if not val("SELECT 1 FROM categories WHERE slug=?", ("academic-" + slugify(n),)): ex("INSERT INTO categories(division,level,name,slug,position) VALUES ('academic','basic',?,?,?)", (n, "academic-" + slugify(n), i))
    for i, n in enumerate(ADVANCED):
        if not val("SELECT 1 FROM categories WHERE slug=?", ("advanced-" + slugify(n),)): ex("INSERT INTO categories(division,level,name,slug,position) VALUES ('academic','advanced',?,?,?)", (n, "advanced-" + slugify(n), i))
    for i, n in enumerate(INCOME):
        if not val("SELECT 1 FROM categories WHERE slug=?", ("income-" + slugify(n),)): ex("INSERT INTO categories(division,name,slug,position) VALUES ('income',?,?,?)", (n, "income-" + slugify(n), i))
    for slug, (t, b) in PAGES.items():
        if not val("SELECT 1 FROM pages WHERE slug=?", (slug,)): ex("INSERT INTO pages(slug,title,body) VALUES (?,?,?)", (slug, t, b))
    if not val("SELECT 1 FROM faqs"):
        for i, (qq, a) in enumerate(FAQS): ex("INSERT INTO faqs(question,answer,position) VALUES (?,?,?)", (qq, a, i))
    if not val("SELECT 1 FROM plans WHERE division='academic' AND COALESCE(level,'basic')='basic'"):
        ex("INSERT INTO plans(name,division,level,description,price_kobo,duration_days,active,position) VALUES ('Basic Subscription','academic','basic','Access to all eligible Basic (secondary school) courses.',0,30,0,1)")
    if not val("SELECT 1 FROM plans WHERE division='income'"):
        ex("INSERT INTO plans(name,division,description,price_kobo,duration_days,active,position) VALUES ('Income Skills Subscription','income','Access to all eligible income skills courses.',0,30,0,3)")
    for n in ("Study Tips", "Careers & Skills", "Money & Business", "Announcements"):
        if not val("SELECT 1 FROM article_categories WHERE slug=?", (slugify(n),)): ex("INSERT INTO article_categories(name,slug) VALUES (?,?)", (n, slugify(n)))
