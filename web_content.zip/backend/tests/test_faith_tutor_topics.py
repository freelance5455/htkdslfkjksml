"""Faith tutor topic assignment: admin assigns/revokes topics, assigned tutors write lessons in those topics only,
everything goes through submit -> admin approval -> publish, and tutors keep all existing permissions."""
from .base import *
from .test_builder import jpost
from .test_faith import FaithBase
from dagba.services import faith as F

class TutorTopicBase(FaithBase):
    def setUp(self):
        super().setUp()
        self.inst = self.client("inst"); self.iid = self.users["inst"]
        self.mk("inst2", "instructor"); self.inst2 = self.client("inst2"); self.i2 = self.users["inst2"]
        tid = lambda slug: self.val("SELECT id FROM faith_topics WHERE slug=?", (slug,))
        self.prayer, self.bible, self.growth = tid("prayer"), tid("bible-studies"), tid("spiritual-growth")
        self.mine = dbm.ex("INSERT INTO faith_series(topic_id,title,slug,status,price_kobo,instructor_id) VALUES (?,?,?,?,?,?)", (self.growth, "Mine", "mine", "published", 0, self.iid))
        self.theirs = dbm.ex("INSERT INTO faith_series(topic_id,title,slug,status,price_kobo) VALUES (?,?,?,?,?)", (self.prayer, "Theirs", "theirs", "published", 0))
    def assign(self, uid, *topics, c=None):
        return self.post(c or self.owner, f"/staff/faith/tutors/{uid}", {"topic": [str(t) for t in topics]})
    def lesson(self, c=None, topic=None, series=None, **kw):
        d = dict(title="Tutor lesson", topic_id=topic or self.prayer, series_id=series, kind="reading", body="Some text", access="members", status="published", featured=True); d.update(kw)
        return jpost(c or self.inst, self, "/staff/faith/save", d)
    def assigned(self, uid): return F.tutor_topic_ids(uid)

class AssignmentAdminTests(TutorTopicBase):
    def test_admin_sees_tutors_and_their_topics(self):
        self.assign(self.iid, self.prayer, self.bible)
        t = self.owner.get("/staff/faith/tutors").data.decode()
        self.assertEqual(self.owner.get("/staff/faith/tutors").status_code, 200)
        self.assertIn("inst", t.lower()); self.assertIn("Prayer", t); self.assertIn("Bible Studies", t)
        self.assertEqual(self.owner.get(f"/staff/faith/tutors/{self.iid}").status_code, 200)
        self.assertIn('href="/staff/faith/tutors"', self.owner.get("/staff/faith/").data.decode())
    def test_assign_one_tutor_several_topics_then_change_and_revoke(self):
        r = self.assign(self.iid, self.prayer, self.bible); self.assertEqual(r.status_code, 302)
        self.assertEqual(self.assigned(self.iid), {self.prayer, self.bible})
        self.assign(self.iid, self.bible, self.growth); self.assertEqual(self.assigned(self.iid), {self.bible, self.growth})      # add + revoke in one save
        self.assign(self.iid); self.assertEqual(self.assigned(self.iid), set())                                                  # revoke everything
        acts = [r["action"] for r in dbm.q("SELECT action FROM audit_logs WHERE entity='faith_topic_tutors'")]
        self.assertIn("faith.assign", acts); self.assertIn("faith.revoke", acts)
        self.assertTrue(self.val("SELECT 1 FROM notifications WHERE user_id=? AND title='Faith topics assigned to you'", (self.iid,)))
        self.assertTrue(self.val("SELECT 1 FROM notifications WHERE user_id=? AND title='Faith topic access removed'", (self.iid,)))
    def test_assign_one_topic_to_several_tutors(self):
        r = self.post(self.owner, f"/staff/faith/tutors/topic/{self.prayer}", {"tutor": [str(self.iid), str(self.i2)]}); self.assertEqual(r.status_code, 302)
        self.assertEqual(self.assigned(self.iid), {self.prayer}); self.assertEqual(self.assigned(self.i2), {self.prayer})
        self.post(self.owner, f"/staff/faith/tutors/topic/{self.prayer}", {"tutor": [str(self.i2)]}); self.assertEqual(self.assigned(self.iid), set()); self.assertEqual(self.assigned(self.i2), {self.prayer})
        self.assertEqual(self.owner.get(f"/staff/faith/tutors/topic/{self.prayer}").status_code, 200)
    def test_assigning_twice_is_harmless_and_junk_is_ignored(self):
        self.assign(self.iid, self.prayer); self.assign(self.iid, self.prayer, 99999, "x")
        self.assertEqual(self.val("SELECT COUNT(*) FROM faith_topic_tutors WHERE user_id=?", (self.iid,)), 1)
        self.assertEqual(self.post(self.owner, f"/staff/faith/tutors/{self.users['alice']}", {"topic": [str(self.prayer)]}).status_code, 404)   # students cannot be assigned
    def test_only_faith_managers_can_assign(self):
        for c in (self.inst, self.client("officer"), self.client("alice"), self.app.test_client()):
            self.assertIn(c.get("/staff/faith/tutors").status_code, (302, 403))
            self.assertIn(self.post(c, f"/staff/faith/tutors/{self.iid}", {"topic": [str(self.prayer)]}).status_code, (302, 403))
        self.assertEqual(self.assigned(self.iid), set())
        self.assertEqual(self.assign(self.iid, self.prayer, c=self.client("faither")).status_code, 302); self.assertEqual(self.assigned(self.iid), {self.prayer})

class TutorLessonTests(TutorTopicBase):
    def test_tutor_without_assignment_cannot_create_in_topic_but_keeps_own_series(self):
        self.assertEqual(self.lesson(topic=self.prayer).status_code, 400)
        self.assertEqual(self.lesson(topic=self.growth, series=self.mine).status_code, 200)              # existing own-series right unchanged
        self.assertEqual(self.lesson(topic=self.growth).status_code, 400)                                # a topic alone needs an assignment
    def test_assigned_tutor_creates_lesson_in_assigned_topic_only(self):
        self.assign(self.iid, self.prayer)
        j = self.lesson(topic=self.prayer).get_json(); self.assertTrue(j["ok"], j)
        row = self.row("SELECT * FROM faith_items WHERE id=?", (j["id"],)); self.assertEqual((row["status"], row["featured"], row["created_by"], row["topic_id"]), ("draft", 0, self.iid, self.prayer))
        self.assertEqual(self.lesson(topic=self.bible).status_code, 400)                                 # not assigned
        self.assertEqual(self.lesson(topic=self.prayer, series=self.theirs).status_code, 400)            # someone else's series is still off limits
        self.assertEqual(self.lesson(topic=self.bible, series=self.mine).status_code, 400)               # own series must match its topic as before
        self.assertEqual(self.val("SELECT COUNT(*) FROM faith_items"), 1)
    def test_tutor_editor_offers_only_assigned_and_own_topics(self):
        self.assign(self.iid, self.prayer)
        t = self.inst.get("/staff/faith/lesson/new").data.decode()
        self.assertIn(">Prayer<", t); self.assertIn(">Spiritual Growth<", t)                              # assigned + topic of own series
        self.assertNotIn(">Bible Studies<", t); self.assertNotIn(">Relationships<", t)
        self.assertIn("Prayer", self.inst.get("/staff/faith/lessons").data.decode())
    def test_cannot_edit_other_tutors_lessons_even_in_a_shared_topic(self):
        self.assign(self.iid, self.prayer); self.assign(self.i2, self.prayer)
        i = self.lesson().get_json()["id"]
        self.assertEqual(self.inst2.get(f"/staff/faith/lesson/{i}").status_code, 403)
        self.assertEqual(self.lesson(c=self.inst2, id=i).status_code, 403)
        self.assertEqual(self.post(self.inst2, f"/staff/faith/lesson/{i}/submit").status_code, 403)
        self.assertEqual(self.post(self.inst2, f"/staff/faith/lesson/{i}/delete").status_code, 403)
        self.assertEqual(self.inst2.get("/staff/faith/lessons").data.decode().count("Tutor lesson"), 0)
    def test_tutor_cannot_move_lesson_into_unassigned_topic_or_publish(self):
        self.assign(self.iid, self.prayer); i = self.lesson().get_json()["id"]
        self.assertEqual(self.lesson(id=i, topic=self.bible).status_code, 400)
        self.assertEqual(self.post(self.inst, f"/staff/faith/lesson/{i}/status", {"status": "published"}).status_code, 403)
        self.assertEqual(self.row("SELECT status FROM faith_items WHERE id=?", (i,))["status"], "draft")

class ApprovalWorkflowTests(TutorTopicBase):
    def setUp(self):
        super().setUp(); self.assign(self.iid, self.prayer)
        self.i = self.lesson().get_json()["id"]; self.slug = self.val("SELECT slug FROM faith_items WHERE id=?", (self.i,))
        self.pub = lambda: self.app.test_client().get("/faith/lesson/" + self.slug).status_code
    def r(self): return self.row("SELECT * FROM faith_items WHERE id=?", (self.i,))
    def test_full_flow_create_submit_approve_publish(self):
        self.assertEqual(self.pub(), 404); self.assertIsNone(self.r()["submitted_at"])
        self.assertEqual(self.post(self.inst, f"/staff/faith/lesson/{self.i}/submit").status_code, 302)
        r = self.r(); self.assertTrue(r["submitted_at"]); self.assertEqual(r["status"], "draft")
        self.assertEqual(self.pub(), 404)                                                                 # submitting never publishes
        self.assertTrue(self.val("SELECT 1 FROM notifications WHERE title='Faith lesson awaiting review'"))
        self.assertIn("awaiting review", self.owner.get("/staff/faith/lessons?status=pending").data.decode().lower())
        self.assertIn("Tutor lesson", self.owner.get("/staff/faith/lessons?status=pending").data.decode())
        self.assertEqual(self.post(self.owner, f"/staff/faith/lesson/{self.i}/status", {"status": "published"}).status_code, 302)
        r = self.r(); self.assertEqual(r["status"], "published"); self.assertIsNone(r["submitted_at"]); self.assertTrue(r["published_at"])
        self.assertEqual(self.pub(), 200)
        self.assertTrue(self.val("SELECT 1 FROM notifications WHERE user_id=? AND title='Your Faith lesson was approved'", (self.iid,)))
        self.assertIn("No lessons found", self.owner.get("/staff/faith/lessons?status=pending").data.decode())      # queue is empty again
        self.assertEqual(F.pending_count(), 0)
    def test_approval_by_saving_status_in_editor_also_closes_review(self):
        self.post(self.inst, f"/staff/faith/lesson/{self.i}/submit")
        j = jpost(self.owner, self, "/staff/faith/save", dict(id=self.i, title="Tutor lesson", topic_id=self.prayer, kind="reading", body="Some text", access="members", status="published")).get_json(); self.assertTrue(j["ok"], j)
        self.assertEqual((self.r()["status"], self.r()["submitted_at"]), ("published", None)); self.assertEqual(self.pub(), 200)
    def test_cannot_submit_empty_lesson_or_twice_or_when_published(self):
        j = self.lesson(body="", title="Empty").get_json(); e = j["id"]
        self.post(self.inst, f"/staff/faith/lesson/{e}/submit"); self.assertIsNone(self.row("SELECT submitted_at FROM faith_items WHERE id=?", (e,))["submitted_at"])
        self.post(self.inst, f"/staff/faith/lesson/{self.i}/submit"); first = self.r()["submitted_at"]
        self.post(self.inst, f"/staff/faith/lesson/{self.i}/submit"); self.assertEqual(self.r()["submitted_at"], first)
        self.post(self.owner, f"/staff/faith/lesson/{self.i}/status", {"status": "published"})
        self.post(self.inst, f"/staff/faith/lesson/{self.i}/submit"); self.assertIsNone(self.r()["submitted_at"])
    def test_tutor_cannot_edit_while_awaiting_review_but_can_withdraw(self):
        self.post(self.inst, f"/staff/faith/lesson/{self.i}/submit")
        self.assertEqual(self.lesson(id=self.i, title="Sneaky change").status_code, 409)
        self.assertEqual(self.r()["title"], "Tutor lesson")
        self.assertEqual(self.post(self.inst, f"/staff/faith/lesson/{self.i}/delete").status_code, 403)
        self.post(self.inst, f"/staff/faith/lesson/{self.i}/withdraw"); self.assertIsNone(self.r()["submitted_at"])
        self.assertEqual(self.lesson(id=self.i, title="Changed").status_code, 200); self.assertEqual(self.r()["title"], "Changed")
    def test_admin_can_return_lesson_with_note(self):
        self.post(self.inst, f"/staff/faith/lesson/{self.i}/submit")
        self.assertEqual(self.post(self.inst, f"/staff/faith/lesson/{self.i}/return", {"note": "x"}).status_code, 403)            # tutors cannot approve/return
        self.post(self.owner, f"/staff/faith/lesson/{self.i}/return", {"note": "Please add the scripture reference."})
        r = self.r(); self.assertEqual((r["status"], r["submitted_at"], r["review_note"]), ("draft", None, "Please add the scripture reference."))
        self.assertTrue(self.val("SELECT 1 FROM notifications WHERE user_id=? AND title='Faith lesson returned for changes'", (self.iid,)))
        self.assertIn("Please add the scripture reference.", self.inst.get(f"/staff/faith/lesson/{self.i}").data.decode())
        self.post(self.inst, f"/staff/faith/lesson/{self.i}/submit"); self.assertTrue(self.r()["submitted_at"])                   # resubmit
    def test_existing_own_series_lessons_use_the_same_review_flow(self):
        j = self.lesson(topic=self.growth, series=self.mine, title="Series lesson").get_json(); n = j["id"]
        self.assertEqual(self.post(self.inst, f"/staff/faith/lesson/{n}/submit").status_code, 302)
        self.assertTrue(self.row("SELECT submitted_at FROM faith_items WHERE id=?", (n,))["submitted_at"])
        self.assertEqual(F.pending_count(), 1)
        self.post(self.inst, f"/staff/faith/lesson/{self.i}/submit"); self.assertEqual(F.pending_count(), 2)           # both count toward the admin's review queue
        self.assertIn("Items awaiting review", self.owner.get("/staff/").data.decode())

class RevocationAndPermissionTests(TutorTopicBase):
    def test_revoking_blocks_new_lessons_but_keeps_all_content(self):
        self.assign(self.iid, self.prayer)
        pub = self.lesson(title="Published one").get_json()["id"]; self.post(self.owner, f"/staff/faith/lesson/{pub}/status", {"status": "published"})
        draft = self.lesson(title="Draft one").get_json()["id"]; sub = self.lesson(title="Submitted one").get_json()["id"]; self.post(self.inst, f"/staff/faith/lesson/{sub}/submit")
        before = self.val("SELECT COUNT(*) FROM faith_items")
        self.assign(self.iid)                                                                              # revoke
        self.assertEqual(self.lesson(title="New after revoke").status_code, 400)                          # no new lessons
        self.assertEqual(self.val("SELECT COUNT(*) FROM faith_items"), before)                            # nothing deleted
        self.assertEqual(self.val("SELECT COUNT(*) FROM faith_items WHERE created_by=?", (self.iid,)), 3)
        slug = self.val("SELECT slug FROM faith_items WHERE id=?", (pub,))
        self.assertEqual(self.app.test_client().get("/faith/lesson/" + slug).status_code, 200)            # published lesson stays public
        for i in (pub, draft, sub): self.assertEqual(self.inst.get(f"/staff/faith/lesson/{i}").status_code, 403)   # and the revoked tutor can no longer open them
        self.assertEqual(self.post(self.inst, f"/staff/faith/lesson/{draft}/submit").status_code, 403)
        self.assertTrue(self.row("SELECT submitted_at FROM faith_items WHERE id=?", (sub,))["submitted_at"])       # pending one is still in the admin's queue
        self.assertEqual(self.post(self.owner, f"/staff/faith/lesson/{sub}/status", {"status": "published"}).status_code, 302)   # admin can still approve it
        self.assign(self.iid, self.prayer); self.assertEqual(self.inst.get(f"/staff/faith/lesson/{draft}").status_code, 200)       # re-assigning restores access
    def test_revoking_one_topic_leaves_other_assignments(self):
        self.assign(self.iid, self.prayer, self.bible); self.assign(self.iid, self.bible)
        self.assertEqual(self.lesson(topic=self.prayer).status_code, 400); self.assertEqual(self.lesson(topic=self.bible).status_code, 200)
    def test_assignment_never_replaces_existing_tutor_permissions(self):
        pages = ("/staff/", "/staff/faith/lessons", "/staff/r/courses", "/staff/r/faith-series", "/staff/payouts/earnings", "/staff/faith/lesson/new")
        before = {p: self.inst.get(p).status_code for p in pages}
        for p in ("/staff/faith/tutors", "/staff/r/faith-topics", "/staff/users"): self.assertIn(self.inst.get(p).status_code, (302, 403))
        self.assign(self.iid, self.prayer)
        self.assertEqual({p: self.inst.get(p).status_code for p in pages}, before)                        # assigning changed nothing else
        self.assign(self.iid)
        self.assertEqual({p: self.inst.get(p).status_code for p in pages}, before)                        # nor did revoking
        self.assertEqual(self.lesson(topic=self.growth, series=self.mine).status_code, 200)               # own-series lessons work with no assignment at all
        self.assertIn("Paid Maths", self.inst.get("/staff/r/courses").data.decode())                       # their courses are still theirs
        self.assertEqual(self.val("SELECT instructor_id FROM courses WHERE id=?", (self.paid,)), self.iid)
        self.assertEqual(self.val("SELECT role FROM users WHERE id=?", (self.iid,)), "instructor")
        self.assertEqual(self.val("SELECT COUNT(*) FROM user_permissions WHERE user_id=?", (self.iid,)), 0)   # no permission rows were created or removed
    def test_assigned_tutor_cannot_reach_admin_only_faith_screens(self):
        self.assign(self.iid, self.prayer)
        for url in ("/staff/faith/", "/staff/faith/tutors"): self.assertIn(self.inst.get(url).status_code, (302, 403))
        self.assertEqual(self.post(self.inst, f"/staff/faith/tutors/{self.iid}", {"topic": [str(self.bible)]}).status_code, 403)
        self.assertEqual(self.assigned(self.iid), {self.prayer})                                          # a tutor cannot grant themselves topics

class MigrationTests(TutorTopicBase):
    def test_new_table_and_columns_exist_and_existing_data_kept(self):
        cols = {r["name"] for r in dbm.q("PRAGMA table_info(faith_items)")}
        self.assertTrue({"submitted_at", "review_note", "reviewed_at"} <= cols)
        self.assertEqual({r["name"] for r in dbm.q("PRAGMA table_info(faith_topic_tutors)")}, {"topic_id", "user_id", "assigned_by", "assigned_at"})
        self.assertEqual(self.val("SELECT COUNT(*) FROM faith_topics"), 6)
        self.assertEqual(self.val("SELECT COUNT(*) FROM faith_topic_tutors"), 0)                          # nobody is assigned automatically
