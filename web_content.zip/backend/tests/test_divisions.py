"""Course structure: Academic (Basic, Advanced) | Income Skills | Professional Development as an independent division.
Homepage: four sections in order (Basic subjects, Advanced subjects, Professional Development subjects, Income Skills courses)."""
import os, re, shutil, sqlite3, tempfile
from .base import *
from dagba import db as dbm_
from dagba.services import academic as A, settings as S, payouts as PO

def jpost(c, t, url, payload):
    return c.post(url, json=payload, headers={"X-CSRF-Token": t.tok(c)})

class DivBase(Base):
    def setUp(self):
        super().setUp()
        ex = dbm.ex
        self.mk("admin2", "admin", perms=["courses.manage", "categories.manage", "settings.manage"])
        self.o = self.client("owner"); self.pub = self.app.test_client()
        # subjects: Basic Mathematics (2 courses), Advanced Law (5 courses), Advanced Physics (no published course), income category, professional area
        self.bmath = ex("INSERT INTO categories(division,level,name,slug,price_kobo,featured,active) VALUES ('academic','basic','Mathematics','t-basic-maths',500000,1,1)")
        self.alaw = dbm.val("SELECT id FROM categories WHERE slug='advanced-law'"); self.aphys = dbm.val("SELECT id FROM categories WHERE slug='advanced-physics'")
        self.icat = ex("INSERT INTO categories(division,name,slug,active) VALUES ('income','Digital Marketing','t-inc-dm',1)")
        self.parea = ex("INSERT INTO categories(division,name,slug,price_kobo,featured,active) VALUES ('professional','Accounting Exams','t-pro-acc',0,1,1)")
        self.courses = {}
        def course(key, div, title, cat=None, level=None, status="published", featured=0):
            self.courses[key] = ex("INSERT INTO courses(division,academic_level,category_id,title,slug,summary,price_kobo,status,featured) VALUES (?,?,?,?,?,?,?,?,?)", (div, level, cat, title, key, f"About {title}", 100000, status, featured))
        for i in (1, 2): course(f"bm{i}", "academic", f"Basic Maths {i}", self.bmath, "basic")
        course("bm-draft", "academic", "Basic Maths Draft", self.bmath, "basic", status="draft")
        for i in range(1, 6): course(f"law{i}", "academic", f"Law Course {i}", self.alaw, "advanced")
        course("phys-draft", "academic", "Physics Draft", self.aphys, "advanced", status="draft")
        course("inc1", "income", "Income Course One", self.icat); course("inc2", "income", "Income Course Two", self.icat, featured=1); course("inc-draft", "income", "Income Draft", status="draft")
        course("pro1", "professional", "ICAN Exam Prep", self.parea); course("pro2", "professional", "Project Management Cert"); course("pro-draft", "professional", "Pro Draft", status="draft")
    def home(self): return self.pub.get("/").data.decode()
    def section(self, h, sid):
        m = re.search(r'<section class="block[^"]*" id="%s">(.*?)</section>' % sid, h, re.S); return m.group(1) if m else ""

class HomepageSectionTests(DivBase):
    def test_four_sections_in_order_with_the_right_content(self):
        h = self.home(); ids = [i for i in re.findall(r'<section class="block[^"]*" id="(basic|advanced|income|professional)"', h)]
        self.assertEqual(ids, ["basic", "advanced", "professional", "income"])
        self.assertLess(h.index('id="basic"'), h.index('id="advanced"')); self.assertLess(h.index('id="advanced"'), h.index('id="professional"')); self.assertLess(h.index('id="professional"'), h.index('id="income"'))
        self.assertIn("<h2>Advanced Courses</h2>", self.section(h, "advanced")); self.assertIn("<h2>Income Skills</h2>", self.section(h, "income")); self.assertIn("<h2>Professional Development</h2>", self.section(h, "professional"))
        self.assertNotIn("Featured courses", h); self.assertNotIn("Featured Courses", h)
    def test_basic_and_advanced_show_subjects_once_not_courses(self):
        h = self.home(); b, a = self.section(h, "basic"), self.section(h, "advanced")
        self.assertEqual(b.count("<h3>Mathematics</h3>"), 1); self.assertNotIn("Basic Maths 1", b)                                  # a subject, never its courses
        self.assertEqual(a.count("<h3>Law</h3>"), 1); self.assertIn("5 courses", a)                                                  # five courses, Law shown once
        for i in range(1, 6): self.assertNotIn(f"Law Course {i}", a)
        self.assertNotIn("Physics", a)                                                                                              # subject with no published course is hidden
        self.assertNotIn("Computer Science", a)                                                                                     # empty seeded subjects are hidden
    def test_duplicate_subject_names_never_produce_two_cards(self):
        dbm.ex("INSERT INTO categories(division,level,name,slug,featured,active) VALUES ('academic','advanced','law ','t-law-dupe',1,1)"); c = dbm.val("SELECT id FROM categories WHERE slug='t-law-dupe'")
        dbm.ex("UPDATE courses SET category_id=? WHERE slug='law1'", (c,)); self.assertEqual(self.section(self.home(), "advanced").lower().count("<h3>law"), 1)
        self.assertEqual(len([s for s in A.subjects("advanced", only_with_courses=True) if s["slug"] == "law"]), 1)
    def test_subject_cards_open_the_correct_listing(self):
        a = self.section(self.home(), "advanced"); href = re.search(r'href="([^"]+)"><span class="badge ">Advanced</span><h3>Law</h3>', a).group(1)
        self.assertEqual(href, "/academic/advanced/law"); r = self.pub.get(href); self.assertEqual(r.status_code, 200); p = r.data.decode()
        for i in range(1, 6): self.assertIn(f"Law Course {i}", p)
        self.assertNotIn("Basic Maths", p); self.assertNotIn("Income Course", p)
        b = self.section(self.home(), "basic"); href = re.search(r'href="(/academic/basic/[^"]+)"', b).group(1); p = self.pub.get(href).data.decode()
        self.assertIn("Basic Maths 1", p); self.assertIn("Basic Maths 2", p); self.assertNotIn("Basic Maths Draft", p); self.assertNotIn("Law Course", p)
    def test_income_section_only_published_income_courses(self):
        i = self.section(self.home(), "income")
        for t in ("Income Course One", "Income Course Two", "Marketing"): self.assertIn(t, i)
        for t in ("Income Draft", "Basic Maths", "Law Course", "ICAN", "Project Management", "Paid Maths"): self.assertNotIn(t, i)
        self.assertLess(i.index("Income Course Two"), i.index("Income Course One"))                                                  # featured first
        self.assertIn('/courses/inc1"', i)                                                                                         # existing course cards
    def test_professional_section_shows_subject_cards_not_individual_courses(self):
        dbm.ex("UPDATE categories SET price_kobo=400000 WHERE id=?", (self.parea,)); p = self.section(self.home(), "professional")
        self.assertEqual(p.count("<h3>Accounting Exams</h3>"), 1); self.assertIn("4,000", p); self.assertIn("1 course", p)           # subject card with its saved price, shown once
        self.assertIn('href="/professional/accounting-exams"', p)
        for t in ("ICAN Exam Prep", "Project Management Cert", "Pro Draft", "Income Course", "Law Course", "Basic Maths"): self.assertNotIn(t, p)      # never individual course cards
        self.assertNotIn('/courses/pro1"', p); r = self.pub.get("/professional/accounting-exams"); self.assertEqual(r.status_code, 200); self.assertIn("ICAN Exam Prep", r.data.decode())
        self.assertEqual(self.pub.get("/courses/pro1").status_code, 200)
    def test_empty_sections_are_hidden_and_toggles_work(self):
        dbm.ex("UPDATE courses SET status='draft' WHERE division='professional'"); h = self.home(); self.assertNotIn('id="professional"', h); self.assertIn('id="income"', h)      # a subject with no published course is hidden
        dbm.ex("UPDATE courses SET status='draft' WHERE division='income'"); self.assertNotIn('id="income"', self.home())
        dbm.ex("UPDATE courses SET status='published' WHERE division IN ('income','professional') AND slug NOT LIKE '%draft'")
        S.put("home.show_advanced", "0"); S.put("home.show_professional", "0"); h = self.home(); self.assertNotIn('id="advanced"', h); self.assertNotIn('id="professional"', h); self.assertIn('id="basic"', h)
    def test_homepage_visibility_is_controlled_per_subject(self):
        dbm.ex("UPDATE categories SET featured=0 WHERE id=?", (self.alaw,)); self.assertNotIn('id="advanced"', self.home())
        dbm.ex("UPDATE categories SET featured=1 WHERE id=?", (self.alaw,)); dbm.ex("UPDATE categories SET active=0 WHERE id=?", (self.alaw,)); self.assertNotIn('id="advanced"', self.home())
    def test_homepage_is_dynamic_new_course_appears_immediately(self):
        c = dbm.ex("INSERT INTO courses(division,title,slug,status,category_id) VALUES ('income','Brand New Income Course','brand-new-inc','published',NULL)"); self.assertIn("Brand New Income Course", self.home())
        dbm.ex("UPDATE courses SET status='archived' WHERE id=?", (c,)); self.assertNotIn("Brand New Income Course", self.home())
        n = dbm.ex("INSERT INTO categories(division,name,slug,price_kobo,featured,active) VALUES ('professional','Fresh Subject','t-fresh',100000,1,1)"); self.assertNotIn("Fresh Subject", self.home())      # no published course yet
        dbm.ex("INSERT INTO courses(division,title,slug,status,category_id) VALUES ('professional','Fresh Course','fresh-course','published',?)", (n,)); self.assertEqual(self.section(self.home(), "professional").count("<h3>Fresh Subject</h3>"), 1)

class NavigationTests(DivBase):
    def test_public_header_and_footer_link_to_professional_development(self):
        h = self.home(); self.assertIn('href="/professional"', h.split("</header>")[0]); self.assertIn("Professional Development", h.split("<footer")[1])
        self.assertEqual(self.pub.get("/professional").status_code, 200)
    def test_stored_menus_and_hero_link_are_updated_once_by_migration_018(self):
        sql = open(os.path.join(MIG, "018_professional_navigation.sql")).read()
        dbm.ex("INSERT OR REPLACE INTO settings(key,value) VALUES ('nav.header','Courses | /courses\nIncome Skills | /income-skills\nFaith | /faith')")
        dbm.ex("INSERT OR REPLACE INTO settings(key,value) VALUES ('nav.footer_explore','Courses | /courses\nFAQ | /faq')")
        dbm.ex("UPDATE hero_slides SET cta_url='/academic/professional' WHERE id=4")
        for _ in range(2): dbm.get_db().executescript(sql)                                                          # running it twice must not duplicate anything
        self.assertEqual(dbm.val("SELECT value FROM settings WHERE key='nav.header'").count("/professional"), 1)
        self.assertEqual(dbm.val("SELECT value FROM settings WHERE key='nav.footer_explore'").count("/professional"), 1)
        self.assertEqual(dbm.val("SELECT cta_url FROM hero_slides WHERE id=4"), "/professional"); self.assertIn('href="/professional"', self.home())

class SeparationTests(DivBase):
    def test_professional_is_its_own_page_and_the_old_address_redirects(self):
        r = self.pub.get("/academic/professional"); self.assertEqual(r.status_code, 301); self.assertTrue(r.headers["Location"].endswith("/professional"))
        r = self.pub.get("/academic/professional?area=%d" % self.parea); self.assertEqual(r.status_code, 301); self.assertIn("area=", r.headers["Location"])
        p = self.pub.get("/professional").data.decode(); self.assertIn("ICAN Exam Prep", p); self.assertIn("Project Management Cert", p); self.assertNotIn("Income Course", p); self.assertNotIn("Law Course", p); self.assertNotIn("Pro Draft", p)
        a = self.pub.get(f"/professional?area={self.parea}").data.decode(); self.assertIn("ICAN Exam Prep", a); self.assertNotIn("Project Management Cert", a)
        self.assertEqual(self.pub.get("/academic/professional/anything").status_code, 301)
    def test_academic_pages_no_longer_contain_professional(self):
        p = self.pub.get("/academic").data.decode(); self.assertIn('href="/academic/basic"', p); self.assertIn('href="/academic/advanced"', p); self.assertNotIn('href="/academic/professional"', p); self.assertIn("/professional", p)
        self.assertEqual(self.pub.get("/academic/basic").status_code, 200); self.assertEqual(self.pub.get("/academic/advanced").status_code, 200)
        self.assertNotIn("ICAN", self.pub.get("/academic/advanced").data.decode()); self.assertNotIn("ICAN", self.pub.get("/academic/basic").data.decode())
        self.assertNotIn("Professional Development", A.LEVELS.get("professional", {}).get("name", ""))
        self.assertEqual(A.level_counts()["professional"], 2); self.assertEqual(A.level_counts()["advanced"], 5)
    def test_course_listing_filters_and_division_badges(self):
        allp = self.pub.get("/courses").data.decode(); self.assertIn("ICAN Exam Prep", allp); self.assertIn("Income Course One", allp)
        pro = self.pub.get("/courses?division=professional").data.decode(); self.assertIn("ICAN Exam Prep", pro); self.assertNotIn("Income Course One", pro); self.assertNotIn("Law Course", pro)
        inc = self.pub.get("/courses?division=income").data.decode(); self.assertIn("Income Course One", inc); self.assertNotIn("ICAN", inc)
        inc2 = self.pub.get("/income-skills").data.decode(); self.assertNotIn("ICAN Exam Prep", inc2); self.assertNotIn("Project Management Cert", inc2)
        c = self.pub.get("/courses/pro1").data.decode(); self.assertIn('<a href="/professional">Professional Development</a>', c); self.assertNotIn('<a href="/academic">Academic</a> &rsaquo;', c)
        c = self.pub.get("/courses/law1").data.decode(); self.assertIn("Academic", c); self.assertIn("Advanced", c)
    def test_seo_pages_titles_sitemap_and_course_alias(self):
        sm = self.pub.get("/sitemap.xml").data.decode(); self.assertIn("/professional<", sm); self.assertIn("/courses/pro1", sm); self.assertIn("/academic/advanced/law", sm); self.assertNotIn("/academic/professional", sm)
        p = self.pub.get("/professional").data.decode(); self.assertIn("<title>", p); self.assertIn("Professional Development", re.search(r"<title>(.*?)</title>", p, re.S).group(1)); self.assertIn("<h1>Professional Development</h1>", p)
    def test_professional_course_has_no_subscription_access(self):
        from dagba.services import access
        self.assertEqual(access.course_scope(dbm.q1("SELECT * FROM courses WHERE slug='pro1'")), "professional"); self.assertEqual(access.course_scope(dbm.q1("SELECT * FROM courses WHERE slug='inc1'")), "income")
        self.assertEqual(access.course_scope(dbm.q1("SELECT * FROM courses WHERE slug='law1'")), "advanced")
    def test_buying_a_professional_course_works_end_to_end(self):
        c = self.client("alice"); ref = self.buy(c, "course", "pro1", who="alice"); t = self.tx(ref); self.assertEqual(t["division"], "professional")
        self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"}); self.assertTrue(dbm.val("SELECT 1 FROM entitlements WHERE user_id=? AND course_id=?", (self.users["alice"], self.courses["pro1"])))
        self.assertEqual(c.get("/courses/pro1").status_code, 200)

class AdminAndCreationTests(DivBase):
    def build(self, c, **kw):
        p = {"action": "publish", "title": "Created Course", "division": "professional", "category_id": self.parea, "modules": [{"title": "M", "lessons": [{"title": "L", "kind": "text", "body": "b"}]}]}; p.update(kw)
        return jpost(c, self, "/staff/builder/save", p)
    def test_admin_creates_courses_in_every_division_with_the_right_subject(self):
        r = self.build(self.o, price="2000", featured=True); self.assertEqual(r.status_code, 200, r.data[:300]); c = dbm.q1("SELECT * FROM courses WHERE id=?", (r.get_json()["id"],))
        self.assertEqual((c["division"], c["academic_level"], c["category_id"], c["status"], c["subscription_eligible"]), ("professional", None, self.parea, "published", 0))
        r = self.build(self.o, division="academic", academic_level="advanced", category_id=self.alaw, title="Adv Law", price="1000"); c = dbm.q1("SELECT * FROM courses WHERE id=?", (r.get_json()["id"],)); self.assertEqual((c["division"], c["academic_level"], c["category_id"]), ("academic", "advanced", self.alaw))
        r = self.build(self.o, division="income", category_id=self.icat, title="Inc New", price="1000"); c = dbm.q1("SELECT * FROM courses WHERE id=?", (r.get_json()["id"],)); self.assertEqual((c["division"], c["academic_level"], c["category_id"]), ("income", None, self.icat))
    def test_cross_division_categories_are_refused(self):
        for kw in (dict(division="professional", category_id=self.icat), dict(division="income", category_id=self.parea), dict(division="professional", category_id=self.alaw), dict(division="academic", academic_level="advanced", category_id=self.parea),
                   dict(division="academic", academic_level="basic", category_id=self.alaw)):
            n = dbm.val("SELECT COUNT(*) FROM courses"); r = self.build(self.o, **kw); self.assertEqual(r.status_code, 400, kw); self.assertEqual(dbm.val("SELECT COUNT(*) FROM courses"), n)
        self.assertEqual(self.build(self.o, division="nonsense").status_code, 400)
    def test_old_form_style_academic_professional_is_mapped_to_the_new_division(self):
        r = self.build(self.o, division="academic", academic_level="professional", category_id=self.parea, title="Legacy Form", price="500"); self.assertEqual(r.status_code, 200)
        c = dbm.q1("SELECT * FROM courses WHERE id=?", (r.get_json()["id"],)); self.assertEqual((c["division"], c["academic_level"]), ("professional", None))
    def test_instructor_can_submit_professional_course_but_not_publish_it(self):
        c = self.client("inst"); r = self.build(c, title="Inst Pro"); self.assertEqual(r.status_code, 200); j = r.get_json(); self.assertEqual(j["status"], "review"); row = dbm.q1("SELECT * FROM courses WHERE id=?", (j["id"],))
        self.assertEqual((row["division"], row["instructor_id"]), ("professional", self.users["inst"])); self.assertEqual(self.pub.get("/courses/" + row["slug"]).status_code, 404)
        self.assertNotIn("Inst Pro", self.pub.get("/professional").data.decode())
        self.post(self.o, f"/staff/catalog/{j['id']}/status", {"status": "published"}); self.assertEqual(dbm.val("SELECT status FROM courses WHERE id=?", (j["id"],)), "published"); self.assertIn("Inst Pro", self.pub.get("/professional").data.decode())
        other = self.client("alice"); self.assertEqual(self.build(other, title="x").status_code, 403)                              # permissions unchanged
        other_course = dbm.ex("INSERT INTO courses(division,title,slug,status,instructor_id) VALUES ('professional','Not Mine','not-mine','draft',NULL)")
        self.assertIn(self.build(c, id=other_course, title="Hijack").status_code, (403, 404))
    def test_staff_course_form_and_subject_management(self):
        f = self.o.get("/staff/r/courses/new"); self.assertEqual(f.status_code, 200); self.assertIn(b'value="professional"', f.data); self.assertNotIn(b"Academic: Professional", f.data)
        r = self.post(self.o, "/staff/r/categories/new?level=professional", {"name": "Banking Exams", "division": "professional", "level": "", "price_kobo": "0", "active": "1", "access_policy": "lifetime"}); self.assertEqual(r.status_code, 302)
        cat = dbm.q1("SELECT * FROM categories WHERE name='Banking Exams'"); self.assertEqual((cat["division"], cat["level"], cat["featured"]), ("professional", None, 0))      # Professional Development subjects can be featured; unticked here
        r = self.post(self.o, "/staff/r/categories/new?level=advanced", {"name": "Medicine", "division": "academic", "level": "advanced", "price_kobo": "0", "active": "1", "featured": "1", "access_policy": "lifetime"}); self.assertEqual(r.status_code, 302)
        adv = dbm.q1("SELECT * FROM categories WHERE name='Medicine'"); self.assertEqual((adv["division"], adv["level"], adv["featured"]), ("academic", "advanced", 1))
        r = self.post(self.o, "/staff/r/categories/new", {"name": "Income Priced", "division": "income", "level": "", "price_kobo": "50", "active": "1", "access_policy": "lifetime"}); self.assertEqual(r.status_code, 200)      # Income Skills stays priced per course
        self.assertIsNone(dbm.val("SELECT id FROM categories WHERE name='Income Priced'"))
        r = self.post(self.o, "/staff/r/categories/new", {"name": "Priced Pro", "division": "professional", "level": "basic", "price_kobo": "50", "featured": "1", "active": "1", "access_policy": "lifetime"}); self.assertEqual(r.status_code, 302)      # Professional Development subjects may be priced and featured
        pp = dbm.q1("SELECT * FROM categories WHERE name='Priced Pro'"); self.assertEqual((pp["division"], pp["level"], pp["price_kobo"], pp["featured"]), ("professional", None, 5000, 1))
        r = self.post(self.o, "/staff/r/categories/new", {"name": "Law", "division": "academic", "level": "advanced", "price_kobo": "0", "active": "1", "access_policy": "lifetime"}); self.assertEqual(r.status_code, 200)       # duplicate subject name refused
        self.assertEqual(dbm.val("SELECT COUNT(*) FROM categories WHERE division='academic' AND level='advanced' AND lower(name)='law'"), 1)
    def test_structure_page_lists_three_groups_and_menu_has_professional(self):
        h = self.o.get("/staff/academic").data.decode(); self.assertIn("Professional Development", h); self.assertIn("Accounting Exams", h); self.assertIn("Law", h)
        menu = self.o.get("/staff/").data.decode(); self.assertIn("Professional Development", menu); self.assertEqual(self.o.get("/staff/r/courses?ctx=professional").status_code, 200)
        cp = self.o.get("/staff/r/courses?ctx=professional").data.decode(); self.assertIn("ICAN Exam Prep", cp); self.assertNotIn("Law Course 1", cp); self.assertNotIn("Income Course One", cp)
        self.assertEqual(self.o.get("/staff/catalog?division=professional").status_code, 200); self.assertIn("ICAN Exam Prep", self.o.get("/staff/catalog?division=professional").data.decode())
        for who in ("alice", "writer", "noperm"): self.assertIn(self.client(who).get("/staff/academic").status_code, (302, 403))
    def test_professional_payout_rate_keeps_the_academic_rate_until_set(self):
        S.put("payout.instructor_percent", "40"); S.put("payout.instructor_percent_academic", "55"); self.assertEqual(PO.percent("professional"), 55.0); S.put("payout.instructor_percent_professional", "65"); self.assertEqual(PO.percent("professional"), 65.0); self.assertEqual(PO.percent("academic"), 55.0)
        self.assertIn("professional", PO.rates()); self.assertIn("professional", PO.by_division())

class MigrationTests(unittest.TestCase):
    def test_upgrade_moves_professional_out_of_academic_without_losing_anything(self):
        tmp = tempfile.mkdtemp(); mig = os.path.join(tmp, "m"); os.makedirs(mig); p = os.path.join(tmp, "t.db")
        try:
            for f in sorted(os.listdir(MIG)):
                if f < "017": shutil.copy(os.path.join(MIG, f), mig)
            dbm_.migrate(p, mig); c = sqlite3.connect(p); c.execute("PRAGMA foreign_keys=ON")
            c.execute("INSERT INTO users(email,password_hash,full_name,role) VALUES ('s@t','x','S','student')"); c.execute("INSERT INTO users(email,password_hash,full_name,role) VALUES ('i@t','x','I','instructor')")
            area = c.execute("INSERT INTO categories(division,level,name,slug) VALUES ('academic','professional','ICAN','prof-ican')").lastrowid
            basic = c.execute("INSERT INTO categories(division,level,name,slug,featured) VALUES ('academic','basic','Maths','b-maths',1)").lastrowid
            inc = c.execute("INSERT INTO categories(division,name,slug) VALUES ('income','Digital','i-dig')").lastrowid
            pro = c.execute("INSERT INTO courses(division,academic_level,category_id,title,slug,status,subscription_eligible,instructor_id) VALUES ('academic','professional',?,'ICAN Prep','ican-prep','published',1,2)", (area,)).lastrowid
            pro2 = c.execute("INSERT INTO courses(division,academic_level,title,slug,status) VALUES ('academic','professional','No Area','no-area','published')").lastrowid
            adv = c.execute("INSERT INTO courses(division,academic_level,category_id,title,slug,status) VALUES ('academic','advanced',(SELECT id FROM categories WHERE slug='advanced-law'),'Law','law-c','published')").lastrowid
            bas = c.execute("INSERT INTO courses(division,academic_level,category_id,title,slug,status) VALUES ('academic','basic',?,'Algebra','algebra','published')", (basic,)).lastrowid
            inco = c.execute("INSERT INTO courses(division,category_id,title,slug,status) VALUES ('income',?,'Ads','ads','published')", (inc,)).lastrowid
            m = c.execute("INSERT INTO modules(course_id,title,position) VALUES (?,?,1)", (pro, "M")).lastrowid; c.execute("INSERT INTO lessons(course_id,module_id,title,kind,position) VALUES (?,?,'L','text',1)", (pro, m))
            c.execute("INSERT INTO entitlements(user_id,kind,course_id,starts_at) VALUES (1,'course',?,'2026-01-01 00:00:00')", (pro,)); c.execute("INSERT INTO progress(user_id,course_id,lesson_id,completed_at) VALUES (1,?,1,'2026-01-02 00:00:00')", (pro,))
            c.execute("INSERT INTO instructor_earnings(instructor_id,transaction_id,course_id,kind,gross_kobo,percent,amount_kobo) SELECT 2, id, ?, 'sale', 1000, 40, 400 FROM (SELECT 1 AS id)", (pro,)) if False else None
            c.execute("INSERT INTO settings(key,value) VALUES ('home.featured_title','Featured Courses')"); c.commit()
            tables = ("users", "categories", "courses", "modules", "lessons", "entitlements", "progress", "plans", "pages"); before = {t: c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in tables}; rows_before = c.execute("SELECT id,title,slug,price_kobo,status,instructor_id,created_at FROM courses ORDER BY id").fetchall(); c.close()
            shutil.copy(os.path.join(MIG, "017_professional_division.sql"), mig); self.assertEqual(dbm_.migrate(p, mig), ["017_professional_division.sql"])
            c = sqlite3.connect(p); c.execute("PRAGMA foreign_keys=ON")
            self.assertEqual(before, {t: c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in tables})                                     # nothing deleted or duplicated
            self.assertEqual(rows_before, c.execute("SELECT id,title,slug,price_kobo,status,instructor_id,created_at FROM courses ORDER BY id").fetchall())   # same ids, same data
            self.assertEqual(c.execute("PRAGMA foreign_key_check").fetchall(), []); self.assertEqual(c.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            get = lambda cid: c.execute("SELECT division, academic_level, subscription_eligible, category_id FROM courses WHERE id=?", (cid,)).fetchone()
            self.assertEqual(get(pro), ("professional", None, 0, area)); self.assertEqual(get(pro2), ("professional", None, 0, None))
            self.assertEqual(get(adv)[:2], ("academic", "advanced")); self.assertEqual(get(bas)[:2], ("academic", "basic")); self.assertEqual(get(inco)[:2], ("income", None))
            self.assertEqual(c.execute("SELECT division, level FROM categories WHERE id=?", (area,)).fetchone(), ("professional", None)); self.assertEqual(c.execute("SELECT division, level, featured FROM categories WHERE id=?", (basic,)).fetchone(), ("academic", "basic", 1))
            self.assertEqual(c.execute("SELECT COUNT(*) FROM categories WHERE division='academic' AND level='advanced' AND featured=1").fetchone()[0], 13)
            self.assertEqual(c.execute("SELECT value FROM settings WHERE key='home.featured_title'").fetchone()[0], "Income Skills")
            self.assertEqual(c.execute("SELECT COUNT(*) FROM modules WHERE course_id=?", (pro,)).fetchone()[0], 1); self.assertEqual(c.execute("SELECT COUNT(*) FROM entitlements WHERE course_id=?", (pro,)).fetchone()[0], 1)
            c.execute("INSERT INTO courses(division,title,slug) VALUES ('professional','New Pro','new-pro-x')"); c.execute("INSERT INTO categories(division,name,slug) VALUES ('professional','Area','area-x')")
            with self.assertRaises(sqlite3.IntegrityError): c.execute("INSERT INTO courses(division,title,slug) VALUES ('bogus','x','x-bogus')")
            c.close()
        finally: shutil.rmtree(tmp, ignore_errors=True)

class DashboardTests(DivBase):
    def test_admin_dashboard_breaks_published_courses_down_by_division(self):
        h = self.o.get("/staff/").data.decode(); self.assertIn("Published courses by division", h)
        for label in ("Academic: Basic", "Academic: Advanced", "Income Skills", "Professional Development"): self.assertIn(label, h)
        counts = {k: n for k, _, n in A.division_counts()}; self.assertEqual((counts["advanced"], counts["professional"]), (5, 2))
        self.assertEqual(sum(counts.values()), dbm.val("SELECT COUNT(*) FROM courses WHERE status='published'"))               # every published course is counted in exactly one group
        dbm.ex("UPDATE courses SET status='archived' WHERE slug='pro2'"); self.assertEqual({k: n for k, _, n in A.division_counts()}["professional"], 1)
    def test_path_dashboards_exist_for_every_division_and_are_scoped(self):
        for ctx, mine, other in (("professional", "ICAN Exam Prep", "Law Course 1"), ("income", "Income Course One", "ICAN Exam Prep"), ("advanced", "Law Course 1", "ICAN Exam Prep"), ("basic", "Basic Maths 1", "ICAN Exam Prep")):
            r = self.o.get(f"/staff/r/courses?ctx={ctx}"); self.assertEqual(r.status_code, 200, ctx); h = r.data.decode(); self.assertIn(mine, h, ctx); self.assertNotIn(other, h, ctx)
    def test_instructor_dashboard_labels_each_course_division(self):
        dbm.ex("UPDATE courses SET instructor_id=? WHERE slug IN ('pro1','inc1','law1')", (self.users["inst"],)); h = self.client("inst").get("/staff/").data.decode()
        self.assertIn("Professional Development", h); self.assertIn("Income Skills", h); self.assertIn("Advanced", h)
    def test_reports_split_course_sales_by_division(self):
        for who, slug in (("alice", "pro1"), ("bob", "inc1"), ("carol", "law1")):
            if who not in self.users: self.mk(who, "student")
            c = self.client(who); t = self.tx(self.buy(c, "course", slug, who=who)); self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"})
        h = self.o.get("/staff/reports").data.decode(); self.assertIn("Course sales by division", h)
        for label in ("Professional Development", "Income Skills", "Academic: Advanced"): self.assertIn(label, h)
        csvd = self.o.get("/staff/reports/export.csv").data.decode(); self.assertIn("Revenue by course division,Professional Development", csvd); self.assertIn("Revenue by course division,Income Skills", csvd)
