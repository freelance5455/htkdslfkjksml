import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { setupTestEnv } from './helpers/setup-test-env.js';

const { token } = setupTestEnv();
const { runMigrations } = await import('../src/database/migrate.js');
const { createApp } = await import('../src/app.js');

let server;
let baseUrl;

before(async () => {
  runMigrations();
  server = createApp();
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(() => {
  server.close();
});

function authedFetch(path, options = {}) {
  return fetch(`${baseUrl}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      ...options.headers,
    },
  });
}


test('OPTIONS permite preflight CORS somente para origem configurada', async () => {
  const allowed = await fetch(`${baseUrl}/api/connect`, {
    method: 'OPTIONS',
    headers: { Origin: 'null', 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'authorization,content-type' },
  });
  assert.equal(allowed.status, 204);
  assert.equal(allowed.headers.get('access-control-allow-origin'), 'null');
  assert.match(allowed.headers.get('access-control-allow-headers'), /Authorization/i);
  const actual = await fetch(`${baseUrl}/api/health`, { headers: { Origin: 'null' } });
  assert.equal(actual.headers.get('access-control-allow-origin'), 'null');

  const denied = await fetch(`${baseUrl}/api/connect`, {
    method: 'OPTIONS', headers: { Origin: 'https://site-nao-autorizado.example' },
  });
  assert.equal(denied.status, 403);
});

test('GET /api/health responde 200 sem autenticacao e com estados reais', async () => {
  const res = await fetch(`${baseUrl}/api/health`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.equal(body.app, 'ADAM KNOWLEDGE');
  assert.equal(body.database, 'OK');
  assert.ok(['NAO CONFIGURADA'].includes(body.webResearch) || body.webResearch === 'DISPONIVEL');
});

test('Rotas autenticadas rejeitam requisicao sem token (401)', async () => {
  const res = await fetch(`${baseUrl}/api/connect`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(res.status, 401);
  const body = await res.json();
  assert.equal(body.error, 'UNAUTHORIZED');
});

test('Rotas autenticadas rejeitam token incorreto (401)', async () => {
  const res = await fetch(`${baseUrl}/api/connect`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer token-errado' },
    body: '{}',
  });
  assert.equal(res.status, 401);
});

test('POST /api/connect com token correto responde 200', async () => {
  const res = await authedFetch('/api/connect', { method: 'POST', body: JSON.stringify({ client_name: 'AddonForge-Test' }) });
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.equal(body.connected, true);
  assert.equal(body.server, 'ADAM KNOWLEDGE');
});

test('POST /api/research sem query retorna 400', async () => {
  const res = await authedFetch('/api/research', { method: 'POST', body: JSON.stringify({}) });
  assert.equal(res.status, 400);
  const body = await res.json();
  assert.equal(body.error, 'INVALID_REQUEST');
});

test('Fluxo completo: POST /api/research -> GET /api/tasks/:request_id com resultado compilado', async () => {
  const requestId = 'integration-test-001';
  const createRes = await authedFetch('/api/research', {
    method: 'POST',
    body: JSON.stringify({
      request_id: requestId,
      query: 'metal enferrujado textura minecraft',
      requirements: { find_images: true },
    }),
  });
  assert.equal(createRes.status, 202);
  const created = await createRes.json();
  assert.equal(created.request_id, requestId);
  assert.equal(created.status, 'processing');
  assert.ok(created.tasks.length >= 2);

  // Aguarda o processamento assincrono real das tarefas
  let status;
  for (let i = 0; i < 20; i++) {
    const statusRes = await authedFetch(`/api/tasks/${requestId}`);
    assert.equal(statusRes.status, 200);
    status = await statusRes.json();
    if (status.status !== 'processing') break;
    await new Promise((r) => setTimeout(r, 100));
  }

  assert.notEqual(status.status, 'processing');
  assert.ok(status.compiledResult, 'compiledResult deve existir quando todas as subtarefas terminam');
  assert.match(status.compiledResult.summary, /subtarefa\(s\) concluida\(s\)/);
});

test('GET /api/tasks/:id com id inexistente retorna 404', async () => {
  const res = await authedFetch('/api/tasks/id-que-nao-existe-123');
  assert.equal(res.status, 404);
});

test('Fluxo completo de recursos: criar -> buscar -> obter por id', async () => {
  const createRes = await authedFetch('/api/resources/create', {
    method: 'POST',
    body: JSON.stringify({
      type: 'texture', category: 'metal', name: 'Metal enferrujado 01',
      description: 'Referencia visual', origin: 'https://exemplo.com/metal.jpg',
      format: 'png', tags: ['metal', 'enferrujado'], project: 'addon-teste',
    }),
  });
  assert.equal(createRes.status, 201);
  const created = await createRes.json();
  assert.ok(created.id);

  const searchRes = await authedFetch('/api/library?type=texture&tag=enferrujado');
  assert.equal(searchRes.status, 200);
  const searchBody = await searchRes.json();
  assert.equal(searchBody.total, 1);
  assert.equal(searchBody.items[0].id, created.id);

  const getRes = await authedFetch(`/api/library/${created.id}`);
  assert.equal(getRes.status, 200);
  const fetched = await getRes.json();
  assert.equal(fetched.name, 'Metal enferrujado 01');
});

test('POST /api/resources/create com tipo invalido retorna 400 com mensagem clara (nao 500)', async () => {
  const res = await authedFetch('/api/resources/create', {
    method: 'POST',
    body: JSON.stringify({ type: 'tipo-invalido', category: 'x', name: 'y' }),
  });
  assert.equal(res.status, 400);
  const body = await res.json();
  assert.equal(body.error, 'VALIDATION_ERROR');
  assert.match(body.message, /Tipo de recurso invalido/);
});

test('POST /api/resources/create sem campos obrigatorios retorna 400', async () => {
  const res = await authedFetch('/api/resources/create', {
    method: 'POST',
    body: JSON.stringify({ type: 'texture' }),
  });
  assert.equal(res.status, 400);
  const body = await res.json();
  assert.match(body.message, /obrigatorios/);
});

test('GET /api/library/:id com id inexistente retorna 404', async () => {
  const res = await authedFetch('/api/library/id-fake-000');
  assert.equal(res.status, 404);
});


test('Download autenticado entrega os bytes reais do arquivo da biblioteca', async () => {
  const bytes = Buffer.from('arquivo-textura-de-teste');
  const createRes = await authedFetch('/api/resources/create', {
    method: 'POST',
    body: JSON.stringify({
      type: 'texture', category: 'testes', name: 'Textura binaria',
      file_base64: bytes.toString('base64'), file_extension: 'png', format: 'png',
    }),
  });
  assert.equal(createRes.status, 201);
  const resource = await createRes.json();

  const download = await authedFetch(`/api/library/${resource.id}/file`);
  assert.equal(download.status, 200);
  assert.equal(download.headers.get('content-type'), 'image/png');
  assert.deepEqual(Buffer.from(await download.arrayBuffer()), bytes);

  const unauthorized = await fetch(`${baseUrl}/api/library/${resource.id}/file`);
  assert.equal(unauthorized.status, 401);
});

test('Criacao de recurso rejeita extensao com tentativa de caminho', async () => {
  const res = await authedFetch('/api/resources/create', {
    method: 'POST',
    body: JSON.stringify({
      type: 'texture', category: 'testes', name: 'Extensao suspeita',
      file_base64: Buffer.from('x').toString('base64'), file_extension: '../../fora',
    }),
  });
  assert.equal(res.status, 400);
  const body = await res.json();
  assert.equal(body.error, 'VALIDATION_ERROR');
});

test('POST /api/sync responde 501 informando que ainda nao esta implementado (nunca finge sucesso)', async () => {
  const res = await authedFetch('/api/sync', { method: 'POST', body: '{}' });
  assert.equal(res.status, 501);
  const body = await res.json();
  assert.equal(body.synced, false);
});

test('Corpo JSON invalido retorna 400 claro', async () => {
  const res = await authedFetch('/api/research', { method: 'POST', body: '{ json invalido ]' });
  assert.equal(res.status, 400);
  const body = await res.json();
  assert.equal(body.error, 'INVALID_JSON');
});

test('Rota inexistente retorna 404', async () => {
  const res = await authedFetch('/api/rota-que-nao-existe');
  assert.equal(res.status, 404);
});
