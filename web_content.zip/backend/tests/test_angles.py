import pytest
from app.main import fmt_pos, sign_index, norm_angle

def test_sign_index_wraps():
    assert sign_index(0) == 0
    assert sign_index(30) == 1
    assert sign_index(360) == 0
    assert sign_index(-1) == 11

def test_normalize_angle():
    assert norm_angle(361) == 1
    assert norm_angle(-1) == 359

def test_format_position():
    assert fmt_pos(0).startswith("0°00′ Овен")
    assert "Телец" in fmt_pos(30)
