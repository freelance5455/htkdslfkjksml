import os
from PIL import Image
from .base import *

def jpg(size=(800, 600), mode="RGB", **kw):
    b = io.BytesIO(); Image.new(mode, size, (30, 120, 200) if mode != "L" else 128).save(b, "JPEG", quality=90, **kw); return b.getvalue()
def noisy(w, h):
    b = io.BytesIO(); Image.frombytes("RGB", (w, h), os.urandom(w * h * 3)).save(b, "JPEG", quality=92); return b.getvalue()
def png(size=(50, 50), mode="RGB", **kw):
    b = io.BytesIO(); Image.new(mode, size).save(b, "PNG", **kw); return b.getvalue()

class BlogPostUploadTests(Base):
    def post_article(self, c, data=None, fname="p.jpg", **form):
        d = {"_csrf": self.tok(c), "title": "My post", "body": "Hello", "status": "draft"}; d.update(form)
        if data is not None: d["featured_image"] = (io.BytesIO(data), fname)
        return c.post("/staff/r/articles/new", data=d, content_type="multipart/form-data")
    def test_real_world_images_never_cause_a_server_error(self):
        cases = {"phone photo": (noisy(4000, 3000), "IMG_1.jpg", 302), "cmyk": (jpg(mode="CMYK"), "c.jpg", 302), "grey": (jpg(mode="L"), "g.jpg", 302), "16-bit png": (png(mode="I;16"), "d.png", 302),
                 "palette+transparency": (png(mode="P", transparency=0), "p.png", 302), "rgba": (png(mode="RGBA"), "r.png", 302), "bilevel": (png(mode="1"), "b.png", 302), "unicode name": (jpg(), "foto é 😀.jpg", 302),
                 "truncated": (jpg(size=(1500, 1500))[:-3000], "cut.jpg", 200), "pixel bomb": (png(size=(22000, 22000), mode="1"), "huge.png", 200), "heic": (b"\x00\x00\x00\x18ftypheic" + b"\0" * 50, "a.heic", 200),
                 "gif as png": (b"GIF89a" + b"\x01\x00\x01\x00" + b"\0" * 20, "x.png", 200), "script as jpg": (b"<?php system($_GET[1]); ?>", "x.jpg", 200), "empty": (b"", "e.jpg", 200)}
        for who in ("writer", "owner"):
            c = self.client(who)
            for name, (data, fname, expect) in cases.items():
                r = self.post_article(c, data, fname); self.assertEqual(r.status_code, expect, (who, name, r.status_code))
        self.assertEqual(self.post_article(self.client("owner"), jpg(size=(1500, 1500))[:-3000], "cut.jpg").data.decode().count("could not be processed"), 1)       # friendly message
    def test_phone_photo_is_resized_and_upright(self):
        im = Image.new("RGB", (3000, 1500), (200, 50, 50)); ex = im.getexif(); ex[0x0112] = 6; b = io.BytesIO(); im.save(b, "JPEG", exif=ex.tobytes())      # EXIF "rotate 90"
        c = self.client("owner"); self.assertEqual(self.post_article(c, b.getvalue(), "r.jpg").status_code, 302)
        name = self.val("SELECT featured_image FROM articles"); out = Image.open(os.path.join(self.app.config["PUBLIC_DIR"], name)); self.assertEqual(max(out.size), 1600); self.assertGreater(out.size[1], out.size[0])   # portrait after rotation
        self.assertEqual(self.app.test_client().get(f"/media/{name}").status_code, 200); self.assertEqual(self.app.test_client().get("/media/x.php").status_code, 404)
    def test_long_post_and_special_characters_save_and_render(self):
        body = ("## Heading\n" + "A paragraph with **bold**, emoji \U0001F600 and \u00e9\u00f1 characters.\n\n" * 20000)           # ~1.2 MB of text
        c = self.client("owner"); r = self.post_article(c, None, title="Long \U0001F680 post", body=body, status="published", excerpt="x" * 400, seo_title="S" * 200, seo_description="D" * 400); self.assertEqual(r.status_code, 302)
        slug = self.val("SELECT slug FROM articles"); page = self.app.test_client().get(f"/blog/{slug}"); self.assertEqual(page.status_code, 200); self.assertIn("A paragraph with", page.data.decode())
    def test_scheduling_formats_and_bad_dates(self):
        c = self.client("owner")
        self.assertEqual(self.post_article(c, None, title="S1", status="scheduled", publish_at="2999-01-01T09:30").status_code, 302)
        self.assertEqual(self.val("SELECT publish_at FROM articles WHERE title='S1'"), "2999-01-01 09:30")
        for bad in ("not a date", "2026-13-45T99:99", "31/12/2026"): self.assertEqual(self.post_article(c, None, title="B", status="scheduled", publish_at=bad).status_code, 200, bad)
        self.assertEqual(self.post_article(c, None, title="NoDate", status="scheduled").status_code, 200)
    def test_other_image_upload_places_dont_crash_either(self):
        bad = jpg(size=(1500, 1500))[:-3000]; o = self.client("owner")
        r = o.post("/staff/builder/thumbnail", data={"file": (io.BytesIO(bad), "t.jpg")}, headers={"X-CSRF-Token": self.tok(o)}, content_type="multipart/form-data"); self.assertEqual(r.status_code, 400); self.assertIn("could not be processed", r.get_json()["error"])
        r = o.post("/staff/settings/brand", data={"_csrf": self.tok(o), "brand.logo": (io.BytesIO(bad), "l.jpg"), "brand.primary": "#7236E6", "brand.dark": "#1b1230", "brand.accent": "#2563eb"}, content_type="multipart/form-data"); self.assertEqual(r.status_code, 200)
        r = o.post("/staff/r/nuggets/new", data={"_csrf": self.tok(o), "title": "N", "body": "b", "status": "draft", "image": (io.BytesIO(bad), "n.jpg")}, content_type="multipart/form-data"); self.assertEqual(r.status_code, 200)
    def test_webp_encoder_missing_falls_back(self):
        from dagba.services import uploads; from PIL import Image as I
        real = I.Image.save
        def fake(self, fp, fmt=None, **k):
            if fmt == "WEBP": raise OSError("encoder webp not available")
            return real(self, fp, fmt, **k)
        I.Image.save = fake
        try: c = self.client("owner"); self.assertEqual(self.post_article(c, jpg(), "p.jpg").status_code, 302)
        finally: I.Image.save = real
        name = self.val("SELECT featured_image FROM articles"); self.assertTrue(name.endswith(".jpg")); self.assertEqual(self.app.test_client().get(f"/media/{name}").status_code, 200)
