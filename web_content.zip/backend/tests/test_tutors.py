"""Tutor programme: application -> approval -> activation -> publication; referral purchase -> commission -> earnings -> withdrawal;
permissions, privacy, anti-abuse (self-referral, duplicates), rates and overrides, suspension, and profile pictures."""
import io, os, re
from .base import *
from dagba.services import tutors as T, payouts as PO, settings as S, avatars

def jpg(w=900, h=700, colour=(40, 90, 200)):
    b = io.BytesIO(); Image.new("RGB", (w, h), colour).save(b, "JPEG"); return b.getvalue()

class TutBase(Base):
    with_mou = True                      # the tutor MOU is published, so applications can be submitted (tests/test_mou.py covers the MOU itself)
    def setUp(self):
        super().setUp()
        if self.with_mou: self.publish_mou()
        self.mk("reviewer", "admin", perms=["tutors.manage"]); self.mk("payroll", "admin", perms=["payouts.manage", "tutors.manage"]); self.mk("eve", "student"); self.mk("inst2", "instructor")
        self.cat = self.val("SELECT id FROM categories WHERE division='income' LIMIT 1")
        self.o = self.client("owner"); self.rev = self.client("reviewer"); self.pay = self.client("payroll")
    # ---- helpers
    def form(self, **kw):
        d = dict(full_name="Eve Teacher", phone="08030000001", location="Lagos", bio="I have taught digital marketing for ten years to hundreds of learners.", experience="10 years training", qualifications="BSc",
                 website="", category_id=str(self.cat), title="Marketing Mastery", summary="Learn marketing", description="A full course.", curriculum="Module 1\nModule 2", outcomes="Plan a campaign\nRun ads", expected_price="25000")
        d.update(kw); return d
    def sign_fields(self, c):
        """What a real applicant sends: they were shown the current MOU (GET the page), ticked the box and typed their registered name."""
        from dagba.services import mou as M
        with c.session_transaction() as s: uid = s["uid"]
        c.get("/tutor/apply"); v = M.current()
        return dict(mou_version_id=str(v["id"]), mou_agree="1", mou_signature=self.val("SELECT full_name FROM users WHERE id=?", (uid,)))
    def apply_form(self, c, action, files=True, sign=True, **kw):
        d = self.form(**kw); d["_csrf"] = self.tok(c); d["action"] = action
        if action == "submit" and sign and self.with_mou: d.update(self.sign_fields(c))
        if files: d["cover"] = (io.BytesIO(jpg()), "cover.jpg")
        return c.post("/tutor/apply/save", data=d, content_type="multipart/form-data")
    def lesson_via_builder(self, c, cid):
        """Add one lesson to the application's course exactly as the applicant would: through the Course Builder save endpoint."""
        from tests.test_builder import jpost
        d = c.get(f"/staff/builder/{cid}")
        self.assertEqual(d.status_code, 200)
        row = dbm.q1("SELECT * FROM courses WHERE id=?", (cid,))
        r = jpost(c, self, "/staff/builder/save", {"id": cid, "action": "publish", "title": row["title"], "division": row["division"], "academic_level": row["academic_level"] or "", "category_id": row["category_id"],
                  "modules": [{"title": "M1", "lessons": [{"title": "L1", "kind": "text", "body": "hello"}]}]})
        return r
    def submitted_application(self, who="eve"):
        c = self.client(who); self.post(c, "/tutor/apply/start")
        self.apply_form(c, "save"); aid = self.val("SELECT id FROM tutor_applications WHERE user_id=?", (self.users[who],)); cid = self.val("SELECT course_id FROM tutor_applications WHERE id=?", (aid,))
        r = self.lesson_via_builder(c, cid); self.assertEqual(r.status_code, 200, r.data[:300])
        self.assertEqual(self.apply_form(c, "submit").status_code, 302); return c, aid, cid
    def decide(self, c, aid, action, **kw):
        d = {"action": action}; d.update(kw); return self.post(c, f"/staff/tutors/applications/{aid}/decide", d)
    def approve(self, aid, **kw): return self.decide(self.rev, aid, "approve", **kw)
    def tutor_with_course(self):
        c, aid, cid = self.submitted_application(); self.approve(aid, price="25000"); return c, aid, cid
    def sale(self, who="bob", cid=None, cookie=None, client=None):
        c = client or self.client(who); slug = self.val("SELECT slug FROM courses WHERE id=?", (cid,)); ref = self.buy(c, "course", slug, who=who); t = self.tx(ref)
        self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"}); return t["id"], c
    def earning(self, tid): return dbm.q1("SELECT * FROM instructor_earnings WHERE transaction_id=? AND kind='sale'", (tid,))

class ApplicationFlowTests(TutBase):
    def test_full_journey_application_to_publication(self):
        # 1. public page, apply requires login
        self.assertEqual(self.app.test_client().get("/become-a-tutor").status_code, 200)
        r = self.app.test_client().get("/tutor/apply"); self.assertEqual(r.status_code, 302); self.assertIn("/login", r.headers["Location"])
        c = self.client("eve"); self.assertEqual(self.post(c, "/tutor/apply/start").status_code, 302)
        aid = self.val("SELECT id FROM tutor_applications WHERE user_id=?", (self.users["eve"],)); self.assertEqual(self.row("SELECT status, kind FROM tutor_applications WHERE id=?", (aid,))["status"], "draft")
        # 2. a draft can be saved incomplete, then completed; the draft course is created and stays private
        self.assertEqual(self.apply_form(c, "save", files=False, description="", outcomes="", curriculum="").status_code, 302)
        cid = self.val("SELECT course_id FROM tutor_applications WHERE id=?", (aid,)); self.assertTrue(cid)
        self.assertEqual(self.row("SELECT status, instructor_id, price_kobo FROM courses WHERE id=?", (cid,))["status"], "draft")
        self.assertEqual(self.app.test_client().get(f"/courses/{self.val('SELECT slug FROM courses WHERE id=?', (cid,))}").status_code, 404)
        # submitting without lessons is refused with a clear message
        r = self.apply_form(c, "submit"); self.assertEqual(self.row("SELECT status FROM tutor_applications WHERE id=?", (aid,))["status"], "draft")
        self.assertIn(b"at least one lesson", c.get("/tutor/apply").data)
        # 3. applicant adds a lesson in the builder (cannot publish there), then submits
        self.assertEqual(self.lesson_via_builder(c, cid).status_code, 200); self.assertEqual(self.row("SELECT status FROM courses WHERE id=?", (cid,))["status"], "draft")
        self.assertEqual(self.apply_form(c, "submit").status_code, 302)
        a = self.row("SELECT * FROM tutor_applications WHERE id=?", (aid,)); self.assertEqual(a["status"], "pending"); self.assertEqual(self.row("SELECT status FROM courses WHERE id=?", (cid,))["status"], "review")
        # locked while pending
        self.assertEqual(self.apply_form(c, "save", title="Changed").status_code, 302); self.assertEqual(self.row("SELECT title FROM tutor_applications WHERE id=?", (aid,))["title"], "Marketing Mastery")
        # 4. reviewer sees it, previews materials
        page = self.rev.get(f"/staff/tutors/applications/{aid}"); self.assertEqual(page.status_code, 200); self.assertIn(b"Marketing Mastery", page.data); self.assertIn(b"L1", page.data)
        self.assertEqual(self.rev.get(f"/courses/{self.val('SELECT slug FROM courses WHERE id=?', (cid,))}").status_code, 200)    # draft preview for admins
        # 5. approve with an adjusted price: account upgraded in place, profile created, course published at the approved price
        self.assertEqual(self.row("SELECT role FROM users WHERE id=?", (self.users["eve"],))["role"], "student")
        r = self.approve(aid, price="30000"); self.assertEqual(r.status_code, 302)
        self.assertEqual(self.row("SELECT role FROM users WHERE id=?", (self.users["eve"],))["role"], "instructor")
        self.assertEqual(self.val("SELECT COUNT(*) FROM users WHERE email='eve@t.test'"), 1)                                   # no duplicate account
        p = self.row("SELECT * FROM tutor_profiles WHERE user_id=?", (self.users["eve"],)); self.assertTrue(p["code"]); self.assertEqual(p["status"], "active")
        co = self.row("SELECT * FROM courses WHERE id=?", (cid,)); self.assertEqual((co["status"], co["price_kobo"], co["instructor_id"]), ("published", 3000000, self.users["eve"]))
        a = self.row("SELECT * FROM tutor_applications WHERE id=?", (aid,)); self.assertEqual((a["status"], a["approved_price_kobo"], a["expected_price_kobo"]), ("approved", 3000000, 2500000))
        self.assertEqual(self.app.test_client().get(f"/courses/{co['slug']}").status_code, 200)                                  # publicly visible
        self.assertEqual(self.app.test_client().get(f"/course/{co['slug']}").status_code, 200)                                   # shareable URL form
        # 6. the same session now has tutor access without logging in again, and the notification exists
        self.assertEqual(c.get("/staff/").status_code, 200); self.assertEqual(c.get("/staff/tutor/links").status_code, 200); self.assertEqual(c.get("/staff/tutor/reports").status_code, 200)
        self.assertGreaterEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=?", (self.users["eve"],)), 1)
        # approving again does nothing
        self.approve(aid); self.assertEqual(self.val("SELECT COUNT(*) FROM tutor_profiles WHERE user_id=?", (self.users["eve"],)), 1)
        self.assertEqual(self.val("SELECT COUNT(*) FROM tutor_application_events WHERE application_id=? AND event='approved'", (aid,)), 1)
    def test_revision_then_resubmit_then_reject_flow(self):
        c, aid, cid = self.submitted_application()
        r = self.decide(self.rev, aid, "revision", feedback=""); self.assertEqual(self.row("SELECT status FROM tutor_applications WHERE id=?", (aid,))["status"], "pending")   # feedback required
        self.decide(self.rev, aid, "revision", feedback="Please add more lessons."); a = self.row("SELECT * FROM tutor_applications WHERE id=?", (aid,)); self.assertEqual((a["status"], a["feedback"]), ("revision", "Please add more lessons."))
        self.assertIn(b"Please add more lessons.", c.get("/tutor/apply").data)
        self.assertEqual(self.apply_form(c, "save", title="Marketing Mastery v2").status_code, 302); self.assertEqual(self.apply_form(c, "submit").status_code, 302)
        self.assertEqual(self.row("SELECT status FROM tutor_applications WHERE id=?", (aid,))["status"], "pending")
        self.decide(self.rev, aid, "reject", feedback=""); self.assertEqual(self.row("SELECT status FROM tutor_applications WHERE id=?", (aid,))["status"], "pending")
        self.decide(self.rev, aid, "reject", feedback="Not a fit right now."); self.assertEqual(self.row("SELECT status FROM tutor_applications WHERE id=?", (aid,))["status"], "rejected")
        self.assertEqual(self.row("SELECT role FROM users WHERE id=?", (self.users["eve"],))["role"], "student"); self.assertNotEqual(self.row("SELECT status FROM courses WHERE id=?", (cid,))["status"], "published")
        self.approve(aid); self.assertEqual(self.row("SELECT role FROM users WHERE id=?", (self.users["eve"],))["role"], "student")          # a rejected application cannot be approved
        self.post(c, "/tutor/apply/start"); self.assertEqual(self.val("SELECT COUNT(*) FROM tutor_applications WHERE user_id=?", (self.users["eve"],)), 2)  # may apply again
    def test_validation_on_submit(self):
        c = self.client("eve"); self.post(c, "/tutor/apply/start")
        for kw in (dict(title=""), dict(bio="short"), dict(category_id=""), dict(expected_price=""), dict(website="http://x.com"), dict(phone="")):
            self.apply_form(c, "submit", **kw); self.assertEqual(self.row("SELECT status FROM tutor_applications WHERE user_id=?", (self.users["eve"],))["status"], "draft", kw)
        self.apply_form(c, "save", expected_price="abc"); self.assertEqual(self.row("SELECT status FROM tutor_applications WHERE user_id=?", (self.users["eve"],))["status"], "draft")      # a bad price is reported, nothing breaks
    def test_only_students_apply_and_one_open_application(self):
        for who in ("inst", "writer", "owner"):
            c = self.client(who); self.post(c, "/tutor/apply/start"); self.assertEqual(self.val("SELECT COUNT(*) FROM tutor_applications WHERE user_id=?", (self.users[who],)), 0, who)
        c = self.client("eve"); self.post(c, "/tutor/apply/start"); self.post(c, "/tutor/apply/start"); self.assertEqual(self.val("SELECT COUNT(*) FROM tutor_applications WHERE user_id=?", (self.users["eve"],)), 1)
        S.put("tutor.applications_open", "0"); c2 = self.client("bob"); self.post(c2, "/tutor/apply/start"); self.assertEqual(self.val("SELECT COUNT(*) FROM tutor_applications WHERE user_id=?", (self.users["bob"],)), 0)
    def test_applicant_cannot_use_builder_beyond_their_own_course(self):
        c = self.client("eve"); self.post(c, "/tutor/apply/start"); self.apply_form(c, "save"); cid = self.val("SELECT course_id FROM tutor_applications WHERE user_id=?", (self.users["eve"],))
        self.assertEqual(c.get("/staff/builder").status_code, 403); self.assertEqual(c.get("/staff/catalog").status_code, 403); self.assertEqual(c.get(f"/staff/builder/{self.paid}").status_code, 403)
        self.assertEqual(c.get(f"/staff/builder/{cid}").status_code, 200)
        from tests.test_builder import jpost
        r = jpost(c, self, "/staff/builder/save", {"action": "draft", "title": "Sneaky", "division": "academic", "academic_level": "basic"}); self.assertEqual(r.status_code, 403)       # cannot create other courses
        r = jpost(c, self, "/staff/builder/save", {"id": self.paid, "action": "draft", "title": "Hijack", "division": "academic", "academic_level": "basic"}); self.assertIn(r.status_code, (403, 404))
        self.assertEqual(self.row("SELECT title FROM courses WHERE id=?", (self.paid,))["title"], "Paid Maths")
        # pending => read only
        self.lesson_via_builder(c, cid); self.apply_form(c, "submit")
        self.assertEqual(c.get(f"/staff/builder/{cid}").status_code, 403)
    def test_permissions_on_admin_pages(self):
        c, aid, cid = self.submitted_application()
        for who in (None, "alice", "inst", "writer", "officer", "noperm", "eve"):
            cl = self.app.test_client() if who is None else self.client(who)
            for u in ("/staff/tutors/applications", f"/staff/tutors/applications/{aid}", "/staff/tutors", "/staff/tutors/ledger", f"/staff/tutors/{self.users['inst']}"):
                self.assertIn(cl.get(u).status_code, (302, 403), (who, u))
            if who:
                self.decide(cl, aid, "approve"); self.assertEqual(self.row("SELECT status FROM tutor_applications WHERE id=?", (aid,))["status"], "pending", who)
        self.assertEqual(self.rev.get("/staff/tutors/applications").status_code, 200)
    def test_reviewer_cannot_review_own_application_or_set_rates_without_payout_permission(self):
        self.mk("adm", "admin", perms=["tutors.manage"])
        c, aid, cid = self.submitted_application(); r = self.approve(aid, aff_percent="90"); self.assertEqual(self.row("SELECT status FROM tutor_applications WHERE id=?", (aid,))["status"], "pending")   # reviewer lacks payouts.manage
        self.decide(self.pay, aid, "approve", aff_percent="90", plat_percent="50"); co = self.row("SELECT * FROM courses WHERE id=?", (cid,)); self.assertEqual((co["tutor_affiliate_percent"], co["tutor_platform_percent"]), (90.0, 50.0))
    def test_existing_tutor_new_course_is_reviewed_and_cannot_self_publish(self):
        from tests.test_builder import jpost
        c = self.client("inst2")
        r = jpost(c, self, "/staff/builder/save", {"action": "publish", "title": "Brand New", "division": "income", "category_id": self.cat, "modules": [{"title": "M", "lessons": [{"title": "L", "kind": "text", "body": "b"}]}]}).get_json()
        cid = r["id"]; self.assertEqual(r["status"], "review"); a = self.row("SELECT * FROM tutor_applications WHERE course_id=?", (cid,)); self.assertEqual((a["kind"], a["status"], a["user_id"]), ("course", "pending", self.users["inst2"]))
        self.assertEqual(self.app.test_client().get(f"/courses/{self.val('SELECT slug FROM courses WHERE id=?', (cid,))}").status_code, 404)
        # a course that was never submitted (draft application) cannot be published by anyone
        dbm.ex("UPDATE tutor_applications SET status='draft' WHERE id=?", (a["id"],)); dbm.ex("UPDATE courses SET status='draft' WHERE id=?", (cid,))
        self.post(self.o, f"/staff/catalog/{cid}/status", {"status": "published"}); self.assertEqual(self.row("SELECT status FROM courses WHERE id=?", (cid,))["status"], "draft")
        r = jpost(self.o, self, "/staff/builder/save", {"id": cid, "action": "publish", "title": "Brand New", "division": "income", "category_id": self.cat, "price": "1000", "modules": [{"title": "M", "lessons": [{"title": "L", "kind": "text", "body": "b"}]}]}); self.assertEqual(r.status_code, 400)
        self.assertEqual(self.row("SELECT status FROM courses WHERE id=?", (cid,))["status"], "draft")
        dbm.ex("UPDATE tutor_applications SET status='pending' WHERE id=?", (a["id"],)); dbm.ex("UPDATE courses SET status='review' WHERE id=?", (cid,))
        # revision from the admin, tutor edits and resubmits, then approval publishes at the approved price
        self.decide(self.rev, a["id"], "revision", feedback="Add a quiz"); self.assertEqual(self.row("SELECT status FROM courses WHERE id=?", (cid,))["status"], "draft")
        self.assertIn(b"Add a quiz", c.get("/staff/tutor/submissions").data)
        r = jpost(c, self, "/staff/builder/save", {"id": cid, "action": "publish", "title": "Brand New", "division": "income", "category_id": self.cat, "modules": [{"title": "M", "lessons": [{"title": "L", "kind": "text", "body": "b"}]}]}).get_json()
        self.assertEqual(self.row("SELECT status FROM tutor_applications WHERE id=?", (a["id"],))["status"], "pending"); self.assertEqual(self.val("SELECT COUNT(*) FROM tutor_applications WHERE course_id=?", (cid,)), 1)
        self.approve(a["id"], price="4500"); co = self.row("SELECT * FROM courses WHERE id=?", (cid,)); self.assertEqual((co["status"], co["price_kobo"]), ("published", 450000)); self.assertEqual(self.row("SELECT role FROM users WHERE id=?", (self.users["inst2"],))["role"], "instructor")
    def test_admin_publishing_a_pending_course_counts_as_approval(self):
        c, aid, cid = self.submitted_application()
        self.post(self.o, f"/staff/catalog/{cid}/status", {"status": "published"})
        self.assertEqual(self.row("SELECT status FROM tutor_applications WHERE id=?", (aid,))["status"], "approved"); self.assertEqual(self.row("SELECT role FROM users WHERE id=?", (self.users["eve"],))["role"], "instructor")
        self.assertTrue(self.row("SELECT 1 FROM tutor_profiles WHERE user_id=?", (self.users["eve"],))); self.assertEqual(self.row("SELECT status FROM courses WHERE id=?", (cid,))["status"], "published")
    def test_legacy_review_courses_appear_in_queue(self):
        cid = dbm.ex("INSERT INTO courses(division,title,slug,price_kobo,status,instructor_id) VALUES ('income','Legacy','legacy',100,'review',?)", (self.users["inst"],))
        self.assertIn(b"Legacy", self.rev.get("/staff/tutors/applications").data); self.assertEqual(self.val("SELECT COUNT(*) FROM tutor_applications WHERE course_id=?", (cid,)), 1)
        self.rev.get("/staff/tutors/applications"); self.assertEqual(self.val("SELECT COUNT(*) FROM tutor_applications WHERE course_id=?", (cid,)), 1)

class ReferralCommissionTests(TutBase):
    def setUp(self):
        super().setUp(); self.tc, self.aid, self.cid = self.tutor_with_course(); self.tid_user = self.users["eve"]; self.code = self.val("SELECT code FROM tutor_profiles WHERE user_id=?", (self.tid_user,))
        self.slug = self.val("SELECT slug FROM courses WHERE id=?", (self.cid,)); self.earn = lambda: self.val("SELECT COALESCE(SUM(amount_kobo),0) FROM instructor_earnings WHERE instructor_id=?", (self.tid_user,))
    def visit(self, c, code=None, path=None):
        return c.get(path or f"/course/{self.slug}?ref={code or self.code}", headers={"User-Agent": "Mozilla/5.0 Chrome"})
    def test_referral_sale_pays_97_percent_and_is_recorded_as_tutor_generated(self):
        c = self.client("bob"); self.visit(c); tid, _ = self.sale("bob", self.cid, client=c)
        e = self.earning(tid); self.assertEqual((e["source"], e["percent"], e["amount_kobo"], e["gross_kobo"], e["ref_code"], e["rate_basis"]), ("affiliate", 97.0, round(e["gross_kobo"] * .97), e["gross_kobo"], self.code, "default"))
        self.assertEqual(self.row("SELECT tutor_ref_id FROM transactions WHERE id=?", (tid,))["tutor_ref_id"], self.tid_user)
        sp = T.split(self.tid_user); self.assertEqual((sp["affiliate"]["sales"], sp["platform"]["sales"]), (1, 0))
    def test_organic_sale_uses_the_lower_platform_rate(self):
        tid, _ = self.sale("bob", self.cid); e = self.earning(tid); self.assertEqual((e["source"], e["percent"], e["ref_code"], e["rate_basis"]), ("platform", 40.0, None, "division"))
    def test_rate_is_configurable_not_hardcoded(self):
        S.put("payout.tutor_referral_percent", "80"); c = self.client("bob"); self.visit(c); tid, _ = self.sale("bob", self.cid, client=c); self.assertEqual(self.earning(tid)["percent"], 80.0)
        S.put("payout.max_percent", "70"); c2 = self.client("alice"); self.visit(c2); tid2, _ = self.sale("alice", self.cid, client=c2); self.assertEqual(self.earning(tid2)["percent"], 70.0)       # cap wins over the default
    def test_per_tutor_and_per_course_overrides_priority(self):
        self.post(self.pay, f"/staff/tutors/{self.tid_user}", {"action": "rates", "affiliate_percent": "90", "platform_percent": "55"})
        c = self.client("bob"); self.visit(c); tid, _ = self.sale("bob", self.cid, client=c); e = self.earning(tid); self.assertEqual((e["percent"], e["rate_basis"]), (90.0, "tutor"))
        self.post(self.pay, f"/staff/tutors/{self.tid_user}", {"action": "course_rates", "course_id": str(self.cid), "affiliate_percent": "85", "platform_percent": "35"})
        c2 = self.client("alice"); self.visit(c2); tid2, _ = self.sale("alice", self.cid, client=c2); e = self.earning(tid2); self.assertEqual((e["percent"], e["rate_basis"]), (85.0, "course"))
        self.mk("carl", "student"); tid3, _ = self.sale("carl", self.cid); e = self.earning(tid3); self.assertEqual((e["source"], e["percent"], e["rate_basis"]), ("platform", 35.0, "course"))
        # overrides above the cap, or by someone without payout permission, are refused
        self.post(self.pay, f"/staff/tutors/{self.tid_user}", {"action": "rates", "affiliate_percent": "99", "platform_percent": ""}); self.assertEqual(self.row("SELECT affiliate_percent FROM tutor_profiles WHERE user_id=?", (self.tid_user,))["affiliate_percent"], 90.0)
        self.post(self.rev, f"/staff/tutors/{self.tid_user}", {"action": "rates", "affiliate_percent": "10", "platform_percent": ""}); self.assertEqual(self.row("SELECT affiliate_percent FROM tutor_profiles WHERE user_id=?", (self.tid_user,))["affiliate_percent"], 90.0)
        self.assertEqual(self.pay.get(f"/staff/tutors/{self.tid_user}").status_code, 200)
    def test_rate_change_never_alters_past_sales(self):
        c = self.client("bob"); self.visit(c); tid, _ = self.sale("bob", self.cid, client=c); before = self.earning(tid)["amount_kobo"]; S.put("payout.tutor_referral_percent", "50"); self.assertEqual(self.earning(tid)["amount_kobo"], before)
    def test_attribution_persists_across_sessions_and_devices_for_30_days(self):
        c = self.app.test_client(); self.visit(c); self.assertIn("dda_tref", c.get("/").headers.get("Set-Cookie", "") + str([x for x in c._cookies] if hasattr(c, "_cookies") else ""))
        # anonymous visit, then sign up and buy later in a "new session": the cookie survives (persistent, 30 days)
        sc = [h for h in self.visit(self.app.test_client()).headers.getlist("Set-Cookie") if h.startswith("dda_tref")][0]; self.assertIn("Max-Age=2592000", sc)
        d = self.app.test_client(); self.visit(d); r = d.post("/register", data={"_csrf": "x", "email": "newbie@t.test", "full_name": "New Bie", "password": "Str0ngPass!word", "password2": "Str0ngPass!word"})
        with d.session_transaction() as s: s["_csrf"] = "tok"
        r = self.post(d, "/register", {"email": "newbie@t.test", "full_name": "New Bie", "password": "Str0ngPass!word", "password2": "Str0ngPass!word"}); self.assertEqual(r.status_code, 302)
        uid = self.val("SELECT id FROM users WHERE email='newbie@t.test'"); self.assertEqual(self.val("SELECT tutor_id FROM tutor_referrals WHERE user_id=?", (uid,)), self.tid_user)
        # a different device with no cookie, same account: still attributed (stored on the account)
        e = self.app.test_client(); self.assertEqual(self.post(e, "/login", {"email": "newbie@t.test", "password": "Str0ngPass!word"}).status_code, 302)
        ref = self.buy(e, "course", self.slug, who="alice"); t = self.tx(ref); self.assertEqual(t["tutor_ref_id"], self.tid_user)
    def test_window_expiry(self):
        c = self.client("bob"); self.visit(c); dbm.ex("UPDATE tutor_referrals SET expires_at='2020-01-01 00:00:00', clicked_at='2020-01-01 00:00:00' WHERE user_id=?", (self.users["bob"],))
        c.delete_cookie("dda_tref"); tid, _ = self.sale("bob", self.cid, client=c); self.assertEqual(self.earning(tid)["source"], "platform")
        S.put("tutor.attribution_days", "1"); c2 = self.client("alice"); self.visit(c2); self.assertEqual(T.attribution_days(), 1)
    def test_last_link_wins_and_other_tutors_links_do_not_apply(self):
        c = self.client("alice"); other = self.val("SELECT code FROM tutor_profiles WHERE user_id=?", (self.users["inst2"],)) or T.ensure_profile(self.users["inst2"])["code"]
        self.visit(c, other, f"/courses/{self.slug}?ref={other}"); tid, _ = self.sale("alice", self.cid, client=c); self.assertEqual(self.earning(tid)["source"], "platform")           # inst2's link, eve's course: no credit
    def test_self_referral_blocked(self):
        # the tutor opening their own link with their own account is never attributed
        self.tc.get(f"/course/{self.slug}?ref={self.code}"); self.assertEqual(self.val("SELECT COUNT(*) FROM tutor_referrals WHERE user_id=?", (self.tid_user,)), 0)
        self.assertEqual(self.val("SELECT COUNT(*) FROM tutor_clicks"), 0)
        # same person under another account (same phone number) is treated as the tutor
        self.mk("eve2", "student"); dbm.ex("UPDATE users SET phone=? WHERE id IN (?,?)", ("08030000001", self.users["eve2"], self.tid_user)); c = self.client("eve2"); self.visit(c); tid, _ = self.sale("eve2", self.cid, client=c)
        self.assertEqual(self.earning(tid)["source"], "platform"); self.assertEqual(self.val("SELECT tutor_ref_id FROM transactions WHERE id=?", (tid,)), None)
    def test_no_duplicate_commission_and_idempotent_approval(self):
        c = self.client("bob"); self.visit(c); tid, _ = self.sale("bob", self.cid, client=c)
        for _ in range(3): self.post(self.client("officer"), f"/staff/payments/{tid}", {"action": "approve", "confirm": "1", "verified_funds": "1"})
        self.assertEqual(self.val("SELECT COUNT(*) FROM instructor_earnings WHERE transaction_id=?", (tid,)), 1)
    def test_refund_reverses_the_referral_commission(self):
        c = self.client("bob"); self.visit(c); tid, _ = self.sale("bob", self.cid, client=c); self.assertGreater(self.earn(), 0)
        self.post(self.client("refunder"), f"/staff/payments/{tid}", {"action": "refund", "text": "x", "confirm": "1"}); rows = dbm.q("SELECT kind, source, amount_kobo FROM instructor_earnings WHERE transaction_id=? ORDER BY id", (tid,))
        self.assertEqual([(r["kind"], r["source"]) for r in rows], [("sale", "affiliate"), ("reversal", "affiliate")]); self.assertEqual(self.earn(), 0)
    def test_influencer_affiliate_never_double_pays_a_tutor_referral_sale(self):
        from dagba.services import affiliates as A
        aff = dbm.ex("INSERT INTO affiliates(user_id,slug,percent) VALUES (?,?,?)", (self.users["alice"], "influ", 20.0)); dbm.ex("UPDATE users SET referred_by_affiliate=? WHERE id=?", (aff, self.users["bob"]))
        tid, _ = self.sale("bob", self.cid); self.assertEqual(self.val("SELECT COUNT(*) FROM affiliate_earnings WHERE transaction_id=?", (tid,)), 1)                    # organic: both paid, within 100%
        c = self.client("bob"); self.mk("dan", "student"); dbm.ex("UPDATE users SET referred_by_affiliate=? WHERE id=?", (aff, self.users["dan"])); cd = self.client("dan"); self.visit(cd)
        tid2, _ = self.sale("dan", self.cid, client=cd); self.assertEqual(self.earning(tid2)["source"], "affiliate"); self.assertEqual(self.val("SELECT COUNT(*) FROM affiliate_earnings WHERE transaction_id=?", (tid2,)), 0)   # tutor link wins: one commission only
    def test_codes_and_slugs_never_collide(self):
        from dagba.services import affiliates as A
        with self.assertRaises(A.AffError): A.check_slug(self.code)
    def test_bots_and_suspended_tutors_do_not_attribute(self):
        c = self.client("bob"); c.get(f"/course/{self.slug}?ref={self.code}", headers={"User-Agent": "facebookexternalhit/1.1"}); self.assertEqual(self.val("SELECT COUNT(*) FROM tutor_clicks"), 0)
        self.assertEqual(self.app.test_client().get(f"/course/{self.slug}?ref=nope").status_code, 200)

class WithdrawalAndSuspensionTests(TutBase):
    def setUp(self):
        super().setUp(); self.tc, self.aid, self.cid = self.tutor_with_course(); self.uid = self.users["eve"]; self.code = self.val("SELECT code FROM tutor_profiles WHERE user_id=?", (self.uid,)); self.slug = self.val("SELECT slug FROM courses WHERE id=?", (self.cid,))
    def referral_sale(self, who="bob"):
        c = self.client(who); c.get(f"/course/{self.slug}?ref={self.code}", headers={"User-Agent": "Mozilla/5.0"}); slug = self.slug; ref = self.buy(c, "course", slug, who=who); t = self.tx(ref)
        self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"}); return t["id"]
    def test_purchase_to_earnings_to_withdrawal_end_to_end(self):
        tid = self.referral_sale(); price = self.val("SELECT amount_kobo FROM transactions WHERE id=?", (tid,)); earned = round(price * .97)
        s = PO.summary(self.uid); self.assertEqual((s["earned"], s["available"], s["pending_total"]), (earned, earned, 0))
        page = self.tc.get("/staff/earnings").data.decode(); self.assertIn("Pending balance", page); self.assertIn("My link", page)
        self.assertEqual(self.post(self.tc, "/staff/earnings/account", {"bank": "GTBank", "account_name": "Eve T", "account_number": "0123456789"}).status_code, 302)
        r = self.post(self.tc, "/staff/earnings/request", {"amount": str(earned / 100)}, follow_redirects=True); rid = self.val("SELECT id FROM payout_requests"); self.assertTrue(rid)
        s = PO.summary(self.uid); self.assertEqual((s["available"], s["pending"], s["pending_total"]), (0, earned, earned))
        r = self.post(self.pay, f"/staff/payouts/{rid}", {"action": "pay", "confirm": "1", "reference": "TRX1", "receipt": (io.BytesIO(png_bytes()), "r.png")}, content_type="multipart/form-data", follow_redirects=True)
        s = PO.summary(self.uid); self.assertEqual((s["paid"], s["available"], s["pending"]), (earned, 0, 0)); self.assertEqual(self.row("SELECT status FROM payout_requests WHERE id=?", (rid,))["status"], "paid")
        self.assertIn("Paid", self.tc.get("/staff/earnings").data.decode())
    def test_hold_period_shows_pending_then_available(self):
        S.put("payout.hold_days", "7"); tid = self.referral_sale(); s = PO.summary(self.uid); self.assertEqual((s["available"], s["clearing"] > 0, s["pending_total"] == s["clearing"]), (0, True, True))
        self.post(self.tc, "/staff/earnings/account", {"bank": "GTBank", "account_name": "Eve T", "account_number": "0123456789"}); self.post(self.tc, "/staff/earnings/request", {"amount": "1"}, follow_redirects=True); self.assertEqual(self.val("SELECT COUNT(*) FROM payout_requests"), 0)
        dbm.ex("UPDATE instructor_earnings SET created_at='2020-01-01 00:00:00'"); s = PO.summary(self.uid); self.assertEqual((s["clearing"], s["available"] > 0), (0, True))
    def test_tutor_sees_only_own_data(self):
        self.referral_sale(); inst = self.client("inst2")
        for u in ("/staff/tutor/reports", "/staff/tutor/links", "/staff/tutor/submissions", "/staff/earnings"):
            h = inst.get(u).data.decode(); self.assertNotIn("Marketing Mastery", h, u); self.assertNotIn(self.code, h, u)
        self.assertNotIn("Marketing Mastery", inst.get("/staff/tutor/reports.csv").data.decode())
        mine = self.tc.get("/staff/tutor/reports.csv").data.decode(); self.assertIn("Marketing Mastery", mine)
        for who in ("alice", "writer"):
            for u in ("/staff/tutor/reports", "/staff/tutor/links", "/staff/tutor/submissions", "/staff/tutor/profile"): self.assertEqual(self.client(who).get(u).status_code, 403, (who, u))
        self.assertIn(self.code, self.tc.get("/staff/tutor/links").data.decode()); self.assertIn(f"/course/{self.slug}?ref={self.code}", self.tc.get("/staff/tutor/links").data.decode())
    def test_separate_reports_for_referral_and_platform_sales(self):
        self.referral_sale("bob"); c = self.client("alice"); ref = self.buy(c, "course", self.slug, who="alice"); t = self.tx(ref); self.post(self.client("officer"), f"/staff/payments/{t['id']}", {"action": "approve", "confirm": "1", "verified_funds": "1"})
        sp = T.split(self.uid); self.assertEqual((sp["affiliate"]["sales"], sp["platform"]["sales"]), (1, 1)); self.assertGreater(sp["affiliate"]["earned"], sp["platform"]["earned"])
        h = self.tc.get("/staff/tutor/reports").data.decode(); self.assertIn("My referral link", h); self.assertIn("Dagba website", h)
        a = self.pay.get("/staff/tutors/ledger?source=affiliate").data.decode(); self.assertIn("Referral", a); csvd = self.pay.get("/staff/tutors/ledger.csv").data.decode(); self.assertIn("Tutor referral", csvd); self.assertIn("Dagba website", csvd)
        st = T.link_stats(self.uid); self.assertEqual(st[2]["sales"], 1)
    def test_suspension_hides_courses_blocks_withdrawals_and_is_reversible(self):
        tid = self.referral_sale(); self.post(self.tc, "/staff/earnings/account", {"bank": "GTBank", "account_name": "Eve T", "account_number": "0123456789"})
        r = self.post(self.rev, f"/staff/tutors/{self.uid}", {"action": "suspend", "reason": ""}); self.assertEqual(self.row("SELECT status FROM tutor_profiles WHERE user_id=?", (self.uid,))["status"], "active")
        self.post(self.rev, f"/staff/tutors/{self.uid}", {"action": "suspend", "reason": "Policy breach"}); self.assertEqual(self.row("SELECT status FROM tutor_profiles WHERE user_id=?", (self.uid,))["status"], "suspended")
        self.assertEqual(self.app.test_client().get(f"/courses/{self.slug}").status_code, 404)
        self.post(self.tc, "/staff/earnings/request", {"amount": "10"}, follow_redirects=True); self.assertEqual(self.val("SELECT COUNT(*) FROM payout_requests"), 0)
        self.assertEqual(self.tc.get("/staff/builder").status_code, 403)
        self.assertEqual(self.app.test_client().get(f"/tutors/{self.code}").status_code, 404)
        self.post(self.rev, f"/staff/tutors/{self.uid}", {"action": "unsuspend"}); self.assertEqual(self.app.test_client().get(f"/courses/{self.slug}").status_code, 200); self.assertEqual(self.tc.get("/staff/builder").status_code, 200)
        self.assertEqual(self.app.test_client().get(f"/tutors/{self.code}").status_code, 200)
    def test_public_profile_and_instructor_section_show_picture_and_link(self):
        self.post(self.tc, "/account", {"action": "avatar", "picture": (io.BytesIO(jpg(600, 600)), "me.jpg")}, content_type="multipart/form-data")
        av = self.row("SELECT avatar FROM users WHERE id=?", (self.uid,))["avatar"]; self.assertTrue(av)
        h = self.app.test_client().get(f"/course/{self.slug}").data.decode(); self.assertIn("Your instructor", h); self.assertIn(av, h); self.assertIn(f"/tutors/{self.code}", h); self.assertIn("Plan a campaign", h)
        p = self.app.test_client().get(f"/tutors/{self.code}").data.decode(); self.assertIn(av, p); self.assertIn("Marketing Mastery", p)

class ProfilePictureTests(TutBase):
    def up(self, c, data, name="me.jpg", url="/account"): return self.post(c, url, {"action": "avatar", "picture": (io.BytesIO(data), name)}, content_type="multipart/form-data", follow_redirects=False)
    def av(self, who): return self.row("SELECT avatar FROM users WHERE id=?", (self.users[who],))["avatar"]
    def files(self): d = self.app.config["PUBLIC_DIR"]; return sorted(f for f in os.listdir(d) if f.startswith("av-")) if os.path.isdir(d) else []
    def test_upload_display_update_removal_for_every_role(self):
        for who in ("alice", "inst", "writer", "officer"):
            c = self.client(who); acct = c.get("/account").data.decode(); self.assertIn("Profile picture", acct); self.assertIn('class="av av-xl av-c', acct)           # initials by default
            self.assertIsNone(self.av(who))
            self.assertEqual(self.up(c, jpg(1200, 900)).status_code, 302); a1 = self.av(who); self.assertTrue(a1 and a1.startswith("av-")); self.assertIn(a1, self.files())
            im = Image.open(os.path.join(self.app.config["PUBLIC_DIR"], a1)); self.assertEqual(im.size, (256, 256))                                                   # square, resized
            self.assertEqual(self.app.test_client().get(f"/media/{a1}").status_code, 200)
            for page in ("/account", "/staff/" if who != "alice" else "/student", "/"): self.assertIn(a1, c.get(page).data.decode(), (who, page))                  # sidebar, dashboard, account menu
            self.assertEqual(self.up(c, png_bytes(), "x.png").status_code, 302); a2 = self.av(who); self.assertNotEqual(a1, a2); self.assertNotIn(a1, self.files()); self.assertIn(a2, c.get("/account").data.decode())   # replaced, old file gone
            r = self.post(c, "/account", {"action": "avatar_remove"}); self.assertEqual(r.status_code, 302); self.assertIsNone(self.av(who)); self.assertNotIn(a2, self.files()); self.assertNotIn(a2, c.get("/account").data.decode())
    def test_admin_can_manage_any_picture(self):
        self.assertEqual(self.up(self.client("alice"), jpg()).status_code, 302); a = self.av("alice")
        r = self.post(self.o, f"/staff/users/{self.users['alice']}", {"action": "avatar_remove"}); self.assertIsNone(self.av("alice")); self.assertNotIn(a, self.files())
        r = self.post(self.o, f"/staff/users/{self.users['alice']}", {"action": "avatar", "picture": (io.BytesIO(jpg()), "a.jpg")}, content_type="multipart/form-data"); self.assertTrue(self.av("alice"))
        self.assertIn(self.av("alice"), self.o.get(f"/staff/users/{self.users['alice']}").data.decode()); self.assertIn(self.av("alice"), self.o.get("/staff/users").data.decode())
        self.post(self.client("bob"), f"/staff/users/{self.users['alice']}", {"action": "avatar_remove"}); self.assertTrue(self.av("alice"))                         # students cannot
    def test_validation_rejects_bad_files_and_keeps_old_picture(self):
        c = self.client("alice"); self.up(c, jpg()); good = self.av("alice")
        for data, name in ((b"not an image", "a.jpg"), (PDF, "a.jpg"), (b"GIF89a....", "a.gif"), (jpg(), "a.png"), (png_bytes()[:40], "t.png"), (b"", "e.jpg"), (b"<svg xmlns='http://www.w3.org/2000/svg'/>", "a.svg")):
            r = self.up(c, data, name); self.assertEqual(r.status_code, 302, name); self.assertEqual(self.av("alice"), good, name)
        self.assertEqual(self.files(), [good])
        big = b"\xff\xd8\xff" + b"0" * (avatars.MAX_BYTES + 10); self.up(c, big, "big.jpg"); self.assertEqual(self.av("alice"), good)
        self.assertEqual(c.post("/account", data={"_csrf": self.tok(c), "action": "avatar"}).status_code, 302)                                                     # no file at all
    def test_formats_jpg_png_webp_and_transparency(self):
        c = self.client("alice")
        b = io.BytesIO(); Image.new("RGBA", (400, 300), (0, 0, 0, 0)).save(b, "PNG"); self.assertEqual(self.up(c, b.getvalue(), "t.png").status_code, 302); self.assertTrue(self.av("alice"))
        b = io.BytesIO(); Image.new("RGB", (300, 500), (5, 5, 200)).save(b, "WEBP"); self.up(c, b.getvalue(), "w.webp"); self.assertTrue(self.av("alice")); self.assertEqual(Image.open(os.path.join(self.app.config["PUBLIC_DIR"], self.av("alice"))).size, (256, 256))
        self.up(c, jpg(), "photo.jpeg"); self.assertTrue(self.av("alice"))
    def test_picture_is_never_required_and_registration_unaffected(self):
        r = self.post(self.app.test_client(), "/register", {"email": "nopic@t.test", "full_name": "No Pic", "password": "Str0ngPass!word", "password2": "Str0ngPass!word"}); self.assertEqual(r.status_code, 302); self.assertIsNone(self.row("SELECT avatar FROM users WHERE email='nopic@t.test'")["avatar"])
        self.assertNotIn(b'name="picture" accept="image/jpeg,image/png,image/webp" required', self.app.test_client().get("/register").data)
        c = self.client("alice"); self.assertEqual(c.get("/student").status_code, 200)
    def test_initials_and_rate_limit_and_csrf(self):
        self.assertEqual(avatars.initials("Ada Lovelace"), "AL"); self.assertEqual(avatars.initials("  cher "), "C"); self.assertEqual(avatars.initials(""), "?"); self.assertEqual(avatars.initials("Mary-Jane O'Neil"), "MO")
        c = self.client("alice"); self.assertIn(b"av av-md av-c", c.get("/student").data)
        r = c.post("/account", data={"action": "avatar_remove"}); self.assertEqual(r.status_code, 400)
    def test_application_form_picture_is_optional_and_updates_profile(self):
        c = self.client("eve"); self.post(c, "/tutor/apply/start"); d = TutBase.form(self); d.update(_csrf=self.tok(c), action="save", cover=(io.BytesIO(jpg()), "c.jpg"), avatar=(io.BytesIO(jpg(500, 500)), "me.jpg"))
        c.post("/tutor/apply/save", data=d, content_type="multipart/form-data"); self.assertTrue(self.av("eve"))
