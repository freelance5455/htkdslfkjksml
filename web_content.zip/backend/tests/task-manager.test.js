import { test, before } from 'node:test';
import assert from 'node:assert/strict';
import { setupTestEnv } from './helpers/setup-test-env.js';

setupTestEnv();
const { runMigrations } = await import('../src/database/migrate.js');
const { TaskManager } = await import('../src/core/task-manager.js');

before(() => {
  runMigrations();
});

function waitFor(conditionFn, { timeoutMs = 3000, intervalMs = 20 } = {}) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const timer = setInterval(() => {
      if (conditionFn()) {
        clearInterval(timer);
        resolve();
      } else if (Date.now() - start > timeoutMs) {
        clearInterval(timer);
        reject(new Error('Timeout aguardando condicao da tarefa.'));
      }
    }, intervalMs);
  });
}

test('TaskManager: executa uma tarefa simples com sucesso', async () => {
  const tm = new TaskManager({ concurrency: 2 });
  tm.registerHandler('echo', async (task) => ({ echoed: task.payload.value }));

  const task = tm.enqueue({ type: 'echo', payload: { value: 123 } });
  await waitFor(() => tm.getTask(task.id).status === 'completed');

  const final = tm.getTask(task.id);
  assert.equal(final.status, 'completed');
  assert.deepEqual(final.result, { echoed: 123 });
});

test('TaskManager: respeita o limite de concorrencia', async () => {
  const tm = new TaskManager({ concurrency: 2 });
  let concurrentNow = 0;
  let maxConcurrent = 0;

  tm.registerHandler('slow', async () => {
    concurrentNow++;
    maxConcurrent = Math.max(maxConcurrent, concurrentNow);
    await new Promise((r) => setTimeout(r, 100));
    concurrentNow--;
    return {};
  });

  const tasks = Array.from({ length: 5 }, () => tm.enqueue({ type: 'slow', payload: {} }));
  await waitFor(() => tasks.every((t) => tm.getTask(t.id).status === 'completed'), { timeoutMs: 5000 });

  assert.ok(maxConcurrent <= 2, `Esperado no maximo 2 tarefas simultaneas, mas rodaram ${maxConcurrent}`);
});

test('TaskManager: tenta novamente apos falha e eventualmente conclui', async () => {
  const tm = new TaskManager({ concurrency: 2, maxAttempts: 3 });
  let attempts = 0;

  tm.registerHandler('flaky', async () => {
    attempts++;
    if (attempts < 3) throw new Error('falha simulada');
    return { recovered: true };
  });

  const task = tm.enqueue({ type: 'flaky', payload: {} });
  await waitFor(() => ['completed', 'failed'].includes(tm.getTask(task.id).status), { timeoutMs: 3000 });

  const final = tm.getTask(task.id);
  assert.equal(final.status, 'completed');
  assert.equal(attempts, 3);
});

test('TaskManager: marca como failed apos exceder o numero maximo de tentativas', async () => {
  const tm = new TaskManager({ concurrency: 2, maxAttempts: 2 });
  tm.registerHandler('always-fails', async () => {
    throw new Error('sempre falha');
  });

  const task = tm.enqueue({ type: 'always-fails', payload: {} });
  await waitFor(() => tm.getTask(task.id).status === 'failed', { timeoutMs: 3000 });

  const final = tm.getTask(task.id);
  assert.equal(final.status, 'failed');
  assert.equal(final.attempts, 2);
  assert.match(final.error, /sempre falha/);
});

test('TaskManager: cancela uma tarefa ainda na fila (antes de comecar)', async () => {
  const tm = new TaskManager({ concurrency: 1 });
  tm.registerHandler('blocker', async () => {
    await new Promise((r) => setTimeout(r, 300));
    return {};
  });
  tm.registerHandler('queued-task', async () => ({ done: true }));

  // ocupa o unico slot de concorrencia
  tm.enqueue({ type: 'blocker', payload: {} });
  const toCancel = tm.enqueue({ type: 'queued-task', payload: {} });

  const cancelled = tm.cancel(toCancel.id);
  assert.equal(cancelled.status, 'cancelled');

  await new Promise((r) => setTimeout(r, 400));
  const final = tm.getTask(toCancel.id);
  assert.equal(final.status, 'cancelled');
});

test('TaskManager: lanca erro claro ao enfileirar tipo sem handler registrado', () => {
  const tm = new TaskManager();
  assert.throws(
    () => tm.enqueue({ type: 'tipo.inexistente', payload: {} }),
    /Nenhum handler registrado/
  );
});

test('TaskManager: getStats reflete contagens reais', async () => {
  const tm = new TaskManager({ concurrency: 3 });
  tm.registerHandler('stat-test', async () => ({}));

  // O banco e compartilhado por todos os testes deste arquivo (mesmo arquivo
  // de teste = mesmo processo = mesma conexao singleton), entao comparamos a
  // VARIACAO causada por esta tarefa, nao o valor absoluto da tabela inteira.
  const before = tm.getStats();
  const t = tm.enqueue({ type: 'stat-test', payload: {} });
  await waitFor(() => tm.getTask(t.id).status === 'completed');

  const after = tm.getStats();
  assert.equal(after.completed, before.completed + 1);
  assert.equal(after.concurrencyLimit, 3);
});


test('TaskManager: recupera tarefas queued e processing apos reinicializacao', async () => {
  const { taskRepository } = await import('../src/database/repositories/task-repository.js');
  const interrupted = taskRepository.create({ type: 'resume-test', payload: { value: 'interrompida' } });
  taskRepository.updateStatus(interrupted.id, 'processing');
  const waiting = taskRepository.create({ type: 'resume-test', payload: { value: 'na-fila' } });

  const restartedManager = new TaskManager({ concurrency: 1 });
  restartedManager.registerHandler('resume-test', async (task) => ({ resumed: task.payload.value }));
  const recovery = restartedManager.recoverPendingTasks();
  assert.ok(recovery.queuedForResume >= 2);

  await waitFor(() => restartedManager.getTask(interrupted.id).status === 'completed'
    && restartedManager.getTask(waiting.id).status === 'completed');
  assert.deepEqual(restartedManager.getTask(interrupted.id).result, { resumed: 'interrompida' });
  assert.deepEqual(restartedManager.getTask(waiting.id).result, { resumed: 'na-fila' });
});

test('TaskManager: nao ultrapassa limite de tentativas ao recuperar tarefa interrompida', async () => {
  const { taskRepository } = await import('../src/database/repositories/task-repository.js');
  const exhausted = taskRepository.create({ type: 'never-run-again', payload: {} });
  taskRepository.updateStatus(exhausted.id, 'processing');
  taskRepository.incrementAttempts(exhausted.id);
  taskRepository.incrementAttempts(exhausted.id);

  const restartedManager = new TaskManager({ concurrency: 1, maxAttempts: 2 });
  restartedManager.registerHandler('never-run-again', async () => ({ shouldNotRun: true }));
  restartedManager.recoverPendingTasks();

  const final = restartedManager.getTask(exhausted.id);
  assert.equal(final.status, 'failed');
  assert.match(final.error, /Limite de tentativas atingido/);
});
