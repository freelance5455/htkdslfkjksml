import base64, json, datetime as dt
from unittest import mock
from tests.base import Base, PW
from dagba import db as dbm
from dagba.services import store_verify as V, store_billing as SB, access

def fake(product, txn, orig=None, state="active", exp="2999-01-01 00:00:00"):
    return dict(product_id=product, store_txn_id=txn, original_txn_id=orig or txn, purchased_at="2026-01-01 00:00:00", expires_at=exp, environment="sandbox", amount_micros=None, currency=None, state=state)

class StoreBilling(Base):
    def setUp(self):
        super().setUp(); self.c = self.app.test_client(); self.ta = self.login("alice"); self.tb = self.login("bob")
    def login(self, who): return self.c.post("/api/v1/auth/login", json={"email": f"{who}@t.test", "password": PW}).get_json()["access_token"]
    def verify(self, tok, platform="google_play", product=None, **kw):
        body = dict(platform=platform, product_id=product, purchase_token="t" * 40, kind="subscription" if product and ".plan." in product else "product", transaction_id="1000"); body.update(kw)
        r = self.c.post("/api/v1/store/verify", json=body, headers={"Authorization": f"Bearer {tok}"}); return r, (r.get_json(silent=True) or {})

    def test_unconfigured_store_is_503_never_a_grant(self):
        r, d = self.verify(self.ta, product=f"dagba.course.{self.paid}"); self.assertEqual(r.status_code, 503); self.assertEqual(d["error"]["code"], "store_unavailable")
        self.assertEqual(self.val("SELECT COUNT(*) FROM entitlements WHERE user_id=?", (self.users["alice"],)), 0)

    def test_requires_login_and_known_product(self):
        self.assertEqual(self.c.post("/api/v1/store/verify", json={"platform": "google_play"}).status_code, 401)
        self.assertEqual(self.verify(self.ta, product="dagba.hack.1")[0].status_code, 400)
        self.assertEqual(self.verify(self.ta, platform="paypal", product="x")[0].status_code, 400)

    def test_course_purchase_grants_access_and_is_idempotent(self):
        pid = f"dagba.course.{self.inc}"
        with mock.patch.object(V, "verify", return_value=fake(pid, "GPA.1")):
            r, d = self.verify(self.ta, product=pid); self.assertEqual(r.status_code, 200, d); self.assertTrue(d["granted"])
            r, d = self.verify(self.ta, product=pid); self.assertEqual(r.status_code, 200); self.assertFalse(d["granted"])          # restore/replay by the same user
            self.assertEqual(self.val("SELECT COUNT(*) FROM entitlements WHERE user_id=? AND course_id=?", (self.users["alice"], self.inc)), 1)
            r, d = self.verify(self.tb, product=pid); self.assertEqual(r.status_code, 409); self.assertEqual(d["error"]["code"], "linked_elsewhere")      # a receipt cannot be reused on another account
        self.assertEqual(self.val("SELECT status FROM transactions WHERE user_id=?", (self.users["alice"],)), "approved")
        self.assertEqual(self.val("SELECT method FROM transactions WHERE user_id=?", (self.users["alice"],)), "google_play")
        self.assertEqual(self.c.get("/api/v1/learn/marketing", headers={"Authorization": f"Bearer {self.ta}"}).status_code, 200)

    def test_academic_subscription_does_not_unlock_income(self):
        pid = f"dagba.plan.{self.plan_a}"
        with mock.patch.object(V, "verify", return_value=fake(pid, "GPA.2")): self.assertEqual(self.verify(self.ta, product=pid)[0].status_code, 200)
        s = access.subscription_status(self.users["alice"]); self.assertIsNotNone(s["basic"]); self.assertIsNone(s["income"]); self.assertIsNone(s["advanced"])
        self.assertEqual(self.c.get("/api/v1/learn/marketing", headers={"Authorization": f"Bearer {self.ta}"}).status_code, 403)
        pid2 = f"dagba.plan.{self.plan_i}"
        with mock.patch.object(V, "verify", return_value=fake(pid2, "GPA.3")): self.assertEqual(self.verify(self.ta, product=pid2)[0].status_code, 200)
        self.assertIsNotNone(access.subscription_status(self.users["alice"])["income"])

    def test_renewal_stacks_time_and_refund_revokes(self):
        pid = f"dagba.plan.{self.plan_a}"
        for n in ("R1", "R2"):
            with mock.patch.object(V, "verify", return_value=fake(pid, n, orig="SUB1")): self.assertEqual(self.verify(self.ta, product=pid)[0].status_code, 200)
        self.assertEqual(self.val("SELECT COUNT(*) FROM entitlements WHERE user_id=? AND kind='subscription'", (self.users["alice"],)), 2)
        with self.app.app_context(): self.assertTrue(SB.revoke("google_play", "R1")); self.assertFalse(SB.revoke("google_play", "R1"))
        self.assertEqual(self.val("SELECT status FROM store_purchases WHERE store_txn_id='R1'"), "refunded")
        self.assertEqual(self.val("SELECT COUNT(*) FROM entitlements WHERE user_id=? AND revoked_at IS NOT NULL", (self.users["alice"],)), 1)
        self.assertEqual(self.val("SELECT status FROM store_purchases WHERE store_txn_id='R2'"), "verified")

    def test_expired_and_refunded_proofs_rejected(self):
        pid = f"dagba.plan.{self.plan_a}"
        for st in ("expired", "refunded"):
            with mock.patch.object(V, "verify", return_value=fake(pid, "X" + st, state=st)): self.assertEqual(self.verify(self.ta, product=pid)[0].status_code, 409)
        self.assertEqual(self.val("SELECT COUNT(*) FROM entitlements WHERE user_id=?", (self.users["alice"],)), 0)

    def test_store_rejection_grants_nothing(self):
        with mock.patch.object(V, "verify", side_effect=V.StoreRejected("no")): self.assertEqual(self.verify(self.ta, product=f"dagba.course.{self.paid}")[0].status_code, 400)
        self.assertEqual(self.val("SELECT COUNT(*) FROM store_purchases"), 0)

    def test_catalogue_lists_only_sellable_items(self):
        dbm.ex("UPDATE plans SET active=0 WHERE id=?", (self.plan_i,))
        ids = {p["product_id"] for p in self.c.get("/api/v1/store/products").get_json()["products"]}
        self.assertIn(f"dagba.plan.{self.plan_a}", ids); self.assertNotIn(f"dagba.plan.{self.plan_i}", ids); self.assertIn(f"dagba.course.{self.paid}", ids); self.assertNotIn(f"dagba.course.{self.free}", ids)

    def test_apple_jws_chain_verification(self):
        from cryptography import x509
        from cryptography.x509.oid import NameOID
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import ec, utils
        def cert(subj, key, issuer, ikey):
            n = lambda c: x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, c)]); t = dt.datetime.now(dt.timezone.utc)
            return x509.CertificateBuilder().subject_name(n(subj)).issuer_name(n(issuer)).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(t - dt.timedelta(days=1)).not_valid_after(t + dt.timedelta(days=30)).add_extension(x509.BasicConstraints(ca=True, path_length=None), True).sign(ikey, hashes.SHA256())
        rk, lk = ec.generate_private_key(ec.SECP256R1()), ec.generate_private_key(ec.SECP256R1()); rc = cert("root", rk, "root", rk); lc = cert("leaf", lk, "root", rk)
        b = lambda x: base64.urlsafe_b64encode(x).rstrip(b"=").decode(); h = b(json.dumps({"alg": "ES256", "x5c": [base64.b64encode(lc.public_bytes(serialization.Encoding.DER)).decode(), base64.b64encode(rc.public_bytes(serialization.Encoding.DER)).decode()]}).encode())
        c = b(json.dumps({"productId": "dagba.plan.1", "transactionId": "9"}).encode()); r, s = utils.decode_dss_signature(lk.sign(f"{h}.{c}".encode(), ec.ECDSA(hashes.SHA256()))); jws = f"{h}.{c}.{b(r.to_bytes(32, 'big') + s.to_bytes(32, 'big'))}"
        root_pem = rc.public_bytes(serialization.Encoding.PEM)
        self.assertEqual(V.decode_apple_jws(jws, root_pem)["transactionId"], "9")
        with self.assertRaises(Exception): V.decode_apple_jws(jws.rsplit(".", 1)[0] + "." + b(b"\x01" * 64), root_pem)         # tampered signature
        other = ec.generate_private_key(ec.SECP256R1()); orc = cert("root", other, "root", other)
        with self.assertRaises(Exception): V.decode_apple_jws(jws, orc.public_bytes(serialization.Encoding.PEM))                    # not chained to the trusted root

class PushTests(Base):
    def test_push_is_noop_without_credentials_and_cleans_dead_tokens(self):
        from dagba.services import push, notify
        uid = self.users["alice"]; dbm.ex("INSERT INTO device_tokens(user_id,platform,token) VALUES (?,?,?)", (uid, "android", "f" * 40))
        self.assertEqual(push.send(uid, "t"), 0)                       # not configured: nothing sent, nothing raised
        notify.notify(uid, "Title", "Body", "/x", "announcement")      # the website's normal notification path still works
        self.assertEqual(self.val("SELECT COUNT(*) FROM notifications WHERE user_id=?", (uid,)), 1)
        with mock.patch.object(push, "configured", return_value=(True, "/f.json")), mock.patch("builtins.open", mock.mock_open(read_data='{"project_id":"p"}')), \
             mock.patch.object(V, "service_account_token", return_value="tok"), mock.patch.object(push, "_post", return_value="dead"):
            push.send(uid, "t")
        self.assertEqual(self.val("SELECT COUNT(*) FROM device_tokens"), 0)
