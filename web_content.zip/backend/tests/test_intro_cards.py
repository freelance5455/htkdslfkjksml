"""Intro Cards: admin-controlled icons (searchable Lucide picker) and the animated carousel markup."""
import json, re
from .base import *
from dagba.services import icons as IC, settings as S, content as C

class IntroBase(Base):
    def setUp(self):
        super().setUp(); self.o = self.client("owner"); self.pub = self.app.test_client()
    def home(self): return self.pub.get("/").data.decode()
    def intro(self, h=None):
        h = h or self.home(); m = re.search(r'<section class="block"><div class="wrap"><h2>What is[^<]*</h2>(.*?)</section>', h, re.S); return m.group(1) if m else ""
    def set_cards(self, text):
        """Post the whole 'Homepage text' group the way the real form does, with only the intro cards changed."""
        d = {f["key"] if False else "c." + f["key"]: S.get("c." + f["key"], "") or "" for f in [fs for gid, _, _, fs in C.GROUPS if gid == "home"][0]}; d["c.home.what_cards"] = text; return self.post(self.o, "/staff/settings/c_home", d)
    def save(self, **icons):
        n = len(IC.intro_cards()); d = {"_csrf": self.tok(self.o)}
        for i in range(n): d[f"icon_{i}"] = icons.get(str(i), ""); d[f"title_{i}"] = IC.intro_cards()[i]["title"]
        return self.o.post("/staff/intro-icons", data=d)

class AdminIconTests(IntroBase):
    def test_page_lists_cards_with_picker_and_is_in_the_menu(self):
        r = self.o.get("/staff/intro-icons"); h = r.data.decode(); self.assertEqual(r.status_code, 200)
        for t in ("Academic learning", "Income skills", "iisearch", "Restore default icons", "Save icons", "intro_icons_admin.js", "lucide-subset.json"): self.assertIn(t, h)
        self.assertEqual(h.count('class="iirow"'), 2); self.assertIn("Intro card icons", self.o.get("/staff/").data.decode()); self.assertIn("/staff/intro-icons", self.o.get("/staff/content").data.decode())
    def test_permissions(self):
        for who in ("alice", "writer", "officer", "inst"): self.assertEqual(self.client(who).get("/staff/intro-icons").status_code, 403, who)
        self.assertEqual(self.pub.get("/staff/intro-icons").status_code, 302)
        r = self.client("alice").post("/staff/intro-icons", data={"action": "reset", "_csrf": self.tok(self.client("alice"))}); self.assertIn(r.status_code, (400, 403))
    def test_icon_saved_in_database_shown_on_homepage_and_persists(self):
        before = self.intro(); self.assertEqual(before.count("<svg"), 2); self.assertNotIn("lucide", before)
        r = self.save(**{"0": "rocket", "1": "banknote"}); self.assertEqual(r.status_code, 302)
        self.assertIn("rocket|banknote", "|".join(c["icon"] for c in IC.intro_cards()))
        stored = dbm.val("SELECT value FROM settings WHERE key='c.home.what_cards'"); self.assertIn("| rocket", stored); self.assertIn("| banknote", stored)      # persisted in the existing settings table
        for _ in range(2):                                                                                                                              # still there on every refresh
            h = self.intro(); self.assertIn(IC.lucide("rocket").split(">", 1)[1][:40], h); self.assertIn(IC.lucide("banknote").split(">", 1)[1][:40], h)
        self.assertNotEqual(self.intro(), before); self.assertIn("Academic learning", self.intro()); self.assertIn("/academic", self.intro())          # wording and links untouched
        page = self.o.get("/staff/intro-icons").data.decode(); self.assertIn('value="rocket"', page); self.assertIn("Intro card icons saved", page)
    def test_each_card_independent_and_default_per_card(self):
        self.save(**{"0": "trophy"}); a, b = IC.intro_cards(); self.assertEqual((a["icon"], b["icon"]), ("trophy", ""))
        self.save(**{"1": "heart"}); a, b = IC.intro_cards(); self.assertEqual((a["icon"], b["icon"]), ("", "heart"))
    def test_restore_default_icons(self):
        self.save(**{"0": "rocket", "1": "banknote"}); changed = self.intro()
        r = self.o.post("/staff/intro-icons", data={"action": "reset", "_csrf": self.tok(self.o)}); self.assertEqual(r.status_code, 302)
        self.assertEqual([c["icon"] for c in IC.intro_cards()], ["", ""]); self.assertNotEqual(self.intro(), changed); self.assertEqual(self.intro().count("<svg"), 2)
        self.assertNotIn("|", "".join(c["icon"] for c in IC.intro_cards())); self.assertNotIn("rocket", dbm.val("SELECT value FROM settings WHERE key='c.home.what_cards'"))
        self.assertEqual(len(C.cl("home.what_cards")[0]), 4)
    def test_invalid_icon_and_stale_form_are_rejected(self):
        self.save(**{"0": "not-an-icon"}); self.assertEqual([c["icon"] for c in IC.intro_cards()], ["", ""])
        d = {"_csrf": self.tok(self.o), "icon_0": "star", "icon_1": "", "title_0": "Old title", "title_1": "Income skills"}; self.o.post("/staff/intro-icons", data=d); self.assertEqual(IC.intro_cards()[0]["icon"], "")
        d = {"_csrf": self.tok(self.o), "icon_0": "<script>", "icon_1": "", "title_0": "Academic learning", "title_1": "Income skills"}; self.o.post("/staff/intro-icons", data=d); self.assertEqual(IC.intro_cards()[0]["icon"], "")
        self.assertEqual(self.o.post("/staff/intro-icons", data={"icon_0": "star"}).status_code, 400)       # CSRF
    def test_text_editor_keeps_icons_and_validates_them(self):
        self.save(**{"0": "rocket"}); lines = S.get("c.home.what_cards").splitlines()
        self.assertTrue(lines[0].endswith("| rocket")); new = lines[0].replace("Academic learning", "Learning") + "\\n" + lines[1]
        r = self.set_cards(new.replace("\\n", "\n")); self.assertEqual(IC.intro_cards()[0]["icon"], "rocket"); self.assertEqual(IC.intro_cards()[0]["title"], "Learning")
        bad = lines[0].replace("| rocket", "| nonsense") + "\n" + lines[1]; self.set_cards(bad); self.assertEqual(IC.intro_cards()[0]["icon"], "rocket")
    def test_reordering_text_keeps_icon_with_its_card(self):
        self.save(**{"0": "rocket", "1": "banknote"}); a, b = S.get("c.home.what_cards").splitlines()
        self.set_cards(b + "\n" + a); c = IC.intro_cards(); self.assertEqual((c[0]["title"], c[0]["icon"], c[1]["icon"]), ("Income skills", "banknote", "rocket"))

class RegistryTests(Base):
    def test_registry(self):
        cat = IC.catalog(); self.assertGreaterEqual(len(cat), 150); self.assertTrue(all(re.fullmatch(r"[a-z0-9-]+", i["n"]) and i["s"].startswith("<") for i in cat))
        for n in ("graduation-cap", "book-open", "rocket", "banknote", "church", "laptop", "briefcase", "heart"): self.assertTrue(IC.valid(n), n)
        self.assertFalse(IC.valid("")); self.assertFalse(IC.valid("../x")); self.assertEqual(str(IC.lucide("nope")), ""); self.assertIn('stroke="currentColor"', IC.lucide("star"))
        self.assertTrue(any("school" in i["k"] for i in cat)); self.assertIn("ISC", json.load(open(IC.PATH))["set"])

class CarouselMarkupTests(IntroBase):
    def test_intro_is_a_carousel_with_dots_and_four_point_five_second_delay(self):
        s = self.intro(); self.assertIn('data-fcar', s); self.assertIn('introcar', s); self.assertIn('data-delay="4500"', s); self.assertIn('class="tdots"', s); self.assertEqual(s.count('class="fslide"'), 2)
        self.assertIn('aria-roledescription="carousel"', s); self.assertEqual(s.count("<div") + 1, s.count("</div>"))      # the section's own wrapper closes in the captured text
    def test_card_count_follows_the_admin_list_and_hiding_works(self):
        three = S.get("c.home.what_cards") + "\nThird card | Third text | /courses | Go"; self.set_cards(three); self.assertEqual(self.intro().count('class="fslide"'), 3)
        S.put("home.show_what", "0"); self.assertEqual(self.intro(), "")
    def test_other_carousels_unchanged_default_delay(self):
        self.assertNotIn("data-delay", re.sub(r'<div class="fcar introcar".*?</section>', "", self.home(), flags=re.S))
